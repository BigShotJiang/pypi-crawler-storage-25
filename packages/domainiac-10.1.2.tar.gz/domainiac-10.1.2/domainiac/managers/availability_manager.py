import datamazing.pandas as pdz
import pandas as pd

from .outage_manager import OutageManager


class AvailabilityManager:
    """
    Manager which simplifies the process of getting availability data.
    """

    def __init__(
        self,
        db: pdz.Database,
        time_interval: pdz.TimeInterval,
        resolution: pd.Timedelta,
    ) -> None:
        self.db = db
        self.time_interval = time_interval
        self.resolution = resolution
        self.outage_manager = OutageManager(db, time_interval, resolution)

    def get_availability(self) -> pd.DataFrame:
        df_availability = self.db.query("schedule_availability", self.time_interval)

        # Rename resource_gsrn to plant_gsrn for consistent merge
        df_availability = df_availability.rename(
            columns={
                "resource_gsrn": "plant_gsrn",
                "schedule_resource_capacity_max_MW": "capacity_max_MW",
                "schedule_resource_capacity_min_MW": "capacity_min_MW",
            }
        )

        required_columns = {
            "time_utc": "datetime64[ns, UTC]",
            "plant_gsrn": "object",
            "capacity_max_MW": "float64",
            "capacity_min_MW": "float64",
        }

        # During market_participant change overlapping availability data might exist.
        # In theory we should be able to check the correct market_participant,
        # using masterdata, but that relies on masterdata being up to date.
        # We know based on past experience that this probably will not match,
        # therefore we will just drop duplicates and keep the most recent entry.
        df_availability = df_availability.sort_values(
            ["plant_gsrn", "time_utc", "created_time_utc"], ascending=False
        ).drop_duplicates(subset=["plant_gsrn", "time_utc"], keep="first")

        # Ensure df_availability has required columns with correct dtypes
        if df_availability.empty:
            df_availability = pd.DataFrame(columns=required_columns.keys()).astype(
                required_columns
            )

        df_outage = self.outage_manager.get_plant_outage_time_series()
        if df_outage.empty:
            df_outage = pd.DataFrame(columns=["plant_gsrn", "time_utc"]).astype(
                {"plant_gsrn": "object", "time_utc": "datetime64[ns, UTC]"}
            )

        # Create an indicator column in outage to mark where outages exist
        df_outage["has_outage"] = True

        # Merge availability with outage data
        df_available = df_availability.merge(
            df_outage, on=["plant_gsrn", "time_utc"], how="outer"
        )

        # Where there's an outage, set capacity to zero
        has_outage = df_available["has_outage"].fillna(False)
        df_available.loc[has_outage, "capacity_max_MW"] = 0
        df_available.loc[has_outage, "capacity_min_MW"] = 0

        # Fill missing capacity values with 0 (from outage-only rows)
        df_available["capacity_max_MW"] = df_available["capacity_max_MW"].fillna(0)
        df_available["capacity_min_MW"] = df_available["capacity_min_MW"].fillna(0)

        # Resample to desired resolution if not already at 1 hour
        if self.resolution != pd.Timedelta("PT1H"):
            df_available = (
                pdz.group(df_available, by=["plant_gsrn"])
                .resample(on="time_utc", bin_size=self.resolution)
                .interpolate(method="ffill")
            )

        # Return only the required columns
        return df_available[list(required_columns.keys())]
