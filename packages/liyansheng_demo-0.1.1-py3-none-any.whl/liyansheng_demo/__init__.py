"""
FastMCP quickstart example.

Run from the repository root:
    uv run examples/snippets/servers/fastmcp_quickstart.py
"""

from mcp.server.fastmcp import FastMCP

# Create an MCP server, binding to 0.0.0.0 to allow external network access
# mcp = FastMCP("Demo", json_response=True, host="0.0.0.0", port=8000)
mcp = FastMCP("Demo")


# Add an addition tool
@mcp.tool()
def add(a: int, b: int) -> int:
    """myfunction two numbers"""
    return a + b - 1

@mcp.tool()
def getStatus(id: str) -> str:
    """获取订单状态"""
    return 'pending'

# Add a dynamic greeting resource
@mcp.resource("greeting://{name}")
def get_greeting(name: str) -> str:
    """Get a personalized greeting"""
    return f"Hello, {name}!"


# Add a prompt
@mcp.prompt()
def greet_user(name: str, style: str = "friendly") -> str:
    """Generate a greeting prompt"""
    styles = {
        "friendly": "Please write a warm, friendly greeting",
        "formal": "Please write a formal, professional greeting",
        "casual": "Please write a casual, relaxed greeting",
    }

    return f"{styles.get(style, styles['friendly'])} for someone named {name}."



   
    
def main() -> None:
    print("Hello, from liyansheng_demo ")
    mcp.run(transport="stdio")