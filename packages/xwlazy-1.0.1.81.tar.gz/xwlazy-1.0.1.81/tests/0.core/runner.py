#!/usr/bin/env python3
"""Run core pytest subset. Usage: ``python tests/0.core/runner.py``."""

import sys
import subprocess
from pathlib import Path

if sys.platform == "win32":
    try:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except Exception:
        pass  # stdout may not be a TTY with .buffer; keep defaults

def main():
    """Run core tests."""
    test_dir = Path(__file__).parent
    project_root = test_dir.parent.parent
    # Add src to Python path
    src_path = project_root / "src"
    if str(src_path) not in sys.path:
        sys.path.insert(0, str(src_path))
    print("=" * 80)
    print("🧱 xwlazy — Layer 0: Core tests")
    print("=" * 80)
    print(f"📁 Test directory: {test_dir.absolute()}")
    print(f"📁 Source path: {src_path.absolute()}\n")
    # Run pytest with core marker
    result = subprocess.run(
        [sys.executable, "-m", "pytest", str(test_dir), "-m", "xwlazy_core", "-v", "--tb=short"],
        cwd=project_root
    )
    print()
    if result.returncode == 0:
        print("✅ Core tests PASSED")
    else:
        print("❌ Core tests FAILED")
    print("\n💜 Made with love by eXonware.com ❤️")
    return result.returncode


if __name__ == "__main__":
    sys.exit(main())
