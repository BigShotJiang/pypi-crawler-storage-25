"""
Regression tests for xwlazy auto-install resolution (GUIDE_51_TEST, GUIDE_53_FIX).

Verifies import-name -> pip-name resolution: HARD_MAPPINGS, runtime registrations,
and lazy_package_getattr (apipkg-style exports + hook-aware imports).
"""

from __future__ import annotations

import sys
import types

import pytest

pytestmark = pytest.mark.xwlazy_unit


def test_resolve_yaml_returns_pyyaml():
    """HARD_MAPPINGS must win so 'yaml' -> 'PyYAML' (not pip install yaml)."""
    from exonware.xwlazy import XWLazy

    guardian = XWLazy(".", default_enabled=True, enable_global_hook=False)
    if hasattr(guardian._resolve_target_cached, "cache_clear"):
        guardian._resolve_target_cached.cache_clear()
    result = guardian._resolve_target("yaml")
    assert result == "PyYAML", f"Expected 'PyYAML' for 'yaml', got {result!r}"


def test_resolve_tomli_w_returns_tomli_w():
    """tomli_w import name must resolve to pip package 'tomli-w'."""
    from exonware.xwlazy import XWLazy

    guardian = XWLazy(".", default_enabled=True, enable_global_hook=False)
    if hasattr(guardian._resolve_target_cached, "cache_clear"):
        guardian._resolve_target_cached.cache_clear()
    result = guardian._resolve_target("tomli_w")
    assert result is not None, "tomli_w should resolve to a pip package name"
    assert "tomli" in result.lower(), f"Expected tomli-related package, got {result!r}"


def test_register_import_mapping_used_in_resolution():
    """Runtime mappings fill gaps apipkg-style namespaces leave vs PyPI names."""
    from exonware.xwlazy import (
        XWLazy,
        register_import_mapping,
        unregister_import_mapping,
    )

    fake_top = "___xwlazy_runtime_map_test_mod___"
    try:
        register_import_mapping(fake_top, "httpx>=0.1")
        guardian = XWLazy(".", default_enabled=True, enable_global_hook=False)
        result = guardian._resolve_target(fake_top)
        assert "httpx" in str(result).lower(), result
    finally:
        unregister_import_mapping(fake_top)


def test_hard_mappings_win_over_runtime_for_same_prefix():
    """Curated TOML / HARD_MAPPINGS must beat a conflicting runtime registration."""
    from exonware.xwlazy import (
        XWLazy,
        register_import_mapping,
        unregister_import_mapping,
    )

    try:
        register_import_mapping("yaml", "wrong-package-for-test")
        guardian = XWLazy(".", default_enabled=True, enable_global_hook=False)
        result = guardian._resolve_target("yaml")
        assert result == "PyYAML", result
    finally:
        unregister_import_mapping("yaml")


def test_lazy_package_getattr_imports_stdlib_module():
    from exonware.xwlazy import lazy_package_getattr
    import json as stdlib_json

    ga = lazy_package_getattr("xwlazy_test_pkg", {"j": "json"})
    assert ga("j") is stdlib_json


def test_lazy_package_getattr_relative_submodule():
    from exonware.xwlazy import lazy_package_getattr

    pkg = types.ModuleType("xwlazy_lazy_pkg_demo")
    pkg.__path__ = []
    sys.modules["xwlazy_lazy_pkg_demo"] = pkg
    sub = types.ModuleType("xwlazy_lazy_pkg_demo.sub")
    sub.mark = 42
    sys.modules["xwlazy_lazy_pkg_demo.sub"] = sub
    try:
        ga = lazy_package_getattr("xwlazy_lazy_pkg_demo", {"sub": ".sub"})
        assert ga("sub") is sub
        assert ga("sub").mark == 42
    finally:
        sys.modules.pop("xwlazy_lazy_pkg_demo.sub", None)
        sys.modules.pop("xwlazy_lazy_pkg_demo", None)
