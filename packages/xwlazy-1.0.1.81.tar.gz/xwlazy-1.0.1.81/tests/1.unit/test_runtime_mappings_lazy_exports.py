"""
Unit tests: register_import_mapping, lazy_package_getattr, exonware re-exports.

Covers validation, copies, and colon-form submodule attributes (GUIDE_51_TEST).
"""

from __future__ import annotations

import collections

import pytest

pytestmark = pytest.mark.xwlazy_unit


def test_register_import_mapping_rejects_empty_import_name():
    from exonware.xwlazy import register_import_mapping

    with pytest.raises(ValueError, match="import_name"):
        register_import_mapping("", "pkg")
    with pytest.raises(ValueError, match="import_name"):
        register_import_mapping("   ", "pkg")


def test_register_import_mapping_rejects_empty_pip_spec():
    from exonware.xwlazy import register_import_mapping

    with pytest.raises(ValueError, match="pip_spec"):
        register_import_mapping("foo", "")
    with pytest.raises(ValueError, match="pip_spec"):
        register_import_mapping("foo", "  ")


def test_get_registered_import_mappings_returns_copy():
    from exonware.xwlazy import (
        get_registered_import_mappings,
        register_import_mapping,
        unregister_import_mapping,
    )

    key = "___xwlazy_copy_test_key___"
    try:
        register_import_mapping(key, "pkg==1")
        a = get_registered_import_mappings()
        b = get_registered_import_mappings()
        assert a == b
        assert a is not b
        a.pop(key)
        assert key in get_registered_import_mappings()
    finally:
        unregister_import_mapping(key)


def test_unregister_import_mapping_idempotent():
    from exonware.xwlazy import unregister_import_mapping

    unregister_import_mapping("___no_such_mapping___")


def test_lazy_package_getattr_colon_returns_attribute():
    from exonware.xwlazy import lazy_package_getattr

    ga = lazy_package_getattr("xwlazy_pkg_colon", {"dq": "collections:deque"})
    assert ga("dq") is collections.deque


def test_lazy_package_getattr_unknown_attribute():
    from exonware.xwlazy import lazy_package_getattr

    ga = lazy_package_getattr("xwlazy_pkg_unknown", {"x": "json"})
    with pytest.raises(AttributeError, match="no attribute 'missing'"):
        ga("missing")


def test_lazy_package_getattr_rejects_empty_package_name():
    from exonware.xwlazy import lazy_package_getattr

    with pytest.raises(ValueError, match="package_name"):
        lazy_package_getattr("", {"a": "json"})


def test_lazy_package_getattr_rejects_empty_exports():
    from exonware.xwlazy import lazy_package_getattr

    with pytest.raises(ValueError, match="exports"):
        lazy_package_getattr("pkg", {})


def test_exonware_module_reexports_mapping_api():
    """Small libs import from exonware.xwlazy; symbols must exist."""
    import exonware.xwlazy as xw

    for name in (
        "register_import_mapping",
        "unregister_import_mapping",
        "get_registered_import_mappings",
        "lazy_package_getattr",
    ):
        assert hasattr(xw, name), f"missing {name}"
        assert callable(getattr(xw, name))


def test_resolve_nested_prefix_uses_runtime_mapping():
    """Walk-up resolution applies runtime map to parent prefix."""
    from exonware.xwlazy import (
        XWLazy,
        register_import_mapping,
        unregister_import_mapping,
    )

    top = "___xwlazy_nested_top___"
    try:
        register_import_mapping(top, "some-dist>=0")
        guardian = XWLazy(".", default_enabled=True, enable_global_hook=False)
        result = guardian._resolve_target(f"{top}.sub.mod")
        assert "some-dist" in str(result).lower()
    finally:
        unregister_import_mapping(top)
