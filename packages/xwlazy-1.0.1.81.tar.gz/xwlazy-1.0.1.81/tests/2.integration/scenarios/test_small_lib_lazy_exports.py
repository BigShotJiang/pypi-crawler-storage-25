"""
Integration: small-package pattern — runtime PyPI mapping + lazy exports (no network).

Mirrors hobby / tiny-library usage: optional deps, system Python, no venv required
for these assertions (GUIDE_51_TEST).
"""

from __future__ import annotations

import sys
import types

import pytest

pytestmark = pytest.mark.xwlazy_integration


def _src_on_path():
    from pathlib import Path

    root = Path(__file__).resolve().parents[3]
    sp = root / "src"
    if str(sp) not in sys.path:
        sys.path.insert(0, str(sp))


_src_on_path()

from exonware.xwlazy import (  # noqa: E402
    lazy_package_getattr,
    register_import_mapping,
    unregister_import_mapping,
    uninstall_global_import_hook,
    XWLazy,
)


class TestSmallLibLazyExportsScenario:

    def teardown_method(self):
        uninstall_global_import_hook()
        unregister_import_mapping("___xwlazy_small_lib_top___")
        sys.modules.pop("xwlazy_small_lib_demo", None)
        sys.modules.pop("xwlazy_small_lib_demo.submod", None)

    def test_runtime_mapping_then_resolve_like_first_import(self):
        """After register_import_mapping, resolver sees pip spec (typical small-lib extension)."""
        top = "___xwlazy_small_lib_top___"
        register_import_mapping(top, "tiny-lib>=0.0.1")
        try:
            g = XWLazy(".", default_enabled=True, enable_global_hook=False)
            spec = g._resolve_target(top)
            assert spec is not None
            assert "tiny-lib" in str(spec).lower()
        finally:
            unregister_import_mapping(top)

    def test_lazy_getattr_defers_submodule_like_apipkg(self):
        """PEP 562 __getattr__ loads submodule only on attribute access."""
        pkg = types.ModuleType("xwlazy_small_lib_demo")
        pkg.__path__ = []
        sub = types.ModuleType("xwlazy_small_lib_demo.submod")
        sub.FLAG = "loaded"
        sys.modules["xwlazy_small_lib_demo"] = pkg
        sys.modules["xwlazy_small_lib_demo.submod"] = sub
        ga = lazy_package_getattr("xwlazy_small_lib_demo", {"submod": ".submod"})
        assert ga("submod").FLAG == "loaded"
