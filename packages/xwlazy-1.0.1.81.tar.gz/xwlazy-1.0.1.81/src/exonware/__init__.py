__path__ = __import__('pkgutil').extend_path(__path__, __name__)
"""``exonware.xwlazy``: optional import hook and lazy-install policy (same implementation as ``xwlazy``)."""

import os
import sys
import importlib.util
from pathlib import Path
_xwlazy_file = Path(__file__).parent / "xwlazy.py"
if _xwlazy_file.exists():
    spec = importlib.util.spec_from_file_location("exonware._xwlazy_module", _xwlazy_file)
    _xwlazy = importlib.util.module_from_spec(spec)
    sys.modules["exonware._xwlazy_module"] = _xwlazy
    spec.loader.exec_module(_xwlazy)
    hook = _xwlazy.hook
    auto_enable_lazy = _xwlazy.auto_enable_lazy
    attach = _xwlazy.attach
    XWLazy = _xwlazy.XWLazy
    enable_keyword_detection = _xwlazy.enable_keyword_detection
    is_keyword_detection_enabled = _xwlazy.is_keyword_detection_enabled
    get_keyword_detection_keyword = _xwlazy.get_keyword_detection_keyword
    check_package_keywords = _xwlazy.check_package_keywords
    enable_learning = _xwlazy.enable_learning
    predict_next_imports = _xwlazy.predict_next_imports
    get_all_stats = _xwlazy.get_all_stats
    generate_sbom = _xwlazy.generate_sbom
    get_lockfile = _xwlazy.get_lockfile
    save_lockfile = _xwlazy.save_lockfile
    install_global_import_hook = _xwlazy.install_global_import_hook
    uninstall_global_import_hook = _xwlazy.uninstall_global_import_hook
    is_global_import_hook_installed = _xwlazy.is_global_import_hook_installed
    is_externally_managed = _xwlazy.is_externally_managed
    resolve_package_lazy_flags = _xwlazy.resolve_package_lazy_flags
    register_import_mapping = _xwlazy.register_import_mapping
    unregister_import_mapping = _xwlazy.unregister_import_mapping
    get_registered_import_mappings = _xwlazy.get_registered_import_mappings
    lazy_package_getattr = _xwlazy.lazy_package_getattr
    add_watched_prefix = _xwlazy.add_watched_prefix
    remove_watched_prefix = _xwlazy.remove_watched_prefix
    get_watched_prefixes = _xwlazy.get_watched_prefixes
    is_module_watched = _xwlazy.is_module_watched
    get_cache_stats = _xwlazy.get_cache_stats
    clear_cache = _xwlazy.clear_cache
    invalidate_cache = _xwlazy.invalidate_cache
    get_performance_stats = _xwlazy.get_performance_stats
    clear_performance_stats = _xwlazy.clear_performance_stats
    lazy_import = _xwlazy.lazy_import
    enable_ast_lazy = _xwlazy.enable_ast_lazy
    disable_ast_lazy = _xwlazy.disable_ast_lazy
    attach_stub = _xwlazy.attach_stub
    get_stub_registry = _xwlazy.get_stub_registry
    config_package_lazy_install_enabled = _xwlazy.config_package_lazy_install_enabled
    if os.environ.get("XWSTACK_SKIP_XWLAZY_INIT", "").lower() not in ("1", "true", "yes"):
        config_package_lazy_install_enabled(
            "exonware.xwlazy",
            enabled=True,
            mode="smart",
        )
else:
    raise ImportError("xwlazy.py module not found!")
try:
    _version_file = Path(__file__).parent / "xwlazy" / "version.py"
    if _version_file.exists():
        _version_spec = importlib.util.spec_from_file_location("exonware.xwlazy.version", _version_file)
        _version_module = importlib.util.module_from_spec(_version_spec)
        _version_spec.loader.exec_module(_version_module)
        __version__ = _version_module.__version__
    else:
        __version__ = "0.0.0"  # fallback only when version.py missing (broken env)
except Exception:
    __version__ = "0.0.0"  # fallback when version.py missing or unloadable (broken env)
__all__ = [
    'hook', 'auto_enable_lazy', 'attach',
    'XWLazy',
    'enable_keyword_detection', 'is_keyword_detection_enabled', 'get_keyword_detection_keyword', 'check_package_keywords',
    'enable_learning', 'predict_next_imports',
    'get_all_stats', 'generate_sbom',
    'get_lockfile', 'save_lockfile',
    'install_global_import_hook', 'uninstall_global_import_hook', 'is_global_import_hook_installed',
    'is_externally_managed',
    'resolve_package_lazy_flags',
    'register_import_mapping', 'unregister_import_mapping', 'get_registered_import_mappings',
    'lazy_package_getattr',
    'add_watched_prefix', 'remove_watched_prefix', 'get_watched_prefixes', 'is_module_watched',
    'get_cache_stats', 'clear_cache', 'invalidate_cache',
    'get_performance_stats', 'clear_performance_stats',
    'lazy_import', 'enable_ast_lazy', 'disable_ast_lazy', 'attach_stub', 'get_stub_registry',
    'config_package_lazy_install_enabled',
]
