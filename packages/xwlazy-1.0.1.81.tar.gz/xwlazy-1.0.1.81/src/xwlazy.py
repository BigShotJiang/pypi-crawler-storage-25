"""Top-level alias for ``exonware.xwlazy`` (wildcard re-export; intentional for this entry point)."""
import sys
from exonware.xwlazy import *  # noqa: F401, F403
# Re-export version from source of truth (exonware.xwlazy does not export __version__ in __all__)
try:
    from exonware.xwlazy.version import __version__
except ImportError:
    __version__ = getattr(sys.modules.get("exonware.xwlazy"), "__version__", "0.0.0")  # fallback when version.py missing
