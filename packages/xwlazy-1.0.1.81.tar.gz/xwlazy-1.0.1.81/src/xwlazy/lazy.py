"""``config_package_lazy_install_enabled`` for downstream packages (e.g. xwsystem, xwnode)."""

from exonware.xwlazy import auto_enable_lazy, lazy_import, resolve_package_lazy_flags

xwimport = lazy_import

__all__ = ["config_package_lazy_install_enabled", "xwimport"]


def config_package_lazy_install_enabled(
    package_name: str,
    enabled: bool = True,
    mode: str = "smart",
    install_hook: bool = True,  # reserved for API compatibility with callers
    **kwargs,
) -> None:
    call_kwargs = dict(kwargs)
    flag_config = resolve_package_lazy_flags(call_kwargs.get("root", "."))
    config_allows_install = flag_config["enable_lazy_install"] is not False
    effective_enabled = bool(enabled) and config_allows_install
    if not effective_enabled:
        return
    if "root" not in call_kwargs and flag_config.get("root_dir"):
        call_kwargs["root"] = flag_config["root_dir"]
    auto_enable_lazy(package_name, mode=mode, **call_kwargs)
