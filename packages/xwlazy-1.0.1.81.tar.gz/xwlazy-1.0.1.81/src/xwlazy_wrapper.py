"""Legacy shim: prefer ``pip install exonware-xwlazy`` and ``import exonware.xwlazy`` or ``import xwlazy``."""

__all__ = []
