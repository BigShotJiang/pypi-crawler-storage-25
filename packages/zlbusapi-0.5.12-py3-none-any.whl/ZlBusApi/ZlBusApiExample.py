#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ZLBus Python SDK 示例代码
========================

本示例展示了如何使用ZLBus Python SDK进行基本操作。
"""
import ZlBusApi as zlapi
import ctypes

def example_basic_usage():
    """基本使用示例"""
    print("=== ZLBus Python SDK 基本使用示例 ===")
    
    # 1. 使用校验和函数
    data = b'\x01\x02\x03\x04'
    # checksum = zlapi.zl_checkSum8_compute(data, len(data))
    # print(f"1 数据 {data.hex(' ').upper()} 的校验和: {hex(checksum).upper()}")

    checkXor = zlapi.zl_checkXor8_compute(data, len(data))
    print(f"1 数据 {data.hex(' ').upper()} 的校验和: {hex(checkXor).upper()}")
    
    # 2. 使用CRC函数
    crc = zlapi.zl_crc16_compute(data, len(data))
    print(f"2 数据 {data.hex(' ').upper()} 的CRC16: {hex(crc).upper()}")
    
    # 3. 使用数据格式修改函数
    # 注意：实际使用时需要提供正确的参数
    # 这里只是展示函数调用方式，实际使用时需要根据具体需求提供参数
    # 缺省参数(rf_id, dot_id)
    result = zlapi.ul_modifyDataFormat(zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_RPY)
    print(f"3 缺省参数(rf_id, dot_id)，修改数据格式结果: {len(result)} | {result.hex(' ').upper()}")

    # 4. 使用数据格式修改函数
    # 输入参数：rf_id = 0x21, dot_id = 0x01
    result = zlapi.ul_modifyDataFormat(zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_RPY, rf_id = 0x21, dot_id = 0x01)
    print(f"4 输入参数(rf_id, dot_id)，修改数据格式结果: {len(result)} | {result.hex(' ').upper()}")


def example_device_operations():
    """设备操作示例"""
    print("\n=== ZLBus Python SDK 设备操作示例 ===")
    
    # 1. 创建设备块列表
    print(f"1 创建DeviceBlock_t实例:")
    block = zlapi.deviceBlock_t()

    # 赋0，初始化
    ctypes.memset(ctypes.addressof(block), 0, ctypes.sizeof(block))

    # 赋值
    block.devId = 0x01
    block.connState = 0x01
    block.mac[:] = (ctypes.c_uint8 * 6)(0x11, 0x22, 0x33, 0x44, 0x55, 0x66)
    device_name = b"ZL25-00000000-0000"
    ctypes.memmove(ctypes.addressof(block.name), device_name, len(device_name))

    # 打印
    print("  block.mac =", bytes(block.mac).hex(' '))
    print("  block.name =", bytes(block.name).split(b'\0', 1)[0].decode('utf-8', errors='ignore'))

    
    # 2. 使用RF功率相关函数
    # 注意：实际使用时需要提供正确的参数
    # 这里只是展示函数调用方式，实际使用时需要根据具体需求提供参数
    #  缺省参数(rf_id, dot_id)
    rf_power = -4
    result = zlapi.ul_modifyIcRfPower(rf_power)
    print(f"2 缺省参数(rf_id, dot_id)，修改RF功率结果: {result.hex(' ').upper()}")

    # 3. 使用RF功率相关函数
    # 输入参数：rf_id = 0x21, dot_id = 0x01
    result = zlapi.ul_modifyIcRfPower(rf_power, rf_id = 0x21, dot_id = 0x01)
    print(f"3 输入参数(rf_id, dot_id)，修改RF功率结果: {len(result)} | {result.hex(' ').upper()}")


def example_decode():
    """解码示例"""
    print("\n=== ZLBus Python SDK 解码示例 ===")

    # 定义辅助函数
    def getBlockContents(addr, block):
        """获取块内容"""
        if addr == 0: 
            print(f'getBlockContents addr is {hex(addr)}, size is {ctypes.sizeof(block)}')
            return None
        return ctypes.cast(addr, ctypes.POINTER(block)).contents

    def getSubBlockContents(addr, block, sub_block):
        """获取子块内容"""
        if addr == 0: 
            print(f'getSubBlockContents addr is {hex(addr)}, size is {ctypes.sizeof(block)}, sub_block size is {ctypes.sizeof(sub_block)}')
            return None
        print(f'getSubBlockContents addr is {hex(addr)}, size is {ctypes.sizeof(block)}, sub_block size is {ctypes.sizeof(sub_block)}')
        return ctypes.cast(addr + ctypes.sizeof(block), ctypes.POINTER(sub_block)).contents

    def printfMemsDataBlock(memsBlock: zlapi.memsDataBlock_t, pkId: zlapi.xxxIdBlock_t):
        """打印 MEMS 数据块内容"""
        print('-----------------------------------------------')
        print(f'zlapi.xxxIdBlock_t is {ctypes.sizeof(zlapi.xxxIdBlock_t)}')
        print(f'userId = 0x{pkId.userId:02X}')  #  用户Id
        print(f'flowId = {pkId.flowId}')        #  流水号
        print(f'cmdId = 0x{pkId.cmdId:02X}, subCmdId = 0x{pkId.subCmdId:02X}')  #  命令Id, 子命令Id
        print(f'rfId = 0x{pkId.rfId:02X}, dotId = 0x{pkId.dotId:02X}')          #  RfId, DotId 

        fmt = memsBlock.effectiveDataFormat
        print(f"  [MEMS] Format: 0x{fmt:08x}")
        
        if fmt & (zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_HL_TIME | zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_TIME):
            print(f"  [MEMS] Timestamp: {memsBlock.timeStamp:.6f} ms")
            print('  [MEMS] timeStamp =', memsBlock.timeStamp)
        
        if fmt & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_QUATERNION:
            q = memsBlock.quat
            print(f"  [MEMS] Quaternion: [{q.element.w:.4f}, {q.element.x:.4f}, {q.element.y:.4f}, {q.element.z:.4f}]")
            
        if fmt & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_RPY:
            e = memsBlock.euler
            print(f"  [MEMS] Euler: [{e.angle.roll:.2f}, {e.angle.pitch:.2f}, {e.angle.yaw:.2f}]")
            
        if fmt & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_ACC:
            a = memsBlock.acc
            print(f"  [MEMS] Acc: [{a.axis.x:.4f}, {a.axis.y:.4f}, {a.axis.z:.4f}]")
            
        if fmt & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_GYRO:
            g = memsBlock.gyro
            print(f"  [MEMS] Gyro: [{g.axis.x:.4f}, {g.axis.y:.4f}, {g.axis.z:.4f}]")
            
        if fmt & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_MAG:
            m = memsBlock.mag
            print(f"  [MEMS] Mag: [{m.axis.x:.4f}, {m.axis.y:.4f}, {m.axis.z:.4f}]")
            
        if fmt & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_LIN_ACC:
            l = memsBlock.lineAcc
            print(f"  [MEMS] LinAcc: [{l.axis.x:.4f}, {l.axis.y:.4f}, {l.axis.z:.4f}]")
            
        if fmt & zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_TEMP:
            print(f"  [MEMS] Temp: {memsBlock.temperature:.2f} C")

    # 解析 BlockID_DATA
    def decodeDataBlock(addr):
        """解码数据块"""
        dataBlock = getBlockContents(addr, zlapi.dataBlock_t)
        if dataBlock is None:
            return
        print(f'dataBlock.dataLen is {dataBlock.dataLen}')
        subBlock = getSubBlockContents(addr, zlapi.dataBlock_t, dataBlockId_map[dataBlock.dataBlockId][0])
        if subBlock is None:
            return
        if (dataBlockId_map[dataBlock.dataBlockId][1] is None):
            return
        dataBlockId_map[dataBlock.dataBlockId][1](subBlock, dataBlock.pkId)

    def decodeOkBlock(addr):
        """解码 OK 响应块"""
        okBlock = getBlockContents(addr, zlapi.cmdOkBlock_t)
        if okBlock is None:
            print('okBlock is None')
            return
        subBlock = getSubBlockContents(addr, zlapi.dataBlock_t, dataBlockId_map[okBlock.dataBlockId][0])
        if subBlock is None:
            print(f'subBlock is None, okBlock.dataBlockId is {okBlock.dataBlockId}')
            return
        if (dataBlockId_map[okBlock.dataBlockId][1] is None):
            print(f'okBlock.dataBlockId is {okBlock.dataBlockId} is not support')
            return
        dataBlockId_map[okBlock.dataBlockId][1](subBlock, okBlock.pkId)

    def decodeErrBlock(addr):
        """解码错误响应块"""
        errBlock = getBlockContents(addr, zlapi.cmdErrBlock_t)
        if errBlock is None:
            print('errBlock is None')
            return
        subBlock = getSubBlockContents(addr, zlapi.dataBlock_t, dataBlockId_map[errBlock.dataBlockId][0])
        if subBlock is None:
            print(f'subBlock is None, errBlock.dataBlockId is {errBlock.dataBlockId}')
            return
        if (dataBlockId_map[errBlock.dataBlockId][1] is None):
            print(f'errBlock.dataBlockId is {errBlock.dataBlockId} is not support')
            return
        dataBlockId_map[errBlock.dataBlockId][1](subBlock, errBlock.pkId)

    # 定义块 ID 映射表（必须在相关函数定义之后）
    # 注意：这个 map 用于根据 dataBlockID 查找子块类型和处理函数
    # 只包含 e_DataBlockID，不包含 e_BlockID
    dataBlockId_map = {
        # e_DataBlockID (使用整数值作为键)
        int(zlapi.e_DataBlockID.DB_ID_MEMS_DATA):    (zlapi.memsDataBlock_t,    printfMemsDataBlock),
        int(zlapi.e_DataBlockID.DB_ID_DEVICE_STATE): (zlapi.deviceStateBlock_t, None),
        int(zlapi.e_DataBlockID.DB_ID_BATTERY):      (zlapi.batteryBlock_t,     None),
        int(zlapi.e_DataBlockID.DB_ID_ADC_VALUE):    (zlapi.adcValueBlock_t,    None),
        # 其他数据块 ID
        # ...
    }

    # 定义块 ID 映射表（必须在相关函数定义之后）
    # 注意：这个 map 用于根据 blockID 查找处理函数
    # 只包含 e_BlockID，不包含 e_DataBlockID
    blockId_map = {
        # e_BlockID (使用整数值作为键)
        int(zlapi.e_BlockID.BlockID_OK):    decodeOkBlock,
        int(zlapi.e_BlockID.BlockID_ERROR): decodeErrBlock,
        int(zlapi.e_BlockID.BlockID_DATA):  decodeDataBlock,
    }

    # 创建数据解码器句柄
    ddb = zlapi.ul_dataDecodeBlockCreate(tracker_nums = 1, user_id = 0xFF, max_nums = 20)

    # 待解码的数据，数据格式为：NEW_UPLOAD_DATA_TIME | NEW_UPLOAD_DATA_QUATERNION | NEW_UPLOAD_DATA_GYRO | NEW_UPLOAD_DATA_LIN_ACC
    data = [
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x6B, 0xE3, 0x82, 0x28, 0x47, 0x0C, 0xF9, 0x7F, 0x3F, 
        0x95, 0xC9, 0xE6, 0x3B, 0x21, 0x41, 0xAA, 0xBA, 0xFB, 0xE7, 0x4F, 0x3C, 0xAC, 0xCB, 0x33, 0x3D, 
        0x0A, 0xCD, 0x65, 0x3D, 0xD7, 0xD8, 0xCA, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0xB0, 
        0x00, 0x00, 0x80, 0x34, 0x38,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x6C, 0xF1, 0x8A, 0x28, 0x47, 0x0C, 0xF9, 0x7F, 0x3F, 
        0x9C, 0xA6, 0xE6, 0x3B, 0x61, 0x51, 0xAA, 0xBA, 0x13, 0xE6, 0x4F, 0x3C, 0x87, 0xEF, 0xCD, 0xBD, 
        0xCF, 0xC3, 0xB6, 0xBD, 0x25, 0x6D, 0x43, 0xBD, 0x00, 0x00, 0x80, 0x2F, 0x00, 0x00, 0x80, 0xB0, 
        0x00, 0x00, 0x00, 0x34, 0x73,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x6D, 0x08, 0x93, 0x28, 0x47, 0x0D, 0xF9, 0x7F, 0x3F, 
        0x2F, 0x91, 0xE6, 0x3B, 0x05, 0x2D, 0xAA, 0xBA, 0x93, 0xE1, 0x4F, 0x3C, 0xD8, 0x5C, 0x34, 0x3D, 
        0x93, 0xC1, 0x65, 0x3D, 0x3C, 0x52, 0xCA, 0x3C, 0x00, 0x00, 0x80, 0x2F, 0x00, 0x00, 0x00, 0x00, 
        0x00, 0x00, 0x40, 0x34, 0x4E,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x6E, 0x0E, 0x9B, 0x28, 0x47, 0x0C, 0xF9, 0x7F, 0x3F, 
        0x13, 0xEE, 0xE6, 0x3B, 0x1C, 0xEC, 0xA9, 0xBA, 0xA4, 0xD3, 0x4F, 0x3C, 0x13, 0x53, 0xEE, 0x3D, 
        0xD8, 0x7C, 0x8C, 0xBC, 0x08, 0xD1, 0x43, 0xBD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x30, 
        0x00, 0x00, 0x00, 0x34, 0xBF,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x6F, 0x1D, 0xA3, 0x28, 0x47, 0x0B, 0xF9, 0x7F, 0x3F, 
        0x0B, 0x0E, 0xE7, 0x3B, 0xFC, 0xBB, 0xAA, 0xBA, 0xBE, 0xDA, 0x4F, 0x3C, 0x25, 0x7D, 0xDD, 0xBC, 
        0xB9, 0x69, 0xB5, 0xBD, 0x44, 0x77, 0xCA, 0x3C, 0x00, 0x00, 0x80, 0x2F, 0x00, 0x00, 0x80, 0xB0, 
        0x00, 0x00, 0x00, 0x34, 0xE7,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x70, 0x5A, 0xAB, 0x28, 0x47, 0x0B, 0xF9, 0x7F, 0x3F, 
        0xE5, 0xFB, 0xE6, 0x3B, 0xC0, 0xD7, 0xA9, 0xBA, 0x60, 0xE2, 0x4F, 0x3C, 0x44, 0x65, 0xE9, 0xBC, 
        0xBA, 0x7A, 0x65, 0x3D, 0xFA, 0x54, 0xCA, 0x3C, 0x00, 0x00, 0x80, 0xAF, 0x00, 0x00, 0x80, 0xB0, 
        0x00, 0x00, 0x80, 0x33, 0x8F,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x71, 0x49, 0xB3, 0x28, 0x47, 0x0B, 0xF9, 0x7F, 0x3F, 
        0xC1, 0x2B, 0xE7, 0x3B, 0xD6, 0xAE, 0xA9, 0xBA, 0x28, 0xD6, 0x4F, 0x3C, 0x19, 0x99, 0x2C, 0x3D, 
        0x93, 0x63, 0x5E, 0x3D, 0x71, 0x8A, 0xF6, 0xBD, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
        0x00, 0x00, 0x00, 0x34, 0xFD,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x72, 0x48, 0xBB, 0x28, 0x47, 0x0A, 0xF9, 0x7F, 0x3F, 
        0xAE, 0x45, 0xE7, 0x3B, 0xAD, 0x87, 0xA9, 0xBA, 0x86, 0xDF, 0x4F, 0x3C, 0x0A, 0x9D, 0x30, 0x3D, 
        0x24, 0xD5, 0x61, 0x3D, 0x8E, 0x02, 0x44, 0xBD, 0x00, 0x00, 0x80, 0xAF, 0x00, 0x00, 0x80, 0xB0, 
        0x00, 0x00, 0x00, 0x00, 0xD9,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x73, 0x57, 0xC3, 0x28, 0x47, 0x0A, 0xF9, 0x7F, 0x3F, 
        0x59, 0x1C, 0xE7, 0x3B, 0x32, 0x4F, 0xA9, 0xBA, 0xBF, 0xE3, 0x4F, 0x3C, 0xEA, 0x35, 0xDB, 0xBC, 
        0xD8, 0x3D, 0x7D, 0xBC, 0xB0, 0xF3, 0xC6, 0x3D, 0x00, 0x00, 0x80, 0xAF, 0x00, 0x00, 0x00, 0x00, 
        0x00, 0x00, 0x80, 0xB3, 0x26,
        0xAA, 0x10, 0x30, 0x00, 0x02, 0x20, 0x00, 0x74, 0x65, 0xCB, 0x28, 0x47, 0x09, 0xF9, 0x7F, 0x3F, 
        0x58, 0x37, 0xE7, 0x3B, 0x1A, 0xC1, 0xA9, 0xBA, 0xEE, 0xEA, 0x4F, 0x3C, 0x95, 0xDF, 0x3A, 0x3D, 
        0xE0, 0xA1, 0xB5, 0xBD, 0x68, 0xC3, 0xC9, 0x3C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x30, 
        0x00, 0x00, 0x80, 0xB3, 0x2D
    ]
    # 手动设置解码格式（data）
    """
    1、待解码的数据data为静态数据，数据格式需要使用zlapi.ul_manualModifyDataFormat手动设置 
    2、在实际的应用中，使用 zlapi.ul_getDataFormat 方法获取模块上传的数据，不需要
    zlapi.ul_manualModifyDataFormat手动进行设置数据解码格式
    3、zlapi.ul_getDataFormat返回值在使用ul_dataBlockDecode方法进行解码过程中，内部自动更
       新数据解码格式，所以不需要调用zlapi.ul_manualModifyDataFormat手动设置
    """
    zlapi.ul_manualModifyDataFormat(ddb, 0, zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_TIME | \
                                            zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_QUATERNION | \
                                            zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_GYRO | \
                                            zlapi.e_Upload_DataFormat.NEW_UPLOAD_DATA_LIN_ACC)

    # 将收到的原始字节流送入解码器，解码后的数据节点追加到链表中。
    zlapi.ul_dataBlockDecode(ddb, bytes(data))

    # 有效节点个数
    node_size = zlapi.ul_dataBlockNodeCount(ddb)
    print('cur node_size =', node_size)

    for i in range(node_size):
        # blockId
        blockId = zlapi.ul_dataBlockGetBlockID(ddb)
        
        if blockId not in blockId_map:
            print(f'blockId is {blockId} is not support')
            zlapi.ul_dataBlockSkipNode(ddb) # 跳过数据
            continue
        blockId_map[blockId](zlapi.ul_dataBlockGetBlock(ddb))
        zlapi.ul_dataBlockSkipNode(ddb) # 跳过数据
        print('cur node_size =', zlapi.ul_dataBlockNodeCount(ddb))
    
    # 销毁解码器句柄。
    zlapi.ul_dataDecodeBlockDelete(ddb)


def example():
    try:
        print()
        example_basic_usage()
        example_device_operations()
        print("\n所有示例执行完成。")
    except Exception as e:
        print(f"执行示例时出错: {e}")

if __name__ == "__main__":
    try:
        example()
        example_decode()
        print("\n解码示例执行完成。")
    except Exception as e:
        print(f"执行解码示例时出错：{e}")
        import traceback
        traceback.print_exc()

