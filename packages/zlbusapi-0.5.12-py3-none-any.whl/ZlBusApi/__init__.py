"""
ZLBus API Python Interface Package
"""

# This file makes the directory a Python package

# Import main classes and functions from zlbus_api module
from .ZlBusApi import *

from .ZlBusApiExample import example, example_decode

# Import all modules from zlbus_modules
from .zlbusModules import *

# Define what should be imported with "from zlbus_api import *"
__all__ = [
    'example',
    'example_decode',

    # 工具函数
    'zl_checkXor8_compute',         # 计算 8 位异或校验和
    'zl_checkSum8_compute',         # 计算 8 位校验和
    'zl_crc16_compute',             # 计算 16 位 CRC 校验和
    
    # 数据解码
    'ul_dataDecodeBlockCreate',     # 创建数据解码块
    'ul_dataDecodeBlockDelete',     # 删除数据解码块
    'ul_dataBlockNodeCount',        # 获取数据链表（内部 FIFO）上有效节点数量
    'ul_dataBlockGetBlockID',       # 获取数据链表（内部 FIFO）上头节点 blockId
    'ul_dataBlockGetBlock',         # 从数据链表中获取头节点的有效数据内存指针
    'ul_dataBlockGetBlockDataLen',  # 从数据链表中获取头节点的有效数据内存大小  
    'ul_dataBlockSkipNode',         # 删除数据链表(内部FIFO)上头节点，并释放节点内存
    'ul_dataBlockReadNode',         # 从数据链表中读取头节点数据并删除该节点（释放内存）。
    'ul_dataBlockNodeClear',        # 清除数据链表中的所有节点
    'ul_dataBlockDecode',           # 将收到的原始字节流送入解码器，解码后的数据节点追加到链表中
    'ul_manualModifyDataFormat',    # 手动修改指定tracker的上传数据格式（e_UPLOAD_FORMAT位图）
    'ul_manualModifyDataFlowIdFormat', # 手动设置流水号格式
    
    # 用户指令
    "ul_modifyDataFormat",          # 修改输出数据格式
    "ul_modifyDataFormatNotSave",   # 修改输出数据格式（不保存到配置文件）
    "ul_getDataFormat",             # 获取输出数据格式
    "ul_modifySampleHz",            # 修改采样频率
    "ul_getSampleHz",               # 获取采样频率
    "ul_modifyUploadHz",            # 修改上传频率
    "ul_getUploadHz",               # 获取上传频率
    "ul_startMagnetometerCalibration", # 开始磁力计校准
    "ul_configDataFilter",          # 配置滤波参数
    "ul_clearDataFilter",           # 清除滤波参数
    "ul_getDataFilter",             # 获取滤波参数
    "ul_modifyIcConvention",        # 修改IC安装方向
    "ul_getIcConvention",           # 获取IC安装方向
    "ul_modifyIcAdvName",           # 修改RF广播名称
    "ul_getIcAdvName",              # 获取RF广播名称
    "ul_modifyIcRfPower",           # 修改RF功率
    "ul_getIcRfPower",              # 获取RF功率
    "ul_disconnectIcRf",            # 断开RF连接
    "ul_enableDataOutPut",          # 使能数据输出
    "ul_disEnableDataOutPut",       # 禁用数据输出
    "ul_resetYaw2zero",             # Yaw归零   
    "ul_enableAdcCalibration",      # 启动ADC归1000化校准
    "ul_disableAdcCalibration",     # 退出ADC归1000化校准
    "ul_disableAdcCalibrationRead", # 退出ADC归1000化校准,并读取校准结果
    "ul_setFingerOrder",            # 设置手指顺序（正序 or 反序）
    "ul_getFingerOrder",            # 读取手指顺序（正序 or 反序）
    "ul_configAdcCalibrationMode",  # 配置ADC校准模式
    "ul_configAdcNormalizationMode",# 开启与关闭归1000化校准模式
    "ul_enterLedInteraction",       # 进入LED交互模式
    "ul_exitLedInteraction",        # 退出LED交互模式
    "ul_modifyLedInteractionColor", # 修改LED交互颜色
    "ul_getLedInteractionColor",    # 获取LED交互颜色
    "ul_modifyUartBaudRate",        # 修改串口波特率
    "ul_getUartBaudRate",           # 获取串口波特率
    "ul_modifyBlockSize",           # 修改BlockSize
    "ul_getBlockSize",              # 获取BlockSize
    "ul_imuStaticCalibrationInit",  # IMU六面静态校准初始化
    "ul_imuStaticCalibration",      # IMU六面静态校准
    "ul_imuStaticCalibrationExit",  # IMU六面静态校准退出
    "ul_clearStaticCalibrationParam", # 清除静态校准参数
    "ul_getMacAddressStr",          # 获取MAC地址
    "ul_getDeviceSnStr",            # 获取设备序列号
    "ul_getBoardVesionStr",         # 获取板卡版本
    "ul_getFirmwareVesionStr",      # 获取固件版本
    "ul_deviceShutdown",            # 设备关机
    "ul_restoreFactorySettings",    # 恢复出厂设置

    # UHL 高级指令
    "hl_modifyDataFormat",          # 高级修改输出数据格式
    "hl_modifyDataFormatNotSave",   # 高级修改输出数据格式（不保存到配置文件）
    "hl_getDataFormat",             # 高级获取输出数据格式
    "hl_modifyDotId",               # 高级修改DotId
    "hl_getDotId",                  # 高级获取DotId
    "hl_modifyRfConnInterval",      # 高级修改RF连接间隔
    "hl_getRfConnInterval",         # 高级获取RF连接间隔
    "hl_modifyAccRange",            # 高级修改ACC量程
    "hl_getAccRange",               # 高级获取ACC量程
    "hl_modifyGyroRange",           # 高级修改Gyro量程
    "hl_getGyroRange",              # 高级获取Gyro量程
    "hl_modifyMagEllCalParam_Ex",   # 高级修改磁力计椭球拟合校准参数
    "hl_getMagEllCalParam_Ex",      # 高级获取磁力计椭球拟合校准参数
    "hl_clearGyroBias",             # 高级清除Gyro Bias
    "hl_configFlowFormat",          # 高级配置流水号格式
    "hl_getFlowFormat",             # 高级获取流水号格式
    "hl_resetFlowNums",             # 高级重置流水号
    "hl_disableAhrsOffsetCal",      # 高级禁用姿态偏移校准
    "hl_setAhrsOffsetParam",        # 高级设置姿态偏移参数
    "hl_getAhrsOffsetParam",        # 高级获取姿态偏移参数
    "hl_configOutDataPort",         # 高级配置数据输出端口
    "hl_getOutDataPort",            # 高级获取数据输出端口
    "hl_checkOutDataPort",          # 高级检查数据输出端口
    "hl_getMachineStatus",          # 高级获取机器状态码
    "hl_configFingerFilterParam",   # 高级配置手指ADC滤波参数
    "hl_getFilterParam",            # 高级获取滤波参数
    "hl_setFingerMap",              # 高级设置手指Map
    "hl_getFingerMap",              # 高级获取手指Map（可选，默认0xFF）
    "hl_swapUserUartTrxPin",        # 高级切换用户UART引脚
    "hl_enableUserSpim",            # 高级使能用户SPIM
    "hl_disableUserSpim",           # 高级禁用用户SPIM
    "hl_enableUserSpis",            # 高级使能用户SPIS
    "hl_disableUserSpis",           # 高级禁用用户SPIS
    "hl_configUserAdc",             # 高级配置用户ADC
    "hl_enableUserBattery",         # 高级使能用户电池
    "hl_disableUserBattery",        # 高级禁用用户电池
    "hl_enableUserRgbLed",          # 高级使能用户RGB LED
    "hl_disableUserRgbLed",         # 高级禁用用户RGB LED
    "hl_enableUserBtn",             # 高级使能用户按钮
    "hl_disableUserBtn",            # 高级禁用用户按钮
    "hl_enableUserPowerEn",         # 高级使能用户电源
    "hl_disableUserPowerEn",        # 高级禁用用户电源
    "hl_enableUserRf",              # 高级使能用户RF
    "hl_enableUserRfPa",            # 高级使能用户RF PA
    "hl_disableUserRfPa",           # 高级禁用用户RF PA

    # Dongle（dl_）系列接口
    "dl_getDeviceFullSnId",         # Dongle获取完整设备序列号
    "dl_modifyDeviceList",          # Dongle修改设备列表
    "dl_getBoardVesionStr",         # Dongle获取板卡版本
    "dl_getFirmwareVesionStr",      # Dongle获取固件版本
    "dl_getDeviceList",             # Dongle获取设备列表
    "dl_clearDeviceList",           # Dongle清除设备列表
    "dl_getDeviceConnList",         # Dongle获取设备连接列表
    "dl_keepDeviceConnList",        # Dongle保持设备连接列表
    "dl_enableScan",                # Dongle使能扫描
    "dl_disEnableScan",             # Dongle禁用扫描
    "dl_disConnectAll",             # Dongle断开所有连接设备
    "dl_configIdentifyWay",         # Dongle配置识别方式
    "dl_getIdentifyWay",            # Dongle获取识别方式
    "dl_outputToXXX",               # Dongle配置数据输出目标
    "dl_restoreFactorySettings",    # Dongle恢复出厂设置
    "dl_deviceShutdown",            # Dongle设备关机
]

# Add package version
__version__ = '0.12.0'
