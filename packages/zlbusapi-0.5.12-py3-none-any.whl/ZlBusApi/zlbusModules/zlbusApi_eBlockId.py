# -*- coding: utf-8 -*-
"""
BlockID 枚举全集（与 C 代码 1:1 对应）
"""

from enum import IntEnum

from .zlbusConfig import *

# -------------------- 统一 BlockID 枚举 --------------------
class e_BlockID(IntEnum):
    """顶层通用 BlockID"""
    BlockID_OK                     = 0x0000D000,    # cmdOkBlock_t
    BlockID_ERROR                  = 0xFFFF0000,    # cmdErrBlock_t
    BlockID_DATA                   = 0x00001000,    # dataBlock_t

# -------------------- 数据导出 BlockID --------------------
# @Note 规则：(cmdId << 8) | subCmdId
class e_DataBlockID(IntEnum) :
    """上报数据包"""
    DB_ID_MEMS_DATA                = 0x00001000,    # memsDataBlock_t
    DB_ID_DEVICE_STATE             = 0x00001100,    # deviceStateBlock_t
    DB_ID_BATTERY                  = 0x00001400,    # batteryBlock_t
    DB_ID_ADC_VALUE                = 0x00001500,    # adcValueBlock_t

    """ 指令返回包"""
    DB_ID_SET_UPLOAD_DATAFORMAT    = 0x0000D500,    # 修改输出数据格式
    DB_ID_GET_UPLOAD_DATAFORMAT    = 0x0000D501,    # uploadDataFormatBlock_t
    DB_ID_SET_SAMPLING_HZ          = 0x0000D502,    # 修改内部采样频率
    DB_ID_GET_SAMPLING_HZ          = 0x0000D503,    # samplingHzBlock_t
    DB_ID_SET_UPLOAD_HZ            = 0x0000D504,    # 修改数据上传频率
    DB_ID_GET_UPLOAD_HZ            = 0x0000D505,    # uploadHzBlock_t
    DB_ID_MAG_ELL_CAL_ENABLE       = 0x0000D506,    # 启动磁力计校准
    DB_ID_SET_AHRS_FILTER_PARAM    = 0x0000D508,    # 配置滤波系数
    DB_ID_CLR_AHRS_FILTER_PARAM    = 0x0000D50A,    # 清除滤波系数
    DB_ID_GET_AHRS_FILTER_PARAM    = 0x0000D50B,    # filterMapBlock_t
    DB_ID_SET_IC_DIR               = 0x0000D50C,    # 修改IC安装方向
    DB_ID_GET_IC_DIR               = 0x0000D50D,    # icDirBlock_t
    DB_ID_SET_RF_ADV_NAME          = 0x0000D50E,    # 修改IC RF 广播名称
    DB_ID_GET_RF_ADV_NAME          = 0x0000D50F,    # devieRfNameBlock_t
    DB_ID_SET_RF_POWER             = 0x0000D510,    # 修改IC RF Power
    DB_ID_GET_RF_POWER             = 0x0000D511,    # rfPowerBlock_t
    DB_ID_RF_CONN_ENABLE           = 0x0000D512,    # 开IC RF 连接
    DB_ID_UPLOAD_DATA_ENABLE       = 0x0000D514,    # 开启数据输出
    DB_ID_UPLOAD_DATA_DISABLE      = 0x0000D515,    # 禁止数据输出
    DB_ID_SET_YAW_ZERO             = 0x0000D516,    # 归零Yaw角度
    DB_ID_ADC_NORM_CAL_ENABLE      = 0x0000D530,    # 启动ADC归1000化校准
    DB_ID_ADC_NORM_CAL_DISABLE     = 0x0000D531,    # 退出ADC归1000化校准 or adcRangeBlock_t
    DB_ID_SET_SET_ADC_ORDER        = 0x0000D532,    # 设置手指顺序（配置ADC顺序）
    DB_ID_GET_GET_ADC_ORDER        = 0x0000D533,    # 获取手指顺序（读取ADC顺序） adcOrderBlock_t or fingerOrderBlock_t
    DB_ID_SET_ADC_NORM_CAL         = 0x0000D534,    # 配置ADC归1000化校准模式
    DB_ID_CONF_ADC_NORM_MODE       = 0x0000D535,    # 开启与关闭归1000化校准模式
    DB_ID_LED_MODE_ENTER           = 0x0000D560,    # 开启LED交互
    DB_ID_LED_MODE_EXIT            = 0x0000D561,    # 退出LED交互
    DB_ID_SET_LED_COLOR            = 0x0000D562,    # 修改LED交互模式下，灯颜色与点灯模式
    DB_ID_GET_LED_COLOR            = 0x0000D563,    # ledRgbDataBlock_t
    DB_ID_SET_UART_BAUDRATE        = 0x0000D564,    # 修改串口波特率
    DB_ID_GET_UART_BAUDRATE        = 0x0000D565,    # uartBaudRateBlock_t
    DB_ID_SET_SPIM_IIC_BLOCKSIZE   = 0x0000D566,    # 修改IIC (SPIM) BlockSIze
    DB_ID_GET_SPIM_IIC_BLOCKSIZE   = 0x0000D567,    # blockSizeBlock_t
    DB_ID_SET_STATIC_CAL_N6        = 0x0000D56E,    # 进入N面静态校准模式, IMU N面静态校准, 退出N面静态校准模式
    DB_ID_CLR_STATIC_CAL_N6        = 0x0000D56F,    # 清除六面校准参数
    DB_ID_GET_MAC_ADDDR_STR        = 0x0000D577,    # deviceMacBlock_t
    DB_ID_GET_FULL_SN_STR          = 0x0000D579,    # deviceSnFullStrBlock_t
    DB_ID_GET_BOARD_VERSION_STR    = 0x0000D57B,    # deviceBoardVersionBlock_t
    DB_ID_GET_FIRMWARE_VERSION_STR = 0x0000D57D,    # deviceFirmwareVersionBlock_t
    DB_ID_DEVICE_SHUTDOWN          = 0x0000D57E,    # 设备关机
    DB_ID_RESTORE_FACTORY_SETTINGD = 0x0000D57F,    # 恢复出厂设置

    # if UHL_LEVEL_EN:
    """ UHL 指令 BlockID（可选）"""
    DB_ID_HL_SET_DOTID             = 0x0000D602,    # 修改DotID
    DB_ID_HL_GET_DOTID             = 0x0000D603     # dotIdBlock_t
    DB_ID_HL_SET_RF_CONNINTERVAL   = 0x0000D606,    # 修改Rf ConnInterval
    DB_ID_HL_GET_RF_CONNINTERVAL   = 0x0000D607     # bleConnIntervalBlock_t
    DB_ID_HL_SET_ACC_RANGE         = 0x0000D610,    # 修改加速度量程
    DB_ID_HL_GET_ACC_RANGE         = 0x0000D611     # accRangeBlock_t
    DB_ID_HL_SET_GYR_RANGE         = 0x0000D612,    # 修改陀螺量程
    DB_ID_HL_GET_GYR_RANGE         = 0x0000D613     # gyroRangeBlock_t
    DB_ID_HL_SET_MAG_ELL_CAL_PARAM = 0x0000D61A,    # 修改磁力计椭球拟合校准参数
    DB_ID_HL_GET_MAG_ELL_CAL_PARAM = 0x0000D61B     # magEllipsoidCalParamBlock_t
    DB_ID_HL_SET_FLOWID_FORMAT     = 0x0000D620,    # 配置流水号格式
    DB_ID_HL_GET_FLOWID_FORMAT     = 0x0000D621     # flowIdFormatBlock_t
    DB_ID_HL_RESET_FLOWID          = 0x0000D622,    # 重置流水号
    DB_ID_HL_CLR_AHRS_OFFSET       = 0x0000D628,    # 取消姿态纠正
    DB_ID_HL_SET_AHRS_OFFSET       = 0x0000D62A,    # 配置姿态纠正参数
    DB_ID_HL_GET_AHRS_OFFSET       = 0x0000D62B     # ahrsOffsetBlock_t
    DB_ID_HL_SET_DATA_OUTPORT      = 0x0000D630,    # 配置 数据输出接口
    DB_ID_HL_GET_DATA_OUTPORT      = 0x0000D631     # dataPortBlock_t   
    DB_ID_HL_GET_DATA_OUTPORT_MAP  = 0x0000D633     # dataPortMapBlock_t
    DB_ID_HL_GET_DEVICE_STATE      = 0x0000D635     # deviceStateBlock_t
    DB_ID_HL_SET_ADC_FILTER_PARAM  = 0x0000D640,    # 设置 手指 ADC 滤波参数
    DB_ID_HL_GET_ADC_FILTER_PARAM  = 0x0000D641     # adcFilterParam_t
    DB_ID_HL_SET_FINGER_MAP        = 0x0000D642,    # 设置 手指Map
    DB_ID_HL_GET_FINGER_MAP        = 0x0000D643     # fingerMapBlock_t
    DB_ID_HL_SWAP_UART_IO          = 0x0000D660,    # 交换 Uart Trx Pin
    DB_ID_HL_SPIM_ENABLE           = 0x0000D664,    # 开启 SPIM, 关闭 SPIM
    DB_ID_HL_SPIS_ENABLE           = 0x0000D666,    # 开启 SPIS, 关闭 SPIS
    DB_ID_HL_ADC_ENABLE            = 0x0000D66A,    # 配置 ADC 端口
    DB_ID_HL_BATTERY_ENABLE        = 0x0000D66C,    # 开启 Battery, 关闭 Battery
    DB_ID_HL_RGBLED_ENABLE         = 0x0000D670,    # 开启 RgbLed, 关闭 RgbLed
    DB_ID_HL_BTN_ENABLE            = 0x0000D672,    # 开启 按钮, 关闭 按钮
    DB_ID_HL_POWEREN_ENABLE        = 0x0000D674,    # 开启 电源管理, 关闭 电源管理
    DB_ID_HL_RF_ENABLE             = 0x0000D676,    # 开启 RF
    DB_ID_HL_RFPA_ENABLE           = 0x0000D678,    # 开启 RfPa, 关闭 RfPa

    # if UDG_LEVEL_EN:
    """ UDG 指令 BlockID（可选）"""
    DB_ID_DG_GET_SN_FULL_STR       = 0x0000C001     # dongleSnFullStrBlock_t
    DB_ID_DG_GET_BOARD_VERSION     = 0x0000C007     # DL_DeviceBoardVersionBlock 
    DB_ID_DG_GET_FIRMWARE_VERSION  = 0x0000C008     # DL_DeviceFirmwareVersionBlock
    DB_ID_DG_SET_DEVICE_LIST2      = 0x0000C010     # 修改设备列表2
    DB_ID_DG_GET_DEVICE_LIST       = 0x0000C011     # 获取设备列表
    DB_ID_DG_CLEAR_DEVICE_LIST     = 0x0000C012     # 清除设备列表
    DB_ID_DG_GET_DEVICE_CONN_LIST  = 0x0000C013     # 获取设备连接列表
    DB_ID_DG_KEEP_DEVICE_CONN_LIST = 0x0000C014     # 保持设备连接列表
    DB_ID_DG_SCAN_ENABLE           = 0x0000C015     # 启用扫描
    DB_ID_DG_SCAN_DISABLE          = 0x0000C016     # 关闭扫描
    DB_ID_DG_DISCONNECT_ALL_DEVICES = 0x0000C017    # 断开所有设备连接
    DB_ID_DG_SET_RECOGNITION_MODE  = 0x0000C020,    # 配置识别方式
    DB_ID_DG_GET_RECOGNITION_MODE  = 0x0000C021,    # 获取识别方式
    DB_ID_DG_OUTPUT_TO_USB         = 0x0000C070,    # 输出数据到USB
    DB_ID_DG_RESET_FACTORY         = 0x0000C07D,    # 恢复出厂设置
    DB_ID_DG_CLOSE_DEVICE          = 0x0000C07F,    # 关闭设备

    # if FDG_LEVEL_EN:
    """ FDG 指令 BlockID（可选）"""
    DB_ID_DG_SCAN                  = 0x00000000     # DL_ScanBlock
    DB_ID_DG_TIMESTAMP_SYNC        = 0x0000000F     # DL_TimeStampSyncBlock

