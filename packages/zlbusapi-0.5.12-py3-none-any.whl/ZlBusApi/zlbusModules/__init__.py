"""
ZLBus API Modules Package

This package contains all the ZLBus API modules.
"""

from .zlbusConfig import *
from .zlbusBaseType import *
from .zlbusApiType import *
from .zlbusError import *
from .zlbusStackConfig import (
    DEFAULT_RF_DISCONN,
    DEFAULT_RFID,
    DEFAULT_DOTID,
    DEFAULT_DONGLEID,
    e_ERROR_CMU,
)
from .zlbusApi_eBlockId import *

__all__ = [
    #-------------------------
    'zlbusConfig', 
    'zlbusBaseType', 
    'zlbusApiType', 
    'zlbusError', 
    'zlbusStackConfig',
    'zlbusApi_eBlockId', 
    #-------------------------
    # e_BlockID
    "e_BlockID",
    "e_DataBlockID",

    # zlbusBaseType
    "Axis3_I16",
    "Axis3_Float",
    "AhrsQuaternion",
    "AhrsEuler",
    "FingerValue_I16",
    "Axis3_ScaleDpsBlock",

    # zlbusApiType | 基础
    "xxxIdBlock_t",
    "cmdOkBlock_t",
    "cmdErrBlock_t",
    "dataBlock_t",
    "e_Upload_DataFormat",
    "memsDataBlock_t",
    "deviceStateBlock_t",
    "batteryBlock_t",
    "adcValueBlock_t",
    "uploadDataFormatBlock_t",
    "e_SampleHz",
    "samplingHzBlock_t",
    "e_UploadHz",
    "uploadHzBlock_t",
    "e_FiterParam",
    "filterMapBlock_t",
    "e_Convention",
    "icDirBlock_t",
    "adcRangeBlock_t",
    "adcOrderBlock_t",
    "fingerOrderBlock_t",
    "devieRfNameBlock_t",
    "rfPowerBlock_t",
    "e_LedColor",
    "e_LedMode",
    "ledRgbDataBlock_t",
    "e_BaudRate",
    "uartBaudRateBlock_t",
    "blockSizeBlock_t",
    "deviceMacBlock_t",
    "deviceSnFullStrBlock_t",
    "deviceBoardVersionBlock_t",
    "deviceFirmwareVersionBlock_t",

    # zlbusApiType | 高级 | UHL
    "dotIdBlock_t",
    "bleConnIntervalBlock_t",
    "e_AccRange",
    "accRangeBlock_t",
    "e_GyroRange",
    "gyroRangeBlock_t",
    "magEllipsoidCalParamBlock_t",
    "e_TK_FlowIdFormat",
    "flowIdFormatBlock_t",
    "ahrsOffsetBlock_t",
    "e_DataOutPort",
    "dataPortBlock_t",
    "dataPortMapBlock_t",
    "adcFilterParam_t",
    "fingerMapBlock_t",
    "e_AdcEn",
    "e_BlockSizeType",

    # zlbusApiType | Dongle | UDG
    "deviceBlock_t",
    "deviceBlockList_t",
    "dongleSnFullStrBlock_t",
    "deviceConnNumsBlock_t",
    "identifyWayBlock_t",
    "scanBlock_t",
    "timeStampSyncBlock_t",

    # zlbusError
    'TKxx_SUCCESS',
    'TKxx_ERR_FAILED',
    'TKxx_ERR_READY',
    'TKxx_ERR_MEM',
    'TKxx_ERR_MAX_SIZE',
    'TKxx_ERR_INTERN',
    'TKxx_ERR_BUSY',
    'TKxx_ERR_ALREADY',
    'TKxx_ERR_VAL',
    'TKxx_ERR_NULL',
    'TKxx_ERR_TIMEOUT',
    'TKxx_ERR_NONE',

    # zlbusStackConfig
    "DEFAULT_RF_DISCONN",
    "DEFAULT_RFID",
    "DEFAULT_DOTID",
    "DEFAULT_DONGLEID",
    "e_ERROR_CMU",
]