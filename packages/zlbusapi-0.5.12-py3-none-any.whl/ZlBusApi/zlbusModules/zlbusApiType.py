"""
ZLBus API Type Python Interface

This module provides Python encapsulations of the C structures defined in the zlbusApiType.h header file.
"""

import ctypes
from ctypes import c_uint8, c_uint16, c_uint32, c_uint64, c_int8, c_bool, c_float, c_double
from .zlbusBaseType import Axis3_I16, Axis3_Float, AhrsQuaternion, AhrsEuler

from enum import IntEnum

from .zlbusConfig import *

# -----------------------------------------------------------------------------
# 1. 基本 ID 结构
# -----------------------------------------------------------------------------
class _xxxIdBlockU(ctypes.Union):
    _pack_   = 4          # 按 4 字节对齐，和 C 保持一致
    _fields_ = [
        ("rfId",     ctypes.c_uint8),          # 整个字节
        ("_bits",    ctypes.c_uint8, 8),       # 位段载体
    ]

    # 用 property 把位段再拆成 icId/dongleId
    @property
    def icId(self):
        return self._bits & 0x1F

    @icId.setter
    def icId(self, val):
        self._bits = (self._bits & 0xE0) | (val & 0x1F)

    @property
    def dongleId(self):
        return (self._bits >> 5) & 0x07

    @dongleId.setter
    def dongleId(self, val):
        self._bits = ((val & 0x07) << 5) | (self._bits & 0x1F)


# 基本ID结构
class xxxIdBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4          # 按 4 字节对齐，和 C 保持一致
    """基本ID结构"""
    _fields_ = [
        ("cmdId",    ctypes.c_uint8),
        ("subCmdId", ctypes.c_uint8),
        ("u",        _xxxIdBlockU),           # 对应 C 里的匿名 union
        ("dotId",    ctypes.c_uint8),
        ("flowId",   ctypes.c_uint32),
        ("userId",   ctypes.c_uint8),
    ]

    # 让外部可直接读写 rfId / icId / dongleId
    rfId     = property(lambda s: s.u.rfId,     lambda s, v: setattr(s.u, 'rfId', v))
    icId     = property(lambda s: s.u.icId,     lambda s, v: setattr(s.u, 'icId', v))
    dongleId = property(lambda s: s.u.dongleId, lambda s, v: setattr(s.u, 'dongleId', v))


# -----------------------------------------------------------------------------
# 2. 通用块结构 (OK / Error)
# -----------------------------------------------------------------------------
# 成功块
class cmdOkBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4  # 【重要】强制 1 字节对齐，防止 padding
    _fields_ = [
        ("pkId", xxxIdBlock_t),
        ("dataBlockId", c_uint32),
        ("dataLen", c_uint32),
        ("data", c_uint8 * 0),  # 柔性数组占位
    ]


# 错误块
class cmdErrBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("pkId", xxxIdBlock_t),
        ("dataBlockId", c_uint32),
        ("errCode", c_uint8),
    ]


# 数据块
class dataBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("pkId", xxxIdBlock_t),
        ("dataBlockId", c_uint32),
        ("dataLen", c_uint32),
        ("data", c_uint8 * 0),
    ]


# uBIT(n) => 1 << n
def uBIT(n: int) -> int:
    return 1 << n

class e_Upload_DataFormat(IntEnum):
    """数据格式位掩码枚举"""
    NEW_UPLOAD_DATA_QUATERNION = uBIT(0)   # /* 四元数           */
    NEW_UPLOAD_DATA_RPY        = uBIT(1)   # /* 欧拉角           */
    NEW_UPLOAD_DATA_ACC        = uBIT(2)   # /* 加速度 g         */
    NEW_UPLOAD_DATA_GYRO       = uBIT(3)   # /* 陀螺仪 °/s       */
    NEW_UPLOAD_DATA_MAG        = uBIT(4)   # /* 磁力计 uT        */
    NEW_UPLOAD_DATA_LIN_ACC    = uBIT(5)   # /* 线性加速度 g/s²  */

    NEW_UPLOAD_DATA_TEMP       = uBIT(14)  # /* IMU 传感器温度   */
    NEW_UPLOAD_DATA_ADCx       = uBIT(16)  # /* ADC(手指弯曲)    */
    NEW_UPLOAD_DATA_REDUCED    = uBIT(29)  # /* REDUCED(压缩数据)*/
    NEW_UPLOAD_DATA_HL_TIME    = uBIT(30)  # /* 时间戳 (double)  */
    NEW_UPLOAD_DATA_TIME       = uBIT(31)  # /* 时间戳 (float)   */


# -----------------------------------------------------------------------------
# 3. 数据输出结构
# -----------------------------------------------------------------------------

# IMU 数据
class memsDataBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("effectiveDataFormat", c_uint32),  # enum e_UPLOAD_FORMAT
        ("timeStamp", c_double),            # 时间戳 [单位：ms]
        ("temperature", c_float),           # 温度 [单位：℃]
        ("quat", AhrsQuaternion),           # 四元数
        ("euler", AhrsEuler),               # 欧拉角 [单位：°]
        ("acc", Axis3_Float),               # 加速度计 [单位：g]
        ("gyro", Axis3_Float),              # 陀螺仪 [单位：°/s]
        ("mag", Axis3_Float),               # 磁力计 [单位：uT]
        ("lineAcc", Axis3_Float),           # 线性加速度 [单位：g]
    ]

    # ------- 可选字段 -------
    _fields_.extend([
        ("None0", Axis3_Float * 4),
        ("None1", Axis3_I16 * 3),
    ])


# 设备状态
class deviceStateBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("deviceState", c_uint32),  # 模块(IC) 状态
    ]


# 电池
class batteryBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("mvOk", c_bool),
        ("levelOk", c_bool),
        ("mv", c_uint16),
        ("level", c_uint8),
    ]

# ADC 弯曲传感器
UL_ADC_MAX_NUMS = 6

class adcValueBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("effectiveDataFormat", c_uint32),
        ("timeStamp", c_double),            # 时间戳 [单位：ms]
        ("normalization", c_bool),
        ("adcNums", c_uint32),
        ("adcValue", c_uint16 * UL_ADC_MAX_NUMS),
    ]


class adcRangeBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("adcValue", c_uint16 * UL_ADC_MAX_NUMS),
    ]

class adcOrderBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("order", c_uint8), # ADC 顺序 (1: 【5 4 3 2 1 6】, 0: 【1 2 3 4 5 6】)
    ]

class fingerOrderBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("order", c_uint8), # 手指顺序 (1: 左手, 0: 右手)
    ]

# -----------------------------------------------------------------------------
# 4. 基本指令结构
# -----------------------------------------------------------------------------
class uploadDataFormatBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("uploadDataFormat", c_uint32),  # 上报数据格式 {e_Upload_DataFormat}
    ]

class e_SampleHz(IntEnum):
    """采样频率"""
    TK_Sample_200HZ = 200  # 200 Hz
    TK_Sample_240HZ = 240  # 240 Hz
    TK_Sample_250HZ = 250  # 250 Hz

class samplingHzBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("samplingHz", c_uint16),  # 采样频率 {e_SampleHz}
    ]

# 上传频率枚举
class e_UploadHz(IntEnum):
    TK_Sample_200HZ_DIVx_UPLOAD_1HZ = 0xC8
    TK_Sample_200HZ_DIVx_UPLOAD_5HZ = 0x28
    TK_Sample_200HZ_DIVx_UPLOAD_10HZ = 0x14
    TK_Sample_200HZ_DIVx_UPLOAD_20HZ = 0x0A
    TK_Sample_200HZ_DIVx_UPLOAD_25HZ = 0x08
    TK_Sample_200HZ_DIVx_UPLOAD_50HZ = 0x04
    TK_Sample_200HZ_DIVx_UPLOAD_100HZ = 0x02
    TK_Sample_200HZ_DIVx_UPLOAD_200HZ = 0x01

    TK_Sample_240HZ_DIVx_UPLOAD_1HZ = 0xF0
    TK_Sample_240HZ_DIVx_UPLOAD_5HZ = 0x30
    TK_Sample_240HZ_DIVx_UPLOAD_10HZ = 0x18
    TK_Sample_240HZ_DIVx_UPLOAD_20HZ = 0x0C
    TK_Sample_240HZ_DIVx_UPLOAD_25HZ = 0x09
    TK_Sample_240HZ_DIVx_UPLOAD_30HZ = 0x08
    TK_Sample_240HZ_DIVx_UPLOAD_60HZ = 0x04
    TK_Sample_240HZ_DIVx_UPLOAD_120HZ = 0x02
    TK_Sample_240HZ_DIVx_UPLOAD_240HZ = 0x01

    TK_Sample_250HZ_DIVx_UPLOAD_1HZ = 0xFA
    TK_Sample_250HZ_DIVx_UPLOAD_5HZ = 0x32
    TK_Sample_250HZ_DIVx_UPLOAD_10HZ = 0x19
    TK_Sample_250HZ_DIVx_UPLOAD_25HZ = 0x0A
    TK_Sample_250HZ_DIVx_UPLOAD_50HZ = 0x05
    TK_Sample_250HZ_DIVx_UPLOAD_250HZ = 0x01


class uploadHzBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("UploadHz", c_uint16),  # 上报频率 (采样分频表示上报频率) {e_UploadHz}
    ]


# 滤波参数枚举
class e_FiterParam(IntEnum):
    """滤波参数位掩码枚举"""
    TK_StaticFiter           = 1 << 0  # 静态滤波
    TK_SixAxisDataFiter      = 1 << 1  # 6轴模式
    TK_MagDataFixedFiter     = 1 << 4  # 抗磁干扰
    TK_TemperatureCompensate = 1 << 6  # 温度补偿
    TK_ZeroOffsetFiter       = 1 << 7  # 实时滤波(零点滤波)
    TK_ZeroReckonFiter       = 1 << 9  # 零点积分滤波


class filterMapBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("filterMap", c_uint16),  # 滤波参数 {e_FiterParam}
    ]


# IC安装方向枚举
class e_Convention(IntEnum):
    TK_NED_0 = 0x00  # default value
    TK_NED_1 = 0x01
    TK_NED_2 = 0x02
    TK_NED_3 = 0x03
    TK_ENU_0 = 0x04
    TK_ENU_1 = 0x05
    TK_ENU_2 = 0x06
    TK_ENU_3 = 0x07


class icDirBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("icDir", c_uint8),  # IC 安装方向 {e_Convention}
    ]


class devieRfNameBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("name", c_uint8 * 20),  # Rf 广播名称 {字符串}
    ]


class rfPowerBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("rssi", c_int8),  # dBm
    ]


# RGB Color枚举
class e_LedColor(IntEnum):
    TK_LED_RED = 0x01    # 红
    TK_LED_GREEN = 0x02  # 绿
    TK_LED_BLUE = 0x04   # 蓝
    TK_LED_YELLOW = 0x03 # 黄
    TK_LED_PUEPLE = 0x05 # 紫
    TK_LED_CYAN = 0x06   # 青
    TK_LED_WHITE = 0x07  # 白


# RGB 点灯模式枚举
class e_LedMode(IntEnum):
    TK_LED_MODE_LIGHT = 0      # 常亮
    TK_LED_MODE_BREATHE = 1    # 呼吸灯
    TK_LED_MODE_FLICKER_LOW = 1    # 低频闪烁
    TK_LED_MODE_FLICKER_MEDIUM = 2 # 中频闪烁
    TK_LED_MODE_FLICKER_HIGH = 3   # 高频闪烁


class ledRgbDataBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("color", c_uint8),  # LED 颜色 {e_LedColor}
        ("mode", c_uint8),   # LED 点亮模式 {e_LedMode}
    ]


# 波特率枚举
class e_BaudRate(IntEnum):
    TK_BaudRate_115200 = 0x1C200
    TK_BaudRate_128000 = 0x1F400
    TK_BaudRate_256000 = 0x3E800
    TK_BaudRate_460800 = 0x70800
    TK_BaudRate_512000 = 0x7D000
    TK_BaudRate_750000 = 0xB71B0
    TK_BaudRate_921600 = 0xE1000


class uartBaudRateBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("baudRate", c_uint32),  # 串口波特率
    ]


class blockSizeBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("type", c_uint8),      # enum e_BlockSizeType
        ("blockSize", c_uint8),
    ]


class deviceMacBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("macStr", c_uint8 * 18),  # MAC 地址
    ]


class deviceSnFullStrBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("snFullStr", c_uint8 * 24),  # 完整设备SN编码
    ]


class deviceBoardVersionBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("boardVersion", c_uint8 * 64),  # 硬件版本号
    ]


class deviceFirmwareVersionBlock_t(ctypes.LittleEndianStructure):
    _pack_ = 4
    _fields_ = [
        ("firmwareVersion", c_uint8 * 64),  # 固件版本号
    ]

# -----------------------------------------------------------------------------
# 5. 高级指令 (条件编译部分)
# ⚠️ 注意：需根据实际 SDK 版本保留或注释相关字段
# -----------------------------------------------------------------------------
if UHL_LEVEL_EN:
    class dotIdBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("dotId", c_uint8),  # dotId
        ]

if UHL_LEVEL_EN:
    class bleConnIntervalBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("bleConnInterval", c_float),  # 交互间隔
        ]

if UHL_LEVEL_EN:
    # 加速度计量程枚举
    class e_AccRange(IntEnum):
        TK_ACC_RANGE_2G = 0x00   # ±2G
        TK_ACC_RANGE_4G = 0x01   # ±4G
        TK_ACC_RANGE_8G = 0x02   # ±8G
        TK_ACC_RANGE_16G = 0x03  # ±16G

    class accRangeBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("accRange", c_uint8),  # 加速度计量程
        ]


    # 陀螺仪量程枚举
    class e_GyroRange(IntEnum):
        TK_GYRO_RANGE_250DPS = 0x00   # ±250DPS
        TK_GYRO_RANGE_500DPS = 0x01   # ±500DPS
        TK_GYRO_RANGE_1000DPS = 0x02  # ±1000DPS
        TK_GYRO_RANGE_2000DPS = 0x03  # ±2000DPS
        TK_GYRO_RANGE_4000DPS = 0x03  # ±4000DPS 仅限于高量程 支持

    class gyroRangeBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("gyroRange", c_uint8),  # 陀螺仪量程
        ]

if UHL_LEVEL_EN:
    class magEllipsoidCalParamBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("kX", c_float), ("kY", c_float), ("kZ", c_float),
            ("Ox", c_float), ("Oy", c_float), ("Oz", c_float),
        ]

    # 流水号格式枚举
    class e_TK_FlowIdFormat(IntEnum):
        TK_FLOW_ID_FORMAT_8 = 0
        TK_FLOW_ID_FORMAT_16 = 1


    class flowIdFormatBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("flowIdFormat", c_uint8),  # 上传数据流水号格式
        ]

    ahrsOffsetBlock_t = AhrsQuaternion

if UHL_LEVEL_EN:
    # 数据输出端口类型枚举
    class e_DataOutPort(IntEnum):
        TK_RF_PORT = 1 << 0
        TK_UART_PORT = 1 << 1
        TK_SPIM_PORT = 1 << 3


    class dataPortBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("dataPort", c_uint16),  # 数据输出端口
        ]


    # blockID: 0xD633
    class dataPortMapBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("dataPortMap", c_uint16),  # 可用输出端口
        ]

    class adcFilterParam_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("offset", c_uint16),
            ("kp", c_float),
        ]

    class fingerMapBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("fingerMap", c_uint8),  # 手指Map
        ]

if UHL_LEVEL_EN:
    # adcEnableMap枚举
    class e_AdcEn(IntEnum):
        TK_ADC0_ENABLE = 1 << 0
        TK_ADC1_ENABLE = 1 << 1
        TK_ADC2_ENABLE = 1 << 2
        TK_ADC3_ENABLE = 1 << 3
        TK_ADC4_ENABLE = 1 << 4
        TK_ADC5_ENABLE = 1 << 5


    # BlockSizeType枚举
    class e_BlockSizeType(IntEnum):
        iic_blockSizeType = 0
        spim_blockSizeType = 1

#------------------------------------------------------------------------------------------------
# Dongle指令
#------------------------------------------------------------------------------------------------
if UDG_LEVEL_EN:
    class deviceBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        """设备信息块"""
        _fields_ = [
            ("devId",     ctypes.c_uint8),      # uint8_t devId
            ("connState", ctypes.c_uint8),      # uint8_t connState
            ("mac",       ctypes.c_uint8 * 6),  # uint8_t mac[6]
            ("name",      ctypes.c_uint8 * 20), # uint8_t name[20]
        ]

    class deviceBlockList_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("list", deviceBlock_t * 20),
            ("nums", c_uint8),
        ]

    class dongleSnFullStrBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("snFullStr", c_uint8 * 24),  # 完整设备SN编码
        ]

    class deviceConnNumsBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [("connNums", c_uint8)]

    class identifyWayBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [("isMacType", c_uint8)]

    class scanBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [
            ("mac", c_uint8 * 6),
            ("name", c_uint8 * 20),
        ]

    class timeStampSyncBlock_t(ctypes.LittleEndianStructure):
        _pack_ = 4
        _fields_ = [("timeStamp", c_double)]


