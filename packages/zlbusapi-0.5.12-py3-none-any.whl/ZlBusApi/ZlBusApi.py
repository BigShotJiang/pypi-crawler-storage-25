"""
ZLBus API Python Interface

This module provides a Python interface to the ZLBus API library.
"""

import os
import platform
import ctypes
from ctypes import CDLL
from ctypes import c_uint8, c_uint16, c_uint32, c_int8, c_int16, c_int32, c_bool, c_float   
from ctypes import c_void_p, c_char_p, POINTER, byref, cast, create_string_buffer

# from zlbusModules import *
from .zlbusModules import (
    magEllipsoidCalParamBlock_t,
    adcFilterParam_t,
    deviceBlockList_t
)
from .zlbusModules import AhrsQuaternion
from .zlbusModules import DEFAULT_RFID, DEFAULT_DOTID, DEFAULT_DONGLEID

def _get_dll_name():
    """根据操作系统和架构获取合适的DLL文件名"""
    system = platform.system()
    architecture = platform.architecture()[0]
    machine = platform.machine().lower()
    
    if system == 'Windows':
        # Windows下只考虑64位版本
        return 'zlbus_x64.dll'
    elif system == 'Linux':
        # Linux下根据架构选择不同的库文件
        if 'aarch' in machine:
            return 'libzlbus_arm64.so'
        elif 'arm' in machine:
            return 'libzlbus_armv7l.so'
        else:
            return 'libzlbus_x64.so'
    else:
        # 其他系统默认使用Linux x64版本
        return 'libzlbus_x64.so'

_dll_name = _get_dll_name()

def _find_dll_path():
    """查找DLL文件的路径，支持多种可能的位置和新的目录结构"""
    system = platform.system()
    
    # 根据系统确定子目录
    system_subdir = 'linux' if system == 'Linux' else 'win'
    
    # 首先尝试在包目录的bin/[system]子目录中查找
    package_bin_path = os.path.join(os.path.dirname(__file__), 'bin', system_subdir, _dll_name)
    if os.path.exists(package_bin_path):
        return package_bin_path
    
    # 如果在包目录中找不到，尝试在site-packages的bin/[system]目录中查找
    try:
        import site
        site_packages = site.getsitepackages()
        for site_package in site_packages:
            site_bin_path = os.path.join(site_package, 'bin', system_subdir, _dll_name)
            if os.path.exists(site_bin_path):
                return site_bin_path
    except:
        pass
    
    # 如果还是找不到，尝试在sys.prefix的bin/[system]目录中查找
    try:
        import sys
        prefix_bin_path = os.path.join(sys.prefix, 'bin', system_subdir, _dll_name)
        if os.path.exists(prefix_bin_path):
            return prefix_bin_path
    except:
        pass
    
    # 尝试在包目录的上一级目录的bin/[system]目录中查找（处理pip安装的情况）
    parent_bin_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'bin', system_subdir, _dll_name)
    if os.path.exists(parent_bin_path):
        return parent_bin_path
    
    # 如果所有位置都找不到，返回包目录中的路径（用于显示错误信息）
    return package_bin_path

_bin_path = _find_dll_path()

class SafeDLL:
    def __init__(self, dll):
        self._dll = dll

    def __getattr__(self, name):
        try:
            return getattr(self._dll, name)
        except AttributeError:
            # Return a dummy function that does nothing and returns 0
            def dummy_func(*args, **kwargs):
                return 0
            return dummy_func

try:
    _lib = SafeDLL(CDLL(_bin_path))
except OSError as e:
    print(f"Warning: Could not load {_dll_name} from {_bin_path}. Some functions may not be available.")
    _lib = SafeDLL(None)

# Define types
uint8_t = c_uint8
uint16_t = c_uint16
uint32_t = c_uint32
int16_t = c_int16
int32_t = c_int32
bool_t = c_bool

# -------------------------------------------------------------
# 工具：申请/释放帧缓存的快捷函数
# -------------------------------------------------------------
_MAX_FRAME = 256          # 内部统一缓存大小
_MAX_MAX_FRAME = 1024     # 内部统一缓存大小
_M_ID = 2
_S_ID = 1
_S_ID_MAX = 0x11

def _make_buffer(max_size: int = 256):
    """创建默认 256 字节的帧缓存并返回 (buffer, c_uint16(max_size))"""
    buf = create_string_buffer(max_size)
    return cast(buf, POINTER(c_uint8)), c_uint16(max_size)

# 统一包装
def _call_cmd(cmdType, func, rf_id, dot_id, *args) -> bytes:
    """
    统一调用函数
    :param func: 底层 C 函数，要求拥有属性 cmdType = _S_ID 或 _M_ID
                 _S_ID -> int func(rf_id,        buf, buf_len)
                 _M_ID -> int func(rf_id, dot_id, buf, buf_len)
    :param rf_id: 必传
    :param dot_id: 当 cmdType == _S_ID 时，设置None即可
    :param args:  额外位置参数，放在固定参数之前
    :return:      bytes
    """
    if cmdType == _S_ID_MAX:
        max_frame = _MAX_MAX_FRAME
    else:
        max_frame = _MAX_FRAME
    # 统一缓冲区
    buf, buf_len = _make_buffer(max_frame)
    # print('buf_len:', type(buf_len), buf_len)
    if cmdType == _M_ID:
        c_args = args + (rf_id, dot_id, buf, buf_len)
    elif cmdType == _S_ID or cmdType == _S_ID_MAX:
        c_args = args + (rf_id, buf, buf_len)
    else:
        raise ValueError('cmdType must be _S_ID or _M_ID')

    # print('\n', type(buf))
    # print(hex(rf_id), hex(dot_id))
    buf_size = func(*c_args)
    # print(buf_size)
    if buf_size < 0:
        raise RuntimeError(f'_call_cmd failed, ret={buf_size}')
    return ctypes.string_at(buf, buf_size)

# -------------------------------------------------------------
# -------------------------------------------------------------


# Function prototypes
# ---------- zl_checkXor8_compute ----------
_lib.zl_checkXor8_compute.argtypes = [POINTER(uint8_t), uint32_t]
_lib.zl_checkXor8_compute.restype = uint8_t

def zl_checkXor8_compute(data, size):
    """
    计算 8 位异或校验和
    
    对给定的数据计算异或校验和。通过将数据中的每个字节进行异或运算，
    最终得到一个 8 位的校验和值。
    
    :param data: 包含数据的 bytes 或 bytearray
    :param size: 数据大小
    :return: 异或校验和 (uint8_t)
    """
    data_array = (uint8_t * size).from_buffer_copy(data)
    return _lib.zl_checkXor8_compute(data_array, size)

# ---------- zl_checkSum8_compute ----------
_lib.zl_checkSum8_compute.argtypes = [POINTER(uint8_t), uint32_t]
_lib.zl_checkSum8_compute.restype = uint8_t

def zl_checkSum8_compute(data: bytes, size: int) -> int:
    """
    计算 8 位校验和
    
    对给定的数据计算 8 位校验和。通过将数据中的每个字节进行累加运算，
    最终得到一个 8 位的校验和值。
    
    :param data: 数据指针 (bytes 或 bytearray)
    :param size: 数据大小
    :return: 校验和 (uint8_t)
    """
    data_array = (uint8_t * size).from_buffer_copy(data)
    return _lib.zl_checkSum8_compute(data_array, size)

# ---------- zl_crc16_compute ----------
_lib.zl_crc16_compute.argtypes = [POINTER(uint8_t), uint32_t, POINTER(uint16_t)]
_lib.zl_crc16_compute.restype = uint16_t

def zl_crc16_compute(data: bytes, size: int, crc_init: int = 0xFFFF) -> int:
    """
    计算 16 位 CRC 校验和
    
    对给定的数据计算 16 位 CRC 校验和。支持初始 CRC 值的设置，
    通常用于连续计算或分段计算场景。
    
    :param data: 数据指针 (bytes 或 bytearray)
    :param size: 数据大小
    :param crc_init: CRC 校验和初始值 (默认 0xFFFF)
    :return: CRC 校验和 (uint16_t)
    """
    data_array = (uint8_t * size).from_buffer_copy(data)
    crc_in = uint16_t(crc_init)
    return _lib.zl_crc16_compute(data_array, size, ctypes.byref(crc_in))

# ---------- ota_firmware_crc32_compute ----------
_lib.ota_firmware_crc32_compute.argtypes = [POINTER(uint8_t), uint32_t, POINTER(uint32_t)]
_lib.ota_firmware_crc32_compute.restype = uint32_t

def ota_firmware_crc32_compute(data: bytes, size: int, crc_init: int = 0xFFFFFFFF) -> int:
    """
    计算 32 位 CRC 校验和
    
    对给定的数据计算 32 位 CRC 校验和，主要用于 OTA 固件镜像的校验。
    支持初始 CRC 值的设置，通常用于连续计算或分段计算场景。
    
    :param data: 数据指针 (bytes 或 bytearray)
    :param size: 数据大小
    :param crc_init: CRC 校验和初始值 (默认 0xFFFFFFFF)
    :return: CRC 校验和 (uint32_t)
    """
    data_array = (uint8_t * size).from_buffer_copy(data)
    crc_in = uint32_t(crc_init)
    return _lib.ota_firmware_crc32_compute(data_array, size, ctypes.byref(crc_in))

#------------------------------------------------------------------------------------------------------
# 数据解码
#------------------------------------------------------------------------------------------------------

# ---------- 创建/销毁解码器 ----------
_lib.ul_dataDecodeBlockCreate.argtypes = [uint8_t, uint8_t, uint16_t]
_lib.ul_dataDecodeBlockCreate.restype  = c_void_p           # 返回 uint32_t* 作为句柄

_lib.ul_dataDecodeBlockDelete.argtypes = [c_void_p]
_lib.ul_dataDecodeBlockDelete.restype  = None

def ul_dataDecodeBlockCreate(tracker_nums: int, user_id: int, max_nums: int) -> int:
    """
    创建数据解码块

    创建数据解码器句柄，用于后续的流数据解码操作。解码器内部维护一个 FIFO 队列，
    用于存储解码后的数据节点。

    :param tracker_nums: 上传数据的 IC 数量（同时接入的 tracker 数量）
    :param user_id: 用户 ID
    :param max_nums: 最大数据数量（内部 FIFO 深度，最大缓存节点数）
    :return: 数据解码块句柄（int，实际为 uint32_t* 指针）
    :raises RuntimeError: 创建失败时抛出异常
    """
    handle = _lib.ul_dataDecodeBlockCreate(uint8_t(tracker_nums), uint8_t(user_id), uint16_t(max_nums))
    if not handle:
        raise RuntimeError("ul_dataDecodeBlockCreate failed")
    return handle

def ul_dataDecodeBlockDelete(handle: int) -> None:
    """
    删除数据解码块

    销毁解码器句柄，释放解码器占用的所有资源。
    调用此函数后，不应再使用该句柄进行任何操作。

    :param handle: 数据解码块句柄
    """
    _lib.ul_dataDecodeBlockDelete(c_void_p(handle))

# ---------- 链表状态查询 ----------
_lib.ul_dataBlockNodeCount.argtypes = [c_void_p]
_lib.ul_dataBlockNodeCount.restype  = c_int32

_lib.ul_dataBlockGetBlockID.argtypes = [c_void_p]
_lib.ul_dataBlockGetBlockID.restype  = uint32_t

_lib.ul_dataBlockGetBlock.argtypes = [c_void_p]
_lib.ul_dataBlockGetBlock.restype  = c_void_p

_lib.ul_dataBlockGetBlockDataLen.argtypes = [c_void_p]
_lib.ul_dataBlockGetBlockDataLen.restype  = uint32_t

def ul_dataBlockNodeCount(handle: int) -> int:
    """
    获取数据链表（内部 FIFO）上有效节点数量

    返回当前解码器内部 FIFO 队列中有效数据节点的数量。
    可用于判断是否有待处理的数据。

    :param handle: 数据解码块句柄
    :return: 有效节点数量（int32_t）
    """
    return _lib.ul_dataBlockNodeCount(c_void_p(handle))

def ul_dataBlockGetBlockID(handle: int) -> int:
    """
    获取数据链表（内部 FIFO）上头节点 blockId

    从解码器内部 FIFO 队列中获取头节点的数据块 ID（blockId），
    用于后续读取或跳过操作时识别数据类型。

    :param handle: 数据解码块句柄
    :return: blockId（uint32_t）
    """
    return _lib.ul_dataBlockGetBlockID(c_void_p(handle))

def ul_dataBlockGetBlock(handle: int) -> int:
    """
    从数据链表中获取头节点的有效数据内存指针

    从解码器内部 FIFO 队列中获取头节点的有效数据内存指针地址。
    此操作不会释放内存，返回的是内存地址整数。

    :param handle: 数据解码块句柄
    :return: 数据内存地址（int）
    :warning: 不要手动释放此指针，应由 ul_dataBlockSkipNode 或 ul_dataBlockReadNode 管理
    """
    ptr = _lib.ul_dataBlockGetBlock(c_void_p(handle))
    return ptr if ptr is not None else 0

def ul_dataBlockGetBlockDataLen(handle: int) -> int:
    """
    从数据链表中获取头节点的有效数据内存大小

    从解码器内部 FIFO 队列中获取头节点的有效数据内存大小（字节数）。
    此操作不会释放内存。

    :param handle: 数据解码块句柄
    :return: 有效数据内存大小（uint32_t，单位：bytes）
    """
    return _lib.ul_dataBlockGetBlockDataLen(c_void_p(handle))

# ---------- 链表节点操作 ----------
_lib.ul_dataBlockSkipNode.argtypes = [c_void_p]
_lib.ul_dataBlockSkipNode.restype  = None

_lib.ul_dataBlockReadNode.argtypes = [c_void_p, c_void_p, uint16_t]
_lib.ul_dataBlockReadNode.restype  = c_int32

def ul_dataBlockSkipNode(handle: int) -> None:
    """
    删除数据链表(内部FIFO)上头节点，并释放节点内存
    # 参数:
    #   handle: 解码器句柄
    # 返回值: None
    """
    _lib.ul_dataBlockSkipNode(c_void_p(handle))

def ul_dataBlockReadNode(handle: int, block_size: int) -> bytes:
    """
    从数据链表中读取头节点数据并删除该节点（释放内存）。
    
    :param handle: 句柄
    :param buffer_size: 缓冲区大小。建议先调用 ul_dataBlockGetBlockDataLen 获取准确长度。
    :return: 读取到的数据 (bytes)。如果失败抛出异常。
    """
    buf = create_string_buffer(block_size)
    ret = _lib.ul_dataBlockReadNode(c_void_p(handle), buf, uint16_t(block_size))
    if ret < 0:
        raise RuntimeError(f"ul_dataBlockReadNode failed, ret={ret}")
    return ctypes.string_at(buf, block_size)    # 将 C 语言风格的内存缓冲区（指针）转换为 Python 的 bytes 对象

_lib.ul_dataBlockNodeClear.argtypes = [c_void_p]
_lib.ul_dataBlockNodeClear.restype  = c_int32

def ul_dataBlockNodeClear(handle: int) -> int:
    """
    清除数据链表中的所有节点
    # 参数:
    #   handle: 解码器句柄
    # 返回值: int：0成功，<0失败
    """
    return _lib.ul_dataBlockNodeClear(c_void_p(handle))

# ---------- 流数据解码 ----------
_lib.ul_dataBlockDecode.argtypes = [c_void_p, POINTER(uint8_t), uint16_t]
_lib.ul_dataBlockDecode.restype  = None

def ul_dataBlockDecode(handle: int, data: bytes) -> None:
    """
    将收到的原始字节流送入解码器，解码后的数据节点追加到链表中
    # 参数:
    #   handle: 解码器句柄
    #   data: 原始流数据 bytes/bytearray
    # 返回值: None
    """
    data_len = len(data)
    data_array = (uint8_t * data_len).from_buffer_copy(data)
    _lib.ul_dataBlockDecode(c_void_p(handle), data_array, uint16_t(data_len))

# ---------- 手动设置参数 ----------
_lib.ul_manualModifyDataFormat.argtypes = [c_void_p, uint8_t, uint32_t]
_lib.ul_manualModifyDataFormat.restype  = c_int32

def ul_manualModifyDataFormat(handle: int, tracker_index: int, data_format: int) -> int:
    """
    手动修改指定tracker的上传数据格式（e_UPLOAD_FORMAT位图）
    # 参数:
    #   handle: 解码器句柄
    #   tracker_index: Tracker索引
    #   data_format: 数据格式
    # 返回值: int：0成功，<0失败
    """
    return _lib.ul_manualModifyDataFormat(c_void_p(handle), uint8_t(tracker_index), uint32_t(data_format))

_lib.ul_manualModifyDataFlowIdFormat.argtypes = [c_void_p, uint8_t]
_lib.ul_manualModifyDataFlowIdFormat.restype  = c_int32

def ul_manualModifyDataFlowIdFormat(handle: int, flow_id_format: int) -> int:
    """
    手动设置流水号格式
    # 参数:
    #   handle: 解码器句柄
    #   flow_id_format: 流水号格式 (0 -> FLOW_ID_FORMAT_8, 1 -> FLOW_ID_FORMAT_16)
    # 返回值: int：0成功，<0失败
    """
    return _lib.ul_manualModifyDataFlowIdFormat(c_void_p(handle), uint8_t(flow_id_format))

_lib.ul_getDataFlowIdFormat.argtypes = [c_void_p]
_lib.ul_getDataFlowIdFormat.restype  = c_uint32

def ul_getDataFlowIdFormat(handle: int) -> int:
    """
    返回流水号格式
    # 参数:
    #   handle: 解码器句柄
    # 返回值: int：0 -> FLOW_ID_FORMAT_8, 1 -> FLOW_ID_FORMAT_16
    """
    return _lib.ul_getDataFlowIdFormat(c_void_p(handle))

#------------------------------------------------------------------------------------------------
# 用户指令
#------------------------------------------------------------------------------------------------

# -------------------------------------------------------------
# 1. 修改/获取输出数据格式
# -------------------------------------------------------------
_lib.ul_modifyDataFormatEx.argtypes = [c_uint32, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyDataFormatEx.restype = c_int16

_lib.ul_modifyDataFormatNotSaveEx.argtypes = [c_uint32, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyDataFormatNotSaveEx.restype = c_int16

_lib.ul_getDataFormatEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getDataFormatEx.restype = c_int16

# 修改输出数据格式
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x00
# - dataBlockId: 0xD500
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 输出数据格式 (e_Upload_DataFormat)
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyDataFormat = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyDataFormatEx, rf_id, dot_id, fmt)

# 修改输出数据格式（不保存到配置文件）
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x00
# - dataBlockId: 0xD500
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 输出数据格式 (e_Upload_DataFormat)
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyDataFormatNotSave = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyDataFormatNotSaveEx, rf_id, dot_id, fmt)

# 获取输出数据格式
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x01
# - dataBlockId: 0xD501
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getDataFormat = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getDataFormatEx, rf_id, dot_id)

# -------------------------------------------------------------
# 2. 采样频率
# -------------------------------------------------------------
_lib.ul_modifySampleHzEx.argtypes = [c_uint16, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifySampleHzEx.restype = c_int16

_lib.ul_getSampleHzEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getSampleHzEx.restype = c_int16

# 修改采样频率
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x02
# - dataBlockId: 0xD502
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 采样频率 (单位 Hz)
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifySampleHz = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifySampleHzEx, rf_id, dot_id, fmt)

# 获取采样频率
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x03
# - dataBlockId: 0xD503
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getSampleHz = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getSampleHzEx, rf_id, dot_id)

# -------------------------------------------------------------
# 3. 上传频率
# -------------------------------------------------------------
_lib.ul_modifyUploadHzEx.argtypes = [c_uint16, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyUploadHzEx.restype = c_int16

_lib.ul_getUploadHzEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getUploadHzEx.restype = c_int16

# 修改上传频率
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x04
# - dataBlockId: 0xD504
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 上传频率 (单位 Hz)
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyUploadHz = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyUploadHzEx, rf_id, dot_id, fmt)

# 获取上传频率
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x05
# - dataBlockId: 0xD505
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getUploadHz = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getUploadHzEx, rf_id, dot_id)

# -------------------------------------------------------------
# 4. 磁力计校准
# -------------------------------------------------------------
_lib.ul_startMagnetometerCalibrationEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_startMagnetometerCalibrationEx.restype = c_int16

# 开始磁力计校准
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x06
# - dataBlockId: 0xD506
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_startMagnetometerCalibration = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_startMagnetometerCalibrationEx, rf_id, dot_id)

# -------------------------------------------------------------
# 5. 滤波配置
# -------------------------------------------------------------
_lib.ul_configDataFilterEx.argtypes = [c_uint16, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_configDataFilterEx.restype = c_int16

_lib.ul_clearDataFilterEx.argtypes = [c_uint16, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_clearDataFilterEx.restype = c_int16

_lib.ul_getDataFilterEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getDataFilterEx.restype = c_int16

# 配置滤波参数
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x08
# - dataBlockId: 0xD508
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 滤波参数
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_configDataFilter = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_configDataFilterEx, rf_id, dot_id, fmt)

# 清除滤波参数
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x0A
# - dataBlockId: 0xD50A
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 滤波参数
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_clearDataFilter = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_clearDataFilterEx, rf_id, dot_id, fmt)

# 获取滤波参数
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x0B
# - dataBlockId: 0xD50B
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getDataFilter = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getDataFilterEx, rf_id, dot_id)

# -------------------------------------------------------------
# 6. IC 安装方向
# -------------------------------------------------------------
_lib.ul_modifyIcConventionEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyIcConventionEx.restype = c_int16

_lib.ul_getIcConventionEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getIcConventionEx.restype = c_int16

# 修改IC安装方向
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x0C
# - dataBlockId: 0xD50C
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: IC安装方向参数
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyIcConvention = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyIcConventionEx, rf_id, dot_id, fmt)

# 获取IC安装方向
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x0D
# - dataBlockId: 0xD50D
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getIcConvention = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getIcConventionEx, rf_id, dot_id)

# -------------------------------------------------------------
# 7. RF 广播名称
# -------------------------------------------------------------
_lib.ul_modifyIcAdvNameEx.argtypes = [c_char_p, c_char_p, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyIcAdvNameEx.restype = c_int16

_lib.ul_getIcAdvNameEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getIcAdvNameEx.restype = c_int16

# 修改RF广播名称
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x0E
# - dataBlockId: 0xD50E
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: RF广播名称
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyIcAdvName = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyIcAdvNameEx, rf_id, dot_id, fmt)

# 获取RF广播名称
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x0F
# - dataBlockId: 0xD50F
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getIcAdvName = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getIcAdvNameEx, rf_id, dot_id)

# -------------------------------------------------------------
# 8. RF 功率
# -------------------------------------------------------------
_lib.ul_modifyIcRfPowerEx.argtypes = [c_int8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyIcRfPowerEx.restype = c_int16

_lib.ul_getIcRfPowerEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getIcRfPowerEx.restype = c_int16

# 修改RF功率
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x10
# - dataBlockId: 0xD510
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rssi: RF功率值
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyIcRfPower = \
    lambda rssi, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyIcRfPowerEx, rf_id, dot_id, rssi)

# 获取RF功率
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x11
# - dataBlockId: 0xD511
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getIcRfPower = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getIcRfPowerEx, rf_id, dot_id)

# -------------------------------------------------------------
# 9. 断开 RF / 数据输出使能 / Yaw 归零 / ADC 归 1000 化校准
# -------------------------------------------------------------
_lib.ul_disconnectIcRfEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_disconnectIcRfEx.restype = c_int16

_lib.ul_enableDataOutPutEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_enableDataOutPutEx.restype = c_int16

_lib.ul_disableDataOutPutEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_disableDataOutPutEx.restype = c_int16

_lib.ul_resetYaw2zeroEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_resetYaw2zeroEx.restype = c_int16

_lib.ul_enableAdcCalibrationEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_enableAdcCalibrationEx.restype = c_int16

_lib.ul_disableAdcCalibrationEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_disableAdcCalibrationEx.restype = c_int16

_lib.ul_disableAdcCalibrationEx2.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_disableAdcCalibrationEx2.restype = c_int16

_lib.ul_setFingerOrderEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_setFingerOrderEx.restype = c_int16

_lib.ul_getFingerOrderEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getFingerOrderEx.restype = c_int16

_lib.ul_configAdcCalibrationModeEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_configAdcCalibrationModeEx.restype = c_int16

_lib.ul_configAdcNormalizationModeEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_configAdcNormalizationModeEx.restype = c_int16


# 断开RF连接
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x12
# - dataBlockId: 0xD512
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_disconnectIcRf          = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_disconnectIcRfEx, rf_id, dot_id)

# 使能数据输出
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x14
# - dataBlockId: 0xD514
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_enableDataOutPut        = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_enableDataOutPutEx, rf_id, dot_id)

# 禁用数据输出
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x15
# - dataBlockId: 0xD515
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_disEnableDataOutPut     = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_disableDataOutPutEx, rf_id, dot_id)

# Yaw归零
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x16
# - dataBlockId: 0xD516
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_resetYaw2zero           = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_resetYaw2zeroEx, rf_id, dot_id)

# 启动ADC归1000化校准
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x30
# - dataBlockId: 0xD530
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_enableAdcCalibration   = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_enableAdcCalibrationEx, rf_id, dot_id)

# 退出ADC归1000化校准
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x31
# - dataBlockId: 0xD531
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   isRead: 读取参数
#         - 0x00   退出校准
#         - 0x01   退出校准,并读取校准结果
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_disableAdcCalibration  = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_disableAdcCalibrationEx, rf_id, dot_id)

ul_disableAdcCalibrationRead  = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_disableAdcCalibrationEx2, rf_id, dot_id, 0x01)

# 设置手指顺序（正序 or 反序） 
#   order: 手指顺序参数
#         - 0x00   右手
#         - 0x01   左手
#   ADC 顺序 (1: 【5 4 3 2 1 6】, 0: 【1 2 3 4 5 6】)
ul_setFingerOrder = \
    lambda order, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_setFingerOrderEx, rf_id, dot_id, order)

# 读取手指顺序（正序 or 反序）
ul_getFingerOrder = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getFingerOrderEx, rf_id, dot_id)  

# 配置ADC校准模式
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x34
# - dataBlockId: 0xD534
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
#      校准流程如下：
#      1、手做好张开状态  -----> 下发张开模式
#         维持3S后，    -----> 下发空闲模式
#      2、手做好手刀状态  -----> 下发手刀模式
#         维持3S后，    -----> 下发空闲模式
#      3、手做好握拳状态  -----> 下发握拳模式
#         维持3S后，    -----> 下发正常模式
#
# 参数:
#   mode: ADC校准模式参数
#         - 0x10   空闲模式
#         - 0x11   张开模式
#         - 0x12   手刀模式
#         - 0x13   握拳模式
#         - 0x01   校准模式	
#         - 0x00   正常模式	
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_configAdcCalibrationMode = \
    lambda mode, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_configAdcCalibrationModeEx, rf_id, dot_id, mode)


# 开启与关闭 ADC 归1000化校准模式
ul_configAdcNormalizationMode = \
    lambda mode, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_configAdcNormalizationModeEx, rf_id, dot_id, mode)

# -------------------------------------------------------------
# 通用工具：申请默认帧缓存
# -------------------------------------------------------------

# ---------- 1. LED 交互 ----------
_lib.ul_enterLedInteractionEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_enterLedInteractionEx.restype = c_int16

_lib.ul_exitLedInteractionEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_exitLedInteractionEx.restype = c_int16

_lib.ul_modifyLedInteractionColorEx.argtypes = [c_uint8, c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyLedInteractionColorEx.restype = c_int16

_lib.ul_getLedInteractionColorEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getLedInteractionColorEx.restype = c_int16

# 进入LED交互模式
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x60
# - dataBlockId: 0xD560
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_enterLedInteraction = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_enterLedInteractionEx, rf_id, dot_id)

# 退出LED交互模式
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x61
# - dataBlockId: 0xD561
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_exitLedInteraction = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_exitLedInteractionEx, rf_id, dot_id)

# 修改LED交互颜色
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x62
# - dataBlockId: 0xD562
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   color: LED颜色
#   mode: LED模式
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyLedInteractionColor = \
    lambda color, mode, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyLedInteractionColorEx, rf_id, dot_id, color, mode)

# 获取LED交互颜色
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x63
# - dataBlockId: 0xD563
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getLedInteractionColor = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getLedInteractionColorEx, rf_id, dot_id)

# ---------- 2. 串口波特率 ----------
_lib.ul_modifyUartBaudRateEx.argtypes = [c_uint32, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyUartBaudRateEx.restype = c_int16

_lib.ul_getUartBaudRateEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getUartBaudRateEx.restype = c_int16

# 修改串口波特率
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x64
# - dataBlockId: 0xD564
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   baud: 波特率值
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyUartBaudRate = \
    lambda baud, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyUartBaudRateEx, rf_id, dot_id, baud)

# 获取串口波特率
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x65
# - dataBlockId: 0xD565
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getUartBaudRate = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getUartBaudRateEx, rf_id, dot_id)

# ---------- 3. BlockSize ----------
_lib.ul_modifyBlockSizeEx.argtypes = [c_uint8, c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_modifyBlockSizeEx.restype = c_int16

_lib.ul_getBlockSizeEx.argtypes = [c_uint8, c_int8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]  # C 原型为 int8_t
_lib.ul_getBlockSizeEx.restype = c_int16

# 修改BlockSize
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x66
# - dataBlockId: 0xD566
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   type_: Block类型
#   size: Block大小
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_modifyBlockSize = \
    lambda type_, size, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_modifyBlockSizeEx, rf_id, dot_id, type_, size)

# 获取BlockSize
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x67
# - dataBlockId: 0xD567
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   type_: Block类型
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getBlockSize = \
    lambda type_, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getBlockSizeEx, rf_id, dot_id, type_)

# ---------- 4. IMU 六面静态校准 ----------
_lib.ul_imuStaticCalibrationEnterEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_imuStaticCalibrationEnterEx.restype = c_int16

_lib.ul_imuStaticCalibrationEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_imuStaticCalibrationEx.restype = c_int16

_lib.ul_imuStaticCalibrationExitEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_imuStaticCalibrationExitEx.restype = c_int16

_lib.ul_clearStaticCalibrationParamEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_clearStaticCalibrationParamEx.restype = c_int16

# IMU六面静态校准初始化
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x6E
# - dataBlockId: 0xD56E
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_imuStaticCalibrationInit = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_imuStaticCalibrationEnterEx, rf_id, dot_id)

# IMU六面静态校准
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x6E
# - dataBlockId: 0xD56E
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_imuStaticCalibration = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_imuStaticCalibrationEx, rf_id, dot_id)

# IMU六面静态校准退出
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x6E
# - dataBlockId: 0xD56E
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_imuStaticCalibrationExit = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_imuStaticCalibrationExitEx, rf_id, dot_id)

# 清除静态校准参数
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x6F
# - dataBlockId: 0xD56F
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_clearStaticCalibrationParam = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_clearStaticCalibrationParamEx, rf_id, dot_id)

# ---------- 5. 设备信息 & 控制 ----------
_lib.ul_getMacAddressStrEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getMacAddressStrEx.restype = c_int16

_lib.ul_getDeviceSnStrEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getDeviceSnStrEx.restype = c_int16

_lib.ul_getBoardVesionStrEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getBoardVesionStrEx.restype = c_int16

_lib.ul_getFirmwareVesionStrEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_getFirmwareVesionStrEx.restype = c_int16

_lib.ul_deviceShutdownEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_deviceShutdownEx.restype = c_int16

_lib.ul_restoreFactorySettingsEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.ul_restoreFactorySettingsEx.restype = c_int16

# 获取MAC地址
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x77
# - dataBlockId: 0xD577
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getMacAddressStr        = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getMacAddressStrEx, rf_id, dot_id)

# 获取设备序列号
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x79
# - dataBlockId: 0xD579
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getDeviceSnStr          = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getDeviceSnStrEx, rf_id, dot_id)

# 获取板卡版本
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x7B
# - dataBlockId: 0xD57B
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getBoardVesionStr       = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getBoardVesionStrEx, rf_id, dot_id)

# 获取固件版本
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x7D
# - dataBlockId: 0xD57D
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_getFirmwareVesionStr    = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_getFirmwareVesionStrEx, rf_id, dot_id)

# 设备关机
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x7E
# - dataBlockId: 0xD57E
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_deviceShutdown          = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_deviceShutdownEx, rf_id, dot_id)

# 恢复出厂设置
# - 指令Id（cmdId）: 0xD5
# - 子指令Id（subCmdId）: 0x7F
# - dataBlockId: 0xD57F
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
ul_restoreFactorySettings  = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.ul_restoreFactorySettingsEx, rf_id, dot_id)

#------------------------------------------------------------------------------------------------
# UHL 高级指令
#------------------------------------------------------------------------------------------------
# -------------------------------------------------------------
# 高级设置：hl_ 系列接口
# -------------------------------------------------------------
_lib.hl_modifyDataFormatEx.argtypes = [c_uint32, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_modifyDataFormatEx.restype = c_int16

_lib.hl_modifyDataFormatNotSaveEx.argtypes = [c_uint32, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_modifyDataFormatNotSaveEx.restype = c_int16

_lib.hl_getDataFormatEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getDataFormatEx.restype = c_int16

_lib.hl_modifyDotIdEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_modifyDotIdEx.restype = c_int16

_lib.hl_getDotIdEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getDotIdEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级修改输出数据格式
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x00
# - dataBlockId: 0xD600
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 输出数据格式 (e_Upload_DataFormat)
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_modifyDataFormat = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_modifyDataFormatEx, rf_id, dot_id, fmt)

# 高级修改输出数据格式（不保存到配置文件）
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x00
# - dataBlockId: 0xD600
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 输出数据格式 (e_Upload_DataFormat)
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_modifyDataFormatNotSave = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_modifyDataFormatNotSaveEx, rf_id, dot_id, fmt)

# 高级获取输出数据格式
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x01
# - dataBlockId: 0xD601
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getDataFormat = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getDataFormatEx, rf_id, dot_id)

# 高级修改DotId
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x02
# - dataBlockId: 0xD602
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   dot_id_cfg: Dot ID配置
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_modifyDotId = \
    lambda dot_id_cfg, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_modifyDotIdEx, rf_id, dot_id, dot_id_cfg)

# 高级获取DotId
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x03
# - dataBlockId: 0xD603
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getDotId = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getDotIdEx, rf_id, dot_id)

# -------------------------------------------------------------
# 高级设置：RF 连接间隔 / ACC 量程 / Gyro 量程
# -------------------------------------------------------------
# ---------- 1. Rf ConnInterval ----------
_lib.hl_modifyRfConnIntervalEx.argtypes = [c_float, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_modifyRfConnIntervalEx.restype = c_int16

_lib.hl_getRfConnIntervalEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getRfConnIntervalEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级修改RF连接间隔
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x06
# - dataBlockId: 0xD606
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   interval: RF连接间隔
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_modifyRfConnInterval = \
    lambda interval, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_modifyRfConnIntervalEx, rf_id, dot_id, interval)

# 高级获取RF连接间隔
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x07
# - dataBlockId: 0xD607
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getRfConnInterval = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getRfConnIntervalEx, rf_id, dot_id)

# ---------- 2. ACC Range ----------
_lib.hl_modifyAccRangeEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_modifyAccRangeEx.restype = c_int16

_lib.hl_getAccRangeEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getAccRangeEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级修改ACC量程
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x10
# - dataBlockId: 0xD610
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   acc_range: ACC量程
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_modifyAccRange = \
    lambda acc_range, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_modifyAccRangeEx, rf_id, dot_id, acc_range)

# 高级获取ACC量程
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x11
# - dataBlockId: 0xD611
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getAccRange = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getAccRangeEx, rf_id, dot_id)

# ---------- 3. Gyro Range ----------
_lib.hl_modifyGyroRangeEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_modifyGyroRangeEx.restype = c_int16

_lib.hl_getGyroRangeEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getGyroRangeEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级修改Gyro量程
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x12
# - dataBlockId: 0xD612
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   gyro_range: Gyro量程
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_modifyGyroRange = \
    lambda gyro_range, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_modifyGyroRangeEx, rf_id, dot_id, gyro_range)

# 高级获取Gyro量程
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x13
# - dataBlockId: 0xD613
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getGyroRange = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getGyroRangeEx, rf_id, dot_id)

# -------------------------------------------------------------
# 高级设置：剩余全部接口一次性封装
# -------------------------------------------------------------
# 1. 磁力计椭球拟合校准
_lib.hl_modifyMagEllipsoidCalParamEx.argtypes = [POINTER(magEllipsoidCalParamBlock_t),c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_modifyMagEllipsoidCalParamEx.restype = c_int16

_lib.hl_getMagEllipsoidCalParamEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getMagEllipsoidCalParamEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级修改磁力计椭球拟合校准参数
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x1A
# - dataBlockId: 0xD61A
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   cal: 磁力计椭球拟合校准参数
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_modifyMagEllCalParam_Ex = \
    lambda cal, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_modifyMagEllipsoidCalParamEx, rf_id, dot_id, cal)

# 高级获取磁力计椭球拟合校准参数
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x1B
# - dataBlockId: 0xD61B
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getMagEllCalParam_Ex = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getMagEllipsoidCalParamEx, rf_id, dot_id)

# 2. 清除/配置/读取 VQF Gyro Bias
_lib.hl_clearGyroBiasEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_clearGyroBiasEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级清除Gyro Bias
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x1C
# - dataBlockId: 0xD61C
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_clearGyroBias = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_clearGyroBiasEx, rf_id, dot_id)

# 3. 流水号格式 / 重置流水号
_lib.hl_configFlowFormatEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_configFlowFormatEx.restype = c_int16

_lib.hl_getFlowFormatEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getFlowFormatEx.restype = c_int16

_lib.hl_resetFlowNumsEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_resetFlowNumsEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级配置流水号格式
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x20
# - dataBlockId: 0xD620
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   fmt: 流水号格式
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_configFlowFormat = \
    lambda fmt, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_configFlowFormatEx, rf_id, dot_id, fmt)

# 高级获取流水号格式
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x21
# - dataBlockId: 0xD621
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getFlowFormat = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getFlowFormatEx, rf_id, dot_id)

# 高级重置流水号
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x22
# - dataBlockId: 0xD622
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_resetFlowNums = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_resetFlowNumsEx, rf_id, dot_id)

# 4. 姿态纠正
_lib.hl_disableAhrsOffsetCalEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_disableAhrsOffsetCalEx.restype = c_int16

_lib.hl_setAhrsOffsetParamEx.argtypes = [POINTER(AhrsQuaternion), c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_setAhrsOffsetParamEx.restype = c_int16

_lib.hl_getAhrsOffsetParamEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getAhrsOffsetParamEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级禁用姿态偏移校准
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x28
# - dataBlockId: 0xD628
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_disableAhrsOffsetCal = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_disableAhrsOffsetCalEx, rf_id, dot_id)

# 高级设置姿态偏移参数
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x2A
# - dataBlockId: 0xD62A
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   quat: 四元数参数
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_setAhrsOffsetParam = \
    lambda quat, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_setAhrsOffsetParamEx, rf_id, dot_id, quat)

# 高级获取姿态偏移参数
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x2B
# - dataBlockId: 0xD62B
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getAhrsOffsetParam = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getAhrsOffsetParamEx, rf_id, dot_id)

# 5. 数据输出端口
_lib.hl_configOutDataPortEx.argtypes = [c_uint16, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_configOutDataPortEx.restype = c_int16

_lib.hl_getOutDataPortEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getOutDataPortEx.restype = c_int16

_lib.hl_checkOutDataPortEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_checkOutDataPortEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级配置数据输出端口
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x30
# - dataBlockId: 0xD630
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   port: 数据输出端口
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_configOutDataPort = \
    lambda port, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_configOutDataPortEx, rf_id, dot_id, port)

# 高级获取数据输出端口
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x31
# - dataBlockId: 0xD631
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getOutDataPort = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getOutDataPortEx, rf_id, dot_id)

# 高级检查数据输出端口
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x33
# - dataBlockId: 0xD633
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_checkOutDataPort = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_checkOutDataPortEx, rf_id, dot_id)

# ---------- 6. 机器状态码 ----------
_lib.hl_getMachineStatusEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getMachineStatusEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级获取机器状态码
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x35
# - dataBlockId: 0xD635
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getMachineStatus = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getMachineStatusEx, rf_id, dot_id)

# ---------- 7. 手指 ADC 滤波参数 ----------
_lib.hl_configFingerFilterParamEx.argtypes = [POINTER(adcFilterParam_t), c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_configFingerFilterParamEx.restype = c_int16

_lib.hl_getFilterParamEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getFilterParamEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级配置手指ADC滤波参数
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x40
# - dataBlockId: 0xD640
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   param: 滤波参数
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_configFingerFilterParam = \
    lambda param, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_configFingerFilterParamEx, rf_id, dot_id, byref(param))

# 高级获取滤波参数
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x41
# - dataBlockId: 0xD641
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getFilterParam = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getFilterParamEx, rf_id, dot_id)

# ---------- 8. 手指 Map ----------
_lib.hl_setFingerMapEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_setFingerMapEx.restype = c_int16

_lib.hl_getFingerMapEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_getFingerMapEx.restype = c_int16

# ---------- 对外函数 ----------
# 高级设置手指Map
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x42
# - dataBlockId: 0xD642
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   map_: 手指Map值
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_setFingerMap = \
    lambda map_, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_setFingerMapEx, rf_id, dot_id, map_)

# 高级获取手指Map
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x43
# - dataBlockId: 0xD643
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_getFingerMap = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_getFingerMapEx, rf_id, dot_id)

# ---------- 9. 通用开关封装 ----------
_lib.hl_swapUserUartTrxPinEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_swapUserUartTrxPinEx.restype = c_int16

# 高级切换用户UART引脚
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x60
# - dataBlockId: 0xD660
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_swapUserUartTrxPin = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_swapUserUartTrxPinEx, rf_id, dot_id)

_lib.hl_enableUserSpimEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_enableUserSpimEx.restype = c_int16

# 高级使能用户SPIM
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x64
# - dataBlockId: 0xD664
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_enableUserSpim = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_enableUserSpimEx, rf_id, dot_id)

_lib.hl_disableUserSpimEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_disableUserSpimEx.restype = c_int16

# 高级禁用用户SPIM
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x64
# - dataBlockId: 0xD664
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_disableUserSpim = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_disableUserSpimEx, rf_id, dot_id)

_lib.hl_enableUserSpisEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_enableUserSpisEx.restype = c_int16

# 高级使能用户SPIS
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x66
# - dataBlockId: 0xD666
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_enableUserSpis = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_enableUserSpisEx, rf_id, dot_id)

_lib.hl_disableUserSpisEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_disableUserSpisEx.restype = c_int16

# 高级禁用用户SPIS
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x66
# - dataBlockId: 0xD666
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_disableUserSpis = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_disableUserSpisEx, rf_id, dot_id)

_lib.hl_configUserAdcEx.argtypes = [c_uint8, c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_configUserAdcEx.restype = c_int16

# 高级配置用户ADC
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x6A
# - dataBlockId: 0xD66A
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   mask: ADC配置掩码
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_configUserAdc = \
    lambda mask, rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_configUserAdcEx, rf_id, dot_id, mask)

_lib.hl_enableUserBatteryEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_enableUserBatteryEx.restype = c_int16

# 高级使能用户电池
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x6C
# - dataBlockId: 0xD66C
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_enableUserBattery = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_enableUserBatteryEx, rf_id, dot_id)

_lib.hl_disableUserBatteryEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_disableUserBatteryEx.restype = c_int16

# 高级禁用用户电池
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x6C
# - dataBlockId: 0xD66C
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_disableUserBattery = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_disableUserBatteryEx, rf_id, dot_id)

_lib.hl_enableUserRgbLedEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_enableUserRgbLedEx.restype = c_int16

# 高级使能用户RGB LED
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x70
# - dataBlockId: 0xD670
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_enableUserRgbLed = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_enableUserRgbLedEx, rf_id, dot_id)

_lib.hl_disableUserRgbLedEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_disableUserRgbLedEx.restype = c_int16

# 高级禁用用户RGB LED
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x70
# - dataBlockId: 0xD670
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_disableUserRgbLed = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_disableUserRgbLedEx, rf_id, dot_id)

_lib.hl_enableUserBtnEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_enableUserBtnEx.restype = c_int16

# 高级使能用户按钮
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x72
# - dataBlockId: 0xD672
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_enableUserBtn = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_enableUserBtnEx, rf_id, dot_id)

_lib.hl_disableUserBtnEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_disableUserBtnEx.restype = c_int16

# 高级禁用用户按钮
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x72
# - dataBlockId: 0xD672
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_disableUserBtn = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_disableUserBtnEx, rf_id, dot_id)

_lib.hl_enableUserPowerEnEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_enableUserPowerEnEx.restype = c_int16

# 高级使能用户电源
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x74
# - dataBlockId: 0xD674
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_enableUserPowerEn = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_enableUserPowerEnEx, rf_id, dot_id)

_lib.hl_disableUserPowerEnEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_disableUserPowerEnEx.restype = c_int16

# 高级禁用用户电源
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x74
# - dataBlockId: 0xD674
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_disableUserPowerEn = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_disableUserPowerEnEx, rf_id, dot_id)

_lib.hl_enableUserRfEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_enableUserRfEx.restype = c_int16

# 高级使能用户RF
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x76
# - dataBlockId: 0xD676
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_enableUserRf = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_enableUserRfEx, rf_id, dot_id)

_lib.hl_enableUserRfPaEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_enableUserRfPaEx.restype = c_int16

# 高级使能用户RF PA
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x78
# - dataBlockId: 0xD678
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_enableUserRfPa = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_enableUserRfPaEx, rf_id, dot_id)

_lib.hl_disableUserRfPaEx.argtypes = [c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.hl_disableUserRfPaEx.restype = c_int16

# 高级禁用用户RF PA
# - 指令Id（cmdId）: 0xD6
# - 子指令Id（subCmdId）: 0x78
# - dataBlockId: 0xD678
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: 上传数据的RF ID（可选，默认0x3F）
#   dot_id: 上传数据的Dot ID（可选，默认0xFF）
# 返回值: bytes：指令帧数据
hl_disableUserRfPa = \
    lambda rf_id = DEFAULT_RFID, dot_id = DEFAULT_DOTID: _call_cmd(_M_ID, _lib.hl_disableUserRfPaEx, rf_id, dot_id)

#------------------------------------------------------------------------------------------------
# FHL 高级指令
#------------------------------------------------------------------------------------------------

#------------------------------------------------------------------------------------------------
# OTA 升级接口
#------------------------------------------------------------------------------------------------

#------------------------------------------------------------------------------------------------
# Dongle 系列接口 UDG_LEVEL_EN
#------------------------------------------------------------------------------------------------
_lib.dl_getDeviceFullSnIdEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_getDeviceFullSnIdEx.restype = c_int16

# Dongle获取完整设备序列号
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x01
# - dataBlockId: 0xC001
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_getDeviceFullSnId = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_getDeviceFullSnIdEx, rf_id, None)

# 4. DeviceList（结构体数组）
_lib.dl_modifyDeviceListEx2.argtypes = [POINTER(deviceBlockList_t), c_uint8, c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_modifyDeviceListEx2.restype = c_int16

# Dongle修改设备列表
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x10
# - dataBlockId: 0xC010
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   blocks: 设备块列表
#   nums: 设备数量
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_modifyDeviceList = \
    lambda blocks, nums, rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID_MAX, _lib.dl_modifyDeviceListEx2, rf_id, None, cast(blocks, POINTER(deviceBlockList_t)), nums)

_lib.dl_getBoardVesionStrEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_getBoardVesionStrEx.restype = c_int16

# Dongle获取板卡版本
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x07
# - dataBlockId: 0xC007
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_getBoardVesionStr = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_getBoardVesionStrEx, rf_id, None)

_lib.dl_getFirmwareVesionStrEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_getFirmwareVesionStrEx.restype = c_int16

# Dongle获取固件版本
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x08
# - dataBlockId: 0xC008
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_getFirmwareVesionStr = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_getFirmwareVesionStrEx, rf_id, None)

_lib.dl_getDeviceListEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_getDeviceListEx.restype = c_int16

# Dongle获取设备列表
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x11
# - dataBlockId: 0xC011
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_getDeviceList = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_getDeviceListEx, rf_id, None)

_lib.dl_clearDeviceListEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_clearDeviceListEx.restype = c_int16

# Dongle清除设备列表
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x112
# - dataBlockId: 0xC0112
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_clearDeviceList = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_clearDeviceListEx, rf_id, None)

_lib.dl_getDeviceConnListEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_getDeviceConnListEx.restype = c_int16

# Dongle获取设备连接列表
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x13
# - dataBlockId: 0xC013
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_getDeviceConnList = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_getDeviceConnListEx, rf_id, None)

_lib.dl_keepDeviceConnListEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_keepDeviceConnListEx.restype = c_int16

# Dongle保持设备连接列表
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x14
# - dataBlockId: 0xC014
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_keepDeviceConnList = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_keepDeviceConnListEx, rf_id, None)

_lib.dl_enableScanEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_enableScanEx.restype = c_int16

# Dongle使能扫描
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x15
# - dataBlockId: 0xC015
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_enableScan = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_enableScanEx, rf_id, None)

_lib.dl_disEnableScanEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_disEnableScanEx.restype = c_int16

# Dongle禁用扫描
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x16
# - dataBlockId: 0xC016
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_disEnableScan = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_disEnableScanEx, rf_id, None)

_lib.dl_disConnectAllEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_disConnectAllEx.restype = c_int16

# Dongle断开所有连接设备
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x17
# - dataBlockId: 0xC017
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_disConnectAll = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_disConnectAllEx, rf_id, None)

_lib.dl_configIdentifyWayEx.argtypes = [c_bool, c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_configIdentifyWayEx.restype = c_int16

# Dongle配置识别方式
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x20
# - dataBlockId: 0xC020
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   isMac: 是否使用MAC地址识别
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_configIdentifyWay = \
    lambda isMac, rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_configIdentifyWayEx, rf_id, None, c_bool(isMac))

_lib.dl_getIdentifyWayEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_getIdentifyWayEx.restype = c_int16

# Dongle获取识别方式
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x21
# - dataBlockId: 0xC021
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_getIdentifyWay = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_getIdentifyWayEx, rf_id, None)

_lib.dl_outputToXXXEx.argtypes = [c_bool, c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_outputToXXXEx.restype = c_int16

# Dongle配置数据输出目标
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x70
# - dataBlockId: 0xC070
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   isUsb: 是否输出到USB
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_outputToXXX = \
    lambda isUsb, rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_outputToXXXEx, rf_id, None, c_bool(isUsb))

_lib.dl_restoreFactorySettingsEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_restoreFactorySettingsEx.restype = c_int16

# Dongle恢复出厂设置
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x7D
# - dataBlockId: 0xC07D
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_restoreFactorySettings = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_restoreFactorySettingsEx, rf_id, None)

_lib.dl_deviceShutdownEx.argtypes = [c_uint8, POINTER(c_uint8), c_uint16]
_lib.dl_deviceShutdownEx.restype = c_int16

# Dongle设备关机
# - 指令Id（cmdId）: 0xC0
# - 子指令Id（subCmdId）: 0x7F
# - dataBlockId: 0xC07F
# Note：执行该函数后，只是得到指令帧序列，该指令帧序列还需通过串口（蓝牙等端口）发送到传感器
# 参数:
#   rf_id: Dongle ID（可选，默认0xE0）
# 返回值: bytes：指令帧数据
dl_deviceShutdown = \
    lambda rf_id = DEFAULT_DONGLEID: _call_cmd(_S_ID, _lib.dl_deviceShutdownEx, rf_id, None)

#------------------------------------------------------------------------------------------------
# Dongle 系列接口 FDG_LEVEL_EN
#------------------------------------------------------------------------------------------------

#------------------------------------------------------------------------------------------------------------
