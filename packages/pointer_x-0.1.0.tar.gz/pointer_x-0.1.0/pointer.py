from enum import Enum, auto
from typing import List
import builtins

_vram = bytearray(1 * 1024 ** 2)

class MainTypes(Enum):
    short = 2
    int = 4
    long = 8
    long_long = 16
    char = 1
    bool = 1
    void = 1

class ModifiedTypes(Enum):
    unsigned = auto()

mat = MainTypes
mot = ModifiedTypes

class _NullptrType:
    def __str__(self):
        return 'nullptr'

nullptr = _NullptrType()

def _deser(cls: "Type", byt):
    if cls.mat in {mat.short, mat.int, mat.long, mat.long_long}:
        res = int.from_bytes(byt, signed=cls.mot != mot.unsigned)
    elif cls.mat == mat.char:
        res = byt.decode('utf-8')
    elif cls.mat == mat.bool:
        res = bool(int.from_bytes(byt))
    return res

class PtrType:
    used = set()
    refers: List["PtrType"] = []
    def __init__(self, type: "Type", default=nullptr, _length=1):
        global _vram
        self.type = type
        self.using_space = type.mat.value
        self.ptr = default
        self._length = _length
        if self.ptr is not nullptr:
            if 0 <= self.ptr <= len(_vram):
                self.ptr = nullptr
            self._update_ptr(default)
        self.refers.append(self)
    @property
    def _usable_ptr(self):
        global _vram
        for ptr in range(0, len(_vram), self.using_space):
            if all(ptr + offset not in self.used for offset in range(self.using_space)):
                return ptr
        else:
            return nullptr
    def _update_ptr(self, ptr):
        if self.ptr is nullptr:
            self.ptr = ptr
            if ptr is not nullptr:
                for boffset in range(self._length):
                    for offset in range(self.using_space):
                        self.used.add(ptr + boffset * self.using_space + offset)
    @property
    def value(self):
        global _vram
        if self.ptr is nullptr:
            return None
        else:
            if self.type != mat.void:
                space = _vram[self.ptr:self.ptr + self.using_space]
                return _deser(self.type, space)
            else:
                return None
    @value.setter
    def value(self, value):
        global _vram
        if self.ptr is nullptr:
            pass
        else:
            if self.type != mat.void:
                buf = _ser(self.type, value)
                for byt, offset in zip(buf, range(self.using_space)):
                    _vram[self.ptr + offset] = byt
    @property
    def used_space(self):
        return self.using_space * self._length
    def __iter__(self):
        return iter((self.value,))
    def __rmul__(self, other):
        return self.value
    def __str__(self):
        return f'<{'' if not self.type.mot else self.type.mot.name + ' '}{self.type.mat.name} pointer = {self.ptr}>'
    def __add__(self, offset):
        global _vram
        if self.ptr is nullptr:
            return PtrType(self.type)
        else:
            return PtrType(
                self.type, min(self.ptr + offset, len(_vram)),
                _length=max(self._length - offset // self.using_space, 1)
            )
    def __sub__(self, offset):
        if self.ptr is nullptr:
            return PtrType(self.type)
        else:
            return PtrType(
                self.type, max(self.ptr - offset, 0),
                _length=self._length + offset // self.using_space
            )
    def __getitem__(self, type: "Type"):
        new = self.__add__(0)
        new._length = 1
        new.type = type
        return new
    def __int__(self):
        return self.ptr
    def last(self):
        return self.__sub__(self.using_space)
    def next(self):
        return self.__add__(self.using_space)
    def free(self):
        if self.ptr is not nullptr:
            for boffset in range(self._length):
                for offset in range(self.using_space):
                    try:
                        self.used.remove(self.ptr + boffset * self.using_space + offset)
                    except KeyError:
                        pass
            
            del_ptr_start = self.ptr
            del_ptr_end = del_ptr_start + self.using_space * self._length
            for ptr in self.refers:
                if self.type.mat == ptr.type.mat and ptr.ptr is not nullptr:
                    ptr_start = ptr.ptr
                    ptr_end = ptr_start + ptr.using_space * ptr._length

                    if ptr_start > del_ptr_end or ptr_end < del_ptr_start:
                        continue
                    elif ptr_start == del_ptr_start:
                        if ptr_end <= del_ptr_end:
                            ptr.ptr = nullptr
                            ptr._length = 0
                        else:
                            ptr.ptr += self.used_space
                            ptr._length -= self.used_space // ptr.using_space
                    elif ptr_end == ptr_end:
                        if ptr_start >= del_ptr_start:
                            ptr.ptr = nullptr
                            ptr._length = 0
                        else:
                            ptr.ptr -= self.used_space
                            ptr._length += self.used_space // ptr.using_space
                    else:
                        continue
            
            self.ptr = nullptr
            self._length = 0

    @classmethod
    def malloc(cls, type: "Type", length: int):
        global _vram
        if length * type.mat.value + len(cls.used) >= len(_vram):
            raise OverflowError('No memory is available at the time of allocation')
        using_space = type.mat.value
        for ptr in range(0, len(_vram), using_space):
            if all(
                ptr + boffset * using_space + offset not in cls.used
                for boffset in range(length)
                for offset in range(using_space)
            ):
                p = ptr
                break
        else:
            raise OverflowError('No correct memory is available at the time of allocation')
        return cls(type, p, length)
    def copy(self):
        return self.__add__(0)

class TypeMismatchError(Exception):
    def __init__(self, type: "Type", value: any):
        self.type = type
        self.value = value
    def __str__(self):
        return f'Unable to apply {self.value}(type {type(self.value)}) to a pointer of type [{'' if not self.type.mot else self.type.mot.name + ' '}{self.type.mat.name}]'

def _ser(cls: "Type", value):
    if cls.mat in {mat.short, mat.int, mat.long, mat.long_long}:
        if isinstance(value, int) and not isinstance(value, bool):
            byt = value.to_bytes(cls.mat.value, signed=cls.mot != mot.unsigned)
        else:
            raise TypeMismatchError(cls, value)
    elif cls.mat == mat.char:
        if isinstance(value, str) and len(value) == 1 and len(value.encode('utf-8')) == 1:
            byt = value.encode('utf-8')
        else:
            raise TypeMismatchError(cls, value)
    elif cls.mat == mat.bool:
        if isinstance(value, bool):
            byt = value.to_bytes(1)
        else:
            raise TypeMismatchError(cls, value)
    else:
        raise ValueError(f'Undefined type: [{cls.mot} {cls.mat}]')
    return byt

class Array:
    def __init__(self, type: "Type", length: int):
        self.type = type
        self.length = length
        self.ptr = PtrType.malloc(type, length)
    def __getitem__(self, offset: int):
        ptr = self.ptr + self.type.mat.value * offset
        return ptr.value
    def __setitem__(self, offset: int, value):
        ptr = self.ptr + self.type.mat.value * offset
        ptr.value = value
    def __del__(self):
        self.ptr.free()

def t_init(self, value):
    global _vram
    self.value = value
    self.ptr = PtrType(self.__class__)
    buf = _ser(self.__class__, value)
    ptr = self.ptr._usable_ptr
    if ptr is not nullptr:
        for offset, byt in zip(range(self.ptr.using_space), buf):
            _vram[ptr + offset] = byt
    else:
        raise OverflowError('No correct memory is available at the time of allocation')
    self.ptr._update_ptr(ptr)

def t_str(self):
    return str(self.value)

def t_del(self):
    self.ptr.free()

class Type(type):
    def __new__(meta, maintype: MainTypes, modifiedtype: ModifiedTypes = None):
        name = f'[{'' if not modifiedtype else modifiedtype.name + '_'}{maintype.name}]'
        bases = ()
        namespace = {}
        return super().__new__(
            meta, name, bases, namespace
        )
    def __init__(cls,  maintype: MainTypes, modifiedtype: ModifiedTypes = None):
        cls.mat = maintype
        cls.mot = modifiedtype
        cls.__init__ = t_init
        cls.__str__ = t_str
        cls.__del__ = t_del
    def __str__(cls):
        return f'[{'' if not cls.mot else cls.mot.name + ' '}{cls.mat.name}]'
    def __and__(cls, other) -> PtrType:
        if other.__class__.__class__ is Type:
            return other.ptr
        else:
            obj = cls(other)
            return obj.ptr
    def __getitem__(cls, length: int):
        return Array(cls, length)

def s_init(self, *args, **kwds):
    self.value = {**{name: value for name, value in zip(self.__slots__[:-1], args)}, **kwds}
    total = sum(t.mat.value for t in self._types.values())
    self.ptr = PtrType.malloc(Type(mat.char), total)
    for name, value in self.value.items():
        field_type = self._types[name]
        offset = self._offset[name]
        field_ptr = PtrType(field_type, self.ptr.ptr + offset)
        field_ptr.value = value

class StructMeta(type):
    def __new__(self, name: str = '...', **kwds: Type):
        name = f'Structure_[{name}]'
        cls = super().__new__(builtins.type, name, (), {})
        cls.__slots__ = tuple(kwds.keys()) + ('_types', 'ptr')
        cls._types = kwds
        cls._offset = {}
        offsetted = 0
        for name, type in kwds.items():
            offset = type.mat.value
            cls._offset[name] = offsetted
            offsetted += offset
        cls.__init__ = s_init
        return cls