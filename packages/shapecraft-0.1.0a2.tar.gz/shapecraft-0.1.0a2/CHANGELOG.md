# Changelog

## v0.1.0-alpha.2 — 2026-04-18

### Fixed
- `release.yml` now explicitly grants `contents: read` alongside `id-token: write`,
  so `actions/checkout` can fetch the tagged ref. Without this, declaring any
  `permissions:` block implicitly scopes all other permissions to `none` and the
  release workflow fails before the PyPI publish step runs.

### Notes
- v0.1.0-alpha.1 was tagged but never reached PyPI because of the above bug.

## v0.1.0-alpha.1 — 2026-04-18 (superseded by 0.1.0a2)

### Added
- HMAC-authenticated Onshape REST client with retries and rate-limit logging
- MCP stdio server with 8 tools:
  - `shapecraft_list_documents`, `shapecraft_create_document`, `shapecraft_create_part_studio`
  - `shapecraft_sketch_rectangle`, `shapecraft_sketch_spline`
  - `shapecraft_offset_plane`
  - `shapecraft_extrude` (symmetric + reverse)
  - `shapecraft_loft`
- `build_coincident_constraint` helper (first of 7 constraint builders in T1)
- Unit test suite (snapshot-based JSON payloads, no network)
- Integration test suite gated by `ONSHAPE_ACCESS_KEY`/`ONSHAPE_SECRET_KEY`
- GitHub Actions: unit tests on py3.10/3.11/3.12, release to PyPI on tag
