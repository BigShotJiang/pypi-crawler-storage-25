from __future__ import annotations

from typing import Optional

from pydantic import TypeAdapter
from typing_extensions import Unpack

from .._resource import AsyncAPIResource, SyncAPIResource
from .._streaming import AsyncStream, SSEEvent, Stream, parse_json
from ..types.messages import (
    MessageParams,
    MessageResponse,
    MessageStreamEvent,
)

_event_adapter: TypeAdapter[MessageStreamEvent] = TypeAdapter(MessageStreamEvent)


def _event_decoder(sse: SSEEvent) -> Optional[MessageStreamEvent]:
    if not sse.data:
        return None
    data = parse_json(sse.data)
    # Server sends `event: <name>` but each data payload also embeds `type`;
    # prefer the data's type field if present, else fall back to the SSE name.
    if isinstance(data, dict) and "type" not in data and sse.event:
        data["type"] = sse.event
    return _event_adapter.validate_python(data)


class Messages(SyncAPIResource):
    def create(self, **params: Unpack[MessageParams]) -> MessageResponse:
        body = {**params, "stream": False}
        data = self._client.request("POST", "/v1/messages", body=body)
        return MessageResponse.model_validate(data)

    def stream(self, **params: Unpack[MessageParams]) -> Stream[MessageStreamEvent]:
        body = {**params, "stream": True}
        response = self._client.stream_request("POST", "/v1/messages", body=body)
        return Stream(response, _event_decoder)


class AsyncMessages(AsyncAPIResource):
    async def create(self, **params: Unpack[MessageParams]) -> MessageResponse:
        body = {**params, "stream": False}
        data = await self._client.request("POST", "/v1/messages", body=body)
        return MessageResponse.model_validate(data)

    async def stream(
        self,
        **params: Unpack[MessageParams],
    ) -> AsyncStream[MessageStreamEvent]:
        body = {**params, "stream": True}
        response = await self._client.stream_request("POST", "/v1/messages", body=body)
        return AsyncStream(response, _event_decoder)


__all__ = ["AsyncMessages", "Messages"]
