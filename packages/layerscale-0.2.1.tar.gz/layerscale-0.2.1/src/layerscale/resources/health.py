from __future__ import annotations

from .._exceptions import APIConnectionError, APIStatusError
from .._resource import AsyncAPIResource, SyncAPIResource
from .._types import NOT_GIVEN, NotGiven, RequestOptions, Timeout
from ..types.common import HealthResponse


def _options(timeout: Timeout | NotGiven) -> RequestOptions | None:
    if isinstance(timeout, NotGiven):
        return None
    return {"timeout": timeout, "max_retries": 0}


class Health(SyncAPIResource):
    def check(self, *, timeout: Timeout | NotGiven = NOT_GIVEN) -> HealthResponse:
        """GET /v1/health. Never raises — the return reports ok/status."""
        try:
            self._client.request("GET", "/v1/health", options=_options(timeout))
            return HealthResponse(ok=True, status=200)
        except APIStatusError as exc:
            return HealthResponse(ok=False, status=exc.status_code)
        except APIConnectionError:
            return HealthResponse(ok=False, status=0)


class AsyncHealth(AsyncAPIResource):
    async def check(self, *, timeout: Timeout | NotGiven = NOT_GIVEN) -> HealthResponse:
        try:
            await self._client.request("GET", "/v1/health", options=_options(timeout))
            return HealthResponse(ok=True, status=200)
        except APIStatusError as exc:
            return HealthResponse(ok=False, status=exc.status_code)
        except APIConnectionError:
            return HealthResponse(ok=False, status=0)


__all__ = ["AsyncHealth", "Health"]
