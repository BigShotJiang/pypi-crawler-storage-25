from __future__ import annotations

from typing_extensions import Unpack

from .._resource import AsyncAPIResource, SyncAPIResource
from ..types.completions import CompletionParams, CompletionResponse


class Completions(SyncAPIResource):
    def create(self, **params: Unpack[CompletionParams]) -> CompletionResponse:
        body = {**params, "stream": False}
        data = self._client.request("POST", "/v1/completions", body=body)
        return CompletionResponse.model_validate(data)


class AsyncCompletions(AsyncAPIResource):
    async def create(self, **params: Unpack[CompletionParams]) -> CompletionResponse:
        body = {**params, "stream": False}
        data = await self._client.request("POST", "/v1/completions", body=body)
        return CompletionResponse.model_validate(data)


__all__ = ["AsyncCompletions", "Completions"]
