from __future__ import annotations

from .._resource import AsyncAPIResource, SyncAPIResource
from ..types.common import ModelsResponse


class Models(SyncAPIResource):
    def list(self) -> ModelsResponse:
        data = self._client.request("GET", "/v1/models")
        return ModelsResponse.model_validate(data)


class AsyncModels(AsyncAPIResource):
    async def list(self) -> ModelsResponse:
        data = await self._client.request("GET", "/v1/models")
        return ModelsResponse.model_validate(data)


__all__ = ["AsyncModels", "Models"]
