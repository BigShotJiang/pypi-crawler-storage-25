from __future__ import annotations

import asyncio
import time
from typing import TYPE_CHECKING, Any, Optional

from pydantic import TypeAdapter
from typing_extensions import Unpack

from .._exceptions import LayerScaleError
from .._resource import AsyncAPIResource, SyncAPIResource
from .._streaming import AsyncStream, SSEEvent, Stream, parse_json
from .._types import NOT_GIVEN, NotGiven
from ..types.sessions import (
    AppendResponse,
    CreateSessionParams,
    CreateSessionResponse,
    FlashDeleteResponse,
    FlashListResponse,
    FlashRegisterResponse,
    GenerateParams,
    GenerateResponse,
    GenerateStreamChunk,
    GenerateStreamDone,
    GenerateStreamToken,
    ListSessionsResponse,
    MarkPrefixResponse,
    SessionEvent,
    SessionState,
    SlotsResponse,
    StreamPushResponse,
    StreamStats,
    StreamStatusResponse,
)
from ..types.stream_data import StreamEntry

if TYPE_CHECKING:
    from ..lib.ws import AsyncSessionSocket, SessionSocket


_DEFAULT_WAIT_TIMEOUT_S = 30.0
_DEFAULT_WAIT_INTERVAL_S = 0.1


# ── Stream decoders ────────────────────────────────────────────────────────

_session_event_adapter: TypeAdapter[SessionEvent] = TypeAdapter(SessionEvent)
_stats_adapter: TypeAdapter[StreamStats] = TypeAdapter(StreamStats)


def _session_event_decoder(sse: SSEEvent) -> Optional[SessionEvent]:
    if not sse.data or not sse.data.strip():
        return None
    try:
        data = parse_json(sse.data)
    except ValueError:
        return None
    if not isinstance(data, dict):
        return None
    if "type" not in data and sse.event:
        data["type"] = sse.event
    if "type" not in data:
        return None
    try:
        return _session_event_adapter.validate_python(data)
    except Exception:
        return None


def _generate_chunk_decoder(sse: SSEEvent) -> Optional[GenerateStreamChunk]:
    if not sse.data:
        return None
    data = parse_json(sse.data)
    if isinstance(data, dict) and data.get("done") is True:
        return GenerateStreamDone.model_validate(data)
    return GenerateStreamToken.model_validate(data)


def _split_create_params(params: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    """Pull the client-side ``mark_prefix`` flag out of the wire payload."""
    payload = dict(params)
    mark_prefix = bool(payload.pop("mark_prefix", False))
    return mark_prefix, payload


# ── Sync ───────────────────────────────────────────────────────────────────


class Sessions(SyncAPIResource):
    # ── Lifecycle ──────────────────────────────────────────────────────────

    def create(self, **params: Unpack[CreateSessionParams]) -> CreateSessionResponse:
        mark_prefix, body = _split_create_params(dict(params))
        data = self._client.request("POST", "/v1/sessions/init", body=body)
        session = CreateSessionResponse.model_validate(data)
        if mark_prefix:
            self.mark_prefix(session.session_id)
        return session

    def list(self) -> ListSessionsResponse:
        data = self._client.request("GET", "/v1/sessions")
        return ListSessionsResponse.model_validate(data)

    def get(self, session_id: str) -> SessionState:
        data = self._client.request("GET", f"/v1/sessions/{session_id}/state")
        return SessionState.model_validate(data)

    def delete(self, session_id: str) -> None:
        self._client.request("DELETE", f"/v1/sessions/{session_id}")

    # ── Text operations ────────────────────────────────────────────────────

    def append(self, session_id: str, text: str) -> AppendResponse:
        data = self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/append",
            body={"text": text},
        )
        return AppendResponse.model_validate(data)

    def slots(self, session_id: str) -> SlotsResponse:
        data = self._client.request("GET", f"/v1/sessions/{session_id}/slots")
        return SlotsResponse.model_validate(data)

    # ── Generation ─────────────────────────────────────────────────────────

    def query(
        self,
        session_id: str,
        **params: Unpack[GenerateParams],
    ) -> GenerateResponse:
        body = {**params, "stream": False}
        data = self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/generate",
            body=body,
        )
        return GenerateResponse.model_validate(data)

    def query_stream(
        self,
        session_id: str,
        **params: Unpack[GenerateParams],
    ) -> Stream[GenerateStreamChunk]:
        body = {**params, "stream": True}
        response = self._client.stream_request(
            "POST",
            f"/v1/sessions/{session_id}/generate",
            body=body,
        )
        return Stream(response, _generate_chunk_decoder)

    # ── Cache ──────────────────────────────────────────────────────────────

    def mark_prefix(self, session_id: str) -> MarkPrefixResponse:
        data = self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/mark_prefix",
            body={},
        )
        return MarkPrefixResponse.model_validate(data)

    # ── Data streaming ─────────────────────────────────────────────────────

    def push(
        self,
        session_id: str,
        data: list[StreamEntry],
        *,
        wait: bool = False,
        wait_timeout: float = _DEFAULT_WAIT_TIMEOUT_S,
        wait_interval: float = _DEFAULT_WAIT_INTERVAL_S,
    ) -> StreamPushResponse:
        ack_data = self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/stream/push",
            body={"data": data},
        )
        ack = StreamPushResponse.model_validate(ack_data)
        if not wait:
            return ack

        deadline = time.monotonic() + wait_timeout
        while time.monotonic() < deadline:
            status = self.stream_status(session_id)
            if status.streaming.queue_size == 0 and status.statistics.items_processed >= ack.total_enqueued:
                return ack
            time.sleep(wait_interval)
        raise LayerScaleError(f"push(wait=True) timed out after {wait_timeout}s")

    def stream_status(self, session_id: str) -> StreamStatusResponse:
        data = self._client.request("GET", f"/v1/sessions/{session_id}/stream/status")
        return StreamStatusResponse.model_validate(data)

    def stats(self, session_id: str) -> StreamStats:
        data = self._client.request("GET", f"/v1/sessions/{session_id}/stats")
        return _stats_adapter.validate_python(data)

    # ── Flash queries ──────────────────────────────────────────────────────

    def flash(
        self,
        session_id: str,
        query: str,
        *,
        max_tokens: int | NotGiven = NOT_GIVEN,
    ) -> FlashRegisterResponse:
        body: dict[str, Any] = {"query": query}
        if not isinstance(max_tokens, NotGiven):
            body["max_tokens"] = max_tokens
        data = self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/flash",
            body=body,
        )
        return FlashRegisterResponse.model_validate(data)

    def unflash(self, session_id: str, query_id: int) -> FlashDeleteResponse:
        data = self._client.request(
            "DELETE",
            f"/v1/sessions/{session_id}/flash/{query_id}",
        )
        return FlashDeleteResponse.model_validate(data)

    def list_flash(self, session_id: str) -> FlashListResponse:
        data = self._client.request("GET", f"/v1/sessions/{session_id}/flash")
        return FlashListResponse.model_validate(data)

    # ── Server-Sent Events ─────────────────────────────────────────────────

    def events(self, session_id: str) -> Stream[SessionEvent]:
        response = self._client.stream_request(
            "GET",
            f"/v1/sessions/{session_id}/events",
        )
        return Stream(response, _session_event_decoder)

    # ── WebSocket ──────────────────────────────────────────────────────────

    def stream(self, session_id: str) -> SessionSocket:
        from ..lib.ws import SessionSocket

        ws_url = self._build_ws_url(session_id)
        return SessionSocket(ws_url, headers=self._client.headers)

    def _build_ws_url(self, session_id: str) -> str:
        base = self._client.base_url
        if base.startswith("https://"):
            base = "wss://" + base[len("https://") :]
        elif base.startswith("http://"):
            base = "ws://" + base[len("http://") :]
        return f"{base}/v1/sessions/{session_id}/ws"


# ── Async ──────────────────────────────────────────────────────────────────


class AsyncSessions(AsyncAPIResource):
    async def create(self, **params: Unpack[CreateSessionParams]) -> CreateSessionResponse:
        mark_prefix, body = _split_create_params(dict(params))
        data = await self._client.request("POST", "/v1/sessions/init", body=body)
        session = CreateSessionResponse.model_validate(data)
        if mark_prefix:
            await self.mark_prefix(session.session_id)
        return session

    async def list(self) -> ListSessionsResponse:
        data = await self._client.request("GET", "/v1/sessions")
        return ListSessionsResponse.model_validate(data)

    async def get(self, session_id: str) -> SessionState:
        data = await self._client.request("GET", f"/v1/sessions/{session_id}/state")
        return SessionState.model_validate(data)

    async def delete(self, session_id: str) -> None:
        await self._client.request("DELETE", f"/v1/sessions/{session_id}")

    async def append(self, session_id: str, text: str) -> AppendResponse:
        data = await self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/append",
            body={"text": text},
        )
        return AppendResponse.model_validate(data)

    async def slots(self, session_id: str) -> SlotsResponse:
        data = await self._client.request("GET", f"/v1/sessions/{session_id}/slots")
        return SlotsResponse.model_validate(data)

    async def query(
        self,
        session_id: str,
        **params: Unpack[GenerateParams],
    ) -> GenerateResponse:
        body = {**params, "stream": False}
        data = await self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/generate",
            body=body,
        )
        return GenerateResponse.model_validate(data)

    async def query_stream(
        self,
        session_id: str,
        **params: Unpack[GenerateParams],
    ) -> AsyncStream[GenerateStreamChunk]:
        body = {**params, "stream": True}
        response = await self._client.stream_request(
            "POST",
            f"/v1/sessions/{session_id}/generate",
            body=body,
        )
        return AsyncStream(response, _generate_chunk_decoder)

    async def mark_prefix(self, session_id: str) -> MarkPrefixResponse:
        data = await self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/mark_prefix",
            body={},
        )
        return MarkPrefixResponse.model_validate(data)

    async def push(
        self,
        session_id: str,
        data: list[StreamEntry],
        *,
        wait: bool = False,
        wait_timeout: float = _DEFAULT_WAIT_TIMEOUT_S,
        wait_interval: float = _DEFAULT_WAIT_INTERVAL_S,
    ) -> StreamPushResponse:
        ack_data = await self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/stream/push",
            body={"data": data},
        )
        ack = StreamPushResponse.model_validate(ack_data)
        if not wait:
            return ack

        loop = asyncio.get_event_loop()
        deadline = loop.time() + wait_timeout
        while loop.time() < deadline:
            status = await self.stream_status(session_id)
            if status.streaming.queue_size == 0 and status.statistics.items_processed >= ack.total_enqueued:
                return ack
            await asyncio.sleep(wait_interval)
        raise LayerScaleError(f"push(wait=True) timed out after {wait_timeout}s")

    async def stream_status(self, session_id: str) -> StreamStatusResponse:
        data = await self._client.request(
            "GET",
            f"/v1/sessions/{session_id}/stream/status",
        )
        return StreamStatusResponse.model_validate(data)

    async def stats(self, session_id: str) -> StreamStats:
        data = await self._client.request("GET", f"/v1/sessions/{session_id}/stats")
        return _stats_adapter.validate_python(data)

    async def flash(
        self,
        session_id: str,
        query: str,
        *,
        max_tokens: int | NotGiven = NOT_GIVEN,
    ) -> FlashRegisterResponse:
        body: dict[str, Any] = {"query": query}
        if not isinstance(max_tokens, NotGiven):
            body["max_tokens"] = max_tokens
        data = await self._client.request(
            "POST",
            f"/v1/sessions/{session_id}/flash",
            body=body,
        )
        return FlashRegisterResponse.model_validate(data)

    async def unflash(self, session_id: str, query_id: int) -> FlashDeleteResponse:
        data = await self._client.request(
            "DELETE",
            f"/v1/sessions/{session_id}/flash/{query_id}",
        )
        return FlashDeleteResponse.model_validate(data)

    async def list_flash(self, session_id: str) -> FlashListResponse:
        data = await self._client.request("GET", f"/v1/sessions/{session_id}/flash")
        return FlashListResponse.model_validate(data)

    async def events(self, session_id: str) -> AsyncStream[SessionEvent]:
        response = await self._client.stream_request(
            "GET",
            f"/v1/sessions/{session_id}/events",
        )
        return AsyncStream(response, _session_event_decoder)

    def stream(self, session_id: str) -> AsyncSessionSocket:
        from ..lib.ws import AsyncSessionSocket

        ws_url = self._build_ws_url(session_id)
        return AsyncSessionSocket(ws_url, headers=self._client.headers)

    def _build_ws_url(self, session_id: str) -> str:
        base = self._client.base_url
        if base.startswith("https://"):
            base = "wss://" + base[len("https://") :]
        elif base.startswith("http://"):
            base = "ws://" + base[len("http://") :]
        return f"{base}/v1/sessions/{session_id}/ws"


__all__ = ["AsyncSessions", "Sessions"]
