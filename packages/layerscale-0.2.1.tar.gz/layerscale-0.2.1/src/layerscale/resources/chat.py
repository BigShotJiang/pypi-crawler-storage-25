from __future__ import annotations

from typing import Optional

from typing_extensions import Unpack

from .._resource import AsyncAPIResource, SyncAPIResource
from .._streaming import AsyncStream, SSEEvent, Stream, mark_done, parse_json
from ..types.chat import (
    ChatCompletionChunk,
    ChatCompletionParams,
    ChatCompletionResponse,
)


def _chunk_decoder(sse: SSEEvent) -> Optional[ChatCompletionChunk]:
    if not sse.data:
        return None
    if sse.data.strip() == "[DONE]":
        return mark_done()
    return ChatCompletionChunk.model_validate(parse_json(sse.data))


class Chat(SyncAPIResource):
    def create(self, **params: Unpack[ChatCompletionParams]) -> ChatCompletionResponse:
        body = {**params, "stream": False}
        data = self._client.request("POST", "/v1/chat/completions", body=body)
        return ChatCompletionResponse.model_validate(data)

    def stream(self, **params: Unpack[ChatCompletionParams]) -> Stream[ChatCompletionChunk]:
        body = {**params, "stream": True}
        response = self._client.stream_request("POST", "/v1/chat/completions", body=body)
        return Stream(response, _chunk_decoder)


class AsyncChat(AsyncAPIResource):
    async def create(self, **params: Unpack[ChatCompletionParams]) -> ChatCompletionResponse:
        body = {**params, "stream": False}
        data = await self._client.request("POST", "/v1/chat/completions", body=body)
        return ChatCompletionResponse.model_validate(data)

    async def stream(self, **params: Unpack[ChatCompletionParams]) -> AsyncStream[ChatCompletionChunk]:
        body = {**params, "stream": True}
        response = await self._client.stream_request("POST", "/v1/chat/completions", body=body)
        return AsyncStream(response, _chunk_decoder)


__all__ = ["AsyncChat", "Chat"]
