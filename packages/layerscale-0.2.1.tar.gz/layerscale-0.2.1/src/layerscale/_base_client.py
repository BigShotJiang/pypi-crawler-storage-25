from __future__ import annotations

import asyncio
import os
import random
import time
from collections.abc import Mapping
from typing import (
    Any,
    Optional,
    Union,
)

import httpx

from ._exceptions import (
    APIConnectionError,
    APITimeoutError,
    LayerScaleError,
    make_status_error,
)
from ._types import NOT_GIVEN, Headers, NotGiven, RequestOptions, Timeout
from ._version import __version__

DEFAULT_TIMEOUT = httpx.Timeout(timeout=600.0, connect=5.0)
DEFAULT_MAX_RETRIES = 2
INITIAL_RETRY_DELAY = 0.5
MAX_RETRY_DELAY = 8.0
_USER_AGENT = f"layerscale-python/{__version__}"


def _coerce_timeout(value: Union[Timeout, NotGiven]) -> httpx.Timeout:
    if isinstance(value, NotGiven):
        return DEFAULT_TIMEOUT
    if value is None:
        return httpx.Timeout(None)
    if isinstance(value, httpx.Timeout):
        return value
    return httpx.Timeout(timeout=float(value))


class _BaseClient:
    base_url: str
    headers: dict[str, str]
    timeout: httpx.Timeout
    max_retries: int

    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str],
        timeout: Union[Timeout, NotGiven] = NOT_GIVEN,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Mapping[str, str]] = None,
    ) -> None:
        if api_key is None:
            api_key = os.environ.get("LAYERSCALE_LICENSE_KEY")

        self.base_url = base_url.rstrip("/")
        self.timeout = _coerce_timeout(timeout)
        self.max_retries = max_retries

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "User-Agent": _USER_AGENT,
        }
        if api_key:
            headers["Authorization"] = f"Bearer {api_key}"
        if default_headers:
            headers.update(default_headers)
        self.headers = headers

    def _merge_headers(self, extra: Optional[Headers]) -> dict[str, str]:
        if not extra:
            return self.headers
        merged = dict(self.headers)
        merged.update(extra)
        return merged

    def _resolve_timeout(self, per_request: Union[Timeout, NotGiven]) -> httpx.Timeout:
        if isinstance(per_request, NotGiven):
            return self.timeout
        return _coerce_timeout(per_request)

    def _prepare_request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        options: Optional[RequestOptions] = None,
    ) -> tuple[dict[str, str], Optional[bytes], httpx.Timeout, int]:
        opts = options or {}
        headers = self._merge_headers(opts.get("headers"))
        timeout = self._resolve_timeout(opts.get("timeout", NOT_GIVEN))
        retries = opts.get("max_retries", self.max_retries)
        content: Optional[bytes]
        if body is None:
            content = None
        else:
            import json as _json

            content = _json.dumps(body).encode("utf-8")
        return headers, content, timeout, retries


def _build_url(base_url: str, path: str) -> str:
    if not path.startswith("/"):
        path = "/" + path
    return f"{base_url}{path}"


def _should_retry(response: httpx.Response) -> bool:
    status = response.status_code
    if status in (408, 409, 429):
        return True
    return 500 <= status < 600


def _retry_delay(attempt: int, response: Optional[httpx.Response]) -> float:
    # Honor Retry-After if the server sent one.
    if response is not None:
        header = response.headers.get("retry-after")
        if header:
            try:
                return max(0.0, float(header))
            except ValueError:
                pass

    # Exponential backoff with jitter.
    delay = min(INITIAL_RETRY_DELAY * (2**attempt), MAX_RETRY_DELAY)
    return delay * (0.5 + random.random() * 0.5)


def _parse_body(response: httpx.Response) -> Any:
    if not response.content:
        return None
    try:
        return response.json()
    except ValueError:
        return response.text


# ── Sync ───────────────────────────────────────────────────────────────────


class SyncAPIClient(_BaseClient):
    _client: httpx.Client
    _owns_client: bool

    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str],
        timeout: Union[Timeout, NotGiven] = NOT_GIVEN,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Mapping[str, str]] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        super().__init__(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
        )
        if http_client is None:
            self._client = httpx.Client(timeout=self.timeout)
            self._owns_client = True
        else:
            self._client = http_client
            self._owns_client = False

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> SyncAPIClient:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        headers, content, timeout, retries = self._prepare_request(
            method,
            path,
            body=body,
            options=options,
        )
        url = _build_url(self.base_url, path)
        last_response: Optional[httpx.Response] = None

        for attempt in range(retries + 1):
            try:
                response = self._client.request(
                    method,
                    url,
                    headers=headers,
                    content=content,
                    timeout=timeout,
                )
            except httpx.TimeoutException as exc:
                if attempt >= retries:
                    raise APITimeoutError(request=exc.request) from exc
                time.sleep(_retry_delay(attempt, None))
                continue
            except httpx.RequestError as exc:
                if attempt >= retries:
                    raise APIConnectionError(
                        message=f"Connection error: {exc}",
                        request=exc.request,
                    ) from exc
                time.sleep(_retry_delay(attempt, None))
                continue

            last_response = response
            if response.is_success:
                return _parse_body(response)

            if attempt < retries and _should_retry(response):
                delay = _retry_delay(attempt, response)
                response.close()
                time.sleep(delay)
                continue

            body_data = _parse_body(response)
            raise make_status_error(response, body_data)

        # Should be unreachable — the loop either returns or raises.
        if last_response is not None:
            raise make_status_error(last_response, _parse_body(last_response))
        raise LayerScaleError("Request failed without producing a response")

    def stream_request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        """Open a streaming response. Caller is responsible for closing it.

        Streaming requests skip automatic retries — mid-stream recovery is
        unsafe for SSE consumers.
        """
        opts = options or {}
        headers = self._merge_headers(opts.get("headers"))
        timeout = self._resolve_timeout(opts.get("timeout", NOT_GIVEN))

        content: Optional[bytes] = None
        if body is not None:
            import json as _json

            content = _json.dumps(body).encode("utf-8")

        url = _build_url(self.base_url, path)
        req = self._client.build_request(
            method,
            url,
            headers=headers,
            content=content,
            timeout=timeout,
        )
        try:
            response = self._client.send(req, stream=True)
        except httpx.TimeoutException as exc:
            raise APITimeoutError(request=exc.request) from exc
        except httpx.RequestError as exc:
            raise APIConnectionError(
                message=f"Connection error: {exc}",
                request=exc.request,
            ) from exc

        if not response.is_success:
            # Read & close before raising so the body is available to the caller.
            response.read()
            body_data = _parse_body(response)
            response.close()
            raise make_status_error(response, body_data)

        return response


# ── Async ──────────────────────────────────────────────────────────────────


class AsyncAPIClient(_BaseClient):
    _client: httpx.AsyncClient
    _owns_client: bool

    def __init__(
        self,
        *,
        base_url: str,
        api_key: Optional[str],
        timeout: Union[Timeout, NotGiven] = NOT_GIVEN,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Mapping[str, str]] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        super().__init__(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
        )
        if http_client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
            self._owns_client = True
        else:
            self._client = http_client
            self._owns_client = False

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> AsyncAPIClient:
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.close()

    async def request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        options: Optional[RequestOptions] = None,
    ) -> Any:
        headers, content, timeout, retries = self._prepare_request(
            method,
            path,
            body=body,
            options=options,
        )
        url = _build_url(self.base_url, path)
        last_response: Optional[httpx.Response] = None

        for attempt in range(retries + 1):
            try:
                response = await self._client.request(
                    method,
                    url,
                    headers=headers,
                    content=content,
                    timeout=timeout,
                )
            except httpx.TimeoutException as exc:
                if attempt >= retries:
                    raise APITimeoutError(request=exc.request) from exc
                await asyncio.sleep(_retry_delay(attempt, None))
                continue
            except httpx.RequestError as exc:
                if attempt >= retries:
                    raise APIConnectionError(
                        message=f"Connection error: {exc}",
                        request=exc.request,
                    ) from exc
                await asyncio.sleep(_retry_delay(attempt, None))
                continue

            last_response = response
            if response.is_success:
                return _parse_body(response)

            if attempt < retries and _should_retry(response):
                delay = _retry_delay(attempt, response)
                await response.aclose()
                await asyncio.sleep(delay)
                continue

            body_data = _parse_body(response)
            raise make_status_error(response, body_data)

        if last_response is not None:
            raise make_status_error(last_response, _parse_body(last_response))
        raise LayerScaleError("Request failed without producing a response")

    async def stream_request(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        options: Optional[RequestOptions] = None,
    ) -> httpx.Response:
        opts = options or {}
        headers = self._merge_headers(opts.get("headers"))
        timeout = self._resolve_timeout(opts.get("timeout", NOT_GIVEN))

        content: Optional[bytes] = None
        if body is not None:
            import json as _json

            content = _json.dumps(body).encode("utf-8")

        url = _build_url(self.base_url, path)
        req = self._client.build_request(
            method,
            url,
            headers=headers,
            content=content,
            timeout=timeout,
        )
        try:
            response = await self._client.send(req, stream=True)
        except httpx.TimeoutException as exc:
            raise APITimeoutError(request=exc.request) from exc
        except httpx.RequestError as exc:
            raise APIConnectionError(
                message=f"Connection error: {exc}",
                request=exc.request,
            ) from exc

        if not response.is_success:
            await response.aread()
            body_data = _parse_body(response)
            await response.aclose()
            raise make_status_error(response, body_data)

        return response


__all__ = [
    "DEFAULT_MAX_RETRIES",
    "DEFAULT_TIMEOUT",
    "AsyncAPIClient",
    "SyncAPIClient",
]
