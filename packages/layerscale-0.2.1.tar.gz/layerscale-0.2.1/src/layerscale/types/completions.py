from __future__ import annotations

from typing import Optional, Union

from typing_extensions import Required, TypedDict

from .._models import BaseModel
from .common import Usage


class CompletionParams(TypedDict, total=False):
    prompt: Required[str]
    model: str
    max_tokens: int
    temperature: float
    top_p: float
    stop: Union[str, list[str]]


class CompletionChoice(BaseModel):
    text: str
    index: int
    finish_reason: Optional[str] = None


class CompletionResponse(BaseModel):
    id: str
    object: str
    created: int
    model: str
    choices: list[CompletionChoice]
    usage: Usage


__all__ = [
    "CompletionChoice",
    "CompletionParams",
    "CompletionResponse",
]
