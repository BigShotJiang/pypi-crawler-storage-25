from __future__ import annotations

from typing import Any, Literal, Optional, Union

from pydantic import Field
from typing_extensions import Required, TypedDict

from .._models import BaseModel

# ── Content blocks ─────────────────────────────────────────────────────────


class TextBlock(BaseModel):
    type: Literal["text"]
    text: str


class ToolUseBlock(BaseModel):
    type: Literal["tool_use"]
    id: str
    name: str
    input: dict[str, Any]


class ToolResultBlock(BaseModel):
    type: Literal["tool_result"]
    tool_use_id: str
    content: Union[str, list[Any]]
    is_error: Optional[bool] = None


ContentBlock = Union[TextBlock, ToolUseBlock, ToolResultBlock]


# ── Tools ──────────────────────────────────────────────────────────────────


class ToolInputSchema(TypedDict, total=False):
    type: Required[Literal["object"]]
    properties: dict[str, Any]
    required: list[str]


class AnthropicTool(TypedDict, total=False):
    name: Required[str]
    input_schema: Required[ToolInputSchema]
    description: str


class ToolChoiceAuto(TypedDict):
    type: Literal["auto"]


class ToolChoiceAny(TypedDict):
    type: Literal["any"]


class ToolChoiceTool(TypedDict):
    type: Literal["tool"]
    name: str


AnthropicToolChoice = Union[ToolChoiceAuto, ToolChoiceAny, ToolChoiceTool]


# ── Messages (input) ───────────────────────────────────────────────────────


class AnthropicUserMessage(TypedDict):
    role: Literal["user"]
    content: Union[str, list[Any]]


class AnthropicAssistantMessage(TypedDict):
    role: Literal["assistant"]
    content: Union[str, list[Any]]


AnthropicMessage = Union[AnthropicUserMessage, AnthropicAssistantMessage]


class MessageParams(TypedDict, total=False):
    messages: Required[list[AnthropicMessage]]
    max_tokens: Required[int]
    model: str
    system: str
    temperature: float
    top_p: float
    stop_sequences: list[str]
    tools: list[AnthropicTool]
    tool_choice: AnthropicToolChoice
    session_id: str


# ── Response models ────────────────────────────────────────────────────────


class MessageUsage(BaseModel):
    input_tokens: int
    output_tokens: int


class MessageResponse(BaseModel):
    id: str
    type: Literal["message"]
    role: Literal["assistant"]
    content: list[ContentBlock]
    model: str
    stop_reason: Optional[str] = None
    stop_sequence: Optional[str] = None
    usage: MessageUsage


# ── Streaming events ───────────────────────────────────────────────────────


class MessageStartInfo(BaseModel):
    id: str
    type: Literal["message"]
    role: Literal["assistant"]
    content: list[ContentBlock]
    model: str
    stop_reason: Optional[str] = None
    usage: MessageUsage


class MessageStart(BaseModel):
    type: Literal["message_start"]
    message: MessageStartInfo


class ContentBlockStart(BaseModel):
    type: Literal["content_block_start"]
    index: int
    content_block: Union[TextBlock, ToolUseBlock]


class TextDelta(BaseModel):
    type: Literal["text_delta"]
    text: str


class InputJsonDelta(BaseModel):
    type: Literal["input_json_delta"]
    partial_json: str


class ContentBlockDelta(BaseModel):
    type: Literal["content_block_delta"]
    index: int
    delta: Union[TextDelta, InputJsonDelta] = Field(discriminator="type")


class ContentBlockStop(BaseModel):
    type: Literal["content_block_stop"]
    index: int


class MessageDeltaInfo(BaseModel):
    stop_reason: str


class MessageDeltaUsage(BaseModel):
    output_tokens: int


class MessageDelta(BaseModel):
    type: Literal["message_delta"]
    delta: MessageDeltaInfo
    usage: MessageDeltaUsage


class MessageStop(BaseModel):
    type: Literal["message_stop"]


MessageStreamEvent = Union[
    MessageStart,
    ContentBlockStart,
    ContentBlockDelta,
    ContentBlockStop,
    MessageDelta,
    MessageStop,
]


__all__ = [
    "AnthropicAssistantMessage",
    "AnthropicMessage",
    "AnthropicTool",
    "AnthropicToolChoice",
    "AnthropicUserMessage",
    "ContentBlock",
    "ContentBlockDelta",
    "ContentBlockStart",
    "ContentBlockStop",
    "InputJsonDelta",
    "MessageDelta",
    "MessageDeltaInfo",
    "MessageDeltaUsage",
    "MessageParams",
    "MessageResponse",
    "MessageStart",
    "MessageStartInfo",
    "MessageStop",
    "MessageStreamEvent",
    "MessageUsage",
    "TextBlock",
    "TextDelta",
    "ToolChoiceAny",
    "ToolChoiceAuto",
    "ToolChoiceTool",
    "ToolInputSchema",
    "ToolResultBlock",
    "ToolUseBlock",
]
