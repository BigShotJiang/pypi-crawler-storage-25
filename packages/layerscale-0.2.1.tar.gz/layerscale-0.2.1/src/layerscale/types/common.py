from __future__ import annotations

from typing import Literal

from .._models import BaseModel

StreamType = Literal["ohlcv", "iot", "spatial", "event", "vitals"]


class HealthResponse(BaseModel):
    ok: bool
    status: int


class Model(BaseModel):
    id: str
    object: str
    created: int
    owned_by: str


class ModelsResponse(BaseModel):
    object: str
    data: list[Model]


class Usage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


__all__ = [
    "HealthResponse",
    "Model",
    "ModelsResponse",
    "StreamType",
    "Usage",
]
