from __future__ import annotations

from typing import Any, Literal, Optional, Union

from typing_extensions import Required, TypedDict

from .._models import BaseModel
from .common import StreamType

# ── Flash query init ───────────────────────────────────────────────────────


class FlashQueryInit(TypedDict, total=False):
    query: Required[str]
    max_tokens: int


# ── Session create ─────────────────────────────────────────────────────────


class CreateSessionParams(TypedDict, total=False):
    type: Required[StreamType]
    prompt: str
    context: int
    window_size: int
    flash: list[FlashQueryInit]
    mark_prefix: bool
    """If True, call ``mark_prefix`` immediately after session creation so the
    system prompt is frozen in the cache. Client-side convenience — not part
    of the wire payload.
    """


class CreateSessionResponse(BaseModel):
    session_id: str
    type: StreamType
    n_tokens: int
    context: int
    window_size: int
    flash_queries: int
    pos_max: int


class SessionSummary(BaseModel):
    session_id: str
    n_tokens: int
    context: int
    prefix_end: int
    last_inject_us: int
    cache_usage: float
    created_at: int
    last_used_at: int
    in_use: bool


class ListSessionsResponse(BaseModel):
    sessions: list[SessionSummary]
    count: int
    max_sessions: int


class DataRegion(BaseModel):
    start: int
    end: int
    window_size: Optional[int] = None


class SessionState(BaseModel):
    session_id: str
    type: StreamType
    n_tokens: int
    context: int
    pos_min: int
    pos_max: int
    pos_next: int
    prefix_end: int
    data_region: DataRegion
    data_count: int
    last_inject_us: int
    cache_usage: float
    created_at: int
    last_used_at: int
    in_use: bool
    context_text: str


# ── Text operations ────────────────────────────────────────────────────────


class AppendResponse(BaseModel):
    n_tokens_added: int
    total_tokens: int
    pos_max: int


class SlotInfo(BaseModel):
    name: str
    start: int
    end: int
    n_tokens: int


class SlotsResponse(BaseModel):
    slots: list[SlotInfo]
    prefix_end: int
    data_region: DataRegion
    pos_next: int
    total_tokens: int


# ── Generation ─────────────────────────────────────────────────────────────


class ToolCallFunction(BaseModel):
    name: str
    arguments: str
    """JSON-encoded string of the tool arguments (OpenAI convention)."""


class ToolCall(BaseModel):
    id: str
    type: Literal["function"] = "function"
    function: ToolCallFunction


class GenerateParams(TypedDict, total=False):
    prompt: str
    """Raw text delta to append before generation (streaming-data style).
    Mutually exclusive with ``messages`` — use one or the other."""

    messages: list[dict[str, Any]]
    """OpenAI-format chat messages. Server applies the model's Jinja chat
    template, then only decodes tokens past the session's current prefix.
    Entries: ``{role, content, tool_calls?, tool_call_id?}``."""

    tools: list[dict[str, Any]]
    """OpenAI tools schema. Passing a non-empty list enables constrained
    tool-call decoding on the server side. The first turn builds the guide;
    subsequent turns hit the per-session cache for free."""

    max_tokens: int
    fast_answer: bool
    clear_after: int
    stop: list[str]


class GenerateResponse(BaseModel):
    text: str
    n_tokens: int
    total_tokens: int
    pos_max: int
    #: "stop" | "length" | "tool_calls". Mirrors OpenAI chat-completion semantics.
    finish_reason: Optional[str] = None
    #: Present when the model emitted a tool call. Shape matches OpenAI's
    #: chat.completion ``tool_calls`` field so you can feed them straight
    #: back into the next turn's ``messages``.
    tool_calls: Optional[list[ToolCall]] = None
    #: OHLCV fast-path diagnostics (unchanged).
    flash: Optional[bool] = None
    flash_id: Optional[int] = None
    data_version: Optional[int] = None
    confidence: Optional[float] = None
    speculative: Optional[bool] = None
    logit_gap: Optional[float] = None


class GenerateStreamToken(BaseModel):
    done: Literal[False] = False
    token: str
    pos: int
    #: Set to True on the frame that carries the constrained tool-call prefix
    #: (``{"name": "X", "parameters": ``) so UIs can switch rendering modes
    #: before the argument values stream in.
    tool_call: Optional[bool] = None


class GenerateStreamDone(BaseModel):
    done: Literal[True] = True
    text: str
    n_tokens: int
    finish_reason: Optional[str] = None
    tool_calls: Optional[list[ToolCall]] = None


GenerateStreamChunk = Union[GenerateStreamToken, GenerateStreamDone]


# ── Cache ──────────────────────────────────────────────────────────────────


class MarkPrefixResponse(BaseModel):
    prefix_end: int
    message: str


# ── Streaming ingest ───────────────────────────────────────────────────────


class StreamPushResponse(BaseModel):
    pushed: int
    dropped: int
    queue_size: int
    queue_capacity: int
    total_enqueued: int
    total_dropped: int


class StreamingInfo(BaseModel):
    initialized: bool
    running: bool
    error: bool
    queue_size: int
    queue_capacity: int
    window_size: int
    process_interval_us: int


class StreamStatistics(BaseModel):
    total_enqueued: int
    total_dropped: int
    batches_processed: int
    items_processed: int
    total_process_time_us: int
    avg_process_time_us: float


class StreamDataInfo(BaseModel):
    initialized: bool
    data_count: int
    total_data_tokens: int
    pos_next: int


class StreamStatusResponse(BaseModel):
    type: StreamType
    streaming: StreamingInfo
    statistics: StreamStatistics
    data: StreamDataInfo


# ── Stats (per stream type) ────────────────────────────────────────────────


class OHLCVStats(BaseModel):
    type: Literal["ohlcv"]
    count: int
    max_high: float
    max_high_index: int
    min_low: float
    min_low_index: int
    max_volume: float
    first_open: float
    last_close: float
    avg_close: float
    change: float
    change_pct: float


class IoTStats(BaseModel):
    type: Literal["iot"]
    count: int
    last_sensor: str
    last_value: float
    min_value: float
    max_value: float
    avg_value: float
    threshold_breaches: int
    breach_rate: float


class SpatialPosition(BaseModel):
    x: float
    y: float
    z: float


class SpatialStats(BaseModel):
    type: Literal["spatial"]
    count: int
    current_position: SpatialPosition
    current_speed: float
    current_heading: float
    total_distance: float
    max_speed: float
    avg_speed: float
    max_turn_rate: float


class EventStats(BaseModel):
    type: Literal["event"]
    count: int
    total_event_count: int
    max_severity: int
    critical_events: int
    unique_sources: int
    unique_categories: int
    top_category: str
    top_category_count: int


class VitalsCurrent(BaseModel):
    hr: float
    bp: str
    spo2: float
    temp: float
    map: float


class VitalsAlerts(BaseModel):
    tachycardia_episodes: int
    bradycardia_episodes: int
    hypoxia_episodes: int
    fever_episodes: int


class VitalsStats(BaseModel):
    type: Literal["vitals"]
    count: int
    current: VitalsCurrent
    avg_heart_rate: float
    avg_map: float
    min_spo2: float
    max_temp: float
    alerts: VitalsAlerts


StreamStats = Union[OHLCVStats, IoTStats, SpatialStats, EventStats, VitalsStats]


# ── Flash queries ──────────────────────────────────────────────────────────


class FlashQuery(BaseModel):
    id: int
    query: str
    max_tokens: int
    n_tokens: int
    has_answer: bool
    value: str
    data_version: int
    confidence: float
    evaluated_at: int


class FlashRegisterResponse(BaseModel):
    id: int
    query: str
    max_tokens: int
    n_tokens: int
    total_flash_queries: int


class FlashListResponse(BaseModel):
    flash_queries: list[FlashQuery]
    count: int
    current_data_version: int


class FlashDeleteResponse(BaseModel):
    success: bool
    remaining: int


# ── Session events (SSE) ───────────────────────────────────────────────────


class FlashReadyEvent(BaseModel):
    type: Literal["flash_ready"]
    id: int
    query: str
    value: str
    data_version: int
    confidence: float
    evaluated_at: int


class DataUpdatedEvent(BaseModel):
    type: Literal["data_updated"]
    data_version: int
    data_count: int
    pos_next: int


class ConnectedEvent(BaseModel):
    type: Literal["connected"]
    data_version: int
    flash_queries: int


SessionEvent = Union[FlashReadyEvent, DataUpdatedEvent, ConnectedEvent]


# ── WebSocket frames ───────────────────────────────────────────────────────


class WsConnectedData(BaseModel):
    session_id: str
    data_version: int
    streaming: bool
    flash_queries: int


class WsPushAckData(BaseModel):
    pushed: int
    dropped: int
    queue_size: int


class WsFlashReadyData(BaseModel):
    id: int
    query: str
    value: str
    data_version: int
    confidence: float
    evaluated_at: int


class WsDataUpdatedData(BaseModel):
    data_version: int
    data_count: int
    pos_next: int


class WsErrorData(BaseModel):
    message: str
    code: int


__all__ = [
    "AppendResponse",
    "ConnectedEvent",
    "CreateSessionParams",
    "CreateSessionResponse",
    "DataRegion",
    "DataUpdatedEvent",
    "EventStats",
    "FlashDeleteResponse",
    "FlashListResponse",
    "FlashQuery",
    "FlashQueryInit",
    "FlashReadyEvent",
    "FlashRegisterResponse",
    "GenerateParams",
    "GenerateResponse",
    "GenerateStreamChunk",
    "GenerateStreamDone",
    "GenerateStreamToken",
    "IoTStats",
    "ListSessionsResponse",
    "MarkPrefixResponse",
    "OHLCVStats",
    "SessionEvent",
    "SessionState",
    "SessionSummary",
    "SlotInfo",
    "SlotsResponse",
    "SpatialPosition",
    "SpatialStats",
    "StreamDataInfo",
    "StreamPushResponse",
    "StreamStatistics",
    "StreamStats",
    "StreamStatusResponse",
    "StreamingInfo",
    "ToolCall",
    "ToolCallFunction",
    "VitalsAlerts",
    "VitalsCurrent",
    "VitalsStats",
    "WsConnectedData",
    "WsDataUpdatedData",
    "WsErrorData",
    "WsFlashReadyData",
    "WsPushAckData",
]
