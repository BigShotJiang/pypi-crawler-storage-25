from __future__ import annotations

from typing import Any, Literal, Optional, Union

from typing_extensions import Required, TypedDict

from .._models import BaseModel
from .common import Usage

# ── Tools ──────────────────────────────────────────────────────────────────


class FunctionDefinition(TypedDict, total=False):
    name: Required[str]
    description: str
    parameters: dict[str, Any]


class ChatCompletionTool(TypedDict):
    type: Literal["function"]
    function: FunctionDefinition


class ToolChoiceFunction(TypedDict):
    type: Literal["function"]
    function: dict[str, str]


ToolChoice = Union[Literal["none", "auto", "required"], ToolChoiceFunction]


# ── Messages (input) ───────────────────────────────────────────────────────


class ChatSystemMessage(TypedDict, total=False):
    role: Required[Literal["system"]]
    content: Required[str]
    name: str


class ChatUserMessage(TypedDict, total=False):
    role: Required[Literal["user"]]
    content: Required[str]
    name: str


class ToolCallDict(TypedDict):
    id: str
    type: Literal["function"]
    function: dict[str, str]


class ChatAssistantMessage(TypedDict, total=False):
    role: Required[Literal["assistant"]]
    content: Optional[str]
    tool_calls: list[ToolCallDict]
    name: str


class ChatToolMessage(TypedDict):
    role: Literal["tool"]
    content: str
    tool_call_id: str


ChatMessage = Union[ChatSystemMessage, ChatUserMessage, ChatAssistantMessage, ChatToolMessage]


class ChatCompletionParams(TypedDict, total=False):
    messages: Required[list[ChatMessage]]
    model: str
    max_tokens: int
    temperature: float
    top_p: float
    stop: Union[str, list[str]]
    tools: list[ChatCompletionTool]
    tool_choice: ToolChoice
    session_id: str


# ── Response models ────────────────────────────────────────────────────────


class ToolCall(BaseModel):
    id: str
    type: Literal["function"]
    function: dict[str, str]


class ChatResponseMessage(BaseModel):
    role: str
    content: Optional[str] = None
    tool_calls: Optional[list[ToolCall]] = None
    name: Optional[str] = None
    tool_call_id: Optional[str] = None


class ChatCompletionChoice(BaseModel):
    index: int
    message: ChatResponseMessage
    finish_reason: Optional[str] = None
    tool_calls: Optional[list[ToolCall]] = None


class ChatCompletionResponse(BaseModel):
    id: str
    object: str
    created: int
    model: str
    choices: list[ChatCompletionChoice]
    usage: Usage


class ChatCompletionChunkDeltaToolCall(BaseModel):
    index: int
    id: Optional[str] = None
    type: Optional[str] = None
    function: Optional[dict[str, Optional[str]]] = None


class ChatCompletionChunkDelta(BaseModel):
    role: Optional[str] = None
    content: Optional[str] = None
    tool_calls: Optional[list[ChatCompletionChunkDeltaToolCall]] = None


class ChatCompletionChunkChoice(BaseModel):
    index: int
    delta: ChatCompletionChunkDelta
    finish_reason: Optional[str] = None


class ChatCompletionChunk(BaseModel):
    id: str
    object: str
    created: int
    choices: list[ChatCompletionChunkChoice]


__all__ = [
    "ChatAssistantMessage",
    "ChatCompletionChoice",
    "ChatCompletionChunk",
    "ChatCompletionChunkChoice",
    "ChatCompletionChunkDelta",
    "ChatCompletionChunkDeltaToolCall",
    "ChatCompletionParams",
    "ChatCompletionResponse",
    "ChatCompletionTool",
    "ChatMessage",
    "ChatResponseMessage",
    "ChatSystemMessage",
    "ChatToolMessage",
    "ChatUserMessage",
    "FunctionDefinition",
    "ToolCall",
    "ToolCallDict",
    "ToolChoice",
    "ToolChoiceFunction",
]
