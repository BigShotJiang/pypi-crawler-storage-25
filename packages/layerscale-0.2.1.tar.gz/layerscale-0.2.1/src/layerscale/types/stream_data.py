from __future__ import annotations

from typing import Union

from typing_extensions import Required, TypedDict


class OHLCVEntry(TypedDict, total=False):
    o: Required[float]
    h: Required[float]
    l: Required[float]  # noqa: E741 (matches server field name)
    c: Required[float]
    v: Required[float]
    timestamp: int
    sym: str


class IoTEntry(TypedDict, total=False):
    sid: Required[str]
    val: Required[float]
    lo: Required[float]
    hi: Required[float]
    timestamp: int


class SpatialEntry(TypedDict, total=False):
    x: Required[float]
    y: Required[float]
    z: Required[float]
    spd: Required[float]
    hdg: Required[float]
    timestamp: int


class EventEntry(TypedDict, total=False):
    src: Required[str]
    sev: Required[int]
    cat: Required[str]
    cnt: Required[int]
    timestamp: int


class VitalsEntry(TypedDict, total=False):
    hr: Required[float]
    bp_s: Required[float]
    bp_d: Required[float]
    spo2: Required[float]
    temp: Required[float]
    timestamp: int


StreamEntry = Union[OHLCVEntry, IoTEntry, SpatialEntry, EventEntry, VitalsEntry]


__all__ = [
    "EventEntry",
    "IoTEntry",
    "OHLCVEntry",
    "SpatialEntry",
    "StreamEntry",
    "VitalsEntry",
]
