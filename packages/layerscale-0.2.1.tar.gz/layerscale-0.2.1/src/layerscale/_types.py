from __future__ import annotations

from typing import TYPE_CHECKING, Union

import httpx
from typing_extensions import TypedDict

if TYPE_CHECKING:
    pass


class NotGiven:
    """Sentinel for parameters the caller didn't pass.

    Useful when ``None`` is a meaningful value. Compare with ``is NOT_GIVEN``
    or check with ``isinstance(x, NotGiven)``.
    """

    def __bool__(self) -> bool:
        return False

    def __repr__(self) -> str:
        return "NOT_GIVEN"


NOT_GIVEN = NotGiven()


Timeout = Union[float, httpx.Timeout, None]
Headers = dict[str, str]


class RequestOptions(TypedDict, total=False):
    """Per-request overrides. All fields optional.

    - ``headers``: extra headers merged on top of client defaults
    - ``timeout``: override the default request timeout
    - ``max_retries``: override the client default retry count
    """

    headers: Headers
    timeout: Timeout
    max_retries: int


__all__ = [
    "NOT_GIVEN",
    "Headers",
    "NotGiven",
    "RequestOptions",
    "Timeout",
]
