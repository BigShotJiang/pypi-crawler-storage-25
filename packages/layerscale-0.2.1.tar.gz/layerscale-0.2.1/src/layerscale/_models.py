from __future__ import annotations

from pydantic import BaseModel as _PydanticBaseModel, ConfigDict


class BaseModel(_PydanticBaseModel):
    """Shared base for all response models.

    ``extra="allow"`` keeps forward compatibility if the server adds new
    fields before this SDK is updated — unknown fields are preserved rather
    than rejected.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)


__all__ = ["BaseModel"]
