from __future__ import annotations

from typing import Any, Optional

import httpx


class LayerScaleError(Exception):
    """Base class for all LayerScale SDK exceptions."""


class APIError(LayerScaleError):
    """Raised when the API returns any non-2xx response.

    Use :class:`APIStatusError` subclasses for specific HTTP status codes.
    """

    message: str
    request: Optional[httpx.Request]
    body: Any

    def __init__(
        self,
        message: str,
        *,
        request: Optional[httpx.Request] = None,
        body: Any = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.request = request
        self.body = body


class APIConnectionError(APIError):
    """Network-level failure (DNS, refused connection, TLS, etc.)."""

    def __init__(
        self,
        *,
        message: str = "Connection error.",
        request: Optional[httpx.Request] = None,
        body: Any = None,
    ) -> None:
        super().__init__(message, request=request, body=body)


class APITimeoutError(APIConnectionError):
    def __init__(self, request: Optional[httpx.Request] = None) -> None:
        super().__init__(message="Request timed out.", request=request)


class APIStatusError(APIError):
    """Raised when the API returns a non-2xx response we could parse.

    Exposes the HTTP status code, the parsed error body (if JSON), and the
    underlying :class:`httpx.Response`.
    """

    response: httpx.Response
    status_code: int
    request_id: Optional[str]
    code: Optional[str]
    type: Optional[str]
    param: Optional[str]

    def __init__(self, message: str, *, response: httpx.Response, body: Any = None) -> None:
        super().__init__(message, request=response.request, body=body)
        self.response = response
        self.status_code = response.status_code
        self.request_id = response.headers.get("x-request-id")

        err = body.get("error") if isinstance(body, dict) else None
        if isinstance(err, dict):
            self.code = _coerce_str(err.get("code"))
            self.type = _coerce_str(err.get("type"))
            self.param = _coerce_str(err.get("param"))
        else:
            self.code = None
            self.type = None
            self.param = None


class BadRequestError(APIStatusError):
    pass


class AuthenticationError(APIStatusError):
    pass


class PermissionDeniedError(APIStatusError):
    pass


class NotFoundError(APIStatusError):
    pass


class ConflictError(APIStatusError):
    pass


class UnprocessableEntityError(APIStatusError):
    pass


class RateLimitError(APIStatusError):
    pass


class InternalServerError(APIStatusError):
    pass


_STATUS_MAP: dict[int, type[APIStatusError]] = {
    400: BadRequestError,
    401: AuthenticationError,
    403: PermissionDeniedError,
    404: NotFoundError,
    409: ConflictError,
    422: UnprocessableEntityError,
    429: RateLimitError,
}


def make_status_error(response: httpx.Response, body: Any) -> APIStatusError:
    """Build the correct :class:`APIStatusError` subclass for a response."""
    message = _extract_error_message(body) or response.reason_phrase or "API error"
    cls: type[APIStatusError]
    cls = InternalServerError if response.status_code >= 500 else _STATUS_MAP.get(response.status_code, APIStatusError)
    return cls(message, response=response, body=body)


def _extract_error_message(body: Any) -> Optional[str]:
    if not isinstance(body, dict):
        return None
    err = body.get("error")
    if isinstance(err, dict):
        msg = err.get("message")
        if isinstance(msg, str):
            return msg
    return None


def _coerce_str(value: Any) -> Optional[str]:
    if value is None:
        return None
    return str(value)


__all__ = [
    "APIConnectionError",
    "APIError",
    "APIStatusError",
    "APITimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ConflictError",
    "InternalServerError",
    "LayerScaleError",
    "NotFoundError",
    "PermissionDeniedError",
    "RateLimitError",
    "UnprocessableEntityError",
    "make_status_error",
]
