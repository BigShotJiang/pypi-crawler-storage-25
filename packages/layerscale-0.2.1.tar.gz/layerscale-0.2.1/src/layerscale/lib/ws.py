from __future__ import annotations

import json
from collections.abc import AsyncIterator, Iterator, Mapping
from typing import (
    Annotated,
    Any,
    Literal,
    Optional,
    Union,
)

from pydantic import Field, TypeAdapter
from typing_extensions import Self

from .._models import BaseModel
from ..types.sessions import (
    WsConnectedData,
    WsDataUpdatedData,
    WsErrorData,
    WsFlashReadyData,
    WsPushAckData,
)
from ..types.stream_data import StreamEntry

# ── Wire-level messages ────────────────────────────────────────────────────


class WsConnected(BaseModel):
    type: Literal["connected"]
    data: WsConnectedData


class WsPushAck(BaseModel):
    type: Literal["push_ack"]
    data: WsPushAckData


class WsFlashReady(BaseModel):
    type: Literal["flash_ready"]
    data: WsFlashReadyData


class WsDataUpdated(BaseModel):
    type: Literal["data_updated"]
    data: WsDataUpdatedData


class WsError(BaseModel):
    type: Literal["error"]
    data: WsErrorData


class WsPong(BaseModel):
    type: Literal["pong"]
    data: Optional[dict[str, Any]] = None


WsEvent = Annotated[
    Union[WsConnected, WsPushAck, WsFlashReady, WsDataUpdated, WsError, WsPong],
    Field(discriminator="type"),
]

_event_adapter: TypeAdapter[WsEvent] = TypeAdapter(WsEvent)


def _parse_frame(raw: Union[str, bytes]) -> Optional[WsEvent]:
    try:
        parsed = json.loads(raw)
    except (ValueError, TypeError):
        return None
    if not isinstance(parsed, dict):
        return None
    try:
        return _event_adapter.validate_python(parsed)
    except Exception:
        return None


# ── Sync ───────────────────────────────────────────────────────────────────


class SessionSocket:
    """Synchronous WebSocket wrapper for a LayerScale session.

    Usage::

        with client.sessions.stream(session_id) as ws:
            ws.push([candle])
            for event in ws:
                if isinstance(event, WsFlashReady):
                    print(event.data.value)

    The socket does NOT auto-reconnect — long-lived consumers should wrap it
    in their own backoff loop.
    """

    def __init__(self, url: str, *, headers: Mapping[str, str]) -> None:
        # Imported lazily so applications that never open a WS don't pay the cost.
        from websockets.sync.client import connect

        self._conn = connect(url, additional_headers=dict(headers))
        self._closed = False

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def __iter__(self) -> Iterator[WsEvent]:
        for raw in self._conn:
            event = _parse_frame(raw)
            if event is not None:
                yield event

    def push(self, data: list[StreamEntry]) -> None:
        self._conn.send(json.dumps({"type": "push", "data": data}))

    def ping(self) -> None:
        self._conn.send(json.dumps({"type": "ping"}))

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._conn.close()


# ── Async ──────────────────────────────────────────────────────────────────


class AsyncSessionSocket:
    """Async WebSocket wrapper.

    Usage::

        async with client.sessions.stream(session_id) as ws:
            await ws.push([candle])
            async for event in ws:
                ...
    """

    def __init__(self, url: str, *, headers: Mapping[str, str]) -> None:
        self._url = url
        self._headers = dict(headers)
        self._conn: Any = None
        self._closed = False

    async def connect(self) -> None:
        if self._conn is not None:
            return
        from websockets.asyncio.client import connect

        self._conn = await connect(self._url, additional_headers=self._headers)

    async def __aenter__(self) -> Self:
        await self.connect()
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.close()

    async def __aiter__(self) -> AsyncIterator[WsEvent]:
        if self._conn is None:
            await self.connect()
        assert self._conn is not None
        async for raw in self._conn:
            event = _parse_frame(raw)
            if event is not None:
                yield event

    async def push(self, data: list[StreamEntry]) -> None:
        if self._conn is None:
            await self.connect()
        assert self._conn is not None
        await self._conn.send(json.dumps({"type": "push", "data": data}))

    async def ping(self) -> None:
        if self._conn is None:
            await self.connect()
        assert self._conn is not None
        await self._conn.send(json.dumps({"type": "ping"}))

    async def close(self) -> None:
        if self._closed or self._conn is None:
            self._closed = True
            return
        self._closed = True
        await self._conn.close()


__all__ = [
    "AsyncSessionSocket",
    "SessionSocket",
    "WsConnected",
    "WsDataUpdated",
    "WsError",
    "WsEvent",
    "WsFlashReady",
    "WsPong",
    "WsPushAck",
]
