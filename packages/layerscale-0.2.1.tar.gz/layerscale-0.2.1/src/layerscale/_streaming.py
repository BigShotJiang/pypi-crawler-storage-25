from __future__ import annotations

import json
from collections.abc import AsyncIterator, Iterator
from typing import (
    Any,
    Callable,
    Generic,
    Optional,
    TypeVar,
)

import httpx
from typing_extensions import Self

_T = TypeVar("_T")


class SSEEvent:
    __slots__ = ("event", "data")

    def __init__(self, event: Optional[str], data: str) -> None:
        self.event = event
        self.data = data


def _iter_sse_lines(raw_lines: Iterator[str]) -> Iterator[SSEEvent]:
    current_event: Optional[str] = None
    data_lines: list[str] = []

    for line in raw_lines:
        # Strip the single trailing \r httpx leaves when servers use \r\n framing.
        if line.endswith("\r"):
            line = line[:-1]

        if line == "":
            if data_lines:
                yield SSEEvent(current_event, "\n".join(data_lines))
                current_event = None
                data_lines = []
            continue

        if line.startswith(":"):
            continue  # comment / heartbeat

        if line.startswith("event: "):
            current_event = line[7:].strip()
        elif line == "event:":
            current_event = ""
        elif line.startswith("data: "):
            data_lines.append(line[6:])
        elif line == "data:":
            data_lines.append("")

    if data_lines:
        yield SSEEvent(current_event, "\n".join(data_lines))


async def _aiter_sse_lines(raw_lines: AsyncIterator[str]) -> AsyncIterator[SSEEvent]:
    current_event: Optional[str] = None
    data_lines: list[str] = []

    async for line in raw_lines:
        if line.endswith("\r"):
            line = line[:-1]

        if line == "":
            if data_lines:
                yield SSEEvent(current_event, "\n".join(data_lines))
                current_event = None
                data_lines = []
            continue

        if line.startswith(":"):
            continue

        if line.startswith("event: "):
            current_event = line[7:].strip()
        elif line == "event:":
            current_event = ""
        elif line.startswith("data: "):
            data_lines.append(line[6:])
        elif line == "data:":
            data_lines.append("")

    if data_lines:
        yield SSEEvent(current_event, "\n".join(data_lines))


# ── Stream wrappers ─────────────────────────────────────────────────────────


class Stream(Generic[_T]):
    """Iterator over decoded SSE events from a streaming HTTP response.

    The wrapped :class:`httpx.Response` is closed when this object is closed,
    exhausted, or exits a ``with`` block.
    """

    def __init__(self, response: httpx.Response, decoder: Callable[[SSEEvent], Optional[_T]]) -> None:
        self._response = response
        self._decoder = decoder
        self._iterator: Optional[Iterator[_T]] = None

    def __iter__(self) -> Iterator[_T]:
        return self._iter_decoded()

    def __next__(self) -> _T:
        if self._iterator is None:
            self._iterator = self._iter_decoded()
        return next(self._iterator)

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    def close(self) -> None:
        self._response.close()

    def _iter_decoded(self) -> Iterator[_T]:
        try:
            for sse in _iter_sse_lines(self._response.iter_lines()):
                decoded = self._decoder(sse)
                if decoded is _DONE_SENTINEL:
                    return
                if decoded is None:
                    continue
                yield decoded
        finally:
            self._response.close()


class AsyncStream(Generic[_T]):
    """Async-iterator variant of :class:`Stream`."""

    def __init__(self, response: httpx.Response, decoder: Callable[[SSEEvent], Optional[_T]]) -> None:
        self._response = response
        self._decoder = decoder
        self._iterator: Optional[AsyncIterator[_T]] = None

    def __aiter__(self) -> AsyncIterator[_T]:
        return self._aiter_decoded()

    async def __anext__(self) -> _T:
        if self._iterator is None:
            self._iterator = self._aiter_decoded()
        return await self._iterator.__anext__()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.close()

    async def close(self) -> None:
        await self._response.aclose()

    async def _aiter_decoded(self) -> AsyncIterator[_T]:
        try:
            async for sse in _aiter_sse_lines(self._response.aiter_lines()):
                decoded = self._decoder(sse)
                if decoded is _DONE_SENTINEL:
                    return
                if decoded is None:
                    continue
                yield decoded
        finally:
            await self._response.aclose()


# ── Sentinels ──────────────────────────────────────────────────────────────

_DONE_SENTINEL: Any = object()


def mark_done() -> Any:
    """Return the sentinel that tells a Stream decoder to terminate."""
    return _DONE_SENTINEL


def parse_json(data: str) -> Any:
    return json.loads(data)


__all__ = [
    "AsyncStream",
    "SSEEvent",
    "Stream",
    "mark_done",
    "parse_json",
]
