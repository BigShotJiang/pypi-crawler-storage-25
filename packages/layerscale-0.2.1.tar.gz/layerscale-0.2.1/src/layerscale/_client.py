from __future__ import annotations

from collections.abc import Mapping
from functools import cached_property
from typing import Any, Optional, Union

import httpx

from ._base_client import DEFAULT_MAX_RETRIES, AsyncAPIClient, SyncAPIClient
from ._types import NOT_GIVEN, NotGiven, Timeout
from .resources import (
    AsyncChat,
    AsyncCompletions,
    AsyncHealth,
    AsyncMessages,
    AsyncModels,
    AsyncSessions,
    Chat,
    Completions,
    Health,
    Messages,
    Models,
    Sessions,
)


class LayerScale:
    """Synchronous client for the LayerScale inference server.

    Example::

        from layerscale import LayerScale

        client = LayerScale(base_url="http://localhost:8080")
        answer = client.sessions.query(session_id, prompt="What's the trend?")
    """

    _client: SyncAPIClient

    def __init__(
        self,
        base_url: str,
        *,
        api_key: Optional[str] = None,
        timeout: Union[Timeout, NotGiven] = NOT_GIVEN,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Mapping[str, str]] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        self._client = SyncAPIClient(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
            http_client=http_client,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> LayerScale:
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()

    # ── Resources ──────────────────────────────────────────────────────────

    @cached_property
    def health(self) -> Health:
        return Health(self._client)

    @cached_property
    def models(self) -> Models:
        return Models(self._client)

    @cached_property
    def chat(self) -> Chat:
        return Chat(self._client)

    @cached_property
    def completions(self) -> Completions:
        return Completions(self._client)

    @cached_property
    def messages(self) -> Messages:
        return Messages(self._client)

    @cached_property
    def sessions(self) -> Sessions:
        return Sessions(self._client)


class AsyncLayerScale:
    """Asynchronous client for the LayerScale inference server.

    Example::

        from layerscale import AsyncLayerScale

        async with AsyncLayerScale(base_url="http://localhost:8080") as client:
            answer = await client.sessions.query(session_id, prompt="...")
    """

    _client: AsyncAPIClient

    def __init__(
        self,
        base_url: str,
        *,
        api_key: Optional[str] = None,
        timeout: Union[Timeout, NotGiven] = NOT_GIVEN,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Optional[Mapping[str, str]] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        self._client = AsyncAPIClient(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
            http_client=http_client,
        )

    async def close(self) -> None:
        await self._client.close()

    async def __aenter__(self) -> AsyncLayerScale:
        return self

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.close()

    # ── Resources ──────────────────────────────────────────────────────────

    @cached_property
    def health(self) -> AsyncHealth:
        return AsyncHealth(self._client)

    @cached_property
    def models(self) -> AsyncModels:
        return AsyncModels(self._client)

    @cached_property
    def chat(self) -> AsyncChat:
        return AsyncChat(self._client)

    @cached_property
    def completions(self) -> AsyncCompletions:
        return AsyncCompletions(self._client)

    @cached_property
    def messages(self) -> AsyncMessages:
        return AsyncMessages(self._client)

    @cached_property
    def sessions(self) -> AsyncSessions:
        return AsyncSessions(self._client)


__all__ = ["AsyncLayerScale", "LayerScale"]
