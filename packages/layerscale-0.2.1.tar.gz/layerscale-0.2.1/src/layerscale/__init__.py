"""Python client for the LayerScale inference server."""

from ._client import AsyncLayerScale, LayerScale
from ._exceptions import (
    APIConnectionError,
    APIError,
    APIStatusError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    ConflictError,
    InternalServerError,
    LayerScaleError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableEntityError,
)
from ._streaming import AsyncStream, Stream
from ._types import NOT_GIVEN, NotGiven, RequestOptions
from ._version import __version__
from .lib.ws import (
    AsyncSessionSocket,
    SessionSocket,
    WsConnected,
    WsDataUpdated,
    WsError,
    WsEvent,
    WsFlashReady,
    WsPong,
    WsPushAck,
)

__all__ = [
    "APIConnectionError",
    "APIError",
    "APIStatusError",
    "APITimeoutError",
    "AsyncLayerScale",
    "AsyncSessionSocket",
    "AsyncStream",
    "AuthenticationError",
    "BadRequestError",
    "ConflictError",
    "InternalServerError",
    "LayerScale",
    "LayerScaleError",
    "NOT_GIVEN",
    "NotFoundError",
    "NotGiven",
    "PermissionDeniedError",
    "RateLimitError",
    "RequestOptions",
    "SessionSocket",
    "Stream",
    "UnprocessableEntityError",
    "WsConnected",
    "WsDataUpdated",
    "WsError",
    "WsEvent",
    "WsFlashReady",
    "WsPong",
    "WsPushAck",
    "__version__",
]
