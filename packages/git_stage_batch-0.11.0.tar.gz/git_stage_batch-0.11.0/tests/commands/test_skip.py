"""Tests for skip command."""

import subprocess

import pytest

from git_stage_batch.commands.skip import command_skip, command_skip_line
from git_stage_batch.commands.start import command_start
from git_stage_batch.data.hunk_tracking import fetch_next_change
from git_stage_batch.data.line_state import load_line_changes_from_state
from git_stage_batch.exceptions import CommandError
from git_stage_batch.utils.file_io import read_text_file_contents
from git_stage_batch.utils.paths import get_processed_skip_ids_file_path


def _prepare_single_line_change(repo, file_name="test.txt"):
    test_file = repo / file_name
    test_file.write_text("base\n")
    subprocess.run(["git", "add", file_name], check=True, cwd=repo, capture_output=True)
    subprocess.run(["git", "commit", "-m", f"Add {file_name}"], check=True, cwd=repo, capture_output=True)
    test_file.write_text("base\nselected\n")
    command_start()
    fetch_next_change()
    return test_file


@pytest.fixture
def temp_git_repo(tmp_path, monkeypatch):
    """Create a temporary git repository for testing."""
    repo = tmp_path / "test_repo"
    repo.mkdir()
    monkeypatch.chdir(repo)

    subprocess.run(["git", "init"], check=True, cwd=repo, capture_output=True)
    subprocess.run(["git", "config", "user.name", "Test User"], check=True, cwd=repo, capture_output=True)
    subprocess.run(["git", "config", "user.email", "test@example.com"], check=True, cwd=repo, capture_output=True)

    # Create initial commit
    (repo / "README.md").write_text("# Test\n")
    subprocess.run(["git", "add", "README.md"], check=True, cwd=repo, capture_output=True)
    subprocess.run(["git", "commit", "-m", "Initial commit"], check=True, cwd=repo, capture_output=True)

    return repo


class TestCommandSkip:
    """Tests for skip command."""

    def test_skip_marks_hunk_as_processed(self, temp_git_repo, capsys):
        """Test that skip marks a hunk as processed without staging it."""
        # Modify README
        readme = temp_git_repo / "README.md"
        readme.write_text("# Test\nNew content\n")

        command_start()
        command_skip()

        # Check that changes remain unstaged.
        result = subprocess.run(
            ["git", "diff", "--cached"],
            check=True,
            cwd=temp_git_repo,
            capture_output=True,
            text=True,
        )
        assert result.stdout == ""  # No staged changes

        # Check that changes still exist in working tree
        result = subprocess.run(
            ["git", "diff"],
            check=True,
            cwd=temp_git_repo,
            capture_output=True,
            text=True,
        )
        assert "+New content" in result.stdout

        captured = capsys.readouterr()
        assert "Hunk skipped" in captured.err

    def test_skip_no_changes(self, temp_git_repo, capsys):
        """Test skip when no more hunks remain."""
        # Create a change
        readme = temp_git_repo / "README.md"
        readme.write_text("# Test\nModified\n")

        # Start session and skip the change
        command_start()
        command_skip()
        capsys.readouterr()  # Clear output

        # Try to skip again - should show "No more hunks"
        command_skip()

        captured = capsys.readouterr()
        assert "No more hunks to process" in captured.err

    def test_skip_then_include_next(self, temp_git_repo, capsys):
        """Test skipping one hunk then including the next."""
        # Create and commit two files
        file1 = temp_git_repo / "file1.txt"
        file1.write_text("original 1\n")
        file2 = temp_git_repo / "file2.txt"
        file2.write_text("original 2\n")
        subprocess.run(["git", "add", "file1.txt", "file2.txt"], check=True, cwd=temp_git_repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Add files"], check=True, cwd=temp_git_repo, capture_output=True)

        # Modify both files
        file1.write_text("modified 1\n")
        file2.write_text("modified 2\n")

        # Start session
        command_start()

        # Skip first hunk
        command_skip()
        captured = capsys.readouterr()
        assert "file1.txt" in captured.err

        # Second hunk should now be available
        # (Would normally use command_include here but we're just testing skip)


class TestCommandSkipLine:
    """Tests for skip --line command."""

    def test_skip_line_requires_selected_hunk(self, temp_git_repo):
        """Test that skip --line requires an active hunk."""
        with pytest.raises(CommandError):
            command_skip_line("1")

    def test_skip_line_rejects_mixed_valid_and_invalid_ids(self, temp_git_repo):
        """skip --line should reject the selection when any ID is stale."""
        _prepare_single_line_change(temp_git_repo)

        with pytest.raises(CommandError) as exc_info:
            command_skip_line("1,99")

        assert "Line selection 1,99 is not valid for test.txt." in exc_info.value.message
        skip_ids_content = read_text_file_contents(get_processed_skip_ids_file_path()).strip()
        assert skip_ids_content == ""

    def test_skip_file_line_rejects_mixed_valid_and_invalid_ids(self, temp_git_repo):
        """skip --file --line should reject when any ID is stale."""
        _prepare_single_line_change(temp_git_repo)

        with pytest.raises(CommandError) as exc_info:
            command_skip_line("1,99", file="test.txt")

        assert "Line selection 1,99 is not valid for test.txt." in exc_info.value.message
        skip_ids_content = read_text_file_contents(get_processed_skip_ids_file_path()).strip()
        assert skip_ids_content == ""

    def test_skip_line_marks_single_addition(self, temp_git_repo):
        """Test skipping a single added line advances past that selection."""
        readme = temp_git_repo / "README.md"
        readme.write_text("# Test\nNew line\n")

        command_start()
        fetch_next_change()

        command_skip_line("1")

        skip_ids_content = read_text_file_contents(get_processed_skip_ids_file_path()).strip()
        assert skip_ids_content == ""
        assert load_line_changes_from_state() is None

    def test_skip_line_marks_single_deletion(self, temp_git_repo):
        """Test skipping a single deleted line advances past that selection."""
        readme = temp_git_repo / "README.md"
        readme.write_text("")

        command_start()
        fetch_next_change()

        command_skip_line("1")

        skip_ids_content = read_text_file_contents(get_processed_skip_ids_file_path()).strip()
        assert skip_ids_content == ""
        assert load_line_changes_from_state() is None

    def test_skip_line_with_range(self, temp_git_repo):
        """Test skipping a full range advances past that selection."""
        readme = temp_git_repo / "README.md"
        readme.write_text("# Test\nLine 1\nLine 2\nLine 3\n")

        command_start()
        fetch_next_change()

        command_skip_line("1-3")

        skip_ids_content = read_text_file_contents(get_processed_skip_ids_file_path()).strip()
        assert skip_ids_content == ""
        assert load_line_changes_from_state() is None

    def test_skip_line_partial_selection(self, temp_git_repo):
        """Test skipping only some lines from a hunk."""
        readme = temp_git_repo / "README.md"
        readme.write_text("# Test\nLine 1\nLine 2\nLine 3\n")

        # Cache the hunk
        command_start()
        fetch_next_change()

        # Skip only line 1
        command_skip_line("1")

        # Check that only line 1 was recorded
        skip_ids_content = read_text_file_contents(get_processed_skip_ids_file_path()).strip()
        skip_ids = skip_ids_content.split("\n") if skip_ids_content else []
        assert skip_ids == ["1"]

        line_changes = load_line_changes_from_state()
        assert line_changes is not None
        visible_ids = [line.id for line in line_changes.lines if line.id is not None]
        assert visible_ids == [2, 3]

    def test_skip_line_advances_when_selection_is_fully_skipped(self, temp_git_repo):
        """Skipping every shown line should advance to the next hunk."""
        file1 = temp_git_repo / "file1.txt"
        file2 = temp_git_repo / "file2.txt"
        file1.write_text("original 1\n")
        file2.write_text("original 2\n")
        subprocess.run(["git", "add", "file1.txt", "file2.txt"], check=True, cwd=temp_git_repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Add files"], check=True, cwd=temp_git_repo, capture_output=True)

        file1.write_text("modified 1\n")
        file2.write_text("modified 2\n")

        command_start()
        fetch_next_change()

        command_skip_line("1-2")

        line_changes = load_line_changes_from_state()
        assert line_changes is not None
        assert line_changes.path == "file2.txt"

    def test_skip_line_accumulates_ids(self, temp_git_repo):
        """Test that multiple skip --line calls accumulate."""
        readme = temp_git_repo / "README.md"
        readme.write_text("# Test\nLine 1\nLine 2\nLine 3\n")

        # Cache the hunk
        command_start()
        fetch_next_change()

        # Skip line 1
        command_skip_line("1")

        # Skip line 3
        command_skip_line("3")

        # Check that both IDs were recorded
        skip_ids_content = read_text_file_contents(get_processed_skip_ids_file_path()).strip()
        skip_ids = skip_ids_content.split("\n") if skip_ids_content else []
        assert set(skip_ids) == {"1", "3"}
