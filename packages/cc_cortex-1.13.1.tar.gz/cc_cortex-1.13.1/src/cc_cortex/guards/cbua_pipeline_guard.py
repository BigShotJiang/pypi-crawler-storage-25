"""cc_cortex.guards.cbua_pipeline_guard — Hardened CBUA pipeline enforcement.

Closes text-only CBUA gaps via PostToolUse state tracking + context injection.
Uses StateStore for cross-tick persistence (hooks run as subprocess per call).

@module cbua_pipeline_guard
@responsibility Enforce CBUA B1/C1/U1/A4/A5 steps. Uses behavioral signals
    (edit count, read count, agent dispatches) + text markers as secondary.
@dependencies cc_cortex.guards.base, cc_cortex.core.state_store
@exports CbuaPipelineGuard

CC ceiling notes:
- L1 (Agent spawn unmonitored): red team dispatch can only be DETECTED
  (by Agent tool name), not ENFORCED. When L1 unlocks → upgrade to enforce.
- L4 (Hook can't read conversation): guard scans tool_input/tool_result only,
  not Claude's reasoning text. When L4 unlocks → scan full response.
- L6 (PostToolUse can't DENY): guard is COGNITIVE (warn only).
  When L6 unlocks → upgrade A5 red-team-not-dispatched to QUALITY (deny).
"""

from __future__ import annotations

import json
import os
import re
from typing import Optional

from cc_cortex.guards.base import (
    BaseGuard,
    GuardCategory,
    GuardContext,
    GuardResult,
)

# ── Detection patterns ──────────────────────────────────────

_B1_MARKERS = re.compile(
    r"B1[_\s]*(根因|甜蜜點|策略|root|sweet|strategy)"
    r"|根因.*甜蜜點.*策略",
    re.IGNORECASE,
)

_C1_MARKERS = re.compile(
    r"我知道.*我不知道.*我假設"
    r"|known.*unknown.*assumed",
    re.IGNORECASE,
)

_U1_MARKERS = re.compile(
    r"反例|counter.?example|edge.?case|what.?if"
    r"|失敗場景|failure.?mode",
    re.IGNORECASE,
)

# A4: only match in Agent/conversational context, not code content
_A4_ASK_PATTERNS = re.compile(
    r"要做嗎|要不要繼續|需要我.*嗎|要繼續嗎",
)

_A5_REDTEAM = re.compile(
    r"紅隊|red.?team|壓測|pressure.?test",
    re.IGNORECASE,
)

_WIREDO_TABLE = re.compile(
    r"W.*Wired.*I.*Inherited|WIREDO|W/I/R/E/D/O",
    re.IGNORECASE,
)

# StateStore namespace
_NAMESPACE = "cbua_pipeline"


def _state_path(cache_dir: str, session_id: str) -> str:
    """Path to persisted guard state."""
    ns_dir = os.path.join(cache_dir, _NAMESPACE)
    os.makedirs(ns_dir, exist_ok=True)
    sid = session_id or "default"
    return os.path.join(ns_dir, f"{sid}.json")


def _load_state(cache_dir: str, session_id: str) -> dict:
    """Load persisted state. Returns empty dict on failure."""
    try:
        path = _state_path(cache_dir, session_id)
        if os.path.isfile(path):
            with open(path, encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save_state(cache_dir: str, session_id: str, state: dict) -> None:
    """Persist state to disk."""
    try:
        path = _state_path(cache_dir, session_id)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(state, f)
    except Exception:
        pass


class CbuaPipelineGuard(BaseGuard):
    """PostToolUse: enforce CBUA pipeline steps via state tracking.

    State persisted to StateStore (survives subprocess restarts).
    Uses behavioral signals (edit/read count, agent dispatch) + text markers.
    """

    name = "cbua_pipeline"
    category = GuardCategory.COGNITIVE

    def check(self, ctx: GuardContext) -> Optional[GuardResult]:
        """PreToolUse: no-op."""
        return None

    def on_post_tool(self, ctx: GuardContext) -> Optional[GuardResult]:
        """PostToolUse: scan for CBUA compliance evidence."""
        if not ctx.cache_dir:
            return None

        # Load persisted state
        state = _load_state(ctx.cache_dir, ctx.session_id)
        complexity = state.get("complexity", "")
        redteam_required = state.get("redteam_required", False)

        # Load C0 if not yet loaded or periodically reclassify
        edit_count = state.get("edit_count", 0)
        if not complexity or (edit_count > 0 and edit_count % 20 == 0):
            complexity, redteam_required = self._classify(
                ctx.cache_dir, ctx.session_id,
            )
            state["complexity"] = complexity
            state["redteam_required"] = redteam_required

        # Simple → skip
        if complexity == "simple":
            _save_state(ctx.cache_dir, ctx.session_id, state)
            return None

        # Track behavioral signals
        if ctx.tool_name in ("Edit", "Write", "NotebookEdit"):
            state["edit_count"] = edit_count + 1
            edit_count += 1
        if ctx.tool_name in ("Read", "Glob", "Grep"):
            state["read_count"] = state.get("read_count", 0) + 1
        if ctx.tool_name == "Agent":
            state["agent_count"] = state.get("agent_count", 0) + 1

        # Scan text markers (secondary signal)
        text = self._get_scannable_text(ctx)
        if _B1_MARKERS.search(text):
            state["b1_shown"] = True
        if _C1_MARKERS.search(text):
            state["c1_shown"] = True
        if _U1_MARKERS.search(text):
            state["u1_shown"] = True
        if _WIREDO_TABLE.search(text):
            state["wiredo_shown"] = True
        if ctx.tool_name == "Agent" and _A5_REDTEAM.search(text):
            state["redteam_dispatched"] = True

        # A4: only check on Agent tool (not code edits — avoid false positives)
        if ctx.tool_name == "Agent" and _A4_ASK_PATTERNS.search(text):
            state["ask_violations"] = state.get("ask_violations", 0) + 1
            _save_state(ctx.cache_dir, ctx.session_id, state)
            return GuardResult.allow(
                context=(
                    "⛔ A4 違規：信心 ≥70% 直接做，<70% 升 B1/B2 自己決策。"
                ),
            )

        # Save state before generating reminder
        _save_state(ctx.cache_dir, ctx.session_id, state)

        # Generate reminders
        return self._generate_reminder(state, complexity, redteam_required)

    def _classify(
        self, cache_dir: str, session_id: str,
    ) -> tuple[str, bool]:
        """Load or reclassify C0. Fail-safe: complicated."""
        try:
            from cc_cortex.c0_router import C0Router
            result = C0Router().load(cache_dir, session_id)
            if result:
                return result.complexity, result.redteam_required
        except Exception:
            pass
        return "complicated", False

    @staticmethod
    def _get_scannable_text(ctx: GuardContext) -> str:
        """Extract text from tool input + result."""
        parts: list[str] = []
        if isinstance(ctx.tool_input, dict):
            for v in ctx.tool_input.values():
                if isinstance(v, str) and len(v) < 2000:
                    parts.append(v)
        # GuardContext field is `tool_result`, not `tool_output`
        if hasattr(ctx, "tool_result") and isinstance(ctx.tool_result, str):
            parts.append(ctx.tool_result[:2000])
        return " ".join(parts)

    @staticmethod
    def _generate_reminder(
        state: dict, complexity: str, redteam_required: bool,
    ) -> Optional[GuardResult]:
        """Generate reminders based on accumulated state."""
        edit_count = state.get("edit_count", 0)
        missing: list[str] = []

        # B1: after 3+ edits without markers (all Complicated+)
        if not state.get("b1_shown") and edit_count >= 3:
            missing.append("B1 結構思考未見（根因→甜蜜點→策略）")

        # C1: after 5+ edits (Complex+ only)
        if (
            not state.get("c1_shown")
            and edit_count >= 5
            and complexity in ("complex", "chaotic")
        ):
            missing.append("C1 情報盤點未見（我知道/不知道/假設）")

        # U1: after 8+ edits (Complex+ only)
        if (
            not state.get("u1_shown")
            and edit_count >= 8
            and complexity in ("complex", "chaotic")
        ):
            missing.append("U1 反例攻擊未見")

        # A5: redteam required but not dispatched
        if (
            redteam_required
            and not state.get("redteam_dispatched")
            and edit_count >= 10
        ):
            missing.append("⛔ A5 紅隊未派出")

        # WIREDO: after 5+ edits
        if not state.get("wiredo_shown") and edit_count >= 5:
            missing.append(
                f"📐 WIREDO 未見（{edit_count} edits）"
            )

        if not missing:
            return None

        severity = "⚠" if len(missing) <= 2 else "⛔"
        return GuardResult.allow(
            context=(
                f"{severity} CBUA ({complexity}, {edit_count} edits):\n"
                + "\n".join(f"  - {m}" for m in missing)
            ),
        )
