---
name: mode
description: Use when the user wants to switch work modes (engineering, judge, evolution, creative, system, persona, research). Triggers on keywords like "mode", "模式", "切換模式".
user-invocable: true
disable-model-invocation: true
---

# /mode — 工作模式切換

根據參數 `$ARGUMENTS` 執行對應操作：

## 參數對照

| 參數 | 動作 |
|------|------|
| `eng` | 工程模式：Plan-Solve + Decompose，改完必驗 |
| `judge` | 判斷模式：元認知+因果推理+道德直覺三層 |
| `evo` | 進化模式：研究→對比→沉澱→更新規則鏈 |
| `create` | 創作模式：Skeleton 骨架先行，類比輔助 |
| `sys` | 系統模式：假設→驗證→縮小範圍，三敗停損 |
| `persona` | 人格模式：五引擎架構，情緒可極端行為不偏激 |
| `research` | 研究模式：ToT 多路徑 + Self-Refine + CoVe |
| `list` | 列出所有可用模式（讀 `_AI_BRAIN/00_System/modes/_index.md`） |
| `status` | 顯示當前模式 + 已載入規則 |
| `<名> full` | 深入模式：載入相關全文規則 |

## 執行流程
1. 解析 `$ARGUMENTS` 取得模式名
2. 讀取 `_AI_BRAIN/00_System/modes/<名>.md` 摘要層（~2K）
3. 若帶 `full` 則額外載入摘要中引用的全文規則
4. 顯示 `⚙ 模式：<名稱>` 確認切換

## 自動偵測
用戶意圖明確時自動切換（說「決定」→judge，說「排查」→sys）

索引：`_AI_BRAIN/00_System/modes/_index.md`
