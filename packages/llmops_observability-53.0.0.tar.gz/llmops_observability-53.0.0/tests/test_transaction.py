import json

import pytest

import llmops_observability.trace_manager as trace_manager
import llmops_observability.outbound_urllib as outbound_urllib
from llmops_observability.outbound_urllib import (
    disable_urllib_instrumentation,
    enable_urllib_instrumentation,
)
from llmops_observability.trace_manager import TraceManager
from llmops_observability.transaction import (
    TRANSACTION_SPAN_TYPE,
    end_transaction,
    get_open_transaction_ids,
    start_transaction,
    track_transaction,
    transaction,
)


@pytest.fixture(autouse=True)
def _transaction_env(monkeypatch):
    monkeypatch.setenv("AWS_SQS_URL", "https://example.com/test-queue")
    monkeypatch.setenv("PROJECT_ID", "test_project")
    monkeypatch.setenv("ENV", "test")
    TraceManager._active["trace_id"] = None
    TraceManager._active["trace_config"] = None
    TraceManager._active["start_time"] = None
    TraceManager._active["spans"] = []
    TraceManager._active["stack"] = []
    TraceManager._active["finalized_trace_id"] = None
    TraceManager._active["finalized_timestamp"] = None
    disable_urllib_instrumentation()
    yield
    disable_urllib_instrumentation()


def test_start_end_transaction_creates_unique_span_and_correlation():
    TraceManager.start_trace(name="tx_trace")
    tx1 = start_transaction(name="tx_1")
    tx2 = start_transaction(name="tx_2")
    assert tx1 is not None and tx2 is not None
    assert tx1 != tx2
    assert get_open_transaction_ids()

    assert end_transaction(tx2) is True
    assert end_transaction(tx1) is True

    tx_spans = [s for s in TraceManager._active["spans"] if s.span_type == TRANSACTION_SPAN_TYPE]
    assert len(tx_spans) == 2
    assert tx_spans[0].span_id != tx_spans[1].span_id


def test_double_end_guardrail_returns_false():
    TraceManager.start_trace(name="tx_double_end")
    txid = start_transaction(name="tx_double")
    assert txid is not None
    assert end_transaction(txid) is True
    assert end_transaction(txid) is False


def test_missing_end_visible_in_open_registry():
    TraceManager.start_trace(name="tx_missing_end")
    txid = start_transaction(name="tx_missing")
    assert txid is not None
    open_ids = get_open_transaction_ids()
    assert txid in open_ids


def test_transaction_context_manager_exception_flow():
    TraceManager.start_trace(name="tx_ctx")
    with pytest.raises(ValueError, match="boom"):
        with transaction(name="tx_context"):
            raise ValueError("boom")

    tx_spans = [s for s in TraceManager._active["spans"] if s.span_type == TRANSACTION_SPAN_TYPE]
    assert len(tx_spans) == 1
    assert tx_spans[0].status == "error"
    assert "boom" in (tx_spans[0].error or "")


def test_track_transaction_decorator_sync():
    TraceManager.start_trace(name="tx_deco")

    @track_transaction(name="wrapped_tx")
    def do_work():
        return "ok"

    assert do_work() == "ok"
    tx_spans = [s for s in TraceManager._active["spans"] if s.span_type == TRANSACTION_SPAN_TYPE]
    assert len(tx_spans) == 1
    assert tx_spans[0].span_name == "wrapped_tx"
    assert tx_spans[0].status == "success"


def test_integration_transaction_parent_child_with_outbound_urllib(monkeypatch):
    import urllib.request

    class DummyResponse:
        status_code = 200
        headers = {}

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            return False

        def read(self):
            return b"ok"

    def fake_urlopen(url, data=None, **kwargs):
        return DummyResponse()

    sent = []

    def _send(payload):
        sent.append(payload)
        return True

    TraceManager.start_trace(name="tx_outbound")
    monkeypatch.setattr(trace_manager, "is_sqs_enabled", lambda: True)
    monkeypatch.setattr(trace_manager, "send_to_sqs", _send)
    enable_urllib_instrumentation()
    monkeypatch.setattr(outbound_urllib, "_original_urlopen", fake_urlopen)

    txid = start_transaction(name="lambda_transaction")
    assert txid is not None
    urllib.request.urlopen("https://example.com/transaction-lambda?token=secret")
    assert end_transaction(txid) is True

    spans = TraceManager._active["spans"]
    tx_span = next(s for s in spans if s.span_type == TRANSACTION_SPAN_TYPE)
    http_span = next(s for s in spans if s.metadata.get("http.client.library") == "urllib")
    assert http_span.parent_span_id == tx_span.span_id

    assert TraceManager.finalize_and_send(trace_name="tx_outbound") is True
    assert sent
    payload = sent[-1] if isinstance(sent[-1], dict) else json.loads(sent[-1])
    assert payload["spans"]
