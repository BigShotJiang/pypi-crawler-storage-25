import pytest
import json

from llmops_observability.crawl import (
    CRAWL_EVENT_SPAN_TYPE,
    CRAWL_PAGE_SPAN_TYPE,
    CRAWL_SESSION_SPAN_TYPE,
    crawl_session,
    end_crawl_session,
    record_crawl_event,
    record_crawl_page,
    start_crawl_session,
)
import llmops_observability.trace_manager as trace_manager
from llmops_observability.trace_manager import TraceManager


@pytest.fixture(autouse=True)
def _crawl_trace_env(monkeypatch):
    monkeypatch.setenv("AWS_SQS_URL", "https://example.com/test-queue")
    monkeypatch.setenv("PROJECT_ID", "test_project")
    monkeypatch.setenv("ENV", "test")
    TraceManager._active["trace_id"] = None
    TraceManager._active["trace_config"] = None
    TraceManager._active["start_time"] = None
    TraceManager._active["spans"] = []
    TraceManager._active["stack"] = []
    TraceManager._active["finalized_trace_id"] = None
    TraceManager._active["finalized_timestamp"] = None
    yield


def test_crawl_no_trace_returns_none():
    assert start_crawl_session(query="q") is None
    assert record_crawl_page(url="https://a.com") is None


def test_crawl_session_pages_and_summary():
    TraceManager.start_trace(name="crawl_test")
    sid = start_crawl_session(name="agent_crawl", provider="scrapy", query="weather", metadata={"safe": "x"})
    assert sid is not None
    assert TraceManager.get_current_parent_span_id() == sid

    p1 = record_crawl_page(
        url="https://news.example.com/a?api_key=secret&q=1",
        status_code=200,
        latency_ms=50,
    )
    p2 = record_crawl_page(url="https://news.example.com/b", status_code=404, latency_ms=30)

    assert p1 and p2
    pages = [s for s in TraceManager._active["spans"] if s.span_type == CRAWL_PAGE_SPAN_TYPE]
    assert len(pages) == 2
    assert pages[0].parent_span_id == sid
    assert "api_key=%5BREDACTED%5D" in (pages[0].metadata or {}).get("crawl.url", "")
    assert pages[1].status == "error" or pages[1].metadata.get("crawl.success") is False

    end_crawl_session(sid, metadata={"note": "done"})
    assert TraceManager.get_current_parent_span_id() is None

    sessions = [s for s in TraceManager._active["spans"] if s.span_type == CRAWL_SESSION_SPAN_TYPE]
    assert len(sessions) == 1
    sess = sessions[0]
    assert sess.span_id == sid
    assert sess.metadata.get("crawl.pages_ok") == 1
    assert sess.metadata.get("crawl.pages_fail") == 1


def test_crawl_session_context_manager():
    TraceManager.start_trace(name="ctx")
    with crawl_session(provider="tavily", query="q") as sid:
        assert sid is not None
        record_crawl_page(url="https://x.com", status_code=200, latency_ms=1)
    sess = [s for s in TraceManager._active["spans"] if s.span_type == CRAWL_SESSION_SPAN_TYPE]
    assert len(sess) == 1


def test_record_crawl_page_redacts_metadata():
    TraceManager.start_trace(name="m")
    sid = start_crawl_session()
    record_crawl_page(
        url="https://z.com",
        status_code=200,
        metadata={"api_key": "hide-me"},
    )
    page = next(s for s in TraceManager._active["spans"] if s.span_type == CRAWL_PAGE_SPAN_TYPE)
    assert page.metadata.get("api_key") == "[REDACTED]"
    end_crawl_session(sid)


def test_crawl_event_telemetry_and_redacted_query():
    TraceManager.start_trace(name="event_trace")
    sid = start_crawl_session(provider="tavily", query={"query": "python", "api_key": "hide"})
    assert sid is not None

    eid = record_crawl_event(
        event_type="search_request",
        url="https://search.example.com?q=python&token=secret",
        query={"query": "python", "api_key": "secret"},
        status="ok",
        duration_ms=22,
        metadata={"authorization": "Bearer top-secret"},
    )
    assert eid is not None
    event = next(s for s in TraceManager._active["spans"] if s.span_type == CRAWL_EVENT_SPAN_TYPE)
    assert event.parent_span_id == sid
    assert event.metadata.get("crawl.url", "").find("%5BREDACTED%5D") >= 0
    assert event.metadata.get("crawl.query", {}).get("api_key") == "[REDACTED]"
    assert event.metadata.get("authorization") == "[REDACTED]"

    end_crawl_session(sid)
    sess = next(s for s in TraceManager._active["spans"] if s.span_type == CRAWL_SESSION_SPAN_TYPE)
    assert sess.metadata.get("crawl.events_total") == 1
    assert sess.metadata.get("crawl.events_fail") == 0


def test_crawl_partial_failures_keep_session_success():
    TraceManager.start_trace(name="partial_fail")
    sid = start_crawl_session(provider="mock", query="news")
    assert sid is not None

    record_crawl_page(url="https://docs.example.com/a", status_code=200, latency_ms=10)
    record_crawl_page(url="https://docs.example.com/b", status_code=503, latency_ms=40, error="upstream unavailable")
    record_crawl_event(
        event_type="rerank",
        status="failed",
        failure_reason="model timeout",
        duration_ms=120,
    )
    end_crawl_session(sid)

    pages = [s for s in TraceManager._active["spans"] if s.span_type == CRAWL_PAGE_SPAN_TYPE]
    sessions = [s for s in TraceManager._active["spans"] if s.span_type == CRAWL_SESSION_SPAN_TYPE]
    assert len(pages) == 2
    assert len(sessions) == 1
    session = sessions[0]
    # Session is complete even with partial failures.
    assert session.status == "success"
    assert session.metadata.get("crawl.pages_ok") == 1
    assert session.metadata.get("crawl.pages_fail") == 1
    assert session.metadata.get("crawl.events_total") == 3
    assert session.metadata.get("crawl.events_fail") == 2


def test_integration_mocked_provider_payload_fields(monkeypatch):
    sent = []

    def _send(payload):
        sent.append(payload)
        return True

    TraceManager.start_trace(name="mocked_provider")
    monkeypatch.setattr(trace_manager, "is_sqs_enabled", lambda: True)
    monkeypatch.setattr(trace_manager, "send_to_sqs", _send)

    # Mocked Tavily-like provider responses (success + partial failure).
    mocked_results = [
        {"url": "https://a.example.com/path?api_key=secret", "status_code": 200, "duration_ms": 41},
        {"url": "https://b.example.com/path?token=secret", "status_code": 504, "duration_ms": 310, "error": "gateway timeout"},
    ]

    with crawl_session(provider="tavily", query={"q": "llm eval", "token": "secret"}) as sid:
        assert sid is not None
        for row in mocked_results:
            record_crawl_page(
                url=row["url"],
                status_code=row["status_code"],
                latency_ms=row["duration_ms"],
                error=row.get("error"),
                query={"q": "llm eval", "api_key": "secret"},
            )
        record_crawl_event(
            event_type="search_result_parse",
            status="failed",
            failure_reason="invalid html fragment",
            duration_ms=18,
        )

    assert TraceManager.finalize_and_send(trace_name="mocked_provider") is True
    assert sent

    payload = sent[-1] if isinstance(sent[-1], dict) else json.loads(sent[-1])
    session_spans = [s for s in payload["spans"] if s.get("span_type") == CRAWL_SESSION_SPAN_TYPE]
    page_spans = [s for s in payload["spans"] if s.get("span_type") == CRAWL_PAGE_SPAN_TYPE]
    event_spans = [s for s in payload["spans"] if s.get("span_type") == CRAWL_EVENT_SPAN_TYPE]

    assert len(session_spans) == 1
    assert len(page_spans) == 2
    assert len(event_spans) == 1
    sess = session_spans[0]
    assert sess["metadata"]["crawl.pages_ok"] == 1
    assert sess["metadata"]["crawl.pages_fail"] == 1
    assert sess["metadata"]["crawl.events_total"] == 3
    assert sess["metadata"]["crawl.events_fail"] == 2
    assert "%5BREDACTED%5D" in page_spans[0]["metadata"]["crawl.url"]
    assert page_spans[1]["metadata"]["crawl.failure_reason"] == "gateway timeout"
