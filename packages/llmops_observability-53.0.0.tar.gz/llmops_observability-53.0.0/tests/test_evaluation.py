import pytest

from llmops_observability.evaluation import EVALUATION_SPAN_TYPE, record_evaluation
import llmops_observability.trace_manager as trace_manager
from llmops_observability.trace_manager import TraceManager


@pytest.fixture(autouse=True)
def _evaluation_trace_env(monkeypatch):
    monkeypatch.setenv("AWS_SQS_URL", "https://example.com/test-queue")
    monkeypatch.setenv("PROJECT_ID", "test_project")
    monkeypatch.setenv("ENV", "test")
    TraceManager._active["trace_id"] = None
    TraceManager._active["trace_config"] = None
    TraceManager._active["start_time"] = None
    TraceManager._active["spans"] = []
    TraceManager._active["stack"] = []
    TraceManager._active["finalized_trace_id"] = None
    TraceManager._active["finalized_timestamp"] = None
    yield


def test_record_evaluation_no_trace_returns_none():
    assert record_evaluation(score=1.0, label="ok") is None


def test_record_evaluation_creates_span_with_payload():
    TraceManager.start_trace(name="eval_test")
    TraceManager.push_span_context("parent-span-1")

    sid = record_evaluation(
        score=0.87,
        label="pass",
        rationale="Matches expected format",
        name="quality_check",
        evaluated_span_id="generation-abc",
    )
    assert sid is not None
    assert len(TraceManager._active["spans"]) == 1
    span = TraceManager._active["spans"][0]
    assert span.span_id == sid
    assert span.span_name == "quality_check"
    assert span.span_type == EVALUATION_SPAN_TYPE
    assert span.parent_span_id == "parent-span-1"
    assert span.input_data["evaluation"]["score"] == pytest.approx(0.87)
    assert span.input_data["evaluation"]["label"] == "pass"
    assert span.input_data["evaluation"]["rationale"] == "Matches expected format"
    assert span.input_data["evaluation"]["trace_id"] == TraceManager._active["trace_id"]
    assert span.input_data["evaluation"]["evaluated_span_id"] == "generation-abc"
    assert "evaluation" in (span.tags or [])


def test_record_evaluation_parent_override():
    TraceManager.start_trace(name="eval_test")
    TraceManager.push_span_context("ignored-parent")

    record_evaluation(score=1, label="x", parent_span_id="explicit-parent")
    span = TraceManager._active["spans"][-1]
    assert span.parent_span_id == "explicit-parent"


def test_record_evaluation_redacts_metadata_keys():
    TraceManager.start_trace(name="eval_test")
    record_evaluation(
        score=0.5,
        evaluator_metadata={"api_key": "secret123", "safe": "visible"},
    )
    span = TraceManager._active["spans"][-1]
    evaluator_meta = span.metadata.get("evaluator", {})
    assert evaluator_meta.get("safe") == "visible"
    assert evaluator_meta.get("api_key") == "[REDACTED]"


def test_record_evaluation_accepts_explicit_trace_id():
    trace_id = TraceManager.start_trace(name="eval_explicit_trace")
    sid = record_evaluation(score=0.99, trace_id=trace_id)
    assert sid is not None
    span = TraceManager._active["spans"][-1]
    assert span.input_data["evaluation"]["trace_id"] == trace_id


def test_record_evaluation_rejects_mismatched_trace_id():
    TraceManager.start_trace(name="eval_bad_trace")
    with pytest.raises(ValueError, match="does not match active trace"):
        record_evaluation(score=0.5, trace_id="another-trace-id")


@pytest.mark.parametrize(
    "kwargs,message",
    [
        ({}, "at least one of score, label, or rationale must be provided"),
        ({"score": "bad"}, "score must be a number"),
        ({"score": float("nan")}, "score must be a finite number"),
        ({"label": ""}, "label must not be empty"),
        ({"rationale": "   "}, "rationale must not be empty"),
        ({"score": 0.1, "name": ""}, "name must not be empty"),
        ({"score": 0.1, "metadata": "oops"}, "metadata must be a dictionary"),
        ({"score": 0.1, "evaluator_metadata": "oops"}, "evaluator_metadata must be a dictionary"),
        ({"score": 0.1, "parent_span_id": ""}, "parent_span_id must not be empty"),
        ({"score": 0.1, "evaluated_span_id": ""}, "evaluated_span_id must not be empty"),
    ],
)
def test_record_evaluation_validation_errors(kwargs, message):
    TraceManager.start_trace(name="eval_validation")
    with pytest.raises(ValueError, match=message):
        record_evaluation(**kwargs)


def test_record_evaluation_pipeline_payload_contains_expected_fields(monkeypatch):
    sent_payloads = []

    def _send(payload):
        sent_payloads.append(payload)
        return True

    TraceManager.start_trace(name="eval_pipeline")
    monkeypatch.setattr(trace_manager, "is_sqs_enabled", lambda: True)
    monkeypatch.setattr(trace_manager, "send_to_sqs", _send)

    record_evaluation(
        score=0.74,
        label="review",
        rationale="Business rule check for non-LLM API response",
        evaluated_span_id="downstream-http-span",
        evaluator_metadata={"name": "rule-engine", "version": "v1"},
    )
    TraceManager.add_span(
        trace_manager.SpanData(
            span_id="supporting-span",
            span_name="supporting-span",
            span_type="span",
        )
    )

    assert TraceManager.finalize_and_send(trace_name="eval_pipeline") is True
    assert sent_payloads

    import base64
    import gzip
    import json

    envelope = sent_payloads[-1] if isinstance(sent_payloads[-1], dict) else json.loads(sent_payloads[-1])
    if envelope.get("compressed"):
        payload = json.loads(gzip.decompress(base64.b64decode(envelope["data"])).decode("utf-8"))
    else:
        payload = envelope

    evaluation_spans = [s for s in payload["spans"] if s.get("span_type") == EVALUATION_SPAN_TYPE]
    assert len(evaluation_spans) == 1
    eval_span = evaluation_spans[0]
    assert eval_span["input_data"]["evaluation"]["score"] == pytest.approx(0.74)
    assert eval_span["input_data"]["evaluation"]["label"] == "review"
    assert eval_span["input_data"]["evaluation"]["rationale"] == "Business rule check for non-LLM API response"
    assert eval_span["input_data"]["evaluation"]["evaluated_span_id"] == "downstream-http-span"
    assert eval_span["metadata"]["evaluator"]["name"] == "rule-engine"
