"""
Shared redaction helpers for telemetry payloads.
"""
from __future__ import annotations

import re
import logging
from typing import Any, Dict, Iterable, Optional

logger = logging.getLogger(__name__)

# Suppress verbose Presidio logs - keep only ERROR level
# This removes: INFO logs (Loaded recognizer, Fetching recognizers)
#              WARNING logs (language mismatches)
logging.getLogger("presidio-analyzer").setLevel(logging.ERROR)
logging.getLogger("presidio-anonymizer").setLevel(logging.ERROR)


REDACTED_VALUE = "[REDACTED]"
LOCATION_TOKEN = "[LOCATION]"
ORG_TOKEN = "[ORG]"
EMAIL_TOKEN = "[EMAIL]"
PHONE_TOKEN = "[PHONE]"
SSN_TOKEN = "[SSN]"
CC_TOKEN = "[CC]"
IBAN_TOKEN = "[IBAN]"
ADDRESS_TOKEN = "[ADDRESS]"
NAME_TOKEN = "[NAME]"
DATE_TOKEN = "[DATE]"
URL_TOKEN = "[URL]"

DEFAULT_SENSITIVE_KEYS = {
    "authorization",
    "proxy-authorization",
    "x-api-key",
    "api-key",
    "api_key",
    "apikey",
    "token",
    "access_token",
    "refresh_token",
    "password",
    "passwd",
    "secret",
    "client_secret",
}


def redact_key_values(values: Dict[str, Any], sensitive_keys: Iterable[str] = DEFAULT_SENSITIVE_KEYS) -> Dict[str, Any]:
    sensitive = {str(k).strip().lower() for k in sensitive_keys}
    out: Dict[str, Any] = {}
    for key, value in values.items():
        normalized = str(key).strip().lower()
        out[str(key)] = REDACTED_VALUE if normalized in sensitive else value
    return out


def redact_deep(value: Any, sensitive_keys: Iterable[str] = DEFAULT_SENSITIVE_KEYS) -> Any:
    sensitive = {str(k).strip().lower() for k in sensitive_keys}
    if isinstance(value, dict):
        redacted: Dict[str, Any] = {}
        for key, val in value.items():
            normalized = str(key).strip().lower()
            if normalized in sensitive:
                redacted[str(key)] = REDACTED_VALUE
            else:
                redacted[str(key)] = redact_deep(val, sensitive)
        return redacted
    if isinstance(value, list):
        return [redact_deep(item, sensitive) for item in value]
    if isinstance(value, tuple):
        return tuple(redact_deep(item, sensitive) for item in value)
    return value


class _TelemetryPIIRedactor:
    def __init__(self) -> None:
        self._analyzer = None
        self._anonymizer = None
        self._init_patterns()
        self._init_presidio()

    def _init_patterns(self) -> None:
        self.email_pattern = re.compile(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b')
        self.ssn_pattern = re.compile(r'\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b')
        self.cc_pattern = re.compile(r'\b(?:\d{4}[-\s]?){3}\d{4}\b')
        self.iban_pattern = re.compile(r'\b[A-Z]{2}\d{2}[A-Z0-9]{1,30}\b')
        self.phone_patterns = [
            re.compile(r'(?<!\d)\+\d{1,3}[-.\s]?\d{10}(?!\d)'),
            re.compile(r'(?<!\d)\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}(?!\d)'),
            re.compile(r'(?<!\d)\d{10}(?!\d)'),
        ]
        address_flags = re.IGNORECASE
        unit_labels = r'(?:Apartment|Apt|Flat|Unit|Suite|Ste|Floor|Fl|Room|Rm|Block|Bldg|Building|Level|Lvl|Tower)'
        street_suffixes = (
            r'(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Lane|Ln|Drive|Dr|Court|Ct|Place|Pl|Way|Terrace|Ter|Circle|Cir|'
            r'Highway|Hwy|Close|Crescent|Cres|Parade|Esplanade|Quay|Mews|Gardens|Garden|Row|Hill|Square|Sq|Strasse|Straße|Str|'
            r'Gasse|Allee|Allée|Weg|Ring|Chauss[eé]e)'
        )
        street_prefixes = r'(?:Rue|Avenida|Avda|Avinguda|Avenue|Calle|Carrer|Camino|Paseo|Via|Viale|Vicolo|Piazza|Piazzale|Place|Route|Chemin|Cours|Quai|Impasse|Strada)'
        street_name_tokens = r"(?:[A-Za-z0-9][\w'.-]*|d'|l'|de|du|des|del|della|di|da|la|le|los|las|van|von|der|den)"
        civic_number = r'(?:\d{1,6}[A-Za-z]?|\d{1,4}/\d{1,6}[A-Za-z]?)'
        leading_unit = rf'(?:{unit_labels}\s+[A-Za-z0-9-]+(?:\s*,\s*|\s+))?'
        trailing_unit = rf'(?:\s*,?\s*{unit_labels}\s*[A-Za-z0-9-]+)?'
        trailing_direction = r'(?:\s+(?:North|South|East|West|N|S|E|W|NE|NW|SE|SW))?'
        locality_tail = (
            r'(?:,\s*(?:[A-Za-z][\w\'.-]*(?:\s+[A-Za-z][\w\'.-]*){0,3}))?'
            r'(?:,\s*[A-Z]{2}(?:\s+\d{5}(?:-\d{4})?)?)?'
            r'(?:,\s*\d{4,6}\s+(?:[A-Za-z][\w\'.-]*(?:\s+[A-Za-z][\w\'.-]*){0,3}))?'
        )
        self.address_patterns = [
            re.compile(
                rf'\b{leading_unit}{civic_number}\s+(?:{street_name_tokens}\s+){{0,6}}{street_suffixes}\b{trailing_direction}{trailing_unit}{locality_tail}',
                address_flags,
            ),
            re.compile(
                rf'\b{leading_unit}{civic_number}\s+{street_prefixes}\s+(?:{street_name_tokens}\s+){{0,6}}{street_name_tokens}\b{trailing_direction}{trailing_unit}{locality_tail}',
                address_flags,
            ),
        ]
        org_name = r'[A-Z][\w&-]*(?:\.[A-Za-z0-9&-]+)*(?:\s+[A-Z][\w&-]*(?:\.[A-Za-z0-9&-]+)*){0,4}'
        self.org_context_patterns = [
            re.compile(
                r'\b((?:work(?:ing)?|employed|employee|contractor|intern|join(?:ed|ing)?)\s+(?:at|for|with)\s+)'
                rf'({org_name})\b'
            ),
            re.compile(
                r'\b((?:company|organization|organisation|employer)\s+(?:is|:|=)\s*)'
                rf'({org_name})\b'
            ),
        ]

    def _init_presidio(self) -> None:
        try:
            from presidio_analyzer import AnalyzerEngine
            from presidio_anonymizer import AnonymizerEngine

            logger.info("[PII Redactor] Initializing Presidio analyzer (NER for names, locations, orgs)...")
            self._analyzer = AnalyzerEngine()
            self._anonymizer = AnonymizerEngine()
            logger.info("[PII Redactor] ✓ Presidio analyzer ready - will be reused for all requests")
        except ImportError as e:
            logger.warning(f"[PII Redactor] Presidio not available: {e}. Falling back to pattern-based redaction only.")
            self._analyzer = None
            self._anonymizer = None

    def _try_parse_dict_string(self, text: str) -> Any:
        """
        Try to parse a string that looks like a dict/list representation.
        This handles cases where dicts are converted to strings before redaction.
        
        Examples:
            "{'key': 'value'}" -> {'key': 'value'}
            "[1, 2, 3]" -> [1, 2, 3]
        
        Returns the parsed object if successful, None otherwise.
        """
        if not text or not isinstance(text, str):
            return None
        
        stripped = text.strip()
        
        # Check if it looks like a dict or list
        if not ((stripped.startswith('{') and stripped.endswith('}')) or 
                (stripped.startswith('[') and stripped.endswith(']'))):
            return None
        
        try:
            import ast
            parsed = ast.literal_eval(stripped)
            # Only accept dict or list types (not arbitrary expressions)
            if isinstance(parsed, (dict, list)):
                return parsed
        except (ValueError, SyntaxError):
            pass
        
        return None

    def redact_value(self, value: Any) -> Any:
        if isinstance(value, str):
            # Try to parse dict/list string representations before redacting
            parsed = self._try_parse_dict_string(value)
            if parsed is not None:
                # Recursively redact the parsed structure, then return as string
                redacted = self.redact_value(parsed)
                # Convert back to string representation to preserve original format
                return str(redacted)
            # Otherwise, treat as regular text
            return self.redact_text(value)
        if isinstance(value, dict):
            return self._redact_dict_value(value)
        if isinstance(value, list):
            return [self.redact_value(item) for item in value]
        if isinstance(value, tuple):
            return tuple(self.redact_value(item) for item in value)
        return value

    def _redact_dict_value(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Redact a dictionary, including special handling for name-type fields."""
        result = {}
        for key, value in data.items():
            # Check if this key looks like a name field
            if self._is_name_field(key):
                # Mask name field values with asterisks
                if isinstance(value, str):
                    result[key] = "*" * len(value)
                else:
                    result[key] = self.redact_value(value)
            else:
                result[key] = self.redact_value(value)
        return result

    def _is_name_field(self, key: str) -> bool:
        """Check if a field likely contains a person name (not user ID or other identifiers)."""
        lower_key = str(key).lower()
        
        # Exact name-type field indicators
        name_patterns = {
            "name", "fullname", "full_name", "firstname", "first_name",
            "lastname", "last_name", "displayname", "display_name",
            "author", "contact", "sender", "recipient", "owner", 
            "requester", "assignee", "creator"
        }
        
        # Check for exact matches or as word boundaries (e.g., "user_name" but not "user_id")
        for pattern in name_patterns:
            if lower_key == pattern:
                return True
            # Match patterns with underscores/hyphens as word separators
            if f"_{pattern}" in lower_key or f"-{pattern}" in lower_key:
                return True
            if lower_key.startswith(f"{pattern}_") or lower_key.startswith(f"{pattern}-"):
                return True
        
        return False

    def _mask_with_asterisks(self, match) -> str:
        """Replace matched text with asterisks matching the original length."""
        return "*" * len(match.group(0))

    def redact_text(self, text: str) -> str:
        if not text or not isinstance(text, str):
            return text

        result = self.cc_pattern.sub(self._mask_with_asterisks, text)
        result = self.email_pattern.sub(self._mask_with_asterisks, result)
        result = self.ssn_pattern.sub(self._mask_with_asterisks, result)
        result = self.iban_pattern.sub(self._mask_with_asterisks, result)
        for phone_pattern in self.phone_patterns:
            result = phone_pattern.sub(self._mask_with_asterisks, result)
        for address_pattern in self.address_patterns:
            result = address_pattern.sub(self._mask_with_asterisks, result)
        
        # Handle org context patterns - preserve the prefix, mask the org name
        for org_pattern in self.org_context_patterns:
            result = org_pattern.sub(
                lambda match: f"{match.group(1)}{self._mask_with_asterisks(type('obj', (object,), {'group': lambda self: match.group(2)})())}",
                result
            )
        
        result = self._redact_presidio(result)
        return result

    def _redact_presidio(self, text: str) -> str:
        if not self._analyzer or not self._anonymizer:
            return text
        try:
            results = self._analyzer.analyze(text=text, language="en", score_threshold=0.5)
            if not results:
                return text
            
            # Sort results by start position in reverse order to replace from end to start
            # (prevents offset issues when replacing multiple matches)
            results_sorted = sorted(results, key=lambda x: x.start, reverse=True)
            
            result_text = text
            for result in results_sorted:
                # Replace detected entity with asterisks matching the original length
                masked = "*" * (result.end - result.start)
                result_text = result_text[:result.start] + masked + result_text[result.end:]
            
            return result_text
        except Exception:
            return text


_PII_REDACTOR: Optional[_TelemetryPIIRedactor] = None


def get_pii_redactor() -> _TelemetryPIIRedactor:
    """Get or create the singleton PII redactor instance (initialized only once)."""
    global _PII_REDACTOR
    if _PII_REDACTOR is None:
        logger.info("[PII Redactor] Creating singleton instance (first time only)...")
        _PII_REDACTOR = _TelemetryPIIRedactor()
        logger.info("[PII Redactor] Singleton instance created - all future requests will reuse this")
    return _PII_REDACTOR


def redact_pii(value: Any) -> Any:
    return get_pii_redactor().redact_value(value)

