"""
Simplified Trace Manager for LLMOps Observability
Collects all spans and sends as single SDKTraceData to SQS
"""
from __future__ import annotations
import uuid
import threading
import time
import traceback
import functools
import inspect
import json
import logging
from contextvars import ContextVar
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List, Union, Callable
from importlib.metadata import version, PackageNotFoundError

from .sqs import send_to_sqs, send_to_sqs_immediate, is_sqs_enabled
from .config import (
    MAX_SQS_SIZE,
    COMPRESSION_THRESHOLD,
    get_project_id,
    get_environment,
)
from .export_hardening import harden_trace_payload
from .redaction import redact_pii

# Configure logger
logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('[llmops_observability] %(levelname)s: %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
logger.propagate = False


def _wall_time_seconds() -> float:
    return time.time_ns() / 1_000_000_000


def _duration_ms_from_perf(start_perf_ns: int, end_perf_ns: Optional[int] = None) -> float:
    stop_perf_ns = end_perf_ns if end_perf_ns is not None else time.perf_counter_ns()
    return round((stop_perf_ns - start_perf_ns) / 1_000_000, 6)


def _is_serializable(value: Any) -> bool:
    """Check if a value is JSON-serializable without custom handlers."""
    if value is None or isinstance(value, (bool, int, float, str)):
        return True
    if isinstance(value, (list, tuple)):
        return all(_is_serializable(v) for v in value)
    if isinstance(value, dict):
        return all(isinstance(k, str) and _is_serializable(v) for k, v in value.items())
    return False


def serialize_value(value: Any, max_size: Optional[int] = None) -> Any:  # NOSONAR
    """Serialize value. If max_size is None, no truncation is applied (full content preserved)."""
    # Handle Bedrock response objects specially - extract metadata, skip body
    if isinstance(value, dict) and "ResponseMetadata" in value and "body" in value:
        cleaned_response = {}
        for key, val in value.items():
            if key == "body":
                cleaned_response[key] = f"<{type(val).__name__} - binary content>"
            elif _is_serializable(val):
                cleaned_response[key] = val
            else:
                cleaned_response[key] = str(val)
        value = cleaned_response

    # Clean non-serializable containers to keep JSON object output
    if not _is_serializable(value):
        if isinstance(value, dict):
            cleaned = {}
            for k, v in value.items():
                key = k if isinstance(k, str) else str(k)
                cleaned[key] = serialize_value(v, max_size)
            value = cleaned
        elif isinstance(value, (list, tuple)):
            value = [serialize_value(v, max_size) for v in value]
        else:
            return f"<{type(value).__name__} object>"

    # Custom JSON encoder that handles non-serializable objects by cleaning them
    def custom_encoder(obj):
        # Handle Bedrock StreamingBody and similar objects
        if hasattr(obj, '__class__') and 'StreamingBody' in obj.__class__.__name__:
            return "<StreamingBody - binary content>"
        # Handle other non-serializable objects
        if hasattr(obj, '__dict__') and hasattr(obj, '__class__'):
            # Try to clean up the object representation
            return f"<{obj.__class__.__name__} object>"
        return str(obj)

    try:
        serialized_str = json.dumps(value, default=custom_encoder)
        serialized_bytes = serialized_str.encode('utf-8')

        # No size limit - return full content
        if max_size is None:
            return json.loads(serialized_str)

        # Size limit applied - truncate if needed
        if len(serialized_bytes) <= max_size:
            return json.loads(serialized_str)

        # Too large - return truncation info
        preview_size = min(1000, max_size // 2)
        preview = serialized_str[:preview_size]

        logger.warning(f"Output truncated: {len(serialized_bytes)} bytes -> {max_size} bytes limit")

        return {
            "_truncated": True,
            "_original_size_bytes": len(serialized_bytes),
            "_original_size_mb": round(len(serialized_bytes) / (1024 * 1024), 2),
            "_preview": preview + "...",
            "_message": f"Output truncated (original: {round(len(serialized_bytes) / (1024 * 1024), 2)} MB, limit: {round(max_size / 1024, 0)} KB)"
        }
    except Exception:
        return str(value)


def ensure_json_object(value: Any, max_size: Optional[int] = None, key: str = "value") -> Dict[str, Any]:
    """Ensure the returned value is always a JSON object (dict). If max_size is None, no truncation applied."""
    if value is None:
        return {key: None}

    if isinstance(value, dict):
        serialized = serialize_value(value, max_size)
        return serialized if isinstance(serialized, dict) else {key: serialized}

    if isinstance(value, str):
        # No size limit - return full string
        if max_size is None:
            return {key: value}

        # Size limit applied - truncate if needed
        size = len(value.encode("utf-8"))
        if size <= max_size:
            return {key: value}

        preview_size = min(1000, max_size // 2)
        preview = value[:preview_size]
        return {
            key: {
                "_truncated": True,
                "_original_size_bytes": size,
                "_original_size_mb": round(size / (1024 * 1024), 2),
                "_preview": preview + "...",
                "_message": f"Output truncated (original: {round(size / (1024 * 1024), 2)} MB, limit: {round(max_size / 1024, 0)} KB)",
            }
        }

    try:
        serialized = serialize_value(value, max_size)
        return serialized if isinstance(serialized, dict) else {key: serialized}
    except Exception:
        return {key: str(value)}


def safe_locals(d: Dict[str, Any]) -> Dict[str, Any]:
    """Safely serialize local variables"""
    return {k: serialize_value(v) for k, v in d.items() if not k.startswith("_")}


# Data models for SDK
class SpanData:
    """Individual span/generation data"""
    def __init__(self, **kwargs):
        self.span_id = kwargs.get('span_id')
        self.span_name = kwargs.get('span_name')
        self.span_type = kwargs.get('span_type')
        self.parent_span_id = kwargs.get('parent_span_id')
        self.start_time = kwargs.get('start_time')
        self.end_time = kwargs.get('end_time')
        self.duration_ms = kwargs.get('duration_ms')
        self.input_data = kwargs.get('input_data')
        self.output_data = kwargs.get('output_data')
        self.error = kwargs.get('error')
        self.model_id = kwargs.get('model_id')
        self.metadata = kwargs.get('metadata', {})
        self.tags = kwargs.get('tags', [])
        self.usage = kwargs.get('usage')
        self.prompt = kwargs.get('prompt')
        self.response = kwargs.get('response')
        self.status = kwargs.get('status', 'success')
        self.status_message = kwargs.get('status_message')
        self.level = kwargs.get('level', 'DEFAULT')
        self.pii_protection = kwargs.get('pii_protection', False)


class SDKTraceData:
    """Complete trace data to be sent to SQS"""
    def __init__(self, **kwargs):
        self.trace_id = kwargs.get('trace_id')
        self.trace_name = kwargs.get('trace_name')
        self.project_id = kwargs.get('project_id')
        self.environment = kwargs.get('environment')
        self.user_id = kwargs.get('user_id')
        self.session_id = kwargs.get('session_id')
        self.start_time = kwargs.get('start_time')
        self.end_time = kwargs.get('end_time')
        self.duration_ms = kwargs.get('duration_ms')
        self.trace_input = kwargs.get('trace_input')
        self.trace_output = kwargs.get('trace_output')
        self.spans = kwargs.get('spans', [])
        self.metadata = kwargs.get('metadata', {})
        self.tags = kwargs.get('tags', [])
        self.total_spans = kwargs.get('total_spans', 0)
        self.total_generations = kwargs.get('total_generations', 0)
        self.sdk_name = kwargs.get('sdk_name', 'llmops-observability')
        self.has_external_segments = kwargs.get('has_external_segments', False)

        # Get SDK version from package, fallback to default
        if 'sdk_version' in kwargs:
            self.sdk_version = kwargs['sdk_version']
        else:
            try:
                self.sdk_version = version("llmops-observability")
            except PackageNotFoundError:
                self.sdk_version = "0.0.0"

    def prepare_for_sqs(self) -> str:
        """Prepare trace data for SQS with compression and S3 Extended Client support"""
        import gzip
        import base64

        def _maybe_redact(value: Any, pii_enabled: bool) -> Any:
            return redact_pii(value) if pii_enabled else value

        def _build_payload() -> Dict[str, Any]:
            processed_spans = []
            for span in self.spans:
                pii_enabled = bool(getattr(span, "pii_protection", False))
                processed_spans.append({
                    "span_id": span.span_id,
                    "span_name": span.span_name,
                    "span_type": span.span_type,
                    "parent_span_id": span.parent_span_id,
                    "start_time": span.start_time,
                    "end_time": span.end_time,
                    "duration_ms": span.duration_ms,
                    "input_data": _maybe_redact(span.input_data, pii_enabled),
                    "output_data": _maybe_redact(span.output_data, pii_enabled),
                    "error": span.error,
                    "model_id": span.model_id,
                    "metadata": span.metadata,
                    "tags": span.tags,
                    "usage": span.usage,
                    "prompt": _maybe_redact(span.prompt, pii_enabled),
                    "response": _maybe_redact(span.response, pii_enabled),
                    "status": span.status,
                    "status_message": span.status_message,
                    "level": span.level,
                })

            return {
                "trace_id": self.trace_id,
                "trace_name": self.trace_name,
                "project_id": self.project_id,
                "environment": self.environment,
                "user_id": self.user_id,
                "session_id": self.session_id,
                "start_time": self.start_time,
                "end_time": self.end_time,
                "duration_ms": self.duration_ms,
                "trace_input": self.trace_input,
                "trace_output": self.trace_output,
                "spans": processed_spans,
                "metadata": self.metadata,
                "tags": self.tags,
                "total_spans": self.total_spans,
                "total_generations": self.total_generations,
                "sdk_name": self.sdk_name,
                "sdk_version": self.sdk_version,
            }

        # Build payload with FULL content and apply export hardening.
        full_payload = _build_payload()
        full_payload["is_child_segment"] = False
        full_payload["has_external_segments"] = self.has_external_segments
        full_payload = harden_trace_payload(full_payload)
        full_json_str = json.dumps(full_payload, default=str)
        full_json_bytes = full_json_str.encode('utf-8')

        # Only compress if uncompressed size > COMPRESSION_THRESHOLD
        # For smaller messages, send as plain JSON (no compression overhead)
        if len(full_json_bytes) <= COMPRESSION_THRESHOLD:
            # Small message - send as plain JSON (no compression)
            return json.dumps(full_payload, default=str)

        # Large message - compress it
        full_compressed = gzip.compress(full_json_bytes, compresslevel=9)

        # If compressed fits in SQS limit, send it directly
        if len(full_compressed) <= MAX_SQS_SIZE:
            return json.dumps({
                "compressed": True,
                "data": base64.b64encode(full_compressed).decode('utf-8'),
                "trace_id": self.trace_id,
            })

        # Payload exceeds SQS limit - use S3 Extended Client
        try:
            from .s3_extended_client import S3ExtendedClient, get_s3_extended_client

            s3_client = get_s3_extended_client()
            if s3_client and s3_client.is_enabled():
                success, s3_key, error = s3_client.store_in_s3(
                    payload_dict=full_payload,
                    trace_id=self.trace_id or "unknown_trace_id"
                )

                if success and s3_key:
                    # Create S3 reference message
                    s3_reference = s3_client.create_sqs_reference(s3_key)
                    logger.info(f"[OK] Trace {self.trace_id} stored in S3: {s3_key}")
                    return json.dumps(s3_reference)
                else:
                    logger.error(f"S3 storage failed for {self.trace_id}: {error}")
            else:
                logger.error("S3 Extended Client not available - sending full payload to SQS")
        except Exception as e:
            logger.error(f"S3 Extended Client error for {self.trace_id}: {str(e)} - sending full payload to SQS")

        # Send full payload anyway (no truncation fallback)
        return json.dumps({
            "compressed": True,
            "data": base64.b64encode(full_compressed).decode('utf-8'),
            "trace_id": self.trace_id,
        })




class TraceManager:
    """Simplified TraceManager"""
    _lock = threading.Lock()
    _pending_lock = threading.Lock()
    _pending_cond = threading.Condition(_pending_lock)
    _pending_count = 0
    _active: Dict[str, Any] = {
        "trace_id": None,
        "trace_config": None,
        "start_time": None,
        "spans": [],
        "stack": [],
        "_span_locals": {},
        "finalized_trace_id": None,  # Track if trace was finalized (for late spans)
        "finalized_timestamp": None,  # When trace was finalized
    }
    _distributed: Dict[str, Any] = {
        "has_external_segments": False,
        "_child_mode": False,
        "_child_trace_id": None,
        "_child_spans": [],
        "_child_prev_trace_config": None,
        "_child_prev_stack": [],
        "_suppress_next_empty_finalize": False,
    }
    _banner_shown = False  # Track if banner was already shown
    _config_warning_shown = False  # Track if config warning was already shown
    _config_info_shown = False  # Track if config OK message was already shown
    _last_config: Optional[Dict[str, Any]] = None  # Track last config to avoid repeated logs
    _context_state: ContextVar[Optional[Dict[str, Dict[str, Any]]]] = ContextVar(
        "llmops_trace_context_state",
        default=None,
    )

    @classmethod
    def _new_context_state(cls) -> Dict[str, Dict[str, Any]]:
        return {
            "active": {
                "trace_id": None,
                "trace_config": None,
                "start_time": None,
                "spans": [],
                "stack": [],
                "_span_locals": {},
                "finalized_trace_id": None,
                "finalized_timestamp": None,
                "_last_model_id": None,
                "_accumulated_usage": {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0},
                "pending_count": 0,
            },
            "distributed": {
                "has_external_segments": False,
                "_child_mode": False,
                "_child_trace_id": None,
                "_child_spans": [],
                "_child_prev_trace_config": None,
                "_child_prev_stack": [],
                "_suppress_next_empty_finalize": False,
            },
        }

    @classmethod
    def _bind_request_context(cls) -> Dict[str, Dict[str, Any]]:
        state = cls._context_state.get()
        if state is None:
            state = cls._new_context_state()
            cls._context_state.set(state)

        cls._active = state["active"]
        cls._distributed = state["distributed"]
        return state

    @classmethod
    def _show_banner(cls):
        """Display SDK welcome banner (only once)"""
        if cls._banner_shown:
            return

        cls._banner_shown = True

        try:
            sdk_version = version("llmops-observability")
        except PackageNotFoundError:
            sdk_version = "unknown"

        banner = f"""
┓ ┓ ┳┳┓┏┓┏┓┏┓  ┏┓┳┓┏┓┏┓┳┓┓┏┏┓┳┓┳┓ ┳┏┳┓┓┏
┃ ┃ ┃┃┃┃┃┃┃┗┓━━┃┃┣┫┗┓┣ ┣┫┃┃┣┫┣┫┃┃ ┃ ┃ ┗┫
┗┛┗┛┛ ┗┗┛┣┛┗┛  ┗┛┻┛┗┛┗┛┛┗┗┛┛┗┻┛┻┗┛┻ ┻ ┗┛

v{sdk_version}
"""
        try:
            print(banner)
        except UnicodeEncodeError:
            print(f"\nLLMOps Observability SDK v{sdk_version}\n")

    @classmethod
    def configuration(
        cls,
        project_id: str,
        env: str,
        aws_sqs_url: str,
        aws_region: str,
        s3_bucket: str,
        aws_profile: Optional[str] = None,
    ) -> None:
        """
        Configure the SDK programmatically instead of using environment variables.
        This should be called once at application startup, before any tracing begins.

        All parameters are required except aws_profile.

        Parameters:
            project_id (str): Project identifier (required)
            env (str): Environment name (required - e.g., "development", "staging", "production")
            aws_sqs_url (str): SQS queue URL for sending traces (required)
            aws_region (str): AWS region (required - e.g., "us-east-1")
            aws_profile (str): AWS profile name (optional - omit to use boto3 default resolution)
            s3_bucket (str): S3 bucket name for large payloads (required)

        Example:
            TraceManager.configuration(
                project_id="my-test-project",
                env="development",
                aws_sqs_url="https://sqs.us-east-1.amazonaws.com/258761349404/MyQueue",
                aws_region="us-east-1",
                s3_bucket="my-trace-storage-bucket"
            )

        Note:
            This configuration is global and persists for the lifetime of the application.
            Configuration values set here take precedence over environment variables.
        """
        from .config import set_configuration

        # Show welcome banner
        cls._show_banner()

        config = {
            "project_id": project_id,
            "env": env,
            "aws_sqs_url": aws_sqs_url,
            "aws_region": aws_region,
            "s3_bucket": s3_bucket,
        }
        if aws_profile:
            config["aws_profile"] = aws_profile

        set_configuration(**config)
        if cls._last_config != config:
            logger.info("[OK] SDK configured programmatically!")
            logger.debug(f"TraceManager configured with: {list(config.keys())}")
            cls._last_config = config

    @classmethod
    def has_active_trace(cls) -> bool:
        """Check if there's an active trace"""
        cls._bind_request_context()
        with cls._lock:
            return cls._active["trace_id"] is not None

    @classmethod
    def can_track_span(cls) -> bool:
        """Check if we can track spans (active OR finalized trace)"""
        cls._bind_request_context()
        with cls._lock:
            return cls._active["trace_id"] is not None or cls._active["finalized_trace_id"] is not None

    @classmethod
    def _now(cls) -> str:
        """Get current UTC timestamp"""
        return datetime.now(timezone.utc).isoformat()

    @classmethod
    def _reset_pending(cls) -> None:
        cls._bind_request_context()
        with cls._pending_cond:
            cls._active["pending_count"] = 0
            cls._pending_cond.notify_all()

    @classmethod
    def _increment_pending_if_active(cls) -> bool:
        cls._bind_request_context()
        with cls._lock:
            if cls._active.get("trace_id") is None:
                return False
        with cls._pending_cond:
            cls._active["pending_count"] = int(cls._active.get("pending_count", 0)) + 1
            return True

    @classmethod
    def _decrement_pending(cls) -> None:
        cls._bind_request_context()
        with cls._pending_cond:
            pending_count = int(cls._active.get("pending_count", 0))
            if pending_count > 0:
                cls._active["pending_count"] = pending_count - 1
            cls._pending_cond.notify_all()

    @classmethod
    def _wait_for_pending(cls) -> None:
        cls._bind_request_context()
        with cls._pending_cond:
            while int(cls._active.get("pending_count", 0)) > 0:
                cls._pending_cond.wait()

    @classmethod
    def start_trace(
        cls,
        name: str,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ) -> Optional[str]:
        """Start a new trace. Returns trace_id or None if tracing is disabled."""
        cls._bind_request_context()
        # Show banner even if configuration isn't used
        cls._show_banner()

        # Early config check: if SQS isn't configured, don't start trace
        try:
            from .config import get_sqs_config
            sqs_config = get_sqs_config()
            if not sqs_config.get("aws_sqs_url"):
                if not cls._config_warning_shown:
                    logger.warning("No SQS URL configured. Traces will not be sent.")
                    cls._config_warning_shown = True
                return None
            # If using .env/environment variables (no programmatic config), log once
            if not cls._config_info_shown and cls._last_config is None:
                logger.info("[OK] SDK configured via .env/environment variables!")
                cls._config_info_shown = True
        except Exception:
            if not cls._config_warning_shown:
                logger.warning("Unable to validate SQS configuration. Traces may not be sent.")
                cls._config_warning_shown = True
        # Get project_id and environment from config (centralized)
        project_id = get_project_id()
        environment = get_environment()

        trace_config = {
            "name": name,
            "project_id": project_id,
            "environment": environment,
            "user_id": user_id,
            "session_id": session_id,
            "metadata": metadata or {},
            "tags": tags or [],
            "trace_name": project_id,
        }

        cls._reset_pending()

        with cls._lock:
            trace_id = uuid.uuid4().hex
            cls._active["trace_id"] = trace_id
            cls._active["trace_config"] = trace_config
            cls._active["start_time"] = time.time()
            cls._active["spans"] = []
            cls._active["stack"] = []
            cls._active["_span_locals"] = {}
            cls._active["_last_model_id"] = None
            cls._active["_accumulated_usage"] = {"input_tokens": 0, "output_tokens": 0, "total_tokens": 0}
            cls._distributed["has_external_segments"] = False
            cls._distributed["_child_mode"] = False
            cls._distributed["_child_trace_id"] = None
            cls._distributed["_child_spans"] = []
            cls._distributed["_suppress_next_empty_finalize"] = False

            logger.info(
                f"Trace started: {trace_config['trace_name']} | "
                f"Operation: {trace_config['name']} | "
                f"Env: {trace_config['environment']} (ID: {trace_id})"
            )

            return trace_id

    @classmethod
    def update(  # NOSONAR
        cls,
        trace_name: Optional[str] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ) -> bool:
        """
        Update active trace fields at runtime.

        This allows GenAI apps to inject resolved identity/session information
        after trace start and before finalize. Values set here override
        header-derived values captured at trace start.
        """
        cls._bind_request_context()
        with cls._lock:
            trace_id = cls._active.get("trace_id")
            trace_config = cls._active.get("trace_config")

            if not trace_id or not isinstance(trace_config, dict):
                logger.debug("TraceManager.update called without an active trace")
                return False

            updated = False

            if trace_name is not None and str(trace_name).strip():
                trace_config["name"] = str(trace_name).strip()
                updated = True

            if user_id is not None and str(user_id).strip():
                trace_config["user_id"] = str(user_id).strip()
                updated = True

            if session_id is not None and str(session_id).strip():
                trace_config["session_id"] = str(session_id).strip()
                updated = True

            if metadata is not None:
                existing_metadata = trace_config.get("metadata")
                if not isinstance(existing_metadata, dict):
                    existing_metadata = {}
                existing_metadata.update(metadata)
                trace_config["metadata"] = existing_metadata
                updated = True

            if tags is not None:
                existing_tags = trace_config.get("tags", [])
                if not isinstance(existing_tags, list):
                    existing_tags = []
                for tag in tags:
                    if tag and tag not in existing_tags:
                        existing_tags.append(tag)
                trace_config["tags"] = existing_tags
                updated = True

            if updated:
                logger.debug(
                    "TraceManager.update applied | trace_id=%s trace_name=%s user_id=%s session_id=%s",
                    trace_id,
                    trace_config.get("name"),
                    trace_config.get("user_id"),
                    trace_config.get("session_id"),
                )

            return updated

    @classmethod
    def set_trace_model_id(cls, model_id: str) -> None:
        """Store the last captured model_id at the trace level (thread-safe).

        This is used as a fallback when ContextVar-based capture cannot
        propagate across thread boundaries (e.g. asyncio.to_thread).
        """
        cls._bind_request_context()
        with cls._lock:
            if cls._active.get("trace_id"):
                cls._active["_last_model_id"] = model_id

    @classmethod
    def get_trace_model_id(cls) -> Optional[str]:
        """Get the last stored model_id from the active trace."""
        cls._bind_request_context()
        with cls._lock:
            return cls._active.get("_last_model_id")

    @classmethod
    def accumulate_trace_usage(cls, input_tokens: int = 0, output_tokens: int = 0, total_tokens: int = 0) -> None:
        """Accumulate Bedrock token usage at the trace level (thread-safe).

        Called from bedrock_instrumentation after each Bedrock API call so
        that parent/agent spans can retrieve the aggregated usage even when
        ContextVar-based capture does not propagate across threads.
        """
        cls._bind_request_context()
        with cls._lock:
            acc = cls._active.get("_accumulated_usage")
            if acc is not None:
                acc["input_tokens"] += int(input_tokens or 0)
                acc["output_tokens"] += int(output_tokens or 0)
                acc["total_tokens"] += int(total_tokens or 0)

    @classmethod
    def get_trace_usage(cls) -> Optional[Dict[str, int]]:
        """Get the accumulated Bedrock usage from the active trace."""
        cls._bind_request_context()
        with cls._lock:
            acc = cls._active.get("_accumulated_usage")
            if acc and acc.get("total_tokens", 0) > 0:
                return dict(acc)
            return None

    @classmethod
    def add_span(cls, span: SpanData):
        """Add a completed span to the trace"""
        cls._bind_request_context()
        with cls._lock:
            trace_id = cls._active.get("trace_id")
            finalized_trace_id = cls._active.get("finalized_trace_id")

            # Auto-inject environment and project_id into span metadata
            trace_config = cls._active.get("trace_config", {})
            if trace_config:
                # Initialize metadata dict if needed
                if not span.metadata:
                    span.metadata = {}

                # Inject environment and project_id from trace config
                span.metadata["environment"] = trace_config.get("environment", "unknown")
                span.metadata["project_id"] = trace_config.get("project_id", "unknown_project")

                # Distributed child mode: route spans to child buffer instead of active trace
                if cls._distributed.get("_child_mode") and cls._distributed.get("_child_trace_id"):
                    cls._distributed["_child_spans"].append(span)
                    logger.debug("[CHILD] Child span buffered: %s", span.span_name)
                    return

            # If no active trace but we have a finalized one, this is a LATE SPAN
            if not trace_id and finalized_trace_id:
                cls._submit_late_span_async(span, finalized_trace_id)
                return

            # Normal path: add to current trace
            if not trace_id:
                logger.warning(f"Cannot add span {span.span_name} - no active trace")
                return

            cls._active["spans"].append(span)
            logger.debug(f"Span added: {span.span_name} ({span.duration_ms}ms)")

    @classmethod
    def push_span_context(cls, span_id: str):
        """Push span ID onto stack (for nesting)"""
        cls._bind_request_context()
        with cls._lock:
            cls._active["stack"].append(span_id)

    @classmethod
    def pop_span_context(cls) -> Optional[str]:
        """Pop span ID from stack"""
        cls._bind_request_context()
        with cls._lock:
            if cls._active["stack"]:
                return cls._active["stack"].pop()
            return None

    @classmethod
    def capture_locals(cls, values: Dict[str, Any]) -> bool:
        """Capture developer-provided local values for the active span.

        These values are attached to the currently active span metadata under
        metadata.local_variables during span finalization.
        """
        if not isinstance(values, dict) or not values:
            return False

        cls._bind_request_context()
        with cls._lock:
            stack = cls._active.get("stack") or []
            if not stack:
                logger.debug("TraceManager.capture_locals called without active span context")
                return False

            current_span_id = stack[-1]
            span_locals = cls._active.get("_span_locals")
            if not isinstance(span_locals, dict):
                span_locals = {}
                cls._active["_span_locals"] = span_locals

            existing = span_locals.get(current_span_id)
            if not isinstance(existing, dict):
                existing = {}

            for key, value in values.items():
                if not isinstance(key, str):
                    continue
                existing[key] = serialize_value(value)

            if not existing:
                return False

            span_locals[current_span_id] = existing
            return True

    @classmethod
    def _consume_captured_locals_for_span(cls, span_id: Optional[str]) -> Dict[str, Any]:
        if not span_id:
            return {}
        cls._bind_request_context()
        with cls._lock:
            span_locals = cls._active.get("_span_locals")
            if not isinstance(span_locals, dict):
                return {}
            values = span_locals.pop(span_id, {})
            return values if isinstance(values, dict) else {}

    @classmethod
    def get_current_parent_span_id(cls) -> Optional[str]:
        """Get the current parent span ID from stack"""
        cls._bind_request_context()
        with cls._lock:
            if cls._active["stack"]:
                return cls._active["stack"][-1]
            return None

    @classmethod
    def end_trace(cls) -> Optional[str]:
        """End the current trace"""
        cls._bind_request_context()
        with cls._lock:
            trace_id = cls._active["trace_id"]
            if not trace_id:
                return None
            logger.info(f"Trace ended: {trace_id}")
            return trace_id

    # Distributed tracing helpers
    @classmethod
    def get_trace_id(cls) -> Optional[str]:
        """Return the current trace_id (normal or child mode)."""
        cls._bind_request_context()
        with cls._lock:
            return cls._active.get("trace_id") or cls._distributed.get("_child_trace_id")

    @classmethod
    def mark_has_external_segments(cls) -> None:
        """Mark the active trace as having downstream child segments."""
        cls._bind_request_context()
        with cls._lock:
            cls._distributed["has_external_segments"] = True

    @classmethod
    def start_child_trace(cls, trace_id: str, entry_span_id: str, service_name: str) -> None:
        """Enter child-mode: collect spans under a parent's trace_id."""
        cls._bind_request_context()
        cls._reset_pending()
        with cls._lock:
            # Preserve current request-trace context (e.g., ASGI middleware trace)
            # so child-mode does not break normal request finalization.
            cls._distributed["_child_prev_trace_config"] = cls._active.get("trace_config")
            cls._distributed["_child_prev_stack"] = list(cls._active.get("stack") or [])
            cls._distributed["_child_mode"] = True
            cls._distributed["_child_trace_id"] = trace_id
            cls._distributed["_child_spans"] = []
            cls._active["stack"] = []
            cls._active["trace_config"] = {
                "project_id": get_project_id(),
                "environment": get_environment(),
                "name": service_name,
            }
        logger.info("[CHILD] Child trace started | trace_id=%s service=%s", trace_id, service_name)

    @classmethod
    def collect_child_spans(cls) -> list:
        """Return and clear spans collected during child-mode."""
        cls._bind_request_context()
        with cls._lock:
            spans = list(cls._distributed.get("_child_spans", []))
            cls._distributed["_child_spans"] = []
            return spans

    @classmethod
    def end_child_trace(cls) -> None:
        """Exit child-mode and reset distributed state."""
        cls._bind_request_context()
        with cls._lock:
            prev_trace_config = cls._distributed.get("_child_prev_trace_config")
            prev_stack = cls._distributed.get("_child_prev_stack") or []
            cls._distributed["_child_mode"] = False
            cls._distributed["_child_trace_id"] = None
            cls._distributed["_child_spans"] = []
            cls._distributed["_child_prev_trace_config"] = None
            cls._distributed["_child_prev_stack"] = []
            cls._active["trace_config"] = prev_trace_config
            cls._active["stack"] = list(prev_stack)
            # Child segment already emitted to SQS. If ASGI request finalizer now
            # sees an empty span list, suppress that envelope to avoid duplicates.
            cls._distributed["_suppress_next_empty_finalize"] = bool(prev_trace_config)
        logger.info("[CHILD] Child trace ended")

    @classmethod
    def _submit_late_span_async(cls, span: SpanData, original_trace_id: str):
        """Submit a single span as late arrival (separate SQS message for merging)"""
        cls._bind_request_context()
        import gzip
        import base64

        try:
            # Package JUST this span with reference to original trace
            payload = {
                "type": "late_span_update",           # Flag for Lambda
                "original_trace_id": original_trace_id,  # Links to main trace
                "span": {
                    "span_id": span.span_id,
                    "span_name": span.span_name,
                    "span_type": span.span_type,
                    "parent_span_id": span.parent_span_id,
                    "start_time": span.start_time,
                    "end_time": span.end_time,
                    "duration_ms": span.duration_ms,
                    "input_data": span.input_data,
                    "output_data": span.output_data,
                    "error": span.error,
                    "model_id": span.model_id,
                    "metadata": span.metadata,
                    "tags": span.tags,
                    "usage": span.usage,
                    "prompt": span.prompt,
                    "response": span.response,
                    "status": span.status,
                    "status_message": span.status_message,
                    "level": span.level,
                },
                "submitted_at": datetime.now(timezone.utc).isoformat(),
            }

            # Compress
            json_str = json.dumps(payload, default=str)
            compressed = gzip.compress(json_str.encode('utf-8'), compresslevel=6)

            # Send as SQS message
            sqs_payload = json.dumps({
                "compressed": True,
                "data": base64.b64encode(compressed).decode('utf-8'),
                "trace_id": original_trace_id,
                "type": "late_span_update",
            })

            queued = send_to_sqs(json.loads(sqs_payload))
            if not queued:
                logger.warning("Late span could not be enqueued; message spilled by sender")
            logger.info(f"[LATE_SPAN] Late span submitted: {span.span_name} for trace {original_trace_id}")

        except Exception as e:
            logger.error(f"Failed to submit late span: {e}")
            traceback.print_exc()

    @classmethod
    def finalize_and_send(  # NOSONAR
        cls,
        *,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        trace_name: Optional[str] = None,
        trace_input: Optional[dict] = None,
        trace_output: Optional[dict] = None,
        extra_spans: list = [],
    ) -> bool:
        """Finalize trace and send to SQS"""
        cls._bind_request_context()
        cls._wait_for_pending()

        with cls._lock:
            trace_id = cls._active.get("trace_id")
            trace_config = cls._active.get("trace_config")
            start_time = cls._active.get("start_time")
            spans = cls._active.get("spans", [])

            if not trace_id or not trace_config:
                logger.error("No active trace to finalize")
                return False

            # Ensure start_time is not None
            if start_time is None:
                logger.error("Invalid trace state: start_time is None")
                return False

            # Use defaults from trace_config if not provided.
            final_trace_name = trace_name or trace_config.get("name", "unknown")
            final_user_id = user_id or trace_config.get("user_id")
            final_session_id = session_id or trace_config.get("session_id") or "anonymous"

            # Enforce safe fallback identity before SQS send.
            if final_user_id is None or not str(final_user_id).strip():
                final_user_id = "anonymous"
                logger.warning(
                    "[LLMOps] Missing user_id for trace '%s' (id=%s). "
                    "Defaulting user_id to 'anonymous'. Please provide user_id via "
                    "request headers or TraceManager.update(...).",
                    final_trace_name,
                    trace_id,
                )

            end_time = time.time()
            duration_ms = int((end_time - start_time) * 1000)

            # Suppress empty request envelopes after distributed child handling.
            if (
                cls._distributed.get("_suppress_next_empty_finalize")
                and len(spans) == 0
            ):
                cls._active["finalized_trace_id"] = trace_id
                cls._active["finalized_timestamp"] = time.time()
                cls._active["trace_id"] = None
                cls._active["trace_config"] = None
                cls._active["start_time"] = None
                cls._active["spans"] = []
                cls._active["stack"] = []
                cls._distributed["has_external_segments"] = False
                cls._distributed["_suppress_next_empty_finalize"] = False
                logger.info(
                    "[DistributedTracing] Suppressed empty finalize envelope | trace_id=%s trace_name=%s",
                    trace_id,
                    trace_name or trace_config.get("name", "unknown"),
                )
                return True

            # Count generations - include agent spans that have model_id and
            # usage so they contribute to cost/token calculations in Langfuse.
            total_generations = sum(
                1 for s in spans
                if s.span_type == "generation"
                or (s.span_type == "agent" and s.model_id and s.usage)
            )

            # Build SDKTraceData
            trace_data = SDKTraceData(
                trace_id=trace_id,
                trace_name=final_trace_name,
                project_id=trace_config.get("project_id", "unknown_project"),
                environment=trace_config.get("environment", "development"),
                user_id=final_user_id,
                session_id=final_session_id,
                start_time=start_time,
                end_time=end_time,
                duration_ms=duration_ms,
                trace_input=trace_input or {},
                trace_output=trace_output or {},
                spans=spans,
                metadata=trace_config.get("metadata", {}),
                tags=trace_config.get("tags", []),
                total_spans=len(spans),
                total_generations=total_generations,
                has_external_segments=cls._distributed.get("has_external_segments", False),
            )

            # Mark this trace as finalized (for late-arriving spans)
            cls._active["finalized_trace_id"] = trace_id
            cls._active["finalized_timestamp"] = time.time()

            # Clear active trace (but keep finalized_trace_id for late spans)
            cls._active["trace_id"] = None
            cls._active["trace_config"] = None
            cls._active["start_time"] = None
            cls._active["spans"] = []
            cls._active["stack"] = []
            cls._distributed["has_external_segments"] = False
            cls._distributed["_suppress_next_empty_finalize"] = False

        # Send to SQS
        if not is_sqs_enabled():
            logger.warning("SQS not enabled - trace data not sent")
            return False

        try:
            # Prepare compressed payload
            compressed_payload = trace_data.prepare_for_sqs()

            # Non-blocking export path: enqueue for background worker delivery.
            queued = send_to_sqs(json.loads(compressed_payload))
            if not queued:
                logger.warning("Trace could not be enqueued for SQS send; message spilled by sender")
                return False

            logger.info(
                "Trace enqueued for SQS | trace_id=%s trace_name=%s spans=%s",
                trace_id,
                final_trace_name,
                len(spans),
            )
            return True

        except Exception as e:
            logger.error(f"Error sending trace to SQS: {e}")
            traceback.print_exc()
            return False


# ============================================================
# Decorator: track_function
# ============================================================

def _build_function_input_data(  # NOSONAR
    args: tuple,
    kwargs: Dict[str, Any],
    local_vars: Optional[Dict[str, Any]] = None,
    capture_locals_spec: Union[bool, List[str]] = False,
    capture_self_flag: bool = False,
    func: Optional[Callable] = None,
) -> Dict[str, Any]:
    """Build input_data dict with optional capture of locals and self"""
    input_data = {}

    # Try to map positional args to parameter names using function signature
    if func:
        try:
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            bound_args.apply_defaults()

            # Use bound arguments as input data (cleaner display)
            for param_name, param_value in bound_args.arguments.items():
                if not param_name.startswith("_"):
                    input_data[param_name] = serialize_value(param_value)

            return input_data
        except Exception:
            # Fallback if binding fails
            pass

    # Fallback: use args and kwargs as-is
    input_data = {
        "args": serialize_value(args),
        "kwargs": serialize_value(kwargs),
    }

    # Capture self if requested
    if capture_self_flag and args and hasattr(args[0], '__dict__'):
        try:
            input_data["self"] = serialize_value(args[0])
        except Exception:
            pass

    # Capture local variables if requested
    if capture_locals_spec and local_vars:
        if isinstance(capture_locals_spec, bool) and capture_locals_spec:
            # Capture all locals (except private ones)
            input_data["locals"] = safe_locals(local_vars)
        elif isinstance(capture_locals_spec, list):
            # Capture only specified locals
            input_data["locals"] = {
                k: serialize_value(v)
                for k, v in local_vars.items()
                if k in capture_locals_spec
            }

    return input_data


def _resolve_custom_value(value: Union[str, Callable], args: tuple, kwargs: dict, result: Any = None, local_vars: Optional[dict] = None) -> Optional[str]:
    """Resolve custom input/output value - can be string, variable name, or callable."""
    if value is None:
        return None

    # If it's a callable, check signature and call with appropriate args
    if callable(value):
        try:
            sig = inspect.signature(value)
            if len(sig.parameters) >= 3:
                return str(value(args, kwargs, result))
            else:
                return str(value(args, kwargs))
        except Exception as e:
            logger.debug(f"Error calling custom value resolver: {e}")
            return None

    # If it's a string, check if it's a variable name in local_vars first
    if isinstance(value, str):
        # Try to find it as a variable name in locals
        if local_vars and value in local_vars:
            return str(local_vars[value])
        # Otherwise, treat it as a literal string
        return value

    return None


def track_function(  # NOSONAR
    name: Optional[str] = None,
    *,
    metadata: Optional[Dict[str, Any]] = None,
    capture_locals: Union[bool, List[str]] = False,
    capture_self: bool = True,
    input: Optional[Union[str, Callable]] = None,
    output: Optional[Union[str, Callable]] = None,
    pii_protection: bool = False,
):
    """
    Decorator to track function execution

    Args:
        name: Optional custom span name
        metadata: Optional metadata dict
        capture_locals: Capture local variables (bool or list of var names)
        capture_self: Capture 'self' parameter (for methods)
        input: Optional custom span input (string or callable that extracts from args/kwargs)
        output: Optional custom span output (string or callable that extracts from result)
        pii_protection: When True, redact span input/output before sending telemetry to SQS
    """
    def decorator(func):
        span_name = name or func.__name__
        is_async = inspect.iscoroutinefunction(func)

        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                # Track spans even after finalization (for late spans)
                if not TraceManager.can_track_span():
                    return await func(*args, **kwargs)

                pending_added = TraceManager._increment_pending_if_active()

                span_id = uuid.uuid4().hex
                parent_span_id = TraceManager.get_current_parent_span_id()
                start_perf_ns = time.perf_counter_ns()
                start_time = _wall_time_seconds()

                TraceManager.push_span_context(span_id)

                error = None
                result = None

                try:
                    result = await func(*args, **kwargs)
                    return result
                except Exception as e:
                    error = e
                    raise
                finally:
                    end_perf_ns = time.perf_counter_ns()
                    end_time = _wall_time_seconds()
                    duration_ms = _duration_ms_from_perf(start_perf_ns, end_perf_ns)

                    popped_span_id = TraceManager.pop_span_context()

                    # Capture local variables FIRST (for custom input/output variable lookup)
                    local_vars = {}
                    try:
                        frame = inspect.currentframe()
                        if frame and frame.f_back:
                            local_vars = frame.f_back.f_locals.copy()
                    except Exception:
                        pass

                    # Resolve custom input/output if provided (can reference local variables)
                    custom_input = None
                    if input:
                        if callable(input):
                            # Check callable signature to support both 2-arg and 3-arg lambdas
                            try:
                                sig = inspect.signature(input)
                                if len(sig.parameters) >= 3:
                                    custom_input = input(args, kwargs, result)
                                else:
                                    custom_input = input(args, kwargs)
                            except Exception:
                                # Fallback to 3-arg call
                                custom_input = input(args, kwargs, result)
                        else:
                            # Resolve string input as variable name (locals/kwargs) or literal
                            custom_input = _resolve_custom_value(input, args, kwargs, result, local_vars)
                    else:
                        # No custom input provided - create merged JSON from kwargs + selective local_vars
                        merged_input = {}

                        # Map positional args to parameter names
                        try:
                            sig = inspect.signature(func)
                            param_names = list(sig.parameters.keys())
                            args_for_params = args
                            # Skip 'self' and 'cls' parameters
                            if param_names and param_names[0] in ("self", "cls"):
                                param_names = param_names[1:]
                                args_for_params = args[1:]
                            # Map positional args to param names
                            for i, arg in enumerate(args_for_params):
                                if i < len(param_names):
                                    merged_input[param_names[i]] = arg
                        except Exception:
                            pass

                        # Add kwargs (function parameters)
                        if kwargs:
                            merged_input.update(kwargs)
                        # Add captured local variables based on capture_locals and capture_self flags
                        if capture_locals or capture_self:
                            # If capture_locals is True, add ALL local variables
                            # If capture_self is True, only add 'self' if present
                            if capture_locals:
                                if local_vars:
                                    merged_input.update(local_vars)
                            elif capture_self and 'self' in local_vars:
                                # Only add self attributes when capture_self=True
                                self_obj = local_vars.get('self')
                                if self_obj is not None:
                                    try:
                                        self_attrs = {k: v for k, v in self_obj.__dict__.items() if not k.startswith('_')}
                                        merged_input.update(self_attrs)
                                    except Exception:
                                        pass
                        # Keep as object to preserve JSON structure
                        custom_input = merged_input
                    custom_output = _resolve_custom_value(output, args, kwargs, result, local_vars) if output else None

                    input_payload = ensure_json_object(
                        custom_input if custom_input is not None else _build_function_input_data(
                            args, kwargs, local_vars, capture_locals, capture_self, func
                        ),
                        key="input",
                    )

                    output_value = custom_output if custom_output is not None else result
                    if error:
                        output_value = None
                    output_payload = ensure_json_object(output_value, key="output")

                    # Build final metadata, injecting captured local_variables
                    final_metadata = dict(metadata or {})
                    explicit_locals = TraceManager._consume_captured_locals_for_span(popped_span_id)
                    if explicit_locals:
                        existing_locals = final_metadata.get("local_variables")
                        if isinstance(existing_locals, dict):
                            existing_locals.update(explicit_locals)
                            final_metadata["local_variables"] = existing_locals
                        else:
                            final_metadata["local_variables"] = explicit_locals

                    span_data = SpanData(
                        span_id=span_id,
                        span_name=span_name,
                        span_type="span",
                        parent_span_id=parent_span_id,
                        start_time=start_time,
                        end_time=end_time,
                        duration_ms=duration_ms,
                        input_data=input_payload,
                        output_data=output_payload,
                        error=str(error) if error else None,
                        metadata=final_metadata,
                        status="error" if error else "success",
                        status_message=str(error) if error else None,
                        pii_protection=pii_protection,
                    )

                    TraceManager.add_span(span_data)

                    if pending_added:
                        TraceManager._decrement_pending()

            return async_wrapper

        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                # Track spans even after finalization (for late spans)
                if not TraceManager.can_track_span():
                    return func(*args, **kwargs)

                pending_added = TraceManager._increment_pending_if_active()

                span_id = uuid.uuid4().hex
                parent_span_id = TraceManager.get_current_parent_span_id()
                start_perf_ns = time.perf_counter_ns()
                start_time = _wall_time_seconds()

                TraceManager.push_span_context(span_id)

                error = None
                result = None

                try:
                    result = func(*args, **kwargs)
                    return result
                except Exception as e:
                    error = e
                    raise
                finally:
                    end_perf_ns = time.perf_counter_ns()
                    end_time = _wall_time_seconds()
                    duration_ms = _duration_ms_from_perf(start_perf_ns, end_perf_ns)

                    popped_span_id = TraceManager.pop_span_context()

                    # Capture local variables FIRST (for custom input/output variable lookup)
                    local_vars = {}
                    try:
                        frame = inspect.currentframe()
                        if frame and frame.f_back:
                            local_vars = frame.f_back.f_locals.copy()
                    except Exception:
                        pass

                    # Resolve custom input/output if provided (can reference local variables)
                    custom_input = None
                    if input:
                        if callable(input):
                            # Check callable signature to support both 2-arg and 3-arg lambdas
                            try:
                                sig = inspect.signature(input)
                                if len(sig.parameters) >= 3:
                                    custom_input = input(args, kwargs, result)
                                else:
                                    custom_input = input(args, kwargs)
                            except Exception:
                                # Fallback to 3-arg call
                                custom_input = input(args, kwargs, result)
                        else:
                            # Resolve string input as variable name (locals/kwargs) or literal
                            custom_input = _resolve_custom_value(input, args, kwargs, result, local_vars)
                    else:
                        # No custom input provided - create merged JSON from kwargs + selective local_vars
                        merged_input = {}

                        # Map positional args to parameter names
                        try:
                            sig = inspect.signature(func)
                            param_names = list(sig.parameters.keys())
                            args_for_params = args
                            # Skip 'self' and 'cls' parameters
                            if param_names and param_names[0] in ("self", "cls"):
                                param_names = param_names[1:]
                                args_for_params = args[1:]
                            # Map positional args to param names
                            for i, arg in enumerate(args_for_params):
                                if i < len(param_names):
                                    merged_input[param_names[i]] = arg
                        except Exception:
                            pass

                        # Add kwargs (function parameters)
                        if kwargs:
                            merged_input.update(kwargs)

                        # Add captured local variables based on capture_locals and capture_self flags
                        if capture_locals or capture_self:
                            # If capture_locals is True, add ALL local variables
                            # If capture_self is True, only add 'self' if present
                            if capture_locals:
                                if local_vars:
                                    merged_input.update(local_vars)
                            elif capture_self and 'self' in local_vars:
                                # Only add self attributes when capture_self=True
                                self_obj = local_vars.get('self')
                                if self_obj is not None:
                                    try:
                                        self_attrs = {k: v for k, v in self_obj.__dict__.items() if not k.startswith('_')}
                                        merged_input.update(self_attrs)
                                    except Exception:
                                        pass
                        # Keep as object to preserve JSON structure
                        custom_input = merged_input
                    custom_output = _resolve_custom_value(output, args, kwargs, result, local_vars) if output else None

                    input_payload = ensure_json_object(
                        custom_input if custom_input is not None else _build_function_input_data(
                            args, kwargs, local_vars, capture_locals, capture_self, func
                        ),
                        key="input",
                    )

                    output_value = custom_output if custom_output is not None else result
                    if error:
                        output_value = None
                    output_payload = ensure_json_object(output_value, key="output")

                    # Build final metadata, injecting captured local_variables
                    final_metadata = dict(metadata or {})
                    explicit_locals = TraceManager._consume_captured_locals_for_span(popped_span_id)
                    if explicit_locals:
                        existing_locals = final_metadata.get("local_variables")
                        if isinstance(existing_locals, dict):
                            existing_locals.update(explicit_locals)
                            final_metadata["local_variables"] = existing_locals
                        else:
                            final_metadata["local_variables"] = explicit_locals

                    span_data = SpanData(
                        span_id=span_id,
                        span_name=span_name,
                        span_type="span",
                        parent_span_id=parent_span_id,
                        start_time=start_time,
                        end_time=end_time,
                        duration_ms=duration_ms,
                        input_data=input_payload,
                        output_data=output_payload,
                        error=str(error) if error else None,
                        metadata=final_metadata,
                        status="error" if error else "success",
                        status_message=str(error) if error else None,
                        pii_protection=pii_protection,
                    )

                    TraceManager.add_span(span_data)

                    if pending_added:
                        TraceManager._decrement_pending()

            return sync_wrapper

    return decorator
