# novaims-bcwds

BCwDS Python package developed at NOVA IMS.

## Installation

```bash
pip install novaims-bcwds
```