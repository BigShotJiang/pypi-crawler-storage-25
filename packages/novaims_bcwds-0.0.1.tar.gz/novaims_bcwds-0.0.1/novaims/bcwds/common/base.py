# File with most basic functions

def hello( name ):
    print( "Hello, " + name + "!. Welcome to Business Cases with Data Science Class." )

def version():
    from importlib.metadata import version
    return "novaims-bcwds v. " + version('novaims-bcwds')
