from importlib.metadata import metadata, PackageNotFoundError

PACKAGE_NAME = "novaims-bcwds"

try:
    meta = metadata(PACKAGE_NAME)

    __title__ = meta.get("Name")
    __version__ = meta.get("Version")
    __license__ = meta.get("License", "MIT")

except PackageNotFoundError:
    __title__ = PACKAGE_NAME
    __version__ = "0.0.1"
    __license__ = "MIT"