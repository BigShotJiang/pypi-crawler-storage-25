//! Live integration tests against real exchange APIs.
//!
//! These tests hit production endpoints — they are **not** run in CI.
//!
//! ## Running
//!
//! Unauthenticated (market data only):
//!   OPENPX_LIVE_TESTS=1 cargo test -p openpx --test live -- --nocapture
//!
//! Single exchange:
//!   OPENPX_LIVE_TESTS=1 cargo test -p openpx --test live kalshi -- --nocapture
//!
//! With auth (enables balance/position/fill tests):
//!   OPENPX_LIVE_TESTS=1 \
//!   KALSHI_API_KEY_ID=... KALSHI_PRIVATE_KEY_PEM=... \
//!   cargo test -p openpx --test live kalshi -- --nocapture

use std::env;
use std::time::Duration;

use openpx::{ExchangeInner, WebSocketInner};
use px_core::TradesRequest;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Skip the test unless OPENPX_LIVE_TESTS=1.
/// Automatically loads `.env` from the workspace root so contributors
/// only need to set credentials there.
fn require_live() -> bool {
    // Load .env once (no-op if already loaded or file missing)
    let _ = dotenvy::dotenv();
    env::var("OPENPX_LIVE_TESTS").is_ok_and(|v| v == "1")
}

/// Build config JSON from env vars for a given exchange.
fn make_exchange_config(id: &str) -> serde_json::Value {
    let mut obj = serde_json::Map::new();
    let vars: &[(&str, &str)] = match id {
        "kalshi" => &[
            ("KALSHI_API_KEY_ID", "api_key_id"),
            ("KALSHI_PRIVATE_KEY_PEM", "private_key_pem"),
            ("KALSHI_PRIVATE_KEY_PATH", "private_key_path"),
        ],
        "polymarket" => &[
            ("POLYMARKET_PRIVATE_KEY", "private_key"),
            ("POLYMARKET_FUNDER", "funder"),
            ("POLYMARKET_API_KEY", "api_key"),
            ("POLYMARKET_API_SECRET", "api_secret"),
            ("POLYMARKET_API_PASSPHRASE", "api_passphrase"),
        ],
        _ => &[],
    };
    for (env_key, config_key) in vars {
        if let Ok(v) = env::var(env_key) {
            obj.insert((*config_key).into(), v.into());
        }
    }
    serde_json::Value::Object(obj)
}

/// Build an exchange from env vars. Returns None if required vars missing.
fn make_exchange(id: &str) -> Option<ExchangeInner> {
    ExchangeInner::new(id, make_exchange_config(id)).ok()
}

/// Returns true if the exchange has auth credentials configured.
fn is_authenticated(exchange: &ExchangeInner) -> bool {
    let info = exchange.describe();
    info.has_create_order
}

/// Helper: returns true if error message indicates auth failure.
fn is_auth_error(e: &px_core::error::OpenPxError) -> bool {
    let msg = format!("{e:?}");
    msg.contains("uthent") || msg.contains("Unauthorized") || msg.contains("403")
}

/// Helper: returns true if error indicates API unreachable.
fn is_network_error(e: &px_core::error::OpenPxError) -> bool {
    let msg = format!("{e:?}");
    msg.contains("http error") || msg.contains("timed out") || msg.contains("connection")
}

/// Helper: returns true if error indicates invalid input.
fn is_invalid_input(e: &px_core::error::OpenPxError) -> bool {
    format!("{e:?}").contains("InvalidInput") || format!("{e:?}").contains("invalid input")
}

/// Helper: returns true if error indicates a config or SDK initialization failure.
fn is_config_error(e: &px_core::error::OpenPxError) -> bool {
    let msg = format!("{e:?}");
    msg.contains("config error")
        || msg.contains("Validation")
        || msg.contains("private key required")
}

/// Helper: returns true if error indicates rate limiting.
fn is_rate_limited(e: &px_core::error::OpenPxError) -> bool {
    let msg = format!("{e:?}");
    msg.contains("rate limit") || msg.contains("429") || msg.contains("RateLimited")
}

// ---------------------------------------------------------------------------
// Macros for per-exchange test generation
// ---------------------------------------------------------------------------

macro_rules! exchange_tests {
    ($exchange_id:ident) => {
        mod $exchange_id {
            use super::*;

            fn get_exchange() -> Option<ExchangeInner> {
                if !require_live() {
                    return None;
                }
                make_exchange(stringify!($exchange_id))
            }

            // ==================================================================
            // Unauthenticated — Exchange metadata
            // ==================================================================

            #[tokio::test]
            async fn describe() {
                let Some(ex) = get_exchange() else { return };
                let info = ex.describe();
                assert_eq!(info.id, stringify!($exchange_id));
                assert!(!info.name.is_empty());
                assert!(info.has_fetch_markets);
                // All exchanges should support single market fetch
                assert!(
                    info.has_fetch_markets,
                    "all exchanges must support fetch_markets"
                );
            }

            #[tokio::test]
            async fn describe_capabilities_consistent() {
                let Some(ex) = get_exchange() else { return };
                let info = ex.describe();
                // If an exchange has create_order, it must also have cancel_order
                if info.has_create_order {
                    assert!(
                        info.has_cancel_order,
                        "exchange with create_order must support cancel_order"
                    );
                }
                // If an exchange has websocket, it should report so
                // (just verify the field exists and is a bool — no panic)
                let _ = info.has_websocket;
            }

            // ==================================================================
            // Unauthenticated — Market data
            // ==================================================================

            #[tokio::test]
            async fn fetch_markets() {
                let Some(ex) = get_exchange() else { return };
                let result = ex.fetch_markets(&Default::default()).await;
                let (markets, cursor) = match result {
                    Ok(r) => r,
                    Err(e) if is_auth_error(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_markets: requires auth",
                            stringify!($exchange_id)
                        );
                        return;
                    }
                    Err(e) if is_network_error(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_markets: API unreachable: {e}",
                            stringify!($exchange_id)
                        );
                        return;
                    }
                    Err(e) => panic!("fetch_markets failed: {e:?}"),
                };
                eprintln!(
                    "\n=== {}: {} markets, cursor={:?} ===",
                    stringify!($exchange_id),
                    markets.len(),
                    cursor,
                );
                for m in markets.iter().take(3) {
                    eprintln!(
                        "  {} | {:50} | status={:?} | event={:?} | vol={:.0}",
                        m.ticker, m.title, m.status, m.event_ticker, m.volume
                    );
                }
                if markets.len() > 3 {
                    eprintln!("  ... and {} more", markets.len() - 3);
                }
                assert!(!markets.is_empty(), "expected at least 1 market");
                for m in &markets {
                    assert!(!m.ticker.is_empty(), "market ticker should not be empty");
                    assert!(!m.title.is_empty(), "market title should not be empty");
                    assert!(!m.outcomes.is_empty(), "market should have outcomes");
                }
            }

            #[tokio::test]
            async fn fetch_markets_field_invariants() {
                let Some(ex) = get_exchange() else { return };
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) if !m.is_empty() => m,
                    _ => return,
                };

                for m in &markets {
                    // openpx_id must be {exchange}:{ticker}
                    let expected_openpx = format!("{}:{}", stringify!($exchange_id), m.ticker);
                    assert_eq!(
                        m.openpx_id, expected_openpx,
                        "openpx_id format mismatch for market {}",
                        m.ticker
                    );

                    // exchange field must match
                    assert_eq!(
                        m.exchange,
                        stringify!($exchange_id),
                        "exchange field mismatch for market {}",
                        m.ticker
                    );

                    // outcomes should be non-empty
                    assert!(
                        !m.outcomes.is_empty(),
                        "market {} should have outcomes",
                        m.ticker
                    );

                    // binary markets should have exactly 2 outcomes
                    if m.outcomes.len() == 2 {
                        assert!(m.is_binary(), "2-outcome market should report is_binary()");
                    }

                    // volume should be non-negative
                    assert!(
                        m.volume >= 0.0,
                        "market {} volume should be non-negative, got {}",
                        m.ticker,
                        m.volume
                    );

                    // outcome prices should be in [0, 1] range when present
                    for o in &m.outcomes {
                        if let Some(p) = o.price {
                            assert!(
                                (0.0..=1.0).contains(&p),
                                "market {} outcome '{}' price {} out of [0,1] range",
                                m.ticker,
                                o.label,
                                p
                            );
                        }
                    }

                    // tick_size, if present, should be a positive small step
                    if let Some(step) = m.tick_size {
                        assert!(
                            step > 0.0 && step <= 0.1,
                            "market {} tick step {} out of expected range",
                            m.ticker,
                            step
                        );
                    }
                }
            }

            #[tokio::test]
            async fn fetch_markets_by_ticker() {
                let Some(ex) = get_exchange() else { return };
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) => m,
                    Err(_) => return, // covered by fetch_markets test
                };
                if markets.is_empty() {
                    return;
                }
                let target_ticker = markets[0].ticker.clone();
                let params = px_core::FetchMarketsParams {
                    market_tickers: vec![target_ticker.clone()],
                    status: Some(px_core::MarketStatusFilter::All),
                    ..Default::default()
                };
                match ex.fetch_markets(&params).await {
                    Ok((singletons, _)) if !singletons.is_empty() => {
                        assert!(singletons.iter().any(|m| m.ticker == target_ticker));
                    }
                    Ok(_) => panic!(
                        "fetch_markets with explicit ticker returned empty for {target_ticker}"
                    ),
                    Err(e) if is_rate_limited(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_markets_by_ticker: rate limited",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) => panic!("fetch_markets-by-ticker failed: {e:?}"),
                }
            }

            #[tokio::test]
            async fn fetch_markets_by_ticker_consistency() {
                let Some(ex) = get_exchange() else { return };
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) if !m.is_empty() => m,
                    _ => return,
                };
                // Pick a market from the list and fetch individually via market_tickers param
                let target = &markets[0];
                let params = px_core::FetchMarketsParams {
                    market_tickers: vec![target.ticker.clone()],
                    status: Some(px_core::MarketStatusFilter::All),
                    ..Default::default()
                };
                let singletons = match ex.fetch_markets(&params).await {
                    Ok((m, _)) => m,
                    Err(_) => return,
                };
                let Some(single) = singletons.iter().find(|m| m.ticker == target.ticker) else {
                    return;
                };

                // Core identity fields must match
                assert_eq!(single.ticker, target.ticker, "ticker mismatch");
                assert_eq!(single.openpx_id, target.openpx_id, "openpx_id mismatch");
                assert_eq!(single.exchange, target.exchange, "exchange mismatch");
                assert_eq!(single.title, target.title, "title mismatch");
                assert_eq!(single.outcomes, target.outcomes, "outcomes mismatch");
                assert_eq!(
                    single.market_type, target.market_type,
                    "market_type mismatch"
                );
            }

            #[tokio::test]
            async fn fetch_markets_invalid_ticker() {
                let Some(ex) = get_exchange() else { return };
                let params = px_core::FetchMarketsParams {
                    market_tickers: vec!["__nonexistent_market_id_12345__".to_string()],
                    status: Some(px_core::MarketStatusFilter::All),
                    ..Default::default()
                };
                // Either an empty result or an error is acceptable — the API
                // must not panic and must not surface a false-positive market.
                if let Ok((markets, _)) = ex.fetch_markets(&params).await {
                    assert!(
                        markets.is_empty(),
                        "fetch_markets with invalid ticker should return empty, got {}",
                        markets.len()
                    );
                }
            }

            // ==================================================================
            // Unauthenticated — Orderbook
            // ==================================================================

            #[tokio::test]
            async fn fetch_orderbook() {
                let Some(ex) = get_exchange() else { return };
                if !ex.describe().has_fetch_orderbook {
                    return;
                }
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) if !m.is_empty() => m,
                    _ => return,
                };

                // Pick the first outcome's asset_id: Kalshi returns the market ticker,
                // Polymarket returns the per-outcome token id.
                let m = markets
                    .iter()
                    .find(|m| m.is_binary())
                    .unwrap_or(&markets[0]);
                let asset_id = m
                    .outcomes
                    .first()
                    .and_then(|o| o.token_id.clone())
                    .unwrap_or_else(|| m.ticker.clone());

                match ex.fetch_orderbook(&asset_id).await {
                    Ok(book) => {
                        let _ = &book.bids;
                        let _ = &book.asks;
                    }
                    Err(e) if is_auth_error(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_orderbook: requires auth",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) if format!("{e:?}").contains("NotFound") => {
                        eprintln!(
                            "SKIP {}/fetch_orderbook: market not found on CLOB",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) if is_invalid_input(&e) => {
                        eprintln!("SKIP {}/fetch_orderbook: {e}", stringify!($exchange_id));
                    }
                    Err(e) if is_rate_limited(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_orderbook: rate limited",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) => panic!("fetch_orderbook failed: {e:?}"),
                }
            }

            #[tokio::test]
            async fn fetch_orderbook_structure() {
                let Some(ex) = get_exchange() else { return };
                if !ex.describe().has_fetch_orderbook {
                    return;
                }
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) if !m.is_empty() => m,
                    _ => return,
                };

                // Try a few markets to find one with orderbook data
                for market in markets.iter().take(5) {
                    let asset_id = market
                        .outcomes
                        .first()
                        .and_then(|o| o.token_id.clone())
                        .unwrap_or_else(|| market.ticker.clone());
                    let book = match ex.fetch_orderbook(&asset_id).await {
                        Ok(b) if b.has_data() => b,
                        _ => continue,
                    };

                    // Bids should be sorted descending (highest first)
                    for window in book.bids.windows(2) {
                        assert!(
                            window[0].price >= window[1].price,
                            "bids should be sorted descending: {} >= {}",
                            window[0].price,
                            window[1].price
                        );
                    }

                    // Asks should be sorted ascending (lowest first)
                    for window in book.asks.windows(2) {
                        assert!(
                            window[0].price <= window[1].price,
                            "asks should be sorted ascending: {} <= {}",
                            window[0].price,
                            window[1].price
                        );
                    }

                    // All prices should be in [0, 1] range
                    for level in book.bids.iter().chain(book.asks.iter()) {
                        let price = level.price.to_f64();
                        assert!(
                            (0.0..=1.0).contains(&price),
                            "orderbook price {} out of [0,1] range",
                            price
                        );
                        assert!(level.size > 0.0, "orderbook level size should be positive");
                    }

                    // Best bid should be <= best ask (no crossed book)
                    if let (Some(best_bid), Some(best_ask)) = (book.best_bid(), book.best_ask()) {
                        assert!(
                            best_bid <= best_ask,
                            "crossed book: best_bid {} > best_ask {}",
                            best_bid,
                            best_ask
                        );
                    }

                    // Spread should be non-negative
                    if let Some(spread) = book.spread() {
                        assert!(
                            spread >= 0.0,
                            "spread should be non-negative, got {}",
                            spread
                        );
                    }

                    // Mid price should be between bid and ask
                    if let (Some(best_bid), Some(mid), Some(best_ask)) =
                        (book.best_bid(), book.mid_price(), book.best_ask())
                    {
                        assert!(
                            mid >= best_bid && mid <= best_ask,
                            "mid {} not between bid {} and ask {}",
                            mid,
                            best_bid,
                            best_ask
                        );
                    }

                    // Found a good book, test passed
                    return;
                }

                eprintln!(
                    "WARN: {}/fetch_orderbook_structure: no market with orderbook data found",
                    stringify!($exchange_id)
                );
            }

            // ==================================================================
            // Unauthenticated — Historical data
            // ==================================================================

            #[tokio::test]
            async fn fetch_trades() {
                let Some(ex) = get_exchange() else { return };
                if !ex.describe().has_fetch_trades {
                    return;
                }
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) if !m.is_empty() => m,
                    _ => return,
                };
                match ex
                    .fetch_trades(TradesRequest {
                        asset_id: markets[0].ticker.clone(),
                        limit: Some(10),
                        ..Default::default()
                    })
                    .await
                {
                    Ok((trades, _cursor)) => {
                        for t in &trades {
                            assert!(t.price >= 0.0 && t.price <= 1.0, "price should be 0..1");
                            assert!(t.size > 0.0, "size should be positive");
                            assert!(!t.id.is_empty(), "id required");
                        }
                    }
                    Err(e) => panic!("fetch_trades failed: {e:?}"),
                }
            }

            #[tokio::test]
            async fn fetch_trades_with_limit() {
                let Some(ex) = get_exchange() else { return };
                if !ex.describe().has_fetch_trades {
                    return;
                }
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) if !m.is_empty() => m,
                    _ => return,
                };

                // Request a small limit and verify we don't exceed it
                let limit = 5;
                match ex
                    .fetch_trades(TradesRequest {
                        asset_id: markets[0].ticker.clone(),
                        limit: Some(limit),
                        ..Default::default()
                    })
                    .await
                {
                    Ok((trades, _cursor)) => {
                        assert!(
                            trades.len() <= limit,
                            "got {} trades but limit was {}",
                            trades.len(),
                            limit
                        );
                    }
                    Err(_) => {} // Not all markets have trades
                }
            }

            #[tokio::test]
            async fn fetch_trades_pagination() {
                let Some(ex) = get_exchange() else { return };
                if !ex.describe().has_fetch_trades {
                    return;
                }
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) if !m.is_empty() => m,
                    _ => return,
                };

                // Fetch first page
                let (page1, cursor) = match ex
                    .fetch_trades(TradesRequest {
                        asset_id: markets[0].ticker.clone(),
                        limit: Some(5),
                        ..Default::default()
                    })
                    .await
                {
                    Ok(r) => r,
                    Err(_) => return,
                };

                if page1.is_empty() {
                    return;
                }

                // If we got a cursor, fetch the next page
                if let Some(cursor) = cursor {
                    match ex
                        .fetch_trades(TradesRequest {
                            asset_id: markets[0].ticker.clone(),
                            limit: Some(5),
                            cursor: Some(cursor),
                            ..Default::default()
                        })
                        .await
                    {
                        Ok((page2, _)) => {
                            if !page2.is_empty() {
                                assert_ne!(
                                    page1[0].id, page2[0].id,
                                    "pagination returned same first trade"
                                );
                            }
                        }
                        Err(_) => {} // Cursor may have expired
                    }
                }
            }

            // ==================================================================
            // Authenticated — Read-only account data
            // ==================================================================

            #[tokio::test]
            async fn fetch_balance() {
                let Some(ex) = get_exchange() else { return };
                if !is_authenticated(&ex) || !ex.describe().has_fetch_balance {
                    return;
                }
                match ex.fetch_balance().await {
                    Ok(balance) => {
                        assert!(
                            !balance.is_empty(),
                            "authenticated account should have at least one balance entry"
                        );
                        for (_asset, amount) in &balance {
                            assert!(*amount >= 0.0, "balance should be non-negative");
                        }
                    }
                    Err(e) if is_config_error(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_balance: config/init error: {e}",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) if is_auth_error(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_balance: auth failed",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) => panic!("fetch_balance failed: {e:?}"),
                }
            }

            #[tokio::test]
            async fn fetch_balance_consistency() {
                let Some(ex) = get_exchange() else { return };
                if !is_authenticated(&ex) || !ex.describe().has_fetch_balance {
                    return;
                }

                // Fetch balance twice — values should be consistent (same account)
                let balance1 = match ex.fetch_balance().await {
                    Ok(b) => b,
                    Err(_) => return,
                };
                let balance2 = match ex.fetch_balance().await {
                    Ok(b) => b,
                    Err(_) => return,
                };

                // Same keys should be present
                assert_eq!(
                    balance1.keys().collect::<std::collections::HashSet<_>>(),
                    balance2.keys().collect::<std::collections::HashSet<_>>(),
                    "balance keys should be consistent across calls"
                );
            }

            #[tokio::test]
            async fn refresh_balance() {
                let Some(ex) = get_exchange() else { return };
                if !is_authenticated(&ex) || !ex.describe().has_refresh_balance {
                    return;
                }
                match ex.refresh_balance().await {
                    Ok(()) => {}
                    Err(e) if is_config_error(&e) => {
                        eprintln!(
                            "SKIP {}/refresh_balance: config/init error: {e}",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) => panic!("refresh_balance failed: {e:?}"),
                }
            }

            #[tokio::test]
            async fn fetch_positions() {
                let Some(ex) = get_exchange() else { return };
                if !is_authenticated(&ex) || !ex.describe().has_fetch_positions {
                    return;
                }
                let positions = ex
                    .fetch_positions(None)
                    .await
                    .expect("fetch_positions failed");
                for p in &positions {
                    assert!(
                        !p.market_ticker.is_empty(),
                        "position market_ticker should not be empty"
                    );
                    assert!(
                        !p.outcome.is_empty(),
                        "position outcome should not be empty"
                    );
                    assert!(
                        p.size >= 0.0,
                        "position size should be non-negative, got {}",
                        p.size
                    );
                    assert!(
                        p.average_price >= 0.0 && p.average_price <= 1.0,
                        "position average_price {} out of [0,1] range",
                        p.average_price
                    );
                    assert!(
                        p.current_price >= 0.0 && p.current_price <= 1.0,
                        "position current_price {} out of [0,1] range",
                        p.current_price
                    );
                }
            }

            #[tokio::test]
            async fn fetch_positions_computed_fields() {
                let Some(ex) = get_exchange() else { return };
                if !is_authenticated(&ex) || !ex.describe().has_fetch_positions {
                    return;
                }
                let positions = match ex.fetch_positions(None).await {
                    Ok(p) if !p.is_empty() => p,
                    _ => return,
                };

                for p in &positions {
                    // Verify computed fields are consistent
                    let expected_cost = p.size * p.average_price;
                    let expected_value = p.size * p.current_price;
                    let expected_pnl = expected_value - expected_cost;

                    assert!(
                        (p.cost_basis() - expected_cost).abs() < 1e-10,
                        "cost_basis() mismatch"
                    );
                    assert!(
                        (p.current_value() - expected_value).abs() < 1e-10,
                        "current_value() mismatch"
                    );
                    assert!(
                        (p.unrealized_pnl() - expected_pnl).abs() < 1e-10,
                        "unrealized_pnl() mismatch"
                    );
                }
            }

            #[tokio::test]
            async fn fetch_open_orders() {
                let Some(ex) = get_exchange() else { return };
                if !is_authenticated(&ex) {
                    return;
                }
                match ex.fetch_open_orders(None).await {
                    Ok(orders) => {
                        for o in &orders {
                            assert!(!o.id.is_empty(), "order id should not be empty");
                            assert!(
                                !o.market_ticker.is_empty(),
                                "order market_ticker should not be empty"
                            );
                            assert!(
                                o.price >= 0.0 && o.price <= 1.0,
                                "order price {} out of [0,1] range",
                                o.price
                            );
                            assert!(o.size > 0.0, "order size should be positive");
                            assert!(
                                o.is_active(),
                                "open order should have active status, got {:?}",
                                o.status
                            );
                        }
                    }
                    Err(e) if is_auth_error(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_open_orders: auth failed",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) if is_config_error(&e) => {
                        eprintln!(
                            "SKIP {}/fetch_open_orders: config/init error: {e}",
                            stringify!($exchange_id)
                        );
                    }
                    Err(e) => panic!("fetch_open_orders failed: {e:?}"),
                }
            }

            #[tokio::test]
            async fn fetch_fills() {
                let Some(ex) = get_exchange() else { return };
                if !is_authenticated(&ex) || !ex.describe().has_fetch_fills {
                    return;
                }
                let fills = ex
                    .fetch_fills(None, Some(5))
                    .await
                    .expect("fetch_fills failed");
                for f in &fills {
                    assert!(!f.fill_id.is_empty(), "fill_id should not be empty");
                    assert!(
                        f.price >= 0.0 && f.price <= 1.0,
                        "fill price should be 0..1"
                    );
                    assert!(f.size > 0.0, "fill size should be positive");
                    assert!(f.fee >= 0.0, "fill fee should be non-negative");
                    assert!(!f.order_id.is_empty(), "fill order_id should not be empty");
                    assert!(
                        !f.market_ticker.is_empty(),
                        "fill market_ticker should not be empty"
                    );
                    assert!(!f.outcome.is_empty(), "fill outcome should not be empty");
                }
            }

            #[tokio::test]
            async fn fetch_fills_with_limit() {
                let Some(ex) = get_exchange() else { return };
                if !is_authenticated(&ex) || !ex.describe().has_fetch_fills {
                    return;
                }
                let limit = 3;
                let fills = match ex.fetch_fills(None, Some(limit)).await {
                    Ok(f) => f,
                    Err(_) => return,
                };
                assert!(
                    fills.len() <= limit,
                    "got {} fills but limit was {}",
                    fills.len(),
                    limit
                );
            }

            // ==================================================================
            // WebSocket — connect, subscribe, receive at least one update
            // ==================================================================

            #[tokio::test]
            async fn websocket_orderbook_stream() {
                let Some(ex) = get_exchange() else { return };
                if !ex.describe().has_websocket {
                    return;
                }

                // All exchanges except polymarket require auth for WebSocket
                if !is_authenticated(&ex) && stringify!($exchange_id) != "polymarket" {
                    eprintln!("SKIP {}/websocket: requires auth", stringify!($exchange_id));
                    return;
                }

                // Get a market to subscribe to
                let markets = match ex.fetch_markets(&Default::default()).await {
                    Ok((m, _)) if !m.is_empty() => m,
                    _ => return,
                };
                let market_ticker = &markets[0].ticker;

                use px_core::OrderBookWebSocket;

                // Install rustls crypto provider (needed for TLS connections in tests)
                let _ = rustls::crypto::ring::default_provider().install_default();

                let config = make_exchange_config(stringify!($exchange_id));
                let mut ws = match WebSocketInner::new(stringify!($exchange_id), config) {
                    Ok(ws) => ws,
                    Err(e) => {
                        eprintln!("SKIP {}/websocket: {e}", stringify!($exchange_id));
                        return;
                    }
                };

                let updates = ws.updates().expect("updates() taken twice");
                let target = market_ticker.clone();

                if let Err(e) = ws.connect().await {
                    eprintln!(
                        "SKIP {}/websocket: connect failed: {e}",
                        stringify!($exchange_id)
                    );
                    return;
                }
                ws.subscribe(market_ticker)
                    .await
                    .expect("ws subscribe failed");

                // Wait up to 15s for the next snapshot/delta on the requested market.
                let deadline = std::time::Instant::now() + Duration::from_secs(15);
                let mut got_book_event = false;
                while std::time::Instant::now() < deadline {
                    let remaining = deadline - std::time::Instant::now();
                    let result = tokio::time::timeout(remaining, updates.next()).await;
                    match result {
                        Ok(Some(px_core::WsUpdate::Snapshot {
                            market_id: m, book, ..
                        })) if m == target => {
                            assert!(
                                !book.bids.is_empty() || !book.asks.is_empty(),
                                "snapshot should have some levels"
                            );
                            got_book_event = true;
                            break;
                        }
                        Ok(Some(px_core::WsUpdate::Delta {
                            market_id: m,
                            changes,
                            ..
                        })) if m == target => {
                            assert!(!changes.is_empty(), "delta should have at least one change");
                            got_book_event = true;
                            break;
                        }
                        Ok(Some(_)) => continue, // other markets / event types
                        Ok(None) => panic!("ws update stream ended unexpectedly"),
                        Err(_) => break, // timed out
                    }
                }

                ws.disconnect().await.expect("ws disconnect failed");

                if !got_book_event {
                    eprintln!(
                        "WARN: no orderbook update within 15s for {} market {}",
                        stringify!($exchange_id),
                        market_ticker
                    );
                }
            }
        }
    };
}

// ---------------------------------------------------------------------------
// Generate tests for each exchange
// ---------------------------------------------------------------------------

exchange_tests!(kalshi);
exchange_tests!(polymarket);
