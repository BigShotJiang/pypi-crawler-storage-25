import pytest

from mosesaic.llm.provider import Capabilities
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry, _provider_tier


def make_registry() -> ProviderRegistry:
    registry = ProviderRegistry()
    registry.register(MockProvider(
        capabilities={
            "mock-cheap": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
            "mock-smart": Capabilities(
                vision=True, tools=True, thinking=True,
                context_k=200, cost_per_1m_input=5.00, cost_per_1m_output=15.00,
            ),
        }
    ))
    return registry


def test_find_cheapest_by_default():
    registry = make_registry()
    model_id, _ = registry.find(task_hint="general")
    assert model_id == "mock-cheap"


def test_find_prefers_thinking_for_reasoning():
    registry = make_registry()
    model_id, _ = registry.find(task_hint="reasoning")
    assert model_id == "mock-smart"


def test_find_filters_by_capability():
    registry = make_registry()
    model_id, _ = registry.find(require=["thinking"])
    assert model_id == "mock-smart"


def test_find_raises_when_no_model_meets_requirements():
    registry = make_registry()
    with pytest.raises(ValueError, match="No model satisfies"):
        registry.find(require=["thinking", "vision"], budget_usd=0.000001)


def test_find_filters_by_budget():
    registry = make_registry()
    # mock-smart estimated cost > 0.001 → filtered out
    model_id, _ = registry.find(budget_usd=0.01)
    assert model_id == "mock-cheap"


def test_all_models_returns_both():
    registry = make_registry()
    models = registry.all_models()
    assert "mock-cheap" in models
    assert "mock-smart" in models


# ── Provider tiering ──────────────────────────────────────────────────────────

class NamedMockProvider(MockProvider):
    """MockProvider with a configurable name to simulate real providers."""
    def __init__(self, provider_name: str, **kwargs):
        super().__init__(**kwargs)
        self._name = provider_name

    @property
    def name(self) -> str:
        return self._name


def test_provider_tier_reasoning_prefers_anthropic_over_groq():
    """Anthropic should have lower (better) tier than groq for reasoning."""
    assert _provider_tier("anthropic", "reasoning") < _provider_tier("groq", "reasoning")


def test_provider_tier_fast_prefers_groq_over_anthropic():
    """Groq should have lower (better) tier than anthropic for cheap/extraction."""
    assert _provider_tier("groq", "cheap") < _provider_tier("anthropic", "cheap")
    assert _provider_tier("groq", "extraction") < _provider_tier("anthropic", "extraction")


def test_provider_tier_unknown_provider_gets_default():
    """Unknown provider names fall back to a sensible default tier."""
    tier = _provider_tier("unknown-provider", "reasoning")
    assert isinstance(tier, int)
    assert tier > 0


def test_reasoning_picks_anthropic_over_groq_non_thinking():
    """When only non-thinking models are available, anthropic wins over groq for reasoning."""
    registry = ProviderRegistry()
    registry.register(NamedMockProvider(
        "groq",
        capabilities={
            "groq-fast": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.10, cost_per_1m_output=0.10,
            ),
        },
    ))
    registry.register(NamedMockProvider(
        "anthropic",
        capabilities={
            "claude-sonnet": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=200, cost_per_1m_input=3.00, cost_per_1m_output=15.00,
            ),
        },
    ))
    model_id, provider = registry.find(task_hint="reasoning")
    assert provider.name == "anthropic"
    assert model_id == "claude-sonnet"


def test_cheap_picks_groq_over_anthropic():
    """For cheap tasks, groq wins even if anthropic is also registered."""
    registry = ProviderRegistry()
    registry.register(NamedMockProvider(
        "anthropic",
        capabilities={
            "claude-haiku": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=200, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
        },
    ))
    registry.register(NamedMockProvider(
        "groq",
        capabilities={
            "llama-fast": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=8, cost_per_1m_input=0.10, cost_per_1m_output=0.10,
            ),
        },
    ))
    model_id, provider = registry.find(task_hint="cheap")
    assert provider.name == "groq"


def test_reasoning_within_same_provider_prefers_expensive_model():
    """Within anthropic, more expensive (more capable) model should win for reasoning."""
    registry = ProviderRegistry()
    registry.register(NamedMockProvider(
        "anthropic",
        capabilities={
            "claude-haiku": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=200, cost_per_1m_input=0.25, cost_per_1m_output=1.25,
            ),
            "claude-opus": Capabilities(
                vision=False, tools=True, thinking=False,
                context_k=200, cost_per_1m_input=15.00, cost_per_1m_output=75.00,
            ),
        },
    ))
    model_id, _ = registry.find(task_hint="reasoning")
    assert model_id == "claude-opus"
