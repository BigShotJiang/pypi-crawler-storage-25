from __future__ import annotations

from mosesaic.llm.provider import Capabilities, LLMProvider

# Provider quality tiers per task category — lower number = more preferred.
# These reflect known capabilities: anthropic/openai excel at reasoning and
# complex tasks; groq/cerebras excel at speed and cost efficiency.
_TIER_REASONING: dict[str, int] = {
    "anthropic": 1,   # Best for reasoning, long-context, instruction following
    "openai": 2,      # Strong reasoning, reliable
    "openrouter": 3,  # Routes to various providers — quality varies
    "groq": 4,        # Fast but weaker on complex reasoning
    "cerebras": 5,    # Fast inference, limited model selection
    "ollama": 6,      # Local models — quality varies greatly
}

_TIER_FAST: dict[str, int] = {
    "groq": 1,        # Fastest inference, great for extraction/cheap tasks
    "cerebras": 1,    # Also very fast
    "ollama": 2,      # Free, local
    "openrouter": 3,  # Varies by routed provider
    "anthropic": 4,   # Capable but overkill for cheap tasks
    "openai": 4,      # Same
}

_TIER_GENERAL: dict[str, int] = {
    "groq": 1,        # Good value — fast, cheap, capable enough for most tasks
    "cerebras": 1,    # Same
    "anthropic": 2,   # High quality when you need it
    "openai": 2,      # Same
    "openrouter": 3,  # Varies
    "ollama": 4,      # Unpredictable quality
}


def _provider_tier(provider_name: str, task_hint: str) -> int:
    """Return quality tier for this provider given the task. Lower = more preferred."""
    name = provider_name.lower()
    if task_hint == "reasoning":
        return _TIER_REASONING.get(name, 5)
    if task_hint in ("cheap", "extraction"):
        return _TIER_FAST.get(name, 3)
    return _TIER_GENERAL.get(name, 3)  # general / vision


class ProviderRegistry:
    """Holds all registered LLM providers and their model capabilities.

    Usage:
        registry = ProviderRegistry()
        registry.register(AnthropicProvider(...))
        registry.register(OllamaProvider(...))

        model_id, provider = registry.find(
            task_hint="reasoning",
            budget_usd=0.10,
            require=["tools"],
        )
    """

    def __init__(self) -> None:
        self._providers: dict[str, LLMProvider] = {}
        # Flat map: model_id → (provider, capabilities)
        self._models: dict[str, tuple[LLMProvider, Capabilities]] = {}

    def register(self, provider: LLMProvider) -> None:
        """Register a provider and index all its models."""
        self._providers[provider.name] = provider
        for model_id, caps in provider.models.items():
            self._models[model_id] = (provider, caps)

    def find(
        self,
        task_hint: str = "general",
        budget_usd: float | None = None,
        require: list[str] | None = None,
        max_output_tokens: int = 4096,
    ) -> tuple[str, LLMProvider]:
        """Select the best model given routing constraints.

        Strategy:
        1. Filter out models that don't meet capability requirements
        2. Filter out models whose estimated cost exceeds budget_usd
        3. Prefer models matching task_hint (reasoning → thinking, extraction → cheap)
        4. Among remaining, pick cheapest that meets all constraints

        Raises ValueError if no model satisfies constraints.
        """
        require = require or []
        candidates: list[tuple[str, LLMProvider, Capabilities]] = []

        for model_id, (provider, caps) in self._models.items():
            if not caps.supports(require):
                continue
            if budget_usd is not None:
                # Estimate worst-case cost: max_output_tokens output
                estimated = caps.estimate_cost(
                    input_tokens=4096, output_tokens=max_output_tokens
                )
                if estimated > budget_usd:
                    continue
            candidates.append((model_id, provider, caps))

        if not candidates:
            raise ValueError(
                f"No model satisfies constraints: task_hint={task_hint!r}, "
                f"budget_usd={budget_usd}, require={require}"
            )

        # Routing preference by task_hint.
        #
        # Score = provider_tier * 10_000 ± cost_adjustment (lower score = more preferred).
        #
        # For "reasoning": pick highest-quality provider first, then most capable
        #   (expensive) model within that provider.  Thinking-cap models always win.
        # For "cheap"/"extraction": pick fastest/cheapest provider first, then
        #   cheapest model within that provider.
        # For "general": balanced — tier dominates but cost breaks ties.
        # For "vision": require vision capability; among those, use general tier.
        def score(item: tuple[str, LLMProvider, Capabilities]) -> float:
            model_id, provider, caps = item
            total_cost = caps.cost_per_1m_input + caps.cost_per_1m_output
            tier = _provider_tier(provider.name, task_hint)

            if task_hint == "reasoning":
                if caps.thinking:
                    return -100_000.0  # thinking model: always first regardless of tier
                # Within same tier, prefer pricier (more capable) models
                return tier * 10_000.0 - total_cost

            if task_hint in ("cheap", "extraction"):
                # Within same tier, prefer cheaper models
                return tier * 10_000.0 + total_cost

            if task_hint == "vision":
                if not caps.vision:
                    return 900_000.0   # push non-vision models to end
                return tier * 10_000.0 + total_cost

            # "general": tier first, then cost as tiebreaker (slightly prefer cheaper)
            return tier * 10_000.0 + total_cost * 0.1

        candidates.sort(key=lambda x: score(x))

        model_id, provider, _ = candidates[0]
        return model_id, provider

    def all_models(self) -> dict[str, Capabilities]:
        return {mid: caps for mid, (_, caps) in self._models.items()}

    def iter_models(self):
        """Yield (model_id, provider, capabilities) for all registered models."""
        for model_id, (provider, caps) in self._models.items():
            yield model_id, provider, caps
