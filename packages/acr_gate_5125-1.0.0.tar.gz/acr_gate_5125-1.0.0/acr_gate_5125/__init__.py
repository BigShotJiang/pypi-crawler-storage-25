"""Best Work Core"""
__version__ = "1.0.0"
