"""QuantOpt visualization package."""
