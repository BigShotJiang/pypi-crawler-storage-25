# Bitogin Studio v5.1.0

Professional AI coding agent for building production-ready Expo React Native, Flutter, Tauri desktop, and full-stack applications.

## Features
- **Cross-Platform Support**: Expo (Zero Android Studio required), Flutter, Tauri, and Supabase.
- **Automated CI/CD**: GitHub Actions, Docker, and docker-compose generation.
- **Deployment**: Integrated EAS builds, Vercel, and Netlify deployment.
- **Developer Experience**: Cursor/VS Code integration and GitHub repository management.
- **Interfaces**: High-performance CLI and Streamlit Web Dashboard.

## Installation
```bash
pip install bitogin-studio[web,voice]