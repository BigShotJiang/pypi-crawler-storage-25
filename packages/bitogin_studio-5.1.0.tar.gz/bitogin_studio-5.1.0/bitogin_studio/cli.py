import os
import sys
import yaml
import json
import subprocess
import shutil
from pathlib import Path
from typing import List, Dict, Any
from openai import OpenAI
from rich.console import Console
from rich.panel import Panel
from rich.live import Live
from rich.markdown import Markdown

console = Console()
CONFIG_PATH = Path.home() / ".bitogin" / "config.yaml"

DEFAULT_SYSTEM_PROMPT = """You are an expert full-stack AI coding agent. 
Your goal is to build production-ready, scalable, and investor-grade applications.
Follow best practices for Expo, Flutter, Tauri, and Supabase.
Ensure all code is linted, tested, and ready for deployment via Docker or CI/CD pipelines.
Always prioritize security and avoid dangerous commands."""

class BitoginAgent:
    def __init__(self):
        self.load_config()
        self.client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=self.config.get("api_key", "sk-or-v3-placeholder"),
        )
        self.model = self.config.get("model", "qwen/qwen-turbo-preview:free")
        self.history = [{"role": "system", "content": DEFAULT_SYSTEM_PROMPT}]

    def load_config(self):
        if not CONFIG_PATH.exists():
            CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
            default_config = {
                "api_key": "YOUR_OPENROUTER_KEY",
                "model": "qwen/qwen-max-preview:free",
                "github_token": ""
            }
            with open(CONFIG_PATH, "w") as f:
                yaml.dump(default_config, f)
        with open(CONFIG_PATH, "r") as f:
            self.config = yaml.safe_load(f)

    def run_command(self, command: str) -> str:
        forbidden = ["rm -rf /", "mkfs", "dd"]
        if any(f in command for f in forbidden):
            return "Error: Command blocked for security reasons."
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            return result.stdout if result.returncode == 0 else result.stderr
        except Exception as e:
            return str(e)

    def write_file(self, path: str, content: str) -> str:
        try:
            p = Path(path)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
            return f"Successfully wrote to {path}"
        except Exception as e:
            return str(e)

    def tools_definition(self) -> List[Dict]:
        return [
            {"type": "function", "function": {"name": "run_command", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
            {"type": "function", "function": {"name": "write_file", "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}}, "required": ["path", "content"]}}},
            {"type": "function", "function": {"name": "read_file", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
            {"type": "function", "function": {"name": "list_files", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
            {"type": "function", "function": {"name": "open_in_cursor", "parameters": {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]}}},
            {"type": "function", "function": {"name": "generate_dockerfile", "parameters": {"type": "object", "properties": {"stack": {"type": "string"}}, "required": ["stack"]}}},
            {"type": "function", "function": {"name": "expo_init", "parameters": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}}},
        ]

    def execute_tool(self, tool_name: str, args: Dict) -> str:
        if tool_name == "run_command": return self.run_command(args["command"])
        if tool_name == "write_file": return self.write_file(args["path"], args["content"])
        if tool_name == "read_file": return Path(args["path"]).read_text() if Path(args["path"]).exists() else "File not found"
        if tool_name == "list_files": return "\n".join([str(p) for p in Path(args["path"]).glob("*")])
        if tool_name == "open_in_cursor": return self.run_command(f"cursor {args['path']}")
        if tool_name == "expo_init": return self.run_command(f"npx create-expo-app {args['name']} --template blank")
        if tool_name == "generate_dockerfile":
            dockerfile = "FROM node:18-alpine\nWORKDIR /app\nCOPY . .\nRUN npm install\nCMD [\"npm\", \"start\"]"
            compose = "services:\n  app:\n    build: .\n    ports:\n      - '3000:3000'"
            self.write_file("Dockerfile", dockerfile)
            self.write_file("docker-compose.yml", compose)
            return "Generated Dockerfile and docker-compose.yml"
        return "Tool not implemented"

    def chat(self, user_input: str):
        self.history.append({"role": "user", "content": user_input})
        response = self.client.chat.completions.create(
            model=self.model,
            messages=self.history,
            tools=self.tools_definition(),
            tool_choice="auto"
        )
        msg = response.choices[0].message
        if msg.tool_calls:
            for tc in msg.tool_calls:
                res = self.execute_tool(tc.function.name, json.loads(tc.function.arguments))
                self.history.append({"role": "assistant", "content": None, "tool_calls": [tc]})
                self.history.append({"role": "tool", "tool_call_id": tc.id, "content": res})
            return self.chat("Continue with the results.")
        self.history.append({"role": "assistant", "content": msg.content})
        return msg.content

def main():
    agent = BitoginAgent()
    console.print(Panel("Bitogin Studio v5.1.0 - Production AI Agent", style="bold blue"))
    while True:
        try:
            query = console.input("[bold green]bitogin> [/]")
            if query.lower() in ["exit", "quit"]: break
            with Live(Markdown("Thinking..."), refresh_per_second=4) as live:
                output = agent.chat(query)
                live.update(Markdown(output))
        except KeyboardInterrupt:
            break

if __name__ == "__main__":
    main()