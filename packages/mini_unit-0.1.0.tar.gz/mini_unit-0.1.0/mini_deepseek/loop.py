"""
query_loop.py — the core reasoning loop.

Mirrors the architecture of claude-code's queryLoop (src/query.ts):

  while True:
      response = call_model(messages)          # → AssistantMessage
      if response has tool_calls:
          for each tool_call:
              result = dispatch(tool, args)    # → tool_result UserMessage
          append results to messages
          continue                             # needsFollowUp = True
      else:
          break                               # needsFollowUp = False → done

State is a simple dict (analogous to the State type in query.ts) that carries
the mutable message list across iterations.
"""

from __future__ import annotations

import json
import os
import sys
from typing import Iterator

import requests
from openai import OpenAI
from openai.types.chat import ChatCompletionMessageParam

from prompts import get_system_prompt
from tools import TOOLS, dispatch


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_TURNS = int(os.environ.get("MAX_TURNS", "30"))

# OpenAI / DeepSeek backend
MODEL    = os.environ.get("DEEPSEEK_MODEL",    "deepseek-chat")
BASE_URL = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com")

# Baidu internal LLM backend
BAIDU_LLM_URL         = os.environ.get("BAIDU_LLM_URL",         "http://llms-se.baidu-int.com:8200/chat/completions")
BAIDU_LLM_API_KEY     = os.environ.get("BAIDU_LLM_API_KEY",     "sk---haoxinda---shEsw6b4ZHkYh5pfd8xs6A==")
BAIDU_LLM_MODEL       = os.environ.get("BAIDU_LLM_MODEL",       "gpt-3.5-turbo")
BAIDU_LLM_TEMPERATURE = float(os.environ.get("BAIDU_LLM_TEMPERATURE", "0.3"))  # Lower = more focused/deterministic

# MiniMax backend
MINIMAX_BASE_URL      = os.environ.get("MINIMAX_BASE_URL",      "https://api.minimax.chat/v1")
MINIMAX_API_KEY       = os.environ.get("MINIMAX_API_KEY",       "")
MINIMAX_MODEL         = os.environ.get("MINIMAX_MODEL",         "MiniMax-M2.7")
MINIMAX_TEMPERATURE   = float(os.environ.get("MINIMAX_TEMPERATURE", "0.3"))
MINIMAX_REASONING_SPLIT = os.environ.get("MINIMAX_REASONING_SPLIT", "true").lower() in ("true", "1", "yes")

# Which backend to use: "baidu" (default), "openai", or "minimax"
LLM_BACKEND = os.environ.get("LLM_BACKEND", "baidu")

# Whether to use enhanced exploration prompt (auto-enabled for Baidu, can override)
USE_ENHANCED_PROMPT = os.environ.get("USE_ENHANCED_PROMPT", "auto").lower()


# ---------------------------------------------------------------------------
# Terminal colours (gracefully degrade when stdout is not a TTY)
# ---------------------------------------------------------------------------

def _c(code: str, text: str) -> str:
    if sys.stdout.isatty():
        return f"\033[{code}m{text}\033[0m"
    return text

BOLD   = lambda t: _c("1",    t)
DIM    = lambda t: _c("2",    t)
CYAN   = lambda t: _c("36",   t)
GREEN  = lambda t: _c("32",   t)
YELLOW = lambda t: _c("33",   t)
RED    = lambda t: _c("31",   t)
BLUE   = lambda t: _c("34",   t)


# ---------------------------------------------------------------------------
# State — mutable across iterations (analogous to the State type in query.ts)
# ---------------------------------------------------------------------------

class State:
    def __init__(self, user_message: str, enhanced_prompt: bool = False) -> None:
        self.messages: list[ChatCompletionMessageParam] = [
            {"role": "system", "content": get_system_prompt(enhanced=enhanced_prompt)},
            {"role": "user",   "content": user_message},
        ]
        self.turn_count: int = 0
        self.transition: str | None = None  # why the previous iter continued


# ---------------------------------------------------------------------------
# Single API call (equivalent to deps.callModel in query.ts)
# ---------------------------------------------------------------------------

def call_model(client: OpenAI, state: State) -> dict:
    """
    Send the current message list to the model and return the raw response
    message object as a dict-like (openai ChatCompletionMessage).
    Streams text output to stdout in real time.
    """
    print(BLUE(f"\n[turn {state.turn_count + 1}] calling model..."), flush=True)

    # Use streaming so the user sees text as it arrives
    collected_content = ""
    collected_tool_calls: dict[int, dict] = {}  # index → partial tool_call

    with client.chat.completions.create(
        model=MODEL,
        messages=state.messages,
        tools=TOOLS,         # full tool definitions every call (see ask.md §6.1)
        tool_choice="auto",  # model decides when to use tools (query.ts:674)
        stream=True,
        max_tokens=4096,
    ) as stream:
        for chunk in stream:
            delta = chunk.choices[0].delta if chunk.choices else None
            if delta is None:
                continue

            # Stream text content to stdout
            if delta.content:
                if not collected_content:
                    print(GREEN("Assistant: "), end="", flush=True)
                print(delta.content, end="", flush=True)
                collected_content += delta.content

            # Accumulate tool_calls (they arrive fragmented across chunks)
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index
                    if idx not in collected_tool_calls:
                        collected_tool_calls[idx] = {
                            "id":   tc.id or "",
                            "type": "function",
                            "function": {"name": tc.function.name or "", "arguments": ""},
                        }
                    else:
                        if tc.id:
                            collected_tool_calls[idx]["id"] = tc.id
                        if tc.function.name:
                            collected_tool_calls[idx]["function"]["name"] = tc.function.name
                    if tc.function.arguments:
                        collected_tool_calls[idx]["function"]["arguments"] += (
                            tc.function.arguments
                        )

    if collected_content:
        print()  # newline after streamed text

    # Build a unified message dict to append to history
    msg: dict = {"role": "assistant"}
    if collected_content:
        msg["content"] = collected_content
    else:
        msg["content"] = None

    if collected_tool_calls:
        msg["tool_calls"] = [
            {
                "id":       tc["id"],
                "type":     "function",
                "function": {
                    "name":      tc["function"]["name"],
                    "arguments": tc["function"]["arguments"],
                },
            }
            for tc in sorted(collected_tool_calls.values(), key=lambda x: list(collected_tool_calls.keys()).index(
                next(k for k, v in collected_tool_calls.items() if v is x)
            ))
        ]

    return msg


# ---------------------------------------------------------------------------
# Baidu internal LLM — direct HTTP POST (non-streaming)
# ---------------------------------------------------------------------------

def call_model_http(state: State) -> dict:
    """
    Send the current message list to the Baidu internal LLM via direct HTTP POST.
    Uses the OpenAI-compatible chat/completions endpoint with Bearer token auth.
    Returns the assistant message as a plain dict.
    """
    print(BLUE(f"\n[turn {state.turn_count + 1}] calling model (baidu-http)..."), flush=True)

    headers = {
        "Authorization": f"Bearer {BAIDU_LLM_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = {
        "model":       BAIDU_LLM_MODEL,
        "messages":    list(state.messages),
        "tools":       TOOLS,
        "tool_choice": "auto",
        "stream":      False,
        "max_tokens":  4096,
        "temperature": BAIDU_LLM_TEMPERATURE,  # Lower temperature for more systematic reasoning
        "top_p":       1,
    }

    resp = requests.post(BAIDU_LLM_URL, headers=headers, json=payload, timeout=120)
    resp.raise_for_status()
    data = resp.json()

    message = data["choices"][0]["message"]
    content: str | None = message.get("content") or None
    tool_calls_raw: list | None = message.get("tool_calls") or None

    if content:
        print(GREEN("Assistant: "), end="", flush=True)
        print(content)

    msg: dict = {"role": "assistant", "content": content}
    if tool_calls_raw:
        msg["tool_calls"] = tool_calls_raw

    return msg


# ---------------------------------------------------------------------------
# MiniMax — OpenAI SDK with streaming and reasoning_split
# ---------------------------------------------------------------------------

def call_model_minimax(client: OpenAI, state: State) -> dict:
    """
    Send the current message list to MiniMax using OpenAI SDK.
    Supports streaming and reasoning_split feature.
    Returns the assistant message as a plain dict.
    """
    print(BLUE(f"\n[turn {state.turn_count + 1}] calling model (minimax)..."), flush=True)

    # Build extra_body for MiniMax-specific features
    extra_body = {}
    if MINIMAX_REASONING_SPLIT:
        extra_body["reasoning_split"] = True

    # Use streaming so the user sees text as it arrives
    collected_content = ""
    collected_reasoning = ""
    collected_tool_calls: dict[int, dict] = {}  # index → partial tool_call

    with client.chat.completions.create(
        model=MINIMAX_MODEL,
        messages=state.messages,
        tools=TOOLS,
        tool_choice="auto",
        stream=True,
        max_tokens=4096,
        temperature=MINIMAX_TEMPERATURE,
        extra_body=extra_body,
    ) as stream:
        for chunk in stream:
            delta = chunk.choices[0].delta if chunk.choices else None
            if delta is None:
                continue

            # Handle reasoning content (if reasoning_split is enabled)
            if hasattr(delta, 'reasoning_details') and delta.reasoning_details:
                for reasoning_item in delta.reasoning_details:
                    if 'text' in reasoning_item:
                        reasoning_text = reasoning_item['text']
                        if not collected_reasoning:
                            print(DIM("Thinking: "), end="", flush=True)
                        print(DIM(reasoning_text), end="", flush=True)
                        collected_reasoning += reasoning_text

            # Stream text content to stdout
            if delta.content:
                if not collected_content and collected_reasoning:
                    print()  # newline after thinking
                if not collected_content:
                    print(GREEN("Assistant: "), end="", flush=True)
                print(delta.content, end="", flush=True)
                collected_content += delta.content

            # Accumulate tool_calls (they arrive fragmented across chunks)
            if delta.tool_calls:
                for tc in delta.tool_calls:
                    idx = tc.index
                    if idx not in collected_tool_calls:
                        collected_tool_calls[idx] = {
                            "id":   tc.id or "",
                            "type": "function",
                            "function": {"name": tc.function.name or "", "arguments": ""},
                        }
                    else:
                        if tc.id:
                            collected_tool_calls[idx]["id"] = tc.id
                        if tc.function.name:
                            collected_tool_calls[idx]["function"]["name"] = tc.function.name
                    if tc.function.arguments:
                        collected_tool_calls[idx]["function"]["arguments"] += (
                            tc.function.arguments
                        )

    if collected_content or collected_reasoning:
        print()  # newline after streamed text

    # Build a unified message dict to append to history
    msg: dict = {"role": "assistant"}
    if collected_content:
        msg["content"] = collected_content
    else:
        msg["content"] = None

    if collected_tool_calls:
        msg["tool_calls"] = [
            {
                "id":       tc["id"],
                "type":     "function",
                "function": {
                    "name":      tc["function"]["name"],
                    "arguments": tc["function"]["arguments"],
                },
            }
            for tc in sorted(collected_tool_calls.values(), key=lambda x: list(collected_tool_calls.keys()).index(
                next(k for k, v in collected_tool_calls.items() if v is x)
            ))
        ]

    return msg


# ---------------------------------------------------------------------------
# Tool execution (equivalent to runTools / StreamingToolExecutor in query.ts)
# ---------------------------------------------------------------------------

def run_tools(tool_calls: list[dict]) -> list[ChatCompletionMessageParam]:
    """
    Execute all tool calls and return tool-result messages.
    Independent calls could be parallelised; for simplicity we run them
    sequentially here (easy to switch to ThreadPoolExecutor if needed).
    """
    results: list[ChatCompletionMessageParam] = []
    for tc in tool_calls:
        name = tc["function"]["name"]
        args = tc["function"]["arguments"]
        call_id = tc["id"]

        print(YELLOW(f"  → tool: {BOLD(name)}"), end="  ", flush=True)

        result = dispatch(name, args)

        # Show a short preview of the result
        preview = result.splitlines()[0][:80] if result else "(empty)"
        print(DIM(f"[{preview}]"), flush=True)

        results.append({
            "role":         "tool",
            "tool_call_id": call_id,
            "content":      result,
        })
    return results


# ---------------------------------------------------------------------------
# Main loop — the queryLoop equivalent
# ---------------------------------------------------------------------------

def query_loop(user_message: str) -> None:
    """
    Entry point for one complete user turn.

    Equivalent to queryLoop() in src/query.ts:
      - Maintains State (messages, turn_count, transition)
      - Calls model → checks for tool_use → executes tools → repeats
      - Exits when model produces no tool calls (needsFollowUp = False)
        or when max turns is reached
    """
    # Determine backend and initialize if necessary
    backend = LLM_BACKEND.lower()
    client = None
    
    # Determine whether to use enhanced prompt
    if USE_ENHANCED_PROMPT == "auto":
        # Auto mode: enable enhanced prompt for ALL backends by default
        use_enhanced_prompt = True
    elif USE_ENHANCED_PROMPT in ("false", "0", "no"):
        # Explicitly disabled
        use_enhanced_prompt = False
    else:
        # Explicit override: "true"/"1"/"yes" = enabled
        use_enhanced_prompt = USE_ENHANCED_PROMPT in ("true", "1", "yes")

    if backend == "baidu":
        print(CYAN(f"[using backend: Baidu internal LLM at {BAIDU_LLM_URL}]"))
        print(CYAN(f"[model: {BAIDU_LLM_MODEL}, temperature: {BAIDU_LLM_TEMPERATURE}]"))
    elif backend == "minimax":
        # MiniMax backend
        api_key = MINIMAX_API_KEY or os.environ.get("OPENAI_API_KEY", "")
        if not api_key:
            print(RED("Error: MINIMAX_API_KEY environment variable is not set."))
            print("Set it with:  export MINIMAX_API_KEY=your-key")
            sys.exit(1)
        client = OpenAI(api_key=api_key, base_url=MINIMAX_BASE_URL)
        print(CYAN(f"[using backend: MiniMax at {MINIMAX_BASE_URL}]"))
        print(CYAN(f"[model: {MINIMAX_MODEL}, temperature: {MINIMAX_TEMPERATURE}]"))
        if MINIMAX_REASONING_SPLIT:
            print(CYAN("[reasoning_split: enabled - thinking will be shown separately]"))
    else:
        # Default to OpenAI / DeepSeek
        api_key = os.environ.get("DEEPSEEK_API_KEY", "")
        if not api_key:
            print(RED("Error: DEEPSEEK_API_KEY environment variable is not set."))
            print("Set it with:  export DEEPSEEK_API_KEY=sk-...")
            sys.exit(1)
        client = OpenAI(api_key=api_key, base_url=BASE_URL)
        print(CYAN(f"[using backend: OpenAI-compatible at {BASE_URL}]"))
        print(CYAN(f"[model: {MODEL}]"))
    
    # Show prompt mode for all backends
    if use_enhanced_prompt:
        print(CYAN("[using enhanced prompt with strict exploration protocol]"))
    else:
        print(CYAN("[using standard prompt]"))

    state = State(user_message, enhanced_prompt=use_enhanced_prompt)

    while True:
        # ── guard: max turns (mirrors maxTurns check in query.ts:1705) ────
        if state.turn_count >= MAX_TURNS:
            print(RED(f"\n[max turns ({MAX_TURNS}) reached — stopping]"))
            break

        state.turn_count += 1

        # ── call model ────────────────────────────────────────────────────
        try:
            if backend == "baidu":
                assistant_msg = call_model_http(state)
            elif backend == "minimax":
                assistant_msg = call_model_minimax(client, state)
            else:
                assistant_msg = call_model(client, state)
        except Exception as exc:
            print(RED(f"\nAPI error: {exc}"))
            break

        # Append assistant message (with or without tool_calls) to history
        # This mirrors query.ts assistantMessages.push(message)
        state.messages.append(assistant_msg)  # type: ignore[arg-type]

        # ── check for tool use (needsFollowUp) ────────────────────────────
        tool_calls = assistant_msg.get("tool_calls")
        if not tool_calls:
            # No tools → turn is complete  (return { reason: 'completed' })
            state.transition = None
            break

        # ── execute tools ─────────────────────────────────────────────────
        # (mirrors runTools / tool execution path in query.ts:1380-1408)
        tool_results = run_tools(tool_calls)

        # Append tool results to history so the model can see them next turn
        state.messages.extend(tool_results)

        # ── continue loop ─────────────────────────────────────────────────
        state.transition = "next_turn"
        # (falls through to while True → next iteration)

    print(DIM(f"\n[done — {state.turn_count} turn(s)]"))

    # ── dump final state.messages to ~/cc/ms.md ───────────────────────────
    _dump_messages(state.messages)


def _dump_messages(messages: list) -> None:
    """Write state.messages to /Users/haoxinda/cc/ms.md as readable Markdown."""
    import json
    from pathlib import Path

    out_path = Path("/Users/haoxinda/cc/ms.md")

    lines: list[str] = ["# state.messages dump\n"]
    for i, msg in enumerate(messages):
        role = msg.get("role", "unknown")
        lines.append(f"## [{i}] role: `{role}`\n")

        # tool_calls block (assistant requesting tools)
        tool_calls = msg.get("tool_calls")
        if tool_calls:
            lines.append("**tool_calls:**\n")
            for tc in tool_calls:
                fn = tc.get("function", {})
                lines.append(f"- `{fn.get('name', '?')}` (id: `{tc.get('id', '?')}`)")
                args_raw = fn.get("arguments", "")
                try:
                    args_pretty = json.dumps(json.loads(args_raw), ensure_ascii=False, indent=2)
                except Exception:
                    args_pretty = args_raw
                lines.append(f"\n  ```json\n{args_pretty}\n  ```\n")

        # content block
        content = msg.get("content")
        if content is not None:
            lines.append("**content:**\n")
            if isinstance(content, str):
                # tool result or plain text — wrap in code fence if it's a tool result
                if role == "tool":
                    preview = content if len(content) <= 2000 else content[:2000] + "\n... (truncated)"
                    lines.append(f"```\n{preview}\n```\n")
                else:
                    lines.append(f"{content}\n")
            elif isinstance(content, list):
                for block in content:
                    btype = block.get("type", "?")
                    btext = block.get("text") or block.get("thinking") or str(block)
                    lines.append(f"- **{btype}**: {btext}\n")

        # tool_call_id (tool result message)
        tc_id = msg.get("tool_call_id")
        if tc_id:
            lines.append(f"*tool_call_id: `{tc_id}`*\n")

        lines.append("---\n")

    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(DIM(f"[messages written to {out_path}]"))
