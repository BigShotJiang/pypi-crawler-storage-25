#!/bin/bash
# 启动脚本 - 百度内部 LLM

export LLM_BACKEND=baidu
export BAIDU_LLM_URL=http://llms-se.baidu-int.com:8200/chat/completions
export BAIDU_LLM_API_KEY=sk---haoxinda---shEsw6b4ZHkYh5pfd8xs6A==
export BAIDU_LLM_MODEL=gpt-3.5-turbo
export BAIDU_LLM_TEMPERATURE=0.3

# 可选：增强 prompt 模式（默认为 auto，已自动启用）
# export USE_ENHANCED_PROMPT=true

echo "✅ 百度 LLM 环境已配置"
echo "   Backend: $LLM_BACKEND"
echo "   Model: $BAIDU_LLM_MODEL"
echo "   Temperature: $BAIDU_LLM_TEMPERATURE"
echo ""
echo "使用方式："
echo "  source start_baidu.sh"
echo "  python3 main.py '你的问题'"
