#!/bin/bash
# 启动脚本 - MiniMax

export LLM_BACKEND=minimax
export MINIMAX_API_KEY=${MINIMAX_API_KEY:-"your-minimax-api-key"}
export MINIMAX_BASE_URL=https://api.minimax.chat/v1
export MINIMAX_MODEL=MiniMax-M2.7
export MINIMAX_TEMPERATURE=0.3
export MINIMAX_REASONING_SPLIT=true

# 可选：增强 prompt 模式（默认为 auto，已自动启用）
# export USE_ENHANCED_PROMPT=true

if [ "$MINIMAX_API_KEY" = "your-minimax-api-key" ]; then
    echo "❌ 错误: 请先设置 MINIMAX_API_KEY 环境变量"
    echo "   export MINIMAX_API_KEY=your-actual-key"
    return 1
fi

echo "✅ MiniMax 环境已配置"
echo "   Backend: $LLM_BACKEND"
echo "   Model: $MINIMAX_MODEL"
echo "   Temperature: $MINIMAX_TEMPERATURE"
echo "   Reasoning Split: $MINIMAX_REASONING_SPLIT"
echo ""
echo "使用方式："
echo "  source start_minimax.sh"
echo "  python3 main.py '你的问题'"
