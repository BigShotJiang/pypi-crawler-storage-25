"""mini-unit - Minimal agentic reasoning tool with multiple LLM backend support."""

__version__ = "0.1.0"
__author__ = "haoxinda"
__email__ = "haoxinda@baidu.com"

from mini_deepseek.main import main

__all__ = ["main"]
