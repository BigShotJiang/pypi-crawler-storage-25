#!/usr/bin/env python3
"""
mini-deepseek — a minimal agentic reasoning tool powered by DeepSeek.

Inspired by claude-code's queryLoop architecture (src/query.ts).

Usage:
    python main.py "your question or task"
    python main.py   # interactive REPL mode

Environment variables:
    DEEPSEEK_API_KEY   required — your DeepSeek API key
    DEEPSEEK_MODEL     optional — model name (default: deepseek-chat)
    DEEPSEEK_BASE_URL  optional — API base URL (default: https://api.deepseek.com)
    MAX_TURNS          optional — max reasoning turns per query (default: 30)

Project structure:
    main.py    — CLI entry point (this file)
    loop.py    — queryLoop: the multi-turn reasoning + tool-execution loop
    tools.py   — tool schemas (sent to API) + Python implementations
    prompts.py — system prompt (intro + doing-tasks + using-tools + explore strategy)
"""

from __future__ import annotations

import sys
import os


# ---------------------------------------------------------------------------
# Startup banner
# ---------------------------------------------------------------------------

BANNER = """
┌─────────────────────────────────────────────────┐
│   mini-deepseek  •  agentic reasoning tool       │
│   tools: glob  read  grep                        │
│   type 'exit' or Ctrl-C to quit                  │
└─────────────────────────────────────────────────┘
"""


def _check_deps() -> None:
    """Fail fast with a helpful message if openai is not installed."""
    try:
        import openai  # noqa: F401
    except ImportError:
        print("Error: 'openai' package not found.")
        print("Install it with:  pip install openai")
        sys.exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    _check_deps()

    # Import here so import errors from openai give the _check_deps message
    from loop import query_loop  # noqa: PLC0415

    # Single-shot mode: question passed as CLI argument
    if len(sys.argv) > 1:
        user_input = " ".join(sys.argv[1:])
        query_loop(user_input)
        return

    # Interactive REPL mode
    print(BANNER)

    if not os.environ.get("DEEPSEEK_API_KEY"):
        print("Warning: DEEPSEEK_API_KEY is not set — queries will fail.\n"
              "Set it with:  export DEEPSEEK_API_KEY=sk-...\n")

    while True:
        try:
            user_input = input("\033[1;36mYou>\033[0m ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break

        if not user_input:
            continue
        if user_input.lower() in {"exit", "quit", "q"}:
            print("Goodbye.")
            break

        query_loop(user_input)


if __name__ == "__main__":
    main()
