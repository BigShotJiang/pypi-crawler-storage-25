#!/bin/bash
# 启动脚本 - DeepSeek

export LLM_BACKEND=openai
export DEEPSEEK_API_KEY=${DEEPSEEK_API_KEY:-"your-deepseek-api-key"}
export DEEPSEEK_BASE_URL=https://api.deepseek.com
export DEEPSEEK_MODEL=deepseek-chat

# 可选：增强 prompt 模式（默认为 auto，已自动启用）
# export USE_ENHANCED_PROMPT=true

if [ "$DEEPSEEK_API_KEY" = "your-deepseek-api-key" ]; then
    echo "❌ 错误: 请先设置 DEEPSEEK_API_KEY 环境变量"
    echo "   export DEEPSEEK_API_KEY=sk-your-actual-key"
    return 1
fi

echo "✅ DeepSeek 环境已配置"
echo "   Backend: $LLM_BACKEND"
echo "   Model: $DEEPSEEK_MODEL"
echo "   Base URL: $DEEPSEEK_BASE_URL"
echo ""
echo "使用方式："
echo "  source start_deepseek.sh"
echo "  python3 main.py '你的问题'"
