"""
Tool definitions and implementations for glob, read, and grep.

Each tool has two parts:
  1. SCHEMA  — the JSON schema dict sent to the DeepSeek/OpenAI API as part of
               the `tools` parameter (mirrors claude-code's toolToAPISchema).
  2. execute — the Python function that actually runs the tool and returns a
               plain-text result string (mirrors each Tool.call() in claude-code).

Design mirrors claude-code's tool prompt files (tools/GlobTool/prompt.ts, etc.):
  the description field IS the tool's guidance prompt — the model reads it to
  decide when and how to use the tool.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# 1. Glob — fast file-pattern matching
# ---------------------------------------------------------------------------

GLOB_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "glob",
        "description": (
            "Fast file pattern matching tool that works with any codebase size.\n\n"
            "### When to Use\n"
            "- Finding files by name or path pattern (e.g. '**/*.py', 'src/**/query*')\n"
            "- Mapping the directory structure before reading files\n"
            "- Returns matching paths sorted by modification time (most-recent first)\n\n"
            "### When NOT to Use\n"
            "- Searching file *contents* — use `grep` instead\n"
            "- Reading a file whose path you already know — use `read` instead\n"
            "- When the search requires multiple rounds of globbing and grepping, "
            "chain tool calls step by step\n\n"
            "### Pattern syntax\n"
            "Standard Unix glob: `*` matches any chars in one segment, `**` matches "
            "across directory separators. Examples:\n"
            "  `**/*.ts`          all TypeScript files\n"
            "  `src/**/prompt*`   any file starting with 'prompt' under src/"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": (
                        "Glob pattern to match. Relative patterns are resolved "
                        "against `base_dir`. Examples: '**/*.py', 'src/**/query*'."
                    ),
                },
                "base_dir": {
                    "type": "string",
                    "description": (
                        "Directory to search in. Defaults to the current working "
                        "directory if omitted."
                    ),
                },
            },
            "required": ["pattern"],
        },
    },
}


def execute_glob(pattern: str, base_dir: str = ".") -> str:
    root = Path(base_dir).expanduser().resolve()
    if not root.exists():
        return f"Error: base_dir does not exist: {root}"

    try:
        # Sort by modification time, most recent first (mirrors claude-code Glob tool)
        matches = sorted(root.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    except Exception as exc:
        return f"Error during glob: {exc}"

    if not matches:
        return f"No files found matching pattern '{pattern}' in {root}"

    lines = [f"Found {len(matches)} file(s) matching '{pattern}' in {root}:"]
    for p in matches[:100]:  # cap at 100 results
        lines.append(str(p))
    if len(matches) > 100:
        lines.append(f"... and {len(matches) - 100} more (showing first 100)")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 2. Read — read file contents with optional offset / limit
# ---------------------------------------------------------------------------

READ_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "read",
        "description": (
            "Reads a file from the local filesystem.\n\n"
            "### When to Use\n"
            "- Reading source code, config, docs, or any text file\n"
            "- Use this INSTEAD of `cat`, `head`, or `tail`\n"
            "- Supports text files, and will do its best with binary files\n\n"
            "### Tips\n"
            "- For large files, use `offset` + `limit` to read a specific range\n"
            "- Defaults to reading up to 200 lines from the top\n"
            "- Results include line numbers (cat -n format): `  42→content`\n"
            "- Prefer an absolute path; relative paths are resolved from cwd"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file to read.",
                },
                "offset": {
                    "type": "integer",
                    "description": (
                        "0-based line index to start reading from. "
                        "Defaults to 0 (beginning of file)."
                    ),
                },
                "limit": {
                    "type": "integer",
                    "description": (
                        "Maximum number of lines to return. "
                        "Defaults to 200. Use a larger value if you need more context."
                    ),
                },
            },
            "required": ["file_path"],
        },
    },
}


def execute_read(file_path: str, offset: int = 0, limit: int = 200) -> str:
    path = Path(file_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    path = path.resolve()

    if not path.exists():
        return f"Error: file not found: {path}"
    if path.is_dir():
        return f"Error: path is a directory, not a file: {path}"

    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        return f"Error reading {path}: {exc}"

    lines = content.splitlines(keepends=True)
    total = len(lines)

    # Clamp offset
    start = max(0, min(offset, total))
    end = min(start + limit, total)
    selected = lines[start:end]

    header = f"File: {path}  (lines {start + 1}–{end} of {total})\n"
    body = "".join(f"{start + i + 1:6d}→{line}" for i, line in enumerate(selected))
    if end < total:
        remaining = total - end
        footer = f"\n... ({remaining} more line(s) not shown — use offset={end} to continue)"
    else:
        footer = ""
    return header + body + footer


# ---------------------------------------------------------------------------
# 3. Grep — search file contents with regex (pure Python, no external deps)
# ---------------------------------------------------------------------------

GREP_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "grep",
        "description": (
            "Search file contents using regular expressions (powered by Python `re`).\n\n"
            "### When to Use\n"
            "- Finding where a symbol, function, or pattern is defined/used\n"
            "- Use this INSTEAD of running `grep` or `rg` as a shell command\n"
            "- For open-ended searches requiring multiple rounds, chain grep calls "
            "or combine with `glob` + `read`\n\n"
            "### Output modes\n"
            "- `files_with_matches` (default) — list of file paths that contain a match\n"
            "- `content`           — matching lines with file path and line number\n"
            "- `count`             — number of matches per file\n\n"
            "### Tips\n"
            "- `file_glob` filters which files to search (e.g. '*.py', '**/*.ts')\n"
            "- Patterns are Python regex; escape special chars if needed\n"
            "- Case-insensitive search: use `(?i)` prefix in the pattern"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Python regex pattern to search for.",
                },
                "path": {
                    "type": "string",
                    "description": (
                        "File or directory to search. Defaults to current working "
                        "directory. If a file path, searches only that file."
                    ),
                },
                "file_glob": {
                    "type": "string",
                    "description": (
                        "Glob pattern to filter which files are searched "
                        "(e.g. '*.py', '**/*.ts'). Only used when `path` is a "
                        "directory. Defaults to all files."
                    ),
                },
                "output_mode": {
                    "type": "string",
                    "enum": ["files_with_matches", "content", "count"],
                    "description": (
                        "How to present results: "
                        "'files_with_matches' (default), 'content', or 'count'."
                    ),
                },
                "context_lines": {
                    "type": "integer",
                    "description": (
                        "Number of context lines to show before and after each "
                        "match (only used with output_mode='content'). Defaults to 0."
                    ),
                },
            },
            "required": ["pattern"],
        },
    },
}


def execute_grep(
    pattern: str,
    path: str = ".",
    file_glob: str = "**/*",
    output_mode: str = "files_with_matches",
    context_lines: int = 0,
) -> str:
    try:
        regex = re.compile(pattern)
    except re.error as exc:
        return f"Error: invalid regex pattern '{pattern}': {exc}"

    search_root = Path(path).expanduser()
    if not search_root.is_absolute():
        search_root = Path.cwd() / search_root
    search_root = search_root.resolve()

    if not search_root.exists():
        return f"Error: path does not exist: {search_root}"

    # Collect files to search
    if search_root.is_file():
        files = [search_root]
    else:
        glob_pat = file_glob if file_glob else "**/*"
        files = [p for p in search_root.glob(glob_pat) if p.is_file()]

    if not files:
        return f"No files to search in {search_root} with pattern '{file_glob}'"

    # Search
    results: list[tuple[Path, list[tuple[int, str]]]] = []  # (file, [(lineno, line)])
    for fpath in sorted(files):
        try:
            text = fpath.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        file_lines = text.splitlines()
        matches = [(i + 1, line) for i, line in enumerate(file_lines) if regex.search(line)]
        if matches:
            results.append((fpath, matches))

    if not results:
        return f"No matches found for pattern '{pattern}'"

    total_matches = sum(len(m) for _, m in results)

    # Format output
    if output_mode == "files_with_matches":
        lines = [f"Found matches in {len(results)} file(s) ({total_matches} total matches):"]
        for fpath, _ in results[:50]:
            lines.append(str(fpath))
        if len(results) > 50:
            lines.append(f"... and {len(results) - 50} more files")
        return "\n".join(lines)

    elif output_mode == "count":
        lines = [f"Match counts for pattern '{pattern}':"]
        for fpath, matches in sorted(results, key=lambda x: -len(x[1])):
            lines.append(f"{len(matches):6d}  {fpath}")
        return "\n".join(lines)

    else:  # content
        lines = [f"Matches for pattern '{pattern}' ({total_matches} total):"]
        shown = 0
        for fpath, matches in results:
            file_lines = fpath.read_text(encoding="utf-8", errors="replace").splitlines()
            lines.append(f"\n── {fpath} ──")
            for lineno, _ in matches:
                if shown >= 200:
                    lines.append("... (truncated at 200 matches)")
                    return "\n".join(lines)
                # context lines
                start = max(0, lineno - 1 - context_lines)
                end = min(len(file_lines), lineno + context_lines)
                for i in range(start, end):
                    prefix = ">" if i == lineno - 1 else " "
                    lines.append(f"  {prefix} {i + 1:5d}│ {file_lines[i]}")
                if context_lines > 0:
                    lines.append("  ···")
                shown += 1
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# 4. Write — write content to a file
# ---------------------------------------------------------------------------

WRITE_SCHEMA: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "write",
        "description": (
            "Writes content to a file on the local filesystem.\n\n"
            "### When to Use\n"
            "- Creating new files (e.g. test files, configuration files)\n"
            "- Overwriting existing files with new content\n"
            "- Use this when you need to save generated code or content\n\n"
            "### Important Notes\n"
            "- This will OVERWRITE the file if it already exists\n"
            "- For existing files, consider reading them first to understand the structure\n"
            "- The file will be created with UTF-8 encoding\n"
            "- Parent directories will NOT be created automatically — ensure the parent path exists\n\n"
            "### Tips\n"
            "- Always use absolute paths when possible\n"
            "- For test files, follow the project's naming conventions (e.g. `*_test.go` for Go)\n"
            "- After writing, you may want to use `read` to verify the content was written correctly"
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Absolute or relative path to the file to write. Parent directory must exist.",
                },
                "content": {
                    "type": "string",
                    "description": "The complete content to write to the file.",
                },
            },
            "required": ["file_path", "content"],
        },
    },
}


def execute_write(file_path: str, content: str) -> str:
    path = Path(file_path).expanduser()
    if not path.is_absolute():
        path = Path.cwd() / path
    path = path.resolve()

    # Check parent directory exists
    if not path.parent.exists():
        return f"Error: parent directory does not exist: {path.parent}\nCreate it first or use an existing directory."

    try:
        path.write_text(content, encoding="utf-8")
        line_count = len(content.splitlines())
        return f"Successfully wrote {line_count} line(s) to {path}"
    except Exception as exc:
        return f"Error writing to {path}: {exc}"


# ---------------------------------------------------------------------------
# Registry — maps tool name → (schema, execute_fn)
# ---------------------------------------------------------------------------

TOOLS: list[dict[str, Any]] = [GLOB_SCHEMA, READ_SCHEMA, GREP_SCHEMA, WRITE_SCHEMA]

_EXECUTORS = {
    "glob": lambda args: execute_glob(**args),
    "read": lambda args: execute_read(**args),
    "grep": lambda args: execute_grep(**args),
    "write": lambda args: execute_write(**args),
}


def dispatch(tool_name: str, arguments_json: str) -> str:
    """
    Execute a tool by name with JSON-encoded arguments.
    Returns the result as a plain-text string.
    Mirrors claude-code's tool dispatch in toolOrchestration.ts.
    """
    executor = _EXECUTORS.get(tool_name)
    if executor is None:
        return f"Error: unknown tool '{tool_name}'"
    try:
        args = json.loads(arguments_json) if arguments_json else {}
    except json.JSONDecodeError as exc:
        return f"Error: could not parse tool arguments: {exc}\nRaw: {arguments_json}"
    try:
        return executor(args)
    except TypeError as exc:
        return f"Error: invalid arguments for tool '{tool_name}': {exc}"
    except Exception as exc:
        return f"Error executing tool '{tool_name}': {exc}"
