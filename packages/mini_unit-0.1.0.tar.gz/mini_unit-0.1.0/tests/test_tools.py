"""Tests for tools module."""

import pytest
from mini_deepseek.tools import execute_glob, execute_read, execute_grep, execute_write
from pathlib import Path
import tempfile


class TestGlobTool:
    """Test glob tool functionality."""
    
    def test_glob_finds_python_files(self, tmp_path):
        """Test that glob can find Python files."""
        # Create test files
        (tmp_path / "test1.py").touch()
        (tmp_path / "test2.py").touch()
        (tmp_path / "test.txt").touch()
        
        result = execute_glob("*.py", str(tmp_path))
        assert "test1.py" in result
        assert "test2.py" in result
        assert "test.txt" not in result
    
    def test_glob_no_matches(self, tmp_path):
        """Test glob with no matches."""
        result = execute_glob("*.nonexistent", str(tmp_path))
        assert "No files found" in result


class TestReadTool:
    """Test read tool functionality."""
    
    def test_read_existing_file(self, tmp_path):
        """Test reading an existing file."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("Line 1\nLine 2\nLine 3")
        
        result = execute_read(str(test_file))
        assert "Line 1" in result
        assert "Line 2" in result
        assert "Line 3" in result
    
    def test_read_nonexistent_file(self, tmp_path):
        """Test reading a nonexistent file."""
        result = execute_read(str(tmp_path / "nonexistent.txt"))
        assert "Error: file not found" in result
    
    def test_read_with_limit(self, tmp_path):
        """Test reading with line limit."""
        test_file = tmp_path / "test.txt"
        test_file.write_text("\n".join([f"Line {i}" for i in range(10)]))
        
        result = execute_read(str(test_file), limit=5)
        assert "Line 0" in result
        assert "Line 4" in result
        # Should have a note about more lines
        assert "more line" in result.lower()


class TestGrepTool:
    """Test grep tool functionality."""
    
    def test_grep_finds_pattern(self, tmp_path):
        """Test grep finding a pattern."""
        test_file = tmp_path / "test.py"
        test_file.write_text("def hello():\n    return 'world'\n")
        
        result = execute_grep("def hello", str(tmp_path), "*.py")
        assert str(test_file) in result or "1 file" in result
    
    def test_grep_no_matches(self, tmp_path):
        """Test grep with no matches."""
        test_file = tmp_path / "test.py"
        test_file.write_text("print('hello')\n")
        
        result = execute_grep("nonexistent_pattern", str(tmp_path))
        assert "No matches found" in result


class TestWriteTool:
    """Test write tool functionality."""
    
    def test_write_new_file(self, tmp_path):
        """Test writing a new file."""
        test_file = tmp_path / "output.txt"
        content = "Hello\nWorld"
        
        result = execute_write(str(test_file), content)
        assert "Successfully wrote" in result
        assert test_file.read_text() == content
    
    def test_write_overwrites_existing(self, tmp_path):
        """Test that write overwrites existing files."""
        test_file = tmp_path / "existing.txt"
        test_file.write_text("Old content")
        
        new_content = "New content"
        result = execute_write(str(test_file), new_content)
        assert "Successfully wrote" in result
        assert test_file.read_text() == new_content
    
    def test_write_nonexistent_directory(self, tmp_path):
        """Test writing to nonexistent directory fails."""
        test_file = tmp_path / "nonexistent" / "file.txt"
        result = execute_write(str(test_file), "content")
        assert "Error" in result
        assert "does not exist" in result
