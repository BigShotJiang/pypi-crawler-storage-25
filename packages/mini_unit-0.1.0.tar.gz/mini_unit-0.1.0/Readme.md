# mini-unit

[![PyPI version](https://badge.fury.io/py/mini-unit.svg)](https://badge.fury.io/py/mini-unit)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

极简 Agentic 推理工具，支持多种 LLM 后端（百度内部 LLM / DeepSeek / MiniMax），基于工具调用实现多轮推理和代码探索。专注于自动化单元测试生成。

## 安装

### 从 PyPI 安装（推荐）

```bash
pip install mini-unit
```

### 从源码安装

```bash
git clone https://github.com/yourusername/mini-unit.git
cd mini-unit
pip install -e .
```

## 快速开始

### 方式 1: 使用命令行工具

```bash
# 设置环境变量
export LLM_BACKEND=baidu  # 或 openai/minimax
export BAIDU_LLM_API_KEY=your-key

# 运行
mini-unit "帮我写单元测试"
```

### 方式 2: 使用启动脚本

#### 1. 安装依赖

```bash
pip install -r requirements.txt
```

#### 2. 选择并启动 LLM 后端

##### 选项 A: 百度内部 LLM（默认）

```bash
source start_baidu.sh
python3 main.py "帮我写单元测试"
```

##### 选项 B: DeepSeek

```bash
export DEEPSEEK_API_KEY=sk-your-key
source start_deepseek.sh
mini-unit "帮我写单元测试"
```

##### 选项 C: MiniMax

```bash
export MINIMAX_API_KEY=your-key
source start_minimax.sh
mini-unit "帮我写单元测试"
```

## 启动脚本说明

项目提供了 3 个启动脚本：

- **start_baidu.sh** - 百度内部 LLM
- **start_deepseek.sh** - DeepSeek
- **start_minimax.sh** - MiniMax

使用方式：
```bash
source start_baidu.sh     # 加载环境变量
python3 main.py "问题"     # 运行
```

## 支持的 LLM 后端

### 1. 百度内部 LLM

**配置**（见 start_baidu.sh）：
```bash
export LLM_BACKEND=baidu
export BAIDU_LLM_URL=http://llms-se.baidu-int.com:8200/chat/completions
export BAIDU_LLM_API_KEY=sk---haoxinda---shEsw6b4ZHkYh5pfd8xs6A==
export BAIDU_LLM_MODEL=gpt-3.5-turbo
export BAIDU_LLM_TEMPERATURE=0.3
```

### 2. DeepSeek

**配置**（见 start_deepseek.sh）：
```bash
export LLM_BACKEND=openai
export DEEPSEEK_API_KEY=sk-your-key  # 必须设置
export DEEPSEEK_BASE_URL=https://api.deepseek.com
export DEEPSEEK_MODEL=deepseek-chat
```

### 3. MiniMax

**配置**（见 start_minimax.sh）：
```bash
export LLM_BACKEND=minimax
export MINIMAX_API_KEY=your-key  # 必须设置
export MINIMAX_BASE_URL=https://api.minimax.chat/v1
export MINIMAX_MODEL=MiniMax-M2.7
export MINIMAX_TEMPERATURE=0.3
export MINIMAX_REASONING_SPLIT=true  # 分离显示思考过程
```

## 增强 Prompt 模式

默认启用增强模式，包含：

- ⚠️⚠️⚠️ 强制性的 9 步探索流程
- 防止低级编译错误（undefined、not used）
- 智能处理外部依赖（2 次失败后跳过）
- 质量检查清单

控制方式：
```bash
export USE_ENHANCED_PROMPT=auto   # 默认，全部启用
export USE_ENHANCED_PROMPT=false  # 禁用
```

## 可用工具

1. **glob** - 文件模式匹配
2. **read** - 读取文件
3. **grep** - 搜索内容
4. **write** - 写入文件

## 使用示例

```bash
# 写单元测试
python3 main.py "帮我写 /path/to/file.go 的单元测试"

# 交互式
python3 main.py

# 单次执行
python3 main.py "解释这个函数"
```

## 配置速查表

| 环境变量 | 默认值 | 说明 |
|---------|-------|------|
| `LLM_BACKEND` | `baidu` | 后端：baidu/openai/minimax |
| `USE_ENHANCED_PROMPT` | `auto` | Prompt 模式 |
| `MAX_TURNS` | `30` | 最大推理轮数 |

## 项目结构

```
/Users/haoxinda/cc/pp/
├── main.py               # CLI 入口
├── loop.py              # 推理循环
├── tools.py             # 工具定义
├── prompts.py           # 系统提示词
├── requirements.txt     # 依赖
├── start_baidu.sh       # 百度启动脚本
├── start_deepseek.sh    # DeepSeek 启动脚本
└── start_minimax.sh     # MiniMax 启动脚本
```