"""Setup configuration for mini-deepseek package."""

from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of README file
this_directory = Path(__file__).parent
long_description = (this_directory / "Readme.md").read_text(encoding="utf-8")

setup(
    name="mini-unit",
    version="0.1.0",
    author="haoxinda",
    author_email="haoxinda@baidu.com",
    description="Minimal agentic reasoning tool with multiple LLM backend support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/mini-unit",  # 替换为实际仓库
    packages=find_packages(),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Code Generators",
        "Topic :: Software Development :: Testing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "openai>=1.0.0",
        "requests>=2.25.0",
    ],
    entry_points={
        "console_scripts": [
            "mini-unit=mini_deepseek.main:main",
        ],
    },
    include_package_data=True,
    package_data={
        "mini_deepseek": ["*.sh"],
    },
    keywords="llm ai agent code-generation testing unit-test",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/mini-unit/issues",
        "Source": "https://github.com/yourusername/mini-unit",
    },
)
