"""
Test suite for the hydra_db Python SDK (fresh-clone of main branch).

Covers:
  - Imports (top-level, types, errors, sub-modules)
  - HydraDBEnvironment enum
  - Sync/Async client instantiation and sub-client access
  - Authentication: token as string, callable, absent
  - Custom headers propagation
  - base_url override
  - _parse_retry_after (including the retry-after-ms string-comparison bug)
  - _should_retry status codes
  - get_request_body / maybe_filter_request_body
  - remove_omit_from_dict
  - MemoryItem and other type models
  - Serialization utilities
  - datetime_utils
  - __all__ completeness
  - _retry_timeout bounds
  - Sub-client with_raw_response types
  - query_encoder / jsonable_encoder
  - Pydantic v2 compatibility flag
"""

import asyncio
import datetime as dt
import inspect
import typing

import httpx
import pydantic
import pytest


# ---------------------------------------------------------------------------
# TC-01  Top-level imports
# ---------------------------------------------------------------------------
class TestTopLevelImports:
    def test_main_clients(self):
        from hydra_db import HydraDB, AsyncHydraDB, HydraDBEnvironment  # noqa: F401

    def test_all_types(self):
        from hydra_db import (  # noqa: F401
            ActualErrorResponse,
            AddMemoryResponse,
            Alpha,
            ApiKeyCreateResponse,
            AttachmentModel,
            BatchProcessingStatus,
            Bm25OperatorType,
            CollectionStats,
            ContentFilter,
            ContentModel,
            CustomPropertyDefinition,
            DeleteResult,
            DeleteUserMemoryResponse,
            Entity,
            ErrorResponse,
            FetchMode,
            ForcefulRelationsPayload,
            GraphContext,
            Infra,
            InfraStatusResponse,
            InsertResult,
            ListContentKind,
            ListUserMemoriesResponse,
            MemoryItem,
            MemoryResultItem,
            MilvusDataType,
            PaginationMeta,
            PathTriplet,
            ProcessingStatus,
            ProcessingStatusIndexingStatus,
            QnASearchResponse,
            RawEmbeddingDocument,
            RawEmbeddingSearchResult,
            RawEmbeddingVector,
            RecallSearchRequest,
            RelationEvidence,
            RetrievalResult,
            RetrieveMode,
            ScoredPathResponse,
            SearchMode,
            SourceDeleteResponse,
            SourceDeleteResultItem,
            SourceFetchResponse,
            SourceGraphRelationsResponse,
            SourceInfo,
            SourceListResponse,
            SourceModel,
            SourceStatus,
            SourceUploadResponse,
            SourceUploadResultItem,
            SubTenantIdsResponse,
            SupportedLlmProviders,
            TenantCreateAcceptedResponse,
            TenantDeleteResponse,
            TenantStatsResponse,
            TripletWithEvidence,
            UserAssistantPair,
            UserMemory,
            VectorStoreChunk,
        )

    def test_all_errors(self):
        from hydra_db import (  # noqa: F401
            BadRequestError,
            ForbiddenError,
            InternalServerError,
            NotFoundError,
            ServiceUnavailableError,
            TooManyRequestsError,
            UnauthorizedError,
            UnprocessableEntityError,
        )

    def test_sub_modules(self):
        from hydra_db import data, embeddings, fetch, key, recall, tenant, upload  # noqa: F401

    def test_fetch_list_data_response(self):
        from hydra_db import FetchListDataResponse  # noqa: F401


# ---------------------------------------------------------------------------
# TC-02  HydraDBEnvironment enum
# ---------------------------------------------------------------------------
class TestEnvironmentEnum:
    def test_hydra_db_prod_value(self):
        from hydra_db import HydraDBEnvironment
        assert HydraDBEnvironment.HYDRA_DB_PROD.value == "https://api.hydradb.com"

    def test_cortex_prod_value(self):
        from hydra_db import HydraDBEnvironment
        assert HydraDBEnvironment.CORTEX_PROD.value == "https://api.hydradb.com"

    def test_both_resolve_to_same_url(self):
        from hydra_db import HydraDBEnvironment
        assert HydraDBEnvironment.HYDRA_DB_PROD.value == HydraDBEnvironment.CORTEX_PROD.value


# ---------------------------------------------------------------------------
# TC-03  Sync HydraDB instantiation and sub-clients
# ---------------------------------------------------------------------------
class TestSyncClientInstantiation:
    def test_instantiates_with_token(self):
        from hydra_db import HydraDB
        client = HydraDB(token="test-token-123")
        assert client is not None

    @pytest.mark.parametrize("attr", ["upload", "tenant", "key", "embeddings", "fetch", "data", "recall"])
    def test_sub_client_accessible(self, attr):
        from hydra_db import HydraDB
        client = HydraDB(token="test-token-123")
        assert getattr(client, attr) is not None

    def test_with_raw_response_returns_raw_hydra_db(self):
        from hydra_db import HydraDB
        from hydra_db.raw_client import RawHydraDB
        client = HydraDB(token="test-token-123")
        assert isinstance(client.with_raw_response, RawHydraDB)

    def test_upload_with_raw_response(self):
        from hydra_db import HydraDB
        from hydra_db.upload.raw_client import RawUploadClient
        client = HydraDB(token="test-token-123")
        assert isinstance(client.upload.with_raw_response, RawUploadClient)

    def test_default_base_url_is_prod(self):
        from hydra_db import HydraDB
        client = HydraDB(token="t")
        assert client._client_wrapper.get_base_url() == "https://api.hydradb.com"


# ---------------------------------------------------------------------------
# TC-04  Async HydraDB instantiation and sub-clients
# ---------------------------------------------------------------------------
class TestAsyncClientInstantiation:
    def test_instantiates_with_token(self):
        from hydra_db import AsyncHydraDB
        client = AsyncHydraDB(token="test-token-async")
        assert client is not None

    @pytest.mark.parametrize("attr", ["upload", "tenant", "key", "embeddings", "fetch", "data", "recall"])
    def test_sub_client_accessible(self, attr):
        from hydra_db import AsyncHydraDB
        client = AsyncHydraDB(token="test-token-async")
        assert getattr(client, attr) is not None

    def test_with_raw_response_returns_async_raw_hydra_db(self):
        from hydra_db import AsyncHydraDB
        from hydra_db.raw_client import AsyncRawHydraDB
        client = AsyncHydraDB(token="test-token-async")
        assert isinstance(client.with_raw_response, AsyncRawHydraDB)

    def test_default_base_url_is_prod(self):
        from hydra_db import AsyncHydraDB
        client = AsyncHydraDB(token="t")
        assert client._client_wrapper.get_base_url() == "https://api.hydradb.com"


# ---------------------------------------------------------------------------
# TC-05  Default environment consistency between sync and async clients
# ---------------------------------------------------------------------------
class TestDefaultEnvironmentConsistency:
    def test_sync_and_async_share_same_default_env_member(self):
        from hydra_db import HydraDB, AsyncHydraDB
        sync_default = inspect.signature(HydraDB.__init__).parameters["environment"].default
        async_default = inspect.signature(AsyncHydraDB.__init__).parameters["environment"].default
        assert sync_default == async_default, (
            f"HydraDB defaults to {sync_default.name} but AsyncHydraDB defaults to "
            f"{async_default.name} — inconsistent public API"
        )


# ---------------------------------------------------------------------------
# TC-06  Token as callable
# ---------------------------------------------------------------------------
class TestTokenCallable:
    def test_callable_token_used_in_auth_header(self):
        from hydra_db import HydraDB
        calls = []

        def token_fn():
            calls.append(1)
            return "dynamic-token-xyz"

        client = HydraDB(token=token_fn)
        headers = client._client_wrapper.get_headers()
        assert headers["Authorization"] == "Bearer dynamic-token-xyz"
        assert len(calls) == 1

    def test_string_token_used_in_auth_header(self):
        from hydra_db import HydraDB
        client = HydraDB(token="static-token-abc")
        headers = client._client_wrapper.get_headers()
        assert headers["Authorization"] == "Bearer static-token-abc"

    def test_no_token_produces_no_auth_header(self):
        from hydra_db import HydraDB
        client = HydraDB()
        headers = client._client_wrapper.get_headers()
        assert "Authorization" not in headers


# ---------------------------------------------------------------------------
# TC-07  Custom headers propagated
# ---------------------------------------------------------------------------
class TestCustomHeaders:
    def test_custom_headers_merged_with_base_headers(self):
        from hydra_db import HydraDB
        client = HydraDB(token="tok", headers={"X-Custom-Header": "custom-value-42"})
        headers = client._client_wrapper.get_headers()
        assert headers["X-Custom-Header"] == "custom-value-42"
        assert "Authorization" in headers
        assert "X-Fern-Language" in headers

    def test_fern_language_header_always_present(self):
        from hydra_db import HydraDB
        client = HydraDB(token="t")
        headers = client._client_wrapper.get_headers()
        assert "X-Fern-Language" in headers


# ---------------------------------------------------------------------------
# TC-08  base_url override
# ---------------------------------------------------------------------------
class TestBaseUrlOverride:
    def test_base_url_takes_precedence_over_environment(self):
        from hydra_db import HydraDB, HydraDBEnvironment
        from hydra_db.client import _get_base_url
        result = _get_base_url(base_url="http://custom.example.com", environment=HydraDBEnvironment.HYDRA_DB_PROD)
        assert result == "http://custom.example.com"

    def test_none_base_url_falls_back_to_environment(self):
        from hydra_db import HydraDBEnvironment
        from hydra_db.client import _get_base_url
        result = _get_base_url(base_url=None, environment=HydraDBEnvironment.HYDRA_DB_PROD)
        assert result == "https://api.hydradb.com"

    def test_client_stores_custom_base_url(self):
        from hydra_db import HydraDB
        client = HydraDB(token="t", base_url="http://localhost:9999")
        assert client._client_wrapper.get_base_url() == "http://localhost:9999"


# ---------------------------------------------------------------------------
# TC-09  _parse_retry_after  (includes the retry-after-ms string bug check)
# ---------------------------------------------------------------------------
def _resp(headers: dict) -> httpx.Response:
    return httpx.Response(200, headers=headers)


class TestParseRetryAfter:
    def test_retry_after_ms_2000_returns_2_seconds(self):
        """Core regression: retry-after-ms header value is a string; comparison must use int()."""
        from hydra_db.core.http_client import _parse_retry_after
        result = _parse_retry_after(_resp({"retry-after-ms": "2000"}).headers)
        assert result == 2.0, f"Expected 2.0 got {result!r}"

    def test_retry_after_ms_500_returns_0_point_5(self):
        from hydra_db.core.http_client import _parse_retry_after
        result = _parse_retry_after(_resp({"retry-after-ms": "500"}).headers)
        assert result == 0.5

    def test_retry_after_ms_zero_returns_zero(self):
        from hydra_db.core.http_client import _parse_retry_after
        result = _parse_retry_after(_resp({"retry-after-ms": "0"}).headers)
        assert result == 0

    def test_retry_after_ms_negative_returns_zero(self):
        from hydra_db.core.http_client import _parse_retry_after
        result = _parse_retry_after(_resp({"retry-after-ms": "-500"}).headers)
        assert result == 0

    def test_retry_after_numeric_seconds(self):
        from hydra_db.core.http_client import _parse_retry_after
        result = _parse_retry_after(_resp({"retry-after": "30"}).headers)
        assert result == 30.0

    def test_no_retry_after_header_returns_none(self):
        from hydra_db.core.http_client import _parse_retry_after
        result = _parse_retry_after(_resp({}).headers)
        assert result is None

    def test_retry_after_ms_takes_priority_over_retry_after(self):
        """retry-after-ms should be parsed first and returned, retry-after ignored."""
        from hydra_db.core.http_client import _parse_retry_after
        result = _parse_retry_after(_resp({"retry-after-ms": "3000", "retry-after": "1"}).headers)
        assert result == 3.0


# ---------------------------------------------------------------------------
# TC-10  _should_retry
# ---------------------------------------------------------------------------
class TestShouldRetry:
    @pytest.mark.parametrize("status,expected", [
        (200, False),
        (201, False),
        (400, False),
        (401, False),
        (403, False),
        (404, False),
        (408, True),
        (409, True),
        (429, True),
        (500, True),
        (502, True),
        (503, True),
        (504, True),
    ])
    def test_status_code(self, status, expected):
        from hydra_db.core.http_client import _should_retry
        assert _should_retry(httpx.Response(status)) == expected


# ---------------------------------------------------------------------------
# TC-11  get_request_body
# ---------------------------------------------------------------------------
class TestGetRequestBody:
    def test_both_none_returns_none_none(self):
        from hydra_db.core.http_client import get_request_body
        json_body, data_body = get_request_body(json=None, data=None, request_options=None, omit=None)
        assert json_body is None
        assert data_body is None

    def test_json_dict_with_additional_body_params_merged(self):
        from hydra_db.core.http_client import get_request_body
        json_body, data_body = get_request_body(
            json={"key": "value"},
            data=None,
            request_options={"additional_body_parameters": {"extra": "param"}},
            omit=None,
        )
        assert json_body is not None
        assert json_body["key"] == "value"
        assert json_body["extra"] == "param"
        assert data_body is None

    def test_empty_json_dict_becomes_none(self):
        from hydra_db.core.http_client import get_request_body
        json_body, data_body = get_request_body(json={}, data=None, request_options=None, omit=None)
        assert json_body is None

    def test_data_present_goes_to_data_body_not_json_body(self):
        from hydra_db.core.http_client import get_request_body
        json_body, data_body = get_request_body(
            json={"ignored": True},
            data={"form_key": "form_val"},
            request_options=None,
            omit=None,
        )
        assert json_body is None
        assert data_body is not None
        assert data_body["form_key"] == "form_val"

    def test_empty_data_dict_becomes_none(self):
        from hydra_db.core.http_client import get_request_body
        json_body, data_body = get_request_body(json=None, data={}, request_options=None, omit=None)
        assert data_body is None


# ---------------------------------------------------------------------------
# TC-12  remove_omit_from_dict
# ---------------------------------------------------------------------------
OMIT = ...  # The sentinel used throughout the SDK


class TestRemoveOmitFromDict:
    def test_omit_sentinel_removed(self):
        from hydra_db.core.http_client import remove_omit_from_dict
        result = remove_omit_from_dict({"a": 1, "b": OMIT, "c": "hello"}, omit=OMIT)
        assert "b" not in result
        assert result["a"] == 1
        assert result["c"] == "hello"

    def test_none_zero_false_not_removed(self):
        from hydra_db.core.http_client import remove_omit_from_dict
        result = remove_omit_from_dict({"a": None, "b": 0, "c": False}, omit=OMIT)
        assert "a" in result
        assert "b" in result
        assert "c" in result

    def test_omit_is_none_returns_original(self):
        from hydra_db.core.http_client import remove_omit_from_dict
        original = {"a": 1}
        result = remove_omit_from_dict(original, omit=None)
        assert result == {"a": 1}


# ---------------------------------------------------------------------------
# TC-13  MemoryItem model
# ---------------------------------------------------------------------------
class TestMemoryItem:
    def test_all_optional_no_args(self):
        from hydra_db import MemoryItem
        item = MemoryItem()
        assert item is not None

    def test_with_text_and_infer(self):
        from hydra_db import MemoryItem
        item = MemoryItem(text="User prefers dark mode", infer=True, user_name="John")
        assert item.text == "User prefers dark mode"
        assert item.infer is True
        assert item.user_name == "John"

    def test_with_user_assistant_pairs(self):
        from hydra_db import MemoryItem, UserAssistantPair
        pair = UserAssistantPair(user="What is X?", assistant="X is Y.")
        item = MemoryItem(user_assistant_pairs=[pair], infer=True)
        assert len(item.user_assistant_pairs) == 1
        assert item.user_assistant_pairs[0].user == "What is X?"

    def test_frozen_raises_on_mutation(self):
        from hydra_db import MemoryItem
        item = MemoryItem(text="immutable")
        with pytest.raises(Exception):
            item.text = "modified"  # type: ignore[misc]


# ---------------------------------------------------------------------------
# TC-14  Other type models
# ---------------------------------------------------------------------------
class TestTypeModels:
    def test_user_assistant_pair(self):
        from hydra_db import UserAssistantPair
        obj = UserAssistantPair(user="hello", assistant="world")
        assert obj.user == "hello"
        assert obj.assistant == "world"

    def test_pagination_meta_with_required_fields(self):
        from hydra_db import PaginationMeta
        obj = PaginationMeta(
            total=10, page=1, page_size=10,
            total_pages=1, has_next=False, has_previous=False,
        )
        assert obj.total == 10
        assert obj.has_next is False

    def test_delete_result_with_required_field(self):
        from hydra_db import DeleteResult
        obj = DeleteResult(delete_count=3)
        assert obj.delete_count == 3

    def test_insert_result_with_required_field(self):
        from hydra_db import InsertResult
        obj = InsertResult(insert_count=5)
        assert obj.insert_count == 5

    def test_error_response_all_optional(self):
        from hydra_db import ErrorResponse
        obj = ErrorResponse()
        assert obj is not None


# ---------------------------------------------------------------------------
# TC-15  Serialization utilities
# ---------------------------------------------------------------------------
class TestSerialization:
    def test_field_metadata_alias(self):
        from hydra_db.core.serialization import FieldMetadata
        fm = FieldMetadata(alias="my_alias")
        assert fm.alias == "my_alias"

    def test_convert_none_returns_none(self):
        from hydra_db.core.serialization import convert_and_respect_annotation_metadata
        result = convert_and_respect_annotation_metadata(object_=None, annotation=str, direction="read")
        assert result is None

    def test_convert_plain_dict_passthrough(self):
        from hydra_db.core.serialization import convert_and_respect_annotation_metadata
        d = {"a": 1, "b": "hello"}
        result = convert_and_respect_annotation_metadata(object_=d, annotation=typing.Dict[str, typing.Any], direction="read")
        assert result["a"] == 1


# ---------------------------------------------------------------------------
# TC-16  datetime_utils
# ---------------------------------------------------------------------------
class TestDatetimeUtils:
    def test_aware_datetime_serialized_as_string(self):
        from hydra_db.core.datetime_utils import serialize_datetime
        aware = dt.datetime(2024, 1, 15, 12, 0, 0, tzinfo=dt.timezone.utc)
        result = serialize_datetime(aware)
        assert isinstance(result, str)
        assert "2024" in result

    def test_naive_datetime_serialized_as_string(self):
        from hydra_db.core.datetime_utils import serialize_datetime
        naive = dt.datetime(2024, 6, 1, 9, 30, 0)
        result = serialize_datetime(naive)
        assert isinstance(result, str)
        assert "2024" in result

    def test_aware_utc_produces_z_suffix(self):
        from hydra_db.core.datetime_utils import serialize_datetime
        aware = dt.datetime(2024, 1, 15, 12, 0, 0, tzinfo=dt.timezone.utc)
        result = serialize_datetime(aware)
        assert result == "2024-01-15T12:00:00Z"


# ---------------------------------------------------------------------------
# TC-17  __all__ completeness
# ---------------------------------------------------------------------------
class TestAllCompleteness:
    def test_all_names_accessible_as_attributes(self):
        import hydra_db
        missing = [name for name in hydra_db.__all__ if not hasattr(hydra_db, name)]
        assert missing == [], f"Names in __all__ but not accessible: {missing}"

    def test_all_has_reasonable_count(self):
        import hydra_db
        # Should have at minimum the types + errors + clients
        assert len(hydra_db.__all__) >= 70


# ---------------------------------------------------------------------------
# TC-18  _retry_timeout bounds
# ---------------------------------------------------------------------------
class TestRetryTimeout:
    def test_always_non_negative(self):
        from hydra_db.core.http_client import _retry_timeout
        resp = httpx.Response(500)
        for attempt in range(15):
            assert _retry_timeout(resp, attempt) >= 0

    def test_capped_at_max_retry_delay(self):
        from hydra_db.core.http_client import _retry_timeout, MAX_RETRY_DELAY_SECONDS
        resp = httpx.Response(500)
        for attempt in range(15):
            # Allow tiny float margin above the cap (jitter math)
            assert _retry_timeout(resp, attempt) <= MAX_RETRY_DELAY_SECONDS + 0.01

    def test_retry_after_header_respected_when_within_limit(self):
        from hydra_db.core.http_client import _retry_timeout, MAX_RETRY_DELAY_SECONDS_FROM_HEADER
        resp = httpx.Response(429, headers={"retry-after": "5"})
        result = _retry_timeout(resp, 0)
        assert result == 5.0


# ---------------------------------------------------------------------------
# TC-19  Sub-client with_raw_response types
# ---------------------------------------------------------------------------
class TestSubClientRawResponse:
    @pytest.mark.parametrize("attr,expected_cls_path", [
        ("recall",     "hydra_db.recall.raw_client.RawRecallClient"),
        ("tenant",     "hydra_db.tenant.raw_client.RawTenantClient"),
        ("key",        "hydra_db.key.raw_client.RawKeyClient"),
        ("fetch",      "hydra_db.fetch.raw_client.RawFetchClient"),
        ("embeddings", "hydra_db.embeddings.raw_client.RawEmbeddingsClient"),
        ("data",       "hydra_db.data.raw_client.RawDataClient"),
    ])
    def test_sync_sub_client_raw_response_type(self, attr, expected_cls_path):
        import importlib
        from hydra_db import HydraDB
        module_path, cls_name = expected_cls_path.rsplit(".", 1)
        expected_cls = getattr(importlib.import_module(module_path), cls_name)
        client = HydraDB(token="t")
        raw = getattr(client, attr).with_raw_response
        assert isinstance(raw, expected_cls)


# ---------------------------------------------------------------------------
# TC-20  query_encoder and jsonable_encoder
# ---------------------------------------------------------------------------
class TestEncoders:
    def test_encode_query_basic_dict(self):
        from hydra_db.core.query_encoder import encode_query
        result = encode_query({"key": "value", "num": 42})
        result_dict = dict(result)
        assert result_dict["key"] == "value"
        assert result_dict["num"] == 42

    def test_jsonable_encoder_datetime(self):
        from hydra_db.core.jsonable_encoder import jsonable_encoder
        result = jsonable_encoder({"dt": dt.datetime(2024, 1, 1, tzinfo=dt.timezone.utc)})
        assert isinstance(result, dict)

    def test_jsonable_encoder_none(self):
        from hydra_db.core.jsonable_encoder import jsonable_encoder
        assert jsonable_encoder(None) is None

    def test_jsonable_encoder_plain_dict(self):
        from hydra_db.core.jsonable_encoder import jsonable_encoder
        result = jsonable_encoder({"a": 1, "b": "hello"})
        assert result["a"] == 1
        assert result["b"] == "hello"


# ---------------------------------------------------------------------------
# TC-21  Pydantic v2 compatibility
# ---------------------------------------------------------------------------
class TestPydanticCompatibility:
    def test_is_pydantic_v2_flag_matches_installed_version(self):
        from hydra_db.core.pydantic_utilities import IS_PYDANTIC_V2
        expected = pydantic.VERSION.startswith("2.")
        assert IS_PYDANTIC_V2 == expected

    def test_universal_base_model_constructs(self):
        from hydra_db.core.pydantic_utilities import UniversalBaseModel

        class TestModel(UniversalBaseModel):
            name: str
            value: int = 0

        m = TestModel(name="hello", value=42)
        assert m.name == "hello"
        assert m.value == 42

    def test_universal_base_model_validates_types(self):
        from hydra_db.core.pydantic_utilities import UniversalBaseModel

        class StrictModel(UniversalBaseModel):
            count: int

        with pytest.raises(Exception):
            StrictModel(count="not-an-int")  # type: ignore[arg-type]
