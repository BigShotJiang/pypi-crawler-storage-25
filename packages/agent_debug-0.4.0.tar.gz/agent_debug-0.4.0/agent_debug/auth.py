"""Credential storage for agent-debug.

Stores API keys in ~/.agent-debug/credentials.json.
Priority (for each provider):
  1. Environment variable  (ANTHROPIC_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY)
  2. Stored credentials    (~/.agent-debug/credentials.json)
  3. Prompt user to run `agent-debug login`
"""

import json
import os
import stat
from pathlib import Path
from typing import Literal

Provider = Literal["anthropic", "openai", "deepseek"]

CREDENTIALS_FILE = Path.home() / ".agent-debug" / "credentials.json"

# Map provider → env var name
_ENV_VARS: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
}

# Map provider → API key management URL (for the login wizard)
_KEY_URLS: dict[str, str] = {
    "anthropic": "https://console.anthropic.com/settings/keys",
    "openai": "https://platform.openai.com/api-keys",
    "deepseek": "https://platform.deepseek.com/api_keys",
}

# Map provider → key prefix for basic validation
_KEY_PREFIXES: dict[str, str] = {
    "anthropic": "sk-ant-",
    "openai": "sk-",
    "deepseek": "sk-",
}


def _load_all() -> dict:
    if not CREDENTIALS_FILE.exists():
        return {}
    try:
        return json.loads(CREDENTIALS_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _save_all(data: dict) -> None:
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_FILE.write_text(json.dumps(data, indent=2))
    # Restrict to owner read/write only
    CREDENTIALS_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)


def get_api_key(provider: str) -> str | None:
    """Return API key for provider, checking env vars first then stored creds."""
    env_var = _ENV_VARS.get(provider)
    if env_var:
        val = os.environ.get(env_var)
        if val:
            return val
    creds = _load_all()
    return creds.get(provider, {}).get("api_key")


def save_credentials(provider: str, api_key: str) -> None:
    """Save API key for provider to credentials file."""
    data = _load_all()
    if provider not in data:
        data[provider] = {}
    data[provider]["api_key"] = api_key
    _save_all(data)


def delete_credentials(provider: str | None) -> list[str]:
    """Delete stored credentials. Returns list of deleted providers."""
    data = _load_all()
    if provider is None:
        deleted = list(data.keys())
        _save_all({})
        return deleted
    if provider in data:
        del data[provider]
        _save_all(data)
        return [provider]
    return []


def list_stored() -> dict[str, dict]:
    """Return stored credentials (with masked keys)."""
    data = _load_all()
    result = {}
    for prov, info in data.items():
        key = info.get("api_key", "")
        result[prov] = {
            "api_key_masked": _mask_key(key),
            "source": "stored",
        }
    return result


def current_status() -> dict[str, dict]:
    """Return auth status for all known providers."""
    status = {}
    for provider in _ENV_VARS:
        env_var = _ENV_VARS[provider]
        env_val = os.environ.get(env_var)
        stored = _load_all().get(provider, {}).get("api_key")
        if env_val:
            status[provider] = {"source": f"env ({env_var})", "key": _mask_key(env_val)}
        elif stored:
            status[provider] = {"source": "stored (~/.agent-debug/credentials.json)", "key": _mask_key(stored)}
        else:
            status[provider] = {"source": None, "key": None}
    return status


def key_url(provider: str) -> str:
    return _KEY_URLS.get(provider, "https://console.anthropic.com/settings/keys")


def validate_key_format(provider: str, key: str) -> bool:
    """Basic format check — does not make API call."""
    prefix = _KEY_PREFIXES.get(provider)
    if not prefix:
        return len(key) > 10
    return key.startswith(prefix) and len(key) > len(prefix) + 5


def _mask_key(key: str) -> str:
    if len(key) <= 8:
        return "****"
    return key[:8] + "..." + key[-4:]
