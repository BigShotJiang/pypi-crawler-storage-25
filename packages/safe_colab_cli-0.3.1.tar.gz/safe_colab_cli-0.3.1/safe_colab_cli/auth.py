"""Authentication and credential management.

Stores credentials in ~/.safe-colab/.env (or $SAFE_COLAB_HOME/.env).
Supports interactive Hypha login with browser-based OAuth.
"""

import os
import re
import json
import base64
import time
from pathlib import Path
from typing import Optional


def get_config_dir() -> Path:
    """Get the safe-colab config directory (~/.safe-colab/)."""
    home = os.environ.get("SAFE_COLAB_HOME", os.path.join(Path.home(), ".safe-colab"))
    return Path(home)


def get_credentials_path() -> Path:
    """Get the credentials file path."""
    return get_config_dir() / ".env"


def save_credentials(server_url: str, token: str, workspace: str):
    """Save credentials to ~/.safe-colab/.env"""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)
    cred_path = get_credentials_path()

    # Read existing lines, preserve non-credential entries
    existing = {}
    if cred_path.exists():
        for line in cred_path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if "=" in line:
                key, val = line.split("=", 1)
                existing[key.strip()] = val.strip()

    existing["HYPHA_SERVER_URL"] = server_url
    existing["HYPHA_TOKEN"] = token
    existing["HYPHA_WORKSPACE"] = workspace

    lines = [f"{k}={v}" for k, v in existing.items()]
    cred_path.write_text("\n".join(lines) + "\n")
    cred_path.chmod(0o600)  # Owner-only read/write
    return cred_path


def load_credentials() -> dict:
    """Load credentials from ~/.safe-colab/.env

    Returns dict with keys: server_url, token, workspace (any may be None).
    """
    result = {"server_url": None, "token": None, "workspace": None}

    cred_path = get_credentials_path()
    if not cred_path.exists():
        return result

    for line in cred_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        key, val = line.split("=", 1)
        key = key.strip()
        val = val.strip().strip("\"'")

        if key == "HYPHA_SERVER_URL":
            result["server_url"] = val
        elif key == "HYPHA_TOKEN":
            result["token"] = val
        elif key == "HYPHA_WORKSPACE":
            result["workspace"] = val

    # Validate token expiry
    if result["token"] and is_token_expired(result["token"]):
        result["token"] = None

    return result


def decode_token(token: str) -> Optional[dict]:
    """Decode JWT payload without verification (for extracting claims)."""
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None
        payload_b64 = parts[1]
        # Add padding
        pad = len(payload_b64) % 4
        if pad:
            payload_b64 += "=" * (4 - pad)
        return json.loads(base64.b64decode(payload_b64))
    except Exception:
        return None


def is_token_expired(token: str) -> bool:
    """Check if a JWT token has expired."""
    payload = decode_token(token)
    if not payload:
        return True
    exp = payload.get("exp")
    if not exp:
        return False
    return time.time() > exp


def extract_workspace_from_token(token: str) -> Optional[str]:
    """Extract workspace ID from token's scope claim."""
    payload = decode_token(token)
    if not payload:
        return None
    scope = payload.get("scope", "")
    # Match patterns like "ws:my-workspace#rw" or "wid:my-workspace"
    m = re.search(r"ws:([\w\-|]+)#", scope)
    if m:
        return m.group(1)
    m = re.search(r"wid:([\w\-|]+)", scope)
    if m:
        return m.group(1)
    return None


def extract_email_from_token(token: str) -> Optional[str]:
    """Extract email from token claims."""
    payload = decode_token(token)
    if not payload:
        return None
    return payload.get("https://amun.ai/email")
