"""Hypha service registration - exposes code execution, shell commands, and file sharing."""

import os
import secrets
import asyncio
import subprocess
import base64
import json
from hypha_rpc import connect_to_server

from .artifacts import SessionArtifactManager


def _build_service_url(server_url: str, service_id: str) -> str:
    """Build the HTTP service URL, stripping the clientId prefix."""
    base = server_url.rstrip("/")
    parts = service_id.split("/", 1)
    if len(parts) == 2:
        workspace, svc_part = parts
        if ":" in svc_part:
            svc_name = svc_part.split(":", 1)[1]
        else:
            svc_name = svc_part
        return f"{base}/{workspace}/services/{svc_name}"
    return f"{base}/services/{service_id}"


def _build_agent_instructions(service_url: str, data_dir: str, work_dir: str) -> str:
    """Build agent instructions with curl examples for all endpoints."""
    return f"""\
## Safe Colab - Remote Code Execution Environment

You have access to a sandboxed Python environment on a remote machine.
The service URL below acts as a secret — no additional token is needed.

**Service URL:** `{service_url}`

### Endpoints

#### 1. `run_code(code: str) -> dict`
Execute Python code in a persistent Jupyter kernel. Variables and imports persist across calls.
```bash
curl -s -X POST "$SERVICE_URL/run_code" \\
  -H "Content-Type: application/json" \\
  -d '{{"code": "import pandas as pd; df = pd.read_csv(\\"{data_dir}/patient_health.csv\\"); print(df.shape)"}}'
```
Returns: `{{"stdout": "...", "stderr": "...", "result": "...", "error": null | {{"ename": "...", "evalue": "...", "traceback": [...]}}, "display_data": [...]}}`

#### 2. `execute_command(command: str, timeout: int = 60) -> dict`
Run shell commands (pip install, ls, cat, wget, etc.).
```bash
curl -s -X POST "$SERVICE_URL/execute_command" \\
  -H "Content-Type: application/json" \\
  -d '{{"command": "pip install scikit-learn matplotlib"}}'
```
Returns: `{{"stdout": "...", "stderr": "...", "returncode": 0}}`

#### 3. `upload_file(file_path: str, remote_name: str = None) -> dict`
Upload a file from the working directory to the shared artifact store. Returns a presigned download URL.
```bash
curl -s -X POST "$SERVICE_URL/upload_file" \\
  -H "Content-Type: application/json" \\
  -d '{{"file_path": "{work_dir}/results.csv"}}'
```
Returns: `{{"url": "https://...", "remote_path": "results.csv"}}`

#### 4. `list_shared_files() -> list`
List all files uploaded to the session artifact store.

#### 5. `get_docs() -> str`
Get detailed documentation about the environment.

### Environment Details
- **Data directory** (read-only): `{data_dir}` — dataset files
- **Working directory** (read-write): `{work_dir}` — outputs, results, logs
- Full Python 3 with pip. Install packages via `execute_command("pip install <pkg>")`
- Jupyter kernel state persists across `run_code` calls
- Generated files (plots, CSVs) can be shared via `upload_file` — returns a URL

### Quick Start
```bash
SERVICE_URL="{service_url}"

# 1. Check what data is available
curl -s -X POST "$SERVICE_URL/execute_command" -H "Content-Type: application/json" \\
  -d '{{"command": "ls -la {data_dir}"}}'

# 2. Install needed packages
curl -s -X POST "$SERVICE_URL/execute_command" -H "Content-Type: application/json" \\
  -d '{{"command": "pip install pandas matplotlib scikit-learn"}}'

# 3. Run analysis code
curl -s -X POST "$SERVICE_URL/run_code" -H "Content-Type: application/json" \\
  -d '{{"code": "import pandas as pd\\ndf = pd.read_csv(\\\"{data_dir}/patient_health.csv\\\")\\nprint(df.describe())"}}'

# 4. Save and share results
curl -s -X POST "$SERVICE_URL/run_code" -H "Content-Type: application/json" \\
  -d '{{"code": "df.to_csv(\\\"{work_dir}/output.csv\\\", index=False)\\nprint(\\\"saved\\\")"}}'
curl -s -X POST "$SERVICE_URL/upload_file" -H "Content-Type: application/json" \\
  -d '{{"file_path": "{work_dir}/output.csv"}}'
```

### Rules
- Do NOT access files outside the data and working directories
- The environment is sandboxed — filesystem access is restricted
- Large outputs are truncated to 50KB
- Code execution timeout: 120 seconds per cell
- All code executions and commands are logged for auditing
"""


async def register_service(
    server_url: str,
    workspace: str,
    token: str,
    kernel,
    data_dir: str,
    work_dir: str,
    session_id: str = None,
):
    """Connect to Hypha and register the code execution service.

    Registers as unlisted with a random service ID (URL-as-secret pattern).
    Returns (server, service_info, agent_instructions, service_url).
    """
    if session_id is None:
        session_id = secrets.token_hex(16)

    server = await connect_to_server({
        "server_url": server_url,
        "workspace": workspace,
        "token": token,
    })
    actual_workspace = (
        server.config.get("workspace", workspace)
        if hasattr(server.config, "get")
        else getattr(server.config, "workspace", workspace)
    )
    print(f"[hypha] Connected to {server_url}, workspace: {actual_workspace}")

    # Initialize artifact manager for file sharing and audit logging
    artifact_mgr = None
    try:
        am_service = await server.get_service("public/artifact-manager")
        artifact_mgr = SessionArtifactManager(am_service, session_id, actual_workspace)
        await artifact_mgr.initialize()
        print(f"[hypha] Session artifact created for file sharing and audit logging")
    except Exception as e:
        print(f"[hypha] Warning: Artifact manager not available ({e}). File sharing disabled.")

    # ── Endpoint: run_code ──
    async def run_code(code: str) -> dict:
        """Execute Python code in the sandboxed Jupyter kernel.
        Variables and imports persist across calls."""
        result = await kernel.execute(code)
        max_len = 50000
        for key in ("stdout", "stderr"):
            if result[key] and len(result[key]) > max_len:
                result[key] = result[key][:max_len] + "\n... (truncated)"
        # Audit log
        if artifact_mgr:
            try:
                await artifact_mgr.log_code_execution(code, result)
            except Exception:
                pass
        return result

    # ── Endpoint: execute_command ──
    # Build env with venv's bin on PATH so pip/python resolve correctly
    import sys
    _cmd_env = os.environ.copy()
    _venv_bin = os.path.dirname(sys.executable)
    _cmd_env["PATH"] = _venv_bin + os.pathsep + _cmd_env.get("PATH", "")
    _cmd_env["VIRTUAL_ENV"] = os.path.dirname(_venv_bin)

    async def execute_command(command: str, timeout: int = 60) -> dict:
        """Execute a shell command in the working directory.
        Use for pip install, file listing, system tools, etc."""
        try:
            proc = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: subprocess.run(
                    command, shell=True, capture_output=True, text=True,
                    timeout=timeout, cwd=work_dir, env=_cmd_env,
                ),
            )
            result = {"stdout": proc.stdout, "stderr": proc.stderr, "returncode": proc.returncode}
            max_len = 50000
            for key in ("stdout", "stderr"):
                if len(result[key]) > max_len:
                    result[key] = result[key][:max_len] + "\n... (truncated)"
        except subprocess.TimeoutExpired:
            result = {"stdout": "", "stderr": f"Command timed out after {timeout}s", "returncode": -1}
        # Audit log
        if artifact_mgr:
            try:
                await artifact_mgr.log_command_execution(command, result)
            except Exception:
                pass
        return result

    # ── Endpoint: upload_file ──
    async def upload_file(file_path: str, remote_name: str = None) -> dict:
        """Upload a file from the working directory to the shared artifact store.
        Returns a presigned download URL for the remote agent."""
        if artifact_mgr is None:
            return {"error": "Artifact manager not available. File sharing is disabled."}

        # Security: only allow files within work_dir or data_dir
        abs_path = os.path.abspath(file_path)
        allowed = abs_path.startswith(os.path.abspath(work_dir))
        if data_dir and data_dir != "(none)":
            allowed = allowed or abs_path.startswith(os.path.abspath(data_dir))
        if not allowed:
            return {"error": f"Access denied: file must be within work_dir or data_dir"}

        if not os.path.exists(abs_path):
            return {"error": f"File not found: {file_path}"}

        if remote_name is None:
            remote_name = os.path.basename(abs_path)

        try:
            url = await artifact_mgr.upload_file(abs_path, remote_name)
            return {"url": url, "remote_path": remote_name}
        except Exception as e:
            return {"error": f"Upload failed: {str(e)}"}

    # ── Endpoint: list_shared_files ──
    async def list_shared_files() -> list:
        """List all files uploaded to the session artifact store."""
        if artifact_mgr is None:
            return []
        try:
            return await artifact_mgr.list_files()
        except Exception:
            return []

    # ── Endpoint: get_docs ──
    async def get_docs() -> str:
        """Get documentation about the sandboxed environment."""
        return f"""# Safe Colab Environment

## Data Directory (read-only): {data_dir}
Contains the dataset files provided by the data owner.

## Working Directory (read-write): {work_dir}
Write outputs, logs, results, and reports here.

## Available Endpoints
- `run_code(code)` — Execute Python (persistent kernel, like Jupyter)
- `execute_command(command)` — Run shell commands (pip, ls, cat, etc.)
- `upload_file(file_path)` — Upload file to artifact store, get shareable URL
- `list_shared_files()` — List uploaded files
- `get_docs()` — This documentation

## Capabilities
- Full Python 3 environment with persistent Jupyter kernel
- Install any pip package: `execute_command("pip install numpy pandas matplotlib")`
- Read data files from {data_dir}
- Write results to {work_dir}
- Share large files (plots, datasets) via `upload_file()` → returns download URL

## Tips
- Install packages FIRST with execute_command before using them in run_code
- Variables persist across run_code calls (like Jupyter cells)
- For large outputs, write to file then upload_file() instead of printing
- All operations are logged for auditing
"""

    # ── Register service ──
    service_id = f"safe-colab-{secrets.token_hex(16)}"

    svc_info = await server.register_service({
        "id": service_id,
        "name": "Safe Colab Sandbox",
        "type": "code-interpreter",
        "description": "Sandboxed Python environment for safe remote code execution",
        "config": {
            "visibility": "unlisted",
            "require_context": False,
            "run_in_executor": True,
        },
        "run_code": run_code,
        "execute_command": execute_command,
        "upload_file": upload_file,
        "list_shared_files": list_shared_files,
        "get_docs": get_docs,
    })

    actual_id = svc_info.get("id", service_id) if isinstance(svc_info, dict) else service_id
    service_url = _build_service_url(server_url, actual_id)

    instructions = _build_agent_instructions(
        service_url=service_url,
        data_dir=data_dir,
        work_dir=work_dir,
    )

    print(f"[hypha] Service registered: {actual_id}")
    print(f"[hypha] Service URL: {service_url}")
    return server, svc_info, instructions, service_url
