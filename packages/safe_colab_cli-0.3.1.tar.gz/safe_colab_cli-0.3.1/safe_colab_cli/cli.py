"""CLI entry point for safe-colab."""

import asyncio
import os
import signal
import sys

import click
from dotenv import load_dotenv

from .auth import (
    load_credentials,
    save_credentials,
    extract_workspace_from_token,
    extract_email_from_token,
    get_credentials_path,
    is_token_expired,
)

# Load .env for development/testing (override so .env wins over inherited env)
load_dotenv(override=True)


def _resolve_credentials(server_url, workspace, token):
    """Resolve credentials from CLI args → env vars → saved credentials."""
    # CLI args take priority, then env vars, then saved creds
    saved = load_credentials()

    if not server_url:
        server_url = os.environ.get("HYPHA_SERVER_URL") or saved.get("server_url")
    if not token:
        token = os.environ.get("HYPHA_TOKEN") or saved.get("token")
    if not workspace:
        workspace = os.environ.get("HYPHA_WORKSPACE") or saved.get("workspace")

    # Default server URL
    if not server_url:
        server_url = "https://hypha.aicell.io"

    # Extract workspace from token if not provided
    if not workspace and token:
        workspace = extract_workspace_from_token(token)

    return server_url, workspace, token


@click.group()
def main():
    """Safe Colab CLI - Sandboxed Python environment for safe AI collaboration."""
    pass


# ─── LOGIN ───────────────────────────────────────────────────────────

@main.command()
@click.option("--server-url", default=None, help="Hypha server URL (default: https://hypha.aicell.io)")
@click.option("--workspace", default=None, help="Workspace to log into (default: your personal workspace)")
def login(server_url, workspace):
    """Log in to Hypha interactively via browser.

    Opens a browser-based OAuth login and saves credentials to ~/.safe-colab/.env
    so you don't need to log in every time.
    """
    asyncio.run(_do_login(server_url or "https://hypha.aicell.io", workspace))


async def _do_login(server_url, workspace):
    from hypha_rpc import login as hypha_login, connect_to_server

    click.echo(f"Logging in to {server_url}...")

    login_config = {
        "server_url": server_url,
        "login_timeout": 120,
    }
    if workspace:
        login_config["workspace"] = workspace

    async def login_callback(context):
        click.echo()
        click.echo("Please open this URL in your browser:")
        click.echo(f"  {context['login_url']}")
        click.echo()
        click.echo("Waiting for you to complete login in the browser...")

    login_config["login_callback"] = login_callback

    try:
        token_info = await hypha_login(login_config)
    except Exception as e:
        click.echo(f"Login failed: {e}", err=True)
        sys.exit(1)

    token = token_info.get("token") if isinstance(token_info, dict) else token_info

    # Exchange for a long-lived token (6 months)
    click.echo("Generating long-lived token...")
    try:
        connect_config = {"server_url": server_url, "token": token}
        if workspace:
            connect_config["workspace"] = workspace
        server = await connect_to_server(connect_config)
        six_months = 6 * 30 * 24 * 3600
        actual_workspace = (
            server.config.get("workspace", workspace)
            if hasattr(server.config, "get")
            else getattr(server.config, "workspace", workspace)
        )
        long_token = await server.generate_token({"expires_in": six_months})
        await server.disconnect()
    except Exception as e:
        click.echo(f"Warning: Could not generate long-lived token ({e}). Using short-lived token.", err=True)
        long_token = token
        actual_workspace = workspace or extract_workspace_from_token(token)

    # Save
    if not actual_workspace:
        actual_workspace = extract_workspace_from_token(long_token) or ""

    cred_path = save_credentials(server_url, long_token, actual_workspace)
    email = extract_email_from_token(long_token) or "unknown"

    click.echo()
    click.echo("Login successful!")
    click.echo(f"  User:      {email}")
    click.echo(f"  Workspace: {actual_workspace}")
    click.echo(f"  Server:    {server_url}")
    click.echo(f"  Saved to:  {cred_path}")


# ─── LOGOUT ──────────────────────────────────────────────────────────

@main.command()
def logout():
    """Remove saved credentials."""
    cred_path = get_credentials_path()
    if cred_path.exists():
        cred_path.unlink()
        click.echo(f"Credentials removed: {cred_path}")
    else:
        click.echo("No saved credentials found.")


# ─── STATUS ──────────────────────────────────────────────────────────

@main.command()
def status():
    """Show current login status and credentials."""
    saved = load_credentials()
    if saved.get("token"):
        email = extract_email_from_token(saved["token"]) or "unknown"
        expired = is_token_expired(saved["token"])
        click.echo(f"  Logged in as: {email}")
        click.echo(f"  Workspace:    {saved.get('workspace', 'unknown')}")
        click.echo(f"  Server:       {saved.get('server_url', 'unknown')}")
        click.echo(f"  Token:        {'EXPIRED' if expired else 'valid'}")
        click.echo(f"  Credentials:  {get_credentials_path()}")
    else:
        click.echo("Not logged in. Run: safe-colab login")


# ─── START ───────────────────────────────────────────────────────────

@main.command()
@click.option("--data-dir", "-d", type=click.Path(exists=True), default=None,
              help="Read-only data directory to mount")
@click.option("--work-dir", "-w", type=click.Path(), default=None,
              help="Read-write working directory (default: current directory)")
@click.option("--server-url", default=None, help="Hypha server URL")
@click.option("--workspace", default=None, help="Hypha workspace (default: from login)")
@click.option("--token", default=None, help="Hypha token (default: from login)")
@click.option("--sandbox", type=click.Choice(["auto", "nono", "docker", "none"]),
              default="auto", help="Sandbox backend (auto-detects by default)")
@click.option("--no-sandbox", is_flag=True, default=False,
              help="Disable sandboxing entirely (shorthand for --sandbox none)")
@click.option("--timeout", type=float, default=120,
              help="Default code execution timeout in seconds")
def start(data_dir, work_dir, server_url, workspace, token, sandbox, no_sandbox, timeout):
    """Start a sandboxed Safe Colab session.

    Launches a Jupyter kernel in a sandboxed environment and registers
    it as a Hypha service for remote code execution.

    The kernel process is sandboxed (not the CLI itself). Sandbox backends:
    - nono: filesystem isolation via nono CLI (macOS/Linux)
    - docker: runs kernel in a Docker container with volume mounts
    - auto: tries nono first, then docker, falls back to none
    - none: no sandboxing (development/testing only)
    """
    # Resolve credentials: CLI args → env → saved credentials
    server_url, workspace, token = _resolve_credentials(server_url, workspace, token)

    if not token:
        click.echo("Error: Not logged in. Run: safe-colab login", err=True)
        click.echo("  Or set HYPHA_TOKEN environment variable", err=True)
        sys.exit(1)

    if is_token_expired(token):
        click.echo("Error: Token has expired. Run: safe-colab login", err=True)
        sys.exit(1)

    # Default work-dir to current directory
    if not work_dir:
        work_dir = os.getcwd()

    os.makedirs(work_dir, exist_ok=True)
    abs_work_dir = os.path.abspath(work_dir)
    abs_data_dir = os.path.abspath(data_dir) if data_dir else None

    # Resolve sandbox backend
    if no_sandbox:
        sandbox = "none"
    elif sandbox == "auto":
        from .sandbox import detect_backend
        sandbox = detect_backend()
        if sandbox == "none":
            click.echo("WARNING: No sandbox backend available (nono or Docker).", err=True)
            click.echo("  The kernel will run WITHOUT filesystem isolation.", err=True)
            click.echo("  This means code can access ANY file on your machine.", err=True)
            click.echo()
            if not click.confirm("Continue without sandboxing?", default=False):
                click.echo("Aborted. Install Docker or nono for sandboxing:")
                click.echo("  Docker: https://docs.docker.com/get-docker/")
                click.echo("  nono:   https://nono.sh")
                sys.exit(1)

    email = extract_email_from_token(token) or "unknown"

    click.echo("=" * 60)
    click.echo("  Safe Colab CLI - Starting Session")
    click.echo("=" * 60)
    click.echo(f"  User:      {email}")
    click.echo(f"  Server:    {server_url}")
    click.echo(f"  Workspace: {workspace or '(auto)'}")
    if abs_data_dir:
        click.echo(f"  Data dir:  {abs_data_dir} (read-only)")
    click.echo(f"  Work dir:  {abs_work_dir} (read-write)")
    click.echo(f"  Sandbox:   {sandbox}")
    click.echo("=" * 60)
    click.echo()

    asyncio.run(_run_session(
        server_url=server_url,
        workspace=workspace,
        token=token,
        data_dir=abs_data_dir,
        work_dir=abs_work_dir,
        sandbox_backend=sandbox,
        timeout=timeout,
    ))


async def _run_session(server_url, workspace, token, data_dir, work_dir, sandbox_backend, timeout):
    """Main async session loop."""
    from .kernel import SandboxKernel
    from .service import register_service

    kernel = SandboxKernel()

    # Prepare kernel environment
    kernel_env = {}
    if data_dir:
        kernel_env["SAFE_COLAB_DATA_DIR"] = data_dir
    kernel_env["SAFE_COLAB_WORK_DIR"] = work_dir

    # Start the Jupyter kernel with sandbox
    click.echo(f"[1/3] Starting Jupyter kernel (sandbox: {sandbox_backend})...")
    await kernel.start(
        env=kernel_env,
        sandbox_backend=sandbox_backend,
        data_dir=data_dir,
        work_dir=work_dir,
    )

    # Set up working directories inside the kernel
    setup_code = f"""
import os, sys
_data_dir = {repr(data_dir) if data_dir else 'None'}
_work_dir = {repr(work_dir)}
os.chdir(_work_dir)
print(f"Working directory: {{os.getcwd()}}")
if _data_dir:
    print(f"Data directory: {{_data_dir}}")
    if os.path.exists(_data_dir):
        files = os.listdir(_data_dir)
        print(f"Data files: {{files[:20]}}")
"""
    result = await kernel.execute(setup_code)
    if result["stdout"]:
        click.echo(f"  {result['stdout'].strip()}")
    if result["error"]:
        click.echo(f"  Warning: {result['error']['evalue']}")

    # Verify sandbox by running security probes inside the kernel
    if sandbox_backend != "none":
        click.echo("[2/3] Verifying sandbox isolation...")
        verify_code = """
import os, json
results = {}
# Test 1: Can we read /etc/passwd?
try:
    open("/etc/passwd").read(1)
    results["etc_passwd"] = "LEAKED"
except:
    results["etc_passwd"] = "BLOCKED"
# Test 2: Can we list home directory?
try:
    os.listdir(os.path.expanduser("~"))
    results["home_dir"] = "LEAKED"
except:
    results["home_dir"] = "BLOCKED"
# Test 3: Can we read /etc/hosts?
try:
    open("/etc/hosts").read(1)
    results["etc_hosts"] = "LEAKED"
except:
    results["etc_hosts"] = "BLOCKED"
print(json.dumps(results))
"""
        verify_result = await kernel.execute(verify_code)
        try:
            import json as json_mod
            checks = json_mod.loads(verify_result["stdout"].strip())
            blocked = sum(1 for v in checks.values() if v == "BLOCKED")
            total = len(checks)
            click.echo(f"  Sandbox probes: {blocked}/{total} blocked")
            for probe, status in checks.items():
                icon = "OK" if status == "BLOCKED" else "FAIL"
                click.echo(f"    [{icon}] {probe}: {status}")
            if blocked < total:
                click.echo(f"  WARNING: Sandbox is not fully effective ({total - blocked} leaks)")
                click.echo(f"  Consider using --sandbox docker for stronger isolation")
        except Exception:
            click.echo(f"  Could not verify sandbox: {verify_result.get('error', 'unknown')}")
    else:
        click.echo("[2/3] Sandbox: none (no isolation)")
        click.echo("  WARNING: Code runs with full access to your filesystem")

    # Register Hypha service
    click.echo("[3/3] Registering Hypha service...")
    server, svc_info, instructions, service_url = await register_service(
        server_url=server_url,
        workspace=workspace,
        token=token,
        kernel=kernel,
        data_dir=data_dir or "(none)",
        work_dir=work_dir,
    )

    click.echo()
    click.echo("=" * 60)
    click.echo("  Session Ready!")
    click.echo("=" * 60)
    click.echo(f"  Service URL: {service_url}")
    click.echo()
    click.echo("Share the instructions below with the remote AI agent:")
    click.echo("(The agent does NOT need any credentials — the URL is the secret)")
    click.echo()
    click.echo("-" * 60)
    click.echo(instructions)
    click.echo("-" * 60)
    click.echo()
    click.echo("Press Ctrl+C to stop the session.")
    click.echo()

    # Keep running until interrupted
    stop_event = asyncio.Event()

    def _signal_handler():
        click.echo("\n[session] Shutting down...")
        stop_event.set()

    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, _signal_handler)

    await stop_event.wait()

    # Cleanup
    await kernel.stop()
    click.echo("[session] Session ended.")


if __name__ == "__main__":
    main()
