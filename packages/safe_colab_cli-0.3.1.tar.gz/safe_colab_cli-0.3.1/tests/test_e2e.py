"""End-to-end test: kernel + Hypha service + artifacts + remote code execution."""

import os
import pytest
from dotenv import load_dotenv

from safe_colab_cli.kernel import SandboxKernel
from safe_colab_cli.service import register_service

# Load .env for credentials
load_dotenv(os.path.join(os.path.dirname(__file__), "..", ".env"), override=True)

SERVER_URL = os.environ.get("HYPHA_SERVER_URL", "https://hypha.aicell.io")
WORKSPACE = os.environ.get("HYPHA_WORKSPACE", "safe-colab")
TOKEN = os.environ.get("HYPHA_TOKEN")


@pytest.fixture
async def kernel():
    k = SandboxKernel()
    await k.start()
    yield k
    await k.stop()


@pytest.mark.asyncio
@pytest.mark.skipif(not TOKEN, reason="HYPHA_TOKEN not set")
async def test_e2e_full_workflow(kernel, tmp_path):
    """Full end-to-end: register, run code, shell commands, upload files, list files."""
    work_dir = str(tmp_path / "workspace")
    os.makedirs(work_dir, exist_ok=True)
    data_dir = str(tmp_path / "data")
    os.makedirs(data_dir, exist_ok=True)

    # Create test data
    with open(os.path.join(data_dir, "test.csv"), "w") as f:
        f.write("name,value\nAlice,42\nBob,17\n")

    # Register service
    server, svc_info, instructions, service_url = await register_service(
        server_url=SERVER_URL,
        workspace=WORKSPACE,
        token=TOKEN,
        kernel=kernel,
        data_dir=data_dir,
        work_dir=work_dir,
    )

    assert svc_info is not None
    assert service_url.startswith("https://")
    assert "safe-colab-" in svc_info["id"]  # Random unlisted ID
    assert "run_code" in instructions
    assert "execute_command" in instructions
    assert "upload_file" in instructions
    assert "curl" in instructions
    print(f"\nService URL: {service_url}")

    # Connect as remote agent
    from hypha_rpc import connect_to_server as connect
    remote_server = await connect({
        "server_url": SERVER_URL,
        "workspace": WORKSPACE,
        "token": TOKEN,
    })
    svc = await remote_server.get_service(svc_info["id"])

    # Test 1: run_code - simple print
    result = await svc.run_code("print('Hello from remote!')")
    assert result["stdout"].strip() == "Hello from remote!"
    assert result["error"] is None
    print("Test 1 passed: run_code basic")

    # Test 2: run_code - expression result
    result = await svc.run_code("2 ** 10")
    assert result["result"] == "1024"
    print("Test 2 passed: run_code expression")

    # Test 3: run_code - error handling
    result = await svc.run_code("raise ValueError('test')")
    assert result["error"]["ename"] == "ValueError"
    print("Test 3 passed: run_code error")

    # Test 4: run_code - state persistence
    await svc.run_code("my_var = 'persistent_value'")
    result = await svc.run_code("print(my_var)")
    assert result["stdout"].strip() == "persistent_value"
    print("Test 4 passed: state persistence")

    # Test 5: execute_command - ls
    result = await svc.execute_command(f"ls {data_dir}")
    assert "test.csv" in result["stdout"]
    assert result["returncode"] == 0
    print("Test 5 passed: execute_command ls")

    # Test 6: execute_command - pip
    result = await svc.execute_command("python -c 'import json; print(json.dumps({\"ok\": True}))'")
    assert result["returncode"] == 0
    print("Test 6 passed: execute_command python")

    # Test 7: run_code - read CSV, write output
    code = f"""
import csv
with open("{data_dir}/test.csv") as f:
    reader = csv.DictReader(f)
    rows = list(reader)
total = sum(int(r["value"]) for r in rows)
print(f"Total: {{total}}")

# Write results
with open("{work_dir}/results.txt", "w") as f:
    f.write(f"Total: {{total}}\\nRows: {{len(rows)}}\\n")
print("Results saved")
"""
    result = await svc.run_code(code)
    assert "Total: 59" in result["stdout"]
    assert "Results saved" in result["stdout"]
    print("Test 7 passed: CSV read + file write")

    # Test 8: upload_file
    result = await svc.upload_file(f"{work_dir}/results.txt")
    assert "url" in result
    assert result["url"].startswith("https://")
    print(f"Test 8 passed: upload_file → {result['url'][:80]}...")

    # Test 9: list_shared_files
    files = await svc.list_shared_files()
    # Should have at least the results.txt and audit_log.jsonl
    print(f"Test 9 passed: list_shared_files → {len(files)} files")

    # Test 10: get_docs
    docs = await svc.get_docs()
    assert "run_code" in docs
    assert "execute_command" in docs
    assert "upload_file" in docs
    print(f"Test 10 passed: get_docs → {len(docs)} chars")

    # Test 11: upload_file security - reject outside work_dir
    result = await svc.upload_file("/etc/passwd")
    assert "error" in result
    assert "Access denied" in result["error"]
    print("Test 11 passed: upload_file security check")

    print("\nAll e2e tests passed!")
