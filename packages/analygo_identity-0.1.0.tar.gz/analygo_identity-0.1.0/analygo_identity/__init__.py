"""analygo-identity: Shared identity resolution, authority services, and onboarding state."""

from analygo_identity.contracts import (
    Organization,
    Workspace,
    Property,
    Target,
    Session,
)

from analygo_identity.user_identity import UserIdentity, UserIdentityValidator

from analygo_identity.identity_resolution_log import (
    Surface,
    ResolutionStatus,
    log_identity_resolution,
)

from analygo_identity.authority_service import AuthorityService

from analygo_identity.onboarding import (
    StepStatus,
    OnboardingStep,
    OnboardingState,
)

from analygo_identity.org_scope import (
    HEADER_AUDITOR_INTERNAL,
    HEADER_CLIENT_ID,
    HEADER_ORG_ID,
    HEADER_PORTAL_REQUEST_ID,
    HEADER_PORTAL_SERVICE,
    LineageSource,
    OrgScope,
    OrgScopeResolvedTo,
    ResolvedOrg,
    SYSTEM_ORG_ID,
    SystemOrgReason,
    get_org_scope,
    is_portal_originated,
)

__all__ = [
    "Organization",
    "Workspace",
    "Property",
    "Target",
    "Session",
    "UserIdentity",
    "UserIdentityValidator",
    "Surface",
    "ResolutionStatus",
    "log_identity_resolution",
    "AuthorityService",
    "StepStatus",
    "OnboardingStep",
    "OnboardingState",
    "OrgScope",
    "ResolvedOrg",
    "HEADER_ORG_ID",
    "HEADER_CLIENT_ID",
    "HEADER_PORTAL_REQUEST_ID",
    "HEADER_PORTAL_SERVICE",
    "HEADER_AUDITOR_INTERNAL",
    "SYSTEM_ORG_ID",
    "LineageSource",
    "OrgScopeResolvedTo",
    "SystemOrgReason",
    "get_org_scope",
    "is_portal_originated",
]
