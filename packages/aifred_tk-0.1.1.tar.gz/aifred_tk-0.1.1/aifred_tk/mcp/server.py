"""MCP presentation layer — FastMCP server with dynamic tool registration."""

import inspect
from itertools import zip_longest
from pathlib import Path
from typing import Any

from dynaconf import Dynaconf
from fastmcp import FastMCP
from fastmcp.server.context import Context

from aifred_tk.config.settings import create_settings
from aifred_tk.core.interfaces import Tool
from aifred_tk.core.registry import PluginRegistry
from aifred_tk.logging.setup import setup_logging


def _build_tool_fn(tool: Tool) -> Any:
    """Build a callable with an explicit signature matching the tool's args schema.

    FastMCP derives the JSON schema from ``inspect.signature(fn)``.  A function
    declared with ``**kwargs`` is not supported.  We therefore synthesise the
    correct :class:`~inspect.Signature` from the Pydantic model fields so that
    FastMCP receives a proper, typed parameter list.

    :param tool: The tool to wrap.
    :type tool: Tool
    :return: A callable whose signature mirrors the tool's ``args_schema``.
    :rtype: Any
    """
    schema_class = tool.args_schema
    captured_tool = tool

    sig_params: list[inspect.Parameter] = []
    for field_name, field_info in schema_class.model_fields.items():
        annotation = field_info.annotation if field_info.annotation is not None else Any
        if field_info.is_required():
            param = inspect.Parameter(
                field_name,
                kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                annotation=annotation,
            )
        else:
            param = inspect.Parameter(
                field_name,
                kind=inspect.Parameter.POSITIONAL_OR_KEYWORD,
                default=field_info.default,
                annotation=annotation,
            )
        sig_params.append(param)

    sig = inspect.Signature(sig_params, return_annotation=dict[str, Any])

    def _impl(**kwargs: Any) -> dict[str, Any]:
        validated = schema_class(**kwargs)
        return captured_tool.execute(validated)

    def tool_fn(**kwargs: Any) -> dict[str, Any]:
        """Execute the tool with validated arguments.

        :return: Result dictionary serialisable to JSON.
        :rtype: dict[str, Any]
        """
        return _impl(**kwargs)

    tool_fn.__signature__ = sig  # type: ignore[attr-defined]
    tool_fn.__name__ = tool.tool_id
    tool_fn.__doc__ = tool.description
    tool_fn.__annotations__ = {
        name: (fi.annotation if fi.annotation is not None else Any)
        for name, fi in schema_class.model_fields.items()
    }
    tool_fn.__annotations__["return"] = dict[str, Any]
    return tool_fn


def build_mcp_server(
    config_file: Path | None = None,
    settings: Dynaconf | None = None,
) -> FastMCP:
    """Construct and return a configured :class:`~fastmcp.FastMCP` server.

    All enabled tools from the plugin registry are registered as MCP tools.

    :param config_file: Optional path to an additional settings file.
    :type config_file: Path | None
    :param settings: Pre-built settings instance; takes precedence over
        *config_file* when provided (useful in tests).
    :type settings: Dynaconf | None
    :return: Configured FastMCP server ready to run.
    :rtype: FastMCP
    """
    if settings is None:
        settings = create_settings(extra_config_file=config_file)

    setup_logging(mode="mcp", settings=settings)

    registry = PluginRegistry(settings)
    registry.load_plugins()

    mcp: FastMCP = FastMCP(name="aifred-tk")

    for tool in registry.get_all_tools().values():
        fn = _build_tool_fn(tool)
        mcp.tool(name=tool.tool_id, description=tool.description)(fn)

    _register_elicit_choice(mcp)

    return mcp


def _register_elicit_choice(mcp: FastMCP) -> None:
    """Register the built-in ``elicit_choice`` MCP tool.

    This tool is exposed so that LLM agents (PydanticAI, LangChain, Claude,
    etc.) can ask the human user to select from a list of labelled choices
    on their own initiative, without needing a plugin tool as an intermediary.

    :param mcp: The FastMCP server instance to register the tool on.
    :type mcp: FastMCP
    """

    @mcp.tool(
        name="elicit_choice",
        description=(
            "Ask the human user to select one option from a list of choices. "
            "Use this when you need the user to make a decision between discrete "
            "alternatives. Provide a clear question, a list of choice labels, and "
            "optionally descriptions and examples to help the user understand each "
            "option. Set allow_free_input=true when the predefined choices may not "
            "cover the user's intent."
        ),
    )
    async def _elicit_choice_tool(
        ctx: Context,
        question: str,
        choices: list[str],
        descriptions: list[str] | None = None,
        examples: list[str] | None = None,
        context: str | None = None,
        allow_free_input: bool = False,
    ) -> dict[str, Any]:
        """Ask the human user to pick from a list of choices.

        This tool is an async MCP handler that calls ``ctx.elicit()`` directly
        on the event loop (unlike plugin tools that bridge via
        ``anyio.from_thread``).

        :param ctx: Injected FastMCP context.
        :type ctx: Context
        :param question: The question to display to the user.
        :type question: str
        :param choices: Labels for each selectable option.
        :type choices: list[str]
        :param descriptions: Optional explanation for each label (same order).
        :type descriptions: list[str] | None
        :param examples: Optional concrete example for each label (same order).
        :type examples: list[str] | None
        :param context: Optional context paragraph shown above the choices.
        :type context: str | None
        :param allow_free_input: When ``True``, an "Other (specify…)" option
            is appended.
        :type allow_free_input: bool
        :return: Dict with ``selected_index``, ``selected_label``, and
            ``free_text`` keys.
        :rtype: dict[str, Any]
        :raises ElicitationCancelledError: When the client declines or cancels.
        """
        from mcp.server.elicitation import CancelledElicitation, DeclinedElicitation

        from aifred_tk.core.models import ElicitationCancelledError

        _FREE_KEY = "__free__"

        # Build titled-enum dict: description and example are folded into the
        # title so the MCP client can show them in the dialog.
        desc_list = descriptions or []
        ex_list = examples or []
        enum_dict: dict[str, dict[str, str]] = {}
        for i, (lbl, desc, ex) in enumerate(zip_longest(choices, desc_list, ex_list, fillvalue="")):
            title_parts = [lbl]
            if desc:
                title_parts.append(f"— {desc}")
            if ex:
                title_parts.append(f"(e.g. {ex})")
            enum_dict[f"opt_{i}"] = {"title": " ".join(title_parts)}

        if allow_free_input:
            enum_dict[_FREE_KEY] = {"title": "Other (specify…)"}

        raw = await ctx.elicit(question, enum_dict, response_description=context)  # type: ignore[arg-type]

        if isinstance(raw, (DeclinedElicitation, CancelledElicitation)):
            raise ElicitationCancelledError(
                "Elicitation was declined or cancelled by the MCP client."
            )

        selected_key: str = raw.data  # type: ignore[assignment]

        if selected_key == _FREE_KEY:
            free_raw = await ctx.elicit("Enter your response:", str)  # type: ignore[arg-type]
            if isinstance(free_raw, (DeclinedElicitation, CancelledElicitation)):
                raise ElicitationCancelledError("Free-text elicitation was declined or cancelled.")
            return {
                "selected_index": -1,
                "selected_label": None,
                "free_text": str(free_raw.data),
            }

        idx = int(selected_key.split("_", 1)[1])
        return {
            "selected_index": idx,
            "selected_label": choices[idx],
            "free_text": None,
        }


def run_stdio() -> None:
    """Start the MCP server using stdio transport.

    This is the entry point referenced by the ``aifred-tk-mcp`` script in
    ``pyproject.toml``.
    """
    server = build_mcp_server()
    server.run(transport="stdio")


def run_http(port: int = 8080) -> None:
    """Start the MCP server using HTTP transport.

    :param port: TCP port to listen on; defaults to ``8080``.
    :type port: int
    """
    server = build_mcp_server()
    server.run(transport="http", port=port)
