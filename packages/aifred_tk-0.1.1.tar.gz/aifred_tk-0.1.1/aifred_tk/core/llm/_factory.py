"""LLM resolution and pydantic-ai model factory for the aifred-tk core."""

from __future__ import annotations

from pydantic_ai.models import Model
from pydantic_ai.models.anthropic import AnthropicModel
from pydantic_ai.models.openai import OpenAIChatModel
from pydantic_ai.providers.anthropic import AnthropicProvider
from pydantic_ai.providers.openai import OpenAIProvider

from aifred_tk.core.models import ConfigurationError

from ._config import (
    AnthropicLlmConfig,
    LlmConfig,
    LlmInlineSetting,
    LlmRefSetting,
    OllamaLlmConfig,
    OpenAICompatLlmConfig,
    OpenAILlmConfig,
    PluginLlmSetting,
)


def resolve_llm(setting: PluginLlmSetting, registry: dict[str, LlmConfig]) -> LlmConfig:
    """Resolve a plugin LLM setting to a concrete :data:`LlmConfig`.

    :param setting: Either a reference to a named LLM or an inline definition.
    :type setting: PluginLlmSetting
    :param registry: Named LLM configs parsed from the top-level ``llms`` settings block.
    :type registry: dict[str, LlmConfig]
    :return: Resolved LLM configuration.
    :rtype: LlmConfig
    :raises ConfigurationError: When a ref target is not present in the registry.
    """
    if isinstance(setting, LlmRefSetting):
        if setting.ref not in registry:
            raise ConfigurationError(
                f"LLM reference {setting.ref!r} not found in llms config; "
                f"available: {sorted(registry)}"
            )
        return registry[setting.ref]
    return _inline_to_config(setting)


def _inline_to_config(setting: LlmInlineSetting) -> LlmConfig:
    match setting.provider:
        case "ollama":
            return OllamaLlmConfig(
                model=setting.model,
                host=setting.host,
                port=setting.port,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case "openai":
            return OpenAILlmConfig(
                model=setting.model,
                api_key=setting.api_key,
                base_url=setting.base_url,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case "anthropic":
            return AnthropicLlmConfig(
                model=setting.model,
                api_key=setting.api_key,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case "openai-compatible":
            return OpenAICompatLlmConfig(
                model=setting.model,
                base_url=setting.base_url or "",
                api_key=setting.api_key,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case _:
            raise ConfigurationError(f"Unsupported provider: {setting.provider!r}")


def build_pydantic_ai_model(config: LlmConfig) -> Model:
    """Return a pydantic-ai :class:`~pydantic_ai.models.Model` for the given LLM configuration.

    Provider mapping:

    - ``ollama`` — :class:`~pydantic_ai.models.openai.OpenAIChatModel` pointed at the Ollama
      OpenAI-compatible endpoint (``http://<host>:<port>/v1``).
    - ``openai`` — :class:`~pydantic_ai.models.openai.OpenAIChatModel` with optional key/URL
      overrides; falls back to the ``OPENAI_API_KEY`` environment variable.
    - ``anthropic`` — :class:`~pydantic_ai.models.anthropic.AnthropicModel`; falls back to
      ``ANTHROPIC_API_KEY`` when no key is set.
    - ``openai-compatible`` — :class:`~pydantic_ai.models.openai.OpenAIChatModel` with a custom
      base URL for any Chat Completions-compatible endpoint.

    :param config: LLM configuration specifying the provider and connection details.
    :type config: LlmConfig
    :return: Configured pydantic-ai Model ready for use in an :class:`~pydantic_ai.Agent`.
    :rtype: pydantic_ai.models.Model
    """
    match config:
        case OllamaLlmConfig():
            return OpenAIChatModel(
                config.model,
                provider=OpenAIProvider(base_url=f"http://{config.host}:{config.port}/v1"),
            )
        case OpenAILlmConfig():
            return OpenAIChatModel(
                config.model,
                provider=OpenAIProvider(base_url=config.base_url, api_key=config.api_key),
            )
        case AnthropicLlmConfig():
            return AnthropicModel(
                config.model,
                provider=AnthropicProvider(api_key=config.api_key),
            )
        case OpenAICompatLlmConfig():
            return OpenAIChatModel(
                config.model,
                provider=OpenAIProvider(base_url=config.base_url, api_key=config.api_key),
            )
        case _:
            raise ConfigurationError(f"Unsupported provider: {config!r}")
