"""Core application layer — interfaces, models, and the plugin registry."""
