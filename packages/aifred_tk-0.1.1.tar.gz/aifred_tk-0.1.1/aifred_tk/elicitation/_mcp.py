"""MCP-protocol elicitor using FastMCP's native elicitation API."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aifred_tk.elicitation._models import Choice, ElicitationResult

_FREE_KEY = "__free__"


class McpElicitor:
    """Elicits a choice from the user via the MCP elicitation protocol.

    Must be called from a thread that was spawned by anyio (e.g. via
    ``anyio.to_thread.run_sync``), as it uses ``anyio.from_thread.run`` to
    bridge synchronous plugin code back into the async event loop where
    ``ctx.elicit()`` can be awaited.

    :param ctx: The active FastMCP :class:`~fastmcp.server.context.Context`.
    :type ctx: Any
    """

    def __init__(self, ctx: Any) -> None:
        """Initialise with the current FastMCP context.

        :param ctx: Active FastMCP context.
        :type ctx: Any
        """
        self._ctx = ctx

    def elicit(
        self,
        question: str,
        choices: list[Choice],
        context: str | None,
        allow_free_input: bool,
    ) -> ElicitationResult:
        """Send an elicitation request over the MCP protocol and return the result.

        :param question: The question shown to the user.
        :type question: str
        :param choices: Ordered list of selectable options.
        :type choices: list[Choice]
        :param context: Optional context description forwarded as
            ``response_description`` in the elicitation request.
        :type context: str | None
        :param allow_free_input: When ``True``, appends an "Other (specify…)"
            choice; if selected, a second elicitation collects the free text.
        :type allow_free_input: bool
        :return: The user's selection.
        :rtype: ElicitationResult
        :raises ElicitationCancelledError: When the MCP client declines or
            cancels the elicitation.
        """
        import anyio.from_thread
        from mcp.server.elicitation import CancelledElicitation, DeclinedElicitation

        from aifred_tk.core.models import ElicitationCancelledError
        from aifred_tk.elicitation._models import ElicitationResult

        # Build the titled-enum dict FastMCP expects for single-select.
        # Keys are stable internal identifiers; titles are the display labels.
        enum_dict: dict[str, dict[str, str]] = {
            f"opt_{i}": {"title": c.label} for i, c in enumerate(choices)
        }
        if allow_free_input:
            enum_dict[_FREE_KEY] = {"title": "Other (specify…)"}

        raw = anyio.from_thread.run(
            self._ctx.elicit(question, enum_dict, response_description=context)
        )

        if isinstance(raw, (DeclinedElicitation, CancelledElicitation)):
            raise ElicitationCancelledError(
                "Elicitation was declined or cancelled by the MCP client."
            )

        selected_key: str = raw.data

        if selected_key == _FREE_KEY:
            free_raw = anyio.from_thread.run(self._ctx.elicit("Enter your response:", str))
            if isinstance(free_raw, (DeclinedElicitation, CancelledElicitation)):
                raise ElicitationCancelledError("Free-text elicitation was declined or cancelled.")
            return ElicitationResult(
                selected_index=-1,
                selected_label=None,
                free_text=str(free_raw.data),
            )

        # Recover the original index from the key "opt_N".
        idx = int(selected_key.split("_", 1)[1])
        return ElicitationResult(
            selected_index=idx,
            selected_label=choices[idx].label,
            free_text=None,
        )
