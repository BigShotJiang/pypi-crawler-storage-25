# MCP Server

aifred-tk includes an [MCP](https://modelcontextprotocol.io/) server that exposes
all enabled plugin tools to agent frameworks.

## Stdio transport

Start the MCP server using stdio (the standard transport for most MCP clients):

```bash
aifred-tk-mcp
```

This is the default entry point and is suitable for use with Claude Desktop,
the MCP CLI, and other stdio-based clients.

## HTTP transport

The HTTP transport is available programmatically:

```python
from aifred_tk.mcp.server import run_http

run_http(port=8080)
```

## Tool registration

All tools registered in the plugin registry are automatically available as MCP tools.
The tool name, description, and parameter schema are derived from the plugin's
`Tool` implementation — no additional registration step is needed.

## Custom config

Pass a settings file at startup:

```python
from pathlib import Path
from aifred_tk.mcp.server import build_mcp_server

server = build_mcp_server(config_file=Path("my-settings.yml"))
server.run(transport="stdio")
```
