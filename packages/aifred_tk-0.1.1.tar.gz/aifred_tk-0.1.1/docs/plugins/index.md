# Plugin System

aifred-tk uses a microkernel plugin architecture. Plugins are discovered at runtime
using Python [entry points](https://packaging.python.org/en/latest/specifications/entry-points/).

## How plugins are discovered

Plugins register themselves under the `aifred_tk.plugins` entry point group in their
`pyproject.toml`:

```toml
[project.entry-points."aifred_tk.plugins"]
my_plugin = "my_package.plugin:create_plugin"
```

The entry point value must be a factory function with this signature:

```python
from dynaconf import Dynaconf
from aifred_tk.core.interfaces import Plugin

def create_plugin(settings: Dynaconf) -> Plugin: ...
```

## Plugin lifecycle

1. At startup the registry discovers all entry points in `aifred_tk.plugins`
2. Each factory function is called with the active `Dynaconf` settings instance
3. The plugin's `get_tools()` is called to collect all provided tools
4. Each tool is checked against settings for the `enabled` flag (defaults to `true`)
5. Enabled tools are registered and exposed via CLI and MCP

## Failure isolation

A plugin that raises an exception during loading is logged as a warning and skipped.
Other plugins continue to load normally.

## See also

- [Creating Plugins](creating-plugins.md)
- [Conventional Commits](conventional-commits.md)
- [File Analysis](file-analysis.md)
- [Prompt Injection Detector](prompt-injection.md)
