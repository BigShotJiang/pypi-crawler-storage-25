# Creating Plugins

## Step 1: Define your argument schema

Subclass `ToolArgs` (a Pydantic `BaseModel`) to describe your tool's inputs:

```python
from pydantic import Field
from aifred_tk.core.interfaces import ToolArgs

class MyToolArgs(ToolArgs):
    query: str = Field(..., description="The search query")
    limit: int = Field(10, ge=1, description="Maximum number of results")
```

## Step 2: Implement your tool

Subclass `Tool` and implement all abstract properties and `execute()`:

```python
from typing import Any
from aifred_tk.core.interfaces import Tool, ToolArgs

class MyTool(Tool):
    @property
    def tool_id(self) -> str:
        return "my_tool"

    @property
    def name(self) -> str:
        return "My Tool"

    @property
    def description(self) -> str:
        return "Does something useful."

    @property
    def args_schema(self) -> type[MyToolArgs]:
        return MyToolArgs

    def execute(self, args: ToolArgs) -> dict[str, Any]:
        assert isinstance(args, MyToolArgs)
        # ... your logic here ...
        return {"result": args.query}
```

## Step 3: Implement your plugin

Subclass `Plugin` and return your tools from `get_tools()`:

```python
from dynaconf import Dynaconf
from aifred_tk.core.interfaces import Plugin, Tool

class MyPlugin(Plugin):
    @property
    def plugin_id(self) -> str:
        return "my_plugin"

    @property
    def name(self) -> str:
        return "My Plugin"

    def get_tools(self) -> list[Tool]:
        return [MyTool()]


def create_plugin(settings: Dynaconf) -> MyPlugin:
    return MyPlugin()
```

## Step 4: Register the entry point

In your package's `pyproject.toml`:

```toml
[project.entry-points."aifred_tk.plugins"]
my_plugin = "my_package.plugin:create_plugin"
```

After installing your package (e.g. `pip install -e .`), aifred-tk discovers
your tool automatically:

```bash
aifred-tk my_tool --query "hello"
```

## Accessing settings

The `settings` argument in `create_plugin` provides access to the full configuration
chain. Use it to read plugin-specific configuration:

```yaml
# ~/.config/aifred-tk/settings.yml
tools:
  my_tool:
    api_key: secret
```

```python
def create_plugin(settings: Dynaconf) -> MyPlugin:
    api_key = settings.get("TOOLS__MY_TOOL__API_KEY", None)
    return MyPlugin(api_key=api_key)
```
