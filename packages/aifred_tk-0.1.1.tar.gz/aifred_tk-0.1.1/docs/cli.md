# CLI Reference

## Synopsis

```
aifred-tk [OPTIONS] COMMAND [ARGS]...
```

## Global options

| Option | Type | Description |
|---|---|---|
| `--config PATH` | File path | Additional settings file (highest priority after env vars). Must exist. |
| `--help` | flag | Show help and exit. |

## Tool commands

Every registered and enabled plugin tool becomes a subcommand:

```bash
aifred-tk TOOL_ID [TOOL_OPTIONS]...
```

Tool options are derived from the tool's Pydantic argument schema. Required fields
produce required options; optional fields produce optional options with defaults.

```bash
# List all available tools
aifred-tk --help

# Get help for a specific tool
aifred-tk demo_echo --help

# Run a tool
aifred-tk demo_echo --message "hello world"
```

## Exit codes

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | Tool not found or not enabled |
| 2 | Argument validation error |
| 3 | Tool execution error |

## Output

On success, tools write JSON to stdout. On error, a message is written to stderr
and the process exits with the appropriate non-zero code.
