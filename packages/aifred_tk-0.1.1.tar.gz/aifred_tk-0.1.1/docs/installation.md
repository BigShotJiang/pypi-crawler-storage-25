# Installation

## Standard install

```bash
pip install aifred-tk
```

## Optional extras

Development tooling:

```bash
pip install "aifred-tk[dev]"
```

Documentation tooling:

```bash
pip install "aifred-tk[docs]"
```

## Development install

```bash
git clone <repo-url>
cd aifred
pip install -e ".[dev]"
```

Or with uv:

```bash
uv sync --extra dev
```

## Requirements

- Python 3.11 or later
