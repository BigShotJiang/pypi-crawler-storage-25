# Configuration

aifred-tk uses a six-layer configuration chain. Layers are merged in ascending
priority order — later layers override earlier ones.

## Configuration layers

| Priority | Source | Example path (Linux) |
|---|---|---|
| 1 (lowest) | Package defaults | bundled `default_settings.yml` |
| 2 | System config | `/etc/xdg/aifred-tk/settings.yml` |
| 3 | User config | `~/.config/aifred-tk/settings.yml` |
| 4 | Local (CWD) | `.aifred-tk/settings.yml` |
| 5 | `--config` flag | any path passed at runtime |
| 6 (highest) | Environment variables | `AIFRED_TK_*` |

System and user paths follow [platformdirs](https://platformdirs.readthedocs.io/) conventions
and resolve to platform-appropriate locations on macOS and Windows as well.

Missing files at layers 2–5 are silently skipped.

## Environment variables

All settings can be overridden with environment variables using the `AIFRED_TK_` prefix
and dynaconf's double-underscore nested key syntax:

```bash
AIFRED_TK_AIFRED_TK__LOG_LEVEL=DEBUG aifred-tk demo_echo --message hi
```

## Settings file format

Settings files use YAML:

```yaml
aifred_tk:
  log_level: INFO
  log_dir: logs/

tools:
  demo_echo:
    enabled: true
```

## Default settings

| Key | Default | Description |
|---|---|---|
| `aifred_tk.log_level` | `INFO` | Logging verbosity |
| `aifred_tk.log_dir` | `.aifred-tk/logs` | Directory for log files |
| `aifred_tk.elicitation.mode` | `auto` | Interaction mode for user choice prompts (`auto`, `interactive`, `numbered`) — see [Elicitation](elicitation.md) |

## Per-tool settings

Tools can be enabled or disabled by tool ID:

```yaml
tools:
  my_tool:
    enabled: false
```

Individual plugins may define additional settings under their own namespace.
Refer to each plugin's documentation for available keys.

## Bundled LLM default

The package ships a named LLM entry called `default` that points at OpenAI `gpt-4o-mini`.
All LLM-backed built-in tools (`commit`, `analyze_file`, `detect_prompt_injection`) reference
it via `type: ref` / `ref: default` out of the box. Override it by redefining `llms.default`
in any higher-priority layer, or change the per-tool `ref` to point at a different entry.

| Key | Default |
|---|---|
| `tools.commit.llm` | `ref: default` |
| `tools.analyze_file.llm` | `ref: default` |
| `tools.detect_prompt_injection.llm` | `ref: default` |

## LLMs

Named LLM configurations are declared under the top-level `llms` key. Each entry is a
dictionary keyed by an arbitrary name. Plugins reference these entries by name, keeping
connection details out of per-tool config.

```yaml
llms:
  my-gemma:
    provider: ollama
    model: gemma4:e4b
    host: 127.0.0.1
    port: 11434
    context_size: 8192
    response_size: 4096

  gpt4o-mini:
    provider: openai
    model: gpt-4o-mini
```

### Provider types

| Provider | `provider` value | Required fields | Optional fields |
|---|---|---|---|
| Ollama | `ollama` | `model` | `host`, `port`, `context_size`, `response_size` |
| OpenAI | `openai` | `model` | `api_key`, `base_url`, `context_size`, `response_size` |
| Anthropic | `anthropic` | `model` | `api_key`, `context_size`, `response_size` |
| OpenAI-compatible | `openai-compatible` | `model`, `base_url` | `api_key`, `context_size`, `response_size` |

**Ollama** defaults to `host: 127.0.0.1` and `port: 11434`. The Ollama server must be
running and serving a Chat Completions-compatible endpoint at `/v1`.

**OpenAI** and **Anthropic** read their API keys from the `OPENAI_API_KEY` and
`ANTHROPIC_API_KEY` environment variables respectively when `api_key` is not set in the
config file. Do not store API keys in settings files tracked by version control.

**OpenAI-compatible** covers any server that implements the OpenAI Chat Completions API,
such as LM Studio, vLLM, or llama.cpp with an HTTP frontend.

### Plugin LLM settings

A plugin tool references a named LLM or defines one inline under `tools.<tool_id>.llm`.

**By reference** — points to a named entry in the `llms` block:

```yaml
tools:
  my_tool:
    llm:
      type: ref
      ref: my-gemma
```

**Inline** — defines the provider and model directly:

```yaml
tools:
  my_tool:
    llm:
      type: custom
      provider: openai
      model: gpt-4o-mini
```

Inline definitions accept the same fields as the corresponding named entry. A reference
is preferred when the same LLM is used by multiple tools.
