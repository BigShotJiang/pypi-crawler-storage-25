# AIfred Toolkit

AIfred Toolkit (`aifred-tk`) is a Python toolkit that exposes AI agent tools through a microkernel plugin system, available via both a CLI and an MCP (Model Context Protocol) server.

## What is aifred-tk?

aifred-tk provides a uniform interface for composable AI tools:

- **Plugin system** — tools are registered via Python entry points and discovered at runtime
- **CLI layer** — every registered tool becomes a subcommand with typed options
- **MCP layer** — the same tools are exposed as an MCP server for agent frameworks

## Sections

- [Installation](installation.md) — get aifred-tk running
- [Configuration](configuration.md) — layered settings and per-tool options
- [CLI Reference](cli.md) — command-line usage
- [MCP Server](mcp.md) — stdio and HTTP transports
- [Elicitation](elicitation.md) — runtime user-choice API for plugins and LLM agents
- [Plugin System](plugins/index.md) — how the plugin system works
- [Creating Plugins](plugins/creating-plugins.md) — write your own tools
- [Conventional Commits](plugins/conventional-commits.md) — AI-assisted commit message generation
- [File Analysis](plugins/file-analysis.md) — LLM-powered file content analysis
- [Prompt Injection Detector](plugins/prompt-injection.md) — detect prompt injection attempts in text
