"""Async client for the IntelliDoc document extraction service.

This module contains the entire async client surface: the public
:class:`IntelliDocClient`, plus the internal helpers that normalize
inputs, build the multipart payload, and translate HTTP responses
into SDK entities/exceptions. Kept together because they share a
single concern — talking HTTP with the IntelliDoc server.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx

from intellidoc_sdk._entities import DocumentInfo, _NormalizedItem
from intellidoc_sdk._polling import poll_until_complete
from intellidoc_sdk.entities import (
    DocumentResult,
    PageResult,
    _parse_extraction_method,
)
from intellidoc_sdk.exceptions import (
    AuthenticationError,
    ExtractionError,
    ExtractionTimeoutError,
    ServiceUnavailableError,
    ValidationError,
)

if TYPE_CHECKING:
    from types import TracebackType


class IntelliDocClient:
    """Async client for the IntelliDoc document extraction service.

    Provides a single :meth:`extract` method that uploads files and
    streams results as each document finishes processing.

    Usage::

        async with IntelliDocClient(url="...", api_key="...") as client:
            # one document — returns DocumentResult directly:
            r = await client.extract("doc.pdf")
            print(r.full_text or r.error)

            # many documents — returns an async iterator:
            async for r in client.extract_batch(["a.pdf", "b.pdf"]):
                print(r.filename, r.full_text or r.error)
    """

    _POLL_INTERVAL: float = 3.0
    _POLL_TIMEOUT: float = 300.0
    _MAX_BATCH_SIZE: int = 500

    def __init__(self, url: str, api_key: str) -> None:
        """Initialize the IntelliDoc client.

        Args:
            url: Base URL of the IntelliDoc service.
            api_key: API key used for authentication.
        """
        self._url = url.rstrip("/")
        self._headers: dict[str, str] = {"X-API-Key": api_key}
        self._client = httpx.AsyncClient(timeout=30.0)

    async def extract(
        self,
        document: str | Path | dict[str, str | bytes],
    ) -> DocumentResult:
        """Extract one document and return its :class:`DocumentResult`.

        Convenience wrapper over :meth:`extract_batch` for the common
        case of a single document. Internally calls ``extract_batch``
        with a single-element list and unwraps the result.

        Args:
            document: Same forms accepted by ``extract_batch`` (one of
                them):

                * filesystem path as ``str`` or ``Path`` — filename is
                  taken from the basename.
                * dict ``{"filename": str, "content": bytes | str}`` —
                  ``filename`` is mandatory. ``bytes`` is sent as
                  binary; ``str`` is treated as base64.

        Returns:
            A :class:`DocumentResult`. On success, ``full_text`` carries
            the extracted text and ``mime_type``, ``overall_quality``,
            ``total_pages``, ``processing_time_ms`` and ``pages`` carry
            extraction metadata. On failure, ``error`` is populated and
            all extra fields are ``None``.

        Raises:
            ValidationError: Same conditions as ``extract_batch``.
            AuthenticationError: If the API key is invalid (401/403).
            ServiceUnavailableError: If the service is unreachable.
        """
        async for result in self.extract_batch([document]):
            return result
        raise RuntimeError(  # pragma: no cover - unreachable for one input
            "extract_batch yielded no result for a single document"
        )

    async def extract_batch(
        self,
        documents: list[str | Path | dict[str, str | bytes]],
    ) -> AsyncIterator[DocumentResult]:
        """Upload many documents and stream their results.

        Each element of ``documents`` may be:

        * a filesystem path (``str`` or ``Path``) — bytes are read from
          disk and the filename is taken from the basename.
        * a dict ``{"filename": str, "content": bytes | str}`` — if
          ``content`` is ``bytes`` it is sent as binary; if ``content``
          is ``str`` it is treated as a base64 string. ``filename`` is
          mandatory.

        Inputs are normalized into a single batched ``POST /documents``
        call.

        Documents rejected at upload (unsupported content, size exceeded,
        invalid base64) are yielded immediately with ``error`` populated.
        Accepted documents are polled concurrently and yielded as each
        finishes; per-document processing failures also come through
        with ``error`` set.

        Args:
            documents: List of paths and/or input dicts.

        Yields:
            DocumentResult for each document, in completion order
            (documents rejected at upload first, then accepted documents
            as they finish processing). On success, each result carries
            not only ``full_text`` but also extraction metadata
            (``mime_type``, ``overall_quality``, ``total_pages``,
            ``processing_time_ms`` and per-page details in ``pages``).
            On failure, ``error`` is populated and the extra fields are
            ``None``.

        Raises:
            ValidationError: If an input has an unsupported type, a
                dict is missing required fields, or IntelliDoc rejects
                the request (HTTP 400/422 — duplicate filenames, batch
                too large, invalid filename).
            AuthenticationError: If the API key is invalid (401/403).
            ServiceUnavailableError: If the service is unreachable.
        """
        items = _normalize_input(documents)
        accepted, rejected = await self._submit(items)
        for r in rejected:
            yield r
        async for result in self._poll_all(accepted):
            yield result

    async def close(self) -> None:
        """Close the underlying HTTP client.

        Safe to call multiple times.
        """
        await self._client.aclose()

    async def __aenter__(self) -> IntelliDocClient:
        """Enter the async context manager."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit the async context manager and close the HTTP client."""
        await self.close()

    async def _submit(
        self,
        items: list[_NormalizedItem],
    ) -> tuple[list[DocumentInfo], list[DocumentResult]]:
        """Upload all normalized items (batched if needed) and partition."""
        all_accepted: list[DocumentInfo] = []
        all_rejected: list[DocumentResult] = []
        for batch in _split_batches(items, self._MAX_BATCH_SIZE):
            accepted, rejected = await self._submit_batch(batch)
            all_accepted.extend(accepted)
            all_rejected.extend(rejected)
        return all_accepted, all_rejected

    async def _poll_all(
        self,
        docs: list[DocumentInfo],
    ) -> AsyncIterator[DocumentResult]:
        """Poll all documents concurrently, yielding in completion order."""
        id_to_filename = {doc.id: doc.filename for doc in docs}
        futures = [
            asyncio.ensure_future(self._poll_single(doc.id))
            for doc in docs
        ]
        for coro in asyncio.as_completed(futures):
            result = await coro
            doc_id = result["document_id"]
            filename = id_to_filename[doc_id]
            yield _build_document_result(doc_id, filename, result)

    async def _submit_batch(
        self,
        items: list[_NormalizedItem],
    ) -> tuple[list[DocumentInfo], list[DocumentResult]]:
        """Upload one batch and split the 207 response into accepted/rejected."""
        multipart = _build_multipart(items)
        data = await self._upload_files(multipart)

        accepted: list[DocumentInfo] = []
        rejected: list[DocumentResult] = []
        for doc in data["documents"]:
            if doc["status"] == "accepted":
                accepted.append(
                    DocumentInfo(
                        id=doc["document_id"],
                        filename=doc["filename"],
                    )
                )
            else:
                rejected.append(
                    DocumentResult(
                        document_id=None,
                        filename=doc["filename"],
                        full_text=None,
                        error=_format_upload_error(doc.get("error") or {}),
                    )
                )
        return accepted, rejected

    async def _poll_single(self, doc_id: str) -> dict[str, Any]:
        """Poll one document; convert ExtractionError/Timeout into a dict.

        Returns the full server result dict on success (including
        ``document_id``, ``full_text``, ``mime_type``, ``overall_quality``,
        ``total_pages``, ``processing_time_ms`` and ``pages``). The SDK's
        ``doc_id`` is layered on top to guarantee its presence regardless
        of the server payload. On failure the dict has only
        ``document_id`` and ``error``.
        """
        try:
            result = await poll_until_complete(
                client=self._client,
                base_url=self._url,
                document_id=doc_id,
                headers=self._headers,
                interval=self._POLL_INTERVAL,
                timeout=self._POLL_TIMEOUT,
            )
            return {**result, "document_id": doc_id}
        except ExtractionError as exc:
            return {"document_id": doc_id, "error": str(exc)}
        except ExtractionTimeoutError:
            return {
                "document_id": doc_id,
                "error": f"Polling timeout for document {doc_id}",
            }

    async def _upload_files(
        self,
        multipart: list[tuple[str, tuple[str, bytes, str]]],
    ) -> dict[str, Any]:
        """POST the multipart payload to ``/documents`` and parse JSON.

        Raises:
            AuthenticationError: On HTTP 401 or 403.
            ValidationError: On HTTP 400 or 422.
            ServiceUnavailableError: On network or server errors.
        """
        url = f"{self._url}/documents"
        try:
            resp = await self._client.post(
                url, headers=self._headers, files=multipart
            )
        except httpx.ConnectError as exc:
            raise ServiceUnavailableError(
                f"Failed to connect to IntelliDoc: {exc}"
            ) from exc
        except httpx.HTTPError as exc:
            raise ServiceUnavailableError(
                f"HTTP error contacting IntelliDoc: {exc}"
            ) from exc

        _raise_for_status(resp)
        return resp.json()


# ----------------------------------------------------------------------------
# Internal helpers (input normalization, multipart building, response parsing).
# Kept module-level (not class methods) because they are stateless and reused
# from tests.
# ----------------------------------------------------------------------------


def _normalize_input(documents: list[Any]) -> list[_NormalizedItem]:
    """Convert heterogeneous user inputs into normalized items.

    Supported forms per element:

    * ``str`` or :class:`pathlib.Path`: filesystem path. Bytes are read
      from disk; ``filename`` is taken from the basename.
    * ``dict`` with keys ``filename`` (non-empty string) and ``content``:
        - ``content`` as ``bytes``: sent as binary on the ``files`` field.
        - ``content`` as ``str``: sent as base64 ASCII on the ``base64`` field.

    Raises:
        ValidationError: If any element has an unsupported type or a
            dict is missing required fields.
    """
    return [_normalize_single(doc) for doc in documents]


def _normalize_single(doc: Any) -> _NormalizedItem:
    """Dispatch a single input to the right normalizer."""
    if isinstance(doc, (str, Path)):
        p = Path(doc)
        try:
            content = p.read_bytes()
        except OSError as exc:
            raise ValidationError(
                f"Arquivo não encontrado ou não legível: {p} ({exc})"
            ) from exc
        return _NormalizedItem(kind="file", filename=p.name, content=content)
    if isinstance(doc, dict):
        return _normalize_dict(doc)
    raise ValidationError(
        f"Tipo não suportado em extract(): esperado str, Path ou dict, "
        f"recebeu {type(doc).__name__}"
    )


def _normalize_dict(doc: dict[str, Any]) -> _NormalizedItem:
    """Normalize an input dict (bytes or base64 string)."""
    filename = doc.get("filename")
    content = doc.get("content")
    if not isinstance(filename, str) or not filename:
        raise ValidationError(
            "Item inválido: campo 'filename' obrigatório (string não vazia)"
        )
    if isinstance(content, bytes):
        return _NormalizedItem(kind="file", filename=filename, content=content)
    if isinstance(content, str):
        return _NormalizedItem(
            kind="base64", filename=filename, content=content.encode("ascii")
        )
    raise ValidationError(
        "Item inválido: campo 'content' obrigatório "
        "(bytes para binário ou string para base64)"
    )


def _split_batches(
    items: list[_NormalizedItem],
    size: int,
) -> list[list[_NormalizedItem]]:
    """Split a list into sublists of at most *size* elements."""
    return [items[i : i + size] for i in range(0, len(items), size)]


def _build_multipart(
    items: list[_NormalizedItem],
) -> list[tuple[str, tuple[str, bytes, str]]]:
    """Build the multipart payload for ``POST /documents``.

    Disk binaries / in-memory bytes go under ``files`` as
    ``application/octet-stream``; ASCII base64 strings go under
    ``base64`` as ``text/plain``.
    """
    parts: list[tuple[str, tuple[str, bytes, str]]] = []
    for item in items:
        if item.kind == "file":
            parts.append(
                ("files", (item.filename, item.content, "application/octet-stream"))
            )
        else:
            parts.append(
                ("base64", (item.filename, item.content, "text/plain"))
            )
    return parts


def _format_upload_error(error: dict[str, Any]) -> str:
    """Render a per-item upload error as a single user-facing string."""
    return error.get("message") or "Documento rejeitado no upload"


def _build_page_result(page: dict[str, Any]) -> PageResult:
    """Build a PageResult from one entry of the server's pages list."""
    return PageResult(
        page_number=page["page_number"],
        content=page["content"],
        extraction_method=_parse_extraction_method(page.get("extraction_method")),
        quality_score=page["quality_score"],
        sheet_name=page.get("sheet_name"),
        sheet_index=page.get("sheet_index"),
    )


def _build_document_result(
    doc_id: str,
    filename: str,
    result: dict[str, Any],
) -> DocumentResult:
    """Build a DocumentResult from a polling result dict.

    On the success path, optional metadata (``mime_type``,
    ``overall_quality``, ``total_pages``, ``processing_time_ms``,
    ``pages``) is read with ``.get()`` so that missing keys degrade to
    ``None`` (or an empty list for ``pages``) instead of raising
    ``KeyError``. On the error path ``pages`` is left at its default
    ``None`` — that's how callers can distinguish "failed" from
    "succeeded but no pages".
    """
    if "error" in result:
        return DocumentResult(
            document_id=doc_id,
            filename=filename,
            full_text=None,
            error=result["error"],
        )
    pages = [_build_page_result(p) for p in result.get("pages", [])]
    return DocumentResult(
        document_id=doc_id,
        filename=filename,
        full_text=result["full_text"],
        error=None,
        mime_type=result.get("mime_type"),
        overall_quality=result.get("overall_quality"),
        total_pages=result.get("total_pages"),
        processing_time_ms=result.get("processing_time_ms"),
        pages=pages,
    )


def _raise_for_status(response: httpx.Response) -> None:
    """Translate HTTP error codes into SDK exceptions.

    Raises:
        AuthenticationError: On HTTP 401 or 403.
        ValidationError: On HTTP 400 or 422.
        ServiceUnavailableError: On HTTP 5xx.
        ExtractionError: On any other non-2xx status.
    """
    code = response.status_code
    if 200 <= code < 300:
        return

    body = response.text
    if code in (401, 403):
        raise AuthenticationError(
            f"Authentication failed (HTTP {code}): {body}"
        )
    if code in (400, 422):
        raise ValidationError(f"Validation error (HTTP {code}): {body}")
    if code >= 500:
        raise ServiceUnavailableError(f"Server error (HTTP {code}): {body}")
    raise ExtractionError(f"Unexpected error (HTTP {code}): {body}")
