"""Async client for the IntelliDoc SDK.

Use this subpackage when calling IntelliDoc from inside an async context
(FastAPI, aiohttp, etc.). For sync code (scripts, CLI, Celery), use the
top-level :mod:`intellidoc_sdk` package instead.
"""

from intellidoc_sdk.aio.client import IntelliDocClient

__all__ = ["IntelliDocClient"]
