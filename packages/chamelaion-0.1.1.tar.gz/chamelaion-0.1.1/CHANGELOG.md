# Changelog

## 0.1.1 (2026-04-02)

Full Changelog: [v0.1.0...v0.1.1](https://github.com/chamelaion/chamelaion-python/compare/v0.1.0...v0.1.1)

### Chores

* update SDK settings ([deb6a3c](https://github.com/chamelaion/chamelaion-python/commit/deb6a3cba95ef5ba01b628a571659cf58864aaa0))

## 0.1.0 (2026-04-02)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/chamelaion/chamelaion-python/compare/v0.0.1...v0.1.0)

### Features

* **api:** manual updates ([75e57de](https://github.com/chamelaion/chamelaion-python/commit/75e57deeecb72e592e20de0d181ef5ce4eee6e55))
* **internal:** implement indices array format for query and form serialization ([3504cf4](https://github.com/chamelaion/chamelaion-python/commit/3504cf4df4861acd47e384555a2c98a9a6867088))


### Chores

* **ci:** skip lint on metadata-only changes ([074bf75](https://github.com/chamelaion/chamelaion-python/commit/074bf752a841aa21f5a2ca1501873718a8650d2e))
* **internal:** update gitignore ([47302fe](https://github.com/chamelaion/chamelaion-python/commit/47302fe543b4933a8cd95a7a4325b3945864221e))
* update SDK settings ([0dc2a77](https://github.com/chamelaion/chamelaion-python/commit/0dc2a77a6780fc47806920b2548bedcc183c9c4c))
* update SDK settings ([62b9694](https://github.com/chamelaion/chamelaion-python/commit/62b969481ab13ff02ff8c1d0c36d8d306df2ee35))
* update SDK settings ([c5cc4b9](https://github.com/chamelaion/chamelaion-python/commit/c5cc4b95a097d263d9a858aab876b68ac38415a1))
* update SDK settings ([abde293](https://github.com/chamelaion/chamelaion-python/commit/abde2931f38426ee844b887bea5cf6852362acee))
* update SDK settings ([7d98646](https://github.com/chamelaion/chamelaion-python/commit/7d98646c510c2eee6898c0c527fb48db8c0857d5))
* update SDK settings ([dbbd35d](https://github.com/chamelaion/chamelaion-python/commit/dbbd35d9759ab9587e5b7bfab8ec9d30b5d449e4))
* update SDK settings ([a458712](https://github.com/chamelaion/chamelaion-python/commit/a458712907f3b85bd8e41190386e8e3896ddca2e))
