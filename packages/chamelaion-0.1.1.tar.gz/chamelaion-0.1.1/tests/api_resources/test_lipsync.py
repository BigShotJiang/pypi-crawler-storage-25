# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from chamelaion import Chamelaion, AsyncChamelaion
from tests.utils import assert_matches_type
from chamelaion.types import LipsyncGenerate

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestLipsync:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_generate(self, client: Chamelaion) -> None:
        lipsync = client.lipsync.generate(
            inputs=[
                {
                    "type": "video",
                    "url": "https://example.com/source/video.mp4",
                },
                {
                    "type": "audio",
                    "url": "https://example.com/source/audio.wav",
                },
            ],
        )
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_generate_with_all_params(self, client: Chamelaion) -> None:
        lipsync = client.lipsync.generate(
            inputs=[
                {
                    "type": "video",
                    "url": "https://example.com/source/video.mp4",
                },
                {
                    "type": "audio",
                    "url": "https://example.com/source/audio.wav",
                },
            ],
            disable_active_speaker_detection=False,
            reference_id="demo-001",
        )
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_generate(self, client: Chamelaion) -> None:
        response = client.lipsync.with_raw_response.generate(
            inputs=[
                {
                    "type": "video",
                    "url": "https://example.com/source/video.mp4",
                },
                {
                    "type": "audio",
                    "url": "https://example.com/source/audio.wav",
                },
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        lipsync = response.parse()
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_generate(self, client: Chamelaion) -> None:
        with client.lipsync.with_streaming_response.generate(
            inputs=[
                {
                    "type": "video",
                    "url": "https://example.com/source/video.mp4",
                },
                {
                    "type": "audio",
                    "url": "https://example.com/source/audio.wav",
                },
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            lipsync = response.parse()
            assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_generate_with_media(self, client: Chamelaion) -> None:
        lipsync = client.lipsync.generate_with_media(
            audio=b"Example data",
            video=b"Example data",
        )
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_generate_with_media_with_all_params(self, client: Chamelaion) -> None:
        lipsync = client.lipsync.generate_with_media(
            audio=b"Example data",
            video=b"Example data",
            disable_active_speaker_detection=True,
            model="lipsync-2",
            reference_id="reference_id",
        )
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_generate_with_media(self, client: Chamelaion) -> None:
        response = client.lipsync.with_raw_response.generate_with_media(
            audio=b"Example data",
            video=b"Example data",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        lipsync = response.parse()
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_generate_with_media(self, client: Chamelaion) -> None:
        with client.lipsync.with_streaming_response.generate_with_media(
            audio=b"Example data",
            video=b"Example data",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            lipsync = response.parse()
            assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncLipsync:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_generate(self, async_client: AsyncChamelaion) -> None:
        lipsync = await async_client.lipsync.generate(
            inputs=[
                {
                    "type": "video",
                    "url": "https://example.com/source/video.mp4",
                },
                {
                    "type": "audio",
                    "url": "https://example.com/source/audio.wav",
                },
            ],
        )
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_generate_with_all_params(self, async_client: AsyncChamelaion) -> None:
        lipsync = await async_client.lipsync.generate(
            inputs=[
                {
                    "type": "video",
                    "url": "https://example.com/source/video.mp4",
                },
                {
                    "type": "audio",
                    "url": "https://example.com/source/audio.wav",
                },
            ],
            disable_active_speaker_detection=False,
            reference_id="demo-001",
        )
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_generate(self, async_client: AsyncChamelaion) -> None:
        response = await async_client.lipsync.with_raw_response.generate(
            inputs=[
                {
                    "type": "video",
                    "url": "https://example.com/source/video.mp4",
                },
                {
                    "type": "audio",
                    "url": "https://example.com/source/audio.wav",
                },
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        lipsync = await response.parse()
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_generate(self, async_client: AsyncChamelaion) -> None:
        async with async_client.lipsync.with_streaming_response.generate(
            inputs=[
                {
                    "type": "video",
                    "url": "https://example.com/source/video.mp4",
                },
                {
                    "type": "audio",
                    "url": "https://example.com/source/audio.wav",
                },
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            lipsync = await response.parse()
            assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_generate_with_media(self, async_client: AsyncChamelaion) -> None:
        lipsync = await async_client.lipsync.generate_with_media(
            audio=b"Example data",
            video=b"Example data",
        )
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_generate_with_media_with_all_params(self, async_client: AsyncChamelaion) -> None:
        lipsync = await async_client.lipsync.generate_with_media(
            audio=b"Example data",
            video=b"Example data",
            disable_active_speaker_detection=True,
            model="lipsync-2",
            reference_id="reference_id",
        )
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_generate_with_media(self, async_client: AsyncChamelaion) -> None:
        response = await async_client.lipsync.with_raw_response.generate_with_media(
            audio=b"Example data",
            video=b"Example data",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        lipsync = await response.parse()
        assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_generate_with_media(self, async_client: AsyncChamelaion) -> None:
        async with async_client.lipsync.with_streaming_response.generate_with_media(
            audio=b"Example data",
            video=b"Example data",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            lipsync = await response.parse()
            assert_matches_type(LipsyncGenerate, lipsync, path=["response"])

        assert cast(Any, response.is_closed) is True
