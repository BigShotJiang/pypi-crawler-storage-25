# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["LipsyncGenerate"]


class LipsyncGenerate(BaseModel):
    request_id: str
    """Identifier of the created lip sync request."""

    status: Literal["success"]
    """Current state of the newly created request."""
