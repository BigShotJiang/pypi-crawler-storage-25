# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["UserRetrieveCurrentResponse"]


class UserRetrieveCurrentResponse(BaseModel):
    name: str
    """Display name of the API token."""
