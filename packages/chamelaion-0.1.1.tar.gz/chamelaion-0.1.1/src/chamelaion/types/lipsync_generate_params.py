# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal, Required, TypedDict

__all__ = ["LipsyncGenerateParams", "Input"]


class LipsyncGenerateParams(TypedDict, total=False):
    inputs: Required[Iterable[Input]]
    """Exactly one video input and one audio input (order does not matter)."""

    disable_active_speaker_detection: bool
    """Disable active speaker detection and use max-face lipsync preprocessing."""

    reference_id: str
    """Optional client-provided identifier for later retrieval."""


class Input(TypedDict, total=False):
    type: Required[Literal["video", "audio"]]
    """Type of input media."""

    url: Required[str]
    """URL of the media resource."""
