# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, TypedDict

from .._types import FileTypes

__all__ = ["LipsyncGenerateWithMediaParams"]


class LipsyncGenerateWithMediaParams(TypedDict, total=False):
    audio: Required[FileTypes]
    """Target audio file."""

    video: Required[FileTypes]
    """Source video file."""

    disable_active_speaker_detection: bool
    """Disable active speaker detection and use max-face lipsync preprocessing."""

    model: Literal["lipsync-2"]
    """Optional model selector."""

    reference_id: str
    """Optional client-provided identifier for later retrieval."""
