# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["RequestListParams"]


class RequestListParams(TypedDict, total=False):
    limit: int
    """Maximum number of items to return."""

    offset: int
    """Number of items to skip before returning results."""

    reference_id: str
    """Filter requests by exact `reference_id`."""
