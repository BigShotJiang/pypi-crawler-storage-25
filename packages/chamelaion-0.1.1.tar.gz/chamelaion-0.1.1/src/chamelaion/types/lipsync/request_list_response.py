# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ..._models import BaseModel
from .lipsync_request import LipsyncRequest

__all__ = ["RequestListResponse", "Pagination"]


class Pagination(BaseModel):
    limit: int
    """Applied page size."""

    offset: int
    """Applied result offset."""

    total: int
    """Total number of matching records."""


class RequestListResponse(BaseModel):
    data: List[LipsyncRequest]

    pagination: Pagination
