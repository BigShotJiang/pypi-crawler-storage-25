# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from ..._models import BaseModel

__all__ = ["LipsyncRequest"]


class LipsyncRequest(BaseModel):
    id: str
    """Lip sync request ID."""

    created_at: datetime
    """Request creation time in UTC."""

    status: str
    """Current request status."""

    error_message: Optional[str] = None
    """Failure message when status is `failed`."""

    finished_at: Optional[datetime] = None
    """Request processing completion time in UTC."""

    output_url: Optional[str] = None
    """URL to the generated output media, when available."""

    reference_id: Optional[str] = None
    """Client-provided identifier for this request."""

    started_at: Optional[datetime] = None
    """Request processing start time in UTC."""
