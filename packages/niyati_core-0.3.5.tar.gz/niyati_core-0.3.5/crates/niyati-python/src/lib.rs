use ::niyati_core::{simulate as rust_simulate, CapabilityMode, VibeSchema};
use pyo3::prelude::*;
use reqwest::blocking::Client;
use serde_json::{json, Value};
use std::thread::sleep;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

// Keep the hosted API target explicit so Python patch releases for packaging/docs
// do not break against the currently deployed version-guarded API.
const API_VERSION_HEADER: &str = "0.3.2";
const DEFAULT_BASE_URL: &str = "https://api.causalorlabs.com";

#[pyclass]
pub struct NiyatiSession {
    schema: VibeSchema,
    api_key: Option<String>,
    base_url: String,
    last_run_ms: u128,
    client: Client,
}

impl NiyatiSession {
    fn parse_capability(capability: Option<&str>) -> PyResult<&'static str> {
        match capability.unwrap_or("full").to_ascii_lowercase().as_str() {
            "full" => Ok("full"),
            "lite" => Ok("lite"),
            other => Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(format!(
                "Invalid capability '{}'. Supported: 'full' or 'lite'.",
                other
            ))),
        }
    }

    fn parse_json_payload(payload_json: &str) -> PyResult<Value> {
        serde_json::from_str(payload_json).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid JSON payload: {}", e))
        })
    }

    fn post_json_with_retry(&self, path: &str, body: &Value) -> PyResult<String> {
        let url = format!(
            "{}/{}",
            self.base_url.trim_end_matches('/'),
            path.trim_start_matches('/')
        );

        // Initial request + two retries with fixed backoff.
        let retry_delays_ms = [0_u64, 200, 500];
        let mut last_error = String::from("unknown error");

        for (attempt_idx, delay_ms) in retry_delays_ms.iter().enumerate() {
            if *delay_ms > 0 {
                sleep(Duration::from_millis(*delay_ms));
            }

            let mut request = self
                .client
                .post(&url)
                .header("Content-Type", "application/json")
                .header("X-Niyati-Version", API_VERSION_HEADER)
                .header("X-Causalor-Version", API_VERSION_HEADER)
                .json(body);

            if let Some(key) = &self.api_key {
                request = request
                    .header("X-Niyati-Key", key)
                    .header("X-Causalor-Key", key);
            }

            match request.send() {
                Ok(resp) => {
                    let status = resp.status();
                    let status_code = status.as_u16();
                    let text = resp.text().unwrap_or_default();

                    if status.is_success() {
                        return Ok(text);
                    }

                    let retriable =
                        status_code == 408 || status_code == 429 || status.is_server_error();
                    let final_attempt = attempt_idx == retry_delays_ms.len() - 1;

                    if retriable && !final_attempt {
                        last_error = format!("API Error: Status {} Body {}", status, text);
                        continue;
                    }

                    return Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                        "API Error: Status {} Body {}",
                        status, text
                    )));
                }
                Err(e) => {
                    let final_attempt = attempt_idx == retry_delays_ms.len() - 1;
                    last_error = format!("API Request Failed: {}", e);
                    if final_attempt {
                        return Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                            last_error.clone(),
                        ));
                    }
                }
            }
        }

        Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
            "API Request Failed after retries: {}",
            last_error
        )))
    }

    fn solve_route(&self, route: &str, payload_json: &str) -> PyResult<String> {
        let payload = Self::parse_json_payload(payload_json)?;
        self.post_json_with_retry(route, &payload)
    }
}

#[pymethods]
impl NiyatiSession {
    #[new]
    #[pyo3(signature = (schema_json, api_key=None, base_url=None))]
    fn new(schema_json: &str, api_key: Option<String>, base_url: Option<String>) -> PyResult<Self> {
        let schema: VibeSchema = serde_json::from_str(schema_json).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid schema: {}", e))
        })?;

        let client = Client::builder()
            .timeout(Duration::from_millis(3500))
            .build()
            .map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                    "Failed to create HTTP client: {}",
                    e
                ))
            })?;

        Ok(Self {
            schema,
            api_key,
            base_url: base_url.unwrap_or_else(|| DEFAULT_BASE_URL.to_string()),
            last_run_ms: 0,
            client,
        })
    }

    /// Evaluates the current schema by delegating to the cloud API.
    #[pyo3(signature = (budget=None, capability=None))]
    fn evaluate(&mut self, budget: Option<f64>, capability: Option<String>) -> PyResult<String> {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis();
        self.last_run_ms = now;

        let capability = Self::parse_capability(capability.as_deref())?;
        let body = json!({
            "schema": self.schema,
            "budget": budget,
            "capability": capability
        });

        self.post_json_with_retry("/v1/simulate", &body)
    }

    /// Capped local execution (Max 5 vars, 12 horizon). Offline-ready.
    #[pyo3(signature = (budget=None))]
    fn simulate_local(&self, budget: Option<f64>) -> PyResult<String> {
        if self.schema.variables.len() > 5 {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "Local Mode Violation: Max 5 variables. Use evaluate() for cloud execution.",
            ));
        }
        if self.schema.time.horizon > 12 {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "Local Mode Violation: Max 12 horizon. Use evaluate() for cloud execution.",
            ));
        }

        let result = rust_simulate(self.schema.clone(), budget, CapabilityMode::Lite);
        serde_json::to_string(&result).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                "Failed to serialize result: {}",
                e
            ))
        })
    }

    fn solve_reachability(&self, payload_json: &str) -> PyResult<String> {
        self.solve_route("/v1/solve/reachability", payload_json)
    }

    fn solve_fragility(&self, payload_json: &str) -> PyResult<String> {
        self.solve_route("/v1/solve/fragility", payload_json)
    }

    fn solve_trajectory(&self, payload_json: &str) -> PyResult<String> {
        self.solve_route("/v1/solve/trajectory", payload_json)
    }

    fn solve_multiagent(&self, payload_json: &str) -> PyResult<String> {
        self.solve_route("/v1/solve/multiagent", payload_json)
    }

    fn solve_competition(&self, payload_json: &str) -> PyResult<String> {
        self.solve_route("/v1/solve/competition", payload_json)
    }

    fn solve_pareto(&self, payload_json: &str) -> PyResult<String> {
        self.solve_route("/v1/solve/pareto", payload_json)
    }

    /// Update the underlying schema for the session.
    fn update_schema(&mut self, schema_json: &str) -> PyResult<()> {
        let schema: VibeSchema = serde_json::from_str(schema_json).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid schema: {}", e))
        })?;
        self.schema = schema;
        Ok(())
    }
}

#[pyclass(name = "CausalorSession")]
pub struct CausalorSessionCompat {
    inner: NiyatiSession,
}

#[pymethods]
impl CausalorSessionCompat {
    #[new]
    #[pyo3(signature = (schema_json, api_key=None, base_url=None))]
    fn new(schema_json: &str, api_key: Option<String>, base_url: Option<String>) -> PyResult<Self> {
        Ok(Self {
            inner: NiyatiSession::new(schema_json, api_key, base_url)?,
        })
    }

    #[pyo3(signature = (budget=None, capability=None))]
    fn evaluate(&mut self, budget: Option<f64>, capability: Option<String>) -> PyResult<String> {
        self.inner.evaluate(budget, capability)
    }

    #[pyo3(signature = (budget=None))]
    fn simulate_local(&self, budget: Option<f64>) -> PyResult<String> {
        self.inner.simulate_local(budget)
    }

    fn solve_reachability(&self, payload_json: &str) -> PyResult<String> {
        self.inner.solve_reachability(payload_json)
    }

    fn solve_fragility(&self, payload_json: &str) -> PyResult<String> {
        self.inner.solve_fragility(payload_json)
    }

    fn solve_trajectory(&self, payload_json: &str) -> PyResult<String> {
        self.inner.solve_trajectory(payload_json)
    }

    fn solve_multiagent(&self, payload_json: &str) -> PyResult<String> {
        self.inner.solve_multiagent(payload_json)
    }

    fn solve_competition(&self, payload_json: &str) -> PyResult<String> {
        self.inner.solve_competition(payload_json)
    }

    fn solve_pareto(&self, payload_json: &str) -> PyResult<String> {
        self.inner.solve_pareto(payload_json)
    }

    fn update_schema(&mut self, schema_json: &str) -> PyResult<()> {
        self.inner.update_schema(schema_json)
    }
}

#[pyfunction]
#[pyo3(signature = (schema_json, budget=None, api_key=None, base_url=None, capability=None))]
fn simulate(
    schema_json: &str,
    budget: Option<f64>,
    api_key: Option<String>,
    base_url: Option<String>,
    capability: Option<String>,
) -> PyResult<String> {
    let mut session = NiyatiSession::new(schema_json, api_key, base_url)?;
    session.evaluate(budget, capability)
}

#[pyfunction]
#[pyo3(signature = (schema_json, budget=None))]
fn simulate_local(schema_json: &str, budget: Option<f64>) -> PyResult<String> {
    let session = NiyatiSession::new(schema_json, None, None)?;
    session.simulate_local(budget)
}

#[pymodule]
fn niyati(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(simulate, m)?)?;
    m.add_function(wrap_pyfunction!(simulate_local, m)?)?;
    m.add_class::<NiyatiSession>()?;
    m.add_class::<CausalorSessionCompat>()?;
    Ok(())
}
