use criterion::{criterion_group, criterion_main, Criterion};
use niyati_core::{simulate, CapabilityMode, VibeSchema};
use serde_json::json;

fn schema_from_value(value: serde_json::Value) -> VibeSchema {
    serde_json::from_value(value).expect("benchmark schema should be valid")
}

fn discrete_schema() -> VibeSchema {
    schema_from_value(json!({
        "version": "1.0.0",
        "metadata": { "name": "Discrete Benchmark" },
        "time": { "type": "discrete", "horizon": 8 },
        "resources": {
            "money": { "initial": 2500.0, "min": 0.0, "max": 10000.0 }
        },
        "variables": {
            "x": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 },
            "y": { "type": "float", "initial": 5.0, "min": 0.0, "max": 10.0, "discretization": 1.0 }
        },
        "actions": [
            {
                "name": "shift_x",
                "cost": { "money": 25.0 },
                "effects": { "x": { "op": "add", "value": 1.0 } },
                "preconditions": []
            },
            {
                "name": "shift_y",
                "cost": { "money": 25.0 },
                "effects": { "y": { "op": "add", "value": -1.0 } },
                "preconditions": []
            }
        ],
        "transitions": [],
        "constraints": [],
        "goal": {
            "type": "threshold",
            "conditions": [{ "variable": "x", "operator": "gte", "value": 6.0 }]
        }
    }))
}

fn hybrid_schema() -> VibeSchema {
    schema_from_value(json!({
        "version": "1.0.0",
        "metadata": { "name": "Hybrid Benchmark" },
        "time": { "type": "discrete", "horizon": 10 },
        "resources": {
            "money": { "initial": 5000.0, "min": 0.0, "max": 50000.0 }
        },
        "variables": {
            "a": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 },
            "b": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 },
            "c": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 }
        },
        "actions": [
            {
                "name": "advance_a",
                "cost": { "money": 50.0 },
                "effects": { "a": { "op": "add", "value": 1.0 } },
                "preconditions": []
            }
        ],
        "transitions": [],
        "constraints": [],
        "goal": {
            "type": "threshold",
            "conditions": [{ "variable": "a", "operator": "gte", "value": 5.0 }]
        }
    }))
}

fn continuous_schema() -> VibeSchema {
    schema_from_value(json!({
        "version": "1.0.0",
        "metadata": { "name": "Continuous Benchmark" },
        "time": { "type": "discrete", "horizon": 12 },
        "resources": {
            "money": { "initial": 10000.0, "min": 0.0, "max": 100000.0 }
        },
        "variables": {
            "a": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 },
            "b": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 },
            "c": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 },
            "d": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 },
            "e": { "type": "float", "initial": 0.0, "min": 0.0, "max": 10.0, "discretization": 1.0 }
        },
        "actions": [
            {
                "name": "advance_a",
                "cost": { "money": 100.0 },
                "effects": { "a": { "op": "add", "value": 1.0 } },
                "preconditions": []
            }
        ],
        "transitions": [],
        "constraints": [],
        "goal": {
            "type": "threshold",
            "conditions": [{ "variable": "a", "operator": "gte", "value": 5.0 }]
        }
    }))
}

fn bench_simulation_modes(c: &mut Criterion) {
    let discrete = discrete_schema();
    let hybrid = hybrid_schema();
    let continuous = continuous_schema();

    c.bench_function("simulate_discrete_mode", |b| {
        b.iter(|| simulate(discrete.clone(), Some(500.0), CapabilityMode::Full))
    });

    c.bench_function("simulate_hybrid_mode", |b| {
        b.iter(|| simulate(hybrid.clone(), Some(750.0), CapabilityMode::Full))
    });

    c.bench_function("simulate_continuous_mode", |b| {
        b.iter(|| simulate(continuous.clone(), Some(1000.0), CapabilityMode::Full))
    });
}

criterion_group!(benches, bench_simulation_modes);
criterion_main!(benches);
