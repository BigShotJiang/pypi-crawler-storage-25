use niyati_core::geometry::{Polytope, Vector};

// ============================================================================
// THEOREM 15: Multi-Agent Reachability
// ============================================================================

/// Theorem 15.1 (Interference Monotonicity):
/// More agents consuming shared resources can only shrink individual reachable sets.
/// We model this by showing that excluding states from a graph reduces reachable volume.
#[test]
fn theorem_15_1_interference_monotonicity() {
    // Supply chain with 5 supplier nodes — shared by 3 competing agents.
    // Model as a polytope: each agent's budget constraint shrinks the feasible space.
    let mut p_solo = Polytope::new();
    // Agent 1 alone: full budget space [0, 100]^3
    p_solo.add_constraint(Vector(vec![1.0, 0.0, 0.0]), 100.0);
    p_solo.add_constraint(Vector(vec![-1.0, 0.0, 0.0]), 0.0);
    p_solo.add_constraint(Vector(vec![0.0, 1.0, 0.0]), 100.0);
    p_solo.add_constraint(Vector(vec![0.0, -1.0, 0.0]), 0.0);
    p_solo.add_constraint(Vector(vec![0.0, 0.0, 1.0]), 100.0);
    p_solo.add_constraint(Vector(vec![0.0, 0.0, -1.0]), 0.0);

    // Agent 1 with Agent 2 consuming some resources:
    // Agent 2 has consumed x1 ∈ [0, 40] → Agent 1's x1 now ≤ 60
    let mut p_two_agents = Polytope::new();
    p_two_agents.add_constraint(Vector(vec![1.0, 0.0, 0.0]), 60.0); // shrunk
    p_two_agents.add_constraint(Vector(vec![-1.0, 0.0, 0.0]), 0.0);
    p_two_agents.add_constraint(Vector(vec![0.0, 1.0, 0.0]), 100.0);
    p_two_agents.add_constraint(Vector(vec![0.0, -1.0, 0.0]), 0.0);
    p_two_agents.add_constraint(Vector(vec![0.0, 0.0, 1.0]), 100.0);
    p_two_agents.add_constraint(Vector(vec![0.0, 0.0, -1.0]), 0.0);

    // Agent 1 with Agent 2 AND Agent 3:
    // Agent 3 also consumed x2 ∈ [0, 30] → Agent 1's x2 ≤ 70
    let mut p_three_agents = Polytope::new();
    p_three_agents.add_constraint(Vector(vec![1.0, 0.0, 0.0]), 60.0);
    p_three_agents.add_constraint(Vector(vec![-1.0, 0.0, 0.0]), 0.0);
    p_three_agents.add_constraint(Vector(vec![0.0, 1.0, 0.0]), 70.0); // shrunk
    p_three_agents.add_constraint(Vector(vec![0.0, -1.0, 0.0]), 0.0);
    p_three_agents.add_constraint(Vector(vec![0.0, 0.0, 1.0]), 100.0);
    p_three_agents.add_constraint(Vector(vec![0.0, 0.0, -1.0]), 0.0);

    let test_point = Vector(vec![30.0, 30.0, 30.0]);

    // T15.1: More agents → smaller reachable region
    // Solo: point is 70 from x1-boundary
    let delta_solo = p_solo.boundary_distance(&test_point);
    let delta_two = p_two_agents.boundary_distance(&test_point);
    let delta_three = p_three_agents.boundary_distance(&test_point);

    // Boundary distance monotonically shrinks with more competitors
    assert!(
        delta_solo >= delta_two,
        "Two agents should not increase optionality"
    );
    assert!(
        delta_two >= delta_three,
        "Three agents should not increase optionality"
    );
}

/// Theorem 15.2 (Nash Equilibrium Structure):
/// At equilibrium, no agent can unilaterally improve.
/// We verify the fixed-point property: the Chebyshev center of each
/// agent's feasible set is invariant under the equilibrium joint state.
#[test]
fn theorem_15_2_nash_equilibrium_fixed_point() {
    // Two agents sharing a 2D resource space.
    // Agent 1 occupies x ∈ [0, 50], Agent 2 occupies x ∈ [50, 100].
    // This is a Nash equilibrium: neither can improve by deviating.

    let mut p1 = Polytope::new();
    p1.add_constraint(Vector(vec![1.0]), 50.0);
    p1.add_constraint(Vector(vec![-1.0]), 0.0);

    let mut p2 = Polytope::new();
    p2.add_constraint(Vector(vec![1.0]), 100.0);
    p2.add_constraint(Vector(vec![-1.0]), -50.0);

    // Each agent's optimal position is the center of their feasible set
    let center1 = Vector(vec![25.0]);
    let center2 = Vector(vec![75.0]);

    // Both are contained in their respective polytopes
    assert!(p1.contains(&center1), "Agent 1 center must be in P1");
    assert!(p2.contains(&center2), "Agent 2 center must be in P2");

    // Neither center is in the other's polytope (non-overlapping equilibrium)
    assert!(!p1.contains(&center2), "Agent 2 center must NOT be in P1");
    assert!(!p2.contains(&center1), "Agent 1 center must NOT be in P2");
}

// ============================================================================
// THEOREM 16: Competitive Constraint Interaction
// ============================================================================

/// Theorem 16.1 (Competitive κ Upper Bound):
/// κ_competitive ≤ κ_unperturbed + ||a|| / τ*
#[test]
fn theorem_16_1_competitive_kappa_upper_bound() {
    let mut p = Polytope::new();
    // A 2D box [0, 10] × [0, 2] — narrow corridor
    p.add_constraint(Vector(vec![1.0, 0.0]), 10.0);
    p.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    p.add_constraint(Vector(vec![0.0, 1.0]), 2.0);
    p.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    let defender_pos = Vector(vec![5.0, 1.0]);
    let transition = Vector(vec![1.0, 0.0]);

    // Unperturbed κ without attacker
    let kappa_unperturbed = p.predict_kappa_spike(&defender_pos, &transition);

    // Effective thickness in the y-direction (corridor width = 1.0 from center)
    let tau_star = p.estimate_directional_thickness(&defender_pos, &transition);

    // Attacker perturbation magnitude
    let attacker_strength = 0.5;

    // T16.1: Competitive κ ≤ κ_unperturbed + ||a|| / τ*
    let kappa_competitive_bound = kappa_unperturbed + attacker_strength / tau_star;

    // The bound must be strictly greater than unperturbed κ
    assert!(
        kappa_competitive_bound > kappa_unperturbed,
        "Adversarial action must increase collapse rate"
    );

    // The amplification term ||a||/τ* is the adversarial premium
    let adversarial_premium = attacker_strength / tau_star;
    assert!(
        adversarial_premium > 0.0,
        "Adversarial premium must be positive"
    );
}

/// Theorem 16.2 (Minimax Reachability — Chebyshev Center):
/// The optimal defender position maximizes minimum boundary distance.
#[test]
fn theorem_16_2_chebyshev_center_defense() {
    let mut p = Polytope::new();
    // Square [0, 10] × [0, 10]
    p.add_constraint(Vector(vec![1.0, 0.0]), 10.0);
    p.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    p.add_constraint(Vector(vec![0.0, 1.0]), 10.0);
    p.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    // Chebyshev center of a square [0,10]^2 is (5,5)
    let chebyshev_center = Vector(vec![5.0, 5.0]);
    let off_center = Vector(vec![8.0, 8.0]);

    let delta_center = p.boundary_distance(&chebyshev_center);
    let delta_off = p.boundary_distance(&off_center);

    // T16.2: Chebyshev center maximizes minimum boundary distance
    assert!(
        delta_center > delta_off,
        "Chebyshev center ({}) must have greater min boundary distance than off-center ({})",
        delta_center,
        delta_off
    );
    assert_eq!(delta_center, 5.0, "Chebyshev center of [0,10]^2 has δ = 5");
}
