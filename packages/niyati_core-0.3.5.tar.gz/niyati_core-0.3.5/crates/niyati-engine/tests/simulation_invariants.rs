use niyati_core::{simulate, CapabilityMode, VibeSchema};
use serde_json::json;

fn invariant_schema() -> VibeSchema {
    serde_json::from_value(json!({
        "version": "1.0.0",
        "metadata": { "name": "Invariant Test" },
        "time": { "type": "discrete", "horizon": 6 },
        "resources": {
            "money": { "initial": 600.0, "min": 0.0, "max": 1000.0 }
        },
        "variables": {
            "x": { "type": "float", "initial": 0.0, "min": 0.0, "max": 6.0, "discretization": 1.0 }
        },
        "actions": [
            {
                "name": "advance",
                "cost": { "money": 100.0 },
                "effects": { "x": { "op": "add", "value": 1.0 } },
                "preconditions": []
            }
        ],
        "transitions": [],
        "constraints": [],
        "goal": {
            "type": "threshold",
            "conditions": [{ "variable": "x", "operator": "gte", "value": 3.0 }]
        }
    }))
    .expect("schema should be valid")
}

#[test]
fn future_width_is_monotonic_non_increasing() {
    let result = simulate(invariant_schema(), Some(600.0), CapabilityMode::Full);

    for pair in result.timeline.windows(2) {
        assert!(
            pair[1].future_width <= pair[0].future_width,
            "future width increased from {} to {}",
            pair[0].future_width,
            pair[1].future_width
        );
    }
}

#[test]
fn point_of_no_return_matches_first_collapsed_step() {
    let result = simulate(invariant_schema(), Some(200.0), CapabilityMode::Full);
    let first_collapsed = result
        .timeline
        .iter()
        .find(|step| step.future_width == 0)
        .map(|step| step.t);

    assert_eq!(result.point_of_no_return, first_collapsed);
}

#[test]
fn goal_distance_stays_in_unit_interval() {
    let result = simulate(invariant_schema(), Some(600.0), CapabilityMode::Full);

    for step in result.timeline {
        assert!(
            (0.0..=1.0).contains(&step.goal_distance),
            "goal distance {} must stay in [0, 1]",
            step.goal_distance
        );
    }
}
