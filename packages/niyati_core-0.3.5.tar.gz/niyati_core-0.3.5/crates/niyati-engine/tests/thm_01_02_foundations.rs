mod common;
use common::create_test_graph;
use niyati_core::*;
use std::collections::HashMap;

// ============================================================================
// THEOREM 1: Reachable Set Definition
// ============================================================================

#[test]
fn theorem_1_property_1_1_reflexivity() {
    let space = create_test_graph();
    let engine = reachability::core::ReachabilityEngine::new(space);
    for budget in [0.0, 1.0, 10.0, 100.0] {
        let reachable = engine.compute_reachable_set(&"A".into(), budget);
        assert!(reachable.is_reachable(&"A".into()));
    }
}

#[test]
fn theorem_1_property_1_3_zero_budget() {
    let space = create_test_graph();
    let engine = reachability::core::ReachabilityEngine::new(space);
    let reachable = engine.compute_reachable_set(&"A".into(), 0.0);
    assert_eq!(reachable.optionality(), 1);
    assert!(reachable.is_reachable(&"A".into()));
    assert!(!reachable.is_reachable(&"B".into()));
}

#[test]
fn theorem_1_example_1_1_linear_chain() {
    let space = create_test_graph();
    let engine = reachability::core::ReachabilityEngine::new(space);
    let r5 = engine.compute_reachable_set(&"A".into(), 5.0);
    assert!(r5.is_reachable(&"A".into()));
    assert!(r5.is_reachable(&"B".into()));
    assert!(!r5.is_reachable(&"C".into()));
}

#[test]
fn theorem_1_corollary_1_1_structural_unreachability() {
    let mut space = StateSpace::new();
    space.add_state(State {
        id: "A".into(),
        attributes: HashMap::new(),
    });
    space.add_state(State {
        id: "B".into(),
        attributes: HashMap::new(),
    });
    space.add_state(State {
        id: "C".into(),
        attributes: HashMap::new(),
    });
    space.add_state(State {
        id: "D".into(),
        attributes: HashMap::new(),
    });
    space.add_transition(Transition {
        from: "A".into(),
        to: "B".into(),
        cost: 5.0,
        metadata: None,
    });
    space.add_transition(Transition {
        from: "C".into(),
        to: "D".into(),
        cost: 5.0,
        metadata: None,
    });

    let engine = reachability::core::ReachabilityEngine::new(space);
    let reachable = engine.compute_reachable_set(&"A".into(), 1000.0);
    assert!(reachable.is_reachable(&"A".into()));
    assert!(reachable.is_reachable(&"B".into()));
    assert!(!reachable.is_reachable(&"C".into()));
}

// ============================================================================
// THEOREM 2: Monotonicity
// ============================================================================

#[test]
fn theorem_2_main_statement() {
    let space = create_test_graph();
    let engine = reachability::core::ReachabilityEngine::new(space);
    let r1 = engine.compute_reachable_set(&"A".into(), 3.0);
    let r2 = engine.compute_reachable_set(&"A".into(), 10.0);
    assert!(r1.states.is_subset(&r2.states));
}

#[test]
fn theorem_2_property_2_2_cardinality_monotonicity() {
    let space = create_test_graph();
    let engine = reachability::core::ReachabilityEngine::new(space);
    let r1 = engine.compute_reachable_set(&"A".into(), 5.0);
    let r2 = engine.compute_reachable_set(&"A".into(), 10.0);
    assert!(r1.optionality() <= r2.optionality());
}
