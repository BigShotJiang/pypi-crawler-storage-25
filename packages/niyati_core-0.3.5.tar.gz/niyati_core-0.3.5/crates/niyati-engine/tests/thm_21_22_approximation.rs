use niyati_core::computability::{ComputabilityAnalysis, ComputationMode};
use niyati_core::geometry::{Polytope, Vector};

// ============================================================================
// THEOREM 21: Approximation Bounds
// ============================================================================

/// Theorem 21.1 (Absolute Error Bound):
/// |Ω_exact - Ω_LP| ≤ C_k · diam^(k-1)
/// Error scales with surface area, not volume.
#[test]
fn theorem_21_1_absolute_error_scales_with_surface() {
    // Two polytopes: same dimension, different diameters.
    // Larger polytope → larger absolute error bound.

    // Small polytope: [0, 5] × [0, 5]
    let dim = 2;
    let diam_small: f64 = 5.0_f64 * 2.0_f64.sqrt(); // diagonal of [0,5]^2
    let diam_large: f64 = 50.0_f64 * 2.0_f64.sqrt(); // diagonal of [0,50]^2

    // Surface normalization constant (dimension-dependent)
    let c_k = (dim as f64).sqrt() * 2.0_f64.powi(dim - 1);

    let error_small = c_k * diam_small.powi(dim - 1);
    let error_large = c_k * diam_large.powi(dim - 1);

    // T21.1: Larger polytope → larger absolute error
    assert!(
        error_large > error_small,
        "Larger polytope ({:.2}) must have larger absolute error ({:.2})",
        error_large,
        error_small
    );
}

/// Theorem 21.2 (Relative Error Bound):
/// Relative error vanishes as volume grows, diverges near collapse.
#[test]
fn theorem_21_2_relative_error_vanishes_with_large_volume() {
    let dim = 3;
    let c_k = (dim as f64).sqrt() * 2.0_f64.powi(dim - 1);

    // Large volume polytope: V ≈ 1,000,000
    let diam_large: f64 = 100.0;
    let vol_large: f64 = 1_000_000.0;
    let abs_error = c_k * diam_large.powi(dim - 1);
    let rel_error_large = abs_error / vol_large;

    // Small volume (near collapse): V ≈ 2
    let vol_small = 2.0;
    let rel_error_small_vol = abs_error / vol_small;

    // T21.2: Relative error is tiny for large volumes, huge near collapse
    assert!(
        rel_error_large < 0.1,
        "Relative error with large volume should be < 10%, got {:.4}",
        rel_error_large
    );
    assert!(
        rel_error_small_vol > 1.0,
        "Relative error near collapse should be > 100%, got {:.2}",
        rel_error_small_vol
    );
}

/// Theorem 21.3 (Critical Phase Error Amplification):
/// LP mode is formally untrustworthy when Ω → 0.
#[test]
fn theorem_21_3_critical_phase_switches_to_bfs() {
    // When Ω is very small, ComputabilityAnalysis should recommend BFS.
    // We verify this by checking that near-collapse volumes trigger warnings.
    let omega_large = 10_000.0;
    let omega_collapse = 1.0;

    let dim = 3;
    let c_k = (dim as f64).sqrt() * 2.0_f64.powi(dim - 1);
    let diam: f64 = 10.0;
    let abs_error = c_k * diam.powi(dim - 1);

    let rel_error_healthy = abs_error / omega_large;
    let rel_error_collapse = abs_error / omega_collapse;

    // T21.3: Near-collapse relative error exceeds 100%
    assert!(
        rel_error_healthy < 0.1,
        "Healthy system relative error should be low"
    );
    assert!(
        rel_error_collapse > 1.0,
        "Near-collapse relative error must exceed 100% (got {:.2})",
        rel_error_collapse
    );

    // The operational consequence: system must switch to BFS
    let analysis_small = ComputabilityAnalysis::analyze(Some(50), false, false);
    assert_eq!(
        analysis_small.mode,
        ComputationMode::ExactBFS,
        "Small state space near collapse must use BFS"
    );
}

// ============================================================================
// THEOREM 22: Sampling Guarantees
// ============================================================================

/// Theorem 22.1 & 22.2 (Mixing Time and Sample Complexity):
/// Both scale with k^3 · r^2 where r = aspect ratio.
#[test]
fn theorem_22_1_2_mixing_time_scales_with_aspect_ratio() {
    let k = 3.0_f64; // dimension
    let log_delta = (1.0 / 0.05_f64).ln(); // 95% confidence

    // Round shape: aspect ratio 1 (inscribed ball = circumscribed ball)
    let r_round: f64 = 1.0;
    let mixing_round = k.powi(3) * r_round.powi(2) * log_delta;

    // Elongated shape: aspect ratio 100
    let r_elongated: f64 = 100.0;
    let mixing_elongated = k.powi(3) * r_elongated.powi(2) * log_delta;

    // T22.1: Mixing time scales quadratically with aspect ratio
    assert!(
        mixing_elongated > mixing_round * 9000.0,
        "Elongated polytope mixing ({:.0}) must be >> round ({:.0})",
        mixing_elongated,
        mixing_round
    );
}

/// Theorem 22.3 (Corridor Deterioration):
/// Mixing time ∝ 1/τ*² — corridors destroy sampling reliability.
#[test]
fn theorem_22_3_corridor_deterioration() {
    let k = 3.0_f64;

    // Wide polytope: τ* = 50
    let tau_wide: f64 = 50.0;
    let diam: f64 = 100.0;
    let r_wide: f64 = diam / tau_wide; // aspect ratio = 2

    // Narrow corridor: τ* = 0.5
    let tau_narrow: f64 = 0.5;
    let r_narrow: f64 = diam / tau_narrow; // aspect ratio = 200

    let mixing_wide = k.powi(3) * r_wide.powi(2);
    let mixing_narrow = k.powi(3) * r_narrow.powi(2);

    // T22.3: Corridors require quadratically more samples
    let ratio = mixing_narrow / mixing_wide;
    assert!(
        ratio > 9000.0,
        "Corridor mixing should be >10000x worse, got {:.0}x",
        ratio
    );

    // The ratio should be approximately (τ_wide/τ_narrow)² = (50/0.5)² = 10000
    let expected_ratio: f64 = (tau_wide / tau_narrow).powi(2);
    assert!(
        (ratio - expected_ratio).abs() < 1.0,
        "Ratio ({:.0}) should match (τ_w/τ_n)² = {:.0}",
        ratio,
        expected_ratio
    );
}

/// Theorem 22.3 — Connection to fragility:
/// Verify that τ* from the geometry module gives consistent results
/// with the sampling complexity formula.
#[test]
fn theorem_22_3_fragility_sampling_connection() {
    let mut corridor = Polytope::new();
    // Corridor: [0, 100] × [0, 2]
    corridor.add_constraint(Vector(vec![1.0, 0.0]), 100.0);
    corridor.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    corridor.add_constraint(Vector(vec![0.0, 1.0]), 2.0);
    corridor.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    let center = Vector(vec![50.0, 1.0]);
    let forward = Vector(vec![1.0, 0.0]);

    // Get τ* from the geometry module (Theorem 14)
    let tau_star = corridor.estimate_directional_thickness(&center, &forward);

    // T22.3: sampling complexity ∝ 1/τ*²
    let sample_complexity_factor = 1.0 / (tau_star * tau_star);
    assert!(
        sample_complexity_factor > 0.0,
        "Sample complexity factor must be positive"
    );
    assert!(
        tau_star > 0.0 && tau_star <= 1.0,
        "Corridor thickness should be ≤ 1.0, got {}",
        tau_star
    );
}
