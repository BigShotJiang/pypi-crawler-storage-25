use niyati_core::geometry::{Polytope, Vector};

// ============================================================================
// THEOREM 8: Polytope Geometry of Reachable Sets
// ============================================================================

#[test]
fn theorem_8_property_8_1_geometric_embedding() {
    // A 2D Simplex budget: x1 + x2 <= 100
    // x1 >= 0  => -x1 <= 0
    // x2 >= 0  => -x2 <= 0
    let mut p = Polytope::new();
    p.add_constraint(Vector(vec![1.0, 1.0]), 100.0);
    p.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
    p.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

    // Deep interior point is reachable
    let interior = Vector(vec![30.0, 30.0]);
    assert!(p.contains(&interior));

    // Boundary point is reachable
    let boundary = Vector(vec![100.0, 0.0]);
    assert!(p.contains(&boundary));

    // External point is unreachable
    let external = Vector(vec![60.0, 60.0]); // 120 > 100
    assert!(!p.contains(&external));
}

// ============================================================================
// THEOREM 13: Boundary Sensitivity
// ============================================================================

#[test]
fn theorem_13_1_boundary_distance_magnitude() {
    let mut p = Polytope::new();
    // Simple 1D boundary at x = 100
    p.add_constraint(Vector(vec![1.0]), 100.0);

    let x1 = Vector(vec![90.0]);
    let x2 = Vector(vec![99.0]);

    // delta(x1) = 10, delta(x2) = 1
    assert_eq!(p.boundary_distance(&x1), 10.0);
    assert_eq!(p.boundary_distance(&x2), 1.0);
}

#[test]
fn theorem_13_2_anisotropic_directional_sensitivity() {
    let mut p = Polytope::new();
    // Square constraint: x <= 10, y <= 10
    p.add_constraint(Vector(vec![1.0, 0.0]), 10.0);
    p.add_constraint(Vector(vec![0.0, 1.0]), 10.0);

    let start = Vector(vec![5.0, 9.0]);

    // Vector pointing directly at the y-wall
    let v_y = Vector(vec![0.0, 1.0]);
    let dist_y = p.directional_distance(&start, &v_y);
    assert_eq!(dist_y, 1.0); // Only 1 unit away from y=10

    // Vector pointing at the x-wall
    let v_x = Vector(vec![1.0, 0.0]);
    let dist_x = p.directional_distance(&start, &v_x);
    assert_eq!(dist_x, 5.0); // 5 units away from x=10

    // Sensitivity is rigorously anisotropic depending on vector choice
    assert!(dist_y < dist_x);
}

#[test]
fn theorem_13_3_kappa_approximation_spike() {
    let mut p = Polytope::new();
    p.add_constraint(Vector(vec![1.0]), 100.0);

    // Transition vector length = 1.0
    let v = Vector(vec![1.0]);

    // Deep interior
    let safe_pos = Vector(vec![50.0]);
    let safe_kappa = p.predict_kappa_spike(&safe_pos, &v);

    // Critical boundary
    let fragile_pos = Vector(vec![99.0]);
    let fragile_kappa = p.predict_kappa_spike(&fragile_pos, &v);

    // Critical boundary threshold
    let terminal_pos = Vector(vec![100.0]);
    let terminal_kappa = p.predict_kappa_spike(&terminal_pos, &v);

    // Kappa spikes precisely as boundary distance collapses (Thm 13.3)
    assert!(
        fragile_kappa > safe_kappa,
        "Fragile state must have higher kappa spike"
    );
    assert_eq!(fragile_kappa, 1.0); // v_mag(1) / dist(1)
    assert_eq!(safe_kappa, 0.02); // v_mag(1) / dist(50)
    assert!(
        terminal_kappa.is_infinite(),
        "Terminal state crossing boundary must yield infinite kappa"
    );
}
