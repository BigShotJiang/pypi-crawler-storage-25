use niyati_core::*;
use std::collections::HashMap;

pub fn create_test_graph() -> StateSpace {
    let mut space = StateSpace::new();

    space.add_state(State {
        id: "A".into(),
        attributes: HashMap::new(),
    });
    space.add_state(State {
        id: "B".into(),
        attributes: HashMap::new(),
    });
    space.add_state(State {
        id: "C".into(),
        attributes: HashMap::new(),
    });
    space.add_state(State {
        id: "D".into(),
        attributes: HashMap::new(),
    });

    space.add_transition(Transition {
        from: "A".into(),
        to: "B".into(),
        cost: 5.0,
        metadata: None,
    });
    space.add_transition(Transition {
        from: "B".into(),
        to: "C".into(),
        cost: 3.0,
        metadata: None,
    });
    space.add_transition(Transition {
        from: "A".into(),
        to: "D".into(),
        cost: 10.0,
        metadata: None,
    });

    space
}
