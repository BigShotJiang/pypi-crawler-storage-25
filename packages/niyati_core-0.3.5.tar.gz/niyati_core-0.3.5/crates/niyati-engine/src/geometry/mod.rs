//! Geometric primitives for Causalor continuous embedding (Theorems 8 and 13).

use std::f64;

#[derive(Debug, Clone, PartialEq)]
pub struct Vector(pub Vec<f64>);

impl Vector {
    pub fn dot(&self, other: &Vector) -> f64 {
        self.0.iter().zip(other.0.iter()).map(|(a, b)| a * b).sum()
    }

    pub fn magnitude(&self) -> f64 {
        self.dot(self).sqrt()
    }

    pub fn dim(&self) -> usize {
        self.0.len()
    }
}

/// Represents a bounding hyperplane A_i * x <= b_i
#[derive(Debug, Clone)]
pub struct ConstraintPlane {
    pub normal: Vector,
    pub bound: f64,
}

/// The feasible region representation of reachable futures (Theorem 8).
#[derive(Debug, Clone)]
pub struct Polytope {
    pub constraints: Vec<ConstraintPlane>,
}

impl Default for Polytope {
    fn default() -> Self {
        Self::new()
    }
}

impl Polytope {
    /// Creates an empty unbounded polytope
    pub fn new() -> Self {
        Polytope {
            constraints: Vec::new(),
        }
    }

    pub fn add_constraint(&mut self, normal: Vector, bound: f64) {
        self.constraints.push(ConstraintPlane { normal, bound });
    }

    /// Checks if a state coordinate x is fully within the feasible boundary.
    pub fn contains(&self, x: &Vector) -> bool {
        for plane in &self.constraints {
            if plane.normal.dot(x) > plane.bound + 1e-9 {
                return false;
            }
        }
        true
    }

    /// Theorem 13: Computes the explicit absolute minimal perturbation to escape feasibility.
    pub fn boundary_distance(&self, x: &Vector) -> f64 {
        let mut min_distance = f64::INFINITY;
        for plane in &self.constraints {
            let magnitude = plane.normal.magnitude();
            if magnitude > 1e-9 {
                // distance = (b - A*x) / ||A||
                let dist = (plane.bound - plane.normal.dot(x)) / magnitude;
                min_distance = min_distance.min(dist);
            }
        }
        min_distance
    }

    /// Returns the signed slack to every constraint plane, normalized by plane magnitude.
    pub fn constraint_slacks(&self, x: &Vector) -> Vec<f64> {
        self.constraints
            .iter()
            .filter_map(|plane| {
                let magnitude = plane.normal.magnitude();
                if magnitude > 1e-9 {
                    Some((plane.bound - plane.normal.dot(x)) / magnitude)
                } else {
                    None
                }
            })
            .collect()
    }

    /// Theorem 12: Active constraints are the boundaries currently pinning the local geometry.
    pub fn active_constraint_count(&self, x: &Vector, tolerance: f64) -> usize {
        self.constraint_slacks(x)
            .into_iter()
            .filter(|slack| *slack <= tolerance)
            .count()
    }

    /// Theorem 12: Local dimensionality of the feasible manifold.
    pub fn local_dimension(&self, x: &Vector, tolerance: f64) -> usize {
        let dim = x.dim();
        let active = self.active_constraint_count(x, tolerance).min(dim);
        dim.saturating_sub(active)
    }

    /// T20.5: Minimum perturbation needed to escape feasibility.
    pub fn minimum_collapse_perturbation(&self, x: &Vector) -> f64 {
        self.boundary_distance(x)
    }

    /// Theorem 13.2: Computes Anisotropic Directional Distance \delta_v(x)
    pub fn directional_distance(&self, x: &Vector, v: &Vector) -> f64 {
        let mut min_distance = f64::INFINITY;

        for plane in &self.constraints {
            let traversal_velocity = plane.normal.dot(v);

            // Limit Definition 13.4: Only examine constraints we are moving *toward*
            if traversal_velocity > 1e-9 {
                let slack = plane.bound - plane.normal.dot(x);
                let distance_to_impact = slack / traversal_velocity;
                min_distance = min_distance.min(distance_to_impact);
            }
        }

        min_distance
    }

    /// Core bridge between Geometry and Entropy (Collapse Rate \kappa).
    pub fn predict_kappa_spike(&self, current_pos: &Vector, transition_vector: &Vector) -> f64 {
        let delta_v = self.directional_distance(current_pos, transition_vector);

        // Kappa spikes strictly inverse to the remaining margin (Thm 13.3)
        let v_mag = transition_vector.magnitude();
        if delta_v == 0.0 || delta_v.is_infinite() {
            return f64::INFINITY;
        }
        v_mag / delta_v
    }

    /// Generates an orthogonal basis via a basic deterministic projection
    fn create_arbitrary_orthogonal(&self, v: &Vector) -> Vec<Vector> {
        let dim = v.dim();
        let mut obs = Vec::new();
        let v_mag = v.magnitude();
        if v_mag < 1e-9 || dim <= 1 {
            return obs;
        }

        // Simple rotation heuristic for 2D/3D to get orthogonal basis for test isolation
        for d in 0..dim {
            let mut orth = vec![0.0; dim];
            orth[d] = 1.0;

            // Gram-Schmidt projection: orth = orth - proj_v(orth)
            let proj_scalar = v.dot(&Vector(orth.clone())) / (v_mag * v_mag);
            for (i, val) in orth.iter_mut().enumerate().take(dim) {
                *val -= proj_scalar * v.0[i];
            }

            let w = Vector(orth);
            if w.magnitude() > 1e-9 {
                let w_norm = Vector(w.0.iter().map(|&val| val / w.magnitude()).collect());
                obs.push(w_norm);
            }
        }
        obs
    }

    /// Theorem 14.4: Estimates the directional thickness \tau_v(x).
    /// Finds the minimum boundary distance explicitly orthogonal to your movement.
    pub fn estimate_directional_thickness(&self, x: &Vector, v: &Vector) -> f64 {
        let obs = self.create_arbitrary_orthogonal(v);
        if obs.is_empty() {
            return 1.0;
        } // 1D handles fallbacks

        let mut min_tau = f64::INFINITY;
        for w in obs {
            let mut w_neg = w.clone();
            for val in &mut w_neg.0 {
                *val = -*val;
            }

            let dist_pos = self.directional_distance(x, &w);
            let dist_neg = self.directional_distance(x, &w_neg);
            min_tau = min_tau.min(dist_pos).min(dist_neg);
        }

        min_tau
    }

    /// Theorem 14.1 (Amplification Law): Unified Collapse Risk (Proximity * Fragility)
    pub fn unified_collapse_risk(&self, x: &Vector, v: &Vector) -> f64 {
        let proximity_risk = self.predict_kappa_spike(x, v);
        let tau_v = self.estimate_directional_thickness(x, v);

        if tau_v <= 1e-9 {
            return f64::INFINITY; // Infinite fragility
        }

        proximity_risk * (1.0 / tau_v)
    }
}
