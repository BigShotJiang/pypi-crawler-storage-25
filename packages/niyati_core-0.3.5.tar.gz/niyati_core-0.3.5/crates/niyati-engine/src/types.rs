use serde::{Deserialize, Serialize};
use std::collections::HashMap;

pub type StateId = String;
pub type Cost = f64;
pub type Budget = f64;
pub type Time = usize;

// Existing simple types remain for backward compatibility
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct State {
    pub id: StateId,
    pub attributes: HashMap<String, serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Transition {
    pub from: StateId,
    pub to: StateId,
    pub cost: Cost,
    pub metadata: Option<HashMap<String, serde_json::Value>>,
}

// NEW: Temporal extensions
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TemporalState {
    pub id: StateId,
    pub attributes: HashMap<String, serde_json::Value>,
    pub valid_from: Time,
    pub valid_until: Option<Time>, // None = still valid
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TemporalTransition {
    pub from: StateId,
    pub to: StateId,
    pub cost: Cost,
    pub valid_from: Time,
    pub valid_until: Option<Time>,
    pub metadata: Option<HashMap<String, serde_json::Value>>,
}

// Static state space (current)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StateSpace {
    pub states: HashMap<StateId, State>,
    pub transitions: Vec<Transition>,
}

// NEW: Evolving state space
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvolvingStateSpace {
    pub states: HashMap<StateId, TemporalState>,
    pub transitions: Vec<TemporalTransition>,
}

impl EvolvingStateSpace {
    pub fn new() -> Self {
        EvolvingStateSpace {
            states: HashMap::new(),
            transitions: Vec::new(),
        }
    }

    /// Get snapshot of state space at specific time
    pub fn snapshot_at(&self, time: Time) -> StateSpace {
        let mut space = StateSpace::new();

        // Add states valid at this time
        for (id, temporal_state) in &self.states {
            if temporal_state.is_valid_at(time) {
                space.add_state(State {
                    id: id.clone(),
                    attributes: temporal_state.attributes.clone(),
                });
            }
        }

        // Add transitions valid at this time
        for temporal_trans in &self.transitions {
            if temporal_trans.is_valid_at(time) {
                space.add_transition(Transition {
                    from: temporal_trans.from.clone(),
                    to: temporal_trans.to.clone(),
                    cost: temporal_trans.cost,
                    metadata: temporal_trans.metadata.clone(),
                });
            }
        }

        space
    }

    /// Add a state that exists from a specific time
    pub fn add_temporal_state(&mut self, state: TemporalState) {
        self.states.insert(state.id.clone(), state);
    }

    /// Add a transition valid for a time period
    pub fn add_temporal_transition(&mut self, transition: TemporalTransition) {
        self.transitions.push(transition);
    }

    /// Mark a state as no longer valid after a time
    pub fn close_state(&mut self, state_id: &StateId, end_time: Time) {
        if let Some(state) = self.states.get_mut(state_id) {
            state.valid_until = Some(end_time);
        }
    }

    /// Mark a transition as no longer valid
    pub fn close_transition(&mut self, from: &StateId, to: &StateId, end_time: Time) {
        for trans in &mut self.transitions {
            if &trans.from == from && &trans.to == to && trans.valid_until.is_none() {
                trans.valid_until = Some(end_time);
            }
        }
    }
}

impl TemporalState {
    pub fn is_valid_at(&self, time: Time) -> bool {
        time >= self.valid_from && self.valid_until.is_none_or(|end| time < end)
    }
}

impl TemporalTransition {
    pub fn is_valid_at(&self, time: Time) -> bool {
        time >= self.valid_from && self.valid_until.is_none_or(|end| time < end)
    }
}

impl StateSpace {
    pub fn new() -> Self {
        StateSpace {
            states: HashMap::new(),
            transitions: Vec::new(),
        }
    }

    pub fn add_state(&mut self, state: State) {
        self.states.insert(state.id.clone(), state);
    }

    pub fn add_transition(&mut self, transition: Transition) {
        self.transitions.push(transition);
    }

    pub fn build_graph(&self) -> HashMap<StateId, Vec<(StateId, Cost)>> {
        let mut graph: HashMap<StateId, Vec<(StateId, Cost)>> = HashMap::new();

        for transition in &self.transitions {
            graph
                .entry(transition.from.clone())
                .or_default()
                .push((transition.to.clone(), transition.cost));
        }

        graph
    }
}

impl Default for StateSpace {
    fn default() -> Self {
        Self::new()
    }
}

impl Default for EvolvingStateSpace {
    fn default() -> Self {
        Self::new()
    }
}
