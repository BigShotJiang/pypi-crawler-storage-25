use crate::approximation::{PolytopeVolumeEstimator, TrustOracle};
use crate::geometry::ConstraintPlane;
use crate::vibe::schema::{ErrorBounds, TrustLevel};
use std::collections::HashMap;

/// Deterministic Monte Carlo Volume Estimator (T21).
///
/// Uses rejection sampling within an axis-aligned bounding box
/// to estimate the volume of an n-dimensional polytope.
pub struct MonteCarloVolumeEstimator {
    pub planes: Vec<ConstraintPlane>,
    pub variable_bounds: HashMap<String, (f64, f64)>,
    pub discretization_factors: HashMap<String, f64>,
}

impl MonteCarloVolumeEstimator {
    pub fn new(
        planes: Vec<ConstraintPlane>,
        variable_bounds: HashMap<String, (f64, f64)>,
        discretization_factors: HashMap<String, f64>,
    ) -> Self {
        Self {
            planes,
            variable_bounds,
            discretization_factors,
        }
    }

    /// A simple, deterministic LCG for cross-platform parity.
    /// x_{n+1} = (a * x_n + c) % m
    fn next_rand(seed: &mut u64) -> f64 {
        *seed = (*seed).wrapping_mul(6364136223846793005).wrapping_add(1);
        (*seed as f64) / (u64::MAX as f64)
    }
}

impl PolytopeVolumeEstimator for MonteCarloVolumeEstimator {
    fn estimate_volume(&self, num_samples: usize) -> (f64, ErrorBounds, TrustLevel) {
        if self.variable_bounds.is_empty() {
            return (
                0.0,
                ErrorBounds {
                    epsilon: 0.0,
                    confidence: 1.0,
                },
                TrustLevel::High,
            );
        }

        // 1. Calculate Bounding Box Volume
        let mut box_volume = 1.0;
        let mut dimensions = Vec::new();
        let sorted_keys: Vec<_> = {
            let mut keys: Vec<_> = self.variable_bounds.keys().collect();
            keys.sort(); // Deterministic order for samples
            keys
        };

        for key in &sorted_keys {
            let (min, max) = self.variable_bounds.get(*key).unwrap();
            let range = (max - min).max(0.0);
            box_volume *= range;
            dimensions.push((*min, range));
        }

        // 2. Perform Rejection Sampling
        let mut inside_count = 0;
        let mut seed = 42; // Canonical seed for determinism

        for _ in 0..num_samples {
            let mut coords = Vec::with_capacity(sorted_keys.len());
            for &(min, range) in dimensions.iter().take(sorted_keys.len()) {
                let val = min + Self::next_rand(&mut seed) * range;
                coords.push(val);
            }
            let x = crate::geometry::Vector(coords);

            // Check against all planes
            let mut is_inside = true;
            for plane in &self.planes {
                if plane.normal.dot(&x) > plane.bound {
                    is_inside = false;
                    break;
                }
            }

            if is_inside {
                inside_count += 1;
            }
        }

        // 3. Final Volume (Ω) and Epistemic Metrics (T22)
        let saturation = inside_count as f64 / num_samples as f64;
        let continuous_volume = box_volume * saturation;

        // Scale by discretization to get discrete state count (Ω)
        // Ω = Volume / Product(discretization_i)
        let mut disc_product = 1.0;
        for key in &sorted_keys {
            disc_product *= self.discretization_factors.get(*key).unwrap_or(&1.0);
        }

        let hat_omega = if disc_product > 0.0 {
            continuous_volume / disc_product
        } else {
            continuous_volume
        };

        let (bounds, trust) = TrustOracle::evaluate(
            hat_omega,
            inside_count,
            num_samples,
            box_volume / disc_product,
        );

        (hat_omega, bounds, trust)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_volume_1d() {
        let mut bounds = HashMap::new();
        bounds.insert("x".to_string(), (0.0, 100.0));

        let mut disc = HashMap::new();
        disc.insert("x".to_string(), 1.0);

        let estimator = MonteCarloVolumeEstimator::new(vec![], bounds, disc);
        let (omega, _, _) = estimator.estimate_volume(1000);

        // 1D volume with 0 planes should be full range
        assert!((omega - 100.0).abs() < 1.0);
    }

    #[test]
    fn test_volume_with_constraint() {
        let mut bounds = HashMap::new();
        bounds.insert("x".to_string(), (0.0, 100.0));

        // Plane: x <= 50. Normal vector [1.0] for the single dimension.
        let normal = crate::geometry::Vector(vec![1.0]);
        let planes = vec![crate::geometry::ConstraintPlane {
            normal,
            bound: 50.0,
        }];

        let mut disc = HashMap::new();
        disc.insert("x".to_string(), 1.0);

        let estimator = MonteCarloVolumeEstimator::new(planes, bounds, disc);
        let (omega, _, _) = estimator.estimate_volume(10000);

        // Should be approximately 50
        assert!((omega - 50.0).abs() < 2.0);
    }
}
