use crate::dynamics::collapse::{
    compute_collapse_rate, safe_log2, CollapseRate, Entropy, Optionality,
};
use crate::types::StateId;

pub fn entropy(omega: Optionality) -> Entropy {
    if omega.0 <= 0.0 {
        Entropy(0.0)
    } else {
        Entropy(safe_log2(omega.0))
    }
}

#[derive(Debug, Clone)]
pub struct DecisionMetrics {
    pub next_state: StateId,
    pub omega_next: Optionality,
    pub entropy_next: Entropy,
    pub kappa: CollapseRate,
    pub impact_ratio: f64, // κ / H
}

pub fn evaluate_transition(
    omega_curr: Optionality,
    next_state: &StateId,
    omega_next: Optionality,
) -> DecisionMetrics {
    let h_curr = entropy(omega_curr);
    let h_next = entropy(omega_next);
    let kappa = compute_collapse_rate(omega_curr, omega_next);

    let impact_ratio = if h_curr.0 > 0.0 {
        kappa.0 / h_curr.0
    } else {
        0.0
    };

    DecisionMetrics {
        next_state: next_state.clone(),
        omega_next,
        entropy_next: h_next,
        kappa,
        impact_ratio,
    }
}

pub fn is_critical(metrics: &DecisionMetrics, epsilon: f64) -> bool {
    metrics.impact_ratio >= epsilon
}

pub fn rank_decisions(mut decisions: Vec<DecisionMetrics>) -> Vec<DecisionMetrics> {
    decisions.sort_by(|a, b| {
        b.impact_ratio
            .partial_cmp(&a.impact_ratio)
            .unwrap_or(std::cmp::Ordering::Equal)
    });
    decisions
}
