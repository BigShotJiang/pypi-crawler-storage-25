use serde::{Deserialize, Serialize};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VibeSchema {
    pub version: String,
    pub metadata: Metadata,
    pub time: TimeConfig,
    pub resources: HashMap<String, ResourceDefinition>,
    pub variables: HashMap<String, VariableDefinition>,
    pub actions: Vec<ActionDefinition>,
    pub transitions: Vec<TransitionDefinition>,
    pub constraints: Vec<ConstraintDefinition>,
    pub goal: GoalDefinition,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub theorem_inputs: Option<TheoremInputs>,
}

impl VibeSchema {
    /// System Law: Compositional Soundness.
    ///
    /// Merges two independent or coupled schemas.
    /// This follows the guarantee that Ω(S₁ ⊕ S₂) = Ω(S₁) · Ω(S₂) for independent systems,
    /// or Ω(S) ≤ Ω(S₁) · Ω(S₂) - ρ for coupled ones.
    pub fn compose(&self, other: &Self) -> Self {
        let mut variables = self.variables.clone();
        for (name, var) in &other.variables {
            variables.entry(name.clone()).or_insert_with(|| var.clone());
        }

        let mut actions = self.actions.clone();
        actions.extend(other.actions.iter().cloned());

        let mut transitions = self.transitions.clone();
        transitions.extend(other.transitions.iter().cloned());

        let mut constraints = self.constraints.clone();
        constraints.extend(other.constraints.iter().cloned());

        let mut resources = self.resources.clone();
        for (name, res) in &other.resources {
            resources.entry(name.clone()).or_insert_with(|| res.clone());
        }

        Self {
            version: self.version.clone(),
            metadata: Metadata {
                name: format!("{} + {}", self.metadata.name, other.metadata.name),
                description: Some(format!(
                    "Composed from {} and {}",
                    self.metadata.name, other.metadata.name
                )),
            },
            time: self.time.clone(),
            resources,
            variables,
            actions,
            transitions,
            constraints,
            goal: self.goal.clone(),
            theorem_inputs: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Metadata {
    pub name: String,
    pub description: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimeConfig {
    pub r#type: TimeType,
    pub horizon: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceDefinition {
    pub initial: f64,
    /// Mandatory minimum bound (e.g., 0 for no debt).
    pub min: f64,
    pub max: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum TimeType {
    Discrete,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VariableDefinition {
    pub r#type: VariableType,
    pub initial: serde_json::Value,
    pub min: Option<f64>,
    pub max: Option<f64>,
    pub discretization: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum VariableType {
    Float,
    Int,
    Bool,
}

impl VariableType {
    pub fn default_max(&self) -> f64 {
        match self {
            Self::Float => 1e12,
            Self::Int => 2147483647.0,
            Self::Bool => 1.0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ActionDefinition {
    pub name: String,
    pub cost: HashMap<String, f64>,
    pub effects: HashMap<String, Effect>,
    pub preconditions: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Effect {
    pub op: EffectOp,
    pub value: EffectValue,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum EffectOp {
    Add,
    Set,
    Multiply,
    Decrement,
    Affine,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum EffectValue {
    Number(f64),
    Variable(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransitionDefinition {
    pub name: String,
    pub r#type: TransitionType,
    pub priority: i32,
    pub condition: Option<String>,
    /// Causal Law: Vector Semantics.
    ///
    /// All effects in a transition are evaluated against the source state
    /// before any mutations are applied.
    pub effects: HashMap<String, Effect>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum TransitionType {
    Recurring,
    Triggered,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConstraintDefinition {
    pub r#type: ConstraintType,
    pub mode: ConstraintMode,
    pub variable: String,
    pub operator: Option<Operator>,
    pub value: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum ConstraintMode {
    Hard,
    Soft,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum Operator {
    Eq,
    Gt,
    Lt,
    Gte,
    Lte,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum ConstraintType {
    Threshold,
    NonNegative,
    ForbiddenZone,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoalDefinition {
    pub r#type: GoalType,
    pub conditions: Vec<GoalCondition>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TheoremInputs {
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub agents: Vec<AgentScenario>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub critical_epsilon: Option<f64>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub discovery_events: Vec<DiscoveryEventInput>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub composition_subsystems: Vec<CompositionSubsystemInput>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentScenario {
    pub id: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub budget: Option<f64>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub consumed_states: Vec<String>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub attacker_strength: Option<f64>,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub role: Option<AgentRole>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum AgentRole {
    Defender,
    Attacker,
    Neutral,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiscoveryEventInput {
    pub time: usize,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub new_states: Vec<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub new_edges: Vec<DiscoveryEdgeInput>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DiscoveryEdgeInput {
    pub from: String,
    pub to: String,
    pub cost: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompositionSubsystemInput {
    pub name: String,
    pub volume: f64,
    pub thickness: f64,
    pub kappa: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GoalCondition {
    pub variable: String,
    pub operator: Operator,
    pub value: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum GoalType {
    Threshold,
    ReachState,
    Composite,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum CapabilityMode {
    /// Public SDK mode. Enforces 'Strategic Hard Limits' to protect IP.
    Lite,
    /// Internal / Hosted API mode. Full access to T1-T30 theorem stack.
    Full,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum ExecutionMode {
    /// Exact BFS representation (< 5,000 states).
    Discrete,
    /// LP-based volume estimation with localized BFS (5k - 100k potential).
    Hybrid,
    /// Pure Polytope Volume estimation (> 100k potential).
    Continuous,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum TrustLevel {
    /// Exact result with zero error margin.
    High,
    /// Hybrid result with bounded approximation.
    Medium,
    /// Approximate result with statistical confidence.
    Low,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ErrorBounds {
    /// Maximum absolute error magnitude (ε).
    pub epsilon: f64,
    /// Statistical confidence level (1-δ).
    pub confidence: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemAlert {
    pub code: String,
    pub severity: AlertSeverity,
    pub message: String,
    pub detail: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub theorem: Option<String>,
    #[serde(rename = "type", skip_serializing_if = "Option::is_none")]
    pub legacy_type: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum AlertSeverity {
    Info,
    Warning,
    Critical,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationResult {
    pub timeline: Vec<TimelineStep>,
    pub point_of_no_return: Option<usize>,
    /// First timestep where the goal is reached. None if never reached.
    pub goal_reached_at: Option<usize>,
    /// The optimal trajectory summary that maximizes the bottleneck Ω.
    pub recommended_path: Option<RecommendedPathSummary>,
    /// True if the state space was too large and an approximation was used.
    pub is_approximate: bool,
    pub verdict: String,
    pub recommendation: String,
    pub calculation_mode: ExecutionMode,
    /// The epistemic trust level of this simulation: High (Exact) to Low (Approximate).
    pub trust_level: TrustLevel,
    /// Mathematical error bounds for the current simulation (T21/T22).
    pub error_bounds: ErrorBounds,
    /// System-level alerts explaining architectural transitions or unsoundness.
    pub alerts: Vec<SystemAlert>,
    /// T17/T18: Aggregated intelligence across the entire simulation.
    pub sensitivity_report: Option<GlobalSensitivityReport>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub impossibility_proof: Option<ImpossibilityProof>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub pareto_analysis: Option<ParetoSummary>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub multi_agent_analysis: Option<MultiAgentSummary>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub dominance_frontier: Option<DominanceSummary>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub critical_decisions: Option<CriticalDecisionSummary>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub survival_policy: Option<SurvivalPolicySummary>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub dynamic_evolution: Option<DynamicEvolutionSummary>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub composition_analysis: Option<CompositionSummary>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub monotonicity_report: Option<MonotonicityReport>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub persistence_report: Option<PersistenceReport>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub collapse_rate_report: Option<CollapseRateReport>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub information_value_report: Option<InformationValueReport>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GlobalSensitivityReport {
    /// Variables most frequently responsible for optionality collapse.
    pub primary_culprits: HashMap<String, usize>,
    /// Average local thickness (τ) across the timeline.
    pub mean_thickness: f64,
    /// Maximum collapse rate (κ) encountered.
    pub peak_fragility: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecommendedPathSummary {
    pub states: Vec<String>,
    pub bottleneck_future_width: f64,
    pub total_cost: f64,
    pub reaches_goal: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ImpossibilityProof {
    pub omega_before: usize,
    pub omega_after: usize,
    pub collapse_step: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub closing_state: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub dominant_constraint: Option<String>,
    pub reproducible: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParetoSummary {
    pub resource_order: Vec<String>,
    pub budget: Vec<f64>,
    pub scalar_reducible: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub scalar_direction: Option<Vec<f64>>,
    pub reachable_states: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MultiAgentSummary {
    pub reports: Vec<MultiAgentReportSummary>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub competitive: Option<CompetitiveSummary>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MultiAgentReportSummary {
    pub agent_id: String,
    pub solo_optionality: usize,
    pub conditional_optionality: usize,
    pub optionality_loss: usize,
    pub interfering_agents: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompetitiveSummary {
    pub kappa_unperturbed: f64,
    pub kappa_competitive_bound: f64,
    pub adversarial_premium: f64,
    pub tau_star: f64,
    pub chebyshev_center: Vec<f64>,
    pub chebyshev_radius: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DominanceSummary {
    pub frontier_size: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub best_state: Option<String>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub best_cost: Option<f64>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub best_optionality: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CriticalDecisionSummary {
    pub epsilon: f64,
    pub current_entropy: f64,
    pub ranked_transitions: Vec<CriticalTransition>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CriticalTransition {
    pub state: String,
    pub kappa: f64,
    pub impact_ratio: f64,
    pub critical: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SurvivalPolicySummary {
    pub regime: String,
    pub recommended_posture: String,
    pub keep_centered: bool,
    pub diversify_actions: bool,
    pub add_resources: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DynamicEvolutionSummary {
    pub discovery_count: usize,
    pub total_new_states: usize,
    pub total_new_edges: usize,
    pub persistence_valid: bool,
    pub discovery_regret: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CompositionSummary {
    pub subsystem_names: Vec<String>,
    pub volume_product: f64,
    pub min_thickness: f64,
    pub coupling: f64,
    pub is_independent: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonotonicityReport {
    pub optionality_non_increasing: bool,
    pub monotonicity_violation_count: usize,
    pub phase_transition_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PersistenceReport {
    pub point_of_no_return_crossed: bool,
    pub collapse_is_persistent: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub collapsed_at: Option<usize>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CollapseRateReport {
    pub total_collapse_bits: f64,
    pub peak_kappa: f64,
    pub terminal_collapse: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct InformationValueReport {
    pub entropy_start: f64,
    pub entropy_end: f64,
    pub net_information_value: f64,
    pub path_independent: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimelineStep {
    pub t: usize,
    /// Total count of reachable states (Ω).
    pub future_width: usize,
    /// Local geometric safety margin (directional thickness τ).
    pub thickness: f64,
    /// Rate of optionality collapse per step (κ).
    pub risk_spike: f64,
    /// Fraction of goal conditions met at this time step (0.0 = none, 1.0 = all met).
    pub goal_distance: f64,
    /// True if this step belongs to the recommended optimal trajectory.
    pub is_on_recommended_path: bool,
    /// T17: Compressed global measure of remaining futures (log2 Ω).
    pub entropy: f64,
    /// T18: The variable name primarily responsible for collapsing optionality at this step.
    pub dominant_root_cause: Option<String>,
    /// Categorical state: "stable", "constrained", or "violation".
    pub status: String,
    /// T12: Number of active constraints at the current point.
    pub active_constraints: usize,
    /// T12: Effective local dimension of the feasible manifold.
    pub local_dimension: usize,
    /// T12: Whether the system crossed a dimensional phase boundary at this step.
    pub phase_transition: bool,
    /// T20.5: Minimum perturbation required to force collapse from the current point.
    pub minimum_collapse_perturbation: f64,
    /// T13: Forward directional margin before the next boundary impact.
    pub directional_margin: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulateRequest {
    pub schema: VibeSchema,
    pub budget: Option<f64>,
    /// Architecture Doctrine: Determines if strategic hard limits are enforced.
    #[serde(default = "default_capability")]
    pub capability: CapabilityMode,
}

fn default_capability() -> CapabilityMode {
    CapabilityMode::Full
}
