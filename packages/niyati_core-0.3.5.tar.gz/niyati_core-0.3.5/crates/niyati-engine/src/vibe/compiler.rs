use super::schema::*;
use crate::types::{State, StateId, StateSpace, Transition};
use serde_json::Value;
use std::collections::{HashMap, VecDeque};

pub struct ScenarioCompiler;

impl Default for ScenarioCompiler {
    fn default() -> Self {
        Self::new()
    }
}

impl ScenarioCompiler {
    pub fn new() -> Self {
        Self
    }

    /// Validate schema variable bounds and enforce 'Strategic Hard Limits' for Lite mode.
    /// Returns Err if any variable definition is invalid or architecture limits are breached.
    pub fn validate_schema(schema: &VibeSchema, capability: &CapabilityMode) -> Result<(), String> {
        // Enforce Strategic Hard Limits (Lite Mode)
        if *capability == CapabilityMode::Lite {
            if schema.variables.len() > 8 {
                return Err("Variable count (max 8) exceeded. Please upgrade to the Hosted API for high-dimensional scenarios.".to_string());
            }
            if schema.time.horizon > 24 {
                return Err("Simulation horizon (max 24) exceeded. Please upgrade to the Hosted API for long-range planning.".to_string());
            }
        }

        for (name, var) in &schema.variables {
            if let (Some(min), Some(max)) = (var.min, var.max) {
                if min >= max {
                    return Err(format!(
                        "Variable '{}': min ({}) must be < max ({})",
                        name, min, max
                    ));
                }
            }
            if var.discretization <= 0.0 {
                return Err(format!(
                    "Variable '{}': discretization must be > 0, got {}",
                    name, var.discretization
                ));
            }
        }

        // Validate Resources
        for (name, res) in &schema.resources {
            if let Some(max) = res.max {
                if res.min >= max {
                    return Err(format!(
                        "Resource '{}': min ({}) must be < max ({})",
                        name, res.min, max
                    ));
                }
            }
            if res.initial < res.min {
                return Err(format!(
                    "Resource '{}': initial value {} < min bound {}",
                    name, res.initial, res.min
                ));
            }
        }
        Ok(())
    }

    /// Complexity Oracle: Estimate the total state space complexity score.
    /// f(dimensions, discretization, horizon)
    pub fn estimate_complexity(schema: &VibeSchema) -> f64 {
        let mut potential_per_step = 1.0;
        for var in schema.variables.values() {
            if let (Some(min), Some(max)) = (var.min, var.max) {
                let range = max - min;
                let steps = (range / var.discretization).ceil();
                // We ensure steps is at least 1.0 to avoid zeroing the product
                potential_per_step *= steps.max(1.0);
            } else {
                // If a variable is unconstrained, it has high potential.
                // We use a heuristic of 100 steps for the initial estimate.
                potential_per_step *= 100.0;
            }
        }

        let dimensions = schema.variables.len() as f64;
        let horizon = schema.time.horizon as f64;

        // Multi-factor formula: (Potential Per Step) * Horizon * (1.0 + DIM_SCALING)
        // This penalizes high-dimensional systems even if discretization is coarse.
        potential_per_step * horizon * (1.0 + 0.2 * dimensions)
    }

    /// Compile a declarative VibeSchema into a formal StateSpace.
    pub fn compile(&self, schema: &VibeSchema) -> StateSpace {
        let mut space = StateSpace::new();
        let mut visited: HashMap<StateId, State> = HashMap::new();
        let mut queue = VecDeque::new();

        // 1. Initialize starting state
        let initial_attr = self.get_initial_attributes(schema);
        let start_id = self.hash_state(&initial_attr);
        let start_state = State {
            id: start_id.clone(),
            attributes: initial_attr,
        };

        space.add_state(start_state.clone());
        visited.insert(start_id.clone(), start_state.clone());
        queue.push_back(start_id);

        // 2. Expand state space
        while let Some(current_id) = queue.pop_front() {
            let current_state = visited.get(&current_id).unwrap().clone();

            // Check if current state violates any HARD constraints
            if self.violates_constraints(&current_state, schema) {
                continue;
            }

            // Apply each action
            for action in &schema.actions {
                // Check preconditions (now supports AND-joined conditions)
                if !self.check_preconditions(&current_state.attributes, &action.preconditions) {
                    continue;
                }

                // Action Step: Apply effects simultaneously
                let action_attr =
                    self.apply_effects(&current_state.attributes, &action.effects, schema);

                // Drift Step: Apply recurring/triggered transitions in priority order
                let final_attr = self.apply_transitions(&action_attr, schema);

                // Grid Snapping (Discretization) — also clamps to [min, max]
                let snapped_attr = self.snap_to_grid(final_attr, schema);

                let next_id = self.hash_state(&snapped_attr);
                // Unified cost resolution:
                // We use the first resource defined in the schema as the 'Primary' for graph weights,
                // but store all costs in metadata for future multi-objective analysis.
                let primary_resource = schema
                    .resources
                    .keys()
                    .next()
                    .cloned()
                    .unwrap_or_else(|| "default".to_string());
                let cost = action
                    .cost
                    .get(&primary_resource)
                    .cloned()
                    .or_else(|| action.cost.values().next().cloned())
                    .unwrap_or(0.0);

                let mut metadata = HashMap::new();
                for (res, val) in &action.cost {
                    metadata.insert(res.clone(), Value::from(*val));
                }

                space.add_transition(Transition {
                    from: current_id.clone(),
                    to: next_id.clone(),
                    cost,
                    metadata: Some(metadata),
                });

                if !visited.contains_key(&next_id) {
                    let next_state = State {
                        id: next_id.clone(),
                        attributes: snapped_attr,
                    };
                    space.add_state(next_state.clone());
                    visited.insert(next_id.clone(), next_state);

                    if visited.len() < 5000 {
                        queue.push_back(next_id);
                    }
                }
            }
        }

        space
    }

    pub fn get_initial_attributes(&self, schema: &VibeSchema) -> HashMap<String, Value> {
        let mut attr = HashMap::new();
        for (name, var) in &schema.variables {
            attr.insert(name.clone(), var.initial.clone());
        }
        attr
    }

    pub fn hash_state(&self, attr: &HashMap<String, Value>) -> StateId {
        let mut keys: Vec<_> = attr.keys().collect();
        keys.sort();
        let parts: Vec<_> = keys
            .iter()
            .map(|k| {
                let val = attr.get(*k).unwrap();
                if let Some(f) = val.as_f64() {
                    format!("{}:{:.4}", k, f)
                } else {
                    format!("{}:{}", k, val)
                }
            })
            .collect();
        parts.join("|")
    }

    /// Phase 24: Snap to grid AND clamp values to [min, max] bounds.
    fn snap_to_grid(
        &self,
        mut attr: HashMap<String, Value>,
        schema: &VibeSchema,
    ) -> HashMap<String, Value> {
        for (name, var) in &schema.variables {
            if let Some(val) = attr.get_mut(name) {
                if let Some(f) = val.as_f64() {
                    let snapped = (f / var.discretization).round() * var.discretization;
                    // Clamp to [min, max] if bounds are specified
                    let clamped = match (var.min, var.max) {
                        (Some(lo), Some(hi)) => snapped.max(lo).min(hi),
                        (Some(lo), None) => snapped.max(lo),
                        (None, Some(hi)) => snapped.min(hi),
                        (None, None) => snapped,
                    };
                    *val = serde_json::json!(clamped);
                }
            }
        }
        attr
    }

    fn apply_effects(
        &self,
        current: &HashMap<String, Value>,
        effects: &HashMap<String, Effect>,
        _schema: &VibeSchema,
    ) -> HashMap<String, Value> {
        let mut next = current.clone();
        for (var_name, effect) in effects {
            if let Some(val) = next.get_mut(var_name) {
                let current_f64 = current
                    .get(var_name)
                    .and_then(|v| v.as_f64())
                    .unwrap_or(0.0);
                let effect_f64 = match &effect.value {
                    EffectValue::Number(n) => *n,
                    EffectValue::Variable(ref_var) => {
                        current.get(ref_var).and_then(|v| v.as_f64()).unwrap_or(0.0)
                    }
                };

                let result = match effect.op {
                    EffectOp::Add => current_f64 + effect_f64,
                    EffectOp::Set => effect_f64,
                    EffectOp::Multiply => current_f64 * effect_f64,
                    EffectOp::Decrement => current_f64 - effect_f64,
                    EffectOp::Affine => current_f64,
                };

                *val = serde_json::json!(result);
            }
        }
        next
    }

    fn apply_transitions(
        &self,
        current: &HashMap<String, Value>,
        schema: &VibeSchema,
    ) -> HashMap<String, Value> {
        let mut next = current.clone();
        let mut sorted_transitions = schema.transitions.clone();
        // Deterministic order: Priority then Lexicographical Name
        sorted_transitions.sort_by(|a, b| {
            a.priority
                .cmp(&b.priority)
                .then_with(|| a.name.cmp(&b.name))
        });

        for trans in sorted_transitions {
            let should_apply = match trans.r#type {
                TransitionType::Recurring => true,
                TransitionType::Triggered => {
                    self.eval_condition(&next, trans.condition.as_deref().unwrap_or("false"))
                }
            };

            if should_apply {
                next = self.apply_effects(&next, &trans.effects, schema);
            }
        }
        next
    }

    fn violates_constraints(&self, state: &State, schema: &VibeSchema) -> bool {
        for constraint in &schema.constraints {
            if constraint.mode == ConstraintMode::Soft {
                continue;
            }

            if let Some(val) = state
                .attributes
                .get(&constraint.variable)
                .and_then(|v| v.as_f64())
            {
                let limit = constraint.value.unwrap_or(0.0);
                let op = constraint.operator.as_ref().unwrap_or(&Operator::Gte);

                let ok = match constraint.r#type {
                    ConstraintType::NonNegative => val >= 0.0,
                    ConstraintType::Threshold => match op {
                        Operator::Eq => (val - limit).abs() < 1e-6,
                        Operator::Gt => val > limit,
                        Operator::Lt => val < limit,
                        Operator::Gte => val >= limit,
                        Operator::Lte => val <= limit,
                    },
                    ConstraintType::ForbiddenZone => val != limit,
                };

                if !ok {
                    return true;
                }
            }
        }
        false
    }

    /// Phase 25: Extended precondition checker — supports AND-joined conditions.
    /// Conditions joined by "&&" are split and all must be true.
    fn check_preconditions(
        &self,
        attr: &HashMap<String, Value>,
        pre: &Option<Vec<String>>,
    ) -> bool {
        if let Some(conds) = pre {
            for cond in conds {
                // Support AND-joined conditions: "A >= 10 && B < 5"
                let sub_conditions: Vec<&str> = cond.split("&&").collect();
                for sub in sub_conditions {
                    if !self.eval_condition(attr, sub.trim()) {
                        return false;
                    }
                }
            }
        }
        true
    }

    /// Minimal expression evaluator for "var op num"
    fn eval_condition(&self, attr: &HashMap<String, Value>, cond: &str) -> bool {
        let parts: Vec<&str> = cond.split_whitespace().collect();
        if parts.len() == 3 {
            let var_val = attr.get(parts[0]).and_then(|v| v.as_f64()).unwrap_or(0.0);
            let op = parts[1];
            let target = parts[2].parse::<f64>().unwrap_or(0.0);

            return match op {
                ">" => var_val > target,
                "<" => var_val < target,
                ">=" => var_val >= target,
                "<=" => var_val <= target,
                "==" => (var_val - target).abs() < 1e-6,
                _ => false,
            };
        }
        // Single token "false" or "true"
        match cond {
            "true" => true,
            "false" => false,
            _ => false, // SECURITY: Unknown conditions must default to FAIL
        }
    }

    /// Compute fraction of goal conditions currently met (0.0 = none, 1.0 = all).
    pub fn goal_progress(&self, attr: &HashMap<String, Value>, schema: &VibeSchema) -> f64 {
        let total = schema.goal.conditions.len();
        if total == 0 {
            return 1.0;
        }

        let met = schema
            .goal
            .conditions
            .iter()
            .filter(|condition| {
                if let Some(val) = attr.get(&condition.variable).and_then(|v| v.as_f64()) {
                    match condition.operator {
                        Operator::Eq => (val - condition.value).abs() < 1e-6,
                        Operator::Gt => val > condition.value,
                        Operator::Lt => val < condition.value,
                        Operator::Gte => val >= condition.value,
                        Operator::Lte => val <= condition.value,
                    }
                } else {
                    false
                }
            })
            .count();

        met as f64 / total as f64
    }

    pub fn is_goal_reached(&self, state: &State, schema: &VibeSchema) -> bool {
        for condition in &schema.goal.conditions {
            if let Some(val) = state
                .attributes
                .get(&condition.variable)
                .and_then(|v| v.as_f64())
            {
                let ok = match condition.operator {
                    Operator::Eq => (val - condition.value).abs() < 1e-6,
                    Operator::Gt => val > condition.value,
                    Operator::Lt => val < condition.value,
                    Operator::Gte => val >= condition.value,
                    Operator::Lte => val <= condition.value,
                };
                if !ok {
                    return false;
                }
            } else {
                return false;
            }
        }
        true
    }
}
