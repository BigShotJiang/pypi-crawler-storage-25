//! Theorem 15 & 16: Multi-Agent Reachability and Competitive Interaction
//!
//! T15: When multiple agents share a constraint space, each agent's reachable
//!      set depends on what other agents have consumed. Adding agents can only
//!      shrink individual reachability (interference monotonicity).
//!
//! T16: When agents are adversarial, the attacker amplifies the defender's
//!      collapse rate by targeting the direction of minimum thickness.
//!      The defender's optimal strategy is the Chebyshev center.

use crate::geometry::{Polytope, Vector};
use crate::reachability::core::ReachabilityEngine;
use crate::types::*;
use std::collections::HashSet;

/// State of a single agent in the shared space.
#[derive(Debug, Clone)]
pub struct AgentState {
    pub id: String,
    pub position: StateId,
    pub budget: Budget,
    /// States consumed/blocked by this agent (unavailable to others)
    pub consumed_states: HashSet<StateId>,
}

/// T15.1: Report on how other agents interfere with agent i's reachability.
#[derive(Debug, Clone)]
pub struct InterferenceReport {
    /// Agent being analyzed
    pub agent_id: String,
    /// Optionality without interference (solo)
    pub solo_optionality: usize,
    /// Optionality with all other agents present
    pub conditional_optionality: usize,
    /// How much optionality was lost due to interference
    pub optionality_loss: usize,
    /// Which agents caused the interference
    pub interfering_agents: Vec<String>,
}

/// T16.1: Competitive collapse analysis between attacker and defender.
#[derive(Debug, Clone)]
pub struct CompetitiveAnalysis {
    /// Unperturbed collapse rate of the defender
    pub kappa_unperturbed: f64,
    /// T16.1: Upper bound on competitive collapse rate
    pub kappa_competitive_bound: f64,
    /// Adversarial premium: ||a|| / τ*
    pub adversarial_premium: f64,
    /// Defender's effective thickness
    pub tau_star: f64,
}

/// Theorem 15 & 16: Multi-Agent Engine
pub struct MultiAgentEngine {
    shared_space: StateSpace,
    agents: Vec<AgentState>,
}

impl MultiAgentEngine {
    pub fn new(shared_space: StateSpace) -> Self {
        Self {
            shared_space,
            agents: Vec::new(),
        }
    }

    pub fn add_agent(&mut self, agent: AgentState) {
        self.agents.push(agent);
    }

    pub fn agent_count(&self) -> usize {
        self.agents.len()
    }

    /// Build a reduced state space for agent `agent_id` that excludes
    /// states consumed by all other agents.
    fn conditional_space(&self, agent_id: usize) -> StateSpace {
        // Collect all states consumed by OTHER agents
        let blocked: HashSet<StateId> = self
            .agents
            .iter()
            .enumerate()
            .filter(|(i, _)| *i != agent_id)
            .flat_map(|(_, a)| a.consumed_states.iter().cloned())
            .collect();

        // Build reduced state space
        let mut reduced = StateSpace::new();

        for (id, state) in &self.shared_space.states {
            if !blocked.contains(id) {
                reduced.add_state(state.clone());
            }
        }

        for transition in &self.shared_space.transitions {
            if !blocked.contains(&transition.from) && !blocked.contains(&transition.to) {
                reduced.add_transition(transition.clone());
            }
        }

        reduced
    }

    /// T15: Compute the conditional reachable set for agent `agent_id`
    /// given the current states of all other agents.
    pub fn conditional_reachable_set(
        &self,
        agent_id: usize,
    ) -> Option<crate::reachability::core::ReachableSet> {
        if agent_id >= self.agents.len() {
            return None;
        }

        let agent = &self.agents[agent_id];
        let space = self.conditional_space(agent_id);
        let engine = ReachabilityEngine::new(space);
        Some(engine.compute_reachable_set(&agent.position, agent.budget))
    }

    /// T15.1: Detect interference — how much has agent_id's reachability
    /// been shrunk by other agents consuming shared resources.
    pub fn detect_interference(&self, agent_id: usize) -> Option<InterferenceReport> {
        if agent_id >= self.agents.len() {
            return None;
        }

        let agent = &self.agents[agent_id];

        // Solo reachability (no other agents)
        let solo_engine = ReachabilityEngine::new(self.shared_space.clone());
        let solo_reachable = solo_engine.compute_reachable_set(&agent.position, agent.budget);
        let solo_opt = solo_reachable.optionality();

        // Conditional reachability (with other agents)
        let cond_reachable = self.conditional_reachable_set(agent_id)?;
        let cond_opt = cond_reachable.optionality();

        let interfering: Vec<String> = self
            .agents
            .iter()
            .enumerate()
            .filter(|(i, a)| *i != agent_id && !a.consumed_states.is_empty())
            .map(|(_, a)| a.id.clone())
            .collect();

        Some(InterferenceReport {
            agent_id: agent.id.clone(),
            solo_optionality: solo_opt,
            conditional_optionality: cond_opt,
            optionality_loss: solo_opt.saturating_sub(cond_opt),
            interfering_agents: interfering,
        })
    }

    /// T16.1: Compute competitive collapse rate upper bound.
    ///
    /// κ_competitive ≤ κ_unperturbed + ||a|| / τ*
    ///
    /// The attacker amplifies the defender's fragility by targeting
    /// the direction of minimum thickness.
    pub fn competitive_analysis(
        polytope: &Polytope,
        defender_position: &Vector,
        defender_action: &Vector,
        attacker_strength: f64,
    ) -> CompetitiveAnalysis {
        let kappa_unperturbed = polytope.predict_kappa_spike(defender_position, defender_action);

        let tau_star = polytope.estimate_directional_thickness(defender_position, defender_action);

        let adversarial_premium = if tau_star > 1e-10 {
            attacker_strength / tau_star
        } else {
            f64::INFINITY
        };

        let kappa_competitive_bound =
            if kappa_unperturbed.is_finite() && adversarial_premium.is_finite() {
                kappa_unperturbed + adversarial_premium
            } else {
                f64::INFINITY
            };

        CompetitiveAnalysis {
            kappa_unperturbed,
            kappa_competitive_bound,
            adversarial_premium,
            tau_star,
        }
    }

    /// T16.2: Find the Chebyshev center — the point that maximizes
    /// minimum distance to any constraint boundary.
    ///
    /// For axis-aligned box constraints, this is simply the midpoint
    /// of each dimension's bounds.
    pub fn chebyshev_center(polytope: &Polytope) -> (Vector, f64) {
        // For general polytopes, the Chebyshev center is an LP.
        // For axis-aligned constraints detected here, we compute analytically.
        let n = if polytope.constraints.is_empty() {
            return (Vector(vec![]), 0.0);
        } else {
            polytope.constraints[0].normal.dim()
        };

        // Find bounds per dimension from constraints of the form ±e_i · x ≤ b
        let mut lower = vec![f64::NEG_INFINITY; n];
        let mut upper = vec![f64::INFINITY; n];

        for plane in &polytope.constraints {
            let normal = &plane.normal.0;
            // Check if this is an axis-aligned constraint
            let nonzero_count = normal.iter().filter(|&&v| v.abs() > 1e-10).count();
            if nonzero_count == 1 {
                let (dim, &val) = normal
                    .iter()
                    .enumerate()
                    .find(|(_, &v)| v.abs() > 1e-10)
                    .unwrap();
                if val > 0.0 {
                    // x_dim ≤ b/val
                    upper[dim] = upper[dim].min(plane.bound / val);
                } else {
                    // x_dim ≥ -b/|val| → lower bound
                    lower[dim] = lower[dim].max(-plane.bound / val.abs());
                }
            }
        }

        // Center = midpoint of each dimension
        let center: Vec<f64> = lower
            .iter()
            .zip(upper.iter())
            .map(|(&lo, &up)| {
                if lo.is_finite() && up.is_finite() {
                    (lo + up) / 2.0
                } else {
                    0.0
                }
            })
            .collect();

        // Radius = minimum half-width
        let radius = lower
            .iter()
            .zip(upper.iter())
            .filter(|(lo, up)| lo.is_finite() && up.is_finite())
            .map(|(&lo, &up)| (up - lo) / 2.0)
            .fold(f64::INFINITY, f64::min);

        (
            Vector(center),
            if radius.is_finite() { radius } else { 0.0 },
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::{State, Transition};

    fn shared_supply_chain() -> StateSpace {
        let mut space = StateSpace::new();
        for id in [
            "warehouse",
            "supplier_a",
            "supplier_b",
            "supplier_c",
            "destination",
        ] {
            space.add_state(State {
                id: id.into(),
                attributes: Default::default(),
            });
        }
        space.add_transition(Transition {
            from: "warehouse".into(),
            to: "supplier_a".into(),
            cost: 3.0,
            metadata: None,
        });
        space.add_transition(Transition {
            from: "warehouse".into(),
            to: "supplier_b".into(),
            cost: 4.0,
            metadata: None,
        });
        space.add_transition(Transition {
            from: "warehouse".into(),
            to: "supplier_c".into(),
            cost: 5.0,
            metadata: None,
        });
        space.add_transition(Transition {
            from: "supplier_a".into(),
            to: "destination".into(),
            cost: 2.0,
            metadata: None,
        });
        space.add_transition(Transition {
            from: "supplier_b".into(),
            to: "destination".into(),
            cost: 2.0,
            metadata: None,
        });
        space.add_transition(Transition {
            from: "supplier_c".into(),
            to: "destination".into(),
            cost: 2.0,
            metadata: None,
        });
        space
    }

    #[test]
    fn t15_interference_monotonicity() {
        let space = shared_supply_chain();
        let mut engine = MultiAgentEngine::new(space);

        // Agent 0: starts at warehouse, budget 10
        engine.add_agent(AgentState {
            id: "agent_0".into(),
            position: "warehouse".into(),
            budget: 10.0,
            consumed_states: HashSet::new(), // no resources consumed yet
        });

        // Solo: agent 0 can reach everything
        let report_solo = engine.detect_interference(0).unwrap();
        let solo_opt = report_solo.solo_optionality;

        // Now agent 1 consumes supplier_a
        engine.add_agent(AgentState {
            id: "agent_1".into(),
            position: "supplier_a".into(),
            budget: 5.0,
            consumed_states: ["supplier_a".into()].into(),
        });

        let report_with_1 = engine.detect_interference(0).unwrap();
        assert!(
            report_with_1.conditional_optionality <= solo_opt,
            "T15.1: Adding agent must not increase optionality"
        );

        // Agent 2 consumes supplier_b
        engine.add_agent(AgentState {
            id: "agent_2".into(),
            position: "supplier_b".into(),
            budget: 5.0,
            consumed_states: ["supplier_b".into()].into(),
        });

        let report_with_2 = engine.detect_interference(0).unwrap();
        assert!(
            report_with_2.conditional_optionality <= report_with_1.conditional_optionality,
            "T15.1: More agents must further shrink or maintain optionality"
        );
    }

    #[test]
    fn t16_competitive_kappa_bound() {
        let mut p = Polytope::new();
        p.add_constraint(Vector(vec![1.0, 0.0]), 10.0);
        p.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
        p.add_constraint(Vector(vec![0.0, 1.0]), 2.0);
        p.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

        let defender_pos = Vector(vec![5.0, 1.0]);
        let action = Vector(vec![1.0, 0.0]);

        let analysis = MultiAgentEngine::competitive_analysis(&p, &defender_pos, &action, 0.5);

        assert!(
            analysis.kappa_competitive_bound > analysis.kappa_unperturbed,
            "Adversary must increase collapse rate"
        );
        assert!(analysis.adversarial_premium > 0.0);
    }

    #[test]
    fn t16_chebyshev_center() {
        let mut p = Polytope::new();
        // Box [0, 10] × [0, 6]
        p.add_constraint(Vector(vec![1.0, 0.0]), 10.0);
        p.add_constraint(Vector(vec![-1.0, 0.0]), 0.0);
        p.add_constraint(Vector(vec![0.0, 1.0]), 6.0);
        p.add_constraint(Vector(vec![0.0, -1.0]), 0.0);

        let (center, radius) = MultiAgentEngine::chebyshev_center(&p);

        assert_eq!(center.0, vec![5.0, 3.0], "Center of [0,10]×[0,6] = (5,3)");
        assert_eq!(radius, 3.0, "Inscribed ball radius = 3 (min half-width)");
    }
}
