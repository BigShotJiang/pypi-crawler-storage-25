//! Theorem 27 & 28: Dominance Pruning and Trajectory Optimality
//!
//! T27: Dominance-based pruning of the search frontier (soundness + completeness).
//! T28: Max-bottleneck trajectory computation via Bellman recursion.
//!
//! These form the top of the theorem stack — T28 consumes every preceding theorem.

use crate::types::*;
use std::cmp::Ordering;
use std::collections::{BinaryHeap, HashMap, HashSet};

// ============================================================================
// THEOREM 27: Dominance Pruning
// ============================================================================

/// A single entry in the dominance frontier.
#[derive(Debug, Clone)]
pub struct FrontierEntry {
    pub state: StateId,
    pub cost: f64,
    pub optionality: f64,
}

/// Theorem 27: The non-dominated frontier over (cost, optionality).
///
/// Maintains a Pareto-optimal set where no entry is dominated.
/// State s' dominates s iff cost(s') ≤ cost(s) AND opt(s') ≥ opt(s)
/// with at least one strict inequality.
#[derive(Debug, Clone)]
pub struct DominanceFrontier {
    entries: Vec<FrontierEntry>,
}

impl DominanceFrontier {
    pub fn new() -> Self {
        Self {
            entries: Vec::new(),
        }
    }

    /// T27.1 (Pruning Soundness): Insert a state into the frontier.
    ///
    /// Returns true if the state was added (not dominated).
    /// Removes any existing entries that the new state dominates.
    pub fn insert(&mut self, state: StateId, cost: f64, optionality: f64) -> bool {
        // Check if the new entry is dominated by any existing entry
        for entry in &self.entries {
            if entry.cost <= cost
                && entry.optionality >= optionality
                && (entry.cost < cost || entry.optionality > optionality)
            {
                return false; // Dominated — don't add
            }
        }

        // Remove entries dominated by the new state
        self.entries.retain(|e| {
            !(cost <= e.cost
                && optionality >= e.optionality
                && (cost < e.cost || optionality > e.optionality))
        });

        self.entries.push(FrontierEntry {
            state,
            cost,
            optionality,
        });
        true
    }

    /// T27.2: Frontier size bound — |F| ≤ min(|S|, B/c_min)
    pub fn size(&self) -> usize {
        self.entries.len()
    }

    /// Get the entry with the highest optionality (the best candidate)
    pub fn best(&self) -> Option<&FrontierEntry> {
        self.entries.iter().max_by(|a, b| {
            a.optionality
                .partial_cmp(&b.optionality)
                .unwrap_or(Ordering::Equal)
        })
    }

    /// Get all frontier entries (for inspection)
    pub fn entries(&self) -> &[FrontierEntry] {
        &self.entries
    }
}

impl Default for DominanceFrontier {
    fn default() -> Self {
        Self::new()
    }
}

// ============================================================================
// THEOREM 28: Trajectory Optimality (Max-Bottleneck Path)
// ============================================================================

/// Result of the max-bottleneck trajectory computation.
#[derive(Debug, Clone)]
pub struct OptimalTrajectory {
    /// The optimal path (sequence of states)
    pub path: Vec<StateId>,
    /// The bottleneck optionality along the path
    pub bottleneck_optionality: f64,
    /// Total path cost
    pub total_cost: f64,
    /// Whether the path reaches a target
    pub reaches_target: bool,
}

/// Internal node for the max-bottleneck priority queue
#[derive(Debug, Clone)]
struct BottleneckNode {
    state: StateId,
    bottleneck: f64, // minimum optionality seen so far on this path
    cost: f64,       // total cost so far
}

impl PartialEq for BottleneckNode {
    fn eq(&self, other: &Self) -> bool {
        self.bottleneck == other.bottleneck
    }
}
impl Eq for BottleneckNode {}
impl Ord for BottleneckNode {
    fn cmp(&self, other: &Self) -> Ordering {
        // Max-heap on bottleneck (highest bottleneck first)
        self.bottleneck
            .partial_cmp(&other.bottleneck)
            .unwrap_or(Ordering::Equal)
    }
}
impl PartialOrd for BottleneckNode {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

/// Theorem 28: Optionality-Optimal Trajectory Engine
///
/// Computes the max-bottleneck path through the state space:
/// π* = argmax_π min_{t ∈ π} Ω(s(t))
///
/// This is the modified Dijkstra that maximizes the minimum
/// optionality along the entire path rather than minimizing cost.
pub struct OptimalTrajectoryEngine;

impl OptimalTrajectoryEngine {
    /// T28.1 + T28.2: Compute the optionality-optimal trajectory.
    ///
    /// Uses a modified Dijkstra's algorithm where the priority is the
    /// *bottleneck* (minimum optionality along the path so far), and
    /// we maximize it rather than minimizing cost.
    ///
    /// # Algorithm (Bellman Recursion, T28.2)
    /// ```text
    /// Ω*(s, B, t) = max_{(s,s')∈T} min(Ω(s,B,t), Ω*(s',B-c,t+1))
    /// ```
    ///
    /// # Arguments
    /// * `space` - The state space graph
    /// * `start` - Starting state
    /// * `targets` - Set of goal states
    /// * `budget` - Maximum total cost
    /// * `optionality_fn` - Function that returns Ω for each state
    pub fn max_bottleneck_path<F>(
        space: &StateSpace,
        start: &StateId,
        targets: &HashSet<StateId>,
        budget: Budget,
        optionality_fn: F,
    ) -> OptimalTrajectory
    where
        F: Fn(&StateId) -> f64,
    {
        let graph = space.build_graph();

        // best_bottleneck[s] = highest bottleneck found reaching s
        let mut best_bottleneck: HashMap<StateId, f64> = HashMap::new();
        // predecessor[s] = (prev_state, cost_to_s)
        let mut predecessor: HashMap<StateId, (StateId, f64)> = HashMap::new();

        let start_omega = optionality_fn(start);

        let mut heap = BinaryHeap::new();
        heap.push(BottleneckNode {
            state: start.clone(),
            bottleneck: start_omega,
            cost: 0.0,
        });
        best_bottleneck.insert(start.clone(), start_omega);

        let mut best_target: Option<(StateId, f64)> = None;

        while let Some(node) = heap.pop() {
            // If we've found a better bottleneck to this state already, skip
            if let Some(&known) = best_bottleneck.get(&node.state) {
                if node.bottleneck < known {
                    continue;
                }
            }

            // Check if this is a target
            if targets.contains(&node.state) {
                match &best_target {
                    None => {
                        best_target = Some((node.state.clone(), node.bottleneck));
                    }
                    Some((_, best_bn)) if node.bottleneck > *best_bn => {
                        best_target = Some((node.state.clone(), node.bottleneck));
                    }
                    _ => {}
                }
            }

            // Expand successors
            if let Some(neighbors) = graph.get(&node.state) {
                for (next_state, edge_cost) in neighbors {
                    let new_cost = node.cost + edge_cost;
                    if new_cost > budget {
                        continue; // Budget exceeded
                    }

                    // T28.2 Bellman: bottleneck = min(current_bottleneck, Ω(next))
                    let next_omega = optionality_fn(next_state);
                    let new_bottleneck = node.bottleneck.min(next_omega);

                    // Only explore if this gives a better bottleneck
                    let current_best = best_bottleneck
                        .get(next_state)
                        .copied()
                        .unwrap_or(f64::NEG_INFINITY);

                    if new_bottleneck > current_best {
                        best_bottleneck.insert(next_state.clone(), new_bottleneck);
                        predecessor.insert(next_state.clone(), (node.state.clone(), new_cost));

                        heap.push(BottleneckNode {
                            state: next_state.clone(),
                            bottleneck: new_bottleneck,
                            cost: new_cost,
                        });
                    }
                }
            }
        }

        // Reconstruct path
        match best_target {
            Some((target, bottleneck)) => {
                let mut path = vec![target.clone()];
                let mut current = target;
                let mut total_cost = 0.0;

                while let Some((prev, cost)) = predecessor.get(&current) {
                    total_cost = *cost;
                    path.push(prev.clone());
                    if prev == start {
                        break;
                    }
                    current = prev.clone();
                }

                path.reverse();

                OptimalTrajectory {
                    path,
                    bottleneck_optionality: bottleneck,
                    total_cost,
                    reaches_target: true,
                }
            }
            None => OptimalTrajectory {
                path: vec![start.clone()],
                bottleneck_optionality: start_omega,
                total_cost: 0.0,
                reaches_target: false,
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::{State, Transition};

    fn build_test_graph() -> StateSpace {
        let mut space = StateSpace::new();
        // Graph:
        //   A --5--> B --3--> D (target)
        //   A --2--> C --6--> D (target)
        //
        // Optionality: A=100, B=30, C=70, D=50
        //
        // Path A→B→D: bottleneck = min(100, 30, 50) = 30, cost = 8
        // Path A→C→D: bottleneck = min(100, 70, 50) = 50, cost = 8
        // Optimal: A→C→D (bottleneck 50 > 30)

        for id in ["A", "B", "C", "D"] {
            space.add_state(State {
                id: id.into(),
                attributes: Default::default(),
            });
        }
        space.add_transition(Transition {
            from: "A".into(),
            to: "B".into(),
            cost: 5.0,
            metadata: None,
        });
        space.add_transition(Transition {
            from: "A".into(),
            to: "C".into(),
            cost: 2.0,
            metadata: None,
        });
        space.add_transition(Transition {
            from: "B".into(),
            to: "D".into(),
            cost: 3.0,
            metadata: None,
        });
        space.add_transition(Transition {
            from: "C".into(),
            to: "D".into(),
            cost: 6.0,
            metadata: None,
        });
        space
    }

    fn test_optionality(state: &StateId) -> f64 {
        match state.as_str() {
            "A" => 100.0,
            "B" => 30.0,
            "C" => 70.0,
            "D" => 50.0,
            _ => 0.0,
        }
    }

    #[test]
    fn t27_dominance_pruning() {
        let mut frontier = DominanceFrontier::new();

        // (5, 80) — not dominated
        assert!(frontier.insert("A".into(), 5.0, 80.0));
        // (7, 60) — dominated by (5, 80)
        assert!(!frontier.insert("B".into(), 7.0, 60.0));
        // (3, 50) — not dominated (cheaper, lower opt)
        assert!(frontier.insert("C".into(), 3.0, 50.0));

        assert_eq!(frontier.size(), 2);
    }

    #[test]
    fn t27_dominant_entry_removes_others() {
        let mut frontier = DominanceFrontier::new();
        frontier.insert("A".into(), 5.0, 80.0);
        frontier.insert("B".into(), 3.0, 50.0);
        assert_eq!(frontier.size(), 2);

        // (2, 90) dominates both
        frontier.insert("C".into(), 2.0, 90.0);
        assert_eq!(frontier.size(), 1);
        assert_eq!(frontier.best().unwrap().state, "C");
    }

    #[test]
    fn t28_max_bottleneck_selects_wider_path() {
        let space = build_test_graph();
        let targets: HashSet<StateId> = ["D".into()].into();

        let trajectory = OptimalTrajectoryEngine::max_bottleneck_path(
            &space,
            &"A".into(),
            &targets,
            100.0,
            test_optionality,
        );

        assert!(trajectory.reaches_target);
        // Should choose A→C→D (bottleneck 50) over A→B→D (bottleneck 30)
        assert_eq!(trajectory.bottleneck_optionality, 50.0);
        assert_eq!(trajectory.path, vec!["A", "C", "D"]);
    }

    #[test]
    fn t28_budget_constraint_respected() {
        let space = build_test_graph();
        let targets: HashSet<StateId> = ["D".into()].into();

        // Budget = 7: only A→B→D is feasible (cost 8 > 7, A→C→D cost 8 > 7)
        // Actually both paths cost 8, so neither is reachable
        let trajectory = OptimalTrajectoryEngine::max_bottleneck_path(
            &space,
            &"A".into(),
            &targets,
            7.0,
            test_optionality,
        );

        assert!(!trajectory.reaches_target);
    }

    #[test]
    fn t28_unreachable_target() {
        let space = build_test_graph();
        let targets: HashSet<StateId> = ["Z".into()].into(); // doesn't exist

        let trajectory = OptimalTrajectoryEngine::max_bottleneck_path(
            &space,
            &"A".into(),
            &targets,
            100.0,
            test_optionality,
        );

        assert!(!trajectory.reaches_target);
    }
}
