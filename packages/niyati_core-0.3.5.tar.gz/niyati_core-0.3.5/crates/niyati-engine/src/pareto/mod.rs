//! Theorem 25 & 26: Constraint Composition and Pareto Reachability
//!
//! T25: How independent/coupled constraint subsystems compose
//!      (volume factorization, fragility = min-thickness, coupling collapse rate).
//! T26: Reachability under multi-dimensional (vector) costs
//!      (Pareto polytope, componentwise budget, scalar reduction).

use crate::types::*;
use std::collections::HashMap;

// ============================================================================
// THEOREM 25: Constraint Composition
// ============================================================================

/// Analysis of how two constraint subsystems compose.
#[derive(Debug, Clone)]
pub struct CompositionAnalysis {
    /// T25.1: Vol(P1⊗P2) = Vol(P1) · Vol(P2) for independent constraints
    pub volume_product: f64,
    /// T25.2: τ*(P1⊗P2) = min(τ*(P1), τ*(P2))
    pub min_thickness: f64,
    /// T25.3: coupling term ρ ≥ 0 (0 iff independent)
    pub coupling: f64,
    /// Whether constraints are independent (product structure)
    pub is_independent: bool,
}

impl CompositionAnalysis {
    /// Theorem 25: Analyze how two subsystems compose.
    ///
    /// # Arguments
    /// * `vol_1`, `vol_2` - Volumes of the two subsystems
    /// * `tau_1`, `tau_2` - Effective thicknesses of the two subsystems  
    /// * `kappa_1`, `kappa_2` - Collapse rates of the two subsystems
    /// * `kappa_joint` - Joint collapse rate (if available)
    pub fn analyze(
        vol_1: f64,
        vol_2: f64,
        tau_1: f64,
        tau_2: f64,
        kappa_1: f64,
        kappa_2: f64,
        kappa_joint: Option<f64>,
    ) -> Self {
        // T25.1: Volume factorizes under independence
        let volume_product = vol_1 * vol_2;

        // T25.2: Fragility = min thickness
        let min_thickness = tau_1.min(tau_2);

        // T25.3: Coupling term ρ
        let coupling = match kappa_joint {
            Some(kj) => {
                let rho = kj - (kappa_1 + kappa_2);
                rho.max(0.0) // ρ ≥ 0 by sub-additivity
            }
            None => 0.0, // Assume independent if no joint data
        };

        let is_independent = coupling < 1e-10;

        Self {
            volume_product,
            min_thickness,
            coupling,
            is_independent,
        }
    }
}

// ============================================================================
// THEOREM 26: Pareto Reachability
// ============================================================================

/// A multi-dimensional budget constraint.
#[derive(Debug, Clone)]
pub struct VectorBudget(pub Vec<f64>);

impl VectorBudget {
    pub fn new(budgets: Vec<f64>) -> Self {
        Self(budgets)
    }

    pub fn dimension(&self) -> usize {
        self.0.len()
    }

    /// Check if a vector cost is within this budget (componentwise).
    pub fn can_afford(&self, cost: &[f64]) -> bool {
        self.0.iter().zip(cost.iter()).all(|(b, c)| c <= b)
    }

    /// Subtract a cost from this budget, returning the remaining budget.
    pub fn subtract(&self, cost: &[f64]) -> Option<VectorBudget> {
        if !self.can_afford(cost) {
            return None;
        }
        let remaining: Vec<f64> = self.0.iter().zip(cost.iter()).map(|(b, c)| b - c).collect();
        Some(VectorBudget(remaining))
    }
}

/// A transition with multi-dimensional cost.
#[derive(Debug, Clone)]
pub struct VectorTransition {
    pub from: StateId,
    pub to: StateId,
    pub costs: Vec<f64>, // cost in each dimension
}

/// Theorem 26: Pareto Reachability Engine
pub struct ParetoEngine;

impl ParetoEngine {
    /// T26.3: Check if cost vectors are collinear (scalar reducible).
    ///
    /// If all edge costs are proportional to a single weight vector w,
    /// the entire Pareto problem reduces to a scalar problem with
    /// B_scalar = min(B_j / w_j).
    pub fn check_scalar_reducibility(cost_vectors: &[Vec<f64>]) -> Option<Vec<f64>> {
        if cost_vectors.is_empty() || cost_vectors[0].is_empty() {
            return None;
        }

        let reference = &cost_vectors[0];
        let dim = reference.len();

        // Find the ratio for normalization
        let first_nonzero = reference.iter().position(|&x| x.abs() > 1e-10)?;
        let base_val = reference[first_nonzero];

        // Normalized direction vector
        let direction: Vec<f64> = reference.iter().map(|x| x / base_val).collect();

        // Check all other cost vectors for collinearity
        for costs in cost_vectors.iter().skip(1) {
            if costs.len() != dim {
                return None;
            }

            // Find the scalar multiple
            let nonzero = costs.iter().position(|&x| x.abs() > 1e-10);
            let scale = match nonzero {
                Some(idx) => costs[idx] / direction[idx],
                None => continue, // Zero vector is trivially collinear
            };

            // Verify all components match
            for (&ci, &di) in costs.iter().zip(direction.iter()) {
                let expected = scale * di;
                if (ci - expected).abs() > 1e-8 {
                    return None; // Not collinear
                }
            }
        }

        Some(direction)
    }

    /// T26.3: Compute the scalar budget for a reducible problem.
    pub fn scalar_budget(budget: &VectorBudget, direction: &[f64]) -> f64 {
        budget
            .0
            .iter()
            .zip(direction.iter())
            .filter(|(_, &d)| d.abs() > 1e-10)
            .map(|(&b, &d)| b / d)
            .fold(f64::INFINITY, f64::min)
    }

    /// T26.1+T26.2: Compute the Pareto-reachable set under vector budget.
    ///
    /// Uses modified Dijkstra with componentwise budget checking.
    /// States are reachable only if the path cost satisfies all budget
    /// dimensions simultaneously.
    pub fn pareto_reachable_set(
        _space: &StateSpace,
        transitions: &[VectorTransition],
        start: &StateId,
        budget: &VectorBudget,
    ) -> Vec<StateId> {
        let _dim = budget.dimension();

        // Build adjacency list with vector costs
        let mut graph: HashMap<StateId, Vec<(StateId, Vec<f64>)>> = HashMap::new();
        for t in transitions {
            graph
                .entry(t.from.clone())
                .or_default()
                .push((t.to.clone(), t.costs.clone()));
        }

        // BFS with componentwise budget tracking
        let mut reachable = Vec::new();
        let mut visited: HashMap<StateId, Vec<f64>> = HashMap::new();

        // (state, remaining_budget)
        let mut queue = vec![(start.clone(), budget.0.clone())];
        visited.insert(start.clone(), budget.0.clone());

        while let Some((state, remaining)) = queue.pop() {
            reachable.push(state.clone());

            if let Some(neighbors) = graph.get(&state) {
                for (next, costs) in neighbors {
                    // Check componentwise budget
                    let can_afford = remaining.iter().zip(costs.iter()).all(|(r, c)| c <= r);

                    if !can_afford {
                        continue;
                    }

                    let new_remaining: Vec<f64> = remaining
                        .iter()
                        .zip(costs.iter())
                        .map(|(r, c)| r - c)
                        .collect();

                    // Only visit if this gives strictly more budget in some dimension
                    let dominated = visited.get(next).is_some_and(|existing| {
                        existing
                            .iter()
                            .zip(new_remaining.iter())
                            .all(|(e, n)| e >= n)
                    });

                    if !dominated {
                        visited.insert(next.clone(), new_remaining.clone());
                        queue.push((next.clone(), new_remaining));
                    }
                }
            }
        }

        reachable.sort();
        reachable.dedup();
        reachable
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn t25_independent_composition() {
        let analysis = CompositionAnalysis::analyze(
            100.0,
            50.0, // volumes
            10.0,
            3.0, // thicknesses
            0.2,
            0.5,       // kappas
            Some(0.7), // joint kappa = sum → independent
        );
        assert_eq!(analysis.volume_product, 5000.0);
        assert_eq!(analysis.min_thickness, 3.0);
        assert!(analysis.is_independent);
        assert!(analysis.coupling < 1e-10);
    }

    #[test]
    fn t25_coupled_composition() {
        let analysis = CompositionAnalysis::analyze(
            100.0,
            50.0,
            10.0,
            3.0,
            0.2,
            0.5,
            Some(1.0), // joint kappa > sum → coupled
        );
        assert!(!analysis.is_independent);
        assert!((analysis.coupling - 0.3).abs() < 1e-10);
    }

    #[test]
    fn t26_scalar_reducibility_detected() {
        // All costs proportional to (1, 2)
        let costs = vec![vec![3.0, 6.0], vec![5.0, 10.0], vec![1.0, 2.0]];
        let direction = ParetoEngine::check_scalar_reducibility(&costs);
        assert!(direction.is_some());
    }

    #[test]
    fn t26_non_reducible_detected() {
        let costs = vec![
            vec![3.0, 6.0],
            vec![5.0, 7.0], // Not proportional to (3, 6)
        ];
        let direction = ParetoEngine::check_scalar_reducibility(&costs);
        assert!(direction.is_none());
    }

    #[test]
    fn t26_scalar_budget_computation() {
        let budget = VectorBudget::new(vec![10.0, 15.0]);
        let direction = vec![1.0, 2.0];
        let scalar = ParetoEngine::scalar_budget(&budget, &direction);
        assert_eq!(scalar, 7.5); // min(10/1, 15/2)
    }

    #[test]
    fn t26_pareto_reachable_set() {
        let space = StateSpace::new();
        let transitions = vec![
            VectorTransition {
                from: "A".into(),
                to: "B".into(),
                costs: vec![3.0, 2.0],
            },
            VectorTransition {
                from: "A".into(),
                to: "C".into(),
                costs: vec![8.0, 1.0],
            },
            VectorTransition {
                from: "B".into(),
                to: "D".into(),
                costs: vec![2.0, 5.0],
            },
        ];
        let budget = VectorBudget::new(vec![10.0, 10.0]);

        let reachable =
            ParetoEngine::pareto_reachable_set(&space, &transitions, &"A".into(), &budget);

        assert!(reachable.contains(&"A".into()));
        assert!(reachable.contains(&"B".into())); // cost (3,2) ≤ (10,10) ✓
        assert!(reachable.contains(&"C".into())); // cost (8,1) ≤ (10,10) ✓
        assert!(reachable.contains(&"D".into())); // A→B→D cost (5,7) ≤ (10,10) ✓
    }

    #[test]
    fn t26_vector_budget_enforcement() {
        let budget = VectorBudget::new(vec![5.0, 3.0]);
        assert!(budget.can_afford(&[3.0, 2.0]));
        assert!(!budget.can_afford(&[6.0, 1.0])); // Exceeds dim 1
        assert!(!budget.can_afford(&[1.0, 4.0])); // Exceeds dim 2
    }
}
