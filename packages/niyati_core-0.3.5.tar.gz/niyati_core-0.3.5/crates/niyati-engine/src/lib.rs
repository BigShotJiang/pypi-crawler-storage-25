//! Niyati: Mathematical infrastructure for computing reachable futures
//!
//! This library implements theorems from reachability theory to analyze
//! what states remain reachable under resource constraints.
//!
//! ## Theorem Stack (T1 → T28)
//! simulate() integrates: T1, T3, T6, T9, T13, T14, T24
//! Expert endpoints: T8, T15, T16, T25, T26, T27, T28

// Tier 1: Core foundations
pub mod dynamics;
pub mod enforcement;
pub mod information;
#[cfg(feature = "observer")]
pub mod observer;
pub mod reachability;
pub mod types;

// Tier 2: Geometric extensions
pub mod computability;
pub mod geometry;

// Tier 3: Advanced modules
pub mod approximation;
pub mod dominance;
pub mod multiagent;
pub mod pareto;
pub mod temporal;

use std::collections::HashMap;

// Compiler layer: Vibe Schema and contract surfaces
pub mod vibe;

use crate::approximation::polytope::MonteCarloVolumeEstimator;
use crate::approximation::PolytopeVolumeEstimator;
pub use vibe::{
    AlertSeverity, CapabilityMode, CollapseRateReport, CompetitiveSummary, CompositionSummary,
    CriticalDecisionSummary, CriticalTransition, DominanceSummary, DynamicEvolutionSummary,
    ErrorBounds, ExecutionMode, GlobalSensitivityReport, ImpossibilityProof,
    InformationValueReport, MonotonicityReport, MultiAgentReportSummary, MultiAgentSummary,
    ParetoSummary, PersistenceReport, RecommendedPathSummary, ScenarioCompiler, SimulateRequest,
    SimulationResult, SurvivalPolicySummary, SystemAlert, TimelineStep, TrustLevel, VibeSchema,
};

// Re-export main types for external crates
pub use dominance::{OptimalTrajectory, OptimalTrajectoryEngine};
pub use geometry::{ConstraintPlane, Polytope, Vector};
pub use multiagent::MultiAgentEngine;
pub use pareto::{CompositionAnalysis, ParetoEngine, VectorBudget};
pub use reachability::core::{ReachabilityEngine, ReachableSet};
pub use temporal::TemporalConsistencyChecker;
pub use types::{Cost, State, StateId, StateSpace, Transition};

/// The universal entry point for the Niyati developer platform.
///
/// ## Theorem Integration Chain
/// - **T1**: Dijkstra reachability — computes R_B(s₀) at each budget slice
/// - **T3/T6**: Collapse rate κ = log(Ω_t) − log(Ω_{t+1}) per step
/// - **T9**: Optionality Ω = |R_B(s₀)| — the raw count of reachable states
/// - **T13**: Directional distance δ_v(x) — how far from constraint boundary
/// - **T14**: Thickness τ(x) — corridor width orthogonal to motion (flexibility)
/// - **T24**: Temporal consistency — monotonicity + κ additivity verification
///
/// Phase 21: goal detection (goal_reached_at, goal_distance per step)
/// Phase 22: n-D polytope — each schema variable gets its own constraint axis
/// Phase 24: schema validation — bounds, discretization, initial value checks
pub fn simulate(
    schema: VibeSchema,
    budget: Option<f64>,
    capability: CapabilityMode,
) -> SimulationResult {
    use dynamics::collapse::{compute_collapse_rate, Optionality};
    use geometry::{Polytope, Vector};
    use information::critical_decisions::{entropy, evaluate_transition, rank_decisions};
    use temporal::TemporalConsistencyChecker;

    // ── Phase 24: Schema Validation (Capability Aware) ───────────────────────
    if let Err(e) = ScenarioCompiler::validate_schema(&schema, &capability) {
        // Return an impossible result with error embedded in recommendation
        return SimulationResult {
            timeline: vec![],
            point_of_no_return: Some(0),
            goal_reached_at: None,
            recommended_path: None,
            is_approximate: false,
            verdict: "invalid_schema".to_string(),
            recommendation: format!("Schema error: {}", e),
            calculation_mode: ExecutionMode::Discrete,
            trust_level: TrustLevel::High,
            error_bounds: ErrorBounds {
                epsilon: 0.0,
                confidence: 1.0,
            },
            alerts: vec![],
            sensitivity_report: None,
            impossibility_proof: None,
            pareto_analysis: None,
            multi_agent_analysis: None,
            dominance_frontier: None,
            critical_decisions: None,
            survival_policy: None,
            dynamic_evolution: None,
            composition_analysis: None,
            monotonicity_report: None,
            persistence_report: None,
            collapse_rate_report: None,
            information_value_report: None,
        };
    }

    // ── Phase 38: Complexity Oracle & Mode Selection ───────────────────────
    let potential = ScenarioCompiler::estimate_complexity(&schema);
    let base_mode = if potential < 5000.0 {
        ExecutionMode::Discrete
    } else if potential < 100000.0 {
        ExecutionMode::Hybrid
    } else {
        ExecutionMode::Continuous
    };

    // Enforcement: Lite mode refuses Discrete/Hybrid for complexity > 5000 (T21 mandatory)
    let calculation_mode = if capability == CapabilityMode::Lite && potential > 5000.0 {
        ExecutionMode::Continuous
    } else {
        base_mode
    };

    let (mut trust_level, mut error_bounds) = match calculation_mode {
        ExecutionMode::Discrete => (
            TrustLevel::High,
            ErrorBounds {
                epsilon: 0.0,
                confidence: 1.0,
            },
        ),
        ExecutionMode::Hybrid => (
            TrustLevel::Medium,
            ErrorBounds {
                epsilon: 0.05,
                confidence: 0.99,
            },
        ),
        ExecutionMode::Continuous => (
            TrustLevel::Low,
            ErrorBounds {
                epsilon: 0.15,
                confidence: 0.95,
            },
        ),
    };

    let is_approximate = calculation_mode == ExecutionMode::Continuous || potential > 1e6;

    let mut alerts = Vec::new();

    // ── Phase 39: Computability Audit (T20c) ──────────────────────────────────
    let mut has_negative_costs = false;
    for action in &schema.actions {
        for cost in action.cost.values() {
            if *cost < 0.0 {
                has_negative_costs = true;
                break;
            }
        }
        if has_negative_costs {
            break;
        }
    }

    let analysis = computability::ComputabilityAnalysis::analyze(
        Some(potential as usize),
        has_negative_costs,
        false, // Non-additive costs not yet modeled in schema
    );

    if !analysis.is_sound() {
        for violation in &analysis.assumption_violations {
            alerts.push(SystemAlert {
                code: "ASSUMPTION_VIOLATION".to_string(),
                severity: AlertSeverity::Critical,
                message: violation.assumption.clone(),
                detail: Some(violation.details.clone()),
                theorem: Some("T20c".to_string()),
                legacy_type: Some("unsound_system".to_string()),
            });
        }
    }

    if calculation_mode != ExecutionMode::Discrete {
        alerts.push(SystemAlert {
            code: "HIGH_COMPLEXITY".to_string(),
            severity: AlertSeverity::Info,
            message: "Performance Scaling Activated: Transitioning to geometric volume estimation (T21).".to_string(),
            detail: Some(format!(
                "Complexity score ({:.1}) exceeds discrete threshold (5000). Switched to {:?} mode to preserve strategic intelligence performance.",
                potential, calculation_mode
            )),
            theorem: Some("T21".to_string()),
            legacy_type: Some("high_complexity".to_string()),
        });
    }

    let compiler = ScenarioCompiler::new();
    let space = compiler.compile(&schema);

    let initial_attr = compiler.get_initial_attributes(&schema);
    let initial_state_id = compiler.hash_state(&initial_attr);

    // Resolve budget: explicit → resources["capital"] → ∞
    let resolved_budget = budget.unwrap_or_else(|| {
        schema
            .resources
            .values()
            .next() // Use first resource as primary budget anchor for now
            .map(|r| r.initial)
            .unwrap_or(f64::INFINITY)
    });

    let horizon = schema.time.horizon;

    // ── Phase 22: n-D Polytope — per-variable constraint planes ──────────────
    // Each variable gets a pair of axis-aligned planes: min and max bounds.
    // Schema constraints add additional planes on the corresponding variable axis.
    let var_names: Vec<&str> = {
        let mut names: Vec<&str> = schema.variables.keys().map(|s| s.as_str()).collect();
        names.sort(); // deterministic ordering
        names
    };
    let n_vars = var_names.len().max(1);

    let mut polytope = Polytope::new();

    // Build per-variable bound planes (axis-aligned)
    for (i, name) in var_names.iter().enumerate() {
        if let Some(var) = schema.variables.get(*name) {
            let mut lo_normal = vec![0.0; n_vars];
            let mut hi_normal = vec![0.0; n_vars];
            lo_normal[i] = -1.0; // -x_i ≤ -min ↔ x_i ≥ min
            hi_normal[i] = 1.0; //  x_i ≤ max

            let lo = var.min.unwrap_or(0.0);
            let hi = var.max.unwrap_or(1e6);
            polytope.add_constraint(Vector(lo_normal), -lo);
            polytope.add_constraint(Vector(hi_normal), hi);
        }
    }

    // Add schema constraints as additional planes on the variable's axis
    for constraint in &schema.constraints {
        if let Some(idx) = var_names
            .iter()
            .position(|&n| n == constraint.variable.as_str())
        {
            if let (Some(val), Some(op)) = (constraint.value, &constraint.operator) {
                use vibe::schema::Operator;
                let (sign, bound) = match op {
                    Operator::Lte | Operator::Lt => (1.0_f64, val),
                    Operator::Gte | Operator::Gt => (-1.0_f64, -val),
                    Operator::Eq => (1.0_f64, val),
                };
                let mut normal = vec![0.0; n_vars];
                normal[idx] = sign;
                polytope.add_constraint(Vector(normal), bound);
            }
        }
    }

    // Motion direction = uniform across all variable dimensions (normalized)
    let motion_dir = Vector(vec![1.0 / (n_vars as f64).sqrt(); n_vars]);
    // Center point at midpoint of variable ranges
    let center_vals: Vec<f64> = var_names
        .iter()
        .map(|name| {
            schema
                .variables
                .get(*name)
                .map(|v| {
                    let lo = v.min.unwrap_or(0.0);
                    let hi = v.max.unwrap_or(1.0);
                    (lo + hi) / 2.0
                })
                .unwrap_or(0.5)
        })
        .collect();
    let center_pt = Vector(center_vals);

    // ── T1: Compute reachable set at full budget ──────────────────────────────
    let engine = reachability::core::ReachabilityEngine::new(space.clone());
    let full_reachable = engine.compute_reachable_set(&initial_state_id, resolved_budget);
    let full_omega = full_reachable.optionality();

    // ── T24: Temporal consistency checker ─────────────────────────────────────
    let mut temporal = TemporalConsistencyChecker::new();

    // ── Phase 21: Goal detection setup ────────────────────────────────────────
    let mut goal_reached_at: Option<usize> = None;
    let initial_goal_progress = compiler.goal_progress(&initial_attr, &schema);

    // ── T14/T13: Pre-compute base thickness & risk for the polytope ───────────
    let base_thickness = polytope.estimate_directional_thickness(&center_pt, &motion_dir);
    let base_kappa_spike = polytope.predict_kappa_spike(&center_pt, &motion_dir);
    let base_directional_margin = polytope.directional_distance(&center_pt, &motion_dir);

    // ── T28: Compute Optimal Trajectory (Max-Bottleneck Path) ─────────────────
    // π* = argmax_π min_{t ∈ π} Ω(s(t))
    // This finds the path that stays in the "widest" part of the future.
    let reachable_states = &full_reachable.states;
    let mut target_states = std::collections::HashSet::new();
    for state_id in reachable_states {
        if let Some(state) = space.states.get(state_id) {
            if compiler.is_goal_reached(state, &schema) {
                target_states.insert(state_id.clone());
            }
        }
    }

    let optimal_trajectory = if !target_states.is_empty() && capability == CapabilityMode::Full {
        let traj = OptimalTrajectoryEngine::max_bottleneck_path(
            &space,
            &initial_state_id,
            &target_states,
            resolved_budget,
            |sid| {
                engine
                    .compute_reachable_set(sid, resolved_budget)
                    .optionality() as f64
            },
        );
        if traj.reaches_target {
            Some(traj)
        } else {
            None
        }
    } else {
        None
    };

    let recommended_path = optimal_trajectory
        .as_ref()
        .map(|traj| RecommendedPathSummary {
            states: traj.path.to_vec(),
            bottleneck_future_width: traj.bottleneck_optionality,
            total_cost: traj.total_cost,
            reaches_goal: traj.reaches_target,
        });

    // ── Phase 42: Continuous Estimator Setup (T21) ───────────────────────────
    let mut variable_bounds = HashMap::new();
    let mut discretization_factors = HashMap::new();
    for (name, var) in &schema.variables {
        let min = var.min.unwrap_or(0.0);
        let max = var
            .max
            .unwrap_or(vibe::schema::VariableType::Float.default_max()); // Use schema logic
        variable_bounds.insert(name.clone(), (min, max));
        discretization_factors.insert(name.clone(), var.discretization);
    }

    let continuous_estimator = if calculation_mode == ExecutionMode::Continuous {
        Some(MonteCarloVolumeEstimator::new(
            polytope.constraints.clone(),
            variable_bounds,
            discretization_factors,
        ))
    } else {
        None
    };

    // ── Timeline: compute per-step Ω, κ, τ, goal_distance ───────────────────
    let mut timeline = Vec::new();
    let mut point_of_no_return: Option<usize> = None;
    let mut prev_omega = full_omega as f64;
    let mut prev_active_constraints = 0usize;
    let mut culprit_freqs: HashMap<String, usize> = HashMap::new();
    let mut total_thickness: f64 = 0.0;
    let mut peak_fragility: f64 = 0.0;
    let mut collapse_state: Option<String> = None;

    for t in 0..=horizon {
        // T1: budget drains linearly over the horizon
        let budget_fraction = if horizon > 0 {
            t as f64 / horizon as f64
        } else {
            0.0
        };
        let step_budget = if resolved_budget.is_infinite() {
            f64::INFINITY
        } else {
            resolved_budget * (1.0 - budget_fraction)
        };

        let step_pos = if base_directional_margin.is_finite() && n_vars > 0 {
            let travel = base_directional_margin * budget_fraction.min(0.98);
            let coords = center_pt
                .0
                .iter()
                .zip(motion_dir.0.iter())
                .map(|(c, d)| c + d * travel)
                .collect();
            Vector(coords)
        } else {
            center_pt.clone()
        };

        // T9: Ω at this time step
        let (step_omega, step_bounds, step_trust) = if step_budget <= 0.0 {
            (
                0,
                ErrorBounds {
                    epsilon: 0.0,
                    confidence: 1.0,
                },
                TrustLevel::High,
            )
        } else if let Some(ref estimator) = continuous_estimator {
            // Continuous T21 Path
            let (omega, bounds, trust) = estimator.estimate_volume(10000);
            (omega as usize, bounds, trust)
        } else {
            // Discrete Path
            let omega = engine
                .compute_reachable_set(&initial_state_id, step_budget)
                .optionality();
            (
                omega,
                ErrorBounds {
                    epsilon: 0.0,
                    confidence: 1.0,
                },
                TrustLevel::High,
            )
        };

        // Update global trust/bounds (pessimistic aggregation)
        if (step_trust.clone() as i32) < (trust_level.clone() as i32) {
            trust_level = step_trust;
        }
        error_bounds.epsilon = error_bounds.epsilon.max(step_bounds.epsilon);
        error_bounds.confidence = error_bounds.confidence.min(step_bounds.confidence);

        // T24: record for monotonicity + additivity validation
        temporal.record(t, step_omega as f64);

        // T3/T6: Collapse rate κ = ln(Ω_prev) − ln(Ω_curr)
        let curr_opt = Optionality(step_omega as f64);
        let prev_opt = Optionality(prev_omega);
        let kappa = compute_collapse_rate(prev_opt, curr_opt);

        // T14: Geometric flexibility = directional thickness τ(x), scaled by Ω fraction
        let omega_fraction = if full_omega > 0 {
            step_omega as f64 / full_omega as f64
        } else {
            0.0
        };
        let thickness = if base_thickness.is_finite() {
            (base_thickness * omega_fraction).max(0.0)
        } else {
            omega_fraction
        };

        total_thickness += thickness;

        // T13.3: Risk spike = κ_geom × κ_discrete
        let risk_spike = if kappa.0.is_finite() && kappa.0 > 0.0 {
            (base_kappa_spike * kappa.0.min(10.0)).min(100.0)
        } else {
            0.0
        };

        let minimum_collapse_perturbation = polytope.minimum_collapse_perturbation(&step_pos);
        let directional_margin = polytope.directional_distance(&step_pos, &motion_dir);
        let active_constraints = polytope.active_constraint_count(&step_pos, 1e-6);
        let local_dimension = polytope.local_dimension(&step_pos, 1e-6);
        let phase_transition = t > 0 && active_constraints > prev_active_constraints;

        // Point-of-no-return: first t where Ω drops to 0
        if step_omega == 0 && point_of_no_return.is_none() {
            point_of_no_return = Some(t);
            collapse_state = optimal_trajectory
                .as_ref()
                .and_then(|traj| traj.path.get(t).cloned())
                .or_else(|| Some(initial_state_id.clone()));
        }

        // T4/T28: Goal distance & progress tracking
        let (goal_dist, reached) = if let Some(ref traj) = optimal_trajectory {
            if let Some(state_id) = traj.path.get(t) {
                if let Some(state) = engine.state_space.states.get(state_id) {
                    let progress = compiler.goal_progress(&state.attributes, &schema);
                    (progress, progress >= 1.0)
                } else {
                    (initial_goal_progress, initial_goal_progress >= 1.0)
                }
            } else {
                (initial_goal_progress, initial_goal_progress >= 1.0)
            }
        } else {
            (initial_goal_progress, initial_goal_progress >= 1.0)
        };

        if reached && goal_reached_at.is_none() {
            goal_reached_at = Some(t);
        }

        // T28: Check if this step is on the recommended path
        // (Simplified: we use index-based matching for discrete time)
        let is_on_recommended_path = optimal_trajectory
            .as_ref()
            .map(|traj| t < traj.path.len())
            .unwrap_or(false);

        let status = if step_omega == 0 {
            "collapsed"
        } else if local_dimension == 0 || active_constraints >= n_vars.saturating_sub(1) {
            "critical"
        } else if active_constraints > 0 || minimum_collapse_perturbation <= thickness.max(1e-6) {
            "narrowing"
        } else {
            "safe"
        }
        .to_string();

        // T17: Structural entropy
        let step_entropy = entropy(Optionality(step_omega as f64));

        // T18: Sensitivity / Root Cause Analysis
        // We look for the variable whose axis-aligned boundary is closest to the center point.
        let mut dominant_root_cause: Option<String> = None;
        if step_omega < full_omega {
            let mut min_dist = f64::INFINITY;
            for (i, name) in var_names.iter().enumerate() {
                // Approximate distance to variable i's specific constraints
                for plane in &polytope.constraints {
                    if plane.normal.0[i].abs() > 0.9 {
                        // Primarily axis-aligned to variable i
                        let dist =
                            (plane.bound - plane.normal.dot(&center_pt)) / plane.normal.magnitude();
                        if dist < min_dist {
                            min_dist = dist;
                            dominant_root_cause = Some(name.to_string());
                        }
                    }
                }
            }
        }

        if let Some(ref cause) = dominant_root_cause {
            *culprit_freqs.entry(cause.clone()).or_insert(0) += 1;
        }
        peak_fragility = peak_fragility.max(risk_spike);

        timeline.push(TimelineStep {
            t,
            future_width: step_omega,
            thickness,
            risk_spike,
            goal_distance: goal_dist,
            is_on_recommended_path,
            entropy: step_entropy.0,
            dominant_root_cause,
            status,
            active_constraints,
            local_dimension,
            phase_transition,
            minimum_collapse_perturbation,
            directional_margin,
        });

        prev_omega = step_omega as f64;
        prev_active_constraints = active_constraints;
    }

    let mean_thickness = if horizon > 0 {
        total_thickness / (horizon + 1) as f64
    } else {
        total_thickness
    };

    let sensitivity_report = Some(GlobalSensitivityReport {
        primary_culprits: culprit_freqs,
        mean_thickness,
        peak_fragility,
    });

    // ── T24: Run full consistency report ──────────────────────────────────────
    let consistency = temporal.full_report();
    if !consistency.is_consistent {
        alerts.push(SystemAlert {
            code: "TEMPORAL_INCONSISTENCY".to_string(),
            severity: AlertSeverity::Warning,
            message: "Monotonicity violation detected in simulation timeline.".to_string(),
            detail: Some(format!(
                "Found {} structural inconsistencies (T24).",
                consistency.monotonicity_violations.len()
            )),
            theorem: Some("T24".to_string()),
            legacy_type: Some("temporal_inconsistency".to_string()),
        });
    }

    // ── Verdict & Recommendation ───────────────────────────────────────────────
    let verdict = if full_omega > 0 {
        "possible"
    } else {
        "impossible"
    };

    let recommendation = match full_omega {
        0 => "Goal is structurally unreachable. Expand action space or relax constraints.",
        1..=5 => "Critically constrained — narrow corridor detected (T14). Urgent: reduce scope or add resources.",
        6..=20 => "Low optionality. Recommend diversifying available actions (T9 < threshold).",
        _ => "Trajectory is stable. Maintain current action plan.",
    };

    let critical_decisions = {
        let epsilon = schema
            .theorem_inputs
            .as_ref()
            .and_then(|t| t.critical_epsilon)
            .unwrap_or(0.25);
        let graph = engine.state_space.build_graph();
        let ranked_transitions = graph
            .get(&initial_state_id)
            .into_iter()
            .flat_map(|neighbors| neighbors.iter())
            .filter_map(|(next_state, edge_cost)| {
                let remaining = resolved_budget - *edge_cost;
                if remaining < 0.0 {
                    return None;
                }
                let omega_next = engine
                    .compute_reachable_set(next_state, remaining)
                    .optionality();
                Some(evaluate_transition(
                    Optionality(full_omega as f64),
                    next_state,
                    Optionality(omega_next as f64),
                ))
            })
            .collect::<Vec<_>>();

        if ranked_transitions.is_empty() {
            None
        } else {
            Some(CriticalDecisionSummary {
                epsilon,
                current_entropy: entropy(Optionality(full_omega as f64)).0,
                ranked_transitions: rank_decisions(ranked_transitions)
                    .into_iter()
                    .map(|m| CriticalTransition {
                        state: m.next_state,
                        kappa: m.kappa.0,
                        impact_ratio: m.impact_ratio,
                        critical: m.kappa.0 == f64::INFINITY || m.impact_ratio >= epsilon,
                    })
                    .collect(),
            })
        }
    };

    let survival_policy = timeline
        .iter()
        .max_by(|a, b| {
            a.risk_spike
                .partial_cmp(&b.risk_spike)
                .unwrap_or(std::cmp::Ordering::Equal)
        })
        .map(|step| {
            let regime = if step.status == "collapsed" {
                "collapsed"
            } else if step.status == "critical" || step.minimum_collapse_perturbation <= 0.05 {
                "corridor"
            } else {
                "open"
            }
            .to_string();

            let recommended_posture = match regime.as_str() {
                "collapsed" => {
                    "Retreat, relax constraints, or expand the action/state space before continuing."
                }
                "corridor" => {
                    "Stay centered, preserve thickness, and avoid irreversible high-impact moves."
                }
                _ => "Advance while preserving optionality and monitoring collapse pressure.",
            }
            .to_string();

            SurvivalPolicySummary {
                regime: regime.clone(),
                recommended_posture,
                keep_centered: regime == "corridor",
                diversify_actions: step.status == "narrowing" || step.status == "critical",
                add_resources: step.status == "critical" || step.status == "collapsed",
            }
        });

    let impossibility_proof = point_of_no_return.map(|collapse_step| ImpossibilityProof {
        omega_before: timeline
            .get(collapse_step.saturating_sub(1))
            .map(|s| s.future_width)
            .unwrap_or(full_omega),
        omega_after: timeline
            .get(collapse_step)
            .map(|s| s.future_width)
            .unwrap_or(0),
        collapse_step,
        closing_state: collapse_state,
        dominant_constraint: timeline
            .get(collapse_step)
            .and_then(|s| s.dominant_root_cause.clone())
            .or_else(|| {
                timeline
                    .iter()
                    .rev()
                    .find_map(|s| s.dominant_root_cause.clone())
            }),
        reproducible: consistency.is_consistent,
    });

    let mut dominance_frontier = dominance::DominanceFrontier::new();
    for state_id in &full_reachable.states {
        if let Some(cost) = full_reachable.cost_to(state_id) {
            let optionality = engine
                .compute_reachable_set(state_id, resolved_budget)
                .optionality() as f64;
            dominance_frontier.insert(state_id.clone(), cost, optionality);
        }
    }
    let dominance_summary = Some(DominanceSummary {
        frontier_size: dominance_frontier.size(),
        best_state: dominance_frontier.best().map(|e| e.state.clone()),
        best_cost: dominance_frontier.best().map(|e| e.cost),
        best_optionality: dominance_frontier.best().map(|e| e.optionality),
    });

    let resource_order: Vec<String> = {
        let mut names: Vec<String> = schema.resources.keys().cloned().collect();
        names.sort();
        names
    };
    let pareto_analysis = if resource_order.len() > 1 {
        let vector_budget = pareto::VectorBudget::new(
            resource_order
                .iter()
                .filter_map(|name| schema.resources.get(name).map(|r| r.initial))
                .collect(),
        );
        let vector_transitions: Vec<pareto::VectorTransition> = space
            .transitions
            .iter()
            .map(|t| {
                let costs = resource_order
                    .iter()
                    .map(|resource| {
                        t.metadata
                            .as_ref()
                            .and_then(|m| m.get(resource))
                            .and_then(|v| v.as_f64())
                            .unwrap_or(0.0)
                    })
                    .collect();
                pareto::VectorTransition {
                    from: t.from.clone(),
                    to: t.to.clone(),
                    costs,
                }
            })
            .collect();

        let cost_vectors: Vec<Vec<f64>> =
            vector_transitions.iter().map(|t| t.costs.clone()).collect();
        let scalar_direction = pareto::ParetoEngine::check_scalar_reducibility(&cost_vectors);
        let reachable_states = pareto::ParetoEngine::pareto_reachable_set(
            &space,
            &vector_transitions,
            &initial_state_id,
            &vector_budget,
        );

        Some(ParetoSummary {
            resource_order,
            budget: vector_budget.0,
            scalar_reducible: scalar_direction.is_some(),
            scalar_direction,
            reachable_states,
        })
    } else {
        None
    };

    let multi_agent_analysis = schema.theorem_inputs.as_ref().and_then(|inputs| {
        if inputs.agents.len() < 2 {
            return None;
        }

        let mut engine_ma = multiagent::MultiAgentEngine::new(space.clone());
        for agent in &inputs.agents {
            engine_ma.add_agent(multiagent::AgentState {
                id: agent.id.clone(),
                position: initial_state_id.clone(),
                budget: agent.budget.unwrap_or(resolved_budget),
                consumed_states: agent.consumed_states.iter().cloned().collect(),
            });
        }

        let reports: Vec<MultiAgentReportSummary> = (0..engine_ma.agent_count())
            .filter_map(|idx| engine_ma.detect_interference(idx))
            .map(|report| MultiAgentReportSummary {
                agent_id: report.agent_id,
                solo_optionality: report.solo_optionality,
                conditional_optionality: report.conditional_optionality,
                optionality_loss: report.optionality_loss,
                interfering_agents: report.interfering_agents,
            })
            .collect();

        let attacker_strength = inputs
            .agents
            .iter()
            .filter_map(|a| a.attacker_strength)
            .fold(0.0_f64, f64::max);

        let competitive = if attacker_strength > 0.0 {
            let analysis = multiagent::MultiAgentEngine::competitive_analysis(
                &polytope,
                &center_pt,
                &motion_dir,
                attacker_strength,
            );
            let (chebyshev_center, chebyshev_radius) =
                multiagent::MultiAgentEngine::chebyshev_center(&polytope);
            Some(CompetitiveSummary {
                kappa_unperturbed: analysis.kappa_unperturbed,
                kappa_competitive_bound: analysis.kappa_competitive_bound,
                adversarial_premium: analysis.adversarial_premium,
                tau_star: analysis.tau_star,
                chebyshev_center: chebyshev_center.0,
                chebyshev_radius,
            })
        } else {
            None
        };

        Some(MultiAgentSummary {
            reports,
            competitive,
        })
    });

    let dynamic_evolution = schema.theorem_inputs.as_ref().and_then(|inputs| {
        if inputs.discovery_events.is_empty() {
            return None;
        }

        let mut dynamic = dynamics::evolution::DynamicStateSpace::new(
            space.states.len(),
            space.transitions.len(),
        );
        let goal_id = "primary_goal".to_string();
        if let Some(t) = point_of_no_return {
            dynamic.mark_collapsed(goal_id.clone(), t);
        }

        let mut total_new_states = 0usize;
        let mut total_new_edges = 0usize;
        for event in &inputs.discovery_events {
            total_new_states += event.new_states.len();
            total_new_edges += event.new_edges.len();
            dynamic.register_discovery(
                event.time,
                event.new_states.clone(),
                event
                    .new_edges
                    .iter()
                    .map(|e| (e.from.clone(), e.to.clone(), e.cost))
                    .collect(),
            );
        }

        Some(DynamicEvolutionSummary {
            discovery_count: dynamic.discovery_count(),
            total_new_states,
            total_new_edges,
            persistence_valid: dynamic.persistence_valid(&goal_id),
            discovery_regret: dynamic.discovery_regret(point_of_no_return.unwrap_or(0)),
        })
    });

    let composition_analysis = schema.theorem_inputs.as_ref().and_then(|inputs| {
        if inputs.composition_subsystems.len() < 2 {
            return None;
        }
        let a = &inputs.composition_subsystems[0];
        let b = &inputs.composition_subsystems[1];
        let analysis = pareto::CompositionAnalysis::analyze(
            a.volume,
            b.volume,
            a.thickness,
            b.thickness,
            a.kappa,
            b.kappa,
            Some(peak_fragility.max(a.kappa + b.kappa)),
        );
        Some(CompositionSummary {
            subsystem_names: vec![a.name.clone(), b.name.clone()],
            volume_product: analysis.volume_product,
            min_thickness: analysis.min_thickness,
            coupling: analysis.coupling,
            is_independent: analysis.is_independent,
        })
    });

    let monotonicity_report = Some(MonotonicityReport {
        optionality_non_increasing: consistency.monotonicity_violations.is_empty(),
        monotonicity_violation_count: consistency.monotonicity_violations.len(),
        phase_transition_count: timeline.iter().filter(|step| step.phase_transition).count(),
    });

    let persistence_report = Some(PersistenceReport {
        point_of_no_return_crossed: point_of_no_return.is_some(),
        collapse_is_persistent: dynamic_evolution
            .as_ref()
            .map(|d| d.persistence_valid)
            .unwrap_or(point_of_no_return.is_some()),
        collapsed_at: point_of_no_return,
    });

    let entropy_start = timeline.first().map(|s| s.entropy).unwrap_or(0.0);
    let entropy_end = timeline.last().map(|s| s.entropy).unwrap_or(0.0);
    let net_information_value = entropy_start - entropy_end;

    let collapse_rate_report = Some(CollapseRateReport {
        total_collapse_bits: net_information_value,
        peak_kappa: peak_fragility,
        terminal_collapse: point_of_no_return.is_some(),
    });

    let information_value_report = Some(InformationValueReport {
        entropy_start,
        entropy_end,
        net_information_value,
        path_independent: consistency.state_function_valid,
    });

    SimulationResult {
        timeline,
        point_of_no_return,
        goal_reached_at,
        recommended_path,
        is_approximate,
        verdict: verdict.to_string(),
        recommendation: recommendation.to_string(),
        calculation_mode,
        trust_level,
        error_bounds,
        alerts,
        sensitivity_report,
        impossibility_proof,
        pareto_analysis,
        multi_agent_analysis,
        dominance_frontier: dominance_summary,
        critical_decisions,
        survival_policy,
        dynamic_evolution,
        composition_analysis,
        monotonicity_report,
        persistence_report,
        collapse_rate_report,
        information_value_report,
    }
}
