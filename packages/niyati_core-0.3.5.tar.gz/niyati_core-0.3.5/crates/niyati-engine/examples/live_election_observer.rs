use async_trait::async_trait;
use chrono::Utc;
use std::collections::HashMap;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Duration;

use niyati_core::observer::types::{StateSnapshot, SystemState};
use niyati_core::observer::{CausalObserver, ObservableSystem, ObserverError};
use niyati_core::reachability::core::ReachabilityEngine;
use niyati_core::types::{State, StateSpace, Transition};

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct SwingState {
    name: &'static str,
    evs: u32,
}

const SWING_STATES: &[SwingState] = &[
    SwingState {
        name: "PA",
        evs: 19,
    },
    SwingState {
        name: "GA",
        evs: 16,
    },
    SwingState {
        name: "NC",
        evs: 16,
    },
    SwingState {
        name: "MI",
        evs: 15,
    },
    SwingState {
        name: "AZ",
        evs: 11,
    },
    SwingState {
        name: "WI",
        evs: 10,
    },
    SwingState { name: "NV", evs: 6 },
];

const BASE_DEM_EVS: u32 = 226;
const WIN_THRESHOLD: u32 = 270;

fn generate_graph() -> StateSpace {
    let mut space = StateSpace::new();
    let mut queue = vec![(0, vec![], vec![])];
    let mut visited = std::collections::HashSet::new();

    while let Some((idx, mut dem_won, mut rep_won)) = queue.pop() {
        dem_won.sort();
        rep_won.sort();

        let state_id = format!("D:{}|R:{}", dem_won.join(","), rep_won.join(","));

        if visited.contains(&state_id) {
            continue;
        }
        visited.insert(state_id.clone());

        space.add_state(State {
            id: state_id.clone(),
            attributes: HashMap::new(),
        });

        if idx < SWING_STATES.len() {
            let next_st = &SWING_STATES[idx];
            queue.push((idx + 1, dem_won.clone(), rep_won.clone()));

            let mut new_dem = dem_won.clone();
            new_dem.push(next_st.name.to_string());
            let child_dem_id = format!(
                "D:{}|R:{}",
                {
                    let mut d = new_dem.clone();
                    d.sort();
                    d.join(",")
                },
                rep_won.join(",")
            );
            space.add_transition(Transition {
                from: state_id.clone(),
                to: child_dem_id,
                cost: 0.0,
                metadata: None,
            });
            queue.push((idx + 1, new_dem, rep_won.clone()));

            let mut new_rep = rep_won.clone();
            new_rep.push(next_st.name.to_string());
            let child_rep_id = format!("D:{}|R:{}", dem_won.join(","), {
                let mut r = new_rep.clone();
                r.sort();
                r.join(",")
            });
            space.add_transition(Transition {
                from: state_id.clone(),
                to: child_rep_id,
                cost: 0.0,
                metadata: None,
            });
            queue.push((idx + 1, dem_won, new_rep));
        }
    }

    space.add_state(State {
        id: "DEM_VICTORY".to_string(),
        attributes: HashMap::new(),
    });

    for state_id in visited {
        let parts: Vec<&str> = state_id.split('|').collect();
        let dem_str = parts[0].trim_start_matches("D:");
        let mut total_evs = BASE_DEM_EVS;
        if !dem_str.is_empty() {
            for st in dem_str.split(',') {
                if let Some(s) = SWING_STATES.iter().find(|x| x.name == st) {
                    total_evs += s.evs;
                }
            }
        }
        if total_evs >= WIN_THRESHOLD {
            space.add_transition(Transition {
                from: state_id.clone(),
                to: "DEM_VICTORY".to_string(),
                cost: 0.0,
                metadata: None,
            });
        }
    }
    space
}

struct ElectionSystem {
    engine: ReachabilityEngine,
    tick: AtomicUsize,
    mock_events: Vec<SystemState>,
}

impl ElectionSystem {
    fn new() -> Self {
        let state_space = generate_graph();
        let engine = ReachabilityEngine::new(state_space);

        let mock_events = vec![
            SystemState {
                id: "D:|R:".to_string(),
                timestamp: Utc::now(),
                data: HashMap::new(),
                confidence: 0.99,
                source: "AP API".to_string(),
                corroborating_sources: vec!["DecisionDesk".to_string()],
            },
            SystemState {
                id: "D:|R:".to_string(),
                timestamp: Utc::now(),
                data: HashMap::new(),
                confidence: 0.99,
                source: "AP API".to_string(),
                corroborating_sources: vec!["DecisionDesk".to_string()],
            },
            SystemState {
                id: "D:PA|R:".to_string(),
                timestamp: Utc::now(),
                data: HashMap::new(),
                confidence: 0.98,
                source: "AP API".to_string(),
                corroborating_sources: vec!["DecisionDesk".to_string()],
            },
            SystemState {
                id: "D:PA|R:GA".to_string(),
                timestamp: Utc::now(),
                data: HashMap::new(),
                confidence: 0.98,
                source: "AP API".to_string(),
                corroborating_sources: vec!["DecisionDesk".to_string()],
            },
            SystemState {
                id: "D:MI,PA|R:GA".to_string(),
                timestamp: Utc::now(),
                data: HashMap::new(),
                confidence: 0.97,
                source: "AP API".to_string(),
                corroborating_sources: vec!["DecisionDesk".to_string()],
            },
            // Fatal cascade for Republicans
            SystemState {
                id: "D:AZ,MI,PA|R:GA".to_string(),
                timestamp: Utc::now(),
                data: HashMap::new(),
                confidence: 0.99,
                source: "AP API + NYT".to_string(),
                corroborating_sources: vec!["AP API".to_string(), "NYT Scraper".to_string()],
            },
        ];

        Self {
            engine,
            tick: AtomicUsize::new(0),
            mock_events,
        }
    }
}

#[async_trait]
impl ObservableSystem for ElectionSystem {
    async fn fetch_state(&self) -> Result<SystemState, ObserverError> {
        let idx = self.tick.fetch_add(1, Ordering::SeqCst);
        if idx < self.mock_events.len() {
            Ok(self.mock_events[idx].clone())
        } else {
            Err(ObserverError::FetchError("No more events".to_string()))
        }
    }

    fn compute_omega(&self, state: &SystemState) -> f64 {
        let reachable = self.engine.compute_reachable_set(&state.id, 100.0);
        if !reachable.is_reachable(&"DEM_VICTORY".to_string()) {
            return 0.0;
        }

        let mut paths = 0;
        for target in &reachable.states {
            if target == "DEM_VICTORY" {
                continue;
            }
            let parts: Vec<&str> = target.split('|').collect();
            let d_len = if parts[0].len() > 2 {
                parts[0][2..].split(',').count()
            } else {
                0
            };
            let r_len = if parts[1].len() > 2 {
                parts[1][2..].split(',').count()
            } else {
                0
            };

            if d_len + r_len == 7 {
                let mut total_evs = BASE_DEM_EVS;
                if d_len > 0 {
                    for st in parts[0][2..].split(',') {
                        if let Some(s) = SWING_STATES.iter().find(|x| x.name == st) {
                            total_evs += s.evs;
                        }
                    }
                }
                // Target: Does Republican win? To be an arbiter for Republican path we invert logic,
                // but let's stick to measuring Democrats chances here:
                if total_evs < WIN_THRESHOLD {
                    paths += 1; // Paths where Republicans win
                }
            }
        }
        paths as f64
    }

    fn build_state_id(&self, state: &SystemState) -> String {
        state.id.clone()
    }

    fn describe_state_snapshot(&self, snapshot: &StateSnapshot) -> String {
        format!("State Config: {}", snapshot.id)
    }
}

#[tokio::main]
async fn main() {
    println!("Starting CausalObserver on Electoral College Live Feed...");
    let system = Box::new(ElectionSystem::new());
    let mut observer =
        CausalObserver::new(system, Duration::from_millis(500), "observer_state.json");

    let _ = std::fs::remove_file("observer_state.json"); // Start clean for demo

    while observer.run().await.is_ok() {
        // Will break out after one tick because I put a `break` in `observer.run()` under `#[cfg(test)]`.
        // To loop it endlessly, we would remove the break. Let me actually loop it here until the fetch fails.
    }
    println!("Observer terminated.");
}
