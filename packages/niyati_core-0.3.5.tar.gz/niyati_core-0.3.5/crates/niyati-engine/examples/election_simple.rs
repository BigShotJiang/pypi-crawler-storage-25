use niyati_core::*;
use std::collections::HashMap;

fn main() {
    println!("=== Simple Election Reachability Example ===\n");

    // Simplified electoral college
    // Start: 219 EVs
    // Need: 270 to win
    // Available swing states: PA(19), GA(16), AZ(11)

    let mut space = StateSpace::new();

    // Create states for EV counts
    for evs in 219..=270 {
        space.add_state(State {
            id: format!("EV_{}", evs),
            attributes: HashMap::new(),
        });
    }

    // Transitions: winning each state
    let swing_states = vec![("PA", 19), ("GA", 16), ("AZ", 11)];

    // Add all possible transitions
    for current_evs in 219..270 {
        for (state_name, evs) in &swing_states {
            let new_evs = current_evs + evs;
            if new_evs <= 270 {
                space.add_transition(Transition {
                    from: format!("EV_{}", current_evs),
                    to: format!("EV_{}", new_evs),
                    cost: 1.0, // Each state "costs" 1 decision
                    metadata: Some({
                        let mut m = HashMap::new();
                        m.insert("state".into(), serde_json::json!(state_name));
                        m
                    }),
                });
            }
        }
    }

    let engine = reachability::core::ReachabilityEngine::new(space);

    // Can we reach 270 from 219?
    let start = "EV_219";
    let budget = 3.0; // Can win all 3 states

    let reachable = engine.compute_reachable_set(&start.into(), budget);

    println!("Starting EVs: 219");
    println!("Target: 270 (victory)");
    println!("Available states: PA(19), GA(16), AZ(11)");
    println!();

    if reachable.is_reachable(&"EV_270".into()) {
        println!("✅ Victory is REACHABLE");

        if let Some(path) = reachable.path_to(&"EV_270".into()) {
            println!("\nOne winning path:");
            for state in path {
                println!("  → {}", state);
            }
        }
    } else {
        println!("❌ Victory is UNREACHABLE");
    }

    println!("\nTotal reachable EV counts: {}", reachable.optionality());

    // Show all reachable EV counts
    println!("\nReachable outcomes:");
    let mut reachable_evs: Vec<_> = reachable.reachable_states();
    reachable_evs.sort();
    for ev_state in reachable_evs {
        if let Some(cost) = reachable.cost_to(&ev_state) {
            println!("  {} (states won: {})", ev_state, cost);
        }
    }
}
