use niyati_core::{
    dynamics::collapse::{classify_collapse, Optionality},
    enforcement::{EnforcementResult, PolicyEnforcer},
    information::critical_decisions::{entropy, evaluate_transition},
    reachability::core::ReachabilityEngine,
    types::{State, StateSpace, Transition},
};
use std::collections::HashMap;

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct SwingState {
    name: &'static str,
    evs: u32,
}

const SWING_STATES: &[SwingState] = &[
    SwingState {
        name: "PA",
        evs: 19,
    },
    SwingState {
        name: "GA",
        evs: 16,
    },
    SwingState {
        name: "NC",
        evs: 16,
    },
    SwingState {
        name: "MI",
        evs: 15,
    },
    SwingState {
        name: "AZ",
        evs: 11,
    },
    SwingState {
        name: "WI",
        evs: 10,
    },
    SwingState { name: "NV", evs: 6 },
];

const BASE_DEM_EVS: u32 = 226;
// const BASE_REP_EVS: u32 = 219;
const WIN_THRESHOLD: u32 = 270;

/// State is encoded as a string: "D:PA,MI|R:GA"
fn generate_graph() -> StateSpace {
    let mut space = StateSpace::new();

    // Total states = 3^7 = 2187.
    // We will generate them via DFS.
    let mut queue = vec![(0, vec![], vec![])]; // (index in SWING_STATES, dem_won, rep_won)
    let mut visited = std::collections::HashSet::new();

    while let Some((idx, mut dem_won, mut rep_won)) = queue.pop() {
        // Sort for consistent ID generation
        dem_won.sort();
        rep_won.sort();

        let state_id = format!("D:{}|R:{}", dem_won.join(","), rep_won.join(","));

        if visited.contains(&state_id) {
            continue;
        }
        visited.insert(state_id.clone());

        space.add_state(State {
            id: state_id.clone(),
            attributes: HashMap::new(),
        });

        if idx < SWING_STATES.len() {
            let next_st = &SWING_STATES[idx];

            // Branch 1: State remains Undecided (we just increment index, no transition added for this, it is just a graph state)
            queue.push((idx + 1, dem_won.clone(), rep_won.clone()));

            // Branch 2: Dem Wins State
            let mut new_dem = dem_won.clone();
            new_dem.push(next_st.name.to_string());
            let child_dem_id = format!(
                "D:{}|R:{}",
                {
                    let mut d = new_dem.clone();
                    d.sort();
                    d.join(",")
                },
                rep_won.join(",")
            );

            space.add_transition(Transition {
                from: state_id.clone(),
                to: child_dem_id,
                cost: 0.0,
                metadata: None,
            });
            queue.push((idx + 1, new_dem, rep_won.clone()));

            // Branch 3: Rep Wins State
            let mut new_rep = rep_won.clone();
            new_rep.push(next_st.name.to_string());
            let child_rep_id = format!("D:{}|R:{}", dem_won.join(","), {
                let mut r = new_rep.clone();
                r.sort();
                r.join(",")
            });

            space.add_transition(Transition {
                from: state_id.clone(),
                to: child_rep_id,
                cost: 0.0,
                metadata: None,
            });
            queue.push((idx + 1, dem_won, new_rep));
        }
    }

    // Add terminal success states for Dem Win
    space.add_state(State {
        id: "DEM_VICTORY".to_string(),
        attributes: HashMap::new(),
    });

    // Connect all winning states to DEM_VICTORY
    for state_id in visited {
        let parts: Vec<&str> = state_id.split('|').collect();
        let dem_str = parts[0].trim_start_matches("D:");

        let mut total_evs = BASE_DEM_EVS;
        if !dem_str.is_empty() {
            for st in dem_str.split(',') {
                if let Some(s) = SWING_STATES.iter().find(|x| x.name == st) {
                    total_evs += s.evs;
                }
            }
        }

        // If this state itself has >270, it's a victory node
        if total_evs >= WIN_THRESHOLD {
            space.add_transition(Transition {
                from: state_id.clone(),
                to: "DEM_VICTORY".to_string(),
                cost: 0.0,
                metadata: None,
            });
        }
    }

    space
}

fn bot_alert(call_name: &str, prev_omega: f64, new_omega: f64, epsilon: f64) {
    let opt_curr = Optionality(prev_omega);
    let opt_next = Optionality(new_omega);

    let metrics = evaluate_transition(opt_curr, &call_name.to_string(), opt_next);

    let enforcer = PolicyEnforcer::new(epsilon);
    let results = enforcer.enforce(&"N/A".to_string(), vec![metrics.clone()]);
    let result = &results[0];

    println!("\n🚨 @ImpossibleNow Bot Engine Triggered 🚨");
    println!("Event: {} is called.", call_name);

    let _h_curr = entropy(opt_curr);

    println!("\nAnalysis:");
    println!("- Initial Paths to Victory (Ω): {:.0}", opt_curr.0);
    println!("- Remaining Paths (Ω_next): {:.0}", metrics.omega_next.0);

    let kappa_str = if metrics.kappa.0 == f64::INFINITY {
        "∞".to_string()
    } else {
        format!("{:.2}", metrics.kappa.0)
    };

    println!(
        "- Information Destruction (κ): {} bits {:?}",
        kappa_str,
        classify_collapse(metrics.kappa)
    );
    println!(
        "- Impact Ratio: {:.2} (Threshold ε={})",
        metrics.impact_ratio, epsilon
    );

    match result {
        EnforcementResult::Allowed(_) => {
            println!("\nStatus: ✅ STILL POSSIBLE");
            println!("Action: No arbitrage. The market still contains structural life.");
        }
        EnforcementResult::CriticalViolation { .. } => {
            if metrics.kappa.0 == f64::INFINITY {
                println!("\nStatus: ❌ STRUCTURALLY IMPOSSIBLE");
                println!(
                    "Action: SHORT the market immediately. Mathematical impossibility reached."
                );
                println!("Lead Time: Our engine detected this mathematically before 538 or CNN.");
            } else {
                println!("\nStatus: ⚠️ CRITICAL COLLAPSE");
                println!("Action: Hedging recommended. Path viability has dropped below safe topological limits.");
            }
        }
    }
}

fn main() {
    println!("Initializing Polymarket Arbiter Engine...");
    let space = generate_graph();
    let engine = ReachabilityEngine::new(space);

    let start_state = "D:|R:"; // Empty

    println!("Computing baseline reachability universe...");
    // We compute reachability to target

    let get_omega = |state_id: &str| -> f64 {
        let reachable = engine.compute_reachable_set(&state_id.to_string(), 100.0);
        // Is DEM_VICTORY reachable?
        if !reachable.is_reachable(&"DEM_VICTORY".to_string()) {
            return 0.0;
        }

        // Count how many terminal nodes lead to Dem victory from here
        // A terminal node is one where all 7 states are decided.
        let mut paths = 0;
        for target in reachable.states.iter() {
            if target == "DEM_VICTORY" {
                continue;
            }

            let parts: Vec<&str> = target.split('|').collect();
            let d_len = if parts[0].len() > 2 {
                parts[0][2..].split(',').count()
            } else {
                0
            };
            let r_len = if parts[1].len() > 2 {
                parts[1][2..].split(',').count()
            } else {
                0
            };

            if d_len + r_len == 7 {
                // Check if this config wins
                let mut total_evs = BASE_DEM_EVS;
                if d_len > 0 {
                    for st in parts[0][2..].split(',') {
                        if let Some(s) = SWING_STATES.iter().find(|x| x.name == st) {
                            total_evs += s.evs;
                        }
                    }
                }
                if total_evs >= WIN_THRESHOLD {
                    paths += 1;
                }
            }
        }
        paths as f64
    };

    let base_omega = get_omega(start_state);
    println!(
        "Base winning configurations for Candidate A: {}",
        base_omega
    ); // Out of 2^7 = 128

    // Scenario 1: Harmless State Call
    // PA goes to Democrats
    let pa_dem_state = "D:PA|R:";
    let pa_dem_omega = get_omega(pa_dem_state);
    bot_alert("PA called for Candidate A", base_omega, pa_dem_omega, 0.40);

    // Scenario 2: Critical Collapse
    // PA goes to Republicans
    let pa_rep_state = "D:|R:PA";
    let pa_rep_omega = get_omega(pa_rep_state);
    bot_alert("PA called for Candidate B", base_omega, pa_rep_omega, 0.40);

    // Scenario 3: Impossibility Arb
    // From PA_Rep, then MI_Rep, then AZ_Rep
    let cascade_state = "D:|R:AZ,MI,PA";
    let casc_omega = get_omega(cascade_state);
    bot_alert(
        "AZ, MI, and PA called for Candidate B",
        base_omega,
        casc_omega,
        0.40,
    );
}
