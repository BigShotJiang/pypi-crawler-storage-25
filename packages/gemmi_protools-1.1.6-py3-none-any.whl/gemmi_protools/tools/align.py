"""
@Author: Luo Jiejian
"""

import os
import re
import shutil
import string
import subprocess
import tempfile
from typing import Literal, Optional, Dict, Any, List

import numpy as np
from Bio.Align import PairwiseAligner, substitution_matrices
from gemmi_protools import StructureParser


def check_sequence(seq: str):
    """
    Remove space, star at the end, and \n, upper the letters
    Check sequence is valid or not

    :param seq:str
    :return:

    """
    seq_clean = re.sub(pattern=r" |\*|-", repl='', string=seq.upper().strip())
    if len(seq_clean) == 0:
        raise ValueError("Sequence is empty")

    s = re.sub(pattern=r"[A-Z]", repl="", string=seq_clean)
    if len(s) > 0:
        raise ValueError("Sequence has Non-alphabetic characters: %s" % str(set(s)))

    return seq_clean


def align_sequences(seq1: str,
                    seq2: str,
                    seq_type: Literal["dna", "rna", "protein"] = "protein",
                    mode: Literal["global", "local"] = "local",
                    substitution_matrix: Optional[str] = None,
                    open_gap_score: Optional[float] = None,
                    extend_gap_score: Optional[float] = None,
                    end_open_gap_score: float = 0.0,
                    end_extend_gap_score: float = 0.0,
                    show_alignment: bool = False,
                    insert_code_mode: str = "alphabet",
                    ):
    """
    If insert_code_mode is alphabet, when the length of insertion is greater than 52, mapping error will raise

    In this situation, set insert_code_mode is number instead, insert code will be i1, i200 format
    """
    assert insert_code_mode in ["alphabet", "number"], "insert_code_mode must be alphabet or number only."
    default_params = {
        "dna": {
            "matrix": "NUC.4.4",
            "open_gap_score": -10.0,
            "extend_gap_score": -0.5,
            "mode": "global"
        },
        "rna": {
            "matrix": "NUC.4.4",
            "open_gap_score": -10.0,
            "extend_gap_score": -0.5,
            "mode": "global"
        },
        "protein": {
            "matrix": "BLOSUM62",
            "open_gap_score": -11.0,
            "extend_gap_score": -1.0,
            "mode": "global"
        }

    }

    available_matrices = {
        "dna": ["NUC.4.4"],
        "rna": ["NUC.4.4"],
        "protein": ["BLOSUM45", "BLOSUM50", "BLOSUM62",
                    "BLOSUM80", "BLOSUM90",
                    "PAM30", "PAM70", "PAM250"]
    }

    seq1 = check_sequence(seq1)
    seq2 = check_sequence(seq2)

    params = default_params[seq_type].copy()
    a_mats = available_matrices[seq_type]

    if substitution_matrix is not None:
        if substitution_matrix not in a_mats:
            raise ValueError("substitution matrix `%s` not support for %s" % (substitution_matrix, seq_type))
        else:
            params["matrix"] = substitution_matrix

    if open_gap_score is not None:
        params["open_gap_score"] = open_gap_score

    if extend_gap_score is not None:
        params["extend_gap_score"] = extend_gap_score

    params["mode"] = mode
    # Finish parameters checking and setting
    aligner = PairwiseAligner()
    aligner.mode = params["mode"]
    aligner.substitution_matrix = substitution_matrices.load(params["matrix"])
    aligner.open_gap_score = params["open_gap_score"]
    aligner.extend_gap_score = params["extend_gap_score"]
    aligner.end_open_gap_score = end_open_gap_score
    aligner.end_extend_gap_score = end_extend_gap_score

    best_alignment = aligner.align(seq1, seq2)[0]
    if show_alignment:
        print(best_alignment)

    aligned_seq1, aligned_seq2 = best_alignment

    # start from 1
    aa_mapper = dict()
    i = 0
    j = 0

    ins_letters = string.ascii_uppercase + string.ascii_lowercase
    k = 0

    for aa1, aa2 in zip(aligned_seq1, aligned_seq2):
        if aa1 != "-":
            i += 1
        if aa2 != "-":
            j += 1
            # reset k
            if k > 0:
                k = 0

        if aa1 != "-" and aa2 != "-":
            aa_mapper[i] = (j, "")

        # for insertion of seq1
        if aa1 != "-" and aa2 == "-":
            if insert_code_mode == "alphabet":
                aa_mapper[i] = (j, ins_letters[k])
            else:
                aa_mapper[i] = (j, "ins%d" % (k + 1,))
            k += 1

    start_1, start_2 = best_alignment.coordinates[:, 0]
    _mapper = {k + start_1: "%d%s" % (v[0] + start_2, v[1]) for k, v in aa_mapper.items()}

    # out_mapper = dict()
    # # check head and tail of seq1 with E prefix
    #
    # for i in range(1, len(seq1) + 1):
    #     if i not in _mapper:
    #         out_mapper[i] = "E%d" % i
    #     else:
    #         out_mapper[i] = _mapper[i]

    ident = best_alignment.counts().identities / best_alignment.length
    n_aligned = best_alignment.length - best_alignment.counts().gaps

    coverage_1 = n_aligned / len(seq1)
    coverage_2 = n_aligned / len(seq2)

    return dict(seq1=seq1,
                seq2=seq2,
                aligned_seq1=aligned_seq1,
                aligned_seq2=aligned_seq2,
                alignment_length=best_alignment.length,
                # aligned_aa_mapper=out_mapper,
                aligned_aa_mapper=_mapper,
                identity=round(ident, 3),
                coverage_1=round(coverage_1, 3),
                coverage_2=round(coverage_2, 3),
                )


class ChainUnknownError(Exception):
    pass


class USalignRunner(object):
    def __init__(self,
                 model_path: str,
                 reference_path: str,
                 model_chains: Optional[List[str]] = None,
                 reference_chains: Optional[List[str]] = None,
                 mm: int = 1,
                 ter: int = 1,
                 ):
        """

        Args:
            model_path: str, model path
            reference_path:, str. reference path
            model_chains: list of chains selected from model
            reference_chains: list of chains selected from reference
            mm: int, default 1, alignment of two multi-chain oligomeric structures
            ter: int, default 1, align all chains of the first model

                See USalign for more setting
        -mm  Multimeric alignment option:
          0: (default) alignment of two monomeric structures
          1: alignment of two multi-chain oligomeric structures
          2: alignment of individual chains to an oligomeric structure
             $ USalign -dir1 monomers/ list oligomer.pdb -ter 0 -mm 2
          3: alignment of circularly permuted structure
          4: MSTA, i.e., alignment of multiple monomeric chains into a
             consensus alignment
             $ USalign -dir chains/ list -suffix .pdb -mm 4
          5: fully non-sequential (fNS) alignment
          6: semi-non-sequential (sNS) alignment
          To use -mm 1 or -mm 2, '-ter' option must be 0 or 1.

        -ter  Number of chains to align.
              0: align all chains from all models (recommended for aligning
                 biological assemblies, i.e. biounits)
              1: align all chains of the first model (recommended for aligning
                 asymmetric units, default for -mm 1,2 and -TMscore 2,6,7)
              2: (default for other cases) only align the first chain
              3: only align the first chain, or the first segment of the
                 first chain as marked by the 'TER' string in PDB file
        """
        self.model_path = model_path
        self.reference_path = reference_path

        self.model_chains = model_chains
        self.reference_chains = reference_chains
        self.mm = mm
        self.ter = ter

        if self.model_chains:
            self.check_chains(self.model_path, self.model_chains)

        if self.reference_chains:
            self.check_chains(self.reference_path, self.reference_chains)

        self.usalign_path = shutil.which("USalign")
        if self.usalign_path is None:
            raise RuntimeError("Executable program USalign is not found. "
                               "Download from https://aideepmed.com/US-align/ ."
                               "Build it and add USalign to environment PATH"
                               )

    @staticmethod
    def check_chains(path: str, chains: List[str]):
        st = StructureParser()
        st.load_from_file(path)

        query_chains = set(chains)
        tgt_chains = set(st.chain_ids)

        unknown_chains = query_chains.difference(tgt_chains)
        if len(unknown_chains) > 0:
            raise ChainUnknownError(f"Chain {",".join(list(unknown_chains))} not found in {path}")

    @staticmethod
    def parser_rotation_matrix(matrix_file: str):
        rotation_matrix = []
        translation_vector = []

        with open(matrix_file, 'r') as file:
            lines = file.readlines()
            values = lines[2:5]
            for cur_line in values:
                tmp = re.split(pattern=r"\s+", string=cur_line.strip())
                assert len(tmp) == 5
                rotation_matrix.append(tmp[2:])
                translation_vector.append(tmp[1])
        return dict(R=np.array(rotation_matrix).astype(np.float32),
                    T=np.array(translation_vector).astype(np.float32))

    @staticmethod
    def parse_terminal_outputs(output_string: str) -> Dict[str, Any]:
        lines = output_string.strip("#").split("\n")
        header = lines[0].split("\t")
        value = lines[1].split("\t")
        pair_values = dict(zip(header, value))

        ch_mapping = dict()
        chain1 = pair_values["PDBchain1"].split(":")
        chain2 = pair_values["PDBchain2"].split(":")
        for ch1, ch2 in zip(chain1[1:], chain2[1:]):
            if ch1 != "" and ch2 != "":
                ch_mapping[ch1] = ch2

        return dict(TM1=round(float(pair_values["TM1"]), 4),
                    TM2=round(float(pair_values["TM2"]), 4),
                    RMSD=round(float(pair_values["RMSD"]), 2),
                    ID1=round(float(pair_values["ID1"]), 3),
                    ID2=round(float(pair_values["ID2"]), 3),
                    IDali=round(float(pair_values["IDali"]), 3),
                    L1=int(pair_values["L1"]),
                    L2=int(pair_values["L2"]),
                    Lali=int(pair_values["Lali"]),
                    ch_mapping=ch_mapping
                    )

    def run(self):
        output = dict()

        with tempfile.TemporaryDirectory() as tmp_dir:
            matrix_file = os.path.join(tmp_dir, "matrix.txt")

            commands = [f"{self.usalign_path} {self.model_path} {self.reference_path}",
                        f"-mm {self.mm}",
                        f"-ter {self.ter}",
                        f"-m {matrix_file}",
                        f"-outfmt 2"
                        ]

            if self.model_chains:
                commands.append(f"-chain1 {",".join(self.model_chains)}")

            if self.reference_chains:
                commands.append(f"-chain2 {",".join(self.reference_chains)}")

            try:
                result = subprocess.run(" ".join(commands), shell=True, check=True,
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            except CalledProcessError as e:
                msg = str(e)
            else:
                if result.returncode == 0:
                    output = self.parse_terminal_outputs(result.stdout.decode("utf-8"))
                    rot = self.parser_rotation_matrix(matrix_file)
                    output["rot"] = rot
                    msg = "Success"
                else:
                    msg = "Unknown Error"

        return dict(model_path=self.model_path,
                    reference_path=self.reference_path,
                    msg=msg,
                    us_scores=output
                    )
