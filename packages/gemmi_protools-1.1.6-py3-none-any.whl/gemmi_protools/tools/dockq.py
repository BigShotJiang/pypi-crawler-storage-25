"""
@Author: Luo Jiejian
"""
import json
import os
import shutil
import string
import subprocess
import tempfile
from copy import deepcopy
from typing import List, Tuple, Optional

import gemmi
import pandas as pd
from gemmi_protools.io.reader import StructureParser


def dockq_score_interface(query_model: str,
                          native_model: str,
                          partner_1_mapping: List[Tuple[str, str]],
                          partner_2_mapping: List[Tuple[str, str]],
                          ):
    """
    Calculate Dockq Score for an interface (partner 1 vs partner 2)

    :param query_model: str
        path of query model, support .pdb, .pdb.gz, .cif, .cif.gz
    :param native_model:
    :param partner_1_mapping: a list of chain ID mapping between query and native for partner1 of the interface
        e.g. [(q chain1, n chain1), (q chain2, n chain2)]
    :param partner_2_mapping:
    :return:
    """
    dockq_program = shutil.which("DockQ")
    if dockq_program is None:
        raise RuntimeError("DockQ is need")

    assert len(partner_1_mapping) > 0, "partner_1_mapping must be a list of chain ID tuples, can't be empty"
    assert len(partner_2_mapping) > 0, "partner_2_mapping must be a list of chain ID tuples, can't be empty"

    def load_struct(path: str, partner_1: List[str], partner_2: List[str]):
        st = StructureParser()
        st.load_from_file(path)
        st.clean_structure()

        for ch in partner_1 + partner_2:
            if ch not in st.chain_ids:
                raise ValueError("Chain %s not found for %s (only [%s])" % (ch, path, " ".join(st.chain_ids)))

        # merge chains in each each partner into on chain
        # partner_1 with chain ID A
        # partner_2 with chain ID B

        chain_a = gemmi.Chain("A")
        idx_a = 1
        for ch in partner_1:
            for res in st.get_chain(ch):
                nr = deepcopy(res)
                nr.seqid.icode = " "
                nr.seqid.num = idx_a
                chain_a.add_residue(nr)
                idx_a += 1

        chain_b = gemmi.Chain("B")
        idx_b = 1
        for ch in partner_2:
            for res in st.get_chain(ch):
                nr = deepcopy(res)
                nr.seqid.icode = " "
                nr.seqid.num = idx_b
                chain_b.add_residue(nr)
                idx_b += 1

        model = gemmi.Model(1)
        model.add_chain(chain_a)
        model.add_chain(chain_b)

        struct = gemmi.Structure()
        struct.add_model(model)

        output = StructureParser(struct)
        return output

    partner_1_query, partner_1_native = list(zip(*partner_1_mapping))
    partner_2_query, partner_2_native = list(zip(*partner_2_mapping))

    q_st = load_struct(query_model, list(partner_1_query), list(partner_2_query))
    n_st = load_struct(native_model, list(partner_1_native), list(partner_2_native))

    with tempfile.TemporaryDirectory() as tmp_dir:
        result_file = os.path.join(tmp_dir, "result.json")
        q_file = os.path.join(tmp_dir, "q.pdb")
        n_file = os.path.join(tmp_dir, "n.pdb")
        q_st.to_pdb(q_file, write_minimal_pdb=True)
        n_st.to_pdb(n_file, write_minimal_pdb=True)

        mapping = "AB:AB"

        _command = "%s --mapping %s --json %s %s %s" % (dockq_program, mapping, result_file, q_file, n_file)
        metrics = ['DockQ', 'F1', 'chain1', 'chain2']

        try:
            _ = subprocess.run(_command, shell=True, check=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               timeout=300.0)
        except subprocess.CalledProcessError as e:
            # Handle errors in the called executable
            msg = e.stderr.decode()
            outputs = pd.DataFrame(columns=metrics)
        except Exception as e:
            # Handle other exceptions such as file not found or permissions issues
            msg = str(e)
            outputs = pd.DataFrame(columns=metrics)
        else:
            with open(result_file, "r") as fin:
                vals = json.load(fin)
            msg = "Finished"
            result = []
            for v in vals["best_result"].values():
                result.append(v)
            outputs = pd.DataFrame(result)[metrics]

        if len(outputs) > 0:
            score = "%.4f" % outputs.iloc[0]["DockQ"]
        else:
            score = ""

        return dict(score=score, status=msg)


class ChainMappingError(Exception):
    pass


class ChainNumberError(Exception):
    pass


class DockQRunner(object):
    def __init__(self,
                 model_path: str,
                 reference_path: str,
                 model_chains: Optional[List[str]] = None,
                 reference_chains: Optional[List[str]] = None,
                 ch_mapping: Optional[dict] = None,
                 ):
        """

        Args:
            model_path:
            reference_path:
            model_chains:
            reference_chains:
            ch_mapping: dict, chain mapping from model chains to ref chains, default None
        """
        self.model_path = model_path
        self.reference_path = reference_path
        self.model, self.model_chains = self.load_structure(model_path, model_chains)
        self.reference, self.reference_chains = self.load_structure(reference_path, reference_chains)
        self.ch_mapping = self.check_chain_mapping(ch_mapping)

        if not (2 <= len(self.ch_mapping) <= 26):
            raise ChainNumberError(f"Support Structures with 2 ~ 26 chains: got {len(self.ch_mapping)} chains")

        self.dockq_program = shutil.which("DockQ")
        if self.dockq_program is None:
            raise RuntimeError("DockQ is need")

    @staticmethod
    def load_structure(path: str, chains: Optional[List[str]] = None):
        st = StructureParser()
        st.load_from_file(path)
        st.clean_structure(remove_ligand=True, remove_hydrogen=True)

        if chains is None:
            return st, st.chain_ids
        else:
            return st.pick_chains(chain_names=chains), chains

    def check_chain_mapping(self, ch_mapping: Optional[dict] = None):
        s_m = set(self.model_chains)
        s_r = set(self.reference_chains)

        if ch_mapping is None:
            # 没有指定，model_chains and ref_chains需一一对应
            model_chains_extra = list(s_m.difference(s_r))
            ref_chains_extra = list(s_r.difference(s_m))

            if model_chains_extra:
                raise ChainMappingError(f"Chains {",".join(model_chains_extra)} not Found for Reference")
            elif ref_chains_extra:
                raise ChainMappingError(f"Chains {",".join(ref_chains_extra)} not Found for Model")
            else:
                return {ch: ch for ch in self.model_chains}
        else:
            mapper_m = set(ch_mapping.keys())
            mapper_r = set(ch_mapping.values())

            if s_m == mapper_m and s_r == mapper_r:
                return ch_mapping
            else:
                raise ChainMappingError(f"Model chains: {self.model_chains}, "
                                        f"Reference chains: {self.reference_chains},"
                                        f"ch_mapping: {ch_mapping}"
                                        )

    @staticmethod
    def _rename_chains(struct: StructureParser, mapper: dict):
        st = struct.pick_chains(struct.chain_ids)

        src2mid = dict()
        mid2tgt = dict()

        for k, v in mapper.items():
            mid = f"MID:{v}"
            src2mid[k] = mid
            mid2tgt[mid] = v

        for k, v in src2mid.items():
            st.rename_chain(k, v)

        for k, v in mid2tgt.items():
            st.rename_chain(k, v)

        return st

    def run(self):
        tmp_chains = list(string.ascii_uppercase)[0: len(self.ch_mapping)]
        # 重命名链名
        model_mapper = dict()
        reference_mapper = dict()

        for idx, (k, v) in enumerate(self.ch_mapping.items()):
            model_mapper[k] = tmp_chains[idx]
            reference_mapper[v] = tmp_chains[idx]

        model_st = self._rename_chains(self.model, model_mapper)
        reference_st = self._rename_chains(self.reference, reference_mapper)

        vals = []

        with tempfile.TemporaryDirectory() as tmp_dir:
            result_file = os.path.join(tmp_dir, "result.json")

            q_file = os.path.join(tmp_dir, "q.pdb")
            r_file = os.path.join(tmp_dir, "r.pdb")

            model_st.to_pdb(q_file, write_minimal_pdb=True)
            reference_st.to_pdb(r_file, write_minimal_pdb=True)

            all_chains = "".join(tmp_chains)
            mapping = f"{all_chains}:{all_chains}"

            _command = f"{self.dockq_program} --mapping {mapping} --json {result_file} {q_file} {r_file}"

            try:
                _ = subprocess.run(_command, shell=True, check=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   timeout=300.0)
            except subprocess.CalledProcessError as e:
                # Handle errors in the called executable
                msg = e.stderr.decode()
            except Exception as e:
                # Handle other exceptions such as file not found or permissions issues
                msg = str(e)
            else:
                if os.path.isfile(result_file):
                    msg = "Success"
                    with open(result_file, "r") as f_in:
                        results = json.load(f_in)

                    if "best_result" in results:
                        reference_mapper_r = {v: k for k, v in reference_mapper.items()}
                        for scores in results["best_result"].values():
                            vals.append(dict(chain1=reference_mapper_r[scores["chain1"]],
                                             chain2=reference_mapper_r[scores["chain2"]],
                                             DockQ=round(scores["DockQ"], 4),
                                             iRMSD=round(scores["iRMSD"], 4)
                                             ))
                else:
                    msg = "No output results"

        return dict(model_path=self.model_path,
                    reference_path=self.reference_path,
                    model_chains=self.model_chains,
                    reference_chains=self.reference_chains,
                    ch_mapping=self.ch_mapping,
                    msg=msg,
                    dq_scores=vals
                    )
