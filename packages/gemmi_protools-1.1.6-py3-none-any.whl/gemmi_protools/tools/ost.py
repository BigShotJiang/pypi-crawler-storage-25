"""
@Author: Luo Jiejian
"""
import json
import os
import shutil
import string
import subprocess
import tempfile
from typing import List, Optional

from gemmi_protools import StructureParser
from gemmi_protools.tools.align import align_sequences


class ChainMappingError(Exception):
    pass


class ChainNumberError(Exception):
    pass


class OSTRunner(object):
    def __init__(self,
                 model_path: str,
                 reference_path: str,
                 model_chains: Optional[List[str]] = None,
                 reference_chains: Optional[List[str]] = None,
                 ch_mapping: Optional[dict] = None,
                 lddt: bool = True,
                 bb_lddt: bool = True,
                 ilddt: bool = True,
                 ics: bool = True,
                 ips: bool = True,
                 dockq: bool = True,
                 tmscore: bool = False,
                 ):
        """
        Args:
            model_path:
            reference_path:
            model_chains:
            reference_chains:
            ch_mapping: dict, chain mapping from model chains to ref chains, default None
        """
        self.model_path = model_path
        self.reference_path = reference_path
        self.model, self.model_chains = self.load_structure(model_path, model_chains)
        self.reference, self.reference_chains = self.load_structure(reference_path, reference_chains)
        self.ch_mapping = self.check_chain_mapping(ch_mapping)

        if not (1 <= len(self.ch_mapping) <= 26):
            raise ChainNumberError(f"Support Structures with 1 ~ 26 chains: got {len(self.ch_mapping)} chains")

        self.ost_program = shutil.which("ost")
        if self.ost_program is None:
            raise RuntimeError("ost is need, install openstructure first")

        self.flags = []
        self.output_keys = []

        if lddt:
            self.flags.append("--lddt")
            self.output_keys.append("lddt")
        if bb_lddt:
            self.flags.append("--bb-lddt")
            self.output_keys.append("bb_lddt")
        if ilddt:
            self.flags.append("--ilddt")
            self.output_keys.append("ilddt")

        if ics:
            self.flags.append("--ics")
            self.output_keys.extend(["contact_reference_interfaces",
                                     "model_contacts", "reference_contacts",
                                     "ics_precision", "ics_recall", "ics",
                                     "per_interface_ics_precision",
                                     "per_interface_ics_recall",
                                     "per_interface_ics"]
                                    )
        if ips:
            self.flags.append("--ips")
            if "--ips" not in self.flags:
                self.output_keys.extend(["contact_reference_interfaces",
                                         "model_contacts", "reference_contacts"]
                                        )

            self.output_keys.extend(["ips_precision", "ips_recall", "ips",
                                     "per_interface_ips_precision",
                                     "per_interface_ips_recall",
                                     "per_interface_ips"]
                                    )

        if dockq:
            self.flags.append("--dockq")
            self.output_keys.extend(["dockq_reference_interfaces",
                                     "dockq_interfaces",
                                     "dockq",
                                     "irmsd"]
                                    )
        if tmscore:
            self.flags.append("--tm-score")
            self.output_keys.extend(["tm_score",
                                     "usalign_mapping"])

    @staticmethod
    def load_structure(path: str, chains: Optional[List[str]] = None):
        st = StructureParser()
        st.load_from_file(path)
        st.clean_structure(remove_ligand=True, remove_hydrogen=True)

        if chains is None:
            return st, st.chain_ids
        else:
            return st.pick_chains(chain_names=chains), chains

    def check_chain_mapping(self, ch_mapping: Optional[dict] = None):
        s_m = set(self.model_chains)
        s_r = set(self.reference_chains)

        if ch_mapping is None:
            # 没有指定，model_chains and ref_chains需一一对应
            model_chains_extra = list(s_m.difference(s_r))
            ref_chains_extra = list(s_r.difference(s_m))

            if model_chains_extra:
                raise ChainMappingError(f"Chains {",".join(model_chains_extra)} not Found for Reference")
            elif ref_chains_extra:
                raise ChainMappingError(f"Chains {",".join(ref_chains_extra)} not Found for Model")
            else:
                return {ch: ch for ch in self.model_chains}
        else:
            mapper_m = set(ch_mapping.keys())
            mapper_r = set(ch_mapping.values())

            if s_m == mapper_m and s_r == mapper_r:
                return ch_mapping
            else:
                raise ChainMappingError(f"Model chains: {self.model_chains}, "
                                        f"Reference chains: {self.reference_chains},"
                                        f"ch_mapping: {ch_mapping}"
                                        )

    @staticmethod
    def _rename_chains(struct: StructureParser, mapper: dict):
        st = struct.pick_chains(struct.chain_ids)

        src2mid = dict()
        mid2tgt = dict()

        for k, v in mapper.items():
            mid = f"MID:{v}"
            src2mid[k] = mid
            mid2tgt[mid] = v

        for k, v in src2mid.items():
            st.rename_chain(k, v)

        for k, v in mid2tgt.items():
            st.rename_chain(k, v)

        return st

    @staticmethod
    def _polymer_resid_mapper(struct: StructureParser):
        out = dict()

        for ch in struct.chain_ids:
            if ch in struct.polymer_types:
                m = dict()
                polymer_chain = struct.get_chain(ch).get_polymer()
                chain_seq = struct.one_letter_code(polymer_chain.extract_sequence())
                for i, res in enumerate(polymer_chain):
                    k = f"{ch}.{res.seqid.num}.{res.seqid.icode.strip()}"
                    m[k] = i + 1
                out[ch] = dict(mapper=m, sequence=chain_seq)
        return out

    def _get_residue_mapper(self, struct1: StructureParser, struct2: StructureParser):
        assert set(struct1.chain_ids) == set(
            struct2.chain_ids), f"Chains are not matching, {struct1.chain_ids} != {struct2.chain_ids}"
        z1 = self._polymer_resid_mapper(struct1)
        z2 = self._polymer_resid_mapper(struct2)

        out = dict()

        for ch in z1.keys():
            s1 = z1[ch]["sequence"]
            m1 = z1[ch]["mapper"]

            s2 = z2[ch]["sequence"]
            m2 = z2[ch]["mapper"]

            aln = align_sequences(s1, s2, mode="global")
            seq_num_mapper = dict()

            for n1, n2 in aln["aligned_aa_mapper"].items():
                try:
                    n2_i = int(n2)
                except ValueError:
                    continue
                else:
                    seq_num_mapper[n1] = n2_i

            m2_r = {v: k for k, v in m2.items()}
            # 从struct1 到 struct2的残基映射
            for res1, seq_num1 in m1.items():
                seq_num2 = seq_num_mapper.get(seq_num1, -1)
                if seq_num2 != -1 and seq_num2 in m2_r:
                    out[res1] = m2_r[seq_num2]
        return out, z1, z2

    def run(self):
        tmp_chains = list(string.ascii_uppercase)[0: len(self.ch_mapping)]
        # 重命名链名
        model_mapper = dict()
        reference_mapper = dict()

        for idx, (k, v) in enumerate(self.ch_mapping.items()):
            model_mapper[k] = tmp_chains[idx]
            reference_mapper[v] = tmp_chains[idx]

        model_st = self._rename_chains(self.model, model_mapper)
        reference_st = self._rename_chains(self.reference, reference_mapper)

        vals = dict()

        with tempfile.TemporaryDirectory() as tmp_dir:
            result_file = os.path.join(tmp_dir, "result.json")

            q_file = os.path.join(tmp_dir, "q.pdb")
            r_file = os.path.join(tmp_dir, "r.pdb")

            model_st.to_pdb(q_file, write_minimal_pdb=True)
            reference_st.to_pdb(r_file, write_minimal_pdb=True)

            mapping = " ".join(f"{ch}:{ch}" for ch in tmp_chains)

            _command = f"{self.ost_program} compare-structures -m {q_file} -r {r_file} -c {mapping} -o {result_file}"

            if self.flags:
                _command = " ".join([_command] + self.flags)

            try:
                _ = subprocess.run(_command, shell=True, check=True,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            except subprocess.CalledProcessError as e:
                # Handle errors in the called executable
                msg = e.stderr.decode()
            except Exception as e:
                # Handle other exceptions such as file not found or permissions issues
                msg = str(e)
            else:
                if os.path.isfile(result_file):
                    msg = "Success"
                    with open(result_file, "r") as f_in:
                        results = json.load(f_in)

                    vals = dict()

                    # 映射回原来chain id
                    model_mapper_r = {v: k for k, v in model_mapper.items()}
                    reference_mapper_r = {v: k for k, v in reference_mapper.items()}

                    model2refer_map, model_map, reference_map = self._get_residue_mapper(model_st, reference_st)

                    # model seqs
                    # site mapper
                    vals["model_sequences"] = {model_mapper_r[ch]: model_map[ch]["sequence"]
                                               for ch in model_map.keys()
                                               }
                    vals["reference_sequences"] = {reference_mapper_r[ch]: reference_map[ch]["sequence"]
                                                   for ch in reference_map.keys()
                                                   }
                    site_mappings = []
                    for site_m, site_r in model2refer_map.items():
                        ch1, res_num1 = site_m.split(".", maxsplit=1)
                        ch2, res_num2 = site_r.split(".", maxsplit=1)
                        site_mappings.append(dict(model_chain=model_mapper_r[ch1],
                                                  model_resnum=res_num1,
                                                  reference_chain=reference_mapper_r[ch2],
                                                  reference_resnum=res_num2
                                                  )
                                             )
                    vals["site_mappings"] = site_mappings

                    for k in self.output_keys:
                        if k in ["contact_reference_interfaces", "dockq_reference_interfaces"]:
                            org_faces = []
                            for ch1, ch2 in results[k]:
                                org_faces.append([reference_mapper_r[ch1], reference_mapper_r[ch2]])
                            vals[k] = org_faces
                        elif k == "dockq_interfaces":
                            dq_faces = []
                            for ch1, ch2, ch3, ch4 in results[k]:
                                dq_faces.append([reference_mapper_r[ch1], reference_mapper_r[ch2],
                                                 model_mapper_r[ch3], model_mapper_r[ch4]
                                                 ])
                            vals[k] = dq_faces
                        elif k in ["model_contacts", "reference_contacts"]:
                            # 处理 contacts
                            if k == "model_contacts":
                                use_site_map = model_map
                                use_ch_map = model_mapper_r
                            else:
                                use_site_map = reference_map
                                use_ch_map = reference_mapper_r

                            contacts = []
                            for site_1, site_2 in results[k]:
                                ch1, res_num1 = site_1.split(".", maxsplit=1)
                                ch2, res_num2 = site_2.split(".", maxsplit=1)

                                seq_num1 = use_site_map[ch1]["mapper"][site_1]
                                seq_num2 = use_site_map[ch2]["mapper"][site_2]

                                contacts.append(dict(chain1=use_ch_map[ch1], resnum1=res_num1, seqnum1=seq_num1,
                                                     chain2=use_ch_map[ch2], resnum2=res_num2, seqnum2=seq_num2,
                                                     )
                                                )
                            vals[k] = contacts
                        else:
                            vals[k] = results[k]
                else:
                    msg = "No output results"

        return dict(model_path=self.model_path,
                    reference_path=self.reference_path,
                    model_chains=self.model_chains,
                    reference_chains=self.reference_chains,
                    ch_mapping=self.ch_mapping,
                    msg=msg,
                    ost_scores=vals
                    )
