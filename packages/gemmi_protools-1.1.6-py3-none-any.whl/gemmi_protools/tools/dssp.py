"""
@Author: Luo Jiejian
"""

import os
import shutil
import subprocess
import tempfile

import gemmi
import pandas as pd


def _read_dssp_contents(dssp_file: str):
    """
    Parameters
    ----------
    dssp_file: str, .cif file from mkdssp outputs

    Returns
    -------

    """
    doc = gemmi.cif.Document()
    _ = gemmi.read_structure(dssp_file, save_doc=doc)
    block = doc.sole_block()

    atoms = pd.DataFrame(block.get_mmcif_category(name="_atom_site", raw=True))
    asym_id = atoms[["label_asym_id", "auth_asym_id"]].drop_duplicates().reset_index(drop=True)

    asym_id_mapper = dict(zip(asym_id["label_asym_id"], asym_id["auth_asym_id"]))
    dk = pd.DataFrame(block.get_mmcif_category(name="_dssp_struct_summary", raw=True))

    if len(dk) > 0:
        ds = dk.groupby("label_asym_id").aggregate(
            pdb_seq=pd.NamedAgg("label_comp_id", lambda s: gemmi.one_letter_code(s.tolist())),
            secondary_structure=pd.NamedAgg("secondary_structure", lambda s: "".join(s.tolist())),
        ).reset_index()
        ds.insert(loc=0, column="auth_asym_id", value=ds["label_asym_id"].apply(lambda s: asym_id_mapper[s]))

        return [ds.iloc[i].to_dict() for i in range(len(ds))]
    else:
        return []


def run_dssp(struct_file: str):
    """
    [Notice]
    struct_file: suggest using raw PDB from RCSB, otherwise DSSP may have some bugs.
    """
    exe_path = shutil.which("mkdssp")
    if exe_path is None:
        raise RuntimeError("mkdssp Not Found")

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_out = os.path.join(tmp_dir, "out.cif")

        commands = [exe_path,
                    "--output-format mmcif",
                    struct_file,
                    tmp_out
                    ]

        _ = subprocess.run(" ".join(commands), shell=True, check=True)
        out = _read_dssp_contents(tmp_out)

    return out
