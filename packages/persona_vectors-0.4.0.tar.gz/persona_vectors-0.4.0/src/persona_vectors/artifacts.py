import json
import os
import warnings
from pathlib import Path

import torch
from persona_data.prompts import BASELINE_PERSONA_ID, BASELINE_PERSONA_NAME
from safetensors.torch import load_file, save_file

PERSONA_VARIANTS: tuple[str, ...] = ("templated", "biography")
SUPPORTED_VARIANTS: tuple[str, ...] = (*PERSONA_VARIANTS, BASELINE_PERSONA_ID)
DEFAULT_MASK_STRATEGY = "answer_mean"
_MANIFEST_FILENAME = "manifest.json"
_TENSOR_KEY = "activations"
_TENSOR_SUFFIX = ".safetensors"


def model_dir_name(model_name: str) -> str:
    return model_name.replace("/", "__")


def _normalize_mask_strategy(mask_strategy: object | None) -> str:
    if mask_strategy is None:
        return DEFAULT_MASK_STRATEGY
    return str(getattr(mask_strategy, "value", mask_strategy))


def _variant_root(
    root_dir: str | Path,
    model_name: str,
    prompt_variant: str,
    mask_strategy: object | None,
) -> Path:
    return (
        Path(root_dir)
        / model_dir_name(model_name)
        / _normalize_mask_strategy(mask_strategy)
        / prompt_variant
    )


def _persona_tensor_path(variant_root: Path, persona_id: str) -> Path:
    if "/" in persona_id or "\\" in persona_id:
        raise ValueError(f"persona_id cannot contain path separators: {persona_id!r}")
    return variant_root / f"{persona_id}{_TENSOR_SUFFIX}"


def _load_manifest(variant_root: Path) -> dict:
    manifest_file = variant_root / _MANIFEST_FILENAME
    if not manifest_file.exists():
        raise FileNotFoundError(manifest_file)
    manifest = json.loads(manifest_file.read_text())
    personas = manifest.get("personas")
    if not isinstance(personas, dict):
        raise ValueError(f"manifest {manifest_file} is missing a personas mapping")
    return manifest


def _variant_manifests(
    root_dir: str | Path,
    model_name: str,
    variants: list[str],
    mask_strategy: object | None,
) -> list[dict]:
    variant_roots = [
        _variant_root(root_dir, model_name, variant, mask_strategy)
        for variant in variants
    ]
    if not variant_roots or any(
        not (root / _MANIFEST_FILENAME).exists() for root in variant_roots
    ):
        return []
    return [_load_manifest(root) for root in variant_roots]


class ActivationStore:
    """Artifact storage for masked-mean activation vectors."""

    def __init__(self, model_name: str, root_dir: str | Path | None = None) -> None:
        self.model_name = model_name
        self.root_dir = (
            Path(root_dir)
            if root_dir is not None
            else Path(os.environ.get("ARTIFACTS_DIR", "artifacts")) / "activations"
        )

    def save(
        self,
        prompt_variant: str,
        persona_id: str,
        persona_name: str,
        per_question_vectors: torch.Tensor,
        sample_ids: list[str],
        mask_strategy: object | None = DEFAULT_MASK_STRATEGY,
    ) -> Path:
        if per_question_vectors.ndim != 3:
            raise ValueError(
                "per_question_vectors must have shape (n_samples, num_layers, hidden_size)"
            )
        if len(sample_ids) != per_question_vectors.shape[0]:
            raise ValueError("number of sample ids must match first tensor dimension")
        if prompt_variant == BASELINE_PERSONA_ID:
            persona_id = BASELINE_PERSONA_ID
            persona_name = BASELINE_PERSONA_NAME

        variant_root = _variant_root(
            self.root_dir, self.model_name, prompt_variant, mask_strategy
        )
        variant_root.mkdir(parents=True, exist_ok=True)

        manifest_path = variant_root / _MANIFEST_FILENAME
        manifest = (
            _load_manifest(variant_root)
            if manifest_path.exists()
            else {
                "num_layers": int(per_question_vectors.shape[1]),
                "hidden_size": int(per_question_vectors.shape[2]),
                "personas": {},
            }
        )
        if manifest.get("num_layers") != int(
            per_question_vectors.shape[1]
        ) or manifest.get("hidden_size") != int(per_question_vectors.shape[2]):
            raise ValueError(
                f"tensor shape for {persona_id!r} does not match existing artifact manifest"
            )

        tensor_path = _persona_tensor_path(variant_root, persona_id)
        save_file({_TENSOR_KEY: per_question_vectors.detach().cpu()}, str(tensor_path))

        manifest["num_layers"] = int(per_question_vectors.shape[1])
        manifest["hidden_size"] = int(per_question_vectors.shape[2])
        if prompt_variant == BASELINE_PERSONA_ID:
            manifest["personas"] = {}
        manifest.setdefault("personas", {})[persona_id] = {
            "name": persona_name,
            "sample_ids": list(sample_ids),
        }
        manifest_path.write_text(json.dumps(manifest, indent=2))
        return variant_root

    def load(
        self,
        prompt_variant: str,
        persona_id: str,
        mask_strategy: object | None = DEFAULT_MASK_STRATEGY,
    ) -> tuple[torch.Tensor, list[str]]:
        requested = _normalize_mask_strategy(mask_strategy)
        variant_root = _variant_root(
            self.root_dir, self.model_name, prompt_variant, requested
        )
        manifest = _load_manifest(variant_root)
        entry = manifest["personas"].get(persona_id)
        if not isinstance(entry, dict):
            raise FileNotFoundError(
                f"No activations found for {self.model_name!r} / {prompt_variant!r} / {requested!r} / {persona_id!r}"
            )

        tensor_path = _persona_tensor_path(variant_root, persona_id)
        if not tensor_path.exists():
            raise FileNotFoundError(tensor_path)
        tensors = load_file(str(tensor_path))
        if _TENSOR_KEY not in tensors:
            raise FileNotFoundError(f"Missing {_TENSOR_KEY!r} tensor in {tensor_path}")

        vectors = tensors[_TENSOR_KEY]
        if vectors.ndim != 3:
            raise ValueError(
                f"tensor for {persona_id!r} must have shape (n_samples, num_layers, hidden_size)"
            )

        sample_ids = entry.get("sample_ids")
        if not isinstance(sample_ids, list):
            raise ValueError(f"manifest entry for {persona_id} is missing sample ids")
        if len(sample_ids) != vectors.shape[0]:
            raise ValueError(
                f"sample ids for {persona_id!r} do not match tensor length"
            )
        return vectors, [str(sample_id) for sample_id in sample_ids]


def list_personas(
    root_dir: str | Path,
    model_name: str,
    variants: list[str],
    mask_strategy: object | None = DEFAULT_MASK_STRATEGY,
    warn_missing: bool = True,
) -> list[str]:
    if not variants:
        return []

    variant_roots = {
        variant: _variant_root(root_dir, model_name, variant, mask_strategy)
        for variant in variants
    }
    if any(not (root / _MANIFEST_FILENAME).exists() for root in variant_roots.values()):
        return []

    variant_personas = {
        variant: set(_load_manifest(root)["personas"].keys())
        for variant, root in variant_roots.items()
    }
    shared = set.intersection(*variant_personas.values())

    if warn_missing and len(variant_personas) > 1:
        all_personas = set.union(*variant_personas.values())
        skipped = len(all_personas - shared)
        if skipped:
            warnings.warn(
                f"Skipping {skipped} persona(s) missing one or more requested variants.",
                stacklevel=2,
            )

    return sorted(shared)


def load_persona_names(
    root_dir: str | Path,
    model_name: str,
    variants: list[str],
    persona_ids: list[str],
    mask_strategy: object | None = DEFAULT_MASK_STRATEGY,
) -> dict[str, str]:
    manifests = _variant_manifests(root_dir, model_name, variants, mask_strategy)
    if not manifests:
        return {}

    names: dict[str, str] = {}
    for persona_id in persona_ids:
        for manifest in manifests:
            entry = manifest["personas"].get(persona_id)
            if isinstance(entry, dict):
                name = entry.get("name")
                if isinstance(name, str) and name:
                    names[persona_id] = name
                    break
    return names


def list_layers(
    root_dir: str | Path,
    model_name: str,
    variants: list[str],
    persona_ids: list[str],
    mask_strategy: object | None = DEFAULT_MASK_STRATEGY,
) -> list[int]:
    manifests = _variant_manifests(root_dir, model_name, variants, mask_strategy)
    if not manifests:
        return []

    if persona_ids:
        shared_personas = set.intersection(
            *(set(manifest["personas"].keys()) for manifest in manifests)
        )
        if not set(persona_ids) <= shared_personas:
            return []

    shared_layers: set[int] | None = None
    for manifest in manifests:
        num_layers = manifest.get("num_layers")
        if isinstance(num_layers, int) and num_layers >= 0:
            layers = set(range(num_layers))
            shared_layers = layers if shared_layers is None else shared_layers & layers
    return sorted(shared_layers or set())


def load_mean_activations(
    root_dir: str | Path,
    model_name: str,
    persona_ids: list[str],
    variant_a: str,
    variant_b: str,
    mask_strategy: object | None = DEFAULT_MASK_STRATEGY,
) -> tuple[list[tuple[str, torch.Tensor, torch.Tensor]], dict[str, str], list[str]]:
    store = ActivationStore(model_name, root_dir)
    persona_names = load_persona_names(
        root_dir,
        model_name,
        [variant_a, variant_b],
        persona_ids,
        mask_strategy=mask_strategy,
    )

    traces: list[tuple[str, torch.Tensor, torch.Tensor]] = []
    errors: list[str] = []

    for persona_id in persona_ids:
        try:
            vectors_a, _ = store.load(
                variant_a, persona_id, mask_strategy=mask_strategy
            )
            vectors_b, _ = store.load(
                variant_b, persona_id, mask_strategy=mask_strategy
            )
        except (FileNotFoundError, KeyError, OSError, ValueError) as exc:
            errors.append(f"{persona_id}: {exc}")
            continue

        traces.append(
            (
                persona_id,
                vectors_a.float().mean(dim=0),
                vectors_b.float().mean(dim=0),
            )
        )

    return traces, persona_names, errors
