"""
### Tribulnation Bitso
> An SDK to connect Bitso with the Tribulnation ecosystem.

- Details
"""