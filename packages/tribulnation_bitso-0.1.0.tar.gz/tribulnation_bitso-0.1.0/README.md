# Tribulnation Bitso SDK

> An SDK to connect Bitso with the Tribulnation ecosystem.

🚧 Under construction.