

class BlockDevHandle:
    pass