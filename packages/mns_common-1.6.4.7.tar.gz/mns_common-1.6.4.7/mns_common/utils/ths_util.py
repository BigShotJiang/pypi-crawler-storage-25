import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)

import json
import os


class THSSelfStockJSON:
    """同花顺SelfStockInfo.json自选股操作类"""

    def __init__(self, json_file_path):
        """
        初始化
        :param json_file_path: SelfStockInfo.json文件的完整路径
        """
        self.json_path = json_file_path
        # 检查文件是否存在，不存在则创建空列表
        if not os.path.exists(self.json_path):
            with open(self.json_path, 'w', encoding='utf-8') as f:
                json.dump([], f, ensure_ascii=False, indent=2)

    def _read_json(self):
        """读取JSON文件，返回股票列表"""
        try:
            with open(self.json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            # 确保读取的是列表格式
            if not isinstance(data, list):
                return []
            return data
        except Exception as e:
            raise Exception(f"读取JSON文件失败：{e}")

    def _write_json(self, stock_list):
        """写入JSON文件（带格式化，便于查看）"""
        try:
            # 备份原文件
            backup_path = self.json_path + ".bak"
            if os.path.exists(self.json_path) and not os.path.exists(backup_path):
                with open(self.json_path, 'r', encoding='utf-8') as f:
                    backup_data = json.load(f)
                with open(backup_path, 'w', encoding='utf-8') as f:
                    json.dump(backup_data, f, ensure_ascii=False, indent=2)

            # 写入新数据
            with open(self.json_path, 'w', encoding='utf-8') as f:
                json.dump(stock_list, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            raise Exception(f"写入JSON文件失败：{e}")

    def get_all_stocks(self):
        """查询：获取所有自选股"""
        stocks = self._read_json()
        print(f"当前自选股总数：{len(stocks)}")
        for idx, stock in enumerate(stocks, 1):
            print(f"{idx}. 代码：{stock['C']}，市场：{stock['M']}，价格：{stock['P']}，日期：{stock['T']}")
        return stocks

    def get_stock_by_code(self, code):
        """查询：根据股票代码查找单只股票"""
        stocks = self._read_json()
        for stock in stocks:
            if stock['C'] == code:
                return stock
        return None

    def add_stock(self, code, market, price="", date=""):
        """
        新增：添加一只自选股
        :param code: 股票代码（如600722）
        :param market: 市场标识（如17/33/48）
        :param price: 价格（可选，默认空）
        :param date: 日期（可选，默认空，格式如20260306）
        """
        # 检查是否已存在
        if self.get_stock_by_code(code):
            print(f"股票代码 {code} 已存在，无需重复添加")
            return False

        stocks = self._read_json()
        # 构造新股票数据
        new_stock = {
            "C": code,
            "M": market,
            "P": price,
            "T": date
        }
        stocks.append(new_stock)
        # 写入文件
        self._write_json(stocks)
        print(f"股票代码 {code} 已成功添加")
        return True

    def delete_stock(self, code):
        """
        删除：根据股票代码删除自选股
        :param code: 股票代码（如600722）
        """
        stocks = self._read_json()
        # 筛选保留的股票（排除要删除的）
        new_stocks = [s for s in stocks if s['C'] != code]

        if len(new_stocks) == len(stocks):
            print(f"未找到股票代码 {code}，删除失败")
            return False

        self._write_json(new_stocks)
        print(f"股票代码 {code} 已成功删除")
        return True

    def update_stock(self, code, new_price=None, new_date=None, new_market=None):
        """
        修改：更新股票的价格/日期/市场标识
        :param code: 股票代码
        :param new_price: 新价格（可选）
        :param new_date: 新日期（可选）
        :param new_market: 新市场标识（可选）
        """
        stocks = self._read_json()
        updated = False
        for stock in stocks:
            if stock['C'] == code:
                # 只更新传入的参数
                if new_price is not None:
                    stock['P'] = new_price
                if new_date is not None:
                    stock['T'] = new_date
                if new_market is not None:
                    stock['M'] = new_market
                updated = True
                break

        if not updated:
            print(f"未找到股票代码 {code}，修改失败")
            return False

        self._write_json(stocks)
        print(f"股票代码 {code} 已成功更新")
        return True


# ------------------- 测试使用示例 -------------------
if __name__ == "__main__":
    # 替换为你的SelfStockInfo.json文件实际路径
    json_file = r"D:\Program Files\ths\景行pM\SelfStockInfo.json"

    # 初始化操作类
    ths_json = THSSelfStockJSON(json_file)

    # 1. 查询所有自选股
    print("=== 所有自选股 ===")
    ths_json.get_all_stocks()

    # 2. 查询单只股票
    print("\n=== 查询单只股票（600722）===")
    stock = ths_json.get_stock_by_code("301575")
    if stock:
        print(f"找到股票：{stock}")
    else:
        print("未找到该股票")

    # 3. 新增股票（示例：添加600000，市场17，价格10.00，日期20260307）
    ths_json.add_stock("600089", "17", "32.23", "20260307")

    # 4. 修改股票（示例：修改600722的价格为12.80）
    ths_json.update_stock("600089", new_price="32.24")

    # 5. 删除股票（示例：删除886067）
    ths_json.delete_stock("886067")