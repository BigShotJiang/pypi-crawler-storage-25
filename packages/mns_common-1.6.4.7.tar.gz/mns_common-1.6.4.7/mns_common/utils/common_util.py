import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)
from datetime import datetime


def get_tqdm(enable: bool = True):
    """
    返回适用于当前环境的 tqdm 对象。

    Args:
        enable (bool): 是否启用进度条。默认为 True。

    Returns:
        tqdm 对象。
    """
    if not enable:
        # 如果进度条被禁用，返回一个不显示进度条的 tqdm 对象
        return lambda iterable, *args, **kwargs: iterable

    try:
        # 尝试检查是否在 jupyter notebook 环境中，有利于退出进度条
        # noinspection PyUnresolvedReferences
        shell = get_ipython().__class__.__name__
        if shell == "ZMQInteractiveShell":
            from tqdm.notebook import tqdm
        else:
            from tqdm import tqdm
    except (NameError, ImportError):
        # 如果不在 Jupyter 环境中，就使用标准 tqdm
        from tqdm import tqdm

    return tqdm


def generate_finance_quarter_dates(start_year=1991):
    """
    生成1991年到当前日期的所有财报季度结束日期，格式8位数字（如20251231）
    :param start_year: 起始年份，默认1991
    :return: 倒序列表（最新季度在前），元素为8位数字字符串
    """
    # 财报季度结束月份（固定），对应Q1-Q4
    quarter_end_months = [3, 6, 9, 12]
    # 每个季度结束的日期（固定）
    quarter_end_day = 30 if quarter_end_months in [6, 9] else 31
    # 获取当前时间
    now = datetime.now()
    current_year = now.year
    current_month = now.month

    quarter_dates = []
    # 遍历从起始年到当前年的每一年
    for year in range(start_year, current_year + 1):
        # 遍历每个季度的结束月份
        for month in quarter_end_months:
            # 跳过当前年中「未结束的季度」
            if current_year == year and month >= 4 and month > current_month:
                continue

                # 构造季度结束日期（处理3/12月31日，6/9月30日）
            day = 31 if month in (3, 12) else 30
            quarter_date = datetime(year, month, day)
            # 格式化为8位数字字符串（如20251231）
            quarter_dates.append(quarter_date.strftime("%Y%m%d"))

    # 倒序排列：最新季度在前（符合日常查看习惯）
    quarter_dates.reverse()
    return quarter_dates


if __name__ == '__main__':
    quarters = generate_finance_quarter_dates(2020)
    print(quarters)
