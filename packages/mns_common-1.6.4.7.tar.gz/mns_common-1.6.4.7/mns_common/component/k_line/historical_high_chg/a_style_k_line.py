from loguru import logger
from mns_common.db.MongodbUtil import MongodbUtil
import mns_common.component.common_service_fun_api as common_service_fun_api
import mns_common.utils.data_frame_util as data_frame_util

mongodb_util = MongodbUtil('27017')
import mns_common.constant.db_name_constant as db_name_constant

DAYS = 60  # 最近60个交易日
MIN_RISE = 0.5  # 低点 → 高点涨幅 ≥50%
AFTER_PEAK_DAYS = 3  # 见顶后至少跌3天（形成右腿）
FALL_RATIO = 0.85  # 现价低于高点的15%


def find_company(symbol_list):
    if len(symbol_list) == 0:
        query = {"deal_days": {"$gte": 60}}
    else:
        query = {
            'symbol': {"$in": symbol_list}}
    query_field = {'symbol': 1, 'name': 1, 'deal_days': 1, 'industry': 1}
    company_info = mongodb_util.find_query_data_choose_field('company_info', query, query_field)
    company_info = common_service_fun_api.exclude_st_symbol(company_info)
    company_info = common_service_fun_api.exclude_change_bjs_code(company_info)
    return company_info


def get_qfq_k_line_data(symbol, begin_day, end_day):
    query = {'symbol': symbol,
             "$and": [{'date': {"$gte": begin_day}},
                      {'date': {"$lte": end_day}}, ]
             }
    return mongodb_util.find_query_data(db_name_constant.STOCK_QFQ_DAILY, query)


def get_a_shape_stocks(symbol_list):
    company_info = find_company(symbol_list)
    for company_one in company_info.itertuples():
        symbol = company_one.symbol
        # 股票名称
        name = company_one.name
        try:

            query = {'symbol': symbol}
            stock_qfq_daily_df = mongodb_util.descend_query(query, 'stock_qfq_daily', 'date', 60)
            if data_frame_util.is_empty(stock_qfq_daily_df):
                continue

            stock_qfq_daily_df = stock_qfq_daily_df.sort_values(by=['date'], ascending=True)

            # 获取 前复权 日K线
            df = stock_qfq_daily_df.copy()
            df = df.tail(DAYS).copy()  # 取最近60日
            if len(df) < DAYS:
                continue

            # ==============================================
            # 【核心修复】严格 A 字逻辑
            # ==============================================
            # 1. 找到60日内最高点 & 位置
            high_price = df["high"].max()
            peak_row = df[df["high"] == high_price].iloc[0]
            peak_date = peak_row["date"]  # 最高点日期
            peak_pos = df.index.get_loc(peak_row.name)

            # 2. 最高点必须出现在“后半段之前”，保证有足够下跌空间
            if peak_pos > DAYS * 0.8:
                continue

                # ========== 2. 只在最高点左侧找最低点 & 日期 ==========
            df_before = df.iloc[:peak_pos + 1]
            low_price = df_before["low"].min()
            low_row = df_before[df_before["low"] == low_price].iloc[0]
            low_date = low_row["date"]  # 左侧最低点日期

            # ========== 3. 计算涨幅 ==========
            rise_rate = (high_price / low_price) - 1
            if rise_rate < MIN_RISE:
                continue

            # 5. 见顶后必须下跌（形成A字右边）
            df_after_peak = df.iloc[peak_pos + 1:]
            if len(df_after_peak) < AFTER_PEAK_DAYS:
                continue

            current_close = df["close"].iloc[-1]
            if current_close / high_price > FALL_RATIO:
                continue

            logger.info("出现A形状股票:{},{},最高点:{},左侧最低点:{}", symbol, name, peak_date, low_date)
        except BaseException as e:
            logger.error("计算形状出现异常:{},{}", symbol, name)


if __name__ == '__main__':
    get_a_shape_stocks([])
