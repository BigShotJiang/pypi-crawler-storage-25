import sys
import os

file_path = os.path.abspath(__file__)
end = file_path.index('mns') + 16
project_path = file_path[0:end]
sys.path.append(project_path)
import pandas as pd
import requests
import mns_common.utils.common_util as common_util
from loguru import logger


# 获取十大股东
def stock_gdfx_holding_analyse_em(date, is_new):
    """
    东方财富网-数据中心-股东分析-股东持股分析-十大股东
    https://data.eastmoney.com/gdfx/HoldingAnalyse.html
    :param date: 报告期
    :type date: str
    :return: 十大股东
    :rtype: pandas.DataFrame
    """
    url = "https://datacenter-web.eastmoney.com/api/data/v1/get"
    params = {
        "sortColumns": "NOTICE_DATE,SECURITY_CODE,RANK",
        "sortTypes": "-1,1,1",
        "pageSize": "500",
        "pageNumber": "1",
        "reportName": "RPT_CUSTOM_DMSK_HOLDERS_JOIN_HOLDER_SHAREANALYSIS",
        "columns": "ALL;D10_ADJCHRATE,D30_ADJCHRATE,D60_ADJCHRATE",
        "source": "WEB",
        "client": "WEB",
        "filter": f"(END_DATE='{'-'.join([date[:4], date[4:6], date[6:]])}')",
    }
    if is_new:
        params.update(
            {"filter": f"""(LISTING_STATE!=\"10\")(END_DATE>='{'-'.join([date[:4], date[4:6], date[6:]])}')"""})
    else:
        params.update(
            {"filter": f"""(LISTING_STATE!=\"10\")(END_DATE='{'-'.join([date[:4], date[4:6], date[6:]])}')"""})
    r = requests.get(url, params=params)
    data_json = r.json()
    total_page = data_json["result"]["pages"]
    temp_big_df = pd.DataFrame()
    tqdm = common_util.get_tqdm()
    for page in tqdm(range(1, total_page + 1), leave=False):
        try:
            params.update({"pageNumber": page})
            r = requests.get(url, params=params)
            data_json = r.json()
            temp_df = pd.DataFrame(data_json["result"]["data"])
            temp_big_df = pd.concat(objs=[temp_big_df, temp_df], ignore_index=True)
        except BaseException as e:
            logger.error("获取十大股东数据异常:{},{}", str(e), date)

    big_df = temp_big_df.copy()
    big_df.reset_index(inplace=True)
    big_df["index"] = big_df.index + 1
    big_df.rename(
        columns={
            "SECURITY_CODE": "symbol",
            "HOLDER_NAME": "shareholder_name",
            "HOLDER_TYPE_ORG": "shareholder_nature",
            "SHARES_TYPE": "shares_type",
            "HOLD_NUM": "shares_number",
            "HOLD_RATIO": "circulation_ratio",
            "HOLD_NUM_CHANGE": "change",
            "HOLD_RATIO_CHANGE": "change_ratio",
            "HOLD_CHANGE": "change_name",
            "SHARES_TYPE": "shares_type",
            "HOLDER_NATURE": "holder_nature",
            'D10_ADJCHRATE': "d10_adjchrate",
            'D30_ADJCHRATE': "d30_adjchrate",
            'D60_ADJCHRATE': "d60_adjchrate",
            'END_DATE': "end_date",
            'HOLDER_NEWTYPE': 'holder_newtype'
        },
        inplace=True,
    )

    big_df["end_date"] = pd.to_datetime(big_df["end_date"], errors="coerce").dt.date

    big_df["end_date"] = pd.to_datetime(big_df["end_date"]).dt.strftime("%Y-%m-%d")
    # big_df["公告日"] = pd.to_datetime(big_df["公告日"], errors="coerce").dt.date

    big_df["d10_adjchrate"] = pd.to_numeric(
        big_df["d10_adjchrate"], errors="coerce"
    )

    big_df["d60_adjchrate"] = pd.to_numeric(
        big_df["d60_adjchrate"], errors="coerce"
    )

    big_df["d30_adjchrate"] = pd.to_numeric(
        big_df["d30_adjchrate"], errors="coerce"
    )

    big_df["shares_number"] = pd.to_numeric(
        big_df["shares_number"], errors="coerce"
    )
    big_df["circulation_ratio"] = pd.to_numeric(
        big_df["circulation_ratio"], errors="coerce"
    )

    big_df["change_ratio"] = pd.to_numeric(
        big_df["change_ratio"], errors="coerce"
    )

    big_df.loc[:, 'circulation_ratio'] = big_df['circulation_ratio'].fillna(0)
    big_df.loc[:, 'change_ratio'] = big_df['change_ratio'].fillna(0)
    big_df.loc[:, 'change'] = big_df['change'].fillna(0)

    big_df.loc[:, 'd10_adjchrate'] = big_df['d10_adjchrate'].fillna(0)
    big_df.loc[:, 'd30_adjchrate'] = big_df['d30_adjchrate'].fillna(0)
    big_df.loc[:, 'd60_adjchrate'] = big_df['d60_adjchrate'].fillna(0)

    big_df = big_df[[
        "index",
        "symbol",
        "shareholder_name",
        "shareholder_nature",
        "shares_type",
        "shares_number",
        "circulation_ratio",
        "change",
        "change_ratio",
        'change_name',
        'shares_type',
        'holder_nature',
        "d10_adjchrate",
        "d30_adjchrate",
        "d60_adjchrate",
        "end_date",
        "holder_newtype"
    ]]
    big_df['shares_number_str'] = big_df['shares_number'].astype(str)
    big_df['period'] = date
    return big_df


if __name__ == '__main__':
    stock_gdfx_holding_analyse_em('20251231', False)
