"""Typed spec models for csrd compose."""

from __future__ import annotations

from pydantic import Field, field_validator

from .base import BaseModel
from .types import OptionsMap


class WorkspaceConfig(BaseModel):
    """Workspace-level metadata for compose rendering."""

    name: str = "workspace"
    git_init: bool = False


class PresetRef(BaseModel):
    """Preset reference with optional options map."""

    name: str
    options: OptionsMap = Field(default_factory=dict)


class ServiceNode(BaseModel):
    """Single service entry in the compose spec.

    Services declare the infrastructure they need via *features* — a list
    of capability tags such as ``"database"``, ``"caching"``, or
    ``"messaging"``.  The renderer inspects these tags to inject the
    correct ``depends_on``, ``environment``, and ``volumes`` entries,
    wiring each service to the workspace's configured infra.
    """

    name: str
    role: str = "custom"
    port: int = 8080
    features: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Infrastructure
# ---------------------------------------------------------------------------

INFRA_DATABASES = frozenset({"postgres", "mariadb", "sqlite"})
INFRA_MESSAGING = frozenset({"rabbitmq"})
INFRA_CACHING = frozenset({"redis"})
INFRA_ALL_TYPES = INFRA_DATABASES | INFRA_MESSAGING | INFRA_CACHING

# Category definitions: (label, member types, single-select?)
INFRA_CATEGORIES: list[tuple[str, frozenset[str], bool]] = [
    ("database", INFRA_DATABASES, True),
    ("messaging", INFRA_MESSAGING, True),
    ("caching", INFRA_CACHING, True),
]


class InfraNode(BaseModel):
    """Single infrastructure entry in the compose spec."""

    type: str

    @field_validator("type")
    @classmethod
    def _validate_type(cls, value: str) -> str:
        if value not in INFRA_ALL_TYPES:
            raise ValueError(
                f"Unknown infra type '{value}'. "
                f"Must be one of: {', '.join(sorted(INFRA_ALL_TYPES))}"
            )
        return value


class ComposeSpec(BaseModel):
    """Canonical top-level model for `csrd-compose.yaml`."""

    version: int = 1
    workspace: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    presets: list[PresetRef] = Field(default_factory=list)
    services: list[ServiceNode] = Field(default_factory=list)
    infra: list[InfraNode] = Field(default_factory=list)
    overrides: dict[str, object] = Field(default_factory=dict)

    @field_validator("version")
    @classmethod
    def _validate_version(cls, value: int) -> int:
        if value != 1:
            raise ValueError("Only compose spec version 1 is supported")
        return value


from dataclasses import dataclass, field  # noqa: E402


@dataclass(frozen=True)
class PresetDefinition:
    """Declarative workspace preset."""

    name: str
    description: str
    required_infra_categories: list[str] = field(default_factory=list)
    optional_infra_categories: list[str] = field(default_factory=list)
    services: list[ServiceNode] = field(default_factory=list)
