"""Type aliases for recurring patterns across the v2 package."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

#: Factory that returns ``(service_dict, volumes_dict)`` for an infra container.
InfraRenderer = Callable[[], tuple[dict[str, Any], dict[str, None]]]

#: Options map used by ``PresetRef`` and ``PresetDefinition``.
OptionsMap = dict[str, str]
