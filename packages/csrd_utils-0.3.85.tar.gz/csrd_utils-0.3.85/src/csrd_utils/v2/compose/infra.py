"""Infrastructure container definitions for docker-compose rendering.

Each definition is a pure data function — no I/O, no side effects.
The renderer calls these to build the ``services`` and ``volumes``
sections of ``docker-compose.yml``.
"""

from __future__ import annotations

from typing import Any

from ..models import InfraRenderer

# ---------------------------------------------------------------------------
# Healthcheck presets
# ---------------------------------------------------------------------------


def _healthcheck(
    test: list[str], interval: str = "5s", timeout: str = "3s", retries: int = 3
) -> dict[str, Any]:
    return {
        "test": test,
        "interval": interval,
        "timeout": timeout,
        "retries": retries,
        "start_period": "10s",
    }


# ---------------------------------------------------------------------------
# Container definitions
# ---------------------------------------------------------------------------


def postgres_service() -> tuple[dict[str, Any], dict[str, None]]:
    """Return (service_dict, volumes_dict) for a Postgres container."""

    service: dict[str, Any] = {
        "image": "postgres:16-alpine",
        "restart": "unless-stopped",
        "environment": {
            "POSTGRES_DB": "${DB_NAME:-service_db}",
            "POSTGRES_USER": "${DB_USER:-service_user}",
            "POSTGRES_PASSWORD": "${DB_PASSWORD:-change_me}",
        },
        "ports": ["5432:5432"],
        "volumes": ["postgres-data:/var/lib/postgresql/data"],
        "healthcheck": _healthcheck(
            ["CMD-SHELL", "pg_isready -U ${DB_USER:-service_user} -d ${DB_NAME:-service_db}"],
        ),
    }
    volumes: dict[str, None] = {"postgres-data": None}
    return service, volumes


def mariadb_service() -> tuple[dict[str, Any], dict[str, None]]:
    """Return (service_dict, volumes_dict) for a MariaDB container."""

    service: dict[str, Any] = {
        "image": "mariadb:11",
        "restart": "unless-stopped",
        "environment": {
            "MYSQL_ROOT_PASSWORD": "${MYSQL_ROOT_PASSWORD:-change_me_root}",
            "MYSQL_DATABASE": "${DB_NAME:-service_db}",
            "MYSQL_USER": "${DB_USER:-service_user}",
            "MYSQL_PASSWORD": "${DB_PASSWORD:-change_me}",
        },
        "ports": ["3306:3306"],
        "volumes": ["mariadb-data:/var/lib/mysql"],
        "healthcheck": _healthcheck(
            ["CMD", "healthcheck.sh", "--connect", "--innodb_initialized"],
        ),
    }
    volumes: dict[str, None] = {"mariadb-data": None}
    return service, volumes


def redis_service() -> tuple[dict[str, Any], dict[str, None]]:
    """Return (service_dict, volumes_dict) for a Redis container."""

    service: dict[str, Any] = {
        "image": "redis:7-alpine",
        "restart": "unless-stopped",
        "ports": ["6379:6379"],
        "healthcheck": _healthcheck(
            ["CMD", "redis-cli", "ping"],
        ),
    }
    return service, {}


def rabbitmq_service() -> tuple[dict[str, Any], dict[str, None]]:
    """Return (service_dict, volumes_dict) for a RabbitMQ container."""

    service: dict[str, Any] = {
        "image": "rabbitmq:3-management-alpine",
        "restart": "unless-stopped",
        "environment": {
            "RABBITMQ_DEFAULT_USER": "${RABBITMQ_USER:-service_rabbit}",
            "RABBITMQ_DEFAULT_PASS": "${RABBITMQ_PASSWORD:-change_me}",
        },
        "ports": ["5672:5672", "15672:15672"],
        "healthcheck": _healthcheck(
            ["CMD", "rabbitmq-diagnostics", "-q", "ping"],
        ),
    }
    return service, {}


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

INFRA_RENDERERS: dict[str, InfraRenderer] = {
    "postgres": postgres_service,
    "mariadb": mariadb_service,
    "redis": redis_service,
    "rabbitmq": rabbitmq_service,
}
"""Map infra type name → factory that returns ``(service_dict, volumes_dict)``."""


def render_infra(infra_type: str) -> tuple[str, dict[str, Any], dict[str, None]]:
    """Render an infra type into its compose service name, service dict, and volumes.

    Raises ``KeyError`` if *infra_type* has no renderer (e.g. ``sqlite``
    which needs no container).
    """

    factory = INFRA_RENDERERS[infra_type]
    service_def, volumes = factory()
    return infra_type, service_def, volumes


# ---------------------------------------------------------------------------
# Service environment wiring
# ---------------------------------------------------------------------------


def service_env_block(db_type: str) -> dict[str, str]:
    """Return the environment variables a service needs to connect to *db_type*.

    For ``postgres``/``mariadb`` the vars point at the shared infra container.
    For ``sqlite`` the var points at a local file path (volume-mounted).
    """

    if db_type == "postgres":
        return {
            "DB_HOST": "postgres",
            "DB_PORT": "5432",
            "DB_NAME": "${DB_NAME:-service_db}",
            "DB_USER": "${DB_USER:-service_user}",
            "DB_PASSWORD": "${DB_PASSWORD:-change_me}",
        }
    if db_type == "mariadb":
        return {
            "DB_HOST": "mariadb",
            "DB_PORT": "3306",
            "DB_NAME": "${DB_NAME:-service_db}",
            "DB_USER": "${DB_USER:-service_user}",
            "DB_PASSWORD": "${DB_PASSWORD:-change_me}",
        }
    if db_type == "sqlite":
        # DB_PATH is set per-service in the renderer; this is the base template.
        return {}
    return {}


def service_depends_on(db_type: str) -> dict[str, Any]:
    """Return ``depends_on`` entries for a service wired to *db_type*.

    ``sqlite`` returns empty (no container dependency).
    """

    if db_type in {"postgres", "mariadb"}:
        return {db_type: {"condition": "service_healthy"}}
    return {}
