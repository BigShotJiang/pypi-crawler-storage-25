"""Renderer for workspace artifacts."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..models import ComposeSpec, ServiceNode
from .git import maybe_git_init
from .infra import INFRA_RENDERERS, render_infra, service_depends_on, service_env_block
from .loader import default_spec, load_spec, save_spec, spec_file_path
from .yaml_editor import dumps_yaml

WORKSPACE_MARKER_FILENAME = ".csrd-workspace"


# ---------------------------------------------------------------------------
# docker-compose.yml rendering
# ---------------------------------------------------------------------------


def _render_service(
    svc: ServiceNode,
    *,
    spec: ComposeSpec,
    base_port_offset: int,
) -> tuple[dict[str, Any], dict[str, None]]:
    """Build a compose service dict and its volumes for a single ServiceNode.

    Wiring is driven by the service's *features* list.  Each feature
    (``database``, ``caching``, ``messaging``) contributes ``depends_on``,
    ``environment``, and/or ``volumes`` entries sourced from the workspace
    infra configuration.

    Returns ``(service_dict, volumes_dict)``.
    """

    svc_def: dict[str, Any] = {
        "build": f"./src/{svc.name}",
        "ports": [f"{svc.port + base_port_offset}:{svc.port + base_port_offset}"],
        "env_file": ".env",
    }

    deps: dict[str, Any] = {}
    env: dict[str, str] = {}
    volumes: dict[str, None] = {}

    infra_types = {n.type for n in spec.infra}

    # --- database capability ---
    if "database" in svc.features:
        db = _detect_configured_db(spec)
        if db == "sqlite":
            vol_name = f"{svc.name}-data"
            svc_def["volumes"] = [f"{vol_name}:/app/data"]
            env["DB_PATH"] = f"/app/data/{svc.name}.db"
            volumes[vol_name] = None
        elif db in {"postgres", "mariadb"}:
            deps.update(service_depends_on(db))
            env.update(service_env_block(db))

    # --- caching capability ---
    if "caching" in svc.features and "redis" in infra_types:
        deps["redis"] = {"condition": "service_healthy"}
        env["REDIS_URL"] = "redis://redis:6379/0"

    # --- messaging capability ---
    if "messaging" in svc.features and "rabbitmq" in infra_types:
        deps["rabbitmq"] = {"condition": "service_healthy"}
        env["RABBITMQ_URL"] = (
            "amqp://${RABBITMQ_USER:-service_rabbit}:${RABBITMQ_PASSWORD:-change_me}@rabbitmq:5672/"
        )

    if deps:
        svc_def["depends_on"] = deps
    if env:
        svc_def["environment"] = env

    return svc_def, volumes


def _render_compose(spec: ComposeSpec) -> str:
    """Build the full ``docker-compose.yml`` content from the spec."""

    services: dict[str, Any] = {}
    volumes: dict[str, None] = {}

    # --- Infra containers first ---
    for infra_node in spec.infra:
        if infra_node.type not in INFRA_RENDERERS:
            continue  # sqlite — no container needed
        name, svc_def, vol_defs = render_infra(infra_node.type)
        services[name] = svc_def
        volumes.update(vol_defs)

    # --- Application services ---
    for svc in spec.services:
        svc_def, svc_volumes = _render_service(svc, spec=spec, base_port_offset=0)
        services[svc.name] = svc_def
        volumes.update(svc_volumes)

    payload: dict[str, Any] = {"services": services}
    if volumes:
        payload["volumes"] = volumes

    return dumps_yaml(payload)


def _detect_configured_db(spec: ComposeSpec) -> str | None:
    """Return the database type configured in the spec, or ``None``."""

    from ..models import INFRA_DATABASES

    for node in spec.infra:
        if node.type in INFRA_DATABASES:
            return node.type
    return None


# ---------------------------------------------------------------------------
# Env example rendering
# ---------------------------------------------------------------------------


def _render_env_example(spec: ComposeSpec) -> str:
    """Build ``.env.example`` with sensible defaults for configured infra."""

    lines = ["# Workspace defaults\n"]

    infra_types = {n.type for n in spec.infra}

    if infra_types & {"postgres", "mariadb"}:
        lines.append("# Database")
        lines.append("DB_NAME=service_db")
        lines.append("DB_USER=service_user")
        lines.append("DB_PASSWORD=change_me")
        if "postgres" in infra_types:
            lines.append("DB_HOST=postgres")
            lines.append("DB_PORT=5432")
        elif "mariadb" in infra_types:
            lines.append("DB_HOST=mariadb")
            lines.append("DB_PORT=3306")
            lines.append("MYSQL_ROOT_PASSWORD=change_me_root")
        lines.append("")

    if "redis" in infra_types:
        lines.append("# Redis")
        lines.append("REDIS_URL=redis://redis:6379/0")
        lines.append("")

    if "rabbitmq" in infra_types:
        lines.append("# RabbitMQ")
        lines.append("RABBITMQ_USER=service_rabbit")
        lines.append("RABBITMQ_PASSWORD=change_me")
        lines.append("RABBITMQ_URL=amqp://service_rabbit:change_me@rabbitmq:5672/")
        lines.append("")

    return "\n".join(lines) + "\n"


def _render_readme(spec: ComposeSpec) -> str:
    return (
        f"# {spec.workspace.name}\n\n"
        "Generated by csrd compose.\n\n"
        "## Next steps\n\n"
        "```bash\n"
        "csrd compose validate\n"
        "csrd compose plan\n"
        "```\n"
    )


def _render_gitignore() -> str:
    return (
        "# Runtime env files\n"
        ".env\n"
        "\n"
        "# Python cache\n"
        "__pycache__/\n"
        "*.py[cod]\n"
        "\n"
        "# Test and tooling cache\n"
        ".pytest_cache/\n"
        ".mypy_cache/\n"
        ".ruff_cache/\n"
    )


def _render_workspace_marker() -> str:
    return "workspace: csrd\n"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def render_workspace(output_dir: Path, *, git_init: bool = False) -> Path:
    """Render deterministic workspace files from the current spec.

    If a ``csrd-compose.yaml`` already exists the spec is loaded from disk
    so that previously-added services and infra are reflected in the
    rendered ``docker-compose.yml`` and ``.env.example``.
    """

    output_dir.mkdir(parents=True, exist_ok=True)

    spec_path = spec_file_path(output_dir)
    spec = load_spec(spec_path) if spec_path.is_file() else default_spec(output_dir)

    spec.workspace.git_init = git_init
    save_spec(spec, spec_path)

    (output_dir / "docker-compose.yml").write_text(_render_compose(spec), encoding="utf-8")
    (output_dir / ".env.example").write_text(_render_env_example(spec), encoding="utf-8")
    (output_dir / "README.md").write_text(_render_readme(spec), encoding="utf-8")
    (output_dir / ".gitignore").write_text(_render_gitignore(), encoding="utf-8")
    (output_dir / WORKSPACE_MARKER_FILENAME).write_text(
        _render_workspace_marker(),
        encoding="utf-8",
    )

    if spec.workspace.git_init:
        maybe_git_init(output_dir)

    return output_dir
