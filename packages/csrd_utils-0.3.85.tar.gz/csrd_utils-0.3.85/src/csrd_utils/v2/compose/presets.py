"""Preset definitions for v2 compose workspaces.

Each preset declares the infrastructure categories it requires (the user
picks the *specific* type within each category, e.g. postgres vs mariadb)
and a set of starter service templates.
"""

from __future__ import annotations

from ..models import INFRA_CATEGORIES, PresetDefinition, ServiceNode

# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

PRESET_REGISTRY: dict[str, PresetDefinition] = {
    "authenticated-cluster": PresetDefinition(
        name="authenticated-cluster",
        description="App + auth + identity backed by a database",
        required_infra_categories=["database"],
        optional_infra_categories=["caching", "messaging"],
        services=[
            ServiceNode(
                name="app-service",
                role="app",
                port=8080,
                features=["database"],
            ),
            ServiceNode(
                name="auth-service",
                role="auth",
                port=8081,
                features=["database"],
            ),
            ServiceNode(
                name="identity-service",
                role="identity",
                port=8082,
                features=["database"],
            ),
        ],
    ),
}


def list_presets() -> list[PresetDefinition]:
    """Return all registered presets in display order."""

    return list(PRESET_REGISTRY.values())


def members_for_category(category_label: str) -> list[str]:
    """Return sorted member infra types for a category label."""

    for label, members, _single in INFRA_CATEGORIES:
        if label == category_label:
            return sorted(members)
    return []
