"""Compose package namespace."""

from pathlib import Path

from .loader import (
    SPEC_FILENAME,
    default_spec,
    load_spec,
    save_spec,
    spec_file_path,
)
from .presets import (
    PRESET_REGISTRY,
    PresetDefinition,
    list_presets,
    members_for_category,
)
from .renderer import render_workspace
from .spec import (
    INFRA_ALL_TYPES,
    INFRA_CATEGORIES,
    INFRA_DATABASES,
    ComposeSpec,
    InfraNode,
    ServiceNode,
)
from .yaml_editor import (
    deep_merge,
    dumps_yaml,
    ensure_list_item,
    load_yaml,
    save_yaml,
    set_key,
)


def apply(output_dir: Path, *, git_init: bool = False) -> Path:
    """Apply baseline empty-workspace rendering into `output_dir`."""

    return render_workspace(output_dir, git_init=git_init)


def validate(output_dir: Path) -> ComposeSpec:
    """Validate and return the canonical compose spec for a workspace."""

    return load_spec(spec_file_path(output_dir))


def add_service(output_dir: Path, service: ServiceNode) -> ComposeSpec:
    """Append a service to the workspace spec and persist to disk.

    Returns the updated spec.
    """

    spec_path = spec_file_path(output_dir)
    spec = load_spec(spec_path)

    existing_names = {s.name for s in spec.services}
    if service.name in existing_names:
        raise ValueError(f"Service '{service.name}' already exists in workspace spec")

    spec.services.append(service)
    save_spec(spec, spec_path)
    return spec


def add_infra(output_dir: Path, infra: InfraNode) -> ComposeSpec:
    # ...existing docstring and body...
    """Add or replace an infrastructure entry in the workspace spec.

    Database types are mutually exclusive — adding one replaces any existing
    database entry.  Other infra types (redis, rabbitmq) are singletons that
    cannot be duplicated.

    Returns the updated spec.
    """

    spec_path = spec_file_path(output_dir)
    spec = load_spec(spec_path)

    existing_types = {i.type for i in spec.infra}

    if infra.type in INFRA_DATABASES:
        # Remove any existing database entry (mutually exclusive)
        spec.infra = [i for i in spec.infra if i.type not in INFRA_DATABASES]
    elif infra.type in existing_types:
        raise ValueError(f"Infra '{infra.type}' already exists in workspace spec")

    spec.infra.append(infra)
    save_spec(spec, spec_path)
    return spec


def remove_infra(output_dir: Path, infra_type: str) -> ComposeSpec:
    """Remove an infrastructure entry from the workspace spec.

    Raises ``ValueError`` if *infra_type* is not currently configured.

    Returns the updated spec.
    """

    spec_path = spec_file_path(output_dir)
    spec = load_spec(spec_path)

    existing_types = {i.type for i in spec.infra}
    if infra_type not in existing_types:
        raise ValueError(f"Infra '{infra_type}' is not configured in workspace spec")

    spec.infra = [i for i in spec.infra if i.type != infra_type]
    save_spec(spec, spec_path)
    return spec


def available_infra(workspace_dir: Path) -> list[str]:
    """Return infra types not yet present in the workspace spec.

    Database types are mutually exclusive — if any database is already
    configured, all database options are excluded.
    """

    spec_path = spec_file_path(workspace_dir)
    if not spec_path.is_file():
        return sorted(INFRA_ALL_TYPES)

    spec = load_spec(spec_path)
    existing = {i.type for i in spec.infra}

    available: list[str] = []
    has_db = bool(existing & INFRA_DATABASES)
    for infra_type in sorted(INFRA_ALL_TYPES):
        if infra_type in existing:
            continue
        if has_db and infra_type in INFRA_DATABASES:
            continue
        available.append(infra_type)
    return available


def configured_infra(workspace_dir: Path) -> list[str]:
    """Return infra types currently configured in the workspace spec."""

    spec_path = spec_file_path(workspace_dir)
    if not spec_path.is_file():
        return []

    spec = load_spec(spec_path)
    return sorted(i.type for i in spec.infra)


__all__ = [
    "INFRA_ALL_TYPES",
    "INFRA_CATEGORIES",
    "INFRA_DATABASES",
    "PRESET_REGISTRY",
    "SPEC_FILENAME",
    "ComposeSpec",
    "InfraNode",
    "PresetDefinition",
    "ServiceNode",
    "add_infra",
    "add_service",
    "apply",
    "available_infra",
    "configured_infra",
    "deep_merge",
    "default_spec",
    "dumps_yaml",
    "ensure_list_item",
    "list_presets",
    "load_spec",
    "load_yaml",
    "members_for_category",
    "remove_infra",
    "render_workspace",
    "save_spec",
    "save_yaml",
    "set_key",
    "spec_file_path",
    "validate",
]
