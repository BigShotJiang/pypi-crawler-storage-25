# Menu System Design Rules

This file captures the design principles of the `v2/generate` menu system.
Consult it for every change that adds, removes, or modifies menus, menu items,
prompts, or interactive selection flows.

## Scope

- Applies to `packages/utils/src/csrd_utils/v2/generate/**`.
- Also follow `packages/utils/AGENTS.md` and the top-level `AGENTS.md`.

## Architecture overview

The menu system is split into three layers:

| Layer | File | Responsibility |
|---|---|---|
| **Primitives** | `helpers.py` | `MenuItem` dataclass, rendering, TTY/non-TTY selection, prompt helpers (`prompt_text`, `prompt_yes_no`, `prompt_single_select`, `prompt_multi_select`). |
| **Orchestration** | `menu.py` | Declarative item lists (`IN_WORKSPACE_ITEMS`, `_build_no_workspace_items`), context predicates, direct-mode dispatch, and the public `run_generate_menu` entry-point. |
| **Handlers** | `handlers.py` | Business-logic callbacks invoked by menu items. Each returns an `int` exit code. |

Changes must respect this separation. Do not put rendering logic in handlers
or business logic in helpers.

## Non-negotiable design rules

### 1. Declarative item definitions

Menu items are declared as static `list[MenuItem]` constants (or built by a
simple factory when runtime data like `default_name` is needed).

- **Do not** build menus with imperative if/else chains.
- Use the `visible` predicate on `MenuItem` to hide items based on context.
  The `filter_visible()` helper evaluates these at menu-build time.

### 2. Dual-mode: interactive + direct dispatch

Every interactive flow must have a non-interactive (direct) counterpart
invokable via CLI flags (`target`, `--name`, `--database`, etc.).

- `run_generate_menu` routes direct targets first, then falls through to the
  interactive menu. Keep this order: direct dispatch → interactive.
- Direct handlers are named `*_direct`, interactive ones `*_interactive`.

### 3. TTY / non-TTY graceful degradation

All interactive primitives must work in both TTY and non-TTY environments:

- **TTY path**: arrow-key navigation via `cbreak_mode()`, `>` cursor marker.
- **Non-TTY path**: numbered list with text input fallback.
- Gate on `sys.stdin.isatty() and sys.stdout.isatty()` — never assume a terminal.
- `cbreak_mode()` yields `None` when `termios` is unavailable; always handle that.
- Escape key detection uses `select.select()` with a 50 ms timeout via
  `_read_escape_seq()` to distinguish standalone Escape from arrow-key
  prefixes (`\x1b[A`/`\x1b[B`).

### 4. Cancel, interrupt, and back-navigation

**Ctrl-C (KeyboardInterrupt)**:
- Must **propagate** from all prompt primitives — they must NOT swallow it.
- Only the outermost handler or `run_menu` catches it.
- Handlers print `"Cancelled."` (wrapped in `contextlib.suppress`) and
  return exit code `1`.
- Swallowing at the primitive level causes fall-through — this is a bug.

**Escape / back (GoBack)**:
- `GoBack` is a lightweight exception raised by `prompt_single_select` and
  `prompt_multi_select` when the user presses Escape (TTY) or types `0` /
  `back` (non-TTY).
- In **nested flows** (e.g. `_prompt_infra_categories`), catch `GoBack`
  from sub-selects and loop back to the parent prompt.
- In **top-level handlers**, catch `GoBack` and skip the step (empty selection).
- In **`run_menu`**, Escape = cancel (same as selecting the cancel item).
- Visual hints: `"Esc back"` (TTY), `"0) back"` (non-TTY).

**EOF (EOFError)**:
- Return quietly with the default/empty value from primitives.
- `run_menu` returns `0`.

### 5. Exit code contract

All handlers and menu runners return an `int` exit code:

| Code | Meaning |
|---|---|
| `0` | Success or clean cancel |
| `1` | Error or user interrupt |

Do not raise exceptions to signal user-facing outcomes; print and return a code.

### 6. Prompt conventions

- `prompt_text(question, default=...)` — returns default on empty input or EOF.
  In TTY mode uses `_tty_line_input` (cbreak-mode character-by-character
  reading) so that Escape raises `GoBack` and Ctrl-C raises
  `KeyboardInterrupt`. Non-TTY falls back to `input()`.
- `prompt_yes_no(question, default=True)` — same TTY/non-TTY split. First
  prompt defaults yes; "add another?" prompts default no.
- `prompt_single_select` — auto-selects when only one option exists. Escape
  raises `GoBack`.
- `prompt_multi_select` — spacebar toggles, Enter confirms; non-TTY accepts
  comma-separated numbers, `all`, or `back`/`0`. Escape raises `GoBack`.

All four prompts support Escape for back-navigation. Do not invent new prompt
primitives without adding them to `helpers.py` first.

### 7. Step-based wizard flows

Multi-step interactive flows (e.g. `create_workspace`) use a step counter
with a `while step <= N` loop. Each step is wrapped in `try/except GoBack`
that decrements the step to return to the previous prompt. Ctrl-C
(`KeyboardInterrupt`) is caught at the outermost level and always aborts.

```
Step 0: name       ← Escape here = cancel (exit code 0)
Step 1: infra      ← Escape here = back to step 0
Step 2: services   ← Escape here = back to step 1
Step 3: git init   ← Escape here = back to step 2
```

Do not use flat sequential code for multi-step interactive flows — always
use the step loop pattern so that Escape goes back.

### 8. Naming & normalization

- Service names: `normalize_service_name()` → kebab-case, appends `-service`.
- Workspace names: `resolve_workspace_name()` → collapse whitespace, reject
  path separators.
- Always print a `"Normalized to: ..."` message when the name changes.

### 9. Category-based infra selection

Infrastructure is organized by category (`database`, `messaging`, `caching`)
defined in `compose/spec.py` via `INFRA_CATEGORIES`.

- Step 1: multi-select categories.
- Step 2: for each category, single-select the specific type (auto-select if
  only one member).
- Already-configured types are excluded from the available set.

Do not bypass the category system with flat infra-type lists.

### 10. Context awareness

Menus adapt based on workspace presence:

- **Inside workspace** (`csrd-compose.yaml` exists): show `add service`,
  `add infra` (if slots remain), `remove infra` (if any configured), `cancel`.
- **Outside workspace**: show `custom`, `preset`, `cancel`.

Context predicates (`_has_workspace`, `_has_available_infra`,
`_has_configured_infra`) must be pure filesystem checks — no global state,
no caching.

Alias uniqueness: each alias must be unique within a menu list. Do not reuse
a shortcut alias across items in the same list (e.g. `"c"` for both `custom`
and `cancel`).

### 11. No runtime auto-discovery

Menu items and infra types are statically registered. Do not add plugin
loaders, dynamic module scanning, or entry-point discovery for menu items.
This aligns with the top-level `AGENTS.md` cookiecutter guardrail.

## Audit checklist

When asked to "audit the menus", verify each of the following:

1. Every `MenuItem` has a `label`, at least two `aliases` (full name + shortcut), and a handler.
2. Every menu list ends with a `cancel` item.
3. `filter_visible()` is called before passing items to `run_menu()`.
4. All interactive flows have a `*_direct` counterpart wired in `run_generate_menu`.
5. TTY and non-TTY paths are both exercised (check for `isatty` gates).
6. `KeyboardInterrupt` and `EOFError` are caught in every prompt/menu call.
7. Exit codes follow the `0`/`1` contract.
8. Infra selection uses the category flow, not a flat list.
9. Names are normalized and the user is informed of changes.
10. No new prompt primitives exist outside `helpers.py`.
11. The three-layer separation (helpers → menu → handlers) is preserved.
12. Tests in `tests/test_cli.py` and `tests/test_v2_generate*.py` cover new/changed items.
