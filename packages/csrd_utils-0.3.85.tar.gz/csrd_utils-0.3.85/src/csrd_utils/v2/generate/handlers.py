"""Command handlers for generate actions."""

from __future__ import annotations

from contextlib import suppress
from pathlib import Path

from ..compose import (
    INFRA_CATEGORIES,
    INFRA_DATABASES,
    InfraNode,
    PresetDefinition,
    ServiceNode,
    available_infra,
    configured_infra,
    list_presets,
    members_for_category,
    render_workspace,
)
from ..compose import add_infra as compose_add_infra
from ..compose import add_service as compose_add_service
from ..compose import apply as compose_apply
from ..compose import remove_infra as compose_remove_infra
from .helpers import (
    GoBack,
    normalize_service_name,
    prompt_multi_select,
    prompt_single_select,
    prompt_text,
    prompt_yes_no,
    resolve_workspace_name,
)

SERVICE_FEATURES = ("database", "caching", "messaging")


def _detect_configured_db(infra_choices: list[str]) -> str | None:
    """Return the database backend from infra choices, or ``None``."""

    for choice in infra_choices:
        if choice in INFRA_DATABASES:
            return choice
    return None


def _available_features_for_infra(infra_choices: list[str]) -> list[str]:
    """Derive selectable features from the workspace's configured infra."""

    feats: list[str] = []
    for cat_label, cat_members, _single in INFRA_CATEGORIES:
        if any(c in cat_members for c in infra_choices):
            feats.append(cat_label)
    return feats


def cancel_ok() -> int:
    """Exit current flow as a successful cancel."""

    print("Cancelled.")
    return 0


# ---------------------------------------------------------------------------
# Service prompts (reused by workspace and add-service flows)
# ---------------------------------------------------------------------------


def _prompt_service(*, available_features: list[str] | None = None) -> ServiceNode | None:
    """Interactively collect service details.  Returns ``None`` on cancel.

    When *available_features* is provided (derived from the workspace's
    configured infra), the user can select which capabilities the service
    should be wired to.
    """

    try:
        raw_name = prompt_text("Service name", default="my-service")
    except KeyboardInterrupt:
        return None

    name = normalize_service_name(raw_name)
    if name != raw_name.strip():
        print(f"  Normalized to: {name}")

    features: list[str] = []
    if available_features:
        try:
            features = prompt_multi_select(
                "Select capabilities",
                available_features,
            )
        except KeyboardInterrupt:
            return None

    try:
        port_raw = prompt_text("Port", default="8080")
    except KeyboardInterrupt:
        return None

    try:
        port = int(port_raw)
    except ValueError:
        print(f"  Invalid port '{port_raw}', defaulting to 8080.")
        port = 8080

    return ServiceNode(name=name, port=port, features=features)


# ---------------------------------------------------------------------------
# Infrastructure prompts (category-based)
# ---------------------------------------------------------------------------


def _prompt_infra_categories(
    existing: set[str] | None = None,
) -> list[str]:
    """Walk through infra categories and collect specific selections.

    1. Multi-select which categories to add (database, messaging, caching).
    2. For each selected category, prompt for the specific type.
       - Single-option categories auto-select.
       - Multi-option categories (database) show a single-select.

    Escape at the category multi-select raises ``GoBack``.
    Escape at a sub-select loops back to the category multi-select.

    Returns a flat list of infra type strings.
    """

    existing = existing or set()

    # Build available categories (skip if all members are already present)
    available_categories: list[tuple[str, list[str], bool]] = []
    for label, cat_members, single in INFRA_CATEGORIES:
        available_members = sorted(m for m in cat_members if m not in existing)
        if available_members:
            available_categories.append((label, available_members, single))

    if not available_categories:
        return []

    while True:
        # Step 1: select categories (GoBack propagates to caller)
        cat_labels = [label for label, _, _ in available_categories]
        selected_labels = prompt_multi_select("Select infrastructure categories:", cat_labels)
        if not selected_labels:
            return []

        # Step 2: for each selected category, pick specific type
        result: list[str] = []
        restarted = False
        for label, members, _single in available_categories:
            if label not in selected_labels:
                continue

            if len(members) == 1:
                # Auto-select the only option
                print(f"  {label}: {members[0]}")
                result.append(members[0])
            else:
                try:
                    choice = prompt_single_select(f"Select {label}:", members)
                except GoBack:
                    # Go back to category selection
                    restarted = True
                    break
                if choice is not None:
                    result.append(choice)

        if restarted:
            continue
        return result


# ---------------------------------------------------------------------------
# Workspace handler
# ---------------------------------------------------------------------------


def _apply_workspace(
    workspace_name: str,
    *,
    git_init: bool = False,
) -> int:
    """Create workspace, render baseline, and print result."""

    try:
        normalized = resolve_workspace_name(workspace_name)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    if workspace_name.strip() and normalized != workspace_name.strip():
        print(f"Normalized workspace name to: {normalized}")

    output_dir = (Path.cwd().resolve() / normalized).resolve()
    compose_apply(output_dir, git_init=git_init)
    print(f"Generated workspace at: {output_dir}")
    return 0


def create_workspace(default_name: str = "my-workspace") -> int:
    """Interactive workspace flow with step-based back-navigation.

    Steps: name → infra → services → git init.
    Escape at any step returns to the previous one.
    Escape at the name step cancels the flow.
    Ctrl-C always cancels immediately.
    """

    normalized_default = resolve_workspace_name(default_name)

    # Collected values for each step
    name: str = ""
    infra_choices: list[str] = []
    services: list[ServiceNode] = []
    git_init: bool = False

    step = 0  # 0=name, 1=infra, 2=services, 3=git_init

    try:
        while step <= 3:
            if step == 0:
                # --- Step 0: workspace name ---
                try:
                    workspace_raw = prompt_text("Workspace name", default=normalized_default)
                except GoBack:
                    print("Cancelled.")
                    return 0

                raw_name = workspace_raw or normalized_default
                try:
                    name = resolve_workspace_name(raw_name)
                except ValueError as exc:
                    print(f"ERROR: {exc}")
                    return 1

                if raw_name.strip() and name != raw_name.strip():
                    print(f"Normalized workspace name to: {name}")
                step = 1

            elif step == 1:
                # --- Step 1: infra categories ---
                try:
                    infra_choices = _prompt_infra_categories()
                except GoBack:
                    step = 0
                    continue
                step = 2

            elif step == 2:
                # --- Step 2: services ---
                services = []
                feats = _available_features_for_infra(infra_choices)
                try:
                    if prompt_yes_no("Add a service?"):
                        while True:
                            svc = _prompt_service(available_features=feats)
                            if svc is not None:
                                services.append(svc)
                                print(f'Added service "{svc.name}" to spec.')
                            if not prompt_yes_no("Add another service?", default=False):
                                break
                except GoBack:
                    step = 1
                    continue
                step = 3

            elif step == 3:
                # --- Step 3: git init ---
                try:
                    git_init = prompt_yes_no("Initialize git repository?")
                except GoBack:
                    step = 2
                    continue
                step = 4  # done

    except KeyboardInterrupt:
        with suppress(KeyboardInterrupt):
            print("\nCancelled.")
        return 1

    # Create workspace
    output_dir = (Path.cwd().resolve() / name).resolve()
    compose_apply(output_dir, git_init=git_init)

    # Append collected infra
    for infra_type in infra_choices:
        try:
            compose_add_infra(output_dir, InfraNode(type=infra_type))
            print(f'Added infra "{infra_type}".')
        except ValueError as exc:
            print(f"WARNING: {exc}")

    # Append collected services
    for svc in services:
        try:
            compose_add_service(output_dir, svc)
        except ValueError as exc:
            print(f"WARNING: {exc}")

    # Re-render to pick up infra + service additions
    render_workspace(output_dir)
    print(f"Generated workspace at: {output_dir}")
    return 0


def create_workspace_direct(
    workspace_name: str = "my-workspace",
    *,
    git_init: bool = False,
) -> int:
    """Direct (non-interactive) workspace creation."""

    return _apply_workspace(workspace_name, git_init=git_init)


# ---------------------------------------------------------------------------
# Preset-based workspace handler
# ---------------------------------------------------------------------------


def _prompt_preset_infra(preset: PresetDefinition) -> list[str]:
    """Walk required then optional infra categories for a preset.

    Required categories force the user to pick a specific type (no skip).
    Optional categories are offered via multi-select, then each selected
    category with multiple members gets a single-select sub-prompt.

    Raises ``GoBack`` if the user escapes at the first required category
    (propagates to caller for step navigation).
    """

    infra_choices: list[str] = []

    # --- Required categories ---
    for cat_label in preset.required_infra_categories:
        members = members_for_category(cat_label)
        if not members:
            continue

        if len(members) == 1:
            print(f"  {cat_label}: {members[0]} (required)")
            infra_choices.append(members[0])
        else:
            # GoBack at first required category propagates; at later ones
            # we could loop back, but for simplicity propagate too.
            choice = prompt_single_select(
                f"Select {cat_label} (required by {preset.name}):", members
            )
            if choice is not None:
                infra_choices.append(choice)

    # --- Optional categories ---
    optional_labels = [
        label for label in preset.optional_infra_categories if members_for_category(label)
    ]
    if optional_labels:
        try:
            selected_labels = prompt_multi_select("Optional infrastructure:", optional_labels)
        except GoBack:
            # Back from optional → treat as "skip optionals"
            selected_labels = []

        for label in optional_labels:
            if label not in selected_labels:
                continue
            members = members_for_category(label)
            if len(members) == 1:
                print(f"  {label}: {members[0]}")
                infra_choices.append(members[0])
            else:
                try:
                    choice = prompt_single_select(f"Select {label}:", members)
                except GoBack:
                    continue  # skip this optional category
                if choice is not None:
                    infra_choices.append(choice)

    return infra_choices


def create_workspace_from_preset(default_name: str = "my-workspace") -> int:
    """Preset workspace flow with step-based back-navigation.

    Steps: name → pick preset → configure infra → add more services → git init.
    """

    normalized_default = resolve_workspace_name(default_name)

    name: str = ""
    preset: PresetDefinition | None = None
    infra_choices: list[str] = []
    extra_services: list[ServiceNode] = []
    git_init: bool = False

    presets = list_presets()
    preset_names = [p.name for p in presets]

    step = 0  # 0=name, 1=preset, 2=infra, 3=services, 4=git_init

    try:
        while step <= 4:
            if step == 0:
                try:
                    workspace_raw = prompt_text("Workspace name", default=normalized_default)
                except GoBack:
                    print("Cancelled.")
                    return 0

                raw_name = workspace_raw or normalized_default
                try:
                    name = resolve_workspace_name(raw_name)
                except ValueError as exc:
                    print(f"ERROR: {exc}")
                    return 1

                if raw_name.strip() and name != raw_name.strip():
                    print(f"Normalized workspace name to: {name}")
                step = 1

            elif step == 1:
                try:
                    chosen = prompt_single_select("Select a preset:", preset_names)
                except GoBack:
                    step = 0
                    continue
                if chosen is None:
                    step = 0
                    continue
                preset = next(p for p in presets if p.name == chosen)
                print(f"  {preset.description}")
                step = 2

            elif step == 2:
                if preset is None:
                    step = 1
                    continue
                try:
                    infra_choices = _prompt_preset_infra(preset)
                except GoBack:
                    step = 1
                    continue
                step = 3

            elif step == 3:
                extra_services = []
                feats = _available_features_for_infra(infra_choices)
                try:
                    if prompt_yes_no("Add extra services?", default=False):
                        while True:
                            svc = _prompt_service(available_features=feats)
                            if svc is not None:
                                extra_services.append(svc)
                                print(f'Added service "{svc.name}" to spec.')
                            if not prompt_yes_no("Add another service?", default=False):
                                break
                except GoBack:
                    step = 2
                    continue
                step = 4

            elif step == 4:
                try:
                    git_init = prompt_yes_no("Initialize git repository?")
                except GoBack:
                    step = 3
                    continue
                step = 5  # done

    except KeyboardInterrupt:
        with suppress(KeyboardInterrupt):
            print("\nCancelled.")
        return 1

    assert preset is not None

    # Create workspace
    output_dir = (Path.cwd().resolve() / name).resolve()
    compose_apply(output_dir, git_init=git_init)

    # Add infra from preset
    for infra_type in infra_choices:
        try:
            compose_add_infra(output_dir, InfraNode(type=infra_type))
            print(f'Added infra "{infra_type}".')
        except ValueError as exc:
            print(f"WARNING: {exc}")

    # Add preset services
    for svc in preset.services:
        try:
            compose_add_service(output_dir, svc)
        except ValueError as exc:
            print(f"WARNING: {exc}")

    # Add extra services
    for svc in extra_services:
        try:
            compose_add_service(output_dir, svc)
        except ValueError as exc:
            print(f"WARNING: {exc}")

    render_workspace(output_dir)
    print(f"Generated workspace at: {output_dir}")
    return 0


# ---------------------------------------------------------------------------
# Add service handler
# ---------------------------------------------------------------------------


def add_service_interactive() -> int:
    """Prompt for service details and append to the current workspace spec."""

    workspace_dir = Path.cwd().resolve()

    # Derive selectable features from configured infra
    configured = configured_infra(workspace_dir)
    feats = _available_features_for_infra(configured)

    try:
        svc = _prompt_service(available_features=feats)
    except GoBack:
        print("Cancelled.")
        return 0
    if svc is None:
        print("Cancelled.")
        return 0

    try:
        compose_add_service(workspace_dir, svc)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Added service "{svc.name}" to {workspace_dir / "csrd-compose.yaml"}')
    return 0


def add_service_direct(
    *,
    name: str,
    port: int = 8080,
    features: list[str] | None = None,
) -> int:
    """Non-interactive service addition to the current workspace spec."""

    service_name = normalize_service_name(name)
    svc = ServiceNode(name=service_name, port=port, features=features or [])

    workspace_dir = Path.cwd().resolve()
    try:
        compose_add_service(workspace_dir, svc)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Added service "{svc.name}" to {workspace_dir / "csrd-compose.yaml"}')
    return 0


# ---------------------------------------------------------------------------
# Add infra handler
# ---------------------------------------------------------------------------


def add_infra_interactive() -> int:
    """Category-based infra selection and addition to the current workspace spec."""

    from ..compose import load_spec, spec_file_path

    workspace_dir = Path.cwd().resolve()
    avail = available_infra(workspace_dir)

    if not avail:
        print("All infrastructure types are already configured.")
        return 0

    # Determine what's already configured so categories hide filled slots
    sp = spec_file_path(workspace_dir)
    existing = set()
    if sp.is_file():
        spec = load_spec(sp)
        existing = {i.type for i in spec.infra}

    try:
        choices = _prompt_infra_categories(existing)
    except GoBack:
        print("No infrastructure selected.")
        return 0
    except KeyboardInterrupt:
        with suppress(KeyboardInterrupt):
            print("\nCancelled.")
        return 1

    if not choices:
        print("No infrastructure selected.")
        return 0

    for infra_type in choices:
        infra = InfraNode(type=infra_type)
        try:
            compose_add_infra(workspace_dir, infra)
            print(f'Added infra "{infra_type}" to {workspace_dir / "csrd-compose.yaml"}')
        except ValueError as exc:
            print(f"WARNING: {exc}")

    render_workspace(workspace_dir)
    return 0


def add_infra_direct(*, infra_type: str) -> int:
    """Non-interactive infra addition to the current workspace spec."""

    infra = InfraNode(type=infra_type)
    workspace_dir = Path.cwd().resolve()

    try:
        compose_add_infra(workspace_dir, infra)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Added infra "{infra_type}" to {workspace_dir / "csrd-compose.yaml"}')
    return 0


# ---------------------------------------------------------------------------
# Remove infra handler
# ---------------------------------------------------------------------------


def remove_infra_interactive() -> int:
    """Prompt the user to select configured infra types to remove."""

    workspace_dir = Path.cwd().resolve()
    configured = configured_infra(workspace_dir)

    if not configured:
        print("No infrastructure is currently configured.")
        return 0

    try:
        if len(configured) == 1:
            # Auto-select the only option, but confirm
            infra_type = configured[0]
            if not prompt_yes_no(f'Remove "{infra_type}"?'):
                print("Cancelled.")
                return 0
            selected = [infra_type]
        else:
            selected = prompt_multi_select("Select infrastructure to remove:", configured)
    except GoBack:
        print("Cancelled.")
        return 0
    except KeyboardInterrupt:
        with suppress(KeyboardInterrupt):
            print("\nCancelled.")
        return 1

    if not selected:
        print("No infrastructure selected.")
        return 0

    for infra_type in selected:
        try:
            compose_remove_infra(workspace_dir, infra_type)
            print(f'Removed infra "{infra_type}" from {workspace_dir / "csrd-compose.yaml"}')
        except ValueError as exc:
            print(f"WARNING: {exc}")

    render_workspace(workspace_dir)
    return 0


def remove_infra_direct(*, infra_type: str) -> int:
    """Non-interactive infra removal from the current workspace spec."""

    workspace_dir = Path.cwd().resolve()

    try:
        compose_remove_infra(workspace_dir, infra_type)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    render_workspace(workspace_dir)
    print(f'Removed infra "{infra_type}" from {workspace_dir / "csrd-compose.yaml"}')
    return 0
