"""Generate menu orchestration for csrd CLI.

Menu items are declared up-front in ``IN_WORKSPACE_ITEMS``.  Each entry
carries an optional ``visible`` predicate so the set of choices adapts
to context (e.g. whether infra slots remain) without imperative branching.
"""

from __future__ import annotations

from pathlib import Path

from ..compose import SPEC_FILENAME, available_infra, configured_infra
from .handlers import (
    add_infra_direct,
    add_infra_interactive,
    add_service_direct,
    add_service_interactive,
    cancel_ok,
    create_workspace,
    create_workspace_direct,
    create_workspace_from_preset,
    remove_infra_direct,
    remove_infra_interactive,
)
from .helpers import (
    MenuItem,
    filter_visible,
    run_menu,
)

# ---------------------------------------------------------------------------
# Context predicates
# ---------------------------------------------------------------------------


def _has_workspace() -> bool:
    """Check whether ``cwd`` contains a ``csrd-compose.yaml``."""

    return (Path.cwd() / SPEC_FILENAME).is_file()


def _has_available_infra() -> bool:
    """True when the current workspace still has un-configured infra types."""

    return _has_workspace() and bool(available_infra(Path.cwd().resolve()))


def _has_configured_infra() -> bool:
    """True when the current workspace has at least one configured infra type."""

    return _has_workspace() and bool(configured_infra(Path.cwd().resolve()))


# ---------------------------------------------------------------------------
# Declarative menu definitions
# ---------------------------------------------------------------------------

#: Items shown when the user is *inside* an existing workspace.
IN_WORKSPACE_ITEMS: list[MenuItem] = [
    MenuItem(
        label="add service",
        aliases=("add service", "add-service", "service", "s"),
        handler=add_service_interactive,
    ),
    MenuItem(
        label="add infra",
        aliases=("add infra", "add-infra", "infra", "i"),
        handler=add_infra_interactive,
        visible=_has_available_infra,
    ),
    MenuItem(
        label="remove infra",
        aliases=("remove infra", "remove-infra", "rm-infra", "ri"),
        handler=remove_infra_interactive,
        visible=_has_configured_infra,
    ),
    MenuItem(label="cancel", aliases=("cancel", "c"), handler=cancel_ok),
]

#: Shared cancel item for the no-workspace menu.
_CANCEL_ITEM = MenuItem(label="cancel", aliases=("cancel", "c"), handler=cancel_ok)


def _build_no_workspace_items(default_name: str, *, name_provided: bool) -> list[MenuItem]:
    """Build menu items for the no-workspace context.

    The workspace handler needs ``default_name`` at construction time,
    so this is the one part that cannot be a static list.  Everything
    else (labels, aliases, cancel) is still declarative.

    Menu: custom / preset / cancel
    """

    if name_provided:
        custom_handler = lambda: create_workspace_direct(default_name)  # noqa: E731
    else:
        custom_handler = lambda: create_workspace(default_name)  # noqa: E731

    preset_handler = lambda: create_workspace_from_preset(default_name)  # noqa: E731

    return [
        MenuItem("custom", ("custom", "workspace", "w"), custom_handler),
        MenuItem("preset", ("preset", "p"), preset_handler),
        _CANCEL_ITEM,
    ]


# ---------------------------------------------------------------------------
# Public entry-point
# ---------------------------------------------------------------------------


def run_generate_menu(
    target: str | None = None,
    name: str | None = None,
    *,
    git_init: bool = False,
    # add-service direct flags
    features: list[str] | None = None,
    port: int | None = None,
    # add-infra direct flag
    infra_type: str | None = None,
) -> int:
    """Run the generator menu.

    Direct-mode targets (``workspace``, ``add-service``, ``add-infra``,
    ``remove-infra``, ``empty``) are dispatched immediately.  Otherwise the
    interactive menu is presented, built declaratively from the item lists
    above.
    """

    default_name = (name or "my-workspace").strip() or "my-workspace"

    # ---- direct-mode dispatch ----
    if target == "workspace":
        return create_workspace_direct(default_name, git_init=git_init)

    if target == "preset":
        return create_workspace_from_preset(default_name)

    if target == "add-service":
        if name is None:
            return add_service_interactive()
        return add_service_direct(
            name=name,
            features=features or [],
            port=port or 8080,
        )

    if target == "add-infra":
        if infra_type is None:
            return add_infra_interactive()
        return add_infra_direct(infra_type=infra_type)

    if target == "remove-infra":
        if infra_type is None:
            return remove_infra_interactive()
        return remove_infra_direct(infra_type=infra_type)

    # Legacy alias
    if target == "empty":
        return create_workspace_direct(default_name, git_init=git_init)

    # ---- interactive menu ----
    if _has_workspace():
        items = filter_visible(IN_WORKSPACE_ITEMS)
    else:
        items = _build_no_workspace_items(default_name, name_provided=name is not None)

    return run_menu("csrd v2 generate", "? What would you like to generate?", items)
