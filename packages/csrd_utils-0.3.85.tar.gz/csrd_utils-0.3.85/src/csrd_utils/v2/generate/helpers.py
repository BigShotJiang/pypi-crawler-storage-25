"""Reusable menu rendering, selection, and prompt helpers for v2 generate flows."""

from __future__ import annotations

import os
import re
import select
import sys
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from dataclasses import dataclass


class GoBack(Exception):
    """Raised by select prompts when the user presses Escape to go back."""


@dataclass(frozen=True)
class MenuItem:
    """Single interactive menu item definition.

    Parameters
    ----------
    label:
        Display text shown in the menu.
    aliases:
        Accepted text inputs that resolve to this item (non-TTY fallback).
    handler:
        Callable invoked when the item is selected.  Must return an exit code.
    visible:
        Optional predicate evaluated at menu-build time.  When provided and
        returning ``False`` the item is excluded from the rendered menu.
        Defaults to ``None`` (always visible).
    """

    label: str
    aliases: tuple[str, ...]
    handler: Callable[[], int]
    visible: Callable[[], bool] | None = None


# ---------------------------------------------------------------------------
# Name helpers
# ---------------------------------------------------------------------------


def resolve_workspace_name(value: str, fallback: str = "my-workspace") -> str:
    """Normalize and validate workspace directory names.

    - collapses whitespace runs into ``-``
    - rejects path separators to keep generation scoped to cwd child folders
    """

    candidate = value.strip() or fallback
    candidate = re.sub(r"\s+", "-", candidate)
    if "/" in candidate or "\\" in candidate:
        raise ValueError("Workspace name must not contain path separators")
    return candidate


def normalize_service_name(value: str) -> str:
    """Normalize a service name to kebab-case and append ``-service`` if missing."""

    candidate = re.sub(r"\s+", "-", value.strip().lower())
    if not candidate.endswith("-service"):
        candidate = f"{candidate}-service"
    return candidate


# ---------------------------------------------------------------------------
# Interactive prompt helpers
# ---------------------------------------------------------------------------


def _tty_line_input(display_prompt: str) -> str:
    """Read a line of text in cbreak mode with Escape / Ctrl-C support.

    Handles printable characters, backspace, Enter, Escape, and Ctrl-C.
    Raises ``GoBack`` on Escape, ``KeyboardInterrupt`` on Ctrl-C.
    Returns the entered string on Enter.
    """

    buf: list[str] = []
    sys.stdout.write(display_prompt)
    sys.stdout.flush()

    with cbreak_mode() as fd:
        if fd is None:
            # Fallback — shouldn't happen if caller checked isatty
            raise RuntimeError("cbreak unavailable")

        while True:
            ch = _read_char(fd)
            if ch in {"\r", "\n"}:
                sys.stdout.write("\n")
                sys.stdout.flush()
                return "".join(buf)
            if ch == "\x03":
                sys.stdout.write("\n")
                sys.stdout.flush()
                raise KeyboardInterrupt
            if ch == "\x1b":
                seq = _read_escape_seq(fd)
                if seq == "ESC":
                    sys.stdout.write("\n")
                    sys.stdout.flush()
                    raise GoBack
                # Ignore arrow keys in text input
            elif ch in {"\x7f", "\x08"}:
                # Backspace
                if buf:
                    buf.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
            elif ch >= " ":
                # Printable character
                buf.append(ch)
                sys.stdout.write(ch)
                sys.stdout.flush()


def prompt_text(question: str, *, default: str = "") -> str:
    """Prompt the user for a text value.

    Returns *default* when the user submits an empty answer.
    Raises ``GoBack`` on Escape, ``KeyboardInterrupt`` on Ctrl-C,
    and returns *default* on EOF.
    """

    hint = f" [{default}]" if default else ""
    display = f"{question}{hint}: "

    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            answer = _tty_line_input(display).strip()
        except EOFError:
            return default
        return answer or default

    # Non-TTY fallback
    try:
        answer = input(display).strip()
    except EOFError:
        return default
    return answer or default


def prompt_yes_no(question: str, *, default: bool = True) -> bool:
    """Prompt the user with a yes/no question.

    Returns *default* when the user submits an empty answer.
    Raises ``GoBack`` on Escape, ``KeyboardInterrupt`` on Ctrl-C.
    On ``EOFError`` returns ``False``.
    """

    hint = "Y/n" if default else "y/N"
    display = f"{question} ({hint}): "

    if sys.stdin.isatty() and sys.stdout.isatty():
        try:
            answer = _tty_line_input(display).strip().lower()
        except EOFError:
            return False
        if not answer:
            return default
        return answer in {"y", "yes", "true", "1"}

    # Non-TTY fallback
    try:
        answer = input(display).strip().lower()
    except EOFError:
        return False
    if not answer:
        return default
    return answer in {"y", "yes", "true", "1"}


# ---------------------------------------------------------------------------
# Menu rendering
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Terminal helpers
# ---------------------------------------------------------------------------


@contextmanager
def cbreak_mode() -> Iterator[int | None]:
    """Context manager that sets the terminal to cbreak mode and restores on exit.

    Yields the file descriptor on success, or ``None`` when raw terminal
    controls are unavailable (e.g. on Windows without termios).
    """

    try:
        import termios
        import tty
    except Exception:
        yield None
        return

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        yield fd
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def _read_char(fd: int) -> str:
    """Read a single byte from *fd* using unbuffered :func:`os.read`.

    This avoids the Python buffered-IO vs ``select`` race where
    ``sys.stdin.read(1)`` consumes multiple bytes into its internal
    buffer, causing ``select.select`` to see an empty fd even though
    characters are available.
    """

    return os.read(fd, 1).decode("latin-1")


def _read_escape_seq(fd: int) -> str:
    """After reading ``\\x1b``, distinguish standalone Escape from arrow keys.

    Uses ``select`` with a 50 ms timeout on the raw *fd*: if more bytes
    arrive they form an arrow-key sequence (``[A``/``[B``); otherwise the
    keypress was a bare Escape.

    Returns ``"ESC"`` for standalone Escape, ``"UP"`` / ``"DOWN"`` for
    arrows, or ``""`` for unrecognised sequences.
    """

    ready, _, _ = select.select([fd], [], [], 0.05)
    if not ready:
        return "ESC"

    ch = _read_char(fd)
    if ch != "[":
        return ""  # unknown sequence

    code = _read_char(fd)
    if code == "A":
        return "UP"
    if code == "B":
        return "DOWN"
    return ""


# ---------------------------------------------------------------------------
# Single-select
# ---------------------------------------------------------------------------


def prompt_single_select(prompt: str, options: list[str]) -> str | None:
    """Interactive single-select: arrow keys to move, Enter to confirm.

    Falls back to numbered input in non-TTY contexts.
    Returns the selected option or ``None`` on cancel/empty.
    Raises ``GoBack`` when the user presses Escape.
    """

    if not options:
        return None

    if len(options) == 1:
        # Auto-select the only option
        print(f"{prompt} {options[0]}")
        return options[0]

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return _single_select_non_tty(prompt, options)

    with cbreak_mode() as fd:
        if fd is None:
            return _single_select_non_tty(prompt, options)

        cursor = 0
        _render_single_select(prompt, options, cursor)
        while True:
            ch = _read_char(fd)
            if ch in {"\r", "\n"}:
                break
            if ch == "\x03":
                sys.stdout.write("\r\n")
                sys.stdout.flush()
                raise KeyboardInterrupt
            if ch == "\x1b":
                seq = _read_escape_seq(fd)
                if seq == "ESC":
                    sys.stdout.write("\x1b[2J\x1b[H")
                    sys.stdout.flush()
                    raise GoBack
                if seq == "UP":
                    cursor = (cursor - 1) % len(options)
                    _render_single_select(prompt, options, cursor)
                elif seq == "DOWN":
                    cursor = (cursor + 1) % len(options)
                    _render_single_select(prompt, options, cursor)

    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.flush()
    return options[cursor]


def _render_single_select(prompt: str, options: list[str], cursor: int) -> None:
    """Draw the single-select list in cbreak mode."""

    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.write(f"{prompt}\r\n")
    sys.stdout.write("(↑/↓ move, Enter confirm, Esc back)\r\n\r\n")
    for idx, option in enumerate(options):
        pointer = ">" if idx == cursor else " "
        sys.stdout.write(f" {pointer} {option}\r\n")
    sys.stdout.flush()


def _single_select_non_tty(prompt: str, options: list[str]) -> str | None:
    """Numbered fallback for non-TTY single-select."""

    print(prompt)
    for idx, option in enumerate(options, start=1):
        print(f"  {idx}) {option}")
    print("  0) back")

    try:
        raw = input("Select [1]: ").strip()
    except EOFError:
        return None

    if raw.lower() in {"0", "back", "b"}:
        raise GoBack

    if not raw:
        return options[0]
    if raw.isdigit():
        idx = int(raw) - 1
        if 0 <= idx < len(options):
            return options[idx]
    # Try by name
    lower = raw.lower()
    for opt in options:
        if opt.lower() == lower:
            return opt
    return None


# ---------------------------------------------------------------------------
# Multi-select
# ---------------------------------------------------------------------------


def prompt_multi_select(prompt: str, options: list[str]) -> list[str]:
    """Interactive multi-select: spacebar toggles, Enter confirms.

    Falls back to comma-separated numeric input in non-TTY contexts.
    Returns the selected option values (empty list if none selected).
    Raises ``KeyboardInterrupt`` on Ctrl-C and ``GoBack`` on Escape.
    """

    if not options:
        return []

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return _multi_select_non_tty(prompt, options)

    with cbreak_mode() as fd:
        if fd is None:
            return _multi_select_non_tty(prompt, options)

        selected: set[int] = set()
        cursor = 0

        _render_multi_select(prompt, options, selected, cursor)
        while True:
            ch = _read_char(fd)
            if ch in {"\r", "\n"}:
                break
            if ch == "\x03":
                sys.stdout.write("\r\n")
                sys.stdout.flush()
                raise KeyboardInterrupt
            if ch == " ":
                selected.symmetric_difference_update({cursor})
                _render_multi_select(prompt, options, selected, cursor)
            elif ch == "\x1b":
                seq = _read_escape_seq(fd)
                if seq == "ESC":
                    sys.stdout.write("\x1b[2J\x1b[H")
                    sys.stdout.flush()
                    raise GoBack
                if seq == "UP":
                    cursor = (cursor - 1) % len(options)
                    _render_multi_select(prompt, options, selected, cursor)
                elif seq == "DOWN":
                    cursor = (cursor + 1) % len(options)
                    _render_multi_select(prompt, options, selected, cursor)

    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.flush()
    return [options[i] for i in sorted(selected)]


def _render_multi_select(prompt: str, options: list[str], selected: set[int], cursor: int) -> None:
    """Draw the multi-select list in cbreak mode."""

    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.write(f"{prompt}\r\n")
    sys.stdout.write("(Space toggle, Enter confirm, Esc back)\r\n\r\n")
    for idx, option in enumerate(options):
        pointer = ">" if idx == cursor else " "
        check = "●" if idx in selected else "○"
        sys.stdout.write(f" {pointer} {check} {option}\r\n")
    sys.stdout.flush()


def _multi_select_non_tty(prompt: str, options: list[str]) -> list[str]:
    """Comma-separated numeric fallback for non-TTY multi-select."""

    print(prompt)
    for idx, option in enumerate(options, start=1):
        print(f"  {idx}) {option}")
    print("  0) back")
    print()

    try:
        raw = input("Select (comma-separated numbers, 'all', or 'back'): ").strip().lower()
    except EOFError:
        return []

    if raw in {"0", "back", "b"}:
        raise GoBack

    if raw in {"all", "*"}:
        return list(options)
    if not raw:
        return []

    result: list[str] = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            idx = int(part) - 1
            if 0 <= idx < len(options) and options[idx] not in result:
                result.append(options[idx])
    return result


def filter_visible(items: list[MenuItem]) -> list[MenuItem]:
    """Return only items whose ``visible`` predicate is absent or truthy."""

    return [item for item in items if item.visible is None or item.visible()]


def run_menu(title: str, prompt: str, items: list[MenuItem]) -> int:
    """Present *items* interactively and execute the selected handler.

    Handles TTY detection, cbreak mode, arrow-key navigation, and
    non-TTY numbered fallback.  Returns the exit code from the chosen
    handler (or ``0`` on cancel / ``1`` on interrupt).
    """

    from contextlib import suppress

    if not items:
        return 0

    # --- non-TTY path ---
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print_basic_menu(title, prompt, items)
        try:
            while True:
                selected = resolve_non_tty_selection(input("Select [1]: "), items)
                if selected is not None:
                    return selected.handler()
                print(f"ERROR: Invalid selection. Enter 1-{len(items)} or a valid alias.")
        except EOFError:
            return 0
        except KeyboardInterrupt:
            with suppress(KeyboardInterrupt):
                print("\nCancelled.")
            return 1

    # --- TTY path ---
    try:
        import termios  # noqa: F401 — availability check only
    except Exception:
        print_basic_menu(title, prompt, items)
        return 0

    with cbreak_mode() as fd:
        if fd is None:
            print_basic_menu(title, prompt, items)
            return 0

        cursor = 0
        try:
            render_tty_menu(title, prompt, items, cursor)
            while True:
                ch = _read_char(fd)
                if ch in {"\r", "\n"}:
                    break
                if ch == "\x03":
                    raise KeyboardInterrupt
                if ch == "\x1b":
                    seq = _read_escape_seq(fd)
                    if seq == "ESC":
                        # Escape at top-level menu = cancel
                        sys.stdout.write("\x1b[2J\x1b[H")
                        sys.stdout.flush()
                        print("Cancelled.")
                        return 0
                    if seq == "UP":
                        cursor = (cursor - 1) % len(items)
                        render_tty_menu(title, prompt, items, cursor)
                    elif seq == "DOWN":
                        cursor = (cursor + 1) % len(items)
                        render_tty_menu(title, prompt, items, cursor)
        except KeyboardInterrupt:
            with suppress(KeyboardInterrupt):
                print("\nCancelled.")
            return 1

    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.flush()
    return items[cursor].handler()


def print_basic_menu(title: str, prompt: str, items: list[MenuItem]) -> None:
    """Render a numbered menu for non-TTY contexts."""

    print(title)
    print()
    print(prompt)
    for idx, item in enumerate(items, start=1):
        print(f"  {idx}) {item.label}")


def render_tty_menu(title: str, prompt: str, items: list[MenuItem], selected: int) -> None:
    """Render menu in TTY mode with the currently selected index highlighted."""

    # In cbreak/raw-like terminal modes, use CRLF to avoid shifted text.
    sys.stdout.write("\x1b[2J\x1b[H")
    sys.stdout.write(f"{title}\r\n\r\n")
    sys.stdout.write(f"{prompt}\r\n")
    sys.stdout.write("(↑/↓ move, Enter confirm, Esc cancel)\r\n\r\n")
    for idx, item in enumerate(items):
        marker = ">" if idx == selected else " "
        sys.stdout.write(f" {marker} {item.label}\r\n")
    sys.stdout.flush()


def resolve_non_tty_selection(raw: str, items: list[MenuItem]) -> MenuItem | None:
    """Resolve user input from non-TTY mode into a menu item selection."""

    value = raw.strip().lower()
    if value == "":
        return items[0]

    if value.isdigit():
        index = int(value) - 1
        if 0 <= index < len(items):
            return items[index]

    for item in items:
        if value in item.aliases:
            return item
    return None
