"""Tests for VoxSession shutdown cleanup — listener unregistration and reference release."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from voxgraph.providers.livekit.session import VoxSession


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_vox_session(mock_session: MagicMock) -> VoxSession:
    """Create a VoxSession with mocked dependencies, bypassing real LiveKit.

    Patches out the version check and config loading so we can focus purely
    on the shutdown cleanup logic.
    """
    with (
        patch("voxgraph.providers.livekit.session.check_livekit_version"),
        patch("voxgraph.providers.livekit.session.load_config") as mock_load,
    ):
        mock_config = MagicMock()
        mock_config.debug = False
        mock_config.api_key = "test_key"
        mock_config.agent_id = "test_agent"
        mock_config.environment = "main"
        mock_config.tags = {}
        mock_config.max_buffer_size = 100
        mock_config.endpoint = "https://api.voxgraph.ai"
        mock_config.region = "us"
        mock_load.return_value = mock_config

        vox = VoxSession(mock_session, api_key="test_key", agent_id="test_agent")

    return vox


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestShutdownListenerCleanup:
    """Verify that shutdown() removes all registered event listeners."""

    async def test_session_listeners_unregistered_on_shutdown(self, mock_session):
        """conversation_item_added and user_state_changed listeners should be
        removed via session.off() during shutdown."""
        vox = _make_vox_session(mock_session)

        # Simulate what start() does — register the listeners
        mock_session.on("conversation_item_added", vox._on_conversation_item_added)
        mock_session.on("user_state_changed", vox._on_user_state_changed)

        assert len(mock_session._listeners.get("conversation_item_added", [])) == 1
        assert len(mock_session._listeners.get("user_state_changed", [])) == 1

        # Patch the sender to avoid real HTTP calls
        vox._sender = MagicMock()
        vox._sender.drain = AsyncMock()
        vox._is_started = True

        await vox.shutdown()

        # Listeners should be removed
        assert len(mock_session._listeners.get("conversation_item_added", [])) == 0
        assert len(mock_session._listeners.get("user_state_changed", [])) == 0

    async def test_room_listener_unregistered_on_shutdown(self, mock_session):
        """participant_connected listener on Room should be removed."""
        vox = _make_vox_session(mock_session)

        # Simulate a Room mock
        mock_room = MagicMock()
        mock_room._listeners: dict[str, list] = {}

        def room_on(event, cb):
            if event not in mock_room._listeners:
                mock_room._listeners[event] = []
            mock_room._listeners[event].append(cb)

        def room_off(event, cb):
            if event in mock_room._listeners:
                mock_room._listeners[event] = [
                    c for c in mock_room._listeners[event] if c != cb
                ]

        mock_room.on = MagicMock(side_effect=room_on)
        mock_room.off = MagicMock(side_effect=room_off)

        # Simulate what start() does — register on the room
        mock_room.on("participant_connected", vox._on_participant_connected)
        vox._room = mock_room

        assert len(mock_room._listeners.get("participant_connected", [])) == 1

        vox._sender = MagicMock()
        vox._sender.drain = AsyncMock()
        vox._is_started = True

        await vox.shutdown()

        assert len(mock_room._listeners.get("participant_connected", [])) == 0
        assert vox._room is None

    async def test_close_listener_unregistered_on_shutdown(self, mock_session):
        """The fallback close listener should be removed if registered."""
        vox = _make_vox_session(mock_session)

        # Simulate no-job-context path where a close listener is registered
        def _on_close(_event):
            pass

        mock_session.on("close", _on_close)
        vox._close_listener = _on_close

        assert len(mock_session._listeners.get("close", [])) == 1

        vox._sender = MagicMock()
        vox._sender.drain = AsyncMock()
        vox._is_started = True

        await vox.shutdown()

        assert len(mock_session._listeners.get("close", [])) == 0
        assert vox._close_listener is None


class TestShutdownReferenceRelease:
    """Verify that shutdown() nulls out heavy references after drain."""

    async def test_heavy_references_cleared_after_shutdown(self, mock_session):
        """_ctx, _session, _recorder, _collector, _sender should be None."""
        vox = _make_vox_session(mock_session)

        # Pre-populate data structures
        vox._speaking_windows = [(1.0, 2.0), (3.0, 4.0)]
        vox._tool_snapshots = [{"agent_id": "a", "tools": []}]
        vox._participant_attrs = {"user1": {"key": "val"}}
        vox._ctx = MagicMock()
        vox._recorder = MagicMock()

        vox._sender = MagicMock()
        vox._sender.drain = AsyncMock()
        vox._is_started = True

        await vox.shutdown()

        assert vox._speaking_windows == []
        assert vox._tool_snapshots == []
        assert vox._participant_attrs == {}
        assert vox._ctx is None
        assert vox._session is None
        assert vox._recorder is None
        assert vox._collector is None
        assert vox._sender is None

    async def test_shutdown_idempotent(self, mock_session):
        """Calling shutdown() twice should not raise."""
        vox = _make_vox_session(mock_session)
        vox._sender = MagicMock()
        vox._sender.drain = AsyncMock()
        vox._is_started = True

        await vox.shutdown()
        await vox.shutdown()  # Should be a no-op


class TestAudioRecorderCleanup:
    """Verify that AudioRecorder.stop() releases heavy references."""

    async def test_recorder_io_nulled_after_stop(self):
        """_recorder_io and _http_client should be None after stop()."""
        from voxgraph.providers.livekit.audio_recorder import AudioRecorder

        recorder = AudioRecorder()

        # Simulate a wired recorder that has been through attach()
        recorder._wired = True
        recorder._stopped = False
        mock_rio = AsyncMock()
        mock_rio.recording_started_at = 1000.0
        recorder._recorder_io = mock_rio
        recorder._http_client = MagicMock()
        recorder._tmp_path = MagicMock()
        recorder._tmp_path.exists.return_value = False
        recorder._conversation_id = "test-conv"
        recorder._started_at = 1000.0
        recorder._encode_started_at = 1000.0

        # Patch _upload_ogg to avoid real S3 calls
        with patch.object(recorder, "_upload_ogg", new_callable=AsyncMock, return_value=None):
            await recorder.stop()

        assert recorder._recorder_io is None
        assert recorder._http_client is None
