from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_feature92_group1() -> None:
    spec_path = ROOT / "docs" / "kinnoo-yaml-spec.md"
    assert spec_path.exists()

    text = spec_path.read_text(encoding="utf-8")

    assert "# kinnoo.yaml Specification" in text
    assert "## Required Fields" in text
    assert "## Optional Fields" in text
    assert "Validation Rules" in text

    # AC3 framework examples (matching feature wording while keeping command-accurate names in doc)
    assert "### chatgpt" in text
    assert "### gemini" in text
    assert "### openai" in text
    assert "### claude" in text
    assert "### Generic" in text


def test_feature92_group2() -> None:
    spec_path = ROOT / "docs" / "kinnoo-yaml-spec.md"
    readme_path = ROOT / "README.md"
    cli_path = ROOT / "src" / "kinnoo" / "cli.py"

    spec_text = spec_path.read_text(encoding="utf-8")
    readme_text = readme_path.read_text(encoding="utf-8")
    cli_text = cli_path.read_text(encoding="utf-8")

    # AC4: manifest version + compatibility notes
    assert "## Scope and Version" in spec_text
    assert "Backward compatibility" in spec_text

    # AC5: cross references
    assert "docs/kinnoo-yaml-spec.md" in readme_text
    assert "docs/kinnoo-yaml-spec.md" in cli_text