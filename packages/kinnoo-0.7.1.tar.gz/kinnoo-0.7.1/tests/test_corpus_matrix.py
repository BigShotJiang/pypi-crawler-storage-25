"""Retired corpus-matrix tests for deprecated task254/task255.

These tests are intentionally commented out and retained only for historical traceability.
"""

# def test_task255_import_matrix_all_agents() -> None:
#     # [agent] Deprecated: task254/task255 were deprecated; corpus matrix execution retired.
#     pass


# def test_task255_inspect_matrix_all_agents() -> None:
#     # [agent] Deprecated: task254/task255 were deprecated; corpus matrix execution retired.
#     pass


# def test_task255_run_matrix_all_agents() -> None:
#     # [agent] Deprecated: task254/task255 were deprecated; corpus matrix execution retired.
#     pass


# def test_task255_pack_matrix_all_agents() -> None:
#     # [agent] Deprecated: task254/task255 were deprecated; corpus matrix execution retired.
#     pass
