from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_feature95_group1() -> None:
    getting_started = ROOT / "docs" / "getting-started.md"
    registry_guide = ROOT / "docs" / "registry-guide.md"

    assert getting_started.exists()
    assert registry_guide.exists()

    gs = getting_started.read_text(encoding="utf-8")
    rg = registry_guide.read_text(encoding="utf-8")

    assert "# Getting Started" in gs
    assert "kinnoo init" in gs
    assert "kinnoo run" in gs
    assert "kinnoo pack" in gs

    assert "# Registry Guide" in rg
    assert "kinnoo login" in rg
    assert "kinnoo publish" in rg
    assert "kinnoo search" in rg
    assert "kinnoo install" in rg

    # AC3 copy-paste command presence
    assert "```bash" in gs
    assert "```bash" in rg


def test_feature95_group2() -> None:
    getting_started = ROOT / "docs" / "getting-started.md"
    registry_guide = ROOT / "docs" / "registry-guide.md"
    readme = ROOT / "README.md"

    gs = getting_started.read_text(encoding="utf-8")
    rg = registry_guide.read_text(encoding="utf-8")
    readme_text = readme.read_text(encoding="utf-8")

    # AC4 expected output snippets (validated as dedicated sections)
    assert "Expected output" in gs
    assert "Expected output" in rg

    # AC5 README cross-reference
    assert "docs/getting-started.md" in readme_text
    assert "docs/registry-guide.md" in readme_text