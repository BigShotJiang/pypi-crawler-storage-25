import os
import subprocess
import sys
from pathlib import Path

import pytest

from kinnoo.config import load_publish_behavior_config, load_registry_config
from kinnoo import run_command


def assert_no_secret_leak(outputs: list[str], sentinels: list[str]) -> None:
    combined_output = "\n".join(outputs)
    for sentinel in sentinels:
        assert sentinel not in combined_output


def _create_agent(agent_dir: Path, include_env_vars: bool) -> None:
    agent_dir.mkdir(parents=True, exist_ok=True)
    env_vars_block = ""
    if include_env_vars:
        env_vars_block = "env_vars:\n  - FEATURE10_SECRET_TOKEN\n"

    (agent_dir / "kinnoo.yaml").write_text(
        """
name: test-agent
version: 0.1.0
entrypoint: run.py
runtime:
  language: python
  version: ">=3.10"
  type: one-shot
dependencies: []
inputs:
  type: text
outputs:
  type: text
"""
        + env_vars_block,
        encoding="utf-8",
    )
    (agent_dir / "requirements.txt").write_text("", encoding="utf-8")
    (agent_dir / "run.py").write_text(
        """
import os

status = "set" if os.getenv("FEATURE10_SECRET_TOKEN") else "missing"
print(f"FEATURE10_SECRET_TOKEN={status}")
print("RUN_OK")
""",
        encoding="utf-8",
    )


def test_env_vars_resolve_from_process_environment(tmp_path: Path) -> None:
    agent_dir = tmp_path / "env-agent"
    _create_agent(agent_dir, include_env_vars=True)

    env = os.environ.copy()
    env["FEATURE10_SECRET_TOKEN"] = "SENTINEL_SECRET_ALPHA_9f3b"

    result = subprocess.run(
        [sys.executable, "-m", "kinnoo.cli", "run", str(agent_dir), "hello"],
        capture_output=True,
        text=True,
        env=env,
    )

    assert result.returncode == 0, f"Expected success, got stderr: {result.stderr}"
    assert "FEATURE10_SECRET_TOKEN=set" in result.stdout
    assert "RUN_OK" in result.stdout


def test_agents_without_env_vars_unaffected(tmp_path: Path) -> None:
    agent_dir = tmp_path / "no-env-agent"
    _create_agent(agent_dir, include_env_vars=False)

    env = os.environ.copy()
    env.pop("FEATURE10_SECRET_TOKEN", None)

    result = subprocess.run(
        [sys.executable, "-m", "kinnoo.cli", "run", str(agent_dir), "hello"],
        capture_output=True,
        text=True,
        env=env,
    )

    assert result.returncode == 0, f"Expected unchanged V1 behavior, got stderr: {result.stderr}"
    assert "RUN_OK" in result.stdout
    assert "Missing required environment variables" not in result.stderr


def test_env_vars_fallback_to_dotenv(tmp_path: Path) -> None:
    agent_dir = tmp_path / "dotenv-env-agent"
    _create_agent(agent_dir, include_env_vars=True)

    (agent_dir / ".env").write_text(
        "FEATURE10_SECRET_TOKEN=SENTINEL_SECRET_BRAVO_7c21\n",
        encoding="utf-8",
    )

    env = os.environ.copy()
    env.pop("FEATURE10_SECRET_TOKEN", None)

    result = subprocess.run(
        [sys.executable, "-m", "kinnoo.cli", "run", str(agent_dir), "hello"],
        capture_output=True,
        text=True,
        env=env,
    )

    assert result.returncode == 0, f"Expected .env fallback success, got stderr: {result.stderr}"
    assert "FEATURE10_SECRET_TOKEN=set" in result.stdout
    assert "RUN_OK" in result.stdout
    assert "SENTINEL_SECRET_BRAVO_7c21" not in result.stdout
    assert "SENTINEL_SECRET_BRAVO_7c21" not in result.stderr


def test_missing_env_var_uses_masked_prompt(
    tmp_path: Path,
    monkeypatch,
    capfd,
) -> None:
    agent_dir = tmp_path / "prompt-env-agent"
    _create_agent(agent_dir, include_env_vars=True)

    sentinel = "SENTINEL_SECRET_CHARLIE_4a22"
    monkeypatch.delenv("FEATURE10_SECRET_TOKEN", raising=False)

    def _fake_getpass(prompt: str) -> str:
        assert "FEATURE10_SECRET_TOKEN" in prompt
        return sentinel

    monkeypatch.setattr(run_command.getpass, "getpass", _fake_getpass)

    exit_code = run_command.run_agent(str(agent_dir), "hello")
    captured = capfd.readouterr()

    assert exit_code == 0
    assert "FEATURE10_SECRET_TOKEN=set" in captured.out
    assert "RUN_OK" in captured.out
    assert sentinel not in captured.out
    assert sentinel not in captured.err


def test_prompt_cancel_aborts_with_missing_var_name(
    tmp_path: Path,
    monkeypatch,
    capfd,
) -> None:
    agent_dir = tmp_path / "prompt-cancel-agent"
    _create_agent(agent_dir, include_env_vars=True)

    monkeypatch.delenv("FEATURE10_SECRET_TOKEN", raising=False)

    def _cancel_getpass(_prompt: str) -> str:
        raise KeyboardInterrupt

    monkeypatch.setattr(run_command.getpass, "getpass", _cancel_getpass)

    exit_code = run_command.run_agent(str(agent_dir), "hello")
    captured = capfd.readouterr()

    assert exit_code != 0
    assert "Error: Missing required environment variable: FEATURE10_SECRET_TOKEN" in captured.err


def test_resolved_env_vars_injected_into_subprocess(
    tmp_path: Path,
    monkeypatch,
    capfd,
) -> None:
    sentinel_env = "SENTINEL_SECRET_DELTA_1a11"
    sentinel_dotenv = "SENTINEL_SECRET_ECHO_2b22"
    sentinel_prompt = "SENTINEL_SECRET_FOXTROT_3c33"

    common_manifest = """
name: test-agent
version: 0.1.0
entrypoint: run.py
runtime:
  language: python
  version: ">=3.10"
  type: one-shot
dependencies: []
inputs:
  type: text
outputs:
  type: text
env_vars:
  - FEATURE10_SECRET_TOKEN
"""

    run_py = (
        "import os\n"
        "import sys\n\n"
        "expected = sys.argv[1]\n"
        "actual = os.getenv('FEATURE10_SECRET_TOKEN')\n"
        "if actual == expected:\n"
        "    print('INJECTED_OK')\n"
        "else:\n"
        "    print('INJECTED_MISMATCH')\n"
        "    sys.exit(2)\n"
    )

    env_agent = tmp_path / "inject-env-agent"
    env_agent.mkdir(parents=True, exist_ok=True)
    (env_agent / "kinnoo.yaml").write_text(common_manifest, encoding="utf-8")
    (env_agent / "requirements.txt").write_text("", encoding="utf-8")
    (env_agent / "run.py").write_text(run_py, encoding="utf-8")

    monkeypatch.setenv("FEATURE10_SECRET_TOKEN", sentinel_env)
    exit_code = run_command.run_agent(str(env_agent), sentinel_env)
    captured = capfd.readouterr()
    assert exit_code == 0
    assert "INJECTED_OK" in captured.out
    combined_env_output = captured.out + captured.err

    dotenv_agent = tmp_path / "inject-dotenv-agent"
    dotenv_agent.mkdir(parents=True, exist_ok=True)
    (dotenv_agent / "kinnoo.yaml").write_text(common_manifest, encoding="utf-8")
    (dotenv_agent / "requirements.txt").write_text("", encoding="utf-8")
    (dotenv_agent / "run.py").write_text(run_py, encoding="utf-8")
    (dotenv_agent / ".env").write_text(
        f"FEATURE10_SECRET_TOKEN={sentinel_dotenv}\n",
        encoding="utf-8",
    )

    monkeypatch.delenv("FEATURE10_SECRET_TOKEN", raising=False)
    exit_code = run_command.run_agent(str(dotenv_agent), sentinel_dotenv)
    captured = capfd.readouterr()
    assert exit_code == 0
    assert "INJECTED_OK" in captured.out
    combined_dotenv_output = captured.out + captured.err

    prompt_agent = tmp_path / "inject-prompt-agent"
    prompt_agent.mkdir(parents=True, exist_ok=True)
    (prompt_agent / "kinnoo.yaml").write_text(common_manifest, encoding="utf-8")
    (prompt_agent / "requirements.txt").write_text("", encoding="utf-8")
    (prompt_agent / "run.py").write_text(run_py, encoding="utf-8")

    monkeypatch.delenv("FEATURE10_SECRET_TOKEN", raising=False)

    def _fake_getpass(_prompt: str) -> str:
        return sentinel_prompt

    monkeypatch.setattr(run_command.getpass, "getpass", _fake_getpass)
    exit_code = run_command.run_agent(str(prompt_agent), sentinel_prompt)
    captured = capfd.readouterr()
    assert exit_code == 0
    assert "INJECTED_OK" in captured.out
    combined_prompt_output = captured.out + captured.err

    assert sentinel_env not in combined_env_output
    assert sentinel_dotenv not in combined_dotenv_output
    assert sentinel_prompt not in combined_prompt_output


def test_secret_values_never_appear_in_output_or_logs(
        tmp_path: Path,
        monkeypatch,
        capfd,
) -> None:
        sentinel_env = "SENTINEL_SECRET_ALPHA_9f3b"
        sentinel_dotenv = "SENTINEL_SECRET_BRAVO_7c21"
        sentinel_prompt = "SENTINEL_SECRET_CHARLIE_4a22"
        sentinels = [sentinel_env, sentinel_dotenv, sentinel_prompt]

        common_manifest = """
name: test-agent
version: 0.1.0
entrypoint: run.py
runtime:
    language: python
    version: ">=3.10"
    type: one-shot
dependencies: []
inputs:
    type: text
outputs:
    type: text
env_vars:
    - FEATURE10_SECRET_TOKEN
"""

        run_py = "print('RUN_OK')\n"

        outputs: list[str] = []

        env_agent = tmp_path / "leakcheck-env-agent"
        env_agent.mkdir(parents=True, exist_ok=True)
        (env_agent / "kinnoo.yaml").write_text(common_manifest, encoding="utf-8")
        (env_agent / "requirements.txt").write_text("", encoding="utf-8")
        (env_agent / "run.py").write_text(run_py, encoding="utf-8")

        monkeypatch.setenv("FEATURE10_SECRET_TOKEN", sentinel_env)
        exit_code = run_command.run_agent(str(env_agent), "hello")
        captured = capfd.readouterr()
        assert exit_code == 0
        outputs.extend([captured.out, captured.err])

        dotenv_agent = tmp_path / "leakcheck-dotenv-agent"
        dotenv_agent.mkdir(parents=True, exist_ok=True)
        (dotenv_agent / "kinnoo.yaml").write_text(common_manifest, encoding="utf-8")
        (dotenv_agent / "requirements.txt").write_text("", encoding="utf-8")
        (dotenv_agent / "run.py").write_text(run_py, encoding="utf-8")
        (dotenv_agent / ".env").write_text(
                f"FEATURE10_SECRET_TOKEN={sentinel_dotenv}\n",
                encoding="utf-8",
        )

        monkeypatch.delenv("FEATURE10_SECRET_TOKEN", raising=False)
        exit_code = run_command.run_agent(str(dotenv_agent), "hello")
        captured = capfd.readouterr()
        assert exit_code == 0
        outputs.extend([captured.out, captured.err])

        prompt_agent = tmp_path / "leakcheck-prompt-agent"
        prompt_agent.mkdir(parents=True, exist_ok=True)
        (prompt_agent / "kinnoo.yaml").write_text(common_manifest, encoding="utf-8")
        (prompt_agent / "requirements.txt").write_text("", encoding="utf-8")
        (prompt_agent / "run.py").write_text(run_py, encoding="utf-8")

        monkeypatch.delenv("FEATURE10_SECRET_TOKEN", raising=False)

        def _fake_getpass(_prompt: str) -> str:
                return sentinel_prompt

        monkeypatch.setattr(run_command.getpass, "getpass", _fake_getpass)
        exit_code = run_command.run_agent(str(prompt_agent), "hello")
        captured = capfd.readouterr()
        assert exit_code == 0
        outputs.extend([captured.out, captured.err])

        cancel_agent = tmp_path / "leakcheck-cancel-agent"
        cancel_agent.mkdir(parents=True, exist_ok=True)
        (cancel_agent / "kinnoo.yaml").write_text(common_manifest, encoding="utf-8")
        (cancel_agent / "requirements.txt").write_text("", encoding="utf-8")
        (cancel_agent / "run.py").write_text(run_py, encoding="utf-8")

        monkeypatch.delenv("FEATURE10_SECRET_TOKEN", raising=False)

        def _cancel_getpass(_prompt: str) -> str:
                raise KeyboardInterrupt

        monkeypatch.setattr(run_command.getpass, "getpass", _cancel_getpass)
        exit_code = run_command.run_agent(str(cancel_agent), "hello")
        captured = capfd.readouterr()
        assert exit_code != 0
        outputs.extend([captured.out, captured.err])

        assert_no_secret_leak(outputs=outputs, sentinels=sentinels)


def test_env_precedence_prefers_process_env_over_dotenv(
    tmp_path: Path,
    monkeypatch,
    capfd,
) -> None:
    sentinel_env = "SENTINEL_SECRET_GOLF_5d44"
    sentinel_dotenv = "SENTINEL_SECRET_HOTEL_6e55"

    agent_dir = tmp_path / "precedence-agent"
    _create_agent(agent_dir, include_env_vars=True)
    (agent_dir / ".env").write_text(
        f"FEATURE10_SECRET_TOKEN={sentinel_dotenv}\n",
        encoding="utf-8",
    )

    monkeypatch.setenv("FEATURE10_SECRET_TOKEN", sentinel_env)

    exit_code = run_command.run_agent(str(agent_dir), "hello")
    captured = capfd.readouterr()

    assert exit_code == 0
    assert "FEATURE10_SECRET_TOKEN=set" in captured.out
    assert "RUN_OK" in captured.out

    combined_output = captured.out + captured.err
    assert sentinel_env not in combined_output
    assert sentinel_dotenv not in combined_output


def test_mixed_source_env_var_resolution_and_injection(
        tmp_path: Path,
        monkeypatch,
        capfd,
) -> None:
        sentinel_env = "SENTINEL_SECRET_INDIA_7f66"
        sentinel_dotenv = "SENTINEL_SECRET_JULIET_8g77"
        sentinel_prompt = "SENTINEL_SECRET_KILO_9h88"
        sentinels = [sentinel_env, sentinel_dotenv, sentinel_prompt]

        manifest = """
name: test-agent
version: 0.1.0
entrypoint: run.py
runtime:
    language: python
    version: ">=3.10"
    type: one-shot
dependencies: []
inputs:
    type: text
outputs:
    type: text
env_vars:
    - FEATURE10_ENV_SECRET
    - FEATURE10_DOTENV_SECRET
    - FEATURE10_PROMPT_SECRET
"""

        run_py = (
                "import os\n"
                "import sys\n\n"
                "expected = {\n"
                f"    'FEATURE10_ENV_SECRET': '{sentinel_env}',\n"
                f"    'FEATURE10_DOTENV_SECRET': '{sentinel_dotenv}',\n"
                f"    'FEATURE10_PROMPT_SECRET': '{sentinel_prompt}',\n"
                "}\n"
                "for name, expected_value in expected.items():\n"
                "    if os.getenv(name) != expected_value:\n"
                "        print(f'MISMATCH:{name}')\n"
                "        sys.exit(2)\n"
                "print('MIXED_INJECTED_OK')\n"
        )

        agent_dir = tmp_path / "mixed-source-agent"
        agent_dir.mkdir(parents=True, exist_ok=True)
        (agent_dir / "kinnoo.yaml").write_text(manifest, encoding="utf-8")
        (agent_dir / "requirements.txt").write_text("", encoding="utf-8")
        (agent_dir / "run.py").write_text(run_py, encoding="utf-8")
        (agent_dir / ".env").write_text(
                f"FEATURE10_DOTENV_SECRET={sentinel_dotenv}\n",
                encoding="utf-8",
        )

        monkeypatch.setenv("FEATURE10_ENV_SECRET", sentinel_env)
        monkeypatch.delenv("FEATURE10_DOTENV_SECRET", raising=False)
        monkeypatch.delenv("FEATURE10_PROMPT_SECRET", raising=False)

        prompts: list[str] = []

        def _fake_getpass(prompt: str) -> str:
                prompts.append(prompt)
                assert "FEATURE10_PROMPT_SECRET" in prompt
                return sentinel_prompt

        monkeypatch.setattr(run_command.getpass, "getpass", _fake_getpass)

        exit_code = run_command.run_agent(str(agent_dir), "hello")
        captured = capfd.readouterr()

        assert exit_code == 0
        assert len(prompts) == 1
        assert "MIXED_INJECTED_OK" in captured.out

        assert_no_secret_leak(
                outputs=[captured.out, captured.err],
                sentinels=sentinels,
        )


def test_registry_config_precedence(tmp_path: Path, monkeypatch) -> None:
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "\n".join(
            [
                "registry_url: https://from-file.example.test",
                "registry_token: file-token",
                "tenant_slug: file-tenant",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    monkeypatch.delenv("KINNOO_REGISTRY_URL", raising=False)
    monkeypatch.delenv("KINNOO_REGISTRY_TOKEN", raising=False)
    monkeypatch.delenv("KINNOO_TENANT_SLUG", raising=False)

    file_config = load_registry_config(config_path=config_path)
    assert file_config.registry_url == "https://from-file.example.test"
    assert file_config.registry_token == "file-token"
    assert file_config.tenant_slug == "file-tenant"

    monkeypatch.setenv("KINNOO_REGISTRY_URL", "https://from-env.example.test")
    monkeypatch.setenv("KINNOO_REGISTRY_TOKEN", "env-token")
    monkeypatch.setenv("KINNOO_TENANT_SLUG", "env-tenant")

    env_config = load_registry_config(config_path=config_path)
    assert env_config.registry_url == "https://from-env.example.test"
    assert env_config.registry_token == "env-token"
    assert env_config.tenant_slug == "env-tenant"


def test_publish_behavior_config_from_project_file(tmp_path: Path, monkeypatch) -> None:
    project_root = tmp_path / "demo-project"
    nested_dir = project_root / "agents" / "calendar"
    nested_dir.mkdir(parents=True, exist_ok=True)

    (project_root / "kinnoo-config.txt").write_text(
        "\n".join(
            [
                "# Project publish behavior",
                "publish_to_authenticated_registry = true",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    monkeypatch.chdir(nested_dir)

    publish_config = load_publish_behavior_config()
    assert publish_config.publish_to_authenticated_registry is True


def test_publish_behavior_config_defaults_when_missing(tmp_path: Path, monkeypatch) -> None:
    project_root = tmp_path / "no-config-project"
    project_root.mkdir(parents=True, exist_ok=True)

    monkeypatch.chdir(project_root)

    publish_config = load_publish_behavior_config()
    assert publish_config.publish_to_authenticated_registry is False


@pytest.mark.skip(reason="Placeholder for test88 implementation")
def test_secret_sentinels_absent_from_runtime_artifacts() -> None:
    # [agent] Implement test88 here: run sentinel leak checks against stdout/stderr and runtime artifact files to enforce non-disclosure.
    pass
