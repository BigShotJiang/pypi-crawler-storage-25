from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_feature93_group1() -> None:
    doc_path = ROOT / "docs" / "cli-reference.md"
    assert doc_path.exists()

    text = doc_path.read_text(encoding="utf-8")

    # AC1/AC2 baseline sections
    assert "# CLI Reference" in text
    assert "## Client Commands (`kinnoo`)" in text
    assert "Usage:" in text
    assert "Description:" in text
    assert "Arguments:" in text
    assert "Options:" in text
    assert "Env vars:" in text
    assert "Exit codes:" in text
    assert "Examples:" in text

    # AC3 command coverage set
    required_markers = [
        "### init",
        "### pack",
        "### install",
        "### run",
        "### publish",
        "### search",
        "### login",
        "### logout",
        "### keygen",
        "### trust",
        "### inspect",
        "### uninstall",
    ]
    for marker in required_markers:
        assert marker in text


def test_feature93_group2() -> None:
    doc_path = ROOT / "docs" / "cli-reference.md"
    readme_path = ROOT / "README.md"

    text = doc_path.read_text(encoding="utf-8")
    readme_text = readme_path.read_text(encoding="utf-8")

    # AC4 server command coverage markers
    assert "## Server Commands (`kinnoo-server`)" in text
    for marker in ["bootstrap", "user create", "user list", "user reset-password", "invite create"]:
        assert marker in text

    # AC5 README cross-reference
    assert "docs/cli-reference.md" in readme_text