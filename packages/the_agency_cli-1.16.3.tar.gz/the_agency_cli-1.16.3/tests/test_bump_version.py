from pathlib import Path

import importlib.util


def _load_bump_version():
    module_path = Path(__file__).resolve().parents[1] / "scripts" / "bump_version.py"
    spec = importlib.util.spec_from_file_location("bump_version", module_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def _write_pyproject(path, version):
    path.write_text(
        (
            "[project]\n"
            'name = "the-agency-cli"\n'
            f'version = "{version}"\n'
        ),
        encoding="utf-8",
    )


def test_bump_version_uses_latest_published_version_when_local_version_lags(tmp_path, monkeypatch):
    bump_version = _load_bump_version()
    pyproject = tmp_path / "pyproject.toml"
    _write_pyproject(pyproject, "1.16.0")

    monkeypatch.setattr(
        bump_version,
        "latest_pypi_version",
        lambda package_name, timeout=10: "1.16.1",
    )

    assert bump_version.bump_version(pyproject_path=str(pyproject)) == "1.16.2"
    assert 'version = "1.16.2"' in pyproject.read_text(encoding="utf-8")


def test_bump_version_still_advances_from_local_version_when_pypi_is_behind(tmp_path, monkeypatch):
    bump_version = _load_bump_version()
    pyproject = tmp_path / "pyproject.toml"
    _write_pyproject(pyproject, "1.16.1")

    monkeypatch.setattr(
        bump_version,
        "latest_pypi_version",
        lambda package_name, timeout=10: "1.16.0",
    )

    assert bump_version.bump_version(pyproject_path=str(pyproject)) == "1.16.2"
    assert 'version = "1.16.2"' in pyproject.read_text(encoding="utf-8")


def test_infer_bump_type_uses_conventional_commit_signals():
    bump_version = _load_bump_version()

    assert bump_version.infer_bump_type("fix: keep patch release") == "patch"
    assert bump_version.infer_bump_type("feat: add team command") == "minor"
    assert (
        bump_version.infer_bump_type(
            "feat: add team command\n\nBREAKING CHANGE: remove legacy CLI flags"
        )
        == "major"
    )
