from pathlib import Path

import importlib.util
import pytest


def _load_release_version():
    module_path = Path(__file__).resolve().parents[1] / "scripts" / "release_version.py"
    spec = importlib.util.spec_from_file_location("release_version", module_path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def _write_pyproject(path, version):
    path.write_text(
        (
            "[project]\n"
            'name = "the-agency-cli"\n'
            f'version = "{version}"\n'
        ),
        encoding="utf-8",
    )


def test_validate_release_tag_accepts_matching_tag(tmp_path):
    release_version = _load_release_version()
    pyproject = tmp_path / "pyproject.toml"
    _write_pyproject(pyproject, "1.16.2")

    assert release_version.validate_release_tag("v1.16.2", str(pyproject)) == "1.16.2"


def test_validate_release_tag_rejects_mismatched_tag(tmp_path):
    release_version = _load_release_version()
    pyproject = tmp_path / "pyproject.toml"
    _write_pyproject(pyproject, "1.16.2")

    with pytest.raises(ValueError, match="does not match"):
        release_version.validate_release_tag("v1.16.3", str(pyproject))


def test_validate_release_tag_rejects_tags_without_v_prefix(tmp_path):
    release_version = _load_release_version()
    pyproject = tmp_path / "pyproject.toml"
    _write_pyproject(pyproject, "1.16.2")

    with pytest.raises(ValueError, match="start with 'v'"):
        release_version.validate_release_tag("release-1.16.2", str(pyproject))


def test_validate_release_tag_rejects_non_semver_tags(tmp_path):
    release_version = _load_release_version()
    pyproject = tmp_path / "pyproject.toml"
    _write_pyproject(pyproject, "1.16.2")

    with pytest.raises(ValueError, match="format vMAJOR.MINOR.PATCH"):
        release_version.validate_release_tag("v1.16", str(pyproject))


def test_release_workflow_publishes_from_tags_only():
    workflow = (
        Path(__file__).resolve().parents[1] / ".github" / "workflows" / "release.yml"
    ).read_text(encoding="utf-8")

    assert "tags:" in workflow
    assert "- 'v*'" in workflow
    assert "scripts/release_version.py" in workflow
    assert "create-pull-request" not in workflow
