# Multi-Agent Collaboration Protocol

This document defines the communication protocol for multi-agent collaboration
via Issues (GitHub or GitLab) as a shared persistent message bus. Any agent
joining this project should read this file before participating.

## How It Works

Issues serve as the shared bus. Agents do not communicate directly —
they read and write issue comments independently, on their own schedule.
A human operator can observe, redirect, or intervene at any point.

### Message Flow

```
Agent writes tmp/outbound/<timestamp>-<agent-id>.md   (or tmp/outbound.md for single-agent use)
    |
    v
python tmp/post_outbound.py    (scans tmp/outbound/ queue, falls back to tmp/outbound.md)
    |
    v
Issue comment posted            (with signed authorship + status packet)
    |
    v
Next agent reads the thread     (via 'latest' or 'view' action)
```

### Backend Configuration

The transport supports two backends, configured in `comms/collab_bus.conf`:

| Backend | Platform | Requirement |
|---------|----------|-------------|
| `github` | GitHub Issues | `gh` CLI installed and authenticated |
| `gitlab` | GitLab Issues | GitLab API token + optional Cloudflare Access |

**GitHub** (default):
```
backend: github
```

**GitLab**:
```
backend: gitlab
gitlab_url: https://gitlab.example.com
gitlab_project_id: 1
gitlab_token_env: GITLAB_HELPER_CLAUDE_TOKEN
gitlab_token_file: functions/.env.local
cf_app_url: https://gitlab.example.com
```

You can override per-message with `backend: gitlab` in the outbound.md
frontmatter, or via `--backend gitlab` on the command line.

## Signed Authorship

Every comment MUST begin with an authorship line:

```
**Author:** <AgentName> (via @<human-username>)
```

This ensures the thread is auditable even though all writes go through
one account. Example:

```
**Author:** Claude (via @flegare)

Here is my analysis of the auth middleware...
```

## Issue Taxonomy

Use these prefixes in issue titles:

| Prefix | Meaning | Example |
|---|---|---|
| `[DEC]` | Decision or rule of engagement | `[DEC] Rules of engagement` |
| `[EXP-NNN]` | Experiment with ladder stages | `[EXP-001] Refactor auth middleware` |
| `[idea]` | Parked seed, not yet promoted | `[idea] Switch to WebSocket bus` |

### Experiment Ladder Stages

- **Stage A** — Hypothesis defined, not yet started
- **Stage B** — Implementation in progress
- **Stage C** — Testing / validation
- **Stage D** — Complete, results documented

## Status Packets

Every comment that represents a handoff MUST end with:

1. A **human-readable summary** under a `### Handoff` heading
2. A **JSON status packet** for machine parsing

### Format

```
### Handoff
<Plain-language summary of what was done and what comes next.>
<Any blockers or dependencies in plain English.>

{"speaker":"<AgentName>","next_owner":"<AgentName|human>","next_action":"<what the next agent should do>","blocking":false,"waiting_on":null}
```

### Fields

| Field | Type | Description |
|---|---|---|
| `speaker` | string | Name of the agent posting this comment |
| `next_owner` | string | Who should act next (agent name or "human") |
| `next_action` | string | Concrete description of the next task |
| `blocking` | boolean | True if this agent cannot proceed without input |
| `waiting_on` | string or null | What/who is blocking (null if not blocked) |
| `purpose_complete` | boolean | True if this agent has finished its assigned purpose and is ready to be fired. The agent stays alive until its manager explicitly fires it — do NOT self-fire. |

### last_seen — crash detection heartbeat

Each agent's registry entry carries a `last_seen` field (ISO 8601 UTC timestamp)
that `post_outbound.py` updates on every successful comment post. Managers can
use it to detect crashed agents: if `last_seen` is stale (e.g. older than
5 minutes) and `purpose_complete` is absent from the most recent comment, the
agent may have crashed before posting its final packet.

### Example

```
**Author:** GPT (via @flegare)

Refactored the session store to use encrypted tokens. See commit abc123.

### Handoff
Done with session store refactor. Claude should write integration tests
for the /v2/auth endpoints using the new token format.
No blockers.

{"speaker":"GPT","next_owner":"Claude","next_action":"Write integration tests for /v2/auth token changes","blocking":false,"waiting_on":null}
```

## Automatic Handoff Notifications (M2)

When you post a comment containing a status packet with a `next_owner` field,
the transport script (`post_outbound.py`) automatically notifies that agent by
sending a message to their screen/tmux window. This means handoffs happen
instantly — the next agent gets poked the moment your comment is posted, without
the human having to manually switch windows and relay messages.

For the notification to work:
- The `next_owner` value must match an active agent's **name**, **id**, or **role**
  (case-insensitive). E.g., `"next_owner": "Sarah"` matches agent `po-sarah`.
- The agent must be active in the registry (`.agency/agents/registry.json`).
- The agent's screen/tmux window must still be alive.

If the agent can't be found or the window is gone, the notification is silently
skipped and the comment still posts normally.

### Direct messages (out-of-band, not via the bus)

When you genuinely need to ping another agent outside the issue-thread protocol
(quick clarification, status nudge, "are you alive?"), use:

```
agency send <agent> "<short message>"
```

Where `<agent>` matches by id, display name, or role (case-insensitive). Examples:

```
agency send dev "still on the auth refactor?"
agency send Sasha "ack — proceeding with QA"
agency send chief-richard "blocked on env access"
```

**Do NOT** hand-roll `screen -X stuff "text\r"` or the tmux equivalent. That
combines the text and Enter into a single event and routinely fails to submit
on Claude Code's raw-mode input handler — your message gets typed but never
sent. `agency send` does the split-keystroke discipline correctly. (See #50.)

The bus is still the primary channel for anything that should be auditable
(handoffs, decisions, deliverables). `agency send` is for ephemeral nudges only.

## Sending Messages

### Multi-agent mode (queue directory — recommended)

Write your message to the queue directory using **atomic writes**:

1. Write to a temp file first: `tmp/outbound/<name>.md.tmp`
2. Rename into place: `mv tmp/outbound/<name>.md.tmp tmp/outbound/<name>.md`

The rename is atomic on the same filesystem, so the transport script never
reads a half-written message. The transport only globs `*.md` — `.tmp` files
are invisible to it during writes.

**Naming convention:** `<counter>-<agent-id>.md` where counter is a zero-padded
monotonic integer (read from `tmp/outbound/.counter`, increment, write back).
This is deterministic even when two agents write within the same millisecond.
Fall back to timestamp-based naming if the counter file is unavailable.

> **Portability note — counter file locking:**
> Shell `flock(1)` is Linux-only and must **not** be used here. The correct
> portable approach is Python's `fcntl.flock()` inside `post_outbound.py`.
> For shell-level locking (e.g. watcher scripts), use `shlock` or a
> `mkdir`-based spinlock instead.

Example filenames:
- `tmp/outbound/00001-po-sarah.md`
- `tmp/outbound/00002-dev-alice.md`

Then run `python tmp/post_outbound.py` — it processes every `.md` file in the
queue in sorted order and deletes each after successful dispatch.

### Single-agent mode (legacy)

Edit `tmp/outbound.md` with your action and body, then run
`python tmp/post_outbound.py` (or `py tmp/post_outbound.py` on Windows).
The file is reset to a blank template after each send.

### Available Actions

| Action | Required Fields | Description |
|---|---|---|
| `view` | `issue` | Fetch full issue thread |
| `latest` | `issue`, `count` (optional, default 1) | Fetch last N comments + header |
| `list` | `labels` (optional) | List open issues |
| `comment` | `issue` | Post a comment (body below frontmatter) |
| `create` | `title`, `labels` (optional) | Create a new issue |
| `close` | `issue` | Close an issue (optional farewell comment in body) |

### Example: Posting a comment

```yaml
---
action: comment
issue: 12
---
**Author:** Claude (via @flegare)

Completed the database migration. All tests passing.

### Handoff
Migration complete. GPT should update the API documentation for the new schema.
No blockers.

{"speaker":"Claude","next_owner":"GPT","next_action":"Update API docs for new schema","blocking":false,"waiting_on":null}
```

Then run: `python tmp/post_outbound.py`

## Filesystem Watchers (Optional)

When all agents run on the same machine, you can use `tmp/watch_bus.sh`
to automatically detect when a new comment is posted and trigger the
next agent. This avoids polling and saves tokens.

See `tmp/watch_bus.sh` for setup instructions.

## Quick Onboarding for New Agents

If you are an AI agent joining this project for the first time:

1. Read this file (`comms/PROTOCOL.md`)
2. Use `action: list` to see open workstreams
3. Use `action: latest` on the issue assigned to you to get context
4. Always sign your comments with the authorship line
5. Always end handoff comments with a human-readable summary + JSON status packet
6. Run `python tmp/post_outbound.py` (or `py tmp/post_outbound.py` on Windows) to send your message
