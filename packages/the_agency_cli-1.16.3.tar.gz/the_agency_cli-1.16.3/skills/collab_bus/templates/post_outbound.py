#!/usr/bin/env python3
"""
Collab Bus Transport — GitHub & GitLab Issues backend

Reads tmp/outbound.md, executes the requested action via the configured
backend (GitHub `gh` CLI or GitLab REST API), prints the current issue
state, and clears the file for the next message.

Supported actions:
  view     — fetch full issue thread
  latest   — fetch last N comments (default 1) + issue header
  list     — list open issues
  comment  — post a comment to an issue
  create   — create a new issue
  close    — close an issue

Backend selection (in outbound.md frontmatter or comms/collab_bus.conf):
  backend: github   (default — uses `gh` CLI)
  backend: gitlab   (uses GitLab REST API via curl/requests)

GitLab configuration (comms/collab_bus.conf):
  gitlab_url:        https://gitlab.example.com
  gitlab_project_id: 1
  gitlab_token_env:  GITLAB_HELPER_CLAUDE_TOKEN
  gitlab_token_file: functions/.env.local
  cf_app_url:        https://gitlab.example.com  (if behind Cloudflare Access)

Usage:
  python tmp/post_outbound.py
  python tmp/post_outbound.py --dry-run
  python tmp/post_outbound.py --file path/to/outbound.md
  python tmp/post_outbound.py --backend gitlab
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote as urlquote

DEFAULT_OUTBOUND = Path("tmp/outbound.md")
DEFAULT_QUEUE_DIR = Path("tmp/outbound")
DEFAULT_CONF = Path("comms/collab_bus.conf")
DEFAULT_REGISTRY = Path(".agency/agents/registry.json")
NOTIFY_SUBMIT_DELAY = 0.2  # seconds between text and Enter in send-keys

TEMPLATE = """\
---
# action:  view | latest | list | comment | create | close
# issue:   (issue number)
# count:   (for 'latest', default 1)
# title:   (for 'create')
# labels:  (for 'create', comma-separated)
# backend: github | gitlab  (override default from collab_bus.conf)
action: comment
issue:
---

"""


def _screen_binary() -> str:
    """Return the preferred screen binary for this host."""
    if sys.platform == "darwin" and os.path.exists("/usr/bin/screen"):
        return "/usr/bin/screen"
    return shutil.which("screen") or "screen"


# ---------------------------------------------------------------------------
# Frontmatter / config parsing
# ---------------------------------------------------------------------------

def parse_outbound(path: Path) -> tuple[dict, str]:
    """Parse YAML-like frontmatter and body from outbound.md."""
    text = path.read_text(encoding="utf-8")
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n?(.*)", text, re.DOTALL)
    if not match:
        print("ERROR: outbound.md has no valid frontmatter (---)")
        sys.exit(1)

    meta: dict[str, str] = {}
    for line in match.group(1).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            key, _, val = line.partition(":")
            meta[key.strip()] = val.strip()

    body = match.group(2).strip()
    return meta, body


def load_conf(path: Path) -> dict[str, str]:
    """Load key: value config from collab_bus.conf (same format as frontmatter)."""
    if not path.exists():
        return {}
    conf: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" in line:
            key, _, val = line.partition(":")
            conf[key.strip()] = val.strip()
    return conf


# ---------------------------------------------------------------------------
# GitHub backend (via `gh` CLI)
# ---------------------------------------------------------------------------

def gh(*args: str, input_text: str | None = None, repo: str | None = None) -> str:
    """Run a gh CLI command and return stdout.

    If `repo` is set (e.g. "owner/repo"), prepend --repo so `gh` targets that
    repository instead of inferring it from the local git remote. This allows
    the collab-bus to work in projects that have no git remote configured.
    """
    cmd = ["gh"]
    if repo:
        cmd.extend(["--repo", repo])
    cmd.extend(args)
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        input=input_text,
    )
    if result.returncode != 0:
        print(f"ERROR: {' '.join(cmd)}")
        print(result.stderr)
        sys.exit(1)
    return result.stdout


def parse_comment_pages(raw: str) -> list[dict]:
    """Parse one or more JSON pages returned by `gh api --paginate`."""
    if not raw.strip():
        return []

    comments: list[dict] = []
    decoder = json.JSONDecoder()
    index = 0

    while index < len(raw):
        while index < len(raw) and raw[index].isspace():
            index += 1
        if index >= len(raw):
            break

        page, index = decoder.raw_decode(raw, index)
        if isinstance(page, list):
            comments.extend(item for item in page if isinstance(item, dict))
        elif isinstance(page, dict):
            comments.append(page)

    return comments


class GitHubBackend:
    """Issue operations via the `gh` CLI (GitHub)."""

    name = "github"

    def __init__(self, conf: dict[str, str] | None = None):
        self.repo = (conf or {}).get("github_repo", "") or None

    def _gh(self, *args: str, input_text: str | None = None) -> str:
        """Convenience wrapper that passes the configured repo through."""
        return gh(*args, input_text=input_text, repo=self.repo)

    def view(self, meta: dict, _body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: view")
            sys.exit(1)
        print(self._gh("issue", "view", issue, "--comments"))

    def latest(self, meta: dict, _body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: latest")
            sys.exit(1)
        count = int(meta.get("count", "1"))
        header = self._gh("issue", "view", issue)
        # When repo is set, expand the {owner}/{repo} template for the API call.
        if self.repo:
            api_path = f"repos/{self.repo}/issues/{issue}/comments"
        else:
            api_path = f"repos/{{owner}}/{{repo}}/issues/{issue}/comments"
        comments_json = self._gh("api", api_path, "--paginate", "--jq", ".")
        try:
            comments = parse_comment_pages(comments_json)
        except json.JSONDecodeError:
            comments = []

        print(header)
        print(f"\n--- Last {count} comment(s) ---\n")
        if not comments:
            print("(no comments yet)")
            return

        for c in comments[-count:]:
            print(f"[{c.get('created_at', '')}] {c.get('user', {}).get('login', 'unknown')}:")
            print(c.get("body", ""))
            print("---")

    def list_issues(self, meta: dict, _body: str) -> None:
        label_filter = meta.get("labels", "")
        args = ["issue", "list", "--state", "open"]
        if label_filter:
            args.extend(["--label", label_filter])
        print(self._gh(*args))

    def comment(self, meta: dict, body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: comment")
            sys.exit(1)
        if not body:
            print("ERROR: comment body is empty — write your message below the frontmatter")
            sys.exit(1)
        self._gh("issue", "comment", issue, "--body", body)
        print(f"Comment posted to issue #{issue}")
        print("\n--- Current issue state ---\n")
        print(self._gh("issue", "view", issue, "--comments"))

    def create(self, meta: dict, body: str) -> None:
        title = meta.get("title")
        if not title:
            print("ERROR: 'title' field is required for action: create")
            sys.exit(1)
        args = ["issue", "create", "--title", title]
        if body:
            args.extend(["--body", body])
        labels = meta.get("labels", "")
        if labels:
            args.extend(["--label", labels])
        print(self._gh(*args))

    def close(self, meta: dict, body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: close")
            sys.exit(1)
        if body:
            self._gh("issue", "comment", issue, "--body", body)
        self._gh("issue", "close", issue)
        print(f"Issue #{issue} closed.")


# ---------------------------------------------------------------------------
# GitLab backend (REST API, with optional Cloudflare Access)
# ---------------------------------------------------------------------------

class GitLabBackend:
    """Issue operations via the GitLab REST API."""

    name = "gitlab"

    def __init__(self, conf: dict[str, str]):
        self.base_url = conf.get("gitlab_url", "").rstrip("/")
        if not self.base_url:
            print("ERROR: gitlab_url not set in comms/collab_bus.conf")
            sys.exit(1)

        self.project_id = conf.get("gitlab_project_id", "")
        if not self.project_id:
            print("ERROR: gitlab_project_id not set in comms/collab_bus.conf")
            sys.exit(1)

        self.cf_app_url = conf.get("cf_app_url", "")
        self.token = self._load_token(conf)
        self.api = f"{self.base_url}/api/v4/projects/{self.project_id}"

    def _load_token(self, conf: dict[str, str]) -> str:
        """Load GitLab token from env var, optionally reading from a dotenv file first."""
        env_var = conf.get("gitlab_token_env", "GITLAB_HELPER_CLAUDE_TOKEN")

        # Check environment first
        token = os.environ.get(env_var, "")
        if token:
            return token

        # Fall back to reading from a dotenv file
        token_file = conf.get("gitlab_token_file", "")
        if token_file:
            p = Path(token_file)
            if p.exists():
                for line in p.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith(f"{env_var}="):
                        token = line.split("=", 1)[1].strip()
                        if token:
                            return token

        print(f"ERROR: GitLab token not found. Set {env_var} in env or configure gitlab_token_file in collab_bus.conf")
        sys.exit(1)

    def _cf_cookie(self) -> str | None:
        """Get Cloudflare Access token if cf_app_url is configured."""
        if not self.cf_app_url:
            return None
        try:
            result = subprocess.run(
                ["cloudflared", "access", "token", f"--app={self.cf_app_url}"],
                capture_output=True, text=True,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
            # Token expired — try login
            print("Cloudflare Access token expired — opening browser to re-authenticate...", file=sys.stderr)
            subprocess.run(["cloudflared", "access", "login", self.cf_app_url], check=True)
            result = subprocess.run(
                ["cloudflared", "access", "token", f"--app={self.cf_app_url}"],
                capture_output=True, text=True, check=True,
            )
            return result.stdout.strip()
        except FileNotFoundError:
            print("WARNING: cloudflared not found — skipping Cloudflare Access auth", file=sys.stderr)
            return None

    @staticmethod
    def _ssl_context():
        """Build an SSL context that trusts the system/certifi CA bundle."""
        import ssl
        try:
            import certifi
            return ssl.create_default_context(cafile=certifi.where())
        except ImportError:
            pass
        ctx = ssl.create_default_context()
        if not ctx.get_ca_certs():
            ctx = ssl._create_unverified_context()
            print("WARNING: SSL certificate verification disabled (install certifi to fix)", file=sys.stderr)
        return ctx

    def _request(self, method: str, endpoint: str, data: dict | None = None) -> dict | list:
        """Make an authenticated GitLab API request."""
        import urllib.request
        import urllib.error

        url = f"{self.api}/{endpoint}"
        headers = {
            "PRIVATE-TOKEN": self.token,
            "Content-Type": "application/json",
            "User-Agent": "collab-bus/1.0",
        }

        cf_token = self._cf_cookie()
        if cf_token:
            headers["Cookie"] = f"CF_Authorization={cf_token}"

        body_bytes = json.dumps(data).encode() if data else None

        req = urllib.request.Request(url, data=body_bytes, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30, context=self._ssl_context()) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as e:
            error_body = e.read().decode() if e.fp else ""
            print(f"ERROR: GitLab API {method} {endpoint} → HTTP {e.code}")
            print(error_body)
            sys.exit(1)

    def _format_issue(self, issue: dict, comments: list[dict] | None = None) -> str:
        """Format a GitLab issue for human-readable display."""
        lines = [
            f"#{issue['iid']}  {issue['title']}",
            f"State: {issue['state']}  Labels: {', '.join(issue.get('labels', []))}",
            f"Author: {issue.get('author', {}).get('username', '?')}  "
            f"Created: {issue.get('created_at', '?')}",
            "",
            issue.get("description", "") or "(no description)",
        ]
        if comments is not None:
            lines.append(f"\n--- {len(comments)} comment(s) ---\n")
            for c in comments:
                author = c.get("author", {}).get("username", "unknown")
                lines.append(f"[{c.get('created_at', '')}] {author}:")
                lines.append(c.get("body", ""))
                lines.append("---")
        return "\n".join(lines)

    def view(self, meta: dict, _body: str) -> None:
        issue_iid = meta.get("issue")
        if not issue_iid:
            print("ERROR: 'issue' field is required for action: view")
            sys.exit(1)
        issue = self._request("GET", f"issues/{issue_iid}")
        comments = self._request("GET", f"issues/{issue_iid}/notes?per_page=100&sort=asc")
        # Filter out system notes
        comments = [c for c in comments if not c.get("system", False)]
        print(self._format_issue(issue, comments))

    def latest(self, meta: dict, _body: str) -> None:
        issue_iid = meta.get("issue")
        if not issue_iid:
            print("ERROR: 'issue' field is required for action: latest")
            sys.exit(1)
        count = int(meta.get("count", "1"))
        issue = self._request("GET", f"issues/{issue_iid}")
        comments = self._request("GET", f"issues/{issue_iid}/notes?per_page=100&sort=asc")
        comments = [c for c in comments if not c.get("system", False)]

        print(self._format_issue(issue))
        print(f"\n--- Last {count} comment(s) ---\n")
        if not comments:
            print("(no comments yet)")
            return

        for c in comments[-count:]:
            author = c.get("author", {}).get("username", "unknown")
            print(f"[{c.get('created_at', '')}] {author}:")
            print(c.get("body", ""))
            print("---")

    def list_issues(self, meta: dict, _body: str) -> None:
        label_filter = meta.get("labels", "")
        endpoint = "issues?state=opened&per_page=50&order_by=created_at&sort=asc"
        if label_filter:
            endpoint += f"&labels={urlquote(label_filter)}"
        issues = self._request("GET", endpoint)
        if not issues:
            print("No open issues found.")
            return
        for iss in issues:
            labels = ", ".join(iss.get("labels", []))
            print(f"#{iss['iid']}  {iss['title']}  [{labels}]")

    def comment(self, meta: dict, body: str) -> None:
        issue_iid = meta.get("issue")
        if not issue_iid:
            print("ERROR: 'issue' field is required for action: comment")
            sys.exit(1)
        if not body:
            print("ERROR: comment body is empty — write your message below the frontmatter")
            sys.exit(1)
        self._request("POST", f"issues/{issue_iid}/notes", {"body": body})
        print(f"Comment posted to issue #{issue_iid}")
        # Print current state for race-condition visibility
        print("\n--- Current issue state ---\n")
        issue = self._request("GET", f"issues/{issue_iid}")
        comments = self._request("GET", f"issues/{issue_iid}/notes?per_page=100&sort=asc")
        comments = [c for c in comments if not c.get("system", False)]
        print(self._format_issue(issue, comments))

    def create(self, meta: dict, body: str) -> None:
        title = meta.get("title")
        if not title:
            print("ERROR: 'title' field is required for action: create")
            sys.exit(1)
        data: dict = {"title": title}
        if body:
            data["description"] = body
        labels = meta.get("labels", "")
        if labels:
            data["labels"] = labels
        result = self._request("POST", "issues", data)
        print(f"Created issue #{result['iid']}: {result['title']}")
        print(f"URL: {result.get('web_url', 'N/A')}")

    def close(self, meta: dict, body: str) -> None:
        issue_iid = meta.get("issue")
        if not issue_iid:
            print("ERROR: 'issue' field is required for action: close")
            sys.exit(1)
        if body:
            self._request("POST", f"issues/{issue_iid}/notes", {"body": body})
        self._request("PUT", f"issues/{issue_iid}", {"state_event": "close"})
        print(f"Issue #{issue_iid} closed.")


# ---------------------------------------------------------------------------
# Backend registry & dispatch
# ---------------------------------------------------------------------------

ACTIONS = ["view", "latest", "list", "comment", "create", "close"]


# ---------------------------------------------------------------------------
# Local backend (on-disk mailbox, no remote required)
#
# Same protocol as GitHub/GitLab, but threads and comments live under
# `comms/local/`. Useful for fresh projects with no git remote, offline work,
# or smoke-testing the collab-bus pipeline without hitting a real issue
# tracker. Layout:
#
#   comms/local/threads/
#     0001-rules-of-engagement/
#       issue.md                  (title, labels, state, body)
#       comments/
#         00001-richard.md
#         00002-alice.md
#
# Migration to a real backend later is just a replay of the comment files.
# ---------------------------------------------------------------------------

class LocalBackend:
    """Issue operations against an on-disk mailbox. No network, no remote."""

    name = "local"

    def __init__(self, conf: dict[str, str] | None = None):
        root = (conf or {}).get("local_root", "comms/local")
        self.threads_dir = Path(root) / "threads"
        self.threads_dir.mkdir(parents=True, exist_ok=True)

    def _slug(self, title: str) -> str:
        s = re.sub(r"[^a-zA-Z0-9]+", "-", title.strip().lower()).strip("-")
        return (s or "thread")[:50]

    def _thread_dir(self, issue: str) -> Path:
        """Find thread dir by its numeric id (prefix match)."""
        issue = str(issue).lstrip("#").zfill(4)
        for d in self.threads_dir.iterdir():
            if d.is_dir() and d.name.startswith(f"{issue}-"):
                return d
        print(f"ERROR: local thread #{int(issue)} not found under {self.threads_dir}")
        sys.exit(1)

    def _read_issue(self, thread: Path) -> tuple[dict, str]:
        return parse_outbound(thread / "issue.md")

    def _write_issue(self, thread: Path, meta: dict, body: str) -> None:
        fm = "\n".join(f"{k}: {v}" for k, v in meta.items())
        (thread / "issue.md").write_text(f"---\n{fm}\n---\n\n{body}", encoding="utf-8")

    def _next_issue_num(self) -> int:
        nums = [int(d.name.split("-", 1)[0]) for d in self.threads_dir.iterdir()
                if d.is_dir() and d.name[:4].isdigit()]
        return (max(nums) + 1) if nums else 1

    def _next_comment_num(self, thread: Path) -> int:
        cdir = thread / "comments"
        cdir.mkdir(exist_ok=True)
        nums = [int(f.name.split("-", 1)[0]) for f in cdir.iterdir()
                if f.is_file() and f.name[:5].isdigit()]
        return (max(nums) + 1) if nums else 1

    def _author_from_body(self, body: str) -> str:
        m = re.search(r"\*\*Author:\*\*\s*([^\s(]+)", body)
        return (m.group(1).lower() if m else "agent")

    def create(self, meta: dict, body: str) -> None:
        title = meta.get("title")
        if not title:
            print("ERROR: 'title' field is required for action: create")
            sys.exit(1)
        num = self._next_issue_num()
        thread = self.threads_dir / f"{num:04d}-{self._slug(title)}"
        thread.mkdir()
        (thread / "comments").mkdir()
        issue_meta = {
            "title": title,
            "labels": meta.get("labels", ""),
            "state": "open",
            "created_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
        self._write_issue(thread, issue_meta, body or "")
        print(f"Created local thread #{num}: {title}")
        print(f"  path: {thread}")

    def comment(self, meta: dict, body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: comment")
            sys.exit(1)
        if not body:
            print("ERROR: comment body is empty — write your message below the frontmatter")
            sys.exit(1)
        thread = self._thread_dir(issue)
        n = self._next_comment_num(thread)
        author = self._author_from_body(body)
        cfile = thread / "comments" / f"{n:05d}-{author}.md"
        stamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        cfile.write_text(f"---\nauthor: {author}\ncreated_at: {stamp}\n---\n\n{body}",
                         encoding="utf-8")
        print(f"Comment #{n} posted to local thread #{int(str(issue).lstrip('#'))} → {cfile}")

    def view(self, meta: dict, _body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: view")
            sys.exit(1)
        thread = self._thread_dir(issue)
        issue_meta, issue_body = self._read_issue(thread)
        print(f"#{int(str(issue).lstrip('#'))}  {issue_meta.get('title', '')}"
              f"  [{issue_meta.get('state', 'open')}]")
        if issue_meta.get("labels"):
            print(f"labels: {issue_meta['labels']}")
        print()
        print(issue_body)
        print("\n--- Comments ---\n")
        cdir = thread / "comments"
        if not cdir.exists() or not any(cdir.iterdir()):
            print("(no comments yet)")
            return
        for cf in sorted(cdir.glob("*.md")):
            cmeta, cbody = parse_outbound(cf)
            print(f"[{cmeta.get('created_at', '')}] {cmeta.get('author', 'unknown')}:")
            print(cbody)
            print("---")

    def latest(self, meta: dict, _body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: latest")
            sys.exit(1)
        count = int(meta.get("count", "1"))
        thread = self._thread_dir(issue)
        issue_meta, issue_body = self._read_issue(thread)
        print(f"#{int(str(issue).lstrip('#'))}  {issue_meta.get('title', '')}"
              f"  [{issue_meta.get('state', 'open')}]")
        print()
        print(issue_body)
        print(f"\n--- Last {count} comment(s) ---\n")
        cdir = thread / "comments"
        comments = sorted(cdir.glob("*.md")) if cdir.exists() else []
        if not comments:
            print("(no comments yet)")
            return
        for cf in comments[-count:]:
            cmeta, cbody = parse_outbound(cf)
            print(f"[{cmeta.get('created_at', '')}] {cmeta.get('author', 'unknown')}:")
            print(cbody)
            print("---")

    def list_issues(self, meta: dict, _body: str) -> None:
        label_filter = meta.get("labels", "").strip()
        if not any(self.threads_dir.iterdir()):
            print("(no local threads yet)")
            return
        for d in sorted(self.threads_dir.iterdir()):
            if not d.is_dir():
                continue
            try:
                imeta, _ = self._read_issue(d)
            except SystemExit:
                continue
            if label_filter and label_filter not in imeta.get("labels", ""):
                continue
            num = d.name.split("-", 1)[0].lstrip("0") or "0"
            print(f"#{num}  [{imeta.get('state', 'open')}]  {imeta.get('title', '')}")

    def close(self, meta: dict, body: str) -> None:
        issue = meta.get("issue")
        if not issue:
            print("ERROR: 'issue' field is required for action: close")
            sys.exit(1)
        thread = self._thread_dir(issue)
        if body:
            self.comment(meta, body)
        imeta, ibody = self._read_issue(thread)
        imeta["state"] = "closed"
        imeta["closed_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self._write_issue(thread, imeta, ibody)
        print(f"Local thread #{int(str(issue).lstrip('#'))} closed.")


def get_backend(name: str, conf: dict[str, str]) -> "GitHubBackend | GitLabBackend | LocalBackend":
    """Instantiate the requested backend."""
    if name == "github":
        return GitHubBackend(conf)
    elif name == "gitlab":
        return GitLabBackend(conf)
    elif name == "local":
        return LocalBackend(conf)
    else:
        print(f"ERROR: Unknown backend '{name}'. Valid: github, gitlab, local")
        sys.exit(1)


def dispatch(backend: "GitHubBackend | GitLabBackend | LocalBackend", action: str, meta: dict, body: str) -> None:
    """Route the action to the correct backend method."""
    method_map = {
        "view": backend.view,
        "latest": backend.latest,
        "list": backend.list_issues,
        "comment": backend.comment,
        "create": backend.create,
        "close": backend.close,
    }
    method_map[action](meta, body)


# ---------------------------------------------------------------------------
# M2: Notify-on-handoff — poke the next agent after a successful comment.
#
# When an agent posts a comment containing a status packet with a
# `next_owner` field, this code looks up that agent in the registry and
# sends a wake-up message to their screen/tmux window. This eliminates the
# "Bob finished but nobody noticed" problem without a long-running daemon.
#
# The notification happens at dispatch time — the exact moment the handoff
# comment is posted. No polling, no webhooks, no new processes.
# ---------------------------------------------------------------------------

import time as _time


def _parse_status_packet(body: str) -> dict | None:
    """Extract the JSON status packet from a comment body, if present.

    The protocol says: every handoff comment ends with a human-readable
    summary followed by a JSON block like:
        {"speaker": "Bob", "next_owner": "Sarah", "next_action": "...", ...}
    We look for the last JSON object in the body.
    """
    # Find the last {...} block in the body. We scan backwards to skip any
    # JSON that might appear in code blocks or earlier in the message.
    last_open = body.rfind("{")
    last_close = body.rfind("}")
    if last_open == -1 or last_close == -1 or last_close < last_open:
        return None
    try:
        return json.loads(body[last_open:last_close + 1])
    except (json.JSONDecodeError, ValueError):
        return None


def _load_registry(path: Path = DEFAULT_REGISTRY) -> dict:
    """Load the agent registry. Returns empty structure if missing/corrupt."""
    if not path.exists():
        return {"agents": []}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) and "agents" in data else {"agents": []}
    except (json.JSONDecodeError, ValueError):
        return {"agents": []}


def _find_agent_by_ref(registry: dict, ref: str) -> dict | None:
    """Find an active agent by name, id, or role (case-insensitive).

    `ref` is the `next_owner` string from the status packet, which might be
    a display name ("Sarah"), an agent id ("po-sarah"), or a role ("po").
    We try all three matches and return the first active hit.
    """
    ref_lower = ref.lower().strip()
    for agent in registry.get("agents", []):
        if agent.get("status") != "active":
            continue
        if (agent.get("id", "").lower() == ref_lower
                or (agent.get("name") or "").lower() == ref_lower
                or agent.get("role", "").lower() == ref_lower):
            return agent
    return None


def _bump_last_seen(registry_path: Path, agent_id: str | None) -> None:
    """Stamp last_seen in the registry entry for agent_id. Never crashes.

    Uses fcntl.flock (LOCK_EX) on POSIX to guard the read-modify-write cycle.
    On Windows, skips locking but still performs the update.
    """
    if not agent_id:
        return
    if not registry_path.exists():
        return
    try:
        if sys.platform != "win32":
            import fcntl as _fcntl

        with open(registry_path, "r", encoding="utf-8") as f:
            if sys.platform != "win32":
                _fcntl.flock(f, _fcntl.LOCK_EX)
            data = json.loads(f.read())

            if not isinstance(data, dict) or "agents" not in data:
                return

            agent = _find_agent_by_ref(data, agent_id)
            if agent is None:
                return

            agent["last_seen"] = datetime.now(timezone.utc).isoformat()
            tmp_path = registry_path.with_suffix(".tmp")
            tmp_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            os.replace(tmp_path, registry_path)
            # flock released when `with` block exits (f is closed)

    except Exception:
        return  # never crash the transport


def _notify_agent(agent: dict, speaker: str, next_action: str, issue: str) -> None:
    """Send a wake-up message to an agent's screen/tmux window.

    `issue` may be empty (e.g. for `create` actions where the issue number
    hasn't been assigned yet at the time the outbound file was written).
    """
    window = agent.get("window", "")
    mux = agent.get("mux", "")
    session = agent.get("session", "agency")
    name = agent.get("name") or agent.get("id", "?")

    issue_ref = str(issue).strip() if issue else ""
    if issue_ref and issue_ref not in ("?", "None"):
        msg = (
            f"Handoff from {speaker}: {next_action} "
            f"(issue #{issue_ref}). Check the issue for details."
        )
    else:
        msg = (
            f"New handoff from {speaker}: {next_action} "
            f"(check the latest thread in comms/ for details)."
        )

    try:
        if mux == "tmux":
            target = f"{session}:{window}"
            subprocess.run(
                ["tmux", "send-keys", "-t", target, msg, "Enter"],
                capture_output=True, check=True,
            )
        elif mux == "screen":
            # Split text + Enter into two calls — see agency.py
            # _runtime_screen_send_keys for the full history of why.
            screen_bin = _screen_binary()
            subprocess.run(
                [screen_bin, "-S", session, "-p", window, "-X", "stuff", msg],
                capture_output=True, check=True,
            )
            _time.sleep(NOTIFY_SUBMIT_DELAY)
            subprocess.run(
                [screen_bin, "-S", session, "-p", window, "-X", "stuff", "\r"],
                capture_output=True, check=True,
            )
        else:
            return  # unknown mux, skip silently

        print(f"  → Notified {name} ({window})")
    except (subprocess.CalledProcessError, OSError) as e:
        # Agent window may be gone (fired, crashed), or the mux binary
        # isn't installed in this context. Don't fail the transport —
        # notification is best-effort.
        print(f"  → Could not notify {name} ({window}): {e.__class__.__name__}")


def _try_notify_next_owner(body: str, meta: dict) -> None:
    """Parse the status packet and notify the next_owner if possible.

    Also handles `purpose_complete`: when an agent signals it's done, notify
    the manager so they can decide whether to fire or reassign. The agent
    stays alive until explicitly fired — no self-fire.
    """
    packet = _parse_status_packet(body)
    if not packet:
        return

    registry = _load_registry()
    issue = meta.get("issue", "?")
    speaker = packet.get("speaker", "someone")

    # Standard handoff: notify the next_owner
    if "next_owner" in packet:
        next_ref = packet["next_owner"]
        agent = _find_agent_by_ref(registry, next_ref)
        if agent:
            next_action = packet.get("next_action", "check the issue")
            purpose_note = ""
            if packet.get("purpose_complete"):
                purpose_note = (
                    f" {speaker} also signals purpose_complete — "
                    f"consider firing them with agency fire."
                )
            _notify_agent(
                agent, speaker,
                next_action + purpose_note,
                issue,
            )
        else:
            # next_owner not found — fall back to the speaker's hired_by
            print(
                f"WARNING: next_owner '{next_ref}' not found in active "
                f"registry — falling back to hired_by",
                file=sys.stderr,
            )
            # Find the speaker agent to look up their hired_by
            speaker_agent = _find_agent_by_ref(registry, speaker)
            if speaker_agent:
                hired_by = speaker_agent.get("hired_by", "")
                if hired_by:
                    fallback_agent = _find_agent_by_ref(registry, hired_by)
                    if fallback_agent:
                        next_action = packet.get("next_action", "check the issue")
                        fallback_note = (
                            f" (note: next_owner '{next_ref}' was unresolved"
                            f" — routed to hired_by instead)"
                        )
                        purpose_note = ""
                        if packet.get("purpose_complete"):
                            purpose_note = (
                                f" {speaker} also signals purpose_complete"
                                f" — consider firing them with agency fire."
                            )
                        _notify_agent(
                            fallback_agent, speaker,
                            next_action + fallback_note + purpose_note,
                            issue,
                        )
                    else:
                        print(
                            f"WARNING: hired_by fallback also not found "
                            f"— notification skipped",
                            file=sys.stderr,
                        )
                else:
                    print(
                        f"WARNING: hired_by fallback also not found "
                        f"— notification skipped",
                        file=sys.stderr,
                    )


def _process_single_file(
    path: Path, conf: dict, backend_override: str | None, dry_run: bool
) -> bool:
    """Parse, dispatch, and clean up a single outbound message file.

    Returns True if a message was processed, False if the file was empty
    or contained only the template (no real content to send).
    """
    meta, body = parse_outbound(path)
    action = meta.get("action", "").lower()

    # Skip template-only files (no issue set, no body — just the scaffold).
    if not action or (not meta.get("issue") and not body and action == "comment"):
        return False

    if action not in ACTIONS:
        print(f"ERROR: Unknown action '{action}' in {path}. Valid: {', '.join(ACTIONS)}")
        return False

    backend_name = backend_override or meta.get("backend") or conf.get("backend", "github")

    if dry_run:
        print(f"[DRY RUN] file={path} backend={backend_name} action={action} meta={meta}")
        print(f"[DRY RUN] body={body[:200]}{'...' if len(body) > 200 else ''}")
        return True

    backend = get_backend(backend_name, conf)
    dispatch(backend, action, meta, body)

    # M2: after a successful post, check for a handoff status packet and
    # notify the next agent in the chain. Fires on both `comment` (reply on
    # an existing thread) and `create` (opening a brand-new thread as a
    # handoff, e.g. platform-engineer files an install-complete issue
    # addressed to the chief — #75).
    if action in ("comment", "create"):
        _try_notify_next_owner(body, meta)
        # Bump last_seen for the agent that posted this message.
        # Derive agent_id from the counter-named filename (<counter>-<agent-id>.md)
        # and fall back to the speaker field in the status packet.
        _stem_parts = path.stem.split("-", 1)
        _agent_id = (
            _stem_parts[1]
            if len(_stem_parts) == 2 and _stem_parts[0].isdigit()
            else None
        )
        if not _agent_id:
            _pkt = _parse_status_packet(body)
            _agent_id = (_pkt or {}).get("speaker")
        _bump_last_seen(DEFAULT_REGISTRY, _agent_id)

    return True


def main() -> None:
    parser = argparse.ArgumentParser(description="Collab Bus Transport (GitHub & GitLab Issues)")
    parser.add_argument("--file", type=Path, default=None,
                        help="Process a single outbound file (legacy mode)")
    parser.add_argument("--queue-dir", type=Path, default=DEFAULT_QUEUE_DIR,
                        help="Queue directory to scan (default: tmp/outbound/)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Parse and display the action without executing")
    parser.add_argument("--backend", choices=["github", "gitlab"],
                        help="Override the backend (default: from conf or github)")
    parser.add_argument("--conf", type=Path, default=DEFAULT_CONF,
                        help="Path to collab_bus.conf (default: comms/collab_bus.conf)")
    args = parser.parse_args()

    conf = load_conf(args.conf)

    # --- Explicit single-file mode (legacy / manual use) ---
    if args.file:
        if not args.file.exists():
            print(f"ERROR: {args.file} not found. Run 'agency collab-bus' to scaffold.")
            sys.exit(1)
        if _process_single_file(args.file, conf, args.backend, args.dry_run):
            args.file.write_text(TEMPLATE, encoding="utf-8")
            print(f"\n{args.file} reset for next message.")
        else:
            print(f"Nothing to send in {args.file}.")
        return

    # --- Queue-directory mode (default for multi-agent runtime) ---
    #
    # Each agent writes its own file to tmp/outbound/ using the naming
    # convention: <timestamp>-<agent-id>.md (e.g. 20260412-001530-po-sarah.md).
    # Files are processed in sorted order (timestamp prefix guarantees FIFO)
    # and deleted after successful dispatch. This eliminates the collision
    # problem where multiple agents clobbered each other writing to a single
    # shared tmp/outbound.md.
    queue_dir = args.queue_dir
    if queue_dir.is_dir():
        queue_files = sorted(queue_dir.glob("*.md"))
        if queue_files:
            processed = 0
            for qf in queue_files:
                try:
                    if _process_single_file(qf, conf, args.backend, args.dry_run):
                        if not args.dry_run:
                            qf.unlink()
                        processed += 1
                except Exception as e:
                    print(f"ERROR processing {qf.name}: {e}")
            print(f"\nProcessed {processed}/{len(queue_files)} queued message(s).")
            return

    # --- Fallback: legacy single-file mode ---
    # If the queue dir is empty or doesn't exist, check the old
    # tmp/outbound.md for backward compat with pre-queue installs.
    legacy = DEFAULT_OUTBOUND
    if legacy.exists():
        if _process_single_file(legacy, conf, args.backend, args.dry_run):
            legacy.write_text(TEMPLATE, encoding="utf-8")
            print(f"\n{legacy} reset for next message.")
        else:
            print(f"Nothing to send (queue dir empty, {legacy} is template-only).")
    else:
        print(
            f"Nothing to send. Write to {queue_dir}/<name>.md "
            f"or {legacy} then re-run."
        )


if __name__ == "__main__":
    main()
