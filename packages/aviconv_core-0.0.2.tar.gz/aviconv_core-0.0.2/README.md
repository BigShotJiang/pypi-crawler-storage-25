# aviconv-core

Shared utilities for the [`aviconv`](https://github.com/ams-dev25/aviconv) family of
aviation-data converters.

This package is the foundation that the format-specific converters
(`aviconv-notam`, `aviconv-fpl`, `aviconv-met`, `aviconv-aixm`) build on. It
intentionally has a small surface area:

- `aviconv_core.coords` — DMS / decimal / signed-decimal coordinate parsing and
  formatting, plus projection helpers via `pyproj`.
- `aviconv_core.airac` — AIRAC cycle math (cycle ↔ effective date, current
  cycle, next/previous cycle).
- `aviconv_core.xml_utils` — lxml helpers, namespace registry, and a cached
  XML-Schema (XSD) loader for validating AIXM / FIXM / IWXXM output.
- `aviconv_core.errors` — typed exception hierarchy used across the family.
- `aviconv_core.cli` — `aviconv` console-script entry point that dispatches to
  format-specific sub-commands installed by sibling packages.

## Install

```bash
pip install aviconv-core
```

## Quick examples

```python
from aviconv_core import coords, airac

coords.parse_lat("503000N")     # 50.5
coords.parse_lon("0001500W")    # -0.25

airac.current_cycle().identifier  # e.g. "2605"
airac.cycle_for_date("2026-05-07").effective_date.isoformat()
```

## License

MIT.
