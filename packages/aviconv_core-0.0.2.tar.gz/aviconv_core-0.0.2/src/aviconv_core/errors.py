"""Typed exception hierarchy shared across the aviconv family.

All sub-packages (``aviconv-notam``, ``aviconv-fpl``, ...) raise subclasses of
:class:`AviconvError` so callers can catch a single base when they want to
treat any aviconv failure uniformly:

>>> from aviconv_core import AviconvError
>>> try:
...     ...  # parse, validate, convert
... except AviconvError as exc:
...     ...  # one branch handles every aviconv-originated failure

Exceptions deliberately stay shallow — we want callers to recognise *what
went wrong* (parse vs. validate vs. coordinate) without learning a deep tree.
"""

from __future__ import annotations


class AviconvError(Exception):
    """Base class for every exception raised by an aviconv package."""


class ParseError(AviconvError):
    """Input could not be parsed into a structured model.

    Used by text parsers (NOTAM free-text, ICAO FPL, METAR/TAF, ...) and by
    XML readers when the document is well-formed but does not match the
    expected element structure.
    """


class SchemaError(AviconvError):
    """A bundled XSD or JSON schema could not be loaded or compiled.

    Distinct from :class:`ValidationError`: this is "the schema itself is
    broken or missing", not "the document failed to validate".
    """


class ValidationError(AviconvError):
    """A parsed model or serialized output failed schema/business validation.

    Carries the optional ``errors`` attribute — a list of human-readable
    messages — so callers can present every issue at once instead of just
    the first.
    """

    def __init__(self, message: str, errors: list[str] | None = None) -> None:
        super().__init__(message)
        self.errors: list[str] = list(errors) if errors else []


class CoordinateError(AviconvError):
    """A coordinate string could not be parsed or is out of valid range."""
