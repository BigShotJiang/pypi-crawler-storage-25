"""``aviconv`` CLI dispatcher.

The format-specific sub-commands (``notam``, ``fpl``, ``met``, ``aixm``) are
discovered at runtime via Python's entry-point mechanism. Each sibling
package — ``aviconv-notam`` and friends — registers a top-level Click group
under the ``aviconv.commands`` entry-point, and this dispatcher mounts every
discovered group as a sub-command of the root :func:`main`.

This means installing only ``aviconv-notam`` gives you::

    $ aviconv --help
    Usage: aviconv [OPTIONS] COMMAND [ARGS]...

    Commands:
      coords  Coordinate conversion utilities.
      notam   ICAO NOTAM parsing and conversion.

…while installing every package fills out the full command set without any
import-time dependency on the optional siblings.
"""

from __future__ import annotations

import sys
from importlib.metadata import entry_points

import click

from aviconv_core import __version__
from aviconv_core import coords as _coords
from aviconv_core.errors import CoordinateError

# ---------------------------------------------------------------------------
# Built-in command group: `aviconv coords`
# ---------------------------------------------------------------------------


@click.group(name="coords")
def coords_group() -> None:
    """Coordinate conversion utilities (DMS / decimal / ICAO fixed-width)."""


@coords_group.command("parse")
@click.argument("text")
@click.option(
    "--axis",
    type=click.Choice(["lat", "lon", "pair"]),
    default="pair",
    help="Whether TEXT is a single latitude, longitude, or a 'lat lon' pair.",
)
def coords_parse(text: str, axis: str) -> None:
    """Parse an ICAO coordinate string and print decimal degrees."""
    try:
        if axis == "lat":
            click.echo(f"{_coords.parse_lat(text):.6f}")
        elif axis == "lon":
            click.echo(f"{_coords.parse_lon(text):.6f}")
        else:
            lat, lon = _coords.parse_pair(text)
            click.echo(f"{lat:.6f} {lon:.6f}")
    except CoordinateError as exc:
        raise click.ClickException(str(exc)) from exc


@coords_group.command("format")
@click.argument("decimal", type=float)
@click.option(
    "--axis",
    type=click.Choice(["lat", "lon"]),
    required=True,
    help="Which axis DECIMAL belongs to.",
)
@click.option(
    "--precision",
    type=click.Choice(["minutes", "seconds"]),
    default="seconds",
)
@click.option(
    "--fractional",
    type=click.IntRange(min=0, max=6),
    default=0,
    help="Fractional digits on the smallest unit.",
)
def coords_format(decimal: float, axis: str, precision: str, fractional: int) -> None:
    """Format a decimal-degrees value as an ICAO fixed-width coordinate."""
    try:
        formatter = _coords.format_lat if axis == "lat" else _coords.format_lon
        click.echo(formatter(decimal, precision=precision, fractional=fractional))  # type: ignore[arg-type]
    except CoordinateError as exc:
        raise click.ClickException(str(exc)) from exc


# ---------------------------------------------------------------------------
# Root command + plugin loader
# ---------------------------------------------------------------------------


def _load_plugin_groups() -> list[click.Command]:
    """Return Click groups registered by sibling packages.

    Each plugin advertises an entry-point in the ``aviconv.commands`` group
    pointing to a :class:`click.Command` (typically a :class:`click.Group`).
    Failures are reported on stderr but do not crash the CLI: a broken
    plugin should not make the rest of the tool unusable.
    """
    discovered: list[click.Command] = []
    eps = entry_points(group="aviconv.commands")
    for ep in eps:
        try:
            cmd = ep.load()
        except Exception as exc:  # pragma: no cover - defensive
            click.echo(f"aviconv: failed to load plugin {ep.name}: {exc}", err=True)
            continue
        if isinstance(cmd, click.Command):
            discovered.append(cmd)
    return discovered


@click.group(
    name="aviconv",
    context_settings={"help_option_names": ["-h", "--help"]},
)
@click.version_option(__version__, prog_name="aviconv")
def main() -> None:
    """Aviation-data converters: NOTAM, FPL, METAR/TAF, AIXM, FIXM."""


# Mount built-in groups.
main.add_command(coords_group)

# Mount plugin groups discovered at import time. Done at module top level so
# `aviconv --help` lists everything available without a separate runtime call.
for _cmd in _load_plugin_groups():
    main.add_command(_cmd)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
