"""XML helpers shared across aviconv readers/writers.

Aviation XML formats (AIXM 5.1.1, FIXM 4.x, IWXXM 3.0, AIXM Event Schema)
all carry deeply nested namespace prefixes. Hand-managing those leads to
subtle bugs and copy-paste drift between sub-packages. This module gives
each format-specific writer one place to:

- look up canonical namespace URIs by short name,
- build :class:`lxml.etree.QName` objects without typoed prefixes,
- create a parser hardened against XXE / billion-laughs attacks,
- and load + cache compiled XSD schemas for validation.

We deliberately keep this surface tiny — the format-specific quirks
belong in the per-format modules; this file is just the toolbox.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import TYPE_CHECKING, Final

from aviconv_core.errors import SchemaError, ValidationError

if TYPE_CHECKING:  # pragma: no cover - typing only
    from lxml import etree as _etree
    from xmlschema import XMLSchema11

# ---------------------------------------------------------------------------
# Canonical namespace registry
# ---------------------------------------------------------------------------
#
# Short-name → URI. Sub-packages may extend this at import time by writing
# additional entries (e.g. AIXM 5.1.1 extension namespaces) — the registry
# is intentionally a plain dict, not frozen.

NAMESPACES: Final[dict[str, str]] = {
    # Generic
    "xsi": "http://www.w3.org/2001/XMLSchema-instance",
    "xlink": "http://www.w3.org/1999/xlink",
    # OGC / GML — used by AIXM and IWXXM for geometry
    "gml": "http://www.opengis.net/gml/3.2",
    # AIXM 5.1.1 core
    "aixm": "http://www.aixm.aero/schema/5.1.1",
    "aixm-evt": "http://www.aixm.aero/schema/5.1.1/event",
    # FIXM 4.3
    "fx": "http://www.fixm.aero/flight/4.3",
    "fb": "http://www.fixm.aero/base/4.3",
    # WMO IWXXM 3.0
    "iwxxm": "http://icao.int/iwxxm/3.0",
    "metce": "http://def.wmo.int/metce/2013",
    "om": "http://www.opengis.net/om/2.0",
    "sams": "http://www.opengis.net/samplingSpatial/2.0",
}


def qname(prefix: str, local: str) -> str:
    """Return a Clark-notation ``{ns}local`` string for an lxml QName.

    >>> qname("gml", "Point")
    '{http://www.opengis.net/gml/3.2}Point'
    """
    try:
        ns = NAMESPACES[prefix]
    except KeyError as exc:
        raise SchemaError(f"unknown namespace prefix: {prefix!r}") from exc
    return f"{{{ns}}}{local}"


# ---------------------------------------------------------------------------
# Hardened parser
# ---------------------------------------------------------------------------


def safe_parser() -> _etree.XMLParser:
    """Return an :class:`lxml.etree.XMLParser` configured to refuse XXE,
    DTD-based denial-of-service, and external entity expansion.

    All aviconv readers should parse untrusted XML through this parser; never
    the lxml default. The settings cost almost nothing at parse time and
    eliminate an entire class of vulnerabilities.
    """
    from lxml import etree

    return etree.XMLParser(
        resolve_entities=False,
        no_network=True,
        load_dtd=False,
        dtd_validation=False,
        huge_tree=False,
    )


# ---------------------------------------------------------------------------
# XSD schema cache
# ---------------------------------------------------------------------------
#
# We use the ``xmlschema`` package rather than lxml's built-in XMLSchema
# because it handles XSD 1.1 (required for IWXXM) and produces structured
# error reports we can wrap into :class:`ValidationError`.


@lru_cache(maxsize=16)
def load_schema(xsd_path: str | Path) -> XMLSchema11:
    """Load and cache an XSD 1.1 schema from disk.

    >>> schema = load_schema("packages/aviconv-aixm/schemas/aixm-5.1.1/AIXM_Features.xsd")  # doctest: +SKIP
    """
    from xmlschema import XMLSchema11

    path = Path(xsd_path)
    if not path.is_file():
        raise SchemaError(f"schema file not found: {path}")
    try:
        return XMLSchema11(str(path))
    except Exception as exc:  # xmlschema raises a variety of exception types
        raise SchemaError(f"failed to load schema {path}: {exc}") from exc


def validate(xml: bytes | str | _etree._Element, xsd_path: str | Path) -> None:
    """Validate XML against an XSD; raise :class:`ValidationError` on failure.

    The XML may be a serialized document (bytes/str) or an already-parsed
    lxml element. All errors are collected so the caller sees every issue
    in a single exception.
    """
    from lxml import etree as _et

    schema = load_schema(xsd_path)

    if isinstance(xml, _et._Element):
        document: bytes | str = _et.tostring(xml)
    else:
        document = xml

    errors: list[str] = [str(err) for err in schema.iter_errors(document)]
    if errors:
        raise ValidationError(
            f"document failed validation against {Path(xsd_path).name}",
            errors=errors,
        )
