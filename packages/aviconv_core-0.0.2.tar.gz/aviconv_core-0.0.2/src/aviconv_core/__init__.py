"""aviconv-core — shared utilities for the aviconv converter family.

Re-exports the most commonly used public symbols from sub-modules so
downstream packages can ``from aviconv_core import ...`` ergonomically.
"""

from __future__ import annotations

from aviconv_core import airac, coords, errors, xml_utils
from aviconv_core.errors import (
    AviconvError,
    CoordinateError,
    ParseError,
    SchemaError,
    ValidationError,
)

__all__ = [
    "AviconvError",
    "CoordinateError",
    "ParseError",
    "SchemaError",
    "ValidationError",
    "__version__",
    "airac",
    "coords",
    "errors",
    "xml_utils",
]

__version__ = "0.0.1"
