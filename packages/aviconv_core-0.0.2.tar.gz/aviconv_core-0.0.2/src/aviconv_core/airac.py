"""AIRAC cycle math.

AIRAC (Aeronautical Information Regulation And Control) divides the calendar
into fixed 28-day cycles whose effective dates are coordinated worldwide.
Each cycle has an identifier ``YYNN`` where ``YY`` is the two-digit year of
the cycle's *effective* date and ``NN`` is its sequence within that year.
Most years have 13 cycles; roughly every seven years a 14th cycle is added.

This module is anchored to AIRAC cycle ``2001``, effective ``2020-01-02``.
That anchor is published by ICAO and EUROCONTROL and lets us compute every
past and future cycle with simple integer date arithmetic.

Public API
----------
:class:`Cycle`
    Immutable record: identifier, effective date, sequence-in-year.
:func:`cycle_for_date`
    Cycle that is in effect on a given date.
:func:`current_cycle`
    Convenience: cycle in effect today (UTC).
:func:`cycle_from_identifier`
    Round-trip lookup by ``"YYNN"`` identifier.
:func:`next_cycle` / :func:`previous_cycle`
    Adjacent cycles.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, date, datetime, timedelta

from aviconv_core.errors import ParseError

# Anchor: cycle 2001 (year 2020, sequence 01) was effective 2020-01-02.
# Source: ICAO / EUROCONTROL published AIRAC schedule.
_ANCHOR_DATE: date = date(2020, 1, 2)
_ANCHOR_INDEX: int = 0  # cycles since anchor; 0 means the anchor cycle itself.
_CYCLE_DAYS: int = 28


@dataclass(frozen=True, slots=True)
class Cycle:
    """One AIRAC cycle.

    Attributes:
        identifier: Four-character ``YYNN`` string (e.g. ``"2605"``).
        effective_date: Date the cycle becomes effective (always a Thursday).
        sequence: 1-based position within the effective year (1 .. 13 or 14).
    """

    identifier: str
    effective_date: date
    sequence: int

    @property
    def end_date(self) -> date:
        """Last day this cycle is in effect (inclusive). Next cycle begins
        the day after."""
        return self.effective_date + timedelta(days=_CYCLE_DAYS - 1)


def _cycle_at_index(index: int) -> Cycle:
    """Return the cycle whose offset from the anchor is ``index`` (may be
    negative for past cycles)."""
    eff = _ANCHOR_DATE + timedelta(days=_CYCLE_DAYS * (index - _ANCHOR_INDEX))
    sequence = _sequence_in_year(eff)
    identifier = f"{eff.year % 100:02d}{sequence:02d}"
    return Cycle(identifier=identifier, effective_date=eff, sequence=sequence)


def _sequence_in_year(eff: date) -> int:
    """How many cycles in ``eff.year`` have started on or before ``eff``."""
    # Walk back day-by-cycle to the first effective date in the same year.
    days_from_anchor = (eff - _ANCHOR_DATE).days
    index = days_from_anchor // _CYCLE_DAYS
    sequence = 1
    cursor_index = index
    while True:
        prev_index = cursor_index - 1
        prev_date = _ANCHOR_DATE + timedelta(days=_CYCLE_DAYS * prev_index)
        if prev_date.year != eff.year:
            return sequence
        sequence += 1
        cursor_index = prev_index


def cycle_for_date(when: date | datetime | str) -> Cycle:
    """Return the AIRAC cycle in effect on ``when``.

    Accepts a :class:`datetime.date`, a :class:`datetime.datetime` (date
    portion is used), or an ISO-8601 ``YYYY-MM-DD`` string.

    >>> cycle_for_date("2020-01-02").identifier
    '2001'
    >>> cycle_for_date("2020-01-29").identifier
    '2001'
    >>> cycle_for_date("2020-01-30").identifier
    '2002'
    """
    target = _coerce_date(when)
    delta_days = (target - _ANCHOR_DATE).days
    index = delta_days // _CYCLE_DAYS  # floor division handles negatives
    return _cycle_at_index(index)


def current_cycle() -> Cycle:
    """AIRAC cycle effective right now (UTC)."""
    return cycle_for_date(datetime.now(UTC).date())


def cycle_from_identifier(identifier: str) -> Cycle:
    """Look up a cycle by its ``YYNN`` identifier.

    The two-digit year is interpreted as 20YY (i.e. cycles span 2000-2099).
    Aviconv does not support pre-2000 cycles — they pre-date the anchor and
    no consumer of this library has asked for them.

    >>> cycle_from_identifier("2001").effective_date.isoformat()
    '2020-01-02'
    """
    if len(identifier) != 4 or not identifier.isdigit():
        raise ParseError(f"invalid AIRAC identifier: {identifier!r}")
    year = 2000 + int(identifier[:2])
    seq = int(identifier[2:])
    if seq < 1:
        raise ParseError(f"invalid AIRAC sequence in {identifier!r}")

    # Find the first cycle of the requested year, then step forward seq-1
    # cycles. We locate it by scanning the cycles around Jan 1 of that year;
    # this is O(1) in practice because at most one cycle straddles Jan 1.
    jan1 = date(year, 1, 1)
    start = cycle_for_date(jan1)
    if start.effective_date.year != year:
        # The cycle in effect on Jan 1 began in the prior year — step forward.
        start = next_cycle(start)
    if start.sequence != 1:
        # Defensive: should always be sequence 1 by construction.
        raise ParseError(f"could not locate first cycle of {year}")
    target = start
    for _ in range(seq - 1):
        target = next_cycle(target)
        if target.effective_date.year != year:
            raise ParseError(f"AIRAC {identifier} does not exist (year overflow)")
    return target


def next_cycle(cycle: Cycle) -> Cycle:
    """Cycle immediately after ``cycle``."""
    days = (cycle.effective_date - _ANCHOR_DATE).days
    return _cycle_at_index(days // _CYCLE_DAYS + 1)


def previous_cycle(cycle: Cycle) -> Cycle:
    """Cycle immediately before ``cycle``."""
    days = (cycle.effective_date - _ANCHOR_DATE).days
    return _cycle_at_index(days // _CYCLE_DAYS - 1)


def _coerce_date(value: date | datetime | str) -> date:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return date.fromisoformat(value)
        except ValueError as exc:
            raise ParseError(f"invalid ISO date: {value!r}") from exc
    raise TypeError(f"expected date/datetime/str, got {type(value).__name__}")
