"""Coordinate parsing, formatting, and projection helpers.

ICAO aviation formats encode latitude/longitude as fixed-width strings with a
trailing hemisphere letter — for example::

    503000N    505000.5N    0001500W    0001500.5W

This module parses every ICAO variant we have seen in real NOTAMs, FPLs, and
AIXM ARINC-424 fields, and round-trips them back to canonical text. For
projection work (lat/lon ↔ UTM/MGRS/projected planar) we delegate to
``pyproj`` rather than reimplementing geodesy — see :func:`transformer`.

Public API
----------
:func:`parse_lat` / :func:`parse_lon`
    Parse a single coordinate string to signed decimal degrees.
:func:`parse_pair`
    Parse a "lat lon" pair as it appears in NOTAM Q-lines and AIXM Point
    elements.
:func:`format_lat` / :func:`format_lon`
    Format signed decimal degrees back to ICAO fixed-width text.
:func:`transformer`
    Cached :class:`pyproj.Transformer` factory for lat/lon ↔ projected CRS
    conversions.
"""

from __future__ import annotations

import re
from functools import lru_cache
from typing import TYPE_CHECKING, Final, Literal

from aviconv_core.errors import CoordinateError

if TYPE_CHECKING:  # pragma: no cover - import only for typing
    from pyproj import Transformer

# ---------------------------------------------------------------------------
# ICAO fixed-width formats
# ---------------------------------------------------------------------------
#
# Latitude is 2 digits of degrees; longitude is 3. Both may carry minutes,
# seconds, and a fractional part. The hemisphere letter is the final char.
#
# Patterns (anchored, case-insensitive):
#   DDMM[.fff]H              e.g. 5030N         -> 50°30'00"N
#   DDMMSS[.fff]H            e.g. 503012.5N     -> 50°30'12.5"N
#   DDDMM[.fff]H             e.g. 00015W        ->  -0°15'00"W
#   DDDMMSS[.fff]H           e.g. 0001530W      ->  -0°15'30"W

_LAT_RE: Final = re.compile(
    r"""^
        (?P<deg>\d{2})
        (?P<min>\d{2})
        (?:(?P<sec>\d{2})(?:\.(?P<frac_s>\d+))?  # SS or SS.fff
           |\.(?P<frac_m>\d+)                     # or MM.fff (no seconds)
        )?
        (?P<hemi>[NS])
    $""",
    re.VERBOSE | re.IGNORECASE,
)

_LON_RE: Final = re.compile(
    r"""^
        (?P<deg>\d{3})
        (?P<min>\d{2})
        (?:(?P<sec>\d{2})(?:\.(?P<frac_s>\d+))?
           |\.(?P<frac_m>\d+)
        )?
        (?P<hemi>[EW])
    $""",
    re.VERBOSE | re.IGNORECASE,
)


def _parse_icao(value: str, regex: re.Pattern[str], pos_hemi: str, axis: str) -> float:
    """Common ICAO fixed-width coordinate parser used by ``parse_lat``/``parse_lon``."""
    match = regex.match(value.strip())
    if match is None:
        raise CoordinateError(f"not a valid ICAO {axis} coordinate: {value!r}")

    degrees = int(match["deg"])
    minutes = int(match["min"])
    seconds = 0.0
    if match["sec"] is not None:
        seconds = float(match["sec"])
        if match["frac_s"] is not None:
            seconds += float(f"0.{match['frac_s']}")
    elif match["frac_m"] is not None:
        # Fractional minutes (DDMM.fff) — convert to whole minutes + seconds.
        minutes_frac = float(f"0.{match['frac_m']}")
        seconds = minutes_frac * 60.0

    if minutes >= 60 or seconds >= 60.0:
        raise CoordinateError(f"minutes/seconds out of range in {axis} coordinate: {value!r}")

    decimal = degrees + minutes / 60.0 + seconds / 3600.0
    if match["hemi"].upper() != pos_hemi:
        decimal = -decimal

    if axis == "latitude" and not -90.0 <= decimal <= 90.0:
        raise CoordinateError(f"latitude out of range: {decimal}")
    if axis == "longitude" and not -180.0 <= decimal <= 180.0:
        raise CoordinateError(f"longitude out of range: {decimal}")
    return decimal


def parse_lat(value: str) -> float:
    """Parse an ICAO latitude string to signed decimal degrees.

    Accepts ``DDMMH``, ``DDMMSSH``, ``DDMM.fffH``, ``DDMMSS.fffH``
    (case-insensitive). N is positive, S is negative.

    >>> parse_lat("503000N")
    50.5
    >>> parse_lat("0030S")
    -0.5
    """
    return _parse_icao(value, _LAT_RE, "N", "latitude")


def parse_lon(value: str) -> float:
    """Parse an ICAO longitude string to signed decimal degrees.

    Accepts ``DDDMMH``, ``DDDMMSSH``, ``DDDMM.fffH``, ``DDDMMSS.fffH``.
    E is positive, W is negative.

    >>> parse_lon("0001500W")
    -0.25
    >>> parse_lon("1800000E")
    180.0
    """
    return _parse_icao(value, _LON_RE, "E", "longitude")


_PAIR_SPLIT: Final = re.compile(r"\s+")


def parse_pair(value: str) -> tuple[float, float]:
    """Parse a "lat lon" pair into ``(lat, lon)`` decimal degrees.

    The ICAO Q-line and many AIXM text fields concatenate the two coordinates
    with whitespace between them. We accept any run of whitespace.

    >>> parse_pair("503000N 0001500W")
    (50.5, -0.25)
    """
    parts = _PAIR_SPLIT.split(value.strip())
    if len(parts) != 2:
        raise CoordinateError(f"expected 'lat lon' pair, got: {value!r}")
    return parse_lat(parts[0]), parse_lon(parts[1])


# ---------------------------------------------------------------------------
# Formatting
# ---------------------------------------------------------------------------

_Precision = Literal["minutes", "seconds"]


def _format(
    decimal: float,
    *,
    deg_width: int,
    pos_hemi: str,
    neg_hemi: str,
    precision: _Precision,
    fractional: int,
) -> str:
    sign_pos = decimal >= 0
    abs_val = abs(decimal)
    degrees = int(abs_val)
    minutes_full = (abs_val - degrees) * 60.0

    if precision == "minutes":
        minutes_int = int(minutes_full)
        # Round fractional minutes; carry into degrees if it overflows.
        if fractional > 0:
            frac = round(minutes_full - minutes_int, fractional)
            mm_text = f"{minutes_int:02d}.{round(frac * 10**fractional):0{fractional}d}"
        else:
            # Round to whole minutes.
            minutes_int = round(minutes_full)
            if minutes_int == 60:
                minutes_int = 0
                degrees += 1
            mm_text = f"{minutes_int:02d}"
        body = f"{degrees:0{deg_width}d}{mm_text}"
    else:  # seconds
        minutes_int = int(minutes_full)
        seconds_full = (minutes_full - minutes_int) * 60.0
        if fractional > 0:
            seconds_rounded = round(seconds_full, fractional)
            ss_int = int(seconds_rounded)
            ss_frac = round((seconds_rounded - ss_int) * 10**fractional)
            ss_text = f"{ss_int:02d}.{ss_frac:0{fractional}d}"
        else:
            ss_int = round(seconds_full)
            if ss_int == 60:
                ss_int = 0
                minutes_int += 1
            if minutes_int == 60:
                minutes_int = 0
                degrees += 1
            ss_text = f"{ss_int:02d}"
        body = f"{degrees:0{deg_width}d}{minutes_int:02d}{ss_text}"

    return body + (pos_hemi if sign_pos else neg_hemi)


def format_lat(
    decimal: float,
    *,
    precision: _Precision = "seconds",
    fractional: int = 0,
) -> str:
    """Format a decimal-degrees latitude as an ICAO fixed-width string.

    >>> format_lat(50.5)
    '503000N'
    >>> format_lat(-0.5, precision="minutes")
    '0030S'
    """
    if not -90.0 <= decimal <= 90.0:
        raise CoordinateError(f"latitude out of range: {decimal}")
    return _format(
        decimal,
        deg_width=2,
        pos_hemi="N",
        neg_hemi="S",
        precision=precision,
        fractional=fractional,
    )


def format_lon(
    decimal: float,
    *,
    precision: _Precision = "seconds",
    fractional: int = 0,
) -> str:
    """Format a decimal-degrees longitude as an ICAO fixed-width string.

    >>> format_lon(-0.25)
    '0001500W'
    >>> format_lon(180.0, precision="minutes")
    '18000E'
    """
    if not -180.0 <= decimal <= 180.0:
        raise CoordinateError(f"longitude out of range: {decimal}")
    return _format(
        decimal,
        deg_width=3,
        pos_hemi="E",
        neg_hemi="W",
        precision=precision,
        fractional=fractional,
    )


# ---------------------------------------------------------------------------
# Projection helpers (thin wrapper around pyproj)
# ---------------------------------------------------------------------------


@lru_cache(maxsize=64)
def transformer(src: str, dst: str, *, always_xy: bool = True) -> Transformer:
    """Return a cached :class:`pyproj.Transformer` for ``src`` → ``dst``.

    Use ``always_xy=True`` (the default) so callers can pass
    ``(lon, lat)`` and get ``(x, y)`` back in the projected CRS, matching
    GeoJSON's coordinate ordering.

    >>> t = transformer("EPSG:4326", "EPSG:32633")  # WGS84 -> UTM 33N
    >>> x, y = t.transform(13.0, 52.0)              # lon, lat
    """
    # Imported lazily so importing aviconv_core does not pull pyproj's heavy
    # PROJ database into memory unless someone actually needs projections.
    from pyproj import Transformer as _T

    return _T.from_crs(src, dst, always_xy=always_xy)
