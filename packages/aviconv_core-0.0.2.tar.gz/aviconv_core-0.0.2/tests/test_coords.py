"""Tests for ``aviconv_core.coords``.

Coverage focus:
- Every ICAO width/precision variant we expect to encounter in NOTAM, FPL,
  and AIXM (DDMM, DDMMSS, DDMM.fff, DDMMSS.fff for lat; DDDMM* for lon).
- Hemisphere handling (N/S, E/W).
- Round-trip parse → format → parse stability for canonical values.
- Defensive: out-of-range, malformed, empty.
"""

from __future__ import annotations

import math

import pytest

from aviconv_core.coords import (
    format_lat,
    format_lon,
    parse_lat,
    parse_lon,
    parse_pair,
)
from aviconv_core.errors import CoordinateError


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("503000N", 50.5),
        ("503000n", 50.5),
        ("0030N", 0.5),
        ("0030S", -0.5),
        ("503012.5N", 50.50347222222222),
        ("5030.5N", 50.508333333333334),
        ("000000N", 0.0),
        ("900000N", 90.0),
        ("900000S", -90.0),
    ],
)
def test_parse_lat(text: str, expected: float) -> None:
    assert math.isclose(parse_lat(text), expected, abs_tol=1e-9)


@pytest.mark.parametrize(
    ("text", "expected"),
    [
        ("0001500W", -0.25),
        ("0001500E", 0.25),
        ("00015W", -0.25),
        ("1800000E", 180.0),
        ("1800000W", -180.0),
        ("0731012.5E", 73.17013888888888),
    ],
)
def test_parse_lon(text: str, expected: float) -> None:
    assert math.isclose(parse_lon(text), expected, abs_tol=1e-9)


def test_parse_pair() -> None:
    lat, lon = parse_pair("503000N 0001500W")
    assert math.isclose(lat, 50.5)
    assert math.isclose(lon, -0.25)


@pytest.mark.parametrize(
    "bad",
    [
        "",
        "abc",
        "503000",  # no hemisphere
        "503000E",  # wrong hemisphere for lat
        "0001500N",  # wrong hemisphere for lon
        "9100000N",  # latitude > 90
        "1810000E",  # longitude > 180
        "506000N",  # minutes >= 60
        "503060N",  # seconds >= 60
    ],
)
def test_parse_lat_or_lon_rejects(bad: str) -> None:
    with pytest.raises(CoordinateError):
        # try as lat first; if it parses (it shouldn't), try as lon to
        # make sure neither accepts the malformed input
        try:
            parse_lat(bad)
        except CoordinateError:
            parse_lon(bad)


def test_format_lat_seconds() -> None:
    assert format_lat(50.5) == "503000N"
    assert format_lat(-0.5) == "003000S"


def test_format_lat_minutes() -> None:
    assert format_lat(50.5, precision="minutes") == "5030N"
    assert format_lat(0.0, precision="minutes") == "0000N"


def test_format_lon_seconds() -> None:
    assert format_lon(-0.25) == "0001500W"
    assert format_lon(180.0) == "1800000E"


@pytest.mark.parametrize(
    "lat",
    [0.0, 50.5, -0.5, 89.999, -89.999],
)
def test_round_trip_lat(lat: float) -> None:
    # 1e-5 deg ≈ 1 m on Earth — well within ICAO precision requirements,
    # and tolerant of float drift through degrees/minutes/seconds split.
    text = format_lat(lat, precision="seconds", fractional=3)
    again = parse_lat(text)
    assert math.isclose(lat, again, abs_tol=1e-5)


@pytest.mark.parametrize(
    "lon",
    [0.0, -0.25, 73.170138, 179.999, -179.999],
)
def test_round_trip_lon(lon: float) -> None:
    text = format_lon(lon, precision="seconds", fractional=3)
    again = parse_lon(text)
    assert math.isclose(lon, again, abs_tol=1e-5)


def test_format_rejects_out_of_range() -> None:
    with pytest.raises(CoordinateError):
        format_lat(91.0)
    with pytest.raises(CoordinateError):
        format_lon(-181.0)
