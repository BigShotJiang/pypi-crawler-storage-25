"""Tests for ``aviconv_core.airac``.

Anchor sanity: cycle 2001 must map to 2020-01-02. Every other property
(spacing, sequence numbering, identifier round-trip) is derived from that.
"""

from __future__ import annotations

from datetime import date, timedelta

import pytest

from aviconv_core.airac import (
    Cycle,
    current_cycle,
    cycle_for_date,
    cycle_from_identifier,
    next_cycle,
    previous_cycle,
)
from aviconv_core.errors import ParseError


def test_anchor_cycle() -> None:
    cycle = cycle_for_date("2020-01-02")
    assert cycle.identifier == "2001"
    assert cycle.effective_date == date(2020, 1, 2)
    assert cycle.sequence == 1


def test_cycle_spans_28_days() -> None:
    c = cycle_for_date("2020-01-02")
    # Last day still in cycle.
    assert cycle_for_date(c.effective_date + timedelta(days=27)).identifier == "2001"
    # First day of the next cycle.
    assert cycle_for_date(c.effective_date + timedelta(days=28)).identifier == "2002"


def test_next_and_previous_round_trip() -> None:
    c = cycle_for_date("2020-01-02")
    assert previous_cycle(next_cycle(c)) == c
    assert next_cycle(previous_cycle(c)) == c


def test_sequence_resets_at_year_boundary() -> None:
    """The first cycle whose effective_date.year == Y must have sequence 1."""
    # Walk through 2021's cycles and confirm sequence numbering.
    c = cycle_from_identifier("2101")
    assert c.sequence == 1
    assert c.effective_date.year == 2021
    # The cycle right before should be the last one of 2020.
    prev = previous_cycle(c)
    assert prev.effective_date.year == 2020
    assert prev.sequence >= 13  # 2020 had 13 cycles


def test_identifier_round_trip() -> None:
    for ident in ["2001", "2007", "2113", "2206", "2605"]:
        cycle = cycle_from_identifier(ident)
        assert cycle.identifier == ident
        assert cycle_for_date(cycle.effective_date).identifier == ident


@pytest.mark.parametrize("bad", ["", "20", "abcd", "20XX", "2000"])
def test_invalid_identifier(bad: str) -> None:
    with pytest.raises(ParseError):
        cycle_from_identifier(bad)


def test_current_cycle_is_a_cycle() -> None:
    c = current_cycle()
    assert isinstance(c, Cycle)
    assert len(c.identifier) == 4
    # Effective date is in the past or today.
    assert c.effective_date <= date.today()


def test_end_date() -> None:
    c = cycle_for_date("2020-01-02")
    assert c.end_date == date(2020, 1, 29)  # 28-day cycle, inclusive end
