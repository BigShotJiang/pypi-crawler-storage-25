"""Smoke tests for the ``aviconv`` CLI dispatcher."""

from __future__ import annotations

from click.testing import CliRunner

from aviconv_core.cli import main


def test_help_lists_coords_subcommand() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "coords" in result.output


def test_version_flag() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "aviconv" in result.output


def test_coords_parse_pair() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["coords", "parse", "503000N 0001500W"])
    assert result.exit_code == 0
    assert result.output.strip() == "50.500000 -0.250000"


def test_coords_parse_invalid() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["coords", "parse", "garbage"])
    assert result.exit_code != 0


def test_coords_format() -> None:
    runner = CliRunner()
    result = runner.invoke(main, ["coords", "format", "--axis", "lat", "50.5"])
    assert result.exit_code == 0
    assert result.output.strip() == "503000N"
