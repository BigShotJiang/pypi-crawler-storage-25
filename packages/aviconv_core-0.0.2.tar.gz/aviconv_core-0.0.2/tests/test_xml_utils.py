"""Tests for ``aviconv_core.xml_utils``.

We focus on:
- the namespace registry round-tripping through ``qname``,
- the safe parser rejecting external entities (XXE),
- ``load_schema`` raising a typed error for missing/broken files.

Schema-validation happy paths are exercised in the format-specific packages
that ship actual XSDs.
"""

from __future__ import annotations

import pytest

from aviconv_core.errors import SchemaError
from aviconv_core.xml_utils import NAMESPACES, qname, safe_parser


def test_qname_known_prefix() -> None:
    assert qname("gml", "Point") == "{http://www.opengis.net/gml/3.2}Point"


def test_qname_unknown_prefix() -> None:
    with pytest.raises(SchemaError):
        qname("nope", "Foo")


def test_namespaces_have_unique_uris() -> None:
    # Defensive: typo'd duplicate URIs cause silent prefix collisions.
    uris = list(NAMESPACES.values())
    assert len(uris) == len(set(uris))


def test_safe_parser_blocks_external_entities(tmp_path) -> None:  # type: ignore[no-untyped-def]
    """The hardened parser must not resolve external entities (XXE)."""
    from lxml import etree

    secret = tmp_path / "secret.txt"
    secret.write_text("ATTACKER_READS_THIS")

    payload = f"""<?xml version="1.0"?>
<!DOCTYPE root [
  <!ENTITY xxe SYSTEM "{secret.as_uri()}">
]>
<root>&xxe;</root>
""".encode()

    parser = safe_parser()
    tree = etree.fromstring(payload, parser)
    # With resolve_entities=False the entity reference is not expanded into
    # the file contents.
    assert "ATTACKER_READS_THIS" not in (tree.text or "")


def test_load_schema_missing_file() -> None:
    from aviconv_core.xml_utils import load_schema

    with pytest.raises(SchemaError):
        load_schema("/nonexistent/path/to/schema.xsd")
