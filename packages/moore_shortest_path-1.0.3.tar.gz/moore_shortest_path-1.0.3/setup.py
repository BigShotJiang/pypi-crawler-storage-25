from setuptools import setup, find_packages

setup(
    name="moore-shortest-path",          # PyPI distribution name
    version="1.0.3",                     # bump version each release
    description="Implementation of Moore's shortest path algorithm in Python",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/yourusername/moore_algorithm",
    license="MIT",
    packages=find_packages(include=["moore_algorithm", "moore_algorithm.*"]),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
        "Intended Audience :: Developers",
    ],
    python_requires=">=3.7",
)
