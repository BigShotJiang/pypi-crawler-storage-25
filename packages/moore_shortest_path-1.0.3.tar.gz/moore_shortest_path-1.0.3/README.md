# moore_algorithm

A Python implementation of Moore's shortest path algorithm.

## Installation
```bash
pip install moore_algorithm
Usage
from moore import moore_shortest_path

graph = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E']
}

print(moore_shortest_path(graph, 'A'))
License

3. Save the file.
4. Bump the version in `setup.py` (e.g. `version="1.0.6"`).
5. Rebuild and upload again:
   ```powershell
   Remove-Item -Recurse -Force dist
   python setup.py sdist bdist_wheel
   twine upload dist/*
