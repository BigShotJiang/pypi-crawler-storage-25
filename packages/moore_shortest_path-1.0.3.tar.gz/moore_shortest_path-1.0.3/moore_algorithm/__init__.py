from collections import deque


def moore_shortest_path(graph, start):
    if start not in graph:
        raise ValueError(f"Start node '{start}' not found in graph.")
    distance = {node: float('inf') for node in graph}
    distance[start] = 0
    queue = deque([start])
    while queue:
        current = queue.popleft()
        for neighbor in graph[current]:
            if distance[neighbor] == float('inf'):
                distance[neighbor] = distance[current] + 1
                queue.append(neighbor)
    return distance


def moore_shortest_path_with_path(graph, start, target):
    if start not in graph:
        raise ValueError(f"Start node '{start}' not found in graph.")
    if target not in graph:
        raise ValueError(f"Target node '{target}' not found in graph.")
    distance = {node: float('inf') for node in graph}
    parent = {node: None for node in graph}
    distance[start] = 0
    queue = deque([start])
    while queue:
        current = queue.popleft()
        for neighbor in graph[current]:
            if distance[neighbor] == float('inf'):
                distance[neighbor] = distance[current] + 1
                parent[neighbor] = current
                queue.append(neighbor)
    if distance[target] == float('inf'):
        return None
    path = []
    node = target
    while node is not None:
        path.append(node)
        node = parent[node]
    path.reverse()
    return path