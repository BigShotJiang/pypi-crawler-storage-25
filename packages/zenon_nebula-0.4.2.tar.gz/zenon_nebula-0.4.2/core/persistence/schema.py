# SPDX-License-Identifier: MIT
"""
Schema definition, migration, and DB maintenance for the Nebula evidence store.

Owns:
- SCHEMA_SQL: canonical DDL for all core tables declared in persist_to_db
- DEFAULT_DB: canonical path to data/engine.db
- _get_connection: SQLite connection with WAL + memory tuning
- ensure_schema: idempotent migration + schema bootstrap
- maintain_db: periodic prune / vacuum / integrity check
"""

from __future__ import annotations

import logging
import sqlite3
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")


# -- Schema DDL --

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS evidence (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    domain TEXT NOT NULL DEFAULT 'system',
    engine TEXT,
    evidence_type TEXT,
    finding TEXT,
    confidence REAL DEFAULT 0.0,
    supports_hypothesis TEXT,
    contradicts_hypothesis TEXT,
    verification_url TEXT,
    raw_data TEXT,
    provenance TEXT DEFAULT 'hypothesis',
    published BOOLEAN DEFAULT FALSE,
    run_id TEXT,
    parent_finding_id INTEGER,
    source_repo TEXT,
    source_file TEXT,
    source_commit TEXT,
    source_line INTEGER,
    reproducible_command TEXT,
    status TEXT DEFAULT 'open',
    resolved_by TEXT,
    resolved_at DATETIME,
    related_findings TEXT,
    -- v0.3.3 — attribution + content addressing foundation for v0.4.0.
    -- discoverer_peer_id: which peer instance produced this finding
    --   (local peer_id for local-scan findings, remote peer_id for
    --   transport-imported findings). First-class column so reward
    --   attribution is queryable without touching raw_data JSON.
    -- content_hash: SHA-256 over (engine, evidence_type, finding,
    --   source_file, source_line, source_commit). The canonical
    --   identity of a finding. Same content_hash from multiple peers
    --   = corroboration (not dedup). Future dedup key. Also the key
    --   the future nebula_attestation contract would hash on-chain.
    -- signature: optional cryptographic signature over the content_hash
    --   by the discoverer_peer_id's private key (when the peer is
    --   running in signed mode). NULL for unsigned findings.
    discoverer_peer_id TEXT,
    content_hash TEXT,
    signature TEXT,
    -- Optional alternative columns used by some domain engines that
    -- write directly to the evidence table with a richer shape:
    finding_type TEXT,
    title TEXT,
    body TEXT,
    source TEXT
);

CREATE TABLE IF NOT EXISTS hypotheses (
    id TEXT PRIMARY KEY,
    domain TEXT NOT NULL DEFAULT 'system',
    title TEXT,
    evidence_for TEXT DEFAULT '[]',
    evidence_against TEXT DEFAULT '[]',
    confidence REAL DEFAULT 0.0,
    status TEXT DEFAULT 'INVESTIGATING',
    last_updated DATETIME,
    publishable BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS actions_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    domain TEXT NOT NULL DEFAULT 'system',
    module TEXT,
    action TEXT,
    target TEXT,
    result TEXT,
    cost_usd REAL DEFAULT 0.0,
    tokens_used INTEGER DEFAULT 0,
    model TEXT,
    error TEXT
);

CREATE TABLE IF NOT EXISTS ecosystem_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    domain TEXT NOT NULL DEFAULT 'system',
    event_type TEXT,
    source TEXT,
    details TEXT,
    commit_hash TEXT,
    narrative_angle TEXT
);

-- v0.3.4 (task #46 Phase B) — repo trust history for content-based
-- trust. Every cycle the source_quality_scorer engine walks a rotating
-- subset of workspace repos, runs core.source_quality.score_repo, and
-- writes one row per (repo_identity, scanned_at) into this table. The
-- rolling average over the last N rows is what compute_dynamic_trust
-- (v0.4.0 Phase C) will read to replace hardcoded trust floors.
--
-- Identity columns: repo_identity is the canonical owner/repo or
-- just the directory name. NO author fields, NO person-linkable
-- data — this table is strictly content-derived.
CREATE TABLE IF NOT EXISTS repo_trust_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    repo_identity TEXT NOT NULL,
    quality_score REAL NOT NULL,
    signals_json TEXT,
    files_scanned INTEGER DEFAULT 0,
    bytes_scanned INTEGER DEFAULT 0,
    scan_duration_seconds REAL DEFAULT 0.0,
    scanned_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_repo_trust_history_identity
    ON repo_trust_history(repo_identity);
CREATE INDEX IF NOT EXISTS idx_repo_trust_history_scanned_at
    ON repo_trust_history(scanned_at);

CREATE INDEX IF NOT EXISTS idx_evidence_domain ON evidence(domain);
CREATE INDEX IF NOT EXISTS idx_evidence_engine ON evidence(engine);
CREATE INDEX IF NOT EXISTS idx_evidence_confidence ON evidence(confidence);
CREATE INDEX IF NOT EXISTS idx_evidence_hypothesis ON evidence(supports_hypothesis);
CREATE INDEX IF NOT EXISTS idx_evidence_provenance ON evidence(provenance);
CREATE INDEX IF NOT EXISTS idx_actions_domain ON actions_log(domain);
CREATE INDEX IF NOT EXISTS idx_actions_module ON actions_log(module);
CREATE INDEX IF NOT EXISTS idx_hypotheses_domain ON hypotheses(domain);

CREATE TABLE IF NOT EXISTS aspirations (
    id TEXT PRIMARY KEY,
    domain TEXT NOT NULL,
    title TEXT,
    description TEXT,
    priority INTEGER DEFAULT 5,
    status TEXT DEFAULT 'ACTIVE',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS collisions (
    id TEXT PRIMARY KEY,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    collision_type TEXT NOT NULL,
    hypothesis_id TEXT,
    title TEXT,
    confidence REAL DEFAULT 0.0,
    domains_involved TEXT DEFAULT '[]',
    engines_involved TEXT DEFAULT '[]',
    engine_count INTEGER DEFAULT 0,
    convergent BOOLEAN DEFAULT FALSE,
    actions_taken TEXT DEFAULT '[]',
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at DATETIME,
    resolved_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_collisions_type
    ON collisions(collision_type);
CREATE INDEX IF NOT EXISTS idx_collisions_resolved
    ON collisions(resolved);
CREATE INDEX IF NOT EXISTS idx_collisions_hypothesis
    ON collisions(hypothesis_id);

CREATE TABLE IF NOT EXISTS cost_tracking (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    domain TEXT NOT NULL DEFAULT 'system',
    provider TEXT,
    model TEXT,
    module TEXT,
    tokens_input INTEGER DEFAULT 0,
    tokens_output INTEGER DEFAULT 0,
    cost_usd REAL DEFAULT 0.0,
    task_type TEXT,
    -- Alternative columns used by core/self_extension.py BudgetGuard:
    amount_usd REAL DEFAULT 0.0,
    description TEXT
);

CREATE INDEX IF NOT EXISTS idx_cost_tracking_domain ON cost_tracking(domain);
CREATE INDEX IF NOT EXISTS idx_cost_tracking_ts ON cost_tracking(timestamp);

CREATE TABLE IF NOT EXISTS spec_coverage (
    id TEXT PRIMARY KEY,
    spec_name TEXT NOT NULL,
    spec_path TEXT,
    overall_coverage REAL DEFAULT 0.0,
    go_zenon TEXT DEFAULT 'not_started',
    sdk_dart TEXT DEFAULT 'not_started',
    cli_dart TEXT DEFAULT 'not_started',
    cli_go TEXT DEFAULT 'not_started',
    syrius TEXT DEFAULT 'not_started',
    wiki TEXT DEFAULT 'not_started',
    zenonhub TEXT DEFAULT 'not_started',
    -- Per-layer status columns used by domains/development/engines:
    go_zenon_status TEXT DEFAULT 'not_started',
    sdk_dart_status TEXT DEFAULT 'not_started',
    cli_dart_status TEXT DEFAULT 'not_started',
    cli_go_status TEXT DEFAULT 'not_started',
    syrius_status TEXT DEFAULT 'not_started',
    docs_status TEXT DEFAULT 'not_started',
    infra_status TEXT DEFAULT 'not_started',
    last_checked DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS security_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    domain TEXT,
    contract TEXT,
    contract_name TEXT,
    engine TEXT,
    severity TEXT,
    category TEXT,
    title TEXT,
    finding TEXT,
    description TEXT,
    file_path TEXT,
    line_number INTEGER,
    confidence REAL DEFAULT 0.0,
    mitigated BOOLEAN DEFAULT 0,
    mitigation TEXT,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at DATETIME,
    resolved_by TEXT
);

CREATE TABLE IF NOT EXISTS intelligence_signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    domain TEXT,
    signal_type TEXT,
    source TEXT,
    details TEXT,
    routed_to_domain TEXT,
    processed BOOLEAN DEFAULT 0
);

CREATE TABLE IF NOT EXISTS bridge_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    metric_type TEXT,
    bridge_name TEXT DEFAULT 'orbital',
    tvl_znn REAL DEFAULT 0,
    tvl_eth REAL DEFAULT 0,
    tvl_usd REAL DEFAULT 0,
    relayer_count INTEGER DEFAULT 0,
    active_relayers INTEGER DEFAULT 0,
    total_relayers INTEGER DEFAULT 0,
    stuck_transactions INTEGER DEFAULT 0,
    pending_wraps INTEGER DEFAULT 0,
    pending_unwraps INTEGER DEFAULT 0,
    overall_health TEXT DEFAULT 'unknown',
    source TEXT DEFAULT 'zenon_rpc',
    value REAL,
    details TEXT
);

CREATE TABLE IF NOT EXISTS compliance_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    check_type TEXT,
    category TEXT,
    check_name TEXT,
    target TEXT,
    expected_standard TEXT,
    actual_standard TEXT,
    status TEXT,
    compliant BOOLEAN DEFAULT 1,
    actual_finding TEXT,
    details TEXT,
    notes TEXT,
    severity TEXT DEFAULT 'info'
);

CREATE TABLE IF NOT EXISTS liquidity_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    pair TEXT,
    pair_name TEXT,
    pool_address TEXT,
    liquidity_usd REAL,
    volume_24h REAL,
    volume_24h_usd REAL,
    price_usd REAL,
    price_change_24h REAL DEFAULT 0,
    slippage_10k REAL,
    slippage_1k_usd REAL DEFAULT 0,
    slippage_10k_usd REAL DEFAULT 0,
    slippage_100k_usd REAL DEFAULT 0,
    details TEXT
);

CREATE TABLE IF NOT EXISTS battle_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    situation_assessment TEXT,
    whats_working TEXT DEFAULT '[]',
    whats_failing TEXT DEFAULT '[]',
    battle_plan_24h TEXT DEFAULT '{}',
    resource_allocation TEXT DEFAULT '{}',
    domain_status TEXT DEFAULT '{}',
    raw_plan TEXT DEFAULT '{}',
    context_size_chars INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_battle_plans_ts
    ON battle_plans(timestamp);

CREATE TABLE IF NOT EXISTS treasury_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    znn_balance REAL DEFAULT 0,
    qsr_balance REAL DEFAULT 0,
    znn_usd REAL DEFAULT 0,
    qsr_usd REAL DEFAULT 0,
    total_usd REAL DEFAULT 0,
    znn_funded_30d REAL DEFAULT 0,
    qsr_funded_30d REAL DEFAULT 0,
    proposal_count INTEGER DEFAULT 0,
    active_proposals INTEGER DEFAULT 0,
    runway_months REAL DEFAULT 0,
    details TEXT
);

CREATE INDEX IF NOT EXISTS idx_treasury_ts ON treasury_snapshots(timestamp);

CREATE TABLE IF NOT EXISTS az_proposals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    proposal_id TEXT UNIQUE,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    title TEXT,
    name TEXT,
    description TEXT,
    owner TEXT,
    owner_address TEXT,
    status TEXT,
    znn_requested REAL DEFAULT 0,
    qsr_requested REAL DEFAULT 0,
    votes_yes INTEGER DEFAULT 0,
    votes_no INTEGER DEFAULT 0,
    votes_abstain INTEGER DEFAULT 0,
    yes_votes INTEGER DEFAULT 0,
    no_votes INTEGER DEFAULT 0,
    created_at TEXT,
    voting_ends_at TEXT,
    funded_at TEXT,
    delivered_at TEXT,
    executed_at TEXT,
    last_updated TEXT
);

CREATE INDEX IF NOT EXISTS idx_proposals_status ON az_proposals(status);
CREATE INDEX IF NOT EXISTS idx_proposals_owner ON az_proposals(owner);

CREATE TABLE IF NOT EXISTS supply_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    znn_total_supply REAL DEFAULT 0,
    znn_circulating REAL DEFAULT 0,
    znn_emission_daily REAL DEFAULT 0,
    znn_burn_daily REAL DEFAULT 0,
    qsr_total_supply REAL DEFAULT 0,
    qsr_circulating REAL DEFAULT 0,
    qsr_emission_daily REAL DEFAULT 0,
    qsr_burn_daily REAL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_supply_ts ON supply_snapshots(timestamp);

CREATE TABLE IF NOT EXISTS staking_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_staked_znn REAL DEFAULT 0,
    total_delegated_znn REAL DEFAULT 0,
    staking_ratio REAL DEFAULT 0,
    unique_stakers INTEGER DEFAULT 0,
    unique_delegators INTEGER DEFAULT 0,
    delegation_hhi REAL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_staking_ts ON staking_metrics(timestamp);

CREATE TABLE IF NOT EXISTS node_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_nodes INTEGER DEFAULT 0,
    pillar_count INTEGER DEFAULT 0,
    sentinel_count INTEGER DEFAULT 0,
    version_distribution TEXT DEFAULT '{}',
    latest_version TEXT,
    latest_version_pct REAL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_node_ts ON node_snapshots(timestamp);

CREATE TABLE IF NOT EXISTS pillar_monitor_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    batch_id INTEGER,
    pillar_name TEXT,
    weight REAL DEFAULT 0,
    produced_momentums INTEGER DEFAULT 0,
    expected_momentums INTEGER DEFAULT 0,
    uptime_pct REAL DEFAULT 0,
    rank INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_pillar_mon_batch ON pillar_monitor_snapshots(batch_id);

CREATE TABLE IF NOT EXISTS pillar_votes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    proposal_id TEXT,
    pillar_name TEXT,
    vote TEXT,
    UNIQUE(proposal_id, pillar_name)
);

CREATE TABLE IF NOT EXISTS pillar_accountability_scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    batch_id INTEGER,
    pillar_name TEXT,
    total_score REAL DEFAULT 0,
    voting_score REAL DEFAULT 0,
    sponsorship_score REAL DEFAULT 0,
    uptime_score REAL DEFAULT 0,
    reward_score REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS whale_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    top_5_share_pct REAL DEFAULT 0,
    top_10_share_pct REAL DEFAULT 0,
    whale_count INTEGER DEFAULT 0,
    total_held_znn REAL DEFAULT 0,
    large_tx_count INTEGER DEFAULT 0,
    delegation_changes_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS whale_delegation_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_id INTEGER,
    pillar_name TEXT,
    weight REAL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS yield_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    avg_delegation_apr REAL DEFAULT 0,
    max_delegation_apr REAL DEFAULT 0,
    min_delegation_apr REAL DEFAULT 0,
    staking_apr_qsr REAL DEFAULT 0,
    pillar_apr REAL DEFAULT 0,
    pillar_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS ecosystem_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    metric_name TEXT,
    metric_value REAL DEFAULT 0,
    source TEXT
);

CREATE INDEX IF NOT EXISTS idx_ecosystem_metric ON ecosystem_metrics(metric_name);

CREATE TABLE IF NOT EXISTS derived_mission (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    pillars_json TEXT NOT NULL,
    source_commit TEXT,
    source_repo TEXT,
    derived_at TEXT NOT NULL,
    llm_model TEXT,
    llm_cost_usd REAL DEFAULT 0.0,
    raw_synthesis TEXT
);

CREATE INDEX IF NOT EXISTS idx_derived_mission_derived_at
    ON derived_mission(derived_at);
"""


def connect(db_path: str) -> sqlite3.Connection:
    """Open a SQLite connection with WAL mode and concurrency tuning.

    **Use this instead of bare ``sqlite3.connect``.** Bare connect misses
    every pragma below — most importantly the ``busy_timeout``, which is
    0 by default and causes random ``database is locked`` errors the
    moment two writers contend.

    All callers (core, domains, scripts) should route through this.
    The architecture audit (R8) flags any new file that imports
    ``sqlite3`` and calls ``.connect`` directly.

    Pragmas applied:

    - ``journal_mode=WAL`` — concurrent readers + one writer
    - ``cache_size=-64000`` — 64 MB page cache
    - ``synchronous=NORMAL`` — durable but faster than FULL
    - ``busy_timeout=5000`` — 5s wait under writer contention

    Args:
        db_path: Filesystem path to the SQLite database.

    Returns:
        A configured ``sqlite3.Connection``. Caller is responsible for
        closing it (use ``with closing(conn): ...`` or a try/finally).
    """
    conn = sqlite3.connect(db_path, timeout=30.0)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA cache_size=-64000")  # 64MB cache
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA busy_timeout=5000")  # 5s wait under contention
    return conn


# Backward-compat alias. The underscore-prefixed name is deprecated but
# still imported by a handful of files; new code should use ``connect``.
_get_connection = connect


# Cache of DB paths whose schema has already been ensured this process.
# Prevents the 20x overhead of re-running the schema registry on every
# persist_finding call.
_SCHEMA_APPLIED: set[str] = set()


def ensure_schema(db_path: str = DEFAULT_DB, *, force: bool = False) -> None:
    """Create all required tables if they do not exist.

    Also migrates existing databases by adding columns that were
    introduced after initial schema creation (e.g. provenance).

    The full schema is applied at most once per (process, db_path).
    Pass ``force=True`` to re-run (useful for tests that replace the
    DB file).
    """
    if not force and db_path in _SCHEMA_APPLIED:
        return
    conn = _get_connection(db_path)
    try:
        # Check if evidence table already exists (pre-migration DB)
        table_exists = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='evidence'"
        ).fetchone()

        if table_exists:
            # Migration: add provenance column if missing BEFORE running full schema
            columns = {row[1] for row in conn.execute("PRAGMA table_info(evidence)").fetchall()}
            if "provenance" not in columns:
                conn.execute("ALTER TABLE evidence ADD COLUMN provenance TEXT DEFAULT 'hypothesis'")
                conn.commit()
                logger.info("Migrated evidence table: added provenance column")

            # Migration: add source tracking columns for reproducibility
            for col_name, col_type in [
                ("source_repo", "TEXT"),
                ("source_file", "TEXT"),
                ("source_commit", "TEXT"),
                ("source_line", "INTEGER"),
                ("reproducible_command", "TEXT"),
                # v0.3.3 attribution + content-addressing foundation.
                # See SCHEMA_SQL for full rationale.
                ("discoverer_peer_id", "TEXT"),
                ("content_hash", "TEXT"),
                ("signature", "TEXT"),
                # Alternative-shape columns used by certain domain engines
                # that INSERT directly into evidence with richer fields:
                ("finding_type", "TEXT"),
                ("title", "TEXT"),
                ("body", "TEXT"),
                ("source", "TEXT"),
            ]:
                if col_name not in columns:
                    try:
                        conn.execute(f"ALTER TABLE evidence ADD COLUMN {col_name} {col_type}")
                        conn.commit()
                        logger.info("Migrated evidence table: added %s column", col_name)
                    except sqlite3.OperationalError as exc:
                        # Column already exists -- expected during idempotent migration
                        logger.debug("evidence ADD COLUMN %s skipped: %s", col_name, exc)

        # Migration: add routed_to_domain to intelligence_signals
        try:
            sig_cols = {
                r[1] for r in conn.execute("PRAGMA table_info(intelligence_signals)").fetchall()
            }
            if sig_cols and "routed_to_domain" not in sig_cols:
                conn.execute("ALTER TABLE intelligence_signals ADD COLUMN routed_to_domain TEXT")
                conn.commit()
        except Exception as exc:
            logger.debug("Signal table migration skipped: %s", exc)

        # Migration: add BudgetGuard shape columns to cost_tracking
        try:
            ct_cols = {r[1] for r in conn.execute("PRAGMA table_info(cost_tracking)").fetchall()}
            if ct_cols:
                for col_name, col_type in [
                    ("amount_usd", "REAL DEFAULT 0.0"),
                    ("description", "TEXT"),
                ]:
                    if col_name not in ct_cols:
                        try:
                            conn.execute(
                                f"ALTER TABLE cost_tracking ADD COLUMN {col_name} {col_type}"
                            )
                            conn.commit()
                        except sqlite3.OperationalError as exc:
                            logger.debug("cost_tracking ADD COLUMN %s skipped: %s", col_name, exc)
        except Exception as exc:
            logger.debug("cost_tracking migration skipped: %s", exc)

        # Migration: add per-layer status + spec_path columns to spec_coverage
        try:
            sc_cols = {r[1] for r in conn.execute("PRAGMA table_info(spec_coverage)").fetchall()}
            if sc_cols:
                for col_name, col_type in [
                    ("spec_path", "TEXT"),
                    ("go_zenon_status", "TEXT DEFAULT 'not_started'"),
                    ("sdk_dart_status", "TEXT DEFAULT 'not_started'"),
                    ("cli_dart_status", "TEXT DEFAULT 'not_started'"),
                    ("cli_go_status", "TEXT DEFAULT 'not_started'"),
                    ("syrius_status", "TEXT DEFAULT 'not_started'"),
                    ("docs_status", "TEXT DEFAULT 'not_started'"),
                    ("infra_status", "TEXT DEFAULT 'not_started'"),
                    ("last_checked", "DATETIME"),
                ]:
                    if col_name not in sc_cols:
                        try:
                            conn.execute(
                                f"ALTER TABLE spec_coverage ADD COLUMN {col_name} {col_type}"
                            )
                            conn.commit()
                        except sqlite3.OperationalError as exc:
                            logger.debug("spec_coverage ADD COLUMN %s skipped: %s", col_name, exc)
        except Exception as exc:
            logger.debug("spec_coverage migration skipped: %s", exc)

        # Migration: add extended columns to community_activity
        try:
            ca_cols = {
                r[1] for r in conn.execute("PRAGMA table_info(community_activity)").fetchall()
            }
            if ca_cols:
                for col_name, col_type in [
                    ("source_type", "TEXT"),
                    ("title", "TEXT"),
                    ("body", "TEXT"),
                    ("url", "TEXT"),
                    ("labels", "TEXT"),
                    ("state", "TEXT"),
                    ("created_at", "TEXT"),
                    ("updated_at", "TEXT"),
                    ("sentiment", "TEXT"),
                    ("relevance_score", "REAL DEFAULT 0.0"),
                    ("processed", "BOOLEAN DEFAULT 0"),
                ]:
                    if col_name not in ca_cols:
                        try:
                            conn.execute(
                                f"ALTER TABLE community_activity ADD COLUMN {col_name} {col_type}"
                            )
                            conn.commit()
                        except sqlite3.OperationalError as exc:
                            logger.debug(
                                "community_activity ADD COLUMN %s skipped: %s",
                                col_name,
                                exc,
                            )
        except Exception as exc:
            logger.debug("community_activity migration skipped: %s", exc)

        # Now run full schema (CREATE TABLE IF NOT EXISTS + indexes)
        conn.executescript(SCHEMA_SQL)
        conn.commit()

        logger.debug("Schema ensured for %s", db_path)
    finally:
        conn.close()

    # Apply every additional schema declared by engines / domain plugins.
    # Imported lazily so persist_to_db stays importable during bootstrap.
    try:
        from core.schema_registry import apply_all_schemas

        apply_all_schemas(db_path)
    except Exception as exc:  # defensive - never let an engine break boot
        logger.debug("Schema registry apply skipped: %s", exc)

    _SCHEMA_APPLIED.add(db_path)


def maintain_db(db_path: str = DEFAULT_DB, retention_days: int = 30) -> dict:
    """Periodic database maintenance — prune stale data, vacuum, check integrity.

    Runs automatically every 24 hours from the autonomous runner.
    Keeps the DB lean and performant.

    Args:
        db_path: SQLite database path.
        retention_days: How many days of data to keep for high-volume tables.

    Returns:
        Dict with counts of rows pruned per table.
    """
    conn = sqlite3.connect(db_path)
    pruned: dict = {}
    cutoff = f"datetime('now', '-{retention_days} days')"

    try:
        # Prune old action logs (keep last N days)
        cursor = conn.execute(f"DELETE FROM actions_log WHERE timestamp < {cutoff}")
        pruned["actions_log"] = cursor.rowcount

        # Prune old battle plans (keep last 50)
        cursor = conn.execute(
            "DELETE FROM battle_plans WHERE id NOT IN "
            "(SELECT id FROM battle_plans ORDER BY timestamp DESC LIMIT 50)"
        )
        pruned["battle_plans"] = cursor.rowcount

        # Acknowledge old feedback bus messages (>7 days)
        cursor = conn.execute(
            "UPDATE feedback_bus SET acknowledged = 1 "
            "WHERE acknowledged = 0 AND timestamp < datetime('now', '-7 days')"
        )
        pruned["feedback_bus_acked"] = cursor.rowcount

        # Prune old compliance checks (keep last 100)
        cursor = conn.execute(
            "DELETE FROM compliance_checks WHERE id NOT IN "
            "(SELECT id FROM compliance_checks ORDER BY timestamp DESC LIMIT 100)"
        )
        pruned["compliance_checks"] = cursor.rowcount

        # Prune old intelligence signals (keep last 500)
        cursor = conn.execute(
            "DELETE FROM intelligence_signals WHERE id NOT IN "
            "(SELECT id FROM intelligence_signals ORDER BY timestamp DESC LIMIT 500)"
        )
        pruned["intelligence_signals"] = cursor.rowcount

        # Prune old cost tracking (keep last 1000 entries)
        cursor = conn.execute(
            "DELETE FROM cost_tracking WHERE id NOT IN "
            "(SELECT id FROM cost_tracking ORDER BY timestamp DESC LIMIT 1000)"
        )
        pruned["cost_tracking"] = cursor.rowcount

        # Archive resolved evidence older than retention period
        # (keeps evidence table lean; resolved findings are historical)
        cursor = conn.execute(
            f"DELETE FROM evidence WHERE status = 'resolved' AND resolved_at < {cutoff}"
        )
        pruned["evidence_archived"] = cursor.rowcount

        # Prune old metric snapshots (staking, supply, liquidity, etc.)
        for table in [
            "staking_metrics",
            "supply_snapshots",
            "liquidity_metrics",
            "bridge_metrics",
            "node_snapshots",
            "treasury_snapshots",
        ]:
            try:
                cursor = conn.execute(
                    f"DELETE FROM {table} WHERE id NOT IN "
                    f"(SELECT id FROM {table} ORDER BY timestamp DESC LIMIT 500)"
                )
                if cursor.rowcount > 0:
                    pruned[table] = cursor.rowcount
            except sqlite3.OperationalError as exc:
                # Table may not exist -- expected when optional engines are disabled
                logger.debug("prune %s skipped: %s", table, exc)

        conn.commit()

        # DB size check
        db_size = conn.execute(
            "SELECT page_count * page_size FROM pragma_page_count(), pragma_page_size()"
        ).fetchone()
        pruned["db_size_mb"] = round(db_size[0] / (1024 * 1024), 2) if db_size else 0

        # Vacuum to reclaim space (only if we pruned significant data)
        total_pruned = sum(v for v in pruned.values() if isinstance(v, int))
        if total_pruned > 100:
            conn.execute("VACUUM")

        # Integrity check
        result = conn.execute("PRAGMA integrity_check").fetchone()
        pruned["integrity"] = result[0] if result else "unknown"

    except Exception as exc:
        logger.warning("DB maintenance failed: %s", exc)
        pruned["error"] = str(exc)
    finally:
        conn.close()

    total = sum(v for v in pruned.values() if isinstance(v, int))
    if total > 0:
        logger.info("DB maintenance: pruned %d rows (%s)", total, pruned)
    return pruned
