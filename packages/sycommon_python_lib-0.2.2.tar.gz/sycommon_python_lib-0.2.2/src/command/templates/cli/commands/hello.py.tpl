"""hello 子命令"""


def handle_hello(args) -> None:
    """处理 hello 命令"""
    print(f"Hello, {args.name}!")
