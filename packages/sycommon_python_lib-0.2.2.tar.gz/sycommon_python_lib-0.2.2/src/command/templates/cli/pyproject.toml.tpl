[project]
name = "{{ project_name }}"
version = "0.1.0"
description = "{{ project_name }} - CLI 命令行工具"
readme = "README.md"
requires-python = ">=3.11"
dependencies = []

[project.scripts]
{{ short_project_name }} = "app:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
