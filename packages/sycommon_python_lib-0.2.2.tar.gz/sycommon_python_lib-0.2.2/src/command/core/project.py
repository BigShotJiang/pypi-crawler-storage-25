"""
项目初始化逻辑
"""
import os
import re
import datetime
from pathlib import Path
from importlib.resources import files
from typing import Optional

from jinja2 import Environment, BaseLoader, TemplateSyntaxError

from .models import FeatureOptions
from .console import (
    print_info, print_success, print_error, print_warning, Colors
)
from .utils import get_all_files_in_directory


def _get_current_user() -> str:
    """获取当前用户名，兼容容器/CI 等无 tty 环境。"""
    try:
        return os.getlogin()
    except OSError:
        # 容器、CI、非交互式 shell 等环境下 os.getlogin() 会失败
        import getpass
        return getpass.getuser() or "unknown"


def interactive_feature_selection(project_type: str = "web") -> FeatureOptions:
    """交互式功能选择

    提示默认值从 FeatureOptions 数据类获取，保证 --quiet 模式和
    交互模式使用完全一致的默认值。
    """
    # 根据项目类型获取推荐默认值
    defaults = FeatureOptions.defaults_for(project_type)

    print(f"\n{Colors.HEADER}🔧 功能模块配置{Colors.ENDC}")
    print("-" * 40)

    def ask_yes_no(question: str, default: bool = False) -> bool:
        default_str = "Y/n (默认y)" if default else "y/N (默认n)"
        while True:
            response = input(f"  {question} [{default_str}]: ").strip().lower()
            if not response:
                return default
            if response in ('y', 'yes', '是'):
                return True
            if response in ('n', 'no', '否'):
                return False
            print_warning("请输入 y/n")

    return FeatureOptions(
        database=ask_yes_no("启用数据库 (MySQL)?", default=defaults.database),
        rabbitmq=ask_yes_no("启用 RabbitMQ 消息队列?", default=defaults.rabbitmq),
        nacos=ask_yes_no("启用 Nacos 服务注册?", default=defaults.nacos),
        kafka_log=ask_yes_no("启用 Kafka 日志?", default=defaults.kafka_log),
        sse=ask_yes_no("启用 SSE 流式响应?", default=defaults.sse),
        llm=ask_yes_no("启用 LLM 大模型支持?", default=defaults.llm),
        redis=ask_yes_no("启用 Redis 缓存?", default=defaults.redis),
        elasticsearch=ask_yes_no("启用 Elasticsearch?", default=defaults.elasticsearch),
        sentry=ask_yes_no("启用 Sentry 错误监控?", default=defaults.sentry),
    )


def init_project(
    project_name: str,
    project_type: str,
    features: Optional[FeatureOptions] = None,
    dry_run: bool = False,
    force: bool = False,
    verbose: bool = True,
    port: int = 8080
) -> bool:
    """
    初始化项目，自动读取模板文件并替换占位符

    Args:
        project_name: 项目名称
        project_type: 项目类型 (web/agent)
        features: 功能选项，为 None 时使用交互式选择
        dry_run: 仅预览，不实际创建文件
        force: 强制覆盖已存在的目录
        verbose: 显示详细输出
        port: 服务端口

    Returns:
        是否成功
    """
    project_path = Path(os.getcwd()) / project_name

    # 检查目录是否存在
    if project_path.exists():
        if not force:
            print_error(f"工程 '{project_path}' 已存在")
            print_info("使用 --force 参数强制覆盖", verbose)
            return False
        elif dry_run:
            print_warning(f"[DRY-RUN] 将覆盖已存在的目录: {project_path}")
        else:
            print_warning(f"将覆盖已存在的目录: {project_path}")

    # 交互式功能选择
    if features is None:
        try:
            features = interactive_feature_selection(project_type)
        except KeyboardInterrupt:
            print("\n")
            print_info("操作已取消")
            return False

    # 模板目录检查
    template_root = files("command.templates")
    if not template_root.is_dir():
        print_error("未找到模板文件目录（command/templates）")
        return False

    # 处理项目名称
    short_project_name = project_name.replace("shengye-platform-", "")
    short_project_name_upper = short_project_name.upper()
    # 生成合法的 Python 标识符（用于类名、变量名）
    # "goodsprice-parse" -> "GoodspriceParse", "GOODSPRICE_PARSE"
    safe_identifier = re.sub(r'[^a-zA-Z0-9]', '_', short_project_name)
    safe_class_name = "".join(part.capitalize() for part in safe_identifier.split("_") if part)
    safe_upper_name = safe_identifier.upper()


    # 定义模板变量
    context = {
        "project_name": project_name,
        "short_project_name": short_project_name,
        "short_project_name_upper": short_project_name_upper,
        "safe_class_name": safe_class_name,
        "safe_upper_name": safe_upper_name,
        "safe_identifier": safe_identifier,
        "project_type": project_type,
        "create_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "author": _get_current_user(),
        "default_port": port,
    }
    context.update(features.to_template_vars())

    # 文件过滤：跳过不需要的模块
    feature_map = {
        'feature_rabbitmq': [
            'tools/mq.py', 'tools/mq.py.tpl',
        ],
        'feature_sse': [
            'api/sse/', 'sse/',
        ],
        'feature_database': [
            'db/', 'db/service.py', 'db/model/', 'db/model/entity.py',
        ],
    }
    # CLI 项目不需要的服务端文件
    cli_skip_files = {'app.yaml', 'app.yaml.tpl', 'requirements.txt', 'requirements.txt.tpl', 'Dockerfile', 'Dockerfile.tpl'}
    disabled_features = {
        key for key, flag_val in features.to_template_vars().items()
        if flag_val == 'false' and key in feature_map
    }

    def _should_skip(rel_path: str) -> bool:
        """检查文件是否因功能关闭或项目类型而应跳过"""
        # CLI 项目跳过不需要的服务端文件
        if project_type == "cli":
            if rel_path in cli_skip_files or rel_path.replace('.tpl', '') in cli_skip_files:
                return True
        for feat_key in disabled_features:
            for pattern in feature_map[feat_key]:
                if pattern in rel_path:
                    return True
        return False

    # 获取模板文件
    base_dir = template_root / "base"
    type_dir = template_root / project_type

    base_files = get_all_files_in_directory(base_dir)
    type_specific_files = get_all_files_in_directory(type_dir)

    # 过滤掉不需要的文件
    file_mappings = []
    for abs_path, rel_path in base_files + type_specific_files:
        if not _should_skip(rel_path):
            file_mappings.append((abs_path, rel_path))

    # Dry run 模式
    if dry_run:
        return _dry_run(file_mappings, features, verbose)

    # 创建目录
    if not project_path.exists():
        project_path.mkdir(parents=True)

    # 渲染并写入文件
    copied_files = _render_files(file_mappings, context, project_path, verbose)

    if copied_files > 0:
        _print_success_message(project_path, project_name, copied_files, project_type)
        return True
    else:
        print_warning("未创建任何文件，可能是缺少模板文件或模板路径配置错误")
        return False


def _dry_run(
    file_mappings: list,
    features: FeatureOptions,
    verbose: bool
) -> bool:
    """预览模式"""
    print_info(f"\n📋 预览将要创建的文件 (共 {len(file_mappings)} 个):", verbose)
    print("-" * 40)
    for _, target_rel_path in file_mappings:
        if target_rel_path.endswith('.tpl'):
            target_rel_path = target_rel_path[:-4]
        print(f"  📄 {target_rel_path}")
    print("-" * 40)
    print_info("功能配置:", verbose)
    print(f"    数据库 (MySQL): {'✓' if features.database else '✗'}")
    print(f"    RabbitMQ: {'✓' if features.rabbitmq else '✗'}")
    print(f"    Nacos: {'✓' if features.nacos else '✗'}")
    print(f"    Kafka日志: {'✓' if features.kafka_log else '✗'}")
    print(f"    SSE流式: {'✓' if features.sse else '✗'}")
    print(f"    LLM支持: {'✓' if features.llm else '✗'}")
    print(f"    Redis缓存: {'✓' if features.redis else '✗'}")
    print(f"    Elasticsearch: {'✓' if features.elasticsearch else '✗'}")
    print(f"    Sentry监控: {'✓' if features.sentry else '✗'}")
    return True


def _render_files(
    file_mappings: list,
    context: dict,
    project_path: Path,
    verbose: bool
) -> int:
    """渲染并写入文件"""
    jinja_env = Environment(
        loader=BaseLoader(),
        trim_blocks=True,
        lstrip_blocks=True,
    )

    copied_files = 0

    for template_file, target_rel_path in file_mappings:
        try:
            # 读取模板内容
            template_content = template_file.read_text(encoding="utf-8")

            # 使用 Jinja2 渲染
            try:
                jinja_template = jinja_env.from_string(template_content)
                rendered_content = jinja_template.render(context)
            except TemplateSyntaxError:
                # 回退到简单替换
                rendered_content = template_content
                for key, value in context.items():
                    pattern = re.compile(rf'{{\s*{re.escape(key)}\s*}}')
                    rendered_content = pattern.sub(str(value), rendered_content)

            # 清理引号（仅对 .py 文件，避免破坏 YAML/JSON/Dockerfile 等格式）
            if target_rel_path.endswith('.py') or target_rel_path.endswith('.py.tpl'):
                rendered_content = re.sub(
                    r'(\w+)\s*:\s*["\']([^"\']+)["\']',
                    r'\1: \2',
                    rendered_content
                )

            # 处理文件后缀
            if target_rel_path.endswith('.tpl'):
                target_rel_path = target_rel_path[:-4]

            # 写入文件
            target_file = project_path / target_rel_path
            target_file.parent.mkdir(parents=True, exist_ok=True)
            target_file.write_text(rendered_content, encoding="utf-8")

            print_info(f"创建: {target_rel_path}", verbose)
            copied_files += 1

        except Exception as e:
            print_error(f"处理模板 {template_file} 失败: {str(e)}")

    return copied_files


def _print_success_message(
    project_path: Path,
    project_name: str,
    copied_files: int,
    project_type: str = "web",
) -> None:
    """打印成功信息"""
    print_success(f"模板工程 {project_name} 创建完成！")
    print(f"📁 工程路径：{project_path}")
    print(f"📊 共创建 {copied_files} 个文件")
    print()
    print_info("下一步操作:")
    print(f"  cd {project_name}")
    if project_type == "cli":
        print(f"  uv sync")
        print(f"  uv run python app.py")
    else:
        print(f"  # 建议先创建虚拟环境")
        print(f"  python -m venv .venv && source .venv/bin/activate")
        print(f"  pip install -r requirements.txt")
        print(f"  python app.py")
