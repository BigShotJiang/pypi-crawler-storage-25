"""
沙箱服务

提供沙箱容器的中间件和 API 路由
支持 user_id 隔离，每个用户独立工作目录

目录结构:
    Linux (固定路径，重启后数据保留):
        /data/sycommon_sandbox/{user_id}/

    macOS/Windows (临时目录):
        {tempdir}/sycommon_sandbox/{user_id}/

    可通过环境变量 SANDBOX_WORKSPACE 覆盖默认路径

路径隔离:
    所有 API 端点使用统一路径解析 (resolve_sandbox_path):
    - /skills/foo.md -> {workspace}/skills/foo.md
    - skills/foo.md -> {workspace}/skills/foo.md
    - 防止路径遍历攻击 (../../../etc/passwd)
"""

import os
import signal
import asyncio
import base64
import json
import shutil
import tempfile
import platform
import uuid
import shlex
import threading
from datetime import datetime
from fastapi import FastAPI, APIRouter, Request, Header
from fastapi.responses import StreamingResponse
from typing import Dict

from sycommon.logging.kafka_log import SYLogger
from sycommon.models.sandbox import (
    ExecuteRequest, ExecuteResponse,
    UploadRequest, UploadResponse,
    DownloadRequest, DownloadResponse,
    DeleteRequest, DeleteResponse,
    FileInfo, LsRequest, LsResponse,
    TreeNode, TreeRequest, TreeResponse,
    GlobRequest, GrepRequest, GrepMatch,
    ReadRequest, ReadResponse,
    WriteRequest, WriteResponse,
    EditRequest, EditResponse,
    HealthResponse, ResetRequest, ResetResponse,
    ExecuteBackgroundRequest, ExecuteBackgroundResponse,
    ProcessStatusRequest, ProcessStatusResponse,
    KillProcessRequest, KillProcessResponse,
    KillAllProcessesRequest, KillAllProcessesResponse,
    StatRequest, StatResponse,
    BatchUploadRequest, BatchUploadResponse, BatchUploadResult,
    ExecuteStreamRequest,
    PortForwardRequest, PortForwardResponse,
    WatchRequest, WatchEvent, WatchResponse,
)


# ============== 后台进程管理 ==============

# 当前 worker 的唯一标识，用于多 worker 部署下定位进程所在 worker
_WORKER_ID = f"{os.getpid()}-{uuid.uuid4().hex[:8]}"

# 进程存储: process_id -> {process: Popen, command: str, user_id: str, started_at: datetime, workspace: str}
# 注意：多 worker 部署时，每个 worker 有独立的进程表。
# 调用方需确保 execute_background / process_status / kill_process 请求路由到同一 worker。
_background_processes: Dict[str, dict] = {}
# 后台监控任务引用，用于在 shutdown 时取消
_monitor_tasks: list = []
# 延迟初始化的 asyncio.Lock，避免模块导入时无事件循环的问题
_process_lock: asyncio.Lock = None
# 线程锁，保护 _background_processes 的读写
_processes_thread_lock = threading.Lock()


def _get_process_lock() -> asyncio.Lock:
    """延迟创建 asyncio.Lock，确保在事件循环运行后调用"""
    global _process_lock
    if _process_lock is None:
        _process_lock = asyncio.Lock()
    return _process_lock


# 进程清理配置
PROCESS_CLEANUP_TTL = 300  # 已完成进程保留时间（秒）
PROCESS_CLEANUP_INTERVAL = 60  # 清理检查间隔（秒）


async def _cleanup_finished_processes():
    """异步清理已完成的过期进程"""
    lock = _get_process_lock()
    while True:
        await asyncio.sleep(PROCESS_CLEANUP_INTERVAL)
        now = datetime.now().timestamp()
        async with lock:
            expired = [
                k for k, v in _background_processes.items()
                if v.get("completed") and now - v.get("completed_at", 0) > PROCESS_CLEANUP_TTL
            ]
            for k in expired:
                _background_processes.pop(k, None)
                SYLogger.debug(f"[Sandbox Server] 清理过期进程: {k}")


# ============== 常量配置 ==============

MAX_OUTPUT_BYTES = 100_000
# 默认工作目录配置
# - Linux: /data/sycommon_sandbox (固定路径，自动创建)
# - macOS/Windows: 使用系统临时目录
# 可通过环境变量 SANDBOX_WORKSPACE 覆盖
if platform.system() == "Linux":
    _default_workspace = "/data/sycommon_sandbox"
    # 自动创建目录（如果不存在）
    try:
        os.makedirs(_default_workspace, exist_ok=True)
    except PermissionError:
        # 降级到临时目录
        _default_workspace = os.path.join(
            tempfile.gettempdir(), "sycommon_sandbox")
else:
    # macOS / Windows 使用临时目录
    _default_workspace = os.path.join(
        tempfile.gettempdir(), "sycommon_sandbox")
WORKSPACE_BASE = os.environ.get("SANDBOX_WORKSPACE", _default_workspace)


# ============== 辅助函数 ==============

def _build_init_script(workspace: str) -> str:
    """构建 shell 初始化脚本（沙箱环境初始化 + 路径映射 + 资源限制）"""
    safe_workspace = shlex.quote(workspace)
    return f'''
# 沙箱环境初始化
export SANDBOX_ROOT={safe_workspace}
export _SANDBOX_WORKSPACE={safe_workspace}

# 资源限制（防止失控进程）
ulimit -f 1048576 2>/dev/null     # 单文件最大 1GB
ulimit -c 0 2>/dev/null           # 禁止 core dump

# 路径映射函数：将绝对路径映射到沙箱内（如果尚未在沙箱内）
sandbox_path() {{
    local path="$1"
    # 如果路径已经在 workspace 内，直接返回
    if [[ "$path" == "$_SANDBOX_WORKSPACE"* ]]; then
        echo "$path"
        return
    fi
    # 如果是绝对路径，映射到沙箱内
    if [[ "$path" == /* ]]; then
        # 移除开头的 /
        path="${{path#/}}"
        echo "$_SANDBOX_WORKSPACE/$path"
    else
        # 相对路径，基于当前目录
        echo "$path"
    fi
}}

# 重写 cd 命令，支持沙箱路径
cd() {{
    local target="$1"
    if [[ -z "$target" ]]; then
        command cd "$_SANDBOX_WORKSPACE"
    elif [[ "$target" == "$_SANDBOX_WORKSPACE"* ]]; then
        # 路径已经在 workspace 内，直接 cd
        command cd "$target"
    elif [[ "$target" == /* ]]; then
        # 其他绝对路径映射到沙箱内
        local mapped="$_SANDBOX_WORKSPACE/${{target#/}}"
        command cd "$mapped"
    else
        command cd "$target"
    fi
}}

# 重写 mkdir，自动创建沙箱内的绝对路径目录
mkdir() {{
    local args=("$@")
    local new_args=()
    for arg in "${{args[@]}}"; do
        if [[ "$arg" == "$_SANDBOX_WORKSPACE"* ]]; then
            # 路径已经在 workspace 内，直接使用
            new_args+=("$arg")
        elif [[ "$arg" == /* ]]; then
            new_args+=("$_SANDBOX_WORKSPACE/${{arg#/}}")
        else
            new_args+=("$arg")
        fi
    done
    command mkdir "${{new_args[@]}}"
}}

# 切换到 workspace 目录
cd "$_SANDBOX_WORKSPACE"
'''

def get_user_workspace(user_id: str) -> str:
    """获取用户工作目录"""
    workspace = os.path.join(WORKSPACE_BASE, user_id)
    if not os.path.exists(workspace):
        os.makedirs(workspace, exist_ok=True)
    return workspace


async def aget_user_workspace(user_id: str) -> str:
    """获取用户工作目录（异步版本，避免阻塞事件循环）"""
    workspace = os.path.join(WORKSPACE_BASE, user_id)

    def _ensure():
        if not os.path.exists(workspace):
            os.makedirs(workspace, exist_ok=True)

    await asyncio.to_thread(_ensure)
    return workspace


async def aensure_subdirs(workspace: str, subdirs: list[str] = None):
    """异步确保子目录存在"""
    subdirs = subdirs or ["tmp", "output", "skills", "memory", "data"]

    def _makedirs():
        for subdir in subdirs:
            os.makedirs(os.path.join(workspace, subdir), exist_ok=True)

    await asyncio.to_thread(_makedirs)


def resolve_sandbox_path(path: str, workspace: str) -> str:
    """
    将沙箱路径解析到用户工作目录，实现路径隔离

    所有路径（包括绝对路径）都会映射到用户工作目录下：
    - /skills/foo.md -> {workspace}/skills/foo.md
    - skills/foo.md -> {workspace}/skills/foo.md

    如果传入的绝对路径已经在工作目录内，则直接返回。

    同时防止路径遍历攻击，确保解析后的路径仍在工作目录内
    """
    # 规范化路径
    path = os.path.normpath(path)
    workspace = os.path.normpath(workspace)

    # 如果路径已经在工作目录内，直接返回
    if path.startswith(workspace + os.sep) or path == workspace:
        return path

    # 移除开头的 / 使其成为相对路径
    if os.path.isabs(path):
        path = path.lstrip(os.sep)

    # 拼接到工作目录
    resolved = os.path.normpath(os.path.join(workspace, path))

    # 安全检查：确保最终路径在工作目录内
    if not resolved.startswith(workspace + os.sep) and resolved != workspace:
        raise ValueError(f"Path traversal detected: {path}")

    return resolved


def setup_sandbox_handler(app: FastAPI, config: dict = None):
    """
    沙箱服务初始化

    Args:
        app: FastAPI 应用实例
        config: 配置字典，检查 SandboxService 是否启用

    功能：
    1. 首次请求时初始化工作目录
    2. 挂载沙箱 API 路由（支持 user_id 隔离）
    """
    global WORKSPACE_BASE
    config = config or {}

    # 检查是否启用沙箱服务
    if not config.get('SandboxService'):
        return app

    # 从配置中读取工作目录
    sandbox_config = config.get('SandboxService', {})
    if isinstance(sandbox_config, dict):
        workspace = sandbox_config.get('workspace')
        if workspace:
            WORKSPACE_BASE = workspace

    initialized = False

    # 沙箱后台清理任务已迁入 Services.combined_lifespan 统一管理，
    # 此处不再通过 on_event("startup") 注册

    @app.middleware("http")
    async def sandbox_middleware(request: Request, call_next):
        nonlocal initialized
        if not initialized:
            def _init():
                if not os.path.exists(WORKSPACE_BASE):
                    os.makedirs(WORKSPACE_BASE, exist_ok=True)
            await asyncio.to_thread(_init)
            initialized = True

        response = await call_next(request)
        return response

    # 挂载沙箱 API 路由
    sandbox_router = APIRouter(prefix="/v1/sandbox", tags=["Sandbox"])

    @sandbox_router.get("/health", response_model=HealthResponse)
    async def health():
        """健康检查，返回 worker_id 用于多 worker 部署下的路由定位"""
        return HealthResponse(status="ok", workspace=WORKSPACE_BASE)

    @sandbox_router.post("/execute", response_model=ExecuteResponse)
    async def execute(req: ExecuteRequest):
        """执行 shell 命令"""
        workspace = await aget_user_workspace(req.user_id)

        if not req.command:
            return ExecuteResponse(
                output="Error: Command must be a non-empty string.",
                exit_code=1
            )

        SYLogger.info(
            f"[Sandbox Server] 执行命令: {req.command} (user={req.user_id}, timeout={req.timeout}s)")

        await aensure_subdirs(workspace)

        # 使用统一初始化脚本
        init_script = _build_init_script(workspace)

        # 使用 heredoc 格式执行命令，避免引号转义问题
        # <<'COMMAND_EOF' 表示 heredoc 内容不进行变量展开，保护命令中的特殊字符
        full_command = f'''bash <<'COMMAND_EOF'
{init_script}
{req.command}
COMMAND_EOF
'''

        # 设置环境变量
        env = os.environ.copy()
        env["TMPDIR"] = os.path.join(workspace, "tmp")
        env["TEMP"] = os.path.join(workspace, "tmp")
        env["TMP"] = os.path.join(workspace, "tmp")
        env["SANDBOX_ROOT"] = workspace

        try:
            # 使用 asyncio.create_subprocess_shell 异步执行命令，避免阻塞事件循环
            process = await asyncio.create_subprocess_shell(
                full_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=workspace,
                env=env,
                start_new_session=True,
            )

            try:
                stdout, stderr = await asyncio.wait_for(
                    process.communicate(),
                    timeout=req.timeout
                )
                # decode bytes to string
                stdout = stdout.decode('utf-8') if stdout else ''
                stderr = stderr.decode('utf-8') if stderr else ''
            except asyncio.TimeoutError:
                # 杀掉整个进程组（包括孙进程）
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    process.kill()
                stdout, stderr = await process.communicate()
                stdout = stdout.decode('utf-8') if stdout else ''
                stderr = stderr.decode('utf-8') if stderr else ''
                SYLogger.error(f"[Sandbox Server] 执行超时: {req.timeout}s")
                return ExecuteResponse(
                    output=f"Error: Command timed out after {req.timeout} seconds.\nPartial output:\n{stdout}",
                    exit_code=124,
                    truncated=False
                )

            output_parts = []
            if stdout:
                output_parts.append(stdout)
            if stderr:
                stderr_lines = stderr.strip().split("\n")
                output_parts.extend(
                    f"[stderr] {line}" for line in stderr_lines)

            output = "\n".join(output_parts) if output_parts else "<no output>"

            truncated = False
            if len(output) > MAX_OUTPUT_BYTES:
                output = output[:MAX_OUTPUT_BYTES] + \
                    f"\n\n... Output truncated at {MAX_OUTPUT_BYTES} bytes."
                truncated = True

            exit_code = process.returncode
            if exit_code != 0:
                output = f"{output.rstrip()}\n\nExit code: {exit_code}"

            SYLogger.info(
                f"[Sandbox Server] 执行完成: exit_code={exit_code}, output_len={len(output)}")

            return ExecuteResponse(
                output=output,
                exit_code=exit_code,
                truncated=truncated
            )

        except Exception as e:
            SYLogger.error(f"[Sandbox Server] 执行异常: {e}")
            return ExecuteResponse(
                output=f"Error: {type(e).__name__}: {e}",
                exit_code=1,
                truncated=False
            )

    @sandbox_router.post("/execute_stream")
    async def execute_stream(req: ExecuteStreamRequest):
        """流式执行 shell 命令（SSE）"""
        workspace = await aget_user_workspace(req.user_id)

        if not req.command:
            async def _empty():
                yield f"data: {json.dumps({'type': 'error', 'data': 'Command must be a non-empty string.'})}\n\n"
            return StreamingResponse(_empty(), media_type="text/event-stream")

        await aensure_subdirs(workspace)

        init_script = _build_init_script(workspace)
        full_command = f'''bash <<'COMMAND_EOF'
{init_script}
{req.command}
COMMAND_EOF
'''

        env = os.environ.copy()
        env["TMPDIR"] = os.path.join(workspace, "tmp")
        env["TEMP"] = os.path.join(workspace, "tmp")
        env["TMP"] = os.path.join(workspace, "tmp")
        env["SANDBOX_ROOT"] = workspace

        async def _stream():
            try:
                process = await asyncio.create_subprocess_shell(
                    full_command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=workspace,
                    env=env,
                    start_new_session=True,
                )

                queue = asyncio.Queue()
                pending = 2  # stdout + stderr 两个生产者

                async def _enqueue(stream, stream_name):
                    nonlocal pending
                    try:
                        while True:
                            chunk = await stream.read(4096)
                            if not chunk:
                                break
                            text = chunk.decode('utf-8', errors='replace')
                            await queue.put((stream_name, text))
                    finally:
                        pending -= 1
                        if pending == 0:
                            await queue.put(None)

                asyncio.create_task(_enqueue(process.stdout, "stdout"))
                asyncio.create_task(_enqueue(process.stderr, "stderr"))

                while True:
                    item = await queue.get()
                    if item is None:
                        break
                    stream_name, text = item
                    if stream_name == "stderr":
                        text = "".join(f"[stderr] {l}\n" for l in text.strip().split("\n"))
                    yield f"data: {json.dumps({'type': 'output', 'data': text})}\n\n"

                try:
                    exit_code = await asyncio.wait_for(process.wait(), timeout=5)
                except asyncio.TimeoutError:
                    try:
                        os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                    except (ProcessLookupError, PermissionError):
                        process.kill()
                    exit_code = -9

                yield f"data: {json.dumps({'type': 'done', 'exit_code': exit_code})}\n\n"

            except Exception as e:
                yield f"data: {json.dumps({'type': 'error', 'data': str(e)})}\n\n"

        return StreamingResponse(_stream(), media_type="text/event-stream")

    @sandbox_router.post("/execute_background", response_model=ExecuteBackgroundResponse)
    async def execute_background(req: ExecuteBackgroundRequest):
        """后台执行 shell 命令（不阻塞，立即返回 process_id）"""
        workspace = await aget_user_workspace(req.user_id)

        if not req.command:
            raise ValueError("Command must be a non-empty string.")

        process_id = str(uuid.uuid4()).replace('-', '')[:16]
        lock = _get_process_lock()
        SYLogger.info(
            f"[Sandbox Server] 后台执行命令: {req.command} (user={req.user_id}, process_id={process_id})")

        await aensure_subdirs(workspace)

        # 使用统一初始化脚本
        init_script = _build_init_script(workspace)

        full_command = f'''bash <<'COMMAND_EOF'
{init_script}
{req.command}
COMMAND_EOF
'''

        env = os.environ.copy()
        env["TMPDIR"] = os.path.join(workspace, "tmp")
        env["TEMP"] = os.path.join(workspace, "tmp")
        env["TMP"] = os.path.join(workspace, "tmp")
        env["SANDBOX_ROOT"] = workspace

        try:
            # 使用 asyncio.create_subprocess_shell 异步执行命令
            process = await asyncio.create_subprocess_shell(
                full_command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=workspace,
                env=env,
                start_new_session=True,
            )

            async with lock:
                with _processes_thread_lock:
                    _background_processes[process_id] = {
                        "process": process,
                        "command": req.command,
                        "user_id": req.user_id,
                        "started_at": datetime.now(),
                        "workspace": workspace,
                        "timeout": req.timeout,
                        "output_buffer": "",
                        "completed": False,
                        "killed": False,
                        "worker_id": _WORKER_ID,
                    }

            # 启动后台异步任务监控进程
            async def monitor_process():
                try:
                    stdout, stderr = await asyncio.wait_for(
                        process.communicate(),
                        timeout=req.timeout
                    )
                    stdout = stdout.decode('utf-8') if stdout else ''
                    stderr = stderr.decode('utf-8') if stderr else ''
                except asyncio.TimeoutError:
                    try:
                        os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                    except (ProcessLookupError, PermissionError):
                        process.kill()
                    stdout, stderr = await process.communicate()
                    stdout = stdout.decode('utf-8') if stdout else ''
                    stderr = stderr.decode('utf-8') if stderr else ''
                    async with lock:
                        with _processes_thread_lock:
                            if process_id in _background_processes:
                                _background_processes[process_id]["killed"] = True
                                _background_processes[process_id][
                                    "output_buffer"] = f"Error: Command timed out after {req.timeout} seconds.\nPartial output:\n{stdout}"
                    return
                except Exception as e:
                    async with lock:
                        with _processes_thread_lock:
                            if process_id in _background_processes:
                                _background_processes[process_id][
                                    "output_buffer"] = f"Error: {type(e).__name__}: {e}"
                    return

                output_parts = []
                if stdout:
                    output_parts.append(stdout)
                if stderr:
                    stderr_lines = stderr.strip().split("\n")
                    output_parts.extend(
                        f"[stderr] {line}" for line in stderr_lines)

                output = "\n".join(
                    output_parts) if output_parts else "<no output>"

                if len(output) > MAX_OUTPUT_BYTES:
                    output = output[:MAX_OUTPUT_BYTES] + \
                        f"\n\n... Output truncated at {MAX_OUTPUT_BYTES} bytes."

                exit_code = process.returncode
                if exit_code != 0:
                    output = f"{output.rstrip()}\n\nExit code: {exit_code}"

                async with _get_process_lock():
                    with _processes_thread_lock:
                        if process_id in _background_processes:
                            _background_processes[process_id]["output_buffer"] = output
                            _background_processes[process_id]["exit_code"] = exit_code
                            _background_processes[process_id]["completed"] = True
                            _background_processes[process_id]["completed_at"] = datetime.now(
                            ).timestamp()

            # 创建后台异步任务（保存引用以便 shutdown 时取消）
            task = asyncio.create_task(monitor_process())
            _monitor_tasks.append(task)
            task.add_done_callback(lambda t: _monitor_tasks.remove(
                t) if t in _monitor_tasks else None)

            return ExecuteBackgroundResponse(process_id=process_id, status="started")

        except Exception as e:
            SYLogger.error(f"[Sandbox Server] 后台执行异常: {e}")
            raise RuntimeError(f"Failed to start background process: {e}")

    @sandbox_router.post("/process_status", response_model=ProcessStatusResponse)
    async def get_process_status(req: ProcessStatusRequest):
        """查询后台进程状态"""
        lock = _get_process_lock()
        async with lock:
            with _processes_thread_lock:
                proc_info = _background_processes.get(req.process_id)

                if not proc_info:
                    return ProcessStatusResponse(
                        process_id=req.process_id,
                        status="not_found"
                    )

                # 检查用户权限
                if proc_info["user_id"] != req.user_id:
                    return ProcessStatusResponse(
                        process_id=req.process_id,
                        status="not_found"
                    )

                process = proc_info["process"]

                # 判断进程状态（asyncio subprocess 使用 returncode 而非 poll）
                if proc_info["killed"]:
                    status = "timeout"
                elif proc_info["completed"]:
                    status = "completed"
                elif process.returncode is not None:
                    # 进程已结束但还没被监控任务处理（极少情况）
                    status = "completed"
                else:
                    status = "running"

                return ProcessStatusResponse(
                    process_id=req.process_id,
                    status=status,
                    exit_code=proc_info.get("exit_code"),
                    output=proc_info.get(
                        "output_buffer") if proc_info["completed"] or proc_info["killed"] else None,
                    truncated=len(proc_info.get("output_buffer", "")) >= MAX_OUTPUT_BYTES if proc_info.get(
                        "output_buffer") else False,
                    command=proc_info["command"],
                    started_at=proc_info["started_at"].isoformat()
                )

    @sandbox_router.post("/kill_process", response_model=KillProcessResponse)
    async def kill_process(req: KillProcessRequest):
        """终止后台进程"""
        lock = _get_process_lock()
        async with lock:
            with _processes_thread_lock:
                proc_info = _background_processes.get(req.process_id)

                if not proc_info:
                    return KillProcessResponse(
                        process_id=req.process_id,
                        status="not_found"
                    )

                # 检查用户权限
                if proc_info["user_id"] != req.user_id:
                    return KillProcessResponse(
                        process_id=req.process_id,
                        status="not_found"
                    )

                if proc_info["completed"] or proc_info["killed"]:
                    return KillProcessResponse(
                        process_id=req.process_id,
                        status="already_completed",
                        output=proc_info.get("output_buffer")
                    )

                process = proc_info["process"]

            # 在线程锁外执行 kill 操作（可能阻塞）
            try:
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    process.kill()
                try:
                    await asyncio.wait_for(process.wait(), timeout=5)
                except asyncio.TimeoutError:
                    SYLogger.warning(
                        f"[Sandbox Server] 终止进程后等待退出超时: {req.process_id}")
            except Exception as e:
                SYLogger.warning(f"[Sandbox Server] 终止进程时出错: {e}")

            with _processes_thread_lock:
                if req.process_id not in _background_processes:
                    return KillProcessResponse(
                        process_id=req.process_id,
                        status="not_found"
                    )
                proc_info = _background_processes[req.process_id]
                current_output = proc_info.get("output_buffer", "")
                proc_info["killed"] = True
                proc_info["completed"] = True
                proc_info["exit_code"] = process.returncode if process.returncode is not None else -9

                if not current_output:
                    current_output = f"Process killed by user request. Exit code: {proc_info['exit_code']}"
                proc_info["output_buffer"] = current_output

            SYLogger.info(f"[Sandbox Server] 进程已终止: {req.process_id}")

            return KillProcessResponse(
                process_id=req.process_id,
                status="killed",
                output=current_output
            )

    @sandbox_router.post("/kill_all_processes", response_model=KillAllProcessesResponse)
    async def kill_all_processes(req: KillAllProcessesRequest):
        """终止用户的所有后台进程"""
        lock = _get_process_lock()
        killed_count = 0
        already_completed = 0

        # 收集匹配的进程
        async with lock:
            with _processes_thread_lock:
                to_kill = []
                for pid, info in list(_background_processes.items()):
                    if info["user_id"] != req.user_id:
                        continue
                    if info["completed"] or info["killed"]:
                        already_completed += 1
                        continue
                    to_kill.append((pid, info))

        # 在锁外逐个 kill
        for pid, info in to_kill:
            process = info["process"]
            try:
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    process.kill()
                try:
                    await asyncio.wait_for(process.wait(), timeout=5)
                except asyncio.TimeoutError:
                    SYLogger.warning(
                        f"[Sandbox Server] kill_all: 等待进程退出超时: {pid}")
            except Exception as e:
                SYLogger.warning(
                    f"[Sandbox Server] kill_all: 终止进程出错: {pid} - {e}")

            with _processes_thread_lock:
                if pid in _background_processes:
                    info = _background_processes[pid]
                    current_output = info.get("output_buffer", "")
                    info["killed"] = True
                    info["completed"] = True
                    info["exit_code"] = process.returncode if process.returncode is not None else -9
                    if not current_output:
                        info[
                            "output_buffer"] = f"Process killed by kill_all. Exit code: {info['exit_code']}"

            killed_count += 1

        SYLogger.info(
            f"[Sandbox Server] kill_all: user={req.user_id}, "
            f"killed={killed_count}, already_completed={already_completed}"
        )

        return KillAllProcessesResponse(
            killed_count=killed_count,
            already_completed=already_completed,
        )

    @sandbox_router.post("/ls", response_model=list[FileInfo])
    async def ls_info(req: LsRequest):
        """列出目录内容"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            target_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            SYLogger.error(f"[Sandbox Server] 列目录失败: {e}")
            return []

        def _ls():
            if not os.path.isdir(target_path):
                return None
            results = []
            try:
                with os.scandir(target_path) as it:
                    for entry in it:
                        abs_path = os.path.join(target_path, entry.name)
                        virtual_path = "/" + os.path.relpath(abs_path, workspace)
                        info = FileInfo(path=virtual_path)
                        try:
                            info.is_dir = entry.is_dir(follow_symlinks=False)
                            if not info.is_dir:
                                info.size = entry.stat().st_size
                                info.modified_at = str(entry.stat().st_mtime)
                        except Exception:
                            pass
                        results.append(info)
            except Exception as e:
                SYLogger.error(f"[Sandbox Server] 列目录异常: {e}")
            return results

        result = await asyncio.to_thread(_ls)
        if result is None:
            SYLogger.error(f"[Sandbox Server] 列目录失败: 目录不存在 {target_path}")
            return []
        SYLogger.info(f"[Sandbox Server] 目录内容: {len(result)} 项")
        return result

    @sandbox_router.post("/read", response_model=ReadResponse)
    async def read_file(req: ReadRequest):
        """读取文件内容"""
        workspace = await aget_user_workspace(req.user_id)
        original_path = req.file_path

        try:
            file_path = resolve_sandbox_path(original_path, workspace)
        except ValueError as e:
            SYLogger.error(f"[Sandbox Server] 读取失败: {e}")
            return ReadResponse(error=str(e), content=None)

        SYLogger.info(
            f"[Sandbox Server] 读取文件: {file_path} (offset={req.offset}, limit={req.limit})")

        def _read():
            if not os.path.isfile(file_path):
                if os.path.isabs(original_path) and os.path.isfile(original_path):
                    return ReadResponse(
                        error=f"File '{original_path}' exists but is outside sandbox. "
                              f"Try reading from sandbox path: {os.path.basename(original_path)}",
                        content=None
                    )
                return ReadResponse(error=f"File '{file_path}' not found", content=None)

            if os.path.getsize(file_path) == 0:
                return ReadResponse(content="System reminder: File exists but has empty contents", error=None)

            with open(file_path, 'rb') as f:
                raw_prefix = f.read(8192)

            try:
                raw_prefix.decode('utf-8')
                is_text = True
            except UnicodeDecodeError:
                is_text = False

            if is_text:
                lines = []
                lines_read = 0
                with open(file_path, 'r', encoding='utf-8', newline=None) as f:
                    for i, line in enumerate(f):
                        if i < req.offset:
                            continue
                        if lines_read >= req.limit:
                            break
                        lines.append(line.rstrip('\n').rstrip('\r'))
                        lines_read += 1

                if not lines:
                    if req.offset > 0:
                        with open(file_path, 'r') as f:
                            total_lines = sum(1 for _ in f)
                        return ReadResponse(error=f"Line offset {req.offset} exceeds file length ({total_lines} lines)", content=None)
                    return ReadResponse(content="System reminder: File exists but has empty contents", error=None)

                content = "\n".join(lines)
                return ReadResponse(content=content, error=None, encoding="utf-8")
            else:
                MAX_BINARY_BYTES = 500 * 1024
                file_size = os.path.getsize(file_path)
                if file_size > MAX_BINARY_BYTES:
                    return ReadResponse(error=f"Binary file exceeds maximum preview size of {MAX_BINARY_BYTES} bytes", content=None)

                with open(file_path, 'rb') as f:
                    raw = f.read()
                content = base64.b64encode(raw).decode('ascii')
                return ReadResponse(content=content, error=None, encoding="base64")

        try:
            return await asyncio.to_thread(_read)
        except Exception as e:
            SYLogger.error(f"[Sandbox Server] 读取异常: {e}")
            return ReadResponse(error=str(e), content=None)

    @sandbox_router.post("/write", response_model=WriteResponse)
    async def write_file(req: WriteRequest):
        """写入新文件（文件已存在时返回错误，应使用 edit 替代）"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            file_path = resolve_sandbox_path(req.file_path, workspace)
        except ValueError as e:
            SYLogger.error(f"[Sandbox Server] 写入失败: {e}")
            return WriteResponse(error=str(e), path=None)

        SYLogger.info(f"[Sandbox Server] 写入文件: {file_path}")

        def _write():
            if os.path.exists(file_path):
                SYLogger.warning(f"[Sandbox Server] 文件已存在: {file_path}")
                return WriteResponse(error=f"Error: File already exists at {req.file_path}. Use edit_file to modify existing files.", path=None)

            content = base64.b64decode(req.content).decode('utf-8')

            parent = os.path.dirname(file_path)
            if parent:
                os.makedirs(parent, exist_ok=True)

            with open(file_path, 'w') as f:
                f.write(content)

            SYLogger.info(
                f"[Sandbox Server] 写入成功(新建): {file_path} ({len(content)} 字符)")
            virtual_path = "/" + os.path.relpath(file_path, workspace)
            return WriteResponse(error=None, path=virtual_path)

        try:
            return await asyncio.to_thread(_write)
        except Exception as e:
            SYLogger.error(f"[Sandbox Server] 写入异常: {e}")
            return WriteResponse(error=str(e), path=None)

    @sandbox_router.post("/edit", response_model=EditResponse)
    async def edit_file(req: EditRequest):
        """编辑文件"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            file_path = resolve_sandbox_path(req.file_path, workspace)
        except ValueError as e:
            SYLogger.error(f"[Sandbox Server] 编辑失败: {e}")
            return EditResponse(error=str(e))

        SYLogger.info(f"[Sandbox Server] 编辑文件: {file_path}")

        def _edit():
            old_string = base64.b64decode(req.old_string).decode('utf-8')
            new_string = base64.b64decode(req.new_string).decode('utf-8')

            if not os.path.isfile(file_path):
                SYLogger.error(f"[Sandbox Server] 编辑失败: 文件不存在 {file_path}")
                return EditResponse(error=f"File '{file_path}' not found")

            with open(file_path, 'r') as f:
                content = f.read()

            count = content.count(old_string)

            if count == 0:
                SYLogger.error(f"[Sandbox Server] 编辑失败: 未找到匹配字符串")
                return EditResponse(error=f"String not found: '{old_string[:50]}...'")
            if count > 1 and not req.replace_all:
                SYLogger.error(f"[Sandbox Server] 编辑失败: 多处匹配 ({count}次)")
                return EditResponse(
                    error=f"String appears {count} times. Use replace_all=True to replace all."
                )

            if req.replace_all:
                new_content = content.replace(old_string, new_string)
            else:
                new_content = content.replace(old_string, new_string, 1)

            with open(file_path, 'w') as f:
                f.write(new_content)

            SYLogger.info(f"[Sandbox Server] 编辑成功: {file_path} (替换 {count} 处)")
            virtual_path = "/" + os.path.relpath(file_path, workspace)
            return EditResponse(error=None, path=virtual_path, occurrences=count)

        try:
            return await asyncio.to_thread(_edit)
        except Exception as e:
            SYLogger.error(f"[Sandbox Server] 编辑异常: {e}")
            return EditResponse(error=str(e))

    @sandbox_router.post("/upload", response_model=UploadResponse)
    async def upload_file(req: UploadRequest):
        """上传文件"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            file_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            return UploadResponse(path=req.path, error=str(e))

        def _upload():
            content = base64.b64decode(req.content)
            parent = os.path.dirname(file_path)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(file_path, 'wb') as f:
                f.write(content)
            return UploadResponse(path=file_path, error=None)

        try:
            return await asyncio.to_thread(_upload)
        except Exception as e:
            return UploadResponse(path=file_path, error=str(e))

    @sandbox_router.post("/delete", response_model=DeleteResponse)
    async def delete_file(req: DeleteRequest):
        """删除文件或目录"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            file_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            return DeleteResponse(path=req.path, error=str(e))

        def _delete():
            if not os.path.exists(file_path):
                return DeleteResponse(path=file_path, error="file_not_found")
            if os.path.isdir(file_path):
                if not req.recursive:
                    return DeleteResponse(path=file_path, error="is_directory, set recursive=true")
                # 重试机制：并发同步写入文件时 rmtree 可能报 Directory not empty
                import time
                for attempt in range(3):
                    try:
                        shutil.rmtree(file_path)
                        break
                    except OSError:
                        if attempt < 2:
                            time.sleep(0.3)
                        else:
                            shutil.rmtree(file_path, ignore_errors=True)
            else:
                os.remove(file_path)
            return DeleteResponse(path=file_path, error=None)

        try:
            return await asyncio.to_thread(_delete)
        except Exception as e:
            return DeleteResponse(path=file_path, error=str(e))

    @sandbox_router.post("/batch_upload", response_model=BatchUploadResponse)
    async def batch_upload(req: BatchUploadRequest):
        """批量上传文件，单次 HTTP 请求上传多个文件"""
        workspace = await aget_user_workspace(req.user_id)

        def _batch():
            results = []
            success_count = 0
            failed_count = 0

            for file_entry in req.files:
                try:
                    file_path = resolve_sandbox_path(file_entry.path, workspace)
                    content = base64.b64decode(file_entry.content)
                    parent = os.path.dirname(file_path)
                    if parent:
                        os.makedirs(parent, exist_ok=True)
                    with open(file_path, 'wb') as f:
                        f.write(content)
                    results.append(BatchUploadResult(path=file_entry.path))
                    success_count += 1
                except Exception as e:
                    results.append(BatchUploadResult(path=file_entry.path, error=str(e)))
                    failed_count += 1

            return BatchUploadResponse(results=results, success_count=success_count, failed_count=failed_count)

        return await asyncio.to_thread(_batch)

    @sandbox_router.post("/download", response_model=DownloadResponse)
    async def download_file(req: DownloadRequest):
        """下载文件"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            file_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            return DownloadResponse(path=req.path, error=str(e))

        def _download():
            if not os.path.isfile(file_path):
                return DownloadResponse(path=file_path, error="file_not_found")
            with open(file_path, 'rb') as f:
                content = f.read()
            return DownloadResponse(
                path=file_path,
                content=base64.b64encode(content).decode(),
                error=None
            )

        try:
            return await asyncio.to_thread(_download)
        except Exception as e:
            return DownloadResponse(path=file_path, error=str(e))

    @sandbox_router.post("/tree", response_model=TreeResponse)
    async def tree_dir(req: TreeRequest):
        """以树形结构展示目录"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            target_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            SYLogger.error(f"[Sandbox Server] tree 失败: {e}")
            return TreeResponse(error=str(e))

        max_depth = req.max_depth if req.max_depth is not None else 0
        max_files = req.max_files if req.max_files is not None else 0
        if max_depth == 0:
            max_depth = 100

        def _tree():
            if not os.path.isdir(target_path):
                return None
            file_count = 0

            def build_tree(dir_path: str, virtual_dir: str, depth: int) -> TreeNode:
                nonlocal file_count
                name = os.path.basename(dir_path) or dir_path
                node = TreeNode(path=virtual_dir, name=name,
                                is_dir=True, children=[])

                if depth >= max_depth:
                    return node

                try:
                    entries = sorted(os.scandir(dir_path), key=lambda e: (
                        not e.is_dir(follow_symlinks=False), e.name.lower()))
                except PermissionError:
                    return node

                for entry in entries:

                    abs_path = os.path.join(dir_path, entry.name)
                    virtual_path = "/" + os.path.relpath(abs_path, workspace)
                    file_count += 1

                    try:
                        is_dir = entry.is_dir(follow_symlinks=False)
                    except OSError:
                        continue

                    if is_dir:
                        child = build_tree(abs_path, virtual_path, depth + 1)
                        node.children.append(child)
                    else:
                        child = TreeNode(
                            path=virtual_path,
                            name=entry.name,
                            is_dir=False,
                            size=entry.stat().st_size,
                        )
                        node.children.append(child)

                return node

            root_virtual = "/" + os.path.relpath(target_path, workspace)
            return build_tree(target_path, root_virtual, 0)

        try:
            tree_root = await asyncio.to_thread(_tree)
            if tree_root is None:
                return TreeResponse(error=f"Directory not found: {req.path}")
            SYLogger.info(
                f"[Sandbox Server] tree 完成: path={req.path}")
            return TreeResponse(tree=tree_root)
        except Exception as e:
            SYLogger.error(f"[Sandbox Server] tree 异常: {e}")
            return TreeResponse(error=str(e))

    @sandbox_router.post("/glob", response_model=list[FileInfo])
    async def glob_files(req: GlobRequest):
        """glob 搜索文件"""
        import glob as glob_module

        workspace = await aget_user_workspace(req.user_id)
        try:
            search_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            SYLogger.error(f"[Sandbox Server] glob 失败: {e}")
            return []

        full_pattern = os.path.join(search_path, req.pattern)

        def _glob():
            matches = sorted(glob_module.glob(full_pattern, recursive=True))
            results = []
            for m in matches:
                virtual_path = "/" + os.path.relpath(m, workspace)
                info = FileInfo(path=virtual_path)
                try:
                    info.is_dir = os.path.isdir(m)
                    if not info.is_dir:
                        info.size = os.path.getsize(m)
                except Exception:
                    pass
                results.append(info)
            return results

        return await asyncio.to_thread(_glob)

    @sandbox_router.post("/grep", response_model=list[GrepMatch])
    async def grep_search(req: GrepRequest):
        """grep 搜索内容"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            search_path = resolve_sandbox_path(req.path or "/", workspace)
        except ValueError as e:
            SYLogger.error(f"[Sandbox Server] grep 失败: {e}")
            return []

        quoted_path = shlex.quote(search_path)
        grep_opts = "-rHnF"

        # 安全处理 glob_pattern，使用 shlex.quote 防止命令注入
        glob_pattern = f"--include={shlex.quote(req.glob)}" if req.glob else ""
        pattern_escaped = shlex.quote(req.pattern)

        cmd = f"grep {grep_opts} {glob_pattern} -e {pattern_escaped} {quoted_path} 2>/dev/null || true"

        # 使用 asyncio.create_subprocess_shell 异步执行
        proc = await asyncio.create_subprocess_shell(
            cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            start_new_session=True,
        )
        stdout, _ = await proc.communicate()
        result_text = stdout.decode('utf-8') if stdout else ''

        matches = []
        for line in result_text.strip().split("\n"):
            if not line:
                continue
            # 使用更稳健的解析方式：找到第一个冒号（行号前）和第二个冒号（内容前）
            # 先获取行号和内容部分（路径:path:line:text）
            # 格式: path:line:text（text 可能包含冒号）
            first_colon = line.find(":")
            if first_colon == -1:
                continue
            second_colon = line.find(":", first_colon + 1)
            if second_colon == -1:
                continue

            path_part = line[:first_colon]
            # 将绝对路径转换为虚拟路径
            try:
                virtual_path_part = "/" + os.path.relpath(path_part, workspace)
            except ValueError:
                virtual_path_part = path_part
            try:
                line_num = int(line[first_colon + 1:second_colon])
            except ValueError:
                continue
            text_part = line[second_colon + 1:]

            matches.append(GrepMatch(
                path=virtual_path_part,
                line=line_num,
                text=text_part
            ))

        return matches

    @sandbox_router.post("/stat", response_model=StatResponse)
    async def stat_file(req: StatRequest):
        """查询文件/目录状态"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            target_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            return StatResponse(error=str(e))

        virtual_path = "/" + os.path.relpath(target_path, workspace)

        def _stat():
            if not os.path.exists(target_path):
                return StatResponse(path=virtual_path, exists=False)
            try:
                is_dir = os.path.isdir(target_path)
                size = None
                if not is_dir:
                    size = os.path.getsize(target_path)
                return StatResponse(path=virtual_path, exists=True, is_dir=is_dir, size=size)
            except Exception as e:
                return StatResponse(path=virtual_path, error=str(e))

        return await asyncio.to_thread(_stat)

    @sandbox_router.post("/list", response_model=LsResponse)
    async def list_files(req: LsRequest):
        """列出目录下的所有文件"""
        workspace = await aget_user_workspace(req.user_id)
        try:
            target_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            return LsResponse(error=str(e))

        MAX_WALK_DEPTH = 100
        MAX_FILES = 100000

        def _list():
            if not os.path.exists(target_path):
                return LsResponse(error="path_not_found")
            if not os.path.isdir(target_path):
                return LsResponse(error="not_a_directory")

            files = []
            file_count = 0
            try:
                for item in os.listdir(target_path):
                    item_path = os.path.join(target_path, item)
                    virtual_path = "/" + os.path.relpath(item_path, workspace)
                    info = FileInfo(path=virtual_path)
                    try:
                        info.is_dir = os.path.isdir(item_path)
                        if not info.is_dir:
                            info.size = os.path.getsize(item_path)
                        info.modified_at = datetime.fromtimestamp(
                            os.path.getmtime(item_path)
                        ).isoformat()
                    except Exception:
                        pass
                    files.append(info)
                    file_count += 1

                    if file_count >= MAX_FILES:
                        return LsResponse(files=files, warning=f"Results truncated at {MAX_FILES} files")

                    if info.is_dir:
                        for root, dirs, filenames in os.walk(item_path):
                            depth = root[len(item_path):].count(os.sep)
                            if depth >= MAX_WALK_DEPTH:
                                dirs.clear()
                                continue

                            for filename in filenames:
                                if file_count >= MAX_FILES:
                                    return LsResponse(files=files, warning=f"Results truncated at {MAX_FILES} files")

                                filepath = os.path.join(root, filename)
                                virtual_filepath = "/" + \
                                    os.path.relpath(filepath, workspace)
                                file_info = FileInfo(path=virtual_filepath)
                                try:
                                    file_info.is_dir = False
                                    file_info.size = os.path.getsize(filepath)
                                    file_info.modified_at = datetime.fromtimestamp(
                                        os.path.getmtime(filepath)
                                    ).isoformat()
                                except Exception:
                                    pass
                                files.append(file_info)
                                file_count += 1
            except Exception as e:
                return LsResponse(error=str(e))

            return LsResponse(files=files)

        return await asyncio.to_thread(_list)

    @sandbox_router.post("/reset", response_model=ResetResponse)
    async def reset_workspace(req: ResetRequest):
        """重置用户工作目录"""
        workspace = await aget_user_workspace(req.user_id)

        def _reset():
            if os.path.exists(workspace):
                for item in os.listdir(workspace):
                    item_path = os.path.join(workspace, item)
                    try:
                        if os.path.isdir(item_path):
                            shutil.rmtree(item_path)
                        else:
                            os.remove(item_path)
                    except Exception:
                        pass
            return ResetResponse(status="reset", path=workspace)

        return await asyncio.to_thread(_reset)

    @sandbox_router.post("/port_forward", response_model=PortForwardResponse)
    async def port_forward(req: PortForwardRequest):
        """端口转发管理（记录/查询沙箱内需要暴露的端口）"""
        workspace = await aget_user_workspace(req.user_id)
        ports_file = os.path.join(workspace, ".ports.json")

        if req.action == "list":
            def _list_ports():
                if os.path.isfile(ports_file):
                    try:
                        with open(ports_file, 'r') as f:
                            return json.load(f)
                    except Exception:
                        return None
                return []

            result = await asyncio.to_thread(_list_ports)
            if result is None:
                return PortForwardResponse(error="Failed to read ports file")
            return PortForwardResponse(ports=result)

        elif req.action == "add":
            if req.port <= 0 or req.port > 65535:
                return PortForwardResponse(error=f"Invalid port: {req.port}")

            def _add_port():
                ports = []
                if os.path.isfile(ports_file):
                    try:
                        with open(ports_file, 'r') as f:
                            ports = json.load(f)
                    except Exception:
                        ports = []
                if not any(p.get("port") == req.port for p in ports):
                    from urllib.parse import urlparse
                    host = urlparse(f"http://{_WORKER_ID}").hostname or "localhost"
                    ports.append({"port": req.port, "url": f"http://{host}:{req.port}"})
                    with open(ports_file, 'w') as f:
                        json.dump(ports, f)
                return ports

            ports = await asyncio.to_thread(_add_port)
            return PortForwardResponse(ports=ports)

        elif req.action == "remove":
            def _remove_port():
                ports = []
                if os.path.isfile(ports_file):
                    try:
                        with open(ports_file, 'r') as f:
                            ports = json.load(f)
                        ports = [p for p in ports if p.get("port") != req.port]
                        with open(ports_file, 'w') as f:
                            json.dump(ports, f)
                    except Exception as e:
                        return None, str(e)
                return ports, None

            ports, error = await asyncio.to_thread(_remove_port)
            if error:
                return PortForwardResponse(error=error)
            return PortForwardResponse(ports=ports)

        else:
            return PortForwardResponse(error=f"Unknown action: {req.action}")

    @sandbox_router.post("/watch", response_model=WatchResponse)
    async def watch_changes(req: WatchRequest):
        """查询指定路径下自上次 watch 以来的文件变更（基于快照 diff）

        首次调用记录当前文件快照，后续调用对比差异返回变更事件。
        """
        workspace = await aget_user_workspace(req.user_id)
        try:
            target_path = resolve_sandbox_path(req.path, workspace)
        except ValueError as e:
            return WatchResponse(error=str(e))

        snapshot_file = os.path.join(workspace, f".watch_{req.path.replace('/', '_')}.json")

        def _scan(d: str) -> dict:
            if not os.path.isdir(d):
                return None
            result = {}
            for root, dirs, files in os.walk(d):
                dirs[:] = [d2 for d2 in dirs if d2 not in (".git", "__pycache__", "node_modules")]
                for name in dirs + files:
                    full = os.path.join(root, name)
                    rel = os.path.relpath(full, d)
                    try:
                        st = os.stat(full)
                        result[rel] = (st.st_mtime, st.st_size, os.path.isdir(full))
                    except OSError:
                        pass
            return result

        current = await asyncio.to_thread(_scan, target_path)

        if current is None:
            return WatchResponse(error=f"Not a directory: {req.path}")

        def _load_prev_and_diff():
            if os.path.isfile(snapshot_file):
                try:
                    with open(snapshot_file, 'r') as f:
                        prev = json.load(f)
                except Exception:
                    prev = {}
            else:
                prev = {}

            events = []
            allowed_types = set(req.event_types) if req.event_types else None
            all_paths = set(list(prev.keys()) + list(current.keys()))

            for p in sorted(all_paths):
                old = prev.get(p)
                new = current.get(p)
                if old and not new:
                    evt = "deleted"
                elif not old and new:
                    evt = "created"
                elif old != new:
                    evt = "modified"
                else:
                    continue

                if allowed_types and evt not in allowed_types:
                    continue

                is_dir = new[2] if new else (old[2] if old else False)
                virtual = "/" + os.path.relpath(os.path.join(target_path, p), workspace)
                events.append(WatchEvent(event_type=evt, path=virtual, is_dir=is_dir))

            with open(snapshot_file, 'w') as f:
                json.dump(current, f)

            return events

        events = await asyncio.to_thread(_load_prev_and_diff)
        return WatchResponse(events=events)

    app.include_router(sandbox_router)

    return app
