"""上下文压缩 middleware 构建工具。

根据 nacos 中配置的模型 maxTokens，用绝对 token 数设置压缩阈值，
避免依赖模型 profile 信息（部分模型不提供 profile）。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from deepagents.middleware.summarization import (
    SummarizationMiddleware,
    SummarizationToolMiddleware,
)

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel
    from deepagents.backends.protocol import BACKEND_TYPES


def build_summarization_middleware(
    model: BaseChatModel,
    model_name: str,
    backend: "BACKEND_TYPES",
    *,
    trigger_fraction: float = 0.70,
    keep_fraction: float = 0.10,
    default_max_tokens: int = 200000,
) -> SummarizationToolMiddleware:
    """根据模型上下文窗口大小构建压缩 middleware。

    使用绝对 token 数而非 fraction 模式，避免要求模型提供 profile 信息。

    Args:
        model: LLM 实例。
        model_name: 模型名称（用于从 nacos 读取配置）。
        backend: 后端实例。
        trigger_fraction: 触发压缩的上下文窗口比例，默认 70%。
        keep_fraction: 压缩后保留的上下文窗口比例，默认 10%。
        default_max_tokens: 无法从配置读取时的默认上下文窗口大小。

    Returns:
        SummarizationToolMiddleware 实例（包含自动压缩 + compact_conversation 工具）。
    """
    try:
        from sycommon.config.Config import Config

        llm_cfg = Config().get_llm_config(model_name)
        max_tokens = llm_cfg.get("maxTokens", default_max_tokens)
    except Exception:
        max_tokens = default_max_tokens

    trigger_tokens = int(max_tokens * trigger_fraction)
    keep_tokens = int(max_tokens * keep_fraction)

    summ = SummarizationMiddleware(
        model=model,
        backend=backend,
        trigger=("tokens", trigger_tokens),
        keep=("tokens", keep_tokens),
        trim_tokens_to_summarize=None,
        truncate_args_settings={
            "trigger": ("tokens", trigger_tokens),
            "keep": ("tokens", keep_tokens),
            "max_length": 2000,
        },
    )
    return SummarizationToolMiddleware(summ)
