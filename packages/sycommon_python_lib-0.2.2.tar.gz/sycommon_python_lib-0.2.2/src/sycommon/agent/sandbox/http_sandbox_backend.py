"""
HTTP 客户端沙箱后端

通过 HTTP API 连接远程沙箱容器，支持 Nacos 服务发现
支持自动故障转移和重试
适配 deepagents 0.5.0a2 协议
"""

import asyncio
import base64
import os
import ssl
import sys
import tempfile
import threading
import requests
from pathlib import Path
from typing import Optional, List

import aiohttp

from sycommon.logging.kafka_log import SYLogger
from sycommon.agent.sandbox.file_ops import FileOperationsMixin, SANDBOX_API_PREFIX

from deepagents.backends.protocol import (
    SandboxBackendProtocol,
    ExecuteResponse,
    FileDownloadResponse,
    FileUploadResponse,
)

# SSL 上下文
try:
    import certifi
    _SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    _SSL_CONTEXT = ssl.create_default_context()


class HTTPSandboxBackend(FileOperationsMixin, SandboxBackendProtocol):
    """
    通过 HTTP API 连接远程沙箱容器

    支持两种模式:
    1. 直接 URL: 直接指定沙箱服务地址
    2. Nacos 服务发现: 通过服务名从 Nacos 获取实例（支持自动故障转移）

    使用示例:
        # 直接 URL 模式
        backend = HTTPSandboxBackend(
            base_url="http://192.168.1.100:8080",
            user_id="user123"
        )

        # Nacos 服务发现模式（支持自动故障转移）
        backend = HTTPSandboxBackend.from_nacos(
            service_name="sandbox-service",
            user_id="user123"
        )

        # 带自动同步目录
        backend = HTTPSandboxBackend(
            base_url="http://localhost:8080",
            user_id="user123",
            sync_dirs=[
                ("/local/path/skills", "/skills"),
                ("/local/path/memory", "/memory"),
            ]
        )
        backend.sync()  # 手动触发同步

        # 同步调用
        result = backend.execute("python --version")

        # 异步调用
        result = await backend.aexecute("python --version")
    """

    def __init__(
        self,
        base_url: str,
        user_id: str,
        timeout: int = 180,
        sync_dirs: List[tuple[str, str]] = None,
        auto_sync: bool = False,
        nacos_service_name: str = None,
        nacos_group: str = "DEFAULT_GROUP",
    ):
        """
        初始化 HTTP 沙箱后端

        Args:
            base_url: 沙箱服务地址，如 http://192.168.1.100:8080
            user_id: 用户ID，用于隔离工作目录
            timeout: 默认超时时间（秒）
            sync_dirs: 要同步的目录列表 [(本地路径, 沙箱路径), ...]
            auto_sync: 是否在首次文件操作时自动同步（默认 False）
            nacos_service_name: Nacos 服务名（用于故障转移时重新发现服务）
            nacos_group: Nacos 服务分组
        """
        self._base_url = base_url.rstrip("/")
        self._user_id = user_id
        self._timeout = timeout
        self._sync_dirs = sync_dirs or []
        self._auto_sync = auto_sync
        self._synced = False
        self._workspace_verified = False

        # Nacos 配置（用于故障转移）
        self._nacos_service_name = nacos_service_name
        self._nacos_group = nacos_group

        # 生成 ID
        self._id = self._base_url.replace(
            "http://", ""
        ).replace(
            "https://", ""
        ).replace(
            ":", "-"
        ).replace(
            "/", "-"
        )

    @classmethod
    def from_nacos(
        cls,
        service_name: str,
        user_id: str,
        group: str = "DEFAULT_GROUP",
        version: str = None,
        timeout: int = 180,
        sync_dirs: List[tuple[str, str]] = None,
        auto_sync: bool = False,
        load_balance: bool = True,
    ) -> "HTTPSandboxBackend":
        """
        从 Nacos 服务发现创建后端实例

        Args:
            service_name: Nacos 服务名
            user_id: 用户ID，用于隔离工作目录和负载均衡
            group: 服务分组
            version: 服务版本
            timeout: 超时时间
            sync_dirs: 要同步的目录列表 [(本地路径, 沙箱路径), ...]
            auto_sync: 是否在首次文件操作时自动同步
            load_balance: 是否基于 user_id 进行负载均衡（默认 True）

        Returns:
            HTTPSandboxBackend 实例

        Raises:
            RuntimeError: 无法发现服务实例或 NacosService 未初始化
        """
        SYLogger.info(f"[Sandbox] from_nacos 开始: service_name={service_name}, user_id={user_id}, version={version}")

        # 本地调试支持：读取环境变量 SANDBOX_URL，如果设置则直接使用，跳过 Nacos
        sandbox_url = os.environ.get('SANDBOX_URL', '').strip()
        if sandbox_url:
            SYLogger.info(f"[Sandbox] 检测到 SANDBOX_URL={sandbox_url}，跳过 Nacos 直接连接")
            return cls(
                base_url=sandbox_url,
                user_id=user_id,
                timeout=timeout,
                sync_dirs=sync_dirs,
                auto_sync=auto_sync,
            )

        from sycommon.synacos.nacos_service import NacosService
        import hashlib

        # 获取单例实例
        nacos_manager = NacosService(None)

        # 检查单例是否已正确初始化
        if not hasattr(nacos_manager, 'discovery'):
            raise RuntimeError(
                "NacosService 未初始化，请确保服务启动时已调用 NacosService.setup_nacos(config)"
            )

        SYLogger.info(f"[Sandbox] 正在查询 Nacos 服务实例...")
        # return_all=True: 返回所有版本匹配的实例，由本地做哈希 LB
        instances = nacos_manager.get_service_instances(
            service_name, group=group, target_version=version, return_all=True
        )

        if not instances:
            raise RuntimeError(f"服务 [{service_name}] 无可用实例")

        # 基于用户ID的负载均衡：使用哈希选择实例
        if load_balance and len(instances) > 1:
            hash_value = int(hashlib.md5(user_id.encode()).hexdigest(), 16)
            instance_index = hash_value % len(instances)
            instance = instances[instance_index]
            SYLogger.info(f"[Sandbox] 负载均衡: user_id={user_id} -> instance[{instance_index}/{len(instances)}]")
        else:
            instance = instances[0]

        base_url = f"http://{instance['ip']}:{instance['port']}"

        SYLogger.info(f"[Sandbox] Nacos 发现沙箱服务: {service_name} -> {base_url}")

        return cls(
            base_url=base_url,
            user_id=user_id,
            timeout=timeout,
            sync_dirs=sync_dirs,
            auto_sync=auto_sync,
            nacos_service_name=service_name,
            nacos_group=group,
        )

    # ============== 内部方法 - 同步版本 ==============

    def _refresh_from_nacos_and_switch_sync(self) -> bool:
        """从 Nacos 重新获取服务实例并切换（同步版本）"""
        # 防止递归：如果在故障转移过程中再次调用，直接返回 False
        if getattr(self, '_in_failover', False):
            SYLogger.warning("[Sandbox] 已在故障转移过程中，跳过重复调用")
            return False

        if not self._nacos_service_name:
            return False

        self._in_failover = True
        try:
            from sycommon.synacos.nacos_service import NacosService
            nacos_manager = NacosService(None)

            if not hasattr(nacos_manager, 'discovery'):
                return False

            instances = nacos_manager.get_service_instances(
                self._nacos_service_name,
                group=self._nacos_group
            )

            if not instances:
                SYLogger.warning(f"[Sandbox] Nacos 未发现可用服务: {self._nacos_service_name}")
                return False

            instance = instances[0]
            new_url = f"http://{instance['ip']}:{instance['port']}"

            if new_url == self._base_url and len(instances) > 1:
                instance = instances[1]
                new_url = f"http://{instance['ip']}:{instance['port']}"

            if new_url != self._base_url:
                old_url = self._base_url
                SYLogger.info(f"[Sandbox] 准备切换服务: {old_url} -> {new_url}")

                # 1. 先从旧服务下载工作空间文件
                workspace_files = []
                try:
                    sync_result = self._sync_workspace_sync()
                    workspace_files = sync_result.get("files", [])
                    SYLogger.info(f"[Sandbox] 从旧服务获取 {len(workspace_files)} 个工作空间文件")
                except Exception as e:
                    SYLogger.warning(f"[Sandbox] 获取工作空间文件失败: {e}")

                # 2. 切换到新服务
                self._base_url = new_url
                self._synced = False

                # 3. 同步配置的目录到新服务
                if self._sync_dirs:
                    SYLogger.info(f"[Sandbox] 重新同步配置目录到新服务...")
                    self._sync_sync()

                # 4. 上传工作空间文件到新服务
                if workspace_files:
                    SYLogger.info(f"[Sandbox] 上传 {len(workspace_files)} 个工作空间文件到新服务...")
                    upload_result = self._upload_workspace_files_sync(workspace_files)
                    SYLogger.info(f"[Sandbox] 工作空间迁移完成: 成功 {upload_result['success']}, 失败 {upload_result['failed']}")

                SYLogger.info(f"[Sandbox] 服务切换完成: {old_url} -> {new_url}")
                return True
            else:
                SYLogger.warning(f"[Sandbox] 无其他可用服务实例")
                return False

        except Exception as e:
            SYLogger.error(f"[Sandbox] 刷新 Nacos 服务失败: {e}")
            return False
        finally:
            self._in_failover = False

    def _post_sync_with_failover(self, endpoint: str, data: dict, timeout: int = None) -> dict:
        """带故障转移的同步 POST 请求"""
        actual_timeout = timeout if timeout is not None else self._timeout
        # 执行命令的 HTTP 超时需要更长，给沙箱足够时间执行
        # 只有在非 execute 端点时才加 30 秒缓冲
        if "/execute" in endpoint:
            http_timeout = actual_timeout + 60  # 执行命令给更多缓冲时间
        else:
            http_timeout = actual_timeout + 30
        max_retries = 3

        trace_id = SYLogger.get_trace_id()
        headers = {}
        if trace_id:
            headers["x-traceid-header"] = str(trace_id)

        url = f"{self._base_url}{endpoint}"
        SYLogger.info(f"[Sandbox] POST 请求开始: {url}, timeout={http_timeout}s, command_timeout={actual_timeout}s")

        for attempt in range(max_retries):
            try:
                SYLogger.info(f"[Sandbox] POST 尝试 {attempt + 1}/{max_retries}: {url}")
                resp = requests.post(
                    url,
                    json=data,
                    headers=headers if headers else None,
                    timeout=http_timeout
                )
                SYLogger.info(f"[Sandbox] POST 响应状态码: {resp.status_code}")
                if resp.status_code >= 400:
                    SYLogger.error(f"[Sandbox] HTTP 错误 {resp.status_code}: {resp.text}")
                    resp.raise_for_status()
                result = resp.json()
                SYLogger.info(f"[Sandbox] POST 成功: {url}")
                return result

            except (requests.exceptions.RequestException, requests.exceptions.HTTPError) as e:
                SYLogger.warning(f"[Sandbox] 请求失败 (尝试 {attempt + 1}/{max_retries}): {self._base_url} - {e}")

                if attempt < max_retries - 1:
                    switched = self._refresh_from_nacos_and_switch_sync()
                    if not switched:
                        import time
                        time.sleep(1)
                else:
                    raise RuntimeError(f"沙箱服务不可用: {e}")

        raise RuntimeError("沙箱服务不可用")

    def _post_sync(self, endpoint: str, data: dict, timeout: int = None) -> dict:
        """发送同步 POST 请求（带故障转移）"""
        return self._post_sync_with_failover(endpoint, data, timeout)

    # ============== 内部方法 - 异步版本 ==============

    async def _post_async(self, endpoint: str, data: dict, timeout: int = None) -> dict:
        """异步 POST 请求（每次创建独立 session，避免跨 Task 共享导致超时上下文错误）"""
        actual_timeout = timeout if timeout is not None else self._timeout
        if "/execute" in endpoint:
            http_timeout = actual_timeout + 60
        else:
            http_timeout = actual_timeout + 30

        trace_id = SYLogger.get_trace_id()
        headers = {"Content-Type": "application/json"}
        if trace_id:
            headers["x-traceid-header"] = str(trace_id)

        url = f"{self._base_url}{endpoint}"
        SYLogger.info(f"[Sandbox] Async POST 请求开始: {url}, timeout={http_timeout}s")

        timeout_obj = aiohttp.ClientTimeout(total=http_timeout)
        connector = aiohttp.TCPConnector(ssl=_SSL_CONTEXT)
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.post(url, json=data, headers=headers, timeout=timeout_obj) as resp:
                SYLogger.info(f"[Sandbox] Async POST 响应状态码: {resp.status}")
                if resp.status >= 400:
                    text = await resp.text()
                    SYLogger.error(f"[Sandbox] HTTP 错误 {resp.status}: {text}")
                    resp.raise_for_status()
                result = await resp.json()
                SYLogger.info(f"[Sandbox] Async POST 成功: {url}")
                return result

    async def _post_async_with_failover(self, endpoint: str, data: dict, timeout: int = None) -> dict:
        """带故障转移的异步 POST 请求"""
        max_retries = 3

        for attempt in range(max_retries):
            try:
                return await self._post_async(endpoint, data, timeout)
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                SYLogger.warning(f"[Sandbox] Async 请求失败 (尝试 {attempt + 1}/{max_retries}): {self._base_url} - {e}")

                if attempt < max_retries - 1:
                    # 尝试故障转移
                    switched = await asyncio.to_thread(self._refresh_from_nacos_and_switch_sync)
                    if not switched:
                        await asyncio.sleep(1)
                else:
                    raise RuntimeError(f"沙箱服务不可用: {e}")

        raise RuntimeError("沙箱服务不可用")

    # ============== 属性 ==============

    @property
    def id(self) -> str:
        """沙箱 ID"""
        return self._id

    @property
    def base_url(self) -> str:
        """服务基础 URL"""
        return self._base_url

    @property
    def user_id(self) -> str:
        """用户ID"""
        return self._user_id

    # 沙箱容器内用户数据的实际根目录，通过 health 接口从沙箱服务端动态获取。
    # 初始化为 None，首次执行命令时通过 _resolve_workspace_root() 延迟获取。
    _workspace_root: Optional[str] = None

    def _resolve_workspace_root(self) -> str:
        """同步获取沙箱服务端的 WORKSPACE_BASE，并缓存到实例"""
        if self._workspace_root is not None:
            return self._workspace_root

        # 优先使用环境变量覆盖
        env_workspace = os.environ.get("SANDBOX_WORKSPACE")
        if env_workspace:
            self._workspace_root = env_workspace
            SYLogger.info(f"[Sandbox] 使用环境变量 SANDBOX_WORKSPACE={env_workspace}")
            return self._workspace_root

        # 从沙箱服务端 health 接口获取
        try:
            url = f"{self._base_url}{SANDBOX_API_PREFIX}/health"
            resp = requests.get(url, timeout=10)
            if resp.status_code == 200:
                workspace = resp.json().get("workspace", "")
                if workspace:
                    self._workspace_root = workspace
                    SYLogger.info(f"[Sandbox] 从沙箱服务端获取 WORKSPACE_ROOT={workspace}")
                    return self._workspace_root
        except Exception as e:
            SYLogger.warning(f"[Sandbox] 获取沙箱 workspace 失败: {e}")

        # 兜底：根据平台猜测
        self._workspace_root = "/data/sycommon_sandbox" if sys.platform != "darwin" and sys.platform != "win32" else os.path.join(tempfile.gettempdir(), "sycommon_sandbox")
        SYLogger.warning(f"[Sandbox] 无法获取沙箱 workspace，使用兜底值: {self._workspace_root}")
        return self._workspace_root

    async def _aresolve_workspace_root(self) -> str:
        """异步获取沙箱服务端的 WORKSPACE_BASE，并缓存到实例"""
        if self._workspace_root is not None:
            return self._workspace_root

        # 优先使用环境变量覆盖
        env_workspace = os.environ.get("SANDBOX_WORKSPACE")
        if env_workspace:
            self._workspace_root = env_workspace
            SYLogger.info(f"[Sandbox] 使用环境变量 SANDBOX_WORKSPACE={env_workspace}")
            return self._workspace_root

        # 从沙箱服务端 health 接口获取（aiohttp 异步）
        try:
            url = f"{self._base_url}{SANDBOX_API_PREFIX}/health"
            connector = aiohttp.TCPConnector(ssl=_SSL_CONTEXT)
            timeout_obj = aiohttp.ClientTimeout(total=10)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(url, timeout=timeout_obj) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        workspace = data.get("workspace", "")
                        if workspace:
                            self._workspace_root = workspace
                            SYLogger.info(f"[Sandbox] 从沙箱服务端获取 WORKSPACE_ROOT={workspace}")
                            return self._workspace_root
        except Exception as e:
            SYLogger.warning(f"[Sandbox] 异步获取沙箱 workspace 失败: {e}")

        # 兜底
        self._workspace_root = "/data/sycommon_sandbox" if sys.platform != "darwin" and sys.platform != "win32" else os.path.join(tempfile.gettempdir(), "sycommon_sandbox")
        SYLogger.warning(f"[Sandbox] 无法获取沙箱 workspace，使用兜底值: {self._workspace_root}")
        return self._workspace_root

    # ============== 执行命令 ==============

    def execute(self, command: str, *, timeout: int = None) -> ExecuteResponse:
        """执行 shell 命令（服务端负责路径隔离和目录初始化）"""
        SYLogger.info(f"[Sandbox] execute 开始: command={command}")
        self._ensure_synced_sync()
        SYLogger.info(f"[Sandbox] _ensure_synced_sync 完成，开始执行命令: {command}")
        try:
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/execute", {
                "command": command.strip(),
                "user_id": self._user_id,
                "timeout": timeout if timeout is not None else self._timeout
            }, timeout=timeout if timeout is not None else self._timeout)
            response = ExecuteResponse(
                output=result["output"],
                exit_code=result["exit_code"],
                truncated=result.get("truncated", False)
            )
            SYLogger.info(f"[Sandbox] 执行完成: exit_code={response.exit_code}, output={response.output[:500] if response.output else 'None'}...")
            return response
        except Exception as e:
            SYLogger.error(f"[Sandbox] 执行异常: {e}")
            return ExecuteResponse(
                output=f"Error: {type(e).__name__}: {e}",
                exit_code=1,
                truncated=False
            )

    async def aexecute(self, command: str, *, timeout: int = None) -> ExecuteResponse:
        """异步执行 shell 命令（服务端负责路径隔离和目录初始化）"""
        SYLogger.info(f"[Sandbox] aexecute 开始: command={command}")
        await self._ensure_synced_async()
        SYLogger.info(f"[Sandbox] _ensure_synced_async 完成，开始执行命令: {command}")
        try:
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/execute", {
                "command": command.strip(),
                "user_id": self._user_id,
                "timeout": timeout if timeout is not None else self._timeout
            }, timeout=timeout if timeout is not None else self._timeout)
            response = ExecuteResponse(
                output=result["output"],
                exit_code=result["exit_code"],
                truncated=result.get("truncated", False)
            )
            SYLogger.info(f"[Sandbox] 异步执行完成: exit_code={response.exit_code}")
            return response
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步执行异常: {e}")
            return ExecuteResponse(
                output=f"Error: {type(e).__name__}: {e}",
                exit_code=1,
                truncated=False
            )

    async def _sync_async(self, *, timeout: int = None) -> dict:
        """同步目录（异步版本）

        sync_dirs 条目支持两种格式:
            (local_path, remote_path)               -> 全量覆盖
            (local_path, remote_path, mode)          -> mode="full" 全量覆盖, mode="partial" 跳过已有子目录
        """
        if not self._sync_dirs:
            SYLogger.info("[Sandbox] 没有配置同步目录")
            return {}

        SYLogger.info(f"[Sandbox] _sync_async 开始, 共 {len(self._sync_dirs)} 个目录")
        results = {}
        for idx, entry in enumerate(self._sync_dirs):
            local_path, remote_path = entry[0], entry[1]
            mode = entry[2] if len(entry) > 2 else "full"
            SYLogger.info(f"[Sandbox] 同步目录 [{idx+1}/{len(self._sync_dirs)}]: {local_path} -> {remote_path} (mode={mode})")
            local_dir = Path(local_path)

            def _check_path(ld=local_dir):
                return ld.exists(), ld.is_dir()

            exists, is_dir = await asyncio.to_thread(_check_path)
            if not exists:
                SYLogger.error(f"[Sandbox] 本地目录不存在: {local_path}")
                results[local_path] = {"success": 0, "failed": 0, "errors": [{"error": "目录不存在"}]}
                continue

            if is_dir:
                SYLogger.info(f"[Sandbox] 开始上传目录: {local_path}")
                result = await self._upload_directory_async(str(local_dir), remote_path, mode=mode, timeout=timeout)
                results[local_path] = result
                SYLogger.info(f"[Sandbox] 目录上传完成: {local_path}, 成功={result['success']}, 失败={result['failed']}")
            else:
                # 单文件
                SYLogger.info(f"[Sandbox] 上传单文件: {local_path}")
                content = await asyncio.to_thread(lambda: open(local_dir, "rb").read())
                upload_results = await self.aupload_files([(remote_path, content)], timeout=timeout)
                if upload_results[0].error:
                    results[local_path] = {"success": 0, "failed": 1, "errors": [{"path": remote_path, "error": upload_results[0].error}]}
                else:
                    results[local_path] = {"success": 1, "failed": 0, "errors": []}

        self._synced = True
        SYLogger.info("[Sandbox] _sync_async 完成")
        return results

    async def _upload_directory_async(self, local_dir: str, remote_path: str = "/", *, mode: str = "full", timeout: int = None) -> dict:
        """上传整个目录到沙箱（异步版本）

        Args:
            local_dir: 本地目录路径
            remote_path: 沙箱目标路径
            mode: 同步模式
                - "full": 全量覆盖（默认），上传所有文件
                - "partial": 部分覆盖，查询沙箱已有子目录并跳过同名目录
        """
        local_path = Path(local_dir)

        def _check():
            if not local_path.exists():
                raise FileNotFoundError(f"本地目录不存在: {local_dir}")
            if not local_path.is_dir():
                raise NotADirectoryError(f"路径不是目录: {local_dir}")

        await asyncio.to_thread(_check)

        SYLogger.info(f"[Sandbox] _upload_directory_async 开始: {local_dir} -> {remote_path} (mode={mode})")

        # partial 模式：查询沙箱已有子目录并跳过
        existing_subdirs = set()
        if mode == "partial":
            try:
                ls_result = await self._post_async(f"{SANDBOX_API_PREFIX}/ls", {
                    "path": remote_path,
                    "user_id": self._user_id
                }, timeout=timeout)
                if ls_result and not ls_result.get("error"):
                    for item in ls_result.get("files", ls_result.get("children", [])):
                        if item.get("is_dir", False):
                            existing_subdirs.add(item.get("name", ""))
                    if existing_subdirs:
                        SYLogger.info(f"[Sandbox] partial 模式，跳过已有子目录: {existing_subdirs}")
            except Exception as e:
                SYLogger.warning(f"[Sandbox] 查询沙箱目录失败，将全量同步: {e}")

        exclude_patterns = [".git", "__pycache__", ".pyc", ".DS_Store", "node_modules"]

        def should_exclude(name: str) -> bool:
            for pattern in exclude_patterns:
                if pattern.startswith("*"):
                    if name.endswith(pattern[1:]):
                        return True
                elif name == pattern:
                    return True
            return False

        def _collect_files():
            """在线程中收集需要上传的文件列表"""
            result = []
            for root, dirs, files in os.walk(local_path):
                dirs[:] = [d for d in dirs if not should_exclude(d)]

                if existing_subdirs:
                    try:
                        rel = Path(root).relative_to(local_path)
                        if str(rel) == ".":
                            dirs[:] = [d for d in dirs if d not in existing_subdirs]
                    except ValueError:
                        pass

                for file in files:
                    if should_exclude(file):
                        continue

                    local_file = Path(root) / file
                    relative_path = local_file.relative_to(local_path)
                    sandbox_path = str(Path(remote_path) / relative_path)
                    result.append((sandbox_path, local_file))
            return result

        files_to_upload = await asyncio.to_thread(_collect_files)

        SYLogger.info(f"[Sandbox] 准备上传 {len(files_to_upload)} 个文件到沙箱")

        BATCH_SIZE = 20

        def _read_file(local_file):
            with open(local_file, "rb") as f:
                return f.read()

        all_results = []
        total = len(files_to_upload)
        for batch_start in range(0, total, BATCH_SIZE):
            batch_files = files_to_upload[batch_start:batch_start + BATCH_SIZE]
            SYLogger.info(f"[Sandbox] 批量上传进度: {batch_start}/{total}")

            def _read_batch():
                items = []
                for sandbox_path, local_file in batch_files:
                    content = open(local_file, "rb").read()
                    items.append((sandbox_path, content))
                return items
            batch_items = await asyncio.to_thread(_read_batch)

            upload_results = await self.aupload_files(batch_items, timeout=timeout)
            for r in upload_results:
                if r.error:
                    all_results.append({"ok": False, "path": r.path, "error": r.error})
                else:
                    all_results.append({"ok": True})

        success_count = sum(1 for r in all_results if r["ok"])
        failed_count = sum(1 for r in all_results if not r["ok"])
        errors = [{"path": r["path"], "error": r["error"]} for r in all_results if not r["ok"]]

        SYLogger.info(f"[Sandbox] _upload_directory_async 完成: 成功={success_count}, 失败={failed_count}")
        return {"success": success_count, "failed": failed_count, "errors": errors}

    # ============== 后台进程执行 ==============

    def execute_background(self, command: str, *, timeout: int = 600) -> dict:
        """后台执行 shell 命令（不阻塞，立即返回 process_id）"""
        self._ensure_synced_sync()
        SYLogger.info(f"[Sandbox] 后台执行: {command}")
        try:
            result = self._post_sync(f"{SANDBOX_API_PREFIX}/execute_background", {
                "command": command.strip(),
                "user_id": self._user_id,
                "timeout": timeout
            })
            SYLogger.info(f"[Sandbox] 后台进程已启动: process_id={result['process_id']}")
            return result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 后台执行失败: {e}")
            return {"process_id": None, "status": "error", "error": str(e)}

    async def aexecute_stream(self, command: str, *, timeout: int = None):
        """异步流式执行 shell 命令，yield SSE 事件字典

        每个 yield 的格式: {"type": "output"|"done"|"error", "data": ..., "exit_code": ...}
        """
        await self._ensure_synced_async()
        actual_timeout = timeout if timeout is not None else self._timeout
        url = f"{self._base_url}{SANDBOX_API_PREFIX}/execute_stream"
        timeout_obj = aiohttp.ClientTimeout(total=actual_timeout + 60)
        connector = aiohttp.TCPConnector(ssl=_SSL_CONTEXT)
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.post(url, json={
                "command": command.strip(),
                "user_id": self._user_id,
                "timeout": actual_timeout
            }, timeout=timeout_obj) as resp:
                resp.raise_for_status()
                buffer = ""
                async for chunk in resp.content.iter_any():
                    buffer += chunk.decode('utf-8', errors='replace')
                    while "\n\n" in buffer:
                        event_str, buffer = buffer.split("\n\n", 1)
                        for line in event_str.strip().split("\n"):
                            if line.startswith("data: "):
                                import json
                                yield json.loads(line[6:])

    async def aexecute_background(self, command: str, *, timeout: int = None) -> dict:
        """异步后台执行 shell 命令（服务端负责路径隔离）"""
        await self._ensure_synced_async()
        actual_timeout = timeout if timeout is not None else 600
        SYLogger.info(f"[Sandbox] 异步后台执行: {command}")
        try:
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/execute_background", {
                "command": command.strip(),
                "user_id": self._user_id,
                "timeout": actual_timeout
            }, timeout=actual_timeout)
            SYLogger.info(f"[Sandbox] 异步后台进程已启动: process_id={result['process_id']}")
            return result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步后台执行失败: {e}")
            return {"process_id": None, "status": "error", "error": str(e)}

    async def acheck_process(self, process_id: str, *, timeout: int = None) -> dict:
        """异步检查后台进程状态"""
        try:
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/process_status", {
                "process_id": process_id,
                "user_id": self._user_id
            }, timeout=timeout)
            return result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步检查进程失败: {e}")
            return {"process_id": process_id, "status": "error", "error": str(e)}

    async def akill_process(self, process_id: str, *, timeout: int = None) -> dict:
        """异步终止后台进程"""
        try:
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/kill_process", {
                "process_id": process_id,
                "user_id": self._user_id
            }, timeout=timeout)
            SYLogger.info(f"[Sandbox] 异步进程终止: {process_id}, status={result['status']}")
            return result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步终止进程失败: {e}")
            return {"process_id": process_id, "status": "error", "error": str(e)}

    async def akill_all_processes(self, *, timeout: int = None) -> dict:
        """异步终止该用户的所有后台进程"""
        try:
            result = await self._post_async_with_failover(
                f"{SANDBOX_API_PREFIX}/kill_all_processes",
                {"user_id": self._user_id},
                timeout=timeout,
            )
            SYLogger.info(
                f"[Sandbox] 批量终止进程: "
                f"killed={result.get('killed_count', 0)}, "
                f"already_completed={result.get('already_completed', 0)}"
            )
            return result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 批量终止进程失败: {e}")
            return {"killed_count": 0, "error": str(e)}

    # ============== 端口转发 ==============

    async def aport_forward(self, port: int, action: str = "list", *, timeout: int = None) -> dict:
        """异步端口转发管理"""
        return await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/port_forward", {
            "port": port,
            "user_id": self._user_id,
            "action": action,
        }, timeout=timeout)

    async def awatch(self, path: str = "/", event_types: list = None, *, timeout: int = None) -> dict:
        """异步查询文件变更"""
        return await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/watch", {
            "path": path,
            "user_id": self._user_id,
            "event_types": event_types,
        }, timeout=timeout)

    # ============== 批量操作 ==============

    def upload_files(self, files: List[tuple[str, bytes]]) -> List[FileUploadResponse]:
        """上传多个文件"""
        results = []
        for path, content in files:
            try:
                result = self._post_sync(f"{SANDBOX_API_PREFIX}/upload", {
                    "path": path,
                    "content": base64.b64encode(content).decode(),
                    "user_id": self._user_id
                })
                results.append(FileUploadResponse(
                    path=result["path"],
                    error=result.get("error")
                ))
            except Exception as e:
                results.append(FileUploadResponse(path=path, error=str(e)))
        return results

    async def aupload_files(self, files: List[tuple[str, bytes]], *, timeout: int = None) -> List[FileUploadResponse]:
        """异步上传多个文件（真正的异步实现，使用 /batch_upload）"""
        if not files:
            return []
        batch = [
            {"path": path, "content": base64.b64encode(content).decode()}
            for path, content in files
        ]
        try:
            result = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/batch_upload", {
                "files": batch,
                "user_id": self._user_id
            }, timeout=timeout)
            return [
                FileUploadResponse(path=r.get("path", ""), error=r.get("error"))
                for r in result.get("results", [])
            ]
        except Exception as e:
            SYLogger.error(f"[Sandbox] 批量上传失败，降级逐个上传: {e}")
            results = []
            for path, content in files:
                try:
                    r = await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/upload", {
                        "path": path,
                        "content": base64.b64encode(content).decode(),
                        "user_id": self._user_id
                    }, timeout=timeout)
                    results.append(FileUploadResponse(path=r["path"], error=r.get("error")))
                except Exception as ex:
                    results.append(FileUploadResponse(path=path, error=str(ex)))
            return results

    def download_files(self, paths: List[str]) -> List[FileDownloadResponse]:
        """下载多个文件"""
        results = []
        for path in paths:
            try:
                result = self._post_sync(
                    f"{SANDBOX_API_PREFIX}/download",
                    {"path": path, "user_id": self._user_id}
                )
                if result.get("error"):
                    results.append(FileDownloadResponse(
                        path=path,
                        error=result["error"]
                    ))
                else:
                    content = base64.b64decode(result["content"])
                    results.append(FileDownloadResponse(path=path, content=content))
            except Exception as e:
                results.append(FileDownloadResponse(path=path, error=str(e)))
        return results

    async def adownload_files(self, paths: List[str], *, timeout: int = None) -> List[FileDownloadResponse]:
        """异步下载多个文件（真正的异步实现）"""
        results = []
        for path in paths:
            try:
                result = await self._post_async_with_failover(
                    f"{SANDBOX_API_PREFIX}/download",
                    {"path": path, "user_id": self._user_id},
                    timeout=timeout
                )
                if result.get("error"):
                    results.append(FileDownloadResponse(
                        path=path,
                        error=result["error"]
                    ))
                else:
                    content = base64.b64decode(result["content"])
                    results.append(FileDownloadResponse(path=path, content=content))
            except Exception as e:
                results.append(FileDownloadResponse(path=path, error=str(e)))
        return results

    # ============== 目录同步 ==============

    def _sync_sync(self) -> dict:
        """同步目录（同步版本）"""
        if not self._sync_dirs:
            SYLogger.info("[Sandbox] 没有配置同步目录")
            return {}

        SYLogger.info(f"[Sandbox] _sync_sync 开始, 共 {len(self._sync_dirs)} 个目录")
        results = {}
        for idx, entry in enumerate(self._sync_dirs):
            local_path, remote_path = entry[0], entry[1]
            mode = entry[2] if len(entry) > 2 else "full"
            SYLogger.info(f"[Sandbox] 同步目录 [{idx+1}/{len(self._sync_dirs)}]: {local_path} -> {remote_path} (mode={mode})")
            local_dir = Path(local_path)

            if not local_dir.exists():
                SYLogger.error(f"[Sandbox] 本地目录不存在: {local_path}")
                results[local_path] = {"success": 0, "failed": 0, "errors": [{"error": "目录不存在"}]}
                continue

            if local_dir.is_dir():
                SYLogger.info(f"[Sandbox] 开始上传目录: {local_path}")
                result = self._upload_directory_sync(str(local_dir), remote_path, mode=mode)
                results[local_path] = result
                SYLogger.info(f"[Sandbox] 目录上传完成: {local_path}, 成功={result['success']}, 失败={result['failed']}")
            else:
                # 单文件
                SYLogger.info(f"[Sandbox] 上传单文件: {local_path}")
                with open(local_dir, "rb") as f:
                    content = f.read()
                upload_results = self.upload_files([(remote_path, content)])
                if upload_results[0].error:
                    results[local_path] = {"success": 0, "failed": 1, "errors": [{"path": remote_path, "error": upload_results[0].error}]}
                else:
                    results[local_path] = {"success": 1, "failed": 0, "errors": []}

        self._synced = True
        SYLogger.info("[Sandbox] _sync_sync 完成")
        return results

    def sync(self) -> dict:
        """手动同步所有配置的目录到沙箱

        Returns:
            dict: 每个目录的同步结果 {"local_path": {"success": x, "failed": y, "errors": [...]}}
        """
        return self._sync_sync()

    async def async_sync(self, *, timeout: int = None) -> dict:
        """异步手动同步所有配置的目录到沙箱"""
        return await self._sync_async(timeout=timeout)

    def sync_dirs(self, dirs: List[tuple[str, str]]) -> dict:
        """同步指定的目录列表到沙箱

        Args:
            dirs: 要同步的目录列表 [(本地路径, 沙箱路径), ...]

        Returns:
            dict: 每个目录的同步结果 {"local_path": {"success": x, "failed": y, "errors": [...]}}
        """
        if not dirs:
            SYLogger.info("[Sandbox] sync_dirs: 没有指定同步目录")
            return {}

        SYLogger.info(f"[Sandbox] sync_dirs 开始, 共 {len(dirs)} 个目录")
        results = {}
        for idx, (local_path, remote_path) in enumerate(dirs):
            SYLogger.info(f"[Sandbox] 同步目录 [{idx+1}/{len(dirs)}]: {local_path} -> {remote_path}")
            local_dir = Path(local_path)

            if not local_dir.exists():
                SYLogger.warning(f"[Sandbox] 本地目录不存在: {local_path}")
                results[local_path] = {"success": 0, "failed": 0, "errors": [{"error": "目录不存在"}]}
                continue

            if local_dir.is_dir():
                SYLogger.info(f"[Sandbox] 开始上传目录: {local_path}")
                result = self._upload_directory_sync(str(local_dir), remote_path)
                results[local_path] = result
                SYLogger.info(f"[Sandbox] 目录上传完成: {local_path}, 成功={result['success']}, 失败={result['failed']}")
            else:
                # 单文件
                SYLogger.info(f"[Sandbox] 上传单文件: {local_path}")
                with open(local_dir, "rb") as f:
                    content = f.read()
                upload_results = self.upload_files([(remote_path, content)])
                if upload_results[0].error:
                    results[local_path] = {"success": 0, "failed": 1, "errors": [{"path": remote_path, "error": upload_results[0].error}]}
                else:
                    results[local_path] = {"success": 1, "failed": 0, "errors": []}

        SYLogger.info("[Sandbox] sync_dirs 完成")
        return results

    async def async_sync_dirs(self, dirs: List[tuple[str, str]], *, timeout: int = None) -> dict:
        """异步同步指定的目录列表到沙箱（真正的异步实现）

        Args:
            dirs: 要同步的目录列表 [(本地路径, 沙箱路径), ...]

        Returns:
            dict: 每个目录的同步结果 {"local_path": {"success": x, "failed": y, "errors": [...]}}
        """
        if not dirs:
            SYLogger.info("[Sandbox] async_sync_dirs: 没有指定同步目录")
            return {}

        SYLogger.info(f"[Sandbox] async_sync_dirs 开始, 共 {len(dirs)} 个目录")
        results = {}
        for idx, (local_path, remote_path) in enumerate(dirs):
            SYLogger.info(f"[Sandbox] 异步同步目录 [{idx+1}/{len(dirs)}]: {local_path} -> {remote_path}")
            local_dir = Path(local_path)

            def _check_path(ld=local_dir):
                return ld.exists(), ld.is_dir()

            exists, is_dir = await asyncio.to_thread(_check_path)
            if not exists:
                SYLogger.warning(f"[Sandbox] 本地目录不存在: {local_path}")
                results[local_path] = {"success": 0, "failed": 0, "errors": [{"error": "目录不存在"}]}
                continue

            if is_dir:
                SYLogger.info(f"[Sandbox] 开始异步上传目录: {local_path}")
                result = await self._upload_directory_async(str(local_dir), remote_path, timeout=timeout)
                results[local_path] = result
                SYLogger.info(f"[Sandbox] 异步目录上传完成: {local_path}, 成功={result['success']}, 失败={result['failed']}")
            else:
                SYLogger.info(f"[Sandbox] 异步上传单文件: {local_path}")
                content = await asyncio.to_thread(lambda: open(local_dir, "rb").read())
                upload_results = await self.aupload_files([(remote_path, content)], timeout=timeout)
                if upload_results[0].error:
                    results[local_path] = {"success": 0, "failed": 1, "errors": [{"path": remote_path, "error": upload_results[0].error}]}
                else:
                    results[local_path] = {"success": 1, "failed": 0, "errors": []}

        SYLogger.info("[Sandbox] async_sync_dirs 完成")
        return results

    def _upload_directory_sync(self, local_dir: str, remote_path: str = "/", *, mode: str = "full") -> dict:
        """上传整个目录到沙箱（同步版本，使用 ThreadPoolExecutor 并发）

        Args:
            local_dir: 本地目录路径
            remote_path: 沙箱目标路径
            mode: 同步模式
                - "full": 全量覆盖（默认），上传所有文件
                - "partial": 部分覆盖，查询沙箱已有子目录并跳过同名目录

        Returns:
            dict: {"success": int, "failed": int, "errors": list}
        """
        local_path = Path(local_dir)
        if not local_path.exists():
            raise FileNotFoundError(f"本地目录不存在: {local_dir}")

        if not local_path.is_dir():
            raise NotADirectoryError(f"路径不是目录: {local_dir}")

        SYLogger.info(f"[Sandbox] _upload_directory_sync 开始: {local_dir} -> {remote_path} (mode={mode})")

        # partial 模式：查询沙箱已有子目录并跳过
        existing_subdirs = set()
        if mode == "partial":
            try:
                ls_result = self._post_sync(f"{SANDBOX_API_PREFIX}/ls", {
                    "path": remote_path,
                    "user_id": self._user_id
                })
                if ls_result and not ls_result.get("error"):
                    for item in ls_result.get("files", ls_result.get("children", [])):
                        if item.get("is_dir", False):
                            existing_subdirs.add(item.get("name", ""))
                    if existing_subdirs:
                        SYLogger.info(f"[Sandbox] partial 模式，跳过已有子目录: {existing_subdirs}")
            except Exception as e:
                SYLogger.warning(f"[Sandbox] 查询沙箱目录失败，将全量同步: {e}")

        exclude_patterns = [".git", "__pycache__", ".pyc", ".DS_Store", "node_modules"]

        def should_exclude(name: str) -> bool:
            for pattern in exclude_patterns:
                if pattern.startswith("*"):
                    if name.endswith(pattern[1:]):
                        return True
                elif name == pattern:
                    return True
            return False

        files_to_upload = []

        for root, dirs, files in os.walk(local_path):
            dirs[:] = [d for d in dirs if not should_exclude(d)]

            # partial 模式：跳过沙箱中已存在的子目录（只检查最外层）
            if existing_subdirs:
                try:
                    rel = Path(root).relative_to(local_path)
                    if str(rel) == ".":
                        skipped_names = [d for d in dirs if d in existing_subdirs]
                        dirs[:] = [d for d in dirs if d not in existing_subdirs]
                        if skipped_names:
                            SYLogger.info(f"[Sandbox] 跳过已有目录: {skipped_names}")
                except ValueError:
                    pass

            for file in files:
                if should_exclude(file):
                    continue

                local_file = Path(root) / file
                relative_path = local_file.relative_to(local_path)
                sandbox_path = str(Path(remote_path) / relative_path)
                files_to_upload.append((sandbox_path, local_file))

        SYLogger.info(f"[Sandbox] 准备上传 {len(files_to_upload)} 个文件到沙箱")

        from concurrent.futures import ThreadPoolExecutor, as_completed

        success_count = 0
        failed_count = 0
        errors = []
        lock = threading.Lock()

        def _upload_one(idx, sandbox_path, local_file):
            nonlocal success_count, failed_count
            if idx % 10 == 0:
                SYLogger.info(f"[Sandbox] 上传进度: {idx}/{len(files_to_upload)}")
            try:
                with open(local_file, "rb") as f:
                    content = f.read()
                result = self._post_sync(f"{SANDBOX_API_PREFIX}/upload", {
                    "path": sandbox_path,
                    "content": base64.b64encode(content).decode(),
                    "user_id": self._user_id
                })
                if result.get("error"):
                    with lock:
                        failed_count += 1
                        errors.append({"path": sandbox_path, "error": result["error"]})
                else:
                    with lock:
                        success_count += 1
            except Exception as e:
                with lock:
                    failed_count += 1
                    errors.append({"path": sandbox_path, "error": str(e)})

        max_workers = min(8, len(files_to_upload)) if files_to_upload else 1
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [
                executor.submit(_upload_one, idx, sandbox_path, local_file)
                for idx, (sandbox_path, local_file) in enumerate(files_to_upload)
            ]
            for future in as_completed(futures):
                future.result()  # propagate exceptions

        SYLogger.info(f"[Sandbox] _upload_directory_sync 完成: 成功={success_count}, 失败={failed_count}")
        return {"success": success_count, "failed": failed_count, "errors": errors}

    def _sync_workspace_sync(self) -> dict:
        """同步用户工作空间的所有文件（同步版本）"""
        try:
            files_info = self._post_sync(
                f"{SANDBOX_API_PREFIX}/list",
                {"path": "/", "user_id": self._user_id}
            )
            if files_info.get("error"):
                return {"success": 0, "failed": 0, "errors": [files_info["error"]]}
        except Exception as e:
            return {"success": 0, "failed": 0, "errors": [str(e)]}

        if not files_info.get("files"):
            return {"success": 0, "failed": 0, "errors": []}

        files_to_sync = []
        success_count = 0
        failed_count = 0
        errors = []

        for file_info in files_info["files"]:
            if file_info.get("is_dir"):
                continue
            file_path = file_info["path"]
            try:
                download_result = self._post_sync(
                    f"{SANDBOX_API_PREFIX}/download",
                    {"path": file_path, "user_id": self._user_id}
                )
                if download_result.get("error"):
                    failed_count += 1
                    errors.append({"path": file_path, "error": download_result["error"]})
                else:
                    content = base64.b64decode(download_result["content"])
                    files_to_sync.append((file_path, content))
                    success_count += 1
            except Exception as e:
                failed_count += 1
                errors.append({"path": file_path, "error": str(e)})

        return {
            "success": success_count,
            "failed": failed_count,
            "errors": errors,
            "files": files_to_sync
        }

    def _upload_workspace_files_sync(self, files: List[tuple[str, bytes]]) -> dict:
        """上传工作空间文件（同步版本）"""
        success_count = 0
        failed_count = 0
        errors = []

        for path, content in files:
            try:
                result = self._post_sync(f"{SANDBOX_API_PREFIX}/upload", {
                    "path": path,
                    "content": base64.b64encode(content).decode(),
                    "user_id": self._user_id
                })
                if result.get("error"):
                    failed_count += 1
                    errors.append({"path": path, "error": result["error"]})
                else:
                    success_count += 1
            except Exception as e:
                failed_count += 1
                errors.append({"path": path, "error": str(e)})

        return {"success": success_count, "failed": failed_count, "errors": errors}

    # ============== 管理操作 ==============

    def reset(self) -> dict:
        """重置沙箱环境"""
        return self._post_sync(f"{SANDBOX_API_PREFIX}/reset", {"user_id": self._user_id})

    async def areset(self, *, timeout: int = None) -> dict:
        """异步重置沙箱环境"""
        return await self._post_async_with_failover(f"{SANDBOX_API_PREFIX}/reset", {"user_id": self._user_id}, timeout=timeout)

    def health_check(self, timeout: int = 10) -> dict:
        """健康检查（快速检查，默认10秒超时）"""
        trace_id = SYLogger.get_trace_id()
        headers = {}
        if trace_id:
            headers["x-traceid-header"] = str(trace_id)

        url = f"{self._base_url}{SANDBOX_API_PREFIX}/health"
        SYLogger.info(f"[Sandbox] 健康检查: {url}, timeout={timeout}s")
        try:
            resp = requests.get(
                url,
                headers=headers if headers else None,
                timeout=timeout
            )
            resp.raise_for_status()
            result = resp.json()
            SYLogger.info(f"[Sandbox] 健康检查成功: {result}")
            return result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 健康检查失败: {e}")
            raise

    async def ahealth_check(self, timeout: int = 10) -> dict:
        """异步健康检查"""
        try:
            url = f"{self._base_url}{SANDBOX_API_PREFIX}/health"
            timeout_obj = aiohttp.ClientTimeout(total=timeout)
            connector = aiohttp.TCPConnector(ssl=_SSL_CONTEXT)
            async with aiohttp.ClientSession(connector=connector) as session:
                async with session.get(url, timeout=timeout_obj) as resp:
                    resp.raise_for_status()
                    result = await resp.json()
                    SYLogger.info(f"[Sandbox] 异步健康检查成功: {result}")
                    return result
        except Exception as e:
            SYLogger.error(f"[Sandbox] 异步健康检查失败: {e}")
            raise

    def check_available(self, timeout: int = 5) -> bool:
        """快速检查沙箱是否可用（5秒超时）"""
        try:
            self.health_check(timeout=timeout)
            return True
        except Exception as e:
            SYLogger.warning(f"[Sandbox] 沙箱不可用: {e}")
            return False
