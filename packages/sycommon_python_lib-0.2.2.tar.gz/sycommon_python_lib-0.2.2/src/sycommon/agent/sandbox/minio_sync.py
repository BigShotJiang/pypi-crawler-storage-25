"""MinIO 文件同步服务

将沙箱中的文件自动同步到 MinIO 对象存储。
存储结构：{user_id}/current/{file_path}
    - current 目录保存沙箱全量文件的最新状态
    - 增量同步：只上传新增或修改的文件
    - 下载时直接从 current 目录查找

配置来源（优先 Nacos，其次环境变量）：
    Nacos:     minio.endpoint, minio.accessKey, minio.secretKey, minio.bucket, minio.secure
    环境变量:  MINIO_ENDPOINT, MINIO_ACCESS_KEY, MINIO_SECRET_KEY, MINIO_BUCKET, MINIO_SECURE
"""

import asyncio
import mimetypes
import os
from datetime import datetime, timedelta, timezone
from io import BytesIO
from typing import Optional

from sycommon.config.Config import SingletonMeta
from sycommon.logging.kafka_log import SYLogger

# 日期快照功能预留，当前暂不启用
_SNAPSHOT_ENABLED = False


class MinioSyncService(metaclass=SingletonMeta):
    """MinIO 文件同步服务（单例）"""

    def __init__(self):
        self._client = None
        self._bucket = None
        # None=未初始化, True=已成功, False=配置缺失/初始化失败(不重试)
        self._initialized = None

    @classmethod
    def setup(cls, config: dict = None):
        """初始化 MinIO 客户端（可多次调用，仅首次生效）"""
        instance = cls()
        if instance._initialized is not None:
            return

        cfg = instance._load_config(config)
        if not cfg.get("endpoint"):
            instance._initialized = False
            return

        try:
            from minio import Minio
            instance._client = Minio(
                endpoint=cfg["endpoint"],
                access_key=cfg["access_key"],
                secret_key=cfg["secret_key"],
                secure=cfg["secure"],
            )
            instance._bucket = cfg["bucket"]

            if not instance._client.bucket_exists(instance._bucket):
                instance._client.make_bucket(instance._bucket)
                SYLogger.info(f"[MinIO] Created bucket: {instance._bucket}")

            instance._initialized = True
            SYLogger.info(
                f"[MinIO] Client initialized: {cfg['endpoint']}, bucket={instance._bucket}")
        except Exception as e:
            SYLogger.error(f"[MinIO] Client initialization failed: {e}")
            instance._initialized = False

    def _load_config(self, config: dict = None) -> dict:
        """从 Nacos 配置或环境变量加载 MinIO 配置"""
        if config:
            minio_cfg = config.get("Minio", {})
            if minio_cfg.get("endpoint"):
                return {
                    "endpoint": minio_cfg.get("endpoint", ""),
                    "access_key": minio_cfg.get("accessKey", ""),
                    "secret_key": minio_cfg.get("secretKey", ""),
                    "bucket": minio_cfg.get("bucket", "digital-work-files"),
                    "secure": str(minio_cfg.get("secure", False)).lower() == "true",
                }

        try:
            from sycommon.config.Config import Config
            nacos_cfg = Config().config
            minio_cfg = nacos_cfg.get("Minio", {})
            if minio_cfg.get("endpoint"):
                return {
                    "endpoint": minio_cfg.get("endpoint", ""),
                    "access_key": minio_cfg.get("accessKey", ""),
                    "secret_key": minio_cfg.get("secretKey", ""),
                    "bucket": minio_cfg.get("bucket", "digital-work-files"),
                    "secure": str(minio_cfg.get("secure", False)).lower() == "true",
                }
        except Exception:
            pass

        # 兜底：尝试从 .env 文件加载（项目未显式 load_dotenv 时）
        if not os.environ.get("MINIO_ENDPOINT"):
            try:
                from dotenv import load_dotenv
                load_dotenv()
            except ImportError:
                pass

        return {
            "endpoint": os.environ.get("MINIO_ENDPOINT", ""),
            "access_key": os.environ.get("MINIO_ACCESS_KEY", ""),
            "secret_key": os.environ.get("MINIO_SECRET_KEY", ""),
            "bucket": os.environ.get("MINIO_BUCKET", "digital-work-files"),
            "secure": os.environ.get("MINIO_SECURE", "false").lower() == "true",
        }

    @classmethod
    def is_available(cls) -> bool:
        """检查 MinIO 是否可用"""
        instance = cls()
        if instance._initialized is None:
            cls.setup()
        return instance._client is not None

    @staticmethod
    def make_object_key(user_id: str, date_str: str, file_path: str) -> str:
        """生成 object key: {user_id}/{date_str}/{file_path}"""
        clean_path = file_path.replace("\\", "/").lstrip("./").lstrip("/")
        return f"{user_id.lower()}/{date_str}/{clean_path}"

    def upload_bytes(self, object_key: str, content: bytes,
                     content_type: str = "application/octet-stream") -> bool:
        """同步上传文件到 MinIO"""
        if not self._client:
            return False
        try:
            self._client.put_object(
                bucket_name=self._bucket,
                object_name=object_key,
                data=BytesIO(content),
                length=len(content),
                content_type=content_type,
            )
            SYLogger.info(
                f"[MinIO] Upload success: {object_key}, size={len(content)}")
            return True
        except Exception as e:
            SYLogger.error(f"[MinIO] Upload failed: {object_key}, error={e}")
            return False

    async def aupload_bytes(self, object_key: str, content: bytes,
                            content_type: str = "application/octet-stream") -> bool:
        """异步上传文件到 MinIO"""
        return await asyncio.to_thread(
            self.upload_bytes, object_key, content, content_type
        )

    def stat_object(self, object_key: str):
        """获取 MinIO 对象元信息（含 last_modified），不存在返回 None"""
        if not self._client:
            return None
        try:
            return self._client.stat_object(self._bucket, object_key)
        except Exception:
            return None

    def get_presigned_url(self, object_key: str, expires_days: int = 7) -> Optional[str]:
        """生成预签名下载 URL"""
        if not self._client:
            return None
        try:
            url = self._client.presigned_get_object(
                bucket_name=self._bucket,
                object_name=object_key,
                expires=timedelta(days=expires_days),
            )
            return url
        except Exception as e:
            SYLogger.error(
                f"[MinIO] Presigned URL failed: {object_key}, error={e}")
            return None

    def remove_object(self, object_key: str) -> bool:
        """从 MinIO 删除文件"""
        if not self._client:
            return False
        try:
            self._client.remove_object(self._bucket, object_key)
            SYLogger.info(f"[MinIO] Delete success: {object_key}")
            return True
        except Exception as e:
            SYLogger.warning(f"[MinIO] Delete failed: {object_key}, error={e}")
            return False

    def remove_prefix(self, prefix: str) -> int:
        """删除 MinIO 中指定前缀下的所有对象（用于目录删除）

        Returns:
            删除的对象数量
        """
        if not self._client:
            return 0
        try:
            objects = list(self._client.list_objects(
                self._bucket, prefix=prefix, recursive=True))
            for obj in objects:
                self._client.remove_object(self._bucket, obj.object_name)
            count = len(objects)
            if count > 0:
                SYLogger.info(f"[MinIO] Delete prefix success: {prefix}, count={count}")
            return count
        except Exception as e:
            SYLogger.warning(f"[MinIO] Delete prefix failed: {prefix}, error={e}")
            return 0

    # ============== 查找最近副本 ==============

    def find_latest_object_key(self, user_id: str, file_path: str) -> Optional[str]:
        """查找某个文件在 MinIO 中的 object key

        当前存储在 current 目录，直接构造 key。
        启用日期快照后改为按日期倒序查找。

        Returns:
            object_key 或 None
        """
        if not self._client:
            return None

        clean_path = file_path.replace("\\", "/").lstrip("./").lstrip("/")
        key = f"{user_id.lower()}/current/{clean_path}"

        if self.stat_object(key):
            return key

        # 回溯旧日期格式目录（兼容已有数据）
        if _SNAPSHOT_ENABLED:
            return self._find_in_date_dirs(user_id, clean_path)
        return None

    def _find_in_date_dirs(self, user_id: str, clean_path: str) -> Optional[str]:
        """按日期倒序查找文件（启用日期快照后使用）"""
        prefix = f"{user_id.lower()}/"
        try:
            objects = list(self._client.list_objects(
                self._bucket, prefix=prefix, recursive=True))
            candidates = [
                obj.object_name for obj in objects
                if obj.object_name.endswith(f"/{clean_path}")
            ]
            if candidates:
                candidates.sort(reverse=True)
                return candidates[0]
        except Exception as e:
            SYLogger.warning(f"[MinIO] find_latest failed: {e}")
        return None

    async def afinf_latest_object_key(self, user_id: str, file_path: str) -> Optional[str]:
        """异步查找某个文件最近一天的 object key"""
        return await asyncio.to_thread(self.find_latest_object_key, user_id, file_path)

    # ============== 批量扫描同步 ==============

    def collect_sandbox_files(self, tree_result) -> list[str]:
        """从沙箱 tree 结果中收集所有文件路径

        tree 根节点 name 通常是 user_id（如 "osulcode.xiao"），
        收集时跳过根节点，从其 children 开始递归，这样路径不含 user_id 前缀，
        与 astat/adownload_files 的路径语义一致。
        """
        if tree_result.error or not tree_result.tree:
            return []

        root = tree_result.tree
        files = []
        if root.is_dir and root.children:
            for child in root.children:
                self._collect_files_from_node(child, "", files)

        # tree 在文件过多时会插入 "... (truncated, max N files)" 虚拟节点，过滤掉
        files = [f for f in files if "truncated" not in f]
        return files

    def _collect_files_from_node(self, node, prefix: str, files: list):
        """递归收集文件节点"""
        if not node:
            return

        path = f"{prefix}/{node.name}" if prefix else node.name

        if node.is_dir:
            if node.children:
                for child in node.children:
                    self._collect_files_from_node(child, path, files)
        else:
            files.append(path)

    async def sync_sandbox_to_minio(self, sandbox_backend, user_id: str) -> int:
        """扫描沙箱目录，增量同步文件到 MinIO

        存储到 {user_id}/current/ 目录，只上传新增或修改的文件。
        max_files=0 表示不限制，tree 返回全部文件。
        下载/上传采用并发（每批 CONCURRENT_BATCH 个），避免串行太慢。

        Args:
            sandbox_backend: 沙箱后端实例
            user_id: 用户ID

        Returns:
            同步的文件数量
        """
        if not self.is_available():
            return 0

        # 1. 获取沙箱目录树（max_files=0 不限制数量，max_depth=0 不限制深度）
        try:
            tree_result = await sandbox_backend.atree(path="/", max_depth=0, max_files=0)
            # 兼容旧版 sandbox：max_depth=0 或 max_files=0 可能返回空树，改用大数值
            if tree_result.tree and tree_result.tree.is_dir and not tree_result.tree.children:
                tree_result = await sandbox_backend.atree(path="/", max_depth=30, max_files=10000)
        except Exception as e:
            SYLogger.error(f"[MinIO] 获取沙箱目录树失败: {e}")
            return 0

        sandbox_files = self.collect_sandbox_files(tree_result)
        if not sandbox_files:
            return 0

        # 2. 确定存储目录
        if _SNAPSHOT_ENABLED:
            dir_name = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        else:
            dir_name = "current"

        prefix = f"{user_id.lower()}/{dir_name}/"

        # 3. 获取 MinIO 已有副本
        existing_objects = {}
        try:
            objects = await asyncio.to_thread(
                lambda: list(self._client.list_objects(
                    self._bucket, prefix=prefix, recursive=True))
            )
            for obj in objects:
                rel_path = obj.object_name[len(prefix):]
                existing_objects[rel_path] = obj
        except Exception as e:
            SYLogger.warning(f"[MinIO] 列出已有副本失败，将全量上传: {e}")

        # 4. 找出需要同步的文件（新增的不在 MinIO 中）
        changed_files = [
            fp for fp in sandbox_files if fp not in existing_objects]

        if not changed_files:
            SYLogger.info(f"[MinIO] 所有文件均无变化，跳过同步: user={user_id}")
            return 0

        SYLogger.info(
            f"[MinIO] 检测到 {len(changed_files)} 个文件有变化: user={user_id}")

        # 5. 并发下载并上传变化文件
        synced = await self._sync_batch(sandbox_backend, changed_files, existing_objects, prefix)

        SYLogger.info(
            f"[MinIO] 同步完成: user={user_id}, dir={dir_name}, synced={synced}/{len(changed_files)}")
        return synced

    async def _sync_batch(self, sandbox_backend, file_paths: list[str],
                          existing_objects: dict, prefix: str,
                          batch_size: int = 5) -> int:
        """并发下载并上传文件，每批 batch_size 个并发"""
        synced = 0

        for i in range(0, len(file_paths), batch_size):
            batch = file_paths[i:i + batch_size]
            tasks = [
                self._sync_one(sandbox_backend, fp, existing_objects, prefix)
                for fp in batch
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for r in results:
                if r is True:
                    synced += 1

        return synced

    async def _sync_one(self, sandbox_backend, fp: str,
                        existing_objects: dict, prefix: str) -> bool:
        """同步单个文件：下载 + 上传，成功返回 True"""
        try:
            results = await sandbox_backend.adownload_files([f"/{fp}"])
            if not results or results[0].error or not results[0].content:
                error = results[0].error if results else "unknown"
                SYLogger.warning(f"[MinIO] 下载沙箱文件失败: {fp}, error={error}")
                return False

            content = results[0].content

            # 如果 MinIO 已有且 size 相同，跳过
            if fp in existing_objects and existing_objects[fp].size == len(content):
                return False

            mime_type, _ = mimetypes.guess_type(fp)
            object_key = f"{prefix}{fp}"

            return await self.aupload_bytes(
                object_key, content,
                content_type=mime_type or "application/octet-stream",
            )
        except Exception as e:
            SYLogger.warning(f"[MinIO] 同步文件异常: {fp}, error={e}")
            return False

    # ============== 反向同步（MinIO → 沙箱） ==============

    async def restore_from_minio(self, sandbox_backend, user_id: str) -> int:
        """将 MinIO 中的文件恢复到沙箱

        场景：沙箱重启后文件丢失，从 MinIO current 目录恢复。
        只上传沙箱中不存在的文件，不覆盖已有文件。

        Args:
            sandbox_backend: 沙箱后端实例
            user_id: 用户ID

        Returns:
            恢复的文件数量
        """
        if not self._client:
            return 0

        prefix = f"{user_id.lower()}/current/"

        # 1. 列出 MinIO 中所有文件
        try:
            objects = await asyncio.to_thread(
                lambda: list(self._client.list_objects(
                    self._bucket, prefix=prefix, recursive=True))
            )
        except Exception as e:
            SYLogger.error(f"[MinIO] 恢复时列出文件失败: {e}")
            return 0

        if not objects:
            return 0

        # 2. 获取沙箱已有文件
        try:
            tree_result = await sandbox_backend.atree(path="/", max_depth=0, max_files=0)
            if tree_result.tree and tree_result.tree.is_dir and not tree_result.tree.children:
                tree_result = await sandbox_backend.atree(path="/", max_depth=30, max_files=10000)
        except Exception:
            tree_result = None

        existing_files = set()
        if tree_result:
            existing_files = set(self.collect_sandbox_files(tree_result))

        # 3. 找出沙箱中没有的文件
        to_restore = []
        for obj in objects:
            rel_path = obj.object_name[len(prefix):]
            if rel_path and rel_path not in existing_files:
                to_restore.append(rel_path)

        if not to_restore:
            SYLogger.info(f"[MinIO] 沙箱文件完整，无需恢复: user={user_id}")
            return 0

        SYLogger.info(f"[MinIO] 需恢复 {len(to_restore)} 个文件到沙箱: user={user_id}")

        # 4. 批量恢复
        restored = 0
        for i in range(0, len(to_restore), 5):
            batch = to_restore[i:i + 5]
            files_to_upload = []
            for rel_path in batch:
                try:
                    response = await asyncio.to_thread(
                        self._client.get_object, self._bucket, f"{prefix}{rel_path}"
                    )
                    content = response.read()
                    response.close()
                    response.release_conn()
                    files_to_upload.append((f"/{rel_path}", content))
                except Exception as e:
                    SYLogger.warning(f"[MinIO] 下载文件失败: {rel_path}, error={e}")

            if files_to_upload:
                try:
                    results = await sandbox_backend.aupload_files(files_to_upload)
                    for r in results:
                        if not r.error:
                            restored += 1
                        else:
                            SYLogger.warning(
                                f"[MinIO] 上传到沙箱失败: {r.path}, error={r.error}")
                except Exception as e:
                    SYLogger.warning(f"[MinIO] 批量上传到沙箱失败: {e}")

        SYLogger.info(
            f"[MinIO] 恢复完成: user={user_id}, restored={restored}/{len(to_restore)}")
        return restored
