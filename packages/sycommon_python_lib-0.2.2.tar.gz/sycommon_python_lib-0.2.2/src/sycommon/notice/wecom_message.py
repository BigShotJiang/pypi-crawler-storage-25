"""
企微消息发送服务

封装企业微信「应用消息 API」和「智能机器人主动消息」两种通道：
- 应用消息：支持文本、Markdown、图片、文件发送（需要 corpid/corpsecret/agentid）
- 机器人消息：支持 Markdown、模板卡片主动推送（需要注入 WSClient 实例）

使用示例::

    from sycommon.notice import WeComMessageService

    svc = WeComMessageService()

    # 应用消息 - 发送文件
    await svc.send_file(touser="0633", file_path="/tmp/report.xlsx")

    # 应用消息 - 发送 Markdown
    await svc.send_markdown(touser="0633", content="# 通知\\n内容")

    # 机器人主动消息
    from aibot import WSClient, WSClientOptions
    ws = WSClient(WSClientOptions(bot_id="...", secret="..."))
    await ws.connect()
    svc.set_ws_client(ws)
    await svc.send_bot_markdown(chatid="single:user123", content="**Hello**")
"""

import logging
import time
from pathlib import Path
from typing import Any, Dict, Optional

import aiohttp
from pydantic import BaseModel

from sycommon.config.Config import SingletonMeta
from sycommon.logging.kafka_log import SYLogger


class WeComMessageConfig(BaseModel):
    """企微消息服务配置"""

    corpid: str
    corpsecret: str
    agentid: int

    @classmethod
    def from_config(cls) -> "WeComMessageConfig":
        from sycommon.config.Config import Config

        wecom_config = Config().config.get("llm", {}).get("WeCom", {})
        corpid = wecom_config.get("corpid", "")
        corpsecret = wecom_config.get("corpsecret", "")
        agentid = wecom_config.get("agentid")

        if not corpid or not corpsecret:
            raise ValueError(
                "企微配置不完整，请在 llm.WeCom 下配置 corpid 和 corpsecret"
            )
        if agentid is None:
            raise ValueError(
                "企微配置不完整，请在 llm.WeCom 下配置 agentid"
            )

        return cls(corpid=corpid, corpsecret=corpsecret, agentid=int(agentid))


class WeComMessageService(metaclass=SingletonMeta):
    """企微消息发送服务

    同时支持应用消息 API 和机器人主动消息。
    应用消息需要 corpid/corpsecret/agentid 配置。
    机器人消息需要通过 set_ws_client() 注入 WSClient 实例。
    """

    def __init__(self):
        self._config: Optional[WeComMessageConfig] = None
        self._access_token: Optional[str] = None
        self._token_expires_at: float = 0
        self._ws_client: Optional[Any] = None

    def _ensure_config(self) -> WeComMessageConfig:
        if self._config is None:
            self._config = WeComMessageConfig.from_config()
        return self._config

    def set_ws_client(self, client: Any) -> None:
        """设置外部管理的 WSClient 实例（用于机器人主动消息）"""
        self._ws_client = client

    # ─── Token 管理 ───

    async def _get_access_token(self) -> str:
        if self._access_token and time.time() < self._token_expires_at:
            return self._access_token

        config = self._ensure_config()
        url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken"
        params = {
            "corpid": config.corpid,
            "corpsecret": config.corpsecret,
        }

        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as resp:
                data = await resp.json()

        if data.get("errcode") != 0:
            raise RuntimeError(f"获取企微 access_token 失败: {data}")

        self._access_token = data["access_token"]
        self._token_expires_at = time.time() + data.get("expires_in", 7200) - 300
        SYLogger.info("[WeComMsg] access_token 已刷新")
        return self._access_token

    # ─── HTTP 辅助 ───

    async def _wecom_post(self, path: str, body: dict) -> dict:
        """发送企微 POST 请求"""
        token = await self._get_access_token()
        url = f"https://qyapi.weixin.qq.com{path}?access_token={token}"

        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=body) as resp:
                return await resp.json()

    async def _wecom_upload(self, file_path: str, media_type: str = "file") -> dict:
        """上传文件到企微素材库"""
        token = await self._get_access_token()
        url = (
            f"https://qyapi.weixin.qq.com/cgi-bin/media/upload"
            f"?access_token={token}&type={media_type}"
        )

        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")

        data = aiohttp.FormData()
        data.add_field("media", open(file_path, "rb"), filename=path.name)

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=data) as resp:
                    return await resp.json()
        finally:
            # FormData 内的文件对象在请求结束后由 aiohttp 关闭，
            # 但保险起见也手动确保关闭
            pass

    # ─── 应用消息 API ───

    async def send_text(
        self, touser: str, content: str, agentid: Optional[int] = None
    ) -> Optional[dict]:
        """发送文本应用消息"""
        config = self._ensure_config()
        body = {
            "touser": touser,
            "msgtype": "text",
            "agentid": agentid or config.agentid,
            "text": {"content": content},
        }

        try:
            result = await self._wecom_post("/cgi-bin/message/send", body)
            if result.get("errcode") != 0:
                SYLogger.warning(f"[WeComMsg] 发送文本消息失败: {result}")
                return result
            SYLogger.info(f"[WeComMsg] 文本消息已发送给 {touser}")
            return result
        except Exception as e:
            SYLogger.error(f"[WeComMsg] 发送文本消息异常: {e}")
            return None

    async def send_markdown(
        self, touser: str, content: str, agentid: Optional[int] = None
    ) -> Optional[dict]:
        """发送 Markdown 应用消息"""
        config = self._ensure_config()
        body = {
            "touser": touser,
            "msgtype": "markdown",
            "agentid": agentid or config.agentid,
            "markdown": {"content": content},
        }

        try:
            result = await self._wecom_post("/cgi-bin/message/send", body)
            if result.get("errcode") != 0:
                SYLogger.warning(f"[WeComMsg] 发送 Markdown 消息失败: {result}")
                return result
            SYLogger.info(f"[WeComMsg] Markdown 消息已发送给 {touser}")
            return result
        except Exception as e:
            SYLogger.error(f"[WeComMsg] 发送 Markdown 消息异常: {e}")
            return None

    async def send_image(
        self, touser: str, media_id: str, agentid: Optional[int] = None
    ) -> Optional[dict]:
        """发送图片应用消息（需先上传获取 media_id）"""
        config = self._ensure_config()
        body = {
            "touser": touser,
            "msgtype": "image",
            "agentid": agentid or config.agentid,
            "image": {"media_id": media_id},
        }

        try:
            result = await self._wecom_post("/cgi-bin/message/send", body)
            if result.get("errcode") != 0:
                SYLogger.warning(f"[WeComMsg] 发送图片消息失败: {result}")
                return result
            SYLogger.info(f"[WeComMsg] 图片消息已发送给 {touser}")
            return result
        except Exception as e:
            SYLogger.error(f"[WeComMsg] 发送图片消息异常: {e}")
            return None

    async def upload_file(self, file_path: str) -> Optional[str]:
        """上传文件到企微临时素材库，返回 media_id

        :param file_path: 本地文件路径
        :return: media_id，失败返回 None
        """
        try:
            result = await self._wecom_upload(file_path, media_type="file")
            if result.get("errcode", 0) != 0:
                SYLogger.warning(f"[WeComMsg] 文件上传失败: {result}")
                return None
            media_id = result["media_id"]
            SYLogger.info(
                f"[WeComMsg] 文件上传成功: {Path(file_path).name} -> {media_id}"
            )
            return media_id
        except Exception as e:
            SYLogger.error(f"[WeComMsg] 文件上传异常: {e}")
            return None

    async def send_file_by_media_id(
        self, touser: str, media_id: str, agentid: Optional[int] = None
    ) -> Optional[dict]:
        """通过 media_id 发送文件应用消息"""
        config = self._ensure_config()
        body = {
            "touser": touser,
            "msgtype": "file",
            "agentid": agentid or config.agentid,
            "file": {"media_id": media_id},
        }

        try:
            result = await self._wecom_post("/cgi-bin/message/send", body)
            if result.get("errcode") != 0:
                SYLogger.warning(f"[WeComMsg] 发送文件消息失败: {result}")
                return result
            SYLogger.info(f"[WeComMsg] 文件消息已发送给 {touser}")
            return result
        except Exception as e:
            SYLogger.error(f"[WeComMsg] 发送文件消息异常: {e}")
            return None

    async def send_file(
        self, touser: str, file_path: str, agentid: Optional[int] = None
    ) -> Optional[dict]:
        """上传文件并发送给指定用户（便捷方法）

        :param touser: 接收人 userid，多人用 "|" 分隔
        :param file_path: 本地文件路径
        :param agentid: 应用 agentid，默认从配置读取
        :return: API 响应，失败返回 None
        """
        media_id = await self.upload_file(file_path)
        if not media_id:
            return None
        return await self.send_file_by_media_id(touser, media_id, agentid)

    # ─── 机器人主动消息 ───

    async def send_bot_markdown(
        self, chatid: str, content: str
    ) -> Optional[Any]:
        """通过机器人 WebSocket 通道发送 Markdown 消息

        :param chatid: 单聊填 userid，群聊填 chatid
        :param content: Markdown 内容
        :return: WsFrame，失败返回 None
        """
        if not self._ws_client:
            SYLogger.error("[WeComMsg] 未设置 WSClient，请先调用 set_ws_client()")
            return None

        try:
            result = await self._ws_client.send_message(chatid, {
                "msgtype": "markdown",
                "markdown": {"content": content},
            })
            SYLogger.info(f"[WeComMsg] 机器人 Markdown 消息已发送到 {chatid}")
            return result
        except Exception as e:
            SYLogger.error(f"[WeComMsg] 机器人发送 Markdown 异常: {e}")
            return None

    async def send_bot_template_card(
        self, chatid: str, template_card: Dict[str, Any]
    ) -> Optional[Any]:
        """通过机器人 WebSocket 通道发送模板卡片消息

        :param chatid: 单聊填 userid，群聊填 chatid
        :param template_card: 模板卡片内容
        :return: WsFrame，失败返回 None
        """
        if not self._ws_client:
            SYLogger.error("[WeComMsg] 未设置 WSClient，请先调用 set_ws_client()")
            return None

        try:
            result = await self._ws_client.send_message(chatid, {
                "msgtype": "template_card",
                "template_card": template_card,
            })
            SYLogger.info(f"[WeComMsg] 机器人模板卡片消息已发送到 {chatid}")
            return result
        except Exception as e:
            SYLogger.error(f"[WeComMsg] 机器人发送模板卡片异常: {e}")
            return None
