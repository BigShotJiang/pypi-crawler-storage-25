from sycommon.notice.wecom_message import WeComMessageService

__all__ = [
    "WeComMessageService",
]
