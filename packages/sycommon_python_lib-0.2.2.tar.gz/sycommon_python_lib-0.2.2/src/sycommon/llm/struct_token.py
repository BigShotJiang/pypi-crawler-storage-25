from sycommon.tools.merge_headers import get_header_value
from sycommon.tools.env import get_env_var
from sycommon.config.LLMConfig import LLMConfig
from sycommon.logging.kafka_log import SYLogger
from sycommon.llm.llm_tokens import TokensCallbackHandler
from sycommon.llm.token_usage_mysql_service import TokenUsageMySQLService
from langchain_core.messages import BaseMessage, SystemMessage, HumanMessage
from langchain_core.runnables import Runnable, RunnableConfig
from sycommon.llm.llm_logger import LLMLogger
from langfuse import Langfuse, LangfuseSpan, propagate_attributes
from typing import Dict, List, Optional, Any
import tiktoken
import warnings
warnings.filterwarnings("ignore", message="Pydantic serializer warnings")


class StructuredRunnableWithToken(Runnable):
    """
    统一功能 Runnable：Trace追踪 + Token统计 + 自动上下文压缩

    支持两种模式：
    1. 兼容模式（is_native_mode=False）：retry_chain 期望输入 {"messages": [...]}
    2. 原生模式（is_native_mode=True）：retry_chain 直接接收消息列表
    """

    def __init__(
        self,
        retry_chain: Runnable,
        langfuse: Optional[Langfuse] = None,
        llmConfig: Optional[LLMConfig] = None,
        summary_prompt: Optional[str] = None,
        model_name: str = "Qwen2.5-72B",
        enable_compression: bool = True,
        threshold_ratio: float = 0.8,
        keep_last_n: int = 2,
        max_compression_attempts: int = 5,
        is_native_mode: bool = False
    ):
        super().__init__()
        self.retry_chain = retry_chain
        self.langfuse = langfuse
        self.llmConfig = llmConfig
        self.summary_prompt = summary_prompt
        self.model_name = model_name
        self.enable_compression = enable_compression
        self.threshold_ratio = threshold_ratio
        self.keep_last_n = keep_last_n  # 保留最近N条消息不压缩
        self.max_compression_attempts = max_compression_attempts  # 最大压缩尝试次数
        self.is_native_mode = is_native_mode  # 是否为原生模式

        # 初始化 Tokenizer
        try:
            self.encoding = tiktoken.encoding_for_model(model_name)
        except KeyError:
            self.encoding = tiktoken.get_encoding("cl100k_base")

    def _count_tokens(self, messages: List[BaseMessage]) -> int:
        """快速估算 Token 数量"""
        num_tokens = 0
        for message in messages:
            num_tokens += 4  # 每条消息的固定开销
            # 兼容 content 是字符串或者 dict 的情况
            content = message.content
            if isinstance(content, str):
                num_tokens += len(self.encoding.encode(content))
            elif isinstance(content, list):  # 多模态或复杂结构
                for item in content:
                    if isinstance(item, dict) and "text" in item:
                        num_tokens += len(self.encoding.encode(item["text"]))
            elif isinstance(content, dict):
                num_tokens += len(self.encoding.encode(str(content)))
        return num_tokens

    async def _acompress_context(self, messages: List[BaseMessage]) -> List[BaseMessage]:
        """
        执行异步上下文压缩

        策略：保留 System Prompt + 最近 N 条，中间的消息分批摘要
        支持多次压缩直到 token 数量低于阈值
        """
        # 分离系统消息和对话消息
        system_msgs = [m for m in messages if isinstance(m, SystemMessage)]
        conversation = [
            m for m in messages if not isinstance(m, SystemMessage)]

        if len(conversation) <= self.keep_last_n:
            return messages

        max_tokens = int(self.llmConfig.maxTokens * self.threshold_ratio)
        # 计算每批消息的压缩阈值：平均分配可用 token 空间
        # 预留给 system_msgs 和 keep_recent 的 token 空间
        reserved_tokens = self._count_tokens(
            system_msgs) + self._count_tokens(conversation[-self.keep_last_n:])
        available_tokens = max_tokens - reserved_tokens

        current_messages = messages

        for attempt in range(self.max_compression_attempts):
            current_tokens = self._count_tokens(current_messages)
            if current_tokens <= max_tokens:
                SYLogger.info(
                    f"✅ Compression complete after {attempt} attempts: "
                    f"{current_tokens} tokens (threshold: {max_tokens})"
                )
                return current_messages

            # 重新分离系统消息和对话消息
            system_msgs = [
                m for m in current_messages if isinstance(m, SystemMessage)]
            conversation = [
                m for m in current_messages if not isinstance(m, SystemMessage)]

            if len(conversation) <= self.keep_last_n:
                SYLogger.warning(
                    f"⚠️ Cannot compress further: only {len(conversation)} messages left")
                return current_messages

            to_summarize = conversation[:-self.keep_last_n]
            keep_recent = conversation[-self.keep_last_n:]

            # 计算每批的压缩阈值
            # 如果消息数量少，每批的阈值就高；消息多，每批阈值就低
            num_batches = max(1, (len(to_summarize) + 9) // 10)
            batch_token_threshold = available_tokens // num_batches

            # 分批压缩，每批最多10条消息
            batch_size = 10
            summary_msgs = []

            for i in range(0, len(to_summarize), batch_size):
                batch = to_summarize[i:i + batch_size]
                batch_tokens = self._count_tokens(batch)

                # 【关键优化】如果这批消息的 token 数量已经低于阈值，不需要压缩
                if batch_tokens <= batch_token_threshold:
                    SYLogger.info(
                        f"⏭️ Batch {i//batch_size + 1} skipped: "
                        f"{batch_tokens} tokens <= threshold {batch_token_threshold}"
                    )
                    summary_msgs.extend(batch)  # 直接保留原消息
                else:
                    # 需要压缩
                    batch_summary = await self._summarize_batch(batch, attempt, batch_token_threshold)
                    summary_msgs.append(batch_summary)

            # 重组消息：System + Summaries + Recent
            current_messages = system_msgs + summary_msgs + keep_recent

            SYLogger.info(
                f"🔄 Compression attempt {attempt + 1}: "
                f"{len(to_summarize)} messages -> {len(summary_msgs)} items, "
                f"tokens: {self._count_tokens(current_messages)}"
            )

        return current_messages

    async def _summarize_batch(
        self,
        messages: List[BaseMessage],
        attempt: int,
        target_tokens: int = None
    ) -> SystemMessage:
        """
        将一批消息压缩为一条摘要消息

        Args:
            messages: 待压缩的消息列表
            attempt: 当前压缩尝试次数
            target_tokens: 目标 token 数量（用于计算压缩比例）
        """
        original_tokens = self._count_tokens(messages)

        # 根据目标 token 计算压缩比例
        if target_tokens and original_tokens > 0:
            compression_ratio = max(
                0.3, min(0.7, target_tokens / original_tokens))
            ratio_text = f"{int(compression_ratio * 100)}%"
        else:
            compression_ratio = 0.5
            ratio_text = "50%"

        summary_content = self.summary_prompt or (
            f"请将以下对话内容进行摘要，保留关键信息。\n"
            f"要求：\n"
            f"1. 保留重要的决策、结论和数据\n"
            f"2. 压缩到原来长度的{ratio_text}左右\n"
            f"3. 使用简洁的中文表达"
        )

        # 格式化消息内容
        formatted_msgs = []
        for m in messages:
            role = m.type if hasattr(m, 'type') else 'unknown'
            content = m.content if isinstance(
                m.content, str) else str(m.content)
            formatted_msgs.append(f"[{role}]: {content}")

        summary_prompt = [
            SystemMessage(content=summary_content),
            HumanMessage(
                content=f"对话内容:\n{chr(10).join(formatted_msgs)}\n\n摘要:")
        ]

        try:
            # 调用子链生成摘要，清空 callbacks 避免递归追踪
            summary_result = await self.retry_chain.ainvoke(
                {"messages": summary_prompt},
                config=RunnableConfig(callbacks=[])
            )

            summary_text = summary_result.content if hasattr(
                summary_result, 'content') else str(summary_result)

            return SystemMessage(content=f"[压缩摘要 #{attempt + 1}]: {summary_text}")

        except Exception as e:
            SYLogger.error(f"❌ Batch summarization failed: {e}")
            # 压缩失败时，保留原始消息的第一条（降级处理）
            return SystemMessage(
                content=f"[压缩失败，保留原始]: {messages[0].content[:500]}..."
            )

    def _adapt_input(self, input: Any) -> List[BaseMessage]:
        """适配输入格式"""
        if isinstance(input, list) and all(isinstance(x, BaseMessage) for x in input):
            return input
        elif isinstance(input, BaseMessage):
            return [input]
        elif isinstance(input, str):
            return [HumanMessage(content=input)]
        elif isinstance(input, dict) and "messages" in input:
            # 如果已经是标准格式字典，直接提取
            msgs = input["messages"]
            return msgs if isinstance(msgs, list) else [msgs]
        elif isinstance(input, dict) and "input" in input:
            return [HumanMessage(content=str(input["input"]))]
        else:
            raise ValueError(f"不支持的输入格式：{type(input)}")

    def _record_token_usage(
        self,
        user_id: str,
        token_usage: Dict[str, Any],
        model: Optional[str] = None
    ):
        """记录 Token 使用量到 MySQL（Fire-and-forget 模式，自动初始化）"""
        if not token_usage:
            return

        try:
            # 尝试从 headers 获取 tenant_id
            tenant_id = get_header_value(
                SYLogger.get_headers(), "x-tenant-header")

            # 调用记录服务（service_name 和 system_env 由服务内部自动获取）
            TokenUsageMySQLService.record_sync(
                user_id=user_id,
                input_tokens=token_usage.get("input_tokens", 0),
                output_tokens=token_usage.get("output_tokens", 0),
                model=model or self.llmConfig.model if self.llmConfig else self.model_name,
                tenant_id=tenant_id
            )
        except Exception as e:
            SYLogger.warning(f"Token 使用量记录失败: {e}")

    async def _record_token_usage_async(
        self,
        user_id: str,
        token_usage: Dict[str, Any],
        model: Optional[str] = None
    ):
        """记录 Token 使用量到 MySQL（异步，自动初始化）"""
        if not token_usage:
            return

        try:
            # 自动初始化（不会重复初始化）
            TokenUsageMySQLService.init()

            # 尝试从 headers 获取 tenant_id
            tenant_id = get_header_value(
                SYLogger.get_headers(), "x-tenant-header")

            # 调用记录服务（service_name 和 system_env 由服务内部自动获取）
            await TokenUsageMySQLService.record(
                user_id=user_id,
                input_tokens=token_usage.get("input_tokens", 0),
                output_tokens=token_usage.get("output_tokens", 0),
                model=model or self.llmConfig.model if self.llmConfig else self.model_name,
                tenant_id=tenant_id
            )
        except Exception as e:
            SYLogger.warning(f"Token 使用量记录失败: {e}")

    def _get_callback_config(
        self,
        config: Optional[RunnableConfig] = None,
        trace_id: Optional[str] = None,
        user_id: Optional[str] = None
    ) -> tuple[RunnableConfig, TokensCallbackHandler]:
        """构建包含Token统计和metadata的回调配置"""
        token_handler = TokensCallbackHandler()

        if config is None:
            processed_config = RunnableConfig(callbacks=[], metadata={})
        else:
            processed_config = config.copy()
            if "callbacks" not in processed_config:
                processed_config["callbacks"] = []
            if "metadata" not in processed_config:
                processed_config["metadata"] = {}

        # 添加 Langfuse metadata
        if trace_id:
            processed_config["metadata"]["langfuse_session_id"] = trace_id
        if user_id:
            processed_config["metadata"]["langfuse_user_id"] = user_id

        callbacks = processed_config["callbacks"]
        if not any(isinstance(cb, LLMLogger) for cb in callbacks):
            callbacks.append(LLMLogger())
        callbacks.append(token_handler)

        # 去重
        callback_types = {}
        unique_callbacks = []
        for cb in callbacks:
            cb_type = type(cb)
            if cb_type not in callback_types:
                callback_types[cb_type] = cb
                unique_callbacks.append(cb)

        processed_config["callbacks"] = unique_callbacks

        return processed_config, token_handler

    def invoke(self, input: Any, config: Optional[RunnableConfig] = None, **kwargs) -> Dict[str, Any]:
        # 获取 trace_id 和 user_id（只从请求头获取，没有则为空）
        trace_id = SYLogger.get_trace_id()
        userid = get_header_value(SYLogger.get_headers(), "x-userid-header")
        user_id = userid if userid else None

        # 判断是否启用 Langfuse
        if self.langfuse:
            try:
                with self.langfuse.start_as_current_observation(as_type="span", name="invoke") as span:
                    with propagate_attributes(session_id=trace_id, user_id=user_id):
                        return self._execute_chain(input, config, trace_id, user_id, span)
            except Exception as e:
                # Langfuse 跟踪失败不应阻断业务，降级执行
                SYLogger.error(f"Langfuse 同步跟踪失败: {str(e)}", exc_info=True)
                return self._execute_chain(input, config, trace_id, user_id, None)
        else:
            # 未启用 Langfuse，直接执行业务逻辑
            return self._execute_chain(input, config, trace_id, user_id, None)

    async def ainvoke(self, input: Any, config: Optional[RunnableConfig] = None, **kwargs) -> Dict[str, Any]:
        # 获取 trace_id 和 user_id（只从请求头获取，没有则为空）
        trace_id = SYLogger.get_trace_id()
        userid = get_header_value(SYLogger.get_headers(), "x-userid-header")
        user_id = userid if userid else None

        # 判断是否启用 Langfuse
        if self.langfuse:
            try:
                with self.langfuse.start_as_current_observation(as_type="span", name="ainvoke") as span:
                    with propagate_attributes(session_id=trace_id, user_id=user_id):
                        return await self._aexecute_chain(input, config, trace_id, user_id, span)
            except Exception as e:
                # Langfuse 跟踪失败不应阻断业务，降级执行
                SYLogger.error(f"Langfuse 异步跟踪失败: {str(e)}", exc_info=True)
                return await self._aexecute_chain(input, config, trace_id, user_id, None)
        else:
            # 未启用 Langfuse，直接执行业务逻辑
            return await self._aexecute_chain(input, config, trace_id, user_id, None)

    def _execute_chain(
        self,
        input: Any,
        config: Optional[RunnableConfig],
        trace_id: str,
        user_id: str,
        span: LangfuseSpan
    ) -> Dict[str, Any]:
        """执行实际的调用逻辑 (同步)"""
        try:
            processed_config, token_handler = self._get_callback_config(
                config,
                trace_id=trace_id,
                user_id=user_id
            )

            # 【同步模式下不建议触发压缩，因为压缩本身是异步调用 LLM】
            # 如果同步也要压缩，需要用 asyncio.run(...)，这里暂时保持原逻辑直接透传
            adapted_input = self._adapt_input(input)

            # 根据模式选择输入格式
            if self.is_native_mode:
                # 原生模式：直接传递消息列表
                input_data = adapted_input
            else:
                # 兼容模式：包装成 {"messages": [...]}
                input_data = {"messages": adapted_input}

            if span:
                span.update(input=input_data)

            structured_result = self.retry_chain.invoke(
                input_data,
                config=processed_config
            )

            if span:
                span.update(output=structured_result)

            token_usage = token_handler.usage_metadata
            structured_result._token_usage_ = token_usage

            # 记录 Token 使用量到 MySQL
            self._record_token_usage(user_id, token_usage)

            return structured_result
        except Exception as e:
            SYLogger.error(f"同步LLM调用失败: {str(e)}", exc_info=True)
            return None

    async def _aexecute_chain(
        self,
        input: Any,
        config: Optional[RunnableConfig],
        trace_id: str,
        user_id: str,
        span: LangfuseSpan
    ) -> Dict[str, Any]:
        """执行实际的调用逻辑 (异步)"""
        try:
            processed_config, token_handler = self._get_callback_config(
                config,
                trace_id=trace_id,
                user_id=user_id
            )

            # 1. 适配输入
            adapted_input = self._adapt_input(input)

            # 2. 检查并执行上下文压缩 (仅在异步模式且开启时)
            if self.enable_compression:
                max_tokens = self.llmConfig.maxTokens
                current_tokens = self._count_tokens(adapted_input)

                if current_tokens > max_tokens * self.threshold_ratio:
                    SYLogger.warning(
                        f"⚠️ Context limit reached: {current_tokens}/{max_tokens}")
                    # 执行压缩，替换 adapted_input
                    adapted_input = await self._acompress_context(adapted_input)

            # 根据模式选择输入格式
            if self.is_native_mode:
                # 原生模式：直接传递消息列表
                input_data = adapted_input
            else:
                # 兼容模式：包装成 {"messages": [...]}
                input_data = {"messages": adapted_input}

            if span:
                span.update(input=input_data)

            # 3. 调用子链
            structured_result = await self.retry_chain.ainvoke(
                input_data,
                config=processed_config
            )

            if span:
                span.update(output=structured_result)

            token_usage = token_handler.usage_metadata
            structured_result._token_usage_ = token_usage

            # 异步记录 Token 使用量到 MySQL
            await self._record_token_usage_async(user_id, token_usage)

            return structured_result
        except Exception as e:
            SYLogger.error(f"异步LLM调用失败: {str(e)}", exc_info=True)
            return None
