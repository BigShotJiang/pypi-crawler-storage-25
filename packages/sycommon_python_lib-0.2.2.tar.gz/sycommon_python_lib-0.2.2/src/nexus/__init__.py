import subprocess
import sys
import os
import glob
import argparse


NEXUS_URL = "http://192.168.2.174:8081"
USERNAME = "Osulcode.xiao"
PASSWORD = "Osulcode.xiao@123"
REPOSITORY = "shengye"


def main():
    parser = argparse.ArgumentParser(prog="sypublish", description="上传 whl 到 Nexus")
    parser.add_argument("file", nargs="?", help="whl 文件路径 (默认: dist/*.whl 中最新的)")
    parser.add_argument("--url", default=NEXUS_URL, help=f"Nexus 地址 (默认: {NEXUS_URL})")
    parser.add_argument("-r", "--repository", default=REPOSITORY, help=f"仓库名称 (默认: {REPOSITORY})")
    args = parser.parse_args()

    if args.file:
        file_path = args.file
    else:
        dist_files = sorted(glob.glob("dist/*.whl"))
        if not dist_files:
            print("No .whl file found in dist/")
            sys.exit(1)
        file_path = dist_files[-1]

    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        sys.exit(1)

    repo_url = f"{args.url}/repository/{args.repository}/"
    cmd = ["twine", "upload", "--repository-url", repo_url, file_path, "-u", USERNAME, "-p", PASSWORD]
    sys.exit(subprocess.call(cmd))


if __name__ == "__main__":
    main()
