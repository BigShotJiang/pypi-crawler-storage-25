# Copyright 2026 The LiteRT CLI Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================

import importlib.metadata
import subprocess
from unittest import mock

from absl.testing import absltest
import click
from litert_cli.core import constants
from litert_cli.core import deps


class DepsTest(absltest.TestCase):

  def setUp(self):
    super().setUp()
    self.enter_context(mock.patch.object(constants, 'IS_INTERNAL_ENV', False))

  @mock.patch.object(importlib.metadata, 'version', autospec=True)
  def test_ensure_extra_already_installed(self, mock_version):
    # Simulate package is already installed
    mock_version.return_value = '0.1.0'

    result = deps.ensure_extra('torch')

    self.assertTrue(result)
    mock_version.assert_called_once_with('litert-torch-nightly')

  @mock.patch.object(subprocess, 'check_call', autospec=True)
  @mock.patch.object(importlib.metadata, 'version', autospec=True)
  def test_ensure_extra_not_installed_success(
      self, mock_version, mock_check_call
  ):
    # Simulate package is NOT installed
    mock_version.side_effect = importlib.metadata.PackageNotFoundError
    mock_check_call.return_value = 0

    result = deps.ensure_extra('torch')

    self.assertTrue(result)
    mock_version.assert_has_calls([
        mock.call('litert-torch-nightly'),
        mock.call('litert-torch'),
        mock.call('litert-cli-nightly'),
    ])
    mock_check_call.assert_called_once()

  @mock.patch.object(subprocess, 'check_call', autospec=True)
  @mock.patch.object(importlib.metadata, 'version', autospec=True)
  def test_ensure_extra_not_installed_failure(
      self, mock_version, mock_check_call
  ):
    # Simulate package is NOT installed and pip install fails
    mock_version.side_effect = importlib.metadata.PackageNotFoundError
    mock_check_call.side_effect = subprocess.CalledProcessError(
        1, 'pip install'
    )

    with self.assertRaises(click.Abort):
      deps.ensure_extra('torch')

  @mock.patch.object(subprocess, 'check_call', autospec=True)
  @mock.patch.object(importlib.metadata, 'version', autospec=True)
  def test_ensure_extra_silent_failure(self, mock_version, mock_check_call):
    # Simulate package is NOT installed and pip install fails, but silent=True
    mock_version.side_effect = importlib.metadata.PackageNotFoundError
    mock_check_call.side_effect = subprocess.CalledProcessError(
        1, 'pip install'
    )

    result = deps.ensure_extra('torch', silent=True)

    self.assertFalse(result)

  @mock.patch.object(deps, 'ensure_extra', autospec=True)
  def test_require_extra_decorator(self, mock_ensure_extra):
    @deps.require_extra('torch')
    def my_func():
      return 'Hello'

    result = my_func()

    self.assertEqual(result, 'Hello')
    mock_ensure_extra.assert_called_once_with('torch', silent=False)


if __name__ == '__main__':
  absltest.main()
