# My ABC Offline Library

This is a custom Python library that automatically pushes its source code into a Jupyter Notebook cell when you import it!

### How to install
```bash
pip install my_abc_offline_yourname
```

### How to use
Open a Python terminal or a Jupyter Notebook and type:
```python
import my_abc
```
