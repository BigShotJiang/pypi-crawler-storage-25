"""
Offline Library 'my_abc'
This library pushes its source code directly into your Jupyter Notebook cell!
"""

import os
try:
    from IPython.core.getipython import get_ipython
except ImportError:
    get_ipython = lambda: None

def show_my_code():
    """
    Reads the file and pushes it into the Jupyter Notebook cell.
    """
    try:
        with open(__file__, 'r', encoding='utf-8') as file:
            source_code = file.read()
            
            ipython = get_ipython()
            if ipython is not None:
                # If running in Jupyter Notebook / Colab, push code to a new cell
                ipython.set_next_input(source_code)
                print("✅ Source code successfully pushed to your next Jupyter cell!")
            else:
                # If running in standard terminal, just print it normally
                print("\n" + "="*50)
                print(f"SOURCE CODE OF: {__file__}")
                print("="*50)
                print(source_code)
                print("="*50 + "\n")
            
    except Exception as e:
        print(f"Could not read source code: {e}")

# Automatically trigger when you type 'import my_abc'
print("[my_abc library loaded] - Checking environment...")
show_my_code()
