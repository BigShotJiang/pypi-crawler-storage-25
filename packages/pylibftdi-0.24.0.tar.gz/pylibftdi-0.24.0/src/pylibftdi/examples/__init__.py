"""pylibftdi examples"""
