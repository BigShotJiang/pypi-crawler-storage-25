#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-07
################################################################

import os, sys
import numpy as np

try:
    from hex_util_data import HexMcapReader
except ImportError:
    sys.path.insert(
        0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from hex_util_data import HexMcapReader

DEFAULT_MCAP = os.path.join(os.path.abspath("multi_arm_rgbd"),
                            "mcap_data.mcap")

EXPECTED_STATE_TOPICS = [
    "arm_0/state", "arm_1/state", "arm_2/state", "arm_3/state"
]
EXPECTED_COLOR_TOPICS = [
    "cam_0/color", "cam_1/color", "cam_2/color", "cam_3/color"
]
EXPECTED_DEPTH_TOPICS = [
    "cam_0/depth", "cam_1/depth", "cam_2/depth", "cam_3/depth"
]
EXPECTED_TOPICS = (EXPECTED_STATE_TOPICS + EXPECTED_COLOR_TOPICS +
                   EXPECTED_DEPTH_TOPICS)

JNT_NUM = 40
COLOR_SHAPE = (480, 640, 3)
DEPTH_SHAPE = (480, 640)


def main():
    mcap_path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_MCAP
    assert os.path.exists(mcap_path), f"MCAP not found: {mcap_path}"

    print(f"Reading MCAP: {mcap_path}")
    reader = HexMcapReader(mcap_path)

    print(f"  topic_dict keys = {reader.topic_dict()}")
    print(f"  summary = {reader.summary()}")
    print(f"  get_data state = {reader.get_data('arm_0/state')}")
    print(f"  get_data color = {reader.get_data('cam_0/color')}")
    print(f"  get_data depth = {reader.get_data('cam_0/depth')}")
    print(f"  get_data not exist = {reader.get_data('nonexistent/topic')}")

    print("=" * 50)
    print("All reader tests passed!")


if __name__ == '__main__':
    main()
