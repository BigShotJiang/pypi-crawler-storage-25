#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-04-07
################################################################

import json
import struct
import cv2
import numpy as np
from typing import Any
from mcap.reader import make_reader


class HexMcapReader:

    def __init__(self, mcap_path: str):
        self.__path = mcap_path
        self.__topic_info: dict[str, tuple[int, int,
                                           int]] = self.__build_topic_info()

    def topic_dict(self) -> dict[str, tuple[int, int, int]]:
        return self.__topic_info

    def summary(self):
        """Print total duration and per-topic statistics."""
        if not self.__topic_info:
            print("Empty MCAP file: no topics found.")
            return

        global_start = min(s for s, _, _ in self.__topic_info.values())
        global_end = max(e for _, e, _ in self.__topic_info.values())
        total_count = sum(c for _, _, c in self.__topic_info.values())
        duration_s = (global_end - global_start) * 1e-9

        print("#" * 60)
        print(f"File     : {self.__path}")
        print(f"Duration : {duration_s:.3f}s")
        print(f"Topics   : {len(self.__topic_info)}")
        print(f"Messages : {total_count}")
        print("-" * 60)
        for topic, (start, end, count) in self.__topic_info.items():
            t_dur = (end - start) * 1e-9
            hz_str = f"{count / t_dur:.1f}" if t_dur > 0 else "N/A"
            print(f"  {topic}")
            print(f"    count={count}  duration={t_dur:.3f}s  Hz={hz_str}")
        print("#" * 60)

    def get_data(
        self,
        topic: str,
        start_ts: int | None = None,
        end_ts: int | None = None,
    ) -> list[dict[str, Any]]:
        if topic not in self.__topic_info:
            return []

        if start_ts is None:
            start_ts = self.__topic_info[topic][0]
        if end_ts is None:
            end_ts = self.__topic_info[topic][1]

        result: list[dict[str, Any]] = []
        with open(self.__path, "rb") as f:
            reader = make_reader(f)
            for _, channel, message in reader.iter_messages(
                    topics=[topic],
                    start_time=start_ts,
                    end_time=end_ts + 1,
            ):
                try:
                    data = self.__decode(channel, message)
                    result.append(data)
                except Exception as e:
                    print(f"Warning: decode failed [{channel.topic}]: {e}")
        return result

    # ------------------------------------------------------------------
    # Topic info builder
    # ------------------------------------------------------------------

    def __build_topic_info(self):
        info: dict[str, list] = {}
        with open(self.__path, "rb") as f:
            reader = make_reader(f)
            for _, channel, message in reader.iter_messages():
                topic = channel.topic
                ts = message.log_time
                if topic not in info:
                    info[topic] = [ts, ts, 1]
                else:
                    if ts < info[topic][0]:
                        info[topic][0] = ts
                    if ts > info[topic][1]:
                        info[topic][1] = ts
                    info[topic][2] += 1
        return {k: (v[0], v[1], v[2]) for k, v in info.items()}

    # ------------------------------------------------------------------
    # Message decoding
    # ------------------------------------------------------------------

    @staticmethod
    def __detect_type(topic: str) -> str:
        if topic.endswith("state"):
            return "state"
        if topic.endswith("color"):
            return "color"
        if topic.endswith("depth"):
            return "depth"
        return "unknown"

    @classmethod
    def __decode(cls, channel, message) -> dict[str, Any]:
        ch_type = cls.__detect_type(channel.topic)
        encoding = channel.message_encoding

        if encoding == "json":
            return cls.__decode_json(json.loads(message.data), ch_type)
        if encoding == "protobuf":
            return cls.__decode_image_wire(message.data, ch_type)

    # ------------------------------------------------------------------
    # JSON decoding
    # ------------------------------------------------------------------

    @classmethod
    def __decode_json(cls, raw: dict, ch_type: str) -> dict[str, Any]:
        if ch_type == "state":
            return cls.__parse_state(raw)
        if ch_type in ("color", "depth"):
            return cls.__parse_image_json(raw, ch_type)
        return raw

    @staticmethod
    def __parse_state(raw: dict) -> dict[str, Any]:
        result: dict[str, Any] = {}
        ts = raw.get("timestamp")
        if ts:
            result["ts_ns"] = (int(ts.get("sec", 0)) * 1_000_000_000 +
                               int(ts.get("nsec", 0)))
        for key, value in raw.items():
            if key == "timestamp":
                continue
            result[key] = np.array(value) if isinstance(value, list) else value
        return result

    @staticmethod
    def __parse_image_json(raw: dict, ch_type: str) -> dict[str, Any]:
        import base64

        ts = raw.get("timestamp", {})
        ts_ns = (int(ts.get("sec", 0)) * 1_000_000_000 +
                 int(ts.get("nsec", 0)))
        img_data = raw.get("data", b"")
        if isinstance(img_data, str):
            img_bytes = base64.b64decode(img_data)
        else:
            img_bytes = bytes(img_data)
        buf = np.frombuffer(img_bytes, dtype=np.uint8)
        flag = cv2.IMREAD_COLOR if ch_type == "color" else cv2.IMREAD_UNCHANGED
        img = cv2.imdecode(buf, flag)
        return {"ts_ns": ts_ns, "data": img}

    # ------------------------------------------------------------------
    # Raw protobuf wire parser for foxglove.CompressedImage
    # (no google-protobuf dependency required)
    # ------------------------------------------------------------------

    @classmethod
    def __decode_image_wire(cls, data: bytes, ch_type: str) -> dict[str, Any]:
        parsed = cls.__parse_compressed_image_wire(data)
        ts_ns = parsed["sec"] * 1_000_000_000 + parsed["nsec"]
        buf = np.frombuffer(parsed["data"], dtype=np.uint8)
        flag = cv2.IMREAD_COLOR if ch_type == "color" else cv2.IMREAD_UNCHANGED
        img = cv2.imdecode(buf, flag)
        return {"ts_ns": ts_ns, "data": img}

    @staticmethod
    def __parse_compressed_image_wire(data: bytes) -> dict:
        """Parse foxglove.CompressedImage without any protobuf library.

        Wire layout (foxglove-sdk proto):
          field 1 - Timestamp (embedded):  uint32 sec, uint32 nsec
          field 2 - data     (bytes)
          field 3 - format   (string)
          field 4 - frame_id (string)      [optional]
        """

        def _read_varint(buf, pos):
            result = shift = 0
            while True:
                b = buf[pos]
                pos += 1
                result |= (b & 0x7F) << shift
                if not (b & 0x80):
                    return result, pos
                shift += 7

        def _skip(buf, pos, wt):
            if wt == 0:
                _, pos = _read_varint(buf, pos)
            elif wt == 1:
                pos += 8
            elif wt == 2:
                ln, pos = _read_varint(buf, pos)
                pos += ln
            elif wt == 5:
                pos += 4
            return pos

        pos = 0
        sec = nsec = 0
        img_data = b""

        while pos < len(data):
            key, pos = _read_varint(data, pos)
            fn, wt = key >> 3, key & 7

            if fn == 1 and wt == 2:
                ln, pos = _read_varint(data, pos)
                end = pos + ln
                while pos < end:
                    sk, pos = _read_varint(data, pos)
                    sf, sw = sk >> 3, sk & 7
                    if sf == 1 and sw == 0:
                        sec, pos = _read_varint(data, pos)
                    elif sf == 2 and sw == 0:
                        nsec, pos = _read_varint(data, pos)
                    elif sf == 1 and sw == 5:
                        sec = struct.unpack_from("<I", data, pos)[0]
                        pos += 4
                    elif sf == 2 and sw == 5:
                        nsec = struct.unpack_from("<I", data, pos)[0]
                        pos += 4
                    else:
                        pos = _skip(data, pos, sw)
            elif fn == 2 and wt == 2:
                ln, pos = _read_varint(data, pos)
                img_data = data[pos:pos + ln]
                pos += ln
            elif fn == 3 and wt == 2:
                ln, pos = _read_varint(data, pos)
                pos += ln
            else:
                pos = _skip(data, pos, wt)

        return {"sec": sec, "nsec": nsec, "data": img_data}
