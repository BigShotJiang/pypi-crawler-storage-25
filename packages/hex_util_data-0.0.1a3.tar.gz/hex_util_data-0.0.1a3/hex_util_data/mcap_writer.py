#!/usr/bin/env python3
# -*- coding:utf-8 -*-
################################################################
# Copyright 2026 Dong Zhaorui. All rights reserved.
# Author: Dong Zhaorui 847235539@qq.com
# Date  : 2026-03-14
################################################################

import os, time, threading, traceback
import foxglove
import cv2
import numpy as np
from typing import Any
from collections import deque
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor
from foxglove.schemas import Timestamp, CompressedImage, RawImage
from hex_util_runtime import ns_now, ns_to_hex_ts


class HexMcapWriter:

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 45678,
    ):
        self.__record_time = None
        self.__record_cnt = {"color": 0, "depth": 0, "state": 0, "single": {}}

        self.__mcap_ctx = None
        self.__exit_stack = None
        self.__is_recording = threading.Event()

        # CPython deque.append/popleft are GIL-atomic; Event for wake-up only
        self.__msg_queue = deque(maxlen=10240)
        self.__queue_event = threading.Event()

        self.__encode_pool = ThreadPoolExecutor(max_workers=4)
        self.__stop_event = threading.Event()

        self.__state_lock = threading.Lock()
        self.__log_lock = threading.Lock()

        self.__worker = threading.Thread(
            target=self.__worker_loop,
            daemon=True,
        )

        self.__server = foxglove.start_server(host=host, port=port)
        self.__worker.start()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def close(self):
        self.__stop_event.set()
        self.__queue_event.set()

        if self.__worker.is_alive():
            self.__worker.join()

        self.__encode_pool.shutdown(wait=True)
        self.stop_record()

    def start_record(self, path: str, name: str = "hex"):
        with self.__state_lock:
            if self.__is_recording.is_set():
                return

            os.makedirs(path, exist_ok=True)
            mcap_path = f"{path}/{name}.mcap"
            if os.path.exists(mcap_path):
                os.remove(mcap_path)

            self.__exit_stack = ExitStack()
            self.__mcap_ctx = self.__exit_stack.enter_context(
                foxglove.open_mcap(mcap_path))
            self.__record_time = ns_now()
            self.__record_cnt = {
                "color": 0,
                "depth": 0,
                "state": 0,
                "single": {},
            }
            self.__record_ts = {}
            self.__drop_count = 0
            self.__is_recording.set()

    def stop_record(self):
        with self.__state_lock:
            if not self.__is_recording.is_set():
                return

            self.__is_recording.clear()
            end_time = ns_now()

            with self.__log_lock:
                self.__exit_stack.close()
                self.__exit_stack = None
                self.__mcap_ctx = None

            self.__summary(end_time)
            print("Recording stopped")
            print("#" * 50)

    def append_data(self, data: dict[str, Any]):
        if self.__stop_event.is_set():
            return

        item = (ns_now(), data)
        self.__msg_queue.append(item)
        self.__queue_event.set()

    def __summary(self, end_time=None):
        record_cnt = {
            "color": self.__record_cnt["color"],
            "depth": self.__record_cnt["depth"],
            "state": self.__record_cnt["state"],
            "single": dict(self.__record_cnt["single"]),
        }
        record_ts = {k: dict(v) for k, v in self.__record_ts.items()}

        print("#" * 50)
        if end_time is not None and self.__record_time is not None:
            duration = (end_time - self.__record_time) * 1e-9
            print(f"Record duration: {duration:.2f}s")

        total_count = (record_cnt["color"] + record_cnt["depth"] +
                       record_cnt["state"])
        print(f"Record total count: {total_count}")
        print(f"--Record color count: {record_cnt['color']}")
        print(f"--Record depth count: {record_cnt['depth']}")
        print(f"--Record state count: {record_cnt['state']}")

        for key, value in record_cnt["single"].items():
            hz_str = ""
            ts = record_ts.get(key)
            if ts is not None:
                topic_dur = (ts["last"] - ts["first"]) * 1e-9
                if topic_dur > 0:
                    hz_str = f", Hz: {(value - 1) / topic_dur:.3f}"
            print(f"----Record {key} count: {value}{hz_str}")
        print("#" * 50)

    def __worker_loop(self):
        print_cnt = 0
        print_interval = 10_000

        while not self.__stop_event.is_set():
            try:
                item = self.__msg_queue.popleft()
            except IndexError:
                self.__queue_event.clear()
                if len(self.__msg_queue) > 0:
                    continue
                self.__queue_event.wait(timeout=0.1)
                continue

            try:
                get_ts, data_dict = item
                self.__process_data(get_ts, data_dict)

                if self.__is_recording.is_set():
                    print_cnt += 1
                    if print_cnt >= print_interval:
                        print_cnt = 0
                        self.__summary()
            except Exception as e:
                print(f"[HexMcapWriter] worker error: {e}")
                traceback.print_exc()
                time.sleep(0.001)

    def __process_data(self, get_ts, data_dict):
        for key, value in data_dict.items():
            if key == "ts_ns":
                continue
            elif key.endswith("state"):
                self.__log_state(key, value, get_ts)
            elif key.endswith("color"):
                self.__encode_pool.submit(self.__safe_call, self.__log_color,
                                          key, value, get_ts)
            elif key.endswith("depth"):
                self.__encode_pool.submit(self.__safe_call, self.__log_depth,
                                          key, value, get_ts)
            else:
                print(f"Warning: unsupported data type: {key}")

    def __safe_call(self, fn, *args, **kwargs):
        try:
            fn(*args, **kwargs)
        except Exception as e:
            print(f"[HexMcapWriter] async task error: {e}")
            traceback.print_exc()

    def __foxglove_log(self, topic, msg, log_time, category):
        with self.__log_lock:
            foxglove.log(topic, msg, log_time=log_time)
            if self.__is_recording.is_set():
                self.__record_cnt[category] += 1
                self.__record_cnt["single"][topic] = (
                    self.__record_cnt["single"].get(topic, 0) + 1)
                if topic not in self.__record_ts:
                    self.__record_ts[topic] = {
                        "first": log_time,
                        "last": log_time,
                    }
                else:
                    self.__record_ts[topic]["last"] = log_time

    def __log_state(self, topic, state_msg, get_ts):
        msg = {}
        for key, value in state_msg.items():
            if key == "ts_ns":
                hex_ts = ns_to_hex_ts(value)
                msg["timestamp"] = {"sec": hex_ts["s"], "nsec": hex_ts["ns"]}
            else:
                msg[key] = value.tolist()

        self.__foxglove_log(topic, msg, get_ts, "state")

    def __log_color(self, topic, color_msg, get_ts):
        color = color_msg.get("data", None)
        if color is None:
            return

        ok, buf = cv2.imencode(
            ".jpg",
            color,
            [cv2.IMWRITE_JPEG_QUALITY, 75],
        )
        if not ok:
            return

        hex_ts = ns_to_hex_ts(color_msg["ts_ns"])
        msg = CompressedImage(
            timestamp=Timestamp(sec=hex_ts["s"], nsec=hex_ts["ns"]),
            format="jpeg",
            data=buf.tobytes(),
        )
        self.__foxglove_log(topic, msg, get_ts, "color")

    def __log_depth(self, topic, depth_msg, get_ts):
        depth = depth_msg.get("data", None)
        if depth is None:
            return

        if depth.dtype == np.float32:
            encoding = "32FC1"
        elif depth.dtype == np.float64:
            depth = depth.astype(np.float32)
            encoding = "32FC1"
        else:
            depth = depth.astype(np.uint16)
            encoding = "16UC1"

        if not depth.flags["C_CONTIGUOUS"]:
            depth = np.ascontiguousarray(depth)

        h, w = depth.shape[:2]
        hex_ts = ns_to_hex_ts(depth_msg["ts_ns"])
        msg = RawImage(
            timestamp=Timestamp(sec=hex_ts["s"], nsec=hex_ts["ns"]),
            width=w,
            height=h,
            encoding=encoding,
            step=w * depth.dtype.itemsize,
            data=depth.tobytes(),
        )
        self.__foxglove_log(topic, msg, get_ts, "depth")
