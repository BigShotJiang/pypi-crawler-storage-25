"""Two-model group1 train/predict runner."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
import time
from typing import Any

from core.common.jsonl import write_jsonl
from core.inference.service import map_group1_clicks
from core.train.base import prepare_dataset_yaml_for_ultralytics
from core.train.group1.dataset import load_group1_dataset_config, load_group1_rows, resolve_group1_path
from core.train.group1.service import QUERY_COMPONENT, SCENE_COMPONENT


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run two-model group1 train/predict flows.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    train_parser = subparsers.add_parser("train", help="train the group1 scene detector and query parser")
    train_parser.add_argument("--dataset-config", type=Path, required=True)
    train_parser.add_argument("--project", type=Path, required=True)
    train_parser.add_argument("--name", required=True)
    train_parser.add_argument("--scene-model", default="yolo26n.pt")
    train_parser.add_argument("--query-model", default="yolo26n.pt")
    train_parser.add_argument("--epochs", type=int, default=120)
    train_parser.add_argument("--batch", type=int, default=16)
    train_parser.add_argument("--imgsz", type=int, default=640)
    train_parser.add_argument("--device", default="0")
    train_parser.add_argument("--resume", action="store_true")

    predict_parser = subparsers.add_parser("predict", help="run group1 pipeline prediction")
    predict_parser.add_argument("--dataset-config", type=Path, required=True)
    predict_parser.add_argument("--scene-model", type=Path, required=True)
    predict_parser.add_argument("--query-model", type=Path, required=True)
    predict_parser.add_argument("--source", type=Path, required=True)
    predict_parser.add_argument("--project", type=Path, required=True)
    predict_parser.add_argument("--name", required=True)
    predict_parser.add_argument("--conf", type=float, default=0.25)
    predict_parser.add_argument("--imgsz", type=int, default=640)
    predict_parser.add_argument("--device", default="0")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "train":
            _run_train(args)
        elif args.command == "predict":
            _run_predict(args)
        else:  # pragma: no cover - argparse guards
            raise RuntimeError(f"unsupported command: {args.command}")
    except RuntimeError as exc:
        parser.exit(1, f"{exc}\n")
    return 0


def _run_train(args: argparse.Namespace) -> None:
    dataset_config = load_group1_dataset_config(args.dataset_config)
    run_dir = args.project / args.name
    run_dir.mkdir(parents=True, exist_ok=True)

    scene_yaml = prepare_dataset_yaml_for_ultralytics(dataset_config.components["scene_detector"].dataset_yaml)
    query_yaml = prepare_dataset_yaml_for_ultralytics(dataset_config.components["query_parser"].dataset_yaml)
    commands = {
        SCENE_COMPONENT: _build_train_command(
            dataset_yaml=scene_yaml,
            project_dir=run_dir,
            run_name=SCENE_COMPONENT,
            model=args.scene_model,
            epochs=args.epochs,
            batch=args.batch,
            imgsz=args.imgsz,
            device=args.device,
            resume=args.resume,
        ),
        QUERY_COMPONENT: _build_train_command(
            dataset_yaml=query_yaml,
            project_dir=run_dir,
            run_name=QUERY_COMPONENT,
            model=args.query_model,
            epochs=args.epochs,
            batch=args.batch,
            imgsz=args.imgsz,
            device=args.device,
            resume=args.resume,
        ),
    }
    for command in commands.values():
        subprocess.run(command, check=True)

    summary = {
        "task": "group1",
        "dataset_config": str(args.dataset_config),
        "run_dir": str(run_dir),
        "components": {
            SCENE_COMPONENT: {
                "dataset_yaml": str(scene_yaml),
                "weights": {
                    "best": str(run_dir / SCENE_COMPONENT / "weights" / "best.pt"),
                    "last": str(run_dir / SCENE_COMPONENT / "weights" / "last.pt"),
                },
                "command": " ".join(commands[SCENE_COMPONENT]),
            },
            QUERY_COMPONENT: {
                "dataset_yaml": str(query_yaml),
                "weights": {
                    "best": str(run_dir / QUERY_COMPONENT / "weights" / "best.pt"),
                    "last": str(run_dir / QUERY_COMPONENT / "weights" / "last.pt"),
                },
                "command": " ".join(commands[QUERY_COMPONENT]),
            },
        },
    }
    (run_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")


def _run_predict(args: argparse.Namespace) -> None:
    try:
        from ultralytics import YOLO
    except Exception as exc:  # pragma: no cover - import error depends on host env
        raise RuntimeError(
            "当前环境缺少 `ultralytics`，无法执行 group1 双模型预测。"
            "请先完成训练环境安装后再重试。"
        ) from exc

    dataset_config = load_group1_dataset_config(args.dataset_config)
    rows = load_group1_rows(dataset_config, args.source)
    if not rows:
        raise RuntimeError("group1 预测输入为空。")

    scene_model = YOLO(str(args.scene_model))
    query_model = YOLO(str(args.query_model))
    output_dir = args.project / args.name
    output_dir.mkdir(parents=True, exist_ok=True)
    predictions: list[dict[str, Any]] = []

    for row in rows:
        query_path = resolve_group1_path(dataset_config.root, Path(str(row["query_image"])))
        scene_path = resolve_group1_path(dataset_config.root, Path(str(row["scene_image"])))
        started = time.perf_counter()
        query_result = query_model.predict(
            source=str(query_path),
            imgsz=args.imgsz,
            conf=args.conf,
            device=args.device,
            verbose=False,
        )[0]
        scene_result = scene_model.predict(
            source=str(scene_path),
            imgsz=args.imgsz,
            conf=args.conf,
            device=args.device,
            verbose=False,
        )[0]
        elapsed_ms = (time.perf_counter() - started) * 1000.0

        predicted_query_targets = _serialize_detections(query_result, ordered=True)
        predicted_scene_targets = _serialize_detections(scene_result, ordered=False)
        mapping = map_group1_clicks(predicted_query_targets, predicted_scene_targets)
        predictions.append(_build_prediction_row(row, predicted_query_targets, mapping, elapsed_ms))

    write_jsonl(output_dir / "labels.jsonl", predictions)
    (output_dir / "summary.json").write_text(
        json.dumps(
            {
                "task": "group1",
                "dataset_config": str(args.dataset_config),
                "source": str(args.source),
                "scene_model": str(args.scene_model),
                "query_model": str(args.query_model),
                "sample_count": len(predictions),
                "labels_path": str(output_dir / "labels.jsonl"),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def _build_train_command(
    *,
    dataset_yaml: Path,
    project_dir: Path,
    run_name: str,
    model: str,
    epochs: int,
    batch: int,
    imgsz: int,
    device: str,
    resume: bool,
) -> list[str]:
    if resume:
        command = [
            "uv",
            "run",
            "yolo",
            "detect",
            "train",
            "resume",
            f"model={model}",
        ]
        if device:
            command.append(f"device={device}")
        return command
    return [
        "uv",
        "run",
        "yolo",
        "detect",
        "train",
        f"data={dataset_yaml}",
        f"model={model}",
        f"imgsz={imgsz}",
        f"epochs={epochs}",
        f"batch={batch}",
        f"device={device}",
        f"project={project_dir}",
        f"name={run_name}",
    ]


def _serialize_detections(result: Any, *, ordered: bool) -> list[dict[str, Any]]:
    boxes = result.boxes
    if boxes is None:
        return []
    names = result.names if isinstance(result.names, dict) else {}
    detections: list[dict[str, Any]] = []
    xyxy = boxes.xyxy.tolist()
    cls_ids = boxes.cls.tolist()
    confidences = boxes.conf.tolist()
    for index, (bbox, class_id, score) in enumerate(zip(xyxy, cls_ids, confidences, strict=False), start=1):
        x1, y1, x2, y2 = [int(round(value)) for value in bbox]
        center_x = int(round((x1 + x2) / 2))
        center_y = int(round((y1 + y2) / 2))
        numeric_class_id = int(class_id)
        class_name = str(names.get(numeric_class_id, numeric_class_id))
        detection = {
            "order": index,
            "class": class_name,
            "class_id": numeric_class_id,
            "bbox": [x1, y1, x2, y2],
            "center": [center_x, center_y],
            "score": float(score),
        }
        detections.append(detection)

    if not ordered:
        return detections
    detections.sort(key=lambda item: (int(item["center"][0]), int(item["center"][1])))
    for order, detection in enumerate(detections, start=1):
        detection["order"] = order
    return detections


def _build_prediction_row(
    row: dict[str, Any],
    predicted_query_targets: list[dict[str, Any]],
    mapping: Any,
    elapsed_ms: float,
) -> dict[str, Any]:
    return {
        "sample_id": row["sample_id"],
        "query_image": row["query_image"],
        "scene_image": row["scene_image"],
        "query_targets": predicted_query_targets,
        "scene_targets": [
            {
                "order": target.order,
                "class": target.class_name,
                "class_id": target.class_id,
                "bbox": target.bbox,
                "center": target.center,
                "score": target.score,
            }
            for target in mapping.ordered_targets
        ],
        "distractors": [],
        "label_source": "pred",
        "source_batch": row.get("source_batch", "prediction"),
        "status": mapping.status,
        "inference_ms": round(elapsed_ms, 4),
    }


if __name__ == "__main__":
    raise SystemExit(main())
