"""Runtime adapter for invoking OpenCode commands from the controller."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path

from core.auto_train import opencode_commands

DEFAULT_PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OPENCODE_BINARY = "opencode"
DEFAULT_TIMEOUT_SECONDS = 60.0


@dataclass(frozen=True)
class OpenCodeRuntimeConfig:
    project_root: Path = DEFAULT_PROJECT_ROOT
    binary: str = DEFAULT_OPENCODE_BINARY
    attach_url: str | None = None
    model: str | None = None
    timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS

    def __post_init__(self) -> None:
        if self.timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be greater than 0")


@dataclass(frozen=True)
class OpenCodeInvocationResult:
    stdout: str
    stderr: str
    command: tuple[str, ...]
    returncode: int


class OpenCodeRuntimeError(RuntimeError):
    def __init__(
        self,
        *,
        command_name: str,
        message: str,
        command: list[str],
        returncode: int | None = None,
    ) -> None:
        super().__init__(message)
        self.command_name = command_name
        self.command = tuple(command)
        self.returncode = returncode


def subprocess_runner(
    command: list[str],
    *,
    cwd: Path,
    timeout_seconds: float,
) -> OpenCodeInvocationResult:
    completed = subprocess.run(
        command,
        cwd=cwd,
        check=False,
        capture_output=True,
        text=True,
        timeout=timeout_seconds,
    )
    return OpenCodeInvocationResult(
        stdout=completed.stdout,
        stderr=completed.stderr,
        command=tuple(command),
        returncode=completed.returncode,
    )


@dataclass(frozen=True)
class OpenCodeRuntimeAdapter:
    config: OpenCodeRuntimeConfig
    runner: object = subprocess_runner

    def judge_trial(
        self,
        *,
        study_name: str,
        task: str,
        trial_id: str,
        files: list[Path],
    ) -> OpenCodeInvocationResult:
        return self.run_command(
            "judge-trial",
            arguments=[study_name, task, trial_id],
            files=files,
        )

    def result_read(
        self,
        *,
        study_name: str,
        task: str,
        trial_id: str,
        primary_metric: str,
        files: list[Path],
    ) -> OpenCodeInvocationResult:
        return self.run_command(
            "result-read",
            arguments=[study_name, task, trial_id, primary_metric],
            files=files,
        )

    def study_status(
        self,
        *,
        study_name: str,
        task: str,
        files: list[Path],
    ) -> OpenCodeInvocationResult:
        return self.run_command(
            "study-status",
            arguments=[study_name, task],
            files=files,
        )

    def plan_dataset(
        self,
        *,
        study_name: str,
        task: str,
        trial_id: str,
        files: list[Path],
    ) -> OpenCodeInvocationResult:
        return self.run_command(
            "plan-dataset",
            arguments=[study_name, task, trial_id],
            files=files,
        )

    def run_command(
        self,
        name: str,
        *,
        arguments: list[str],
        files: list[Path],
    ) -> OpenCodeInvocationResult:
        command = opencode_commands.build_headless_invocation(
            name,
            arguments=arguments,
            files=files,
            attach_url=self.config.attach_url,
            model=self.config.model,
        )
        command[0] = self.config.binary
        try:
            result = self.runner(
                command,
                cwd=self.config.project_root,
                timeout_seconds=self.config.timeout_seconds,
            )
        except FileNotFoundError as exc:
            raise OpenCodeRuntimeError(
                command_name=name,
                message=f"opencode_binary_not_found: {self.config.binary}",
                command=command,
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise OpenCodeRuntimeError(
                command_name=name,
                message=f"opencode_timeout: {self.config.timeout_seconds}s",
                command=command,
            ) from exc

        if result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip() or f"exit_code={result.returncode}"
            raise OpenCodeRuntimeError(
                command_name=name,
                message=f"opencode_command_failed: {detail}",
                command=list(result.command),
                returncode=result.returncode,
            )

        if not result.stdout.strip():
            raise OpenCodeRuntimeError(
                command_name=name,
                message="opencode_empty_stdout",
                command=list(result.command),
                returncode=result.returncode,
            )
        return result
