---
description: Summarize the current study and return study_status.json
agent: plan
subtask: true
---

Read the attached files for:

- `study_name`: `$1`
- `task`: `$2`

Required attached files:

- `study.json`
- `leaderboard.json`

Optional attached files:

- `best_trial.json`
- `decisions.jsonl`

Task:

1. Load and follow the local `study-archivist` skill.
2. Read the current study status, budget pressure, and leaderboard trend.
3. Produce the final contents of `study_status.json`.
4. Keep the output structured and concise.
5. Do not ask for shell access or return prose outside the JSON object.

Return only one JSON object.
No markdown fences.
No prose before or after the JSON.
