"""Tide Chip Mint"""
__version__ = "1.0.0"
