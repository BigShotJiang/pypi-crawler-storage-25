from .core import aiodict, Namespacedaiodict

__all__ = ["aiodict", "Namespacedaiodict"]
__version__ = "0.1.0"
