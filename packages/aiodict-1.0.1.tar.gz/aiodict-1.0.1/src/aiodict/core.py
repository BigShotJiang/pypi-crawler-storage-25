from __future__ import annotations

import json
import math
import os
import shutil
import tempfile
import threading
import time
from collections.abc import Iterator, MutableMapping
from contextlib import contextmanager
from dataclasses import asdict, is_dataclass
from datetime import UTC, date, datetime, time as dt_time
from pathlib import Path
from typing import Any, Callable, Optional

from filelock import FileLock

JSONValue = Any
Serializer = Callable[[Any], JSONValue]
Deserializer = Callable[[JSONValue], Any]


class aiodict(MutableMapping[str, Any]):
    """A fast JSON-backed dictionary with in-memory caching, autosave, TTL,
    atomic writes, and optional namespacing.

    Parameters
    ----------
    path:
        Path to the JSON file.
    autosave:
        Whether to debounce writes and save automatically after mutations.
    autosave_delay:
        Seconds to wait before flushing a pending write.
    create_backup:
        Whether to keep a ``.bak`` copy of the previous file on each save.
    serializer:
        Optional callable to convert non-JSON-native values before encoding.
    deserializer:
        Optional callable applied to values after decoding.
    indent:
        JSON indentation. Use ``None`` for compact output.
    sort_keys:
        Whether to sort keys in the saved JSON.
    cleanup_expired_on_load:
        Whether to drop expired keys during initialization.
    lock_timeout:
        Max seconds to wait for a filesystem lock during reads/writes.
    encoding:
        File encoding.
    """

    FILE_VERSION = 1

    def __init__(
        self,
        path: str | os.PathLike[str] = "db.json",
        *,
        autosave: bool = True,
        autosave_delay: float = 0.35,
        create_backup: bool = True,
        serializer: Optional[Serializer] = None,
        deserializer: Optional[Deserializer] = None,
        indent: int | None = None,
        sort_keys: bool = False,
        cleanup_expired_on_load: bool = True,
        lock_timeout: float = 10.0,
        encoding: str = "utf-8",
    ) -> None:
        self.path = Path(path)
        self.lock_path = self.path.with_suffix(self.path.suffix + ".lock")
        self._file_lock = FileLock(str(self.lock_path), timeout=lock_timeout)
        self._mutex = threading.RLock()
        self._timer: threading.Timer | None = None
        self._closed = False
        self._autosave_suspended = 0

        self.autosave = autosave
        self.autosave_delay = float(autosave_delay)
        self.create_backup = create_backup
        self.serializer = serializer
        self.deserializer = deserializer
        self.indent = indent
        self.sort_keys = sort_keys
        self.cleanup_expired_on_load = cleanup_expired_on_load
        self.encoding = encoding

        self._data: dict[str, dict[str, Any]] = {}
        self._dirty = False

        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._load()

    # -------------------------
    # Internal lifecycle helpers
    # -------------------------
    def _ensure_open(self) -> None:
        if self._closed:
            raise RuntimeError("aiodict is closed")

    def _load(self) -> None:
        with self._mutex:
            if not self.path.exists():
                self._data = {}
                self._dirty = True
                self.flush()
                return

            with self._file_lock:
                raw = self.path.read_text(encoding=self.encoding).strip()

            if not raw:
                self._data = {}
                self._dirty = False
                return

            payload = json.loads(raw)
            if isinstance(payload, dict) and "data" in payload and "version" in payload:
                data = payload.get("data", {})
            else:
                # Backward-compatible plain-dict mode
                data = payload

            if not isinstance(data, dict):
                raise ValueError("Stored payload must contain a JSON object")

            normalized: dict[str, dict[str, Any]] = {}
            for key, record in data.items():
                if isinstance(record, dict) and "value" in record:
                    value = record.get("value")
                    expires_at = record.get("expires_at")
                else:
                    value = record
                    expires_at = None
                if self.deserializer is not None:
                    value = self.deserializer(value)
                normalized[str(key)] = {"value": value, "expires_at": expires_at}

            self._data = normalized
            if self.cleanup_expired_on_load and self.cleanup_expired() > 0:
                self.flush()
            else:
                self._dirty = False

    def _json_default(self, value: Any) -> Any:
        if self.serializer is not None:
            return self.serializer(value)

        if is_dataclass(value):
            return asdict(value)
        if isinstance(value, (datetime, date, dt_time)):
            return value.isoformat()
        if isinstance(value, Path):
            return str(value)
        if isinstance(value, set):
            return list(value)
        if isinstance(value, tuple):
            return list(value)
        raise TypeError(f"Object of type {type(value).__name__!s} is not JSON serializable")

    def _payload(self) -> dict[str, Any]:
        serializable_data = {
            key: {
                "value": record["value"],
                "expires_at": record.get("expires_at"),
            }
            for key, record in self._data.items()
            if not self._is_expired_record(record)
        }
        return {
            "version": self.FILE_VERSION,
            "updated_at": datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
            "data": serializable_data,
        }

    def _schedule_flush(self) -> None:
        if not self.autosave or self._autosave_suspended > 0:
            return

        with self._mutex:
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(self.autosave_delay, self.flush)
            self._timer.daemon = True
            self._timer.start()

    def _cancel_timer(self) -> None:
        with self._mutex:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None

    def _is_expired_record(self, record: dict[str, Any]) -> bool:
        expires_at = record.get("expires_at")
        return expires_at is not None and expires_at <= time.time()

    def _purge_if_expired(self, key: str) -> bool:
        record = self._data.get(key)
        if record is None:
            return False
        if self._is_expired_record(record):
            del self._data[key]
            self._dirty = True
            self._schedule_flush()
            return True
        return False

    def _get_record(self, key: str) -> dict[str, Any]:
        self._ensure_open()
        with self._mutex:
            if self._purge_if_expired(key):
                raise KeyError(key)
            return self._data[key]

    def _set_record(self, key: str, value: Any, ttl: float | None = None) -> None:
        if ttl is not None and ttl <= 0:
            raise ValueError("ttl must be greater than 0")
        expires_at = None if ttl is None else time.time() + float(ttl)
        with self._mutex:
            self._data[str(key)] = {"value": value, "expires_at": expires_at}
            self._dirty = True
        self._schedule_flush()

    # -------------------------
    # MutableMapping interface
    # -------------------------
    def __getitem__(self, key: str) -> Any:
        return self._get_record(str(key))["value"]

    def __setitem__(self, key: str, value: Any) -> None:
        self.set(str(key), value)

    def __delitem__(self, key: str) -> None:
        self._ensure_open()
        with self._mutex:
            self._purge_if_expired(str(key))
            del self._data[str(key)]
            self._dirty = True
        self._schedule_flush()

    def __iter__(self) -> Iterator[str]:
        self._ensure_open()
        keys = list(self._data.keys())
        for key in keys:
            if not self._purge_if_expired(key):
                yield key

    def __len__(self) -> int:
        self.cleanup_expired()
        return len(self._data)

    def __repr__(self) -> str:
        return f"aiodict(path={str(self.path)!r}, size={len(self)})"

    # -------------------------
    # Core operations
    # -------------------------
    def set(self, key: str, value: Any, *, ttl: float | None = None) -> None:
        self._ensure_open()
        self._set_record(key, value, ttl=ttl)

    def get(self, key: str, default: Any = None) -> Any:
        try:
            return self[key]
        except KeyError:
            return default

    def pop(self, key: str, default: Any = ...):
        self._ensure_open()
        with self._mutex:
            self._purge_if_expired(str(key))
            if default is ...:
                value = self._data.pop(str(key))["value"]
            else:
                record = self._data.pop(str(key), None)
                value = default if record is None else record["value"]
            self._dirty = True
        self._schedule_flush()
        return value

    def setdefault(self, key: str, default: Any = None) -> Any:
        self._ensure_open()
        with self._mutex:
            if self._purge_if_expired(str(key)) or str(key) not in self._data:
                self._data[str(key)] = {"value": default, "expires_at": None}
                self._dirty = True
                self._schedule_flush()
                return default
            return self._data[str(key)]["value"]

    def update(self, other: MutableMapping[str, Any] | dict[str, Any] | Iterator[tuple[str, Any]] = (), /, **kwargs: Any) -> None:  # type: ignore[override]
        self._ensure_open()
        if hasattr(other, "items"):
            items = list(other.items())  # type: ignore[arg-type]
        else:
            items = list(other)
        items.extend(kwargs.items())

        with self._mutex:
            for key, value in items:
                self._data[str(key)] = {"value": value, "expires_at": None}
            self._dirty = True
        self._schedule_flush()

    def clear(self) -> None:  # type: ignore[override]
        self._ensure_open()
        with self._mutex:
            self._data.clear()
            self._dirty = True
        self._schedule_flush()

    def exists(self, key: str) -> bool:
        self._ensure_open()
        with self._mutex:
            return not self._purge_if_expired(str(key)) and str(key) in self._data

    def copy(self) -> dict[str, Any]:
        self.cleanup_expired()
        with self._mutex:
            return {key: record["value"] for key, record in self._data.items()}

    def keys(self):  # type: ignore[override]
        return list(iter(self))

    def values(self):  # type: ignore[override]
        return [self[key] for key in self]

    def items(self):  # type: ignore[override]
        return [(key, self[key]) for key in self]

    # -------------------------
    # Extended helpers
    # -------------------------
    def mset(self, mapping: dict[str, Any], *, ttl: float | None = None) -> None:
        self._ensure_open()
        with self._mutex:
            expires_at = None if ttl is None else time.time() + float(ttl)
            for key, value in mapping.items():
                self._data[str(key)] = {"value": value, "expires_at": expires_at}
            self._dirty = True
        self._schedule_flush()

    def mget(self, keys: list[str] | tuple[str, ...], default: Any = None) -> list[Any]:
        return [self.get(key, default) for key in keys]

    def incr(self, key: str, amount: int | float = 1, *, ttl: float | None = None) -> int | float:
        self._ensure_open()
        with self._mutex:
            current = self.get(key, 0)
            if not isinstance(current, (int, float)) or isinstance(current, bool):
                raise TypeError(f"Value for {key!r} is not numeric")
            new_value = current + amount
            expires_at = None
            if key in self._data:
                expires_at = self._data[key].get("expires_at")
            if ttl is not None:
                expires_at = time.time() + float(ttl)
            self._data[str(key)] = {"value": new_value, "expires_at": expires_at}
            self._dirty = True
        self._schedule_flush()
        return new_value

    def append(self, key: str, value: Any, *, unique: bool = False, ttl: float | None = None) -> list[Any]:
        self._ensure_open()
        with self._mutex:
            current = self.get(key, [])
            if not isinstance(current, list):
                raise TypeError(f"Value for {key!r} is not a list")
            if not unique or value not in current:
                current.append(value)
            expires_at = self._data.get(key, {}).get("expires_at")
            if ttl is not None:
                expires_at = time.time() + float(ttl)
            self._data[str(key)] = {"value": current, "expires_at": expires_at}
            self._dirty = True
        self._schedule_flush()
        return current

    def extend(self, key: str, values: list[Any] | tuple[Any, ...], *, unique: bool = False, ttl: float | None = None) -> list[Any]:
        self._ensure_open()
        with self._mutex:
            current = self.get(key, [])
            if not isinstance(current, list):
                raise TypeError(f"Value for {key!r} is not a list")
            if unique:
                existing = set(current)
                for value in values:
                    if value not in existing:
                        current.append(value)
                        existing.add(value)
            else:
                current.extend(values)
            expires_at = self._data.get(key, {}).get("expires_at")
            if ttl is not None:
                expires_at = time.time() + float(ttl)
            self._data[str(key)] = {"value": current, "expires_at": expires_at}
            self._dirty = True
        self._schedule_flush()
        return current

    def remove(self, key: str, value: Any, *, all_occurrences: bool = False) -> list[Any]:
        self._ensure_open()
        with self._mutex:
            current = self[key]
            if not isinstance(current, list):
                raise TypeError(f"Value for {key!r} is not a list")
            if all_occurrences:
                current = [item for item in current if item != value]
            else:
                current.remove(value)
            expires_at = self._data[key].get("expires_at")
            self._data[str(key)] = {"value": current, "expires_at": expires_at}
            self._dirty = True
        self._schedule_flush()
        return current

    def expire(self, key: str, ttl: float) -> None:
        self._ensure_open()
        if ttl <= 0:
            raise ValueError("ttl must be greater than 0")
        with self._mutex:
            record = self._get_record(str(key))
            record["expires_at"] = time.time() + float(ttl)
            self._dirty = True
        self._schedule_flush()

    def ttl(self, key: str) -> float | None:
        self._ensure_open()
        with self._mutex:
            if self._purge_if_expired(str(key)) or str(key) not in self._data:
                raise KeyError(key)
            expires_at = self._data[str(key)].get("expires_at")
            if expires_at is None:
                return None
            remaining = expires_at - time.time()
            if remaining <= 0:
                self._purge_if_expired(str(key))
                raise KeyError(key)
            return remaining

    def persist(self, key: str) -> None:
        self._ensure_open()
        with self._mutex:
            record = self._get_record(str(key))
            record["expires_at"] = None
            self._dirty = True
        self._schedule_flush()

    def cleanup_expired(self) -> int:
        self._ensure_open()
        removed = 0
        with self._mutex:
            expired_keys = [key for key, record in self._data.items() if self._is_expired_record(record)]
            for key in expired_keys:
                del self._data[key]
            if expired_keys:
                self._dirty = True
                removed = len(expired_keys)
        if removed:
            self._schedule_flush()
        return removed

    def touch(self, key: str, ttl: float | None = None) -> None:
        self._ensure_open()
        with self._mutex:
            record = self._get_record(str(key))
            if ttl is None:
                if record.get("expires_at") is None:
                    return
                remaining = max(record["expires_at"] - time.time(), 0.001)
                record["expires_at"] = time.time() + remaining
            else:
                if ttl <= 0:
                    raise ValueError("ttl must be greater than 0")
                record["expires_at"] = time.time() + float(ttl)
            self._dirty = True
        self._schedule_flush()

    def stats(self) -> dict[str, Any]:
        self.cleanup_expired()
        file_size = self.path.stat().st_size if self.path.exists() else 0
        with self._mutex:
            ttl_keys = sum(1 for record in self._data.values() if record.get("expires_at") is not None)
            return {
                "keys": len(self._data),
                "ttl_keys": ttl_keys,
                "autosave": self.autosave,
                "autosave_delay": self.autosave_delay,
                "file_path": str(self.path),
                "file_size_bytes": file_size,
                "dirty": self._dirty,
            }

    # -------------------------
    # Persistence
    # -------------------------
    def flush(self) -> None:
        self._ensure_open()
        with self._mutex:
            self._cancel_timer()
            self.cleanup_expired()
            if not self._dirty and self.path.exists():
                return

            payload = self._payload()
            serialized = json.dumps(
                payload,
                ensure_ascii=False,
                indent=self.indent,
                sort_keys=self.sort_keys,
                separators=(",", ":") if self.indent is None else None,
                default=self._json_default,
            )

            tmp_fd, tmp_name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=str(self.path.parent))
            try:
                with os.fdopen(tmp_fd, "w", encoding=self.encoding) as tmp_file:
                    tmp_file.write(serialized)
                    tmp_file.flush()
                    os.fsync(tmp_file.fileno())

                with self._file_lock:
                    if self.create_backup and self.path.exists():
                        backup_path = self.path.with_suffix(self.path.suffix + ".bak")
                        shutil.copy2(self.path, backup_path)
                    os.replace(tmp_name, self.path)
                self._dirty = False
            finally:
                if os.path.exists(tmp_name):
                    os.remove(tmp_name)

    def reload(self) -> None:
        self._ensure_open()
        self._cancel_timer()
        self._load()

    def close(self) -> None:
        if self._closed:
            return
        self._cancel_timer()
        self.flush()
        self._closed = True

    def __enter__(self) -> "aiodict":
        self._ensure_open()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @contextmanager
    def transaction(self):
        """Batch multiple mutations and flush once on success."""
        self._ensure_open()
        with self._mutex:
            self._autosave_suspended += 1
        try:
            yield self
        except Exception:
            with self._mutex:
                self._autosave_suspended = max(0, self._autosave_suspended - 1)
            raise
        else:
            with self._mutex:
                self._autosave_suspended = max(0, self._autosave_suspended - 1)
            self.flush()

    # -------------------------
    # Namespacing
    # -------------------------
    def namespace(self, prefix: str, separator: str = ":") -> "Namespacedaiodict":
        return Namespacedaiodict(self, prefix=prefix, separator=separator)


class Namespacedaiodict(MutableMapping[str, Any]):
    """A light view that prefixes all keys inside a parent ``aiodict``."""

    def __init__(self, parent: aiodict, *, prefix: str, separator: str = ":") -> None:
        self.parent = parent
        self.prefix = prefix
        self.separator = separator

    def _wrap(self, key: str) -> str:
        return f"{self.prefix}{self.separator}{key}"

    def _unwrap(self, key: str) -> str:
        return key[len(self.prefix + self.separator):]

    def __getitem__(self, key: str) -> Any:
        return self.parent[self._wrap(key)]

    def __setitem__(self, key: str, value: Any) -> None:
        self.parent[self._wrap(key)] = value

    def __delitem__(self, key: str) -> None:
        del self.parent[self._wrap(key)]

    def __iter__(self) -> Iterator[str]:
        prefix = self.prefix + self.separator
        for key in self.parent:
            if key.startswith(prefix):
                yield self._unwrap(key)

    def __len__(self) -> int:
        return sum(1 for _ in self)

    def set(self, key: str, value: Any, *, ttl: float | None = None) -> None:
        self.parent.set(self._wrap(key), value, ttl=ttl)

    def get(self, key: str, default: Any = None) -> Any:
        return self.parent.get(self._wrap(key), default)

    def pop(self, key: str, default: Any = ...):
        return self.parent.pop(self._wrap(key), default)

    def clear(self) -> None:  # type: ignore[override]
        for key in list(self):
            del self[key]

    def keys(self):  # type: ignore[override]
        return list(iter(self))

    def values(self):  # type: ignore[override]
        return [self[key] for key in self]

    def items(self):  # type: ignore[override]
        return [(key, self[key]) for key in self]

    def incr(self, key: str, amount: int | float = 1, *, ttl: float | None = None) -> int | float:
        return self.parent.incr(self._wrap(key), amount, ttl=ttl)

    def append(self, key: str, value: Any, *, unique: bool = False, ttl: float | None = None) -> list[Any]:
        return self.parent.append(self._wrap(key), value, unique=unique, ttl=ttl)

    def extend(self, key: str, values: list[Any] | tuple[Any, ...], *, unique: bool = False, ttl: float | None = None) -> list[Any]:
        return self.parent.extend(self._wrap(key), values, unique=unique, ttl=ttl)

    def remove(self, key: str, value: Any, *, all_occurrences: bool = False) -> list[Any]:
        return self.parent.remove(self._wrap(key), value, all_occurrences=all_occurrences)

    def exists(self, key: str) -> bool:
        return self.parent.exists(self._wrap(key))

    def expire(self, key: str, ttl: float) -> None:
        self.parent.expire(self._wrap(key), ttl)

    def ttl(self, key: str) -> float | None:
        return self.parent.ttl(self._wrap(key))

    def persist(self, key: str) -> None:
        self.parent.persist(self._wrap(key))

    def cleanup_expired(self) -> int:
        removed = 0
        for key in list(self):
            wrapped = self._wrap(key)
            try:
                self.parent.ttl(wrapped)
            except KeyError:
                removed += 1
        return removed
