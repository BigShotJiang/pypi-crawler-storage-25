import time
from pathlib import Path

from aiodict import aiodict


def test_basic_set_get(tmp_path: Path):
    db = aiodict(tmp_path / "db.json", autosave=False)
    db["a"] = 1
    assert db["a"] == 1
    db.flush()
    db.close()


def test_persistence(tmp_path: Path):
    path = tmp_path / "db.json"
    db = aiodict(path, autosave=False)
    db["name"] = "Ali"
    db.flush()
    db.close()

    db2 = aiodict(path, autosave=False)
    assert db2["name"] == "Ali"
    db2.close()


def test_ttl_expiration(tmp_path: Path):
    db = aiodict(tmp_path / "db.json", autosave=False)
    db.set("otp", "1234", ttl=0.1)
    time.sleep(0.15)
    assert db.get("otp") is None
    db.close()


def test_namespace(tmp_path: Path):
    db = aiodict(tmp_path / "db.json", autosave=False)
    users = db.namespace("users")
    users["1"] = {"name": "Alice"}
    assert db["users:1"] == {"name": "Alice"}
    assert users["1"] == {"name": "Alice"}
    db.close()


def test_transaction(tmp_path: Path):
    db = aiodict(tmp_path / "db.json", autosave=True, autosave_delay=1.0)
    with db.transaction():
        db["a"] = 1
        db["b"] = 2
    assert db["a"] == 1
    assert db["b"] == 2
    db.close()
