"""Core dataclasses passed between Raggedy components.

Everything user-facing or cross-protocol lives here; adapter-internal
structures stay in their own modules.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import StrEnum
from typing import Any


@dataclass(slots=True)
class Document:
    """An input document submitted to `Raggedy.ingest`.

    `tags` is a free-form string map used for filtering at retrieval time.
    `metadata` is opaque to Raggedy and round-tripped on each chunk.
    """

    id: str
    text: str
    tags: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class Chunk:
    """A chunk of a document, ready for embedding and storage."""

    id: str
    document_id: str
    namespace: str
    text: str
    chunk_index: int
    start_char: int
    end_char: int
    token_count: int
    overlap_tokens: int = 0
    start_page: int | None = None
    end_page: int | None = None
    tags: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    embedding: list[float] | None = None


@dataclass(slots=True)
class ScoredChunk:
    """A chunk returned from a vector-store query with its similarity score."""

    chunk: Chunk
    score: float


@dataclass(slots=True)
class Source:
    """A single source citation surfaced in a `QueryResult`."""

    index: int
    document_id: str
    chunk_id: str
    score: float
    text_preview: str
    start_char: int
    end_char: int
    start_page: int | None = None
    end_page: int | None = None
    tags: dict[str, str] = field(default_factory=dict)


@dataclass(slots=True)
class QueryResult:
    """The result of `Raggedy.query` / `RAGPipeline.query`."""

    answer: str
    sources: list[Source]
    run_id: str
    cost_usd: float
    prompt_tokens: int
    completion_tokens: int
    latency_ms: int
    finish_reason: str
    model: str
    provider: str
    prompt_template_version: str


@dataclass(slots=True)
class LLMRequest:
    """Input to `LLMProvider.complete`."""

    system: str
    user: str
    model: str
    max_tokens: int = 1024
    temperature: float = 0.2
    stop: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class LLMResponse:
    """Output from `LLMProvider.complete`."""

    text: str
    prompt_tokens: int
    completion_tokens: int
    latency_ms: int
    finish_reason: str
    model: str
    provider: str
    safety_ratings: dict[str, Any] = field(default_factory=dict)
    raw: dict[str, Any] = field(default_factory=dict)


class PIIType(StrEnum):
    SSN = "ssn"
    EMAIL = "email"
    PHONE = "phone"
    DOB = "dob"
    ADDRESS = "address"
    CREDIT_CARD = "credit_card"
    IP_ADDRESS = "ip_address"
    PASSPORT = "passport"
    DRIVERS_LICENSE = "drivers_license"
    BANK_ACCOUNT = "bank_account"


@dataclass(slots=True)
class PIIMatch:
    pii_type: PIIType
    original_value: str
    start_pos: int
    end_pos: int
    confidence: float


@dataclass(slots=True)
class RedactionResult:
    """Result of redacting text.

    `redaction_map` maps placeholders back to originals. It is
    **memory-only** — callers must never persist it.
    """

    redacted_text: str
    matches: list[PIIMatch]
    redaction_map: dict[str, str]
    policy_version: str
    patterns_version: str

    @property
    def pii_count(self) -> int:
        return len(self.matches)

    @property
    def counts_by_type(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for m in self.matches:
            out[m.pii_type.value] = out.get(m.pii_type.value, 0) + 1
        return out


@dataclass(slots=True)
class RunRecord:
    """An audit record covering one `query` or `ingest` call."""

    run_id: str
    namespace: str
    kind: str
    started_at: datetime
    finished_at: datetime | None = None
    status: str = "running"
    query: str | None = None
    config_snapshot: dict[str, Any] = field(default_factory=dict)
    artifacts: list[dict[str, Any]] = field(default_factory=list)
    result: dict[str, Any] | None = None
    error: str | None = None
    cost_usd: float = 0.0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    latency_ms: int = 0
    tags: dict[str, str] = field(default_factory=dict)


def utcnow() -> datetime:
    return datetime.now(UTC)
