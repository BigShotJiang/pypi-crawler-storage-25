"""SQLite-backed `RunRecorder` — `pip install raggedy[sqlitevec]`.

Two tables: `raggedy_runs` for the run header and `raggedy_artifacts` for
the per-run artifact stream (redaction stats, retrieved chunks, prompt
metadata). Foreign-key cascade on delete; foreign keys are turned on per
connection because SQLite ships them off by default.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from typing import Any

from raggedy.errors import ConfigError
from raggedy.types import RunRecord, utcnow
from raggedy.util.ids import new_run_id


class SqliteRunRecorder:
    def __init__(self, url: str | None = None) -> None:
        try:
            import aiosqlite  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "SqliteRunRecorder requires aiosqlite. "
                "Install with: pip install 'raggedy[sqlitevec]'"
            ) from e
        self._path = _parse_url(url) or "./raggedy_runs.db"
        self._conn: Any = None
        self._initialized = False

    async def _get_conn(self) -> Any:
        if self._conn is not None:
            return self._conn
        import aiosqlite

        try:
            self._conn = await aiosqlite.connect(self._path)
            await self._conn.execute("PRAGMA foreign_keys = ON")
        except Exception as e:
            raise ConfigError(
                f"SqliteRunRecorder could not open {self._path!r}: "
                f"{type(e).__name__}: {e}"
            ) from e
        if not self._initialized:
            try:
                await self._conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS raggedy_runs (
                        run_id TEXT PRIMARY KEY,
                        namespace TEXT NOT NULL,
                        kind TEXT NOT NULL,
                        started_at TEXT NOT NULL,
                        finished_at TEXT,
                        status TEXT NOT NULL DEFAULT 'running',
                        query TEXT,
                        config_snapshot_json TEXT NOT NULL DEFAULT '{}',
                        result_json TEXT,
                        error TEXT,
                        cost_usd REAL NOT NULL DEFAULT 0,
                        prompt_tokens INTEGER NOT NULL DEFAULT 0,
                        completion_tokens INTEGER NOT NULL DEFAULT 0,
                        latency_ms INTEGER NOT NULL DEFAULT 0,
                        tags_json TEXT NOT NULL DEFAULT '{}'
                    )
                    """
                )
                await self._conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_raggedy_runs_ns_started "
                    "ON raggedy_runs(namespace, started_at DESC)"
                )
                await self._conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS raggedy_artifacts (
                        run_id TEXT NOT NULL,
                        idx INTEGER NOT NULL,
                        kind TEXT NOT NULL,
                        payload_json TEXT NOT NULL,
                        ts TEXT NOT NULL,
                        PRIMARY KEY (run_id, idx),
                        FOREIGN KEY (run_id) REFERENCES raggedy_runs(run_id) ON DELETE CASCADE
                    )
                    """
                )
                await self._conn.commit()
                self._initialized = True
            except Exception as e:
                raise ConfigError(
                    f"SqliteRunRecorder schema init failed: {type(e).__name__}: {e}"
                ) from e
        return self._conn

    async def start_run(
        self,
        *,
        namespace: str,
        kind: str,
        query: str | None = None,
        config_snapshot: dict[str, Any] | None = None,
        tags: dict[str, str] | None = None,
    ) -> str:
        run_id = new_run_id()
        conn = await self._get_conn()
        try:
            await conn.execute(
                """
                INSERT INTO raggedy_runs
                    (run_id, namespace, kind, started_at, status,
                     query, config_snapshot_json, tags_json)
                VALUES (?, ?, ?, ?, 'running', ?, ?, ?)
                """,
                (
                    run_id,
                    namespace,
                    kind,
                    utcnow().isoformat(),
                    query,
                    json.dumps(config_snapshot or {}, default=str),
                    json.dumps(tags or {}),
                ),
            )
            await conn.commit()
        except Exception as e:
            raise ConfigError(
                f"SqliteRunRecorder start_run failed: {type(e).__name__}: {e}"
            ) from e
        return run_id

    async def record_artifact(
        self, run_id: str, kind: str, payload: dict[str, Any]
    ) -> None:
        conn = await self._get_conn()
        try:
            # Use a subquery to compute the next idx atomically rather than
            # doing a separate SELECT + INSERT.
            await conn.execute(
                """
                INSERT INTO raggedy_artifacts (run_id, idx, kind, payload_json, ts)
                VALUES (
                    ?,
                    COALESCE((SELECT MAX(idx) + 1 FROM raggedy_artifacts WHERE run_id = ?), 0),
                    ?, ?, ?
                )
                """,
                (run_id, run_id, kind, json.dumps(payload, default=str), utcnow().isoformat()),
            )
            await conn.commit()
        except Exception as e:
            raise ConfigError(
                f"SqliteRunRecorder record_artifact failed: {type(e).__name__}: {e}"
            ) from e

    async def finish_run(
        self,
        run_id: str,
        *,
        status: str,
        result: dict[str, Any] | None = None,
        error: str | None = None,
        cost_usd: float = 0.0,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        latency_ms: int = 0,
    ) -> None:
        conn = await self._get_conn()
        try:
            await conn.execute(
                """
                UPDATE raggedy_runs
                SET finished_at = ?, status = ?, result_json = ?, error = ?,
                    cost_usd = ?, prompt_tokens = ?, completion_tokens = ?,
                    latency_ms = ?
                WHERE run_id = ?
                """,
                (
                    utcnow().isoformat(),
                    status,
                    json.dumps(result, default=str) if result is not None else None,
                    error,
                    float(cost_usd),
                    int(prompt_tokens),
                    int(completion_tokens),
                    int(latency_ms),
                    run_id,
                ),
            )
            await conn.commit()
        except Exception as e:
            raise ConfigError(
                f"SqliteRunRecorder finish_run failed: {type(e).__name__}: {e}"
            ) from e

    async def list_runs(
        self, *, namespace: str | None = None, limit: int = 100
    ) -> list[RunRecord]:
        conn = await self._get_conn()
        try:
            if namespace is None:
                cur = await conn.execute(
                    "SELECT * FROM raggedy_runs ORDER BY started_at DESC LIMIT ?",
                    (limit,),
                )
            else:
                cur = await conn.execute(
                    "SELECT * FROM raggedy_runs WHERE namespace = ? "
                    "ORDER BY started_at DESC LIMIT ?",
                    (namespace, limit),
                )
            rows = await cur.fetchall()
        except Exception as e:
            raise ConfigError(
                f"SqliteRunRecorder list_runs failed: {type(e).__name__}: {e}"
            ) from e
        out: list[RunRecord] = []
        for row in rows:
            run_id = row[0]
            artifacts = await self._load_artifacts(run_id)
            out.append(_row_to_record(row, artifacts))
        return out

    async def get(self, run_id: str) -> RunRecord | None:
        conn = await self._get_conn()
        try:
            cur = await conn.execute(
                "SELECT * FROM raggedy_runs WHERE run_id = ?", (run_id,)
            )
            row = await cur.fetchone()
        except Exception as e:
            raise ConfigError(
                f"SqliteRunRecorder get failed: {type(e).__name__}: {e}"
            ) from e
        if row is None:
            return None
        artifacts = await self._load_artifacts(run_id)
        return _row_to_record(row, artifacts)

    async def _load_artifacts(self, run_id: str) -> list[dict[str, Any]]:
        conn = await self._get_conn()
        cur = await conn.execute(
            "SELECT kind, payload_json, ts FROM raggedy_artifacts "
            "WHERE run_id = ? ORDER BY idx",
            (run_id,),
        )
        rows = await cur.fetchall()
        out: list[dict[str, Any]] = []
        for kind, payload_json, ts in rows:
            try:
                payload = json.loads(payload_json) if payload_json else {}
            except Exception:
                payload = {}
            out.append({"kind": kind, "payload": payload, "ts": ts})
        return out

    async def aclose(self) -> None:
        if self._conn is not None:
            try:
                await self._conn.close()
            finally:
                self._conn = None


def _parse_url(url: str | None) -> str | None:
    if not url:
        return None
    if url.startswith("sqlite:///"):
        return url[len("sqlite:///"):]
    if url.startswith("sqlite://"):
        return url[len("sqlite://"):]
    return url


def _safe_json(raw: Any, default: Any) -> Any:
    if raw is None:
        return default
    if isinstance(raw, dict | list):
        return raw
    try:
        return json.loads(raw)
    except Exception:
        return default


def _parse_dt(s: str | None) -> datetime | None:
    if not s:
        return None
    try:
        return datetime.fromisoformat(s)
    except ValueError:
        return None


def _row_to_record(row: tuple[Any, ...], artifacts: list[dict[str, Any]]) -> RunRecord:
    (
        run_id, namespace, kind, started_at, finished_at, status,
        query, config_snapshot_json, result_json, error,
        cost_usd, prompt_tokens, completion_tokens, latency_ms, tags_json,
    ) = row
    started = _parse_dt(started_at) or datetime.now(UTC)
    return RunRecord(
        run_id=run_id,
        namespace=namespace,
        kind=kind,
        started_at=started,
        finished_at=_parse_dt(finished_at),
        status=status,
        query=query,
        config_snapshot=_safe_json(config_snapshot_json, {}),
        artifacts=artifacts,
        result=_safe_json(result_json, None),
        error=error,
        cost_usd=float(cost_usd or 0.0),
        prompt_tokens=int(prompt_tokens or 0),
        completion_tokens=int(completion_tokens or 0),
        latency_ms=int(latency_ms or 0),
        tags=_safe_json(tags_json, {}),
    )
