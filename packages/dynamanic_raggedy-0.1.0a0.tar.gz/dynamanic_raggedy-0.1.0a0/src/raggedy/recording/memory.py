"""In-memory `RunRecorder` — default audit-trail backend.

Holds at most `maxlen` recent records in a deque. The library does not
ship persistence by default; pick `SQLiteRunRecorder` (phase 2) when the
host process is short-lived or you need to query historical runs.
"""

from __future__ import annotations

import asyncio
from collections import deque
from typing import Any

from raggedy.types import RunRecord, utcnow
from raggedy.util.ids import new_run_id


class InMemoryRunRecorder:
    def __init__(self, maxlen: int = 1000) -> None:
        self._runs: dict[str, RunRecord] = {}
        self._order: deque[str] = deque(maxlen=maxlen)
        self._lock = asyncio.Lock()

    async def start_run(
        self,
        *,
        namespace: str,
        kind: str,
        query: str | None = None,
        config_snapshot: dict[str, Any] | None = None,
        tags: dict[str, str] | None = None,
    ) -> str:
        run_id = new_run_id()
        record = RunRecord(
            run_id=run_id,
            namespace=namespace,
            kind=kind,
            started_at=utcnow(),
            query=query,
            config_snapshot=dict(config_snapshot or {}),
            tags=dict(tags or {}),
        )
        async with self._lock:
            if len(self._order) == self._order.maxlen:
                evicted = self._order[0]
                self._runs.pop(evicted, None)
            self._runs[run_id] = record
            self._order.append(run_id)
        return run_id

    async def record_artifact(self, run_id: str, kind: str, payload: dict[str, Any]) -> None:
        async with self._lock:
            record = self._runs.get(run_id)
            if record is None:
                return
            record.artifacts.append({"kind": kind, "payload": payload, "ts": utcnow()})

    async def finish_run(
        self,
        run_id: str,
        *,
        status: str,
        result: dict[str, Any] | None = None,
        error: str | None = None,
        cost_usd: float = 0.0,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        latency_ms: int = 0,
    ) -> None:
        async with self._lock:
            record = self._runs.get(run_id)
            if record is None:
                return
            record.finished_at = utcnow()
            record.status = status
            record.result = result
            record.error = error
            record.cost_usd = cost_usd
            record.prompt_tokens = prompt_tokens
            record.completion_tokens = completion_tokens
            record.latency_ms = latency_ms

    async def list_runs(
        self, *, namespace: str | None = None, limit: int = 100
    ) -> list[RunRecord]:
        async with self._lock:
            out: list[RunRecord] = []
            for run_id in reversed(self._order):
                record = self._runs.get(run_id)
                if record is None:
                    continue
                if namespace is not None and record.namespace != namespace:
                    continue
                out.append(record)
                if len(out) >= limit:
                    break
            return out

    async def get(self, run_id: str) -> RunRecord | None:
        async with self._lock:
            return self._runs.get(run_id)
