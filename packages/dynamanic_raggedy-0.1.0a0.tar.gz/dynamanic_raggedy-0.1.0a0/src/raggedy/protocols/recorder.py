from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from raggedy.types import RunRecord


@runtime_checkable
class RunRecorder(Protocol):
    async def start_run(
        self,
        *,
        namespace: str,
        kind: str,
        query: str | None = None,
        config_snapshot: dict[str, Any] | None = None,
        tags: dict[str, str] | None = None,
    ) -> str: ...

    async def record_artifact(
        self, run_id: str, kind: str, payload: dict[str, Any]
    ) -> None: ...

    async def finish_run(
        self,
        run_id: str,
        *,
        status: str,
        result: dict[str, Any] | None = None,
        error: str | None = None,
        cost_usd: float = 0.0,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        latency_ms: int = 0,
    ) -> None: ...

    async def list_runs(
        self, *, namespace: str | None = None, limit: int = 100
    ) -> list[RunRecord]: ...

    async def get(self, run_id: str) -> RunRecord | None: ...
