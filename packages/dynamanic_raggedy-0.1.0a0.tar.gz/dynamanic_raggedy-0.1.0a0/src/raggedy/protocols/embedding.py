from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class EmbeddingBackend(Protocol):
    model_id: str

    # `dimension` is declared as a read-only property so both plain
    # attributes (e.g. `self.dimension = 384`) and `@property` definitions
    # (e.g. OllamaEmbedder where the dim is discovered lazily) satisfy the
    # protocol.
    @property
    def dimension(self) -> int: ...

    async def embed(self, text: str) -> list[float]: ...
    async def embed_batch(self, texts: list[str]) -> list[list[float]]: ...
