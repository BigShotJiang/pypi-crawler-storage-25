from __future__ import annotations

from typing import Protocol, runtime_checkable

from raggedy.types import PIIMatch, RedactionResult


@runtime_checkable
class PIIRedactor(Protocol):
    policy_version: str
    patterns_version: str

    def detect(self, text: str) -> list[PIIMatch]: ...
    def redact(self, text: str) -> RedactionResult: ...
