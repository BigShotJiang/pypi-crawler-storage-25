from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from raggedy.types import LLMRequest, LLMResponse


@dataclass(slots=True, frozen=True)
class ProviderCapabilities:
    supports_streaming: bool = False
    supports_tools: bool = False
    max_context_tokens: int = 8000
    extra: dict[str, object] = field(default_factory=dict)


@runtime_checkable
class LLMProvider(Protocol):
    name: str

    async def complete(self, request: LLMRequest) -> LLMResponse: ...

    def count_tokens(self, text: str) -> int: ...

    def estimate_cost(self, prompt_tokens: int, completion_tokens: int, *, model: str) -> float: ...

    @property
    def capabilities(self) -> ProviderCapabilities: ...
