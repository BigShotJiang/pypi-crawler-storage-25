from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class CostTracker(Protocol):
    async def check_limit(self, *, namespace: str, projected_cost_usd: float) -> None: ...
    async def record_usage(
        self,
        *,
        namespace: str,
        model: str,
        cost_usd: float,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> None: ...
    async def get_daily_cost(self, *, namespace: str) -> float: ...
