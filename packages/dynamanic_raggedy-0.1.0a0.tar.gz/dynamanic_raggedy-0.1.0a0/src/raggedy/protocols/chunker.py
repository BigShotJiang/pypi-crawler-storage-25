from __future__ import annotations

from typing import Protocol, runtime_checkable

from raggedy.types import Chunk, Document


@runtime_checkable
class Chunker(Protocol):
    strategy: str
    target_tokens: int
    overlap_tokens: int

    async def chunk(self, document: Document, *, namespace: str) -> list[Chunk]: ...
