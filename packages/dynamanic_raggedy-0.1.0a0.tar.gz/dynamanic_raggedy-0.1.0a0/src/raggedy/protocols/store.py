from __future__ import annotations

from typing import Protocol, runtime_checkable

from raggedy.types import Chunk, ScoredChunk


@runtime_checkable
class VectorStore(Protocol):
    async def upsert(self, chunks: list[Chunk]) -> None: ...

    async def query(
        self,
        vector: list[float],
        *,
        top_k: int,
        namespace: str,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> list[ScoredChunk]: ...

    async def delete(
        self,
        *,
        ids: list[str] | None = None,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> int: ...

    async def count(self, *, namespace: str | None = None) -> int: ...
