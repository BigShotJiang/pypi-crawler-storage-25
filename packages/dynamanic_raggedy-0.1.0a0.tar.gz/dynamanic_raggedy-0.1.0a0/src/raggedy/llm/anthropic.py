"""Anthropic LLM provider — requires `pip install raggedy[anthropic]`."""

from __future__ import annotations

import os
import time

from raggedy.cost.pricing import get_price
from raggedy.errors import ConfigError, ProviderError
from raggedy.protocols.llm import ProviderCapabilities
from raggedy.types import LLMRequest, LLMResponse
from raggedy.util.tokens import naive_token_count

DEFAULT_MODEL = "claude-haiku-4-5-20251001"


class AnthropicProvider:
    name = "anthropic"

    def __init__(
        self,
        model: str | None = None,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
    ) -> None:
        try:
            from anthropic import AsyncAnthropic
        except ImportError as e:
            raise ConfigError(
                "Anthropic SDK not installed. Install with: pip install 'raggedy[anthropic]'"
            ) from e
        key = api_key or os.getenv("ANTHROPIC_API_KEY")
        client_kwargs: dict[str, str] = {}
        if key:
            client_kwargs["api_key"] = key
        if base_url:
            client_kwargs["base_url"] = base_url
        self._client = AsyncAnthropic(**client_kwargs)
        self._model = model or DEFAULT_MODEL

    async def complete(self, request: LLMRequest) -> LLMResponse:
        started = time.perf_counter()
        try:
            response = await self._client.messages.create(
                model=request.model or self._model,
                system=request.system,
                messages=[{"role": "user", "content": request.user}],
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                stop_sequences=request.stop or None,
            )
        except Exception as e:
            raise ProviderError(
                f"Anthropic call failed: {e}", provider=self.name, retryable=True
            ) from e
        latency_ms = int((time.perf_counter() - started) * 1000)
        text = "".join(
            block.text for block in response.content if getattr(block, "type", None) == "text"
        )
        return LLMResponse(
            text=text,
            prompt_tokens=response.usage.input_tokens,
            completion_tokens=response.usage.output_tokens,
            latency_ms=latency_ms,
            finish_reason=response.stop_reason or "stop",
            model=response.model,
            provider=self.name,
            raw={"id": response.id, "stop_reason": response.stop_reason},
        )

    def count_tokens(self, text: str) -> int:
        # Anthropic's SDK exposes count_tokens via the API but each call costs
        # a network round-trip. For pipeline budget planning we accept the
        # ~4-chars-per-token heuristic. Override in subclass if needed.
        return naive_token_count(text)

    def estimate_cost(self, prompt_tokens: int, completion_tokens: int, *, model: str) -> float:
        price = get_price(model)
        return (prompt_tokens / 1000.0) * price.input_per_ktok + (
            completion_tokens / 1000.0
        ) * price.output_per_ktok

    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supports_streaming=True,
            supports_tools=True,
            max_context_tokens=200000,
        )
