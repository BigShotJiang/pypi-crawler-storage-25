"""Ollama LLM provider — uses base `httpx`, no optional extras needed."""

from __future__ import annotations

import os
import time
from typing import Any

import httpx

from raggedy.errors import ProviderError
from raggedy.protocols.llm import ProviderCapabilities
from raggedy.types import LLMRequest, LLMResponse
from raggedy.util.tokens import naive_token_count

DEFAULT_MODEL = "llama3.2"
DEFAULT_BASE_URL = "http://localhost:11434"


class OllamaProvider:
    name = "ollama"

    def __init__(
        self,
        model: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float = 120.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._model = model or DEFAULT_MODEL
        self._base_url = (base_url or os.getenv("OLLAMA_HOST") or DEFAULT_BASE_URL).rstrip("/")
        self._timeout = timeout
        self._client = client
        self._owns_client = client is None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self._timeout)
        return self._client

    async def complete(self, request: LLMRequest) -> LLMResponse:
        started = time.perf_counter()
        client = await self._get_client()
        options: dict[str, Any] = {
            "temperature": request.temperature,
            "num_predict": request.max_tokens,
        }
        if request.stop:
            options["stop"] = request.stop
        payload: dict[str, Any] = {
            "model": request.model or self._model,
            "messages": [
                {"role": "system", "content": request.system},
                {"role": "user", "content": request.user},
            ],
            "stream": False,
            "options": options,
        }
        try:
            resp = await client.post(f"{self._base_url}/api/chat", json=payload)
            resp.raise_for_status()
        except httpx.HTTPError as e:
            raise ProviderError(
                f"Ollama call failed: {e}", provider=self.name, retryable=True
            ) from e
        data = resp.json()
        latency_ms = int((time.perf_counter() - started) * 1000)
        message = data.get("message", {})
        return LLMResponse(
            text=message.get("content", ""),
            prompt_tokens=int(data.get("prompt_eval_count", 0) or 0),
            completion_tokens=int(data.get("eval_count", 0) or 0),
            latency_ms=latency_ms,
            finish_reason=data.get("done_reason") or ("stop" if data.get("done") else "length"),
            model=data.get("model") or self._model,
            provider=self.name,
            raw={k: data.get(k) for k in ("total_duration", "load_duration", "done_reason")},
        )

    def count_tokens(self, text: str) -> int:
        return naive_token_count(text)

    def estimate_cost(self, prompt_tokens: int, completion_tokens: int, *, model: str) -> float:
        # Ollama is local; tokens are free.
        return 0.0

    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supports_streaming=True,
            supports_tools=False,
            max_context_tokens=8000,
        )

    async def aclose(self) -> None:
        if self._client is not None and self._owns_client:
            await self._client.aclose()
            self._client = None
