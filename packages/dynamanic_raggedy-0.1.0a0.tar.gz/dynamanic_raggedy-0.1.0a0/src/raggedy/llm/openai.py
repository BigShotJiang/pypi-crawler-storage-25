"""OpenAI LLM provider — requires `pip install raggedy[openai]`."""

from __future__ import annotations

import os
import time
from typing import Any

from raggedy.cost.pricing import get_price
from raggedy.errors import ConfigError, ProviderError
from raggedy.protocols.llm import ProviderCapabilities
from raggedy.types import LLMRequest, LLMResponse
from raggedy.util.tokens import naive_token_count

DEFAULT_MODEL = "gpt-4o-mini"


class OpenAIProvider:
    name = "openai"

    def __init__(
        self,
        model: str | None = None,
        *,
        api_key: str | None = None,
        organization: str | None = None,
        base_url: str | None = None,
    ) -> None:
        try:
            from openai import AsyncOpenAI
        except ImportError as e:
            raise ConfigError(
                "OpenAI SDK not installed. Install with: pip install 'raggedy[openai]'"
            ) from e
        client_kwargs: dict[str, str] = {}
        key = api_key or os.getenv("OPENAI_API_KEY")
        if key:
            client_kwargs["api_key"] = key
        if organization:
            client_kwargs["organization"] = organization
        if base_url:
            client_kwargs["base_url"] = base_url
        self._client = AsyncOpenAI(**client_kwargs)
        self._model = model or DEFAULT_MODEL
        self._tiktoken_encoding = self._maybe_load_tiktoken(self._model)

    async def complete(self, request: LLMRequest) -> LLMResponse:
        started = time.perf_counter()
        try:
            response = await self._client.chat.completions.create(
                model=request.model or self._model,
                messages=[
                    {"role": "system", "content": request.system},
                    {"role": "user", "content": request.user},
                ],
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                stop=request.stop or None,
            )
        except Exception as e:
            raise ProviderError(
                f"OpenAI call failed: {e}", provider=self.name, retryable=True
            ) from e
        latency_ms = int((time.perf_counter() - started) * 1000)
        choice = response.choices[0]
        usage = response.usage
        return LLMResponse(
            text=choice.message.content or "",
            prompt_tokens=usage.prompt_tokens if usage else 0,
            completion_tokens=usage.completion_tokens if usage else 0,
            latency_ms=latency_ms,
            finish_reason=choice.finish_reason or "stop",
            model=response.model,
            provider=self.name,
            raw={"id": response.id},
        )

    def count_tokens(self, text: str) -> int:
        if self._tiktoken_encoding is not None:
            try:
                return len(self._tiktoken_encoding.encode(text))
            except Exception:
                pass
        return naive_token_count(text)

    def estimate_cost(self, prompt_tokens: int, completion_tokens: int, *, model: str) -> float:
        price = get_price(model)
        return (prompt_tokens / 1000.0) * price.input_per_ktok + (
            completion_tokens / 1000.0
        ) * price.output_per_ktok

    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            supports_streaming=True,
            supports_tools=True,
            max_context_tokens=128000,
        )

    @staticmethod
    def _maybe_load_tiktoken(model: str) -> Any:
        try:
            import tiktoken
        except ImportError:
            return None
        try:
            return tiktoken.encoding_for_model(model)
        except Exception:
            try:
                return tiktoken.get_encoding("cl100k_base")
            except Exception:
                return None
