"""Lazy registry that maps `RaggedyConfig.llm` names to provider instances.

Each adapter lives behind a lazy import so missing extras turn into a clear
`ConfigError("pip install raggedy[<extra>]")` instead of an `ImportError`
deep in user code.
"""

from __future__ import annotations

import importlib
from collections.abc import Callable
from typing import Any

from raggedy.errors import ConfigError
from raggedy.protocols.llm import LLMProvider


def _load_anthropic(model: str) -> LLMProvider:
    try:
        mod = importlib.import_module("raggedy.llm.anthropic")
    except ImportError as e:
        raise ConfigError(
            "Anthropic provider requested but the optional dependency is missing. "
            "Install with: pip install 'raggedy[anthropic]'"
        ) from e
    return mod.AnthropicProvider(model=model)  # type: ignore[no-any-return]


def _load_openai(model: str) -> LLMProvider:
    try:
        mod = importlib.import_module("raggedy.llm.openai")
    except ImportError as e:
        raise ConfigError(
            "OpenAI provider requested but the optional dependency is missing. "
            "Install with: pip install 'raggedy[openai]'"
        ) from e
    return mod.OpenAIProvider(model=model)  # type: ignore[no-any-return]


def _load_ollama(model: str) -> LLMProvider:
    mod = importlib.import_module("raggedy.llm.ollama")
    return mod.OllamaProvider(model=model)  # type: ignore[no-any-return]


def _load_lm_studio(model: str) -> LLMProvider:
    """LM Studio exposes an OpenAI-compatible API. We reuse OpenAIProvider
    with a sensible local default and a dummy API key (the SDK requires one
    even when the server doesn't enforce it).
    """
    import os

    try:
        mod = importlib.import_module("raggedy.llm.openai")
    except ImportError as e:
        raise ConfigError(
            "LM Studio support reuses the OpenAI SDK. "
            "Install with: pip install 'raggedy[openai]'"
        ) from e
    base_url = os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
    return mod.OpenAIProvider(  # type: ignore[no-any-return]
        model=model,
        api_key=os.getenv("LMSTUDIO_API_KEY", "lm-studio"),
        base_url=base_url,
    )


_REGISTRY: dict[str, Callable[[str], LLMProvider]] = {
    "anthropic": _load_anthropic,
    "openai": _load_openai,
    "ollama": _load_ollama,
    "lm_studio": _load_lm_studio,
    "lmstudio": _load_lm_studio,
}


def build_llm(name: str, model: str, **_extra: Any) -> LLMProvider:
    try:
        factory = _REGISTRY[name]
    except KeyError as e:
        known = ", ".join(sorted(_REGISTRY))
        raise ConfigError(f"Unknown llm {name!r}. Known: {known}") from e
    return factory(model)


def register(name: str, factory: Callable[[str], LLMProvider]) -> None:
    """Allow downstream packages to register custom LLM providers."""
    _REGISTRY[name] = factory
