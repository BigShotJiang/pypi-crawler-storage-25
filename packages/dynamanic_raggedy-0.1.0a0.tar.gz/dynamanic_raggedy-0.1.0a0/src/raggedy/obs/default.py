"""Default `Logger` and `EventSink` implementations."""

from __future__ import annotations

import logging as stdlib_logging
from typing import Any


class StdlibLogger:
    """Thin adapter over stdlib logging — keyword fields are stuffed into `extra`."""

    def __init__(self, name: str = "raggedy", level: str = "INFO") -> None:
        self._log = stdlib_logging.getLogger(name)
        self._log.setLevel(level)

    def debug(self, msg: str, **fields: Any) -> None:
        self._log.debug(msg, extra={"fields": fields})

    def info(self, msg: str, **fields: Any) -> None:
        self._log.info(msg, extra={"fields": fields})

    def warning(self, msg: str, **fields: Any) -> None:
        self._log.warning(msg, extra={"fields": fields})

    def error(self, msg: str, **fields: Any) -> None:
        self._log.error(msg, extra={"fields": fields})


class NullEventSink:
    """Drop every event on the floor. Default until the caller wires real telemetry."""

    async def emit(self, event_type: str, payload: dict[str, Any]) -> None:
        return None
