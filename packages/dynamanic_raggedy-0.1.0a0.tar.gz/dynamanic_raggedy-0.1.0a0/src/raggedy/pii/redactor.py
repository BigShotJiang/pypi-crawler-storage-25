"""Regex-based PII redactor.

`redact` returns a `RedactionResult` with an in-memory `redaction_map`. The
map is never persisted by Raggedy — callers that pass it on assume that risk.
Confidence scores boost on Luhn-valid credit cards and drop the overlap
between credit-card and bank-account hits onto credit card.
"""

from __future__ import annotations

from raggedy.pii.patterns import PATTERNS, PATTERNS_VERSION, luhn_valid
from raggedy.types import PIIMatch, PIIType, RedactionResult


class RegexPIIRedactor:
    def __init__(
        self,
        policy_version: str = "default-v1",
        min_confidence: float = 0.5,
        enabled_types: set[PIIType] | None = None,
    ) -> None:
        self.policy_version = policy_version
        self.patterns_version = PATTERNS_VERSION
        self._min_confidence = min_confidence
        self._enabled_types = enabled_types or set(PIIType)

    def detect(self, text: str) -> list[PIIMatch]:
        if not text:
            return []
        raw: list[PIIMatch] = []
        for pat in PATTERNS:
            if pat.pii_type not in self._enabled_types:
                continue
            for m in pat.regex.finditer(text):
                conf = pat.confidence
                if pat.pii_type is PIIType.CREDIT_CARD and luhn_valid(m.group()):
                    conf = 0.99
                if conf < self._min_confidence:
                    continue
                raw.append(
                    PIIMatch(
                        pii_type=pat.pii_type,
                        original_value=m.group(),
                        start_pos=m.start(),
                        end_pos=m.end(),
                        confidence=conf,
                    )
                )
        return _resolve_overlaps(raw)

    def redact(self, text: str) -> RedactionResult:
        matches = self.detect(text)
        if not matches:
            return RedactionResult(
                redacted_text=text,
                matches=[],
                redaction_map={},
                policy_version=self.policy_version,
                patterns_version=self.patterns_version,
            )
        out_parts: list[str] = []
        redaction_map: dict[str, str] = {}
        counters: dict[PIIType, int] = {}
        cursor = 0
        for m in sorted(matches, key=lambda mm: mm.start_pos):
            counters[m.pii_type] = counters.get(m.pii_type, 0) + 1
            placeholder = f"[{m.pii_type.value.upper()}_REDACTED_{counters[m.pii_type]}]"
            redaction_map[placeholder] = m.original_value
            out_parts.append(text[cursor : m.start_pos])
            out_parts.append(placeholder)
            cursor = m.end_pos
        out_parts.append(text[cursor:])
        return RedactionResult(
            redacted_text="".join(out_parts),
            matches=matches,
            redaction_map=redaction_map,
            policy_version=self.policy_version,
            patterns_version=self.patterns_version,
        )


def _resolve_overlaps(matches: list[PIIMatch]) -> list[PIIMatch]:
    """Drop matches whose span is contained in a higher-confidence match.

    Bank-account regex is intentionally broad and frequently catches credit
    cards or SSNs; this pass de-duplicates overlap deterministically.
    """
    by_priority = sorted(matches, key=lambda m: (-m.confidence, m.start_pos, m.end_pos))
    kept: list[PIIMatch] = []
    for m in by_priority:
        if any(_overlaps(m, k) for k in kept):
            continue
        kept.append(m)
    kept.sort(key=lambda m: m.start_pos)
    return kept


def _overlaps(a: PIIMatch, b: PIIMatch) -> bool:
    return a.start_pos < b.end_pos and b.start_pos < a.end_pos
