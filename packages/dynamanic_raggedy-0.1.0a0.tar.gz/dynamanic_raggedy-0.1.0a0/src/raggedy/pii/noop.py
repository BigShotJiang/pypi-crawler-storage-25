"""Pass-through redactor used when redaction is disabled."""

from __future__ import annotations

from raggedy.types import PIIMatch, RedactionResult


class NoOpRedactor:
    policy_version = "noop"
    patterns_version = "noop"

    def detect(self, text: str) -> list[PIIMatch]:
        return []

    def redact(self, text: str) -> RedactionResult:
        return RedactionResult(
            redacted_text=text,
            matches=[],
            redaction_map={},
            policy_version=self.policy_version,
            patterns_version=self.patterns_version,
        )
