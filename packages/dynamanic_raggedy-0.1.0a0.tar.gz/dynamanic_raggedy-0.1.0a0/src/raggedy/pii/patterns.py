"""Versioned regex catalog for PII detection.

Bump `PATTERNS_VERSION` any time you add a new pattern, broaden one,
or change a confidence score. The version travels in every
`RedactionResult` so callers can correlate behavior changes.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from raggedy.types import PIIType

PATTERNS_VERSION = "1.0.0"


@dataclass(slots=True, frozen=True)
class PIIPattern:
    pii_type: PIIType
    regex: re.Pattern[str]
    confidence: float


PATTERNS: list[PIIPattern] = [
    # SSN — 3-2-4 with optional separators
    PIIPattern(
        PIIType.SSN,
        re.compile(r"\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b"),
        0.85,
    ),
    # Email
    PIIPattern(
        PIIType.EMAIL,
        re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
        0.99,
    ),
    # US phone: (xxx) xxx-xxxx, xxx-xxx-xxxx, +1 ...
    PIIPattern(
        PIIType.PHONE,
        re.compile(r"(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b"),
        0.85,
    ),
    # DOB — common written forms
    PIIPattern(
        PIIType.DOB,
        re.compile(
            r"\b(?:0?[1-9]|1[0-2])[/\-](?:0?[1-9]|[12]\d|3[01])[/\-](?:19|20)\d{2}\b"
        ),
        0.7,
    ),
    # Credit card — 13-19 digits, optional spaces/dashes (validated downstream)
    PIIPattern(
        PIIType.CREDIT_CARD,
        re.compile(r"\b(?:\d[ -]?){13,19}\b"),
        0.75,
    ),
    # IPv4
    PIIPattern(
        PIIType.IP_ADDRESS,
        re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\b"),
        0.95,
    ),
    # US passport — letter followed by 8 digits
    PIIPattern(
        PIIType.PASSPORT,
        re.compile(r"\b[A-Z]\d{8}\b"),
        0.6,
    ),
    # Drivers license — heuristic: letter + 7-8 digits
    PIIPattern(
        PIIType.DRIVERS_LICENSE,
        re.compile(r"\b[A-Z]\d{7,8}\b"),
        0.55,
    ),
    # Bank account — 9-17 digits (broad — confidence is low)
    PIIPattern(
        PIIType.BANK_ACCOUNT,
        re.compile(r"\b\d{9,17}\b"),
        0.5,
    ),
    # US street address — "<num> <Words> <Street|St|Ave|...>"
    PIIPattern(
        PIIType.ADDRESS,
        re.compile(
            r"\b\d{1,5}\s+(?:[A-Z][a-z]+\s+){1,4}"
            r"(?:Street|St|Avenue|Ave|Boulevard|Blvd|Road|Rd|Lane|Ln|Drive|Dr|Court|Ct)\b"
        ),
        0.7,
    ),
]


def luhn_valid(digits: str) -> bool:
    """Standard mod-10 check used to boost credit-card confidence."""
    nums = [int(d) for d in digits if d.isdigit()]
    if len(nums) < 13 or len(nums) > 19:
        return False
    total = 0
    parity = len(nums) % 2
    for i, n in enumerate(nums):
        if i % 2 == parity:
            n *= 2
            if n > 9:
                n -= 9
        total += n
    return total % 10 == 0
