"""In-memory `Source` for tests and quick glue."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterable

from raggedy.intake.protocols import Source
from raggedy.intake.types import IntakeItem


class MemorySource(Source):
    name = "memory"

    def __init__(self, items: Iterable[IntakeItem]) -> None:
        self._items = list(items)

    async def items(self) -> AsyncIterator[IntakeItem]:
        for it in self._items:
            yield it
