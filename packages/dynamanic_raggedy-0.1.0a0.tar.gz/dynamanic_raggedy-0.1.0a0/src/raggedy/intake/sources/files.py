"""Filesystem sources — single files and directory walks."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from pathlib import Path

from raggedy.intake.extractors.registry import guess_content_type
from raggedy.intake.protocols import Source
from raggedy.intake.types import IntakeItem


class FileSource(Source):
    """Read one file."""

    name = "file"

    def __init__(self, path: str | Path, *, content_type: str | None = None) -> None:
        self._path = Path(path)
        self._content_type = content_type

    async def items(self) -> AsyncIterator[IntakeItem]:
        data = await asyncio.to_thread(self._path.read_bytes)
        ct = self._content_type or guess_content_type(self._path.name)
        yield IntakeItem(
            source_uri=self._path.resolve().as_uri(),
            filename=self._path.name,
            content_type=ct,
            data=data,
            metadata={"size": len(data)},
        )


class DirectorySource(Source):
    """Walk a directory and yield one item per matching file.

    `pattern` accepts `pathlib`-style globs (`**/*.md`). `recursive` defaults
    to True so patterns without `**` still descend; set False to limit to a
    single level. `extensions` is a convenience filter applied after the
    glob match — pass `{".pdf", ".md"}` to skip the rest.
    """

    name = "directory"

    def __init__(
        self,
        path: str | Path,
        *,
        pattern: str = "**/*",
        recursive: bool = True,
        extensions: set[str] | None = None,
        follow_symlinks: bool = False,
    ) -> None:
        self._root = Path(path)
        self._pattern = pattern
        self._recursive = recursive
        self._extensions = {e.lower() for e in extensions} if extensions else None
        self._follow_symlinks = follow_symlinks

    async def items(self) -> AsyncIterator[IntakeItem]:
        for path in await asyncio.to_thread(self._list):
            data = await asyncio.to_thread(path.read_bytes)
            yield IntakeItem(
                source_uri=path.resolve().as_uri(),
                filename=path.name,
                content_type=guess_content_type(path.name),
                data=data,
                metadata={
                    "size": len(data),
                    "relative_path": str(path.relative_to(self._root)),
                },
            )

    def _list(self) -> list[Path]:
        if not self._root.exists():
            return []
        glob_method = self._root.rglob if self._recursive else self._root.glob
        # When recursive and the user gave a pure-name pattern (no slashes), apply rglob.
        # When pattern uses ** explicitly, glob() handles it.
        candidates: list[Path] = []
        seen: set[Path] = set()
        # If pattern contains '/' or '**', use it as-is via glob.
        if "**" in self._pattern or "/" in self._pattern:
            iterator = self._root.glob(self._pattern)
        else:
            iterator = glob_method(self._pattern)
        for p in iterator:
            if not p.is_file():
                continue
            if not self._follow_symlinks and p.is_symlink():
                continue
            if self._extensions and p.suffix.lower() not in self._extensions:
                continue
            if p in seen:
                continue
            seen.add(p)
            candidates.append(p)
        candidates.sort()
        return candidates
