"""HTTP/URL source — uses httpx (already a base dependency)."""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterable
from urllib.parse import urlparse

import httpx

from raggedy.intake.protocols import Source
from raggedy.intake.types import IntakeItem


class UrlSource(Source):
    """Fetch one or more URLs as `IntakeItem`s.

    Follows redirects, raises on 4xx/5xx, and uses the response's
    `Content-Type` header (sans parameters) as the dispatch key.
    """

    name = "url"

    def __init__(
        self,
        urls: str | Iterable[str],
        *,
        timeout: float = 30.0,
        headers: dict[str, str] | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        if isinstance(urls, str):
            self._urls = [urls]
        else:
            self._urls = list(urls)
        self._timeout = timeout
        self._headers = headers
        self._client = client

    async def items(self) -> AsyncIterator[IntakeItem]:
        owns_client = self._client is None
        client = self._client or httpx.AsyncClient(
            follow_redirects=True,
            timeout=self._timeout,
            headers=self._headers,
        )
        try:
            for url in self._urls:
                resp = await client.get(url)
                resp.raise_for_status()
                content_type = resp.headers.get("content-type", "application/octet-stream")
                content_type = content_type.split(";", 1)[0].strip().lower()
                filename = _filename_from_url(url)
                yield IntakeItem(
                    source_uri=str(resp.url),
                    filename=filename,
                    content_type=content_type,
                    data=resp.content,
                    metadata={
                        "status_code": resp.status_code,
                        "headers": dict(resp.headers),
                    },
                )
        finally:
            if owns_client:
                await client.aclose()


def _filename_from_url(url: str) -> str:
    parsed = urlparse(url)
    path = parsed.path.rstrip("/")
    return path.rsplit("/", 1)[-1] or parsed.netloc or url
