"""S3 source — requires `pip install raggedy[s3]` (boto3)."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from typing import Any

from raggedy.errors import ConfigError
from raggedy.intake.extractors.registry import guess_content_type
from raggedy.intake.protocols import Source
from raggedy.intake.types import IntakeItem


class S3Source(Source):
    """List and download objects from an S3 (or S3-compatible) prefix.

    boto3 itself is sync; calls are offloaded with `asyncio.to_thread`.
    Pass `client_kwargs` for non-AWS endpoints (e.g. MinIO):
        S3Source(bucket="b", prefix="docs/",
                 client_kwargs={"endpoint_url": "http://minio:9000",
                                "aws_access_key_id": "...",
                                "aws_secret_access_key": "..."})
    """

    name = "s3"

    def __init__(
        self,
        bucket: str,
        *,
        prefix: str = "",
        client_kwargs: dict[str, Any] | None = None,
        max_objects: int | None = None,
    ) -> None:
        try:
            import boto3  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "S3Source requires the optional dependency. "
                "Install with: pip install 'raggedy[s3]'"
            ) from e
        self._bucket = bucket
        self._prefix = prefix
        self._client_kwargs = client_kwargs or {}
        self._max_objects = max_objects

    async def items(self) -> AsyncIterator[IntakeItem]:
        keys = await asyncio.to_thread(self._list_keys)
        for key in keys:
            data, content_type = await asyncio.to_thread(self._fetch, key)
            yield IntakeItem(
                source_uri=f"s3://{self._bucket}/{key}",
                filename=key.rsplit("/", 1)[-1],
                content_type=content_type or guess_content_type(key),
                data=data,
                metadata={"bucket": self._bucket, "key": key, "size": len(data)},
            )

    def _client(self) -> Any:
        import boto3

        return boto3.client("s3", **self._client_kwargs)

    def _list_keys(self) -> list[str]:
        client = self._client()
        paginator = client.get_paginator("list_objects_v2")
        keys: list[str] = []
        for page in paginator.paginate(Bucket=self._bucket, Prefix=self._prefix):
            for obj in page.get("Contents", []):
                if obj["Key"].endswith("/"):
                    continue
                keys.append(obj["Key"])
                if self._max_objects is not None and len(keys) >= self._max_objects:
                    return keys
        return keys

    def _fetch(self, key: str) -> tuple[bytes, str | None]:
        client = self._client()
        resp = client.get_object(Bucket=self._bucket, Key=key)
        body = resp["Body"].read()
        ct = resp.get("ContentType")
        return body, (ct.lower() if ct else None)
