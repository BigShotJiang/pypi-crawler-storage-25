"""Intake protocols.

A `Source` yields raw `IntakeItem`s. An `Extractor` turns one item's bytes
into plain text. The intake pipeline dispatches items to extractors based
on `content_type`.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import Protocol, runtime_checkable

from raggedy.intake.types import IntakeItem


@runtime_checkable
class Source(Protocol):
    name: str

    def items(self) -> AsyncIterator[IntakeItem]: ...


@runtime_checkable
class Extractor(Protocol):
    name: str
    content_types: frozenset[str]

    async def extract(self, item: IntakeItem) -> str: ...
