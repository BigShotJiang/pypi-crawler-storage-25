"""Raggedy intake layer.

Sources fetch raw bytes; Extractors turn them into text; `IntakeRunner`
glues them together and yields `Document`s. The `Raggedy.ingest_from`
helper consumes a `Source` end-to-end.
"""

from raggedy.intake.extractors import (
    ExtractorRegistry,
    HtmlExtractor,
    PlainTextExtractor,
    guess_content_type,
)
from raggedy.intake.pipeline import IntakeRunner
from raggedy.intake.protocols import Extractor, Source
from raggedy.intake.sources import (
    DirectorySource,
    FileSource,
    MemorySource,
    UrlSource,
)
from raggedy.intake.types import IntakeItem

__all__ = [
    "DirectorySource",
    "Extractor",
    "ExtractorRegistry",
    "FileSource",
    "HtmlExtractor",
    "IntakeItem",
    "IntakeRunner",
    "MemorySource",
    "PlainTextExtractor",
    "Source",
    "UrlSource",
    "guess_content_type",
]
