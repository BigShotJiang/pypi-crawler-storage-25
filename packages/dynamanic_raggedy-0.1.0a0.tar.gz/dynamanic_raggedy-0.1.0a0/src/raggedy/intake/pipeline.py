"""Intake runner: pulls items from a `Source`, dispatches them through
the `ExtractorRegistry`, and yields `Document`s suitable for `Raggedy.ingest`.
"""

from __future__ import annotations

import hashlib
from collections.abc import AsyncIterator

from raggedy.intake.extractors.registry import ExtractorRegistry
from raggedy.intake.protocols import Extractor, Source
from raggedy.intake.types import IntakeItem
from raggedy.types import Document


class IntakeRunner:
    def __init__(self, registry: ExtractorRegistry | None = None) -> None:
        self._registry = registry or ExtractorRegistry()

    def register_extractor(self, extractor: Extractor) -> None:
        self._registry.register(extractor)

    async def documents(
        self,
        source: Source,
        *,
        tags: dict[str, str] | None = None,
        skip_unsupported: bool = True,
    ) -> AsyncIterator[Document]:
        async for item in source.items():
            if not self._registry.has(item.content_type) and skip_unsupported:
                continue
            extractor = self._registry.get(item.content_type)
            text = await extractor.extract(item)
            if not text or not text.strip():
                continue
            yield _to_document(item, text, tags)


def _to_document(
    item: IntakeItem,
    text: str,
    extra_tags: dict[str, str] | None,
) -> Document:
    doc_id = _stable_doc_id(item)
    merged_tags = {**item.tags, **(extra_tags or {})}
    metadata = {
        **item.metadata,
        "source_uri": item.source_uri,
        "content_type": item.content_type,
        "filename": item.filename,
    }
    return Document(id=doc_id, text=text, tags=merged_tags, metadata=metadata)


def _stable_doc_id(item: IntakeItem) -> str:
    digest = hashlib.sha256(item.source_uri.encode("utf-8")).hexdigest()[:16]
    return f"intake_{digest}"
