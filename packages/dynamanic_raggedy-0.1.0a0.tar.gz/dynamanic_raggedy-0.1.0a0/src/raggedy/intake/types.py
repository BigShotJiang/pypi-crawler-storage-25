"""Dataclasses passed between intake sources and extractors."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class IntakeItem:
    """A raw payload yielded by a `Source`, before extraction.

    `source_uri` is the canonical location (e.g. `file:///path/to/x.pdf`,
    `https://example.com/blog`, `s3://bucket/key`). Stable enough to use as
    a document id when one is not supplied.
    """

    source_uri: str
    filename: str | None
    content_type: str
    data: bytes
    tags: dict[str, str] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
