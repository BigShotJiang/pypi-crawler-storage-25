"""HTML extractor — uses stdlib `html.parser` so no extra is required.

Strips `<script>`, `<style>`, and HTML comments, then joins remaining text
with whitespace normalisation. Good enough for the common case; for
article-mode extraction, wire a custom Extractor backed by trafilatura
or readability-lxml.
"""

from __future__ import annotations

import re
from html.parser import HTMLParser

from raggedy.intake.extractors.plaintext import _decode
from raggedy.intake.types import IntakeItem

_SKIP_TAGS = frozenset({"script", "style", "noscript", "template"})
_WHITESPACE_RE = re.compile(r"[ \t\f\v]+")
_BLANK_LINE_RE = re.compile(r"\n\s*\n+")


class _TextOnlyParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._chunks: list[str] = []
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in _SKIP_TAGS:
            self._skip_depth += 1
        elif tag in {"br", "p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"}:
            self._chunks.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in _SKIP_TAGS and self._skip_depth > 0:
            self._skip_depth -= 1
        elif tag in {"p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"}:
            self._chunks.append("\n")

    def handle_data(self, data: str) -> None:
        if self._skip_depth == 0:
            self._chunks.append(data)

    def text(self) -> str:
        return "".join(self._chunks)


class HtmlExtractor:
    name = "html"
    content_types = frozenset(
        {
            "text/html",
            "application/xhtml+xml",
        }
    )

    async def extract(self, item: IntakeItem) -> str:
        raw = _decode(item.data)
        parser = _TextOnlyParser()
        parser.feed(raw)
        text = parser.text()
        text = _WHITESPACE_RE.sub(" ", text)
        text = _BLANK_LINE_RE.sub("\n\n", text)
        return text.strip()
