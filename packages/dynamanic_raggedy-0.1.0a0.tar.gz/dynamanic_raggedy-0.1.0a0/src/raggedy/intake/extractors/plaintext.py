"""Plain-text extractor — always available."""

from __future__ import annotations

from raggedy.intake.types import IntakeItem


class PlainTextExtractor:
    name = "plaintext"
    content_types = frozenset(
        {
            "text/plain",
            "text/markdown",
            "text/x-markdown",
            "text/csv",
            "text/tab-separated-values",
            "application/json",
            "application/yaml",
            "application/x-yaml",
            "text/yaml",
        }
    )

    async def extract(self, item: IntakeItem) -> str:
        return _decode(item.data)


def _decode(data: bytes) -> str:
    # Try utf-8 first, then latin-1 as a no-fail fallback.
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1", errors="replace")
