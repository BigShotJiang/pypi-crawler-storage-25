"""PDF extractor — requires `pip install raggedy[pdf]` (pypdf)."""

from __future__ import annotations

import asyncio
import io

from raggedy.errors import ConfigError
from raggedy.intake.types import IntakeItem


class PdfExtractor:
    name = "pdf"
    content_types = frozenset(
        {
            "application/pdf",
            "application/x-pdf",
        }
    )

    def __init__(self) -> None:
        try:
            import pypdf  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "PdfExtractor requires the optional dependency. "
                "Install with: pip install 'raggedy[pdf]'"
            ) from e

    async def extract(self, item: IntakeItem) -> str:
        return await asyncio.to_thread(self._extract_sync, item.data)

    @staticmethod
    def _extract_sync(data: bytes) -> str:
        import pypdf

        reader = pypdf.PdfReader(io.BytesIO(data))
        pages: list[str] = []
        for page in reader.pages:
            try:
                pages.append(page.extract_text() or "")
            except Exception:
                pages.append("")
        return "\n\n".join(p.strip() for p in pages if p.strip())
