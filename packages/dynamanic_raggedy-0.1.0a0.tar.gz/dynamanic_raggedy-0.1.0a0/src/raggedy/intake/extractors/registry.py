"""Content-type → Extractor dispatch.

The registry is constructed lazily: PDF/DOCX extractors raise `ConfigError`
on instantiation when their optional dep is missing, so we only instantiate
them on first need and cache the result.
"""

from __future__ import annotations

import os
from collections.abc import Callable
from pathlib import PurePosixPath

from raggedy.errors import ConfigError
from raggedy.intake.extractors.html import HtmlExtractor
from raggedy.intake.extractors.plaintext import PlainTextExtractor
from raggedy.intake.protocols import Extractor


def _load_pdf() -> Extractor:
    from raggedy.intake.extractors.pdf import PdfExtractor

    return PdfExtractor()


def _load_docx() -> Extractor:
    from raggedy.intake.extractors.docx import DocxExtractor

    return DocxExtractor()


_EXTENSION_TO_TYPE: dict[str, str] = {
    ".txt": "text/plain",
    ".md": "text/markdown",
    ".markdown": "text/markdown",
    ".csv": "text/csv",
    ".tsv": "text/tab-separated-values",
    ".json": "application/json",
    ".yaml": "application/yaml",
    ".yml": "application/yaml",
    ".html": "text/html",
    ".htm": "text/html",
    ".xhtml": "application/xhtml+xml",
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc": "application/msword",
}


def guess_content_type(filename: str | None, fallback: str = "application/octet-stream") -> str:
    if not filename:
        return fallback
    ext = os.path.splitext(PurePosixPath(filename).name)[1].lower()
    return _EXTENSION_TO_TYPE.get(ext, fallback)


class ExtractorRegistry:
    """Lazy registry that maps content_type → Extractor instance.

    Plain-text and HTML extractors are always available. PDF and DOCX
    require their respective extras; instantiation is deferred until the
    first item that needs them.
    """

    def __init__(self) -> None:
        self._instances: dict[str, Extractor] = {}
        self._lazy_factories: dict[str, Callable[[], Extractor]] = {}
        # Eager: zero-cost extractors.
        for inst in (PlainTextExtractor(), HtmlExtractor()):
            for ct in inst.content_types:
                self._instances[ct] = inst
        # Lazy: extras-gated extractors.
        for ct in (
            "application/pdf",
            "application/x-pdf",
        ):
            self._lazy_factories[ct] = _load_pdf
        for ct in (
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/msword",
        ):
            self._lazy_factories[ct] = _load_docx

    def register(self, extractor: Extractor) -> None:
        for ct in extractor.content_types:
            self._instances[ct] = extractor

    def get(self, content_type: str) -> Extractor:
        if content_type in self._instances:
            return self._instances[content_type]
        if content_type in self._lazy_factories:
            inst = self._lazy_factories[content_type]()
            self.register(inst)
            return inst
        # Last resort: treat as plain text. Callers can override by passing
        # an explicit content_type that DOES match a registered extractor.
        raise ConfigError(
            f"No extractor registered for content_type {content_type!r}. "
            f"Known types: {sorted(self._instances) + sorted(self._lazy_factories)}"
        )

    def has(self, content_type: str) -> bool:
        return content_type in self._instances or content_type in self._lazy_factories
