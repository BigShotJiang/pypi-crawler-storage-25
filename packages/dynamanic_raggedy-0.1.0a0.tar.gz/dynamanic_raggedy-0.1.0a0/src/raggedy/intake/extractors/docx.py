"""DOCX extractor — requires `pip install raggedy[docx]` (python-docx)."""

from __future__ import annotations

import asyncio
import io

from raggedy.errors import ConfigError
from raggedy.intake.types import IntakeItem


class DocxExtractor:
    name = "docx"
    content_types = frozenset(
        {
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/msword",
        }
    )

    def __init__(self) -> None:
        try:
            import docx  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "DocxExtractor requires the optional dependency. "
                "Install with: pip install 'raggedy[docx]'"
            ) from e

    async def extract(self, item: IntakeItem) -> str:
        return await asyncio.to_thread(self._extract_sync, item.data)

    @staticmethod
    def _extract_sync(data: bytes) -> str:
        import docx

        document = docx.Document(io.BytesIO(data))
        parts: list[str] = [p.text for p in document.paragraphs if p.text.strip()]
        for table in document.tables:
            for row in table.rows:
                cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
                if cells:
                    parts.append("\t".join(cells))
        return "\n\n".join(parts)
