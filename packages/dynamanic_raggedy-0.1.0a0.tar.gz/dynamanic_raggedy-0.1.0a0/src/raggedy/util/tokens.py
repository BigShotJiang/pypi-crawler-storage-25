"""Token-count utilities.

The default `naive_token_count` uses the well-worn `len(text) // 4`
heuristic — close enough for context-window packing across BPE-style
tokenizers. Real `LLMProvider`s override `count_tokens` to use the
provider's tokenizer (tiktoken, Anthropic SDK, etc.) when available.
"""

from __future__ import annotations


def naive_token_count(text: str) -> int:
    if not text:
        return 0
    return max(1, len(text) // 4)
