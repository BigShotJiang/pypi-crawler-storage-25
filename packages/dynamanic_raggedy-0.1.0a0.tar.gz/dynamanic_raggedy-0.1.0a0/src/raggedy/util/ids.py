"""ID generation helpers."""

from __future__ import annotations

from ulid import ULID


def new_run_id() -> str:
    return f"run_{ULID()}"


def new_chunk_id(document_id: str, chunk_index: int) -> str:
    return f"{document_id}::chunk-{chunk_index:05d}"
