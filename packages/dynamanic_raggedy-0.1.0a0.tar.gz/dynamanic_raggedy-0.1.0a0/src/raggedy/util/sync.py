"""Async → sync shim used by the `Raggedy` facade for `_sync` methods."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TypeVar

from asgiref.sync import async_to_sync

T = TypeVar("T")


def to_sync(coro_fn: Callable[..., Awaitable[T]]) -> Callable[..., T]:
    return async_to_sync(coro_fn)
