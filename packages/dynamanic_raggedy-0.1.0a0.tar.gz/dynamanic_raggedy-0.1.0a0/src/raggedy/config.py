"""Raggedy configuration object.

Field names (`llm`, `embedding`, `store`, `recorder`, `chunker_strategy`)
identify adapter implementations; the registry layer resolves them.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic_settings import BaseSettings, SettingsConfigDict

from raggedy.errors import ConfigError


class RaggedyConfig(BaseSettings):
    # Reads RAGGEDY_* environment variables. If a `.env` file is present in
    # the working directory at construction time, it is loaded automatically
    # (so `ANTHROPIC_API_KEY=...` etc. flow through to the provider SDKs).
    model_config = SettingsConfigDict(
        env_prefix="RAGGEDY_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        validate_default=True,
    )

    # Adapter selection (by name; registry resolves to a class)
    # `llm` has no built-in default — pick anthropic | openai | ollama |
    # lm_studio (or register a custom). The library never ships a fake LLM.
    llm: str = "ollama"
    llm_model: str = "llama3.2"
    embedding: str = "deterministic"
    embedding_model: str = "deterministic-384"
    store: str = "memory"
    store_url: str | None = None
    recorder: str = "memory"
    recorder_url: str | None = None
    chunker_strategy: str = "semantic"

    # Namespacing
    namespace: str = "default"

    # Chunking
    chunk_target_tokens: int = 512
    chunk_overlap_tokens: int = 100
    chunk_min_tokens: int = 50

    # Retrieval
    top_k: int = 5
    min_score: float = 0.0
    max_context_tokens: int = 8000
    empty_retrieval_policy: str = "fall_through"  # "fall_through" | "raise"

    # LLM
    llm_max_output_tokens: int = 1024
    llm_temperature: float = 0.2

    # PII redaction
    redaction_enabled: bool = True
    redaction_policy: str = "default-v1"

    # Cost
    cost_tracking_enabled: bool = True
    cost_daily_limit_usd: float | None = None
    cost_backend: str = "memory"  # memory | sqlite
    cost_backend_url: str | None = None

    # Prompt template
    prompt_template_version: str = "rag-v1"

    # Logging
    log_level: str = "INFO"

    # Embedding dimension (used by deterministic embedder; real backends override)
    embedding_dimension: int = 384

    # Device selection for local embedders (sentence-transformers).
    # "auto" picks the best available: CUDA → MPS (Apple Silicon) → CPU.
    # Other valid values: "cuda", "cuda:0", "mps", "cpu".
    device: str = "auto"
    # Optional: limit batch size for local embedders running on constrained GPUs.
    embedding_batch_size: int = 32

    @classmethod
    def from_yaml(cls, path: str | Path, **overrides: Any) -> RaggedyConfig:
        """Load config from a YAML file, with optional keyword overrides.

        YAML keys map 1:1 to `RaggedyConfig` field names (no `RAGGEDY_`
        prefix). Environment variables and `.env` still take effect for
        any field not present in the YAML or overrides.
        """
        try:
            import yaml
        except ImportError as e:
            raise ConfigError(
                "from_yaml requires PyYAML. Install with: pip install pyyaml"
            ) from e
        p = Path(path)
        if not p.exists():
            raise ConfigError(f"Config file not found: {p}")
        try:
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception as e:
            raise ConfigError(
                f"Failed to parse YAML {p}: {type(e).__name__}: {e}"
            ) from e
        if not isinstance(data, dict):
            raise ConfigError(f"YAML root must be a mapping, got {type(data).__name__}")
        data.update(overrides)
        try:
            return cls(**data)
        except Exception as e:
            raise ConfigError(
                f"Invalid config in {p}: {type(e).__name__}: {e}"
            ) from e
