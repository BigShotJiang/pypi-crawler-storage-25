"""Local sentence-transformers embedder — `pip install raggedy[local]`.

Mirrors ediscovery's `LocalEmbeddingGenerator` GPU-aware behaviour:
auto-detects CUDA → MPS → CPU, honours explicit `device=` overrides, and
runs encoding off the event loop with `asyncio.to_thread`.
"""

from __future__ import annotations

import asyncio

from raggedy.errors import ConfigError, ProviderError

DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def detect_device(preference: str = "auto") -> str:
    """Return a device string usable by sentence-transformers / torch.

    - "auto"  → CUDA if available, else MPS on Apple Silicon, else CPU
    - "cuda" / "cuda:N" / "mps" / "cpu" → returned verbatim
    - Anything else falls back to CPU with a swallowed warning so init
      doesn't crash if torch isn't installed or doesn't recognise the name.
    """
    if preference != "auto":
        return preference
    try:
        import torch
    except ImportError:
        return "cpu"
    try:
        if torch.cuda.is_available():
            return "cuda"
        mps = getattr(torch.backends, "mps", None)
        if mps is not None and bool(getattr(mps, "is_available", lambda: False)()):
            return "mps"
    except Exception:
        return "cpu"
    return "cpu"


class SentenceTransformersEmbedder:
    def __init__(
        self,
        model_name: str | None = None,
        *,
        device: str | None = None,
        normalize: bool = True,
        batch_size: int = 32,
    ) -> None:
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as e:
            raise ConfigError(
                "sentence-transformers not installed. "
                "Install with: pip install 'raggedy[local]'"
            ) from e
        resolved_device = detect_device(device or "auto")
        try:
            self._model = SentenceTransformer(
                model_name or DEFAULT_MODEL, device=resolved_device
            )
        except Exception as e:
            raise ConfigError(
                f"SentenceTransformer init failed (model="
                f"{model_name or DEFAULT_MODEL!r}, device={resolved_device!r}): "
                f"{type(e).__name__}: {e}"
            ) from e
        self.model_id = f"{model_name or DEFAULT_MODEL}@{resolved_device}"
        self.device = resolved_device
        try:
            self.dimension = int(self._model.get_sentence_embedding_dimension())
        except Exception as e:
            raise ConfigError(
                f"Could not determine embedding dimension: {type(e).__name__}: {e}"
            ) from e
        self._normalize = normalize
        self._batch_size = max(1, batch_size)

    async def embed(self, text: str) -> list[float]:
        return (await self.embed_batch([text]))[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        try:
            return await asyncio.to_thread(self._encode_sync, texts)
        except Exception as e:
            raise ProviderError(
                f"sentence-transformers encode failed: {type(e).__name__}: {e}",
                provider=self.model_id,
                retryable=False,
            ) from e

    def _encode_sync(self, texts: list[str]) -> list[list[float]]:
        result = self._model.encode(
            texts,
            batch_size=self._batch_size,
            normalize_embeddings=self._normalize,
            convert_to_numpy=True,
            show_progress_bar=False,
        )
        return [list(map(float, row)) for row in result]
