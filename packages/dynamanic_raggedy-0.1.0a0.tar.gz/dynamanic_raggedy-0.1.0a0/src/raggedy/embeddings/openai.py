"""OpenAI embedding backend — `pip install raggedy[openai]`."""

from __future__ import annotations

import os

from raggedy.errors import ConfigError, ProviderError

DEFAULT_MODEL = "text-embedding-3-small"

# Per-model native dimensions; the API lets callers truncate via `dimensions=`
# for the v3 family, but the default-output sizes are:
DIMENSIONS = {
    "text-embedding-3-small": 1536,
    "text-embedding-3-large": 3072,
    "text-embedding-ada-002": 1536,
}


class OpenAIEmbedder:
    def __init__(
        self,
        model: str | None = None,
        *,
        api_key: str | None = None,
        organization: str | None = None,
        base_url: str | None = None,
        dimensions: int | None = None,
    ) -> None:
        try:
            from openai import AsyncOpenAI
        except ImportError as e:
            raise ConfigError(
                "OpenAI SDK not installed. Install with: pip install 'raggedy[openai]'"
            ) from e
        client_kwargs: dict[str, str] = {}
        key = api_key or os.getenv("OPENAI_API_KEY")
        if key:
            client_kwargs["api_key"] = key
        if organization:
            client_kwargs["organization"] = organization
        if base_url:
            client_kwargs["base_url"] = base_url
        self._client = AsyncOpenAI(**client_kwargs)
        self._model = model or DEFAULT_MODEL
        self._explicit_dim = dimensions
        self.model_id = f"openai:{self._model}"
        self.dimension = dimensions or DIMENSIONS.get(self._model, 1536)

    async def embed(self, text: str) -> list[float]:
        return (await self.embed_batch([text]))[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        kwargs: dict[str, object] = {"model": self._model, "input": texts}
        if self._explicit_dim is not None:
            kwargs["dimensions"] = self._explicit_dim
        try:
            resp = await self._client.embeddings.create(**kwargs)
        except Exception as e:
            raise ProviderError(
                f"OpenAI embedding call failed: {e}", provider="openai", retryable=True
            ) from e
        return [list(d.embedding) for d in resp.data]
