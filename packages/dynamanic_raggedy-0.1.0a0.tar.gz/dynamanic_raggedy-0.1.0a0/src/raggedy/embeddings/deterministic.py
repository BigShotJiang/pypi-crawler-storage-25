"""Deterministic, dependency-free embedder used as the test/offline default.

Hashed bag-of-words: each lower-cased token contributes to a hash-derived
dimension, then the vector is L2-normalised. Identical text always maps
to the same unit vector, AND texts that share vocabulary produce vectors
with positive cosine similarity — enough for the retrieval pipeline to
exercise meaningfully offline. Real workloads should swap in
`SentenceTransformersEmbedder` (extra `[local]`) or an API embedder.
"""

from __future__ import annotations

import hashlib
import re

import numpy as np

TOKEN_PATTERN = re.compile(r"[A-Za-z0-9]+")


class DeterministicEmbedder:
    def __init__(self, dimension: int = 384, model_id: str = "deterministic-384") -> None:
        if dimension < 8:
            raise ValueError("dimension must be >= 8")
        self.dimension = dimension
        self.model_id = model_id

    async def embed(self, text: str) -> list[float]:
        return self._embed(text)

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        return [self._embed(t) for t in texts]

    def _embed(self, text: str) -> list[float]:
        vec = np.zeros(self.dimension, dtype=np.float32)
        tokens = TOKEN_PATTERN.findall(text.lower())
        if not tokens:
            # Stable fallback: seed by full-text hash so empty/punct-only
            # inputs still produce a unique unit vector.
            digest = hashlib.sha256(text.encode("utf-8")).digest()
            idx = int.from_bytes(digest[:4], "big") % self.dimension
            vec[idx] = 1.0
            return [float(x) for x in vec.tolist()]
        for token in tokens:
            digest = hashlib.sha256(token.encode("utf-8")).digest()
            idx = int.from_bytes(digest[:4], "big") % self.dimension
            sign = 1.0 if digest[4] & 1 else -1.0
            # Sign reduces collision bias; abs values still sum so shared
            # vocabulary lifts the dot product.
            vec[idx] += sign
        norm = float(np.linalg.norm(vec))
        if norm == 0.0:
            vec[0] = 1.0
            norm = 1.0
        return [float(x) for x in (vec / norm).tolist()]
