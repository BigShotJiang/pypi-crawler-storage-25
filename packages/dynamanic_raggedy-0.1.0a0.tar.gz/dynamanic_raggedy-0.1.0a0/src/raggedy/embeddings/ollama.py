"""Ollama embedding backend — uses base `httpx`, no optional extras."""

from __future__ import annotations

import os

import httpx

from raggedy.errors import ProviderError

DEFAULT_MODEL = "nomic-embed-text"
DEFAULT_BASE_URL = "http://localhost:11434"


class OllamaEmbedder:
    def __init__(
        self,
        model: str | None = None,
        *,
        base_url: str | None = None,
        dimension: int | None = None,
        timeout: float = 60.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._model = model or DEFAULT_MODEL
        self._base_url = (base_url or os.getenv("OLLAMA_HOST") or DEFAULT_BASE_URL).rstrip("/")
        self._timeout = timeout
        self._client = client
        self.model_id = f"ollama:{self._model}"
        # The host may not have downloaded the model yet; dimension is
        # discovered lazily on first embed unless caller supplies it.
        self._dimension: int | None = dimension

    @property
    def dimension(self) -> int:
        if self._dimension is None:
            raise RuntimeError(
                "OllamaEmbedder dimension not known yet; call embed() once or pass "
                "dimension=... to the constructor."
            )
        return self._dimension

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self._timeout)
        return self._client

    async def embed(self, text: str) -> list[float]:
        return (await self.embed_batch([text]))[0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        if not texts:
            return []
        client = await self._get_client()
        try:
            # Newer Ollama exposes /api/embed with batch `input`; older has
            # /api/embeddings (single `prompt`). We prefer the batch endpoint.
            resp = await client.post(
                f"{self._base_url}/api/embed",
                json={"model": self._model, "input": texts},
            )
            if resp.status_code == 404:
                # Fall back to single-shot endpoint.
                out: list[list[float]] = []
                for t in texts:
                    r = await client.post(
                        f"{self._base_url}/api/embeddings",
                        json={"model": self._model, "prompt": t},
                    )
                    r.raise_for_status()
                    out.append(r.json()["embedding"])
                vectors = out
            else:
                resp.raise_for_status()
                vectors = resp.json()["embeddings"]
        except httpx.HTTPError as e:
            raise ProviderError(
                f"Ollama embedding call failed: {e}", provider="ollama", retryable=True
            ) from e
        if self._dimension is None and vectors:
            self._dimension = len(vectors[0])
        return [list(v) for v in vectors]
