"""Raggedy — batteries-included importable RAG core."""

from raggedy._version import __version__
from raggedy.config import RaggedyConfig
from raggedy.errors import (
    ConfigError,
    CostLimitExceeded,
    NoMatchesFound,
    ProviderError,
    RaggedyError,
)
from raggedy.pipeline import Raggedy, RAGPipeline
from raggedy.protocols import (
    Chunker,
    CostTracker,
    EmbeddingBackend,
    EventSink,
    LLMProvider,
    Logger,
    PIIRedactor,
    ProviderCapabilities,
    RunRecorder,
    VectorStore,
)
from raggedy.types import (
    Chunk,
    Document,
    LLMRequest,
    LLMResponse,
    PIIMatch,
    PIIType,
    QueryResult,
    RedactionResult,
    RunRecord,
    ScoredChunk,
    Source,
)

__all__ = [
    "Chunk",
    "Chunker",
    "ConfigError",
    "CostLimitExceeded",
    "CostTracker",
    "Document",
    "EmbeddingBackend",
    "EventSink",
    "LLMProvider",
    "LLMRequest",
    "LLMResponse",
    "Logger",
    "NoMatchesFound",
    "PIIMatch",
    "PIIRedactor",
    "PIIType",
    "ProviderCapabilities",
    "ProviderError",
    "QueryResult",
    "RAGPipeline",
    "Raggedy",
    "RaggedyConfig",
    "RaggedyError",
    "RedactionResult",
    "RunRecord",
    "RunRecorder",
    "ScoredChunk",
    "Source",
    "VectorStore",
    "__version__",
]
