"""RAG orchestration pipeline and the user-facing `Raggedy` facade.

The 14-step `RAGPipeline.query` flow:

  1. validate input
  2. start run record
  3. pre-flight cost estimate
  4. cost gate (raises `CostLimitExceeded`)
  5. PII-redact the query (record `redaction_applied` counts only)
  6. embed redacted query
  7. retrieve top-k chunks from vector store
  8. defense-in-depth: re-redact each retrieved chunk's text
  9. assemble [Source N]-cited context within `max_context_tokens`
 10. render versioned prompt template
 11. call LLM
 12. record actual usage with the cost tracker
 13. finish run record
 14. return QueryResult

`ingest` mirrors steps 1, 2, 5, 6, then `store.upsert` and `finish_run`.
"""

from __future__ import annotations

import time
from typing import Any

from raggedy.chunking.semantic import SemanticChunker
from raggedy.config import RaggedyConfig
from raggedy.cost.tracker import InMemoryCostTracker, NoOpCostTracker
from raggedy.embeddings.deterministic import DeterministicEmbedder
from raggedy.errors import (
    ConfigError,
    CostLimitExceeded,
    NoMatchesFound,
    ProviderError,
)
from raggedy.intake.pipeline import IntakeRunner
from raggedy.intake.protocols import Source as IntakeSource
from raggedy.llm.registry import build_llm
from raggedy.pii.noop import NoOpRedactor
from raggedy.pii.redactor import RegexPIIRedactor
from raggedy.prompts.templates import get_template
from raggedy.protocols import (
    Chunker,
    CostTracker,
    EmbeddingBackend,
    LLMProvider,
    PIIRedactor,
    RunRecorder,
    VectorStore,
)
from raggedy.recording.memory import InMemoryRunRecorder
from raggedy.stores.memory import InMemoryStore
from raggedy.types import (
    Chunk,
    Document,
    LLMRequest,
    QueryResult,
    ScoredChunk,
    Source,
)
from raggedy.util.sync import to_sync


class RAGPipeline:
    """Async orchestrator wired with concrete protocol implementations."""

    def __init__(
        self,
        config: RaggedyConfig,
        *,
        store: VectorStore,
        embedder: EmbeddingBackend,
        llm: LLMProvider,
        chunker: Chunker,
        redactor: PIIRedactor,
        cost: CostTracker,
        recorder: RunRecorder,
    ) -> None:
        self.config = config
        self.store = store
        self.embedder = embedder
        self.llm = llm
        self.chunker = chunker
        self.redactor = redactor
        self.cost = cost
        self.recorder = recorder

    async def ingest(
        self,
        documents: list[Document],
        *,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> list[Chunk]:
        ns = namespace or self.config.namespace
        if not documents:
            raise ConfigError("ingest called with no documents")
        run_id = await self.recorder.start_run(
            namespace=ns,
            kind="ingest",
            config_snapshot=self._snapshot(),
            tags=tags or {},
        )
        started = time.perf_counter()
        try:
            all_chunks: list[Chunk] = []
            for doc in documents:
                if not doc.text or not doc.text.strip():
                    continue
                redaction = self.redactor.redact(doc.text)
                await self.recorder.record_artifact(
                    run_id,
                    "redaction_applied",
                    {
                        "stage": "ingest",
                        "document_id": doc.id,
                        "counts_by_type": redaction.counts_by_type,
                        "pii_count": redaction.pii_count,
                        "policy_version": redaction.policy_version,
                        "patterns_version": redaction.patterns_version,
                    },
                )
                safe_doc = Document(
                    id=doc.id,
                    text=redaction.redacted_text,
                    tags=doc.tags,
                    metadata=doc.metadata,
                )
                try:
                    chunks = await self.chunker.chunk(safe_doc, namespace=ns)
                except Exception as e:
                    raise ConfigError(
                        f"Chunker failed on document {doc.id!r}: {type(e).__name__}: {e}"
                    ) from e
                if not chunks:
                    continue
                try:
                    vectors = await self.embedder.embed_batch([c.text for c in chunks])
                except ProviderError:
                    raise
                except Exception as e:
                    raise ProviderError(
                        f"Embedder failed on document {doc.id!r}: {type(e).__name__}: {e}",
                        provider=getattr(self.embedder, "model_id", "unknown"),
                        retryable=True,
                    ) from e
                if len(vectors) != len(chunks):
                    raise ProviderError(
                        f"Embedder returned {len(vectors)} vectors for "
                        f"{len(chunks)} chunks (document {doc.id!r}).",
                        provider=getattr(self.embedder, "model_id", "unknown"),
                    )
                for chunk, vec in zip(chunks, vectors, strict=True):
                    chunk.embedding = vec
                try:
                    await self.store.upsert(chunks)
                except Exception as e:
                    raise ConfigError(
                        f"VectorStore upsert failed: {type(e).__name__}: {e}"
                    ) from e
                all_chunks.extend(chunks)
            latency_ms = int((time.perf_counter() - started) * 1000)
            await self.recorder.finish_run(
                run_id,
                status="ok",
                result={"chunks_upserted": len(all_chunks), "documents": len(documents)},
                latency_ms=latency_ms,
            )
            return all_chunks
        except Exception as e:
            latency_ms = int((time.perf_counter() - started) * 1000)
            await self.recorder.finish_run(
                run_id,
                status="error",
                error=f"{type(e).__name__}: {e}",
                latency_ms=latency_ms,
            )
            raise

    async def query(
        self,
        query_text: str,
        *,
        namespace: str | None = None,
        top_k: int | None = None,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> QueryResult:
        # Step 1 — validate
        if not query_text or not query_text.strip():
            raise ConfigError("query must be a non-empty string")
        cfg = self.config
        ns = namespace or cfg.namespace
        top_k_eff = top_k if top_k is not None else cfg.top_k
        min_score_eff = min_score if min_score is not None else cfg.min_score

        # Step 2 — start run
        run_id = await self.recorder.start_run(
            namespace=ns,
            kind="query",
            query=query_text,
            config_snapshot=self._snapshot(),
            tags=tags or {},
        )
        started = time.perf_counter()

        try:
            # Step 3 — pre-flight cost estimate
            projected_prompt_tokens = self.llm.count_tokens(query_text) + cfg.max_context_tokens
            projected_cost = self.llm.estimate_cost(
                projected_prompt_tokens,
                cfg.llm_max_output_tokens,
                model=cfg.llm_model,
            )

            # Step 4 — cost gate
            try:
                await self.cost.check_limit(namespace=ns, projected_cost_usd=projected_cost)
            except Exception as e:
                latency_ms = int((time.perf_counter() - started) * 1000)
                await self.recorder.finish_run(
                    run_id,
                    status="cost_blocked",
                    error=f"{type(e).__name__}: {e}",
                    latency_ms=latency_ms,
                )
                raise

            # Step 5 — redact query
            redaction = self.redactor.redact(query_text)
            await self.recorder.record_artifact(
                run_id,
                "redaction_applied",
                {
                    "stage": "query",
                    "counts_by_type": redaction.counts_by_type,
                    "pii_count": redaction.pii_count,
                    "policy_version": redaction.policy_version,
                    "patterns_version": redaction.patterns_version,
                },
            )

            # Step 6 — embed
            try:
                qvec = await self.embedder.embed(redaction.redacted_text)
            except ProviderError:
                raise
            except Exception as e:
                raise ProviderError(
                    f"Embedder failed: {type(e).__name__}: {e}",
                    provider=getattr(self.embedder, "model_id", "unknown"),
                    retryable=True,
                ) from e

            # Step 7 — retrieve
            try:
                hits = await self.store.query(
                    qvec,
                    top_k=top_k_eff,
                    namespace=ns,
                    tags=tags,
                    min_score=min_score_eff,
                )
            except Exception as e:
                raise ConfigError(
                    f"VectorStore query failed: {type(e).__name__}: {e}"
                ) from e
            if not hits and cfg.empty_retrieval_policy == "raise":
                latency_ms = int((time.perf_counter() - started) * 1000)
                await self.recorder.finish_run(
                    run_id,
                    status="no_matches",
                    error=f"No chunks above min_score={min_score_eff} in namespace {ns!r}",
                    latency_ms=latency_ms,
                )
                raise NoMatchesFound(
                    f"No chunks above min_score={min_score_eff} in namespace {ns!r}"
                )

            # Step 8 — defense-in-depth re-redact chunk text
            safe_hits = self._redact_hits(hits)

            # Step 9 — assemble context
            context_str, sources, included = self._pack_context(safe_hits)
            await self.recorder.record_artifact(
                run_id,
                "retrieved_chunks",
                {
                    "hits": [
                        {
                            "chunk_id": h.chunk.id,
                            "document_id": h.chunk.document_id,
                            "score": h.score,
                            "tokens": h.chunk.token_count,
                            "included": h.chunk.id in included,
                        }
                        for h in safe_hits
                    ]
                },
            )

            # Step 10 — render prompt
            template = get_template(cfg.prompt_template_version)
            user_prompt = template["user"].format(context=context_str, query=redaction.redacted_text)
            system_prompt = template["system"]
            await self.recorder.record_artifact(
                run_id,
                "prompt_render",
                {
                    "prompt_template_version": cfg.prompt_template_version,
                    "system_chars": len(system_prompt),
                    "user_chars": len(user_prompt),
                },
            )

            # Step 11 — LLM call
            try:
                resp = await self.llm.complete(
                    LLMRequest(
                        system=system_prompt,
                        user=user_prompt,
                        model=cfg.llm_model,
                        max_tokens=cfg.llm_max_output_tokens,
                        temperature=cfg.llm_temperature,
                    )
                )
            except Exception as e:
                latency_ms = int((time.perf_counter() - started) * 1000)
                await self.recorder.finish_run(
                    run_id,
                    status="provider_error",
                    error=f"{type(e).__name__}: {e}",
                    latency_ms=latency_ms,
                )
                raise ProviderError(
                    f"{type(e).__name__}: {e}", provider=self.llm.name
                ) from e

            # Step 12 — record actual usage
            actual_cost = self.llm.estimate_cost(
                resp.prompt_tokens, resp.completion_tokens, model=cfg.llm_model
            )
            await self.cost.record_usage(
                namespace=ns,
                model=cfg.llm_model,
                cost_usd=actual_cost,
                prompt_tokens=resp.prompt_tokens,
                completion_tokens=resp.completion_tokens,
            )

            # Step 13 — finish run
            total_latency_ms = int((time.perf_counter() - started) * 1000)
            await self.recorder.finish_run(
                run_id,
                status="ok",
                result={
                    "answer_chars": len(resp.text),
                    "sources_count": len(sources),
                    "cost_usd": actual_cost,
                    "model": resp.model,
                    "provider": resp.provider,
                    "finish_reason": resp.finish_reason,
                },
                cost_usd=actual_cost,
                prompt_tokens=resp.prompt_tokens,
                completion_tokens=resp.completion_tokens,
                latency_ms=total_latency_ms,
            )

            # Step 14 — return
            return QueryResult(
                answer=resp.text,
                sources=sources,
                run_id=run_id,
                cost_usd=actual_cost,
                prompt_tokens=resp.prompt_tokens,
                completion_tokens=resp.completion_tokens,
                latency_ms=resp.latency_ms,
                finish_reason=resp.finish_reason,
                model=resp.model,
                provider=resp.provider,
                prompt_template_version=cfg.prompt_template_version,
            )
        except (ConfigError, ProviderError, NoMatchesFound, CostLimitExceeded):
            # These already finished the run record above (or are config-level
            # validation that fired before start_run). Don't double-finish.
            raise
        except Exception as e:
            latency_ms = int((time.perf_counter() - started) * 1000)
            await self.recorder.finish_run(
                run_id,
                status="error",
                error=f"{type(e).__name__}: {e}",
                latency_ms=latency_ms,
            )
            raise

    # -- helpers -----------------------------------------------------------

    def _redact_hits(self, hits: list[ScoredChunk]) -> list[ScoredChunk]:
        out: list[ScoredChunk] = []
        for h in hits:
            redaction = self.redactor.redact(h.chunk.text)
            safe_chunk = Chunk(
                id=h.chunk.id,
                document_id=h.chunk.document_id,
                namespace=h.chunk.namespace,
                text=redaction.redacted_text,
                chunk_index=h.chunk.chunk_index,
                start_char=h.chunk.start_char,
                end_char=h.chunk.end_char,
                token_count=h.chunk.token_count,
                overlap_tokens=h.chunk.overlap_tokens,
                start_page=h.chunk.start_page,
                end_page=h.chunk.end_page,
                tags=h.chunk.tags,
                metadata=h.chunk.metadata,
                embedding=None,
            )
            out.append(ScoredChunk(chunk=safe_chunk, score=h.score))
        return out

    def _pack_context(
        self, hits: list[ScoredChunk]
    ) -> tuple[str, list[Source], set[str]]:
        budget = self.config.max_context_tokens
        used = 0
        included: set[str] = set()
        parts: list[str] = []
        sources: list[Source] = []
        for i, h in enumerate(hits, start=1):
            header = f"[Source {i}] document={h.chunk.document_id} chunk={h.chunk.id}"
            block = f"{header}\n{h.chunk.text}\n"
            block_tokens = self.llm.count_tokens(block)
            if used + block_tokens > budget and sources:
                break
            used += block_tokens
            parts.append(block)
            included.add(h.chunk.id)
            sources.append(
                Source(
                    index=i,
                    document_id=h.chunk.document_id,
                    chunk_id=h.chunk.id,
                    score=h.score,
                    text_preview=h.chunk.text[:200],
                    start_char=h.chunk.start_char,
                    end_char=h.chunk.end_char,
                    start_page=h.chunk.start_page,
                    end_page=h.chunk.end_page,
                    tags=dict(h.chunk.tags),
                )
            )
        return "\n".join(parts), sources, included

    def _snapshot(self) -> dict[str, Any]:
        cfg = self.config.model_dump()
        # Strip nothing for now — config has no secrets, but if api_keys are added
        # later, scrub them here.
        return cfg


class Raggedy:
    """User-facing facade. Owns adapter wiring and exposes sync helpers."""

    def __init__(
        self,
        config: RaggedyConfig | None = None,
        *,
        store: VectorStore | None = None,
        embedder: EmbeddingBackend | None = None,
        llm: LLMProvider | None = None,
        chunker: Chunker | None = None,
        redactor: PIIRedactor | None = None,
        cost: CostTracker | None = None,
        recorder: RunRecorder | None = None,
        load_dotenv: bool = True,
    ) -> None:
        if load_dotenv:
            _load_dotenv_safely()
        cfg = config or RaggedyConfig()
        self.config = cfg
        self.store = store or _build_store(cfg)
        self.embedder = embedder or _build_embedder(cfg)
        self.llm = llm or build_llm(cfg.llm, cfg.llm_model)
        self.chunker = chunker or _build_chunker(cfg)
        self.redactor = redactor or _build_redactor(cfg)
        self.cost = cost or _build_cost(cfg)
        self.recorder = recorder or _build_recorder(cfg)
        self.pipeline = RAGPipeline(
            cfg,
            store=self.store,
            embedder=self.embedder,
            llm=self.llm,
            chunker=self.chunker,
            redactor=self.redactor,
            cost=self.cost,
            recorder=self.recorder,
        )

    async def ingest(
        self,
        documents: list[Document],
        *,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> list[Chunk]:
        return await self.pipeline.ingest(documents, namespace=namespace, tags=tags)

    async def query(
        self,
        query_text: str,
        *,
        namespace: str | None = None,
        top_k: int | None = None,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> QueryResult:
        return await self.pipeline.query(
            query_text,
            namespace=namespace,
            top_k=top_k,
            tags=tags,
            min_score=min_score,
        )

    def ingest_sync(
        self,
        documents: list[Document],
        *,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> list[Chunk]:
        return to_sync(self.ingest)(documents, namespace=namespace, tags=tags)

    async def ingest_from(
        self,
        source: IntakeSource,
        *,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
        batch_size: int = 32,
        skip_unsupported: bool = True,
        intake: IntakeRunner | None = None,
    ) -> list[Chunk]:
        """Stream documents from a `Source` through the intake layer and ingest.

        Documents are accumulated up to `batch_size` and then flushed to
        `ingest`, so large directories don't materialise every Document in
        memory at once.
        """
        runner = intake or IntakeRunner()
        buffered: list[Document] = []
        all_chunks: list[Chunk] = []
        async for doc in runner.documents(
            source, tags=tags, skip_unsupported=skip_unsupported
        ):
            buffered.append(doc)
            if len(buffered) >= batch_size:
                all_chunks.extend(
                    await self.ingest(buffered, namespace=namespace, tags=tags)
                )
                buffered = []
        if buffered:
            all_chunks.extend(
                await self.ingest(buffered, namespace=namespace, tags=tags)
            )
        return all_chunks

    def ingest_from_sync(
        self,
        source: IntakeSource,
        *,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
        batch_size: int = 32,
        skip_unsupported: bool = True,
        intake: IntakeRunner | None = None,
    ) -> list[Chunk]:
        return to_sync(self.ingest_from)(
            source,
            namespace=namespace,
            tags=tags,
            batch_size=batch_size,
            skip_unsupported=skip_unsupported,
            intake=intake,
        )

    def query_sync(
        self,
        query_text: str,
        *,
        namespace: str | None = None,
        top_k: int | None = None,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> QueryResult:
        return to_sync(self.query)(
            query_text,
            namespace=namespace,
            top_k=top_k,
            tags=tags,
            min_score=min_score,
        )


# -- adapter wiring helpers --------------------------------------------------


def _load_dotenv_safely() -> None:
    """Populate os.environ from a `.env` file in CWD if present.

    Existing env vars are NOT overridden. We import python-dotenv lazily and
    swallow ImportError — Raggedy still works without it; the user just won't
    get auto-loading.
    """
    import contextlib

    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    # A malformed .env should never crash Raggedy init.
    with contextlib.suppress(Exception):
        load_dotenv(override=False)


def _build_store(cfg: RaggedyConfig) -> VectorStore:
    name = cfg.store
    if name == "memory":
        return InMemoryStore()
    import importlib

    lazy = {
        "sqlite-vec": ("raggedy.stores.sqlite_vec", "SqliteVecStore", "sqlitevec"),
        "pgvector":   ("raggedy.stores.pgvector",   "PgVectorStore",  "pgvector"),
        "qdrant":     ("raggedy.stores.qdrant",     "QdrantStore",    "qdrant"),
        "chroma":     ("raggedy.stores.chroma",     "ChromaStore",    "chroma"),
        "weaviate":   ("raggedy.stores.weaviate",   "WeaviateStore",  "weaviate"),
    }
    if name not in lazy:
        raise ConfigError(
            f"Store {name!r} is not available. Known: "
            f"memory | sqlite-vec | pgvector | qdrant | chroma | weaviate"
        )
    mod_name, cls_name, extra = lazy[name]
    try:
        mod = importlib.import_module(mod_name)
    except ImportError as e:
        raise ConfigError(
            f"Store {name!r} requires its adapter to ship and its extra installed. "
            f"Try: pip install 'raggedy[{extra}]' once the adapter is available."
        ) from e
    cls = getattr(mod, cls_name)
    try:
        instance: VectorStore = cls(url=cfg.store_url) if cfg.store_url else cls()
        return instance
    except Exception as e:
        raise ConfigError(
            f"Store {name!r} failed to initialise: {type(e).__name__}: {e}"
        ) from e


def _build_embedder(cfg: RaggedyConfig) -> EmbeddingBackend:
    name = cfg.embedding
    try:
        if name == "deterministic":
            return DeterministicEmbedder(dimension=cfg.embedding_dimension)
        if name in ("sentence-transformers", "local"):
            from raggedy.embeddings.local import SentenceTransformersEmbedder

            return SentenceTransformersEmbedder(
                model_name=cfg.embedding_model,
                device=cfg.device,
                batch_size=cfg.embedding_batch_size,
            )
        if name == "openai":
            from raggedy.embeddings.openai import OpenAIEmbedder

            return OpenAIEmbedder(model=cfg.embedding_model)
        if name == "ollama":
            from raggedy.embeddings.ollama import OllamaEmbedder

            return OllamaEmbedder(model=cfg.embedding_model)
        if name in ("lm_studio", "lmstudio"):
            import os

            from raggedy.embeddings.openai import OpenAIEmbedder

            return OpenAIEmbedder(
                model=cfg.embedding_model,
                api_key=os.getenv("LMSTUDIO_API_KEY", "lm-studio"),
                base_url=os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1"),
            )
    except ConfigError:
        raise
    except Exception as e:
        raise ConfigError(
            f"Embedder {name!r} failed to initialise: {type(e).__name__}: {e}"
        ) from e
    raise ConfigError(
        f"Embedder {name!r} is not available. Known: "
        f"deterministic | sentence-transformers | openai | ollama | lm_studio"
    )


def _build_chunker(cfg: RaggedyConfig) -> Chunker:
    name = cfg.chunker_strategy
    try:
        if name == "semantic":
            return SemanticChunker(
                target_tokens=cfg.chunk_target_tokens,
                overlap_tokens=cfg.chunk_overlap_tokens,
                min_chunk_tokens=cfg.chunk_min_tokens,
            )
        if name == "paragraph":
            from raggedy.chunking.paragraph import ParagraphChunker

            return ParagraphChunker(
                target_tokens=cfg.chunk_target_tokens,
                overlap_tokens=cfg.chunk_overlap_tokens,
                min_chunk_tokens=cfg.chunk_min_tokens,
            )
        if name == "sentence":
            from raggedy.chunking.sentence import SentenceChunker

            return SentenceChunker(
                target_tokens=cfg.chunk_target_tokens,
                overlap_tokens=cfg.chunk_overlap_tokens,
                min_chunk_tokens=cfg.chunk_min_tokens,
            )
        if name == "fixed":
            from raggedy.chunking.fixed import FixedChunker

            return FixedChunker(
                target_tokens=cfg.chunk_target_tokens,
                overlap_tokens=cfg.chunk_overlap_tokens,
                min_chunk_tokens=cfg.chunk_min_tokens,
            )
    except ValueError as e:
        raise ConfigError(f"Chunker {name!r}: {e}") from e
    raise ConfigError(
        f"Chunker {name!r} is not available. Known: "
        f"semantic | paragraph | sentence | fixed"
    )


def _build_redactor(cfg: RaggedyConfig) -> PIIRedactor:
    if not cfg.redaction_enabled:
        return NoOpRedactor()
    return RegexPIIRedactor(policy_version=cfg.redaction_policy)


def _build_cost(cfg: RaggedyConfig) -> CostTracker:
    if not cfg.cost_tracking_enabled:
        return NoOpCostTracker()
    name = getattr(cfg, "cost_backend", "memory")
    if name == "memory":
        return InMemoryCostTracker(daily_limit_usd=cfg.cost_daily_limit_usd)
    if name == "sqlite":
        import importlib

        try:
            mod = importlib.import_module("raggedy.cost.sqlite")
        except ImportError as e:
            raise ConfigError(
                "Cost tracker 'sqlite' requires aiosqlite. "
                "Install with: pip install 'raggedy[sqlitevec]'"
            ) from e
        try:
            sqlite_cost: CostTracker = mod.SqliteCostTracker(
                url=cfg.cost_backend_url or "raggedy_cost.db",
                daily_limit_usd=cfg.cost_daily_limit_usd,
            )
            return sqlite_cost
        except ConfigError:
            raise
        except Exception as e:
            raise ConfigError(
                f"SqliteCostTracker failed to initialise: {type(e).__name__}: {e}"
            ) from e
    raise ConfigError(
        f"Cost backend {name!r} is not available. Known: memory | sqlite"
    )


def _build_recorder(cfg: RaggedyConfig) -> RunRecorder:
    name = cfg.recorder
    if name == "memory":
        return InMemoryRunRecorder()
    if name == "sqlite":
        import importlib

        try:
            mod = importlib.import_module("raggedy.recording.sqlite")
        except ImportError as e:
            raise ConfigError(
                "Recorder 'sqlite' requires aiosqlite. "
                "Install with: pip install 'raggedy[sqlitevec]'"
            ) from e
        try:
            sqlite_recorder: RunRecorder = mod.SqliteRunRecorder(
                url=cfg.recorder_url or "raggedy_runs.db"
            )
            return sqlite_recorder
        except ConfigError:
            raise
        except Exception as e:
            raise ConfigError(
                f"SqliteRunRecorder failed to initialise: {type(e).__name__}: {e}"
            ) from e
    raise ConfigError(
        f"Recorder {name!r} is not available. Known: memory | sqlite"
    )
