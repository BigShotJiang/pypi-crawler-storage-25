"""Exception hierarchy raised by Raggedy."""

from __future__ import annotations


class RaggedyError(Exception):
    """Base class for every exception Raggedy raises."""


class ConfigError(RaggedyError):
    """A configuration value or dependency is invalid or missing."""


class CostLimitExceeded(RaggedyError):
    """A pre-flight cost check would push a namespace past its limit."""

    def __init__(self, message: str, *, namespace: str, projected_cost_usd: float, limit_usd: float):
        super().__init__(message)
        self.namespace = namespace
        self.projected_cost_usd = projected_cost_usd
        self.limit_usd = limit_usd


class NoMatchesFound(RaggedyError):
    """Retrieval returned no chunks above the configured threshold."""


class ProviderError(RaggedyError):
    """An LLM or embedding provider failed."""

    def __init__(self, message: str, *, provider: str, retryable: bool = False):
        super().__init__(message)
        self.provider = provider
        self.retryable = retryable
