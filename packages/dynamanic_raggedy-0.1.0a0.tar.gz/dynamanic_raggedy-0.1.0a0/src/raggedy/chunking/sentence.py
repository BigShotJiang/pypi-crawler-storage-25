"""Sentence chunker.

Splits on sentence boundaries (`.!?` followed by whitespace + capital).
Sentences are greedily merged up to `target_tokens`; an oversize sentence
becomes its own chunk. No overlap by default — set `overlap_tokens` to
include trailing tokens from the previous chunk.
"""

from __future__ import annotations

import hashlib
import re

from raggedy.types import Chunk, Document
from raggedy.util.ids import new_chunk_id
from raggedy.util.tokens import naive_token_count

SENTENCE_PATTERN = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"'\(])")


class SentenceChunker:
    strategy = "sentence"

    def __init__(
        self,
        target_tokens: int = 256,
        overlap_tokens: int = 0,
        min_chunk_tokens: int = 1,
    ) -> None:
        if target_tokens < 1:
            raise ValueError("target_tokens must be >= 1")
        if overlap_tokens < 0 or overlap_tokens >= target_tokens:
            raise ValueError("overlap_tokens must be in [0, target_tokens)")
        self.target_tokens = target_tokens
        self.overlap_tokens = overlap_tokens
        self.min_chunk_tokens = min_chunk_tokens

    async def chunk(self, document: Document, *, namespace: str) -> list[Chunk]:
        text = document.text
        if not text or not text.strip():
            return []
        sentences = _split_sentences(text)
        merged: list[tuple[int, int]] = []
        cur_start: int | None = None
        cur_end: int = 0
        for start, end in sentences:
            if cur_start is None:
                cur_start, cur_end = start, end
                continue
            combined_tokens = naive_token_count(text[cur_start:end])
            if combined_tokens <= self.target_tokens:
                cur_end = end
            else:
                merged.append((cur_start, cur_end))
                cur_start, cur_end = start, end
        if cur_start is not None:
            merged.append((cur_start, cur_end))

        chunks: list[Chunk] = []
        for idx, (start, end) in enumerate(merged):
            piece_start = start
            overlap_token_count = 0
            if self.overlap_tokens > 0 and idx > 0:
                prev_start, _prev_end = merged[idx - 1]
                overlap_chars = self.overlap_tokens * 4
                piece_start = max(prev_start, start - overlap_chars)
                while piece_start > prev_start and not text[piece_start].isspace():
                    piece_start -= 1
                overlap_token_count = naive_token_count(text[piece_start:start])
            piece = text[piece_start:end]
            chunks.append(
                Chunk(
                    id=new_chunk_id(document.id, idx),
                    document_id=document.id,
                    namespace=namespace,
                    text=piece,
                    chunk_index=idx,
                    start_char=piece_start,
                    end_char=end,
                    token_count=naive_token_count(piece),
                    overlap_tokens=overlap_token_count,
                    tags=dict(document.tags),
                    metadata={
                        **document.metadata,
                        "content_hash": hashlib.sha256(piece.encode("utf-8")).hexdigest(),
                    },
                )
            )
        return chunks


def _split_sentences(text: str) -> list[tuple[int, int]]:
    spans: list[tuple[int, int]] = []
    cursor = 0
    for m in SENTENCE_PATTERN.finditer(text):
        if cursor < m.start():
            spans.append((cursor, m.start()))
        cursor = m.end()
    if cursor < len(text):
        spans.append((cursor, len(text)))
    return [(s, e) for s, e in spans if text[s:e].strip()]
