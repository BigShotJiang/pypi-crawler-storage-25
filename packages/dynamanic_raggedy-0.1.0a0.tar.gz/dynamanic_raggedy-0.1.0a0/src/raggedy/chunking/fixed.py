"""Fixed-window chunker.

Slices text into windows of approximately `target_tokens` (character-wise,
no boundary awareness). Snaps the start of each chunk back to a whitespace
boundary so words aren't split mid-character. Useful as a fallback or for
benchmarking against the smarter chunkers.
"""

from __future__ import annotations

import hashlib

from raggedy.types import Chunk, Document
from raggedy.util.ids import new_chunk_id
from raggedy.util.tokens import naive_token_count


class FixedChunker:
    strategy = "fixed"

    def __init__(
        self,
        target_tokens: int = 256,
        overlap_tokens: int = 32,
        min_chunk_tokens: int = 1,
    ) -> None:
        if target_tokens < 1:
            raise ValueError("target_tokens must be >= 1")
        if overlap_tokens < 0 or overlap_tokens >= target_tokens:
            raise ValueError("overlap_tokens must be in [0, target_tokens)")
        self.target_tokens = target_tokens
        self.overlap_tokens = overlap_tokens
        self.min_chunk_tokens = min_chunk_tokens

    async def chunk(self, document: Document, *, namespace: str) -> list[Chunk]:
        text = document.text
        if not text or not text.strip():
            return []
        window_chars = max(4, self.target_tokens * 4)
        step_chars = max(1, window_chars - self.overlap_tokens * 4)
        chunks: list[Chunk] = []
        n = len(text)
        cursor = 0
        idx = 0
        while cursor < n:
            end = min(n, cursor + window_chars)
            start = cursor
            # Snap start back to a whitespace boundary (except for first chunk).
            if idx > 0:
                while start > 0 and not text[start].isspace():
                    start -= 1
            piece = text[start:end]
            if piece.strip():
                overlap_token_count = (
                    naive_token_count(text[start:cursor]) if idx > 0 else 0
                )
                chunks.append(
                    Chunk(
                        id=new_chunk_id(document.id, idx),
                        document_id=document.id,
                        namespace=namespace,
                        text=piece,
                        chunk_index=idx,
                        start_char=start,
                        end_char=end,
                        token_count=naive_token_count(piece),
                        overlap_tokens=overlap_token_count,
                        tags=dict(document.tags),
                        metadata={
                            **document.metadata,
                            "content_hash": hashlib.sha256(
                                piece.encode("utf-8")
                            ).hexdigest(),
                        },
                    )
                )
                idx += 1
            cursor += step_chars
            if cursor >= n:
                break
        return chunks
