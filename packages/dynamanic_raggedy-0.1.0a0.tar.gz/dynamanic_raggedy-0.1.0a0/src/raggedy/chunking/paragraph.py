"""Paragraph chunker.

One chunk per paragraph (`\\n\\s*\\n` boundary). No merging, no overlap —
just clean splits. Useful when paragraphs are already the unit of meaning
(FAQs, prose with stable section structure).
"""

from __future__ import annotations

import hashlib
import re

from raggedy.types import Chunk, Document
from raggedy.util.ids import new_chunk_id
from raggedy.util.tokens import naive_token_count

PARAGRAPH_PATTERN = re.compile(r"\n\s*\n")


class ParagraphChunker:
    strategy = "paragraph"

    def __init__(
        self,
        target_tokens: int = 512,
        overlap_tokens: int = 0,
        min_chunk_tokens: int = 1,
    ) -> None:
        # target/overlap/min are accepted for protocol parity but unused —
        # paragraph boundaries are the only split rule.
        self.target_tokens = target_tokens
        self.overlap_tokens = overlap_tokens
        self.min_chunk_tokens = min_chunk_tokens

    async def chunk(self, document: Document, *, namespace: str) -> list[Chunk]:
        text = document.text
        if not text or not text.strip():
            return []
        spans: list[tuple[int, int]] = []
        cursor = 0
        for m in PARAGRAPH_PATTERN.finditer(text):
            spans.append((cursor, m.start()))
            cursor = m.end()
        spans.append((cursor, len(text)))
        chunks: list[Chunk] = []
        for start, end in _drop_blank(spans, text):
            piece = text[start:end]
            chunks.append(
                Chunk(
                    id=new_chunk_id(document.id, len(chunks)),
                    document_id=document.id,
                    namespace=namespace,
                    text=piece,
                    chunk_index=len(chunks),
                    start_char=start,
                    end_char=end,
                    token_count=naive_token_count(piece),
                    overlap_tokens=0,
                    tags=dict(document.tags),
                    metadata={
                        **document.metadata,
                        "content_hash": hashlib.sha256(piece.encode("utf-8")).hexdigest(),
                    },
                )
            )
        return chunks


def _drop_blank(spans: list[tuple[int, int]], text: str) -> list[tuple[int, int]]:
    return [(s, e) for s, e in spans if s < e and text[s:e].strip()]
