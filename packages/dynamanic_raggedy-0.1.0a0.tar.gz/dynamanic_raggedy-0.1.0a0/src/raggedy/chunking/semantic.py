"""Semantic chunker.

Splits text on paragraph boundaries, falls back to sentence boundaries
for paragraphs that exceed `target_tokens`, merges runs of small paragraphs
up to the target, and applies a leading overlap from the tail of the previous
chunk. Character offsets reference the original document text so callers
can highlight or quote exact spans.
"""

from __future__ import annotations

import hashlib
import re
from itertools import pairwise

from raggedy.types import Chunk, Document
from raggedy.util.ids import new_chunk_id
from raggedy.util.tokens import naive_token_count

PARAGRAPH_PATTERN = re.compile(r"\n\s*\n")
SENTENCE_PATTERN = re.compile(r"(?<=[.!?])\s+(?=[A-Z\"'\(])")


class SemanticChunker:
    strategy = "semantic"

    def __init__(
        self,
        target_tokens: int = 512,
        overlap_tokens: int = 100,
        min_chunk_tokens: int = 50,
    ) -> None:
        if target_tokens < 1:
            raise ValueError("target_tokens must be >= 1")
        if overlap_tokens < 0 or overlap_tokens >= target_tokens:
            raise ValueError("overlap_tokens must be in [0, target_tokens)")
        if min_chunk_tokens < 0 or min_chunk_tokens > target_tokens:
            raise ValueError("min_chunk_tokens must be in [0, target_tokens]")
        self.target_tokens = target_tokens
        self.overlap_tokens = overlap_tokens
        self.min_chunk_tokens = min_chunk_tokens

    async def chunk(self, document: Document, *, namespace: str) -> list[Chunk]:
        segments = self._split_segments(document.text)
        merged = self._merge_segments(segments)
        with_overlap = self._apply_overlap(merged, document.text)
        chunks: list[Chunk] = []
        for idx, (start, end, overlap_tokens) in enumerate(with_overlap):
            text = document.text[start:end]
            chunks.append(
                Chunk(
                    id=new_chunk_id(document.id, idx),
                    document_id=document.id,
                    namespace=namespace,
                    text=text,
                    chunk_index=idx,
                    start_char=start,
                    end_char=end,
                    token_count=naive_token_count(text),
                    overlap_tokens=overlap_tokens,
                    tags=dict(document.tags),
                    metadata={
                        **document.metadata,
                        "content_hash": hashlib.sha256(text.encode("utf-8")).hexdigest(),
                    },
                )
            )
        return chunks

    def _split_segments(self, text: str) -> list[tuple[int, int]]:
        """Return (start, end) spans for each segment in order.

        First-pass split on paragraphs; over-long paragraphs are sub-split
        on sentences. Empty/whitespace-only spans are dropped.
        """
        spans: list[tuple[int, int]] = []
        cursor = 0
        for match in PARAGRAPH_PATTERN.finditer(text):
            spans.append((cursor, match.start()))
            cursor = match.end()
        spans.append((cursor, len(text)))

        out: list[tuple[int, int]] = []
        for start, end in spans:
            if start >= end or not text[start:end].strip():
                continue
            if naive_token_count(text[start:end]) <= self.target_tokens:
                out.append((start, end))
                continue
            # Over-long paragraph: split on sentences.
            sub_cursor = start
            for sm in SENTENCE_PATTERN.finditer(text, start, end):
                if sub_cursor < sm.start():
                    out.append((sub_cursor, sm.start()))
                sub_cursor = sm.end()
            if sub_cursor < end:
                out.append((sub_cursor, end))
        return out

    def _merge_segments(self, spans: list[tuple[int, int]]) -> list[tuple[int, int]]:
        """Greedy merge: extend current span until it would exceed target_tokens."""
        if not spans:
            return []
        merged: list[tuple[int, int]] = []
        cur_start, cur_end = spans[0]
        for start, end in spans[1:]:
            combined_token_estimate = naive_token_count_for_range(cur_start, end)
            if combined_token_estimate <= self.target_tokens:
                cur_end = end
            else:
                merged.append((cur_start, cur_end))
                cur_start, cur_end = start, end
        merged.append((cur_start, cur_end))
        # Drop trailing tiny chunks by folding into previous when possible.
        if len(merged) >= 2:
            last_start, last_end = merged[-1]
            last_tokens = (last_end - last_start) // 4
            if last_tokens < self.min_chunk_tokens:
                prev_start, _ = merged[-2]
                merged[-2] = (prev_start, last_end)
                merged.pop()
        return merged

    def _apply_overlap(
        self, spans: list[tuple[int, int]], text: str
    ) -> list[tuple[int, int, int]]:
        """Apply leading overlap by extending each chunk's start backwards.

        Returns (start, end, overlap_token_count) tuples. The first chunk has
        zero overlap. Subsequent chunks pull back into the previous chunk's tail
        until their leading region carries approximately `overlap_tokens`.
        """
        if not spans:
            return []
        out: list[tuple[int, int, int]] = [(spans[0][0], spans[0][1], 0)]
        for prev, (start, end) in pairwise(spans):
            prev_start, _ = prev
            overlap_chars = self.overlap_tokens * 4
            new_start = max(prev_start, start - overlap_chars)
            # Snap to a word boundary to avoid cutting tokens.
            while new_start > prev_start and not text[new_start].isspace():
                new_start -= 1
            overlap_text = text[new_start:start]
            out.append((new_start, end, naive_token_count(overlap_text)))
        return out


def naive_token_count_for_range(start: int, end: int) -> int:
    return max(1, (end - start) // 4)
