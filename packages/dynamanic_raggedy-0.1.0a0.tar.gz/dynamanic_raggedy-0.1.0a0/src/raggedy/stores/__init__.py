from raggedy.stores.memory import InMemoryStore

__all__ = ["InMemoryStore"]

# Optional adapters are lazily imported by name through `pipeline._build_store`
# to avoid forcing every user to install asyncpg / sqlite-vec / qdrant-client.
# Import them directly when you need to construct them by hand:
#     from raggedy.stores.sqlite_vec import SqliteVecStore
#     from raggedy.stores.pgvector import PgVectorStore
