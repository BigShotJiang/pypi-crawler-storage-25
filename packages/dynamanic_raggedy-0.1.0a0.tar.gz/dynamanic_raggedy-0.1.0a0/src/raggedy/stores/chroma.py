"""ChromaDB vector store — `pip install raggedy[chroma]`.

Uses Chroma's sync clients wrapped with `asyncio.to_thread` so the same
code path covers embedded, persistent-file, and HTTP-server deployments.

`url` accepts:
    None / ":memory:"        → EphemeralClient (in-process, default for tests)
    "http://host:8000"       → HttpClient against a Chroma server
    "/path/to/dir"           → PersistentClient (on-disk)

Chroma metadata values must be primitives, so each `tags` entry is flattened
to a `tag_<key>` top-level field, and `Chunk.metadata` is stored as a single
JSON string under `metadata_json`.
"""

from __future__ import annotations

import asyncio
import json
import os
from typing import Any
from urllib.parse import urlparse

from raggedy.errors import ConfigError, ProviderError
from raggedy.types import Chunk, ScoredChunk

DEFAULT_COLLECTION = "raggedy"
_TAG_PREFIX = "tag_"


class ChromaStore:
    def __init__(
        self,
        url: str | None = None,
        *,
        collection: str = DEFAULT_COLLECTION,
        tenant: str | None = None,
        database: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        try:
            import chromadb  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "Chroma store requires extras. "
                "Install with: pip install 'raggedy[chroma]'"
            ) from e
        if not _safe_collection_name(collection):
            raise ConfigError(
                f"Invalid collection name {collection!r} (must match [A-Za-z0-9_-]+)."
            )
        self._url = url
        self._collection_name = collection
        self._tenant = tenant
        self._database = database
        self._headers = headers
        self._client: Any = None
        self._collection: Any = None
        self._dim: int | None = None
        self._lock = asyncio.Lock()

    def _build_client_sync(self) -> Any:
        import chromadb

        url = self._url
        if url is None or url == ":memory:":
            return chromadb.EphemeralClient()
        if url.startswith("http://") or url.startswith("https://"):
            parsed = urlparse(url)
            host = parsed.hostname or "localhost"
            port = parsed.port or (443 if parsed.scheme == "https" else 8000)
            kwargs: dict[str, Any] = {
                "host": host,
                "port": port,
                "ssl": parsed.scheme == "https",
            }
            if self._headers:
                kwargs["headers"] = self._headers
            if self._tenant:
                kwargs["tenant"] = self._tenant
            if self._database:
                kwargs["database"] = self._database
            return chromadb.HttpClient(**kwargs)
        # Treat anything else as a local persistent path.
        return chromadb.PersistentClient(path=os.path.abspath(url))

    async def _get_client(self) -> Any:
        if self._client is not None:
            return self._client
        try:
            self._client = await asyncio.to_thread(self._build_client_sync)
        except Exception as e:
            raise ConfigError(
                f"ChromaStore could not connect to {self._url!r}: "
                f"{type(e).__name__}: {e}"
            ) from e
        return self._client

    async def _ensure_collection(self, dim: int) -> None:
        if self._dim is not None:
            if self._dim != dim:
                raise ProviderError(
                    f"Embedding dimension mismatch: store dim={self._dim}, got {dim}",
                    provider="chroma",
                )
            return
        client = await self._get_client()

        def _get_or_create() -> Any:
            # We provide our own embeddings; tell Chroma not to install its
            # default embedding function (which pulls onnxruntime).
            return client.get_or_create_collection(
                name=self._collection_name,
                metadata={"hnsw:space": "cosine"},
                embedding_function=None,
            )

        try:
            self._collection = await asyncio.to_thread(_get_or_create)
            # Stamp dim from existing collection if present.
            count = await asyncio.to_thread(self._collection.count)
            if count > 0:
                peek = await asyncio.to_thread(self._collection.peek, 1)
                embeds = peek.get("embeddings") or []
                if embeds and embeds[0] is not None and len(embeds[0]) != dim:
                    raise ProviderError(
                        f"Existing Chroma collection has dim {len(embeds[0])}, "
                        f"but inputs have dim {dim}.",
                        provider="chroma",
                    )
            self._dim = dim
        except ProviderError:
            raise
        except Exception as e:
            raise ConfigError(
                f"ChromaStore schema init failed: {type(e).__name__}: {e}"
            ) from e

    async def upsert(self, chunks: list[Chunk]) -> None:
        if not chunks:
            return
        for c in chunks:
            if c.embedding is None:
                raise ProviderError(
                    f"Chunk {c.id!r} has no embedding", provider="chroma"
                )
        dim = len(chunks[0].embedding or [])
        async with self._lock:
            await self._ensure_collection(dim)
        collection = self._collection
        ids = [c.id for c in chunks]
        embeddings = [list(c.embedding or []) for c in chunks]
        documents = [c.text for c in chunks]
        metadatas = [_chunk_to_metadata(c) for c in chunks]
        try:
            await asyncio.to_thread(
                collection.upsert,
                ids=ids,
                embeddings=embeddings,
                metadatas=metadatas,
                documents=documents,
            )
        except Exception as e:
            raise ProviderError(
                f"ChromaStore upsert failed: {type(e).__name__}: {e}",
                provider="chroma",
            ) from e

    async def query(
        self,
        vector: list[float],
        *,
        top_k: int,
        namespace: str,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> list[ScoredChunk]:
        if self._dim is None or self._collection is None:
            return []
        if len(vector) != self._dim:
            raise ProviderError(
                f"Query vector dim {len(vector)} != store dim {self._dim}",
                provider="chroma",
            )
        where = _build_where(namespace, tags)
        try:
            result = await asyncio.to_thread(
                self._collection.query,
                query_embeddings=[list(vector)],
                n_results=top_k,
                where=where,
                include=["distances", "metadatas", "documents"],
            )
        except Exception as e:
            raise ProviderError(
                f"ChromaStore query failed: {type(e).__name__}: {e}",
                provider="chroma",
            ) from e
        ids_rows = result.get("ids") or [[]]
        dist_rows = result.get("distances") or [[]]
        meta_rows = result.get("metadatas") or [[]]
        doc_rows = result.get("documents") or [[]]
        ids = ids_rows[0] if ids_rows else []
        distances = dist_rows[0] if dist_rows else []
        metadatas = meta_rows[0] if meta_rows else []
        documents = doc_rows[0] if doc_rows else []
        results: list[ScoredChunk] = []
        for cid, dist, meta, doc in zip(ids, distances, metadatas, documents, strict=False):
            score = 1.0 - float(dist)
            if min_score is not None and score < min_score:
                continue
            results.append(
                ScoredChunk(chunk=_metadata_to_chunk(cid, doc or "", meta or {}), score=score)
            )
        return results

    async def delete(
        self,
        *,
        ids: list[str] | None = None,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> int:
        if self._dim is None or self._collection is None:
            return 0
        if ids is not None and not ids:
            return 0
        where = _build_where(namespace, tags) if (namespace is not None or tags) else None
        try:
            if ids is not None:
                # Resolve count under the filter to know what we're about to delete.
                found = await asyncio.to_thread(
                    self._collection.get, ids=ids, where=where, include=[]
                )
                matching_ids = list(found.get("ids") or [])
                if not matching_ids:
                    return 0
                await asyncio.to_thread(self._collection.delete, ids=matching_ids)
                return len(matching_ids)
            if where is not None:
                found = await asyncio.to_thread(
                    self._collection.get, where=where, include=[]
                )
                matching_ids = list(found.get("ids") or [])
                if not matching_ids:
                    return 0
                await asyncio.to_thread(self._collection.delete, ids=matching_ids)
                return len(matching_ids)
            return 0
        except Exception as e:
            raise ProviderError(
                f"ChromaStore delete failed: {type(e).__name__}: {e}",
                provider="chroma",
            ) from e

    async def count(self, *, namespace: str | None = None) -> int:
        if self._dim is None or self._collection is None:
            return 0
        try:
            if namespace is None:
                return int(await asyncio.to_thread(self._collection.count))
            found = await asyncio.to_thread(
                self._collection.get, where={"namespace": namespace}, include=[]
            )
            return len(found.get("ids") or [])
        except Exception as e:
            raise ProviderError(
                f"ChromaStore count failed: {type(e).__name__}: {e}",
                provider="chroma",
            ) from e

    async def aclose(self) -> None:
        # Chroma clients don't expose async close. Reset references so the
        # next operation creates a fresh client. The underlying connection
        # cleanup happens at process exit.
        self._client = None
        self._collection = None


def _chunk_to_metadata(c: Chunk) -> dict[str, Any]:
    base: dict[str, Any] = {
        "document_id": c.document_id,
        "namespace": c.namespace,
        "chunk_index": c.chunk_index,
        "start_char": c.start_char,
        "end_char": c.end_char,
        "token_count": c.token_count,
        "overlap_tokens": c.overlap_tokens,
    }
    if c.start_page is not None:
        base["start_page"] = c.start_page
    if c.end_page is not None:
        base["end_page"] = c.end_page
    for k, v in c.tags.items():
        if isinstance(v, str | int | float | bool):
            base[f"{_TAG_PREFIX}{k}"] = v
    if c.metadata:
        base["metadata_json"] = json.dumps(c.metadata)
    return base


def _metadata_to_chunk(cid: str, text: str, meta: dict[str, Any]) -> Chunk:
    tags = {
        k[len(_TAG_PREFIX):]: str(v)
        for k, v in meta.items()
        if k.startswith(_TAG_PREFIX)
    }
    try:
        extra = json.loads(meta.get("metadata_json", "")) if meta.get("metadata_json") else {}
    except Exception:
        extra = {}
    return Chunk(
        id=cid,
        document_id=str(meta.get("document_id", "")),
        namespace=str(meta.get("namespace", "")),
        text=text,
        chunk_index=int(meta.get("chunk_index", 0) or 0),
        start_char=int(meta.get("start_char", 0) or 0),
        end_char=int(meta.get("end_char", 0) or 0),
        token_count=int(meta.get("token_count", 0) or 0),
        overlap_tokens=int(meta.get("overlap_tokens", 0) or 0),
        start_page=meta.get("start_page"),
        end_page=meta.get("end_page"),
        tags=tags,
        metadata=extra,
        embedding=None,
    )


def _build_where(
    namespace: str | None, tags: dict[str, str] | None
) -> dict[str, Any] | None:
    clauses: list[dict[str, Any]] = []
    if namespace is not None:
        clauses.append({"namespace": namespace})
    if tags:
        for k, v in tags.items():
            clauses.append({f"{_TAG_PREFIX}{k}": v})
    if not clauses:
        return None
    if len(clauses) == 1:
        return clauses[0]
    return {"$and": clauses}


def _safe_collection_name(name: str) -> bool:
    if not name:
        return False
    return all(ch.isalnum() or ch in ("_", "-") for ch in name)
