"""In-memory vector store.

Plain dict of `chunk_id -> Chunk` per namespace. Cosine similarity computed
with numpy. Suitable for tests, demos, and small (< ~100k chunk) workloads.
"""

from __future__ import annotations

from collections import defaultdict

import numpy as np

from raggedy.types import Chunk, ScoredChunk


class InMemoryStore:
    def __init__(self) -> None:
        self._chunks: dict[str, dict[str, Chunk]] = defaultdict(dict)

    async def upsert(self, chunks: list[Chunk]) -> None:
        for chunk in chunks:
            if chunk.embedding is None:
                raise ValueError(f"Chunk {chunk.id} has no embedding; cannot upsert")
            self._chunks[chunk.namespace][chunk.id] = chunk

    async def query(
        self,
        vector: list[float],
        *,
        top_k: int,
        namespace: str,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> list[ScoredChunk]:
        bucket = self._chunks.get(namespace)
        if not bucket:
            return []
        q = np.asarray(vector, dtype=np.float32)
        q_norm = float(np.linalg.norm(q))
        if q_norm == 0.0:
            return []
        q = q / q_norm

        candidates: list[ScoredChunk] = []
        for chunk in bucket.values():
            if tags and not _tags_match(chunk.tags, tags):
                continue
            if chunk.embedding is None:
                continue
            v = np.asarray(chunk.embedding, dtype=np.float32)
            v_norm = float(np.linalg.norm(v))
            if v_norm == 0.0:
                continue
            score = float(np.dot(q, v / v_norm))
            if min_score is not None and score < min_score:
                continue
            candidates.append(ScoredChunk(chunk=chunk, score=score))
        candidates.sort(key=lambda sc: sc.score, reverse=True)
        return candidates[:top_k]

    async def delete(
        self,
        *,
        ids: list[str] | None = None,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> int:
        deleted = 0
        namespaces = [namespace] if namespace else list(self._chunks.keys())
        for ns in namespaces:
            bucket = self._chunks.get(ns)
            if not bucket:
                continue
            to_drop: list[str] = []
            for cid, chunk in bucket.items():
                if ids is not None and cid not in ids:
                    continue
                if tags and not _tags_match(chunk.tags, tags):
                    continue
                to_drop.append(cid)
            for cid in to_drop:
                bucket.pop(cid, None)
                deleted += 1
        return deleted

    async def count(self, *, namespace: str | None = None) -> int:
        if namespace is not None:
            return len(self._chunks.get(namespace, {}))
        return sum(len(b) for b in self._chunks.values())


def _tags_match(chunk_tags: dict[str, str], filter_tags: dict[str, str]) -> bool:
    return all(chunk_tags.get(k) == v for k, v in filter_tags.items())
