"""SQLite-vec vector store — `pip install raggedy[sqlitevec]`.

Backed by a single `aiosqlite` connection per store. Loads the `sqlite-vec`
extension at first connect and uses a `vec0` virtual table for KNN.

`url` accepts:
    None / ""           → in-memory ":memory:"
    ":memory:"          → in-memory
    "sqlite:///path"    → file at /path
    "/abs/path.db"      → file
    "./relative.db"     → file
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

from raggedy.errors import ConfigError, ProviderError
from raggedy.types import Chunk, ScoredChunk


class SqliteVecStore:
    def __init__(self, url: str | None = None) -> None:
        self._path = self._parse_url(url)
        self._conn: Any = None
        self._lock = asyncio.Lock()
        self._dim: int | None = None

    @staticmethod
    def _parse_url(url: str | None) -> str:
        if not url:
            return ":memory:"
        if url == ":memory:":
            return url
        if url.startswith("sqlite:///"):
            return url[len("sqlite:///"):]
        if url.startswith("sqlite://"):
            return url[len("sqlite://"):]
        return url

    async def _get_conn(self) -> Any:
        if self._conn is not None:
            return self._conn
        try:
            import aiosqlite
            import sqlite_vec
        except ImportError as e:
            raise ConfigError(
                "sqlite-vec store requires extras. "
                "Install with: pip install 'raggedy[sqlitevec]'"
            ) from e
        try:
            conn = await aiosqlite.connect(self._path)
            await conn.enable_load_extension(True)
            # sqlite-vec ships a sync `load(connection)` helper that expects the
            # underlying sqlite3 connection. aiosqlite stores it as
            # `_connection`; fall back to loading by path for older versions.
            sync_conn = getattr(conn, "_connection", None)
            loaded = False
            if sync_conn is not None:
                try:
                    sqlite_vec.load(sync_conn)
                    loaded = True
                except Exception:
                    loaded = False
            if not loaded:
                await conn.load_extension(sqlite_vec.loadable_path())
            await conn.enable_load_extension(False)
        except ProviderError:
            raise
        except Exception as e:
            raise ConfigError(
                f"SqliteVecStore could not open {self._path!r}: {type(e).__name__}: {e}"
            ) from e
        self._conn = conn
        return conn

    async def _ensure_schema(self, dim: int) -> None:
        if self._dim is None:
            self._dim = dim
            conn = await self._get_conn()
            try:
                await conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS raggedy_chunks (
                        id TEXT PRIMARY KEY,
                        document_id TEXT NOT NULL,
                        namespace TEXT NOT NULL,
                        text TEXT NOT NULL,
                        chunk_index INTEGER NOT NULL,
                        start_char INTEGER, end_char INTEGER,
                        token_count INTEGER, overlap_tokens INTEGER,
                        start_page INTEGER, end_page INTEGER,
                        tags_json TEXT NOT NULL DEFAULT '{}',
                        metadata_json TEXT NOT NULL DEFAULT '{}'
                    )
                    """
                )
                await conn.execute(
                    "CREATE INDEX IF NOT EXISTS idx_raggedy_chunks_ns "
                    "ON raggedy_chunks(namespace)"
                )
                await conn.execute(
                    f"""
                    CREATE VIRTUAL TABLE IF NOT EXISTS raggedy_vec USING vec0(
                        chunk_id TEXT PRIMARY KEY,
                        embedding float[{dim}] distance_metric=cosine
                    )
                    """
                )
                await conn.commit()
            except Exception as e:
                raise ConfigError(
                    f"SqliteVecStore schema init failed: {type(e).__name__}: {e}"
                ) from e
        elif self._dim != dim:
            raise ProviderError(
                f"Embedding dimension mismatch: store dim={self._dim}, got {dim}",
                provider="sqlite-vec",
            )

    async def upsert(self, chunks: list[Chunk]) -> None:
        if not chunks:
            return
        for c in chunks:
            if c.embedding is None:
                raise ProviderError(
                    f"Chunk {c.id!r} has no embedding", provider="sqlite-vec"
                )
        dim = len(chunks[0].embedding or [])
        async with self._lock:
            await self._ensure_schema(dim)
            conn = await self._get_conn()
            try:
                await conn.executemany(
                    """
                    INSERT OR REPLACE INTO raggedy_chunks
                        (id, document_id, namespace, text, chunk_index,
                         start_char, end_char, token_count, overlap_tokens,
                         start_page, end_page, tags_json, metadata_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    [
                        (
                            c.id, c.document_id, c.namespace, c.text, c.chunk_index,
                            c.start_char, c.end_char, c.token_count, c.overlap_tokens,
                            c.start_page, c.end_page,
                            json.dumps(c.tags), json.dumps(c.metadata),
                        )
                        for c in chunks
                    ],
                )
                # vec0 does not support INSERT OR REPLACE. Delete-then-insert.
                await conn.executemany(
                    "DELETE FROM raggedy_vec WHERE chunk_id = ?",
                    [(c.id,) for c in chunks],
                )
                await conn.executemany(
                    "INSERT INTO raggedy_vec(chunk_id, embedding) VALUES (?, ?)",
                    [(c.id, json.dumps(c.embedding)) for c in chunks],
                )
                await conn.commit()
            except Exception as e:
                raise ProviderError(
                    f"SqliteVecStore upsert failed: {type(e).__name__}: {e}",
                    provider="sqlite-vec",
                ) from e

    async def query(
        self,
        vector: list[float],
        *,
        top_k: int,
        namespace: str,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> list[ScoredChunk]:
        if self._dim is None:
            return []
        if len(vector) != self._dim:
            raise ProviderError(
                f"Query vector dim {len(vector)} != store dim {self._dim}",
                provider="sqlite-vec",
            )
        # Over-fetch when tag-filtering since vec0 doesn't filter on JSON text.
        fetch = top_k * 4 if tags else top_k
        async with self._lock:
            conn = await self._get_conn()
            try:
                cur = await conn.execute(
                    """
                    SELECT v.chunk_id, v.distance,
                           c.document_id, c.namespace, c.text, c.chunk_index,
                           c.start_char, c.end_char, c.token_count, c.overlap_tokens,
                           c.start_page, c.end_page, c.tags_json, c.metadata_json
                    FROM raggedy_vec v
                    JOIN raggedy_chunks c ON c.id = v.chunk_id
                    WHERE v.embedding MATCH ? AND k = ? AND c.namespace = ?
                    ORDER BY v.distance
                    """,
                    (json.dumps(vector), fetch, namespace),
                )
                rows = await cur.fetchall()
            except Exception as e:
                raise ProviderError(
                    f"SqliteVecStore query failed: {type(e).__name__}: {e}",
                    provider="sqlite-vec",
                ) from e

        results: list[ScoredChunk] = []
        for row in rows:
            chunk_tags = _safe_json(row[12], default={})
            if tags and not _tags_match(chunk_tags, tags):
                continue
            score = 1.0 - float(row[1])
            if min_score is not None and score < min_score:
                continue
            chunk = Chunk(
                id=row[0],
                document_id=row[2],
                namespace=row[3],
                text=row[4],
                chunk_index=row[5],
                start_char=row[6],
                end_char=row[7],
                token_count=row[8],
                overlap_tokens=row[9],
                start_page=row[10],
                end_page=row[11],
                tags=chunk_tags,
                metadata=_safe_json(row[13], default={}),
                embedding=None,
            )
            results.append(ScoredChunk(chunk=chunk, score=score))
            if len(results) >= top_k:
                break
        return results

    async def delete(
        self,
        *,
        ids: list[str] | None = None,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> int:
        if self._dim is None:
            return 0
        async with self._lock:
            conn = await self._get_conn()
            try:
                where: list[str] = []
                params: list[Any] = []
                if ids is not None:
                    if not ids:
                        return 0
                    placeholders = ",".join("?" * len(ids))
                    where.append(f"id IN ({placeholders})")
                    params.extend(ids)
                if namespace is not None:
                    where.append("namespace = ?")
                    params.append(namespace)
                base_where = (" WHERE " + " AND ".join(where)) if where else ""
                cur = await conn.execute(
                    f"SELECT id, tags_json FROM raggedy_chunks{base_where}",
                    params,
                )
                candidates = await cur.fetchall()
                to_drop: list[str] = []
                for cid, tags_json in candidates:
                    if tags and not _tags_match(_safe_json(tags_json, {}), tags):
                        continue
                    to_drop.append(cid)
                if not to_drop:
                    return 0
                placeholders = ",".join("?" * len(to_drop))
                await conn.execute(
                    f"DELETE FROM raggedy_chunks WHERE id IN ({placeholders})", to_drop
                )
                await conn.execute(
                    f"DELETE FROM raggedy_vec WHERE chunk_id IN ({placeholders})", to_drop
                )
                await conn.commit()
                return len(to_drop)
            except Exception as e:
                raise ProviderError(
                    f"SqliteVecStore delete failed: {type(e).__name__}: {e}",
                    provider="sqlite-vec",
                ) from e

    async def count(self, *, namespace: str | None = None) -> int:
        if self._dim is None:
            return 0
        async with self._lock:
            conn = await self._get_conn()
            try:
                if namespace is None:
                    cur = await conn.execute("SELECT COUNT(*) FROM raggedy_chunks")
                else:
                    cur = await conn.execute(
                        "SELECT COUNT(*) FROM raggedy_chunks WHERE namespace = ?",
                        (namespace,),
                    )
                row = await cur.fetchone()
                return int(row[0]) if row else 0
            except Exception as e:
                raise ProviderError(
                    f"SqliteVecStore count failed: {type(e).__name__}: {e}",
                    provider="sqlite-vec",
                ) from e

    async def aclose(self) -> None:
        if self._conn is not None:
            try:
                await self._conn.close()
            finally:
                self._conn = None


def _safe_json(raw: str | None, default: Any) -> Any:
    if not raw:
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


def _tags_match(chunk_tags: dict[str, str], filter_tags: dict[str, str]) -> bool:
    return all(chunk_tags.get(k) == v for k, v in filter_tags.items())
