"""pgvector vector store — `pip install raggedy[pgvector]`.

Single Postgres table with a `vector(N)` column. Tags stored in JSONB,
filtered with the `@>` containment operator. Schema is created lazily on
the first `upsert` so the embedding dimension is known.

`url` is a standard `postgresql://...` DSN. Required — no default.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

from raggedy.errors import ConfigError, ProviderError
from raggedy.types import Chunk, ScoredChunk


class PgVectorStore:
    def __init__(
        self,
        url: str | None = None,
        *,
        table: str = "raggedy_chunks",
        min_pool_size: int = 1,
        max_pool_size: int = 5,
    ) -> None:
        if not url:
            raise ConfigError(
                "PgVectorStore requires a postgresql:// URL. "
                "Set RaggedyConfig.store_url or RAGGEDY_STORE_URL."
            )
        try:
            import asyncpg  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "pgvector store requires extras. "
                "Install with: pip install 'raggedy[pgvector]'"
            ) from e
        if not _safe_table_name(table):
            raise ConfigError(f"Invalid table name {table!r} (must match [A-Za-z0-9_]+).")
        self._dsn = url
        self._table = table
        self._min_pool = min_pool_size
        self._max_pool = max_pool_size
        self._pool: Any = None
        self._lock = asyncio.Lock()
        self._dim: int | None = None

    async def _get_pool(self) -> Any:
        if self._pool is not None:
            return self._pool
        import asyncpg

        try:
            self._pool = await asyncpg.create_pool(
                self._dsn,
                min_size=self._min_pool,
                max_size=self._max_pool,
            )
        except Exception as e:
            raise ConfigError(
                f"PgVectorStore could not connect to {_redact_dsn(self._dsn)!r}: "
                f"{type(e).__name__}: {e}"
            ) from e
        return self._pool

    async def _ensure_schema(self, dim: int) -> None:
        if self._dim is not None:
            if self._dim != dim:
                raise ProviderError(
                    f"Embedding dimension mismatch: store dim={self._dim}, got {dim}",
                    provider="pgvector",
                )
            return
        self._dim = dim
        pool = await self._get_pool()
        try:
            async with pool.acquire() as conn:
                await conn.execute("CREATE EXTENSION IF NOT EXISTS vector")
                await conn.execute(
                    f"""
                    CREATE TABLE IF NOT EXISTS {self._table} (
                        id TEXT PRIMARY KEY,
                        document_id TEXT NOT NULL,
                        namespace TEXT NOT NULL,
                        text TEXT NOT NULL,
                        chunk_index INTEGER NOT NULL,
                        start_char INTEGER, end_char INTEGER,
                        token_count INTEGER, overlap_tokens INTEGER,
                        start_page INTEGER, end_page INTEGER,
                        tags JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                        metadata JSONB NOT NULL DEFAULT '{{}}'::jsonb,
                        embedding vector({dim}) NOT NULL
                    )
                    """
                )
                await conn.execute(
                    f"CREATE INDEX IF NOT EXISTS idx_{self._table}_ns "
                    f"ON {self._table}(namespace)"
                )
                await conn.execute(
                    f"CREATE INDEX IF NOT EXISTS idx_{self._table}_tags "
                    f"ON {self._table} USING gin (tags)"
                )
        except Exception as e:
            raise ConfigError(
                f"PgVectorStore schema init failed: {type(e).__name__}: {e}"
            ) from e

    async def upsert(self, chunks: list[Chunk]) -> None:
        if not chunks:
            return
        for c in chunks:
            if c.embedding is None:
                raise ProviderError(
                    f"Chunk {c.id!r} has no embedding", provider="pgvector"
                )
        dim = len(chunks[0].embedding or [])
        async with self._lock:
            await self._ensure_schema(dim)
        pool = await self._get_pool()
        rows = [
            (
                c.id, c.document_id, c.namespace, c.text, c.chunk_index,
                c.start_char, c.end_char, c.token_count, c.overlap_tokens,
                c.start_page, c.end_page,
                json.dumps(c.tags), json.dumps(c.metadata),
                _vec_literal(c.embedding or []),
            )
            for c in chunks
        ]
        sql = f"""
            INSERT INTO {self._table}
                (id, document_id, namespace, text, chunk_index,
                 start_char, end_char, token_count, overlap_tokens,
                 start_page, end_page, tags, metadata, embedding)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11,
                    $12::jsonb, $13::jsonb, $14::vector)
            ON CONFLICT (id) DO UPDATE SET
                document_id = EXCLUDED.document_id,
                namespace = EXCLUDED.namespace,
                text = EXCLUDED.text,
                chunk_index = EXCLUDED.chunk_index,
                start_char = EXCLUDED.start_char,
                end_char = EXCLUDED.end_char,
                token_count = EXCLUDED.token_count,
                overlap_tokens = EXCLUDED.overlap_tokens,
                start_page = EXCLUDED.start_page,
                end_page = EXCLUDED.end_page,
                tags = EXCLUDED.tags,
                metadata = EXCLUDED.metadata,
                embedding = EXCLUDED.embedding
        """
        try:
            async with pool.acquire() as conn, conn.transaction():
                await conn.executemany(sql, rows)
        except Exception as e:
            raise ProviderError(
                f"PgVectorStore upsert failed: {type(e).__name__}: {e}",
                provider="pgvector",
            ) from e

    async def query(
        self,
        vector: list[float],
        *,
        top_k: int,
        namespace: str,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> list[ScoredChunk]:
        if self._dim is None:
            return []
        if len(vector) != self._dim:
            raise ProviderError(
                f"Query vector dim {len(vector)} != store dim {self._dim}",
                provider="pgvector",
            )
        params: list[Any] = [namespace]
        where = ["namespace = $1"]
        if tags:
            params.append(json.dumps(tags))
            where.append(f"tags @> ${len(params)}::jsonb")
        params.append(_vec_literal(vector))
        vec_idx = len(params)
        params.append(top_k)
        limit_idx = len(params)
        sql = f"""
            SELECT id, document_id, namespace, text, chunk_index,
                   start_char, end_char, token_count, overlap_tokens,
                   start_page, end_page, tags, metadata,
                   1 - (embedding <=> ${vec_idx}::vector) AS score
            FROM {self._table}
            WHERE {' AND '.join(where)}
            ORDER BY embedding <=> ${vec_idx}::vector
            LIMIT ${limit_idx}
        """
        pool = await self._get_pool()
        try:
            async with pool.acquire() as conn:
                rows = await conn.fetch(sql, *params)
        except Exception as e:
            raise ProviderError(
                f"PgVectorStore query failed: {type(e).__name__}: {e}",
                provider="pgvector",
            ) from e
        results: list[ScoredChunk] = []
        for r in rows:
            score = float(r["score"])
            if min_score is not None and score < min_score:
                continue
            chunk = Chunk(
                id=r["id"],
                document_id=r["document_id"],
                namespace=r["namespace"],
                text=r["text"],
                chunk_index=r["chunk_index"],
                start_char=r["start_char"],
                end_char=r["end_char"],
                token_count=r["token_count"],
                overlap_tokens=r["overlap_tokens"],
                start_page=r["start_page"],
                end_page=r["end_page"],
                tags=_safe_json(r["tags"], default={}),
                metadata=_safe_json(r["metadata"], default={}),
                embedding=None,
            )
            results.append(ScoredChunk(chunk=chunk, score=score))
        return results

    async def delete(
        self,
        *,
        ids: list[str] | None = None,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> int:
        if self._dim is None:
            return 0
        where: list[str] = []
        params: list[Any] = []
        if ids is not None:
            if not ids:
                return 0
            params.append(list(ids))
            where.append(f"id = ANY(${len(params)})")
        if namespace is not None:
            params.append(namespace)
            where.append(f"namespace = ${len(params)}")
        if tags:
            params.append(json.dumps(tags))
            where.append(f"tags @> ${len(params)}::jsonb")
        if not where:
            return 0
        sql = f"DELETE FROM {self._table} WHERE {' AND '.join(where)} RETURNING id"
        pool = await self._get_pool()
        try:
            async with pool.acquire() as conn:
                rows = await conn.fetch(sql, *params)
        except Exception as e:
            raise ProviderError(
                f"PgVectorStore delete failed: {type(e).__name__}: {e}",
                provider="pgvector",
            ) from e
        return len(rows)

    async def count(self, *, namespace: str | None = None) -> int:
        if self._dim is None:
            return 0
        pool = await self._get_pool()
        try:
            async with pool.acquire() as conn:
                if namespace is None:
                    val = await conn.fetchval(f"SELECT COUNT(*) FROM {self._table}")
                else:
                    val = await conn.fetchval(
                        f"SELECT COUNT(*) FROM {self._table} WHERE namespace = $1",
                        namespace,
                    )
        except Exception as e:
            raise ProviderError(
                f"PgVectorStore count failed: {type(e).__name__}: {e}",
                provider="pgvector",
            ) from e
        return int(val or 0)

    async def aclose(self) -> None:
        if self._pool is not None:
            try:
                await self._pool.close()
            finally:
                self._pool = None


def _vec_literal(vec: list[float]) -> str:
    # pgvector accepts the text form '[1.0,2.0,3.0]'::vector.
    return "[" + ",".join(repr(float(x)) for x in vec) + "]"


def _safe_json(raw: Any, default: Any) -> Any:
    if raw is None:
        return default
    if isinstance(raw, dict | list):
        return raw
    try:
        return json.loads(raw)
    except Exception:
        return default


def _safe_table_name(name: str) -> bool:
    if not name:
        return False
    return all(ch.isalnum() or ch == "_" for ch in name)


def _redact_dsn(dsn: str) -> str:
    # Hide the password portion of a postgres URL: postgresql://user:pwd@host/db
    if "://" not in dsn:
        return dsn
    scheme, rest = dsn.split("://", 1)
    if "@" not in rest:
        return dsn
    creds, host = rest.rsplit("@", 1)
    if ":" in creds:
        user, _ = creds.split(":", 1)
        return f"{scheme}://{user}:***@{host}"
    return dsn
