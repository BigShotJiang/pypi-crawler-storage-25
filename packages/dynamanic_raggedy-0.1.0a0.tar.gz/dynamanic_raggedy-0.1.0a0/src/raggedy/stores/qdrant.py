"""Qdrant vector store — `pip install raggedy[qdrant]`.

Single collection keyed by namespace + tags in payload. Vector ids are
UUIDv5 derived from the chunk id so arbitrary string ids work with
Qdrant's `id: int | uuid` requirement; the original chunk id is preserved
in the `chunk_id` payload field.

`url` accepts:
    None                     → http://localhost:6333
    ":memory:"               → in-process embedded server (great for tests)
    "http://host:6333"       → HTTP
    "https://host:6333"      → HTTPS (Qdrant Cloud)
    "/path/to/local/store"   → local file storage
"""

from __future__ import annotations

import asyncio
import contextlib
import uuid
from typing import Any

from raggedy.errors import ConfigError, ProviderError
from raggedy.types import Chunk, ScoredChunk

DEFAULT_URL = "http://localhost:6333"
DEFAULT_COLLECTION = "raggedy"
# Standard OID namespace UUID, used to derive a deterministic UUIDv5 for
# each chunk id (Qdrant point ids must be int or UUID).
_NAMESPACE_OID = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")


def _point_id(chunk_id: str) -> str:
    return str(uuid.uuid5(_NAMESPACE_OID, chunk_id))


class QdrantStore:
    def __init__(
        self,
        url: str | None = None,
        *,
        collection: str = DEFAULT_COLLECTION,
        api_key: str | None = None,
        prefer_grpc: bool = False,
        timeout: float | None = 30.0,
    ) -> None:
        try:
            from qdrant_client import AsyncQdrantClient  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "Qdrant store requires extras. "
                "Install with: pip install 'raggedy[qdrant]'"
            ) from e
        if not _safe_collection_name(collection):
            raise ConfigError(
                f"Invalid collection name {collection!r} (must match [A-Za-z0-9_-]+)."
            )
        self._url = url or DEFAULT_URL
        self._collection = collection
        self._api_key = api_key
        self._prefer_grpc = prefer_grpc
        self._timeout = timeout
        self._client: Any = None
        self._dim: int | None = None
        self._lock = asyncio.Lock()

    async def _get_client(self) -> Any:
        if self._client is not None:
            return self._client
        from qdrant_client import AsyncQdrantClient

        try:
            kwargs: dict[str, Any] = {}
            if self._api_key:
                kwargs["api_key"] = self._api_key
            if self._timeout is not None:
                kwargs["timeout"] = self._timeout
            # AsyncQdrantClient routes ":memory:" / file paths to the embedded
            # local engine and http(s):// URLs to the network transport.
            self._client = AsyncQdrantClient(
                location=self._url,
                prefer_grpc=self._prefer_grpc,
                **kwargs,
            )
        except Exception as e:
            raise ConfigError(
                f"QdrantStore could not connect to {self._url!r}: {type(e).__name__}: {e}"
            ) from e
        return self._client

    async def _ensure_collection(self, dim: int) -> None:
        if self._dim is not None:
            if self._dim != dim:
                raise ProviderError(
                    f"Embedding dimension mismatch: store dim={self._dim}, got {dim}",
                    provider="qdrant",
                )
            return
        client = await self._get_client()
        from qdrant_client.http import models as qm

        try:
            exists = await client.collection_exists(self._collection)
            if exists:
                info = await client.get_collection(self._collection)
                # vectors_config may be VectorParams or {name: VectorParams}.
                params = info.config.params.vectors
                existing_dim = (
                    params.size if hasattr(params, "size") else next(iter(params.values())).size
                )
                if existing_dim != dim:
                    raise ProviderError(
                        f"Existing Qdrant collection {self._collection!r} has dim "
                        f"{existing_dim}, but inputs have dim {dim}.",
                        provider="qdrant",
                    )
                self._dim = dim
                return
            await client.create_collection(
                collection_name=self._collection,
                vectors_config=qm.VectorParams(size=dim, distance=qm.Distance.COSINE),
            )
            # Index the namespace field so retrieval-side filters are fast.
            # Skipped for local/embedded mode (payload indexes are a no-op
            # there and the client emits a UserWarning).
            if not self._is_local_mode():
                # Index creation is best-effort; queries still work without it.
                with contextlib.suppress(Exception):
                    await client.create_payload_index(
                        collection_name=self._collection,
                        field_name="namespace",
                        field_schema=qm.PayloadSchemaType.KEYWORD,
                    )
            self._dim = dim
        except ProviderError:
            raise
        except Exception as e:
            raise ConfigError(
                f"QdrantStore schema init failed: {type(e).__name__}: {e}"
            ) from e

    async def upsert(self, chunks: list[Chunk]) -> None:
        if not chunks:
            return
        for c in chunks:
            if c.embedding is None:
                raise ProviderError(
                    f"Chunk {c.id!r} has no embedding", provider="qdrant"
                )
        dim = len(chunks[0].embedding or [])
        async with self._lock:
            await self._ensure_collection(dim)
        client = await self._get_client()
        from qdrant_client.http import models as qm

        points = [
            qm.PointStruct(
                id=_point_id(c.id),
                vector=list(c.embedding or []),
                payload={
                    "chunk_id": c.id,
                    "document_id": c.document_id,
                    "namespace": c.namespace,
                    "text": c.text,
                    "chunk_index": c.chunk_index,
                    "start_char": c.start_char,
                    "end_char": c.end_char,
                    "token_count": c.token_count,
                    "overlap_tokens": c.overlap_tokens,
                    "start_page": c.start_page,
                    "end_page": c.end_page,
                    "tags": dict(c.tags),
                    "metadata": dict(c.metadata),
                },
            )
            for c in chunks
        ]
        try:
            await client.upsert(collection_name=self._collection, points=points, wait=True)
        except Exception as e:
            raise ProviderError(
                f"QdrantStore upsert failed: {type(e).__name__}: {e}",
                provider="qdrant",
            ) from e

    async def query(
        self,
        vector: list[float],
        *,
        top_k: int,
        namespace: str,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> list[ScoredChunk]:
        if self._dim is None:
            return []
        if len(vector) != self._dim:
            raise ProviderError(
                f"Query vector dim {len(vector)} != store dim {self._dim}",
                provider="qdrant",
            )
        client = await self._get_client()
        from qdrant_client.http import models as qm

        must: list[Any] = [
            qm.FieldCondition(key="namespace", match=qm.MatchValue(value=namespace))
        ]
        if tags:
            for k, v in tags.items():
                must.append(
                    qm.FieldCondition(key=f"tags.{k}", match=qm.MatchValue(value=v))
                )
        flt = qm.Filter(must=must)
        try:
            response = await client.query_points(
                collection_name=self._collection,
                query=list(vector),
                limit=top_k,
                query_filter=flt,
                score_threshold=min_score,
                with_payload=True,
            )
        except Exception as e:
            raise ProviderError(
                f"QdrantStore query failed: {type(e).__name__}: {e}",
                provider="qdrant",
            ) from e
        results: list[ScoredChunk] = []
        for point in response.points:
            payload = point.payload or {}
            chunk = Chunk(
                id=str(payload.get("chunk_id") or point.id),
                document_id=str(payload.get("document_id", "")),
                namespace=str(payload.get("namespace", "")),
                text=str(payload.get("text", "")),
                chunk_index=int(payload.get("chunk_index", 0) or 0),
                start_char=int(payload.get("start_char", 0) or 0),
                end_char=int(payload.get("end_char", 0) or 0),
                token_count=int(payload.get("token_count", 0) or 0),
                overlap_tokens=int(payload.get("overlap_tokens", 0) or 0),
                start_page=payload.get("start_page"),
                end_page=payload.get("end_page"),
                tags=dict(payload.get("tags") or {}),
                metadata=dict(payload.get("metadata") or {}),
                embedding=None,
            )
            results.append(ScoredChunk(chunk=chunk, score=float(point.score)))
        return results

    async def delete(
        self,
        *,
        ids: list[str] | None = None,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> int:
        if self._dim is None:
            return 0
        if ids is not None and not ids:
            return 0
        client = await self._get_client()
        from qdrant_client.http import models as qm

        must: list[Any] = []
        if ids is not None:
            must.append(qm.FieldCondition(key="chunk_id", match=qm.MatchAny(any=list(ids))))
        if namespace is not None:
            must.append(
                qm.FieldCondition(key="namespace", match=qm.MatchValue(value=namespace))
            )
        if tags:
            for k, v in tags.items():
                must.append(
                    qm.FieldCondition(key=f"tags.{k}", match=qm.MatchValue(value=v))
                )
        if not must:
            return 0
        flt = qm.Filter(must=must)
        try:
            count_before = await client.count(
                collection_name=self._collection, count_filter=flt
            )
            await client.delete(
                collection_name=self._collection,
                points_selector=qm.FilterSelector(filter=flt),
                wait=True,
            )
        except Exception as e:
            raise ProviderError(
                f"QdrantStore delete failed: {type(e).__name__}: {e}",
                provider="qdrant",
            ) from e
        return int(count_before.count)

    async def count(self, *, namespace: str | None = None) -> int:
        if self._dim is None:
            return 0
        client = await self._get_client()
        from qdrant_client.http import models as qm

        flt = None
        if namespace is not None:
            flt = qm.Filter(
                must=[
                    qm.FieldCondition(
                        key="namespace", match=qm.MatchValue(value=namespace)
                    )
                ]
            )
        try:
            result = await client.count(
                collection_name=self._collection, count_filter=flt
            )
        except Exception as e:
            raise ProviderError(
                f"QdrantStore count failed: {type(e).__name__}: {e}",
                provider="qdrant",
            ) from e
        return int(result.count)

    async def aclose(self) -> None:
        if self._client is not None:
            try:
                await self._client.close()
            finally:
                self._client = None

    def _is_local_mode(self) -> bool:
        # AsyncQdrantClient runs locally for ":memory:" or filesystem paths.
        if self._url == ":memory:":
            return True
        return not (self._url.startswith("http://") or self._url.startswith("https://"))


def _safe_collection_name(name: str) -> bool:
    if not name:
        return False
    return all(ch.isalnum() or ch in ("_", "-") for ch in name)
