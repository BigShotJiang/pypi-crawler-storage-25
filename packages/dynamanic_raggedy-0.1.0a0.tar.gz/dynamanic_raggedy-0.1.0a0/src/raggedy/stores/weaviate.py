"""Weaviate vector store — `pip install raggedy[weaviate]`.

Uses the v4 async client. Single collection (`Raggedy` by default), with
Raggedy chunk fields stored as top-level properties; `tags` is flattened
into individual `tag_<key>` properties so the filter API can compare them.

`url` accepts:
    "http://host:8080"     → custom HTTP host (sets `grpc_port=50051`)
    "https://host"         → Weaviate Cloud (api_key required via api_key=)
    None                   → http://localhost:8080 (sensible default)
"""

from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any
from urllib.parse import urlparse

from raggedy.errors import ConfigError, ProviderError
from raggedy.types import Chunk, ScoredChunk

DEFAULT_COLLECTION = "Raggedy"
_NAMESPACE_OID = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")
_TAG_PREFIX = "tag_"


def _point_uuid(chunk_id: str) -> str:
    return str(uuid.uuid5(_NAMESPACE_OID, chunk_id))


class WeaviateStore:
    def __init__(
        self,
        url: str | None = None,
        *,
        collection: str = DEFAULT_COLLECTION,
        api_key: str | None = None,
        grpc_port: int = 50051,
    ) -> None:
        try:
            import weaviate  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "Weaviate store requires extras. "
                "Install with: pip install 'raggedy[weaviate]'"
            ) from e
        if not _safe_collection_name(collection):
            raise ConfigError(
                f"Invalid collection name {collection!r} "
                f"(must start with an uppercase letter and contain [A-Za-z0-9_]+)."
            )
        self._url = url or "http://localhost:8080"
        self._collection_name = collection
        self._api_key = api_key
        self._grpc_port = grpc_port
        self._client: Any = None
        self._dim: int | None = None
        self._lock = asyncio.Lock()

    async def _get_client(self) -> Any:
        if self._client is not None:
            return self._client
        import weaviate
        from weaviate.classes.init import Auth

        parsed = urlparse(self._url)
        host = parsed.hostname or "localhost"
        port = parsed.port or (443 if parsed.scheme == "https" else 8080)
        secure = parsed.scheme == "https"
        try:
            if secure and self._api_key:
                client = weaviate.use_async_with_weaviate_cloud(
                    cluster_url=self._url,
                    auth_credentials=Auth.api_key(self._api_key),
                )
            else:
                client = weaviate.use_async_with_custom(
                    http_host=host,
                    http_port=port,
                    http_secure=secure,
                    grpc_host=host,
                    grpc_port=self._grpc_port,
                    grpc_secure=secure,
                    auth_credentials=(
                        Auth.api_key(self._api_key) if self._api_key else None
                    ),
                )
            await client.connect()
        except Exception as e:
            raise ConfigError(
                f"WeaviateStore could not connect to {self._url!r}: "
                f"{type(e).__name__}: {e}"
            ) from e
        self._client = client
        return client

    async def _ensure_collection(self, dim: int) -> None:
        if self._dim is not None:
            if self._dim != dim:
                raise ProviderError(
                    f"Embedding dimension mismatch: store dim={self._dim}, got {dim}",
                    provider="weaviate",
                )
            return
        client = await self._get_client()
        from weaviate.classes.config import Configure, DataType, Property, VectorDistances

        try:
            exists = await client.collections.exists(self._collection_name)
            if not exists:
                await client.collections.create(
                    name=self._collection_name,
                    properties=[
                        Property(name="chunk_id", data_type=DataType.TEXT),
                        Property(name="document_id", data_type=DataType.TEXT),
                        Property(name="namespace", data_type=DataType.TEXT),
                        Property(name="text", data_type=DataType.TEXT),
                        Property(name="chunk_index", data_type=DataType.INT),
                        Property(name="start_char", data_type=DataType.INT),
                        Property(name="end_char", data_type=DataType.INT),
                        Property(name="token_count", data_type=DataType.INT),
                        Property(name="overlap_tokens", data_type=DataType.INT),
                        Property(name="start_page", data_type=DataType.INT),
                        Property(name="end_page", data_type=DataType.INT),
                        Property(name="tags_json", data_type=DataType.TEXT),
                        Property(name="metadata_json", data_type=DataType.TEXT),
                    ],
                    vectorizer_config=Configure.Vectorizer.none(),
                    vector_index_config=Configure.VectorIndex.hnsw(
                        distance_metric=VectorDistances.COSINE
                    ),
                )
            self._dim = dim
        except ProviderError:
            raise
        except Exception as e:
            raise ConfigError(
                f"WeaviateStore schema init failed: {type(e).__name__}: {e}"
            ) from e

    async def upsert(self, chunks: list[Chunk]) -> None:
        if not chunks:
            return
        for c in chunks:
            if c.embedding is None:
                raise ProviderError(
                    f"Chunk {c.id!r} has no embedding", provider="weaviate"
                )
        dim = len(chunks[0].embedding or [])
        async with self._lock:
            await self._ensure_collection(dim)
        client = await self._get_client()
        coll = client.collections.get(self._collection_name)
        try:
            for c in chunks:
                props = _chunk_to_properties(c)
                point_id = _point_uuid(c.id)
                exists = await coll.data.exists(point_id)
                if exists:
                    await coll.data.replace(
                        uuid=point_id,
                        properties=props,
                        vector=list(c.embedding or []),
                    )
                else:
                    await coll.data.insert(
                        uuid=point_id,
                        properties=props,
                        vector=list(c.embedding or []),
                    )
        except Exception as e:
            raise ProviderError(
                f"WeaviateStore upsert failed: {type(e).__name__}: {e}",
                provider="weaviate",
            ) from e

    async def query(
        self,
        vector: list[float],
        *,
        top_k: int,
        namespace: str,
        tags: dict[str, str] | None = None,
        min_score: float | None = None,
    ) -> list[ScoredChunk]:
        if self._dim is None:
            return []
        if len(vector) != self._dim:
            raise ProviderError(
                f"Query vector dim {len(vector)} != store dim {self._dim}",
                provider="weaviate",
            )
        client = await self._get_client()
        from weaviate.classes.query import Filter, MetadataQuery

        coll = client.collections.get(self._collection_name)
        flt = Filter.by_property("namespace").equal(namespace)
        if tags:
            for k, v in tags.items():
                flt = flt & Filter.by_property(f"{_TAG_PREFIX}{k}").equal(v)
        try:
            response = await coll.query.near_vector(
                near_vector=list(vector),
                limit=top_k,
                filters=flt,
                return_metadata=MetadataQuery(distance=True),
            )
        except Exception as e:
            raise ProviderError(
                f"WeaviateStore query failed: {type(e).__name__}: {e}",
                provider="weaviate",
            ) from e
        results: list[ScoredChunk] = []
        for obj in response.objects:
            distance = float(obj.metadata.distance or 0.0)
            score = 1.0 - distance
            if min_score is not None and score < min_score:
                continue
            results.append(
                ScoredChunk(
                    chunk=_properties_to_chunk(obj.properties or {}),
                    score=score,
                )
            )
        return results

    async def delete(
        self,
        *,
        ids: list[str] | None = None,
        namespace: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> int:
        if self._dim is None:
            return 0
        if ids is not None and not ids:
            return 0
        client = await self._get_client()
        from weaviate.classes.query import Filter

        coll = client.collections.get(self._collection_name)
        flt = None
        if ids is not None:
            flt = Filter.by_property("chunk_id").contains_any(list(ids))
        if namespace is not None:
            ns_flt = Filter.by_property("namespace").equal(namespace)
            flt = ns_flt if flt is None else flt & ns_flt
        if tags:
            for k, v in tags.items():
                tag_flt = Filter.by_property(f"{_TAG_PREFIX}{k}").equal(v)
                flt = tag_flt if flt is None else flt & tag_flt
        if flt is None:
            return 0
        try:
            result = await coll.data.delete_many(where=flt)
        except Exception as e:
            raise ProviderError(
                f"WeaviateStore delete failed: {type(e).__name__}: {e}",
                provider="weaviate",
            ) from e
        return int(getattr(result, "successful", 0) or 0)

    async def count(self, *, namespace: str | None = None) -> int:
        if self._dim is None:
            return 0
        client = await self._get_client()
        coll = client.collections.get(self._collection_name)
        try:
            if namespace is None:
                result = await coll.aggregate.over_all(total_count=True)
            else:
                from weaviate.classes.query import Filter

                result = await coll.aggregate.over_all(
                    total_count=True,
                    filters=Filter.by_property("namespace").equal(namespace),
                )
        except Exception as e:
            raise ProviderError(
                f"WeaviateStore count failed: {type(e).__name__}: {e}",
                provider="weaviate",
            ) from e
        return int(result.total_count or 0)

    async def aclose(self) -> None:
        if self._client is not None:
            try:
                await self._client.close()
            finally:
                self._client = None


def _chunk_to_properties(c: Chunk) -> dict[str, Any]:
    props: dict[str, Any] = {
        "chunk_id": c.id,
        "document_id": c.document_id,
        "namespace": c.namespace,
        "text": c.text,
        "chunk_index": c.chunk_index,
        "start_char": c.start_char,
        "end_char": c.end_char,
        "token_count": c.token_count,
        "overlap_tokens": c.overlap_tokens,
        "tags_json": json.dumps(c.tags),
        "metadata_json": json.dumps(c.metadata),
    }
    if c.start_page is not None:
        props["start_page"] = c.start_page
    if c.end_page is not None:
        props["end_page"] = c.end_page
    # Flatten string tags into top-level props so the Filter API can match them.
    for k, v in c.tags.items():
        if isinstance(v, str):
            props[f"{_TAG_PREFIX}{k}"] = v
    return props


def _properties_to_chunk(props: dict[str, Any]) -> Chunk:
    try:
        tags = json.loads(props.get("tags_json") or "{}")
    except Exception:
        tags = {}
    try:
        metadata = json.loads(props.get("metadata_json") or "{}")
    except Exception:
        metadata = {}
    return Chunk(
        id=str(props.get("chunk_id", "")),
        document_id=str(props.get("document_id", "")),
        namespace=str(props.get("namespace", "")),
        text=str(props.get("text", "")),
        chunk_index=int(props.get("chunk_index", 0) or 0),
        start_char=int(props.get("start_char", 0) or 0),
        end_char=int(props.get("end_char", 0) or 0),
        token_count=int(props.get("token_count", 0) or 0),
        overlap_tokens=int(props.get("overlap_tokens", 0) or 0),
        start_page=props.get("start_page"),
        end_page=props.get("end_page"),
        tags=tags,
        metadata=metadata,
        embedding=None,
    )


def _safe_collection_name(name: str) -> bool:
    # Weaviate v4 requires PascalCase-ish names — start uppercase, then
    # alphanumerics and underscores.
    if not name or not name[0].isupper():
        return False
    return all(ch.isalnum() or ch == "_" for ch in name)
