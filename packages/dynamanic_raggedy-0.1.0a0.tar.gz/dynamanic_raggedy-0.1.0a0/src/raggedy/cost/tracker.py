"""In-process cost trackers.

`InMemoryCostTracker` keeps a per-namespace daily total in a dict and
enforces `daily_limit_usd` synchronously. Persistence-backed trackers
(`SQLiteCostTracker`) live alongside under separate modules.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from datetime import date

from raggedy.errors import CostLimitExceeded


class InMemoryCostTracker:
    def __init__(self, daily_limit_usd: float | None = None) -> None:
        self._daily_limit = daily_limit_usd
        self._totals: dict[tuple[str, date], float] = defaultdict(float)
        self._tokens: dict[tuple[str, date], tuple[int, int]] = defaultdict(lambda: (0, 0))
        self._lock = asyncio.Lock()

    async def check_limit(self, *, namespace: str, projected_cost_usd: float) -> None:
        if self._daily_limit is None:
            return
        async with self._lock:
            today = date.today()
            current = self._totals[(namespace, today)]
            if current + projected_cost_usd > self._daily_limit:
                raise CostLimitExceeded(
                    f"Daily cost limit ${self._daily_limit:.4f} would be exceeded "
                    f"in namespace {namespace!r} (current ${current:.4f} + "
                    f"projected ${projected_cost_usd:.4f}).",
                    namespace=namespace,
                    projected_cost_usd=projected_cost_usd,
                    limit_usd=self._daily_limit,
                )

    async def record_usage(
        self,
        *,
        namespace: str,
        model: str,
        cost_usd: float,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> None:
        async with self._lock:
            key = (namespace, date.today())
            self._totals[key] += cost_usd
            pt, ct = self._tokens[key]
            self._tokens[key] = (pt + prompt_tokens, ct + completion_tokens)

    async def get_daily_cost(self, *, namespace: str) -> float:
        return self._totals.get((namespace, date.today()), 0.0)


class NoOpCostTracker:
    async def check_limit(self, *, namespace: str, projected_cost_usd: float) -> None:
        return None

    async def record_usage(
        self,
        *,
        namespace: str,
        model: str,
        cost_usd: float,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> None:
        return None

    async def get_daily_cost(self, *, namespace: str) -> float:
        return 0.0
