"""SQLite-backed `CostTracker` — `pip install raggedy[sqlitevec]`.

Single table, `(namespace, date_utc, model)` PK. `record_usage` performs
an atomic `INSERT ... ON CONFLICT DO UPDATE SET cost_usd = cost_usd +
excluded.cost_usd` so concurrent writes are serialized by SQLite without
the application holding a lock across the round-trip.

`url` accepts a path or `sqlite:///path` URL; defaults to `./raggedy_cost.db`.
The `[sqlitevec]` extra is reused because it already pulls in `aiosqlite`.
"""

from __future__ import annotations

from datetime import UTC, date, datetime
from typing import Any

from raggedy.errors import ConfigError, CostLimitExceeded


class SqliteCostTracker:
    def __init__(
        self,
        url: str | None = None,
        *,
        daily_limit_usd: float | None = None,
    ) -> None:
        try:
            import aiosqlite  # noqa: F401
        except ImportError as e:
            raise ConfigError(
                "SqliteCostTracker requires aiosqlite. "
                "Install with: pip install 'raggedy[sqlitevec]'"
            ) from e
        self._path = _parse_url(url) or "./raggedy_cost.db"
        self._daily_limit = daily_limit_usd
        self._conn: Any = None
        self._initialized = False

    async def _get_conn(self) -> Any:
        if self._conn is not None:
            return self._conn
        import aiosqlite

        try:
            self._conn = await aiosqlite.connect(self._path)
        except Exception as e:
            raise ConfigError(
                f"SqliteCostTracker could not open {self._path!r}: "
                f"{type(e).__name__}: {e}"
            ) from e
        if not self._initialized:
            try:
                await self._conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS raggedy_cost_daily (
                        namespace TEXT NOT NULL,
                        date_utc TEXT NOT NULL,
                        model TEXT NOT NULL,
                        cost_usd REAL NOT NULL DEFAULT 0,
                        prompt_tokens INTEGER NOT NULL DEFAULT 0,
                        completion_tokens INTEGER NOT NULL DEFAULT 0,
                        runs_count INTEGER NOT NULL DEFAULT 0,
                        PRIMARY KEY (namespace, date_utc, model)
                    )
                    """
                )
                await self._conn.commit()
                self._initialized = True
            except Exception as e:
                raise ConfigError(
                    f"SqliteCostTracker schema init failed: {type(e).__name__}: {e}"
                ) from e
        return self._conn

    async def check_limit(self, *, namespace: str, projected_cost_usd: float) -> None:
        if self._daily_limit is None:
            return
        current = await self.get_daily_cost(namespace=namespace)
        if current + projected_cost_usd > self._daily_limit:
            raise CostLimitExceeded(
                f"Daily cost limit ${self._daily_limit:.4f} would be exceeded "
                f"in namespace {namespace!r} (current ${current:.4f} + "
                f"projected ${projected_cost_usd:.4f}).",
                namespace=namespace,
                projected_cost_usd=projected_cost_usd,
                limit_usd=self._daily_limit,
            )

    async def record_usage(
        self,
        *,
        namespace: str,
        model: str,
        cost_usd: float,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> None:
        conn = await self._get_conn()
        today = _today_utc()
        try:
            await conn.execute(
                """
                INSERT INTO raggedy_cost_daily
                    (namespace, date_utc, model, cost_usd,
                     prompt_tokens, completion_tokens, runs_count)
                VALUES (?, ?, ?, ?, ?, ?, 1)
                ON CONFLICT(namespace, date_utc, model) DO UPDATE SET
                    cost_usd = cost_usd + excluded.cost_usd,
                    prompt_tokens = prompt_tokens + excluded.prompt_tokens,
                    completion_tokens = completion_tokens + excluded.completion_tokens,
                    runs_count = runs_count + 1
                """,
                (namespace, today, model, cost_usd, prompt_tokens, completion_tokens),
            )
            await conn.commit()
        except Exception as e:
            raise ConfigError(
                f"SqliteCostTracker record_usage failed: {type(e).__name__}: {e}"
            ) from e

    async def get_daily_cost(self, *, namespace: str) -> float:
        conn = await self._get_conn()
        try:
            cur = await conn.execute(
                "SELECT COALESCE(SUM(cost_usd), 0.0) FROM raggedy_cost_daily "
                "WHERE namespace = ? AND date_utc = ?",
                (namespace, _today_utc()),
            )
            row = await cur.fetchone()
            return float(row[0]) if row else 0.0
        except Exception as e:
            raise ConfigError(
                f"SqliteCostTracker get_daily_cost failed: {type(e).__name__}: {e}"
            ) from e

    async def aclose(self) -> None:
        if self._conn is not None:
            try:
                await self._conn.close()
            finally:
                self._conn = None


def _parse_url(url: str | None) -> str | None:
    if not url:
        return None
    if url.startswith("sqlite:///"):
        return url[len("sqlite:///"):]
    if url.startswith("sqlite://"):
        return url[len("sqlite://"):]
    return url


def _today_utc() -> str:
    return datetime.now(UTC).date().isoformat()


def _date_to_str(d: date) -> str:
    return d.isoformat()
