"""Per-model pricing.

USD per 1000 tokens. Public providers maintain their own copies that
override these values; this table seeds the registry and serves as the
last-resort fallback. Pricing drifts — bump in step with provider
announcements.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True, frozen=True)
class ModelPrice:
    input_per_ktok: float
    output_per_ktok: float


MODEL_PRICING: dict[str, ModelPrice] = {
    # Anthropic — captured Jan 2026; refresh as needed
    "claude-3-5-haiku-latest": ModelPrice(0.0008, 0.004),
    "claude-3-5-sonnet-latest": ModelPrice(0.003, 0.015),
    "claude-3-opus-latest": ModelPrice(0.015, 0.075),
    "claude-haiku-4-5-20251001": ModelPrice(0.0008, 0.004),
    "claude-sonnet-4-6": ModelPrice(0.003, 0.015),
    "claude-opus-4-7": ModelPrice(0.015, 0.075),
    # OpenAI
    "gpt-4o-mini": ModelPrice(0.00015, 0.0006),
    "gpt-4o": ModelPrice(0.0025, 0.01),
    # Local / OpenAI-compatible servers (Ollama, LM Studio) — free
}


def get_price(model: str) -> ModelPrice:
    return MODEL_PRICING.get(model, ModelPrice(0.0, 0.0))
