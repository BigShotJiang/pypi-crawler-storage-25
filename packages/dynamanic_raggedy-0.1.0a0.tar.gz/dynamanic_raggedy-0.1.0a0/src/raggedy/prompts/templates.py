"""Versioned RAG prompt templates.

Each version is a pinned `{system, user}` pair. The active version
travels in the `RunRecord` for reproducibility — never mutate a
released template in place.
"""

from __future__ import annotations

from raggedy.errors import ConfigError

RAG_V1_SYSTEM = """You are a retrieval-augmented assistant.
Answer questions based ONLY on the provided source excerpts.
Cite your sources using [Source N] format where N is the source number.
If the excerpts do not contain enough information to answer, say so plainly."""

RAG_V1_USER = """Answer the question using only the source excerpts below.

SOURCES:
{context}

QUESTION: {query}

INSTRUCTIONS:
1. Answer using only the provided source excerpts.
2. Cite sources using [Source N] references (e.g., [Source 1], [Source 2]).
3. If the excerpts do not contain enough information, say so plainly.
4. If excerpts conflict, note the discrepancy.

ANSWER:"""


RAG_PROMPT_TEMPLATES: dict[str, dict[str, str]] = {
    "rag-v1": {"system": RAG_V1_SYSTEM, "user": RAG_V1_USER},
}


def get_template(version: str) -> dict[str, str]:
    try:
        return RAG_PROMPT_TEMPLATES[version]
    except KeyError as e:
        known = ", ".join(sorted(RAG_PROMPT_TEMPLATES))
        raise ConfigError(
            f"Unknown prompt_template_version {version!r}. Known: {known}"
        ) from e
