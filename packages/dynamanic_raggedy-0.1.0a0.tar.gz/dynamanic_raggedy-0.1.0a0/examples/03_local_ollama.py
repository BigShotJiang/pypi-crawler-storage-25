"""Fully-local Ollama RAG example.

Runs everything on your machine: sentence-transformers embeddings (GPU-aware),
Ollama for generation, in-memory vector store, in-memory recorder.

Requires:
    pip install 'raggedy[local,ollama]'   # ollama uses base httpx; local adds torch
    ollama pull llama3.2                  # or any model you like
"""

from __future__ import annotations

import os

from raggedy import Document, Raggedy, RaggedyConfig


def main() -> None:
    rag = Raggedy(
        RaggedyConfig(
            llm="ollama",
            llm_model=os.getenv("OLLAMA_MODEL", "llama3.2"),
            embedding="sentence-transformers",
            embedding_model="sentence-transformers/all-MiniLM-L6-v2",
            device="auto",  # CUDA → MPS → CPU
            store="memory",
            namespace="local-ollama",
        )
    )

    rag.ingest_sync(
        [
            Document(
                id="bio-1",
                text=(
                    "The mitochondrion is a double membrane-bound organelle found in "
                    "most eukaryotic cells. It generates most of the cell's supply of ATP."
                ),
            ),
            Document(
                id="bio-2",
                text=(
                    "Photosynthesis is the process used by plants to convert light energy "
                    "into chemical energy stored as glucose."
                ),
            ),
        ]
    )

    result = rag.query_sync("What is the role of the mitochondrion?")
    print(f"Device  : {getattr(rag.embedder, 'device', 'n/a')}")
    print(f"Provider: {result.provider}/{result.model}")
    print(f"Answer  : {result.answer}\n")
    for s in result.sources:
        print(f"  [Source {s.index}] {s.document_id} score={s.score:.3f}")


if __name__ == "__main__":
    main()
