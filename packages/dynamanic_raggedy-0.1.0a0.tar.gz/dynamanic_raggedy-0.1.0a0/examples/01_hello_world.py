"""Hello-world Raggedy example.

Picks the first reachable real LLM provider (Anthropic / OpenAI / Ollama /
LM Studio) and runs an end-to-end RAG query. Embeddings stay offline via
the deterministic embedder; vector store is in-memory.

Provider resolution:
    ANTHROPIC_API_KEY → anthropic     (set via .env or env var)
    OPENAI_API_KEY    → openai
    OLLAMA running    → ollama
    LM STUDIO running → lm_studio
"""

from __future__ import annotations

import os
import sys

import httpx

from raggedy import Document, Raggedy, RaggedyConfig


def pick_llm() -> tuple[str, str]:
    if os.getenv("ANTHROPIC_API_KEY"):
        return "anthropic", "claude-haiku-4-5-20251001"
    if os.getenv("OPENAI_API_KEY"):
        return "openai", "gpt-4o-mini"
    if _reachable(os.getenv("OLLAMA_HOST", "http://localhost:11434") + "/api/tags"):
        return "ollama", os.getenv("OLLAMA_MODEL", "llama3.2")
    base = os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
    if _reachable(base + "/models"):
        return "lm_studio", os.getenv("LMSTUDIO_MODEL", "local-model")
    print(
        "No LLM provider reachable.\n"
        "  - put ANTHROPIC_API_KEY or OPENAI_API_KEY in .env, or\n"
        "  - start Ollama (http://localhost:11434), or\n"
        "  - start LM Studio (http://localhost:1234)\n",
        file=sys.stderr,
    )
    sys.exit(1)


def _reachable(url: str) -> bool:
    try:
        return httpx.get(url, timeout=1.0).status_code < 500
    except Exception:
        return False


def main() -> None:
    llm, llm_model = pick_llm()
    print(f"Using LLM: {llm} ({llm_model})")
    rag = Raggedy(
        RaggedyConfig(
            llm=llm,
            llm_model=llm_model,
            embedding="deterministic",
            store="memory",
            namespace="kb-handbook",
        )
    )

    rag.ingest_sync(
        [
            Document(
                id="hb-1",
                text=(
                    "Refunds are processed within 5 business days after approval.\n\n"
                    "Customers receive an email confirmation when a refund is issued."
                ),
                tags={"section": "policy"},
            ),
            Document(
                id="hb-2",
                text=(
                    "Shipping typically takes 3-7 business days within the continental US.\n\n"
                    "International shipping can take up to 14 business days."
                ),
                tags={"section": "shipping"},
            ),
        ]
    )

    result = rag.query_sync("How long do refunds take?", top_k=4)

    print()
    print("Answer:")
    print(f"  {result.answer}")
    print()
    print("Sources:")
    for s in result.sources:
        print(
            f"  [Source {s.index}] document={s.document_id} chunk={s.chunk_id} "
            f"score={s.score:.3f}"
        )
    print()
    print(
        f"cost=${result.cost_usd:.6f}  "
        f"tokens_in={result.prompt_tokens} tokens_out={result.completion_tokens}  "
        f"run_id={result.run_id}"
    )


if __name__ == "__main__":
    main()
