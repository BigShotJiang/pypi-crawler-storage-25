"""pgvector store + Anthropic LLM example.

Requires:
    pip install 'raggedy[pgvector,anthropic]'
    docker run --rm -d -p 5432:5432 -e POSTGRES_PASSWORD=pg ankane/pgvector

Env:
    ANTHROPIC_API_KEY   (set via .env)
    RAGGEDY_STORE_URL   defaults to postgresql://postgres:pg@localhost/postgres
"""

from __future__ import annotations

import os
import sys

from raggedy import Document, Raggedy, RaggedyConfig

DEFAULT_DSN = "postgresql://postgres:pg@localhost:5432/postgres"


def main() -> None:
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("ANTHROPIC_API_KEY not set (put it in .env). Aborting.", file=sys.stderr)
        sys.exit(1)
    dsn = os.getenv("RAGGEDY_STORE_URL", DEFAULT_DSN)

    rag = Raggedy(
        RaggedyConfig(
            llm="anthropic",
            llm_model="claude-haiku-4-5-20251001",
            embedding="deterministic",  # swap to "sentence-transformers" with [local] extra
            store="pgvector",
            store_url=dsn,
            namespace="pg-demo",
        )
    )

    rag.ingest_sync(
        [
            Document(
                id="kb-1",
                text=(
                    "Refunds are processed within 5 business days of approval.\n\n"
                    "Email confirmations are sent to the customer once issued."
                ),
                tags={"section": "policy"},
            ),
            Document(
                id="kb-2",
                text=(
                    "Standard shipping takes 3-7 business days within the continental US."
                ),
                tags={"section": "shipping"},
            ),
        ]
    )

    result = rag.query_sync("How long do refunds take?", top_k=3)
    print(f"Provider: {result.provider}/{result.model}")
    print(f"Answer  : {result.answer}\n")
    for s in result.sources:
        print(f"  [Source {s.index}] {s.document_id} score={s.score:.3f}")
    print(f"\ncost=${result.cost_usd:.6f}  run_id={result.run_id}")


if __name__ == "__main__":
    main()
