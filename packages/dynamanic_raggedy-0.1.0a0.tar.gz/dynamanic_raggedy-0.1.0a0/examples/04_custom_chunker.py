"""Custom chunker example.

Any object that satisfies the `Chunker` Protocol can be injected directly
via the `Raggedy(chunker=...)` constructor arg, bypassing the config-name
registry. Use this when you need a domain-specific splitter (markdown
headings, transcripts with timestamps, code blocks, etc.).
"""

from __future__ import annotations

import re
from itertools import pairwise

from examples_helpers import pick_llm

from raggedy import Chunk, Document, Raggedy, RaggedyConfig
from raggedy.util.ids import new_chunk_id
from raggedy.util.tokens import naive_token_count


class MarkdownHeadingChunker:
    """Splits a markdown document at each top-level `#`/`##` heading."""

    strategy = "markdown-heading"
    target_tokens = 0       # protocol parity (unused here)
    overlap_tokens = 0

    _HEADING = re.compile(r"^(#{1,2})\s+(.+)$", flags=re.MULTILINE)

    async def chunk(self, document: Document, *, namespace: str) -> list[Chunk]:
        text = document.text
        positions = [m.start() for m in self._HEADING.finditer(text)]
        if not positions:
            return [
                Chunk(
                    id=new_chunk_id(document.id, 0),
                    document_id=document.id,
                    namespace=namespace,
                    text=text,
                    chunk_index=0,
                    start_char=0,
                    end_char=len(text),
                    token_count=naive_token_count(text),
                    overlap_tokens=0,
                    tags=dict(document.tags),
                    metadata=dict(document.metadata),
                )
            ]
        positions.append(len(text))
        chunks: list[Chunk] = []
        for idx, (start, end) in enumerate(pairwise(positions)):
            piece = text[start:end].rstrip()
            chunks.append(
                Chunk(
                    id=new_chunk_id(document.id, idx),
                    document_id=document.id,
                    namespace=namespace,
                    text=piece,
                    chunk_index=idx,
                    start_char=start,
                    end_char=start + len(piece),
                    token_count=naive_token_count(piece),
                    overlap_tokens=0,
                    tags=dict(document.tags),
                    metadata=dict(document.metadata),
                )
            )
        return chunks


def main() -> None:
    llm, llm_model = pick_llm()

    rag = Raggedy(
        RaggedyConfig(
            llm=llm,
            llm_model=llm_model,
            embedding="deterministic",
            store="memory",
            namespace="custom-chunker",
        ),
        chunker=MarkdownHeadingChunker(),  # inject directly
    )

    rag.ingest_sync(
        [
            Document(
                id="handbook",
                text=(
                    "# Refunds\n"
                    "Refunds are processed within 5 business days.\n\n"
                    "## Eligibility\n"
                    "Items must be returned within 30 days of purchase.\n\n"
                    "# Shipping\n"
                    "Standard shipping takes 3-7 business days within the US.\n"
                ),
            )
        ]
    )

    result = rag.query_sync("How long do refunds take?")
    print(f"Chunker  : {rag.chunker.strategy}")
    print(f"Provider : {result.provider}/{result.model}")
    print(f"Answer   : {result.answer}\n")
    for s in result.sources:
        print(f"  [Source {s.index}] {s.document_id} score={s.score:.3f}")


if __name__ == "__main__":
    main()
