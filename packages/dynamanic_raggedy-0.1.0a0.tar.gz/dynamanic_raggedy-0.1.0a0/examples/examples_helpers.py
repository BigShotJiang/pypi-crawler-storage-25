"""Shared helpers for the example scripts."""

from __future__ import annotations

import os
import sys

import httpx


def pick_llm() -> tuple[str, str]:
    """Return (provider_name, model_name) for the first reachable LLM.

    Exits with status 1 if nothing is reachable.
    """
    if os.getenv("ANTHROPIC_API_KEY"):
        return "anthropic", os.getenv("ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")
    if os.getenv("OPENAI_API_KEY"):
        return "openai", os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    ollama_base = os.getenv("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
    if _reachable(f"{ollama_base}/api/tags"):
        return "ollama", os.getenv("OLLAMA_MODEL", "llama3.2")
    lmstudio_base = os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1").rstrip("/")
    if _reachable(f"{lmstudio_base}/models"):
        return "lm_studio", os.getenv("LMSTUDIO_MODEL", "local-model")
    print(
        "No LLM provider reachable.\n"
        "  - put ANTHROPIC_API_KEY or OPENAI_API_KEY in .env, or\n"
        "  - start Ollama (http://localhost:11434), or\n"
        "  - start LM Studio (http://localhost:1234)\n",
        file=sys.stderr,
    )
    sys.exit(1)


def _reachable(url: str, timeout: float = 1.0) -> bool:
    try:
        return httpx.get(url, timeout=timeout).status_code < 500
    except Exception:
        return False
