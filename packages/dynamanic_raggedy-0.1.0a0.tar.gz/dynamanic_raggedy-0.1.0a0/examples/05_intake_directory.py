"""Intake example: index a directory of mixed .txt/.md/.html files.

Run from the repo root:
    python examples/05_intake_directory.py
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from examples_helpers import pick_llm

from raggedy import Raggedy, RaggedyConfig
from raggedy.intake import DirectorySource


def main() -> None:
    llm, llm_model = pick_llm()
    print(f"Using LLM: {llm} ({llm_model})")

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "policy.md").write_text(
            "# Refund policy\n\nRefunds are processed within 5 business days.\n",
            encoding="utf-8",
        )
        (root / "shipping.html").write_text(
            "<html><body><p>Shipping takes 3-7 business days within the US.</p></body></html>",
            encoding="utf-8",
        )
        (root / "faq.txt").write_text(
            "Q: Do you ship internationally?\nA: Yes, up to 14 business days.\n",
            encoding="utf-8",
        )

        rag = Raggedy(
            RaggedyConfig(
                llm=llm,
                llm_model=llm_model,
                embedding="deterministic",
                store="memory",
                namespace="handbook",
            )
        )

        chunks = rag.ingest_from_sync(
            DirectorySource(root),
            tags={"corpus": "handbook"},
        )
        print(f"Ingested {len(chunks)} chunks from {root}")

        result = rag.query_sync("How long does international shipping take?", top_k=3)
        print()
        print("Answer:")
        print(f"  {result.answer}")
        print()
        print("Sources:")
        for s in result.sources:
            print(
                f"  [Source {s.index}] document={s.document_id} chunk={s.chunk_id} "
                f"score={s.score:.3f}"
            )


if __name__ == "__main__":
    main()
