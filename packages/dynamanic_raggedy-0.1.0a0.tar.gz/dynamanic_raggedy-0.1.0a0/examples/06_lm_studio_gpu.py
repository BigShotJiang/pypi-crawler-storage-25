"""LM Studio example with GPU-accelerated local embeddings.

Set up:
  - Start LM Studio with a model loaded (e.g., Llama 3.1 / Qwen / Mistral)
  - Default base URL: http://localhost:1234/v1
  - Override with LMSTUDIO_BASE_URL / LMSTUDIO_MODEL

The embedder runs sentence-transformers locally with device="auto"
(CUDA → MPS → CPU). Requires:
    pip install 'raggedy[local,openai]'
(openai SDK is used for LM Studio's OpenAI-compatible endpoint.)
"""

from __future__ import annotations

import os

from raggedy import Document, Raggedy, RaggedyConfig


def main() -> None:
    rag = Raggedy(
        RaggedyConfig(
            llm="lm_studio",
            llm_model=os.getenv("LMSTUDIO_MODEL", "local-model"),
            embedding="sentence-transformers",
            embedding_model="sentence-transformers/all-MiniLM-L6-v2",
            device="auto",
            store="memory",
            namespace="lm-demo",
        )
    )

    rag.ingest_sync(
        [
            Document(
                id="d1",
                text="The mitochondrion is the powerhouse of the cell.",
            ),
            Document(
                id="d2",
                text="Photosynthesis converts light energy into chemical energy in plants.",
            ),
        ]
    )

    result = rag.query_sync("What does the mitochondrion do?")
    print(f"LLM   : {result.provider} / {result.model}")
    print(f"Device: {getattr(rag.embedder, 'device', 'n/a')}")
    print(f"Answer: {result.answer}")
    for s in result.sources:
        print(f"  [Source {s.index}] {s.document_id} score={s.score:.3f}")


if __name__ == "__main__":
    main()
