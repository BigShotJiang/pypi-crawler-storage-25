"""`RaggedyConfig.from_yaml` tests."""

from __future__ import annotations

from pathlib import Path

import pytest

from raggedy import RaggedyConfig
from raggedy.errors import ConfigError


def test_from_yaml_loads_fields(tmp_path: Path):
    cfg_path = tmp_path / "raggedy.yaml"
    cfg_path.write_text(
        """
        llm: anthropic
        llm_model: claude-haiku-4-5-20251001
        embedding: sentence-transformers
        embedding_model: sentence-transformers/all-MiniLM-L6-v2
        device: auto
        store: memory
        namespace: yaml-test
        chunker_strategy: paragraph
        chunk_target_tokens: 256
        cost_daily_limit_usd: 0.50
        """,
        encoding="utf-8",
    )
    cfg = RaggedyConfig.from_yaml(cfg_path)
    assert cfg.llm == "anthropic"
    assert cfg.llm_model == "claude-haiku-4-5-20251001"
    assert cfg.chunker_strategy == "paragraph"
    assert cfg.chunk_target_tokens == 256
    assert cfg.cost_daily_limit_usd == 0.50
    assert cfg.namespace == "yaml-test"


def test_from_yaml_overrides_take_precedence(tmp_path: Path):
    cfg_path = tmp_path / "raggedy.yaml"
    cfg_path.write_text("namespace: from_file\nllm: ollama\n", encoding="utf-8")
    cfg = RaggedyConfig.from_yaml(cfg_path, namespace="override", llm="openai")
    assert cfg.namespace == "override"
    assert cfg.llm == "openai"


def test_from_yaml_missing_file_raises(tmp_path: Path):
    with pytest.raises(ConfigError):
        RaggedyConfig.from_yaml(tmp_path / "nope.yaml")


def test_from_yaml_empty_file_is_ok(tmp_path: Path):
    cfg_path = tmp_path / "empty.yaml"
    cfg_path.write_text("", encoding="utf-8")
    cfg = RaggedyConfig.from_yaml(cfg_path)
    # All defaults retained.
    assert cfg.llm == "ollama"


def test_from_yaml_non_mapping_root_raises(tmp_path: Path):
    cfg_path = tmp_path / "bad.yaml"
    cfg_path.write_text("- just\n- a\n- list\n", encoding="utf-8")
    with pytest.raises(ConfigError):
        RaggedyConfig.from_yaml(cfg_path)


def test_from_yaml_invalid_field_raises(tmp_path: Path):
    cfg_path = tmp_path / "bad.yaml"
    cfg_path.write_text("top_k: not-an-int\n", encoding="utf-8")
    with pytest.raises(ConfigError):
        RaggedyConfig.from_yaml(cfg_path)
