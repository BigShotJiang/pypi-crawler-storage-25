from __future__ import annotations

from raggedy import Document
from raggedy.chunking.semantic import SemanticChunker


async def test_short_doc_yields_single_chunk():
    chunker = SemanticChunker(target_tokens=512)
    chunks = await chunker.chunk(Document(id="d", text="Hello world."), namespace="ns")
    assert len(chunks) == 1
    assert chunks[0].text == "Hello world."
    assert chunks[0].start_char == 0
    assert chunks[0].end_char == len("Hello world.")
    assert chunks[0].chunk_index == 0
    assert chunks[0].namespace == "ns"


async def test_long_doc_splits_with_overlap():
    paragraphs = ["Paragraph " + str(i) + " " + ("word " * 80) for i in range(6)]
    text = "\n\n".join(paragraphs)
    chunker = SemanticChunker(target_tokens=80, overlap_tokens=20, min_chunk_tokens=10)
    chunks = await chunker.chunk(Document(id="d", text=text), namespace="ns")
    assert len(chunks) >= 2
    # First chunk has no overlap; subsequent ones do.
    assert chunks[0].overlap_tokens == 0
    assert any(c.overlap_tokens > 0 for c in chunks[1:])
    # All chunks index into the original text.
    for c in chunks:
        assert text[c.start_char:c.end_char] == c.text


async def test_chunks_carry_tags_and_metadata():
    chunker = SemanticChunker()
    doc = Document(
        id="d",
        text="A short doc.",
        tags={"k": "v"},
        metadata={"source": "unit-test"},
    )
    chunks = await chunker.chunk(doc, namespace="ns")
    assert chunks[0].tags == {"k": "v"}
    assert chunks[0].metadata["source"] == "unit-test"
    assert "content_hash" in chunks[0].metadata
