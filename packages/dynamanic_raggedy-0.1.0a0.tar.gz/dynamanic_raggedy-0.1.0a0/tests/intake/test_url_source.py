"""`UrlSource` tests — backed by an in-process httpx MockTransport."""

from __future__ import annotations

import httpx

from raggedy.intake import UrlSource


def _client_with(responses: dict[str, httpx.Response]) -> httpx.AsyncClient:
    def handler(request: httpx.Request) -> httpx.Response:
        return responses[str(request.url)]

    transport = httpx.MockTransport(handler)
    return httpx.AsyncClient(transport=transport, follow_redirects=True)


async def test_url_source_yields_one_item_per_url():
    client = _client_with(
        {
            "https://example.com/a": httpx.Response(
                200, content=b"<html><body>Alpha</body></html>",
                headers={"content-type": "text/html; charset=utf-8"},
            ),
            "https://example.com/b.txt": httpx.Response(
                200, content=b"Beta plain text",
                headers={"content-type": "text/plain"},
            ),
        }
    )
    src = UrlSource(
        ["https://example.com/a", "https://example.com/b.txt"],
        client=client,
    )
    items = [it async for it in src.items()]
    assert [it.source_uri for it in items] == [
        "https://example.com/a",
        "https://example.com/b.txt",
    ]
    assert items[0].content_type == "text/html"
    assert items[1].content_type == "text/plain"
    assert items[0].filename == "a"
    assert items[1].filename == "b.txt"
    assert "Alpha" in items[0].data.decode()
    await client.aclose()


async def test_url_source_strips_content_type_parameters():
    client = _client_with(
        {
            "https://example.com/x": httpx.Response(
                200, content=b"x",
                headers={"content-type": "text/plain; charset=us-ascii; boundary=abc"},
            ),
        }
    )
    src = UrlSource("https://example.com/x", client=client)
    items = [it async for it in src.items()]
    assert items[0].content_type == "text/plain"
    await client.aclose()


async def test_url_source_raises_on_4xx():
    import pytest

    client = _client_with(
        {
            "https://example.com/missing": httpx.Response(
                404, content=b"not found", headers={"content-type": "text/plain"}
            ),
        }
    )
    src = UrlSource("https://example.com/missing", client=client)
    with pytest.raises(httpx.HTTPStatusError):
        _ = [it async for it in src.items()]
    await client.aclose()
