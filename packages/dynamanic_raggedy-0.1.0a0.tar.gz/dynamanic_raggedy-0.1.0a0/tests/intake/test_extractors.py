from __future__ import annotations

from raggedy.intake import HtmlExtractor, IntakeItem, PlainTextExtractor, guess_content_type


async def test_plaintext_extractor_utf8():
    item = IntakeItem(
        source_uri="memory://x", filename="x.txt",
        content_type="text/plain", data=b"hello world",
    )
    text = await PlainTextExtractor().extract(item)
    assert text == "hello world"


async def test_plaintext_extractor_falls_back_to_latin1():
    item = IntakeItem(
        source_uri="memory://x", filename="x.txt",
        content_type="text/plain", data=b"caf\xe9",  # latin-1 for "café"
    )
    text = await PlainTextExtractor().extract(item)
    assert "caf" in text


async def test_html_extractor_strips_script_and_style():
    html = (
        "<html><head><style>p{color:red}</style>"
        "<script>alert('x')</script></head>"
        "<body><p>Hello <b>world</b></p><p>Goodbye</p></body></html>"
    )
    item = IntakeItem(
        source_uri="https://example.com",
        filename="index.html",
        content_type="text/html",
        data=html.encode("utf-8"),
    )
    text = await HtmlExtractor().extract(item)
    assert "Hello" in text
    assert "Goodbye" in text
    assert "alert" not in text
    assert "color:red" not in text


def test_guess_content_type_known_extensions():
    assert guess_content_type("notes.md") == "text/markdown"
    assert guess_content_type("doc.pdf") == "application/pdf"
    assert guess_content_type("page.html") == "text/html"
    assert guess_content_type("data.json") == "application/json"
    assert guess_content_type("UPPER.PDF") == "application/pdf"
    assert guess_content_type(None) == "application/octet-stream"
    assert guess_content_type("no-ext") == "application/octet-stream"
