from __future__ import annotations

from pathlib import Path

import pytest

from raggedy.intake import (
    DirectorySource,
    FileSource,
    IntakeItem,
    IntakeRunner,
    MemorySource,
)


async def test_memory_source_yields_items_in_order():
    items = [
        IntakeItem(
            source_uri=f"memory://{i}",
            filename=f"f{i}.txt",
            content_type="text/plain",
            data=f"item-{i}".encode(),
        )
        for i in range(3)
    ]
    out = [it async for it in MemorySource(items).items()]
    assert [it.source_uri for it in out] == [f"memory://{i}" for i in range(3)]


async def test_file_source_reads_a_file(tmp_path: Path):
    p = tmp_path / "hello.txt"
    p.write_text("hello from file", encoding="utf-8")
    out = [it async for it in FileSource(p).items()]
    assert len(out) == 1
    assert out[0].filename == "hello.txt"
    assert out[0].content_type == "text/plain"
    assert out[0].data == b"hello from file"


async def test_directory_source_walks_and_filters(tmp_path: Path):
    (tmp_path / "a.txt").write_text("alpha", encoding="utf-8")
    (tmp_path / "b.md").write_text("# beta", encoding="utf-8")
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "c.txt").write_text("gamma", encoding="utf-8")

    # All files
    src = DirectorySource(tmp_path)
    names = sorted([it.filename for it in [i async for i in src.items()]])
    assert names == ["a.txt", "b.md", "c.txt"]

    # Filter by extension
    src = DirectorySource(tmp_path, extensions={".txt"})
    names = sorted([it.filename for it in [i async for i in src.items()]])
    assert names == ["a.txt", "c.txt"]


async def test_directory_source_non_recursive(tmp_path: Path):
    (tmp_path / "top.txt").write_text("top", encoding="utf-8")
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "deep.txt").write_text("deep", encoding="utf-8")
    src = DirectorySource(tmp_path, pattern="*.txt", recursive=False)
    names = sorted([it.filename for it in [i async for i in src.items()]])
    assert names == ["top.txt"]


async def test_intake_runner_produces_documents(tmp_path: Path):
    (tmp_path / "a.md").write_text("# Heading\nSome text.", encoding="utf-8")
    (tmp_path / "b.html").write_text(
        "<html><body><p>HTML body content</p></body></html>", encoding="utf-8"
    )
    src = DirectorySource(tmp_path)
    runner = IntakeRunner()
    docs = [d async for d in runner.documents(src)]
    assert any("Heading" in d.text for d in docs)
    assert any("HTML body content" in d.text for d in docs)
    # source_uri propagates into metadata
    for d in docs:
        assert "source_uri" in d.metadata
        assert d.id.startswith("intake_")


async def test_intake_runner_skips_unsupported_when_asked(tmp_path: Path):
    (tmp_path / "x.bin").write_bytes(b"\x00\x01\x02")
    (tmp_path / "y.txt").write_text("readable", encoding="utf-8")
    src = DirectorySource(tmp_path)
    runner = IntakeRunner()
    docs = [d async for d in runner.documents(src, skip_unsupported=True)]
    assert len(docs) == 1
    assert docs[0].text == "readable"


async def test_intake_runner_raises_on_unsupported_when_not_skipping(tmp_path: Path):
    from raggedy.errors import ConfigError

    (tmp_path / "x.bin").write_bytes(b"\x00\x01\x02")
    src = DirectorySource(tmp_path)
    runner = IntakeRunner()
    with pytest.raises(ConfigError):
        _ = [d async for d in runner.documents(src, skip_unsupported=False)]
