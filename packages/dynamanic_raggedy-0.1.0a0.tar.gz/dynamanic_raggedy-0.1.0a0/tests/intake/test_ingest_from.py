from __future__ import annotations

from pathlib import Path

from raggedy import Raggedy, RaggedyConfig
from raggedy.intake import DirectorySource, IntakeItem, MemorySource


def _rag() -> Raggedy:
    return Raggedy(
        RaggedyConfig(
            llm="ollama",  # constructed but never called in these tests
            embedding="deterministic",
            store="memory",
            namespace="ingest-from-test",
        )
    )


async def test_ingest_from_directory_yields_chunks(tmp_path: Path):
    (tmp_path / "policy.md").write_text(
        "Refunds are processed within 5 business days.\n\nEmail confirmation is sent.",
        encoding="utf-8",
    )
    (tmp_path / "shipping.html").write_text(
        "<html><body><p>Shipping takes 3-7 business days within the US.</p></body></html>",
        encoding="utf-8",
    )

    rag = _rag()
    chunks = await rag.ingest_from(
        DirectorySource(tmp_path),
        tags={"corpus": "tmp"},
    )
    assert chunks
    assert all(c.tags.get("corpus") == "tmp" for c in chunks)


async def test_ingest_from_memory_source_yields_chunks():
    items = [
        IntakeItem(
            source_uri="memory://kb-1",
            filename="kb-1.txt",
            content_type="text/plain",
            data=b"Coffee is a brewed beverage prepared from roasted beans.",
        ),
        IntakeItem(
            source_uri="memory://kb-2",
            filename="kb-2.md",
            content_type="text/markdown",
            data=b"# Tea\n\nTea is an aromatic beverage prepared by pouring hot water over leaves.",
        ),
    ]
    rag = _rag()
    chunks = await rag.ingest_from(MemorySource(items))
    assert len(chunks) >= 2
    assert any("source_uri" in c.metadata for c in chunks)


def test_ingest_from_sync_wrapper(tmp_path: Path):
    (tmp_path / "doc.txt").write_text("sync wrapper test content", encoding="utf-8")
    rag = _rag()
    chunks = rag.ingest_from_sync(DirectorySource(tmp_path))
    assert chunks
