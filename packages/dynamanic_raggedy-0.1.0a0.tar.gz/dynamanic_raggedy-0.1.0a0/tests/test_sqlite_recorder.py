"""SqliteRunRecorder tests."""

from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("aiosqlite")

from raggedy.recording.sqlite import SqliteRunRecorder


async def test_full_run_round_trip(tmp_path: Path):
    db = tmp_path / "runs.db"
    recorder = SqliteRunRecorder(url=str(db))
    try:
        run_id = await recorder.start_run(
            namespace="ns",
            kind="query",
            query="What is X?",
            config_snapshot={"key": "value"},
            tags={"trace": "abc"},
        )
        await recorder.record_artifact(run_id, "retrieved_chunks", {"hits": [{"id": "c1"}]})
        await recorder.record_artifact(run_id, "prompt_render", {"template": "rag-v1"})
        await recorder.finish_run(
            run_id,
            status="ok",
            result={"answer_chars": 42},
            cost_usd=0.0125,
            prompt_tokens=120,
            completion_tokens=20,
            latency_ms=850,
        )

        record = await recorder.get(run_id)
        assert record is not None
        assert record.namespace == "ns"
        assert record.kind == "query"
        assert record.status == "ok"
        assert record.query == "What is X?"
        assert record.cost_usd == pytest.approx(0.0125)
        assert record.prompt_tokens == 120
        assert record.completion_tokens == 20
        assert record.latency_ms == 850
        assert record.tags == {"trace": "abc"}
        assert record.config_snapshot == {"key": "value"}
        assert record.result == {"answer_chars": 42}
        assert len(record.artifacts) == 2
        kinds = [a["kind"] for a in record.artifacts]
        assert kinds == ["retrieved_chunks", "prompt_render"]
    finally:
        await recorder.aclose()


async def test_list_filters_by_namespace_and_limit(tmp_path: Path):
    db = tmp_path / "runs.db"
    recorder = SqliteRunRecorder(url=str(db))
    try:
        for _ in range(3):
            run_id = await recorder.start_run(namespace="alpha", kind="ingest")
            await recorder.finish_run(run_id, status="ok")
        for _ in range(2):
            run_id = await recorder.start_run(namespace="beta", kind="query")
            await recorder.finish_run(run_id, status="ok")

        alpha_runs = await recorder.list_runs(namespace="alpha")
        beta_runs = await recorder.list_runs(namespace="beta")
        all_runs = await recorder.list_runs()
        assert len(alpha_runs) == 3
        assert len(beta_runs) == 2
        assert len(all_runs) == 5

        limited = await recorder.list_runs(namespace="alpha", limit=2)
        assert len(limited) == 2
    finally:
        await recorder.aclose()


async def test_persistence_across_instances(tmp_path: Path):
    db = tmp_path / "runs.db"
    r1 = SqliteRunRecorder(url=str(db))
    try:
        run_id = await r1.start_run(namespace="ns", kind="query", query="hello")
        await r1.record_artifact(run_id, "redaction_applied", {"pii_count": 0})
        await r1.finish_run(run_id, status="ok")
    finally:
        await r1.aclose()

    r2 = SqliteRunRecorder(url=str(db))
    try:
        record = await r2.get(run_id)
        assert record is not None
        assert record.status == "ok"
        assert record.artifacts and record.artifacts[0]["kind"] == "redaction_applied"
    finally:
        await r2.aclose()


async def test_record_artifact_on_unknown_run_silently_skips(tmp_path: Path):
    """Foreign-key-on conn raises; ensure the error surfaces as ConfigError."""
    from raggedy.errors import ConfigError

    db = tmp_path / "runs.db"
    recorder = SqliteRunRecorder(url=str(db))
    try:
        with pytest.raises(ConfigError):
            await recorder.record_artifact("no-such-run", "x", {"v": 1})
    finally:
        await recorder.aclose()


async def test_end_to_end_through_raggedy(tmp_path: Path):
    """Wire sqlite recorder via RaggedyConfig and verify a query lands in the DB."""
    from raggedy import Document, Raggedy, RaggedyConfig

    db = tmp_path / "runs.db"
    rag = Raggedy(
        RaggedyConfig(
            llm="ollama",  # never called
            embedding="deterministic",
            store="memory",
            recorder="sqlite",
            recorder_url=str(db),
            namespace="sqlite-recorder-test",
        )
    )
    try:
        await rag.ingest([Document(id="d1", text="hello world")])
        runs = await rag.recorder.list_runs(namespace="sqlite-recorder-test")
        assert any(r.kind == "ingest" and r.status == "ok" for r in runs)
    finally:
        await rag.recorder.aclose()  # type: ignore[attr-defined]
