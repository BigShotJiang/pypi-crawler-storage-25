"""SqliteCostTracker tests."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

pytest.importorskip("aiosqlite")

from raggedy.cost.sqlite import SqliteCostTracker
from raggedy.errors import CostLimitExceeded


async def test_record_usage_accumulates(tmp_path: Path):
    db = tmp_path / "cost.db"
    tracker = SqliteCostTracker(url=str(db))
    try:
        await tracker.record_usage(
            namespace="ns", model="m", cost_usd=0.10,
            prompt_tokens=100, completion_tokens=50,
        )
        await tracker.record_usage(
            namespace="ns", model="m", cost_usd=0.25,
            prompt_tokens=200, completion_tokens=100,
        )
        assert await tracker.get_daily_cost(namespace="ns") == pytest.approx(0.35)
    finally:
        await tracker.aclose()


async def test_check_limit_raises_when_over(tmp_path: Path):
    db = tmp_path / "cost.db"
    tracker = SqliteCostTracker(url=str(db), daily_limit_usd=1.00)
    try:
        await tracker.record_usage(
            namespace="ns", model="m", cost_usd=0.95,
            prompt_tokens=1, completion_tokens=1,
        )
        # Projected cost 0.10 + current 0.95 = 1.05 > 1.00
        with pytest.raises(CostLimitExceeded):
            await tracker.check_limit(namespace="ns", projected_cost_usd=0.10)
        # Stays within budget for a smaller projection
        await tracker.check_limit(namespace="ns", projected_cost_usd=0.04)
    finally:
        await tracker.aclose()


async def test_record_usage_concurrent_safe(tmp_path: Path):
    db = tmp_path / "cost.db"
    tracker = SqliteCostTracker(url=str(db))
    try:
        await asyncio.gather(
            *[
                tracker.record_usage(
                    namespace="ns", model="m", cost_usd=0.01,
                    prompt_tokens=1, completion_tokens=1,
                )
                for _ in range(20)
            ]
        )
        assert await tracker.get_daily_cost(namespace="ns") == pytest.approx(0.20)
    finally:
        await tracker.aclose()


async def test_per_namespace_isolation(tmp_path: Path):
    db = tmp_path / "cost.db"
    tracker = SqliteCostTracker(url=str(db))
    try:
        await tracker.record_usage(
            namespace="alpha", model="m", cost_usd=0.50,
            prompt_tokens=1, completion_tokens=1,
        )
        await tracker.record_usage(
            namespace="beta", model="m", cost_usd=0.10,
            prompt_tokens=1, completion_tokens=1,
        )
        assert await tracker.get_daily_cost(namespace="alpha") == pytest.approx(0.50)
        assert await tracker.get_daily_cost(namespace="beta") == pytest.approx(0.10)
        assert await tracker.get_daily_cost(namespace="gamma") == pytest.approx(0.0)
    finally:
        await tracker.aclose()


async def test_persistence_across_instances(tmp_path: Path):
    db = tmp_path / "cost.db"
    t1 = SqliteCostTracker(url=str(db))
    try:
        await t1.record_usage(
            namespace="ns", model="m", cost_usd=0.42,
            prompt_tokens=1, completion_tokens=1,
        )
    finally:
        await t1.aclose()
    t2 = SqliteCostTracker(url=str(db))
    try:
        assert await t2.get_daily_cost(namespace="ns") == pytest.approx(0.42)
    finally:
        await t2.aclose()
