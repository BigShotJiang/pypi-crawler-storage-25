from __future__ import annotations

import pytest

from raggedy import (
    CostLimitExceeded,
    Document,
    Raggedy,
    RaggedyConfig,
)
from raggedy.errors import ConfigError


async def test_ingest_returns_chunks_and_records_run(rag, sample_docs):
    chunks = await rag.ingest(sample_docs)
    assert chunks
    runs = await rag.recorder.list_runs(namespace="test")
    assert any(r.status == "ok" and r.kind == "ingest" for r in runs)


async def test_query_returns_sources_and_calls_live_llm(rag, sample_docs, live_llm):
    rag.llm = live_llm
    rag.pipeline.llm = live_llm
    await rag.ingest(sample_docs)
    result = await rag.query("How long do refunds take?", top_k=2)
    assert result.answer.strip(), "live LLM returned an empty answer"
    assert 1 <= len(result.sources) <= 2
    assert result.run_id.startswith("run_")
    assert result.provider == live_llm.name


async def test_query_with_tag_filter_returns_filtered_sources(rag, sample_docs, live_llm):
    rag.llm = live_llm
    rag.pipeline.llm = live_llm
    await rag.ingest(sample_docs)
    result = await rag.query(
        "How long does shipping take?",
        tags={"section": "shipping"},
        top_k=5,
    )
    assert result.sources
    assert all(s.tags.get("section") == "shipping" for s in result.sources)


async def test_cost_limit_blocks_query_before_llm_call():
    """Cost gate runs before the LLM, so this test never hits the network."""
    cfg = RaggedyConfig(
        llm="ollama",  # constructed but never called
        embedding="deterministic",
        store="memory",
        cost_daily_limit_usd=1.00,
    )
    rag = Raggedy(cfg)
    await rag.ingest([Document(id="d1", text="hello world")])
    # Pre-record enough usage that today's spend is already over the limit;
    # this exercises the gate regardless of the LLM's `estimate_cost` (Ollama
    # returns 0 since it's free).
    await rag.cost.record_usage(
        namespace=cfg.namespace,
        model="seed",
        cost_usd=10.0,
        prompt_tokens=0,
        completion_tokens=0,
    )
    with pytest.raises(CostLimitExceeded):
        await rag.query("hi there")
    runs = await rag.recorder.list_runs()
    assert any(r.status == "cost_blocked" for r in runs)


async def test_empty_query_rejected(rag):
    with pytest.raises(ConfigError):
        await rag.query("   ")


async def test_redaction_artifact_records_counts_only(rag):
    await rag.ingest(
        [Document(id="leaky", text="Email me at alice@example.com or call 555-867-5309.")]
    )
    runs = await rag.recorder.list_runs(namespace="test")
    ingest_run = next(r for r in runs if r.kind == "ingest")
    redaction_artifacts = [a for a in ingest_run.artifacts if a["kind"] == "redaction_applied"]
    assert redaction_artifacts
    payload = redaction_artifacts[0]["payload"]
    counts = payload["counts_by_type"]
    assert counts.get("email") == 1
    assert counts.get("phone") == 1
    flat = str(payload)
    assert "alice@example.com" not in flat
    assert "867-5309" not in flat


async def test_unknown_llm_name_raises_config_error():
    with pytest.raises(ConfigError):
        Raggedy(RaggedyConfig(llm="not-a-real-provider"))


async def test_unknown_embedder_name_raises_config_error():
    with pytest.raises(ConfigError):
        Raggedy(RaggedyConfig(embedding="not-a-real-embedder"))


async def test_unknown_store_name_raises_config_error():
    with pytest.raises(ConfigError):
        Raggedy(RaggedyConfig(store="not-a-real-store"))
