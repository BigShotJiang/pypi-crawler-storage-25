"""Direct contract tests for `InMemoryStore`.

The pipeline integration tests skip when no LLM is reachable, so we
exercise the store API directly here.
"""

from __future__ import annotations

import pytest

from raggedy.stores.memory import InMemoryStore
from raggedy.types import Chunk


def _make_chunk(cid: str, ns: str, vec: list[float], **tags: str) -> Chunk:
    return Chunk(
        id=cid,
        document_id=cid.split("::")[0],
        namespace=ns,
        text=f"text-{cid}",
        chunk_index=0,
        start_char=0,
        end_char=10,
        token_count=2,
        overlap_tokens=0,
        tags=dict(tags),
        metadata={},
        embedding=vec,
    )


async def test_upsert_query_top_k_and_score():
    store = InMemoryStore()
    await store.upsert(
        [
            _make_chunk("a::0", "ns", [1.0, 0.0, 0.0, 0.0]),
            _make_chunk("b::0", "ns", [0.0, 1.0, 0.0, 0.0]),
            _make_chunk("c::0", "ns", [0.0, 0.0, 1.0, 0.0]),
        ]
    )
    hits = await store.query([1.0, 0.0, 0.0, 0.0], top_k=2, namespace="ns")
    assert len(hits) == 2
    assert hits[0].chunk.id == "a::0"
    assert hits[0].score == pytest.approx(1.0, abs=1e-6)


async def test_query_filters_by_tags():
    store = InMemoryStore()
    await store.upsert(
        [
            _make_chunk("a::0", "ns", [1.0, 0.0, 0.0, 0.0], color="red"),
            _make_chunk("b::0", "ns", [1.0, 0.0, 0.0, 0.0], color="blue"),
        ]
    )
    hits = await store.query(
        [1.0, 0.0, 0.0, 0.0], top_k=5, namespace="ns", tags={"color": "blue"}
    )
    assert {h.chunk.id for h in hits} == {"b::0"}


async def test_query_namespace_isolation():
    store = InMemoryStore()
    await store.upsert(
        [
            _make_chunk("a::0", "ns1", [1.0, 0.0, 0.0, 0.0]),
            _make_chunk("b::0", "ns2", [1.0, 0.0, 0.0, 0.0]),
        ]
    )
    hits = await store.query([1.0, 0.0, 0.0, 0.0], top_k=5, namespace="ns1")
    assert {h.chunk.id for h in hits} == {"a::0"}
    assert await store.query([1.0, 0.0, 0.0, 0.0], top_k=5, namespace="ghost") == []


async def test_query_min_score():
    store = InMemoryStore()
    await store.upsert(
        [
            _make_chunk("a::0", "ns", [1.0, 0.0, 0.0, 0.0]),
            _make_chunk("b::0", "ns", [-1.0, 0.0, 0.0, 0.0]),
        ]
    )
    hits = await store.query(
        [1.0, 0.0, 0.0, 0.0], top_k=5, namespace="ns", min_score=0.5
    )
    assert {h.chunk.id for h in hits} == {"a::0"}


async def test_query_skips_chunks_with_zero_vector():
    store = InMemoryStore()
    await store.upsert([_make_chunk("a::0", "ns", [0.0, 0.0, 0.0, 0.0])])
    assert await store.query([1.0, 0.0, 0.0, 0.0], top_k=5, namespace="ns") == []


async def test_zero_query_vector_returns_nothing():
    store = InMemoryStore()
    await store.upsert([_make_chunk("a::0", "ns", [1.0, 0.0, 0.0, 0.0])])
    assert await store.query([0.0, 0.0, 0.0, 0.0], top_k=5, namespace="ns") == []


async def test_upsert_requires_embedding():
    store = InMemoryStore()
    chunk = _make_chunk("a::0", "ns", [1.0])
    chunk.embedding = None
    with pytest.raises(ValueError):
        await store.upsert([chunk])


async def test_delete_by_ids_and_tags():
    store = InMemoryStore()
    await store.upsert(
        [
            _make_chunk("a::0", "ns", [1.0, 0.0, 0.0, 0.0], color="red"),
            _make_chunk("b::0", "ns", [0.0, 1.0, 0.0, 0.0], color="red"),
            _make_chunk("c::0", "ns", [0.0, 0.0, 1.0, 0.0], color="blue"),
        ]
    )
    assert await store.delete(ids=["a::0"]) == 1
    assert await store.count() == 2
    assert await store.delete(namespace="ns", tags={"color": "red"}) == 1
    assert await store.count() == 1


async def test_count_by_namespace():
    store = InMemoryStore()
    await store.upsert(
        [
            _make_chunk("a::0", "ns1", [1.0, 0.0, 0.0, 0.0]),
            _make_chunk("b::0", "ns2", [0.0, 1.0, 0.0, 0.0]),
        ]
    )
    assert await store.count() == 2
    assert await store.count(namespace="ns1") == 1
    assert await store.count(namespace="unknown") == 0
