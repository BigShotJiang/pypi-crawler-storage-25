"""ChromaStore tests.

Uses Chroma's `EphemeralClient` (in-process) by default so these run in CI
without an external service. Set `RAGGEDY_TEST_CHROMA_URL` to a real
Chroma server URL to additionally exercise the HTTP transport.
"""

from __future__ import annotations

import os
import uuid

import pytest

pytest.importorskip("chromadb")

from raggedy import Document, Raggedy, RaggedyConfig
from raggedy.stores.chroma import ChromaStore
from raggedy.types import Chunk

CHROMA_URL = os.getenv("RAGGEDY_TEST_CHROMA_URL", ":memory:")


def _collection() -> str:
    return f"raggedy_test_{uuid.uuid4().hex[:8]}"


def _make_chunk(cid: str, ns: str, text: str, vec: list[float], **tags: str) -> Chunk:
    return Chunk(
        id=cid,
        document_id=cid.split("::")[0],
        namespace=ns,
        text=text,
        chunk_index=0,
        start_char=0,
        end_char=len(text),
        token_count=max(1, len(text) // 4),
        overlap_tokens=0,
        tags=dict(tags),
        metadata={"k": "v"},
        embedding=vec,
    )


async def test_upsert_then_query_returns_nearest():
    store = ChromaStore(url=CHROMA_URL, collection=_collection())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns", "apple", [1.0, 0.0, 0.0, 0.0]),
                _make_chunk("b::0", "ns", "banana", [0.0, 1.0, 0.0, 0.0]),
                _make_chunk("c::0", "ns", "cherry", [0.0, 0.0, 1.0, 0.0]),
            ]
        )
        assert await store.count() == 3
        assert await store.count(namespace="ns") == 3
        assert await store.count(namespace="other") == 0

        hits = await store.query([1.0, 0.0, 0.0, 0.0], top_k=2, namespace="ns")
        assert hits
        assert hits[0].chunk.id == "a::0"
        assert hits[0].score == pytest.approx(1.0, abs=1e-3)
    finally:
        await store.aclose()


async def test_query_respects_namespace_isolation():
    store = ChromaStore(url=CHROMA_URL, collection=_collection())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns1", "apple", [1.0, 0.0, 0.0, 0.0]),
                _make_chunk("b::0", "ns2", "banana", [1.0, 0.0, 0.0, 0.0]),
            ]
        )
        hits = await store.query([1.0, 0.0, 0.0, 0.0], top_k=5, namespace="ns1")
        assert {h.chunk.id for h in hits} == {"a::0"}
    finally:
        await store.aclose()


async def test_query_filters_by_tags():
    store = ChromaStore(url=CHROMA_URL, collection=_collection())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns", "apple", [1.0, 0.0, 0.0, 0.0], color="red"),
                _make_chunk("b::0", "ns", "banana", [1.0, 0.0, 0.0, 0.0], color="yellow"),
            ]
        )
        hits = await store.query(
            [1.0, 0.0, 0.0, 0.0],
            top_k=5,
            namespace="ns",
            tags={"color": "red"},
        )
        assert {h.chunk.id for h in hits} == {"a::0"}
    finally:
        await store.aclose()


async def test_min_score_filters_results():
    store = ChromaStore(url=CHROMA_URL, collection=_collection())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns", "x", [1.0, 0.0, 0.0, 0.0]),
                _make_chunk("b::0", "ns", "y", [-1.0, 0.0, 0.0, 0.0]),
            ]
        )
        hits = await store.query(
            [1.0, 0.0, 0.0, 0.0], top_k=5, namespace="ns", min_score=0.5
        )
        assert {h.chunk.id for h in hits} == {"a::0"}
    finally:
        await store.aclose()


async def test_delete_by_ids_and_by_tags():
    store = ChromaStore(url=CHROMA_URL, collection=_collection())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns", "x", [1.0, 0.0, 0.0, 0.0], color="red"),
                _make_chunk("b::0", "ns", "y", [0.0, 1.0, 0.0, 0.0], color="red"),
                _make_chunk("c::0", "ns", "z", [0.0, 0.0, 1.0, 0.0], color="blue"),
            ]
        )
        assert await store.delete(ids=["a::0"]) == 1
        assert await store.count() == 2
        assert await store.delete(namespace="ns", tags={"color": "red"}) == 1
        assert await store.count() == 1
    finally:
        await store.aclose()


async def test_end_to_end_through_raggedy():
    cfg = RaggedyConfig(
        llm="ollama",  # never called
        embedding="deterministic",
        store="chroma",
        store_url=CHROMA_URL,
        namespace="chroma-test",
    )
    rag = Raggedy(cfg)
    rag.store._collection_name = _collection()  # type: ignore[attr-defined]
    try:
        await rag.ingest(
            [
                Document(id="d1", text="Refunds take 5 business days."),
                Document(id="d2", text="Shipping takes 3-7 days within the US."),
            ]
        )
        assert await rag.store.count() == 2
    finally:
        await rag.store.aclose()  # type: ignore[attr-defined]
