"""PgVectorStore tests.

Requires a reachable Postgres instance with the `vector` extension available.
Set `RAGGEDY_TEST_PG_URL` to a postgres DSN to enable. Skipped otherwise.

Quick local setup:
    docker run --rm -d -p 5432:5432 -e POSTGRES_PASSWORD=pg \
        --name raggedy-pg ankane/pgvector
    export RAGGEDY_TEST_PG_URL=postgresql://postgres:pg@localhost:5432/postgres
"""

from __future__ import annotations

import os
import uuid

import pytest

pytest.importorskip("asyncpg")

PG_URL = os.getenv("RAGGEDY_TEST_PG_URL")
if not PG_URL:
    pytest.skip("RAGGEDY_TEST_PG_URL not set", allow_module_level=True)

from raggedy import Document, Raggedy, RaggedyConfig  # noqa: E402
from raggedy.stores.pgvector import PgVectorStore  # noqa: E402
from raggedy.types import Chunk  # noqa: E402


def _table() -> str:
    return f"raggedy_test_{uuid.uuid4().hex[:8]}"


def _make_chunk(cid: str, ns: str, text: str, vec: list[float], **tags: str) -> Chunk:
    return Chunk(
        id=cid,
        document_id=cid.split("::")[0],
        namespace=ns,
        text=text,
        chunk_index=0,
        start_char=0,
        end_char=len(text),
        token_count=max(1, len(text) // 4),
        overlap_tokens=0,
        tags=dict(tags),
        metadata={"k": "v"},
        embedding=vec,
    )


async def _drop(store: PgVectorStore) -> None:
    pool = await store._get_pool()  # type: ignore[attr-defined]
    async with pool.acquire() as conn:
        await conn.execute(f"DROP TABLE IF EXISTS {store._table}")  # type: ignore[attr-defined]


async def test_upsert_query_and_delete():
    store = PgVectorStore(url=PG_URL, table=_table())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns", "apple", [1.0, 0.0, 0.0, 0.0]),
                _make_chunk("b::0", "ns", "banana", [0.0, 1.0, 0.0, 0.0]),
                _make_chunk("c::0", "ns2", "cherry", [0.0, 0.0, 1.0, 0.0]),
            ]
        )
        assert await store.count() == 3
        assert await store.count(namespace="ns") == 2

        hits = await store.query([1.0, 0.0, 0.0, 0.0], top_k=2, namespace="ns")
        assert hits[0].chunk.id == "a::0"
        assert hits[0].score == pytest.approx(1.0, abs=1e-3)

        deleted = await store.delete(ids=["a::0"])
        assert deleted == 1
        assert await store.count() == 2
    finally:
        await _drop(store)
        await store.aclose()


async def test_filters_by_tags():
    store = PgVectorStore(url=PG_URL, table=_table())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns", "x", [1.0, 0.0, 0.0, 0.0], color="red"),
                _make_chunk("b::0", "ns", "y", [1.0, 0.0, 0.0, 0.0], color="blue"),
            ]
        )
        hits = await store.query(
            [1.0, 0.0, 0.0, 0.0],
            top_k=5,
            namespace="ns",
            tags={"color": "red"},
        )
        assert {h.chunk.id for h in hits} == {"a::0"}
    finally:
        await _drop(store)
        await store.aclose()


async def test_dim_mismatch_raises():
    from raggedy.errors import ProviderError

    store = PgVectorStore(url=PG_URL, table=_table())
    try:
        await store.upsert([_make_chunk("a::0", "ns", "x", [1.0, 0.0, 0.0, 0.0])])
        with pytest.raises(ProviderError):
            await store.upsert([_make_chunk("b::0", "ns", "y", [1.0, 0.0, 0.0])])
    finally:
        await _drop(store)
        await store.aclose()


async def test_end_to_end_through_raggedy():
    """Wire the store through Raggedy facade and run ingest end-to-end."""
    table = _table()
    cfg = RaggedyConfig(
        llm="ollama",  # never called
        embedding="deterministic",
        store="pgvector",
        store_url=PG_URL,
        namespace="pg-test",
    )
    rag = Raggedy(cfg)
    # The facade passed only `url=` to the constructor, so we replace the
    # table on the live store to keep the test isolated:
    rag.store._table = table  # type: ignore[attr-defined]
    try:
        await rag.ingest(
            [
                Document(id="d1", text="Refunds take 5 business days."),
                Document(id="d2", text="Shipping takes 3-7 days within the US."),
            ]
        )
        assert await rag.store.count() == 2
    finally:
        await _drop(rag.store)  # type: ignore[arg-type]
        await rag.store.aclose()  # type: ignore[attr-defined]
