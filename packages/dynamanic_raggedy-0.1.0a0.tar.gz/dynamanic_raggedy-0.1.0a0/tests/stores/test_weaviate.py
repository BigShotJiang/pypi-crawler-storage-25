"""WeaviateStore tests.

Requires a reachable Weaviate v1.24+ instance (HTTP + gRPC). Set
`RAGGEDY_TEST_WEAVIATE_URL` to enable. Skipped otherwise.

Quick local setup:
    docker run --rm -d -p 8080:8080 -p 50051:50051 \\
        -e AUTHENTICATION_ANONYMOUS_ACCESS_ENABLED=true \\
        -e DEFAULT_VECTORIZER_MODULE=none \\
        --name raggedy-weaviate \\
        semitechnologies/weaviate:1.27
    export RAGGEDY_TEST_WEAVIATE_URL=http://localhost:8080
"""

from __future__ import annotations

import os
import uuid

import pytest

pytest.importorskip("weaviate")

WEAVIATE_URL = os.getenv("RAGGEDY_TEST_WEAVIATE_URL")
if not WEAVIATE_URL:
    pytest.skip("RAGGEDY_TEST_WEAVIATE_URL not set", allow_module_level=True)

from raggedy import Document, Raggedy, RaggedyConfig  # noqa: E402
from raggedy.stores.weaviate import WeaviateStore  # noqa: E402
from raggedy.types import Chunk  # noqa: E402


def _collection() -> str:
    # Weaviate requires PascalCase starting with an uppercase letter.
    return f"RaggedyTest{uuid.uuid4().hex[:8]}"


def _make_chunk(cid: str, ns: str, text: str, vec: list[float], **tags: str) -> Chunk:
    return Chunk(
        id=cid,
        document_id=cid.split("::")[0],
        namespace=ns,
        text=text,
        chunk_index=0,
        start_char=0,
        end_char=len(text),
        token_count=max(1, len(text) // 4),
        overlap_tokens=0,
        tags=dict(tags),
        metadata={"k": "v"},
        embedding=vec,
    )


async def _drop(store: WeaviateStore) -> None:
    import contextlib

    client = await store._get_client()  # type: ignore[attr-defined]
    with contextlib.suppress(Exception):
        await client.collections.delete(store._collection_name)  # type: ignore[attr-defined]


async def test_upsert_query_and_delete():
    store = WeaviateStore(url=WEAVIATE_URL, collection=_collection())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns", "apple", [1.0, 0.0, 0.0, 0.0]),
                _make_chunk("b::0", "ns", "banana", [0.0, 1.0, 0.0, 0.0]),
                _make_chunk("c::0", "ns2", "cherry", [0.0, 0.0, 1.0, 0.0]),
            ]
        )
        assert await store.count() == 3
        assert await store.count(namespace="ns") == 2

        hits = await store.query([1.0, 0.0, 0.0, 0.0], top_k=2, namespace="ns")
        assert hits[0].chunk.id == "a::0"
        assert hits[0].score == pytest.approx(1.0, abs=1e-3)

        deleted = await store.delete(ids=["a::0"])
        assert deleted == 1
        assert await store.count() == 2
    finally:
        await _drop(store)
        await store.aclose()


async def test_filters_by_tags():
    store = WeaviateStore(url=WEAVIATE_URL, collection=_collection())
    try:
        await store.upsert(
            [
                _make_chunk("a::0", "ns", "x", [1.0, 0.0, 0.0, 0.0], color="red"),
                _make_chunk("b::0", "ns", "y", [1.0, 0.0, 0.0, 0.0], color="blue"),
            ]
        )
        hits = await store.query(
            [1.0, 0.0, 0.0, 0.0],
            top_k=5,
            namespace="ns",
            tags={"color": "red"},
        )
        assert {h.chunk.id for h in hits} == {"a::0"}
    finally:
        await _drop(store)
        await store.aclose()


async def test_dim_mismatch_raises():
    from raggedy.errors import ProviderError

    store = WeaviateStore(url=WEAVIATE_URL, collection=_collection())
    try:
        await store.upsert([_make_chunk("a::0", "ns", "x", [1.0, 0.0, 0.0, 0.0])])
        with pytest.raises(ProviderError):
            await store.upsert([_make_chunk("b::0", "ns", "y", [1.0, 0.0, 0.0])])
    finally:
        await _drop(store)
        await store.aclose()


async def test_end_to_end_through_raggedy():
    cfg = RaggedyConfig(
        llm="ollama",  # never called
        embedding="deterministic",
        store="weaviate",
        store_url=WEAVIATE_URL,
        namespace="weaviate-test",
    )
    rag = Raggedy(cfg)
    rag.store._collection_name = _collection()  # type: ignore[attr-defined]
    try:
        await rag.ingest(
            [
                Document(id="d1", text="Refunds take 5 business days."),
                Document(id="d2", text="Shipping takes 3-7 days within the US."),
            ]
        )
        assert await rag.store.count() == 2
    finally:
        await _drop(rag.store)  # type: ignore[arg-type]
        await rag.store.aclose()  # type: ignore[attr-defined]
