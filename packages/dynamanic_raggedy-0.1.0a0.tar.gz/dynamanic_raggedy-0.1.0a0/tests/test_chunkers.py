"""Contract tests covering the four chunker strategies."""

from __future__ import annotations

import pytest

from raggedy import Document
from raggedy.chunking import (
    FixedChunker,
    ParagraphChunker,
    SemanticChunker,
    SentenceChunker,
)


def _doc(text: str) -> Document:
    return Document(id="d", text=text, tags={"k": "v"}, metadata={"src": "ut"})


async def test_paragraph_chunker_one_chunk_per_paragraph():
    text = "Para one is here.\n\nPara two is over here.\n\n\nPara three."
    chunks = await ParagraphChunker().chunk(_doc(text), namespace="ns")
    assert len(chunks) == 3
    assert chunks[0].text == "Para one is here."
    assert chunks[1].text == "Para two is over here."
    assert chunks[2].text == "Para three."
    for c in chunks:
        assert text[c.start_char:c.end_char] == c.text
        assert c.namespace == "ns"
        assert c.tags == {"k": "v"}
        assert c.overlap_tokens == 0


async def test_paragraph_chunker_skips_blank_runs():
    text = "Alpha.\n\n   \n\nBeta."
    chunks = await ParagraphChunker().chunk(_doc(text), namespace="ns")
    assert [c.text for c in chunks] == ["Alpha.", "Beta."]


async def test_sentence_chunker_merges_to_target():
    text = (
        "First sentence. Second sentence. Third sentence. "
        "Fourth sentence here. Fifth one too."
    )
    chunker = SentenceChunker(target_tokens=10)
    chunks = await chunker.chunk(_doc(text), namespace="ns")
    assert len(chunks) >= 2
    for c in chunks:
        assert text[c.start_char:c.end_char] == c.text
    assert chunks[0].overlap_tokens == 0


async def test_sentence_chunker_overlap_extends_start():
    text = "Sentence A. " * 10
    chunker = SentenceChunker(target_tokens=10, overlap_tokens=5)
    chunks = await chunker.chunk(_doc(text), namespace="ns")
    assert any(c.overlap_tokens > 0 for c in chunks[1:])


async def test_fixed_chunker_windowing():
    text = ("word " * 200).strip()  # ~1000 chars
    chunker = FixedChunker(target_tokens=50, overlap_tokens=10)
    chunks = await chunker.chunk(_doc(text), namespace="ns")
    assert len(chunks) >= 2
    for c in chunks:
        assert text[c.start_char:c.end_char] == c.text
    # Subsequent chunks carry overlap_tokens > 0
    assert any(c.overlap_tokens > 0 for c in chunks[1:])


async def test_semantic_chunker_still_works():
    text = "Para one " * 20 + "\n\n" + "Para two " * 20
    chunker = SemanticChunker(target_tokens=30, overlap_tokens=5, min_chunk_tokens=1)
    chunks = await chunker.chunk(_doc(text), namespace="ns")
    assert len(chunks) >= 1
    for c in chunks:
        assert text[c.start_char:c.end_char] == c.text


async def test_chunker_validation_rejects_bad_overlap():
    with pytest.raises(ValueError):
        SentenceChunker(target_tokens=10, overlap_tokens=10)
    with pytest.raises(ValueError):
        FixedChunker(target_tokens=10, overlap_tokens=15)


async def test_pipeline_dispatches_to_paragraph_chunker():
    from raggedy import Raggedy, RaggedyConfig

    rag = Raggedy(
        RaggedyConfig(
            llm="ollama",
            embedding="deterministic",
            store="memory",
            chunker_strategy="paragraph",
            namespace="chunker-test",
        )
    )
    chunks = await rag.ingest(
        [Document(id="d1", text="Alpha section.\n\nBeta section.\n\nGamma section.")]
    )
    assert len(chunks) == 3
