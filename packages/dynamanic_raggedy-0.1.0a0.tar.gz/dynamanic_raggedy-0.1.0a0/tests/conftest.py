"""Shared pytest fixtures.

No mock or stub providers — tests that need a live LLM use a real one
(Anthropic / OpenAI / Ollama / LM Studio) and skip when none is reachable.
Tests that exercise paths *before* the LLM call (chunking, PII, cost gate,
retrieval, ingest) build `Raggedy` with the standard config and never reach
a network.
"""

from __future__ import annotations

import os
from collections.abc import Iterator

import httpx
import pytest

from raggedy import Document, Raggedy, RaggedyConfig
from raggedy.protocols.llm import LLMProvider


@pytest.fixture
def offline_config() -> RaggedyConfig:
    """Config that never touches the network for ingest/retrieval/cost paths.

    `llm` is set to `ollama` so Raggedy can construct an LLMProvider, but
    the provider only contacts Ollama on `complete()` — which these tests
    do not call.
    """
    return RaggedyConfig(
        llm="ollama",
        llm_model="llama3.2",
        embedding="deterministic",
        store="memory",
        recorder="memory",
        namespace="test",
    )


@pytest.fixture
def rag(offline_config: RaggedyConfig) -> Raggedy:
    return Raggedy(offline_config)


@pytest.fixture
def sample_docs() -> list[Document]:
    return [
        Document(
            id="doc-1",
            text=(
                "Refunds are processed within 5 business days after approval. "
                "Customers receive an email confirmation when the refund is issued."
            ),
            tags={"section": "policy"},
        ),
        Document(
            id="doc-2",
            text=(
                "Shipping typically takes 3-7 business days within the continental US. "
                "International shipping can take up to 14 business days."
            ),
            tags={"section": "shipping"},
        ),
    ]


@pytest.fixture
def live_llm() -> Iterator[LLMProvider]:
    """Return a reachable real `LLMProvider`, or skip the test.

    Resolution order:
      1. `RAGGEDY_TEST_LLM` env var (anthropic | openai | ollama | lm_studio)
      2. Anthropic if `ANTHROPIC_API_KEY` is set
      3. OpenAI if `OPENAI_API_KEY` is set
      4. Ollama if reachable at `OLLAMA_HOST` or http://localhost:11434
      5. LM Studio if reachable at LMSTUDIO_BASE_URL or http://localhost:1234
    """
    forced = os.getenv("RAGGEDY_TEST_LLM", "").strip().lower()
    if forced:
        provider = _build_named(forced)
        if provider is None:
            pytest.skip(f"RAGGEDY_TEST_LLM={forced!r} but provider not reachable")
        yield provider
        return

    for candidate in ("anthropic", "openai", "ollama", "lm_studio"):
        provider = _build_named(candidate)
        if provider is not None:
            yield provider
            return
    pytest.skip(
        "No live LLM available. Set ANTHROPIC_API_KEY, OPENAI_API_KEY, "
        "run Ollama, or run LM Studio to enable LLM tests."
    )


def _build_named(name: str) -> LLMProvider | None:
    from raggedy.llm.registry import build_llm

    if name == "anthropic":
        if not os.getenv("ANTHROPIC_API_KEY"):
            return None
        try:
            return build_llm("anthropic", "claude-haiku-4-5-20251001")
        except Exception:
            return None
    if name == "openai":
        if not os.getenv("OPENAI_API_KEY"):
            return None
        try:
            return build_llm("openai", "gpt-4o-mini")
        except Exception:
            return None
    if name == "ollama":
        base = os.getenv("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
        if not _http_reachable(f"{base}/api/tags"):
            return None
        try:
            return build_llm("ollama", os.getenv("OLLAMA_MODEL", "llama3.2"))
        except Exception:
            return None
    if name in ("lm_studio", "lmstudio"):
        base = os.getenv("LMSTUDIO_BASE_URL", "http://localhost:1234/v1").rstrip("/")
        if not _http_reachable(f"{base}/models"):
            return None
        try:
            return build_llm("lm_studio", os.getenv("LMSTUDIO_MODEL", "local-model"))
        except Exception:
            return None
    return None


def _http_reachable(url: str, timeout: float = 1.0) -> bool:
    try:
        r = httpx.get(url, timeout=timeout)
        return r.status_code < 500
    except Exception:
        return False
