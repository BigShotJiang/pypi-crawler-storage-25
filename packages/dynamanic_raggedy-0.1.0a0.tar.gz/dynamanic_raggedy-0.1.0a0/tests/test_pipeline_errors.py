"""Pipeline error-path tests — exercises wrapping into ProviderError / ConfigError."""

from __future__ import annotations

import pytest

from raggedy import Document, Raggedy, RaggedyConfig
from raggedy.errors import ConfigError, NoMatchesFound, ProviderError


class _FailingEmbedder:
    model_id = "test-embedder"
    dimension = 4

    async def embed(self, text: str) -> list[float]:
        raise RuntimeError("embed-boom")

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        raise RuntimeError("batch-boom")


class _WrongCountEmbedder:
    model_id = "wrong-count"
    dimension = 4

    async def embed(self, text: str) -> list[float]:
        return [1.0, 0.0, 0.0, 0.0]

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        # Return fewer vectors than chunks
        return [[1.0, 0.0, 0.0, 0.0]] if texts else []


async def test_embedder_failure_in_ingest_raises_provider_error():
    rag = Raggedy(
        RaggedyConfig(llm="ollama", embedding="deterministic", store="memory"),
        embedder=_FailingEmbedder(),
    )
    with pytest.raises(ProviderError):
        await rag.ingest([Document(id="d1", text="hello world")])
    runs = await rag.recorder.list_runs()
    assert any(r.status == "error" for r in runs)


async def test_embedder_returns_wrong_count_raises_provider_error():
    rag = Raggedy(
        RaggedyConfig(
            llm="ollama",
            embedding="deterministic",
            store="memory",
            chunker_strategy="paragraph",  # one chunk per paragraph guarantees > 1
        ),
        embedder=_WrongCountEmbedder(),
    )
    with pytest.raises(ProviderError):
        await rag.ingest(
            [Document(id="d1", text="Para one is here.\n\nPara two is over here.")]
        )


async def test_no_matches_found_when_policy_is_raise():
    cfg = RaggedyConfig(
        llm="ollama",
        embedding="deterministic",
        store="memory",
        namespace="empty",
        empty_retrieval_policy="raise",
        min_score=0.99,  # nothing will pass since corpus is empty anyway
    )
    rag = Raggedy(cfg)
    with pytest.raises(NoMatchesFound):
        await rag.query("anything")
    runs = await rag.recorder.list_runs()
    assert any(r.status == "no_matches" for r in runs)


async def test_empty_documents_raises_config_error():
    rag = Raggedy(RaggedyConfig(llm="ollama", embedding="deterministic", store="memory"))
    with pytest.raises(ConfigError):
        await rag.ingest([])
