from __future__ import annotations

from raggedy import PIIType
from raggedy.pii.redactor import RegexPIIRedactor


def test_redact_email_and_phone():
    r = RegexPIIRedactor()
    result = r.redact("Email alice@example.com or call 555-867-5309 for details.")
    assert "alice@example.com" not in result.redacted_text
    assert "555-867-5309" not in result.redacted_text
    assert "[EMAIL_REDACTED_1]" in result.redacted_text
    assert "[PHONE_REDACTED_1]" in result.redacted_text
    assert result.counts_by_type == {"email": 1, "phone": 1}


def test_redaction_map_round_trip():
    r = RegexPIIRedactor()
    text = "SSN: 123-45-6789"
    result = r.redact(text)
    placeholder = next(iter(result.redaction_map))
    assert result.redaction_map[placeholder] == "123-45-6789"
    assert "123-45-6789" not in result.redacted_text


def test_no_pii_passes_through_unchanged():
    r = RegexPIIRedactor()
    text = "This document discusses generic policies and procedures."
    result = r.redact(text)
    assert result.redacted_text == text
    assert result.pii_count == 0
    assert result.redaction_map == {}


def test_credit_card_luhn_boosts_confidence():
    r = RegexPIIRedactor()
    # 4111 1111 1111 1111 — a well-known Luhn-valid test card.
    result = r.redact("Card on file: 4111 1111 1111 1111.")
    cc_matches = [m for m in result.matches if m.pii_type is PIIType.CREDIT_CARD]
    assert cc_matches
    assert cc_matches[0].confidence >= 0.99


def test_versions_present_on_result():
    r = RegexPIIRedactor()
    result = r.redact("nothing here")
    assert result.policy_version
    assert result.patterns_version
