# Raggedy

Batteries-included, importable RAG core. `pip install dynamanic-raggedy`, then `from raggedy import ...` — drop it into any Python app.

## Status

Pre-release (`0.1.0a0`). The library ships no mock providers — every LLM and embedder is a real adapter. Tests skip cleanly when no live LLM is reachable.

Phase 1 + intake + real providers shipped: in-memory store, deterministic embedder, semantic chunker, PII redaction (10 types, ephemeral map), cost tracking with daily limits, audit-run records, intake layer (files / directories / URLs / S3 → plain text / markdown / HTML / PDF / DOCX), and LLM adapters for Anthropic, OpenAI, Ollama, and LM Studio plus a GPU-aware local embedder (sentence-transformers, CUDA → MPS → CPU autodetect).

## Quick start

```python
from raggedy import Raggedy, RaggedyConfig, Document

rag = Raggedy(RaggedyConfig(
    llm="anthropic",                  # or "openai", "ollama", "lm_studio"
    llm_model="claude-haiku-4-5-20251001",
    embedding="sentence-transformers",
    embedding_model="sentence-transformers/all-MiniLM-L6-v2",
    device="auto",                    # CUDA → MPS → CPU
    store="memory",
    namespace="kb-handbook",
))

rag.ingest_sync([
    Document(id="hb-1", text="Refunds are processed within 5 business days."),
])

result = rag.query_sync("How long do refunds take?", top_k=4)
print(result.answer)
for s in result.sources:
    print(f"[Source {s.index}] {s.document_id} score={s.score:.3f}")
print(f"cost=${result.cost_usd:.6f} run_id={result.run_id}")
```

### `.env`

`Raggedy()` calls `python-dotenv` once at construction and populates `os.environ` (without overriding existing vars). Drop your keys in a `.env` file at the project root:

```
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
OLLAMA_HOST=http://localhost:11434
LMSTUDIO_BASE_URL=http://localhost:1234/v1
```

See `.env.example` for the full list.

### Intake

`Raggedy.ingest_from(source)` streams documents through extractors before indexing.

```python
from raggedy.intake import DirectorySource, UrlSource

rag.ingest_from_sync(DirectorySource("./docs"), tags={"corpus": "handbook"})
rag.ingest_from_sync(UrlSource(["https://example.com/blog"]))
```

## Install

The PyPI distribution name is `dynamanic-raggedy` (the short name `raggedy` is taken by an unrelated maintained project). The import path is still `raggedy`.

```sh
pip install dynamanic-raggedy                  # base: deterministic embedder, in-memory store, intake stdlib parsers
pip install "dynamanic-raggedy[anthropic]"     # Anthropic LLM
pip install "dynamanic-raggedy[openai]"        # OpenAI LLM + embeddings; also powers LM Studio (OpenAI-compatible)
pip install "dynamanic-raggedy[ollama]"        # no extra deps — ollama uses base httpx
pip install "dynamanic-raggedy[local]"         # sentence-transformers + torch (GPU-aware)
pip install "dynamanic-raggedy[pdf]"           # PDF extractor (pypdf)
pip install "dynamanic-raggedy[docx]"          # DOCX extractor (python-docx)
pip install "dynamanic-raggedy[s3]"            # S3 source (boto3)
pip install "dynamanic-raggedy[sqlitevec]"     # SQLite-vec store
pip install "dynamanic-raggedy[pgvector]"      # pgvector store
pip install "dynamanic-raggedy[qdrant]"        # Qdrant store
pip install "dynamanic-raggedy[chroma]"        # Chroma store
pip install "dynamanic-raggedy[weaviate]"      # Weaviate store
pip install "dynamanic-raggedy[all]"           # everything
```

## License

MIT
