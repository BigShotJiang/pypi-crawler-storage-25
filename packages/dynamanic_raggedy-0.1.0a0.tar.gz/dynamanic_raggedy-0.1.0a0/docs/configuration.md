# Configuration

`RaggedyConfig` is a `pydantic_settings.BaseSettings` with `env_prefix="RAGGEDY_"`. Every field is overridable in three ways:

1. **Constructor kwargs** — `RaggedyConfig(llm="anthropic", top_k=8)`
2. **Environment variables** — `RAGGEDY_LLM=anthropic RAGGEDY_TOP_K=8 python my_app.py`
3. **`.env` file** — picked up automatically; loaded once at `Raggedy(...)` construction by `python-dotenv`
4. **YAML file** — `RaggedyConfig.from_yaml("raggedy.yaml", llm="openai")` (kwargs override file values)

## All fields

### Adapter selection

| Field | Default | Description |
|-------|---------|-------------|
| `llm`               | `"ollama"`       | `anthropic` \| `openai` \| `ollama` \| `lm_studio` |
| `llm_model`         | `"llama3.2"`     | Provider-specific model id |
| `embedding`         | `"deterministic"` | `deterministic` \| `sentence-transformers` \| `openai` \| `ollama` \| `lm_studio` |
| `embedding_model`   | `"deterministic-384"` | Backend-specific model id |
| `store`             | `"memory"`       | `memory` \| `sqlite-vec` \| `pgvector` \| `qdrant` \| `chroma` \| `weaviate` |
| `store_url`         | `None`           | Backend DSN / URL / path |
| `recorder`          | `"memory"`       | `memory` \| `sqlite` |
| `recorder_url`      | `None`           | SQLite path for the sqlite recorder |
| `chunker_strategy`  | `"semantic"`     | `semantic` \| `paragraph` \| `sentence` \| `fixed` |

### Namespacing & retrieval

| Field | Default | Description |
|-------|---------|-------------|
| `namespace`               | `"default"`       | Logical workspace; used by every store |
| `top_k`                   | `5`               | Default top-k for `query()` |
| `min_score`               | `0.0`             | Discard hits below this score |
| `max_context_tokens`      | `8000`            | Budget for the assembled `[Source N]` context |
| `empty_retrieval_policy`  | `"fall_through"`  | `fall_through` \| `raise` (`NoMatchesFound`) |

### Chunking

| Field | Default | Description |
|-------|---------|-------------|
| `chunk_target_tokens`  | `512` | Target chunk size |
| `chunk_overlap_tokens` | `100` | Tokens of leading overlap |
| `chunk_min_tokens`     | `50`  | Drop chunks smaller than this |

### LLM

| Field | Default | Description |
|-------|---------|-------------|
| `llm_max_output_tokens` | `1024` | `max_tokens` for the completion |
| `llm_temperature`       | `0.2`  | Temperature passed to the provider |

### Embeddings

| Field | Default | Description |
|-------|---------|-------------|
| `embedding_dimension`   | `384`    | Used by the deterministic embedder |
| `device`                | `"auto"` | `auto` \| `cuda` \| `cuda:0` \| `mps` \| `cpu` |
| `embedding_batch_size`  | `32`     | Batch for local embedders (constrained GPUs) |

### PII redaction

| Field | Default | Description |
|-------|---------|-------------|
| `redaction_enabled` | `True`         | Set False to swap in `NoOpRedactor` |
| `redaction_policy`  | `"default-v1"` | Pinned in run records for reproducibility |

### Cost tracking

| Field | Default | Description |
|-------|---------|-------------|
| `cost_tracking_enabled` | `True`     | Set False to swap in `NoOpCostTracker` |
| `cost_daily_limit_usd`  | `None`     | Per-namespace daily limit (USD); `None` disables the gate |
| `cost_backend`          | `"memory"` | `memory` \| `sqlite` |
| `cost_backend_url`      | `None`     | SQLite path for the sqlite cost tracker |

### Prompt template

| Field | Default | Description |
|-------|---------|-------------|
| `prompt_template_version` | `"rag-v1"` | Pinned in run records; switch to a new key in `raggedy.prompts.templates.RAG_PROMPT_TEMPLATES` to A/B prompts. |

### Logging

| Field | Default | Description |
|-------|---------|-------------|
| `log_level` | `"INFO"` | Standard library log levels |

## YAML loading

```python
from raggedy import RaggedyConfig

cfg = RaggedyConfig.from_yaml("raggedy.yaml", namespace="acme")
```

```yaml
# raggedy.yaml
llm: anthropic
llm_model: claude-haiku-4-5-20251001
embedding: sentence-transformers
embedding_model: sentence-transformers/all-MiniLM-L6-v2
device: auto
store: pgvector
store_url: postgresql://postgres:pg@localhost/postgres
chunker_strategy: semantic
chunk_target_tokens: 512
chunk_overlap_tokens: 64
cost_daily_limit_usd: 5.00
cost_backend: sqlite
cost_backend_url: ./raggedy_cost.db
recorder: sqlite
recorder_url: ./raggedy_runs.db
```

## Reading API keys

Raggedy never reads provider keys from `RaggedyConfig`. Instead it calls `python-dotenv` once at `Raggedy(...)` construction and populates `os.environ` (without overriding existing vars). Provider SDKs (`anthropic`, `openai`, etc.) read from `os.getenv("ANTHROPIC_API_KEY")` directly.

Drop your keys in `.env`:

```bash
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
OLLAMA_HOST=http://localhost:11434
LMSTUDIO_BASE_URL=http://localhost:1234/v1
```

See `.env.example` in the repo root for the canonical list.
