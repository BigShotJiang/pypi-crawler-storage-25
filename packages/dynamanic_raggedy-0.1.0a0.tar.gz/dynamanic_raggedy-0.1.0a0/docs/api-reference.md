# API reference

This is the curated public surface. Everything in `from raggedy import …` is supported; everything else is internal and may change between minor versions.

## `Raggedy`

```python
class Raggedy:
    def __init__(
        self,
        config: RaggedyConfig | None = None,
        *,
        store: VectorStore | None = None,
        embedder: EmbeddingBackend | None = None,
        llm: LLMProvider | None = None,
        chunker: Chunker | None = None,
        redactor: PIIRedactor | None = None,
        cost: CostTracker | None = None,
        recorder: RunRecorder | None = None,
        load_dotenv: bool = True,
    ): ...

    # Async
    async def ingest(self, documents: list[Document], *, namespace: str | None = None,
                     tags: dict[str, str] | None = None) -> list[Chunk]: ...
    async def query(self, query_text: str, *, namespace: str | None = None,
                    top_k: int | None = None, tags: dict[str, str] | None = None,
                    min_score: float | None = None) -> QueryResult: ...
    async def ingest_from(self, source: Source, *, namespace: str | None = None,
                          tags: dict[str, str] | None = None, batch_size: int = 32,
                          skip_unsupported: bool = True,
                          intake: IntakeRunner | None = None) -> list[Chunk]: ...

    # Sync shims (asgiref.async_to_sync)
    def ingest_sync(...) -> list[Chunk]
    def query_sync(...) -> QueryResult
    def ingest_from_sync(...) -> list[Chunk]
```

## `RaggedyConfig`

Full field list lives in [Configuration](configuration.md). Two construction helpers:

```python
RaggedyConfig()                                # uses env + .env
RaggedyConfig.from_yaml("raggedy.yaml", **overrides)
```

## Core dataclasses

```python
@dataclass(slots=True)
class Document:
    id: str
    text: str
    tags: dict[str, str] = ...
    metadata: dict[str, Any] = ...

@dataclass(slots=True)
class Chunk:
    id: str
    document_id: str
    namespace: str
    text: str
    chunk_index: int
    start_char: int
    end_char: int
    token_count: int
    overlap_tokens: int = 0
    start_page: int | None = None
    end_page: int | None = None
    tags: dict[str, str] = ...
    metadata: dict[str, Any] = ...
    embedding: list[float] | None = None

@dataclass(slots=True)
class Source:
    index: int
    document_id: str
    chunk_id: str
    score: float
    text_preview: str
    start_char: int
    end_char: int
    start_page: int | None = None
    end_page: int | None = None
    tags: dict[str, str] = ...

@dataclass(slots=True)
class QueryResult:
    answer: str
    sources: list[Source]
    run_id: str
    cost_usd: float
    prompt_tokens: int
    completion_tokens: int
    latency_ms: int
    finish_reason: str
    model: str
    provider: str
    prompt_template_version: str

@dataclass(slots=True)
class RunRecord:
    run_id: str
    namespace: str
    kind: str                              # "query" | "ingest"
    started_at: datetime
    finished_at: datetime | None
    status: str                            # "ok" | "cost_blocked" | "provider_error" | "no_matches" | "error" | "running"
    query: str | None
    config_snapshot: dict[str, Any]
    artifacts: list[dict[str, Any]]
    result: dict[str, Any] | None
    error: str | None
    cost_usd: float
    prompt_tokens: int
    completion_tokens: int
    latency_ms: int
    tags: dict[str, str]
```

## Errors

```python
class RaggedyError(Exception): ...
class ConfigError(RaggedyError): ...
class CostLimitExceeded(RaggedyError):
    namespace: str
    projected_cost_usd: float
    limit_usd: float
class NoMatchesFound(RaggedyError): ...
class ProviderError(RaggedyError):
    provider: str
    retryable: bool
```

## Protocols

All eight protocols are exposed from `raggedy.protocols` and re-exported at the top level for type hints:

```python
from raggedy import (
    VectorStore, EmbeddingBackend, LLMProvider, Chunker,
    PIIRedactor, CostTracker, RunRecorder,
    Logger, EventSink, ProviderCapabilities,
)
```

Implement any of these to swap a piece of the pipeline. See [Concepts](concepts.md) for signatures.

## Intake

```python
from raggedy.intake import (
    DirectorySource, FileSource, MemorySource, UrlSource,   # base
    HtmlExtractor, PlainTextExtractor,                       # base
    ExtractorRegistry, IntakeRunner, IntakeItem,
    guess_content_type,
    Source, Extractor,                                       # protocols
)
# Extras:
from raggedy.intake.sources.s3 import S3Source              # [s3]
from raggedy.intake.extractors.pdf import PdfExtractor      # [pdf]
from raggedy.intake.extractors.docx import DocxExtractor    # [docx]
```
