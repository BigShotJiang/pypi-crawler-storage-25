# Intake layer

`Raggedy.ingest_from(source)` streams documents from a `Source`, dispatches each item's `content_type` to an `Extractor`, builds `Document`s, and feeds them through the same ingest pipeline as `ingest(...)`. Use this when you have files / URLs / cloud objects to consume rather than hand-built `Document` payloads.

## Sources

| `Source` | Module | Extra | Notes |
|----------|--------|-------|-------|
| `MemorySource(items)`                          | `raggedy.intake.sources.memory`   | —          | Wrap an iterable of `IntakeItem`s. |
| `FileSource(path, *, content_type=None)`       | `raggedy.intake.sources.files`    | —          | One file. |
| `DirectorySource(path, *, pattern, recursive, extensions)` | `raggedy.intake.sources.files`    | —          | Walk a directory with glob filters. |
| `UrlSource(url_or_urls, *, timeout, headers)`  | `raggedy.intake.sources.url`      | —          | HTTP/HTTPS fetch via base httpx. |
| `S3Source(bucket, *, prefix, client_kwargs)`   | `raggedy.intake.sources.s3`       | `[s3]`     | List + download via boto3 wrapped in `asyncio.to_thread`. |

## Extractors

| `Extractor` | Module | Extra | Content types |
|-------------|--------|-------|---------------|
| `PlainTextExtractor`  | `raggedy.intake.extractors.plaintext` | —              | `text/plain`, `text/markdown`, `text/csv`, `application/json`, … |
| `HtmlExtractor`       | `raggedy.intake.extractors.html`      | — (stdlib only) | `text/html`, `application/xhtml+xml` |
| `PdfExtractor`        | `raggedy.intake.extractors.pdf`       | `[pdf]`         | `application/pdf` |
| `DocxExtractor`       | `raggedy.intake.extractors.docx`      | `[docx]`        | `application/vnd.openxmlformats-officedocument.wordprocessingml.document` |

The `ExtractorRegistry` maps `content_type` to an extractor instance. `guess_content_type(filename)` does the filename-extension lookup that `FileSource` / `DirectorySource` use internally. Unknown content types either skip silently (default) or raise via `IntakeRunner.documents(source, skip_unsupported=False)`.

## Full example

```python
from raggedy import Raggedy, RaggedyConfig
from raggedy.intake import DirectorySource, UrlSource

rag = Raggedy(RaggedyConfig(llm="anthropic", store="memory"))

# Local files
rag.ingest_from_sync(
    DirectorySource("./handbook", pattern="**/*", extensions={".md", ".pdf", ".docx"}),
    tags={"corpus": "handbook"},
)

# Web pages
rag.ingest_from_sync(
    UrlSource(["https://example.com/about", "https://example.com/pricing"]),
    tags={"corpus": "marketing"},
)

result = rag.query_sync("How do I get a refund?", tags={"corpus": "handbook"})
print(result.answer)
```

## Document IDs

Intake assigns a deterministic id from the source URI: `intake_<sha256(source_uri)[:16]>`. Re-running intake on the same source therefore replaces existing chunks (upsert semantics) rather than duplicating.

## Writing a custom Source

```python
from collections.abc import AsyncIterator
from raggedy.intake import IntakeItem
from raggedy.intake.protocols import Source

class RssSource(Source):
    name = "rss"
    def __init__(self, feed_url: str): self._url = feed_url
    async def items(self) -> AsyncIterator[IntakeItem]:
        # ... fetch + parse RSS ...
        for entry in entries:
            yield IntakeItem(
                source_uri=entry.link,
                filename=entry.title,
                content_type="text/html",
                data=entry.summary.encode("utf-8"),
                tags={"feed": self._url},
            )
```

Pass `RssSource(...)` to `rag.ingest_from(...)` and it dispatches into the same chunk → embed → store pipeline.
