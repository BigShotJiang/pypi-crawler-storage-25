# Quickstart

## Install

The base install brings the deterministic embedder, in-memory store, intake parsers (text + HTML), and the dotenv loader. Everything else is opt-in via extras.

The PyPI distribution name is `dynamanic-raggedy`; the import path is still `raggedy`.

```sh
pip install dynamanic-raggedy
```

Then add what you need:

```sh
pip install 'dynamanic-raggedy[anthropic]'   # Claude
pip install 'dynamanic-raggedy[openai]'      # GPT family + LM Studio
pip install 'dynamanic-raggedy[ollama]'      # no extra deps; uses base httpx
pip install 'dynamanic-raggedy[local]'       # sentence-transformers + torch
pip install 'dynamanic-raggedy[pgvector]'    # asyncpg + pgvector
pip install 'dynamanic-raggedy[qdrant]'      # qdrant-client
pip install 'dynamanic-raggedy[chroma]'      # chromadb
pip install 'dynamanic-raggedy[weaviate]'    # weaviate-client (v4)
pip install 'dynamanic-raggedy[sqlitevec]'   # sqlite-vec + aiosqlite
pip install 'dynamanic-raggedy[pdf]'         # pypdf
pip install 'dynamanic-raggedy[docx]'        # python-docx
pip install 'dynamanic-raggedy[s3]'          # boto3
pip install 'dynamanic-raggedy[all]'         # everything
```

## Set up `.env`

Raggedy calls `python-dotenv` once at construction time so SDK env vars (`ANTHROPIC_API_KEY`, `OPENAI_API_KEY`, …) are picked up automatically. Drop a `.env` next to your script:

```bash
# .env
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
OLLAMA_HOST=http://localhost:11434
LMSTUDIO_BASE_URL=http://localhost:1234/v1
```

## Hello world

```python
from raggedy import Document, Raggedy, RaggedyConfig

rag = Raggedy(RaggedyConfig(
    llm="anthropic",
    llm_model="claude-haiku-4-5-20251001",
    embedding="deterministic",   # swap to "sentence-transformers" for real semantics
    store="memory",
    namespace="kb",
))

rag.ingest_sync([
    Document(id="hb-1", text="Refunds are processed within 5 business days."),
    Document(id="hb-2", text="Standard shipping takes 3-7 business days in the US."),
])

result = rag.query_sync("How long do refunds take?", top_k=3)
print(result.answer)
for s in result.sources:
    print(f"[Source {s.index}] {s.document_id} score={s.score:.3f}")
print(f"cost=${result.cost_usd:.6f}  run_id={result.run_id}")
```

## Streaming a directory in

Use the [intake layer](intake.md) when you have files on disk, URLs to fetch, or S3 buckets to walk:

```python
from raggedy import Raggedy, RaggedyConfig
from raggedy.intake import DirectorySource

rag = Raggedy(RaggedyConfig(llm="anthropic", store="memory"))
rag.ingest_from_sync(DirectorySource("./docs"), tags={"corpus": "handbook"})
```

PDFs, DOCX, HTML, plain text, and markdown are all extracted to plain text and chunked the same way `Document(...)` payloads are.

## Going async

Every `_sync` method has an `async` sibling:

```python
async def main():
    rag = Raggedy(RaggedyConfig(...))
    await rag.ingest([...])
    result = await rag.query("...")
```

The pipeline is async-first; the sync wrappers exist for scripts and notebooks.
