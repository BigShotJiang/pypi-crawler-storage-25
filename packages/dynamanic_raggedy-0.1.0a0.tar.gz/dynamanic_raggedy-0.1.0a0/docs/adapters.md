# Adapters

Every adapter is loaded lazily by name through `RaggedyConfig`. Missing extras surface as `ConfigError` with the exact `pip install` command — never a raw `ImportError`.

## Vector stores

| `store=` | Module | Extra | URL form | Notes |
|----------|--------|-------|----------|-------|
| `memory`     | `raggedy.stores.memory.InMemoryStore`     | — (numpy only)         | n/a                              | Default. Dict + numpy cosine. |
| `sqlite-vec` | `raggedy.stores.sqlite_vec.SqliteVecStore`| `[sqlitevec]`          | `:memory:` / file path / `sqlite:///…` | Local persistent. vec0 with `distance_metric=cosine`. |
| `pgvector`   | `raggedy.stores.pgvector.PgVectorStore`   | `[pgvector]`           | `postgresql://…`                 | JSONB tags + GIN index. |
| `qdrant`     | `raggedy.stores.qdrant.QdrantStore`       | `[qdrant]`             | `:memory:` / file path / `http(s)://…` | UUIDv5 from chunk id; one collection per Raggedy instance. |
| `chroma`     | `raggedy.stores.chroma.ChromaStore`       | `[chroma]`             | `:memory:` / file path / `http(s)://…` | `embedding_function=None`; tags flattened to `tag_*` keys. |
| `weaviate`   | `raggedy.stores.weaviate.WeaviateStore`   | `[weaviate]`           | `http(s)://…`                    | v4 async client; PascalCase collection. |

Shared behaviour:

- Cosine similarity throughout. Score = `1 - cosine_distance`.
- Schema lazy-created on first `upsert` so the embedding dimension is known. Subsequent upserts with a different dim raise `ProviderError`.
- Every adapter exposes `aclose()` to release pooled connections.

## LLM providers

| `llm=` | Module | Extra | Notes |
|--------|--------|-------|-------|
| `anthropic`           | `raggedy.llm.anthropic.AnthropicProvider` | `[anthropic]`           | Claude 4.x family. Reads `ANTHROPIC_API_KEY`. |
| `openai`              | `raggedy.llm.openai.OpenAIProvider`       | `[openai]`              | tiktoken-aware `count_tokens` when installed. |
| `ollama`              | `raggedy.llm.ollama.OllamaProvider`       | — (base httpx)          | Local. `estimate_cost` always returns 0. |
| `lm_studio` / `lmstudio` | `raggedy.llm.openai.OpenAIProvider`    | `[openai]`              | OpenAI-compatible endpoint; reads `LMSTUDIO_BASE_URL`, `LMSTUDIO_API_KEY`. |

## Embedding backends

| `embedding=` | Module | Extra | Notes |
|--------------|--------|-------|-------|
| `deterministic`        | `raggedy.embeddings.deterministic.DeterministicEmbedder` | —              | Hashed bag-of-words. Real algorithm, no semantics — good for tests/CI. |
| `sentence-transformers` / `local` | `raggedy.embeddings.local.SentenceTransformersEmbedder` | `[local]` | GPU-aware. `device="auto"` picks CUDA → MPS → CPU. |
| `openai`               | `raggedy.embeddings.openai.OpenAIEmbedder`               | `[openai]`     | `text-embedding-3-small` default; pass `dimensions=` to truncate. |
| `ollama`               | `raggedy.embeddings.ollama.OllamaEmbedder`               | — (base httpx) | Uses `/api/embed` (batch); falls back to `/api/embeddings`. |
| `lm_studio` / `lmstudio` | `raggedy.embeddings.openai.OpenAIEmbedder`             | `[openai]`     | Reuses the OpenAI client pointed at LM Studio. |

## Chunkers

| `chunker_strategy=` | Module | Notes |
|---------------------|--------|-------|
| `semantic`  | `raggedy.chunking.semantic.SemanticChunker`   | Default. Paragraph + sentence boundaries, greedy merge, leading overlap. |
| `paragraph` | `raggedy.chunking.paragraph.ParagraphChunker` | One chunk per paragraph (no merging). |
| `sentence`  | `raggedy.chunking.sentence.SentenceChunker`   | Sentence-level greedy merge to `target_tokens`. |
| `fixed`     | `raggedy.chunking.fixed.FixedChunker`         | Fixed window with overlap; word-boundary snap. |

For a custom chunker, write any object satisfying the `Chunker` protocol and pass `chunker=` to `Raggedy(...)`. See [example 04](https://github.com/Dynamanic/raggedy/blob/main/examples/04_custom_chunker.py).

## Persistence

| `recorder=` / `cost_backend=` | Module | Extra |
|---|---|---|
| `recorder=memory`           | `raggedy.recording.memory.InMemoryRunRecorder` | — |
| `recorder=sqlite`           | `raggedy.recording.sqlite.SqliteRunRecorder`   | `[sqlitevec]` |
| `cost_backend=memory`       | `raggedy.cost.tracker.InMemoryCostTracker`     | — |
| `cost_backend=sqlite`       | `raggedy.cost.sqlite.SqliteCostTracker`        | `[sqlitevec]` |

The `SqliteCostTracker` uses an atomic `INSERT … ON CONFLICT DO UPDATE` to keep concurrent writers correct without an app-level lock.
