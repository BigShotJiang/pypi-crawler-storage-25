# Raggedy

Batteries-included, importable RAG core for Python apps.

```sh
pip install raggedy
```

Raggedy is a single library that gives a host app the full RAG flow: **chunk → embed → store → retrieve → cite → generate**, with PII redaction, cost tracking, and audit-run records turned on by default.

It's domain-neutral — designed to be dropped into any Python application that needs retrieval-augmented generation, whether for legal review, internal knowledge bases, customer support, or research pipelines.

## What's in the box

- **6 vector stores** — in-memory, SQLite-vec, pgvector, Qdrant, Chroma, Weaviate
- **4 LLM providers** — Anthropic, OpenAI, Ollama, LM Studio (OpenAI-compatible)
- **4 embedding backends** — deterministic (hashed BoW for tests), sentence-transformers (GPU-aware), OpenAI, Ollama
- **4 chunkers** — semantic, paragraph, sentence, fixed-window
- **Intake layer** — sources (files, directories, URLs, S3) → extractors (text, markdown, HTML, PDF, DOCX) → `Document`s
- **PII redaction** — 10 types, ephemeral redaction map (never persisted)
- **Cost tracking** — per-namespace daily limits, in-memory or SQLite
- **Audit-run records** — every query and ingest is logged with artifacts and tokens
- **No mock providers** — only real adapters, with skip-if-unavailable tests

## Design principles

- **Library, not service.** No HTTP server, no daemons. Your app stays in control.
- **Protocols over inheritance.** Every swappable piece is a `typing.Protocol` — bring your own implementation any time.
- **Async-first, sync shim.** All adapters are async; `Raggedy.query_sync(...)` and friends are convenience wrappers.
- **Domain-neutral.** `namespace: str` + `tags: dict[str, str]` — no `tenant_id`, no `matter_id`, no legal-specific concepts.
- **Honest about infrastructure.** No mock LLMs. Tests skip cleanly when a provider isn't reachable.

## Where to go next

- [Quickstart](quickstart.md) — install, configure, ingest, query
- [Concepts](concepts.md) — pipeline orchestration, protocols, run records
- [Adapters](adapters.md) — every store, embedder, LLM provider
- [Intake layer](intake.md) — sources and extractors for ingesting from the outside world
- [Configuration](configuration.md) — every `RaggedyConfig` field + env vars + YAML
- [API reference](api-reference.md) — the public surface
