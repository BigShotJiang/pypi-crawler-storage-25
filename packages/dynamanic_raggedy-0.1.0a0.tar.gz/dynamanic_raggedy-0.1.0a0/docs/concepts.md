# Concepts

## The pipeline

`RAGPipeline.query` is a 14-step orchestrator. Understanding it tells you exactly where each adapter slots in.

| Step | What happens | Protocol |
|------|--------------|----------|
| 1 | Validate the query string (empty → `ConfigError`) | — |
| 2 | `start_run` → returns `run_id` | `RunRecorder` |
| 3 | Pre-flight cost estimate | `LLMProvider.estimate_cost` |
| 4 | Cost gate — raises `CostLimitExceeded` if over budget | `CostTracker` |
| 5 | PII-redact the query, log redaction counts only | `PIIRedactor` |
| 6 | Embed the redacted query | `EmbeddingBackend` |
| 7 | Top-k retrieval, filtered by namespace + tags | `VectorStore` |
| 8 | Defense-in-depth: re-redact each retrieved chunk's text | `PIIRedactor` |
| 9 | Pack chunks into `[Source N]`-cited context (token-budgeted) | `LLMProvider.count_tokens` |
| 10 | Render versioned prompt template; log `prompt_render` artifact | — |
| 11 | LLM call (provider exceptions wrapped as `ProviderError`) | `LLMProvider` |
| 12 | Record actual cost & token usage | `CostTracker` |
| 13 | `finish_run` with status + cost + latency | `RunRecorder` |
| 14 | Return `QueryResult(answer, sources, run_id, cost_usd, …)` | — |

`ingest` mirrors steps 1, 2, 5, 6, then `store.upsert(chunks)` and `finish_run`. No cost gate on ingest (the embedding cost is recorded post-hoc).

## Protocols you can swap

Every dotted line in the pipeline is a `typing.Protocol`:

- `VectorStore` — `upsert`, `query`, `delete`, `count`
- `EmbeddingBackend` — `embed`, `embed_batch`, attrs `model_id`, `dimension`
- `LLMProvider` — `complete`, `count_tokens`, `estimate_cost`, `capabilities`
- `Chunker` — `chunk(document, *, namespace)`, attrs `strategy`, `target_tokens`, `overlap_tokens`
- `PIIRedactor` — `detect`, `redact`, attrs `policy_version`, `patterns_version`
- `CostTracker` — `check_limit`, `record_usage`, `get_daily_cost`
- `RunRecorder` — `start_run`, `record_artifact`, `finish_run`, `list`, `get`
- `Logger` / `EventSink` — observability hooks

Inject any of them directly:

```python
rag = Raggedy(config, store=MyCustomStore(), chunker=MyChunker())
```

Or register by name through the [config layer](configuration.md).

## Run records

Every `query()` and `ingest()` produces a `RunRecord` with:

- `run_id` — ULID, prefixed `run_`
- `namespace`, `kind` (`"query"` | `"ingest"`), `started_at`, `finished_at`, `status`
- `query` (the original text, redacted before LLM)
- `config_snapshot` — the `RaggedyConfig` at the moment the run started
- `artifacts` — list of `{kind, payload, ts}`:
    - `redaction_applied` — counts only, never the original PII
    - `retrieved_chunks` — chunk ids, scores, included-in-context flag
    - `prompt_render` — template version + character counts
- `cost_usd`, `prompt_tokens`, `completion_tokens`, `latency_ms`
- `tags` — anything passed at call time

Records persist in `InMemoryRunRecorder` (bounded deque) or `SqliteRunRecorder` (durable, queryable).

## Namespaces and tags

Raggedy uses one isolation primitive (`namespace`) plus one free-form filter (`tags`). No tenants, no matters, no nested groups. If you need finer slicing, encode it in tags:

```python
rag.query("...", namespace="acme", tags={"section": "policy", "lang": "en"})
```

Tag filtering is supported in every store — see [Adapters](adapters.md) for the per-backend details.

## PII redaction

`RegexPIIRedactor` covers 10 PII types: SSN, email, phone, DOB, address, credit card (Luhn-validated), IP address, passport, driver's license, bank account. The `RedactionResult.redaction_map` maps placeholders back to originals — **callers must never persist it**. Artifacts only carry counts.

Disable with `RaggedyConfig(redaction_enabled=False)` or swap in any object satisfying `PIIRedactor`.

## Cost tracking

`InMemoryCostTracker` accumulates a per-namespace daily total and enforces `cost_daily_limit_usd`. `SqliteCostTracker` persists and uses an atomic `INSERT … ON CONFLICT DO UPDATE` so concurrent writes never lose updates. Both raise `CostLimitExceeded` from `check_limit` — the gate runs *before* the LLM, so a blocked query costs nothing.

## Error contract

Every external call (provider SDK, HTTP, DB) is wrapped:

- `ProviderError(provider=..., retryable=...)` — embedding or LLM provider failure
- `ConfigError` — missing extras, invalid names, schema init failure
- `CostLimitExceeded` — pre-flight cost gate
- `NoMatchesFound` — only raised when `empty_retrieval_policy="raise"`

The run record always finalises — even on failure — with the appropriate `status` (`ok`, `cost_blocked`, `provider_error`, `no_matches`, `error`).
