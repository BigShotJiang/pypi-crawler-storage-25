# Changelog

All notable changes to Raggedy are documented here. The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] — 2026-05-19

Initial alpha release.

### Added

#### Core pipeline
- `Raggedy` facade and `RAGPipeline` async orchestrator (14-step flow: validate → start run → cost-gate → PII-redact → embed → retrieve → re-redact → pack → render prompt → LLM → record usage → finish run → return).
- Eight Protocols for full adapter swappability: `VectorStore`, `EmbeddingBackend`, `LLMProvider`, `Chunker`, `PIIRedactor`, `CostTracker`, `RunRecorder`, `Logger`/`EventSink`.
- Domain-neutral isolation: single `namespace: str` plus free-form `tags: dict[str, str]`. No tenant / matter / legal-specific concepts.
- `RaggedyConfig` (pydantic-settings) with `RAGGEDY_*` env prefix, `.env` auto-load via python-dotenv, and `from_yaml(path)` loader.

#### Vector stores
- `InMemoryStore` — numpy cosine, namespace + tag filter.
- `SqliteVecStore` (`[sqlitevec]`) — `sqlite-vec` extension, `distance_metric=cosine`, in-memory and file-backed.
- `PgVectorStore` (`[pgvector]`) — asyncpg + pgvector; JSONB tags with GIN index.
- `QdrantStore` (`[qdrant]`) — UUIDv5 from chunk id; supports embedded `:memory:` and HTTP/HTTPS endpoints.
- `ChromaStore` (`[chroma]`) — EphemeralClient / PersistentClient / HttpClient; primitive metadata flattening.
- `WeaviateStore` (`[weaviate]`) — v4 async client; PascalCase collection.

#### LLM providers
- `AnthropicProvider` (`[anthropic]`) — Claude 4.x family.
- `OpenAIProvider` (`[openai]`) — tiktoken-aware `count_tokens` when installed.
- `OllamaProvider` — uses base httpx; local zero-cost.
- LM Studio dispatched through `OpenAIProvider` against `LMSTUDIO_BASE_URL`.

#### Embedding backends
- `DeterministicEmbedder` — hashed bag-of-words (real algorithm, useful for tests).
- `SentenceTransformersEmbedder` (`[local]`) — GPU-aware via `detect_device()` (CUDA → MPS → CPU); honours `embedding_batch_size`.
- `OpenAIEmbedder` (`[openai]`).
- `OllamaEmbedder` — uses base httpx; batch `/api/embed` with single-shot fallback.

#### Chunkers
- `SemanticChunker` — paragraph + sentence boundaries, greedy merge, leading overlap, char-offset tracking.
- `ParagraphChunker` — one chunk per paragraph.
- `SentenceChunker` — sentence-level greedy merge.
- `FixedChunker` — fixed-window with word-boundary snap.

#### Intake layer
- Sources: `MemorySource`, `FileSource`, `DirectorySource`, `UrlSource` (base), `S3Source` (`[s3]`).
- Extractors: `PlainTextExtractor`, `HtmlExtractor` (stdlib only), `PdfExtractor` (`[pdf]`), `DocxExtractor` (`[docx]`).
- `IntakeRunner` orchestrates source → extractor → `Document`. `ExtractorRegistry` dispatches by `content_type`.
- `Raggedy.ingest_from(source)` one-liner with batching.

#### Batteries
- `RegexPIIRedactor` — 10 PII types (SSN, email, phone, DOB, address, credit-card with Luhn, IP, passport, driver's license, bank account). `RedactionResult.redaction_map` is in-memory only; never persisted.
- `InMemoryCostTracker` and `SqliteCostTracker` (atomic daily upsert via `INSERT … ON CONFLICT DO UPDATE`).
- `InMemoryRunRecorder` (bounded deque) and `SqliteRunRecorder` (FK-cascade artifacts, durable).
- Versioned RAG prompt templates pinned in every run record (`prompt_template_version`).

#### Tests, examples, docs
- 73+ tests; full-suite tests run offline; pgvector / Weaviate / live-LLM tests skip-if-unavailable.
- 6 worked examples (hello world, pgvector + Anthropic, local Ollama, custom chunker, intake directory, LM Studio GPU).
- mkdocs-material site (`docs/`).

### Design constraints
- No mock LLM providers ship with the library; tests use real providers with skip-if-unavailable.
- Async-first; sync shims via `asgiref.async_to_sync`.
- All external calls wrapped → `ProviderError` / `ConfigError`. Run record always finalises with the appropriate status on every code path.
