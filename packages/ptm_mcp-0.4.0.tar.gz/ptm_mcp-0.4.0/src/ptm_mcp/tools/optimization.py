"""Optimization read tools: status, history, detail.

Write-side optimization tools (submit/cancel/restart) land in Commit 3.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ._helpers import call_client_safely


def specs() -> list[tuple[Tool, Any]]:
    return [
        (_status_schema(), _status_handler),
        (_history_schema(), _history_handler),
        (_detail_schema(), _detail_handler),
    ]


# ----------------------------------------------------------------------
# get_optimization_status
# ----------------------------------------------------------------------


def _status_schema() -> Tool:
    return Tool(
        name="get_optimization_status",
        description="Return the current optimization status for a prompt (running/idle/etc).",
        inputSchema={
            "type": "object",
            "properties": {"prompt_id": {"type": "string"}},
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _status_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    return await call_client_safely(client.get_optimization_status, prompt_id)


# ----------------------------------------------------------------------
# get_optimization_history
# ----------------------------------------------------------------------


def _history_schema() -> Tool:
    return Tool(
        name="get_optimization_history",
        description="List past optimization runs for a prompt, newest first.",
        inputSchema={
            "type": "object",
            "properties": {"prompt_id": {"type": "string"}},
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _history_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    return await call_client_safely(client.get_optimization_history, prompt_id)


# ----------------------------------------------------------------------
# get_optimization_detail
# ----------------------------------------------------------------------


def _detail_schema() -> Tool:
    return Tool(
        name="get_optimization_detail",
        description=(
            "Fetch the full detail record for a single optimization run, including "
            "per-cycle scores, costs, and mutation reasoning."
        ),
        inputSchema={
            "type": "object",
            "properties": {"optimization_id": {"type": "string"}},
            "required": ["optimization_id"],
            "additionalProperties": False,
        },
    )


async def _detail_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    optimization_id = _require_str(arguments, "optimization_id")
    return await call_client_safely(client.get_optimization_detail, optimization_id)


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value
