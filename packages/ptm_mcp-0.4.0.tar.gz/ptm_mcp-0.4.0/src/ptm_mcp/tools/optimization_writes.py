"""Write tools for optimization: submit_optimization, cancel_optimization.

Both go through the read-only gate. ``submit_optimization`` exposes the full
parameter surface per plan + code-review-2 G1 (``min_improvement`` and
``max_cost_usd`` are load-bearing for the org-level plateau settings).
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient, PTMConflictError

from ..config import Settings
from ._helpers import call_client_safely
from ._writes import ensure_writes_allowed

_VISIBILITY_SCOPES = ("private_only", "org_visible", "group_visible")


def specs(settings: Settings) -> list[tuple[Tool, Any]]:
    return [
        (_submit_schema(), _make_submit_handler(settings)),
        (_cancel_schema(), _make_cancel_handler(settings)),
    ]


# ----------------------------------------------------------------------
# submit_optimization
# ----------------------------------------------------------------------


def _submit_schema() -> Tool:
    return Tool(
        name="submit_optimization",
        description=(
            "Queue an auto-optimization run for a library prompt. Evolves the prompt "
            "through evaluate -> analyze -> LLM-mutate cycles until target_score, "
            "max_cycles, max_cost_usd, or plateau. Phase 1 adds variance-aware "
            "sampling: stability_samples repeats the baseline N times per cycle "
            "and validation_samples repeats the mutated prompt M times before "
            "accepting/rejecting the mutation. Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
                "provider_profiles": {"type": "array", "items": {"type": "string"}},
                "judge_profile": {"type": ["string", "null"]},
                "max_cycles": {"type": "integer", "minimum": 1, "maximum": 50},
                "target_score": {"type": "number", "minimum": 0, "maximum": 100},
                "min_improvement": {"type": "number", "minimum": 0},
                "max_cost_usd": {"type": "number", "minimum": 0},
                "comparison_strategy": {"type": ["string", "null"]},
                "visibility_scope": {"type": "string", "enum": list(_VISIBILITY_SCOPES)},
                "stability_samples": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10,
                    "description": (
                        "Number of baseline evaluation runs per cycle. Higher "
                        "values reduce LLM-noise false wins at linear cost."
                    ),
                },
                "validation_samples": {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10,
                    "description": (
                        "Number of evaluation runs on a mutated prompt before "
                        "accepting or rejecting the mutation."
                    ),
                },
                "flakiness_threshold": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 1.0,
                    "description": (
                        "Maximum fractional widening of validation stddev over "
                        "baseline stddev before the mutation is rejected as a "
                        "variance regression (even if mean score improved)."
                    ),
                },
                "min_consistent_improvement": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 100.0,
                    "description": (
                        "Minimum mean-score gain (percentage points) required to keep a mutation."
                    ),
                },
                "variance_aware_mutator": {
                    "type": "boolean",
                    "description": (
                        "When true, the mutator receives per-case variance "
                        "classification so it targets deterministic failures "
                        "and ignores LLM flakiness."
                    ),
                },
                "variance_signal": {
                    "type": "string",
                    "enum": ["levenshtein", "embedding", "both"],
                    "description": (
                        "Signal used to classify per-case variance as prompt "
                        "ambiguity vs LLM flakiness."
                    ),
                },
                "enforce_target_score": {
                    "type": "boolean",
                    "description": (
                        "If true (default) the optimizer stops early once "
                        "target_score is reached; if false the run continues "
                        "to max_cycles (or cost cap / plateau) so the full "
                        "mutation history is preserved."
                    ),
                    "default": True,
                },
            },
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


def _make_submit_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = _require_str(arguments, "prompt_id")

        # Forward only keys the caller supplied so ptm-client defaults
        # (max_cycles=10, target_score=90, etc.) stay authoritative.
        kwargs: dict[str, Any] = {}
        for key in (
            "provider_profiles",
            "judge_profile",
            "max_cycles",
            "target_score",
            "min_improvement",
            "max_cost_usd",
            "comparison_strategy",
            "visibility_scope",
            "stability_samples",
            "validation_samples",
            "flakiness_threshold",
            "min_consistent_improvement",
            "variance_aware_mutator",
            "variance_signal",
            "enforce_target_score",
        ):
            if arguments.get(key) is not None:
                kwargs[key] = arguments[key]

        return await call_client_safely(client.submit_optimization, prompt_id, **kwargs)

    return _handler


# ----------------------------------------------------------------------
# cancel_optimization
# ----------------------------------------------------------------------


def _cancel_schema() -> Tool:
    return Tool(
        name="cancel_optimization",
        description=("Cancel a running optimization by id. Requires PTM_MCP_READ_ONLY=false."),
        inputSchema={
            "type": "object",
            "properties": {"optimization_id": {"type": "string"}},
            "required": ["optimization_id"],
            "additionalProperties": False,
        },
    )


def _make_cancel_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        optimization_id = _require_str(arguments, "optimization_id")
        try:
            return await call_client_safely(client.cancel_optimization, optimization_id)
        except ValueError as exc:
            # call_client_safely turns PTMConflictError into the generic
            # "repository-backed" ValueError. For cancel we prefer to surface
            # the server's machine-readable reason when present.
            cause = exc.__cause__
            if isinstance(cause, PTMConflictError):
                mapped = _map_cancel_conflict(cause)
                if mapped is not None:
                    raise ValueError(mapped) from cause
            raise

    return _handler


def _map_cancel_conflict(exc: PTMConflictError) -> str | None:
    """Format a 409 from ``cancel_optimization`` into an actionable string.

    Returns ``None`` if the server body does not carry a known ``reason``
    code - the caller should fall through to the generic mapping.
    """
    body = getattr(exc, "body", None)
    if not isinstance(body, dict):
        return None
    detail = body.get("detail")
    if not isinstance(detail, dict):
        return None
    reason = detail.get("reason")
    if reason == "already_terminal":
        terminal = detail.get("terminal_status") or "terminal"
        return f"Cannot cancel: optimization is already in state '{terminal}'. Nothing to cancel."
    if reason == "repository_backed":
        return "Cannot modify: prompt is repository-backed. Edit the files in git, not via the API."
    if reason == "write_race":
        return (
            "Write race: another client updated state between your read and "
            "write. Re-fetch and retry."
        )
    return None


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value
