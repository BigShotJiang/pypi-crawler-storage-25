"""`list_providers` canary tool.

Chosen as the Phase 2 Commit 1 end-to-end smoke target because the backend
endpoint is read-only, cheap, and exercised by the existing PTM CI matrix.
If this tool works over stdio, the middleware chokepoint is wired up for
every future tool.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient


def specs() -> list[tuple[Tool, Any]]:
    """Return (schema, handler) pairs for every tool exposed by this module."""
    return [(_list_providers_schema(), _list_providers_handler)]


def _list_providers_schema() -> Tool:
    return Tool(
        name="list_providers",
        description=(
            "List available provider profiles configured on the PTM backend. "
            "Returns one entry per profile with id, label, and capability flags."
        ),
        inputSchema={
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
    )


async def _list_providers_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    del arguments  # list_providers takes no input
    return client.list_providers()
