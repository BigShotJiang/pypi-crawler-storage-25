"""Run read tools: list_runs, get_run, get_run_report."""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ._helpers import call_client_safely

_REPORT_FORMATS = ("markdown", "html", "json", "csv")


def specs() -> list[tuple[Tool, Any]]:
    return [
        (_list_runs_schema(), _list_runs_handler),
        (_get_run_schema(), _get_run_handler),
        (_get_run_report_schema(), _get_run_report_handler),
    ]


# ----------------------------------------------------------------------
# list_runs
# ----------------------------------------------------------------------


def _list_runs_schema() -> Tool:
    return Tool(
        name="list_runs",
        description=(
            "List recent runs. All filters optional. Returns `{runs: [...], "
            "total_active_count: N}`."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "minimum": 1, "maximum": 500, "default": 50},
                "terminal_only": {
                    "type": "boolean",
                    "description": "Only include completed/failed/canceled runs.",
                },
                "mine_only": {
                    "type": "boolean",
                    "description": "Only include runs owned by the calling principal.",
                },
                "source": {
                    "type": "string",
                    "description": "e.g. 'ptm-mcp', 'manual', 'repository', 'optimization'.",
                },
                "prompt_id": {"type": "string"},
                "since": {
                    "type": "string",
                    "description": "ISO-8601 timestamp; only runs at or after this time.",
                },
            },
            "additionalProperties": False,
        },
    )


async def _list_runs_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    return await call_client_safely(
        client.list_runs,
        limit=int(arguments.get("limit") or 50),
        terminal_only=bool(arguments.get("terminal_only") or False),
        mine_only=bool(arguments.get("mine_only") or False),
        source=arguments.get("source"),
        prompt_id=arguments.get("prompt_id"),
        since=arguments.get("since"),
    )


# ----------------------------------------------------------------------
# get_run
# ----------------------------------------------------------------------


def _get_run_schema() -> Tool:
    return Tool(
        name="get_run",
        description="Fetch the current status of a run by run_key.",
        inputSchema={
            "type": "object",
            "properties": {"run_key": {"type": "string"}},
            "required": ["run_key"],
            "additionalProperties": False,
        },
    )


async def _get_run_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    run_key = _require_str(arguments, "run_key")
    return await call_client_safely(client.get_run, run_key)


# ----------------------------------------------------------------------
# get_run_report
# ----------------------------------------------------------------------


def _get_run_report_schema() -> Tool:
    return Tool(
        name="get_run_report",
        description=(
            "Fetch the rendered evaluation report for a completed run. "
            "Default format is 'markdown' because MCP clients render it inline. "
            "HTML is served as raw text here; Commit 3 exposes it as an MCP resource "
            "with proper MIME typing."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "run_key": {"type": "string"},
                "format": {
                    "type": "string",
                    "enum": list(_REPORT_FORMATS),
                    "default": "markdown",
                },
            },
            "required": ["run_key"],
            "additionalProperties": False,
        },
    )


async def _get_run_report_handler(client: PTMClient, arguments: dict[str, Any]) -> str:
    run_key = _require_str(arguments, "run_key")
    fmt = arguments.get("format") or "markdown"
    if fmt not in _REPORT_FORMATS:
        raise ValueError(f"'format' must be one of {list(_REPORT_FORMATS)}, got {fmt!r}")
    # run_report returns a str already. Returning the str causes the
    # aggregator to pass it through to TextContent verbatim.
    return await call_client_safely(client.run_report, run_key, format=fmt)


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value
