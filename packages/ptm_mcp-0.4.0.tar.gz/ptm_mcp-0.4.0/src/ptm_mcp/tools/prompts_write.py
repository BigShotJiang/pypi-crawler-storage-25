"""Library-mutation write tools (v0.2.0).

Unified ``update_prompt`` + admin-only share / group / transfer helpers.
Every handler goes through ``ensure_writes_allowed`` so they all register
with the MCP server but fail fast under ``PTM_MCP_READ_ONLY=true``. Backend
RBAC enforces per-prompt ownership, Phase 15 group membership, and admin
role on top of the PAT's scopes; ptm-mcp does NOT re-implement permission
logic - 403 / 404 / 409 / 422 responses are translated to actionable
LLM-facing messages via ``_helpers.call_client_safely``.
"""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ..config import Settings
from ._helpers import call_client_safely, require_int, require_str
from ._writes import ensure_writes_allowed

_CONTENT_FIELDS = (
    "name",
    "team",
    "service",
    "description",
    "tags",
    "prompt_text",
    "tests",
    "deepeval_metrics",
    "kpis",
    "provider_profiles",
    "judge_profile",
)


def specs(settings: Settings) -> list[tuple[Tool, Any]]:
    """Return (schema, handler) pairs for the library-mutation tools."""
    return [
        (_update_prompt_schema(), _make_update_prompt_handler(settings)),
        (_activate_prompt_version_schema(), _make_activate_version_handler(settings)),
        (_share_prompt_schema(), _make_share_handler(settings)),
        (_unshare_prompt_schema(), _make_unshare_handler(settings)),
        (_add_to_group_schema(), _make_add_to_group_handler(settings)),
        (_remove_from_group_schema(), _make_remove_from_group_handler(settings)),
        (_transfer_ownership_schema(), _make_transfer_handler(settings)),
    ]


# --- schemas --------------------------------------------------------------


def _update_prompt_schema() -> Tool:
    return Tool(
        name="update_prompt",
        description=(
            "Atomically update a library prompt. Send only the fields you want "
            "to change; others are left unchanged. Content fields (prompt_text, "
            "tests, deepeval_metrics, kpis, provider_profiles, judge_profile) "
            "auto-create a new version and set it active; metadata-only updates "
            "(name, team, service, description, tags) do not rev the version.\n\n"
            "Partial-update semantics: null/omitted = leave unchanged; `[]` = "
            "clear the list field; populated list = replace the list entirely. "
            "Do not use this tool for tests/metrics/KPIs unless you intend a "
            "full replacement of that list.\n\n"
            "`change_summary` is required (one-line 'why' for the audit log). "
            "prompt_text max 500,000 chars. Calling twice with the same payload "
            "is safe; the backend may still create a duplicate version row if "
            "content differs from the previous active version by even "
            "whitespace.\n\n"
            "RBAC: the caller must be the prompt owner OR hold a "
            "PROMPT_OVERWRITE role (admin / privileged). Requires "
            "PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "change_summary"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string", "description": "Prompt identifier."},
                "change_summary": {
                    "type": "string",
                    "maxLength": 500,
                    "description": "One-line explanation of the edit for the audit log.",
                },
                "name": {"type": ["string", "null"]},
                "team": {"type": ["string", "null"]},
                "service": {"type": ["string", "null"]},
                "description": {"type": ["string", "null"]},
                "tags": {
                    "type": ["array", "null"],
                    "items": {"type": "string"},
                    "description": "Full replacement of tags list. `[]` clears.",
                },
                "prompt_text": {
                    "type": ["string", "null"],
                    "maxLength": 500000,
                    "description": "New prompt template. Triggers a new version.",
                },
                "tests": {
                    "type": ["array", "null"],
                    "items": {"type": "object", "additionalProperties": True},
                    "description": (
                        "Full replacement of the promptfoo test list. Each item: "
                        "`{description, vars, assert?, expected_output?}`. `[]` clears all."
                    ),
                },
                "deepeval_metrics": {
                    "type": ["array", "null"],
                    "items": {"type": "object", "additionalProperties": True},
                    "description": (
                        "Full replacement of DeepEval judge criteria. Each item: "
                        "the DeepEval metric config shape (name, threshold, "
                        "criteria, etc.). `[]` clears all."
                    ),
                },
                "kpis": {
                    "type": ["array", "null"],
                    "items": {"type": "object", "additionalProperties": True},
                    "description": "Full replacement of KPI expressions. `[]` clears.",
                },
                "provider_profiles": {
                    "type": ["array", "null"],
                    "items": {"type": "string"},
                    "description": "Full replacement of default provider profile list.",
                },
                "judge_profile": {"type": ["string", "null"]},
                "set_active": {
                    "type": "boolean",
                    "default": True,
                    "description": (
                        "If content changes create a new version, make it active "
                        "(default). Set false to create without activating (preview)."
                    ),
                },
            },
        },
    )


def _activate_prompt_version_schema() -> Tool:
    return Tool(
        name="activate_prompt_version",
        description=(
            "Set a specific existing version as the active version of a library "
            "prompt. POST /api/v1/prompts/{id}/versions/{version_number}/activate. "
            "No content change, no new version row - this is the rollback / "
            "roll-forward path.\n\n"
            "RBAC: prompt owner OR PROMPT_OVERWRITE role (admin / privileged). "
            "Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "version_number"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "version_number": {"type": "integer", "minimum": 1},
            },
        },
    )


def _share_prompt_schema() -> Tool:
    return Tool(
        name="share_prompt",
        description=(
            "Move a prompt into the default org-visible group (org-wide share). "
            "**Requires admin or group_mgr role.** There is no per-user sharing "
            "mode; use `add_prompt_to_group` for fine-grained group access. "
            "Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
            },
        },
    )


def _unshare_prompt_schema() -> Tool:
    return Tool(
        name="unshare_prompt",
        description=(
            "Remove a prompt from a specific group. `group_id` is required "
            "(query parameter on the backend). **Requires admin or group_mgr "
            "role.** Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "group_id"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "group_id": {"type": "string"},
            },
        },
    )


def _add_to_group_schema() -> Tool:
    return Tool(
        name="add_prompt_to_group",
        description=(
            "Grant a specific group access to a prompt. `editable=true` lets "
            "group members edit the prompt; default is read-only access. "
            "**Requires admin or group_mgr of the target group.** Requires "
            "PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "group_id"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "group_id": {"type": "string"},
                "editable": {
                    "type": "boolean",
                    "default": False,
                    "description": "Group members can edit when true.",
                },
            },
        },
    )


def _remove_from_group_schema() -> Tool:
    return Tool(
        name="remove_prompt_from_group",
        description=(
            "Revoke a group's access to a prompt. **Requires admin or "
            "group_mgr role.** Requires PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "group_id"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "group_id": {"type": "string"},
            },
        },
    )


def _transfer_ownership_schema() -> Tool:
    return Tool(
        name="transfer_prompt_ownership",
        description=(
            "Transfer prompt ownership to another user. **ADMIN ONLY** (the "
            "current owner cannot self-transfer; admin intervention is "
            "required). Target user must exist and be active. Requires "
            "PTM_MCP_READ_ONLY=false."
        ),
        inputSchema={
            "type": "object",
            "required": ["prompt_id", "new_owner_id"],
            "additionalProperties": False,
            "properties": {
                "prompt_id": {"type": "string"},
                "new_owner_id": {
                    "type": "string",
                    "description": "User id of the new owner.",
                },
            },
        },
    )


# --- handlers -------------------------------------------------------------


def _make_update_prompt_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        change_summary = require_str(arguments, "change_summary")
        # Only forward fields the caller explicitly set. An explicit None
        # stays None (which ptm-client interprets as "leave unchanged"), so
        # callers must send `[]` explicitly to clear a list.
        optional: dict[str, Any] = {k: arguments[k] for k in _CONTENT_FIELDS if k in arguments}
        set_active = bool(arguments.get("set_active", True))
        return await call_client_safely(
            client.update_prompt,
            prompt_id,
            change_summary=change_summary,
            set_active=set_active,
            **optional,
        )

    return _handler


def _make_activate_version_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        version_number = require_int(arguments, "version_number")
        return await call_client_safely(client.activate_prompt_version, prompt_id, version_number)

    return _handler


def _make_share_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        return await call_client_safely(client.share_prompt, prompt_id)

    return _handler


def _make_unshare_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        group_id = require_str(arguments, "group_id")
        return await call_client_safely(client.unshare_prompt, prompt_id, group_id)

    return _handler


def _make_add_to_group_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        group_id = require_str(arguments, "group_id")
        editable = bool(arguments.get("editable", False))
        return await call_client_safely(
            client.add_prompt_to_group, prompt_id, group_id, editable=editable
        )

    return _handler


def _make_remove_from_group_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        group_id = require_str(arguments, "group_id")
        await call_client_safely(client.remove_prompt_from_group, prompt_id, group_id)
        return {"prompt_id": prompt_id, "group_id": group_id, "removed": True}

    return _handler


def _make_transfer_handler(settings: Settings):
    async def _handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
        ensure_writes_allowed(settings)
        prompt_id = require_str(arguments, "prompt_id")
        new_owner_id = require_str(arguments, "new_owner_id")
        return await call_client_safely(client.transfer_prompt_ownership, prompt_id, new_owner_id)

    return _handler
