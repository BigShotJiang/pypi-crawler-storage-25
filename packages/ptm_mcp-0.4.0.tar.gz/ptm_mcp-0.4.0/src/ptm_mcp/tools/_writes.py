"""Shared read-only gate for write tools.

Write tools (``run_manual_eval``, ``run_prompt_eval``, ``submit_optimization``,
``cancel_optimization``) always register so clients see them in ``list_tools``
and can surface a clean error instead of "unknown tool". The gate check fires
on the call-tool path when ``Settings.read_only`` is True.

``register_tools`` threads ``Settings`` through via a closure (see
``tools/__init__.py``) rather than a process-level singleton so the handler
contract stays explicit and testable.
"""

from __future__ import annotations

from ..config import Settings


def ensure_writes_allowed(settings: Settings) -> None:
    """Raise ``ValueError`` if read-only mode is active.

    The message points at the single env-var toggle so operators flipping
    it can verify they only need to change one thing. 0.2.0 added 10
    library-mutation tools, so the list is no longer enumerated in-line
    (see README tool inventory for the full 14 writes).
    """
    if settings.read_only:
        raise ValueError(
            "Read-only mode is enabled. Set PTM_MCP_READ_ONLY=false to allow "
            "write tools (eval submission, optimization, and library mutation). "
            "See the ptm-mcp README for the full inventory."
        )
