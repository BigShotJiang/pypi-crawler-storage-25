"""Prompt-version read tools: list, get, client-side compare."""

from __future__ import annotations

import difflib
from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ._helpers import call_client_safely


def specs() -> list[tuple[Tool, Any]]:
    return [
        (_list_prompt_versions_schema(), _list_prompt_versions_handler),
        (_get_prompt_version_schema(), _get_prompt_version_handler),
        (_compare_prompt_versions_schema(), _compare_prompt_versions_handler),
    ]


# ----------------------------------------------------------------------
# list_prompt_versions
# ----------------------------------------------------------------------


def _list_prompt_versions_schema() -> Tool:
    return Tool(
        name="list_prompt_versions",
        description="List every saved version of a prompt, newest first.",
        inputSchema={
            "type": "object",
            "properties": {"prompt_id": {"type": "string"}},
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _list_prompt_versions_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    return await call_client_safely(client.list_prompt_versions, prompt_id)


# ----------------------------------------------------------------------
# get_prompt_version
# ----------------------------------------------------------------------


def _get_prompt_version_schema() -> Tool:
    return Tool(
        name="get_prompt_version",
        description="Fetch one specific version of a prompt.",
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
                "version_number": {"type": "integer", "minimum": 1},
            },
            "required": ["prompt_id", "version_number"],
            "additionalProperties": False,
        },
    )


async def _get_prompt_version_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    version_number = _require_int(arguments, "version_number")
    return await call_client_safely(client.get_prompt_version, prompt_id, version_number)


# ----------------------------------------------------------------------
# compare_prompt_versions - client-side diff, no backend endpoint
# ----------------------------------------------------------------------


def _compare_prompt_versions_schema() -> Tool:
    return Tool(
        name="compare_prompt_versions",
        description=(
            "Compare two versions of a prompt. Returns a unified diff of the prompt "
            "text plus a small structural-delta summary for tests, metrics, KPIs, "
            "tags, provider profiles, and judge profile."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
                "version_a": {"type": "integer", "minimum": 1},
                "version_b": {"type": "integer", "minimum": 1},
            },
            "required": ["prompt_id", "version_a", "version_b"],
            "additionalProperties": False,
        },
    )


async def _compare_prompt_versions_handler(client: PTMClient, arguments: dict[str, Any]) -> str:
    prompt_id = _require_str(arguments, "prompt_id")
    va = _require_int(arguments, "version_a")
    vb = _require_int(arguments, "version_b")

    version_a = await call_client_safely(client.get_prompt_version, prompt_id, va)
    version_b = await call_client_safely(client.get_prompt_version, prompt_id, vb)

    text_a = str(version_a.get("prompt_text") or "")
    text_b = str(version_b.get("prompt_text") or "")

    diff_lines = list(
        difflib.unified_diff(
            text_a.splitlines(keepends=False),
            text_b.splitlines(keepends=False),
            fromfile=f"v{va}",
            tofile=f"v{vb}",
            lineterm="",
        )
    )
    diff_text = "\n".join(diff_lines) if diff_lines else "(no prompt_text changes)"

    summary = [
        f"=== Version {va} -> Version {vb} ===",
        diff_text,
        "",
        "=== Structural deltas ===",
        _count_delta("tests", version_a.get("tests_json"), version_b.get("tests_json")),
        _count_delta(
            "deepeval_metrics",
            version_a.get("deepeval_metrics_json"),
            version_b.get("deepeval_metrics_json"),
        ),
        _count_delta("kpis", version_a.get("kpis_json"), version_b.get("kpis_json")),
        _set_delta("tags", version_a.get("tags") or [], version_b.get("tags") or []),
        _set_delta(
            "provider_profiles",
            version_a.get("provider_profiles") or [],
            version_b.get("provider_profiles") or [],
        ),
        _scalar_delta(
            "judge_profile", version_a.get("judge_profile"), version_b.get("judge_profile")
        ),
    ]
    return "\n".join(summary)


def _count_delta(label: str, a: Any, b: Any) -> str:
    len_a = len(a) if isinstance(a, list | dict) else 0
    len_b = len(b) if isinstance(b, list | dict) else 0
    delta = len_b - len_a
    sign = "+" if delta >= 0 else ""
    return (
        f"{label}: {len_a} -> {len_b} ({sign}{delta}) "
        "(details elided; call get_prompt_version for full content)"
    )


def _set_delta(label: str, a: list, b: list) -> str:
    set_a = set(a)
    set_b = set(b)
    added = sorted(set_b - set_a)
    removed = sorted(set_a - set_b)
    return f"{label}: added {added}, removed {removed}"


def _scalar_delta(label: str, a: Any, b: Any) -> str:
    return f"{label}: {a!r} -> {b!r}"


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value


def _require_int(arguments: dict[str, Any], key: str) -> int:
    value = arguments.get(key)
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValueError(f"'{key}' is required and must be an integer")
    return value
