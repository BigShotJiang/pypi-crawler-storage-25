"""Prompt-library read tools: list_prompts, get_prompt, get_prompt_tests."""

from __future__ import annotations

from typing import Any

from mcp.types import Tool
from ptm_client import PTMClient

from ._helpers import call_client_safely


def specs() -> list[tuple[Tool, Any]]:
    return [
        (_list_prompts_schema(), _list_prompts_handler),
        (_get_prompt_schema(), _get_prompt_handler),
        (_get_prompt_tests_schema(), _get_prompt_tests_handler),
    ]


# ----------------------------------------------------------------------
# list_prompts
# ----------------------------------------------------------------------


def _list_prompts_schema() -> Tool:
    return Tool(
        name="list_prompts",
        description=(
            "List prompts in the PTM library. All filters are optional; pass only the "
            "ones you want to apply. Returns a list of prompt summaries."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "tag": {"type": "string", "description": "Filter by a single tag."},
                "team": {"type": "string", "description": "Filter by owning team."},
                "service": {"type": "string", "description": "Filter by service."},
                "source": {
                    "type": "string",
                    "description": "Filter by source (e.g. 'library', 'repository').",
                },
                "search": {"type": "string", "description": "Free-text search."},
                "group": {"type": "string", "description": "Filter by group name."},
            },
            "additionalProperties": False,
        },
    )


async def _list_prompts_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    return await call_client_safely(
        client.list_prompts,
        tag=arguments.get("tag"),
        team=arguments.get("team"),
        service=arguments.get("service"),
        source=arguments.get("source"),
        search=arguments.get("search"),
        group=arguments.get("group"),
    )


# ----------------------------------------------------------------------
# get_prompt
# ----------------------------------------------------------------------


def _get_prompt_schema() -> Tool:
    return Tool(
        name="get_prompt",
        description="Fetch a single prompt record by ID.",
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
            },
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _get_prompt_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    return await call_client_safely(client.get_prompt, prompt_id)


# ----------------------------------------------------------------------
# get_prompt_tests
# ----------------------------------------------------------------------


def _get_prompt_tests_schema() -> Tool:
    return Tool(
        name="get_prompt_tests",
        description="Return test cases and DeepEval metrics attached to a prompt.",
        inputSchema={
            "type": "object",
            "properties": {
                "prompt_id": {"type": "string"},
            },
            "required": ["prompt_id"],
            "additionalProperties": False,
        },
    )


async def _get_prompt_tests_handler(client: PTMClient, arguments: dict[str, Any]) -> Any:
    prompt_id = _require_str(arguments, "prompt_id")
    return await call_client_safely(client.get_prompt_tests, prompt_id)


def _require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value
