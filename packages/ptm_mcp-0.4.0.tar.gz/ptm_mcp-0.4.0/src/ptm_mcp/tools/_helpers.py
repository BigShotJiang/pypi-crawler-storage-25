"""Shared helpers for ptm-mcp tool handlers.

Centralizes the error-mapping pattern (PTMError -> ValueError) and the
output-serialization contract so every tool file stays focused on its
schema + argument handling.
"""

from __future__ import annotations

import inspect
from collections.abc import Callable
from typing import Any

from ptm_client import (
    PTMConflictError,
    PTMError,
    PTMNotFoundError,
    PTMPermissionError,
    PTMValidationError,
)


async def call_client_safely(fn: Callable[..., Any], /, *args: Any, **kwargs: Any) -> Any:
    """Invoke a ptm-client method, mapping ``PTMError`` to ``ValueError``.

    MCP clients surface ``ValueError`` from a tool handler as a tool-call
    error. Embedding the HTTP status code in the message keeps the error
    actionable without leaking internals.

    Accepts either sync or async callables so the same helper handles
    future async client shapes without a signature change.

    Specialized ``PTMError`` subclasses get actionable messages so LLM
    callers see a next step rather than an opaque HTTP status:
    - 403 (``PTMPermissionError``): ownership / admin / group_mgr role.
    - 404 (``PTMNotFoundError``): check the id + visibility scope.
    - 409 (``PTMConflictError``): repo-backed prompt or concurrent write.
    - 422 (``PTMValidationError``): field shape / size / type problem.
    """
    try:
        result = fn(*args, **kwargs)
        if inspect.isawaitable(result):
            result = await result
        return result
    except PTMPermissionError as exc:
        raise ValueError(
            "Permission denied. This operation requires prompt ownership or "
            "admin / group_mgr role. Check your PAT's user roles and verify "
            "you own the prompt. "
            f"Original: {exc}"
        ) from exc
    except PTMNotFoundError as exc:
        raise ValueError(
            "Prompt or resource not found. Verify prompt_id and that your "
            "PAT has visibility on it. "
            f"Original: {exc}"
        ) from exc
    except PTMConflictError as exc:
        raise ValueError(
            "Conflict. Either this is a repository-backed prompt (edit the "
            "files in git, not the API), or another writer changed state "
            "between your read and write. Re-fetch and retry. "
            f"Original: {exc}"
        ) from exc
    except PTMValidationError as exc:
        raise ValueError(
            "Validation failed. Common causes: prompt_text over 500,000 "
            "chars, malformed test / deepeval_metric dicts, unknown "
            "provider_profile name, or field type mismatch. "
            f"Original: {exc}"
        ) from exc
    except PTMError as exc:
        raise ValueError(f"PTM {exc.status_code}: {exc}") from exc


def require_str(arguments: dict[str, Any], key: str) -> str:
    value = arguments.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty string")
    return value


def require_non_empty_list(arguments: dict[str, Any], key: str) -> list:
    value = arguments.get(key)
    if not isinstance(value, list) or not value:
        raise ValueError(f"'{key}' is required and must be a non-empty list")
    return value


def require_dict(arguments: dict[str, Any], key: str) -> dict:
    value = arguments.get(key)
    if not isinstance(value, dict):
        raise ValueError(f"'{key}' is required and must be an object")
    return value


def require_int(arguments: dict[str, Any], key: str) -> int:
    value = arguments.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"'{key}' is required and must be an integer")
    return value
