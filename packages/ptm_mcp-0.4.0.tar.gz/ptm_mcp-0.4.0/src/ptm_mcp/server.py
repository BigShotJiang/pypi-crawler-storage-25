"""MCP server bootstrap.

Owns the startup sequence: scrub env, load settings, install logging,
run preflight, construct the ``PTMClient``, inject chokepoint headers,
register tools, and hand control to the stdio transport. Every side
effect is ordered so a failure surfaces before the client can issue a
tool call.
"""

from __future__ import annotations

import logging
import sys

from mcp.server import Server
from mcp.server.stdio import stdio_server
from ptm_client import PTMClient

from .config import load_settings
from .env import scrub_env
from .headers import install_client_headers, new_session_id
from .resources import register_resources
from .startup import StartupError, run_preflight
from .tools import register_tools


async def run() -> int:
    """Boot ptm-mcp and serve tools over stdio. Returns process exit code."""
    scrub_env()
    settings = load_settings()
    logging.basicConfig(
        stream=sys.stderr,
        level=settings.log_level,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )
    logger = logging.getLogger("ptm_mcp.server")

    session_id = new_session_id()
    client = PTMClient(
        base_url=settings.ptm_api_base_url,
        token=settings.ptm_api_token,
        timeout=settings.timeout_seconds,
    )
    # Merge the chokepoint headers onto PTMClient's existing bearer-auth
    # dict. v0.3.0 exposes `_headers` as a plain dict; see headers.py.
    install_client_headers(client, session_id)

    try:
        report = run_preflight(client, settings)
    except StartupError as exc:
        # Log + return the layer-specific code; __main__'s generic handler
        # would collapse every preflight failure to exit 1.
        logger.error("[ptm-mcp] preflight failed (exit %d): %s", exc.exit_code, exc)
        return exc.exit_code
    logger.info(
        "[ptm-mcp] startup ok: backend=%s token_kind=%s session=%s",
        report.backend_version,
        report.token_kind,
        session_id[:8],
    )

    server: Server = Server("ptm-mcp")
    register_tools(server, client, settings)
    register_resources(server, client)

    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())
    return 0
