"""Startup env-var scrubber.

ptm-mcp inherits the full environment of the MCP client (Claude Desktop,
Goose, etc.), which typically contains cloud credentials, GitHub tokens,
and similar secrets unrelated to PTM. The stdio server does not subprocess
anything, so it has no legitimate use for most of those. We drop everything
outside a narrow allow-list at startup to shrink the blast radius if the
process is ever compromised.
"""

from __future__ import annotations

import logging
import os

logger = logging.getLogger("ptm_mcp.env")


# ``PATH`` is in the allow-list as of v0.2.0: ptm-client's Cloudflare Access
# auto-discovery (added in 0.3.2 / rolled into 0.4.0) shells out to
# ``cloudflared access token`` via ``shutil.which``, which needs PATH to
# resolve the binary. The documented subprocess caller referenced in
# ~/dev/docs/code-review-1.md item C1 is now ptm-client's
# ``_cloudflared_access_token``.
_ALLOWED_PREFIXES = ("PTM_", "LC_")
_ALLOWED_EXACT = frozenset(
    {
        "HOME",
        "USER",
        "LANG",
        "TZ",
        "TERM",
        "PATH",
        "PYTHONPATH",
        "PYTHONUNBUFFERED",
        "SSL_CERT_FILE",
        "REQUESTS_CA_BUNDLE",
        "CF_ACCESS_CLIENT_ID",
        "CF_ACCESS_CLIENT_SECRET",
        "CF_ACCESS_JWT",
    }
)


def scrub_env() -> int:
    """Remove env vars outside the allow-list. Returns count dropped."""
    dropped: list[str] = []
    for key in list(os.environ):
        if key in _ALLOWED_EXACT:
            continue
        if any(key.startswith(p) for p in _ALLOWED_PREFIXES):
            continue
        dropped.append(key)
        del os.environ[key]
    if dropped:
        logger.info(
            "[ptm-mcp] Scrubbed %d env vars at startup. Kept %d.",
            len(dropped),
            len(os.environ),
        )
    return len(dropped)
