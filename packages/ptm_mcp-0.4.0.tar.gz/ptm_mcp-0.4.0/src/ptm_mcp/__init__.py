"""ptm-mcp: MCP stdio server for the Prompt Test Manager API."""

__version__ = "0.4.0"

__all__ = ["__version__"]
