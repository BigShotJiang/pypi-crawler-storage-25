"""``ptm-mcp doctor`` - preflight diagnostics without entering the MCP loop.

Reads the same env vars as the server (``PTM_API_BASE_URL``, ``PTM_API_TOKEN``,
CF Access vars). Token is optional; CF path and ``/healthz`` run without it.

Exit codes:
  0  - all checks passed.
  10 - env vars missing / malformed.
  11 - cloudflared binary missing.
  12 - cloudflared session missing (run ``cloudflared access login``).
  13 - API probe failed (healthz / auth / meta).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from collections.abc import Callable
from dataclasses import dataclass

from ptm_client import PTMClient
from ptm_client.errors import CloudflareAccessError, PTMError

from .config import ConfigError, load_settings
from .headers import install_client_headers, new_session_id

EXIT_OK = 0
EXIT_CONFIG = 10
EXIT_CLOUDFLARED_MISSING = 11
EXIT_CLOUDFLARED_NO_SESSION = 12
EXIT_API_FAILED = 13

_CF_UNABLE_PREFIX = "Unable to find"
_CLOUDFLARED_TIMEOUT_SECONDS = 5

_PASS = "[PASS]"
_FAIL = "[FAIL]"
_WARN = "[WARN]"
_SKIP = "[SKIP]"


@dataclass
class StepResult:
    ok: bool
    label: str
    detail: str = ""
    remediation: str = ""
    skipped: bool = False


def _emit(result: StepResult, out: Callable[[str], None]) -> None:
    tag = _SKIP if result.skipped else (_PASS if result.ok else _FAIL)
    out(f"{tag} {result.label}")
    if result.detail:
        out(f"       {result.detail}")
    if not result.ok and not result.skipped and result.remediation:
        for line in result.remediation.splitlines():
            out(f"       -> {line}")


def check_cloudflared_installed() -> StepResult:
    path = shutil.which("cloudflared")
    if path:
        return StepResult(ok=True, label="cloudflared installed", detail=path)
    return StepResult(
        ok=False,
        label="cloudflared installed",
        detail="binary not found on PATH",
        remediation=(
            "Install cloudflared, then retry:\n"
            "  macOS:   brew install cloudflared\n"
            "  Linux:   see https://pkg.cloudflare.com/index.html\n"
            "  Windows: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/"
        ),
    )


def check_cloudflared_session(base_url: str) -> StepResult:
    """Pass if ``cloudflared access token -app=<base_url>`` emits a non-empty
    token not prefixed with the "Unable to find" miss string."""
    try:
        result = subprocess.run(
            ["cloudflared", "access", "token", f"-app={base_url}"],
            capture_output=True,
            text=True,
            timeout=_CLOUDFLARED_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired:
        return StepResult(
            ok=False,
            label="cloudflared session cached",
            detail=f"timed out after {_CLOUDFLARED_TIMEOUT_SECONDS}s",
            remediation=("cloudflared hung. Try killing stuck cloudflared processes and retry."),
        )
    except (FileNotFoundError, PermissionError, OSError) as exc:
        return StepResult(
            ok=False,
            label="cloudflared session cached",
            detail=f"exec failed: {exc}",
        )
    token = (result.stdout or "").strip()
    if not token or token.startswith(_CF_UNABLE_PREFIX):
        return StepResult(
            ok=False,
            label="cloudflared session cached",
            detail="no cached token for this app",
            remediation=(
                "Run once in a normal terminal (opens a browser):\n"
                f"  cloudflared access login {base_url}"
            ),
        )
    return StepResult(
        ok=True,
        label="cloudflared session cached",
        detail=f"token len={len(token)}",
    )


def _run_client_probe(client: PTMClient, path: str, label: str, remediation: str) -> StepResult:
    try:
        client._get(path)  # type: ignore[attr-defined]
        return StepResult(ok=True, label=label, detail=f"GET {path}")
    except CloudflareAccessError as exc:
        return StepResult(
            ok=False,
            label=label,
            detail=f"CF Access blocked (status {exc.status_code})",
            remediation=str(exc),
        )
    except PTMError as exc:
        return StepResult(
            ok=False,
            label=label,
            detail=f"{exc}",
            remediation=remediation,
        )


def check_healthz(client: PTMClient) -> StepResult:
    """Probe /healthz. CF blocks surface ptm-client's differentiated
    CloudflareAccessError remediation verbatim via ``_run_client_probe``."""
    return _run_client_probe(
        client,
        "/healthz",
        "backend /healthz reachable",
        "Backend may be down, URL may be wrong, or network path blocked.",
    )


def check_auth_me(client: PTMClient) -> StepResult:
    res = _run_client_probe(
        client,
        "/api/v1/auth/me",
        "PTM token valid",
        "Check PTM_API_TOKEN is current; it may be expired or revoked.",
    )
    if res.ok:
        try:
            me = client._get("/api/v1/auth/me")  # type: ignore[attr-defined]
            kind = (me or {}).get("token_kind") or "unknown"
            expires = (me or {}).get("token_expires_at") or "never"
            res.detail = f"token_kind={kind} expires={expires}"
        except Exception:  # noqa: BLE001 - informational only
            pass
    return res


def check_meta(client: PTMClient) -> StepResult:
    res = _run_client_probe(
        client,
        "/api/v1/meta",
        "backend version",
        "Upgrade the backend or check /meta wiring.",
    )
    if res.ok:
        try:
            meta = client._get("/api/v1/meta")  # type: ignore[attr-defined]
            res.detail = f"version={(meta or {}).get('version') or 'unknown'}"
        except Exception:  # noqa: BLE001 - informational only
            pass
    return res


def run(out: Callable[[str], None] = print) -> int:
    """Run the doctor diagnostic. Returns a process exit code."""
    out("ptm-mcp doctor")
    out("=" * 60)

    base = os.environ.get("PTM_API_BASE_URL", "").strip()
    token = os.environ.get("PTM_API_TOKEN", "").strip()
    if not base:
        out(f"{_FAIL} PTM_API_BASE_URL")
        out("       required env var not set")
        out("       -> export PTM_API_BASE_URL=https://ptm-api.example.com")
        return EXIT_CONFIG
    out(f"{_PASS} PTM_API_BASE_URL     {base}")

    if token:
        kind_hint = "service-account" if token.startswith("ptm_sa_") else "user-PAT-or-other"
        out(f"{_PASS} PTM_API_TOKEN        set (prefix={token[:6]}..., kind hint={kind_hint})")
    else:
        out(f"{_WARN} PTM_API_TOKEN        not set - will skip /auth/me and /meta checks")

    cf_sa = bool(
        os.environ.get("CF_ACCESS_CLIENT_ID") and os.environ.get("CF_ACCESS_CLIENT_SECRET")
    )
    cf_jwt = bool(os.environ.get("CF_ACCESS_JWT"))
    if cf_sa:
        out(f"{_PASS} CF_ACCESS service-token set (CLIENT_ID + CLIENT_SECRET present)")
    elif cf_jwt:
        out(f"{_PASS} CF_ACCESS_JWT        set (explicit JWT, auto-discovery skipped)")
    else:
        out(f"{_WARN} CF_ACCESS env vars   none set - relying on cloudflared auto-discovery")

    out("-" * 60)

    # load_settings requires a token; use a placeholder when absent so the
    # anonymous /healthz probe can still run.
    try:
        settings = load_settings() if token else None
    except ConfigError as exc:
        out(f"{_FAIL} load_settings         {exc}")
        return EXIT_CONFIG

    client = PTMClient(
        base_url=base,
        token=token or "doctor-placeholder",
        timeout=(settings.timeout_seconds if settings else 15),
    )
    install_client_headers(client, new_session_id())

    # /healthz is ground truth: success means CF is happy and cloudflared
    # checks are unneeded. Prevents misdiagnosing localhost / direct-access
    # deploys as "missing cloudflared session".
    r = check_healthz(client)
    _emit(r, out)
    if r.ok:
        _emit(
            StepResult(
                ok=True,
                skipped=True,
                label="cloudflared checks",
                detail=("skipped: /healthz succeeded, no CF Access challenge to resolve"),
            ),
            out,
        )
    else:
        # CF-blocked: walk cloudflared setup. Non-CF: plain backend/network fail.
        detail = r.detail or ""
        remediation = r.remediation or ""
        is_cf_block = "Cloudflare Access" in detail or "Cloudflare Access" in remediation
        if not is_cf_block:
            return EXIT_API_FAILED
        if cf_sa or cf_jwt:
            # Explicit CF creds still blocked -> wrong env or policy mismatch.
            # cloudflared cannot help.
            return EXIT_API_FAILED
        rc = check_cloudflared_installed()
        _emit(rc, out)
        if not rc.ok:
            return EXIT_CLOUDFLARED_MISSING
        rs = check_cloudflared_session(base)
        _emit(rs, out)
        if not rs.ok:
            return EXIT_CLOUDFLARED_NO_SESSION
        # Session cached but still blocked -> post-JWT block (WARP / group /
        # service-token-only policy). r.remediation enumerates causes.
        return EXIT_API_FAILED

    if not token:
        _emit(
            StepResult(
                ok=True,
                skipped=True,
                label="PTM token checks",
                detail="skipped: PTM_API_TOKEN not set",
            ),
            out,
        )
        out("-" * 60)
        out("Doctor: CF path OK. Set PTM_API_TOKEN and re-run for full verdict.")
        return EXIT_OK

    r = check_auth_me(client)
    _emit(r, out)
    if not r.ok:
        return EXIT_API_FAILED

    r = check_meta(client)
    _emit(r, out)
    if not r.ok:
        return EXIT_API_FAILED

    out("-" * 60)
    out("Doctor: all checks passed. ptm-mcp should start cleanly.")
    return EXIT_OK


def main() -> int:
    return run(out=lambda s: print(s, file=sys.stdout, flush=True))
