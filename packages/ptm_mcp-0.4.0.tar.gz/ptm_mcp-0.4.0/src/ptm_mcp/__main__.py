"""CLI entry point (``python -m ptm_mcp`` / ``ptm-mcp``).

Subcommands: ``doctor`` runs diagnostics and exits; no arg starts stdio server.
"""

from __future__ import annotations

import sys


def main() -> int:
    import asyncio
    import logging

    argv = sys.argv[1:]
    if argv and argv[0] == "doctor":
        from .doctor import main as doctor_main

        return doctor_main()

    from .server import run

    try:
        return asyncio.run(run())
    except KeyboardInterrupt:
        return 130
    except Exception as exc:  # noqa: BLE001 - top-level boundary
        logging.getLogger("ptm_mcp").exception("fatal: %s", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
