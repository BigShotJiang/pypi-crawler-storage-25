"""MCP resource registration.

Exposes PTM data as addressable MCP resources so MCP clients can surface
them inline (Claude Desktop's @-mention flow, Goose's resource browser).

URI patterns (see ``_URI_TEMPLATES`` below for the authoritative list):

- ``ptm://prompts/{prompt_id}`` -> active version's ``prompt_text`` (text/plain)
- ``ptm://prompts/{prompt_id}/v{N}`` -> that version's ``prompt_text`` (text/plain)
- ``ptm://runs/{run_key}/report.md`` -> ``run_report(key, format="markdown")``
- ``ptm://runs/{run_key}/report.html`` -> ``run_report(key, format="html")``
- ``ptm://optimizations/{id}/report.md`` -> built from ``get_optimization_detail``

Every dynamic URI segment is passed through ``validate_uri_component`` so
path-traversal sequences (``..``, URL-encoded slashes, quoted tokens) never
reach the backend. See ``docs/mcp-ptm-phase1.md`` section 12.
"""

from __future__ import annotations

import re
from typing import Any

from mcp.server import Server
from mcp.server.lowlevel.helper_types import ReadResourceContents
from mcp.types import ResourceTemplate
from ptm_client import PTMClient

from .tools._helpers import call_client_safely

_SEGMENT_RE = re.compile(r"^[a-zA-Z0-9_.-]+$")

_URI_TEMPLATES = (
    (
        "ptm://prompts/{prompt_id}",
        "prompt",
        "Active version's prompt_text for a library prompt.",
        "text/plain",
    ),
    (
        "ptm://prompts/{prompt_id}/v{version_number}",
        "prompt_version",
        "A specific version's prompt_text.",
        "text/plain",
    ),
    (
        "ptm://runs/{run_key}/report.md",
        "run_report_markdown",
        "Evaluation report for a completed run, markdown.",
        "text/markdown",
    ),
    (
        "ptm://runs/{run_key}/report.html",
        "run_report_html",
        "Evaluation report for a completed run, HTML.",
        "text/html",
    ),
    (
        "ptm://optimizations/{optimization_id}/report.md",
        "optimization_report_markdown",
        "Markdown summary built from optimization detail JSON.",
        "text/markdown",
    ),
)


# ----------------------------------------------------------------------
# URI validation
# ----------------------------------------------------------------------


def validate_uri_component(value: str, *, label: str) -> str:
    """Reject anything outside ``[A-Za-z0-9_.-]`` plus the dot-only cases.

    ``.`` and ``..`` pass the regex (dots are allowed inside tokens), so
    they are rejected explicitly to close the path-traversal vector.
    Prevents URL-encoded escapes, embedded protocol separators, and
    relative-path segments from reaching the ptm-client methods.
    """
    if not isinstance(value, str) or not value or not _SEGMENT_RE.fullmatch(value):
        raise ValueError(f"Invalid {label}: {value!r}")
    if value in (".", ".."):
        raise ValueError(f"Invalid {label}: {value!r}")
    return value


def _coerce_version(raw: str) -> int:
    """Convert the validated ``v{N}`` segment to a positive int."""
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid version_number: {raw!r}") from exc
    if value < 1:
        raise ValueError(f"Invalid version_number: {raw!r} (must be >= 1)")
    return value


# ----------------------------------------------------------------------
# URI resolution
# ----------------------------------------------------------------------


_PROMPT_URI = re.compile(r"^ptm://prompts/(?P<prompt_id>[^/]+)$")
_PROMPT_VERSION_URI = re.compile(r"^ptm://prompts/(?P<prompt_id>[^/]+)/v(?P<version>[^/]+)$")
_RUN_REPORT_URI = re.compile(r"^ptm://runs/(?P<run_key>[^/]+)/report\.(?P<ext>md|html)$")
_OPT_REPORT_URI = re.compile(r"^ptm://optimizations/(?P<opt_id>[^/]+)/report\.md$")


async def resolve_resource(uri: str, client: PTMClient) -> ReadResourceContents:
    """Dispatch a ``ptm://`` URI to the appropriate ptm-client call.

    Unknown URIs raise ``ValueError`` (surfaced by the MCP SDK as an error
    response). The 5 known patterns each validate their dynamic segments
    before touching the client.
    """
    m = _PROMPT_URI.match(uri)
    if m:
        prompt_id = validate_uri_component(m.group("prompt_id"), label="prompt_id")
        prompt = await call_client_safely(client.get_prompt, prompt_id)
        return ReadResourceContents(
            content=str(prompt.get("prompt_text") or ""),
            mime_type="text/plain",
        )

    m = _PROMPT_VERSION_URI.match(uri)
    if m:
        prompt_id = validate_uri_component(m.group("prompt_id"), label="prompt_id")
        raw_version = validate_uri_component(m.group("version"), label="version_number")
        version_number = _coerce_version(raw_version)
        payload = await call_client_safely(client.get_prompt_version, prompt_id, version_number)
        return ReadResourceContents(
            content=str(payload.get("prompt_text") or ""),
            mime_type="text/plain",
        )

    m = _RUN_REPORT_URI.match(uri)
    if m:
        run_key = validate_uri_component(m.group("run_key"), label="run_key")
        ext = m.group("ext")
        fmt = "markdown" if ext == "md" else "html"
        body = await call_client_safely(client.run_report, run_key, format=fmt)
        return ReadResourceContents(
            content=str(body),
            mime_type="text/markdown" if ext == "md" else "text/html",
        )

    m = _OPT_REPORT_URI.match(uri)
    if m:
        optimization_id = validate_uri_component(m.group("opt_id"), label="optimization_id")
        detail = await call_client_safely(client.get_optimization_detail, optimization_id)
        return ReadResourceContents(
            content=_render_optimization_report(optimization_id, detail),
            mime_type="text/markdown",
        )

    raise ValueError(f"Unsupported resource URI: {uri!r}")


def _render_optimization_report(optimization_id: str, detail: dict[str, Any]) -> str:
    """Render a compact markdown summary from the JSON detail payload."""
    status = detail.get("status", "unknown")
    best_score = detail.get("best_score")
    baseline = detail.get("baseline_score")
    total_cost = detail.get("total_cost_usd")
    cycles = detail.get("cycles") or []

    lines = [
        f"# Optimization {optimization_id}",
        "",
        f"- Status: {status}",
        f"- Baseline score: {baseline}",
        f"- Best score: {best_score}",
        f"- Total cost USD: {total_cost}",
        f"- Cycles recorded: {len(cycles)}",
        "",
        "## Cycles",
        "",
        "| # | kept | score | score_delta | cost_usd |",
        "|---|------|-------|-------------|----------|",
    ]
    for cycle in cycles[:50]:  # hard-cap; full data lives in get_optimization_detail
        lines.append(
            "| {n} | {kept} | {score} | {delta} | {cost} |".format(
                n=cycle.get("cycle_number"),
                kept=cycle.get("kept"),
                score=cycle.get("score"),
                delta=cycle.get("score_delta"),
                cost=cycle.get("cost_usd"),
            )
        )
    if len(cycles) > 50:
        lines.append(f"\n(truncated - {len(cycles) - 50} more cycles in detail JSON)")
    return "\n".join(lines)


# ----------------------------------------------------------------------
# Server wiring
# ----------------------------------------------------------------------


def register_resources(server: Server, client: PTMClient) -> None:
    """Register resource templates + the read-resource dispatcher."""
    templates = [
        ResourceTemplate(
            uriTemplate=uri,
            name=name,
            description=description,
            mimeType=mime,
        )
        for uri, name, description, mime in _URI_TEMPLATES
    ]

    @server.list_resource_templates()
    async def _list_templates() -> list[ResourceTemplate]:
        return templates

    @server.read_resource()
    async def _read(uri):  # uri is AnyUrl; str() on it yields the canonical string
        return [await resolve_resource(str(uri), client)]
