"""MCP chokepoint signal headers.

The PTM backend middleware (``@app.middleware("http")``) reads
``X-PTM-Client`` to classify incoming requests as MCP-tagged and
``X-PTM-MCP-Session`` to correlate the whole agent conversation with
rows in ``mcp_usage`` and ``RunRecord.mcp_session_id``. See
``docs/mcp-ptm-phase1.md`` sections 18.1 and 18.6.
"""

from __future__ import annotations

from uuid import uuid4

from . import __version__


def new_session_id() -> str:
    """UUID for the lifetime of one ptm-mcp server process.

    Attached to every outbound HTTP call as ``X-PTM-MCP-Session``. The
    backend correlates this with ``mcp_usage`` and ``RunRecord.mcp_session_id``
    for forensic replay of an agent conversation.
    """
    return str(uuid4())


def build_client_headers(session_id: str) -> dict[str, str]:
    """Return the MCP-chokepoint signal headers the backend middleware reads."""
    return {
        "X-PTM-Client": f"ptm-mcp/{__version__}",
        "X-PTM-MCP-Session": session_id,
    }


def install_client_headers(client, session_id: str) -> None:
    """Merge MCP headers onto an existing ``PTMClient``.

    v0.3.0 exposes ``client._headers`` as a plain dict; mutating it is the
    simplest path that does not fork the client. If a future release hides
    the dict, this helper becomes the single place to adapt.
    """
    headers = getattr(client, "_headers", None)
    if headers is None or not isinstance(headers, dict):
        raise RuntimeError(
            "PTMClient does not expose a mutable _headers dict; update ptm-mcp to "
            "match the current ptm-client shape."
        )
    headers.update(build_client_headers(session_id))
