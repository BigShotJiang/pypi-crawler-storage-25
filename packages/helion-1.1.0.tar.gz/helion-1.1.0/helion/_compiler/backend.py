from __future__ import annotations

import abc
import ast
import functools
from itertools import starmap
import math
import operator
import os
import re
from typing import TYPE_CHECKING
from typing import Any
from typing import Callable
from typing import ClassVar
from typing import Sequence

import sympy
import torch

from .. import exc
from .ast_extension import expr_from_string
from .cute.tcgen05_constants import TCGEN05_CUBIN_LINEINFO_CONFIG_KEY

if TYPE_CHECKING:
    from torch._inductor.ops_handler import OpsHandler

    from ..autotuner.config_fragment import ConfigSpecFragment
    from ..runtime.config import Config
    from ..runtime.kernel import BoundKernel
    from .device_function import Argument
    from .device_function import DeviceFunction
    from .device_ir import GraphInfo
    from .tile_dispatch import TileStrategyDispatch
    from .tile_strategy import TileStrategy

    InductorOpOverrides = OpsHandler[Any]


@functools.cache
def _triton_jit_supports_do_not_specialize() -> bool:
    try:
        import inspect

        import triton
    except ImportError:
        return False

    params = inspect.signature(triton.jit).parameters
    return "do_not_specialize" in params and "do_not_specialize_on_alignment" in params


class Backend(abc.ABC):
    """Abstract base class for Helion code generation backends.

    Each backend is responsible for defining:
    - How types are represented in generated code
    - What imports are needed in generated code
    - What decorators and annotations are used on generated functions
    """

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Backend name used for codegen dispatch (e.g., 'triton')."""
        ...

    @property
    def experimental(self) -> bool:
        """Whether this backend is experimental and should emit a warning."""
        return True

    @property
    def max_tensor_numel(self) -> int | None:
        """Per-tile maximum tensor element count enforced during config search.

        Triton has a hard internal ceiling (currently 2**20) past which its
        codegen rejects the kernel, so the search must avoid generating
        configs that exceed it. Pallas/Mosaic has no analogous compile-time
        cap; tile size is bounded by VMEM bytes (already guarded at runtime
        in :mod:`helion.runtime`). Backends that don't need the cap should
        return ``None`` to disable the constraint.
        """
        from ..autotuner.config_generation import TRITON_MAX_TENSOR_NUMEL

        return TRITON_MAX_TENSOR_NUMEL

    @property
    def pad_factory_tensors_to_power_of_2(self) -> bool:
        """Whether on-device tensor factory ops (zeros/ones/empty/full/...) should
        have their integer dim sizes rounded up to the next power of 2.

        Triton requires power-of-2 block sizes, so the default is True. Pallas
        does not require this and the padding causes broadcast mismatches
        against unpadded full-tensor loads.
        """
        return True

    @property
    def codegen_name(self) -> str:
        """Backend name used to look up registered codegen functions."""
        return self.name

    @abc.abstractmethod
    def dtype_str(self, dtype: torch.dtype) -> str:
        """Convert a torch dtype to a backend-specific type string.

        For example, Triton returns 'tl.float32' for torch.float32.
        """
        ...

    @abc.abstractmethod
    def acc_type(self, dtype: torch.dtype) -> str:
        """Get the accumulator type string for reductions.

        Some backends may promote certain types for numerical stability
        during reductions (e.g., fp16 -> fp32).
        """
        ...

    def index_type_str(self, index_dtype: torch.dtype) -> str:
        """Get the index type string for the given dtype.

        Defaults to dtype_str, but backends may override for special handling.
        """
        return self.dtype_str(index_dtype)

    def program_id_expr(self, dim: int, *, index_dtype: str) -> str:
        raise exc.BackendUnsupported(self.name, "program IDs")

    def cdiv_expr(self, numel: str, block_size: str, *, is_device: bool) -> str:
        return f"(({numel}) + ({block_size}) - 1) // ({block_size})"

    def cast_expr(self, expr_str: str, dtype_str: str) -> str:
        """Generate a backend-specific type cast expression."""
        raise exc.BackendUnsupported(self.name, "cast")

    def sympy_printer_expr(self, expr: sympy.Expr) -> str:
        """Render a SymPy expression for this backend's device code."""
        from .device_function import texpr

        return texpr(expr)

    @property
    def range_requires_python_int(self) -> bool:
        """Whether range bounds must be plain Python ints (not traced values).

        When True, the codegen will skip dtype casts on range end/step
        expressions so that ``range()`` receives concrete Python integers
        instead of backend-traced values.
        """
        return False

    def range_str(
        self,
        begin: str | None,
        end: str,
        step: str | None,
    ) -> str | None:
        """Generate a backend-specific range expression, or None to use the default."""
        return None

    def arange_expr(
        self,
        offsets_var: str,
        lid: str,
        block_size_var: str,
        dtype: str,
        *,
        axis: int = 0,
    ) -> str:
        """Generate a backend-specific arange expression for loop offsets."""
        raise exc.BackendUnsupported(self.name, "arange")

    def grid_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        """Generate backend-specific grid index expression from an offset."""
        raise exc.BackendUnsupported(self.name, "grid index")

    def loop_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        """Generate backend-specific device-loop index expression from an offset."""
        raise exc.BackendUnsupported(self.name, "loop index")

    def scalar_load_expr(self, tensor_name: str, index_expr: str | None = None) -> str:
        """Load scalar value from a tensor argument."""
        raise exc.BackendUnsupported(self.name, "scalar load")

    def ast_to_dtype_expr(self, expr_str: str, dtype_str: str) -> str:
        """Generate dtype conversion expression for AST values."""
        return self.cast_expr(expr_str, dtype_str)

    def thread_in_tile_mask_expr(
        self, block_size_var: str, *, axis: int = 0
    ) -> str | None:
        """Optional per-thread mask restricting active threads to tile width."""
        return None

    def max_reduction_threads(self) -> int | None:
        """Maximum threads for a single warp-level reduction, or None if unlimited."""
        return None

    def adjust_reduction_thread_count(
        self, requested: int, existing_strategies: list[TileStrategy]
    ) -> int:
        """Adjust reduction thread count to fit within hardware thread limits.

        Tile-level backends return the count unchanged. Thread-level backends
        (e.g., CuTe) override this to cap against the per-block thread budget
        shared across all tiled dimensions.
        """
        return requested

    def create_synthetic_reduction_lanes(
        self,
        thread_count: int,
        size_hint: int,
    ) -> int | None:
        """Determine if a synthetic lane loop is needed for a persistent reduction.

        Returns the lane extent when lanes are needed, or None if not.
        Tile-level backends never need lanes. Thread-level backends
        (e.g., CuTe) override this to create lanes when the padded
        reduction size exceeds the thread count.
        """
        return None

    def barrier_semaphore_dtype(self) -> torch.dtype:
        """Dtype used for persistent multi-phase barrier semaphore tensors."""
        return torch.uint32

    def grid_barrier_stmt(self, sem_arg: str) -> str | None:
        """Statement emitted between persistent phases, if supported."""
        raise exc.BackendUnsupported(self.name, "hl.barrier()")

    def reduction_axis_first(self) -> bool:
        """Whether reduction strategies should occupy the first (lowest) thread axes."""
        return False

    def force_tile_mask(self) -> bool:
        """Whether tile strategies must emit explicit masks for all tiles."""
        return False

    def supports_config_key(self, key: str) -> bool:
        from ..autotuner.config_spec import BACKEND_SPECIFIC_KEYS

        return key not in BACKEND_SPECIFIC_KEYS

    def supports_block_ptr_indexing(self) -> bool:
        return True

    def process_fake_tensor_load(
        self,
        tensor: torch.Tensor,
        index: list[object],
    ) -> None:
        """Called during `type_propagation` when processing a `load` memory op on fake tensors"""
        return

    def adjust_block_size_constraints(
        self,
        block_specs: list[object],
        ndim: int,
        block_sizes: list[object] | None = None,
        kernel_tensor_sizes: dict[tuple[object, ...], int] | None = None,
        min_element_bits: int = 32,
    ) -> None:
        """Adjust block-size min/max constraints for backend-specific alignment.

        Called after all block-size specs have been created.  ``block_specs``
        is a list of ``BlockSizeSpec`` objects (one per tiled dimension).
        ``ndim`` is the total number of tiled dimensions.
        ``block_sizes``, ``kernel_tensor_sizes``, and ``min_element_bits``
        provide additional context for backends that need physical tensor
        dimension info.

        The default does nothing.  Backends with alignment requirements
        (e.g., Pallas/TPU) override this to enforce minimums.
        """
        return

    def tunable_fragments(self) -> dict[str, ConfigSpecFragment]:
        return {}

    def get_do_bench(self) -> Callable[..., float | tuple[float, ...]] | None:
        """Return the benchmarking function for this backend.

        The default returns ``None`` which causes the autotuner to use the
        module-level ``do_bench`` (patchable by tests).  Backends that need
        a different timing mechanism (e.g., Pallas/TPU) should override
        this to return their own function.
        """
        return None

    def get_interleaved_bench(
        self,
    ) -> Callable[..., list[float]] | None:
        """Return the interleaved benchmarking function for this backend.

        The default returns ``None`` which causes the autotuner to use the
        module-level ``interleaved_bench``.  Backends without Triton event
        timing should override.
        """
        return None

    def supports_precompile(self) -> bool:
        """Whether this backend supports subprocess precompilation.

        Triton backends use fork/spawn to precompile kernels and detect hangs.
        Other backends (Pallas, CuTe) may not need or support this.
        """
        return True

    def classify_autotune_exception(self, err: BaseException) -> str | None:
        """Classify an exception that occurred during autotuning.

        Returns one of:
          - ``"raise"``: unexpected error, caller should re-raise
          - ``"warn"``:  notable but expected; log as warning
          - ``"debug"``: benign/expected; log at debug level
          - ``None``:    backend has no opinion; fall through to default

        The default returns ``None`` so the existing Triton-oriented
        classifier handles it.
        """
        return None

    def where_expr(self, mask: str, true_val: str, false_val: str) -> str:
        """Generate a backend-specific conditional select expression."""
        raise exc.BackendUnsupported(self.name, "where")

    def minimum_expr(self, a: str, b: str) -> str:
        """Generate a backend-specific minimum expression."""
        raise exc.BackendUnsupported(self.name, "minimum")

    def arange_index_expr(self, block_size_var: str, dtype: str) -> str:
        """Generate a backend-specific arange expression for reduction index setup."""
        raise exc.BackendUnsupported(self.name, "arange index")

    def zeros_expr(self, shape: str, dtype: str) -> str:
        """Generate a backend-specific zeros expression."""
        raise exc.BackendUnsupported(self.name, "zeros")

    def full_expr(
        self, shape_dims: list[str], value_expr: str, dtype: torch.dtype
    ) -> str:
        raise exc.BackendUnsupported(self.name, "full tensor creation")

    def reshape_expr(self, expr: str, shape: str) -> str:
        raise exc.BackendUnsupported(self.name, "reshape")

    def broadcast_to_expr(self, expr: str, shape: str) -> str:
        raise exc.BackendUnsupported(self.name, "broadcast_to")

    def maybe_reshape_reduction(
        self,
        expr: str,
        source_shape: Sequence[int],
        target_shape: Sequence[int],
        target_shape_expr: str,
    ) -> str:
        """Reshape a reduction result from its physical to logical shape."""
        return self.reshape_expr(expr, target_shape_expr)

    def reduction_index_expr(
        self, block_size_var: str, dtype: str, block_idx: int, *, axis: int
    ) -> str:
        """Generate the index expression for a reduction dimension."""
        raise exc.BackendUnsupported(self.name, "reduction index")

    def reduction_index_zero_expr(self, dtype: str) -> str:
        """Generate the zero-length index expression for an empty reduction."""
        raise exc.BackendUnsupported(self.name, "reduction index zero")

    def next_power_of_2_host_expr(self, expr: str) -> str:
        """Generate a host-side next-power-of-2 expression."""
        raise exc.BackendUnsupported(self.name, "next_power_of_2")

    def static_rdim_size(self, numel: int) -> int:
        """Return the RDIM block size for a statically known reduction dimension."""
        from torch._inductor.runtime.runtime_utils import next_power_of_2

        return next_power_of_2(numel)

    def dynamic_rdim_size_expr(self, expr: str) -> str:
        """Generate a host-side expression for RDIM size from a dynamic dimension.

        By default delegates to next_power_of_2_host_expr. Backends like Pallas
        that need exact sizes can override to return the expression unchanged.
        """
        return self.next_power_of_2_host_expr(expr)

    def lane_index_expr(
        self, offset_var: str, elements_per_thread: int, *, axis: int
    ) -> str:
        """Thread index expression with elements-per-thread stride for lane loops."""
        raise exc.BackendUnsupported(self.name, "lane index")

    def lane_offset_expr(self, lane_var: str) -> str:
        """Cast a lane variable for addition to an index expression."""
        raise exc.BackendUnsupported(self.name, "lane offset")

    def reduction_combine_expr(
        self,
        reduction_type: str,
        acc: str,
        val: str,
        dtype: torch.dtype,
    ) -> str:
        """Generate the combine expression for looped reductions."""
        from torch._inductor.ir import get_reduction_combine_fn

        combine_fn = get_reduction_combine_fn(reduction_type, dtype)
        return str(combine_fn(acc, val))

    def reduction_expr(
        self,
        input_name: str,
        reduction_type: str,
        dim: int,
        *,
        block_size_var: str | None = None,
        threads_in_group: int | None = None,
    ) -> str:
        raise exc.BackendUnsupported(self.name, f"reduction {reduction_type!r}")

    def thread_linear_index_expr(self, axis_sizes: dict[int, int]) -> str | None:
        """Linearized thread index expression for active block axes, if available."""
        return None

    def reduction_threads_hint(self, block_size_var: str | None = None) -> int | None:
        """Best-effort thread count used by reduction_expr for the given block size."""
        return None

    def is_indexed_reduction(self, reduction_type: str) -> bool:
        """Whether this reduction type tracks an auxiliary index state."""
        return False

    def reduction_index_init_expr(
        self, shape_dims: list[str], index_dtype: torch.dtype
    ) -> str:
        """Initial accumulator value for index-carrying reductions."""
        return self.full_expr(
            shape_dims, repr(torch.iinfo(index_dtype).max), index_dtype
        )

    def argreduce_result_expr(
        self,
        input_name: str,
        index_value: str,
        reduction_type: str,
        dim: int,
        output_dtype: torch.dtype,
        *,
        block_size_var: str | None = None,
        index_dtype: torch.dtype | None = None,
        threads_in_group: int | None = None,
    ) -> str:
        raise exc.BackendUnsupported(self.name, "argmin/argmax reductions")

    def argreduce_loop_update_statements(
        self,
        *,
        reduction_type: str,
        acc: str,
        acc_index: str,
        value: str,
        index: str,
    ) -> list[str]:
        raise exc.BackendUnsupported(self.name, "argmin/argmax reductions")

    def inductor_op_overrides(self) -> InductorOpOverrides:
        raise exc.BackendUnsupported(self.name, "Inductor OpOverrides")

    def cast_ast(self, x: ast.AST, target_dtype: torch.dtype) -> ast.AST:
        return expr_from_string(
            self.cast_expr("{x}", self.dtype_str(target_dtype)),
            x=x,
        )

    @property
    @abc.abstractmethod
    def function_decorator(self) -> str:
        """Expression string for the kernel function decorator.

        For example, Triton returns 'triton.jit'.
        """
        ...

    def function_decorator_for_args(self, args: Sequence[Argument]) -> str:
        """Expression string for the kernel function decorator.

        Backends can override this when the decorator needs to depend on the
        generated function signature.
        """
        return self.function_decorator

    @property
    @abc.abstractmethod
    def constexpr_type(self) -> str:
        """Type annotation string for compile-time constant arguments.

        For example, Triton returns 'tl.constexpr'.
        """
        ...

    def inline_constexpr(self, name: str, value: str) -> str:
        """Return the source for a module-level inlined constexpr assignment.

        For example, Triton returns '_BLOCK_SIZE_0 = tl.constexpr(256)'.
        """
        return f"{name} = {self.constexpr_type}({value})"

    @property
    @abc.abstractmethod
    def default_launcher_name(self) -> str:
        """Name of the default host-side launcher symbol for this backend."""
        ...

    def get_launcher_name(self) -> str:
        """Return the launcher name to use for the current config.

        Subclasses can override to select a different launcher based on
        the active configuration (e.g., pipeline launcher).
        """
        return self.default_launcher_name

    @property
    @abc.abstractmethod
    def library_imports(self) -> dict[str, str]:
        """Mapping of short names to import statements for generated code.

        Keys are the short names used in generated code (e.g., 'tl'),
        values are the corresponding import statements.
        """
        ...

    def launcher_keyword_args(self, config: Config, *, has_barrier: bool) -> list[str]:
        return []

    def pre_codegen(
        self,
        graphs: list[GraphInfo],
        config: Config,
        tile_strategy: TileStrategyDispatch,
    ) -> None:
        """Run backend-specific passes after tiling is finalized, before codegen.

        Backends can override this to analyze or transform the graphs.
        """
        return None

    @staticmethod
    def reserved_launch_param_names() -> frozenset[str]:
        """Names reserved by this backend's kernel launch mechanism.

        These names cannot be used as kernel variables because they
        collide with parameters of the backend's kernel launch API
        (e.g., Triton's ``run()`` method uses ``grid``, ``num_warps``,
        ``num_stages``, etc.).
        """
        return frozenset()

    def transform_host_arg(
        self,
        arg: Argument,
        host_str: str,
        tensor_host_args: list[str],
    ) -> str:
        """Transform a host argument expression before passing to the launcher.

        Backends can override this to wrap certain argument types.
        Called during codegen for each argument in sorted order.
        """
        return host_str

    def scalar_arg_preamble(self, arg: Argument) -> list[ast.AST]:
        """Generate preamble statements for scalar arguments in the device function.

        Backends can override to dereference scalar refs, etc.
        """
        return []

    def rng_seed_buffer_expr(self, count: int) -> str:
        """Return the Python expression string that creates the RNG seed buffer.

        Backends can override to customize seed generation (e.g. for devices
        that don't support int64 randint).
        """
        return f"inductor_prims.seeds({count}, torch.accelerator.current_accelerator())"

    def build_launcher_args(
        self,
        args: list[str],
        *,
        tensor_host_args: list[str],
        has_rng_ops: bool,
        config: Config,
        has_barrier: bool,
        sorted_args: list[Argument] | None = None,
    ) -> list[str]:
        if has_rng_ops:
            raise exc.BackendUnsupported(self.name, "RNG ops")
        return [*args, *self.launcher_keyword_args(config, has_barrier=has_barrier)]

    def create_loop_strategy(
        self, fn: DeviceFunction, block_ids: list[int], config: Config
    ) -> TileStrategy:
        from .compile_environment import CompileEnvironment
        from .tile_strategy import FlattenedTileStrategy
        from .tile_strategy import NDTileStrategy

        env = CompileEnvironment.current()
        block_size_infos = [env.block_sizes[i] for i in block_ids]
        loop_order = env.config_spec.loop_orders.config_get(
            config.loop_orders, block_ids[0]
        ) or [*range(len(block_ids))]
        l2_grouping = env.config_spec.l2_groupings.config_get(
            config.l2_groupings, block_ids[0], 1
        )

        if block_size_infos[0].is_flattened(config):
            block_size = functools.reduce(
                operator.mul, [bs.from_config_assert(config) for bs in block_size_infos]
            )
            return FlattenedTileStrategy(
                fn,
                block_ids,
                block_size=block_size,
                loop_order=loop_order,
            )

        return NDTileStrategy(
            fn,
            block_ids,
            block_size=[bs.from_config_assert(config) for bs in block_size_infos],
            loop_order=loop_order,
            l2_grouping=l2_grouping,
        )

    def create_reduction_strategy(
        self,
        fn: DeviceFunction,
        block_id: int,
        reduction_loop: int | None,
    ) -> TileStrategy:
        """Create a reduction strategy for the given block dimension.

        Analogous to create_loop_strategy() but for reduction dimensions.
        Backends can override to return backend-specific strategy subclasses.
        """
        from .reduction_strategy import LoopedReductionStrategy
        from .reduction_strategy import PersistentReductionStrategy

        if reduction_loop is None:
            return PersistentReductionStrategy(fn, block_id)
        return LoopedReductionStrategy(fn, block_id, reduction_loop)

    def autotune(
        self,
        bound_kernel: BoundKernel[Any],
        args: Sequence[object],
        *,
        force: bool = True,
        **kwargs: object,
    ) -> Config:
        """Run autotuning to find the best configuration.

        This default implementation handles:
        - Using a single provided config directly
        - Searching over finite predetermined configs
        - Running a full search algorithm

        Subclasses can override to customize behavior (e.g., disabling
        precompile for backends that don't support it).
        """
        force = force or bound_kernel.settings.force_autotune

        # Disable precompile for backends that don't support it
        if not self.supports_precompile():
            bound_kernel.settings.autotune_precompile = None

        if bound_kernel.settings.autotune_effort == "none" and (
            force or not bound_kernel.kernel.configs
        ):
            config = bound_kernel.config_spec.default_config()
        elif not force and bound_kernel.kernel.configs:
            if len(bound_kernel.kernel.configs) == 1:
                (config,) = bound_kernel.kernel.configs
            else:
                # We have finite predetermined configs, no need to precompile
                bound_kernel.settings.autotune_precompile = None

                from ..autotuner import FiniteSearch

                config = FiniteSearch(
                    bound_kernel, args, bound_kernel.configs
                ).autotune()
        else:
            bound_kernel.settings.check_autotuning_disabled()
            config = bound_kernel.settings.autotuner_fn(
                bound_kernel, args, **kwargs
            ).autotune(skip_cache=force)
        return config


class TritonBackend(Backend):
    """Triton code generation backend."""

    @property
    def name(self) -> str:
        return "triton"

    @property
    def experimental(self) -> bool:
        return False

    def supports_config_key(self, key: str) -> bool:
        if key == "waves_per_eu":
            from .._compat import is_hip

            return is_hip()
        if key == "matrix_instr_nonkdim":
            from .._compat import supports_amd_cdna_tunables

            return supports_amd_cdna_tunables()

        from .._compat import get_mtia_tunable_fragments
        from .._compat import supports_mtia_tunables

        if key in get_mtia_tunable_fragments():
            return supports_mtia_tunables()
        return super().supports_config_key(key)

    def tunable_fragments(self) -> dict[str, ConfigSpecFragment]:
        from .._compat import get_mtia_tunable_fragments
        from .._compat import is_hip
        from .._compat import supports_amd_cdna_tunables
        from .._compat import supports_mtia_tunables
        from ..autotuner.config_fragment import EnumFragment

        if not is_hip() and not supports_mtia_tunables():
            return {}
        fragments: dict[str, ConfigSpecFragment] = {}
        if is_hip():
            fragments["waves_per_eu"] = EnumFragment(choices=(1, 2, 3, 4))
            if supports_amd_cdna_tunables():
                fragments["matrix_instr_nonkdim"] = EnumFragment(choices=(0, 16))

        if supports_mtia_tunables():
            fragments.update(get_mtia_tunable_fragments())

        return fragments

    def dtype_str(self, dtype: torch.dtype) -> str:
        from torch._inductor.utils import triton_type

        return triton_type(dtype)

    def acc_type(self, dtype: torch.dtype) -> str:
        from torch._inductor.codegen.triton import triton_acc_type

        return triton_acc_type(dtype)

    def cast_expr(self, expr_str: str, dtype_str: str) -> str:
        return f"tl.cast({expr_str}, {dtype_str})"

    def arange_expr(
        self,
        offsets_var: str,
        lid: str,
        block_size_var: str,
        dtype: str,
        *,
        axis: int = 0,
    ) -> str:
        return f"{offsets_var} = {lid} * {block_size_var} + tl.arange(0, {block_size_var}).to({dtype})"

    def loop_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        return f"{offset_var} + tl.arange(0, ({block_size_var})).to({dtype})"

    def scalar_load_expr(self, tensor_name: str, index_expr: str | None = None) -> str:
        if index_expr is None:
            return f"tl.load({tensor_name})"
        return f"tl.load({tensor_name} + {index_expr})"

    def where_expr(self, mask: str, true_val: str, false_val: str) -> str:
        return f"tl.where({mask}, {true_val}, {false_val})"

    def minimum_expr(self, a: str, b: str) -> str:
        return f"tl.minimum({a}, {b})"

    def arange_index_expr(self, block_size_var: str, dtype: str) -> str:
        return f"tl.arange(0, {block_size_var}).to({dtype})"

    def zeros_expr(self, shape: str, dtype: str) -> str:
        return f"tl.zeros({shape}, {dtype})"

    def reshape_expr(self, expr: str, shape: str) -> str:
        return f"tl.reshape({expr}, {shape})"

    def broadcast_to_expr(self, expr: str, shape: str) -> str:
        return f"tl.broadcast_to({expr}, {shape})"

    def maybe_reshape_reduction(
        self,
        expr: str,
        source_shape: Sequence[int],
        target_shape: Sequence[int],
        target_shape_expr: str,
    ) -> str:
        # Triton reductions over a 1D tile produce a scalar even when
        # keepdim=True makes the logical result shape [1]. tl.reshape() only
        # accepts block tensors here, so leave the scalar and let later ops
        # broadcast it.
        if not source_shape and math.prod(target_shape) == 1:
            return expr
        return self.reshape_expr(expr, target_shape_expr)

    def reduction_index_expr(
        self, block_size_var: str, dtype: str, block_idx: int, *, axis: int
    ) -> str:
        return f"tl.arange(0, {block_size_var}).to({dtype})"

    def reduction_index_zero_expr(self, dtype: str) -> str:
        return f"tl.zeros([0], {dtype})"

    def next_power_of_2_host_expr(self, expr: str) -> str:
        return f"triton.next_power_of_2({expr})"

    @property
    def function_decorator(self) -> str:
        return "triton.jit"

    def function_decorator_for_args(self, args: Sequence[Argument]) -> str:
        from .compile_environment import CompileEnvironment
        from .device_function import SymbolArgument
        from .device_function import TensorSizeArg
        from .device_function import TensorStrideArg

        # Default to Triton's own behavior: let Triton specialize on values and
        # alignment.  This enables vectorized loads (constexpr 1 for inner
        # strides, divisibility-by-16 hint for sizes) at the cost of an
        # occasional Triton recompile when a value crosses a specialization
        # boundary (e.g. size 1 -> 2, alignment changes).
        if not CompileEnvironment.current().settings.triton_do_not_specialize:
            return self.function_decorator

        do_not_specialize = [
            arg.name
            for arg in args
            if isinstance(arg, (TensorSizeArg, TensorStrideArg, SymbolArgument))
        ]
        if not do_not_specialize or not _triton_jit_supports_do_not_specialize():
            return self.function_decorator
        return (
            "triton.jit("
            f"do_not_specialize={do_not_specialize!r}, "
            f"do_not_specialize_on_alignment={do_not_specialize!r})"
        )

    @property
    def constexpr_type(self) -> str:
        return "tl.constexpr"

    @property
    def default_launcher_name(self) -> str:
        return "_default_launcher"

    @property
    def library_imports(self) -> dict[str, str]:
        return {
            "math": "import math",
            "operator": "import operator",
            "torch": "import torch",
            "helion": "import helion",
            "hl": "import helion.language as hl",
            "triton": "import triton",
            "tl": "import triton.language as tl",
            "triton_helpers": "from torch._inductor.runtime import triton_helpers",
            "tl_math": "from torch._inductor.runtime.triton_helpers import math as tl_math",
            "libdevice": "from torch._inductor.runtime.triton_compat import libdevice",
            "_default_launcher": "from helion.runtime import default_launcher as _default_launcher",
            "fast_dividef": "from triton.language.extra.libdevice import fast_dividef",
            "fast_expf": "from triton.language.extra.libdevice import fast_expf",
        }

    def program_id_expr(self, dim: int, *, index_dtype: str) -> str:
        if index_dtype != "tl.int32":
            return f"tl.program_id({dim}).to({index_dtype})"
        return f"tl.program_id({dim})"

    def cdiv_expr(self, numel: str, block_size: str, *, is_device: bool) -> str:
        if is_device:
            return f"tl.cdiv({numel}, {block_size})"
        return f"triton.cdiv({numel}, {block_size})"

    def inductor_op_overrides(self) -> InductorOpOverrides:
        from torch._inductor.codegen.triton import TritonOverrides

        return TritonOverrides()

    def grid_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        if block_size_var == "1":
            return f"{offset_var} + tl.zeros([1], {dtype})"
        return f"({offset_var} + tl.arange(0, ({block_size_var}))).to({dtype})"

    def reduction_expr(
        self,
        input_name: str,
        reduction_type: str,
        dim: int,
        *,
        block_size_var: str | None = None,
        threads_in_group: int | None = None,
    ) -> str:
        if reduction_type in {"sum", "max", "min"}:
            return f"tl.{reduction_type}({input_name}, {dim})"
        if reduction_type == "prod":
            return f"triton_helpers.prod({input_name}, {dim})"
        raise exc.BackendUnsupported(self.name, f"reduction {reduction_type!r}")

    def is_indexed_reduction(self, reduction_type: str) -> bool:
        return reduction_type in {"argmin", "argmax"}

    def argreduce_result_expr(
        self,
        input_name: str,
        index_value: str,
        reduction_type: str,
        dim: int,
        output_dtype: torch.dtype,
        *,
        block_size_var: str | None = None,
        index_dtype: torch.dtype | None = None,
        threads_in_group: int | None = None,
    ) -> str:
        helper = "max" if reduction_type == "argmax" else "min"
        return (
            f"triton_helpers.{helper}_with_index("
            f"{input_name}, {index_value}, {dim})[1].to({self.dtype_str(output_dtype)})"
        )

    def argreduce_loop_update_statements(
        self,
        *,
        reduction_type: str,
        acc: str,
        acc_index: str,
        value: str,
        index: str,
    ) -> list[str]:
        helper = "maximum" if reduction_type == "argmax" else "minimum"
        return [
            (
                f"{acc}, {acc_index} = "
                f"triton_helpers.{helper}_with_index({acc}, {acc_index}, {value}, {index})"
            )
        ]

    def full_expr(
        self, shape_dims: list[str], value_expr: str, dtype: torch.dtype
    ) -> str:
        return (
            f"tl.full([{', '.join(shape_dims)}], {value_expr}, {self.dtype_str(dtype)})"
        )

    def launcher_keyword_args(self, config: Config, *, has_barrier: bool) -> list[str]:
        from .._compat import supports_maxnreg

        # Workaround for triton bug: warp_specialize requires at least 4 warps
        # See: https://github.com/triton-lang/triton/issues/7354
        num_warps = config.num_warps
        if any(config.range_warp_specializes):
            num_warps = max(4, num_warps)

        args = [
            f"num_warps={num_warps}",
            f"num_stages={config.num_stages}",
            *(["launch_cooperative_grid=True"] if has_barrier else []),
        ] + [
            f"{x.removeprefix('_triton_config_')}={config[x]}"
            for x in config
            if x.startswith("_triton_config_")
        ]

        from ..autotuner.config_spec import _get_backend_tunable_keys

        for key in _get_backend_tunable_keys():
            if key in config:
                args.append(f"{key}={config[key]!r}")

        if "maxnreg" in config and config["maxnreg"] is not None and supports_maxnreg():
            args.append(f"maxnreg={config['maxnreg']}")

        advanced_controls_file = config.advanced_controls_file
        if advanced_controls_file:
            ptx_option = f"--apply-controls {advanced_controls_file}"
            args.append(f"ptx_options={ptx_option!r}")

        return args

    def grid_barrier_stmt(self, sem_arg: str) -> str:
        return f"triton_helpers.x_grid_barrier({sem_arg})"

    def build_launcher_args(
        self,
        args: list[str],
        *,
        tensor_host_args: list[str],
        has_rng_ops: bool,
        config: Config,
        has_barrier: bool,
        sorted_args: list[Argument] | None = None,
    ) -> list[str]:
        out = [*args]
        if has_rng_ops:
            out.append("_rng_seed_buffer")
        out.extend(self.launcher_keyword_args(config, has_barrier=has_barrier))
        return out

    @staticmethod
    def reserved_launch_param_names() -> frozenset[str]:
        return frozenset({"grid", "warmup", "num_warps", "num_stages"})


class TileIRBackend(TritonBackend):
    """TileIR code generation backend (extends Triton)."""

    @property
    def name(self) -> str:
        return "tileir"

    @property
    def codegen_name(self) -> str:
        return "triton"

    def supports_config_key(self, key: str) -> bool:
        # Override TritonBackend/Backend rejections for tileir-specific tunables
        if key in {"num_ctas", "occupancy"}:
            return True
        return super().supports_config_key(key)

    def supports_block_ptr_indexing(self) -> bool:
        return False

    def tunable_fragments(self) -> dict[str, ConfigSpecFragment]:
        from ..autotuner.config_fragment import PowerOfTwoFragment

        return {
            **super().tunable_fragments(),
            "num_ctas": PowerOfTwoFragment(1, 2, 1),
            "occupancy": PowerOfTwoFragment(1, 8, 1),
        }

    @staticmethod
    def reserved_launch_param_names() -> frozenset[str]:
        return frozenset(
            {"grid", "warmup", "num_warps", "num_stages", "num_ctas", "occupancy"}
        )


# Mapping from torch dtype to JAX dtype string (e.g., "jnp.float32")
_TORCH_TO_JAX_DTYPE: dict[str, str] = {
    "torch.float16": "jnp.float16",
    "torch.float32": "jnp.float32",
    "torch.float64": "jnp.float64",
    "torch.bfloat16": "jnp.bfloat16",
    "torch.int8": "jnp.int8",
    "torch.int16": "jnp.int16",
    "torch.int32": "jnp.int32",
    "torch.int64": "jnp.int64",
    "torch.uint8": "jnp.uint8",
    "torch.uint32": "jnp.uint32",
    "torch.uint64": "jnp.uint64",
    "torch.bool": "jnp.bool_",
    "torch.complex64": "jnp.complex64",
    "torch.complex128": "jnp.complex128",
    "torch.float8_e4m3fn": "jnp.float8_e4m3fn",
    "torch.float8_e4m3fnuz": "jnp.float8_e4m3fnuz",
    "torch.float8_e5m2": "jnp.float8_e5m2",
    "torch.float8_e5m2fnuz": "jnp.float8_e5m2fnuz",
    "torch.float8_e8m0fnu": "jnp.float8_e8m0fnu",
}


# TPU does not natively support 64-bit element types.
_PALLAS_UNSUPPORTED_DTYPES = frozenset({torch.int64, torch.uint64, torch.float64})


class PallasBackend(Backend):
    """Pallas (JAX) code generation backend for TPU."""

    @property
    def name(self) -> str:
        return "pallas"

    @property
    def max_tensor_numel(self) -> int | None:
        # No compile-time element cap on Pallas; VMEM byte budget is the
        # real constraint and is enforced separately at runtime.
        return None

    @property
    def pad_factory_tensors_to_power_of_2(self) -> bool:
        return False

    def max_reduction_threads(self) -> int | None:
        return None

    def dtype_str(self, dtype: torch.dtype) -> str:
        key = str(dtype)
        if key not in _TORCH_TO_JAX_DTYPE:
            raise ValueError(f"Unsupported dtype for Pallas backend: {dtype}")
        return _TORCH_TO_JAX_DTYPE[key]

    def acc_type(self, dtype: torch.dtype) -> str:
        # Promote half-precision types to float32 for numerical stability
        if dtype in (torch.float16, torch.bfloat16):
            return "jnp.float32"
        return self.dtype_str(dtype)

    @property
    def function_decorator(self) -> str:
        return ""

    @property
    def constexpr_type(self) -> str:
        return "int"

    @property
    def default_launcher_name(self) -> str:
        return "_default_pallas_launcher"

    @property
    def library_imports(self) -> dict[str, str]:
        return {
            "math": "import math",
            "torch": "import torch",
            "helion": "import helion",
            "hl": "import helion.language as hl",
            "jax": "import jax",
            "jnp": "import jax.numpy as jnp",
            "pl": "from jax.experimental import pallas as pl",
            "lax": "import jax.lax as lax",
            "pltpu": "from jax.experimental.pallas import tpu as pltpu",
            "_default_pallas_launcher": "from helion.runtime import default_pallas_launcher as _default_pallas_launcher",
            "_default_pallas_pipeline_launcher": "from helion.runtime import default_pallas_pipeline_launcher as _default_pallas_pipeline_launcher",
            "_default_pallas_fori_launcher": "from helion.runtime import default_pallas_fori_launcher as _default_pallas_fori_launcher",
        }

    # Config keys that Pallas actually uses.  Everything else
    # (pid_type, num_warps, num_stages, maxnreg, indexing, etc.)
    # is GPU-specific and should not be tuned.
    _PALLAS_SUPPORTED_KEYS: frozenset[str] = frozenset(
        {
            "block_sizes",
            "loop_orders",
            "flatten_loops",
            "pallas_loop_type",
            "pallas_pre_broadcast",
        }
    )

    def supports_config_key(self, key: str) -> bool:
        return key in self._PALLAS_SUPPORTED_KEYS

    def program_id_expr(self, dim: int, *, index_dtype: str) -> str:
        return f"pl.program_id({dim})"

    def cast_expr(self, expr_str: str, dtype_str: str) -> str:
        return f"lax.convert_element_type({expr_str}, {dtype_str})"

    @property
    def range_requires_python_int(self) -> bool:
        return True

    def range_str(
        self,
        begin: str | None,
        end: str,
        step: str | None,
    ) -> str | None:
        range_args = []
        if begin is not None:
            range_args.append(begin)
        range_args.append(end)
        if step is not None and step != "1":
            range_args.append(step)
        return f"range({', '.join(range_args)})"

    def arange_expr(
        self,
        offsets_var: str,
        lid: str,
        block_size_var: str,
        dtype: str,
        *,
        axis: int = 0,
    ) -> str:
        return f"{offsets_var} = {lid} * {block_size_var} + jnp.arange(0, {block_size_var}, dtype={dtype})"

    def sympy_printer_expr(self, expr: sympy.Expr) -> str:
        from .device_function import pallas_texpr

        return pallas_texpr(expr)

    def inductor_op_overrides(self) -> InductorOpOverrides:
        from torch._inductor.codegen.pallas import PallasKernelOverrides

        return PallasKernelOverrides()

    def cast_ast(self, x: ast.AST, target_dtype: torch.dtype) -> ast.AST:
        return expr_from_string(
            f"lax.convert_element_type({{x}}, {self.dtype_str(target_dtype)})", x=x
        )

    def transform_host_arg(
        self,
        arg: Argument,
        host_str: str,
        tensor_host_args: list[str],
    ) -> str:
        from .device_function import SymbolArgument
        from .device_function import TensorSizeArg
        from .device_function import TensorStrideArg

        if isinstance(arg, (SymbolArgument, TensorSizeArg, TensorStrideArg)):
            from .compile_environment import CompileEnvironment

            if tensor_host_args:
                device_expr = f"{tensor_host_args[0]}.device"
            elif CompileEnvironment.current().settings.pallas_interpret:
                device_expr = "'cpu'"
            else:
                device_expr = "'tpu'"
            # Scalars are passed as 1-dim tensors (shape [1]) rather than
            # 0-dim tensors (shape []) because TPU Pallas Mosaic lowering
            # requires rank >= 1 for all block specs.  A 0-dim input causes:
            #   ValueError: The Pallas TPU lowering currently supports only
            #   blocks of rank >= 1.
            # The kernel dereferences the scalar with ``name[0]`` (see
            # ``scalar_arg_preamble``).
            if isinstance(arg, (TensorSizeArg, TensorStrideArg)):
                from .compile_environment import CompileEnvironment

                idx_dtype = CompileEnvironment.current().index_dtype
                return f"torch.tensor([{host_str}], dtype={idx_dtype!r}, device={device_expr})"
            return f"torch.tensor([{host_str}], dtype=torch.float32 if isinstance({host_str}, float) else torch.int32, device={device_expr})"
        return host_str

    def scalar_arg_preamble(self, arg: Argument) -> list[ast.AST]:
        from .ast_extension import statement_from_string
        from .device_function import SymbolArgument
        from .device_function import TensorSizeArg
        from .device_function import TensorStrideArg

        if isinstance(arg, (SymbolArgument, TensorSizeArg, TensorStrideArg)):
            # TPU: scalars are wrapped as 1-dim tensors, index with [0]
            return [statement_from_string(f"{arg.name} = {arg.name}[0]")]
        return []

    def grid_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        return f"{offset_var} + jnp.arange(0, ({block_size_var}), dtype={dtype})"

    def loop_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        return f"{offset_var} + jnp.arange(0, ({block_size_var}), dtype={dtype})"

    def scalar_load_expr(self, tensor_name: str, index_expr: str | None = None) -> str:
        if index_expr is None:
            index_expr = "0"
        return f"({tensor_name})[{index_expr}]"

    def full_expr(
        self, shape_dims: list[str], value_expr: str, dtype: torch.dtype
    ) -> str:
        return f"jnp.full([{', '.join(shape_dims)}], {value_expr}, {self.dtype_str(dtype)})"

    def reshape_expr(self, expr: str, shape: str) -> str:
        return f"jnp.reshape({expr}, {shape})"

    def broadcast_to_expr(self, expr: str, shape: str) -> str:
        return f"jnp.broadcast_to({expr}, {shape})"

    def reduction_expr(
        self,
        input_name: str,
        reduction_type: str,
        dim: int,
        *,
        block_size_var: str | None = None,
        threads_in_group: int | None = None,
    ) -> str:
        if reduction_type in {"sum", "max", "min", "prod"}:
            return f"jnp.{reduction_type}({input_name}, axis={dim})"
        raise exc.BackendUnsupported(self.name, f"reduction {reduction_type!r}")

    def is_indexed_reduction(self, reduction_type: str) -> bool:
        return reduction_type in {"argmin", "argmax"}

    def argreduce_result_expr(
        self,
        input_name: str,
        index_value: str,
        reduction_type: str,
        dim: int,
        output_dtype: torch.dtype,
        *,
        block_size_var: str | None = None,
        index_dtype: torch.dtype | None = None,
        threads_in_group: int | None = None,
    ) -> str:
        fn = "jnp.argmax" if reduction_type == "argmax" else "jnp.argmin"
        return (
            f"lax.convert_element_type("
            f"{fn}({input_name}, axis={dim}), {self.dtype_str(output_dtype)})"
        )

    def argreduce_loop_update_statements(
        self,
        *,
        reduction_type: str,
        acc: str,
        acc_index: str,
        value: str,
        index: str,
    ) -> list[str]:
        if reduction_type == "argmin":
            better = (
                f"(({value}) < ({acc})) | "
                f"((({value}) == ({acc})) & (({index}) < ({acc_index})))"
            )
        else:
            better = (
                f"(({value}) > ({acc})) | "
                f"((({value}) == ({acc})) & (({index}) < ({acc_index})))"
            )
        return [
            f"{acc} = jnp.where({better}, {value}, {acc})",
            f"{acc_index} = jnp.where({better}, {index}, {acc_index})",
        ]

    def where_expr(self, mask: str, true_val: str, false_val: str) -> str:
        return f"jnp.where({mask}, {true_val}, {false_val})"

    def minimum_expr(self, a: str, b: str) -> str:
        return f"jnp.minimum({a}, {b})"

    def arange_index_expr(self, block_size_var: str, dtype: str) -> str:
        return f"jnp.arange(0, {block_size_var}, dtype={dtype})"

    def zeros_expr(self, shape: str, dtype: str) -> str:
        return f"jnp.zeros({shape}, dtype={dtype})"

    def reduction_index_expr(
        self, block_size_var: str, dtype: str, block_idx: int, *, axis: int
    ) -> str:
        return f"jnp.arange(0, {block_size_var}, dtype={dtype})"

    def reduction_index_zero_expr(self, dtype: str) -> str:
        return f"jnp.zeros([0], dtype={dtype})"

    def static_rdim_size(self, numel: int) -> int:
        # Pallas block refs use exact tensor dimensions, so RDIM_SIZE must
        # match (no power-of-2 rounding that would exceed the block ref).
        return numel

    def dynamic_rdim_size_expr(self, expr: str) -> str:
        return expr

    def _get_pallas_required_alignment(
        self, dim_from_end: int, tensor_ndim: int, bitwidth: int
    ) -> int:
        """Requirements documented in https://docs.jax.dev/en/latest/pallas/grid_blockspec.html

        Args:
            dim_from_end (int): The dimension being queried for alignment requirements, indexed from the end. i.e. [... ,2, 1, 0]
            tensor_ndim (int): Amount of dimensions for the tensor.
            bitwidth (int): Bitwidth of tensor elements
        """
        # Cap to 32: wider dtypes (e.g. float64, int64) would cause
        # ZeroDivisionError in 32 // bitwidth.  64-bit types are rejected
        # at runtime, so block spec computation uses 32-bit alignment.
        bitwidth = min(bitwidth, 32)
        if dim_from_end == 0:  # Last dimension
            if tensor_ndim <= 1:
                return 128 * (32 // bitwidth)
            return 128
        if dim_from_end == 1:  # Second to last dimension
            return 8
        return 1  # No requirements for other dimensions

    fake_tensor_loads: list[tuple[torch.Tensor, list[object]]]

    def process_fake_tensor_load(
        self,
        tensor: torch.Tensor,
        index: list[object],
    ) -> None:
        if not hasattr(self, "fake_tensor_loads"):
            self.fake_tensor_loads = []
        self.fake_tensor_loads.append((tensor, index))

    def adjust_block_size_constraints(
        self,
        block_specs: list[object],
        ndim: int,
        block_sizes: list[object] | None = None,
        kernel_tensor_sizes: dict[tuple[object, ...], int] | None = None,
        min_element_bits: int = 32,
    ) -> None:
        """Enforce TPU alignment on block sizes.

        TPU Pallas requires:
        - 1D last dim: multiple of ``128 * (32 // dtype_bits)``
          (128 for f32, 256 for bf16)
        - 2D+ last dim: multiple of 128
        - 2D+ second-to-last dim: multiple of 8

        When the tensor dimension is smaller than the alignment requirement,
        we set the minimum block size to ``next_power_of_2(tensor_dim)``
        instead.  At runtime the block shape is capped to
        ``min(block_size, tensor_dim)`` which equals the full array
        dimension -- always valid per TPU rules.
        """
        from ..autotuner.config_spec import BlockSizeSpec
        from .ast_extension import ExtendedAST
        from .compile_environment import BlockSizeInfo
        from helion._compiler.compile_environment import _to_sympy
        from helion._compiler.host_function import HostFunction
        from helion._compiler.type_propagation import SequenceType
        from helion._compiler.type_propagation import TensorType
        from helion._compiler.type_propagation import TileIndexType

        host_func = HostFunction.current()

        class TensorTiledAccessAnalyzer(ast.NodeVisitor):
            def __init__(self, backend: PallasBackend) -> None:
                super().__init__()
                self.backend = backend
                self.required_alignments: dict[int, int] = {}
                self.update_requirements_from_fake_tensor_loads()

            def visit_Subscript(self, node: ast.Subscript) -> None:
                assert isinstance(node, ExtendedAST)
                assert isinstance(node.value, ExtendedAST)
                value_type = node.value._type_info
                if not isinstance(value_type, TensorType):
                    return
                tensor = value_type.fake_value
                if isinstance(node.slice, (ast.Tuple, ast.List)):
                    num_squeezed_dimensions = 0
                    for i, subscript in enumerate(node.slice.elts):
                        if (
                            isinstance(subscript, ast.Constant)
                            and subscript.value is None
                        ):
                            num_squeezed_dimensions += 1
                            continue
                        accessed_dim = i - num_squeezed_dimensions
                        self.maybe_update_alignment_requirement(
                            tensor, accessed_dim, subscript
                        )
                else:
                    self.maybe_update_alignment_requirement(tensor, 0, node.slice)
                # Nested subscripts (e.g. idx[tile] in table[idx[tile], :])
                # are themselves tiled accesses and need their own alignment.
                self.generic_visit(node)

            def maybe_update_alignment_requirement(
                self, tensor: torch.Tensor, accessed_dim_start: int, subscript: ast.AST
            ) -> None:
                if not isinstance(subscript, ExtendedAST):
                    return
                subscript_type = subscript._type_info
                tile_index_types: list[TileIndexType] = []
                if isinstance(subscript_type, TileIndexType):
                    tile_index_types.append(subscript_type)
                elif isinstance(subscript_type, SequenceType):
                    for el_type in subscript_type.element_types:
                        if isinstance(el_type, TileIndexType):
                            tile_index_types.append(el_type)

                for i, tile_index_type in enumerate(tile_index_types):
                    bid = tile_index_type.block_id
                    accessed_dim = accessed_dim_start + i
                    dim_from_end = tensor.ndim - accessed_dim - 1
                    bitwidth = tensor.dtype.itemsize * 8

                    required_alignment = self.backend._get_pallas_required_alignment(
                        dim_from_end, tensor.ndim, bitwidth
                    )
                    self.maybe_update_required_alignment(bid, required_alignment)

            def maybe_update_required_alignment(
                self, bid: int, required_alignment: int
            ) -> None:
                if bid not in self.required_alignments:
                    self.required_alignments[bid] = required_alignment
                else:
                    self.required_alignments[bid] = max(
                        self.required_alignments[bid], required_alignment
                    )

            def update_requirements_from_fake_tensor_loads(self) -> None:
                # When tensors are indexed within external lambdas called by the kernel,
                # they generate fake loads, which we don't pickup during AST walk.
                if not hasattr(self.backend, "fake_tensor_loads"):
                    return
                if block_sizes is None:
                    return
                for info in block_sizes:
                    if not isinstance(info, BlockSizeInfo):
                        continue
                    for tensor, subscripts in self.backend.fake_tensor_loads:
                        for dim, subscript in enumerate(subscripts):
                            if isinstance(subscript, torch.SymInt) and info.dim_matches(
                                _to_sympy(subscript)
                            ):
                                dim_from_end = tensor.ndim - 1 - dim
                                bitwidth = tensor.dtype.itemsize * 8
                                required_alignment = (
                                    self.backend._get_pallas_required_alignment(
                                        dim_from_end, tensor.ndim, bitwidth
                                    )
                                )
                                self.maybe_update_required_alignment(
                                    info.block_id, required_alignment
                                )

        analyzer = TensorTiledAccessAnalyzer(self)
        for stmt in host_func.body:
            analyzer.visit(stmt)

        from torch._inductor.runtime.runtime_utils import next_power_of_2

        if block_sizes is not None and kernel_tensor_sizes is not None:
            for shape in kernel_tensor_sizes:
                for bid, info in enumerate(block_sizes):
                    if not isinstance(info, BlockSizeInfo):
                        continue
                    # pyrefly: ignore[no-matching-overload]
                    if math.prod(shape) == info.var:
                        # avoid creating size-1 kernel tensors, which triggers Pallas Mosaic lowering failure:
                        # https://github.com/jax-ml/jax/issues/36970
                        analyzer.maybe_update_required_alignment(bid, 2)

        for spec in block_specs:
            if not isinstance(spec, BlockSizeSpec):
                continue
            bid = spec.block_ids[0]
            if bid not in analyzer.required_alignments:
                continue
            requirement_alignment = analyzer.required_alignments[bid]
            # When the tensor dim is smaller than the alignment, any
            # block_size >= tensor_dim will be capped to tensor_dim at
            # runtime (full-dim access, always valid).  Use the
            # tensor dim as the minimum so smaller but still-valid
            # block sizes are not unnecessarily excluded.
            dim_size = next_power_of_2(max(spec.size_hint, 1))

            spec.update_min(min(requirement_alignment, dim_size))

    def tunable_fragments(self) -> dict[str, ConfigSpecFragment]:
        return {}

    def get_do_bench(self) -> Callable[..., float | tuple[float, ...]]:
        from ..autotuner.benchmarking import do_bench_generic

        return do_bench_generic

    def get_interleaved_bench(self) -> Callable[..., list[float]]:
        from ..autotuner.benchmarking import interleaved_bench_generic

        return interleaved_bench_generic

    def supports_precompile(self) -> bool:
        return False

    def classify_autotune_exception(self, err: BaseException) -> str | None:
        # Pallas/JAX compilation and runtime errors are generally expected
        # during autotuning when invalid configs are tried.
        # Only truly fatal errors (KeyboardInterrupt, SystemExit, etc.)
        # should propagate; everything else is a config incompatibility.
        if isinstance(err, Exception):
            return "debug"
        return None

    def rng_seed_buffer_expr(self, count: int) -> str:
        # Generate on CPU, then move to the accelerator so the full 64-bit
        # Philox seed survives backend handoff.
        return f"inductor_prims.seeds({count}, torch.device('cpu')).to(torch.accelerator.current_accelerator())"

    def _compute_block_spec_info(
        self,
        sorted_args: list[Argument] | None,
        config: Config,
    ) -> (
        list[
            tuple[
                tuple[int | None, ...],
                tuple[int | tuple[int, int, int] | None, ...],
            ]
            | None
        ]
        | None
    ):
        """Compute per-tensor ``(block_shape, grid_dims)`` from codegen tiling info.

        Uses ``DeviceFunction.pallas_tensor_dim_tilings`` (recorded during
        ``plan_tiling`` from SymInt subscripts) for an unambiguous
        dim → block_id mapping.
        """
        if sorted_args is None:
            return None

        from .compile_environment import CompileEnvironment
        from .device_function import DeviceFunction
        from .device_function import SymbolArgument
        from .device_function import TensorArg
        from .device_function import TensorSizeArg
        from .device_function import TensorStrideArg
        from .host_function import HostFunction
        from .program_id import FlatProgramIDs

        env = CompileEnvironment.current()
        device_fn = DeviceFunction.current()

        # Build block_id → grid_dim from the actual PID ordering (which
        # reflects loop_order).  ``pid_info`` is ordered by grid dimension,
        # so pid_info[g].block_id is the block_id assigned to grid dim g.
        if device_fn.pid is None:
            return None
        flat_grid_block_ids = [pid.block_id for pid in device_fn.pid.pid_info]
        block_id_to_grid_dim = {bid: g for g, bid in enumerate(flat_grid_block_ids)}
        known_block_ids = set(block_id_to_grid_dim)

        # FlattenedTileStrategy collapses all block_ids into a single
        # pid_info entry, but the full set lives in device_ir.grid_block_ids.
        # Recover them so we can build flat decomposition and so downstream
        # checks (e.g. 1D tensor validation) see every block_id.
        flat_decomp: dict[int, tuple[int, int, int]] | None = None
        if isinstance(device_fn.pid, FlatProgramIDs):
            device_ir = HostFunction.current().device_ir
            all_grid_block_ids = [
                bid for bids in device_ir.grid_block_ids for bid in bids
            ]
            known_block_ids.update(all_grid_block_ids)

            if len(all_grid_block_ids) > 1:
                import sympy

                stride = 1
                flat_decomp = {}
                for bid in all_grid_block_ids:
                    bs = env.block_sizes[bid].from_config(config)
                    numel = env.block_sizes[bid].numel
                    if not isinstance(bs, int) or isinstance(numel, str):
                        return None
                    try:
                        numel_val = (
                            int(numel) if isinstance(numel, sympy.Expr) else numel
                        )
                    except (TypeError, ValueError):
                        return None
                    num_blocks = -(-numel_val // bs)  # cdiv
                    flat_decomp[bid] = (0, stride, num_blocks)
                    stride *= num_blocks

        result: list[
            tuple[tuple[int | None, ...], tuple[int | tuple[int, int, int] | None, ...]]
            | None
        ] = []

        for arg in sorted_args:
            if isinstance(arg, (SymbolArgument, TensorSizeArg, TensorStrideArg)):
                result.append(None)  # scalars wrapped as 1-D tensors
                continue
            if not isinstance(arg, TensorArg) or arg.fake_value.ndim == 0:
                continue
            tensor = arg.fake_value
            dim_tilings = device_fn.pallas_tensor_dim_tilings.get(id(tensor))
            if dim_tilings is None:
                # this means this tensor isn't accessed at all in the kernel
                result.append(None)
                return None
            block_shape: list[int | None] = []
            grid_dims: list[int | tuple[int, int, int] | None] = []
            for d in range(tensor.ndim):
                dim_tiling = dim_tilings[d]
                if not dim_tiling.can_tile or len(dim_tiling.block_ids) == 0:
                    block_shape.append(None)
                    grid_dims.append(None)
                    continue
                assert len(dim_tiling.block_ids) == 1
                bid = dim_tiling.block_ids[0]
                if bid is not None and bid in known_block_ids:
                    bs = env.block_sizes[bid].from_config(config)
                    if isinstance(bs, int):
                        block_shape.append(bs)
                        dim_size = tensor.shape[d]
                        # When the block covers the entire tensor
                        # dimension there is only one tile, so the grid
                        # index must be constant 0 — iterating would
                        # read out-of-bounds (e.g. bias [1, N] with
                        # block_size > 1).
                        if isinstance(dim_size, int) and dim_size <= bs:
                            grid_dims.append(None)
                        elif flat_decomp is not None and bid in flat_decomp:
                            grid_dims.append(flat_decomp[bid])
                        else:
                            grid_dims.append(block_id_to_grid_dim[bid])
                        continue
                block_shape.append(None)
                grid_dims.append(None)
            result.append((tuple(block_shape), tuple(grid_dims)))
        return result

    def _compute_pad_info(
        self,
        sorted_args: list[Argument] | None,
        config: Config,
    ) -> list[tuple[int, int, int, int]] | None:
        """Identify pl.ds() dims that may need padding and their block sizes.

        Uses ``pallas_pad_info`` recorded during codegen to identify which
        tensor dimensions use ``pl.ds()`` slicing.

        Returns ``[(arg_index, tensor_dim, block_size, extra_pad), ...]``
        or ``None``.  The launcher computes the actual pad amount at runtime
        as ``(-tensor.shape[dim]) % block_size + extra_pad``.

        ``extra_pad`` is 0 when the tile loop starts at offset 0,
        ``begin % block_size`` for a constant begin offset, or
        ``block_size - 1`` for a data-dependent begin.
        """
        if sorted_args is None:
            return None

        from .compile_environment import CompileEnvironment
        from .device_function import DeviceFunction
        from .device_function import TensorArg

        env = CompileEnvironment.current()
        device_fn = DeviceFunction.current()
        if not device_fn.pallas_pad_info:
            return None

        result: list[tuple[int, int, int, int]] = []
        for i, arg in enumerate(sorted_args):
            if not isinstance(arg, TensorArg):
                continue
            dims_info = device_fn.pallas_pad_info.get(id(arg.fake_value))
            if dims_info is not None:
                for dim, (block_id, extra_pad) in dims_info.items():
                    bsi = env.block_sizes[block_id]
                    bs = bsi.from_config(config)
                    if isinstance(bs, int) and bs > 1:
                        result.append((i, dim, bs, extra_pad))

        return result or None

    def build_launcher_args(
        self,
        args: list[str],
        *,
        tensor_host_args: list[str],
        has_rng_ops: bool,
        config: Config,
        has_barrier: bool,
        sorted_args: list[Argument] | None = None,
    ) -> list[str]:
        # Determine which arg positions are outputs.  A tensor is an output if:
        #   1. It was created inside the function body (not in input_sources), OR
        #   2. It is a function parameter that is mutated in-place (e.g. x[tile] += ...)
        from .compile_environment import CompileEnvironment
        from .device_function import DeviceFunction
        from .device_function import TensorArg
        from .host_function import HostFunction

        device_fn = DeviceFunction.current()

        def _empty_allocated_vars(body: list[ast.stmt]) -> set[str]:
            """Return names of variables allocated with torch.empty/empty_like/new_empty.

            Only checks top-level assignments; allocations nested inside
            if/with/try are conservatively missed (treated as needing input,
            which is correct but suboptimal).
            """
            result: set[str] = set()
            for stmt in body:
                if (
                    isinstance(stmt, ast.Assign)
                    and len(stmt.targets) == 1
                    and isinstance(stmt.targets[0], ast.Name)
                    and isinstance(stmt.value, ast.Call)
                    and isinstance(stmt.value.func, ast.Attribute)
                    and stmt.value.func.attr in ("empty", "empty_like", "new_empty")
                ):
                    result.add(stmt.targets[0].id)
            return result

        output_indices: list[int] = []
        # Indices of output tensors that are also read by the kernel
        # (inplace-mutated params or body-created tensors the kernel reads).
        # These must use VMEM BlockSpecs. Output-only tensors (written but
        # never read) get HBM in_specs to avoid VMEM pressure.
        inplace_indices: list[int] = []
        if sorted_args is not None:
            env = CompileEnvironment.current()
            host_fn = HostFunction.current()
            read_names, write_names = device_fn.get_tensor_read_write_names()
            mutated_params = write_names & {a.arg for a in host_fn.args.args}
            input_storages = {id(t.untyped_storage()) for t in env.input_sources}
            # Only tensors allocated with torch.empty/empty_like/new_empty can be
            # output-only — their initial values are undefined, so it's safe
            # to use HBM BlockSpecs.  Tensors allocated with torch.zeros_like,
            # torch.full, etc. have meaningful initial values that must be
            # preserved via VMEM BlockSpecs.
            empty_vars = _empty_allocated_vars(host_fn.body)
            for i, arg in enumerate(sorted_args):
                if not isinstance(arg, TensorArg):
                    continue
                if id(arg.fake_value.untyped_storage()) not in input_storages:
                    # Tensor created inside the function body (output)
                    output_indices.append(i)
                    if arg.host_str() in read_names or arg.host_str() not in empty_vars:
                        # Also read by the kernel (e.g. broadcast result)
                        inplace_indices.append(i)
                elif arg.host_str() in mutated_params:
                    # Input tensor mutated in-place
                    output_indices.append(i)
                    inplace_indices.append(i)

        # Collect output-only tensor names so codegen can retarget their
        # allocations to ``device='meta'`` and capture the launcher return.
        output_only_set = set(output_indices) - set(inplace_indices)
        output_only_names: list[str] = []
        if sorted_args is not None:
            for i in output_indices:
                if i in output_only_set:
                    arg = sorted_args[i]
                    assert isinstance(arg, TensorArg)
                    output_only_names.append(arg.host_str())
        self._output_only_names = output_only_names

        launcher_args = [*args, f"_output_indices={output_indices}"]
        launcher_args.append(f"_inplace_indices={inplace_indices}")

        if has_rng_ops:
            launcher_args.insert(-1, "_rng_seed_buffer")

        block_spec_info = self._compute_block_spec_info(sorted_args, config)
        if block_spec_info is not None:
            if has_rng_ops:
                block_spec_info.append(None)  # RNG seed buffer is untiled
            launcher_args.append(f"_block_spec_info={block_spec_info!r}")

        pad_info = self._compute_pad_info(sorted_args, config)
        if pad_info:
            launcher_args.append(f"_ds_pad_dims={pad_info!r}")

        from .device_function import PallasMemorySpace

        mem_space = device_fn.pallas_memory_space
        if sorted_args is not None:
            smem_arg_indices = [
                i
                for i, arg in enumerate(sorted_args)
                if isinstance(arg, TensorArg)
                and mem_space.get(id(arg.fake_value)) == PallasMemorySpace.SMEM
            ]
            if smem_arg_indices:
                launcher_args.append(f"_smem_arg_indices={smem_arg_indices!r}")

        # Pass scratch shapes for pipeline/fori_loop launcher
        pallas_loop_type = config.get("pallas_loop_type", "unroll")
        if pallas_loop_type in ("emit_pipeline", "fori_loop"):
            scratch_shapes = [
                (
                    s.shape,
                    self.dtype_str(s.dtype) if s.dtype is not None else None,
                    s.scratch_type,
                )
                for s in device_fn._scratch_args
            ]
            if scratch_shapes:
                launcher_args.append(f"_scratch_shapes={scratch_shapes!r}")

            # Identify which launcher arg positions correspond to pipeline-body
            # tensors (need HBM refs); all others get proper BlockSpecs.
            from .device_function import TensorArg

            if sorted_args is not None:
                pipeline_arg_indices = [
                    i
                    for i, arg in enumerate(sorted_args)
                    if isinstance(arg, TensorArg)
                    and mem_space.get(id(arg.fake_value)) == PallasMemorySpace.HBM
                ]
                if pipeline_arg_indices:
                    launcher_args.append(
                        f"_pipeline_arg_indices={pipeline_arg_indices!r}"
                    )

        if CompileEnvironment.current().settings.pallas_interpret:
            launcher_args.append("_pallas_interpret=True")

        return launcher_args

    def build_launcher_name(self, config: Config) -> str:
        """Return the launcher name to use based on ``pallas_loop_type``."""
        from ..autotuner.config_spec import VALID_PALLAS_LOOP_TYPES

        pallas_loop_type = config.get("pallas_loop_type", "unroll")
        if pallas_loop_type not in VALID_PALLAS_LOOP_TYPES:
            raise ValueError(
                f"Invalid pallas_loop_type {pallas_loop_type!r}. "
                f"Expected one of {VALID_PALLAS_LOOP_TYPES}."
            )
        if pallas_loop_type == "emit_pipeline":
            return "_default_pallas_pipeline_launcher"
        if pallas_loop_type == "fori_loop":
            return "_default_pallas_fori_launcher"
        return self.default_launcher_name

    def get_launcher_name(self) -> str:
        """Return the launcher name based on the current config."""
        from .device_function import DeviceFunction
        from .device_function import NoCurrentFunction

        try:
            device_fn = DeviceFunction.current()
        except NoCurrentFunction:
            return self.default_launcher_name
        return self.build_launcher_name(device_fn.config)

    def pre_codegen(
        self,
        graphs: list[GraphInfo],
        config: Config,
        tile_strategy: TileStrategyDispatch,
    ) -> None:
        from .pallas.plan_tiling import plan_tiling

        plan_tiling(graphs, config, tile_strategy)


def _detect_mma_loop(
    fn: DeviceFunction,
    block_ids: list[int],
    *,
    block_sizes: Sequence[int | torch.SymInt],
    num_threads_config: Sequence[int],
) -> bool:
    """Check if a device loop contains a matmul with MMA-compatible dtypes.

    Returns True only when the loop contains a compatible addmm/dot AND
    the grid has at least 2 block IDs (M and N), so the MMA pipeline
    can map them to tile offsets.  Three-level loops (grid[M] +
    device_loop[N] + device_loop[K]) are NOT supported yet.
    """
    from ..language._decorators import is_api_func
    from .cute.cute_mma import can_codegen_cute_mma_aten
    from .cute.cute_mma import can_codegen_cute_mma_dot
    from .device_ir import ForLoopGraphInfo
    from .host_function import HostFunction

    # MMA lowering currently relies on a single grid state that carries
    # both the M and N axes. Nested grid loops like grid[M] + grid[N] do
    # not satisfy that requirement because GenerateAST.current_grid_state
    # only tracks the innermost grid.
    device_ir = HostFunction.current().device_ir
    if len(device_ir.grid_block_ids) != 1:
        return False
    if len(device_ir.grid_block_ids[0]) != 2:
        return False
    root_grid_ids = set(device_ir.grid_block_ids[0])
    # CuTe MMA fragment partitioning is currently keyed to physical threads.
    # When an M/N tile is partially serialized into lane loops, the same
    # fragment would be reused for multiple logical lanes and produce
    # incorrect results. A pure K reduction loop is different: it does not
    # contribute MMA fragment coordinates, so we can still enable mma_mode
    # there to suppress synthetic lane loops around the K body.
    if any(
        block_id in root_grid_ids and threads > 0 and threads < block_size
        for block_id, block_size, threads in zip(
            block_ids,
            block_sizes,
            num_threads_config,
            strict=False,
        )
    ):
        return False
    for graph_info in fn.codegen.codegen_graphs:
        if not isinstance(graph_info, ForLoopGraphInfo):
            continue
        if graph_info.block_ids != block_ids:
            continue
        for node in graph_info.graph.nodes:
            if node.op != "call_function":
                continue
            # Only addmm/baddbmm trigger MMA mode — mm/bmm don't have
            # a built-in accumulator so their result is needed per iteration.
            if node.target in (
                torch.ops.aten.addmm.default,
                torch.ops.aten.baddbmm.default,
            ) and can_codegen_cute_mma_aten(node, with_acc=True):
                return True
            if (
                callable(node.target)
                and is_api_func(node.target)
                and getattr(node.target, "__name__", "") == "dot"
                and can_codegen_cute_mma_dot(node)
            ):
                return True
    return False


def _detect_specialized_mma_loop(
    fn: DeviceFunction,
    block_ids: list[int],
    *,
    block_sizes: Sequence[int | torch.SymInt],
    config: Config,
) -> bool:
    from ..language._decorators import is_api_func
    from .compile_environment import CompileEnvironment
    from .cute.cute_mma import _choose_mma_impl
    from .cute.cute_mma import _mma_active_n_threads
    from .cute.cute_mma import _tcgen05_root_m_threads
    from .cute.cute_mma import can_codegen_cute_mma_aten
    from .cute.cute_mma import can_codegen_cute_mma_dot
    from .host_function import HostFunction

    device_ir = HostFunction.current().device_ir
    if len(device_ir.grid_block_ids) != 1:
        return False
    root_grid_ids = device_ir.grid_block_ids[0]
    if len(root_grid_ids) != 2:
        return False
    if len(block_ids) != 1 or any(block_id in root_grid_ids for block_id in block_ids):
        return False

    env = CompileEnvironment.current()
    root_block_sizes: list[int] = []
    root_thread_counts: list[int] = []
    root_thread_auto: list[bool] = []
    for block_id in root_grid_ids:
        block_size = env.block_sizes[block_id].from_config(config)
        if not isinstance(block_size, int):
            return False
        root_block_sizes.append(block_size)
        threads = env.config_spec.num_threads.config_get(
            config.num_threads, block_id, 0
        )
        resolved_threads = threads if threads > 0 else block_size
        root_thread_counts.append(resolved_threads)
        root_thread_auto.append(threads == 0)

    if functools.reduce(operator.mul, root_thread_counts, 1) > 1024:

        def _largest_divisor_at_most(size: int, limit: int) -> int:
            for divisor in range(limit, 0, -1):
                if size % divisor == 0:
                    return divisor
            return 1

        for idx in sorted(
            (i for i, is_auto in enumerate(root_thread_auto) if is_auto),
            reverse=True,
        ):
            other_threads = functools.reduce(
                operator.mul,
                (
                    root_thread_counts[j]
                    for j in range(len(root_thread_counts))
                    if j != idx
                ),
                1,
            )
            if other_threads <= 0:
                continue
            thread_budget = max(1024 // other_threads, 1)
            next_threads = _largest_divisor_at_most(
                root_block_sizes[idx], thread_budget
            )
            root_thread_counts[idx] = next_threads
            if functools.reduce(operator.mul, root_thread_counts, 1) <= 1024:
                break

    (bk,) = block_sizes
    if not isinstance(bk, int):
        return False
    bm, bn = root_block_sizes
    root_m_threads, root_n_threads = root_thread_counts

    def root_threads_support_impl(mma_impl: str) -> bool:
        if mma_impl == "tcgen05":
            mma_n_threads = _mma_active_n_threads("tcgen05")
            min_root_m_threads = _tcgen05_root_m_threads(bm, bn)
            if (
                root_m_threads < min_root_m_threads
                or root_m_threads > bm
                or bm % root_m_threads != 0
            ):
                return False
            if root_n_threads < mma_n_threads or root_n_threads > bn:
                return False
            if bn % root_n_threads != 0:
                return False
            return root_m_threads * root_n_threads <= 1024
        if mma_impl == "warp":
            return root_m_threads == bm and root_n_threads == bn
        return False

    for graph_info in fn.codegen.codegen_graphs:
        if getattr(graph_info, "block_ids", None) != block_ids:
            continue
        for node in graph_info.graph.nodes:
            if node.op != "call_function":
                continue
            if node.target in (
                torch.ops.aten.addmm.default,
                torch.ops.aten.baddbmm.default,
            ) and can_codegen_cute_mma_aten(node, with_acc=True):
                lhs_node = node.args[1]
                if not isinstance(lhs_node, torch.fx.Node):
                    continue
                lhs_val = lhs_node.meta.get("val")
                if not isinstance(lhs_val, torch.Tensor):
                    continue
                mma_impl = _choose_mma_impl(
                    lhs_val.dtype, bm=bm, bn=bn, bk=bk, config=config
                )
                if mma_impl != "universal" and root_threads_support_impl(mma_impl):
                    return True
            if (
                callable(node.target)
                and is_api_func(node.target)
                and getattr(node.target, "__name__", "") == "dot"
                and can_codegen_cute_mma_dot(node)
            ):
                lhs_node = node.args[0]
                if not isinstance(lhs_node, torch.fx.Node):
                    continue
                lhs_val = lhs_node.meta.get("val")
                if not isinstance(lhs_val, torch.Tensor):
                    continue
                mma_impl = _choose_mma_impl(
                    lhs_val.dtype, bm=bm, bn=bn, bk=bk, config=config
                )
                if mma_impl != "universal" and root_threads_support_impl(mma_impl):
                    return True
    return False


def _is_mma_candidate_loop(
    fn: DeviceFunction,
    block_ids: list[int],
    *,
    block_sizes: Sequence[int | torch.SymInt],
    num_threads_config: Sequence[int],
    grid_ids: set[int],
) -> bool:
    if not any(bid not in grid_ids for bid in block_ids):
        return False
    resolved_threads: list[int] = [
        num_threads
        if num_threads > 0
        else int(block_size)
        if isinstance(block_size, int)
        else 0
        for block_size, num_threads in zip(block_sizes, num_threads_config, strict=True)
    ]
    return _detect_mma_loop(
        fn,
        block_ids,
        block_sizes=block_sizes,
        num_threads_config=resolved_threads,
    )


def _loop_may_use_mma(
    fn: DeviceFunction,
    block_ids: list[int],
) -> bool:
    from ..language._decorators import is_api_func
    from .cute.cute_mma import can_codegen_cute_mma_aten
    from .cute.cute_mma import can_codegen_cute_mma_dot
    from .device_ir import RootGraphInfo
    from .host_function import HostFunction

    device_ir = HostFunction.current().device_ir
    graph_by_id = {
        graph_info.graph_id: graph_info
        for graph_info in fn.codegen.codegen_graphs
        if hasattr(graph_info, "graph")
    }

    def graph_contains_mma(graph: object) -> bool:
        if not isinstance(graph, torch.fx.Graph):
            return False
        for node in graph.nodes:
            if node.op != "call_function":
                continue
            if node.target in (
                torch.ops.aten.addmm.default,
                torch.ops.aten.baddbmm.default,
            ) and can_codegen_cute_mma_aten(node, with_acc=True):
                return True
            if (
                callable(node.target)
                and is_api_func(node.target)
                and getattr(node.target, "__name__", "") == "dot"
                and can_codegen_cute_mma_dot(node)
            ):
                return True
            if is_api_func(node.target) and getattr(node.target, "__name__", "") in {
                "_for_loop",
                "_for_loop_step",
            }:
                graph_id = node.args[0] if node.args else None
                if isinstance(graph_id, int):
                    nested = graph_by_id.get(graph_id)
                    if nested is not None and graph_contains_mma(nested.graph):
                        return True
        return False

    def graph_matches_loop(graph_info: object) -> bool:
        if getattr(graph_info, "block_ids", None) == block_ids:
            return True
        if not isinstance(graph_info, RootGraphInfo):
            return False
        phase_index = graph_info.phase_index
        return (
            0 <= phase_index < len(device_ir.grid_block_ids)
            and device_ir.grid_block_ids[phase_index] == block_ids
        )

    for graph_info in fn.codegen.codegen_graphs:
        if not graph_matches_loop(graph_info):
            continue
        if graph_contains_mma(getattr(graph_info, "graph", None)):
            return True
    return False


def _kernel_has_specialized_mma_path(
    fn: DeviceFunction,
    *,
    config: Config,
) -> bool:
    from .compile_environment import CompileEnvironment
    from .device_ir import ForLoopGraphInfo
    from .host_function import HostFunction

    env = CompileEnvironment.current()
    grid_ids = {
        bid for ids in HostFunction.current().device_ir.grid_block_ids for bid in ids
    }
    seen_block_ids: set[tuple[int, ...]] = set()
    for graph_info in fn.codegen.codegen_graphs:
        if not isinstance(graph_info, ForLoopGraphInfo):
            continue
        block_ids = tuple(graph_info.block_ids)
        if block_ids in seen_block_ids or not any(
            bid not in grid_ids for bid in block_ids
        ):
            continue
        seen_block_ids.add(block_ids)
        block_sizes: list[int | torch.SymInt] = []
        for bid in block_ids:
            size = env.block_sizes[bid].from_config(config)
            if not isinstance(size, (int, torch.SymInt)):
                break
            block_sizes.append(size)
        else:
            if _detect_specialized_mma_loop(
                fn,
                list(block_ids),
                block_sizes=block_sizes,
                config=config,
            ):
                return True
    return False


def _kernel_specialized_mma_impl(
    fn: DeviceFunction,
    *,
    config: Config,
) -> str | None:
    from ..language._decorators import is_api_func
    from .compile_environment import CompileEnvironment
    from .cute.cute_mma import _choose_mma_impl
    from .cute.cute_mma import can_codegen_cute_mma_aten
    from .cute.cute_mma import can_codegen_cute_mma_dot
    from .device_ir import ForLoopGraphInfo
    from .host_function import HostFunction

    env = CompileEnvironment.current()
    grid_ids = {
        bid for ids in HostFunction.current().device_ir.grid_block_ids for bid in ids
    }
    seen_block_ids: set[tuple[int, ...]] = set()
    for graph_info in fn.codegen.codegen_graphs:
        if not isinstance(graph_info, ForLoopGraphInfo):
            continue
        block_ids = tuple(graph_info.block_ids)
        if block_ids in seen_block_ids or not any(
            bid not in grid_ids for bid in block_ids
        ):
            continue
        seen_block_ids.add(block_ids)
        block_sizes = [env.block_sizes[bid].from_config(config) for bid in block_ids]
        if len(block_sizes) != 1 or not isinstance(block_sizes[0], int):
            continue
        bk = block_sizes[0]
        host_device_ir = HostFunction.current().device_ir
        if len(host_device_ir.grid_block_ids) != 1:
            continue
        root_grid_ids = host_device_ir.grid_block_ids[0]
        if len(root_grid_ids) != 2:
            continue
        bm = env.block_sizes[root_grid_ids[0]].from_config(config)
        bn = env.block_sizes[root_grid_ids[1]].from_config(config)
        if not isinstance(bm, int) or not isinstance(bn, int):
            continue
        for node in graph_info.graph.nodes:
            if node.op != "call_function":
                continue
            if node.target in (
                torch.ops.aten.addmm.default,
                torch.ops.aten.baddbmm.default,
            ) and can_codegen_cute_mma_aten(node, with_acc=True):
                lhs_node = node.args[1]
            elif (
                callable(node.target)
                and is_api_func(node.target)
                and getattr(node.target, "__name__", "") == "dot"
                and can_codegen_cute_mma_dot(node)
            ):
                lhs_node = node.args[0]
            else:
                continue
            if not isinstance(lhs_node, torch.fx.Node):
                continue
            lhs_val = lhs_node.meta.get("val")
            if not isinstance(lhs_val, torch.Tensor):
                continue
            mma_impl = _choose_mma_impl(
                lhs_val.dtype, bm=bm, bn=bn, bk=bk, config=config
            )
            if mma_impl != "universal":
                return mma_impl
    return None


def _loop_contains_matmul(
    fn: DeviceFunction,
    block_ids: list[int],
) -> bool:
    from ..language._decorators import is_api_func
    from .device_ir import RootGraphInfo
    from .host_function import HostFunction

    matmul_targets = {
        torch.ops.aten.mm.default,
        torch.ops.aten.addmm.default,
        torch.ops.aten.bmm.default,
        torch.ops.aten.baddbmm.default,
    }
    device_ir = HostFunction.current().device_ir
    graph_by_id = {
        graph_info.graph_id: graph_info
        for graph_info in fn.codegen.codegen_graphs
        if hasattr(graph_info, "graph")
    }

    def graph_contains_matmul(graph: object) -> bool:
        if not isinstance(graph, torch.fx.Graph):
            return False
        for node in graph.nodes:
            if node.op != "call_function":
                continue
            if node.target in matmul_targets:
                return True
            if is_api_func(node.target):
                name = getattr(node.target, "__name__", "")
                if name == "dot":
                    return True
                if name in {"_for_loop", "_for_loop_step"}:
                    graph_id = node.args[0] if node.args else None
                    if isinstance(graph_id, int):
                        nested = graph_by_id.get(graph_id)
                        if nested is not None and graph_contains_matmul(nested.graph):
                            return True
        return False

    def graph_matches_loop(graph_info: object) -> bool:
        if getattr(graph_info, "block_ids", None) == block_ids:
            return True
        if not isinstance(graph_info, RootGraphInfo):
            return False
        phase_index = graph_info.phase_index
        return (
            0 <= phase_index < len(device_ir.grid_block_ids)
            and device_ir.grid_block_ids[phase_index] == block_ids
        )

    for graph_info in fn.codegen.codegen_graphs:
        if not graph_matches_loop(graph_info):
            continue
        if graph_contains_matmul(graph_info.graph):
            return True
    return False


def _loop_contains_atomic(
    fn: DeviceFunction,
    block_ids: list[int],
) -> bool:
    from ..language._decorators import is_api_func
    from ..language.atomic_ops import ATOMIC_OPS as atomic_targets
    from .device_ir import RootGraphInfo
    from .host_function import HostFunction

    device_ir = HostFunction.current().device_ir
    graph_by_id = {
        graph_info.graph_id: graph_info
        for graph_info in fn.codegen.codegen_graphs
        if hasattr(graph_info, "graph")
    }

    def graph_contains_atomic(graph: object) -> bool:
        if not isinstance(graph, torch.fx.Graph):
            return False
        for node in graph.nodes:
            if node.op != "call_function":
                continue
            if node.target in atomic_targets:
                return True
            if is_api_func(node.target) and getattr(node.target, "__name__", "") in {
                "_for_loop",
                "_for_loop_step",
            }:
                graph_id = node.args[0] if node.args else None
                if isinstance(graph_id, int):
                    nested = graph_by_id.get(graph_id)
                    if nested is not None and graph_contains_atomic(nested.graph):
                        return True
        return False

    def graph_matches_loop(graph_info: object) -> bool:
        if getattr(graph_info, "block_ids", None) == block_ids:
            return True
        if not isinstance(graph_info, RootGraphInfo):
            return False
        phase_index = graph_info.phase_index
        return (
            0 <= phase_index < len(device_ir.grid_block_ids)
            and device_ir.grid_block_ids[phase_index] == block_ids
        )

    for graph_info in fn.codegen.codegen_graphs:
        if not graph_matches_loop(graph_info):
            continue
        if graph_contains_atomic(getattr(graph_info, "graph", None)):
            return True
    return False


def _graph_used_block_ids(
    fn: DeviceFunction,
    block_ids: list[int],
) -> set[int]:
    from .compile_environment import CompileEnvironment
    from .device_ir import RootGraphInfo
    from .host_function import HostFunction

    env = CompileEnvironment.current()
    device_ir = HostFunction.current().device_ir
    candidate_block_ids = set(block_ids)
    used: set[int] = set()

    def visit_value(value: object) -> None:
        if isinstance(value, torch.Tensor):
            for dim in value.shape:
                visit_value(dim)
            return
        if isinstance(value, torch.SymInt):
            block_id = env.get_block_id(value)
            if block_id is not None and block_id in candidate_block_ids:
                used.add(block_id)
            raw_expr = getattr(getattr(value, "node", None), "_expr", None)
            if isinstance(raw_expr, sympy.Expr):
                visit_value(raw_expr)
            return
        if isinstance(value, sympy.Expr):
            for symbol in value.free_symbols:
                block_id = env.get_block_id(symbol)
                if block_id is not None and block_id in candidate_block_ids:
                    used.add(block_id)
            return
        if isinstance(value, dict):
            for key, item in value.items():
                visit_value(key)
                visit_value(item)
            return
        if isinstance(value, (list, tuple)):
            for item in value:
                visit_value(item)

    def is_tensor_like_value(value: object) -> bool:
        if isinstance(value, torch.Tensor):
            return True
        if isinstance(value, dict):
            return any(
                is_tensor_like_value(key) or is_tensor_like_value(item)
                for key, item in value.items()
            )
        if isinstance(value, (list, tuple)):
            return any(is_tensor_like_value(item) for item in value)
        return False

    for block_id in candidate_block_ids:
        block_info = env.block_sizes[block_id]
        if block_info.reduction:
            used.add(block_id)

    def graph_matches_loop(graph_info: object) -> bool:
        if getattr(graph_info, "block_ids", None) == block_ids:
            return True
        if not isinstance(graph_info, RootGraphInfo):
            return False
        try:
            phase_index = device_ir.root_ids.index(graph_info.graph_id)
        except ValueError:
            return False
        return (
            0 <= phase_index < len(device_ir.grid_block_ids)
            and device_ir.grid_block_ids[phase_index] == block_ids
        )

    for graph_info in fn.codegen.codegen_graphs:
        if not graph_matches_loop(graph_info):
            continue
        graph = getattr(graph_info, "graph", None)
        if graph is None:
            continue
        for node in graph.nodes:
            value = node.meta.get("val")
            if is_tensor_like_value(value):
                visit_value(value)
                for arg in node.args:
                    if is_tensor_like_value(arg):
                        visit_value(arg)
                for arg in node.kwargs.values():
                    if is_tensor_like_value(arg):
                        visit_value(arg)
    return used


def _active_loop_block_ids(fn: DeviceFunction) -> set[int]:
    from .host_function import HostFunction

    device_ir = HostFunction.current().device_ir
    active: set[int] = {
        block_id for block_ids in device_ir.grid_block_ids for block_id in block_ids
    }
    for graph_info in fn.codegen.codegen_graphs:
        block_ids = getattr(graph_info, "block_ids", None)
        if block_ids is None:
            continue
        active.update(block_ids)
    return active


class CuteBackend(Backend):
    """CuTe DSL (CUTLASS Python DSL) code generation backend."""

    @property
    def name(self) -> str:
        return "cute"

    def pre_codegen(
        self,
        graphs: list[GraphInfo],
        config: Config,
        tile_strategy: TileStrategyDispatch,
    ) -> None:
        from .cute.layout_propagation import plan_layouts

        plan_layouts(graphs, config, tile_strategy)

    def supports_config_key(self, key: str) -> bool:
        if key == "num_threads" or key.startswith("tcgen05_"):
            return True
        return super().supports_config_key(key)

    def dtype_str(self, dtype: torch.dtype) -> str:
        from torch._inductor.codegen.cutedsl.cutedsl_op_overrides import (
            CuteDSLOpOverrides,
        )

        if (
            inductor_dtype := CuteDSLOpOverrides.TORCH_TO_CUTE_DTYPE.get(dtype)
        ) is not None:
            return inductor_dtype
        if dtype is torch.float4_e2m1fn_x2:
            # PyTorch's shell dtype stores two E2M1 values in one byte.  CuTe
            # does not support scalar dereference for its 4-bit type yet, so
            # SIMT scalar loads treat the tensor as raw byte storage.
            return "cutlass.Uint8"
        if dtype is torch.uint64:
            return "cutlass.Int64"

        raise ValueError(f"Unsupported dtype for Cute backend: {dtype}")

    def acc_type(self, dtype: torch.dtype) -> str:
        if dtype in (torch.float16, torch.bfloat16):
            return "cutlass.Float32"
        return self.dtype_str(dtype)

    def supports_precompile(self) -> bool:
        # The CuTe DSL does not expose a Triton-style precompile entry point;
        # the autotuner has to compile + benchmark each config inline.
        return False

    def classify_autotune_exception(self, err: BaseException) -> str | None:
        # Exceptions raised from inside the cute/cutlass DSL during compile or
        # launch are expected when an invalid config is tried; treat them as
        # benign so the autotuner moves on. Anything else (AssertionError,
        # NameError/TypeError/AttributeError from generated code, ...) is
        # almost certainly a real Helion bug and is surfaced at warn level so
        # it gets noticed without terminating tuning.
        cls = type(err)
        module = getattr(cls, "__module__", "") or ""
        if module.startswith(("cutlass", "cute")):
            return "debug"
        if isinstance(err, Exception):
            return "warn"
        return None

    def get_do_bench(self) -> Callable[..., float | tuple[float, ...]]:
        # The default Triton do_bench uses CUDA events that mis-time the CuTe
        # path on Blackwell - launches show up as ~5ms when the kernel is
        # actually 250ms+. Use synchronized wall-clock timing instead so
        # autotune scores reflect real performance.
        from ..autotuner.benchmarking import do_bench_generic

        return do_bench_generic

    def get_interleaved_bench(self) -> Callable[..., list[float]]:
        # Same rationale as get_do_bench: the default interleaved bench uses
        # CUDA events that mis-time the CuTe path. Use the synchronized
        # wall-clock fallback so the autotuner's interleaved compare path
        # produces real timings.
        from ..autotuner.benchmarking import interleaved_bench_generic

        return interleaved_bench_generic

    def autotune(
        self,
        bound_kernel: BoundKernel[Any],
        args: Sequence[object],
        *,
        force: bool = True,
        **kwargs: object,
    ) -> Config:
        return super().autotune(bound_kernel, args, force=force, **kwargs)

    @property
    def function_decorator(self) -> str:
        return "cute.kernel"

    @property
    def constexpr_type(self) -> str:
        return "cutlass.Constexpr"

    def inline_constexpr(self, name: str, value: str) -> str:
        return f"{name} = {value}"

    @property
    def default_launcher_name(self) -> str:
        return "_default_cute_launcher"

    @property
    def library_imports(self) -> dict[str, str]:
        return {
            "math": "import math",
            "operator": "import operator",
            "torch": "import torch",
            "helion": "import helion",
            "hl": "import helion.language as hl",
            "cutlass": "import cutlass",
            "cute": "import cutlass.cute as cute",
            "_default_cute_launcher": "from helion.runtime import default_cute_launcher as _default_cute_launcher",
            "_next_power_of_2": "from helion._utils import next_power_of_2 as _next_power_of_2",
            "_cute_argreduce_index": "from helion._compiler.cute.reduce_helpers import _cute_argreduce_index",
            "_cute_grouped_reduce_shared_tree": "from helion._compiler.cute.reduce_helpers import _cute_grouped_reduce_shared_tree",
            "_cute_grouped_reduce_shared_two_stage": "from helion._compiler.cute.reduce_helpers import _cute_grouped_reduce_shared_two_stage",
            "_cute_grouped_reduce_warp": "from helion._compiler.cute.reduce_helpers import _cute_grouped_reduce_warp",
            "_cute_store_shared_remote_x4": "from helion._compiler.cute.cluster_helpers import store_shared_remote_x4 as _cute_store_shared_remote_x4",
            "_cute_issue_clc_query_nomulticast": "from helion._compiler.cute.clc_helpers import issue_clc_query_nomulticast as _cute_issue_clc_query_nomulticast",
            "_cute_inline_asm_elementwise": "from helion._compiler.cute.inline_asm_helpers import inline_asm_elementwise as _cute_inline_asm_elementwise",
            "_cute_fp8e4m3fn_to_float32": "from helion._compiler.cute.quantized_helpers import fp8e4m3fn_to_float32 as _cute_fp8e4m3fn_to_float32",
            "_cute_float4_e2m1fn_x2_to_float32": "from helion._compiler.cute.quantized_helpers import float4_e2m1fn_x2_to_float32 as _cute_float4_e2m1fn_x2_to_float32",
        }

    def program_id_expr(self, dim: int, *, index_dtype: str) -> str:
        return f"{index_dtype}(cute.arch.block_idx()[{dim}])"

    def inductor_op_overrides(self) -> InductorOpOverrides:
        from torch._inductor.codegen.cutedsl.cutedsl_op_overrides import CuteDSLArg
        from torch._inductor.codegen.cutedsl.cutedsl_op_overrides import (
            CuteDSLOpOverrides,
        )

        class HelionCuteDSLOpOverrides(CuteDSLOpOverrides):
            @staticmethod
            def where(
                condition: CuteDSLArg,
                a: CuteDSLArg,
                b: CuteDSLArg,
            ) -> CuteDSLArg:
                tensor_arg = (
                    HelionCuteDSLOpOverrides._get_cse_var(a)
                    or HelionCuteDSLOpOverrides._get_cse_var(b)
                    or HelionCuteDSLOpOverrides._get_cse_var(condition)
                )
                if tensor_arg is not None:
                    return CuteDSLOpOverrides.where(condition, a, b)
                return f"(({a}) if ({condition}) else ({b}))"

        return HelionCuteDSLOpOverrides()

    def cast_expr(self, expr_str: str, dtype_str: str) -> str:
        return f"{dtype_str}({expr_str})"

    def cast_ast(self, x: ast.AST, target_dtype: torch.dtype) -> ast.AST:
        from .device_function import DeviceFunction
        from .device_function import NoCurrentFunction

        if isinstance(x, ast.Name):
            try:
                df = DeviceFunction.current()
            except NoCurrentFunction:
                pass
            else:
                if df.get_cute_tcgen05_store_value(x.id) is not None:
                    return x
        return super().cast_ast(x, target_dtype)

    def grid_barrier_stmt(self, sem_arg: str) -> str | None:
        del sem_arg
        raise exc.BackendUnsupported(self.name, "hl.barrier()")

    def lane_index_expr(
        self, offset_var: str, elements_per_thread: int, *, axis: int
    ) -> str:
        from .compile_environment import CompileEnvironment

        index_dtype = CompileEnvironment.current().index_type()
        return (
            f"{offset_var} + {index_dtype}(cute.arch.thread_idx()[{axis}])"
            f" * {elements_per_thread}"
        )

    def lane_offset_expr(self, lane_var: str) -> str:
        return f"cutlass.Int32({lane_var})"

    def sympy_printer_expr(self, expr: sympy.Expr) -> str:
        from .device_function import cute_texpr

        return cute_texpr(expr)

    def range_str(
        self,
        begin: str | None,
        end: str,
        step: str | None,
    ) -> str | None:
        range_args = []
        if begin is not None:
            range_args.append(f"cutlass.Int32({begin})")
        range_args.append(f"cutlass.Int32({end})")
        if step is not None and step != "1":
            range_args.append(f"cutlass.Int32({step})")
        return f"range({', '.join(range_args)})"

    def arange_expr(
        self,
        offsets_var: str,
        lid: str,
        block_size_var: str,
        dtype: str,
        *,
        axis: int = 0,
    ) -> str:
        return (
            f"{offsets_var} = ({lid}) * ({block_size_var})"
            f" + {dtype}(cute.arch.thread_idx()[{axis}])"
        )

    def grid_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        if axis >= 3 and block_size_var != "1":
            raise exc.BackendUnsupported(self.name, f"thread axis {axis}")
        if block_size_var == "1":
            return offset_var
        return f"{offset_var} + {dtype}(cute.arch.thread_idx()[{axis}])"

    def loop_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        return self.grid_index_expr(offset_var, block_size_var, dtype, axis=axis)

    def scalar_load_expr(self, tensor_name: str, index_expr: str | None = None) -> str:
        if index_expr is None:
            index_expr = "0"
        return f"({tensor_name})[{index_expr}]"

    def max_reduction_threads(self) -> int | None:
        return 32

    def adjust_reduction_thread_count(
        self, requested: int, existing_strategies: list[TileStrategy]
    ) -> int:
        from .cute.thread_budget import MAX_THREADS_PER_BLOCK
        from .reduction_strategy import ReductionStrategy

        if requested <= 1:
            return requested
        other_threads = 1
        for strategy in existing_strategies:
            if isinstance(strategy, ReductionStrategy):
                count = strategy._reduction_thread_count()
                if count > 0:
                    other_threads *= count
            else:
                for size in strategy.thread_block_sizes():
                    if size > 1:
                        other_threads *= size
        while other_threads * requested > MAX_THREADS_PER_BLOCK and requested > 1:
            requested //= 2
        return requested

    def create_synthetic_reduction_lanes(
        self,
        thread_count: int,
        size_hint: int,
    ) -> int | None:
        from torch._inductor.runtime.runtime_utils import next_power_of_2

        if thread_count <= 0:
            return None
        padded_size = next_power_of_2(max(1, size_hint))
        if padded_size > thread_count:
            return padded_size // thread_count
        return None

    def reduction_axis_first(self) -> bool:
        return True

    def thread_in_tile_mask_expr(
        self, block_size_var: str, *, axis: int = 0
    ) -> str | None:
        return f"cutlass.Int32(cute.arch.thread_idx()[{axis}]) < ({block_size_var})"

    def force_tile_mask(self) -> bool:
        return True

    def full_expr(
        self, shape_dims: list[str], value_expr: str, dtype: torch.dtype
    ) -> str:
        # One element per thread: tile-shaped temporaries are scalars.
        return f"{self.dtype_str(dtype)}({value_expr})"

    def reshape_expr(self, expr: str, shape: str) -> str:
        return expr

    def broadcast_to_expr(self, expr: str, shape: str) -> str:
        return expr

    def where_expr(self, mask: str, true_val: str, false_val: str) -> str:
        return f"({true_val}) if ({mask}) else ({false_val})"

    def minimum_expr(self, a: str, b: str) -> str:
        from .compile_environment import CompileEnvironment

        index_type = CompileEnvironment.current().index_type()
        lhs = self.cast_expr(a, index_type)
        rhs = self.cast_expr(b, index_type)
        return f"({lhs}) if ({lhs}) < ({rhs}) else ({rhs})"

    def reduction_index_expr(
        self, block_size_var: str, dtype: str, block_idx: int, *, axis: int
    ) -> str:
        return f"cutlass.Int32(cute.arch.thread_idx()[{axis}])"

    def reduction_index_zero_expr(self, dtype: str) -> str:
        return "cutlass.Int32(0)"

    def next_power_of_2_host_expr(self, expr: str) -> str:
        return f"_next_power_of_2({expr})"

    def reduction_combine_expr(
        self,
        reduction_type: str,
        acc: str,
        val: str,
        dtype: torch.dtype,
    ) -> str:
        # Use Python ternary instead of cute.where for max/min because
        # these operate on scalar registers, not tensors.
        if reduction_type == "sum":
            return f"({acc} + {val})"
        if reduction_type == "max":
            return f"({acc}) if ({acc}) > ({val}) else ({val})"
        if reduction_type == "min":
            return f"({acc}) if ({acc}) < ({val}) else ({val})"
        if reduction_type == "prod":
            return f"({acc} * {val})"
        raise exc.BackendUnsupported(self.name, f"reduction combine {reduction_type!r}")

    def _threads_for_block_size_var(self, block_size_var: str | None) -> int:
        # threads_in_group must be a Python int literal for CuTe DSL.
        from .reduction_strategy import ReductionStrategy
        from .tile_strategy import BlockSizeTileStrategy

        threads = 32
        strategies = self._get_strategies()
        if block_size_var is not None:
            for strategy in strategies:
                if not isinstance(strategy, ReductionStrategy):
                    continue
                strategy_bs_var = strategy.block_size_var(strategy.block_index)
                if strategy_bs_var != block_size_var:
                    continue
                tc = strategy._reduction_thread_count()
                if tc > 0:
                    return tc

            # Block reductions are keyed by a tile block-size var rather than a
            # ReductionStrategy var. Recover the tile width from the owning strategy.
            for strategy in strategies:
                if not isinstance(strategy, BlockSizeTileStrategy):
                    continue
                for idx, block_id in enumerate(strategy.block_ids):
                    strategy_bs_var = strategy.block_size_var(block_id)
                    if strategy_bs_var != block_size_var:
                        continue
                    block_size = strategy.block_size
                    if isinstance(block_size, list) and idx < len(block_size):
                        block_size = block_size[idx]
                    if isinstance(block_size, int) and block_size > 0:
                        return min(block_size, 32)
            return threads

        for strategy in strategies:
            if isinstance(strategy, ReductionStrategy):
                tc = strategy._reduction_thread_count()
                if tc > 0:
                    return tc
        return threads

    def reduction_threads_hint(self, block_size_var: str | None = None) -> int | None:
        return self._threads_for_block_size_var(block_size_var)

    def reduction_expr(
        self,
        input_name: str,
        reduction_type: str,
        dim: int,
        *,
        block_size_var: str | None = None,
        threads_in_group: int | None = None,
    ) -> str:
        threads = (
            threads_in_group
            if threads_in_group is not None
            else self._threads_for_block_size_var(block_size_var)
        )
        tg = f", threads_in_group={threads}"
        if reduction_type == "sum":
            return f"cute.arch.warp_reduction_sum({input_name}{tg})"
        if reduction_type == "max":
            return f"cute.arch.warp_reduction_max({input_name}{tg})"
        if reduction_type == "min":
            return (
                f"cute.arch.warp_reduction("
                f"{input_name}, lambda a, b: (a if a < b else b){tg})"
            )
        if reduction_type == "prod":
            return f"cute.arch.warp_reduction({input_name}, lambda a, b: (a * b){tg})"
        raise exc.BackendUnsupported(self.name, f"reduction {reduction_type!r}")

    def thread_linear_index_expr(self, axis_sizes: dict[int, int]) -> str | None:
        from .compile_environment import CompileEnvironment

        index_dtype = CompileEnvironment.current().index_dtype
        index_type = self.index_type_str(index_dtype)
        if not axis_sizes:
            return self.cast_expr("0", index_type)
        stride = 1
        terms: list[str] = []
        for axis, size in sorted(axis_sizes.items()):
            term = self.cast_expr(f"cute.arch.thread_idx()[{axis}]", index_type)
            if stride != 1:
                term = f"({term}) * {self.cast_expr(repr(stride), index_type)}"
            terms.append(term)
            stride *= size
        return " + ".join(terms)

    def is_indexed_reduction(self, reduction_type: str) -> bool:
        return reduction_type in {"argmin", "argmax"}

    def argreduce_result_expr(
        self,
        input_name: str,
        index_value: str,
        reduction_type: str,
        dim: int,
        output_dtype: torch.dtype,
        *,
        block_size_var: str | None = None,
        index_dtype: torch.dtype | None = None,
        threads_in_group: int | None = None,
    ) -> str:
        if index_dtype is None:
            raise exc.BackendUnsupported(self.name, "missing index_dtype for argreduce")
        value_reduction = "min" if reduction_type == "argmin" else "max"
        reduced_value = self.reduction_expr(
            input_name,
            value_reduction,
            dim,
            block_size_var=block_size_var,
            threads_in_group=threads_in_group,
        )
        index_dtype_str = self.index_type_str(index_dtype)
        max_index = self.cast_expr(repr(torch.iinfo(index_dtype).max), index_dtype_str)
        candidate_index = f"({index_value}) if (({input_name}) == ({reduced_value})) else ({max_index})"
        reduced_index = self.reduction_expr(
            candidate_index,
            "min",
            dim,
            block_size_var=block_size_var,
            threads_in_group=threads_in_group,
        )
        return self.cast_expr(reduced_index, self.dtype_str(output_dtype))

    def argreduce_loop_update_statements(
        self,
        *,
        reduction_type: str,
        acc: str,
        acc_index: str,
        value: str,
        index: str,
    ) -> list[str]:
        if reduction_type == "argmin":
            better = (
                f"(({value}) < ({acc})) | "
                f"((({value}) == ({acc})) & (({index}) < ({acc_index})))"
            )
        else:
            better = (
                f"(({value}) > ({acc})) | "
                f"((({value}) == ({acc})) & (({index}) < ({acc_index})))"
            )
        return [
            (
                f"{acc}, {acc_index} = "
                f"(({value}), ({index})) if ({better}) else (({acc}), ({acc_index}))"
            )
        ]

    def _get_strategies(self) -> list[TileStrategy]:
        """Get the current device function's strategies."""
        from .device_function import DeviceFunction

        try:
            return DeviceFunction.current().tile_strategy.strategies
        except Exception:
            return []

    def launcher_keyword_args(self, config: Config, *, has_barrier: bool) -> list[str]:
        from .cute.thread_budget import MAX_THREADS_PER_BLOCK
        from .device_function import DeviceFunction
        from .host_function import HostFunction

        device_function = DeviceFunction.current()
        codegen = device_function.codegen
        tile_strategy = device_function.tile_strategy
        final_kernel_text = "\n".join(
            ast.unparse(stmt)
            for stmt in [*device_function.preamble, *device_function.body]
        )
        final_thread_axes = {
            int(axis_text)
            for axis_text in re.findall(
                r"cute\.arch\.thread_idx\(\)\[(\d+)\]",
                final_kernel_text,
            )
        }

        def launcher_args_with_compile_options(block_arg: str) -> list[str]:
            launcher_args = [block_arg]
            if config.get(TCGEN05_CUBIN_LINEINFO_CONFIG_KEY) is True:
                launcher_args.append("cute_compile_options='--generate-line-info'")
            return launcher_args

        block_size_values = {
            name: int(value)
            for name, value in re.findall(
                r"^(_BLOCK_SIZE_\d+) = (\d+)$",
                final_kernel_text,
                flags=re.MULTILINE,
            )
        }
        # Accept both the historical ``offset_<n>`` prefix (non-CuTe backends)
        # and the post-rename ``tile_offset_<n>`` prefix (CuTe backend, see the
        # CuTe DSL preprocessor counter-collision note in
        # ``tile_strategy.py``). The launch-dim recovery walks the generated
        # source to pair Helion's per-axis offsets with their thread axes; if
        # the regex misses, we fall back to ``[1, 1, 1]`` and any kernel that
        # depends on the recovery launches with too-small dims.
        offset_block_sizes = dict(
            re.findall(
                r"^\s*(?:tile_)?offset_(\d+) = .* \* (_BLOCK_SIZE_\d+)$",
                final_kernel_text,
                flags=re.MULTILINE,
            )
        )
        offset_thread_dims = [1, 1, 1]
        # When a lane loop is active for an axis the generated index expression
        # has the form
        #   ``indices_<n> = tile_offset_<n> + Int32(thread_idx()[<axis>]) * <epT> + Int32(lane_<n>)``
        # where ``<epT>`` is ``elements_per_thread`` for that axis and the
        # outer ``for lane_<n> in range(<epT>):`` covers the residual. In
        # that case the launch-time thread extent for the axis is
        # ``block_size / <epT>``, not ``block_size``. Without dividing by
        # ``<epT>`` here the launch dim ends up at ``block_size`` while the
        # generated tile arithmetic only spans ``block_size / <epT>`` threads,
        # which means ``thread_idx[axis] >= block_size / <epT>`` writes past
        # the tile and triggers ``cudaErrorIllegalAddress`` mid-search. The
        # ``cutlass.Int32(...)`` wrapper around ``thread_idx`` is closed
        # before the ``* <epT>`` multiplier, so the closing ``)`` between
        # ``[axis]`` and ``*`` is part of the line we have to skip over.
        #
        # The launch dim along ``axis`` has to serve **every** indices line
        # that uses that axis. If two lines on the same axis emit different
        # multipliers (e.g. one block_id with ``epT=1`` and another with
        # ``epT=2``), the line with the larger ``thread_idx[axis]`` range
        # is the binding one — so we compute ``block_size // epT`` *per
        # line* and take the ``max`` across lines, rather than combining
        # multipliers across lines and dividing once. ``re.findall`` over
        # the optional-multiplier alternation cannot be made to populate
        # the multiplier group reliably (the optional ``(?:...)?`` form
        # prefers the empty match), so we scan the lines once in Python
        # to keep the per-line ``(block_size, epT)`` pair intact.
        # ``indices_line_re`` anchors on the
        # ``cutlass.Int32(cute.arch.thread_idx()[<axis>])`` form the CuTe
        # backend emits via ``lane_index_expr`` (see backend.py:2666).
        # The trailing ``\)`` after ``\]`` is the close of the
        # ``cutlass.Int32(...)`` wrapper around ``thread_idx``; if a
        # future codegen path drops the wrapper, the regex will
        # silently fail to match and the launch dim under-dimensions
        # without a signal. ``indices_line_assert_re`` below detects
        # the "wrapper-dropped" form so we can fail loudly instead.
        indices_line_re = re.compile(
            r"^\s*indices_\d+ = (?:tile_)?offset_(\d+) \+ "
            r"[^\n]*?cute\.arch\.thread_idx\(\)\[(\d+)\]\)"
            r"(?:\s*\*\s*(?:cutlass\.Int32\()?(\d+))?",
            flags=re.MULTILINE,
        )
        # Loose form: any ``indices_<n>`` line containing ``thread_idx``
        # under any wrapping. Used only for the wrapper-invariant
        # assertion below — never consulted for launch-dim values.
        indices_line_loose_re = re.compile(
            r"^\s*indices_\d+ = (?:tile_)?offset_\d+ \+ "
            r"[^\n]*?cute\.arch\.thread_idx\(\)",
            flags=re.MULTILINE,
        )
        matched_lines = 0
        for line_match in indices_line_re.finditer(final_kernel_text):
            matched_lines += 1
            offset_id = line_match.group(1)
            axis_text = line_match.group(2)
            multiplier_text = line_match.group(3)
            axis = int(axis_text)
            if not (0 <= axis < len(offset_thread_dims)):
                continue
            block_name = offset_block_sizes.get(offset_id)
            block_size = block_size_values.get(block_name or "")
            if block_size is None and block_name is not None:
                try:
                    config_index = int(block_name.removeprefix("_BLOCK_SIZE_"))
                except ValueError:
                    config_index = -1
                if 0 <= config_index < len(config.block_sizes):
                    config_block_size = config.block_sizes[config_index]
                    if isinstance(config_block_size, int):
                        block_size = config_block_size
            if block_size is None:
                continue
            elements_per_thread = int(multiplier_text) if multiplier_text else 1
            if elements_per_thread <= 0:
                # ``lane_index_expr`` only emits ``* <n>`` for ``n >= 1``;
                # a ``* 0`` multiplier would mean the index expression is
                # already invalid (every thread maps to offset 0), so
                # silently falling back to ``block_size`` here would
                # mask the very class of bug this recovery exists to
                # catch. Surface it loudly.
                raise AssertionError(
                    f"launch-dim recovery: non-positive "
                    f"elements_per_thread={elements_per_thread} for axis="
                    f"{axis}"
                )
            if block_size % elements_per_thread != 0:
                # The strategy invariant ``_thread_extent_for_axis``
                # rejects non-divisible ``block_size / nt`` at
                # construction, so the regex should never see a line
                # whose ``epT`` does not divide ``block_size`` evenly.
                # If a future codegen regression breaks that invariant,
                # surface it loudly here rather than silently
                # under-dimensioning the launch.
                raise AssertionError(
                    f"launch-dim recovery: block_size={block_size} not "
                    f"divisible by elements_per_thread={elements_per_thread} "
                    f"for axis={axis}"
                )
            line_extent = block_size // elements_per_thread
            offset_thread_dims[axis] = max(offset_thread_dims[axis], line_extent)
        # Wrapper-invariant assertion: when there is at least one
        # ``indices_<n> = ... thread_idx() ...`` line and we have
        # ``_BLOCK_SIZE_<n>`` constants to consume, the strict regex
        # above must have matched at least one of them. A loose match
        # without a strict match means the codegen emitted
        # ``thread_idx[axis]`` outside the ``cutlass.Int32(...)``
        # wrapper the strict regex anchors on; in that case the
        # launch dim would silently fall back to ``[1, 1, 1]`` and
        # under-dimension every kernel that uses a thread axis.
        if (
            offset_block_sizes
            and indices_line_loose_re.search(final_kernel_text)
            and matched_lines == 0
        ):
            raise AssertionError(
                "launch-dim recovery: indices_<n> lines reference "
                "cute.arch.thread_idx() but none matched the "
                "cutlass.Int32(...)-wrapped form. The strict regex in "
                "_launcher_block_arg is anchored on the wrapper emitted "
                "by lane_index_expr; if the codegen producer was changed "
                "to drop the wrapper, update the regex to match the new "
                "form."
            )
        dims = tuple(codegen.max_thread_block_dims)
        root_live_dims = tuple(codegen.root_thread_block_dims)
        referenced_dims = tuple(codegen.referenced_thread_block_dims)
        static_dims = tile_strategy.thread_block_dims()
        dim_exprs = tile_strategy.thread_block_dim_exprs()
        static_threads = functools.reduce(operator.mul, static_dims, 1)
        dynamic_threads = functools.reduce(operator.mul, dims, 1)
        has_nested_device_loops = any(
            getattr(graph_info, "block_ids", None) is not None
            for graph_info in codegen.codegen_graphs
        )
        root_grid_dims = [1, 1, 1]
        device_ir = HostFunction.current().device_ir
        for block_ids in device_ir.grid_block_ids:
            strategy = tile_strategy.block_id_to_strategy.get(tuple(block_ids))
            if strategy is None:
                continue
            for axis, size in enumerate(strategy.thread_block_sizes()):
                if axis < len(root_grid_dims):
                    root_grid_dims[axis] = max(root_grid_dims[axis], size)
        root_static_dims = tuple(root_grid_dims)
        root_static_threads = functools.reduce(operator.mul, root_static_dims, 1)
        specialized_root_tcgen05 = (
            _kernel_specialized_mma_impl(device_function, config=device_function.config)
            == "tcgen05"
            and root_static_dims != (1, 1, 1)
            and root_static_threads <= MAX_THREADS_PER_BLOCK
        )
        tcgen05_compact_dims = (
            device_function.cute_block_shape if specialized_root_tcgen05 else None
        )
        if referenced_dims != (1, 1, 1):
            dims = referenced_dims
        elif has_nested_device_loops:
            dims = tuple(codegen.max_thread_block_dims)
        if functools.reduce(operator.mul, dims, 1) > MAX_THREADS_PER_BLOCK:
            if (
                root_static_dims != (1, 1, 1)
                and root_static_threads <= MAX_THREADS_PER_BLOCK
            ):
                dims = root_static_dims
            elif static_dims != (1, 1, 1) and static_threads <= MAX_THREADS_PER_BLOCK:
                dims = static_dims
        recorded_dims = tuple(
            max(
                codegen.max_thread_block_dims[axis],
                root_live_dims[axis],
                referenced_dims[axis],
            )
            for axis in range(3)
        )
        if tcgen05_compact_dims is not None:
            dims = tcgen05_compact_dims
        elif specialized_root_tcgen05:
            dims = root_static_dims
        elif final_thread_axes and (
            referenced_dims != (1, 1, 1) or has_nested_device_loops
        ):
            dims = tuple(
                max(size, root_static_dims[axis], recorded_dims[axis])
                if axis in final_thread_axes
                else size
                for axis, size in enumerate(dims)
            )
            dims = tuple(
                size if axis in final_thread_axes else 1
                for axis, size in enumerate(dims)
            )
        else:
            dims = tuple(
                min(size, recorded_dims[axis]) for axis, size in enumerate(dims)
            )
        current_threads = functools.reduce(operator.mul, dims, 1)
        if current_threads > MAX_THREADS_PER_BLOCK:
            if static_dims != (1, 1, 1) and static_threads <= MAX_THREADS_PER_BLOCK:
                dims = static_dims
            elif (
                root_live_dims != (1, 1, 1)
                and functools.reduce(operator.mul, root_live_dims, 1)
                <= MAX_THREADS_PER_BLOCK
            ):
                dims = root_live_dims
            elif (
                referenced_dims != (1, 1, 1)
                and functools.reduce(operator.mul, referenced_dims, 1)
                <= MAX_THREADS_PER_BLOCK
            ):
                dims = referenced_dims
        if (
            dims != (1, 1, 1)
            and static_dims != (1, 1, 1)
            and not has_nested_device_loops
            and static_threads < dynamic_threads
        ):
            dims = static_dims
        if dim_exprs is not None and dim_exprs != ("1", "1", "1"):
            if all(expr.isdigit() for expr in dim_exprs):
                expr_dims = tuple(int(expr) for expr in dim_exprs)
                if functools.reduce(
                    operator.mul, expr_dims, 1
                ) <= MAX_THREADS_PER_BLOCK and all(
                    expr_dim <= current_dim
                    for expr_dim, current_dim in zip(expr_dims, dims, strict=True)
                ):
                    dims = expr_dims
            elif dims == (1, 1, 1):
                return launcher_args_with_compile_options(
                    f"block=({dim_exprs[0]}, {dim_exprs[1]}, {dim_exprs[2]})"
                )
        if offset_thread_dims != [1, 1, 1]:
            candidate_dims = tuple(
                starmap(max, zip(dims, offset_thread_dims, strict=True))
            )
            if (
                functools.reduce(operator.mul, candidate_dims, 1)
                <= MAX_THREADS_PER_BLOCK
            ):
                dims = candidate_dims
        if dims == (1, 1, 1):
            dynamic_dims = tuple(codegen.max_thread_block_dims)
            if (
                dynamic_dims != (1, 1, 1)
                and functools.reduce(operator.mul, dynamic_dims, 1)
                <= MAX_THREADS_PER_BLOCK
            ):
                dims = dynamic_dims
            else:
                dims = DeviceFunction.current().tile_strategy.thread_block_dims()
        from .cute.thread_budget import check_thread_limit

        check_thread_limit(dims[0] * dims[1] * dims[2], context=str(tuple(dims)))
        return launcher_args_with_compile_options(
            f"block=({dims[0]}, {dims[1]}, {dims[2]})"
        )

    def build_launcher_args(
        self,
        args: list[str],
        *,
        tensor_host_args: list[str],
        has_rng_ops: bool,
        config: Config,
        has_barrier: bool,
        sorted_args: list[Argument] | None = None,
    ) -> list[str]:
        if not tensor_host_args:
            raise exc.BackendUnsupported(self.name, "kernel launch without tensor args")
        out = [*args]
        if has_rng_ops:
            out.append("_rng_seed_buffer")
        out.extend(self.launcher_keyword_args(config, has_barrier=has_barrier))
        return out

    def create_loop_strategy(
        self, fn: DeviceFunction, block_ids: list[int], config: Config
    ) -> TileStrategy:
        from .compile_environment import CompileEnvironment
        from .device_ir import ForLoopGraphInfo
        from .device_ir import ReductionLoopGraphInfo
        from .host_function import HostFunction
        from .tile_strategy import CuteFlattenedTileStrategy
        from .tile_strategy import CuteNDTileStrategy

        env = CompileEnvironment.current()
        device_ir = HostFunction.current().device_ir
        block_size_infos = [env.block_sizes[i] for i in block_ids]
        flattened = block_size_infos[0].is_flattened(config)
        loop_order = env.config_spec.loop_orders.config_get(
            config.loop_orders, block_ids[0]
        ) or [*range(len(block_ids))]
        l2_grouping = env.config_spec.l2_groupings.config_get(
            config.l2_groupings, block_ids[0], 1
        )
        has_device_loops = any(
            isinstance(graph, ForLoopGraphInfo)
            and not isinstance(graph, ReductionLoopGraphInfo)
            for graph in fn.codegen.codegen_graphs
        )
        has_dynamic_shape = any(env.block_sizes[i].size is None for i in block_ids)
        grid_ids = {bid for ids in device_ir.grid_block_ids for bid in ids}
        num_threads_config = [
            int(env.config_spec.num_threads.config_get(config.num_threads, block_id, 0))
            for block_id in block_ids
        ]
        # Compute the total thread count across all block dimensions
        # (grid + device loops) to check against the hardware limit.
        # When it would exceed 1024, default device-loop (non-grid)
        # dimensions to 1 thread to avoid budget overflow.
        from .cute.thread_budget import MAX_THREADS_PER_BLOCK

        def _largest_divisor_at_most(size: int, limit: int) -> int:
            for divisor in range(limit, 0, -1):
                if size % divisor == 0:
                    return divisor
            return 1

        def _shrink_auto_thread_counts(
            nd_block_size: Sequence[object], thread_limit: int
        ) -> int:
            int_positions: list[int] = []
            int_block_sizes: dict[int, int] = {}
            for i, block_size in enumerate(nd_block_size):
                if isinstance(block_size, int):
                    int_positions.append(i)
                    int_block_sizes[i] = block_size
            resolved_threads = [
                num_threads_config[i]
                if num_threads_config[i] > 0
                else int_block_sizes[i]
                for i in int_positions
            ]
            auto_positions = {
                pos
                for pos, block_idx in enumerate(int_positions)
                if num_threads_config[block_idx] == 0
            }
            static_threads = functools.reduce(operator.mul, resolved_threads, 1)
            while static_threads > thread_limit and auto_positions:
                shrink_idx = max(
                    (pos for pos in auto_positions if resolved_threads[pos] > 1),
                    key=lambda pos: resolved_threads[pos],
                    default=None,
                )
                if shrink_idx is None:
                    break
                block_idx = int_positions[shrink_idx]
                block_size = int_block_sizes[block_idx]
                next_threads = _largest_divisor_at_most(
                    block_size, resolved_threads[shrink_idx] - 1
                )
                if next_threads == resolved_threads[shrink_idx]:
                    break
                resolved_threads[shrink_idx] = next_threads
                num_threads_config[block_idx] = next_threads
                static_threads = functools.reduce(operator.mul, resolved_threads, 1)
            return static_threads

        active_loop_block_ids = _active_loop_block_ids(fn)
        all_block_infos = [env.block_sizes[i] for i in sorted(active_loop_block_ids)]
        total_threads = 1
        for info in all_block_infos:
            if info.reduction:
                continue
            bs = info.from_config(config)
            if isinstance(bs, int):
                nt = int(
                    env.config_spec.num_threads.config_get(
                        config.num_threads, info.block_id, 0
                    )
                )
                total_threads *= nt if nt > 0 else bs
        if total_threads > MAX_THREADS_PER_BLOCK:
            for i, block_id in enumerate(block_ids):
                if num_threads_config[i] == 0 and block_id not in grid_ids:
                    num_threads_config[i] = 1
        if (
            has_device_loops
            or has_dynamic_shape
            or len(device_ir.grid_block_ids) != 1
            or (len(block_ids) > 1 and not flattened)
        ):
            known_equal = getattr(env, "known_equal", None)

            def sizes_known_equal(
                lhs: int | torch.SymInt,
                rhs: int | torch.SymInt,
            ) -> bool:
                if known_equal is not None:
                    return known_equal(lhs, rhs)
                return lhs == rhs

            nd_block_size = [bs.from_config_assert(config) for bs in block_size_infos]
            original_num_threads_config = list(num_threads_config)
            mma_candidate = _is_mma_candidate_loop(
                fn,
                block_ids,
                block_sizes=nd_block_size,
                num_threads_config=original_num_threads_config,
                grid_ids=grid_ids,
            )
            should_filter_inactive_block_ids = len(block_ids) > 1
            inactive_block_ids: set[int] = set()
            if should_filter_inactive_block_ids:
                used_block_ids = _graph_used_block_ids(fn, block_ids)
                if not used_block_ids:
                    used_block_ids = set(block_ids)
                for block_id in tuple(used_block_ids):
                    block_size = env.block_sizes[block_id].size
                    if block_size is None or not isinstance(
                        block_size, (int, torch.SymInt)
                    ):
                        continue
                    for other_block_id in block_ids:
                        if other_block_id == block_id:
                            continue
                        other_size = env.block_sizes[other_block_id].size
                        if other_size is None or not isinstance(
                            other_size, (int, torch.SymInt)
                        ):
                            continue
                        if sizes_known_equal(block_size, other_size):
                            used_block_ids.add(other_block_id)
                inactive_block_ids = set(block_ids) - used_block_ids
                for i, block_id in enumerate(block_ids):
                    if block_id in inactive_block_ids:
                        num_threads_config[i] = 1
            is_device_loop = any(bid not in grid_ids for bid in block_ids)
            reduction_axis_reserve = (
                1
                if any(info.reduction for info in env.block_sizes)
                and self.reduction_axis_first()
                else 0
            )

            def uses_thread_axis_for(
                block_id: int, block_size: object, num_threads: int
            ) -> bool:
                if block_id in inactive_block_ids:
                    return False
                if num_threads > 0:
                    return num_threads > 1
                return not (isinstance(block_size, int) and block_size == 1)

            consumed_grid_axes = 0
            if is_device_loop:
                for grid_block_id in grid_ids:
                    grid_info = env.block_sizes[grid_block_id]
                    grid_block_size = grid_info.from_config(config)
                    grid_threads = int(
                        env.config_spec.num_threads.config_get(
                            config.num_threads,
                            grid_block_id,
                            0,
                        )
                    )
                    if uses_thread_axis_for(
                        grid_block_id,
                        grid_block_size,
                        grid_threads,
                    ):
                        consumed_grid_axes += 1
            available_axes = max(0, 3 - reduction_axis_reserve - consumed_grid_axes)

            def current_strategy_axes() -> int:
                return sum(
                    int(uses_thread_axis_for(block_id, block_size, threads))
                    for block_id, block_size, threads in zip(
                        block_ids,
                        nd_block_size,
                        num_threads_config,
                        strict=True,
                    )
                )

            while current_strategy_axes() > available_axes:
                candidates = [
                    i
                    for i, (block_id, block_size, threads) in enumerate(
                        zip(block_ids, nd_block_size, num_threads_config, strict=True)
                    )
                    if threads == 0
                    and uses_thread_axis_for(block_id, block_size, threads)
                    and (not is_device_loop or block_id not in grid_ids)
                ]
                if not candidates:
                    break
                num_threads_config[candidates[-1]] = 1
            thread_limit = MAX_THREADS_PER_BLOCK
            if len(block_ids) > 1 and _loop_contains_matmul(fn, block_ids):
                forced_mma_impl = os.environ.get("HELION_CUTE_MMA_IMPL", "auto")
                if (
                    mma_candidate
                    or _kernel_has_specialized_mma_path(fn, config=config)
                    or (
                        _loop_may_use_mma(fn, block_ids)
                        and not _loop_contains_atomic(fn, block_ids)
                        and forced_mma_impl.strip().lower() != "auto"
                    )
                ):
                    thread_limit = MAX_THREADS_PER_BLOCK
                else:
                    # Matmul-heavy CuTe kernels with no viable MMA path, and
                    # especially atomic-accumulating split-K loops, can be
                    # register/smem limited well before the 1024-thread hard
                    # cap. Keep those auto-threaded ND tiles within 256
                    # threads and let lane loops cover the rest.
                    thread_limit = min(thread_limit, 256)
            if should_filter_inactive_block_ids and mma_candidate:
                inactive_block_ids.clear()
                num_threads_config = [
                    env.config_spec.num_threads.config_get(
                        config.num_threads, block_id, 0
                    )
                    for block_id in block_ids
                ]
            static_threads = _shrink_auto_thread_counts(nd_block_size, thread_limit)
            from .cute.thread_budget import check_thread_limit

            # Detect MMA-compatible K-loops: device loops containing
            # addmm/mm with float16/bfloat16 operands.
            mma_mode = False
            if is_device_loop:
                mma_mode = _detect_specialized_mma_loop(
                    fn,
                    block_ids,
                    block_sizes=nd_block_size,
                    config=config,
                )
            elif (
                len(device_ir.grid_block_ids) == 1
                and block_ids == device_ir.grid_block_ids[0]
            ):
                specialized_mma_impl = _kernel_specialized_mma_impl(fn, config=config)
                if specialized_mma_impl == "tcgen05" and len(nd_block_size) == 2:
                    from .cute.cute_mma import _tcgen05_root_m_threads

                    root_m_threads = (
                        _tcgen05_root_m_threads(
                            int(nd_block_size[0]), int(nd_block_size[1])
                        )
                        if num_threads_config[0] == 0
                        and isinstance(nd_block_size[0], int)
                        and isinstance(nd_block_size[1], int)
                        else num_threads_config[0]
                    )
                    root_n_threads = (
                        min(int(nd_block_size[1]), 8)
                        if num_threads_config[1] == 0
                        and isinstance(nd_block_size[1], int)
                        else num_threads_config[1]
                    )
                    num_threads_config[0] = root_m_threads
                    num_threads_config[1] = root_n_threads
                    static_threads = root_m_threads * root_n_threads

            check_thread_limit(static_threads, context=str(tuple(nd_block_size)))
            return CuteNDTileStrategy(
                fn,
                block_ids,
                block_size=nd_block_size,
                loop_order=loop_order,
                l2_grouping=l2_grouping,
                num_threads=num_threads_config,
                mma_mode=mma_mode,
                inactive_block_ids=inactive_block_ids,
            )
        nd_block_size = [bs.from_config_assert(config) for bs in block_size_infos]
        block_size = functools.reduce(operator.mul, nd_block_size)
        # Resolve per-axis thread counts then flatten to a single total
        flat_num_threads = functools.reduce(
            operator.mul,
            (
                nt if nt > 0 else (int(bs) if isinstance(bs, int) else 0)
                for nt, bs in zip(num_threads_config, nd_block_size, strict=True)
            ),
            1,
        )
        if isinstance(block_size, int) and flat_num_threads > 0:
            from .cute.thread_budget import check_thread_limit

            check_thread_limit(flat_num_threads, context=str(block_size))
        return CuteFlattenedTileStrategy(
            fn,
            block_ids,
            block_size=block_size,
            loop_order=loop_order,
            num_threads=flat_num_threads,
        )


class MetalBackend(Backend):
    """Metal Shading Language (MSL) code generation backend for macOS."""

    @staticmethod
    def _get_dtype_to_metal() -> dict[torch.dtype, str]:
        from torch._inductor.codegen.mps import DTYPE_TO_METAL

        return DTYPE_TO_METAL

    _ACC_TYPE: ClassVar[dict[torch.dtype, str]] = {
        torch.float16: "float",
        torch.bfloat16: "float",
        torch.float32: "float",
        torch.int8: "int",
        torch.int16: "int",
        torch.int32: "int",
        torch.int64: "long",
        torch.uint8: "uint",
        torch.bool: "int",
    }

    _SUPPORTED_CONFIG_KEYS: frozenset[str] = frozenset(
        {
            "block_sizes",
            "num_warps",
        }
    )

    @property
    def name(self) -> str:
        return "metal"

    def dtype_str(self, dtype: torch.dtype) -> str:
        dtype_map = self._get_dtype_to_metal()
        if dtype not in dtype_map:
            raise exc.BackendUnsupported(self.name, f"dtype: {dtype}")
        return dtype_map[dtype]

    def acc_type(self, dtype: torch.dtype) -> str:
        if dtype not in self._ACC_TYPE:
            raise exc.BackendUnsupported(self.name, f"acc_type for: {dtype}")
        return self._ACC_TYPE[dtype]

    @property
    def function_decorator(self) -> str:
        return "metal_jit"

    @property
    def constexpr_type(self) -> str:
        return "int"

    @property
    def default_launcher_name(self) -> str:
        return "_default_metal_launcher"

    @property
    def library_imports(self) -> dict[str, str]:
        return {
            "math": "import math",
            "torch": "import torch",
            "helion": "import helion",
            "hl": "import helion.language as hl",
            "_default_metal_launcher": (
                "from helion.runtime import default_metal_launcher"
                " as _default_metal_launcher"
            ),
            "metal_jit": ("from helion._compiler.metal.metal_jit import metal_jit"),
        }

    def index_type_str(self, index_dtype: torch.dtype) -> str:
        return "uint"

    def inline_constexpr(self, name: str, value: str) -> str:
        return f"{name} = {value}"

    def cast_expr(self, expr_str: str, dtype_str: str) -> str:
        return f"static_cast<{dtype_str}>({expr_str})"

    def program_id_expr(self, dim: int, *, index_dtype: str) -> str:
        return f"tgid[{dim}]"

    def grid_index_expr(
        self, offset_var: str, block_size_var: str, dtype: str, *, axis: int
    ) -> str:
        return f"{offset_var} + tid[{axis}]"

    def force_tile_mask(self) -> bool:
        return True

    def inductor_op_overrides(self) -> InductorOpOverrides:
        from .metal.metal_overrides import MetalOverrides

        return MetalOverrides()

    def full_expr(
        self, shape_dims: list[str], value_expr: str, dtype: torch.dtype
    ) -> str:
        metal_type = self.dtype_str(dtype)
        return f"{metal_type}({value_expr})"

    def reshape_expr(self, expr: str, shape: str) -> str:
        return expr

    def broadcast_to_expr(self, expr: str, shape: str) -> str:
        return expr

    def zeros_expr(self, shape: str, dtype: str) -> str:
        return "0"

    def where_expr(self, mask: str, true_val: str, false_val: str) -> str:
        # Must be valid Python for expr_from_string; walker converts to C++ ternary
        return f"({true_val} if {mask} else {false_val})"

    def minimum_expr(self, a: str, b: str) -> str:
        return f"min({a}, {b})"

    def supports_config_key(self, key: str) -> bool:
        return key in self._SUPPORTED_CONFIG_KEYS

    def supports_precompile(self) -> bool:
        return False

    def autotune(
        self,
        bound_kernel: BoundKernel[Any],
        args: Sequence[object],
        *,
        force: bool = True,
        **kwargs: object,
    ) -> Config:
        return bound_kernel.config_spec.default_config()

    def transform_host_arg(
        self,
        arg: Argument,
        host_str: str,
        tensor_host_args: list[str],
    ) -> str:
        """Wrap scalar SymbolArguments as 1-element tensors for buffer passing."""
        from .device_function import SymbolArgument

        if isinstance(arg, SymbolArgument):
            device_expr = (
                f"{tensor_host_args[0]}.device" if tensor_host_args else "'mps'"
            )
            return (
                f"torch.scalar_tensor(float({host_str}), "
                f"dtype=torch.float32, "
                f"device={device_expr})"
            )
        return host_str

    def launcher_keyword_args(self, config: Config, *, has_barrier: bool) -> list[str]:
        from .device_function import DeviceFunction

        dims = tuple(DeviceFunction.current().codegen.max_thread_block_dims)
        return [f"_block_dims=({dims[0]}, {dims[1]}, {dims[2]})"]
