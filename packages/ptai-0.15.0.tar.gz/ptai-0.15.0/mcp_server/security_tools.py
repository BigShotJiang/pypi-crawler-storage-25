"""MCP tools for the security-tool catalog: ``plan_tools`` and
``ensure_tools_installed``.

Companion to ``mcp_server.server`` ``list_tools`` / ``run_tool`` (which already
exist). The two new ones let an outer LLM (Claude Code, Cursor, Codex) drive
the *install* side of ptai without an Anthropic API key:

  - ``plan_tools`` predicts the canonical tool list for a (scope, intensity,
    target) profile. Useful at engagement start to batch-install before the
    LLM picks specific tools.
  - ``ensure_tools_installed`` audits a list of tools (installed / missing /
    unknown) and, when ``auto_install=True``, installs the missing ones in
    one shot.

The flow:

  1. Claude Code calls ``plan_tools(scope="web")`` → gets predicted list.
  2. Claude Code asks the user "install these N tools?" in chat.
  3. On yes, Claude Code calls ``ensure_tools_installed(tools=[...], auto_install=True)``.
  4. Claude Code can now call ``run_tool(name, ...)`` for any of them.

Extracted into its own module so ``mcp_server/server.py`` stays under 1500
lines (matching the convention set by ``mcp_server/probes.py`` in the
0.13.0 cleanup). Imported at the bottom of ``server.py`` to trigger
@mcp.tool() registrations.
"""
from __future__ import annotations

from typing import Any

# Late import from server.py: by the time this module runs, server.py has
# already defined `mcp` and `logger`. The bottom-of-server.py import of
# this module is what triggers our @mcp.tool() registrations.
from mcp_server.server import (  # noqa: E402  - intentional late binding
    logger,
    mcp,
)


@mcp.tool()
async def plan_tools(
    scope: str = "web",
    intensity: str = "normal",
    target: str = "",
) -> dict[str, Any]:
    """Predict which security tools will likely be needed for an engagement.

    Static map per scope (``web`` → wpscan/dalfox/sqlmap/..., ``ad`` →
    enum4linux-ng/kerbrute/..., ``cloud`` → prowler/scout-suite/...).
    ``scope="full"`` returns the union of every scope's static list.

    The MCP-side caller (Claude Code) supplies no LLM client to this
    predictor, so the answer is purely static — that's intentional, the
    outer LLM IS the planner and uses this for the canonical baseline.

    Returns:
        {"scope", "intensity", "target", "predicted": [tool names],
         "static_floor": [same list — labeled so callers know there's no
         LLM augmentation happening server-side]}
    """
    from engine.install_planner import predict_tools_for_engagement

    try:
        predicted = await predict_tools_for_engagement(
            agent=None,
            scope=scope,
            intensity=intensity,
            target=target,
        )
    except Exception as exc:  # noqa: BLE001 - planner must not crash the MCP call
        logger.warning("plan_tools failed: %s", exc)
        predicted = []

    return {
        "scope": scope,
        "intensity": intensity,
        "target": target,
        "predicted": predicted,
        "static_floor": predicted,  # No LLM augmentation server-side.
    }


@mcp.tool()
async def ensure_tools_installed(
    tools: list[str],
    auto_install: bool = False,
) -> dict[str, Any]:
    """Audit which of the given tools are installed; optionally install the missing ones.

    The MCP-side prompt is the *outer LLM's* responsibility: with
    ``auto_install=False`` (default), this just returns the audit, and the
    LLM is expected to surface a confirmation prompt to the user in chat.
    On the user's yes, the LLM re-calls with ``auto_install=True`` to actually
    run the installs.

    Returns:
        {"installed": [names], "missing": [names], "unknown": [names],
         "install_results"?: [{"tool", "ok", "message"}, ...]}

    ``unknown`` is the subset of input names that match no SecurityTool
    wrapper. ``install_results`` only appears when ``auto_install=True``.
    """
    from engine.tool_installer import audit_named, install_tool_by_name

    if not tools:
        return {"installed": [], "missing": [], "unknown": []}

    audit = audit_named(tools)
    response: dict[str, Any] = {
        "installed": audit["installed"],
        "missing": audit["missing"],
        "unknown": audit["unknown"],
    }

    if auto_install and audit["missing"]:
        results: list[dict[str, Any]] = []
        for name in audit["missing"]:
            ok, message = install_tool_by_name(name)
            results.append({"tool": name, "ok": ok, "message": message})
        response["install_results"] = results

    return response
