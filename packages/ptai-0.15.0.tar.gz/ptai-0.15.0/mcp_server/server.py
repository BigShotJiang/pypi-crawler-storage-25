"""
pentest-ai MCP Server

Exposes 150+ security tools via the Model Context Protocol.
Connects to Claude, GPT, Copilot, or any MCP-compatible client.

AUTHORIZED TARGETS ONLY. Every tool exposed here performs real network
or host operations. Calling client (the LLM agent) and the operator
behind it are solely responsible for ensuring written authorization
exists for every target. See https://pentestai.xyz/aup.
"""

import asyncio
import logging
import os
from typing import Any

from fastmcp import Context, FastMCP
from pydantic import BaseModel, Field

from engine.findings_db import FindingsDB
from engine.orchestrator import AgentOrchestrator
from tools.registry import ToolRegistry

logger = logging.getLogger("pentest-ai.mcp")

# Initialize MCP server
mcp = FastMCP("pentest-ai")

# Global state
findings_db: FindingsDB | None = None
orchestrator: AgentOrchestrator | None = None
tool_registry: ToolRegistry | None = None

def get_findings_db() -> FindingsDB:
    global findings_db
    if findings_db is None:
        db_path = os.getenv("PENTEST_DB_PATH", "pentest_findings.db")
        findings_db = FindingsDB(db_path)
        logger.info("findings DB resolved to %s", os.path.abspath(db_path))
    return findings_db


def get_orchestrator() -> AgentOrchestrator:
    global orchestrator
    if orchestrator is None:
        orchestrator = AgentOrchestrator(get_findings_db())
    return orchestrator


def get_tool_registry() -> ToolRegistry:
    global tool_registry
    if tool_registry is None:
        tool_registry = ToolRegistry()
    return tool_registry


# ─── Engagement Management ───────────────────────────────────────────────


class EngagementParams(BaseModel):
    target: str = Field(description="Target hostname, IP, or URL")
    scope: str = Field(default="full", description="Scope: recon, web, ad, cloud, full")
    rules_of_engment: str = Field(default="", description="Rules of engagement / exclusions")
    intensity: str = Field(default="normal", description="Scan intensity: stealth, normal, aggressive")


@mcp.tool()
async def start_engagement(
    target: str,
    scope: str = "full",
    rules_of_engment: str = "",
    intensity: str = "normal",
    auth_profile: str = "",
    respect_rate_limits: bool = False,
    strict_scope: bool = False,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Start a new pentest engagement against a target. AUTHORIZED TARGETS ONLY.

    This initiates reconnaissance and begins the automated assessment.
    All findings are stored and correlated in the findings database.
    Poll get_engagement_status(eng_id) for phase progress.

    The caller (LLM agent and the human operator behind it) MUST have
    written authorization to test the target. See pentestai.xyz/aup.

    Pass ``auth_profile`` to log into the target before scanning. Use
    the secure credential-resolver path (``pentest-ai auth profile add``)
    so secrets never enter the MCP/LLM payload. Without it, auth-gated
    bug classes (race conditions, mass assignment, type confusion,
    authenticated SQLi/XXE/IDOR) cannot be reached.

    Pass ``respect_rate_limits=True`` to honor HTTP 429 / Retry-After
    responses with exponential backoff (capped at 30s, 3 retries).
    Recommended for real bug-bounty targets behind WAFs; default off
    preserves today's behavior.

    Pass ``strict_scope=True`` to refuse any request whose host is
    outside the engagement target's host. Also disables redirect-
    following in primitives so a 302 to attacker.com cannot pull the
    scan off-target. Bug-bounty programs care a lot about scope
    discipline; default off preserves today's wide-open behavior.
    """
    db = get_findings_db()
    engagement = await db.create_engagement(
        target=target,
        scope=scope,
        rules_of_engment=rules_of_engment,
        intensity=intensity,
        respect_rate_limits=respect_rate_limits,
        strict_scope=strict_scope,
    )
    eng_id = engagement["id"]

    # Resolve auth_profile up-front so failures surface as an engagement
    # failure rather than a silent skip of auth-gated probes. None
    # (profile_name unset, or resolution failed) means unauthenticated
    # scan — caller has been warned in the docstring.
    auth_creds = None
    if auth_profile:
        auth_dict = _resolve_auth_profile_to_dict(auth_profile)
        auth_creds = await _resolve_auth_to_credentials(auth_dict)
        if auth_creds is None:
            await db.update_engagement_status(eng_id, "failed")
            return {
                "engagement_id": eng_id,
                "error": f"auth_profile {auth_profile!r} could not be resolved or login failed; see server log",
            }

    # Run the orchestrator as a detached background task so this tool returns
    # immediately. The full pipeline takes 1-5 minutes for a real target
    # (recon + web + chain + validation + detection + report). MCP clients
    # have per-tool-call timeouts (claude defaults around 60-120s) and will
    # report "Connection closed" if the tool blocks past that, even though
    # the engagement is succeeding server-side.
    #
    # Callers poll progress with get_engagement_status(eng_id) and pull
    # findings with get_findings(engagement_id=eng_id).
    async def _run_orchestrator() -> None:
        try:
            orch = get_orchestrator()
            # Inject the resolved auth so orchestrator._configure_agent
            # propagates it into every specialist agent's set_auth. The
            # orchestrator's set_auth is a no-op when auth_creds is None.
            if auth_creds is not None:
                orch.set_auth(auth_creds)
            await orch.start_engagement(engagement, on_progress=None)
        except Exception as e:
            logger.exception("start_engagement %s failed: %s", eng_id, e)
            await db.update_engagement_status(eng_id, "failed")

    asyncio.create_task(_run_orchestrator())

    return {
        "engagement_id": eng_id,
        "target": target,
        "scope": scope,
        "status": "running",
        "message": (
            f"Engagement {eng_id} started against {target}. "
            f"Pipeline runs asynchronously (1-5 min depending on scope/tools). "
            f"Poll get_engagement_status('{eng_id}') for progress and "
            f"get_findings(engagement_id='{eng_id}') for results."
        ),
    }


@mcp.tool()
async def get_engagement_status(engagement_id: str) -> dict[str, Any] | None:
    """Get the current status of a pentest engagement."""
    db = get_findings_db()
    return await db.get_engagement(engagement_id)


@mcp.tool()
async def get_findings(
    engagement_id: str | None = None,
    severity: str | None = None,
    status: str | None = None,
) -> list[dict[str, Any]]:
    """Get findings from current or specific engagement.

    Filter by severity (critical, high, medium, low, info) or status (confirmed, pending, false_positive).
    """
    db = get_findings_db()
    return await db.get_findings(
        engagement_id=engagement_id,
        severity=severity,
        status=status,
    )


@mcp.tool()
async def get_attack_chains(engagement_id: str) -> list[dict[str, Any]]:
    """Get discovered attack chains for an engagement.

    Shows how individual findings chain together into full compromise paths.
    """
    db = get_findings_db()
    return await db.get_attack_chains(engagement_id)


# ─── Tool Execution ──────────────────────────────────────────────────────


@mcp.tool()
async def list_tools(category: str | None = None) -> list[dict[str, Any]]:
    """List all available security tools, optionally filtered by category.

    Categories: network, web, password, binary, cloud, osint
    """
    registry = get_tool_registry()
    tools = registry.list_tools(category=category)
    return [
        {
            "name": t.name,
            "category": t.category,
            "description": t.description,
            "required_deps": t.required_deps,
            "installed": t.is_installed(),
        }
        for t in tools
    ]


_TARGET_BAD_CHARS = set(";|&`$<>\n\r\t\\")


# Auth helpers extracted to mcp_server.auth in the 0.13.0 cleanup pass
# (2026-05-12). Re-exported here under their underscore-prefixed names
# so the existing call sites in start_engagement / test_web_app /
# authenticated_scan don't have to change.
from mcp_server.auth import (  # noqa: E402
    resolve_auth_profile_to_dict as _resolve_auth_profile_to_dict,
)
from mcp_server.auth import (  # noqa: E402
    resolve_auth_to_credentials as _resolve_auth_to_credentials,
)


def _validate_target_arg(target: str) -> str | None:
    """Return None if target is acceptable, else an error string explaining why.

    Rejects shell metacharacters, empty strings, and excessively long inputs.
    Tools are launched without shell=True, but defense-in-depth + clearer errors
    are worth a few extra lines.
    """
    if not target or not target.strip():
        return "target is empty"
    if len(target) > 506:
        return f"target too long ({len(target)} chars; max 506)"
    found = _TARGET_BAD_CHARS.intersection(target)
    if found:
        return f"target contains shell metacharacters: {sorted(found)}"
    return None


@mcp.tool()
async def run_tool(
    tool_name: str,
    target: str,
    args: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run a specific security tool against a target.

    Returns structured results that are automatically stored in the findings database.
    """
    bad = _validate_target_arg(target)
    if bad:
        return {"error": f"invalid target: {bad}", "tool": tool_name, "target": target}

    registry = get_tool_registry()
    tool = registry.get_tool(tool_name)

    if tool is None:
        return {"error": f"Tool '{tool_name}' not found. Use list_tools to see available tools."}

    if not tool.is_installed():
        return {"error": f"Tool '{tool_name}' is not installed on this system."}

    result = await tool.execute(target, args or {})

    # Auto-store findings
    if result.get("findings"):
        db = get_findings_db()
        for finding in result["findings"]:
            await db.add_finding(finding)

    return result


# ─── Reconnaissance ──────────────────────────────────────────────────────


@mcp.tool()
async def run_recon(target: str, depth: str = "standard") -> dict[str, Any]:
    """Start a reconnaissance scan against a target.

    Returns immediately with an engagement_id while the recon agent runs
    asynchronously. Poll get_engagement_status(engagement_id) for status
    and get_findings(engagement_id=...) for results.

    Depth levels:
    - passive: OSINT only, no direct interaction
    - standard: Passive + light active scanning
    - deep: Full active scanning including port scans, vuln scans
    """
    from agents.recon.recon_agent import ReconAgent

    db = get_findings_db()
    engagement = await db.create_engagement(
        target=target, scope="recon", rules_of_engment="", intensity="normal",
    )
    eng_id = engagement["id"]

    async def _run() -> None:
        try:
            agent = ReconAgent(get_tool_registry(), db)
            await agent.run_recon(target, depth=depth, engagement_id=eng_id)
            await db.update_engagement_status(eng_id, "completed")
        except Exception:
            await db.update_engagement_status(eng_id, "failed")

    asyncio.create_task(_run())

    return {
        "engagement_id": eng_id,
        "target": target,
        "depth": depth,
        "status": "running",
        "message": (
            f"Recon scan {eng_id} started against {target} (depth={depth}). "
            f"Runs asynchronously. Poll get_engagement_status('{eng_id}') for "
            f"progress and get_findings(engagement_id='{eng_id}') for results."
        ),
    }


# MCP tools `list_probes`, `run_probe`, `http_request` live in
# `mcp_server.probes` (extracted in the 0.13.0 cleanup pass, 2026-05-12).
# They register themselves against the shared `mcp` instance via the
# late-import at the bottom of this file.


# ─── Web Application Testing ─────────────────────────────────────────────


@mcp.tool()
async def test_web_app(
    target: str,
    auth_profile: str = "",
    auth_credentials: dict[str, str] | None = None,
    focus_areas: list[str] | None = None,
) -> dict[str, Any]:
    """Run a full deterministic web application scan against ``target``.

    Fire-and-forget. Returns immediately with an ``engagement_id``; poll
    ``get_engagement_status`` and pull results with ``get_findings``.

    Coverage when ``auth_profile`` is set (recommended):
        SQL injection (reflected + blind + login-bypass), reflected and
        stored XSS, SSRF, XXE, path traversal, IDOR (sequential +
        authenticated), JWT alg-confusion, race conditions / TOCTOU,
        type confusion (negative-quantity, etc), trusted-header bypass,
        mass assignment via PATCH, host-header poisoning, insecure
        session cookies, missing security headers, directory listings,
        info disclosure, and the OWASP API Top 10. Internally runs the
        WebAgent registry sweep (60+ probes) + content discovery, with
        ``WebAgent.set_auth`` populated so requires_auth probes actually
        fire (regression-fixed 2026-05-11; see CHANGELOG 0.13.0).

    Coverage without auth: discovery + unauthenticated probes only.
    Race conditions, mass assignment, authenticated IDOR, type
    confusion, authenticated SQLi, and stored XSS will all be skipped.

    Credential handling:
      - ``auth_profile``: profile name from ``pentest-ai auth profile add``.
        Credentials resolve server-side; never enter MCP/LLM context.
      - ``auth_credentials`` (deprecated, legacy): inline dict.
        Tolerated for back-compat but logs a warning. Will be removed.

    For iterative LLM-driven testing (Claude Code driving probe-by-probe
    rather than fire-and-forget), prefer ``run_probe`` + ``http_request``
    keyed on a shared ``engagement_id``.

    Args:
        focus_areas: Restrict to a subset (``sqli``, ``xss``, ``ssrf``,
            ``idor``, ``auth``, ``api``, ``all``). Defaults to ``["all"]``.
    """
    from agents.web.web_agent import WebAgent

    if auth_profile:
        if auth_credentials:
            return {"error": "auth_profile is mutually exclusive with auth_credentials"}
        try:
            from cli.auth_profiles import (
                ProfileError,
                get_profile,
            )
            from cli.auth_profiles import (
                resolve as resolve_profile,
            )
            from cli.credential_resolvers import SecurityError

            prof = get_profile(auth_profile)
            resolved = resolve_profile(prof)
        except (ProfileError, SecurityError) as e:
            return {"error": f"profile {auth_profile!r}: {e}"}
        if resolved.token is not None:
            auth_credentials = {
                "type": "bearer",
                "username": prof.username,
                "token": resolved.token.reveal(),
            }
        elif resolved.password is not None:
            auth_credentials = {
                "type": "form",
                "login_url": prof.login_url,
                "username": prof.username,
                "password": resolved.password.reveal(),
            }
        else:
            return {"error": f"profile {auth_profile!r} resolved no credential"}
    elif auth_credentials:
        logger.warning(
            "test_web_app: raw auth_credentials in MCP call. "
            "Migrate to auth_profile (will be removed in ptai 0.11)."
        )

    db = get_findings_db()
    engagement = await db.create_engagement(
        target=target, scope="web", rules_of_engment="", intensity="normal",
    )
    eng_id = engagement["id"]
    creds = auth_credentials  # capture in closure

    async def _run() -> None:
        try:
            agent = WebAgent(get_tool_registry(), db)
            # Bridge auth_credentials → AuthCredentials → WebAgent.set_auth
            # so registry probes marked requires_auth=True actually fire.
            # Without this, requires_auth probes skip silently at
            # agents/web/web_agent.py: `if spec.requires_auth and
            # self._captured_auth is None: return []`, which is the bug
            # that capped the MCP catch rate at 6/10 on the in-process
            # honeypot (race, type_confusion, mass_assignment, xxe all
            # skipped). The orchestrator path already does this at
            # engine/orchestrator.py:_configure_agent.
            if creds:
                auth_creds = await _resolve_auth_to_credentials(creds)
                if auth_creds is not None:
                    agent.set_auth(auth_creds)
            await agent.run_assessment(target, creds, focus_areas, engagement_id=eng_id)
            await db.update_engagement_status(eng_id, "completed")
        except Exception as e:
            logger.exception("test_web_app engagement %s failed: %s", eng_id, e)
            await db.update_engagement_status(eng_id, "failed")

    asyncio.create_task(_run())

    return {
        "engagement_id": eng_id,
        "target": target,
        "status": "running",
        "message": (
            f"Web-app assessment {eng_id} started against {target}. "
            f"Runs asynchronously (1-5 min). Poll get_engagement_status('{eng_id}') "
            f"and get_findings(engagement_id='{eng_id}')."
        ),
    }


# ─── Authenticated Web Scanner ───────────────────────────────────────────


@mcp.tool()
async def authenticated_scan(
    target: str,
    auth_profile: str = "",
    login_url: str = "",
    username: str = "",
    password: str = "",
    username_field: str = "username",
    password_field: str = "password",
    success_marker: str = "",
    success_status: int | None = None,
    bearer_token: str = "",
    max_pages: int = 40,
    timeout_seconds: float = 10.0,
    engagement_id: str = "",
) -> dict[str, Any]:
    """Run a deterministic authenticated web scan (no LLM required).

    Logs in, crawls same-host pages, probes each parameterized endpoint with
    SQLi/XSS/command-injection payloads. Returns structured findings suitable
    for the findings database.

    Recommended (secure): pass ``auth_profile`` = name of a profile created
    via ``pentest-ai auth profile add``. Credentials are resolved server-side
    and never enter the MCP request payload (so they never reach the LLM).

    Deprecated (insecure, removed in 0.11): ``login_url`` + ``username`` +
    ``password`` for form login, or ``bearer_token`` for a static API token.
    These pass the credential value through the MCP/LLM context.

    When ``engagement_id`` is set, findings are persisted to the DB.
    """
    from engine.auth_session import AuthError, WebAuthenticator
    from engine.authenticated_scan import run_authenticated_scan

    # If a profile name was supplied, resolve it server-side (credentials
    # never enter the MCP request payload).
    if auth_profile:
        if password or bearer_token:
            return {
                "error": (
                    "auth_profile is mutually exclusive with password/bearer_token. "
                    "Pick one: pass auth_profile (recommended) or the legacy raw "
                    "credential params (deprecated, removed in 0.11)."
                ),
                "target": target,
            }
        try:
            from cli.auth_profiles import (
                ProfileError,
                get_profile,
            )
            from cli.auth_profiles import (
                resolve as resolve_profile,
            )
            from cli.credential_resolvers import SecurityError

            prof = get_profile(auth_profile)
            resolved = resolve_profile(prof)
        except (ProfileError, SecurityError) as e:
            return {"error": f"profile {auth_profile!r}: {e}", "target": target}
        # Pull the resolved value into local vars; do not echo into logs.
        if prof.flow == "bearer":
            if resolved.token is None:
                return {
                    "error": f"profile {auth_profile!r}: bearer profile resolved no token",
                    "target": target,
                }
            flow = "bearer_static"
            bearer_token = resolved.token.reveal()
            login_url = ""
            username = ""
            password = ""
        else:
            if resolved.password is None:
                return {
                    "error": f"profile {auth_profile!r}: form profile resolved no password",
                    "target": target,
                }
            flow = "form_post"
            login_url = prof.login_url
            username = prof.username
            password = resolved.password.reveal()
            username_field = prof.username_field or username_field
            password_field = prof.password_field or password_field
            success_marker = prof.success_marker or success_marker
    else:
        # Legacy path: warn but accept.
        if password or bearer_token:
            logger.warning(
                "authenticated_scan: raw password/bearer_token in MCP call. "
                "Migrate to auth_profile (will be removed in ptai 0.11). "
                "See: pentest-ai auth profile add"
            )
        flow = "bearer_static" if bearer_token else "form_post"

    authenticator = WebAuthenticator(
        flow=flow,
        login_url=login_url,
        username=username,
        password=password,
        username_field=username_field,
        password_field=password_field,
        success_marker=success_marker,
        success_status=success_status,
        bearer_token=bearer_token,
        body_shape=(prof.body_shape or "json") if auth_profile else "json",
        token_path=prof.token_path if auth_profile else "",
    )

    # Async-task pattern: a real authenticated scan is the same >60s
    # class of pathology as start_engagement (commit f2c58d3) and the
    # 13 specialist tools (commit b8d2f10). Returning sync used to mean
    # MCP clients hit "Connection closed" before findings landed. Now
    # the scan runs in the background; callers poll get_findings.
    db = get_findings_db()
    if not engagement_id:
        engagement = await db.create_engagement(
            target=target, scope="web_authenticated",
            rules_of_engment="", intensity="normal",
        )
        engagement_id = engagement["id"]
    eng_id = engagement_id

    async def _run() -> None:
        try:
            result = await run_authenticated_scan(
                target=target,
                authenticator=authenticator,
                max_pages=max_pages,
                timeout_seconds=timeout_seconds,
            )
        except AuthError:
            await db.update_engagement_status(eng_id, "failed")
            return
        except Exception:
            await db.update_engagement_status(eng_id, "failed")
            return

        for f in result.get("findings", []) or []:
            f["engagement_id"] = eng_id
            await db.add_finding(f)
        await db.update_engagement_status(eng_id, "completed")

    asyncio.create_task(_run())

    return {
        "engagement_id": eng_id,
        "target": target,
        "status": "running",
        "message": (
            f"Authenticated scan {eng_id} started against {target}. "
            f"Runs asynchronously. Poll get_engagement_status('{eng_id}') for "
            f"progress and get_findings(engagement_id='{eng_id}') for results."
        ),
    }


# ─── Active Directory Testing ────────────────────────────────────────────


@mcp.tool()
async def test_active_directory(
    domain: str,
    target_ip: str,
    auth_profile: str = "",
    credentials: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Run Active Directory security assessment.

    Includes: BloodHound enumeration, Kerberoasting, AS-REP roasting,
    privilege escalation paths, delegation attacks, and domain dominance.

    Recommended (secure): pass ``auth_profile`` = name of an ntlm profile
    created via ``pentest-ai auth profile add``. The password is resolved
    server-side and never enters the MCP/LLM context.

    Deprecated (insecure, removed in 0.11): ``credentials`` dict literal.
    """
    from agents.ad.ad_agent import ADAgent

    if auth_profile:
        if credentials:
            return {"error": "auth_profile is mutually exclusive with credentials"}
        try:
            from cli.auth_profiles import (
                ProfileError,
                get_profile,
            )
            from cli.auth_profiles import (
                resolve as resolve_profile,
            )
            from cli.credential_resolvers import SecurityError

            prof = get_profile(auth_profile)
            resolved = resolve_profile(prof)
        except (ProfileError, SecurityError) as e:
            return {"error": f"profile {auth_profile!r}: {e}"}
        if resolved.password is None:
            return {"error": f"profile {auth_profile!r} resolved no password"}
        credentials = {
            "username": prof.username,
            "domain": prof.domain or domain,
            "password": resolved.password.reveal(),
        }
    elif credentials:
        logger.warning(
            "test_active_directory: raw credentials in MCP call. "
            "Migrate to auth_profile (will be removed in ptai 0.11)."
        )

    agent = ADAgent(get_tool_registry(), get_findings_db())
    # ADAgent.run_assessment doesn't accept credentials yet; the resolved
    # `credentials` dict above is unused until AD gets a set_auth pathway
    # parallel to WebAgent. Tracking that as a follow-up; for now the
    # assessment runs against the AD target with whatever ambient creds
    # the operator's environment provides.
    del credentials
    return await _spawn_specialist(
        target=domain, scope="active_directory", engagement_id="",
        coro_factory=lambda eng: agent.run_assessment(domain, target_ip, engagement_id=eng),
        extras={"domain": domain, "target_ip": target_ip},
    )


# ─── Cloud Security ──────────────────────────────────────────────────────


@mcp.tool()
async def test_cloud(
    provider: str,
    target: str,
    auth_profile: str = "",
    credentials: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Run cloud security assessment.

    Providers: aws, azure, gcp

    Tests for: Misconfigurations, exposed secrets, overly permissive IAM,
    vulnerable services, and privilege escalation paths.

    Recommended (secure): pass ``auth_profile`` = name of a profile that
    references the cloud credential (env var, op://, vault path, AWS-SM ARN).

    Deprecated (insecure, removed in 0.11): ``credentials`` dict literal.
    """
    from agents.cloud.cloud_agent import CloudAgent

    if auth_profile:
        if credentials:
            return {"error": "auth_profile is mutually exclusive with credentials"}
        try:
            from cli.auth_profiles import (
                ProfileError,
                get_profile,
            )
            from cli.auth_profiles import (
                resolve as resolve_profile,
            )
            from cli.credential_resolvers import SecurityError

            prof = get_profile(auth_profile)
            resolved = resolve_profile(prof)
        except (ProfileError, SecurityError) as e:
            return {"error": f"profile {auth_profile!r}: {e}"}
        secret_value = ""
        if resolved.token is not None:
            secret_value = resolved.token.reveal()
        elif resolved.password is not None:
            secret_value = resolved.password.reveal()
        if not secret_value:
            return {"error": f"profile {auth_profile!r} resolved no credential"}
        credentials = {"profile_name": auth_profile, "secret": secret_value}
    elif credentials:
        logger.warning(
            "test_cloud: raw credentials in MCP call. "
            "Migrate to auth_profile (will be removed in ptai 0.11)."
        )

    agent = CloudAgent(get_tool_registry(), get_findings_db())
    # CloudAgent.run_assessment doesn't accept credentials yet; resolved
    # `credentials` is unused pending a set_auth pathway. See parallel
    # comment in test_active_directory above.
    del credentials
    return await _spawn_specialist(
        target=target, scope="cloud", engagement_id="",
        coro_factory=lambda eng: agent.run_assessment(provider, target, engagement_id=eng),
        extras={"provider": provider},
    )


# ─── Exploit Chaining ────────────────────────────────────────────────────


@mcp.tool()
async def discover_attack_chains(engagement_id: str) -> dict[str, Any]:
    """Discover attack chains from existing findings.

    Analyzes all findings for an engagement and identifies how they can
    be chained together to achieve full system compromise.
    """
    from agents.exploit_chain.chain_agent import ExploitChainAgent

    agent = ExploitChainAgent(get_findings_db())
    chains = await agent.discover_chains(engagement_id)

    return {
        "engagement_id": engagement_id,
        "chains_found": len(chains),
        "chains": chains,
    }


# ─── Report Generation ───────────────────────────────────────────────────


@mcp.tool()
async def generate_report(
    engagement_id: str,
    format: str = "markdown",
    include_pocs: bool = True,
    include_detections: bool = True,
) -> dict[str, Any]:
    """Generate a professional pentest report (asynchronous).

    Formats: markdown, html, pdf, json

    Includes executive summary, technical findings, attack chains,
    proof of concepts, remediation guidance, and detection rules.

    Returns immediately with status='running'. PDF generation in
    particular can take 30-60s; the underlying file lands at
    reports/pentest-<engagement_id>-<date>.<format>. Poll the file or
    call get_engagement_summary(engagement_id) once the report exists.
    """
    from agents.report.report_agent import ReportAgent

    db = get_findings_db()
    agent = ReportAgent(db)

    async def _run() -> None:
        try:
            await agent.generate_report(engagement_id, format, include_pocs, include_detections)
        except Exception as exc:
            logger.warning("generate_report failed for %s: %s", engagement_id, exc)

    asyncio.create_task(_run())

    return {
        "engagement_id": engagement_id,
        "format": format,
        "status": "running",
        "message": (
            f"Report generation started for {engagement_id} (format={format}). "
            f"File will land at reports/pentest-{engagement_id}-<date>.{format} "
            f"once complete."
        ),
    }


# ─── Detection Rule Generation ───────────────────────────────────────────


@mcp.tool()
async def generate_detection_rules(engagement_id: str) -> dict[str, Any]:
    """Generate detection rules (Sigma, SPL, KQL) for all discovered attacks.

    Every offensive technique gets a corresponding detection rule for blue
    teams. Runs asynchronously; returns immediately with status='running'.
    Rules attach to findings in the engagement; pull them with
    get_findings(engagement_id) once status flips to 'completed'.
    """
    from agents.detection.detection_agent import DetectionAgent

    db = get_findings_db()
    agent = DetectionAgent(db)

    async def _run() -> None:
        try:
            await agent.generate_rules(engagement_id)
        except Exception as exc:
            logger.warning("generate_detection_rules failed for %s: %s", engagement_id, exc)

    asyncio.create_task(_run())

    return {
        "engagement_id": engagement_id,
        "status": "running",
        "message": (
            f"Detection rule generation started for {engagement_id}. "
            f"Poll get_findings(engagement_id='{engagement_id}') for "
            f"detection_rules attached to each finding."
        ),
    }


# ─── PoC Validation ──────────────────────────────────────────────────────


@mcp.tool()
async def validate_finding(finding_id: str) -> dict[str, Any]:
    """Validate a specific finding with a safe, non-destructive proof of concept.

    Confirms the vulnerability is real and exploitable without causing
    damage. Runs asynchronously (PoC execution can take 30-120s);
    returns immediately with status='running'. Once complete, the
    finding's poc_status flips to 'confirmed' or 'failed' — pull the
    updated finding via get_findings to read it.
    """
    from agents.poc_validator.poc_agent import PoCAgent

    db = get_findings_db()
    agent = PoCAgent(db)

    async def _run() -> None:
        try:
            await agent.validate_finding(finding_id)
        except Exception as exc:
            logger.warning("validate_finding failed for %s: %s", finding_id, exc)

    asyncio.create_task(_run())

    return {
        "finding_id": finding_id,
        "status": "running",
        "message": (
            f"PoC validation started for finding {finding_id}. "
            f"Pull the updated finding via get_findings to see "
            f"poc_status (confirmed / failed)."
        ),
    }


# ─── Specialist Agents Not Wired Above ───────────────────────────────────


async def _spawn_specialist(
    *,
    target: str,
    scope: str,
    engagement_id: str,
    coro_factory: Any,
    extras: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Shared async-task pattern for the specialist test_* MCP tools.

    Creates an engagement (or reuses the caller-provided one), spawns the
    agent's run_assessment coroutine as a detached background task, and
    returns immediately with status='running'. The pattern matches what
    start_engagement already does (commit f2c58d3) — this helper just
    factors out the boilerplate so the 8+ specialist wrappers stay terse.

    `coro_factory(eng_id)` must return the awaitable that runs the agent
    against `eng_id`. The wrapping task marks the engagement completed
    on success or failed on exception.
    """
    db = get_findings_db()
    if not engagement_id:
        engagement = await db.create_engagement(
            target=target, scope=scope, rules_of_engment="", intensity="normal",
        )
        engagement_id = engagement["id"]

    eng_id = engagement_id

    async def _run() -> None:
        try:
            await coro_factory(eng_id)
            await db.update_engagement_status(eng_id, "completed")
        except Exception:
            await db.update_engagement_status(eng_id, "failed")

    asyncio.create_task(_run())

    return {
        "engagement_id": eng_id,
        "target": target,
        "scope": scope,
        "status": "running",
        "message": (
            f"{scope} assessment {eng_id} started against {target}. "
            f"Runs asynchronously. Poll get_engagement_status('{eng_id}') for "
            f"progress and get_findings(engagement_id='{eng_id}') for results."
        ),
        **(extras or {}),
    }


@mcp.tool()
async def test_api_security(
    target: str,
    spec_url: str = "",
    engagement_id: str = "",
) -> dict[str, Any]:
    """Run API security testing (REST + GraphQL) following OWASP API Top 10.

    Tests for: BOLA/IDOR, JWT alg-confusion, OAuth callback validation,
    rate-limit bypass, mass assignment, GraphQL introspection. Returns
    immediately with engagement_id; agent runs asynchronously.
    """
    from agents.api_security.api_security_agent import APISecurityAgent
    agent = APISecurityAgent(get_tool_registry(), get_findings_db())
    return await _spawn_specialist(
        target=target, scope="api_security", engagement_id=engagement_id,
        coro_factory=lambda eng: agent.run_assessment(target, spec_url=spec_url, engagement_id=eng),
    )


@mcp.tool()
async def test_credentials(
    target: str,
    userlist: str = "",
    wordlist: str = "",
    engagement_id: str = "",
) -> dict[str, Any]:
    """Run authentication testing (default creds, password spray, MFA bypass).

    Lockout-aware. Prefers spraying over brute force on production targets.
    Returns immediately with engagement_id; agent runs asynchronously.
    """
    from agents.credential_tester.credential_tester_agent import CredentialTesterAgent
    agent = CredentialTesterAgent(get_tool_registry(), get_findings_db())
    return await _spawn_specialist(
        target=target, scope="credentials", engagement_id=engagement_id,
        coro_factory=lambda eng: agent.run_assessment(target, userlist=userlist, wordlist=wordlist, engagement_id=eng),
    )


@mcp.tool()
async def test_vulnerabilities(
    target: str,
    templates: str = "cves,vulnerabilities,misconfiguration,exposures",
    engagement_id: str = "",
) -> dict[str, Any]:
    """Run vulnerability scanning (Nuclei + RouterSploit + nikto + dirb).

    De-duplicates against findings already in the engagement, filters
    false positives, scores by CVSS + EPSS exploit probability. Returns
    immediately with engagement_id; agent runs asynchronously.
    """
    from agents.vuln_scanner.vuln_scanner_agent import VulnScannerAgent
    agent = VulnScannerAgent(get_tool_registry(), get_findings_db())
    return await _spawn_specialist(
        target=target, scope="vulnerabilities", engagement_id=engagement_id,
        coro_factory=lambda eng: agent.run_assessment(target, templates=templates, engagement_id=eng),
    )


@mcp.tool()
async def test_privesc(
    target: str,
    platform: str = "linux",
    engagement_id: str = "",
) -> dict[str, Any]:
    """Run privilege escalation enumeration on a compromised host.

    Platforms: linux, windows, container. Uses linpeas/winpeas/deepce
    plus kernel-exploit-suggester. Enumeration only by default. Returns
    immediately with engagement_id; agent runs asynchronously.
    """
    from agents.privesc.privesc_agent import PrivescAdvisorAgent
    agent = PrivescAdvisorAgent(get_tool_registry(), get_findings_db())
    return await _spawn_specialist(
        target=target, scope="privesc", engagement_id=engagement_id,
        coro_factory=lambda eng: agent.run_assessment(target, platform=platform, engagement_id=eng),
    )


@mcp.tool()
async def test_mobile(
    target: str,
    platform: str = "android",
    engagement_id: str = "",
) -> dict[str, Any]:
    """Run mobile app security testing (Android or iOS).

    Static + dynamic analysis. OWASP Mobile Top 10 coverage. Returns
    immediately with engagement_id; agent runs asynchronously.
    """
    from agents.mobile.mobile_agent import MobileAgent
    agent = MobileAgent(get_tool_registry(), get_findings_db())
    return await _spawn_specialist(
        target=target, scope="mobile", engagement_id=engagement_id,
        coro_factory=lambda eng: agent.run_assessment(target, platform=platform, engagement_id=eng),
    )


@mcp.tool()
async def test_wireless(
    target: str,
    interface: str = "wlan0",
    engagement_id: str = "",
) -> dict[str, Any]:
    """Run wireless security assessment (WiFi + Bluetooth). Returns
    immediately with engagement_id; agent runs asynchronously."""
    from agents.wireless.wireless_agent import WirelessAgent
    agent = WirelessAgent(get_tool_registry(), get_findings_db())
    return await _spawn_specialist(
        target=target, scope="wireless", engagement_id=engagement_id,
        coro_factory=lambda eng: agent.run_assessment(target, interface=interface, engagement_id=eng),
    )


@mcp.tool()
async def test_social_engineering(
    target: str,
    campaign_type: str = "phishing",
    targets_list: list[str] | None = None,
    engagement_id: str = "",
) -> dict[str, Any]:
    """Run a social engineering assessment (phishing simulation, OSINT, DMARC audit).
    Returns immediately with engagement_id; agent runs asynchronously."""
    from agents.social_engineer.social_engineer_agent import SocialEngineerAgent
    agent = SocialEngineerAgent(get_tool_registry(), get_findings_db())
    return await _spawn_specialist(
        target=target, scope="social_engineering", engagement_id=engagement_id,
        coro_factory=lambda eng: agent.run_assessment(
            target, campaign_type=campaign_type, targets_list=targets_list, engagement_id=eng,
        ),
    )


@mcp.tool()
async def browser_inspect(
    url: str,
    action: str = "headers",
) -> dict[str, Any]:
    """Inspect a URL with the headless browser.

    Actions: headers (security headers), dom (forms+links+scripts),
    network (request log), forms, cookies, screenshot.
    """
    from agents.browser.browser_agent import BrowserAgent
    agent = BrowserAgent()
    if action == "headers":
        return {"url": url, "result": await agent.check_security_headers(url)}
    if action == "dom":
        return {"url": url, "result": await agent.inspect_dom(url)}
    if action == "network":
        return {"url": url, "result": await agent.capture_network(url)}
    if action == "forms":
        return {"url": url, "result": await agent.extract_forms(url)}
    if action == "cookies":
        return {"url": url, "result": await agent.get_cookies(url)}
    if action == "screenshot":
        return {"url": url, "result": "screenshot captured", "bytes": len(await agent.capture_screenshot(url))}
    return {"error": f"unknown action: {action}", "valid": ["headers", "dom", "network", "forms", "cookies", "screenshot"]}


# ─── Selection / Router ──────────────────────────────────────────────────


@mcp.tool()
async def select_agent(target: str, intent: str = "") -> dict[str, Any]:
    """Pick the right specialist agent for a target + optional intent hint.

    Heuristic, deterministic, no LLM call. Returns
    {"target", "agent", "reason", "confidence"}. Use this as a first
    step when an MCP client gets a free-form request and needs to know
    which test_* tool to invoke (e.g. test_web_app vs test_active_directory
    vs test_api_security).
    """
    from agents.selection.selection_agent import route_target
    return route_target(target, intent=intent)


# ─── Process Control ─────────────────────────────────────────────────────


@mcp.tool()
async def list_processes() -> list[dict[str, Any]]:
    """List running tool subprocesses tracked by the engine.

    Each entry includes pid, tool, target, runtime_seconds, engagement_id,
    and cmd. Useful for monitoring long-running scans (nuclei, masscan,
    full-portscan nmap) and deciding whether to kill them.
    """
    from engine.process_registry import get_default_registry
    return [r.to_dict() for r in get_default_registry().list_records()]


@mcp.tool()
async def kill_process(pid: int, grace_seconds: float = 2.0) -> dict[str, Any]:
    """Terminate a running tool subprocess by PID.

    Sends SIGTERM, waits up to grace_seconds, then escalates to SIGKILL.
    Returns {"killed": bool, "pid": int}. Use list_processes first to
    confirm the PID is one ptai owns.
    """
    from engine.process_registry import get_default_registry
    killed = await get_default_registry().kill(pid, grace_seconds=grace_seconds)
    return {"killed": killed, "pid": pid}


# ─── Built-in Scanners (No External Tools Required) ──────────────────────


@mcp.tool()
async def builtin_scan(
    target: str,
    scan_type: str = "all",
) -> dict[str, Any]:
    """Run built-in security scans without requiring any external tools.

    Works immediately after install. Scan types: all, ports, headers, ssl, paths, dns, secrets.
    Includes: port scanning, HTTP header analysis, SSL/TLS checks, sensitive path discovery,
    DNS enumeration, and secret/credential detection in responses.
    """
    from engine.scanners import run_builtin_scan

    result = await run_builtin_scan(target, scan_type)

    # Auto-store findings
    if result.get("findings"):
        db = get_findings_db()
        for f in result["findings"]:
            f["engagement_id"] = ""
            await db.add_finding(f)

    return result


@mcp.tool()
async def scan_ports_builtin(target: str) -> dict[str, Any]:
    """Scan common ports on a target (built-in, no nmap required)."""
    from engine.scanners import scan_ports

    findings = await scan_ports(target)
    return {"target": target, "findings_count": len(findings), "findings": findings}


@mcp.tool()
async def scan_headers_builtin(target: str) -> dict[str, Any]:
    """Analyze HTTP security headers (built-in)."""
    from engine.scanners import scan_http_headers

    findings = await scan_http_headers(target)
    return {"target": target, "findings_count": len(findings), "findings": findings}


@mcp.tool()
async def scan_ssl_builtin(target: str, port: int = 443) -> dict[str, Any]:
    """Check SSL/TLS configuration (built-in)."""
    from engine.scanners import check_ssl

    findings = await check_ssl(target, port)
    return {"target": target, "findings_count": len(findings), "findings": findings}


@mcp.tool()
async def scan_paths_builtin(target: str) -> dict[str, Any]:
    """Scan for common sensitive paths (built-in)."""
    from engine.scanners import scan_common_paths

    findings = await scan_common_paths(target)
    return {"target": target, "findings_count": len(findings), "findings": findings}


@mcp.tool()
async def scan_dns_builtin(target: str) -> dict[str, Any]:
    """Perform DNS enumeration (built-in)."""
    from engine.scanners import check_dns

    findings = await check_dns(target)
    return {"target": target, "findings_count": len(findings), "findings": findings}


@mcp.tool()
async def scan_secrets_builtin(target: str) -> dict[str, Any]:
    """Scan HTTP responses for leaked secrets and credentials (built-in)."""
    from engine.scanners import scan_secrets_in_response

    findings = await scan_secrets_in_response(target)
    return {"target": target, "findings_count": len(findings), "findings": findings}


# ─── Engagement Management Extras ────────────────────────────────────────


@mcp.tool()
async def get_engagement_summary(engagement_id: str) -> dict[str, Any]:
    """Get a summary of an engagement including finding counts, chains, and rules."""
    db = get_findings_db()
    return await db.get_engagement_summary(engagement_id)


@mcp.tool()
async def list_engagements(
    limit: int = 20,
    status_filter: str | None = None,
) -> list[dict[str, Any]]:
    """List all pentest engagements, optionally filtered by status."""
    db = get_findings_db()
    return await db.list_engagements(limit=limit, status_filter=status_filter)


@mcp.tool()
async def resume_engagement(engagement_id: str) -> dict[str, Any]:
    """Resume an interrupted engagement from its last checkpoint.

    Returns immediately with status='running' and runs the resume in a
    background task — same async-task pattern as start_engagement
    (commit f2c58d3) so the MCP client doesn't time out on long
    resumes. Poll get_engagement_status / get_findings to track progress.
    """
    db = get_findings_db()
    eng = await db.get_engagement(engagement_id)
    if not eng:
        return {"error": f"Engagement {engagement_id} not found"}

    checkpoint = await db.get_checkpoint(engagement_id)
    if not checkpoint:
        return {"error": f"No checkpoint found for {engagement_id}"}

    if checkpoint["status"] == "completed":
        return {"engagement_id": engagement_id, "status": "already_completed"}

    orch = get_orchestrator()

    async def _run() -> None:
        try:
            await orch.resume_engagement(eng)
            await db.update_engagement_status(engagement_id, "completed")
        except Exception:
            await db.update_engagement_status(engagement_id, "failed")

    asyncio.create_task(_run())

    return {
        "engagement_id": engagement_id,
        "status": "running",
        "resumed_from": checkpoint.get("completed_phases", []),
        "message": (
            f"Resume started for {engagement_id}. Runs asynchronously. "
            f"Poll get_engagement_status('{engagement_id}') for progress."
        ),
    }


@mcp.tool()
async def close_engagement(engagement_id: str) -> dict[str, Any]:
    """Close an engagement and mark it as completed."""
    db = get_findings_db()
    await db.update_engagement_status(engagement_id, "completed")
    return {"engagement_id": engagement_id, "status": "completed"}


# ─── Compliance & Evidence ───────────────────────────────────────────────


@mcp.tool()
async def query_compliance(
    engagement_id: str,
    framework: str = "all",
) -> dict[str, Any]:
    """Query compliance mapping for an engagement's findings.

    Frameworks: pci_dss, hipaa, soc2, owasp, all
    Returns findings grouped by compliance control.
    """
    db = get_findings_db()
    findings_list = await db.get_findings(engagement_id=engagement_id)
    from engine.compliance import map_finding_compliance

    results: dict[str, list[dict]] = {}
    for f in findings_list:
        mapping = map_finding_compliance(f)
        for fw, controls in mapping.items():
            if framework != "all" and fw != framework:
                continue
            for ctrl in controls:
                key = f"{fw}:{ctrl}"
                results.setdefault(key, []).append({"title": f.get("title"), "severity": f.get("severity")})
    return {"engagement_id": engagement_id, "framework": framework, "controls": results}


@mcp.tool()
async def get_evidence(
    engagement_id: str,
    finding_id: str | None = None,
) -> dict[str, Any]:
    """Retrieve evidence artifacts for an engagement or specific finding."""
    import os
    from pathlib import Path

    evidence_dir = Path(os.getenv("PENTEST_EVIDENCE_DIR", "evidence")) / engagement_id
    if not evidence_dir.exists():
        return {"engagement_id": engagement_id, "artifacts": [], "message": "No evidence directory found"}

    artifacts = []
    for f in sorted(evidence_dir.iterdir()):
        if finding_id and finding_id not in f.name:
            continue
        artifacts.append({
            "filename": f.name,
            "size_bytes": f.stat().st_size,
            "path": str(f),
        })
    return {"engagement_id": engagement_id, "artifacts": artifacts}


@mcp.tool()
async def list_plugins() -> list[dict[str, Any]]:
    """List installed YAML plugins from ~/.pentest-ai/plugins/."""
    from tools.plugin_loader import load_plugins
    return load_plugins()


@mcp.tool()
async def get_config() -> dict[str, Any]:
    """Get current pentest-ai configuration (secrets masked)."""
    from config.settings import load_config
    return load_config().to_dict(mask_secrets=True)


@mcp.tool()
async def set_intensity(engagement_id: str, intensity: str) -> dict[str, Any]:
    """Change scan intensity (stealth, normal, aggressive) mid-engagement.

    Persists to DB. If the engagement is currently running, also updates the
    live rate limiter so subsequent phases respect the new pace immediately.
    """
    db = get_findings_db()
    eng = await db.get_engagement(engagement_id)
    if not eng:
        return {"error": f"engagement not found: {engagement_id}", "engagement_id": engagement_id}

    orch = get_orchestrator()
    try:
        await orch.set_intensity(engagement_id, intensity)
    except ValueError as e:
        return {"error": str(e), "engagement_id": engagement_id}
    return {
        "engagement_id": engagement_id,
        "intensity": intensity,
        "applied_live": orch.is_running,
    }


# ─── Campaign Management ────────────────────────────────────────────────


@mcp.tool()
async def start_campaign(
    targets: list[str],
    scope: str = "full",
    intensity: str = "normal",
) -> dict[str, Any]:
    """Start a multi-target campaign. Creates one engagement per target.

    Accepts a list of IPs, hostnames, or URLs.
    """
    db = get_findings_db()
    campaign_id = await db.create_campaign(
        name=f"Campaign ({len(targets)} targets)",
        targets=targets,
    )

    engagements = []
    for target in targets:
        eng = await db.create_engagement(
            target=target,
            scope=scope,
            intensity=intensity,
            campaign_id=campaign_id,
        )
        engagements.append(eng["id"])

    return {
        "campaign_id": campaign_id,
        "targets": len(targets),
        "engagement_ids": engagements,
        "status": "created",
    }


@mcp.tool()
async def get_campaign_summary(campaign_id: str) -> dict[str, Any]:
    """Get aggregated summary across all engagements in a campaign."""
    db = get_findings_db()
    return await db.get_campaign_summary(campaign_id)


# ─── Late MCP tool registration ──────────────────────────────────────────
#
# Submodules whose tools register against the shared `mcp` instance must
# be imported AFTER `mcp` is fully constructed (top of this file) and
# AFTER the helpers / constants they depend on (`get_findings_db`,
# `_validate_target_arg`, `logger`). Importing here at module bottom
# guarantees both ordering invariants. The lint-suppression markers are
# intentional: the import has side effects (registration), not a
# value to use here.
from mcp_server import (  # noqa: E402, F401
    probes,
    security_tools,
)

# ─── Server Entry Point ──────────────────────────────────────────────────


def run_server(transport: str = "stdio", host: str = "0.0.0.0", port: int = 8765):
    """Start the MCP server."""
    logging.basicConfig(level=logging.INFO)
    logger.info(f"Starting pentest-ai MCP server v0.1.0 ({transport})")

    if transport == "stdio":
        mcp.run(transport="stdio")
    else:
        mcp.run(transport="sse", host=host, port=port)


if __name__ == "__main__":
    run_server()
