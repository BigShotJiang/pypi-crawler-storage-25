"""Interactive tool-installer wizard for ptai.

Presents a 1-2-3 tier picker, accepts a comma-separated skip list,
then dispatches to engine.tool_installer.install_tier.

Kept dependency-light so it works whether or not rich is fully wired.
"""

from __future__ import annotations

from rich.console import Console

from engine.tool_installer import (
    InstallTier,
    audit_tools,
    install_tier,
    install_tool_by_name,
    print_audit,
)

console = Console()

_TIER_CHOICES: dict[str, InstallTier] = {
    "1": InstallTier.CORE,
    "2": InstallTier.RECOMMENDED,
    "3": InstallTier.FULL,
}


def _parse_skip_list(raw: str) -> tuple[str, ...]:
    """Split a comma-separated skip list into a tuple of trimmed names."""
    if not raw:
        return ()
    return tuple(item.strip() for item in raw.split(",") if item.strip())


_QUIT = object()  # sentinel returned by _prompt_choice when the user bails


def _prompt_choice(input_fn=input):
    """Prompt for a top-level choice: tier, per-tool, or quit.

    Returns:
      * an ``InstallTier`` for choices 1-3,
      * the literal string ``"per-tool"`` for choice 4,
      * ``_QUIT`` if the user opts out.
    """
    console.print("[bold cyan]ptai tool installer wizard[/bold cyan]")
    console.print("Pick how you want to install:")
    console.print("  [cyan]1[/cyan]. Core (~30s)        nmap, nikto, sqlmap, nuclei, dnsutils")
    console.print("  [cyan]2[/cyan]. Recommended (~5m)  + ffuf, gobuster, hydra, john, hashcat")
    console.print("  [cyan]3[/cyan]. Full (~30m)        + AD, cloud, mobile, recon, binary")
    console.print("  [cyan]4[/cyan]. Specific tools     pick by name (e.g. wpscan,dalfox)")
    console.print("  [cyan]q[/cyan]. Quit without installing")
    choice = input_fn("Choice [1/2/3/4/q]: ").strip().lower()
    if choice in {"q", "quit", "exit", ""}:
        return _QUIT
    if choice == "4":
        return "per-tool"
    return _TIER_CHOICES.get(choice, _QUIT)


# Back-compat alias for callers / tests that imported the old name.
_prompt_tier = _prompt_choice


def install_named(names: list[str]) -> dict:
    """Install a specific list of tools by name. Returns a summary dict."""
    results: list[dict] = []
    installed_count = 0
    failed_count = 0
    for name in names:
        ok, message = install_tool_by_name(name)
        status = "installed" if ok else "failed"
        results.append({"tool": name, "status": status, "message": message})
        if ok:
            installed_count += 1
            console.print(f"  [green]✓[/green] {name}")
        else:
            failed_count += 1
            console.print(f"  [red]✗[/red] {name}: {message}")
    console.print(
        f"\n[bold green]{installed_count} installed[/bold green], "
        f"[bold red]{failed_count} failed[/bold red]"
    )
    return {
        "installed": installed_count,
        "failed": failed_count,
        "skipped": 0,
        "details": results,
    }


def run_install_wizard(input_fn=input) -> dict | None:
    """Run the interactive install wizard.

    Returns the install_tier (or install_named) result dict, or None if the
    user quit. ``input_fn`` is injectable so tests can drive without stdin.
    """
    audit = audit_tools()
    print_audit(audit)

    choice = _prompt_choice(input_fn)
    if choice is _QUIT or choice is None:
        console.print("[dim]No tier selected. Built-in scanners are always available.[/dim]")
        return None

    if choice == "per-tool":
        raw = input_fn(
            "Tool names (comma-separated, e.g. wpscan,dalfox,paramspider): "
        ).strip()
        names = list(_parse_skip_list(raw))  # reuse the comma-splitting helper
        if not names:
            console.print("[dim]No tools entered. Nothing to install.[/dim]")
            return None
        console.print(f"[dim]Installing: {', '.join(names)}[/dim]")
        return install_named(names)

    raw_skip = input_fn(
        "Skip any tools by comma-separated name (or leave blank): "
    ).strip()
    skip_list = _parse_skip_list(raw_skip)

    if skip_list:
        console.print(f"[dim]Skipping: {', '.join(skip_list)}[/dim]")

    return install_tier(choice, skip_tools=skip_list)
