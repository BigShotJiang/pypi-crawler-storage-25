"""Tests for engine.agents.anthropic_agent.

The Anthropic SDK is mocked. Real network calls happen in the e2e CI
job, not the unit suite.
"""
from __future__ import annotations

import pytest

from engine.agent_loop import Action
from engine.agents.anthropic_agent import AnthropicAgent


class _Block:
    def __init__(self, text):
        self.text = text


class _Resp:
    def __init__(self, text):
        self.content = [_Block(text)]
        self.stop_reason = "end_turn"


class _FakeMessages:
    def __init__(self, response_text: str):
        self._response_text = response_text
        self.calls: list[dict] = []

    async def create(self, **kw):
        self.calls.append(kw)
        return _Resp(self._response_text)


class _FakeAnthropic:
    def __init__(self, response_text: str):
        self.messages = _FakeMessages(response_text)


@pytest.mark.asyncio
async def test_anthropic_agent_parses_action_json():
    fake_response = (
        '{"action": "probe.jwt_alg_none", '
        '"args": {"endpoints": ["/api/Users/"]}, '
        '"rationale": "user list endpoint commonly exposed"}'
    )
    client = _FakeAnthropic(fake_response)
    agent = AnthropicAgent(client=client, registered_handlers=["probe.jwt_alg_none"])

    state = {"engagement_id": "eng-1", "iteration": 0, "findings_total": 0}
    action = await agent.decide_next_action(state)

    assert isinstance(action, Action)
    assert action.name == "probe.jwt_alg_none"
    assert action.args == {"endpoints": ["/api/Users/"]}
    assert "user list endpoint" in action.rationale


@pytest.mark.asyncio
async def test_anthropic_agent_returns_finish_when_llm_says_so():
    fake_response = '{"action": "finish", "args": {}, "rationale": "coverage complete"}'
    client = _FakeAnthropic(fake_response)
    agent = AnthropicAgent(client=client, registered_handlers=["probe.jwt_alg_none"])
    action = await agent.decide_next_action({"iteration": 10})
    assert action.name == "finish"


@pytest.mark.asyncio
async def test_anthropic_agent_falls_back_on_unparseable_response():
    fake_response = "I think you should do something but I forgot the JSON"
    client = _FakeAnthropic(fake_response)
    agent = AnthropicAgent(client=client, registered_handlers=[])
    action = await agent.decide_next_action({"iteration": 1})
    assert action.name == "finish"
    assert "parse" in action.rationale.lower() or "unparseable" in action.rationale.lower()


@pytest.mark.asyncio
async def test_anthropic_agent_handles_anthropic_call_failure():
    """If the SDK call raises (network down, auth failed), the agent
    must return finish rather than propagate.
    """
    class _BadMessages:
        async def create(self, **kw):
            raise RuntimeError("connection refused")

    class _BadClient:
        messages = _BadMessages()

    agent = AnthropicAgent(client=_BadClient(), registered_handlers=[])
    action = await agent.decide_next_action({"iteration": 1})
    assert action.name == "finish"
    assert "fail" in action.rationale.lower() or "connection" in action.rationale.lower()


@pytest.mark.asyncio
async def test_anthropic_agent_includes_handler_list_in_user_message():
    """The system prompt tells Claude to use only registered handlers.
    The user message has to actually list them.
    """
    fake_response = '{"action": "finish", "args": {}, "rationale": "ok"}'
    client = _FakeAnthropic(fake_response)
    agent = AnthropicAgent(
        client=client,
        registered_handlers=["probe.alpha", "probe.beta", "probe.gamma"],
    )
    await agent.decide_next_action({"iteration": 0})

    assert len(client.messages.calls) == 1
    user_msg = client.messages.calls[0]["messages"][0]["content"]
    assert "probe.alpha" in user_msg
    assert "probe.beta" in user_msg
    assert "probe.gamma" in user_msg
