"""Tests for the probe registry (engine/probes/registry.py).

The registry is the single source of truth for ptai probes. Probes register
via a decorator, carry typed metadata, and the agent loop + legacy pipeline
discover them through one query API.
"""
from __future__ import annotations

import pytest

# Registry isolation is provided by the autouse fixture in conftest.py;
# each test can call registry.clear() freely without affecting siblings.


def test_probe_decorator_registers_minimal_spec():
    from engine.probes import ProbeSpec, registry

    registry.clear()

    @registry.probe(
        name="test.minimal",
        bug_class="sqli",
        severity_max="critical",
        owasp="A03:2021",
    )
    async def my_probe(ctx):
        return []

    spec = registry.get("test.minimal")
    assert isinstance(spec, ProbeSpec)
    assert spec.name == "test.minimal"
    assert spec.bug_class == "sqli"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A03:2021"
    assert spec.fn is my_probe


def test_probe_decorator_default_metadata():
    from engine.probes import registry

    registry.clear()

    @registry.probe(name="test.defaults", bug_class="cors_misconfig", severity_max="medium")
    async def p(ctx):
        return []

    spec = registry.get("test.defaults")
    assert spec.requires == ("session", "base")
    assert spec.runtime_budget_s == 8.0
    assert spec.owasp == ""
    assert spec.tags == ()
    assert spec.requires_auth is False


def test_probe_decorator_rejects_unknown_bug_class():
    from engine.probes import registry

    registry.clear()

    with pytest.raises(ValueError, match="unknown bug_class"):

        @registry.probe(
            name="test.bad", bug_class="totally_made_up", severity_max="high"
        )
        async def p(ctx):
            return []


def test_probe_decorator_rejects_invalid_severity():
    from engine.probes import registry

    registry.clear()

    with pytest.raises(ValueError, match="severity_max"):

        @registry.probe(
            name="test.bad_sev", bug_class="sqli", severity_max="cosmic"
        )
        async def p(ctx):
            return []


def test_probe_decorator_rejects_duplicate_name():
    from engine.probes import registry

    registry.clear()

    @registry.probe(name="test.dup", bug_class="sqli", severity_max="high")
    async def first(ctx):
        return []

    with pytest.raises(ValueError, match="already registered"):

        @registry.probe(name="test.dup", bug_class="sqli", severity_max="high")
        async def second(ctx):
            return []


def test_get_returns_none_for_unknown_probe():
    from engine.probes import registry

    registry.clear()
    assert registry.get("nope.does_not_exist") is None


def test_all_returns_registered_probes():
    from engine.probes import registry

    registry.clear()

    @registry.probe(name="test.a", bug_class="sqli", severity_max="critical")
    async def a(ctx):
        return []

    @registry.probe(name="test.b", bug_class="xss_reflected", severity_max="high")
    async def b(ctx):
        return []

    names = sorted(s.name for s in registry.all())
    assert names == ["test.a", "test.b"]


def test_filter_by_bug_class():
    from engine.probes import registry

    registry.clear()

    @registry.probe(name="test.s1", bug_class="sqli", severity_max="critical")
    async def s1(ctx):
        return []

    @registry.probe(name="test.s2", bug_class="sqli", severity_max="high")
    async def s2(ctx):
        return []

    @registry.probe(name="test.x", bug_class="xss_reflected", severity_max="medium")
    async def x(ctx):
        return []

    sqli_names = sorted(s.name for s in registry.filter(bug_class="sqli"))
    assert sqli_names == ["test.s1", "test.s2"]


def test_filter_by_requires_auth():
    from engine.probes import registry

    registry.clear()

    @registry.probe(
        name="test.anon", bug_class="sqli", severity_max="critical", requires_auth=False
    )
    async def anon(ctx):
        return []

    @registry.probe(
        name="test.auth", bug_class="idor", severity_max="high", requires_auth=True
    )
    async def auth(ctx):
        return []

    anon_only = [s.name for s in registry.filter(requires_auth=False)]
    auth_only = [s.name for s in registry.filter(requires_auth=True)]
    assert anon_only == ["test.anon"]
    assert auth_only == ["test.auth"]


def test_filter_by_tag():
    from engine.probes import registry

    registry.clear()

    @registry.probe(
        name="test.fast",
        bug_class="cors_misconfig",
        severity_max="medium",
        tags=("fast", "anonymous"),
    )
    async def fast(ctx):
        return []

    @registry.probe(
        name="test.slow",
        bug_class="cors_misconfig",
        severity_max="medium",
        tags=("slow",),
    )
    async def slow(ctx):
        return []

    fast_probes = [s.name for s in registry.filter(tag="fast")]
    assert fast_probes == ["test.fast"]


def test_clear_removes_all_probes():
    from engine.probes import registry

    registry.clear()

    @registry.probe(name="test.gone", bug_class="sqli", severity_max="critical")
    async def gone(ctx):
        return []

    assert registry.get("test.gone") is not None
    registry.clear()
    assert registry.get("test.gone") is None
    assert registry.all() == []


def test_probe_spec_is_frozen():
    from dataclasses import FrozenInstanceError

    from engine.probes import ProbeSpec

    async def f(ctx):
        return []

    spec = ProbeSpec(
        name="x",
        bug_class="sqli",
        severity_max="critical",
        owasp="",
        requires=("session", "base"),
        runtime_budget_s=4.0,
        tags=(),
        requires_auth=False,
        fn=f,
    )
    with pytest.raises(FrozenInstanceError):
        spec.name = "y"  # type: ignore[misc]
