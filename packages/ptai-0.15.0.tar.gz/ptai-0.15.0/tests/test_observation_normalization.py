"""Tests for the observation normalization layer (Step 2 of the autonomy roadmap).

NormalizedResult is the typed shape sent to the LLM in place of raw probe
output. Truncation caps keep per-iteration token cost bounded.
"""
from __future__ import annotations

from unittest.mock import patch

import pytest


def test_normalized_result_truncates_evidence_at_120_chars():
    from engine.agent_loop import NormalizedResult

    n = NormalizedResult(
        tool="probe.x",
        target="http://x",
        verdict="confirmed",
        evidence="A" * 500,
    )
    assert len(n.evidence) == 120


def test_normalized_result_truncates_response_snippet_at_200_chars():
    from engine.agent_loop import NormalizedResult

    n = NormalizedResult(
        tool="probe.x",
        target="http://x",
        verdict="confirmed",
        evidence="ok",
        response_snippet="B" * 800,
    )
    assert len(n.response_snippet) == 200


def test_normalized_result_to_dict_round_trip():
    from engine.agent_loop import NormalizedResult

    n = NormalizedResult(
        tool="probe.web.sqli_fuzz",
        target="http://localhost:3000/rest/products/search",
        verdict="confirmed",
        evidence="UNION SELECT NULL bypass succeeded",
        payload_used="' UNION SELECT NULL--",
        http_status=200,
        response_snippet='{"status":"success","data":[]}',
    )
    d = n.to_dict()
    assert d["tool"] == "probe.web.sqli_fuzz"
    assert d["verdict"] == "confirmed"
    assert d["http_status"] == 200


def test_observation_default_normalized_is_none():
    from engine.agent_loop import Observation

    obs = Observation(action_name="probe.x", success=True)
    assert obs.normalized is None


def test_observation_can_carry_normalized():
    from engine.agent_loop import NormalizedResult, Observation

    n = NormalizedResult(
        tool="probe.x", target="http://x", verdict="failed", evidence="boom"
    )
    obs = Observation(action_name="probe.x", success=False, normalized=n)
    assert obs.normalized is n
    assert obs.normalized.verdict == "failed"


@pytest.mark.asyncio
async def test_bridge_populates_normalized_on_findings():
    from engine.agent_loop import _HANDLERS  # noqa: F401  - just to import module
    from engine.agents.handlers.registry_bridge import make_handler_for_spec
    from engine.probes import ProbeSpec
    from engine.working_memory import WorkingMemory

    async def fake_probe(ctx):
        return [
            {
                "id": "f-1",
                "title": "SQLi confirmed on /api/x",
                "severity": "critical",
                "category": "injection",
                "target": "http://x/api/x",
                "evidence": "status=200 union leaked",
                "payload": "' UNION SELECT NULL--",
            }
        ]

    spec = ProbeSpec(
        name="test.normalize",
        bug_class="sqli",
        severity_max="critical",
        owasp="A03:2021",
        requires=("session", "base"),
        runtime_budget_s=4.0,
        tags=(),
        requires_auth=False,
        fn=fake_probe,
    )
    handler = make_handler_for_spec(spec)
    memory = WorkingMemory(engagement_id="e-1", target="http://x")

    with patch(
        "engine.agents.handlers.registry_bridge.aiohttp.ClientSession"
    ):
        obs = await handler(memory, {})

    assert obs.success is True
    assert obs.normalized is not None
    assert obs.normalized.verdict == "confirmed"
    assert "SQLi confirmed" in obs.normalized.evidence
    assert obs.normalized.payload_used == "' UNION SELECT NULL--"
    assert obs.normalized.http_status == 200


@pytest.mark.asyncio
async def test_bridge_normalized_inconclusive_on_empty_findings():
    from engine.agents.handlers.registry_bridge import make_handler_for_spec
    from engine.probes import ProbeSpec
    from engine.working_memory import WorkingMemory

    async def fake_probe(ctx):
        return []

    spec = ProbeSpec(
        name="test.empty",
        bug_class="sqli",
        severity_max="high",
        owasp="A03:2021",
        requires=("session", "base"),
        runtime_budget_s=4.0,
        tags=(),
        requires_auth=False,
        fn=fake_probe,
    )
    handler = make_handler_for_spec(spec)
    memory = WorkingMemory(engagement_id="e-2", target="http://x")

    with patch(
        "engine.agents.handlers.registry_bridge.aiohttp.ClientSession"
    ):
        obs = await handler(memory, {})

    assert obs.normalized is not None
    assert obs.normalized.verdict == "inconclusive"
    assert "no findings" in obs.normalized.evidence


@pytest.mark.asyncio
async def test_bridge_normalized_failed_on_exception():
    from engine.agents.handlers.registry_bridge import make_handler_for_spec
    from engine.probes import ProbeSpec
    from engine.working_memory import WorkingMemory

    async def fake_probe(ctx):
        raise RuntimeError("network is on fire")

    spec = ProbeSpec(
        name="test.boom",
        bug_class="sqli",
        severity_max="critical",
        owasp="A03:2021",
        requires=("session", "base"),
        runtime_budget_s=4.0,
        tags=(),
        requires_auth=False,
        fn=fake_probe,
    )
    handler = make_handler_for_spec(spec)
    memory = WorkingMemory(engagement_id="e-3", target="http://x")

    with patch(
        "engine.agents.handlers.registry_bridge.aiohttp.ClientSession"
    ):
        obs = await handler(memory, {})

    assert obs.success is False
    assert obs.normalized is not None
    assert obs.normalized.verdict == "failed"
    assert "network is on fire" in obs.normalized.evidence
