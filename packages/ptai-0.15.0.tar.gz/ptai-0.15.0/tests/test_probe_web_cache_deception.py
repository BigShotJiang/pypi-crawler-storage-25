"""Tests for the Web Cache Deception probe.

The probe sends two requests to a delimiter-trick URL: one authenticated,
one anonymous. If the anonymous response matches the authed response
byte-for-byte, the cache served authed content to a non-authenticated
client. That's WCD.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.fixture
def captured_auth():
    return {
        "token": "x",
        "auth_header": "Authorization",
        "auth_value": "Bearer x",
        "user_id": 7,
    }


@pytest.mark.asyncio
async def test_returns_empty_when_no_captured_auth(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.web_cache_deception import probe_web_cache_deception

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=None,
    )

    findings = await probe_web_cache_deception(ctx)
    assert findings == []
    fake_session.get.assert_not_called()


@pytest.mark.asyncio
async def test_wcd_detected_when_anonymous_body_matches_authed(
    fake_session, captured_auth
):
    """First variant /api/me/.css leaks: authed and anon return same body."""
    from engine.probes import ProbeContext
    from engine.probes.web.web_cache_deception import probe_web_cache_deception

    secret_body = (
        '{"email":"victim@example.com","role":"user",'
        '"sessionId":"abc123","fullName":"Victim McUser"}'
    )
    # First base path is /api/me; first variant is /api/me/.css.
    # Sequence: authed-200-secret, anon-200-secret -> HIT, then loop
    # continues with non-matches. We cap follow-ups at empty matches.
    responses = [
        _make_response(200, secret_body),  # authed /api/me/.css
        _make_response(200, secret_body),  # anon /api/me/.css (cache hit)
    ]
    # All remaining variants miss: authed gives 404 so we skip immediately.
    responses += [_make_response(404, "not found") for _ in range(40)]
    fake_session.get.side_effect = responses

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
        endpoint_hints=("/api/me",),
    )

    findings = await probe_web_cache_deception(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "high"
    assert f["bug_class"] == "business_logic"
    assert "Web Cache Deception" in f["title"]
    assert "/api/me/.css" in f["target"]


@pytest.mark.asyncio
async def test_no_finding_when_anonymous_body_differs_from_authed(
    fake_session, captured_auth
):
    """Anonymous response differs from authed: cache is correctly partitioned."""
    from engine.probes import ProbeContext
    from engine.probes.web.web_cache_deception import probe_web_cache_deception

    authed_body = '{"email":"victim@example.com","role":"user","extra":"' + "x" * 200 + '"}'
    anon_body = '{"error":"unauthorized","code":401, "padding":"' + "x" * 200 + '"}'
    responses = []
    # 7 variants, each gets an authed and anon response.
    for _ in range(7):
        responses.append(_make_response(200, authed_body))
        responses.append(_make_response(200, anon_body))
    fake_session.get.side_effect = responses

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
        endpoint_hints=("/api/me",),
    )

    findings = await probe_web_cache_deception(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_no_finding_when_authed_body_too_short(fake_session, captured_auth):
    """Tiny bodies under min-size threshold cannot trigger a finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.web_cache_deception import probe_web_cache_deception

    tiny = "{}"
    # All variants return tiny bodies, both authed and anon. Should skip.
    responses = [_make_response(200, tiny) for _ in range(40)]
    fake_session.get.side_effect = responses

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
        endpoint_hints=("/api/me",),
    )

    findings = await probe_web_cache_deception(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_candidate_cap_bounds_runtime(fake_session, captured_auth):
    """Even with many endpoint_hints, total variants stay capped."""
    from engine.probes import ProbeContext
    from engine.probes.web import web_cache_deception
    from engine.probes.web.web_cache_deception import probe_web_cache_deception

    # 10 hints * 7 variants = 70 candidates, but cap is _MAX_CANDIDATES.
    hints = tuple(f"/api/path{i}" for i in range(10))
    # Every authed call returns 404 so probe loops without flagging.
    responses = [_make_response(404, "x") for _ in range(200)]
    fake_session.get.side_effect = responses

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
        endpoint_hints=hints,
    )

    findings = await probe_web_cache_deception(ctx)
    assert findings == []
    # Cap means we never exceed _MAX_CANDIDATES authed-GETs.
    assert fake_session.get.call_count <= web_cache_deception._MAX_CANDIDATES


def test_web_cache_deception_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import web_cache_deception

    # The autouse registry-isolation fixture restores only probes captured
    # at fixture setup; reload guarantees the decorator runs again.
    importlib.reload(web_cache_deception)

    spec = registry.get("web.cache_deception")
    assert spec is not None
    assert spec.bug_class == "business_logic"
    assert spec.severity_max == "high"
    assert spec.requires_auth is True
    assert "cache" in spec.tags
