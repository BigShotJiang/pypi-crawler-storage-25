"""Tests for the EXIF metadata exposure probe.

Validates EXIF parsing across both code paths (Pillow if installed, the
pure-python fallback otherwise), the Juice Shop /api/Memorys discovery
flow, and graceful degradation when no upload directory exists.
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Import the probe module at collection time so the @registry.probe decorator
# fires once and the conftest's `_isolate_probe_registry` fixture captures the
# probe in its saved-state snapshot. Without this, importing the module from
# inside a test body registers it for that test only, then the fixture's
# restore step drops it before the next test runs.
from engine.probes.web import exif_metadata as _exif_module  # noqa: F401

# Minimal JPEG with APP1 EXIF carrying Make=X, Model=Y, GPS sub-IFD with
# GPSLatitudeRef=N + GPSLongitudeRef=W. Hand-crafted (94 bytes) so the
# fallback parser path is exercised without depending on Pillow.
JPEG_WITH_GPS = (
    b"\xff\xd8\xff\xe1\x00XExif\x00\x00II*\x00\x08\x00\x00\x00\x03\x00"
    b"\x0f\x01\x02\x00\x02\x00\x00\x00X\x00\x00\x00\x10\x01\x02\x00\x02"
    b"\x00\x00\x00Y\x00\x00\x00%\x88\x04\x00\x01\x00\x00\x002\x00\x00"
    b"\x00\x00\x00\x00\x00\x02\x00\x01\x00\x02\x00\x02\x00\x00\x00N\x00"
    b"\x00\x00\x03\x00\x02\x00\x02\x00\x00\x00W\x00\x00\x00\x00\x00\x00"
    b"\x00\xff\xd9"
)

# Same shape but EXIF only carries Make=AB, Model=CD; no GPS sub-IFD.
JPEG_WITH_CAMERA_ONLY = (
    b"\xff\xd8\xff\xe1\x00.Exif\x00\x00II*\x00\x08\x00\x00\x00\x02\x00"
    b"\x0f\x01\x02\x00\x04\x00\x00\x00AB\x00\x00\x10\x01\x02\x00\x04\x00"
    b"\x00\x00CD\x00\x00\x00\x00\x00\x00\xff\xd9"
)

# JPEG SOI/EOI with no APP1 segment at all.
JPEG_NO_EXIF = b"\xff\xd8\xff\xd9"


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


def _make_bytes_response(status: int, data: bytes):
    resp = AsyncMock()
    resp.status = status
    resp.read = AsyncMock(return_value=data)
    resp.text = AsyncMock(return_value="")
    resp.headers = {"Content-Type": "image/jpeg"}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


def _memorys_body(paths: list[str]) -> str:
    return json.dumps({"data": [{"imagePath": p} for p in paths]})


def _route(memorys_body: str | None, image_bytes: dict[str, bytes]):
    """Build a session.get side_effect that routes by URL substring.

    memorys_body: JSON to return on /api/Memorys (None -> 404).
    image_bytes: map of URL substring -> bytes payload returned with 200.
    Anything else returns 404 with an empty body.
    """

    def side(url, **_kwargs):
        if "/api/Memorys" in url:
            if memorys_body is None:
                return _make_response(404, "")
            return _make_response(200, memorys_body)
        for needle, data in image_bytes.items():
            if needle in url:
                return _make_bytes_response(200, data)
        # Any directory walk or unknown path: 404 to keep the probe quiet.
        return _make_response(404, "")

    return side


@pytest.mark.asyncio
async def test_exif_emits_high_when_gps_present(fake_session):
    """Image with GPS coords -> high severity finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.exif_metadata import probe_exif_metadata

    fake_session.get.side_effect = _route(
        memorys_body=_memorys_body(["/assets/public/images/uploads/john.jpg"]),
        image_bytes={"john.jpg": JPEG_WITH_GPS},
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_exif_metadata(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "high"
    assert f["bug_class"] == "source_map_exposure"
    assert f["category"] == "exposure"
    assert "GPS" in f["title"]
    assert "john.jpg" in f["target"]


@pytest.mark.asyncio
async def test_exif_no_finding_when_image_has_no_metadata(fake_session):
    """Image with no EXIF data -> no finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.exif_metadata import probe_exif_metadata

    fake_session.get.side_effect = _route(
        memorys_body=_memorys_body(["/uploads/clean.jpg"]),
        image_bytes={"clean.jpg": JPEG_NO_EXIF},
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_exif_metadata(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_exif_emits_medium_when_only_camera_fingerprint(fake_session):
    """Image with EXIF Make+Model but no GPS -> medium severity."""
    from engine.probes import ProbeContext
    from engine.probes.web.exif_metadata import probe_exif_metadata

    # Force the fallback parser path so the test outcome doesn't depend on
    # whether Pillow is installed in the test environment.
    with patch(
        "engine.probes.web.exif_metadata._PILLOW_AVAILABLE",
        False,
    ):
        fake_session.get.side_effect = _route(
            memorys_body=_memorys_body(["/uploads/emma.jpg"]),
            image_bytes={"emma.jpg": JPEG_WITH_CAMERA_ONLY},
        )
        ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
        findings = await probe_exif_metadata(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "medium"
    assert f["bug_class"] == "source_map_exposure"
    assert "fingerprint" in f["title"].lower()
    assert "emma.jpg" in f["target"]


@pytest.mark.asyncio
async def test_exif_graceful_when_memorys_404(fake_session):
    """No /api/Memorys + no upload listings -> no finding, no crash."""
    from engine.probes import ProbeContext
    from engine.probes.web.exif_metadata import probe_exif_metadata

    fake_session.get.side_effect = _route(
        memorys_body=None,  # 404 on /api/Memorys
        image_bytes={},
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_exif_metadata(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_exif_caps_at_max_images(fake_session):
    """Memorys with 50 images: only the first 20 are fetched."""
    from engine.probes import ProbeContext
    from engine.probes.web import exif_metadata as mod

    paths = [f"/uploads/img{i}.jpg" for i in range(50)]
    bytes_map = {f"img{i}.jpg": JPEG_NO_EXIF for i in range(50)}
    fake_session.get.side_effect = _route(
        memorys_body=_memorys_body(paths),
        image_bytes=bytes_map,
    )

    fetched: list[str] = []
    real_fetch = mod._fetch_bytes

    async def spy(session, url):
        fetched.append(url)
        return await real_fetch(session, url)

    with patch.object(mod, "_fetch_bytes", side_effect=spy):
        ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
        await mod.probe_exif_metadata(ctx)

    assert len(fetched) <= mod._MAX_IMAGES


def test_exif_metadata_is_registered():
    from engine.probes import registry
    from engine.probes.web import exif_metadata  # noqa: F401  - registers

    spec = registry.get("web.exif_metadata")
    assert spec is not None
    assert spec.bug_class == "source_map_exposure"
    assert spec.severity_max == "high"
    assert spec.owasp == "A01:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 15.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "privacy" in spec.tags


def test_exif_fallback_parser_extracts_gps():
    """Fallback parser path works even without Pillow installed."""
    from engine.probes.web.exif_metadata import (
        _extract_with_fallback,
        _has_camera_fingerprint,
        _has_gps,
    )

    tags = _extract_with_fallback(JPEG_WITH_GPS)
    assert _has_gps(tags) is True
    assert tags.get("Make") == "X"
    assert tags.get("Model") == "Y"

    tags2 = _extract_with_fallback(JPEG_WITH_CAMERA_ONLY)
    assert _has_gps(tags2) is False
    assert _has_camera_fingerprint(tags2) is True

    tags3 = _extract_with_fallback(JPEG_NO_EXIF)
    assert _has_gps(tags3) is False
    assert _has_camera_fingerprint(tags3) is False
