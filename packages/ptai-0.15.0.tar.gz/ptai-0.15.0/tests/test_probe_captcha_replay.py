"""Tests for the CAPTCHA token replay probe.

A captcha service that does not invalidate tokens after first use lets
attackers automate any flow gated behind it. The probe issues a GET to
fetch a captcha id+answer pair, POSTs a benign feedback row, and POSTs
the same credentials a second time. Two consecutive 201s = replayable.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_captcha_replay_detects_two_consecutive_201s(fake_session):
    """GET captcha, POST 201, POST 201 again => medium business_logic finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.captcha_replay import probe_captcha_replay

    fake_session.get.side_effect = [
        _make_response(
            200,
            '{"captchaId": 42, "answer": "7"}',
            {"Content-Type": "application/json"},
        ),
    ]
    fake_session.post.side_effect = [
        _make_response(201, '{"id": 1, "comment": "first"}'),
        _make_response(201, '{"id": 2, "comment": "replay"}'),
    ]
    # Scope the captcha service path so the GET phase resolves on the first try.
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
    )

    findings = await probe_captcha_replay(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "medium"
    assert f["bug_class"] == "business_logic"
    assert f["category"] == "business_logic"
    assert f["owasp"] == "A04:2021"
    assert "replay" in f["title"].lower() or "captcha" in f["title"].lower()


@pytest.mark.asyncio
async def test_captcha_replay_no_finding_when_second_post_rejected(fake_session):
    """Second submission rejected (e.g. 401) means captcha is single-use."""
    from engine.probes import ProbeContext
    from engine.probes.web.captcha_replay import probe_captcha_replay

    fake_session.get.side_effect = [
        _make_response(200, '{"captchaId": "abc", "answer": "42"}'),
    ]
    # Alternate accepted-first then rejected-replay across every submit
    # candidate the probe walks. Use a callable so the probe never runs
    # out of mock responses regardless of how many endpoints it tries.
    _post_counter = {"n": 0}

    def _post_side_effect(*_args, **_kwargs):
        _post_counter["n"] += 1
        # Odd-numbered calls (first submission per endpoint) accepted.
        # Even-numbered calls (replay attempt) rejected.
        if _post_counter["n"] % 2 == 1:
            return _make_response(201, '{"id": 1}')
        return _make_response(401, '{"error": "invalid captcha"}')

    fake_session.post.side_effect = _post_side_effect
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
    )

    findings = await probe_captcha_replay(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_captcha_replay_no_finding_when_no_captcha_service(fake_session):
    """No captcha endpoint responds => probe exits cleanly with no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.captcha_replay import probe_captcha_replay

    # All captcha service candidates return 404.
    fake_session.get.return_value = _make_response(404, "not found")
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
    )

    findings = await probe_captcha_replay(ctx)
    assert findings == []
    # Crucially, no POST should be issued if no captcha credentials were captured.
    fake_session.post.assert_not_called()


@pytest.mark.asyncio
async def test_captcha_replay_handles_unparseable_captcha_body(fake_session):
    """Captcha endpoint returning HTML or no JSON => probe skips silently."""
    from engine.probes import ProbeContext
    from engine.probes.web.captcha_replay import probe_captcha_replay

    fake_session.get.return_value = _make_response(
        200, "<html><body>captcha image</body></html>"
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
    )

    findings = await probe_captcha_replay(ctx)
    assert findings == []
    fake_session.post.assert_not_called()


def test_captcha_replay_is_registered():
    """Registry metadata is the public contract; assert it explicitly."""
    from engine.probes import registry
    from engine.probes.web import captcha_replay  # noqa: F401  - import registers

    spec = registry.get("web.captcha_replay")
    assert spec is not None
    assert spec.bug_class == "business_logic"
    assert spec.severity_max == "medium"
    assert spec.owasp == "A04:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 8.0
    assert "anonymous" in spec.tags
    assert "destructive-low" in spec.tags
    assert "captcha" in spec.tags
