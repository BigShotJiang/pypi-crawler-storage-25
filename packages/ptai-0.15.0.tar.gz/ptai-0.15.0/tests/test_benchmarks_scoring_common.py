"""Tests for the shared scoring matcher (URL / payload substring / title match)."""
from __future__ import annotations

import pytest

from benchmarks.scoring.common import matches, GroundTruthEntry, Finding


def _gt(id_, url=None, attack_patterns=None, notes=""):
    return GroundTruthEntry(id=id_, url=url, attack_patterns=list(attack_patterns or []), notes=notes)


def _f(url=None, payload=None, title="", description=""):
    return Finding(url=url or "", payload=payload or "", title=title, description=description)


def test_url_host_path_match_wins_first():
    gt = _gt("x", url="http://localhost:3000/rest/admin/coupons")
    finding = _f(url="http://localhost:3000/rest/admin/coupons?q=1")
    assert matches(finding, gt) == "url"


def test_payload_substring_match_when_no_url_match():
    gt = _gt("x", attack_patterns=["' OR 1=1--"])
    finding = _f(url="http://localhost:3000/rest/user/login", payload="email=x' OR 1=1-- &password=y")
    assert matches(finding, gt) == "payload"


def test_no_match_returns_none():
    gt = _gt("x", url="http://localhost:3000/admin", attack_patterns=["foo"])
    finding = _f(url="http://localhost:3000/products", payload="bar")
    assert matches(finding, gt) is None


def test_url_match_ignores_query_and_fragment():
    gt = _gt("x", url="http://localhost:3000/api/users")
    finding = _f(url="http://localhost:3000/api/users?id=1#section")
    assert matches(finding, gt) == "url"


def test_url_match_case_insensitive_host_strict_path():
    gt = _gt("x", url="http://LOCALHOST:3000/api/users")
    finding = _f(url="http://localhost:3000/api/users")
    assert matches(finding, gt) == "url"


def test_payload_pattern_case_sensitive_substring():
    gt = _gt("x", attack_patterns=["UNION SELECT"])
    finding_yes = _f(payload="1 UNION SELECT password FROM users")
    finding_no = _f(payload="1 union select password from users")
    assert matches(finding_yes, gt) == "payload"
    assert matches(finding_no, gt) is None


def test_title_branch_keyword_hits_finding_title():
    gt = _gt("x", notes="Admin Section Challenge")
    finding = _f(title="Hidden admin section reachable without auth")
    assert matches(finding, gt) == "title"


def test_title_branch_keyword_hits_finding_description():
    gt = _gt("x", notes="Password Hash Leak Challenge")
    finding = _f(title="API exposure", description="Endpoint returns user password hash in response body")
    assert matches(finding, gt) == "title"


def test_title_branch_filler_only_notes_no_match():
    gt = _gt("x", notes="Find the user")
    finding = _f(title="JWT alg none accepted")
    assert matches(finding, gt) is None


def test_title_branch_short_words_filtered():
    gt = _gt("x", notes="XSS via API")
    finding = _f(title="API endpoint returns user data")
    # 'api' is 3 chars, filtered. 'via' filler. Only 'xss' (3 chars, filtered).
    # No 4+ char distinguishing words remain → no match.
    assert matches(finding, gt) is None


def test_url_match_beats_title_match():
    gt = _gt("x", url="http://localhost:3000/admin", notes="Admin Section Challenge")
    finding = _f(url="http://localhost:3000/admin", title="something completely unrelated")
    assert matches(finding, gt) == "url"
