"""Tests for the Web3 / NFT probe.

The probe walks a small list of Web3 paths (sandbox, wallet, NFT,
mint) and emits findings on accessible ones. OWASP Juice Shop
recently added these challenges (#108 sandbox, #102 NFT takeover,
#106 honey-pot mint), and pure Web3 frontends bolted onto classic
stacks tend to leak the same surfaces.
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

# Import the probe module at collection time so the @registry.probe
# decorator fires before conftest's _isolate_probe_registry fixture
# snapshots the registry. Without this, the probe is missing from the
# snapshot and the fixture's teardown removes it for subsequent tests.
from engine.probes.web import web3_probe as _web3_probe  # noqa: F401, E402


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_web3_sandbox_solidity_body_emits_medium(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.web3_probe import GET_PATHS, probe_web3

    def get_side_effect(url, **_kwargs):
        if "/#/web3-sandbox" in url:
            return _make_response(
                200,
                "<html><body>Compile your Solidity contract here</body></html>",
            )
        return _make_response(404, "")

    fake_session.get.side_effect = get_side_effect
    fake_session.post.return_value = _make_response(404, "")

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_web3(ctx)

    sandbox_findings = [f for f in findings if "Sandbox" in f["title"]]
    assert len(sandbox_findings) == 1
    assert sandbox_findings[0]["severity"] == "medium"
    assert sandbox_findings[0]["bug_class"] == "exposed_dev"
    assert "/#/web3-sandbox" in sandbox_findings[0]["target"]
    # Make sure we walked the documented set (sanity check).
    assert "/#/web3-sandbox" in GET_PATHS


@pytest.mark.asyncio
async def test_wallet_endpoint_array_emits_medium(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.web3_probe import probe_web3

    wallet_body = json.dumps([
        {"id": 1, "address": "0xdead", "balance": 100},
        {"id": 2, "address": "0xbeef", "balance": 50},
    ])

    def get_side_effect(url, **_kwargs):
        if url.endswith("/api/Wallet"):
            return _make_response(200, wallet_body)
        return _make_response(404, "")

    fake_session.get.side_effect = get_side_effect
    fake_session.post.return_value = _make_response(404, "")

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_web3(ctx)

    wallet_findings = [f for f in findings if "Wallet enumeration" in f["title"]]
    assert len(wallet_findings) == 1
    assert wallet_findings[0]["severity"] == "medium"
    assert wallet_findings[0]["bug_class"] == "exposed_dev"


@pytest.mark.asyncio
async def test_mint_success_emits_high(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.web3_probe import probe_web3

    fake_session.get.return_value = _make_response(404, "")
    fake_session.post.return_value = _make_response(
        200, json.dumps({"status": "ok", "minted": True, "tokenId": 42})
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_web3(ctx)

    mint_findings = [f for f in findings if "mint" in f["title"].lower()]
    assert len(mint_findings) == 1
    assert mint_findings[0]["severity"] == "high"
    assert mint_findings[0]["bug_class"] == "business_logic"
    assert mint_findings[0]["target"].endswith("/api/Wallet/mint")


@pytest.mark.asyncio
async def test_all_paths_404_emits_no_findings(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.web3_probe import probe_web3

    fake_session.get.return_value = _make_response(404, "")
    fake_session.post.return_value = _make_response(404, "")

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_web3(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_mint_attaches_captured_auth_header(fake_session):
    """When captured_auth is present, mint POST must carry an Authorization header."""
    from engine.probes import ProbeContext
    from engine.probes.web.web3_probe import probe_web3

    fake_session.get.return_value = _make_response(404, "")
    fake_session.post.return_value = _make_response(
        200, json.dumps({"minted": True, "tokenId": 7})
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth={"token": "abc.def.ghi"},
    )

    findings = await probe_web3(ctx)
    assert len(findings) == 1
    assert findings[0]["severity"] == "high"

    # Inspect the POST kwargs to confirm the Authorization header propagated.
    assert fake_session.post.call_count == 1
    _, kwargs = fake_session.post.call_args
    headers = kwargs.get("headers") or {}
    assert headers.get("Authorization") == "Bearer abc.def.ghi"


@pytest.mark.asyncio
async def test_web3_probe_works_on_non_web3_target(fake_session):
    """Index loads but shows no Web3 markers: probe skips cleanly."""
    from engine.probes import ProbeContext
    from engine.probes.web.web3_probe import probe_web3

    # /, /index.html return a generic page with no wallet/web3/eth/nft
    # markers. detect_web3_markers should return (False, True) and the
    # probe skips without enumerating /api/Wallet, /api/Wallet/mint, etc.
    fake_session.get.return_value = _make_response(
        200, "<html><head><title>Hello</title></head><body>Welcome</body></html>"
    )
    fake_session.post.return_value = _make_response(
        200, json.dumps({"minted": True, "tokenId": 1})
    )

    ctx = ProbeContext(session=fake_session, base="http://example.com")
    findings = await probe_web3(ctx)

    assert findings == []
    # No mint POST should have fired.
    assert fake_session.post.call_count == 0


def test_web3_probe_is_registered():
    from engine.probes import registry
    from engine.probes.web import web3_probe  # noqa: F401  - import registers

    spec = registry.get("web.web3_probe")
    assert spec is not None
    assert spec.bug_class == "exposed_dev"
    assert spec.severity_max == "high"
    assert spec.owasp == "A05:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 10.0
    assert "anonymous" in spec.tags
    assert "web3" in spec.tags
    assert "novel" in spec.tags
