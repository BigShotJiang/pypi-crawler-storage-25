"""Tests for the password-reset-via-weak-security-answer probe.

Juice Shop ships with documented canonical answers for its demo accounts
("Stop'n'Drop am Wallueck", "Samuel", etc.). A reset endpoint that
accepts those answers and changes the password is a critical
authentication bypass. The probe walks a list of target emails, fetches
each one's security question, matches the question text against a known
canonical-answer table, and POSTs the reset.
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_password_reset_weak_hit_on_canonical_answer(fake_session):
    """Question disclosed + canonical answer accepted -> critical finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.password_reset_weak import probe_password_reset_weak

    # First GET hits the question endpoint with Bender's question.
    question_resp = _make_response(
        200,
        json.dumps(
            {"question": "Name of your favorite eatery from your childhood?"}
        ),
    )
    fake_session.get.side_effect = [question_resp]

    # Reset POST returns 200 with a user payload -> success.
    reset_resp = _make_response(
        200,
        json.dumps({"user": {"id": 4, "email": "bender@juice-sh.op"}}),
    )
    fake_session.post.side_effect = [reset_resp]

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("bender@juice-sh.op",),
    )

    findings = await probe_password_reset_weak(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "auth_bypass"
    assert "bender@juice-sh.op" in f["title"]

    # Reset payload must contain the canonical answer plus the probe's
    # new-password pair.
    post_call = fake_session.post.call_args
    payload = post_call.kwargs["json"]
    assert payload["email"] == "bender@juice-sh.op"
    assert payload["answer"] == "Stop'n'Drop am Wallueck"
    assert payload["new"] == payload["repeat"] == "Ptai-Reset-1234!"


@pytest.mark.asyncio
async def test_password_reset_weak_miss_when_question_text_unknown(fake_session):
    """Question text the probe can't match should produce no finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.password_reset_weak import probe_password_reset_weak

    # Question text is a custom prompt with no canonical-answer match.
    question_resp = _make_response(
        200,
        json.dumps(
            {"question": "What was the registration code on your activation letter?"}
        ),
    )
    # Only one email in hints, three question paths -> at most three GETs;
    # all return the same uninformative question. The probe should give up
    # before issuing any POST.
    fake_session.get.return_value = question_resp

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("jim@juice-sh.op",),
    )

    findings = await probe_password_reset_weak(ctx)

    assert findings == []
    assert fake_session.post.call_count == 0


@pytest.mark.asyncio
async def test_password_reset_weak_miss_on_401(fake_session):
    """A reset endpoint that rejects the answer must not flag a finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.password_reset_weak import probe_password_reset_weak

    question_resp = _make_response(
        200,
        json.dumps({"question": "What is your favorite color?"}),
    )
    fake_session.get.return_value = question_resp

    # Both candidate reset endpoints return 401.
    rejected = _make_response(401, json.dumps({"error": "invalid answer"}))
    fake_session.post.side_effect = [rejected, rejected]

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("someone@example.com",),
    )

    findings = await probe_password_reset_weak(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_password_reset_weak_miss_when_question_endpoint_unavailable(
    fake_session,
):
    """No question endpoint (all 404) -> no question text, no reset attempt."""
    from engine.probes import ProbeContext
    from engine.probes.web.password_reset_weak import probe_password_reset_weak

    # Every GET returns 404; probe shouldn't issue any POST.
    fake_session.get.return_value = _make_response(404, "")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("ghost@example.com",),
    )

    findings = await probe_password_reset_weak(ctx)

    assert findings == []
    assert fake_session.post.call_count == 0


@pytest.mark.asyncio
async def test_password_reset_weak_works_on_non_juiceshop_target(fake_session):
    """No fingerprint, no user disclosure: probe runs cleanly with zero findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.password_reset_weak import probe_password_reset_weak

    # Every GET 404s (user lists, fingerprint paths, security-question
    # endpoints). Probe must not crash and must not emit any finding.
    fake_session.get.return_value = _make_response(404, "")
    fake_session.post.return_value = _make_response(404, "")

    ctx = ProbeContext(
        session=fake_session,
        base="http://example.com",
    )

    findings = await probe_password_reset_weak(ctx)
    assert findings == []


def test_password_reset_weak_is_registered():
    from engine.probes import registry
    from engine.probes.web import password_reset_weak  # noqa: F401  - registers

    spec = registry.get("web.password_reset_weak")
    assert spec is not None
    assert spec.bug_class == "auth_bypass"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 10.0
    assert spec.owasp == "A07:2021"
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "destructive-low" in spec.tags
