"""Tests for the SAML XSW + parser-differential probe.

XSW (Signature Wrapping) and comment-injection are the 2025 enterprise
SSO bypass class (CVE-2025-47949 samlify, CVE-2025-25291/25292 ruby-saml).
The probe POSTs benign baseline plus four XSW variants plus comment
injection, watching for login-success response shape.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_xsw_redirect_to_dashboard_emits_critical(fake_session):
    """Baseline 400, XSW1 redirects to /dashboard => CRITICAL finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.saml_xsw import probe_saml_xsw

    # Baseline POST -> 400, then first XSW variant -> 302 to /dashboard.
    fake_session.post.side_effect = [
        _make_response(400, "<error>invalid SAML</error>"),  # baseline
        _make_response(302, "", {"Location": "/dashboard"}),  # XSW1 hits
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://idp.target",
        candidate_endpoints=("/saml/acs",),
    )

    findings = await probe_saml_xsw(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "auth_bypass"
    assert "XSW1" in f["title"]


@pytest.mark.asyncio
async def test_xsw_session_cookie_emits_critical(fake_session):
    """A 200 response with a session cookie counts as a successful bypass."""
    from engine.probes import ProbeContext
    from engine.probes.web.saml_xsw import probe_saml_xsw

    # Baseline 400, XSW1 fails (still 400), XSW2 sets a session cookie.
    fake_session.post.side_effect = [
        _make_response(400, ""),  # baseline
        _make_response(400, ""),  # XSW1
        _make_response(
            200,
            '{"ok":true}',
            {"Set-Cookie": "session=abc123; Path=/; HttpOnly"},
        ),  # XSW2
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://idp.target",
        candidate_endpoints=("/saml/acs",),
    )

    findings = await probe_saml_xsw(ctx)

    assert any("XSW2" in f["title"] for f in findings)
    assert findings[0]["severity"] == "critical"


@pytest.mark.asyncio
async def test_no_finding_when_all_variants_rejected(fake_session):
    """Baseline 400 + every XSW variant 400 => no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.saml_xsw import probe_saml_xsw

    # Baseline + 5 XSW variants all return 400 with no success markers.
    fake_session.post.side_effect = [
        _make_response(400, "<error>invalid signature</error>")
        for _ in range(6)
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://idp.target",
        candidate_endpoints=("/saml/acs",),
    )

    findings = await probe_saml_xsw(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_skip_endpoint_when_baseline_already_logged_in(fake_session):
    """If baseline (benign minimal SAML) already 'succeeds', endpoint is junk."""
    from engine.probes import ProbeContext
    from engine.probes.web.saml_xsw import probe_saml_xsw

    fake_session.post.side_effect = [
        # Baseline already redirects to /dashboard - means the endpoint
        # accepts anything, not a real bypass.
        _make_response(302, "", {"Location": "/dashboard"}),
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://idp.target",
        candidate_endpoints=("/saml/acs",),
    )

    findings = await probe_saml_xsw(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_comment_injection_variant_detected(fake_session):
    """Comment-injection NameID succeeds where XSW1-4 failed."""
    from engine.probes import ProbeContext
    from engine.probes.web.saml_xsw import probe_saml_xsw

    fake_session.post.side_effect = [
        _make_response(400, ""),  # baseline
        _make_response(400, ""),  # XSW1
        _make_response(400, ""),  # XSW2
        _make_response(400, ""),  # XSW3
        _make_response(400, ""),  # XSW4
        _make_response(302, "", {"Location": "/admin"}),  # CommentInjection
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://idp.target",
        candidate_endpoints=("/saml/acs",),
    )

    findings = await probe_saml_xsw(ctx)

    assert len(findings) == 1
    assert "CommentInjection" in findings[0]["title"]


@pytest.mark.asyncio
async def test_error_redirect_does_not_count_as_login(fake_session):
    """A 302 to /sso/error is NOT a successful bypass."""
    from engine.probes import ProbeContext
    from engine.probes.web.saml_xsw import probe_saml_xsw

    fake_session.post.side_effect = [
        _make_response(400, ""),  # baseline
        _make_response(302, "", {"Location": "/sso/error?code=403"}),  # XSW1
        _make_response(302, "", {"Location": "/sso/error?code=403"}),  # XSW2
        _make_response(302, "", {"Location": "/sso/error?code=403"}),  # XSW3
        _make_response(302, "", {"Location": "/sso/error?code=403"}),  # XSW4
        _make_response(302, "", {"Location": "/sso/error?code=403"}),  # CI
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://idp.target",
        candidate_endpoints=("/saml/acs",),
    )

    findings = await probe_saml_xsw(ctx)
    assert findings == []


def test_saml_xsw_is_registered():
    """Conftest snapshots the registry before each test; reload to make the
    @registry.probe decorator fire again inside the active snapshot."""
    import importlib

    from engine.probes import registry
    from engine.probes.web import saml_xsw

    importlib.reload(saml_xsw)

    spec = registry.get("web.saml_xsw")
    assert spec is not None
    assert spec.bug_class == "auth_bypass"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is False
    assert 15.0 <= spec.runtime_budget_s <= 25.0
