"""Tests for the crawler-driven SQLi fuzz probe.

Validates that web.sqli_fuzz uses both the recon crawler and the 34-payload
SQLi library to fan out across discovered query endpoints.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def _resp(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {"Content-Type": "text/html"}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_sqli_fuzz_emits_finding_when_size_delta_detected(fake_session):
    """Size delta > 2.5x with 200 OK = SQLi hit."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.sqli_fuzz import probe_sqli_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/rest/products/search"},
        forms=[],
    )

    # Baseline returns small body; ANY payload returns body 5x larger.
    def get_side(url, **_kwargs):
        if "payload" in url.lower() or "%27" in url or "%20" in url:
            return _resp(200, "X" * 5000)
        return _resp(200, "X" * 500)

    fake_session.get.side_effect = get_side

    with patch(
        "engine.probes.web.sqli_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_sqli_fuzz(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"
    assert findings[0]["bug_class"] == "sqli"
    assert "/rest/products/search" in findings[0]["target"]


@pytest.mark.asyncio
async def test_sqli_fuzz_emits_finding_on_sql_error_marker(fake_session):
    """SQL error fingerprint in body but not baseline = hit."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.sqli_fuzz import probe_sqli_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/api/products/search"},
        forms=[],
    )

    def get_side(url, **_kwargs):
        if "payload" in url.lower() or "%27" in url or "%20" in url:
            return _resp(
                200,
                "Error: SQLITE_ERROR: no such column near 'UNION'",
            )
        return _resp(200, "OK results")

    fake_session.get.side_effect = get_side

    with patch(
        "engine.probes.web.sqli_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_sqli_fuzz(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"


@pytest.mark.asyncio
async def test_sqli_fuzz_no_finding_when_baseline_already_has_marker(fake_session):
    """If baseline body already contains the SQL error string, ignore (false positive guard)."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.sqli_fuzz import probe_sqli_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/api/q/search"},
        forms=[],
    )

    # Both baseline AND attack contain "PostgreSQL" (e.g., dev page footer)
    fake_session.get.side_effect = lambda url, **_k: _resp(
        200, "Powered by PostgreSQL"
    )

    with patch(
        "engine.probes.web.sqli_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_sqli_fuzz(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_sqli_fuzz_no_finding_on_clean_endpoints(fake_session):
    """Equal-size 200 responses everywhere = no findings."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.sqli_fuzz import probe_sqli_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/api/clean/search"},
        forms=[],
    )

    fake_session.get.side_effect = lambda url, **_k: _resp(200, "X" * 1000)

    with patch(
        "engine.probes.web.sqli_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_sqli_fuzz(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_sqli_fuzz_handles_crawler_failure_gracefully(fake_session):
    """Crawler exception must not crash the probe."""
    from engine.probes import ProbeContext
    from engine.probes.web.sqli_fuzz import probe_sqli_fuzz

    with patch(
        "engine.probes.web.sqli_fuzz.run_crawler",
        side_effect=RuntimeError("boom"),
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_sqli_fuzz(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_sqli_fuzz_propagates_cookie_auth_to_crawler_and_fuzz(fake_session):
    """captured_auth flows into run_crawler kwargs AND every session.get call."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.sqli_fuzz import probe_sqli_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths=set(),
        forms=[],
    )
    fake_session.get.side_effect = lambda url, **_k: _resp(200, "ok")

    captured_crawler_kwargs: dict = {}

    async def fake_run_crawler(session, base, **kwargs):
        captured_crawler_kwargs.update(kwargs)
        return fake_crawl

    with patch(
        "engine.probes.web.sqli_fuzz.run_crawler",
        side_effect=fake_run_crawler,
    ):
        ctx = ProbeContext(
            session=fake_session,
            base="http://x",
            captured_auth={"kind": "cookie", "token": "session=abc123"},
        )
        await probe_sqli_fuzz(ctx)

    assert captured_crawler_kwargs.get("auth_headers") == {"Cookie": "session=abc123"}
    assert fake_session.get.call_count > 0
    for call in fake_session.get.call_args_list:
        assert call.kwargs.get("headers", {}).get("Cookie") == "session=abc123"


@pytest.mark.asyncio
async def test_sqli_fuzz_fuzzes_ctx_candidate_endpoints(fake_session):
    """Paths in ctx.candidate_endpoints get wrapped against common query params."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.sqli_fuzz import probe_sqli_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths=set(),
        forms=[],
    )
    fake_session.get.side_effect = lambda url, **_k: _resp(200, "ok")

    with patch(
        "engine.probes.web.sqli_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(
            session=fake_session,
            base="http://x",
            candidate_endpoints=("/api/search",),
        )
        await probe_sqli_fuzz(ctx)

    posted_urls = [call.args[0] for call in fake_session.get.call_args_list]
    assert any("/api/search?q=" in url for url in posted_urls), (
        f"expected /api/search?q=... to be fuzzed, got URLs: {posted_urls[:5]}"
    )


def test_sqli_fuzz_is_registered():
    from engine.probes import registry
    from engine.probes.web import sqli_fuzz  # noqa: F401  - registers

    spec = registry.get("web.sqli_fuzz")
    assert spec is not None
    assert spec.bug_class == "sqli"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A03:2021"
    assert "fuzzing" in spec.tags
    assert "uses-crawler" in spec.tags
