"""Regression tests for WebAgent.set_auth — the orchestrator -> probe-context
auth bridge.

Without this bridge, requires_auth=True probes silently skip in
deterministic CLI mode even when the operator passed --cookie / --header.
That cost ~7 missed criticals against the TaskFlow honeypot before the
fix landed (mass assignment, type confusion, race condition, JWT alg:none
on gated endpoints).
"""
from __future__ import annotations

from unittest.mock import MagicMock

import pytest


@pytest.fixture
def fresh_agent():
    from agents.web.web_agent import WebAgent

    return WebAgent(registry=MagicMock(), db=MagicMock())


def test_set_auth_with_none_clears_state(fresh_agent):
    fresh_agent._captured_auth = {"token": "old", "kind": "bearer"}
    fresh_agent.set_auth(None)
    assert fresh_agent._captured_auth is None


def test_set_auth_with_cookie_renders_cookie_kind(fresh_agent):
    from engine.auth_handler import AuthCredentials

    creds = AuthCredentials(auth_type="cookie", cookies="session=abc123")
    fresh_agent.set_auth(creds)
    assert fresh_agent._captured_auth is not None
    assert fresh_agent._captured_auth["kind"] == "cookie"
    assert fresh_agent._captured_auth["token"] == "session=abc123"


def test_set_auth_with_bearer_renders_bearer_kind(fresh_agent):
    from engine.auth_handler import AuthCredentials

    creds = AuthCredentials(auth_type="bearer", bearer_token="eyJfake.token")
    fresh_agent.set_auth(creds)
    assert fresh_agent._captured_auth is not None
    assert fresh_agent._captured_auth["kind"] == "bearer"
    assert fresh_agent._captured_auth["token"] == "eyJfake.token"


def test_set_auth_with_authorization_header_extracts_token(fresh_agent):
    from engine.auth_handler import AuthCredentials

    creds = AuthCredentials(headers={"Authorization": "Bearer header-token-xyz"})
    fresh_agent.set_auth(creds)
    assert fresh_agent._captured_auth is not None
    assert "header-token-xyz" in fresh_agent._captured_auth["token"]
    assert fresh_agent._captured_auth["auth_value"] == "Bearer header-token-xyz"


def test_set_auth_empty_credentials_yields_none(fresh_agent):
    from engine.auth_handler import AuthCredentials

    fresh_agent.set_auth(AuthCredentials())
    assert fresh_agent._captured_auth is None


def test_auth_headers_renders_cookie_kind_as_cookie_header():
    """Cookie-kind tokens must produce Cookie: ..., not Authorization: Bearer ..."""
    from engine.probes.auth.runner import auth_headers

    h = auth_headers({"token": "session=abc", "kind": "cookie"})
    assert h == {"Cookie": "session=abc"}


def test_auth_headers_renders_bearer_kind_as_authorization():
    from engine.probes.auth.runner import auth_headers

    h = auth_headers({"token": "eyJfake.token", "kind": "bearer"})
    assert h == {"Authorization": "Bearer eyJfake.token"}


def test_auth_headers_unknown_kind_falls_back_to_bearer():
    from engine.probes.auth.runner import auth_headers

    h = auth_headers({"token": "abc"})
    assert h == {"Authorization": "Bearer abc"}


def test_auth_headers_explicit_pair_wins_over_kind():
    """When the agent loop pre-rendered an auth_header/auth_value pair,
    use it verbatim — don't second-guess it.
    """
    from engine.probes.auth.runner import auth_headers

    h = auth_headers({
        "auth_header": "X-Custom-Auth",
        "auth_value": "raw-value",
        "token": "ignored",
        "kind": "ignored",
    })
    assert h == {"X-Custom-Auth": "raw-value"}


def test_auth_headers_session_id_kind_renders_as_cookie():
    """session_id kind also maps to Cookie header (legacy CapturedAuth.kind)."""
    from engine.probes.auth.runner import auth_headers

    h = auth_headers({"token": "PHPSESSID=xyz", "kind": "session_id"})
    assert h == {"Cookie": "PHPSESSID=xyz"}
