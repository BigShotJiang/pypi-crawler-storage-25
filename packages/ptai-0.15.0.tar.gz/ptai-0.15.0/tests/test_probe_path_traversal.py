"""Tests for the path-traversal probe.

Walks filename-style query params with varying-depth ../etc/passwd
payloads. Fires critical when the response body contains canonical
file markers (root:x:0: for Linux, [boot loader] for Windows).
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

# Force decorator to register before the autouse snapshot fixture.
from engine.probes.web import path_traversal as _path_traversal  # noqa: F401


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_path_traversal_critical_on_etc_passwd(fake_session):
    """root:x:0: in body -> critical Linux LFI."""
    from engine.probes import ProbeContext
    from engine.probes.web.path_traversal import probe_path_traversal

    # First GET to /files returns passwd content; subsequent GETs on
    # other DEFAULT_PATHS return harmless 404. URL-encoded "etc/passwd"
    # appears as "etc%2Fpasswd" in the request URL.
    def side(url, **_k):
        if "/files" in url and "passwd" in url:
            return _make_response(
                200, "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:",
            )
        return _make_response(404, "not found")

    fake_session.get.side_effect = side

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/files",),
    )
    findings = await probe_path_traversal(ctx)

    files_findings = [f for f in findings if "/files" in f["target"]]
    assert files_findings
    assert files_findings[0]["severity"] == "critical"
    assert files_findings[0]["bug_class"] == "path_traversal"
    assert "root:x:0:" in files_findings[0]["evidence"]


@pytest.mark.asyncio
async def test_path_traversal_critical_on_windows_systemini(fake_session):
    """[boot loader] in body -> critical Windows LFI."""
    from engine.probes import ProbeContext
    from engine.probes.web.path_traversal import probe_path_traversal

    def side(url, **_k):
        if "/download" in url and "win" in url.lower():
            return _make_response(
                200, "; for 16-bit app support\n[boot loader]\ntimeout=30\n",
            )
        return _make_response(404, "not found")

    fake_session.get.side_effect = side

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/download",),
    )
    findings = await probe_path_traversal(ctx)

    hits = [f for f in findings if "/download" in f["target"]]
    assert hits
    assert hits[0]["severity"] == "critical"
    assert "[boot loader]" in hits[0]["evidence"]


@pytest.mark.asyncio
async def test_path_traversal_no_finding_on_clean_404(fake_session):
    """All endpoints 404 -> no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.path_traversal import probe_path_traversal

    fake_session.get.side_effect = lambda *a, **k: _make_response(404, "")

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_path_traversal(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_path_traversal_propagates_cookie_auth(fake_session):
    """captured_auth carries through every GET as Cookie header."""
    from engine.probes import ProbeContext
    from engine.probes.web.path_traversal import probe_path_traversal

    fake_session.get.side_effect = lambda *a, **k: _make_response(404, "")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth={"kind": "cookie", "token": "session=xyz"},
    )
    await probe_path_traversal(ctx)

    assert fake_session.get.call_count > 0
    for call in fake_session.get.call_args_list:
        headers = call.kwargs.get("headers", {})
        assert headers.get("Cookie") == "session=xyz", (
            f"missing Cookie in GET: {headers}"
        )


@pytest.mark.asyncio
async def test_path_traversal_stops_after_first_hit_per_path(fake_session):
    """Once one payload fires on a path, that path is not retried."""
    from engine.probes import ProbeContext
    from engine.probes.web.path_traversal import probe_path_traversal

    call_count = {"n": 0}

    def side(url, **_k):
        call_count["n"] += 1
        # Match exactly /files (not /api/files etc.).
        if "//localhost:3000/files?" in url and "passwd" in url:
            return _make_response(200, "root:x:0:0:root:/root:/bin/bash")
        return _make_response(404, "")

    fake_session.get.side_effect = side

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/files",),
    )
    findings = await probe_path_traversal(ctx)

    # Exactly one /files finding (probe stopped iterating params + payloads
    # for that path after the hit). Filter on /files? to exclude /api/files.
    files_findings = [
        f for f in findings if "//localhost:3000/files?" in f["target"]
    ]
    assert len(files_findings) == 1


def test_path_traversal_is_registered():
    from engine.probes import registry

    spec = registry.get("web.path_traversal")
    assert spec is not None
    assert spec.bug_class == "path_traversal"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A01:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 15.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "lfi" in spec.tags
