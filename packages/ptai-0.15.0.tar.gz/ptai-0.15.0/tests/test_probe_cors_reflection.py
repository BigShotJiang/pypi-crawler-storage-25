"""Tests for the CORS origin-reflection probe.

CORS misconfiguration is a top-5 high-ROI bug class. The probe sends an
attacker-controlled Origin header on a credentialed endpoint. If the
server reflects the origin AND sets Access-Control-Allow-Credentials:
true, an attacker page can read authenticated responses cross-site.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_cors_reflection_critical_when_allow_credentials_with_reflection(
    fake_session,
):
    from engine.probes import ProbeContext
    from engine.probes.web.cors_reflection import probe_cors_reflection

    fake_session.get.return_value = _make_response(
        200,
        '{"data": "secret"}',
        {
            "Access-Control-Allow-Origin": "https://ptai-cors-canary.example",
            "Access-Control-Allow-Credentials": "true",
        },
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/me",),
    )

    findings = await probe_cors_reflection(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["category"] == "misconfiguration"
    assert "CORS" in f["title"]


@pytest.mark.asyncio
async def test_cors_reflection_high_when_reflection_no_credentials(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.cors_reflection import probe_cors_reflection

    fake_session.get.return_value = _make_response(
        200,
        '{"data": "ok"}',
        {"Access-Control-Allow-Origin": "https://ptai-cors-canary.example"},
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/me",),
    )

    findings = await probe_cors_reflection(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "high"


@pytest.mark.asyncio
async def test_cors_reflection_no_finding_when_origin_not_reflected(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.cors_reflection import probe_cors_reflection

    fake_session.get.return_value = _make_response(
        200,
        '{"data": "ok"}',
        {"Access-Control-Allow-Origin": "https://app.legitimate.com"},
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/me",),
    )

    findings = await probe_cors_reflection(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_cors_reflection_handles_null_origin_acceptance(fake_session):
    """`Access-Control-Allow-Origin: null` is exploitable via sandboxed iframes."""
    from engine.probes import ProbeContext
    from engine.probes.web.cors_reflection import probe_cors_reflection

    # First call returns Origin reflection check (no reflection).
    # Second call probes "null" Origin and gets it back.
    fake_session.get.side_effect = [
        _make_response(
            200, "{}", {"Access-Control-Allow-Origin": "https://app.legitimate.com"}
        ),
        _make_response(
            200,
            "{}",
            {
                "Access-Control-Allow-Origin": "null",
                "Access-Control-Allow-Credentials": "true",
            },
        ),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/me",),
    )

    findings = await probe_cors_reflection(ctx)
    assert any("null" in f["title"] for f in findings)


def test_cors_reflection_is_registered():
    from engine.probes import registry
    from engine.probes.web import cors_reflection  # noqa: F401  - import registers

    spec = registry.get("web.cors_reflection")
    assert spec is not None
    assert spec.bug_class == "cors_misconfig"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is False
