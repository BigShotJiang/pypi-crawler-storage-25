"""Registration + smoke tests for probes added after the honeypot test.

Covers `web.api_path_discovery`, `web.trusted_header_bypass`,
`web.type_confusion`, and `web.privilege_escalation_patch`. Heavier
behavioural validation lives in the e2e honeypot run; these tests only
prove the probes wire up correctly and short-circuit cleanly when their
preconditions aren't met.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Import for registration-side-effect.
from engine.probes.web import (  # noqa: F401
    api_path_discovery as _api_path_discovery,
)


def _make_response(status: int, body: str = "", headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.read = AsyncMock(return_value=body.encode())
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


def test_all_four_probes_are_registered():
    from engine.probes import registry

    for name in (
        "web.api_path_discovery",
        "web.trusted_header_bypass",
        "web.type_confusion",
        "web.privilege_escalation_patch",
    ):
        spec = registry.get(name)
        assert spec is not None, f"{name} not registered"
        assert spec.bug_class
        assert spec.severity_max
        assert spec.owasp
        assert spec.runtime_budget_s > 0


def test_registry_metadata_matches_intent():
    from engine.probes import registry

    api = registry.get("web.api_path_discovery")
    assert api.requires_auth is False  # discovery is anonymous-first
    assert "discovery" in api.tags

    th = registry.get("web.trusted_header_bypass")
    assert th.requires_auth is False
    assert th.severity_max == "critical"

    tc = registry.get("web.type_confusion")
    assert tc.requires_auth is True

    pep = registry.get("web.privilege_escalation_patch")
    assert pep.requires_auth is True
    assert pep.severity_max == "critical"


@pytest.mark.asyncio
async def test_type_confusion_no_findings_without_auth():
    """Probe gates on ctx.captured_auth; without it, returns [] cleanly."""
    from engine.probes import ProbeContext
    from engine.probes.web.type_confusion import probe_type_confusion

    ctx = ProbeContext(
        session=MagicMock(),
        base="http://localhost:5000",
        captured_auth=None,
    )
    assert await probe_type_confusion(ctx) == []


@pytest.mark.asyncio
async def test_privilege_escalation_no_findings_without_auth():
    from engine.probes import ProbeContext
    from engine.probes.web.privilege_escalation_patch import (
        probe_privilege_escalation_patch,
    )

    ctx = ProbeContext(
        session=MagicMock(),
        base="http://localhost:5000",
        captured_auth=None,
    )
    assert await probe_privilege_escalation_patch(ctx) == []


@pytest.mark.asyncio
async def test_trusted_header_bypass_no_findings_when_path_not_gated():
    """Anonymous baseline returns 200 -> probe only fires on 401/403 paths.
    Every default target returning 200 means nothing should be flagged.
    """
    from engine.probes import ProbeContext
    from engine.probes.web.trusted_header_bypass import probe_trusted_header_bypass

    fake_session_cls = MagicMock()
    instance = MagicMock()
    fake_session_cls.return_value.__aenter__.return_value = instance
    fake_session_cls.return_value.__aexit__.return_value = None
    instance.get.return_value = _make_response(200, "<html>...</html>")

    ctx = ProbeContext(session=MagicMock(), base="http://localhost:5000")
    with patch("aiohttp.ClientSession", fake_session_cls), \
         patch("aiohttp.DummyCookieJar", lambda: object()):
        findings = await probe_trusted_header_bypass(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_trusted_header_bypass_emits_critical_on_401_to_200_flip():
    """401 anonymously, 200 with X-Forwarded-User=admin -> critical finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.trusted_header_bypass import probe_trusted_header_bypass

    instance = MagicMock()
    state = {"calls": 0}

    _BYPASS_KEYS = (
        "X-Forwarded-User", "X-Original-User", "X-Remote-User",
        "X-Forwarded-For", "X-Forwarded-Host", "X-Real-IP",
        "X-Authenticated-User",
    )

    def _get_side_effect(*_args, **kwargs):
        state["calls"] += 1
        hdrs = kwargs.get("headers") or {}
        if any(k in hdrs for k in _BYPASS_KEYS):
            return _make_response(200, '{"users": [{"email": "admin@example.com"}]}')
        return _make_response(401, "")

    instance.get.side_effect = _get_side_effect
    fake_session_cls = MagicMock()
    fake_session_cls.return_value.__aenter__.return_value = instance
    fake_session_cls.return_value.__aexit__.return_value = None

    ctx = ProbeContext(session=MagicMock(), base="http://localhost:5000")
    with patch("aiohttp.ClientSession", fake_session_cls), \
         patch("aiohttp.DummyCookieJar", lambda: object()):
        findings = await probe_trusted_header_bypass(ctx)

    critical = [f for f in findings if f["severity"] == "critical"]
    assert critical, f"expected a critical finding, got {findings}"
    assert any("/admin" in f["target"] or "/internal" in f["target"]
               or "/api/admin" in f["target"] or "/actuator" in f["target"]
               for f in critical)
