"""Tests for the DOM-rendered XSS probe.

The probe drives Playwright. Tests mock the entire ``async_playwright``
chain so no real browser launches. We assert that:

- a dialog fired with our canary text yields a finding,
- a clean page (no dialog) yields no findings,
- a missing playwright import degrades to an empty list,
- the probe is registered with the expected metadata.
"""
from __future__ import annotations

import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class _FakeDialog:
    """Stand-in for playwright.async_api.Dialog."""

    def __init__(self, message: str) -> None:
        self.message = message

    async def dismiss(self) -> None:
        return None


def _make_page(dialog_messages: list[str]) -> MagicMock:
    """Build a fake Page that fires ``dialog_messages`` when goto runs."""
    page = MagicMock()
    handlers: list = []

    def _on(event: str, handler) -> None:
        if event == "dialog":
            handlers.append(handler)

    async def _goto(url: str, **kwargs):
        # When navigation runs, simulate the browser firing each dialog.
        for msg in dialog_messages:
            for h in handlers:
                h(_FakeDialog(msg))
        return None

    async def _wait_for_timeout(ms: int) -> None:
        return None

    page.on = _on
    page.goto = _goto
    page.wait_for_timeout = _wait_for_timeout
    return page


def _make_playwright_cm(page: MagicMock) -> MagicMock:
    """Mock ``async_playwright()`` returning an async context manager."""
    browser = MagicMock()
    browser.close = AsyncMock(return_value=None)

    context = MagicMock()
    context.new_page = AsyncMock(return_value=page)

    chromium = MagicMock()
    chromium.launch = AsyncMock(return_value=browser)
    browser.new_context = AsyncMock(return_value=context)

    p_obj = SimpleNamespace(chromium=chromium)

    cm = MagicMock()
    cm.__aenter__ = AsyncMock(return_value=p_obj)
    cm.__aexit__ = AsyncMock(return_value=None)

    factory = MagicMock(return_value=cm)
    return factory


@pytest.mark.asyncio
async def test_dom_xss_emits_finding_when_canary_dialog_fires():
    """Browser dialog with the canary string -> high-severity finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.dom_xss import CANARY, probe_dom_xss

    page = _make_page([f"hello {CANARY} world"])
    factory = _make_playwright_cm(page)

    fake_module = SimpleNamespace(async_playwright=factory)
    with patch.dict(sys.modules, {"playwright.async_api": fake_module}):
        ctx = ProbeContext(session=MagicMock(), base="http://localhost:3000")
        findings = await probe_dom_xss(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "high"
    assert f["category"] == "injection"
    assert f["bug_class"] in {"xss_reflected", "xss_stored"}
    assert "DOM" in f["title"] or "dialog" in f["title"].lower()
    assert CANARY in f["evidence"]


@pytest.mark.asyncio
async def test_dom_xss_no_finding_when_no_dialog_fires():
    """No dialog ever fires -> empty findings list."""
    from engine.probes import ProbeContext
    from engine.probes.web.dom_xss import probe_dom_xss

    page = _make_page([])  # no dialogs
    factory = _make_playwright_cm(page)

    fake_module = SimpleNamespace(async_playwright=factory)
    with patch.dict(sys.modules, {"playwright.async_api": fake_module}):
        ctx = ProbeContext(session=MagicMock(), base="http://localhost:3000")
        findings = await probe_dom_xss(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_dom_xss_no_finding_when_dialog_lacks_canary():
    """A dialog with unrelated text doesn't count as a hit."""
    from engine.probes import ProbeContext
    from engine.probes.web.dom_xss import probe_dom_xss

    page = _make_page(["Are you sure you want to leave?"])
    factory = _make_playwright_cm(page)

    fake_module = SimpleNamespace(async_playwright=factory)
    with patch.dict(sys.modules, {"playwright.async_api": fake_module}):
        ctx = ProbeContext(session=MagicMock(), base="http://localhost:3000")
        findings = await probe_dom_xss(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_dom_xss_graceful_when_playwright_missing():
    """Import failure (no playwright installed) returns []."""
    from engine.probes import ProbeContext
    from engine.probes.web.dom_xss import probe_dom_xss

    # Force the inner import to fail by inserting a sentinel module that
    # raises on attribute access for ``async_playwright``.
    class _Boom:
        def __getattr__(self, name: str):
            raise ImportError("playwright not installed")

    with patch.dict(sys.modules, {"playwright.async_api": _Boom()}):
        ctx = ProbeContext(session=MagicMock(), base="http://localhost:3000")
        findings = await probe_dom_xss(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_dom_xss_emits_one_finding_per_url_with_canary():
    """If multiple URLs trigger the canary, emit one finding per URL."""
    from engine.probes import ProbeContext
    from engine.probes.web.dom_xss import CANARY, probe_dom_xss

    page = _make_page([f"alert!{CANARY}!"])
    factory = _make_playwright_cm(page)

    fake_module = SimpleNamespace(async_playwright=factory)
    with patch.dict(sys.modules, {"playwright.async_api": fake_module}):
        ctx = ProbeContext(session=MagicMock(), base="http://localhost:3000")
        findings = await probe_dom_xss(ctx)

    # CANDIDATE_TEMPLATES has 4 entries; every navigation fires the canary
    # in this fake, so we expect 4 findings (one per URL).
    assert len(findings) == 4
    targets = {f["target"] for f in findings}
    assert len(targets) == 4  # distinct URLs
    # At least one stored-class finding (the /contact entry).
    bug_classes = {f["bug_class"] for f in findings}
    assert "xss_stored" in bug_classes
    assert "xss_reflected" in bug_classes


def test_dom_xss_is_registered():
    import importlib

    import engine.probes.web.dom_xss as dom_xss_mod
    from engine.probes import registry

    # The autouse registry-isolation fixture in conftest snapshots probes
    # before the test and restores after. Because dom_xss isn't imported
    # by engine.probes.web.__init__, it isn't in that snapshot, so we
    # reload the module here to re-fire the @registry.probe decorator.
    if registry.get("web.dom_xss") is None:
        importlib.reload(dom_xss_mod)

    spec = registry.get("web.dom_xss")
    assert spec is not None
    assert spec.bug_class == "xss_reflected"
    assert spec.severity_max == "high"
    assert spec.owasp == "A03:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 30.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "browser" in spec.tags
    assert "playwright" in spec.tags
