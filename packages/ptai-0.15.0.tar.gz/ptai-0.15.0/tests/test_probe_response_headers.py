"""Tests for the response-headers probe.

One GET, three classes of finding: missing security headers (low),
insecure session cookies (medium), Server/X-Powered-By info disclosure
(info). Cookie inspection ALSO checks ctx.captured_auth.set_cookie_raw
so apps that only mint cookies on successful login (Flask, Rails) get
flagged via the orchestrator's login response.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

# Trigger decorator registration before the autouse snapshot.
from engine.probes.web import response_headers as _rh  # noqa: F401


def _make_response(
    status: int, body: str, headers: dict[str, str] | None = None,
):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_response_headers_flags_missing_csp_xfo(fake_session):
    """No CSP / X-Frame-Options / X-Content-Type-Options on response -> finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.response_headers import probe_response_headers

    fake_session.get.return_value = _make_response(
        200, "<html></html>",
        headers={"Content-Type": "text/html"},
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:4000")
    findings = await probe_response_headers(ctx)

    missing = [f for f in findings if "Missing security headers" in f["title"]]
    assert missing
    assert missing[0]["severity"] == "low"
    assert missing[0]["bug_class"] == "security_misconfig"
    assert "Content-Security-Policy" in missing[0]["evidence"]
    assert "X-Frame-Options" in missing[0]["evidence"]


@pytest.mark.asyncio
async def test_response_headers_no_missing_when_all_present(fake_session):
    """All security headers set -> no missing-header finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.response_headers import probe_response_headers

    fake_session.get.return_value = _make_response(
        200, "<html></html>",
        headers={
            "Content-Security-Policy": "default-src 'self'",
            "X-Frame-Options": "DENY",
            "X-Content-Type-Options": "nosniff",
            "Referrer-Policy": "no-referrer",
            "Permissions-Policy": "geolocation=()",
        },
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:4000")
    findings = await probe_response_headers(ctx)

    missing = [f for f in findings if "Missing security headers" in f["title"]]
    assert missing == []


@pytest.mark.asyncio
async def test_response_headers_flags_server_and_xpoweredby(fake_session):
    """Versioned Server header + X-Powered-By -> info findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.response_headers import probe_response_headers

    fake_session.get.return_value = _make_response(
        200, "ok",
        headers={
            "Server": "TaskFlow/1.0 (Python/Flask)",
            "X-Powered-By": "PHP/8.2.4",
        },
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:4000")
    findings = await probe_response_headers(ctx)

    server_hits = [
        f for f in findings if "Server" in f["title"] and "Information disclosure" in f["title"]
    ]
    xpb_hits = [
        f for f in findings if "X-Powered-By" in f["title"]
    ]
    assert server_hits and server_hits[0]["severity"] == "info"
    assert xpb_hits and xpb_hits[0]["severity"] == "info"


@pytest.mark.asyncio
async def test_response_headers_ignores_bare_nginx_server(fake_session):
    """Server: nginx (no version) is conventional - no flag."""
    from engine.probes import ProbeContext
    from engine.probes.web.response_headers import probe_response_headers

    fake_session.get.return_value = _make_response(
        200, "ok",
        headers={"Server": "nginx"},
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:4000")
    findings = await probe_response_headers(ctx)

    server_hits = [f for f in findings if "Server" in f["title"]]
    assert server_hits == []


@pytest.mark.asyncio
async def test_response_headers_flags_insecure_session_cookie_via_captured_auth(fake_session):
    """captured_auth.set_cookie_raw with no HttpOnly/Secure/SameSite -> medium finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.response_headers import probe_response_headers

    fake_session.get.return_value = _make_response(200, "ok")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:4000",
        captured_auth={
            "kind": "cookie",
            "token": "session=abc123",
            "set_cookie_raw": "session=abc123; Path=/",
        },
    )
    findings = await probe_response_headers(ctx)

    cookie_hits = [
        f for f in findings if "Insecure session cookie" in f["title"]
    ]
    assert cookie_hits
    assert cookie_hits[0]["severity"] == "medium"
    assert cookie_hits[0]["bug_class"] == "insecure_cookie"
    assert "HttpOnly" in cookie_hits[0]["evidence"]
    assert "Secure" in cookie_hits[0]["evidence"]
    assert "SameSite" in cookie_hits[0]["evidence"]


@pytest.mark.asyncio
async def test_response_headers_no_cookie_finding_when_all_flags_set(fake_session):
    """Cookie with HttpOnly + Secure + SameSite -> no finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.response_headers import probe_response_headers

    fake_session.get.return_value = _make_response(200, "ok")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:4000",
        captured_auth={
            "kind": "cookie",
            "token": "session=abc123",
            "set_cookie_raw": "session=abc123; Path=/; HttpOnly; Secure; SameSite=Lax",
        },
    )
    findings = await probe_response_headers(ctx)

    cookie_hits = [f for f in findings if "Insecure session cookie" in f["title"]]
    assert cookie_hits == []


@pytest.mark.asyncio
async def test_response_headers_skips_when_target_unreachable(fake_session):
    """status=0 (transport error) -> empty findings, no crash."""
    from engine.probes import ProbeContext
    from engine.probes.web.response_headers import probe_response_headers

    fake_session.get.return_value = _make_response(0, "")

    ctx = ProbeContext(session=fake_session, base="http://localhost:4000")
    findings = await probe_response_headers(ctx)
    assert findings == []


def test_response_headers_is_registered():
    from engine.probes import registry

    spec = registry.get("web.response_headers")
    assert spec is not None
    assert spec.bug_class == "security_misconfig"
    assert spec.severity_max == "medium"
    assert spec.owasp == "A05:2021"
    assert spec.requires_auth is False
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "headers" in spec.tags
    assert spec.fn.__name__ == "probe_response_headers"
