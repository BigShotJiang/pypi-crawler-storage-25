"""Tests for the race-condition probe.

The probe fires 15 concurrent POSTs at single-use endpoints. If more
than one returns 2xx, the uniqueness or rate-limit check is non-atomic.
Five or more 2xxs is HIGH; two-to-four is MEDIUM. A correctly gated
endpoint accepts exactly one (the baseline) and rate-limits the rest.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

# Module-level import so the @registry.probe decorator runs at collection
# time, before the autouse _isolate_probe_registry fixture takes its
# snapshot. Without this, the registration test sees an empty slot.
from engine.probes.web import race_condition as _race_condition  # noqa: F401


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


def _seq_post_factory(plan: list[int]):
    """Return a side_effect callable that yields _make_response per status code."""
    state = {"i": 0}

    def _side(*_args, **_kwargs):
        i = state["i"]
        state["i"] += 1
        status = plan[i] if i < len(plan) else plan[-1]
        return _make_response(status, '{"ok": true}')

    return _side


@pytest.mark.asyncio
async def test_race_condition_high_when_many_concurrent_2xx(fake_session):
    """Baseline 201 plus 5 of 15 racers 201 -> HIGH race_condition finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.race_condition import probe_race_condition

    # Endpoint 1 (/api/Feedbacks): baseline 201, then 5x201 + 10x429 in burst.
    # Subsequent endpoints all reject baseline (401) so the probe stops there.
    plan = (
        [201]              # baseline POST on /api/Feedbacks
        + [201] * 5        # 5 racers accepted
        + [429] * 10       # 10 racers rate-limited
        + [401] * 50       # every later endpoint rejects baseline cleanly
    )
    fake_session.post.side_effect = _seq_post_factory(plan)

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_race_condition(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "high"
    assert f["bug_class"] == "race_condition"
    assert f["category"] == "business_logic"
    assert f["owasp"] == "A04:2021"
    assert "/api/Feedbacks" in f["target"]
    import re
    match = re.search(r"(\d+) returned 2xx", f["evidence"])
    assert match and int(match.group(1)) >= 5, (
        f"expected >= 5 accepted in evidence, got: {f['evidence']}"
    )


@pytest.mark.asyncio
async def test_race_condition_no_finding_when_proper_rate_limit(fake_session):
    """Baseline 201 then 14x429 + 1 baseline-only success -> no finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.race_condition import probe_race_condition

    # For each endpoint: baseline 201, then 15 burst calls all 429.
    # That's exactly one 2xx per endpoint (the baseline), zero racers
    # accepted, so the probe should not flag.
    def _per_endpoint_pattern() -> list[int]:
        return [201] + [429] * 15

    # Probe walks 4 endpoints; pattern for the auth-gated one won't run
    # because no captured_auth, but be defensive.
    plan: list[int] = []
    for _ in range(4):
        plan.extend(_per_endpoint_pattern())
    fake_session.post.side_effect = _seq_post_factory(plan)

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_race_condition(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_race_condition_no_finding_when_baseline_rejected(fake_session):
    """Every endpoint rejects baseline (401) -> probe skips cleanly, no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.race_condition import probe_race_condition

    fake_session.post.return_value = _make_response(401, '{"error": "unauthorized"}')

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_race_condition(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_race_condition_skips_auth_gated_when_no_token(fake_session):
    """/rest/basket/1/checkout requires auth; probe must skip it without ctx token."""
    from engine.probes import ProbeContext
    from engine.probes.web.race_condition import probe_race_condition

    # All non-auth endpoints reject baseline -> probe falls through every
    # entry. The auth-gated checkout must not be touched at all because
    # ctx.captured_auth is None.
    fake_session.post.return_value = _make_response(404, "not found")

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_race_condition(ctx)

    assert findings == []
    # Every recorded POST URL must NOT include the auth-gated checkout path.
    for call in fake_session.post.call_args_list:
        url = call.args[0] if call.args else call.kwargs.get("url", "")
        assert "/rest/basket/1/checkout" not in url


@pytest.mark.asyncio
async def test_race_condition_medium_when_few_concurrent_2xx(fake_session):
    """Baseline 201 then 3x201 + 12x429 -> MEDIUM finding (2 < accepted < 5)."""
    from engine.probes import ProbeContext
    from engine.probes.web.race_condition import probe_race_condition

    plan = (
        [201]              # baseline on /api/Feedbacks
        + [201] * 3        # 3 racers accepted
        + [429] * 12       # 12 racers rate-limited
        + [401] * 50       # later endpoints reject baseline
    )
    fake_session.post.side_effect = _seq_post_factory(plan)

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_race_condition(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "medium"
    assert findings[0]["bug_class"] == "race_condition"


@pytest.mark.asyncio
async def test_race_condition_propagates_cookie_auth(fake_session):
    """captured_auth with kind=cookie -> bursts carry Cookie, not Bearer."""
    from engine.probes import ProbeContext
    from engine.probes.web.race_condition import probe_race_condition

    fake_session.post.return_value = _make_response(404, "nothing")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth={"kind": "cookie", "token": "session=abc"},
    )
    await probe_race_condition(ctx)

    # At least one auth-required endpoint should have been attempted
    # (now that we have auth). Every POST must carry the cookie header,
    # never an erroneous Bearer-shaped Authorization.
    assert fake_session.post.call_count > 0
    for call in fake_session.post.call_args_list:
        headers = call.kwargs.get("headers") or {}
        assert headers.get("Cookie") == "session=abc", (
            f"missing/wrong Cookie header: {headers}"
        )
        assert "Authorization" not in headers, (
            f"unexpected Authorization for cookie-kind auth: {headers}"
        )


def test_race_condition_is_registered():
    """Registry metadata is the public contract; assert it explicitly."""
    from engine.probes import registry
    from engine.probes.web import race_condition  # noqa: F401  - import registers

    spec = registry.get("web.race_condition")
    assert spec is not None
    assert spec.bug_class == "race_condition"
    assert spec.severity_max == "high"
    assert spec.owasp == "A04:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 15.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "destructive-low" in spec.tags
    assert "concurrent" in spec.tags
    # Guard against the decorator getting accidentally attached to a
    # helper. The registered fn must be the probe entry point.
    assert spec.fn.__name__ == "probe_race_condition"
