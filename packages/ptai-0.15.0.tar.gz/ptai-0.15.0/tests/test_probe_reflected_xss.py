"""Tests for the reflected-XSS probe.

The probe walks common search/lookup paths injecting a canary script
either in the path or in `q=`, plus two header reflectors on `/`.
A finding requires the literal `<script>alert('ptai')` to land in the
response body unescaped.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_reflected_xss_query_reflection_emits_medium(fake_session):
    """Server echoes the raw payload in a `q=` response: medium severity."""
    from engine.probes import ProbeContext
    from engine.probes.web.reflected_xss import probe_reflected_xss

    reflecting_body = (
        "<html><body>You searched for <script>alert('ptai')</script>"
        "</body></html>"
    )

    def side_effect(url, **kwargs):
        # Reflect only on /search?q=
        if "/search?q=" in url and "?q=" in url:
            return _make_response(200, reflecting_body)
        return _make_response(200, "no reflection here")

    fake_session.get.side_effect = side_effect

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_reflected_xss(ctx)

    query_hits = [f for f in findings if "query reflection" in f["title"]]
    assert len(query_hits) >= 1
    assert query_hits[0]["severity"] == "medium"
    assert query_hits[0]["bug_class"] == "xss_reflected"
    assert query_hits[0]["category"] == "injection"


@pytest.mark.asyncio
async def test_reflected_xss_path_reflection_emits_high(fake_session):
    """Path-style reflectors (e.g. /track-order/) escalate to high."""
    from engine.probes import ProbeContext
    from engine.probes.web.reflected_xss import probe_reflected_xss

    reflecting_body = "Tracking <script>alert('ptai')</script> not found"

    def side_effect(url, **kwargs):
        if "/track-order/" in url or "/rest/track-order/" in url:
            return _make_response(200, reflecting_body)
        return _make_response(200, "clean")

    fake_session.get.side_effect = side_effect

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_reflected_xss(ctx)

    path_hits = [f for f in findings if "path reflection" in f["title"]]
    assert len(path_hits) >= 1
    assert path_hits[0]["severity"] == "high"
    assert path_hits[0]["bug_class"] == "xss_reflected"


@pytest.mark.asyncio
async def test_reflected_xss_no_finding_when_payload_html_escaped(fake_session):
    """Server escapes the payload (`&lt;script&gt;`): no finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.reflected_xss import probe_reflected_xss

    escaped_body = (
        "<html><body>You searched for "
        "&lt;script&gt;alert(&#39;ptai&#39;)&lt;/script&gt;"
        "</body></html>"
    )

    fake_session.get.return_value = _make_response(200, escaped_body)

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_reflected_xss(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_reflected_xss_header_reflection_xff(fake_session):
    """X-Forwarded-For payload echoed back into the homepage HTML."""
    from engine.probes import ProbeContext
    from engine.probes.web.reflected_xss import probe_reflected_xss

    reflecting_body = (
        "<p>Your IP: <script>alert('ptai')</script></p>"
    )

    def side_effect(url, **kwargs):
        headers = kwargs.get("headers") or {}
        if "X-Forwarded-For" in headers:
            return _make_response(200, reflecting_body)
        return _make_response(200, "clean")

    fake_session.get.side_effect = side_effect

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_reflected_xss(ctx)

    header_hits = [f for f in findings if "header reflection" in f["title"]]
    assert len(header_hits) >= 1
    assert any("X-Forwarded-For" in f["title"] for f in header_hits)


@pytest.mark.asyncio
async def test_reflected_xss_header_reflection_referer_javascript(fake_session):
    """Referer `javascript:` URL reflected unescaped into the body."""
    from engine.probes import ProbeContext
    from engine.probes.web.reflected_xss import probe_reflected_xss

    reflecting_body = '<a href="javascript:alert(1)">back</a>'

    def side_effect(url, **kwargs):
        headers = kwargs.get("headers") or {}
        if "Referer" in headers:
            return _make_response(200, reflecting_body)
        return _make_response(200, "clean")

    fake_session.get.side_effect = side_effect

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_reflected_xss(ctx)

    referer_hits = [f for f in findings if "Referer" in f["title"]]
    assert len(referer_hits) >= 1
    assert referer_hits[0]["severity"] == "medium"


@pytest.mark.asyncio
async def test_reflected_xss_skips_non_200_status(fake_session):
    """Non-200 responses (404, 500) must not produce findings even with echo."""
    from engine.probes import ProbeContext
    from engine.probes.web.reflected_xss import probe_reflected_xss

    fake_session.get.return_value = _make_response(
        404, "<script>alert('ptai')</script>"
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_reflected_xss(ctx)

    assert findings == []


def test_reflected_xss_is_registered():
    from engine.probes import registry
    from engine.probes.web import reflected_xss  # noqa: F401  - import registers

    spec = registry.get("web.reflected_xss")
    assert spec is not None
    assert spec.bug_class == "xss_reflected"
    assert spec.severity_max == "high"
    assert spec.owasp == "A03:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 8.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
