"""Regression test for the AD-mislabel chain assembler bug.

Earlier behavior: web findings with category="authentication" (e.g., JWT
alg=none on /api/Users) matched the AD Privilege Escalation template
because both shared the "authentication" category string. The chain
output then claimed "Domain Admin via AD attack chain" on a pure web
target, which was misleading and unprofessional.

This test pins the fix: AD templates only fire on AD-context findings,
web templates on web-context findings, etc.
"""
from __future__ import annotations


def test_web_auth_findings_do_not_match_ad_template():
    """A web target with auth findings must not produce 'AD Privilege Escalation'."""
    from agents.exploit_chain.chain_agent import _detect_finding_context

    web_finding = {
        "id": "f-1",
        "title": "JWT 'alg: none' accepted on /api/Users",
        "severity": "critical",
        "category": "authentication",
        "target": "http://localhost:3000/api/Users",
    }
    assert _detect_finding_context(web_finding) == "web"


def test_ad_finding_with_ldap_target_classified_as_ad():
    from agents.exploit_chain.chain_agent import _detect_finding_context

    ad_finding = {
        "id": "f-2",
        "title": "Kerberoastable account",
        "severity": "high",
        "category": "ad",
        "target": "ldap://corp.example.com:389",
    }
    assert _detect_finding_context(ad_finding) == "ad"


def test_ad_finding_with_kerberos_target_classified_as_ad():
    from agents.exploit_chain.chain_agent import _detect_finding_context

    ad_finding = {
        "id": "f-3",
        "title": "ASREP-roast candidate",
        "severity": "high",
        "category": "authentication",
        "target": "kerberos://dc01.example.com",
    }
    assert _detect_finding_context(ad_finding) == "ad"


def test_aws_metadata_target_classified_as_cloud():
    from agents.exploit_chain.chain_agent import _detect_finding_context

    finding = {
        "id": "f-4",
        "title": "SSRF to AWS metadata",
        "severity": "critical",
        "category": "ssrf",
        "target": "http://169.254.169.254/latest/meta-data/",
    }
    assert _detect_finding_context(finding) == "cloud"


def test_ad_template_blocked_when_no_ad_findings():
    """End-to-end: a chain over web findings must not emit an AD template chain."""
    import asyncio
    from unittest.mock import AsyncMock, MagicMock

    from agents.exploit_chain.chain_agent import ExploitChainAgent

    web_findings = [
        {
            "id": "f-1",
            "title": "JWT 'alg: none' accepted on /api/Users",
            "severity": "critical",
            "category": "authentication",
            "target": "http://localhost:3000/api/Users",
        },
        {
            "id": "f-2",
            "title": "Authenticated pivot: SQLi-captured admin token unlocks /api/Users",
            "severity": "high",
            "category": "authentication",
            "target": "http://localhost:3000/api/Users",
        },
        {
            "id": "f-3",
            "title": "GET-method SQL injection on /rest/products/search",
            "severity": "critical",
            "category": "injection",
            "target": "http://localhost:3000/rest/products/search",
        },
    ]

    db = MagicMock()
    db.get_findings = AsyncMock(return_value=web_findings)
    db.get_attack_chains = AsyncMock(return_value=[])
    db.add_attack_chain = AsyncMock()

    agent = ExploitChainAgent(db=db, llm=None)
    chains = asyncio.run(agent.discover_chains("eng-test"))

    # No chain should claim AD context
    ad_chains = [c for c in chains if c.get("name") == "AD Privilege Escalation"]
    assert ad_chains == [], (
        f"AD Privilege Escalation chains should not appear on web findings, "
        f"got: {ad_chains}"
    )


def test_web_auth_template_fires_on_web_findings():
    """The new 'Auth Bypass to Admin Access' template must fire on web auth chains."""
    import asyncio
    from unittest.mock import AsyncMock, MagicMock

    from agents.exploit_chain.chain_agent import ExploitChainAgent

    web_findings = [
        {
            "id": "f-1",
            "title": "JWT 'alg: none' accepted on /api/Users",
            "severity": "critical",
            "category": "authentication",
            "target": "http://localhost:3000/api/Users",
        },
        {
            "id": "f-2",
            "title": "REST resource leaks data without authentication: /api/Recycles",
            "severity": "high",
            "category": "exposure",
            "target": "http://localhost:3000/api/Recycles",
        },
    ]

    db = MagicMock()
    db.get_findings = AsyncMock(return_value=web_findings)
    db.get_attack_chains = AsyncMock(return_value=[])
    db.add_attack_chain = AsyncMock()

    agent = ExploitChainAgent(db=db, llm=None)
    chains = asyncio.run(agent.discover_chains("eng-test"))

    web_chain_names = [c.get("name") for c in chains]
    # Either Auth Bypass to Admin Access or Progressive Severity Chain is acceptable;
    # both correctly describe the web auth bypass + exposure pattern.
    assert any(
        "Auth Bypass" in n or "Progressive Severity" in n
        for n in web_chain_names
    ), f"Expected web-context chain, got: {web_chain_names}"
