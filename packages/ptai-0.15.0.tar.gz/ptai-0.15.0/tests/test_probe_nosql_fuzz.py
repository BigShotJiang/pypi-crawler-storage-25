"""Tests for the crawler-driven NoSQL injection fuzz probe."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def _resp(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {"Content-Type": "application/json"}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_nosql_fuzz_emits_finding_on_token_response(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.nosql_fuzz import probe_nosql_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/api/login"},
        forms=[],
    )

    def get_side(url, **_kwargs):
        # Baseline: 401, attack with $ne returns token
        if "%24ne" in url or "%5B%24" in url or "$ne" in url:
            return _resp(200, '{"token":"eyJhbGciOiJIUzI1NiJ9...", "expires":3600}')
        return _resp(401, '{"error":"unauthorized"}')

    fake_session.get.side_effect = get_side

    with patch(
        "engine.probes.web.nosql_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_nosql_fuzz(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "high"
    assert findings[0]["bug_class"] == "nosql_injection"


@pytest.mark.asyncio
async def test_nosql_fuzz_no_finding_when_baseline_already_returns_token(fake_session):
    """If baseline already has a token (e.g., session endpoint), no spurious hit."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.nosql_fuzz import probe_nosql_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/api/login"},
        forms=[],
    )

    fake_session.get.side_effect = lambda url, **_k: _resp(200, '{"token":"abc"}')

    with patch(
        "engine.probes.web.nosql_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_nosql_fuzz(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_nosql_fuzz_no_finding_when_endpoints_clean(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.nosql_fuzz import probe_nosql_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/api/login"},
        forms=[],
    )

    fake_session.get.side_effect = lambda url, **_k: _resp(401, '{"error":"unauthorized"}')

    with patch(
        "engine.probes.web.nosql_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_nosql_fuzz(ctx)

    assert findings == []


def test_nosql_fuzz_is_registered():
    from engine.probes import registry
    from engine.probes.web import nosql_fuzz  # noqa: F401  - registers

    spec = registry.get("web.nosql_fuzz")
    assert spec is not None
    assert spec.bug_class == "nosql_injection"
    assert spec.severity_max == "high"
    assert "fuzzing" in spec.tags
