"""Tests for the asset secrets / hidden URL scanner probe.

Targets OWASP Juice Shop's needle-in-haystack family (challenges #11,
#34, #42). The probe walks crawler-discovered HTML and JS, mining each
body for hidden URLs, base64-encoded breadcrumbs, and developer comment
leaks.
"""
from __future__ import annotations

import base64
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from engine.probes.recon.crawler import CrawlResult


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_js_bundle_contains_base64_url_emits_info_finding(fake_session):
    """A JS bundle carries a base64-encoded URL. Probe decodes and flags it."""
    from engine.probes import ProbeContext
    from engine.probes.web.asset_secrets_scan import probe_asset_secrets_scan

    encoded = base64.b64encode(b"https://internal.ptai-test/score").decode()
    js_body = f"var token = '{encoded}'; console.log('boot');"

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js={"/main.js"},
    )

    fake_session.get.return_value = _make_response(200, js_body)

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    with patch(
        "engine.probes.web.asset_secrets_scan.run_crawler",
        new=AsyncMock(return_value=fake_crawl),
    ):
        findings = await probe_asset_secrets_scan(ctx)

    assert any(
        "Base64" in f["title"] and f["severity"] in ("info", "medium")
        for f in findings
    ), findings


@pytest.mark.asyncio
async def test_html_comment_easter_egg_shape_emits_info_finding(fake_session):
    """Juice Shop signature easter-egg shape `/the/.../easter` in a comment."""
    from engine.probes import ProbeContext
    from engine.probes.web.asset_secrets_scan import probe_asset_secrets_scan

    html_body = (
        "<html><body>"
        "<!-- TODO: remove before launch, the easter URL is "
        "/the/quiet/forgotten/path/to/the/crawl/space/easter -->"
        "</body></html>"
    )

    fake_crawl = CrawlResult(
        discovered_paths={"/"},
        discovered_js=set(),
    )

    fake_session.get.return_value = _make_response(200, html_body)

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    with patch(
        "engine.probes.web.asset_secrets_scan.run_crawler",
        new=AsyncMock(return_value=fake_crawl),
    ):
        findings = await probe_asset_secrets_scan(ctx)

    assert any("Easter-egg" in f["title"] for f in findings), findings
    assert all(f["severity"] in ("info", "medium") for f in findings)


@pytest.mark.asyncio
async def test_base64_decodes_to_admin_keyword_emits_finding(fake_session):
    """Decoded base64 contains an interesting keyword (`admin`, `ptai-test`)."""
    from engine.probes import ProbeContext
    from engine.probes.web.asset_secrets_scan import probe_asset_secrets_scan

    encoded = base64.b64encode(b"admin password ptai-test").decode()
    html_body = f"<html><body><div data-x='{encoded}'></div></body></html>"

    fake_crawl = CrawlResult(
        discovered_paths={"/"},
        discovered_js=set(),
    )

    fake_session.get.return_value = _make_response(200, html_body)

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    with patch(
        "engine.probes.web.asset_secrets_scan.run_crawler",
        new=AsyncMock(return_value=fake_crawl),
    ):
        findings = await probe_asset_secrets_scan(ctx)

    assert any(
        "Base64" in f["title"] and "admin" in f["evidence"].lower()
        for f in findings
    ), findings


@pytest.mark.asyncio
async def test_empty_crawler_yields_no_findings(fake_session):
    """Crawler returns nothing -> probe stays silent (graceful)."""
    from engine.probes import ProbeContext
    from engine.probes.web.asset_secrets_scan import probe_asset_secrets_scan

    fake_crawl = CrawlResult()  # all empty

    # Index fetch returns boring body with no signals.
    fake_session.get.return_value = _make_response(200, "<html>nothing here</html>")

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    with patch(
        "engine.probes.web.asset_secrets_scan.run_crawler",
        new=AsyncMock(return_value=fake_crawl),
    ):
        findings = await probe_asset_secrets_scan(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_crawler_raises_probe_returns_empty(fake_session):
    """Crawler raises -> probe degrades gracefully and returns []."""
    from engine.probes import ProbeContext
    from engine.probes.web.asset_secrets_scan import probe_asset_secrets_scan

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    boom = AsyncMock(side_effect=RuntimeError("crawler down"))
    with patch("engine.probes.web.asset_secrets_scan.run_crawler", new=boom):
        findings = await probe_asset_secrets_scan(ctx)

    assert findings == []


def test_asset_secrets_scan_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import asset_secrets_scan

    # The conftest snapshot is taken before the module gets a chance to
    # re-register on a fresh registry, so reload to force the decorator
    # to re-run against the current registry state.
    if registry.get("web.asset_secrets_scan") is None:
        importlib.reload(asset_secrets_scan)

    spec = registry.get("web.asset_secrets_scan")
    assert spec is not None
    assert spec.bug_class == "exposed_admin"
    assert spec.severity_max == "medium"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 15.0
    assert "anonymous" in spec.tags
    assert "discovery" in spec.tags
