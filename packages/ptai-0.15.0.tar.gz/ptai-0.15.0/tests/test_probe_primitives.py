"""Tests for probe primitives (engine/probes/primitives.py).

Primitives are the building blocks probes call: walk_paths for path-list
loops, baseline_attack_diff for response-shape comparisons, and the HTTP
helpers (get, post_json) that handle errors and timeouts uniformly.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


@pytest.fixture
def fake_session():
    """A mock aiohttp session whose .get / .post return what we configure."""
    session = MagicMock()
    return session


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    """Build an async-context-manager fake response."""
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.mark.asyncio
async def test_get_returns_status_headers_body(fake_session):
    from engine.probes.primitives import http_get

    fake_session.get.return_value = _make_response(
        200, "hello world", {"Content-Type": "text/plain"}
    )

    status, headers, body = await http_get(fake_session, "http://x/")

    assert status == 200
    assert body == "hello world"
    assert headers["Content-Type"] == "text/plain"


@pytest.mark.asyncio
async def test_get_handles_errors_returning_zero(fake_session):
    """Network errors must not raise; probes count on (0, {}, '') sentinel."""
    import aiohttp

    from engine.probes.primitives import http_get

    fake_session.get.side_effect = aiohttp.ClientError("boom")
    status, headers, body = await http_get(fake_session, "http://x/")
    assert status == 0
    assert body == ""
    assert headers == {}


@pytest.mark.asyncio
async def test_get_truncates_body_to_64k(fake_session):
    from engine.probes.primitives import http_get

    huge = "A" * 100_000
    fake_session.get.return_value = _make_response(200, huge)
    _, _, body = await http_get(fake_session, "http://x/")
    assert len(body) == 65000


@pytest.mark.asyncio
async def test_post_json_sends_json_body(fake_session):
    from engine.probes.primitives import http_post_json

    fake_session.post.return_value = _make_response(201, '{"ok":true}')

    status, _, body = await http_post_json(
        fake_session, "http://x/api/x", {"k": "v"}
    )
    assert status == 201
    assert body == '{"ok":true}'
    fake_session.post.assert_called_once()
    # second positional arg or kwarg "json"
    kwargs = fake_session.post.call_args.kwargs
    assert kwargs["json"] == {"k": "v"}


@pytest.mark.asyncio
async def test_walk_paths_invokes_predicate_for_each_path(fake_session):
    """walk_paths GETs every path and yields findings where predicate hits."""
    from engine.probes.primitives import walk_paths

    fake_session.get.side_effect = [
        _make_response(200, "secret data"),
        _make_response(404, ""),
        _make_response(200, "more secrets"),
    ]

    def predicate(status, headers, body):
        return status == 200 and "secret" in body

    findings = await walk_paths(
        session=fake_session,
        base="http://x",
        paths=("/a", "/b", "/c"),
        predicate=predicate,
        finding_template={
            "title": "leak: {path}",
            "severity": "high",
            "category": "exposure",
        },
    )

    assert len(findings) == 2
    titles = sorted(f["title"] for f in findings)
    assert titles == ["leak: /a", "leak: /c"]


@pytest.mark.asyncio
async def test_walk_paths_caps_concurrency(fake_session):
    """Driver should not blast 100 in-flight GETs. concurrency=8 by default."""
    import asyncio

    from engine.probes.primitives import walk_paths

    # fake_session.get returns an async context manager; we count entries
    cm_count = {"in": 0, "peak": 0}

    class CountingCM:
        async def __aenter__(self):
            cm_count["in"] += 1
            cm_count["peak"] = max(cm_count["peak"], cm_count["in"])
            await asyncio.sleep(0.005)
            r = AsyncMock()
            r.status = 404
            r.text = AsyncMock(return_value="")
            r.headers = {}
            return r

        async def __aexit__(self, *a):
            cm_count["in"] -= 1
            return None

    fake_session.get.side_effect = lambda *a, **k: CountingCM()

    paths = tuple(f"/p{i}" for i in range(40))
    await walk_paths(
        session=fake_session,
        base="http://x",
        paths=paths,
        predicate=lambda *a: False,
        finding_template={"title": "x", "severity": "low", "category": "x"},
        concurrency=8,
    )
    assert cm_count["peak"] <= 8, f"peak concurrency {cm_count['peak']} exceeded 8"


@pytest.mark.asyncio
async def test_baseline_attack_diff_size_ratio(fake_session):
    """3.0x size ratio with HTTP 200 = hit."""
    from engine.probes.primitives import baseline_attack_diff

    fake_session.get.side_effect = [
        _make_response(200, "x" * 1000),  # baseline
        _make_response(200, "x" * 4000),  # attack (4x size)
    ]

    hit, baseline_size, attack_size = await baseline_attack_diff(
        session=fake_session,
        baseline_url="http://x/?q=apple",
        attack_url="http://x/?q=apple'%20UNION%20SELECT%201--",
        size_ratio_threshold=3.0,
    )
    assert hit is True
    assert baseline_size == 1000
    assert attack_size == 4000


@pytest.mark.asyncio
async def test_baseline_attack_diff_no_hit_on_similar_sizes(fake_session):
    from engine.probes.primitives import baseline_attack_diff

    fake_session.get.side_effect = [
        _make_response(200, "x" * 1000),
        _make_response(200, "x" * 1100),
    ]

    hit, _, _ = await baseline_attack_diff(
        session=fake_session,
        baseline_url="http://x/a",
        attack_url="http://x/a?q=test",
        size_ratio_threshold=3.0,
    )
    assert hit is False


@pytest.mark.asyncio
async def test_baseline_attack_diff_no_hit_on_non_200(fake_session):
    from engine.probes.primitives import baseline_attack_diff

    fake_session.get.side_effect = [
        _make_response(200, "x" * 1000),
        _make_response(500, "x" * 5000),  # 5x size but 500 status
    ]

    hit, _, _ = await baseline_attack_diff(
        session=fake_session,
        baseline_url="http://x/a",
        attack_url="http://x/a?q=test",
        size_ratio_threshold=3.0,
    )
    assert hit is False
