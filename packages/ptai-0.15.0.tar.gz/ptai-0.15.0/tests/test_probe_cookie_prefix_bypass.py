"""Tests for the cookie `__Host-` / `__Secure-` prefix bypass probe.

The probe captures Set-Cookie values from a baseline request, identifies
prefixed cookies, then replays with mutated cookie names. A successful
bypass shows up as a response shape close to the baseline while the
random-prefix control diverges.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_skip_when_no_prefixed_cookies(fake_session):
    """Server that sets only ordinary cookies emits no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.cookie_prefix_bypass import probe_cookie_prefix_bypass

    fake_session.get.return_value = _make_response(
        200, "ok", {"Set-Cookie": "sessionid=abc; Path=/"}
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_cookie_prefix_bypass(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_skip_when_baseline_request_fails(fake_session):
    """status=0 from the baseline GET means we cannot probe."""
    from engine.probes import ProbeContext
    from engine.probes.web.cookie_prefix_bypass import probe_cookie_prefix_bypass

    fake_session.get.return_value = _make_response(0, "")

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_cookie_prefix_bypass(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_high_when_mutation_matches_baseline_and_control_diverges(fake_session):
    """Mutated cookie name matching baseline shape is the bypass signal."""
    from engine.probes import ProbeContext
    from engine.probes.web.cookie_prefix_bypass import probe_cookie_prefix_bypass

    baseline_body = "x" * 1000  # privileged-shape body
    control_body = "y" * 200  # logged-out / unknown-cookie shape

    baseline = _make_response(
        200,
        baseline_body,
        {"Set-Cookie": "__Host-sessionid=abc; Path=/; Secure"},
    )
    control = _make_response(200, control_body)
    # All mutated variants come back with privileged-shape body.
    mutated = _make_response(200, baseline_body)

    # First call: baseline. Second call: control. Remaining calls: mutated.
    fake_session.get.side_effect = [baseline, control] + [mutated] * 12

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_cookie_prefix_bypass(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "high"
    assert findings[0]["bug_class"] == "auth_bypass"
    assert "__Host-sessionid" in findings[0]["title"]


@pytest.mark.asyncio
async def test_no_finding_when_mutation_matches_control(fake_session):
    """Mutated request matching the control means the parser rejected it."""
    from engine.probes import ProbeContext
    from engine.probes.web.cookie_prefix_bypass import probe_cookie_prefix_bypass

    baseline_body = "x" * 1000
    control_body = "y" * 200

    baseline = _make_response(
        200,
        baseline_body,
        {"Set-Cookie": "__Secure-token=abc; Path=/; Secure"},
    )
    control = _make_response(200, control_body)
    # All mutated variants look like the control: parser correctly ignores them.
    mutated = _make_response(200, control_body)

    fake_session.get.side_effect = [baseline, control] + [mutated] * 12

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_cookie_prefix_bypass(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_secure_prefix_also_detected(fake_session):
    """`__Secure-` prefix gets the same treatment as `__Host-`."""
    from engine.probes import ProbeContext
    from engine.probes.web.cookie_prefix_bypass import probe_cookie_prefix_bypass

    baseline_body = "z" * 800
    control_body = "q" * 100

    baseline = _make_response(
        200,
        baseline_body,
        {"Set-Cookie": "__Secure-auth=abc; Secure"},
    )
    control = _make_response(200, control_body)
    mutated = _make_response(200, baseline_body)

    fake_session.get.side_effect = [baseline, control] + [mutated] * 12

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_cookie_prefix_bypass(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "high"
    assert "__Secure-auth" in findings[0]["title"]


def test_cookie_prefix_bypass_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import cookie_prefix_bypass

    importlib.reload(cookie_prefix_bypass)

    spec = registry.get("web.cookie_prefix_bypass")
    assert spec is not None
    assert spec.bug_class == "auth_bypass"
    assert spec.severity_max == "high"
    assert spec.requires_auth is False
