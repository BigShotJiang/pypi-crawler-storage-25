"""Tests for the JWT jku/x5u SSRF and kid-injection probe.

The probe captures an existing JWT (or skips), forges header variants
that target jku, x5u, kid path traversal, and kid SQL injection, and
replays each forged token against protected endpoints.
"""
from __future__ import annotations

import base64
import json
from unittest.mock import AsyncMock, MagicMock

import pytest


def _b64url(blob: bytes) -> str:
    return base64.urlsafe_b64encode(blob).rstrip(b"=").decode("ascii")


def _make_jwt(header: dict, payload: dict) -> str:
    h = _b64url(json.dumps(header, separators=(",", ":")).encode())
    p = _b64url(json.dumps(payload, separators=(",", ":")).encode())
    return f"{h}.{p}.sig"


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_skip_when_no_jwt_obtainable(fake_session):
    """Probe must skip cleanly when login flows do not yield a JWT."""
    from engine.probes import ProbeContext
    from engine.probes.web.jwt_jku_x5u_ssrf import probe_jwt_jku_x5u_ssrf

    fake_session.post.return_value = _make_response(401, '{"error":"unauthorized"}')

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    findings = await probe_jwt_jku_x5u_ssrf(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_critical_on_admin_shape_response(fake_session):
    """200 + admin-shape body via forged token is auth bypass = critical."""
    from engine.probes import ProbeContext
    from engine.probes.web.jwt_jku_x5u_ssrf import probe_jwt_jku_x5u_ssrf

    captured_token = _make_jwt(
        {"alg": "HS256", "typ": "JWT"},
        {"sub": "user1", "role": "user"},
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth={"token": captured_token},
    )

    fake_session.get.return_value = _make_response(
        200, '{"id":1,"username":"admin","role":"admin"}'
    )

    findings = await probe_jwt_jku_x5u_ssrf(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"
    assert findings[0]["bug_class"] == "auth_bypass"


@pytest.mark.asyncio
async def test_medium_on_kid_jku_stack_trace_leak(fake_session):
    """500 with kid/jku in the trace is medium parser leak, not bypass."""
    from engine.probes import ProbeContext
    from engine.probes.web.jwt_jku_x5u_ssrf import probe_jwt_jku_x5u_ssrf

    captured_token = _make_jwt(
        {"alg": "HS256", "typ": "JWT"},
        {"sub": "user1"},
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth={"token": captured_token},
    )

    fake_session.get.return_value = _make_response(
        500,
        "Internal Server Error: failed to resolve kid '../../../dev/null' for jku lookup",
    )

    findings = await probe_jwt_jku_x5u_ssrf(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "medium"
    assert findings[0]["category"] == "information-disclosure"


@pytest.mark.asyncio
async def test_no_finding_when_protected_endpoint_rejects(fake_session):
    """A clean 401 on every variant emits no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.jwt_jku_x5u_ssrf import probe_jwt_jku_x5u_ssrf

    captured_token = _make_jwt(
        {"alg": "HS256", "typ": "JWT"},
        {"sub": "user1"},
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth={"token": captured_token},
    )

    fake_session.get.return_value = _make_response(401, '{"error":"invalid token"}')

    findings = await probe_jwt_jku_x5u_ssrf(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_jwt_capture_via_login_post(fake_session):
    """Probe pulls a JWT from a login response when ctx has no captured_auth."""
    from engine.probes import ProbeContext
    from engine.probes.web.jwt_jku_x5u_ssrf import probe_jwt_jku_x5u_ssrf

    token = _make_jwt(
        {"alg": "HS256", "typ": "JWT"},
        {"sub": "user1"},
    )
    fake_session.post.return_value = _make_response(
        200, json.dumps({"authentication": {"token": token}})
    )
    fake_session.get.return_value = _make_response(
        200, '{"username":"admin","role":"admin"}'
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    findings = await probe_jwt_jku_x5u_ssrf(ctx)
    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"


def test_jwt_jku_x5u_ssrf_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import jwt_jku_x5u_ssrf

    importlib.reload(jwt_jku_x5u_ssrf)

    spec = registry.get("web.jwt_jku_x5u_ssrf")
    assert spec is not None
    assert spec.bug_class == "auth_bypass"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is False
