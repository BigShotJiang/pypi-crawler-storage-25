"""Tests for the finalizer handlers (Step 5 of the autonomy roadmap).

The finalizers wrap the four legacy terminal-phase agents
(ExploitChainAgent, PoCAgent, DetectionAgent, ReportAgent) so the agent
loop produces the same outputs as the legacy fixed pipeline.

Tests mock the agent classes; nothing here actually runs the agents.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.fixture
def fresh_memory():
    from engine.working_memory import WorkingMemory

    return WorkingMemory(engagement_id="e-fin-test", target="http://localhost:3000")


@pytest.fixture(autouse=True)
def _reset_finalizer_state():
    """Reset the module-level db handle between tests."""
    from engine.agents.handlers import finalizers

    finalizers._db = None
    finalizers._llm = None
    finalizers._scope = None
    yield
    finalizers._db = None
    finalizers._llm = None
    finalizers._scope = None


@pytest.fixture
def fake_db():
    """Sentinel db handle. The finalizers only pass it through to agent ctors."""
    return MagicMock(name="FindingsDB")


@pytest.mark.asyncio
async def test_finalize_chain_calls_discover_chains(fresh_memory, fake_db):
    from engine.agents.handlers import finalizers

    finalizers.set_db_handle(fake_db)

    fake_chains = [{"id": "c1"}, {"id": "c2"}, {"id": "c3"}]
    mock_agent = MagicMock()
    mock_agent.discover_chains = AsyncMock(return_value=fake_chains)

    with patch(
        "agents.exploit_chain.chain_agent.ExploitChainAgent",
        return_value=mock_agent,
    ) as ctor:
        obs = await finalizers.handle_chain(fresh_memory, {})

    ctor.assert_called_once()
    mock_agent.discover_chains.assert_awaited_once_with("e-fin-test")
    assert obs.success is True
    assert obs.raw["chains_added"] == 3
    assert obs.normalized is not None
    assert obs.normalized.verdict == "confirmed"
    assert "3 attack chains" in obs.normalized.evidence


@pytest.mark.asyncio
async def test_finalize_chain_handles_exception(fresh_memory, fake_db):
    from engine.agents.handlers import finalizers

    finalizers.set_db_handle(fake_db)

    mock_agent = MagicMock()
    mock_agent.discover_chains = AsyncMock(side_effect=RuntimeError("kaboom"))

    with patch(
        "agents.exploit_chain.chain_agent.ExploitChainAgent",
        return_value=mock_agent,
    ):
        obs = await finalizers.handle_chain(fresh_memory, {})

    assert obs.success is False
    assert obs.normalized.verdict == "failed"
    assert "kaboom" in obs.normalized.evidence


@pytest.mark.asyncio
async def test_finalize_chain_no_db_returns_failed(fresh_memory):
    """When set_db_handle was never called, handler returns a failed observation."""
    from engine.agents.handlers import finalizers

    obs = await finalizers.handle_chain(fresh_memory, {})

    assert obs.success is False
    assert obs.normalized.verdict == "failed"
    assert "db handle" in obs.error


@pytest.mark.asyncio
async def test_finalize_validate_pocs_returns_count(fresh_memory, fake_db):
    from engine.agents.handlers import finalizers

    finalizers.set_db_handle(fake_db)

    fake_results = [{"id": "f1"}, {"id": "f2"}]
    mock_agent = MagicMock()
    mock_agent.validate_all = AsyncMock(return_value=fake_results)

    with patch("agents.poc_validator.poc_agent.PoCAgent", return_value=mock_agent):
        obs = await finalizers.handle_validate_pocs(fresh_memory, {})

    mock_agent.validate_all.assert_awaited_once_with("e-fin-test")
    assert obs.success is True
    assert obs.raw["validations_count"] == 2
    assert obs.normalized.verdict == "confirmed"


@pytest.mark.asyncio
async def test_finalize_generate_detections_returns_rules_count(fresh_memory, fake_db):
    from engine.agents.handlers import finalizers

    finalizers.set_db_handle(fake_db)

    fake_rules = [{"id": "r1"}, {"id": "r2"}, {"id": "r3"}, {"id": "r4"}]
    mock_agent = MagicMock()
    mock_agent.generate_rules = AsyncMock(return_value=fake_rules)

    with patch(
        "agents.detection.detection_agent.DetectionAgent",
        return_value=mock_agent,
    ):
        obs = await finalizers.handle_generate_detections(fresh_memory, {})

    mock_agent.generate_rules.assert_awaited_once_with("e-fin-test")
    assert obs.success is True
    assert obs.raw["rules_count"] == 4


@pytest.mark.asyncio
async def test_finalize_report_returns_path(fresh_memory, fake_db):
    from engine.agents.handlers import finalizers

    finalizers.set_db_handle(fake_db)

    fake_report = {
        "output_path": "reports/pentest-e-fin-test-20260508.md",
        "output_paths": {"markdown": "reports/pentest-e-fin-test-20260508.md"},
    }
    mock_agent = MagicMock()
    mock_agent.generate_report = AsyncMock(return_value=fake_report)

    with patch("agents.report.report_agent.ReportAgent", return_value=mock_agent):
        obs = await finalizers.handle_report(fresh_memory, {})

    mock_agent.generate_report.assert_awaited_once()
    assert obs.success is True
    assert obs.raw["report_path"] == "reports/pentest-e-fin-test-20260508.md"
    assert obs.normalized.verdict == "confirmed"


@pytest.mark.asyncio
async def test_finalize_report_handles_exception(fresh_memory, fake_db):
    from engine.agents.handlers import finalizers

    finalizers.set_db_handle(fake_db)

    mock_agent = MagicMock()
    mock_agent.generate_report = AsyncMock(side_effect=RuntimeError("io error"))

    with patch("agents.report.report_agent.ReportAgent", return_value=mock_agent):
        obs = await finalizers.handle_report(fresh_memory, {})

    assert obs.success is False
    assert obs.normalized.verdict == "failed"
    assert "io error" in obs.normalized.evidence


def test_register_finalizer_handlers_wires_all_four():
    from engine.agent_loop import _HANDLERS
    from engine.agents.handlers.finalizers import register_finalizer_handlers

    expected = {
        "finalize.chain",
        "finalize.validate_pocs",
        "finalize.generate_detections",
        "finalize.report",
    }
    # Snapshot any existing registrations so re-running doesn't pollute.
    pre_existing = expected & set(_HANDLERS.keys())

    newly = set(register_finalizer_handlers())
    # All expected names should now be registered (whether by this call
    # or a previous one in the same process).
    assert expected <= set(_HANDLERS.keys())
    # The handler wired must equal the expected set minus any that were
    # already registered before this call.
    assert newly == (expected - pre_existing)


def test_register_default_handlers_includes_finalizers():
    from engine.agent_loop import _HANDLERS
    from engine.agents.handlers import register_default_handlers

    register_default_handlers()
    expected = {
        "finalize.chain",
        "finalize.validate_pocs",
        "finalize.generate_detections",
        "finalize.report",
    }
    assert expected <= set(_HANDLERS.keys())


def test_set_db_handle_is_idempotent_and_overwrites(fake_db):
    from engine.agents.handlers import finalizers

    finalizers.set_db_handle(fake_db)
    assert finalizers._db is fake_db

    other_db = MagicMock(name="OtherDB")
    finalizers.set_db_handle(other_db, llm="llm-stub", scope="scope-stub")
    assert finalizers._db is other_db
    assert finalizers._llm == "llm-stub"
    assert finalizers._scope == "scope-stub"
