"""Tests for the crawler-driven SSTI fuzz probe."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def _resp(status: int, body: str):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = {"Content-Type": "text/html"}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_ssti_fuzz_emits_finding_on_numeric_eval(fake_session):
    """Body containing '49' but not in baseline triggers a finding."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.ssti_fuzz import probe_ssti_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/render"},
        forms=[],
    )

    def get_side(url, **_kw):
        if "7" in url:
            return _resp(200, "Result: 49 computed")
        return _resp(200, "Result: nothing")

    fake_session.get.side_effect = get_side

    with patch("engine.probes.web.ssti_fuzz.run_crawler", return_value=fake_crawl):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_ssti_fuzz(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"
    assert findings[0]["bug_class"] == "ssti"


@pytest.mark.asyncio
async def test_ssti_fuzz_no_finding_when_49_in_baseline(fake_session):
    """If baseline already contains '49', no false positive."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.ssti_fuzz import probe_ssti_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/render"},
        forms=[],
    )

    # Both baseline and payload responses contain '49'
    fake_session.get.side_effect = lambda url, **_kw: _resp(200, "Value is 49 items")

    with patch("engine.probes.web.ssti_fuzz.run_crawler", return_value=fake_crawl):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_ssti_fuzz(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_ssti_fuzz_detects_engine_error_string(fake_session):
    """An engine error traceback in body (absent from baseline) is a hit."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.ssti_fuzz import probe_ssti_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/render"},
        forms=[],
    )

    call_count = 0

    def get_side(url, **_kw):
        nonlocal call_count
        call_count += 1
        # First call is baseline (clean param), subsequent calls are payload requests
        if call_count == 1:
            return _resp(200, "Welcome")
        return _resp(500, "jinja2.exceptions.TemplateSyntaxError: unexpected token")

    fake_session.get.side_effect = get_side

    with patch("engine.probes.web.ssti_fuzz.run_crawler", return_value=fake_crawl):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_ssti_fuzz(ctx)

    assert len(findings) >= 1
    assert findings[0]["bug_class"] == "ssti"


@pytest.mark.asyncio
async def test_ssti_fuzz_handles_crawler_failure(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.ssti_fuzz import probe_ssti_fuzz

    with patch(
        "engine.probes.web.ssti_fuzz.run_crawler",
        side_effect=RuntimeError("crawler down"),
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_ssti_fuzz(ctx)

    assert findings == []


def test_ssti_fuzz_is_registered():
    from engine.probes import registry
    from engine.probes.web import ssti_fuzz  # noqa: F401

    spec = registry.get("web.ssti_fuzz")
    assert spec is not None
    assert spec.bug_class == "ssti"
    assert spec.severity_max == "critical"
    assert "fuzzing" in spec.tags
