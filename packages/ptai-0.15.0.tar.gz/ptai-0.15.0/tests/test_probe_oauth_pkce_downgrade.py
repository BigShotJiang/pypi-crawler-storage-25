"""Tests for the OAuth PKCE downgrade + redirect_uri mutation probe.

Inspired by CVE-2025-4144. The probe walks common authorize endpoints
and flags when the server accepts code_challenge_method=plain, omits
the method entirely, or accepts a redirect_uri that doesn't match the
registered allowlist.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.fixture
def captured_auth():
    return {
        "token": "x",
        "auth_header": "Authorization",
        "auth_value": "Bearer x",
    }


@pytest.mark.asyncio
async def test_returns_empty_when_no_captured_auth(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.oauth_pkce_downgrade import probe_oauth_pkce_downgrade

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=None,
    )
    findings = await probe_oauth_pkce_downgrade(ctx)
    assert findings == []
    fake_session.get.assert_not_called()


def _five_for_endpoint(
    baseline: tuple, plain: tuple, no_method: tuple, mut_a: tuple, mut_b: tuple, mut_c: tuple
):
    """Return the six responses needed per endpoint in order."""
    return [
        _make_response(*baseline),
        _make_response(*plain),
        _make_response(*no_method),
        _make_response(*mut_a),
        _make_response(*mut_b),
        _make_response(*mut_c),
    ]


@pytest.mark.asyncio
async def test_pkce_plain_downgrade_flagged(fake_session, captured_auth):
    """Server accepts method=plain and returns code in Location."""
    from engine.probes import ProbeContext
    from engine.probes.web import oauth_pkce_downgrade as mod
    from engine.probes.web.oauth_pkce_downgrade import probe_oauth_pkce_downgrade

    # First endpoint /oauth/authorize: baseline 302 ok, plain 302 with code (HIT),
    # no-method 200 (no code), three mutations -> 200 (no code).
    first = _five_for_endpoint(
        baseline=(302, "", {"Location": "https://app/cb?code=ok"}),
        plain=(302, "", {"Location": "https://app/cb?code=BAD"}),
        no_method=(200, "ok"),
        mut_a=(200, "no-redirect"),
        mut_b=(200, "no-redirect"),
        mut_c=(200, "no-redirect"),
    )
    # Remaining endpoints all return 404 baseline so they short-circuit.
    rest = [_make_response(404, "nope") for _ in range(len(mod.AUTHORIZE_PATHS) - 1)]
    fake_session.get.side_effect = first + rest

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
    )

    findings = await probe_oauth_pkce_downgrade(ctx)
    assert any("method=plain" in f["title"] for f in findings)
    plain_finding = next(f for f in findings if "method=plain" in f["title"])
    assert plain_finding["severity"] == "critical"
    assert plain_finding["bug_class"] == "auth_bypass"


@pytest.mark.asyncio
async def test_redirect_uri_attacker_mutation_flagged(fake_session, captured_auth):
    """Server accepts redirect_uri pointing at an attacker-controlled host."""
    from engine.probes import ProbeContext
    from engine.probes.web import oauth_pkce_downgrade as mod
    from engine.probes.web.oauth_pkce_downgrade import probe_oauth_pkce_downgrade

    # baseline 302 (OK), plain 200 (no hit), no_method 200, mut attacker-host 302 with code (HIT),
    # mut path-traversal 200, mut subdomain-confusion 200.
    first = _five_for_endpoint(
        baseline=(302, "", {"Location": "https://app/cb?code=ok"}),
        plain=(200, "ok"),
        no_method=(200, "ok"),
        mut_a=(302, "", {"Location": "https://ptai-pkce-canary.example/cb?code=PWN"}),
        mut_b=(200, "no-redirect"),
        mut_c=(200, "no-redirect"),
    )
    rest = [_make_response(404, "nope") for _ in range(len(mod.AUTHORIZE_PATHS) - 1)]
    fake_session.get.side_effect = first + rest

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
    )

    findings = await probe_oauth_pkce_downgrade(ctx)
    assert any("attacker-host" in f["title"] for f in findings)
    f = next(x for x in findings if "attacker-host" in x["title"])
    assert f["severity"] == "critical"
    assert f["category"] == "auth"


@pytest.mark.asyncio
async def test_no_finding_when_endpoint_unreachable(fake_session, captured_auth):
    """Every authorize endpoint returns 404 baseline; nothing should fire."""
    from engine.probes import ProbeContext
    from engine.probes.web import oauth_pkce_downgrade as mod
    from engine.probes.web.oauth_pkce_downgrade import probe_oauth_pkce_downgrade

    fake_session.get.side_effect = [
        _make_response(404, "nope") for _ in range(len(mod.AUTHORIZE_PATHS) * 6)
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
    )
    findings = await probe_oauth_pkce_downgrade(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_no_finding_when_downgrades_rejected(fake_session, captured_auth):
    """Baseline reachable but every downgrade variant returns 400."""
    from engine.probes import ProbeContext
    from engine.probes.web import oauth_pkce_downgrade as mod
    from engine.probes.web.oauth_pkce_downgrade import probe_oauth_pkce_downgrade

    first = _five_for_endpoint(
        baseline=(302, "", {"Location": "https://app/cb?code=ok"}),
        plain=(400, "invalid_request"),
        no_method=(400, "invalid_request"),
        mut_a=(400, "invalid_request"),
        mut_b=(400, "invalid_request"),
        mut_c=(400, "invalid_request"),
    )
    rest = [_make_response(404, "nope") for _ in range(len(mod.AUTHORIZE_PATHS) - 1)]
    fake_session.get.side_effect = first + rest

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
    )
    findings = await probe_oauth_pkce_downgrade(ctx)
    assert findings == []


def test_oauth_pkce_downgrade_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import oauth_pkce_downgrade

    importlib.reload(oauth_pkce_downgrade)

    spec = registry.get("web.oauth_pkce_downgrade")
    assert spec is not None
    assert spec.bug_class == "auth_bypass"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is True
    assert "oauth" in spec.tags
