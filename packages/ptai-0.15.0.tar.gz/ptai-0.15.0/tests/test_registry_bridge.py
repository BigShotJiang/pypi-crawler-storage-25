"""Tests for registry_bridge: turns ProbeSpec into agent-loop handlers.

The bridge is the gateway between the probe registry and the agent loop.
For each registered probe, it auto-creates a handler that:
  1. Builds a ProbeContext from WorkingMemory + provided args
  2. Calls the probe function
  3. Translates findings into FindingRefs
  4. Marks coverage on the (endpoint, bug-class) pair
  5. Returns an Observation
"""
from __future__ import annotations

from unittest.mock import patch

import pytest


@pytest.fixture
def fresh_registry():
    """Each test gets an empty registry."""
    from engine.probes import registry

    registry.clear()
    yield registry
    registry.clear()


@pytest.fixture
def fresh_memory():
    from engine.working_memory import WorkingMemory

    return WorkingMemory(
        engagement_id="test-eng-1",
        target="http://localhost:3000",
    )


@pytest.mark.asyncio
async def test_bridge_runs_probe_and_returns_observation(fresh_registry, fresh_memory):
    """Bridge invokes the probe function and reports success."""
    from engine.agents.handlers.registry_bridge import make_handler_for_spec

    @fresh_registry.probe(
        name="test.fast", bug_class="cors_misconfig", severity_max="medium"
    )
    async def fake_probe(ctx):
        return [
            {
                "title": "CORS reflection on /api/me",
                "severity": "high",
                "category": "misconfiguration",
                "target": "http://localhost:3000/api/me",
                "evidence": "Origin reflected",
            }
        ]

    spec = fresh_registry.get("test.fast")
    handler = make_handler_for_spec(spec)

    with patch("engine.agents.handlers.registry_bridge.aiohttp.ClientSession"):
        obs = await handler(fresh_memory, {})

    assert obs.success is True
    assert obs.action_name == "probe.test.fast"
    assert obs.findings_added == 1


@pytest.mark.asyncio
async def test_bridge_translates_findings_into_workmemory(fresh_registry, fresh_memory):
    from engine.agents.handlers.registry_bridge import make_handler_for_spec

    @fresh_registry.probe(name="test.idor", bug_class="idor", severity_max="high")
    async def fake_probe(ctx):
        return [
            {
                "id": "f-1",
                "title": "IDOR on /api/users/2",
                "severity": "high",
                "category": "authorization",
                "target": "http://localhost:3000/api/users/2",
            }
        ]

    spec = fresh_registry.get("test.idor")
    handler = make_handler_for_spec(spec)

    with patch("engine.agents.handlers.registry_bridge.aiohttp.ClientSession"):
        await handler(fresh_memory, {})

    assert len(fresh_memory.findings) == 1
    fr = fresh_memory.findings[0]
    assert fr.bug_class == "idor"
    assert fr.severity == "high"
    assert fr.target == "http://localhost:3000/api/users/2"


@pytest.mark.asyncio
async def test_bridge_marks_coverage_on_findings(fresh_registry, fresh_memory):
    from engine.agents.handlers.registry_bridge import make_handler_for_spec
    from engine.working_memory import EndpointKey

    @fresh_registry.probe(name="test.cors", bug_class="cors_misconfig", severity_max="high")
    async def fake_probe(ctx):
        return [
            {
                "title": "CORS reflection",
                "severity": "high",
                "target": "http://localhost:3000/api/me",
            }
        ]

    handler = make_handler_for_spec(fresh_registry.get("test.cors"))
    with patch("engine.agents.handlers.registry_bridge.aiohttp.ClientSession"):
        await handler(fresh_memory, {})

    assert fresh_memory.coverage.has_tried(
        EndpointKey("GET", "/api/me"), "cors_misconfig"
    )


@pytest.mark.asyncio
async def test_bridge_handles_probe_exception(fresh_registry, fresh_memory):
    from engine.agents.handlers.registry_bridge import make_handler_for_spec

    @fresh_registry.probe(name="test.boom", bug_class="sqli", severity_max="critical")
    async def fake_probe(ctx):
        raise RuntimeError("network is on fire")

    handler = make_handler_for_spec(fresh_registry.get("test.boom"))
    with patch("engine.agents.handlers.registry_bridge.aiohttp.ClientSession"):
        obs = await handler(fresh_memory, {})

    assert obs.success is False
    assert obs.error is not None
    assert "network is on fire" in obs.error


@pytest.mark.asyncio
async def test_bridge_passes_captured_auth_when_required(fresh_registry, fresh_memory):
    """Probes with requires_auth=True should receive captured_auth via ctx."""
    from engine.agents.handlers.registry_bridge import make_handler_for_spec

    received_auth = {}

    @fresh_registry.probe(
        name="test.auth", bug_class="idor", severity_max="high", requires_auth=True
    )
    async def fake_probe(ctx):
        received_auth["auth"] = ctx.captured_auth
        return []

    from engine.working_memory import CapturedAuth

    handler = make_handler_for_spec(fresh_registry.get("test.auth"))
    fresh_memory.add_auth(
        CapturedAuth(
            kind="jwt",
            value="fake-jwt",
            source_endpoint="/rest/user/login",
            captured_at="2026-05-07T18:00:00Z",
            role_hint="admin",
        )
    )

    with patch("engine.agents.handlers.registry_bridge.aiohttp.ClientSession"):
        await handler(fresh_memory, {})

    assert received_auth["auth"] is not None
    assert received_auth["auth"]["token"] == "fake-jwt"
    assert received_auth["auth"]["kind"] == "jwt"
    assert received_auth["auth"]["role_hint"] == "admin"


def test_register_all_probes_registers_action_handlers(fresh_registry):
    """Importing a probe module + calling register_all_probes() wires every
    probe into the agent loop's handler registry."""
    from engine.agent_loop import _HANDLERS  # type: ignore[import-untyped]
    from engine.agents.handlers.registry_bridge import register_all_probes

    @fresh_registry.probe(name="test.a", bug_class="sqli", severity_max="critical")
    async def a(ctx):
        return []

    @fresh_registry.probe(name="test.b", bug_class="xss_reflected", severity_max="high")
    async def b(ctx):
        return []

    # save handlers existing before
    before = set(_HANDLERS.keys())
    register_all_probes()
    after = set(_HANDLERS.keys())

    new = after - before
    assert "probe.test.a" in new
    assert "probe.test.b" in new
