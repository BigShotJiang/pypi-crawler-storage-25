"""Tests for the GraphQL introspection + field-suggestion probe.

Catches three info-disclosure failure modes on GraphQL endpoints:
introspection enabled, did-you-mean field suggestions, and mutation
argument disclosure via error messages. All three leak the schema
shape without ever needing auth.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_introspection_enabled_emits_medium_finding(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.graphql_introspection import probe_graphql_introspection

    # Discovery GET returns 200 (GraphiQL playground served).
    fake_session.get.return_value = _make_response(200, "GraphiQL")
    # POST 1: introspection responds with __schema body.
    # POST 2: suggestion query, no "Did you mean" leak.
    # POST 3: mutation login, no helpful error.
    fake_session.post.side_effect = [
        _make_response(
            200,
            '{"data":{"__schema":{"types":[{"name":"User"},{"name":"Query"}]}}}',
        ),
        _make_response(200, '{"errors":[{"message":"unknown field"}]}'),
        _make_response(200, '{"errors":[{"message":"unauthorized"}]}'),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/graphql",),
    )

    findings = await probe_graphql_introspection(ctx)

    medium = [f for f in findings if f["severity"] == "medium"]
    assert len(medium) == 1
    assert medium[0]["bug_class"] == "exposed_dev"
    assert "introspection" in medium[0]["title"].lower()
    assert medium[0]["target"].endswith("/graphql")


@pytest.mark.asyncio
async def test_field_suggestions_emit_low_finding(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.graphql_introspection import probe_graphql_introspection

    fake_session.get.return_value = _make_response(400, "no query")
    fake_session.post.side_effect = [
        # No introspection.
        _make_response(400, '{"errors":[{"message":"introspection disabled"}]}'),
        # Suggestion leaks: server names a real field.
        _make_response(
            200,
            '{"errors":[{"message":"Cannot query field \\"XYZ_invalid_field_canary'
            '\\" on type \\"Query\\". Did you mean \\"users\\" or \\"posts\\"?"}]}',
        ),
        # No mutation hint.
        _make_response(200, '{"errors":[{"message":"unauthorized"}]}'),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/graphql",),
    )

    findings = await probe_graphql_introspection(ctx)

    low_suggest = [f for f in findings if "suggestions" in f["title"].lower()]
    assert len(low_suggest) == 1
    assert low_suggest[0]["severity"] == "low"
    assert low_suggest[0]["bug_class"] == "exposed_dev"


@pytest.mark.asyncio
async def test_mutation_surface_emits_low_finding(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.graphql_introspection import probe_graphql_introspection

    fake_session.get.return_value = _make_response(400, "no query")
    fake_session.post.side_effect = [
        _make_response(400, '{"errors":[{"message":"introspection disabled"}]}'),
        _make_response(200, '{"errors":[{"message":"unknown field"}]}'),
        _make_response(
            200,
            '{"errors":[{"message":"Field \\"login\\" argument \\"username\\" '
            'of type \\"String!\\" is required but not provided."}]}',
        ),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/graphql",),
    )

    findings = await probe_graphql_introspection(ctx)

    mutation = [f for f in findings if "mutation" in f["title"].lower()]
    assert len(mutation) == 1
    assert mutation[0]["severity"] == "low"
    assert mutation[0]["bug_class"] == "exposed_dev"


@pytest.mark.asyncio
async def test_no_findings_when_graphql_endpoint_missing(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.graphql_introspection import probe_graphql_introspection

    # 404 means no GraphQL endpoint discovered; probe should never POST.
    fake_session.get.return_value = _make_response(404, "not found")
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/graphql",),
    )

    findings = await probe_graphql_introspection(ctx)
    assert findings == []
    fake_session.post.assert_not_called()


@pytest.mark.asyncio
async def test_all_three_findings_emitted_on_one_endpoint(fake_session):
    """Single probe run can emit medium + low + low on the same URL."""
    from engine.probes import ProbeContext
    from engine.probes.web.graphql_introspection import probe_graphql_introspection

    fake_session.get.return_value = _make_response(200, "GraphiQL")
    fake_session.post.side_effect = [
        _make_response(
            200, '{"data":{"__schema":{"types":[{"name":"User"}]}}}'
        ),
        _make_response(
            200,
            '{"errors":[{"message":"Cannot query field. Did you mean \\"users\\"?"}]}',
        ),
        _make_response(
            200,
            '{"errors":[{"message":"Field \\"login\\" argument \\"input\\" '
            'of type \\"LoginInput!\\" is required."}]}',
        ),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/graphql",),
    )

    findings = await probe_graphql_introspection(ctx)
    severities = sorted(f["severity"] for f in findings)
    assert severities == ["low", "low", "medium"]


def test_graphql_introspection_is_registered():
    from engine.probes import registry
    from engine.probes.web import graphql_introspection  # noqa: F401

    spec = registry.get("web.graphql_introspection")
    assert spec is not None
    assert spec.bug_class == "exposed_dev"
    assert spec.severity_max == "medium"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 8.0
    assert "graphql" in spec.tags
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert spec.owasp == "A05:2021"
