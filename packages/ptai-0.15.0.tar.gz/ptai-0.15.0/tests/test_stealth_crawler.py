"""Tests for engine.probes.recon.stealth_crawler.

Scrapling is an optional dep gated behind `pip install ptai[stealth]`.
These tests must pass on a base install too. Strategy: register a fake
`scrapling.fetchers` module in sys.modules before importing the
stealth_crawler functions that touch it.
"""
from __future__ import annotations

import sys
import types
from unittest.mock import AsyncMock, MagicMock

import pytest

from engine.probes.recon.stealth_crawler import (
    _extract_xhr_path,
    is_available,
    run_stealth_crawler,
)

# --------------------------------------------------------------------- helpers


def _install_fake_scrapling(fetcher_mock):
    """Inject a fake scrapling.fetchers module into sys.modules.

    Returns a teardown callable.
    """
    fake_pkg = types.ModuleType("scrapling")
    fake_fetchers = types.ModuleType("scrapling.fetchers")
    fake_fetchers.StealthyFetcher = fetcher_mock
    sys.modules["scrapling"] = fake_pkg
    sys.modules["scrapling.fetchers"] = fake_fetchers

    def _teardown():
        sys.modules.pop("scrapling.fetchers", None)
        sys.modules.pop("scrapling", None)

    return _teardown


# --------------------------------------------------------------------- is_available


def test_is_available_false_when_missing(monkeypatch):
    monkeypatch.delitem(sys.modules, "scrapling", raising=False)

    real_import = __builtins__["__import__"] if isinstance(__builtins__, dict) else __builtins__.__import__

    def _fail_on_scrapling(name, *args, **kwargs):
        if name == "scrapling" or name.startswith("scrapling."):
            raise ImportError("forced")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", _fail_on_scrapling)
    assert is_available() is False


def test_is_available_true_when_present():
    teardown = _install_fake_scrapling(MagicMock())
    try:
        assert is_available() is True
    finally:
        teardown()


# --------------------------------------------------------------------- _extract_xhr_path


def test_extract_xhr_path_accepts_string():
    assert _extract_xhr_path("juice-shop.local", "http://juice-shop.local/api/users") == "/api/users"


def test_extract_xhr_path_accepts_dict():
    entry = {"url": "http://juice-shop.local/rest/products?id=1"}
    assert _extract_xhr_path("juice-shop.local", entry) == "/rest/products?id=1"


def test_extract_xhr_path_accepts_object_attr():
    entry = MagicMock()
    entry.url = "http://juice-shop.local/v3/items"
    assert _extract_xhr_path("juice-shop.local", entry) == "/v3/items"


def test_extract_xhr_path_filters_cross_origin():
    assert _extract_xhr_path("juice-shop.local", "http://cdn.example.com/api/x") is None


def test_extract_xhr_path_keeps_relative_when_netloc_empty():
    assert _extract_xhr_path("juice-shop.local", "/api/local-only") == "/api/local-only"


def test_extract_xhr_path_handles_unparseable():
    assert _extract_xhr_path("juice-shop.local", None) is None
    assert _extract_xhr_path("juice-shop.local", "") is None
    assert _extract_xhr_path("juice-shop.local", 123) is None


# --------------------------------------------------------------------- run_stealth_crawler


@pytest.mark.asyncio
async def test_run_stealth_crawler_raises_when_scrapling_missing(monkeypatch):
    monkeypatch.delitem(sys.modules, "scrapling", raising=False)
    monkeypatch.delitem(sys.modules, "scrapling.fetchers", raising=False)

    real_import = __builtins__["__import__"] if isinstance(__builtins__, dict) else __builtins__.__import__

    def _fail_on_scrapling(name, *args, **kwargs):
        if name == "scrapling" or name.startswith("scrapling."):
            raise ImportError("forced")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", _fail_on_scrapling)
    with pytest.raises(ImportError, match="scrapling is required"):
        await run_stealth_crawler("http://juice-shop.local")


@pytest.mark.asyncio
async def test_run_stealth_crawler_merges_html_and_xhr():
    fake_page = MagicMock()
    fake_page.body = (
        "<html><body><a href='/login'>Login</a>"
        "<form action='/checkout' method='POST'></form></body></html>"
    )
    fake_page.captured_xhr = [
        {"url": "http://juice-shop.local/api/users"},
        {"url": "http://juice-shop.local/rest/products"},
        {"url": "http://cdn.example.com/api/external"},  # cross-origin, dropped
        {"url": "http://juice-shop.local/static/foo.png"},  # not an api path, dropped
    ]
    fetcher = MagicMock()
    fetcher.async_fetch = AsyncMock(return_value=fake_page)

    teardown = _install_fake_scrapling(fetcher)
    try:
        result = await run_stealth_crawler("http://juice-shop.local")
    finally:
        teardown()

    assert "/login" in result.discovered_paths
    assert "/checkout" in result.discovered_paths
    assert "/api/users" in result.api_paths
    assert "/rest/products" in result.api_paths
    assert "/api/external" not in result.api_paths
    assert "/static/foo.png" not in result.api_paths


@pytest.mark.asyncio
async def test_run_stealth_crawler_returns_empty_on_fetch_exception():
    fetcher = MagicMock()
    fetcher.async_fetch = AsyncMock(side_effect=RuntimeError("playwright crashed"))

    teardown = _install_fake_scrapling(fetcher)
    try:
        result = await run_stealth_crawler("http://juice-shop.local")
    finally:
        teardown()

    assert result.discovered_paths == set()
    assert result.api_paths == set()


@pytest.mark.asyncio
async def test_run_stealth_crawler_handles_none_page():
    fetcher = MagicMock()
    fetcher.async_fetch = AsyncMock(return_value=None)

    teardown = _install_fake_scrapling(fetcher)
    try:
        result = await run_stealth_crawler("http://juice-shop.local")
    finally:
        teardown()

    assert result.discovered_paths == set()
    assert result.api_paths == set()


@pytest.mark.asyncio
async def test_run_stealth_crawler_decodes_bytes_body():
    fake_page = MagicMock()
    fake_page.body = b"<html><body><a href='/x'>x</a></body></html>"
    fake_page.captured_xhr = []
    fetcher = MagicMock()
    fetcher.async_fetch = AsyncMock(return_value=fake_page)

    teardown = _install_fake_scrapling(fetcher)
    try:
        result = await run_stealth_crawler("http://juice-shop.local")
    finally:
        teardown()

    assert "/x" in result.discovered_paths


@pytest.mark.asyncio
async def test_run_stealth_crawler_passes_correct_kwargs():
    fake_page = MagicMock()
    fake_page.body = ""
    fake_page.captured_xhr = []
    fetcher = MagicMock()
    fetcher.async_fetch = AsyncMock(return_value=fake_page)

    teardown = _install_fake_scrapling(fetcher)
    try:
        await run_stealth_crawler("http://juice-shop.local", solve_cloudflare=False, headless=False)
    finally:
        teardown()

    fetcher.async_fetch.assert_awaited_once()
    call_kwargs = fetcher.async_fetch.call_args.kwargs
    assert call_kwargs["solve_cloudflare"] is False
    assert call_kwargs["headless"] is False
    assert call_kwargs["block_webrtc"] is True
    assert call_kwargs["network_idle"] is True
    assert call_kwargs["block_ads"] is True
    assert "capture_xhr" in call_kwargs
