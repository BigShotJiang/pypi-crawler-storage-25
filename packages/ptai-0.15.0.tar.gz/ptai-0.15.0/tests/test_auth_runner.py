"""Tests for the authenticated probe runner foundation.

Covers signup-then-login, signup-includes-token, login-only, total
failure, generated-email uniqueness, and the auth_headers helper.

Mocks aiohttp sessions with the same _make_response pattern used by
tests/test_probe_cors_reflection.py.
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_juice_shop_style_signup_then_login_returns_token(fake_session):
    """Juice Shop pattern: signup creates user (no token), login returns
    token nested under authentication.token."""
    from engine.probes.auth import acquire_test_auth

    # Signup returns the user record but no token field.
    signup_resp = _make_response(
        201, json.dumps({"data": {"id": 42, "email": "x@x"}})
    )
    fake_session.post.side_effect = [
        signup_resp,
        _make_response(
            200,
            json.dumps(
                {"authentication": {"token": "JUICE.JWT.TOKEN", "umail": "x@x"}}
            ),
        ),
    ]
    # whoami verification with the bearer token.
    fake_session.get.return_value = _make_response(200, "{}")

    auth = await acquire_test_auth(fake_session, "http://localhost:3000")

    assert auth is not None
    assert auth["token"] == "JUICE.JWT.TOKEN"
    assert auth["auth_header"] == "Authorization"
    assert auth["auth_value"] == "Bearer JUICE.JWT.TOKEN"


@pytest.mark.asyncio
async def test_signup_includes_token_skips_login(fake_session):
    """Some apps return both user + token from a single signup call."""
    from engine.probes.auth import acquire_test_auth

    fake_session.post.return_value = _make_response(
        201, json.dumps({"id": 7, "access_token": "ONESHOT.TOKEN"})
    )
    fake_session.get.return_value = _make_response(200, "{}")

    auth = await acquire_test_auth(fake_session, "http://example.com")

    assert auth is not None
    assert auth["token"] == "ONESHOT.TOKEN"
    assert auth["user_id"] == 7
    # Login path should not have been called: only one POST total.
    assert fake_session.post.call_count == 1


@pytest.mark.asyncio
async def test_login_only_when_signup_blocked_and_creds_provided(fake_session):
    """Admin-restricted signup. Caller passes existing creds; runner
    skips signup entirely and goes straight to login."""
    from engine.probes.auth import acquire_test_auth

    fake_session.post.return_value = _make_response(
        200, json.dumps({"token": "LOGIN.ONLY.TOKEN"})
    )
    fake_session.get.return_value = _make_response(200, "{}")

    auth = await acquire_test_auth(
        fake_session,
        "http://example.com",
        email="admin@example.com",
        password="hunter2",
    )

    assert auth is not None
    assert auth["token"] == "LOGIN.ONLY.TOKEN"
    assert auth["email"] == "admin@example.com"
    # Each call to session.post should target a login path, not signup.
    for call in fake_session.post.call_args_list:
        url = call.args[0] if call.args else call.kwargs.get("url", "")
        assert "register" not in url and "/api/Users" not in url


@pytest.mark.asyncio
async def test_returns_none_when_every_endpoint_404s(fake_session):
    from engine.probes.auth import acquire_test_auth

    fake_session.post.return_value = _make_response(404, "")
    fake_session.get.return_value = _make_response(404, "")

    auth = await acquire_test_auth(fake_session, "http://nothing.example")

    assert auth is None


@pytest.mark.asyncio
async def test_generated_email_is_unique_per_call(fake_session):
    """Two independent invocations should produce distinct throwaway
    emails so we don't collide on a target's user table."""
    from engine.probes.auth import acquire_test_auth

    # Successful signup-with-token on every call so we can read back
    # the email the runner picked.
    fake_session.post.return_value = _make_response(
        201, json.dumps({"id": 1, "token": "T"})
    )
    fake_session.get.return_value = _make_response(200, "{}")

    a = await acquire_test_auth(fake_session, "http://x.example")
    b = await acquire_test_auth(fake_session, "http://x.example")

    assert a is not None and b is not None
    assert a["email"] != b["email"]


def test_auth_headers_renders_bearer_and_handles_none():
    from engine.probes.auth import auth_headers

    assert auth_headers(None) == {}
    assert auth_headers({}) == {}
    rendered = auth_headers(
        {"auth_header": "Authorization", "auth_value": "Bearer XYZ"}
    )
    assert rendered == {"Authorization": "Bearer XYZ"}
    # Token-only dict should still produce a Bearer header.
    fallback = auth_headers({"token": "ABC"})
    assert fallback == {"Authorization": "Bearer ABC"}
