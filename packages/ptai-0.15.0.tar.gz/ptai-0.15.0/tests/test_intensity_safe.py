"""Tests for the opt-in intensity="safe" mode.

Safe mode skips probes tagged destructive-low so an engagement against a
bug-bounty / CTF target cannot mutate state via stored XSS, mass
assignment, race conditions, file uploads, etc.

Default behavior (intensity in {stealth, normal, aggressive}) is
unchanged — every existing probe still fires.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


@pytest.fixture(autouse=True)
def _ensure_probes_loaded():
    """Trigger @registry.probe decorators across every probe module."""
    import engine.probes.web  # noqa: F401


# ---------- registry.all / filter exclude_tags ----------


def test_registry_all_default_returns_every_probe():
    from engine.probes import registry
    assert len(registry.all()) >= 60


def test_registry_all_exclude_destructive_drops_tagged_probes():
    from engine.probes import registry
    full = registry.all()
    safe = registry.all(exclude_tags=("destructive-low",))
    assert len(safe) < len(full), "exclude_tags should drop at least one probe"
    for spec in safe:
        assert "destructive-low" not in spec.tags


def test_registry_filter_accepts_exclude_tags():
    from engine.probes import registry
    full = registry.filter(bug_class="ssti")
    safe = registry.filter(bug_class="ssti", exclude_tags=("destructive-low",))
    assert len(safe) <= len(full)
    for spec in safe:
        assert "destructive-low" not in spec.tags


# ---------- orchestrator.set_intensity ----------


@pytest.mark.asyncio
async def test_set_intensity_accepts_safe():
    """`safe` is a valid intensity value alongside stealth/normal/aggressive."""
    from engine.orchestrator import AgentOrchestrator
    db = MagicMock()
    db.update_engagement_intensity = AsyncMock()
    orch = AgentOrchestrator(db=db, llm=None, scope=None)
    await orch.set_intensity("eng-1", "safe")
    db.update_engagement_intensity.assert_awaited_once_with("eng-1", "safe")


@pytest.mark.asyncio
async def test_set_intensity_rejects_unknown_values():
    from engine.orchestrator import AgentOrchestrator
    db = MagicMock()
    db.update_engagement_intensity = AsyncMock()
    orch = AgentOrchestrator(db=db, llm=None, scope=None)
    with pytest.raises(ValueError):
        await orch.set_intensity("eng-1", "completely-bogus")


# ---------- ScanProfile.from_intensity ----------


def test_scan_profile_safe_uses_throttled_settings():
    """Safe maps to the same throttle as stealth: 2 rps, 1 concurrent."""
    from engine.rate_limiter import ScanProfile
    p = ScanProfile.from_intensity("safe")
    assert p.requests_per_second == 2.0
    assert p.max_concurrent_tools == 1


# ---------- MCP run_probe gate ----------


@pytest.mark.asyncio
async def test_run_probe_blocks_destructive_when_engagement_intensity_is_safe():
    """When the engagement was started with intensity="safe", run_probe
    refuses to invoke a destructive-low probe and returns a structured
    error explaining how to override."""
    from mcp_server import probes as mp
    from mcp_server import server as srv

    # Real registered destructive probe — pick one with the tag.
    target_probe = "web.stored_xss"

    fake_db = MagicMock()
    fake_db.get_engagement = AsyncMock(return_value={"id": "eng-safe", "intensity": "safe"})
    srv.findings_db = fake_db

    result = await mp.run_probe(
        probe_name=target_probe,
        target="http://example.test",
        engagement_id="eng-safe",
    )

    assert "error" in result
    assert "intensity=safe" in result["error"]
    assert result["probe"] == target_probe
    srv.findings_db = None


@pytest.mark.asyncio
async def test_run_probe_allows_destructive_when_intensity_is_normal():
    """Default intensity (normal) lets destructive probes run as before.
    We don't actually execute the probe — we assert the safe-mode block
    isn't tripped by checking the response has no 'intensity=safe' error.
    """
    from mcp_server import probes as mp
    from mcp_server import server as srv

    fake_db = MagicMock()
    fake_db.get_engagement = AsyncMock(return_value={"id": "eng-x", "intensity": "normal"})
    srv.findings_db = fake_db

    # An unauth-required destructive probe so we don't trip the requires_auth
    # guard. web.race_condition is unauth in the registry.
    result = await mp.run_probe(
        probe_name="web.race_condition",
        target="http://example.test",
        engagement_id="eng-x",
    )

    # We expect either findings, a 0-finding response, or a non-safe-related
    # error — but specifically NOT the safe-mode block message.
    safe_block = isinstance(result, dict) and "intensity=safe" in (result.get("error") or "")
    assert not safe_block, f"safe block tripped on normal intensity: {result}"
    srv.findings_db = None


# ---------- web_agent registry sweep ----------


@pytest.mark.asyncio
async def test_web_agent_excludes_destructive_when_intensity_safe(monkeypatch):
    """When engagement.intensity == "safe", WebAgent's registry pass calls
    registry.all(exclude_tags=("destructive-low",)) so destructive probes
    don't run during the bulk sweep either."""
    from agents.web.web_agent import WebAgent

    db = MagicMock()
    db.get_engagement = AsyncMock(return_value={"id": "eng-s", "intensity": "safe"})
    registry_mock = MagicMock()
    agent = WebAgent(registry_mock, db, llm=None, scope=None)

    # Capture the exclude_tags arg passed to registry.all()
    captured: dict = {}

    def fake_all(**kwargs):
        captured["exclude_tags"] = kwargs.get("exclude_tags", ())
        return []

    import engine.probes.registry as reg
    monkeypatch.setattr(reg, "all", fake_all)

    result = await agent._run_registry_probes(
        "http://example.test", engagement_id="eng-s", js_urls=[]
    )
    assert result == []
    assert captured["exclude_tags"] == ("destructive-low",)


@pytest.mark.asyncio
async def test_web_agent_no_exclusion_when_intensity_normal(monkeypatch):
    """Default intensity preserves today's call: registry.all() with no
    exclude_tags argument."""
    from agents.web.web_agent import WebAgent

    db = MagicMock()
    db.get_engagement = AsyncMock(return_value={"id": "eng-n", "intensity": "normal"})
    registry_mock = MagicMock()
    agent = WebAgent(registry_mock, db, llm=None, scope=None)

    captured: dict = {}

    def fake_all(**kwargs):
        captured["exclude_tags"] = kwargs.get("exclude_tags", ())
        return []

    import engine.probes.registry as reg
    monkeypatch.setattr(reg, "all", fake_all)

    result = await agent._run_registry_probes(
        "http://example.test", engagement_id="eng-n", js_urls=[]
    )
    assert result == []
    assert captured["exclude_tags"] == ()
