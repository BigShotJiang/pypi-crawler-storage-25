"""Tests for the extended tool catalog (batch 2: 50+ new tools).

Validates:
- Every spec has valid InstallTier and InstallMethod values.
- Tool names are unique across the whole catalog.
- Each install command is a non-empty tuple consistent with its method.
- Each tool has a non-empty category and est_install_time_s > 0.
- Per-tier counts hit the targets the wizard advertises.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from cli.install_wizard import _parse_skip_list, run_install_wizard
from engine.tool_installer import (
    TOOL_CATALOG,
    InstallMethod,
    InstallTier,
    ToolSpec,
)

# Names of tools from the original (batch 1) catalog. Anything NOT in this set
# is part of the extended batch added in this change.
_BATCH1_NAMES = {
    "nmap", "nikto", "sqlmap", "whatweb", "sslscan", "dnsutils", "whois",
    "curl", "nuclei", "gobuster", "ffuf", "httpx", "subfinder", "naabu",
    "katana", "wafw00f", "dirsearch", "wpscan", "hydra", "john", "hashcat",
    "metasploit", "responder", "crackmapexec", "bloodhound-python", "amass",
    "dalfox", "arjun", "xsstrike", "testssl", "aircrack-ng",
}

EXTENDED: tuple[ToolSpec, ...] = tuple(
    t for t in TOOL_CATALOG if t.name not in _BATCH1_NAMES
)


class TestExtendedCatalog:
    def test_at_least_50_new_tools(self):
        assert len(EXTENDED) >= 50, f"expected >=50 new tools, got {len(EXTENDED)}"

    def test_valid_tier(self):
        for t in EXTENDED:
            assert t.tier in InstallTier

    def test_valid_method(self):
        for t in EXTENDED:
            assert t.method in InstallMethod

    def test_unique_names_across_catalog(self):
        names = [t.name for t in TOOL_CATALOG]
        assert len(names) == len(set(names))

    def test_unique_commands_across_catalog(self):
        commands = [t.command for t in TOOL_CATALOG]
        assert len(commands) == len(set(commands))

    def test_install_cmd_is_non_empty_tuple(self):
        for t in EXTENDED:
            assert isinstance(t.install_cmd, tuple)
            assert len(t.install_cmd) >= 2
            assert all(isinstance(part, str) and part for part in t.install_cmd)

    def test_install_cmd_matches_method(self):
        prefix_for = {
            InstallMethod.APT: "apt-get",
            InstallMethod.GO: "go",
            InstallMethod.PIP: "pip",
            InstallMethod.CARGO: "cargo",
            InstallMethod.SNAP: "snap",
        }
        for t in EXTENDED:
            expected = prefix_for.get(t.method)
            if expected is None:
                # MANUAL specs are free-form; skip.
                continue
            assert t.install_cmd[0] == expected, (
                f"{t.name}: expected install_cmd[0]={expected}, got {t.install_cmd[0]}"
            )

    def test_each_tool_has_category(self):
        for t in EXTENDED:
            assert t.category, f"{t.name} has empty category"

    def test_each_tool_has_positive_install_time(self):
        for t in EXTENDED:
            assert t.est_install_time_s > 0, f"{t.name} est_install_time_s must be > 0"

    def test_categories_cover_expected_domains(self):
        cats = {t.category for t in EXTENDED}
        # At least these high-level domains must show up in the new batch.
        for required in ("cloud", "ad", "web", "recon", "mobile", "binary", "network"):
            assert required in cats, f"missing category: {required}"

    def test_tier_counts(self):
        core_total = sum(1 for t in TOOL_CATALOG if t.tier == InstallTier.CORE)
        rec_total = sum(1 for t in TOOL_CATALOG if t.tier == InstallTier.RECOMMENDED)
        full_total = sum(1 for t in TOOL_CATALOG if t.tier == InstallTier.FULL)

        # Wizard advertises 3 tiers, each meaningful.
        assert core_total >= 9
        assert rec_total >= 15
        assert full_total >= 30
        assert core_total + rec_total + full_total == len(TOOL_CATALOG)


class TestInstallWizardHelpers:
    def test_parse_skip_list_blank(self):
        assert _parse_skip_list("") == ()

    def test_parse_skip_list_spaces(self):
        assert _parse_skip_list(" nmap , metasploit ,john ") == (
            "nmap", "metasploit", "john",
        )

    def test_parse_skip_list_drops_empty_segments(self):
        assert _parse_skip_list("nmap,,john,") == ("nmap", "john")


class TestInstallWizardFlow:
    @patch("cli.install_wizard.install_tier")
    @patch("cli.install_wizard.audit_tools")
    @patch("cli.install_wizard.print_audit")
    def test_quit_returns_none(self, _audit, _print, mock_install):
        inputs = iter(["q"])
        result = run_install_wizard(input_fn=lambda _prompt: next(inputs))
        assert result is None
        mock_install.assert_not_called()

    @patch("cli.install_wizard.install_tier")
    @patch("cli.install_wizard.audit_tools", return_value={
        "installed": [], "missing": [], "total_missing_mb": 0,
        "go_available": False, "pip_available": False,
    })
    @patch("cli.install_wizard.print_audit")
    def test_core_tier_with_skips(self, _print, _audit, mock_install):
        mock_install.return_value = {"installed": 5, "failed": 0, "skipped": 1}
        inputs = iter(["1", "metasploit, john"])
        result = run_install_wizard(input_fn=lambda _prompt: next(inputs))
        assert result == {"installed": 5, "failed": 0, "skipped": 1}
        mock_install.assert_called_once_with(
            InstallTier.CORE, skip_tools=("metasploit", "john")
        )

    @patch("cli.install_wizard.install_tier")
    @patch("cli.install_wizard.audit_tools", return_value={
        "installed": [], "missing": [], "total_missing_mb": 0,
        "go_available": False, "pip_available": False,
    })
    @patch("cli.install_wizard.print_audit")
    def test_unknown_choice_returns_none(self, _print, _audit, mock_install):
        inputs = iter(["banana"])
        result = run_install_wizard(input_fn=lambda _prompt: next(inputs))
        assert result is None
        mock_install.assert_not_called()


@pytest.mark.parametrize("name", [
    "prowler", "trivy", "checkov", "kerbrute", "impacket", "feroxbuster",
    "frida", "objection", "radare2", "pwntools", "masscan", "rustscan",
    "mitmproxy", "playwright", "sslyze", "assetfinder", "findomain",
])
def test_named_tools_present(name: str):
    names = {t.name for t in TOOL_CATALOG}
    assert name in names, f"{name} expected in catalog"
