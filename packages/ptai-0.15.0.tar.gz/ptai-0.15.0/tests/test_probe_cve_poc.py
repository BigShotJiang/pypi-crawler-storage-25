"""Tests for the CVE PoC primitives probe.

The probe runs in two phases: optional manifest leak via /ftp/, then a
table of CVE-specific exploit primitives. Each test wires up the
aiohttp session mock so the probe sees a deterministic sequence of
GET/POST responses.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

# Import at module load so the probe is in the registry snapshot the
# conftest fixture takes at the start of every test. Without this the
# `_isolate_probe_registry` fixture restores a saved registry that
# doesn't include this probe, breaking the registration test on rerun.
from engine.probes.web import cve_poc_primitives as _cve_poc_module  # noqa: F401, E402


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


def _make_session(get_responses, post_responses):
    """Build a MagicMock session that returns successive responses.

    get_responses / post_responses are lists of (status, body) tuples.
    The mock walks them in order and falls back to the last entry when
    exhausted so tests can keep the lists short.
    """
    session = MagicMock()

    g_idx = {"i": 0}
    p_idx = {"i": 0}

    def get_side_effect(*args, **kwargs):
        i = min(g_idx["i"], len(get_responses) - 1)
        g_idx["i"] += 1
        status, body = get_responses[i]
        return _make_response(status, body)

    def post_side_effect(*args, **kwargs):
        i = min(p_idx["i"], len(post_responses) - 1)
        p_idx["i"] += 1
        status, body = post_responses[i]
        return _make_response(status, body)

    session.get.side_effect = get_side_effect
    session.post.side_effect = post_side_effect
    return session


# ---------------------------------------------------------------------------
# 1. Manifest leak shows marsdb 0.6.0; perturbation triggers proto pollution.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_manifest_marsdb_then_proto_pollution_critical():
    from engine.probes import ProbeContext
    from engine.probes.web.cve_poc_primitives import probe_cve_poc_primitives

    manifest_body = (
        '{"name":"juice-shop","version":"15.0.0",'
        '"dependencies":{"marsdb":"0.6.0"}}'
    )
    # GETs in order:
    #   1. /ftp/package.json.bak (manifest hit, 200)
    #   2. follow-up GET /api/me after marsdb POST (canary echoes back)
    get_responses = [
        (200, manifest_body),
        (200, '{"email":"a@b","isAdmin":true}'),
    ]
    # POSTs in order: only marsdb primitive applies, so POST /api/Users/.
    post_responses = [
        (201, '{"id": 99}'),
    ]
    session = _make_session(get_responses, post_responses)
    ctx = ProbeContext(session=session, base="http://localhost:3000")

    findings = await probe_cve_poc_primitives(ctx)
    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "vulnerable_dep"
    assert f["cve"] == "CVE-2017-16028"
    assert f["package"] == "marsdb"
    assert "marsdb" in f["title"].lower()


# ---------------------------------------------------------------------------
# 2. Manifest does NOT leak: probe runs all primitives blindly, captures hits.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_no_manifest_runs_blindly_and_detects_jwt_alg_confusion():
    from engine.probes import ProbeContext
    from engine.probes.web.cve_poc_primitives import probe_cve_poc_primitives

    # All manifest GETs 404 -> empty deps. The fingerprint check then
    # confirms Juice Shop, so the probe runs every primitive blind. The
    # JWT primitive sends GET /rest/user/whoami; we want that one to
    # detect. Other GETs/POSTs return inert bodies so their detect_fns miss.
    #
    # Order of GETs from the probe (blind, all primitives):
    #   manifest paths: 4 x 404
    #   fingerprint /rest/admin/application-configuration -> Juice Shop
    #   marsdb follow-up GET /api/me -> inert
    #   minimist follow-up GET /api/me -> inert
    #   jwt primitive request GET /rest/user/whoami -> hit
    #   sanitize-html follow-up GET /api/Feedbacks/ -> inert
    #   node-serialize follow-up GET /api/me -> inert
    #   redos primitive request GET / -> inert (clean 200 with body)
    #   tough-cookie primitive request GET / -> inert
    #   tough-cookie follow-up GET /api/me -> inert
    get_responses = [
        (404, ""),
        (404, ""),
        (404, ""),
        (404, ""),
        (200, '{"application":{"name":"OWASP Juice Shop"}}'),
        (200, '{"status":"ok"}'),
        (200, '{"status":"ok"}'),
        (200, '{"email":"admin@juice-sh.op","id":1,"role":"admin"}'),
        (200, "[]"),
        (200, '{"status":"ok"}'),
        (200, '<html><body>welcome</body></html>'),
        (200, '<html><body>welcome</body></html>'),
        (200, '{"status":"ok"}'),
    ]
    post_responses = [
        (200, '{"ok": true}'),  # marsdb POST /api/Users/
        (200, '{"ok": true}'),  # minimist POST /api/Users/
        (200, '{"ok": true}'),  # sanitize-html POST /api/Feedbacks/
        (200, '{"ok": true}'),  # node-serialize POST /api/Users/
    ]
    session = _make_session(get_responses, post_responses)
    ctx = ProbeContext(session=session, base="http://localhost:3000")

    findings = await probe_cve_poc_primitives(ctx)
    cves = {f["cve"] for f in findings}
    assert "CVE-2015-9235" in cves
    for f in findings:
        assert f["bug_class"] == "vulnerable_dep"


# ---------------------------------------------------------------------------
# 3. Manifest shows safe versions: no primitive fires.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_manifest_safe_versions_no_findings():
    from engine.probes import ProbeContext
    from engine.probes.web.cve_poc_primitives import probe_cve_poc_primitives

    manifest_body = (
        '{"name":"app","dependencies":{'
        '"marsdb":"99.0.0","minimist":"1.2.8","jsonwebtoken":"9.0.0",'
        '"sanitize-html":"2.10.0","node-serialize":"9.9.9",'
        '"http-cache-semantics":"4.1.1","tough-cookie":"4.1.3"'
        '}}'
    )
    get_responses = [(200, manifest_body)]
    post_responses = [(500, "should-not-be-called")]
    session = _make_session(get_responses, post_responses)
    ctx = ProbeContext(session=session, base="http://localhost:3000")

    findings = await probe_cve_poc_primitives(ctx)
    assert findings == []
    # Probe must NOT issue any POST when no primitive applies.
    assert session.post.call_count == 0


# ---------------------------------------------------------------------------
# 4. Specific CVE detect_fn returns true -> finding emitted.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_sanitize_html_bypass_emits_high_finding():
    from engine.probes import ProbeContext
    from engine.probes.web.cve_poc_primitives import probe_cve_poc_primitives

    manifest_body = (
        '{"name":"app","dependencies":{"sanitize-html":"2.0.0"}}'
    )
    # GETs: manifest hit, then follow-up GET /api/Feedbacks/ that returns
    # the canary plus the unfiltered <script> payload.
    get_responses = [
        (200, manifest_body),
        (
            200,
            '[{"comment":"<img src=x onerror=alert(\'ptai-xss-cve\')>"}]',
        ),
    ]
    post_responses = [(201, '{"id":1}')]
    session = _make_session(get_responses, post_responses)
    ctx = ProbeContext(session=session, base="http://localhost:3000")

    findings = await probe_cve_poc_primitives(ctx)
    assert len(findings) == 1
    f = findings[0]
    assert f["cve"] == "CVE-2021-26539"
    assert f["severity"] == "high"
    assert f["package"] == "sanitize-html"


# ---------------------------------------------------------------------------
# 5. Specific CVE detect_fn returns false -> no finding for that CVE.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_marsdb_request_succeeds_but_canary_missing_no_finding():
    from engine.probes import ProbeContext
    from engine.probes.web.cve_poc_primitives import probe_cve_poc_primitives

    manifest_body = (
        '{"name":"app","dependencies":{"marsdb":"0.5.0"}}'
    )
    # POST is accepted, but the follow-up GET /api/me returns a clean
    # body without isAdmin or polluted canary. detect_fn must return False.
    get_responses = [
        (200, manifest_body),
        (200, '{"email":"a@b","isAdmin":false}'),
    ]
    post_responses = [(201, '{"id": 99}')]
    session = _make_session(get_responses, post_responses)
    ctx = ProbeContext(session=session, base="http://localhost:3000")

    findings = await probe_cve_poc_primitives(ctx)
    assert findings == []


# ---------------------------------------------------------------------------
# 6. Registration metadata test.
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_cve_poc_primitives_works_on_non_juiceshop_target():
    """No manifest, no Juice Shop fingerprint: probe runs only the generic subset.

    With no manifest leak and no Juice Shop fingerprint, the probe must
    NOT blast Juice-Shop-specific primitives (marsdb, node-serialize,
    sanitize-html). It runs the small generic fallback set against a
    target whose responses are all inert and emits zero findings.
    """
    from engine.probes import ProbeContext
    from engine.probes.web.cve_poc_primitives import probe_cve_poc_primitives

    # Every GET returns inert 200 with non-empty body so the redos
    # detector's empty-body sentinel doesn't fire. None of the detect_fns
    # should return True.
    session = MagicMock()
    session.get.side_effect = lambda *a, **k: _make_response(200, '{"ok":true}')
    session.post.side_effect = lambda *a, **k: _make_response(200, '{"ok":true}')

    ctx = ProbeContext(session=session, base="http://example.com")
    findings = await probe_cve_poc_primitives(ctx)
    assert findings == []
    # Make sure we did NOT issue any POST: marsdb/minimist/sanitize-html/
    # node-serialize primitives are not in the generic fallback set.
    assert session.post.call_count == 0


def test_cve_poc_primitives_is_registered():
    from engine.probes import registry
    from engine.probes.web import cve_poc_primitives as _cve_module  # noqa: F401

    spec = registry.get("web.cve_poc_primitives")
    assert spec is not None
    assert spec.bug_class == "vulnerable_dep"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A06:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 20.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "cve" in spec.tags


# ---------------------------------------------------------------------------
# 7. Bonus: primitive table covers at least 5 distinct CVEs across the
#    required exploit families.
# ---------------------------------------------------------------------------


def test_primitive_table_covers_required_families():
    from engine.probes.web.cve_poc_primitives import CVE_PRIMITIVES

    cves = {p["cve"] for p in CVE_PRIMITIVES}
    packages = {p["package"] for p in CVE_PRIMITIVES}
    assert len(cves) >= 5
    # Required families: prototype pollution (marsdb / minimist), JWT alg
    # confusion, sanitize-html bypass, deserialization variant, ReDoS.
    assert {"marsdb", "minimist"} & packages
    assert "jsonwebtoken" in packages
    assert "sanitize-html" in packages
    assert "node-serialize" in packages
    assert "http-cache-semantics" in packages or "tough-cookie" in packages
