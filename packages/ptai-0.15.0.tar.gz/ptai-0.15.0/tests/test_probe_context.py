"""Tests for ProbeContext (engine/probes/context.py).

Probes receive a single ProbeContext argument carrying everything they need:
session, base URL, captured auth, hint inputs from prior probes. The driver
constructs a context once per engagement and passes it to every probe.
"""
from __future__ import annotations

import pytest


def test_probe_context_minimal():
    from engine.probes import ProbeContext

    ctx = ProbeContext(session=object(), base="http://localhost:3000")
    assert ctx.base == "http://localhost:3000"
    assert ctx.captured_auth is None
    assert ctx.endpoint_hints == ()
    assert ctx.js_urls == ()
    assert ctx.candidate_endpoints == ()
    assert ctx.findings_so_far == ()


def test_probe_context_normalizes_base_trailing_slash():
    from engine.probes import ProbeContext

    ctx = ProbeContext(session=object(), base="http://localhost:3000/")
    assert ctx.base == "http://localhost:3000"


def test_probe_context_adds_http_scheme_when_missing():
    from engine.probes import ProbeContext

    ctx = ProbeContext(session=object(), base="localhost:3000")
    assert ctx.base == "http://localhost:3000"


def test_probe_context_with_captured_auth():
    from engine.probes import ProbeContext

    ctx = ProbeContext(
        session=object(),
        base="http://localhost:3000",
        captured_auth={"token": "eyJ.fake.jwt", "user_id": 1},
    )
    assert ctx.captured_auth == {"token": "eyJ.fake.jwt", "user_id": 1}


def test_probe_context_is_frozen():
    from dataclasses import FrozenInstanceError

    from engine.probes import ProbeContext

    ctx = ProbeContext(session=object(), base="http://localhost:3000")
    with pytest.raises(FrozenInstanceError):
        ctx.base = "http://other"  # type: ignore[misc]


def test_probe_context_with_method_returns_new_context():
    """ProbeContext is immutable; with_findings returns a new copy."""
    from engine.probes import ProbeContext

    ctx = ProbeContext(session=object(), base="http://localhost:3000")
    new_ctx = ctx.with_findings([{"id": "f1", "severity": "critical"}])
    assert ctx.findings_so_far == ()
    assert len(new_ctx.findings_so_far) == 1
    assert new_ctx.findings_so_far[0]["id"] == "f1"


def test_probe_context_with_captured_auth_method():
    from engine.probes import ProbeContext

    ctx = ProbeContext(session=object(), base="http://localhost:3000")
    new_ctx = ctx.with_captured_auth({"token": "abc"})
    assert ctx.captured_auth is None
    assert new_ctx.captured_auth == {"token": "abc"}
