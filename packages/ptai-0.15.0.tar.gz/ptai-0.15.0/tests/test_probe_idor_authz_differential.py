"""Tests for the two-user authorization-differential probe.

The probe runs three checks: BOLA-read (GET cross-user records), BOLA-write
(PUT a benign update onto cross-user IDs), and BFLA (POST to admin
endpoints with a non-admin token). The fixtures here force the probe
through specific outcomes by mocking the underlying HTTP primitives.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    s = MagicMock()
    # GET, PUT, POST all need to behave like context-manager factories.
    return s


@pytest.fixture
def auth_a():
    return {
        "token": "x",
        "auth_header": "Authorization",
        "auth_value": "Bearer x",
        "user_id": 1,
    }


@pytest.fixture
def auth_b():
    return {
        "token": "y",
        "auth_header": "Authorization",
        "auth_value": "Bearer y",
        "user_id": 2,
    }


@pytest.mark.asyncio
async def test_returns_empty_when_no_captured_auth(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.idor_authz_differential import (
        probe_idor_authz_differential,
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=None,
    )
    findings = await probe_idor_authz_differential(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_bola_read_flagged_on_cross_user_200(fake_session, auth_a, auth_b):
    """GET /api/orders/1 returns 200 with non-error body: BOLA-read fires."""
    from engine.probes import ProbeContext
    from engine.probes.web import idor_authz_differential as mod
    from engine.probes.web.idor_authz_differential import (
        probe_idor_authz_differential,
    )

    # Build GET responses: first /api/orders/1 returns 200 with order data;
    # remaining GETs 404. PUT and POST all 403.
    get_responses = [_make_response(200, '{"id":1,"owner":"victim"}')]
    get_responses += [_make_response(404, "nope") for _ in range(len(mod._OBJECT_PREFIXES) * len(mod._IDS) - 1)]
    fake_session.get.side_effect = get_responses
    fake_session.put.side_effect = [
        _make_response(403, "forbidden")
        for _ in range(len(mod._OBJECT_PREFIXES) * len(mod._IDS))
    ]
    fake_session.post.side_effect = [
        _make_response(403, "forbidden") for _ in range(len(mod._ADMIN_ENDPOINTS))
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=auth_a,
        extras={"captured_auth_b": auth_b},
    )

    findings = await probe_idor_authz_differential(ctx)
    bola_reads = [f for f in findings if "cross-user read" in f["title"]]
    assert len(bola_reads) == 1
    assert "/api/orders/1" in bola_reads[0]["target"]
    assert bola_reads[0]["severity"] == "critical"
    assert bola_reads[0]["bug_class"] == "idor"


@pytest.mark.asyncio
async def test_bfla_admin_flagged_on_201(fake_session, auth_a, auth_b):
    """POST /api/admin/users returns 201: BFLA fires."""
    from engine.probes import ProbeContext
    from engine.probes.web import idor_authz_differential as mod
    from engine.probes.web.idor_authz_differential import (
        probe_idor_authz_differential,
    )

    fake_session.get.side_effect = [
        _make_response(403, "forbidden")
        for _ in range(len(mod._OBJECT_PREFIXES) * len(mod._IDS))
    ]
    fake_session.put.side_effect = [
        _make_response(403, "forbidden")
        for _ in range(len(mod._OBJECT_PREFIXES) * len(mod._IDS))
    ]
    # First admin endpoint returns 201 with non-error body. Rest 403.
    post_responses = [_make_response(201, '{"id":99,"name":"ptai-canary"}')]
    post_responses += [
        _make_response(403, "forbidden") for _ in range(len(mod._ADMIN_ENDPOINTS) - 1)
    ]
    fake_session.post.side_effect = post_responses

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=auth_a,
        extras={"captured_auth_b": auth_b},
    )

    findings = await probe_idor_authz_differential(ctx)
    bfla = [f for f in findings if "BFLA" in f["title"]]
    assert len(bfla) == 1
    assert "/api/admin/users" in bfla[0]["target"]
    assert bfla[0]["severity"] == "critical"


@pytest.mark.asyncio
async def test_no_findings_when_all_endpoints_reject(fake_session, auth_a, auth_b):
    """Server returns 403 to everything: no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web import idor_authz_differential as mod
    from engine.probes.web.idor_authz_differential import (
        probe_idor_authz_differential,
    )

    fake_session.get.side_effect = [
        _make_response(403, "forbidden")
        for _ in range(len(mod._OBJECT_PREFIXES) * len(mod._IDS))
    ]
    fake_session.put.side_effect = [
        _make_response(403, "forbidden")
        for _ in range(len(mod._OBJECT_PREFIXES) * len(mod._IDS))
    ]
    fake_session.post.side_effect = [
        _make_response(403, "forbidden") for _ in range(len(mod._ADMIN_ENDPOINTS))
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=auth_a,
        extras={"captured_auth_b": auth_b},
    )

    findings = await probe_idor_authz_differential(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_error_body_on_200_does_not_flag(fake_session, auth_a, auth_b):
    """200 response carrying 'unauthorized' string is not a BOLA hit."""
    from engine.probes import ProbeContext
    from engine.probes.web import idor_authz_differential as mod
    from engine.probes.web.idor_authz_differential import (
        probe_idor_authz_differential,
    )

    # All GETs return 200 with a body containing "unauthorized" -> filtered out.
    fake_session.get.side_effect = [
        _make_response(200, '{"error":"unauthorized"}')
        for _ in range(len(mod._OBJECT_PREFIXES) * len(mod._IDS))
    ]
    fake_session.put.side_effect = [
        _make_response(403, "forbidden")
        for _ in range(len(mod._OBJECT_PREFIXES) * len(mod._IDS))
    ]
    fake_session.post.side_effect = [
        _make_response(403, "forbidden") for _ in range(len(mod._ADMIN_ENDPOINTS))
    ]

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=auth_a,
        extras={"captured_auth_b": auth_b},
    )

    findings = await probe_idor_authz_differential(ctx)
    assert findings == []


def test_idor_authz_differential_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import idor_authz_differential

    importlib.reload(idor_authz_differential)

    spec = registry.get("web.idor_authz_differential")
    assert spec is not None
    assert spec.bug_class == "idor"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is True
    assert spec.owasp == "A01:2021"
    assert "differential" in spec.tags
