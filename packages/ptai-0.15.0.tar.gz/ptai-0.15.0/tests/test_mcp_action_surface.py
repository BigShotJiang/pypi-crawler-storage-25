"""Tests for the iterative MCP action surface added in the 2026-05-11
launch sprint: ``list_probes``, ``run_probe``, ``http_request``.

These tools are the contract Claude Code uses to drive a pentest
engagement step-by-step (rather than firing the fire-and-forget
``start_engagement``). Regressions here mean broken iterative driving,
which is the launch story for MCP-native LLM agents.
"""
from __future__ import annotations

import socket

import pytest


@pytest.fixture(autouse=True)
def _reset_mcp_globals():
    import mcp_server.server as srv
    srv.findings_db = None
    srv.orchestrator = None
    srv.tool_registry = None
    yield
    srv.findings_db = None
    srv.orchestrator = None
    srv.tool_registry = None


@pytest.mark.asyncio
async def test_list_probes_returns_all_registered_probes(tmp_path, monkeypatch):
    """list_probes() enumerates every @registry.probe-decorated function."""
    from fastmcp import Client

    import mcp_server.server as srv

    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool("list_probes", {})
    probes = result.data
    assert isinstance(probes, list) and len(probes) > 30, f"expected >30 probes, got {len(probes)}"
    names = {p["name"] for p in probes}
    # A representative sample that has shipped by 0.12.0.
    for must_have in ("web.api_path_discovery", "web.idor_sequential", "web.race_condition",
                      "web.privilege_escalation_patch", "web.xxe_upload"):
        assert must_have in names, f"missing {must_have}"
    sample = probes[0]
    for field in ("name", "bug_class", "severity_max", "requires_auth",
                  "runtime_budget_s", "owasp"):
        assert field in sample, f"missing field {field}: {sample}"


@pytest.mark.asyncio
async def test_list_probes_filters_by_bug_class(tmp_path, monkeypatch):
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool("list_probes", {"bug_class": "idor"})
    probes = result.data
    assert probes, "no idor probes"
    assert all(p["bug_class"] == "idor" for p in probes)


@pytest.mark.asyncio
async def test_list_probes_filters_requires_auth(tmp_path, monkeypatch):
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool("list_probes", {"requires_auth_only": True})
    probes = result.data
    assert probes, "no requires_auth probes"
    assert all(p["requires_auth"] is True for p in probes)


@pytest.mark.asyncio
async def test_run_probe_unknown_returns_error(tmp_path, monkeypatch):
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "run_probe", {"probe_name": "web.does_not_exist", "target": "http://localhost"}
        )
    assert "error" in result.data and "unknown probe" in result.data["error"]


@pytest.mark.asyncio
async def test_run_probe_rejects_invalid_target(tmp_path, monkeypatch):
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "run_probe",
            {"probe_name": "web.api_path_discovery", "target": "http://localhost;ls"},
        )
    assert "error" in result.data, result.data


@pytest.mark.asyncio
async def test_run_probe_requires_auth_without_session_returns_error(tmp_path, monkeypatch):
    """A probe with requires_auth=True must refuse to run when no
    auth_profile is provided. Without this guard the LLM gets silent
    empty findings and can't tell the probe was skipped."""
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        # privilege_escalation_patch is decorated with requires_auth=True
        # so its registry-spec gates at the MCP layer when no auth_profile
        # is provided. Pick any other requires_auth probe if this is ever
        # renamed; list_probes(requires_auth_only=True) enumerates them.
        result = await client.call_tool(
            "run_probe",
            {"probe_name": "web.privilege_escalation_patch", "target": "http://localhost"},
        )
    data = result.data
    assert "error" in data and "requires authentication" in data["error"], data
    assert data["findings_count"] == 0


@pytest.mark.asyncio
async def test_http_request_requires_engagement_id(tmp_path, monkeypatch):
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "http_request",
            {"method": "GET", "url": "http://example.com/", "engagement_id": ""},
        )
    assert "error" in result.data and "engagement_id" in result.data["error"]


@pytest.mark.asyncio
async def test_http_request_blocks_out_of_scope_url(tmp_path, monkeypatch):
    """Scope guard: URL host:port must match engagement target host:port."""
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))

    db = srv.get_findings_db()
    eng = await db.create_engagement(
        target="http://example.com", scope="web", rules_of_engment="", intensity="normal",
    )

    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "http_request",
            {
                "method": "GET",
                "url": "http://attacker.example.net/loot",
                "engagement_id": eng["id"],
            },
        )
    err = result.data.get("error", "")
    assert "out_of_scope" in err, f"expected out_of_scope error, got: {err}"


@pytest.mark.asyncio
async def test_http_request_blocks_destructive_method_by_default(tmp_path, monkeypatch):
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))

    db = srv.get_findings_db()
    eng = await db.create_engagement(
        target="http://example.com", scope="web", rules_of_engment="", intensity="normal",
    )

    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "http_request",
            {
                "method": "DELETE",
                "url": "http://example.com/api/users/1",
                "engagement_id": eng["id"],
            },
        )
    err = result.data.get("error", "")
    assert "allow_destructive" in err, f"expected destructive guard, got: {err}"


@pytest.mark.asyncio
async def test_http_request_blocks_unsupported_method(tmp_path, monkeypatch):
    from fastmcp import Client

    import mcp_server.server as srv
    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))

    db = srv.get_findings_db()
    eng = await db.create_engagement(
        target="http://example.com", scope="web", rules_of_engment="", intensity="normal",
    )

    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "http_request",
            {"method": "BOGUS", "url": "http://example.com/", "engagement_id": eng["id"]},
        )
    assert "error" in result.data and "unsupported" in result.data["error"]


@pytest.mark.asyncio
async def test_http_request_succeeds_in_scope_against_loopback():
    """Spin a tiny aiohttp echo server on a free localhost port and
    drive an actual http_request through MCP. Validates the happy path
    end-to-end: scope ok, method ok, body returned with correct status.
    """
    from aiohttp import web as aweb
    from fastmcp import Client

    import mcp_server.server as srv

    async def _echo(request):
        return aweb.json_response({"ok": True, "path": request.path})

    app = aweb.Application()
    app.router.add_get("/ping", _echo)
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    runner = aweb.AppRunner(app)
    await runner.setup()
    site = aweb.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    target = f"http://127.0.0.1:{port}"

    try:
        db = srv.get_findings_db()
        eng = await db.create_engagement(
            target=target, scope="web", rules_of_engment="", intensity="normal",
        )
        async with Client(srv.mcp) as client:
            r = await client.call_tool(
                "http_request",
                {"method": "GET", "url": f"{target}/ping", "engagement_id": eng["id"]},
            )
        data = r.data
        assert data.get("status") == 200, data
        assert "ok" in data["response_body"]
        assert data["response_bytes_total"] > 0
        assert data["elapsed_ms"] >= 0
    finally:
        if srv.findings_db is not None:
            await srv.findings_db.close()
        await runner.cleanup()
