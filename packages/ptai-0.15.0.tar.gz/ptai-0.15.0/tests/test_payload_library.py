"""Tests for the typed payload library and fuzz() primitive.

Mirrors the `_make_response` mocking pattern from
tests/test_probe_cors_reflection.py and the concurrency-counter pattern
from tests/test_probe_primitives.py::test_walk_paths_caps_concurrency.
"""
from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


# ---------------------------------------------------------------------------
# Payload list shape
# ---------------------------------------------------------------------------
def test_all_payload_lists_non_empty_and_unique():
    from engine.probes.payloads import (
        NOSQL_PAYLOADS,
        OPEN_REDIRECT_PAYLOADS,
        PATH_TRAVERSAL_PAYLOADS,
        SQLI_PAYLOADS,
        SSTI_PAYLOADS,
        XSS_PAYLOADS,
    )

    for name, lst in [
        ("SQLI", SQLI_PAYLOADS),
        ("XSS", XSS_PAYLOADS),
        ("NOSQL", NOSQL_PAYLOADS),
        ("SSTI", SSTI_PAYLOADS),
        ("OPEN_REDIRECT", OPEN_REDIRECT_PAYLOADS),
        ("PATH_TRAVERSAL", PATH_TRAVERSAL_PAYLOADS),
    ]:
        assert len(lst) > 0, f"{name} empty"
        assert len(set(lst)) == len(lst), f"{name} contains duplicates"


def test_payload_minimum_counts():
    """Per spec: SQLI 30+, XSS 25+, NoSQL 15+, SSTI 10+, redirect 15+, traversal 20+."""
    from engine.probes.payloads import (
        NOSQL_PAYLOADS,
        OPEN_REDIRECT_PAYLOADS,
        PATH_TRAVERSAL_PAYLOADS,
        SQLI_PAYLOADS,
        SSTI_PAYLOADS,
        XSS_PAYLOADS,
    )

    assert len(SQLI_PAYLOADS) >= 30
    assert len(XSS_PAYLOADS) >= 25
    assert len(NOSQL_PAYLOADS) >= 15
    assert len(SSTI_PAYLOADS) >= 10
    assert len(OPEN_REDIRECT_PAYLOADS) >= 15
    assert len(PATH_TRAVERSAL_PAYLOADS) >= 20


def test_sqli_covers_union_boolean_and_time_based():
    from engine.probes.payloads import SQLI_PAYLOADS

    blob = " ".join(SQLI_PAYLOADS).upper()
    assert "UNION SELECT" in blob
    # Boolean blind variants
    assert any("AND '1'='1" in p or "AND 1=1" in p or "OR '1'='1" in p for p in SQLI_PAYLOADS)
    # Time-based across MySQL, Postgres, MSSQL
    assert any("SLEEP(5)" in p.upper() for p in SQLI_PAYLOADS)
    assert any("PG_SLEEP(5)" in p.upper() for p in SQLI_PAYLOADS)
    assert any("WAITFOR DELAY" in p.upper() for p in SQLI_PAYLOADS)
    # Comment variations
    assert any("--" in p for p in SQLI_PAYLOADS)
    assert any("#" in p for p in SQLI_PAYLOADS)
    assert any("/**/" in p for p in SQLI_PAYLOADS)


def test_xss_covers_tag_and_handler_variants():
    from engine.probes.payloads import XSS_PAYLOADS

    # Tag-based
    assert any("<script" in p.lower() for p in XSS_PAYLOADS)
    assert any("<svg" in p.lower() for p in XSS_PAYLOADS)
    assert any("<img" in p.lower() for p in XSS_PAYLOADS)
    # Handler-based
    assert any("onerror" in p.lower() for p in XSS_PAYLOADS)
    assert any("onload" in p.lower() for p in XSS_PAYLOADS)
    assert any("onclick" in p.lower() or "onmouseover" in p.lower() for p in XSS_PAYLOADS)
    # javascript: URI
    assert any(p.lower().startswith("javascript:") for p in XSS_PAYLOADS)
    # Encoded variant
    assert any("%3C" in p or "&lt;" in p or "&#60;" in p for p in XSS_PAYLOADS)


def test_nosql_covers_mongo_operators():
    from engine.probes.payloads import NOSQL_PAYLOADS

    blob = " ".join(NOSQL_PAYLOADS)
    assert "$ne" in blob
    assert "$gt" in blob
    assert "$regex" in blob
    assert "$where" in blob


def test_ssti_covers_multiple_engines():
    from engine.probes.payloads import SSTI_PAYLOADS

    blob = " ".join(SSTI_PAYLOADS)
    assert "{{7*7}}" in blob  # Jinja/Twig
    assert "<%=" in blob  # ERB
    # Handlebars / Velocity / FreeMarker present (one of these markers)
    assert any(
        marker in blob
        for marker in ("{{this", "#set(", "freemarker", "{{#with", "{php}")
    )


def test_open_redirect_covers_scheme_confusion_and_data_uri():
    from engine.probes.payloads import OPEN_REDIRECT_PAYLOADS

    blob = " ".join(OPEN_REDIRECT_PAYLOADS)
    assert "//attacker" in blob
    assert "\\\\attacker" in blob
    assert "data:" in blob
    assert "javascript:" in blob


def test_path_traversal_covers_encoded_and_null_byte():
    from engine.probes.payloads import PATH_TRAVERSAL_PAYLOADS

    blob = " ".join(PATH_TRAVERSAL_PAYLOADS)
    assert "../" in blob
    assert "%2f" in blob.lower() or "%2F" in blob
    assert "%00" in blob
    assert "\\" in blob  # backslash variant


# ---------------------------------------------------------------------------
# PAYLOAD_REGISTRY
# ---------------------------------------------------------------------------
def test_payload_registry_maps_sqli_to_sqli_payloads():
    from engine.probes.payloads import PAYLOAD_REGISTRY, SQLI_PAYLOADS

    assert PAYLOAD_REGISTRY["sqli"] is SQLI_PAYLOADS


def test_payload_registry_keys_match_bug_classes():
    from engine.probes.payloads import PAYLOAD_REGISTRY
    from engine.working_memory import BUG_CLASSES

    for key in PAYLOAD_REGISTRY:
        assert key in BUG_CLASSES, f"registry key {key!r} not in BUG_CLASSES"


def test_payload_registry_covers_core_bug_classes():
    from engine.probes.payloads import PAYLOAD_REGISTRY

    for bc in (
        "sqli",
        "xss_reflected",
        "nosql_injection",
        "ssti",
        "open_redirect",
        "path_traversal",
    ):
        assert bc in PAYLOAD_REGISTRY


# ---------------------------------------------------------------------------
# fuzz()
# ---------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_fuzz_invokes_detect_fn_for_each_payload(fake_session):
    from engine.probes.payloads import fuzz

    fake_session.get.return_value = _make_response(200, "OK BODY", {})

    seen_payloads = []

    def detect(status, headers, body, baseline):
        # Detect baseline_body presence; record the call.
        seen_payloads.append((status, body, baseline))
        return body == "OK BODY"

    payloads = ("a", "b", "c")
    results = await fuzz(
        fake_session,
        "http://x/q?x={payload}",
        payloads,
        detect,
    )

    assert len(results) == 3
    # detect_fn invoked once per payload (baseline GET does not invoke detect)
    assert len(seen_payloads) == 3
    assert all(r["hit"] for r in results)
    payload_set = {r["payload"] for r in results}
    assert payload_set == set(payloads)
    # Each row carries metadata
    for r in results:
        assert "status" in r and "body_size" in r and "body_snippet" in r


@pytest.mark.asyncio
async def test_fuzz_aggregates_results_with_mixed_hits(fake_session):
    from engine.probes.payloads import fuzz

    fake_session.get.return_value = _make_response(200, "body", {})

    def detect(status, headers, body, baseline):
        # Hit only on payloads containing "X"
        return False  # overridden via closure below

    captured = []

    def detect_partial(status, headers, body, baseline):
        # Hit when current call number is even
        captured.append(1)
        return len(captured) % 2 == 0

    results = await fuzz(
        fake_session,
        "http://x/q?x={payload}",
        ("p1", "p2", "p3", "p4"),
        detect_partial,
    )
    hits = [r for r in results if r["hit"]]
    assert len(hits) == 2


@pytest.mark.asyncio
async def test_fuzz_requires_payload_placeholder(fake_session):
    from engine.probes.payloads import fuzz

    with pytest.raises(ValueError):
        await fuzz(
            fake_session,
            "http://x/q?x=fixed",  # no {payload}
            ("a",),
            lambda *a: False,
        )


@pytest.mark.asyncio
async def test_fuzz_uses_baseline_url_when_provided():
    from engine.probes.payloads import fuzz

    session = MagicMock()
    calls: list[str] = []

    def get_side_effect(url, *a, **k):
        calls.append(url)
        return _make_response(200, "x", {})

    session.get.side_effect = get_side_effect

    await fuzz(
        session,
        "http://t/path?p={payload}",
        ("a",),
        lambda *a: False,
        baseline_url="http://t/baseline",
    )

    # First call must be the explicit baseline URL.
    assert calls[0] == "http://t/baseline"
    # Subsequent call carries the payload-substituted URL.
    assert "p=a" in calls[1]


@pytest.mark.asyncio
async def test_fuzz_caps_concurrency():
    """concurrency=4 means peak in-flight payload GETs must be <= 4."""
    from engine.probes.payloads import fuzz

    session = MagicMock()
    cm_count = {"in": 0, "peak": 0}

    class CountingCM:
        def __init__(self, is_baseline: bool):
            self.is_baseline = is_baseline

        async def __aenter__(self):
            if not self.is_baseline:
                cm_count["in"] += 1
                cm_count["peak"] = max(cm_count["peak"], cm_count["in"])
            await asyncio.sleep(0.01)
            r = AsyncMock()
            r.status = 200
            r.text = AsyncMock(return_value="body")
            r.headers = {}
            return r

        async def __aexit__(self, *a):
            if not self.is_baseline:
                cm_count["in"] -= 1
            return None

    call_n = {"i": 0}

    def side(url, *a, **k):
        # First call is the baseline GET.
        call_n["i"] += 1
        return CountingCM(is_baseline=(call_n["i"] == 1))

    session.get.side_effect = side

    payloads = tuple(f"p{i}" for i in range(40))
    await fuzz(
        session,
        "http://x/q?x={payload}",
        payloads,
        lambda *a: False,
        concurrency=4,
    )
    assert cm_count["peak"] <= 4, f"peak {cm_count['peak']} exceeded 4"


@pytest.mark.asyncio
async def test_fuzz_url_encodes_payload(fake_session):
    from engine.probes.payloads import fuzz

    fake_session.get.return_value = _make_response(200, "body", {})

    captured: list[str] = []

    def get_side(url, *a, **k):
        captured.append(url)
        return _make_response(200, "body", {})

    fake_session.get.side_effect = get_side

    await fuzz(
        fake_session,
        "http://x/q?p={payload}",
        ("' OR 1=1--",),
        lambda *a: False,
    )

    # Find the payload-substituted call (not the baseline).
    payload_calls = [u for u in captured if "p=" in u and u != "http://x/q?p="]
    assert payload_calls, "no payload call captured"
    encoded = payload_calls[0]
    # Spaces must be encoded; quote/equals must be encoded.
    assert " " not in encoded
    assert "%27" in encoded  # encoded single quote


@pytest.mark.asyncio
async def test_fuzz_swallows_detect_fn_exceptions(fake_session):
    from engine.probes.payloads import fuzz

    fake_session.get.return_value = _make_response(200, "body", {})

    def detect(status, headers, body, baseline):
        raise RuntimeError("boom")

    results = await fuzz(
        fake_session,
        "http://x/q?p={payload}",
        ("a", "b"),
        detect,
    )
    # Errors in detect_fn must not crash the fuzz run; rows come back as hit=False.
    assert len(results) == 2
    assert all(r["hit"] is False for r in results)
