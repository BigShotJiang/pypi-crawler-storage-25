"""Tests verifying the 14 legacy spa_probes register through the new registry.

The legacy probes (agents/web/spa_probes.py) keep their existing call sites
in WebAgent. The registry-side wrappers expose them as agent-loop actions
without rewriting their internals. Once the legacy pipeline is retired,
the wrappers can absorb the original logic in place.
"""
from __future__ import annotations

import pytest


@pytest.fixture
def fresh_registry():
    """Each test starts with a clean registry, restores afterwards.

    We also reload the legacy module so the @probe decorators re-fire on
    each test, since `import` is a no-op for already-cached modules.
    """
    import importlib
    import sys

    from engine.probes import registry

    saved = registry.all()
    registry.clear()

    # Reload legacy so its decorators re-fire (no-op if not previously imported)
    if "engine.probes.web.legacy" in sys.modules:
        importlib.reload(sys.modules["engine.probes.web.legacy"])

    yield registry

    # Teardown: clear what the test added, then restore what was there before
    registry.clear()
    if "engine.probes.web.legacy" in sys.modules:
        del sys.modules["engine.probes.web.legacy"]
        # also drop the attribute on the parent so re-imports work
        web_pkg = sys.modules.get("engine.probes.web")
        if web_pkg is not None and hasattr(web_pkg, "legacy"):
            delattr(web_pkg, "legacy")
    for spec in saved:
        registry._PROBES[spec.name] = spec  # type: ignore[attr-defined]


def test_all_14_legacy_probes_register(fresh_registry):
    from engine.probes.web import legacy  # noqa: F401  - import registers

    expected = {
        "web.open_redirect",
        "web.user_enum",
        "web.unauth_rest_leak",
        "web.search_sqli_get",
        "web.jwt_alg_variants",
        "web.authenticated_pivot",
        "web.jwt_alg_none",
        "web.source_maps",
        "web.directory_listing",
        "web.dev_interfaces",
        "web.login_sqli_bypass",
        "web.role_self_promote",
        "web.ftp_leak",
        "web.nosql_inject",
    }
    actual = {s.name for s in fresh_registry.all()}
    assert expected.issubset(actual), f"missing legacy probes: {expected - actual}"


def test_legacy_jwt_alg_none_carries_correct_metadata(fresh_registry):
    from engine.probes.web import legacy  # noqa: F401

    spec = fresh_registry.get("web.jwt_alg_none")
    assert spec is not None
    assert spec.bug_class == "jwt_alg_none"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is False


def test_legacy_authenticated_pivot_self_captures_auth(fresh_registry):
    """probe_authenticated_pivot self-captures an admin token via the SQLi
    auth bypass, so requires_auth=False. Gating this probe behind caller-
    supplied auth removed 9 high-severity findings from MCP runs (see
    project_juice_shop_benchmark_63_2026_05_09.md)."""
    from engine.probes.web import legacy  # noqa: F401

    spec = fresh_registry.get("web.authenticated_pivot")
    assert spec is not None
    assert spec.requires_auth is False
    assert "high-roi" in spec.tags


def test_legacy_source_maps_carries_correct_metadata(fresh_registry):
    from engine.probes.web import legacy  # noqa: F401

    spec = fresh_registry.get("web.source_maps")
    assert spec.bug_class == "source_map_exposure"
    assert spec.severity_max == "medium"
