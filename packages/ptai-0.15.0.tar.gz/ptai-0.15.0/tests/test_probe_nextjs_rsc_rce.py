"""Tests for the Next.js RSC RCE / deserialization probe.

The probe targets the Server Action dispatcher in the Next.js App Router
(CVE-2025-66478, CVE-2025-55182). It fingerprints Next.js, enumerates
Server Action hashes from build manifests, fires Flight payloads against
candidate routes, and classifies responses by severity.

All HTTP is mocked. No live network.
"""
from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    """aiohttp response context-manager mock used across probe tests."""
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


def _slow_response(status: int, body: str, delay_s: float):
    """Response whose .text() awaits for delay_s before returning."""
    resp = AsyncMock()
    resp.status = status

    async def _slow_text(errors: str = "replace") -> str:
        await asyncio.sleep(delay_s)
        return body

    resp.text = _slow_text
    resp.headers = {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


# --------------------------------------------------------------------- #
# Phase 1: fingerprint
# --------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_non_nextjs_target_skips_cleanly(fake_session):
    """Plain WordPress / static site: no Next.js markers => [] no POSTs."""
    from engine.probes import ProbeContext
    from engine.probes.web.nextjs_rsc_rce import probe_nextjs_rsc_rce

    fake_session.get.return_value = _make_response(
        200,
        "<html><body><h1>Hello WordPress</h1></body></html>",
        {"x-powered-by": "PHP/8.1"},
    )
    fake_session.post = MagicMock(side_effect=AssertionError("must not POST"))

    ctx = ProbeContext(session=fake_session, base="http://example.com")
    findings = await probe_nextjs_rsc_rce(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_nextjs_fingerprint_no_actions_no_findings(fake_session):
    """Next.js detected but every Flight POST returns benign 200; 0 findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.nextjs_rsc_rce import probe_nextjs_rsc_rce

    fake_session.get.return_value = _make_response(
        200,
        '<script>self.__next_f.push([1,""])</script>'
        '<script src="/_next/static/chunks/app/page.js"></script>',
    )
    # Every POST: 200 with body that has no critical/high/medium markers.
    fake_session.post.return_value = _make_response(200, '{"ok":true}')

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_nextjs_rsc_rce(ctx)
    assert findings == []


# --------------------------------------------------------------------- #
# Phase 4: severity classification
# --------------------------------------------------------------------- #


@pytest.mark.asyncio
async def test_critical_when_process_versions_leaked(fake_session):
    """200 response with Node version string -> CRITICAL (RCE w/ exfil)."""
    from engine.probes import ProbeContext
    from engine.probes.web.nextjs_rsc_rce import probe_nextjs_rsc_rce

    fake_session.get.return_value = _make_response(
        200,
        '<script id="__NEXT_DATA__" type="application/json">{}</script>',
        {"x-powered-by": "Next.js"},
    )
    fake_session.post.return_value = _make_response(
        200,
        '{"node":"node-v20.11.0","platform":"linux","arch":"x64"}',
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_nextjs_rsc_rce(ctx)

    assert findings, "expected at least one finding"
    assert any(f["severity"] == "critical" for f in findings)
    f = findings[0]
    assert f["bug_class"] == "rce_deserialization"
    assert f["category"] == "injection"
    assert "Next.js RSC RCE" in f["title"]


@pytest.mark.asyncio
async def test_medium_when_500_with_react_server_dom_webpack_stack(fake_session):
    """500 + react-server-dom-webpack stack => MEDIUM (parser reachable)."""
    from engine.probes import ProbeContext
    from engine.probes.web.nextjs_rsc_rce import probe_nextjs_rsc_rce

    fake_session.get.return_value = _make_response(
        200,
        "<html><body>app/<script>self.__next_f.push(</script></body></html>",
    )
    fake_session.post.return_value = _make_response(
        500,
        "Error: Could not parse Flight payload\n"
        "    at decodeReply (react-server-dom-webpack/server.edge.js:42)\n"
        "    at handleAction (.next/server/app/page.js:120)",
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_nextjs_rsc_rce(ctx)

    assert findings
    assert any(f["severity"] == "medium" for f in findings)
    assert any("react-server-dom-webpack" in f["evidence"] for f in findings)


@pytest.mark.asyncio
async def test_high_when_sleep_payload_delays_response(fake_session):
    """Time delay on a Flight sleep payload => HIGH (blind RCE)."""
    from engine.probes import ProbeContext
    from engine.probes.web.nextjs_rsc_rce import probe_nextjs_rsc_rce

    fake_session.get.return_value = _make_response(
        200,
        '<script id="__NEXT_DATA__" type="application/json">{}</script>'
        "_next/static/chunks/app/page.js",
    )

    # Every POST stalls for 5.5s before returning. Probe sees elapsed >= 5s
    # and classifies HIGH on the very first payload.
    delay_count = {"n": 0}

    def _post_side_effect(*args, **kwargs):
        delay_count["n"] += 1
        # Only delay the first call to keep test runtime bounded; the
        # probe stops hammering this route after the first hit.
        delay = 5.5 if delay_count["n"] == 1 else 0.0
        return _slow_response(200, "{}", delay)

    fake_session.post.side_effect = _post_side_effect

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_nextjs_rsc_rce(ctx)

    assert findings
    assert any(f["severity"] == "high" for f in findings)
    assert any("Time-delay" in f["evidence"] for f in findings)


@pytest.mark.asyncio
async def test_high_when_flight_markers_reflected(fake_session):
    """200 + echoed `$F`/`$E` Flight markers => HIGH (parser executes)."""
    from engine.probes import ProbeContext
    from engine.probes.web.nextjs_rsc_rce import probe_nextjs_rsc_rce

    fake_session.get.return_value = _make_response(
        200,
        '<script>self.__next_f.push(</script>',
        {"x-nextjs-cache": "HIT"},
    )
    fake_session.post.return_value = _make_response(
        200,
        'parsed: [{"$F":"process.exit(0)"}] node_versions=...',
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_nextjs_rsc_rce(ctx)
    assert findings
    assert any(f["severity"] == "high" for f in findings)


# --------------------------------------------------------------------- #
# Registry metadata
# --------------------------------------------------------------------- #


def test_nextjs_rsc_rce_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import nextjs_rsc_rce

    # The conftest fixture snapshots the registry before each test, so a
    # plain import (already cached from earlier tests) won't re-trigger
    # the decorator. Reload to force re-registration into the post-snapshot
    # registry state.
    importlib.reload(nextjs_rsc_rce)

    spec = registry.get("web.nextjs_rsc_rce")
    assert spec is not None
    assert spec.bug_class == "rce_deserialization"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A08:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 25.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "novel" in spec.tags
    assert "destructive-low" in spec.tags
