"""Tests for the LDAP injection auth-bypass probe.

LDAP injection in login endpoints is a top-tier auth bypass. The probe
sends clean creds (expecting 401/403) then a wildcard filter break-out
payload. If the server flips to 200 plus a token or session cookie, the
filter is unsafe and the bypass is real.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_ldap_injection_critical_when_status_flip_with_token(fake_session):
    """Baseline 401, attack 200 with a token-shaped body -> critical."""
    from engine.probes import ProbeContext
    from engine.probes.web.ldap_injection import probe_ldap_injection

    fake_session.post.side_effect = [
        _make_response(401, '{"error":"invalid"}'),
        _make_response(
            200,
            '{"access_token":"eyJhbGciOi..."}',
            {"Content-Type": "application/json"},
        ),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/rest/user/login",),
    )

    findings = await probe_ldap_injection(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["category"] == "auth_bypass"
    assert f["bug_class"] == "auth_bypass"
    assert "LDAP injection" in f["title"]


@pytest.mark.asyncio
async def test_ldap_injection_high_when_status_flip_without_token(fake_session):
    """Baseline 403, attack 200 with no auth signal -> high."""
    from engine.probes import ProbeContext
    from engine.probes.web.ldap_injection import probe_ldap_injection

    fake_session.post.side_effect = [
        _make_response(403, "forbidden"),
        _make_response(200, "<html>welcome</html>"),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/login",),
    )

    findings = await probe_ldap_injection(ctx)

    assert len(findings) == 1
    assert findings[0]["severity"] == "high"


@pytest.mark.asyncio
async def test_ldap_injection_critical_when_set_cookie_signal(fake_session):
    """Set-Cookie on the attack response is a strong auth signal."""
    from engine.probes import ProbeContext
    from engine.probes.web.ldap_injection import probe_ldap_injection

    fake_session.post.side_effect = [
        _make_response(401, "nope"),
        _make_response(
            200, "{}", {"Set-Cookie": "session=abc123; Path=/; HttpOnly"}
        ),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/auth/login",),
    )

    findings = await probe_ldap_injection(ctx)

    assert len(findings) == 1
    assert findings[0]["severity"] == "critical"
    assert "Set-Cookie" in findings[0]["evidence"] or "Cookie" in findings[0]["evidence"]


@pytest.mark.asyncio
async def test_ldap_injection_no_finding_when_baseline_already_200(fake_session):
    """If clean creds already return 200, this isn't a real login surface."""
    from engine.probes import ProbeContext
    from engine.probes.web.ldap_injection import probe_ldap_injection

    fake_session.post.side_effect = [
        _make_response(200, "ok"),
        _make_response(200, '{"token":"x"}'),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/login",),
    )

    findings = await probe_ldap_injection(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_ldap_injection_no_finding_when_attack_still_rejected(fake_session):
    """Baseline 401 and attack 401 -> no bypass, no finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.ldap_injection import probe_ldap_injection

    fake_session.post.side_effect = [
        _make_response(401, "nope"),
        _make_response(401, "still nope"),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/login",),
    )

    findings = await probe_ldap_injection(ctx)
    assert findings == []


def test_ldap_injection_is_registered():
    from engine.probes import registry
    from engine.probes.web import ldap_injection  # noqa: F401  - import registers

    spec = registry.get("web.ldap_injection")
    assert spec is not None
    assert spec.bug_class == "auth_bypass"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A03:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 6.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
