"""Tests for the host-header reset-poisoning probe.

The probe replays a benign forgot-password POST with header overrides
(Host, X-Forwarded-Host, X-Forwarded-Server, X-Host, Forwarded). It
detects poisoning when the attacker host shows up in the response body,
in the Location header, or as part of a full reset URL.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_critical_when_full_reset_url_points_to_attacker(fake_session):
    """A reset link with attacker host inside an absolute URL is critical."""
    from engine.probes import ProbeContext
    from engine.probes.web.host_header_reset_poisoning import (
        probe_host_header_reset_poisoning,
    )

    body = (
        '{"message":"Reset email queued","reset_link":'
        '"https://ptai-host-canary.example/reset?token=abc"}'
    )
    fake_session.post.return_value = _make_response(200, body)

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("/api/auth/forgot-password",),
    )

    findings = await probe_host_header_reset_poisoning(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"
    assert findings[0]["bug_class"] == "auth_bypass"
    assert "ptai-host-canary.example" in findings[0]["evidence"] or "Reset link" in (
        findings[0]["title"] + findings[0]["evidence"]
    )


@pytest.mark.asyncio
async def test_high_when_attacker_host_reflected_in_response_header(fake_session):
    """Attacker host echoed via a custom response header is high severity."""
    from engine.probes import ProbeContext
    from engine.probes.web.host_header_reset_poisoning import (
        probe_host_header_reset_poisoning,
    )

    fake_session.post.return_value = _make_response(
        200,
        '{"status":"ok"}',
        {"X-Reset-Origin": "ptai-host-canary.example"},
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("/forgot-password",),
    )

    findings = await probe_host_header_reset_poisoning(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "high"
    assert findings[0]["bug_class"] == "auth_bypass"


@pytest.mark.asyncio
async def test_no_finding_when_response_omits_attacker_host(fake_session):
    """Server that echoes only the canonical host emits zero findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.host_header_reset_poisoning import (
        probe_host_header_reset_poisoning,
    )

    body = '{"message":"If the email exists, a reset has been sent."}'
    fake_session.post.return_value = _make_response(200, body)

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("/forgot-password",),
    )

    findings = await probe_host_header_reset_poisoning(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_critical_when_location_header_redirects_to_attacker(fake_session):
    """Attacker host in a Location header is also critical."""
    from engine.probes import ProbeContext
    from engine.probes.web.host_header_reset_poisoning import (
        probe_host_header_reset_poisoning,
    )

    fake_session.post.return_value = _make_response(
        302,
        "",
        {"Location": "https://ptai-host-canary.example/reset?token=xyz"},
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("/api/auth/forgot-password",),
    )

    findings = await probe_host_header_reset_poisoning(ctx)
    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"


@pytest.mark.asyncio
async def test_no_finding_on_4xx_or_5xx(fake_session):
    """Endpoint that rejects the request outright cannot poison anything."""
    from engine.probes import ProbeContext
    from engine.probes.web.host_header_reset_poisoning import (
        probe_host_header_reset_poisoning,
    )

    fake_session.post.return_value = _make_response(404, "not found")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        endpoint_hints=("/forgot-password",),
    )

    findings = await probe_host_header_reset_poisoning(ctx)
    assert findings == []


def test_host_header_reset_poisoning_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import host_header_reset_poisoning

    # Force decorator re-run; the conftest snapshot may not include this
    # probe yet because it isn't wired into engine/probes/web/__init__.py.
    importlib.reload(host_header_reset_poisoning)

    spec = registry.get("web.host_header_reset_poisoning")
    assert spec is not None
    assert spec.bug_class == "auth_bypass"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is False
