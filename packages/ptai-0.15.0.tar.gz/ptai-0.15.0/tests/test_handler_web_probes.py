"""Tests for engine.agents.handlers.web_probes.

Each handler is a thin wrapper around an SPA probe. The probe is
mocked; the test asserts the handler:
  - Translates probe findings into FindingRef rows in working memory.
  - Marks coverage on the (endpoint, bug-class) pair.
  - Returns a structured Observation.
  - Doesn't crash if the probe raises.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from engine.agent_loop import Observation
from engine.agents.handlers.web_probes import (
    HANDLER_BUG_CLASSES,
    handle_ftp_leak_probe,
    handle_jwt_alg_none_probe,
    handle_sqli_login_probe,
)
from engine.working_memory import (
    BUG_CLASSES,
    EndpointKey,
    FindingRef,
    make_working_memory,
)


@pytest.mark.asyncio
async def test_handle_jwt_alg_none_probe_records_findings_and_coverage():
    memory = make_working_memory("eng-1", "http://x.example")
    fake_findings = [
        {
            "title": "JWT 'alg: none' accepted on authenticated endpoint",
            "severity": "critical",
            "category": "authentication",
            "tool_source": "spa_probe",
            "target": "http://x.example/api/Users/",
            "evidence": "{}",
        }
    ]
    with patch(
        "engine.agents.handlers.web_probes.probe_jwt_alg_none",
        new=AsyncMock(return_value=fake_findings),
    ):
        obs = await handle_jwt_alg_none_probe(memory, {"endpoints": ["/api/Users/"]})

    assert isinstance(obs, Observation)
    assert obs.success is True
    assert obs.findings_added == 1
    assert len(memory.findings) == 1
    finding = memory.findings[0]
    assert isinstance(finding, FindingRef)
    assert finding.bug_class == "jwt_alg_none"
    assert finding.severity == "critical"
    assert memory.coverage.has_tried(EndpointKey("GET", "/api/Users/"), "jwt_alg_none")


@pytest.mark.asyncio
async def test_handle_sqli_login_probe_records_finding_and_endpoint():
    memory = make_working_memory("eng-2", "http://x.example")
    fake_findings = [
        {
            "title": "SQL injection auth bypass on login endpoint",
            "severity": "critical",
            "category": "injection",
            "tool_source": "spa_probe",
            "target": "http://x.example/rest/user/login",
            "evidence": "{}",
        }
    ]
    with patch(
        "engine.agents.handlers.web_probes.probe_login_sqli_bypass",
        new=AsyncMock(return_value=fake_findings),
    ):
        obs = await handle_sqli_login_probe(memory, {})

    assert obs.success is True
    assert obs.findings_added == 1
    assert obs.endpoints_added >= 1
    assert any(f.bug_class == "sqli" for f in memory.findings)


@pytest.mark.asyncio
async def test_handle_ftp_leak_probe_returns_no_findings_when_probe_returns_empty():
    memory = make_working_memory("eng-3", "http://x.example")
    with patch(
        "engine.agents.handlers.web_probes.probe_ftp_leak",
        new=AsyncMock(return_value=[]),
    ):
        obs = await handle_ftp_leak_probe(memory, {})

    assert obs.success is True
    assert obs.findings_added == 0


@pytest.mark.asyncio
async def test_handler_handles_probe_exception_without_crashing_the_loop():
    memory = make_working_memory("eng-4", "http://x.example")
    with patch(
        "engine.agents.handlers.web_probes.probe_jwt_alg_none",
        new=AsyncMock(side_effect=RuntimeError("network unreachable")),
    ):
        obs = await handle_jwt_alg_none_probe(memory, {})

    assert obs.success is False
    assert "network unreachable" in obs.error


def test_all_bug_classes_used_by_handlers_are_in_taxonomy():
    """Pin: each handler's emitted bug_class must appear in BUG_CLASSES."""
    missing = [bc for bc in HANDLER_BUG_CLASSES if bc not in BUG_CLASSES]
    assert missing == []
