"""Tests for the server-side prototype pollution probe.

The probe is two-step: POST a `__proto__` / `constructor.prototype`
payload to a candidate JSON sink, then GET a verification endpoint and
look for the canary string. We mock aiohttp at the session level so the
tests stay hermetic.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_prototype_pollution_critical_when_proto_canary_echoed(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.prototype_pollution import probe_prototype_pollution

    # Both POSTs accepted; subsequent GET on /health echoes the
    # __proto__ canary, proving the prototype now leaks across requests.
    fake_session.post.return_value = _make_response(200, '{"ok": true}')
    fake_session.get.return_value = _make_response(
        200, '{"status":"up","polluted":"yes-via-proto","isAdmin":true}'
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/preferences",),
    )

    findings = await probe_prototype_pollution(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "business_logic"
    assert f["category"] == "business_logic"
    assert "prototype pollution" in f["title"].lower()
    assert "yes-via-proto" in f["evidence"] or "yes-via-proto" in f["title"]


@pytest.mark.asyncio
async def test_prototype_pollution_critical_when_ctor_canary_echoed(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.prototype_pollution import probe_prototype_pollution

    # Same shape but the server only accepted the constructor.prototype
    # path. The canary that comes back is yes-via-ctor.
    fake_session.post.return_value = _make_response(201, '{"id": 1}')
    fake_session.get.return_value = _make_response(
        200, '{"app":"demo","polluted":"yes-via-ctor"}'
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/settings",),
    )

    findings = await probe_prototype_pollution(ctx)
    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"
    assert "yes-via-ctor" in findings[0]["evidence"]


@pytest.mark.asyncio
async def test_prototype_pollution_no_finding_when_no_canary(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.prototype_pollution import probe_prototype_pollution

    # POSTs accepted but verification GETs come back clean: the server
    # accepted the body but did not merge __proto__ into a shared graph.
    fake_session.post.return_value = _make_response(200, '{"ok": true}')
    fake_session.get.return_value = _make_response(
        200, '{"status":"up","version":"1.2.3"}'
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/preferences",),
    )

    findings = await probe_prototype_pollution(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_prototype_pollution_no_finding_when_server_rejects_proto(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.prototype_pollution import probe_prototype_pollution

    # The server filters dangerous keys: baseline POST is fine (200),
    # pollution POST is rejected with 400. No follow-up GET should
    # produce a finding even if a canary somehow appeared.
    call_count = {"n": 0}

    def post_side_effect(*args, **kwargs):
        call_count["n"] += 1
        # First call (baseline) returns 200, second (pollution) returns 400.
        if call_count["n"] == 1:
            return _make_response(200, '{"ok": true}')
        return _make_response(400, '{"error": "invalid key __proto__"}')

    fake_session.post.side_effect = post_side_effect
    # If the probe ignores the rejection and still GETs, this canary
    # body would falsely trigger; the test asserts the probe respects
    # the 400 and emits nothing.
    fake_session.get.return_value = _make_response(
        200, '{"polluted":"yes-via-proto"}'
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/preferences",),
    )

    findings = await probe_prototype_pollution(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_prototype_pollution_no_finding_when_baseline_already_has_canary(
    fake_session,
):
    from engine.probes import ProbeContext
    from engine.probes.web.prototype_pollution import probe_prototype_pollution

    # Baseline response already contains the canary string (e.g. the
    # target app happens to include the literal text). The probe must
    # treat that as noise, not pollution evidence.
    fake_session.post.return_value = _make_response(
        200, '{"echo":"polluted":"yes-via-proto"}'
    )
    fake_session.get.return_value = _make_response(
        200, '{"polluted":"yes-via-proto"}'
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/preferences",),
    )

    findings = await probe_prototype_pollution(ctx)
    assert findings == []


def test_prototype_pollution_is_registered():
    from engine.probes import registry
    from engine.probes.web import prototype_pollution  # noqa: F401  - import registers

    spec = registry.get("web.prototype_pollution")
    assert spec is not None
    assert spec.bug_class == "business_logic"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A04:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 10.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "destructive-low" in spec.tags
