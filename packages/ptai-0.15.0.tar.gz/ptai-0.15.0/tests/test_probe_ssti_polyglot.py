"""Tests for the SSTI polyglot probe.

Server-Side Template Injection is a high-impact bug class because a
positive hit usually means RCE. The probe sends a single polyglot
payload that any of the common engines (Jinja2, Twig, ERB, Velocity,
SpEL) will evaluate to ``49``. We compare baseline vs perturbation:
``49`` must appear in the perturbation body and NOT in the baseline.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


def _cycling_side_effect(baseline_body: str, attack_body: str):
    """Return a side_effect callable that alternates baseline/attack responses.

    The probe iterates many param names per path; each iteration does two
    GETs. We want every odd call to be the baseline and every even call
    the attack, regardless of how many params the probe walks.
    """
    counter = {"n": 0}

    def _get(*args, **kwargs):
        counter["n"] += 1
        body = baseline_body if counter["n"] % 2 == 1 else attack_body
        return _make_response(200, body)

    return _get


@pytest.mark.asyncio
async def test_ssti_hit_when_49_appears_only_in_perturbation(fake_session):
    """Baseline is clean, perturbation contains '49' -> high severity hit."""
    from engine.probes import ProbeContext
    from engine.probes.web.ssti_polyglot import probe_ssti_polyglot

    fake_session.get.side_effect = _cycling_side_effect(
        "<html>Hello ptaicanary</html>",
        "<html>Hello 49</html>",
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/greet",),
    )

    findings = await probe_ssti_polyglot(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "high"
    assert f["category"] == "injection"
    assert f["bug_class"] == "rce_template"
    assert "Template Injection" in f["title"]


@pytest.mark.asyncio
async def test_ssti_no_hit_when_49_in_baseline_already(fake_session):
    """If '49' is already in the baseline, we cannot attribute it to SSTI."""
    from engine.probes import ProbeContext
    from engine.probes.web.ssti_polyglot import probe_ssti_polyglot

    # Both baseline and perturbation contain "49"; ambiguous.
    fake_session.get.return_value = _make_response(
        200, "<html>Result: 49 items in stock</html>"
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/search",),
    )

    findings = await probe_ssti_polyglot(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_ssti_no_hit_when_perturbation_does_not_contain_49(fake_session):
    """Engine did not evaluate the payload -> no SSTI."""
    from engine.probes import ProbeContext
    from engine.probes.web.ssti_polyglot import probe_ssti_polyglot

    fake_session.get.side_effect = _cycling_side_effect(
        "<html>Welcome ptaicanary</html>",
        "<html>Welcome ${7*7}{{7*7}}&lt;%=7*7%&gt;#{7*7}</html>",
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/render",),
    )

    findings = await probe_ssti_polyglot(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_ssti_medium_severity_on_partial_evaluation(fake_session):
    """Some engines partial-evaluate; mark medium instead of high."""
    from engine.probes import ProbeContext
    from engine.probes.web.ssti_polyglot import probe_ssti_polyglot

    fake_session.get.side_effect = _cycling_side_effect(
        "<html>Hi ptaicanary</html>",
        # One variant evaluated, another wrapped the result.
        "<html>Hi 49 and {{49}}</html>",
    )
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/template",),
    )

    findings = await probe_ssti_polyglot(ctx)
    assert len(findings) >= 1
    assert findings[0]["severity"] == "medium"


def test_ssti_polyglot_is_registered():
    from engine.probes import registry
    from engine.probes.web import ssti_polyglot  # noqa: F401  - import registers

    spec = registry.get("web.ssti_polyglot")
    assert spec is not None
    assert spec.bug_class == "rce_template"
    assert spec.severity_max == "high"
    assert spec.requires_auth is False
    assert spec.owasp == "A03:2021"
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert spec.runtime_budget_s == 10.0
