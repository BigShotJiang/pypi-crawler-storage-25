"""Tests for the forced-error stack-trace disclosure probe."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from engine.probes.web import forced_error  # noqa: F401  - registers


def _resp(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {"Content-Type": "application/json"}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_forced_error_emits_high_finding_on_path_disclosure(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.forced_error import probe_forced_error

    def get_side(url, **_kwargs):
        return _resp(200, "OK")

    def post_side(url, **_kwargs):
        return _resp(
            500,
            "Error: Unexpected token at /var/www/juice/node_modules/express/lib/router.js:42",
        )

    fake_session.get.side_effect = get_side
    fake_session.post.side_effect = post_side

    ctx = ProbeContext(
        session=fake_session,
        base="http://x",
        candidate_endpoints=("/api/Users/",),
    )
    findings = await probe_forced_error(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "high"
    assert findings[0]["bug_class"] == "exposed_dev"


@pytest.mark.asyncio
async def test_forced_error_emits_medium_when_only_framework_marker(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.forced_error import probe_forced_error

    fake_session.get.side_effect = lambda url, **_k: _resp(200, "OK")
    fake_session.post.side_effect = lambda url, **_k: _resp(
        500, "ReferenceError: foo is not defined"
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://x",
        candidate_endpoints=("/api/Users/",),
    )
    findings = await probe_forced_error(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "medium"


@pytest.mark.asyncio
async def test_forced_error_no_finding_on_clean_400(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.forced_error import probe_forced_error

    fake_session.get.side_effect = lambda url, **_k: _resp(200, "OK")
    fake_session.post.side_effect = lambda url, **_k: _resp(
        400, '{"error": "Bad Request"}'
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://x",
        candidate_endpoints=("/api/Users/",),
    )
    findings = await probe_forced_error(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_forced_error_skips_404_endpoints(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.forced_error import probe_forced_error

    fake_session.get.side_effect = lambda url, **_k: _resp(404, "")
    fake_session.post.side_effect = lambda url, **_k: _resp(
        500, "/var/www/leak"
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://x",
        candidate_endpoints=("/api/Users/",),
    )
    findings = await probe_forced_error(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_forced_error_baseline_marker_does_not_trigger(fake_session):
    """If baseline body already has the marker, post-attack must not flag."""
    from engine.probes import ProbeContext
    from engine.probes.web.forced_error import probe_forced_error

    # Both baseline and attack contain a path
    fake_session.get.side_effect = lambda url, **_k: _resp(
        200, "see /var/www/docs/readme"
    )
    fake_session.post.side_effect = lambda url, **_k: _resp(
        500, "see /var/www/docs/readme"
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://x",
        candidate_endpoints=("/api/Users/",),
    )
    findings = await probe_forced_error(ctx)
    assert findings == []


def test_forced_error_is_registered():
    from engine.probes import registry

    spec = registry.get("web.forced_error")
    assert spec is not None
    assert spec.bug_class == "exposed_dev"
    assert spec.severity_max == "high"
    assert spec.owasp == "A05:2021"
    assert "fast" in spec.tags
    assert spec.requires_auth is False
