"""Tests for the IDOR sequential-ID probe.

REST endpoints that hand back sequential resources (e.g. /api/Baskets/1,
/api/Baskets/2) without ownership checks leak other-user data. The probe
walks candidate REST roots, GETs three sequential IDs, and flags when
the responses contain divergent identity fields.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {"Content-Type": "application/json"}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_idor_hit_when_three_sequential_ids_return_different_users(
    fake_session,
):
    from engine.probes import ProbeContext
    from engine.probes.web.idor_sequential import probe_idor_sequential

    fake_session.get.side_effect = [
        _make_response(
            200,
            '{"id": 1, "email": "alice@example.com", "name": "Alice"}',
        ),
        _make_response(
            200,
            '{"id": 2, "email": "bob@example.com", "name": "Bob"}',
        ),
        _make_response(
            200,
            '{"id": 3, "email": "carol@example.com", "name": "Carol"}',
        ),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Baskets/",),
    )

    findings = await probe_idor_sequential(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "high"
    assert f["bug_class"] == "idor"
    assert f["category"] == "access_control"
    assert "IDOR" in f["title"]
    assert "alice@example.com" in f["evidence"]


@pytest.mark.asyncio
async def test_idor_no_hit_when_only_one_id_returns_200(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.idor_sequential import probe_idor_sequential

    fake_session.get.side_effect = [
        _make_response(
            200, '{"id": 1, "email": "alice@example.com"}'
        ),
        _make_response(404, '{"error": "not found"}'),
        _make_response(404, '{"error": "not found"}'),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Baskets/",),
    )

    findings = await probe_idor_sequential(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_idor_no_hit_when_responses_are_identical(fake_session):
    """Placeholder/error pages with identical content must not flag."""
    from engine.probes import ProbeContext
    from engine.probes.web.idor_sequential import probe_idor_sequential

    same_body = '{"message": "resource not available", "status": "ok"}'
    fake_session.get.side_effect = [
        _make_response(200, same_body),
        _make_response(200, same_body),
        _make_response(200, same_body),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Baskets/",),
    )

    findings = await probe_idor_sequential(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_idor_no_hit_when_response_is_not_json(fake_session):
    """HTML 200 pages (SPA fallback) must not flag."""
    from engine.probes import ProbeContext
    from engine.probes.web.idor_sequential import probe_idor_sequential

    fake_session.get.side_effect = [
        _make_response(
            200,
            "<!doctype html><html><body>App</body></html>",
            {"Content-Type": "text/html"},
        ),
        _make_response(
            200,
            "<!doctype html><html><body>App</body></html>",
            {"Content-Type": "text/html"},
        ),
        _make_response(
            200,
            "<!doctype html><html><body>App</body></html>",
            {"Content-Type": "text/html"},
        ),
    ]
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Baskets/",),
    )

    findings = await probe_idor_sequential(ctx)
    assert findings == []


def test_idor_sequential_is_registered():
    from engine.probes import registry
    from engine.probes.web import idor_sequential  # noqa: F401  - import registers

    spec = registry.get("web.idor_sequential")
    assert spec is not None
    assert spec.bug_class == "idor"
    assert spec.severity_max == "high"
    assert spec.owasp == "A01:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 8.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
