"""Tests for ``engine.async_prompt.prompt_with_timeout``."""
from __future__ import annotations

from unittest.mock import patch

import pytest

from engine.async_prompt import is_non_interactive, prompt_with_timeout


@pytest.mark.asyncio
async def test_returns_input_when_provided():
    """When the underlying input() returns, we get that value back."""

    def fake_input(_prompt):
        return "yes"

    with patch("builtins.input", side_effect=fake_input), patch(
        "engine.async_prompt.is_non_interactive", return_value=False
    ):
        result = await prompt_with_timeout("ok?", default="n", timeout_s=2)
    assert result == "yes"


@pytest.mark.asyncio
async def test_timeout_returns_default():
    """If input() never returns, we get the default and no hanging task."""

    def slow_input(_prompt):
        import time

        time.sleep(2)
        return "ignored"

    with patch("builtins.input", side_effect=slow_input), patch("engine.async_prompt.is_non_interactive", return_value=False):
        result = await prompt_with_timeout("ok?", default="default-val", timeout_s=0.2)
    assert result == "default-val"


@pytest.mark.asyncio
async def test_non_interactive_skips_prompt(monkeypatch):
    """PTAI_NON_INTERACTIVE=1 short-circuits without ever invoking input()."""
    monkeypatch.setenv("PTAI_NON_INTERACTIVE", "1")
    sentinel = {"called": False}

    def trap_input(_prompt):
        sentinel["called"] = True
        return "should-not-be-used"

    with patch("builtins.input", side_effect=trap_input):
        result = await prompt_with_timeout("ok?", default="def", timeout_s=2)
    assert result == "def"
    assert sentinel["called"] is False


@pytest.mark.asyncio
async def test_eof_returns_default():
    """A closed stdin (EOFError) returns the default instead of crashing."""

    def eof_input(_prompt):
        raise EOFError()

    with patch("builtins.input", side_effect=eof_input), patch("engine.async_prompt.is_non_interactive", return_value=False):
        result = await prompt_with_timeout("ok?", default="ok-default", timeout_s=2)
    assert result == "ok-default"


def test_is_non_interactive_with_env_var(monkeypatch):
    monkeypatch.setenv("PTAI_NON_INTERACTIVE", "1")
    assert is_non_interactive() is True


def test_is_non_interactive_without_tty(monkeypatch):
    monkeypatch.delenv("PTAI_NON_INTERACTIVE", raising=False)
    # Under pytest stdin is typically not a TTY.
    # We don't assert exact value because some local dev setups DO have a TTY;
    # instead, verify the call doesn't crash and returns a bool.
    result = is_non_interactive()
    assert isinstance(result, bool)
