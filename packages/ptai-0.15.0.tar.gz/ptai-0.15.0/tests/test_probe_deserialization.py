"""Tests for the Node.js deserialization probe.

Validates web.deserialization correctly distinguishes:
  - RCE via response-time delta (sleep 3 gadget)
  - Memory bomb DoS via 503 + parser error
  - Slow-baseline false-positive guard
  - Missing endpoint (404) skip
  - Registry metadata
"""
from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def fake_session():
    return MagicMock()


def _make_clock(values: list[float]):
    """Return a callable yielding successive absolute clock readings.

    The probe calls `time.monotonic()` twice per request (start, end).
    Provide one value per call; elapsed = values[2k+1] - values[2k].
    Past the end of the list, the last value repeats.
    """
    state = {"i": 0}

    def now() -> float:
        idx = state["i"]
        if idx < len(values):
            state["i"] += 1
            return values[idx]
        return values[-1] if values else 0.0

    return now


def _post_returning(status: int, body: str = ""):
    """AsyncMock side_effect helper returning a constant (status, headers, body)."""

    async def _post(session, url, payload, **_kwargs):  # noqa: ARG001
        return status, {}, body

    return _post


@pytest.mark.asyncio
async def test_deserialization_rce_detected_via_time_delta(fake_session):
    """Attack 1 takes 3.5s vs 0.1s baseline -> critical RCE finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.deserialization import probe_deserialization

    # Sequence of request "elapseds" the probe will see, per endpoint:
    # baseline=0.1s, RCE=3.5s, DoS=skipped(continue after rce_hit).
    # First endpoint hits, subsequent endpoints baseline=404 -> skip.
    call_state = {"endpoint_idx": 0, "step": 0}

    async def post(session, url, payload, **_kwargs):  # noqa: ARG001
        # First endpoint: baseline 200, RCE 200 (slow). Others: 404 baseline.
        if "/b2b/v2/orders" in url:
            call_state["step"] += 1
            if call_state["step"] == 1:  # baseline
                return 200, {}, "OK"
            if call_state["step"] == 2:  # rce
                return 200, {}, "internal err"
            return 200, {}, "OK"
        return 404, {}, ""

    # Absolute clock readings; each request consumes (start, end).
    # ep1: baseline 0.0->0.1 (=0.1s), rce 0.1->3.6 (=3.5s); rce_hit -> no DoS.
    # ep2..5: baseline only (404), tiny duration each.
    deltas = [
        0.0, 0.1,    # ep1 baseline
        0.1, 3.6,    # ep1 rce
        3.6, 3.61,   # ep2 baseline
        3.61, 3.62,  # ep3 baseline
        3.62, 3.63,  # ep4 baseline
        3.63, 3.64,  # ep5 baseline
    ]

    with patch(
        "engine.probes.web.deserialization.http_post_json",
        side_effect=post,
    ), patch(
        "engine.probes.web.deserialization.monotonic",
        side_effect=_make_clock(deltas),
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_deserialization(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "rce_deserialization"
    assert "/b2b/v2/orders" in f["target"]
    assert "deserialization RCE" in f["title"]


@pytest.mark.asyncio
async def test_deserialization_memory_bomb_detected_via_503(fake_session):
    """Attack 2 returns 503 with YAMLException -> high severity DoS finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.deserialization import probe_deserialization

    state = {"step": 0}

    async def post(session, url, payload, **_kwargs):  # noqa: ARG001
        if "/b2b/v2/orders" not in url:
            return 404, {}, ""
        state["step"] += 1
        if state["step"] == 1:  # baseline
            return 200, {}, "OK"
        if state["step"] == 2:  # rce: nothing happens, fast 200
            return 200, {}, "OK"
        if state["step"] == 3:  # dos: 503 with YAMLException
            return 503, {}, "YAMLException: bad yaml at line 1"
        return 200, {}, "OK"

    # All requests fast; DoS detection comes from status+body, not timing.
    deltas = [
        0.0, 0.05,    # ep1 baseline
        0.05, 0.10,   # ep1 rce (no hit, fast)
        0.10, 0.15,   # ep1 dos
        0.15, 0.16,   # ep2 baseline
        0.16, 0.17,
        0.17, 0.18,
        0.18, 0.19,
    ]

    with patch(
        "engine.probes.web.deserialization.http_post_json",
        side_effect=post,
    ), patch(
        "engine.probes.web.deserialization.monotonic",
        side_effect=_make_clock(deltas),
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_deserialization(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "high"
    assert f["bug_class"] == "rce_deserialization"
    assert f["category"] == "denial_of_service"
    assert "/b2b/v2/orders" in f["target"]


@pytest.mark.asyncio
async def test_deserialization_no_finding_when_baseline_slow(fake_session):
    """Baseline already > 3s -> timing signal discarded, no false positive."""
    from engine.probes import ProbeContext
    from engine.probes.web.deserialization import probe_deserialization

    async def post(session, url, payload, **_kwargs):  # noqa: ARG001
        if "/b2b/v2/orders" not in url:
            return 404, {}, ""
        # Always 200 with a clean body, no markers.
        return 200, {}, "OK"

    # Baseline 4s (slow), RCE 7s (delta would trigger but baseline_slow
    # guard kicks in), DoS 6s (>5s but baseline_slow guard kicks in).
    # No body markers anywhere -> no findings expected.
    deltas = [
        0.0, 4.0,     # ep1 baseline (4s, slow)
        4.0, 11.0,    # ep1 rce (7s, but guarded)
        11.0, 17.0,   # ep1 dos (6s, but guarded)
        17.0, 17.01,  # ep2 baseline (404)
        17.01, 17.02,
        17.02, 17.03,
        17.03, 17.04,
    ]

    with patch(
        "engine.probes.web.deserialization.http_post_json",
        side_effect=post,
    ), patch(
        "engine.probes.web.deserialization.monotonic",
        side_effect=_make_clock(deltas),
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_deserialization(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_deserialization_no_finding_on_404_endpoints(fake_session):
    """All endpoints return 404 -> probe skips everything cleanly."""
    from engine.probes import ProbeContext
    from engine.probes.web.deserialization import probe_deserialization

    # Generate ascending absolute clock values; elapsed per request ~ 0.01s.
    clock_values = [i * 0.01 for i in range(100)]

    with patch(
        "engine.probes.web.deserialization.http_post_json",
        side_effect=_post_returning(404, ""),
    ), patch(
        "engine.probes.web.deserialization.monotonic",
        side_effect=_make_clock(clock_values),
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_deserialization(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_deserialization_rce_detected_via_body_marker(fake_session):
    """Body contains `_$$ND_FUNC$$_` echo / ReferenceError -> critical."""
    from engine.probes import ProbeContext
    from engine.probes.web.deserialization import probe_deserialization

    state = {"step": 0}

    async def post(session, url, payload, **_kwargs):  # noqa: ARG001
        if "/b2b/v2/orders" not in url:
            return 404, {}, ""
        state["step"] += 1
        if state["step"] == 1:
            return 200, {}, "OK"
        if state["step"] == 2:
            # RCE attack response leaks the gadget marker - clear hit.
            return 500, {}, "ReferenceError: child_process is not defined"
        return 200, {}, "OK"

    deltas = [i * 0.05 for i in range(60)]

    with patch(
        "engine.probes.web.deserialization.http_post_json",
        side_effect=post,
    ), patch(
        "engine.probes.web.deserialization.monotonic",
        side_effect=_make_clock(deltas),
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_deserialization(ctx)

    assert len(findings) == 1
    assert findings[0]["severity"] == "critical"
    assert "ReferenceError" in findings[0]["evidence"]


def test_deserialization_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import deserialization

    # The shared conftest fixture restores a registry snapshot taken
    # before our module was first imported, so the @probe decorator's
    # side effect can be wiped between tests. Reload to re-execute it.
    importlib.reload(deserialization)

    spec = registry.get("web.deserialization")
    assert spec is not None
    assert spec.bug_class == "rce_deserialization"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A08:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 20.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "destructive-low" in spec.tags
