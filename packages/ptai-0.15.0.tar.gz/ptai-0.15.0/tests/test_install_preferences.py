"""Tests for ``engine.install_preferences``."""
from __future__ import annotations

import json

from engine.install_preferences import InstallPreferences, load, save


def test_load_missing_file_returns_defaults(tmp_path):
    """A nonexistent path returns conservative defaults (no denial, no auto)."""
    target = tmp_path / "prefs.json"
    prefs = load(target)
    assert prefs.auto_install is False
    assert prefs.denied_tools == []
    assert prefs.approved_methods == {
        "apt": False,
        "go": False,
        "pip": False,
        "cargo": False,
    }


def test_roundtrip_preserves_shape(tmp_path):
    """save → load returns equivalent preferences."""
    target = tmp_path / "prefs.json"
    prefs = InstallPreferences(
        auto_install=True,
        denied_tools=["wpscan", "metasploit"],
        approved_methods={"apt": True, "go": True, "pip": False, "cargo": False},
    )
    save(prefs, target)
    loaded = load(target)
    assert loaded.auto_install is True
    assert loaded.denied_tools == ["wpscan", "metasploit"]
    assert loaded.approved_methods["apt"] is True
    assert loaded.approved_methods["go"] is True
    assert loaded.approved_methods["pip"] is False
    assert loaded.last_updated is not None  # save() stamps it


def test_load_corrupt_json_returns_defaults(tmp_path):
    """Corrupt JSON shouldn't crash; the planner must keep going."""
    target = tmp_path / "prefs.json"
    target.write_text("{not-json")
    prefs = load(target)
    assert prefs.auto_install is False
    assert prefs.denied_tools == []


def test_deny_idempotent():
    """Denying the same tool twice doesn't duplicate the entry."""
    prefs = InstallPreferences()
    prefs.deny("wpscan")
    prefs.deny("wpscan")
    assert prefs.denied_tools == ["wpscan"]


def test_is_denied():
    prefs = InstallPreferences(denied_tools=["sqlmap"])
    assert prefs.is_denied("sqlmap") is True
    assert prefs.is_denied("nuclei") is False


def test_approve_method():
    prefs = InstallPreferences()
    assert prefs.is_method_approved("apt") is False
    prefs.approve_method("apt")
    assert prefs.is_method_approved("apt") is True


def test_save_writes_iso8601_timestamp(tmp_path):
    """The stamp is round-trippable as ISO-8601."""
    target = tmp_path / "prefs.json"
    prefs = InstallPreferences()
    save(prefs, target)
    data = json.loads(target.read_text())
    assert data["last_updated"]
    # Crude check: includes a 'T' and a timezone offset / Z.
    assert "T" in data["last_updated"]
