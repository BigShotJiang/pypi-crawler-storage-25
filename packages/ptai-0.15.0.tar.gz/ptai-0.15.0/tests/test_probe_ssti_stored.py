"""Tests for the stored-SSTI probe.

Stored SSTI is the two-step analogue of stored XSS: POST a template
payload, GET a render endpoint, see the multiplication marker prove
the server-side template engine evaluated the stored value.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_ssti_stored_fires_when_form_post_redirect_renders_marker(fake_session):
    """Flask-style: POST /profile/update bio={{137*97}} -> 302 -> /profile/1
    rendering the bio as `13289`. aiohttp follows the redirect so the
    form-POST final response body already contains the marker."""
    from engine.probes import ProbeContext
    from engine.probes.web.ssti_stored import probe_ssti_stored

    fake_session.post.return_value = _make_response(
        200, "<html><p>Bio:</p><blockquote>13289</blockquote></html>",
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://taskflow.local",
        candidate_endpoints=("/profile/update",),
    )

    findings = await probe_ssti_stored(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "ssti"
    assert f["category"] == "injection"
    assert "Stored SSTI" in f["title"]


@pytest.mark.asyncio
async def test_ssti_stored_fires_on_separate_get_readback(fake_session):
    """REST-style: POST /api/profile (200 with {id:7}) does NOT echo the
    eval in the POST response. A separate GET on the readback URL
    renders the marker."""
    from engine.probes import ProbeContext
    from engine.probes.web.ssti_stored import probe_ssti_stored

    # POST response (any shape) returns ok but no marker in the body.
    fake_session.post.return_value = _make_response(
        200, '{"id": 7, "bio": "{{137*97}}"}',
    )
    # GET on any readback URL returns the rendered marker.
    fake_session.get.return_value = _make_response(
        200, "<div>profile bio = 13289</div>",
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://app.local",
        candidate_endpoints=("/api/profile",),
    )

    findings = await probe_ssti_stored(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "critical"


@pytest.mark.asyncio
async def test_ssti_stored_silent_when_marker_absent(fake_session):
    """Server stores payload but autoescapes on render -> marker stays
    `{{137*97}}` literal in the body. No finding emitted."""
    from engine.probes import ProbeContext
    from engine.probes.web.ssti_stored import probe_ssti_stored

    fake_session.post.return_value = _make_response(
        200, "<html><p>Bio: {{137*97}}</p></html>",
    )
    fake_session.get.return_value = _make_response(
        200, "<html><p>Bio: {{137*97}}</p></html>",
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://safe.local",
        candidate_endpoints=("/profile/update",),
    )

    findings = await probe_ssti_stored(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_ssti_stored_registered_in_registry():
    """Importing the package registers the probe under its declared name."""
    import engine.probes.web  # noqa: F401  - triggers registration
    from engine.probes import registry

    assert registry.get("web.ssti_stored") is not None
