"""End-to-end smoke test: tool.run against a live HTTP target.

Exercises the full pipeline:

  1. register_default_handlers wires tool.<name> handlers.
  2. The LLM (faked here) picks a tool by calling `tool.run`.
  3. The handler resolves the wrapper, runs it in a subprocess, parses
     output, and appends findings to WorkingMemory.

This test is skipped unless juice-shop (or any HTTP server) is reachable
on the configured port. Run locally with juice-shop up:

    docker run --rm -d --name juice -p 3000:3000 bkimminich/juice-shop
    pytest tests/test_tool_bridge_e2e.py -v

Or set ``PTAI_E2E_TARGET=http://127.0.0.1:3001`` for a different target.
"""
from __future__ import annotations

import os
import shutil
import socket
import urllib.parse

import pytest

DEFAULT_TARGET = os.environ.get("PTAI_E2E_TARGET", "http://127.0.0.1:3000")


def _target_reachable(target: str) -> bool:
    parsed = urllib.parse.urlparse(target)
    host = parsed.hostname or "127.0.0.1"
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    try:
        with socket.create_connection((host, port), timeout=1.0):
            return True
    except OSError:
        return False


pytestmark = pytest.mark.skipif(
    not _target_reachable(DEFAULT_TARGET),
    reason=f"e2e: nothing listening on {DEFAULT_TARGET}",
)


@pytest.mark.asyncio
async def test_register_default_handlers_wires_tools():
    """Importing the package registers 200+ tool.<name> handlers without crashing."""
    from engine.agent_loop import _HANDLERS
    from engine.agents.handlers import register_default_handlers

    # Already wired by previous tests' imports; call again with force=False to confirm idempotent.
    register_default_handlers()
    tool_handlers = [k for k in _HANDLERS if k.startswith("tool.") and k not in {"tool.run", "tool.list", "tool.plan", "tool.ensure_installed"}]
    assert len(tool_handlers) >= 100, f"expected 100+ tool handlers, got {len(tool_handlers)}"
    # Meta handlers present.
    for required in ("tool.run", "tool.list", "tool.plan", "tool.ensure_installed"):
        assert required in _HANDLERS


@pytest.mark.asyncio
async def test_tool_list_returns_installed_subset():
    """tool.list installed_only=True returns only wrappers whose command is on PATH."""
    from engine.agents.handlers.tool_bridge import handle_tool_list
    from engine.working_memory import make_working_memory

    memory = make_working_memory("e2e-test", DEFAULT_TARGET)
    obs = await handle_tool_list(memory, {"installed_only": True})
    assert obs.success
    entries = obs.raw["tools"]
    # We expect at least the tools we know are installed on this dev box.
    names = {e["name"] for e in entries}
    assert names, "no installed tools detected — is PATH right?"
    # nmap or curl is on every standard install.
    assert "nmap" in names or "curl" in names or "ffuf" in names


@pytest.mark.asyncio
async def test_tool_run_wafw00f_against_live_target():
    """Run wafw00f via tool.run against the live target; verify pipeline plumbing.

    wafw00f is wrapped in `tools/registry.py`, lightweight (one-shot WAF
    fingerprinting), and finishes in under 10 seconds. The point of this
    test is the *pipeline* — generic dispatcher → per-tool handler →
    subprocess → parser → Observation — not that wafw00f finds a WAF.
    """
    if not shutil.which("wafw00f"):
        pytest.skip("wafw00f not on PATH")

    from engine.agents.handlers.tool_bridge import handle_tool_run
    from engine.working_memory import make_working_memory

    memory = make_working_memory("e2e-test", DEFAULT_TARGET)
    obs = await handle_tool_run(
        memory,
        {"tool": "wafw00f", "target": DEFAULT_TARGET, "timeout_s": 30},
    )

    # The Observation should ALWAYS be a valid response regardless of wafw00f's
    # exit code; this is the integration-pipeline contract.
    assert obs is not None
    assert obs.normalized is not None
    # The dispatcher returns the per-tool handler's observation verbatim,
    # so action_name should be tool.wafw00f (not tool.run).
    assert obs.action_name == "tool.wafw00f", f"got {obs.action_name}"
    # Raw output cap applies regardless of how chatty wafw00f got.
    assert len(obs.raw.get("stdout_snippet", "")) <= 4096
    # exit_code is set whenever the wrapper actually executed.
    assert obs.raw.get("exit_code") is not None
    assert isinstance(obs.raw["exit_code"], int)
