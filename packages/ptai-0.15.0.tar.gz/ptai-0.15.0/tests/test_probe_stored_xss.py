"""Tests for the stored-XSS probe.

Stored XSS is a top-class injection bug: POST a script tag to a
comments / feedback endpoint, GET the collection back, see the literal
payload echoed unencoded. The probe walks a small set of candidate
sinks and emits a high-severity finding on read-back.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_stored_xss_high_when_script_echoed_unencoded(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.stored_xss import probe_stored_xss

    # Sequence: POST accepted (201) returning {"id": 7}, then GET on
    # the collection echoes the script payload unencoded.
    fake_session.post.return_value = _make_response(
        201, '{"id": 7, "comment": "<script>alert(\'ptai\')</script>"}'
    )
    fake_session.get.return_value = _make_response(
        200,
        '[{"id": 7, "comment": "<script>alert(\'ptai\')</script>", "rating": 1}]',
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Feedbacks",),
    )

    findings = await probe_stored_xss(ctx)

    assert len(findings) >= 1
    f = findings[0]
    assert f["severity"] == "high"
    assert f["bug_class"] == "xss_stored"
    assert f["category"] == "injection"
    assert "Stored XSS" in f["title"]


@pytest.mark.asyncio
async def test_stored_xss_no_finding_when_payload_html_encoded(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.stored_xss import probe_stored_xss

    # POST accepted but GET returns HTML-encoded entities, not literal tags.
    fake_session.post.return_value = _make_response(
        201, '{"id": 7}'
    )
    fake_session.get.return_value = _make_response(
        200,
        '[{"id": 7, "comment": "&lt;script&gt;alert(&#39;ptai&#39;)&lt;/script&gt;"}]',
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Feedbacks",),
    )

    findings = await probe_stored_xss(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_stored_xss_no_finding_when_post_rejected(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.stored_xss import probe_stored_xss

    # Server rejects every comment-field variant with 400.
    fake_session.post.return_value = _make_response(400, '{"error": "bad"}')
    # GET should not even be reached when no POST is accepted, but if it
    # is, return a clean body to make sure we still emit nothing.
    fake_session.get.return_value = _make_response(200, "[]")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Feedbacks",),
    )

    findings = await probe_stored_xss(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_stored_xss_detects_iframe_javascript_payload(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.stored_xss import probe_stored_xss

    # POST accepted; GET reflects an iframe javascript: payload (the
    # server stripped the <script> tag but missed the iframe vector).
    fake_session.post.return_value = _make_response(
        200, '{"id": "abc"}'
    )
    fake_session.get.return_value = _make_response(
        200,
        'rendered: <iframe src="javascript:alert(1)"></iframe> end',
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Comments",),
    )

    findings = await probe_stored_xss(ctx)
    assert len(findings) >= 1
    assert findings[0]["severity"] == "high"


@pytest.mark.asyncio
async def test_stored_xss_propagates_cookie_auth_to_post_and_get(fake_session):
    """captured_auth=cookie -> every session.post AND .get carries Cookie."""
    from engine.probes import ProbeContext
    from engine.probes.web.stored_xss import probe_stored_xss

    # All POSTs return 400 so the probe iterates every (shape, field, path)
    # combination, giving us many call_args to inspect.
    fake_session.post.return_value = _make_response(400, "rejected")
    fake_session.get.return_value = _make_response(200, "nothing")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/feedback",),
        captured_auth={"kind": "cookie", "token": "session=xyz"},
    )
    await probe_stored_xss(ctx)

    assert fake_session.post.call_count > 0
    for call in fake_session.post.call_args_list:
        assert call.kwargs.get("headers", {}).get("Cookie") == "session=xyz", (
            f"missing Cookie in POST {call}"
        )


@pytest.mark.asyncio
async def test_stored_xss_falls_back_to_form_shape_when_json_inert(fake_session):
    """When JSON POST is accepted but doesn't persist (no echo), form shape is tried.

    Models a Flask handler that returns 200 to anything but only reads
    request.form: a JSON POST returns 200 with empty index page (no
    echo), so the probe must try the form-encoded shape next.
    """
    from engine.probes import ProbeContext
    from engine.probes.web.stored_xss import probe_stored_xss

    posts_made: list[tuple[str, dict]] = []

    def post_side(url, **kwargs):
        # data=dict -> form-urlencoded shape
        "data" in kwargs and isinstance(kwargs["data"], dict)
        posts_made.append((url, kwargs))
        return _make_response(200, "")

    def get_side(url, **_k):
        # Only the form-shape POST persisted the script. So if any form
        # POST hit this URL before, the GET echoes the script.
        if any(is_form and u == url for u, kw in posts_made
               for is_form in [isinstance(kw.get("data"), dict)]):
            return _make_response(
                200,
                "<html><body>"
                "<p>nice list</p>"
                "<li>alice: <script>alert('ptai')</script></li>"
                "</body></html>",
            )
        return _make_response(200, "<html><body><p>empty</p></body></html>")

    fake_session.post.side_effect = post_side
    fake_session.get.side_effect = get_side

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/tasks/42",),
    )
    findings = await probe_stored_xss(ctx)

    task_findings = [f for f in findings if f["target"].endswith("/tasks/42")]
    assert task_findings, (
        f"expected stored XSS on /tasks/42 via form shape; got {findings}"
    )
    assert task_findings[0]["severity"] == "high"


@pytest.mark.asyncio
async def test_stored_xss_candidates_are_union_with_defaults(fake_session):
    """ctx.candidate_endpoints add to DEFAULT_CANDIDATES, don't replace them."""
    from engine.probes import ProbeContext
    from engine.probes.web.stored_xss import DEFAULT_CANDIDATES, probe_stored_xss

    fake_session.post.return_value = _make_response(400, "no")
    fake_session.get.return_value = _make_response(200, "nothing")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/custom/sink",),
    )
    await probe_stored_xss(ctx)

    posted_urls = {call.args[0] for call in fake_session.post.call_args_list}
    assert "http://localhost:3000/custom/sink" in posted_urls
    assert "http://localhost:3000/api/Feedbacks" in posted_urls
    assert "http://localhost:3000/tasks/1" in posted_urls
    # Path count = union (deduped); per path, 2 shapes × up to 5 fields
    expected_paths = len(set(list(DEFAULT_CANDIDATES) + ["/custom/sink"]))
    # Each path tries every (shape, field) until a 2xx fires, but here
    # every POST returns 400, so all combinations run: 2 shapes * 5 fields
    assert fake_session.post.call_count == expected_paths * 2 * 5


def test_stored_xss_is_registered():
    from engine.probes import registry
    from engine.probes.web import stored_xss  # noqa: F401  - import registers

    spec = registry.get("web.stored_xss")
    assert spec is not None
    assert spec.bug_class == "xss_stored"
    assert spec.severity_max == "high"
    assert spec.owasp == "A03:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 10.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "destructive-low" in spec.tags
    # Guard against the decorator getting accidentally attached to a
    # helper. The registered fn must be the probe entry point.
    assert spec.fn.__name__ == "probe_stored_xss"
