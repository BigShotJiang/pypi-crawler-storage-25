"""Tests for the meta-handlers (Step 3 of the autonomy roadmap)."""
from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest


@pytest.fixture
def fresh_memory():
    from engine.working_memory import WorkingMemory

    return WorkingMemory(engagement_id="e-test", target="http://localhost:3000")


@pytest.mark.asyncio
async def test_meta_crawl_adds_endpoints(fresh_memory):
    from engine.agents.handlers.meta import handle_crawl
    from engine.probes.recon.crawler import CrawlResult

    fake_crawl = CrawlResult(
        discovered_paths={"/about", "/contact"},
        discovered_js=set(),
        api_paths={"/api/users", "/api/products"},
        forms=[],
    )

    with patch(
        "engine.probes.recon.crawler.run_crawler",
        new=AsyncMock(return_value=fake_crawl),
    ), patch("engine.agents.handlers.meta.aiohttp.ClientSession"):
        obs = await handle_crawl(fresh_memory, {})

    assert obs.success is True
    assert obs.endpoints_added >= 4
    assert obs.normalized is not None
    assert obs.normalized.verdict == "confirmed"


@pytest.mark.asyncio
async def test_meta_crawl_forwards_captured_auth_headers(fresh_memory):
    """Regression: when an earlier probe in the engagement captured a
    session token (memory.captured_auth), meta.crawl must forward those
    headers to the crawler so authenticated routes (admin pages, /api/users,
    /internal/*) get discovered. Without this, every authenticated app's
    interesting endpoints stay invisible to the rest of the engagement.
    """
    from engine.agents.handlers.meta import handle_crawl
    from engine.probes.recon.crawler import CrawlResult

    fresh_memory.captured_auth = {
        "auth_header": "Authorization",
        "auth_value": "Bearer eyJhbGciOiJIUzI1NiJ9.fake.token",
        "kind": "bearer",
    }

    fake_crawl = CrawlResult(
        discovered_paths={"/admin/users"}, discovered_js=set(),
        api_paths={"/api/secrets"}, forms=[],
    )
    captured_headers = {}

    async def _spy_run_crawler(session, base, auth_headers=None):
        captured_headers["value"] = auth_headers
        return fake_crawl

    with patch(
        "engine.probes.recon.crawler.run_crawler", new=_spy_run_crawler,
    ), patch("engine.agents.handlers.meta.aiohttp.ClientSession"):
        obs = await handle_crawl(fresh_memory, {})

    assert obs.success is True
    assert captured_headers.get("value") is not None, (
        "meta.crawl must pass auth_headers when memory.captured_auth is set"
    )
    assert "Authorization" in captured_headers["value"], (
        f"expected Authorization header, got {captured_headers['value']!r}"
    )


@pytest.mark.asyncio
async def test_meta_crawl_handles_exception(fresh_memory):
    from engine.agents.handlers.meta import handle_crawl

    with patch(
        "engine.probes.recon.crawler.run_crawler",
        new=AsyncMock(side_effect=RuntimeError("boom")),
    ), patch("engine.agents.handlers.meta.aiohttp.ClientSession"):
        obs = await handle_crawl(fresh_memory, {})

    assert obs.success is False
    assert obs.normalized.verdict == "failed"
    assert "boom" in obs.normalized.evidence


@pytest.mark.asyncio
async def test_meta_set_auth_captures_token(fresh_memory):
    from engine.agents.handlers.meta import handle_set_auth

    fake_auth = {
        "token": "eyJhbGciOiJIUzI1NiJ9.fake.token",
        "kind": "jwt",
        "email": "test@example.com",
        "source_endpoint": "/rest/user/login",
        "role_hint": "customer",
    }

    with patch(
        "engine.probes.auth.runner.acquire_test_auth",
        new=AsyncMock(return_value=fake_auth),
    ), patch("engine.agents.handlers.meta.aiohttp.ClientSession"):
        obs = await handle_set_auth(fresh_memory, {})

    assert obs.success is True
    assert obs.auth_added == 1
    assert len(fresh_memory.captured_auth) == 1
    assert fresh_memory.captured_auth[0].kind == "jwt"
    assert obs.normalized.verdict == "confirmed"


@pytest.mark.asyncio
async def test_meta_set_auth_returns_failed_on_none(fresh_memory):
    from engine.agents.handlers.meta import handle_set_auth

    with patch(
        "engine.probes.auth.runner.acquire_test_auth",
        new=AsyncMock(return_value=None),
    ), patch("engine.agents.handlers.meta.aiohttp.ClientSession"):
        obs = await handle_set_auth(fresh_memory, {})

    assert obs.success is False
    assert obs.normalized.verdict == "failed"


@pytest.mark.asyncio
async def test_meta_validate_finding_returns_failed_on_unknown_id(fresh_memory):
    from engine.agents.handlers.meta import handle_validate_finding

    obs = await handle_validate_finding(
        fresh_memory, {"finding_id": "does-not-exist"}
    )
    assert obs.success is False
    assert "not in memory" in obs.normalized.evidence


@pytest.mark.asyncio
async def test_meta_validate_finding_returns_failed_on_missing_arg(fresh_memory):
    from engine.agents.handlers.meta import handle_validate_finding

    obs = await handle_validate_finding(fresh_memory, {})
    assert obs.success is False
    assert "missing finding_id" in obs.normalized.evidence


@pytest.mark.asyncio
async def test_meta_mutate_args_returns_failed_on_missing_action(fresh_memory):
    from engine.agents.handlers.meta import handle_mutate_args

    obs = await handle_mutate_args(fresh_memory, {})
    assert obs.success is False
    assert "missing action_name" in obs.normalized.evidence


@pytest.mark.asyncio
async def test_meta_mutate_args_returns_failed_on_unknown_handler(fresh_memory):
    from engine.agents.handlers.meta import handle_mutate_args

    obs = await handle_mutate_args(
        fresh_memory, {"action_name": "probe.does.not.exist"}
    )
    assert obs.success is False
    assert "unknown handler" in obs.normalized.evidence


@pytest.mark.asyncio
async def test_meta_mutate_args_invokes_existing_handler(fresh_memory):
    """When action_name resolves, the meta handler delegates and propagates result."""
    from engine.agent_loop import Observation, register_handler
    from engine.agents.handlers.meta import handle_mutate_args

    captured_args = {}

    async def fake_handler(memory, args):
        captured_args.update(args)
        return Observation(
            action_name="probe.fake.test",
            success=True,
            findings_added=2,
        )

    # Register a one-shot handler. clean up via try/finally.
    from engine.agent_loop import _HANDLERS

    if "probe.fake.test" in _HANDLERS:
        del _HANDLERS["probe.fake.test"]
    register_handler("probe.fake.test", fake_handler)
    try:
        obs = await handle_mutate_args(
            fresh_memory,
            {
                "action_name": "probe.fake.test",
                "extra_args": {"candidate_endpoints": ["/api/X"]},
            },
        )
        assert obs.success is True
        assert obs.findings_added == 2
        assert captured_args == {"candidate_endpoints": ["/api/X"]}
        assert obs.normalized.verdict == "confirmed"
    finally:
        del _HANDLERS["probe.fake.test"]


def test_register_meta_handlers_wires_all_four():
    from engine.agent_loop import _HANDLERS
    from engine.agents.handlers.meta import register_meta_handlers

    # Pre-clear in case prior tests registered them.
    for n in (
        "meta.crawl",
        "meta.set_auth",
        "meta.validate_finding",
        "meta.mutate_args",
    ):
        _HANDLERS.pop(n, None)

    registered = register_meta_handlers()
    assert "meta.crawl" in registered
    assert "meta.set_auth" in registered
    assert "meta.validate_finding" in registered
    assert "meta.mutate_args" in registered
    assert all(n in _HANDLERS for n in registered)


def test_register_default_handlers_wires_probes_and_meta():
    """register_default_handlers in the package init wires both tiers."""
    from engine.agent_loop import _HANDLERS
    from engine.agents.handlers import register_default_handlers

    # Clear meta handlers; register_default_handlers should re-add them.
    for n in (
        "meta.crawl",
        "meta.set_auth",
        "meta.validate_finding",
        "meta.mutate_args",
    ):
        _HANDLERS.pop(n, None)

    register_default_handlers()
    assert "meta.crawl" in _HANDLERS
    assert "meta.mutate_args" in _HANDLERS
