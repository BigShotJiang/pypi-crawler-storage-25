"""Tests for the XXE upload probe.

XXE (XML External Entity) is a high-impact bug class spanning file
disclosure, billion-laughs DoS, and parser-reachability hints. The
probe baselines a benign XML upload, then perturbs with a malicious
DOCTYPE entity and a recursive expansion, watching for /etc/passwd
disclosure, Windows system.ini disclosure, response-time blowup, or
DOCTYPE/entity error fingerprints in 500s.

Per-path the probe tries TWO request shapes: multipart/form-data (for
file-upload-style endpoints) and raw application/xml (for modern REST
endpoints like Flask's `request.get_data()` + lxml). Tests below use
a callable side_effect that emits explicit sequences for the URL+shape
under test and falls back to 404 for every other candidate path so the
9-entry ALWAYS_PROBED + candidate_endpoints union short-circuits
cleanly without mock exhaustion.
"""
from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


def _shape_of(headers: dict[str, str]) -> str:
    ct = headers.get("Content-Type", "")
    return "multipart" if "multipart/form-data" in ct else "raw"


def _picker(targeted: dict[tuple[str, str], list[Any]]):
    """Build a session.post side_effect that emits targeted sequences and
    falls back to a 404 baseline for any non-matching (url, shape) pair.

    `targeted` is keyed by (url, shape). Each call to session.post with a
    matching url+shape consumes the next response in the list; exhausting
    the list raises (caught by the probe's error handling). All other
    POSTs return a 404 so the probe skips that endpoint cleanly.
    """
    cursors: dict[tuple[str, str], int] = {k: 0 for k in targeted}

    def side_effect(url: str, *_args, **kwargs):
        shape = _shape_of(kwargs.get("headers") or {})
        key = (url, shape)
        if key in targeted and cursors[key] < len(targeted[key]):
            resp = targeted[key][cursors[key]]
            cursors[key] += 1
            return resp
        return _make_response(404, "Not Found")

    return side_effect


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_xxe_upload_critical_on_etc_passwd_disclosure(fake_session):
    """Body containing 'root:x:0:' after the malicious upload -> CRITICAL."""
    from engine.probes import ProbeContext
    from engine.probes.web.xxe_upload import probe_xxe_upload

    fake_session.post.side_effect = _picker({
        ("http://localhost:3000/file-upload", "multipart"): [
            _make_response(200, "ok"),  # baseline
            _make_response(
                200,
                "root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin",
            ),  # file-disclosure attack
        ],
    })
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/file-upload",),
    )

    findings = await probe_xxe_upload(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "xxe"
    assert "passwd" in f["title"].lower() or "file_disclosure" in f["title"]
    assert "root:x:0:" in f["evidence"]


@pytest.mark.asyncio
async def test_xxe_upload_critical_on_windows_systemini(fake_session):
    """Body containing '[boot loader]' -> CRITICAL Windows file disclosure."""
    from engine.probes import ProbeContext
    from engine.probes.web.xxe_upload import probe_xxe_upload

    fake_session.post.side_effect = _picker({
        ("http://localhost:3000/file-upload", "multipart"): [
            _make_response(200, "ok"),
            _make_response(
                200,
                "; for 16-bit app support\n[boot loader]\ntimeout=30\n[Mail]\nMAPI=1\n",
            ),
        ],
    })
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/file-upload",),
    )

    findings = await probe_xxe_upload(ctx)

    assert len(findings) == 1
    assert findings[0]["severity"] == "critical"
    assert "systemini" in findings[0]["title"] or "[boot loader]" in findings[0]["evidence"]


@pytest.mark.asyncio
async def test_xxe_upload_high_on_response_time_dos(fake_session, monkeypatch):
    """Attack response 6s after a 0.1s baseline -> HIGH (billion laughs).

    Drive _post_xml directly so we can fabricate elapsed timings without
    needing a real time.monotonic() spread across awaits. The fake
    short-circuits every non-/file-upload + non-multipart pair with a 404
    baseline so the 9-path union doesn't have to be hand-mocked.
    """
    from engine.probes import ProbeContext
    from engine.probes.web import xxe_upload as mod
    from engine.probes.web.xxe_upload import probe_xxe_upload

    target_url = "http://localhost:3000/file-upload"
    call_log: list[bytes] = []

    async def fake_post_xml(
        session,
        url,
        xml_bytes,
        *,
        shape: str = "multipart",
        extra_headers: dict[str, str] | None = None,
        timeout_s: float = 10.0,
    ):
        if url != target_url or shape != "multipart":
            return 404, {}, "", 0.0
        call_log.append(xml_bytes)
        # 1: baseline fast, 2: file-disclosure fast/no leak, 3: DoS slow.
        if len(call_log) == 1:
            return 200, {}, "ok", 0.1
        if len(call_log) == 2:
            return 200, {}, "ok", 0.1
        return 200, {}, "ok", 6.5

    monkeypatch.setattr(mod, "_post_xml", fake_post_xml)

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/file-upload",),
    )
    findings = await probe_xxe_upload(ctx)

    assert len(findings) == 1
    assert findings[0]["severity"] == "high"
    assert "billion_laughs" in findings[0]["title"] or "DoS" in findings[0]["title"]


@pytest.mark.asyncio
async def test_xxe_upload_no_finding_when_xml_rejected(fake_session):
    """400 baselines + 400 attack + 400 DoS on /file-upload, all shapes -> no findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.xxe_upload import probe_xxe_upload

    # Both shapes attempt baseline+attack+DoS; all 400 with body that
    # doesn't contain the DOCTYPE/entity 500-shape signature.
    bad_xml = [
        _make_response(400, "Bad XML"),
        _make_response(400, "Bad XML"),
        _make_response(400, "Bad XML"),
    ]
    fake_session.post.side_effect = _picker({
        ("http://localhost:3000/file-upload", "multipart"): list(bad_xml),
        ("http://localhost:3000/file-upload", "raw"): list(bad_xml),
    })
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/file-upload",),
    )

    findings = await probe_xxe_upload(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_xxe_upload_skips_endpoint_on_404(fake_session):
    """404 on baseline -> probe skips attack/dos for that shape on that endpoint.

    Both shapes baseline-404 for /file-upload AND every other candidate
    in the ALWAYS_PROBED union also gets the picker's default 404, so
    no findings emerge and the probe issues 2 POSTs per candidate path
    (one baseline per shape) and nothing else.
    """
    from engine.probes import ProbeContext
    from engine.probes.web.xxe_upload import ALWAYS_PROBED, probe_xxe_upload

    fake_session.post.side_effect = _picker({})  # everything 404s
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/file-upload",),
    )

    findings = await probe_xxe_upload(ctx)
    assert findings == []
    # 2 shapes × (ALWAYS_PROBED ∪ {/file-upload}); /file-upload is already
    # in ALWAYS_PROBED so the union size equals len(ALWAYS_PROBED).
    assert fake_session.post.call_count == 2 * len(ALWAYS_PROBED)


@pytest.mark.asyncio
async def test_xxe_upload_fires_on_raw_xml_body_with_etc_passwd(fake_session):
    """Multipart rejected with 415, raw application/xml leaks /etc/passwd -> CRITICAL.

    Models TaskFlow's /api/import: reads request.get_data() and parses
    with lxml.resolve_entities=True. Won't accept multipart bodies (the
    boundary header breaks the XML parse) but happily resolves entities
    when the body is raw XML.
    """
    from engine.probes import ProbeContext
    from engine.probes.web.xxe_upload import probe_xxe_upload

    target = "http://localhost:4000/api/import"
    fake_session.post.side_effect = _picker({
        # Multipart shape: 415 on baseline, probe skips to next shape.
        # (No, actually: 415 != (0, 404), so probe DOES try the attack.
        # We return 415 again, and _classify gets status=415, body short,
        # no time delta -> None, no finding emitted. Then DoS likewise.
        # That's fine, the multipart path produces no finding.)
        (target, "multipart"): [
            _make_response(415, "Unsupported Media Type"),  # baseline
            _make_response(415, "Unsupported Media Type"),  # attack
            _make_response(415, "Unsupported Media Type"),  # dos
        ],
        # Raw shape: baseline accepted, attack leaks /etc/passwd.
        (target, "raw"): [
            _make_response(200, '{"ok":true,"text":"baseline"}'),
            _make_response(
                200,
                '{"ok":true,"text":"root:x:0:0:root:/root:/bin/bash"}',
            ),
        ],
    })
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:4000",
        candidate_endpoints=("/api/import",),
    )

    findings = await probe_xxe_upload(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "xxe"
    assert f["target"].endswith("/api/import")
    assert "root:x:0:" in f["evidence"]


@pytest.mark.asyncio
async def test_xxe_upload_propagates_cookie_auth_header(fake_session):
    """captured_auth with kind=cookie -> every POST carries Cookie header."""
    from engine.probes import ProbeContext
    from engine.probes.web.xxe_upload import probe_xxe_upload

    fake_session.post.side_effect = _picker({})  # all 404, just inspect headers
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:4000",
        candidate_endpoints=("/api/import",),
        captured_auth={"kind": "cookie", "token": "session=abc123"},
    )

    await probe_xxe_upload(ctx)

    assert fake_session.post.call_count > 0
    for call in fake_session.post.call_args_list:
        headers = call.kwargs.get("headers") or {}
        assert headers.get("Cookie") == "session=abc123", (
            f"missing/wrong Cookie header in call: {call}"
        )


@pytest.mark.asyncio
async def test_xxe_upload_candidates_are_union_with_always_probed(fake_session):
    """candidate_endpoints + ALWAYS_PROBED both get probed (union, not replace)."""
    from engine.probes import ProbeContext
    from engine.probes.web.xxe_upload import ALWAYS_PROBED, probe_xxe_upload

    fake_session.post.side_effect = _picker({})
    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/foo/custom",),
    )

    await probe_xxe_upload(ctx)

    posted_urls = {
        call.args[0] for call in fake_session.post.call_args_list
    }
    # Custom path was probed:
    assert "http://localhost:3000/foo/custom" in posted_urls
    # And ALWAYS_PROBED defenses still ran:
    assert "http://localhost:3000/file-upload" in posted_urls
    assert "http://localhost:3000/api/import" in posted_urls
    # Sanity: total POST count == 2 shapes × (custom + ALWAYS_PROBED, deduped)
    expected_paths = len(set(list(ALWAYS_PROBED) + ["/foo/custom"]))
    assert fake_session.post.call_count == 2 * expected_paths


def test_xxe_upload_is_registered():
    """Registry metadata test: name, bug_class, severity_max, owasp, tags.

    The autouse conftest fixture restores a snapshot taken before importing
    `engine.probes.web` (which doesn't include xxe_upload), so we have to
    force the decorator to run again by re-executing the module.
    """
    import importlib
    import sys

    from engine.probes import registry

    sys.modules.pop("engine.probes.web.xxe_upload", None)
    importlib.import_module("engine.probes.web.xxe_upload")

    spec = registry.get("web.xxe_upload")
    assert spec is not None
    assert spec.name == "web.xxe_upload"
    assert spec.bug_class == "xxe"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A05:2021"
    assert spec.requires_auth is False
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "destructive-low" in spec.tags
    assert spec.runtime_budget_s == 15.0
