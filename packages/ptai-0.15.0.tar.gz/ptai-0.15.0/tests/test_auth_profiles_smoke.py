"""Profile load + flow-executor-coverage smoke test."""
from __future__ import annotations

import pytest

from cli.auth_profiles import VALID_FLOWS
from engine.auth_session import WebAuthenticator, AuthError


# Profile-level flows (from VALID_FLOWS) that have a runtime executor.
# `bearer_static` is an internal/legacy runtime flow not exposed in profiles.
IMPLEMENTED_FLOWS = {"form_post", "bearer"}


def test_implemented_flows_subset_of_valid_flows():
    assert IMPLEMENTED_FLOWS.issubset(VALID_FLOWS)


@pytest.mark.parametrize("flow", sorted(IMPLEMENTED_FLOWS))
@pytest.mark.asyncio
async def test_implemented_flow_does_not_raise_unsupported(flow):
    """Each implemented flow should dispatch to its own executor, not raise 'unsupported'."""
    auth = WebAuthenticator(
        flow=flow,
        login_url="http://localhost:0/login",
        username="x", password="y",
        body_shape="json", token_path="token",
    )
    with pytest.raises(AuthError) as ei:
        await auth.login()
    assert "unsupported auth flow" not in str(ei.value), (
        f"flow {flow!r} dispatched to the default unsupported branch"
    )


@pytest.mark.parametrize("flow", sorted(VALID_FLOWS - IMPLEMENTED_FLOWS))
@pytest.mark.asyncio
async def test_unimplemented_flow_raises_unsupported(flow):
    """Flows declared in VALID_FLOWS but not implemented MUST raise 'unsupported'."""
    auth = WebAuthenticator(flow=flow)
    with pytest.raises(AuthError, match="unsupported auth flow"):
        await auth.login()
