"""Tests for the leaked-credentials JS bundle probe.

The probe runs the crawler to find same-origin JS bundles, fetches each
with the wider 2 MiB envelope, scans for credential patterns, and where
it finds an email plus password pair tries the login endpoint. A 200
with a token-shaped body lifts the finding to critical.

These tests stub the crawler and the wide GET so the probe runs in
pure Python with no network. Login confirmation goes through the
standard `http_post_json` primitive, so the aiohttp-style session mock
covers it the same way the cors_reflection tests do.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from engine.probes.recon.crawler import CrawlResult


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


def _patch_crawler_and_get(
    monkeypatch,
    *,
    js_paths: tuple[str, ...],
    bundle_bodies: dict[str, str],
):
    """Stub run_crawler to return the given js paths and _http_get_full to
    return the right body per URL. Both are imported inside the probe
    module so we patch on that module."""
    from engine.probes.web import leaked_credentials as mod

    async def fake_run_crawler(session, base):
        return CrawlResult(discovered_js=set(js_paths))

    async def fake_http_get_full(session, url):
        for path, body in bundle_bodies.items():
            if url.endswith(path):
                return 200, body
        return 0, ""

    monkeypatch.setattr(mod, "run_crawler", fake_run_crawler)
    monkeypatch.setattr(mod, "_http_get_full", fake_http_get_full)


# -----------------------------------------------------------------------------
# 1. Email + password leaked + login succeeds -> critical
# -----------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_leaked_credentials_critical_when_login_succeeds(
    fake_session, monkeypatch
):
    from engine.probes import ProbeContext
    from engine.probes.web.leaked_credentials import probe_leaked_credentials

    bundle = """
    var creds = { email: "amy@juice-sh.op", password: "K1f.....2!" };
    """
    _patch_crawler_and_get(
        monkeypatch,
        js_paths=("/static/main.bundle.js",),
        bundle_bodies={"/static/main.bundle.js": bundle},
    )

    # The login POST must return a token-shaped body.
    fake_session.post.return_value = _make_response(
        200, '{"authentication": {"token": "ey.eee.eee"}}'
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_leaked_credentials(ctx)

    critical = [f for f in findings if f["severity"] == "critical"]
    assert len(critical) == 1
    assert "amy@juice-sh.op" in critical[0]["title"]
    assert critical[0]["category"] == "exposure"
    assert critical[0]["bug_class"] == "source_map_exposure"
    assert critical[0]["leaked_value"] == "amy@juice-sh.op:K1f.....2!"


# -----------------------------------------------------------------------------
# 2. API key but no email+password pair -> high
# -----------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_leaked_credentials_high_for_api_key_no_pair(
    fake_session, monkeypatch
):
    from engine.probes import ProbeContext
    from engine.probes.web.leaked_credentials import probe_leaked_credentials

    bundle = """
    const config = { apiKey: "PTAITESTFAKEKEY1234567890ABCD" };
    """
    _patch_crawler_and_get(
        monkeypatch,
        js_paths=("/static/main.bundle.js",),
        bundle_bodies={"/static/main.bundle.js": bundle},
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_leaked_credentials(ctx)

    assert len(findings) == 1
    assert findings[0]["severity"] == "high"
    assert "API key" in findings[0]["title"]
    assert findings[0]["leaked_value"] == "PTAITESTFAKEKEY1234567890ABCD"
    # No login attempt was made.
    fake_session.post.assert_not_called()


# -----------------------------------------------------------------------------
# 3. Clean JS bundle -> no findings
# -----------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_leaked_credentials_no_findings_for_clean_bundle(
    fake_session, monkeypatch
):
    from engine.probes import ProbeContext
    from engine.probes.web.leaked_credentials import probe_leaked_credentials

    bundle = """
    function add(a, b) { return a + b; }
    var greeting = "hello";
    """
    _patch_crawler_and_get(
        monkeypatch,
        js_paths=("/static/main.bundle.js",),
        bundle_bodies={"/static/main.bundle.js": bundle},
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_leaked_credentials(ctx)

    assert findings == []


# -----------------------------------------------------------------------------
# 4. Crawler returns no JS bundles -> no findings, no errors
# -----------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_leaked_credentials_handles_empty_crawl(fake_session, monkeypatch):
    from engine.probes import ProbeContext
    from engine.probes.web.leaked_credentials import probe_leaked_credentials

    _patch_crawler_and_get(monkeypatch, js_paths=(), bundle_bodies={})

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_leaked_credentials(ctx)

    assert findings == []


# -----------------------------------------------------------------------------
# 5. Pair present but login fails -> high (still a leak, just stale)
# -----------------------------------------------------------------------------
@pytest.mark.asyncio
async def test_leaked_credentials_high_when_login_fails(
    fake_session, monkeypatch
):
    from engine.probes import ProbeContext
    from engine.probes.web.leaked_credentials import probe_leaked_credentials

    bundle = """
    var dev = { email: "dev@example.com", password: "stalepw123" };
    """
    _patch_crawler_and_get(
        monkeypatch,
        js_paths=("/static/main.bundle.js",),
        bundle_bodies={"/static/main.bundle.js": bundle},
    )

    # Login returns 401 / non-token body.
    fake_session.post.return_value = _make_response(
        401, '{"error": "invalid credentials"}'
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_leaked_credentials(ctx)

    assert len(findings) == 1
    assert findings[0]["severity"] == "high"
    assert "Hardcoded credentials" in findings[0]["title"]
    assert findings[0]["leaked_value"] == "dev@example.com:stalepw123"


# -----------------------------------------------------------------------------
# 6. Registration metadata
# -----------------------------------------------------------------------------
def test_leaked_credentials_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import leaked_credentials

    # The autouse registry-isolation fixture restores a snapshot taken
    # before this test runs. If a prior test already imported the module,
    # `sys.modules` has it cached and the decorator never re-fires, so
    # the snapshot can be missing this probe. Reload to guarantee the
    # decorator runs against the current registry.
    if registry.get("web.leaked_credentials") is None:
        importlib.reload(leaked_credentials)

    spec = registry.get("web.leaked_credentials")
    assert spec is not None
    assert spec.bug_class == "source_map_exposure"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A05:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 20.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "secrets" in spec.tags
