"""Tests for the SecurityTool → agent-loop bridge.

These tests exercise the per-tool handler factory, the `tool.run` and
`tool.list` meta-handlers, scope-guard / not-installed / timeout-cap edges,
and idempotent registration.
"""
from __future__ import annotations

import pytest

from engine.agent_loop import _HANDLERS, Observation
from engine.agents.handlers.tool_bridge import (
    _AGGRESSIVE_TOOLS,
    _STDOUT_SNIPPET_MAX,
    _TIMEOUT_HARD_CAP_S,
    handle_tool_list,
    handle_tool_run,
    make_handler_for_tool,
    register_all_tools,
)
from engine.working_memory import make_working_memory
from tools.registry import SecurityTool


def _mk_memory():
    return make_working_memory("test-engagement", "http://127.0.0.1:9999")


def _mk_tool(name: str = "fakeprobe", *, installed: bool = True) -> SecurityTool:
    """Stub SecurityTool with controllable install state and execute()."""
    tool = SecurityTool(
        name=name,
        category="network",
        description=f"stub {name}",
        command=name,
    )
    if installed:
        tool.is_installed = lambda: True  # type: ignore[method-assign]
    else:
        tool.is_installed = lambda: False  # type: ignore[method-assign]
    return tool


def _ok_exec_result(findings: list[dict] | None = None, stdout: str = "ok") -> dict:
    return {
        "tool": "fakeprobe",
        "target": "http://127.0.0.1:9999",
        "exit_code": 0,
        "stdout": stdout,
        "stderr": "",
        "duration": 0.01,
        "findings": findings or [],
        "cache_hit": False,
    }


@pytest.mark.asyncio
async def test_handle_tool_run_unknown_tool_returns_failed():
    """The generic dispatcher returns a clear error for an unknown tool name."""
    memory = _mk_memory()
    obs = await handle_tool_run(memory, {"tool": "nonexistent_xyz"})
    assert isinstance(obs, Observation)
    assert obs.success is False
    assert "unknown tool" in obs.error
    assert obs.normalized.verdict == "failed"


@pytest.mark.asyncio
async def test_handle_tool_run_missing_tool_arg():
    """`tool.run` without a `tool` arg returns a clear validation error."""
    memory = _mk_memory()
    obs = await handle_tool_run(memory, {})
    assert obs.success is False
    assert "missing 'tool'" in obs.error


@pytest.mark.asyncio
async def test_handler_for_not_installed_returns_install_hint():
    """A tool that's not on PATH yields verdict=failed and surfaces an install_hint."""
    spec = _mk_tool("fakeghost", installed=False)
    handler = make_handler_for_tool(spec)
    memory = _mk_memory()
    obs = await handler(memory, {})
    assert obs.success is False
    assert "not installed" in obs.error
    assert "install_hint" in obs.raw
    assert obs.normalized.verdict == "failed"


@pytest.mark.asyncio
async def test_handler_normalization_caps_evidence():
    """Findings produce a NormalizedResult that respects evidence/snippet caps."""
    spec = _mk_tool("fakecap")
    huge_title = "T" * 500
    huge_evidence = "E" * 500

    async def stub_execute(target, args=None, timeout=600.0):
        return _ok_exec_result(
            findings=[
                {
                    "title": huge_title,
                    "severity": "high",
                    "category": "vulnerability",
                    "evidence": huge_evidence,
                    "target": target,
                }
            ]
        )

    spec.execute = stub_execute  # type: ignore[method-assign]
    handler = make_handler_for_tool(spec)
    obs = await handler(_mk_memory(), {})
    assert obs.success
    # NormalizedResult.__post_init__ truncates evidence to <=120 and snippet to <=200
    assert obs.normalized.evidence is not None
    assert len(obs.normalized.evidence) <= 120
    if obs.normalized.response_snippet is not None:
        assert len(obs.normalized.response_snippet) <= 200
    # raw.findings keeps the full set
    assert len(obs.raw["findings"]) == 1


@pytest.mark.asyncio
async def test_handler_stdout_snippet_capped():
    """Raw stdout returned to the caller is truncated to the snippet max."""
    spec = _mk_tool("fakebulk")

    async def stub_execute(target, args=None, timeout=600.0):
        return _ok_exec_result(stdout="X" * (_STDOUT_SNIPPET_MAX + 1000))

    spec.execute = stub_execute  # type: ignore[method-assign]
    handler = make_handler_for_tool(spec)
    obs = await handler(_mk_memory(), {})
    assert len(obs.raw["stdout_snippet"]) == _STDOUT_SNIPPET_MAX


@pytest.mark.asyncio
async def test_handler_does_not_call_mark_tried():
    """Tool categories aren't in BUG_CLASSES; ensure no ValueError from mark_tried."""
    spec = _mk_tool("fakecov")

    async def stub_execute(target, args=None, timeout=600.0):
        return _ok_exec_result(
            findings=[
                {
                    "title": "thing",
                    "severity": "medium",
                    "category": "network",  # NOT a BUG_CLASSES entry
                    "target": target,
                }
            ]
        )

    spec.execute = stub_execute  # type: ignore[method-assign]
    handler = make_handler_for_tool(spec)
    memory = _mk_memory()
    obs = await handler(memory, {})
    # No ValueError raised, finding recorded, coverage NOT mutated.
    assert obs.success
    assert obs.findings_added == 1
    assert memory.coverage.stats()["tried_pairs"] == 0


@pytest.mark.asyncio
async def test_handler_timeout_cap_applied():
    """A caller-supplied timeout above the hard cap gets clamped."""
    spec = _mk_tool("faketmo")
    seen_timeout = {}

    async def stub_execute(target, args=None, timeout=600.0):
        seen_timeout["v"] = timeout
        return _ok_exec_result()

    spec.execute = stub_execute  # type: ignore[method-assign]
    handler = make_handler_for_tool(spec)
    await handler(_mk_memory(), {"timeout_s": 999_999})
    assert seen_timeout["v"] == _TIMEOUT_HARD_CAP_S


@pytest.mark.asyncio
async def test_handler_scope_block_rejects_before_execute():
    """An off-scope target trips the scope guard and never reaches execute()."""
    from engine.scope import ScopeEnforcer, set_current_scope

    spec = _mk_tool("fakescope")

    called = {"n": 0}

    async def stub_execute(target, args=None, timeout=600.0):
        called["n"] += 1
        return _ok_exec_result()

    spec.execute = stub_execute  # type: ignore[method-assign]
    handler = make_handler_for_tool(spec)
    memory = _mk_memory()

    # Lock scope to a different host than memory.target.
    scope = ScopeEnforcer(
        allowed_targets=["other.example.com"],
        allowed_ports=None,
        mode="strict",
    )
    token = set_current_scope(scope)
    try:
        obs = await handler(memory, {"target": "http://evil.example.com"})
    finally:
        from engine.scope import _current_scope

        _current_scope.reset(token)

    assert obs.success is False
    assert "scope blocked" in obs.error
    assert called["n"] == 0


@pytest.mark.asyncio
async def test_aggressive_tool_gated_on_normal_intensity():
    """Aggressive tools refuse to run when memory.intensity is set and != aggressive."""
    spec = _mk_tool("sqlmap")  # in _AGGRESSIVE_TOOLS
    assert "sqlmap" in _AGGRESSIVE_TOOLS

    called = {"n": 0}

    async def stub_execute(target, args=None, timeout=600.0):
        called["n"] += 1
        return _ok_exec_result()

    spec.execute = stub_execute  # type: ignore[method-assign]
    handler = make_handler_for_tool(spec)
    memory = _mk_memory()
    memory.intensity = "normal"  # type: ignore[attr-defined]
    obs = await handler(memory, {})
    assert obs.success is False
    assert "intensity gate" in obs.error
    assert called["n"] == 0


@pytest.mark.asyncio
async def test_aggressive_tool_allowed_when_memory_lacks_intensity():
    """If WorkingMemory doesn't carry an intensity field, the gate is dormant."""
    spec = _mk_tool("sqlmap")

    async def stub_execute(target, args=None, timeout=600.0):
        return _ok_exec_result()

    spec.execute = stub_execute  # type: ignore[method-assign]
    handler = make_handler_for_tool(spec)
    memory = _mk_memory()
    # Do NOT set memory.intensity.
    obs = await handler(memory, {})
    assert obs.success is True


@pytest.mark.asyncio
async def test_handle_tool_list_installed_only_filters():
    """tool.list with installed_only=True excludes non-installed wrappers."""
    memory = _mk_memory()
    obs = await handle_tool_list(memory, {"installed_only": True})
    assert obs.success
    for entry in obs.raw["tools"]:
        assert entry["installed"] is True


@pytest.mark.asyncio
async def test_handle_tool_list_by_category():
    """tool.list filters by category when provided."""
    memory = _mk_memory()
    obs = await handle_tool_list(memory, {"category": "network", "installed_only": False})
    assert obs.success
    for entry in obs.raw["tools"]:
        assert entry["category"] == "network" or "network" in entry.get("extra_categories", [])


def test_register_all_tools_idempotent():
    """Re-registering with force=False is a no-op for existing names."""
    # The handlers module imports register_default_handlers, which calls
    # register_all_tools() already. Repeat with force=False to assert no-op.
    register_all_tools(force=False)
    second = register_all_tools(force=False)
    assert second == [], f"second call should be no-op; got {second[:5]}..."
    # And the meta handlers we expect are present.
    assert "tool.run" in _HANDLERS
    assert "tool.list" in _HANDLERS
    assert "tool.plan" in _HANDLERS
    assert "tool.ensure_installed" in _HANDLERS


@pytest.mark.asyncio
async def test_handle_tool_plan_static_fallback():
    """tool.plan with no agent returns the static map for the scope."""
    from engine.agents.handlers.tool_bridge import handle_tool_plan

    memory = _mk_memory()
    obs = await handle_tool_plan(memory, {"scope": "web"})
    assert obs.success
    predicted = obs.raw["predicted"]
    assert isinstance(predicted, list)
    # Static map includes wpscan/dalfox for web.
    assert "wpscan" in predicted or "dalfox" in predicted


@pytest.mark.asyncio
async def test_handle_tool_ensure_installed_empty_list():
    """Empty tools list returns success with no work done."""
    from engine.agents.handlers.tool_bridge import handle_tool_ensure_installed

    memory = _mk_memory()
    obs = await handle_tool_ensure_installed(memory, {"tools": []})
    assert obs.success
    assert obs.raw["results"] == []


@pytest.mark.asyncio
async def test_handle_tool_ensure_installed_all_present(monkeypatch):
    """When every requested tool is already installed, no prompt fires."""
    from engine.agents.handlers import tool_bridge

    # Force the audit to report every tool as installed.
    monkeypatch.setattr(
        "engine.tool_installer.audit_named",
        lambda names: {"installed": list(names), "missing": [], "unknown": []},
    )
    # If any prompt fires, the test will fail with a hang or detect call.
    monkeypatch.setattr(
        "engine.async_prompt.prompt_with_timeout",
        lambda *a, **k: (_ for _ in ()).throw(AssertionError("prompt should not fire")),
    )

    obs = await tool_bridge.handle_tool_ensure_installed(
        _mk_memory(), {"tools": ["nuclei", "nmap"], "interactive": True}
    )
    assert obs.success
    assert obs.raw["results"] == []


@pytest.mark.asyncio
async def test_handle_tool_ensure_installed_non_interactive_skips(monkeypatch):
    """Non-interactive mode + auto_install=False = skip silently."""
    from engine.agents.handlers import tool_bridge

    monkeypatch.setenv("PTAI_NON_INTERACTIVE", "1")
    monkeypatch.setattr(
        "engine.tool_installer.audit_named",
        lambda names: {"installed": [], "missing": list(names), "unknown": []},
    )
    # auto_install defaults to False
    from engine.install_preferences import InstallPreferences

    monkeypatch.setattr(
        "engine.install_preferences.load", lambda *a, **k: InstallPreferences()
    )

    install_called = {"n": 0}

    def trap_install(name, sudo_password=None):
        install_called["n"] += 1
        return True, "ok"

    monkeypatch.setattr("engine.tool_installer.install_tool_by_name", trap_install)

    obs = await tool_bridge.handle_tool_ensure_installed(
        _mk_memory(), {"tools": ["nuclei"], "interactive": True}
    )
    assert obs.success
    assert obs.raw["decision"] == "skipped_non_interactive"
    assert install_called["n"] == 0


@pytest.mark.asyncio
async def test_handle_tool_ensure_installed_user_declines(monkeypatch):
    """User responds 'n' → tools recorded as denied for future engagements."""
    from engine.agents.handlers import tool_bridge
    from engine.install_preferences import InstallPreferences

    monkeypatch.setenv("PTAI_NON_INTERACTIVE", "")
    monkeypatch.setattr("engine.async_prompt.is_non_interactive", lambda: False)
    monkeypatch.setattr(
        "engine.tool_installer.audit_named",
        lambda names: {"installed": [], "missing": list(names), "unknown": []},
    )
    monkeypatch.setattr(
        "engine.install_preferences.load", lambda *a, **k: InstallPreferences()
    )
    saved: dict[str, list[str]] = {}

    def fake_save(prefs, path=None):
        saved["denied"] = list(prefs.denied_tools)
        return path

    monkeypatch.setattr("engine.install_preferences.save", fake_save)

    async def fake_prompt(*a, **k):
        return "n"

    monkeypatch.setattr("engine.async_prompt.prompt_with_timeout", fake_prompt)

    install_called = {"n": 0}

    def trap_install(name, sudo_password=None):
        install_called["n"] += 1
        return True, "ok"

    monkeypatch.setattr("engine.tool_installer.install_tool_by_name", trap_install)

    obs = await tool_bridge.handle_tool_ensure_installed(
        _mk_memory(), {"tools": ["wpscan", "dalfox"], "interactive": True}
    )
    assert obs.success
    assert obs.raw["decision"] == "user_declined"
    assert install_called["n"] == 0
    assert saved.get("denied") == ["wpscan", "dalfox"]
