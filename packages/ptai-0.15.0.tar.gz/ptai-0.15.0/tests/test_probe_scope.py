"""Tests for opt-in strict_scope enforcement.

When the engagement was started with strict_scope=True, primitives
refuse any request whose host is outside the engagement target and
disable redirect-following so a 302 to attacker.com cannot pull the
scan off-target.

Default (no extras attached, or strict_scope unset) preserves today's
behavior end to end.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    s = MagicMock()
    s._ptai_extras = None
    return s


# ---------- host_allowed helper ----------


def test_host_allowed_same_host_passes():
    from engine.probes._safety import host_allowed
    assert host_allowed("http://target.example/x", "http://target.example") is True


def test_host_allowed_different_host_fails():
    from engine.probes._safety import host_allowed
    assert host_allowed("http://attacker.example/x", "http://target.example") is False


def test_host_allowed_different_ports_still_same_host():
    """A target on port 8080 should match a request to that host on any
    port; we compare hostnames, not netloc."""
    from engine.probes._safety import host_allowed
    assert host_allowed("http://target.example/x", "http://target.example:8080") is True


def test_host_allowed_empty_target_means_no_enforcement():
    from engine.probes._safety import host_allowed
    assert host_allowed("http://anything.example/x", "") is True


def test_host_allowed_case_insensitive():
    from engine.probes._safety import host_allowed
    assert host_allowed("http://Target.Example/x", "http://target.example") is True


# ---------- primitives integration ----------


@pytest.mark.asyncio
async def test_http_get_blocks_off_host_when_strict_scope(fake_session):
    """Off-host request under strict_scope: primitive returns (0, {}, '')
    and does NOT call session.get at all."""
    from engine.probes.primitives import http_get
    fake_session._ptai_extras = {
        "strict_scope": True,
        "engagement_target": "http://target.example",
    }

    status, _, body = await http_get(fake_session, "http://attacker.example/")

    assert status == 0
    assert body == ""
    fake_session.get.assert_not_called()


@pytest.mark.asyncio
async def test_http_get_allows_same_host_under_strict_scope(fake_session):
    from engine.probes.primitives import http_get
    fake_session._ptai_extras = {
        "strict_scope": True,
        "engagement_target": "http://target.example",
    }
    fake_session.get.return_value = _make_response(200, "ok", {})

    status, _, body = await http_get(fake_session, "http://target.example/x")
    assert status == 200
    fake_session.get.assert_called_once()


@pytest.mark.asyncio
async def test_http_get_off_host_succeeds_when_strict_scope_off(fake_session):
    """Default sessions (no strict_scope): off-host requests pass through."""
    from engine.probes.primitives import http_get
    fake_session.get.return_value = _make_response(200, "off-host ok", {})

    status, _, body = await http_get(fake_session, "http://attacker.example/")
    assert status == 200
    assert body == "off-host ok"


@pytest.mark.asyncio
async def test_http_post_form_disables_redirect_when_strict_scope(fake_session):
    """Under strict_scope, http_post_form forces allow_redirects=False to
    prevent host-changing 302s. The caller passes allow_redirects=True
    (the default) but the primitive overrides."""
    from engine.probes.primitives import http_post_form
    fake_session._ptai_extras = {
        "strict_scope": True,
        "engagement_target": "http://target.example",
    }
    fake_session.post.return_value = _make_response(200, "form ok", {})

    await http_post_form(fake_session, "http://target.example/x", {"a": "b"})

    call = fake_session.post.call_args
    assert call.kwargs["allow_redirects"] is False


@pytest.mark.asyncio
async def test_http_post_form_keeps_redirect_when_strict_scope_off(fake_session):
    """Default behavior preserved: form POSTs still follow redirects."""
    from engine.probes.primitives import http_post_form
    fake_session.post.return_value = _make_response(200, "form ok", {})

    await http_post_form(fake_session, "http://anywhere.example/x", {"a": "b"})

    call = fake_session.post.call_args
    assert call.kwargs["allow_redirects"] is True
