"""Tests for the SQLi login-bypass probe.

The probe POSTs classic auth-bypass payloads at /login-style endpoints
and detects bypass via three signals on the attack response that are
absent from the wrong-password baseline: a new session cookie, a 3xx
redirect to a non-login URL, or a status flip (401/403 -> 200) with
logged-in markers in the body.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

# Force the @registry.probe decorator to run before the autouse fixture
# snapshots the registry.
from engine.probes.web import sqli_login_bypass as _slb  # noqa: F401


def _make_response(
    status: int, body: str, headers: dict[str, str] | None = None,
):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


def _picker(targeted: dict[str, list]):
    """side_effect picker: targeted[url] sequence else default 404."""
    cursors = {url: 0 for url in targeted}

    def _side(url, *_args, **_kwargs):
        if url in targeted and cursors[url] < len(targeted[url]):
            resp = targeted[url][cursors[url]]
            cursors[url] += 1
            return resp
        return _make_response(404, "not found")

    return _side


@pytest.mark.asyncio
async def test_login_bypass_critical_on_session_cookie_minted(fake_session):
    """Attack response carries a Set-Cookie session= that baseline didn't."""
    from engine.probes import ProbeContext
    from engine.probes.web.sqli_login_bypass import probe_sqli_login_bypass

    url = "http://localhost:3000/login"
    fake_session.post.side_effect = _picker({
        url: [
            # Baseline: wrong credentials -> 401, no cookie.
            _make_response(401, '{"error":"bad credentials"}'),
            # Attack: bypass works -> 200 + session cookie.
            _make_response(
                200, '{"ok":true}',
                headers={"Set-Cookie": "session=eyJ1aWQiOjF9; HttpOnly"},
            ),
        ],
    })

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_sqli_login_bypass(ctx)

    login_hits = [f for f in findings if f["target"].endswith("/login")]
    assert login_hits, f"expected bypass finding; got {findings}"
    assert login_hits[0]["severity"] == "critical"
    assert login_hits[0]["bug_class"] == "sqli"
    assert "session" in login_hits[0]["evidence"].lower()


@pytest.mark.asyncio
async def test_login_bypass_critical_on_redirect_to_non_login(fake_session):
    """Attack 302s to /dashboard while baseline 200s the login form."""
    from engine.probes import ProbeContext
    from engine.probes.web.sqli_login_bypass import probe_sqli_login_bypass

    url = "http://localhost:3000/login"
    fake_session.post.side_effect = _picker({
        url: [
            _make_response(200, "<html>login form</html>"),
            _make_response(
                302, "",
                headers={"Location": "/dashboard"},
            ),
        ],
    })

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_sqli_login_bypass(ctx)

    login_hits = [f for f in findings if f["target"].endswith("/login")]
    assert login_hits
    assert login_hits[0]["severity"] == "critical"
    assert "redirect" in login_hits[0]["evidence"].lower() or "dashboard" in login_hits[0]["evidence"].lower()


@pytest.mark.asyncio
async def test_login_bypass_no_finding_when_baseline_also_succeeds(fake_session):
    """Both baseline and attack mint a session: nothing distinguishes them."""
    from engine.probes import ProbeContext
    from engine.probes.web.sqli_login_bypass import probe_sqli_login_bypass

    cookie_resp = _make_response(
        200, "ok", headers={"Set-Cookie": "session=abc"},
    )
    fake_session.post.return_value = cookie_resp  # every POST returns same

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_sqli_login_bypass(ctx)

    login_hits = [f for f in findings if f["target"].endswith("/login")]
    assert login_hits == [], (
        f"unexpected finding when baseline already succeeds: {login_hits}"
    )


@pytest.mark.asyncio
async def test_login_bypass_no_finding_when_redirect_back_to_login(fake_session):
    """302 to /login (failed-auth redirect) must NOT be flagged."""
    from engine.probes import ProbeContext
    from engine.probes.web.sqli_login_bypass import probe_sqli_login_bypass

    failed_redirect = _make_response(
        302, "", headers={"Location": "/login?error=1"},
    )
    fake_session.post.return_value = failed_redirect

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_sqli_login_bypass(ctx)

    login_hits = [f for f in findings if f["target"].endswith("/login")]
    assert login_hits == []


def test_login_bypass_is_registered():
    from engine.probes import registry

    spec = registry.get("web.sqli_login_bypass")
    assert spec is not None
    assert spec.bug_class == "sqli"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A07:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 20.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "auth" in spec.tags
