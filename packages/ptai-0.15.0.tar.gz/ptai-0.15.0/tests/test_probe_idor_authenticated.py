"""Tests for the authenticated IDOR probe.

The probe uses a captured session token to look up the user's own
basket/order/memory/card/address record, then probes adjacent IDs to
see if the server returns a different user's data to the same token.
The hit signal is `200 + JSON body + UserId differs from own user's id`.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {"Content-Type": "application/json"}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.fixture
def captured_auth():
    return {
        "token": "x",
        "auth_header": "Authorization",
        "auth_value": "Bearer x",
        "user_id": 1,
    }


@pytest.mark.asyncio
async def test_returns_empty_when_no_captured_auth(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.idor_authenticated import probe_idor_authenticated

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=None,
    )

    findings = await probe_idor_authenticated(ctx)

    assert findings == []
    # Must short-circuit; never touch the session.
    fake_session.get.assert_not_called()


@pytest.mark.asyncio
async def test_idor_found_on_baskets_when_neighbor_user_differs(
    fake_session, captured_auth
):
    """Own basket is id=2 owned by UserId=7; neighbor id=3 owned by UserId=8."""
    from engine.probes import ProbeContext
    from engine.probes.web.idor_authenticated import probe_idor_authenticated

    # Discovery on Baskets: id=1 -> 403, id=2 -> 200 with UserId=7 (stop).
    # Then neighbors: id=3 (own+1) -> 200 UserId=8 (HIT), id=1 (own-1) -> 403.
    # Then Orders, Memorys, Cards, Addresses each return all 403 on discovery.
    basket_responses = [
        _make_response(403, '{"error": "forbidden"}'),
        _make_response(200, '{"id": 2, "UserId": 7, "products": []}'),
        _make_response(200, '{"id": 3, "UserId": 8, "products": []}'),
        _make_response(403, '{"error": "forbidden"}'),
    ]
    other_object_responses = [
        _make_response(403, '{"error": "forbidden"}') for _ in range(3 * 4)
    ]
    fake_session.get.side_effect = basket_responses + other_object_responses

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
    )

    findings = await probe_idor_authenticated(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert f["severity"] == "critical"
    assert f["bug_class"] == "idor"
    assert f["category"] == "access_control"
    assert f["owasp"] == "A01:2021"
    assert "/api/Baskets/3" in f["target"]
    assert "UserId=7" in f["evidence"]
    assert "UserId=8" in f["evidence"]


@pytest.mark.asyncio
async def test_no_idor_when_neighbor_returns_403(fake_session, captured_auth):
    """Own basket is id=1 owned by UserId=5; neighbor id=2 -> 403 (no leak)."""
    from engine.probes import ProbeContext
    from engine.probes.web.idor_authenticated import probe_idor_authenticated

    # Baskets: id=1 -> 200 UserId=5 (own), id=2 -> 403 (no neighbor leak).
    # Note: own_id=1 means own-1=0 is skipped, so only one neighbor probe.
    basket_responses = [
        _make_response(200, '{"id": 1, "UserId": 5, "products": []}'),
        _make_response(403, '{"error": "forbidden"}'),
    ]
    # Other 4 object types: 3 discovery probes each, all 403.
    other_object_responses = [
        _make_response(403, '{"error": "forbidden"}') for _ in range(3 * 4)
    ]
    fake_session.get.side_effect = basket_responses + other_object_responses

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
    )

    findings = await probe_idor_authenticated(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_idor_found_on_orders_object(fake_session, captured_auth):
    """Multi-object coverage: IDOR fires on /api/Orders/ too."""
    from engine.probes import ProbeContext
    from engine.probes.web.idor_authenticated import probe_idor_authenticated

    # Baskets: 3x discovery 403 -> no own_id, no findings.
    baskets_responses = [
        _make_response(403, '{"error": "forbidden"}') for _ in range(3)
    ]
    # Orders: id=1 -> 200 UserId=10 (own); neighbor id=2 -> 200 UserId=11 (HIT);
    # own-1=0 skipped (must be >= 1).
    orders_responses = [
        _make_response(200, '{"id": 1, "UserId": 10, "total": 99.0}'),
        _make_response(200, '{"id": 2, "UserId": 11, "total": 42.0}'),
    ]
    # Memorys, Cards, Addresses: 3x discovery 403 each.
    rest_responses = [
        _make_response(403, '{"error": "forbidden"}') for _ in range(3 * 3)
    ]
    fake_session.get.side_effect = (
        baskets_responses + orders_responses + rest_responses
    )

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
    )

    findings = await probe_idor_authenticated(ctx)

    assert len(findings) == 1
    f = findings[0]
    assert "/api/Orders/2" in f["target"]
    assert f["severity"] == "critical"
    assert "UserId=10" in f["evidence"]
    assert "UserId=11" in f["evidence"]


@pytest.mark.asyncio
async def test_no_idor_when_neighbor_user_matches_own(fake_session, captured_auth):
    """Same user owns both own and neighbor record: not an IDOR."""
    from engine.probes import ProbeContext
    from engine.probes.web.idor_authenticated import probe_idor_authenticated

    basket_responses = [
        _make_response(200, '{"id": 1, "UserId": 5}'),
        _make_response(200, '{"id": 2, "UserId": 5}'),
    ]
    other_object_responses = [
        _make_response(403, '{"error": "forbidden"}') for _ in range(3 * 4)
    ]
    fake_session.get.side_effect = basket_responses + other_object_responses

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth=captured_auth,
    )

    findings = await probe_idor_authenticated(ctx)
    assert findings == []


def test_idor_authenticated_is_registered():
    from engine.probes import registry
    from engine.probes.web import idor_authenticated  # noqa: F401  - registers

    spec = registry.get("web.idor_authenticated")
    assert spec is not None
    assert spec.bug_class == "idor"
    assert spec.severity_max == "critical"
    assert spec.owasp == "A01:2021"
    assert spec.requires_auth is True
    assert spec.runtime_budget_s == 12.0
    assert "authenticated" in spec.tags
    assert "high-roi" in spec.tags
