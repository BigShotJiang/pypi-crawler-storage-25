"""Tests for the mass-assignment probe.

Mass assignment is critical because it turns a normal user-creation
endpoint into a privilege-escalation primitive. The probe sends a
baseline registration, then a perturbed one with `role`, `isAdmin`,
`credits` etc. mixed in. If the server reflects those fields back at
elevated values, that's the bug.
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_mass_assignment_critical_when_role_admin_reflected(fake_session):
    """role=admin echoed back in the response is critical privesc."""
    from engine.probes import ProbeContext
    from engine.probes.web.mass_assignment import probe_mass_assignment

    baseline = _make_response(
        201, json.dumps({"id": 1, "email": "a@example.com", "role": "customer"})
    )
    perturbed = _make_response(
        201,
        json.dumps(
            {"id": 2, "email": "b@example.com", "role": "admin"}
        ),
    )
    fake_session.post.side_effect = [baseline, perturbed]

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/Users/",),
    )

    findings = await probe_mass_assignment(ctx)

    assert any(
        f["severity"] == "critical" and "role" in f["title"] for f in findings
    )
    assert all(f["bug_class"] == "business_logic" for f in findings)


@pytest.mark.asyncio
async def test_mass_assignment_high_when_credits_reflected(fake_session):
    """credits=999999 echoed back is a high-severity money/tier override."""
    from engine.probes import ProbeContext
    from engine.probes.web.mass_assignment import probe_mass_assignment

    baseline = _make_response(
        200, json.dumps({"id": 1, "email": "a@example.com", "credits": 0})
    )
    perturbed = _make_response(
        200,
        json.dumps(
            {"id": 2, "email": "b@example.com", "credits": 999999}
        ),
    )
    fake_session.post.side_effect = [baseline, perturbed]

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/v1/users",),
    )

    findings = await probe_mass_assignment(ctx)

    credit_hits = [f for f in findings if "credits" in f["title"]]
    assert credit_hits, f"expected credits finding, got {findings}"
    assert credit_hits[0]["severity"] == "high"


@pytest.mark.asyncio
async def test_mass_assignment_no_hit_when_fields_stripped(fake_session):
    """Server-side allowlisting should leave the response clean."""
    from engine.probes import ProbeContext
    from engine.probes.web.mass_assignment import probe_mass_assignment

    baseline = _make_response(
        201, json.dumps({"id": 1, "email": "a@example.com"})
    )
    # Perturbed body has only the safe fields back; privileged keys absent.
    perturbed = _make_response(
        201,
        json.dumps({"id": 2, "email": "b@example.com"}),
    )
    fake_session.post.side_effect = [baseline, perturbed]
    # No follow-up GET should hit; if it does, return empty body.
    fake_session.get.return_value = _make_response(404, "")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/api/auth/register",),
    )

    findings = await probe_mass_assignment(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_mass_assignment_registration_uses_random_email(fake_session):
    """Each run must produce a unique email so re-runs don't 409."""
    from engine.probes import ProbeContext
    from engine.probes.web.mass_assignment import probe_mass_assignment

    baseline = _make_response(201, json.dumps({"id": 1}))
    perturbed = _make_response(201, json.dumps({"id": 2}))
    fake_session.post.side_effect = [baseline, perturbed]
    # Probe falls back to a follow-up GET when the response has an id but
    # no echoed privileged fields. Stub it so http_get returns cleanly.
    fake_session.get.return_value = _make_response(404, "")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        candidate_endpoints=("/register",),
    )

    await probe_mass_assignment(ctx)

    # Inspect both POST calls; emails should differ and match the
    # ptai-mass-<hex>@example.com shape.
    assert fake_session.post.call_count == 2
    # aiohttp call signature: session.post(url, json=..., headers=..., timeout=...)
    json_payloads = [c.kwargs["json"] for c in fake_session.post.call_args_list]
    emails = [p["email"] for p in json_payloads]
    assert len(set(emails)) == 2, f"emails must differ across calls: {emails}"
    for e in emails:
        assert e.startswith("ptai-mass-") and e.endswith("@example.com")
    # Perturbed body must include privileged fields.
    assert json_payloads[1].get("role") == "admin"
    assert json_payloads[1].get("isAdmin") is True
    assert json_payloads[1].get("credits") == 999999


def test_mass_assignment_is_registered():
    from engine.probes import registry
    from engine.probes.web import mass_assignment  # noqa: F401  - import registers

    spec = registry.get("web.mass_assignment")
    assert spec is not None
    assert spec.bug_class == "business_logic"
    assert spec.severity_max == "critical"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 10.0
    assert "destructive-low" in spec.tags
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert spec.owasp == "A04:2021"
