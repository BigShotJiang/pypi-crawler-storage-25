"""Tests for the crawler-driven XSS fuzz probe."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


def _resp(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {"Content-Type": "text/html"}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_xss_fuzz_emits_finding_when_script_tag_reflects(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.xss_fuzz import probe_xss_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/search"},
        forms=[],
    )

    def get_side(url, **_kwargs):
        # Attack response reflects the literal script payload
        if "%3Cscript%3Ealert" in url or "alert(1)" in url:
            return _resp(200, "<html>q=<script>alert(1)</script></html>")
        return _resp(200, "<html>baseline</html>")

    fake_session.get.side_effect = get_side

    with patch(
        "engine.probes.web.xss_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_xss_fuzz(ctx)

    assert len(findings) >= 1
    assert findings[0]["severity"] == "high"
    assert findings[0]["bug_class"] == "xss_reflected"


@pytest.mark.asyncio
async def test_xss_fuzz_no_finding_when_payload_is_html_encoded(fake_session):
    """If the server returns the payload entity-encoded, no exploitable hit."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.xss_fuzz import probe_xss_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/search"},
        forms=[],
    )

    fake_session.get.side_effect = lambda url, **_k: _resp(
        200,
        "<html>q=&lt;script&gt;alert(1)&lt;/script&gt;</html>",
    )

    with patch(
        "engine.probes.web.xss_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_xss_fuzz(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_xss_fuzz_no_finding_when_baseline_already_contains_marker(fake_session):
    """A page that legitimately renders <script>alert is not a hit."""
    from engine.probes import ProbeContext
    from engine.probes.recon.crawler import CrawlResult
    from engine.probes.web.xss_fuzz import probe_xss_fuzz

    fake_crawl = CrawlResult(
        discovered_paths=set(),
        discovered_js=set(),
        api_paths={"/search"},
        forms=[],
    )

    fake_session.get.side_effect = lambda url, **_k: _resp(
        200, "<html>tutorial: <script>alert(1)</script></html>"
    )

    with patch(
        "engine.probes.web.xss_fuzz.run_crawler",
        return_value=fake_crawl,
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_xss_fuzz(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_xss_fuzz_handles_crawler_failure(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.xss_fuzz import probe_xss_fuzz

    with patch(
        "engine.probes.web.xss_fuzz.run_crawler",
        side_effect=RuntimeError("boom"),
    ):
        ctx = ProbeContext(session=fake_session, base="http://x")
        findings = await probe_xss_fuzz(ctx)

    assert findings == []


def test_xss_fuzz_is_registered():
    from engine.probes import registry
    from engine.probes.web import xss_fuzz  # noqa: F401  - registers

    spec = registry.get("web.xss_fuzz")
    assert spec is not None
    assert spec.bug_class == "xss_reflected"
    assert spec.severity_max == "high"
    assert spec.owasp == "A03:2021"
    assert "fuzzing" in spec.tags
    assert "uses-crawler" in spec.tags
