"""Tests for the business-logic boundary fuzz probe.

The probe runs a curated list of known boundary cases and emits a
finding when the server SHOULD have rejected the request but didn't.
The fixtures below stub aiohttp's session.post to return one queued
response per POST call so each test focuses on a single check.
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

# Importing the probe module at collection time guarantees it registers
# before the autouse `_isolate_probe_registry` fixture snapshots state,
# so the registration test sees the spec regardless of test ordering.
from engine.probes.web import business_logic_fuzz as _bl_fuzz_module  # noqa: F401,E402


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


def _stub_responses(per_check_response):
    """Return a side_effect list with one response slot per CHECK.

    The probe calls session.post once per single-shot check and twice
    for the repetitive_registration check. Tests use the check name as
    a key into `per_check_response`; missing keys default to a hard 400.
    """
    from engine.probes.web.business_logic_fuzz import CHECKS

    rejected = _make_response(400, '{"error":"validation"}')
    out = []
    for check in CHECKS:
        responses = per_check_response.get(check.name)
        if responses is None:
            out.append(rejected)
            if check.twice:
                out.append(rejected)
            continue
        if check.twice:
            r1, r2 = responses
            out.extend([r1, r2])
        else:
            out.append(responses)
    return out


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_empty_registration_accepted_emits_high(fake_session):
    """Server returning 201 to {email:'',password:''} is a high finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.business_logic_fuzz import probe_business_logic_fuzz

    accepted = _make_response(201, json.dumps({"id": 99, "email": ""}))
    fake_session.post.side_effect = _stub_responses(
        {"empty_registration": accepted}
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_business_logic_fuzz(ctx)

    matches = [f for f in findings if f["check"] == "empty_registration"]
    assert matches, f"expected empty_registration finding, got {findings}"
    assert matches[0]["severity"] == "high"
    assert matches[0]["bug_class"] == "business_logic"
    assert "/api/Users/" in matches[0]["target"]


@pytest.mark.asyncio
async def test_negative_quantity_accepted_emits_high(fake_session):
    """Server echoing back negative quantity in 200 body is a high bug."""
    from engine.probes import ProbeContext
    from engine.probes.web.business_logic_fuzz import probe_business_logic_fuzz

    accepted = _make_response(
        200, json.dumps({"BasketId": 1, "ProductId": 1, "quantity": -100})
    )
    fake_session.post.side_effect = _stub_responses(
        {"negative_quantity": accepted}
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_business_logic_fuzz(ctx)

    matches = [f for f in findings if f["check"] == "negative_quantity"]
    assert matches, f"expected negative_quantity finding, got {findings}"
    assert matches[0]["severity"] == "high"
    assert "Negative quantity" in matches[0]["title"]


@pytest.mark.asyncio
async def test_repetitive_registration_both_succeed_emits_medium(fake_session):
    """Two successful POSTs of the same email is a medium uniqueness bug."""
    from engine.probes import ProbeContext
    from engine.probes.web.business_logic_fuzz import probe_business_logic_fuzz

    r1 = _make_response(201, json.dumps({"id": 1, "email": "x@example.com"}))
    r2 = _make_response(201, json.dumps({"id": 2, "email": "x@example.com"}))
    fake_session.post.side_effect = _stub_responses(
        {"repetitive_registration": (r1, r2)}
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_business_logic_fuzz(ctx)

    matches = [f for f in findings if f["check"] == "repetitive_registration"]
    assert matches, f"expected repetitive_registration finding, got {findings}"
    assert matches[0]["severity"] == "medium"
    assert "twice" in matches[0]["title"].lower()


@pytest.mark.asyncio
async def test_all_checks_rejected_emits_no_findings(fake_session):
    """Server returning 400/422 across the board produces zero findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.business_logic_fuzz import probe_business_logic_fuzz

    fake_session.post.side_effect = _stub_responses({})

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_business_logic_fuzz(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_deluxe_membership_no_payment_emits_high(fake_session):
    """200 with 'deluxe' in body without payment proof is a high finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.business_logic_fuzz import probe_business_logic_fuzz

    accepted = _make_response(
        200, json.dumps({"status": "success", "data": {"membership": "deluxe"}})
    )
    fake_session.post.side_effect = _stub_responses(
        {"deluxe_membership_no_payment": accepted}
    )

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_business_logic_fuzz(ctx)

    matches = [f for f in findings if f["check"] == "deluxe_membership_no_payment"]
    assert matches, f"expected deluxe finding, got {findings}"
    assert matches[0]["severity"] == "high"


@pytest.mark.asyncio
async def test_business_logic_fuzz_works_on_non_juiceshop_target(fake_session):
    """Target-specific endpoints 404 + every other check rejected: zero findings."""
    from engine.probes import ProbeContext
    from engine.probes.web.business_logic_fuzz import probe_business_logic_fuzz

    # Stub GET so target-specific paths (deluxe-membership, expired-coupon)
    # get the 404 they need to be skipped.
    fake_session.get.return_value = _make_response(404, "")
    fake_session.post.side_effect = _stub_responses({})

    ctx = ProbeContext(session=fake_session, base="http://example.com")
    findings = await probe_business_logic_fuzz(ctx)

    assert findings == []


def test_business_logic_fuzz_is_registered():
    """Decorator must register the probe with the documented metadata."""
    from engine.probes import registry
    from engine.probes.web import business_logic_fuzz  # noqa: F401  - registers

    spec = registry.get("web.business_logic_fuzz")
    assert spec is not None
    assert spec.bug_class == "business_logic"
    assert spec.severity_max == "high"
    assert spec.owasp == "A04:2021"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 20.0
    assert "anonymous" in spec.tags
    assert "high-roi" in spec.tags
    assert "destructive-low" in spec.tags
