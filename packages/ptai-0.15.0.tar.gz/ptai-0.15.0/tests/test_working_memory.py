"""Tests for engine.working_memory.

Cover three things:
  - Per-engagement isolation (the privacy rule).
  - Coverage matrix correctness (drives termination).
  - Pattern export (cross-engagement sharing) refuses without opt-in.
"""
from __future__ import annotations

import json

import pytest

from engine.working_memory import (
    BUG_CLASSES,
    CapturedAuth,
    CoverageMatrix,
    EndpointKey,
    EngagementPattern,
    FindingRef,
    make_working_memory,
)


def test_make_working_memory_requires_engagement_id():
    with pytest.raises(ValueError):
        make_working_memory("", "http://x.example")


def test_make_working_memory_requires_target():
    with pytest.raises(ValueError):
        make_working_memory("eng-1", "")


def test_engagement_id_is_immutable_after_construction():
    """The engagement boundary is enforced by construction; the id field
    is the dataclass attribute and shouldn't be changed mid-flight.
    """
    m = make_working_memory("eng-1", "http://x.example")
    assert m.engagement_id == "eng-1"


def test_coverage_rejects_unknown_bug_class():
    cov = CoverageMatrix()
    ep = EndpointKey(method="GET", path="/api/Users")
    with pytest.raises(ValueError):
        cov.mark_tried(ep, "not_a_real_class", hit=False)


def test_coverage_records_tries_and_hits():
    cov = CoverageMatrix()
    ep1 = EndpointKey(method="GET", path="/api/Users")
    ep2 = EndpointKey(method="POST", path="/rest/user/login")
    cov.mark_tried(ep1, "jwt_alg_none", hit=True)
    cov.mark_tried(ep2, "sqli", hit=True)
    cov.mark_tried(ep1, "xss_reflected", hit=False)

    s = cov.stats()
    assert s["tried_pairs"] == 3
    assert s["hit_pairs"] == 2

    assert cov.has_tried(ep1, "jwt_alg_none")
    assert not cov.has_tried(ep1, "ssrf")


def test_coverage_untried_pairs():
    cov = CoverageMatrix()
    ep = EndpointKey(method="GET", path="/api/Users")
    cov.mark_tried(ep, "jwt_alg_none", hit=True)
    untried = cov.untried_pairs([ep], ["jwt_alg_none", "sqli", "xss_reflected"])
    assert (ep, "jwt_alg_none") not in untried
    assert (ep, "sqli") in untried
    assert (ep, "xss_reflected") in untried


def test_summary_for_llm_excludes_raw_auth_values():
    """Privacy rule: the LLM-facing summary must not contain raw token
    values, even though the loop is supposed to use them downstream.
    """
    m = make_working_memory("eng-1", "http://x.example")
    m.add_auth(CapturedAuth(
        kind="jwt",
        value="eyJSECRET.PAYLOAD.SIG",
        source_endpoint="/rest/user/login",
        captured_at="2026-05-06T20:00:00Z",
        role_hint="admin",
    ))
    summary = m.summary_for_llm()
    assert summary["auth_captured_count"] == 1
    # The raw value MUST NOT appear anywhere in the summary.
    assert "eyJSECRET.PAYLOAD.SIG" not in json.dumps(summary)


def test_to_redacted_json_omits_secret_values():
    m = make_working_memory("eng-1", "http://x.example")
    m.add_auth(CapturedAuth(
        kind="bearer",
        value="super-secret-token-xyz",
        source_endpoint="/login",
        captured_at="t",
    ))
    redacted = m.to_redacted_json()
    assert "super-secret-token-xyz" not in redacted
    assert "bearer" in redacted  # the kind is fine, the value is not


def test_export_patterns_refuses_without_opt_in():
    """Privacy rule: cross-engagement sharing is opt-in, off by default."""
    m = make_working_memory("eng-1", "http://x.example")
    m.add_finding(FindingRef(
        id="f1", severity="critical", category="authentication",
        bug_class="jwt_alg_none", target="http://x.example/api/Users",
    ))
    assert m.cross_engagement_share is False
    assert m.export_patterns() == []


def test_export_patterns_works_with_opt_in_and_drops_no_raw_data():
    m = make_working_memory("eng-1", "http://x.example")
    m.cross_engagement_share = True
    m.add_finding(FindingRef(
        id="f1", severity="critical", category="authentication",
        bug_class="jwt_alg_none", target="http://x.example/api/Users",
    ))

    patterns = m.export_patterns()
    assert len(patterns) == 1
    p = patterns[0]
    assert isinstance(p, EngagementPattern)
    assert p.bug_class == "jwt_alg_none"
    # No raw target, no finding id, no engagement id leaked.
    p_dump = f"{p.pattern_hash} {p.bug_class} {p.feature_signature}"
    assert "eng-1" not in p_dump
    assert "x.example" not in p_dump
    assert "f1" not in p_dump


def test_two_engagements_have_isolated_state():
    """Two WorkingMemory objects share NO state. The agent loop never
    treats them as a pool.
    """
    m1 = make_working_memory("eng-1", "http://a.example")
    m2 = make_working_memory("eng-2", "http://b.example")
    m1.add_finding(FindingRef(
        id="f1", severity="critical", category="authentication",
        bug_class="jwt_alg_none", target="http://a.example/x",
    ))
    assert len(m1.findings) == 1
    assert len(m2.findings) == 0
    assert m1.engagement_id != m2.engagement_id


def test_bug_class_taxonomy_is_non_empty_and_includes_canonical_classes():
    """A safety check: a typo in BUG_CLASSES would break coverage tracking
    silently. Pin the canonical classes the SPA probes already produce.
    """
    must_have = {
        "sqli", "jwt_alg_none", "auth_bypass", "open_redirect",
        "xss_reflected", "xss_stored", "xxe", "ssti", "ssrf", "idor",
        "file_upload_bypass", "path_traversal", "vulnerable_dep",
        "exposed_admin", "dir_listing", "source_map_exposure",
    }
    missing = must_have - set(BUG_CLASSES)
    assert missing == set(), f"missing bug classes: {missing}"
