"""Tests for the MCP-side tool-install action surface: ``plan_tools``,
``ensure_tools_installed``.

These let an outer LLM (Claude Code, Cursor, Codex) plan and install
ptai's 200+ security-tool wrappers without an Anthropic API key.
Companion to ``list_tools`` / ``run_tool`` which have been around since
0.10.0.
"""
from __future__ import annotations

import pytest


@pytest.fixture(autouse=True)
def _reset_mcp_globals():
    import mcp_server.server as srv

    srv.findings_db = None
    srv.orchestrator = None
    srv.tool_registry = None
    yield
    srv.findings_db = None
    srv.orchestrator = None
    srv.tool_registry = None


@pytest.mark.asyncio
async def test_plan_tools_web_scope_returns_static_floor(tmp_path, monkeypatch):
    """plan_tools(scope='web') returns the canonical static list."""
    from fastmcp import Client

    import mcp_server.server as srv

    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "plan_tools", {"scope": "web", "intensity": "normal"}
        )
    data = result.data
    assert data["scope"] == "web"
    assert isinstance(data["predicted"], list)
    # The static map for "web" includes these.
    expected_subset = {"wpscan", "dalfox", "sqlmap"}
    found = expected_subset.intersection(data["predicted"])
    assert found, f"expected at least one of {expected_subset} in {data['predicted']}"
    # static_floor mirrors predicted (no LLM augmentation server-side).
    assert data["static_floor"] == data["predicted"]


@pytest.mark.asyncio
async def test_plan_tools_full_scope_is_union(tmp_path, monkeypatch):
    """plan_tools(scope='full') unions every static scope's list."""
    from fastmcp import Client

    import mcp_server.server as srv

    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool("plan_tools", {"scope": "full"})
    predicted = result.data["predicted"]
    # full = union(web, ad, cloud) — assert representatives from each.
    assert "wpscan" in predicted  # web
    assert "kerbrute" in predicted or "enum4linux-ng" in predicted  # ad
    assert "prowler" in predicted  # cloud


@pytest.mark.asyncio
async def test_plan_tools_unknown_scope_empty_list(tmp_path, monkeypatch):
    """Unknown scope returns no predictions (caller falls back)."""
    from fastmcp import Client

    import mcp_server.server as srv

    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool("plan_tools", {"scope": "weird-xyz"})
    assert result.data["predicted"] == []


@pytest.mark.asyncio
async def test_ensure_tools_installed_audit_only_no_install(tmp_path, monkeypatch):
    """auto_install=False returns the audit without running installs."""
    from fastmcp import Client

    import mcp_server.server as srv

    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    install_called = {"n": 0}

    def trap_install(name, sudo_password=None):
        install_called["n"] += 1
        return True, "ok"

    monkeypatch.setattr("engine.tool_installer.install_tool_by_name", trap_install)

    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "ensure_tools_installed",
            {"tools": ["nmap", "this-tool-does-not-exist-xyz"], "auto_install": False},
        )
    data = result.data
    # Must have the three audit buckets and NOT have install_results.
    assert "installed" in data
    assert "missing" in data
    assert "unknown" in data
    assert "install_results" not in data
    assert "this-tool-does-not-exist-xyz" in data["unknown"]
    assert install_called["n"] == 0


@pytest.mark.asyncio
async def test_ensure_tools_installed_auto_install_runs_installs(tmp_path, monkeypatch):
    """auto_install=True invokes install_tool_by_name for each missing tool."""
    from fastmcp import Client

    import mcp_server.server as srv

    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))

    # Stub audit so we control which tools land in "missing".
    def fake_audit(names):
        return {"installed": [], "missing": list(names), "unknown": []}

    install_calls: list[str] = []

    def fake_install(name, sudo_password=None):
        install_calls.append(name)
        return True, f"installed {name}"

    monkeypatch.setattr("engine.tool_installer.audit_named", fake_audit)
    monkeypatch.setattr("engine.tool_installer.install_tool_by_name", fake_install)

    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "ensure_tools_installed",
            {"tools": ["wpscan", "dalfox"], "auto_install": True},
        )
    data = result.data
    assert "install_results" in data
    assert len(data["install_results"]) == 2
    assert all(r["ok"] for r in data["install_results"])
    assert install_calls == ["wpscan", "dalfox"]


@pytest.mark.asyncio
async def test_ensure_tools_installed_empty_input(tmp_path, monkeypatch):
    """Empty tools list returns empty audit without error."""
    from fastmcp import Client

    import mcp_server.server as srv

    monkeypatch.setenv("PENTEST_DB_PATH", str(tmp_path / "db"))
    async with Client(srv.mcp) as client:
        result = await client.call_tool(
            "ensure_tools_installed", {"tools": [], "auto_install": False}
        )
    data = result.data
    assert data == {"installed": [], "missing": [], "unknown": []}
