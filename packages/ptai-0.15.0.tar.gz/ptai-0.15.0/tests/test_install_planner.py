"""Tests for ``engine.install_planner.predict_tools_for_engagement``."""
from __future__ import annotations

import pytest

from engine.install_planner import _STATIC_SCOPE_MAP, predict_tools_for_engagement


@pytest.mark.asyncio
async def test_static_fallback_for_web():
    """When agent is None, static map for 'web' is the answer."""
    available = list({*_STATIC_SCOPE_MAP["web"], "extra-tool-xyz"})
    result = await predict_tools_for_engagement(
        agent=None,
        scope="web",
        intensity="normal",
        target="http://example.com",
        available_names=available,
    )
    for name in _STATIC_SCOPE_MAP["web"]:
        assert name in result


@pytest.mark.asyncio
async def test_static_for_ad_and_cloud_disjoint_from_web():
    """Other scopes return their own static lists, not web's."""
    available = list(
        set(_STATIC_SCOPE_MAP["web"])
        | set(_STATIC_SCOPE_MAP["ad"])
        | set(_STATIC_SCOPE_MAP["cloud"])
    )
    ad = await predict_tools_for_engagement(
        agent=None, scope="ad", available_names=available
    )
    cloud = await predict_tools_for_engagement(
        agent=None, scope="cloud", available_names=available
    )
    assert any(name in ad for name in _STATIC_SCOPE_MAP["ad"])
    assert any(name in cloud for name in _STATIC_SCOPE_MAP["cloud"])
    # ad list does not get web's wpscan etc.
    assert "wpscan" not in ad


@pytest.mark.asyncio
async def test_full_scope_is_union():
    """scope='full' unions every static list."""
    available = list(
        set(_STATIC_SCOPE_MAP["web"])
        | set(_STATIC_SCOPE_MAP["ad"])
        | set(_STATIC_SCOPE_MAP["cloud"])
    )
    result = await predict_tools_for_engagement(
        agent=None, scope="full", available_names=available
    )
    expected = (
        set(_STATIC_SCOPE_MAP["web"])
        | set(_STATIC_SCOPE_MAP["ad"])
        | set(_STATIC_SCOPE_MAP["cloud"])
    )
    assert expected.issubset(set(result))


@pytest.mark.asyncio
async def test_unknown_scope_returns_empty():
    """Bogus scopes get an empty static list (LLM-only mode would fill in)."""
    result = await predict_tools_for_engagement(
        agent=None, scope="weird-scope-xyz", available_names=["a", "b"]
    )
    assert result == []


@pytest.mark.asyncio
async def test_llm_union_with_static(monkeypatch):
    """When an agent picks tools, they're unioned with the static set."""
    available = list(set(_STATIC_SCOPE_MAP["web"]) | {"paramspider"})

    class FakeAgent:
        async def ask(self, prompt: str) -> str:
            return '["paramspider"]'

    result = await predict_tools_for_engagement(
        agent=FakeAgent(),
        scope="web",
        target="http://example.com",
        available_names=available,
    )
    assert "paramspider" in result
    for name in _STATIC_SCOPE_MAP["web"]:
        assert name in result


@pytest.mark.asyncio
async def test_llm_failure_falls_back_to_static():
    """If the agent raises, we still return the static set, no crash."""
    available = list(_STATIC_SCOPE_MAP["web"])

    class BrokenAgent:
        async def ask(self, prompt: str) -> str:
            raise RuntimeError("network down")

    result = await predict_tools_for_engagement(
        agent=BrokenAgent(),
        scope="web",
        available_names=available,
    )
    assert set(result) == set(_STATIC_SCOPE_MAP["web"])


@pytest.mark.asyncio
async def test_llm_garbage_response_ignored():
    """LLM returning non-JSON / non-list output is silently ignored."""
    available = list(_STATIC_SCOPE_MAP["web"])

    class ChattyAgent:
        async def ask(self, prompt: str) -> str:
            return "sure, here are the tools you want"

    result = await predict_tools_for_engagement(
        agent=ChattyAgent(),
        scope="web",
        available_names=available,
    )
    assert set(result) == set(_STATIC_SCOPE_MAP["web"])


@pytest.mark.asyncio
async def test_llm_picks_names_not_in_available_dropped():
    """The LLM cannot smuggle in tool names that aren't in the registry."""
    available = list(_STATIC_SCOPE_MAP["web"])

    class TrickyAgent:
        async def ask(self, prompt: str) -> str:
            return '["smuggled-tool", "wpscan"]'

    result = await predict_tools_for_engagement(
        agent=TrickyAgent(),
        scope="web",
        available_names=available,
    )
    assert "smuggled-tool" not in result
    assert "wpscan" in result  # was already in the static map
