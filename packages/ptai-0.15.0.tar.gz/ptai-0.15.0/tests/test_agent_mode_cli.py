"""Tests that --agent-mode dispatches the new agent loop instead of the
legacy fixed-pipeline orchestrator.

Both branches are mocked. The test asserts only the dispatch decision.
End-to-end coverage of the agent loop with a real LLM happens in the
e2e CI job, not here.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

from typer.testing import CliRunner

from cli.main import app

runner = CliRunner()


def _start_mock_db():
    db = MagicMock()
    db.reconcile_stale_engagements = AsyncMock(return_value=None)
    db.create_engagement = AsyncMock(return_value={"id": "eng-test"})
    db.get_findings = AsyncMock(return_value=[])
    db.add_finding = AsyncMock()
    db.add_attack_chain = AsyncMock()
    db.get_attack_chains = AsyncMock(return_value=[])
    db.get_engagement_summary = AsyncMock(
        return_value={"total_findings": 0, "by_severity": {}, "phase_errors": {}}
    )
    db.update_engagement_status = AsyncMock()
    db.update_engagement_phase = AsyncMock()
    db.close = AsyncMock()
    return db


def test_agent_mode_flag_dispatches_to_run_agent_loop(monkeypatch, tmp_path):
    """Passing --agent-mode runs the agent loop, not the legacy pipeline."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test-fake")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("PENTEST_AI_AUP_ACCEPTED", "1")

    db = _start_mock_db()
    legacy_orch = MagicMock()
    legacy_orch.start_engagement = AsyncMock()
    legacy_orch.phase_errors = {}

    fake_run_agent_loop = AsyncMock(return_value=None)
    fake_anthropic = MagicMock()

    with patch("engine.findings_db.FindingsDB", return_value=db), \
         patch("engine.orchestrator.AgentOrchestrator", return_value=legacy_orch), \
         patch("engine.agent_loop.run_agent_loop", new=fake_run_agent_loop), \
         patch("engine.agents.anthropic_agent.AnthropicAgent", return_value=MagicMock()), \
         patch.dict(
             "sys.modules",
             {"anthropic": MagicMock(AsyncAnthropic=MagicMock(return_value=fake_anthropic))},
         ):
        result = runner.invoke(
            app,
            ["start", "http://example.test/", "--scope", "web", "--agent-mode", "--ci"],
        )

    assert result.exit_code == 0, result.output
    fake_run_agent_loop.assert_called_once()
    legacy_orch.start_engagement.assert_not_called()


def test_legacy_pipeline_flag_uses_legacy_orchestrator(monkeypatch, tmp_path):
    """Passing --legacy-pipeline forces the old fixed-phase orchestrator.

    As of the autonomy roadmap step 7 (commit b569f36 + this commit),
    agent mode is the DEFAULT. Users opt out of the loop by passing
    --legacy-pipeline explicitly.
    """
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test-fake")
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("PENTEST_AI_AUP_ACCEPTED", "1")

    db = _start_mock_db()
    legacy_orch = MagicMock()
    legacy_orch.start_engagement = AsyncMock()
    legacy_orch.phase_errors = {}

    fake_run_agent_loop = AsyncMock(return_value=None)

    with patch("engine.findings_db.FindingsDB", return_value=db), \
         patch("engine.orchestrator.AgentOrchestrator", return_value=legacy_orch), \
         patch("engine.agent_loop.run_agent_loop", new=fake_run_agent_loop):
        result = runner.invoke(
            app,
            [
                "start",
                "http://example.test/",
                "--scope",
                "web",
                "--legacy-pipeline",
                "--ci",
            ],
        )

    assert result.exit_code == 0, result.output
    fake_run_agent_loop.assert_not_called()
    legacy_orch.start_engagement.assert_called_once()


def test_agent_mode_with_no_llm_falls_back_to_legacy(monkeypatch, tmp_path):
    """If both --agent-mode and --no-llm are passed, --no-llm wins:
    the legacy deterministic pipeline runs.
    """
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("PENTEST_AI_AUP_ACCEPTED", "1")

    db = _start_mock_db()
    legacy_orch = MagicMock()
    legacy_orch.start_engagement = AsyncMock()
    legacy_orch.phase_errors = {}

    fake_run_agent_loop = AsyncMock(return_value=None)

    with patch("engine.findings_db.FindingsDB", return_value=db), \
         patch("engine.orchestrator.AgentOrchestrator", return_value=legacy_orch), \
         patch("engine.agent_loop.run_agent_loop", new=fake_run_agent_loop):
        result = runner.invoke(
            app,
            ["start", "http://example.test/", "--scope", "web",
             "--agent-mode", "--no-llm", "--ci"],
        )

    assert result.exit_code == 0, result.output
    fake_run_agent_loop.assert_not_called()
    legacy_orch.start_engagement.assert_called_once()
