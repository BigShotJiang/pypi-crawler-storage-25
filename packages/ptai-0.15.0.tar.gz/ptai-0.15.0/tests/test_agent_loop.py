"""Tests for engine.agent_loop.

The loop's behaviour is the contract: given an LLM agent that proposes
actions, the loop dispatches them to registered handlers, records the
observation, and terminates correctly.

The Anthropic API is NOT called from these tests. We pass a fake
LLMAgent so the loop can be tested fully offline.
"""
from __future__ import annotations

import pytest

from agents.base import LLMUnavailableError
from engine.agent_loop import (
    _HANDLERS,
    Action,
    LoopConfig,
    Observation,
    register_handler,
    run_agent_loop,
)
from engine.working_memory import (
    EndpointKey,
    FindingRef,
    make_working_memory,
)


class _StubCostTracker:
    """Minimal CostTracker-like double for budget-cap tests."""

    def __init__(self, *, over: bool = False):
        self._over = over

    def trip(self) -> None:
        self._over = True

    def over_budget(self) -> bool:
        return self._over


class _RaisingAgent:
    """Agent that raises the configured exception on the first call."""

    def __init__(self, exc):
        self._exc = exc

    async def decide_next_action(self, state):
        raise self._exc


class _FakeAgent:
    """A scripted agent that returns a queue of actions."""

    def __init__(self, actions):
        self._actions = list(actions)

    async def decide_next_action(self, state):
        if not self._actions:
            return Action(name="finish")
        return self._actions.pop(0)


@pytest.mark.asyncio
async def test_loop_calls_registered_handler_with_args():
    captured = []

    async def handler(memory, args):
        captured.append(args)
        memory.add_endpoint(EndpointKey(method="GET", path=args["path"]))
        return Observation(
            action_name="probe.test", success=True, endpoints_added=1,
        )

    # Use a unique handler name per test to avoid registry collision.
    register_handler("probe.test_calls_registered", handler)

    agent = _FakeAgent([
        Action(
            name="probe.test_calls_registered",
            args={"path": "/api/Users/"},
            rationale="check for known endpoint",
        ),
    ])
    memory = make_working_memory("eng-1", "http://x.example")

    out = await run_agent_loop(
        agent, memory, LoopConfig(max_iterations=3, min_iterations_before_finish=0),
    )

    assert captured == [{"path": "/api/Users/"}]
    assert len(out.endpoints_seen) == 1
    assert out.last_observation["success"] is True


@pytest.mark.asyncio
async def test_loop_handles_unknown_handler_without_crashing():
    agent = _FakeAgent([
        Action(name="this.does.not.exist", args={}, rationale="test"),
    ])
    memory = make_working_memory("eng-2", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(max_iterations=2, min_iterations_before_finish=0),
    )

    assert out.last_observation["success"] is False
    assert "no handler registered" in out.last_observation["error"]


@pytest.mark.asyncio
async def test_loop_respects_min_iterations_before_finish():
    """A buggy agent that calls 'finish' on iteration 1 must be ignored
    until min_iterations_before_finish is reached.
    """
    async def noop_handler(memory, args):
        return Observation(action_name="probe.noop", success=True)

    register_handler("probe.noop", noop_handler)

    # Agent: finish, finish, finish, finish, probe.noop, finish.
    # With min_iter_before_finish=3, the first two 'finish' get ignored,
    # iteration 3 finish is honoured.
    agent = _FakeAgent([
        Action(name="finish"),
        Action(name="finish"),
        Action(name="finish"),
    ])
    memory = make_working_memory("eng-3", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(max_iterations=5, min_iterations_before_finish=3),
    )
    # iterations counter increments every loop pass, including ignored finish.
    assert out.iterations >= 3


@pytest.mark.asyncio
async def test_loop_stops_at_max_iterations():
    """If the agent never finishes, max_iterations bounds the run."""
    async def churn_handler(memory, args):
        return Observation(action_name="probe.churn", success=True)

    register_handler("probe.churn", churn_handler)

    # Agent always proposes the same action, never says finish.
    agent = _FakeAgent([
        Action(name="probe.churn") for _ in range(100)
    ])
    memory = make_working_memory("eng-4", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(max_iterations=4, min_iterations_before_finish=0),
    )
    assert out.iterations == 4


@pytest.mark.asyncio
async def test_loop_terminates_on_coverage_threshold():
    """When the coverage matrix passes the threshold, the loop stops
    even if the agent has more actions queued.
    """
    async def cover_handler(memory, args):
        # Each call marks (1 endpoint × every bug class) so coverage rises
        # quickly to 100% with one endpoint.
        from engine.working_memory import BUG_CLASSES
        ep = EndpointKey(method="GET", path="/api/Users/")
        memory.add_endpoint(ep)
        for bc in BUG_CLASSES:
            memory.coverage.mark_tried(ep, bc, hit=False)
        return Observation(action_name="probe.cover", success=True)

    register_handler("probe.cover", cover_handler)

    agent = _FakeAgent([
        Action(name="probe.cover"),
        Action(name="probe.cover"),
        Action(name="probe.cover"),
    ])
    memory = make_working_memory("eng-5", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(
            max_iterations=10,
            coverage_threshold=0.5,
            min_iterations_before_finish=0,
        ),
    )
    # Single iteration fills coverage to 100% -> loop should stop.
    assert out.iterations == 1


@pytest.mark.asyncio
async def test_loop_records_action_and_observation_for_explainability():
    async def handler(memory, args):
        memory.add_finding(FindingRef(
            id="f-1", severity="high", category="authentication",
            bug_class="auth_bypass", target=memory.target,
        ))
        return Observation(
            action_name="probe.auth", success=True, findings_added=1,
        )

    register_handler("probe.auth_explain", handler)

    agent = _FakeAgent([
        Action(name="probe.auth_explain", args={"x": 1}, rationale="explainable"),
    ])
    memory = make_working_memory("eng-6", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(max_iterations=2, min_iterations_before_finish=0),
    )

    assert out.last_action["name"] == "probe.auth_explain"
    assert out.last_action["rationale"] == "explainable"
    assert out.last_observation["findings_added"] == 1


# ─── Cost limit + LLM-unavailable fallback tests (autonomy roadmap step 6) ──


@pytest.mark.asyncio
async def test_loop_exits_when_cost_tracker_over_budget():
    """A cost_tracker reporting over_budget=True must stop the loop on the
    next iteration check, before another LLM call is made.
    """
    tracker = _StubCostTracker(over=True)

    async def noop_handler(memory, args):
        return Observation(action_name="probe.cost_a", success=True)

    register_handler("probe.cost_a", noop_handler)

    agent = _FakeAgent([Action(name="probe.cost_a") for _ in range(5)])
    memory = make_working_memory("eng-cost-1", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(
            max_iterations=5,
            min_iterations_before_finish=0,
            cost_tracker=tracker,
        ),
    )
    # First iteration's pre-flight budget check trips immediately.
    assert out.last_observation["evidence"] == "cost limit reached"
    assert out.last_observation["verdict"] == "failed"


@pytest.mark.asyncio
async def test_loop_exit_reason_is_cost_limit():
    tracker = _StubCostTracker(over=True)
    agent = _FakeAgent([Action(name="finish")])
    memory = make_working_memory("eng-cost-2", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(max_iterations=3, min_iterations_before_finish=0, cost_tracker=tracker),
    )
    assert out.exit_reason == "cost_limit"


@pytest.mark.asyncio
async def test_loop_exits_cleanly_on_llm_unavailable():
    """LLMUnavailableError from decide_next_action must not crash the loop."""
    agent = _RaisingAgent(LLMUnavailableError("anthropic 401"))
    memory = make_working_memory("eng-llm-1", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(
            max_iterations=3,
            min_iterations_before_finish=0,
            fallback_to_deterministic=False,
        ),
    )
    assert out.last_observation["action_name"] == "llm_unavailable"
    assert out.last_observation["verdict"] == "failed"
    assert "LLM provider unreachable" in out.last_observation["evidence"]


@pytest.mark.asyncio
async def test_loop_exit_reason_is_llm_unavailable():
    agent = _RaisingAgent(LLMUnavailableError("provider down"))
    memory = make_working_memory("eng-llm-2", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(
            max_iterations=3,
            min_iterations_before_finish=0,
            fallback_to_deterministic=False,
        ),
    )
    assert out.exit_reason == "llm_unavailable"


@pytest.mark.asyncio
async def test_loop_falls_back_to_deterministic_on_llm_failure():
    """With fallback_to_deterministic=True, registered probe.* handlers must
    still run after the LLM dies, so the engagement returns findings instead
    of an empty result.
    """
    called = []

    async def det_probe(memory, args):
        called.append("det.fallback")
        memory.add_finding(FindingRef(
            id="f-det-1", severity="medium", category="x",
            bug_class="probe", target=memory.target,
        ))
        return Observation(action_name="probe.det_fallback", success=True, findings_added=1)

    # Use a unique name so this handler is the only probe.* in the registry
    # for this test path. Other tests register different probe.* keys.
    register_handler("probe.det_fallback", det_probe)

    agent = _RaisingAgent(LLMUnavailableError("provider down"))
    memory = make_working_memory("eng-llm-3", "http://x.example")

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(
            max_iterations=3,
            min_iterations_before_finish=0,
            fallback_to_deterministic=True,
        ),
    )
    # The deterministic sweep visits probe.det_fallback (along with any
    # other probe.* handlers registered earlier in the test session).
    assert "det.fallback" in called
    assert out.exit_reason == "deterministic"
    assert any(f.id == "f-det-1" for f in out.findings)


@pytest.mark.asyncio
async def test_loop_stops_without_fallback_when_disabled():
    """fallback_to_deterministic=False: loop stops at the LLM failure,
    no probe handlers run, exit_reason is llm_unavailable.
    """
    called = []

    async def never_called_probe(memory, args):
        called.append("nope")
        return Observation(action_name="probe.never", success=True)

    register_handler("probe.never_called", never_called_probe)

    agent = _RaisingAgent(LLMUnavailableError("nope"))
    memory = make_working_memory("eng-llm-4", "http://x.example")

    # Sanity: snapshot how many findings/handlers existed before the run so
    # the assertion below doesn't depend on test ordering.
    pre_findings = len(memory.findings)

    out = await run_agent_loop(
        agent, memory,
        LoopConfig(
            max_iterations=3,
            min_iterations_before_finish=0,
            fallback_to_deterministic=False,
        ),
    )
    assert out.exit_reason == "llm_unavailable"
    assert called == []
    assert len(out.findings) == pre_findings


def test_handlers_registry_is_global():
    """Sanity check: the module-level _HANDLERS dict is the registry the
    loop uses. Imported here so the deterministic-fallback test stays
    deterministic across test ordering.
    """
    assert isinstance(_HANDLERS, dict)
