"""Tests for the recon crawler.

Crawler is the missing exploration phase. Probes today walk hardcoded
path lists; the crawler feeds them real endpoints found by parsing
HTML, JS bundles, OpenAPI docs, sitemap.xml, and robots.txt. Without
this, probes miss anything not on a built-in list.
"""
from __future__ import annotations

import os
from unittest.mock import AsyncMock, MagicMock

import pytest

# --------------------------------------------------------------------- helpers


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


# --------------------------------------------------------------------- HTML


SAMPLE_HTML = """
<!doctype html>
<html><head>
  <link rel="stylesheet" href="/static/app.css">
  <script src="/static/main.bundle.js"></script>
  <script src="https://cdn.example.com/external.js"></script>
</head>
<body>
  <a href="/login">Login</a>
  <a href="/products">Products</a>
  <a href="https://other.example/external">External</a>
  <a href="#hash">Hash only</a>
  <img src="/img/logo.png">
  <form action="/api/login" method="POST">
    <input name="email" type="text">
    <input name="password" type="password">
  </form>
</body></html>
"""


def test_parse_html_extracts_anchor_hrefs():
    from engine.probes.recon.crawler import parse_html

    result = parse_html("http://localhost:3000", SAMPLE_HTML)

    assert "/login" in result.discovered_paths
    assert "/products" in result.discovered_paths
    # Hash-only and cross-origin links must be excluded.
    assert "#hash" not in result.discovered_paths
    assert "https://other.example/external" not in result.discovered_paths


def test_parse_html_extracts_form_actions_and_fields():
    from engine.probes.recon.crawler import parse_html

    result = parse_html("http://localhost:3000", SAMPLE_HTML)

    assert len(result.forms) == 1
    form = result.forms[0]
    assert form["action"] == "/api/login"
    assert form["method"] == "POST"
    assert "email" in form["fields"]
    assert "password" in form["fields"]
    # Form action must also land in discovered_paths.
    assert "/api/login" in result.discovered_paths


def test_parse_html_extracts_same_origin_script_srcs():
    from engine.probes.recon.crawler import parse_html

    result = parse_html("http://localhost:3000", SAMPLE_HTML)

    assert "/static/main.bundle.js" in result.discovered_js
    # Cross-origin JS must not be fetched.
    assert not any("cdn.example.com" in js for js in result.discovered_js)


def test_parse_html_handles_malformed_input():
    from engine.probes.recon.crawler import parse_html

    # Garbage in: no crash, empty result is fine.
    result = parse_html("http://localhost:3000", "<<<not html>>>")
    assert isinstance(result.discovered_paths, set)


def test_parse_html_handles_empty_body():
    from engine.probes.recon.crawler import parse_html

    result = parse_html("http://localhost:3000", "")
    assert result.discovered_paths == set()
    assert result.forms == []


# --------------------------------------------------------------------- JS


SAMPLE_JS = """
const config = { apiUrl: "/api/v1", baseURL: 'https://api.example.com/rest' };
fetch('/api/users/me').then(r => r.json());
axios.get('/rest/products/search?q=x');
$.ajax({ url: '/api/orders', method: 'POST' });
const ENDPOINTS = { login: '/api/auth/login' };
// Junk that must not match:
const cls = "/btn-primary/active";
const word = "/users";
"""


def test_parse_js_extracts_api_path_literals():
    from engine.probes.recon.crawler import parse_js

    paths = parse_js(SAMPLE_JS)

    assert "/api/users/me" in paths
    assert "/rest/products/search?q=x" in paths
    assert "/api/orders" in paths
    assert "/api/auth/login" in paths
    assert "/api/v1" in paths
    # CSS-y string and bare /users (no /api prefix) must NOT match.
    assert "/btn-primary/active" not in paths


def test_parse_js_handles_empty():
    from engine.probes.recon.crawler import parse_js

    assert parse_js("") == set()


# --------------------------------------------------------------------- OpenAPI


MINI_SWAGGER = """{
  "swagger": "2.0",
  "basePath": "/api",
  "paths": {
    "/users": {"get": {}},
    "/users/{id}": {"get": {}, "delete": {}},
    "/products/search": {"get": {}}
  }
}"""

MINI_OPENAPI3 = """{
  "openapi": "3.0.0",
  "paths": {
    "/v1/orders": {"get": {}},
    "/v1/orders/{orderId}": {"put": {}}
  }
}"""


def test_parse_openapi_extracts_swagger_v2_paths_with_basepath():
    from engine.probes.recon.crawler import parse_openapi

    paths = parse_openapi(MINI_SWAGGER)

    assert "/api/users" in paths
    assert "/api/users/{id}" in paths
    assert "/api/products/search" in paths


def test_parse_openapi_extracts_openapi_v3_paths():
    from engine.probes.recon.crawler import parse_openapi

    paths = parse_openapi(MINI_OPENAPI3)

    assert "/v1/orders" in paths
    assert "/v1/orders/{orderId}" in paths


def test_parse_openapi_handles_malformed_json():
    from engine.probes.recon.crawler import parse_openapi

    assert parse_openapi("{not valid") == set()
    assert parse_openapi("") == set()
    assert parse_openapi("[1, 2, 3]") == set()


# --------------------------------------------------------------------- sitemap


def test_parse_sitemap_extracts_loc_urls():
    from engine.probes.recon.crawler import parse_sitemap

    xml = """<?xml version="1.0"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>http://localhost:3000/about</loc></url>
  <url><loc>http://localhost:3000/contact</loc></url>
</urlset>"""

    urls = parse_sitemap(xml)
    assert "http://localhost:3000/about" in urls
    assert "http://localhost:3000/contact" in urls


def test_parse_sitemap_handles_malformed_xml():
    from engine.probes.recon.crawler import parse_sitemap

    assert parse_sitemap("<<<not xml") == set()
    assert parse_sitemap("") == set()


# --------------------------------------------------------------------- robots


def test_parse_robots_extracts_disallow_paths():
    from engine.probes.recon.crawler import parse_robots

    body = """User-agent: *
Disallow: /admin
Disallow: /api/internal
Allow: /api/public
# comment
Sitemap: https://example.com/sitemap.xml
"""
    out = parse_robots(body)
    assert "/admin" in out
    assert "/api/internal" in out
    assert "/api/public" in out
    assert "https://example.com/sitemap.xml" in out


# --------------------------------------------------------------------- run_crawler


@pytest.mark.asyncio
async def test_run_crawler_handles_missing_sitemap_gracefully(fake_session):
    """All discovery endpoints can 404 and the crawler still returns a result."""
    from engine.probes.recon.crawler import run_crawler

    # Every GET returns 404 / empty body.
    fake_session.get.return_value = _make_response(404, "")

    result = await run_crawler(fake_session, "http://localhost:3000")

    # No crash, result is empty but well-formed.
    assert result.discovered_paths == set()
    assert result.api_paths == set()
    assert result.forms == []


@pytest.mark.asyncio
async def test_run_crawler_merges_html_js_and_openapi(fake_session):
    """Crawler should union paths from all sources and dedupe."""
    from engine.probes.recon.crawler import run_crawler

    # Map URL -> response. session.get(url, ...) returns _make_response().
    responses: dict[str, tuple[int, str]] = {
        "http://localhost:3000/": (200, SAMPLE_HTML),
        "http://localhost:3000/static/main.bundle.js": (200, SAMPLE_JS),
        "http://localhost:3000/swagger.json": (200, MINI_SWAGGER),
        "http://localhost:3000/api-docs": (404, ""),
        "http://localhost:3000/api-docs/swagger.json": (404, ""),
        "http://localhost:3000/openapi.json": (404, ""),
        "http://localhost:3000/v2/api-docs": (404, ""),
        "http://localhost:3000/v3/api-docs": (404, ""),
        "http://localhost:3000/graphql": (200, "{}"),
        "http://localhost:3000/sitemap.xml": (404, ""),
        "http://localhost:3000/robots.txt": (404, ""),
    }

    def fake_get(url, **_kwargs):
        status, body = responses.get(url, (404, ""))
        return _make_response(status, body)

    fake_session.get.side_effect = fake_get

    result = await run_crawler(fake_session, "http://localhost:3000")

    # HTML anchors made it through.
    assert "/login" in result.discovered_paths
    assert "/products" in result.discovered_paths

    # JS literals made it through.
    assert "/api/users/me" in result.api_paths
    assert "/api/orders" in result.api_paths

    # Swagger paths made it through with basePath applied.
    assert "/api/users" in result.api_paths
    assert "/api/users/{id}" in result.api_paths

    # GraphQL existence captured.
    assert "/graphql" in result.api_paths

    # Forms preserved.
    assert any(f["action"] == "/api/login" for f in result.forms)


@pytest.mark.asyncio
async def test_run_crawler_dedupes_across_sources(fake_session):
    """A path that appears in HTML and OpenAPI must appear once."""
    from engine.probes.recon.crawler import run_crawler

    html = '<html><body><a href="/api/users">Users</a></body></html>'
    swagger = '{"swagger":"2.0","paths":{"/api/users":{"get":{}}}}'

    def fake_get(url, **_kwargs):
        if url.endswith("/"):
            return _make_response(200, html)
        if "swagger.json" in url and "api-docs" not in url:
            return _make_response(200, swagger)
        return _make_response(404, "")

    fake_session.get.side_effect = fake_get

    result = await run_crawler(fake_session, "http://localhost:3000")

    # Path lives in HTML (discovered_paths) and Swagger (api_paths). Each set
    # holds it exactly once.
    assert sum(1 for p in result.discovered_paths if p == "/api/users") <= 1
    assert sum(1 for p in result.api_paths if p == "/api/users") <= 1
    assert "/api/users" in (result.discovered_paths | result.api_paths)


# --------------------------------------------------------------------- exports


def test_crawler_exports_through_probes_package():
    """run_crawler and CrawlResult must be importable from engine.probes."""
    from engine.probes import CrawlResult, run_crawler

    assert run_crawler is not None
    assert CrawlResult is not None


def test_recon_subpackage_exposes_helpers():
    from engine.probes.recon import (
        CrawlResult,
        parse_html,
        parse_js,
        parse_openapi,
        run_crawler,
    )

    assert all(x is not None for x in (CrawlResult, parse_html, parse_js, parse_openapi, run_crawler))


# --------------------------------------------------------------------- live


@pytest.mark.skipif(
    os.environ.get("PTAI_LIVE_CRAWLER") != "1",
    reason="set PTAI_LIVE_CRAWLER=1 with Juice Shop running on :3000 to enable",
)
@pytest.mark.asyncio
async def test_run_crawler_against_live_juice_shop():
    """Smoke test: crawl a real Juice Shop instance and assert non-empty output."""
    import aiohttp

    from engine.probes.recon.crawler import run_crawler

    async with aiohttp.ClientSession() as session:
        result = await run_crawler(session, "http://localhost:3000")

    # Juice Shop's main bundle exposes /api/* and /rest/* literals.
    assert len(result.discovered_paths) + len(result.api_paths) > 5
    assert any(p.startswith(("/api", "/rest")) for p in result.api_paths)
