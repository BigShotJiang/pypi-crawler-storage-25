"""Tests for the `bearer` flow executor in WebAuthenticator."""
from __future__ import annotations

import json
import pytest
from unittest.mock import AsyncMock, MagicMock

import httpx

from engine.auth_session import AuthError, AuthSession, WebAuthenticator


@pytest.mark.asyncio
async def test_bearer_flow_extracts_token_from_json_path():
    """POST creds → extract token at configurable JSON path → return AuthSession with bearer_token."""
    auth = WebAuthenticator(
        flow="bearer",
        login_url="https://app.example/api/login",
        username="alice@example.com",
        password="hunter2",
        username_field="email",
        password_field="password",
        body_shape="json",
        token_path="authentication.token",
    )

    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 200
    mock_resp.text = json.dumps({"authentication": {"token": "FAKE.JWT.TOKEN"}})
    mock_resp.json.return_value = {"authentication": {"token": "FAKE.JWT.TOKEN"}}
    mock_resp.headers = httpx.Headers({})

    client = AsyncMock(spec=httpx.AsyncClient)
    client.post = AsyncMock(return_value=mock_resp)

    session = await auth.login(client=client)

    assert isinstance(session, AuthSession)
    assert session.bearer_token == "FAKE.JWT.TOKEN"
    assert session.flow == "bearer"

    call = client.post.call_args
    assert call.kwargs.get("json") == {"email": "alice@example.com", "password": "hunter2"}


@pytest.mark.asyncio
async def test_bearer_flow_missing_token_raises():
    auth = WebAuthenticator(
        flow="bearer",
        login_url="https://app.example/api/login",
        username="x", password="y",
        body_shape="json", token_path="authentication.token",
    )
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 200
    mock_resp.text = '{"authentication": {}}'
    mock_resp.json.return_value = {"authentication": {}}
    mock_resp.headers = httpx.Headers({})
    client = AsyncMock(spec=httpx.AsyncClient)
    client.post = AsyncMock(return_value=mock_resp)

    with pytest.raises(AuthError, match="missing token"):
        await auth.login(client=client)


@pytest.mark.asyncio
async def test_bearer_flow_form_body_shape():
    auth = WebAuthenticator(
        flow="bearer",
        login_url="https://app.example/api/login",
        username="x", password="y",
        body_shape="form", token_path="token",
    )
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 200
    mock_resp.text = '{"token": "T"}'
    mock_resp.json.return_value = {"token": "T"}
    mock_resp.headers = httpx.Headers({})
    client = AsyncMock(spec=httpx.AsyncClient)
    client.post = AsyncMock(return_value=mock_resp)

    session = await auth.login(client=client)
    assert session.bearer_token == "T"
    call = client.post.call_args
    assert call.kwargs.get("data") == {"username": "x", "password": "y"}
    assert call.kwargs.get("json") is None


@pytest.mark.asyncio
async def test_bearer_flow_non_json_response_raises():
    auth = WebAuthenticator(
        flow="bearer", login_url="https://x/y",
        username="a", password="b", body_shape="json", token_path="token",
    )
    mock_resp = MagicMock(spec=httpx.Response)
    mock_resp.status_code = 200
    mock_resp.text = "<html>not json</html>"
    mock_resp.json.side_effect = ValueError("no JSON")
    mock_resp.headers = httpx.Headers({})
    client = AsyncMock(spec=httpx.AsyncClient)
    client.post = AsyncMock(return_value=mock_resp)

    with pytest.raises(AuthError, match="not JSON"):
        await auth.login(client=client)
