"""Tests for the forged-coupon probe.

The probe's job is to detect that a target uses Juice Shop's
deterministic Z85 coupon scheme and that forged coupons mint locally
are accepted by the basket-coupon endpoint. Acceptance with a non-zero
discount is a high-severity financial-impact finding.
"""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


@pytest.fixture
def fake_session():
    return MagicMock()


def test_z85_encode_matches_canonical_rfc32_vector():
    """Canonical Z85 test vector from the RFC: 8 bytes -> 'HelloWorld'."""
    from engine.probes.web.coupon_forging import z85_encode

    # 0x86 0x4F 0xD2 0x6F 0xB5 0x59 0xF7 0x5B -> "HelloWorld" per RFC 32.
    raw = bytes([0x86, 0x4F, 0xD2, 0x6F, 0xB5, 0x59, 0xF7, 0x5B])
    assert z85_encode(raw) == "HelloWorld"


def test_z85_encode_pads_unaligned_input():
    """Inputs whose length is not a multiple of 4 are NUL-padded; output stays length 5*ceil(n/4)."""
    from engine.probes.web.coupon_forging import z85_encode

    out = z85_encode(b"abc")  # 3 bytes -> pads to 4 -> 5 chars
    assert len(out) == 5
    out2 = z85_encode(b"abcde")  # 5 bytes -> pads to 8 -> 10 chars
    assert len(out2) == 10


@pytest.mark.asyncio
async def test_forged_coupon_accepted_yields_high_finding(fake_session):
    """App config exposes the scheme + PUT redemption returns a discount -> high finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.coupon_forging import probe_coupon_forging

    config_body = json.dumps(
        {
            "config": {
                "application": {"name": "OWASP Juice Shop"},
                "challenges": {"couponCode": "FORGEME"},
            }
        }
    )
    fake_session.get.return_value = _make_response(200, config_body)

    # First PUT is the hit; subsequent calls return harmless 404 so the
    # probe doesn't blow up enumerating the rest of the basket ids.
    accept_body = json.dumps({"status": "success", "data": {"discount": 80}})
    fake_session.put.side_effect = [
        _make_response(200, accept_body),
    ] + [_make_response(404, "") for _ in range(60)]
    fake_session.post.return_value = _make_response(404, "")

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_coupon_forging(ctx)

    assert findings, "expected a finding when redemption succeeds"
    f = findings[0]
    assert f["severity"] == "high"
    assert f["bug_class"] == "business_logic"
    assert "Forged Z85 coupon accepted" in f["title"]
    assert "discount=80" in f["evidence"]


@pytest.mark.asyncio
async def test_no_finding_when_redemption_returns_401(fake_session):
    """Server requires auth and rejects the forged code -> no finding emitted."""
    from engine.probes import ProbeContext
    from engine.probes.web.coupon_forging import probe_coupon_forging

    config_body = json.dumps(
        {"config": {"application": {"name": "Juice Shop"}, "challenges": {}}}
    )
    fake_session.get.return_value = _make_response(200, config_body)
    fake_session.put.return_value = _make_response(401, '{"error":"unauthorized"}')
    fake_session.post.return_value = _make_response(401, '{"error":"unauthorized"}')

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_coupon_forging(ctx)

    assert findings == []


@pytest.mark.asyncio
async def test_no_finding_when_app_config_missing(fake_session):
    """If the config endpoint 404s, we never even mint coupons -> no finding."""
    from engine.probes import ProbeContext
    from engine.probes.web.coupon_forging import probe_coupon_forging

    fake_session.get.return_value = _make_response(404, "")
    # Should never be reached, but stub to prove it.
    fake_session.put.return_value = _make_response(200, json.dumps({"data": {"discount": 99}}))
    fake_session.post.return_value = _make_response(200, json.dumps({"data": {"discount": 99}}))

    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")
    findings = await probe_coupon_forging(ctx)

    assert findings == []
    # And specifically: no redemption attempts were issued.
    assert fake_session.put.call_count == 0
    assert fake_session.post.call_count == 0


@pytest.mark.asyncio
async def test_uses_captured_auth_when_present(fake_session):
    """When ctx.captured_auth has a token, redemption requests carry Authorization."""
    from engine.probes import ProbeContext
    from engine.probes.web.coupon_forging import probe_coupon_forging

    config_body = json.dumps(
        {"config": {"application": {"name": "Juice Shop"}, "challenges": {"couponCode": "X"}}}
    )
    fake_session.get.return_value = _make_response(200, config_body)
    fake_session.put.return_value = _make_response(404, "")
    fake_session.post.return_value = _make_response(404, "")

    ctx = ProbeContext(
        session=fake_session,
        base="http://localhost:3000",
        captured_auth={"token": "deadbeef"},
    )
    await probe_coupon_forging(ctx)

    assert fake_session.put.call_count > 0
    sent_headers = fake_session.put.call_args_list[0].kwargs.get("headers", {})
    assert sent_headers.get("Authorization") == "Bearer deadbeef"


@pytest.mark.asyncio
async def test_coupon_forging_works_on_non_juiceshop_target(fake_session):
    """Generic config body with no scheme hints: probe skips cleanly."""
    from engine.probes import ProbeContext
    from engine.probes.web.coupon_forging import probe_coupon_forging

    # 200 config body that doesn't mention z85, base64, rot13, md5,
    # sha256, or Juice Shop. Probe must NOT mint or attempt redemption.
    fake_session.get.return_value = _make_response(
        200, json.dumps({"server": "nginx", "buildId": "abc123"})
    )
    fake_session.put.return_value = _make_response(
        200, json.dumps({"data": {"discount": 99}})
    )
    fake_session.post.return_value = _make_response(
        200, json.dumps({"data": {"discount": 99}})
    )

    ctx = ProbeContext(session=fake_session, base="http://example.com")
    findings = await probe_coupon_forging(ctx)

    assert findings == []
    assert fake_session.put.call_count == 0
    assert fake_session.post.call_count == 0


def test_coupon_forging_is_registered():
    """Importing the module registers it with the expected metadata.

    The conftest fixture snapshots the registry before each test and
    restores it after, which can wipe a probe that registered for the
    first time mid-test. Reload the module so the @registry.probe
    decorator runs again under the snapshot in flight here.
    """
    import importlib

    from engine.probes import registry
    from engine.probes.web import coupon_forging

    importlib.reload(coupon_forging)

    spec = registry.get("web.coupon_forging")
    assert spec is not None
    assert spec.bug_class == "business_logic"
    assert spec.severity_max == "high"
    assert spec.requires_auth is False
    assert spec.runtime_budget_s == 10.0
    assert spec.owasp == "A04:2021"
    for tag in ("anonymous", "high-roi", "financial", "destructive-low"):
        assert tag in spec.tags
