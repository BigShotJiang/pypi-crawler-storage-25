"""Tests for the hidden-page discovery probe.

Covers Juice Shop Miscellaneous and Security-through-Obscurity
challenges (Score Board, security.txt, Chatbot API, Easter eggs).
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest


def _make_response(status: int, body: str, headers: dict[str, str] | None = None):
    resp = AsyncMock()
    resp.status = status
    resp.text = AsyncMock(return_value=body)
    resp.headers = headers or {}
    cm = AsyncMock()
    cm.__aenter__.return_value = resp
    cm.__aexit__.return_value = None
    return cm


def _responses_for(target_path: str, status: int, body: str):
    """Return a side_effect callable that returns 200/body for one path, 404 elsewhere."""

    def side_effect(url, *args, **kwargs):
        if url.endswith(target_path):
            return _make_response(status, body)
        return _make_response(404, "")

    return side_effect


@pytest.fixture
def fake_session():
    return MagicMock()


@pytest.mark.asyncio
async def test_score_board_returns_medium_finding(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.hidden_discovery import probe_hidden_discovery

    fake_session.get.side_effect = _responses_for(
        "/score-board", 200, "<html>Score Board</html>"
    )
    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    findings = await probe_hidden_discovery(ctx)

    score_board_findings = [f for f in findings if "/score-board" in f["target"]]
    assert len(score_board_findings) >= 1
    assert any(f["severity"] == "medium" for f in score_board_findings)
    assert all(f["category"] == "information_disclosure" for f in score_board_findings)


@pytest.mark.asyncio
async def test_security_txt_returns_info_finding(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.hidden_discovery import probe_hidden_discovery

    # Match the .well-known variant explicitly.
    fake_session.get.side_effect = _responses_for(
        "/.well-known/security.txt", 200, "Contact: security@example.com"
    )
    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    findings = await probe_hidden_discovery(ctx)

    sec_findings = [
        f for f in findings if f["target"].endswith("/.well-known/security.txt")
    ]
    assert len(sec_findings) == 1
    assert sec_findings[0]["severity"] == "info"
    assert sec_findings[0]["bug_class"] == "exposed_dev"


@pytest.mark.asyncio
async def test_all_paths_404_emits_no_findings(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.hidden_discovery import probe_hidden_discovery

    fake_session.get.return_value = _make_response(404, "Not Found")
    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    findings = await probe_hidden_discovery(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_chatbot_api_returns_low_finding(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.hidden_discovery import probe_hidden_discovery

    fake_session.get.side_effect = _responses_for(
        "/api/Chatbot", 200, '{"status": "ok", "body": "Hi there"}'
    )
    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    findings = await probe_hidden_discovery(ctx)

    chatbot = [f for f in findings if f["target"].endswith("/api/Chatbot")]
    assert len(chatbot) == 1
    assert chatbot[0]["severity"] == "low"
    assert "Chatbot" in chatbot[0]["title"]


@pytest.mark.asyncio
async def test_empty_body_does_not_emit_finding(fake_session):
    from engine.probes import ProbeContext
    from engine.probes.web.hidden_discovery import probe_hidden_discovery

    # Status 200 but empty body: no finding.
    fake_session.get.side_effect = _responses_for("/score-board", 200, "")
    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    findings = await probe_hidden_discovery(ctx)
    assert findings == []


@pytest.mark.asyncio
async def test_score_board_does_not_fire_on_generic_spa_shell(fake_session):
    """SPAs return 200 + shell HTML for any hash route. Without content
    validation the score-board probe was firing on every SPA target
    regardless of whether Juice Shop was actually running.
    """
    from engine.probes import ProbeContext
    from engine.probes.web.hidden_discovery import probe_hidden_discovery

    shell = "<html><app-root></app-root><script src='/main.js'></script></html>"
    fake_session.get.side_effect = _responses_for("/#/score-board", 200, shell)
    ctx = ProbeContext(session=fake_session, base="http://example.com")

    findings = await probe_hidden_discovery(ctx)

    score_board_findings = [f for f in findings if "score-board" in f["target"]]
    assert score_board_findings == [], (
        "score-board probe must require Juice-Shop-shaped content, not "
        "just a 200 from the SPA shell route"
    )


@pytest.mark.asyncio
async def test_score_board_fires_on_juice_shop_marker_present(fake_session):
    """When the body actually contains Juice Shop's score-board markers,
    the finding should still emit at medium severity."""
    from engine.probes import ProbeContext
    from engine.probes.web.hidden_discovery import probe_hidden_discovery

    juice_body = (
        "<html><body><h1>Score Board</h1>"
        "<div class='challenge'>Challenge: Find the secret</div>"
        "<span>solved: 3/100</span></body></html>"
    )
    fake_session.get.side_effect = _responses_for(
        "/#/score-board", 200, juice_body
    )
    ctx = ProbeContext(session=fake_session, base="http://localhost:3000")

    findings = await probe_hidden_discovery(ctx)

    score_board_findings = [f for f in findings if "score-board" in f["target"]]
    assert len(score_board_findings) >= 1
    assert any(f["severity"] == "medium" for f in score_board_findings)


@pytest.mark.asyncio
async def test_hidden_discovery_works_on_non_juiceshop_target(fake_session):
    """Generic target with no Juice Shop markers: only generic-path findings emit.

    A 200 hit on a Juice-Shop easter-egg path must be classed as "info"
    severity (not medium) so it doesn't pollute reports against generic
    targets that happen to serve unrelated content at that URL shape.
    """
    from engine.probes import ProbeContext
    from engine.probes.web.hidden_discovery import probe_hidden_discovery

    easter = "/the/devs/are/so/funny/they/hid/an/easter/egg/within/the/easter/egg"
    fake_session.get.side_effect = _responses_for(
        easter, 200, "<html>not juice shop</html>"
    )
    ctx = ProbeContext(session=fake_session, base="http://example.com")

    findings = await probe_hidden_discovery(ctx)

    # Whatever findings emit must NOT be medium-severity for the
    # easter-egg path; severity stays at info.
    matched = [f for f in findings if easter in f["target"]]
    for f in matched:
        assert f["severity"] == "info"


def test_hidden_discovery_is_registered():
    import importlib

    from engine.probes import registry
    from engine.probes.web import hidden_discovery

    # Force re-registration: conftest's _isolate_probe_registry fixture saves
    # the registry state BEFORE the test body runs, so any probe whose module
    # is already imported (and thus not re-decorated) needs an explicit reload
    # to land in the active registry snapshot.
    importlib.reload(hidden_discovery)

    spec = registry.get("web.hidden_discovery")
    assert spec is not None
    assert spec.bug_class == "exposed_dev"
    assert spec.severity_max == "medium"
    assert spec.requires_auth is False
    assert spec.owasp == "A05:2021"
    assert "anonymous" in spec.tags
    assert "discovery" in spec.tags
    assert spec.runtime_budget_s == 10.0
