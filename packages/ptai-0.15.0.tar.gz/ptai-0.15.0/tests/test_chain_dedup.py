"""Dedup guards on the exploit chainer.

Background: before fingerprint dedup, calling discover_chains() twice on the
same engagement appended a new attack_chains row each time because the row id
was a fresh uuid each call. Six rows from what should have been three chains.
"""

from __future__ import annotations

import pytest

from agents.exploit_chain.chain_agent import ExploitChainAgent
from engine.findings_db import FindingsDB


@pytest.fixture
def db():
    return FindingsDB(":memory:")


async def _add(db: FindingsDB, eng_id: str, **fields):
    base = {
        "engagement_id": eng_id,
        "title": "default",
        "description": "",
        "severity": "critical",
        "category": "injection",
        "target": "http://t.example",
    }
    base.update(fields)
    return await db.add_finding(base)


@pytest.mark.asyncio
async def test_discover_chains_is_idempotent(db):
    eng = await db.create_engagement("http://t.example", "full", "", "normal")
    await _add(db, eng["id"], title="SQLi /products", category="injection")
    await _add(db, eng["id"], title="Open admin port 8080", category="discovery", severity="medium")
    agent = ExploitChainAgent(db)

    first = await agent.discover_chains(eng["id"])
    second = await agent.discover_chains(eng["id"])

    rows = await db.get_attack_chains(eng["id"])
    assert len(rows) == len(first), (
        f"discover_chains is not idempotent: {len(first)} chains on first run, "
        f"{len(rows)} rows after second run"
    )
    assert len(first) == len(second)


@pytest.mark.asyncio
async def test_chain_fingerprint_stable_across_runs(db):
    eng = await db.create_engagement("http://t.example", "full", "", "normal")
    f1 = await _add(db, eng["id"], title="SQLi", category="injection")
    f2 = await _add(db, eng["id"], title="Open port", category="discovery", severity="medium")
    agent = ExploitChainAgent(db)

    chain1 = agent._try_template(
        {
            "name": "Web to Shell",
            "entry_categories": ["injection"],
            "pivot_categories": ["discovery"],
            "impact": "test",
            "context": "web",
        },
        [
            {"id": f1, "category": "injection", "severity": "critical",
             "title": "SQLi", "target": "http://t.example"},
            {"id": f2, "category": "discovery", "severity": "medium",
             "title": "Open port", "target": "http://t.example"},
        ],
        eng["id"],
    )
    chain2 = agent._try_template(
        {
            "name": "Web to Shell",
            "entry_categories": ["injection"],
            "pivot_categories": ["discovery"],
            "impact": "test",
            "context": "web",
        },
        [
            {"id": f1, "category": "injection", "severity": "critical",
             "title": "SQLi", "target": "http://t.example"},
            {"id": f2, "category": "discovery", "severity": "medium",
             "title": "Open port", "target": "http://t.example"},
        ],
        eng["id"],
    )
    assert chain1 is not None and chain2 is not None
    assert chain1["fingerprint"] == chain2["fingerprint"]
    # ids differ (fresh uuid each call), but fingerprint pins identity
    assert chain1["id"] != chain2["id"]
