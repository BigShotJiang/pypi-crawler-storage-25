"""Web Agent — LLM-driven web application and API security testing.

Follows OWASP Testing Guide v4 methodology when LLM is available.
Falls back to deterministic tool loops otherwise.
"""

import asyncio
import logging
from typing import Any

from agents.base import BaseAgent, LLMUnavailableError
from engine.llm.client import LLMClient

logger = logging.getLogger("pentest-ai.web")


def _captured_auth_from_dict(creds: dict[str, Any]) -> dict[str, Any] | None:
    """Best-effort bridge from a free-form auth_credentials dict to the
    captured_auth shape that registry probes consume. Used as a
    defense-in-depth fallback when callers pass auth_credentials but
    don't go through WebAgent.set_auth(AuthCredentials).
    """
    if not isinstance(creds, dict) or not creds:
        return None
    token = creds.get("token") or creds.get("bearer_token")
    if token:
        return {
            "token": token,
            "kind": "bearer",
            "auth_header": "Authorization",
            "auth_value": f"Bearer {token}",
            "source_endpoint": "run_assessment_arg",
            "role_hint": "",
        }
    cookie = creds.get("cookies") or creds.get("cookie")
    if cookie:
        entry: dict[str, Any] = {
            "token": cookie,
            "kind": "cookie",
            "source_endpoint": "run_assessment_arg",
            "role_hint": "",
        }
        raw = creds.get("set_cookie_raw")
        if raw:
            entry["set_cookie_raw"] = raw
        return entry
    return None


class WebAgent(BaseAgent):
    agent_type = "web"

    def __init__(self, registry: Any, db: Any, llm: LLMClient | None = None, scope: Any = None):
        super().__init__(registry, db, llm, scope=scope)
        self._captured_auth: dict[str, Any] | None = None

    def set_auth(self, creds: Any) -> None:
        """Bridge orchestrator-supplied AuthCredentials onto a probe-friendly
        captured_auth dict so requires_auth=True probes can fire from the
        deterministic CLI path. Without this the cookie/header silently
        dropped at the WebAgent boundary and any auth-gated bug class
        (mass assignment, type confusion, race condition, JWT alg:none
        on gated endpoints) was unreachable.
        """
        if not creds:
            self._captured_auth = None
            return
        # AuthCredentials shape: cookies, bearer_token, headers dict.
        cookie = getattr(creds, "cookies", "") or ""
        bearer = getattr(creds, "bearer_token", "") or ""
        headers = dict(getattr(creds, "headers", {}) or {})
        set_cookie_raw = getattr(creds, "set_cookie_raw", "") or ""
        if cookie:
            entry = {
                "token": cookie,
                "kind": "cookie",
                "source_endpoint": "cli_arg",
                "role_hint": "",
            }
            if set_cookie_raw:
                entry["set_cookie_raw"] = set_cookie_raw
            self._captured_auth = entry
        elif bearer:
            self._captured_auth = {
                "token": bearer,
                "kind": "bearer",
                "source_endpoint": "cli_arg",
                "role_hint": "",
            }
        elif "Authorization" in headers:
            value = headers["Authorization"]
            self._captured_auth = {
                "auth_header": "Authorization",
                "auth_value": value,
                "token": value.split(" ", 1)[-1] if " " in value else value,
                "kind": "bearer",
                "source_endpoint": "cli_arg",
                "role_hint": "",
            }
        else:
            self._captured_auth = None

    async def run_assessment(
        self,
        target: str,
        auth_credentials: dict[str, str] | None = None,
        focus_areas: list[str] | None = None,
        engagement_id: str = "",
    ) -> dict[str, Any]:
        logger.info(f"Starting web assessment against {target}")

        if self.llm:
            areas = focus_areas or ["all"]
            if auth_credentials:
                cred_info = f"\nAuthentication credentials provided: {list(auth_credentials.keys())}"
            else:
                cred_info = "\nNo authentication credentials provided (testing unauthenticated)."
            prompt = (
                f"Run a web application security assessment against {target}.\n"
                f"Focus areas: {', '.join(areas)}\n"
                f"{cred_info}\n\n"
                f"Follow the OWASP Testing Guide methodology:\n"
                f"1. Content discovery and tech fingerprinting\n"
                f"2. Vulnerability scanning (nuclei, nikto)\n"
                f"3. Injection testing (SQLi, XSS, SSRF, command injection)\n"
                f"4. Authentication and session testing\n"
                f"5. API endpoint discovery and testing\n"
                f"6. Business logic testing (IDOR, race conditions)\n\n"
                f"Start with built-in scanners, then use external tools. Analyze results between phases."
            )
            try:
                return await self.run_tool_loop(prompt, engagement_id)
            except LLMUnavailableError:
                logger.warning("LLM unreachable; falling back to deterministic web assessment")

        # Defense-in-depth: if a caller passed auth_credentials but did
        # not call set_auth(), bridge them now so the deterministic
        # registry sweep doesn't silently skip every requires_auth probe.
        # The MCP server's test_web_app calls set_auth explicitly (since
        # 2026-05-11 launch hardening), so on that path this is a no-op.
        if auth_credentials and self._captured_auth is None:
            self._captured_auth = _captured_auth_from_dict(auth_credentials)

        return await self._run_deterministic(target, focus_areas, engagement_id)

    async def _run_deterministic(self, target: str, focus_areas: list[str] | None, engagement_id: str) -> dict[str, Any]:  # type: ignore[override]
        areas = focus_areas or ["all"]

        # Run discovery, fingerprinting, vuln scan, crawl-for-params, and a
        # parameter-discovery step (arjun) in parallel. The crawl + arjun
        # outputs both feed the injection phase below: sqlmap and dalfox need
        # URLs with parameters to attack, and modern targets (SPAs, parameter-
        # less REST endpoints) frequently expose nothing through the crawler
        # alone. arjun bruteforces hidden GET params on the base target so
        # injection has something to chew on even in those cases.
        # Phase 1: fingerprinting + content discovery + BrowserAgent crawl
        # + SPA probes. These are light-weight and don't hammer the target.
        # BrowserAgent (Playwright) runs here so it completes before the heavy
        # scanners (nuclei, nikto) start: avoids OOM on memory-constrained hosts.
        # SPA probes run early too, because they're cheap (under 5 seconds total)
        # and they catch criticals that disappear if the heavy scanners crash
        # the target before we get to them. They go BEFORE injection / fuzzing.
        discovery_tasks = [
            self._run_tool_phase(["gobuster", "ffuf", "feroxbuster", "dirsearch"], target, engagement_id, "content_discovery"),
            self._run_tool_phase(["whatweb", "wafw00f", "httpx"], target, engagement_id, "tech_fingerprint"),
        ]
        (content_result, fp_result), param_urls, spa_findings_count = await asyncio.gather(
            asyncio.gather(*discovery_tasks, return_exceptions=True),
            self._discover_param_urls(target),
            self._run_spa_probes(target, engagement_id, []),
        )

        # Phase 2: heavy vuln scanners + hidden param discovery.
        # Run after BrowserAgent so Playwright isn't competing for memory.
        vuln_tasks = [
            self._run_tool_phase(["nuclei", "nikto", "skipfish"], target, engagement_id, "vuln_scan"),
            self._discover_hidden_params(target, engagement_id),
        ]
        vuln_result, hidden_params = await asyncio.gather(*vuln_tasks, return_exceptions=True)
        hidden_params = [] if isinstance(hidden_params, BaseException) else list(hidden_params)
        discovery_results = [content_result, fp_result, vuln_result]

        injection_targets = list(param_urls)
        # If the crawler found nothing useful but arjun discovered hidden
        # params, synthesize URLs from the base target + each discovered param.
        if not injection_targets and hidden_params:
            sep_target = target.rstrip("/")
            injection_targets = [
                f"{sep_target}/?{p}=1" for p in hidden_params[: self._MAX_INJECTION_TARGETS]
            ]
        # Even if the crawler found URLs, mix in arjun-discovered param URLs
        # against the base target so injection covers both spaces.
        elif hidden_params:
            sep_target = target.rstrip("/")
            extra = [f"{sep_target}/?{p}=1" for p in hidden_params[:5]]
            injection_targets = (injection_targets + extra)[: self._MAX_INJECTION_TARGETS]

        if not injection_targets:
            injection_targets = [target]

        injection_tasks: list[Any] = []
        if "sqli" in areas or "all" in areas:
            injection_tasks.append(self._run_injection_phase("sqlmap", injection_targets, engagement_id, "sqli"))
        if "xss" in areas or "all" in areas:
            injection_tasks.append(self._run_injection_phase("dalfox", injection_targets, engagement_id, "xss"))
        if "api" in areas or "all" in areas:
            injection_tasks.append(self._run_tool_phase(["kiterunner", "paramspider"], target, engagement_id, "api"))

        injection_results = await asyncio.gather(*injection_tasks, return_exceptions=True)

        # SPA probes already ran in Phase 1 (above), so we don't re-run here.
        # The earlier-run guarantees we capture critical findings even if the
        # injection phase ends up crashing or rate-limiting the target.

        all_results = list(discovery_results) + list(injection_results)
        total_findings = sum(r.get("findings_count", 0) for r in all_results if isinstance(r, dict))
        total_findings += spa_findings_count

        return {
            "target": target,
            "focus_areas": areas,
            "param_urls_discovered": len(param_urls),
            "hidden_params_discovered": len(hidden_params),
            "spa_probe_findings": spa_findings_count,
            "findings_count": total_findings,
            "status": "complete",
        }

    async def _run_spa_probes(
        self, target: str, engagement_id: str, param_urls: list[str]
    ) -> int:
        """Run BOTH the legacy 14 SPA probes AND every @probe in the registry.

        Before the autonomy roadmap, this only called agents/web/spa_probes
        run_all_probes (14 probes hand-wired in the gather list). The 30+
        new probes registered via @registry.probe in engine/probes/web/
        (cors_reflection, idor_*, ssti_*, mass_assignment, sqli_fuzz, xss_fuzz,
        etc) never ran on the legacy path. Now both run; results are
        deduped by (title, target) before persistence.
        """
        # Pass any .js URLs the crawler saw so source-map probe has candidates.
        js_urls = [u for u in param_urls if ".js" in u]

        legacy_findings: list[dict[str, Any]] = []
        registry_findings: list[dict[str, Any]] = []

        try:
            from agents.web.spa_probes import run_all_probes
            legacy_findings = await run_all_probes(target, js_urls=js_urls)
        except Exception as e:  # noqa: BLE001
            logger.warning("legacy spa_probes failed: %s", e)

        try:
            registry_findings = await self._run_registry_probes(
                target, engagement_id=engagement_id, js_urls=js_urls
            )
        except Exception as e:  # noqa: BLE001
            logger.warning("registry probes run failed: %s", e)

        # Dedup on (title, target) so we don't double-count when both paths
        # find the same bug (jwt_alg_none on /api/Users etc).
        seen: set[tuple[str, str]] = set()
        all_findings: list[dict[str, Any]] = []
        for f in legacy_findings + registry_findings:
            key = (f.get("title", ""), f.get("target", ""))
            if key in seen:
                continue
            seen.add(key)
            all_findings.append(f)

        for f in all_findings:
            f["engagement_id"] = engagement_id
            try:
                await self.db.add_finding(f)
            except Exception as e:  # noqa: BLE001
                logger.warning("spa_probe finding persist failed: %s", e)

        if all_findings:
            logger.info(
                "spa_probes added %d findings (legacy=%d, registry=%d, after dedup=%d)",
                len(all_findings),
                len(legacy_findings),
                len(registry_findings),
                len(all_findings),
            )
        return len(all_findings)

    async def _run_registry_probes(
        self, target: str, engagement_id: str | None = None,
        js_urls: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """Run every @probe in engine.probes.registry and aggregate findings.

        Three-pass design:
          1. Reachability check: 2s GET on base URL. If it fails, skip ALL
             registry probes (avoids 47 x 3s connection-refused on unresolvable
             targets in unit tests).
          2. Discovery pass: run web.api_path_discovery synchronously first
             to seed candidate_endpoints. Without this, downstream probes
             (sqli, xxe, ssrf, mass assignment) only see the base URL and
             miss every authenticated route the app doesn't link from its
             public pages.
          3. Parallel run: asyncio.gather across the remaining probes with
             a global cap, so one slow probe doesn't block the rest. Each
             probe gets a ProbeContext seeded with the discovered paths
             plus any captured_auth this agent was told about via set_auth.
        """
        import asyncio

        import aiohttp

        # Importing engine.probes.web triggers @probe decorators across every
        # probe module so registry.all() returns the full set.
        import engine.probes.web  # noqa: F401
        from engine.probes import ProbeContext, registry

        # Safe-mode opt-in: when the engagement was started with
        # intensity="safe", skip every probe tagged destructive-low so we
        # don't mutate state on the target. Default intensity (normal/
        # stealth/aggressive) keeps all probes.
        exclude_tags: tuple[str, ...] = ()
        session_extras: dict[str, Any] = {}
        if engagement_id:
            try:
                eng = await self.db.get_engagement(engagement_id)
            except Exception:  # noqa: BLE001
                eng = None
            if eng:
                if (eng.get("intensity") or "").lower() == "safe":
                    exclude_tags = ("destructive-low",)
                if eng.get("respect_rate_limits"):
                    session_extras["respect_rate_limits"] = True
                if eng.get("strict_scope"):
                    session_extras["strict_scope"] = True
                    session_extras["engagement_target"] = eng.get("target") or target

        all_specs = registry.all(exclude_tags=exclude_tags)
        if not all_specs:
            return []

        findings: list[dict[str, Any]] = []
        async with aiohttp.ClientSession() as session:
            # Surface opt-in safety flags to the HTTP primitives via a
            # session-attached attribute. Default sessions have nothing
            # attached, so primitives behave exactly as before.
            if session_extras:
                session._ptai_extras = session_extras  # type: ignore[attr-defined]
            # Pass 1: reachability. A 2-second budget tells us whether running
            # 47 probes would just time out 47 times. Cheap insurance.
            try:
                async with session.get(
                    target,
                    timeout=aiohttp.ClientTimeout(total=2),
                    allow_redirects=False,
                ) as resp:
                    _ = resp.status  # consume to avoid unclosed warning
            except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
                logger.debug(
                    "registry probes skipped: target %s unreachable (%s)",
                    target,
                    exc,
                )
                return []

            # Pass 2: discovery. Run api_path_discovery first so its
            # discovered paths (admin/users, api/secrets, internal/whoami,
            # etc) become candidate_endpoints for every other probe. The
            # whole point of discovery probes is to feed downstream ones.
            discovery_ctx = ProbeContext(
                session=session,
                base=target,
                js_urls=tuple(js_urls),
                captured_auth=self._captured_auth,
            )
            discovered_paths: list[str] = []
            api_path_spec = next(
                (s for s in all_specs if s.name == "web.api_path_discovery"), None,
            )
            if api_path_spec is not None:
                try:
                    api_findings = await asyncio.wait_for(
                        api_path_spec.fn(discovery_ctx), timeout=20,
                    )
                    findings.extend(api_findings or [])
                    for f in api_findings or []:
                        path = f.get("target", "")
                        if path.startswith(target):
                            path = path[len(target):] or "/"
                        if path and path not in discovered_paths:
                            discovered_paths.append(path)
                except (asyncio.TimeoutError, Exception) as exc:  # noqa: BLE001
                    logger.debug("api_path_discovery failed: %s", exc)

            # Pass 3: parallel run with per-probe budget enforcement.
            # Discovered paths flow through ctx.candidate_endpoints so
            # SQLi / XXE / SSRF / mass-assignment probes test them.
            ctx = ProbeContext(
                session=session,
                base=target,
                js_urls=tuple(js_urls),
                captured_auth=self._captured_auth,
                candidate_endpoints=tuple(discovered_paths),
            )

            # Cap concurrent probes. 53 probes hammering one target at once
            # exhausts Juice Shop's request handlers; many probes that solo
            # under their declared budget time out under that pressure.
            # 8 concurrent keeps individual probes responsive without
            # making the wall clock balloon.
            sem = asyncio.Semaphore(8)

            async def _run_one(spec):
                # api_path_discovery already ran in the discovery pass.
                if spec.name == "web.api_path_discovery":
                    return []
                # Skip auth-required probes only when we don't have a session.
                # When set_auth populated captured_auth, those probes can
                # actually run and surface the auth-gated bug classes
                # (mass assignment, type confusion, race condition, etc).
                if spec.requires_auth and self._captured_auth is None:
                    return []
                # Per-probe timeout must accommodate queueing behind the
                # semaphore on top of the declared runtime. 2x the budget
                # plus 10s gives slow probes (sqli_fuzz, xss_fuzz, ssti_fuzz)
                # the headroom they need on a busy target.
                budget = max(spec.runtime_budget_s * 2 + 10, 30)
                async with sem:
                    try:
                        return await asyncio.wait_for(spec.fn(ctx), timeout=budget)
                    except (asyncio.TimeoutError, Exception) as exc:  # noqa: BLE001
                        logger.debug("registry probe %s failed: %s", spec.name, exc)
                        return []

            results = await asyncio.gather(
                *(_run_one(s) for s in all_specs), return_exceptions=False
            )
            for res in results:
                for f in res or []:
                    findings.append(f)
        return findings

    # Per-tool wall-clock cap inside deterministic mode. nuclei + nikto need
    # ~60-90s to land real findings on a typical web app; the previous 30s was
    # too aggressive and produced zero findings on intentionally-vulnerable
    # targets like Juice Shop (the canonical training app). Per-tool timeout
    # here is the ceiling, individual tools still finish faster on small apps.
    _DETERMINISTIC_TOOL_TIMEOUT = 120.0

    # Crawler step is a setup phase, not a find-vulns phase. Cap shorter so the
    # injection phase doesn't sit waiting on a slow archive query.
    _CRAWL_TIMEOUT = 60.0

    # Cap parameterized URLs sent to sqlmap/dalfox. Each injection run can take
    # 30-120s; without a cap a chatty crawler can stretch the injection phase
    # to hours.
    _MAX_INJECTION_TARGETS = 20
    # URL substrings that are never useful injection targets: dynamic transport
    # tokens (socket.io, SockJS), asset hashes, health-check paths, etc.
    _NOISE_URL_SUBSTRINGS: tuple[str, ...] = (
        "socket.io",
        "sockjs",
        "/ws",
        "transport=polling",
        "transport=websocket",
        "/__webpack",
        "/_next/",
        "/__vite",
        "/static/",
        "/assets/",
        "/fonts/",
        "/images/",
        "favicon",
        ".map?",
        ".js?",
        ".css?",
    )

    # arjun bruteforces param names; on a small target it usually finishes in
    # 30-60s. Cap so it can't dominate the wall-clock for a single phase.
    _ARJUN_TIMEOUT = 90.0

    async def _run_tool_phase(self, tool_names: list[str], target: str, engagement_id: str, phase: str) -> dict[str, Any]:
        """Run all installed tools in this phase in parallel with a per-tool timeout.

        Previously ran sequentially; nuclei + nikto + skipfish in series could push
        a single phase past 5 minutes even with everything mocked. Parallel + 30s
        cap keeps a full deterministic web assessment under a minute.
        """
        installed = []
        for name in tool_names:
            tool = self.registry.get_tool(name) if self.registry else None
            if tool and tool.is_installed():
                installed.append((name, tool))

        if not installed:
            return {"phase": phase, "findings_count": 0}

        async def _run_one(name: str, tool: Any) -> list[dict[str, Any]]:
            try:
                # Push the timeout into tool.execute() instead of wrapping in
                # wait_for here. tool.execute() kills the subprocess on timeout;
                # wait_for would only cancel the await and orphan the subprocess,
                # which previously caused ptai to hang on shutdown.
                result = await tool.execute(target, timeout=self._DETERMINISTIC_TOOL_TIMEOUT)
                if result.get("exit_code") == -1:
                    logger.warning(f"{name} timed out after {self._DETERMINISTIC_TOOL_TIMEOUT}s in phase {phase}")
                return result.get("findings", []) or []
            except Exception as e:
                logger.warning(f"{name} failed in phase {phase}: {e}")
                return []

        findings_lists = await asyncio.gather(*[_run_one(n, t) for n, t in installed])
        findings_count = 0
        for findings in findings_lists:
            findings_count += len(findings)
            for f in findings:
                f["engagement_id"] = engagement_id
                await self.db.add_finding(f)
        return {"phase": phase, "findings_count": findings_count}

    async def _discover_param_urls(self, target: str) -> list[str]:
        """Run a crawler against the target and return URLs that have query params.

        Tries external crawlers in priority order (katana, hakrawler, gau).
        If they return nothing (typical for SPAs and hash-routed apps that
        external crawlers can't render), falls back to the BrowserAgent
        which uses Playwright to actually render the page and harvest:

        - XHR/fetch endpoints called during initial render
        - DOM links present after JS hydration
        - Hash-routed SPA URLs normalized to server-route form

        Returns an empty list if no crawler succeeds, in which case the caller
        falls back to the bare target.
        """
        for name in ("katana", "hakrawler", "gau"):
            tool = self.registry.get_tool(name) if self.registry else None
            if not tool or not tool.is_installed():
                continue
            try:
                result = await tool.execute(target, timeout=self._CRAWL_TIMEOUT)
            except Exception as e:
                logger.warning(f"crawler {name} failed: {e}")
                continue
            stdout = result.get("stdout", "") or ""
            seen: set[str] = set()
            urls: list[str] = []
            for raw in stdout.splitlines():
                line = raw.strip()
                if "?" not in line or not line.startswith(("http://", "https://")):
                    continue
                key = line.split("#", 1)[0]
                if key in seen:
                    continue
                seen.add(key)
                urls.append(line)
                if len(urls) >= self._MAX_INJECTION_TARGETS:
                    break
            if urls:
                logger.info(f"crawler {name} found {len(urls)} parameterized URLs to inject against")
                return urls
            logger.info(f"crawler {name} found no parameterized URLs, will try browser fallback")
            break

        # External crawler returned nothing useful (or none installed).
        # Run swagger spec parser and BrowserAgent in parallel for best coverage.
        swagger_urls, browser_urls = await asyncio.gather(
            self._discover_from_swagger(target),
            self._discover_param_urls_via_browser(target),
        )
        merged: list[str] = list(swagger_urls)
        seen_merged: set[str] = set(swagger_urls)
        for u in browser_urls:
            if u not in seen_merged:
                seen_merged.add(u)
                merged.append(u)
        if merged:
            if swagger_urls:
                logger.info(f"OpenAPI spec: {len(swagger_urls)} endpoints; BrowserAgent supplement: {len(browser_urls)} URLs")
            else:
                logger.info(f"BrowserAgent found {len(browser_urls)} parameterized URLs")
            return self._filter_injection_targets(merged)[: self._MAX_INJECTION_TARGETS]

        logger.info("no crawler produced parameterized URLs; injection phase will run against bare target")
        return []

    def _filter_injection_targets(self, urls: list[str]) -> list[str]:
        """Remove URLs that are useless for injection: dynamic transport tokens,
        asset URLs, and other noise that wastes injection budget.
        """
        clean: list[str] = []
        for url in urls:
            lower = url.lower()
            if any(noise in lower for noise in self._NOISE_URL_SUBSTRINGS):
                logger.debug(f"filtered noise URL from injection targets: {url[:80]}")
                continue
            clean.append(url)
        return clean

    async def _target_is_alive(self, target: str) -> bool:
        """Quick liveness check before running the injection phase.
        Returns True if the target responds to an HTTP request.
        """
        import urllib.error
        import urllib.request
        try:
            req = urllib.request.Request(target, headers={"User-Agent": "ptai-health-check/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                return resp.status < 500
        except urllib.error.HTTPError as e:
            return e.code < 500
        except Exception:
            return False

    async def _discover_from_swagger(self, target: str) -> list[str]:
        """Fetch and parse OpenAPI / Swagger spec from well-known paths.
        Returns a list of parameterized URLs suitable for injection testing.
        Extracts GET endpoints that have query parameters defined in the spec.
        """
        import json
        import re
        import urllib.error
        import urllib.request

        base = target.rstrip("/")
        swagger_paths = [
            "/api-docs/swagger.yaml",
            "/api-docs",
            "/swagger.json",
            "/openapi.json",
            "/api/swagger.json",
            "/api/openapi.json",
            "/v1/swagger.json",
            "/api/v1/openapi.json",
            "/swagger/v1/swagger.json",
        ]
        spec: dict | None = None
        for path in swagger_paths:
            url = base + path
            try:
                req = urllib.request.Request(url, headers={"Accept": "application/json,application/yaml,text/yaml,*/*", "User-Agent": "ptai-api-discovery/1.0"})
                with urllib.request.urlopen(req, timeout=8) as resp:
                    raw = resp.read().decode("utf-8", errors="replace")
                # Try JSON first
                try:
                    spec = json.loads(raw)
                    logger.info(f"Found OpenAPI spec at {url}")
                    break
                except json.JSONDecodeError:
                    pass
                # Try YAML
                try:
                    import yaml  # type: ignore[import]
                    spec = yaml.safe_load(raw)
                    if isinstance(spec, dict) and ("paths" in spec or "openapi" in spec or "swagger" in spec):
                        logger.info(f"Found OpenAPI/Swagger YAML spec at {url}")
                        break
                    spec = None
                except Exception:
                    pass
            except (urllib.error.URLError, Exception):
                continue

        if not spec or not isinstance(spec, dict):
            return []

        # Determine base URL from spec servers or fall back to target
        server_base = base
        servers = spec.get("servers", [])
        if servers and isinstance(servers[0], dict):
            server_url = servers[0].get("url", "")
            if server_url.startswith("http"):
                server_base = server_url.rstrip("/")

        found: list[str] = []
        paths = spec.get("paths", {})
        for api_path, methods in paths.items():
            if not isinstance(methods, dict):
                continue
            for method, op in methods.items():
                if method.lower() not in ("get",):
                    continue
                if not isinstance(op, dict):
                    continue
                params = op.get("parameters", [])
                query_params = [
                    p.get("name", "param")
                    for p in params
                    if isinstance(p, dict) and p.get("in") == "query"
                ]
                if query_params:
                    qs = "&".join(f"{n}=1" for n in query_params[:3])
                    full_path = api_path
                    # Replace path params with placeholder values
                    full_path = re.sub(r"\{[^}]+\}", "1", full_path)
                    url = server_base + full_path + "?" + qs
                    found.append(url)
                    if len(found) >= 30:
                        break
            if len(found) >= 30:
                break

        logger.info(f"Swagger parser extracted {len(found)} parameterized API endpoints")
        return found

    async def _discover_param_urls_via_browser(self, target: str) -> list[str]:
        """Use Playwright (via BrowserAgent) to render target and extract URLs.

        Optional: skipped silently if Playwright isn't installed (no
        ptai[browser] extra). Catches the SPA case where katana sees only
        the empty shell HTML and external crawlers find nothing.
        """
        try:
            from agents.browser.browser_agent import BrowserAgent
        except ImportError:
            return []
        try:
            agent = BrowserAgent(headless=True, timeout_ms=int(self._CRAWL_TIMEOUT * 1000))
            endpoints = await agent.crawl_for_endpoints(target, max_endpoints=50)
        except RuntimeError as e:
            # BrowserAgent raises RuntimeError when Playwright isn't installed.
            logger.info(f"browser-based crawler unavailable: {e}")
            return []
        except Exception as e:
            logger.warning(f"browser-based crawler failed: {e}")
            return []

        param_urls: list[str] = []
        seen: set[str] = set()
        for url in endpoints:
            if "?" not in url:
                continue
            key = url.split("#", 1)[0]
            if key in seen:
                continue
            seen.add(key)
            param_urls.append(url)
            if len(param_urls) >= self._MAX_INJECTION_TARGETS:
                break
        if param_urls:
            logger.info(
                f"browser crawler found {len(param_urls)} parameterized URLs from rendered DOM"
            )
        return param_urls

    async def _discover_hidden_params(self, target: str, engagement_id: str) -> list[str]:
        """Run arjun against the target's base URL to find hidden GET params.

        arjun bruteforces a wordlist of common param names against the URL,
        looking for response-delta or reflection signals. The returned param
        names are then synthesized into URLs the injection phase can attack.

        Persists the discovery as a finding so the audit + chaining stages
        know which params were considered. Returns an empty list if arjun is
        not installed, fails, or produces no params.
        """
        arjun = self.registry.get_tool("arjun") if self.registry else None
        if not arjun or not arjun.is_installed():
            return []
        try:
            result = await arjun.execute(target, timeout=self._ARJUN_TIMEOUT)
        except Exception as e:
            logger.warning(f"arjun param discovery failed: {e}")
            return []
        if result.get("exit_code") == -1:
            logger.warning("arjun param discovery timed out")
        for f in result.get("findings", []) or []:
            f["engagement_id"] = engagement_id
            await self.db.add_finding(f)
        # Re-extract param names from stdout for the injection synthesis;
        # we don't want to depend on the parser's exact finding shape.
        from tools.registry import _extract_arjun_params
        params = _extract_arjun_params(result.get("stdout", "") or "")
        if params:
            logger.info(f"arjun discovered {len(params)} hidden params: {params[:10]}")
        return params

    async def _run_injection_phase(
        self, tool_name: str, urls: list[str], engagement_id: str, phase: str
    ) -> dict[str, Any]:
        """Run an injection tool (sqlmap, dalfox) once per parameterized URL.

        Each URL runs in parallel with the same per-tool timeout used elsewhere.
        Findings are tagged with the engagement and persisted as usual.
        """
        tool = self.registry.get_tool(tool_name) if self.registry else None
        if not tool or not tool.is_installed():
            return {"phase": phase, "findings_count": 0}

        async def _run_one(url: str) -> list[dict[str, Any]]:
            try:
                result = await tool.execute(url, timeout=self._DETERMINISTIC_TOOL_TIMEOUT)
                if result.get("exit_code") == -1:
                    logger.warning(f"{tool_name} timed out on {url}")
                return result.get("findings", []) or []
            except Exception as e:
                logger.warning(f"{tool_name} failed on {url}: {e}")
                return []

        findings_lists = await asyncio.gather(*[_run_one(u) for u in urls])
        findings_count = 0
        for findings in findings_lists:
            findings_count += len(findings)
            for f in findings:
                f["engagement_id"] = engagement_id
                await self.db.add_finding(f)
        return {"phase": phase, "findings_count": findings_count, "targets_tested": len(urls)}
