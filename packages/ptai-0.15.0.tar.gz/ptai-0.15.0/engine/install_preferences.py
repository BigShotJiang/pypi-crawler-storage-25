"""Persistent install-prompt preferences at ``~/.pentest-ai/install-preferences.json``.

The smart-install flow consults this file so users aren't re-prompted every
engagement. Schema:

.. code-block:: json

    {
      "auto_install": false,
      "denied_tools": ["wpscan"],
      "approved_methods": {"apt": true, "go": false, "pip": true, "cargo": false},
      "last_updated": "2026-05-12T22:00:00+00:00"
    }

Conservative defaults: ``auto_install`` is False (always ask in interactive
shells; skip silently in non-interactive). ``denied_tools`` and
``approved_methods`` start empty. Updates round-trip through ``save()``.
"""
from __future__ import annotations

import contextlib
import json
import logging
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger("pentest-ai.install_preferences")

_DEFAULT_PATH = Path.home() / ".pentest-ai" / "install-preferences.json"


def _default_methods() -> dict[str, bool]:
    return {"apt": False, "go": False, "pip": False, "cargo": False}


@dataclass
class InstallPreferences:
    """Round-trip wrapper for the preferences JSON."""

    auto_install: bool = False
    denied_tools: list[str] = field(default_factory=list)
    approved_methods: dict[str, bool] = field(default_factory=_default_methods)
    last_updated: str | None = None

    def deny(self, tool_name: str) -> None:
        if tool_name not in self.denied_tools:
            self.denied_tools.append(tool_name)

    def approve_method(self, method: str) -> None:
        self.approved_methods[method] = True

    def is_denied(self, tool_name: str) -> bool:
        return tool_name in self.denied_tools

    def is_method_approved(self, method: str) -> bool:
        return bool(self.approved_methods.get(method, False))


def load(path: Path | None = None) -> InstallPreferences:
    """Load preferences from disk. Missing file or corrupt JSON returns defaults."""
    path = path or _path_from_env()
    if not path.exists():
        return InstallPreferences()
    try:
        data = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("install_preferences: could not parse %s: %s", path, exc)
        return InstallPreferences()

    methods = _default_methods()
    methods.update(data.get("approved_methods") or {})
    return InstallPreferences(
        auto_install=bool(data.get("auto_install", False)),
        denied_tools=list(data.get("denied_tools") or []),
        approved_methods=methods,
        last_updated=data.get("last_updated"),
    )


def save(prefs: InstallPreferences, path: Path | None = None) -> Path:
    """Write the preferences JSON. Creates the parent directory if needed."""
    path = path or _path_from_env()
    path.parent.mkdir(parents=True, exist_ok=True)
    prefs.last_updated = datetime.now(timezone.utc).isoformat()
    payload = json.dumps(asdict(prefs), indent=2, sort_keys=True)
    path.write_text(payload)
    with contextlib.suppress(OSError):
        # Best-effort chmod; some filesystems don't support it.
        os.chmod(path, 0o600)
    return path


def _path_from_env() -> Path:
    override = os.environ.get("PTAI_INSTALL_PREFS")
    return Path(override).expanduser() if override else _DEFAULT_PATH
