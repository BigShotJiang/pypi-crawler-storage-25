"""LLMAgent backed by the Anthropic Messages API.

Given a working-memory state snapshot and the registered handler list,
asks Claude to return a JSON object with action/args/rationale, parses
it, and returns an Action. Malformed responses fall back to 'finish'
so the loop terminates rather than looping on a bad LLM output.
"""
from __future__ import annotations

import json
import logging
from typing import Any

from engine.agent_loop import Action

logger = logging.getLogger("pentest-ai.anthropic_agent")

SYSTEM_PROMPT = """You are an offensive-security agent driving an
authorized penetration test against a target. You have access to a
fixed set of registered probe handlers. On each turn you receive the
current engagement state (findings, endpoints, coverage, last action,
last observation) and must respond with a single JSON object naming
the next action to run.

Response format, exact JSON, no prose around it:
  {
    "action": "<handler-name from the registered list, or 'finish'>",
    "args": {<keyword args for the handler>},
    "rationale": "<one short sentence why>"
  }

Pick 'finish' when the coverage matrix is full or no productive
action remains. Pick a handler from the registered list otherwise.
Do not invent handler names. Do not request actions outside the
registered list.

Authorized testing only. Never propose actions that would harm
infrastructure outside the engagement scope.
"""

DEFAULT_MODEL = "claude-sonnet-4-6"


class AnthropicAgent:
    def __init__(
        self,
        client: Any,
        registered_handlers: list[str],
        *,
        model: str = DEFAULT_MODEL,
        max_tokens: int = 1024,
    ):
        self._client = client
        self._handlers = list(registered_handlers)
        self._model = model
        self._max_tokens = max_tokens

    async def decide_next_action(self, state: dict[str, Any]) -> Action:
        user_msg = self._render_user_message(state)
        try:
            resp = await self._client.messages.create(
                model=self._model,
                max_tokens=self._max_tokens,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": user_msg}],
            )
        except Exception as e:
            logger.warning("Anthropic call failed: %s", e)
            return Action(
                name="finish",
                rationale=f"LLM call failed, terminating: {e}",
            )

        text = self._extract_text(resp)
        return self._parse_action(text)

    def _render_user_message(self, state: dict[str, Any]) -> str:
        return (
            "Registered handlers: " + json.dumps(self._handlers) + "\n\n"
            "Engagement state:\n" + json.dumps(state, indent=2, sort_keys=True) +
            "\n\nReply with a single JSON object as specified."
        )

    @staticmethod
    def _extract_text(resp: Any) -> str:
        try:
            return resp.content[0].text or ""
        except (AttributeError, IndexError, TypeError):
            return ""

    @staticmethod
    def _parse_action(text: str) -> Action:
        if not text:
            return Action(name="finish", rationale="empty LLM response, unparseable")
        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return Action(name="finish", rationale="no JSON in LLM response, unparseable")
        try:
            payload = json.loads(text[start : end + 1])
        except (TypeError, ValueError, json.JSONDecodeError):
            return Action(name="finish", rationale="malformed JSON in LLM response, unparseable")
        name = payload.get("action") or "finish"
        args = payload.get("args") or {}
        rationale = payload.get("rationale") or ""
        if not isinstance(args, dict):
            args = {}
        if not isinstance(rationale, str):
            rationale = str(rationale)
        return Action(name=name, args=args, rationale=rationale)
