"""Agent implementations for the agent loop.

AnthropicAgent is the production path. Test suites use a fake/scripted
agent to keep unit tests offline.
"""
