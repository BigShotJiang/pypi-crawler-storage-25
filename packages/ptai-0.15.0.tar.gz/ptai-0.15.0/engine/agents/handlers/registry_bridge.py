"""Bridge between the probe registry and the agent loop.

For every ProbeSpec in `engine.probes.registry`, this module can build a
generic agent-loop handler that:

1. Constructs a ProbeContext from WorkingMemory + the dispatch args
2. Calls the probe function under an aiohttp.ClientSession
3. Translates each finding dict into a FindingRef row in WorkingMemory
4. Marks coverage on the (endpoint, bug-class) pair per finding
5. Wraps the result in an Observation

`register_all_probes()` walks the registry and wires one handler per probe
into the agent loop's `_HANDLERS` dict. Probes acquire auto-discovery this
way: the LLM sees `probe.web.cors_reflection`, `probe.web.idor_sequential`,
etc. without any manual handler-shim per probe.
"""
from __future__ import annotations

import logging
import urllib.parse
from collections.abc import Callable
from typing import Any

import aiohttp

from engine.agent_loop import NormalizedResult, Observation, register_handler
from engine.probes import ProbeContext, ProbeSpec, registry
from engine.working_memory import CapturedAuth, EndpointKey, FindingRef, WorkingMemory

logger = logging.getLogger("pentest-ai.handlers.registry_bridge")


def _captured_auth_to_dict(captured: list[CapturedAuth]) -> dict[str, Any] | None:
    """Pick the most-privileged auth and return as plain dict for ProbeContext.

    Probes need a flat dict, not the typed CapturedAuth dataclass, because
    they may run in environments without ptai imports (subagents, future
    plugin packages). Prefer admin-role auth, fall back to any.
    """
    if not captured:
        return None
    admin = [a for a in captured if a.role_hint == "admin"]
    pick = admin[-1] if admin else captured[-1]
    return {
        "token": pick.value,
        "kind": pick.kind,
        "source_endpoint": pick.source_endpoint,
        "role_hint": pick.role_hint,
    }


def _path_from_target(target: str, base: str) -> str:
    """Extract the URL path from a finding's target.

    Falls back to the raw target if parsing fails.
    """
    base = base.rstrip("/")
    if target.startswith(base):
        path = target[len(base):]
        return path or "/"
    try:
        return urllib.parse.urlparse(target).path or "/"
    except (ValueError, AttributeError):
        return target


def _ref_from_finding(f: dict[str, Any], bug_class: str) -> FindingRef:
    return FindingRef(
        id=f.get("id") or "",
        severity=f.get("severity", "info"),
        category=f.get("category", "discovery"),
        bug_class=bug_class,
        target=f.get("target", ""),
        poc_status=f.get("poc_status", "pending"),
    )


def _build_normalized(
    action_name: str, target: str, findings: list[dict[str, Any]]
) -> NormalizedResult:
    """Convert probe findings into a single bounded NormalizedResult.

    Sent to the LLM in place of the raw findings list. Truncation caps
    are inside NormalizedResult.__post_init__; we just pick the highest-
    severity finding's metadata as the representative evidence.
    """
    if not findings:
        return NormalizedResult(
            tool=action_name,
            target=target,
            verdict="inconclusive",
            evidence=f"no findings on {action_name}",
        )

    # Pick the first critical/high finding as the representative
    severity_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    sorted_findings = sorted(
        findings,
        key=lambda f: severity_rank.get(f.get("severity", "info"), 4),
    )
    rep = sorted_findings[0]
    title = rep.get("title", "") or ""
    evidence_str = rep.get("evidence", "") or ""

    # Try to parse http_status out of evidence "status=NNN" hint
    http_status = None
    if "status=" in evidence_str:
        try:
            after = evidence_str.split("status=", 1)[1].split()[0].rstrip(",.")
            http_status = int(after)
        except (ValueError, IndexError):
            http_status = None

    return NormalizedResult(
        tool=action_name,
        target=rep.get("target") or target,
        verdict="confirmed",
        evidence=title[:120] if title else evidence_str[:120],
        payload_used=rep.get("payload"),
        http_status=http_status,
        response_snippet=evidence_str[:200] if evidence_str else None,
    )


def make_handler_for_spec(spec: ProbeSpec) -> Callable:
    """Return an agent-loop handler bound to one ProbeSpec.

    The handler reads memory state, builds a ProbeContext, calls the probe,
    persists findings + coverage, and returns an Observation.
    """

    async def handler(memory: WorkingMemory, args: dict[str, Any]) -> Observation:
        action_name = f"probe.{spec.name}"
        findings_before = len(memory.findings)
        endpoints_before = len(memory.endpoints_seen)

        # Step 4 (inter-probe dataflow): the LLM (or another probe) can pass
        # any ProbeContext field via args. Common cases:
        #   - candidate_endpoints: list of paths to test (instead of defaults)
        #   - endpoint_hints: paths the probe should focus on
        #   - js_urls: JS bundles for source-map / leaked-credentials probes
        #   - findings_so_far: prior findings the probe should reason about
        #   - captured_auth: override for memory.captured_auth (e.g. test as another role)
        #   - extras: opaque dict for probe-specific args (e.g. tamper="space2comment")
        candidates = tuple(args.get("candidate_endpoints") or ())
        endpoint_hints = tuple(args.get("endpoint_hints") or ())
        js_urls = tuple(args.get("js_urls") or ())
        findings_so_far = tuple(args.get("findings_so_far") or ())
        captured_auth_override = args.get("captured_auth")
        extras = dict(args.get("extras") or {})
        # Anything else in args becomes extras so probes can read tampers, payloads, etc.
        for k, v in args.items():
            if k not in (
                "candidate_endpoints",
                "endpoint_hints",
                "js_urls",
                "findings_so_far",
                "captured_auth",
                "extras",
            ):
                extras.setdefault(k, v)

        captured_auth_dict = (
            captured_auth_override
            if captured_auth_override is not None
            else _captured_auth_to_dict(memory.captured_auth)
        )

        try:
            async with aiohttp.ClientSession() as session:
                ctx = ProbeContext(
                    session=session,
                    base=memory.target,
                    captured_auth=captured_auth_dict,
                    candidate_endpoints=candidates,
                    endpoint_hints=endpoint_hints,
                    js_urls=js_urls,
                    findings_so_far=findings_so_far,
                    extras=extras,
                )
                findings = await spec.fn(ctx)
        except Exception as exc:  # noqa: BLE001 - probe-level failures must not crash the loop
            logger.warning("probe %s failed: %s", spec.name, exc)
            return Observation(
                action_name=action_name,
                success=False,
                error=str(exc),
                normalized=NormalizedResult(
                    tool=action_name,
                    target=memory.target,
                    verdict="failed",
                    evidence=str(exc)[:120],
                ),
            )

        for f in findings or []:
            memory.add_finding(_ref_from_finding(f, spec.bug_class))
            target = f.get("target", "")
            if target:
                path = _path_from_target(target, memory.target)
                ep = EndpointKey("GET", path)
                memory.add_endpoint(ep)
                memory.coverage.mark_tried(ep, spec.bug_class, hit=True)

        normalized = _build_normalized(action_name, memory.target, findings or [])

        return Observation(
            action_name=action_name,
            success=True,
            findings_added=len(memory.findings) - findings_before,
            endpoints_added=len(memory.endpoints_seen) - endpoints_before,
            normalized=normalized,
        )

    handler.__name__ = f"handler_for_{spec.name.replace('.', '_')}"
    return handler


def register_all_probes(*, force: bool = False) -> list[str]:
    """Wire every registered probe into the agent loop's handler table.

    Returns the list of action names that were registered. Already-present
    handler names are skipped silently (so re-importing modules is safe).
    Pass force=True to overwrite existing handlers.
    """
    from engine.agent_loop import _HANDLERS  # local import to avoid cycles

    registered: list[str] = []
    for spec in registry.all():
        action_name = f"probe.{spec.name}"
        if action_name in _HANDLERS and not force:
            continue
        if force:
            _HANDLERS.pop(action_name, None)
        register_handler(action_name, make_handler_for_spec(spec))
        registered.append(action_name)
    return registered
