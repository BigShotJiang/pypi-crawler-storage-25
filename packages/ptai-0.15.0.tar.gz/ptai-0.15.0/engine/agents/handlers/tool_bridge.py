"""Bridge between the SecurityTool wrappers and the agent loop.

For every wrapper in `tools.registry.ToolRegistry`, this module builds a
generic agent-loop handler that:

1. Resolves the target from WorkingMemory + dispatch args.
2. Applies the scope guard (rejects off-scope targets before any subprocess).
3. Checks `is_installed()` — surfaces an install hint to the LLM if missing.
4. Calls `SecurityTool.execute(target, args, timeout)` with a hard-capped timeout.
5. Maps each finding dict into a FindingRef on WorkingMemory.
6. Wraps the result in an Observation with a bounded NormalizedResult.

`register_all_tools()` walks the registry and wires one handler per tool into
the agent loop's `_HANDLERS` dict, plus the meta handlers `tool.run` (generic
dispatch by name) and `tool.list` (discovery). The LLM sees the tools as
`tool.nmap`, `tool.sqlmap`, `tool.wpscan`, etc.

This file deliberately does NOT call `memory.coverage.mark_tried`. Tool
categories ("network", "web", "password", etc.) are not in
`engine.working_memory.BUG_CLASSES`, so `mark_tried` would raise.
Coverage stays a probe-level concept; tool runs count toward `findings_added`
only.
"""
from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from engine.agent_loop import NormalizedResult, Observation, register_handler
from engine.agents.handlers.registry_bridge import _build_normalized, _ref_from_finding
from engine.working_memory import WorkingMemory
from tools.registry import SecurityTool, ToolRegistry

logger = logging.getLogger("pentest-ai.handlers.tool_bridge")

_TIMEOUT_DEFAULT_S = 600.0
_TIMEOUT_HARD_CAP_S = 1800.0
_STDOUT_SNIPPET_MAX = 4096

# Tools that require intensity == "aggressive" to invoke.
# Active enforcement is deferred until WorkingMemory grows an `intensity`
# field (Phase B); for now the gate trips only when the attribute is present.
_AGGRESSIVE_TOOLS = frozenset(
    {"sqlmap", "hashcat", "metasploit", "hydra", "medusa", "ncrack"}
)

# Module-level registry singleton. ToolRegistry() does a dict-pop in init —
# cheap, but no reason to reconstruct on every handler invocation.
_REGISTRY: ToolRegistry | None = None


def _get_registry() -> ToolRegistry:
    global _REGISTRY
    if _REGISTRY is None:
        _REGISTRY = ToolRegistry()
    return _REGISTRY


def _bug_class_from_finding(f: dict[str, Any]) -> str:
    """Return a BUG_CLASSES-safe bug_class for a tool finding.

    The wrapper parsers (`parse_nuclei`, `parse_sqlmap`, etc.) populate
    `category` with values like "vulnerability" or "injection" that aren't
    in `engine.working_memory.BUG_CLASSES`. The agent_loop's FindingRef
    requires a valid bug_class to round-trip through coverage logic, so
    we coerce to a safe default if the wrapper didn't provide one explicitly.
    """
    explicit = f.get("bug_class")
    if explicit and isinstance(explicit, str):
        return explicit
    return "info_disclosure"


def _resolve_scope_check(target: str, tool_name: str) -> tuple[bool, str]:
    """Apply the active scope contextvar's check to a target before subprocess spawn.

    Returns (allowed, reason). If no scope is set, allow.
    """
    try:
        from engine.scope import get_current_scope
    except ImportError:
        return True, ""
    scope = get_current_scope()
    if scope is None:
        return True, ""
    return scope.check(target, tool_name)


def _build_install_hint(spec: SecurityTool) -> str:
    """Best-effort install hint surfaced when the tool is missing.

    Phase A: looks for optional `install_cmd` on the wrapper (added in Phase C).
    Falls back to a generic apt suggestion. The smarter `install_tool_by_name`
    path arrives in Phase B.
    """
    install_cmd = getattr(spec, "install_cmd", None)
    if install_cmd:
        return " ".join(install_cmd)
    return f"apt install {spec.command}  # best-effort; verify package name"


def make_handler_for_tool(spec: SecurityTool) -> Callable:
    """Return an agent-loop handler bound to one SecurityTool wrapper."""

    async def handler(memory: WorkingMemory, args: dict[str, Any]) -> Observation:
        action_name = f"tool.{spec.name}"
        findings_before = len(memory.findings)
        target = args.get("target") or memory.target
        tool_args = args.get("tool_args") or {}
        timeout = min(float(args.get("timeout_s", _TIMEOUT_DEFAULT_S)), _TIMEOUT_HARD_CAP_S)

        # Scope guard — reject off-scope targets before any subprocess.
        allowed, reason = _resolve_scope_check(target, spec.name)
        if not allowed:
            return Observation(
                action_name=action_name,
                success=False,
                error=f"scope blocked: {reason}",
                normalized=NormalizedResult(
                    tool=action_name,
                    target=target,
                    verdict="failed",
                    evidence=f"scope blocked: {reason}"[:120],
                ),
            )

        # Aggressive-tool gate — active when WorkingMemory carries an intensity.
        intensity = getattr(memory, "intensity", None) or getattr(
            memory, "engagement_intensity", None
        )
        if spec.name in _AGGRESSIVE_TOOLS and intensity and intensity != "aggressive":
            return Observation(
                action_name=action_name,
                success=False,
                error=f"intensity gate: {spec.name} requires aggressive",
                normalized=NormalizedResult(
                    tool=action_name,
                    target=target,
                    verdict="failed",
                    evidence=f"{spec.name} requires aggressive intensity"[:120],
                ),
            )

        # Installation check — surface a hint instead of crashing.
        if not spec.is_installed():
            hint = _build_install_hint(spec)
            return Observation(
                action_name=action_name,
                success=False,
                error=f"tool not installed: {spec.name}",
                raw={"install_hint": hint, "tool": spec.name},
                normalized=NormalizedResult(
                    tool=action_name,
                    target=target,
                    verdict="failed",
                    evidence=f"not installed; try: {hint}"[:120],
                ),
            )

        # Execute the wrapper.
        try:
            result = await spec.execute(target, tool_args, timeout=timeout)
        except Exception as exc:  # noqa: BLE001 - tool-level failures must not crash the loop
            logger.warning("tool %s failed: %s", spec.name, exc)
            return Observation(
                action_name=action_name,
                success=False,
                error=str(exc),
                normalized=NormalizedResult(
                    tool=action_name,
                    target=target,
                    verdict="failed",
                    evidence=str(exc)[:120],
                ),
            )

        findings = result.get("findings") or []
        stdout = result.get("stdout") or ""
        exit_code = result.get("exit_code")

        # Append findings to WorkingMemory. Coverage left alone on purpose
        # (see module docstring).
        for f in findings:
            try:
                ref = _ref_from_finding(f, _bug_class_from_finding(f))
            except Exception as exc:  # noqa: BLE001 - keep loop going if a parser returns junk
                logger.warning("tool %s: skipping malformed finding: %s", spec.name, exc)
                continue
            memory.add_finding(ref)

        normalized = _build_normalized(action_name, target, findings)

        return Observation(
            action_name=action_name,
            success=exit_code == 0,
            findings_added=len(memory.findings) - findings_before,
            error=result.get("error", "") if exit_code != 0 else "",
            raw={
                "tool": spec.name,
                "findings": findings,
                "stdout_snippet": stdout[:_STDOUT_SNIPPET_MAX],
                "exit_code": exit_code,
                "duration": result.get("duration"),
                "cache_hit": result.get("cache_hit", False),
            },
            normalized=normalized,
        )

    handler.__name__ = f"handler_for_tool_{spec.name.replace('-', '_').replace('.', '_')}"
    return handler


async def handle_tool_run(memory: WorkingMemory, args: dict[str, Any]) -> Observation:
    """Generic dispatcher: ``tool.run({"tool": "wpscan", "target": "...", ...})``.

    The per-tool handlers (`tool.wpscan`, `tool.sqlmap`, etc.) are the primary
    LLM-visible action surface. This dispatcher exists so the LLM can also
    pick a tool dynamically based on the action it's about to take, without
    needing to know the exact handler name upfront.
    """
    name = args.get("tool")
    if not name or not isinstance(name, str):
        return Observation(
            action_name="tool.run",
            success=False,
            error="missing 'tool' arg",
            normalized=NormalizedResult(
                tool="tool.run",
                target=memory.target,
                verdict="failed",
                evidence="missing 'tool' arg",
            ),
        )

    spec = _get_registry().get_tool(name)
    if spec is None:
        return Observation(
            action_name="tool.run",
            success=False,
            error=f"unknown tool: {name}",
            normalized=NormalizedResult(
                tool="tool.run",
                target=memory.target,
                verdict="failed",
                evidence=f"unknown tool: {name}"[:120],
            ),
        )

    delegate = make_handler_for_tool(spec)
    return await delegate(memory, args)


async def handle_tool_list(memory: WorkingMemory, args: dict[str, Any]) -> Observation:
    """List available tools the LLM can call.

    args = {"category"?: str, "installed_only"?: bool (default True)}

    Returns the list in `raw['tools']`. Each entry: `{name, category, description, installed}`.
    """
    category = args.get("category")
    installed_only = bool(args.get("installed_only", True))
    registry = _get_registry()
    tools = registry.list_tools(category=category) if category else registry.list_tools()
    entries: list[dict[str, Any]] = []
    for t in tools:
        is_installed = t.is_installed()
        if installed_only and not is_installed:
            continue
        entries.append(
            {
                "name": t.name,
                "category": t.category,
                "extra_categories": list(t.extra_categories or []),
                "description": t.description,
                "installed": is_installed,
            }
        )

    return Observation(
        action_name="tool.list",
        success=True,
        raw={"tools": entries, "count": len(entries), "category": category},
        normalized=NormalizedResult(
            tool="tool.list",
            target=memory.target,
            verdict="confirmed" if entries else "inconclusive",
            evidence=f"{len(entries)} tools listed"
            + (f" for category={category}" if category else "")[:120],
        ),
    )


async def handle_tool_plan(memory: WorkingMemory, args: dict[str, Any]) -> Observation:
    """Predict which tools the engagement is likely to need.

    args = {"scope"?: str (default "web"), "intensity"?: str (default "normal"),
            "agent"?: <opaque LLM client>, "available_names"?: list[str]}

    Returns the predicted list in ``raw['predicted']``. The smart-install flow
    feeds this to ``tool.ensure_installed`` for the one-shot install prompt.
    """
    from engine.install_planner import predict_tools_for_engagement

    scope = args.get("scope") or "web"
    intensity = args.get("intensity") or "normal"
    agent = args.get("agent")
    available_names = args.get("available_names")

    try:
        predicted = await predict_tools_for_engagement(
            agent,
            scope=scope,
            intensity=intensity,
            target=memory.target,
            available_names=available_names,
        )
    except Exception as exc:  # noqa: BLE001 - planner must not crash the loop
        logger.warning("tool.plan: predict failed: %s", exc)
        predicted = []

    return Observation(
        action_name="tool.plan",
        success=True,
        raw={"predicted": predicted, "scope": scope, "intensity": intensity},
        normalized=NormalizedResult(
            tool="tool.plan",
            target=memory.target,
            verdict="confirmed" if predicted else "inconclusive",
            evidence=f"{len(predicted)} tools predicted for scope={scope}"[:120],
        ),
    )


async def handle_tool_ensure_installed(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    """Make sure the given tools are installed; prompt the user once if not.

    args = {"tools": list[str], "interactive"?: bool (default True),
            "timeout_s"?: float (default 30.0)}

    Flow:

      1. Audit which tools are already installed (skip those).
      2. Filter out tools the user has previously denied
         (``install-preferences.json``).
      3. If everything's installed, return success.
      4. Otherwise, in interactive mode show ONE prompt listing missing
         tools; in non-interactive mode consult ``auto_install`` and
         either install silently or skip silently.
      5. Per approved tool, run ``install_tool_by_name``.
      6. Return per-tool results in ``raw['results']``.
    """
    from engine.async_prompt import is_non_interactive, prompt_with_timeout
    from engine.install_preferences import load as load_prefs
    from engine.install_preferences import save as save_prefs
    from engine.tool_installer import audit_named, install_tool_by_name

    tool_names = list(args.get("tools") or [])
    if not tool_names:
        return Observation(
            action_name="tool.ensure_installed",
            success=True,
            raw={"results": [], "audit": {"installed": [], "missing": [], "unknown": []}},
            normalized=NormalizedResult(
                tool="tool.ensure_installed",
                target=memory.target,
                verdict="inconclusive",
                evidence="no tools requested",
            ),
        )

    interactive = bool(args.get("interactive", True)) and not is_non_interactive()
    timeout_s = float(args.get("timeout_s", 30.0))

    prefs = load_prefs()
    audit = audit_named(tool_names)
    missing = [name for name in audit["missing"] if not prefs.is_denied(name)]
    unknown = audit["unknown"]

    if not missing:
        return Observation(
            action_name="tool.ensure_installed",
            success=True,
            raw={"results": [], "audit": audit},
            normalized=NormalizedResult(
                tool="tool.ensure_installed",
                target=memory.target,
                verdict="confirmed",
                evidence=f"all {len(tool_names) - len(unknown)} tools already installed"[:120],
            ),
        )

    # Decide whether to install.
    if interactive:
        listing = ", ".join(missing)
        message = (
            f"ptai wants to install {len(missing)} tool"
            f"{'s' if len(missing) != 1 else ''} for this engagement:\n\n"
            f"  {listing}\n\n"
            f"Install? [y/N] (timeout: {timeout_s:g}s defaults to N)"
        )
        answer = await prompt_with_timeout(
            message,
            default="n",
            timeout_s=timeout_s,
            title="ptai · install preflight",
        )
        approved = answer.lower() in ("y", "yes")
        if not approved:
            # User said no — remember the denial so the next engagement
            # doesn't re-prompt for the same tools.
            for name in missing:
                prefs.deny(name)
            try:
                save_prefs(prefs)
            except OSError as exc:
                logger.warning("could not persist install preferences: %s", exc)
            return Observation(
                action_name="tool.ensure_installed",
                success=True,
                raw={"results": [], "audit": audit, "decision": "user_declined"},
                normalized=NormalizedResult(
                    tool="tool.ensure_installed",
                    target=memory.target,
                    verdict="inconclusive",
                    evidence=f"user declined install of {len(missing)} tool(s)"[:120],
                ),
            )
    else:
        # Non-interactive: only auto-install when the user has opted in.
        if not prefs.auto_install:
            return Observation(
                action_name="tool.ensure_installed",
                success=True,
                raw={"results": [], "audit": audit, "decision": "skipped_non_interactive"},
                normalized=NormalizedResult(
                    tool="tool.ensure_installed",
                    target=memory.target,
                    verdict="inconclusive",
                    evidence=f"non-interactive; {len(missing)} missing tool(s) skipped"[:120],
                ),
            )

    # Actually install.
    results: list[dict[str, Any]] = []
    for name in missing:
        ok, message = install_tool_by_name(name)
        results.append({"tool": name, "ok": ok, "message": message})

    installed_count = sum(1 for r in results if r["ok"])
    return Observation(
        action_name="tool.ensure_installed",
        success=True,
        raw={"results": results, "audit": audit},
        normalized=NormalizedResult(
            tool="tool.ensure_installed",
            target=memory.target,
            verdict="confirmed" if installed_count else "inconclusive",
            evidence=f"{installed_count}/{len(missing)} tools installed"[:120],
        ),
    )


def register_all_tools(*, force: bool = False) -> list[str]:
    """Wire every SecurityTool in the registry into _HANDLERS as ``tool.<name>``.

    Also registers the meta handlers ``tool.run`` (generic dispatch) and
    ``tool.list`` (discovery). Returns the list of action names registered.
    Already-present handler names are skipped silently unless ``force=True``.
    """
    from engine.agent_loop import _HANDLERS  # local import to avoid cycles

    registered: list[str] = []
    registry = _get_registry()

    # One handler per SecurityTool.
    for spec in registry.list_tools():
        name = f"tool.{spec.name}"
        if name in _HANDLERS and not force:
            continue
        register_handler(name, make_handler_for_tool(spec))
        registered.append(name)

    # Meta handlers for dispatch, discovery, planning, and install.
    for meta_name, meta_handler in (
        ("tool.run", handle_tool_run),
        ("tool.list", handle_tool_list),
        ("tool.plan", handle_tool_plan),
        ("tool.ensure_installed", handle_tool_ensure_installed),
    ):
        if meta_name in _HANDLERS and not force:
            continue
        register_handler(meta_name, meta_handler)
        registered.append(meta_name)

    logger.info("tool_bridge: registered %d tool handlers (force=%s)", len(registered), force)
    return registered
