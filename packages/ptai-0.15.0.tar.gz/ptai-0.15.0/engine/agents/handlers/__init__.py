"""Probe + tool + meta + finalizer handlers registered with engine.agent_loop.

The legacy `web_probes` module hand-wired 3 specific handlers; the bulk
`register_default_handlers()` helper walks the @probe-decorated registry
and creates a generic handler for every probe (44+ as of 2026-05-08), then
adds the 200+ SecurityTool wrappers from `tools.registry` as `tool.<name>`
handlers, plus meta- and finalizer-handlers.
"""
from __future__ import annotations

from engine.agents.handlers import web_probes  # noqa: F401  - legacy 3 handlers
from engine.agents.handlers.registry_bridge import register_all_probes
from engine.agents.handlers.tool_bridge import register_all_tools


def register_default_handlers() -> list[str]:
    """Wire every @probe-decorated probe + tool wrapper + meta-handler into the agent loop.

    Five tiers of handlers get wired:

      1. Probe handlers (44+): every @probe in the registry is bridged
         into a generic handler by `register_all_probes()`.
      2. Tool handlers (200+): every SecurityTool in `tools.registry` is
         bridged into a `tool.<name>` handler by `register_all_tools()`.
         Plus `tool.run` (generic dispatch) and `tool.list` (discovery).
      3. Meta-handlers (4): meta.crawl, meta.set_auth, meta.validate_finding,
         meta.mutate_args. Wired by `register_meta_handlers()`.
      4. Finalizer handlers (4): finalize.chain, finalize.validate_pocs,
         finalize.generate_detections, finalize.report. Wired by
         `register_finalizer_handlers()`.
      5. Legacy handlers (3 hand-wired in web_probes): already imported at
         the top of this module.

    Returns the union list of action names registered. Idempotent: existing
    action names are skipped silently.
    """
    import engine.probes.web  # noqa: F401  - triggers @probe decorators
    from engine.agents.handlers.finalizers import register_finalizer_handlers
    from engine.agents.handlers.meta import register_meta_handlers

    probe_actions = register_all_probes()
    tool_actions = register_all_tools()
    meta_actions = register_meta_handlers()
    finalizer_actions = register_finalizer_handlers()
    return probe_actions + tool_actions + meta_actions + finalizer_actions
