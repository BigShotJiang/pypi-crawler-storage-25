"""Agent-loop handlers wrapping SPA probes.

Each handler:
  1. Calls the underlying probe (which talks to the live target).
  2. Translates the probe's finding dicts into FindingRef rows in
     working memory.
  3. Marks coverage on the (endpoint, bug-class) pair.
  4. Returns an Observation describing what happened.
"""
from __future__ import annotations

import logging
from typing import Any

import aiohttp

from agents.web.spa_probes import (
    probe_ftp_leak,
    probe_jwt_alg_none,
    probe_login_sqli_bypass,
)
from engine.agent_loop import Observation, register_handler
from engine.working_memory import EndpointKey, FindingRef, WorkingMemory

logger = logging.getLogger("pentest-ai.handlers.web_probes")

HANDLER_BUG_CLASSES: tuple[str, ...] = (
    "jwt_alg_none",
    "sqli",
    "auth_bypass",
    "exposed_admin",
    "vulnerable_dep",
)


def _ref_from_finding(f: dict[str, Any], bug_class: str) -> FindingRef:
    return FindingRef(
        id=f.get("id") or "",
        severity=f.get("severity", "info"),
        category=f.get("category", "discovery"),
        bug_class=bug_class,
        target=f.get("target", ""),
        poc_status=f.get("poc_status", "pending"),
    )


def _bug_class_for_finding(f: dict[str, Any], default: str) -> str:
    title = (f.get("title") or "").lower()
    if "jwt" in title and "alg" in title and "none" in title:
        return "jwt_alg_none"
    if "sql injection" in title or "sqli" in title:
        return "sqli"
    if "without authentication" in title or "without auth" in title:
        return "auth_bypass"
    if "vulnerable npm dependencies" in title or "known advisories" in title:
        return "vulnerable_dep"
    return default


async def handle_jwt_alg_none_probe(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    endpoints = args.get("endpoints") or [
        "/api/Users/", "/rest/admin/application-configuration", "/rest/user/whoami",
    ]
    base = memory.target.rstrip("/")
    findings_before = len(memory.findings)
    try:
        async with aiohttp.ClientSession() as session:
            findings = await probe_jwt_alg_none(session, base, endpoints)
    except Exception as e:
        logger.warning("probe_jwt_alg_none failed: %s", e)
        return Observation(action_name="probe.jwt_alg_none", success=False, error=str(e))

    for f in findings:
        bc = _bug_class_for_finding(f, default="jwt_alg_none")
        memory.add_finding(_ref_from_finding(f, bc))

    for ep in endpoints:
        memory.add_endpoint(EndpointKey("GET", ep))
        memory.coverage.mark_tried(
            EndpointKey("GET", ep), "jwt_alg_none", hit=any(
                _bug_class_for_finding(f, default="") == "jwt_alg_none" for f in findings
            ),
        )

    return Observation(
        action_name="probe.jwt_alg_none",
        success=True,
        findings_added=len(memory.findings) - findings_before,
        endpoints_added=len(endpoints),
    )


async def handle_sqli_login_probe(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    base = memory.target.rstrip("/")
    findings_before = len(memory.findings)
    endpoints_before = len(memory.endpoints_seen)
    try:
        async with aiohttp.ClientSession() as session:
            findings = await probe_login_sqli_bypass(session, base)
    except Exception as e:
        logger.warning("probe_login_sqli_bypass failed: %s", e)
        return Observation(action_name="probe.sqli_login", success=False, error=str(e))

    for f in findings:
        memory.add_finding(_ref_from_finding(f, "sqli"))
        target = f.get("target") or ""
        if target.startswith(base):
            path = target[len(base):]
            memory.add_endpoint(EndpointKey("POST", path))
            memory.coverage.mark_tried(EndpointKey("POST", path), "sqli", hit=True)

    return Observation(
        action_name="probe.sqli_login",
        success=True,
        findings_added=len(memory.findings) - findings_before,
        endpoints_added=len(memory.endpoints_seen) - endpoints_before,
    )


async def handle_ftp_leak_probe(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    base = memory.target.rstrip("/")
    findings_before = len(memory.findings)
    try:
        async with aiohttp.ClientSession() as session:
            findings = await probe_ftp_leak(session, base)
    except Exception as e:
        logger.warning("probe_ftp_leak failed: %s", e)
        return Observation(action_name="probe.ftp_leak", success=False, error=str(e))

    for f in findings:
        bc = _bug_class_for_finding(f, default="exposed_admin")
        memory.add_finding(_ref_from_finding(f, bc))

    memory.add_endpoint(EndpointKey("GET", "/ftp/"))
    memory.coverage.mark_tried(
        EndpointKey("GET", "/ftp/"), "exposed_admin", hit=bool(findings)
    )
    return Observation(
        action_name="probe.ftp_leak",
        success=True,
        findings_added=len(memory.findings) - findings_before,
        endpoints_added=1,
    )


# Register at import time so importing this module wires the handlers in.
register_handler("probe.jwt_alg_none", handle_jwt_alg_none_probe)
register_handler("probe.sqli_login", handle_sqli_login_probe)
register_handler("probe.ftp_leak", handle_ftp_leak_probe)
