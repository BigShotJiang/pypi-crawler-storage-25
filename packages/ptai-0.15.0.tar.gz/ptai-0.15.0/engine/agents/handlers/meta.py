"""Meta-handlers for the agent loop.

Today the LLM in --agent-mode can only call probe handlers. This module
adds four meta-actions the LLM can take:

  - meta.crawl: trigger the recon crawler on the target, populate
    memory.endpoints_seen with discovered paths.
  - meta.set_auth: register a fresh test user and capture a JWT into
    memory.captured_auth so subsequent authenticated probes can use it.
  - meta.validate_finding: re-run the probe that emitted a given finding
    and confirm the result.
  - meta.mutate_args: re-invoke an existing probe handler with merged
    args (e.g. extra candidate_endpoints, tampered payloads).

HackingBuddyGPT's published result shows mutation passes recover ~30% of
findings stock probes miss (WAF/encoding bypasses).
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

import aiohttp

from engine.agent_loop import (
    NormalizedResult,
    Observation,
    register_handler,
)
from engine.working_memory import (
    CapturedAuth,
    EndpointKey,
    WorkingMemory,
)

logger = logging.getLogger("pentest-ai.handlers.meta")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


async def handle_crawl(memory: WorkingMemory, args: dict[str, Any]) -> Observation:
    """Run the recon crawler against memory.target.

    Adds every discovered path to memory.endpoints_seen as
    EndpointKey('GET', path) so subsequent probes can target them.

    Falls back to the optional Scrapling-backed stealth crawler when the
    default aiohttp crawler returns zero paths (typical for SPAs that
    require JS execution, or for Cloudflare-protected targets that 403
    a plain GET). Stealth fallback is opt-in: requires `pip install
    ptai[stealth]`. If scrapling is not installed, the fallback is
    silently skipped.

    args (all optional):
      - force_stealth: bool, skip the default crawler and go straight
        to stealth_crawler. Useful when caller already knows the target
        is hardened.
    """
    from engine.probes.recon.crawler import CrawlResult, run_crawler

    endpoints_before = len(memory.endpoints_seen)
    force_stealth = bool(args.get("force_stealth", False))

    # If a prior probe captured auth (e.g. set_auth meta-handler logged
    # in and recorded a session token), forward those headers to the
    # crawler so it discovers authenticated routes. Without this, every
    # /api/users / /admin/* / /internal/* path stays invisible to the
    # rest of the engagement.
    auth_hdrs: dict[str, str] | None = None
    if memory.captured_auth is not None:
        from engine.probes.auth.runner import auth_headers as _build_auth_headers
        try:
            captured = (
                memory.captured_auth
                if isinstance(memory.captured_auth, dict)
                else memory.captured_auth.__dict__
            )
            auth_hdrs = _build_auth_headers(captured) or None
        except Exception:
            auth_hdrs = None

    crawl = CrawlResult()
    if not force_stealth:
        try:
            async with aiohttp.ClientSession() as session:
                crawl = await run_crawler(session, memory.target, auth_headers=auth_hdrs)
        except Exception as exc:  # noqa: BLE001
            logger.warning("meta.crawl default crawler failed: %s", exc)
            return Observation(
                action_name="meta.crawl",
                success=False,
                error=str(exc),
                normalized=NormalizedResult(
                    tool="meta.crawl",
                    target=memory.target,
                    verdict="failed",
                    evidence=str(exc)[:120],
                ),
            )

    default_total = (
        len(crawl.discovered_paths) + len(crawl.api_paths) + len(crawl.discovered_js)
    )

    stealth_used = False
    if force_stealth or default_total == 0:
        try:
            from engine.probes.recon.stealth_crawler import (
                is_available as stealth_available,
            )
            from engine.probes.recon.stealth_crawler import (
                run_stealth_crawler,
            )

            if stealth_available():
                logger.info("meta.crawl: default returned %d paths, trying stealth", default_total)
                stealth = await run_stealth_crawler(memory.target)
                crawl.merge(stealth)
                stealth_used = True
        except Exception as exc:  # noqa: BLE001
            logger.warning("meta.crawl stealth fallback failed: %s", exc)

    all_paths: set[str] = set()
    for p in crawl.discovered_paths:
        all_paths.add(p)
    for p in crawl.api_paths:
        all_paths.add(p)
    for p in crawl.discovered_js:
        all_paths.add(p)

    for path in all_paths:
        if not path.startswith(("http://", "https://", "/")):
            continue
        if path.startswith(("http://", "https://")):
            continue  # only same-origin relative paths
        memory.add_endpoint(EndpointKey("GET", path))

    added = len(memory.endpoints_seen) - endpoints_before
    source = "default+stealth" if stealth_used else "default"

    return Observation(
        action_name="meta.crawl",
        success=True,
        endpoints_added=added,
        normalized=NormalizedResult(
            tool="meta.crawl",
            target=memory.target,
            verdict="confirmed" if added > 0 else "inconclusive",
            evidence=f"crawler ({source}) discovered {added} new endpoints "
            f"({len(crawl.api_paths)} api, {len(crawl.discovered_js)} js)",
        ),
    )


async def handle_set_auth(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    """Register a fresh test user, capture the resulting JWT into memory.

    args (all optional):
      - email: explicit email for registration (default: auto-generated)
      - password: explicit password (default: auto-generated)
    """
    from engine.probes.auth.runner import acquire_test_auth

    auth_before = len(memory.captured_auth)

    try:
        async with aiohttp.ClientSession() as session:
            auth = await acquire_test_auth(
                session,
                memory.target,
                email=args.get("email"),
                password=args.get("password"),
            )
    except Exception as exc:  # noqa: BLE001
        logger.warning("meta.set_auth failed: %s", exc)
        return Observation(
            action_name="meta.set_auth",
            success=False,
            error=str(exc),
            normalized=NormalizedResult(
                tool="meta.set_auth",
                target=memory.target,
                verdict="failed",
                evidence=str(exc)[:120],
            ),
        )

    if auth is None:
        return Observation(
            action_name="meta.set_auth",
            success=False,
            normalized=NormalizedResult(
                tool="meta.set_auth",
                target=memory.target,
                verdict="failed",
                evidence="acquire_test_auth returned None",
            ),
        )

    memory.add_auth(
        CapturedAuth(
            kind=auth.get("kind", "jwt"),
            value=auth.get("token", ""),
            source_endpoint=auth.get("source_endpoint", "/rest/user/login"),
            captured_at=_now_iso(),
            role_hint=auth.get("role_hint", ""),
        )
    )

    return Observation(
        action_name="meta.set_auth",
        success=True,
        auth_added=len(memory.captured_auth) - auth_before,
        normalized=NormalizedResult(
            tool="meta.set_auth",
            target=memory.target,
            verdict="confirmed",
            evidence=f"captured {auth.get('kind', 'jwt')} for "
            f"{auth.get('email', 'unknown')[:40]}",
        ),
    )


async def handle_validate_finding(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    """Re-run the probe that produced a finding to confirm it.

    args:
      - finding_id: the FindingRef.id to validate (required)
    """
    finding_id = args.get("finding_id", "")
    if not finding_id:
        return Observation(
            action_name="meta.validate_finding",
            success=False,
            error="missing finding_id",
            normalized=NormalizedResult(
                tool="meta.validate_finding",
                target=memory.target,
                verdict="failed",
                evidence="missing finding_id arg",
            ),
        )

    target_finding = next(
        (f for f in memory.findings if f.id == finding_id), None
    )
    if target_finding is None:
        return Observation(
            action_name="meta.validate_finding",
            success=False,
            error=f"finding {finding_id} not in memory",
            normalized=NormalizedResult(
                tool="meta.validate_finding",
                target=memory.target,
                verdict="failed",
                evidence=f"finding {finding_id[:40]} not in memory",
            ),
        )

    # Find the handler for the bug_class. Map bug_class to most-recently-
    # tried action. Today this is heuristic; future iteration can store
    # the producing action_name on FindingRef.
    from engine.agent_loop import _HANDLERS
    from engine.probes import registry

    candidate_specs = registry.filter(bug_class=target_finding.bug_class)
    if not candidate_specs:
        return Observation(
            action_name="meta.validate_finding",
            success=False,
            error=f"no probe registered for bug_class {target_finding.bug_class}",
            normalized=NormalizedResult(
                tool="meta.validate_finding",
                target=target_finding.target,
                verdict="inconclusive",
                evidence=f"no probe for {target_finding.bug_class}",
            ),
        )

    # Pick the first matching probe and call its handler.
    spec = candidate_specs[0]
    action_name = f"probe.{spec.name}"
    handler = _HANDLERS.get(action_name)
    if handler is None:
        return Observation(
            action_name="meta.validate_finding",
            success=False,
            error=f"handler {action_name} not registered",
            normalized=NormalizedResult(
                tool="meta.validate_finding",
                target=target_finding.target,
                verdict="failed",
                evidence=f"handler {action_name} not in registry",
            ),
        )

    findings_before = len(memory.findings)
    sub_obs = await handler(memory, {})
    findings_after = len(memory.findings)
    confirmed = findings_after > findings_before and sub_obs.success

    return Observation(
        action_name="meta.validate_finding",
        success=confirmed,
        findings_added=findings_after - findings_before,
        normalized=NormalizedResult(
            tool="meta.validate_finding",
            target=target_finding.target,
            verdict="confirmed" if confirmed else "inconclusive",
            evidence=(
                f"re-ran {action_name}; "
                f"{'validated' if confirmed else 'no new evidence'}"
            ),
        ),
    )


async def handle_mutate_args(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    """Re-invoke an existing handler with merged args.

    args:
      - action_name: the registered handler name (required)
      - extra_args: dict merged into the handler's args (default: {})
    """
    from engine.agent_loop import _HANDLERS

    action_name = args.get("action_name", "")
    extra_args = args.get("extra_args", {}) or {}

    if not action_name:
        return Observation(
            action_name="meta.mutate_args",
            success=False,
            error="missing action_name",
            normalized=NormalizedResult(
                tool="meta.mutate_args",
                target=memory.target,
                verdict="failed",
                evidence="missing action_name arg",
            ),
        )

    handler = _HANDLERS.get(action_name)
    if handler is None:
        return Observation(
            action_name="meta.mutate_args",
            success=False,
            error=f"handler {action_name} not registered",
            normalized=NormalizedResult(
                tool="meta.mutate_args",
                target=memory.target,
                verdict="failed",
                evidence=f"unknown handler {action_name[:60]}",
            ),
        )

    sub_obs = await handler(memory, extra_args)
    return Observation(
        action_name="meta.mutate_args",
        success=sub_obs.success,
        findings_added=sub_obs.findings_added,
        endpoints_added=sub_obs.endpoints_added,
        auth_added=sub_obs.auth_added,
        error=sub_obs.error,
        normalized=NormalizedResult(
            tool="meta.mutate_args",
            target=memory.target,
            verdict="confirmed" if sub_obs.success else "failed",
            evidence=f"re-ran {action_name} with {len(extra_args)} extra args",
        ),
    )


def register_meta_handlers() -> list[str]:
    """Wire the four meta-handlers into the agent loop.

    Idempotent: re-registration of an existing action skips silently.
    Returns the list of action names registered.
    """
    from engine.agent_loop import _HANDLERS

    handlers = (
        ("meta.crawl", handle_crawl),
        ("meta.set_auth", handle_set_auth),
        ("meta.validate_finding", handle_validate_finding),
        ("meta.mutate_args", handle_mutate_args),
    )
    registered: list[str] = []
    for name, fn in handlers:
        if name in _HANDLERS:
            continue
        register_handler(name, fn)
        registered.append(name)
    return registered
