"""Finalizer handlers for the agent loop.

The legacy fixed pipeline (engine/orchestrator.py) runs four terminal
phases after the per-domain agents finish:

  - chaining: ExploitChainAgent.discover_chains
  - validation: PoCAgent.validate_all (+ validate_chains)
  - detection: DetectionAgent.generate_rules
  - report: ReportAgent.generate_report

Today --agent-mode skips all four. Customers running the agent loop get
findings but no chain graph, no PoC validation, no detection rules, and
no report. This module wires the four legacy agents behind agent-loop
handlers so the LLM (or the loop's terminal step) can call them by name
and produce the same outputs.

Each handler:

  - is async (signature: (memory, args) -> Observation)
  - uses the shared db handle registered via set_db_handle
  - catches exceptions and returns Observation(success=False) with a
    NormalizedResult verdict="failed"
  - on success returns verdict="confirmed" plus an evidence summary

The handlers do NOT replace the legacy agents; they wrap them.
"""
from __future__ import annotations

import logging
from typing import Any

from engine.agent_loop import (
    NormalizedResult,
    Observation,
    register_handler,
)
from engine.working_memory import WorkingMemory

logger = logging.getLogger("pentest-ai.handlers.finalizers")

# Module-level db handle. cli/main.py (or any caller wiring the agent
# loop) sets this before running. Kept module-scoped because the
# WorkingMemory dataclass intentionally does not carry the db handle:
# memory is the LLM's reasoning surface, the db is plumbing.
_db: Any = None
_llm: Any = None
_scope: Any = None


def set_db_handle(db: Any, llm: Any = None, scope: Any = None) -> None:
    """Register the FindingsDB (and optional LLM/scope) used by finalizers.

    Call this once from the agent-loop entrypoint, before run_agent_loop.
    Idempotent: re-calling overwrites the previous handle.
    """
    global _db, _llm, _scope
    _db = db
    _llm = llm
    _scope = scope


def _no_db_observation(action_name: str, target: str) -> Observation:
    return Observation(
        action_name=action_name,
        success=False,
        error="db handle not registered; call set_db_handle() first",
        normalized=NormalizedResult(
            tool=action_name,
            target=target,
            verdict="failed",
            evidence="db handle not registered",
        ),
    )


async def handle_chain(memory: WorkingMemory, args: dict[str, Any]) -> Observation:
    """Run ExploitChainAgent.discover_chains for the engagement.

    args: {} (no args today; reserved for future template filters).
    """
    if _db is None:
        return _no_db_observation("finalize.chain", memory.target)

    try:
        from agents.exploit_chain.chain_agent import ExploitChainAgent

        agent = ExploitChainAgent(self_or_db(), llm=_llm, scope=_scope)
        chains = await agent.discover_chains(memory.engagement_id)
    except Exception as exc:  # noqa: BLE001
        logger.warning("finalize.chain failed: %s", exc)
        return Observation(
            action_name="finalize.chain",
            success=False,
            error=str(exc),
            normalized=NormalizedResult(
                tool="finalize.chain",
                target=memory.target,
                verdict="failed",
                evidence=str(exc)[:120],
            ),
        )

    n = len(chains) if chains is not None else 0
    return Observation(
        action_name="finalize.chain",
        success=True,
        raw={"chains_added": n},
        normalized=NormalizedResult(
            tool="finalize.chain",
            target=memory.target,
            verdict="confirmed" if n > 0 else "inconclusive",
            evidence=f"discovered {n} attack chains",
        ),
    )


async def handle_validate_pocs(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    """Run PoCAgent.validate_all for the engagement (+ chain validation).

    args: {} (no args).
    """
    if _db is None:
        return _no_db_observation("finalize.validate_pocs", memory.target)

    try:
        from agents.poc_validator.poc_agent import PoCAgent

        agent = PoCAgent(self_or_db(), llm=_llm, scope=_scope)
        results = await agent.validate_all(memory.engagement_id)
    except Exception as exc:  # noqa: BLE001
        logger.warning("finalize.validate_pocs failed: %s", exc)
        return Observation(
            action_name="finalize.validate_pocs",
            success=False,
            error=str(exc),
            normalized=NormalizedResult(
                tool="finalize.validate_pocs",
                target=memory.target,
                verdict="failed",
                evidence=str(exc)[:120],
            ),
        )

    n = len(results) if results is not None else 0
    return Observation(
        action_name="finalize.validate_pocs",
        success=True,
        raw={"validations_count": n},
        normalized=NormalizedResult(
            tool="finalize.validate_pocs",
            target=memory.target,
            verdict="confirmed" if n > 0 else "inconclusive",
            evidence=f"validated {n} findings",
        ),
    )


async def handle_generate_detections(
    memory: WorkingMemory, args: dict[str, Any]
) -> Observation:
    """Run DetectionAgent.generate_rules for the engagement.

    args: {} (no args).
    """
    if _db is None:
        return _no_db_observation("finalize.generate_detections", memory.target)

    try:
        from agents.detection.detection_agent import DetectionAgent

        agent = DetectionAgent(self_or_db(), llm=_llm, scope=_scope)
        rules = await agent.generate_rules(memory.engagement_id)
    except Exception as exc:  # noqa: BLE001
        logger.warning("finalize.generate_detections failed: %s", exc)
        return Observation(
            action_name="finalize.generate_detections",
            success=False,
            error=str(exc),
            normalized=NormalizedResult(
                tool="finalize.generate_detections",
                target=memory.target,
                verdict="failed",
                evidence=str(exc)[:120],
            ),
        )

    n = len(rules) if rules is not None else 0
    return Observation(
        action_name="finalize.generate_detections",
        success=True,
        raw={"rules_count": n},
        normalized=NormalizedResult(
            tool="finalize.generate_detections",
            target=memory.target,
            verdict="confirmed" if n > 0 else "inconclusive",
            evidence=f"generated {n} detection rules",
        ),
    )


async def handle_report(memory: WorkingMemory, args: dict[str, Any]) -> Observation:
    """Run ReportAgent.generate_report for the engagement.

    args (all optional):
      - format: 'markdown' | 'html' | 'pdf' | 'all' (default 'all')
      - include_pocs: bool (default True)
      - include_detections: bool (default True)
    """
    if _db is None:
        return _no_db_observation("finalize.report", memory.target)

    try:
        from agents.report.report_agent import ReportAgent

        agent = ReportAgent(self_or_db(), llm=_llm, scope=_scope)
        report = await agent.generate_report(
            memory.engagement_id,
            format=args.get("format", "all"),
            include_pocs=args.get("include_pocs", True),
            include_detections=args.get("include_detections", True),
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("finalize.report failed: %s", exc)
        return Observation(
            action_name="finalize.report",
            success=False,
            error=str(exc),
            normalized=NormalizedResult(
                tool="finalize.report",
                target=memory.target,
                verdict="failed",
                evidence=str(exc)[:120],
            ),
        )

    report = report or {}
    report_path = report.get("output_path", "")
    return Observation(
        action_name="finalize.report",
        success=bool(report_path),
        raw={"report_path": report_path, "output_paths": report.get("output_paths", {})},
        normalized=NormalizedResult(
            tool="finalize.report",
            target=memory.target,
            verdict="confirmed" if report_path else "inconclusive",
            evidence=f"report at {report_path or 'unknown'}"[:120],
        ),
    )


def self_or_db() -> Any:
    """Return the registered db handle.

    Indirection exists so tests can monkey-patch _db without re-wiring
    every handler call site, and so a future refactor can swap in
    contextvars-backed lookup without changing callers.
    """
    return _db


def register_finalizer_handlers() -> list[str]:
    """Wire the four finalizer handlers into the agent loop.

    Idempotent: re-registration of an existing action skips silently.
    Returns the list of action names registered.
    """
    from engine.agent_loop import _HANDLERS

    handlers = (
        ("finalize.chain", handle_chain),
        ("finalize.validate_pocs", handle_validate_pocs),
        ("finalize.generate_detections", handle_generate_detections),
        ("finalize.report", handle_report),
    )
    registered: list[str] = []
    for name, fn in handlers:
        if name in _HANDLERS:
            continue
        register_handler(name, fn)
        registered.append(name)
    return registered
