"""Engagement-scoped working memory for the agent loop.

Replaces the previous "fixed-pipeline + isolated specialists" design
where each agent ran independently and the only shared state was the
findings DB. The agent loop needs richer in-flight context:

  - Endpoints discovered and tested.
  - Payloads attempted on each endpoint (so we don't repeat).
  - Credentials and tokens captured during the engagement.
  - A coverage matrix of (endpoint, bug-class) pairs the loop has tried.
  - The latest LLM-proposed plan and the result of the last action.

This module owns the in-memory state. The findings DB stays the
authoritative store of what got persisted; working memory is what the
LLM agent reasons over while the engagement is live.

PRIVACY RULES (non-negotiable, enforced by the type system).

  Rule 1, per-engagement isolation by default. State is constructed for
  one engagement_id and never reads or writes other engagements. The
  cross_engagement_share flag is opt-in, off by default.

  Rule 2, patterns cross engagements, raw data does not. When a customer
  opts into cross-engagement sharing, only `EngagementPattern` records
  are exported. Raw findings, raw HTTP, captured tokens, and credentials
  never leave the engagement.

  Rule 3, sharing is local by default. Even with cross_engagement_share
  on, patterns stay on disk in ~/.local/share/pentest-ai/patterns.db.
  Uploading to a global pool is a separate, explicit step the customer
  must take per-engagement.

These rules are enforced in code. See tests/test_working_memory.py for
the assertions.
"""
from __future__ import annotations

import hashlib
import json
import logging
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("pentest-ai.working_memory")


# Bug-class taxonomy used by the coverage matrix. New SPA probes register
# their class here so coverage tracking knows what to count.
BUG_CLASSES: tuple[str, ...] = (
    "sqli",
    "xss_reflected",
    "xss_stored",
    "ssrf",
    "ssti",
    "xxe",
    "idor",
    "auth_bypass",
    "jwt_alg_none",
    "jwt_kid_inject",
    "jwt_secret_weak",
    "open_redirect",
    "file_upload_bypass",
    "path_traversal",
    "nosql_injection",
    "command_injection",
    "rce_deserialization",
    "rce_template",
    "csrf",
    "cors_misconfig",
    "header_injection",
    "race_condition",
    "business_logic",
    "exposed_admin",
    "exposed_dev",
    "dir_listing",
    "source_map_exposure",
    "vulnerable_dep",
    "security_misconfig",
    "insecure_cookie",
    "info_disclosure",
)


@dataclass(frozen=True)
class EndpointKey:
    """A coverage-matrix row key. Hashed on (method, path) so query strings
    don't fragment coverage when only the value differs.
    """

    method: str
    path: str


@dataclass
class FindingRef:
    """In-memory reference to a finding. Full record stays in the findings DB."""

    id: str
    severity: str
    category: str
    bug_class: str
    target: str
    poc_status: str = "pending"


@dataclass
class CoverageMatrix:
    """Tracks which (endpoint, bug-class) pairs have been attempted.

    The agent uses this to decide what's left to try and to declare done.
    """

    _tried: set[tuple[EndpointKey, str]] = field(default_factory=set)
    _hits: set[tuple[EndpointKey, str]] = field(default_factory=set)

    def mark_tried(self, endpoint: EndpointKey, bug_class: str, hit: bool) -> None:
        if bug_class not in BUG_CLASSES:
            raise ValueError(f"unknown bug_class: {bug_class}")
        self._tried.add((endpoint, bug_class))
        if hit:
            self._hits.add((endpoint, bug_class))

    def has_tried(self, endpoint: EndpointKey, bug_class: str) -> bool:
        return (endpoint, bug_class) in self._tried

    def untried_pairs(
        self, endpoints: Iterable[EndpointKey], bug_classes: Iterable[str] | None = None
    ) -> list[tuple[EndpointKey, str]]:
        bcs = list(bug_classes) if bug_classes else list(BUG_CLASSES)
        out = []
        for ep in endpoints:
            for bc in bcs:
                if (ep, bc) not in self._tried:
                    out.append((ep, bc))
        return out

    def stats(self) -> dict[str, int]:
        return {
            "tried_pairs": len(self._tried),
            "hit_pairs": len(self._hits),
        }


@dataclass
class CapturedAuth:
    """Credentials or tokens captured during the engagement.

    NEVER persisted across engagements. Lives in working memory only.
    The findings DB may store a redacted reference but the value is in-memory.
    """

    kind: str  # 'jwt', 'cookie', 'basic', 'bearer', 'session_id'
    value: str
    source_endpoint: str
    captured_at: str
    role_hint: str = ""  # e.g. 'admin' if we know


@dataclass
class EngagementPattern:
    """A pattern-level signature suitable for cross-engagement sharing.

    Contains NO raw data. Only hashed indicators and a category.
    Example: "express + body-parser <1.20 + has /admin/config endpoint"
    becomes a pattern_hash + bug_class + an opaque feature signature.
    """

    pattern_hash: str
    bug_class: str
    feature_signature: str  # human-readable summary, no PII allowed
    seen_count: int = 1


@dataclass
class WorkingMemory:
    """Per-engagement state object.

    Constructor enforces the engagement_id boundary. Methods refuse to
    operate across engagements unless cross_engagement_share is True
    AND the caller passes the correct global registry handle.
    """

    engagement_id: str
    target: str
    findings: list[FindingRef] = field(default_factory=list)
    endpoints_seen: set[EndpointKey] = field(default_factory=set)
    coverage: CoverageMatrix = field(default_factory=CoverageMatrix)
    captured_auth: list[CapturedAuth] = field(default_factory=list)
    last_action: dict[str, Any] | None = None
    last_observation: dict[str, Any] | None = None
    cross_engagement_share: bool = False
    iterations: int = 0
    # Set by run_agent_loop on exit. One of agent_loop.ExitReason or None
    # if the loop never ran. Surfaced here (not on a return tuple) so
    # existing callers that only inspect the WorkingMemory keep working.
    exit_reason: str | None = None

    def add_finding(self, ref: FindingRef) -> None:
        self.findings.append(ref)

    def add_endpoint(self, ep: EndpointKey) -> None:
        self.endpoints_seen.add(ep)

    def add_auth(self, auth: CapturedAuth) -> None:
        if not self.engagement_id:
            raise ValueError("auth captured but engagement_id is empty; refusing to retain")
        self.captured_auth.append(auth)

    def summary_for_llm(self) -> dict[str, Any]:
        """Compact state snapshot the LLM agent can reason over.

        Excludes raw auth values. Includes counts, samples of recent findings
        and discovered endpoints, plus the untried (endpoint, bug_class) pairs
        so the LLM can pick what's most likely to find a new bug next.

        Sampling caps: 10 recent findings, 30 endpoints, 20 untried pairs.
        These keep token usage bounded while giving the LLM actionable state
        rather than just counts. PentestGPT's published 228% task-completion
        improvement (arXiv 2308.06782) comes from this kind of structured
        state representation versus a flat counts dict.
        """
        sev_counts: dict[str, int] = {}
        for f in self.findings:
            sev_counts[f.severity] = sev_counts.get(f.severity, 0) + 1

        recent = [
            {
                "id": f.id,
                "severity": f.severity,
                "bug_class": f.bug_class,
                "category": f.category,
                "target": f.target,
            }
            for f in self.findings[-10:]
        ]

        endpoints_sample = [
            {"method": e.method, "path": e.path}
            for e in list(self.endpoints_seen)[:30]
        ]

        untried_sample = [
            {"path": ep.path, "method": ep.method, "bug_class": bc}
            for ep, bc in self.coverage.untried_pairs(self.endpoints_seen)[:20]
        ]

        return {
            "engagement_id": self.engagement_id,
            "target": self.target,
            "iteration": self.iterations,
            "findings_total": len(self.findings),
            "findings_by_severity": sev_counts,
            "recent_findings": recent,
            "endpoints_seen_count": len(self.endpoints_seen),
            "endpoints_seen_sample": endpoints_sample,
            "untried_pairs_sample": untried_sample,
            "coverage": self.coverage.stats(),
            "auth_captured_count": len(self.captured_auth),
            "auth_kinds": [a.kind for a in self.captured_auth],
            "last_action": self.last_action,
            "last_observation": self.last_observation,
        }

    def export_patterns(self) -> list[EngagementPattern]:
        """Pattern-level export. Always safe across engagements.

        Refuses to export if the engagement has no findings (nothing
        meaningful to share) or if cross_engagement_share is off.
        """
        if not self.cross_engagement_share:
            return []
        if not self.findings:
            return []
        out = []
        for f in self.findings:
            sig = f"{f.bug_class}:{f.category}"
            h = hashlib.sha256(f"{self.target}:{f.bug_class}:{f.category}".encode()).hexdigest()[:16]
            out.append(
                EngagementPattern(
                    pattern_hash=h,
                    bug_class=f.bug_class,
                    feature_signature=sig,
                )
            )
        return out

    def to_redacted_json(self) -> str:
        """JSON dump safe for logging. Auth values + finding evidence redacted."""
        d = {
            "engagement_id": self.engagement_id,
            "target": self.target,
            "iterations": self.iterations,
            "findings": [
                {"id": f.id, "severity": f.severity, "bug_class": f.bug_class}
                for f in self.findings
            ],
            "endpoints_seen": [{"method": e.method, "path": e.path} for e in self.endpoints_seen],
            "auth_kinds_captured": [a.kind for a in self.captured_auth],
            "coverage": self.coverage.stats(),
        }
        return json.dumps(d, indent=2, sort_keys=True)


def make_working_memory(engagement_id: str, target: str) -> WorkingMemory:
    """Factory. Validates inputs to keep the engagement_id boundary explicit."""
    if not engagement_id:
        raise ValueError("engagement_id required")
    if not target:
        raise ValueError("target required")
    return WorkingMemory(engagement_id=engagement_id, target=target)
