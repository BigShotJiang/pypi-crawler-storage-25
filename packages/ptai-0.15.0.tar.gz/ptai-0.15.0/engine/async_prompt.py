"""Async wrapper around ``input()`` with a hard timeout.

Used by the smart-install flow to ask "install X, Y, Z? [y/n]" without
blocking the agent loop forever. Honors ``sys.stdin.isatty()`` and the
``PTAI_NON_INTERACTIVE`` environment variable so CI runs never hang.

Rendered through ``rich.console.Console`` so the prompt matches the rest of
ptai's CLI look.
"""
from __future__ import annotations

import asyncio
import os
import sys

from rich.console import Console
from rich.panel import Panel

_console = Console()


def is_non_interactive() -> bool:
    """Return True when we should auto-default without prompting.

    Mirrors the convention used at ``cli/main.py:464`` plus the explicit
    ``PTAI_NON_INTERACTIVE`` env override.
    """
    if os.environ.get("PTAI_NON_INTERACTIVE", "").strip() in ("1", "true", "yes"):
        return True
    return not sys.stdin.isatty()


async def prompt_with_timeout(
    message: str,
    *,
    default: str,
    timeout_s: float = 30.0,
    title: str | None = None,
) -> str:
    """Ask the user a question and wait up to ``timeout_s`` seconds for an answer.

    Returns the user's response stripped of whitespace, or ``default`` if the
    timer expires, stdin is not a TTY, ``PTAI_NON_INTERACTIVE=1`` is set,
    or the underlying ``input()`` raises ``EOFError`` (closed stdin).

    The renderer is rich; ``title`` is shown as the panel heading when set.
    """
    if is_non_interactive():
        return default

    if title:
        _console.print(Panel.fit(message, title=title, border_style="cyan"))
        prompt = "> "
    else:
        prompt = f"{message} "

    try:
        answer = await asyncio.wait_for(
            asyncio.to_thread(input, prompt),
            timeout=timeout_s,
        )
    except asyncio.TimeoutError:
        _console.print(f"[dim](no answer in {timeout_s:g}s; defaulting to {default!r})[/dim]")
        return default
    except EOFError:
        return default
    return (answer or "").strip() or default
