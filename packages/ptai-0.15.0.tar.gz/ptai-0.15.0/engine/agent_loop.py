"""Outer reasoning loop for autonomous offensive engagements.

The loop replaces the previous fixed-pipeline orchestration. Instead of
running recon, then discovery, then injection, then chain, then validate,
then report, the agent loop:

  1. Observes the current engagement state via WorkingMemory.summary_for_llm.
  2. Asks the LLM to propose the most valuable next action given the
     state, the findings, the captured auth, and the coverage matrix.
  3. Dispatches the action to a registered handler (probe, tool, agent).
  4. Records the observation back into WorkingMemory.
  5. Repeats until the LLM proposes 'finish' OR a coverage threshold is
     met OR the iteration cap is reached.

This module owns the interface only. Action handlers live elsewhere
(agents/web/spa_probes.py, agents/exploit_chain/chain_agent.py, etc).
The loop calls into them by name.

Today the loop is behind the --agent-mode flag. The legacy fixed-
pipeline orchestration stays the default until the new path has been
shipped through phases 1 to 5 of the rebuild.
"""
from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal, Protocol

from engine.working_memory import WorkingMemory

logger = logging.getLogger("pentest-ai.agent_loop")

# Typed reasons for why the loop exited. Surfaced on WorkingMemory.exit_reason
# so callers can branch on cost-limit vs LLM-unavailable vs normal completion.
ExitReason = Literal[
    "finished",        # agent proposed finish (or queue drained)
    "max_iterations",  # iteration cap hit
    "coverage",        # coverage threshold met
    "cost_limit",      # CostTracker.over_budget() returned True
    "llm_unavailable", # LLM provider raised LLMUnavailableError
    "deterministic",   # finished after deterministic fallback exhausted probes
]

# Truncation caps for normalized observation fields. Keeping these
# small is the whole point of normalization, every byte we feed back
# into the LLM costs tokens. CAI's published 41% reduction comes
# from caps in this neighborhood (arXiv 2504.06017).
_EVIDENCE_MAX = 120
_RESPONSE_SNIPPET_MAX = 200

Verdict = Literal["confirmed", "partial", "failed", "inconclusive"]


@dataclass
class Action:
    """An action the LLM agent decides to take.

    name: handler key, e.g. 'probe.jwt_alg_none' or 'tool.sqlmap'.
    args: keyword args for the handler.
    rationale: free text from the LLM. Logged for explainability.
    """

    name: str
    args: dict[str, Any] = field(default_factory=dict)
    rationale: str = ""


@dataclass
class NormalizedResult:
    """Compact, structured shape sent to the LLM in place of raw tool output.

    The agent loop converts whatever a probe or tool returned into this
    seven-field record before exposing it via working memory. This is the
    contract the LLM sees, not the underlying probe result dict.

    Fields are bounded:
      - evidence is truncated to 120 chars
      - response_snippet is truncated to 200 chars
    so the per-iteration token cost stays predictable.
    """

    tool: str
    target: str
    verdict: Verdict
    evidence: str
    payload_used: str | None = None
    http_status: int | None = None
    response_snippet: str | None = None

    def __post_init__(self) -> None:
        if self.evidence and len(self.evidence) > _EVIDENCE_MAX:
            self.evidence = self.evidence[:_EVIDENCE_MAX]
        if (
            self.response_snippet is not None
            and len(self.response_snippet) > _RESPONSE_SNIPPET_MAX
        ):
            self.response_snippet = self.response_snippet[:_RESPONSE_SNIPPET_MAX]

    def to_dict(self) -> dict[str, Any]:
        return {
            "tool": self.tool,
            "target": self.target,
            "verdict": self.verdict,
            "evidence": self.evidence,
            "payload_used": self.payload_used,
            "http_status": self.http_status,
            "response_snippet": self.response_snippet,
        }


@dataclass
class Observation:
    """The result of an action. Goes back into working memory.

    `raw` is archived to the findings DB but NEVER sent to the LLM.
    `normalized` is the compact shape the agent loop exposes via
    WorkingMemory.summary_for_llm. Probes built before the
    normalization layer leave `normalized=None`; the legacy fallback
    in working_memory handles those.
    """

    action_name: str
    success: bool
    findings_added: int = 0
    endpoints_added: int = 0
    auth_added: int = 0
    raw: dict[str, Any] = field(default_factory=dict)  # archived to DB, never sent to LLM
    error: str = ""
    normalized: NormalizedResult | None = None


class LLMAgent(Protocol):
    """Anything that can take a state + propose a next action."""

    async def decide_next_action(self, state: dict[str, Any]) -> Action: ...


# Handler registry. Each registered handler takes (working_memory, args)
# and returns an Observation. New probes, tools, and agents register here
# so the LLM can call them by name.
_HANDLERS: dict[str, Callable] = {}


def register_handler(name: str, fn: Callable) -> None:
    if name in _HANDLERS:
        raise ValueError(f"handler {name} already registered")
    _HANDLERS[name] = fn


def get_registered_handlers() -> list[str]:
    return sorted(_HANDLERS.keys())


def _is_finish_action(action: Action) -> bool:
    return action.name in ("finish", "stop", "done")


class CostTrackerLike(Protocol):
    """Minimal surface the loop needs from a cost tracker.

    The real engine.llm.cost.CostTracker satisfies this. Tests pass a
    tiny stub class with the same `over_budget()` method.
    """

    def over_budget(self) -> bool: ...


@dataclass
class LoopConfig:
    """Termination + safety knobs for the agent loop."""

    max_iterations: int = 50
    coverage_threshold: float = 0.8  # stop when we've tried 80% of (endpoint, bug-class) pairs
    min_iterations_before_finish: int = 5  # don't let the agent give up after 1 step
    # Optional CostTracker. When set, the loop checks over_budget() after
    # each LLM call and exits cleanly (exit_reason='cost_limit') if true.
    # Backward-compat: None means no budget enforcement.
    cost_tracker: CostTrackerLike | None = None
    # On LLMUnavailableError, fall through to deterministic mode (run all
    # registered probe.* handlers in order) rather than stopping the run
    # with zero findings. Mirrors BaseAgent.run_tool_loop's fallback.
    fallback_to_deterministic: bool = True
    # Optional ScopeEnforcer. When set, exposed to handlers via the
    # engine.scope._current_scope contextvar for the duration of the run.
    # meta.http_request and any other URL-taking handlers hard-block when
    # the proposed target is out of scope. None disables enforcement
    # (back-compat for callers that haven't wired scope yet).
    scope: Any | None = None


def _get_llm_unavailable_cls() -> type[BaseException]:
    """Lazy import to avoid a hard dependency on agents/ from engine/."""
    try:
        from agents.base import LLMUnavailableError
        return LLMUnavailableError
    except Exception:  # noqa: BLE001
        return RuntimeError


async def run_agent_loop(
    agent: LLMAgent,
    memory: WorkingMemory,
    config: LoopConfig | None = None,
) -> WorkingMemory:
    """Drive the engagement to completion via the LLM agent.

    The agent decides each step. The loop enforces safety (iteration cap,
    handler validity, coverage termination, cost limit, LLM-unavailable
    fallback). Returns the same memory object with state updated; the
    typed exit reason is exposed as memory.exit_reason.
    """
    cfg = config or LoopConfig()
    llm_unavailable_cls = _get_llm_unavailable_cls()
    exit_reason: ExitReason = "max_iterations"

    # Expose scope to handlers via contextvar so e.g. meta.http_request can
    # hard-block off-scope URLs without every handler having to thread the
    # ScopeEnforcer through args. Reset on the way out.
    scope_token = None
    if cfg.scope is not None:
        from engine.scope import set_current_scope
        scope_token = set_current_scope(cfg.scope)

    while memory.iterations < cfg.max_iterations:
        memory.iterations += 1

        # Budget check is intentionally pre-flight: if the prior iteration's
        # LLM call pushed us over the limit, refuse to spend another dollar.
        if cfg.cost_tracker is not None and cfg.cost_tracker.over_budget():
            logger.warning("cost limit reached at iteration %d, stopping", memory.iterations)
            memory.last_observation = {
                "action_name": "cost_limit",
                "success": False,
                "verdict": "failed",
                "evidence": "cost limit reached",
                "error": "PTAI_PRICE_LIMIT exceeded",
            }
            exit_reason = "cost_limit"
            break

        state = memory.summary_for_llm()
        try:
            action = await agent.decide_next_action(state)
        except llm_unavailable_cls as e:
            logger.warning("LLM unavailable: %s", e)
            memory.last_observation = {
                "action_name": "llm_unavailable",
                "success": False,
                "verdict": "failed",
                "evidence": "LLM provider unreachable",
                "error": str(e),
            }
            if cfg.fallback_to_deterministic:
                await _run_deterministic_fallback(memory)
                exit_reason = "deterministic"
            else:
                exit_reason = "llm_unavailable"
            break
        except Exception as e:  # noqa: BLE001
            logger.warning("LLM proposed-action call failed: %s", e)
            exit_reason = "llm_unavailable"
            break

        if _is_finish_action(action):
            if memory.iterations < cfg.min_iterations_before_finish:
                logger.info(
                    "agent proposed finish at iteration %d, below floor %d, ignoring",
                    memory.iterations,
                    cfg.min_iterations_before_finish,
                )
                continue
            logger.info("agent proposed finish at iteration %d", memory.iterations)
            exit_reason = "finished"
            break

        handler = _HANDLERS.get(action.name)
        if handler is None:
            logger.warning("agent proposed unknown handler: %s", action.name)
            memory.last_action = {"name": action.name, "rationale": action.rationale}
            memory.last_observation = {
                "action_name": action.name,
                "success": False,
                "error": f"no handler registered for {action.name}",
            }
            continue

        memory.last_action = {
            "name": action.name,
            "args": action.args,
            "rationale": action.rationale,
        }
        try:
            obs = await handler(memory, action.args)
        except Exception as e:  # noqa: BLE001
            logger.warning("handler %s raised: %s", action.name, e)
            obs = Observation(action_name=action.name, success=False, error=str(e))
        memory.last_observation = {
            "action_name": obs.action_name,
            "success": obs.success,
            "findings_added": obs.findings_added,
            "endpoints_added": obs.endpoints_added,
            "auth_added": obs.auth_added,
            "error": obs.error,
        }

        if _coverage_above_threshold(memory, cfg.coverage_threshold):
            logger.info("coverage threshold %.2f reached, terminating", cfg.coverage_threshold)
            exit_reason = "coverage"
            break

    memory.exit_reason = exit_reason
    if scope_token is not None:
        from engine.scope import reset_current_scope
        reset_current_scope(scope_token)
    return memory


async def _run_deterministic_fallback(memory: WorkingMemory) -> None:
    """Run every registered probe.* handler in registry order.

    Used when the LLM provider is unreachable and fallback_to_deterministic
    is on. Mirrors agents.base.BaseAgent's deterministic fallback path.
    Exceptions in individual handlers are swallowed so one bad probe can't
    kill the whole sweep. Findings already collected before the failure
    are preserved.
    """
    import asyncio

    handlers = [(n, h) for n, h in _HANDLERS.items() if n.startswith("probe.")]
    logger.info("deterministic fallback: running %d probe handlers", len(handlers))
    for name, handler in handlers:
        try:
            result = handler(memory, {})
            if asyncio.iscoroutine(result):
                obs = await result
            else:
                obs = result
            if isinstance(obs, Observation):
                memory.last_observation = {
                    "action_name": obs.action_name,
                    "success": obs.success,
                    "findings_added": obs.findings_added,
                    "endpoints_added": obs.endpoints_added,
                    "auth_added": obs.auth_added,
                    "error": obs.error,
                }
        except Exception as e:  # noqa: BLE001
            logger.warning("deterministic probe %s raised: %s", name, e)


def _coverage_above_threshold(memory: WorkingMemory, threshold: float) -> bool:
    """Stop when the coverage matrix is filled past the threshold.

    Coverage is `tried_pairs / (endpoints_seen * bug_classes)`. With no
    endpoints, coverage is 0 by definition.
    """
    from engine.working_memory import BUG_CLASSES
    n_endpoints = len(memory.endpoints_seen)
    if n_endpoints == 0:
        return False
    total_possible = n_endpoints * len(BUG_CLASSES)
    if total_possible == 0:
        return False
    tried = memory.coverage.stats()["tried_pairs"]
    return (tried / total_possible) >= threshold
