"""Tool dependency manager for pentest-ai.

Handles detection, installation, and validation of external security tools.
Supports tiered installation profiles based on disk/network constraints.
"""

import os
import platform
import shutil
import subprocess
from dataclasses import dataclass
from enum import Enum
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

console = Console()


class InstallTier(str, Enum):
    CORE = "core"
    RECOMMENDED = "recommended"
    FULL = "full"


class InstallMethod(str, Enum):
    APT = "apt"
    GO = "go"
    PIP = "pip"
    CARGO = "cargo"
    SNAP = "snap"
    MANUAL = "manual"


@dataclass(frozen=True)
class ToolSpec:
    name: str
    command: str
    tier: InstallTier
    method: InstallMethod
    install_cmd: tuple[str, ...]
    category: str
    size_mb: int = 0
    description: str = ""
    est_install_time_s: int = 60


TOOL_CATALOG: tuple[ToolSpec, ...] = (
    # Core tier (~200 MB): essentials for any engagement
    ToolSpec("nmap", "nmap", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "nmap"), "network", 25,
             "Port scanner and service detection"),
    ToolSpec("nikto", "nikto", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "nikto"), "web", 15,
             "Web server vulnerability scanner"),
    ToolSpec("sqlmap", "sqlmap", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "sqlmap"), "web", 20,
             "SQL injection detection and exploitation"),
    ToolSpec("whatweb", "whatweb", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "whatweb"), "recon", 10,
             "Web technology fingerprinting"),
    ToolSpec("sslscan", "sslscan", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "sslscan"), "network", 5,
             "SSL/TLS configuration scanner"),
    ToolSpec("dnsutils", "dig", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "dnsutils"), "recon", 5,
             "DNS lookup utilities"),
    ToolSpec("whois", "whois", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "whois"), "recon", 2,
             "Domain registration lookups"),
    ToolSpec("curl", "curl", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "curl"), "recon", 5,
             "HTTP client"),
    ToolSpec("nuclei", "nuclei", InstallTier.CORE, InstallMethod.GO,
             ("go", "install", "github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"), "web", 50,
             "Template-based vulnerability scanner"),

    # Recommended tier (~500 MB): solid coverage for most engagements
    ToolSpec("gobuster", "gobuster", InstallTier.RECOMMENDED, InstallMethod.GO,
             ("go", "install", "github.com/OJ/gobuster/v3@latest"), "web", 15,
             "Directory and DNS brute-forcing"),
    ToolSpec("ffuf", "ffuf", InstallTier.RECOMMENDED, InstallMethod.GO,
             ("go", "install", "github.com/ffuf/ffuf/v2@latest"), "web", 15,
             "Fast web fuzzer"),
    ToolSpec("httpx", "httpx", InstallTier.RECOMMENDED, InstallMethod.GO,
             ("go", "install", "github.com/projectdiscovery/httpx/cmd/httpx@latest"), "recon", 20,
             "HTTP probing and tech detection"),
    ToolSpec("subfinder", "subfinder", InstallTier.RECOMMENDED, InstallMethod.GO,
             ("go", "install", "github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"), "recon", 20,
             "Subdomain enumeration"),
    ToolSpec("naabu", "naabu", InstallTier.RECOMMENDED, InstallMethod.GO,
             ("go", "install", "github.com/projectdiscovery/naabu/v2/cmd/naabu@latest"), "network", 15,
             "Fast port scanner"),
    ToolSpec("katana", "katana", InstallTier.RECOMMENDED, InstallMethod.GO,
             ("go", "install", "github.com/projectdiscovery/katana/cmd/katana@latest"), "web", 15,
             "Web crawler"),
    ToolSpec("wafw00f", "wafw00f", InstallTier.RECOMMENDED, InstallMethod.PIP,
             ("pip", "install", "wafw00f"), "web", 5,
             "WAF detection"),
    ToolSpec("dirsearch", "dirsearch", InstallTier.RECOMMENDED, InstallMethod.PIP,
             ("pip", "install", "dirsearch"), "web", 5,
             "Web path brute-forcer"),
    ToolSpec("wpscan", "wpscan", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "wpscan"), "web", 30,
             "WordPress vulnerability scanner"),
    ToolSpec("hydra", "hydra", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "hydra"), "network", 10,
             "Brute-force password testing"),
    ToolSpec("john", "john", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "john"), "network", 15,
             "Password hash cracker"),
    ToolSpec("hashcat", "hashcat", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "hashcat"), "network", 20,
             "GPU-accelerated hash cracker"),

    # Full tier (~2 GB+): everything for deep engagements
    ToolSpec("metasploit", "msfconsole", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "metasploit-framework"), "exploit", 500,
             "Exploitation framework"),
    ToolSpec("responder", "responder", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "responder"), "ad", 20,
             "LLMNR/NBT-NS/MDNS poisoner"),
    ToolSpec("crackmapexec", "crackmapexec", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "crackmapexec"), "ad", 40,
             "AD/SMB pentesting toolkit"),
    ToolSpec("bloodhound-python", "bloodhound-python", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "bloodhound"), "ad", 15,
             "AD relationship data collector"),
    ToolSpec("amass", "amass", InstallTier.FULL, InstallMethod.GO,
             ("go", "install", "github.com/owasp-amass/amass/v4/...@master"), "recon", 50,
             "Attack surface mapping"),
    ToolSpec("dalfox", "dalfox", InstallTier.FULL, InstallMethod.GO,
             ("go", "install", "github.com/hahwul/dalfox/v2@latest"), "web", 15,
             "XSS scanner"),
    ToolSpec("arjun", "arjun", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "arjun"), "web", 5,
             "HTTP parameter discovery"),
    ToolSpec("xsstrike", "xsstrike", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "xsstrike"), "web", 5,
             "XSS detection"),
    ToolSpec("testssl", "testssl.sh", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "testssl.sh"), "network", 10,
             "TLS/SSL cipher testing"),
    ToolSpec("aircrack-ng", "aircrack-ng", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "aircrack-ng"), "wireless", 20,
             "Wireless network auditing"),

    # --- Extended catalog (batch 2): 50+ more tools ---
    # Cloud security
    ToolSpec("prowler", "prowler", InstallTier.RECOMMENDED, InstallMethod.PIP,
             ("pip", "install", "prowler"), "cloud", 25,
             "Multi-cloud security assessment", 90),
    ToolSpec("scout-suite", "scout", InstallTier.RECOMMENDED, InstallMethod.PIP,
             ("pip", "install", "scoutsuite"), "cloud", 30,
             "Multi-cloud security auditing", 90),
    ToolSpec("pacu", "pacu", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "pacu"), "cloud", 40,
             "AWS exploitation framework", 120),
    ToolSpec("kube-hunter", "kube-hunter", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "kube-hunter"), "cloud", 15,
             "Kubernetes vulnerability hunting", 60),
    ToolSpec("kube-bench", "kube-bench", InstallTier.FULL, InstallMethod.GO,
             ("go", "install", "github.com/aquasecurity/kube-bench@latest"), "cloud", 25,
             "CIS Kubernetes benchmarks", 120),
    ToolSpec("checkov", "checkov", InstallTier.RECOMMENDED, InstallMethod.PIP,
             ("pip", "install", "checkov"), "cloud", 50,
             "IaC static analysis", 90),
    ToolSpec("terrascan", "terrascan", InstallTier.FULL, InstallMethod.GO,
             ("go", "install", "github.com/tenable/terrascan@latest"), "cloud", 30,
             "Terraform/IaC compliance scanner", 120),
    ToolSpec("trivy", "trivy", InstallTier.RECOMMENDED, InstallMethod.GO,
             ("go", "install", "github.com/aquasecurity/trivy/cmd/trivy@latest"), "cloud", 60,
             "Container and IaC vulnerability scanner", 180),
    ToolSpec("cloudmapper", "cloudmapper", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "cloudmapper"), "cloud", 35,
             "AWS environment visualization", 120),

    # Active Directory
    ToolSpec("impacket", "impacket-getuserspns", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "impacket"), "ad", 25,
             "Network protocol toolkit (Kerberos, SMB, etc.)", 90),
    ToolSpec("kerbrute", "kerbrute", InstallTier.FULL, InstallMethod.GO,
             ("go", "install", "github.com/ropnop/kerbrute@latest"), "ad", 10,
             "Kerberos pre-auth username enumeration", 60),
    ToolSpec("enum4linux", "enum4linux", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "enum4linux"), "ad", 5,
             "SMB/Windows enumeration", 30),
    ToolSpec("enum4linux-ng", "enum4linux-ng", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "enum4linux-ng"), "ad", 5,
             "Modern Python rewrite of enum4linux", 30),
    ToolSpec("smbmap", "smbmap", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "smbmap"), "ad", 5,
             "SMB share enumeration", 30),
    ToolSpec("ldap-utils", "ldapsearch", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "ldap-utils"), "ad", 5,
             "LDAP query tools", 30),
    ToolSpec("evil-winrm", "evil-winrm", InstallTier.FULL, InstallMethod.MANUAL,
             ("gem", "install", "evil-winrm"), "ad", 10,
             "WinRM shell over PowerShell remoting", 90),
    ToolSpec("netexec", "nxc", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "netexec"), "ad", 40,
             "Network execution toolkit (CME successor)", 120),

    # Web app pen-test
    ToolSpec("feroxbuster", "feroxbuster", InstallTier.RECOMMENDED, InstallMethod.CARGO,
             ("cargo", "install", "feroxbuster"), "web", 20,
             "Recursive content discovery", 180),
    ToolSpec("wfuzz", "wfuzz", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "wfuzz"), "web", 5,
             "Web application brute forcer", 30),
    ToolSpec("commix", "commix", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "commix"), "web", 10,
             "Command injection exploitation", 60),
    ToolSpec("xsser", "xsser", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "xsser"), "web", 10,
             "Cross-site scripting framework", 60),
    ToolSpec("graphql-cop", "graphql-cop", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "graphql-cop"), "web", 5,
             "GraphQL security audit", 30),

    # Recon / OSINT
    ToolSpec("assetfinder", "assetfinder", InstallTier.RECOMMENDED, InstallMethod.GO,
             ("go", "install", "github.com/tomnomnom/assetfinder@latest"), "recon", 10,
             "Subdomain finder", 60),
    ToolSpec("findomain", "findomain", InstallTier.RECOMMENDED, InstallMethod.CARGO,
             ("cargo", "install", "findomain"), "recon", 15,
             "Cross-platform subdomain enumerator", 180),
    ToolSpec("shuffledns", "shuffledns", InstallTier.FULL, InstallMethod.GO,
             ("go", "install", "github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"), "recon", 20,
             "Mass DNS resolver", 90),
    ToolSpec("theharvester", "theHarvester", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "theharvester"), "recon", 20,
             "OSINT email/domain harvesting", 60),
    ToolSpec("recon-ng", "recon-ng", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "recon-ng"), "recon", 30,
             "Web reconnaissance framework", 90),
    ToolSpec("dnsenum", "dnsenum", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "dnsenum"), "recon", 5,
             "DNS enumeration", 30),
    ToolSpec("dnsrecon", "dnsrecon", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "dnsrecon"), "recon", 5,
             "DNS reconnaissance", 30),
    ToolSpec("fierce", "fierce", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "fierce"), "recon", 5,
             "Domain DNS sweep", 30),

    # Mobile
    ToolSpec("jadx", "jadx", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "jadx"), "mobile", 50,
             "Android decompiler", 90),
    ToolSpec("apktool", "apktool", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "apktool"), "mobile", 25,
             "APK reverse engineering", 60),
    ToolSpec("frida", "frida", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "frida-tools"), "mobile", 30,
             "Dynamic instrumentation toolkit", 120),
    ToolSpec("objection", "objection", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "objection"), "mobile", 20,
             "Frida-powered runtime mobile exploration", 90),
    ToolSpec("mobsf", "mobsf", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "mobsf"), "mobile", 200,
             "Mobile security framework", 600),

    # Binary / reverse engineering
    ToolSpec("radare2", "r2", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "radare2"), "binary", 40,
             "Reverse engineering framework", 90),
    ToolSpec("gdb", "gdb", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "gdb"), "binary", 20,
             "GNU debugger", 30),
    ToolSpec("pwntools", "pwn", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "pwntools"), "binary", 30,
             "CTF / exploit development framework", 120),
    ToolSpec("ropgadget", "ROPgadget", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "ropgadget"), "binary", 5,
             "ROP gadget finder", 30),
    ToolSpec("binwalk", "binwalk", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "binwalk"), "binary", 10,
             "Firmware analysis", 30),

    # Crypto / TLS
    ToolSpec("sslyze", "sslyze", InstallTier.RECOMMENDED, InstallMethod.PIP,
             ("pip", "install", "sslyze"), "network", 10,
             "Fast TLS/SSL configuration analyzer", 60),

    # Network
    ToolSpec("masscan", "masscan", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "masscan"), "network", 10,
             "Internet-scale port scanner", 60),
    ToolSpec("zmap", "zmap", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "zmap"), "network", 10,
             "Internet-scale network scanner", 60),
    ToolSpec("rustscan", "rustscan", InstallTier.FULL, InstallMethod.CARGO,
             ("cargo", "install", "rustscan"), "network", 15,
             "Modern fast port scanner", 180),
    ToolSpec("mitmproxy", "mitmproxy", InstallTier.RECOMMENDED, InstallMethod.PIP,
             ("pip", "install", "mitmproxy"), "network", 30,
             "Interactive HTTPS proxy", 90),
    ToolSpec("bettercap", "bettercap", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "bettercap"), "network", 25,
             "Network attack and monitoring framework", 60),
    ToolSpec("tcpdump", "tcpdump", InstallTier.CORE, InstallMethod.APT,
             ("apt-get", "install", "-y", "tcpdump"), "network", 5,
             "Packet capture", 30),
    ToolSpec("tshark", "tshark", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "tshark"), "network", 30,
             "Wireshark CLI", 60),

    # Browser automation
    ToolSpec("playwright", "playwright", InstallTier.RECOMMENDED, InstallMethod.PIP,
             ("pip", "install", "playwright"), "web", 100,
             "Browser automation (used by ptai for auth flows)", 180),
    ToolSpec("selenium", "selenium", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "selenium"), "web", 30,
             "Browser automation library", 60),

    # Misc
    ToolSpec("wapiti", "wapiti", InstallTier.FULL, InstallMethod.PIP,
             ("pip", "install", "wapiti3"), "web", 20,
             "Web application vulnerability scanner", 60),
    ToolSpec("nbtscan", "nbtscan", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "nbtscan"), "ad", 5,
             "NetBIOS scanner", 30),
    ToolSpec("crackmap-smb", "smbclient", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "smbclient"), "ad", 10,
             "SMB client", 30),
    ToolSpec("medusa", "medusa", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "medusa"), "network", 10,
             "Parallel brute-force login", 30),
    ToolSpec("ncrack", "ncrack", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "ncrack"), "network", 10,
             "Network authentication cracker", 30),
    ToolSpec("snmpwalk", "snmpwalk", InstallTier.RECOMMENDED, InstallMethod.APT,
             ("apt-get", "install", "-y", "snmp"), "network", 5,
             "SNMP enumeration", 30),
    ToolSpec("onesixtyone", "onesixtyone", InstallTier.FULL, InstallMethod.APT,
             ("apt-get", "install", "-y", "onesixtyone"), "network", 5,
             "Fast SNMP scanner", 30),
)


def detect_os() -> str:
    if os.path.exists("/etc/debian_version"):
        return "debian"
    if os.path.exists("/etc/redhat-release"):
        return "redhat"
    if platform.system() == "Darwin":
        return "macos"
    return "unknown"


def has_go() -> bool:
    return shutil.which("go") is not None


def has_pip() -> bool:
    return shutil.which("pip") is not None or shutil.which("pip3") is not None


def audit_tools(tier: InstallTier | None = None) -> dict[str, Any]:
    """Check which tools are installed and which are missing."""
    installed: list[ToolSpec] = []
    missing: list[ToolSpec] = []

    for tool in TOOL_CATALOG:
        if tier and tool.tier.value > tier.value:
            continue
        if shutil.which(tool.command):
            installed.append(tool)
        else:
            missing.append(tool)

    total_missing_mb = sum(t.size_mb for t in missing)
    return {
        "installed": installed,
        "missing": missing,
        "total_missing_mb": total_missing_mb,
        "go_available": has_go(),
        "pip_available": has_pip(),
    }


def audit_named(names: list[str]) -> dict[str, list[str]]:
    """Audit a specific subset of tool names. Reads from TOOL_CATALOG + registry.

    Used by the smart-install flow at engagement start: given the list of
    tools the planner predicted, return which are already on PATH and which
    are missing. Names that match no SecurityTool wrapper AND no ToolSpec
    are reported as "unknown".
    """
    installed: list[str] = []
    missing: list[str] = []
    unknown: list[str] = []

    catalog_by_name = {spec.name: spec for spec in TOOL_CATALOG}
    # Lazy import to avoid circulars: this module is imported very early.
    from tools.registry import ToolRegistry  # noqa: PLC0415 - intentional lazy import

    registry = ToolRegistry()

    for name in names:
        spec = catalog_by_name.get(name)
        if spec is not None:
            command = spec.command
        else:
            tool = registry.get_tool(name)
            if tool is None:
                unknown.append(name)
                continue
            command = tool.command

        (installed if shutil.which(command) else missing).append(name)

    return {"installed": installed, "missing": missing, "unknown": unknown}


def install_tool_by_name(
    name: str, sudo_password: str | None = None
) -> tuple[bool, str]:
    """Install a single tool by its wrapper name.

    Resolution order:

      1. ``TOOL_CATALOG`` (well-known tools with explicit install metadata).
      2. ``SecurityTool.install_method`` / ``install_cmd`` fields on the wrapper
         (added in Phase C of the tool-bridge plan; default ``None`` means
         "no programmatic install path").
      3. Returns ``(False, "manual install required ...")``.

    On success returns ``(True, message)``.
    """
    for spec in TOOL_CATALOG:
        if spec.name == name:
            return install_tool(spec, sudo_password=sudo_password)

    from tools.registry import ToolRegistry  # noqa: PLC0415 - intentional lazy import

    tool = ToolRegistry().get_tool(name)
    if tool is None:
        return False, f"unknown tool: {name}"

    install_method = getattr(tool, "install_method", None)
    install_cmd = getattr(tool, "install_cmd", None)
    manual_url = getattr(tool, "manual_url", None)

    if not install_method or not install_cmd:
        if manual_url:
            return False, f"manual install required: see {manual_url}"
        return False, (
            f"manual install required: no install metadata for {name}. "
            f"Try 'apt install {tool.command}' or check the tool's docs."
        )

    try:
        method = InstallMethod(install_method)
    except ValueError:
        return False, f"unknown install_method {install_method!r} on {name}"

    synthetic = ToolSpec(
        name=tool.name,
        command=tool.command,
        tier=InstallTier.FULL,  # not used by install_tool() path resolution
        method=method,
        install_cmd=tuple(install_cmd),
        category=tool.category,
        description=tool.description,
    )
    return install_tool(synthetic, sudo_password=sudo_password)


def print_audit(audit: dict[str, Any]) -> None:
    """Print a rich table showing tool install status."""
    table = Table(title="Security Tool Status")
    table.add_column("Tool", style="cyan")
    table.add_column("Tier")
    table.add_column("Category")
    table.add_column("Status")
    table.add_column("Size")

    for tool in audit["installed"]:
        table.add_row(
            tool.name,
            tool.tier.value,
            tool.category,
            "[green]Installed[/green]",
            f"{tool.size_mb}MB",
        )
    for tool in audit["missing"]:
        table.add_row(
            tool.name,
            tool.tier.value,
            tool.category,
            "[red]Missing[/red]",
            f"{tool.size_mb}MB",
        )

    console.print(table)
    console.print(f"\n[bold]Missing tools need ~{audit['total_missing_mb']}MB[/bold]")
    if not audit["go_available"]:
        console.print("[yellow]Go toolchain not found. Go-based tools will be skipped.[/yellow]")


def install_tool(tool: ToolSpec, sudo_password: str | None = None) -> tuple[bool, str]:
    """Install a single tool. Returns (success, message)."""
    if shutil.which(tool.command):
        return True, f"{tool.name} already installed"

    if tool.method == InstallMethod.APT:
        if sudo_password:
            # Pipe the password to sudo's stdin instead of using shell=True with
            # an f-string (CWE-78 risk if the password contained shell metachars).
            result = subprocess.run(
                ["sudo", "-S"] + list(tool.install_cmd),
                input=sudo_password + "\n",
                capture_output=True, text=True, timeout=300,
            )
        else:
            result = subprocess.run(
                ["sudo"] + list(tool.install_cmd), capture_output=True, text=True, timeout=300
            )
    elif tool.method == InstallMethod.GO:
        if not has_go():
            return False, "Go toolchain not installed"
        env = os.environ.copy()
        env["GOPATH"] = os.path.expanduser("~/go")
        env["PATH"] = env["PATH"] + ":" + os.path.expanduser("~/go/bin")
        result = subprocess.run(
            list(tool.install_cmd), capture_output=True, text=True, timeout=600, env=env
        )
    elif tool.method == InstallMethod.PIP:
        pip_cmd = "pip3" if shutil.which("pip3") else "pip"
        pip_argv: list[str] = list(tool.install_cmd)
        pip_argv[0] = pip_cmd
        result = subprocess.run(pip_argv, capture_output=True, text=True, timeout=300)
    else:
        return False, f"Unsupported install method: {tool.method}"

    if result.returncode == 0:
        return True, f"{tool.name} installed"
    return False, f"Failed: {result.stderr[:200]}"


def install_tier(
    tier: InstallTier,
    sudo_password: str | None = None,
    skip_tools: tuple[str, ...] = (),
) -> dict[str, Any]:
    """Install all tools up to a given tier."""
    tier_order = {InstallTier.CORE: 0, InstallTier.RECOMMENDED: 1, InstallTier.FULL: 2}
    target_level = tier_order[tier]

    to_install = [
        t for t in TOOL_CATALOG
        if tier_order[t.tier] <= target_level
        and t.name not in skip_tools
        and not shutil.which(t.command)
    ]

    if not to_install:
        console.print("[green]All tools for this tier are already installed.[/green]")
        return {"installed": 0, "failed": 0, "skipped": 0}

    # Run apt-get update once if any APT tools are needed
    apt_tools = [t for t in to_install if t.method == InstallMethod.APT]
    if apt_tools:
        console.print("[dim]Updating package index...[/dim]")
        if sudo_password:
            # See note in install_tool: pipe the password via stdin, never f-string into a shell.
            subprocess.run(
                ["sudo", "-S", "apt-get", "update", "-qq"],
                input=sudo_password + "\n",
                text=True, capture_output=True, timeout=120,
            )
        else:
            subprocess.run(
                ["sudo", "apt-get", "update", "-qq"],
                capture_output=True, timeout=120,
            )

    installed_count = 0
    failed_count = 0
    results: list[dict[str, str]] = []

    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
        task = progress.add_task(f"Installing {len(to_install)} tools...", total=len(to_install))

        for tool in to_install:
            progress.update(task, description=f"Installing {tool.name}...")
            ok, msg = install_tool(tool, sudo_password)
            if ok:
                installed_count += 1
                results.append({"tool": tool.name, "status": "ok", "message": msg})
            else:
                failed_count += 1
                results.append({"tool": tool.name, "status": "failed", "message": msg})
            progress.advance(task)

    console.print(f"\n[bold green]{installed_count} installed[/bold green], [bold red]{failed_count} failed[/bold red]")
    for r in results:
        if r["status"] == "failed":
            console.print(f"  [red]{r['tool']}: {r['message']}[/red]")

    return {"installed": installed_count, "failed": failed_count, "skipped": len(skip_tools), "details": results}


def interactive_setup(sudo_password: str | None = None) -> dict[str, Any]:
    """Run the interactive setup flow. Returns install results."""
    console.print(Panel.fit(
        "[bold cyan]pentest-ai Tool Setup[/bold cyan]\n\n"
        "This will install external security tools needed for pentesting.\n"
        "All tools are open source. You can skip any tier.",
        title="Setup",
    ))

    audit = audit_tools()
    print_audit(audit)

    console.print("\n[bold]Installation Tiers:[/bold]")
    console.print("  [cyan]core[/cyan]         ~200MB  Essential scanners (nmap, nuclei, nikto, sqlmap)")
    console.print("  [cyan]recommended[/cyan]   ~500MB  Core + fuzzers, crawlers, password tools")
    console.print("  [cyan]full[/cyan]          ~2GB+   Everything including Metasploit, wireless, AD tools")
    console.print("  [cyan]skip[/cyan]          0MB     Install nothing, use only built-in scanners\n")

    return audit
