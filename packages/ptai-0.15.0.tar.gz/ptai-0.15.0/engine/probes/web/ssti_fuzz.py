"""Fuzzed SSTI probe: 13 polyglot payloads against render/preview/search endpoints.

Server-Side Template Injection occurs when user input is concatenated into a
template string and evaluated by the engine. Payloads target Jinja2 ({{7*7}}
returns 49), Twig ({{7*'7'}} returns 7777777), FreeMarker (${7*7}), Thymeleaf,
ERB, and Pebble/Velocity.

Detection: response body contains the numeric evaluation result ("49" or
"7777777") absent from baseline, or an engine error traceback string that
reveals the template engine identity.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.payloads.library import SSTI_PAYLOADS, fuzz
from engine.probes.recon.crawler import run_crawler

logger = logging.getLogger("pentest-ai.probes.web.ssti_fuzz")

ALWAYS_PROBED_TEMPLATES: tuple[str, ...] = (
    "/search?q={payload}",
    "/api/search?q={payload}",
    "/rest/track-order/{payload}",
    "/render?template={payload}",
    "/preview?data={payload}",
    "/api/feedback?comment={payload}",
    "/?name={payload}",
)

SSTI_PATH_HINTS: tuple[str, ...] = (
    "/render",
    "/preview",
    "/template",
    "/compile",
    "/evaluate",
    "/markdown",
    "/feedback",
    "/report",
    "/greet",
)

DEFAULT_PARAMS: tuple[str, ...] = (
    "q",
    "query",
    "template",
    "data",
    "text",
    "input",
    "content",
    "name",
)

# Strings present in response body when a template engine evaluates the payload.
SSTI_EVAL_MARKERS: tuple[str, ...] = (
    "49",       # {{7*7}} - Jinja2, FreeMarker, Pebble, Mako
    "7777777",  # {{7*'7'}} - Twig
    "343",      # {{7**3}} fallback for some engines
)

# Engine error substrings that indicate template evaluation attempted.
SSTI_ERROR_MARKERS: tuple[str, ...] = (
    "jinja2.exceptions",
    "TemplateSyntaxError",
    "UndefinedError",
    "nunjucks error",
    "FreeMarker template error",
    "org.thymeleaf",
    "com.mitchellbosecke.pebble",
    "velocity error",
)


def _make_detect_fn():
    """Hit when body shows evaluated arithmetic or an engine error traceback."""

    def detect(status: int, _headers: dict[str, str], body: str, baseline: str) -> bool:
        if status == 0 or not body:
            return False
        body_lc = body.lower()
        baseline_lc = baseline.lower()
        if any(m in body and m not in baseline for m in SSTI_EVAL_MARKERS):
            return True
        return any(m in body_lc and m not in baseline_lc for m in SSTI_ERROR_MARKERS)

    return detect


def _candidates(crawl) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for tpl in ALWAYS_PROBED_TEMPLATES:
        if tpl not in seen:
            seen.add(tpl)
            out.append(tpl)

    for path in crawl.api_paths | crawl.discovered_paths:
        path_lc = path.lower()
        if not any(h in path_lc for h in SSTI_PATH_HINTS):
            continue
        for param in DEFAULT_PARAMS:
            tpl = f"{path}?{param}={{payload}}"
            if tpl not in seen:
                seen.add(tpl)
                out.append(tpl)

    return out[:25]


def _emit(target: str, payload: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"Server-side template injection on {target}",
        "severity": "critical",
        "category": "injection",
        "target": target,
        "evidence": f"payload={payload[:80]} :: {evidence[:200]}",
        "bug_class": "ssti",
        "remediation": (
            "Never pass user input to template render functions. "
            "Use a sandboxed template engine or pre-compile templates at deploy time."
        ),
    }


@registry.probe(
    name="web.ssti_fuzz",
    bug_class="ssti",
    severity_max="critical",
    owasp="A03:2021",
    runtime_budget_s=25.0,
    tags=("anonymous", "high-roi", "fuzzing", "uses-crawler"),
    requires_auth=False,
)
async def probe_ssti_fuzz(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Crawler-driven 13-payload SSTI fuzz."""
    findings: list[dict[str, Any]] = []
    seen_targets: set[str] = set()

    try:
        crawl = await run_crawler(ctx.session, ctx.base)
    except Exception as exc:  # noqa: BLE001
        logger.warning("crawler failed during ssti_fuzz: %s", exc)
        return findings

    templates = _candidates(crawl)
    if not templates:
        return findings

    detect = _make_detect_fn()
    base = ctx.base.rstrip("/")

    for path_template in templates:
        url_template = (
            path_template
            if path_template.startswith(("http://", "https://"))
            else base + path_template
        )
        target_id = url_template.split("?", 1)[0].rstrip("/")
        if target_id in seen_targets:
            continue
        try:
            results = await asyncio.wait_for(
                fuzz(
                    ctx.session,
                    url_template,
                    SSTI_PAYLOADS,
                    detect,
                    concurrency=6,
                ),
                timeout=10,
            )
        except (asyncio.TimeoutError, Exception):  # noqa: BLE001
            continue

        hits = [r for r in results if r.get("hit")]
        if hits:
            seen_targets.add(target_id)
            best = hits[0]
            findings.append(
                _emit(target_id, best["payload"], best.get("body_snippet", "")[:200])
            )

    return findings
