"""Hidden-page discovery probe.

Walks a curated list of "hidden but findable" paths that show up in
Juice Shop's Miscellaneous and Security-through-Obscurity challenges.
Each hit (status 200 with a non-empty body) becomes a finding tagged
with the path's importance: medium for admin/score-board surfaces, low
for chatbots and Easter eggs, info for security.txt, robots.txt, and
sitemap.xml.

The probe is read-only, runs unauthenticated, and uses the shared
`http_get` primitive for uniform error and timeout behavior.
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

# Each entry: (path, severity, bug_class, title, content_markers)
#
# `content_markers`: optional tuple of substrings that MUST appear in the
# response body for the finding to fire. None means "fire on any 200 with a
# non-empty body" (the original behavior). Use markers for paths whose URL
# alone is ambiguous on non-Juice-Shop targets — SPA shell HTML returns 200
# for any hash route, so `/#/score-board` without content validation
# triggers a false positive on every SPA.
#
# Marker matching is case-sensitive substring on the response body.
_JUICE_SCORE_BOARD_MARKERS = ("Challenge", "Score Board", "solved")
HIDDEN_PATHS: tuple[tuple[str, str, str, str, tuple[str, ...] | None], ...] = (
    (
        "/score-board",
        "medium",
        "exposed_admin",
        "Score Board exposed",
        _JUICE_SCORE_BOARD_MARKERS,
    ),
    (
        "/#/score-board",
        "medium",
        "exposed_admin",
        "Score Board SPA route exposed",
        _JUICE_SCORE_BOARD_MARKERS,
    ),
    (
        "/.well-known/security.txt",
        "info",
        "exposed_dev",
        "security.txt published at .well-known location",
        None,
    ),
    (
        "/security.txt",
        "info",
        "exposed_dev",
        "security.txt published at root",
        None,
    ),
    (
        "/robots.txt",
        "info",
        "exposed_dev",
        "robots.txt directives exposed",
        None,
    ),
    (
        "/sitemap.xml",
        "info",
        "exposed_dev",
        "sitemap.xml exposed",
        None,
    ),
    (
        "/api/Chatbot",
        "low",
        "exposed_dev",
        "Chatbot API endpoint reachable",
        None,
    ),
    (
        "/promotion",
        "low",
        "exposed_dev",
        "Promotion page reachable",
        None,
    ),
    # Juice-Shop easter-egg paths. Kept for backward compatibility but
    # downgraded to "info" severity: a hit on a non-Juice-Shop target
    # would be a false positive at any higher level.
    (
        "/the/devs/are/so/funny/they/hid/an/easter/egg/within/the/easter/egg",
        "info",
        "exposed_dev",
        "Easter Egg hidden path reachable",
        None,
    ),
    (
        "/we/may/also/instruct/you/to/refuse/all/reasonably/necessary/responsibility",
        "info",
        "exposed_dev",
        "Hidden privacy clause path reachable",
        None,
    ),
    (
        "/redirect?to=https://blockchain.info/",
        "info",
        "exposed_dev",
        "Redirect endpoint reachable",
        None,
    ),
    # Generic ops/observability paths. These belong to Spring Actuator,
    # Prometheus, and friends, not Juice Shop.
    (
        "/metrics",
        "medium",
        "exposed_admin",
        "Metrics endpoint reachable",
        None,
    ),
    (
        "/actuator",
        "medium",
        "exposed_admin",
        "Spring Actuator base path reachable",
        None,
    ),
    (
        "/actuator/health",
        "low",
        "exposed_dev",
        "Spring Actuator health endpoint reachable",
        None,
    ),
    (
        "/admin",
        "medium",
        "exposed_admin",
        "Admin path reachable",
        None,
    ),
    (
        "/profile",
        "medium",
        "exposed_admin",
        "Admin profile page reachable",
        None,
    ),
    (
        "/snippets",
        "medium",
        "exposed_admin",
        "Code snippets endpoint reachable",
        None,
    ),
)


def _emit(
    target: str,
    path: str,
    severity: str,
    bug_class: str,
    title: str,
    body: str,
) -> dict[str, Any]:
    return {
        "title": f"{title} ({path})",
        "severity": severity,
        "category": "information_disclosure",
        "target": target,
        "evidence": body[:512],
        "bug_class": bug_class,
        "remediation": (
            "Remove or gate the path behind authentication if it is not "
            "intended to be public. For score boards and admin surfaces, "
            "require an authenticated admin role."
        ),
    }


@registry.probe(
    name="web.hidden_discovery",
    bug_class="exposed_dev",
    severity_max="medium",
    owasp="A05:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "fast", "discovery"),
    requires_auth=False,
)
async def probe_hidden_discovery(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk the hidden-paths list, emit findings on 200 + non-empty body."""
    base = ctx.base
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    for path, severity, bug_class, title, content_markers in HIDDEN_PATHS:
        url = path if path.startswith(("http://", "https://")) else base + path
        status, _, body = await http_get(ctx.session, url, allow_redirects=False)
        if status != 200 or not body:
            continue
        if content_markers is not None and not any(m in body for m in content_markers):
            # 200 + non-empty body alone isn't enough — the path is one whose
            # URL would also resolve on unrelated targets (e.g. SPA shells
            # return 200 for any hash route). Require at least one marker
            # before classifying the response as a real hit.
            continue
        if url in seen:
            continue
        seen.add(url)
        findings.append(_emit(url, path, severity, bug_class, title, body))

    return findings
