"""Server-Side Template Injection probe (polyglot payload).

Many SSRF/SSTI hunts rip through engine-specific payloads one by one.
This probe takes a different shape: a single polyglot payload that any
of the common server-side template engines will evaluate to "49".

Payload: ``${7*7}{{7*7}}<%=7*7%>#{7*7}``

Coverage by engine:
  - Jinja2, Twig, Liquid, Nunjucks: ``{{7*7}}`` -> ``49``
  - ERB, EJS:                       ``<%=7*7%>`` -> ``49``
  - Velocity, Spring SpEL, JSP EL:  ``${7*7}`` -> ``49``
  - Ruby string interp, Pebble:     ``#{7*7}`` -> ``49``
  - Handlebars/Mustache: usually no eval but exposes literal braces

Two-step shape:

  1. Baseline: GET candidate URL with a benign canary value. Confirm
     status 200 and the body does NOT already contain "49".
  2. Perturbation: GET same URL with the polyglot payload URL-encoded.
     If the response contains "49" where the baseline did not, we have
     a server-side evaluation, ie. SSTI.

Severity:
  - high when the body contains a clean "49" (full evaluation).
  - medium when the body contains "{{49}}" or similar partial-evaluated
    artefacts (engine evaluated some but not all variants).

Read-only GET; runs unauthenticated; modest runtime budget.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import quote

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

CANARY = "ptaicanary"
POLYGLOT = "${7*7}{{7*7}}<%=7*7%>#{7*7}"
EVALUATED = "49"

# Partial-evaluation artefacts seen in the wild when only one engine
# variant fires. We treat any of these as a medium-severity signal.
PARTIAL_MARKERS: tuple[str, ...] = (
    "{{49}}",
    "${49}",
    "<%=49%>",
    "#{49}",
)

# Endpoint candidates: pages that historically reflect a query value
# back into a rendered template.
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/",
    "/search",
    "/api/search",
    "/q",
    "/lookup",
    "/name",
    "/greet",
    "/preview",
    "/render",
    "/template",
    "/msg",
    "/text",
)

# Common reflective parameter names.
DEFAULT_PARAMS: tuple[str, ...] = (
    "q",
    "query",
    "search",
    "name",
    "message",
    "text",
    "greet",
    "template",
    "content",
)


def _build_url(base: str, path: str, param: str, value: str) -> str:
    """Compose the test URL with one URL-encoded query parameter."""
    root = path if path.startswith(("http://", "https://")) else base + path
    sep = "&" if "?" in root else "?"
    return f"{root}{sep}{param}={quote(value, safe='')}"


def _classify(baseline_body: str, attack_body: str) -> str | None:
    """Return 'high', 'medium', or None for the body delta."""
    if EVALUATED in baseline_body:
        # Site already had "49" somewhere; any reflection is ambiguous.
        return None
    if EVALUATED not in attack_body:
        return None
    # We have a fresh "49" in the attack response. Distinguish full vs
    # partial evaluation by looking for the unevaluated wrappers.
    for marker in PARTIAL_MARKERS:
        if marker in attack_body:
            return "medium"
    return "high"


def _emit(
    target: str,
    severity: str,
    param: str,
    evidence: str,
) -> dict[str, Any]:
    return {
        "title": f"Server-Side Template Injection via '{param}' parameter",
        "severity": severity,
        "category": "injection",
        "target": target,
        "evidence": evidence,
        "bug_class": "rce_template",
        "remediation": (
            "Never render user input as a template. Pass values as "
            "context variables to a sandboxed renderer and HTML-escape "
            "all output. Audit every call site that interpolates "
            "request data into template strings."
        ),
    }


@registry.probe(
    name="web.ssti_polyglot",
    bug_class="rce_template",
    severity_max="high",
    owasp="A03:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_ssti_polyglot(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Two-step SSTI probe with a single polyglot payload."""
    candidates = ctx.candidate_endpoints or DEFAULT_CANDIDATES
    base = ctx.base
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    for path in candidates:
        for param in DEFAULT_PARAMS:
            baseline_url = _build_url(base, path, param, CANARY)
            b_status, _, b_body = await http_get(ctx.session, baseline_url)
            if b_status != 200:
                continue

            attack_url = _build_url(base, path, param, POLYGLOT)
            a_status, _, a_body = await http_get(ctx.session, attack_url)
            if a_status != 200:
                continue

            severity = _classify(b_body, a_body)
            if severity is None:
                continue

            # Dedupe per (path, param). A single hit per pair is plenty.
            key = f"{path}::{param}"
            if key in seen:
                continue
            seen.add(key)

            # Snip a window around the "49" for evidence.
            idx = a_body.find(EVALUATED)
            window_start = max(0, idx - 64)
            window_end = min(len(a_body), idx + 64)
            evidence = a_body[window_start:window_end]

            findings.append(_emit(attack_url, severity, param, evidence))

    return findings
