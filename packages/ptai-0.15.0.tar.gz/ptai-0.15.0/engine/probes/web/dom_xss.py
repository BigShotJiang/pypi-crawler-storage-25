"""DOM-rendered XSS probe.

Where ``reflected_xss`` only inspects raw HTTP bodies, this probe drives
a real browser. Some XSS bugs (Juice Shop #1, #36, #37, #41 among them)
only fire after the SPA bootstraps and the JS framework constructs DOM
nodes from user-controlled fragments. Server-side reflection checks
miss those entirely.

Approach: launch headless Chromium via Playwright, register a
``page.on('dialog')`` handler, navigate to candidate URLs that carry an
``alert('ptai-dom-xss-canary')`` payload, and wait briefly for a real
dialog to fire. The canary text is the only proof we accept; that
distinguishes our payload firing from any pre-existing site dialog.

Playwright is wrapped in try/except at call time so machines without a
browser (CI without ``playwright install`` run, locked-down servers)
get an empty finding list rather than an exception.
"""
from __future__ import annotations

import asyncio
import contextlib
from typing import Any

from engine.probes import ProbeContext, registry

CANARY = "ptai-dom-xss-canary"

# Probed against ctx.base. Each template carries the canary in an
# alert() expression so any dialog firing is unambiguously ours.
CANDIDATE_TEMPLATES: tuple[str, ...] = (
    f"/#/search?q=<iframe src=javascript:alert('{CANARY}')>",
    f"/#/track-order/<iframe src=javascript:alert('{CANARY}')>",
    f"/#/contact?comment=<iframe src=javascript:alert('{CANARY}')>",
    f"/#/?q=<svg/onload=alert('{CANARY}')>",
)

NAV_TIMEOUT_MS = 10_000
DIALOG_WAIT_MS = 2_000


def _emit(target: str, evidence: str, bug_class: str) -> dict[str, Any]:
    return {
        "title": "DOM-rendered XSS (browser dialog fired)",
        "severity": "high",
        "category": "injection",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": bug_class,
        "remediation": (
            "Sanitize untrusted input before inserting it into the DOM. "
            "Avoid innerHTML / bypassSecurityTrust* APIs on user content. "
            "Use a hardened sanitizer (DOMPurify with a strict allowlist) "
            "and a Content-Security-Policy that blocks inline scripts and "
            "javascript: URIs."
        ),
    }


def _classify_bug_class(url_template: str) -> str:
    """Stored vs reflected: only /contact (comment sink) is stored."""
    if "/contact" in url_template:
        return "xss_stored"
    return "xss_reflected"


async def _probe_url(page: Any, url: str) -> list[str]:
    """Navigate to ``url`` and return any dialog messages that fired."""
    triggered: list[str] = []

    def _on_dialog(dialog: Any) -> None:
        triggered.append(dialog.message)
        # Schedule dismiss without awaiting; Playwright tolerates this
        # because dialogs auto-dismiss when the handler returns control.
        with contextlib.suppress(Exception):
            asyncio.create_task(dialog.dismiss())

    page.on("dialog", _on_dialog)
    try:
        await page.goto(url, wait_until="networkidle", timeout=NAV_TIMEOUT_MS)
        await page.wait_for_timeout(DIALOG_WAIT_MS)
    except Exception:
        # Navigation failures (timeout, DNS, TLS) are non-findings.
        pass
    return triggered


@registry.probe(
    name="web.dom_xss",
    bug_class="xss_reflected",
    severity_max="high",
    owasp="A03:2021",
    runtime_budget_s=30.0,
    tags=("anonymous", "high-roi", "browser", "playwright"),
    requires_auth=False,
)
async def probe_dom_xss(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Drive headless Chromium against candidate URLs, watch for canary dialogs."""
    try:
        from playwright.async_api import async_playwright
    except Exception:
        # Playwright not installed or browser binaries missing: degrade
        # gracefully so the rest of the engagement isn't blocked.
        return []

    findings: list[dict[str, Any]] = []
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=True, args=["--no-sandbox"]
            )
            context = await browser.new_context()
            page = await context.new_page()
            try:
                for template in CANDIDATE_TEMPLATES:
                    url = ctx.base + template
                    triggered = await _probe_url(page, url)
                    canary_hits = [m for m in triggered if CANARY in m]
                    if canary_hits:
                        findings.append(
                            _emit(
                                target=url,
                                evidence=(
                                    f"Browser dialog fired with canary: "
                                    f"{canary_hits[0]}"
                                ),
                                bug_class=_classify_bug_class(template),
                            )
                        )
            finally:
                await browser.close()
    except Exception:
        # Any unexpected runtime failure (browser crash, OOM) downgrades
        # to "no findings" rather than poisoning the probe pipeline.
        return findings

    return findings
