"""Web Cache Deception probe with delimiter-discrepancy variants.

Based on PortSwigger's Kettle research ("Gotta cache 'em all", 2024-2025)
which paid out six-figure cumulative bounties on Next.js/CDN stacks.

Mechanism: many CDNs and reverse caches use a path-suffix rule to decide
"is this a static asset, cache it" while the upstream origin uses a
different rule (or none) to decide which authenticated handler runs. If
the cache treats `/api/me/.css` as a CSS asset and the origin treats it
as `/api/me`, the authenticated response gets cached under a static
cache key. Anonymous visitors then hit the same key and receive the
authenticated body.

Detection shape:

  1. Build candidate paths from prior findings + known authenticated
     shapes (/api/me, /api/profile, /me, /account, /dashboard).
  2. For each path, generate variants with delimiter tricks:
        /api/me/.css, /api/me/.js, /api/me/.json,
        /api/me;.css,
        /api/me%2F.css, /api/me%3B.css,
        /api/me/static.css.
  3. GET each variant authenticated. Then GET the SAME variant
     anonymously (no Authorization header).
  4. If the anonymous body is byte-equivalent to the authenticated
     body AND non-trivial in length, the cache served the authed
     response to an anonymous request: confirmed WCD.

Severity: HIGH on confirmed WCD because the leaked body normally
contains session-bound data (PII, internal IDs, tokens).
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_get

# Paths that commonly return per-user authenticated data.
DEFAULT_AUTH_PATHS: tuple[str, ...] = (
    "/api/me",
    "/api/profile",
    "/api/account",
    "/me",
    "/account",
    "/dashboard",
    "/api/users/me",
    "/api/v1/me",
)

# Delimiter tricks. Each is a format-string template applied to a base path.
# {p} is the candidate path stripped of any trailing slash.
_VARIANTS: tuple[str, ...] = (
    "{p}/.css",
    "{p}/.js",
    "{p}/.json",
    "{p};.css",
    "{p}%2F.css",
    "{p}%3B.css",
    "{p}/static.css",
)

# Cap total candidate variants to keep runtime bounded.
_MAX_CANDIDATES = 12

# Minimum body size required for a confident match. Empty 200s and tiny
# error pages would otherwise trigger spurious matches.
_MIN_BODY_SIZE = 64


def _build_variants(paths: tuple[str, ...]) -> list[str]:
    """Expand each base path into delimiter-discrepancy variants, capped."""
    out: list[str] = []
    seen: set[str] = set()
    for base_path in paths:
        p = base_path.rstrip("/")
        if not p:
            continue
        for tpl in _VARIANTS:
            v = tpl.format(p=p)
            if v not in seen:
                seen.add(v)
                out.append(v)
            if len(out) >= _MAX_CANDIDATES:
                return out
    return out


def _candidate_paths(ctx: ProbeContext) -> tuple[str, ...]:
    """Pick base auth paths to test. Hints + findings override defaults."""
    hint_paths = tuple(p for p in ctx.endpoint_hints if p.startswith("/"))
    if hint_paths:
        return hint_paths
    return DEFAULT_AUTH_PATHS


def _emit(target: str, evidence: str) -> dict[str, Any]:
    return {
        "title": "Web Cache Deception: authenticated body served to anonymous client",
        "severity": "high",
        "category": "misconfiguration",
        "target": target,
        "evidence": evidence,
        "bug_class": "business_logic",
        "owasp": "A05:2021",
        "remediation": (
            "Make the cache key include authentication state, or refuse "
            "to cache responses that vary by user. Normalize trailing "
            "static-extension paths at the edge before they reach the "
            "origin handler."
        ),
    }


@registry.probe(
    name="web.cache_deception",
    bug_class="business_logic",
    severity_max="high",
    owasp="A05:2021",
    runtime_budget_s=12.0,
    tags=("authenticated", "cache", "high-roi"),
    requires_auth=True,
)
async def probe_web_cache_deception(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Detect WCD by comparing authed vs anonymous responses on cache-trick URLs."""
    if ctx.captured_auth is None:
        return []
    headers = auth_headers(ctx.captured_auth)
    if not headers:
        return []

    findings: list[dict[str, Any]] = []
    seen: set[str] = set()
    base = ctx.base
    variants = _build_variants(_candidate_paths(ctx))

    for variant in variants:
        url = base + variant if variant.startswith("/") else f"{base}/{variant}"

        a_status, _, a_body = await http_get(ctx.session, url, headers=headers)
        if a_status != 200 or len(a_body) < _MIN_BODY_SIZE:
            continue

        n_status, _, n_body = await http_get(ctx.session, url)
        if n_status != 200 or len(n_body) < _MIN_BODY_SIZE:
            continue

        if a_body == n_body and url not in seen:
            seen.add(url)
            evidence = (
                f"authed_len={len(a_body)} anon_len={len(n_body)} match=byte-equal; "
                f"snippet={a_body[:200]}"
            )
            findings.append(_emit(url, evidence[:512]))

    return findings
