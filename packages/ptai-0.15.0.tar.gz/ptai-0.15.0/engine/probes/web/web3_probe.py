"""Web3 / NFT probe.

OWASP Juice Shop added Web3 challenges in recent versions, mirroring the
class of bugs that show up in production Web3 frontends bolted onto
classic web stacks: dev-only Solidity sandboxes shipped to prod, wallet
enumeration endpoints, and mint endpoints that forget to charge.

The probe is gated on Web3 detection: if the target's index page (and
optionally a few primary JS bundles) shows no Web3 markers
(`window.ethereum`, MetaMask references, contract addresses), the probe
skips cleanly. When markers are present the probe walks a small list of
known Web3 paths and emits findings on the ones that are accessible.
"""
from __future__ import annotations

import re
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

# Paths walked with GET. Each maps to a detector that decides whether
# the response shape matches a known Web3 surface.
GET_PATHS: tuple[str, ...] = (
    "/#/web3-sandbox",
    "/api/Wallet",
    "/api/Wallets",
    "/api/Web3Sandbox",
    "/promotion",
    "/api/NFTs",
    "/api/Coins",
)

MINT_PATH = "/api/Wallet/mint"

_SANDBOX_MARKERS: tuple[str, ...] = ("solidity", "compile", "Solc")
_MINT_MARKERS: tuple[str, ...] = ("minted", "tokenId")

# Markers in the index HTML / JS bundles that say "this app talks to a
# wallet or smart contract". Without one of these we have no business
# spraying NFT-shaped paths at the target.
_WEB3_MARKERS: tuple[str, ...] = (
    "window.ethereum",
    "metamask",
    "web3.js",
    "ethers.js",
    "walletconnect",
    "0x",  # contract address prefix in JS bundles
    "smartcontract",
    "smart contract",
    "nft",
    "wallet",
)

_CONTRACT_ADDR_RE = re.compile(r"0x[a-fA-F0-9]{40}\b")


async def detect_web3_markers(ctx: ProbeContext) -> tuple[bool, bool]:
    """Return (has_markers, sampled_any).

    `sampled_any` is True when at least one fetch returned a non-empty
    200 body. When we couldn't sample anything (every probe path 404s
    or fails) we have no signal; the caller proceeds conservatively.
    `has_markers` is True only when a sampled body explicitly hints at
    Web3 wiring.
    """
    base = ctx.base.rstrip("/")
    paths = ("/", "/index.html", "/rest/admin/application-configuration")
    sampled_any = False
    for path in paths:
        try:
            status, _, body = await http_get(ctx.session, base + path)
        except Exception:  # noqa: BLE001
            continue
        if status != 200 or not body:
            continue
        sampled_any = True
        lower = body.lower()
        # Contract-address regex is the strongest signal: a 40-hex 0x
        # token in an HTML/JS body almost always means Web3 wiring.
        if _CONTRACT_ADDR_RE.search(body):
            return True, True
        if any(marker in lower for marker in _WEB3_MARKERS):
            return True, True
    return False, sampled_any


def _emit(
    *,
    title: str,
    severity: str,
    target: str,
    evidence: str,
    bug_class: str,
) -> dict[str, Any]:
    return {
        "title": title,
        "severity": severity,
        "category": "web3",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": bug_class,
        "remediation": (
            "Remove dev-only Web3 surfaces from production builds, gate "
            "wallet/NFT endpoints behind authentication, and require "
            "payment confirmation before minting tokens."
        ),
    }


def _looks_like_sandbox(body: str) -> bool:
    lower = body.lower()
    return any(marker.lower() in lower for marker in _SANDBOX_MARKERS)


def _looks_like_json_array(body: str) -> bool:
    stripped = body.lstrip()
    if stripped.startswith("["):
        return True
    # Many Juice Shop endpoints wrap the array in {"data": [...]}.
    return '"data"' in stripped and "[" in stripped


def _looks_like_mint_success(body: str) -> bool:
    lower = body.lower()
    return any(marker.lower() in lower for marker in _MINT_MARKERS)


@registry.probe(
    name="web.web3_probe",
    bug_class="exposed_dev",
    severity_max="high",
    owasp="A05:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "web3", "novel"),
    requires_auth=False,
)
async def probe_web3(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk known Web3 paths; flag exposed sandboxes, wallets, NFTs, free mints."""
    base = ctx.base
    findings: list[dict[str, Any]] = []

    # Gate on Web3 markers when we can sample the index. If no body
    # came back at all (sampled_any=False) we keep the legacy behavior
    # of walking the path list anyway, since absence of evidence here
    # is not evidence of absence.
    has_markers, sampled_any = await detect_web3_markers(ctx)
    if sampled_any and not has_markers:
        return findings

    auth_headers: dict[str, str] = {}
    if ctx.captured_auth:
        token = ctx.captured_auth.get("token") or ctx.captured_auth.get("Authorization")
        if token:
            value = token if str(token).lower().startswith("bearer ") else f"Bearer {token}"
            auth_headers["Authorization"] = value

    for path in GET_PATHS:
        url = base + path
        status, _, body = await http_get(ctx.session, url)
        if status != 200:
            continue

        if path == "/#/web3-sandbox" or path == "/api/Web3Sandbox":
            if _looks_like_sandbox(body):
                findings.append(
                    _emit(
                        title=f"Web3 Sandbox exposed at {path}",
                        severity="medium",
                        target=url,
                        evidence=body,
                        bug_class="exposed_dev",
                    )
                )
            continue

        if path in ("/api/Wallet", "/api/Wallets"):
            if _looks_like_json_array(body):
                findings.append(
                    _emit(
                        title=f"Wallet enumeration at {path}",
                        severity="medium",
                        target=url,
                        evidence=body,
                        bug_class="exposed_dev",
                    )
                )
            continue

        if path == "/api/NFTs":
            if _looks_like_json_array(body) or "token" in body.lower():
                findings.append(
                    _emit(
                        title=f"NFT collection disclosure at {path}",
                        severity="low",
                        target=url,
                        evidence=body,
                        bug_class="exposed_dev",
                    )
                )
            continue

        if path == "/api/Coins":
            if _looks_like_json_array(body):
                findings.append(
                    _emit(
                        title=f"Coin/token listing at {path}",
                        severity="low",
                        target=url,
                        evidence=body,
                        bug_class="exposed_dev",
                    )
                )
            continue

        if path == "/promotion":
            # Promotion page is NFT-related on Juice Shop; treat plain 200 as info.
            findings.append(
                _emit(
                    title="Promotion page accessible",
                    severity="low",
                    target=url,
                    evidence=body,
                    bug_class="exposed_dev",
                )
            )
            continue

    # Mint attempt. The interesting signal is "minted" or "tokenId" in the body
    # on a 200, which means the server accepted a mint without payment.
    mint_url = base + MINT_PATH
    status, _, body = await http_post_json(
        ctx.session,
        mint_url,
        {"tokenId": 1, "amount": 1},
        headers=auth_headers or None,
    )
    if status == 200 and _looks_like_mint_success(body):
        findings.append(
            _emit(
                title="Free NFT mint without payment",
                severity="high",
                target=mint_url,
                evidence=body,
                bug_class="business_logic",
            )
        )

    return findings
