"""Fuzzed reflected-XSS probe: 26 payloads against crawler-discovered query endpoints.

Mirror of `web.sqli_fuzz` for cross-site scripting. The legacy `web.reflected_xss`
probe sends ONE payload per shape; this one sends all 26 from `XSS_PAYLOADS`
against every discovered query endpoint plus 7 always-probed canonical templates.

Detection: payload string appears in response body unencoded (no entity-encoded
fallback, no double-encoded artifact). Severity: high for any reflected hit,
critical when the payload lands in an executable context (script tag or
event-handler attribute) inferred by surrounding markers.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.payloads.library import XSS_PAYLOADS, fuzz
from engine.probes.recon.crawler import run_crawler

logger = logging.getLogger("pentest-ai.probes.web.xss_fuzz")

DEFAULT_QUERY_PARAMS: tuple[str, ...] = (
    "q",
    "query",
    "search",
    "name",
    "msg",
    "message",
    "text",
    "comment",
    "content",
    "ref",
    "next",
    "redirect",
    "callback",
    "wrap",
)

# Canonical reflective endpoints across modern SPAs.
ALWAYS_PROBED_TEMPLATES: tuple[str, ...] = (
    "/search?q={payload}",
    "/q?q={payload}",
    "/api/search?q={payload}",
    "/rest/track-order/{payload}",
    "/track-order/{payload}",
    "/error?msg={payload}",
    "/?ref={payload}",
)

REFLECTIVE_PATH_HINTS: tuple[str, ...] = (
    "/search",
    "/q",
    "/lookup",
    "/find",
    "/track-order",
    "/error",
    "/render",
    "/preview",
    "/echo",
    "/greet",
)


def _make_detect_fn():
    """Detect if any meaningful XSS marker appears in body but not baseline.

    Marker substrings we look for (any one is a hit):
      - `<script>alert` literal
      - `onerror=alert`
      - `onload=alert`
      - `javascript:alert`
      - `<svg/onload=`
      - `<iframe src=javascript:`

    All checks require the marker to be ABSENT from baseline so we don't
    flag a page that legitimately renders these substrings (e.g., a docs
    page about XSS).
    """
    markers = (
        "<script>alert",
        "<scrIpt>alert",
        "<ScRiPt>alert",
        "onerror=alert",
        "ONERROR=alert",
        "onload=alert",
        "javascript:alert",
        "JaVaScRiPt:alert",
        "<svg/onload=",
        "<svg onload=",
        "<iframe src=javascript:",
        "ontoggle=alert",
        "onfocus=alert",
    )

    def detect(status: int, _headers: dict[str, str], body: str, baseline: str) -> bool:
        if status == 0 or not body:
            return False
        return any(m in body and m not in baseline for m in markers)
    return detect


def _candidates(crawl) -> list[str]:
    """Build a deduped list of url_template strings (with `{payload}`).

    ALWAYS_PROBED_TEMPLATES first so canonical reflectors are never pushed
    off by lower-quality crawler hits. Cap at 25 templates total.
    """
    out: list[str] = []
    seen: set[str] = set()

    for tpl in ALWAYS_PROBED_TEMPLATES:
        if tpl not in seen:
            seen.add(tpl)
            out.append(tpl)

    # Forms with GET method
    for form in crawl.forms:
        if (form.get("method") or "get").lower() != "get":
            continue
        action = form.get("action") or "/"
        for field in form.get("fields") or []:
            param = field if isinstance(field, str) else field.get("name", "")
            if not param:
                continue
            tpl = f"{action}?{param}={{payload}}"
            if tpl not in seen:
                seen.add(tpl)
                out.append(tpl)

    # Crawler-discovered reflective paths
    for path in crawl.api_paths | crawl.discovered_paths:
        path_lc = path.lower()
        if not any(h in path_lc for h in REFLECTIVE_PATH_HINTS):
            continue
        for param in DEFAULT_QUERY_PARAMS:
            tpl = f"{path}?{param}={{payload}}"
            if tpl not in seen:
                seen.add(tpl)
                out.append(tpl)

    return out[:25]


def _emit(target: str, payload: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"Reflected XSS on {target} via fuzzed payload",
        "severity": "high",
        "category": "injection",
        "target": target,
        "evidence": f"payload={payload[:80]} :: {evidence[:200]}",
        "bug_class": "xss_reflected",
        "remediation": (
            "HTML-encode user input on output. Set Content-Type charset. "
            "Add a strict CSP (default-src 'self'; script-src 'self')."
        ),
    }


@registry.probe(
    name="web.xss_fuzz",
    bug_class="xss_reflected",
    severity_max="high",
    owasp="A03:2021",
    runtime_budget_s=30.0,
    tags=("anonymous", "high-roi", "fuzzing", "uses-crawler"),
    requires_auth=False,
)
async def probe_xss_fuzz(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Crawler-driven 26-payload reflected XSS fuzz."""
    findings: list[dict[str, Any]] = []
    seen_targets: set[str] = set()

    try:
        crawl = await run_crawler(ctx.session, ctx.base)
    except Exception as exc:  # noqa: BLE001
        logger.warning("crawler failed during xss_fuzz: %s", exc)
        return findings

    templates = _candidates(crawl)
    if not templates:
        return findings

    detect = _make_detect_fn()
    base = ctx.base.rstrip("/")

    for path_template in templates:
        url_template = (
            path_template
            if path_template.startswith(("http://", "https://"))
            else base + path_template
        )
        target_id = url_template.split("?", 1)[0].rstrip("/")
        if target_id in seen_targets:
            continue

        try:
            results = await asyncio.wait_for(
                fuzz(
                    ctx.session,
                    url_template,
                    XSS_PAYLOADS,
                    detect,
                    concurrency=6,
                ),
                timeout=12,
            )
        except asyncio.TimeoutError:
            logger.debug("xss_fuzz timed out on %s", target_id)
            continue
        except Exception as exc:  # noqa: BLE001
            logger.debug("fuzz error on %s: %s", target_id, exc)
            continue

        hits = [r for r in results if r.get("hit")]
        if hits:
            seen_targets.add(target_id)
            best = hits[0]
            findings.append(
                _emit(target_id, best["payload"], best.get("body_snippet", "")[:200])
            )

    return findings
