"""CAPTCHA token replay probe (broken anti-automation).

Tests whether a server enforces single-use CAPTCHA tokens. A correctly
implemented anti-automation challenge invalidates a captcha id+answer
pair after a single successful submission. Servers that accept the same
pair repeatedly let attackers automate spam, brute-force, or feedback
flooding behind a UI that looks gated.

Three-step shape:

1. GET a captcha service path (e.g. /rest/image-captcha/, /api/captcha,
   /captcha) and extract `captchaId` plus `answer` (or `solution`,
   `result`) from the JSON body.
2. POST a benign feedback/comment with that id+answer pair. Expect 201.
3. POST a SECOND, different feedback/comment using the SAME id+answer.
   If the server again returns 201, the captcha is replayable.

Detection signal: two consecutive 201s with identical captcha credentials.
Non-destructive in spirit: payloads are benign feedback rows. Tagged
`destructive-low` because each successful submission persists a new row.
"""
from __future__ import annotations

import json
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

# Captcha service candidates. Juice Shop uses /rest/image-captcha/.
CAPTCHA_PATHS: tuple[str, ...] = (
    "/rest/image-captcha/",
    "/api/captcha",
    "/captcha",
)

# Submission endpoints that gate behind the captcha.
SUBMIT_PATHS: tuple[str, ...] = (
    "/api/Feedbacks",
    "/api/feedbacks",
    "/api/Feedbacks/",
    "/comments",
)

# JSON keys we accept for the captcha id and the expected answer.
_ID_KEYS = ("captchaId", "captchaID", "id")
_ANSWER_KEYS = ("answer", "solution", "result", "captcha")


def _extract_captcha(body: str) -> tuple[Any, Any] | None:
    """Pull (captcha_id, answer) out of a JSON body. None if absent."""
    try:
        data = json.loads(body)
    except (ValueError, TypeError):
        return None
    if not isinstance(data, dict):
        return None
    cid = next((data[k] for k in _ID_KEYS if k in data), None)
    ans = next((data[k] for k in _ANSWER_KEYS if k in data), None)
    if cid is None or ans is None:
        return None
    return cid, ans


def _submission_payload(captcha_id: Any, answer: Any, comment: str) -> dict[str, Any]:
    """Benign feedback row carrying the captcha credentials."""
    return {
        "captchaId": captcha_id,
        "captcha": answer,
        "comment": comment,
        "rating": 3,
    }


def _emit(target: str, captcha_id: Any) -> dict[str, Any]:
    return {
        "title": "CAPTCHA token replay accepted (broken anti-automation)",
        "severity": "medium",
        "category": "business_logic",
        "target": target,
        "evidence": (
            f"Two consecutive 201 responses on {target} using captchaId="
            f"{captcha_id!r}. The server does not invalidate captcha "
            "credentials after first use."
        ),
        "bug_class": "business_logic",
        "owasp": "A04:2021",
        "remediation": (
            "Mark each captcha id as consumed after the first successful "
            "verification. Reject submissions that reuse a previously seen "
            "id, regardless of whether the answer is correct."
        ),
    }


@registry.probe(
    name="web.captcha_replay",
    bug_class="business_logic",
    severity_max="medium",
    owasp="A04:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "destructive-low", "captcha"),
    requires_auth=False,
)
async def probe_captcha_replay(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Three-step probe: fetch captcha, submit, replay submit."""
    base = ctx.base
    findings: list[dict[str, Any]] = []

    # Step 1: locate a captcha service and extract credentials.
    captcha_id: Any = None
    answer: Any = None
    for path in CAPTCHA_PATHS:
        url = base + path
        status, _, body = await http_get(ctx.session, url)
        if status != 200 or not body:
            continue
        extracted = _extract_captcha(body)
        if extracted is not None:
            captcha_id, answer = extracted
            break

    if captcha_id is None or answer is None:
        # No captcha service present; nothing to test.
        return findings

    # Steps 2 + 3: submit, then re-submit with same credentials.
    for submit_path in SUBMIT_PATHS:
        submit_url = base + submit_path

        first_payload = _submission_payload(
            captcha_id, answer, "ptai-canary first submission"
        )
        first_status, _, _ = await http_post_json(
            ctx.session, submit_url, first_payload
        )
        if first_status != 201:
            continue

        second_payload = _submission_payload(
            captcha_id, answer, "ptai-canary replay submission"
        )
        second_status, _, _ = await http_post_json(
            ctx.session, submit_url, second_payload
        )
        if second_status == 201:
            findings.append(_emit(submit_url, captcha_id))
            # One confirmed replay is enough; stop hammering submit endpoints.
            break

    return findings
