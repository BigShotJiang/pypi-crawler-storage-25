"""Reflected XSS probe.

Walks common search/lookup endpoints and injects a canary script payload
either as a path segment (for path-style reflectors like `/track-order/<id>`)
or as a `q=` query parameter (for traditional search endpoints). Also fires
two header-based reflection probes against `/`: `X-Forwarded-For` and
`Referer`. A finding emits when the response body contains the literal
payload string unencoded (no HTML-entity escaping).

Severity ladder:

- query reflection: medium (classic search-box XSS)
- path reflection: high (often pivots into auth-bypass or routing bugs)
- header reflection: medium (XFF/Referer reflected into HTML)

Probe is read-only and runs unauthenticated.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import quote

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

PAYLOAD = "<script>alert('ptai')</script>"
PAYLOAD_NEEDLE = "<script>alert('ptai')"
ENCODED_NEEDLE = "&lt;script&gt;"

# (path, mode) where mode is "query" or "path".
DEFAULT_TARGETS: tuple[tuple[str, str], ...] = (
    ("/search", "query"),
    ("/q", "query"),
    ("/lookup", "query"),
    ("/api/search", "query"),
    ("/products/search", "query"),
    ("/api/v1/search", "query"),
    ("/rest/track-order/", "path"),
    ("/track-order/", "path"),
)

HEADER_TARGETS: tuple[tuple[str, str], ...] = (
    ("X-Forwarded-For", PAYLOAD),
    ("Referer", "javascript:alert(1)"),
)


def _body_reflects_payload(body: str, needle: str) -> bool:
    """True when the unencoded payload survives into the response body.

    The check is deliberately strict: the literal `<script>alert('ptai')`
    (or the configured needle) must be present, and the encoded form must
    not be the only occurrence. Servers that escape the input (turning
    `<` into `&lt;`) won't match.
    """
    # If the body contains ONLY the encoded form, it isn't exploitable.
    # The needle check requires the raw `<` form.
    return needle in body


def _emit(
    target: str, severity: str, variant: str, evidence: str
) -> dict[str, Any]:
    return {
        "title": f"Reflected XSS ({variant})",
        "severity": severity,
        "category": "injection",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": "xss_reflected",
        "remediation": (
            "Context-aware output encoding. Encode user input before "
            "rendering into HTML, attributes, JS, or URL contexts. Use "
            "a templating engine with auto-escaping by default."
        ),
    }


@registry.probe(
    name="web.reflected_xss",
    bug_class="xss_reflected",
    severity_max="high",
    owasp="A03:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_reflected_xss(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk path/query targets and header reflectors, emit on raw payload echo."""
    base = ctx.base
    findings: list[dict[str, Any]] = []
    encoded_payload = quote(PAYLOAD, safe="")

    for path, mode in DEFAULT_TARGETS:
        if mode == "query":
            url = f"{base}{path}?q={encoded_payload}"
            severity = "medium"
            variant = "query reflection"
        else:
            url = f"{base}{path}{encoded_payload}"
            severity = "high"
            variant = "path reflection"

        status, _, body = await http_get(ctx.session, url)
        if status != 200:
            continue
        if _body_reflects_payload(body, PAYLOAD_NEEDLE):
            findings.append(_emit(url, severity, variant, body))

    # Header-based reflection probes against the root.
    root_url = f"{base}/"
    for header_name, header_value in HEADER_TARGETS:
        status, _, body = await http_get(
            ctx.session, root_url, headers={header_name: header_value}
        )
        if status != 200:
            continue
        # For the Referer javascript: variant, look for that literal too.
        needle = (
            PAYLOAD_NEEDLE
            if header_value == PAYLOAD
            else "javascript:alert(1)"
        )
        if needle in body and ENCODED_NEEDLE not in body[: body.find(needle) + 1]:
            findings.append(
                _emit(
                    root_url,
                    "medium",
                    f"header reflection ({header_name})",
                    body,
                )
            )

    return findings
