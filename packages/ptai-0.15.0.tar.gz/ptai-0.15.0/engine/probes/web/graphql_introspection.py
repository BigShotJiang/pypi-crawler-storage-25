"""GraphQL introspection and field-suggestion probe.

Three failure modes worth catching, on a single discovered endpoint:

1. Introspection enabled in production. The standard `__schema` query
   returns the full type graph, exposing every internal field name,
   mutation, and argument shape. Medium severity, info disclosure.

2. Field suggestions enabled. Even with introspection off, the server
   helpfully responds to a query with a non-existent field by saying
   "Did you mean ...?" and naming real schema fields. Low severity,
   slow but reliable schema-leak primitive.

3. Mutation surface enumeration. Posting `mutation{login}` with no args
   triggers an error like
   `Field "login" argument "username" of type "String!" is required` ,
   which names every required argument. Low severity, narrows attack
   surface for credential stuffing or business-logic abuse.

Discovery walks a small candidate-path list (`/graphql`, `/api/graphql`,
etc.). Each discovered endpoint runs all three checks. Probe is
non-destructive (read-only POST of canary queries), runs unauthenticated.
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

# Conventional GraphQL endpoint paths. Most frameworks default to one of these.
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/graphql",
    "/api/graphql",
    "/v1/graphql",
    "/api/v1/graphql",
    "/query",
)

# Canary field name unlikely to collide with any real schema field.
_INVALID_FIELD = "XYZ_invalid_field_canary"

_INTROSPECTION_QUERY = {"query": "query{__schema{types{name}}}"}
_SUGGESTION_QUERY = {"query": "query{" + _INVALID_FIELD + "}"}
_MUTATION_QUERY = {"query": "mutation{login}"}


def _is_graphql_endpoint(status: int) -> bool:
    """GraphQL servers usually answer GET with 200 (GraphiQL) or 400 (no query)."""
    return status in (200, 400, 405)


def _emit_introspection(target: str, body: str) -> dict[str, Any]:
    return {
        "title": "GraphQL introspection enabled in production",
        "severity": "medium",
        "category": "information_disclosure",
        "target": target,
        "evidence": body[:512],
        "bug_class": "exposed_dev",
        "owasp": "A05:2021",
        "remediation": (
            "Disable GraphQL introspection in production. Most servers "
            "expose a flag (Apollo: introspection: false; graphql-ruby: "
            "disable_introspection_entry_points). Gate behind staff auth "
            "if you need it for internal tooling."
        ),
    }


def _emit_suggestions(target: str, body: str) -> dict[str, Any]:
    return {
        "title": "GraphQL field suggestions leak schema names",
        "severity": "low",
        "category": "information_disclosure",
        "target": target,
        "evidence": body[:512],
        "bug_class": "exposed_dev",
        "owasp": "A05:2021",
        "remediation": (
            "Disable did-you-mean field suggestions in production. "
            "Apollo: set didYouMean to false or use a custom error "
            "formatter. graphql-js: strip suggestion text from errors "
            "in the response pipeline."
        ),
    }


def _emit_mutation_surface(target: str, body: str) -> dict[str, Any]:
    return {
        "title": "GraphQL mutation surface disclosed via error messages",
        "severity": "low",
        "category": "information_disclosure",
        "target": target,
        "evidence": body[:512],
        "bug_class": "exposed_dev",
        "owasp": "A05:2021",
        "remediation": (
            "Return generic validation errors for mutations. Avoid naming "
            "required arguments and types in error responses; an attacker "
            "uses these to map your authentication and write surface "
            "without ever needing introspection."
        ),
    }


async def _discover(ctx: ProbeContext, candidates: tuple[str, ...]) -> list[str]:
    base = ctx.base
    found: list[str] = []
    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path
        status, _, _ = await http_get(ctx.session, url)
        if _is_graphql_endpoint(status):
            found.append(url)
    return found


async def _check_introspection(ctx: ProbeContext, url: str) -> dict[str, Any] | None:
    status, _, body = await http_post_json(ctx.session, url, _INTROSPECTION_QUERY)
    if status == 200 and "__schema" in body:
        return _emit_introspection(url, body)
    return None


async def _check_suggestions(ctx: ProbeContext, url: str) -> dict[str, Any] | None:
    _, _, body = await http_post_json(ctx.session, url, _SUGGESTION_QUERY)
    if "Did you mean" in body:
        return _emit_suggestions(url, body)
    return None


async def _check_mutation_surface(
    ctx: ProbeContext, url: str
) -> dict[str, Any] | None:
    _, _, body = await http_post_json(ctx.session, url, _MUTATION_QUERY)
    # graphql-js: `Field "login" argument "username" of type "String!" is required`
    # apollo:    `Field "login" argument "input" of type "LoginInput!" is required`
    if "argument" in body and "login" in body and "required" in body:
        return _emit_mutation_surface(url, body)
    return None


@registry.probe(
    name="web.graphql_introspection",
    bug_class="exposed_dev",
    severity_max="medium",
    owasp="A05:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "high-roi", "graphql"),
    requires_auth=False,
)
async def probe_graphql_introspection(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Discover GraphQL endpoints, then probe introspection + suggestions + mutation."""
    candidates = ctx.candidate_endpoints or DEFAULT_CANDIDATES
    endpoints = await _discover(ctx, candidates)
    findings: list[dict[str, Any]] = []
    for url in endpoints:
        intro = await _check_introspection(ctx, url)
        if intro is not None:
            findings.append(intro)
        suggest = await _check_suggestions(ctx, url)
        if suggest is not None:
            findings.append(suggest)
        mutation = await _check_mutation_surface(ctx, url)
        if mutation is not None:
            findings.append(mutation)
    return findings
