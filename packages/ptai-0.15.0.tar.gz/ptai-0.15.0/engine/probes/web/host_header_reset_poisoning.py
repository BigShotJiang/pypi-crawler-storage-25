"""Host header password-reset poisoning probe.

Direct ATO surface: a reset-link generator that builds the link from a
client-controlled Host header. Attacker triggers a reset for the victim,
the server emails the victim a link pointing to the attacker's host, the
attacker captures the token when the victim clicks.

The probe walks a small list of candidate reset endpoints. For each that
accepts a benign POST, it replays the request with a series of header
override variants (Host, X-Forwarded-Host, X-Forwarded-Server, X-Host,
Forwarded). Detection is response-side: if the server reflects the
attacker host in the body, a redirect Location, or a follow-up status
endpoint, the link generator is poisoned.

Non-destructive in the sense that we POST a benign email; the side
effect is a reset email being sent. We use a probe-controlled victim
address to keep the blast radius bounded.
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_post_json

ATTACKER_HOST = "ptai-host-canary.example"
PROBE_VICTIM_EMAIL = "ptai-canary@ptai-host-canary.example"

# Endpoints commonly used to start a password reset across modern SPAs.
DEFAULT_RESET_ENDPOINTS: tuple[str, ...] = (
    "/forgot-password",
    "/api/auth/forgot-password",
    "/api/auth/forgot",
    "/password/reset",
    "/rest/user/reset-password",
    "/api/users/forgot",
    "/api/users/forgot-password",
    "/reset-password",
    "/api/password/forgot",
)

# Header-override variants. Each entry is a (variant_name, headers) tuple.
# The variants cover both clean overrides and the dual-Host CRLF style.
HEADER_VARIANTS: tuple[tuple[str, dict[str, str]], ...] = (
    ("host_override", {"Host": ATTACKER_HOST}),
    ("x_forwarded_host", {"X-Forwarded-Host": ATTACKER_HOST}),
    ("x_forwarded_server", {"X-Forwarded-Server": ATTACKER_HOST}),
    ("x_host", {"X-Host": ATTACKER_HOST}),
    ("forwarded_header", {"Forwarded": f"host={ATTACKER_HOST}"}),
    (
        "dual_host",
        {"Host": ATTACKER_HOST, "X-Forwarded-Host": ATTACKER_HOST},
    ),
)


def _looks_like_full_url_poisoning(body: str, headers: dict[str, str]) -> bool:
    """Return True if attacker host shows up inside a full reset URL."""
    haystack = body or ""
    location = headers.get("Location", "") if headers else ""
    candidates = (
        f"http://{ATTACKER_HOST}",
        f"https://{ATTACKER_HOST}",
        f"//{ATTACKER_HOST}/",
    )
    return any(c in haystack or c in location for c in candidates)


def _body_reflects_attacker(body: str, headers: dict[str, str]) -> bool:
    """Return True if attacker host is anywhere in body or response headers."""
    if body and ATTACKER_HOST in body:
        return True
    if not headers:
        return False
    return any(
        isinstance(value, str) and ATTACKER_HOST in value
        for value in headers.values()
    )


def _emit(
    target: str, variant: str, severity: str, detail: str, evidence: str
) -> dict[str, Any]:
    return {
        "title": f"Host header password-reset poisoning ({variant}): {detail}",
        "severity": severity,
        "category": "authentication",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": "auth_bypass",
        "remediation": (
            "Build absolute URLs from a server-side allowlist of canonical "
            "hostnames. Do not trust Host, X-Forwarded-Host, X-Forwarded-Server, "
            "X-Host, or Forwarded headers when generating password-reset links."
        ),
    }


def _classify(status: int, headers: dict[str, str], body: str) -> tuple[str, str] | None:
    """Return (severity, detail) if the response shows poisoning, else None."""
    if status == 0:
        return None
    # 2xx/3xx accepted requests are the only ones that could leak a reset link.
    if not (200 <= status < 400):
        return None
    if _looks_like_full_url_poisoning(body, headers):
        return "critical", "Reset link points to attacker-controlled host"
    if _body_reflects_attacker(body, headers):
        return "high", "Attacker host reflected in reset response"
    return None


@registry.probe(
    name="web.host_header_reset_poisoning",
    bug_class="auth_bypass",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_host_header_reset_poisoning(
    ctx: ProbeContext,
) -> list[dict[str, Any]]:
    """Walk reset endpoints, replay with header overrides, detect poisoning."""
    candidates = ctx.endpoint_hints or DEFAULT_RESET_ENDPOINTS
    base = ctx.base
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    payload = {"email": PROBE_VICTIM_EMAIL}

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        for variant, headers in HEADER_VARIANTS:
            status, resp_headers, body = await http_post_json(
                ctx.session, url, payload, headers=headers
            )
            classified = _classify(status, resp_headers, body)
            if classified is None:
                continue
            severity, detail = classified
            key = (url, severity)
            if key in seen:
                continue
            seen.add(key)
            findings.append(
                _emit(
                    url,
                    variant,
                    severity,
                    detail,
                    f"Variant {variant!r} status={status} body_excerpt={body[:200]!r}",
                )
            )
            # Critical hit on this URL: stop trying further variants.
            if severity == "critical":
                break

    return findings
