"""Cookie `__Host-` / `__Secure-` prefix bypass probe.

Modern browsers enforce `__Host-` and `__Secure-` cookie prefixes at the
client. Server-side parsers do not always agree on what counts as the
prefix, especially around UTF-8 whitespace and zero-width characters.

PortSwigger Top-10 Web Hacking Techniques 2025 documents bypasses where
a cookie like `__Host- sessionid` (with U+2000 between dash and name)
gets normalised by some parsers back to `__Host-sessionid`, letting an
attacker overwrite a privileged cookie from a sibling subdomain.

The probe:

1. GETs the base URL, captures Set-Cookie headers.
2. Filters to cookies starting with `__Host-` or `__Secure-`.
3. For each, replays the request with manipulated cookie names that
   should NOT match the original (en-quad, zero-width-space, no-break
   space, leading whitespace, tab).
4. Compares response body length against a control request that uses a
   purely random prefix. If the manipulated request matches the original
   shape closely while the control request does not, the parser is
   normalising the prefix away.
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

PREFIXES: tuple[str, ...] = ("__Host-", "__Secure-")

# Whitespace and zero-width insertions that some parsers normalise.
# Each entry is (variant_name, separator_inserted_after_prefix).
WHITESPACE_VARIANTS: tuple[tuple[str, str], ...] = (
    ("en_quad", " "),
    ("zero_width_space", "​"),
    ("no_break_space", " "),
    ("tab", "\t"),
)

# Variants that prepend whitespace to the full cookie name.
LEADING_VARIANTS: tuple[tuple[str, str], ...] = (
    ("leading_space", " "),
    ("leading_tab", "\t"),
)

CONTROL_PREFIX = "ptai-noprefix-"


def _split_cookie_name(set_cookie: str) -> str | None:
    """Pull the cookie name from a Set-Cookie header value."""
    if not set_cookie or "=" not in set_cookie:
        return None
    name = set_cookie.split("=", 1)[0].strip()
    return name or None


def _set_cookie_lines(headers: dict[str, str]) -> list[str]:
    """Return Set-Cookie values. aiohttp collapses repeats into one comma-split.

    Splitting on commas is unsafe for date-bearing cookies (Expires=Wed, ...).
    We handle the common case of one or two cookies plus the simple comma case.
    """
    raw = headers.get("Set-Cookie") or headers.get("set-cookie")
    if not raw:
        return []
    return [raw]


def _has_prefix(name: str) -> bool:
    return any(name.startswith(p) for p in PREFIXES)


def _build_manipulated_names(original: str) -> list[tuple[str, str]]:
    """Return (variant_name, manipulated_cookie_name) pairs for a prefixed cookie.

    Splits the original at the prefix boundary and inserts the variant
    separator. For leading variants the separator is prepended to the
    whole name.
    """
    out: list[tuple[str, str]] = []
    for prefix in PREFIXES:
        if not original.startswith(prefix):
            continue
        rest = original[len(prefix) :]
        for variant, sep in WHITESPACE_VARIANTS:
            out.append((variant, f"{prefix}{sep}{rest}"))
        for variant, sep in LEADING_VARIANTS:
            out.append((variant, f"{sep}{original}"))
        break
    return out


def _control_name(original: str) -> str:
    """Return a control cookie name that strips the prefix entirely."""
    for prefix in PREFIXES:
        if original.startswith(prefix):
            return CONTROL_PREFIX + original[len(prefix) :]
    return CONTROL_PREFIX + original


def _shape_close(a: int, b: int, tolerance: float = 0.1) -> bool:
    """Return True when two body sizes are within `tolerance` of each other."""
    if a == 0 and b == 0:
        return True
    larger = max(a, b)
    if larger == 0:
        return False
    return abs(a - b) / larger <= tolerance


def _emit(target: str, cookie_name: str, variant: str, evidence: str) -> dict[str, Any]:
    return {
        "title": (
            f"Cookie prefix bypass on {cookie_name!r} via {variant}"
        ),
        "severity": "high",
        "category": "authentication",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": "auth_bypass",
        "remediation": (
            "Reject cookie names that contain whitespace, zero-width, or "
            "non-ASCII characters. Match `__Host-` / `__Secure-` prefixes "
            "byte-exactly before treating a cookie as privileged."
        ),
    }


@registry.probe(
    name="web.cookie_prefix_bypass",
    bug_class="auth_bypass",
    severity_max="high",
    owasp="A07:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_cookie_prefix_bypass(
    ctx: ProbeContext,
) -> list[dict[str, Any]]:
    """Probe `__Host-` / `__Secure-` parser bypasses via name mutations."""
    base = ctx.base

    # Step 1: discover prefixed cookies.
    status, headers, baseline_body = await http_get(ctx.session, base + "/")
    if status == 0:
        return []

    cookie_names: list[str] = []
    for line in _set_cookie_lines(headers):
        name = _split_cookie_name(line)
        if name and _has_prefix(name):
            cookie_names.append(name)

    if not cookie_names:
        return []

    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    baseline_size = len(baseline_body)

    for cookie_name in cookie_names:
        # Control: random-prefix cookie name. Server should treat as unknown.
        control = _control_name(cookie_name)
        ctrl_status, _, ctrl_body = await http_get(
            ctx.session,
            base + "/",
            headers={"Cookie": f"{control}=ptai-canary"},
        )
        if ctrl_status == 0:
            continue
        ctrl_size = len(ctrl_body)

        for variant, mutated in _build_manipulated_names(cookie_name):
            m_status, _, m_body = await http_get(
                ctx.session,
                base + "/",
                headers={"Cookie": f"{mutated}=ptai-canary"},
            )
            if m_status == 0:
                continue
            m_size = len(m_body)

            # Bypass signal: manipulated request looks like the baseline-
            # authenticated shape (close to baseline_size) AND clearly
            # diverges from the control shape.
            if _shape_close(m_size, baseline_size) and not _shape_close(
                m_size, ctrl_size
            ):
                key = (cookie_name, variant)
                if key in seen:
                    continue
                seen.add(key)
                findings.append(
                    _emit(
                        base + "/",
                        cookie_name,
                        variant,
                        (
                            f"baseline={baseline_size} control={ctrl_size} "
                            f"mutated={m_size} mutated_name={mutated!r}"
                        ),
                    )
                )

    return findings
