"""CORS origin-reflection probe.

The probe sends an attacker-controlled Origin header on a credentialed
endpoint. Two failure modes count:

1. `Access-Control-Allow-Origin: <attacker>` reflected back. High severity:
   any attacker page can read responses unless credentials are blocked.

2. `Access-Control-Allow-Origin: <attacker>` PLUS
   `Access-Control-Allow-Credentials: true`. Critical severity: attacker
   can read authenticated responses with the user's cookies/tokens.

Plus a third variant: `Access-Control-Allow-Origin: null` acceptance,
exploitable from sandboxed iframes.

Probe is non-destructive (read-only GET) and runs unauthenticated. It
walks a candidate-endpoint list (defaulting to common API roots) so it
fires on more than one URL per engagement.
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

ATTACKER_ORIGIN = "https://ptai-cors-canary.example"

# Common credentialed endpoints across modern SPAs.
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/",
    "/api/",
    "/api/users",
    "/api/me",
    "/api/profile",
    "/api/Users",
    "/rest/user/whoami",
    "/api/account",
    "/me",
    "/whoami",
    "/graphql",
    "/api/v1/users",
    "/api/v2/users",
)


def _classify(headers: dict[str, str], reflected: str) -> tuple[str, str] | None:
    """Return (severity, detail) if CORS misconfig present, else None."""
    aco = headers.get("Access-Control-Allow-Origin", "")
    acc = headers.get("Access-Control-Allow-Credentials", "").lower()

    if aco == reflected and acc == "true":
        return "critical", f"Origin reflected with credentials: {aco}"
    if aco == reflected:
        return "high", f"Origin reflected without credentials gate: {aco}"
    if aco == "null" and acc == "true":
        return "critical", "Access-Control-Allow-Origin: null with credentials"
    if aco == "null":
        return "high", "Access-Control-Allow-Origin: null"
    return None


def _emit(target: str, severity: str, detail: str, variant: str) -> dict[str, Any]:
    return {
        "title": f"CORS misconfiguration ({variant}): {detail}",
        "severity": severity,
        "category": "misconfiguration",
        "target": target,
        "evidence": detail,
        "bug_class": "cors_misconfig",
        "remediation": (
            "Reject untrusted Origin values. Use an explicit allowlist or "
            "drop credentials from cross-origin responses entirely."
        ),
    }


@registry.probe(
    name="web.cors_reflection",
    bug_class="cors_misconfig",
    severity_max="critical",
    owasp="A05:2021",
    runtime_budget_s=4.0,
    tags=("fast", "anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_cors_reflection(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Two-step CORS probe: attacker Origin then null Origin."""
    candidates = ctx.candidate_endpoints or DEFAULT_CANDIDATES
    base = ctx.base
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        # Attempt 1: attacker-controlled Origin
        status, headers, _ = await http_get(
            ctx.session, url, headers={"Origin": ATTACKER_ORIGIN}
        )
        if status == 200:
            classified = _classify(headers, ATTACKER_ORIGIN)
            if classified is not None:
                severity, detail = classified
                key = (url, severity)
                if key not in seen:
                    seen.add(key)
                    findings.append(_emit(url, severity, detail, "origin_reflection"))
                    continue  # don't re-test this URL with null

        # Attempt 2: null Origin (exploitable from sandboxed iframes)
        status2, headers2, _ = await http_get(
            ctx.session, url, headers={"Origin": "null"}
        )
        if status2 == 200:
            classified2 = _classify(headers2, "null")
            if classified2 is not None:
                severity, detail = classified2
                key = (url, severity)
                if key not in seen:
                    seen.add(key)
                    findings.append(_emit(url, severity, detail, "null_origin"))

    return findings
