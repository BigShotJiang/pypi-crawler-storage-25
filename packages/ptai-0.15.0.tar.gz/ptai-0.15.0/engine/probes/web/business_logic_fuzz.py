"""Business-logic boundary fuzz probe.

Most web apps validate types but forget semantic boundaries. A
registration form that accepts blank email and blank password, a basket
endpoint that accepts negative quantities, a feedback form that accepts
zero stars, a "deluxe membership" upgrade with no payment proof: each
of these is a server-side trust failure dressed up as a happy-path
response.

Juice Shop's "Improper Input Validation" challenge family is the
canonical training set for this class. The probe runs a hand-curated
list of known boundary cases and checks the server SHOULD have rejected
each one. Per-check predicates live next to the check so adding a new
case is one tuple, not new wiring.

The probe is destructive-low: it creates accounts and posts feedback,
but does nothing irreversible. Random hex per probe run keeps repeated
runs from colliding on uniqueness constraints.
"""
from __future__ import annotations

import json
import secrets
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_post_json

# Predicate signatures. Single-shot checks evaluate one (status, body).
# Twice-shot checks compare two (status, body) responses to the same body.
SinglePredicate = Callable[[int, str], bool]
DoublePredicate = Callable[[dict[str, Any], dict[str, Any]], bool]


@dataclass(frozen=True)
class Check:
    """One business-logic boundary case.

    `body_fn` lets the check randomise per-run inputs (emails, ids).
    `twice` repeats the same body twice and uses `hit_when_double`
    instead of `hit_when`.
    """

    name: str
    method: str
    path: str
    body_fn: Callable[[str], dict[str, Any]]
    severity: str
    title: str
    remediation: str
    hit_when: SinglePredicate | None = None
    hit_when_double: DoublePredicate | None = None
    twice: bool = False


def _empty_registration_body(_rand: str) -> dict[str, Any]:
    return {"email": "", "password": ""}


def _negative_quantity_body(_rand: str) -> dict[str, Any]:
    return {"BasketId": 1, "ProductId": 1, "quantity": -100}


def _zero_rating_body(_rand: str) -> dict[str, Any]:
    return {
        "comment": "ptai-rating",
        "rating": 0,
        "captchaId": 1,
        "captcha": "1",
    }


def _deluxe_no_payment_body(_rand: str) -> dict[str, Any]:
    return {"paymentMode": "free"}


def _repetitive_registration_body(rand: str) -> dict[str, Any]:
    return {
        "email": f"ptai-dup-{rand}@example.com",
        "password": "Test-1234!Aa",
    }


def _expired_coupon_body(_rand: str) -> dict[str, Any]:
    # Juice Shop ships a known-expired coupon string for challenge #69.
    return {"couponCode": "n1aD4iIWJTAYg5o"}


def _negative_amount_body(_rand: str) -> dict[str, Any]:
    return {"BasketId": 1, "ProductId": 1, "quantity": 1, "amount": -50}


def _huge_quantity_body(_rand: str) -> dict[str, Any]:
    return {"BasketId": 1, "ProductId": 1, "quantity": 10**9}


CHECKS: tuple[Check, ...] = (
    Check(
        name="empty_registration",
        method="POST",
        path="/api/Users/",
        body_fn=_empty_registration_body,
        hit_when=lambda status, body: status in (200, 201),
        severity="high",
        title="Empty user registration accepted",
        remediation=(
            "Reject empty email and password at the registration endpoint. "
            "Enforce non-empty, format-validated, length-checked credentials "
            "before persisting a user record."
        ),
    ),
    Check(
        name="negative_quantity",
        method="POST",
        path="/api/BasketItems",
        body_fn=_negative_quantity_body,
        hit_when=lambda status, body: (
            status in (200, 201) and "quantity" in (body or "").lower()
        ),
        severity="high",
        title="Negative quantity accepted on basket item",
        remediation=(
            "Validate that BasketItem quantities are positive integers on "
            "the server. Negative quantities can refund money or invert "
            "totals."
        ),
    ),
    Check(
        name="out_of_range_rating",
        method="POST",
        path="/api/Feedbacks/",
        body_fn=_zero_rating_body,
        hit_when=lambda status, body: status in (200, 201),
        severity="medium",
        title="Out-of-range rating (zero stars) accepted",
        remediation=(
            "Constrain feedback rating to the documented 1..5 range on the "
            "server. UI-only validation is not enough."
        ),
    ),
    Check(
        name="deluxe_membership_no_payment",
        method="POST",
        path="/rest/deluxe-membership",
        body_fn=_deluxe_no_payment_body,
        hit_when=lambda status, body: (
            status == 200 and "deluxe" in (body or "").lower()
        ),
        severity="high",
        title="Deluxe membership upgrade without payment",
        remediation=(
            "Require a verified payment intent before upgrading a user to a "
            "paid tier. Reject upgrade requests without proof of charge."
        ),
    ),
    Check(
        name="repetitive_registration",
        method="POST",
        path="/api/Users/",
        body_fn=_repetitive_registration_body,
        twice=True,
        hit_when_double=lambda r1, r2: (
            r1.get("status") in (200, 201) and r2.get("status") in (200, 201)
        ),
        severity="medium",
        title="Repetitive registration: same email accepted twice",
        remediation=(
            "Enforce a unique constraint on the user email column and have "
            "the registration endpoint return 409 on duplicate. Without "
            "this, account-takeover races become trivial."
        ),
    ),
    Check(
        name="expired_coupon",
        method="POST",
        path="/rest/basket/1/coupon/n1aD4iIWJTAYg5o",
        body_fn=_expired_coupon_body,
        hit_when=lambda status, body: status == 200,
        severity="medium",
        title="Expired coupon accepted",
        remediation=(
            "Validate coupon expiry server-side before applying any "
            "discount. Reject expired coupons with 410 or 422."
        ),
    ),
    Check(
        name="negative_amount",
        method="POST",
        path="/api/BasketItems",
        body_fn=_negative_amount_body,
        hit_when=lambda status, body: (
            status in (200, 201) and "amount" in (body or "").lower()
        ),
        severity="high",
        title="Negative amount accepted on basket item",
        remediation=(
            "Reject negative monetary fields on basket and order endpoints. "
            "Use unsigned types and explicit lower bounds."
        ),
    ),
    Check(
        name="huge_quantity",
        method="POST",
        path="/api/BasketItems",
        body_fn=_huge_quantity_body,
        hit_when=lambda status, body: status in (200, 201),
        severity="medium",
        title="Unbounded quantity accepted on basket item",
        remediation=(
            "Cap basket quantities at a sane upper bound (e.g. 1000) on "
            "the server to prevent integer overflow and resource abuse."
        ),
    ),
)


def _emit(check: Check, url: str, evidence: str) -> dict[str, Any]:
    return {
        "title": check.title,
        "severity": check.severity,
        "category": "business_logic",
        "target": url,
        "evidence": evidence[:512],
        "bug_class": "business_logic",
        "remediation": check.remediation,
        "check": check.name,
    }


def _safe_status_body(parsed: tuple[int, dict[str, str], str]) -> dict[str, Any]:
    status, _, body = parsed
    return {"status": status, "body": body}


@registry.probe(
    name="web.business_logic_fuzz",
    bug_class="business_logic",
    severity_max="high",
    owasp="A04:2021",
    runtime_budget_s=20.0,
    tags=("anonymous", "high-roi", "destructive-low"),
    requires_auth=False,
)
async def probe_business_logic_fuzz(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Run a curated list of business-logic boundary cases.

    Each check is independent. Predicates live on the Check tuple, so
    adding a new boundary case is a single dataclass entry, not new
    wiring. Random hex is generated once per probe run so checks that
    use it (repetitive registration) collide with themselves and not
    with prior runs.
    """
    base = ctx.base
    findings: list[dict[str, Any]] = []
    rand = secrets.token_hex(4)

    for check in CHECKS:
        url = base + check.path
        body = check.body_fn(rand)

        try:
            payload = json.dumps(body)
        except (TypeError, ValueError):
            payload = str(body)

        if check.twice:
            r1 = _safe_status_body(
                await http_post_json(ctx.session, url, body)
            )
            r2 = _safe_status_body(
                await http_post_json(ctx.session, url, body)
            )
            predicate = check.hit_when_double
            if predicate is None:
                continue
            if predicate(r1, r2):
                evidence = (
                    f"POST {check.path} body={payload} -> "
                    f"{r1['status']} then {r2['status']}; "
                    "second request should have failed (duplicate)."
                )
                findings.append(_emit(check, url, evidence))
            continue

        status, _, resp_body = await http_post_json(ctx.session, url, body)
        predicate = check.hit_when
        if predicate is None:
            continue
        if predicate(status, resp_body):
            evidence = (
                f"POST {check.path} body={payload} -> {status}; "
                "boundary case should have been rejected."
            )
            findings.append(_emit(check, url, evidence))

    return findings
