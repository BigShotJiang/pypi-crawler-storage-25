"""Authenticated IDOR probe on Basket/Order/Memory/Card/Address objects.

The unauthenticated sibling (`web.idor_sequential`) only catches servers
that hand back resources without any auth at all. The realistic, modern
break is a logged-in user reading another user's data through an ID
they're allowed to enumerate but not allowed to read. This probe targets
that case: with the captured session token in `ctx.captured_auth`, walk
a small set of REST roots, find the user's own resource id, then probe
the immediate neighbors to see if the server returns somebody else's
record.

Algorithm per object type (Baskets, Orders, Memorys, Cards, Addresses):

  1. With the captured token, GET /{base}/{id} for id in (1, 2, 3).
     The first one whose response is a 200 with a JSON body that
     contains a UserId/userId field is treated as "the user's own".
  2. Probe own_id+1 and own_id-1 with the same token. If either comes
     back 200 with a JSON body whose UserId differs from the own id,
     that's IDOR.

Severity: critical. The principal had a valid session and still read
data belonging to another user. OWASP A01:2021.

The probe is read-only (GETs only) and bails out immediately if no
captured auth is present, so the driver can run it in any registry
sweep without worrying about ordering.
"""
from __future__ import annotations

import json
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_get

# Object types to walk. Each entry is the collection root used when
# building per-id URLs; trailing slash is required so we can safely
# append the numeric id.
_OBJECT_PATHS: tuple[str, ...] = (
    "/api/Baskets/",
    "/api/Orders/",
    "/api/Memorys/",
    "/api/Cards/",
    "/api/Addresses/",
)

# IDs to probe when locating the user's own record.
_DISCOVERY_IDS: tuple[int, ...] = (1, 2, 3)

# Field names that hold the owning user's id in the response body.
_USER_ID_FIELDS: tuple[str, ...] = ("UserId", "userId", "user_id", "ownerId")


def _looks_like_json(body: str, headers: dict[str, str]) -> bool:
    ctype = headers.get("Content-Type", "").lower()
    if "json" in ctype:
        return True
    stripped = body.lstrip()
    return stripped.startswith(("{", "["))


def _parse_json(body: str) -> Any:
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None


def _extract_user_id(payload: Any) -> Any:
    """Pull the owning UserId out of a JSON payload.

    Handles both flat objects and Juice-Shop-style {"data": {...}}
    wrappers. Returns None if no candidate field is present.
    """
    candidates: list[dict[str, Any]] = []
    if isinstance(payload, dict):
        candidates.append(payload)
        data = payload.get("data")
        if isinstance(data, dict):
            candidates.append(data)
        elif isinstance(data, list) and data and isinstance(data[0], dict):
            candidates.append(data[0])
    elif isinstance(payload, list) and payload and isinstance(payload[0], dict):
        candidates.append(payload[0])

    for obj in candidates:
        for field in _USER_ID_FIELDS:
            if field in obj and obj[field] is not None:
                return obj[field]
    return None


def _emit(target: str, evidence: str) -> dict[str, Any]:
    return {
        "title": "Authenticated IDOR: cross-user record returned to valid session",
        "severity": "critical",
        "category": "access_control",
        "target": target,
        "evidence": evidence,
        "bug_class": "idor",
        "owasp": "A01:2021",
        "remediation": (
            "Enforce per-request ownership checks on every REST resource "
            "for authenticated callers. Scope queries to the principal's "
            "user_id rather than relying on ID enumeration controls. "
            "Return 403 (or 404) when the caller does not own the object."
        ),
    }


async def _fetch_user_id(
    session: Any,
    url: str,
    headers: dict[str, str],
) -> tuple[bool, Any, str]:
    """GET url, return (is_json_200, user_id_or_none, body).

    is_json_200 is True only when status == 200 AND body parses as JSON.
    user_id is whatever _extract_user_id returns; may be None even on
    a json hit (object had no UserId field).
    """
    status, hdrs, body = await http_get(session, url, headers=headers)
    if status != 200 or not _looks_like_json(body, hdrs):
        return False, None, body
    payload = _parse_json(body)
    if payload is None:
        return False, None, body
    return True, _extract_user_id(payload), body


async def _probe_object(
    ctx: ProbeContext,
    prefix: str,
    headers: dict[str, str],
) -> list[dict[str, Any]]:
    """Run the authenticated-IDOR check against one collection root."""
    base = ctx.base
    findings: list[dict[str, Any]] = []

    own_id: int | None = None
    own_user_id: Any = None
    for resource_id in _DISCOVERY_IDS:
        url = f"{base}{prefix}{resource_id}"
        ok, user_id, _body = await _fetch_user_id(ctx.session, url, headers)
        if ok and user_id is not None:
            own_id = resource_id
            own_user_id = user_id
            break

    if own_id is None or own_user_id is None:
        return findings

    neighbor_ids = [own_id + 1]
    if own_id - 1 >= 1:
        neighbor_ids.append(own_id - 1)

    for neighbor in neighbor_ids:
        url = f"{base}{prefix}{neighbor}"
        ok, neighbor_user_id, body = await _fetch_user_id(
            ctx.session, url, headers
        )
        if not ok or neighbor_user_id is None:
            continue
        if str(neighbor_user_id) == str(own_user_id):
            continue
        evidence = (
            f"own_id={own_id} owned by UserId={own_user_id}; "
            f"neighbor_id={neighbor} returned UserId={neighbor_user_id}; "
            f"body={body[:256]}"
        )
        findings.append(_emit(url, evidence[:512]))

    return findings


@registry.probe(
    name="web.idor_authenticated",
    bug_class="idor",
    severity_max="critical",
    owasp="A01:2021",
    runtime_budget_s=12.0,
    tags=("authenticated", "high-roi"),
    requires_auth=True,
)
async def probe_idor_authenticated(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk Basket/Order/Memory/Card/Address roots looking for cross-user reads."""
    if ctx.captured_auth is None:
        return []
    headers = auth_headers(ctx.captured_auth)
    if not headers:
        return []

    findings: list[dict[str, Any]] = []
    for prefix in _OBJECT_PATHS:
        findings.extend(await _probe_object(ctx, prefix, headers))
    return findings
