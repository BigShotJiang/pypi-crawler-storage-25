"""HTTP response-header hygiene probe.

One GET against the base URL captures three classes of finding the
fuzzers ignore:

1. Missing security headers (CSP, X-Frame-Options, X-Content-Type-
   Options, Referrer-Policy, Strict-Transport-Security on HTTPS,
   Permissions-Policy). Each missing header lowers defence-in-depth.

2. Insecure session cookie attributes — Set-Cookie that mints a
   session-shaped cookie without HttpOnly, Secure, or SameSite.
   Session-shaped names: ``session``, ``sessionid``, ``JSESSIONID``,
   ``connect.sid``, ``PHPSESSID``, ``ASP.NET_SessionId``.

3. Server / X-Powered-By info disclosure: the framework + version
   shipping in every response, handing fingerprinters a CVE lookup
   for free.

Severity:
  - Missing security headers: low (defence-in-depth)
  - Insecure session cookie: medium (XSS leaps to ATO without
    HttpOnly; CSRF without SameSite)
  - Server / X-Powered-By disclosure: info
"""
from __future__ import annotations

import logging
import re
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_get

logger = logging.getLogger("pentest-ai.probes.web.response_headers")

_SECURITY_HEADERS: tuple[str, ...] = (
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
)

# Set-Cookie names that indicate a session/auth cookie. If the
# response sets one of these without the right flags, it's a finding.
_SESSION_COOKIE_NAMES: tuple[str, ...] = (
    "session=",
    "sessionid=",
    "_session=",
    "JSESSIONID=",
    "connect.sid=",
    "PHPSESSID=",
    "ASP.NET_SessionId=",
    "auth=",
    "token=",
)


def _header_lookup(headers: dict[str, str], name: str) -> str | None:
    """Case-insensitive single-header lookup."""
    lc = name.lower()
    for k, v in headers.items():
        if k.lower() == lc:
            return v
    return None


def _all_set_cookies(headers: dict[str, str]) -> list[str]:
    """Return every Set-Cookie value. aiohttp surfaces multiple Set-Cookie
    headers as a comma-joined single value in dict; split on `, ` followed
    by a name= pattern so we don't break on Expires=Mon, 01 Jan ... commas.
    """
    raw = _header_lookup(headers, "Set-Cookie")
    if not raw:
        return []
    parts = re.split(r", (?=[A-Za-z_][\w\-]*=)", raw)
    return [p.strip() for p in parts if p.strip()]


def _missing_security_headers(
    headers: dict[str, str], is_https: bool,
) -> list[str]:
    missing: list[str] = []
    for h in _SECURITY_HEADERS:
        if _header_lookup(headers, h) is None:
            missing.append(h)
    if is_https and _header_lookup(headers, "Strict-Transport-Security") is None:
        missing.append("Strict-Transport-Security")
    return missing


def _insecure_session_cookies(cookies: list[str]) -> list[tuple[str, list[str]]]:
    """Return [(cookie_name_value, missing_flags)] for any session cookie
    that lacks HttpOnly, Secure, or SameSite.
    """
    out: list[tuple[str, list[str]]] = []
    for c in cookies:
        c_lc = c.lower()
        if not any(name in c for name in _SESSION_COOKIE_NAMES):
            continue
        missing: list[str] = []
        if "httponly" not in c_lc:
            missing.append("HttpOnly")
        if "secure" not in c_lc:
            missing.append("Secure")
        if "samesite=" not in c_lc:
            missing.append("SameSite")
        if missing:
            out.append((c.split(";", 1)[0], missing))
    return out


def _info_disclosure(headers: dict[str, str]) -> list[tuple[str, str]]:
    """Return [(header_name, value)] for Server / X-Powered-By disclosure.

    Bare "nginx"/"apache"/"iis" without a version is conventional and
    not flagged. Versioned or app-named Server headers ARE flagged.
    """
    out: list[tuple[str, str]] = []
    server = _header_lookup(headers, "Server")
    if server and server.lower() not in ("", "nginx", "apache", "iis"):
        out.append(("Server", server))
    xpb = _header_lookup(headers, "X-Powered-By")
    if xpb:
        out.append(("X-Powered-By", xpb))
    return out


def _emit_missing_headers(target: str, missing: list[str]) -> dict[str, Any]:
    return {
        "title": f"Missing security headers ({len(missing)})",
        "severity": "low",
        "category": "security_misconfig",
        "target": target,
        "evidence": "missing: " + ", ".join(missing),
        "bug_class": "security_misconfig",
        "owasp": "A05:2021",
        "remediation": (
            "Add the missing response headers. CSP (Content-Security-"
            "Policy) restricts script/style sources; X-Frame-Options "
            "blocks clickjacking; X-Content-Type-Options: nosniff stops "
            "MIME-sniff attacks; Referrer-Policy controls referrer leaks; "
            "Permissions-Policy gates browser features; Strict-Transport-"
            "Security forces HTTPS for one year (HTTPS only)."
        ),
    }


def _emit_insecure_cookie(
    target: str, name_val: str, missing: list[str],
) -> dict[str, Any]:
    return {
        "title": (
            f"Insecure session cookie: {name_val} missing "
            f"{'/'.join(missing)}"
        ),
        "severity": "medium",
        "category": "security_misconfig",
        "target": target,
        "evidence": f"cookie={name_val}; missing flags: {', '.join(missing)}",
        "bug_class": "insecure_cookie",
        "owasp": "A05:2021",
        "remediation": (
            "Set Secure, HttpOnly, and SameSite=Lax (or Strict) on the "
            "session cookie. HttpOnly blocks JS access (mitigates XSS-"
            "to-session-theft); Secure forbids HTTP transport (mitigates "
            "MITM); SameSite blocks cross-site cookie attach (mitigates "
            "CSRF). For Flask: app.config.update("
            "SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SECURE=True, "
            "SESSION_COOKIE_SAMESITE='Lax')."
        ),
    }


def _emit_info_disclosure(
    target: str, header: str, value: str,
) -> dict[str, Any]:
    return {
        "title": f"Information disclosure header: {header}",
        "severity": "info",
        "category": "info_disclosure",
        "target": target,
        "evidence": f"{header}: {value}",
        "bug_class": "info_disclosure",
        "owasp": "A05:2021",
        "remediation": (
            f"Remove or generalise the {header} header. It hands "
            "fingerprinters the framework + version, enabling targeted "
            "CVE lookups. Most app servers expose a config knob "
            "(e.g. server_tokens off; in nginx; expose_php=Off in "
            "php.ini; remove WSGIServerHeader in mod_wsgi)."
        ),
    }


@registry.probe(
    name="web.response_headers",
    bug_class="security_misconfig",
    severity_max="medium",
    owasp="A05:2021",
    runtime_budget_s=5.0,
    tags=("anonymous", "high-roi", "headers"),
    requires_auth=False,
)
async def probe_response_headers(ctx: ProbeContext) -> list[dict[str, Any]]:
    """One GET on the base URL, parse headers for three finding classes.

    For the insecure-cookie check, we also inspect any raw Set-Cookie
    header the orchestrator captured at login time (passed via
    ``captured_auth["set_cookie_raw"]``). Apps that only mint session
    cookies on successful login (Flask sessions, Rails) won't surface
    a Set-Cookie on a bare GET — but their original login response
    does, and the orchestrator already has it.
    """
    extra = auth_headers(ctx.captured_auth)
    status, headers, _body = await http_get(
        ctx.session, ctx.base, headers=extra or None,
    )
    if status == 0:
        return []

    findings: list[dict[str, Any]] = []
    is_https = ctx.base.lower().startswith("https://")

    missing = _missing_security_headers(headers, is_https)
    if missing:
        findings.append(_emit_missing_headers(ctx.base, missing))

    cookies = _all_set_cookies(headers)
    if ctx.captured_auth:
        raw = ctx.captured_auth.get("set_cookie_raw")
        if isinstance(raw, str) and raw:
            cookies.extend(re.split(r", (?=[A-Za-z_][\w\-]*=)", raw))

    seen_cookie_names: set[str] = set()
    for name_val, missing_flags in _insecure_session_cookies(cookies):
        if name_val in seen_cookie_names:
            continue
        seen_cookie_names.add(name_val)
        findings.append(_emit_insecure_cookie(ctx.base, name_val, missing_flags))

    for header, value in _info_disclosure(headers):
        findings.append(_emit_info_disclosure(ctx.base, header, value))

    return findings
