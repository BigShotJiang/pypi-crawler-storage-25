"""Registry adapters for the 14 legacy SPA probes.

The legacy probes live in `agents/web/spa_probes.py` and keep their
existing call sites in `WebAgent._run_deterministic`. This module wraps
each one with the @registry.probe decorator so they're discoverable by:

  - The agent loop (via engine.agents.handlers.registry_bridge)
  - The benchmark harness (via engine.probes.registry.all())
  - Future tooling that reads ProbeSpec metadata

Wrappers are thin: they pull (session, base) plus optional inputs from
ProbeContext and call the original function unchanged. No logic was
rewritten in this commit. Once the registry path becomes the default
dispatcher, each legacy probe can be moved into its own module under
engine/probes/web/ in place.

Metadata mapping (bug_class + severity_max) was hand-picked from each
probe's emitted findings. Adjustments belong in this file only.
"""
from __future__ import annotations

from typing import Any

from agents.web.spa_probes import (
    probe_authenticated_pivot as _probe_authenticated_pivot,
)
from agents.web.spa_probes import (
    probe_dev_interfaces as _probe_dev_interfaces,
)
from agents.web.spa_probes import (
    probe_directory_listing as _probe_directory_listing,
)
from agents.web.spa_probes import (
    probe_ftp_leak as _probe_ftp_leak,
)
from agents.web.spa_probes import (
    probe_jwt_alg_none as _probe_jwt_alg_none,
)
from agents.web.spa_probes import (
    probe_jwt_alg_variants as _probe_jwt_alg_variants,
)
from agents.web.spa_probes import (
    probe_login_sqli_bypass as _probe_login_sqli_bypass,
)
from agents.web.spa_probes import (
    probe_nosql_inject as _probe_nosql_inject,
)
from agents.web.spa_probes import (
    probe_open_redirect as _probe_open_redirect,
)
from agents.web.spa_probes import (
    probe_role_self_promote as _probe_role_self_promote,
)
from agents.web.spa_probes import (
    probe_search_sqli_get as _probe_search_sqli_get,
)
from agents.web.spa_probes import (
    probe_source_maps as _probe_source_maps,
)
from agents.web.spa_probes import (
    probe_unauth_rest_leak as _probe_unauth_rest_leak,
)
from agents.web.spa_probes import (
    probe_user_enum as _probe_user_enum,
)
from engine.probes import ProbeContext, registry

DEFAULT_JWT_ENDPOINTS: tuple[str, ...] = (
    "/api/Users/",
    "/api/Users",
    "/api/users",
    "/api/users/",
    "/rest/admin/application-configuration",
    "/rest/user/whoami",
    "/api/SecurityAnswers",
    "/api/PrivacyRequests",
    "/api/BasketItems",
    "/api/Complaints",
    "/api/Challenges",
)


@registry.probe(
    name="web.open_redirect",
    bug_class="open_redirect",
    severity_max="medium",
    owasp="A01:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "legacy"),
)
async def open_redirect(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_open_redirect(ctx.session, ctx.base)


@registry.probe(
    name="web.user_enum",
    bug_class="auth_bypass",
    severity_max="medium",
    owasp="A07:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "legacy"),
)
async def user_enum(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_user_enum(ctx.session, ctx.base)


@registry.probe(
    name="web.unauth_rest_leak",
    bug_class="auth_bypass",
    severity_max="high",
    owasp="A01:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "legacy", "high-roi"),
)
async def unauth_rest_leak(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_unauth_rest_leak(ctx.session, ctx.base)


@registry.probe(
    name="web.search_sqli_get",
    bug_class="sqli",
    severity_max="critical",
    owasp="A03:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "legacy", "high-roi"),
)
async def search_sqli_get(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_search_sqli_get(ctx.session, ctx.base)


@registry.probe(
    name="web.jwt_alg_variants",
    bug_class="jwt_alg_none",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "legacy"),
)
async def jwt_alg_variants(ctx: ProbeContext) -> list[dict[str, Any]]:
    candidates = list(ctx.candidate_endpoints) or list(DEFAULT_JWT_ENDPOINTS)
    return await _probe_jwt_alg_variants(ctx.session, ctx.base, candidates)


@registry.probe(
    name="web.authenticated_pivot",
    bug_class="auth_bypass",
    severity_max="critical",
    owasp="A01:2021",
    runtime_budget_s=12.0,
    tags=("authenticated", "legacy", "high-roi"),
    requires_auth=False,
)
async def authenticated_pivot(ctx: ProbeContext) -> list[dict[str, Any]]:
    # Captures its own admin token via the SQLi auth bypass on the login
    # endpoint, then re-tests every protected endpoint with that token.
    # requires_auth=False because the probe self-captures: filtering it
    # out when ctx.captured_auth is empty would skip a high-value chain
    # the registry-driven loop can otherwise reach (yesterday's MCP run
    # produced 9 high findings here; today's lost them when the filter
    # gated this probe out).
    return await _probe_authenticated_pivot(ctx.session, ctx.base)


@registry.probe(
    name="web.jwt_alg_none",
    bug_class="jwt_alg_none",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "legacy", "high-roi"),
)
async def jwt_alg_none(ctx: ProbeContext) -> list[dict[str, Any]]:
    candidates = list(ctx.candidate_endpoints) or list(DEFAULT_JWT_ENDPOINTS)
    return await _probe_jwt_alg_none(ctx.session, ctx.base, candidates)


@registry.probe(
    name="web.source_maps",
    bug_class="source_map_exposure",
    severity_max="medium",
    owasp="A05:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "legacy"),
)
async def source_maps(ctx: ProbeContext) -> list[dict[str, Any]]:
    js_urls = list(ctx.js_urls)
    return await _probe_source_maps(ctx.session, ctx.base, js_urls)


@registry.probe(
    name="web.directory_listing",
    bug_class="dir_listing",
    severity_max="medium",
    owasp="A05:2021",
    runtime_budget_s=6.0,
    tags=("anonymous", "legacy", "fast"),
)
async def directory_listing(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_directory_listing(ctx.session, ctx.base)


@registry.probe(
    name="web.dev_interfaces",
    bug_class="exposed_dev",
    severity_max="medium",
    owasp="A05:2021",
    runtime_budget_s=6.0,
    tags=("anonymous", "legacy", "fast"),
)
async def dev_interfaces(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_dev_interfaces(ctx.session, ctx.base)


@registry.probe(
    name="web.login_sqli_bypass",
    bug_class="sqli",
    severity_max="critical",
    owasp="A03:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "legacy", "high-roi"),
)
async def login_sqli_bypass(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_login_sqli_bypass(ctx.session, ctx.base)


@registry.probe(
    name="web.role_self_promote",
    bug_class="business_logic",
    severity_max="high",
    owasp="A04:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "legacy"),
)
async def role_self_promote(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_role_self_promote(ctx.session, ctx.base)


@registry.probe(
    name="web.ftp_leak",
    bug_class="exposed_admin",
    severity_max="high",
    owasp="A05:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "legacy", "high-roi"),
)
async def ftp_leak(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_ftp_leak(ctx.session, ctx.base)


@registry.probe(
    name="web.nosql_inject",
    bug_class="nosql_injection",
    severity_max="high",
    owasp="A03:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "legacy"),
)
async def nosql_inject(ctx: ProbeContext) -> list[dict[str, Any]]:
    return await _probe_nosql_inject(ctx.session, ctx.base)
