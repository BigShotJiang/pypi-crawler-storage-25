"""Wordlist-driven API/admin path discovery.

The default crawler only follows links it can find in HTML and JS literals.
That misses every authenticated route an app doesn't link from its
public pages — `/api/users`, `/api/search`, `/admin/*`, `/internal/*` —
which is exactly where the interesting bugs live.

This probe brute-forces a curated list of common paths against the
target. It runs both unauthenticated and (when ctx.captured_auth is
set) authenticated, so it can surface routes that 401 anonymously and
200 with a session token.

The wordlist is small and high-signal — kept tight so the probe is
fast and false-positive light. Severity stays low/info by design;
this is a discovery probe, not a vuln probe. The discovered paths
land as endpoint hints for downstream probes (SQLi, IDOR, mass
assignment, etc.) to actually exploit.
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import walk_paths

# Common API resource names. Kept short to keep the request budget
# bounded; specific apps can extend via ctx.candidate_endpoints.
_API_NOUNS: tuple[str, ...] = (
    "users", "user", "accounts", "account", "profile", "profiles",
    "admin", "session", "sessions", "tokens", "auth",
    "products", "items", "orders", "payments", "invoices",
    "search", "import", "export", "upload", "download",
    "config", "settings", "secrets", "keys", "credentials",
    "logs", "audit", "events", "metrics", "health", "status",
    "internal", "private", "debug",
    "webhook", "webhooks", "callback", "callbacks", "notify",
    "files", "documents", "uploads", "attachments",
)

_API_PREFIXES: tuple[str, ...] = (
    "/api/{}",
    "/api/v1/{}",
    "/api/v2/{}",
    "/rest/{}",
    "/admin/{}",
    "/internal/{}",
    "/_admin/{}",
    "/_internal/{}",
)

_BARE_PATHS: tuple[str, ...] = (
    "/api", "/api/", "/rest", "/rest/",
    "/admin", "/admin/", "/_admin", "/_admin/",
    "/internal", "/internal/", "/_internal", "/_internal/",
    "/.env", "/.git/config", "/.git/HEAD",
    "/swagger", "/swagger.json", "/swagger-ui", "/openapi.json",
    "/api-docs", "/redoc",
    "/graphql", "/graphiql",
    "/actuator", "/actuator/env", "/actuator/health",
    "/metrics", "/prometheus", "/healthz",
    "/debug", "/__debug__", "/_debug", "/_dev",
    "/console", "/_console",
    "/server-status", "/server-info",
    # Common bug-class entry points that scanners typically miss because
    # they're not linked from the homepage. Adding them here lets SSRF /
    # XXE / path-traversal / SQLi probes know they exist as targets.
    "/webhook", "/webhooks", "/callback", "/proxy", "/fetch",
    "/api/webhook", "/api/import", "/api/export", "/api/upload",
    "/files", "/file", "/download", "/api/files", "/api/download",
    "/api/search", "/search/api", "/api/v1/search",
    "/api/login", "/api/auth", "/api/auth/login", "/api/token",
    "/reset-password", "/api/reset-password", "/forgot-password",
)


def _build_wordlist(extra: tuple[str, ...] = ()) -> tuple[str, ...]:
    paths = list(_BARE_PATHS)
    for prefix in _API_PREFIXES:
        for noun in _API_NOUNS:
            paths.append(prefix.format(noun))
    paths.extend(extra)
    seen: set[str] = set()
    deduped: list[str] = []
    for p in paths:
        if p not in seen:
            seen.add(p)
            deduped.append(p)
    return tuple(deduped)


def _is_spa_shell(body: str) -> bool:
    """True for tiny HTML responses that look like an SPA shell.

    Mirrors the FP guard added in commit 62bc908 to the score-board
    probe: SPA apps return 200+index.html for any unknown path, so we
    can't trust 200+body as evidence of a real endpoint without a
    content-shape check.
    """
    if not body:
        return True
    stripped = body.lstrip().lower()
    if not stripped.startswith("<"):
        return False
    return len(body) <= 800


def _looks_like_shell(body: str, shell: str) -> bool:
    """True when `body` is byte-similar to the recorded SPA shell.

    The cheap length+prefix check catches Angular/React/Vue catch-all
    responses where every unknown path returns the same index.html.
    Without this guard, wordlist probes report hundreds of phantom
    "discovered" paths on any SPA target.

    Similarity rule: lengths within 10% AND the first 500 chars match
    byte-for-byte. Tighter than substring containment so a partial-
    match (e.g. shared template fragment) doesn't false-negative a
    real endpoint that happens to embed the shell wrapper.
    """
    if not shell or not body:
        return False
    if abs(len(body) - len(shell)) > max(64, len(shell) // 10):
        return False
    return body[:500] == shell[:500]


_SENSITIVE_MARKERS: tuple[str, ...] = (
    '"email":', '"password":', '"token":', '"secret":',
    '"role":', '"isAdmin":', '"is_admin":', '"api_key":', '"apiKey":',
    "stripe_", "sk_live_", "sk_test_",
)


@registry.probe(
    name="web.api_path_discovery",
    bug_class="exposed_dev",
    severity_max="medium",
    owasp="A05:2021",
    runtime_budget_s=15.0,
    tags=("discovery", "anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_api_path_discovery(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Brute-force a wordlist of API/admin/internal paths.

    Forwards ctx.captured_auth as request headers when present, so
    authenticated routes get discovered too. Adds discovered paths
    as endpoints in the engagement so downstream probes (SQLi, IDOR,
    mass assignment, etc.) can target them.
    """
    headers = auth_headers(ctx.captured_auth) if ctx.captured_auth else None
    extra = tuple(ctx.candidate_endpoints or ())
    paths = _build_wordlist(extra=extra)

    base = ctx.base.rstrip("/")
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    # Fingerprint the SPA catch-all body (if any) before walking the
    # wordlist. Angular/React/Vue apps return index.html for every
    # unknown path with HTTP 200 — without this fingerprint the probe
    # reports hundreds of phantom paths on any SPA target. Best-effort:
    # tolerate fingerprint failure (mocked tests, transport errors) so
    # the probe still walks the wordlist without the dedup guard.
    from engine.probes.primitives import http_get as _http_get
    try:
        _, _, _spa_shell = await _http_get(
            ctx.session,
            base + "/this-path-definitely-does-not-exist-ptai-canary",
            headers=headers,
        )
    except Exception:  # noqa: BLE001
        _spa_shell = ""

    def predicate(status: int, hdrs: dict[str, str], body: str) -> bool:  # noqa: ARG001
        if status in (401, 403):
            return True
        if status == 200 and not _is_spa_shell(body):
            return not _looks_like_shell(body, _spa_shell)
        # 400/405/422 on a bare GET against a wordlist path is a strong
        # "endpoint exists, wants different args/method" signal — random
        # missing paths return 404 from every mainstream framework. We
        # surface them as info-severity discovery hits so downstream probes
        # (SSRF, XXE, path-trav) can target them. Without this, endpoints
        # like /webhook (which 400s without a `callback` param) are
        # invisible to the rest of the registry.
        return status in (400, 405, 422)

    raw = await walk_paths(
        session=ctx.session,
        base=base,
        paths=paths,
        predicate=predicate,
        finding_template={
            "title": "Path discovered: {path}",
            "severity": "info",
            "category": "exposure",
            "bug_class": "exposed_dev",
            "remediation": (
                "Audit the discovered path. If it's a real endpoint, "
                "ensure it's authentication-gated and only exposed to "
                "the audience that needs it. Remove dev/admin paths "
                "from production deployments."
            ),
        },
        concurrency=12,
        headers=None,
    )

    for f in raw:
        url = f["target"]
        if url in seen:
            continue
        seen.add(url)
        body = f.get("evidence", "")
        if body and any(m in body for m in _SENSITIVE_MARKERS):
            f["severity"] = "medium"
            f["evidence"] = f"200 with sensitive-shape JSON: {body[:300]}"
        elif body and not _is_spa_shell(body):
            f["severity"] = "low"
            f["evidence"] = f"200 with non-shell body: {body[:300]}"
        else:
            f["severity"] = "info"
            f["evidence"] = "endpoint exists but requires auth (401/403)"
        findings.append(f)

    if headers:
        raw_auth = await walk_paths(
            session=ctx.session,
            base=base,
            paths=paths,
            predicate=predicate,
            finding_template={
                "title": "Path discovered (authenticated): {path}",
                "severity": "low",
                "category": "exposure",
                "bug_class": "exposed_dev",
                "remediation": (
                    "Authenticated route surface — review whether each "
                    "endpoint enforces the right authorization (not just "
                    "authentication) and whether IDOR / mass-assignment "
                    "checks are in place."
                ),
            },
            concurrency=12,
            headers=headers,
        )
        for f in raw_auth:
            url = f["target"]
            if url in seen:
                continue
            seen.add(url)
            body = f.get("evidence", "")
            if body and any(m in body for m in _SENSITIVE_MARKERS):
                f["severity"] = "medium"
            f["evidence"] = (
                f"only reachable with auth (200): {body[:300]}"
                if body else "only reachable with auth (200)"
            )
            findings.append(f)

    return findings
