"""Leaked credentials in JavaScript bundles probe.

Modern SPAs ship credentials they should not. Developers leave behind:

1. Hardcoded test users (`email: "amy@..." password: "K1f....!"`) used
   during local dev that survive the production build.
2. API keys and bearer tokens for third-party services baked into the
   bundle so the SPA can call them without a backend round trip.
3. JWTs minted at build time and stuffed into config objects.

Juice Shop has three challenges around this exact pattern (Login Amy,
Login MC SafeSearch, Exposed Credentials). The probe walks the crawler
output, fetches each same-origin JS bundle with the wider 2 MiB envelope,
runs a small set of conservative regexes, and where it finds an
email plus password pair it tries the login endpoint. A 200 with a
token-shaped body lifts severity to critical; a clean leak with no live
account is still high.

The probe is read-only and runs anonymously.
"""
from __future__ import annotations

import re
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_post_json
from engine.probes.recon.crawler import _http_get_full, run_crawler

# --- credential pattern set ---------------------------------------------------
#
# The patterns are intentionally narrow. False positives here cost the
# operator time triaging. Each pattern has a label that maps to the
# detection-signal table in the docstring.

_PASSWORD_LITERAL = re.compile(
    r"""password['"]?\s*[:=]\s*['"]([^'"]{3,30})['"]""",
    re.IGNORECASE,
)
_EMAIL_LITERAL = re.compile(
    r"""email['"]?\s*[:=]\s*['"]([^'"]+@[^'"]+)['"]""",
    re.IGNORECASE,
)
_API_KEY_LITERAL = re.compile(
    r"""api[_-]?key['"]?\s*[:=]\s*['"]([^'"]{16,})['"]""",
    re.IGNORECASE,
)
_SECRET_LITERAL = re.compile(
    r"""secret['"]?\s*[:=]\s*['"]([^'"]{8,})['"]""",
    re.IGNORECASE,
)
_BEARER_LITERAL = re.compile(r"""Bearer\s+([A-Za-z0-9._-]{20,})""")
_JWT_LITERAL = re.compile(
    r"""(eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})"""
)

# Endpoints to attempt login confirmation on. Order matters: Juice Shop
# uses /rest/user/login; most other Express/JWT-style apps use
# /api/auth/login. Two attempts is cheap.
_LOGIN_ENDPOINTS: tuple[str, ...] = (
    "/rest/user/login",
    "/api/auth/login",
)

_JS_BODY_CAP = 2 * 1024 * 1024


def _scan_bundle(body: str) -> dict[str, list[str]]:
    """Run every regex over the bundle. Return a label -> matches map."""
    hits: dict[str, list[str]] = {}
    for label, pattern in (
        ("password", _PASSWORD_LITERAL),
        ("email", _EMAIL_LITERAL),
        ("api_key", _API_KEY_LITERAL),
        ("secret", _SECRET_LITERAL),
        ("bearer", _BEARER_LITERAL),
        ("jwt", _JWT_LITERAL),
    ):
        matches = pattern.findall(body)
        if matches:
            hits[label] = matches
    return hits


def _looks_like_token_response(status: int, body: str) -> bool:
    """200 plus a token-shaped JSON body counts as a confirmed login.

    Conservative: requires status 200 and at least one of `token`, `jwt`,
    `access_token`, or `authentication` substrings. Juice Shop returns
    {"authentication": {"token": "..."}}.
    """
    if status != 200 or not body:
        return False
    lowered = body.lower()
    return any(
        marker in lowered
        for marker in ('"token"', '"jwt"', '"access_token"', '"authentication"')
    )


async def _try_login(
    session: Any, base: str, email: str, password: str
) -> tuple[bool, str]:
    """Attempt login on each known endpoint. Return (confirmed, evidence)."""
    for path in _LOGIN_ENDPOINTS:
        url = base + path
        status, _, body = await http_post_json(
            session, url, {"email": email, "password": password}
        )
        if _looks_like_token_response(status, body):
            return True, f"{path} returned 200 with token body"
    return False, ""


def _emit(
    *,
    severity: str,
    title: str,
    target: str,
    evidence: str,
    leaked_value: str,
) -> dict[str, Any]:
    return {
        "title": title,
        "severity": severity,
        "category": "exposure",
        "target": target,
        "evidence": evidence,
        "bug_class": "source_map_exposure",
        "leaked_value": leaked_value,
        "remediation": (
            "Remove credentials, API keys, and tokens from client-side "
            "bundles. Rotate any secret that shipped to production. Use a "
            "backend proxy or short-lived per-user tokens for third-party "
            "API access."
        ),
    }


@registry.probe(
    name="web.leaked_credentials",
    bug_class="source_map_exposure",
    severity_max="critical",
    owasp="A05:2021",
    runtime_budget_s=20.0,
    tags=("anonymous", "high-roi", "secrets"),
    requires_auth=False,
)
async def probe_leaked_credentials(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk JS bundles, scan for credentials, confirm with a login attempt.

    Step 1: discover JS bundle URLs via `run_crawler`. The crawler hits
    `/`, parses script tags, and returns a `discovered_js` set.

    Step 2: for each bundle, GET with the wider 2 MiB envelope so the
    back half of large bundles is not silently dropped.

    Step 3: scan for credentials with the regex set above.

    Step 4: for each (email, password) pair, post to Juice Shop's
    /rest/user/login and to /api/auth/login. A 200 with a token-shaped
    body upgrades the finding to critical.
    """
    findings: list[dict[str, Any]] = []
    base = ctx.base

    crawl = await run_crawler(ctx.session, base)
    js_paths = sorted(crawl.discovered_js)
    if not js_paths:
        return findings

    for js_path in js_paths:
        url = (
            js_path
            if js_path.startswith(("http://", "https://"))
            else base + js_path
        )
        status, body = await _http_get_full(ctx.session, url)
        if not status or not body:
            continue
        # _http_get_full already caps at 2 MiB; the explicit slice keeps
        # the contract obvious to anyone reading this probe.
        hits = _scan_bundle(body[:_JS_BODY_CAP])
        if not hits:
            continue

        emails = hits.get("email", [])
        passwords = hits.get("password", [])

        # Try every email x password combination on the bundle. Most
        # bundles only carry a single pair; the loop is cheap when the
        # cartesian product is 1x1 and bounded by regex caps anyway.
        login_pairs_tried: set[tuple[str, str]] = set()
        confirmed_pair: tuple[str, str] | None = None
        login_evidence = ""
        for email in emails:
            for password in passwords:
                key = (email, password)
                if key in login_pairs_tried:
                    continue
                login_pairs_tried.add(key)
                ok, evidence = await _try_login(
                    ctx.session, base, email, password
                )
                if ok:
                    confirmed_pair = key
                    login_evidence = evidence
                    break
            if confirmed_pair is not None:
                break

        if confirmed_pair is not None:
            email, password = confirmed_pair
            findings.append(
                _emit(
                    severity="critical",
                    title=(
                        f"Live credentials leaked in JS bundle: {email}"
                    ),
                    target=url,
                    evidence=(
                        f"Hardcoded email/password in {url}; "
                        f"{login_evidence}"
                    ),
                    leaked_value=f"{email}:{password}",
                )
            )
        elif emails and passwords:
            # Pair present but login did not succeed. Still a leak.
            email = emails[0]
            password = passwords[0]
            findings.append(
                _emit(
                    severity="high",
                    title=(
                        f"Hardcoded credentials in JS bundle: {email}"
                    ),
                    target=url,
                    evidence=(
                        f"Email/password literals in {url}; login "
                        f"attempt did not confirm a live account"
                    ),
                    leaked_value=f"{email}:{password}",
                )
            )

        for api_key in hits.get("api_key", []):
            findings.append(
                _emit(
                    severity="high",
                    title="API key leaked in JS bundle",
                    target=url,
                    evidence=f"api_key literal in {url}",
                    leaked_value=api_key,
                )
            )

        for secret in hits.get("secret", []):
            findings.append(
                _emit(
                    severity="high",
                    title="Secret literal leaked in JS bundle",
                    target=url,
                    evidence=f"secret literal in {url}",
                    leaked_value=secret,
                )
            )

        for token in hits.get("bearer", []):
            findings.append(
                _emit(
                    severity="high",
                    title="Bearer token leaked in JS bundle",
                    target=url,
                    evidence=f"Bearer token literal in {url}",
                    leaked_value=token,
                )
            )

        for jwt in hits.get("jwt", []):
            findings.append(
                _emit(
                    severity="high",
                    title="JWT leaked in JS bundle",
                    target=url,
                    evidence=f"JWT literal in {url}",
                    leaked_value=jwt,
                )
            )

    return findings
