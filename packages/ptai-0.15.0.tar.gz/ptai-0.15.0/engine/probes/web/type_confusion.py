"""Type-confusion / negative-quantity / boundary probe.

Business-logic flaws scanners typically miss. Many apps validate JSON
shape but not VALUES — they'll happily accept `quantity=-5`, `price=0`,
`amount=null`, or `quantity=[]` and pass them through to the pricing
or balance code, where math goes inverted (negative total = credit).

This probe POSTs/PATCHes JSON to a small list of likely-impacted
endpoints (cart, order, withdraw, transfer) with each variant of the
candidate fields. A 200/201 response that echoes the perturbed value
back is the finding.

Runs authenticated by default (most cart/order flows need a session).
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

import aiohttp

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers

_TARGETS: tuple[tuple[str, str], ...] = (
    ("/api/cart", "POST"),
    ("/api/cart/add", "POST"),
    ("/cart/add", "POST"),
    ("/api/orders", "POST"),
    ("/api/orders/place", "POST"),
    ("/api/withdraw", "POST"),
    ("/api/transfer", "POST"),
    ("/api/payments", "POST"),
    ("/api/wallet/credit", "POST"),
    ("/api/balance/adjust", "POST"),
)

_BASELINE_PAYLOAD: dict[str, Any] = {
    "item": "ptai-canary-item",
    "product": "ptai-canary-item",
    "sku": "PTAI-CANARY",
    "price": 100,
    "amount": 100,
    "quantity": 1,
    "qty": 1,
    "count": 1,
}

# Field -> list of (perturbation, label) pairs.
_PERTURBATIONS: dict[str, tuple[tuple[Any, str], ...]] = {
    "quantity": (
        (-5, "negative integer"),
        (-1, "minus one"),
        ([], "empty array"),
        (None, "null"),
        (9_999_999_999, "very large integer"),
    ),
    "qty": (
        (-5, "negative integer"),
        ([], "empty array"),
    ),
    "amount": (
        (-100, "negative amount"),
        (None, "null amount"),
    ),
    "price": (
        (0, "zero price"),
        (-1, "negative price"),
    ),
    "count": (
        (-1, "negative count"),
    ),
}


async def _post(
    session: aiohttp.ClientSession,
    url: str,
    payload: dict[str, Any],
    headers: dict[str, str] | None,
) -> tuple[int, str]:
    try:
        async with session.post(
            url, json=payload, headers=headers,
            timeout=aiohttp.ClientTimeout(total=8),
        ) as resp:
            body = (await resp.text(errors="replace"))[:1000]
            return resp.status, body
    except (asyncio.TimeoutError, aiohttp.ClientError, OSError):
        return 0, ""


def _accepted(status: int, body: str, perturbed_field: str, perturbed_value: Any) -> bool:
    """Did the server accept the perturbed payload?

    Heuristics:
    - 200 / 201: probably accepted.
    - 400/422 with explicit error mentioning the field: rejected (good).
    - 200 with the perturbed value reflected in the response body:
      strong signal of acceptance.
    """
    if status not in (200, 201):
        return False
    # Reflection check.
    if perturbed_value is None:
        return True  # 200 + null accepted is a signal on its own
    needle = (
        json.dumps(perturbed_value)
        if isinstance(perturbed_value, (int, float, list, dict))
        else str(perturbed_value)
    )
    if needle in body:
        return True
    # Some apps don't echo the value but still process it. Treat 200
    # as soft signal — still emit, but mark severity accordingly.
    return True


@registry.probe(
    name="web.type_confusion",
    bug_class="business_logic",
    severity_max="high",
    owasp="A04:2021",
    runtime_budget_s=12.0,
    tags=("authenticated", "high-roi"),
    requires_auth=True,
)
async def probe_type_confusion(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk POST/PATCH endpoints with type-confusion perturbations."""
    headers = auth_headers(ctx.captured_auth) if ctx.captured_auth else None
    if not headers:
        return []

    base = ctx.base.rstrip("/")
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    for path, _method in _TARGETS:
        url = path if path.startswith(("http://", "https://")) else base + path

        # Baseline: confirm endpoint accepts our shape with normal values.
        b_status, _ = await _post(ctx.session, url, _BASELINE_PAYLOAD, headers)
        if b_status not in (200, 201):
            continue

        for field, variants in _PERTURBATIONS.items():
            if field not in _BASELINE_PAYLOAD:
                continue
            for value, label in variants:
                payload = dict(_BASELINE_PAYLOAD)
                payload[field] = value

                p_status, p_body = await _post(ctx.session, url, payload, headers)
                if not _accepted(p_status, p_body, field, value):
                    continue
                key = (url, field, label)
                if key[:2] in seen:
                    continue
                seen.add((url, field))

                # Negative numeric quantity / amount that's accepted is
                # high-severity (price flip / credit). Other variants
                # (null, empty array, oversize) emit at medium.
                severity = "high" if isinstance(value, (int, float)) and value < 0 and field in ("quantity", "qty", "amount", "price", "count") else "medium"

                findings.append({
                    "title": f"Type confusion: {field}={label} accepted at {path}",
                    "severity": severity,
                    "category": "business_logic",
                    "bug_class": "business_logic",
                    "target": url,
                    "evidence": (
                        f"POST {url} with {field}={value!r} ({label}) "
                        f"returned HTTP {p_status}. Server should reject "
                        f"out-of-range and wrong-type values at the "
                        f"validation boundary."
                    ),
                    "owasp_category": "A04:2021",
                    "remediation": (
                        f"Validate `{field}` server-side: reject negative, "
                        "null, array, and oversize values. Use a typed "
                        "schema (Pydantic, JSONSchema, Zod) at every input "
                        "boundary. Don't rely on client-side validation."
                    ),
                })

    return findings
