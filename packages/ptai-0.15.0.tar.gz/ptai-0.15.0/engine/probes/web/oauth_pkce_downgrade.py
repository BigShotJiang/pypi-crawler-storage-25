"""OAuth PKCE downgrade and redirect_uri mutation probe.

Inspired by CVE-2025-4144 (Cloudflare Workers OAuth Provider) where the
authorization server accepted PKCE method=plain even though the client
had pinned S256, and accepted redirect_uri values that bypassed the
registered allowlist via subdomain confusion or path traversal.

A correct authorization server MUST:
  1. Reject PKCE method=plain when the original /authorize bound S256.
  2. Reject redirect_uri values that are not byte-for-byte registered
     URIs. No path traversal, no parent-domain swap, no scheme swap.

This probe walks common OAuth authorize endpoints, then for each
endpoint that responds 200/302 issues:

  a. A baseline /authorize with code_challenge_method=S256
  b. A downgrade /authorize with code_challenge_method=plain
  c. A downgrade with code_challenge but no method param at all
  d. A redirect_uri mutation set: full attacker URL, path traversal,
     subdomain-confusion ("legit.com.attacker.tld")

Detection: server responds 302 Location with `code=` (or any opaque
authorization code) under the downgraded or mutated request shape.

Severity: CRITICAL. A successful PKCE downgrade or redirect_uri swap
turns into full account takeover via a one-click phishing chain.
"""
from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

# Probe these endpoints. Order matters: discovery doc first so we can
# read its authorization_endpoint, then conventional shortcuts.
AUTHORIZE_PATHS: tuple[str, ...] = (
    "/oauth/authorize",
    "/authorize",
    "/oauth2/auth",
    "/oauth2/authorize",
    "/o/oauth2/v2/auth",
    "/.well-known/oauth-authorization-server",
)

ATTACKER_URL = "https://ptai-pkce-canary.example/cb"
LEGIT_HOST_FOR_CONFUSION = "legit-site.com.ptai-pkce-canary.example"

# Fixed canary values; unique enough to recognize in logs but harmless.
_CLIENT_ID = "ptai-canary-client"
_CHALLENGE = "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM"
_STATE = "ptai-state-canary"


def _wants_query(headers: dict[str, str], body: str) -> bool:
    """Did the response carry an authorization code in a Location header?"""
    loc = headers.get("Location") or headers.get("location") or ""
    if not loc:
        return False
    parsed = urlparse(loc)
    qs = (parsed.query or "") + (parsed.fragment or "")
    if "code=" in qs:
        return True
    # Some servers redirect with `?token=` for implicit-style flows; treat
    # that as success too because the leak is just as bad.
    return "token=" in qs or "access_token=" in qs


def _baseline_query(redirect_uri: str) -> str:
    """Build the canonical S256 challenge query string."""
    return (
        f"response_type=code&client_id={_CLIENT_ID}"
        f"&redirect_uri={redirect_uri}&state={_STATE}"
        f"&code_challenge={_CHALLENGE}&code_challenge_method=S256"
    )


def _plain_query(redirect_uri: str) -> str:
    """code_challenge_method=plain (downgrade)."""
    return (
        f"response_type=code&client_id={_CLIENT_ID}"
        f"&redirect_uri={redirect_uri}&state={_STATE}"
        f"&code_challenge={_CHALLENGE}&code_challenge_method=plain"
    )


def _no_method_query(redirect_uri: str) -> str:
    """code_challenge present, code_challenge_method missing entirely."""
    return (
        f"response_type=code&client_id={_CLIENT_ID}"
        f"&redirect_uri={redirect_uri}&state={_STATE}"
        f"&code_challenge={_CHALLENGE}"
    )


def _emit_pkce(target: str, variant: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"OAuth PKCE downgrade accepted ({variant})",
        "severity": "critical",
        "category": "auth",
        "target": target,
        "evidence": evidence,
        "bug_class": "auth_bypass",
        "owasp": "A07:2021",
        "remediation": (
            "Reject any authorize request whose code_challenge_method is "
            "not exactly S256 when S256 was registered. Reject requests "
            "that include code_challenge without a method."
        ),
    }


def _emit_redirect(target: str, mutation: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"OAuth redirect_uri mutation accepted ({mutation})",
        "severity": "critical",
        "category": "auth",
        "target": target,
        "evidence": evidence,
        "bug_class": "auth_bypass",
        "owasp": "A07:2021",
        "remediation": (
            "Match redirect_uri byte-for-byte against the client's "
            "registered values. Reject path traversal, scheme swaps, "
            "and any host that is a substring of a registered host."
        ),
    }


async def _probe_endpoint(
    ctx: ProbeContext, path: str
) -> list[dict[str, Any]]:
    """Run the PKCE-downgrade and redirect_uri checks against one endpoint."""
    findings: list[dict[str, Any]] = []
    base = ctx.base
    legit_redirect = f"{base}/oauth/cb"

    base_url = base + path if path.startswith("/") else f"{base}/{path}"

    # Quick reachability check using S256 baseline.
    baseline_url = f"{base_url}?{_baseline_query(legit_redirect)}"
    b_status, b_headers, b_body = await http_get(ctx.session, baseline_url)
    if b_status not in (200, 302, 303):
        return findings

    # PKCE downgrade variants. We only flag if the downgraded request
    # produces an auth code while the baseline either also did or did not;
    # what matters is the server accepting the downgrade.
    plain_url = f"{base_url}?{_plain_query(legit_redirect)}"
    p_status, p_headers, p_body = await http_get(ctx.session, plain_url)
    if p_status in (302, 303) and _wants_query(p_headers, p_body):
        findings.append(
            _emit_pkce(
                plain_url,
                "method=plain",
                f"status={p_status} location={p_headers.get('Location', '')[:200]}",
            )
        )

    no_method_url = f"{base_url}?{_no_method_query(legit_redirect)}"
    n_status, n_headers, n_body = await http_get(ctx.session, no_method_url)
    if n_status in (302, 303) and _wants_query(n_headers, n_body):
        findings.append(
            _emit_pkce(
                no_method_url,
                "method-omitted",
                f"status={n_status} location={n_headers.get('Location', '')[:200]}",
            )
        )

    # redirect_uri mutations.
    mutations: tuple[tuple[str, str], ...] = (
        ("attacker-host", ATTACKER_URL),
        ("path-traversal", f"{base}/legit_path/../../attacker"),
        ("subdomain-confusion", f"https://{LEGIT_HOST_FOR_CONFUSION}/cb"),
    )
    for label, mutated in mutations:
        m_url = f"{base_url}?{_baseline_query(mutated)}"
        m_status, m_headers, m_body = await http_get(ctx.session, m_url)
        if m_status in (302, 303) and _wants_query(m_headers, m_body):
            findings.append(
                _emit_redirect(
                    m_url,
                    label,
                    f"status={m_status} location={m_headers.get('Location', '')[:200]}",
                )
            )

    # Suppress unused-warning for body inspection points.
    _ = (b_body, p_body, n_body)
    return findings


@registry.probe(
    name="web.oauth_pkce_downgrade",
    bug_class="auth_bypass",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=15.0,
    tags=("authenticated", "oauth", "high-roi"),
    requires_auth=True,
)
async def probe_oauth_pkce_downgrade(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk authorize endpoints and emit findings for accepted downgrades."""
    if ctx.captured_auth is None:
        return []

    findings: list[dict[str, Any]] = []
    for path in AUTHORIZE_PATHS:
        findings.extend(await _probe_endpoint(ctx, path))
    return findings
