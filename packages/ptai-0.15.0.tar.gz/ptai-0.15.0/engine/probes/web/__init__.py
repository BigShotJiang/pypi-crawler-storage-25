"""Web probes registered through engine.probes.registry.

Importing this package side-effect registers every web probe via the
`@registry.probe` decorator. Drivers that want the agent loop to know
about web probes should `import engine.probes.web` once at startup.
"""
from __future__ import annotations

from engine.probes.web import (
    api_path_discovery,  # noqa: F401  - wordlist API/admin/internal path brute-force
    asset_secrets_scan,  # noqa: F401  - base64 + hidden URL discovery
    business_logic_fuzz,  # noqa: F401  - boundary value tests (8 checks)
    captcha_replay,  # noqa: F401
    cookie_prefix_bypass,  # noqa: F401  - __Host-/__Secure- prefix bypass
    cors_reflection,  # noqa: F401
    coupon_forging,  # noqa: F401  - Z85 coupon forgery via app config leak
    cve_poc_primitives,  # noqa: F401  - top-N CVE PoC primitives library
    deserialization,  # noqa: F401  - Node.js node-serialize + js-yaml RCE/DoS
    dom_xss,  # noqa: F401  - Playwright-driven DOM XSS detection
    exif_metadata,  # noqa: F401  - GPS / camera fingerprint from uploaded images
    file_upload_validation,  # noqa: F401  - oversize / wrong-type / polyglot
    forced_error,  # noqa: F401  - stack-trace disclosure via malformed payloads
    graphql_introspection,  # noqa: F401
    hidden_discovery,  # noqa: F401  - score-board, security.txt, easter-egg paths
    host_header_reset_poisoning,  # noqa: F401  - ATO via reset link poisoning
    idor_authenticated,  # noqa: F401
    idor_authz_differential,  # noqa: F401  - BOLA + BFLA cross-user testing
    idor_sequential,  # noqa: F401
    jwt_jku_x5u_ssrf,  # noqa: F401  - JWT header SSRF + key confusion
    ldap_injection,  # noqa: F401
    leaked_credentials,  # noqa: F401  - hardcoded creds in JS bundles
    legacy,  # noqa: F401  - wraps the 14 spa_probes
    mass_assignment,  # noqa: F401
    nextjs_rsc_rce,  # noqa: F401  - Next.js Server Action deserialization (CVE-2025-66478)
    nosql_fuzz,  # noqa: F401  - crawler-driven 17-payload NoSQL fuzz
    oauth_pkce_downgrade,  # noqa: F401  - OAuth PKCE S256->plain + redirect_uri mutation
    password_reset_weak,  # noqa: F401
    path_traversal,  # noqa: F401  - LFI via ../../../etc/passwd in filename params
    privilege_escalation_patch,  # noqa: F401  - PATCH/PUT mass assignment to user record
    prototype_pollution,  # noqa: F401
    race_condition,  # noqa: F401  - 15-concurrent rate limit bypass
    reflected_xss,  # noqa: F401
    response_headers,  # noqa: F401  - missing CSP/XFO, insecure cookies, info-disclosure headers
    saml_xsw,  # noqa: F401  - SAML signature wrapping + parser differential
    sqli_fuzz,  # noqa: F401  - crawler-driven 34-payload SQLi fuzz
    sqli_login_bypass,  # noqa: F401  - classic ' OR 1=1 -- auth-bypass
    ssrf_cloud_metadata,  # noqa: F401  - AWS IMDSv2 / GCP / Azure metadata pivot
    ssti_fuzz,  # noqa: F401  - crawler-driven 13-payload SSTI fuzz
    ssti_polyglot,  # noqa: F401
    ssti_stored,  # noqa: F401  - stored SSTI via POST + GET round-trip
    stored_xss,  # noqa: F401
    trusted_header_bypass,  # noqa: F401  - X-Forwarded-User and similar header bypass
    type_confusion,  # noqa: F401  - negative quantity / null / array boundary fuzz
    web3_probe,  # noqa: F401  - Web3 sandbox + NFT mint without payment
    web_cache_deception,  # noqa: F401  - WCD with delimiter discrepancy
    xss_fuzz,  # noqa: F401  - crawler-driven 26-payload XSS fuzz
    xxe_upload,  # noqa: F401  - XML External Entity via file upload
)

__all__: list[str] = []
