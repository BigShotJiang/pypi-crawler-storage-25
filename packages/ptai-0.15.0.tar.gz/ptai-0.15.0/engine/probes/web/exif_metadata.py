"""EXIF metadata exposure probe.

Juice Shop's "Meta Geo Stalking" (#22) and "Visual Geo Stalking" (#23)
challenges hinge on user-uploaded photos that still carry EXIF metadata,
specifically GPS coordinates and camera fingerprints. This probe walks
common upload paths plus Juice Shop's /api/Memorys index, downloads each
image, and parses EXIF using either Pillow (if installed) or a minimal
pure-python JPEG APP1 reader.

Detection signals:
  - GPS coordinates present in any user-uploaded image -> high severity.
    GPS in a profile photo can answer "where is your favorite place?"
    style security questions.
  - Camera Make/Model + DateTimeOriginal without GPS -> medium severity.
    Reveals user device + activity time, useful for correlation.

Read-only, unauthenticated, bounded by max-image and max-bytes caps so
hostile or oversized payloads cannot blow the runtime budget.
"""
from __future__ import annotations

import asyncio
import json
import logging
import struct
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

logger = logging.getLogger("pentest-ai.probes.web.exif_metadata")

# Per-image and overall caps. EXIF parsing is CPU-cheap but bytes are not.
_MAX_BYTES_PER_IMAGE = 5 * 1024 * 1024  # 5 MB
_MAX_IMAGES = 20

# Always-walked upload directories. Hits common SPA conventions plus
# Juice Shop's static asset path.
DEFAULT_UPLOAD_PATHS: tuple[str, ...] = (
    "/assets/public/images/uploads/",
    "/api/Recycles/image",
    "/uploads/",
    "/static/uploads/",
)

# Juice Shop "memories" index returns JSON with imagePath fields.
MEMORYS_PATH = "/api/Memorys"

_IMAGE_EXTS: tuple[str, ...] = (".jpg", ".jpeg", ".png", ".tif", ".tiff")


# --- Pillow-or-fallback EXIF extraction -----------------------------------

try:  # pragma: no cover - import guard, both branches tested
    from PIL import ExifTags as _ExifTags  # type: ignore
    from PIL import Image as _PILImage  # type: ignore

    _PILLOW_AVAILABLE = True
except Exception:  # noqa: BLE001
    _PILLOW_AVAILABLE = False


def _extract_with_pillow(data: bytes) -> dict[str, Any]:
    """Parse EXIF using Pillow. Returns flat tag->value dict."""
    import io

    out: dict[str, Any] = {}
    try:
        img = _PILImage.open(io.BytesIO(data))
        raw = img.getexif() or {}
    except Exception as exc:  # noqa: BLE001
        logger.debug("Pillow EXIF parse failed: %s", exc)
        return out

    tag_names = {v: k for k, v in _ExifTags.TAGS.items()}  # name -> id
    id_to_name = _ExifTags.TAGS

    for tag_id, value in raw.items():
        name = id_to_name.get(tag_id, str(tag_id))
        out[name] = value

    # GPS sub-IFD is nested. Pillow exposes it via tag 0x8825.
    gps_id = tag_names.get("GPSInfo")
    if gps_id is not None and gps_id in raw:
        try:
            gps_ifd = img.getexif().get_ifd(gps_id)  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            gps_ifd = {}
        gps_names = _ExifTags.GPSTAGS
        for gid, gval in gps_ifd.items():
            gname = gps_names.get(gid, str(gid))
            out[gname] = gval
    return out


def _extract_with_fallback(data: bytes) -> dict[str, Any]:
    """Minimal EXIF parser: locate APP1 / "Exif\\x00\\x00", parse TIFF IFD0.

    Handles only the tags this probe cares about: GPS lat/lon refs,
    Make, Model, DateTimeOriginal. Returns a flat dict mirroring the
    Pillow output shape so callers don't branch.
    """
    out: dict[str, Any] = {}
    if len(data) < 12 or not data.startswith(b"\xff\xd8"):
        return out

    marker = data.find(b"Exif\x00\x00")
    if marker < 0:
        return out
    tiff_off = marker + 6
    tiff = data[tiff_off:]
    if len(tiff) < 8:
        return out

    if tiff[:2] == b"II":
        endian = "<"
    elif tiff[:2] == b"MM":
        endian = ">"
    else:
        return out

    try:
        ifd0_off = struct.unpack(endian + "I", tiff[4:8])[0]
        if ifd0_off + 2 > len(tiff):
            return out
        n_entries = struct.unpack(endian + "H", tiff[ifd0_off : ifd0_off + 2])[0]
    except struct.error:
        return out

    # We only walk IFD0 looking for Make (0x010f), Model (0x0110), and
    # the GPS sub-IFD pointer (0x8825). Going deeper would mean parsing
    # rationals, which is what Pillow is for.
    interesting = {
        0x010F: "Make",
        0x0110: "Model",
        0x9003: "DateTimeOriginal",
        0x8825: "GPSInfo",
    }
    gps_ifd_off = None
    for i in range(n_entries):
        entry_off = ifd0_off + 2 + i * 12
        if entry_off + 12 > len(tiff):
            break
        try:
            tag_id, dtype, count, value_off = struct.unpack(
                endian + "HHII", tiff[entry_off : entry_off + 12]
            )
        except struct.error:
            break
        name = interesting.get(tag_id)
        if name is None:
            continue
        if name == "GPSInfo":
            gps_ifd_off = value_off
            continue
        # ASCII string fields stored inline if <=4 bytes else at value_off
        if dtype == 2 and count > 0:
            if count <= 4:
                raw = tiff[entry_off + 8 : entry_off + 8 + count]
            else:
                if value_off + count > len(tiff):
                    continue
                raw = tiff[value_off : value_off + count]
            out[name] = raw.rstrip(b"\x00").decode("ascii", errors="replace")

    # If the GPS sub-IFD exists at all, the producer chose to include
    # location data; that alone is enough to flag the image as a privacy
    # leak even if we don't decode the rationals.
    if gps_ifd_off is not None and gps_ifd_off + 2 <= len(tiff):
        try:
            n_gps = struct.unpack(
                endian + "H", tiff[gps_ifd_off : gps_ifd_off + 2]
            )[0]
        except struct.error:
            n_gps = 0
        if n_gps > 0:
            out["GPSInfo"] = {"present": True, "entries": n_gps}
            # Pull GPSLatitude / GPSLongitude markers so callers can see them.
            gps_interest = {
                0x0001: "GPSLatitudeRef",
                0x0002: "GPSLatitude",
                0x0003: "GPSLongitudeRef",
                0x0004: "GPSLongitude",
            }
            for i in range(n_gps):
                e_off = gps_ifd_off + 2 + i * 12
                if e_off + 12 > len(tiff):
                    break
                try:
                    g_tag, g_dtype, g_count, g_value = struct.unpack(
                        endian + "HHII", tiff[e_off : e_off + 12]
                    )
                except struct.error:
                    break
                g_name = gps_interest.get(g_tag)
                if g_name is None:
                    continue
                if g_dtype == 2 and g_count <= 4:
                    raw = tiff[e_off + 8 : e_off + 8 + g_count]
                    out[g_name] = raw.rstrip(b"\x00").decode(
                        "ascii", errors="replace"
                    )
                else:
                    out[g_name] = f"<offset={g_value} count={g_count}>"
    return out


def _extract_exif(data: bytes) -> dict[str, Any]:
    """Pick the best available extractor. Both paths return same shape."""
    if _PILLOW_AVAILABLE:
        try:
            tags = _extract_with_pillow(data)
            if tags:
                return tags
        except Exception as exc:  # noqa: BLE001
            logger.debug("Pillow path errored, falling back: %s", exc)
    return _extract_with_fallback(data)


# --- Image discovery ------------------------------------------------------


def _looks_like_image(href: str) -> bool:
    href_lc = href.lower().split("?", 1)[0]
    return href_lc.endswith(_IMAGE_EXTS)


def _parse_dir_listing(body: str) -> list[str]:
    """Pull href values pointing at image files from a directory listing."""
    found: list[str] = []
    # Tiny scanner; full HTML parse is overkill for nginx/apache autoindex.
    lower = body.lower()
    cursor = 0
    while True:
        idx = lower.find("href=", cursor)
        if idx < 0:
            break
        quote = body[idx + 5 : idx + 6]
        if quote in ('"', "'"):
            end = body.find(quote, idx + 6)
            if end < 0:
                break
            href = body[idx + 6 : end]
            cursor = end + 1
        else:
            end = body.find(" ", idx + 5)
            if end < 0:
                end = idx + 100
            href = body[idx + 5 : end]
            cursor = end
        if href and _looks_like_image(href):
            found.append(href)
    return found


def _parse_memorys(body: str) -> list[str]:
    """Pull imagePath values from Juice Shop /api/Memorys JSON."""
    try:
        data = json.loads(body)
    except (ValueError, TypeError):
        return []
    rows = data.get("data") if isinstance(data, dict) else None
    if not isinstance(rows, list):
        return []
    paths: list[str] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        ipath = row.get("imagePath") or row.get("image")
        if isinstance(ipath, str) and ipath:
            paths.append(ipath)
    return paths


def _resolve(base: str, href: str) -> str:
    if href.startswith(("http://", "https://")):
        return href
    if href.startswith("/"):
        return base.rstrip("/") + href
    return base.rstrip("/") + "/" + href


async def _fetch_bytes(session, url: str) -> bytes | None:
    """Fetch up to _MAX_BYTES_PER_IMAGE bytes. Sentinel None on failure."""
    import aiohttp

    try:
        async with session.get(url, timeout=aiohttp.ClientTimeout(total=8)) as resp:
            if resp.status != 200:
                return None
            data = await resp.read()
            if not data:
                return None
            return data[:_MAX_BYTES_PER_IMAGE]
    except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
        logger.debug("image fetch %s failed: %s", url, exc)
        return None


# --- Detection ------------------------------------------------------------


def _has_gps(tags: dict[str, Any]) -> bool:
    if not tags:
        return False
    if "GPSInfo" in tags and tags["GPSInfo"]:
        return True
    return any(
        key in tags and tags[key] not in (None, "", b"")
        for key in ("GPSLatitude", "GPSLongitude", "GPSLatitudeRef", "GPSLongitudeRef")
    )


def _has_camera_fingerprint(tags: dict[str, Any]) -> bool:
    if not tags:
        return False
    return bool(tags.get("Make") or tags.get("Model") or tags.get("DateTimeOriginal"))


def _emit_gps(target: str, tags: dict[str, Any]) -> dict[str, Any]:
    keys = sorted(
        k
        for k in tags
        if k.startswith("GPS") or k in ("Make", "Model", "DateTimeOriginal")
    )
    return {
        "title": "GPS coordinates exposed in user-uploaded image EXIF",
        "severity": "high",
        "category": "exposure",
        "target": target,
        "evidence": f"EXIF tags present: {', '.join(keys)[:300]}",
        "bug_class": "source_map_exposure",
        "remediation": (
            "Strip EXIF metadata server-side on upload. GPS coordinates "
            "leak user location and can answer security questions like "
            "'favorite place'."
        ),
    }


def _emit_camera(target: str, tags: dict[str, Any]) -> dict[str, Any]:
    parts = []
    for key in ("Make", "Model", "DateTimeOriginal"):
        v = tags.get(key)
        if v:
            parts.append(f"{key}={v}")
    return {
        "title": "Camera fingerprint exposed in user-uploaded image EXIF",
        "severity": "medium",
        "category": "exposure",
        "target": target,
        "evidence": "; ".join(parts)[:300],
        "bug_class": "source_map_exposure",
        "remediation": (
            "Strip EXIF metadata server-side on upload. Camera Make/Model "
            "and capture timestamps enable user device fingerprinting."
        ),
    }


# --- Probe ----------------------------------------------------------------


@registry.probe(
    name="web.exif_metadata",
    bug_class="source_map_exposure",
    severity_max="high",
    owasp="A01:2021",
    runtime_budget_s=15.0,
    tags=("anonymous", "high-roi", "privacy"),
    requires_auth=False,
)
async def probe_exif_metadata(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk upload paths, parse EXIF, flag GPS or camera fingerprints."""
    base = ctx.base
    image_urls: list[str] = []
    seen: set[str] = set()

    # Step 1: Juice Shop /api/Memorys (returns JSON listing imagePath rows)
    memorys_url = base + MEMORYS_PATH
    m_status, _m_hdrs, m_body = await http_get(ctx.session, memorys_url)
    if m_status == 200 and m_body:
        for path in _parse_memorys(m_body):
            url = _resolve(base, path)
            if url not in seen:
                seen.add(url)
                image_urls.append(url)

    # Step 2: walk each upload directory; if it returns a directory listing,
    # extract image hrefs. If it returns an image directly, treat the URL
    # itself as a candidate.
    for path in DEFAULT_UPLOAD_PATHS:
        url = _resolve(base, path)
        status, headers, body = await http_get(ctx.session, url)
        if status != 200:
            continue
        ctype = (
            headers.get("Content-Type") or headers.get("content-type") or ""
        ).lower()
        if ctype.startswith("image/"):
            if url not in seen:
                seen.add(url)
                image_urls.append(url)
            continue
        for href in _parse_dir_listing(body):
            full = _resolve(base, href if href.startswith("/") else path + href)
            if full not in seen:
                seen.add(full)
                image_urls.append(full)

    if not image_urls:
        return []

    # Step 3: cap, fetch, parse
    image_urls = image_urls[:_MAX_IMAGES]
    findings: list[dict[str, Any]] = []
    for url in image_urls:
        data = await _fetch_bytes(ctx.session, url)
        if not data:
            continue
        try:
            tags = _extract_exif(data)
        except Exception as exc:  # noqa: BLE001
            logger.debug("EXIF parse error on %s: %s", url, exc)
            continue
        if _has_gps(tags):
            findings.append(_emit_gps(url, tags))
        elif _has_camera_fingerprint(tags):
            findings.append(_emit_camera(url, tags))

    return findings
