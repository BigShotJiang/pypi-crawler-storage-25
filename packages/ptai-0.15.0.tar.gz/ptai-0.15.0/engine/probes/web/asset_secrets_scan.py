"""Asset secrets / hidden URL scanner.

Many production builds leave breadcrumbs in HTML comments, JS bundles,
and base64 blobs that point at hidden routes, admin panels, or developer
notes. Generic to any HTTP target.

The probe runs the recon crawler to discover HTML pages and JS bundles,
then mines each body for:

  1. HTML/JS comment blocks longer than 30 chars
  2. base64-shaped strings that decode into URLs or known keywords
  3. Hidden URL patterns (`/secret/`, `_admin`, etc.). The Juice-Shop-
     style `/the/.../easter` shape is matched too, but only emitted at
     `info` severity so it can't pollute reports against generic
     targets that happen to serve unrelated content at that URL shape.
  4. References to admin/debug/internal/dev paths

Findings are info or medium severity. The probe is anonymous, read-only,
and degrades gracefully when the crawler fails.
"""
from __future__ import annotations

import base64
import logging
import re
from typing import Any
from urllib.parse import urlparse

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get
from engine.probes.recon import run_crawler

logger = logging.getLogger("pentest-ai.probes.web.asset_secrets_scan")

# Min comment length to bother extracting. Short comments are usually
# build-tool noise (license headers, sourcemap markers).
_MIN_COMMENT_LEN = 30

# Cap on per-body extraction so one giant minified bundle can't dominate
# the probe budget.
_MAX_COMMENTS_PER_BODY = 40
_MAX_BASE64_PER_BODY = 40

# Regex set. All compiled once at module import.
_HTML_COMMENT_RE = re.compile(r"<!--(.*?)-->", re.DOTALL)
_JS_BLOCK_COMMENT_RE = re.compile(r"/\*(.*?)\*/", re.DOTALL)
_JS_LINE_COMMENT_RE = re.compile(r"//([^\n\r]+)")

# base64-shaped tokens with proper boundaries (no surrounding word chars).
_BASE64_RE = re.compile(r"(?<![A-Za-z0-9+/=])([A-Za-z0-9+/]{20,}={0,2})(?![A-Za-z0-9+/=])")

# Easter-egg URL shape: /the/<seg>/<seg>/.../easter style. Juice Shop's
# challenge #11 hides a path with five+ slash-separated segments.
_EASTER_SHAPE_RE = re.compile(r"/the/(?:[a-z]+/){3,}[a-z]+")

# Generic hidden URL hints inside text bodies.
_HIDDEN_URL_RE = re.compile(
    r"""(?ix)                       # case-insensitive, verbose
    (?:^|[\s'"`(])                  # boundary
    (
        /(?:secret|hidden|internal|debug|dev|admin|_[a-z][\w./-]+)
        [\w./?=&%-]*
    )
    """
)

# Keywords that, if found inside a base64-decoded blob, are interesting.
_DECODE_KEYWORDS: tuple[str, ...] = ("score", "easter", "admin", "secret", "ptai-test")


def _extract_comments(body: str) -> list[str]:
    """Pull HTML/JS comment payloads from a string. De-duped, length-filtered."""
    if not body:
        return []
    out: list[str] = []
    seen: set[str] = set()
    for regex in (_HTML_COMMENT_RE, _JS_BLOCK_COMMENT_RE, _JS_LINE_COMMENT_RE):
        for m in regex.finditer(body):
            text = m.group(1).strip()
            if len(text) < _MIN_COMMENT_LEN:
                continue
            if text in seen:
                continue
            seen.add(text)
            out.append(text)
            if len(out) >= _MAX_COMMENTS_PER_BODY:
                return out
    return out


def _extract_base64(body: str) -> list[str]:
    """Pull base64-shaped tokens from a string."""
    if not body:
        return []
    out: list[str] = []
    seen: set[str] = set()
    for m in _BASE64_RE.finditer(body):
        token = m.group(1)
        if token in seen:
            continue
        seen.add(token)
        out.append(token)
        if len(out) >= _MAX_BASE64_PER_BODY:
            break
    return out


def _decode_base64(token: str) -> str | None:
    """Decode a base64 token; return printable text or None on failure."""
    try:
        raw = base64.b64decode(token, validate=False)
    except (ValueError, TypeError):
        return None
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError:
        return None
    # Reject blobs that are mostly control bytes or unprintable junk.
    printable = sum(1 for c in text if c.isprintable() or c in "\n\r\t")
    if not text or printable / max(len(text), 1) < 0.85:
        return None
    return text


def _decoded_is_interesting(decoded: str) -> tuple[bool, str]:
    """Return (hit, reason) when a decoded blob looks like a URL/keyword."""
    low = decoded.lower()
    if "://" in low or low.startswith("/") or "www." in low:
        return True, "decoded base64 contains URL"
    for kw in _DECODE_KEYWORDS:
        if kw in low:
            return True, f"decoded base64 contains keyword: {kw}"
    return False, ""


def _extract_hidden_urls(text: str) -> list[str]:
    """Pull /secret, /admin, /the/.../easter style paths from a text blob."""
    if not text:
        return []
    out: list[str] = []
    seen: set[str] = set()
    for m in _EASTER_SHAPE_RE.finditer(text):
        path = m.group(0)
        if path not in seen:
            seen.add(path)
            out.append(path)
    for m in _HIDDEN_URL_RE.finditer(text):
        path = m.group(1)
        if path and path not in seen:
            seen.add(path)
            out.append(path)
    return out


def _emit(
    *,
    title: str,
    severity: str,
    target: str,
    evidence: str,
    bug_class: str = "exposed_admin",
) -> dict[str, Any]:
    return {
        "title": title,
        "severity": severity,
        "category": "information_disclosure",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": bug_class,
        "remediation": (
            "Strip developer comments, debug URLs, and inline base64 blobs "
            "from production HTML and JS bundles. Move secrets and internal "
            "paths server-side."
        ),
    }


def _resolve_url(base: str, path: str) -> str:
    if path.startswith(("http://", "https://")):
        return path
    if not path.startswith("/"):
        path = "/" + path
    return base + path


@registry.probe(
    name="web.asset_secrets_scan",
    bug_class="exposed_admin",
    severity_max="medium",
    owasp="A05:2021",
    runtime_budget_s=15.0,
    tags=("anonymous", "discovery"),
    requires_auth=False,
)
async def probe_asset_secrets_scan(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Mine HTML + JS assets for hidden URLs, base64 secrets, dev breadcrumbs."""
    findings: list[dict[str, Any]] = []
    seen_signals: set[tuple[str, str]] = set()

    # 1. Discover assets via the recon crawler. Degrade gracefully if it
    # raises: this probe still has work it can do off the index page, but
    # without a discovered asset list we have nothing to scan, so return.
    try:
        crawl = await run_crawler(ctx.session, ctx.base)
    except Exception as exc:  # noqa: BLE001 - crawler errors must not abort probe
        logger.debug("crawler failed; asset_secrets_scan skipping: %s", exc)
        return findings

    # 2. Pull bodies for the index plus every discovered HTML path and JS
    # bundle. The index sometimes carries the only easter-egg comment, so
    # always include "/" even if the crawler didn't list it explicitly.
    html_paths: set[str] = set(crawl.discovered_paths)
    html_paths.add("/")
    js_paths: set[str] = set(crawl.discovered_js)

    # Cap how many assets we pull. A wide crawl can return hundreds of
    # paths; the probe budget is 15s and we don't want one slow asset to
    # starve the rest of the run.
    html_targets = list(html_paths)[:20]
    js_targets = list(js_paths)[:20]

    bodies: list[tuple[str, str]] = []  # (url, body)
    for path in html_targets:
        url = _resolve_url(ctx.base, path)
        status, _, body = await http_get(ctx.session, url)
        if status and body:
            bodies.append((url, body))
    for path in js_targets:
        url = _resolve_url(ctx.base, path)
        status, _, body = await http_get(ctx.session, url)
        if status and body:
            bodies.append((url, body))

    base_host = urlparse(ctx.base).netloc

    # 3. Mine each body for the four signal classes.
    for url, body in bodies:
        # Comments: extract, then scan each comment for URL hints + easter shape.
        for comment in _extract_comments(body):
            for hidden in _extract_hidden_urls(comment):
                key = ("hidden_url", hidden)
                if key in seen_signals:
                    continue
                seen_signals.add(key)
                # Easter-egg shape gets its own info-level finding regardless
                # of fetch outcome. Generic hidden URLs only fire if a GET
                # comes back 200 on the same host.
                if _EASTER_SHAPE_RE.fullmatch(hidden) or _EASTER_SHAPE_RE.match(hidden):
                    findings.append(
                        _emit(
                            title=f"Easter-egg URL pattern in source comment: {hidden}",
                            severity="info",
                            target=url,
                            evidence=f"comment hint: {hidden}",
                        )
                    )
                    continue
                probe_url = _resolve_url(ctx.base, hidden)
                if urlparse(probe_url).netloc != base_host:
                    continue
                p_status, _, _p_body = await http_get(ctx.session, probe_url)
                if p_status == 200:
                    findings.append(
                        _emit(
                            title=f"Hidden URL from source comment returns 200: {hidden}",
                            severity="medium",
                            target=probe_url,
                            evidence=f"discovered in comment on {url}",
                        )
                    )

        # Easter-egg shape can also live raw in the body (outside comments).
        for hidden in _EASTER_SHAPE_RE.findall(body):
            key = ("easter_shape", hidden)
            if key in seen_signals:
                continue
            seen_signals.add(key)
            findings.append(
                _emit(
                    title=f"Easter-egg URL pattern in asset: {hidden}",
                    severity="info",
                    target=url,
                    evidence=f"matched /the/.../easter shape in {url}",
                )
            )

        # base64 tokens: decode, classify.
        for token in _extract_base64(body):
            decoded = _decode_base64(token)
            if decoded is None:
                continue
            hit, reason = _decoded_is_interesting(decoded)
            if not hit:
                continue
            key = ("b64", token)
            if key in seen_signals:
                continue
            seen_signals.add(key)
            # If the decoded text looks like a URL, treat it as medium;
            # keyword-only hits stay at info.
            sev = "medium" if "URL" in reason else "info"
            findings.append(
                _emit(
                    title=f"Base64 blob in asset decodes to interesting content ({reason})",
                    severity=sev,
                    target=url,
                    evidence=f"token={token[:40]}... decoded={decoded[:120]}",
                )
            )

    return findings
