"""Stored server-side template injection via POST + GET round-trip.

Many user-profile / about / description endpoints accept text that the
server later renders through a template engine. When the persisted text
goes through `render_template_string` (Jinja2) or its peers without
sandboxing, an attacker can store `{{7*7}}` once and have it evaluate
to `49` on every subsequent page render — and from there escalate to
RCE via `__class__.__mro__[...]__subclasses__()` or
`lipsum.__globals__["os"].popen(...)`.

The existing `web.ssti_fuzz` and `web.ssti_polyglot` probes only test
*reflected* SSTI — payload in same request, eval in same response.
Stored SSTI needs a POST then a separate GET on a different URL. This
probe is the stored-flow analogue of `web.stored_xss`.

Detection marker is `137*97` -> `13289` (or `${...}`/`<%=...%>` syntax
variants). 13289 is distinctive enough that a substring match has
near-zero false-positive risk; baseline-diff isn't needed.

Severity is critical: stored template injection on an authenticated
profile field is a direct path to RCE on the running web process.
"""
from __future__ import annotations

import json
import re
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_get, http_post_form, http_post_json

# Candidate endpoints that commonly accept profile-shaped text. Flask
# /profile/update is the honeypot's sink; the REST entries cover modern
# scaffolds (Rails, Django REST, NestJS, FastAPI).
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/profile/update",
    "/profile",
    "/api/profile",
    "/api/users/me",
    "/me",
    "/account",
    "/settings/profile",
    "/users/me",
)

# Fields that commonly land in a renderable template. `bio` is the
# honeypot's; `signature` and `about` are the classic forum / OSS patterns.
PROFILE_FIELDS: tuple[str, ...] = (
    "bio",
    "about",
    "description",
    "signature",
    "notes",
    "profile",
)

# Pick a multiplication that's unlikely to appear in a page by chance.
# 137 * 97 = 13289 is a 5-digit string with no semantic meaning in any
# normal HTML and doesn't collide with version strings, timestamps, etc.
PAYLOAD_JINJA = "{{137*97}}"
PAYLOAD_VELOCITY = "${137*97}"
PAYLOAD_ERB = "<%=137*97%>"
MARKER = "13289"

PAYLOADS_BY_SYNTAX: tuple[tuple[str, str], ...] = (
    ("jinja2", PAYLOAD_JINJA),
    ("velocity", PAYLOAD_VELOCITY),
    ("erb", PAYLOAD_ERB),
)

# Status codes that count as a successful write. 302 covers Flask-style
# POST-redirect-GET; aiohttp follows the redirect by default so the body
# of the final response is what we ultimately inspect.
_OK_POST = (200, 201, 302)

# Readback URLs to try after a successful POST, in addition to the POST
# URL itself. Numeric IDs cover Flask-style /profile/<int> renders.
READBACK_SUFFIXES: tuple[str, ...] = (
    "",          # the POST URL itself (often /profile)
    "/1",
    "/2",
    "/3",
)


def _parse_json(body: str) -> Any:
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None


_MISSING = object()


def _walk_for_field(blob: Any, key: str) -> Any:
    if isinstance(blob, dict):
        if key in blob:
            return blob[key]
        for v in blob.values():
            found = _walk_for_field(v, key)
            if found is not _MISSING:
                return found
    elif isinstance(blob, list):
        for item in blob:
            found = _walk_for_field(item, key)
            if found is not _MISSING:
                return found
    return _MISSING


def _extract_id(parsed: Any) -> str | None:
    for key in ("id", "_id", "uuid"):
        found = _walk_for_field(parsed, key)
        if found is _MISSING or found is None:
            continue
        if isinstance(found, (str, int)):
            return str(found)
    return None


def _emit(target: str, syntax: str, field: str, body_excerpt: str) -> dict[str, Any]:
    return {
        "title": f"Stored SSTI: {field!r} field evaluated as {syntax} template on read-back",
        "severity": "critical",
        "category": "injection",
        "target": target,
        "evidence": body_excerpt[:512],
        "bug_class": "ssti",
        "remediation": (
            "Never pass user-supplied text through render_template_string "
            "or the equivalent in your template engine. Render the value "
            "as data (autoescape on, treated as text) instead of as a "
            "template. If template-rendered content is required, use a "
            "strict sandbox with an explicit safe-attribute whitelist."
        ),
    }


def _post_readback_urls(post_url: str, parsed: Any) -> list[str]:
    """Build a list of URLs likely to render the stored value.

    For /profile/update we try /profile, /profile/1..3. For /api/foo we
    try /api/foo and /api/foo/<id> when the POST returned one.
    """
    # Strip a trailing /update segment that's common on form POSTs.
    base = post_url
    if base.endswith("/update"):
        base = base[: -len("/update")]

    urls: list[str] = [post_url, base]
    for suffix in READBACK_SUFFIXES:
        if suffix:
            urls.append(base + suffix)

    record_id = _extract_id(parsed)
    if record_id:
        urls.append(f"{base.rstrip('/')}/{record_id}")

    # Preserve insertion order, drop dups.
    return list(dict.fromkeys(urls))


@registry.probe(
    name="web.ssti_stored",
    bug_class="ssti",
    severity_max="critical",
    owasp="A03:2021",
    runtime_budget_s=12.0,
    tags=("authenticated", "high-roi", "destructive-low"),
    requires_auth=True,
)
async def probe_ssti_stored(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Two-step probe: POST a template payload, then GET to confirm eval.

    For each candidate path the probe tries each (syntax, field-name)
    combination as form-urlencoded first (Flask-style) and then JSON
    (REST-style). After every accepted POST it GETs a small set of
    readback URLs and emits a critical finding on first appearance of
    the multiplication marker.
    """
    candidates = list(dict.fromkeys(
        list(DEFAULT_CANDIDATES) + list(ctx.candidate_endpoints or ())
    ))
    base = ctx.base
    extra = auth_headers(ctx.captured_auth)
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        fired_here = False
        for syntax, payload in PAYLOADS_BY_SYNTAX:
            if fired_here:
                break
            for field_name in PROFILE_FIELDS:
                if fired_here:
                    break
                body = {field_name: payload}

                # Try form-encoded first (matches the Flask honeypot and
                # any handler reading from request.form).
                status_f, _, body_f = await http_post_form(
                    ctx.session, url, body, headers=extra or None,
                )
                # aiohttp follows the 302; the final body is the render
                # response. Check it directly before fanning out.
                if status_f in _OK_POST and MARKER in (body_f or ""):
                    findings.append(_emit(url, syntax, field_name, body_f))
                    fired_here = True
                    continue

                # JSON shape for REST endpoints.
                status_j, _, body_j = await http_post_json(
                    ctx.session, url, body, headers=extra or None,
                )
                parsed = _parse_json(body_j) if status_j in _OK_POST else None
                if status_j in _OK_POST and MARKER in (body_j or ""):
                    findings.append(_emit(url, syntax, field_name, body_j))
                    fired_here = True
                    continue

                # Neither POST response contained the marker; fan out to
                # plausible readback URLs and check each.
                if status_f not in _OK_POST and status_j not in _OK_POST:
                    continue

                for read_url in _post_readback_urls(url, parsed):
                    key = (read_url, field_name)
                    if key in seen:
                        continue
                    r_status, _, r_body = await http_get(
                        ctx.session, read_url, headers=extra or None,
                    )
                    if r_status != 200 or not r_body:
                        continue
                    if MARKER in r_body:
                        seen.add(key)
                        findings.append(_emit(read_url, syntax, field_name, r_body))
                        fired_here = True
                        break

    return findings


# Public regex for tests that want to assert detection logic separately.
MARKER_RE = re.compile(re.escape(MARKER))
