"""IDOR sequential-ID probe.

REST APIs that expose resources by sequential numeric IDs leak
other-user data when the server checks ID existence but not ownership.
The classic OWASP Juice Shop "Basket #2" bug fits here: hit
`/api/Baskets/1`, `/api/Baskets/2`, `/api/Baskets/3` without auth and
the server hands back three different users' baskets.

Detection signal:
  - At least 2 of 3 sequential IDs return 200 with a JSON body
  - The responses contain different identity fields (different
    "email", "username", "userId", or "name" values across responses)
  - No Authorization header is set (probe runs unauthenticated, so any
    hit is by definition unauthenticated IDOR)

The probe walks a candidate-endpoint list of common REST collection
roots; for each, it fetches `/{1}`, `/{2}`, `/{3}` and compares the
identity fields across the JSON responses.
"""
from __future__ import annotations

import json
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.primitives import http_get

# Common REST collection paths across modern SPAs and Juice Shop-style
# scaffolds. Each entry must end with a trailing slash so we can append
# `1`, `2`, `3` cleanly.
DEFAULT_CANDIDATES: tuple[str, ...] = (
    "/api/users/",
    "/api/orders/",
    "/api/posts/",
    "/api/comments/",
    "/api/messages/",
    "/api/Baskets/",
    "/api/Feedbacks/",
    "/api/Memorys/",
    "/api/Recycles/",
    "/api/Quantitys/",
    "/api/PrivacyRequests/",
    "/api/SecurityAnswers/",
    "/api/Complaints/",
    "/api/Cards/",
    "/api/Addresses/",
    "/api/Deluxe/",
)

# Identity fields whose divergence across responses signals different
# users' data is being returned.
_IDENTITY_FIELDS: tuple[str, ...] = ("email", "username", "userId", "name")

# How many sequential IDs to probe per endpoint.
_IDS: tuple[int, ...] = (1, 2, 3)


def _looks_like_json(body: str, headers: dict[str, str]) -> bool:
    """Return True if the response is plausibly JSON."""
    ctype = headers.get("Content-Type", "").lower()
    if "json" in ctype:
        return True
    stripped = body.lstrip()
    return stripped.startswith(("{", "["))


def _parse_json(body: str) -> Any | None:
    """Parse JSON, swallowing errors. Returns None on failure."""
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None


def _extract_identity(payload: Any) -> dict[str, str]:
    """Pull identity fields out of a JSON payload.

    The payload may be a dict (single resource), a dict wrapping a "data"
    key (Juice Shop style), or a list. We dig one level for each.
    """
    candidates: list[dict[str, Any]] = []

    if isinstance(payload, dict):
        candidates.append(payload)
        data = payload.get("data")
        if isinstance(data, dict):
            candidates.append(data)
        elif isinstance(data, list) and data and isinstance(data[0], dict):
            candidates.append(data[0])
    elif isinstance(payload, list) and payload and isinstance(payload[0], dict):
        candidates.append(payload[0])

    out: dict[str, str] = {}
    for obj in candidates:
        for field in _IDENTITY_FIELDS:
            value = obj.get(field)
            if value is None:
                continue
            # Coerce to string; we only care about distinctness.
            sval = str(value)
            if sval and field not in out:
                out[field] = sval
    return out


def _identities_diverge(identities: list[dict[str, str]]) -> bool:
    """Return True if at least one identity field has >= 2 distinct values."""
    for field in _IDENTITY_FIELDS:
        values = {ident[field] for ident in identities if field in ident}
        if len(values) >= 2:
            return True
    return False


def _emit(target: str, evidence: str) -> dict[str, Any]:
    return {
        "title": "IDOR: sequential IDs return distinct user records without auth",
        "severity": "high",
        "category": "access_control",
        "target": target,
        "evidence": evidence,
        "bug_class": "idor",
        "owasp": "A01:2021",
        "remediation": (
            "Enforce per-request ownership checks on every REST resource. "
            "Reject requests for objects the authenticated principal does "
            "not own; do not rely on ID obscurity. For collection endpoints, "
            "scope queries to the caller's tenant or user_id."
        ),
    }


@registry.probe(
    name="web.idor_sequential",
    bug_class="idor",
    severity_max="high",
    owasp="A01:2021",
    runtime_budget_s=8.0,
    tags=("anonymous", "high-roi"),
    requires_auth=False,
)
async def probe_idor_sequential(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Walk candidate REST roots and flag sequential-ID IDOR.

    Two-pass strategy:
      1. Unauthenticated walk (the canonical IDOR shape: server forgot
         to gate at all). Emit as critical when it fires.
      2. If unauth yielded zero 200 responses on this path (i.e. the
         server uniformly required auth) AND we have captured_auth from
         a prior set_auth call, replay with the session. Emit as high
         when divergent identities appear, since "any logged-in user
         can see any other user's record" is still an authorization
         bug — just one tier less severe than zero-auth disclosure.
    """
    candidates = ctx.candidate_endpoints or DEFAULT_CANDIDATES
    base = ctx.base
    findings: list[dict[str, Any]] = []
    headers_auth = auth_headers(ctx.captured_auth) if ctx.captured_auth else {}

    for path in candidates:
        prefix = path if path.endswith("/") else path + "/"

        # Pass 1: unauthenticated
        json_hits, identities, sample_evidence, status_counts = await _walk_ids(
            ctx, base, prefix, request_headers=None,
        )
        if json_hits >= 2 and _identities_diverge(identities):
            target_url = (
                prefix
                if prefix.startswith(("http://", "https://"))
                else base + prefix
            )
            evidence = "; ".join(sample_evidence)[:512]
            findings.append(_emit(target_url, evidence))
            continue

        # Pass 2: auth fallback. Only triggers when the unauth pass got
        # zero 200s (i.e. the path is auth-gated). With captured_auth,
        # retry to see if cross-user data leaks to any logged-in caller.
        if json_hits > 0 or not headers_auth:
            continue
        auth_rejected = sum(1 for s in status_counts if s in (401, 403))
        if auth_rejected < 2:
            # Wasn't an auth wall; it was 404s/500s/etc. Skip the retry.
            continue
        json_hits_a, identities_a, sample_evidence_a, _ = await _walk_ids(
            ctx, base, prefix, request_headers=headers_auth,
        )
        if json_hits_a >= 2 and _identities_diverge(identities_a):
            target_url = (
                prefix
                if prefix.startswith(("http://", "https://"))
                else base + prefix
            )
            evidence = (
                "auth-fallback IDOR (path returned "
                f"{auth_rejected}× 401/403 unauth, then leaked cross-user data "
                f"to authenticated caller): "
                + "; ".join(sample_evidence_a)
            )[:512]
            f = _emit(target_url, evidence)
            # Slightly de-rate severity vs canonical zero-auth IDOR.
            f["severity"] = "high"
            f["title"] = f["title"].replace("IDOR", "Authenticated IDOR")
            findings.append(f)

    return findings


async def _walk_ids(
    ctx: ProbeContext,
    base: str,
    prefix: str,
    request_headers: dict[str, str] | None,
) -> tuple[int, list[dict[str, str]], list[str], list[int]]:
    """Internal: GET prefix+{1,2,3}, collect JSON-shaped 200 responses."""
    json_hits = 0
    identities: list[dict[str, str]] = []
    sample_evidence: list[str] = []
    status_counts: list[int] = []
    for resource_id in _IDS:
        url_path = f"{prefix}{resource_id}"
        url = (
            url_path
            if url_path.startswith(("http://", "https://"))
            else base + url_path
        )
        status, headers, body = await http_get(
            ctx.session, url, headers=request_headers,
        )
        status_counts.append(status)
        if status != 200:
            continue
        if not _looks_like_json(body, headers):
            continue
        payload = _parse_json(body)
        if payload is None:
            continue
        json_hits += 1
        ident = _extract_identity(payload)
        if ident:
            identities.append(ident)
            sample_evidence.append(f"id={resource_id} -> {ident}")
    return json_hits, identities, sample_evidence, status_counts
