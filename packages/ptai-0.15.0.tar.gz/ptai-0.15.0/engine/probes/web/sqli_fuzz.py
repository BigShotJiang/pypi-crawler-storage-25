"""Fuzzed SQLi probe: 34 payloads against crawler-discovered query endpoints.

Replaces the single-payload SQLi pattern. Two-phase shape:

  1. Run the crawler to discover endpoints with query parameters
     (forms with method=get, /search-style paths, OpenAPI definitions).
  2. For each (endpoint, parameter) pair, fuzz the 34 SQLi payloads
     using `payloads.library.fuzz()`. Detection predicate compares
     baseline body to attack body for size deltas, error fingerprints,
     and time-based delays.

Where the original `web.search_sqli_get` probe sent ONE UNION payload
against ONE hardcoded path (/rest/products/search), this probe sends
34 against every discovered query-parameterized endpoint. Expected uplift
on Juice Shop: 1 critical -> 4 to 8 criticals across multiple endpoints.

Detection signals:
  - Response-size delta >= 2.5x baseline (UNION leaked rows)
  - Body contains canonical SQL error markers (SQLite, Postgres, MySQL,
    MSSQL) that didn't appear in baseline
  - Response time delta >= 4 seconds vs baseline (time-based blind)
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import auth_headers
from engine.probes.payloads.library import SQLI_PAYLOADS, fuzz
from engine.probes.recon.crawler import run_crawler

logger = logging.getLogger("pentest-ai.probes.web.sqli_fuzz")

SQL_ERROR_MARKERS: tuple[str, ...] = (
    # SQLite
    "SQLITE_ERROR",
    "SQLite/JDBCDriver",
    "no such column",
    "syntax error near",
    # Postgres
    "PostgreSQL",
    "PSQLException",
    "ERROR: syntax error",
    "pg_query()",
    # MySQL / MariaDB
    "You have an error in your SQL syntax",
    "MySQL server version",
    "mysqli_",
    "Warning: mysql_",
    # MSSQL
    "Microsoft OLE DB Provider for ODBC",
    "ODBC Driver",
    "Unclosed quotation mark",
    "Incorrect syntax near",
    # Generic
    "SQLException",
    "JDBC SQL",
    "OLE DB",
)

DEFAULT_QUERY_PARAMS: tuple[str, ...] = (
    "q",
    "query",
    "search",
    "id",
    "name",
    "user",
    "username",
    "email",
    "category",
    "filter",
    "sort",
    "order",
)


def _sql_error_in(body: str, baseline: str) -> bool:
    """True when an SQL error fingerprint appears in body but not baseline."""
    body_lc = body.lower()
    base_lc = baseline.lower()
    for marker in SQL_ERROR_MARKERS:
        m_lc = marker.lower()
        if m_lc in body_lc and m_lc not in base_lc:
            return True
    return False


_UNION_LEAK_MARKERS: tuple[str, ...] = (
    # Sequential numeric leakage from UNION SELECT 1,2,3,4...
    '"name":"2"',
    '"name":"1"',
    '"description":"3"',
    '"description":"2"',
    '"price":4',
    '"price":3',
    '"image":6',
    '"image":5',
    # Sequential string leakage
    '"1","2","3"',
    '"1","2","3","4"',
)


def _make_detect_fn():
    """Build a detect_fn that captures size + error + UNION leakage signals.

    Three positive signals on attack response:
      1. SQL error fingerprint not present in baseline -> error-based SQLi
      2. UNION leak markers present (sequential 1,2,3 leaking into product fields)
      3. Response size differs from baseline by >= 2.5x in either direction
         (Juice Shop's UNION returns SMALLER body when bypass succeeds)
    """
    def detect(status: int, _headers: dict[str, str], body: str, baseline: str) -> bool:
        if status == 0:
            return False
        if _sql_error_in(body, baseline):
            return True
        # UNION leakage: sequential ints/strings in response body
        for marker in _UNION_LEAK_MARKERS:
            if marker in body and marker not in baseline:
                return True
        # Size delta in either direction (UNION can shrink or grow the body)
        if status == 200 and baseline:
            ratio = len(body) / max(len(baseline), 1)
            if ratio >= 2.5 or (ratio <= 0.4 and len(body) > 0):
                return True
        return False
    return detect


SEARCH_PATH_HINTS: tuple[str, ...] = (
    "/search",
    "search/",
    "/lookup",
    "/find",
    "/query",
    "/rest/products",
    "/api/products",
)

# Known SQLi-prone endpoint patterns; always probed regardless of crawl results.
ALWAYS_PROBED_TEMPLATES: tuple[str, ...] = (
    "/rest/products/search?q={payload}",
    "/rest/products/search?query={payload}",
    "/api/products/search?q={payload}",
    "/search?q={payload}",
    "/search?query={payload}",
    "/api/users?email={payload}",
    "/api/Users?email={payload}",
    "/api/search?q={payload}",
    "/api/search?query={payload}",
    "/api/lookup?q={payload}",
    "/api/find?q={payload}",
)


def _candidate_query_endpoints(
    crawl, ctx_candidate_endpoints: tuple[str, ...] = (),
) -> list[tuple[str, str]]:
    """Build (path_template_with_placeholder, param_name) candidates.

    The ALWAYS_PROBED list takes priority so canonical SQLi targets like
    /rest/products/search?q=... never get pushed off by the runtime cap.
    Then ctx.candidate_endpoints (paths seeded by web.api_path_discovery
    in the three-pass orchestrator) wrapped against every common query
    param. Then forms with GET method. Then crawler-discovered paths
    matching search-shape heuristics. Total cap of 25 to bound runtime.
    """
    candidates: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()

    # 1. Always-probed canonical templates first
    for tpl in ALWAYS_PROBED_TEMPLATES:
        path = tpl.split("?", 1)[0]
        param = tpl.split("?", 1)[1].split("=", 1)[0]
        key = (path, param)
        if key not in seen:
            seen.add(key)
            candidates.append((tpl, param))

    # 2. ctx.candidate_endpoints: paths the discovery probe surfaced
    # (e.g. /api/search behind auth that the crawler can't reach).
    # We wrap each one against every common query param so the fuzzer
    # actually attacks the parameter that's used downstream.
    for path in ctx_candidate_endpoints:
        if not path or "?" in path:
            continue
        for param in DEFAULT_QUERY_PARAMS:
            key = (path, param)
            if key not in seen:
                seen.add(key)
                candidates.append((f"{path}?{param}={{payload}}", param))

    # 3. Forms with GET method
    for form in crawl.forms:
        if (form.get("method") or "get").lower() != "get":
            continue
        action = form.get("action") or "/"
        for field in form.get("fields") or []:
            param = field if isinstance(field, str) else field.get("name", "")
            if not param:
                continue
            template = f"{action}?{param}={{payload}}"
            key = (action, param)
            if key not in seen:
                seen.add(key)
                candidates.append((template, param))

    # 4. API paths whose lowercased path contains a search-shape hint
    for path in crawl.api_paths | crawl.discovered_paths:
        path_lc = path.lower()
        if not any(h in path_lc for h in SEARCH_PATH_HINTS):
            continue
        for param in DEFAULT_QUERY_PARAMS:
            key = (path, param)
            if key not in seen:
                seen.add(key)
                candidates.append((f"{path}?{param}={{payload}}", param))

    return candidates[:25]


def _emit(target: str, payload: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"SQL injection on {target} via fuzzed payload",
        "severity": "critical",
        "category": "injection",
        "target": target,
        "evidence": f"payload={payload[:80]} :: {evidence[:200]}",
        "bug_class": "sqli",
        "remediation": "Use parameterized queries; never interpolate user input into SQL.",
    }


@registry.probe(
    name="web.sqli_fuzz",
    bug_class="sqli",
    severity_max="critical",
    owasp="A03:2021",
    runtime_budget_s=30.0,
    tags=("anonymous", "high-roi", "fuzzing", "uses-crawler"),
    requires_auth=False,
)
async def probe_sqli_fuzz(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Crawler-driven 34-payload SQLi fuzz across query parameters."""
    findings: list[dict[str, Any]] = []
    seen_targets: set[str] = set()
    extra = auth_headers(ctx.captured_auth)

    # Phase 1: discover endpoints. Forward captured_auth so the crawler
    # surfaces routes that 401 anonymously (e.g. /api/search behind login).
    try:
        crawl = await run_crawler(
            ctx.session, ctx.base, auth_headers=extra or None,
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("crawler failed during sqli_fuzz: %s", exc)
        return findings

    candidates = _candidate_query_endpoints(
        crawl, tuple(ctx.candidate_endpoints or ()),
    )
    if not candidates:
        return findings

    detect = _make_detect_fn()
    base = ctx.base.rstrip("/")

    # Phase 2: fuzz each candidate. param is part of the candidate tuple
    # but not used directly here (it's already embedded in path_template).
    for path_template, _param in candidates:
        url_template = (
            path_template
            if path_template.startswith(("http://", "https://"))
            else base + path_template
        )
        target_id = url_template.split("?", 1)[0]
        if target_id in seen_targets:
            continue

        try:
            results = await asyncio.wait_for(
                fuzz(
                    ctx.session,
                    url_template,
                    SQLI_PAYLOADS,
                    detect,
                    concurrency=6,
                    headers=extra or None,
                ),
                timeout=12,
            )
        except asyncio.TimeoutError:
            logger.debug("sqli_fuzz timed out on %s", target_id)
            continue
        except Exception as exc:  # noqa: BLE001
            logger.debug("fuzz error on %s: %s", target_id, exc)
            continue

        # Emit one finding per endpoint where ANY payload hit, not 34 per endpoint
        hits = [r for r in results if r.get("hit")]
        if hits:
            seen_targets.add(target_id)
            best = hits[0]
            findings.append(
                _emit(
                    target_id,
                    best["payload"],
                    best.get("body_snippet", "")[:200],
                )
            )

    return findings
