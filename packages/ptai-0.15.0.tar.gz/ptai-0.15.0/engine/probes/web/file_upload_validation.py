"""File upload validation probe.

Multi-shot probe targeting endpoints that accept file uploads. Sends a
small valid baseline first, then perturbs along three axes:

1. Oversized PDF (200 KB) with declared application/pdf -> MEDIUM if
   accepted (Juice Shop challenge #85, Upload Size).

2. Wrong extension/type (`exploit.exe`, octet-stream) -> HIGH if accepted
   (Juice Shop challenge #86, Upload Type).

3. Polyglot JPEG/PHP file (JPEG SOI markers prepended to a `<?php phpinfo(); ?>`
   payload) -> CRITICAL if accepted with image/jpeg content type. Real
   RCE risk if the same file is later served back from a path that runs
   PHP.

Probe walks a fixed list of upload endpoints (no crawler needed). Uses
a hand-rolled multipart/form-data body so we can post exact bytes. We
try both `file` and `filename` form field names because Juice Shop and
similar Express apps disagree on the convention.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

import aiohttp

from engine.probes import ProbeContext, registry

logger = logging.getLogger("pentest-ai.probes.web.file_upload_validation")

_USER_AGENT = "pentest-ai/0.11 (+https://pentestai.xyz)"
_BODY_TRUNCATE = 65000
_DEFAULT_TIMEOUT_S = 10.0
_BOUNDARY = "----ptaiUploadBoundary7MA4YWxkTrZu0gW"

ALWAYS_PROBED: tuple[str, ...] = (
    "/file-upload",
    "/api/Complaints",
    "/api/Memorys",
    "/uploads",
    "/api/upload",
    "/api/Files",
)

# Tiny valid-ish PDF: header byte sequence is enough for most validators.
BASELINE_PDF = b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF\n"

# 200 KB random-ish binary buffer. Deterministic so test snapshots stay stable.
OVERSIZED_PDF = b"%PDF-1.4\n" + (b"A" * (200 * 1024))

EXE_PAYLOAD = b"MZ\x90\x00" + (b"\x00" * 1020)  # ~1 KB, looks like a PE header

POLYGLOT_JPEG_PHP = b"\xff\xd8\xff\xe0" + b"\x00\x10JFIF\x00\x01" + b"<?php phpinfo(); ?>"

_FIELD_NAMES: tuple[str, ...] = ("file", "filename")


def _build_multipart(
    payload: bytes,
    *,
    field_name: str,
    filename: str,
    content_type: str,
) -> bytes:
    """Construct a multipart/form-data body with a single file field.

    Hand-rolled so we can attach exact bytes verbatim. aiohttp's FormData
    would re-encode and strip control bytes from the polyglot.
    """
    crlf = b"\r\n"
    parts = (
        f"--{_BOUNDARY}".encode(),
        f'Content-Disposition: form-data; name="{field_name}"; filename="{filename}"'.encode(),
        f"Content-Type: {content_type}".encode(),
        b"",
        payload,
        f"--{_BOUNDARY}--".encode(),
        b"",
    )
    return crlf.join(parts)


async def _post_multipart_file(
    session: aiohttp.ClientSession,
    url: str,
    filename: str,
    content_type: str,
    data: bytes,
) -> tuple[int, dict[str, str], str]:
    """POST a single file as multipart form-data trying both field names."""
    last: tuple[int, dict[str, str], str] = (0, {}, "")
    for field_name in _FIELD_NAMES:
        body = _build_multipart(
            data, field_name=field_name, filename=filename, content_type=content_type
        )
        headers = {
            "User-Agent": _USER_AGENT,
            "Content-Type": f"multipart/form-data; boundary={_BOUNDARY}",
            "Content-Length": str(len(body)),
            "Accept": "*/*",
        }
        timeout = aiohttp.ClientTimeout(total=_DEFAULT_TIMEOUT_S)
        try:
            async with session.post(url, data=body, headers=headers, timeout=timeout) as resp:
                text = await resp.text(errors="replace")
                status = resp.status
                hdrs = {k: v for k, v in resp.headers.items()}
                if status in (200, 201):
                    return status, hdrs, text[:_BODY_TRUNCATE]
                last = (status, hdrs, text[:_BODY_TRUNCATE])
        except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
            logger.debug("upload POST %s failed: %s", url, exc)
    return last


def _emit(
    target: str,
    severity: str,
    variant: str,
    detail: str,
    evidence: str,
) -> dict[str, Any]:
    return {
        "title": f"File upload validation ({variant}): {detail}",
        "severity": severity,
        "category": "input_validation",
        "target": target,
        "evidence": evidence[:512],
        "bug_class": "file_upload_bypass",
        "remediation": (
            "Enforce server-side file validation: cap upload size, allowlist "
            "extensions and MIME types, and verify magic bytes match the "
            "declared type. Never serve uploaded files from a path that "
            "executes scripts."
        ),
    }


def _accepted(status: int) -> bool:
    return status in (200, 201)


def _looks_like_spa_shell(body: str, shell: str) -> bool:
    """True when an upload-acceptance response is just the SPA catch-all.

    SPAs (Angular, React) return 200 + index.html for any unknown path
    with any body, including multipart uploads. Without this guard the
    probe flags hundreds of phantom upload endpoints — every wordlist
    path that discovery seeded reports "Server accepted .exe upload"
    because the SPA happily 200s with index.html. We compare the upload
    response to a known-shell fingerprint captured at probe start.
    """
    if not shell or not body:
        return False
    if abs(len(body) - len(shell)) > max(64, len(shell) // 10):
        return False
    return body[:500] == shell[:500]


@registry.probe(
    name="web.file_upload_validation",
    bug_class="file_upload_bypass",
    severity_max="critical",
    owasp="A04:2021",
    runtime_budget_s=15.0,
    tags=("anonymous", "high-roi", "destructive-low", "upload"),
    requires_auth=False,
)
async def probe_file_upload_validation(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Four-shot upload probe: baseline, oversize, wrong-type, polyglot."""
    candidates = ctx.candidate_endpoints or ALWAYS_PROBED
    base = ctx.base.rstrip("/")
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    # Fingerprint the SPA catch-all body (if any) so we can ignore
    # "uploads accepted" on paths that are really just the SPA 200ing
    # an unknown path with index.html. Best-effort: if the fingerprint
    # fetch fails (e.g. heavily mocked test environment with no GET
    # handler), continue without the dedup guard.
    from engine.probes.primitives import http_get as _http_get
    try:
        _, _, _spa_shell = await _http_get(
            ctx.session,
            base + "/this-path-definitely-does-not-exist-ptai-canary",
        )
    except Exception:  # noqa: BLE001
        _spa_shell = ""

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        # Step 1: baseline. Skip endpoint if it doesn't exist or rejects everything.
        b_status, _b_headers, b_body = await _post_multipart_file(
            ctx.session, url, "baseline.pdf", "application/pdf", BASELINE_PDF
        )
        if b_status in (0, 404):
            continue
        # If even the baseline response looks like the SPA shell, every
        # subsequent shot on this URL would too — skip the endpoint.
        if _looks_like_spa_shell(b_body, _spa_shell):
            continue

        # Step 2: oversized PDF (size validation).
        s_status, _s_headers, s_body = await _post_multipart_file(
            ctx.session, url, "oversized.pdf", "application/pdf", OVERSIZED_PDF
        )
        if _accepted(s_status):
            key = (url, "oversized")
            if key not in seen:
                seen.add(key)
                findings.append(
                    _emit(
                        url,
                        "medium",
                        "oversized",
                        "Server accepted a 200 KB upload; size validation missing.",
                        s_body,
                    )
                )

        # Step 3: wrong extension/type.
        t_status, _t_headers, t_body = await _post_multipart_file(
            ctx.session, url, "exploit.exe", "application/octet-stream", EXE_PAYLOAD
        )
        if _accepted(t_status):
            key = (url, "wrong_type")
            if key not in seen:
                seen.add(key)
                findings.append(
                    _emit(
                        url,
                        "high",
                        "wrong_type",
                        "Server accepted .exe upload; extension/type allowlist missing.",
                        t_body,
                    )
                )

        # Step 4: polyglot JPEG/PHP. Sent with Content-Type: image/jpeg.
        p_status, _p_headers, p_body = await _post_multipart_file(
            ctx.session, url, "polyglot.jpg", "image/jpeg", POLYGLOT_JPEG_PHP
        )
        if _accepted(p_status):
            key = (url, "polyglot")
            if key not in seen:
                seen.add(key)
                findings.append(
                    _emit(
                        url,
                        "critical",
                        "polyglot",
                        "Server accepted a JPEG/PHP polyglot; potential RCE if served back.",
                        p_body,
                    )
                )

    return findings
