"""Two-user authorization-differential probe (BOLA + BFLA).

HackerOne 2025 paid out 23% more on IDOR than the year prior; it is the
single biggest rising paid bug class. This probe goes beyond the existing
single-user authenticated-IDOR shape by running a TWO-user differential:

  * User A and user B are distinct accounts. If only one captured_auth
    is present in `ctx.captured_auth`, the probe registers a second
    account via `acquire_test_auth()` so the differential always has
    two credentials.
  * For each common object-collection root, walk known IDs and try
    cross-user reads/writes:
        BOLA-read:  A GETs a record owned by B
        BOLA-write: A PUTs an update onto a record owned by B
        BFLA:       A POSTs to admin-shape endpoints
  * Detection: status 200/201 plus a body that is not an obvious error
    is enough to flag.

Severity: critical. Either kind of hit is direct PII leak or privilege
escalation, both pay top of the bounty band.
"""
from __future__ import annotations

from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.auth.runner import acquire_test_auth, auth_headers
from engine.probes.primitives import http_get, http_post_json, http_put_json

# Object collection roots; trailing slash so we can append numeric ids
# without ambiguity. Common across REST APIs and Juice Shop variants.
_OBJECT_PREFIXES: tuple[str, ...] = (
    "/api/orders/",
    "/api/messages/",
    "/api/baskets/",
    "/api/profile/",
    "/api/users/",
    "/api/files/",
    "/api/Baskets/",
    "/api/Orders/",
)

# IDs to walk per prefix. Small range keeps runtime in check.
_IDS: tuple[int, ...] = (1, 2, 3)

# Admin-shape function-level endpoints. POSTing a benign payload here
# from a non-admin token should be rejected. Acceptance = BFLA.
_ADMIN_ENDPOINTS: tuple[str, ...] = (
    "/api/admin/users",
    "/api/admin/products",
    "/api/admin/orders",
    "/api/admin/roles",
    "/admin/api/users",
)

_BENIGN_UPDATE = {"note": "ptai-canary"}
_BENIGN_CREATE = {"name": "ptai-canary", "active": False}

# Markers indicating an error or rejection page; presence in response
# body weakens a 200 hit and short-circuits the finding.
_ERROR_MARKERS: tuple[str, ...] = (
    "forbidden",
    "unauthorized",
    "access denied",
    "not allowed",
)


def _looks_like_error(body: str) -> bool:
    body_lc = body.lower()
    return any(m in body_lc for m in _ERROR_MARKERS)


def _emit_bola_read(target: str, evidence: str) -> dict[str, Any]:
    return {
        "title": "BOLA: cross-user read by authenticated low-priv account",
        "severity": "critical",
        "category": "access_control",
        "target": target,
        "evidence": evidence,
        "bug_class": "idor",
        "owasp": "A01:2021",
        "remediation": (
            "Scope reads to the principal's user_id. Return 403 (or 404) "
            "for objects the caller does not own."
        ),
    }


def _emit_bola_write(target: str, evidence: str) -> dict[str, Any]:
    return {
        "title": "BOLA write: cross-user update by authenticated low-priv account",
        "severity": "critical",
        "category": "access_control",
        "target": target,
        "evidence": evidence,
        "bug_class": "idor",
        "owasp": "A01:2021",
        "remediation": (
            "Enforce object ownership on every mutating handler. Return "
            "403 when the caller does not own the target record."
        ),
    }


def _emit_bfla(target: str, evidence: str) -> dict[str, Any]:
    return {
        "title": "BFLA: admin-shape endpoint accepted non-admin token",
        "severity": "critical",
        "category": "access_control",
        "target": target,
        "evidence": evidence,
        "bug_class": "idor",
        "owasp": "A01:2021",
        "remediation": (
            "Gate admin endpoints behind a dedicated authorization check, "
            "not just authentication. Reject non-admin tokens with 403."
        ),
    }


async def _bola_reads(
    ctx: ProbeContext,
    headers_a: dict[str, str],
) -> list[dict[str, Any]]:
    """As user A, walk object IDs and flag 200s with non-error bodies."""
    findings: list[dict[str, Any]] = []
    base = ctx.base
    seen: set[str] = set()

    for prefix in _OBJECT_PREFIXES:
        for rid in _IDS:
            url = f"{base}{prefix}{rid}"
            status, _, body = await http_get(ctx.session, url, headers=headers_a)
            if status != 200 or not body or _looks_like_error(body):
                continue
            if url in seen:
                continue
            seen.add(url)
            findings.append(
                _emit_bola_read(
                    url, f"status=200 body_snippet={body[:200]}"
                )
            )
    return findings


async def _bola_writes(
    ctx: ProbeContext,
    headers_a: dict[str, str],
) -> list[dict[str, Any]]:
    """As user A, PUT a benign update onto cross-user ids."""
    findings: list[dict[str, Any]] = []
    base = ctx.base
    seen: set[str] = set()

    for prefix in _OBJECT_PREFIXES:
        for rid in _IDS:
            url = f"{base}{prefix}{rid}"
            status, _, body = await http_put_json(
                ctx.session, url, _BENIGN_UPDATE, headers=headers_a
            )
            if status not in (200, 201, 204):
                continue
            if body and _looks_like_error(body):
                continue
            if url in seen:
                continue
            seen.add(url)
            findings.append(
                _emit_bola_write(
                    url, f"status={status} body_snippet={body[:200]}"
                )
            )
    return findings


async def _bfla_admin(
    ctx: ProbeContext,
    headers_a: dict[str, str],
) -> list[dict[str, Any]]:
    """POST a benign payload to admin endpoints with a non-admin token."""
    findings: list[dict[str, Any]] = []
    base = ctx.base
    seen: set[str] = set()

    for path in _ADMIN_ENDPOINTS:
        url = f"{base}{path}"
        status, _, body = await http_post_json(
            ctx.session, url, _BENIGN_CREATE, headers=headers_a
        )
        if status not in (200, 201):
            continue
        if body and _looks_like_error(body):
            continue
        if url in seen:
            continue
        seen.add(url)
        findings.append(
            _emit_bfla(url, f"status={status} body_snippet={body[:200]}")
        )
    return findings


async def _ensure_two_auths(
    ctx: ProbeContext,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Return (auth_a, auth_b). Acquire a second account when needed.

    The first auth is always taken from ``ctx.captured_auth``. The
    second is read from ``ctx.extras['captured_auth_b']`` if present;
    otherwise the probe boots a new test account so the differential
    always has two distinct credentials.
    """
    auth_a = ctx.captured_auth
    if auth_a is None:
        return None, None

    extra_b = ctx.extras.get("captured_auth_b") if ctx.extras else None
    if isinstance(extra_b, dict) and extra_b.get("auth_value"):
        return auth_a, extra_b

    auth_b = await acquire_test_auth(ctx.session, ctx.base)
    return auth_a, auth_b


@registry.probe(
    name="web.idor_authz_differential",
    bug_class="idor",
    severity_max="critical",
    owasp="A01:2021",
    runtime_budget_s=15.0,
    tags=("authenticated", "idor", "differential", "high-roi"),
    requires_auth=True,
)
async def probe_idor_authz_differential(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Two-account BOLA/BFLA differential walker."""
    auth_a, _auth_b = await _ensure_two_auths(ctx)
    if auth_a is None:
        return []
    headers_a = auth_headers(auth_a)
    if not headers_a:
        return []

    findings: list[dict[str, Any]] = []
    findings.extend(await _bola_reads(ctx, headers_a))
    findings.extend(await _bola_writes(ctx, headers_a))
    findings.extend(await _bfla_admin(ctx, headers_a))
    return findings
