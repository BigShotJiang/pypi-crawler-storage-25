"""Forced-error stack-trace disclosure probe.

OWASP Juice Shop challenge #27 (Error Handling): provoke an error that
isn't gracefully handled. The web app leaks an Express stack trace with
file paths in the error response.

Probe sends malformed payloads to JSON-accepting endpoints and looks for
stack-trace fingerprints (Node, Python, Java, .NET) in the body that
weren't present in the baseline.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get, http_post_json

logger = logging.getLogger("pentest-ai.probes.web.forced_error")

MALFORMED_PAYLOADS: tuple[tuple[str, str, dict[str, Any] | str], ...] = (
    # name, content_type-ish hint, payload
    ("truncated_json", "json", '{"email":'),
    ("array_instead_of_object", "json", "[1,2,3]"),
    ("unicode_bomb", "json", {"name": " " * 10000}),
    ("null_byte_in_field", "json", {"email": "x\x00y@example.com"}),
    ("nested_recursion", "json", {"a": {"a": {"a": {"a": {"a": {"a": {"a": 1}}}}}}}),
)

ALWAYS_PROBED: tuple[str, ...] = (
    "/api/Users/",
    "/api/Feedbacks",
    "/api/Products/1",
    "/rest/products/1",
    "/api/Complaints",
    "/api/Orders",
    "/api/BasketItems",
)

# Stack-trace fingerprints from common runtimes.
TRACE_MARKERS_HIGH: tuple[str, ...] = (
    # Path-disclosing markers (highest signal): file paths leak
    "node_modules/express/",
    "/var/www/",
    "/usr/local/lib/",
    "/home/administrator/",
    "/home/runner/",
    "C:\\\\",
    "C:\\Users\\",
    "/Users/",  # macOS
)

TRACE_MARKERS_MEDIUM: tuple[str, ...] = (
    # Framework / runtime fingerprints without paths
    "at Object.",
    "at Module._compile",
    "at process.processTicksAndRejections",
    "Traceback (most recent call last)",
    "java.lang.",
    "System.IO.",
    "TypeError:",
    "SyntaxError:",
    "ReferenceError:",
    "RangeError:",
    "ENOENT",
    "EADDRINUSE",
    "Error: Unexpected token",
    "JsonParseError",
)


def _classify_trace(body: str, baseline: str) -> tuple[str, str] | None:
    """Return (severity, marker) when a fingerprint appears in body but not baseline."""
    for marker in TRACE_MARKERS_HIGH:
        if marker in body and marker not in baseline:
            return "high", marker
    for marker in TRACE_MARKERS_MEDIUM:
        if marker in body and marker not in baseline:
            return "medium", marker
    return None


def _emit(target: str, severity: str, payload_name: str, marker: str) -> dict[str, Any]:
    return {
        "title": f"Error handler leaks stack trace on {target}",
        "severity": severity,
        "category": "exposure",
        "target": target,
        "evidence": f"malformation={payload_name} marker={marker[:60]}",
        "bug_class": "exposed_dev",
        "remediation": (
            "Catch and log errors server-side; return a generic 500 to clients. "
            "Disable Express's default error handler in production."
        ),
    }


async def _post_raw(
    session: Any,
    url: str,
    body: str,
    content_type: str = "application/json",
) -> tuple[int, str]:
    """POST a raw string body (used for truncated/malformed JSON)."""
    headers = {"Content-Type": content_type, "User-Agent": "pentest-ai/0.11"}
    try:
        async with session.post(url, data=body, headers=headers, timeout=8) as resp:
            text = await resp.text(errors="replace")
            return resp.status, text[:65000]
    except Exception as exc:  # noqa: BLE001
        logger.debug("post_raw failed on %s: %s", url, exc)
        return 0, ""


@registry.probe(
    name="web.forced_error",
    bug_class="exposed_dev",
    severity_max="high",
    owasp="A05:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "fast", "info-disclosure"),
    requires_auth=False,
)
async def probe_forced_error(ctx: ProbeContext) -> list[dict[str, Any]]:
    """Send malformed payloads, look for stack traces in response.

    SPA-style catch-all routers (Angular, React, Vue) return the same
    error handler output for every unknown path, so a naive per-URL
    emit can produce N copies of the same vuln. We dedup by the
    (severity, marker) pair: the FIRST URL where a given fingerprint
    fires gets the finding; subsequent URLs that produce the same
    marker are silently skipped. The underlying defect — unhandled
    error -> framework stack trace -> path disclosure — is the same
    server-wide regardless of which path tripped it.
    """
    findings: list[dict[str, Any]] = []
    seen_targets: set[str] = set()
    seen_markers: set[tuple[str, str]] = set()
    base = ctx.base.rstrip("/")
    candidates = ctx.candidate_endpoints or ALWAYS_PROBED

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        # Baseline: clean GET
        b_status, _, b_body = await http_get(ctx.session, url)
        if b_status == 0 or b_status == 404:
            continue
        if url in seen_targets:
            continue

        # Try each malformation
        for name, _hint, payload in MALFORMED_PAYLOADS:
            try:
                if isinstance(payload, str):
                    status, body = await asyncio.wait_for(
                        _post_raw(ctx.session, url, payload),
                        timeout=8,
                    )
                else:
                    status, _, body = await asyncio.wait_for(
                        http_post_json(ctx.session, url, payload),
                        timeout=8,
                    )
            except (asyncio.TimeoutError, Exception):  # noqa: BLE001
                continue

            classified = _classify_trace(body, b_body)
            if classified is not None:
                severity, marker = classified
                seen_targets.add(url)
                marker_key = (severity, marker)
                if marker_key in seen_markers:
                    break  # same trace on a different path — already emitted
                seen_markers.add(marker_key)
                findings.append(_emit(url, severity, name, marker))
                break  # one finding per endpoint is enough

    return findings
