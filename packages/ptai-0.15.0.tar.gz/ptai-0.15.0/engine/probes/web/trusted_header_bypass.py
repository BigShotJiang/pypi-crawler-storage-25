"""Trusted-proxy header bypass probe.

Common misconfiguration: an app fronted by an LB / API gateway trusts
headers like `X-Forwarded-User`, `X-Original-User`, `X-Real-IP`,
`X-Forwarded-For` for auth/authz decisions. If those headers reach the
backend without LB validation, any external caller can spoof them.

Algorithm:

1. Identify endpoints that 401/403 anonymously (from ctx.candidate_endpoints
   plus a hardcoded admin/internal path list).
2. For each, replay with each of the bypass-header sets.
3. If a 401/403 flips to 200 with non-shell body, finding fires —
   critical severity for admin/internal paths, high otherwise.

Runs unauthenticated by design — the probe's whole point is testing
whether headers alone unlock protected content.
"""
from __future__ import annotations

from typing import Any

import aiohttp

from engine.probes import ProbeContext, registry
from engine.probes.primitives import http_get

_DEFAULT_TARGETS: tuple[str, ...] = (
    "/admin", "/admin/", "/admin/users", "/admin/dashboard",
    "/internal", "/internal/", "/internal/whoami", "/internal/db-stats",
    "/_admin", "/_internal",
    "/api/admin", "/api/internal", "/api/secrets", "/api/users",
    "/actuator/env", "/actuator/heapdump",
    "/console", "/_console",
)

_BYPASS_HEADER_SETS: tuple[dict[str, str], ...] = (
    {"X-Forwarded-User": "admin"},
    {"X-Forwarded-User": "root"},
    {"X-Original-User": "admin"},
    {"X-Remote-User": "admin"},
    {"X-Forwarded-For": "127.0.0.1"},
    {"X-Forwarded-Host": "localhost"},
    {"X-Real-IP": "127.0.0.1"},
    {"X-Authenticated-User": "admin"},
)

_HIGHRISK_PREFIXES: tuple[str, ...] = (
    "/admin", "/_admin", "/internal", "/_internal", "/api/admin",
    "/api/internal", "/api/secrets", "/actuator",
)


def _is_highrisk(path: str) -> bool:
    return any(path.startswith(p) for p in _HIGHRISK_PREFIXES)


def _is_shell_or_empty(body: str) -> bool:
    if not body:
        return True
    stripped = body.lstrip().lower()
    return bool(stripped.startswith("<") and len(body) <= 800)


@registry.probe(
    name="web.trusted_header_bypass",
    bug_class="auth_bypass",
    severity_max="critical",
    owasp="A07:2021",
    runtime_budget_s=10.0,
    tags=("anonymous", "high-roi", "fast"),
    requires_auth=False,
)
async def probe_trusted_header_bypass(ctx: ProbeContext) -> list[dict[str, Any]]:
    """For each gated path, try each bypass header set. Emit on 401→200 flip."""
    base = ctx.base.rstrip("/")
    candidates: list[str] = list(_DEFAULT_TARGETS)
    candidates.extend(ctx.candidate_endpoints or ())
    candidates.extend(ctx.endpoint_hints or ())

    findings: list[dict[str, Any]] = []
    seen: set[str] = set()

    # Use a fresh cookie-less session so any caller-supplied session
    # state can't authenticate the requests. We need true anonymous
    # baseline + true header-only attempts to attribute results
    # correctly (same FP fix as the JWT alg:none probe).
    async with aiohttp.ClientSession(cookie_jar=aiohttp.DummyCookieJar()) as fresh:
        for path in candidates:
            if path in seen:
                continue
            seen.add(path)
            url = path if path.startswith(("http://", "https://")) else base + path

            anon_status, _, _ = await http_get(fresh, url)
            if anon_status not in (401, 403):
                continue

            for header_set in _BYPASS_HEADER_SETS:
                try_status, _, try_body = await http_get(fresh, url, headers=header_set)
                if try_status != 200 or _is_shell_or_empty(try_body):
                    continue

                severity = "critical" if _is_highrisk(path) else "high"
                hdr_str = ", ".join(f"{k}={v}" for k, v in header_set.items())
                findings.append({
                    "title": f"Trusted-header bypass on {path} via {hdr_str}",
                    "severity": severity,
                    "category": "authentication",
                    "bug_class": "auth_bypass",
                    "target": url,
                    "evidence": (
                        f"Anonymous GET {url} -> {anon_status}. With "
                        f"{hdr_str} -> 200 with non-shell body. The "
                        f"backend is trusting a header that any external "
                        f"caller can set."
                    ),
                    "owasp_category": "A07:2021",
                    "remediation": (
                        "Either strip these headers at the LB/edge (so "
                        "they only ever come from trusted upstream) or "
                        "use mTLS/signed-token auth between the edge "
                        "and backend instead of free-text headers. "
                        "Never derive identity or authorization from a "
                        "header the client can rewrite."
                    ),
                })
                break  # one bypass per path is enough

    return findings
