"""Recon primitives for the probe pipeline.

The recon subpackage holds exploration logic that runs *before* the 26
attack probes. Today there is one module: a depth-1 HTML/JS/OpenAPI
crawler that feeds discovered paths into ProbeContext.candidate_endpoints.
"""
from __future__ import annotations

from engine.probes.recon.crawler import (
    CrawlResult,
    parse_html,
    parse_js,
    parse_openapi,
    parse_robots,
    parse_sitemap,
    run_crawler,
)

__all__ = [
    "CrawlResult",
    "parse_html",
    "parse_js",
    "parse_openapi",
    "parse_robots",
    "parse_sitemap",
    "run_crawler",
]
