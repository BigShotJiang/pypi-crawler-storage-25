"""Lightweight exploration phase for ptai.

The 26 attack probes today walk hardcoded path lists. They miss endpoints
that only show up after parsing the SPA's index page, its bundled JS,
or an OpenAPI doc. CAI and HexStrike find more bugs partly because they
explore first, attack second. This module is the missing first half.

Scope is deliberately narrow:

1. GET `/` and parse anchors, forms, scripts, images, link tags.
2. Fetch every same-origin JS bundle and rip out URL string literals
   (`/api/...`, `/rest/...`, `/v1/...`), `fetch`/`axios`/`$.ajax/.get/.post`
   call paths, and `apiUrl`/`baseURL`/`endpoints` config keys.
3. Probe common API discovery endpoints (Swagger, OpenAPI, GraphQL).
4. Pull URLs from `/sitemap.xml` and `/robots.txt`.

No recursive crawl. Depth is capped at 1 so the whole pass stays under
~15 seconds on Juice Shop. Robots.txt is treated as input only, never
as a gate.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urljoin, urlparse

import aiohttp
from bs4 import BeautifulSoup

from engine.probes.primitives import http_get

logger = logging.getLogger("pentest-ai.probes.recon.crawler")

# SPA index pages and JS bundles routinely exceed the 65 KB cap used by
# probes. The crawler keeps the wider envelope so script-tag extraction
# and JS literal scanning don't silently drop the back half of the doc.
_CRAWLER_BODY_MAX = 2 * 1024 * 1024
_CRAWLER_TIMEOUT = aiohttp.ClientTimeout(total=8)
_USER_AGENT = "pentest-ai/0.11 (+https://pentestai.xyz)"


async def _http_get_full(
    session: aiohttp.ClientSession,
    url: str,
    extra_headers: dict[str, str] | None = None,
) -> tuple[int, str]:
    """Crawler-local GET that returns up to 2 MiB of body, no redirects.

    `engine.probes.primitives.http_get` truncates at 65 KB, which loses
    the script tags on every modern SPA. This helper exists only inside
    the crawler so probe-side consumers keep the standard short-body
    envelope.

    `extra_headers` lets the caller inject auth headers (Authorization
    Bearer, custom session headers, etc.) so the crawler can discover
    routes that require authentication. The User-Agent default is
    preserved unless the caller explicitly overrides it.
    """
    h = {"User-Agent": _USER_AGENT}
    if extra_headers:
        h.update(extra_headers)
    try:
        async with session.get(
            url, headers=h, allow_redirects=False, timeout=_CRAWLER_TIMEOUT
        ) as resp:
            body = await resp.text(errors="replace")
            return resp.status, body[:_CRAWLER_BODY_MAX]
    except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
        logger.debug("crawler GET %s failed: %s", url, exc)
        return 0, ""

# Common API discovery endpoints. Order matters only loosely; all are tried.
_API_DISCOVERY_PATHS: tuple[str, ...] = (
    "/swagger.json",
    "/api-docs",
    "/api-docs/swagger.json",
    "/openapi.json",
    "/v2/api-docs",
    "/v3/api-docs",
    "/graphql",
)

# JS literal extractors. Conservative: anchored on the leading slash so we
# avoid catching CSS class fragments or comment text.
_JS_URL_LITERAL = re.compile(r"""['"`](/(?:api|rest|v\d+|graphql)/[A-Za-z0-9_\-./{}:]*)['"`]""")
_JS_FETCH_CALL = re.compile(
    r"""(?:fetch|axios(?:\.(?:get|post|put|delete|patch))?|\$\.(?:ajax|get|post))\s*\(\s*['"`]([^'"`)]+)['"`]"""
)
_JS_CONFIG_URL = re.compile(
    r"""['"]?(?:apiUrl|baseURL|baseUrl|endpoints?|API_URL|API_BASE)['"]?\s*[:=]\s*['"`]([^'"`]+)['"`]"""
)


@dataclass
class CrawlResult:
    """Structured output of a single crawl pass.

    All four URL-bearing fields are sets so callers can union results
    from multiple sources (HTML, JS, OpenAPI, sitemap) without writing
    dedup logic. `forms` is a list because each form is a distinct dict
    with action/method/fields and there is no useful equality on it.
    """

    discovered_paths: set[str] = field(default_factory=set)
    discovered_js: set[str] = field(default_factory=set)
    api_paths: set[str] = field(default_factory=set)
    forms: list[dict[str, Any]] = field(default_factory=list)

    def merge(self, other: CrawlResult) -> None:
        """Union URL sets and extend forms list. Mutates self."""
        self.discovered_paths |= other.discovered_paths
        self.discovered_js |= other.discovered_js
        self.api_paths |= other.api_paths
        self.forms.extend(other.forms)


def _same_origin(base: str, url: str) -> bool:
    """True if url is same-origin as base or a relative path."""
    if url.startswith("/"):
        return True
    if not url.startswith(("http://", "https://")):
        return True  # relative
    bp = urlparse(base)
    up = urlparse(url)
    return (bp.scheme, bp.netloc) == (up.scheme, up.netloc)


def _to_path(base: str, url: str) -> str:
    """Normalize a URL/href to a same-origin path. Cross-origin returns ""."""
    if url.startswith(("#", "mailto:", "tel:", "javascript:")):
        return ""
    if url.startswith(("http://", "https://")):
        if not _same_origin(base, url):
            return ""
        p = urlparse(url)
        return p.path + (f"?{p.query}" if p.query else "")
    if url.startswith("/"):
        return url
    # Relative path. Resolve against base's root.
    return urljoin(base + "/", url).replace(base, "", 1) or "/"


def parse_html(base: str, html: str) -> CrawlResult:
    """Extract anchors, forms, scripts, images, links from one HTML doc.

    Robust to malformed input: BeautifulSoup with html.parser tolerates
    unclosed tags, stray markup, and non-HTML payloads (returns empty).
    """
    result = CrawlResult()
    if not html:
        return result
    try:
        soup = BeautifulSoup(html, "html.parser")
    except Exception as exc:  # pragma: no cover - bs4 html.parser ~never raises
        logger.debug("parse_html: BeautifulSoup failed: %s", exc)
        return result

    for a in soup.find_all("a", href=True):
        path = _to_path(base, a["href"])
        if path:
            result.discovered_paths.add(path)

    for img in soup.find_all("img", src=True):
        path = _to_path(base, img["src"])
        if path:
            result.discovered_paths.add(path)

    for link in soup.find_all("link", href=True):
        path = _to_path(base, link["href"])
        if path:
            result.discovered_paths.add(path)

    for script in soup.find_all("script", src=True):
        src = script["src"]
        if _same_origin(base, src):
            path = _to_path(base, src)
            if path and path.endswith((".js", ".mjs")) or "/js/" in path or "main." in path:
                result.discovered_js.add(path)
            elif path:
                # Also add to general paths in case it's a dynamic JS endpoint.
                result.discovered_js.add(path)

    for form in soup.find_all("form"):
        action = form.get("action") or ""
        method = (form.get("method") or "GET").upper()
        fields: list[str] = []
        for inp in form.find_all(["input", "textarea", "select"]):
            name = inp.get("name")
            if name:
                fields.append(name)
        action_path = _to_path(base, action) if action else "/"
        result.forms.append(
            {"action": action_path or "/", "method": method, "fields": fields}
        )
        if action_path:
            result.discovered_paths.add(action_path)

    return result


def parse_js(js: str) -> set[str]:
    """Extract API path literals from a JS source string.

    Returns a set of paths. Conservative: only matches paths that begin
    with `/api`, `/rest`, `/v\\d+`, `/graphql`, or appear in a recognised
    fetch/axios/jQuery call or config key.
    """
    paths: set[str] = set()
    if not js:
        return paths
    for m in _JS_URL_LITERAL.finditer(js):
        paths.add(m.group(1))
    for m in _JS_FETCH_CALL.finditer(js):
        candidate = m.group(1)
        if candidate.startswith("/") or candidate.startswith(("http://", "https://")):
            paths.add(candidate)
    for m in _JS_CONFIG_URL.finditer(js):
        candidate = m.group(1)
        if candidate.startswith("/") or candidate.startswith(("http://", "https://")):
            paths.add(candidate)
    return paths


def parse_openapi(body: str) -> set[str]:
    """Extract path templates from an OpenAPI/Swagger JSON document.

    Tolerates malformed JSON (returns empty set) and missing `paths`
    key. Both Swagger 2.0 and OpenAPI 3.x put route templates under
    `paths`.
    """
    if not body:
        return set()
    try:
        doc = json.loads(body)
    except (json.JSONDecodeError, ValueError) as exc:
        logger.debug("parse_openapi: JSON decode failed: %s", exc)
        return set()
    if not isinstance(doc, dict):
        return set()
    paths_obj = doc.get("paths")
    if not isinstance(paths_obj, dict):
        return set()
    base_path = doc.get("basePath", "") or ""
    out: set[str] = set()
    for path in paths_obj:
        if not isinstance(path, str):
            continue
        full = (base_path.rstrip("/") + path) if base_path else path
        if not full.startswith("/"):
            full = "/" + full
        out.add(full)
    return out


def parse_sitemap(xml_body: str) -> set[str]:
    """Extract <loc> URLs from a sitemap.xml. Tolerates malformed XML."""
    if not xml_body:
        return set()
    try:
        # Strip default XML namespace so .find/.iter work without prefixes.
        cleaned = re.sub(r'\sxmlns="[^"]+"', "", xml_body, count=1)
        root = ET.fromstring(cleaned)
    except ET.ParseError as exc:
        logger.debug("parse_sitemap: XML parse failed: %s", exc)
        return set()
    out: set[str] = set()
    for loc in root.iter("loc"):
        if loc.text:
            out.add(loc.text.strip())
    return out


def parse_robots(body: str) -> set[str]:
    """Pull Allow/Disallow path lists out of robots.txt. Input only, not a gate."""
    out: set[str] = set()
    if not body:
        return out
    for line in body.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip().lower()
        value = value.strip()
        if (
            key in ("allow", "disallow", "sitemap")
            and value
            and value.startswith(("http://", "https://", "/"))
        ):
            out.add(value)
    return out


async def run_crawler(
    session: aiohttp.ClientSession,
    base: str,
    auth_headers: dict[str, str] | None = None,
) -> CrawlResult:
    """Execute one crawl pass against `base`. Depth-1, no recursion.

    `auth_headers` lets callers run the crawler authenticated. When
    `meta.crawl` has captured a session token from a prior probe it
    forwards those headers here, so routes that 401 anonymously
    (admin pages, /api/users, /internal/*) get discovered and added
    to memory.endpoints_seen. Without this, the crawler would only
    surface public-facing paths and the rest of the engagement's
    probes would never see authenticated targets.

    Returns a merged CrawlResult. Never raises on malformed responses;
    errors are logged at DEBUG and the offending source contributes
    nothing to the result.
    """
    base = base.rstrip("/")
    result = CrawlResult()
    headers = auth_headers or None

    # 1. Index page. Use the wider-envelope GET so we don't drop the
    # back half of large SPA index docs (script tags often live there).
    status, body = await _http_get_full(session, base + "/", extra_headers=headers)
    if status and body:
        html_result = parse_html(base, body)
        result.merge(html_result)

    # 2. Same-origin JS bundles (depth-1, no recursion into more JS).
    js_targets = list(result.discovered_js)
    for js_path in js_targets:
        url = js_path if js_path.startswith(("http://", "https://")) else base + js_path
        if not _same_origin(base, url):
            continue
        js_status, js_body = await _http_get_full(session, url, extra_headers=headers)
        if js_status and js_body:
            for found in parse_js(js_body):
                if found.startswith("/"):
                    result.api_paths.add(found)
                elif found.startswith(("http://", "https://")) and _same_origin(base, found):
                    p = urlparse(found).path
                    if p:
                        result.api_paths.add(p)

    # 3. API discovery endpoints.
    for api_path in _API_DISCOVERY_PATHS:
        a_status, _, a_body = await http_get(session, base + api_path, headers=headers)
        if not a_status or not a_body:
            continue
        if api_path == "/graphql":
            # Existence is the signal; introspection lives in its own probe.
            result.api_paths.add(api_path)
            continue
        for found in parse_openapi(a_body):
            result.api_paths.add(found)

    # 4. Sitemap and robots.
    s_status, _, s_body = await http_get(session, base + "/sitemap.xml", headers=headers)
    if s_status and s_body:
        for url in parse_sitemap(s_body):
            path = _to_path(base, url)
            if path:
                result.discovered_paths.add(path)

    r_status, _, r_body = await http_get(session, base + "/robots.txt", headers=headers)
    if r_status and r_body:
        for entry in parse_robots(r_body):
            if entry.startswith("/"):
                result.discovered_paths.add(entry)

    return result
