"""Optional Scrapling-backed crawler for hardened web targets.

The default crawler at `engine.probes.recon.crawler` uses aiohttp and
cannot see content that only appears after JavaScript executes. It also
returns 0 endpoints on Cloudflare-protected sites because plain HTTP
gets a challenge page.

This module wraps Scrapling's StealthyFetcher to fix both gaps:

1. JS rendering picks up lazy-loaded SPA routes the static parser misses.
2. capture_xhr watches real fetch/XHR requests as they fire, so we get
   actual API endpoints instead of regexing JS source for literals.
3. solve_cloudflare bypasses Turnstile / Interstitial automatically.

Gated behind `pip install ptai[stealth]`. The base install never touches
Playwright. Callers should check `is_available()` first or catch the
ImportError raised by `run_stealth_crawler` when scrapling is missing.

The output is a `CrawlResult` (defined in crawler.py) so this module is
a drop-in replacement at the data-shape level. It is NOT a drop-in at
the call-site level: `run_crawler` takes an aiohttp session, this takes
no session because Scrapling manages its own browser context.
"""
from __future__ import annotations

import logging
import re
from urllib.parse import urlparse

from engine.probes.recon.crawler import CrawlResult, parse_html

logger = logging.getLogger("pentest-ai.probes.recon.stealth_crawler")

# Path patterns that look like API endpoints. Used to filter captured XHR
# down to the high-signal subset. Same regex the default crawler's JS
# scanner uses, so the two paths produce comparable results.
_API_PATH_RE = re.compile(r"^/(?:api|rest|v\d+|graphql)(?:/|$)")

# Cloudflare's longer challenge dance can take 30+ seconds. Default
# Scrapling timeout is 30 s, which fails partway through. 60 s gives
# headroom without making clean targets feel slow (network_idle is
# ~5 s on an unhardened SPA).
_STEALTH_TIMEOUT_MS = 60_000


def is_available() -> bool:
    """Return True if Scrapling is importable in the current environment."""
    try:
        import scrapling  # noqa: F401
    except ImportError:
        return False
    return True


def _extract_xhr_path(base_netloc: str, raw_url: object) -> str | None:
    """Pull a same-origin path out of a captured-XHR entry.

    Scrapling's `captured_xhr` items can be dicts or objects depending on
    the version. We accept both shapes. Returns the path (with query) or
    None if cross-origin / unparseable.
    """
    url: str | None = None
    if isinstance(raw_url, str):
        url = raw_url
    elif isinstance(raw_url, dict):
        url = raw_url.get("url")
    else:
        url = getattr(raw_url, "url", None)
    if not isinstance(url, str) or not url:
        return None
    try:
        parsed = urlparse(url)
    except ValueError:
        return None
    if parsed.netloc and parsed.netloc != base_netloc:
        return None
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    return path


async def run_stealth_crawler(
    base: str,
    *,
    solve_cloudflare: bool = True,
    headless: bool = True,
) -> CrawlResult:
    """Render `base` in a stealth headless browser and harvest endpoints.

    Returns a CrawlResult that callers can merge with one from the default
    crawler. Two sources contribute:

    1. Parsed HTML of the rendered page (anchors, forms, scripts, links).
       Reuses crawler.parse_html so the output format is consistent.
    2. Real network requests captured during page load that match the API
       path regex (api / rest / v\\d+ / graphql).

    Raises ImportError if scrapling is not installed. Callers should
    check `is_available()` first when they want a graceful fallback.
    """
    try:
        from scrapling.fetchers import StealthyFetcher
    except ImportError as exc:
        raise ImportError(
            "scrapling is required for stealth crawling. "
            "Install with `pip install ptai[stealth]`, then run "
            "`scrapling install --force` to download browser binaries."
        ) from exc

    base = base.rstrip("/")
    result = CrawlResult()
    base_netloc = urlparse(base).netloc

    try:
        page = await StealthyFetcher.async_fetch(
            base + "/",
            solve_cloudflare=solve_cloudflare,
            headless=headless,
            block_webrtc=True,
            network_idle=True,
            timeout=_STEALTH_TIMEOUT_MS,
            capture_xhr=r"/(?:api|rest|v\d+|graphql)/",
            google_search=False,
            block_ads=True,
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning("stealth_crawler: fetch failed for %s: %s", base, exc)
        return result

    if page is None:
        logger.debug("stealth_crawler: fetch returned None for %s", base)
        return result

    body = getattr(page, "body", None)
    if isinstance(body, bytes):
        body = body.decode("utf-8", errors="replace")
    if isinstance(body, str) and body:
        result.merge(parse_html(base, body))

    captured = getattr(page, "captured_xhr", None) or []
    for entry in captured:
        path = _extract_xhr_path(base_netloc, entry)
        if path and _API_PATH_RE.match(path):
            result.api_paths.add(path)

    logger.info(
        "stealth_crawler: %s -> %d paths, %d api, %d xhr captured",
        base,
        len(result.discovered_paths),
        len(result.api_paths),
        len(captured) if captured else 0,
    )
    return result
