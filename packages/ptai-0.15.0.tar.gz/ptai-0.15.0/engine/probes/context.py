"""ProbeContext: the single argument every probe takes.

Carries everything a probe needs: HTTP session, normalized base URL,
optionally captured auth from prior probes, and structured hints from
the recon phase. Immutable; helper methods return new copies.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any


def _normalize_base(target: str) -> str:
    if not target.startswith(("http://", "https://")):
        target = "http://" + target
    return target.rstrip("/")


@dataclass(frozen=True)
class ProbeContext:
    """Per-engagement state passed to every probe.

    Probes never mutate the context. Driver constructs once, passes by
    reference. Use `with_findings()` and `with_captured_auth()` to derive
    new contexts when later probes depend on earlier results.
    """

    session: Any
    base: str
    captured_auth: dict[str, Any] | None = None
    endpoint_hints: tuple[str, ...] = ()
    js_urls: tuple[str, ...] = ()
    candidate_endpoints: tuple[str, ...] = ()
    findings_so_far: tuple[dict[str, Any], ...] = ()
    extras: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # frozen=True means we have to bypass __setattr__ for normalization
        normalized = _normalize_base(self.base)
        if normalized != self.base:
            object.__setattr__(self, "base", normalized)

    def with_findings(self, findings: list[dict[str, Any]]) -> ProbeContext:
        """Return a new context with findings_so_far merged."""
        merged = self.findings_so_far + tuple(findings)
        return replace(self, findings_so_far=merged)

    def with_captured_auth(self, auth: dict[str, Any]) -> ProbeContext:
        """Return a new context with captured_auth replaced."""
        return replace(self, captured_auth=auth)
