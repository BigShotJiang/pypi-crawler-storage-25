"""Probe registry. Decorator-based, single source of truth.

Probes register via @registry.probe at import time. The driver, agent
loop, and benchmark harness all read from this registry. Adding a probe
means writing one decorated async function, no other wiring.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from engine.working_memory import BUG_CLASSES

# Severity ordering. severity_max is the highest severity a probe can emit.
_VALID_SEVERITIES: frozenset[str] = frozenset(
    {"info", "low", "medium", "high", "critical"}
)


@dataclass(frozen=True)
class ProbeSpec:
    """Frozen metadata for a registered probe.

    The decorator constructs this; the registry stores it; the driver
    reads it to dispatch probes and the agent loop reads it to render
    actions for the LLM.
    """

    name: str
    bug_class: str
    severity_max: str
    owasp: str
    requires: tuple[str, ...]
    runtime_budget_s: float
    tags: tuple[str, ...]
    requires_auth: bool
    fn: Callable[..., Any]


_PROBES: dict[str, ProbeSpec] = {}


def probe(
    *,
    name: str,
    bug_class: str,
    severity_max: str,
    owasp: str = "",
    requires: tuple[str, ...] = ("session", "base"),
    runtime_budget_s: float = 8.0,
    tags: tuple[str, ...] = (),
    requires_auth: bool = False,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Decorator that registers a probe with typed metadata.

    Validates bug_class against BUG_CLASSES (engine.working_memory) and
    severity_max against _VALID_SEVERITIES. Refuses duplicate names.
    """
    if bug_class not in BUG_CLASSES:
        raise ValueError(
            f"unknown bug_class {bug_class!r}; must be one of {sorted(BUG_CLASSES)}"
        )
    if severity_max not in _VALID_SEVERITIES:
        raise ValueError(
            f"severity_max {severity_max!r} invalid; must be one of "
            f"{sorted(_VALID_SEVERITIES)}"
        )

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        existing = _PROBES.get(name)
        # Re-registration is allowed when:
        #   1. Same function instance (registry.clear() then re-import)
        #   2. Same qualified name + module path (importlib.reload makes a
        #      new function object but the qualname/module are stable)
        # A different function with the same name and a different qualname
        # is a real conflict.
        if existing is not None and existing.fn is not fn:
            same_qualname = (
                getattr(existing.fn, "__qualname__", None)
                == getattr(fn, "__qualname__", None)
                and getattr(existing.fn, "__module__", None)
                == getattr(fn, "__module__", None)
            )
            if not same_qualname:
                raise ValueError(f"probe {name!r} already registered")
        _PROBES[name] = ProbeSpec(
            name=name,
            bug_class=bug_class,
            severity_max=severity_max,
            owasp=owasp,
            requires=requires,
            runtime_budget_s=runtime_budget_s,
            tags=tags,
            requires_auth=requires_auth,
            fn=fn,
        )
        return fn

    return decorator


def get(name: str) -> ProbeSpec | None:
    """Return the spec for a registered probe, or None."""
    return _PROBES.get(name)


def all(  # noqa: A001 - shadowing builtin is intentional API
    *,
    exclude_tags: tuple[str, ...] = (),
) -> list[ProbeSpec]:
    """Return every registered probe spec.

    ``exclude_tags`` lets callers skip probes that carry any of the given
    tags (e.g. ``("destructive-low",)`` for safe-mode sweeps). Default
    empty tuple is a no-op so existing call sites behave identically.
    """
    out: list[ProbeSpec] = []
    for spec in _PROBES.values():
        if exclude_tags and any(t in spec.tags for t in exclude_tags):
            continue
        out.append(spec)
    return out


def filter(  # noqa: A001 - shadowing builtin is intentional API
    *,
    bug_class: str | None = None,
    requires_auth: bool | None = None,
    tag: str | None = None,
    exclude_tags: tuple[str, ...] = (),
) -> list[ProbeSpec]:
    """Return probes matching all provided criteria.

    Any criterion left as None is ignored. ``exclude_tags`` skips probes
    carrying any of the given tags; default empty tuple is a no-op.
    """
    out: list[ProbeSpec] = []
    for spec in _PROBES.values():
        if bug_class is not None and spec.bug_class != bug_class:
            continue
        if requires_auth is not None and spec.requires_auth != requires_auth:
            continue
        if tag is not None and tag not in spec.tags:
            continue
        if exclude_tags and any(t in spec.tags for t in exclude_tags):
            continue
        out.append(spec)
    return out


def clear() -> None:
    """Remove every registered probe. Test-only helper."""
    _PROBES.clear()
