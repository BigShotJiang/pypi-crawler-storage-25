"""Authenticated probe runner foundation.

Detects auth surface, registers a fresh test user (or uses provided creds),
logs in, and returns a populated ``captured_auth`` dict that downstream
probes can inject into ``ProbeContext`` via ``ctx.with_captured_auth()``.

Public API: ``acquire_test_auth`` and ``auth_headers``.
"""
from __future__ import annotations

from engine.probes.auth.runner import acquire_test_auth, auth_headers

__all__ = ["acquire_test_auth", "auth_headers"]
