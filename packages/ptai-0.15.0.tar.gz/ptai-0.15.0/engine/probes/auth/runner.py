"""Reusable authenticated-session acquisition for probes.

Modern web apps gate the interesting attack surface (PII, admin actions,
business logic) behind login. The probe registry needs a single, reusable
way to bootstrap a real session so authenticated probes can run on any
target without each probe rolling its own signup + login dance.

Algorithm:

1. Try a list of common signup endpoints. POST a JSON body with email +
   password. Accept 200/201 as success. Some apps return the new user
   record plus a token in one shot; others require a follow-up login.

2. If signup did not return a token, POST to a list of common login
   endpoints with the same credentials. Walk the response JSON looking
   for a token at any of the known keys ("token", "access_token",
   "jwt", "id_token", or nested under "authentication.token", "data.*").

3. Verify the token works against ``/rest/user/whoami`` or ``/api/me``
   with ``Authorization: Bearer {token}``. Treat status 200 as success.

4. Return ``{"token": ..., "email": ..., "user_id": ..., "auth_header":
   "Authorization", "auth_value": "Bearer ..."}`` on success, ``None``
   on failure so the driver can fall back to unauthenticated mode.
"""
from __future__ import annotations

import json
import logging
import secrets
from typing import Any

import aiohttp

from engine.probes.primitives import http_get, http_post_json

logger = logging.getLogger("pentest-ai.probes.auth.runner")


SIGNUP_PATHS: tuple[str, ...] = (
    "/api/Users/",
    "/api/users/register",
    "/api/auth/register",
    "/api/v1/auth/register",
    "/api/register",
    "/auth/register",
    "/register",
)

LOGIN_PATHS: tuple[str, ...] = (
    "/rest/user/login",
    "/api/auth/login",
    "/api/v1/auth/login",
    "/api/login",
    "/auth/login",
    "/login",
)

WHOAMI_PATHS: tuple[str, ...] = (
    "/rest/user/whoami",
    "/api/me",
    "/api/v1/me",
    "/api/users/me",
    "/me",
)

# Keys (top-level or nested) that commonly hold an auth token.
TOKEN_KEYS: tuple[str, ...] = (
    "token",
    "access_token",
    "accessToken",
    "jwt",
    "id_token",
    "idToken",
)

# JSON paths to walk when a token might be nested. Each tuple is a chain
# of object keys, applied in order against the parsed body.
NESTED_TOKEN_PATHS: tuple[tuple[str, ...], ...] = (
    ("authentication", "token"),
    ("data", "token"),
    ("data", "access_token"),
    ("data", "accessToken"),
    ("data", "authentication", "token"),
    ("result", "token"),
    ("result", "access_token"),
)


def _generate_email() -> str:
    """Return a unique-per-call low-collision throwaway email."""
    return f"ptai-{secrets.token_hex(6)}@ptai-canary.example"


def _generate_password() -> str:
    """Return a high-entropy password that satisfies common policies."""
    return f"Ptai!{secrets.token_urlsafe(12)}"


def _parse_json(body: str) -> Any:
    """Best-effort JSON parse. Returns None on any failure."""
    if not body:
        return None
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None


def _extract_token(parsed: Any) -> str | None:
    """Find an auth token in a parsed JSON body. None if not present.

    Tries top-level keys, then a fixed set of nested key paths. Keeps
    matching cheap and predictable, no recursive walks.
    """
    if not isinstance(parsed, dict):
        return None
    for key in TOKEN_KEYS:
        val = parsed.get(key)
        if isinstance(val, str) and val:
            return val
    for path in NESTED_TOKEN_PATHS:
        cur: Any = parsed
        ok = True
        for key in path:
            if not isinstance(cur, dict) or key not in cur:
                ok = False
                break
            cur = cur[key]
        if ok and isinstance(cur, str) and cur:
            return cur
    return None


def _extract_user_id(parsed: Any) -> Any:
    """Extract a user id from the parsed body if obvious. None if missing."""
    if not isinstance(parsed, dict):
        return None
    for key in ("id", "user_id", "userId"):
        if key in parsed:
            return parsed[key]
    for container_key in ("data", "user", "authentication"):
        sub = parsed.get(container_key)
        if isinstance(sub, dict):
            for key in ("id", "user_id", "userId"):
                if key in sub:
                    return sub[key]
    return None


def auth_headers(captured_auth: dict[str, Any] | None) -> dict[str, str]:
    """Render captured_auth as request headers.

    Empty dict if input is None or lacks a usable token. Probes call this
    so they never have to know the shape of the captured_auth dict.

    Kind handling:
    - "cookie" / "session_id": render as `Cookie: <token>` so cookie-based
      sessions actually authenticate. Previously these silently became
      `Authorization: Bearer session=...` which the server ignores.
    - "jwt" / "bearer" / unspecified: render as `Authorization: Bearer ...`.
    - Explicit auth_header / auth_value pair wins over the kind-derived form.
    """
    if not captured_auth:
        return {}
    explicit_header = captured_auth.get("auth_header")
    explicit_value = captured_auth.get("auth_value")
    if explicit_header and explicit_value:
        return {explicit_header: explicit_value}

    token = captured_auth.get("token")
    if not token:
        return {}

    kind = (captured_auth.get("kind") or "").lower()
    if kind in ("cookie", "session_id"):
        return {"Cookie": token}
    return {"Authorization": f"Bearer {token}"}


def _extract_set_cookie(headers: dict[str, str]) -> str:
    """Case-insensitive Set-Cookie lookup. Returns '' if not present."""
    if not headers:
        return ""
    for k, v in headers.items():
        if k.lower() == "set-cookie":
            return v or ""
    return ""


async def _try_signup(
    session: aiohttp.ClientSession,
    base: str,
    email: str,
    password: str,
) -> tuple[str | None, Any, str]:
    """POST to each signup path. Return (token_or_none, user_id_or_none, set_cookie_raw).

    Token presence means the server returns auth credentials immediately
    on signup (some Juice-Shop forks do this). user_id is best-effort.
    set_cookie_raw preserves the response Set-Cookie header verbatim for
    downstream cookie-flag inspection.
    """
    payload = {"email": email, "password": password, "passwordRepeat": password}
    for path in SIGNUP_PATHS:
        url = f"{base}{path}"
        status, headers, body = await http_post_json(session, url, payload)
        if status not in (200, 201):
            continue
        parsed = _parse_json(body)
        token = _extract_token(parsed)
        user_id = _extract_user_id(parsed)
        return token, user_id, _extract_set_cookie(headers)
    return None, None, ""


async def _try_login(
    session: aiohttp.ClientSession,
    base: str,
    email: str,
    password: str,
) -> tuple[str | None, Any, str]:
    """POST credentials to each login path. Return (token, user_id, set_cookie_raw)."""
    payload = {"email": email, "password": password}
    for path in LOGIN_PATHS:
        url = f"{base}{path}"
        status, headers, body = await http_post_json(session, url, payload)
        if status not in (200, 201):
            continue
        parsed = _parse_json(body)
        token = _extract_token(parsed)
        if token:
            return token, _extract_user_id(parsed), _extract_set_cookie(headers)
    return None, None, ""


async def _verify_token(
    session: aiohttp.ClientSession,
    base: str,
    token: str,
) -> bool:
    """GET a whoami-shaped endpoint with the bearer token. True on 200."""
    headers = {"Authorization": f"Bearer {token}"}
    for path in WHOAMI_PATHS:
        url = f"{base}{path}"
        status, _, _ = await http_get(session, url, headers=headers)
        if status == 200:
            return True
    return False


async def acquire_test_auth(
    session: aiohttp.ClientSession,
    base: str,
    email: str | None = None,
    password: str | None = None,
) -> dict[str, Any] | None:
    """Bootstrap an authenticated session against ``base``.

    Tries signup then login. Verifies the token before returning. On any
    failure returns None so callers can fall back to unauthenticated mode.

    The returned dict is shaped for direct injection via
    ``ProbeContext.with_captured_auth()`` and includes a pre-rendered
    ``auth_value`` so probes don't re-derive the header format.
    """
    base = base.rstrip("/")
    creds_provided = email is not None and password is not None
    if email is None:
        email = _generate_email()
    if password is None:
        password = _generate_password()

    token: str | None = None
    user_id: Any = None
    set_cookie_raw: str = ""

    # Skip signup when caller already has credentials. Avoids polluting
    # the target's user table when not needed.
    if not creds_provided:
        token, user_id, set_cookie_raw = await _try_signup(
            session, base, email, password,
        )

    if token is None:
        login_token, login_uid, login_set_cookie = await _try_login(
            session, base, email, password,
        )
        if login_token is not None:
            token = login_token
            user_id = login_uid if login_uid is not None else user_id
            if login_set_cookie:
                set_cookie_raw = login_set_cookie

    if token is None:
        logger.debug("acquire_test_auth: no token from signup or login at %s", base)
        return None

    if not await _verify_token(session, base, token):
        logger.debug("acquire_test_auth: token did not validate against whoami at %s", base)
        return None

    result: dict[str, Any] = {
        "token": token,
        "email": email,
        "user_id": user_id,
        "auth_header": "Authorization",
        "auth_value": f"Bearer {token}",
    }
    if set_cookie_raw:
        result["set_cookie_raw"] = set_cookie_raw
    return result
