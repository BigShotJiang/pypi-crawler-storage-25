"""Probe registry, context, and primitives.

Probes are the deterministic detection engine of ptai. Each probe is a
two-step shape: baseline + perturbation, with a clear delta signal.

The registry is the single source of truth. Probes register via the
@registry.probe decorator, carry typed metadata (bug_class, severity,
auth requirements, runtime budget), and the agent loop discovers them
through one query API.

Usage:

    from engine.probes import registry, ProbeContext

    @registry.probe(
        name="web.cors_reflection",
        bug_class="cors_misconfig",
        severity_max="high",
        owasp="A05:2021",
        runtime_budget_s=2.0,
    )
    async def probe_cors_reflection(ctx: ProbeContext) -> list[dict]:
        ...
"""
from __future__ import annotations

from engine.probes.context import ProbeContext
from engine.probes.recon.crawler import CrawlResult, run_crawler
from engine.probes.registry import ProbeSpec

__all__ = ["CrawlResult", "ProbeContext", "ProbeSpec", "run_crawler"]
