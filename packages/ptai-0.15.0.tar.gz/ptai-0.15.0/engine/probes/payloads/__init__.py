"""Payload library and fuzzing primitive for probes.

Probes import named payload tuples or pick by bug class via
`PAYLOAD_REGISTRY`, and call `fuzz()` to drive a fuzzing run with bounded
concurrency.
"""
from __future__ import annotations

from engine.probes.payloads.library import (
    NOSQL_PAYLOADS,
    OPEN_REDIRECT_PAYLOADS,
    PATH_TRAVERSAL_PAYLOADS,
    PAYLOAD_REGISTRY,
    SQLI_PAYLOADS,
    SSTI_PAYLOADS,
    XSS_PAYLOADS,
    fuzz,
)

__all__ = [
    "NOSQL_PAYLOADS",
    "OPEN_REDIRECT_PAYLOADS",
    "PATH_TRAVERSAL_PAYLOADS",
    "PAYLOAD_REGISTRY",
    "SQLI_PAYLOADS",
    "SSTI_PAYLOADS",
    "XSS_PAYLOADS",
    "fuzz",
]
