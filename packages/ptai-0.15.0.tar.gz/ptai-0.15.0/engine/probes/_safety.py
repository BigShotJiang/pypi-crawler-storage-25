"""Shared opt-in safety helpers used by HTTP primitives.

This module hosts the small utilities that let primitives respect
server-side rate limits (HTTP 429) and engagement-level scope rules
without changing default behavior. Callers opt in by setting flags in
ProbeContext.extras:

  - ``extras["respect_rate_limits"] = True`` enables 429/Retry-After backoff
  - ``extras["strict_scope"] = True`` enables host-allowlist enforcement

Defaults are off everywhere so existing probes and tests are unaffected.
"""
from __future__ import annotations

import asyncio
import logging
from email.utils import parsedate_to_datetime
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlparse

logger = logging.getLogger("pentest-ai.probes.safety")

# Hard cap on how long we will obey a single Retry-After value. A
# malicious or misconfigured server returning Retry-After: 31536000
# (one year) should not stall a scan.
_RETRY_AFTER_CAP_S: float = 30.0
_MAX_BACKOFF_ATTEMPTS: int = 3
_DEFAULT_BACKOFF_S: float = 2.0


def _parse_retry_after(value: str) -> float:
    """Parse a Retry-After header into a bounded sleep duration in seconds.

    Retry-After can be either a non-negative integer (seconds) or an
    HTTP-date. Anything we can't parse falls back to _DEFAULT_BACKOFF_S.
    The result is always clamped to [0, _RETRY_AFTER_CAP_S].
    """
    if not value:
        return _DEFAULT_BACKOFF_S
    try:
        seconds = float(value.strip())
        return max(0.0, min(seconds, _RETRY_AFTER_CAP_S))
    except ValueError:
        pass
    try:
        when = parsedate_to_datetime(value)
        if when is None:
            return _DEFAULT_BACKOFF_S
        if when.tzinfo is None:
            when = when.replace(tzinfo=timezone.utc)
        delta = (when - datetime.now(timezone.utc)).total_seconds()
        return max(0.0, min(delta, _RETRY_AFTER_CAP_S))
    except (TypeError, ValueError):
        return _DEFAULT_BACKOFF_S


async def maybe_backoff_429(
    status: int,
    headers: dict[str, str],
    *,
    ctx_extras: dict[str, Any] | None,
    attempt: int,
) -> bool:
    """Sleep + signal a retry when the response is a 429 and the caller
    opted into rate-limit respect. Returns True iff the caller should
    redo the request.

    Default behavior (extras empty or respect_rate_limits=False) is to
    return False immediately so primitives behave exactly as before.
    """
    if status != 429:
        return False
    if not (ctx_extras and ctx_extras.get("respect_rate_limits")):
        return False
    if attempt >= _MAX_BACKOFF_ATTEMPTS:
        logger.info("429 backoff: giving up after %d attempts", attempt)
        return False
    delay = _parse_retry_after(headers.get("Retry-After", "") or headers.get("retry-after", ""))
    logger.info("429 backoff: sleeping %.1fs (attempt %d)", delay, attempt + 1)
    await asyncio.sleep(delay)
    return True


def host_allowed(url: str, engagement_target: str) -> bool:
    """Return True iff the URL's host matches the engagement's target host.

    Case-insensitive comparison. Port differences are tolerated so a
    target `http://example.test:8080` matches both port 80 and 8080
    requests. Empty engagement_target means no enforcement.
    """
    if not engagement_target:
        return True
    try:
        target_host = (urlparse(engagement_target).hostname or "").lower()
        request_host = (urlparse(url).hostname or "").lower()
    except (ValueError, AttributeError):
        return False
    if not target_host:
        return True
    return request_host == target_host
