"""Probe primitives. Building blocks every probe shares.

These exist so a new probe is 10 lines of declaration, not 60 lines of
HTTP plumbing. Every probe should reach for these instead of rolling
its own asyncio + aiohttp glue.

Three families:

1. HTTP helpers (`http_get`, `http_post_json`, `http_put_json`):
   uniform error handling, timeout, body truncation, sentinel returns.

2. Path walkers (`walk_paths`): GET a list of paths concurrently with
   bounded concurrency, run a predicate over each response, emit findings
   where it hits. Replaces 8+ probes' inner loops.

3. Baseline-vs-attack comparators (`baseline_attack_diff`): two-step
   shape that probes 12 (GET SQLi) and similar use to detect bugs by
   response delta.
"""
from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from typing import Any

import aiohttp

from engine.probes._safety import host_allowed, maybe_backoff_429

logger = logging.getLogger("pentest-ai.probes.primitives")

_DEFAULT_TIMEOUT = aiohttp.ClientTimeout(total=8)
_USER_AGENT = "pentest-ai/0.11 (+https://pentestai.xyz)"
_BODY_TRUNCATE = 65000


def _session_extras(session: aiohttp.ClientSession) -> dict[str, Any] | None:
    """Return the per-session opt-in safety flags, if any.

    web_agent / mcp_server.run_probe attach a ``_ptai_extras`` dict to the
    session when the engagement opted into rate-limit or scope safety.
    Probes never set this; default sessions have nothing attached and
    primitives behave exactly as before.

    Requires the attribute be an actual dict — anything else (None, a
    MagicMock auto-attribute in tests, an unrelated object) reads as
    "no extras attached" so existing test fixtures with bare MagicMock
    sessions keep working without manual ``_ptai_extras = None`` setup.
    """
    extras = getattr(session, "_ptai_extras", None)
    return extras if isinstance(extras, dict) else None


def _strict_scope_block(
    extras: dict[str, Any] | None, url: str
) -> bool:
    """Return True iff this request should be refused because strict_scope
    is opted in and the URL's host is outside the engagement target."""
    if not (extras and extras.get("strict_scope")):
        return False
    eng_target = extras.get("engagement_target") or ""
    if host_allowed(url, eng_target):
        return False
    logger.info(
        "strict_scope: blocked off-host %s (engagement target %s)",
        url, eng_target,
    )
    return True


async def http_get(
    session: aiohttp.ClientSession,
    url: str,
    *,
    headers: dict[str, str] | None = None,
    allow_redirects: bool = False,
    timeout: aiohttp.ClientTimeout | None = None,
) -> tuple[int, dict[str, str], str]:
    """GET wrapper. Returns (status, headers, body[:65k]). Errors -> (0, {}, "").

    Probes call this; never use raw session.get(). The sentinel return
    on error means probes can write `if status == 200 and ...` without
    threading exception handlers through every call.
    """
    h = {"User-Agent": _USER_AGENT}
    if headers:
        h.update(headers)
    extras = _session_extras(session)
    if _strict_scope_block(extras, url):
        return 0, {}, ""
    if extras and extras.get("strict_scope"):
        allow_redirects = False
    attempt = 0
    while True:
        try:
            async with session.get(
                url,
                headers=h,
                allow_redirects=allow_redirects,
                timeout=timeout or _DEFAULT_TIMEOUT,
            ) as resp:
                body = await resp.text(errors="replace")
                status = resp.status
                resp_headers = {k: v for k, v in resp.headers.items()}
                if await maybe_backoff_429(status, resp_headers, ctx_extras=extras, attempt=attempt):
                    attempt += 1
                    continue
                return status, resp_headers, body[:_BODY_TRUNCATE]
        except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
            logger.debug("GET %s failed: %s", url, exc)
            return 0, {}, ""


async def http_post_json(
    session: aiohttp.ClientSession,
    url: str,
    payload: dict[str, Any],
    *,
    headers: dict[str, str] | None = None,
    timeout: aiohttp.ClientTimeout | None = None,
) -> tuple[int, dict[str, str], str]:
    """POST a JSON body. Same return shape as http_get."""
    h = {"Content-Type": "application/json", "User-Agent": _USER_AGENT}
    if headers:
        h.update(headers)
    extras = _session_extras(session)
    if _strict_scope_block(extras, url):
        return 0, {}, ""
    attempt = 0
    while True:
        try:
            async with session.post(
                url, json=payload, headers=h, timeout=timeout or _DEFAULT_TIMEOUT
            ) as resp:
                body = await resp.text(errors="replace")
                status = resp.status
                resp_headers = {k: v for k, v in resp.headers.items()}
                if await maybe_backoff_429(status, resp_headers, ctx_extras=extras, attempt=attempt):
                    attempt += 1
                    continue
                return status, resp_headers, body[:_BODY_TRUNCATE]
        except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
            logger.debug("POST %s failed: %s", url, exc)
            return 0, {}, ""


async def http_post_form(
    session: aiohttp.ClientSession,
    url: str,
    payload: dict[str, Any],
    *,
    headers: dict[str, str] | None = None,
    timeout: aiohttp.ClientTimeout | None = None,
    allow_redirects: bool = True,
) -> tuple[int, dict[str, str], str]:
    """POST application/x-www-form-urlencoded body. Same return shape as http_get.

    Flask handlers using `request.form.get(...)` need this shape; sending
    JSON to them leaves request.form empty. allow_redirects defaults True
    because form-POST endpoints commonly 302 back to a render route.
    """
    h = {"User-Agent": _USER_AGENT}
    if headers:
        h.update(headers)
    extras = _session_extras(session)
    if _strict_scope_block(extras, url):
        return 0, {}, ""
    if extras and extras.get("strict_scope"):
        allow_redirects = False
    attempt = 0
    while True:
        try:
            async with session.post(
                url,
                data=payload,
                headers=h,
                allow_redirects=allow_redirects,
                timeout=timeout or _DEFAULT_TIMEOUT,
            ) as resp:
                body = await resp.text(errors="replace")
                status = resp.status
                resp_headers = {k: v for k, v in resp.headers.items()}
                if await maybe_backoff_429(status, resp_headers, ctx_extras=extras, attempt=attempt):
                    attempt += 1
                    continue
                return status, resp_headers, body[:_BODY_TRUNCATE]
        except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
            logger.debug("POST(form) %s failed: %s", url, exc)
            return 0, {}, ""


async def http_put_json(
    session: aiohttp.ClientSession,
    url: str,
    payload: dict[str, Any],
    *,
    headers: dict[str, str] | None = None,
    timeout: aiohttp.ClientTimeout | None = None,
) -> tuple[int, dict[str, str], str]:
    """PUT a JSON body. Same return shape as http_get."""
    h = {"Content-Type": "application/json", "User-Agent": _USER_AGENT}
    if headers:
        h.update(headers)
    extras = _session_extras(session)
    if _strict_scope_block(extras, url):
        return 0, {}, ""
    attempt = 0
    while True:
        try:
            async with session.put(
                url, json=payload, headers=h, timeout=timeout or _DEFAULT_TIMEOUT
            ) as resp:
                body = await resp.text(errors="replace")
                status = resp.status
                resp_headers = {k: v for k, v in resp.headers.items()}
                if await maybe_backoff_429(status, resp_headers, ctx_extras=extras, attempt=attempt):
                    attempt += 1
                    continue
                return status, resp_headers, body[:_BODY_TRUNCATE]
        except (asyncio.TimeoutError, aiohttp.ClientError, OSError) as exc:
            logger.debug("PUT %s failed: %s", url, exc)
            return 0, {}, ""


# Predicate signature: (status, headers, body) -> bool
Predicate = Callable[[int, dict[str, str], str], bool]


async def walk_paths(
    *,
    session: aiohttp.ClientSession,
    base: str,
    paths: tuple[str, ...],
    predicate: Predicate,
    finding_template: dict[str, Any],
    concurrency: int = 8,
    headers: dict[str, str] | None = None,
) -> list[dict[str, Any]]:
    """GET every path concurrently. Emit a finding per path where predicate hits.

    `finding_template` is shallow-copied per hit; any string value containing
    `{path}` gets the path substituted in. The base URL is prepended to each
    path; both forms work (paths starting with `/` or absolute URLs).

    Returns a list of findings.
    """
    sem = asyncio.Semaphore(concurrency)
    base = base.rstrip("/")

    async def fetch_one(path: str) -> dict[str, Any] | None:
        url = path if path.startswith(("http://", "https://")) else base + path
        async with sem:
            status, hdrs, body = await http_get(session, url, headers=headers)
        if not predicate(status, hdrs, body):
            return None
        finding = {}
        for k, v in finding_template.items():
            finding[k] = v.format(path=path) if isinstance(v, str) else v
        finding.setdefault("target", url)
        finding.setdefault("evidence", body[:512])
        return finding

    results = await asyncio.gather(*(fetch_one(p) for p in paths))
    return [r for r in results if r is not None]


async def baseline_attack_diff(
    *,
    session: aiohttp.ClientSession,
    baseline_url: str,
    attack_url: str,
    size_ratio_threshold: float = 3.0,
    expected_status: int = 200,
    headers: dict[str, str] | None = None,
) -> tuple[bool, int, int]:
    """Two-step diff: GET baseline, GET attack, compare body sizes.

    Returns (hit, baseline_size, attack_size). Hit when both responses
    have status == expected_status AND attack_size / baseline_size
    >= size_ratio_threshold. Used by GET-method SQLi, NoSQL injection,
    and template injection probes.
    """
    b_status, _, b_body = await http_get(session, baseline_url, headers=headers)
    a_status, _, a_body = await http_get(session, attack_url, headers=headers)
    if b_status != expected_status or a_status != expected_status:
        return False, len(b_body), len(a_body)
    if len(b_body) == 0:
        return False, 0, len(a_body)
    ratio = len(a_body) / len(b_body)
    return ratio >= size_ratio_threshold, len(b_body), len(a_body)


async def gather_with_budget(
    *coros: Awaitable[Any],
    budget_s: float,
) -> list[Any]:
    """Run coros concurrently with a soft timeout; collect what completed.

    Used by the driver to enforce per-probe runtime budgets. Coros that
    exceed the budget are cancelled and their slot returns None.
    """
    try:
        return await asyncio.wait_for(asyncio.gather(*coros), timeout=budget_s)
    except asyncio.TimeoutError:
        logger.warning("probe budget %.1fs exceeded; cancelling", budget_s)
        return []
