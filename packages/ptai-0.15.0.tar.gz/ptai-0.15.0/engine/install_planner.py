"""Predict which SecurityTool wrappers an engagement is likely to need.

At engagement start, the orchestrator asks the planner for a list of tools
the LLM is likely to call given (scope, intensity, target). The planner
returns a list of tool names. The smart-install flow then batches a single
prompt to install whatever's missing.

Two strategies stacked:

  1. Static map keyed by scope. The floor — always returns something.
  2. Optional LLM call: if an LLM client is available, asks it to pick a
     handful of additional tools given the target. Result is unioned with
     the static set.

If the LLM call fails (no key, cost limit, network error, malformed
response), the static set stands. The planner never raises into the caller.
"""
from __future__ import annotations

import json
import logging
from typing import Any

logger = logging.getLogger("pentest-ai.install_planner")

# Static floor — tools we know are useful for each scope. Keep this small;
# the LLM call (when available) handles target-specific picks.
_STATIC_SCOPE_MAP: dict[str, list[str]] = {
    "web": [
        "wpscan",
        "dalfox",
        "sqlmap",
        "ffuf",
        "gobuster",
        "nuclei",
        "nikto",
        "wafw00f",
        "katana",
    ],
    "ad": [
        "enum4linux-ng",
        "kerbrute",
        "smbmap",
        "ldap-utils",
        "netexec",
    ],
    "cloud": [
        "prowler",
        "scout-suite",
        "trivy",
        "checkov",
    ],
}

_LLM_PROMPT = """\
You are picking a handful of pentest tools to pre-install before the engagement begins.

Target: {target}
Scope: {scope}
Intensity: {intensity}

Available tool names (sample): {sample}

Return a JSON array of tool names (between 0 and 20) the engagement is likely
to need beyond the static defaults. Names must come from the available list.
No commentary, just the JSON array.
"""


def _static_for_scope(scope: str) -> list[str]:
    if scope == "full":
        # Union of every scope.
        seen: dict[str, None] = {}
        for tools in _STATIC_SCOPE_MAP.values():
            for t in tools:
                seen.setdefault(t, None)
        return list(seen.keys())
    return list(_STATIC_SCOPE_MAP.get(scope, []))


async def _llm_predict(
    agent: Any,
    *,
    scope: str,
    intensity: str,
    target: str,
    available_names: list[str],
) -> list[str]:
    """Ask the agent to pick extra tools. Returns [] on any failure."""
    sample = ", ".join(available_names[:80])  # cap for prompt-token sanity
    prompt = _LLM_PROMPT.format(
        target=target, scope=scope, intensity=intensity, sample=sample
    )
    try:
        # AnthropicAgent (and subclasses) expose `ask(prompt: str) -> str` in
        # newer revisions. Older shims use `decide_next_action`. We try the
        # cheap `ask` path first; if absent, give up and fall back.
        ask = getattr(agent, "ask", None)
        if ask is None:
            return []
        raw = await ask(prompt) if _is_coroutine_callable(ask) else ask(prompt)
    except Exception as exc:  # noqa: BLE001 - planner must never propagate
        logger.info("install_planner: LLM prediction failed: %s", exc)
        return []

    return _parse_tool_list(raw, available_names)


def _is_coroutine_callable(fn: Any) -> bool:
    import inspect

    return inspect.iscoroutinefunction(fn)


def _parse_tool_list(raw: str, available_names: list[str]) -> list[str]:
    """Extract a clean tool-name list from a possibly-noisy LLM string."""
    if not raw or not isinstance(raw, str):
        return []
    text = raw.strip()
    # Strip leading/trailing markdown fencing.
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()
    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return []
    if not isinstance(parsed, list):
        return []
    available = set(available_names)
    return [t for t in parsed if isinstance(t, str) and t in available]


async def predict_tools_for_engagement(
    agent: Any | None,
    *,
    scope: str,
    intensity: str = "normal",
    target: str = "",
    available_names: list[str] | None = None,
) -> list[str]:
    """Return a deduplicated list of tool names to ensure-install at engagement start.

    ``agent`` may be ``None``, in which case the static fallback is the entire
    answer. ``available_names`` defaults to the tools currently in
    ``tools.registry`` (lazy import so test fixtures can stub it).
    """
    static = _static_for_scope(scope)

    if available_names is None:
        from tools.registry import ToolRegistry

        available_names = [t.name for t in ToolRegistry().list_tools()]

    # Intersect static picks with what's actually known to the registry so
    # we don't try to install names that don't exist.
    static = [name for name in static if name in set(available_names)]

    extra: list[str] = []
    if agent is not None:
        extra = await _llm_predict(
            agent,
            scope=scope,
            intensity=intensity,
            target=target,
            available_names=available_names,
        )

    # Preserve order, dedupe.
    seen: dict[str, None] = {}
    for t in static + extra:
        seen.setdefault(t, None)
    return list(seen.keys())
