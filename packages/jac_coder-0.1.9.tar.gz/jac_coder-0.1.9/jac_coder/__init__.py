# Registers JacMetaImporter so .jac submodules (e.g. serve_entry.jac) are importable.
import jaclang  # noqa: F401

# Re-export the library-mode entry point so callers can `from jac_coder import JacCoder`.
# jaclang's meta importer (registered by the import above) lets Python import .jac
# files transparently; this works from both Python and Jac consumer code.
from jac_coder.lib.coder import JacCoder  # noqa: E402, F401

__all__ = ["JacCoder"]
