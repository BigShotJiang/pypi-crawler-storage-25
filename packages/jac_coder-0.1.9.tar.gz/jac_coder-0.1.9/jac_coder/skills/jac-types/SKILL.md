---
name: jac-types
description: The Jac type system — type annotations, generics, unions, optionals, inference rules, and common type errors. Load before writing any non-trivial typed function or when debugging a type-check failure.
---

Jac is statically typed at **annotation boundaries** and inferred inside function bodies. Every `def` parameter and return, and every `has` field, needs an explicit type. Local variables inside bodies get their type from the right-hand side. Types are unified across client (`.cl.jac`) and server code — only the specific types in scope differ (JsxElement in client, node archetypes in server).

```jac
obj User {
    has name: str;                       # required — must be passed at construction
    has age: int = 0;                    # typed primitive with default
    has tags: list[str] = [];            # generic container
    has meta: dict[str, int] = {};       # two-type-param generic
    has manager: User | None = None;     # self-referencing optional
}


def score(points: list[int]) -> int {
    total = sum(points);                 # inferred int, no annotation needed
    return total;
}


def greet(u: User) -> str {
    if u.manager is None {
        return "Hi " + u.name + ", no manager";
    }
    return "Hi " + u.name + ", manager is " + u.manager.name;  # safe — None branch returned
}


def describe(x: int | str) -> str {      # union type: x is either int or str
    if isinstance(x, int) {
        return "number: " + str(x);
    }
    return "text: " + x;                 # narrowed to str by the isinstance check
}


def log_any(value: Any) -> None {        # Any = escape hatch, no import needed
    print(value);
}


with entry {
    alice = User(name="alice", age=30);
    bob   = User(name="bob", manager=alice);

    print(score([1, 2, 3]));             # 6
    print(greet(bob));                   # Hi bob, manager is alice
    print(describe(42));                 # number: 42
    print(describe("hi"));               # text: hi
    log_any({"foo": "bar"});             # {'foo': 'bar'}
}
```

## Common patterns

**Optional field + None narrowing:**
```
has owner: User | None = None;
if self.owner is None { return "no owner"; }
return self.owner.name;                  # safe — compiler knows owner is User here
```

**Union type + narrowing with `isinstance`:**
```
def parse(x: int | str) -> int {
    if isinstance(x, int) { return x; }
    return int(x);
}
```

**Generic containers nested:**
```
has rows: list[dict[str, int]] = [];
has adjacency: dict[str, list[str]] = {};
```

**`Any` where dynamic access is needed:**
```
def on_event(e: Any) -> None {
    print(e.target.value);               # can touch any attribute — no type check
}
```

## Pitfalls

- **Every `def` parameter needs a type** (E0052). `def foo(x) -> int` is invalid — must be `def foo(x: int) -> int`.
- **Every `def` needs an explicit return type.** Even `-> None`.
- **`has name;`** without a type is a parse error. Always `has name: type;`.
- `list`, `dict`, `set` without type args default to `list[Any]` (W1036) — add args when you know the element type: `list[str]`, `dict[str, int]`.
- Use **`T | None`** for optional references. NOT `Optional[T]` (Python stdlib, not idiomatic). Always check `is None` before dereferencing.
- **`Any`** is Jac-native — no import needed. Do NOT `import from typing { Any }` (Python stdlib, missing in Vite client bundle) or `import from "@jac/runtime" { Any }` (not exported). Just write `e: Any`.
- **`any` lowercase** refers to the Python `any()` builtin — not the Any type. Using `e: any` in handlers fails **E1103** (function signature mismatch with JSX intrinsic prop type).
- **E1030** (`Type T has no attribute X`) — you called a method/field that doesn't exist on that type. Example: `items.map(...)` on `list[Item]` fails because lists don't have `.map()`; use comprehensions.
- **E1032** (`Type is Unknown, cannot access attribute`) — inference couldn't figure out a variable's type. Add an explicit annotation (`x: SomeType = ...`) so the rest of the code can narrow.
- **E1001** (`Cannot assign <Unknown> to T`) — the right-hand side's type doesn't match the declared type. Usually means you need to widen the declared type or narrow the value with an explicit cast/check.
- **Non-default fields MUST come before defaulted ones** (E2004) — see `jac-has-fields` for the full rule.
