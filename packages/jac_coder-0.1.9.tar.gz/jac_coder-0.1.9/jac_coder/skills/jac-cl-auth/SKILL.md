---
name: jac-cl-auth
description: Client-side authentication — signing up, logging in, logging out, and protecting pages behind login. Load when adding any auth UI or guarding pages from unauthenticated users. Pair with `jac-sv-auth` (server side of the auth loop), `jac-cl-routing` (post-login navigation).
---

Client auth uses four helpers from `@jac/runtime`. `jacLogin` and `jacSignup` are **async** and return a truthy value on success, falsy otherwise. `jacLogout` is **synchronous** — just call it. `jacIsLoggedIn` is a synchronous session check used inline at the top of protected pages.

```jac
import from "@jac/runtime" { jacLogin, jacSignup, jacLogout, jacIsLoggedIn, Navigate }

# Login attempt — call from a submit handler or effect. Returns a status string.
async def try_login(email: str, password: str) -> str {
    try {
        ok = await jacLogin(email, password);
        if ok {
            return "success";
        }
        return "invalid credentials";
    } except Exception as e {
        return "error";
    }
}

# Signup is usually followed by a login to establish the session.
async def try_signup(email: str, password: str) -> str {
    try {
        ok = await jacSignup(email, password);
        if not ok {
            return "signup failed (email may be in use)";
        }
        login_ok = await jacLogin(email, password);
        if login_ok {
            return "success";
        }
        return "login after signup failed";
    } except Exception as e {
        return "error";
    }
}

# Logout is synchronous — no await.
def perform_logout() -> None {
    jacLogout();
}

# Typical protected page — inline guard at the top.
def:pub Dashboard() -> JsxElement {
    if not jacIsLoggedIn() {
        return <Navigate to="/login" replace={True} />;
    }
    return <div className="p-4">Welcome to the dashboard</div>;
}
```

## Signup + first `def:priv` call: the 3-step chain

When the same form that signs a user up also needs to call a `def:priv` endpoint (e.g. saving the new user's profile, preferences, default workspace), the call order is **fixed and each step MUST be awaited**:

1. `await jacSignup(email, password)` — creates the account; **no session yet**
2. `await jacLogin(email, password)` — establishes the session cookie
3. `await save_profile(...)` — only now does the `def:priv` call have an authenticated session

```
# `save_profile` here is YOUR server function (def:priv) — imported from a .sv.jac module.
async def handle_register(name: str, email: str, password: str) -> str {
    signup_ok = await jacSignup(email, password);
    if not signup_ok { return "registration failed"; }

    login_ok = await jacLogin(email, password);
    if not login_ok { return "login after signup failed"; }

    profile_result = await save_profile(name, email);
    if profile_result is None { return "save failed"; }
    if not profile_result.success { return profile_result.message; }

    return "success";
}
```

**Why every `await` matters:** all three are async (return Promises). Skipping any `await` fires that call as a background Promise and lets the next line execute immediately. If `save_profile` fires before `jacLogin` completes, the session cookie isn't set yet → the server gets the request without auth → `401 Unauthorized`. The bug is silent at compile time — only surfaces at runtime on first registration.

## Auth-relevant `@jac/runtime` exports

`jacLogin`, `jacSignup`, `jacLogout`, `jacIsLoggedIn`, plus `Navigate` / `useNavigate` for post-auth redirects. For the full client export list and the "compile-passes-build-fails" rule, see `jac-cl-components`.

## Pitfalls

- Import auth helpers from `@jac/runtime` — see `jac-core-cheatsheet` for import form rules.
- Post-logout pattern: `jacLogout(); nav("/login");` — synchronous call, then navigate.
- Post-login navigation uses `useNavigate()` from `jac-cl-routing` — `nav = useNavigate(); ... nav("/dashboard");` after a successful login.
- `jacSignup` does NOT establish a session. ALWAYS follow with a `jacLogin` call using the same credentials — signup alone leaves the user unauthenticated.
- `jacLogin` and `jacSignup` are **async** — always `await`. `jacLogout` and `jacIsLoggedIn` are **sync** — NEVER `await` them. `await jacLogout()` type-errors; missing `await` on `jacLogin` silently returns a coroutine instead of the result.
- **Signup + first `def:priv` call must be a 3-step awaited chain: `await jacSignup` → `await jacLogin` → `await <def:priv>(...)`.** Skipping or reordering any await fires the calls in parallel and the `def:priv` request reaches the server before the session cookie is set → `401 Unauthorized`. Silent at compile time; caught only on first registration. See the "3-step chain" example above.
