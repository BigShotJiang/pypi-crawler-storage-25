---
name: jac-scaffold
description: Bootstrapping a new Jac project — which scaffolder to use, what each project type lays out on disk, and the post-scaffold checklist. Load when starting from scratch or when you need to know what files a project type ships with. Pair with `jac-fullstack-patterns` when building a new fullstack project.
---

There are TWO scaffolders. Use **`scaffold_project`** (JacCoder's built-in tool) by default — it tracks the current Jac best-practice patterns. The Jac CLI's `jac create --use <template>` is an alternative, but the upstream templates can lag behind syntax changes (e.g. they still use the deprecated `cl { ... }` / `sv { ... }` braced blocks instead of `to cl:` / `to sv:` section headers).

## `scaffold_project` (preferred)

Four project types. Pick by what the user is building:

| `project_type` | Use when | What ships |
|---|---|---|
| `frontend` | Pure client app, no server data | `main.jac`, `components/` (Header, Counter, Layout), `lib/utils.cl.jac`, `styles/global.css`, `jac.toml` |
| `backend` | Pure REST/RPC server, no UI | `main.jac` (with node + `def:pub` endpoints), `jac.toml` |
| `fullstack` | Client UI + server endpoints + auth | `main.jac` (server imports + `to cl:` + `def:pub app()`), `services/todo.sv.jac`, `hooks/useItems.cl.jac`, `components/` (Header, ItemList, ItemCard, Layout), `lib/utils.cl.jac`, `styles/global.css`, `jac.toml` |
| `ai_agent` | LLM-powered walker app (chat, agent loop) | `main.jac` (model setup), `nodes.jac` (Router/Handler nodes + `interact` walker), `.env`, `jac.toml` |

The fullstack template embodies the patterns taught in `jac-fullstack-patterns`: server imports plain at the top of `main.jac`, `to cl:` opens the client section, services in `services/*.sv.jac`, hooks call them with `sv import from`.

## `jac create --use <template>` (Jac CLI alternative)

```
jac create myapp                       # default: empty project
jac create myapp --use client          # client-only template
jac create myapp --use fullstack       # fullstack template
jac create --use ./local.jacpack       # from a local jacpack archive
jac create --use https://.../t.jacpack # from a URL
jac create --list_jacpacks             # list available templates
```

Useful for getting the upstream "blessed" layout, but **adapt the output**: convert `cl { ... }` / `sv { ... }` braced blocks into `to cl:` / `to sv:` section headers, replace any `cl import` / `sv import` prefixes in `main.jac` with plain `import from` (server) or `to cl:` + plain `import` (client). See `jac-fullstack-patterns` for the canonical `main.jac` shape.

## Post-scaffold checklist

After `scaffold_project` (or `jac create`):

1. `cd <project>`
2. `jac install` — installs Python + npm deps from `jac.toml`
3. `jac start --dev main.jac` (background for hot reload). NOT `jac serve` (deprecated).

After any later edit to `jac.toml`: `jac install` again.

## Pitfalls

- **Don't hand-write `jac.toml`.** Generate it via the scaffolder. The Tailwind plugin entry needs both `plugins = ["tailwindcss()"]` (with parens — it's a function call) AND `lib_imports = ["import tailwindcss from '@tailwindcss/vite'"]`. Missing either stops Tailwind from compiling.
- **Match the project type to the user's actual need.** Picking `fullstack` for a UI-only spike adds unused server scaffolding; picking `frontend` for an app that needs persistence forces a later migration.
- **`jac create --use fullstack` ships deprecated syntax** (`cl { ... }` / `sv { ... }` blocks → W0064). Adapt to `to cl:` / `to sv:` section headers before adding code.
- **`-s` / `--skip` on `jac create --use client`** skips npm install — convenient for offline scaffolding, but you'll need `jac install` before running.
- **Project-name argument is optional** — defaults to `jactastic`, then `jactastic1`, `jactastic2`, etc. Always pass an explicit name.
