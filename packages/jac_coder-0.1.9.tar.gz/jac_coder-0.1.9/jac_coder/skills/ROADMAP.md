# JacCoder Skills — Roadmap

The skill set JacCoder ships is the agent's curated knowledge of Jac.
This file is the plan: what skills exist, what's next, and how they're
organized. It's a living doc — update it when adding, merging, or
renaming a skill.

Check off with `✅` when shipped, `🟡` when in-progress, `⬜` when planned.

---

## 1. Shipped and planned skills

### Language / type-system (any `.jac` file)

- ✅ `jac-has-fields` — `has` field declarations on obj/node/walker/edge
- ✅ `jac-walker-patterns` — walker mechanics (entries, visit, report, disengage)
- ✅ `jac-node-edge-patterns` — graph construction, list-style reads with filters
- ✅ `jac-by-llm` — LLM-delegated function bodies, tools, `sem` semantics
- ✅ `jac-core-cheatsheet` — imports, lambda, ternary, f-strings, `with entry`, control flow, try/except
- ✅ `jac-types` — primitives, unions, `T | None`, `Any`, inference, type-error codes
- ✅ `jac-impl-files` — `.jac` / `.impl.jac` split, declaration forms, `impl Obj.method`, abstract + override

### Client (`.cl.jac`)

- ✅ `jac-cl-components` — component shape, state, effects, JSX basics, event handlers
- ✅ `jac-cl-routing` — Router, Routes, Route, Navigate, useNavigate, Link
- ✅ `jac-cl-auth` — jacLogin, jacSignup, jacLogout, jacIsLoggedIn, protected routes
- ✅ `jac-cl-organization` — file layout, component reuse discipline, hook pattern, when to extract
- ⬜ `jac-cl-forms` (maybe) — controlled inputs, submit handlers, validation patterns

### Server (`.sv.jac`)

- ✅ `jac-sv-endpoints` — `def:pub` / `def:priv` / plain `def`, typed returns, CRUD shape, authenticated vs public
- ✅ `jac-sv-persistence` — typed-edge creation, multi-hop reads, field-predicate filters, aggregates, find-by-jid patterns
- ✅ `jac-sv-auth` — `def:pub` shared-root vs `def:priv` per-user-root, mixing in same file, UNAUTHORIZED handling

### Wiring / project

- ✅ `jac-fullstack-patterns` — `main.jac` with `to sv:` / `to cl:` sections, two-place imports (functions + types), positional RPC calls, `jac.toml`, project layout
- ✅ `jac-scaffold` — `scaffold_project` types + `jac create --use`, post-scaffold checklist, jacpack note
- ⬜ `jac-debug-syntax` — reading `jac_check` errors, common error codes, fix recipes

**Target total: ~15 skills.** Each under ~900 tokens. No skill overlaps with another's scope.

---

## 2. Architecture question: flat vs nested

### Current state: flat

Every skill is a top-level directory under `jac_coder/skills/<name>/` with a
`SKILL.md`. Registry scans one level deep. The listing the LLM sees is a
single flat list of `name: description` pairs.

Works well while skill count is small (<10). At 15-20 skills the listing
becomes harder to scan, but still fits under 2-3 KB — manageable.

### Option A — flat + grouped listing *(recommended start)*

Keep the flat filesystem, but add a `group:` field to frontmatter. The
listing renders grouped by area:

```
<jac-skills-available>
  Language primitives:
    - jac-has-fields: ...
    - jac-walker-patterns: ...
  Client (.cl.jac):
    - jac-cl-components: ...
    - jac-cl-routing: ...
  Server (.sv.jac):
    - jac-sv-endpoints: ...
</jac-skills-available>
```

**Cost:** tiny — add `group` field, change `inject_skills_listing()` to
sort/group by it. ~10 lines of code. No registry scan changes.

**Wins:** easier for the model to navigate the listing. Scales to 20-30
skills without pain.

### Option B — nested skills (parent + sub-skills)

Directory tree with parent skills and children:

```
skills/
├── jac-cl/
│   ├── SKILL.md               ← parent / overview / dispatcher
│   ├── components/SKILL.md    ← sub
│   ├── routing/SKILL.md       ← sub
│   └── auth/SKILL.md          ← sub
```

Parent skill either:
1. Acts as an **overview** — lists sub-skills in its body so the model knows what to load next
2. Acts as a **dispatcher** — loading the parent also loads all its subs as one bundle
3. Acts as a **foundation** — parent has shared setup; subs extend it

**Cost:** medium — registry refactor to scan recursively, loader decides
parent-only vs parent+subs, frontmatter needs a `parent:` or similar
field, listing renders hierarchically.

**Wins:** progressive disclosure. For `.cl.jac` tasks, model can load
just `jac-cl` for an overview, then pull `jac-cl-routing` only if the
task mentions routes.

**Costs:** more judgment calls for the model (load parent? load subs?
how many?). Registry complexity. Risk of content duplication between
parent and subs.

### Recommendation

**Start with Option A (flat + grouped listing).** At 15-20 skills flat
scales fine, and grouping solves the "long flat list" problem cheaply.
Option B's progressive-disclosure benefit only matters if the model
actually struggles with the grouped listing — we have no evidence yet
that it does.

Upgrade to Option B only if we run into a specific pain that grouping
doesn't solve (e.g., a parent that all sub-skills meaningfully share
content with and re-teaching would waste tokens).

---

## 3. Naming conventions

- **Language primitives**: no prefix — `jac-has-fields`, `jac-walker-patterns`, `jac-by-llm`
- **Client**: `jac-cl-<concern>` — `jac-cl-components`, `jac-cl-routing`
- **Server**: `jac-sv-<concern>` — `jac-sv-endpoints`, `jac-sv-persistence`
- **Cross-stack / project**: `jac-<concern>` — `jac-fullstack-patterns`, `jac-scaffold`

File layout (current, flat): `jac_coder/skills/<name>/SKILL.md` plus
optional supporting files in the same directory (scripts, reference,
examples). Claude-Code-compatible.

---

## 4. Scope rule (the discipline)

**One skill per distinct generation concern.** A skill owns exactly one
topic; topics never overlap between skills.

- If two skills ALWAYS get loaded together, they're one skill — consolidate.
- If one skill has >2 distinct sub-patterns the model generates differently
  (e.g., routing = Router setup + Link + Navigate + useNavigate + protected
  routes), it may warrant a split.
- If a skill file exceeds ~900 tokens, scope is probably too wide.
- If a skill file is under ~300 tokens, scope is probably too narrow or
  better folded into a neighbour.

---

## 5. Authoring checklist

For every new skill:

1. Draft SKILL.md against the standard template (concept + example + rules).
2. Extract all ```jac blocks; run each through `jac check`.
3. Fix anything that fails or emits a W0xxx deprecation warning.
4. Spot-test each rule against a minimal failing case — the compiler
   message must match what the rule claims.
5. Run `python scripts/check_skills.py` — must exit zero.
6. Update this roadmap (check off the ⬜).

---

## 6. Open questions

- **When to add a `group` field to frontmatter?** Add as a one-shot migration
  when we hit ~10 skills. Not earlier — the listing is still easy to scan.
- **When to revisit Option B (nested)?** If a skill's rules section grows
  past ~12 items, it's a candidate for splitting into a parent + subs.
- **How to handle deprecated-content watchdog?** The validator catches
  syntax deprecations. Content deprecation (e.g., a rule that stops being
  true because Jac evolved) needs manual review. Roadmap doesn't solve
  this; periodic re-validation does.
