---
name: jac-core-cheatsheet
description: Jac-language baseline — imports, control flow, lambdas, ternary, string formatting, error handling, top-level execution. Load for basic-syntax questions no specific skill covers.
---

Jac is Python-flavored with stricter typing, braces, and terminators. Every `def` has typed args and a return type; every block is `{ }`-braced; every statement ends with `;`. Top-level code runs inside `with entry { ... }`.

```jac
import os;
import from math { pi }


def double(x: int) -> int {
    return x * 2;
}


with entry {
    name: str = "alice";
    age: int = 30;
    tags: list[str] = ["a", "b"];
    meta: dict[str, int] = {"x": 1};
    manager: str | None = None;

    doubled: list[int] = [n * 2 for n in [1, 2, 3]];

    label: str = "adult" if age >= 18 else "minor";   # ternary: A if cond else B

    square = lambda(x: int) -> int { return x * x; }; # typed lambda with braces
    print(square(5));

    greeting = f"hello {name}, {len(tags)} tags";

    for n in doubled {
        if n > 4 {
            print(f"big: {n}");
        } elif n > 2 {
            print(f"mid: {n}");
        } else {
            print(f"small: {n}");
        }
    }

    try {
        value = int("not-a-number");
    } except ValueError as e {
        print(f"parse error: {str(e)}");
    }
}
```

## Import forms

**Plain `.jac` file imports:**
```
import os;                              # module — takes `;`
import from byllm.lib { Model }         # selective — NO `;`
import ".styles/global.css";            # file — takes `;`
```

**Client imports (inside `.cl.jac` files, or under `to cl:` in `main.jac`):**
```
import from .button { Button }                        # relative (dots)
import from "@jac/runtime" { Router, Routes, Route }  # npm (quoted)
```

**`main.jac` is the one mixed-context file.** Server imports go at the top (server is the default context — no header needed). Then `to cl:` opens the client section: CSS import, top-level component, `def:pub app()`:
```
import from services.recipe { ApiResponse, save_profile }   # server: no leading dot
to cl:
import ".styles/global.css";
import from .components.AppShell { AppShell }               # client: relative dots
def:pub app() -> JsxElement { return <AppShell />; }
```

## Pitfalls

- Type system (annotations, unions, optional `T | None`, `Any`, inference, type-error codes) — see `jac-types`.
- **Don't reuse a variable name across sibling `if` / `else` branches.** The Jac → JS compiler emits `let x = ...` on the first branch and a bare `x = ...` on the sibling — the sibling assignment then fails at runtime with `ReferenceError: x is not defined` because the first branch's `let` is block-scoped. Use distinct names in each branch (`login_ok` vs `post_signup_login`, etc.) or the model hits a silent runtime error no `jac check` catches.
- Concatenating a string with an Exception fails — wrap with `str(e)`: `"error: " + str(e)`.
- `import from X { Y };` fails with E0030. **Brace imports take NO trailing semicolon.** Plain module form `import X;` does.
- Statements end with `;`; blocks use `{ }`. No significant indentation (Python-style).
- Lambda requires types AND braces: `lambda(x: int) -> int { return x; }`. NOT `lambda x: x` (Python), `:x: x` (invented), or `<lambda x: x>` (invented) — all fail.
- Ternary is **Python-style**: `A if cond else B`. NOT `cond ? A : B` (JS/C-style) — that's a parse error in Jac.
- **Python stdlib needs explicit import — Jac auto-imports nothing.** `datetime.now()`, `os.environ`, `json.dumps`, `math.pi`, `random.randint`, etc. ALL need a top-of-file `import from <mod> { name }` or `import <mod>;` first. Common slip: using `datetime.now()` for `created_at` fields without `import from datetime { datetime }` → `NameError: name 'datetime' is not defined` at runtime.
