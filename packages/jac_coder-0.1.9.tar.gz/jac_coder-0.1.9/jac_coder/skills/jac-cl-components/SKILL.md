---
name: jac-cl-components
description: Writing a client-side UI component — shape, reactive state, mount effects, rendering, event handlers. Load when creating or editing any `.cl.jac` file. Pair with `jac-cl-routing` (multi-page apps), `jac-cl-organization` (file layout & hooks), `jac-cl-auth` (protected pages).
---

`.cl.jac` files are client-side Jac. A component is a `def:pub` function returning `JsxElement`. State = `has` fields (assign directly, UI re-renders; NO `useState`/`setX`). Mount effects = `async can with entry`. Event handlers = `def` methods typed with ambient DOM events (`MouseEvent`, `ChangeEvent`, `FormEvent`, `KeyboardEvent`). No `to cl:` header — the extension sets client context.

```jac
def:pub Counter() -> JsxElement {
    has count: int = 0;
    has label: str = "";

    async can with entry {
        count = 0;                               # mount effect — runs once
    }

    def handle_click(e: MouseEvent) -> None {
        count = count + 1;
    }

    def handle_input(e: ChangeEvent) -> None {
        label = e.target.value;                  # .target.value is typed via ChangeEvent
    }

    return <section className="p-4">
        <input value={label} onChange={handle_input} />
        <h1 className="text-xl">
            {"Clicks: " + str(count) if count > 0 else "Start clicking!"}
        </h1>
        <button onClick={handle_click}>+</button>
    </section>;
}
```

## Props

Components declare props as typed function params; callers pass as JSX attributes. Callback props are typed `Any`. Wrap incoming callbacks in a local handler so parent-side data (like a row's id) is closed over when the event fires.

```jac
def:pub BookCard(bookId: str, title: str, onDelete: Any) -> JsxElement {
    def handle_delete(e: MouseEvent) -> None {
        if onDelete { onDelete(bookId); }
    }
    return <div>{title} <button onClick={handle_delete}>X</button></div>;
}
```

Call site: `<BookCard bookId={b["id"]} title={b["title"]} onDelete={remove} />`.

## Event types (ambient, no import)

| Handler | Type | Access |
|---|---|---|
| `onClick`, `onMouseDown`, `onDoubleClick` | `MouseEvent` | `e.clientX`, `e.button` |
| `onChange` | `ChangeEvent` | `e.target.value` |
| `onInput` | `InputEvent` | `e.target.value` |
| `onKeyDown`, `onKeyUp`, `onKeyPress` | `KeyboardEvent` | `e.key`, `e.code` |
| `onSubmit`, `onReset` | `FormEvent` | `e.preventDefault()` |
| `onFocus`, `onBlur` | `FocusEvent` | `e.target` |

Fall back to `Any` (capital, built-in) only when you don't read `e`.

## Built-in in `.cl.jac` — NEVER import these

`JsxElement` (the component return type), `Any`, and all DOM event types (`MouseEvent`, `ChangeEvent`, `FormEvent`, `KeyboardEvent`, `InputEvent`, `FocusEvent`) are Jac built-ins in client context. Trying `import from "@jac/runtime" { JsxElement }` is wrong and can fail the Vite build.

## Imports from `@jac/runtime` (complete list)

- **Routing components:** `Router`, `Routes`, `Route`, `Link`, `Navigate`, `Outlet`
- **Routing hooks:** `useNavigate`, `useLocation`, `useParams`, `useRouter` (NO `useSearchParams`)
- **Auth:** `jacLogin`, `jacSignup`, `jacLogout`, `jacIsLoggedIn`
- **Validation / error boundary:** `JacSchema`, `JacClientErrorBoundary`
- **DO NOT use:** `useState`, `useEffect` (aliases exist but `has` + `async can with entry` are idiomatic)

## Rules

- **`has` fields are reactive state — assign directly.** `count = count + 1` re-renders. No `setCount`. Non-default fields come before defaulted ones (E2004 — see `jac-has-fields`).
- **Hooks + `has` BEFORE any conditional return.** React hooks must fire in the same order every render. `if not jacIsLoggedIn() { return <Navigate />; } has x: int = 0;` → white screen, no compile error.
- **Mount effects (`async can with entry`) fire even when the component returns `<Navigate>`.** Guard the EFFECT body with `if jacIsLoggedIn() { ... }`, not just the render — otherwise `def:priv` calls fire and return 401.
- **Server RPC import uses `sv import from ...services.X { fn, Types }`** (prefix required). Plain `import from` to a `.sv.jac` breaks the Vite build. Include obj/node types too. See `jac-fullstack-patterns`.
- **Call server endpoints POSITIONAL, not kwargs.** `save(a, b)` works; `save(a=a, b=b)` sends empty body → 422.
- **JSX ternary is Python-style:** `{X if cond else Y}`. NOT `{cond ? X : Y}` (parse error even inside JSX). Short-circuit also works: `{cond and <X />}`.
- **Iterate with comprehensions, NOT `.map()`.** `items.map(...)` on a Jac list fails E1030. Use `[<li>...</li> for i in items]` inside JSX.
- **Dict access uses `[key]`, NOT `.get()`.** `params.get("id")` runtime-fails in browser (`useParams` returns plain JS object). Use `val = params["id"]; if val is None { ... }`.
- **Guard None/null/undefined when iterating or dotting into server data.** Runtime-only failure (`Cannot read properties of null/undefined`), nothing at compile. Four hot spots — single-level access is the most common:

```
# FRAGILE — crashes if the value is None/null
total = result.total_posts;                            # result is None → crash (SINGLE-LEVEL)
status = result.recipe.status;                         # result.recipe is None → crash (NESTED)
rows = [<Card title={s["title"]} /> for s in songs];  # any s is None in list → crash
first = songs[0]["title"];                             # empty list → crash

# SAFE — narrow, filter, or length-check first (use `!= None`, NOT `is not None` in .cl.jac)
if result != None { total = result.total_posts; }
if result.recipe != None { status = result.recipe.status; }
rows = [<Card ... /> for s in songs if s != None];
if len(songs) > 0 { first = songs[0]["title"]; }
```

Also works: short-circuit in JSX — `{result and <X total={result.total_posts} />}`.
- **Event params are typed — `MouseEvent`/`ChangeEvent`/etc.** `e: any` (lowercase) is the Python `any()` builtin, fails E1103. Use capital `Any` (no import) for untyped.
- **JSX uses `className`, curly-brace interpolation `{expr}`, camelCase events** (`onClick`, `onChange`).
- **No `to cl:` / `cl def:pub` / `cl { }` in `.cl.jac` files.** Extension already sets context. Braced blocks are deprecated (W0064).
- **Top-level component name is `def:pub app()`** — lowercase. Runtime mounts the literal name.
- **`is not None` is a `.cl.jac` compiler bug — use `!= None`.** Both `x is None` and `x is not None` compile to `x === null` in the generated JS — the `not` is silently dropped. Your guard runs the OPPOSITE of what you wrote (a `for ... if x is not None` comprehension keeps only the nulls). Use `!= None` / `== None` in client code. (Server `.sv.jac` compiles to Python normally and is unaffected.)

## See also

- `jac-cl-routing` — `Router`/`Route`/`Navigate`/`useNavigate` patterns
- `jac-cl-auth` — `jacLogin`/`jacSignup`/`jacLogout`, signup→login→def:priv chain
- `jac-cl-organization` — file layout, component reuse, hook pattern
- `jac-core-cheatsheet` — imports, lambda, ternary, error handling
