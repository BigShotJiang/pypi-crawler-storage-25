"""Pytest wrapper for tests/check_jaccoder.jac — the library-mode JacCoder class."""

import pytest
from conftest import run_jac


@pytest.fixture(scope="module")
def jaccoder_output():
    # Larger timeout because first run may compile a lot of Jac modules.
    return run_jac("tests/check_jaccoder.jac", timeout=180)


def test_jaccoder_check_exits_cleanly(jaccoder_output):
    assert jaccoder_output.returncode == 0, (
        f"check_jaccoder.jac failed:\n"
        f"stdout:\n{jaccoder_output.stdout}\n"
        f"stderr:\n{jaccoder_output.stderr}"
    )


def test_service_or_scale_unavailable_branch(jaccoder_output):
    """Accept either branch of the conditional in check_jaccoder.jac §2."""
    msg = jaccoder_output.stdout
    assert (
        "service mode raises without scale when allow_unscaled=False: OK" in msg
        or "service mode with scale present constructs OK: OK" in msg
    ), msg


@pytest.mark.parametrize(
    "marker",
    [
        # Section 1 — stateless mode
        "construct stateless (no args): OK",
        "stateless health reports mode=stateless: OK",
        "stateless health has username='': OK",
        "stateless health has svc_root_id='': OK",
        "stateless create_session empty title raises InvalidInputError: OK",
        "partial credentials (only username) raises InvalidInputError: OK",
        # Section 3 — service / unscaled mode
        "construct with allow_unscaled=True: OK",
        "unscaled-fallback health mode=unscaled (or service if scale present): OK",
        "create_session empty title raises InvalidInputError: OK",
        "create_session empty workspace_path raises InvalidInputError: OK",
        "create_session empty owner raises InvalidInputError: OK",
        "create_session relative workspace_path raises InvalidInputError: OK",
        "create_session non-existent workspace_path raises WorkspaceError: OK",
        "create_session returns non-empty session_id: OK",
        "create_session for same owner returns distinct id: OK",
        "list_sessions empty owner raises InvalidInputError: OK",
        "list_sessions(user-alpha) returns exactly that user's sessions: OK",
        "list_sessions(user-beta) does not leak user-alpha's sessions: OK",
        "get_history on fresh session returns empty list: OK",
        "get_history on unknown session_id raises NotFoundError: OK",
        "delete_session returns True on existing session: OK",
        "delete_session returns False on missing session: OK",
        "interrupt on unknown run_id raises NotFoundError: OK",
        # Stateless ↔ service cross-check
        "stateless create_session returns non-empty session_id: OK",
        "stateless list_sessions finds its own session: OK",
        # health shape
        "health() returns expected keys: OK",
        "health().username matches constructor: OK",
        "health().scale_mode is bool: OK",
        "health().active_runs is 0 after all cleanups: OK",
    ],
)
def test_jaccoder_case(jaccoder_output, marker):
    assert marker in jaccoder_output.stdout, (
        f"Missing marker: {marker!r}\n"
        f"Full stdout:\n{jaccoder_output.stdout}"
    )
