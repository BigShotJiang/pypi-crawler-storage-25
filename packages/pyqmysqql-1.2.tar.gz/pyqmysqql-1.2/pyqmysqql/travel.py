"""
DROP DATABASE IF EXISTS travel_agency_min;
CREATE DATABASE travel_agency_min CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE travel_agency_min;

CREATE TABLE cities (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    price_per_day DECIMAL(10,2) NOT NULL,
    image_path VARCHAR(255) NOT NULL
);

CREATE TABLE hotels (
    id INT PRIMARY KEY AUTO_INCREMENT,
    city_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    price_per_night DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (city_id) REFERENCES cities(id)
);

CREATE TABLE additional_services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(150) NOT NULL UNIQUE,
    price DECIMAL(10,2) NOT NULL
);

CREATE TABLE clients (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    phone VARCHAR(30) NOT NULL,
    birth_date DATE NOT NULL
);

CREATE TABLE tour_applications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    client_id INT NOT NULL,
    city_id INT NOT NULL,
    hotel_id INT NOT NULL,
    start_date DATE NOT NULL,
    days_count INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    status VARCHAR(50) NOT NULL,
    created_at DATETIME NOT NULL,
    FOREIGN KEY (client_id) REFERENCES clients(id),
    FOREIGN KEY (city_id) REFERENCES cities(id),
    FOREIGN KEY (hotel_id) REFERENCES hotels(id)
);

CREATE TABLE application_services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    application_id INT NOT NULL,
    service_id INT NOT NULL,
    FOREIGN KEY (application_id) REFERENCES tour_applications(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES additional_services(id)
);

INSERT INTO cities (name, price_per_day, image_path) VALUES
('Суздаль', 1000, 'resources/images/suzdal.png'),
('Казань', 1800, 'resources/images/kazan.png'),
('Псков', 1200, 'resources/images/pskov.png'),
('Байкал', 1500, 'resources/images/baikal.png'),
('Алтай', 1400, 'resources/images/altai.png'),
('Карелия', 1700, 'resources/images/karelia.png');

INSERT INTO hotels (city_id, name, price_per_night) VALUES
(1, 'Суздаль Отель', 2500),
(1, 'Уютный двор', 3200),
(2, 'Казанский берег', 3600),
(2, 'Татарстан Плаза', 4200),
(3, 'Псков Центр', 2800),
(3, 'Белая башня', 3400),
(4, 'Байкал Вью', 3900),
(4, 'Озёрный дом', 4500),
(5, 'Алтай Резорт', 4100),
(5, 'Горный уют', 3000),
(6, 'Карелия Лайф', 3300),
(6, 'Северный лес', 3700);

INSERT INTO additional_services (name, price) VALUES
('Трансфер', 1200),
('Экскурсия', 2500),
('Страховка', 900);

INSERT INTO clients (full_name, email, phone, birth_date) VALUES
('Иванов Иван Иванович', 'ivan@test.ru', '+79990000001', '1998-05-14'),
('Петрова Анна Сергеевна', 'anna@test.ru', '+79990000002', '2010-09-10');


####main#####
import os
import sys
from datetime import date, datetime

import pymysql
from PyQt6 import uic
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import *

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def db():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="travel_agency_min",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )

class CatalogWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi(os.path.join(BASE_DIR, "main.ui"), self)

        self.btnSearch.clicked.connect(self.load_cities)
        self.editSearch.returnPressed.connect(self.load_cities)

        container = QWidget()
        self.cardsLayout = QGridLayout(container)
        self.cardsLayout.setContentsMargins(20, 20, 20, 20)
        self.cardsLayout.setHorizontalSpacing(18)
        self.cardsLayout.setVerticalSpacing(18)
        self.scrollArea.setWidget(container)

        self.load_cities()

    def load_cities(self):
        while self.cardsLayout.count():
            item = self.cardsLayout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()

        text = self.editSearch.text().strip()
        query = """
            SELECT id, name, price_per_day, image_path
            FROM cities
            WHERE name LIKE %s
            ORDER BY name
        """
        con = db()
        try:
            cur = con.cursor()
            cur.execute(query, (f"%{text}%",))
            rows = cur.fetchall()
        finally:
            con.close()

        if not rows:
            label = QLabel("По вашему запросу города не найдены")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setStyleSheet("font-size: 16px; padding: 20px;")
            self.cardsLayout.addWidget(label, 0, 0, 1, 3)
            return

        for index, city in enumerate(rows):
            row = index // 3
            col = index % 3
            self.cardsLayout.addWidget(self.create_city_card(city), row, col)

        for col in range(3):
            self.cardsLayout.setColumnStretch(col, 1)

    def create_city_card(self, city):
        card = QFrame()
        card.setObjectName("cityCard")
        card.setStyleSheet(
            """
            QFrame#cityCard {
                background-color: white;
                border: 1px solid black;
            }
            QLabel {
                color: black;
            }
            QPushButton {
                background-color: white;
                color: black;
                border: 1px solid black;
                padding: 6px 10px;
                font-weight: bold;
            }
            """
        )

        layout = QVBoxLayout(card)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(6)

        title = QLabel(city["name"])
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 18px; font-weight: bold;")

        image_label = QLabel()
        image_label.setFixedSize(220, 120)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        image_path = os.path.join(BASE_DIR, city["image_path"])
        if os.path.exists(image_path):
            pixmap = QPixmap(image_path)
            image_label.setPixmap(
                pixmap.scaled(
                    220,
                    120,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
        else:
            image_label.setText("фото")
            image_label.setStyleSheet("border:1px solid black;")

        price = QLabel(f"{city['price_per_day']} р. в сутки")
        price.setAlignment(Qt.AlignmentFlag.AlignCenter)
        price.setStyleSheet("font-size: 16px; font-weight: bold;")

        button = QPushButton("Оформить")
        button.clicked.connect(lambda _, city_id=city["id"]: self.open_order(city_id))

        layout.addWidget(title)
        layout.addWidget(image_label)
        layout.addWidget(price)
        layout.addWidget(button)
        return card

    def open_order(self, city_id):
        self.w = OrderWindow(city_id)
        self.w.show()
        self.close()


class OrderWindow(QMainWindow):
    def __init__(self, city_id):
        super().__init__()
        uic.loadUi(os.path.join(BASE_DIR, "order.ui"), self)
        self.city_id = city_id
        self.current_client_id = None

        self.btnBack.clicked.connect(self.back)
        self.btnFindClient.clicked.connect(self.find_client)
        self.btnCalc.clicked.connect(self.calculate_total)
        self.btnSubmit.clicked.connect(self.submit_application)

        self.load_city()
        self.load_hotels()
        self.load_services()

    def load_city(self):
        con = db()
        try:
            cur = con.cursor()
            cur.execute("SELECT name FROM cities WHERE id=%s", (self.city_id,))
            city = cur.fetchone()
        finally:
            con.close()

        self.lblCity.setText(city["name"] if city else "Неизвестный город")

    def load_hotels(self):
        self.comboHotel.clear()
        con = db()
        try:
            cur = con.cursor()
            cur.execute(
                "SELECT id, name, price_per_night FROM hotels WHERE city_id=%s ORDER BY price_per_night",
                (self.city_id,),
            )
            rows = cur.fetchall()
        finally:
            con.close()

        for row in rows:
            self.comboHotel.addItem(f"{row['name']} - {row['price_per_night']} р./сутки", row)

    def load_services(self):
        self.lstServices.clear()
        con = db()
        try:
            cur = con.cursor()
            cur.execute(
                "SELECT id, name, price FROM additional_services ORDER BY name"
            )
            rows = cur.fetchall()
        finally:
            con.close()

        for row in rows:
            item = QListWidgetItem(f"{row['name']} - {row['price']} р.")
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Unchecked)
            item.setData(Qt.ItemDataRole.UserRole, row)
            self.lstServices.addItem(item)

    def find_client(self):
        email = self.editEmail.text().strip()
        if not email:
            QMessageBox.warning(self, "Ошибка", "Введите email для поиска")
            return

        con = db()
        try:
            cur = con.cursor()
            cur.execute(
                "SELECT * FROM clients WHERE email=%s",
                (email,),
            )
            row = cur.fetchone()
        finally:
            con.close()

        if row:
            self.current_client_id = row["id"]
            self.editFullName.setText(row["full_name"])
            self.editPhone.setText(row["phone"])
            birth = row["birth_date"]
            if birth:
                self.dateBirth.setDate(birth)
            QMessageBox.information(self, "Клиент найден", "Данные клиента подставлены из базы")
        else:
            self.current_client_id = None
            self.editFullName.clear()
            self.editPhone.clear()
            QMessageBox.information(self, "Клиент не найден", "Заполните данные вручную")

    def calculate_total(self):
        try:
            total, details = self.get_calculation()
            self.textResult.setPlainText(details)
            self.lblTotal.setText(f"Итого: {total} р.")
            return total
        except ValueError as e:
            QMessageBox.warning(self, "Ошибка", str(e))
            return None

    def get_calculation(self):
        start_date = self.dateStart.date().toPyDate()
        days = self.spinDays.value()
        if start_date < date.today():
            raise ValueError("Дата начала тура не может быть раньше текущей даты")
        if days < 1:
            raise ValueError("Продолжительность тура должна быть не меньше 1 суток")
        if self.comboHotel.currentIndex() == -1:
            raise ValueError("Выберите отель")

        hotel = self.comboHotel.currentData()
        hotel_total = hotel["price_per_night"] * days
        services_total = 0
        service_lines = []

        for i in range(self.lstServices.count()):
            item = self.lstServices.item(i)
            if item.checkState() == Qt.CheckState.Checked:
                service = item.data(Qt.ItemDataRole.UserRole)
                services_total += service["price"]
                service_lines.append(f"- {service['name']}: {service['price']} р.")

        total = hotel_total + services_total
        details = [
            f"Город: {self.lblCity.text()}",
            f"Отель: {hotel['name']}",
            f"Количество дней: {days}",
            f"Проживание: {hotel_total} р.",
        ]
        if service_lines:
            details.append("Дополнительные услуги:")
            details.extend(service_lines)
        else:
            details.append("Дополнительные услуги: не выбраны")
        details.append(f"Итоговая стоимость: {total} р.")
        return total, "\n".join(details)

    def validate_fields(self):
        if not self.editEmail.text().strip():
            raise ValueError("Введите email")
        if not self.editFullName.text().strip():
            raise ValueError("Введите ФИО")
        if not self.editPhone.text().strip():
            raise ValueError("Введите телефон")

    def get_age(self, birth_date):
        today = date.today()
        return today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))

    def submit_application(self):
        try:
            self.validate_fields()
            total, details = self.get_calculation()
        except ValueError as e:
            QMessageBox.warning(self, "Ошибка", str(e))
            return

        email = self.editEmail.text().strip()
        full_name = self.editFullName.text().strip()
        phone = self.editPhone.text().strip()
        birth_date = self.dateBirth.date().toPyDate()
        start_date = self.dateStart.date().toPyDate()
        days = self.spinDays.value()
        age = self.get_age(birth_date)
        status = "Требует модерации" if age < 18 else "Ожидает оплаты"
        hotel = self.comboHotel.currentData()

        con = db()
        try:
            cur = con.cursor()
            if self.current_client_id:
                client_id = self.current_client_id
                cur.execute(
                    """
                    UPDATE clients
                    SET full_name=%s, phone=%s, birth_date=%s
                    WHERE id=%s
                    """,
                    (full_name, phone, birth_date, client_id),
                )
            else:
                cur.execute("SELECT id FROM clients WHERE email=%s", (email,))
                existed = cur.fetchone()
                if existed:
                    client_id = existed["id"]
                    cur.execute(
                        """
                        UPDATE clients
                        SET full_name=%s, phone=%s, birth_date=%s
                        WHERE id=%s
                        """,
                        (full_name, phone, birth_date, client_id),
                    )
                else:
                    cur.execute(
                        """
                        INSERT INTO clients(full_name, email, phone, birth_date)
                        VALUES (%s, %s, %s, %s)
                        """,
                        (full_name, email, phone, birth_date),
                    )
                    client_id = cur.lastrowid

            cur.execute(
                """
                INSERT INTO tour_applications
                (client_id, city_id, hotel_id, start_date, days_count, total_price, status, created_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s, NOW())
                """,
                (client_id, self.city_id, hotel["id"], start_date, days, total, status),
            )
            application_id = cur.lastrowid

            for i in range(self.lstServices.count()):
                item = self.lstServices.item(i)
                if item.checkState() == Qt.CheckState.Checked:
                    service = item.data(Qt.ItemDataRole.UserRole)
                    cur.execute(
                        """
                        INSERT INTO application_services(application_id, service_id)
                        VALUES (%s, %s)
                        """,
                        (application_id, service["id"]),
                    )

            con.commit()
        except Exception as e:
            con.rollback()
            QMessageBox.critical(self, "Ошибка БД", str(e))
            return
        finally:
            con.close()

        self.textResult.setPlainText(details + f"\nСтатус заявки: {status}")
        self.lblTotal.setText(f"Итого: {total} р.")
        QMessageBox.information(self, "Успех", f"Заявка оформлена. Статус: {status}")

    def back(self):
        self.w = CatalogWindow()
        self.w.show()
        self.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CatalogWindow()
    window.show()
    sys.exit(app.exec())


####main.ui####
<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>MainWindow</class>
 <widget class="QMainWindow" name="MainWindow">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>900</width>
    <height>700</height>
   </rect>
  </property>
  <property name="windowTitle">
   <string>Путешествуй по России</string>
  </property>
  <property name="styleSheet">
   <string notr="true"/>
  </property>
  <widget class="QWidget" name="centralwidget">
   <layout class="QVBoxLayout" name="verticalLayout">
    <property name="spacing">
     <number>14</number>
    </property>
    <property name="leftMargin">
     <number>20</number>
    </property>
    <property name="topMargin">
     <number>20</number>
    </property>
    <property name="rightMargin">
     <number>20</number>
    </property>
    <property name="bottomMargin">
     <number>20</number>
    </property>
    <item>
     <widget class="QLabel" name="lblTitle">
      <property name="text">
       <string>Туристическое агентство «Путешествуй по России»</string>
      </property>
      <property name="alignment">
       <set>Qt::AlignCenter</set>
      </property>
      <property name="wordWrap">
       <bool>true</bool>
      </property>
     </widget>
    </item>
    <item>
     <layout class="QHBoxLayout" name="horizontalLayout">
      <property name="spacing">
       <number>10</number>
      </property>
      <item>
       <widget class="QLabel" name="label">
        <property name="text">
         <string>Введите текст для поиска:</string>
        </property>
       </widget>
      </item>
      <item>
       <widget class="QLineEdit" name="editSearch">
        <property name="placeholderText">
         <string>Например: Казань</string>
        </property>
       </widget>
      </item>
      <item>
       <widget class="QPushButton" name="btnSearch">
        <property name="text">
         <string>Найти</string>
        </property>
       </widget>
      </item>
     </layout>
    </item>
    <item>
     <widget class="QScrollArea" name="scrollArea">
      <property name="widgetResizable">
       <bool>true</bool>
      </property>
      <widget class="QWidget" name="scrollAreaWidgetContents">
       <property name="geometry">
        <rect>
         <x>0</x>
         <y>0</y>
         <width>858</width>
         <height>591</height>
        </rect>
       </property>
      </widget>
     </widget>
    </item>
   </layout>
  </widget>
 </widget>
 <resources/>
 <connections/>
</ui>

####order.ui#####
<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>OrderWindow</class>
 <widget class="QMainWindow" name="OrderWindow">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>950</width>
    <height>760</height>
   </rect>
  </property>
  <property name="windowTitle">
   <string>Оформление заявки</string>
  </property>
  <property name="styleSheet">
   <string notr="true"/>
  </property>
  <widget class="QWidget" name="centralwidget">
   <layout class="QVBoxLayout" name="verticalLayout_6">
    <property name="spacing">
     <number>12</number>
    </property>
    <property name="leftMargin">
     <number>18</number>
    </property>
    <property name="topMargin">
     <number>18</number>
    </property>
    <property name="rightMargin">
     <number>18</number>
    </property>
    <property name="bottomMargin">
     <number>18</number>
    </property>
    <item>
     <layout class="QHBoxLayout" name="horizontalLayout_4">
      <item>
       <widget class="QPushButton" name="btnBack">
        <property name="text">
         <string>Назад</string>
        </property>
       </widget>
      </item>
      <item>
       <widget class="QLabel" name="lblCity">
        <property name="text">
         <string>Город</string>
        </property>
        <property name="alignment">
         <set>Qt::AlignCenter</set>
        </property>
       </widget>
      </item>
     </layout>
    </item>
    <item>
     <layout class="QHBoxLayout" name="horizontalLayout_3">
      <property name="spacing">
       <number>12</number>
      </property>
      <item>
       <widget class="QGroupBox" name="groupClient">
        <property name="title">
         <string>Данные клиента</string>
        </property>
        <layout class="QVBoxLayout" name="verticalLayout">
         <item>
          <widget class="QLabel" name="label_1">
           <property name="text">
            <string>Email</string>
           </property>
          </widget>
         </item>
         <item>
          <layout class="QHBoxLayout" name="horizontalLayout">
           <item>
            <widget class="QLineEdit" name="editEmail">
             <property name="placeholderText">
              <string>mail@example.com</string>
             </property>
            </widget>
           </item>
           <item>
            <widget class="QPushButton" name="btnFindClient">
             <property name="text">
              <string>Найти</string>
             </property>
            </widget>
           </item>
          </layout>
         </item>
         <item>
          <widget class="QLabel" name="label_2">
           <property name="text">
            <string>ФИО</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QLineEdit" name="editFullName"/>
         </item>
         <item>
          <widget class="QLabel" name="label_3">
           <property name="text">
            <string>Телефон</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QLineEdit" name="editPhone"/>
         </item>
         <item>
          <widget class="QLabel" name="label_4">
           <property name="text">
            <string>Дата рождения</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QDateEdit" name="dateBirth">
           <property name="calendarPopup">
            <bool>true</bool>
           </property>
          </widget>
         </item>
        </layout>
       </widget>
      </item>
      <item>
       <widget class="QGroupBox" name="groupTour">
        <property name="title">
         <string>Параметры тура</string>
        </property>
        <layout class="QVBoxLayout" name="verticalLayout_2">
         <item>
          <widget class="QLabel" name="label_5">
           <property name="text">
            <string>Отель</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QComboBox" name="comboHotel"/>
         </item>
         <item>
          <widget class="QLabel" name="label_6">
           <property name="text">
            <string>Дата начала</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QDateEdit" name="dateStart">
           <property name="calendarPopup">
            <bool>true</bool>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QLabel" name="label_7">
           <property name="text">
            <string>Количество суток</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QSpinBox" name="spinDays">
           <property name="minimum">
            <number>1</number>
           </property>
           <property name="maximum">
            <number>365</number>
           </property>
           <property name="value">
            <number>3</number>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QLabel" name="label_8">
           <property name="text">
            <string>Дополнительные услуги</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QListWidget" name="lstServices"/>
         </item>
        </layout>
       </widget>
      </item>
     </layout>
    </item>
    <item>
     <widget class="QGroupBox" name="groupResult">
      <property name="title">
       <string>Расчёт стоимости</string>
      </property>
      <layout class="QVBoxLayout" name="verticalLayout_3">
       <item>
        <layout class="QHBoxLayout" name="horizontalLayout_2">
         <item>
          <widget class="QPushButton" name="btnCalc">
           <property name="text">
            <string>Рассчитать</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QPushButton" name="btnSubmit">
           <property name="text">
            <string>Оформление</string>
           </property>
          </widget>
         </item>
         <item>
          <widget class="QLabel" name="lblTotal">
           <property name="text">
            <string>Итого: 0 р.</string>
           </property>
          </widget>
         </item>
        </layout>
       </item>
       <item>
        <widget class="QPlainTextEdit" name="textResult">
         <property name="readOnly">
          <bool>true</bool>
         </property>
        </widget>
       </item>
      </layout>
     </widget>
    </item>
   </layout>
  </widget>
 </widget>
 <resources/>
 <connections/>
</ui>
"""