import setuptools

setuptools.setup(
    name='pyqmysqql',
    version='1.2',
    author='md_wuru',
    author_email='ars021204@gmail.com',
    description='looooooooooooooooooool',
    packages=['pyqmysqql'],
    include_package_data=True,
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.11',
)
