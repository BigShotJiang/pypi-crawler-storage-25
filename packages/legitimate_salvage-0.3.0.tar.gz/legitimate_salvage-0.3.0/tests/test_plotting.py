"""Smoke tests for legitimate_salvage.plotting.

Run with: conda run -n ml pytest tests/ -v
"""

from __future__ import annotations

import importlib
import tempfile
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import plotnine as p9
import pytest
from plotnine import aes, geom_col, geom_point, ggplot, labs

from legitimate_salvage.palettes import ThemeName, available_themes, get_palette
from legitimate_salvage.plotting import (
    color_palette,
    mpl_style,
    scale_color,
    scale_fill,
    set_theme,
    theme_plotnine,
)

ALL_THEMES: list[str] = available_themes()


# ── Palette tests ────────────────────────────────────────────────────


class TestPalettes:
    def test_available_themes_nonempty(self):
        assert len(ALL_THEMES) >= 9

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_get_palette_returns_all_keys(self, name: str):
        p = get_palette(name)  # type: ignore[arg-type]
        required = {
            "bg", "bg_alt", "bg_hl", "bg_region",
            "fg", "fg_dim", "fg_bright",
            "accent", "accent_bright", "accent_dark",
            "green", "red", "blue", "magenta", "orange", "yellow", "cyan",
            "border", "is_light",
        }
        assert required.issubset(p.keys())

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_all_colors_are_valid_hex(self, name: str):
        p = get_palette(name)  # type: ignore[arg-type]
        # Skip non-color fields (booleans, dicts, font strings)
        skip_keys = {"is_light", "syntax", "content_font_family", "code_font_family", "ui_font_family"}
        for k, v in p.items():
            if k in skip_keys:
                continue
            assert isinstance(v, str) and v.startswith("#") and len(v) == 7, (
                f"{name}.{k} = {v!r} is not a valid hex color"
            )

    def test_invalid_theme_raises(self):
        with pytest.raises(ValueError, match="Available themes"):
            get_palette("nonexistent")  # type: ignore[arg-type]


# ── Matplotlib style tests ──────────────────────────────────────────


class TestMplStyle:
    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_mpl_style_returns_dict(self, name: str):
        style = mpl_style(name)  # type: ignore[arg-type]
        assert isinstance(style, dict)
        assert "figure.facecolor" in style
        assert "axes.prop_cycle" in style

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_set_theme_updates_rcparams(self, name: str):
        set_theme(name)  # type: ignore[arg-type]
        p = get_palette(name)  # type: ignore[arg-type]
        assert mpl.rcParams["figure.facecolor"] == p["bg"]
        assert mpl.rcParams["text.color"] == p["fg"]

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_matplotlib_plot_renders(self, name: str):
        set_theme(name)  # type: ignore[arg-type]
        fig, ax = plt.subplots()
        ax.plot([0, 1, 2], [0, 1, 4])
        ax.set_title("smoke test")
        with tempfile.NamedTemporaryFile(suffix=".png") as f:
            fig.savefig(f.name)
            assert Path(f.name).stat().st_size > 0
        plt.close(fig)

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_pandas_plot_renders(self, name: str):
        set_theme(name)  # type: ignore[arg-type]
        df = pd.DataFrame({"a": [1, 2, 3], "b": [4, 5, 6]})
        ax = df.plot.bar()
        fig = ax.get_figure()
        with tempfile.NamedTemporaryFile(suffix=".png") as f:
            fig.savefig(f.name)
            assert Path(f.name).stat().st_size > 0
        plt.close(fig)


# ── Color palette tests ─────────────────────────────────────────────


class TestColorPalette:
    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_qualitative_returns_list(self, name: str):
        colors = color_palette(name, "qualitative")  # type: ignore[arg-type]
        assert isinstance(colors, list)
        assert len(colors) >= 7

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_qualitative_no_duplicates(self, name: str):
        colors = color_palette(name, "qualitative")  # type: ignore[arg-type]
        assert len(colors) == len(set(c.lower() for c in colors))

    def test_qualitative_n_truncates(self):
        colors = color_palette("olive", "qualitative", n=3)
        assert len(colors) == 3

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_sequential_returns_requested_count(self, name: str):
        for n in (3, 8, 15):
            colors = color_palette(name, "sequential", n=n)  # type: ignore[arg-type]
            assert len(colors) == n

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_sequential_colors_are_distinct(self, name: str):
        colors = color_palette(name, "sequential", n=8)  # type: ignore[arg-type]
        assert len(set(colors)) == 8

    def test_sequential_lightness_ramp_light_theme(self):
        """Light themes should ramp from light to dark."""
        import colorsys

        colors = color_palette("olive", "sequential", n=5)
        lightness = []
        for c in colors:
            r, g, b = (int(c[i : i + 2], 16) / 255 for i in (1, 3, 5))
            _, l, _ = colorsys.rgb_to_hls(r, g, b)
            lightness.append(l)
        # first should be lighter than last
        assert lightness[0] > lightness[-1]

    def test_sequential_lightness_ramp_dark_theme(self):
        """Dark themes should ramp from dark to light."""
        import colorsys

        colors = color_palette("rocinante", "sequential", n=5)
        lightness = []
        for c in colors:
            r, g, b = (int(c[i : i + 2], 16) / 255 for i in (1, 3, 5))
            _, l, _ = colorsys.rgb_to_hls(r, g, b)
            lightness.append(l)
        # first should be darker than last
        assert lightness[0] < lightness[-1]

    def test_no_theme_set_raises(self):
        import legitimate_salvage.plotting as mod

        importlib.reload(mod)
        with pytest.raises(ValueError, match="No theme set"):
            mod.color_palette()


# ── plotnine theme tests ────────────────────────────────────────────


class TestPlotnineTheme:
    @pytest.fixture()
    def sample_df(self):
        return pd.DataFrame(
            {"x": range(10), "y": np.random.default_rng(42).random(10), "g": list("aabbc") * 2}
        )

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_theme_plotnine_returns_theme(self, name: str):
        t = theme_plotnine(name)  # type: ignore[arg-type]
        assert isinstance(t, p9.theme)

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_plotnine_scatter_renders(self, name: str, sample_df: pd.DataFrame):
        set_theme(name)  # type: ignore[arg-type]
        p = (
            ggplot(sample_df, aes(x="x", y="y", color="g"))
            + geom_point()
            + theme_plotnine()
            + scale_color()
        )
        with tempfile.NamedTemporaryFile(suffix=".png") as f:
            p.save(f.name, width=6, height=4, dpi=72, verbose=False)
            assert Path(f.name).stat().st_size > 0

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_plotnine_bar_renders(self, name: str, sample_df: pd.DataFrame):
        set_theme(name)  # type: ignore[arg-type]
        p = (
            ggplot(sample_df, aes(x="g", y="y", fill="g"))
            + geom_col()
            + theme_plotnine()
            + scale_fill()
        )
        with tempfile.NamedTemporaryFile(suffix=".png") as f:
            p.save(f.name, width=6, height=4, dpi=72, verbose=False)
            assert Path(f.name).stat().st_size > 0

    @pytest.mark.parametrize("name", ALL_THEMES)
    def test_plotnine_sequential_scale(self, name: str):
        set_theme(name)  # type: ignore[arg-type]
        df = pd.DataFrame(
            {"x": range(6), "y": range(6), "rank": [f"tier_{i}" for i in range(6)]}
        )
        p = (
            ggplot(df, aes(x="x", y="y", color="rank"))
            + geom_point(size=3)
            + scale_color(kind="sequential", n=6)
            + theme_plotnine()
        )
        with tempfile.NamedTemporaryFile(suffix=".png") as f:
            p.save(f.name, width=6, height=4, dpi=72, verbose=False)
            assert Path(f.name).stat().st_size > 0
