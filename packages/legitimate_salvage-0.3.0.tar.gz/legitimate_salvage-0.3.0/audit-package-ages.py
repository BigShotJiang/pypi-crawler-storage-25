#!/usr/bin/env python3
"""
Supply chain guard: ensure all dependencies were published at least N days ago.

Checks JS packages (from yarn.lock) against the npm registry and Python
packages (from requirements-build.txt, falling back to pyproject.toml)
against PyPI. Exits non-zero if any package version is newer than the
threshold.

Usage:
    python audit-package-ages.py                  # default 7-day minimum
    python audit-package-ages.py --min-days 14    # custom threshold
    python audit-package-ages.py --js-only        # skip Python check
    python audit-package-ages.py --py-only        # skip JS check

No external dependencies — stdlib only.
"""

import argparse
import json
import re
import sys
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone, timedelta
from pathlib import Path

DEFAULT_MIN_AGE_DAYS = 7
MAX_WORKERS = 12


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------

def parse_yarn_lock(path: Path) -> dict[str, str]:
    """Parse Yarn Berry (v2+) lockfile -> {package_name: resolved_version}."""
    packages: dict[str, str] = {}
    if not path.exists():
        print(f"  warn: {path} not found, skipping JS audit", file=sys.stderr)
        return packages

    for line in path.read_text().splitlines():
        # Lines like:  resolution: "@babel/core@npm:7.27.4"
        m = re.match(r'\s+resolution:\s+"(.+)@npm:(\d[^"]*)"', line)
        if m:
            packages[m.group(1)] = m.group(2)

    return packages


def parse_pyproject_deps(path: Path) -> list[str]:
    """Extract all dependency package names from pyproject.toml.

    Covers [build-system] requires, [project] dependencies,
    [project.optional-dependencies], and [tool.hatch.*.dependencies].
    Only looks at lines whose key is 'requires' or 'dependencies'.
    """
    if not path.exists():
        print(f"  warn: {path} not found, skipping Python audit", file=sys.stderr)
        return []

    content = path.read_text()
    names: set[str] = set()

    # Track which TOML section we're in and whether we're inside an array.
    # Dependency arrays appear in these contexts:
    #   [build-system]               → requires = [...]
    #   [project]                    → dependencies = [...]
    #   [project.optional-dependencies] → <group> = [...]  (any key)
    #   [tool.hatch.*.dependencies]  → dependencies = [...]
    DEP_SECTIONS = {
        "[build-system]",
        "[project]",
        "[tool.hatch.build.hooks.jupyter-builder]",
    }
    current_section = ""
    in_dep_array = False

    for line in content.splitlines():
        stripped = line.strip()

        # Track section headers
        sec_match = re.match(r"^(\[[\w._-]+(?:\.[^\]]+)*\])", stripped)
        if sec_match:
            current_section = sec_match.group(1).lower()
            continue

        if not in_dep_array:
            # In optional-dependencies, every key is a dep array
            is_opt_deps = current_section == "[project.optional-dependencies]"
            # In other known sections, only requires/dependencies keys
            is_dep_key = current_section in {
                s.lower() for s in DEP_SECTIONS
            } and re.match(r"^(requires|dependencies)\s*=", stripped)

            if (is_opt_deps or is_dep_key) and "[" in stripped:
                in_dep_array = True
            else:
                continue

        # Extract PEP 508 package names from quoted strings on this line
        for m in re.finditer(r'"([A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?)', stripped):
            candidate = m.group(1).lower()
            # Normalize PEP 503: underscores/dots → hyphens
            candidate = re.sub(r"[_.]+", "-", candidate)
            names.add(candidate)

        if "]" in stripped:
            in_dep_array = False

    names.discard("legitimate-salvage")
    return sorted(names)


def parse_requirements_txt(path: Path) -> dict[str, str]:
    """Parse requirements.txt with pinned versions -> {name: version}.

    Only handles lines of the form ``name==version``.
    """
    pkgs: dict[str, str] = {}
    if not path.exists():
        return pkgs
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^([A-Za-z0-9_.-]+)==([^\s#]+)", line)
        if m:
            name = re.sub(r"[_.]+", "-", m.group(1).lower())
            pkgs[name] = m.group(2)
    return pkgs


# ---------------------------------------------------------------------------
# Registry checkers
# ---------------------------------------------------------------------------

def check_npm_age(
    name: str, version: str
) -> tuple[str, str, datetime | None, str | None]:
    """Return (name, version, publish_datetime, error_or_None) for an npm pkg."""
    try:
        # Fetch only the abbreviated metadata + time field
        url = f"https://registry.npmjs.org/{urllib.request.quote(name, safe='@')}"
        req = urllib.request.Request(
            url,
            headers={
                "Accept": "application/vnd.npm.install-v1+json",
            },
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read())

        time_map = data.get("modified")
        # The abbreviated doc doesn't always include per-version times.
        # Fall back to the full doc if needed.
        if isinstance(time_map, str):
            # abbreviated doc — refetch with full metadata
            req2 = urllib.request.Request(
                url, headers={"Accept": "application/json"}
            )
            with urllib.request.urlopen(req2, timeout=20) as resp2:
                data = json.loads(resp2.read())

        time_map = data.get("time", {})
        pub_str = time_map.get(version)
        if pub_str:
            pub = datetime.fromisoformat(pub_str.replace("Z", "+00:00"))
            return (name, version, pub, None)
        return (name, version, None, f"version {version} not found in registry time map")
    except urllib.error.HTTPError as exc:
        return (name, version, None, f"HTTP {exc.code}")
    except Exception as exc:
        return (name, version, None, str(exc))


def check_pypi_age(
    name: str, version: str | None = None
) -> tuple[str, str, datetime | None, str | None]:
    """Return (name, version, publish_datetime, error_or_None) for a PyPI pkg.

    If *version* is given, check that specific version; otherwise check the
    latest release.
    """
    try:
        if version:
            url = f"https://pypi.org/pypi/{urllib.request.quote(name)}/{version}/json"
        else:
            url = f"https://pypi.org/pypi/{urllib.request.quote(name)}/json"
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read())

        ver = data["info"]["version"]
        files = data.get("urls") or data.get("releases", {}).get(ver, [])
        if files:
            ts = files[0].get("upload_time_iso_8601")
            if ts:
                pub = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                return (name, ver, pub, None)
        return (name, ver, None, "no upload timestamp found")
    except urllib.error.HTTPError as exc:
        return (name, version or "?", None, f"HTTP {exc.code}")
    except Exception as exc:
        return (name, version or "?", None, str(exc))


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Audit dependency ages for supply-chain safety."
    )
    parser.add_argument(
        "--min-days",
        type=int,
        default=DEFAULT_MIN_AGE_DAYS,
        help=f"Minimum package age in days (default: {DEFAULT_MIN_AGE_DAYS})",
    )
    parser.add_argument("--js-only", action="store_true", help="Only check JS (npm)")
    parser.add_argument("--py-only", action="store_true", help="Only check Python (PyPI)")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=args.min_days)

    too_new: list[str] = []
    errors: list[str] = []
    checked = 0

    # ---- JS packages (yarn.lock) ----
    if not args.py_only:
        js_pkgs = parse_yarn_lock(root / "yarn.lock")
        if js_pkgs:
            print(f"Checking {len(js_pkgs)} JS packages against npm registry ...")
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
                futs = {
                    pool.submit(check_npm_age, name, ver): name
                    for name, ver in js_pkgs.items()
                }
                for fut in as_completed(futs):
                    name, version, pub, err = fut.result()
                    checked += 1
                    if err:
                        errors.append(f"  npm  {name}@{version} -- {err}")
                    elif pub and pub > cutoff:
                        age = (now - pub).days
                        too_new.append(
                            f"  npm  {name}@{version} -- "
                            f"published {pub.date()} ({age}d ago)"
                        )

    # ---- Python packages ----
    # Prefer requirements-build.txt (pinned versions used during release)
    # over pyproject.toml (which includes unpinned optional/test deps).
    if not args.js_only:
        reqs_file = root / "requirements-build.txt"
        pinned = parse_requirements_txt(reqs_file)
        if pinned:
            print(
                f"Checking {len(pinned)} Python packages from "
                f"{reqs_file.name} against PyPI ..."
            )
            with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
                futs = {
                    pool.submit(check_pypi_age, name, ver): name
                    for name, ver in pinned.items()
                }
                for fut in as_completed(futs):
                    name, version, pub, err = fut.result()
                    checked += 1
                    if err:
                        errors.append(f"  pypi {name}@{version} -- {err}")
                    elif pub and pub > cutoff:
                        age = (now - pub).days
                        too_new.append(
                            f"  pypi {name}@{version} -- "
                            f"published {pub.date()} ({age}d ago)"
                        )
        else:
            # Fallback: scan pyproject.toml (checks latest versions)
            py_deps = parse_pyproject_deps(root / "pyproject.toml")
            if py_deps:
                print(f"Checking {len(py_deps)} Python packages from pyproject.toml against PyPI ...")
                with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
                    futs = {
                        pool.submit(check_pypi_age, name): name
                        for name in py_deps
                    }
                    for fut in as_completed(futs):
                        name, version, pub, err = fut.result()
                        checked += 1
                        if err:
                            errors.append(f"  pypi {name}@{version} -- {err}")
                        elif pub and pub > cutoff:
                            age = (now - pub).days
                            too_new.append(
                                f"  pypi {name}@{version} -- "
                                f"published {pub.date()} ({age}d ago)"
                            )

    # ---- Report ----
    print(f"\nChecked {checked} packages (minimum age: {args.min_days} days)\n")

    if errors:
        print(f"[WARN] {len(errors)} package(s) could not be checked:")
        for e in sorted(errors):
            print(e)
        print()

    if too_new:
        print(f"[FAIL] {len(too_new)} package(s) newer than {args.min_days} days:")
        for t in sorted(too_new):
            print(t)
        sys.exit(1)
    else:
        print(f"[PASS] All {checked} packages are at least {args.min_days} days old.")


if __name__ == "__main__":
    main()
