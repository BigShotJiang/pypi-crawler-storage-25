"""
Color palettes for legitimate-salvage JupyterLab themes.

Loads palette data from palettes.json (the single source of truth shared
with the TypeScript extension). Converts camelCase keys to snake_case
for Python conventions.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Literal

ThemeName = Literal[
    "amber",
    "broadsheet",
    "caramel",
    "cinnamon",
    "graphite",
    "mauve",
    "muslin",
    "olive",
    "parchment",
    "rocinante",
    "rose-pine",
    "rose-pine-dawn",
    "rosewater",
    "spinzero",
]


def _camel_to_snake(name: str) -> str:
    """Convert camelCase to snake_case."""
    return re.sub(r"(?<=[a-z0-9])([A-Z])", r"_\1", name).lower()


def _convert_keys(d: dict) -> dict:
    """Recursively convert dict keys from camelCase to snake_case."""
    out: dict = {}
    for k, v in d.items():
        new_key = _camel_to_snake(k)
        out[new_key] = _convert_keys(v) if isinstance(v, dict) else v
    return out


def _load_palettes() -> dict[str, dict[str, str | bool]]:
    """Load palettes from JSON. Checks package dir first, then project root."""
    json_path = Path(__file__).resolve().parent / "palettes.json"
    if not json_path.exists():
        # Dev / editable install: JSON is at project root alongside src/
        json_path = Path(__file__).resolve().parent.parent / "palettes.json"
    if not json_path.exists():
        raise FileNotFoundError(
            f"palettes.json not found. Searched:\n"
            f"  {Path(__file__).resolve().parent / 'palettes.json'}\n"
            f"  {Path(__file__).resolve().parent.parent / 'palettes.json'}"
        )
    with open(json_path) as f:
        raw = json.load(f)
    return {name: _convert_keys(data) for name, data in raw.items()}


_PALETTES = _load_palettes()


def get_palette(name: ThemeName) -> dict[str, str | bool]:
    """Return a palette dict by theme name (case-insensitive)."""
    key = name.lower()
    if key not in _PALETTES:
        available = ", ".join(sorted(_PALETTES))
        raise ValueError(
            f"Unknown theme {name!r}. Available themes: {available}"
        )
    return dict(_PALETTES[key])


def available_themes() -> list[str]:
    """Return sorted list of available theme names."""
    return sorted(_PALETTES)
