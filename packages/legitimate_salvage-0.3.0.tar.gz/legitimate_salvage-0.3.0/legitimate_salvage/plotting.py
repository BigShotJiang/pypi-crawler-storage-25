"""
Matplotlib and plotnine theme integration for legitimate-salvage.

Usage::

    from legitimate_salvage.plotting import set_theme
    set_theme('olive')

    # Matplotlib / pandas plots now use the theme colors automatically.
    df.plot()

    # For plotnine, add the theme + scales to your plot:
    from legitimate_salvage.plotting import theme_plotnine, scale_color
    ggplot(df, aes(...)) + geom_point() + theme_plotnine() + scale_color()

    # Sequential palette for ordered categories:
    scale_fill(kind='sequential')
"""

from __future__ import annotations

import colorsys
from typing import Literal

from .palettes import ThemeName, get_palette

_active_theme: ThemeName | None = None

PaletteKind = Literal["qualitative", "sequential"]


# ── Color math helpers ──────────────────────────────────────────────


def _hex_to_hls(hex_color: str) -> tuple[float, float, float]:
    """Hex → (hue, lightness, saturation) via ``colorsys``."""
    r = int(hex_color[1:3], 16) / 255
    g = int(hex_color[3:5], 16) / 255
    b = int(hex_color[5:7], 16) / 255
    return colorsys.rgb_to_hls(r, g, b)


def _hls_to_hex(h: float, l: float, s: float) -> str:
    """(hue, lightness, saturation) → hex."""
    r, g, b = colorsys.hls_to_rgb(h, l, s)
    return (
        f"#{int(r * 255 + 0.5):02x}"
        f"{int(g * 255 + 0.5):02x}"
        f"{int(b * 255 + 0.5):02x}"
    )


# ── Palette generation ──────────────────────────────────────────────


def _qualitative_cycle(palette: dict) -> list[str]:
    """Distinct colors for unordered categories.

    Alternates warm/cool hues for max visual separation.
    Deduplicates (e.g. rocinante has accent == cyan).
    """
    candidates = [
        palette["accent"],
        palette["orange"],
        palette["blue"],
        palette["red"],
        palette["green"],
        palette["magenta"],
        palette["yellow"],
        palette["cyan"],
    ]
    seen: set[str] = set()
    unique: list[str] = []
    for c in candidates:
        low = c.lower()
        if low not in seen:
            seen.add(low)
            unique.append(c)
    return unique


def _sequential_colors(base_hex: str, n: int, is_light: bool) -> list[str]:
    """Generate *n* colors as a lightness ramp from *base_hex*.

    For light themes the ramp goes lightest → darkest (low → high ink).
    For dark themes it goes darkest → lightest.
    """
    h, _l, s = _hex_to_hls(base_hex)
    if is_light:
        l_start, l_end = 0.82, 0.25
        s_start, s_end = max(s * 0.35, 0.08), min(s * 1.15, 0.95)
    else:
        l_start, l_end = 0.18, 0.78
        s_start, s_end = min(s * 1.15, 0.95), max(s * 0.35, 0.08)
    colors: list[str] = []
    for i in range(n):
        t = i / max(n - 1, 1)
        li = l_start + (l_end - l_start) * t
        si = s_start + (s_end - s_start) * t
        colors.append(_hls_to_hex(h, li, si))
    return colors


# ── Internal resolution ─────────────────────────────────────────────


def _resolve(name: ThemeName | None) -> dict:
    """Resolve a palette by name, falling back to the active theme."""
    if name is None:
        if _active_theme is None:
            raise ValueError(
                "No theme set. Call set_theme() first or pass a theme name."
            )
        name = _active_theme
    return get_palette(name)


# ── Public API ───────────────────────────────────────────────────────


def color_palette(
    name: ThemeName | None = None,
    kind: PaletteKind = "qualitative",
    n: int | None = None,
) -> list[str]:
    """Return a list of theme colors as hex strings.

    Parameters
    ----------
    name
        Theme name. Uses the active theme (from :func:`set_theme`) when ``None``.
    kind
        ``'qualitative'`` — distinct hues for unordered categories (default).
        ``'sequential'`` — lightness gradient for ordered categories.
    n
        Number of colors.  Defaults to 7–8 for qualitative, 8 for sequential.
        Sequential palettes can generate any *n*; qualitative truncates at 8.
    """
    p = _resolve(name)
    if kind == "qualitative":
        colors = _qualitative_cycle(p)
        if n is not None:
            colors = colors[:n]
        return colors
    else:
        return _sequential_colors(p["accent"], n or 8, p.get("is_light", False))


def mpl_style(name: ThemeName | None = None) -> dict:
    """Return a dict of matplotlib rcParams for the given theme.

    Can be applied manually::

        import matplotlib as mpl
        mpl.rcParams.update(mpl_style('olive'))
    """
    from cycler import cycler as Cycler

    p = _resolve(name)
    is_light = p.get("is_light", False)
    cycle = _qualitative_cycle(p)

    return {
        # Figure
        "figure.facecolor": p["bg"],
        "figure.edgecolor": p["bg"],
        "figure.dpi": 150,
        # Axes
        "axes.facecolor": p["bg_alt"],
        "axes.edgecolor": p["border"],
        "axes.labelcolor": p["fg"],
        "axes.titlecolor": p["fg_bright"],
        "axes.prop_cycle": Cycler(color=cycle),
        "axes.grid": True,
        "axes.axisbelow": True,
        "axes.spines.top": False,
        "axes.spines.right": False,
        # Grid
        "grid.color": p["bg_hl"] if is_light else p["bg_region"],
        "grid.linewidth": 0.6,
        # Ticks
        "xtick.color": p["fg_dim"],
        "ytick.color": p["fg_dim"],
        "xtick.labelcolor": p["fg_dim"],
        "ytick.labelcolor": p["fg_dim"],
        # Text
        "text.color": p["fg"],
        # Legend
        "legend.facecolor": p["bg"],
        "legend.edgecolor": p["border"],
        "legend.framealpha": 0.9,
        # Save
        "savefig.facecolor": p["bg"],
        "savefig.edgecolor": "none",
        "savefig.dpi": 150,
        "savefig.bbox": "tight",
    }


def set_theme(name: ThemeName) -> None:
    """Apply a legitimate-salvage theme to matplotlib.

    Updates ``matplotlib.rcParams`` so all subsequent matplotlib and pandas
    plots use the theme's colors.  If plotnine is installed, also sets the
    global plotnine theme via ``theme_set()``.
    """
    global _active_theme
    import matplotlib as mpl

    _active_theme = name
    mpl.rcParams.update(mpl_style(name))

    try:
        import plotnine

        plotnine.theme_set(theme_plotnine(name))
    except ImportError:
        pass


def theme_plotnine(name: ThemeName | None = None):
    """Return a plotnine ``theme`` object matching the given palette.

    Inherits structure from ``theme_minimal`` and overrides colors to
    match the palette.  Add it to any ggplot::

        ggplot(...) + theme_plotnine('olive')

    If *name* is ``None``, uses the active theme from :func:`set_theme`.
    """
    from plotnine import (
        element_blank,
        element_line,
        element_rect,
        element_text,
        theme,
    )
    from plotnine.themes import theme_minimal

    p = _resolve(name)

    return theme_minimal() + theme(
        plot_background=element_rect(fill=p["bg"], colour="none"),
        panel_background=element_rect(fill=p["bg_alt"], colour="none"),
        panel_border=element_rect(colour=p["border"], fill="none"),
        panel_grid_major=element_line(colour=p["bg_hl"]),
        panel_grid_minor=element_blank(),
        axis_text=element_text(color=p["fg_dim"]),
        axis_title=element_text(color=p["fg"]),
        axis_ticks=element_line(colour=p["border"]),
        plot_title=element_text(color=p["fg_bright"], weight="bold"),
        plot_subtitle=element_text(color=p["fg"]),
        plot_caption=element_text(color=p["fg_dim"]),
        legend_background=element_rect(fill=p["bg"], colour="none"),
        legend_text=element_text(color=p["fg"]),
        legend_title=element_text(color=p["fg_bright"]),
        legend_key=element_rect(fill=p["bg_alt"], colour="none"),
        strip_background=element_rect(fill=p["bg_hl"], colour="none"),
        strip_text=element_text(color=p["fg_bright"]),
    )


def scale_color(
    name: ThemeName | None = None,
    kind: PaletteKind = "qualitative",
    n: int | None = None,
):
    """Return a plotnine ``scale_color_manual`` using the theme's color cycle.

    Pass ``kind='sequential'`` for an ordered gradient.
    """
    from plotnine import scale_color_manual

    return scale_color_manual(values=color_palette(name, kind, n))


def scale_fill(
    name: ThemeName | None = None,
    kind: PaletteKind = "qualitative",
    n: int | None = None,
):
    """Return a plotnine ``scale_fill_manual`` using the theme's color cycle.

    Pass ``kind='sequential'`` for an ordered gradient.
    """
    from plotnine import scale_fill_manual

    return scale_fill_manual(values=color_palette(name, kind, n))
