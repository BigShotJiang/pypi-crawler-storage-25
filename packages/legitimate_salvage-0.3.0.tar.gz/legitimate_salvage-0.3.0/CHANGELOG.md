# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.2.0

### New Themes

- **Rosé Pine** — muted purple/rose dark theme adapted from the [Rosé Pine](https://rosepinetheme.com) community theme
- **Rosé Pine Dawn** — warm cream/rose light theme adapted from the [Rosé Pine](https://rosepinetheme.com) community theme

### Fixes

- Fix `pyproject.toml` — `project.dynamic` field was incorrectly nested under `[project.optional-dependencies]`, breaking `pip install -e .` with newer hatchling/uv

<!-- <END NEW CHANGELOG ENTRY> -->
