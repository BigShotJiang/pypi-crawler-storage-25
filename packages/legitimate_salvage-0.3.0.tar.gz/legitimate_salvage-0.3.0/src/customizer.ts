import { Widget } from '@lumino/widgets';
import { Message } from '@lumino/messaging';
import { ISettingRegistry } from '@jupyterlab/settingregistry';
import { IThemeManager } from '@jupyterlab/apputils';
import { allPalettes, IThemePalette } from './palettes';
import { ColorPicker } from './color-picker';

// ── Types ───────────────────────────────────────────────────────

type FieldType = 'color' | 'text' | 'boolean' | 'enum';

interface IFieldDef {
  key: string;
  label: string;
  description: string;
  type: FieldType;
  enumValues?: string[];
  boolDefault?: boolean;
}

interface ISectionDef {
  key: string;
  title: string;
  fields: IFieldDef[];
  open?: boolean;
}

interface IFieldRef {
  picker?: ColorPicker;
  textEl?: HTMLInputElement;
  selectEl?: HTMLSelectElement;
  checkEl?: HTMLInputElement;
  hintEl?: HTMLElement;
  resetEl: HTMLElement;
  isGlobal: boolean;
  sectionKey: string;
  fieldKey: string;
}

export interface IThemeCustomizerOptions {
  settings: ISettingRegistry.ISettings;
  themeManager: IThemeManager;
}

// ── Display Names ───────────────────────────────────────────────

const DISPLAY_NAMES: Record<string, string> = {
  rocinante: 'Rocinante',
  amber: 'Amber',
  olive: 'Olive',
  cinnamon: 'Cinnamon',
  mauve: 'Mauve',
  rosewater: 'Rosewater',
  caramel: 'Caramel',
  parchment: 'Parchment',
  muslin: 'Muslin',
  'rose-pine': 'Ros\u00e9 Pine',
  'rose-pine-dawn': 'Ros\u00e9 Pine Dawn',
  spinzero: 'Spinzero'
};

// ── Section & Field Definitions ─────────────────────────────────

const ALIGN_ENUM = ['', 'left', 'center', 'right'];

const THEME_SECTIONS: ISectionDef[] = [
  {
    key: 'colors',
    title: 'Palette Colors',
    open: true,
    fields: [
      { key: 'bg', label: 'Primary Background', description: 'Main editor area, code cells, notebook background', type: 'color' },
      { key: 'bgAlt', label: 'Secondary Background', description: 'Sidebar, toolbar, file browser, inactive tabs', type: 'color' },
      { key: 'bgHl', label: 'Highlight Background', description: 'Hover states, active toolbar items, focus backgrounds', type: 'color' },
      { key: 'bgRegion', label: 'Selection Background', description: 'Text selection regions, multi-select cells', type: 'color' },
      { key: 'fg', label: 'Body Text', description: 'Main content text, code variable references, UI labels', type: 'color' },
      { key: 'fgDim', label: 'Secondary Text', description: 'Code comments, placeholders, muted UI chrome', type: 'color' },
      { key: 'fgBright', label: 'Headings & Emphasis', description: 'Bold text, strong emphasis, rendered heading text', type: 'color' },
      { key: 'accent', label: 'Primary Accent', description: 'Links, cursor, active cell border, active tab indicator', type: 'color' },
      { key: 'accentBright', label: 'Strong Accent', description: 'Markdown heading color, strongest brand emphasis', type: 'color' },
      { key: 'accentDark', label: 'Soft Accent', description: 'Subtle selection borders, muted brand backgrounds', type: 'color' },
      { key: 'green', label: 'Green', description: 'String literals in code, success indicators', type: 'color' },
      { key: 'red', label: 'Red', description: 'Errors, tracebacks, HTML/XML tag names', type: 'color' },
      { key: 'blue', label: 'Blue', description: 'Info messages, HTML/XML attributes', type: 'color' },
      { key: 'orange', label: 'Orange', description: 'Numeric literals, constants, atoms', type: 'color' },
      { key: 'yellow', label: 'Yellow', description: 'Warnings, type annotations', type: 'color' },
      { key: 'cyan', label: 'Cyan', description: 'Secondary accent, JSON icon, collaborator markers', type: 'color' },
      { key: 'magenta', label: 'Magenta', description: 'Collaborator colors, decorative accents', type: 'color' },
      { key: 'border', label: 'Border', description: 'Cell borders, panel separators, dividers', type: 'color' }
    ]
  },
  {
    key: 'typography',
    title: 'Typography',
    fields: [
      { key: 'codeFontFamily', label: 'Code Font Family', description: 'Font for code cells, inline code, and terminal', type: 'text' },
      { key: 'contentFontFamily', label: 'Content Font Family', description: 'Font for rendered markdown, headings, and prose', type: 'text' },
      { key: 'uiFontFamily', label: 'UI Font Family', description: 'Font for menus, tabs, sidebar, status bar', type: 'text' }
    ]
  },
  {
    key: 'syntax',
    title: 'Syntax Colors',
    fields: [
      { key: 'keyword', label: 'Keywords', description: 'if, for, def, class, import, return', type: 'color' },
      { key: 'string', label: 'Strings', description: 'String literals, f-strings, docstrings', type: 'color' },
      { key: 'string2', label: 'Strings (alternate)', description: 'Template literals, raw strings', type: 'color' },
      { key: 'number', label: 'Numbers', description: 'Numeric literals: 42, 3.14, 0xff', type: 'color' },
      { key: 'atom', label: 'Atoms / Constants', description: 'True, False, None, null, undefined', type: 'color' },
      { key: 'comment', label: 'Comments', description: '# line comments, // and /* */ block comments', type: 'color' },
      { key: 'def', label: 'Definitions', description: 'Function/class names at definition site', type: 'color' },
      { key: 'variable', label: 'Variables', description: 'Primary variable references', type: 'color' },
      { key: 'variable2', label: 'Variables (secondary)', description: 'Parameters, loop variables', type: 'color' },
      { key: 'variable3', label: 'Variables (tertiary)', description: 'Tertiary variable category', type: 'color' },
      { key: 'operator', label: 'Operators', description: '+, -, *, ==, !=, and, or, not', type: 'color' },
      { key: 'builtin', label: 'Builtins', description: 'print, len, range, int, str, list', type: 'color' },
      { key: 'meta', label: 'Decorators & Meta', description: '@property, @staticmethod, @dataclass', type: 'color' },
      { key: 'property', label: 'Properties', description: 'Attribute access: obj.property, self.name', type: 'color' },
      { key: 'punctuation', label: 'Punctuation', description: 'Commas, colons, semicolons', type: 'color' },
      { key: 'bracket', label: 'Brackets', description: 'Parentheses (), square [], curly {}', type: 'color' },
      { key: 'qualifier', label: 'Qualifiers', description: 'CSS qualifiers, type qualifiers', type: 'color' },
      { key: 'tag', label: 'Tags', description: 'HTML/XML tag names: <div>, <span>', type: 'color' },
      { key: 'attribute', label: 'Attributes', description: 'HTML/XML attribute names: class=, id=', type: 'color' },
      { key: 'header', label: 'Markdown Headers', description: 'Heading markers in code cells', type: 'color' },
      { key: 'quote', label: 'Block Quotes', description: 'Block quote markers in code cells', type: 'color' },
      { key: 'link', label: 'Links', description: 'URLs and link syntax in code', type: 'color' },
      { key: 'error', label: 'Error Highlights', description: 'Syntax errors, invalid tokens', type: 'color' },
      { key: 'hr', label: 'Horizontal Rules', description: 'Horizontal rule markers (---)', type: 'color' }
    ]
  },
  {
    key: 'markdown',
    title: 'Markdown',
    fields: [
      { key: 'headingColor', label: 'Heading Color', description: 'Color for all heading levels (h1-h6)', type: 'color' },
      { key: 'headingFontWeight', label: 'Heading Font Weight', description: 'e.g. 400 (normal), 600 (semibold), 700 (bold)', type: 'text' },
      { key: 'headingBorderBottom', label: 'Heading Bottom Border', description: 'Show a subtle border below headings', type: 'boolean', boolDefault: true },
      { key: 'headingAlign', label: 'Heading Alignment', description: 'Default alignment for all headings', type: 'enum', enumValues: ALIGN_ENUM },
      { key: 'h1Size', label: 'H1 Size', description: "e.g. '2em', '28px'", type: 'text' },
      { key: 'h2Size', label: 'H2 Size', description: "e.g. '1.6em', '24px'", type: 'text' },
      { key: 'h3Size', label: 'H3 Size', description: "e.g. '1.4em', '20px'", type: 'text' },
      { key: 'h4Size', label: 'H4 Size', description: "e.g. '1.2em', '18px'", type: 'text' },
      { key: 'h5Size', label: 'H5 Size', description: "e.g. '1em', '16px'", type: 'text' },
      { key: 'h6Size', label: 'H6 Size', description: "e.g. '0.9em', '14px'", type: 'text' },
      { key: 'h1Align', label: 'H1 Alignment', description: 'Override alignment for h1', type: 'enum', enumValues: ALIGN_ENUM },
      { key: 'h2Align', label: 'H2 Alignment', description: 'Override alignment for h2', type: 'enum', enumValues: ALIGN_ENUM },
      { key: 'h3Align', label: 'H3 Alignment', description: 'Override alignment for h3', type: 'enum', enumValues: ALIGN_ENUM },
      { key: 'h4Align', label: 'H4 Alignment', description: 'Override alignment for h4', type: 'enum', enumValues: ALIGN_ENUM },
      { key: 'h5Align', label: 'H5 Alignment', description: 'Override alignment for h5', type: 'enum', enumValues: ALIGN_ENUM },
      { key: 'h6Align', label: 'H6 Alignment', description: 'Override alignment for h6', type: 'enum', enumValues: ALIGN_ENUM },
      { key: 'blockquoteBorderColor', label: 'Blockquote Border', description: 'Left border color on blockquotes', type: 'color' },
      { key: 'blockquoteBorderWidth', label: 'Blockquote Border Width', description: "e.g. '3px', '4px'", type: 'text' },
      { key: 'blockquoteTextColor', label: 'Blockquote Text', description: 'Text color inside blockquotes', type: 'color' },
      { key: 'inlineCodeBackground', label: 'Inline Code Background', description: 'Background for `inline code`', type: 'color' },
      { key: 'inlineCodeColor', label: 'Inline Code Text', description: 'Text color for `inline code`', type: 'color' },
      { key: 'codeBlockBackground', label: 'Code Block Background', description: 'Background for fenced code blocks', type: 'color' },
      { key: 'linkColor', label: 'Link Color', description: 'Color for hyperlinks in rendered markdown', type: 'color' }
    ]
  },
  {
    key: 'dataframes',
    title: 'DataFrames',
    fields: [
      { key: 'headerBackground', label: 'Header Background', description: 'Background for table header cells', type: 'color' },
      { key: 'headerColor', label: 'Header Text Color', description: 'Text color for table header cells', type: 'color' },
      { key: 'headerFontWeight', label: 'Header Font Weight', description: 'e.g. 400, 600, 700', type: 'text' },
      { key: 'rowAltBackground', label: 'Alternating Row Background', description: 'Even-numbered row background (zebra striping)', type: 'color' },
      { key: 'rowHoverBackground', label: 'Row Hover Background', description: 'Background on row hover', type: 'color' },
      { key: 'borderColor', label: 'Border Color', description: 'Table borders and cell dividers', type: 'color' },
      { key: 'fontFamily', label: 'Font Family', description: "'content' (default), 'code', or a custom font name", type: 'text' }
    ]
  },
  {
    key: 'toc',
    title: 'Table of Contents',
    fields: [
      { key: 'fontSize', label: 'Font Size', description: "e.g. '12px', '0.85em'", type: 'text' },
      { key: 'activeColor', label: 'Active Item Color', description: 'Highlight for the current heading', type: 'color' },
      { key: 'indentSize', label: 'Indent Size', description: "e.g. '12px', '16px'", type: 'text' }
    ]
  }
];

const GLOBAL_SECTIONS: ISectionDef[] = [
  {
    key: 'typography',
    title: 'Typography',
    fields: [
      { key: 'codeFontFamily', label: 'Code Font Family', description: 'Default code font across all themes', type: 'text' },
      { key: 'contentFontFamily', label: 'Content Font Family', description: 'Default content font across all themes', type: 'text' },
      { key: 'uiFontFamily', label: 'UI Font Family', description: 'Default UI font across all themes', type: 'text' },
      { key: 'codeFontSize', label: 'Code Font Size', description: "e.g. '13px', '14px'", type: 'text' },
      { key: 'contentFontSize', label: 'Content Font Size', description: "e.g. '14px', '15px'", type: 'text' },
      { key: 'uiFontSize', label: 'UI Font Size', description: "e.g. '13px'", type: 'text' },
      { key: 'codeLineHeight', label: 'Code Line Height', description: 'e.g. 1.4, 1.5 (unitless recommended)', type: 'text' },
      { key: 'contentLineHeight', label: 'Content Line Height', description: 'e.g. 1.6, 1.8 (unitless recommended)', type: 'text' }
    ]
  },
  {
    key: 'layout',
    title: 'Layout',
    fields: [
      { key: 'borderRadius', label: 'Border Radius', description: "e.g. '4px', '0' for sharp, '8px' for rounded", type: 'text' },
      { key: 'cellPadding', label: 'Cell Padding', description: "Internal padding inside each cell (e.g. '8px')", type: 'text' },
      { key: 'notebookPadding', label: 'Notebook Padding', description: "Margin around notebook content (e.g. '12px')", type: 'text' },
      { key: 'promptWidth', label: 'Prompt Width', description: "Width of In[]/Out[] gutter (e.g. '80px', '0' to hide)", type: 'text' },
      { key: 'cursorWidth', label: 'Cursor Width', description: "Text cursor width (e.g. '1.4px', '2px')", type: 'text' }
    ]
  },
  {
    key: 'scrollbar',
    title: 'Scrollbar',
    fields: [
      { key: 'autoHide', label: 'Auto-hide Scrollbar', description: 'Follow OS behavior (auto-hide on macOS)', type: 'boolean', boolDefault: true },
      { key: 'width', label: 'Width', description: "Custom scrollbar width when auto-hide is off (e.g. '10px')", type: 'text' },
      { key: 'thumbColor', label: 'Thumb Color', description: 'Color of the scrollbar thumb', type: 'color' },
      { key: 'trackColor', label: 'Track Color', description: 'Color of the scrollbar track', type: 'color' }
    ]
  },
  {
    key: 'terminal',
    title: 'Terminal',
    fields: [
      { key: 'useThemeColors', label: 'Use Theme Colors', description: 'Map palette colors to terminal ANSI colors', type: 'boolean', boolDefault: true }
    ]
  }
];

// ── Default Value Helpers ───────────────────────────────────────

function syntaxDefault(key: string, p: IThemePalette): string {
  if (p.syntax) {
    const val = p.syntax[key as keyof typeof p.syntax];
    if (val) {
      return val;
    }
  }
  const map: Record<string, string> = {
    keyword: p.accent,
    atom: p.orange,
    number: p.orange,
    def: p.accentBright,
    variable: p.fgBright,
    variable2: p.fg,
    variable3: p.fgDim,
    punctuation: p.fgDim,
    property: p.fg,
    operator: p.accent,
    comment: p.fgDim,
    string: p.green,
    string2: p.green,
    meta: p.orange,
    qualifier: p.fgDim,
    builtin: p.accent,
    bracket: p.fgDim,
    tag: p.red,
    attribute: p.blue,
    header: p.accent,
    quote: p.fgDim,
    link: p.accent,
    error: p.red,
    hr: p.bgRegion
  };
  return map[key] ?? p.fg;
}

function getFieldDefault(
  isGlobal: boolean,
  sectionKey: string,
  fieldKey: string,
  palette: IThemePalette | null
): string {
  if (!palette) {
    return '';
  }

  if (isGlobal) {
    if (sectionKey === 'typography') {
      const typoDefaults: Record<string, string> = {
        codeFontFamily:
          palette.codeFontFamily || 'Input Mono, JetBrains Mono, ...',
        contentFontFamily:
          palette.contentFontFamily || 'Inter, -apple-system, ...',
        uiFontFamily: '(inherits content font)',
        codeFontSize: '13px',
        contentFontSize: '14px',
        uiFontSize: '13px',
        codeLineHeight: '1.4',
        contentLineHeight: '1.6'
      };
      return typoDefaults[fieldKey] ?? '';
    }
    if (sectionKey === 'layout') {
      const layoutDefaults: Record<string, string> = {
        borderRadius: '4px',
        cellPadding: '8px',
        notebookPadding: '12px',
        promptWidth: '80px',
        cursorWidth: '1.4px'
      };
      return layoutDefaults[fieldKey] ?? '';
    }
    if (sectionKey === 'scrollbar') {
      if (fieldKey === 'thumbColor') {
        return palette.border;
      }
      if (fieldKey === 'trackColor') {
        return palette.bgAlt;
      }
      if (fieldKey === 'width') {
        return '10px';
      }
    }
    return '';
  }

  switch (sectionKey) {
    case 'colors':
      return (palette as Record<string, any>)[fieldKey] ?? '';
    case 'syntax':
      return syntaxDefault(fieldKey, palette);
    case 'typography':
      if (fieldKey === 'codeFontFamily') {
        return palette.codeFontFamily ?? '(global default)';
      }
      if (fieldKey === 'contentFontFamily') {
        return palette.contentFontFamily ?? '(global default)';
      }
      if (fieldKey === 'uiFontFamily') {
        return palette.uiFontFamily ?? '(inherits content font)';
      }
      return '';
    case 'markdown': {
      const mdMap: Record<string, string> = {
        headingColor: palette.accentBright,
        headingFontWeight: '600',
        blockquoteBorderColor: palette.accentDark,
        blockquoteBorderWidth: '3px',
        blockquoteTextColor: palette.fgDim,
        inlineCodeBackground: palette.bgHl,
        inlineCodeColor: palette.orange,
        codeBlockBackground: palette.bgAlt,
        linkColor: palette.accent,
        h1Size: '2em',
        h2Size: '1.6em',
        h3Size: '1.3em',
        h4Size: '1.1em',
        h5Size: '1em',
        h6Size: '0.9em'
      };
      return mdMap[fieldKey] ?? '';
    }
    case 'dataframes': {
      const dfMap: Record<string, string> = {
        headerBackground: palette.bgHl,
        headerColor: palette.accent,
        headerFontWeight: '600',
        rowAltBackground: palette.bgRegion,
        rowHoverBackground: palette.accent,
        borderColor: palette.bgHl,
        fontFamily: 'content'
      };
      return dfMap[fieldKey] ?? '';
    }
    case 'toc': {
      const tocMap: Record<string, string> = {
        fontSize: '13px',
        activeColor: palette.accent,
        indentSize: '12px'
      };
      return tocMap[fieldKey] ?? '';
    }
    default:
      return '';
  }
}

// ── Validation Helpers ──────────────────────────────────────────

function validateFont(fontName: string): boolean {
  if (!fontName || fontName === 'content' || fontName === 'code') {
    return true;
  }
  try {
    return document.fonts.check(`12px "${fontName}"`);
  } catch {
    return true;
  }
}

type ValidationKind = 'css-size' | 'font-weight' | 'line-height' | 'none';

const CSS_SIZE_FIELDS = new Set([
  'codeFontSize', 'contentFontSize', 'uiFontSize',
  'borderRadius', 'cellPadding', 'notebookPadding', 'promptWidth', 'cursorWidth',
  'width',
  'h1Size', 'h2Size', 'h3Size', 'h4Size', 'h5Size', 'h6Size',
  'blockquoteBorderWidth', 'fontSize', 'indentSize'
]);

const FONT_WEIGHT_FIELDS = new Set(['headingFontWeight', 'headerFontWeight']);
const LINE_HEIGHT_FIELDS = new Set(['codeLineHeight', 'contentLineHeight']);

function getValidationKind(fieldKey: string): ValidationKind {
  if (CSS_SIZE_FIELDS.has(fieldKey)) {
    return 'css-size';
  }
  if (FONT_WEIGHT_FIELDS.has(fieldKey)) {
    return 'font-weight';
  }
  if (LINE_HEIGHT_FIELDS.has(fieldKey)) {
    return 'line-height';
  }
  return 'none';
}

function validateFieldValue(value: string, kind: ValidationKind): boolean {
  if (!value) {
    return true;
  }
  switch (kind) {
    case 'css-size':
      return /^\d+(\.\d+)?(px|em|rem|%)$/.test(value) || value === '0';
    case 'font-weight':
      if (/^\d+$/.test(value)) {
        const n = parseInt(value, 10);
        return n >= 100 && n <= 900;
      }
      return ['normal', 'bold', 'lighter', 'bolder'].includes(
        value.toLowerCase()
      );
    case 'line-height':
      return (
        /^\d+(\.\d+)?$/.test(value) ||
        /^\d+(\.\d+)?(px|em|rem|%)$/.test(value)
      );
    default:
      return true;
  }
}

const VALIDATION_HINTS: Record<ValidationKind, string> = {
  'css-size': 'Expected a CSS size like "13px", "1.2em", "2rem"',
  'font-weight': 'Expected 100\u2013900 or "normal"/"bold"',
  'line-height': 'Expected a number like "1.4" or a size like "20px"',
  none: ''
};

function hasOverride(userValue: unknown): boolean {
  if (userValue === undefined || userValue === null) {
    return false;
  }
  if (typeof userValue === 'string') {
    return userValue !== '';
  }
  return true;
}

// ── Syntax Preview Helpers ──────────────────────────────────────

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/** Build a <span> styled with the corresponding --jp-mirror-editor-*-color variable. */
function syn(token: string, text: string): string {
  const cssVar = `--jp-mirror-editor-${token.replace(/(\d)/, '-$1')}-color`;
  return `<span style="color:var(${cssVar})">${escapeHtml(text)}</span>`;
}

// ── Styles ──────────────────────────────────────────────────────

const STYLE_ID = 'legitimate-salvage-customizer-styles';

const CUSTOMIZER_CSS = `
.ls-customizer {
  display: flex;
  flex-direction: column;
  height: 100%;
  font-family: var(--jp-ui-font-family);
  color: var(--jp-ui-font-color0);
  background: var(--jp-layout-color0);
}
.ls-customizer-header {
  flex: 0 0 auto;
  padding: 16px 20px 12px;
  border-bottom: 1px solid var(--jp-border-color1);
}
.ls-customizer-header h2 {
  margin: 0 0 2px;
  font-size: 1.2em;
  font-weight: 600;
}
.ls-customizer-subtitle {
  margin: 0 0 8px;
  color: var(--jp-ui-font-color2);
  font-size: 0.85em;
}
.ls-customizer-body {
  flex: 1 1 auto;
  overflow-y: auto;
  padding: 12px 20px 20px;
}
.ls-customizer-divider {
  margin: 16px 0 8px;
  font-size: 0.75em;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--jp-ui-font-color2);
}
.ls-section {
  margin-bottom: 4px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius, 4px);
}
.ls-section > summary {
  padding: 6px 12px;
  cursor: pointer;
  background: var(--jp-layout-color1);
  font-size: 0.9em;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 8px;
  user-select: none;
  list-style: none;
}
.ls-section > summary::-webkit-details-marker { display: none; }
.ls-section > summary::before {
  content: '';
  display: inline-block;
  border-left: 5px solid var(--jp-ui-font-color2);
  border-top: 4px solid transparent;
  border-bottom: 4px solid transparent;
  transition: transform 0.15s;
  flex: 0 0 auto;
}
.ls-section[open] > summary::before { transform: rotate(90deg); }
.ls-section > summary:hover { background: var(--jp-layout-color2); }
.ls-section-title { flex: 1; }
.ls-badge {
  font-size: 0.8em;
  color: var(--jp-brand-color1);
}
.ls-section-reset {
  font-size: 0.75em;
  padding: 1px 6px;
  background: none;
  border: 1px solid var(--jp-border-color1);
  border-radius: 3px;
  cursor: pointer;
  color: var(--jp-ui-font-color2);
}
.ls-section-reset:hover {
  color: var(--jp-brand-color1);
  border-color: var(--jp-brand-color1);
}
.ls-fields { padding: 4px 12px 8px; }
.ls-field {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 3px 0;
  min-height: 28px;
}
.ls-field > label {
  flex: 0 0 175px;
  font-size: 0.82em;
  color: var(--jp-ui-font-color1);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ls-color-group {
  display: flex;
  align-items: center;
  gap: 6px;
}
.ls-color-group input[type=text] {
  width: 80px;
  padding: 2px 5px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 3px;
  background: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  font-family: var(--jp-code-font-family);
  font-size: 0.8em;
}
.ls-field input[type=text],
.ls-field select {
  padding: 2px 5px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 3px;
  background: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  font-size: 0.82em;
}
.ls-field input[type=text] { width: 200px; }
.ls-field select { width: 110px; }
.ls-field input[type=checkbox] {
  width: 16px;
  height: 16px;
  accent-color: var(--jp-brand-color1);
}
.ls-reset {
  padding: 0 4px;
  background: none;
  border: none;
  cursor: pointer;
  color: var(--jp-ui-font-color2);
  font-size: 0.9em;
  opacity: 0.5;
  flex: 0 0 auto;
}
.ls-reset:hover { opacity: 1; color: var(--jp-brand-color1); }
.ls-field-hint {
  font-size: 0.72em;
  color: var(--jp-error-color0, #d85050);
  white-space: nowrap;
  flex: 0 1 auto;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ls-hidden { visibility: hidden; }
.ls-not-active {
  padding: 40px 20px;
  text-align: center;
  color: var(--jp-ui-font-color2);
  line-height: 1.8;
}
.ls-not-active p { margin: 0 0 12px; }
.ls-not-active ul {
  list-style: none;
  padding: 0;
  font-size: 0.9em;
}
.ls-reset-all {
  padding: 4px 12px;
  background: none;
  border: 1px solid var(--jp-border-color1);
  border-radius: 3px;
  cursor: pointer;
  color: var(--jp-ui-font-color2);
  font-size: 0.82em;
}
.ls-reset-all:hover {
  color: var(--jp-error-color0, #d85050);
  border-color: var(--jp-error-color0, #d85050);
}
.ls-field input.ls-warn {
  border-color: var(--jp-warn-color0, #d8c860);
  box-shadow: 0 0 0 1px var(--jp-warn-color0, #d8c860);
}
.ls-search-box {
  position: sticky;
  top: 0;
  z-index: 1;
  padding: 8px 0 12px;
  background: var(--jp-layout-color0);
}
.ls-search-box input {
  width: 100%;
  padding: 6px 10px;
  border: 1px solid var(--jp-border-color1);
  border-radius: var(--jp-border-radius, 4px);
  background: var(--jp-layout-color1);
  color: var(--jp-ui-font-color0);
  font-size: 0.85em;
  box-sizing: border-box;
}
.ls-search-box input:focus {
  border-color: var(--jp-brand-color1);
  outline: none;
}
.ls-section-content {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  gap: 0 16px;
}
.ls-section-content > .ls-fields {
  flex: 0 0 auto;
}
.ls-syntax-preview {
  flex: 1 1 340px;
  position: sticky;
  top: 0;
  max-height: calc(100vh - 120px);
  overflow-y: auto;
  margin: 4px 0 8px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius, 4px);
  background: var(--jp-layout-color0);
}
.ls-syntax-preview pre {
  margin: 0;
  padding: 12px 16px;
  font-family: var(--jp-code-font-family);
  font-size: var(--jp-code-font-size);
  line-height: var(--jp-code-line-height);
  white-space: pre;
  overflow-x: auto;
}
.ls-syntax-preview code {
  font-family: inherit;
}
`;

// ── Widget ──────────────────────────────────────────────────────

export class ThemeCustomizerWidget extends Widget {
  private _settings: ISettingRegistry.ISettings;
  private _themeManager: IThemeManager;
  private _themeName: string | null;
  private _debounceTimers = new Map<string, ReturnType<typeof setTimeout>>();
  private _fieldRefs = new Map<string, IFieldRef>();
  private _badgeRefs = new Map<string, HTMLElement>();
  private _sectionStates = new Map<string, boolean>();
  private _searchActive = false;

  constructor(options: IThemeCustomizerOptions) {
    super();
    this._settings = options.settings;
    this._themeManager = options.themeManager;
    this._themeName = this._themeManager.theme;
    this.addClass('ls-customizer');
    this._buildContent();
    this._settings.changed.connect(this._onSettingsChanged, this);
    this._themeManager.themeChanged.connect(this._onThemeChanged, this);
  }

  dispose(): void {
    this._settings.changed.disconnect(this._onSettingsChanged, this);
    this._themeManager.themeChanged.disconnect(this._onThemeChanged, this);
    for (const timer of this._debounceTimers.values()) {
      clearTimeout(timer);
    }
    this._disposePickers();
    super.dispose();
  }

  private _disposePickers(): void {
    for (const ref of this._fieldRefs.values()) {
      ref.picker?.dispose();
    }
  }

  protected onAfterAttach(msg: Message): void {
    super.onAfterAttach(msg);
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = CUSTOMIZER_CSS;
      document.head.appendChild(style);
    }
  }

  protected onBeforeDetach(msg: Message): void {
    document.getElementById(STYLE_ID)?.remove();
    super.onBeforeDetach(msg);
  }

  // ── Content Building ────────────────────────────────────────

  private _buildContent(): void {
    this.node.innerHTML = '';
    this._disposePickers();
    this._fieldRefs.clear();
    this._badgeRefs.clear();

    const palette = this._themeName
      ? allPalettes[this._themeName]
      : null;

    if (!palette) {
      this._buildNotActive();
      return;
    }

    // Header
    const header = document.createElement('div');
    header.className = 'ls-customizer-header';

    const h2 = document.createElement('h2');
    h2.textContent = 'Theme Customizer';
    header.appendChild(h2);

    const subtitle = document.createElement('p');
    subtitle.className = 'ls-customizer-subtitle';
    subtitle.textContent = `Active theme: ${DISPLAY_NAMES[this._themeName!] ?? this._themeName}`;
    header.appendChild(subtitle);

    const resetAllBtn = document.createElement('button');
    resetAllBtn.className = 'ls-reset-all';
    resetAllBtn.textContent = 'Reset All to Defaults';
    resetAllBtn.addEventListener('click', () => {
      this._resetAll();
    });
    header.appendChild(resetAllBtn);

    this.node.appendChild(header);

    // Body (scrollable)
    const body = document.createElement('div');
    body.className = 'ls-customizer-body';

    // Search box
    const searchBox = document.createElement('div');
    searchBox.className = 'ls-search-box';
    const searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.placeholder = 'Filter settings\u2026';
    searchInput.addEventListener('input', () => {
      this._filterFields(searchInput.value, body);
    });
    searchBox.appendChild(searchInput);
    body.appendChild(searchBox);

    // Per-theme sections
    for (const section of THEME_SECTIONS) {
      body.appendChild(this._buildSection(section, false));
    }

    // Divider
    const divider = document.createElement('div');
    divider.className = 'ls-customizer-divider';
    divider.textContent = 'Global Settings';
    body.appendChild(divider);

    // Global sections
    for (const section of GLOBAL_SECTIONS) {
      body.appendChild(this._buildSection(section, true));
    }

    this.node.appendChild(body);

    // Initialize badges
    this._updateBadges();
  }

  private _buildNotActive(): void {
    const container = document.createElement('div');
    container.className = 'ls-not-active';

    const msg = document.createElement('p');
    msg.textContent =
      'The Theme Customizer works with Legitimate Salvage themes. Switch to one of:';
    container.appendChild(msg);

    const list = document.createElement('ul');
    for (const name of Object.keys(allPalettes)) {
      const li = document.createElement('li');
      li.textContent = DISPLAY_NAMES[name] ?? name;
      list.appendChild(li);
    }
    container.appendChild(list);

    this.node.appendChild(container);
  }

  private _buildSection(
    section: ISectionDef,
    isGlobal: boolean
  ): HTMLDetailsElement {
    const details = document.createElement('details');
    details.className = 'ls-section';
    details.dataset.sectionId = `${isGlobal ? 'g' : 't'}:${section.key}`;
    if (section.open) {
      details.open = true;
    }

    const summary = document.createElement('summary');

    const titleSpan = document.createElement('span');
    titleSpan.className = 'ls-section-title';
    titleSpan.textContent = section.title;

    const badge = document.createElement('span');
    badge.className = 'ls-badge';
    const badgeId = `${isGlobal ? 'g' : 't'}:${section.key}`;
    this._badgeRefs.set(badgeId, badge);

    const resetBtn = document.createElement('button');
    resetBtn.className = 'ls-section-reset';
    resetBtn.textContent = 'Reset';
    resetBtn.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      this._resetSection(isGlobal, section.key);
    });

    summary.appendChild(titleSpan);
    summary.appendChild(badge);
    summary.appendChild(resetBtn);
    details.appendChild(summary);

    const fieldsDiv = document.createElement('div');
    fieldsDiv.className = 'ls-fields';

    for (const field of section.fields) {
      const fieldId = `${isGlobal ? 'g' : 't'}:${section.key}:${field.key}`;
      fieldsDiv.appendChild(
        this._buildField(field, fieldId, isGlobal, section.key)
      );
    }

    if (!isGlobal && section.key === 'syntax') {
      const content = document.createElement('div');
      content.className = 'ls-section-content';
      content.appendChild(fieldsDiv);
      content.appendChild(this._buildSyntaxPreview());
      details.appendChild(content);
    } else {
      details.appendChild(fieldsDiv);
    }
    return details;
  }

  private _buildSyntaxPreview(): HTMLDivElement {
    const wrap = document.createElement('div');
    wrap.className = 'ls-syntax-preview';
    const pre = document.createElement('pre');
    const code = document.createElement('code');

    // Python snippet covering all 24 syntax token types
    code.innerHTML = [
      `${syn('comment', '# A simple data processor')}`,
      `${syn('meta', '@dataclass')}`,
      `${syn('keyword', 'class')} ${syn('def', 'DataPoint')}${syn('punctuation', ':')}`,
      `    ${syn('string', '"""A tagged measurement."""')}`,
      `    ${syn('variable', 'tag')}${syn('punctuation', ':')} ${syn('qualifier', 'str')} ${syn('operator', '=')} ${syn('string2', "r'\\\\raw'")}`,
      `    ${syn('variable', 'value')}${syn('punctuation', ':')} ${syn('qualifier', 'float')} ${syn('operator', '=')} ${syn('number', '3.14')}`,
      `    ${syn('variable', 'active')}${syn('punctuation', ':')} ${syn('qualifier', 'bool')} ${syn('operator', '=')} ${syn('atom', 'True')}`,
      ``,
      `    ${syn('meta', '@property')}`,
      `    ${syn('keyword', 'def')} ${syn('def', 'label')}${syn('bracket', '(')}${syn('variable2', 'self')}${syn('bracket', ')')} ${syn('operator', '->')} ${syn('qualifier', 'str')}${syn('punctuation', ':')}`,
      `        ${syn('variable', 'result')} ${syn('operator', '=')} ${syn('string', 'f"')}${syn('bracket', '{')}${syn('variable2', 'self')}${syn('punctuation', '.')}${syn('property', 'tag')}${syn('bracket', '}')}${syn('string', ': ')}${syn('bracket', '{')}${syn('variable2', 'self')}${syn('punctuation', '.')}${syn('property', 'value')}${syn('bracket', '}')}${syn('string', '"')}`,
      `        ${syn('keyword', 'return')} ${syn('variable', 'result')}`,
      ``,
      `${syn('keyword', 'def')} ${syn('def', 'process')}${syn('bracket', '(')}${syn('variable2', 'items')}${syn('punctuation', ':')} ${syn('qualifier', 'list')}${syn('bracket', ')')} ${syn('operator', '->')} ${syn('atom', 'None')}${syn('punctuation', ':')}`,
      `    ${syn('string', '"""Transform all active items."""')}`,
      `    ${syn('keyword', 'if')} ${syn('operator', 'not')} ${syn('variable', 'items')}${syn('punctuation', ':')}`,
      `        ${syn('builtin', 'print')}${syn('bracket', '(')}${syn('string', '"Empty!"')}${syn('bracket', ')')}`,
      `        ${syn('keyword', 'return')} ${syn('atom', 'None')}`,
      `    ${syn('variable', 'total')} ${syn('operator', '=')} ${syn('builtin', 'sum')}${syn('bracket', '(')}${syn('variable2', 'p')}${syn('punctuation', '.')}${syn('property', 'value')} ${syn('keyword', 'for')} ${syn('variable2', 'p')} ${syn('keyword', 'in')} ${syn('variable', 'items')}${syn('bracket', ')')}`,
      `    ${syn('variable', 'count')}${syn('punctuation', ':')} ${syn('qualifier', 'int')} ${syn('operator', '=')} ${syn('builtin', 'len')}${syn('bracket', '(')}${syn('variable', 'items')}${syn('bracket', ')')}`,
      `    ${syn('builtin', 'print')}${syn('bracket', '(')}${syn('string', 'f"Total: ')}${syn('bracket', '{')}${syn('variable3', 'total')} ${syn('operator', '/')} ${syn('variable3', 'count')}${syn('punctuation', ':')}${syn('number', '.2f')}${syn('bracket', '}')}${syn('string', '"')}${syn('bracket', ')')}`,
      ``,
      `${syn('hr', '# \u2500\u2500\u2500 separator \u2500\u2500\u2500')}`,
      `${syn('header', '## Summary')}`,
      `${syn('quote', '> Results are logged below')}`,
      `${syn('link', 'See: https://docs.example.com')}`,
      `${syn('tag', '<div')} ${syn('attribute', 'class=')}${syn('string', '"out"')}${syn('tag', '>')}${syn('error', 'done')}${syn('tag', '</div>')}`,
    ].join('\n');

    pre.appendChild(code);
    wrap.appendChild(pre);
    return wrap;
  }

  private _buildField(
    def: IFieldDef,
    fieldId: string,
    isGlobal: boolean,
    sectionKey: string
  ): HTMLDivElement {
    const palette = this._themeName ? allPalettes[this._themeName] : null;
    const userVal = this._getUserOverride(isGlobal, sectionKey, def.key);
    const has = hasOverride(userVal);
    const defaultVal = getFieldDefault(
      isGlobal,
      sectionKey,
      def.key,
      palette
    );

    const row = document.createElement('div');
    row.className = 'ls-field';

    const label = document.createElement('label');
    label.textContent = def.label;
    label.title = def.description;
    row.appendChild(label);

    const resetBtn = document.createElement('button');
    resetBtn.className = 'ls-reset' + (has ? '' : ' ls-hidden');
    resetBtn.textContent = '\u21BA';
    resetBtn.title = `Reset to default${defaultVal ? ': ' + defaultVal : ''}`;
    resetBtn.addEventListener('click', () => {
      this._resetField(isGlobal, sectionKey, def.key);
    });

    const ref: IFieldRef = {
      resetEl: resetBtn,
      isGlobal,
      sectionKey,
      fieldKey: def.key
    };

    switch (def.type) {
      case 'color':
        this._addColorInputs(
          row,
          ref,
          has ? String(userVal) : '',
          defaultVal,
          def,
          fieldId,
          isGlobal,
          sectionKey
        );
        break;
      case 'text':
        this._addTextInput(
          row,
          ref,
          has ? String(userVal) : '',
          defaultVal,
          def,
          isGlobal,
          sectionKey
        );
        break;
      case 'boolean':
        this._addBoolInput(
          row,
          ref,
          has ? Boolean(userVal) : (def.boolDefault ?? true),
          def,
          isGlobal,
          sectionKey,
          has
        );
        break;
      case 'enum':
        this._addEnumInput(
          row,
          ref,
          has ? String(userVal) : '',
          def,
          isGlobal,
          sectionKey
        );
        break;
    }

    row.appendChild(resetBtn);
    this._fieldRefs.set(fieldId, ref);
    return row;
  }

  private _addColorInputs(
    row: HTMLDivElement,
    ref: IFieldRef,
    value: string,
    defaultVal: string,
    def: IFieldDef,
    fieldId: string,
    isGlobal: boolean,
    sectionKey: string
  ): void {
    const group = document.createElement('div');
    group.className = 'ls-color-group';

    const picker = new ColorPicker({
      value: value,
      defaultValue: defaultVal || '#000000',
      description: def.description,
      onChange: (hex: string) => {
        // Update the text input
        textInput.value = hex;
        textInput.classList.remove('ls-warn');
        if (hintEl) {
          hintEl.textContent = '';
        }
        this._debouncedWrite(fieldId, isGlobal, sectionKey, def.key, hex);
      },
      onClear: () => {
        textInput.value = '';
        textInput.classList.remove('ls-warn');
        if (hintEl) {
          hintEl.textContent = '';
        }
        this._resetField(isGlobal, sectionKey, def.key);
      }
    });

    const textInput = document.createElement('input');
    textInput.type = 'text';
    textInput.value = value;
    textInput.placeholder = defaultVal;
    textInput.maxLength = 7;

    group.appendChild(picker.element);
    group.appendChild(textInput);
    row.appendChild(group);

    const hintEl = document.createElement('span');
    hintEl.className = 'ls-field-hint';
    row.appendChild(hintEl);

    ref.picker = picker;
    ref.textEl = textInput;
    ref.hintEl = hintEl;

    // Write on text input blur/Enter
    textInput.addEventListener('change', () => {
      const val = textInput.value.trim();
      if (!val) {
        textInput.classList.remove('ls-warn');
        hintEl.textContent = '';
        picker.setDisplayValue(null, defaultVal || '#000000');
        this._resetField(isGlobal, sectionKey, def.key);
      } else if (/^#[0-9a-f]{6}$/i.test(val)) {
        textInput.classList.remove('ls-warn');
        hintEl.textContent = '';
        picker.value = val;
        this._writeField(isGlobal, sectionKey, def.key, val);
      } else if (/^[0-9a-f]{6}$/i.test(val)) {
        const hex = '#' + val;
        textInput.value = hex;
        textInput.classList.remove('ls-warn');
        hintEl.textContent = '';
        picker.value = hex;
        this._writeField(isGlobal, sectionKey, def.key, hex);
      } else {
        textInput.classList.add('ls-warn');
        hintEl.textContent = 'Expected #hex, e.g. #3a7bd5';
      }
    });
  }

  private _addTextInput(
    row: HTMLDivElement,
    ref: IFieldRef,
    value: string,
    placeholder: string,
    def: IFieldDef,
    isGlobal: boolean,
    sectionKey: string
  ): void {
    const input = document.createElement('input');
    input.type = 'text';
    input.value = value;
    input.placeholder = placeholder || '';
    row.appendChild(input);

    const hint = document.createElement('span');
    hint.className = 'ls-field-hint';
    row.appendChild(hint);

    ref.textEl = input;
    ref.hintEl = hint;

    // Font validation
    const isFontField =
      (sectionKey === 'typography' && def.key.includes('FontFamily')) ||
      (sectionKey === 'dataframes' && def.key === 'fontFamily');
    const vKind = getValidationKind(def.key);

    const validateInput = (): boolean => {
      const val = input.value.trim();
      if (!val) {
        input.classList.remove('ls-warn');
        input.title = def.description;
        hint.textContent = '';
        return true;
      }
      if (isFontField && !validateFont(val)) {
        input.classList.add('ls-warn');
        const msg = `Font "${val}" not found`;
        input.title = msg + ' \u2014 will fall back to default';
        hint.textContent = msg;
        return false;
      }
      if (vKind !== 'none' && !validateFieldValue(val, vKind)) {
        input.classList.add('ls-warn');
        input.title = VALIDATION_HINTS[vKind];
        hint.textContent = VALIDATION_HINTS[vKind];
        return false;
      }
      input.classList.remove('ls-warn');
      input.title = def.description;
      hint.textContent = '';
      return true;
    };

    input.addEventListener('change', () => {
      const val = input.value.trim();
      if (!val) {
        this._resetField(isGlobal, sectionKey, def.key);
        return;
      }
      if (validateInput()) {
        this._writeField(isGlobal, sectionKey, def.key, val);
      }
    });

    input.addEventListener('blur', () => {
      validateInput();
    });

    if (value) {
      validateInput();
    }
  }

  private _addBoolInput(
    row: HTMLDivElement,
    ref: IFieldRef,
    value: boolean,
    def: IFieldDef,
    isGlobal: boolean,
    sectionKey: string,
    currentlyHasOverride: boolean
  ): void {
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.checked = value;
    row.appendChild(input);

    ref.checkEl = input;

    // Only show reset if override differs from default
    const boolDefault = def.boolDefault ?? true;
    if (!currentlyHasOverride || value === boolDefault) {
      ref.resetEl.classList.add('ls-hidden');
    }

    input.addEventListener('change', () => {
      this._writeField(isGlobal, sectionKey, def.key, input.checked);
    });
  }

  private _addEnumInput(
    row: HTMLDivElement,
    ref: IFieldRef,
    value: string,
    def: IFieldDef,
    isGlobal: boolean,
    sectionKey: string
  ): void {
    const select = document.createElement('select');
    for (const opt of def.enumValues ?? []) {
      const option = document.createElement('option');
      option.value = opt;
      option.textContent = opt || '(default)';
      if (opt === value) {
        option.selected = true;
      }
      select.appendChild(option);
    }
    row.appendChild(select);

    ref.selectEl = select;

    select.addEventListener('change', () => {
      if (select.value) {
        this._writeField(isGlobal, sectionKey, def.key, select.value);
      } else {
        this._resetField(isGlobal, sectionKey, def.key);
      }
    });
  }

  // ── Settings Access ─────────────────────────────────────────

  private _getUserOverride(
    isGlobal: boolean,
    sectionKey: string,
    fieldKey: string
  ): unknown {
    if (isGlobal) {
      const userData = this._settings.get(sectionKey).user as
        | Record<string, unknown>
        | undefined;
      return userData?.[fieldKey];
    }
    const userData = this._settings.get('themeCustomization').user as
      | Record<string, any>
      | undefined;
    return userData?.[this._themeName!]?.[sectionKey]?.[fieldKey];
  }

  private async _writeField(
    isGlobal: boolean,
    sectionKey: string,
    fieldKey: string,
    value: string | boolean
  ): Promise<void> {
    if (this.isDisposed) {
      return;
    }
    try {
      if (isGlobal) {
        const current = JSON.parse(
          JSON.stringify(this._settings.get(sectionKey).user ?? {})
        );
        current[fieldKey] = value;
        await this._settings.set(sectionKey, current);
      } else {
        const current = JSON.parse(
          JSON.stringify(
            this._settings.get('themeCustomization').user ?? {}
          )
        );
        if (!current[this._themeName!]) {
          current[this._themeName!] = {};
        }
        if (!current[this._themeName!][sectionKey]) {
          current[this._themeName!][sectionKey] = {};
        }
        current[this._themeName!][sectionKey][fieldKey] = value;
        await this._settings.set('themeCustomization', current);
      }
    } catch (e) {
      console.warn('Failed to save setting:', e);
    }
  }

  private async _resetField(
    isGlobal: boolean,
    sectionKey: string,
    fieldKey: string
  ): Promise<void> {
    if (this.isDisposed) {
      return;
    }
    try {
      if (isGlobal) {
        const current = JSON.parse(
          JSON.stringify(this._settings.get(sectionKey).user ?? {})
        );
        delete current[fieldKey];
        await this._settings.set(sectionKey, current);
      } else {
        const current = JSON.parse(
          JSON.stringify(
            this._settings.get('themeCustomization').user ?? {}
          )
        );
        const themeData = current[this._themeName!];
        if (themeData?.[sectionKey]) {
          delete themeData[sectionKey][fieldKey];
          if (Object.keys(themeData[sectionKey]).length === 0) {
            delete themeData[sectionKey];
          }
          if (Object.keys(themeData).length === 0) {
            delete current[this._themeName!];
          }
        }
        await this._settings.set('themeCustomization', current);
      }
    } catch (e) {
      console.warn('Failed to reset setting:', e);
    }
  }

  private async _resetSection(
    isGlobal: boolean,
    sectionKey: string
  ): Promise<void> {
    if (this.isDisposed) {
      return;
    }
    try {
      if (isGlobal) {
        await this._settings.set(sectionKey, {});
      } else {
        const current = JSON.parse(
          JSON.stringify(
            this._settings.get('themeCustomization').user ?? {}
          )
        );
        if (current[this._themeName!]) {
          delete current[this._themeName!][sectionKey];
          if (Object.keys(current[this._themeName!]).length === 0) {
            delete current[this._themeName!];
          }
        }
        await this._settings.set('themeCustomization', current);
      }
    } catch (e) {
      console.warn('Failed to reset section:', e);
    }
  }

  private async _resetAll(): Promise<void> {
    if (this.isDisposed) {
      return;
    }
    try {
      // Reset all global sections
      for (const section of GLOBAL_SECTIONS) {
        await this._settings.set(section.key, {});
      }
      // Reset per-theme customization for this theme
      const current = JSON.parse(
        JSON.stringify(
          this._settings.get('themeCustomization').user ?? {}
        )
      );
      delete current[this._themeName!];
      await this._settings.set('themeCustomization', current);
    } catch (e) {
      console.warn('Failed to reset all settings:', e);
    }
  }

  private _debouncedWrite(
    fieldId: string,
    isGlobal: boolean,
    sectionKey: string,
    fieldKey: string,
    value: string
  ): void {
    const existing = this._debounceTimers.get(fieldId);
    if (existing) {
      clearTimeout(existing);
    }
    const timer = setTimeout(() => {
      this._debounceTimers.delete(fieldId);
      this._writeField(isGlobal, sectionKey, fieldKey, value);
    }, 150);
    this._debounceTimers.set(fieldId, timer);
  }

  // ── Signal Handlers ─────────────────────────────────────────

  private _onSettingsChanged(): void {
    if (this.isDisposed || !this._themeName) {
      return;
    }

    const palette = allPalettes[this._themeName];
    if (!palette) {
      return;
    }

    for (const [, ref] of this._fieldRefs) {
      const userVal = this._getUserOverride(
        ref.isGlobal,
        ref.sectionKey,
        ref.fieldKey
      );
      const has = hasOverride(userVal);
      const defaultVal = getFieldDefault(
        ref.isGlobal,
        ref.sectionKey,
        ref.fieldKey,
        palette
      );

      // Update color picker + text input
      if (ref.picker) {
        ref.picker.setDisplayValue(
          has ? String(userVal) : null,
          defaultVal || '#000000'
        );
      }
      if (ref.textEl && ref.textEl !== document.activeElement) {
        if (ref.picker) {
          // Color field text input
          ref.textEl.value = has ? String(userVal) : '';
          ref.textEl.placeholder = defaultVal;
        } else {
          // Regular text input
          ref.textEl.value = has ? String(userVal) : '';
          ref.textEl.placeholder = defaultVal;
        }
        ref.textEl.classList.remove('ls-warn');
        if (ref.hintEl) {
          ref.hintEl.textContent = '';
        }
      }
      if (ref.selectEl && ref.selectEl !== document.activeElement) {
        ref.selectEl.value = has ? String(userVal) : '';
      }
      if (ref.checkEl) {
        // Find the boolean default from the section definition
        const sections = ref.isGlobal ? GLOBAL_SECTIONS : THEME_SECTIONS;
        const sectionDef = sections.find(s => s.key === ref.sectionKey);
        const fieldDef = sectionDef?.fields.find(
          f => f.key === ref.fieldKey
        );
        const boolDefault = fieldDef?.boolDefault ?? true;
        ref.checkEl.checked = has ? Boolean(userVal) : boolDefault;

        // Show reset only if value differs from default
        const showReset = has && Boolean(userVal) !== boolDefault;
        ref.resetEl.classList.toggle('ls-hidden', !showReset);
        continue; // skip the generic reset toggle below
      }

      // Toggle reset button visibility
      ref.resetEl.classList.toggle('ls-hidden', !has);
    }

    this._updateBadges();
  }

  private _onThemeChanged(): void {
    this._themeName = this._themeManager.theme;
    this._buildContent();
  }

  private _updateBadges(): void {
    for (const [badgeId, badgeEl] of this._badgeRefs) {
      let count = 0;
      for (const [fieldId, ref] of this._fieldRefs) {
        if (!fieldId.startsWith(badgeId + ':')) {
          continue;
        }
        const userVal = this._getUserOverride(
          ref.isGlobal,
          ref.sectionKey,
          ref.fieldKey
        );
        if (hasOverride(userVal)) {
          count++;
        }
      }
      badgeEl.textContent = count > 0 ? `${count} modified` : '';
    }
  }

  // ── Search / Filter ─────────────────────────────────────────

  private _filterFields(query: string, body: HTMLElement): void {
    const q = query.trim().toLowerCase();
    const sections =
      body.querySelectorAll<HTMLDetailsElement>('.ls-section');

    if (!q) {
      // Restore original collapsed states
      if (this._searchActive) {
        sections.forEach(section => {
          const key = section.dataset.sectionId ?? '';
          const wasOpen = this._sectionStates.get(key) ?? false;
          section.open = wasOpen;
          section.style.display = '';
        });
        this._searchActive = false;
      }
      body
        .querySelectorAll<HTMLElement>('.ls-field')
        .forEach(el => {
          el.style.display = '';
        });
      body
        .querySelectorAll<HTMLElement>('.ls-customizer-divider')
        .forEach(el => {
          el.style.display = '';
        });
      return;
    }

    // Save section states before first search
    if (!this._searchActive) {
      sections.forEach(section => {
        const key = section.dataset.sectionId ?? '';
        this._sectionStates.set(key, section.open);
      });
      this._searchActive = true;
    }

    // Expand all sections and filter fields
    sections.forEach(section => {
      section.open = true;
      let visibleCount = 0;
      section
        .querySelectorAll<HTMLElement>('.ls-field')
        .forEach(field => {
          const label = field.querySelector('label');
          const matches =
            label?.textContent?.toLowerCase().includes(q) ?? false;
          field.style.display = matches ? '' : 'none';
          if (matches) {
            visibleCount++;
          }
        });
      section.style.display = visibleCount > 0 ? '' : 'none';
    });

    body
      .querySelectorAll<HTMLElement>('.ls-customizer-divider')
      .forEach(el => {
        el.style.display = 'none';
      });
  }
}
