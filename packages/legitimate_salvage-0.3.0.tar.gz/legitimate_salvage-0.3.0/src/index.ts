import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';

import { IThemeManager, MainAreaWidget } from '@jupyterlab/apputils';

import { ICommandPalette } from '@jupyterlab/apputils';

import { ISettingRegistry } from '@jupyterlab/settingregistry';

import { ThemeCustomizerWidget } from './customizer';

import {
  allPalettes,
  IThemePalette,
  injectThemeVariables,
  removeThemeVariables
} from './palettes';

import {
  readSettings,
  getThemeCustomization,
  mergeThemePalette,
  generateOverrideCSS,
  IGlobalSettings
} from './settings';

import palettesData from '../palettes.json';

const PLUGIN_ID = 'legitimate-salvage:plugin';
const OVERRIDE_STYLE_ID = 'legitimate-salvage-overrides';
const SCROLLBAR_STYLE_ID = 'legitimate-salvage-scrollbar';
const TERMINAL_STYLE_ID = 'legitimate-salvage-terminal';

/**
 * Theme metadata loaded from palettes.json.
 */
interface IThemeEntry {
  name: string;
  displayName: string;
  isLight: boolean;
  palette: IThemePalette;
}

/**
 * Build the list of themes from palettes.json.
 */
const THEME_ENTRIES: IThemeEntry[] = [
  { name: 'rocinante', displayName: 'Rocinante' },
  { name: 'amber', displayName: 'Amber' },
  { name: 'olive', displayName: 'Olive' },
  { name: 'cinnamon', displayName: 'Cinnamon' },
  { name: 'mauve', displayName: 'Mauve' },
  { name: 'rosewater', displayName: 'Rosewater' },
  { name: 'caramel', displayName: 'Caramel' },
  { name: 'parchment', displayName: 'Parchment' },
  { name: 'muslin', displayName: 'Muslin' },
  { name: 'rose-pine', displayName: 'Rosé Pine' },
  { name: 'rose-pine-dawn', displayName: 'Rosé Pine Dawn' },
  { name: 'broadsheet', displayName: 'Broadsheet' },
  { name: 'graphite', displayName: 'Graphite' },
  { name: 'spinzero', displayName: 'Spinzero' }
].map(entry => ({
  ...entry,
  isLight: (palettesData as Record<string, any>)[entry.name]?.isLight ?? false,
  palette: allPalettes[entry.name]
}));

/**
 * Inject the override CSS (granular settings beyond palette colors).
 */
function injectOverrideCSS(css: string): void {
  removeOverrideCSS();
  if (!css) {
    return;
  }
  const style = document.createElement('style');
  style.id = OVERRIDE_STYLE_ID;
  style.textContent = css;
  document.head.appendChild(style);
}

function removeOverrideCSS(): void {
  document.getElementById(OVERRIDE_STYLE_ID)?.remove();
}

/**
 * Inject or remove scrollbar CSS based on settings.
 */
function applyScrollbarCSS(
  global: IGlobalSettings,
  activeTheme: string | null
): void {
  document.getElementById(SCROLLBAR_STYLE_ID)?.remove();

  const scrollbar = global.scrollbar ?? {};
  const autoHide = scrollbar.autoHide !== false; // default true

  if (autoHide || !activeTheme) {
    // Let the OS handle scrollbar visibility (macOS auto-hides by default).
    // Remove any custom scrollbar styling so native behavior takes over.
    return;
  }

  // Custom themed scrollbar
  const width = scrollbar.width || '10px';
  const thumbColor = scrollbar.thumbColor || 'var(--jp-border-color0)';
  const trackColor = scrollbar.trackColor || 'var(--jp-layout-color1)';

  const css = `
body[data-jp-theme-name='${activeTheme}'] ::-webkit-scrollbar {
  width: ${width};
  height: ${width};
}
body[data-jp-theme-name='${activeTheme}'] ::-webkit-scrollbar-track {
  background: ${trackColor};
}
body[data-jp-theme-name='${activeTheme}'] ::-webkit-scrollbar-thumb {
  background: ${thumbColor};
  border-radius: 5px;
  border: 2px solid ${trackColor};
}
body[data-jp-theme-name='${activeTheme}'] ::-webkit-scrollbar-thumb:hover {
  background: var(--jp-brand-color2);
}`;

  const style = document.createElement('style');
  style.id = SCROLLBAR_STYLE_ID;
  style.textContent = css;
  document.head.appendChild(style);
}

/**
 * Hex to RGB for terminal ANSI color mapping.
 */
function hexToRgb(hex: string): [number, number, number] {
  return [
    parseInt(hex.slice(1, 3), 16),
    parseInt(hex.slice(3, 5), 16),
    parseInt(hex.slice(5, 7), 16)
  ];
}

function darkenHex(hex: string, amount: number): string {
  const [r, g, b] = hexToRgb(hex);
  const dr = Math.round(r * (1 - amount));
  const dg = Math.round(g * (1 - amount));
  const db = Math.round(b * (1 - amount));
  return `#${dr.toString(16).padStart(2, '0')}${dg.toString(16).padStart(2, '0')}${db.toString(16).padStart(2, '0')}`;
}

function lightenHex(hex: string, amount: number): string {
  const [r, g, b] = hexToRgb(hex);
  const lr = Math.round(r + (255 - r) * amount);
  const lg = Math.round(g + (255 - g) * amount);
  const lb = Math.round(b + (255 - b) * amount);
  return `#${lr.toString(16).padStart(2, '0')}${lg.toString(16).padStart(2, '0')}${lb.toString(16).padStart(2, '0')}`;
}

/**
 * Inject or remove terminal ANSI color CSS.
 */
function applyTerminalCSS(
  global: IGlobalSettings,
  palette: IThemePalette | null
): void {
  document.getElementById(TERMINAL_STYLE_ID)?.remove();

  const useThemeColors = global.terminal?.useThemeColors !== false; // default true
  if (!useThemeColors || !palette) {
    return;
  }

  // Map palette colors to ANSI 16-color terminal palette
  const p = palette;
  const css = `:root {
  /* ANSI normal colors (0-7) */
  --jp-terminal-color0: ${darkenHex(p.bg, -0.1)};
  --jp-terminal-color1: ${p.red};
  --jp-terminal-color2: ${p.green};
  --jp-terminal-color3: ${p.yellow};
  --jp-terminal-color4: ${p.blue};
  --jp-terminal-color5: ${p.magenta};
  --jp-terminal-color6: ${p.cyan};
  --jp-terminal-color7: ${p.fg};
  /* ANSI bright colors (8-15) */
  --jp-terminal-color8: ${p.fgDim};
  --jp-terminal-color9: ${lightenHex(p.red, 0.15)};
  --jp-terminal-color10: ${lightenHex(p.green, 0.15)};
  --jp-terminal-color11: ${lightenHex(p.yellow, 0.15)};
  --jp-terminal-color12: ${lightenHex(p.blue, 0.15)};
  --jp-terminal-color13: ${lightenHex(p.magenta, 0.15)};
  --jp-terminal-color14: ${lightenHex(p.cyan, 0.15)};
  --jp-terminal-color15: ${p.fgBright};
  /* Terminal foreground/background */
  --jp-terminal-cursor-color: ${p.accent};
}`;

  const style = document.createElement('style');
  style.id = TERMINAL_STYLE_ID;
  style.textContent = css;
  document.head.appendChild(style);
}

/**
 * Legitimate Salvage theme extension for JupyterLab.
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: PLUGIN_ID,
  autoStart: true,
  requires: [IThemeManager, ISettingRegistry],
  activate: (
    app: JupyterFrontEnd,
    manager: IThemeManager,
    settingRegistry: ISettingRegistry
  ) => {
    const style = 'legitimate-salvage/index.css';
    let currentSettings: IGlobalSettings = {};
    let activeThemeName: string | null = null;
    let activePalette: IThemePalette | null = null;

    /**
     * Re-apply the active theme with current settings.
     */
    function reapplyTheme(): void {
      if (!activeThemeName || !activePalette) {
        return;
      }
      const basePalette = allPalettes[activeThemeName];
      if (!basePalette) {
        return;
      }
      const themeOverrides = getThemeCustomization(
        currentSettings,
        activeThemeName
      );
      const merged = mergeThemePalette(
        basePalette,
        currentSettings,
        themeOverrides
      );
      activePalette = merged;

      // Re-inject palette CSS
      injectThemeVariables(activeThemeName, merged);

      // Inject granular overrides
      const overrideCSS = generateOverrideCSS(
        currentSettings,
        themeOverrides,
        activeThemeName
      );
      injectOverrideCSS(overrideCSS);

      // Apply scrollbar and terminal settings
      applyScrollbarCSS(currentSettings, activeThemeName);
      applyTerminalCSS(currentSettings, merged);
    }

    // Load settings
    settingRegistry
      .load(PLUGIN_ID)
      .then(settings => {
        currentSettings = readSettings(settings);

        // Hot reload: re-apply theme when settings change
        settings.changed.connect(() => {
          currentSettings = readSettings(settings);
          reapplyTheme();
        });

        // If a theme is already active, re-apply with loaded settings
        if (activeThemeName) {
          reapplyTheme();
        }
      })
      .catch(reason => {
        console.warn(
          `Failed to load settings for ${PLUGIN_ID}:`,
          reason
        );
      });

    // Register all themes
    for (const entry of THEME_ENTRIES) {
      manager.register({
        name: entry.name,
        displayName: entry.displayName,
        isLight: entry.isLight,
        themeScrollbars: false, // We handle scrollbar CSS ourselves
        load: () => {
          activeThemeName = entry.name;

          // Merge base palette with user settings
          const themeOverrides = getThemeCustomization(
            currentSettings,
            entry.name
          );
          const merged = mergeThemePalette(
            entry.palette,
            currentSettings,
            themeOverrides
          );
          activePalette = merged;

          // Inject palette variables
          injectThemeVariables(entry.name, merged);

          // Inject granular overrides
          const overrideCSS = generateOverrideCSS(
            currentSettings,
            themeOverrides,
            entry.name
          );
          injectOverrideCSS(overrideCSS);

          // Apply scrollbar and terminal settings
          applyScrollbarCSS(currentSettings, entry.name);
          applyTerminalCSS(currentSettings, merged);

          return manager.loadCSS(style);
        },
        unload: () => {
          removeThemeVariables(entry.name);
          removeOverrideCSS();
          document.getElementById(SCROLLBAR_STYLE_ID)?.remove();
          document.getElementById(TERMINAL_STYLE_ID)?.remove();
          activeThemeName = null;
          activePalette = null;
          return Promise.resolve(undefined);
        }
      });
    }
  }
};

const CUSTOMIZER_COMMAND = 'legitimate-salvage:open-customizer';

const customizerPlugin: JupyterFrontEndPlugin<void> = {
  id: 'legitimate-salvage:customizer',
  autoStart: true,
  requires: [IThemeManager, ISettingRegistry],
  optional: [ICommandPalette],
  activate: (
    app: JupyterFrontEnd,
    manager: IThemeManager,
    settingRegistry: ISettingRegistry,
    palette: ICommandPalette | null
  ) => {
    let widget: MainAreaWidget<ThemeCustomizerWidget> | null = null;

    app.commands.addCommand(CUSTOMIZER_COMMAND, {
      label: 'Customize Theme\u2026',
      caption: 'Open the Legitimate Salvage Theme Customizer',
      execute: async () => {
        // Re-use existing tab if open
        if (widget && !widget.isDisposed) {
          app.shell.activateById(widget.id);
          return;
        }

        const settings = await settingRegistry.load(PLUGIN_ID);

        const content = new ThemeCustomizerWidget({
          settings,
          themeManager: manager
        });

        widget = new MainAreaWidget({ content });
        widget.id = 'legitimate-salvage-customizer';
        widget.title.label = 'Theme Customizer';
        widget.title.closable = true;

        widget.disposed.connect(() => {
          widget = null;
        });

        app.shell.add(widget, 'main');
        app.shell.activateById(widget.id);
      }
    });

    if (palette) {
      palette.addItem({
        command: CUSTOMIZER_COMMAND,
        category: 'Theme'
      });
    }

  }
};

export default [plugin, customizerPlugin];
