import palettesData from '../palettes.json';

export interface ISyntaxColors {
  keyword: string;
  atom: string;
  number: string;
  def: string;
  variable: string;
  variable2: string;
  variable3: string;
  punctuation: string;
  property: string;
  operator: string;
  comment: string;
  string: string;
  string2: string;
  meta: string;
  qualifier: string;
  builtin: string;
  bracket: string;
  tag: string;
  attribute: string;
  header: string;
  quote: string;
  link: string;
  error: string;
  hr: string;
}

export interface IThemePalette {
  // Backgrounds (dark to light)
  bg: string;
  bgAlt: string;
  bgHl: string;
  bgRegion: string;
  // Foregrounds (bright to dim)
  fg: string;
  fgDim: string;
  fgBright: string;
  // Accent colors
  accent: string;
  accentBright: string;
  accentDark: string;
  // Semantic palette
  green: string;
  red: string;
  blue: string;
  magenta: string;
  orange: string;
  yellow: string;
  cyan: string;
  // Border
  border: string;
  // Optional per-theme overrides
  syntax?: Partial<ISyntaxColors>;
  uiFontFamily?: string;
  contentFontFamily?: string;
  codeFontFamily?: string;
}

/**
 * Load a palette from palettes.json. The JSON is the single source of truth
 * for both the TypeScript extension and the Python plotting module.
 */
function loadPalette(name: string): IThemePalette {
  const data = (palettesData as Record<string, any>)[name];
  if (!data) {
    throw new Error(`Unknown palette: ${name}`);
  }
  // isLight is used in manager.register(), not in the palette itself
  const { isLight: _, ...palette } = data;
  return palette as IThemePalette;
}

export const rocinantePalette = loadPalette('rocinante');
export const amberPalette = loadPalette('amber');
export const olivePalette = loadPalette('olive');
export const cinnamonPalette = loadPalette('cinnamon');
export const mauvePalette = loadPalette('mauve');
export const rosewaterPalette = loadPalette('rosewater');
export const caramelPalette = loadPalette('caramel');
export const parchmentPalette = loadPalette('parchment');
export const muslinPalette = loadPalette('muslin');
export const rosePinePalette = loadPalette('rose-pine');
export const rosePineDawnPalette = loadPalette('rose-pine-dawn');
export const broadsheetPalette = loadPalette('broadsheet');
export const graphitePalette = loadPalette('graphite');
export const spinzeroPalette = loadPalette('spinzero');

/**
 * All palettes keyed by theme name.
 */
export const allPalettes: Record<string, IThemePalette> = {
  rocinante: rocinantePalette,
  amber: amberPalette,
  olive: olivePalette,
  cinnamon: cinnamonPalette,
  mauve: mauvePalette,
  rosewater: rosewaterPalette,
  caramel: caramelPalette,
  parchment: parchmentPalette,
  muslin: muslinPalette,
  'rose-pine': rosePinePalette,
  'rose-pine-dawn': rosePineDawnPalette,
  broadsheet: broadsheetPalette,
  graphite: graphitePalette,
  spinzero: spinzeroPalette
};

/**
 * Hex to rgb helper for rgba() usage in CSS.
 */
function hexToRgb(hex: string): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `${r}, ${g}, ${b}`;
}

/**
 * Darken a hex color by mixing it toward black.
 */
function darken(hex: string, amount: number): string {
  const r = Math.round(parseInt(hex.slice(1, 3), 16) * (1 - amount));
  const g = Math.round(parseInt(hex.slice(3, 5), 16) * (1 - amount));
  const b = Math.round(parseInt(hex.slice(5, 7), 16) * (1 - amount));
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}

/**
 * Lighten a hex color by mixing it toward white.
 */
function lighten(hex: string, amount: number): string {
  const r = Math.round(
    parseInt(hex.slice(1, 3), 16) + (255 - parseInt(hex.slice(1, 3), 16)) * amount
  );
  const g = Math.round(
    parseInt(hex.slice(3, 5), 16) + (255 - parseInt(hex.slice(3, 5), 16)) * amount
  );
  const b = Math.round(
    parseInt(hex.slice(5, 7), 16) + (255 - parseInt(hex.slice(5, 7), 16)) * amount
  );
  return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
}

/**
 * Generate the full set of --jp-* CSS variables for a given palette.
 */
export function generateVariablesCSS(p: IThemePalette): string {
  return `:root {
  /* ── Layout colors ── */
  --jp-layout-color0: ${p.bg};
  --jp-layout-color1: ${p.bgAlt};
  --jp-layout-color2: ${p.bgHl};
  --jp-layout-color3: ${p.bgRegion};
  --jp-layout-color4: ${lighten(p.bgRegion, 0.15)};

  /* ── Inverse layout (icon fills in dark themes need these to be light) ── */
  --jp-inverse-layout-color0: ${p.fgBright};
  --jp-inverse-layout-color1: ${p.fg};
  --jp-inverse-layout-color2: ${p.fgDim};
  --jp-inverse-layout-color3: ${lighten(p.fgDim, 0.1)};
  --jp-inverse-layout-color4: ${darken(p.fgDim, 0.15)};

  /* ── Icon contrast colors (critical for sidebar icon visibility) ── */
  --jp-icon-contrast-color0: ${p.fgBright};
  --jp-icon-contrast-color1: ${p.accent};
  --jp-icon-contrast-color2: ${p.fg};
  --jp-icon-contrast-color3: ${p.fgDim};

  /* ── Brand / accent ── */
  --jp-brand-color0: ${p.accentBright};
  --jp-brand-color1: ${p.accent};
  --jp-brand-color2: ${p.accentDark};
  --jp-brand-color3: ${darken(p.accentDark, 0.3)};

  --jp-accent-color0: ${p.orange};
  --jp-accent-color1: ${darken(p.orange, 0.15)};
  --jp-accent-color2: ${darken(p.orange, 0.3)};
  --jp-accent-color3: ${darken(p.orange, 0.5)};

  /* ── State colors ── */
  --jp-warn-color0: ${p.yellow};
  --jp-warn-color1: ${darken(p.yellow, 0.15)};
  --jp-warn-color2: ${darken(p.yellow, 0.3)};
  --jp-warn-color3: ${darken(p.yellow, 0.5)};

  --jp-error-color0: ${p.red};
  --jp-error-color1: ${darken(p.red, 0.1)};
  --jp-error-color2: ${lighten(p.red, 0.15)};
  --jp-error-color3: ${lighten(p.red, 0.3)};

  --jp-success-color0: ${p.green};
  --jp-success-color1: ${darken(p.green, 0.1)};
  --jp-success-color2: ${lighten(p.green, 0.15)};
  --jp-success-color3: ${lighten(p.green, 0.3)};

  --jp-info-color0: ${p.blue};
  --jp-info-color1: ${darken(p.blue, 0.1)};
  --jp-info-color2: ${lighten(p.blue, 0.15)};
  --jp-info-color3: ${lighten(p.blue, 0.3)};

  /* ── Borders ── */
  --jp-border-width: 1px;
  --jp-border-radius: 4px;
  --jp-border-color0: ${p.border};
  --jp-border-color1: ${p.bgRegion};
  --jp-border-color2: ${p.bgHl};
  --jp-border-color3: ${p.bgAlt};

  /* ── Shadows ── */
  --jp-shadow-base-lightness: 0;
  --jp-shadow-umbra-color: rgba(0, 0, 0, 0.4);
  --jp-shadow-penumbra-color: rgba(0, 0, 0, 0.28);
  --jp-shadow-ambient-color: rgba(0, 0, 0, 0.24);
  --jp-elevation-z0: none;
  --jp-elevation-z1: 0 2px 1px -1px var(--jp-shadow-umbra-color), 0 1px 1px 0 var(--jp-shadow-penumbra-color), 0 1px 3px 0 var(--jp-shadow-ambient-color);
  --jp-elevation-z2: 0 3px 1px -2px var(--jp-shadow-umbra-color), 0 2px 2px 0 var(--jp-shadow-penumbra-color), 0 1px 5px 0 var(--jp-shadow-ambient-color);
  --jp-elevation-z4: 0 2px 4px -1px var(--jp-shadow-umbra-color), 0 4px 5px 0 var(--jp-shadow-penumbra-color), 0 1px 10px 0 var(--jp-shadow-ambient-color);
  --jp-elevation-z6: 0 3px 5px -1px var(--jp-shadow-umbra-color), 0 6px 10px 0 var(--jp-shadow-penumbra-color), 0 1px 18px 0 var(--jp-shadow-ambient-color);
  --jp-elevation-z8: 0 5px 5px -3px var(--jp-shadow-umbra-color), 0 8px 10px 1px var(--jp-shadow-penumbra-color), 0 3px 14px 2px var(--jp-shadow-ambient-color);
  --jp-elevation-z12: 0 7px 8px -4px var(--jp-shadow-umbra-color), 0 12px 17px 2px var(--jp-shadow-penumbra-color), 0 5px 22px 4px var(--jp-shadow-ambient-color);
  --jp-elevation-z16: 0 8px 10px -5px var(--jp-shadow-umbra-color), 0 16px 24px 2px var(--jp-shadow-penumbra-color), 0 6px 30px 5px var(--jp-shadow-ambient-color);
  --jp-elevation-z20: 0 10px 13px -6px var(--jp-shadow-umbra-color), 0 20px 31px 3px var(--jp-shadow-penumbra-color), 0 8px 38px 7px var(--jp-shadow-ambient-color);
  --jp-elevation-z24: 0 11px 15px -7px var(--jp-shadow-umbra-color), 0 24px 38px 3px var(--jp-shadow-penumbra-color), 0 9px 46px 8px var(--jp-shadow-ambient-color);

  /* ── UI Fonts ── */
  --jp-ui-font-scale-factor: 1.2;
  --jp-ui-font-size0: 0.8333em;
  --jp-ui-font-size1: 13px;
  --jp-ui-font-size2: 1.2em;
  --jp-ui-font-size3: 1.44em;
  --jp-ui-font-family: ${p.uiFontFamily ?? 'var(--jp-content-font-family)'};
  --jp-ui-font-color0: ${p.fgBright};
  --jp-ui-font-color1: ${p.fg};
  --jp-ui-font-color2: ${p.fgDim};
  --jp-ui-font-color3: ${darken(p.fgDim, 0.2)};
  --jp-ui-inverse-font-color0: ${p.bg};
  --jp-ui-inverse-font-color1: ${p.bg};
  --jp-ui-inverse-font-color2: rgba(${hexToRgb(p.bg)}, 0.8);
  --jp-ui-inverse-font-color3: rgba(${hexToRgb(p.bg)}, 0.6);

  /* ── Content fonts ── */
  --jp-content-line-height: 1.6;
  --jp-content-font-scale-factor: 1.2;
  --jp-content-font-size0: 0.8333em;
  --jp-content-font-size1: 14px;
  --jp-content-font-size2: 1.2em;
  --jp-content-font-size3: 1.44em;
  --jp-content-font-size4: 1.728em;
  --jp-content-font-size5: 2.0736em;
  --jp-content-presentation-font-size1: 17px;
  --jp-content-heading-line-height: 1.2;
  --jp-content-heading-margin-top: 1.2em;
  --jp-content-heading-margin-bottom: 0.8em;
  --jp-content-heading-font-weight: 600;
  --jp-content-font-color0: ${p.fgBright};
  --jp-content-font-color1: ${p.fg};
  --jp-content-font-color2: ${p.fgDim};
  --jp-content-font-color3: ${darken(p.fgDim, 0.2)};
  --jp-content-link-color: ${p.accent};
  --jp-content-font-family: ${p.contentFontFamily ?? "'Inter', -apple-system, blinkmacsystemfont, 'Segoe UI', helvetica, arial, sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol'"};

  /* ── Code fonts ── */
  --jp-code-font-size: 13px;
  --jp-code-line-height: 1.4;
  --jp-code-padding: 0.5em;
  --jp-code-font-family-default: ${p.codeFontFamily ?? "'Input Mono', 'JetBrains Mono', 'IBM Plex Mono', 'iA Writer Mono V', 'Fira Code', 'Consolas', monospace"};
  --jp-code-font-family: var(--jp-code-font-family-default);
  --jp-code-presentation-font-size: 16px;
  --jp-code-cursor-width0: 1.4px;
  --jp-code-cursor-width1: 2px;
  --jp-code-cursor-width2: 4px;

  /* ── Cells ── */
  --jp-cell-padding: 8px;
  --jp-cell-collapser-width: 8px;
  --jp-cell-collapser-min-height: 20px;
  --jp-cell-collapser-not-active-hover-opacity: 0.8;
  --jp-cell-editor-background: ${p.bg};
  --jp-cell-editor-border-color: ${p.bgHl};
  --jp-cell-editor-box-shadow: none;
  --jp-cell-editor-active-background: ${p.bgAlt};
  --jp-cell-editor-active-border-color: ${p.accent};
  --jp-cell-prompt-width: 80px;
  --jp-cell-prompt-font-family: var(--jp-code-font-family);
  --jp-cell-prompt-letter-spacing: 0.5px;
  --jp-cell-prompt-opacity: 1;
  --jp-cell-prompt-not-active-opacity: 0.7;
  --jp-cell-prompt-not-active-font-color: ${p.fgDim};
  --jp-cell-inprompt-font-color: ${p.accent};
  --jp-cell-outprompt-font-color: ${p.accentDark};

  /* ── Notebook ── */
  --jp-notebook-padding: 12px;
  --jp-notebook-select-background: ${p.bgHl};
  --jp-notebook-multiselected-color: rgba(${hexToRgb(p.accent)}, 0.15);
  --jp-notebook-scroll-padding: calc(100% - var(--jp-code-font-size) * var(--jp-code-line-height) - var(--jp-code-padding) - var(--jp-cell-padding) - 1px);

  /* ── Rendermime ── */
  --jp-rendermime-error-background: rgba(${hexToRgb(p.red)}, 0.08);
  --jp-rendermime-table-row-background: rgba(${hexToRgb(p.bgRegion)}, 0.3);
  --jp-rendermime-table-row-hover-background: rgba(${hexToRgb(p.accent)}, 0.08);

  /* ── Dialog ── */
  --jp-dialog-background: rgba(0, 0, 0, 0.6);

  /* ── Console ── */
  --jp-console-padding: 12px;

  /* ── Toolbar ── */
  --jp-toolbar-border-color: ${p.bgHl};
  --jp-toolbar-micro-height: 8px;
  --jp-toolbar-background: ${p.bgAlt};
  --jp-toolbar-box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.3);
  --jp-toolbar-header-margin: 6px 6px 0 6px;
  --jp-toolbar-active-background: ${p.bgHl};

  /* ── Status bar ── */
  --jp-statusbar-height: 26px;

  /* ── Input fields ── */
  --jp-input-box-shadow: none;
  --jp-input-active-background: ${p.bgHl};
  --jp-input-hover-background: ${p.bgHl};
  --jp-input-background: ${p.bgAlt};
  --jp-input-border-color: ${p.bgRegion};
  --jp-input-active-border-color: ${p.accent};

  /* ── Editor ── */
  --jp-editor-selected-background: rgba(${hexToRgb(p.accent)}, 0.2);
  --jp-editor-selected-focused-background: rgba(${hexToRgb(p.accent)}, 0.3);
  --jp-editor-cursor-color: ${p.accent};

  /* ── CodeMirror syntax highlighting (Emacs semantic roles) ── */
  --jp-mirror-editor-keyword-color: ${p.syntax?.keyword ?? p.accent};
  --jp-mirror-editor-atom-color: ${p.syntax?.atom ?? p.orange};
  --jp-mirror-editor-number-color: ${p.syntax?.number ?? p.orange};
  --jp-mirror-editor-def-color: ${p.syntax?.def ?? p.accentBright};
  --jp-mirror-editor-variable-color: ${p.syntax?.variable ?? p.fgBright};
  --jp-mirror-editor-variable-2-color: ${p.syntax?.variable2 ?? p.fg};
  --jp-mirror-editor-variable-3-color: ${p.syntax?.variable3 ?? p.fgDim};
  --jp-mirror-editor-punctuation-color: ${p.syntax?.punctuation ?? p.fgDim};
  --jp-mirror-editor-property-color: ${p.syntax?.property ?? p.fg};
  --jp-mirror-editor-operator-color: ${p.syntax?.operator ?? p.accent};
  --jp-mirror-editor-comment-color: ${p.syntax?.comment ?? p.fgDim};
  --jp-mirror-editor-string-color: ${p.syntax?.string ?? p.green};
  --jp-mirror-editor-string-2-color: ${p.syntax?.string2 ?? darken(p.green, 0.15)};
  --jp-mirror-editor-meta-color: ${p.syntax?.meta ?? p.orange};
  --jp-mirror-editor-qualifier-color: ${p.syntax?.qualifier ?? p.fgDim};
  --jp-mirror-editor-builtin-color: ${p.syntax?.builtin ?? p.accent};
  --jp-mirror-editor-bracket-color: ${p.syntax?.bracket ?? p.fgDim};
  --jp-mirror-editor-tag-color: ${p.syntax?.tag ?? p.red};
  --jp-mirror-editor-attribute-color: ${p.syntax?.attribute ?? p.blue};
  --jp-mirror-editor-header-color: ${p.syntax?.header ?? p.accent};
  --jp-mirror-editor-quote-color: ${p.syntax?.quote ?? p.fgDim};
  --jp-mirror-editor-link-color: ${p.syntax?.link ?? p.accent};
  --jp-mirror-editor-error-color: ${p.syntax?.error ?? p.red};
  --jp-mirror-editor-hr-color: ${p.syntax?.hr ?? p.bgRegion};

  /* ── Collaborator colors ── */
  --jp-collaborator-color1: ${p.red};
  --jp-collaborator-color2: ${p.cyan};
  --jp-collaborator-color3: ${p.blue};
  --jp-collaborator-color4: ${p.yellow};
  --jp-collaborator-color5: ${p.orange};
  --jp-collaborator-color6: ${lighten(p.red, 0.15)};
  --jp-collaborator-color7: ${p.magenta};

  /* ── File / activity icons ── */
  --jp-jupyter-icon-color: ${p.orange};
  --jp-notebook-icon-color: ${p.accent};
  --jp-json-icon-color: ${p.cyan};
  --jp-console-icon-background-color: ${p.bgAlt};
  --jp-console-icon-color: ${p.accent};
  --jp-terminal-icon-background-color: ${p.bg};
  --jp-terminal-icon-color: ${p.fg};
  --jp-text-editor-icon-color: ${p.fgDim};
  --jp-inspector-icon-color: ${p.blue};
  --jp-switch-color: ${p.bgRegion};
  --jp-switch-true-position-color: ${p.accent};
  --jp-switch-cursor-color: ${p.fgBright};

  /* ── Vega ── */
  --jp-vega-background: ${p.bgAlt};

  /* ── Sidebar ── */
  --jp-sidebar-min-width: 200px;

  /* ── Theme-specific tokens for structural CSS ── */
  --theme-accent-rgb: ${hexToRgb(p.accent)};
  --theme-accent-dark-rgb: ${hexToRgb(p.accentDark)};
  --theme-bg-alt-rgb: ${hexToRgb(p.bgAlt)};
}`;
}

const STYLE_ID_PREFIX = 'rocinante-theme-vars-';

/**
 * Inject theme-specific CSS variables into the document head.
 */
export function injectThemeVariables(
  themeId: string,
  palette: IThemePalette
): void {
  removeThemeVariables(themeId);
  const style = document.createElement('style');
  style.id = `${STYLE_ID_PREFIX}${themeId}`;
  style.textContent = generateVariablesCSS(palette);
  document.head.appendChild(style);
}

/**
 * Remove injected theme variables from the document head.
 */
export function removeThemeVariables(themeId: string): void {
  const existing = document.getElementById(`${STYLE_ID_PREFIX}${themeId}`);
  if (existing) {
    existing.remove();
  }
}
