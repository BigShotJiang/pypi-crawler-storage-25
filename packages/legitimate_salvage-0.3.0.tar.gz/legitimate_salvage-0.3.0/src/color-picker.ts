// ── Custom Color Picker ────────────────────────────────────────
//
// Modern HSL-first color picker with:
//   - 2D saturation/value gradient area
//   - Horizontal hue strip
//   - Hex input with paste support
//   - Editable H / S / L fields
//   - Popover anchored to a swatch trigger
//
// Internal model is HSV (maps directly to the 2D area).
// Display model is HSL (user-facing). Output is hex.

// ── Color Math ─────────────────────────────────────────────────

interface IHSV {
  h: number; // 0–360
  s: number; // 0–100
  v: number; // 0–100
}

interface IHSL {
  h: number; // 0–360
  s: number; // 0–100
  l: number; // 0–100
}

function hsvToRgb(h: number, s: number, v: number): [number, number, number] {
  s /= 100;
  v /= 100;
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;
  let r = 0,
    g = 0,
    b = 0;
  if (h < 60) {
    r = c;
    g = x;
  } else if (h < 120) {
    r = x;
    g = c;
  } else if (h < 180) {
    g = c;
    b = x;
  } else if (h < 240) {
    g = x;
    b = c;
  } else if (h < 300) {
    r = x;
    b = c;
  } else {
    r = c;
    b = x;
  }
  return [
    Math.round((r + m) * 255),
    Math.round((g + m) * 255),
    Math.round((b + m) * 255)
  ];
}

function rgbToHsv(r: number, g: number, b: number): IHSV {
  r /= 255;
  g /= 255;
  b /= 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  if (d !== 0) {
    if (max === r) {
      h = ((g - b) / d) % 6;
    } else if (max === g) {
      h = (b - r) / d + 2;
    } else {
      h = (r - g) / d + 4;
    }
    h *= 60;
    if (h < 0) {
      h += 360;
    }
  }
  const s = max === 0 ? 0 : (d / max) * 100;
  const v = max * 100;
  return { h: Math.round(h), s: Math.round(s), v: Math.round(v) };
}

function hsvToHsl(h: number, s: number, v: number): IHSL {
  s /= 100;
  v /= 100;
  const l = v * (1 - s / 2);
  let sl = 0;
  if (l > 0 && l < 1) {
    sl = (v - l) / Math.min(l, 1 - l);
  }
  return {
    h: Math.round(h),
    s: Math.round(sl * 100),
    l: Math.round(l * 100)
  };
}

function hslToHsv(h: number, s: number, l: number): IHSV {
  s /= 100;
  l /= 100;
  const v = l + s * Math.min(l, 1 - l);
  let sv = 0;
  if (v > 0) {
    sv = 2 * (1 - l / v);
  }
  return {
    h: Math.round(h),
    s: Math.round(sv * 100),
    v: Math.round(v * 100)
  };
}

function hsvToHex(h: number, s: number, v: number): string {
  const [r, g, b] = hsvToRgb(h, s, v);
  return (
    '#' +
    r.toString(16).padStart(2, '0') +
    g.toString(16).padStart(2, '0') +
    b.toString(16).padStart(2, '0')
  );
}

function hexToHsv(hex: string): IHSV | null {
  const m = hex.match(/^#?([0-9a-f]{6})$/i);
  if (!m) {
    return null;
  }
  const r = parseInt(m[1].slice(0, 2), 16);
  const g = parseInt(m[1].slice(2, 4), 16);
  const b = parseInt(m[1].slice(4, 6), 16);
  return rgbToHsv(r, g, b);
}

// ── CSS ────────────────────────────────────────────────────────

const PICKER_CSS = `
.ls-picker-swatch {
  width: 30px;
  height: 24px;
  border: 1px solid var(--jp-border-color0);
  border-radius: 4px;
  cursor: pointer;
  padding: 0;
  background: transparent;
  position: relative;
  overflow: hidden;
  flex: 0 0 auto;
}
.ls-picker-swatch-inner {
  position: absolute;
  inset: 2px;
  border-radius: 2px;
  transition: background-color 0.1s ease;
}
.ls-picker-swatch:hover {
  border-color: var(--jp-brand-color1);
}
.ls-picker-swatch:focus-visible {
  outline: 2px solid var(--jp-brand-color1);
  outline-offset: 1px;
}

/* ── Popover ── */
.ls-picker-popover {
  position: fixed;
  z-index: 10000;
  width: 232px;
  padding: 12px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color0);
  border-radius: 8px;
  box-shadow: 0 8px 30px rgba(0,0,0,0.18), 0 2px 8px rgba(0,0,0,0.08);
  opacity: 0;
  transform: translateY(4px) scale(0.98);
  transition: opacity 0.15s ease-out, transform 0.15s ease-out;
  pointer-events: none;
  font-family: var(--jp-ui-font-family);
}
.ls-picker-popover.ls-picker-open {
  opacity: 1;
  transform: translateY(0) scale(1);
  pointer-events: auto;
}

/* ── Saturation/Value Area ── */
.ls-picker-sv {
  position: relative;
  width: 208px;
  height: 150px;
  border-radius: 6px;
  cursor: crosshair;
  overflow: hidden;
  user-select: none;
  touch-action: none;
}
.ls-picker-sv-white {
  position: absolute;
  inset: 0;
  background: linear-gradient(to right, #fff, transparent);
  border-radius: 6px;
}
.ls-picker-sv-black {
  position: absolute;
  inset: 0;
  background: linear-gradient(to top, #000, transparent);
  border-radius: 6px;
}
.ls-picker-sv-thumb {
  position: absolute;
  width: 14px;
  height: 14px;
  border: 2px solid #fff;
  border-radius: 50%;
  box-shadow: 0 0 0 1px rgba(0,0,0,0.2), 0 2px 4px rgba(0,0,0,0.2);
  transform: translate(-50%, -50%);
  pointer-events: none;
  transition: box-shadow 0.1s ease;
  will-change: left, top;
}
.ls-picker-sv-thumb.ls-picker-dragging {
  box-shadow: 0 0 0 1px rgba(0,0,0,0.3), 0 2px 8px rgba(0,0,0,0.3);
  transform: translate(-50%, -50%) scale(1.15);
}

/* ── Hue Strip ── */
.ls-picker-hue {
  position: relative;
  width: 208px;
  height: 14px;
  margin-top: 10px;
  border-radius: 7px;
  background: linear-gradient(to right,
    hsl(0,100%,50%), hsl(60,100%,50%), hsl(120,100%,50%),
    hsl(180,100%,50%), hsl(240,100%,50%), hsl(300,100%,50%),
    hsl(360,100%,50%)
  );
  cursor: pointer;
  user-select: none;
  touch-action: none;
}
.ls-picker-hue-thumb {
  position: absolute;
  top: 50%;
  width: 6px;
  height: 18px;
  border: 2px solid #fff;
  border-radius: 3px;
  box-shadow: 0 0 0 1px rgba(0,0,0,0.15), 0 1px 3px rgba(0,0,0,0.2);
  transform: translate(-50%, -50%);
  pointer-events: none;
  will-change: left;
  background: transparent;
}

/* ── Inputs Row ── */
.ls-picker-inputs {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 10px;
}
.ls-picker-hex-group {
  display: flex;
  align-items: center;
  gap: 0;
  flex: 0 0 auto;
}
.ls-picker-hex-prefix {
  font-size: 0.78em;
  color: var(--jp-ui-font-color2);
  font-family: var(--jp-code-font-family);
  padding: 3px 0 3px 6px;
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color1);
  border-right: none;
  border-radius: 4px 0 0 4px;
  line-height: 1;
  height: 24px;
  box-sizing: border-box;
  display: flex;
  align-items: center;
}
.ls-picker-hex {
  width: 62px;
  padding: 3px 5px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 0 4px 4px 0;
  background: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  font-family: var(--jp-code-font-family);
  font-size: 0.78em;
  height: 24px;
  box-sizing: border-box;
}
.ls-picker-hex:focus {
  border-color: var(--jp-brand-color1);
  outline: none;
}
.ls-picker-sep {
  width: 1px;
  height: 16px;
  background: var(--jp-border-color1);
  flex: 0 0 auto;
}
.ls-picker-hsl-group {
  display: flex;
  align-items: center;
  gap: 3px;
  flex: 1 1 auto;
}
.ls-picker-hsl-field {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1px;
  flex: 1 1 0;
}
.ls-picker-hsl-input {
  width: 100%;
  padding: 3px 2px;
  border: 1px solid var(--jp-border-color1);
  border-radius: 4px;
  background: var(--jp-layout-color0);
  color: var(--jp-ui-font-color0);
  font-family: var(--jp-code-font-family);
  font-size: 0.74em;
  text-align: center;
  height: 24px;
  box-sizing: border-box;
}
.ls-picker-hsl-input:focus {
  border-color: var(--jp-brand-color1);
  outline: none;
}
.ls-picker-hsl-label {
  font-size: 0.62em;
  color: var(--jp-ui-font-color2);
  text-transform: uppercase;
  letter-spacing: 0.05em;
  user-select: none;
}
`;

let cssInjected = false;

function injectPickerCSS(): void {
  if (cssInjected) {
    return;
  }
  const style = document.createElement('style');
  style.id = 'ls-color-picker-styles';
  style.textContent = PICKER_CSS;
  document.head.appendChild(style);
  cssInjected = true;
}

// ── Color Picker Class ─────────────────────────────────────────

export interface IColorPickerOptions {
  value: string; // hex
  defaultValue: string; // hex (shown as placeholder)
  description: string;
  onChange: (hex: string) => void;
  onClear: () => void;
}

export class ColorPicker {
  private _hsv: IHSV;
  private _onChange: (hex: string) => void;
  private _onClear: () => void;
  private _defaultValue: string;
  private _hasUserValue: boolean;

  // DOM
  readonly element: HTMLDivElement;
  private _swatch: HTMLButtonElement;
  private _swatchInner: HTMLDivElement;
  private _popover: HTMLDivElement;
  private _svArea: HTMLDivElement;
  private _svThumb: HTMLDivElement;
  private _hueStrip: HTMLDivElement;
  private _hueThumb: HTMLDivElement;
  private _hexInput: HTMLInputElement;
  private _hInput: HTMLInputElement;
  private _sInput: HTMLInputElement;
  private _lInput: HTMLInputElement;

  // State
  private _isOpen = false;
  private _isDraggingSV = false;
  private _isDraggingHue = false;
  private _disposed = false;

  // Bound handlers for cleanup
  private _onDocClick: (e: MouseEvent) => void;
  private _onDocKeydown: (e: KeyboardEvent) => void;

  constructor(options: IColorPickerOptions) {
    injectPickerCSS();

    this._onChange = options.onChange;
    this._onClear = options.onClear;
    this._defaultValue = options.defaultValue || '#000000';
    this._hasUserValue = !!options.value;

    const initialHex = options.value || this._defaultValue;
    this._hsv = hexToHsv(initialHex) || { h: 0, s: 0, v: 0 };

    // ── Build DOM ──
    this.element = document.createElement('div');
    this.element.style.display = 'inline-flex';
    this.element.style.alignItems = 'center';
    this.element.style.position = 'relative';

    // Swatch trigger
    this._swatch = document.createElement('button');
    this._swatch.type = 'button';
    this._swatch.className = 'ls-picker-swatch';
    this._swatch.title = options.description;
    this._swatchInner = document.createElement('div');
    this._swatchInner.className = 'ls-picker-swatch-inner';
    this._swatch.appendChild(this._swatchInner);
    this.element.appendChild(this._swatch);

    // Popover
    this._popover = document.createElement('div');
    this._popover.className = 'ls-picker-popover';

    // SV area
    this._svArea = document.createElement('div');
    this._svArea.className = 'ls-picker-sv';
    const svWhite = document.createElement('div');
    svWhite.className = 'ls-picker-sv-white';
    const svBlack = document.createElement('div');
    svBlack.className = 'ls-picker-sv-black';
    this._svThumb = document.createElement('div');
    this._svThumb.className = 'ls-picker-sv-thumb';
    this._svArea.appendChild(svWhite);
    this._svArea.appendChild(svBlack);
    this._svArea.appendChild(this._svThumb);
    this._popover.appendChild(this._svArea);

    // Hue strip
    this._hueStrip = document.createElement('div');
    this._hueStrip.className = 'ls-picker-hue';
    this._hueThumb = document.createElement('div');
    this._hueThumb.className = 'ls-picker-hue-thumb';
    this._hueStrip.appendChild(this._hueThumb);
    this._popover.appendChild(this._hueStrip);

    // Inputs row
    const inputsRow = document.createElement('div');
    inputsRow.className = 'ls-picker-inputs';

    // Hex input group
    const hexGroup = document.createElement('div');
    hexGroup.className = 'ls-picker-hex-group';
    const hexPrefix = document.createElement('span');
    hexPrefix.className = 'ls-picker-hex-prefix';
    hexPrefix.textContent = '#';
    this._hexInput = document.createElement('input');
    this._hexInput.type = 'text';
    this._hexInput.className = 'ls-picker-hex';
    this._hexInput.maxLength = 6;
    this._hexInput.spellcheck = false;
    hexGroup.appendChild(hexPrefix);
    hexGroup.appendChild(this._hexInput);
    inputsRow.appendChild(hexGroup);

    // Separator
    const sep = document.createElement('div');
    sep.className = 'ls-picker-sep';
    inputsRow.appendChild(sep);

    // HSL fields
    const hslGroup = document.createElement('div');
    hslGroup.className = 'ls-picker-hsl-group';
    this._hInput = this._createHSLField(hslGroup, 'H');
    this._sInput = this._createHSLField(hslGroup, 'S');
    this._lInput = this._createHSLField(hslGroup, 'L');
    inputsRow.appendChild(hslGroup);

    this._popover.appendChild(inputsRow);
    document.body.appendChild(this._popover);

    // ── Initial render ──
    this._updateUI();

    // ── Event handlers ──
    this._swatch.addEventListener('click', (e: MouseEvent) => {
      e.stopPropagation();
      this._toggle();
    });

    // SV area pointer events
    this._svArea.addEventListener('pointerdown', (e: PointerEvent) => {
      e.preventDefault();
      this._isDraggingSV = true;
      this._svThumb.classList.add('ls-picker-dragging');
      this._svArea.setPointerCapture(e.pointerId);
      this._handleSVMove(e);
    });
    this._svArea.addEventListener('pointermove', (e: PointerEvent) => {
      if (this._isDraggingSV) {
        this._handleSVMove(e);
      }
    });
    this._svArea.addEventListener('pointerup', () => {
      this._isDraggingSV = false;
      this._svThumb.classList.remove('ls-picker-dragging');
    });

    // Hue strip pointer events
    this._hueStrip.addEventListener('pointerdown', (e: PointerEvent) => {
      e.preventDefault();
      this._isDraggingHue = true;
      this._hueStrip.setPointerCapture(e.pointerId);
      this._handleHueMove(e);
    });
    this._hueStrip.addEventListener('pointermove', (e: PointerEvent) => {
      if (this._isDraggingHue) {
        this._handleHueMove(e);
      }
    });
    this._hueStrip.addEventListener('pointerup', () => {
      this._isDraggingHue = false;
    });

    // Hex input
    this._hexInput.addEventListener('keydown', (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        this._commitHex();
      } else if (e.key === 'Escape') {
        this._hexInput.blur();
      }
    });
    this._hexInput.addEventListener('blur', () => {
      this._commitHex();
    });
    // Handle paste — accept with or without #
    this._hexInput.addEventListener('paste', (e: ClipboardEvent) => {
      e.preventDefault();
      const text = (e.clipboardData?.getData('text') || '').trim();
      const clean = text.startsWith('#') ? text.slice(1) : text;
      // Only take the first 6 hex chars
      const hex6 = clean.replace(/[^0-9a-fA-F]/g, '').slice(0, 6);
      this._hexInput.value = hex6;
      if (hex6.length === 6) {
        this._commitHex();
      }
    });

    // HSL inputs
    const commitHSL = (): void => this._commitHSL();
    for (const input of [this._hInput, this._sInput, this._lInput]) {
      input.addEventListener('keydown', (e: KeyboardEvent) => {
        if (e.key === 'Enter') {
          commitHSL();
        } else if (e.key === 'Escape') {
          input.blur();
        }
      });
      input.addEventListener('blur', commitHSL);
    }

    // Document-level handlers
    this._onDocClick = (e: MouseEvent) => {
      if (
        this._isOpen &&
        !this._popover.contains(e.target as Node) &&
        !this._swatch.contains(e.target as Node)
      ) {
        this._close();
      }
    };
    this._onDocKeydown = (e: KeyboardEvent) => {
      if (this._isOpen && e.key === 'Escape') {
        e.stopPropagation();
        this._close();
      }
    };
    document.addEventListener('mousedown', this._onDocClick, true);
    document.addEventListener('keydown', this._onDocKeydown, true);
  }

  // ── Public API ───────────────────────────────────────────────

  get value(): string {
    return hsvToHex(this._hsv.h, this._hsv.s, this._hsv.v);
  }

  set value(hex: string) {
    const hsv = hexToHsv(hex);
    if (hsv) {
      this._hsv = hsv;
      this._hasUserValue = true;
      this._updateUI();
    }
  }

  get defaultValue(): string {
    return this._defaultValue;
  }

  set defaultValue(hex: string) {
    this._defaultValue = hex;
    if (!this._hasUserValue) {
      const hsv = hexToHsv(hex);
      if (hsv) {
        this._hsv = hsv;
        this._updateUI();
      }
    }
  }

  /** Update displayed color without triggering onChange (e.g. external settings sync). */
  setDisplayValue(hex: string | null, defaultHex: string): void {
    this._defaultValue = defaultHex;
    if (hex) {
      this._hasUserValue = true;
      const hsv = hexToHsv(hex);
      if (hsv) {
        this._hsv = hsv;
      }
    } else {
      this._hasUserValue = false;
      const hsv = hexToHsv(defaultHex);
      if (hsv) {
        this._hsv = hsv;
      }
    }
    this._updateUI();
  }

  dispose(): void {
    if (this._disposed) {
      return;
    }
    this._disposed = true;
    document.removeEventListener('mousedown', this._onDocClick, true);
    document.removeEventListener('keydown', this._onDocKeydown, true);
    this._popover.remove();
    this.element.remove();
  }

  // ── Popover ──────────────────────────────────────────────────

  private _toggle(): void {
    if (this._isOpen) {
      this._close();
    } else {
      this._open();
    }
  }

  private _open(): void {
    if (this._isOpen) {
      return;
    }
    this._isOpen = true;

    // Position popover relative to swatch
    const rect = this._swatch.getBoundingClientRect();
    const popW = 232 + 24; // width + padding
    const popH = 260; // approx height

    let top = rect.bottom + 6;
    let left = rect.left;

    // Flip up if would overflow bottom
    if (top + popH > window.innerHeight - 8) {
      top = rect.top - popH - 6;
    }
    // Shift left if would overflow right
    if (left + popW > window.innerWidth - 8) {
      left = window.innerWidth - popW - 8;
    }
    // Don't go off left edge
    if (left < 8) {
      left = 8;
    }

    this._popover.style.top = `${top}px`;
    this._popover.style.left = `${left}px`;

    // Trigger animation
    requestAnimationFrame(() => {
      this._popover.classList.add('ls-picker-open');
    });
  }

  private _close(): void {
    if (!this._isOpen) {
      return;
    }
    this._isOpen = false;
    this._popover.classList.remove('ls-picker-open');
  }

  // ── Interaction Handlers ─────────────────────────────────────

  private _handleSVMove(e: PointerEvent): void {
    const rect = this._svArea.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const y = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));
    this._hsv.s = Math.round(x * 100);
    this._hsv.v = Math.round((1 - y) * 100);
    this._updateUI();
    this._emitChange();
  }

  private _handleHueMove(e: PointerEvent): void {
    const rect = this._hueStrip.getBoundingClientRect();
    const x = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    this._hsv.h = Math.round(x * 360);
    this._updateUI();
    this._emitChange();
  }

  private _commitHex(): void {
    const raw = this._hexInput.value.trim().replace(/^#/, '');
    if (/^[0-9a-f]{6}$/i.test(raw)) {
      const hsv = hexToHsv('#' + raw);
      if (hsv) {
        this._hsv = hsv;
        this._updateUI();
        this._emitChange();
      }
    } else if (raw === '') {
      // Empty = clear override
      this._hasUserValue = false;
      const hsv = hexToHsv(this._defaultValue);
      if (hsv) {
        this._hsv = hsv;
      }
      this._updateUI();
      this._onClear();
      return;
    } else {
      // Revert to current value
      this._updateHexInput();
    }
  }

  private _commitHSL(): void {
    const h = parseInt(this._hInput.value, 10);
    const s = parseInt(this._sInput.value, 10);
    const l = parseInt(this._lInput.value, 10);
    if (
      !isNaN(h) &&
      !isNaN(s) &&
      !isNaN(l) &&
      h >= 0 &&
      h <= 360 &&
      s >= 0 &&
      s <= 100 &&
      l >= 0 &&
      l <= 100
    ) {
      this._hsv = hslToHsv(h, s, l);
      this._updateUI();
      this._emitChange();
    } else {
      // Revert to current values
      this._updateHSLInputs();
    }
  }

  private _emitChange(): void {
    this._hasUserValue = true;
    const hex = hsvToHex(this._hsv.h, this._hsv.s, this._hsv.v);
    this._onChange(hex);
  }

  // ── UI Updates ───────────────────────────────────────────────

  private _updateUI(): void {
    const { h, s, v } = this._hsv;
    const hex = hsvToHex(h, s, v);

    // Swatch
    this._swatchInner.style.backgroundColor = hex;

    // SV area background hue
    this._svArea.style.backgroundColor = `hsl(${h}, 100%, 50%)`;

    // SV thumb position
    this._svThumb.style.left = `${s}%`;
    this._svThumb.style.top = `${100 - v}%`;

    // Hue thumb
    this._hueThumb.style.left = `${(h / 360) * 100}%`;

    // Inputs (only update if not focused, to avoid fighting the user)
    if (document.activeElement !== this._hexInput) {
      this._updateHexInput();
    }
    if (
      document.activeElement !== this._hInput &&
      document.activeElement !== this._sInput &&
      document.activeElement !== this._lInput
    ) {
      this._updateHSLInputs();
    }
  }

  private _updateHexInput(): void {
    const hex = hsvToHex(this._hsv.h, this._hsv.s, this._hsv.v);
    this._hexInput.value = hex.slice(1); // without #
  }

  private _updateHSLInputs(): void {
    const hsl = hsvToHsl(this._hsv.h, this._hsv.s, this._hsv.v);
    this._hInput.value = String(hsl.h);
    this._sInput.value = String(hsl.s);
    this._lInput.value = String(hsl.l);
  }

  // ── Helpers ──────────────────────────────────────────────────

  private _createHSLField(parent: HTMLDivElement, label: string): HTMLInputElement {
    const field = document.createElement('div');
    field.className = 'ls-picker-hsl-field';
    const input = document.createElement('input');
    input.type = 'text';
    input.className = 'ls-picker-hsl-input';
    input.spellcheck = false;
    input.inputMode = 'numeric';
    const lbl = document.createElement('span');
    lbl.className = 'ls-picker-hsl-label';
    lbl.textContent = label;
    field.appendChild(input);
    field.appendChild(lbl);
    parent.appendChild(field);
    return input;
  }
}
