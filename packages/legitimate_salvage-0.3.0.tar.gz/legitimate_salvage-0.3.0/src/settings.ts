import { ISettingRegistry } from '@jupyterlab/settingregistry';
import { IThemePalette, ISyntaxColors } from './palettes';

/**
 * Per-theme customization settings (mirrors schema/plugin.json themeCustomization).
 */
export interface IThemeCustomization {
  typography?: {
    codeFontFamily?: string;
    contentFontFamily?: string;
    uiFontFamily?: string;
  };
  colors?: Partial<
    Record<
      | 'bg'
      | 'bgAlt'
      | 'bgHl'
      | 'bgRegion'
      | 'fg'
      | 'fgDim'
      | 'fgBright'
      | 'accent'
      | 'accentBright'
      | 'accentDark'
      | 'green'
      | 'red'
      | 'blue'
      | 'orange'
      | 'yellow'
      | 'cyan'
      | 'magenta'
      | 'border',
      string
    >
  >;
  syntax?: Partial<Record<keyof ISyntaxColors, string>>;
  markdown?: {
    headingColor?: string;
    headingFontWeight?: string | number;
    headingBorderBottom?: boolean;
    headingAlign?: string;
    h1Size?: string;
    h2Size?: string;
    h3Size?: string;
    h4Size?: string;
    h5Size?: string;
    h6Size?: string;
    h1Align?: string;
    h2Align?: string;
    h3Align?: string;
    h4Align?: string;
    h5Align?: string;
    h6Align?: string;
    blockquoteBorderColor?: string;
    blockquoteBorderWidth?: string;
    blockquoteTextColor?: string;
    inlineCodeBackground?: string;
    inlineCodeColor?: string;
    codeBlockBackground?: string;
    linkColor?: string;
  };
  dataframes?: {
    headerBackground?: string;
    headerColor?: string;
    headerFontWeight?: string | number;
    rowAltBackground?: string;
    rowHoverBackground?: string;
    borderColor?: string;
    fontFamily?: string;
  };
  toc?: {
    fontSize?: string;
    activeColor?: string;
    indentSize?: string;
  };
}

/**
 * Global settings (mirrors schema/plugin.json top-level).
 */
export interface IGlobalSettings {
  typography?: {
    codeFontFamily?: string;
    contentFontFamily?: string;
    uiFontFamily?: string;
    codeFontSize?: string;
    contentFontSize?: string;
    uiFontSize?: string;
    codeLineHeight?: string | number;
    contentLineHeight?: string | number;
  };
  scrollbar?: {
    autoHide?: boolean;
    width?: string;
    thumbColor?: string;
    trackColor?: string;
  };
  layout?: {
    borderRadius?: string;
    cellPadding?: string;
    notebookPadding?: string;
    promptWidth?: string;
    cursorWidth?: string;
  };
  terminal?: {
    useThemeColors?: boolean;
  };
  themeCustomization?: Record<string, IThemeCustomization>;
}

/**
 * Helper: return the value if it's a non-empty string, otherwise undefined.
 */
function nonEmpty(val: unknown): string | undefined {
  if (typeof val === 'string' && val.trim() !== '') {
    return val.trim();
  }
  return undefined;
}

/**
 * Read the full settings object from ISettingRegistry settings.
 */
export function readSettings(
  settings: ISettingRegistry.ISettings
): IGlobalSettings {
  return settings.composite as unknown as IGlobalSettings;
}

/**
 * Get the per-theme customization for a given theme name.
 */
export function getThemeCustomization(
  global: IGlobalSettings,
  themeName: string
): IThemeCustomization {
  return global.themeCustomization?.[themeName] ?? {};
}

/**
 * Merge a base palette with global settings and per-theme overrides.
 *
 * Priority: per-theme user override > global user override > theme built-in default
 */
export function mergeThemePalette(
  basePalette: IThemePalette,
  global: IGlobalSettings,
  themeOverrides: IThemeCustomization
): IThemePalette {
  const colors = themeOverrides.colors ?? {};

  // Merge palette colors: user override > base palette
  const merged: IThemePalette = {
    bg: nonEmpty(colors.bg) ?? basePalette.bg,
    bgAlt: nonEmpty(colors.bgAlt) ?? basePalette.bgAlt,
    bgHl: nonEmpty(colors.bgHl) ?? basePalette.bgHl,
    bgRegion: nonEmpty(colors.bgRegion) ?? basePalette.bgRegion,
    fg: nonEmpty(colors.fg) ?? basePalette.fg,
    fgDim: nonEmpty(colors.fgDim) ?? basePalette.fgDim,
    fgBright: nonEmpty(colors.fgBright) ?? basePalette.fgBright,
    accent: nonEmpty(colors.accent) ?? basePalette.accent,
    accentBright: nonEmpty(colors.accentBright) ?? basePalette.accentBright,
    accentDark: nonEmpty(colors.accentDark) ?? basePalette.accentDark,
    green: nonEmpty(colors.green) ?? basePalette.green,
    red: nonEmpty(colors.red) ?? basePalette.red,
    blue: nonEmpty(colors.blue) ?? basePalette.blue,
    magenta: nonEmpty(colors.magenta) ?? basePalette.magenta,
    orange: nonEmpty(colors.orange) ?? basePalette.orange,
    yellow: nonEmpty(colors.yellow) ?? basePalette.yellow,
    cyan: nonEmpty(colors.cyan) ?? basePalette.cyan,
    border: nonEmpty(colors.border) ?? basePalette.border
  };

  // Merge syntax colors
  const syntaxOverrides = themeOverrides.syntax ?? {};
  const baseSyntax = basePalette.syntax ?? {};
  const hasSyntaxOverrides = Object.values(syntaxOverrides).some(
    v => nonEmpty(v) !== undefined
  );
  if (hasSyntaxOverrides || basePalette.syntax) {
    const mergedSyntax: Partial<ISyntaxColors> = {};
    const syntaxKeys: (keyof ISyntaxColors)[] = [
      'keyword',
      'atom',
      'number',
      'def',
      'variable',
      'variable2',
      'variable3',
      'punctuation',
      'property',
      'operator',
      'comment',
      'string',
      'string2',
      'meta',
      'qualifier',
      'builtin',
      'bracket',
      'tag',
      'attribute',
      'header',
      'quote',
      'link',
      'error',
      'hr'
    ];
    for (const key of syntaxKeys) {
      const val =
        nonEmpty(syntaxOverrides[key]) ?? baseSyntax[key] ?? undefined;
      if (val !== undefined) {
        mergedSyntax[key] = val;
      }
    }
    if (Object.keys(mergedSyntax).length > 0) {
      merged.syntax = mergedSyntax;
    }
  }

  // Merge fonts: per-theme > global > theme built-in > extension default
  const globalTypo = global.typography ?? {};
  const themeTypo = themeOverrides.typography ?? {};

  merged.codeFontFamily =
    nonEmpty(themeTypo.codeFontFamily) ??
    nonEmpty(globalTypo.codeFontFamily) ??
    basePalette.codeFontFamily;
  merged.contentFontFamily =
    nonEmpty(themeTypo.contentFontFamily) ??
    nonEmpty(globalTypo.contentFontFamily) ??
    basePalette.contentFontFamily;
  merged.uiFontFamily =
    nonEmpty(themeTypo.uiFontFamily) ??
    nonEmpty(globalTypo.uiFontFamily) ??
    basePalette.uiFontFamily;

  return merged;
}

/**
 * Generate additional CSS for granular settings that go beyond the palette
 * (heading sizes, DataFrame theming, TOC, scrollbar, layout overrides).
 *
 * Returns a CSS string to be injected alongside the palette variables.
 */
export function generateOverrideCSS(
  global: IGlobalSettings,
  themeOverrides: IThemeCustomization,
  _themeName: string
): string {
  const lines: string[] = [];
  const globalTypo = global.typography ?? {};
  const layout = global.layout ?? {};
  const md = themeOverrides.markdown ?? {};
  const df = themeOverrides.dataframes ?? {};
  const toc = themeOverrides.toc ?? {};

  // Global typography overrides
  if (nonEmpty(globalTypo.codeFontSize)) {
    lines.push(`  --jp-code-font-size: ${globalTypo.codeFontSize};`);
  }
  if (nonEmpty(globalTypo.contentFontSize)) {
    lines.push(`  --jp-content-font-size1: ${globalTypo.contentFontSize};`);
  }
  if (nonEmpty(globalTypo.uiFontSize)) {
    lines.push(`  --jp-ui-font-size1: ${globalTypo.uiFontSize};`);
  }
  if (nonEmpty(String(globalTypo.codeLineHeight ?? ''))) {
    lines.push(`  --jp-code-line-height: ${globalTypo.codeLineHeight};`);
  }
  if (nonEmpty(String(globalTypo.contentLineHeight ?? ''))) {
    lines.push(`  --jp-content-line-height: ${globalTypo.contentLineHeight};`);
  }

  // Layout overrides
  if (nonEmpty(layout.borderRadius)) {
    lines.push(`  --jp-border-radius: ${layout.borderRadius};`);
  }
  if (nonEmpty(layout.cellPadding)) {
    lines.push(`  --jp-cell-padding: ${layout.cellPadding};`);
  }
  if (nonEmpty(layout.notebookPadding)) {
    lines.push(`  --jp-notebook-padding: ${layout.notebookPadding};`);
  }
  if (nonEmpty(layout.promptWidth)) {
    lines.push(`  --jp-cell-prompt-width: ${layout.promptWidth};`);
  }
  if (nonEmpty(layout.cursorWidth)) {
    lines.push(`  --jp-code-cursor-width0: ${layout.cursorWidth};`);
  }

  // Markdown heading overrides
  if (nonEmpty(md.headingColor)) {
    lines.push(`  --theme-heading-color: ${md.headingColor};`);
  }
  if (nonEmpty(String(md.headingFontWeight ?? ''))) {
    lines.push(`  --theme-heading-font-weight: ${md.headingFontWeight};`);
  }
  if (md.headingBorderBottom === false) {
    lines.push(`  --theme-heading-border-bottom: none;`);
  }
  if (nonEmpty(md.headingAlign)) {
    lines.push(`  --theme-heading-align: ${md.headingAlign};`);
  }

  // Per-level heading sizes and alignment
  const levels = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'] as const;
  for (const level of levels) {
    const sizeKey = `${level}Size` as keyof typeof md;
    const alignKey = `${level}Align` as keyof typeof md;
    const sizeVal = nonEmpty(md[sizeKey] as string);
    const alignVal = nonEmpty(md[alignKey] as string);
    if (sizeVal) {
      lines.push(`  --theme-${level}-size: ${sizeVal};`);
    }
    if (alignVal) {
      lines.push(`  --theme-${level}-align: ${alignVal};`);
    }
  }

  // Markdown blockquote
  if (nonEmpty(md.blockquoteBorderColor)) {
    lines.push(
      `  --theme-blockquote-border-color: ${md.blockquoteBorderColor};`
    );
  }
  if (nonEmpty(md.blockquoteBorderWidth)) {
    lines.push(
      `  --theme-blockquote-border-width: ${md.blockquoteBorderWidth};`
    );
  }
  if (nonEmpty(md.blockquoteTextColor)) {
    lines.push(`  --theme-blockquote-text-color: ${md.blockquoteTextColor};`);
  }

  // Markdown inline code
  if (nonEmpty(md.inlineCodeBackground)) {
    lines.push(
      `  --theme-inline-code-background: ${md.inlineCodeBackground};`
    );
  }
  if (nonEmpty(md.inlineCodeColor)) {
    lines.push(`  --theme-inline-code-color: ${md.inlineCodeColor};`);
  }

  // Markdown code blocks
  if (nonEmpty(md.codeBlockBackground)) {
    lines.push(
      `  --theme-code-block-background: ${md.codeBlockBackground};`
    );
  }

  // Markdown link color
  if (nonEmpty(md.linkColor)) {
    lines.push(`  --jp-content-link-color: ${md.linkColor};`);
  }

  // DataFrame overrides
  if (nonEmpty(df.headerBackground)) {
    lines.push(`  --theme-df-header-bg: ${df.headerBackground};`);
  }
  if (nonEmpty(df.headerColor)) {
    lines.push(`  --theme-df-header-color: ${df.headerColor};`);
  }
  if (nonEmpty(String(df.headerFontWeight ?? ''))) {
    lines.push(`  --theme-df-header-weight: ${df.headerFontWeight};`);
  }
  if (nonEmpty(df.rowAltBackground)) {
    lines.push(`  --theme-df-row-alt-bg: ${df.rowAltBackground};`);
  }
  if (nonEmpty(df.rowHoverBackground)) {
    lines.push(`  --theme-df-row-hover-bg: ${df.rowHoverBackground};`);
  }
  if (nonEmpty(df.borderColor)) {
    lines.push(`  --theme-df-border-color: ${df.borderColor};`);
  }
  if (nonEmpty(df.fontFamily)) {
    const fontVal = df.fontFamily!;
    let resolved: string;
    if (fontVal === 'code') {
      resolved = 'var(--jp-code-font-family)';
    } else if (fontVal === 'content') {
      resolved = 'var(--jp-content-font-family)';
    } else {
      resolved = `${fontVal}, var(--jp-content-font-family)`;
    }
    lines.push(`  --theme-df-font-family: ${resolved};`);
  }

  // TOC overrides
  if (nonEmpty(toc.fontSize)) {
    lines.push(`  --theme-toc-font-size: ${toc.fontSize};`);
  }
  if (nonEmpty(toc.activeColor)) {
    lines.push(`  --theme-toc-active-color: ${toc.activeColor};`);
  }
  if (nonEmpty(toc.indentSize)) {
    lines.push(`  --theme-toc-indent: ${toc.indentSize};`);
  }

  if (lines.length === 0) {
    return '';
  }

  return `:root {\n${lines.join('\n')}\n}`;
}
