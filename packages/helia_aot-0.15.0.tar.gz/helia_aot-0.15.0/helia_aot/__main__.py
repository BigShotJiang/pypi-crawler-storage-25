from helia_aot import cli

cli.run()
