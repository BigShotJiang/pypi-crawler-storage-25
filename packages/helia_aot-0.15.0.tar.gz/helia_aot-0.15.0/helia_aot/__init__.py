"""
# :material-api: heliaAOT API Documentation

## Available APIs

* **[AIR API](air/)**: Back-end Ambiq Intermediate Representation (AIR) API.
* **[AOT API](aot/)**: Ahead-Of-Time (AOT) code generation API.
* **[Attributes API](attributes/)**: Entity attributes management API.
* **[CLI API](cli.md)**: Command line interface (CLI) for heliaAOT.
* **[Converters API](converters/)**: Front-end model conversion to AIR API.
* **[Interpreters API](interpreters/)**: Front-end interpreter API.
* **[Memory API](memory/)**: Memory management and planning API.
* **[Platforms API](platforms/)**: Target platform/SoC API.
* **[Transforms API](transforms/)**: AIR model transform/fusion API.
* **[Utils API](utils.py)**: Utility API.
* **[Converter API](converter.py)**: Main AOT converter class.
* **[Defines API](defines.py)**: Constants and common definitions.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from . import air
from . import aot
from . import attributes
from . import cli
from . import converters
from . import interpreters
from . import memory
from . import platforms
from . import transforms
from . import utils
from .converter import AotConverter
from . import defines
