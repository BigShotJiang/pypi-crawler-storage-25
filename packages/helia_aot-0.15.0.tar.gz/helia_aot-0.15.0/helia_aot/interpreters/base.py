import abc
from pathlib import Path
import numpy as np
from helia_aot.air.tensor import AirTensor


class AirInterpreter(abc.ABC):
    """Unified API for TinyML interpreters."""

    def __init__(self, model_path: Path):
        """Load the model and prepare for allocation."""
        pass

    @abc.abstractmethod
    def set_input(self, tensor: AirTensor | np.ndarray, key: str | int = None) -> None:
        """Feed one input tensor by name/ID or index."""
        pass

    @abc.abstractmethod
    def invoke(self) -> None:
        """Run inference."""
        pass

    @abc.abstractmethod
    def get_output(self, key: str | int = None, wrap: bool = False) -> np.ndarray | AirTensor:
        """Fetch one output by name/ID or index."""
        pass
