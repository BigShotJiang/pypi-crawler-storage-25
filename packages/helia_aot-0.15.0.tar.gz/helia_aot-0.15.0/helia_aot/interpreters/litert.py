from pathlib import Path
import numpy as np
import numpy.typing as npt
from helia_aot.litert.interpreter import Interpreter
from helia_aot.air.tensor import AirTensor
from .base import AirInterpreter
from ..utils import suppress_os_stdio


class LitertInterpreter(AirInterpreter):
    """LiteRT based interpreter."""

    def __init__(self, model_path: Path):
        # 1) Load the flatbuffer and create the Interpreter
        with suppress_os_stdio():
            self.interp = Interpreter(str(model_path), experimental_preserve_all_tensors=False)
            self.interp.allocate_tensors()

        # 2) Build mappings: name → index, string(ID) → index
        self._index_by_name: dict[str, int] = {}
        self._index_by_strid: dict[str, int] = {}
        details = self.interp.get_tensor_details()  # list of dicts
        for d in details:
            idx = d["index"]
            name = d["name"]  # e.g. "input:0" or "conv1/weights"
            self._index_by_name[name] = idx
            self._index_by_strid[str(idx)] = idx

        # 3) remember which indices are inputs/outputs
        self.input_indices = self.interp.get_input_details()  # list of dicts
        self.output_indices = self.interp.get_output_details()  # list of dicts

    def _resolve_index(self, key: str | int) -> int:
        """Turn a name or string-ID or int into the actual tensor index."""
        if isinstance(key, int):
            return key
        # try as string ID
        if key in self._index_by_strid:
            return self._index_by_strid[key]
        # try as tensor name
        if key in self._index_by_name:
            return self._index_by_name[key]
        raise KeyError(f"Unknown tensor key {key!r}")

    def set_input(self, tensor: AirTensor | np.ndarray, *, key: str | int | None = None) -> None:
        """Assign data to one of the interpreter's inputs.

        Note:
            If an `AirTensor` is passed, its `.data` will be used.

        Args:
            tensor (AirTensor | np.ndarray): The input tensor to set.
            key (str | int | None): The key to identify the input tensor.

        """
        data = tensor.data.copy() if isinstance(tensor, AirTensor) else tensor.copy()
        if key is None:
            # for AirTensor case, use its id
            if not isinstance(tensor, AirTensor):
                raise ValueError("When passing raw array, you must specify `key=`")
            key = tensor.id
        idx = self._resolve_index(key)
        exp_data: npt.NDArray = self.interp.get_tensor(idx)
        # Reshape input if necessary
        if exp_data.shape != data.shape:
            data = data.reshape(exp_data.shape)
        self.interp.set_tensor(idx, data)

    def invoke(self) -> None:
        """Run inference."""
        self.interp.invoke()

    def get_output(self, *, key: str | int | None = None, wrap: bool = False) -> np.ndarray | AirTensor:
        """Retrieve an output tensor.
        If wrap=True, returns an AirTensor with `.data` populated.

        Args:
            key (str | int | None): The name or ID of the output tensor. If None, will use the first output.
            wrap (bool): If True, returns an AirTensor

        Returns:
            np.ndarray | AirTensor: The output tensor.
        """
        if key is None:
            # if only one output, pick it
            outputs = self.interp.get_output_details()
            if len(outputs) != 1:
                raise ValueError("Must specify `key=` when multiple outputs exist")
            idx = outputs[0]["index"]
        else:
            idx = self._resolve_index(key)

        arr = self.interp.get_tensor(idx)
        if wrap:
            at = AirTensor(id=str(idx), data=arr.copy())
            return at
        return arr
