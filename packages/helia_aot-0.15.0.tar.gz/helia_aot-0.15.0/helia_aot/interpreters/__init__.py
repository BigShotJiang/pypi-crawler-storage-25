"""

# :material-engine-outline: heliaAOT Interpreters API

This module is responsible for creating a unified interpreter for the given front-end model.

## Available Converters

- **[LiteRT](./litert)**: LiteRT (TFLite) interpreter

Copyright 2025 Ambiq. All Rights Reserved.

"""

from pathlib import Path
from .base import AirInterpreter

__all__ = ["AirInterpreter", "create_interpreter"]


def create_interpreter(model_path: Path) -> AirInterpreter:
    """Factory: Instantiate the appropriate interpreter class based on the model file type.

    Note:
        This function lazy-loads the interpreter class based on the file extension.
    """
    # You could also inspect the flatbuffer magic bytes to decide more robustly.
    suffix = model_path.suffix.lower()
    if suffix in {".litert", ".tflite"}:
        from .litert import LitertInterpreter

        return LitertInterpreter(model_path)

    raise RuntimeError("No suitable interpreter backend available. Install ai_edge_litert or tflite-runtime.")
