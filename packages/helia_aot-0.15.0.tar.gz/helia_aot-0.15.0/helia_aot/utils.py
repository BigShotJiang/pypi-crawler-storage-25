"""
# :material-tools: heliaAOT Utility API

This module provides utility functions for various tasks.

Classes:
    MarkdownRichHandler: Custom logging handler for Rich library with Markdown support.
    StepContext: Context manager for logging steps in a process.

Functions:
    get_version: Get the version of the package
    setup_logger: Set up a logger with optional file output
    suppress_os_stdio: Context manager to suppress OS stdout and stderr

Copyright 2025 Ambiq. All Rights Reserved.

"""

import os
import sys
import time
import logging
from pathlib import Path
from contextlib import contextmanager, ContextDecorator
from importlib.metadata import version, PackageNotFoundError
from rich.logging import RichHandler
from rich.markdown import Markdown


try:
    __version__ = version("helia_aot")
except PackageNotFoundError:
    __version__ = "0.0.0"


def get_version() -> str:
    """Get the version of the package.

    Returns:
        str: Version string.
    """
    return __version__


class MarkdownRichHandler(RichHandler):
    """Custom logging handler for Rich library with Markdown support."""

    def emit(self, record):
        msg = record.msg
        if isinstance(msg, Markdown):
            self.console.print(msg)
        else:
            super().emit(record)


_LOGGERS_INITIALIZED: set[str] = set()


def setup_logger(
    log_name: str,
    level: int | None = None,
    recursive: bool = True,
    file_path: str | Path | None = None,
) -> logging.Logger:
    """Configure a logger with optional file output.

    This function ensures that the logger is only initialized once per name.
    The logger can be configured to propagate messages to the root logger.

    Included handlers are:
        - RichHandler: For console output with rich formatting.
        - FileHandler: For file output (optional).

    Args:
        log_name (str): Name of the logger.
        level (int, optional): Logging level (0: ERROR, 1: INFO, 2: DEBUG). Defaults to None.
        recursive (bool, optional): If True, use the root logger name. Defaults to True.
        file_path (str|Path, optional): Path to the log file. Defaults to None.

    Returns:
        logging.Logger: Configured logger instance.
    """
    # map verbosity 0/1/2→ERROR/INFO/DEBUG
    level = max(0, min(2, level)) if level is not None else None
    lvl_map = {0: logging.ERROR, 1: logging.INFO, 2: logging.DEBUG}
    log_level = lvl_map.get(level, None)

    root_name = log_name.split(".", 1)[0] if recursive else log_name
    logger = logging.getLogger(root_name)

    if root_name not in _LOGGERS_INITIALIZED:
        _LOGGERS_INITIALIZED.add(root_name)
        logger.handlers.clear()
        logger.propagate = False

        rich_h = MarkdownRichHandler(markup=True, show_time=False, show_path=False, rich_tracebacks=True)
        if log_level is not None:
            rich_h.setLevel(log_level)
        logger.addHandler(rich_h)

    if file_path and not any(isinstance(handler, logging.FileHandler) for handler in logger.handlers):
        file_handler = logging.FileHandler(file_path, mode="w")
        file_handler.setLevel(log_level)
        logger.addHandler(file_handler)

    if log_level is not None:
        logger.setLevel(log_level)

    return logger


@contextmanager
def suppress_os_stdio():
    """
    Redirects the OS stdout (fd=1) and stderr (fd=2) to /dev/null, then restores them on exit.
    Suppresses all output **unless** an exception is raised, in which case it will be logged.

    Example:
        with suppress_os_stdio():
            noisy_function()
    """
    # 1) Flush Python buffers
    sys.stdout.flush()
    sys.stderr.flush()

    # 2) Duplicate original FDs so we can restore them later
    orig_stdout_fd = os.dup(sys.stdout.fileno())
    orig_stderr_fd = os.dup(sys.stderr.fileno())

    try:
        # 3) Open /dev/null and redirect
        devnull_fd = os.open(os.devnull, os.O_RDWR)
        os.dup2(devnull_fd, sys.stdout.fileno())
        os.dup2(devnull_fd, sys.stderr.fileno())
        os.close(devnull_fd)

        # 4) Enter user’s block
        yield

    except Exception:
        # 5) An error occurred! Log it (the FDs are still /dev/null at this moment).
        logging.exception("Error inside suppressed stdout/stderr block")
        raise

    finally:
        # 6) Restore original FDs no matter what
        os.dup2(orig_stdout_fd, sys.stdout.fileno())
        os.dup2(orig_stderr_fd, sys.stderr.fileno())
        os.close(orig_stdout_fd)
        os.close(orig_stderr_fd)


class StepContext(ContextDecorator):
    def __init__(self, name: str, ellipses: bool = True):
        """Context manager for logging the duration of a code execution step.

        Args:
            name (str): Name of the step.
            ellipses (bool): Whether to show ellipses in the log message.
        """
        self.logger = setup_logger(__name__)
        self.name = name
        self.ellipses = ellipses
        self.tic = time.perf_counter()

    def __enter__(self):
        self.logger.info(f"[bold]Step: {self.name}{'…' if self.ellipses else ''}[/]")
        self.tic = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc:
            self.logger.exception("[red]Step failed ✖:[/]")
            return False  # let the exception propagate

        toc = time.perf_counter()
        elapsed = toc - self.tic
        self.logger.info(f"[green]Step completed in {elapsed:.2f}s ✔[/]")
        return True
