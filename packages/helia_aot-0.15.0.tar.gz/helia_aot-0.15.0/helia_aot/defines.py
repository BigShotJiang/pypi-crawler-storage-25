"""

# :material-library: Defines API

Classes:
    ModuleType: Enum representing the type of exported module.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from enum import StrEnum, auto


class AnyCaseStrEnum(StrEnum):
    """Case-insensitive string enumeration.

    This is useful for parsing user input in a flexible manner.
    """

    @classmethod
    def _missing_(cls, value):
        # 1) Idempotent: already a member
        if isinstance(value, cls):
            return value

        # 2) Require strings for conversion
        if not isinstance(value, str):
            return None

        # 3) Case-insensitive match on name OR value
        needle = value.casefold()
        for member in cls:
            if member.name.casefold() == needle or member.value.casefold() == needle:
                return member

        # 4) No match ->  error
        return None


class LowerCaseStrEnum(AnyCaseStrEnum):
    """Lowercase string enumeration."""

    def _generate_next_value_(name, start, count, last_values):
        # Ensure canonical lowercase values
        return name.lower()


class UpperCaseStrEnum(AnyCaseStrEnum):
    """Uppercase string enumeration."""

    def _generate_next_value_(name, start, count, last_values):
        # Ensure canonical uppercase values
        return name.upper()


class ModuleType(AnyCaseStrEnum):
    """Exported module type

    Attributes:
        neuralspot (str): NeuralSpot module
        zephyr (str): Zephyr RTOS module
        cmake (str): CMake module
        nsx (str): NSX module (neuralspotx build system)
    """

    neuralspot = auto()
    zephyr = auto()
    cmake = auto()
    nsx = auto()
