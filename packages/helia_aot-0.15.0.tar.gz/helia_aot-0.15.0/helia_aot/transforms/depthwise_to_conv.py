from typing import Any
from dataclasses import asdict, fields
from pydantic.dataclasses import dataclass
from pydantic import Field
from .transform import AirTransform
from ..utils import setup_logger
from helia_aot.air import AirModel, AirOperator, AirOpType, AirConv2DOptions

logger = setup_logger(log_name=__name__)


@dataclass
class DepthwiseToConvOptions:
    """Options for the DepthwiseToConv transform."""

    output_channel_threshold: int = Field(default=1, description="Minimum output channels to consider conversion.")


class DepthwiseToConv(AirTransform):
    """The purpose of this transform is to convert DEPTHWISE_CONV_2D to CONV_2D operators
    when more efficient.

    1. Find any DEPTHWISE_CONV_2D operator that is convertible
    2. Transform to CONV_2D operator if threshold is met.

    """

    NAME = "DEPTHWISE_TO_CONV"

    def __init__(self, enabled: bool = True, options: dict[str, Any] = None):
        super().__init__(enabled, options)
        self.options = DepthwiseToConvOptions(**(options or {}))

    def convert_operator(self, op: AirOperator, model: AirModel):
        """Convert the DEPTHWISE_CONV_2D operator to CONV_2D operator.

        Args:
            op (AirOperator): The DEPTHWISE_CONV_2D operator to convert.
            model (AirModel): The AIR model

        """
        # 1. Update the operator type
        op.op_type = AirOpType.CONV_2D

        # 2. Convert the options
        options_dict = asdict(op.options)
        dst_fields = {f.name for f in fields(AirConv2DOptions)}
        filtered = {k: v for k, v in options_dict.items() if k in dst_fields}
        op.options = AirConv2DOptions(**filtered)

        # 3. Fix the weights tensor
        weights_tensor = model.get_tensor(op.named_tensors["weights"])
        weights_tensor.data = weights_tensor.data.transpose(3, 1, 2, 0).copy()

    def is_convertible(self, op: AirOperator, model: AirModel) -> bool:
        """Check if the DEPTHWISE_CONV_2D operator is convertible.

        Args:
            op (AirOperator): The DEPTHWISE_CONV_2D operator to check.
            model (AirModel): The AIR model

        Returns:
            bool: True if the operator is convertible, False otherwise.
        """
        # Check if has single input channel
        input_tensor = model.get_tensor(op.input_ids[0])
        return input_tensor.shape[-1] == 1

    def is_efficient(self, op: AirOperator, model: AirModel) -> bool:
        """Check if converting DEPTHWISE_CONV_2D operator is efficient.

        Args:
            op (AirOperator): The DEPTHWISE_CONV_2D operator to check.
            model (AirModel): The AIR model

        Returns:
            bool: True if the operator is efficient to convert, False otherwise.
        """
        output_tensor = model.get_tensor(op.output_ids[0])
        output_channels = output_tensor.shape[-1]
        if output_channels > self.options.output_channel_threshold:
            return True
        return False

    def apply(self, model: AirModel) -> AirModel:
        """Apply the transform.

        Args:
            model (AirModel): The model to transform.

        Returns:
            AirModel: The transformed model.
        """

        for op in model.operators:
            if (
                op.op_type == AirOpType.DEPTHWISE_CONV_2D
                and self.is_convertible(op, model)
                and self.is_efficient(op, model)
            ):
                logger.debug(f"[magenta]  • Converting operator {op.id} from {op.op_type} to {AirOpType.CONV_2D} [/]")
                self.convert_operator(op, model)
            # END IF
        # END FOR

        return model
