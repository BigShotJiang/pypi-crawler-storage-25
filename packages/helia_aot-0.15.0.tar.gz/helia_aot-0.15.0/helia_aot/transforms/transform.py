import abc
from typing import Any
from helia_aot.air import AirModel


class AirTransform(abc.ABC):
    """Base class for all AIR model fusion/transformations."""

    NAME: str

    def __init__(self, enabled: bool = True, options: dict[str, Any] = None):
        self.enabled = enabled
        self.options = options or {}

    @property
    def name(self) -> str:
        """Unique name of the transform."""
        return self.NAME

    @abc.abstractmethod
    def apply(self, model: AirModel) -> AirModel:
        """Perform the transform on the given model."""
        raise NotImplementedError("Transform must implement the apply method.")
