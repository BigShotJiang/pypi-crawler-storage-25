"""
:material-merge: Transforms API

The `transforms` module provides a set of classes to perform operator transforms and fusion.

## Available Transforms

* **[DepthwiseToConv](./depthwise_to_conv)**: Transform depthwise convolutions to standard convolutions
* **[PruneIdentityOps](./prune_identity_ops)**: Prune identity operations
* **[TransposeReverseConv](./tranpose_reverse_conv)**: Transform reversible transpose convolutions to standard convolutions

Copyright 2025 Ambiq. All Rights Reserved.

"""

from helia_aot.registry import Registry

from .defines import TransformSpec
from .transform import AirTransform
from .transform_pipeline import TransformPipeline
from .depthwise_to_conv import DepthwiseToConv
from .prune_identity_ops import PruneIdentityOps
from .transpose_reverse_conv import TransposeReverseConv


def register_default_transforms(registry: Registry[str, type[AirTransform]]) -> None:
    """Register all built-in transforms into the provided registry."""
    for cls in (DepthwiseToConv, PruneIdentityOps, TransposeReverseConv):
        registry.register(cls.NAME, cls, overwrite=True)
