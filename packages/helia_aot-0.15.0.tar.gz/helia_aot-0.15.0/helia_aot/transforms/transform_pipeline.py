from helia_aot.registry import Registry
from .transform import AirTransform
from .defines import TransformSpec
from helia_aot.air import AirModel
from ..utils import setup_logger

logger = setup_logger(log_name=__name__)


def apply_wildcard_and_validate(
    specs: list[TransformSpec],
    transform_registry: Registry[str, type[AirTransform]],
) -> list[TransformSpec]:
    """Apply wildcard and validate the transforms configuration."""

    specs = list(specs)
    wildcard_index = next((i for i, s in enumerate(specs) if s.name == "*"), None)
    if wildcard_index is not None:
        default_spec = specs.pop(wildcard_index)
    else:
        default_spec = TransformSpec(name="*", enabled=True, options={})

    full_specs = [TransformSpec(name=name, enabled=default_spec.enabled) for name in transform_registry.list()]

    for spec in specs:
        index = next((i for i, s in enumerate(full_specs) if s.name == spec.name), None)
        if index is None:
            raise ValueError(f"Transform {spec.name!r} not found in the registry.")
        full_specs[index] = spec

    return full_specs


class TransformPipeline:
    def __init__(self, transforms: list[AirTransform]):
        self.transforms = transforms

    def apply(self, model: AirModel) -> AirModel:
        for t in self.transforms:
            if t.enabled:
                logger.debug(f"  • Applying transform {t.name}")
                model = t.apply(model)
        return model

    @classmethod
    def from_config(
        cls,
        specs: list[TransformSpec],
        transform_registry: Registry[str, type[AirTransform]],
    ) -> "TransformPipeline":
        specs = apply_wildcard_and_validate(specs, transform_registry)

        transforms: list[AirTransform] = []
        for spec in specs:
            transforms.append(transform_registry.get(spec.name)(enabled=spec.enabled, options=spec.options))
        return cls(transforms)
