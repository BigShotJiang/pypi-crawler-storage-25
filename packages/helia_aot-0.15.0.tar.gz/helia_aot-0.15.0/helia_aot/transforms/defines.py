from pydantic.dataclasses import dataclass
from pydantic import Field

BasicType = float | int | str | bool
NestedType = BasicType | list[BasicType] | dict[str, BasicType]


@dataclass
class TransformSpec:
    """Configuration for a transform.

    Attributes:
        name (str): Name of the transform. Use "*" to match all transforms.
        enabled (bool): Whether the transform is enabled.
        options (dict[str, Any]): Additional options for the transform.
    """

    name: str = Field(default="*", description="Name of the transform")
    enabled: bool = Field(default=True, description="Whether the transform is enabled")
    options: dict[str, NestedType] = Field(default_factory=dict, description="Additional options for the transform")
