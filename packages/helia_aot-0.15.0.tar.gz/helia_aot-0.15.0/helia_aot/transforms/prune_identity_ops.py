from pydantic.dataclasses import dataclass
from pydantic import Field
from .transform import AirTransform
from ..utils import setup_logger
from helia_aot.air import AirModel, AirOpType, AirOperator

logger = setup_logger(log_name=__name__)


@dataclass
class PruneIdentityOpsOptions:
    """Options for the PruneIdentityOps transform."""

    identity_ops: frozenset["AirOpType"] = Field(
        default_factory=lambda: frozenset(
            {
                AirOpType.EXPAND_DIMS,
                AirOpType.RESHAPE,
                AirOpType.SQUEEZE,
            }
        ),
        description="Set of ops to treat as identity (no-op) and prune.",
    )


class PruneIdentityOps(AirTransform):
    """The purpose of this transform is to make identity ops into no-ops.

    Identity operators are those that only change the view but not the data itself,
    such as EXPAND_DIMS, RESHAPE, and SQUEEZE.

    1. Find any identity operator where subsequent operators dont rely on input tensor.
    2. If found, set output tensor as alias of input tensor.

    """

    NAME = "PRUNE_IDENTITY_OPS"

    IDENTITY_OPS = {AirOpType.EXPAND_DIMS, AirOpType.RESHAPE, AirOpType.SQUEEZE}

    def is_identity(self, op: AirOperator) -> bool:
        if op.op_type not in self.IDENTITY_OPS:
            return False
        if len(op.input_ids) != 1 or len(op.output_ids) != 1:
            return False
        return True

    def apply(self, model: AirModel) -> AirModel:
        """Apply the transform.

        Args:
            model (AirModel): The model to transform.

        Returns:
            AirModel: The transformed model.
        """

        for op in model.operators:
            if self.is_identity(op):
                logger.debug(f"[magenta]  • Making operator {op.id} of type {op.op_type} a no-op [/]")
                input_tensor = model.get_tensor(op.input_ids[0])
                output_tensor = model.get_tensor(op.output_ids[0])
                output_tensor.alias_of = input_tensor.id
            # END IF
        # END FOR

        return model
