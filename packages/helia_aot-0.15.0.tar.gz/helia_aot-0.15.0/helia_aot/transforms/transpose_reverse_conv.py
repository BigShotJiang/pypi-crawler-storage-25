from typing import Any
from pydantic.dataclasses import dataclass
from pydantic import Field
import numpy as np
from .transform import AirTransform
from ..utils import setup_logger
from helia_aot.air import AirModel, AirOperator, AirOpType, AirConv2DOptions, AirTransposeConvOptions

logger = setup_logger(log_name=__name__)


@dataclass
class TransposeReverseConvOptions:
    """Options for the TransposeReverseConv transform."""

    input_channel_threshold: int = Field(default=16, description="Minimum input channels to consider conversion.")


class TransposeReverseConv(AirTransform):
    """The purpose of this transform is to convert TRANSPOSE_CONV to CONV_2D operators
    when possible and efficient.

    1. Find any TRANSPOSE_CONV operator that is reversible
    2. Transform to CONV_2D operator if threshold is met.

    """

    NAME = "TRANSPOSE_REVERSE_CONV"
    options: TransposeReverseConvOptions

    def __init__(self, enabled: bool = True, options: dict[str, Any] = None):
        super().__init__(enabled, options)
        self.options = TransposeReverseConvOptions(**(options or {}))

    def convert_operator(self, op: AirOperator, model: AirModel):
        """Convert the TRANSPOSE_CONV operator to CONV_2D operator.

        Args:
            op (AirOperator): The TRANSPOSE_CONV operator to convert.
            model (AirModel): The AIR model

        """

        transpose_options = op.options
        if not isinstance(transpose_options, AirTransposeConvOptions):
            raise TypeError(f"Expected AirTransposeConvOptions, received {type(transpose_options)}")

        # 1. Update the operator type
        op.op_type = AirOpType.CONV_2D

        # 2. Convert the options
        weights_tensor = model.get_tensor(op.named_tensors["weights"])
        filter_height = weights_tensor.shape[1]
        filter_width = weights_tensor.shape[2]

        op.options = AirConv2DOptions(
            padding_height=filter_height - 1 - transpose_options.padding_height,
            padding_width=filter_width - 1 - transpose_options.padding_width,
            stride_height=1,
            stride_width=1,
            dilation_height=1,
            dilation_width=1,
            activation=transpose_options.activation,
            bias_tensor_type=transpose_options.bias_tensor_type,
            upscale_height=max(1, transpose_options.stride_height),
            upscale_width=max(1, transpose_options.stride_width),
        )

        # 3. Fix the weights tensor
        weights_tensor.data = np.flip(weights_tensor.data, axis=(1, 2)).copy()

    def is_reversible(self, op: AirOperator, model: AirModel) -> bool:
        """Check if the TRANSPOSE_CONV operator is reversible.

        Args:
            op (AirOperator): The TRANSPOSE_CONV operator to check.
            model (AirModel): The AIR model

        Returns:
            bool: True if the operator is reversible, False otherwise.
        """
        reversible = (op.options.stride_width <= 2) and (op.options.stride_height <= 2)
        return reversible

    def is_efficient(self, op: AirOperator, model: AirModel) -> bool:
        """Check if the TRANSPOSE_CONV operator is efficient to convert.

        Args:
            op (AirOperator): The TRANSPOSE_CONV operator to check.
            model (AirModel): The AIR model

        Returns:
            bool: True if the operator is efficient to convert, False otherwise.
        """
        input_tensor = model.get_tensor(op.input_ids[0])
        input_channels = input_tensor.shape[-1]
        if input_channels > self.options.input_channel_threshold:
            return True
        return False

    def apply(self, model: AirModel) -> AirModel:
        """Apply the transform.

        Args:
            model (AirModel): The model to transform.

        Returns:
            AirModel: The transformed model.
        """

        for op in model.operators:
            if (
                op.op_type == AirOpType.TRANSPOSE_CONV
                and self.is_reversible(op, model)
                and self.is_efficient(op, model)
            ):
                logger.debug(f"[magenta]  • Converting operator {op.id} from {op.op_type} to {AirOpType.CONV_2D} [/]")
                self.convert_operator(op, model)
            # END IF
        # END FOR

        return model
