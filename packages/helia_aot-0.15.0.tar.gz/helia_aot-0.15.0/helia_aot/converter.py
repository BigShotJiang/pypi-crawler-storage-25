"""

# :material-graph: AotModel API

The `AotConverter` class is responsible for converting a model into an AOT inference C module.

Classes:
    AotConverter: Performs the AOT conversion process.

Copyright 2025 Ambiq. All Rights Reserved.

"""

import tempfile
import shutil
import json
from pathlib import Path

from .cli import ConvertArgs

from helia_aot.aot import (
    AotHandler,
    DocHandler,
    ModelHandler,
    ModuleHandler,
    OperatorHandler,
    TensorHandler,
    TestHandler,
    CodeGenContext,
)
from helia_aot.memory import get_memory_planner
from helia_aot.memory.backend import PlannerBackend
from helia_aot.platforms import resolve_platform
from helia_aot.converters import convert_backend_model
from helia_aot.transforms import TransformPipeline
from .aot.render_plan import build_render_plan
from .utils import setup_logger, StepContext
from helia_aot.air import propagate_shapes
from helia_aot.registry.context import RegistryContext, build_default_registry_context
from helia_aot.aot.operators.rsqrt import warn_on_rsqrt_lut_mode

logger = setup_logger(log_name=__name__)


class AotConverter:
    config: ConvertArgs

    def __init__(self, config: ConvertArgs, registry_context: RegistryContext | None = None):
        """Initialize the AOT converter.

        This class is responsible for converting a model into an AOT inference C module.

        Args:
            config (ConvertArgs): Conversion parameters.
            registry_context (RegistryContext | None): Optional registry context for parser/operator/transform
                dispatch. If omitted, a fresh default frozen context is created.
        """
        self.config = config
        self.registry_context = registry_context or build_default_registry_context()

    def convert(self) -> CodeGenContext:
        """Convert the model to an AOT module.

        The conversion process consists of six stages:
            1. Load (Backend → AIR)
            2. Transform (Graph-Level Optimizations)
            3. Resolve (Final AIR Structure)
            4. Plan (Memory & Handler Planning)
            5. Emit (Code Generation)
            6. Export (Module Export)

        Returns:
            CodeGenContext: Code generation context.
        """

        # Surface the deprecated ``memory.auto_hydrate_constants=False``
        # toggle as a soft warning so users know it no longer affects
        # generated code. ``model_init`` always invokes
        # ``hydrate_constants`` between ``context_init`` and the op-init
        # loop; callers needing custom hydration override the weak
        # symbol instead.
        if not self.config.memory.auto_hydrate_constants:
            logger.warning(
                "memory.auto_hydrate_constants=False is deprecated and no "
                "longer changes generated runtime behavior; model_init "
                "always hydrates staged-constant arenas before op-init. "
                "Override the weak <prefix>_hydrate_constants symbol for "
                "custom hydration (DMA / async pre-stage / model swap)."
            )

        #######################################################################
        # AIR FRONT-END STEPS
        #######################################################################

        # 1. Load (Backend → AIR)
        with StepContext(f"Loading model {self.config.model.path.name}"):
            model = convert_backend_model(
                model_path=self.config.model.path,
                registry_context=self.registry_context,
                subgraph=self.config.model.subgraph,
                type=self.config.model.type,
                verbose=self.config.verbose,
            )
            for attr in ("name", "description", "version"):
                val = getattr(self.config.model, attr)
                if val:
                    setattr(model, attr, val)
            # END FOR
        # END WITH

        # 2. Transform (Graph-Level Optimizations)
        with StepContext("Applying graph-level transforms"):
            pipeline = TransformPipeline.from_config(
                specs=self.config.transforms,
                transform_registry=self.registry_context.transforms,
            )
            model = pipeline.apply(model)
        # END WITH

        warn_on_rsqrt_lut_mode(model, self.config.operators)

        with StepContext("Propagating tensor shapes"):
            propagate_shapes(model=model, strict=False)
        # END WITH

        #######################################################################
        # AOT BACK-END STEPS
        #######################################################################

        # Create code generation context
        context = CodeGenContext(
            config=self.config,
            model=model,
            platform=resolve_platform(self.config.platform),
            work_path=Path(tempfile.mkdtemp(prefix="helia-aot")) / self.config.module.name,
            memory_plan=None,
            registry_context=self.registry_context,
        )
        context.work_path.mkdir(parents=True, exist_ok=True)

        # 3. Resolve (Final AIR structure)
        with StepContext("Resolving handlers"):
            #  Create handlers
            handlers: list[AotHandler] = [
                ModuleHandler(context),
                OperatorHandler(context),
                TensorHandler(context),
                ModelHandler(context),
                DocHandler(context),
            ]
            if context.config.test.enabled:
                handlers.append(TestHandler(context))

            # Resolve each handler
            for handler in handlers:
                handler.resolve()
        # END WITH

        # 4. Plan (Memory & Handler Planning)
        with StepContext(f"Memory planning via {context.config.memory.planner}"):
            # Drop tensors that no operator (or model I/O) references
            # before planning so the planner and downstream emit stages
            # observe the same tensor set. Previously this lived inside
            # ``GreedyMemoryPlanner.plan`` as an implicit side effect;
            # promoting it to an explicit converter step keeps planner
            # implementations side-effect-free on the model.
            removed = context.model.prune_unused_tensors()
            if removed:
                logger.info(
                    "pruned %d unreferenced tensor(s) before planning: %s",
                    len(removed),
                    ", ".join(sorted(map(str, removed))),
                )
            planner: PlannerBackend = get_memory_planner(context.config.memory.planner)(target=context.platform)
            context.memory_plan = planner.plan(
                model=context.model,
                memory_constraints=context.config.memory.constraints,
                tensor_constraints=context.config.memory.tensors,
            )
            # Project planner output into the render-side DTO once,
            # so handlers and templates consume already-resolved
            # cold/staged predicates and packed constant blobs.
            context.render_plan = build_render_plan(
                plan=context.memory_plan,
                model=context.model,
                module_prefix=context.config.module.prefix,
            )
            # Handler planning
            for handler in handlers:
                handler.plan()
            # END FOR
            # Emit a hydration / residency summary so users can sanity
            # check staged-mode plans before flashing. Verbose-only to
            # stay quiet on default invocations.
            if context.config.verbose >= 2:
                _log_residency_summary(context)
            if context.config.memory.dump_residency_json:
                _dump_residency_json(context)
        # END WITH

        # 5. Emit (Code Generation)
        with StepContext(f"Emitting code as {context.config.module.type} module"):
            for handler in handlers:
                handler.emit(save_path=context.work_path)
            # END FOR
        # END WITH

        # 6. Export the module
        with StepContext(f"Exporting module: {context.config.module.path}", ellipses=False):
            # As archive
            if context.config.module.path.suffix == ".zip":
                save_path = context.config.module.path
                if save_path.exists() and not context.config.force:
                    raise FileExistsError(
                        f"Output path {context.config.module.path} already exists. Use --force to overwrite."
                    )
                shutil.make_archive(
                    base_name=save_path.with_suffix(""),
                    format="zip",
                    root_dir=context.work_path.parent,
                    base_dir=context.work_path.name,
                )
            # As directory
            else:
                save_path = context.config.module.path / context.config.module.name
                if save_path.exists():
                    if not context.config.force:
                        raise FileExistsError(f"Output path {save_path} already exists. Use --force to overwrite.")
                    # END IF
                    shutil.rmtree(save_path)
                # END IF
                shutil.copytree(context.work_path, save_path, dirs_exist_ok=True)
            # END IF
        # END WITH

        return context


def _log_residency_summary(context: "CodeGenContext") -> None:
    """Emit a verbose summary of how the planner allocated tensors
    across arenas (scratch, persistent, constant).

    Output is intended for ``--verbose 2`` and above and is purely
    informational. Constant arenas come in two shapes — *cold* (the
    arena buffer is the read-only blob in source memory; kernels read
    in place) and *staged* (the arena buffer is a writable runtime
    copy hydrated from a separate source blob).

    Iterates the :class:`RenderMemoryPlan` (single source of truth
    for region ordering, cold/staged predicate, source memory) and
    looks up planner-only details (``total_size``, per-arena tensor
    count) on the planner's :class:`MemoryPlan`.
    """
    plan = context.memory_plan
    render_plan = context.render_plan
    if plan is None or render_plan is None:
        return

    if render_plan.scratch_arenas:
        logger.info("Scratch arenas:")
        for arena in render_plan.scratch_arenas:
            usage = plan.arena_usages.get(arena.memory)
            total = int(usage.total_size) if usage is not None else int(arena.size)
            logger.info(
                f"  • {arena.memory.name.lower():<6}  used={arena.size}  total={total}"
            )

    if render_plan.persistent_arenas:
        logger.info("Persistent arenas:")
        for arena in render_plan.persistent_arenas:
            logger.info(
                f"  • persistent_{arena.memory.name.lower():<6}  size={arena.size} B"
            )

    if render_plan.constant_arenas:
        # Per-arena constant tensor counts (planner-only detail).
        const_counts: dict = {}
        for alloc in plan.tensor_allocs.values():
            if alloc.binding is not None and alloc.binding.role.name == "constant":
                const_counts[alloc.binding.memory] = const_counts.get(alloc.binding.memory, 0) + 1

        logger.info(f"Constant arenas ({len(render_plan.constant_arenas)}):")
        for arena in render_plan.constant_arenas:
            shape = "staged" if arena.is_staged else "cold"
            src = arena.source_memory.name.lower()
            n_consts = const_counts.get(arena.memory, 0)
            logger.info(
                f"  • const_{arena.memory.name.lower():<6}  size={arena.size} B  "
                f"shape={shape}  src={src} -> dst={arena.memory.name.lower()}  "
                f"consts={n_consts}"
            )
        # Hint at hydration only if any arena is staged.
        if render_plan.has_staged_constants:
            logger.info(
                "  (staged constants hydrated by <prefix>_model_init; "
                "override the weak <prefix>_hydrate_constants to customize)"
            )


_RESIDENCY_SCHEMA_VERSION = 3


def _dump_residency_json(context: "CodeGenContext") -> None:
    """Write a machine-readable residency report alongside the module.

    The report mirrors :func:`_log_residency_summary` as a stable JSON
    document for tooling that needs to introspect post-planning arena
    layout, staged-vs-cold residency, and per-tensor placement
    without scraping log output. The file is written to
    ``<work_path>/<prefix>_residency.json`` and is opt-in via
    ``memory.dump_residency_json``.

    Schema (``schema_version = 3``):

    .. code-block:: json

        {
          "schema_version": 3,
          "module_prefix": "<prefix>",
          "plan_hash": "<16 hex chars>",
          "tensor_layout_hash": "<16 hex chars>",
          "arenas": {
            "scratch":    [ {region_id, memory, used, total_size, alignment} ],
            "persistent": [ {region_id, memory, used, total_size, alignment} ],
            "constant":   [ {region_id, memory, source_memory, kind,
                             used, total_size, alignment,
                             tensor_count} ]
          },
          "tensors": [
            {id, role, memory, source_memory, offset, size}
          ]
        }

    Schema-version 3 (vs 2) adds ``tensor_layout_hash`` at the top
    level. The two hashes have disjoint scopes:

    * ``plan_hash`` fingerprints the **arena envelope** only
      (per-region role / memory / source_memory / size / alignment /
      is_staged). Used by ``<PREFIX>_PLAN_HASH`` for arena-ABI
      drift detection across separately-compiled binaries.
    * ``tensor_layout_hash`` fingerprints **per-tensor placement**
      (tensor_id / role / memory / offset / size). Captures drift
      the envelope hash misses — e.g. two tensors swapping offsets
      within the same arena, or a tensor migrating between arenas
      of identical shape.

    Schema-version 2 (vs 1) added ``plan_hash`` at the top level
    and ``region_id`` on every arena entry so consumers can
    correlate JSON entries with the C ``<prefix>_arena_*``
    enumerator values.

    Args:
        context: Active codegen context. Must have a populated
            ``memory_plan`` and ``render_plan``; otherwise the helper
            is a no-op.
    """
    plan = context.memory_plan
    render_plan = context.render_plan
    if plan is None or render_plan is None:
        return

    def _arena_dict(render_arena, *, include_source: bool = False) -> dict:
        # Look up planner-only total_size by memory key. For
        # bump-allocated constant/persistent arenas this equals
        # ``size``; for scratch it is the reservation high-water mark.
        if render_arena.role == "scratch":
            usage = plan.arena_usages.get(render_arena.memory)
        elif render_arena.role == "persistent":
            usage = plan.persistent_arenas.get(render_arena.memory)
        else:
            usage = plan.constant_arenas.get(render_arena.memory)
        total = int(usage.total_size) if usage is not None else int(render_arena.size)

        d: dict = {
            "region_id": int(render_arena.region_id),
            "memory": render_arena.memory.name.lower(),
            "used": int(render_arena.size),
            "total_size": total,
            "alignment": int(render_arena.alignment),
        }
        if include_source:
            d["source_memory"] = render_arena.source_memory.name.lower()
            d["kind"] = "staged" if render_arena.is_staged else "cold"
        return d

    # Per-arena tensor counts for constants (purely informational).
    const_counts: dict = {}
    for alloc in plan.tensor_allocs.values():
        if alloc.binding is not None and alloc.binding.role.name == "constant":
            const_counts[alloc.binding.memory] = const_counts.get(alloc.binding.memory, 0) + 1

    constant_entries = []
    for arena in render_plan.constant_arenas:
        entry = _arena_dict(arena, include_source=True)
        entry["tensor_count"] = const_counts.get(arena.memory, 0)
        constant_entries.append(entry)

    tensors = []
    for tid, alloc in plan.tensor_allocs.items():
        binding = alloc.binding
        tensors.append(
            {
                "id": str(tid),
                "role": binding.role.name.lower() if binding is not None else None,
                "memory": alloc.memory.name.lower(),
                "source_memory": (
                    binding.source_memory.name.lower()
                    if binding is not None and binding.source_memory is not None
                    else None
                ),
                "offset": int(alloc.offset),
                "size": int(alloc.size),
            }
        )

    def _tensor_sort_key(t: dict) -> tuple[int, int | str]:
        # Sort numerically when possible (so "10" follows "2"), else
        # fall back to lexicographic on the string id. Returning a
        # 2-tuple keeps numeric and non-numeric ids in disjoint bands
        # while still giving a stable, total order.
        tid = t["id"]
        try:
            return (0, int(tid))
        except (TypeError, ValueError):
            return (1, tid)

    tensors.sort(key=_tensor_sort_key)

    report = {
        "schema_version": _RESIDENCY_SCHEMA_VERSION,
        "module_prefix": context.config.module.prefix,
        "plan_hash": render_plan.plan_hash,
        "tensor_layout_hash": render_plan.tensor_layout_hash,
        "arenas": {
            "scratch": [_arena_dict(a) for a in render_plan.scratch_arenas],
            "persistent": [_arena_dict(a) for a in render_plan.persistent_arenas],
            "constant": constant_entries,
        },
        "tensors": tensors,
    }

    out_path = context.work_path / f"{context.config.module.prefix}_residency.json"
    if out_path.exists() and not context.config.force:
        raise FileExistsError(
            f"Residency report {out_path} already exists. Use --force to overwrite."
        )
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    logger.info("wrote residency report to %s", out_path)
