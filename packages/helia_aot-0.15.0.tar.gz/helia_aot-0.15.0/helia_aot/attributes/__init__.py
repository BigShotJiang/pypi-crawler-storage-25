"""

# :material-tune: Attributes API

The attributes feature allows you to customize the behavior of specific entities (e.g. operators and tensors) during the conversion process. This is useful for optimizing performance or adapting to specific hardware constraints. For example, you can specify the memory placement for certain operators. You can define operator attributes in the YAML configuration file. The `operator_attributes` section allows you to specify a list of attributes for different operators.
An attribute ruleset allows providing sets of attributes for an entity that is of the specified type or ID(s).

Copyright 2025 Ambiq. All Rights Reserved.

"""

from .defines import AttributeRuleset
from .attributes import compute_entity_attributes
