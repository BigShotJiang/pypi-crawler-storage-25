from pydantic import BaseModel, Field

BasicType = float | int | str | bool


class AttributeRuleset(BaseModel):
    """This class defines a powerful and flexible way to customize the conversion process for specific entities in the model.

    Multiple attributes can be specified and allow slicing the model by entity type, entity identifier(s), or a specific combination of both.

    The `type` field can be a specific entity type (e.g., CONV_2D) or * for all types.
    The `id` field can be a specific entity identifier or a list of identifiers.

    Since multiple attributes can be applied to the same entity, precedence is given based on the pair:
        1. (1, 1) if both type and id are specified and match
        2. (1, 0) if type is specified and id is not
        3. (0, 1) if id is specified and type is not
        4. (0, 0) if neither is specified

    Currently, if multiple attributes have the same precedence, the last one in the list will be used.

    Attributes:
        type (str): The entity type (e.g. CONV_2D or PERSISTENT) or * for all.
        id (str|list[str]|None): The entity identifier or list of identifiers.
        attributes (dict[str, BasicType]): A dictionary of entity attributes.

    """

    type: str = Field(default="*", description="Entity type (e.g. CONV_2D) or * for all")
    id: str | list[str] | None = Field(default=None, description="Entity identifier(s)")
    attributes: dict[str, BasicType] = Field(..., description="Entity attributes", default_factory=dict)
