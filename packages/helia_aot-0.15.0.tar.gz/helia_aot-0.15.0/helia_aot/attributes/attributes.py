"""
# :material-function-variant: Entity Attributes Utility API

This module provides utility functions for handling entity attributes.

Functions:
    is_attribute_rule_match: Check if an entity attribute rule matches a given entity type and identifier.
    get_attributes_rule_specificity: Compute the specificity of an entity attribute rule.
    compute_entity_attributes: Compute the entity attributes for a given entity type and identifier.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from typing import Any
from .defines import AttributeRuleset


def is_attribute_rule_match(rule: AttributeRuleset, entity_type: str, entity_id: str) -> bool:
    """Determine if an attribute rule matches a given entity type and identifier.

    Args:
        rule (AttributeRuleset): The attribute rule.
        entity_type (str): The entity type.
        entity_id (str): The entity identifier.

    Returns:
        bool: True if the rule matches, False otherwise.
    """
    if rule.type != "*" and rule.type != entity_type:
        return False
    if rule.id is None:
        return True
    if isinstance(rule.id, str):
        return rule.id == entity_id
    return entity_id in rule.id


def get_attributes_rule_specificity(rule: AttributeRuleset) -> tuple[int, int]:
    """Compute the specificity of an entity attribute rule.
    The specificity is determined by the presence of type and identifier.

    Args:
        rule (AttributeRuleset): The entity attribute rule.

    Returns:
        tuple[int,int]: A tuple representing the specificity of the rule.
    """

    type_spec = 0 if rule.type == "*" else 1
    ident_spec = 0 if rule.id is None else 1
    return (type_spec, ident_spec)


def compute_entity_attributes(attributes: list[AttributeRuleset], entity_type: str, entity_id: str) -> dict[str, Any]:
    """Compute the attributes for a given entity type and identifier.

    This function collects all matching rules, sorts them by specificity and index,
    and merges them into a final dictionary of attributes.
    The specificity is determined by the presence of type and identifier.
    The index is the order in which the rules were defined in the YAML file.

    Args:
        attributes (list[AttributeRuleset]): List of attribute rules.
        entity_type (str): The entity type.
        entity_id (str): The entity identifier.

    Returns:
        dict[str, Any]: Merged dictionary of entity attributes.
    """

    # 1) collect all matching rules with their index
    matched = []
    for idx, rule in enumerate(attributes):
        if is_attribute_rule_match(rule, entity_type, entity_id):
            spec = get_attributes_rule_specificity(rule)
            matched.append((spec, idx, rule))

    # 2) sort by (specificity, yaml_index)
    matched.sort(key=lambda x: (x[0], x[1]))

    # 3) merge them in that order
    final: dict[str, Any] = {}
    for _, _, rule in matched:
        final.update(rule.attributes)

    return final
