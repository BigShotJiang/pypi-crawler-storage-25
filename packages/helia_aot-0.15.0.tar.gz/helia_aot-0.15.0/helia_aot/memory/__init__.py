"""

# :material-memory: heliaAOT Memory API

The `memory` module performs memory management and planning tasks of AIR models.

It provides classes and functions to handle memory allocation, tensor lifetimes, and operator scheduling.

1. **Computing tensor lifetimes**: This involves determining the lifetime of each tensor in the network graph, which is essential for memory management.
2. **Operator scheduling**: This involves determining the order in which operators should be executed to optimize memory usage and performance.
3. **Memory allocation**: This involves allocating memory for the tensors based on their lifetimes and the order of operator execution.

## Available Memory Planners

The `AirMemoryPlanner` class provides a common interface for all memory planners, and each subclass implements a specific memory planning algorithm.

- **[GreedyMemoryPlanner](./greedy_memory_planner)**: A greedy algorithm that allocates memory for tensors based on their lifetimes and the order of operator execution.
This planner currently uses the default operator order from the model.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from .defines import (
    MemoryPlan,
    TensorLifetime,
    ArenaRole,
    ArenaUsage,
    TensorAllocation,
    TensorBinding,
    MemoryPlannerType,
    MemoryConstraint,
    TensorAttributes,
    MemoryFreeBlock,
    MemoryActiveBlock,
)
from .planner import AirMemoryPlanner, get_memory_planner
from .greedy_planner import GreedyMemoryPlanner
from .backend import PlannerBackend
