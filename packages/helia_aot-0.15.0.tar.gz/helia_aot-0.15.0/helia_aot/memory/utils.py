"""
# :material-tools: Memory Planners Utilities API

The `utils` module provides utility functions for memory planning in the AOT compilation process.

Functions:
    compute_tensor_lifetimes: Computes the lifetimes of tensors based on the operators.
    merge_free_list: Merges contiguous free blocks in memory.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from .defines import TensorLifetime, MemoryFreeBlock
from helia_aot.air import TensorId, AirModel
from ..utils import setup_logger


logger = setup_logger(log_name=__name__)


def compute_tensor_lifetimes(model: AirModel) -> dict[TensorId, TensorLifetime]:
    """Compute the lifetimes of tensors based on the operators.

    For each tensor, compute its lifetime as a tuple (first, last)
    based on the operator order. The lifetime is defined by the first operator that
    uses or produces the tensor and the last operator that uses it.

    Args:
        model (AirModel): The model to compute tensor lifetimes for.

    Returns:
        lifetimes (dict[TensorId, TensorLifetime]): Mapping from tensor ID to its lifetime.
    """

    lifetimes: dict[TensorId, TensorLifetime] = {}

    for i, op in enumerate(model.operators):
        for tensor_id in op.tensor_ids:
            tensor = model.get_tensor(tensor_id)
            # These persist across the entire model execution
            if tensor.is_constant or tensor.is_persistent:
                lifetimes[tensor_id] = TensorLifetime(tensor_id=tensor_id, start_op=0, end_op=len(model.operators) - 1)
            # Update if already exists
            elif tensor_id in lifetimes:
                lifetimes[tensor_id].add_op(i)
            # Otherwise, create a new lifetime entry
            else:
                lifetimes[tensor_id] = TensorLifetime(tensor_id=tensor_id, start_op=i, end_op=i)
        # END FOR

    # For input tensors, extend the lifetime to the first operator
    for tensor_id in model.input_ids:
        if tensor_id in lifetimes:
            lifetimes[tensor_id].start_op = 0
        else:
            lifetimes[tensor_id] = TensorLifetime(tensor_id=tensor_id, start_op=0, end_op=0)

    # For output tensors, extend the lifetime to the last operator
    for tensor_id in model.output_ids:
        if tensor_id in lifetimes:
            lifetimes[tensor_id].end_op = len(model.operators) - 1
        else:
            lifetimes[tensor_id] = TensorLifetime(tensor_id=tensor_id, start_op=len(model.operators) - 1, end_op=len(model.operators) - 1)

    logger.debug("Tensor lifetimes:")
    for tensor_id, lifetime in lifetimes.items():
        logger.debug(f"  • Tensor {tensor_id}: Lifetime from operator {lifetime.start_op} to {lifetime.end_op}")
    # END FOR

    return lifetimes


def merge_free_list(free_list: list[MemoryFreeBlock]) -> list[MemoryFreeBlock]:
    """Merge contiguous free blocks.

    Args:
        free_list (list[MemoryFreeBlock]): List of MemoryFreeBlock instances.

    Returns:
        merged (list[MemoryFreeBlock]): A new list with contiguous blocks merged.
    """

    if not free_list:
        return []

    # Sort free blocks by offset.
    free_list.sort(key=lambda x: x.offset)
    merged = []
    cur_block = free_list[0]
    for block in free_list[1:]:
        # If current block touches the next block, merge them.
        if cur_block.offset + cur_block.size == block.offset:
            cur_block.size += block.size
        else:
            merged.append(cur_block)
            cur_block = block
    merged.append(cur_block)
    return merged
