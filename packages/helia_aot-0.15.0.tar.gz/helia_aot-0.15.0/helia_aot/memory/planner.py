"""

# :material-graph: AotMemoryPlanner API

This class is the base class for all memory planners in the heliaAOT framework.

Classes:
    AotMemoryPlanner: Base class for memory planners

Functions:

Copyright 2025 Ambiq. All Rights Reserved.

"""

import abc
import copy
from types import MappingProxyType

from helia_aot.air import AirModel, TensorId, AirTensor
from helia_aot.platforms import SocPlatform, MemoryType
from helia_aot.attributes import AttributeRuleset, compute_entity_attributes
from .defines import MemoryPlan, MemoryConstraint, TensorAttributes, TensorLifetime
from ..utils import setup_logger

logger = setup_logger(log_name=__name__)

_MEMORY_PLANNER_REGISTRY: dict[str, type["AirMemoryPlanner"]] = {}

# read-only view for introspection
MEMORY_PLANNER_REGISTRY = MappingProxyType(_MEMORY_PLANNER_REGISTRY)


def register_memory_planner(cls: type["AirMemoryPlanner"]) -> type["AirMemoryPlanner"]:
    """Class decorator: register each memory planner by its NAME."""
    _MEMORY_PLANNER_REGISTRY[cls.NAME] = cls
    return cls


def get_memory_planner(name: str) -> type["AirMemoryPlanner"]:
    """Get a memory planner by its name."""
    if name not in _MEMORY_PLANNER_REGISTRY:
        raise ValueError(f"Memory planner '{name}' not found.")
    return _MEMORY_PLANNER_REGISTRY[name]


class AirMemoryPlanner(abc.ABC):
    NAME: str  # Unique name for the memory planner

    target: SocPlatform
    default_alignment: int = 16

    def __init__(self, target: SocPlatform):
        self.target = target

    def _required_alignment(self, tensor: AirTensor) -> int:
        """Compute the required alignment for a tensor.

        Current inputs (Phase 1):
            * ``self.target.min_alignment`` — platform/SoC-level floor
              (e.g. MVE/Helium load width).
            * ``tensor.dtype_alignment_floor`` — natural alignment of the
              element type.
            * ``tensor.alignment_hint`` — per-tensor override populated
              by op handlers that need stronger alignment than dtype
              alone implies (e.g. CMSIS-NN dot-product kernels, Ethos-U
              command streams).

        The result is ``max`` of all populated candidates. Behavior is
        characterization-locked by
        ``tests/unit/memory/test_planner_alignment.py``.

        TODO (tracked in `docs/rfcs/0002-arena-model-hardening.md`):
        generalize this to accept ``(consumer_set, hydration_mode)``
        so DMA-driven hydration can demand stronger alignment without
        an op-side ``alignment_hint`` workaround. Until that lands
        the consumer set is implicit via ``alignment_hint``
        populated by op handlers.
        """
        alignment_candidates: list[int] = [
            self.target.min_alignment or 1,
            tensor.dtype_alignment_floor,
        ]
        if tensor.alignment_hint is not None:
            alignment_candidates.append(tensor.alignment_hint)
        return max(alignment_candidates)

    @staticmethod
    def _align_up(value: int, alignment: int) -> int:
        """Round value up to the nearest multiple of alignment."""
        if alignment <= 1:
            return value
        return ((value + alignment - 1) // alignment) * alignment

    # Implementation-level alignment floor applied to every arena
    # **base** symbol regardless of platform. Matches the historical
    # ``alignas(16)`` baked into templates so the emitted layout is
    # unchanged when users do not explicitly set
    # ``MemoryConstraint.arena_alignment``. Note this is **not**
    # applied to per-slot offsets within an arena: those continue to
    # use the platform/dtype/hint-derived alignment so behavior of
    # existing models is preserved.
    ARENA_BASE_ALIGNMENT_FLOOR: int = 16

    def _arena_alignment(
        self,
        memory: MemoryType,
        memory_constraints: dict[MemoryType, MemoryConstraint] | None = None,
    ) -> int:
        """Slot alignment floor for tensors packed into ``memory``.

        Returns ``max(platform.min_alignment, MemoryConstraint.arena_alignment)``.
        Callers ``max`` this with :meth:`_required_alignment` when
        choosing a slot offset, so per-tensor dtype/hint alignment is
        still honored. The implementation-level
        :attr:`ARENA_BASE_ALIGNMENT_FLOOR` is **not** included here —
        it only applies to the arena base symbol via
        :meth:`_arena_base_alignment`.
        """
        candidates: list[int] = [self.target.min_alignment or 1]
        if memory_constraints is not None:
            constraint = memory_constraints.get(memory)
            if constraint is not None and constraint.arena_alignment is not None:
                candidates.append(constraint.arena_alignment)
        return max(candidates)

    def _arena_base_alignment(
        self,
        memory: MemoryType,
        memory_constraints: dict[MemoryType, MemoryConstraint] | None = None,
    ) -> int:
        """Resolved alignment of an arena's base symbol in C.

        ``max(ARENA_BASE_ALIGNMENT_FLOOR, _arena_alignment(memory))``.
        The base must be at least as aligned as any slot inside it,
        and historically every arena base was hard-coded
        ``alignas(16)``; that floor is preserved here.
        """
        return max(self.ARENA_BASE_ALIGNMENT_FLOOR, self._arena_alignment(memory, memory_constraints))

    def fill_memory_constraints(
        self,
        _model: AirModel,
        constraints: list[MemoryConstraint] | None = None,
    ) -> dict[MemoryType, MemoryConstraint]:
        """Resolve memory constraints, filling defaults from the target when max_size is None."""
        memory_constraints: dict[MemoryType, MemoryConstraint] = {}

        if constraints is None:
            for mem_type in self.target.preferred_memory_order:
                memory_constraints[mem_type] = MemoryConstraint(
                    name=mem_type,
                    max_size=self.target.memories[mem_type],
                )
            return memory_constraints

        for constraint in constraints:
            memory = MemoryType(constraint.name)
            if memory not in self.target.memories:
                raise ValueError(f"Memory type {memory} not found in target platform {self.target.name}")

            resolved_constraint = copy.copy(constraint)
            if resolved_constraint.max_size is None:
                resolved_constraint.max_size = self.target.memories[memory]
            if (
                resolved_constraint.max_size < 0
                or resolved_constraint.max_size > self.target.memories[memory]
            ):
                raise ValueError(
                    f"Invalid size {resolved_constraint.max_size} for memory type {memory} in target platform {self.target.name}"
                )
            memory_constraints[memory] = resolved_constraint

        return memory_constraints

    def fill_tensor_constraints(
        self,
        model: AirModel,
        attributes: list[AttributeRuleset] | None = None,
    ) -> dict[TensorId, TensorAttributes]:
        """Resolve per-tensor placement constraints from attribute rules."""
        tensor_constraints: dict[TensorId, TensorAttributes] = {}
        if attributes is None:
            return tensor_constraints
        for tensor_id, tensor in model.tensors.items():
            attrs = compute_entity_attributes(attributes, tensor.kind.value, tensor.id)
            if len(attrs) == 0:
                continue
            tensor_constraints[tensor_id] = TensorAttributes(**attrs)
        return tensor_constraints

    def merge_alias_lifetimes_to_fixed_point(
        self,
        model: AirModel,
        tensor_lifetimes: dict[TensorId, TensorLifetime],
    ) -> None:
        """Merge alias-linked tensor lifetimes until no live range changes remain."""
        changed = True
        while changed:
            changed = False
            for tensor_id, lifetime in tensor_lifetimes.items():
                tensor = model.get_tensor(tensor_id)
                if tensor.alias_of and tensor.alias_of in tensor_lifetimes:
                    alias_lifetime = tensor_lifetimes[tensor.alias_of]
                    old_lifetime_range = (lifetime.start_op, lifetime.end_op)
                    old_alias_range = (alias_lifetime.start_op, alias_lifetime.end_op)
                    lifetime.merge(alias_lifetime)
                    alias_lifetime.merge(lifetime)
                    new_lifetime_range = (lifetime.start_op, lifetime.end_op)
                    new_alias_range = (alias_lifetime.start_op, alias_lifetime.end_op)
                    if new_lifetime_range != old_lifetime_range or new_alias_range != old_alias_range:
                        changed = True

    def populate_alias_allocations(
        self,
        model: AirModel,
        plan: MemoryPlan,
        sorted_tensors: list[tuple[TensorId, TensorLifetime]],
    ) -> None:
        """Populate allocation entries for alias tensors by reusing root allocations."""
        for tensor_id, _ in sorted_tensors:
            tensor = model.get_tensor(tensor_id)
            if tensor.alias_of is None:
                continue

            visited: set[TensorId] = {tensor_id}
            root_id = tensor.alias_of
            while True:
                if root_id in visited:
                    raise ValueError(
                        f"Alias cycle detected for tensor '{tensor_id}': "
                        f"visited {visited} and encountered '{root_id}' again."
                    )
                visited.add(root_id)
                try:
                    root_tensor = model.get_tensor(root_id)
                except KeyError as exc:
                    raise ValueError(
                        f"Alias target '{root_id}' referenced by tensor "
                        f"'{tensor_id}' was not found in the model."
                    ) from exc
                if root_tensor.alias_of is None:
                    break
                root_id = root_tensor.alias_of

            if root_id not in plan.tensor_allocs:
                raise ValueError(
                    f"Alias target '{root_id}' for tensor '{tensor_id}' has no allocation. "
                    f"Ensure the target tensor is referenced by at least one operator."
                )

            alias_tensor_alloc = plan.tensor_allocs[root_id]
            plan.tensor_allocs[tensor_id] = copy.deepcopy(alias_tensor_alloc)
            plan.tensor_allocs[tensor_id].tensor_id = tensor_id

    def plan(
        self,
        model: AirModel,
        memory_constraints: list[MemoryConstraint] | None = None,
        tensor_constraints: list[AttributeRuleset] | None = None,
    ) -> MemoryPlan:
        """Plan tensor memory allocation for the model.

        Every tensor is bound to an arena slot. Persistent tensors
        live in their own per-bank persistent arenas; constant tensors
        live in per-destination-memory constant arenas (cold by
        default — the arena buffer is the read-only blob in source
        memory; staged when a per-tensor
        ``constant_destination_memory`` differs from ``memory``, in
        which case the arena buffer is a writable runtime copy and a
        separate source blob lives in the source memory).

        Args:
            model (AirModel): The target model.
            memory_constraints (list[MemoryConstraint]|None): Memory
                constraints (per-platform writable budget).
            tensor_constraints (list[AttributeRuleset]|None):
                Per-tensor attribute rules (memory placement,
                ``constant_destination_memory`` override, etc.).

        Returns:
            MemoryPlan: The memory plan containing offsets and total
            size.
        """

        raise NotImplementedError("plan method should be implemented in subclasses.")
