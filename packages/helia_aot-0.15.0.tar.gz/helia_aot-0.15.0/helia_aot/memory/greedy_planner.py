"""

# GreedyMemoryPlanner API

The `GreedyMemoryPlanner` class implements a greedy algorithm for memory allocation in the context of AOT (Ahead-Of-Time) compilation for machine learning models.
It is designed to optimize memory usage by reusing gaps from tensors whose lifetimes have ended.

Classes:
    GreedyMemoryPlanner: Implements a greedy memory allocation strategy for tensors in a shared buffer.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from ..utils import setup_logger
from helia_aot.air import AirModel, TensorId
from helia_aot.platforms import SocPlatform, MemoryType
from .planner import AirMemoryPlanner, register_memory_planner
from helia_aot.attributes import AttributeRuleset
from .defines import (
    ArenaRole,
    MemoryPlan,
    TensorLifetime,
    ArenaUsage,
    TensorAllocation,
    TensorBinding,
    MemoryConstraint,
    TensorAttributes,
    MemoryActiveBlock,
    MemoryFreeBlock,
)
from .utils import compute_tensor_lifetimes, merge_free_list

logger = setup_logger(log_name=__name__)


@register_memory_planner
class GreedyMemoryPlanner(AirMemoryPlanner):
    NAME: str = "greedy"

    target: SocPlatform

    def __init__(self, target: SocPlatform):
        """Greedy memory planner for AOT models."""
        super().__init__(target=target)

    def plan(
        self,
        model: AirModel,
        memory_constraints: list[MemoryConstraint] | None = None,
        tensor_constraints: list[AttributeRuleset] | None = None,
    ) -> MemoryPlan:
        """Allocate offsets for each tensor in a shared buffer using a first-fit algorithm
        that reuses gaps from tensors whose lifetimes have ended.

        Every tensor is bound to an arena slot — there are no
        per-tensor C symbols. Three arena families are populated:

        - :attr:`MemoryPlan.arena_usages` — writable scratch arenas
          (one per writable memory bank), reused via liveness
          analysis.
        - :attr:`MemoryPlan.persistent_arenas` — writable persistent
          arenas (one per writable memory bank that received a
          persistent), bump-allocated and never reclaimed.
        - :attr:`MemoryPlan.constant_arenas` — constant arenas, keyed
          by runtime (kernel-visible) memory. Two shapes share the
          map: **cold** (``arena.source_memory == arena.memory``,
          arena buffer is the read-only blob in cold storage) and
          **staged** (``arena.source_memory != arena.memory``, arena
          buffer is a writable runtime copy hydrated from a separate
          source blob). The shape is per-arena and follows from the
          ``constant_destination_memory`` attribute on the
          constituent tensors.

        Args:
            model (AirModel): The target model.
            memory_constraints (list[MemoryConstraint]|None): Memory constraints
            tensor_constraints (list[AttributeRuleset]|None): Tensor constraints

        Returns:
            MemoryPlan: The memory plan containing tensor allocations and arena usages.
        """

        plan = MemoryPlan()

        # Track the strongest slot alignment actually used in each
        # arena across all three passes. Stamped onto the
        # corresponding ``ArenaUsage.alignment`` so the arena base
        # symbol is at least as strict as any slot inside it. Without
        # this, a tensor with ``alignment_hint=64`` packed into a
        # default 16-aligned arena would receive a 64-aligned offset
        # within the arena but the absolute address (base + offset)
        # would only be 16-aligned.
        observed_slot_alignment: dict[MemoryType, int] = {}

        memory_constraints: dict[MemoryType, MemoryConstraint] = self.fill_memory_constraints(model, memory_constraints)
        tensor_constraints: dict[TensorId, TensorAttributes] = self.fill_tensor_constraints(model, tensor_constraints)
        remaining_capacity: dict[MemoryType, int] = {
            mem_type: int(constraint.max_size or 0) for mem_type, constraint in memory_constraints.items()
        }

        tensor_lifetimes: dict[TensorId, TensorLifetime] = compute_tensor_lifetimes(model)
        self.merge_alias_lifetimes_to_fixed_point(model, tensor_lifetimes)

        plan.tensor_lifetimes = tensor_lifetimes

        # Sort tensors by the start time of their lifetime.
        sorted_tensors = sorted(tensor_lifetimes.items(), key=lambda kv: kv[1].start_op)

        # Default order of writable memories used when a tensor has no
        # per-tensor memory constraint. Materialized here because both
        # the constants pass and the scratch pass consume it.
        default_ordered_memories = [memory for memory in memory_constraints.keys() if memory.writeable]

        # Pass 1: constants — always arena-bound.
        self._plan_constants(
            model=model,
            sorted_tensors=sorted_tensors,
            memory_constraints=memory_constraints,
            tensor_constraints=tensor_constraints,
            default_ordered_memories=default_ordered_memories,
            remaining_capacity=remaining_capacity,
            plan=plan,
            observed_slot_alignment=observed_slot_alignment,
        )

        # Pass 2: persistents — bump-allocate into per-bank persistent
        # arenas. Bindings are ``arena_slot`` with
        # ``role=persistent``. Each persistent occupies a permanent
        # window in its ``persistent_arenas[mem]`` arena; the scratch
        # pass below does not see persistent bytes, so the scratch
        # arena stays purely transient and may be aliased across
        # models.
        persistent_next_offset: dict[MemoryType, int] = {}
        for tensor_id, _ in sorted_tensors:
            tensor = model.get_tensor(tensor_id)
            if tensor.alias_of or not tensor.is_persistent:
                continue
            tensor_constraint = tensor_constraints.get(tensor_id)
            if tensor_constraint is None:
                mem_types = list(default_ordered_memories)
            else:
                mem_types = [tensor_constraint.memory]

            found = False
            for mem_type in mem_types:
                if mem_type not in memory_constraints:
                    raise ValueError(
                        f"Memory type {mem_type} not found in target platform {self.target.name}"
                    )
                if not mem_type.writeable:
                    raise ValueError(
                        f"Persistent tensor {tensor_id} requested memory {mem_type} which "
                        f"is not writable on target {self.target.name}; persistent arenas "
                        f"must live in writable memory."
                    )
                alignment = max(
                    self._required_alignment(tensor),
                    self._arena_alignment(mem_type, memory_constraints),
                )
                observed_slot_alignment[mem_type] = max(
                    observed_slot_alignment.get(mem_type, 1), alignment
                )
                current = persistent_next_offset.get(mem_type, 0)
                aligned_offset = self._align_up(current, alignment)
                reserved_nbytes = (aligned_offset - current) + tensor.nbytes
                if reserved_nbytes > remaining_capacity[mem_type]:
                    continue
                plan.tensor_allocs[tensor_id] = TensorAllocation(
                    tensor_id=tensor_id,
                    memory=mem_type,
                    offset=aligned_offset,
                    size=tensor.nbytes,
                    binding=TensorBinding(
                        role=ArenaRole.persistent,
                        memory=mem_type,
                        offset=aligned_offset,
                        source_memory=mem_type,
                    ),
                )
                remaining_capacity[mem_type] -= reserved_nbytes
                persistent_next_offset[mem_type] = aligned_offset + tensor.nbytes
                found = True
                break
            if not found:
                raise ValueError(
                    f"Insufficient memory for persistent tensor {tensor_id}. Please review constraints."
                )

        for mem_type, used in persistent_next_offset.items():
            plan.persistent_arenas[mem_type] = ArenaUsage(
                memory=mem_type,
                total_size=used,
                used=used,
                role=ArenaRole.persistent,
                source_memory=mem_type,
                alignment=max(
                    self._arena_base_alignment(mem_type, memory_constraints),
                    observed_slot_alignment.get(mem_type, 1),
                ),
            )

        # Pass 3: scratch arenas — built from leftover capacity per
        # writable memory. First-fit with liveness-based reuse.
        mem_free_segments: dict[MemoryType, list[MemoryFreeBlock]] = {}  # [(offset, size)]
        mem_active_segments: dict[MemoryType, list[MemoryActiveBlock]] = {}  # [(end_time, offset, size)]
        for mem_type, constraint in memory_constraints.items():
            if not mem_type.writeable:
                continue
            arena_total = remaining_capacity[mem_type]
            plan.arena_usages[constraint.name] = ArenaUsage(
                memory=constraint.name,
                total_size=arena_total,
                used=0,
                role=ArenaRole.scratch,
                source_memory=constraint.name,
                alignment=self._arena_base_alignment(constraint.name, memory_constraints),
            )
            mem_free_segments[mem_type] = [MemoryFreeBlock(offset=0, size=arena_total)]
            mem_active_segments[mem_type] = []
        # END FOR

        for tensor_id, lifetime in sorted_tensors:
            tensor = model.get_tensor(tensor_id)

            # Skip if alias or not a scratch tensor.
            if tensor.alias_of or not tensor.is_scratch:
                continue

            # Get valid memory locations for this tensor.
            tensor_constraint = tensor_constraints.get(tensor_id)
            if tensor_constraint is None:
                mem_types = default_ordered_memories
            else:
                mem_types = [tensor_constraint.memory]

            # Free active blocks past their lifetime.
            for mem_type in mem_types:
                still_active = []
                for active_block in mem_active_segments[mem_type]:
                    if active_block.end_time < lifetime.start_op:
                        mem_free_segments[mem_type].append(
                            MemoryFreeBlock(offset=active_block.offset, size=active_block.size)
                        )
                    else:
                        still_active.append(active_block)
                mem_active_segments[mem_type] = still_active
                # Merge contiguous free blocks.
                mem_free_segments[mem_type] = merge_free_list(mem_free_segments[mem_type])
            # END FOR

            # Allocate tensor memory using the first-fit strategy.
            found = False
            for mem_type in mem_types:
                for i, free_block in enumerate(mem_free_segments[mem_type]):
                    if free_block.size >= tensor.nbytes:
                        alignment = max(
                            self._required_alignment(tensor),
                            self._arena_alignment(mem_type, memory_constraints),
                        )
                        observed_slot_alignment[mem_type] = max(
                            observed_slot_alignment.get(mem_type, 1), alignment
                        )
                        aligned_offset = self._align_up(free_block.offset, alignment)
                        padding = aligned_offset - free_block.offset
                        if tensor.nbytes + padding > free_block.size:
                            continue

                        plan.tensor_allocs[tensor_id] = TensorAllocation(
                            tensor_id=tensor_id,
                            memory=mem_type,
                            offset=aligned_offset,
                            size=tensor.nbytes,
                            binding=TensorBinding(
                                role=ArenaRole.scratch,
                                memory=mem_type,
                                offset=aligned_offset,
                                source_memory=mem_type,
                            ),
                        )
                        plan.arena_usages[mem_type].used = max(
                            plan.arena_usages[mem_type].used, aligned_offset + tensor.nbytes
                        )
                        mem_active_segments[mem_type].append(
                            MemoryActiveBlock(
                                end_time=lifetime.end_op,
                                offset=aligned_offset,
                                size=tensor.nbytes,
                            )
                        )
                        # Sort active_blocks by end time for efficient freeing.
                        mem_active_segments[mem_type].sort(key=lambda x: x.end_time)

                        # Update free blocks to account for both padding and allocation.
                        # We always pop first since we may have up to 2 free blocks from the original block.
                        # The next tensor that uses the same memory type will invoke merge_free_list() to sort and merge.
                        mem_free_segments[mem_type].pop(i)
                        leading_size = padding
                        trailing_offset = aligned_offset + tensor.nbytes
                        trailing_size = (free_block.offset + free_block.size) - trailing_offset
                        if leading_size > 0:
                            mem_free_segments[mem_type].append(
                                MemoryFreeBlock(offset=free_block.offset, size=leading_size)
                            )
                        if trailing_size > 0:
                            mem_free_segments[mem_type].append(
                                MemoryFreeBlock(offset=trailing_offset, size=trailing_size)
                            )

                        found = True
                        break
                    # END IF
                # END FOR
                if found:
                    break
            # END FOR

            # No suitable free block found.
            if not found:
                raise ValueError(f"Insufficient memory for scratch tensor {tensor_id}. Please review constraints.")
        # END FOR

        # Bump scratch arena base alignment to dominate the strongest
        # slot alignment observed in the pass, so the absolute address
        # ``base + offset`` honors per-slot ``alignment_hint`` even
        # when the hint exceeds the historical 16-byte floor.
        for mem_type, arena in plan.arena_usages.items():
            observed = observed_slot_alignment.get(mem_type)
            if observed is not None and observed > arena.alignment:
                arena.alignment = observed

        self.populate_alias_allocations(model, plan, sorted_tensors)

        # Remove any empty arenas.
        for mem_type in list(plan.arena_usages.keys()):
            if plan.arena_usages[mem_type].used == 0:
                del plan.arena_usages[mem_type]

        logger.debug("Memory allocation:")
        for tensor_id, allocation in plan.tensor_allocs.items():
            logger.debug(
                f"  • Tensor {tensor_id}: {allocation.memory}[{allocation.offset}:{allocation.offset + allocation.size}]"
            )

        return plan

    def _plan_constants(
        self,
        *,
        model: AirModel,
        sorted_tensors: list,
        memory_constraints: dict,
        tensor_constraints: dict,
        default_ordered_memories: list[MemoryType],
        remaining_capacity: dict,
        plan: MemoryPlan,
        observed_slot_alignment: dict[MemoryType, int],
    ) -> None:
        """Allocate every constant tensor into a constant arena.

        Each constant lands in :attr:`MemoryPlan.constant_arenas`
        keyed by its **runtime** (kernel-visible) memory. Two arena
        shapes are produced from the same code path, distinguished
        only by whether the arena's ``source_memory`` matches its
        ``memory``:

        - **Cold** (default — runtime memory equals source memory):
          the arena buffer is the read-only blob in cold storage and
          kernels read it in place. Capacity is charged once to the
          shared (source == runtime) memory.
        - **Staged** (runtime memory differs from source memory, set
          via per-tensor ``constant_destination_memory``): the arena
          buffer is a writable runtime copy and a separate source
          blob lives in the source memory. Both are charged.

        Per-arena single-source-memory is a hard invariant — every
        constant placed into the same runtime memory must agree on
        ``source_memory`` so the arena can be hydrated by a single
        bulk transfer (relevant only when staged; vacuous when cold
        because source and runtime coincide).

        Source-blob bytes are emitted in arena-allocation order with
        the same per-element alignment padding as the destination
        layout, so source/destination relative offsets coincide and
        a single ``memcpy``/DMA suffices to populate the destination
        arena.
        """
        if not memory_constraints:
            for tensor_id, _ in sorted_tensors:
                tensor = model.get_tensor(tensor_id)
                if tensor.is_constant and not tensor.alias_of:
                    raise ValueError(
                        f"Cannot place constant tensor {tensor_id}: target platform "
                        f"{self.target.name} has no usable memories."
                    )
            return

        # High-water mark per runtime arena.
        mem_next_offset_const: dict[MemoryType, int] = {}
        # Per-runtime-arena single-source-memory invariant. The first
        # constant landing in a given runtime memory establishes the
        # source memory for the whole arena; subsequent constants
        # destined for the same runtime memory must share it.
        arena_source_memory: dict[MemoryType, MemoryType] = {}
        # First tensor that locked the source memory for each runtime
        # arena. Used purely for error attribution so the offending
        # rule can be traced back to the YAML author.
        arena_lock_origin: dict[MemoryType, TensorId] = {}

        # Pre-plan validator: aggregate every staged routing decision
        # by destination arena and surface *all* single-source-memory
        # conflicts in a single diagnostic, instead of failing on the
        # first one we hit during allocation.
        self._validate_constants_invariants(
            model=model,
            sorted_tensors=sorted_tensors,
            tensor_constraints=tensor_constraints,
            memory_constraints=memory_constraints,
        )

        for tensor_id, _ in sorted_tensors:
            tensor = model.get_tensor(tensor_id)
            if tensor.alias_of or not tensor.is_constant:
                continue

            tensor_constraint = tensor_constraints.get(tensor_id)
            dest_override = (
                tensor_constraint.constant_destination_memory
                if tensor_constraint is not None
                else None
            )

            # Normalize: an explicit destination equal to the
            # tensor's own source memory is semantically cold (no
            # staging, no hydration), even though the user spelled
            # it out. The ``is_staged`` predicate on ArenaUsage is
            # ``source_memory != memory``, so routing such a tensor
            # through the staged branch would (a) misclassify the
            # arena and (b) spuriously reject non-writable source
            # memories that are perfectly valid cold-read targets.
            if (
                dest_override is not None
                and tensor_constraint is not None
                and dest_override == tensor_constraint.memory
            ):
                dest_override = None

            if dest_override is not None:
                # Explicit staged routing. Destination is the runtime
                # memory the kernel reads from at inference; it must
                # be writable since the arena buffer is a runtime
                # mutable copy.
                if dest_override not in memory_constraints:
                    raise ValueError(
                        f"constant_destination_memory={dest_override} for "
                        f"tensor {tensor_id} is not a memory of the target "
                        f"platform {self.target.name}."
                    )
                if not dest_override.writeable:
                    raise ValueError(
                        f"constant_destination_memory={dest_override} for "
                        f"tensor {tensor_id} is not writable; staged "
                        f"destinations must be writable memories."
                    )
                runtime_mem = dest_override
                if tensor_constraint is None:
                    source_mem_candidates = list(memory_constraints.keys())
                else:
                    source_mem_candidates = [tensor_constraint.memory]
            else:
                # Cold path: runtime memory equals source memory. The
                # arena buffer is the cold blob itself; no hydration
                # is required. The first writable (or any) memory is
                # used as a fallback when no per-tensor ``memory:``
                # rule applies.
                if tensor_constraint is None:
                    source_mem_candidates = list(memory_constraints.keys())
                else:
                    source_mem_candidates = [tensor_constraint.memory]
                runtime_mem = None  # decided per-candidate below

            # If a runtime memory is already locked, enforce single-
            # source-memory across the arena.
            if runtime_mem is not None:
                locked_source = arena_source_memory.get(runtime_mem)
                if locked_source is not None:
                    if locked_source not in source_mem_candidates:
                        origin = arena_lock_origin.get(runtime_mem, "<unknown>")
                        raise ValueError(
                            f"Per-arena single-source-memory invariant violated for "
                            f"constant arena runtime memory {runtime_mem.name}:\n"
                            f"  - tensor {origin!s} locked source memory to "
                            f"{locked_source.name} (placed first into this arena)\n"
                            f"  - tensor {tensor_id!s} requires source memory in "
                            f"{[m.name for m in source_mem_candidates]} "
                            f"(via constant_destination_memory={runtime_mem.name})\n"
                            f"Resolve by either (a) routing one of these tensors to a "
                            f"different runtime destination memory, or (b) aligning their "
                            f"source `memory:` rule to {locked_source.name}."
                        )
                    source_mem_candidates = [locked_source]

            base_alignment = self._required_alignment(tensor)

            # Pick a (source_mem, runtime_mem) pair that fits.
            # For cold (dest_override is None), runtime_mem == source_mem and we
            # iterate candidates. For staged, runtime_mem is fixed.
            chosen_source: MemoryType | None = None
            chosen_runtime: MemoryType | None = None
            chosen_aligned_offset = 0
            chosen_reserved = 0
            # Track why each candidate was rejected so the final
            # diagnostic can name a concrete cause instead of the
            # generic "insufficient memory" fallback.
            skip_reasons: list[str] = []
            for candidate in source_mem_candidates:
                if candidate not in memory_constraints:
                    raise ValueError(
                        f"Memory type {candidate} not found in target platform {self.target.name}"
                    )
                effective_runtime = runtime_mem if runtime_mem is not None else candidate
                # When cold, runtime arena must agree with the per-arena
                # single-source-memory invariant established by an earlier
                # tensor (vacuous on the first tensor).
                locked = arena_source_memory.get(effective_runtime)
                if locked is not None and locked != candidate:
                    origin = arena_lock_origin.get(effective_runtime, "<unknown>")
                    skip_reasons.append(
                        f"  - candidate source={candidate.name} into runtime="
                        f"{effective_runtime.name}: arena already locked to "
                        f"source={locked.name} by tensor {origin!s}"
                    )
                    continue
                # The arena_alignment floor applies to every slot in every
                # arena -- scratch, persistent, and constant alike. The floor
                # comes from the runtime (destination) arena because that is
                # the memory the application actually allocates / DMAs into.
                alignment = max(
                    base_alignment,
                    self._arena_alignment(effective_runtime, memory_constraints),
                )
                current = mem_next_offset_const.get(effective_runtime, 0)
                aligned_offset = self._align_up(current, alignment)
                padding = aligned_offset - current
                reserved = padding + tensor.nbytes
                # Cold: charge once (source == runtime). Staged:
                # charge both source and runtime symmetrically.
                if candidate == effective_runtime:
                    if remaining_capacity[candidate] < reserved:
                        skip_reasons.append(
                            f"  - candidate {candidate.name}: needs "
                            f"{reserved} bytes (incl. {padding} padding for "
                            f"alignment={alignment}), only "
                            f"{remaining_capacity[candidate]} remaining"
                        )
                        continue
                else:
                    if remaining_capacity[candidate] < reserved:
                        skip_reasons.append(
                            f"  - candidate source={candidate.name}: needs "
                            f"{reserved} bytes for source copy, only "
                            f"{remaining_capacity[candidate]} remaining"
                        )
                        continue
                    if remaining_capacity[effective_runtime] < reserved:
                        skip_reasons.append(
                            f"  - candidate runtime={effective_runtime.name}: "
                            f"needs {reserved} bytes (incl. {padding} padding "
                            f"for alignment={alignment}), only "
                            f"{remaining_capacity[effective_runtime]} remaining"
                        )
                        continue
                chosen_source = candidate
                chosen_runtime = effective_runtime
                chosen_aligned_offset = aligned_offset
                chosen_reserved = reserved
                # Record the slot alignment actually used so the
                # arena base symbol can be stamped at least as strict.
                observed_slot_alignment[effective_runtime] = max(
                    observed_slot_alignment.get(effective_runtime, 1), alignment
                )
                break

            if chosen_source is None:
                detail = (
                    "\n".join(skip_reasons)
                    if skip_reasons
                    else "  (no candidate source memories were considered)"
                )
                raise ValueError(
                    f"Insufficient memory for constant tensor {tensor_id} "
                    f"({tensor.nbytes} bytes). Rejected candidates:\n{detail}\n"
                    f"Review memory.constraints (max_size, arena_alignment) "
                    f"and memory.tensors routing for this tensor."
                )

            # Charge capacities and update arena state.
            if chosen_source == chosen_runtime:
                remaining_capacity[chosen_source] -= chosen_reserved
            else:
                remaining_capacity[chosen_source] -= chosen_reserved
                remaining_capacity[chosen_runtime] -= chosen_reserved
            mem_next_offset_const[chosen_runtime] = chosen_aligned_offset + tensor.nbytes
            arena_source_memory.setdefault(chosen_runtime, chosen_source)
            arena_lock_origin.setdefault(chosen_runtime, tensor_id)

            plan.tensor_allocs[tensor_id] = TensorAllocation(
                tensor_id=tensor_id,
                memory=chosen_runtime,
                offset=chosen_aligned_offset,
                size=tensor.nbytes,
                binding=TensorBinding(
                    role=ArenaRole.constant,
                    memory=chosen_runtime,
                    offset=chosen_aligned_offset,
                    source_memory=chosen_source,
                ),
            )

        # Materialize one ArenaUsage per runtime memory that received
        # any constant. Bump-allocated, never reclaimed.
        for runtime_mem, used in mem_next_offset_const.items():
            plan.constant_arenas[runtime_mem] = ArenaUsage(
                memory=runtime_mem,
                total_size=used,
                used=used,
                role=ArenaRole.constant,
                source_memory=arena_source_memory[runtime_mem],
                alignment=max(
                    self._arena_base_alignment(runtime_mem, memory_constraints),
                    observed_slot_alignment.get(runtime_mem, 1),
                ),
            )

    def _validate_constants_invariants(
        self,
        *,
        model: AirModel,
        sorted_tensors: list,
        tensor_constraints: dict,
        memory_constraints: dict,
    ) -> None:
        """Validate per-arena single-source-memory ahead of allocation.

        Walks every constant tensor's resolved attributes and groups
        the staged routing decisions by destination (runtime) memory.
        If any destination receives constants from more than one
        source memory, raises a single :class:`ValueError` listing
        every contributing tensor so the YAML author can correct all
        offending rules in one round-trip rather than fixing them
        one error at a time.

        Cold tensors (no ``constant_destination_memory``) are not
        considered here: their runtime memory equals their source
        memory by definition, and the per-source-memory ambiguity
        between several writable candidates is resolved by the
        bin-packing pass below, not by validation.

        Args:
            model: Air model with constant tensors to validate.
            sorted_tensors: ``[(tensor_id, lifetime), ...]`` already
                ordered by lifetime start, as produced by ``plan``.
            tensor_constraints: Resolved per-tensor attribute map.
            memory_constraints: Per-platform memory map; used to
                reject ``constant_destination_memory`` values that
                are not present on the target.
        """
        # destination_memory -> { source_memory -> [tensor_id, ...] }
        staged_groups: dict[MemoryType, dict[MemoryType, list[TensorId]]] = {}
        for tensor_id, _ in sorted_tensors:
            tensor = model.get_tensor(tensor_id)
            if tensor.alias_of or not tensor.is_constant:
                continue
            tc = tensor_constraints.get(tensor_id)
            if tc is None or tc.constant_destination_memory is None:
                continue
            dest = tc.constant_destination_memory
            # ``destination == source`` is semantically cold: no
            # staging, no hydration, source memory equals runtime
            # memory. Skip the staged validation rules so a verbose
            # author can spell out their (no-op) destination without
            # being rejected for naming a non-writable memory.
            if dest == tc.memory:
                continue
            if dest not in memory_constraints:
                raise ValueError(
                    f"constant_destination_memory={dest.name} for tensor "
                    f"{tensor_id} is not a memory of target platform "
                    f"{self.target.name}."
                )
            if not dest.writeable:
                raise ValueError(
                    f"constant_destination_memory={dest.name} for tensor "
                    f"{tensor_id} is not writable; staged destinations must "
                    f"be writable memories."
                )
            staged_groups.setdefault(dest, {}).setdefault(tc.memory, []).append(tensor_id)

        conflicts: list[str] = []
        for dest, by_source in staged_groups.items():
            if len(by_source) <= 1:
                continue
            lines = [
                f"  destination memory {dest.name} receives constants from "
                f"{len(by_source)} different source memories:"
            ]
            for src, ids in by_source.items():
                lines.append(f"    • source {src.name}: {', '.join(str(i) for i in ids)}")
            conflicts.append("\n".join(lines))

        if conflicts:
            raise ValueError(
                "Per-arena single-source-memory invariant violated for one "
                "or more constant arenas. Each runtime destination memory "
                "must be hydrated from a single source memory so the arena "
                "can be populated by one bulk transfer. Offending groups:\n"
                + "\n".join(conflicts)
                + "\nResolve by either (a) routing the conflicting tensors "
                "to different ``constant_destination_memory`` destinations, "
                "or (b) aligning their source ``memory:`` rule on a single "
                "common memory."
            )
