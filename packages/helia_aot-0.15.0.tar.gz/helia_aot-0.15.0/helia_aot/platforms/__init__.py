"""

# :material-chip: Platforms API

This module is responsible for providing capabilities and memory info for Ambiq SoC platforms

Copyright 2025 Ambiq. All Rights Reserved.

"""

from .defines import SocCapability, MemoryType, SocPlatform
from .platforms import PLATFORM_REGISTRY, register_platform, get_platform, resolve_platform
