from types import MappingProxyType
from .defines import SocCapability, MemoryType, SocPlatform

# internal mutable registry
_PLATFORM_REGISTRY: dict[str, SocPlatform] = {}


def register_platform(p: SocPlatform) -> SocPlatform:
    """Register a platform in the registry."""
    if p.name in _PLATFORM_REGISTRY:
        raise KeyError(f"Platform {p.name!r} already registered")
    _PLATFORM_REGISTRY[p.name] = p
    return p


def get_platform(name: str) -> SocPlatform:
    """Get a platform by its name."""
    if name not in _PLATFORM_REGISTRY:
        raise ValueError(f"Platform '{name}' not found.")
    return _PLATFORM_REGISTRY[name]


def resolve_platform(platform_cfg) -> SocPlatform:
    """Resolve a platform from the registry or register a custom one on the fly."""

    try:
        return get_platform(platform_cfg.name)
    except ValueError:
        pass

    missing: list[str] = []

    # Treat None / empty containers as "missing" for custom platforms
    if platform_cfg.cpu is None:
        missing.append("cpu")
    if not platform_cfg.speeds:
        missing.append("speeds")
    if not platform_cfg.memories:
        missing.append("memories")
    if not platform_cfg.preferred_memory_order:
        missing.append("preferred_memory_order")
    if platform_cfg.min_alignment is None:
        missing.append("min_alignment")

    if missing:
        missing_str = ", ".join(f"platform.{f}" for f in missing)
        raise ValueError(
            f"Unknown platform '{platform_cfg.name}'. Provide {missing_str} to register a custom platform."
        )

    platform = SocPlatform(
        name=platform_cfg.name,
        cpu=platform_cfg.cpu,
        speeds=platform_cfg.speeds,
        memories=platform_cfg.memories,
        capabilities=platform_cfg.capabilities,
        preferred_memory_order=platform_cfg.preferred_memory_order,
        min_alignment=platform_cfg.min_alignment,
    )

    return register_platform(platform)


# read-only view for introspection
PLATFORM_REGISTRY = MappingProxyType(_PLATFORM_REGISTRY)

################################################################################
# Apollo3 Series
# NOTE:
# - SRAM below is MAIN SRAM only (excludes DTCM)
# - DTCM is modeled separately for placement/perf control
################################################################################

apollo3_evb = register_platform(
    SocPlatform(
        name="apollo3_evb",
        cpu="cortex-m4",
        speeds=[48, 96],
        memories={
            MemoryType.MRAM: 1024 * 1024,
            MemoryType.SRAM: 320 * 1024,   # main SRAM only
            MemoryType.DTCM: 64 * 1024,
        },
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.MCU, SocCapability.DSP],
        min_alignment=4,
    )
)

apollo3_blue_evb = register_platform(
    SocPlatform(
        name="apollo3_blue_evb",
        cpu="cortex-m4",
        speeds=[48, 96],
        memories={
            MemoryType.MRAM: 1024 * 1024,
            MemoryType.SRAM: 320 * 1024,   # main SRAM only
            MemoryType.DTCM: 64 * 1024,
        },
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.BLE, SocCapability.MCU, SocCapability.DSP],
        min_alignment=4,
    )
)

apollo3_blue_thin_evb = register_platform(
    SocPlatform(
        name="apollo3_blue_thin_evb",
        cpu="cortex-m4",
        speeds=[48, 96],
        memories={
            MemoryType.MRAM: 1024 * 1024,
            MemoryType.SRAM: 320 * 1024,   # main SRAM only
            MemoryType.DTCM: 64 * 1024,
        },
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.BLE, SocCapability.MCU, SocCapability.DSP],
        min_alignment=4,
    )
)

apollo3_blue_plus_evb = register_platform(
    SocPlatform(
        name="apollo3_blue_plus_evb",
        cpu="cortex-m4",
        speeds=[48, 96],
        memories={
            MemoryType.MRAM: 2048 * 1024,
            MemoryType.SRAM: 704 * 1024,   # main SRAM only
            MemoryType.DTCM: 64 * 1024,
        },
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.BLE, SocCapability.MCU, SocCapability.DSP],
        min_alignment=4,
    )
)

# Optional compatibility alias if existing flows use apollo3p_evb naming.
apollo3p_evb = register_platform(
    SocPlatform(
        name="apollo3p_evb",
        cpu="cortex-m4",
        speeds=[48, 96],
        memories={
            MemoryType.MRAM: 2048 * 1024,
            MemoryType.SRAM: 704 * 1024,   # main SRAM only
            MemoryType.DTCM: 64 * 1024,
        },
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.BLE, SocCapability.MCU, SocCapability.DSP],
        min_alignment=4,
    )
)


################################################################################
# Apollo4 Series
################################################################################

apollo4p_evb = register_platform(
    SocPlatform(
        name="apollo4p_evb",
        cpu="cortex-m4",
        speeds=[96, 192],
        memories={MemoryType.MRAM: 2000 * 1024, MemoryType.SRAM: 1024 * 1024, MemoryType.DTCM: 384 * 1024},
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.MCU, SocCapability.USB, SocCapability.DSP],
        min_alignment=4,
    )
)

apollo4p_blue_kbr_evb = register_platform(
    SocPlatform(
        name="apollo4p_blue_kbr_evb",
        cpu="cortex-m4",
        speeds=[96, 192],
        memories={MemoryType.MRAM: 2000 * 1024, MemoryType.SRAM: 1024 * 1024, MemoryType.DTCM: 384 * 1024},
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.MCU, SocCapability.USB, SocCapability.BLE, SocCapability.DSP],
        min_alignment=4,
    )
)

apollo4p_blue_kxr_evb = register_platform(
    SocPlatform(
        name="apollo4p_blue_kxr_evb",
        cpu="cortex-m4",
        speeds=[96, 192],
        memories={MemoryType.MRAM: 2000 * 1024, MemoryType.SRAM: 1024 * 1024, MemoryType.DTCM: 384 * 1024},
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.MCU, SocCapability.USB, SocCapability.BLE, SocCapability.DSP],
        min_alignment=4,
    )
)

apollo4l_evb = register_platform(
    SocPlatform(
        name="apollo4l_evb",
        cpu="cortex-m4",
        speeds=[96, 192],
        memories={MemoryType.MRAM: 2000 * 1024, MemoryType.SRAM: 1024 * 1024, MemoryType.DTCM: 384 * 1024},
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.MCU, SocCapability.DSP],
        min_alignment=4,
    )
)

apollo4l_blue_evb = register_platform(
    SocPlatform(
        name="apollo4l_blue_evb",
        cpu="cortex-m4",
        speeds=[96, 192],
        memories={MemoryType.MRAM: 2000 * 1024, MemoryType.SRAM: 1024 * 1024, MemoryType.DTCM: 384 * 1024},
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM],
        capabilities=[SocCapability.MCU, SocCapability.BLE, SocCapability.DSP],
        min_alignment=4,
    )
)

################################################################################
# Apollo510 Series
################################################################################

apollo510_eb = register_platform(
    SocPlatform(
        name="apollo510_eb",
        cpu="cortex-m55",
        speeds=[96, 250],
        memories={
            MemoryType.MRAM: 4096 * 1024,
            MemoryType.SRAM: 3072 * 1024,
            MemoryType.DTCM: 512 * 1024,
            MemoryType.ITCM: 256 * 1024,
            MemoryType.PSRAM: 32168 * 1024,
        },
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM, MemoryType.PSRAM],
        capabilities=[SocCapability.MCU, SocCapability.USB, SocCapability.PSRAM, SocCapability.DSP, SocCapability.MVE],
        min_alignment=16,
    )
)

apollo510_evb = register_platform(
    SocPlatform(
        name="apollo510_evb",
        cpu="cortex-m55",
        speeds=[96, 250],
        memories={
            MemoryType.MRAM: 4096 * 1024,
            MemoryType.SRAM: 3072 * 1024,
            MemoryType.DTCM: 512 * 1024,
            MemoryType.ITCM: 256 * 1024,
            MemoryType.PSRAM: 32168 * 1024,
        },
        preferred_memory_order=[MemoryType.DTCM, MemoryType.SRAM, MemoryType.MRAM, MemoryType.PSRAM],
        capabilities=[SocCapability.MCU, SocCapability.USB, SocCapability.PSRAM, SocCapability.DSP, SocCapability.MVE],
        min_alignment=16,
    )
)
