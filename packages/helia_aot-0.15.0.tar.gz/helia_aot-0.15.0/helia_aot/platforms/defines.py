from enum import auto
from pydantic.dataclasses import dataclass
from pydantic import Field, field_validator
from helia_aot.defines import AnyCaseStrEnum


class SocCapability(AnyCaseStrEnum):
    """SoC available capabilities"""

    MCU = auto()
    DSP = auto()
    USB = auto()
    BLE = auto()
    MVE = auto()
    PSRAM = auto()


class MemoryType(AnyCaseStrEnum):
    """SoC available memory types"""

    MRAM = auto()
    SRAM = auto()
    DTCM = auto()
    ITCM = auto()
    PSRAM = auto()

    @property
    def readable(self) -> bool:
        """Check if this memory type is readable."""
        return True

    @property
    def writeable(self) -> bool:
        """Check if this memory type is writeable."""
        return self in (MemoryType.SRAM, MemoryType.DTCM, MemoryType.ITCM, MemoryType.PSRAM)

    @property
    def executable(self) -> bool:
        """Check if this memory type is executable."""
        return self in (MemoryType.ITCM, MemoryType.MRAM)

    @property
    def is_init_ram(self) -> bool:
        """Whether the ``_INIT`` placement for this memory targets loadable RAM.

        Memories whose ``*_INIT`` linker macro places symbols into
        loadable RAM (i.e. the section is writable at the linker
        level, with bytes copied from a load region at boot) cannot
        be declared ``const`` at the C type level — GNU ld will
        otherwise infer a read-only section group, refuse to merge
        with the writable RAM section, and orphan the symbol into an
        unrelated output section.

        Returns:
            bool: ``True`` for RAM-class memories (DTCM, SRAM, ITCM,
            PSRAM); ``False`` for flash-class memories (MRAM) whose
            init section is genuinely read-only and accepts ``const``.
        """
        return self in (MemoryType.SRAM, MemoryType.DTCM, MemoryType.ITCM, MemoryType.PSRAM)

    def init_const_qualifier(self) -> str:
        """C ``const`` prefix appropriate for an ``_INIT`` blob in this memory.

        Returns ``"const "`` for memories whose init section is
        read-only at link time (flash/XIP), and ``""`` for memories
        whose init section is loadable RAM (where ``const`` would
        cause a section-flag conflict — see :attr:`is_init_ram`).

        Returns:
            str: Either ``"const "`` or the empty string. Suitable
            for direct interpolation in templates.
        """
        return "" if self.is_init_ram else "const "

    def to_qualifiers(self, prefix: str = "AOT", init: bool = False, writable: bool = True) -> str:
        """Convert memory placement to C qualifiers

        Args:
            prefix (str): Prefix for the qualifier macro
            init (bool): For pre-initialized data (aka .data) vs zeroed (.bss)
            writable (bool): Whether the data will be written to at runtime

        Returns:
            str: C qualifier macro (e.g., AOT_PUT_IN_SRAM_INIT)
        """
        if writable and not self.writeable:
            raise ValueError(f"Memory type {self} is not writeable, cannot use as writable.")
        prefix = f"{prefix.upper()}_"
        suffix = "_INIT" if init else ""
        location = f"PUT_IN_{self.name}"
        qualifier = f"{prefix}{location}{suffix}"
        return qualifier


@dataclass(frozen=True)
class SocPlatform:
    """Base class for SoC platforms

    Attributes:
        name (str): Unique platform name
        speeds (list[int]): List of supported clock speeds in MHz
        memories (dict[MemoryType, int]): Memory sizes in bytes
        capabilities (list[SocCapability]): List of SoC capabilities
        preferred_memory_order (list[MemoryType]): Preferred memory order for allocations
        min_alignment (int | None): Minimum alignment requirement in bytes
    """

    name: str = Field(..., description="Unique platform name")
    cpu: str = Field(default="cortex-m4", description="CPU architecture")
    speeds: list[int] = Field(default_factory=list, description="List of supported clock speeds in MHz")
    memories: dict[MemoryType, int] = Field(default_factory=dict, description="Memory sizes in bytes")
    capabilities: list[SocCapability] = Field(default_factory=list, description="List of SoC capabilities")
    preferred_memory_order: list[MemoryType] = Field(
        default_factory=list, description="Preferred memory order for allocations"
    )
    min_alignment: int = Field(..., description="Minimum alignment requirement in bytes")

    @field_validator("min_alignment")
    @classmethod
    def _validate_min_alignment_pow2(cls, value: int) -> int:
        """Reject non-positive or non-power-of-two ``min_alignment``.

        The generated ``<prefix>_bind_arena`` validates caller-supplied
        buffer alignment with a bitmask test
        ``(uintptr_t)buf & (align - 1)``, which is only correct when
        ``align`` is a power of two. A value such as ``24`` would pass
        on accidentally-aligned buffers and silently misclassify
        otherwise. Enforce the invariant at config load so the failure
        mode is a clear ``ValueError`` instead of a runtime alignment
        miscompile.
        """
        if value <= 0:
            raise ValueError(
                f"SocPlatform.min_alignment must be a positive power of two, got {value}"
            )
        if value & (value - 1):
            raise ValueError(
                f"SocPlatform.min_alignment must be a power of two, got {value}"
            )
        return value
