"""

# :material-code-braces: heliaAOT CLI API

The `cli` module provides a command line interface (CLI) for the heliaAOT library.
The CLI allows users to convert a model into a highly optimized, ahead-of-time (AOT) module for Ambiq's ultra-low-power SoCs.
Both command line arguments and YAML configuration file can be suppled, in which case the command line arguments will override the YAML configuration.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from argdantic import ArgParser

from ..utils import setup_logger, get_version
from .defines import ConvertArgs
from ..converter import AotConverter
from ..registry.context import build_default_registry_context


parser = ArgParser(force_group=True)


@parser.command(name="version", help="Display the version of the heliaAOT library.")
def version():
    """Display the version of the heliaAOT library."""
    logger = setup_logger(__name__, level=1)
    logger.info("[bold]heliaAOT version:[/] %s", get_version())


@parser.command(name="convert", singleton=True, help="Convert a model to standalone C inference module.")
def convert(args: ConvertArgs):
    """
    Convert a model to standalone C inference module.

    Args:
        args (ConvertArgs): Arguments for conversion.

    """
    logger = setup_logger(__name__, level=args.verbose, file_path=args.log_file)
    logger.info("[bold]Started AOT conversion[/]")
    registry_context = build_default_registry_context()
    converter = AotConverter(config=args, registry_context=registry_context)
    converter.convert()
    logger.info("[bold]AOT conversion completed[/]")


def run():
    """Main function to run the CLI."""
    parser()


if __name__ == "__main__":
    run()
