import tempfile
from typing import Annotated, ClassVar
from pathlib import Path
from pydantic import BaseModel, Field, StringConstraints, field_validator, model_validator
from argdantic.sources import YamlFileLoader, from_file

from helia_aot.attributes.attributes import AttributeRuleset
from helia_aot.memory import MemoryPlannerType, MemoryConstraint
from helia_aot.transforms import TransformSpec
from helia_aot.defines import ModuleType
from helia_aot.platforms.defines import MemoryType, SocCapability

ValidCVarNameType = Annotated[str, StringConstraints(pattern=r"^[A-Za-z_][A-Za-z0-9_]*$")]
ValidModuleNameType = Annotated[str, StringConstraints(pattern=r"^[A-Za-z_][A-Za-z0-9_-]*$")]  # with dashes


class ModelArgs(BaseModel):
    """Model configuration for the conversion process.

    Attributes:
        path (Path): Path to the model file.
        subgraph (int): Subgraph index to process.
        type (str|None): Type of the model (e.g., tflite, litert)
        name (str): Name of the model.
        description (str|None): Optional description of the model.
        version (str|None): Version of the model.
    """

    path: Path = Field("model.tflite", description="Path to target model file")
    subgraph: int = Field(0, ge=0, description="Subgraph index")
    type: str | None = Field(None, description="Model type (e.g., tflite, litert)")
    name: str = Field("model", description="Model name")
    description: str | None = Field(None, description="Description of the model")
    version: str | None = Field("v1.0.0", description="Model version")


class ModuleArgs(BaseModel):
    """Module configuration for the conversion process.

    Attributes:
        path (Path): Base path for output module. Can also be a zip file. Defaults to "output.zip".
        type (ModuleType): Type of the module (e.g., neuralspot, zephyr, cmake, nsx). Defaults to neuralspot.
        name (ValidModuleNameType): Name of the module. Defaults to "helia_aot_nn".
        prefix (ValidCVarNameType): Prefix added to sources for unique namespace. Defaults to "aot".
    """

    path: Path = Field(
        ...,
        description="Base path for output module. Can also be a zip file.",
        default_factory=lambda: Path("output.zip"),
    )
    type: ModuleType = Field(default=ModuleType.neuralspot, description="Module type")
    name: ValidModuleNameType = Field(default="helia_aot_nn", description="Module name")
    prefix: ValidCVarNameType = Field(default="aot", description="Prefix added to sources for unique namespace")


class TestArgs(BaseModel):
    """Test configuration for the conversion process.

    Attributes:
        enabled (bool): Include test case. Defaults to False.
        tolerance (float|int): Test tolerance. Defaults to 1.0.
        skip_verification (bool): Skip runtime output verification.
        golden_data (Path|None): Optional path to golden input/output npz file.
        num_iterations (int): Number of times to run the same stimulus through the model. Defaults to 1.
    """

    enabled: bool = Field(False, description="Include test case")
    tolerance: float | int = Field(1.0, description="Test tolerance")
    skip_verification: bool = Field(False, description="Skip runtime output verification")
    golden_data: Path | None = Field(None, description="Golden input/output npz file")
    num_iterations: int = Field(1, description="Number of times to run the same stimulus through the model")


class MemoryArgs(BaseModel):
    """Memory configuration for the conversion process.

    Attributes:
        planner (MemoryPlannerType): Memory planner strategy. Defaults to greedy.
        constraints (list[MemoryConstraint]|None): Memory constraints (ordered by preference). Defaults to None.
        tensors (list[AttributeRuleset]): Per-tensor attribute rulesets.
        allocate_arenas (bool): If true, generated module declares its own arena buffers.
        auto_hydrate_constants (bool): **Deprecated** — retained for
            backwards compatibility but no longer changes generated
            runtime behavior. ``<prefix>_model_init`` always invokes
            ``<prefix>_hydrate_constants`` between
            ``<prefix>_context_init`` and the operator init loop, so
            kernels that read constants in their ``_init`` hook always
            observe hydrated arenas. Override the weak
            ``<prefix>_hydrate_constants`` symbol for DMA / async
            pre-stage / model-swap behavior; ``model_init`` calls the
            override at the same fixed point.
    """

    planner: MemoryPlannerType = Field(default=MemoryPlannerType.greedy, description="Memory planner strategy")
    constraints: list[MemoryConstraint] | None = Field(None, description="Memory constraints (ordered by preference)")
    tensors: list[AttributeRuleset] = Field(..., description="Tensor attributes", default_factory=list)
    allocate_arenas: bool = Field(
        True,
        description=(
            "If true, the module will use internal, statically allocated arenas. "
            "If false, the caller must bind every region via "
            "<prefix>_bind_arena() / <prefix>_bind_arenas() before model_init."
        ),
    )
    auto_hydrate_constants: bool = Field(
        True,
        description=(
            "Deprecated — retained for backwards compatibility but no longer "
            "changes generated runtime behavior. model_init always invokes "
            "hydrate_constants between context_init and the operator init "
            "loop. Override the weak hydrate_constants symbol for custom "
            "hydration mechanisms (DMA / async pre-stage / model swap)."
        ),
    )
    dump_residency_json: bool = Field(
        False,
        description=(
            "If true, write a machine-readable residency report "
            "(``<prefix>_residency.json``) alongside the emitted module. "
            "Mirrors the verbose log summary as JSON for tooling that "
            "needs to introspect arena layout, staged-vs-cold residency, "
            "and per-tensor placement post-planning."
        ),
    )

    # Removed YAML keys → actionable migration error. The
    # tensor-packaging branch dropped the standalone
    # ``persistent_storage`` and ``constant_residency`` blocks in
    # favor of unified per-tensor ``memory`` /
    # ``constant_destination_memory`` rules under
    # ``memory.tensors``. The top-level ``ConvertArgs`` model is
    # ``extra="allow"``, so without this validator stale keys would
    # load silently with the new defaults.
    _REMOVED_KEYS: ClassVar[dict[str, str]] = {
        "persistent_storage": (
            "Use a per-tensor rule under `memory.tensors` instead, e.g. "
            "`- type: persistent\\n  memory: <MEMORY>` to pin all "
            "persistents to a specific memory."
        ),
        "constant_residency": (
            "Use per-tensor rules under `memory.tensors` with `memory:` "
            "(source) and optional `constant_destination_memory:` "
            "(staged runtime memory) to express constant placement."
        ),
    }

    @model_validator(mode="before")
    @classmethod
    def _reject_removed_keys(cls, data: object) -> object:
        if not isinstance(data, dict):
            return data
        offenders = [k for k in cls._REMOVED_KEYS if k in data]
        if not offenders:
            return data
        lines = [
            f"  - `memory.{k}`: {cls._REMOVED_KEYS[k]}" for k in offenders
        ]
        raise ValueError(
            "The following memory keys were removed in the tensor-"
            "packaging refactor and are no longer supported:\n"
            + "\n".join(lines)
            + "\nSee docs/how-to/tensor-packaging.md for the migration."
        )


class PlatformArgs(BaseModel):
    """Platform configuration for the conversion process.

    Attributes:
        name (str): Target platform name. Defaults to "apollo510_evb".
        cpu (str|None): CPU core type (e.g., cortex-m55). Optional for built-ins.
        speeds (list[int]): Supported clock speeds in MHz.
        memories (dict[MemoryType,int]): Memory sizes in bytes.
        capabilities (list[SocCapability]): Available SoC capabilities.
        preferred_memory_order (list[MemoryType]): Placement preference for planner.
        min_alignment (int|None): Minimum alignment in bytes.
    """

    name: str = Field(default="apollo510_evb", description="Target platform name")
    cpu: str | None = Field(None, description="CPU core type (e.g., cortex-m55)")
    speeds: list[int] = Field(default_factory=list, description="List of supported clock speeds in MHz")
    memories: dict[MemoryType, int] = Field(default_factory=dict, description="Memory sizes in bytes")
    capabilities: list[SocCapability] = Field(default_factory=list, description="List of SoC capabilities")
    preferred_memory_order: list[MemoryType] = Field(
        default_factory=list, description="Preferred memory order for allocations"
    )
    min_alignment: int | None = Field(None, description="Minimum alignment requirement in bytes")

    @field_validator("min_alignment")
    @classmethod
    def _validate_min_alignment_pow2(cls, value: int | None) -> int | None:
        """Reject non-positive or non-power-of-two ``min_alignment`` at config load.

        ``SocPlatform`` enforces the same invariant, but custom
        platforms only hit that constructor lazily, and built-in
        platform names short-circuit through the registry without
        ever constructing a ``SocPlatform`` from the user's CLI
        input — so a malformed CLI/YAML value would otherwise be
        silently dropped on built-ins and surface as a late, less
        local error on customs. Validating at the CLI boundary
        keeps the failure mode uniform.
        """
        if value is None:
            return value
        if value <= 0:
            raise ValueError(
                f"platform.min_alignment must be a positive power of two, got {value}"
            )
        if value & (value - 1):
            raise ValueError(
                f"platform.min_alignment must be a power of two, got {value}"
            )
        return value


class DocumentationArgs(BaseModel):
    """Documentation configuration for the generated module.

    Attributes:
        html (bool): Generate html documentation site (experimental).
    """

    html: bool = Field(default=False, description="Generate html documentation site (experimental).")


@from_file(loader=YamlFileLoader, use_field="path")
class ConvertArgs(BaseModel, extra="allow"):
    """Configuration for the conversion process.

    Attributes:
        path (Path): Path to yaml configuration.
        model (ModelArgs): Model configuration.
        module (ModuleArgs): Module configuration.
        test (TestArgs): Test configuration.
        transforms (list[TransformSpec]): Transforms configuration.
        memory (MemoryArgs): Memory configuration.
        platform (PlatformArgs): Target platform configuration.
        verbose (int): Verbosity level (0-3).
        log_file (Path|None): Optional log file path.
    """

    path: Path = Field(
        default_factory=lambda: tempfile.NamedTemporaryFile().name,
        exclude=True,
        description="Path to yaml configuration",
    )
    model: ModelArgs = Field(default_factory=ModelArgs, description="Model configuration")
    module: ModuleArgs = Field(default_factory=ModuleArgs, description="Module configuration")
    test: TestArgs = Field(default_factory=TestArgs, description="Test configuration")
    transforms: list[TransformSpec] = Field(default_factory=list, description="Transforms configuration")
    memory: MemoryArgs = Field(default_factory=MemoryArgs, description="Memory configuration")
    platform: PlatformArgs = Field(default_factory=PlatformArgs, description="Target platform configuration")
    operators: list[AttributeRuleset] = Field(default_factory=list, description="Operator attributes")
    documentation: DocumentationArgs = Field(
        default_factory=DocumentationArgs, description="Documentation configuration"
    )
    verbose: int = Field(1, ge=0, le=3, description="Verbosity level")
    force: bool = Field(False, description="Force conversion even if output exists")
    log_file: Path | None = Field(None, description="Optional log file path")
