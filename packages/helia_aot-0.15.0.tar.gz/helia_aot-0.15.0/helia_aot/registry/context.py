from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from helia_aot.air import AirOpType, AirOperatorOptions
from helia_aot.air.op_keys import canonical_op_key
from helia_aot.converters.litert.op_parsers import OpParserFn, register_default_litert_parsers
from helia_aot.aot.operators import AotOperator, register_default_aot_operators
from helia_aot.transforms.transform import AirTransform
from helia_aot.transforms import register_default_transforms
from helia_aot.air.options import register_default_air_options

from . import Registry


@dataclass
class RegistryBundle:
    litert_parsers: Registry[AirOpType | str, OpParserFn]
    aot_operator_classes: Registry[AirOpType | str, type[AotOperator]]
    transforms: Registry[str, type[AirTransform]]
    air_options: Registry[AirOpType | str, type[AirOperatorOptions]]


class RegistryContext:
    def __init__(self, bundle: RegistryBundle):
        self.bundle = bundle
        self.litert_parsers = bundle.litert_parsers
        self.aot_operator_classes = bundle.aot_operator_classes
        self.transforms = bundle.transforms
        self.air_options = bundle.air_options

    def freeze(self) -> None:
        self.litert_parsers.freeze()
        self.aot_operator_classes.freeze()
        self.transforms.freeze()
        self.air_options.freeze()

    def unfreeze(self) -> None:
        self.litert_parsers.unfreeze()
        self.aot_operator_classes.unfreeze()
        self.transforms.unfreeze()
        self.air_options.unfreeze()


def _snapshot(context: RegistryContext) -> dict[str, dict[str, object]]:
    return {
        "litert_parsers": dict(context.litert_parsers.items()),
        "aot_operator_classes": dict(context.aot_operator_classes.items()),
        "transforms": dict(context.transforms.items()),
        "air_options": dict(context.air_options.items()),
    }


def _assert_no_replacements(context: RegistryContext, before: dict[str, dict[str, object]]) -> None:
    replaced: list[str] = []
    removed: list[str] = []
    for name, reg in (
        ("litert_parsers", context.litert_parsers),
        ("aot_operator_classes", context.aot_operator_classes),
        ("transforms", context.transforms),
        ("air_options", context.air_options),
    ):
        prev = before[name]
        current = dict(reg.items())
        for key, value in prev.items():
            if key not in current:
                removed.append(f"{name}:{key}")
            elif current[key] is not value:
                replaced.append(f"{name}:{key}")
    issues: list[str] = []
    if replaced:
        issues.append("overrides: " + ", ".join(sorted(replaced)))
    if removed:
        issues.append("removals: " + ", ".join(sorted(removed)))
    if issues:
        raise RuntimeError("Registry override is disabled; attempted mutations detected (" + "; ".join(issues) + ")")


def build_default_registry_context(
    *,
    customizers: list[Callable[[RegistryContext], None]] | None = None,
    allow_override: bool = False,
    freeze: bool = True,
) -> RegistryContext:
    """Build a fresh registry context with built-ins and optional customizers."""

    bundle = RegistryBundle(
        litert_parsers=Registry(key_encoder=canonical_op_key),
        aot_operator_classes=Registry(key_encoder=canonical_op_key),
        transforms=Registry(),
        air_options=Registry(key_encoder=canonical_op_key),
    )
    context = RegistryContext(bundle=bundle)

    register_default_litert_parsers(context.litert_parsers)
    register_default_aot_operators(context.aot_operator_classes)
    register_default_transforms(context.transforms)
    register_default_air_options(context.air_options)

    if customizers:
        before = _snapshot(context) if not allow_override else {}
        for customize in customizers:
            customize(context)
        if not allow_override:
            _assert_no_replacements(context, before)

    if freeze:
        context.freeze()

    return context
