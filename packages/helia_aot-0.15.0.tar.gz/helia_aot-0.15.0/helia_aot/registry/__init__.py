"""

# :material-view-list: Registry API

Generic thread-safe registry primitives used by the explicit `RegistryContext`.

"""

from __future__ import annotations

from threading import Lock
from typing import Callable, Generic, Iterable, TypeVar

K = TypeVar("K")
T = TypeVar("T")


class Registry(Generic[K, T]):
    """Thread-safe registry with optional key encoding."""

    def __init__(self, *, key_encoder: Callable[[K], str] | None = None):
        self._items: dict[str, T] = {}
        self._locked = False
        self._lock = Lock()
        self._key_encoder = key_encoder or (lambda key: str(key))

    def _encode(self, key: K) -> str:
        return self._key_encoder(key)

    def register(self, key: K, item: T, *, overwrite: bool = False) -> None:
        """Register an item under the given key."""
        name = self._encode(key)
        with self._lock:
            if self._locked:
                raise RuntimeError("Registry is frozen; cannot register items")
            if not overwrite and name in self._items:
                raise KeyError(f"Item '{name}' already registered")
            self._items[name] = item

    def unregister(self, key: K) -> None:
        """Unregister an item if present."""
        name = self._encode(key)
        with self._lock:
            if self._locked:
                raise RuntimeError("Registry is frozen; cannot unregister items")
            self._items.pop(name, None)

    def get(self, key: K) -> T:
        """Get a registered item by key."""
        return self._items[self._encode(key)]

    def has(self, key: K) -> bool:
        """Check if an item is registered."""
        return self._encode(key) in self._items

    def list(self) -> list[str]:
        """List registered encoded key names."""
        return list(self._items.keys())

    def decorator(self, key: K, *, overwrite: bool = False) -> Callable[[T], T]:
        """Decorator helper to register callables/classes."""

        def _decorator(obj: T) -> T:
            self.register(key, obj, overwrite=overwrite)
            return obj

        return _decorator

    def freeze(self) -> None:
        """Prevent modifications; useful after bootstrapping built-ins."""
        with self._lock:
            self._locked = True

    def unfreeze(self) -> None:
        """Allow modifications again."""
        with self._lock:
            self._locked = False

    def clear(self) -> None:
        """Remove all items from the registry."""
        with self._lock:
            if self._locked:
                raise RuntimeError("Registry is frozen; cannot clear items")
            self._items.clear()

    def items(self) -> Iterable[tuple[str, T]]:
        """Iterate over encoded key, item pairs."""
        return tuple(self._items.items())


__all__ = [
    "Registry",
]
