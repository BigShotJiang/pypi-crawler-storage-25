"""
# :simple-tensorflow: heliaAOT LiteRT API

Thin compatibility wrapper that re-exports LiteRT APIs from `ai-edge-litert`.
"""

from __future__ import annotations

from ai_edge_litert import schema_py_generated as schema_py_generated  # type: ignore

# ALWAYS import our real submodule so Pylance can resolve it
from . import interpreter as interpreter
from .interpreter import Interpreter, has_interpreter  # re-export handy names

__all__ = ["schema_py_generated", "interpreter", "Interpreter", "has_interpreter"]
