from __future__ import annotations

try:
    from ai_edge_litert.interpreter import Interpreter as _UpInterpreter  # type: ignore

    Interpreter = _UpInterpreter  # re-export

    def has_interpreter() -> bool:
        return True
except (ModuleNotFoundError, ImportError, OSError):
    class Interpreter:
        def __init__(self, *args, **kwargs):
            raise RuntimeError(
                "ai-edge-litert Interpreter is unavailable in this environment. "
                "Install 'ai-edge-litert>=2.1.2' and ensure a compatible wheel exists "
                "for your Python version and platform."
            )

    def has_interpreter() -> bool:
        return False


__all__ = ["Interpreter", "has_interpreter"]
