"""
# LiteRT Converter API

This module handles converting models to LiteRT format.

Classes:
    LiteRTQuantizationType: Enum class for quantization types.
    LiteRTConverter: LiteRT model converter.
    LiteRTConversionType: Enum class for conversion types.

"""

import tempfile
from enum import StrEnum
from typing import Callable

import numpy as np
import numpy.typing as npt

import tensorflow as tf
from helia_aot.utils import suppress_os_stdio


class LiteRTQuantizationType(StrEnum):
    """Supported quantization formats

    Attributes:
        FP32: FP32 quantization
        FP16: FP16 quantization
        INT8: INT8 quantization
        INT16X8: INT16X8 quantization

    """

    FP32 = "FP32"
    FP16 = "FP16"
    INT8 = "INT8"
    INT16X8 = "INT16X8"

    @classmethod
    def from_dtype(cls, dtype: np.dtype):
        """Get quantization type from dtype string

        Args:
            dtype (np.dtype): Dtype object

        Returns:
            LiteRTQuantizationType: Corresponding quantization type
        """
        dtype_str = str(dtype).lower()
        match dtype_str:
            case "float32" | "fp32":
                return cls.FP32
            case "float16" | "fp16":
                return cls.FP16
            case "int8" | "s8":
                return cls.INT8
            case "int16" | "s16" | "int16x8" | "s16x8":
                return cls.INT16X8
            case _:
                raise ValueError(f"Unsupported dtype for quantization type: {dtype_str}")
        # END MATCH



class LiteRTConversionType(StrEnum):
    """Supported conversion types

    Attributes:
        KERAS: Use Keras model directly
        SAVED_MODEL: Use TF Saved model format
        CONCRETE: Lower to TF Concrete functions
    """

    KERAS = "KERAS"
    SAVED_MODEL = "SAVED_MODEL"
    CONCRETE = "CONCRETE"


class LiteRTConverter:

    def __init__(
        self,
        model: tf.keras.Model,
    ):
        """Converts Keras/TF model to LiteRT model.

        Args:
            model (tf.keras.Model): Keras model

        Example:

        ```python
        # Create simple dataset
        test_x = np.random.rand(1000, 64).astype(np.float32)
        test_y = np.random.randint(0, 10, 1000).astype(np.int32)

        # Create a dense model and train
        model = tf.keras.Sequential([
            tf.keras.layers.Dense(64, activation="relu", input_shape=(64,)),
            tf.keras.layers.Dense(32, activation="relu"),
            tf.keras.layers.Dense(10, activation="softmax"),
        ])
        model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
        model.fit(test_x, test_y, epochs=1, validation_split=0.2)

        # Create converter and convert to LiteRT w/ FP32 quantization
        converter = LiteRTKerasConverter(model=model)
        model_content = converter.convert(
            test_x,
            quantization=LiteRTQuantizationType.FP32,
            io_type="float32"
        )
        y_pred_tfl = converter.predict(test_x)
        y_pred_tf = model.predict(test_x)
        print(np.allclose(y_pred_tf, y_pred_tfl, atol=1e-3))
        ```
        """
        self.model = model
        self.representative_dataset = None
        self._converter: tf.lite.TFLiteConverter | None = None
        self._model_content: str | None = None
        self.tf_model_path = tempfile.TemporaryDirectory()


    def convert(
        self,
        rep_dataset: Callable | None = None,
        quantization: LiteRTQuantizationType = LiteRTQuantizationType.FP32,
        io_type: str | None = None,
        mode: LiteRTConversionType = LiteRTConversionType.KERAS,
        strict: bool = True,
        verbose: int = 2,
    ) -> str:
        """Convert TF model into LiteRT model content

        Args:
            rep_dataset (Callable | None, optional): Representative dataset generator. Defaults to None.
            quantization (QuantizationType, optional): Quantization type. Defaults to QuantizationType.FP32.
            io_type (str | None, optional): Input/Output type. Defaults to None.
            mode (ConversionType, optional): Conversion mode. Defaults to ConversionType.KERAS.
            strict (bool, optional): Strict mode. Defaults to True.
            verbose (int, optional): Verbosity level (0,1,2). Defaults to 2.

        Returns:
            str: model content
        """
        quantization = LiteRTQuantizationType(quantization)

        match mode:
            case LiteRTConversionType.KERAS:
                converter = tf.lite.TFLiteConverter.from_keras_model(model=self.model)
            case LiteRTConversionType.SAVED_MODEL:
                self.model.export(self.tf_model_path.name, format="tf_saved_model")
                converter = tf.lite.TFLiteConverter.from_saved_model(self.tf_model_path.name)
            # Following case is a workaround for bug (https://github.com/tensorflow/tflite-micro/issues/2319)
            # Default TFLiteConverter generates equivalent graph w/ SpaceToBatchND operations but losses dilation_rate factor.
            case LiteRTConversionType.CONCRETE:
                input_shapes = self.model.input_shape
                if isinstance(input_shapes, list):
                    for i, shape in enumerate(input_shapes):
                        input_shapes[i] = (1,) + shape[1:]
                elif isinstance(input_shapes, tuple):
                    input_shapes = (1,) + input_shapes[1:]
                input_spec = tf.TensorSpec(shape=input_shapes, dtype=self.model.input_dtype)

                model_func = tf.function(func=self.model)
                model_cf = model_func.get_concrete_function(input_spec)
                converter = tf.lite.TFLiteConverter.from_concrete_functions([model_cf])
            case _:
                raise ValueError(f"Invalid conversion mode: {mode}")
        # END MATCH

        self.representative_dataset = rep_dataset

        match quantization:
            # float32 weights, bias, activation
            case LiteRTQuantizationType.FP32:
                pass
            # float16 weights, bias, activation
            case LiteRTQuantizationType.FP16:
                converter.optimizations = [tf.lite.Optimize.DEFAULT]
                converter.target_spec.supported_types = [tf.float16]
            # int8 weights, bias, activation
            case LiteRTQuantizationType.INT8:
                converter.optimizations = [tf.lite.Optimize.DEFAULT]
                converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
                io_dtype = tf.dtypes.as_dtype(io_type) if io_type else tf.int8
                converter.inference_input_type = io_dtype
                converter.inference_output_type = io_dtype
                converter.representative_dataset = self.representative_dataset
            # int8 weights, int64 bias, int16 activation
            case LiteRTQuantizationType.INT16X8:
                converter.optimizations = [tf.lite.Optimize.DEFAULT]
                converter.target_spec.supported_ops = [
                    tf.lite.OpsSet.EXPERIMENTAL_TFLITE_BUILTINS_ACTIVATIONS_INT16_WEIGHTS_INT8
                ]
                io_dtype = tf.dtypes.as_dtype(io_type) if io_type else tf.float32
                converter.inference_input_type = io_dtype
                converter.inference_output_type = io_dtype
                converter.representative_dataset = self.representative_dataset
        # END MATCH

        # For fallback append tf.lite.OpsSet.TFLITE_BUILTINS for INT8 and INT16X8
        if not strict and quantization in [
            LiteRTQuantizationType.INT8,
            LiteRTQuantizationType.INT16X8,
        ]:
            converter.target_spec.supported_ops.append(tf.lite.OpsSet.TFLITE_BUILTINS)
        # END IF

        # Convert model
        self._converter = converter
        with suppress_os_stdio():
            self._model_content = converter.convert()

        return self._model_content

    def predict(
        self,
        x: npt.NDArray,
        input_name: str | None = None,
        output_name: str | None = None,
    ):
        # Prepare the test data
        inputs = x.copy()
        inputs = inputs.astype(np.float32)

        interpreter = tf.lite.Interpreter(model_content=self._model_content)
        interpreter.allocate_tensors()

        # No signature
        if len(interpreter.get_signature_list()) == 0:
            output_details = interpreter.get_output_details()[0]
            input_details = interpreter.get_input_details()[0]

            input_scale: list[float] = input_details["quantization_parameters"]["scales"]
            input_zero_point: list[int] = input_details["quantization_parameters"]["zero_points"]
            output_scale: list[float] = output_details["quantization_parameters"]["scales"]
            output_zero_point: list[int] = output_details["quantization_parameters"]["zero_points"]

            inputs = inputs.reshape([-1] + input_details["shape_signature"].tolist())
            if len(input_scale) and len(input_zero_point):
                inputs = inputs / input_scale[0] + input_zero_point[0]
                inputs = inputs.astype(input_details["dtype"])

            outputs = []
            for sample in inputs:
                interpreter.set_tensor(input_details["index"], sample)
                interpreter.invoke()
                y = interpreter.get_tensor(output_details["index"])
                outputs.append(y)
            outputs = np.concatenate(outputs, axis=0)

            if len(output_scale) and len(output_zero_point):
                outputs = outputs.astype(np.float32)
                outputs = (outputs - output_zero_point[0]) * output_scale[0]

            return outputs

        # WITH Signature
        model_sig = interpreter.get_signature_runner()
        inputs_details = model_sig.get_input_details()
        outputs_details = model_sig.get_output_details()
        if input_name is None:
            input_name = list(inputs_details.keys())[0]
        if output_name is None:
            output_name = list(outputs_details.keys())[0]
        input_details = inputs_details[input_name]
        output_details = outputs_details[output_name]
        input_scale: list[float] = input_details["quantization_parameters"]["scales"]
        input_zero_point: list[int] = input_details["quantization_parameters"]["zero_points"]
        output_scale: list[float] = output_details["quantization_parameters"]["scales"]
        output_zero_point: list[int] = output_details["quantization_parameters"]["zero_points"]

        inputs = inputs.reshape([-1] + input_details["shape_signature"].tolist()[1:])
        if len(input_scale) and len(input_zero_point):
            inputs = inputs / input_scale[0] + input_zero_point[0]
            inputs = inputs.astype(input_details["dtype"])

        outputs = np.array(
            [model_sig(**{input_name: inputs[i : i + 1]})[output_name][0] for i in range(inputs.shape[0])],
            dtype=output_details["dtype"],
        )

        if len(output_scale) and len(output_zero_point):
            outputs = outputs.astype(np.float32)
            outputs = (outputs - output_zero_point[0]) * output_scale[0]

        return outputs

    def evaluate(
        self,
        x: npt.NDArray,
        y: npt.NDArray,
        input_name: str | None = None,
        output_name: str | None = None,
    ) -> npt.NDArray:
        """Evaluate LiteRT model

        Args:
            x (npt.NDArray): Input samples
            y (npt.NDArray): Input labels
            input_name (str | None, optional): Input layer name. Defaults to None.
            output_name (str | None, optional): Output layer name. Defaults to None.

        Returns:
            npt.NDArray: Loss values
        """
        y_pred = self.predict(
            x=x,
            input_name=input_name,
            output_name=output_name,
        )
        loss_function = tf.keras.losses.get(self.model.loss)
        loss = loss_function(y, y_pred).numpy()
        return loss

    def export(self, save_path: str):
        """Export LiteRT model content to file

        Args:
            save_path (str): LiteRT file path
        """
        if self._model_content is None:
            raise ValueError("No LiteRT content to export. Run convert() first.")

        with open(save_path, "wb") as f:
            f.write(self._model_content)

    def cleanup(self):
        """Cleanup temporary files"""
        self.tf_model_path.cleanup()
