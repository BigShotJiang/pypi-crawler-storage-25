"""
# :material-file-code-outline: Templates API

The templates module provides the jinja2 template files used to generate the AOT code.

"""

from datetime import date
from pathlib import Path

import numpy as np
from jinja2 import Environment, FileSystemLoader, select_autoescape, Template
from helia_aot.utils import get_version

_templates_dir = Path(__file__).resolve().parent.parent / "templates"

env = Environment(
    loader=FileSystemLoader(_templates_dir),
    autoescape=select_autoescape(["html", "xml"]),
    trim_blocks=True,
    lstrip_blocks=True,
)


def _raise(msg: str) -> str:
    """Jinja2 global that raises a template error with a clear message."""
    raise RuntimeError(msg)


def _as_int8_bytes(data) -> list[int]:
    """Reinterpret an arbitrary-dtype numpy array's bit pattern as a
    flat list of signed-int8 values.

    Used by the staged-constant source-blob emitter so a tensor whose
    runtime ``ctype`` is e.g. ``int32_t`` still serializes into the
    ``int8_t [N]`` source blob with the *exact same* byte image the
    xip-mode dedicated symbol would have produced. Without this the
    template would emit the int32 *values* into an int8 array
    (compiler-narrowed and corrupt for any value outside [-128, 127]).
    """
    arr = np.ascontiguousarray(data)
    return np.frombuffer(arr.tobytes(), dtype=np.int8).tolist()


env.filters["as_int8_bytes"] = _as_int8_bytes

# set default global variables for templates
env.globals.update(
    dict(
        generation_date=date.today().isoformat(),
        copyright_year=str(date.today().year),
        tool_version=get_version(),
    )
)
env.globals["raise"] = _raise


def load_template(name: str) -> Template:
    """Load a Jinja2 template given filename

    Args:
        name (str): Template filename (e.g. conv.c)

    Returns:
        Template: The loaded template
    """
    return env.get_template(f"{name}.j2")


def update_env_globals(globals_dict: dict):
    """Update the Jinja2 environment globals with the provided dictionary.

    Args:
        globals_dict (dict): Dictionary of global variables to update.
    """
    env.globals.update(globals_dict)
