from __future__ import annotations

import tempfile
from typing import TYPE_CHECKING
from pathlib import Path
from dataclasses import dataclass, field
from pydantic.dataclasses import dataclass as py_dataclass
from pydantic import Field
from helia_aot.air import AirModel
from helia_aot.memory import MemoryPlan
from helia_aot.platforms import SocPlatform
from .operators.operator import AotOperator
from .render_plan import RenderMemoryPlan

if TYPE_CHECKING:
    from ..cli.defines import ConvertArgs
    from ..registry.context import RegistryContext


@py_dataclass(frozen=True)
class SemanticVersion:
    major: int = Field(..., description="Major version number")
    minor: int = Field(..., description="Minor version number")
    patch: int = Field(..., description="Patch version number")


# Minimum required ns-cmsis-nn version (v7.22.0+)
CMSIS_NN_VERSION = SemanticVersion(major=7, minor=22, patch=0)


@dataclass
class CodeGenContext:
    """Context for code generation.

    Attributes:
        config (ConvertArgs): Configuration for the conversion process.
        model (AirModel|None): The AIR model being processed.
        work_path (Path): Working directory for generated files.
        memory_plan (MemoryPlan|None): Memory plan for the model.
        render_plan (RenderMemoryPlan|None): Render-side projection of
            the memory plan, populated immediately after planning.
            Templates and emit handlers should consume this in
            preference to ``memory_plan`` so derived predicates
            (cold-vs-staged, sidecar filenames, constant byte
            payloads) live in a single builder.
        platform (SocPlatform|None): Target platform for code generation.
        operators (list[AotOperator]): List of operators in the model.
    """

    config: ConvertArgs = field(metadata=dict(description="Configuration for the conversion process."))
    registry_context: RegistryContext = field(metadata=dict(description="Registry context for op parsing/dispatch."))
    model: AirModel | None = field(default=None, metadata=dict(description="The AIR model being processed."))
    work_path: Path = field(
        default_factory=lambda: Path(tempfile.mkdtemp(prefix="helia-aot")),
        metadata=dict(description="Working directory for generated files."),
    )
    memory_plan: MemoryPlan | None = field(default=None, metadata=dict(description="Memory plan for the model."))
    render_plan: RenderMemoryPlan | None = field(
        default=None,
        metadata=dict(description="Render-side projection of the memory plan."),
    )
    platform: SocPlatform | None = field(
        default=None, metadata=dict(description="Target platform for code generation.")
    )
    operators: list[AotOperator] = field(
        default_factory=list, metadata=dict(description="List of operators in the model.")
    )
    @property
    def prefix(self) -> str:
        return self.config.module.prefix
