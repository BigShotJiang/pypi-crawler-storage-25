"""

:material-rocket-launch-outline: Ambiq Ahead-of-Time (AOT) API

Use this API when you need programmatic control over conversion, kernel selection,
memory planning, and asset generation. For most users, the `helia-aot` **CLI** is the
recommended entry point; this package underpins that CLI.

Features:

- Model → AIR → C module pipeline
- Kernel registry with capability/rule-based selection
- Static memory planning (arenas, lifetimes, offsets)
- Extensible handlers (module, model, operator, tensor, test, assets)
- Platform hooks (NeuralSPOT / Zephyr / generic)

"""

from .handlers import AotHandler, DocHandler, ModelHandler, ModuleHandler, OperatorHandler, TensorHandler, TestHandler
from .defines import CMSIS_NN_VERSION, CodeGenContext
