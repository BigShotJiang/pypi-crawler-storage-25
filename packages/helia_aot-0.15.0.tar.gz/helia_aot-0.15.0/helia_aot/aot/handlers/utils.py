"""
# :material-tools: AOT Handler Utilities API

The `utils` module provides utility functions for AOT handlers.


Copyright 2025 Ambiq. All Rights Reserved.

"""

import re
from collections import defaultdict
import numpy as np
from helia_aot.air import AirModel, AirTensor, TensorId


def generate_mermaid(model: AirModel, direction: str = "TB") -> str:
    """Generate a Mermaid flowchart showing operator connectivity.

    Args:
        model (AirModel): The model to generate the flowchart for.
        direction (str): Mermaid graph direction (“TB”, “LR”, etc.)

    Returns:
        str: Mermaid code as a string.
    """

    lines = ["```mermaid", "---", "config:", "  look: handDrawn", "  theme: neutral", "---", f"flowchart {direction}"]

    # 1) Declare one node per operator
    for op in model.operators:
        # e.g. op42["42: CONV_2D"]
        lines.append(f'  op{op.id}["{op.id}: {op.op_type}"]')

    # 2) Build a map: tensor_id -> producer (buffer, op_id)
    producer: dict[TensorId, str] = {}
    for op in model.operators:
        for t_id in op.output_ids:
            producer[t_id] = (t_id, op.id)

    # 3) Build a map: tensor_id -> list of consumer (buffer, op_id)
    consumers: dict[str, list[tuple[TensorId, str]]] = defaultdict(list)
    for op in model.operators:
        for t_id in op.input_ids:
            consumers[t_id].append((t_id, op.id))

    # 4) Emit edges for every tensor that has both a producer and at least one consumer
    for tensor_id, prod in producer.items():
        for cons in consumers.get(tensor_id, []):
            lines.append(f'  op{prod[1]} -->|"T{prod[0]}"| op{cons[1]}')

    lines.append("```")
    return "\n".join(lines)


def sanitize_for_c_comment(text: str | bytes | bytearray) -> str:
    """Sanitize a string (or bytes) so it can safely live inside a C block comment (/* ... */).

    Transforms:
    - If bytes/bytearray, decode as UTF-8 (replacing errors).
    - Replaces '/*' with '/ *' and '*/' with '* /'
    - Strips out non-printable/control chars except tab/newline/carriage-return.

    Args:
        text (str|bytes|bytearray): Input text to sanitize.

    Returns:
        str: Sanitized text.
    """
    if text is None:
        return ""

    if isinstance(text, (bytes, bytearray)):
        text = text.decode("utf-8", errors="replace")

    # break any comment delimiters
    text = text.replace("/*", "/ *")
    text = text.replace("*/", "* /")

    # remove other control characters
    text = re.sub(r"[^\x09\x0A\x0D\x20-\x7E]", " ", text)
    return text


def generate_stimulus_data(tensor: AirTensor) -> np.ndarray:
    """Generate random stimulus data for given tensor

    Args:
        tensor (AirTensor): Target tensor

    Returns:
        np.ndarray: Generated stimulus data
    """
    quantization = tensor.quantization
    scale = None
    zero_point = None
    if quantization is not None and quantization.scale is not None and quantization.zero_point is not None:
        if len(quantization.scale) > 0 and len(quantization.zero_point) > 0:
            scale = float(quantization.scale[0])
            zero_point = int(quantization.zero_point[0])
    is_quantized = scale is not None and scale > 0.0

    if np.issubdtype(tensor.dtype, np.floating):
        return np.array(np.random.random(tensor.shape).astype(tensor.dtype))

    # Integer quantized:
    q_min, q_max = np.iinfo(tensor.dtype).min, np.iinfo(tensor.dtype).max

    if not is_quantized:
        # no quantization ⇒ full int range
        return np.array(np.random.randint(q_min, q_max + 1, size=tensor.shape, dtype=tensor.dtype))

    # Option A: direct integer sampling
    # return np.random.randint(q_min, q_max+1, size=shape, dtype=dtype)

    assert zero_point is not None and scale is not None

    # Option B: float‐then‐quantize
    r_min = (q_min - zero_point) * scale
    r_max = (q_max - zero_point) * scale
    fdata = np.random.uniform(r_min, r_max, size=tensor.shape).astype(np.float32)
    qdata = np.round(fdata / scale) + zero_point
    qdata = np.clip(qdata, q_min, q_max).astype(tensor.dtype)
    return np.array(qdata)
