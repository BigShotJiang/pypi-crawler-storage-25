from pathlib import Path
from ..defines import CodeGenContext
from .handler import AotHandler
from ..templates import load_template
from ..operators import AotOperator
from helia_aot.air.op_keys import canonical_op_key
from helia_aot.attributes import compute_entity_attributes
from helia_aot.utils import setup_logger

logger = setup_logger(log_name=__name__)


class OperatorHandler(AotHandler):
    """Responsible for generating operator source code."""

    context: CodeGenContext

    def __init__(self, context: CodeGenContext):
        super().__init__(context=context)
        self.context.operators = []

    def compute_values(self) -> dict[str, str]:
        """Computes the values needed for generating the model source code.

        Returns:
            dict: A dictionary containing the computed values for code generation.
        """

        sub_values = dict(
            prefix=self.context.config.module.prefix,
            operators=self.context.operators,
        )
        return sub_values

    def resolve(self):
        air_operators = self.context.model.operators
        self.context.operators = []
        for op in air_operators:
            logger.debug("Resolving operator %s (%s)", op.op_type, op.id)
            op_type_name = op.op_type.value if hasattr(op.op_type, "value") else str(op.op_type)
            op_type_name = canonical_op_key(op_type_name)
            attributes = compute_entity_attributes(
                attributes=self.context.config.operators, entity_type=op_type_name, entity_id=op.id
            )
            registry = self.context.registry_context.aot_operator_classes
            op_cls = registry.get(op.op_type) if registry.has(op.op_type) else AotOperator
            aot_op = op_cls(
                op=op,
                model=self.context.model,
                platform=self.context.platform,
                prefix=self.context.config.module.prefix,
                attributes=attributes,
            )
            aot_op.resolve()
            self.context.operators.append(aot_op)
        # END FOR

    def plan(self):
        for op in self.context.operators:
            op.plan()

    def emit(self, save_path: Path):
        for op in self.context.operators:
            op.emit(save_path=save_path)

        sub_values = self.compute_values()
        hdr_template = load_template("operators.h")
        hdr_code = hdr_template.render(sub_values)

        with open(
            save_path / "includes-api" / f"{self.context.config.module.prefix}_operators.h", "w", encoding="utf-8"
        ) as f:
            f.write(hdr_code)
