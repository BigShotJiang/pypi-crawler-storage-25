from pathlib import Path
from datetime import date
from ..defines import CodeGenContext
from .handler import AotHandler
from ..templates import load_template
from helia_aot.utils import setup_logger, get_version

logger = setup_logger(log_name=__name__)


class ModelHandler(AotHandler):
    """Responsible for generating model source code."""

    def __init__(self, context: CodeGenContext):
        super().__init__(context=context)

    def compute_values(self) -> dict[str, str]:
        """Computes the values needed for generating the model source code.

        Returns:
            dict: A dictionary containing the computed values for code generation.
        """

        sub_values = dict(
            prefix=self.context.config.module.prefix,
            model=self.context.model,
            operators=self.context.operators,
            config=self.context.config,
            plan=self.context.memory_plan,
            render_plan=self._resolve_render_plan(),
            # Header docs
            generation_date=date.today().isoformat(),
            copyright_year=str(date.today().year),
            tool_version=get_version(),
        )
        return sub_values

    def resolve(self):
        pass

    def plan(self):
        pass

    def emit(self, save_path: Path):
        """Generate the source code for the main inference model.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("model.h")
        src_template = load_template("model.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        # Save the generated code to files.
        with open(save_path / "includes-api" / f"{self.context.config.module.prefix}_model.h", "w") as hdr_file:
            hdr_file.write(hdr_code)

        with open(save_path / "src" / f"{self.context.config.module.prefix}_model.c", "w") as src_file:
            src_file.write(src_code)
