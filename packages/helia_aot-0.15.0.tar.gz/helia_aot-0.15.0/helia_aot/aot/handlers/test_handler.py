from pathlib import Path

import numpy as np

from ..defines import CodeGenContext
from .handler import AotHandler
from helia_aot.air import AirTensor
from helia_aot.interpreters import create_interpreter, AirInterpreter
from helia_aot.utils import setup_logger
from ..templates import load_template
from .utils import generate_stimulus_data

logger = setup_logger(log_name=__name__)


class TestHandler(AotHandler):
    """Responsible for generating test code."""

    context: CodeGenContext
    interpreter: AirInterpreter | None

    def __init__(self, context: CodeGenContext):
        super().__init__(context=context)
        self.interpreter = None
        self._golden_cache: dict[str, np.ndarray] | None = None

    def compute_values(self) -> dict[str, str]:
        """Computes the values needed for generating the model source code.

        Returns:
            dict: A dictionary containing the computed values for code generation.
        """

        skip_verification = self.context.config.test.skip_verification
        golden_path = self.context.config.test.golden_data
        num_iterations = self.context.config.test.num_iterations
        if not golden_path and not skip_verification and self.interpreter is None:
            raise RuntimeError("Interpreter not resolved. Call `resolve()` before emitting.")

        inputs: list[AirTensor] = []
        outputs: list[AirTensor] = []

        if golden_path:
            golden_file = Path(golden_path)
            if self._golden_cache is None:
                if not golden_file.exists():
                    raise FileNotFoundError(f"Golden data file {golden_file} not found")
                loaded_npz = np.load(golden_file, allow_pickle=False)
                self._golden_cache = {name: loaded_npz[name] for name in loaded_npz.files}
            for idx, tensor_id in enumerate(self.context.model.input_ids):
                tensor = self.context.model.get_tensor(tensor_id)
                key = f"input_{idx}"
                if key not in self._golden_cache:
                    raise KeyError(f"Golden data missing key '{key}'")
                tensor.data = np.array(self._golden_cache[key], copy=True)
                inputs.append(tensor)
            for idx, tensor_id in enumerate(self.context.model.output_ids):
                tensor = self.context.model.get_tensor(tensor_id)
                key = f"output_{idx}"
                if key in self._golden_cache:
                    tensor.data = np.array(self._golden_cache[key], copy=True)
                outputs.append(tensor)
        elif self.interpreter is not None:
            for tensor_id in self.context.model.input_ids:
                tensor = self.context.model.get_tensor(tensor_id)
                tensor.data = generate_stimulus_data(tensor)
                inputs.append(tensor)
                self.interpreter.set_input(tensor, key=tensor.id)
            for _ in range(num_iterations):
                self.interpreter.invoke()
            for tensor_id in self.context.model.output_ids:
                tensor = self.interpreter.get_output(key=tensor_id, wrap=True)
                outputs.append(tensor)
        else:
            # Generate deterministic stimulus even when verification is skipped so
            # the emitted sources remain well-defined.
            for tensor_id in self.context.model.input_ids:
                tensor = self.context.model.get_tensor(tensor_id)
                tensor.data = generate_stimulus_data(tensor)
                inputs.append(tensor)
            for tensor_id in self.context.model.output_ids:
                tensor = self.context.model.get_tensor(tensor_id)
                tensor.data = np.zeros(tensor.shape, dtype=tensor.dtype)
                outputs.append(tensor)

        sub_values = dict(
            config=self.context.config,
            prefix=self.context.config.module.prefix,
            inputs=inputs,
            outputs=outputs,
            plan=self.context.memory_plan,
            render_plan=self._resolve_render_plan(),
            tolerance=self.context.config.test.tolerance,
            skip_verification=skip_verification,
            num_iterations=num_iterations,
        )

        return sub_values

    def resolve(self):
        if self.context.config.test.golden_data:
            self.interpreter = None
            return
        try:
            self.interpreter = create_interpreter(self.context.config.model.path)
        except Exception as exc:  # pragma: no cover - protective path
            if self.context.config.test.skip_verification:
                logger.warning("Skipping interpreter creation due to unsupported custom op: %s", exc)
                self.interpreter = None
            else:
                raise

    def plan(self):
        pass

    def emit(self, save_path: Path):
        sub_values = self.compute_values()

        hdr_template = load_template("test_case.h")
        src_template = load_template("test_case.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        # Save the generated code to files.
        with open(save_path / "includes-api" / f"{self.context.config.module.prefix}_test_case.h", "w") as hdr_file:
            hdr_file.write(hdr_code)

        with open(save_path / "src" / f"{self.context.config.module.prefix}_test_case.c", "w") as src_file:
            src_file.write(src_code)
