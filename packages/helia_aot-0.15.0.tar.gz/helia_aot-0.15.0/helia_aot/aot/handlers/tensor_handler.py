from pathlib import Path
from datetime import date
from ..defines import CodeGenContext
from .handler import AotHandler
from ..templates import load_template
from helia_aot.utils import setup_logger, get_version


logger = setup_logger(log_name=__name__)


class TensorHandler(AotHandler):
    """Handles the generation of tensor-related source code."""

    context: CodeGenContext

    def __init__(self, context: CodeGenContext):
        super().__init__(context=context)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator source code template.

        Returns:
            dict[str, str]: Dictionary of values for the operator template.
        """
        # Iterate all model tensors and print associated metadata.
        for tensor in self.context.model.tensors.values():
            meta = self.context.memory_plan.tensor_allocs.get(tensor.id)
            if meta is None:
                logger.warning(f"Tensor {tensor.id} has no memory allocation metadata.")
            else:
                logger.debug(f"Tensor {tensor.id} - Allocated size: {meta.size}, Arena: {meta.memory}")

        sub_values = dict(
            config=self.context.config,
            model=self.context.model,
            plan=self.context.memory_plan,
            render_plan=self._resolve_render_plan(),
            platform=self.context.platform,
            # Header docs
            prefix=self.context.config.module.prefix,
            filename=f"{self.context.config.module.prefix}_tensors",
            tool_version=get_version(),
            version=self.context.model.version,
            generation_date=date.today().isoformat(),
            copyright_year=str(date.today().year),
        )

        return sub_values

    def resolve(self):
        pass

    def plan(self):
        pass

    def _emit_constant_sidecars(self, save_path: Path) -> None:
        """Emit per-arena constant sidecars for external-arena builds.

        Sidecars are written only when ``allocate_arenas`` is disabled,
        because callers are then responsible for provisioning
        ``ctx->arena_buffers`` and can load these blobs from storage.

        The ``RenderMemoryPlan`` builder pre-resolves the cold-vs-staged
        split, the byte payload, and the ``__blob`` / ``__source``
        suffix that matches the corresponding C symbol; this method
        just writes one file per :class:`RenderConstantBlob`.
        """
        if self.context.config.memory.allocate_arenas:
            return

        render_plan = self._resolve_render_plan()

        for blob in render_plan.constant_blobs:
            (save_path / blob.sidecar_filename).write_bytes(blob.payload)

    def emit(self, save_path: Path):
        """Generate the source code for resource variables.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("tensors.h")
        src_template = load_template("tensors.c")
        constants_src_template = load_template("constants.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)
        constants_src_code = constants_src_template.render(sub_values)

        # Save the generated code to files.
        with open(save_path / "includes-api" / f"{self.context.config.module.prefix}_tensors.h", "w") as hdr_file:
            hdr_file.write(hdr_code)

        with open(save_path / "src" / f"{self.context.config.module.prefix}_tensors.c", "w") as src_file:
            src_file.write(src_code)

        with open(save_path / "src" / f"{self.context.config.module.prefix}_constants.c", "w") as src_file:
            src_file.write(constants_src_code)

        self._emit_constant_sidecars(save_path)

        sub_values["op_type"] = "context"
        hdr_template = load_template("context.h")
        src_template = load_template("context.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.context.config.module.prefix}_context.h", "w") as hdr_file:
            hdr_file.write(hdr_code)

        with open(save_path / "src" / f"{self.context.config.module.prefix}_context.c", "w") as src_file:
            src_file.write(src_code)
