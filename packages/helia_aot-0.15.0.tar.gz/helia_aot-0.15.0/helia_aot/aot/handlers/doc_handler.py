import yaml
import json
import shutil
from pathlib import Path
from collections import Counter
from .handler import AotHandler
from helia_aot.aot.defines import CMSIS_NN_VERSION, CodeGenContext
from helia_aot.aot.assets import copy_asset
from helia_aot.aot.templates import load_template
from helia_aot.utils import setup_logger
from .utils import generate_mermaid

logger = setup_logger(log_name=__name__)


def generate_html_docs(context: CodeGenContext, save_path: Path):
    """Generate offline html documentation site.

    Args:
        context: (CodeGenContext): Code generation context.
        save_path (Path): Path to save the generated code.
    """

    # Lazy load mkdocs as not strictly required
    from mkdocs.config import load_config
    from mkdocs.commands.build import build as mkdocs_build

    yaml_config_str = yaml.safe_dump(json.loads(context.config.model_dump_json()), sort_keys=False)

    op_dist = Counter(op.op_type for op in context.model.operators)

    sub_values = dict(
        context=context,
        prefix=context.config.module.prefix,
        operator_distribution=op_dist,
        operators_unique=len(set([op.op_type for op in context.model.operators])),
        model_mermaid=generate_mermaid(context.model),
        yaml_configuration=yaml_config_str,
        cmsis=CMSIS_NN_VERSION,
    )

    # Create the docs-src and docs directories
    docs_path = save_path / "docs-src"
    docs_path.mkdir(parents=True, exist_ok=True)
    asset_path = docs_path / "assets"
    asset_path.mkdir(parents=True, exist_ok=True)
    site_path = save_path / "docs"
    site_path.mkdir(parents=True, exist_ok=True)

    # Create mkdocs configuration
    with open(save_path / "mkdocs.yaml", "w") as fp:
        fp.write(
            load_template("docs/mkdocs.yaml").render(
                dict(module_name=context.config.module.name, site_dir=str(site_path), docs_dir=str(docs_path))
            )
        )

    # Generate mkdocs content
    with open(docs_path / "index.md", "w") as fp:
        fp.write(load_template("docs/index.md").render(sub_values))

    with open(docs_path / "model.md", "w") as fp:
        fp.write(load_template("docs/model.md").render(sub_values))

    with open(docs_path / "memory.md", "w") as fp:
        fp.write(load_template("docs/memory.md").render(sub_values))

    with open(docs_path / "usage.md", "w") as fp:
        fp.write(load_template("docs/usage.md").render(sub_values))

    with open(docs_path / "config.md", "w") as fp:
        fp.write(load_template("docs/config.md").render(sub_values))

    with open(docs_path / "license.md", "w") as fp:
        license_template = load_template("docs/license.md")
        fp.write(license_template.render(sub_values))

    # Copy required assets
    copy_asset("helia-aot-icon-white.png", save_path=asset_path)
    copy_asset("simple-datatables.css", save_path=asset_path)
    copy_asset("simple-datatables.js", save_path=asset_path)
    copy_asset("table-init.js", save_path=asset_path)
    copy_asset("custom.css", save_path=asset_path)

    # Load mkdocs config
    config = load_config(str(save_path / "mkdocs.yaml"))

    # Build mkdocs offline site
    mkdocs_build(config, dirty=False)

    # Remove the docs directory after building the site
    shutil.rmtree(docs_path)
    (save_path / "mkdocs.yaml").unlink()


def generate_license(context: CodeGenContext, save_path: Path):
    """Generate module license file.

    Args:
        context: (CodeGenContext): Code generation context.
        save_path (Path): Path to save the generated code.
    """

    lic_code = load_template("docs/license.md").render({})
    with open(save_path / "LICENSE", "w") as fp:
        fp.write(lic_code)


def generate_readme(context: CodeGenContext, save_path: Path):
    """Generate the README markdown file.

    Args:
        context: (CodeGenContext): Code generation context.
        save_path (Path): Path to save the generated code.
    """

    yaml_config_str = yaml.safe_dump(json.loads(context.config.model_dump_json()), sort_keys=False)

    op_dist = Counter(op.op_type for op in context.model.operators)

    sub_values = dict(
        context=context,
        prefix=context.config.module.prefix,
        operator_distribution=op_dist,
        operators_unique=len(set([op.op_type for op in context.model.operators])),
        # model_mermaid=generate_mermaid(context.model),
        yaml_configuration=yaml_config_str,
        cmsis=CMSIS_NN_VERSION,
    )

    readme_code = load_template("docs/readme.md").render(sub_values)
    with open(save_path / "README.md", "w") as fp:
        fp.write(readme_code)


class DocHandler(AotHandler):
    """Responsible for generating documentation and supporting assets."""

    def __init__(self, context: CodeGenContext):
        super().__init__(context=context)

    def resolve(self):
        pass

    def plan(self):
        pass

    def emit(self, save_path: Path):
        """Generate documentation and supporting assets.

        Args:
            save_path (Path): Path to save the generated code.
        """

        generate_license(self.context, save_path=save_path)
        generate_readme(self.context, save_path=save_path)
        if self.context.config.documentation.html:
            generate_html_docs(self.context, save_path=save_path)
