"""

# :material-function-variant: Handlers API

The 'handlers' module provides classes to handle specific component/step in AOT conversion process.

## Available Handlers

- **[AotHandler](./handler)**: Base class for all handlers, providing common functionality.
- **[DocHandler](./doc_handler)**: Manages the generation of documentation and assets.
- **[ModelHandler](./model_handler)**: Handles the generation of main model.
- **[ModuleHandler](./module_handler)**: Manages the generation of exported module.
- **[OperatorHandler](./operator_handler)**: Manages the generation of operator-specific code.
- **[TensorHandler](./tensor_handler)**: Manages the generation of tensors.
- **[TestHandler](./test_handler)**: Manages the generation of test code.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from .handler import AotHandler
from .doc_handler import DocHandler
from .model_handler import ModelHandler
from .module_handler import ModuleHandler
from .operator_handler import OperatorHandler
from .tensor_handler import TensorHandler
from .test_handler import TestHandler
