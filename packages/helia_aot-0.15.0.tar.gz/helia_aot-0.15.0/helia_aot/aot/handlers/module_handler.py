import shutil
from pathlib import Path
from ..defines import CodeGenContext, CMSIS_NN_VERSION
from helia_aot.defines import ModuleType
from .handler import AotHandler
from ..templates import load_template
from helia_aot.utils import setup_logger

logger = setup_logger(log_name=__name__)


class ModuleHandler(AotHandler):
    """Responsible for generating the module source code."""

    def __init__(self, context: CodeGenContext):
        super().__init__(context=context)

    def _get_source_files(self) -> list[str]:
        source_files = []
        for operator in self.context.operators:
            source_files.append(f"src/{self.context.config.module.prefix}_{operator.name}.c")
        source_files.append(f"src/{self.context.config.module.prefix}_model.c")
        source_files.append(f"src/{self.context.config.module.prefix}_tensors.c")
        source_files.append(f"src/{self.context.config.module.prefix}_constants.c")
        source_files.append(f"src/{self.context.config.module.prefix}_context.c")
        if self.context.config.test.enabled:
            source_files.append(f"src/{self.context.config.module.prefix}_test_case.c")

        return source_files

    def compute_values(self) -> dict[str, str]:
        """Computes the values needed for generating the module source code.

        Returns:
            dict: A dictionary containing the computed values for code generation.
        """
        return dict(
            prefix=self.context.config.module.prefix,
            cmsis_nn_version=CMSIS_NN_VERSION,
            module_name=self.context.config.module.name,
            module_type=self.context.config.module.type.value,
            source_files=self._get_source_files(),
        )

    def generate_common_files(self, save_path: Path):
        """Generates common files for the module.

        Args:
            save_path (Path): Path to save the generated files.
        """
        # Create prefix_common.h, prefix_platform.h, prefix_compiler.h
        sub_values = self.compute_values()
        common_template = load_template("common.h")
        platform_template = load_template("platform.h")
        compiler_template = load_template("compiler.h")

        common_code = common_template.render(sub_values)
        platform_code = platform_template.render(sub_values)
        compiler_code = compiler_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.context.config.module.prefix}_common.h", "w") as common_file:
            common_file.write(common_code)
        with open(save_path / "includes-api" / f"{self.context.config.module.prefix}_platform.h", "w") as platform_file:
            platform_file.write(platform_code)
        with open(save_path / "includes-api" / f"{self.context.config.module.prefix}_compiler.h", "w") as compiler_file:
            compiler_file.write(compiler_code)

    def generate_neuralspot_module(self, save_path: Path):
        """Generates the NeuralSpot module files.

        This method creates the module.mk file for the NeuralSpot module.
        """

        sub_values = self.compute_values()

        module_template = load_template("neuralspot/module.mk")
        module_code = module_template.render(sub_values)

        with open(save_path / "module.mk", "w") as module_file:
            module_file.write(module_code)

    def generate_zephyr_module(self, save_path: Path):
        """Generates the Zephyr module files.

        This method creates the module.yml and CMakeLists.txt files for the Zephyr module.
        """

        sub_values = self.compute_values()

        module_template = load_template("zephyr/module.yml")
        cmake_template = load_template("zephyr/CMakeLists.txt")
        kconfig_template = load_template("zephyr/Kconfig")
        module_code = module_template.render(sub_values)
        cmake_code = cmake_template.render(sub_values)
        kconfig_code = kconfig_template.render(sub_values)

        # Make the zephyr module directory
        zephyr_module_path = save_path / "zephyr"
        zephyr_module_path.mkdir(parents=True, exist_ok=True)

        # Save the generated code to files.
        with open(zephyr_module_path / "module.yml", "w") as module_file:
            module_file.write(module_code)
        with open(zephyr_module_path / "CMakeLists.txt", "w") as cmake_file:
            cmake_file.write(cmake_code)
        with open(zephyr_module_path / "Kconfig", "w") as kconfig_file:
            kconfig_file.write(kconfig_code)

    def generate_cmake_module(self, save_path: Path):
        """Generates the CMake module files.

        This method creates the CMakeLists.txt files for the CMake module.
        """

        sub_values = self.compute_values()

        cmake_template = load_template("cmake/CMakeLists.txt")
        cmake_code = cmake_template.render(sub_values)

        # Save the generated code to files.
        with open(save_path / "CMakeLists.txt", "w") as cmake_file:
            cmake_file.write(cmake_code)

    def generate_nsx_module(self, save_path: Path):
        """Generates the NSX (neuralspotx) module files.

        Creates both the ``nsx-module.yaml`` manifest and a CMakeLists.txt
        that follows NSX conventions (``nsx::`` alias, board flags linkage,
        CMSIS-NN dependency, and an optional attributes-header override hook).
        """

        sub_values = self.compute_values()

        manifest_template = load_template("nsx/nsx-module.yaml")
        cmake_template = load_template("nsx/CMakeLists.txt")

        manifest_code = manifest_template.render(sub_values)
        cmake_code = cmake_template.render(sub_values)

        with open(save_path / "nsx-module.yaml", "w") as manifest_file:
            manifest_file.write(manifest_code)
        with open(save_path / "CMakeLists.txt", "w") as cmake_file:
            cmake_file.write(cmake_code)

    def resolve(self):
        module_path = self.context.work_path

        if module_path.exists():
            shutil.rmtree(module_path)
        module_path.mkdir(parents=True, exist_ok=True)
        module_path_src = module_path / "src"
        module_path_src.mkdir(parents=True, exist_ok=True)
        module_path_includes_api = module_path / "includes-api"
        module_path_includes_api.mkdir(parents=True, exist_ok=True)

    def plan(self):
        pass

    def emit(self, save_path: Path):
        self.generate_common_files(save_path)
        if self.context.config.module.type == ModuleType.neuralspot:
            self.generate_neuralspot_module(save_path)
        elif self.context.config.module.type == ModuleType.zephyr:
            self.generate_zephyr_module(save_path)
        elif self.context.config.module.type == ModuleType.cmake:
            self.generate_cmake_module(save_path)
        elif self.context.config.module.type == ModuleType.nsx:
            self.generate_nsx_module(save_path)
        else:
            raise ValueError(f"Unsupported module type: {self.context.config.module.type}")
        # END IF
