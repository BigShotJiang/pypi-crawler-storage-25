import abc
from pathlib import Path
from ..defines import CodeGenContext


class AotHandler(abc.ABC):
    """Base class for all AOT code-generation handlers.

    Lifecycle:
      The lifecycle of an AOT handler consists of three main stages:

      1. resolve() — inspect AIR, add any scratch tensors, choose kernels
      2. plan()    — (optional) adjust memory plan or other per-handler scheduling
      3. emit()    — write out headers, C sources, assets, etc.
    """

    context: CodeGenContext

    def __init__(self, context: CodeGenContext):
        """Base class for AOT handlers.

        Args:
            context (CodeGenContext): Code generation context

        """
        self.context = context

    @abc.abstractmethod
    def resolve(self):
        """Resolve the handler's context and prepare for code generation."""
        raise NotImplementedError("Handler must implement the resolve method.")

    def plan(self):
        """Hook for any handler-specific planning (default no-op)."""
        pass

    @abc.abstractmethod
    def emit(self, save_path: Path):
        """Generate artifacts for the AOT handler.

        Args:
            save_path (Path): The path where the generated code will be saved.
        """
        raise NotImplementedError("Handler must implement the emit method.")

    def _resolve_render_plan(self):
        """Return the context's :class:`RenderMemoryPlan`, building it on demand.

        The render-plan is computed once in the converter pipeline and
        cached on :attr:`CodeGenContext.render_plan`. Tests and
        ad-hoc callers that construct a :class:`CodeGenContext`
        directly may forget to populate it; build the projection on
        demand and cache it back into the context so subsequent
        handlers (and a re-entrant call within the same handler) see
        the same instance and the same ``plan_hash``.

        Returns:
            The single :class:`RenderMemoryPlan` for this context.
        """
        if self.context.render_plan is None:
            from ..render_plan import build_render_plan

            self.context.render_plan = build_render_plan(
                plan=self.context.memory_plan,
                model=self.context.model,
                module_prefix=self.context.config.module.prefix,
            )
        return self.context.render_plan
