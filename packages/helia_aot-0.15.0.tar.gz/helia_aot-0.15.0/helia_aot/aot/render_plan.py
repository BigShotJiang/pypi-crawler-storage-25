"""Render-side projection of a :class:`~helia_aot.memory.MemoryPlan`.

The memory planner produces a :class:`MemoryPlan` describing how
tensors map into arenas. Templates and emit handlers historically
reached directly into that structure to recompute derived facts
(cold-vs-staged predicates, sidecar filenames, packed blob bytes,
etc.). That coupling made it impossible to swap a different planner
backend without re-deriving every predicate in the templates, and it
scattered the same logic across multiple sites.

This module introduces a small set of frozen render dataclasses that
sit between the planner and the codegen. The builder
(:func:`build_render_plan`) is the only place that knows how to
turn a :class:`MemoryPlan` into render-ready records:

- :class:`RenderArena` — one arena (scratch, persistent, or constant)
  with all derived predicates pre-resolved (``is_staged``, ``role``)
  and an explicit, deterministic ``region_id``.
- :class:`RenderConstantBlob` — one packed byte image for a constant
  arena, ready to be written as a sidecar or embedded inline.
- :class:`RenderMemoryPlan` — top-level container holding the
  arenas and constant blobs, plus a ``plan_hash`` that fingerprints
  the schema-relevant region layout for ABI drift detection.

The DTO is additive: ``CodeGenContext.memory_plan`` is unchanged and
templates that have not been migrated continue to work. Migration
proceeds incrementally.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

from helia_aot.memory.defines import ArenaRole, ArenaUsage, MemoryPlan
from helia_aot.platforms import MemoryType

if TYPE_CHECKING:
    from helia_aot.air import Model


ArenaRoleStr = Literal["scratch", "persistent", "constant"]


@dataclass(frozen=True)
class RenderArena:
    """Render-side projection of one :class:`ArenaUsage`.

    Attributes:
        region_id: Stable region index used as the C enumerator
            value. Assigned by :func:`build_render_plan` from a
            deterministic policy (role priority then ``memory.name``
            ascending) so two independent re-plans of the same model
            produce identical region IDs.
        role: Logical role as a plain string (``scratch``,
            ``persistent``, or ``constant``). Stable across planner
            backends and friendly for template comparisons.
        memory: Runtime (kernel-visible) memory of the arena.
        source_memory: Cold-storage source memory. Equals ``memory``
            for non-staged arenas; different for staged constants.
        size: Bytes used (==``arena.used``). For bump-allocated
            constant/persistent arenas this also equals
            ``total_size``.
        alignment: Resolved alignment of the arena base symbol.
        is_staged: ``True`` iff ``source_memory`` differs from
            ``memory``. Centralized so every consumer (template,
            handler, doc snippet) reads the same predicate.
    """

    region_id: int
    role: ArenaRoleStr
    memory: MemoryType
    source_memory: MemoryType
    size: int
    alignment: int
    is_staged: bool


@dataclass(frozen=True)
class RenderConstantBlob:
    """One packed byte image for a constant arena.

    Attributes:
        memory: Runtime memory of the destination arena.
        is_staged: ``True`` iff the arena is staged (copy at boot)
            rather than cold (read in place).
        sidecar_filename: Filename to use when writing the byte image
            as a sidecar in external-arena builds. Already includes
            the module prefix and the ``__blob`` / ``__source``
            suffix that matches the corresponding C symbol.
        payload: Packed bytes including alignment padding between
            constants.
    """

    memory: MemoryType
    is_staged: bool
    sidecar_filename: str
    payload: bytes


@dataclass(frozen=True)
class RenderMemoryPlan:
    """Render-ready projection of a :class:`MemoryPlan`.

    Attributes:
        scratch_arenas: Scratch arenas in deterministic order.
        persistent_arenas: Persistent arenas in deterministic order.
        constant_arenas: Constant arenas in deterministic order.
        constant_blobs: One packed byte image per constant arena,
            ordered to match ``constant_arenas``.
        plan_hash: Hex digest fingerprinting the **arena envelope**
            only: per-region ``(role, memory, source_memory, size,
            alignment, is_staged)`` in ``region_id`` order. Stable
            across re-plans of the same model; changes when any
            region's envelope shape differs. Emitted into the
            generated header as ``<PREFIX>_PLAN_HASH`` so downstream
            binaries can detect arena-ABI drift at link time. Does
            **not** cover per-tensor placement (a planner change
            that re-shuffles tensors within the same arena envelope
            leaves ``plan_hash`` unchanged); use
            :attr:`tensor_layout_hash` for the per-tensor layer.
        tensor_layout_hash: Hex digest fingerprinting per-tensor
            placement: each tensor's ``(tensor_id, role, memory,
            offset, size)`` in sorted ``tensor_id`` order. Captures
            drift the arena-envelope hash can miss (e.g. two tensors
            swapping offsets within the same arena). Surfaced in the
            residency JSON; not currently emitted as a C macro.
    """

    scratch_arenas: tuple[RenderArena, ...] = field(default_factory=tuple)
    persistent_arenas: tuple[RenderArena, ...] = field(default_factory=tuple)
    constant_arenas: tuple[RenderArena, ...] = field(default_factory=tuple)
    constant_blobs: tuple[RenderConstantBlob, ...] = field(default_factory=tuple)
    plan_hash: str = ""
    tensor_layout_hash: str = ""

    @property
    def staged_constant_arenas(self) -> tuple[RenderArena, ...]:
        """Constant arenas with a distinct cold source memory.

        Convenience for templates that gate hydration emission on
        the presence of any staged-constant residency.
        """
        return tuple(a for a in self.constant_arenas if a.is_staged)

    @property
    def has_staged_constants(self) -> bool:
        """True iff any constant arena is staged."""
        return any(a.is_staged for a in self.constant_arenas)

    @property
    def all_arenas(self) -> tuple[RenderArena, ...]:
        """Every arena in ``region_id`` order.

        Concatenation of ``scratch_arenas + persistent_arenas +
        constant_arenas``; the index in the returned tuple equals
        ``arena.region_id`` for every entry. This is the canonical
        iteration order for any consumer that needs region IDs to
        match the C enumerator values (size table, alignment table,
        bind table).
        """
        return self.scratch_arenas + self.persistent_arenas + self.constant_arenas


def _project_arena(arena: ArenaUsage, region_id: int) -> RenderArena:
    """Build a :class:`RenderArena` from a planner :class:`ArenaUsage`."""
    source_memory = arena.source_memory if arena.source_memory is not None else arena.memory
    return RenderArena(
        region_id=region_id,
        role=arena.role.value,
        memory=arena.memory,
        source_memory=source_memory,
        size=arena.used,
        alignment=arena.alignment,
        is_staged=arena.is_staged,
    )


def _sorted_for_role(arenas: list[ArenaUsage]) -> list[ArenaUsage]:
    """Sort arenas within a single role by memory name (str) ascending.

    The planner's dict ordering reflects the order in which arenas
    are first allocated, which depends on tensor visit order and is
    stable for a given model + planner version but is not guaranteed
    across planner refactors. Sorting by memory name pins the
    ordering to the model's residency declaration so a planner-side
    refactor cannot silently shuffle region IDs.
    """
    return sorted(arenas, key=lambda a: a.memory.name)


def _compute_plan_hash(arenas: tuple[RenderArena, ...]) -> str:
    """Hex digest fingerprinting the arena envelope for ABI guards.

    Scope: per-region ``(role, memory, source_memory, size,
    alignment, is_staged)`` in ``region_id`` order. Uses SHA-256
    truncated to 16 hex chars (64 bits) — collision risk negligible
    for the small region tuples here.

    Does **not** cover per-tensor placement: a planner change that
    re-shuffles tensors within the same arena envelope (same total
    size / alignment) leaves this hash unchanged. Use
    :func:`_compute_tensor_layout_hash` for that layer.
    """
    h = hashlib.sha256()
    for a in arenas:
        h.update(
            "|".join(
                [
                    a.role,
                    a.memory.name,
                    a.source_memory.name,
                    str(a.size),
                    str(a.alignment),
                    "1" if a.is_staged else "0",
                ]
            ).encode("utf-8")
        )
        h.update(b";")
    return h.hexdigest()[:16]


def _compute_tensor_layout_hash(
    plan: MemoryPlan,
) -> str:
    """Hex digest fingerprinting per-tensor placement.

    Scope: each tensor's ``(tensor_id, role, memory, offset, size)``
    in sorted ``tensor_id`` order (numeric ids first in numeric
    order, then non-numeric ids lexicographically). Uses SHA-256
    truncated to 16 hex chars.

    Captures drift the arena-envelope ``plan_hash`` can miss:
    e.g. two tensors swapping offsets within the same arena, or a
    tensor migrating between arenas of identical envelope shape.
    Tensors without a binding are skipped (the
    :func:`_validate_plan_completeness` pass rejects emit-critical
    bindings earlier; this guard preserves robustness for callers
    that hash partial plans during development).
    """

    def _sort_key(tid: object) -> tuple[int, int | str]:
        try:
            return (0, int(tid))  # type: ignore[arg-type]
        except (TypeError, ValueError):
            return (1, str(tid))

    h = hashlib.sha256()
    for tid in sorted(plan.tensor_allocs.keys(), key=_sort_key):
        alloc = plan.tensor_allocs[tid]
        binding = alloc.binding
        if binding is None:
            continue
        h.update(
            "|".join(
                [
                    str(tid),
                    binding.role.name,
                    alloc.memory.name,
                    str(int(alloc.offset)),
                    str(int(alloc.size)),
                ]
            ).encode("utf-8")
        )
        h.update(b";")
    return h.hexdigest()[:16]


def _validate_plan_completeness(plan: MemoryPlan, model: "Model") -> None:
    """Fail fast when the planner output is missing emit-critical bindings.

    The render-plan packer iterates ``model.tensors`` and projects
    bindings into byte payloads / region descriptors. A backend that
    omits a binding for a tensor would otherwise silently produce a
    valid-looking blob with missing bytes. Catch the contract
    violation here so the diagnostic surfaces at convert time and
    points at the backend rather than at a runtime accuracy
    regression.

    Validates:
      * Every constant tensor has a non-``None`` ``TensorAllocation``
        with a binding into a registered constant arena.
      * Every persistent tensor has a binding into a registered
        persistent arena.
      * Constant-arena bindings reference an arena whose
        ``source_memory`` is consistent (cold or staged with the
        same source memory across slots).

    Args:
        plan: The planner output to validate.
        model: The model the plan was produced for.

    Raises:
        ValueError: If any of the contracts above is violated.
            The message identifies the offending tensor / arena.
    """
    constant_memories = set(plan.constant_arenas.keys())
    persistent_memories = set(plan.persistent_arenas.keys())

    for tensor in model.tensors.values():
        meta = plan.tensor_allocs.get(tensor.id)
        if meta is None or meta.binding is None:
            if tensor.is_constant:
                kind = "constant"
            elif tensor.is_persistent:
                kind = "persistent"
            else:
                kind = "scratch"
            raise ValueError(
                f"Planner output is incomplete: {kind} tensor "
                f"{tensor.id!r} has no allocation/binding. Every "
                f"tensor must be bound by the planner before render "
                "plan construction."
            )

        binding = meta.binding
        # ``TensorAllocation.offset`` and ``TensorBinding.offset`` are
        # two views of the same arena offset and must agree. The
        # blob packer reads ``meta.offset`` while the C tensor
        # descriptor also emits ``meta.offset``; if a backend sets
        # only one of the two fields, the inconsistency would be
        # silent.
        if binding.offset != meta.offset:
            raise ValueError(
                f"Tensor {tensor.id!r}: TensorAllocation.offset "
                f"({meta.offset}) disagrees with TensorBinding.offset "
                f"({binding.offset}). The planner must set both "
                "fields to the same arena offset."
            )
        if tensor.is_constant:
            if binding.role is not ArenaRole.constant:
                raise ValueError(
                    f"Constant tensor {tensor.id!r} is bound to a "
                    f"{binding.role.value} arena (expected constant)."
                )
            if binding.memory not in constant_memories:
                raise ValueError(
                    f"Constant tensor {tensor.id!r} is bound to memory "
                    f"{binding.memory.name} which is not a registered "
                    "constant arena in the plan."
                )
        elif tensor.is_persistent:
            if binding.role is not ArenaRole.persistent:
                raise ValueError(
                    f"Persistent tensor {tensor.id!r} is bound to a "
                    f"{binding.role.value} arena (expected persistent)."
                )
            if binding.memory not in persistent_memories:
                raise ValueError(
                    f"Persistent tensor {tensor.id!r} is bound to memory "
                    f"{binding.memory.name} which is not a registered "
                    "persistent arena in the plan."
                )

    # Per-arena source-memory consistency: every slot bound into a
    # given constant arena must agree on the cold source. Mismatched
    # source memories across slots in the same arena would mean
    # hydration cannot copy a single contiguous blob.
    arena_sources: dict[MemoryType, MemoryType] = {}
    for tensor in model.tensors.values():
        meta = plan.tensor_allocs.get(tensor.id)
        if meta is None or meta.binding is None:
            continue
        if meta.binding.role is not ArenaRole.constant:
            continue
        arena_mem = meta.binding.memory
        slot_source = meta.binding.source_memory
        previous = arena_sources.setdefault(arena_mem, slot_source)
        if previous != slot_source:
            raise ValueError(
                f"Constant arena {arena_mem.name} has slots with "
                f"mixed source memories ({previous.name} vs "
                f"{slot_source.name}). Every slot in a constant arena "
                "must share the same cold source so the staged-blob "
                "hydration path can copy a single contiguous payload."
            )

    # Cross-check: ``ArenaUsage.source_memory`` (the value projected
    # into ``RenderArena.source_memory`` and used to qualify the
    # source-blob C symbol's section) must agree with the consensus
    # source memory observed across all bindings into that arena.
    # A mismatch would silently land the source blob in the wrong
    # memory at link time.
    for arena_mem, consensus_source in arena_sources.items():
        usage = plan.constant_arenas.get(arena_mem)
        if usage is None or usage.source_memory is None:
            continue
        if usage.source_memory != consensus_source:
            raise ValueError(
                f"Constant arena {arena_mem.name}: "
                f"ArenaUsage.source_memory ({usage.source_memory.name}) "
                f"disagrees with the binding consensus source "
                f"({consensus_source.name}). The arena metadata and "
                "the per-tensor bindings must agree on the cold "
                "source memory."
            )


def _build_constant_blob(
    plan: MemoryPlan,
    model: "Model",
    arena_memory: MemoryType,
    size: int,
) -> bytes:
    """Pack every constant tensor placed in ``arena_memory`` into a single blob.

    The byte image lays tensors out by their planner-assigned
    offsets, with zero padding between them when offsets are not
    contiguous (alignment / explicit padding by the planner).

    Args:
        plan: The memory plan whose ``tensor_allocs`` drives placement.
        model: The model whose tensors carry the byte payloads.
        arena_memory: Runtime memory key of the destination arena.
        size: Total byte size of the destination arena.

    Returns:
        Packed bytes of length ``size``.

    Raises:
        ValueError: If a tensor's byte length does not match its
            allocated size, or if its placement overflows the arena.
    """
    blob = bytearray(size)
    placements: list[tuple[int, object]] = []
    for tensor in model.tensors.values():
        meta = plan.tensor_allocs.get(tensor.id)
        if (
            meta is not None
            and meta.binding is not None
            and meta.binding.role is ArenaRole.constant
            and meta.binding.memory == arena_memory
        ):
            placements.append((meta.offset, tensor))

    for offset, tensor in sorted(placements, key=lambda item: item[0]):
        tensor_bytes = tensor.data.tobytes()
        if len(tensor_bytes) != tensor.nbytes:
            raise ValueError(
                f"Constant tensor {tensor.id} byte-size mismatch: "
                f"expected {tensor.nbytes}, got {len(tensor_bytes)}"
            )
        end = offset + tensor.nbytes
        if end > size:
            raise ValueError(
                f"Constant tensor {tensor.id} overflows arena {arena_memory}: "
                f"offset {offset}, size {tensor.nbytes}, arena size {size}"
            )
        blob[offset:end] = tensor_bytes

    return bytes(blob)


def build_render_plan(
    plan: MemoryPlan,
    model: "Model",
    *,
    module_prefix: str,
) -> RenderMemoryPlan:
    """Project a :class:`MemoryPlan` into a :class:`RenderMemoryPlan`.

    All cold-vs-staged decisions, sidecar filename construction,
    constant-blob byte assembly, and region-id assignment happen
    here. Downstream consumers (templates, sidecar emit) read the
    resolved fields directly.

    Region IDs follow an explicit policy: scratch arenas first, then
    persistent, then constant. Within each role, arenas are sorted
    by ``memory.name`` ascending. The generated ``plan_hash``
    fingerprints the schema-relevant fields so a downstream binary
    can detect when its compiled-against region layout no longer
    matches a freshly-planned one.

    Args:
        plan: The planner output to project.
        model: The model the plan was produced for; needed to
            materialize constant byte payloads.
        module_prefix: Module prefix used when constructing sidecar
            filenames.

    Returns:
        A frozen :class:`RenderMemoryPlan` whose ``all_arenas`` tuple
        is in ``region_id`` order.

    Raises:
        ValueError: If the planner output is missing emit-critical
            bindings (e.g. a constant tensor with no allocation, a
            constant arena whose slots disagree on their cold source
            memory). See :func:`_validate_plan_completeness` for the
            full set of contracts.
    """
    _validate_plan_completeness(plan, model)

    sorted_scratch = _sorted_for_role(list(plan.arena_usages.values()))
    sorted_persistent = _sorted_for_role(list(plan.persistent_arenas.values()))
    sorted_constants = _sorted_for_role(list(plan.constant_arenas.values()))

    region_cursor = 0
    scratch: list[RenderArena] = []
    for a in sorted_scratch:
        scratch.append(_project_arena(a, region_cursor))
        region_cursor += 1
    persistent: list[RenderArena] = []
    for a in sorted_persistent:
        persistent.append(_project_arena(a, region_cursor))
        region_cursor += 1
    constants: list[RenderArena] = []
    for a in sorted_constants:
        constants.append(_project_arena(a, region_cursor))
        region_cursor += 1

    blobs: list[RenderConstantBlob] = []
    for arena in sorted_constants:
        suffix = "__source" if arena.is_staged else "__blob"
        filename = f"{module_prefix}_arena_const_{arena.memory.value}{suffix}.bin"
        payload = _build_constant_blob(plan, model, arena.memory, arena.used)
        blobs.append(
            RenderConstantBlob(
                memory=arena.memory,
                is_staged=arena.is_staged,
                sidecar_filename=filename,
                payload=payload,
            )
        )

    all_arenas = tuple(scratch) + tuple(persistent) + tuple(constants)
    plan_hash = _compute_plan_hash(all_arenas)
    tensor_layout_hash = _compute_tensor_layout_hash(plan)

    return RenderMemoryPlan(
        scratch_arenas=tuple(scratch),
        persistent_arenas=tuple(persistent),
        constant_arenas=tuple(constants),
        constant_blobs=tuple(blobs),
        plan_hash=plan_hash,
        tensor_layout_hash=tensor_layout_hash,
    )
