"""

# :material-image-multiple: Assets API

The `assets` module provides functions to manage static asset files required for AOT generation.

Functions:
    get_asset_path: Get the full path to an asset file.
    copy_asset: Copy an asset file to a specified directory.

"""

import shutil
from pathlib import Path

_assets_dir = Path(__file__).resolve().parent


def get_asset_path(name: str) -> Path:
    """Get full asset path.

    Args:
        name (str): Asset filename w/ extension.

    Returns:
        Path: Full asset path
    """
    asset_path = _assets_dir / name
    if not asset_path.is_file:
        raise KeyError(f"No asset w/ name {name} found.")
    return asset_path


def copy_asset(name: str, save_path: Path, dst_name: str | None = None):
    """Copy asset to save path.

    Args:
        name (str): Asset filename w/ extension.
        save_path (Path): Save folder path.
        dst_name (str|None): Destination filename. If not set, will use `name`.
    """
    if dst_name is None:
        dst_name = name
    src_path = get_asset_path(name)
    shutil.copy(src_path, save_path / dst_name)
