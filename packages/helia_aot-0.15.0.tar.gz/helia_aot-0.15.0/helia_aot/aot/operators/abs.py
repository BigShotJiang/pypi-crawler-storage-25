from __future__ import annotations

from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirFixedPointScale, AirAbsOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class AbsOperator(AotOperator):
    TYPE: AirOpType = AirOpType.ABS

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """ABS operator.

        This operator computes the element-wise absolute value of a tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        assert isinstance(self.op.options, AirAbsOptions)
        assert len(self.input_tensors) == 1, "ABS operator must have exactly one input tensor."
        assert len(self.output_tensors) == 1, "ABS operator must have exactly one output tensor."

        if self.input_tensors[self.kInputTensorIndex].dtype != self.output_tensors[self.kOutputTensorIndex].dtype:
            raise ValueError("Input and output tensor must have the same dtype.")
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Output tensor must be int8 or int16.")

    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        needs_rescale = False
        if input_tensor.quantization.scale[0] != output_tensor.quantization.scale[0]:
            needs_rescale = True

        real_multiplier = (
            input_tensor.quantization.scale[0] / output_tensor.quantization.scale[0]
        )
        output_fp = AirFixedPointScale.from_real_multiplier(real_multiplier)

        sub_values.update(
            dict(
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                output_fp=output_fp,
                needs_rescale=needs_rescale,
            )
        )

        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("abs.h")
        src_template = load_template("abs.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
