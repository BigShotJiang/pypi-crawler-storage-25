from __future__ import annotations
from pathlib import Path
import math

import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirSqrtOptions
from helia_aot.platforms import SocPlatform

from .operator import AotOperator
from .utils import lut_populate_s16
from ..templates import load_template


def make_sqrt_lut(
    input_scale: float,
    input_zero_point: int,
    output_scale: float,
    output_zero_point: int,
) -> np.ndarray:
    """Build a 256-entry int8 SQRT LUT."""

    lut = np.zeros(256, dtype=np.int8)
    for i in range(-128, 128):
        final_val = output_zero_point
        x = np.float32(input_scale) * np.float32(i - input_zero_point)

        if x > np.float32(0.0):
            res = np.float32(math.sqrt(float(x)))
            quantized_output = int(np.trunc(np.float32(res / np.float32(output_scale)))) + int(
                output_zero_point
            )
            final_val = min(max(quantized_output, -128), 127)

        # Mimic C's (uint8_t)i indexing with two's complement wrap.
        lut[i & 0xFF] = np.int8(final_val)

    return lut


class SqrtOperator(AotOperator):
    TYPE: AirOpType = AirOpType.SQRT

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """SQRT operator.

        This operator computes the element-wise square root of a float tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """
        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        assert isinstance(self.op.options, AirSqrtOptions)

        if len(self.input_tensors) != 1:
            raise ValueError("SQRT operator must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError("SQRT operator must have exactly one output tensor.")

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        input_dtype = np.dtype(input_tensor.dtype)
        output_dtype = np.dtype(output_tensor.dtype)

        supported_types = {np.dtype(np.int8), np.dtype(np.int16), np.dtype(np.float32)}
        if input_dtype not in supported_types or output_dtype not in supported_types:
            raise ValueError("SQRT operator currently supports only int8, int16, and float32 tensors.")
        if input_dtype != output_dtype:
            raise ValueError("SQRT input and output tensors must have matching dtypes.")
        if input_tensor.shape != output_tensor.shape:
            raise ValueError("SQRT input and output tensor shapes must match.")
        # Ensure quantization parameters exist for input and output
        if not input_tensor.quantization:
            raise ValueError("Input tensor must have quantization parameters")
        if not output_tensor.quantization:
            raise ValueError("Output tensor must have quantization parameters")


    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, str]:
        """Compute template values for the operator."""

        sub_values = super().compute_values()
        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        if input_tensor.dtype == np.int8:
            sqrt_lut = make_sqrt_lut(
                input_scale=float(input_tensor.quantization.scale[0]),
                input_zero_point=int(input_tensor.quantization.zero_point[0]),
                output_scale=float(output_tensor.quantization.scale[0]),
                output_zero_point=int(output_tensor.quantization.zero_point[0]),
            )
            sub_values.update(
                dict(
                    input_tensor=input_tensor,
                    output_tensor=output_tensor,
                    sqrt_lut=sqrt_lut,
                )
            )
        elif input_tensor.dtype == np.int16:

            def _safe_sqrt(x: float) -> float:
                return math.sqrt(x) if x > 0.0 else 0.0

            sqrt_lut_s16 = lut_populate_s16(
                input_scale=float(input_tensor.quantization.scale[0]),
                input_zero_point=int(input_tensor.quantization.zero_point[0]),
                output_scale=float(output_tensor.quantization.scale[0]),
                output_zero_point=int(output_tensor.quantization.zero_point[0]),
                transform_fn=_safe_sqrt,
            )
            sub_values.update(
                dict(
                    input_tensor=input_tensor,
                    output_tensor=output_tensor,
                    sqrt_lut_s16=sqrt_lut_s16,
                )
            )
        else:
            sub_values.update(
                dict(
                    input_tensor=input_tensor,
                    output_tensor=output_tensor,
                )
            )
        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator."""

        sub_values = self.compute_values()
        hdr_template = load_template("sqrt.h")
        src_template = load_template("sqrt.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
