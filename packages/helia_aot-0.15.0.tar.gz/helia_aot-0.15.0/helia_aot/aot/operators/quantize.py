from pathlib import Path
import numpy as np
from helia_aot.air import AirOpType, AirModel, AirOperator, AirQuantizeOptions, AirFixedPointScale
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class QuantizeOperator(AotOperator):
    TYPE: AirOpType = AirOpType.QUANTIZE

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """QUANTIZE operator.

        This operator converts a float tensor to a quantized tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        sub_values.update(
            dict(
            options=self.op.options,
            input_tensor=input_tensor,
            output_tensor=output_tensor,
        ))
        if self.output_tensors[0].dtype == self.input_tensors[0].dtype:
            real_multiplier = (
                input_tensor.quantization.scale[0] / output_tensor.quantization.scale[0]
            )
            sub_values["output_fp"] = AirFixedPointScale.from_real_multiplier(real_multiplier)


        return sub_values

    # Supported CMSIS-NN quantize/requantize dtype combinations.
    # Quantize: float32 → {int8, int16}
    # Requantize: int8 → int8, int16 → int16
    _SUPPORTED_DTYPE_PAIRS: list[tuple[type, type]] = [
        (np.float32, np.int8),
        (np.float32, np.int16),
        (np.int8, np.int8),
        (np.int16, np.int16),
    ]

    def validate(self):
        assert isinstance(self.op.options, AirQuantizeOptions)
        assert len(self.input_tensors) == 1
        assert len(self.output_tensors) == 1

        in_dtype = self.input_tensors[0].dtype
        out_dtype = self.output_tensors[0].dtype

        pair = (in_dtype, out_dtype)
        if pair not in self._SUPPORTED_DTYPE_PAIRS:
            supported_str = ", ".join(
                f"{np.dtype(i).name} → {np.dtype(o).name}"
                for i, o in self._SUPPORTED_DTYPE_PAIRS
            )
            raise ValueError(
                f"QUANTIZE operator (id={self.op.id}): unsupported dtype "
                f"combination input={np.dtype(in_dtype).name}, "
                f"output={np.dtype(out_dtype).name}. "
                f"Supported pairs: {supported_str}."
            )

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("quantize.h")
        src_template = load_template("quantize.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)