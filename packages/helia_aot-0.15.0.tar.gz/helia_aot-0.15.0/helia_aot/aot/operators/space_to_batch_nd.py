from pathlib import Path
from helia_aot.air import AirOpType, AirModel, AirOperator, AirSpaceToBatchNDOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class SpaceToBatchNDOperator(AotOperator):

    TYPE: AirOpType = AirOpType.SPACE_TO_BATCH_ND

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """SPACE_TO_BATCH_ND operator.

        This operator rearranges the input tensor from space-major to batch-major order.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        sub_values.update(dict(
            options=self.op.options,
            input_tensor=input_tensor,
            output_tensor=output_tensor,
        ))

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirSpaceToBatchNDOptions)
        if len(self.input_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")
        input_tensor = self.input_tensors[self.kInputTensorIndex]

        input_shape = tuple(int(dim) for dim in input_tensor.shape)
        spatial_dims_num = len(input_shape) - 2
        if spatial_dims_num not in (1, 2):
            raise ValueError(
                f"{self.TYPE} operator ({self.id}) expects input rank 3 or 4, got rank {len(input_shape)}."
            )

        block_shape = tuple(int(dim) for dim in self.op.options.block_shape)
        if len(block_shape) != spatial_dims_num:
            raise ValueError(
                f"{self.TYPE} operator ({self.id}) block_shape rank {len(block_shape)} "
                f"must equal spatial dims {spatial_dims_num}."
            )

        paddings = self.op.options.paddings
        paddings_by_dim = (
            (int(paddings.top), int(paddings.bottom)),
            (int(paddings.left), int(paddings.right)),
        )

        output_batch_size = int(input_shape[0])
        for dim in range(spatial_dims_num):
            block_dim = block_shape[dim]
            if block_dim == 0:
                raise ValueError(
                    f"{self.TYPE} operator ({self.id}) block_shape[{dim}] must be non-zero."
                )

            pad_before, pad_after = paddings_by_dim[dim]
            final_dim_size = int(input_shape[dim + 1]) + pad_before + pad_after
            if final_dim_size % block_dim != 0:
                raise ValueError(
                    f"{self.TYPE} operator ({self.id}) dim {dim + 1} size ({input_shape[dim + 1]}) "
                    f"with padding ({pad_before}, {pad_after}) is not divisible by block_shape {block_dim}."
                )
            output_batch_size *= block_dim

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("space_to_batch_nd.h")
        src_template = load_template("space_to_batch_nd.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
