from __future__ import annotations

from pathlib import Path
import numpy as np

from helia_aot.air import (
    AirOpType,
    AirModel,
    AirOperator,
    AirArgMinOptions,
)
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template

class ArgMinOperator(AotOperator):
    TYPE: AirOpType = AirOpType.ARG_MIN

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] | None = None,
    ):
        super().__init__(op, model, platform, prefix, attributes or {})

    def validate(self):
        assert isinstance(self.op.options, AirArgMinOptions)
        if len(self.input_tensors) != 1:
            raise ValueError(f"{self.TYPE} requires exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} requires exactly one output tensor.")

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        if input_tensor.dtype not in (np.int8, np.int16):
            raise ValueError(f"{self.TYPE} supports only int8/int16 inputs.")
        if output_tensor.dtype != np.int32:
            raise ValueError(f"{self.TYPE} produces int32 outputs.")

        axis = self.op.options.axis
        if axis < 0 or axis >= len(input_tensor.shape):
            raise ValueError(f"{self.TYPE} axis {axis} out of range for shape {input_tensor.shape}.")

    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, object]:
        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                output_tensor=output_tensor
            )
        )

        return sub_values

    def emit(self, save_path: Path):
        sub_values = self.compute_values()

        hdr_template = load_template("argmin.h")
        src_template = load_template("argmin.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
