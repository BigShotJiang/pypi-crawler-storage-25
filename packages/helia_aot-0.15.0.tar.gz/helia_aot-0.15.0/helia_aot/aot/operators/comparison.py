from __future__ import annotations

from pathlib import Path
import numpy as np

from helia_aot.air import (
    AirOpType,
    AirModel,
    AirOperator,
    AirFixedPointScale,
    AirComparisonOptions,
)
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class ComparisonOperator(AotOperator):
    """Shared logic for comparison operators."""

    TYPE: AirOpType = AirOpType.COMPARISON

    kInput1TensorIndex: int = 0
    kInput2TensorIndex: int = 1
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] | None = None,
    ):
        super().__init__(op, model, platform, prefix, attributes or {})

    def validate(self):
        """Ensure operator compatibility with CMSIS comparison kernels."""
        assert isinstance(self.op.options, AirComparisonOptions)

        if len(self.input_tensors) != 2:
            raise ValueError(f"{self.TYPE} requires 2 input tensors.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} requires 1 output tensor.")

        input1_tensor = self.input_tensors[self.kInput1TensorIndex]
        input2_tensor = self.input_tensors[self.kInput2TensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        if input1_tensor.dtype != input2_tensor.dtype:
            raise ValueError("Comparison inputs must share the same dtype.")

        if input1_tensor.dtype not in (np.int8, np.int16):
            raise ValueError(f"Unsupported comparison input dtype: {input1_tensor.dtype}.")

        if output_tensor.dtype != np.dtype("bool"):
            raise ValueError(f"Comparison output must be boolean, got {output_tensor.dtype}.")

        if not input1_tensor.quantization or not input1_tensor.quantization.scale:
            raise ValueError("Input1 tensor must provide quantization scale.")
        if not input2_tensor.quantization or not input2_tensor.quantization.scale:
            raise ValueError("Input2 tensor must provide quantization scale.")

        if not input1_tensor.quantization.zero_point:
            raise ValueError("Input1 tensor must provide quantization zero point.")
        if not input2_tensor.quantization.zero_point:
            raise ValueError("Input2 tensor must provide quantization zero point.")

    def compute_values(self) -> dict[str, object]:
        """Collect template values for the comparison kernels."""
        self.validate()

        sub_values = super().compute_values()

        input1_tensor = self.input_tensors[self.kInput1TensorIndex]
        input2_tensor = self.input_tensors[self.kInput2TensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        input1_multiplier = float(input1_tensor.quantization.scale[0])
        input2_multiplier = float(input2_tensor.quantization.scale[0])

        input1_fp = AirFixedPointScale.from_real_multiplier(input1_multiplier)
        input2_fp = AirFixedPointScale.from_real_multiplier(input2_multiplier)

        if input1_tensor.dtype in (np.int8, np.int16):
            left_shift = 8
        else:
            raise ValueError(f"Unsupported comparison input dtype: {input1_tensor.dtype}.")

        sub_values.update(
            dict(
                options=self.op.options,
                input1_tensor=input1_tensor,
                input2_tensor=input2_tensor,
                output_tensor=output_tensor,
                input1_fp=input1_fp,
                input2_fp=input2_fp,
                left_shift=left_shift,
            )
        )

        return sub_values

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Render comparison kernels."""
        sub_values = self.compute_values()

        hdr_template = load_template("comparison.h")
        src_template = load_template("comparison.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as hdr:
            hdr.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as src:
            src.write(src_code)
