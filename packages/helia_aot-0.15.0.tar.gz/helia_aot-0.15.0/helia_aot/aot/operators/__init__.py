"""

# :material-function-variant: Operators API

The 'operators' module provides classes to represent operators in the network graph. These classes all
inherit from the `AotOperator` class, which provides a common interface for all operators. Each operator class
is responsible for generating the C code for its specific operation. Built-in classes are registered into
`RegistryContext.aot_operator_classes` via `register_default_aot_operators`.

## Available Operators

- **[Add](./add)**: Element-wise addition
- **[ArgMax](./argmax)**: Argmax reduction
- **[ArgMin](./argmin)**: Argmin reduction
- **[AssignVariable](./assign_variable)**: Assigns a value to a variable
- **[AveragePool](./average_pool_2d)**: Average pooling operation
- **[BatchMatMul](./batch_matmul)**: Batch matrix multiplication
- **[BatchToSpaceND](./batch_to_space_nd)**: Batch to space transformation
- **[Comparison](./comparison)**: Comparison operations (e.g., equal, not equal, less than)
- **[Concatenation](./concatenation)**: Concatenates tensors along a specified axis
- **[Conv](./conv_2d)**: 2D convolution operation
- **[DepthwiseConv](./depthwise_conv_2d)**: Depthwise separable convolution operation
- **[DepthToSpace](./depth_to_space)**: Rearranges data from depth into blocks of spatial data
- **[Dequantize](./dequantize)**: Dequantizes a tensor
- **[EthosU](./ethosu_operator)**: Ethos-U NPU operator
- **[ExpandDims](./expand_dims)**: Expands the shape of a tensor
- **[Fill](./fill)**: Fills a tensor with a specified value
- **[Gather](./gather)**: Gathers elements along an axis
- **[GatherNd](./gather_nd)**: Gathers slices using multi-dimensional indices
- **[FullyConnected](./fully_connected)**: Fully connected layer
- **[HardSwish](./hard_swish)**: Hard swish activation function
- **[LeakyRelu](./leaky_relu)**: Leaky ReLU activation function
- **[Logistic](./logistic)**: Logistic activation function
- **[MaxPool](./max_pool_2d)**: Max pooling operation
- **[Maximum](./maximum)**: Element-wise maximum
- **[Mean](./mean)**: Computes the mean of a tensor along specified axes
- **[Sum](./sum)**: Computes the sum of a tensor along specified axes
- **[Minimum](./minimum)**: Element-wise minimum
- **[Mul](./mul)**: Element-wise multiplication
- **[Pack](./pack)**: Packs a list of tensors into a single tensor
- **[Pad](./pad)**: Pads a tensor
- **[Quantize](./quantize)**: Quantizes a tensor
- **[ReadVariable](./read_variable)**: Reads a variable
- **[ReduceMax](./reduce_max)**: Reduces a tensor by taking the maximum along specified axes
- **[ReduceMin](./reduce_min)**: Reduces a tensor by taking the minimum along specified axes
- **[Relu](./relu)**: Rectified Linear Unit activation
- **[Reshape](./reshape)**: Reshapes a tensor
- **[Shape](./shape)**: Returns the shape of a tensor
- **[Softmax](./softmax)**: Softmax activation
- **[Sqrt](./sqrt)**: Quantized square root
- **[SpaceToBatchND](./space_to_batch_nd)**: Space to batch transformation
- **[SpaceToDepth](./space_to_depth)**: Rearranges data from spatial blocks into depth
- **[Split](./split)**: Splits a tensor into multiple tensors along a specified axis
- **[Squeeze](./squeeze)**: Removes dimensions of size 1 from the shape of a tensor
- **[StridedSlice](./strided_slice)**: Slices a tensor with strides
- **[Sub](./sub)**: Element-wise subtraction
- **[Svdf](./svdf)**: SVDF operation
- **[Tanh](./tanh)**: Hyperbolic tangent activation function
- **[TransposeConv](./transpose_conv)**: Transpose convolution operation
- **[Transpose](./transpose)**: Transposes a tensor
- **[Unpack](./unpack)**: Unpacks a tensor into multiple tensors along a specified axis
- **[ZerosLike](./zeros_like)**: Generates a tensor of zeros
- **[Rsqrt](./rsqrt)**: Quantized reciprocal square root


Copyright 2025 Ambiq. All Rights Reserved.

"""

from helia_aot.air import AirOpType
from helia_aot.registry import Registry
from .operator import AotOperator
from .add import AddOperator
from .argmax import ArgMaxOperator
from .argmin import ArgMinOperator
from .sub import SubOperator
from .squared_difference import SquaredDifferenceOperator
from .assign_variable import AssignVariableOperator
from .average_pool_2d import AveragePool2DOperator
from .batch_matmul import BatchMatMulOperator
from .batch_to_space_nd import BatchToSpaceNDOperator
from .concatenation import ConcatenationOperator
from .conv_2d import Conv2DOperator
from .depthwise_conv_2d import DepthwiseConv2DOperator
from .depth_to_space import DepthToSpaceOperator
from .dequantize import DequantizeOperator
from .expand_dims import ExpandDimsOperator
from .fill import FillOperator
from .gather import GatherOperator
from .gather_nd import GatherNdOperator
from .fully_connected import FullyConnectedOperator
from .hard_swish import HardSwishOperator
from .leaky_relu import LeakyReluOperator
from .logistic import LogisticOperator
from .max_pool_2d import MaxPool2DOperator
from .maximum import MaximumOperator
from .mean import MeanOperator
from .sum import SumOperator
from .minimum import MinimumOperator
from .mul import MulOperator
from .comparison import ComparisonOperator
from .pack import PackOperator
from .pad import PadOperator
from .quantize import QuantizeOperator
from .read_variable import ReadVariableOperator
from .reduce_max import ReduceMaxOperator
from .reduce_min import ReduceMinOperator
from .relu import ReluOperator
from .shape import ShapeOperator
from .reshape import ReshapeOperator
from .softmax import SoftmaxOperator
from .space_to_batch_nd import SpaceToBatchNDOperator
from .space_to_depth import SpaceToDepthOperator
from .split import SplitOperator
from .slice import SliceOperator
from .squeeze import SqueezeOperator
from .strided_slice import StridedSliceOperator
from .tanh import TanhOperator
from .transpose_conv import TransposeConvOperator
from .transpose import TransposeOperator
from .reverse_v2 import ReverseV2Operator
from .unpack import UnpackOperator
from .zeros_like import ZerosLikeOperator
from .svdf import SvdfOperator
from .ethosu_operator import EthosUOperator
from .prelu import PreluOperator
from .resize_nearest_neighbor import ResizeNearestNeighborOperator
from .abs import AbsOperator
from .sqrt import SqrtOperator
from .rsqrt import RsqrtOperator

_AOT_OPERATOR_CLASSES = [
    AddOperator,
    ArgMaxOperator,
    ArgMinOperator,
    SubOperator,
    SquaredDifferenceOperator,
    AssignVariableOperator,
    AveragePool2DOperator,
    BatchMatMulOperator,
    BatchToSpaceNDOperator,
    ComparisonOperator,
    ConcatenationOperator,
    Conv2DOperator,
    DepthwiseConv2DOperator,
    DepthToSpaceOperator,
    DequantizeOperator,
    ExpandDimsOperator,
    FillOperator,
    GatherOperator,
    GatherNdOperator,
    FullyConnectedOperator,
    HardSwishOperator,
    LeakyReluOperator,
    LogisticOperator,
    MaxPool2DOperator,
    MaximumOperator,
    MeanOperator,
    SumOperator,
    MinimumOperator,
    MulOperator,
    PackOperator,
    PadOperator,
    QuantizeOperator,
    ReadVariableOperator,
    ReduceMaxOperator,
    ReduceMinOperator,
    ReluOperator,
    ReshapeOperator,
    ShapeOperator,
    SliceOperator,
    SplitOperator,
    SoftmaxOperator,
    SpaceToBatchNDOperator,
    SpaceToDepthOperator,
    SqueezeOperator,
    StridedSliceOperator,
    TanhOperator,
    TransposeConvOperator,
    TransposeOperator,
    ReverseV2Operator,
    UnpackOperator,
    ZerosLikeOperator,
    SvdfOperator,
    EthosUOperator,
    PreluOperator,
    ResizeNearestNeighborOperator,
    AbsOperator,
    SqrtOperator,
    RsqrtOperator,
]

def register_default_aot_operators(registry: Registry[AirOpType | str, type[AotOperator]]) -> None:
    """Register all built-in AOT operators into the provided registry."""
    for op_cls in _AOT_OPERATOR_CLASSES:
        registry.register(op_cls.TYPE, op_cls, overwrite=True)
