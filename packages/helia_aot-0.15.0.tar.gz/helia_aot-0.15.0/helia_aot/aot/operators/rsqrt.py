import math
import logging
import tempfile
from pathlib import Path
from typing import Any

import numpy as np
from pydantic import TypeAdapter

from helia_aot.air import AirFixedPointScale, AirModel, AirOpType, AirOperator, AirRsqrtOptions, AirTensor, AirTensorKind
from helia_aot.platforms import SocPlatform

from .operator import AotOperator
from ..templates import load_template

logger = logging.getLogger(__name__)


ARM_RSQRT_S16_BASE_LUT_STEP = 64
ARM_RSQRT_S16_BASE_LUT_SIZE = 513
ARM_RSQRT_S16_BASE_Q_BITS = 30
RSQRT_LUT_MODES = {"per_op", "universal"}
DEFAULT_RSQRT_LUT_MODE = "per_op"
AIR_TENSOR_ADAPTER = TypeAdapter(AirTensor)


def resolve_rsqrt_lut_mode(attributes: dict[str, Any] | None = None) -> str:
    """Resolve the RSQRT LUT mode from operator attributes."""
    mode = str((attributes or {}).get("lut_mode", DEFAULT_RSQRT_LUT_MODE))
    if mode not in RSQRT_LUT_MODES:
        raise ValueError(f"Unsupported RSQRT LUT mode: {mode}. Expected one of {sorted(RSQRT_LUT_MODES)}")
    return mode


def warn_on_rsqrt_lut_mode(model: AirModel, operators_config: list | None = None) -> None:
    """Log a guidance warning when multiple INT16 RSQRT ops all use per_op mode.

    Only considers INT16 RSQRT operators; INT8 RSQRT ignores lut_mode entirely.

    Args:
        model: The AIR model to inspect.
        operators_config: The ``operators`` attribute ruleset from ConvertArgs.
    """
    from helia_aot.air.op_keys import canonical_op_key
    from helia_aot.attributes import compute_entity_attributes

    operators_config = operators_config or []
    rsqrt_ops = [
        op for op in model.operators
        if op.op_type == AirOpType.RSQRT
        and op.input_ids
        and np.dtype(model.tensors[op.input_ids[0]].dtype) == np.dtype("int16")
    ]
    if len(rsqrt_ops) <= 1:
        return

    rsqrt_type = canonical_op_key(AirOpType.RSQRT.value)
    resolved_modes = [
        resolve_rsqrt_lut_mode(
            compute_entity_attributes(
                attributes=operators_config,
                entity_type=rsqrt_type,
                entity_id=op.id,
            )
        )
        for op in rsqrt_ops
    ]
    if any(mode != DEFAULT_RSQRT_LUT_MODE for mode in resolved_modes):
        return

    logger.warning(
        "Model contains %s INT16 RSQRT ops and all resolve to `lut_mode=per_op`; "
        "consider an operator attribute such as "
        "`operators: [{type: RSQRT, attributes: {lut_mode: universal}}]` "
        "to share one LUT across RSQRT operators, but note universal mode "
        "may differ from TFLite by 1-2 LSBs.",
        len(rsqrt_ops),
    )


def _count_leading_zeros_u32(x: int) -> int:
    """Return number of leading zeros for a 32-bit unsigned integer."""
    x &= 0xFFFFFFFF
    if x == 0:
        return 32
    return 32 - x.bit_length()


def _doubling_high_mult_no_sat(m1: int, m2: int) -> int:
    mult = (1 << 30) + (int(m1) * int(m2))
    return int(mult >> 31)


def _divide_by_power_of_two(dividend: int, exponent: int) -> int:
    if exponent <= 0:
        return int(dividend)
    remainder_mask = (1 << exponent) - 1
    remainder = remainder_mask & dividend
    result = int(dividend) >> exponent
    threshold = remainder_mask >> 1
    if result < 0:
        threshold += 1
    if remainder > threshold:
        result += 1
    return int(result)


def _requantize(val: int, multiplier: int, shift: int) -> int:
    left_shift = shift if shift > 0 else 0
    right_shift = 0 if shift > 0 else -shift
    multiplied = _doubling_high_mult_no_sat(int(val) * (1 << left_shift), int(multiplier))
    return _divide_by_power_of_two(multiplied, right_shift)


def _get_inv_sqrt_quantized_multiplier_exp(input_value: int, reverse_shift: int) -> tuple[int, int]:
    if input_value <= 1:
        return np.iinfo(np.int32).max, 0

    output_shift = 11
    while input_value >= (1 << 29):
        input_value //= 4
        output_shift += 1

    max_left_shift_bits = _count_leading_zeros_u32(input_value) - 1
    max_left_shift_bit_pairs = max_left_shift_bits // 2
    left_shift_bit_pairs = max_left_shift_bit_pairs - 1
    output_shift -= left_shift_bit_pairs
    input_value <<= 2 * left_shift_bit_pairs

    fixedpoint_input = float(input_value >> 1) / float(1 << 28)
    fixedpoint_half_input = fixedpoint_input * 0.5
    x = 1.0
    for _ in range(5):
        x = 1.5 * x - fixedpoint_half_input * x * x * x
    x *= 0.7071067811865476

    raw = int(round(x * float(1 << 28)))
    raw = min(max(raw, np.iinfo(np.int32).min), np.iinfo(np.int32).max)
    output_inv_sqrt = int(raw)

    if output_shift < 0:
        left = -output_shift
        if left >= 31:
            output_inv_sqrt = np.iinfo(np.int32).max
        else:
            output_inv_sqrt <<= left
        output_shift = 0

    output_shift *= reverse_shift
    return output_inv_sqrt, int(output_shift)


def make_rsqrt_lut_s8(
    input_scale: float,
    input_zero_point: int,
    output_scale: float,
    output_zero_point: int,
) -> np.ndarray:
    """Build a 256-entry int8 RSQRT LUT using fixed-point emulation."""
    lut = np.zeros(256, dtype=np.int8)
    output_fp = AirFixedPointScale.from_real_multiplier(1.0 / (math.sqrt(input_scale) * output_scale))

    k_shift = 20
    k_reverse_shift = -1
    k_min = np.int8(-128)
    k_max = np.int8(127)

    for i in range(-128, 128):
        if i < input_zero_point:
            final_val = k_max
        else:
            value = i - input_zero_point
            if value == 0:
                final_val = k_max
            else:
                inv_sqrt_multiplier, inv_sqrt_shift = _get_inv_sqrt_quantized_multiplier_exp(
                    value, k_reverse_shift
                )
                data = _requantize(1, inv_sqrt_multiplier, inv_sqrt_shift + k_shift)
                out_val = _requantize(data, output_fp.multiplier, output_fp.shift - k_shift) + output_zero_point
                final_val = min(max(out_val, k_min), k_max)

        lut[i & 0xFF] = np.int8(final_val)

    return lut


def make_universal_rsqrt_lut_s16() -> np.ndarray:
    """Build a universal RSQRT base LUT shared by all INT16 operators.

    The table stores ``1 / sqrt(q)`` in Q30 for positive quantized values ``q``
    sampled every 64 steps. Per-operator output scaling is applied later during
    code generation/runtime.
    """

    lut = np.zeros(ARM_RSQRT_S16_BASE_LUT_SIZE, dtype=np.int32)
    for index in range(1, ARM_RSQRT_S16_BASE_LUT_SIZE):
        q_value = min(index * ARM_RSQRT_S16_BASE_LUT_STEP, np.iinfo(np.int16).max)
        lut[index] = int(round((1.0 / math.sqrt(q_value)) * (1 << ARM_RSQRT_S16_BASE_Q_BITS)))
    return lut


def _build_rsqrt_tflite_bytes(input_scale: float, output_scale: float, width: int) -> bytes:
    """Build a minimal TFLite flatbuffer with one RSQRT op and exact quant params."""
    import flatbuffers
    from helia_aot.litert import schema_py_generated as schema_fb

    model = schema_fb.ModelT()
    model.version = 3
    model.description = "rsqrt_probe"

    buf0 = schema_fb.BufferT()
    buf0.data = None
    buf1 = schema_fb.BufferT()
    buf1.data = None
    buf2 = schema_fb.BufferT()
    buf2.data = None
    model.buffers = [buf0, buf1, buf2]

    inp_t = schema_fb.TensorT()
    inp_t.shape = [1, width]
    inp_t.type = schema_fb.TensorType.INT16
    inp_t.buffer = 1
    inp_t.name = "input"
    inp_q = schema_fb.QuantizationParametersT()
    inp_q.scale = [input_scale]
    inp_q.zeroPoint = [0]
    inp_t.quantization = inp_q

    out_t = schema_fb.TensorT()
    out_t.shape = [1, width]
    out_t.type = schema_fb.TensorType.INT16
    out_t.buffer = 2
    out_t.name = "output"
    out_q = schema_fb.QuantizationParametersT()
    out_q.scale = [output_scale]
    out_q.zeroPoint = [0]
    out_t.quantization = out_q

    op_code = schema_fb.OperatorCodeT()
    op_code.builtinCode = schema_fb.BuiltinOperator.RSQRT
    op_code.deprecatedBuiltinCode = 76
    model.operatorCodes = [op_code]

    op = schema_fb.OperatorT()
    op.opcodeIndex = 0
    op.inputs = [0]
    op.outputs = [1]

    sg = schema_fb.SubGraphT()
    sg.tensors = [inp_t, out_t]
    sg.inputs = [0]
    sg.outputs = [1]
    sg.operators = [op]
    sg.name = "main"
    model.subgraphs = [sg]

    builder = flatbuffers.Builder(1024)
    model_offset = model.Pack(builder)
    builder.Finish(model_offset, b"TFL3")
    return bytes(builder.Output())


def extract_per_op_rsqrt_lut_s16(input_scale: float, output_scale: float) -> np.ndarray:
    """Extract a 513-entry INT16 RSQRT LUT by probing a throwaway TFLite model.

    Builds a minimal single-op TFLite model with the given quantization
    parameters and feeds grid-aligned inputs (frac=0) so that TFLite returns
    the exact LUT entries.  This guarantees bit-exact agreement with TFLite's
    ``LUTPopulate<int16_t>`` (float32 arithmetic) without reimplementing its
    rounding in Python.

    The positive domain (LUT indices 257-511) is probed directly.  The negative
    domain (indices 0-256, never accessed by valid RSQRT inputs) and the last
    endpoint (index 512) are computed in float32 to match TFLite's Prepare().

    Args:
        input_scale: Quantization scale for the INT16 input tensor.
        output_scale: Quantization scale for the INT16 output tensor.

    Returns:
        A 513-entry INT16 LUT matching TFLite's internal table.
    """
    from helia_aot.litert.interpreter import Interpreter
    import os

    _SLOT_SHIFT = 7
    _LUT_SIZE = 513

    # --- Probe positive domain (indices 257..511) via TFLite ---
    positive_count = 255  # indices 257..511
    probe_values = np.array(
        [(i - 256) << _SLOT_SHIFT for i in range(257, 512)],
        dtype=np.int16,
    )

    model_bytes = _build_rsqrt_tflite_bytes(input_scale, output_scale, width=positive_count)

    fd, tmp_path = tempfile.mkstemp(suffix=".tflite")
    os.close(fd)
    try:
        Path(tmp_path).write_bytes(model_bytes)
        interp = Interpreter(model_path=tmp_path)
        interp.allocate_tensors()
        inp_det = interp.get_input_details()[0]
        out_det = interp.get_output_details()[0]

        interp.set_tensor(inp_det["index"], probe_values.reshape(1, positive_count))
        interp.invoke()
        probed = interp.get_tensor(out_det["index"]).reshape(-1)[:positive_count].copy()
    finally:
        os.unlink(tmp_path)

    # --- Compute negative domain + endpoint in float32 (matches TFLite Prepare) ---
    INT16_MIN_F = np.float32(-32768)
    INT16_MAX_F = np.float32(32767)

    inp_min = np.float32(input_scale) * INT16_MIN_F
    inp_max = np.float32(input_scale) * INT16_MAX_F
    out_min = np.float32(output_scale) * INT16_MIN_F
    out_max = np.float32(output_scale) * INT16_MAX_F

    out_scale_inv = np.float32(65536.0) / (out_max - out_min)
    step = (inp_max - inp_min) / np.float32(512.0)
    half = step / np.float32(2.0)

    def _rsqrt(x: float) -> float:
        return (float(INT16_MAX_F) * float(output_scale)) if x <= 0.0 else (1.0 / math.sqrt(x))

    lut = np.zeros(_LUT_SIZE, dtype=np.int16)

    for i in range(257):  # negative + zero domain
        x0 = np.float32(inp_min + np.float32(i) * step)
        xmid = np.float32(x0 + half)
        x1 = np.float32(x0 + step)

        s0 = np.float32(np.round(np.float32(_rsqrt(float(x0))) * out_scale_inv))
        s1 = np.float32(np.round(np.float32(_rsqrt(float(x1))) * out_scale_inv))
        sm = np.float32(np.round(np.float32(_rsqrt(float(xmid))) * out_scale_inv))

        mid_interp = np.float32(np.round((s1 + s0) / np.float32(2.0)))
        bias = np.float32(np.round((mid_interp - sm) / np.float32(2.0)))
        lut[i] = np.int16(int(np.clip(np.round(s0 - bias), -32768, 32767)))

    # Positive domain from TFLite probe
    lut[257:512] = probed

    # Last endpoint
    vend = np.float32(_rsqrt(float(inp_max)))
    lut[512] = np.int16(int(np.clip(np.round(np.float32(vend * out_scale_inv)), -32768, 32767)))

    return lut


def compute_rsqrt_scale_s16(input_scale: float, output_scale: float) -> AirFixedPointScale:
    """Compute the fixed-point scale for the universal RSQRT base LUT.

    The shared LUT stores base samples in Q30 for ``1 / sqrt(q)`` where
    ``x_real = input_scale * q``.

    RSQRT in real space is:

    ``y_real = 1 / sqrt(x_real)``
    ``       = 1 / sqrt(input_scale * q)``
    ``       = (1 / sqrt(input_scale)) * (1 / sqrt(q))``

    Output quantization is:

    ``y_real = output_scale * y_q``
    ``y_q = y_real / output_scale``

    Combining both gives:

    ``y_q = (1 / (output_scale * sqrt(input_scale))) * (1 / sqrt(q))``

    The LUT stores ``2^30 * (1 / sqrt(q))``, so converting that LUT value into
    the quantized output domain requires one extra division by ``2^30``:

    ``real_multiplier = 1 / (output_scale * sqrt(input_scale) * 2^30)``

    This real multiplier is then converted into the CMSIS-NN fixed-point pair
    ``(multiplier, shift)`` via ``AirFixedPointScale.from_real_multiplier``,
    and the generated C passes that pair to ``arm_rsqrt_s16_universal(...)``.

    Args:
        input_scale: Quantization scale for the INT16 input tensor.
        output_scale: Quantization scale for the INT16 output tensor.

    Returns:
        Fixed-point multiplier/shift pair for the universal INT16 RSQRT path,
        passed to ``arm_rsqrt_s16_universal(...)``.
    """
    real_multiplier = 1.0 / (output_scale * math.sqrt(input_scale) * (1 << ARM_RSQRT_S16_BASE_Q_BITS))
    return AirFixedPointScale.from_real_multiplier(real_multiplier)


class RsqrtOperator(AotOperator):
    TYPE: AirOpType = AirOpType.RSQRT

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0
    kLutTensorName: str = "lut"
    kUniversalLutTensorId: str = "rsqrt_s16_universal_lut"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] | None = None,
    ):
        """RSQRT operator with configurable INT16 LUT mode."""
        super().__init__(op, model, platform, prefix, attributes or {})

    @property
    def lut_mode(self) -> str:
        """Return the configured RSQRT LUT mode."""
        return resolve_rsqrt_lut_mode(self.attributes.__dict__)

    def validate(self):
        assert isinstance(self.op.options, AirRsqrtOptions)

        if len(self.input_tensors) != 1:
            raise ValueError("RSQRT operator must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError("RSQRT operator must have exactly one output tensor.")

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        input_dtype = np.dtype(input_tensor.dtype)
        output_dtype = np.dtype(output_tensor.dtype)
        if input_dtype != output_dtype:
            raise ValueError("RSQRT input and output tensors must have matching dtypes.")
        if input_dtype not in {np.dtype(np.int8), np.dtype(np.int16)}:
            raise ValueError("RSQRT operator currently supports INT8 and INT16 input/output only.")

        if input_tensor.shape != output_tensor.shape:
            raise ValueError("RSQRT input and output tensors must have the same shape.")

        if input_tensor.quantization is None or output_tensor.quantization is None:
            raise ValueError("RSQRT input and output tensors must have quantization parameters.")

        for label, tensor in [("input", input_tensor), ("output", output_tensor)]:
            q = tensor.quantization
            if q.scale is None or len(q.scale) == 0:
                raise ValueError(f"RSQRT {label} tensor must have a quantization scale.")
            if q.zero_point is None or len(q.zero_point) == 0:
                raise ValueError(f"RSQRT {label} tensor must have a quantization zero_point.")

        if input_dtype == np.dtype(np.int16):
            if input_tensor.quantization.zero_point[0] != 0:
                raise ValueError("RSQRT INT16 input zero_point must be 0.")
            if output_tensor.quantization.zero_point[0] != 0:
                raise ValueError("RSQRT INT16 output zero_point must be 0.")

    def on_resolve(self):
        self.validate()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        if np.dtype(input_tensor.dtype) == np.dtype(np.int8):
            return

        if self.lut_mode == "universal":
            if self.kUniversalLutTensorId not in self.model.tensors:
                lut_data = make_universal_rsqrt_lut_s16()
                lut_tensor_kwargs = {
                    "id": self.kUniversalLutTensorId,
                    "kind": AirTensorKind.CONSTANT,
                    "shape": lut_data.shape,
                    "dtype": lut_data.dtype,
                }
                lut_tensor = AIR_TENSOR_ADAPTER.validate_python(lut_tensor_kwargs)
                lut_tensor.data = lut_data
                self.model.add_tensor(lut_tensor)
            self.op.named_tensors[self.kLutTensorName] = self.kUniversalLutTensorId
            return

        lut_tensor_id = f"{self.name}_lut"
        if lut_tensor_id not in self.model.tensors:
            lut_data = extract_per_op_rsqrt_lut_s16(
                input_scale=float(input_tensor.quantization.scale[0]),
                output_scale=float(output_tensor.quantization.scale[0]),
            )
            lut_tensor_kwargs = {
                "id": lut_tensor_id,
                "kind": AirTensorKind.CONSTANT,
                "shape": lut_data.shape,
                "dtype": lut_data.dtype,
            }
            lut_tensor = AIR_TENSOR_ADAPTER.validate_python(lut_tensor_kwargs)
            lut_tensor.data = lut_data
            self.model.add_tensor(lut_tensor)

        self.op.named_tensors[self.kLutTensorName] = lut_tensor_id

    def compute_values(self) -> dict[str, str]:
        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        if np.dtype(input_tensor.dtype) == np.dtype(np.int8):
            rsqrt_lut = make_rsqrt_lut_s8(
                input_scale=float(input_tensor.quantization.scale[0]),
                input_zero_point=int(input_tensor.quantization.zero_point[0]),
                output_scale=float(output_tensor.quantization.scale[0]),
                output_zero_point=int(output_tensor.quantization.zero_point[0]),
            )
            sub_values.update(
                dict(
                    input_tensor=input_tensor,
                    output_tensor=output_tensor,
                    rsqrt_lut=rsqrt_lut,
                )
            )
            return sub_values

        lut_tensor = self.get_local_tensor(self.kLutTensorName)
        if self.lut_mode == "universal":
            output_fp = compute_rsqrt_scale_s16(
                input_scale=float(input_tensor.quantization.scale[0]),
                output_scale=float(output_tensor.quantization.scale[0]),
            )
            needs_rescale = not (output_fp.multiplier == (1 << 31) - 1 and output_fp.shift == 0)
        else:
            real_multiplier = 1.0
            output_fp = AirFixedPointScale.from_real_multiplier(real_multiplier)
            needs_rescale = False

        sub_values.update(
            dict(
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                lut_tensor=lut_tensor,
                output_fp=output_fp,
                lut_mode=self.lut_mode,
                input_offset=int(input_tensor.quantization.zero_point[0]),
                output_offset=int(output_tensor.quantization.zero_point[0]),
                needs_rescale=needs_rescale,
                activation_min=int(np.iinfo(np.int16).min),
                activation_max=int(np.iinfo(np.int16).max),
                block_size=int(output_tensor.size),
            )
        )
        return sub_values

    def emit(self, save_path: Path):
        sub_values = self.compute_values()

        hdr_template = load_template("rsqrt.h")
        src_template = load_template("rsqrt.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w", encoding="utf-8") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w", encoding="utf-8") as f:
            f.write(src_code)
