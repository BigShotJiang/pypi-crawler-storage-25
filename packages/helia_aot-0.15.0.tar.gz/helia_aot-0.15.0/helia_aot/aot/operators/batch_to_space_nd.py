from pathlib import Path
from helia_aot.air import AirOpType, AirModel, AirOperator, AirBatchToSpaceNDOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class BatchToSpaceNDOperator(AotOperator):

    TYPE: AirOpType = AirOpType.BATCH_TO_SPACE_ND

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """BATCH_TO_SPACE_ND operator.

        This operator rearranges the input tensor from batch-major to space-major order.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        sub_values.update(dict(
            options=self.op.options,
            input_tensor=input_tensor,
            output_tensor=output_tensor,
        ))

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirBatchToSpaceNDOptions)
        if len(self.input_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")

        input_tensor = self.input_tensors[self.kInputTensorIndex]

        input_shape = tuple(int(dim) for dim in input_tensor.shape)
        spatial_dims_num = len(input_shape) - 2
        if spatial_dims_num not in (1, 2):
            raise ValueError(
                f"{self.TYPE} operator ({self.id}) expects input rank 3 or 4, got rank {len(input_shape)}."
            )

        block_shape = tuple(int(dim) for dim in self.op.options.block_shape)
        if len(block_shape) != spatial_dims_num:
            raise ValueError(
                f"{self.TYPE} operator ({self.id}) block_shape rank {len(block_shape)} "
                f"must equal spatial dims {spatial_dims_num}."
            )

        crops = self.op.options.crops
        crops_by_dim = (
            (int(crops.top), int(crops.bottom)),
            (int(crops.left), int(crops.right)),
        )
        for dim in range(spatial_dims_num):
            crop_before, crop_after = crops_by_dim[dim]
            if crop_before < 0 or crop_after < 0:
                raise ValueError(
                    f"{self.TYPE} operator ({self.id}) crops for dim {dim} must be non-negative, "
                    f"got ({crop_before}, {crop_after})."
                )

        output_batch_size = int(input_shape[0])
        for dim in range(spatial_dims_num):
            block_dim = block_shape[dim]
            if block_dim == 0:
                raise ValueError(
                    f"{self.TYPE} operator ({self.id}) block_shape[{dim}] must be non-zero."
                )
            if output_batch_size % block_dim != 0:
                raise ValueError(
                    f"{self.TYPE} operator ({self.id}) batch size ({output_batch_size}) "
                    f"is not divisible by block_shape[{dim}] ({block_dim})."
                )
            output_batch_size //= block_dim

            crop_before, crop_after = crops_by_dim[dim]
            out_dim = int(input_shape[dim + 1]) * block_dim - crop_before - crop_after
            if out_dim <= 0:
                raise ValueError(
                    f"{self.TYPE} operator ({self.id}) computed non-positive output dim {out_dim} "
                    f"for spatial dim {dim + 1}."
                )

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("batch_to_space_nd.h")
        src_template = load_template("batch_to_space_nd.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
