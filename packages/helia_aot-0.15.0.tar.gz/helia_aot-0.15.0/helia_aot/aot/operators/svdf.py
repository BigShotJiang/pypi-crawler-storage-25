from pathlib import Path
import numpy as np

from helia_aot.air import (
    AirOpType,
    AirModel,
    AirOperator,
    AirTensor,
    AirTensorKind,
    AirFixedPointScale,
    AirSvdfOptions,
)
from helia_aot.platforms import SocPlatform, SocCapability
from .operator import AotOperator
from ..templates import load_template


class SvdfOperator(AotOperator):
    TYPE: AirOpType = AirOpType.SVDF

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0
    # Local tensors
    kWeightsFeatureTensorName = "weights_feature"
    kWeightsTimeTensorName = "weights_time"
    kBiasTensorName = "bias"
    kStateTensorName = "state"

    # Scratch / aux buffers
    kScratchATensorName = "scratch_a"   # maps to input_ctx->buf (int32)
    kScratchBTensorName = "scratch_b"   # maps to output_ctx->buf (int32)
    kWeightSumTensorName = "weight_sum" # maps to ctx->buf (int32 kernel sums)

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """SVDF operator."""
        super().__init__(op, model, platform, prefix, attributes)

    def compute_scratch_a_size(self) -> int:
        """Bytes for input_ctx->buf (buffer_a): (batches * num_filters * sizeof(int32))"""
        batches = int(self.input_tensors[self.kInputTensorIndex].shape[0])
        num_filters = int(self.get_local_tensor(self.kWeightsFeatureTensorName).shape[0])
        return (batches * num_filters * 4)

    def compute_scratch_b_size(self) -> int:
        """Bytes for input_ctx->buf (buffer_b): (batches * num_filters * sizeof(int32))"""
        batches = int(self.input_tensors[self.kInputTensorIndex].shape[0])
        num_filters = int(self.get_local_tensor(self.kWeightsFeatureTensorName).shape[0])
        rank = int(self.op.options.rank)
        num_units = num_filters // rank
        return (batches * num_units * 4)

    def compute_weight_sum_size(self) -> int:
        """Bytes for ctx->buf (kernel_sum_data): num_filters * sizeof(int32) if MVE, else 0."""
        num_filters = int(self.get_local_tensor(self.kWeightsFeatureTensorName).shape[0])
        return (num_filters * 4) if (SocCapability.MVE in self.platform.capabilities) else 0


    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator."""
        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        weights_feature_tensor = self.get_local_tensor(self.kWeightsFeatureTensorName)
        weights_time_tensor = self.get_local_tensor(self.kWeightsTimeTensorName)

        bias_tensor = None
        if self.kBiasTensorName in self.op.named_tensors:
            bias_tensor = self.get_local_tensor(self.kBiasTensorName)

        state_tensor = None
        if self.kStateTensorName in self.op.named_tensors:
            state_tensor = self.get_local_tensor(self.kStateTensorName)

        scratch_a_tensor = self.get_local_tensor(self.kScratchATensorName) if self.kScratchATensorName in self.op.named_tensors else None
        scratch_b_tensor = self.get_local_tensor(self.kScratchBTensorName) if self.kScratchBTensorName in self.op.named_tensors else None
        weight_sum_tensor = self.get_local_tensor(self.kWeightSumTensorName) if self.kWeightSumTensorName in self.op.named_tensors else None

        # Quantization params
        S_in = float(input_tensor.quantization.scale[0])
        S_wf = float(weights_feature_tensor.quantization.scale[0])
        S_wt = float(weights_time_tensor.quantization.scale[0])
        S_out = float(output_tensor.quantization.scale[0])
        S_state = float(state_tensor.quantization.scale[0])

        # Bias scale check (matches TFLM rule): S_bias == S_state * S_wt
        if bias_tensor is not None:
            S_bias = float(bias_tensor.quantization.scale[0])
            if abs(S_bias - (S_state * S_wt)) > 1e-5:
                raise ValueError(
                    f"SVDF bias scale mismatch: bias={S_bias} vs state*wt={S_state * S_wt}"
                )

        # Two-stage quantization
        real_multiplier_in = (S_in * S_wf) / S_state
        input_fp = AirFixedPointScale.from_real_multiplier(real_multiplier_in)

        real_multiplier_out = (S_state * S_wt) / S_out
        output_fp = AirFixedPointScale.from_real_multiplier(real_multiplier_out)

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                weights_feature_tensor=weights_feature_tensor,
                weights_time_tensor=weights_time_tensor,
                bias_tensor=bias_tensor,
                state_tensor=state_tensor,
                scratch_a_tensor=scratch_a_tensor,
                scratch_b_tensor=scratch_b_tensor,
                weight_sum_tensor=weight_sum_tensor,
                input_fp=input_fp,
                output_fp=output_fp,
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirSvdfOptions)

        # Rank and divisibility
        rank = int(self.op.options.rank)
        if rank <= 0:
            raise ValueError(f"SVDF rank must be > 0, got {rank}")

        # Required tensors
        if self.kWeightsFeatureTensorName not in self.op.named_tensors:
            raise KeyError(f"Operator {self.op.id} missing weights_feature")
        if self.kWeightsTimeTensorName not in self.op.named_tensors:
            raise KeyError(f"Operator {self.op.id} missing weights_time")
        if self.kStateTensorName not in self.op.named_tensors:
            raise KeyError(f"Operator {self.op.id} missing state tensor")

        # Exactly one input and one output
        if len(self.input_tensors) != 1:
            raise ValueError("SVDF must have exactly one input tensor")
        if len(self.output_tensors) != 1:
            raise ValueError("SVDF must have exactly one output tensor")

        # DType support
        in_dt = self.input_tensors[self.kInputTensorIndex].dtype
        out_dt = self.output_tensors[self.kOutputTensorIndex].dtype
        if in_dt != out_dt:
            raise ValueError("SVDF input and output dtypes must match")
        if in_dt not in [np.int8]:
            raise ValueError("SVDF currently supports int8 inputs only")

        # Shape/rank checks for units = num_filters / rank
        num_filters = int(self.get_local_tensor(self.kWeightsFeatureTensorName).shape[0])
        if num_filters % rank != 0:
            raise ValueError(f"num_filters ({num_filters}) must be divisible by rank ({rank})")

    def on_resolve(self):
        self.validate()

        # Allocate scratch buffer a (input_ctx->buf)
        bytes_a = self.compute_scratch_a_size()
        if bytes_a > 0:
            scratch_a = AirTensor(
                id=f"{self.name}_{self.kScratchATensorName}",
                kind=AirTensorKind.SCRATCH,
                shape=(bytes_a,),
                dtype=np.int8,
                alignment_hint=16,
            )
            self.op.named_tensors[self.kScratchATensorName] = scratch_a.id
            self.model.add_tensor(scratch_a)

        # Allocate scratch B (output_ctx->buf)
        bytes_b = self.compute_scratch_b_size()
        if bytes_b > 0:
            scratch_b = AirTensor(
                id=f"{self.name}_{self.kScratchBTensorName}",
                kind=AirTensorKind.SCRATCH,
                shape=(bytes_b,),
                dtype=np.int8,
                alignment_hint=16,
            )
            self.op.named_tensors[self.kScratchBTensorName] = scratch_b.id
            self.model.add_tensor(scratch_b)

        # Allocate kernel-sum buffer (ctx->buf)
        weight_sum_bytes = self.compute_weight_sum_size()
        if weight_sum_bytes > 0:
            weight_sum = AirTensor(
                id=f"{self.name}_{self.kWeightSumTensorName}",
                kind=AirTensorKind.PERSISTENT,
                shape=(weight_sum_bytes,),
                dtype=np.int8,
            )
            self.op.named_tensors[self.kWeightSumTensorName] = weight_sum.id
            self.model.add_tensor(weight_sum)

    def emit(self, save_path: Path):
        """Generate the source code for the operator."""
        sub_values = self.compute_values()

        hdr_template = load_template("svdf.h")
        src_template = load_template("svdf.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
