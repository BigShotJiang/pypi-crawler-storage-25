from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirMinimumOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class MinimumOperator(AotOperator):
    TYPE: AirOpType = AirOpType.MINIMUM

    kInputTensorIndex1: int = 0
    kInputTensorIndex2: int = 1
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """MINIMUM operator.

        This operator computes the element-wise minimum of two tensors or tensor with scalar.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input1_tensor = self.input_tensors[self.kInputTensorIndex1]
        input2_tensor = self.input_tensors[self.kInputTensorIndex2]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        sub_values.update(
            dict(
                options=self.op.options,
                input1_tensor=input1_tensor,
                input2_tensor=input2_tensor,
                output_tensor=output_tensor,
            )
        )

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirMinimumOptions)
        if len(self.input_tensors) != 2:
            raise ValueError(f"{self.TYPE} operator ({self.id}) requires exactly two input tensors.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")

        is_input1_scalar = self.input_tensors[self.kInputTensorIndex1].size == 1
        is_input2_scalar = self.input_tensors[self.kInputTensorIndex2].size == 1
        if is_input1_scalar and is_input2_scalar:
            raise ValueError("Both inputs cannot be scalars.")

        if self.input_tensors[self.kInputTensorIndex1].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input tensor dtype", self.input_tensors[self.kInputTensorIndex1].dtype)
        if self.input_tensors[self.kInputTensorIndex2].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input tensor dtype", self.input_tensors[self.kInputTensorIndex2].dtype)
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported output tensor dtype", self.output_tensors[self.kOutputTensorIndex].dtype)

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("minimum.h")
        src_template = load_template("minimum.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
