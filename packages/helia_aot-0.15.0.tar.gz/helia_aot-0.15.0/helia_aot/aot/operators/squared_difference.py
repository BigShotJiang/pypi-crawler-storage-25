from pathlib import Path

import numpy as np

from helia_aot.air import (
    AirActivationType,
    AirFixedPointScale,
    AirModel,
    AirOpType,
    AirOperator,
    AirSquaredDifferenceOptions,
)
from helia_aot.platforms import SocPlatform

from .operator import AotOperator
from ..templates import load_template


class SquaredDifferenceOperator(AotOperator):
    """AOT code generator for SQUARED_DIFFERENCE."""

    TYPE: AirOpType = AirOpType.SQUARED_DIFFERENCE

    kInput1TensorIndex: int = 0
    kInput2TensorIndex: int = 1
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] | None = None,
    ):
        super().__init__(op, model, platform, prefix, attributes or {})

    def validate(self):
        assert isinstance(self.op.options, AirSquaredDifferenceOptions)
        if len(self.input_tensors) != 2:
            raise ValueError(
                f"{self.TYPE} operator ({self.id}) requires exactly 2 input tensors, "
                f"got {len(self.input_tensors)}."
            )
        if len(self.output_tensors) != 1:
            raise ValueError(
                f"{self.TYPE} operator ({self.id}) requires exactly 1 output tensor, "
                f"got {len(self.output_tensors)}."
            )

        input1_tensor = self.input_tensors[self.kInput1TensorIndex]
        input2_tensor = self.input_tensors[self.kInput2TensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        for tensor in (input1_tensor, input2_tensor, output_tensor):
            if tensor.dtype not in (np.int8, np.int16):
                raise ValueError(
                    f"Unsupported tensor dtype for SQUARED_DIFFERENCE: {tensor.dtype}"
                )

        if input1_tensor.dtype != input2_tensor.dtype or input1_tensor.dtype != output_tensor.dtype:
            raise ValueError("SQUARED_DIFFERENCE input and output dtypes must match")

    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, str]:
        sub_values = super().compute_values()

        input1_tensor = self.input_tensors[self.kInput1TensorIndex]
        input2_tensor = self.input_tensors[self.kInput2TensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        if output_tensor.dtype == np.int8:
            left_shift = 7
        else:
            left_shift = 0

        input1_scale = input1_tensor.quantization.scale[0]
        input2_scale = input2_tensor.quantization.scale[0]
        output_scale = output_tensor.quantization.scale[0]

        twice_max_input_scale = 2.0 * max(input1_scale, input2_scale)
        real_input1_multiplier = input1_scale / twice_max_input_scale
        real_input2_multiplier = input2_scale / twice_max_input_scale
        real_output_multiplier = (twice_max_input_scale * twice_max_input_scale) / ((1 << (left_shift * 2)) * output_scale)

        input1_fp = AirFixedPointScale.from_real_multiplier(real_input1_multiplier)
        input2_fp = AirFixedPointScale.from_real_multiplier(real_input2_multiplier)
        output_fp = AirFixedPointScale.from_real_multiplier(real_output_multiplier)
        activation_min, activation_max = AirActivationType.NONE.compute_range(
            output_zero_point=output_tensor.quantization.zero_point[0],
            output_scale=output_scale,
            dtype=output_tensor.dtype,
        )

        sub_values.update(
            dict(
                input1_tensor=input1_tensor,
                input2_tensor=input2_tensor,
                output_tensor=output_tensor,
                input1_fp=input1_fp,
                input2_fp=input2_fp,
                output_fp=output_fp,
                left_shift=left_shift,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )
        return sub_values

    def emit(self, save_path: Path):
        sub_values = self.compute_values()

        hdr_template = load_template("squared_difference.h")
        src_template = load_template("squared_difference.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
