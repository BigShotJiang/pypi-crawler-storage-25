import functools
from pathlib import Path
import numpy as np
from datetime import date
from pydantic.dataclasses import dataclass
from pydantic import Field, ConfigDict
from helia_aot.platforms import SocPlatform, MemoryType
from helia_aot.air import AirOperator, AirTensor, AirModel, AirOpType

from helia_aot.utils import setup_logger, get_version
# from ...defines import OperatorAttributes

logger = setup_logger(log_name=__name__)


@dataclass(config=ConfigDict(extra="allow"))
class OperatorAttributes:
    code_placement: MemoryType = Field(default=MemoryType.MRAM)
    scratch_placement: MemoryType = Field(default=MemoryType.SRAM)


def run_once(method):
    """Decorator to run a method only once per instance."""

    @functools.wraps(method)
    def wrapper(self, *args, **kwargs):
        if getattr(self, "_has_resolved", False):
            return
        result = method(self, *args, **kwargs)
        self._has_resolved = True
        return result

    return wrapper


class AotMeta(type):
    def __setattr__(cls, name, value):
        if name.isupper() and name in cls.__dict__:
            raise AttributeError(f"{name!r} is read-only")
        super().__setattr__(name, value)


class AotOperator(metaclass=AotMeta):
    TYPE: AirOpType = AirOpType.OPERATOR

    op: AirOperator
    model: AirModel
    platform: SocPlatform
    prefix: str
    attributes: OperatorAttributes

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """Base class for all AOT operators.

        Execution flow:
        1. Initialize the operator.
        2. Call `resolve()` to validate and prepare the operator.
        3. Call `plan()` to set up any necessary planning.
        4. Call `emit()` to generate the operator's code.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        self.op = op
        self.model = model
        self.platform = platform
        self.prefix = prefix
        self.attributes = OperatorAttributes(**attributes)

    @property
    def id(self) -> str:
        """Return the operator ID."""
        return self.op.id

    @property
    def name(self) -> str:
        """Return the operator name."""
        return f"{self.TYPE.lower()}_{self.op.id}"

    @property
    def input_tensors(self) -> list[AirTensor]:
        """Return the input tensors."""
        return [self.model.get_tensor(tensor_id) for tensor_id in self.op.input_ids]

    @property
    def output_tensors(self) -> list[AirTensor]:
        """Return the output tensors."""
        return [self.model.get_tensor(tensor_id) for tensor_id in self.op.output_ids]

    @property
    def local_tensors(self) -> list[AirTensor]:
        """Get all local tensors used by the operator."""
        return [self.model.get_tensor(tensor_id) for tensor_id in self.op.named_tensors.values()]

    def get_local_tensor(self, name: str) -> AirTensor:
        """Get a local tensor by name."""
        if name not in self.op.named_tensors:
            raise KeyError(f"Local tensor '{name}' not found in operator '{self.op.id}'")
        return self.model.get_tensor(self.op.named_tensors[name])

    def validate(self):
        """Validate the operator configuration."""
        pass

    @run_once
    def resolve(self):
        """Public entry point—only runs once, even if called repeatedly.

        This method validates the AIR operator and performs any model mutations needed.

        """
        self.on_resolve()

    def on_resolve(self):
        """Override this in subclasses to do the actual work."""
        pass

    def plan(self):
        """Operator planning step."""
        pass

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator source code template.

        Args:

        Returns:
            dict[str, str]: Dictionary of values for the operator template.
        """
        sub_values = dict(
            id=self.op.id,
            prefix=self.prefix,
            name=self.name,
            filename=f"{self.prefix}_{self.name}",
            op_name=self.name,
            op_type=self.TYPE.lower(),
            generation_date=date.today().isoformat(),
            copyright_year=str(date.today().year),
            tool_version=get_version(),
        )
        return sub_values

    def print_info(self, verbose: int = 0):
        """Debug print the template values for the operator."""
        if verbose <= 0:
            pass
        elif verbose <= 2:
            logger.info(f"  • Operator {self.TYPE} (id: {self.op.id})")
        else:
            logger.info(f"[bold]Operator {self.TYPE} (id: {self.op.id})[/]")
            logger.debug(f"{120 * '='}")
            logger.debug("  Inputs/Outputs:")
            logger.debug(f"    • Inputs: ({[input_tensor.shape for input_tensor in self.input_tensors]})")
            logger.debug(f"    • Outputs: ({[output_tensor.shape for output_tensor in self.output_tensors]})")
            logger.debug("  Template values:")
            values = self.compute_values()
            for key, value in values.items():
                if isinstance(value, (np.ndarray, list)):
                    logger.debug(f"    • {key}: {len(value)}")
                # if string display only first 100 characters
                elif isinstance(value, str):
                    logger.debug(f"    • {key}: {value[:100]}")
                else:
                    logger.debug(f"    • {key}: {value}")
            logger.debug(f"Attributes: {self.attributes.json()}")
            logger.debug(f"{120 * '='}")

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        This method should be overridden by subclasses.

        Args:
            save_path (Path): Path to save the generated source code.
        """
        raise NotImplementedError("Subclasses should implement this method.")
