from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirFixedPointScale, AirLeakyReluOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class LeakyReluOperator(AotOperator):
    TYPE: AirOpType = AirOpType.LEAKY_RELU

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """LEAKY_RELU operator.

        This operator computes the Leaky ReLU activation function on the input tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        alpha_multiplier = (
            input_tensor.quantization.scale[0] * self.op.options.alpha / output_tensor.quantization.scale[0]
        )
        alpha_fp = AirFixedPointScale.from_real_multiplier(alpha_multiplier)

        identity_multiplier = input_tensor.quantization.scale[0] / output_tensor.quantization.scale[0]
        identity_fp = AirFixedPointScale.from_real_multiplier(identity_multiplier)

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                alpha_fp=alpha_fp,
                identity_fp=identity_fp,
            )
        )
        return sub_values

    def validate(self):
        """Validate the operator configuration."""
        assert isinstance(self.op.options, AirLeakyReluOptions)
        assert len(self.input_tensors) == 1, "Invalid number of input tensors"
        assert len(self.output_tensors) == 1, "Invalid number of output tensors"

        if self.input_tensors[self.kInputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input tensor dtype", self.input_tensors[self.kInputTensorIndex].dtype)
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported output tensor dtype", self.output_tensors[self.kOutputTensorIndex].dtype)

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("leaky_relu.h")
        src_template = load_template("leaky_relu.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
