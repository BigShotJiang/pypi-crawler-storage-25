from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirFixedPointScale, AirAddOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class AddOperator(AotOperator):
    TYPE: AirOpType = AirOpType.ADD

    kInput1TensorIndex: int = 0
    kInput2TensorIndex: int = 1
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """ADD operator.

        This operator computes the element-wise addition of two tensors.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        assert isinstance(self.op.options, AirAddOptions)
        assert len(self.input_tensors) == 2, "ADD operator must have exactly two input tensors."
        assert len(self.output_tensors) == 1, "ADD operator must have exactly one output tensor."
        is_input1_scalar = self.input_tensors[self.kInput1TensorIndex].size == 1
        is_input2_scalar = self.input_tensors[self.kInput2TensorIndex].size == 1
        if is_input1_scalar and is_input2_scalar:
            raise ValueError("Both inputs cannot be scalars.")
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Output tensor must be int8 or int16.")

    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input1_tensor = self.input_tensors[self.kInput1TensorIndex]
        input2_tensor = self.input_tensors[self.kInput2TensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        # Compute quantization parameters
        if output_tensor.dtype == np.int16:
            left_shift = 15
        elif output_tensor.dtype == np.int8:
            left_shift = 20
        else:
            raise ValueError("Unsupported output tensor dtype", output_tensor.dtype)
        twice_max_input_scale = 2 * max(input1_tensor.quantization.scale[0], input2_tensor.quantization.scale[0])
        real_input1_multiplier = input1_tensor.quantization.scale[0] / twice_max_input_scale
        real_input2_multiplier = input2_tensor.quantization.scale[0] / twice_max_input_scale
        real_output_multiplier = twice_max_input_scale / ((1 << left_shift) * output_tensor.quantization.scale[0])

        input1_fp = AirFixedPointScale.from_real_multiplier(real_input1_multiplier)
        input2_fp = AirFixedPointScale.from_real_multiplier(real_input2_multiplier)
        output_fp = AirFixedPointScale.from_real_multiplier(real_output_multiplier)

        activation_min, activation_max = self.op.options.activation.compute_range(
            output_zero_point=output_tensor.quantization.zero_point[0],
            output_scale=output_tensor.quantization.scale[0],
            dtype=output_tensor.dtype,
        )

        sub_values.update(
            dict(
                input1_tensor=input1_tensor,
                input2_tensor=input2_tensor,
                output_tensor=output_tensor,
                input1_fp=input1_fp,
                input2_fp=input2_fp,
                output_fp=output_fp,
                left_shift=left_shift,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )

        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("add.h")
        src_template = load_template("add.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
