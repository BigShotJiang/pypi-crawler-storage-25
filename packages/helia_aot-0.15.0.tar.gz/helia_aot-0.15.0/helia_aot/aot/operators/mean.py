import math
import numpy as np
from pathlib import Path
from helia_aot.air import AirOpType, AirModel, AirOperator, AirFixedPointScale, AirMeanOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


def fold_mean_multiplier(base_fp: AirFixedPointScale, count) -> AirFixedPointScale:
    """
    Fold 1 / count into base_multiplier and shift, such that
    the result is compatible with arm_nn_requantize().

    Ensures shift is in [0, 31] and multiplier fits in Q31.

    Args:
        base_fp (AirFixedPointScale): Base fixed-point scale.
        count (int): Count to fold into the multiplier.
    """
    Q31_MAX = (1 << 31) - 1

    shift = 63 - (count.bit_length() - 1)
    shift = min(shift, 32)
    shift = min(shift, 31 + base_fp.shift)  # ensure we don't overflow Q31

    while shift >= 0:
        folded_mult = ((base_fp.multiplier << shift) + (count // 2)) // count
        if folded_mult <= Q31_MAX:
            folded_shift = base_fp.shift - shift
            return AirFixedPointScale(int(folded_mult), folded_shift)
        shift -= 1  # try smaller shift to prevent overflow

    # Fallback: use unadjusted multiplier (caller can handle div at runtime)
    return base_fp


class MeanOperator(AotOperator):
    TYPE: AirOpType = AirOpType.MEAN

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """MEAN operator.

        This operator computes the mean of the input tensor along specified axes.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        axis_dims = [1 if i in self.op.options.axis else 0 for i in range(len(input_tensor.shape))]

        # Compute output dimensions based on input and axis
        output_dims = tuple([1 if ax else input_tensor.shape[i] for i, ax in enumerate(axis_dims)])

        # Verify that output dimensions match
        if output_tensor.shape != output_dims:
            raise ValueError(
                f"Output tensor shape {output_tensor.shape} does not match computed dimensions {output_dims}."
            )
        
        dim_pad = max(0, 4 - len(input_tensor.shape))
        axis_dims_nhwc = [0, 0, 0, 0]  # n,h,w,c
        for a in self.op.options.axis:
            nhwc_idx = a + dim_pad
            axis_dims_nhwc[nhwc_idx] = 1

        reduction_size = math.prod((input_tensor.shape[ax] for ax in self.op.options.axis))

        input_scales = input_tensor.quantization.scale
        output_scales = output_tensor.quantization.scale

        # Compute base scale and quantize
        real_multiplier = input_scales[0] / output_scales[0]
        base_fp = AirFixedPointScale.from_real_multiplier(real_multiplier)

        # Fold mean division (1 / reduction_size)
        output_fp = fold_mean_multiplier(base_fp, reduction_size)

        # Fallback to recomputing effective scale
        if output_fp.multiplier == 0 or output_fp.shift < -31:
            effective_scale = (input_scales[0] / output_scales[0]) / reduction_size
            output_fp = AirFixedPointScale.from_real_multiplier(effective_scale)

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                axis_dims=axis_dims_nhwc,
                output_fp=output_fp,
            )
        )

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirMeanOptions)
        if len(self.input_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")
        if self.input_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError("Input tensor must be int8 or int16.")
        if self.output_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError("Output tensor must be int8 or int16.")

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("mean.h")
        src_template = load_template("mean.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
