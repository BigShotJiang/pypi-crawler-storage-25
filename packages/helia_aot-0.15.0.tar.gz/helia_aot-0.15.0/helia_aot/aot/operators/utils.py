"""
# :material-tools: Operators Utilities API

The `utils` module provides utility functions for AOT operators.


Copyright 2025 Ambiq. All Rights Reserved.

"""

import math
import numpy as np


def pad_shape_to_4d(shape: tuple[int, ...]) -> tuple[int, int, int, int]:
    """Pad a tensor shape to 4D (N, H, W, C) order, filling missing dims with 1."""
    dims = list(shape)
    if len(dims) == 0:
        dims = [1]
    if len(dims) > 4:
        raise ValueError(f"Expected rank <= 4, got {len(dims)} for shape {shape}.")
    while len(dims) < 4:
        dims.append(1)
    return tuple(int(dim) for dim in dims)


def clamp_to_int_range(x: float, dtype: np.dtype = np.int8) -> int:
    """Clamp a float to the specified integer type range.

    Args:
        x (float): The float to clip.
        dtype (np.dtype, optional): The target integer type. Defaults to np.int8.

    Returns:
        int: The clipped integer value.
    """
    return int(min(max(round(x), np.iinfo(dtype).min), np.iinfo(dtype).max))


def lut_populate_s16(
    input_scale: float,
    input_zero_point: int,
    output_scale: float,
    output_zero_point: int,
    transform_fn,
) -> np.ndarray:
    """Recreates TFLM's LUTPopulate<int16_t> behavior.

    Args
      input_scale, input_zero_point: affine scale for LUT input domain
      output_scale, output_zero_point: affine scale for LUT output domain
      transform_fn: function f: R -> R (e.g., exp, 1/(1+x))

    Returns
      np.int16 array of length 513.
    """

    LUT_STEPS  = 512  # -> 513 entries
    INT16_MIN = np.iinfo(np.int16).min
    INT16_MAX = np.iinfo(np.int16).max

    # Input/output dynamic ranges in float
    inp_min = input_scale * (INT16_MIN - input_zero_point)
    inp_max = input_scale * (INT16_MAX - input_zero_point)

    out_min = output_scale * (INT16_MIN - output_zero_point)
    out_max = output_scale * (INT16_MAX - output_zero_point)

    # Map float outputs back to int16 table domain
    out_scale_inv = (INT16_MAX - INT16_MIN + 1) / (out_max - out_min)

    step = (inp_max - inp_min) / LUT_STEPS
    half = step / 2.0

    lut = np.zeros(LUT_STEPS + 1, dtype=np.int16)

    for i in range(LUT_STEPS):
        x0 = inp_min + i * step
        xmid = x0 + half
        x1 = x0 + step

        v0   = transform_fn(x0)
        vmid = transform_fn(xmid)
        v1   = transform_fn(x1)

        # Quantize endpoints and midpoint (TFLM bias correction)
        s0 = round(v0 * out_scale_inv)
        s1 = round(v1 * out_scale_inv)
        sm = round(vmid * out_scale_inv)

        mid_interp = round((s1 + round(s0)) / 2.0)
        bias = round((mid_interp - sm) / 2.0)

        lut[i] = clamp_to_int_range(s0 - bias, dtype=np.int16)

    # Last entry
    vend = transform_fn(inp_max)
    lut[LUT_STEPS] = clamp_to_int_range(round(vend * out_scale_inv), dtype=np.int16)
    return lut


def calculate_input_radius(input_integer_bits, input_left_shift, total_signed_bits=31) -> int:
    """Mimics litert::CalculateInputRadius (non-emulated version).

    This computes the maximum representable difference in the scaled domain.

    Args:
        input_integer_bits (int): Number of integer bits reserved (e.g., kScaledDiffIntegerBits, typically 5).
        input_left_shift (int): The left shift computed from PreprocessSoftmaxScaling.
        total_signed_bits (int): Total bits available in the representation (typically 31 for Q31 arithmetic).

    Returns:
        int: The computed input radius.
    """
    # Compute the maximum value representable using the integer bits.
    max_val = (1 << input_integer_bits) - 1
    # Scale it up to the full bit-width and then shift right by input_left_shift.
    max_input_rescaled = 1.0 * max_val * (1 << (total_signed_bits - input_integer_bits)) / (1 << input_left_shift)
    return int(math.floor(max_input_rescaled))


def tflite_round(x: float) -> int:
    """TFLM's TfLiteRound: round half away from zero, implemented with +/-0.5 then trunc.
    Args:
        x (float): The float to round.

    Returns:
        int: The rounded integer.
    """
    # std::round semantics: half away from zero
    return math.floor(x + 0.5) if x >= 0.0 else math.ceil(x - 0.5)

def checked_log2(x: float, tol: float = 1e-3) -> tuple[bool, int]:
    """Exact port of TFLM's CheckedLog2:
      - Uses log(x) / log(2) (not math.log2)
      - Rounds with TfLiteRound
      - 'Power-of-two' if |fracpart| < 1e-3

    Args:
        x (float): The positive float to compute log2 for.
        tol (float): The tolerance for determining if the value is a power of two.

    Returns:
        tuple[bool, int]: A tuple where the first element indicates if x is a power of two,
                          and the second element is the rounded log2 value.
    """
    if x <= 0.0:
        raise ValueError("checked_log2 expects x > 0")
    x_log2 = math.log(x) * (1.0 / math.log(2.0))
    x_log2_rounded = tflite_round(x_log2)
    x_log2_fracpart = x_log2 - x_log2_rounded
    return (abs(x_log2_fracpart) < tol, int(x_log2_rounded))

def downscale_q31_to_q15(q31: int) -> int:
    """Downscale a Q31 integer to Q15.

    Args:
        q31 (int): The Q31 integer to downscale.

    Returns:
        int: The downscaled Q15 integer.
    """
    q15 = int((q31 + (1 << 15)) >> 16)
    if q15 == (1 << 15):  # saturate if it rounded up to 2^15
        q15 = (1 << 15) - 1
    return q15


def vector_sum_s8(
    vector_data: np.ndarray,
    vector_cols: int,
    vector_rows: int,
    lhs_offset: int,
    rhs_offset: int,
    bias_data: np.ndarray | None = None,
) -> np.ndarray:
    """Pure-Python port of CMSIS-NN's arm_vector_sum_s8 helper.

    Args:
        vector_data: Flattened (rows * cols) int8 buffer containing the kernel matrix.
        vector_cols: Number of columns per output channel (accumulation depth).
        vector_rows: Number of rows/output channels.
        lhs_offset: Input offset applied during accumulation.
        rhs_offset: Filter/weight offset applied during accumulation.
        bias_data: Optional per-output bias (length == vector_rows), int32.

    Returns:
        np.ndarray: int32 array with the kernel sums, matching CMSIS-NN behaviour.
    """
    kernel = np.asarray(vector_data, dtype=np.int8).reshape(vector_rows, vector_cols)

    if bias_data is not None:
        vector_sum_buf = np.asarray(bias_data, dtype=np.int32).copy()
    else:
        vector_sum_buf = np.zeros(vector_rows, dtype=np.int32)

    if lhs_offset != 0:
        sums = kernel.astype(np.int32).sum(axis=1)
        if rhs_offset != 0:
            sums = sums + vector_cols * rhs_offset
        vector_sum_buf += sums * lhs_offset

    return vector_sum_buf
