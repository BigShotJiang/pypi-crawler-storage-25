from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirZerosLikeOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class ZerosLikeOperator(AotOperator):
    TYPE: AirOpType = AirOpType.ZEROS_LIKE

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """ZEROS_LIKE operator.

        This operator creates a tensor filled with zeros that has the same shape as the input tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        sub_values = super().compute_values()

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=self.input_tensors[0],
                output_tensor=self.output_tensors[0],
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirZerosLikeOptions)

        if len(self.input_tensors) != 1 or len(self.output_tensors) != 1:
            raise ValueError("Operator must have exactly one input and one output tensor.")

        input_tensor = self.input_tensors[0]
        output_tensor = self.output_tensors[0]

        # Ensure input and output tensors have the same shape and dtype
        if input_tensor.shape != output_tensor.shape:
            raise ValueError("Input and output tensors must have the same shape.")
        if input_tensor.dtype != output_tensor.dtype:
            raise ValueError("Input and output tensors must have the same data type.")

        # Ensure tensors are int8 or int16
        if input_tensor.dtype not in [np.int8, np.int16, np.int32]:
            raise ValueError("Input and output tensors must be int8, int16, or int32.")

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("zeros_like.h")
        src_template = load_template("zeros_like.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
