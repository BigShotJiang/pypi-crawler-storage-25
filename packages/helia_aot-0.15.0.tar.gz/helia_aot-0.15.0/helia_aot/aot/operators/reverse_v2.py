from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirReverseV2Options
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class ReverseV2Operator(AotOperator):
    TYPE: AirOpType = AirOpType.REVERSE_V2

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """REVERSE_V2 operator.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """
        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        assert isinstance(self.op.options, AirReverseV2Options)

        if len(self.input_tensors) != 1 or len(self.output_tensors) != 1:
            raise ValueError("REVERSE_V2 operator must have exactly one input and one output tensor.")

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        if input_tensor.dtype != output_tensor.dtype:
            raise ValueError("REVERSE_V2 input and output dtypes must match.")
        if input_tensor.shape != output_tensor.shape:
            raise ValueError("REVERSE_V2 input and output shapes must match.")

        rank = len(input_tensor.shape)
        if rank <= 0:
            raise ValueError("REVERSE_V2 requires rank >= 1.")

        normalized_axes: list[int] = []
        for axis in self.op.options.axes:
            normalized = int(axis)
            if normalized < 0:
                normalized += rank
            if normalized < 0 or normalized >= rank:
                raise ValueError(f"REVERSE_V2 axis {axis} out of range for rank {rank}.")
            normalized_axes.append(normalized)

        if len(set(normalized_axes)) != len(normalized_axes):
            raise ValueError(
                f"REVERSE_V2 axes must be unique after normalization, got {self.op.options.axes}."
            )

        self.op.options.axes = normalized_axes

    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, str]:
        """Compute values for REVERSE_V2 code generation.

        Returns:
            dict[str, str]: Template values.
        """
        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        shape = [int(dim) for dim in input_tensor.shape]
        rank = len(shape)

        strides = [1] * rank
        running = 1
        for index in range(rank - 1, -1, -1):
            strides[index] = running
            running *= shape[index]

        reverse_axes = set(self.op.options.axes)
        reverse_flags = [1 if index in reverse_axes else 0 for index in range(rank)]

        is_single_axis_reverse = len(self.op.options.axes) == 1
        single_axis = int(self.op.options.axes[0]) if is_single_axis_reverse else -1
        outer_size = 1
        axis_size = 0
        inner_size = 1
        if is_single_axis_reverse:
            axis_size = int(shape[single_axis])
            if single_axis > 0:
                outer_size = int(np.prod(shape[:single_axis], dtype=int))
            if single_axis < rank - 1:
                inner_size = int(np.prod(shape[single_axis + 1 :], dtype=int))

        sub_values.update(
            dict(
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                rank=rank,
                shape=shape,
                strides=strides,
                reverse_flags=reverse_flags,
                size=int(output_tensor.size),
                is_single_axis_reverse=is_single_axis_reverse,
                single_axis=single_axis,
                outer_size=outer_size,
                axis_size=axis_size,
                inner_size=inner_size,
            )
        )
        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """
        sub_values = self.compute_values()

        hdr_template = load_template("reverse_v2.h")
        src_template = load_template("reverse_v2.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
