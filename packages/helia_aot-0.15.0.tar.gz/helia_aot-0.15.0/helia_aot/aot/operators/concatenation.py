from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirConcatenationOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class ConcatenationOperator(AotOperator):
    TYPE: AirOpType = AirOpType.CONCATENATION

    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """CONCATENATION operator.

        This operator performs concatenation of input tensors along the specified axis.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        assert isinstance(self.op.options, AirConcatenationOptions)
        # Verify at least one input tensor is provided
        if len(self.input_tensors) == 0:
            raise ValueError("At least one input tensor is required for concatenation.")
        if len(self.input_tensors) > 10:
            raise ValueError("Concatenation supports at most 10 input tensors.")
        if len(self.output_tensors) != 1:
            raise ValueError("Concatenation operator must have exactly one output tensor.")
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16, np.int32]:
            raise ValueError("Unsupported output tensor dtype", self.output_tensors[self.kOutputTensorIndex].dtype)

    def on_resolve(self):
        self.validate()
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        if self.op.options.axis < 0:
            self.op.options.axis += len(output_tensor.shape)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensors=self.input_tensors,
                output_tensor=self.output_tensors[self.kOutputTensorIndex],
            )
        )
        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("concatenation.h")
        src_template = load_template("concatenation.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
