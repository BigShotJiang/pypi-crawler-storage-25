from __future__ import annotations

from pathlib import Path
from typing import cast

from helia_aot.air import (
    AirEthosUOptions,
    AirModel,
    AirOperator,
    AirOpType,
    AirTensor,
)
from helia_aot.platforms import SocPlatform

from .operator import AotOperator
from ..templates import load_template


class EthosUOperator(AotOperator):
    """AIR Ethos-U custom operator.

    This operator is exerimental and has following issues for now:
    - Does not enfore 16-byte alignment for tensors.
    - E2E tests do not properly invoke the ethos-u driver.
    - The generated source currently uses a stub driver.
    """

    TYPE: AirOpType = AirOpType.ETHOS_U
    kCommandStreamTensorName = "command_stream"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        super().__init__(op, model, platform, prefix, attributes)

    def _get_command_stream_tensor(self) -> AirTensor:
        if self.kCommandStreamTensorName not in self.op.named_tensors:
            raise KeyError("ETHOS_U operator requires a 'command_stream' tensor")
        tensor_id = self.op.named_tensors[self.kCommandStreamTensorName]
        command_stream_tensor = self.model.get_tensor(tensor_id)
        command_stream_tensor.alignment_hint = 16
        return command_stream_tensor

    def validate(self):
        if not isinstance(self.op.options, AirEthosUOptions):
            raise TypeError("ETHOS_U operator requires AirEthosUOptions")
        command_stream_tensor = self._get_command_stream_tensor()
        if command_stream_tensor.data is None:
            raise ValueError("ETHOS_U command stream tensor must contain data")

    def on_resolve(self):
        self.validate()
        # Align tensors before memory plan phase
        for name, tensor_id in self.op.named_tensors.items():
            if name == self.kCommandStreamTensorName:
                continue
            auxiliary_tensor = self.model.get_tensor(tensor_id)
            auxiliary_tensor.alignment_hint = 16

        for tensor in self.input_tensors:
            tensor.alignment_hint = 16

        for tensor in self.output_tensors:
            tensor.alignment_hint = 16

    def compute_values(self) -> dict[str, object]:
        sub_values = super().compute_values()

        options = cast(AirEthosUOptions, self.op.options)
        command_stream_tensor = self._get_command_stream_tensor()

        auxiliary_tensors: list[tuple[str, AirTensor]] = []
        for name, tensor_id in self.op.named_tensors.items():
            if name == self.kCommandStreamTensorName:
                continue
            auxiliary_tensors.append((name, self.model.get_tensor(tensor_id)))

        input_params = [
            {"name": f"input_{idx}", "tensor": tensor}
            for idx, tensor in enumerate(self.input_tensors)
        ]
        output_params = [
            {"name": f"output_{idx}", "tensor": tensor}
            for idx, tensor in enumerate(self.output_tensors)
        ]

        base_entries: list[dict[str, object]] = []

        for name, tensor in auxiliary_tensors:
            base_entries.append(
                dict(
                    label=name,
                    ptr=f"ctx->tensor_ptrs[{self.prefix}_{tensor.name}]",
                    size=tensor.nbytes,
                )
            )

        for param in input_params:
            tensor = param["tensor"]
            base_entries.append(
                dict(
                    label=param["name"],
                    ptr=param["name"],
                    size=tensor.nbytes,
                )
            )

        for param in output_params:
            tensor = param["tensor"]
            base_entries.append(
                dict(
                    label=param["name"],
                    ptr=param["name"],
                    size=tensor.nbytes,
                )
            )

        if options.num_base_addresses and options.num_base_addresses != len(base_entries):
            raise ValueError(
                f"ETHOS_U operator expected {options.num_base_addresses} base addresses, "
                f"but computed {len(base_entries)}"
            )

        sub_values.update(
            dict(
                options=options,
                command_stream_tensor=command_stream_tensor,
                auxiliary_tensors=[dict(name=name, tensor=tensor) for name, tensor in auxiliary_tensors],
                input_params=input_params,
                output_params=output_params,
                base_entries=base_entries,
            )
        )

        return sub_values

    def emit(self, save_path: Path):
        sub_values = self.compute_values()

        header_template = load_template("ethos_u.h")
        source_template = load_template("ethos_u.c")

        header_code = header_template.render(sub_values)
        source_code = source_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as header_file:
            header_file.write(header_code)

        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as source_file:
            source_file.write(source_code)
