from pathlib import Path
from helia_aot.air import AirOpType, AirModel, AirOperator, AirExpandDimsOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class ExpandDimsOperator(AotOperator):
    TYPE: AirOpType = AirOpType.EXPAND_DIMS

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """EXPAND_DIMS operator.

        This operator expands the dimensions of the input tensor

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        """Validate the operator configuration."""
        assert isinstance(self.op.options, AirExpandDimsOptions)
        if len(self.input_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")

    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        sub_values.update(dict(options=self.op.options, output_tensor=output_tensor))
        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("expand_dims.h")
        src_template = load_template("expand_dims.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
