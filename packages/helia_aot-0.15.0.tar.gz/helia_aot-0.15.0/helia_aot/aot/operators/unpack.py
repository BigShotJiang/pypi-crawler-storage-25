from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirUnpackOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class UnpackOperator(AotOperator):
    TYPE: AirOpType = AirOpType.UNPACK

    kInputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """UNPACK operator.

        This operator performs unpacking of input tensor along the specified axis.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        assert isinstance(self.op.options, AirUnpackOptions)

        # Verify one input tensor and at least one output tensor is provided
        if len(self.input_tensors) != 1:
            raise ValueError("One input tensor is required for unpacking.")
        if len(self.output_tensors) < 1:
            raise ValueError("At least one output tensor is required for unpacking.")
        if self.op.options.num != len(self.output_tensors):
            raise ValueError(
                f"Number of output tensors ({len(self.output_tensors)}) does not match the expected number ({self.op.options.num})."
            )

        # Ensure tensors are int8 or int16
        if self.input_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError("Input and output tensors must be int8 or int16.")

    def on_resolve(self):
        self.validate()
        input_tensor = self.input_tensors[self.kInputTensorIndex]
        if self.op.options.axis < 0:
            self.op.options.axis += len(input_tensor.shape)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=self.input_tensors[self.kInputTensorIndex],
                output_tensors=self.output_tensors,
            )
        )
        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("unpack.h")
        src_template = load_template("unpack.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
