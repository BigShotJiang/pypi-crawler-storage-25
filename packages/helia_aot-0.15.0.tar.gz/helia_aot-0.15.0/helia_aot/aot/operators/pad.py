from pathlib import Path
import numpy as np
from helia_aot.air import AirOpType, AirModel, AirOperator, AirPadOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class PadOperator(AotOperator):
    TYPE: AirOpType = AirOpType.PAD

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """PAD operator.

        This operator pads a tensor with constant values.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=self.input_tensors[0],
                output_tensor=self.output_tensors[0],
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirPadOptions)

        if self.input_tensors[0].quantization.scale[0] != self.output_tensors[0].quantization.scale[0]:
            raise ValueError("Input and output scales must be equal")

        if self.op.options.pre_paddings is None or self.op.options.post_paddings is None:
            raise ValueError("Pad operator requires pre and post paddings to be defined")

        assert len(self.input_tensors) == 1, "Expected one input tensor"
        assert len(self.output_tensors) == 1, "Expected one output tensor"

        if self.input_tensors[0].dtype != self.output_tensors[0].dtype:
            raise ValueError("Input and output tensor dtypes must match")
        dtype = self.output_tensors[0].dtype

        if dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported tensor dtype", dtype)

        if self.op.options.constant_value < np.iinfo(dtype).min or self.op.options.constant_value > np.iinfo(dtype).max:
            raise ValueError("Constant value is out of range for quantization", self.op.options.constant_value)

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("pad.h")
        src_template = load_template("pad.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
