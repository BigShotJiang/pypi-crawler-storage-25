from pathlib import Path
from helia_aot.air import AirOpType, AirModel, AirOperator, AirReduceMinOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class ReduceMinOperator(AotOperator):

    TYPE: AirOpType = AirOpType.REDUCE_MIN

    kInputTensorIndex: int = 0
    kAxisTensorIndex: int = 1
    kOutputTensorIndex: int = 0

    def __init__(self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """REDUCE_MIN operator.

        This operator computes the minimum of the input tensor along specified axes.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        axis_dims = [1 if i in self.op.options.axis else 0 for i in range(len(input_tensor.shape))]

        # Compute output dimensions based on input and axis
        output_dims = tuple([1 if ax else input_tensor.shape[i] for i, ax in enumerate(axis_dims)])

        # Verify that output dimensions match
        if output_tensor.shape != output_dims:
            raise ValueError(f"Output tensor shape {output_tensor.shape} does not match computed dimensions {output_dims}.")

        dim_pad = max(0, 4 - len(input_tensor.shape))
        axis_dims_nhwc = [0, 0, 0, 0]  # n,h,w,c
        for a in self.op.options.axis:
            nhwc_idx = a + dim_pad
            axis_dims_nhwc[nhwc_idx] = 1

        sub_values.update(dict(
            options=self.op.options,
            input_tensor=input_tensor,
            output_tensor=output_tensor,
            axis_dims=axis_dims_nhwc,
        ))

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirReduceMinOptions)
        if len(self.input_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("reduce_min.h")
        src_template = load_template("reduce_min.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
