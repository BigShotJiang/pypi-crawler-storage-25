from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirSplitOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class SplitOperator(AotOperator):
    TYPE: AirOpType = AirOpType.SPLIT

    kInputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """SPLIT operator.

        This operator performs splitting of input tensor along the specified axis.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        assert isinstance(self.op.options, AirSplitOptions)
        input_tensor = self.input_tensors[self.kInputTensorIndex]

        # Verify one input tensor and at least one output tensor is provided
        if len(self.input_tensors) != 1:
            raise ValueError("One input tensor is required for splitting.")
        if len(self.output_tensors) < 1:
            raise ValueError("At least one output tensor is required for splitting.")
        if len(self.op.options.split_lengths) != len(self.output_tensors):
            raise ValueError(
                f"Number of split lengths ({len(self.op.options.split_lengths)}) does not match the number of output tensors ({len(self.output_tensors)})."
            )
        # Ensure tensors are supported numeric types.
        supported_dtypes = [np.int8, np.int16, np.int32, np.float32]
        if input_tensor.dtype not in supported_dtypes:
            raise ValueError("Input tensor must be one of int8/int16/int32/float32.")
        for tensor in self.output_tensors:
            if tensor.dtype != input_tensor.dtype:
                raise ValueError("All SPLIT outputs must match input dtype.")

        # Validate and normalize axis.
        rank = len(input_tensor.shape)
        axis = int(self.op.options.axis)
        if axis < 0:
            axis += rank
        if axis < 0 or axis >= rank:
            raise ValueError(f"SPLIT axis {self.op.options.axis} is out of bounds for input rank {rank}.")
        self.op.options.axis = axis

        # Validate split lengths are positive and sum to axis dimension size.
        split_lengths = [int(length) for length in self.op.options.split_lengths]
        for i, length in enumerate(split_lengths):
            if length <= 0:
                raise ValueError(f"SPLIT length at index {i} must be positive; got {length}.")

        dim_size = int(input_tensor.shape[axis])
        total_split = int(sum(split_lengths))
        if total_split != dim_size:
            raise ValueError(
                f"Sum of split lengths ({total_split}) must equal size of axis {axis} ({dim_size})."
            )

    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=self.input_tensors[self.kInputTensorIndex],
                output_tensors=self.output_tensors,
            )
        )
        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("split.h")
        src_template = load_template("split.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
