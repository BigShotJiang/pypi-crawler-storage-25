from pathlib import Path
import numpy as np
from helia_aot.air import (
    AirOpType,
    AirModel,
    AirOperator,
    AirTensor,
    AirFixedPointScale,
    AirTensorKind,
    AirDepthwiseConv2DOptions,
)
from helia_aot.platforms import SocPlatform
from ..operator import AotOperator
from ...templates import load_template
from .kernels import available_kernels
from ..utils import vector_sum_s8


class DepthwiseConv2DOperator(AotOperator):
    TYPE: AirOpType = AirOpType.DEPTHWISE_CONV_2D

    kInputTensorIndex = 0
    kOutputTensorIndex = 0
    # Local tensors
    kWeightsTensorName = "weights"
    kBiasTensorName = "bias"
    kScratchTensorName = "scratch"
    kWeightSumTensorName = "weight_sum"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """DEPTHWISE_CONV_2D operator.

        This operator performs depthwise convolution on the input tensor using the specified filter tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        """Validate the operator."""
        assert isinstance(self.op.options, AirDepthwiseConv2DOptions)
        if self.kWeightsTensorName not in self.op.named_tensors:
            raise KeyError(f"Operator {self.op.id} does not have weights tensor defined")
        # Need 1 input and 1 output
        if len(self.input_tensors) != 1:
            raise ValueError("Operator must have exactly one input tensor")
        if len(self.output_tensors) != 1:
            raise ValueError("Operator must have exactly one output tensor")
        # Input and output must be same dtype
        if self.input_tensors[self.kInputTensorIndex].dtype != self.output_tensors[self.kOutputTensorIndex].dtype:
            raise ValueError("Operator input and output tensors must have the same dtype")
        # Support only int8 and int16
        if self.input_tensors[self.kInputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input/output tensor dtype", self.input_tensors[self.kInputTensorIndex].dtype)

    def _get_zero_point(self, tensor: AirTensor) -> int:
        if tensor.quantization is None or tensor.quantization.zero_point is None:
            return 0
        if len(tensor.quantization.zero_point) == 0:
            return 0
        return int(tensor.quantization.zero_point[0])

    def on_resolve(self):
        """Resolve the operator."""
        self.validate()

        # Find optimal kernel
        viable_kernels = [kernel for kernel in available_kernels if kernel.applicable(self)]
        if not viable_kernels:
            raise ValueError(f"No viable kernels found for operator {self.op.id}")
        self.kernel = max(viable_kernels, key=lambda k: k.priority)

        # Add scratch tensor
        scratch_buffer_size = self.kernel.compute_scratch_size(self)
        if scratch_buffer_size > 0:
            scratch_tensor = AirTensor(
                id=f"{self.name}_{self.kScratchTensorName}",
                kind=AirTensorKind.SCRATCH,
                shape=(scratch_buffer_size,),
                dtype=np.dtype(np.int8),
                alignment_hint=16,
            )
            self.op.named_tensors[self.kScratchTensorName] = scratch_tensor.id
            self.model.add_tensor(scratch_tensor)
        # END IF

        # Add weight sum tensor
        weight_sum_buffer_size = self.kernel.compute_weight_sum_size(self)
        weight_sum_tensor_id = f"{self.name}_{self.kWeightSumTensorName}"
        if weight_sum_buffer_size > 0:
            if self.model.has_tensor(weight_sum_tensor_id):
                self.model.remove_tensor(weight_sum_tensor_id)
            if self.kWeightSumTensorName in self.op.named_tensors:
                del self.op.named_tensors[self.kWeightSumTensorName]

            weights_tensor = self.get_local_tensor(self.kWeightsTensorName)
            if weights_tensor.data is None:
                raise ValueError("DepthwiseConv2D weights tensor data is required to pre-compute weight sums.")

            bias_tensor = None
            if self.kBiasTensorName in self.op.named_tensors:
                bias_tensor = self.get_local_tensor(self.kBiasTensorName)

            bias_data = None
            if bias_tensor is not None:
                if bias_tensor.data is None:
                    raise ValueError("DepthwiseConv2D bias tensor data must be available for pre-computation.")
                bias_data = bias_tensor.data

            input_tensor = self.input_tensors[self.kInputTensorIndex]
            output_tensor = self.output_tensors[self.kOutputTensorIndex]

            vector_rows = output_tensor.shape[3]
            weights_data = weights_tensor.data
            if weights_data.ndim == 4:
                kernel_matrix = weights_data.transpose(3, 0, 1, 2).reshape(vector_rows, -1)
            elif weights_data.ndim == 3:
                kernel_matrix = weights_data.transpose(2, 0, 1).reshape(vector_rows, -1)
            else:
                raise ValueError("Unsupported depthwise filter layout for weight sum pre-computation.")

            weight_sum = vector_sum_s8(
                vector_data=kernel_matrix,
                vector_cols=kernel_matrix.shape[1],
                vector_rows=vector_rows,
                lhs_offset=-self._get_zero_point(input_tensor),
                rhs_offset=0,
                bias_data=bias_data,
            ).astype(np.int32)

            weight_sum_tensor = AirTensor(
                id=weight_sum_tensor_id,
                kind=AirTensorKind.CONSTANT,
                data=weight_sum,
                alignment_hint=16,
            )
            self.model.add_tensor(weight_sum_tensor)
            self.op.named_tensors[self.kWeightSumTensorName] = weight_sum_tensor.id

            if bias_tensor is not None:
                del self.op.named_tensors[self.kBiasTensorName]
                self.model.remove_tensor(bias_tensor.id)
        # END IF

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        weights_tensor = self.get_local_tensor(self.kWeightsTensorName)

        bias_tensor = None
        if self.kBiasTensorName in self.op.named_tensors:
            bias_tensor = self.get_local_tensor(self.kBiasTensorName)

        scratch_tensor = None
        if self.kScratchTensorName in self.op.named_tensors:
            scratch_tensor = self.get_local_tensor(self.kScratchTensorName)

        weight_sum_tensor = None
        if self.kWeightSumTensorName in self.op.named_tensors:
            weight_sum_tensor = self.get_local_tensor(self.kWeightSumTensorName)

        input_scales = input_tensor.quantization.scale
        weights_scales = weights_tensor.quantization.scale
        output_scales = output_tensor.quantization.scale

        activation_min, activation_max = self.op.options.activation.compute_range(
            output_zero_point=output_tensor.quantization.zero_point[0],
            output_scale=output_scales[0],
            dtype=output_tensor.dtype,
        )

        # Compute fixed-point representation for output tensors
        outputs_fp = []
        for i in range(len(weights_scales)):
            real_multiplier = (input_scales[0] * weights_scales[i]) / output_scales[0]
            outputs_fp.append(AirFixedPointScale.from_real_multiplier(real_multiplier))
        # END FOR

        sub_values.update(
            dict(
                options=self.op.options,
                kernel=self.kernel,
                input_tensor=input_tensor,
                weights_tensor=weights_tensor,
                bias_tensor=bias_tensor,
                output_tensor=output_tensor,
                scratch_tensor=scratch_tensor,
                weight_sum_tensor=weight_sum_tensor,
                outputs_fp=outputs_fp,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )

        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("depthwise_conv_2d.h")
        src_template = load_template("depthwise_conv_2d.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
