from .operator import DepthwiseConv2DOperator
