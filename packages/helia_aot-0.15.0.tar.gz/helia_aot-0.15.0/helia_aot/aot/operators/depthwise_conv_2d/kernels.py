from typing import TYPE_CHECKING, Any
import numpy as np
from helia_aot.air import AirTensorDim
from helia_aot.platforms import SocCapability
from .defines import DepthwiseConv2dKernelSpec, Predicate

if TYPE_CHECKING:
    from .operator import DepthwiseConv2DOperator
else:
    DepthwiseConv2DOperator = Any


def caps_any(*caps: SocCapability) -> Predicate:
    req = set(caps)
    return lambda op: bool(req & set(op.platform.capabilities))


def not_cap(cap: SocCapability) -> Predicate:
    return lambda op: cap not in op.platform.capabilities


def filter_hw_is(h: int, w: int) -> Predicate:
    return lambda op: (
        op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.H] == h
        and op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.W] == w
    )


def filter_hw_size_less_than(length: int) -> Predicate:
    return lambda op: (
        op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.H]
        * op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.W]
        < length
    )


def out_is_s8(op) -> bool:
    y = op.output_tensors[op.kOutputTensorIndex]
    return y.dtype == np.int8


def out_is_s16(op) -> bool:
    y = op.output_tensors[op.kOutputTensorIndex]
    return y.dtype == np.int16


def padding_leq(h: int, w: int) -> Predicate:
    return lambda op: (op.op.options.padding_height <= h and op.op.options.padding_width <= w)


def dilation_is(h: int, w: int) -> Predicate:
    return lambda op: (op.op.options.dilation_height == h and op.op.options.dilation_width == w)


def batch_is(n: int) -> Predicate:
    return lambda op: op.input_tensors[op.kInputTensorIndex].shape[AirTensorDim.N] == n


def depth_multiplier_is(v: int) -> Predicate:
    return lambda op: op.op.options.depth_multiplier == v


# ---------- shared sizers ----------
def weight_sum_size(op: DepthwiseConv2DOperator) -> int:
    # Only used by MVE paths
    if SocCapability.MVE in op.platform.capabilities:
        output_dims = op.output_tensors[op.kOutputTensorIndex].shape
        return output_dims[AirTensorDim.C] * 4  # int32 per output channel
    return 0


# ---------- kernel builders (closures) ----------
def k_arm_depthwise_conv_3x3_s8() -> DepthwiseConv2dKernelSpec:
    def scratch(op: DepthwiseConv2DOperator):
        return 0

    # MCU/DSP only (explicitly exclude MVE)
    capabilities = [SocCapability.MCU, SocCapability.DSP]
    return DepthwiseConv2dKernelSpec(
        id="arm_depthwise_conv_3x3_s8",
        fn_name="arm_depthwise_conv_3x3_s8",
        capabilities=capabilities,
        priority=80,
        rules=(
            caps_any(*capabilities),
            not_cap(SocCapability.MVE),
            out_is_s8,
            depth_multiplier_is(1),
            batch_is(1),
            dilation_is(1, 1),
            filter_hw_is(3, 3),
            padding_leq(1, 1),
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=lambda op: 0,
    )


def k_arm_depthwise_conv_s8_opt() -> DepthwiseConv2dKernelSpec:
    # Optimized path for DSP/MVE, ch_mult==1, NHWC batch==1, no dilation

    def scratch(op: DepthwiseConv2DOperator) -> int:
        CH_IN_BLOCK_MVE = 124
        input = op.input_tensors[op.kInputTensorIndex]
        weights = op.get_local_tensor(op.kWeightsTensorName)
        if SocCapability.MVE in op.platform.capabilities:
            # Mirrors your constant; CMSIS packs by channel blocks for MVE
            return 4 * CH_IN_BLOCK_MVE * weights.shape[AirTensorDim.W] * weights.shape[AirTensorDim.H]
        if SocCapability.DSP in op.platform.capabilities:
            return input.shape[AirTensorDim.C] * weights.shape[AirTensorDim.W] * weights.shape[AirTensorDim.H] * 2
        return 0

    capabilities = [SocCapability.DSP, SocCapability.MVE]

    return DepthwiseConv2dKernelSpec(
        id="arm_depthwise_conv_s8_opt",
        fn_name="arm_depthwise_conv_s8_opt",
        capabilities=capabilities,
        priority=80,
        rules=(
            caps_any(*capabilities),
            out_is_s8,
            depth_multiplier_is(1),
            batch_is(1),
            dilation_is(1, 1),
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum_size,
    )


def k_arm_depthwise_conv_s8() -> DepthwiseConv2dKernelSpec:
    def scratch(op: DepthwiseConv2DOperator) -> int:
        return 0

    return DepthwiseConv2dKernelSpec(
        id="arm_depthwise_conv_s8",
        fn_name="arm_depthwise_conv_s8",
        capabilities=[SocCapability.MCU, SocCapability.DSP, SocCapability.MVE],
        priority=1,
        rules=(out_is_s8,),
        compute_scratch_size=scratch,
        compute_weight_sum_size=lambda op: 0,
    )


def k_arm_depthwise_conv_fast_s16() -> DepthwiseConv2dKernelSpec:
    def scratch(op: DepthwiseConv2DOperator) -> int:
        input = op.input_tensors[op.kInputTensorIndex]
        weights = op.get_local_tensor(op.kWeightsTensorName)
        if SocCapability.MVE in op.platform.capabilities:
            return (
                4 * input.shape[AirTensorDim.C] * weights.shape[AirTensorDim.W] * weights.shape[AirTensorDim.H] * 2 + 8
            )
        if SocCapability.DSP in op.platform.capabilities:
            return input.shape[AirTensorDim.C] * weights.shape[AirTensorDim.W] * weights.shape[AirTensorDim.H] * 2
        return 0

    capabilities = [SocCapability.DSP, SocCapability.MVE]

    return DepthwiseConv2dKernelSpec(
        id="arm_depthwise_conv_fast_s16",
        fn_name="arm_depthwise_conv_fast_s16",
        capabilities=capabilities,
        priority=80,
        rules=(
            caps_any(*capabilities),
            out_is_s16,
            depth_multiplier_is(1),
            batch_is(1),
            dilation_is(1, 1),
            filter_hw_size_less_than(512),
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=lambda op: 0,
    )


def k_arm_depthwise_conv_s16() -> DepthwiseConv2dKernelSpec:
    def scratch(op: DepthwiseConv2DOperator) -> int:
        return 0

    return DepthwiseConv2dKernelSpec(
        id="arm_depthwise_conv_s16",
        fn_name="arm_depthwise_conv_s16",
        capabilities=[SocCapability.MCU, SocCapability.DSP, SocCapability.MVE],
        priority=1,
        rules=(out_is_s16,),
        compute_scratch_size=scratch,
        compute_weight_sum_size=lambda op: 0,
    )


# ---------- registry ----------
available_kernels: list[DepthwiseConv2dKernelSpec] = [
    # S8 kernels
    k_arm_depthwise_conv_3x3_s8(),
    k_arm_depthwise_conv_s8_opt(),
    k_arm_depthwise_conv_s8(),
    # S16 kernels
    k_arm_depthwise_conv_fast_s16(),
    k_arm_depthwise_conv_s16(),
]
