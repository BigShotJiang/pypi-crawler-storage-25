from typing import Any, Callable
from pydantic.dataclasses import dataclass
from pydantic import Field
from helia_aot.platforms import SocCapability

Predicate = Callable[[Any], bool]
Sizer = Callable[[Any], int]


@dataclass(frozen=True)
class DepthwiseConv2dKernelSpec:
    # Identity & binding
    id: str = Field(description="User-facing kernel id")
    fn_name: str = Field(description="C symbol to call")

    # Targeting / selection
    capabilities: list[SocCapability] = Field(default_factory=list, description="List of required SoC capabilities")
    priority: int = Field(0, ge=0, le=100, description="Priority of the kernel, 0-100")

    # Rules-based applicability (lightweight, data-driven)
    rules: tuple[Predicate, ...] = Field(default_factory=tuple, description="List of rules for kernel applicability")

    # Optional custom predicate if rules aren’t enough
    is_applicable: Callable[[Any], bool] | None = None

    # Sizing hooks
    compute_scratch_size: Sizer = Field(lambda _op: 0)
    compute_weight_sum_size: Sizer = Field(lambda _op: 0)

    def applicable(self, op: Any) -> bool:
        # 1) SoC capability gate (intersection is required)
        if self.capabilities:
            if not (set(self.capabilities) & set(op.platform.capabilities)):
                return False
        # 2) Custom predicate wins
        if self.is_applicable is not None:
            return self.is_applicable(op)
        # 3) Otherwise, all rules must pass
        return all(rule(op) for rule in self.rules)
