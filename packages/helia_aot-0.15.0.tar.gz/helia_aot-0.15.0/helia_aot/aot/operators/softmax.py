import math
from pathlib import Path
import numpy as np
from helia_aot.air import AirOpType, AirModel, AirOperator, AirTensor, AirTensorKind, AirFixedPointScale, AirSoftmaxOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template
from .utils import lut_populate_s16, calculate_input_radius


def preprocess_softmax_scaling(
    beta: float, input_scale: float, scaled_diff_integer_bits: int = 5
) -> AirFixedPointScale:
    """Mimics litert::PreprocessSoftmaxScaling.

    Args:
        beta (float): The softmax beta parameter (often 1.0).
        input_scale (float): The quantization scale for the input tensor.
        scaled_diff_integer_bits (int): Number of integer bits to reserve in the scaled difference (typically 5).

    Returns:
        input_multiplier (int): The fixed-point multiplier (in Q31 format).
        input_left_shift (int): The left shift to apply; computed as (shift from quantization + scaled_diff_integer_bits).
    """
    max_real_multiplier = (1 << 31) - 1
    input_beta_real_multiplier = min(beta * input_scale * (1 << (31 - scaled_diff_integer_bits)), max_real_multiplier)
    return AirFixedPointScale.from_real_multiplier(input_beta_real_multiplier)


def make_softmax_s16_exp_luts():
    """Build the exp LUT NS-CMSIS-NN expects, matching TFLM.

      exp_lut:
        input_scale  = 10.0 / 65535
        input_zp     = INT16_MAX
        output_scale =  2.0 / 65535
        output_zp    = 0
        transform    = exp(x)

    Returns:
        np.ndarray: The generated exp LUT (shape: (513,))
    """
    # Range is full integer range (65535)
    rng = np.iinfo(np.int16).max - np.iinfo(np.int16).min
    exp_lut = lut_populate_s16(
        input_scale=10.0 / rng,
        input_zero_point=np.iinfo(np.int16).max,
        output_scale=2.0 / rng,
        output_zero_point=0,
        transform_fn=math.exp,
    )
    return exp_lut


def make_softmax_s16_luts():
    """Build the one_by_one_lut LUT NS-CMSIS-NN expects, matching TFLM.

      one_by_one_lut:
        input_scale  = 1.0 / 65535
        input_zp     = INT16_MIN
        output_scale = 2.0 / 65535
        output_zp    = 0
        transform    = 1 / (1 + x)

    Returns:
        np.ndarray: The generated one_by_one_lut (shape: (513,))
    """
    # Range is full integer range (65535)
    rng = np.iinfo(np.int16).max - np.iinfo(np.int16).min
    one_by_one_lut = lut_populate_s16(
        input_scale=1.0 / rng,
        input_zero_point=np.iinfo(np.int16).min,
        output_scale=2.0 / rng,
        output_zero_point=0,
        transform_fn=lambda x: 1.0 / (1.0 + x),
    )

    return one_by_one_lut

class SoftmaxOperator(AotOperator):
    TYPE: AirOpType = AirOpType.SOFTMAX

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0
    kExpLutTensorName = "exp_lut"
    kOneByOneLutTensorName = "one_by_one_lut"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """SOFTMAX operator.

        This operator computes the softmax activation function on the input tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()
        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        sub_values.update(dict(
            input_tensor=input_tensor,
            output_tensor=output_tensor,
            row_size=int(input_tensor.shape[-1]),  # last dimension
            num_rows=int(np.prod(input_tensor.shape[:-1])),  # product of rest
        ))

        scaled_diff_integer_bits = 5  # matches ns-cmsis-nn

        if self.input_tensors[0].dtype == np.int16:
            input_scale = input_tensor.quantization.scale[0]
            input_scale_beta_rescale = self.op.options.beta * input_scale / (10.0 / 65535.0)
            input_fp = AirFixedPointScale.from_real_multiplier(input_scale_beta_rescale)
            sub_values.update(dict(
                input_fp=input_fp,
                exp_lut_tensor=self.get_local_tensor(self.kExpLutTensorName),
                one_by_one_lut_tensor=self.get_local_tensor(self.kOneByOneLutTensorName),
            ))

        elif self.input_tensors[0].dtype == np.int8:
            input_fp = preprocess_softmax_scaling(
                beta=self.op.options.beta,
                input_scale=input_tensor.quantization.scale[0],
                scaled_diff_integer_bits=scaled_diff_integer_bits,
            )
            diff_min = -1.0 * calculate_input_radius(
                input_integer_bits=scaled_diff_integer_bits,
                input_left_shift=input_fp.shift,
                total_signed_bits=31,
            )
            sub_values.update(
                dict(
                    input_fp=input_fp,
                    diff_min=int(diff_min),
                )
            )
        else:
            raise ValueError("Input tensor must be int8 or int16.")

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirSoftmaxOptions)
        # Ensure single input and output
        if len(self.input_tensors) != 1 or len(self.output_tensors) != 1:
            raise ValueError("Softmax operator must have exactly one input and one output.")
        if self.input_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError("Input tensor must be int8 or int16.")
        input_tensor = self.input_tensors[0]
        output_tensor = self.output_tensors[0]
        # If input is int8 then output can int8 or int16
        if input_tensor.dtype == np.int8 and output_tensor.dtype not in [np.int8, np.int16]:
            raise ValueError("If input is int8 then output must be int8 or int16.")
        # if input is int16 then output must be int16
        if input_tensor.dtype == np.int16 and output_tensor.dtype != np.int16:
            raise ValueError("If input is int16 then output must be int16.")

        assert input_tensor.quantization is not None, "Input tensor must be quantized"
        assert output_tensor.quantization is not None, "Output tensor must be quantized"
        # Validate quantization parameters
        if input_tensor.dtype == np.int16:
            assert input_tensor.quantization.zero_point[0] == 0, "Input zero point must be 0"
            assert output_tensor.quantization.zero_point[0] == 0, "Output zero point must be 0"
            output_scale_delta = abs(output_tensor.quantization.scale[0] - (1.0 / 32768))
            assert output_scale_delta < (0.001 * 1.0 / 32768), "Output scale must be ~1.0 / 32768"
        elif input_tensor.dtype == np.int8:
            if output_tensor.dtype == np.int16:
                assert output_tensor.quantization.zero_point[0] == -32768, "Output zero point must be -32768"
                output_scale_delta = abs(output_tensor.quantization.scale[0] - (1.0 / 65536))
                assert output_scale_delta < (0.001 * 1.0 / 65536), "Output scale must be ~1.0 / 65536"
            elif output_tensor.dtype == np.int8:
                assert output_tensor.quantization.zero_point[0] == -128, "Output zero point must be -128"
                assert output_tensor.quantization.scale[0] == 1.0 / 256, "Output scale must be 1.0 / 256"

    def on_resolve(self):
        self.validate()

        # For int16, we must generate two LUTs
        if self.input_tensors[0].dtype == np.int16:
            # Add exp_lut tensor
            exp_lut = make_softmax_s16_exp_luts()
            exp_lut_tensor = AirTensor(
                id=f"{self.name}_{self.kExpLutTensorName}",
                kind=AirTensorKind.CONSTANT,
                shape=exp_lut.shape,
                dtype=np.dtype(np.int16),
                data=exp_lut,
            )
            self.op.named_tensors[self.kExpLutTensorName] = exp_lut_tensor.id
            self.model.add_tensor(exp_lut_tensor)

            # Add one_by_one_lut tensor
            one_by_one_lut = make_softmax_s16_luts()
            one_by_one_lut_tensor = AirTensor(
                id=f"{self.name}_{self.kOneByOneLutTensorName}",
                kind=AirTensorKind.CONSTANT,
                shape=one_by_one_lut.shape,
                dtype=np.dtype(np.int16),
                data=one_by_one_lut,
            )
            self.op.named_tensors[self.kOneByOneLutTensorName] = one_by_one_lut_tensor.id
            self.model.add_tensor(one_by_one_lut_tensor)
        # END IF

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("softmax.h")
        src_template = load_template("softmax.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
