from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirFixedPointScale, AirMulOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class MulOperator(AotOperator):
    TYPE: AirOpType = AirOpType.MUL
    kInput1TensorIndex: int = 0
    kInput2TensorIndex: int = 1
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """MUL operator.

        This operator computes the element-wise multiplication of two tensors.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input1_tensor = self.input_tensors[self.kInput1TensorIndex]
        input2_tensor = self.input_tensors[self.kInput2TensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        input1_scales = input1_tensor.quantization.scale
        input2_scales = input2_tensor.quantization.scale
        output_scales = output_tensor.quantization.scale

        real_multiplier = input1_scales[0] * input2_scales[0] / output_scales[0]
        output_fp = AirFixedPointScale.from_real_multiplier(real_multiplier)

        activation_min, activation_max = self.op.options.activation.compute_range(
            output_zero_point=output_tensor.quantization.zero_point[0],
            output_scale=output_scales[0],
            dtype=output_tensor.dtype,
        )

        sub_values.update(
            dict(
                options=self.op.options,
                input1_tensor=input1_tensor,
                input2_tensor=input2_tensor,
                output_tensor=output_tensor,
                output_fp=output_fp,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirMulOptions)
        if len(self.input_tensors) != 2:
            raise ValueError(
                f"{self.TYPE} operator ({self.id}) requires exactly 2 input tensors, got {len(self.input_tensors)}."
            )
        if len(self.output_tensors) != 1:
            raise ValueError(
                f"{self.TYPE} operator ({self.id}) requires exactly 1 output tensor, got {len(self.output_tensors)}."
            )
        is_input1_scalar = self.input_tensors[self.kInput1TensorIndex].size == 1
        is_input2_scalar = self.input_tensors[self.kInput2TensorIndex].size == 1
        if is_input1_scalar and is_input2_scalar:
            raise ValueError("Both inputs cannot be scalars.")
        if self.input_tensors[self.kInput1TensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input tensor dtype", self.input_tensors[self.kInput1TensorIndex].dtype)
        if self.input_tensors[self.kInput2TensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input tensor dtype", self.input_tensors[self.kInput2TensorIndex].dtype)
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported output tensor dtype", self.output_tensors[self.kOutputTensorIndex].dtype)

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("mul.h")
        src_template = load_template("mul.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
