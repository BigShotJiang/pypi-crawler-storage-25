from pathlib import Path
import numpy as np
from helia_aot.air import AirOpType, AirModel, AirTensor, AirOperator, AirTensorKind, AirTanhOptions, AirFixedPointScale
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template
from .utils import checked_log2


def make_tanh_lut(input_scale: float, input_zero_point: int, output_scale: float, output_zero_point: int) -> np.ndarray:
    """
    Build a 256-entry int8 → int8 LUT for quantized Tanh,
    iterating over q in [-128..127].
    """
    lut = np.zeros(256, dtype=np.int8)
    for q in range(-128, 128):
        # 1) dequantize
        x = (q - input_zero_point) * input_scale
        # 2) tanh in float
        y = np.tanh(x)
        # 3) requantize
        qy = int(round(y / output_scale + output_zero_point))
        qy = np.clip(qy, -128, 127)
        lut[q + 128] = np.int8(qy)
    return lut

def compute_params_s16(
    input_tensor: AirTensor,
    output_tensor: AirTensor
) -> AirFixedPointScale:
    """Compute the input_multiplier and input_left_shift parameters for int16 Tanh.

    Args:
        input_tensor (AirTensor): The input tensor.
        output_tensor (AirTensor): The output tensor.

    Returns:
        AirFixedPointScale: The input_multiplier and input_left_shift parameters.
    """

    kInputIntegerBits = 3
    kOutputFractionalBits = 15

    input_scale = input_tensor.quantization.scale[0]
    output_scale = output_tensor.quantization.scale[0]

    # Verify output scale is 2^-15 and power-of-two
    is_pot_out, log2_out = checked_log2(output_scale)
    if not (is_pot_out and log2_out == -kOutputFractionalBits):
        raise ValueError(f"output_scale must be 2^-15 for int16 activations, got {output_scale}")

    # If input_scale is a power-of-two and small enough, we can use a shift-only scaling
    is_pot_in, log2_in = checked_log2(input_scale)
    input_left_shift = (15 - kInputIntegerBits) + log2_in
    param_scale_pot = is_pot_in and (input_left_shift == 0 or input_left_shift == 1)
    if param_scale_pot:
        return AirFixedPointScale(multiplier=0, shift=input_left_shift)

    # Otherwise, we need to compute a multiplier as well
    multiplier = float(input_scale) * 4096.0 * 3.0
    input_left_shift = 0
    while (multiplier <= (32767.0 / 2.0)) and (input_left_shift <= 30):
        multiplier *= 2.0
        input_left_shift += 1
    input_multiplier = int(multiplier)
    if input_multiplier > 32767:
        raise ValueError(f"input_multiplier {input_multiplier} out of range for int16")

    return AirFixedPointScale(multiplier=input_multiplier, shift=input_left_shift)

class TanhOperator(AotOperator):
    TYPE: AirOpType = AirOpType.TANH

    kInputTensorIndex = 0
    kOutputTensorIndex = 0
    # Local tensors
    kLutTensorName = "lut"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """TANH operator.

        This operator computes the tanh activation function on the input tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        sub_values.update(dict(
            input_tensor=input_tensor,
            output_tensor=output_tensor,
        ))

        if input_tensor.dtype == np.int16:
            input_fp = compute_params_s16(input_tensor, output_tensor)
            sub_values.update(dict(
                template_name="tanh",
                input_fp=input_fp
            ))

        elif input_tensor.dtype == np.int8:
            if self.kLutTensorName not in self.op.named_tensors:
                raise ValueError("LUT tensor not found in operator named tensors")
            lut_tensor = self.get_local_tensor(self.kLutTensorName)
            sub_values.update(dict(
                template_name="activation_lut",
                lut_tensor=lut_tensor
            ))
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirTanhOptions), "Expected AirTanhOptions"
        # Assert one input and one output tensor
        if len(self.input_tensors) != 1 or len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator must have exactly one input and one output.")
        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        # Only support int8 or int16
        if input_tensor.dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input tensor dtype", input_tensor.dtype)
        if output_tensor.dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported output tensor dtype", output_tensor.dtype)
        # Ensure quantization parameters exist for input and output
        if not input_tensor.quantization:
            raise ValueError("Input tensor must have quantization parameters")
        if not output_tensor.quantization:
            raise ValueError("Output tensor must have quantization parameters")
        if input_tensor.dtype == np.int16:
            if input_tensor.quantization.zero_point[0] != 0:
                raise ValueError("Input tensor zero point must be zero for int16 Tanh")
            if output_tensor.quantization.zero_point[0] != 0:
                raise ValueError("Output tensor zero point must be zero for int16 Tanh")

    def on_resolve(self):
        self.validate()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        if input_tensor.dtype == np.int8:
            # Add LUT tensor
            lut_tensor = AirTensor(
                id=f"{self.name}_{self.kLutTensorName}",
                kind=AirTensorKind.CONSTANT,
                data=make_tanh_lut(
                    input_tensor.quantization.scale[0],
                    input_tensor.quantization.zero_point[0],
                    output_tensor.quantization.scale[0],
                    output_tensor.quantization.zero_point[0],
                ),
            )
            self.op.named_tensors[self.kLutTensorName] = lut_tensor.id
            self.model.add_tensor(lut_tensor)

        elif input_tensor.dtype == np.int16:
            pass
        # ENDIF

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        template_name = sub_values.get("template_name", "tanh")
        hdr_template = load_template(f"{template_name}.h")
        src_template = load_template(f"{template_name}.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
