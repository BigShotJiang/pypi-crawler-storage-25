from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirSliceOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class SliceOperator(AotOperator):
    TYPE: AirOpType = AirOpType.SLICE

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] | None = None,
    ):
        super().__init__(op, model, platform, prefix, attributes or {})

    def compute_values(self) -> dict[str, str]:
        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        if len(input_tensor.shape) > 4:
            raise ValueError("Input tensor must have 4 or fewer dimensions.")

        slices = self.op.options.get_slices(input_tensor.shape)

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                slices=slices,
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirSliceOptions)
        if len(self.input_tensors) != 1 or len(self.output_tensors) != 1:
            raise ValueError("Slice operator must have exactly one input tensor and one output tensor.")
        if self.input_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError("Input tensor must be int8 or int16.")
        if self.output_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError("Output tensor must be int8 or int16.")

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        sub_values = self.compute_values()

        hdr_template = load_template("strided_slice.h")
        src_template = load_template("strided_slice.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
