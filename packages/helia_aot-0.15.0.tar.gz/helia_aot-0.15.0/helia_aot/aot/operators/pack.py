from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirPackOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class PackOperator(AotOperator):
    TYPE: AirOpType = AirOpType.PACK

    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """PACK operator.

        This operator packs multiple input tensors into a single output tensor along a specified axis.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensors=self.input_tensors,
                output_tensor=self.output_tensors[self.kOutputTensorIndex],
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirPackOptions)
        if len(self.input_tensors) != self.op.options.values_count:
            raise ValueError(
                f"Number of input tensors ({len(self.input_tensors)}) does not match the expected values count ({self.op.options.values_count})."
            )
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16, np.int32]:
            raise ValueError("Unsupported output tensor dtype", self.output_tensors[self.kOutputTensorIndex].dtype)

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("pack.h")
        src_template = load_template("pack.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
