from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirGatherOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template
from .utils import pad_shape_to_4d


class GatherOperator(AotOperator):
    TYPE: AirOpType = AirOpType.GATHER

    kDataTensorIndex = 0
    kIndicesTensorIndex = 1
    kOutputTensorIndex = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] | None = None,
    ):
        """GATHER operator.

        This operator gathers slices from params along the specified axis.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): Target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str] | None, optional): Attributes for template values.
        """
        super().__init__(op, model, platform, prefix, attributes or {})

    def validate(self):
        assert isinstance(self.op.options, AirGatherOptions)
        if len(self.input_tensors) != 2:
            raise ValueError("Gather operator expects exactly two input tensors (data and indices).")
        if len(self.output_tensors) != 1:
            raise ValueError("Gather operator expects exactly one output tensor.")

        data_tensor = self.input_tensors[self.kDataTensorIndex]
        indices_tensor = self.input_tensors[self.kIndicesTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        if data_tensor.dtype not in (np.int8, np.int16):
            raise ValueError("Gather data tensor must be int8 or int16.")
        if indices_tensor.dtype != np.int32:
            raise ValueError("Gather indices tensor must be int32.")
        if output_tensor.dtype != data_tensor.dtype:
            raise ValueError("Gather output tensor dtype must match input dtype.")

        if not (0 <= self.op.options.axis < self.op.options.input_rank):
            raise ValueError("Gather axis is out of bounds for the input rank.")

    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, object]:
        sub_values = super().compute_values()
        options = self.op.options

        sub_values.update(
            dict(
                options=options,
                input_tensor=self.input_tensors[self.kDataTensorIndex],
                indices_tensor=self.input_tensors[self.kIndicesTensorIndex],
                output_tensor=self.output_tensors[self.kOutputTensorIndex],
                input_dims=pad_shape_to_4d(options.input_shape),
                indices_dims=pad_shape_to_4d(options.indices_shape),
                output_dims=pad_shape_to_4d(options.output_shape),
            )
        )
        return sub_values

    def emit(self, save_path: Path):
        sub_values = self.compute_values()

        hdr_template = load_template("gather.h")
        src_template = load_template("gather.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
