from pathlib import Path
import numpy as np
from helia_aot.air import (
    AirOpType,
    AirModel,
    AirOperator,
    AirTensor,
    AirFixedPointScale,
    AirTensorKind,
    AirActivationType,
    AirBatchMatMulOptions,
)
from helia_aot.platforms import SocCapability, SocPlatform
from .operator import AotOperator
from ..templates import load_template

class BatchMatMulOperator(AotOperator):
    TYPE: AirOpType = AirOpType.BATCH_MATMUL

    kLhsTensorIndex: int = 0
    kRhsTensorIndex: int = 1
    kOutputTensorIndex: int = 0
    # Local tensors
    kScratchTensorName = "scratch"
    kLhsTpTensorName = "lhs_tp"
    kRhsTpTensorName = "rhs_tp"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """BATCH_MATMUL operator.

        This operator computes the batch matrix multiplication of two tensors.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def _swap_last_two(self, shape: tuple[int, ...]) -> tuple[int, ...]:
        """Return shape with the last two dims swapped. Requires rank >= 2."""
        if len(shape) < 2:
            raise ValueError(f"BatchMatMul input must have rank >= 2, got {shape}.")
        return (*shape[:-2], shape[-1], shape[-2])

    def compute_scratch_size(self) -> int:
        """Compute the scratch size for the operator.

        Returns:
            int: Computed scratch size.
        """
        if SocCapability.MVE in self.platform.capabilities:
            lhs_chs = self.input_tensors[0].shape[-1]
            return lhs_chs * 4
        return 0

    def validate(self):
        assert isinstance(self.op.options, AirBatchMatMulOptions)

    def on_resolve(self):
        self.validate()

        if self.op.options.adj_x:
            lhs_tensor = self.input_tensors[self.kLhsTensorIndex]
            kind = AirTensorKind.PERSISTENT if lhs_tensor.is_constant else AirTensorKind.SCRATCH
            lhs_tp_dims = self._swap_last_two(tuple(lhs_tensor.shape))
            lhs_tp_tensor = AirTensor(
                id=f"{self.name}_{self.kLhsTpTensorName}",
                kind=kind,
                shape=lhs_tp_dims,
                dtype=lhs_tensor.dtype,
            )
            self.op.named_tensors[self.kLhsTpTensorName] = lhs_tp_tensor.id
            self.model.add_tensor(lhs_tp_tensor)
        # END IF

        if not self.op.options.adj_y:
            rhs_tensor = self.input_tensors[self.kRhsTensorIndex]
            rhs_tp_dims = self._swap_last_two(tuple(rhs_tensor.shape))
            kind = AirTensorKind.PERSISTENT if rhs_tensor.is_constant else AirTensorKind.SCRATCH
            rhs_tp_tensor = AirTensor(
                id=f"{self.name}_{self.kRhsTpTensorName}",
                kind=kind,
                shape=rhs_tp_dims,
                dtype=rhs_tensor.dtype,
            )
            self.op.named_tensors[self.kRhsTpTensorName] = rhs_tp_tensor.id
            self.model.add_tensor(rhs_tp_tensor)
        # END IF

        # Add scratch tensor
        scratch_buffer_size = self.compute_scratch_size()
        if scratch_buffer_size > 0:
            scratch_tensor = AirTensor(
                id=f"{self.name}_{self.kScratchTensorName}",
                kind=AirTensorKind.SCRATCH,
                shape=(scratch_buffer_size,),
                dtype=np.dtype(np.int8),
            )
            self.op.named_tensors[self.kScratchTensorName] = scratch_tensor.id
            self.model.add_tensor(scratch_tensor)
        # END IF

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        lhs_tensor = self.input_tensors[self.kLhsTensorIndex]
        rhs_tensor = self.input_tensors[self.kRhsTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        scratch_tensor = None
        if self.kScratchTensorName in self.op.named_tensors:
            scratch_tensor = self.get_local_tensor(self.kScratchTensorName)

        lhs_tp_tensor = None
        if self.kLhsTpTensorName in self.op.named_tensors:
            lhs_tp_tensor = self.get_local_tensor(self.kLhsTpTensorName)

        rhs_tp_tensor = None
        if self.kRhsTpTensorName in self.op.named_tensors:
            rhs_tp_tensor = self.get_local_tensor(self.kRhsTpTensorName)

        lhs_scale = lhs_tensor.quantization.scale[0]
        rhs_scale = rhs_tensor.quantization.scale[0]
        output_scale = output_tensor.quantization.scale[0]
        output_zero_point = output_tensor.quantization.zero_point[0]

        real_multiplier = lhs_scale * rhs_scale / output_scale
        output_fp = AirFixedPointScale.from_real_multiplier(real_multiplier)

        activation_min, activation_max = AirActivationType.NONE.compute_range(
            output_zero_point=output_zero_point, output_scale=output_scale, dtype=output_tensor.dtype
        )

        sub_values.update(
            dict(
                options=self.op.options,
                lhs_tensor=lhs_tensor,
                rhs_tensor=rhs_tensor,
                output_tensor=output_tensor,
                scratch_tensor=scratch_tensor,
                lhs_tp_tensor=lhs_tp_tensor,
                rhs_tp_tensor=rhs_tp_tensor,
                output_fp=output_fp,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )

        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("batch_matmul.h")
        src_template = load_template("batch_matmul.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
