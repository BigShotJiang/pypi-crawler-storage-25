from pathlib import Path
from helia_aot.air import (
    AirOpType,
    AirModel,
    AirOperator,
    AirResizeNearestNeighborOptions,
    AirTensor,
    AirTensorKind,
)
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template
import numpy as np


class ResizeNearestNeighborOperator(AotOperator):
    TYPE: AirOpType = AirOpType.RESIZE_NEAREST_NEIGHBOR

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0
    kSizeTensorName = "size"
    kScratchTensorName = "scratch"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """Resize Nearest Neighbor operator.

        This operator resizes a tensor to a new shape.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=self.input_tensors[self.kInputTensorIndex],
                output_tensor=self.output_tensors[self.kOutputTensorIndex],
                size_tensor=self.get_local_tensor(self.kSizeTensorName),
                scratch_tensor=self.get_local_tensor(self.kScratchTensorName)
                if self.kScratchTensorName in self.op.named_tensors
                else None,
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirResizeNearestNeighborOptions)
        assert len(self.input_tensors) == 1
        assert len(self.output_tensors) == 1
        assert len(self.local_tensors) == 1
        if self.kSizeTensorName not in self.op.named_tensors:
            raise KeyError(f"Operator {self.op.id} missing size tensor")

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        size_tensor = self.get_local_tensor(self.kSizeTensorName)

        if input_tensor.dtype not in [np.int8, np.int16]:
            raise ValueError("Input tensor must be int8 or int16.")
        if output_tensor.dtype != input_tensor.dtype:
            raise ValueError("Output tensor dtype must match input tensor dtype.")
        if size_tensor.dtype != np.int32:
            raise ValueError("Size tensor must be int32.")
        if size_tensor.size != 2:
            raise ValueError("Size tensor must contain exactly 2 elements (height, width).")

        if len(input_tensor.shape) > 4 or len(output_tensor.shape) > 4:
            raise ValueError("ResizeNearestNeighbor supports tensors with rank <= 4.")

        if self.op.options.align_corners and self.op.options.half_pixel_centers:
            raise ValueError("half_pixel_centers must be False when align_corners is True.")

        if size_tensor.data is not None:
            output_dims = output_tensor.get_shape_with_axis_expanded(0)
            size_values = size_tensor.data.flatten()
            if size_values[0] != output_dims[1] or size_values[1] != output_dims[2]:
                raise ValueError("Size tensor values do not match output tensor height/width.")


    def on_resolve(self):
        self.validate()
        size_tensor = self.get_local_tensor(self.kSizeTensorName)
        scratch_bytes = 0
        if size_tensor.data is not None:
            size_values = size_tensor.data.flatten()
            scratch_bytes = int((size_values[0] + size_values[1]) * np.dtype(np.int32).itemsize)

        if scratch_bytes > 0:
            scratch_elems = scratch_bytes // np.dtype(np.int32).itemsize
            scratch_tensor = AirTensor(
                id=f"{self.name}_{self.kScratchTensorName}",
                kind=AirTensorKind.SCRATCH,
                shape=(scratch_elems,),
                dtype=np.dtype(np.int32),
                alignment_hint=4,
            )
            self.op.named_tensors[self.kScratchTensorName] = scratch_tensor.id
            self.model.add_tensor(scratch_tensor)

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("resize_nearest_neighbor.h")
        src_template = load_template("resize_nearest_neighbor.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
