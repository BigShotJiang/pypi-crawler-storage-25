from typing import TYPE_CHECKING, Any
import numpy as np

from helia_aot.air import AirTensorDim
from helia_aot.platforms import SocCapability
from .defines import Conv2dKernelSpec, Predicate

if TYPE_CHECKING:
    from .operator import Conv2DOperator
else:
    Conv2DOperator = Any


def caps_any(*caps: SocCapability) -> Predicate:
    req = set(caps)
    return lambda op: bool(req & set(op.platform.capabilities))


def filter_hw_is(h: int, w: int) -> Predicate:
    return lambda op: (
        op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.H] == h
        and op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.W] == w
    )


def padding_is(h: int, w: int) -> Predicate:
    return lambda op: (op.op.options.padding_height == h and op.op.options.padding_width == w)


def dilation_is(h: int, w: int) -> Predicate:
    return lambda op: (op.op.options.dilation_height == h and op.op.options.dilation_width == w)


def stride_is(h: int, w: int) -> Predicate:
    return lambda op: (op.op.options.stride_height == h and op.op.options.stride_width == w)


def upscale_is(h: int, w: int) -> Predicate:
    return lambda op: (
        getattr(op.op.options, "upscale_height", 1) == h
        and getattr(op.op.options, "upscale_width", 1) == w
    )


def filter_c_is(c: int) -> Predicate:
    return lambda op: op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.C] == c


def input_c_equals_output_c(op) -> bool:
    x = op.input_tensors[op.kInputTensorIndex]
    y = op.output_tensors[op.kOutputTensorIndex]
    return x.shape[AirTensorDim.C] == y.shape[AirTensorDim.C]


def channels_match_input_and_weights(op) -> bool:
    x = op.input_tensors[op.kInputTensorIndex]
    w = op.get_local_tensor(op.kWeightsTensorName)
    return x.shape[AirTensorDim.C] == w.shape[AirTensorDim.C]


def out_is_1x1(op) -> bool:
    y = op.output_tensors[op.kOutputTensorIndex]
    return y.shape[AirTensorDim.H] == 1 and y.shape[AirTensorDim.W] == 1


def out_is_s8(op) -> bool:
    y = op.output_tensors[op.kOutputTensorIndex]
    return y.dtype == np.int8


def out_is_s16(op) -> bool:
    y = op.output_tensors[op.kOutputTensorIndex]
    return y.dtype == np.int16


def aligned_rhs_cols(op) -> int:
    x = op.input_tensors[op.kInputTensorIndex]
    w = op.get_local_tensor(op.kWeightsTensorName)
    rhs = w.shape[AirTensorDim.H] * w.shape[AirTensorDim.W] * x.shape[AirTensorDim.C]
    return (rhs + 3) & ~3


def filter_size_less_than(length: int) -> Predicate:
    return lambda op: (
        op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.H]
        * op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.W]
        * op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.C]
        < length
    )


def mve_1xn_padding_feasible(op) -> bool:
    if SocCapability.MVE not in op.platform.capabilities:
        return True
    input = op.input_tensors[op.kInputTensorIndex]
    weights = op.get_local_tensor(op.kWeightsTensorName)
    output = op.output_tensors[op.kOutputTensorIndex]
    input_w = input.shape[AirTensorDim.W]
    kernel_w = weights.shape[AirTensorDim.W]
    output_w = output.shape[AirTensorDim.W]
    stride_w = op.op.options.stride_width
    pad_w = op.op.options.padding_width
    total_pad = (output_w - 1) * stride_w + kernel_w - input_w
    asym = total_pad % 2
    right = max(1, (pad_w + asym + stride_w - 1) // stride_w) if (pad_w + asym) != 0 else 0
    left = max(1, (pad_w + stride_w - 1) // stride_w) if pad_w != 0 else 0
    no_pad = max(output_w - (right + left), 0)
    return (right + left + no_pad) == output_w


def k_arm_convolve_1x1_s8_fast() -> Conv2dKernelSpec:
    def scratch(op: Conv2DOperator) -> int:
        if SocCapability.MVE in op.platform.capabilities:
            return 0
        if SocCapability.DSP in op.platform.capabilities:
            # if defined(__ARMCC_VERSION) && (__ARMCC_VERSION >= 6010050)
            c = op.input_tensors[op.kInputTensorIndex].shape[AirTensorDim.C]
            return 2 * c * 2  # 2*C*sizeof(int16_t)
        return 0

    def weight_sum(op: Conv2DOperator) -> int:
        if SocCapability.MVE in op.platform.capabilities:
            return op.output_tensors[op.kOutputTensorIndex].shape[AirTensorDim.C] * 4
        return 0

    capabilities = [SocCapability.MCU, SocCapability.DSP, SocCapability.MVE]

    return Conv2dKernelSpec(
        id="arm_convolve_1x1_s8_fast",
        fn_name="arm_convolve_1x1_s8_fast",
        capabilities=capabilities,
        priority=80,
        rules=(
            caps_any(*capabilities),
            out_is_s8,
            upscale_is(1, 1),
            padding_is(0, 0),
            filter_hw_is(1, 1),
            dilation_is(1, 1),
            stride_is(1, 1),
            channels_match_input_and_weights,
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


def k_arm_convolve_1x1_s8() -> Conv2dKernelSpec:
    def scratch(op: Conv2DOperator) -> int:
        return 0

    def weight_sum(op: Conv2DOperator) -> int:
        if SocCapability.MVE in op.platform.capabilities:
            return op.output_tensors[op.kOutputTensorIndex].shape[AirTensorDim.C] * 4
        return 0

    return Conv2dKernelSpec(
        id="arm_convolve_1x1_s8",
        fn_name="arm_convolve_1x1_s8",
        capabilities=[SocCapability.MCU, SocCapability.DSP, SocCapability.MVE],
        priority=60,
        rules=(
            caps_any(SocCapability.MCU, SocCapability.DSP, SocCapability.MVE),
            out_is_s8,
            upscale_is(1, 1),
            padding_is(0, 0),
            filter_hw_is(1, 1),
            dilation_is(1, 1),
            channels_match_input_and_weights,
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


def k_arm_convolve_1_x_n_s8() -> Conv2dKernelSpec:
    def scratch(op: Conv2DOperator) -> int:
        if SocCapability.MVE in op.platform.capabilities:
            input = op.input_tensors[op.kInputTensorIndex]
            weights = op.get_local_tensor(op.kWeightsTensorName)
            output = op.output_tensors[op.kOutputTensorIndex]
            stride_w = op.op.options.stride_width
            pad_x = op.op.options.padding_width
            input_w = input.shape[AirTensorDim.W]
            kernel_w = weights.shape[AirTensorDim.W]
            output_w = output.shape[AirTensorDim.W]
            total_pad = (output_w - 1) * stride_w + kernel_w - input_w
            asym = total_pad % 2
            right = max(1, (pad_x + asym + stride_w - 1) // stride_w) if (pad_x + asym) != 0 else 0
            pad_left = pad_x * input.shape[AirTensorDim.C]
            pad_right = (right * input.shape[AirTensorDim.C]) if asym else pad_left
            num_elem_left = kernel_w * input.shape[AirTensorDim.C]
            num_elem_right = num_elem_left - input.shape[AirTensorDim.C]
            return max(num_elem_left + pad_left, num_elem_right + pad_right)
        return 0

    def weight_sum(op: Conv2DOperator) -> int:
        return op.output_tensors[op.kOutputTensorIndex].shape[AirTensorDim.C] * 4

    return Conv2dKernelSpec(
        id="arm_convolve_1_x_n_s8",
        fn_name="arm_convolve_1_x_n_s8",
        capabilities=[SocCapability.MVE],
        priority=59,
        rules=(
            caps_any(SocCapability.MVE),
            out_is_s8,
            upscale_is(1, 1),
            lambda op: op.input_tensors[op.kInputTensorIndex].shape[AirTensorDim.H] == 1,
            lambda op: op.op.options.dilation_height == 1,
            lambda op: op.get_local_tensor(op.kWeightsTensorName).shape[AirTensorDim.H] == 1,
            lambda op: (op.op.options.stride_width * op.input_tensors[op.kInputTensorIndex].shape[AirTensorDim.C]) % 4
            == 0,
            channels_match_input_and_weights,
            mve_1xn_padding_feasible,
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


def k_arm_convolve_1x1_out_s8() -> Conv2dKernelSpec:
    def scratch(op: Conv2DOperator):
        return aligned_rhs_cols(op)

    def weight_sum(op: Conv2DOperator):
        return op.output_tensors[op.kOutputTensorIndex].shape[AirTensorDim.C] * 4

    return Conv2dKernelSpec(
        id="arm_convolve_1x1_out_s8",
        fn_name="arm_convolve_1x1_out_s8",
        capabilities=[SocCapability.MVE],
        priority=80,
        rules=(
            caps_any(SocCapability.MVE),
            out_is_s8,
            upscale_is(1, 1),
            out_is_1x1,
            lambda op: (op.op.options.stride_width * op.input_tensors[op.kInputTensorIndex].shape[AirTensorDim.C]) % 4
            == 0,
            channels_match_input_and_weights,
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


def k_arm_convolve_s8() -> Conv2dKernelSpec:
    def scratch(op: Conv2DOperator):
        x = op.input_tensors[op.kInputTensorIndex]
        wts = op.get_local_tensor(op.kWeightsTensorName)
        if SocCapability.MVE in op.platform.capabilities:
            col = x.shape[AirTensorDim.C] * wts.shape[AirTensorDim.W] * wts.shape[AirTensorDim.H]
            col = (col + 15) // 16
            return 4 * col * 16 * 1
        rhs = wts.shape[AirTensorDim.W] * wts.shape[AirTensorDim.H] * x.shape[AirTensorDim.C]
        aligned = rhs if rhs % 4 == 0 else rhs + (4 - rhs % 4)
        return 2 * aligned * 2  # 2 * aligned * sizeof(int16_t)

    def weight_sum(op: Conv2DOperator):
        if SocCapability.MVE in op.platform.capabilities:
            return op.output_tensors[op.kOutputTensorIndex].shape[AirTensorDim.C] * 4
        return 0

    return Conv2dKernelSpec(
        id="arm_convolve_s8",
        fn_name="arm_convolve_s8",
        capabilities=[SocCapability.MCU, SocCapability.DSP, SocCapability.MVE],
        priority=1,
        rules=(out_is_s8,),  # catch-all for s8
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


def k_arm_convolve_1x1_s16_ns_np_nd() -> Conv2dKernelSpec:
    def scratch(op: Conv2DOperator):
        x = op.input_tensors[op.kInputTensorIndex]
        wts = op.get_local_tensor(op.kWeightsTensorName)
        if SocCapability.MVE in op.platform.capabilities:
            col = x.shape[AirTensorDim.C] * wts.shape[AirTensorDim.W] * wts.shape[AirTensorDim.H]
            col = (col + 7) // 8
            return 4 * col * 8 * 2
        # (2 * input_dims->c * filter_dims->w * filter_dims->h) * (int32_t)sizeof(int16_t);
        return 2 * x.shape[AirTensorDim.C] * wts.shape[AirTensorDim.H] * wts.shape[AirTensorDim.W] * 2

    def weight_sum(op: Conv2DOperator):
        # NOTE: Not supported yet in NS-CMSIS-NN
        return 0

    capabilities = [SocCapability.MVE]

    return Conv2dKernelSpec(
        id="arm_convolve_1x1_s16_ns_np_nd",
        fn_name="arm_convolve_1x1_s16_ns_np_nd",
        capabilities=capabilities,
        priority=80,
        rules=(
            caps_any(*capabilities),
            out_is_s16,
            upscale_is(1, 1),
            filter_hw_is(1, 1),
            padding_is(0, 0),
            stride_is(1, 1),
            dilation_is(1, 1),
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


def k_arm_convolve_s16_fast_small_kernel() -> Conv2dKernelSpec:
    def scratch(op: Conv2DOperator):
        return 0

    def weight_sum(op: Conv2DOperator):
        return 0

    capabilities = [SocCapability.MVE]

    return Conv2dKernelSpec(
        id="arm_convolve_s16_fast_small_kernel",
        fn_name="arm_convolve_s16_fast_small_kernel",
        capabilities=capabilities,
        priority=90,
        rules=(
            caps_any(*capabilities),
            out_is_s16,
            upscale_is(1, 1),
            filter_size_less_than(9),
            padding_is(0, 0),
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


def k_arm_convolve_s16_group_ch_mult_1() -> Conv2dKernelSpec:
    """Group s16 conv2d with ch_mult==1: filter C==1 and input_ch==output_ch."""

    def scratch(op: Conv2DOperator):
        return 0

    def weight_sum(op: Conv2DOperator):
        return 0

    capabilities = [SocCapability.MVE]

    return Conv2dKernelSpec(
        id="arm_convolve_s16_group_ch_mult_1",
        fn_name="arm_convolve_s16_group_ch_mult_1",
        capabilities=capabilities,
        priority=10,
        rules=(
            caps_any(*capabilities),
            out_is_s16,
            upscale_is(1, 1),
            filter_c_is(1),
            input_c_equals_output_c,
        ),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


def k_arm_convolve_s16() -> Conv2dKernelSpec:
    def scratch(op: Conv2DOperator):
        x = op.input_tensors[op.kInputTensorIndex]
        wts = op.get_local_tensor(op.kWeightsTensorName)
        if SocCapability.MVE in op.platform.capabilities:
            col = x.shape[AirTensorDim.C] * wts.shape[AirTensorDim.W] * wts.shape[AirTensorDim.H]
            col = (col + 7) // 8
            return 4 * col * 8 * 2
        # (2 * input_dims->c * filter_dims->w * filter_dims->h) * (int32_t)sizeof(int16_t);
        return 2 * x.shape[AirTensorDim.C] * wts.shape[AirTensorDim.H] * wts.shape[AirTensorDim.W] * 2

    def weight_sum(op: Conv2DOperator):
        # NOTE: Not supported yet in NS-CMSIS-NN
        return 0

    return Conv2dKernelSpec(
        id="arm_convolve_s16",
        fn_name="arm_convolve_s16",
        capabilities=[SocCapability.MCU, SocCapability.DSP, SocCapability.MVE],
        priority=1,
        rules=(
            out_is_s16,
            upscale_is(1, 1),
        ),  # catch-all for s16
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum,
    )


# Final registry
available_kernels: list[Conv2dKernelSpec] = [
    # S8 kernels
    k_arm_convolve_1x1_s8_fast(),
    k_arm_convolve_1x1_s8(),
    k_arm_convolve_1_x_n_s8(),
    k_arm_convolve_1x1_out_s8(),
    k_arm_convolve_s8(),
    # S16 kernels
    k_arm_convolve_1x1_s16_ns_np_nd(),
    k_arm_convolve_s16_fast_small_kernel(),
    k_arm_convolve_s16_group_ch_mult_1(),
    k_arm_convolve_s16(),
]
