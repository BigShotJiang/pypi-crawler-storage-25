from typing import cast
from pathlib import Path
import numpy as np
from helia_aot.air import (
    AirOpType,
    AirModel,
    AirOperator,
    AirTensor,
    AirFixedPointScale,
    AirTensorKind,
    AirTransposeConvOptions,
)
from helia_aot.platforms import SocPlatform
from ..operator import AotOperator
from ...templates import load_template
from .kernels import available_kernels


class TransposeConvOperator(AotOperator):
    TYPE: str = AirOpType.TRANSPOSE_CONV

    kInputTensorIndex = 0
    kOutputTensorIndex = 0
    # Local tensors
    kWeightsTensorName = "weights"
    kBiasTensorName = "bias"
    kScratchTensorName = "scratch"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """TRANSPOSE_CONV operator.

        This operator performs a transposed convolution operation on the input tensor with the given weight and bias tensors.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        """Validate the operator."""
        assert isinstance(self.op.options, AirTransposeConvOptions)
        if self.kWeightsTensorName not in self.op.named_tensors:
            raise KeyError(f"Operator {self.op.id} does not have weights tensor defined")
        if len(self.input_tensors) != 1:
            raise ValueError("Operator must have exactly one input tensor")
        if len(self.output_tensors) != 1:
            raise ValueError("Operator must have exactly one output tensor")
        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        weights_tensor = self.get_local_tensor(self.kWeightsTensorName)
        if input_tensor.dtype != output_tensor.dtype:
            raise ValueError("Operator input and output tensors must have the same dtype")
        if input_tensor.dtype != np.int8 or weights_tensor.dtype != np.int8:
            raise ValueError(
                "TransposeConv input, weights, and output tensors must all be int8; "
                f"got input={input_tensor.dtype}, weights={weights_tensor.dtype}, "
                f"output={output_tensor.dtype}"
            )
        if self.kBiasTensorName in self.op.named_tensors:
            bias_tensor = self.get_local_tensor(self.kBiasTensorName)
            if bias_tensor.dtype != np.int32:
                raise ValueError("TransposeConv bias tensor must be int32")

    def on_resolve(self):
        """Resolve the operator."""
        self.validate()

        # Find optimal kernel
        viable_kernels = [kernel for kernel in available_kernels if kernel.applicable(self)]
        if not viable_kernels:
            raise ValueError(f"No viable kernels found for operator {self.op.id}")
        self.kernel = max(viable_kernels, key=lambda k: k.priority)

        # Add scratch tensor
        scratch_buffer_size = self.kernel.compute_scratch_size(self)
        if scratch_buffer_size > 0:
            scratch_tensor = AirTensor(
                id=f"{self.name}_{self.kScratchTensorName}",
                kind=AirTensorKind.SCRATCH,
                shape=(scratch_buffer_size,),
                dtype=np.dtype(np.int8),
                alignment_hint=16,
            )
            self.op.named_tensors[self.kScratchTensorName] = scratch_tensor.id
            self.model.add_tensor(scratch_tensor)
        # END IF

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        options = cast(AirTransposeConvOptions, self.op.options)

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        weights_tensor = self.get_local_tensor(self.kWeightsTensorName)

        bias_tensor = None
        if self.kBiasTensorName in self.op.named_tensors:
            bias_tensor = self.get_local_tensor(self.kBiasTensorName)

        scratch_tensor = None
        if self.kScratchTensorName in self.op.named_tensors:
            scratch_tensor = self.get_local_tensor(self.kScratchTensorName)

        input_scales = input_tensor.quantization.scale
        weights_scales = weights_tensor.quantization.scale
        output_scales = output_tensor.quantization.scale

        activation_min, activation_max = options.activation.compute_range(
            output_zero_point=output_tensor.quantization.zero_point[0],
            output_scale=output_scales[0],
            dtype=output_tensor.dtype,
        )

        # Compute fixed-point representation for output tensors
        outputs_fp = []
        for i in range(len(weights_scales)):
            real_multiplier = (input_scales[0] * weights_scales[i]) / output_scales[0]
            outputs_fp.append(AirFixedPointScale.from_real_multiplier(real_multiplier))
        # END FOR

        sub_values.update(
            dict(
                options=options,
                input_tensor=input_tensor,
                weights_tensor=weights_tensor,
                bias_tensor=bias_tensor,
                output_tensor=output_tensor,
                scratch_tensor=scratch_tensor,
                outputs_fp=outputs_fp,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )

        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("transpose_conv.h")
        src_template = load_template("transpose_conv.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
