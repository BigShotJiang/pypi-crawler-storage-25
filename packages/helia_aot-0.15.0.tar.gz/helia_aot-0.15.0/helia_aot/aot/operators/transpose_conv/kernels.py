from typing import TYPE_CHECKING, Any
from helia_aot.air import AirTensorDim
from helia_aot.platforms import SocCapability
from .defines import TransposeConvKernelSpec

if TYPE_CHECKING:
    from .operator import TransposeConvOperator
else:
    TransposeConvOperator = Any


def k_arm_transpose_conv_s8() -> TransposeConvKernelSpec:
    # Generic fallback

    def scratch(op: TransposeConvOperator) -> int:
        return 0

    def weight_sum_size(op: TransposeConvOperator) -> int:
        input = op.input_tensors[op.kInputTensorIndex]
        weights = op.get_local_tensor(op.kWeightsTensorName)
        output = op.output_tensors[op.kOutputTensorIndex]

        options = op.op.options

        buf_x = (
            (input.shape[AirTensorDim.W] - 1) * options.stride_width
            + max(weights.shape[AirTensorDim.W], options.stride_width)
        ) * output.shape[AirTensorDim.C]

        buf_y = max(weights.shape[AirTensorDim.H], options.stride_height)
        buf_size = buf_x * buf_y * 4
        return buf_size

    return TransposeConvKernelSpec(
        id="arm_transpose_conv_s8",
        fn_name="arm_transpose_conv_s8",
        capabilities=[SocCapability.MCU, SocCapability.DSP, SocCapability.MVE],
        priority=1,
        rules=(lambda _op: True,),
        compute_scratch_size=scratch,
        compute_weight_sum_size=weight_sum_size,
    )


# ---------- registry ----------
available_kernels: list[TransposeConvKernelSpec] = [
    k_arm_transpose_conv_s8(),
]
