from pathlib import Path
import numpy as np
from helia_aot.air import (
    AirOpType,
    AirModel,
    AirOperator,
    AirTensor,
    AirTensorKind,
    AirFixedPointScale,
    AirFullyConnectedOptions,
    reduce_multiplier_q31_to_q15
)
from helia_aot.platforms import SocPlatform
from helia_aot.platforms.defines import SocCapability
from .operator import AotOperator
from .utils import vector_sum_s8
from ..templates import load_template


class FullyConnectedOperator(AotOperator):
    TYPE: AirOpType = AirOpType.FULLY_CONNECTED

    kInputTensorIndex = 0
    kOutputTensorIndex = 0
    # Local tensors
    kWeightsTensorName = "weights"
    kBiasTensorName = "bias"
    kWeightSumTensorName = "weight_sum"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """FULLY_CONNECTED operator.

        This operator performs a fully connected layer operation on the input tensor with the given weight and bias tensors.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)


    def compute_weight_sum_size(self) -> int:
        """Compute the size of the weight sum tensor.

        Returns:
            int: Size of the weight sum tensor in int32_t.
        """
        weights_tensor = self.get_local_tensor(self.kWeightsTensorName)
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        if output_tensor.dtype == np.int8 and self._supports_weight_sum():
            return weights_tensor.shape[-2]
        elif output_tensor.dtype == np.int16:
            return 0
        return 0

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        weights_tensor = self.get_local_tensor(self.kWeightsTensorName)

        bias_tensor = None
        if self.kBiasTensorName in self.op.named_tensors:
            bias_tensor = self.get_local_tensor(self.kBiasTensorName)

        weight_sum_tensor = None
        if self.kWeightSumTensorName in self.op.named_tensors:
            weight_sum_tensor = self.get_local_tensor(self.kWeightSumTensorName)

        input_scales = input_tensor.quantization.scale
        weights_scales = weights_tensor.quantization.scale
        output_scales = output_tensor.quantization.scale

        activation_min, activation_max = self.op.options.activation.compute_range(
            output_zero_point=output_tensor.quantization.zero_point[0],
            output_scale=output_scales[0],
            dtype=output_tensor.dtype,
        )

        # Compute fixed-point representation for output tensors
        outputs_fp = []
        for i in range(len(weights_scales)):
            real_multiplier = (input_scales[0] * weights_scales[i]) / output_scales[0]
            outputs_fp.append(AirFixedPointScale.from_real_multiplier(real_multiplier))
        # END FOR

        input_batch_count = int(np.prod(input_tensor.shape[:-1])) if len(input_tensor.shape) > 1 else 1
        output_batch_count = int(np.prod(output_tensor.shape[:-1])) if len(output_tensor.shape) > 1 else 1
        if input_batch_count != output_batch_count:
            raise ValueError(
                "FULLY_CONNECTED batch mismatch: "
                f"input batch={input_batch_count}, output batch={output_batch_count}. "
                "Expected output leading dimensions to match input leading dimensions."
            )

        # For 16x8 per-channel, we pre-compute corrected multipliers
        if len(outputs_fp) > 1 and output_tensor.dtype == np.int16:
            for i in range(len(outputs_fp)):
                outputs_fp[i].multiplier = reduce_multiplier_q31_to_q15(outputs_fp[i].multiplier)
        # END IF

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                weights_tensor=weights_tensor,
                bias_tensor=bias_tensor,
                weight_sum_tensor=weight_sum_tensor,
                input_batch_count=input_batch_count,
                output_batch_count=output_batch_count,
                outputs_fp=outputs_fp,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirFullyConnectedOptions)
        if self.kWeightsTensorName not in self.op.named_tensors:
            raise KeyError(f"Operator {self.op.id} does not have weights tensor defined")
        # Need 1 input and 1 output
        if len(self.input_tensors) != 1:
            raise ValueError("Operator must have exactly one input tensor")
        if len(self.output_tensors) != 1:
            raise ValueError("Operator must have exactly one output tensor")
        # Input and output must be same dtype
        if self.input_tensors[self.kInputTensorIndex].dtype != self.output_tensors[self.kOutputTensorIndex].dtype:
            raise ValueError("Operator input and output tensors must have the same dtype")
        # Support only int8 and int16
        if self.input_tensors[self.kInputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input/output tensor dtype", self.input_tensors[self.kInputTensorIndex].dtype)

    def _supports_weight_sum(self) -> bool:
        return SocCapability.MVE in self.platform.capabilities

    def _should_precompute_weight_sum(self) -> bool:
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        weights_tensor = self.get_local_tensor(self.kWeightsTensorName)
        return (
            output_tensor.dtype == np.int8
            and self._supports_weight_sum()
            and weights_tensor.data is not None
        )

    def _get_zero_point(self, tensor: AirTensor) -> int:
        if tensor.quantization is None or tensor.quantization.zero_point is None:
            return 0
        if len(tensor.quantization.zero_point) == 0:
            return 0
        return int(tensor.quantization.zero_point[0])

    def on_resolve(self):
        self.validate()

        weight_sum_buffer_size = self.compute_weight_sum_size()
        if weight_sum_buffer_size <= 0:
            if self.kWeightSumTensorName in self.op.named_tensors:
                del self.op.named_tensors[self.kWeightSumTensorName]
            return

        weight_sum_tensor_id = f"{self.name}_{self.kWeightSumTensorName}"
        if self.model.has_tensor(weight_sum_tensor_id):
            self.model.remove_tensor(weight_sum_tensor_id)
        if self.kWeightSumTensorName in self.op.named_tensors:
            del self.op.named_tensors[self.kWeightSumTensorName]

        weights_tensor = self.get_local_tensor(self.kWeightsTensorName)
        bias_tensor = None
        if self.kBiasTensorName in self.op.named_tensors:
            bias_tensor = self.get_local_tensor(self.kBiasTensorName)

        if self._should_precompute_weight_sum() and weights_tensor.data is not None:
            input_tensor = self.input_tensors[self.kInputTensorIndex]

            lhs_offset = -self._get_zero_point(input_tensor)
            rhs_offset = -self._get_zero_point(weights_tensor)

            bias_data = bias_tensor.data if (bias_tensor is not None and bias_tensor.data is not None) else None

            weight_sum = vector_sum_s8(
                vector_data=weights_tensor.data,
                vector_cols=weights_tensor.shape[-1],
                vector_rows=weights_tensor.shape[-2],
                lhs_offset=lhs_offset,
                rhs_offset=rhs_offset,
                bias_data=bias_data,
            ).astype(np.int32)

            weight_sum_tensor = AirTensor(
                id=weight_sum_tensor_id,
                kind=AirTensorKind.CONSTANT,
                data=weight_sum,
            )

            self.model.add_tensor(weight_sum_tensor)
            self.op.named_tensors[self.kWeightSumTensorName] = weight_sum_tensor.id

            if bias_tensor is not None:
                del self.op.named_tensors[self.kBiasTensorName]
                self.model.remove_tensor(bias_tensor.id)

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("fully_connected.h")
        src_template = load_template("fully_connected.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
