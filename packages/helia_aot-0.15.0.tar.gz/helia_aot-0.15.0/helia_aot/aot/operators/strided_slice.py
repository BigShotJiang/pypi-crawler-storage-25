from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirStridedSliceOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class StridedSliceOperator(AotOperator):
    TYPE: AirOpType = AirOpType.STRIDED_SLICE

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """STRIDED_SLICE operator.

        This operator performs a strided slice operation on the input tensor according to the specified parameters.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[0]
        output_tensor = self.output_tensors[0]

        if len(input_tensor.shape) > 4:
            raise ValueError("Input tensor must have 4 or fewer dimensions.")

        slices = self.op.options.get_slices(input_tensor.shape)

        sub_values.update(
            dict(options=self.op.options, input_tensor=input_tensor, output_tensor=output_tensor, slices=slices)
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirStridedSliceOptions)
        if len(self.input_tensors) != 1 or len(self.output_tensors) != 1:
            raise ValueError("Strided slice operator must have exactly one input tensor and one output tensor.")
        # Ensure tensors are int8 or int16
        if self.input_tensors[0].dtype not in [np.int8, np.int16, np.int32]:
            raise ValueError("Input tensor must be int8, int16, or int32.")
        if self.output_tensors[0].dtype not in [np.int8, np.int16, np.int32]:
            raise ValueError("Output tensor must be int8, int16, or int32.")

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("strided_slice.h")
        src_template = load_template("strided_slice.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
