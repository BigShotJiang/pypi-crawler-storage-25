from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirAssignVariableOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class AssignVariableOperator(AotOperator):
    TYPE: AirOpType = AirOpType.ASSIGN_VARIABLE

    kResourceVariableIdx = 0
    kAssignTensorIdx = 1

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """ASSIGN_VARIABLE operator.

        This operator stores a resource variable tensor into persistent memory.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def validate(self):
        assert isinstance(self.op.options, AirAssignVariableOptions)
        # Assert one input and one output tensor
        assert len(self.input_tensors) == 2, "Expected two input tensors"
        assert len(self.output_tensors) == 0, "Expected zero output tensors"
        resource_dtype = np.dtype(self.input_tensors[0].dtype)
        assign_dtype = np.dtype(self.input_tensors[1].dtype)

        assert np.issubdtype(resource_dtype, np.number), (
            f"Resource tensor must be numeric, got {resource_dtype}."
        )
        assert np.issubdtype(assign_dtype, np.number), (
            f"Assign tensor must be numeric, got {assign_dtype}."
        )
        assert resource_dtype == assign_dtype, (
            f"Resource/assign dtype mismatch: {resource_dtype} vs {assign_dtype}."
        )


    def on_resolve(self):
        self.validate()

    def compute_values(self) -> dict[str, str]:
        sub_values = super().compute_values()

        resource_tensor = self.input_tensors[self.kResourceVariableIdx]
        assign_tensor = self.input_tensors[self.kAssignTensorIdx]

        sub_values.update(
            dict(
                options=self.op.options,
                resource_tensor=resource_tensor,
                assign_tensor=assign_tensor,
            )
        )

        return sub_values

    def emit(self, save_path: Path):
        sub_values = self.compute_values()

        hdr_template = load_template("assign_variable.h")
        src_template = load_template("assign_variable.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
