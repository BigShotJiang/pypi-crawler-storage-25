from pathlib import Path
from pydantic.dataclasses import dataclass
from pydantic import ConfigDict, Field
import numpy as np
from helia_aot.air import AirOpType, AirModel, AirTensor, AirOperator, AirTensorKind, AirHardSwishOptions, AirFixedPointScale
from helia_aot.aot.operators.operator import OperatorAttributes
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template
from .utils import downscale_q31_to_q15, tflite_round

def compute_prescale(q6: int, dtype: np.dtype) -> int:
    """Compute the prescale shift needed to keep intermediate products in range.

    Args:
        q6 (int): The quantized value representing 6.0 in the input scale
        dtype (np.dtype): The data type of the input tensor (np.int8 or np.int16)

    Returns:
        int: The prescale shift amount
    """
    prod_max = 32767 * int(q6)
    prescale = 0
    dtype_max = np.iinfo(dtype).max
    while prod_max > dtype_max:
        prescale += 1
        prod_max >>= 1
    return prescale

def make_hardswish_lut_s8(
    input_scale: float,
    input_zero_point: int,
    output_scale: float,
    output_zero_point: int
) -> np.ndarray:
    """Build a 256-entry int8 → int8 LUT for HardSwish, iterating over q in [-128,127].

    Args:
        input_scale (float): Scale of the input tensor.
        input_zero_point (int): Zero point of the input tensor.
        output_scale (float): Scale of the output tensor.
        output_zero_point (int): Zero point of the output tensor.

    Returns:
        np.ndarray: The generated LUT.
    """
    lut = np.zeros(256, dtype=np.int8)
    for q in range(-128, 128):
        # Dequantize to float
        x = (q - input_zero_point) * input_scale
        # HardSwish: x * relu6(x+3)/6
        relu6 = min(max(x + 3.0, 0.0), 6.0)
        y = x * (relu6 / 6.0)
        # Requantize back to int8
        qy = int(round(y / output_scale + output_zero_point))
        qy = np.clip(qy, -128, 127)
        lut[q + 128] = np.int8(qy)
    return lut

@dataclass(config=ConfigDict(extra="allow"))
class HardSwishAttributes(OperatorAttributes):
    use_lut: bool = Field(True, description="Whether to use a LUT for HardSwish computation.")
    compat_variant: bool = Field(True, description="Use heliaRT/TFLM compatible kernel variant.")


class HardSwishOperator(AotOperator):
    TYPE: AirOpType = AirOpType.HARD_SWISH

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0
    # Local tensors
    kLutTensorName = "lut"

    attributes: HardSwishAttributes

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """HARD_SWISH operator.

        This operator computes the hard swish activation function on the input tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)
        self.attributes = HardSwishAttributes(**attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        sub_values.update(dict(
            input_tensor=input_tensor,
            output_tensor=output_tensor,
        ))

        # If using LUTs for S8
        if self.kLutTensorName in self.op.named_tensors:
            lut_tensor = self.get_local_tensor(self.kLutTensorName)
            sub_values.update(dict(lut_tensor=lut_tensor))
            return sub_values

        input_scale = input_tensor.quantization.scale[0]
        input_zero_point = input_tensor.quantization.zero_point[0]
        output_scale = output_tensor.quantization.scale[0]
        output_zero_point = output_tensor.quantization.zero_point[0]

        sub_values.update(dict(
            input_zero_point=input_zero_point,
            output_zero_point=output_zero_point
        ))

        # Use compat variant for S8 if enabled
        if input_tensor.dtype == np.int8 and self.attributes.compat_variant:
            hires_input_scale = (1.0 / 128.0) * float(input_scale)
            out_mul_real = hires_input_scale / float(output_scale)
            output_fp = AirFixedPointScale.from_real_multiplier(out_mul_real)
            output_fp.multiplier = downscale_q31_to_q15(output_fp.multiplier)

            relu_scale = 3.0 / 32768.0
            relu_mul_real = hires_input_scale / relu_scale
            relu_fp = AirFixedPointScale.from_real_multiplier(relu_mul_real)
            relu_fp.multiplier = downscale_q31_to_q15(relu_fp.multiplier)
            sub_values.update(dict(
                use_compat=True,
                output_fp=output_fp,
                relu_fp=relu_fp,
            ))

        # Use precise variant
        else:
            relu_q3 = tflite_round(3.0 / input_scale)
            relu_q6 = tflite_round(6.0 / input_scale)
            prescale = compute_prescale(relu_q6, input_tensor.dtype)
            real_multiplier = (input_scale * input_scale) / (6.0 * output_scale)
            adj_multiplier = real_multiplier * (1 << prescale)
            output_fp = AirFixedPointScale.from_real_multiplier(adj_multiplier)
            sub_values.update(dict(
                use_compat=False,
                output_fp=output_fp,
                relu_q3=relu_q3,
                relu_q6=relu_q6,
                prescale=prescale,
            ))

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirHardSwishOptions)
        if len(self.input_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")
        if self.input_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError(f"{self.TYPE} operator ({self.id}) input tensor must be int8 or int16.")
        if self.output_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError(f"{self.TYPE} operator ({self.id}) output tensor must be int8 or int16.")

    def on_resolve(self):
        self.validate()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        # Use LUTs for S8 if enabled
        if input_tensor.dtype == np.int8 and self.attributes.use_lut:
            lut_tensor = AirTensor(
                id=f"{self.name}_{self.kLutTensorName}",
                kind=AirTensorKind.CONSTANT,
                data=make_hardswish_lut_s8(
                    input_tensor.quantization.scale[0],
                    input_tensor.quantization.zero_point[0],
                    output_tensor.quantization.scale[0],
                    output_tensor.quantization.zero_point[0],
                ),
            )
            self.op.named_tensors[self.kLutTensorName] = lut_tensor.id
            self.model.add_tensor(lut_tensor)

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        template_name = "hard_swish"
        if self.kLutTensorName in self.op.named_tensors:
            template_name = "activation_lut"

        hdr_template = load_template(f"{template_name}.h")
        src_template = load_template(f"{template_name}.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
