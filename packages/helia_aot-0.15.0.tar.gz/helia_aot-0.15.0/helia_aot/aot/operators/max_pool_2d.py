from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirMaxPool2DOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class MaxPool2DOperator(AotOperator):
    TYPE: AirOpType = AirOpType.MAX_POOL_2D

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """MAX_POOL_2D operator.

        This operator computes the max pooling of a tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        activation_min, activation_max = self.op.options.activation.compute_range(
            output_zero_point=output_tensor.quantization.zero_point[0],
            output_scale=output_tensor.quantization.scale[0],
            dtype=output_tensor.dtype,
        )

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirMaxPool2DOptions)
        if self.input_tensors[self.kInputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input tensor dtype", self.input_tensors[self.kInputTensorIndex].dtype)
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported output tensor dtype", self.output_tensors[self.kOutputTensorIndex].dtype)

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("max_pool_2d.h")
        src_template = load_template("max_pool_2d.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
