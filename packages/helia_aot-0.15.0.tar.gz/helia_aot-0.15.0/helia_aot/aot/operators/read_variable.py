from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirReadVariableOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class ReadVariableOperator(AotOperator):
    TYPE: AirOpType = AirOpType.READ_VARIABLE

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """READ_VARIABLE operator.

        This operator reads a resource variable tensor from persistent memory.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()
        resource_tensor = self.input_tensors[self.kInputTensorIndex]
        read_tensor = self.output_tensors[self.kOutputTensorIndex]

        sub_values.update(
            dict(
                options=self.op.options,
                resource_tensor=resource_tensor,
                read_tensor=read_tensor,
            )
        )

        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirReadVariableOptions)
        # Assert one input and one output tensor
        assert len(self.input_tensors) == 1, "Expected one input tensor"
        assert len(self.output_tensors) == 1, "Expected one output tensor"
        resource_dtype = np.dtype(self.input_tensors[0].dtype)
        output_dtype = np.dtype(self.output_tensors[0].dtype)

        assert np.issubdtype(resource_dtype, np.number), (
            f"Resource tensor must be numeric, got {resource_dtype}."
        )
        assert np.issubdtype(output_dtype, np.number), (
            f"Read tensor must be numeric, got {output_dtype}."
        )
        assert resource_dtype == output_dtype, (
            f"Resource/read dtype mismatch: {resource_dtype} vs {output_dtype}."
        )

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("read_variable.h")
        src_template = load_template("read_variable.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
