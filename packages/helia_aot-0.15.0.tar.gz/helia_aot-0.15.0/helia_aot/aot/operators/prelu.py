from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirFixedPointScale
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class PreluOperator(AotOperator):
    TYPE: AirOpType = AirOpType.PRELU

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0
    kAlphaName = "alpha"
    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """PReLU operator.

        This operator computes the PReLU activation function on the input tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        if self.kAlphaName not in self.op.named_tensors:
            raise ValueError("PReLU operator requires an alpha tensor named 'alpha'")
        alpha_tensor = self.get_local_tensor(self.kAlphaName)

        output_multiplier_identity = (input_tensor.quantization.scale[0]) / (output_tensor.quantization.scale[0])
        output_multiplier_identity = AirFixedPointScale.from_real_multiplier(output_multiplier_identity)

        output_multiplier_alpha = (input_tensor.quantization.scale[0] * alpha_tensor.quantization.scale[0]) / (output_tensor.quantization.scale[0])
        output_multiplier_alpha = AirFixedPointScale.from_real_multiplier(output_multiplier_alpha)
        sub_values.update(
            dict(
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                alpha_tensor=alpha_tensor,
                output_multiplier_identity=output_multiplier_identity,
                output_multiplier_alpha=output_multiplier_alpha,
            )
        )
        return sub_values

    def validate(self):
        """Validate the operator configuration."""
        assert len(self.input_tensors) == 1, "Invalid number of input tensors"
        assert len(self.output_tensors) == 1, "Invalid number of output tensors"
        assert self.input_tensors[self.kInputTensorIndex].shape == self.output_tensors[self.kOutputTensorIndex].shape, "Input and Output tensors must have the same shape"
        if self.kAlphaName not in self.op.named_tensors:
            raise KeyError(f"Operator {self.op.id} missing alpha tensor")
        if self.input_tensors[self.kInputTensorIndex].dtype != np.int8:
            raise ValueError("Unsupported input tensor dtype", self.input_tensors[self.kInputTensorIndex].dtype)
        if self.get_local_tensor(self.kAlphaName).dtype != np.int8:
            raise ValueError("Unsupported alpha tensor dtype", self.get_local_tensor(self.kAlphaName).dtype)
        if self.output_tensors[self.kOutputTensorIndex].dtype != np.int8:
            raise ValueError("Unsupported output tensor dtype", self.output_tensors[self.kOutputTensorIndex].dtype)

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("prelu.h")
        src_template = load_template("prelu.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
