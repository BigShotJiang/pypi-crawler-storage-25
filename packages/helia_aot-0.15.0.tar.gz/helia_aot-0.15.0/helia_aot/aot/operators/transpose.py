from pathlib import Path
import numpy as np

from helia_aot.air import AirOpType, AirModel, AirOperator, AirTransposeOptions
from helia_aot.platforms import SocPlatform
from .operator import AotOperator
from ..templates import load_template


class TransposeOperator(AotOperator):
    TYPE: AirOpType = AirOpType.TRANSPOSE

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """TRANSPOSE operator.

        This operator transposes a tensor according to the specified permutation.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=self.input_tensors[0],
                output_tensor=self.output_tensors[0],
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirTransposeOptions)

        # Ensure exactly two input tensors and one output tensor
        if len(self.input_tensors) != 1 or len(self.output_tensors) != 1:
            raise ValueError("Transpose operator must have exactly two input tensors and one output tensor.")

        # Ensure tensors are int8 or int16
        if self.input_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError("Input tensor must be int8 or int16.")
        if self.output_tensors[0].dtype not in [np.int8, np.int16]:
            raise ValueError("Output tensor must be int8 or int16.")

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("transpose.h")
        src_template = load_template("transpose.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
