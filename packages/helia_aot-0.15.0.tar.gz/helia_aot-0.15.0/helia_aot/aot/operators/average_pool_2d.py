from pathlib import Path
import numpy as np
from helia_aot.air import (
    AirOpType,
    AirModel,
    AirTensorDim,
    AirOperator,
    AirTensor,
    AirTensorKind,
    AirAveragePool2DOptions,
)
from helia_aot.platforms import SocCapability, SocPlatform
from .operator import AotOperator
from ..templates import load_template


class AveragePool2DOperator(AotOperator):
    TYPE: AirOpType = AirOpType.AVERAGE_POOL_2D

    kInputTensorIndex: int = 0
    kOutputTensorIndex: int = 0
    # Local tensors
    kScratchTensorName = "scratch"

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """AVERAGE_POOL_2D operator.

        This operator computes the average pooling of a tensor.

        Args:
            op (AirOperator): The AIR operator to wrap.
            model (AirModel): The AIR model.
            platform (SocPlatform): The target platform for code generation.
            prefix (str, optional): Prefix for generated code files. Defaults to "aot".
            attributes (dict[str, str], optional): Attributes for template values. Defaults to {}.
        """

        super().__init__(op, model, platform, prefix, attributes)

    def compute_scratch_size(self) -> int:
        """Compute the scratch size for the operator in bytes.

        Returns:
            int: Computed scratch size in bytes.
        """
        # NOTE: Same scratch size required for S8 and S16
        input_channel = int(self.input_tensors[self.kInputTensorIndex].shape[AirTensorDim.C])
        if SocCapability.MVE in self.platform.capabilities:
            return 0
        if SocCapability.DSP in self.platform.capabilities:
            return input_channel * 4  # ch_src * sizeof(int32_t)
        return 0

    def validate(self):
        assert isinstance(self.op.options, AirAveragePool2DOptions)
        if len(self.input_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one input tensor.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")
        if self.input_tensors[self.kInputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported input tensor dtype", self.input_tensors[self.kInputTensorIndex].dtype)
        if self.output_tensors[self.kOutputTensorIndex].dtype not in [np.int8, np.int16]:
            raise ValueError("Unsupported output tensor dtype", self.output_tensors[self.kOutputTensorIndex].dtype)

    def on_resolve(self):
        self.validate()

        # Add scratch tensor
        scratch_buffer_size = self.compute_scratch_size()
        if scratch_buffer_size > 0:
            scratch_tensor = AirTensor(
                id=f"{self.name}_{self.kScratchTensorName}",
                kind=AirTensorKind.SCRATCH,
                shape=(scratch_buffer_size,),
                dtype=np.dtype(np.int8),
            )
            self.op.named_tensors[self.kScratchTensorName] = scratch_tensor.id
            self.model.add_tensor(scratch_tensor)
        # END IF

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator.

        Returns:
            dict[str, str]: Computed values for the operator.
        """

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        scratch_tensor = None
        if self.kScratchTensorName in self.op.named_tensors:
            scratch_tensor = self.get_local_tensor(self.kScratchTensorName)

        activation_min, activation_max = self.op.options.activation.compute_range(
            output_zero_point=output_tensor.quantization.zero_point[0],
            output_scale=output_tensor.quantization.scale[0],
            dtype=output_tensor.dtype,
        )

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                output_tensor=output_tensor,
                scratch_tensor=scratch_tensor,
                activation_min=activation_min,
                activation_max=activation_max,
            )
        )
        return sub_values

    def emit(self, save_path: Path):
        """Generate the source code for the operator.

        Args:
            save_path (Path): Path to save the generated code.
        """

        sub_values = self.compute_values()

        hdr_template = load_template("average_pool_2d.h")
        src_template = load_template("average_pool_2d.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
