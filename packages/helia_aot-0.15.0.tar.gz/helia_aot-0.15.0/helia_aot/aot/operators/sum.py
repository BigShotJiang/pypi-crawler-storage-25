import numpy as np
from pathlib import Path

from helia_aot.air import AirFixedPointScale, AirModel, AirOpType, AirOperator, AirSumOptions
from helia_aot.platforms import SocPlatform

from .operator import AotOperator
from ..templates import load_template


class SumOperator(AotOperator):
    TYPE: AirOpType = AirOpType.SUM

    kInputTensorIndex = 0
    kAxisTensorIndex = 1
    kOutputTensorIndex = 0

    def __init__(
        self,
        op: AirOperator,
        model: AirModel,
        platform: SocPlatform,
        prefix: str = "aot",
        attributes: dict[str, str] = {},
    ):
        """SUM operator."""

        super().__init__(op, model, platform, prefix, attributes)

    def compute_values(self) -> dict[str, str]:
        """Compute the values for the operator."""

        sub_values = super().compute_values()

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        axis_tensor = self.input_tensors[self.kAxisTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]
        
        input_rank = len(input_tensor.shape)
        axis_data = np.asarray(axis_tensor.data, dtype=np.int32).reshape(-1).tolist()
        axis = sorted(set(a + input_rank if a < 0 else a for a in axis_data))

        if any(a < 0 or a >= input_rank for a in axis):
            raise ValueError(f"SUM axis {axis} is out of range for input rank {input_rank}.")

        input_dims = list(input_tensor.shape) + [1] * (4 - input_rank)
        axis_dims = [0, 0, 0, 0]
        for a in axis:
            axis_dims[a] = 1

        output_dims = [1 if axis_dims[i] else input_dims[i] for i in range(4)]

        real_multiplier = input_tensor.quantization.scale[0] / output_tensor.quantization.scale[0]
        output_fp = AirFixedPointScale.from_real_multiplier(real_multiplier)

        sub_values.update(
            dict(
                options=self.op.options,
                input_tensor=input_tensor,
                axis_tensor=axis_tensor,
                output_tensor=output_tensor,
                input_dims=input_dims,
                axis_dims=axis_dims,
                output_dims=output_dims,
                output_fp=output_fp,
            )
        )
        return sub_values

    def validate(self):
        assert isinstance(self.op.options, AirSumOptions)
        if len(self.input_tensors) != 2:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly two input tensors.")
        if len(self.output_tensors) != 1:
            raise ValueError(f"{self.TYPE} operator ({self.id}) must have exactly one output tensor.")

        input_tensor = self.input_tensors[self.kInputTensorIndex]
        axis_tensor = self.input_tensors[self.kAxisTensorIndex]
        output_tensor = self.output_tensors[self.kOutputTensorIndex]

        if input_tensor.dtype not in (np.int8, np.int16):
            raise ValueError("SUM input tensor must be int8 or int16.")
        if output_tensor.dtype not in (np.int8, np.int16):
            raise ValueError("SUM output tensor must be int8 or int16.")
        if input_tensor.dtype != output_tensor.dtype:
            raise ValueError("SUM input and output tensors must have the same dtype.")
        if axis_tensor.dtype != np.int32:
            raise ValueError("SUM axes tensor must be int32.")
        if input_tensor.quantization is None or output_tensor.quantization is None:
            raise ValueError("SUM input and output tensors must have quantization parameters.")

    def on_resolve(self):
        self.validate()

    def emit(self, save_path: Path):
        """Generate the source code for the operator."""

        sub_values = self.compute_values()

        hdr_template = load_template("sum.h")
        src_template = load_template("sum.c")

        hdr_code = hdr_template.render(sub_values)
        src_code = src_template.render(sub_values)

        with open(save_path / "includes-api" / f"{self.prefix}_{self.name}.h", "w") as f:
            f.write(hdr_code)
        with open(save_path / "src" / f"{self.prefix}_{self.name}.c", "w") as f:
            f.write(src_code)
