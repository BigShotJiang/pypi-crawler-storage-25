from pydantic.dataclasses import dataclass
from pydantic import Field


@dataclass
class AirDimensionMetaData:
    """Metadata for a dimension in a sparse tensor.

    Attributes:
        format (int): Format of the dimension.
        dense_size (int): Dense size of the dimension.
        array_segments_type (int): Array segments type.
        array_segments (list[int] | None): Array segments.
        array_indices_type (int): Array indices type.
        array_indices (list[int] | None): Array indices.
    """

    format: int = Field(0, description="Format of the dimension")
    dense_size: int = Field(0, description="Dense size of the dimension")
    array_segments_type: int = Field(0, description="Array segments type")
    array_segments: list[int] | None = Field(None, description="Array segments")
    array_indices_type: int = Field(0, description="Array indices type")
    array_indices: list[int] | None = Field(None, description="Array indices")


@dataclass
class AirSparsityParameters:
    """Parameters for sparsity in a tensor.

    Attributes:
        traversal_order (list[int] | None): Traversal order.
        block_map (list[int] | None): Block map.
        dim_meta_data (list[AirDimensionMetaData] | None): Dimension metadata.
    """

    traversal_order: list[int] | None = Field(None, description="Traversal order")
    block_map: list[int] | None = Field(None, description="Block map")
    dim_meta_data: list[AirDimensionMetaData] | None = Field(None, description="Dimension metadata")
