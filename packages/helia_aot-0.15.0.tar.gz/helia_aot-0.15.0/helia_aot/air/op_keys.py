from __future__ import annotations

from .enums import AirOpType


def custom_code_to_op_key(custom_code: str | bytes | bytearray) -> str:
    """Convert LiteRT customCode into the canonical registry key."""
    if isinstance(custom_code, (bytes, bytearray)):
        custom_code = custom_code.decode("utf-8")
    if not isinstance(custom_code, str):
        raise TypeError("customCode must be str, bytes, or bytearray")
    op_key = canonical_op_key(custom_code.replace("-", "_").replace(" ", "_").strip())
    if not op_key or not any(ch.isalnum() for ch in op_key):
        raise ValueError("customCode must include at least one alphanumeric character")
    return op_key


def canonical_op_key(value: AirOpType | str) -> str:
    """Normalize op identifiers to uppercase string keys."""
    if isinstance(value, AirOpType):
        return value.value
    if isinstance(value, str):
        return value.upper()
    raise TypeError("op id must be AirOpType or str")
