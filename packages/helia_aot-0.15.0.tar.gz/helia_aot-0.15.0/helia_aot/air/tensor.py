from pydantic.dataclasses import dataclass
from typing import Any, Annotated, cast
from pydantic import Field, PlainValidator, PlainSerializer
import numpy as np
import numpy.typing as npt
from .enums import AirTensorKind
from .sparsity import AirSparsityParameters
from .quantization import AirQuantizationParameters

TensorId = str

Array = Annotated[
    npt.NDArray[Any],
    PlainValidator(lambda v: v if isinstance(v, np.ndarray) else np.asarray(v)),
    PlainSerializer(lambda a, _: a.tolist()),
]

DType = Annotated[np.dtype, PlainValidator(lambda v: np.dtype(v)), PlainSerializer(lambda dt, _: dt.name)]


@dataclass
class AirTensor:
    """AIR tensor representation."""

    id: TensorId = Field(..., description="Unique tensor identifier")
    kind: AirTensorKind = Field(AirTensorKind.SCRATCH, description="The kind of tensor")
    quantization: AirQuantizationParameters | None = Field(
        default_factory=AirQuantizationParameters, description="Quantization parameters for the tensor"
    )
    sparsity: AirSparsityParameters | None = Field(
        default_factory=AirSparsityParameters, description="Sparsity parameters for the tensor"
    )

    # Real attributes
    _shape: tuple[int, ...] | None = Field(
        default=None, validation_alias="shape", repr=False, description="Internal shape storage"
    )
    _dtype: DType | None = Field(
        default=None, validation_alias="dtype", repr=False, description="Internal dtype storage"
    )
    _data: Array | None = Field(default=None, validation_alias="data", repr=False, description="Internal data storage")

    buffer_index: int | None = Field(None, description="Index of the buffer this tensor is mapped to")
    local_name: str | None = Field(None, description="Local name for the tensor")
    shape_signature: tuple[int, ...] | None = Field(None, description="Shape signature of the tensor")
    has_rank: bool = Field(False, description="Indicates if the tensor has a rank")
    alias_of: TensorId | None = Field(None, description="Optional alias for this tensor")
    alignment_hint: int | None = Field(None, description="Alignment hint for the tensor in bytes")

    def __post_init__(self):
        if self._data is not None:
            self.data = self._data
        if self._data is None and (self._shape is None or self._dtype is None):
            raise ValueError("Tensor must have either data or both shape and dtype defined.")

    def __hash__(self):
        return hash(self.id)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, AirTensor):
            return False
        return self.id == other.id

    @property
    def shape(self) -> tuple[int, ...]:
        if self.data is not None:
            return self.data.shape
        return self._shape

    @shape.setter
    def shape(self, shape: tuple[int, ...]):
        if self.data is not None:
            # Try to reshape the data if possible
            self.data.shape = shape
        self._shape = shape

    @property
    def dtype(self) -> np.dtype:
        if self.data is not None:
            return self.data.dtype
        return self._dtype

    @dtype.setter
    def dtype(self, val: np.dtype | str):
        if self.data is not None:
            self._data = self._data.astype(val)
        self._dtype = np.dtype(val)

    @property
    def data(self) -> npt.NDArray | None:
        """Return the data of the tensor."""
        return self._data

    @data.setter
    def data(self, data: npt.NDArray | None):
        """Set the data of the tensor."""
        if data is None:
            self._data = None
            return
        if not isinstance(data, np.ndarray):
            raise TypeError("Data must be a numpy ndarray.")

        self._shape = data.shape
        self._dtype = data.dtype
        self._data = data

    @property
    def size(self) -> int:
        """Return the size of the tensor."""
        if self.data is not None:
            return self.data.size
        if self._shape is not None:
            return np.prod(self._shape)
        raise ValueError("Tensor shape is not set")

    @property
    def nbytes(self) -> int:
        """Return the number of bytes in the tensor."""
        if self.data is not None:
            return self.data.nbytes
        if self._dtype is not None:
            return self.size * self._dtype.itemsize
        raise ValueError("Tensor dtype is not set")

    @property
    def ndim(self) -> int:
        """Return the number of dimensions of the tensor."""
        return len(self.shape)

    @property
    def is_constant(self) -> bool:
        """Check if the tensor is a constant."""
        return self.kind == AirTensorKind.CONSTANT

    @property
    def is_persistent(self) -> bool:
        """Check if the tensor is a persistent variable."""
        return self.kind == AirTensorKind.PERSISTENT

    @property
    def is_scratch(self) -> bool:
        """Check if the tensor is a scratch tensor."""
        return self.kind == AirTensorKind.SCRATCH

    @property
    def name(self) -> str:
        return f"tensor_{self.id}"

    @property
    def ctype(self) -> str:
        """Return the C type of the tensor.

        This is used for generating C code that operates on the tensor.
        For example, if the tensor is of type int16, the C type will be int16_t.

        """
        if self.dtype in [
            "float16",
            "bfloat16",
            "int4",
            "int8",
            "uint8",
            "int16",
            "uint16",
            "int32",
            "uint32",
            "int64",
            "uint64",
            "complex64",
            "complex128",
        ]:
            return f"{self.dtype}_t"

        if self.dtype == "float32":
            return "float"

        if self.dtype in ["float", "bool"]:
            return f"{self.dtype}"

    @property
    def dtype_alignment_floor(self) -> int:
        """Return the alignment floor based on the tensor's dtype."""
        return max(1, self.dtype.itemsize)

    def get_shape_nhwc(self, pre: bool = True) -> tuple[int, int, int, int]:
        """Return a NHWC padded shape tuple, padding missing axes with 1."""

        shape = tuple(self.shape)
        if len(shape) > 4:
            raise ValueError(f"NHWC view requires rank <= 4, got {len(shape)} dims")

        pad = 4 - len(shape)
        filler = (1,) * pad
        nhwc = filler + shape if pre else shape + filler
        return cast(tuple[int, int, int, int], nhwc)
    
    def get_shape_with_axis_expanded(self, axis: int) -> tuple[int, ...]:
        base = tuple(self.shape)
        rank = len(base)

        if axis < 0:
            axis += rank + 1
        if axis < 0 or axis > rank:
            raise ValueError(f"axis {axis} out of range for rank {rank}")

        expanded = base if rank >= 4 else base[:axis] + (1,) + base[axis:]

        # enforce 4D NHWC
        if len(expanded) < 4:
            expanded = expanded + (1,) * (4 - len(expanded))
        elif len(expanded) > 4:
            expanded = expanded[:4]

        return expanded

    
