"""

:material-vector-polyline: Ambiq Intermediate Representation (AIR) API

The AIR API provides a unified intermediate representation for AI models to ease conversion. This eases adding additional frameworks in the future.

Copyright 2025 Ambiq. All Rights Reserved.

"""

from .enums import (
    AirOpType,
    AirTensorType,
    AirTensorDim,
    AirActivationType,
    AirReluType,
    AirComparisonType,
    AirFullyConnectedWeightsFormat,
    AirTensorKind,
    AirSpatialPad,
)
from .model import AirModel
from .operator import OpId, AirOperator
from .options import (
    AirOperatorOptions,
    get_options_class,
    AirDepthwiseConv2DOptions,
    AirTransposeConvOptions,
    AirAddOptions,
    AirSubOptions,
    AirSquaredDifferenceOptions,
    AirAssignVariableOptions,
    AirAveragePool2DOptions,
    AirBatchMatMulOptions,
    AirBatchToSpaceNDOptions,
    AirConcatenationOptions,
    AirConv2DOptions,
    AirDepthToSpaceOptions,
    AirDequantizeOptions,
    AirExpandDimsOptions,
    AirFillOptions,
    AirFullyConnectedOptions,
    AirHardSwishOptions,
    AirLeakyReluOptions,
    AirLogisticOptions,
    AirMaxPool2DOptions,
    AirMaximumOptions,
    AirMeanOptions,
    AirSumOptions,
    AirMinimumOptions,
    AirMulOptions,
    AirComparisonOptions,
    AirPackOptions,
    AirPadOptions,
    AirQuantizeOptions,
    AirReadVariableOptions,
    AirReduceMaxOptions,
    AirReduceMinOptions,
    AirArgMaxOptions,
    AirArgMinOptions,
    AirReluOptions,
    AirReshapeOptions,
    AirShapeOptions,
    AirSoftmaxOptions,
    AirSpaceToBatchNDOptions,
    AirSpaceToDepthOptions,
    AirSplitOptions,
    AirSqueezeOptions,
    AirSliceOptions,
    AirGatherOptions,
    AirGatherNdOptions,
    AirStridedSliceOptions,
    AirEthosUOptions,
    AirTanhOptions,
    AirTransposeOptions,
    AirReverseV2Options,
    AirUnpackOptions,
    AirZerosLikeOptions,
    AirSvdfOptions,
    AirPreluOptions,
    AirResizeNearestNeighborOptions,
    AirAbsOptions,
    AirSqrtOptions,
    AirRsqrtOptions,
)
from .quantization import (
    AirFixedPointScale,
    AirQuantizationDetails,
    AirBlockwiseQuantization,
    AirQuantizationParameters,
)
from .sparsity import AirDimensionMetaData, AirSparsityParameters
from .tensor import TensorId, AirTensor
from .utils import (
    quantize_multiplier,
    compute_fused_activation_range,
    compute_padding_with_offset,
    compute_padding,
    reduce_multiplier_q31_to_q15
)
from .op_keys import canonical_op_key, custom_code_to_op_key

from .shape_propagation import propagate_shapes, ShapeInferenceResult
