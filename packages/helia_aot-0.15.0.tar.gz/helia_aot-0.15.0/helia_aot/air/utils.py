import math
import numpy.typing as npt
from .enums import AirActivationType, AirPaddingType


def quantize_multiplier(real_multiplier: float) -> tuple[int, int]:
    """Convert a floating point multiplier into a fixed-point multiplier and shift.

    Given a real multiplier, this function computes a pair (quantized_multiplier, shift)
    such that the fixed-point multiplication approximates the real multiplier:

        real_multiplier ~ quantized_multiplier / (2^(31 - shift))

    This is typically used in quantized inference to convert floating-point scaling
    factors to fixed-point representation.

    The CMSIS-NN ``arm_nn_divide_by_power_of_two`` function only supports
    exponent values in [0, 31], so the resulting shift is clamped to [-31, 30].
    When the real multiplier is so small that the shift would fall below -31
    the contribution is negligible and the multiplier is flushed to zero.

    Args:
        real_multiplier (float): The floating-point multiplier.

    Returns:
        tuple: (quantized_multiplier, shift)
    """
    if real_multiplier == 0:
        return 0, 0

    # Decompose real_multiplier into fraction and exponent such that:
    #   real_multiplier = fraction * 2^exponent,  with fraction in [0.5, 1).
    fraction, exponent = math.frexp(real_multiplier)

    # Convert fraction to a Q31 fixed-point value.
    # Use round-half-up instead of banker's rounding:
    quantized_multiplier = int(math.floor(fraction * (1 << 31) + 0.5))
    # quantized_multiplier = int(round(fraction * (1 << 31)))

    # Handle the corner-case where rounding might push the value to 1<<31.
    if quantized_multiplier == (1 << 31):
        quantized_multiplier //= 2
        exponent += 1

    shift = exponent

    # Clamp to the range supported by CMSIS-NN.  arm_nn_requantize calls
    # arm_nn_divide_by_power_of_two with ``-shift`` when shift < 0; that
    # helper uses ``(1 << exponent)`` in int32_t arithmetic, so the
    # exponent must stay in [0, 31].  When shift < -31 the effective
    # multiplier is < 2^{-62} which is negligible – flush to zero.
    if shift < -31:
        return 0, 0

    # Upper-bound clamp: arm_nn_requantize (single-rounding branch) computes
    # ``total_shift = 31 - shift``, which must be >= 1 for the rounding
    # ``(result + 1) >> 1`` to be valid.  The default (double-rounding) branch
    # uses ``val * (1 << shift)`` in int32_t, so shift > 30 causes UB.
    # Match TFLite's QuantizeMultiplier which saturates to (INT32_MAX, 30).
    if shift > 30:
        return (1 << 31) - 1, 30

    return quantized_multiplier, shift


def compute_fused_activation_range(
    activation_function: AirActivationType,
    output_zero_point: int = 0,
    output_scale: float = 1.0,
    qmin: int = -128,
    qmax: int = 127,
) -> tuple[int, int]:
    """Compute the activation min and max values based on the fused activation function.

    Args:
        activation_function (litert.ActivationFunctionType): The activation function type.
        output_zero_point (int): The zero point for the output tensor. Defaults to 0.
        output_scale (float): The scale for the output tensor. Defaults to 1.0.
        qmin (int, optional): Minimum quantized value. Defaults to -128.
        qmax (int, optional): Maximum quantized value. Defaults to 127.

    Returns:
        tuple[int, int]: The activation min and max values.

    """
    if activation_function == AirActivationType.RELU:
        activation_min = max(output_zero_point, qmin)
        activation_max = qmax
    elif activation_function == AirActivationType.RELU6:
        quantized_6 = int(round(6.0 / output_scale)) + output_zero_point
        activation_min = max(output_zero_point, qmin)
        activation_max = min(quantized_6, qmax)
    elif activation_function == AirActivationType.RELU_N1_TO_1:
        quantized_minus1 = int(round(-1.0 / output_scale)) + output_zero_point
        quantized_plus1 = int(round(1.0 / output_scale)) + output_zero_point
        activation_min = max(quantized_minus1, qmin)
        activation_max = min(quantized_plus1, qmax)
    elif activation_function == AirActivationType.RELU_0_TO_1:
        quantized_1 = int(round(1.0 / output_scale)) + output_zero_point
        activation_min = max(output_zero_point, qmin)
        activation_max = min(quantized_1, qmax)
    else:
        activation_min = qmin
        activation_max = qmax

    return activation_min, activation_max


def compute_padding_with_offset(
    in_size: int, filter_size: int, stride: int, dilation_rate: int = 1, padding_type: int = AirPaddingType.SAME
) -> tuple[int, int]:
    """Computes a single padding value (top/left) for one dimension with offset.

    Args:
        in_size (int): Input dimension (height or width).
        filter_size (int): Kernel dimension (height or width).
        stride (int): Stride for that dimension.
        dilation_rate (int): Dilation rate for that dimension (default is 1).
        padding_type (int): 0 for SAME padding, 1 for VALID padding (default is SAME).

    Returns:
        int: The computed top or left padding value.
    """
    if padding_type == AirPaddingType.VALID:
        return 0, 0

    if padding_type == AirPaddingType.SAME:
        eff_filter_size = (filter_size - 1) * dilation_rate + 1
        out_size = math.ceil(float(in_size) / float(stride))
        pad_total = max((out_size - 1) * stride + eff_filter_size - in_size, 0)
        offset = pad_total % 2
        pad = pad_total // 2
        return pad, offset

    raise ValueError("Unsupported padding type: use 0 for SAME or 1 for VALID.")


def compute_padding(
    in_size: int, filter_size: int, stride: int, dilation_rate: int = 1, padding_type: int = AirPaddingType.SAME
) -> int:
    """Computes a single padding value (top/left) for one dimension.

    Args:
        in_size (int): Input dimension (height or width).
        filter_size (int): Kernel dimension (height or width).
        stride (int): Stride for that dimension.
        dilation_rate (int): Dilation rate for that dimension (default is 1).
        padding_type (int): 0 for SAME padding, 1 for VALID padding (default is SAME).

    Returns:
        int: The computed top or left padding value.
    """
    pad, _ = compute_padding_with_offset(
        in_size=in_size, filter_size=filter_size, stride=stride, dilation_rate=dilation_rate, padding_type=padding_type
    )
    return pad


def get_expanded_dims_shape(x: npt.NDArray, num_dims: int = 4, pre: bool = True) -> tuple[int, ...]:
    """Expand the shape of a tensor to a specified number of dimensions.

    Args:
        x (npt.NDArray): Input tensor whose shape is to be expanded.
        num_dims (int, optional): Number of dimensions to expand to. Defaults to 4.

    Returns:
        tuple[int, ...]: Expanded shape of the tensor.
    """
    shape = tuple(x.shape)

    if num_dims < 1:
        raise ValueError("num_dims must be at least 1")

    if len(shape) > num_dims:
        raise ValueError(f"Input tensor has more than {num_dims} dimensions")
    if len(shape) == num_dims:
        return shape
    if pre:
        return (1,) * (num_dims - len(shape)) + shape
    return shape + (1,) * (num_dims - len(shape))


def reduce_multiplier_q31_to_q15(multiplier: int) -> int:
    """Reduce a multiplier value for int16 quantization.

    Certain CMSIS functions for int16 quantized models require the
    multiplier to be reduced from Q31 format to Q15 format. This function
    performs that reduction.

    Args:
        multiplier (int): The original multiplier value.

    Returns:
        int: The reduced multiplier value.
    """

    if multiplier < 0x7FFF0000:
        return (multiplier + (1 << 15)) >> 16
    return 0x7FFF
