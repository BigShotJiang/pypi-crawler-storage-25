from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass, field
from typing import Callable

from helia_aot.utils import setup_logger

from .model import AirModel
from .operator import AirOperator
from .enums import AirOpType
from .op_keys import canonical_op_key
from .options import AirBatchToSpaceNDOptions, AirConcatenationOptions, AirSpaceToBatchNDOptions

logger = setup_logger(log_name=__name__)

ShapeRule = Callable[[AirOperator, AirModel], dict[str, tuple[int, ...]]]


@dataclass
class ShapeInferenceResult:
    """Shape propagation outcome.

    Attributes:
        changed_tensor_ids: Tensor IDs whose shapes changed during propagation.
        unresolved_tensor_ids: Dynamic tensor IDs that remain unresolved.
        diagnostics: Human-readable diagnostics describing inference updates and unresolved
            tensors. Skip diagnostics (rule/fallback skipped) are only included when DEBUG
            logging is enabled to avoid unbounded growth on large graphs.
    """

    changed_tensor_ids: set[str] = field(default_factory=set)
    unresolved_tensor_ids: set[str] = field(default_factory=set)
    diagnostics: list[str] = field(default_factory=list)


def _infer_space_to_batch(op: AirOperator, model: AirModel) -> dict[str, tuple[int, ...]]:
    if not isinstance(op.options, AirSpaceToBatchNDOptions) or len(op.input_ids) != 1 or len(op.output_ids) != 1:
        return {}

    output_tensor = model.get_tensor(op.output_ids[0])
    if output_tensor.shape_signature is None or len(output_tensor.shape_signature) < 1:
        return {}
    if int(output_tensor.shape_signature[0]) != -1:
        return {}

    input_shape = tuple(int(dim) for dim in model.get_tensor(op.input_ids[0]).shape)
    if len(input_shape) not in (3, 4):
        return {}

    spatial_dims = len(input_shape) - 2
    block_shape = tuple(int(dim) for dim in op.options.block_shape)
    if len(block_shape) != spatial_dims or any(dim <= 0 for dim in block_shape[:spatial_dims]):
        return {}

    paddings_by_dim = (
        (int(op.options.paddings.top), int(op.options.paddings.bottom)),
        (int(op.options.paddings.left), int(op.options.paddings.right)),
    )

    output_shape = list(input_shape)
    output_batch = int(input_shape[0])
    for idx in range(spatial_dims):
        block = block_shape[idx]
        pad_before, pad_after = paddings_by_dim[idx]
        final_dim = int(input_shape[idx + 1]) + pad_before + pad_after
        if final_dim <= 0 or final_dim % block != 0:
            return {}
        output_shape[idx + 1] = final_dim // block
        output_batch *= block
    output_shape[0] = output_batch
    return {op.output_ids[0]: tuple(output_shape)}


def _infer_batch_to_space(op: AirOperator, model: AirModel) -> dict[str, tuple[int, ...]]:
    if not isinstance(op.options, AirBatchToSpaceNDOptions) or len(op.input_ids) != 1 or len(op.output_ids) != 1:
        return {}

    output_tensor = model.get_tensor(op.output_ids[0])
    if output_tensor.shape_signature is None or len(output_tensor.shape_signature) < 1:
        return {}
    if int(output_tensor.shape_signature[0]) != -1:
        return {}

    input_shape = tuple(int(dim) for dim in model.get_tensor(op.input_ids[0]).shape)
    if len(input_shape) not in (3, 4):
        return {}

    spatial_dims = len(input_shape) - 2
    block_shape = tuple(int(dim) for dim in op.options.block_shape)
    if len(block_shape) != spatial_dims or any(dim <= 0 for dim in block_shape):
        return {}

    crops_by_dim = (
        (int(op.options.crops.top), int(op.options.crops.bottom)),
        (int(op.options.crops.left), int(op.options.crops.right)),
    )

    output_shape = list(input_shape)
    output_batch = int(input_shape[0])
    for idx in range(spatial_dims):
        block = block_shape[idx]
        if output_batch % block != 0:
            return {}
        output_batch //= block
        crop_before, crop_after = crops_by_dim[idx]
        out_dim = int(input_shape[idx + 1]) * block - crop_before - crop_after
        if out_dim <= 0:
            return {}
        output_shape[idx + 1] = out_dim
    output_shape[0] = output_batch
    return {op.output_ids[0]: tuple(output_shape)}

def _infer_concatenation(op: AirOperator, model: AirModel) -> dict[str, tuple[int, ...]]:
    """Infer CONCATENATION output batch for axis-0 concatenation."""
    if not isinstance(op.options, AirConcatenationOptions) or len(op.output_ids) != 1 or not op.input_ids:
        return {}
    if int(op.options.axis) != 0:
        return {}

    output_tensor = model.get_tensor(op.output_ids[0])
    if output_tensor.shape_signature is None or len(output_tensor.shape_signature) < 1:
        return {}
    if int(output_tensor.shape_signature[0]) != -1:
        return {}

    output_shape = tuple(int(dim) for dim in output_tensor.shape)
    if len(output_shape) < 1:
        return {}

    batch_sum = 0
    for tensor_id in op.input_ids:
        input_shape = tuple(int(dim) for dim in model.get_tensor(tensor_id).shape)
        if len(input_shape) < 1:
            return {}
        input_batch = int(input_shape[0])
        if input_batch < 0:
            return {}
        batch_sum += input_batch

    new_shape = list(output_shape)
    new_shape[0] = batch_sum
    return {op.output_ids[0]: tuple(new_shape)}

def _infer_batch_fallback(op: AirOperator, model: AirModel) -> dict[str, tuple[int, ...]]:
    """Propagate batch dim for non-rule ops whose output batch is dynamic. 
    This fallback assumes the operator preserves the batch dimension. Operators
    that modify the batch dimension require
    custom shape inference rules."""
    if not op.input_ids or not op.output_ids:
        return {}

    source_shape = tuple(int(dim) for dim in model.get_tensor(op.input_ids[0]).shape)
    if len(source_shape) < 1:
        return {}

    inferred: dict[str, tuple[int, ...]] = {}
    for tensor_id in op.output_ids:
        output_tensor = model.get_tensor(tensor_id)
        if output_tensor.shape_signature is None or len(output_tensor.shape_signature) < 1:
            continue
        if int(output_tensor.shape_signature[0]) != -1:
            continue

        output_shape = tuple(int(dim) for dim in output_tensor.shape)
        if len(output_shape) < 1:
            continue
        new_shape = list(output_shape)
        new_shape[0] = source_shape[0]
        inferred[tensor_id] = tuple(new_shape)
    return inferred


SHAPE_RULES: dict[str, ShapeRule] = {
    canonical_op_key(AirOpType.SPACE_TO_BATCH_ND): _infer_space_to_batch,
    canonical_op_key(AirOpType.CONCATENATION): _infer_concatenation,
    canonical_op_key(AirOpType.BATCH_TO_SPACE_ND): _infer_batch_to_space,
    # Depthwise and most ops use generic fallback for batch-only propagation.
}


def _apply_updates(
    *,
    op: AirOperator,
    op_key: str,
    update_kind: str,
    inferred_shapes: dict[str, tuple[int, ...]],
    model: AirModel,
    consumers_by_tensor: dict[str, list[int]],
    queue: deque[int],
    in_queue: set[int],
    result: ShapeInferenceResult,
) -> bool:
    any_update = False
    for tensor_id, new_shape in inferred_shapes.items():
        tensor = model.get_tensor(tensor_id)
        old_shape = tuple(int(dim) for dim in tensor.shape)
        if old_shape == new_shape:
            continue
        tensor.shape = new_shape
        result.changed_tensor_ids.add(tensor_id)
        result.diagnostics.append(
            f"{update_kind} update: {op_key}({op.id}) updated tensor {tensor_id} shape {old_shape} -> {new_shape}"
        )
        any_update = True
        for consumer_idx in consumers_by_tensor.get(tensor_id, []):
            if consumer_idx not in in_queue:
                queue.append(consumer_idx)
                in_queue.add(consumer_idx)
    return any_update


def propagate_shapes(model: AirModel, *, strict: bool = False) -> ShapeInferenceResult:
    """Infer and propagate tensor shapes over the graph until fixed-point.

    Args:
        model: AIR model to update in place.
        strict: If True, raise when unresolved dynamic tensors remain.

    Returns:
        Shape inference result with updated tensors and diagnostics.

    Raises:
        ValueError: If ``strict`` is True and unresolved dynamic tensors remain.
    """
    result = ShapeInferenceResult()
    if not model.operators:
        return result

    consumers_by_tensor: dict[str, list[int]] = {}
    for idx, op in enumerate(model.operators):
        for tensor_id in op.input_ids:
            consumers_by_tensor.setdefault(tensor_id, []).append(idx)

    queue = deque(range(len(model.operators)))
    in_queue = set(queue)
    while queue:
        op_idx = queue.popleft()
        in_queue.discard(op_idx)
        op = model.operators[op_idx]
        op_key = canonical_op_key(op.op_type)
        rule = SHAPE_RULES.get(op_key)
        if rule is not None:
            inferred_shapes = rule(op, model)
            if inferred_shapes:
                _apply_updates(
                    op=op,
                    op_key=op_key,
                    update_kind="rule",
                    inferred_shapes=inferred_shapes,
                    model=model,
                    consumers_by_tensor=consumers_by_tensor,
                    queue=queue,
                    in_queue=in_queue,
                    result=result,
                )
                continue
            else:
                if logger.isEnabledFor(logging.DEBUG):
                    result.diagnostics.append(f"rule skipped: {op_key}({op.id})")

        fallback_shapes = _infer_batch_fallback(op, model)
        if not fallback_shapes:
            if logger.isEnabledFor(logging.DEBUG):
                result.diagnostics.append(f"fallback skipped: {op_key}({op.id})")
            continue
        _apply_updates(
            op=op,
            op_key=op_key,
            update_kind="fallback",
            inferred_shapes=fallback_shapes,
            model=model,
            consumers_by_tensor=consumers_by_tensor,
            queue=queue,
            in_queue=in_queue,
            result=result,
        )

    for tensor_id, tensor in model.tensors.items():
        signature = tuple(int(dim) for dim in tensor.shape_signature) if tensor.shape_signature is not None else None
        if signature is None or all(dim >= 0 for dim in signature):
            continue
        if tensor_id in result.changed_tensor_ids:
            continue
        result.unresolved_tensor_ids.add(tensor_id)
        result.diagnostics.append(
            f"unresolved: tensor {tensor_id} (shape_signature={signature}) remains unresolved with shape={tensor.shape}"
        )

    if strict and result.unresolved_tensor_ids:
        unresolved = ", ".join(sorted(result.unresolved_tensor_ids))
        raise ValueError(f"Unresolved dynamic tensor shapes after propagation: {unresolved}")

    if result.changed_tensor_ids:
        logger.info("[shape] propagated shapes for %d tensor(s): %s", len(result.changed_tensor_ids), sorted(result.changed_tensor_ids))
    if result.unresolved_tensor_ids:
        logger.warning(
            "[shape] unresolved dynamic tensors remain (%d): %s. Conversion continues with placeholder dims.",
            len(result.unresolved_tensor_ids),
            sorted(result.unresolved_tensor_ids),
        )
    for msg in result.diagnostics:
        logger.debug("[shape] %s", msg)

    return result
