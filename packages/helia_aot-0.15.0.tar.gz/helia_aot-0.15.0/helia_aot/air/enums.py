import numpy as np
import numpy.typing as npt
from pydantic.dataclasses import dataclass


from enum import IntEnum, auto
from helia_aot.defines import AnyCaseStrEnum, UpperCaseStrEnum


class AirTensorDim(IntEnum):
    """AIR tensor dimensions.

    Attributes:
        N (int): Batch dimension.
        H (int): Height dimension.
        W (int): Width dimension.
        C (int): Channel dimension.
    """

    N = 0
    H = 1
    W = 2
    C = 3

    def __str__(self):
        return self.name

@dataclass
class AirSpatialPad:
    """AIR spatial padding specification.

    Attributes:
        top (int): Padding on the top.
        bottom (int): Padding on the bottom.
        left (int): Padding on the left.
        right (int): Padding on the right.
    """
    top: int = 0
    bottom: int = 0
    left: int = 0
    right: int = 0


class AirPaddingType(IntEnum):
    """AIR padding types for AIR operators.

    Attributes:
        SAME (int): Same padding.
        VALID (int): Valid padding.
    """

    SAME = 0
    VALID = 1

    def __str__(self):
        return self.name


class AirTensorType(IntEnum):
    """AIR tensor data types."""

    FLOAT32 = 0
    FLOAT16 = 1
    INT32 = 2
    UINT8 = 3
    INT64 = 4
    STRING = 5
    BOOL = 6
    INT16 = 7
    COMPLEX64 = 8
    INT8 = 9
    FLOAT64 = 10
    COMPLEX128 = 11
    UINT64 = 12
    RESOURCE = 13
    VARIANT = 14
    UINT32 = 15
    UINT16 = 16
    INT4 = 17
    BFLOAT16 = 18

    def __str__(self):
        return self.name


class AirActivationType(AnyCaseStrEnum):
    """AIR activation function types.

    Attributes:
        NONE (str): No activation.
        RELU (str): ReLU activation.
        RELU_N1_TO_1 (str): ReLU activation with range [-1, 1].
        RELU_0_TO_1 (str): ReLU activation with range [0, 1].
        RELU6 (str): ReLU activation with range [0, 6].
        TANH (str): Tanh activation.
        SIGN_BIT (str): Sign bit activation.
        PRELU (str): Parametric ReLU activation.
    """

    NONE = auto()
    RELU = auto()
    RELU_N1_TO_1 = auto()
    RELU_0_TO_1 = auto()
    RELU6 = auto()
    TANH = auto()
    SIGN_BIT = auto()
    PRELU = auto()

    @staticmethod
    def _qrange_from_dtype(dtype: npt.DTypeLike) -> tuple[int, int]:
        dt = np.dtype(dtype)
        if dt.kind in ("i", "u"):  # integer dtypes only
            info = np.iinfo(dt)
            return int(info.min), int(info.max)
        raise TypeError(f"dtype {dt} is not an integer dtype")

    @staticmethod
    def _qrange_from_bits(num_bits: int, signed: bool) -> tuple[int, int]:
        if num_bits <= 0:
            raise ValueError("num_bits must be positive")
        if signed:
            return (-(1 << (num_bits - 1)), (1 << (num_bits - 1)) - 1)
        else:
            return (0, (1 << num_bits) - 1)

    def compute_range(
        self,
        output_zero_point: int,
        output_scale: float,
        *,
        dtype: npt.DTypeLike | None = None,
        qmin: int | None = None,
        qmax: int | None = None,
        num_bits: int | None = None,
        signed: bool | None = None,
    ) -> tuple[int, int]:
        """
        Compute quantized activation clamp range.

        Precedence for the quantized range:
          1) dtype (e.g., np.int8 / np.uint8 / np.int16)
          2) (num_bits, signed) (e.g., 4-bit signed)
          3) qmin/qmax (explicit)
          4) default to int8: [-128, 127]
        """
        if dtype is not None:
            qmin, qmax = self._qrange_from_dtype(dtype)
        elif qmin is None or qmax is None:
            if num_bits is not None and signed is not None:
                qmin, qmax = self._qrange_from_bits(num_bits, signed)
            else:
                qmin, qmax = -128, 127  # sensible default: int8

        if output_scale <= 0:
            raise ValueError("output_scale must be > 0")

        z = int(output_zero_point)
        qmin = int(qmin)  # type: ignore[arg-type]
        qmax = int(qmax)  # type: ignore[arg-type]

        # Ensure zero-point is in range (some toolchains rely on this)
        z = min(max(z, qmin), qmax)

        if self == AirActivationType.RELU:
            amin = max(z, qmin)
            amax = qmax
        elif self == AirActivationType.RELU6:
            q6 = int(round(6.0 / output_scale)) + z
            amin = max(z, qmin)
            amax = min(q6, qmax)
        elif self == AirActivationType.RELU_N1_TO_1:
            qn1 = int(round(-1.0 / output_scale)) + z
            qp1 = int(round(1.0 / output_scale)) + z
            amin = max(qn1, qmin)
            amax = min(qp1, qmax)
        elif self == AirActivationType.RELU_0_TO_1:
            q1 = int(round(1.0 / output_scale)) + z
            amin = max(z, qmin)
            amax = min(q1, qmax)
        else:
            amin, amax = qmin, qmax

        return int(amin), int(amax)


class AirTensorKind(AnyCaseStrEnum):
    """AIR tensor kinds.

    Attributes:
        CONSTANT (str): Constant tensors (read-only).
        PERSISTENT (str): Persistent including resource variables (read-write).
        SCRATCH (str): Scratch tensors for ops (read-write).
    """

    CONSTANT = auto()  # Constant tensors (read-only)
    PERSISTENT = auto()  # Persistent including resource variables (read-write)
    SCRATCH = auto()  # Scratch tensors for ops (read-write)


class AirReluType(AnyCaseStrEnum):
    """AIR RELU types.

    Attributes:
        RELU (str): ReLU activation.
        RELU6 (str): ReLU6 activation.
        RELU_N1_TO_1 (str): ReLU activation with range [-1, 1].
        RELU_0_TO_1 (str): ReLU activation with range [0, 1].
    """

    RELU = auto()
    RELU6 = auto()
    RELU_N1_TO_1 = auto()
    RELU_0_TO_1 = auto()

    @staticmethod
    def _qrange_from_dtype(dtype: npt.DTypeLike) -> tuple[int, int]:
        dt = np.dtype(dtype)
        if dt.kind in ("i", "u"):  # integer dtypes only
            info = np.iinfo(dt)
            return int(info.min), int(info.max)
        raise TypeError(f"dtype {dt} is not an integer dtype")

    @staticmethod
    def _qrange_from_bits(num_bits: int, signed: bool) -> tuple[int, int]:
        if num_bits <= 0:
            raise ValueError("num_bits must be positive")
        if signed:
            return (-(1 << (num_bits - 1)), (1 << (num_bits - 1)) - 1)
        else:
            return (0, (1 << num_bits) - 1)

    def compute_range(
        self,
        output_zero_point: int,
        output_scale: float,
        *,
        dtype: npt.DTypeLike | None = None,
        qmin: int | None = None,
        qmax: int | None = None,
        num_bits: int | None = None,
        signed: bool | None = None,
    ) -> tuple[int, int]:
        """
        Compute quantized activation clamp range.

        Precedence for the quantized range:
          1) dtype (e.g., np.int8 / np.uint8 / np.int16)
          2) (num_bits, signed) (e.g., 4-bit signed)
          3) qmin/qmax (explicit)
          4) default to int8: [-128, 127]
        """
        if dtype is not None:
            qmin, qmax = self._qrange_from_dtype(dtype)
        elif qmin is None or qmax is None:
            if num_bits is not None and signed is not None:
                qmin, qmax = self._qrange_from_bits(num_bits, signed)
            else:
                qmin, qmax = -128, 127  # sensible default: int8

        if output_scale <= 0:
            raise ValueError("output_scale must be > 0")

        z = int(output_zero_point)
        qmin = int(qmin)  # type: ignore[arg-type]
        qmax = int(qmax)  # type: ignore[arg-type]

        # Ensure zero-point is in range (some toolchains rely on this)
        z = min(max(z, qmin), qmax)

        if self == AirReluType.RELU:
            amin = max(z, qmin)
            amax = qmax
        elif self == AirReluType.RELU6:
            q6 = int(round(6.0 / output_scale)) + z
            amin = max(z, qmin)
            amax = min(q6, qmax)
        elif self == AirReluType.RELU_N1_TO_1:
            qn1 = int(round(-1.0 / output_scale)) + z
            qp1 = int(round(1.0 / output_scale)) + z
            amin = max(qn1, qmin)
            amax = min(qp1, qmax)
        elif self == AirReluType.RELU_0_TO_1:
            q1 = int(round(1.0 / output_scale)) + z
            amin = max(z, qmin)
            amax = min(q1, qmax)
        else:
            amin, amax = qmin, qmax

        return int(amin), int(amax)


class AirComparisonType(AnyCaseStrEnum):
    """AIR comparison operation types."""

    EQUAL = auto()
    NOT_EQUAL = auto()
    LESS = auto()
    LESS_EQUAL = auto()
    GREATER = auto()
    GREATER_EQUAL = auto()


class AirFullyConnectedWeightsFormat(IntEnum):
    """AIR fully-connected weights format.

    Attributes:
        DEFAULT (int): Default weights format.
        SHUFFLED4x16INT8 (int): Shuffled 4x16 INT8 weights format.
    """

    DEFAULT = 0
    SHUFFLED4x16INT8 = 1


class AirOpType(UpperCaseStrEnum):
    """AIR supported operator types."""

    # Convolution operators
    CONV_2D = auto()
    DEPTHWISE_CONV_2D = auto()
    TRANSPOSE_CONV = auto()

    # SVDF operator
    SVDF = auto()

    # Pooling
    AVERAGE_POOL_2D = auto()
    MAX_POOL_2D = auto()

    # Fully-connected and matmul
    FULLY_CONNECTED = auto()
    BATCH_MATMUL = auto()

    # Element-wise
    ADD = auto()
    SUB = auto()
    SQUARED_DIFFERENCE = auto()
    MUL = auto()
    DIV = auto()
    MAXIMUM = auto()
    MINIMUM = auto()
    COMPARISON = auto()
    ABS = auto()
    SQRT = auto()
    RSQRT = auto()
    
    # Activations
    RELU = auto()
    TANH = auto()
    LOGISTIC = auto()
    HARD_SWISH = auto()
    LEAKY_RELU = auto()
    SOFTMAX = auto()
    PRELU = auto()

    # Tensor transforms
    RESHAPE = auto()
    TRANSPOSE = auto()
    REVERSE_V2 = auto()
    CONCATENATION = auto()
    PACK = auto()
    PAD = auto()
    SQUEEZE = auto()
    EXPAND_DIMS = auto()
    SHAPE = auto()
    STRIDED_SLICE = auto()
    SLICE = auto()
    GATHER = auto()
    GATHER_ND = auto()
    SPLIT = auto()
    UNPACK = auto()
    DEPTH_TO_SPACE = auto()
    SPACE_TO_DEPTH = auto()
    BATCH_TO_SPACE_ND = auto()
    SPACE_TO_BATCH_ND = auto()
    RESIZE_NEAREST_NEIGHBOR = auto()

    # Quantization & dequantization
    QUANTIZE = auto()
    DEQUANTIZE = auto()

    # Variables
    READ_VARIABLE = auto()
    ASSIGN_VARIABLE = auto()

    # Reduction
    MEAN = auto()
    SUM = auto()
    REDUCE_MAX = auto()
    REDUCE_MIN = auto()
    ARG_MAX = auto()
    ARG_MIN = auto()

    # Utility ops
    FILL = auto()
    ZEROS_LIKE = auto()

    # NPU ops
    ETHOS_U = auto()

    # Base class (should not be used directly)
    OPERATOR = auto()
