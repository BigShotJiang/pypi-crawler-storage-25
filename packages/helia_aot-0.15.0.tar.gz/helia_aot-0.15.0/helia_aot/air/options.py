from typing import Any
from pydantic.dataclasses import dataclass
from pydantic import Field
from helia_aot.registry import Registry
from .op_keys import canonical_op_key
from .enums import (
    AirOpType,
    AirActivationType,
    AirReluType,
    AirTensorType,
    AirFullyConnectedWeightsFormat,
    AirSpatialPad,
    AirComparisonType,
)


@dataclass
class AirOperatorOptions:
    """Marker base for operator-specific configurations."""

    # No fields; serves as a common ancestor for all options
    pass


def register_op_options(op_type: AirOpType | str, **dataclass_kwargs: Any):
    """
    Decorator that:
      1) Ensures the decorated class inherits from AirOperatorOptions,
      2) Converts it into a @dataclass(**dataclass_kwargs),
      3) Annotates it with a canonical registry key,
      4) Returns the resulting dataclass.

    Usage:
      @register_op_options("Conv2D")
      class AirConv2DOptions:
          ... fields ...
    """

    def decorator(cls: type) -> type[AirOperatorOptions]:
        # 1) Ensure subclassing of AirOperatorOptions
        if not issubclass(cls, AirOperatorOptions):
            cls = type(cls.__name__, (AirOperatorOptions, cls), dict(cls.__dict__))
        # 2) Apply @dataclass to the resulting class
        decorated = dataclass(**dataclass_kwargs)(cls)  # type: ignore
        # 3) Annotate with canonical op key for explicit registration later
        setattr(decorated, "__helia_op_key__", canonical_op_key(op_type))
        return decorated  # type: ignore

    return decorator


def register_default_air_options(registry: Registry[AirOpType | str, type[AirOperatorOptions]]) -> None:
    """Register all built-in AIR option classes into the provided registry."""
    for name, option_cls in _iter_registered_option_classes():
        registry.register(name, option_cls, overwrite=True)


def _iter_registered_option_classes() -> list[tuple[str, type[AirOperatorOptions]]]:
    """Discover built-in option classes decorated with register_op_options."""
    specs: list[tuple[str, type[AirOperatorOptions]]] = []
    seen: set[tuple[str, type[AirOperatorOptions]]] = set()
    for value in globals().values():
        if not isinstance(value, type):
            continue
        if not issubclass(value, AirOperatorOptions):
            continue
        op_key = getattr(value, "__helia_op_key__", None)
        if not isinstance(op_key, str):
            continue
        spec = (op_key, value)
        if spec in seen:
            continue
        seen.add(spec)
        specs.append(spec)
    return specs


def get_options_class(
    registry: Registry[AirOpType | str, type[AirOperatorOptions]],
    op_type: AirOpType | str,
) -> type[AirOperatorOptions]:
    """Retrieve the registered options dataclass for a given op_type.

    If not found, falls back to the base AirOperatorOptions.

    Args:
        op_type (AirOpType): The operator type to look up.

    Returns:
        type[AirOperatorOptions]: The options class for the operator type.
    """
    if registry.has(op_type):
        return registry.get(op_type)
    return AirOperatorOptions


@register_op_options(AirOpType.ADD)
class AirAddOptions:
    """Options for the ADD operator.

    Attributes:
        activation (AirActivationType): fused activation function (default NONE).

    """

    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")


@register_op_options(AirOpType.SUB)
class AirSubOptions:
    """Options for the SUB operator.

    Attributes:
        activation (AirActivationType): fused activation function (default NONE).
    """

    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")


@register_op_options(AirOpType.SQUARED_DIFFERENCE)
class AirSquaredDifferenceOptions:
    """Options for the SQUARED_DIFFERENCE operator."""

    pass


@register_op_options(AirOpType.ASSIGN_VARIABLE)
class AirAssignVariableOptions:
    """Options for the ASSIGN_VARIABLE operator."""

    pass


@register_op_options(AirOpType.AVERAGE_POOL_2D)
class AirAveragePool2DOptions:
    """Options for the AVERAGE_POOL_2D operator.

    Attributes:
        padding_height (int): number of rows to pad at top & bottom (default 0).
        padding_width (int): number of columns to pad at left & right (default 0).
        stride_height (int): vertical step between pooling windows (default 1).
        stride_width (int): horizontal step between pooling windows (default 1).
        filter_height (int): height of the pooling window (default 1).
        filter_width (int): width of the pooling window (default 1).
        activation (AirActivationType): fused activation function (default NONE).
    """

    padding_height: int = Field(0, description="Padding for top & bottom")
    padding_width: int = Field(0, description="Padding for left & right")
    stride_height: int = Field(1, description="Vertical stride")
    stride_width: int = Field(1, description="Horizontal stride")
    filter_height: int = Field(0, description="Height of the pooling window")
    filter_width: int = Field(0, description="Width of the pooling window")
    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")


@register_op_options(AirOpType.BATCH_MATMUL)
class AirBatchMatMulOptions:
    """Options for the BATCH_MATMUL operator.

    Attributes:
        adj_x (bool): If True, transpose the first (left) input matrix before multiplication (default False).
        adj_y (bool): If True, transpose the second (right) input matrix before multiplication (default False).
        asymmetric_quantize_inputs (bool): If True, use asymmetric quantization for inputs (default False).
    """

    adj_x: bool = Field(False, description="If True, transpose the first (left) input matrix before multiplication")
    adj_y: bool = Field(False, description="If True, transpose the second (right) input matrix before multiplication")
    asymmetric_quantize_inputs: bool = Field(False, description="If True, use asymmetric quantization for inputs")


@register_op_options(AirOpType.BATCH_TO_SPACE_ND)
class AirBatchToSpaceNDOptions:
    """Options for the BATCH_TO_SPACE_ND operator.

    Attributes:
        block_shape (tuple[int, int]): The size of the spatial block (default (1, 1)).
        crops (tuple[int, int, int, int]): Crops for the spatial dimensions (default (0, 0, 0, 0)).
    """
    block_shape: tuple[int, int] = Field((1, 1), description="The size of the spatial block")
    crops: AirSpatialPad = Field(default_factory=AirSpatialPad, description="Crops for the spatial dimensions")


@register_op_options(AirOpType.CONCATENATION)
class AirConcatenationOptions:
    """Options for the CONCATENATION operator.

    Attributes:
        axis (int): Axis along which to concatenate the input tensors (default 0).
        activation (AirActivationType): Activation function to apply after concatenation (default NONE).
    """

    axis: int = Field(0, description="Axis along which to concatenate the input tensors")
    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")


@register_op_options(AirOpType.CONV_2D)
class AirConv2DOptions:
    """Options for CONV_2D.

    Attributes:
        padding_height (int): padding for top & bottom (default 0).
        padding_width (int): padding for left & right (default 0).
        stride_height (int): vertical stride (default 1).
        stride_width (int): horizontal stride (default 1).
        dilation_height (int): vertical dilation (default 1).
        dilation_width (int): horizontal dilation (default 1).
        activation (AirActivationType): fused activation function (default NONE).
        bias_tensor_type (AirTensorType): bias tensor type.
        upscale_height (int): implicit height upscaling factor applied before convolution.
        upscale_width (int): implicit width upscaling factor applied before convolution.
    """

    padding_height: int = Field(0, description="Padding for top & bottom")
    padding_width: int = Field(0, description="Padding for left & right")
    stride_height: int = Field(1, description="Vertical stride")
    stride_width: int = Field(1, description="Horizontal stride")
    dilation_height: int = Field(1, description="Vertical dilation")
    dilation_width: int = Field(1, description="Horizontal dilation")
    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")
    bias_tensor_type: AirTensorType = Field(AirTensorType.FLOAT32, description="Bias tensor type")
    upscale_height: int = Field(1, description="Implicit height upscaling factor applied before convolution")
    upscale_width: int = Field(1, description="Implicit width upscaling factor applied before convolution")


@register_op_options(AirOpType.DEPTH_TO_SPACE)
class AirDepthToSpaceOptions:
    """Options for the DEPTH_TO_SPACE operator.

    Attributes:
        block_size (int): The size of the spatial block (default 0).
    """

    block_size: int = Field(0, description="The size of the spatial block")


@register_op_options(AirOpType.DEPTHWISE_CONV_2D)
class AirDepthwiseConv2DOptions:
    """Options for the DEPTHWISE_CONV_2D operator.

    Attributes:
        depth_multiplier (int): number of output channels per input channel (default 1).
        padding_height (int): padding for top & bottom (default 0).
        padding_width (int): padding for left & right (default 0).
        stride_height (int): vertical stride (default 1).
        stride_width (int): horizontal stride (default 1).
        dilation_height (int): vertical dilation factor (default 1).
        dilation_width (int): horizontal dilation factor (default 1).
        activation (AirActivationType): fused activation function (default NONE).
    """

    depth_multiplier: int = Field(1, description="Number of output channels per input channel")
    padding_height: int = Field(0, description="Padding for top & bottom")
    padding_width: int = Field(0, description="Padding for left & right")
    stride_height: int = Field(1, description="Vertical stride")
    stride_width: int = Field(1, description="Horizontal stride")
    dilation_height: int = Field(1, description="Vertical dilation")
    dilation_width: int = Field(1, description="Horizontal dilation")
    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")


@register_op_options(AirOpType.DEQUANTIZE)
class AirDequantizeOptions:
    """Options for the DEQUANTIZE operator."""

    pass


@register_op_options(AirOpType.EXPAND_DIMS)
class AirExpandDimsOptions:
    """Options for the EXPAND_DIMS operator."""

    pass


@register_op_options(AirOpType.FILL)
class AirFillOptions:
    """Options for the FILL operator."""
    pass

@register_op_options(AirOpType.FULLY_CONNECTED)
class AirFullyConnectedOptions:
    """Options for the FULLY_CONNECTED operator.

    Attributes:
        activation (AirActivationType):
            Fused activation function (default NONE).

        weights_format (FullyConnectedWeightsFormat):
            Memory layout of the weights matrix
            (default DEFAULT, i.e. row-major).

        keep_num_dims (bool):
            If True, preserve the input's rank in the output.
            Otherwise, collapse to 2D (default False).

        asymmetric_quantize_inputs (bool):
            If True, use asymmetric quantization for inputs
            (default False).

        bias_tensor_type (AirTensorType):
            Data type of the bias tensor.
            FLOAT32 for hybrid/dynamic-range quant,
            INT32 for full-integer quant (default FLOAT32).
    """

    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")
    weights_format: AirFullyConnectedWeightsFormat = Field(
        AirFullyConnectedWeightsFormat.DEFAULT, description="Memory layout of the weights matrix"
    )
    keep_num_dims: bool = Field(False, description="If True, preserve the input's rank in the output")
    asymmetric_quantize_inputs: bool = Field(False, description="If True, use asymmetric quantization for inputs")
    bias_tensor_type: AirTensorType = Field(AirTensorType.FLOAT32, description="Bias tensor type")


@register_op_options(AirOpType.HARD_SWISH)
class AirHardSwishOptions:
    """Options for the HARD_SWISH operator."""

    pass


@register_op_options(AirOpType.LEAKY_RELU)
class AirLeakyReluOptions:
    """Options for the LEAKY_RELU operator.

    Attributes:
        alpha (float): The slope for negative values (default 0.2).
    """

    alpha: float = Field(0.2, description="The slope for negative values")


@register_op_options(AirOpType.LOGISTIC)
class AirLogisticOptions:
    """Options for the LOGISTIC operator."""

    pass


@register_op_options("MAX_POOL_2D")
class AirMaxPool2DOptions:
    """Options for the MAX_POOL_2D operator.

    Attributes:
        padding_height (int): number of rows to pad at top & bottom (default 0).
        padding_width (int): number of columns to pad at left & right (default 0).
        stride_height (int): vertical step between pooling windows (default 1).
        stride_width (int): horizontal step between pooling windows (default 1).
        filter_height (int): height of the pooling window (default 1).
        filter_width (int): width of the pooling window (default 1).
        activation (AirActivationType): fused activation function (default NONE).
    """

    padding_height: int = Field(0, description="Padding for top & bottom")
    padding_width: int = Field(0, description="Padding for left & right")
    stride_height: int = Field(1, description="Vertical stride")
    stride_width: int = Field(1, description="Horizontal stride")
    filter_height: int = Field(0, description="Height of the pooling window")
    filter_width: int = Field(0, description="Width of the pooling window")
    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")


@register_op_options(AirOpType.MAXIMUM)
class AirMaximumOptions:
    """Options for the Maximum operator."""

    pass


@register_op_options(AirOpType.MEAN)
class AirMeanOptions:
    """Options for the MEAN operator.

    Attributes:
        axis (list[int]): List of axes to compute the mean over (default None).
    """

    axis: list[int] = Field(None, description="List of axes to compute the mean over")


@register_op_options(AirOpType.SUM)
class AirSumOptions:
    """Options for the SUM operator."""

    pass


@register_op_options(AirOpType.MINIMUM)
class AirMinimumOptions:
    """Options for the Minimum operator."""

    pass


@register_op_options(AirOpType.COMPARISON)
class AirComparisonOptions:
    """Options shared by comparison operators."""

    operation: AirComparisonType = Field(
        AirComparisonType.EQUAL,
        description="Element-wise comparison operation type",
    )


@register_op_options(AirOpType.MUL)
class AirMulOptions:
    """Options for the MUL operator.

    Attributes:
        activation (AirActivationType): Fused activation function to apply after multiplication (default NONE).
    """

    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")


@register_op_options(AirOpType.PACK)
class AirPackOptions:
    """Options for the PACK operator.

    Attributes:
        values_count (int): Number of input tensors to pack (default 0).
        axis (int): Axis along which to pack the input tensors (default 0).
    """

    values_count: int = Field(0, description="Number of input tensors to pack")
    axis: int = Field(0, description="Axis along which to pack the input tensors")


@register_op_options(AirOpType.PAD)
class AirPadOptions:
    """Options for the PAD operator.

    Attributes:
        constant_value (int): Value to use for padding (default 0).
        pre_paddings (list[int]): List of padding sizes before each dimension (default None).
        post_paddings (list[int]): List of padding sizes after each dimension (default None).
    """

    constant_value: int = Field(0, description="Value to use for padding")
    pre_paddings: list[int] = Field(None, description="List of padding sizes before each dimension")
    post_paddings: list[int] = Field(None, description="List of padding sizes after each dimension")


@register_op_options(AirOpType.QUANTIZE)
class AirQuantizeOptions:
    """Options for the QUANTIZE operator."""

    pass


@register_op_options(AirOpType.READ_VARIABLE)
class AirReadVariableOptions:
    """Options for the READ_VARIABLE operator.

    Attributes:
        init_value (int): Initial value for the variable (default 0).
    """

    init_value: int = Field(0, description="Initial value for the variable")

@register_op_options(AirOpType.REDUCE_MAX)
class AirReduceMaxOptions:
    """Options for the REDUCE_MAX operator.

    Attributes:
        axis (list[int]): List of axes to compute the maximum over (default None).
    """

    axis: list[int] = Field(None, description="List of axes to compute the maximum over")

@register_op_options(AirOpType.REDUCE_MIN)
class AirReduceMinOptions:
    """Options for the REDUCE_MIN operator.

    Attributes:
        axis (list[int]): List of axes to compute the minimum over (default None).
    """

    axis: list[int] = Field(None, description="List of axes to compute the minimum over")


@register_op_options(AirOpType.ARG_MAX)
class AirArgMaxOptions:
    """Options for the ARG_MAX operator."""

    axis: int = Field(0, description="Axis along which to compute the argmax")


@register_op_options(AirOpType.ARG_MIN)
class AirArgMinOptions:
    """Options for the ARG_MIN operator."""

    axis: int = Field(0, description="Axis along which to compute the argmin")


@register_op_options(AirOpType.RELU)
class AirReluOptions:
    """Options for the RELU operator.

    Attributes:
        relu_type (AirReluType): Type of ReLU activation to use (default RELU).
    """

    relu_type: AirReluType = Field(AirReluType.RELU, description="Type of ReLU activation")


@register_op_options(AirOpType.RESHAPE)
class AirReshapeOptions:
    """Options for the RESHAPE operator.

    Attributes:
        new_shape (list[int]|None): The new shape to reshape the input tensor to.
    """

    new_shape: list[int] | None = Field(None, description="The new shape to reshape the input tensor to.")


@register_op_options(AirOpType.SHAPE)
class AirShapeOptions:
    """Options for the SHAPE operator.

    Attributes:
        out_type (int): The data type of the output tensor (default 0).
    """

    out_type: int = Field(0, description="The data type of the output tensor")


@register_op_options(AirOpType.SOFTMAX)
class AirSoftmaxOptions:
    """Options for the SOFTMAX operator.

    Attributes:
        beta (float): The beta parameter for softmax scaling (default 1.0).
    """

    beta: float = Field(1.0, description="The beta parameter for softmax scaling")


@register_op_options(AirOpType.SPACE_TO_BATCH_ND)
class AirSpaceToBatchNDOptions:
    """Options for the SPACE_TO_BATCH_ND operator.

    Attributes:
        block_shape (tuple[int, int]): The size of the spatial block (default (1, 1)).
        paddings (tuple[int, int, int, int]): Paddings for the spatial dimensions (default (0, 0, 0, 0)).
    """
    block_shape: tuple[int, int] = Field((1, 1), description="The size of the spatial block")
    paddings: AirSpatialPad = Field(default_factory=AirSpatialPad, description="Paddings for the spatial dimensions")


@register_op_options(AirOpType.SPACE_TO_DEPTH)
class AirSpaceToDepthOptions:
    """Options for the SPACE_TO_DEPTH operator.

    Attributes:
        block_size (int): The size of the spatial block (default 0).
    """

    block_size: int = Field(0, description="The size of the spatial block")


@register_op_options(AirOpType.SPLIT)
class AirSplitOptions:
    """Options for the SPLIT operator.

    Attributes:
        axis (int): Axis along which to split the input tensor (default 0).
        split_lengths (list[int]): List of lengths for each split (default empty list).

    """

    axis: int = Field(0, description="Axis along which to split the input tensor")
    split_lengths: list[int] = Field(default_factory=list, description="List of lengths for each split")

    @property
    def num_splits(self) -> int:
        return len(self.split_lengths)


@register_op_options(AirOpType.SQUEEZE)
class AirSqueezeOptions:
    """Options for the SQUEEZE operator.

    Attributes:
        squeeze_dims (list[int]|None): List of dimensions to squeeze from the input tensor.
    """

    squeeze_dims: list[int] | None = Field(None, description="List of dimensions to squeeze from the input tensor")


@dataclass
class AirStrideSlice:
    begin: int = Field(0, description="Begin index for the slice")
    end: int = Field(0, description="End index for the slice")
    stride: int = Field(1, description="Stride value for the slice")


@register_op_options(AirOpType.SLICE)
class AirSliceOptions:
    """Options for the SLICE operator."""

    begin: tuple[int, ...] = Field(..., description="Begin indices for each dimension")
    size: tuple[int, ...] = Field(..., description="Sizes for each dimension (-1 means the rest)")

    def get_slices(self, input_shape: tuple[int, ...], pad_to: int = 4) -> list[AirStrideSlice]:
        """Compute (begin, end, stride) tuples for each axis."""

        def _pad_to_n(tup: tuple[int, ...], n: int, pad_val: int) -> tuple[int, ...]:
            length = len(tup)
            if length > n:
                raise ValueError(f"Tuple length {length} exceeds expected {n}")
            if length < n:
                return (pad_val,) * (n - length) + tup
            return tup

        input_shape = _pad_to_n(input_shape, pad_to, pad_val=1)
        begin_dims = _pad_to_n(self.begin, pad_to, pad_val=0)
        size_dims = _pad_to_n(self.size, pad_to, pad_val=-1)

        slices: list[AirStrideSlice] = []

        for axis, dim in enumerate(input_shape):
            b = begin_dims[axis]
            sz = size_dims[axis]

            if b < 0:
                b += dim
            b = max(0, min(b, dim if dim > 0 else 0))

            if sz == -1:
                e = dim
            else:
                e = b + sz
            e = max(0, min(e, dim))

            slices.append(AirStrideSlice(begin=b, end=e, stride=1))

        return slices


@register_op_options(AirOpType.GATHER)
class AirGatherOptions:
    """Options for the GATHER operator."""

    axis: int = Field(0, description="Axis to gather along (supports negative indexing)")
    batch_dims: int = Field(0, description="Number of leading batch dimensions")
    input_shape: tuple[int, ...] = Field(..., description="Original input tensor shape (rank ≤ 4)")
    indices_shape: tuple[int, ...] = Field(..., description="Original indices tensor shape (rank ≤ 4)")
    output_shape: tuple[int, ...] = Field(..., description="Original output tensor shape (rank ≤ 4)")

    @property
    def input_rank(self) -> int:
        return len(self.input_shape)

    @property
    def indices_rank(self) -> int:
        return len(self.indices_shape)


@register_op_options(AirOpType.GATHER_ND)
class AirGatherNdOptions:
    """Options for the GATHER_ND operator."""
    params_shape: tuple[int, ...] = Field(..., description="Original params tensor shape (rank ≤ 4)")
    indices_shape: tuple[int, ...] = Field(..., description="Original indices tensor shape (rank ≤ 4)")
    output_shape: tuple[int, ...] = Field(..., description="Original output tensor shape (rank ≤ 4)")

    @property
    def params_rank(self) -> int:
        return len(self.params_shape)

    @property
    def indices_rank(self) -> int:
        return len(self.indices_shape)


@register_op_options(AirOpType.STRIDED_SLICE)
class AirStridedSliceOptions:
    """Options for STRIDED_SLICE operator.

    Attributes:
        begin (tuple[int, int, int, int]): Begin indices for each dimension.
        end (tuple[int, int, int, int]): End indices for each dimension.
        stride (tuple[int, int, int, int]): Stride values for each dimension.
        begin_mask (int): Mask for begin indices (default 0).
        end_mask (int): Mask for end indices (default 0).
        ellipsis_mask (int): Mask for ellipsis (default 0).
        new_axis_mask (int): Mask for new axes (default 0).
        shrink_axis_mask (int): Mask for shrink axes (default 0).
        offset (bool): If True, apply offset to the begin and end indices (default False).
    """

    begin: tuple[int, ...] = Field(..., description="Begin indices for each dimension")
    end: tuple[int, ...] = Field(..., description="End indices for each dimension")
    stride: tuple[int, ...] = Field(..., description="Stride values for each dimension")

    begin_mask: int = Field(0, description="Mask for begin indices")
    end_mask: int = Field(0, description="Mask for end indices")
    ellipsis_mask: int = Field(0, description="Mask for ellipsis")
    new_axis_mask: int = Field(0, description="Mask for new axes")
    shrink_axis_mask: int = Field(0, description="Mask for shrink axes")
    offset: bool = Field(False, description="If True, apply offset to the begin and end indices")

    def get_slices(self, input_shape: tuple[int, ...], pad_to: int = 4) -> list[AirStrideSlice]:
        """Compute (begin, end, stride) for each axis, padding dims and shape to `pad_to` dims.

        Args:
            input_shape: The shape of the input tensor.
            pad_to: The number of dimensions to pad the input shape to (default 4).

        Returns:
            A list of AirStrideSlice, each containing (begin, end, stride) for each axis.
        """

        def _pad_to_n(tup: tuple[int, ...], n: int, pad_val: int) -> tuple[int, ...]:
            length = len(tup)
            if length > n:
                raise ValueError(f"Tuple length {length} exceeds expected {n}")
            if length < n:
                return (pad_val,) * (n - length) + tup
            return tup

        def _clamp(idx: int, size: int, stride: int) -> int:
            lo, hi = (0, size) if stride > 0 else (-1, size - 1)
            return max(lo, min(idx, hi))
        orig_rank = len(input_shape)
        shift = pad_to - orig_rank

        # 1) Normalize input_shape using _pad_to_n (pad_val=1)
        input_shape = _pad_to_n(input_shape, pad_to, pad_val=1)

        # 2) Pad the raw slice parameters (pad_val=0 for begins, =1 for ends/strides)
        b_dims = _pad_to_n(self.begin, pad_to, pad_val=0)
        e_dims = _pad_to_n(self.end, pad_to, pad_val=1)
        s_dims = _pad_to_n(self.stride, pad_to, pad_val=1)

        # 3) Unsupported masks
        if self.ellipsis_mask or self.new_axis_mask:
            raise NotImplementedError("ellipsis_mask/new_axis_mask not supported")
        begin_mask = self.begin_mask << shift
        end_mask = self.end_mask << shift
        shrink_axis_mask = self.shrink_axis_mask << shift

        slices: list[AirStrideSlice] = []

        for axis, size in enumerate(input_shape):
            b, e, s = b_dims[axis], e_dims[axis], s_dims[axis]

            # negative begin
            if b < 0:
                b += size
            # begin_mask
            if begin_mask & (1 << axis):
                b = 0 if s > 0 else size - 1
            b = _clamp(b, size, s)

            # shrink-axis
            if shrink_axis_mask & (1 << axis):
                e = b + 1 if b < size else b
                slices.append(AirStrideSlice(begin=b, end=e, stride=1))
                continue

            # offset end
            if self.offset:
                e += b
            # negative end
            if e < 0:
                e += size
            # end_mask
            if end_mask & (1 << axis):
                e = size if s > 0 else -1
            e = _clamp(e, size, s)

            slices.append(AirStrideSlice(begin=b, end=e, stride=s))
        # END FOR
        return slices


@register_op_options(AirOpType.TANH)
class AirTanhOptions:
    """Options for the TANH operator."""

    pass


@register_op_options(AirOpType.ETHOS_U)
class AirEthosUOptions:
    """Options for the ETHOS_U operator.

    Attributes:
        co_type (int): Command-stream type identifier encoded by Vela (default 0).
        command_stream_size (int): Size in bytes of the command stream tensor.
        num_base_addresses (int): Total number of base addresses (inputs excluding command stream plus outputs).
        custom_options_format (int): LiteRT CustomOptionsFormat value for the operator.
        custom_options (tuple[int, ...]): Raw custom options payload (typically Flexbuffers encoded).
    """

    co_type: int = Field(0, description="Command-stream type identifier encoded by Vela")
    command_stream_size: int = Field(0, ge=0, description="Size in bytes of the command stream tensor")
    num_base_addresses: int = Field(0, ge=0, description="Total number of base addresses for the invocation")
    custom_options_format: int = Field(0, description="LiteRT CustomOptionsFormat value")
    custom_options: tuple[int, ...] = Field(default_factory=tuple, description="Raw custom options payload")

@register_op_options(AirOpType.TRANSPOSE_CONV)
class AirTransposeConvOptions:
    """Options for the TRANSPOSE_CONV operator.

    Attributes:
        padding_height (int): pixels to pad input top & bottom (default 0).
        padding_width (int): pixels to pad input left & right (default 0).
        padding_offsets_height (int): Padding for top & bottom offsets (default 0).
        padding_offsets_width (int): Padding for left & right offsets (default 0).
        stride_height (int): vertical stride (default 1).
        stride_width (int): horizontal stride (default 1).
        dilation_height (int): vertical dilation factor (default 1).
        dilation_width (int): horizontal dilation factor (default 1).
        activation (AirActivationType): fused activation (default NONE).
        bias_tensor_type (AirTensorType): bias tensor type (default FLOAT32).
    """

    padding_height: int = Field(0, description="Padding for top & bottom")
    padding_width: int = Field(0, description="Padding for left & right")
    padding_offsets_height: int = Field(0, description="Padding for top & bottom offsets")
    padding_offsets_width: int = Field(0, description="Padding for left & right offsets")
    stride_height: int = Field(1, description="Vertical stride")
    stride_width: int = Field(1, description="Horizontal stride")
    dilation_height: int = Field(1, description="Vertical dilation")
    dilation_width: int = Field(1, description="Horizontal dilation")
    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")
    bias_tensor_type: AirTensorType = Field(AirTensorType.FLOAT32, description="Bias tensor type")


@register_op_options(AirOpType.TRANSPOSE)
class AirTransposeOptions:
    """Options for the TRANSPOSE operator.

    Attributes:
        perm (list[int]|None): The permutation of the dimensions of the input tensor.
    """

    permutations: list[int] | None = Field(None, description="The permutation of the dimensions of the input tensor.")


@register_op_options(AirOpType.REVERSE_V2)
class AirReverseV2Options:
    """Options for the REVERSE_V2 operator.

    Attributes:
        axes (list[int]): Axes to reverse.
    """

    axes: list[int] = Field(default_factory=list, description="Axes to reverse")


@register_op_options(AirOpType.UNPACK)
class AirUnpackOptions:
    """Options for the UNPACK operator.

    Attributes:
        num (int): Number of output tensors to unpack (default 0).
        axis (int): Axis along which to unpack the input tensor (default 0).
    """

    num: int = Field(0, description="Number of output tensors to unpack")
    axis: int = Field(0, description="Axis along which to unpack the input tensor")


@register_op_options(AirOpType.SVDF)
class AirSvdfOptions:
    """Options for the SVDF operator.

    Attributes:
        rank (int): The rank of the SVDF operation (default 1).
        activation (AirActivationType): Fused activation function (default NONE).
        asymmetric_quantize_inputs (bool): If True, use asymmetric quantization for inputs (default False).
    """

    rank: int = Field(1, description="The rank of the SVDF operation")
    activation: AirActivationType = Field(AirActivationType.NONE, description="Fused activation function")
    asymmetric_quantize_inputs: bool = Field(False, description="If True, use asymmetric quantization for inputs")


@register_op_options(AirOpType.ZEROS_LIKE)
class AirZerosLikeOptions:
    """Options for the ZEROS_LIKE operator.

    Attributes:
        zero_point (int): The zero point for the ZEROS_LIKE operator.
    """

    zero_point: int = Field(0, description="The zero point for the operator")


@register_op_options(AirOpType.PRELU)
class AirPreluOptions:
    """Options for the PReLU operator."""
    pass

@register_op_options(AirOpType.RESIZE_NEAREST_NEIGHBOR)
class AirResizeNearestNeighborOptions:
    """Options for the RESIZE_NEAREST_NEIGHBOR operator.
    
    Attributes:
        align_corners (bool): If True, align the input and output corners (default False).
        half_pixel_centers (bool): If True, use half-pixel centers (default False).
    """

    align_corners: bool = Field(False, description="If True, align the input and output corners")
    half_pixel_centers: bool = Field(False, description="If True, use half-pixel centers")

@register_op_options(AirOpType.ABS)
class AirAbsOptions:
    """Options for the ABS operator."""
    pass


@register_op_options(AirOpType.SQRT)
class AirSqrtOptions:
    """Options for the SQRT operator."""
    pass
@register_op_options(AirOpType.RSQRT)
class AirRsqrtOptions:
    """Options for the RSQRT operator."""
    pass
