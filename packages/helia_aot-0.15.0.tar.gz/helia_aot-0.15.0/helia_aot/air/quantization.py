from pydantic.dataclasses import dataclass
from pydantic import Field
from .utils import quantize_multiplier


@dataclass
class AirFixedPointScale:
    multiplier: int = Field(..., description="The fixed point multiplier")
    shift: int = Field(..., description="The fixed point shift")

    @classmethod
    def from_real_multiplier(cls, real_multiplier: float):
        """Create a fixed point scale from a real multiplier."""
        multiplier, shift = quantize_multiplier(real_multiplier)
        return cls(multiplier=multiplier, shift=shift)


@dataclass
class AirQuantizationDetails:
    """Base class for quantization details."""

    pass


@dataclass
class AirBlockwiseQuantization(AirQuantizationDetails):
    """Blockwise quantization details."""

    scales: int = Field(0, description="Number of scales")
    zero_points: int = Field(0, description="Number of zero points")
    block_size: int = Field(0, description="Size of the blocks")


@dataclass
class AirQuantizationParameters:
    """Parameters for quantization of a tensor."""

    min: list[float] | None = Field(None, description="Minimum values for quantization")
    max: list[float] | None = Field(None, description="Maximum values for quantization")
    scale: list[float] | None = Field(None, description="Scale factors for quantization")
    zero_point: list[int] | None = Field(None, description="Zero points for quantization")
    details_type: int = Field(0, description="Type of quantization details")
    details: AirQuantizationDetails | None = Field(None, description="Quantization details")
    quantization_dimension: int = Field(0, description="Quantization dimension")
