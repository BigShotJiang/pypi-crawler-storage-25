from logging import getLogger
from dataclasses import asdict
from pydantic.dataclasses import dataclass
from pydantic import Field
import numpy as np
from .enums import AirOpType
from .tensor import TensorId
from .options import AirOperatorOptions

logger = getLogger(__name__)

OpId = str


@dataclass
class AirOperator:
    """Intermediate Representation of an operator (node) in the graph.

    Attributes:
        id (OpId): Unique node identifier (e.g. 'conv1').
        op_type (AirOpType): The operator unique type.
        input_ids (list[TensorId]): Input tensor IDs.
        output_ids (list[TensorId]): Output tensor IDs.
        named_tensors (dict[str, TensorId]): Local tensor names to IDs mapping.
        options (AirOperatorOptions): Typed options/config for this op.
    """

    id: OpId = Field(..., description="Unique node identifier (e.g. 'conv1')")
    op_type: AirOpType | str = Field(..., description="The operator unique type.")
    input_ids: list[TensorId] = Field(default_factory=list, description="Input tensor IDs.")
    output_ids: list[TensorId] = Field(default_factory=list, description="Output tensor IDs.")
    named_tensors: dict[str, TensorId] = Field(default_factory=dict, description="Local tensor names to IDs mapping.")
    options: AirOperatorOptions = Field(
        default_factory=AirOperatorOptions, description="Typed options/config for this op."
    )

    def __hash__(self):
        return hash(self.id)

    def __eq__(self, other: object) -> bool:
        return isinstance(other, AirOperator) and self.id == other.id

    @property
    def tensor_ids(self) -> list[TensorId]:
        """All tensor IDs (inputs + outputs + named tensors) associated with this operator."""
        return self.input_ids + self.output_ids + list(self.named_tensors.values())

    @property
    def fan_in(self) -> int:
        """How many input tensors this operator consumes."""
        return len(self.input_ids)

    @property
    def fan_out(self) -> int:
        """How many output tensors this operator produces."""
        return len(self.output_ids)

    def print_info(self, verbose: int = 0):
        """Debug print the template values for the operator."""
        if verbose <= 0:
            pass
        elif verbose <= 2:
            logger.info(f"  • AIR Operator {self.op_type} (id: {self.id})")
        else:
            logger.debug(f"{120 * '='}")
            logger.debug(f"[bold]AIR Operator {self.op_type} (id: {self.id})[/]")
            logger.debug(f"{120 * '='}")
            logger.debug("  Tensors:")
            logger.debug(f"  •  Inputs: ({self.input_ids})")
            logger.debug(f"  • Outputs: ({self.output_ids})")
            logger.debug(f"  •   Local: ({[tensor_id for tensor_id in self.named_tensors.values()]})")

            logger.debug("  Options:")
            for name, val in asdict(self.options).items():
                if isinstance(val, (np.ndarray, list)):
                    logger.debug(f"    • {name}: {len(val)}")
                elif isinstance(val, str):
                    logger.debug(f"    • {name}: {val[:100]}")
                else:
                    logger.debug(f"    • {name}: {val}")
            logger.debug(f"{120 * '='}\n")
