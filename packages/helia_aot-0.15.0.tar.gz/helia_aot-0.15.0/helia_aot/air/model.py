from pydantic.dataclasses import dataclass
from pydantic import Field
from .tensor import AirTensor, TensorId
from .operator import AirOperator


@dataclass
class AirModel:
    """In-memory graph IR for AOT codegen.

    Attributes:
        name (str): Name of the model.
        version (str): Version of the model.
        description (str): Description of the model.
        tensors (dict[str, AirTensor]): Mapping from tensor ID to its AirTensor metadata.
        operators (list[AirOperator]): Topologically ordered list of operators (nodes) in the graph.
        input_ids (list[str]): IDs of tensors that serve as model inputs.
        output_ids (list[str]): IDs of tensors that serve as model outputs.
    """

    name: str = Field(default="Model", description="Name of the model")
    version: str = Field(default="1.0.0", description="Version of the model")
    description: str = Field(default="", description="Description of the model")
    tensors: dict[str, AirTensor] = Field(
        default_factory=dict, description="Mapping from tensor ID to its AirTensor metadata"
    )
    operators: list[AirOperator] = Field(
        default_factory=list, description="Topologically ordered list of operators (nodes) in the graph"
    )
    input_ids: list[TensorId] = Field(default_factory=list, description="IDs of tensors that serve as model inputs")
    output_ids: list[TensorId] = Field(default_factory=list, description="IDs of tensors that serve as model outputs")

    def add_tensor(self, tensor: AirTensor) -> None:
        """Register a new tensor in the model.

        Raises:
            ValueError: If a tensor with the same ID already exists.
        """
        if tensor.id in self.tensors:
            raise ValueError(f"Tensor '{tensor.id}' already exists in the model")
        self.tensors[tensor.id] = tensor

    def remove_tensor(self, tid: TensorId) -> None:
        """Remove a tensor from the model by its ID.

        Raises:
            KeyError: If the tensor ID is not found.
        """
        try:
            del self.tensors[tid]
        except KeyError:
            raise KeyError(f"Tensor '{tid}' not found in the model")

    def add_operator(self, op: AirOperator) -> None:
        """Append a new operator to the execution list.

        Raises:
            ValueError: If an operator with the same ID already exists.
        """
        if any(existing.id == op.id for existing in self.operators):
            raise ValueError(f"Operator '{op.id}' already exists in the model")
        self.operators.append(op)

    def has_tensor(self, tid: TensorId) -> bool:
        """Check if a tensor exists in the model by its ID."""
        return tid in self.tensors

    def get_tensor(self, tid: TensorId) -> AirTensor:
        """Lookup a tensor by its ID.

        Raises:
            KeyError: If the tensor ID is not found.
        """
        try:
            return self.tensors[tid]
        except KeyError:
            raise KeyError(f"Tensor '{tid}' not found in the model")

    @property
    def inputs(self) -> list[AirTensor]:
        """List of AirTensor objects corresponding to model inputs."""
        return [self.get_tensor(tid) for tid in self.input_ids]

    @property
    def outputs(self) -> list[AirTensor]:
        """List of AirTensor objects corresponding to model outputs."""
        return [self.get_tensor(tid) for tid in self.output_ids]

    def topo_sort(self) -> list[AirOperator]:
        """Return operators in execution order.

        Assumes `operators` was populated in valid topological order.
        """
        return list(self.operators)

    def prune_unused_tensors(self) -> list[TensorId]:
        """Remove dangling tensors that are not referenced by any operator or model input/output."""
        # Collect all used tensors
        used_tensor_ids = set([tensor_id for op in self.operators for tensor_id in op.tensor_ids])
        used_tensor_ids.update(self.input_ids)
        used_tensor_ids.update(self.output_ids)
        # Remove unused tensors
        unused_tensor_ids = [tid for tid in self.tensors.keys() if tid not in used_tensor_ids]
        for tid in unused_tensor_ids:
            self.remove_tensor(tid)
        return unused_tensor_ids
