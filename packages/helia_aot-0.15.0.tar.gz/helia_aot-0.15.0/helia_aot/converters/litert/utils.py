"""
# :material-tools: LiteRT Utility API

This module provides utility functions for working with the LiteRT schema.

Classes:
    BuiltinOperatorMap: Mapping of builtin operator codes to their names.
    BuiltinOptionsMap: Mapping of builtin options codes to their names.

Functions:
    get_builtin_code: Return the builtin code of the given operator code.
    compute_tensor_bytes: Compute the number of bytes for a tensor based on its type and shape.
    compute_tensor_ctype: Compute the C type for a tensor based on its type.
    get_tensor_dtype: Get the numpy dtype of a tensor.

Copyright 2025 Ambiq. All Rights Reserved.

"""

import numpy as np
from helia_aot.litert import schema_py_generated as litert
# from helia_aot.air import AirOpType

BuiltinOperatorMap: dict[int, str] = {
    value: key
    for key, value in litert.BuiltinOperator.__dict__.items()
    if not key.startswith("__") and isinstance(value, int)
}

BuiltinOptionsMap: dict[int, str] = {
    value: key
    for key, value in litert.BuiltinOptions.__dict__.items()
    if not key.startswith("__") and isinstance(value, int)
}


def get_builtin_code(opcode: litert.OperatorCodeT | litert.OperatorCode) -> int:
    """Return the builtin code of the given operator code.

    This function serves as a workaround for older versions of LiteRT
    that do not support/populate the BuiltinCode property.

    Args:
      opcode: Operator code.

    Returns:
      int: Builtin code.
    """

    if hasattr(opcode, "BuiltinCode") and callable(opcode.BuiltinCode):
        return max(opcode.BuiltinCode(), opcode.DeprecatedBuiltinCode())

    return max(opcode.builtinCode, opcode.deprecatedBuiltinCode)


def compute_tensor_bytes(tensor: litert.TensorT) -> int:
    """Compute the number of bytes for a tensor based on its type and shape.

    Args:
        tensor (litert.TensorT): Tensor object.

    Returns:
        int: Number of bytes for the tensor.
    """

    tensor_size_map = {
        litert.TensorType.FLOAT32: 4,
        litert.TensorType.FLOAT16: 2,
        litert.TensorType.INT32: 4,
        litert.TensorType.UINT8: 1,
        litert.TensorType.INT64: 8,
        litert.TensorType.STRING: -1,
        litert.TensorType.BOOL: 1,
        litert.TensorType.INT16: 2,
        litert.TensorType.COMPLEX64: 8,
        litert.TensorType.INT8: 1,
        litert.TensorType.FLOAT64: 8,
        litert.TensorType.COMPLEX128: 16,
        litert.TensorType.UINT64: 8,
        litert.TensorType.RESOURCE: -1,
        litert.TensorType.VARIANT: -1,
        litert.TensorType.UINT32: 4,
        litert.TensorType.UINT16: 2,
        litert.TensorType.INT4: 1,
        litert.TensorType.BFLOAT16: 2,
    }

    byte_size = tensor_size_map.get(tensor.type, -1)
    if byte_size == -1:
        raise ValueError(f"Unsupported tensor type: {tensor.type}")

    if len(tensor.shape) == 0:
        return 0

    return int(np.prod(tensor.shape) * byte_size)


def compute_tensor_ctype(tensor: litert.TensorT) -> str:
    """Compute the C type for a tensor based on its type.

    Args:
        tensor (litert.TensorT): Tensor object.

    Returns:
        str: C type of the tensor.
    """
    tensor_ctype_map = {
        litert.TensorType.FLOAT32: "float",
        litert.TensorType.FLOAT16: "float16_t",
        litert.TensorType.INT32: "int32_t",
        litert.TensorType.UINT8: "uint8_t",
        litert.TensorType.INT64: "int64_t",
        litert.TensorType.STRING: -1,
        litert.TensorType.BOOL: "bool",
        litert.TensorType.INT16: "int16_t",
        litert.TensorType.COMPLEX64: "complex64_t",
        litert.TensorType.INT8: "int8_t",
        litert.TensorType.FLOAT64: "double",
        litert.TensorType.COMPLEX128: "complex128_t",
        litert.TensorType.UINT64: "uint64_t",
        litert.TensorType.RESOURCE: None,
        litert.TensorType.VARIANT: None,
        litert.TensorType.UINT32: "uint32_t",
        litert.TensorType.UINT16: "uint16_t",
        litert.TensorType.INT4: "int4_t",
        litert.TensorType.BFLOAT16: "bfloat16_t",
    }
    ctype = tensor_ctype_map.get(tensor.type)
    if ctype is None:
        raise ValueError(f"Unsupported tensor type: {tensor.type}")

    return ctype


def get_tensor_dtype(tensor: litert.TensorT) -> np.dtype:
    """Get the numpy dtype of a tensor.

    Args:
        tensor (litert.TensorT): Tensor object.

    Returns:
        np.dtype: Numpy dtype of the tensor.
    """
    tensor_dtype_map = {
        litert.TensorType.FLOAT32: np.float32,
        litert.TensorType.FLOAT16: np.float16,
        litert.TensorType.INT32: np.int32,
        litert.TensorType.UINT8: np.uint8,
        litert.TensorType.INT64: np.int64,
        litert.TensorType.STRING: None,  # Not supported
        litert.TensorType.BOOL: np.bool,
        litert.TensorType.INT16: np.int16,
        litert.TensorType.COMPLEX64: np.complex64,
        litert.TensorType.INT8: np.int8,
        litert.TensorType.FLOAT64: np.float64,
        litert.TensorType.COMPLEX128: np.complex128,
        litert.TensorType.UINT64: np.uint64,
        litert.TensorType.RESOURCE: np.int8,
        litert.TensorType.VARIANT: None,
        litert.TensorType.UINT32: np.uint32,
        litert.TensorType.UINT16: np.uint16,
        litert.TensorType.INT4: np.int8,
        litert.TensorType.BFLOAT16: None,  # Not supported
    }
    dtype = tensor_dtype_map.get(tensor.type)
    if dtype is None:
        raise ValueError(f"Unsupported tensor type: {tensor.type}")

    return np.dtype(dtype)


def is_constant_tensor(tensor: litert.TensorT, model: litert.ModelT, subgraph: litert.SubGraphT) -> bool:
    """Check if a tensor is a constant tensor in the LiteRT model.

    Args:
        tensor (litert.TensorT): Tensor object.
        model (litert.ModelT): LiteRT model object.
        subgraph (litert.SubGraphT): Subgraph object from LiteRT model.

    Returns:
        bool: True if the tensor is constant, False otherwise.
    """
    if tensor.buffer < 0:
        return False
    buffer = model.buffers[tensor.buffer]
    if buffer.data is None or len(buffer.data) == 0:
        return False

    subgraph_inputs = [subgraph.tensors[i].buffer for i in subgraph.inputs]
    subgraph_outputs = [subgraph.tensors[i].buffer for i in subgraph.outputs]

    if tensor.buffer in subgraph_inputs or tensor.buffer in subgraph_outputs:
        return False

    return True


def load_tensor_data(
    tensor: litert.TensorT,
    model: litert.ModelT,
) -> np.ndarray:
    """Load the data of a tensor from the LiteRT model.

    Args:
        tensor (litert.TensorT): Tensor object.
        model (litert.ModelT): LiteRT model object.

    Returns:
        np.ndarray: Numpy array containing the tensor data.
    """
    # Grab tensor buffer
    buffer = model.buffers[tensor.buffer]

    # If the buffer is empty, return None
    if buffer.data is None or len(buffer.data) == 0:
        return None

    # Convert to correct numpy dtype
    data = buffer.data.view(get_tensor_dtype(tensor))

    # Reshape data if tensor has a shape
    if tensor.shape is not None and len(tensor.shape) != 0:
        data = data.reshape(tensor.shape)

    return data


# OperatorMap: dict[int, AirOpType] = {
#     litert.BuiltinOperator.ADD: AirOpType.ADD,
#     litert.BuiltinOperator.ASSIGN_VARIABLE: AirOpType.ASSIGN_VARIABLE,
#     litert.BuiltinOperator.AVERAGE_POOL_2D: AirOpType.AVERAGE_POOL_2D,
#     litert.BuiltinOperator.BATCH_MATMUL: AirOpType.BATCH_MATMUL,
#     litert.BuiltinOperator.CONCATENATION: AirOpType.CONCATENATION,
#     litert.BuiltinOperator.CONV_2D: AirOpType.CONV_2D,
#     litert.BuiltinOperator.DEPTHWISE_CONV_2D: AirOpType.DEPTHWISE_CONV_2D,
#     litert.BuiltinOperator.DEQUANTIZE: AirOpType.DEQUANTIZE,
#     litert.BuiltinOperator.EXPAND_DIMS: AirOpType.EXPAND_DIMS,
#     litert.BuiltinOperator.FILL: AirOpType.FILL,
#     litert.BuiltinOperator.FULLY_CONNECTED: AirOpType.FULLY_CONNECTED,
#     litert.BuiltinOperator.HARD_SWISH: AirOpType.HARD_SWISH,
#     litert.BuiltinOperator.LEAKY_RELU: AirOpType.LEAKY_RELU,
#     litert.BuiltinOperator.LOGISTIC: AirOpType.LOGISTIC,
#     litert.BuiltinOperator.MAX_POOL_2D: AirOpType.MAX_POOL_2D,
#     litert.BuiltinOperator.MAXIMUM: AirOpType.MAXIMUM,
#     litert.BuiltinOperator.EQUAL: AirOpType.EQUAL,
#     litert.BuiltinOperator.NOT_EQUAL: AirOpType.COMPARISON,
#     litert.BuiltinOperator.LESS: AirOpType.COMPARISON,
#     litert.BuiltinOperator.LESS_EQUAL: AirOpType.COMPARISON,
#     litert.BuiltinOperator.GREATER: AirOpType.COMPARISON,
#     litert.BuiltinOperator.GREATER_EQUAL: AirOpType.COMPARISON,
#     litert.BuiltinOperator.MEAN: AirOpType.MEAN,
#     litert.BuiltinOperator.MINIMUM: AirOpType.MINIMUM,
#     litert.BuiltinOperator.MUL: AirOpType.MUL,
#     litert.BuiltinOperator.PACK: AirOpType.PACK,
#     litert.BuiltinOperator.PAD: AirOpType.PAD,
#     litert.BuiltinOperator.PADV2: AirOpType.PAD,
#     litert.BuiltinOperator.READ_VARIABLE: AirOpType.READ_VARIABLE,
#     litert.BuiltinOperator.QUANTIZE: AirOpType.QUANTIZE,
#     litert.BuiltinOperator.RELU: AirOpType.RELU,
#     litert.BuiltinOperator.RELU6: AirOpType.RELU,
#     litert.BuiltinOperator.RELU_N1_TO_1: AirOpType.RELU,
#     litert.BuiltinOperator.RESHAPE: AirOpType.RESHAPE,
#     litert.BuiltinOperator.SHAPE: AirOpType.SHAPE,
#     litert.BuiltinOperator.SOFTMAX: AirOpType.SOFTMAX,
#     litert.BuiltinOperator.SQUEEZE: AirOpType.SQUEEZE,
#     litert.BuiltinOperator.STRIDED_SLICE: AirOpType.STRIDED_SLICE,
#     litert.BuiltinOperator.SVDF: AirOpType.SVDF,
#     litert.BuiltinOperator.TANH: AirOpType.TANH,
#     litert.BuiltinOperator.TRANSPOSE_CONV: AirOpType.TRANSPOSE_CONV,
#     litert.BuiltinOperator.TRANSPOSE: AirOpType.TRANSPOSE,
#     litert.BuiltinOperator.ZEROS_LIKE: AirOpType.ZEROS_LIKE,
# }
