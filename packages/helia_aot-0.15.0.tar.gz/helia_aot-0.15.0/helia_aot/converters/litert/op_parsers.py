from typing import Callable
import numpy as np
from helia_aot.litert import schema_py_generated as litert

from helia_aot.air import (
    AirOpType,
    AirReluType,
    AirTensorType,
    AirTensorKind,
    AirTensorDim,
    AirFullyConnectedWeightsFormat,
    AirModel,
    AirOperator,
    AirActivationType,
    AirBatchToSpaceNDOptions,
    AirConv2DOptions,
    AirDepthwiseConv2DOptions,
    AirDepthToSpaceOptions,
    AirTransposeConvOptions,
    AirAddOptions,
    AirSubOptions,
    AirSquaredDifferenceOptions,
    AirAssignVariableOptions,
    AirAveragePool2DOptions,
    AirBatchMatMulOptions,
    AirConcatenationOptions,
    AirComparisonOptions,
    AirComparisonType,
    AirDequantizeOptions,
    AirExpandDimsOptions,
    AirFillOptions,
    AirGatherOptions,
    AirGatherNdOptions,
    AirFullyConnectedOptions,
    AirHardSwishOptions,
    AirLeakyReluOptions,
    AirLogisticOptions,
    AirMaxPool2DOptions,
    AirMaximumOptions,
    AirMeanOptions,
    AirSumOptions,
    AirMinimumOptions,
    AirMulOptions,
    AirPackOptions,
    AirPadOptions,
    AirQuantizeOptions,
    AirReadVariableOptions,
    AirReduceMaxOptions,
    AirReduceMinOptions,
    AirArgMaxOptions,
    AirArgMinOptions,
    AirReluOptions,
    AirReshapeOptions,
    AirShapeOptions,
    AirSoftmaxOptions,
    AirSpaceToBatchNDOptions,
    AirSpaceToDepthOptions,
    AirSplitOptions,
    AirSqueezeOptions,
    AirSliceOptions,
    AirStridedSliceOptions,
    AirSvdfOptions,
    AirTanhOptions,
    AirTransposeOptions,
    AirReverseV2Options,
    AirUnpackOptions,
    AirZerosLikeOptions,
    AirEthosUOptions,
    AirSpatialPad,
    AirPreluOptions,
    AirResizeNearestNeighborOptions,
    AirAbsOptions,
    AirSqrtOptions,
    AirRsqrtOptions,
    compute_padding_with_offset,
    compute_padding,
)

from .utils import get_builtin_code
from helia_aot.registry import Registry
from helia_aot.air.op_keys import canonical_op_key

OpParserFn = Callable[[int, litert.ModelT, litert.SubGraphT, AirModel], AirOperator]


def register_op_parser(op_type: str) -> Callable[[OpParserFn], OpParserFn]:
    """Decorator to annotate default operator parser registrations."""

    def _decorator(fn: OpParserFn) -> OpParserFn:
        op_keys = tuple(getattr(fn, "__helia_op_keys__", ()))
        setattr(fn, "__helia_op_keys__", (*op_keys, canonical_op_key(op_type)))
        return fn

    return _decorator


def get_op_parser(registry: Registry[str | AirOpType, OpParserFn], op_type: str | AirOpType) -> OpParserFn | None:
    """Get the operator parser for a specific operator type."""
    return registry.get(op_type) if registry.has(op_type) else None


def register_default_litert_parsers(registry: Registry[str | AirOpType, OpParserFn]) -> None:
    """Register all built-in LiteRT op parsers into the provided registry."""
    for name, parser in _iter_registered_op_parsers():
        registry.register(name, parser, overwrite=True)


def _iter_registered_op_parsers() -> list[tuple[str, OpParserFn]]:
    """Discover built-in parser functions decorated with register_op_parser."""
    specs: list[tuple[str, OpParserFn]] = []
    for value in globals().values():
        if not callable(value):
            continue
        op_keys = getattr(value, "__helia_op_keys__", None)
        if not isinstance(op_keys, tuple):
            continue
        for op_key in op_keys:
            specs.append((op_key, value))
    return specs


def parse_tensor_type(tensor_type: litert.TensorType) -> AirTensorType:
    """Convert a LiteRT TensorType to AIR TensorType.

    Args:
        tensor_type (litert.TensorType): The LiteRT tensor type.

    Returns:
        AirTensorType: The corresponding AIR tensor type.
    """
    return AirTensorType(tensor_type)


def parse_activation_type(value: litert.ActivationFunctionType) -> AirActivationType:
    """Convert a LiteRT ActivationFunctionType to AIR ActivationType.

    Args:
        value (litert.ActivationFunctionType): The LiteRT activation function type.

    Returns:
        AirActivationType: The corresponding AIR activation type.
    """
    if value == litert.ActivationFunctionType.NONE or value is None:
        return AirActivationType.NONE
    elif value == litert.ActivationFunctionType.RELU:
        return AirActivationType.RELU
    elif value == litert.ActivationFunctionType.RELU_N1_TO_1:
        return AirActivationType.RELU_N1_TO_1
    elif value == litert.ActivationFunctionType.RELU6:
        return AirActivationType.RELU6
    elif value == litert.ActivationFunctionType.TANH:
        return AirActivationType.TANH
    elif value == litert.ActivationFunctionType.SIGN_BIT:
        return AirActivationType.SIGN_BIT
    else:
        raise ValueError(f"Unknown ActivationFunctionType: {value}")


def _get_static_shape(
    tensor: litert.TensorT,
    *,
    name: str,
    min_rank: int = 0,
    max_rank: int = 4,
) -> tuple[int, ...]:
    """Return the static shape of a LiteRT tensor, enforcing rank constraints."""

    if tensor.shape is None:
        raise ValueError(f"{name} tensor must have a statically known shape.")
    dims_raw = tensor.shape.tolist() if hasattr(tensor.shape, "tolist") else list(tensor.shape)
    dims = tuple(int(dim) for dim in dims_raw)

    rank = len(dims)
    if rank < min_rank:
        raise ValueError(f"{name} tensor rank must be >= {min_rank}, got {rank}.")
    if rank > max_rank:
        raise ValueError(f"{name} tensor rank must be <= {max_rank}, got {rank}.")
    if any(dim < 0 for dim in dims):
        raise ValueError(f"{name} tensor must have non-negative dimensions, got {dims}.")

    return dims


@register_op_parser("CONV_2D")
def parse_conv_2d(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a 2D convolution operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    kInputTensorIndex = 0
    kWeightsTensorIndex = 1
    kBiasTensorIndex = 2
    kOutputTensorIndex = 0

    op = subgraph.operators[id]

    input_tensor = subgraph.tensors[op.inputs[kInputTensorIndex]]
    weights_tensor = subgraph.tensors[op.inputs[kWeightsTensorIndex]]
    # bias_tensor = subgraph.tensors[op.inputs[kBiasTensorIndex]]
    # output_tensor = subgraph.tensors[op.outputs[kOutputTensorIndex]]

    options = AirConv2DOptions(
        padding_height=compute_padding(
            in_size=int(input_tensor.shape[AirTensorDim.H]),
            filter_size=int(weights_tensor.shape[AirTensorDim.H]),
            stride=op.builtinOptions.strideH,
            dilation_rate=op.builtinOptions.dilationHFactor,
            padding_type=op.builtinOptions.padding,
        ),
        padding_width=compute_padding(
            in_size=int(input_tensor.shape[AirTensorDim.W]),
            filter_size=int(weights_tensor.shape[AirTensorDim.W]),
            stride=op.builtinOptions.strideW,
            dilation_rate=op.builtinOptions.dilationWFactor,
            padding_type=op.builtinOptions.padding,
        ),
        stride_height=op.builtinOptions.strideH,
        stride_width=op.builtinOptions.strideW,
        dilation_height=op.builtinOptions.dilationHFactor,
        dilation_width=op.builtinOptions.dilationWFactor,
        activation=parse_activation_type(op.builtinOptions.fusedActivationFunction),
        bias_tensor_type=parse_tensor_type(op.builtinOptions.quantizedBiasType),
    )

    input_ids = [f"{op.inputs[kInputTensorIndex]}"]
    named_tensors = dict(weights=f"{op.inputs[kWeightsTensorIndex]}")
    [f"{op.inputs[kWeightsTensorIndex]}"]
    if (
        len(op.inputs) > kBiasTensorIndex
        and op.inputs[kBiasTensorIndex] is not None
        and op.inputs[kBiasTensorIndex] >= 0
    ):
        named_tensors["bias"] = f"{op.inputs[kBiasTensorIndex]}"
    output_ids = [f"{op.outputs[kOutputTensorIndex]}"]

    return AirOperator(
        id=str(id),
        op_type=AirOpType.CONV_2D,
        input_ids=input_ids,
        output_ids=output_ids,
        named_tensors=named_tensors,
        options=options,
    )


@register_op_parser("DEPTHWISE_CONV_2D")
def parse_depthwise_conv_2d(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a depthwise 2D convolution operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    kInputTensorIndex = 0
    kWeightsTensorIndex = 1
    kBiasTensorIndex = 2
    kOutputTensorIndex = 0

    op = subgraph.operators[id]

    input_tensor = subgraph.tensors[op.inputs[kInputTensorIndex]]
    weights_tensor = subgraph.tensors[op.inputs[kWeightsTensorIndex]]
    # bias_tensor = subgraph.tensors[op.inputs[kBiasTensorIndex]]
    # output_tensor = subgraph.tensors[op.outputs[kOutputTensorIndex]]

    options = AirDepthwiseConv2DOptions(
        depth_multiplier=op.builtinOptions.depthMultiplier,
        padding_height=compute_padding(
            in_size=int(input_tensor.shape[AirTensorDim.H]),
            filter_size=int(weights_tensor.shape[AirTensorDim.H]),
            stride=op.builtinOptions.strideH,
            dilation_rate=op.builtinOptions.dilationHFactor,
            padding_type=op.builtinOptions.padding,
        ),
        padding_width=compute_padding(
            in_size=int(input_tensor.shape[AirTensorDim.W]),
            filter_size=int(weights_tensor.shape[AirTensorDim.W]),
            stride=op.builtinOptions.strideW,
            dilation_rate=op.builtinOptions.dilationWFactor,
            padding_type=op.builtinOptions.padding,
        ),
        stride_height=op.builtinOptions.strideH,
        stride_width=op.builtinOptions.strideW,
        dilation_height=op.builtinOptions.dilationHFactor,
        dilation_width=op.builtinOptions.dilationWFactor,
        activation=parse_activation_type(op.builtinOptions.fusedActivationFunction),
    )

    input_ids = [f"{op.inputs[kInputTensorIndex]}"]
    named_tensors = dict(weights=f"{op.inputs[kWeightsTensorIndex]}")
    if (
        len(op.inputs) > kBiasTensorIndex
        and op.inputs[kBiasTensorIndex] is not None
        and op.inputs[kBiasTensorIndex] >= 0
    ):
        named_tensors["bias"] = f"{op.inputs[kBiasTensorIndex]}"
    output_ids = [f"{op.outputs[kOutputTensorIndex]}"]

    return AirOperator(
        id=str(id),
        op_type=AirOpType.DEPTHWISE_CONV_2D,
        input_ids=input_ids,
        output_ids=output_ids,
        named_tensors=named_tensors,
        options=options,
    )

@register_op_parser("DEPTH_TO_SPACE")
def parse_depth_to_space(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a depth to space operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.

    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirDepthToSpaceOptions(
        block_size=int(op.builtinOptions.blockSize)
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.DEPTH_TO_SPACE,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options
    )

@register_op_parser("TRANSPOSE_CONV")
def parse_transpose_conv(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a 2D transpose convolution operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    kInputTensorIndex = 2
    kWeightsTensorIndex = 1
    kBiasTensorIndex = 3
    kOutputTensorIndex = 0

    op = subgraph.operators[id]

    input_tensor = subgraph.tensors[op.inputs[kInputTensorIndex]]
    weights_tensor = subgraph.tensors[op.inputs[kWeightsTensorIndex]]
    # bias_tensor = subgraph.tensors[op.inputs[kBiasTensorIndex]]
    # output_tensor = subgraph.tensors[op.outputs[kOutputTensorIndex]]

    padding_h, padding_offsets_h = compute_padding_with_offset(
        in_size=int(input_tensor.shape[AirTensorDim.H]),
        filter_size=int(weights_tensor.shape[AirTensorDim.H]),
        stride=op.builtinOptions.strideH,
        dilation_rate=1,
        padding_type=op.builtinOptions.padding,
    )
    padding_offsets_h = int(padding_h) + int(padding_offsets_h)

    padding_w, padding_offsets_w = compute_padding_with_offset(
        in_size=int(input_tensor.shape[AirTensorDim.W]),
        filter_size=int(weights_tensor.shape[AirTensorDim.W]),
        stride=op.builtinOptions.strideW,
        dilation_rate=1,
        padding_type=op.builtinOptions.padding,
    )
    padding_offsets_w = int(padding_w) + int(padding_offsets_w)

    options = AirTransposeConvOptions(
        padding_height=padding_h,
        padding_width=padding_w,
        padding_offsets_height=padding_offsets_h,
        padding_offsets_width=padding_offsets_w,
        stride_height=op.builtinOptions.strideH,
        stride_width=op.builtinOptions.strideW,
        activation=parse_activation_type(op.builtinOptions.fusedActivationFunction),
        bias_tensor_type=parse_tensor_type(op.builtinOptions.quantizedBiasType),
    )

    input_ids = [f"{op.inputs[kInputTensorIndex]}"]
    named_tensors = dict(weights=f"{op.inputs[kWeightsTensorIndex]}")
    if (
        len(op.inputs) > kBiasTensorIndex
        and op.inputs[kBiasTensorIndex] is not None
        and op.inputs[kBiasTensorIndex] >= 0
    ):
        named_tensors["bias"] = f"{op.inputs[kBiasTensorIndex]}"
    output_ids = [f"{op.outputs[kOutputTensorIndex]}"]

    return AirOperator(
        id=str(id),
        op_type=AirOpType.TRANSPOSE_CONV,
        input_ids=input_ids,
        output_ids=output_ids,
        named_tensors=named_tensors,
        options=options,
    )


@register_op_parser("ADD")
def parse_add(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a 2D addition operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInput1TensorIndex = 0
    kInput2TensorIndex = 1
    kOutputTensorIndex = 0

    input1_tensor_id = f"{op.inputs[kInput1TensorIndex]}"
    input2_tensor_id = f"{op.inputs[kInput2TensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirAddOptions(activation=parse_activation_type(op.builtinOptions.fusedActivationFunction))

    return AirOperator(
        id=str(id),
        op_type=AirOpType.ADD,
        input_ids=[input1_tensor_id, input2_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("SUB")
def parse_sub(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a subtraction operator."""

    op = subgraph.operators[id]

    kInput1TensorIndex = 0
    kInput2TensorIndex = 1
    kOutputTensorIndex = 0

    input1_tensor_id = f"{op.inputs[kInput1TensorIndex]}"
    input2_tensor_id = f"{op.inputs[kInput2TensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirSubOptions(activation=parse_activation_type(op.builtinOptions.fusedActivationFunction))

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SUB,
        input_ids=[input1_tensor_id, input2_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("SQUARED_DIFFERENCE")
def parse_squared_difference(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a squared difference operator."""

    op = subgraph.operators[id]

    kInput1TensorIndex = 0
    kInput2TensorIndex = 1
    kOutputTensorIndex = 0

    input1_tensor_id = f"{op.inputs[kInput1TensorIndex]}"
    input2_tensor_id = f"{op.inputs[kInput2TensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirSquaredDifferenceOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SQUARED_DIFFERENCE,
        input_ids=[input1_tensor_id, input2_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("ASSIGN_VARIABLE")
def parse_assign_variable(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """
    Parse a variable assignment operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    kResourceVariableIdx = 0
    kAssignTensorIdx = 1

    op = subgraph.operators[id]

    resource_tensor_id = f"{op.inputs[kResourceVariableIdx]}"
    assign_tensor_id = f"{op.inputs[kAssignTensorIdx]}"

    resource_tensor = air_model.get_tensor(resource_tensor_id)
    assign_tensor = air_model.get_tensor(assign_tensor_id)

    # NOTE: Set the resource tensor shape and dtype to match the assign tensor
    resource_tensor.shape = assign_tensor.shape
    resource_tensor.dtype = assign_tensor.dtype

    options = AirAssignVariableOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.ASSIGN_VARIABLE,
        input_ids=[resource_tensor_id, assign_tensor_id],
        output_ids=[],
        options=options,
    )


@register_op_parser("AVERAGE_POOL_2D")
def parse_average_pool_2d(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a 2D average pooling operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)

    options = AirAveragePool2DOptions(
        padding_height=compute_padding(
            in_size=int(input_tensor.shape[AirTensorDim.H]),
            filter_size=op.builtinOptions.filterHeight,
            stride=op.builtinOptions.strideH,
            dilation_rate=1,
            padding_type=op.builtinOptions.padding,
        ),
        padding_width=compute_padding(
            in_size=int(input_tensor.shape[AirTensorDim.W]),
            filter_size=op.builtinOptions.filterWidth,
            stride=op.builtinOptions.strideW,
            dilation_rate=1,
            padding_type=op.builtinOptions.padding,
        ),
        stride_height=op.builtinOptions.strideH,
        stride_width=op.builtinOptions.strideW,
        filter_height=op.builtinOptions.filterHeight,
        filter_width=op.builtinOptions.filterWidth,
        activation=parse_activation_type(op.builtinOptions.fusedActivationFunction),
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.AVERAGE_POOL_2D,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )

@register_op_parser("BATCH_TO_SPACE_ND")
def parse_batch_to_space_nd(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a batch to space operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.

    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kBlockShapeTensorIndex = 1
    kCropsTensorIndex = 2
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    block_shape_tensor_id = f"{op.inputs[kBlockShapeTensorIndex]}"
    crops_tensor_id = f"{op.inputs[kCropsTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)
    if input_tensor.ndim not in (3, 4):
        raise ValueError("Input tensor for BATCH_TO_SPACE_ND must be 3D or 4D.")

    output_tensor = air_model.get_tensor(output_tensor_id)
    if output_tensor.ndim not in (3, 4):
        raise ValueError("Output tensor for BATCH_TO_SPACE_ND must be 3D or 4D.")

    block_shape_tensor = air_model.get_tensor(block_shape_tensor_id)
    if len(block_shape_tensor.data) == 1:
        block_shape = (int(block_shape_tensor.data[0]), 1)
    elif len(block_shape_tensor.data) == 2:
        block_shape = (int(block_shape_tensor.data[0]), int(block_shape_tensor.data[1]))
    else:
        raise ValueError("Block shape tensor for BATCH_TO_SPACE_ND must be of size 1 or 2.")

    crops_tensor = air_model.get_tensor(crops_tensor_id)
    if crops_tensor.ndim == 1:
        crops_tensor.shape = (1,) + crops_tensor.shape
    if crops_tensor.shape[0] > 2:
        raise ValueError("Crops tensor for BATCH_TO_SPACE_ND must be of shape (1, 2) or (2, 2).")
    crops = AirSpatialPad(
        top=int(crops_tensor.data[0, 0]),
        bottom=int(crops_tensor.data[0, 1]),
        left=0 if crops_tensor.shape[0] == 1 else int(crops_tensor.data[1, 0]),
        right=0 if crops_tensor.shape[0] == 1 else int(crops_tensor.data[1, 1])
    )

    options = AirBatchToSpaceNDOptions(
        block_shape=block_shape,
        crops=crops,
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.BATCH_TO_SPACE_ND,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options
    )

@register_op_parser("BATCH_MATMUL")
def parse_batch_matmul(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a batch matrix multiplication operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kLhsTensorIndex = 0
    kRhsTensorIndex = 1
    kOutputTensorIndex = 0

    lhs_tensor_id = f"{op.inputs[kLhsTensorIndex]}"
    rhs_tensor_id = f"{op.inputs[kRhsTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    lhs_tensor = air_model.get_tensor(lhs_tensor_id)
    if lhs_tensor.data is not None:
        lhs_tensor.kind = AirTensorKind.CONSTANT

    rhs_tensor = air_model.get_tensor(rhs_tensor_id)
    if rhs_tensor.data is not None:
        rhs_tensor.kind = AirTensorKind.CONSTANT

    options = AirBatchMatMulOptions(
        adj_x=op.builtinOptions.adjX,
        adj_y=op.builtinOptions.adjY,
        asymmetric_quantize_inputs=op.builtinOptions.asymmetricQuantizeInputs,
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.BATCH_MATMUL,
        input_ids=[lhs_tensor_id, rhs_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("CONCATENATION")
def parse_concatenation(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a 2D concatenation operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    input_tensor_ids = [f"{id}" for id in op.inputs]
    output_tensor_id = f"{op.outputs[0]}"

    output_tensor = air_model.get_tensor(output_tensor_id)

    options = AirConcatenationOptions(
        axis=op.builtinOptions.axis, activation=parse_activation_type(op.builtinOptions.fusedActivationFunction)
    )

    if options.axis < 0:
        options.axis += len(output_tensor.shape)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.CONCATENATION,
        input_ids=input_tensor_ids,
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("DEQUANTIZE")
def parse_dequantize(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a dequantization operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirDequantizeOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.DEQUANTIZE,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("EXPAND_DIMS")
def parse_expand_dims(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse an expand dimensions operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirExpandDimsOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.EXPAND_DIMS,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("FILL")
def parse_fill(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a fill operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.

    """
    op = subgraph.operators[id]

    # kDimsTensorIndex = 0
    kFillValueTensorIndex = 1
    kOutputTensorIndex = 0

    # dims_tensor_id = f"{op.inputs[kDimsTensorIndex]}"
    fill_tensor_id = f"{op.inputs[kFillValueTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirFillOptions()

    return AirOperator(
        id=str(id), op_type=AirOpType.FILL, input_ids=[fill_tensor_id], output_ids=[output_tensor_id], options=options
    )


@register_op_parser("FULLY_CONNECTED")
def parse_fully_connected(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a fully connected operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kWeightsTensorIndex = 1
    kBiasTensorIndex = 2
    kOutputTensorIndex = 0

    options = AirFullyConnectedOptions(
        activation=parse_activation_type(op.builtinOptions.fusedActivationFunction),
        weights_format=AirFullyConnectedWeightsFormat(op.builtinOptions.weightsFormat),
        keep_num_dims=op.builtinOptions.keepNumDims,
        asymmetric_quantize_inputs=op.builtinOptions.asymmetricQuantizeInputs,
        bias_tensor_type=parse_tensor_type(op.builtinOptions.quantizedBiasType),
    )

    input_ids = [f"{op.inputs[kInputTensorIndex]}"]
    named_tensors = dict(weights=f"{op.inputs[kWeightsTensorIndex]}")
    if (
        len(op.inputs) > kBiasTensorIndex
        and op.inputs[kBiasTensorIndex] is not None
        and op.inputs[kBiasTensorIndex] >= 0
    ):
        named_tensors["bias"] = f"{op.inputs[kBiasTensorIndex]}"
    output_ids = [f"{op.outputs[kOutputTensorIndex]}"]

    return AirOperator(
        id=str(id),
        op_type=AirOpType.FULLY_CONNECTED,
        input_ids=input_ids,
        output_ids=output_ids,
        named_tensors=named_tensors,
        options=options,
    )


@register_op_parser("HARD_SWISH")
def parse_hard_swish(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a hard swish operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirHardSwishOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.HARD_SWISH,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("LEAKY_RELU")
def parse_leaky_relu(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a leaky ReLU operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirLeakyReluOptions(alpha=op.builtinOptions.alpha)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.LEAKY_RELU,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("LOGISTIC")
def parse_logistic(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a logistic (sigmoid) operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirLogisticOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.LOGISTIC,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("MAX_POOL_2D")
def parse_max_pool_2d(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a 2D max pooling operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)

    options = AirMaxPool2DOptions(
        padding_height=compute_padding(
            in_size=int(input_tensor.shape[AirTensorDim.H]),
            filter_size=op.builtinOptions.filterHeight,
            stride=op.builtinOptions.strideH,
            dilation_rate=1,
            padding_type=op.builtinOptions.padding,
        ),
        padding_width=compute_padding(
            in_size=int(input_tensor.shape[AirTensorDim.W]),
            filter_size=op.builtinOptions.filterWidth,
            stride=op.builtinOptions.strideW,
            dilation_rate=1,
            padding_type=op.builtinOptions.padding,
        ),
        stride_height=op.builtinOptions.strideH,
        stride_width=op.builtinOptions.strideW,
        filter_height=op.builtinOptions.filterHeight,
        filter_width=op.builtinOptions.filterWidth,
        activation=parse_activation_type(op.builtinOptions.fusedActivationFunction),
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.MAX_POOL_2D,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("MAXIMUM")
def parse_maximum(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a maximum operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInput1TensorIndex = 0
    kInput2TensorIndex = 1
    kOutputTensorIndex = 0

    input1_tensor_id = f"{op.inputs[kInput1TensorIndex]}"
    input2_tensor_id = f"{op.inputs[kInput2TensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirMaximumOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.MAXIMUM,
        input_ids=[input1_tensor_id, input2_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("MEAN")
def parse_mean(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a MEAN operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kAxisTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    axis_tensor_id = f"{op.inputs[kAxisTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)
    axis_tensor = air_model.get_tensor(axis_tensor_id)
    output_tensor = air_model.get_tensor(output_tensor_id)

    axis = axis_tensor.data
    axis = [a + len(input_tensor.shape) if a < 0 else a for a in axis]

    if len(input_tensor.shape) > 4:
        raise ValueError("MEAN operator only supports 1D-4D tensors.")

    # Compute output dimensions
    axis_dims = [1 if i in axis else 0 for i in range(len(input_tensor.shape))]
    output_dims = tuple([1 if ax else input_tensor.shape[i] for i, ax in enumerate(axis_dims)])
    output_tensor.shape = output_dims

    axis = sorted(set(axis))

    options = AirMeanOptions(axis=axis)

    return AirOperator(
        id=str(id), op_type=AirOpType.MEAN, input_ids=[input_tensor_id], output_ids=[output_tensor_id], options=options
    )


@register_op_parser("SUM")
def parse_sum(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a sum operator."""

    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kAxisTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    axis_tensor_id = f"{op.inputs[kAxisTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)

    if len(input_tensor.shape) > 4:
        raise ValueError("SUM operator only supports 1D-4D tensors.")

    options = AirSumOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SUM,
        input_ids=[input_tensor_id, axis_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("MINIMUM")
def parse_minimum(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a minimum operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInput1TensorIndex = 0
    kInput2TensorIndex = 1
    kOutputTensorIndex = 0

    input1_tensor_id = f"{op.inputs[kInput1TensorIndex]}"
    input2_tensor_id = f"{op.inputs[kInput2TensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirMinimumOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.MINIMUM,
        input_ids=[input1_tensor_id, input2_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


def _parse_comparison_op(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
    comparison_type: AirComparisonType,
) -> AirOperator:
    """Parse a LiteRT comparison operator into an AIR operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.
        comparison_type (AirComparisonType): The type of comparison operation.
    """

    op = subgraph.operators[id]

    kInput1TensorIndex = 0
    kInput2TensorIndex = 1
    kOutputTensorIndex = 0

    input1_tensor_id = f"{op.inputs[kInput1TensorIndex]}"
    input2_tensor_id = f"{op.inputs[kInput2TensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirComparisonOptions(operation=comparison_type)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.COMPARISON,
        input_ids=[input1_tensor_id, input2_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("EQUAL")
def parse_equal(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    return _parse_comparison_op(
        id=id,
        model=model,
        subgraph=subgraph,
        air_model=air_model,
        comparison_type=AirComparisonType.EQUAL,
    )


@register_op_parser("NOT_EQUAL")
def parse_not_equal(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    return _parse_comparison_op(
        id=id,
        model=model,
        subgraph=subgraph,
        air_model=air_model,
        comparison_type=AirComparisonType.NOT_EQUAL,
    )


@register_op_parser("LESS")
def parse_less(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    return _parse_comparison_op(
        id=id,
        model=model,
        subgraph=subgraph,
        air_model=air_model,
        comparison_type=AirComparisonType.LESS,
    )


@register_op_parser("LESS_EQUAL")
def parse_less_equal(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    return _parse_comparison_op(
        id=id,
        model=model,
        subgraph=subgraph,
        air_model=air_model,
        comparison_type=AirComparisonType.LESS_EQUAL,
    )


@register_op_parser("GREATER")
def parse_greater(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    return _parse_comparison_op(
        id=id,
        model=model,
        subgraph=subgraph,
        air_model=air_model,
        comparison_type=AirComparisonType.GREATER,
    )


@register_op_parser("GREATER_EQUAL")
def parse_greater_equal(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    return _parse_comparison_op(
        id=id,
        model=model,
        subgraph=subgraph,
        air_model=air_model,
        comparison_type=AirComparisonType.GREATER_EQUAL,
    )


@register_op_parser("MUL")
def parse_mul(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a multiplication operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInput1TensorIndex = 0
    kInput2TensorIndex = 1
    kOutputTensorIndex = 0

    input1_tensor_id = f"{op.inputs[kInput1TensorIndex]}"
    input2_tensor_id = f"{op.inputs[kInput2TensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirMulOptions(activation=parse_activation_type(op.builtinOptions.fusedActivationFunction))

    return AirOperator(
        id=str(id),
        op_type=AirOpType.MUL,
        input_ids=[input1_tensor_id, input2_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("PACK")
def parse_pack(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a pack operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kOutputTensorIndex = 0

    input_tensor_ids = [f"{id}" for id in op.inputs]
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    output_tensor = air_model.get_tensor(output_tensor_id)

    options = AirPackOptions(values_count=op.builtinOptions.valuesCount, axis=op.builtinOptions.axis)

    if options.axis < 0:
        options.axis += len(output_tensor.shape)

    return AirOperator(
        id=str(id), op_type=AirOpType.PACK, input_ids=input_tensor_ids, output_ids=[output_tensor_id], options=options
    )


@register_op_parser("PAD")
@register_op_parser("PADV2")
def parse_pad(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a padding operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kPadTensorIndex = 1
    kOutputTensorIndex = 0
    kConstantValuesIndex = 2

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    pad_tensor_id = f"{op.inputs[kPadTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    pad_tensor = air_model.get_tensor(pad_tensor_id)
    pre_paddings = pad_tensor.data[:, 0].tolist()
    post_paddings = pad_tensor.data[:, 1].tolist()
    if len(pre_paddings) < 4:
        pre_paddings = [0] * (4 - len(pre_paddings)) + pre_paddings
    if len(post_paddings) < 4:
        post_paddings = [0] * (4 - len(post_paddings)) + post_paddings
    output_tensor = air_model.get_tensor(output_tensor_id)

    if len(op.inputs) > 2:
        const_id = f"{op.inputs[kConstantValuesIndex]}"
        constant_values_tensor = air_model.get_tensor(const_id)
        constant_value = constant_values_tensor.data[0]
    elif output_tensor.quantization:
        constant_value = output_tensor.quantization.zero_point[0]
    else:
        constant_value = 0

    options = AirPadOptions(pre_paddings=pre_paddings, post_paddings=post_paddings, constant_value=constant_value)

    return AirOperator(
        id=str(id), op_type=AirOpType.PAD, input_ids=[input_tensor_id], output_ids=[output_tensor_id], options=options
    )


@register_op_parser("QUANTIZE")
def parse_quantize(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a quantization operator.


    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirQuantizeOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.QUANTIZE,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("READ_VARIABLE")
def parse_read_variable(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a variable read operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    kResourceVariableIdx = 0
    kOutputTensorIdx = 0

    op = subgraph.operators[id]

    resource_tensor_id = f"{op.inputs[kResourceVariableIdx]}"
    read_tensor_id = f"{op.outputs[kOutputTensorIdx]}"

    resource_tensor = air_model.get_tensor(resource_tensor_id)
    read_tensor = air_model.get_tensor(read_tensor_id)

    # Set shape and dtype of resource tensor to match read tensor
    resource_tensor.shape = read_tensor.shape
    resource_tensor.dtype = read_tensor.dtype

    # Set init value based on quantization parameters if available
    if read_tensor.quantization and read_tensor.quantization.zero_point and len(read_tensor.quantization.zero_point) > 0:
        init_value = read_tensor.quantization.zero_point[0]
    else:
        init_value = 0

    options = AirReadVariableOptions(init_value=init_value)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.READ_VARIABLE,
        input_ids=[resource_tensor_id],
        output_ids=[read_tensor_id],
        options=options,
    )

@register_op_parser("REDUCE_MAX")
def parse_reduce_max(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a REDUCE_MAX operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kAxisTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"
    axis_tensor_id = f"{op.inputs[kAxisTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)
    output_tensor = air_model.get_tensor(output_tensor_id)
    axis_tensor = air_model.get_tensor(axis_tensor_id)

    axis = axis_tensor.data
    axis = [a + len(input_tensor.shape) if a < 0 else a for a in axis]

    if len(input_tensor.shape) > 4:
        raise ValueError("REDUCE_MAX operator only supports 1D-4D tensors.")

    # Compute output dimensions
    axis_dims = [1 if i in axis else 0 for i in range(len(input_tensor.shape))]
    output_dims = tuple([1 if ax else input_tensor.shape[i] for i, ax in enumerate(axis_dims)])
    output_tensor.shape = output_dims

    axis = sorted(set(axis))

    options = AirReduceMaxOptions(axis=axis)

    return AirOperator(
        id=str(id), op_type=AirOpType.REDUCE_MAX, input_ids=[input_tensor_id], output_ids=[output_tensor_id], options=options
    )

@register_op_parser("REDUCE_MIN")
def parse_reduce_min(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a REDUCE_MIN operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kAxisTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    axis_tensor_id = f"{op.inputs[kAxisTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)
    axis_tensor = air_model.get_tensor(axis_tensor_id)
    output_tensor = air_model.get_tensor(output_tensor_id)

    axis = axis_tensor.data
    axis = [a + len(input_tensor.shape) if a < 0 else a for a in axis]

    if len(input_tensor.shape) > 4:
        raise ValueError("REDUCE_MIN operator only supports 1D-4D tensors.")
    
    # Compute output dimensions
    axis_dims = [1 if i in axis else 0 for i in range(len(input_tensor.shape))]
    output_dims = tuple([1 if ax else input_tensor.shape[i] for i, ax in enumerate(axis_dims)])
    output_tensor.shape = output_dims

    axis = sorted(set(axis))

    options = AirReduceMinOptions(axis=axis)

    return AirOperator(
        id=str(id), op_type=AirOpType.REDUCE_MIN, input_ids=[input_tensor_id], output_ids=[output_tensor_id], options=options
    )


@register_op_parser("ARG_MAX")
def parse_arg_max(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse an ARG_MAX operator."""

    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kAxisTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    axis_tensor_id = f"{op.inputs[kAxisTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)
    axis_tensor = air_model.get_tensor(axis_tensor_id)
    output_tensor = air_model.get_tensor(output_tensor_id)

    if axis_tensor.data is None:
        raise ValueError("ARG_MAX requires a constant axis tensor.")

    axis_values = np.array(axis_tensor.data).astype(np.int32).flatten()
    if axis_values.size != 1:
        raise ValueError("ARG_MAX axis tensor must contain exactly one value.")

    axis = int(axis_values[0])
    rank = len(input_tensor.shape)
    if axis < 0:
        axis += rank
    if axis < 0 or axis >= rank:
        raise ValueError(f"ARG_MAX axis {axis} out of range for rank {rank}.")
    if rank > 4:
        raise ValueError("ARG_MAX operator only supports tensors with rank <= 4.")

    dim_pad = max(0, 4 - rank)
    axis_padded = axis + dim_pad

    output_shape = list(int(dim) for dim in output_tensor.shape) or [1]
    output_tensor.shape = tuple(output_shape)

    if output_tensor.dtype != np.int32:
        raise ValueError("ARG_MAX output tensor must be int32.")

    options = AirArgMaxOptions(axis=axis_padded)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.ARG_MAX,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("ARG_MIN")
def parse_arg_min(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse an ARG_MIN operator."""

    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kAxisTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    axis_tensor_id = f"{op.inputs[kAxisTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)
    axis_tensor = air_model.get_tensor(axis_tensor_id)
    output_tensor = air_model.get_tensor(output_tensor_id)

    if axis_tensor.data is None:
        raise ValueError("ARG_MIN requires a constant axis tensor.")

    axis_values = np.array(axis_tensor.data).astype(np.int32).flatten()
    if axis_values.size != 1:
        raise ValueError("ARG_MIN axis tensor must contain exactly one value.")

    axis = int(axis_values[0])
    rank = len(input_tensor.shape)
    if axis < 0:
        axis += rank
    if axis < 0 or axis >= rank:
        raise ValueError(f"ARG_MIN axis {axis} out of range for rank {rank}.")
    if rank > 4:
        raise ValueError("ARG_MIN operator only supports tensors with rank <= 4.")

    dim_pad = max(0, 4 - rank)
    axis_padded = axis + dim_pad

    output_shape = list(int(dim) for dim in output_tensor.shape) or [1]
    output_tensor.shape = tuple(output_shape)

    if output_tensor.dtype != np.int32:
        raise ValueError("ARG_MIN output tensor must be int32.")

    options = AirArgMinOptions(axis=axis_padded)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.ARG_MIN,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )

@register_op_parser("RELU_N1_TO_1")
@register_op_parser("RELU_0_TO_1")
@register_op_parser("RELU6")
@register_op_parser("RELU")
def parse_relu(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a ReLU operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    input_tensor_id = f"{op.inputs[0]}"
    output_tensor_id = f"{op.outputs[0]}"

    builtin_code = get_builtin_code(model.operatorCodes[op.opcodeIndex])
    relu_type = AirReluType.RELU
    if builtin_code == litert.BuiltinOperator.RELU6:
        relu_type = AirReluType.RELU6
    elif builtin_code == litert.BuiltinOperator.RELU_N1_TO_1:
        relu_type = AirReluType.RELU_N1_TO_1
    elif builtin_code == litert.BuiltinOperator.RELU_0_TO_1:
        relu_type = AirReluType.RELU_0_TO_1
    elif builtin_code == litert.BuiltinOperator.RELU:
        relu_type = AirReluType.RELU
    else:
        raise ValueError(f"Unsupported activation function: {builtin_code}")

    options = AirReluOptions(relu_type=relu_type)

    return AirOperator(
        id=str(id), op_type=AirOpType.RELU, input_ids=[input_tensor_id], output_ids=[output_tensor_id], options=options
    )


@register_op_parser("RESHAPE")
def parse_reshape(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a reshape operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirReshapeOptions(new_shape=getattr(op.builtinOptions, "newShape", []))

    return AirOperator(
        id=str(id),
        op_type=AirOpType.RESHAPE,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("SHAPE")
def parse_shape(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a shape operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirShapeOptions(out_type=op.builtinOptions.outType)

    return AirOperator(
        id=str(id), op_type=AirOpType.SHAPE, input_ids=[input_tensor_id], output_ids=[output_tensor_id], options=options
    )


@register_op_parser("SOFTMAX")
def parse_softmax(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a softmax operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirSoftmaxOptions(beta=op.builtinOptions.beta)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SOFTMAX,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )

@register_op_parser("SPACE_TO_BATCH_ND")
def parse_space_to_batch_nd(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a space to batch operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.

    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kBlockShapeTensorIndex = 1
    kPaddingsTensorIndex = 2
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    block_shape_tensor_id = f"{op.inputs[kBlockShapeTensorIndex]}"
    paddings_tensor_id = f"{op.inputs[kPaddingsTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    input_tensor = air_model.get_tensor(input_tensor_id)
    if input_tensor.ndim not in (3, 4):
        raise ValueError("Input tensor for SPACE_TO_BATCH_ND must be 3D or 4D.")

    output_tensor = air_model.get_tensor(output_tensor_id)
    if output_tensor.ndim not in (3, 4):
        raise ValueError("Output tensor for SPACE_TO_BATCH_ND must be 3D or 4D.")

    block_shape_tensor = air_model.get_tensor(block_shape_tensor_id)
    if len(block_shape_tensor.data) == 1:
        block_shape = (block_shape_tensor.data[0], 1)
    elif len(block_shape_tensor.data) == 2:
        block_shape = (block_shape_tensor.data[0], block_shape_tensor.data[1])
    else:
        raise ValueError("Block shape tensor for SPACE_TO_BATCH_ND must be of size 1 or 2.")

    paddings_tensor = air_model.get_tensor(paddings_tensor_id)
    if paddings_tensor.ndim == 1:
        paddings_tensor.shape = (1,) + paddings_tensor.shape
    if paddings_tensor.shape[0] > 2:
        raise ValueError("Paddings tensor for SPACE_TO_BATCH_ND must be of shape (1, 2) or (2, 2).")
    paddings = AirSpatialPad(
        top=paddings_tensor.data[0, 0],
        bottom=paddings_tensor.data[0, 1],
        left=0 if paddings_tensor.shape[0] == 1 else paddings_tensor.data[1, 0],
        right=0 if paddings_tensor.shape[0] == 1 else paddings_tensor.data[1, 1]
    )

    options = AirSpaceToBatchNDOptions(
        block_shape=block_shape,
        paddings=paddings,
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SPACE_TO_BATCH_ND,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options
    )

@register_op_parser("SPACE_TO_DEPTH")
def parse_space_to_depth(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a space to depth operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.

    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirSpaceToDepthOptions(
        block_size=int(op.builtinOptions.blockSize)
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SPACE_TO_DEPTH,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options
    )

@register_op_parser("SPLIT")
def parse_split(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a split operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kAxisTensorIndex = 0
    kInputTensorIndex = 1

    axis_tensor_id = f"{op.inputs[kAxisTensorIndex]}"
    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_ids = [f"{id}" for id in op.outputs]

    input_tensor = air_model.get_tensor(input_tensor_id)
    axis_tensor = air_model.get_tensor(axis_tensor_id)
    axis = int(axis_tensor.data.item())
    if axis < 0:
        axis += len(input_tensor.shape)

    split_length = input_tensor.shape[axis] // len(op.outputs)
    split_lengths = [split_length] * len(op.outputs)

    options = AirSplitOptions(axis=axis, split_lengths=split_lengths)

    return AirOperator(
        id=str(id), op_type=AirOpType.SPLIT, input_ids=[input_tensor_id], output_ids=output_tensor_ids, options=options
    )


@register_op_parser("SPLIT_V")
def parse_split_v(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a split_v operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kSplitTensorIndex = 1
    kAxisTensorIndex = 2

    axis_tensor_id = f"{op.inputs[kAxisTensorIndex]}"
    split_tensor_id = f"{op.inputs[kSplitTensorIndex]}"
    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_ids = [f"{id}" for id in op.outputs]

    input_tensor = air_model.get_tensor(input_tensor_id)
    axis_tensor = air_model.get_tensor(axis_tensor_id)
    axis = int(axis_tensor.data.item())
    if axis < 0:
        axis += len(input_tensor.shape)

    split_tensor = air_model.get_tensor(split_tensor_id)
    split_lengths = split_tensor.data.tolist()
    if split_lengths.count(-1) > 1:
        raise ValueError("SPLIT_V size_splits may contain at most one -1 sentinel.")
    if -1 in split_lengths:
        input_axis_size = int(input_tensor.shape[axis])
        known_total = sum(int(length) for length in split_lengths if int(length) >= 0)
        inferred_length = input_axis_size - known_total
        if inferred_length < 0:
            raise ValueError(
                f"SPLIT_V inferred split length is negative: input axis size {input_axis_size}, known total {known_total}."
            )
        split_lengths = [inferred_length if int(length) == -1 else int(length) for length in split_lengths]

    options = AirSplitOptions(axis=axis, split_lengths=split_lengths)

    return AirOperator(
        id=str(id), op_type=AirOpType.SPLIT, input_ids=[input_tensor_id], output_ids=output_tensor_ids, options=options
    )


@register_op_parser("SQUEEZE")
def parse_squeeze(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a squeeze operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirSqueezeOptions(squeeze_dims=op.builtinOptions.squeezeDims)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SQUEEZE,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("SLICE")
def parse_slice(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a slice operator."""

    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kBeginTensorIndex = 1
    kSizeTensorIndex = 2
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    begin_tensor_id = f"{op.inputs[kBeginTensorIndex]}"
    size_tensor_id = f"{op.inputs[kSizeTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    begin_tensor = air_model.get_tensor(begin_tensor_id)
    size_tensor = air_model.get_tensor(size_tensor_id)

    if begin_tensor.data is None or size_tensor.data is None:
        raise ValueError("Slice operator requires constant begin and size tensors.")

    begin = [int(v) for v in begin_tensor.data.tolist()]
    size = [int(v) for v in size_tensor.data.tolist()]

    if len(begin) != len(size):
        raise ValueError("Slice begin and size tensors must have the same length.")

    options = AirSliceOptions(
        begin=tuple(begin),
        size=tuple(size),
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SLICE,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("STRIDED_SLICE")
def parse_strided_slice(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a strided slice operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kBeginTensorIndex = 1
    kEndTensorIndex = 2
    kStridesTensorIndex = 3
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    begin_tensor_id = f"{op.inputs[kBeginTensorIndex]}"
    end_tensor_id = f"{op.inputs[kEndTensorIndex]}"
    strides_tensor_id = f"{op.inputs[kStridesTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    begin = air_model.get_tensor(begin_tensor_id).data.tolist()
    end = air_model.get_tensor(end_tensor_id).data.tolist()
    strides = air_model.get_tensor(strides_tensor_id).data.tolist()

    options = AirStridedSliceOptions(
        begin=tuple(begin),
        end=tuple(end),
        stride=tuple(strides),
        begin_mask=op.builtinOptions.beginMask,
        end_mask=op.builtinOptions.endMask,
        ellipsis_mask=op.builtinOptions.ellipsisMask,
        new_axis_mask=op.builtinOptions.newAxisMask,
        shrink_axis_mask=op.builtinOptions.shrinkAxisMask,
        offset=op.builtinOptions.offset,
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.STRIDED_SLICE,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("GATHER")
def parse_gather(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a gather operator."""

    op = subgraph.operators[id]

    if len(op.inputs) < 2:
        raise ValueError("Gather operator expects 2 inputs (input and indices).")

    input_tensor_id = f"{op.inputs[0]}"
    indices_tensor_id = f"{op.inputs[1]}"
    output_tensor_id = f"{op.outputs[0]}"

    input_tensor_litert = subgraph.tensors[op.inputs[0]]
    indices_tensor_litert = subgraph.tensors[op.inputs[1]]
    output_tensor_litert = subgraph.tensors[op.outputs[0]]

    input_shape = _get_static_shape(input_tensor_litert, name="Gather input", min_rank=1)
    indices_shape = _get_static_shape(indices_tensor_litert, name="Gather indices", min_rank=1)
    output_shape = _get_static_shape(output_tensor_litert, name="Gather output", min_rank=0)

    options_fb = op.builtinOptions
    if options_fb is None:
        raise ValueError("Gather operator missing builtin options.")

    axis = options_fb.axis
    input_rank = len(input_shape)
    if axis < 0:
        axis += input_rank
    if axis < 0 or axis >= input_rank:
        raise ValueError(f"Gather axis {options_fb.axis} is out of range for rank {input_rank}.")

    batch_dims = options_fb.batchDims
    coords_rank = len(indices_shape)
    if batch_dims < 0:
        batch_dims += coords_rank
    if batch_dims < 0 or batch_dims > coords_rank:
        raise ValueError(f"Gather batch_dims {options_fb.batchDims} incompatible with indices rank {coords_rank}.")
    if batch_dims > axis:
        raise ValueError("Gather batch_dims must be <= axis.")
    if batch_dims >= input_rank:
        raise ValueError("Gather batch_dims must be < input rank.")

    input_tensor = air_model.get_tensor(input_tensor_id)
    indices_tensor = air_model.get_tensor(indices_tensor_id)
    output_tensor = air_model.get_tensor(output_tensor_id)

    if input_tensor.dtype not in (np.int8, np.int16):
        raise ValueError("Gather only supports int8 or int16 input tensors.")
    if indices_tensor.dtype != np.int32:
        raise ValueError("Gather only supports int32 indices tensors.")
    if output_tensor.dtype != input_tensor.dtype:
        raise ValueError("Gather output dtype must match input dtype.")

    options = AirGatherOptions(
        axis=axis,
        batch_dims=batch_dims,
        input_shape=input_shape,
        indices_shape=indices_shape,
        output_shape=output_shape,
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.GATHER,
        input_ids=[input_tensor_id, indices_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("GATHER_ND")
def parse_gather_nd(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a gather_nd operator."""

    op = subgraph.operators[id]

    if len(op.inputs) < 2:
        raise ValueError("GatherNd operator expects 2 inputs (params and indices).")

    params_tensor_id = f"{op.inputs[0]}"
    indices_tensor_id = f"{op.inputs[1]}"
    output_tensor_id = f"{op.outputs[0]}"

    params_tensor_litert = subgraph.tensors[op.inputs[0]]
    indices_tensor_litert = subgraph.tensors[op.inputs[1]]
    output_tensor_litert = subgraph.tensors[op.outputs[0]]

    params_shape = _get_static_shape(params_tensor_litert, name="GatherNd params", min_rank=1)
    indices_shape = _get_static_shape(indices_tensor_litert, name="GatherNd indices", min_rank=1)
    output_shape = _get_static_shape(output_tensor_litert, name="GatherNd output", min_rank=0)

    indices_nd = indices_shape[-1]
    if indices_nd <= 0:
        raise ValueError("GatherNd indices last dimension must be > 0.")

    params_tensor = air_model.get_tensor(params_tensor_id)
    indices_tensor = air_model.get_tensor(indices_tensor_id)
    output_tensor = air_model.get_tensor(output_tensor_id)

    if params_tensor.dtype not in (np.int8, np.int16):
        raise ValueError("GatherNd only supports int8 or int16 params tensors.")
    if indices_tensor.dtype != np.int32:
        raise ValueError("GatherNd only supports int32 indices tensors.")
    if output_tensor.dtype != params_tensor.dtype:
        raise ValueError("GatherNd output dtype must match params dtype.")

    options = AirGatherNdOptions(
        params_shape=params_shape,
        indices_shape=indices_shape,
        output_shape=output_shape,
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.GATHER_ND,
        input_ids=[params_tensor_id, indices_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("TANH")
def parse_tanh(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a tanh operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirTanhOptions()

    return AirOperator(
        id=str(id), op_type=AirOpType.TANH, input_ids=[input_tensor_id], output_ids=[output_tensor_id], options=options
    )


@register_op_parser("ETHOS_U")
def parse_ethos_u(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse an Ethos-U custom operator."""

    op = subgraph.operators[id]
    if len(op.inputs) == 0:
        raise ValueError("ETHOS_U operator must have at least one input tensor (command stream).")

    command_stream_index = op.inputs[0]
    command_stream_tensor = subgraph.tensors[command_stream_index]
    command_stream_size = 0
    if command_stream_tensor.buffer >= 0:
        buffer = model.buffers[command_stream_tensor.buffer]
        if buffer.data is not None:
            command_stream_size = len(buffer.data)
    if command_stream_size == 0:
        size = 1
        shape = command_stream_tensor.shape or []
        for dim in shape:
            size *= dim
        command_stream_size = int(size)

    raw_custom_options = getattr(op, "customOptions", None)
    if raw_custom_options is not None:
        if hasattr(raw_custom_options, "tolist"):
            custom_options = tuple(int(v) for v in raw_custom_options.tolist())
        else:
            custom_options = tuple(int(v) for v in raw_custom_options)
    else:
        custom_options = tuple()
    co_type = custom_options[0] if custom_options else 0
    custom_options_format = int(getattr(op, "customOptionsFormat", 0) or 0)

    graph_inputs = set(subgraph.inputs)
    runtime_input_ids: list[str] = []
    named_tensors: dict[str, str] = {"command_stream": f"{command_stream_index}"}

    auxiliary_keys = ["model", "arena", "scratch_fast"]
    aux_index = 0
    for position, tensor_index in enumerate(op.inputs[1:], start=1):
        tensor_id_str = f"{tensor_index}"
        if tensor_index in graph_inputs:
            runtime_input_ids.append(tensor_id_str)
            continue
        if aux_index < len(auxiliary_keys):
            key = auxiliary_keys[aux_index]
            aux_index += 1
        else:
            key = f"extra_{position}"
        if key in named_tensors:
            key = f"{key}_{position}"
        named_tensors[key] = tensor_id_str

    auxiliary_count = max(len(named_tensors) - 1, 0)
    total_inputs = len(runtime_input_ids)

    options = AirEthosUOptions(
        co_type=co_type,
        command_stream_size=command_stream_size,
        num_base_addresses=auxiliary_count + total_inputs + len(op.outputs),
        custom_options_format=custom_options_format,
        custom_options=custom_options,
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.ETHOS_U,
        input_ids=runtime_input_ids,
        output_ids=[f"{tensor_id}" for tensor_id in op.outputs],
        named_tensors=named_tensors,
        options=options,
    )


@register_op_parser("TRANSPOSE")
def parse_transpose(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a transpose operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kPermTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    perm_tensor_id = f"{op.inputs[kPermTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    perm_tensor = air_model.get_tensor(perm_tensor_id)
    permutations = perm_tensor.data.tolist()

    options = AirTransposeOptions(permutations=permutations)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.TRANSPOSE,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("REVERSE_V2")
def parse_reverse_v2(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a REVERSE_V2 operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kAxesTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    axes_tensor_id = f"{op.inputs[kAxesTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    axes_tensor = air_model.get_tensor(axes_tensor_id)
    if axes_tensor.data is None:
        raise ValueError("REVERSE_V2 requires a constant axes tensor.")

    raw_axes = np.asarray(axes_tensor.data).reshape(-1).tolist()
    axes = [int(axis) for axis in raw_axes]

    options = AirReverseV2Options(axes=axes)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.REVERSE_V2,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("UNPACK")
def parse_unpack(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse an unpack operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_ids = [f"{id}" for id in op.outputs]

    input_tensor = air_model.get_tensor(input_tensor_id)

    options = AirUnpackOptions(num=op.builtinOptions.num, axis=op.builtinOptions.axis)

    if options.axis < 0:
        options.axis += len(input_tensor.shape)

    return AirOperator(
        id=str(id), op_type=AirOpType.UNPACK, input_ids=[input_tensor_id], output_ids=output_tensor_ids, options=options
    )


@register_op_parser("ZEROS_LIKE")
def parse_zeros_like(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a zeros_like operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kOutputTensorIndex = 0

    # Get the output zero-point if quantized
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"
    output_tensor = air_model.get_tensor(output_tensor_id)
    if output_tensor.quantization:
        zero_point = output_tensor.quantization.zero_point[0]
    else:
        zero_point = 0
    options = AirZerosLikeOptions(zero_point=zero_point)

    return AirOperator(
        id=str(id),
        op_type=AirOpType.ZEROS_LIKE,
        # INPUT
        input_ids=[f"{id}" for id in op.inputs],
        # OUTPUT
        output_ids=[f"{id}" for id in op.outputs],
        options=options,
    )

@register_op_parser("SVDF")
def parse_svdf(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse an SVDF operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    kInputTensorIndex = 0
    kWeightsFeatureTensorIndex = 1
    kWeightsTimeTensorIndex = 2
    kBiasTensorIndex = 3
    kActivationStateTensorIndex = 4
    kOutputTensorIndex = 0

    op = subgraph.operators[id]

    # TFLM ignores fused activation function for SVDF
    options = AirSvdfOptions(
        rank=op.builtinOptions.rank,
        asymmetric_quantize_inputs=op.builtinOptions.asymmetricQuantizeInputs,
    )

    input_ids = [f"{op.inputs[kInputTensorIndex]}"]
    named_tensors = dict(
        weights_feature=f"{op.inputs[kWeightsFeatureTensorIndex]}",
        weights_time=f"{op.inputs[kWeightsTimeTensorIndex]}",
        state=f"{op.inputs[kActivationStateTensorIndex]}"
    )
    if (
        len(op.inputs) > kBiasTensorIndex
        and op.inputs[kBiasTensorIndex] is not None
        and op.inputs[kBiasTensorIndex] >= 0
    ):
        named_tensors["bias"] = f"{op.inputs[kBiasTensorIndex]}"
    output_ids = [f"{op.outputs[kOutputTensorIndex]}"]

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SVDF,
        input_ids=input_ids,
        output_ids=output_ids,
        named_tensors=named_tensors,
        options=options,
    )

@register_op_parser("PRELU")
def parse_prelu(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a PReLU operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kAlphaTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    alpha_tensor_id = f"{op.inputs[kAlphaTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    named_tensors = dict(
        alpha=alpha_tensor_id
    )
    options = AirPreluOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.PRELU,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        named_tensors=named_tensors,
        options=options
    )
@register_op_parser("RESIZE_NEAREST_NEIGHBOR")
def parse_resize_nearest_neighbor(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a Resize Nearest Neighbor operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kSizeTensorIndex = 1
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    size_tensor_id = f"{op.inputs[kSizeTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    named_tensors = dict(
        size=size_tensor_id
    )
    options = AirResizeNearestNeighborOptions(
        align_corners=op.builtinOptions.alignCorners,
        half_pixel_centers=op.builtinOptions.halfPixelCenters,
    )

    return AirOperator(
        id=str(id),
        op_type=AirOpType.RESIZE_NEAREST_NEIGHBOR,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        named_tensors=named_tensors,
        options=options
    )

@register_op_parser("ABS")
def parse_abs(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse an absolute value operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirAbsOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.ABS,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options
    )

@register_op_parser("SQRT")
def parse_sqrt(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a square-root operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirSqrtOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.SQRT,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )


@register_op_parser("RSQRT")
def parse_rsqrt(
    id: int,
    model: litert.ModelT,
    subgraph: litert.SubGraphT,
    air_model: AirModel,
) -> AirOperator:
    """Parse a reciprocal square-root operator.

    Args:
        id (int): The operator ID.
        model (litert.ModelT): The LiteRT model.
        subgraph (litert.SubGraphT): The LiteRT subgraph.
        air_model (AirModel): The AIR model.

    Returns:
        AirOperator: The parsed AIR operator.
    """
    op = subgraph.operators[id]

    kInputTensorIndex = 0
    kOutputTensorIndex = 0

    input_tensor_id = f"{op.inputs[kInputTensorIndex]}"
    output_tensor_id = f"{op.outputs[kOutputTensorIndex]}"

    options = AirRsqrtOptions()

    return AirOperator(
        id=str(id),
        op_type=AirOpType.RSQRT,
        input_ids=[input_tensor_id],
        output_ids=[output_tensor_id],
        options=options,
    )
