import numpy as np
from helia_aot.litert import schema_py_generated as litert

from helia_aot.air import (
    AirTensorKind,
    AirTensor,
    AirQuantizationParameters,
    AirBlockwiseQuantization,
    AirSparsityParameters,
    AirDimensionMetaData,
)

from .utils import get_tensor_dtype, load_tensor_data


def parse_blockwise_quantization(details: litert.BlockwiseQuantizationT) -> AirBlockwiseQuantization:
    """Create AirBlockwiseQuantization from LiteRT BlockwiseQuantizationT."""
    return AirBlockwiseQuantization(
        scales=details.scales,
        zero_points=details.zeroPoints,
        block_size=details.blockSize,
    )


def parse_dimension_meta_data(meta: litert.DimensionMetadataT) -> AirDimensionMetaData:
    """Create AirDimensionMetaData from LiteRT DimensionMetadataT."""
    return AirDimensionMetaData(
        format=meta.format,
        dense_size=meta.denseSize,
        array_segments_type=meta.arraySegmentsType,
        array_segments=meta.arraySegments.values.tolist() if meta.arraySegments else None,
        array_indices_type=meta.arrayIndicesType,
        array_indices=meta.arrayIndices.values.tolist() if meta.arrayIndices else None,
    )


def parse_sparsity(sparsity: litert.SparsityParametersT | None) -> AirSparsityParameters | None:
    """Create sparsity parameters from LiteRT SparsityParametersT."""
    if sparsity is None:
        return None

    return AirSparsityParameters(
        traversal_order=(
            np.array(sparsity.traversalOrder).tolist() if sparsity.traversalOrder is not None else None),
        block_map=(
            np.array(sparsity.blockMap).tolist() if sparsity.blockMap is not None else None),
        dim_meta_data=(
            [parse_dimension_meta_data(meta) for meta in sparsity.dimMetadata] if sparsity.dimMetadata else None),
    )

def parse_quantization_parameters(quantization: litert.QuantizationParametersT) -> AirQuantizationParameters | None:
    """Create quantization parameters from LiteRT QuantizationParametersT."""
    if quantization is None:
        return None
    details = None
    if isinstance(quantization.details, litert.BlockwiseQuantizationT):
        details = parse_blockwise_quantization(quantization.details)
    return AirQuantizationParameters(
        min=np.array(quantization.min) if quantization.min is not None else None,
        max=np.array(quantization.max) if quantization.max is not None else None,
        scale=np.array(quantization.scale) if quantization.scale is not None and len(quantization.scale) > 0 else None,
        zero_point=np.array(quantization.zeroPoint)
        if quantization.zeroPoint is not None and len(quantization.zeroPoint) > 0
        else None,
        details_type=quantization.detailsType,
        details=details,
        quantization_dimension=quantization.quantizedDimension,
    )


def parse_tensor(id: int, tensor: litert.TensorT, model: litert.ModelT, subgraph: litert.SubGraphT) -> AirTensor:
    """Create an AirTensor from a LiteRT Tensor."""

    id = int(id)
    data = load_tensor_data(tensor, model)

    if tensor.isVariable or tensor.type == litert.TensorType.RESOURCE:
        kind = AirTensorKind.PERSISTENT
    elif data is not None:
        kind = AirTensorKind.CONSTANT
    else:
        kind = AirTensorKind.SCRATCH

    # If no data, set dtype and shape from tensor info
    if data is None:
        dtype = get_tensor_dtype(tensor)
        if tensor.shape is not None:
            shape = tuple(tensor.shape.tolist())
        elif tensor.hasRank:
            # Resource variables with no shape but hasRank=True: use (0,) as
            # placeholder — READ_VARIABLE / ASSIGN_VARIABLE op parsers will
            # overwrite it before code generation.
            shape = (0,)
        else:
            # Unranked intermediate tensors (e.g. requantized scalars emitted
            # by the TFLite converter) should be treated as true scalars so
            # that get_shape_nhwc() pads to (1,1,1,1) instead of (1,1,1,0).
            shape = ()

    else:
        dtype = data.dtype
        shape = data.shape

    air_tensor = AirTensor(
        id=str(id),
        kind=kind,
        shape=shape,
        dtype=dtype,
        data=data,
        buffer_index=tensor.buffer,
        local_name=tensor.name,
        quantization=parse_quantization_parameters(tensor.quantization),
        sparsity=parse_sparsity(tensor.sparsity),
        shape_signature=tensor.shapeSignature,
        has_rank=tensor.hasRank,
    )

    return air_tensor
