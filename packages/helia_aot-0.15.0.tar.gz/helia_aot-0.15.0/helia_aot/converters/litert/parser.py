from pathlib import Path
from helia_aot.litert import schema_py_generated as litert

from helia_aot.air import AirModel
from helia_aot.air.op_keys import custom_code_to_op_key
from .op_parsers import get_op_parser
from .tensor_parser import parse_tensor
from .utils import get_builtin_code, BuiltinOperatorMap
from helia_aot.utils import setup_logger
from helia_aot.registry.context import RegistryContext

logger = setup_logger(log_name=__name__)


def air_model_from_litert(
    model_path: Path,
    registry_context: RegistryContext,
    subgraph_index: int = 0,
    verbose: int = 1,
) -> AirModel:
    """Create an AirModel from a LiteRT model.

    Args:
        model_path (Path): Path to the LiteRT model file.
        subgraph_index (int, optional): Index of the subgraph to use. Defaults to 0.
        verbose (int, optional): Verbosity level. Defaults to 1.

    Returns:
        AirModel: The AirModel.
    """

    if not model_path.exists():
        raise FileNotFoundError(f"Model file {model_path} does not exist.")

    global_ignore_operators = [
        litert.BuiltinOperator.CALL_ONCE,
        litert.BuiltinOperator.CALL,
        litert.BuiltinOperator.VAR_HANDLE,
    ]

    # 1. Load the model
    with open(model_path, "rb") as fp:
        model_content = fp.read()
    model: litert.ModelT = litert.ModelT.InitFromObj(litert.Model.GetRootAsModel(model_content))
    if subgraph_index < 0 or subgraph_index >= len(model.subgraphs):
        raise ValueError(
            f"Subgraph index {subgraph_index} is out of range. Model has {len(model.subgraphs)} subgraphs."
        )
    subgraph = model.subgraphs[subgraph_index]

    # 2. Create the AirModel
    air_model = AirModel(
        name=subgraph.name,
        version=f"{model.version}",
        description=model.description.decode("utf-8") if model.description else "",
    )

    # 3. Parse tensors
    for tensor_id, tensor in enumerate(subgraph.tensors):
        if tensor_id < 0:
            continue
        air_model.add_tensor(parse_tensor(tensor_id, tensor, model, subgraph))

    # 4. Record inputs and outputs
    air_model.input_ids = [str(tensor_id) for tensor_id in subgraph.inputs]
    air_model.output_ids = [str(tensor_id) for tensor_id in subgraph.outputs]

    # 5. Parse operators
    for op_id, op in enumerate(subgraph.operators):
        op_code = model.operatorCodes[op.opcodeIndex]
        custom_code = getattr(op_code, "customCode", None)
        if custom_code not in (None, b""):
            op_name = custom_code_to_op_key(custom_code)
        else:
            builtin_code = get_builtin_code(op_code)
            if builtin_code in global_ignore_operators:
                continue
            op_name = BuiltinOperatorMap.get(builtin_code, "UNKNOWN")
        op_parser = get_op_parser(registry_context.litert_parsers, op_name)
        if op_parser is None:
            raise ValueError(f"Operator {op_id} {op_name} is not registered in the parser")

        operator = op_parser(op_id, model, subgraph, air_model)
        air_model.add_operator(operator)
    # END FOR

    return air_model
