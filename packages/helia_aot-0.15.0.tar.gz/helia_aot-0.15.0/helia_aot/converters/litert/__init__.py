"""

#  :simple-tensorflow: LiteRT Converter API

This module is responsible for converting LiteRT (TFLite) model to AIR model


Copyright 2025 Ambiq. All Rights Reserved.

"""

from pathlib import Path
from typing import TYPE_CHECKING, Any

from helia_aot.air import AirModel

if TYPE_CHECKING:
    from helia_aot.registry.context import RegistryContext
else:
    RegistryContext = Any


def air_model_from_litert(
    model_path: Path,
    registry_context: RegistryContext,
    subgraph_index: int = 0,
    verbose: int = 1,
) -> AirModel:
    from .parser import air_model_from_litert as _impl

    return _impl(model_path, registry_context, subgraph_index, verbose)
