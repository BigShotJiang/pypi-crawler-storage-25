"""

# :material-autorenew: heliaAOT Converters API

This module is responsible for converting different front-ends to back-end AIR format

## Available Converters

- **[LiteRT](./litert)**: LiteRT (TFLite) flatbuffers

Copyright 2025 Ambiq. All Rights Reserved.

"""

from pathlib import Path
from helia_aot.air import AirModel
from helia_aot.registry.context import RegistryContext


def convert_backend_model(
    model_path: Path,
    registry_context: RegistryContext,
    subgraph: int = 0,
    type: str | None = None,
    verbose: int = 1,
) -> AirModel:
    """Load an AIR Model from a file of given front-end.

    Args:
        model_path (Path): Path to model file
        subgraph (int): Specific subgraph to load. Defaults to 0.
        type (str): Front-end type. If not given will infer from path extension
        verbose (int): Verbosity level. Defaults to 1.

    Returns:
        AirModel: The converted AIR model.
    """

    if type is None:
        type = model_path.suffix.lower().replace(".", "")

    if type not in ["tflite", "litert"]:
        raise ValueError(f"Unsupported model type: {type}. Supported types are 'tflite' and 'litert'.")

    # Check if the model file exists
    if not model_path.exists():
        raise FileNotFoundError(f"Model file {model_path} does not exist.")

    # Check if the file is LiteRT model
    if type in ["tflite", "litert"]:
        from . import litert  # noqa: E402

        model = litert.air_model_from_litert(model_path, registry_context, subgraph, verbose)

    else:
        raise ValueError(f"Unsupported model type: {type}. Supported types are 'tflite' and 'litert'.")

    if verbose >= 2:
        for operator in model.operators:
            operator.print_info(verbose=verbose)

    return model
