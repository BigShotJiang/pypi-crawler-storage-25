"""TALISMAN module."""
