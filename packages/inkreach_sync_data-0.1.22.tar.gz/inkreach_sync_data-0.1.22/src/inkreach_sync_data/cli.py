import click

from inkreach_sync_data.commands.sds import cli as sds_cli


@click.group()
def cli():
    """Sync Data 命令行工具"""
    pass


cli.add_command(sds_cli)
