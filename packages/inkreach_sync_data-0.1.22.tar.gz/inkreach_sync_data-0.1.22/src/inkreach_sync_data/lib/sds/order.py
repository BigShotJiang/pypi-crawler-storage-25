import os
import json
import asyncio
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed
from sds_mng.order.fetch_orders_async import fetch_orders
from sds_mng.exception import UnauthorizedError
from aiohttp import ClientError
from inkreach_sync_data.lib.sds.token import maybe_refresh_token
from inkreach_sync_data.lib.sds.product import update_sds_products_file
from inkreach_sync_data.lib.sds.logistics import update_sds_logistics_file


@retry(
    stop=stop_after_attempt(3),
    wait=wait_fixed(2),
    retry=retry_if_exception_type((UnauthorizedError, ClientError)),
    before_sleep=maybe_refresh_token,
    reraise=True,
)
async def fetch_sds_order(star="", end="", filters={}, limi=None):
    data = await fetch_orders(
        os.environ.get("SDS_MNG_TOKEN"),
        {
            "orderTimeRangeType": "lastThreeMonths",
            "payDateBegin": star or "",
            "payDateEnd": end or "",
            **filters,
        },
        limit=limi,
    )
    status_map = {
        "1": "待付款",
        "7": "待设计",
        "2": "待确认",
        "5": "搁置中",
        "3": "备货中",
        "9": "部分发货",
        "4": "已完成",
        "98": "已取消",
        "hasApplyAfterAudit": "售后",
        "99": "已删除",
    }
    await asyncio.gather(update_sds_logistics_file(), update_sds_products_file())

    with open(
        os.environ.get("SDS_MNG_LOGISTICS_PATH") or "sds_mng_logistics.json",
        "r",
        encoding="utf-8",
    ) as f:
        logistics = json.load(f)

    with open(
        os.environ.get("SDS_MNG_PRODUCTS_PATH") or "sds_mng_products.json",
        "r",
        encoding="utf-8",
    ) as f:
        products = json.load(f)

    return [
        {
            "production_no": product.get("no"),
            "order_no": order.get("no"),
            "third_party_order_no": order.get("outOrderNo"),
            "product_name": products.get(product.get("productName"), {}).get(
                "product_name"
            ),
            "product_color": product.get("productColorBlock", {}).get("colorName"),
            "product_size": product.get("productSize"),
            "quantity": product.get("num"),
            "waybill_no": order.get("parcelList", [])[0]
            .get("logistics", {})
            .get("carriage", {})
            .get("no")
            if order.get("parcelList", [])
            else None,
            "merchant_no": order.get("merchant", {}).get("name"),
            "country_region": order.get("issuingBayArea", "").get("name"),
            "factory_name": product.get("factory", {}).get("name"),
            "paid_date": order.get("gmtPay"),
            "confirmed_at": order.get("gmtConfirmTime"),
            "completed_date": order.get("gmtFinished"),
            "status": status_map.get(str(product.get("status"))),
            "system_name": "SDS",
            "platform": order.get("merchantStore", {}).get("platformName"),
            "carriage_name": order.get("carriageName"),
            "product_coding": products.get(product.get("productName"), {}).get("sku"),
            "created_at": order.get("gmtCreated"),
            "carriage_type": next(
                (
                    log["type"]
                    for entry in logistics
                    if entry["country"] == order.get("issuingBayArea", "").get("name")
                    for log in entry["logistics"]
                    if log["name"] == order.get("carriageName")
                ),
                None,
            ),
            "ordered_at": order.get("gmtPay"),
            "completed_at": order.get("gmtFinished"),
            "product_style_no": products.get(product.get("productName"), {}).get(
                "style_no"
            ),
        }
        for order in data.get("list", [])
        for product in order.get("items", [])
    ]
