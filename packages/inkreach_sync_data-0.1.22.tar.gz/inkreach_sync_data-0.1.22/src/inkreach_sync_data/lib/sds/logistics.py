import os
import json
import asyncio
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed
from sds_mng.setting.fetch_logistics import fetch_id, fetch_logistics
from sds_mng.exception import UnauthorizedError
from aiohttp import ClientError
from inkreach_sync_data.lib.sds.token import maybe_refresh_token
from inkreach_sync_data.lib.sds.config import JSON_INDENT, SYNC_DATA_FILE_UPDATE_GAP
from sds_mng.util import logger
import arrow


@retry(
    stop=stop_after_attempt(3),
    wait=wait_fixed(2),
    retry=retry_if_exception_type((UnauthorizedError, ClientError)),
    before_sleep=maybe_refresh_token,
    reraise=True,
)
async def update_sds_logistics():
    logistics_config_path = (
        os.environ.get("SDS_MNG_LOGISTICS_PATH") or "sds_mng_logistics.json"
    )
    ids = await fetch_id(os.environ.get("SDS_MNG_TOKEN"))
    logistics_type = {
        "offline": "普通物流",
        "manual": "手动物流",
        "self_pickup": "自提",
        "online": "线上物流",
    }
    results = await asyncio.gather(
        *[
            fetch_logistics(
                os.environ.get("SDS_MNG_TOKEN"), {"issuingBayAreaId": bay_id}
            )
            for bay_id in ids.values()
        ]
    )
    data = [
        {
            "country": country,
            "logistics": [
                {
                    "name": item.get("name"),
                    "type": logistics_type.get(item.get("channelType"), "未知"),
                }
                for item in data.get("list", [])
            ],
        }
        for (country, bay_id), data in zip(ids.items(), results)
    ]
    with open(logistics_config_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=JSON_INDENT)


async def update_sds_logistics_file():
    logistics_config_path = (
        os.environ.get("SDS_MNG_LOGISTICS_PATH") or "sds_mng_logistics.json"
    )

    if not os.path.exists(logistics_config_path):
        await update_sds_logistics()
        return

    arrow.default_tz = "Asia/Shanghai"
    mtime = arrow.get(os.path.getmtime(logistics_config_path))
    logger.info(f"物流信息上次更新时间为 {mtime.format('YYYY-MM-DD HH:mm:ss')}")
    if mtime < arrow.now().shift(hours=-SYNC_DATA_FILE_UPDATE_GAP):
        logger.info(
            f"物流信息上次更新时间为 {mtime.format('YYYY-MM-DD HH:mm:ss')}，"
            + "可以更新物流信息了"
        )
        await update_sds_logistics()
    else:
        logger.info(
            f"物流信息上次更新时间为 {mtime.format('YYYY-MM-DD HH:mm:ss')}，"
            + "可以更新物流信息了"
        )
        return


async def update_sds_products():
    pass
