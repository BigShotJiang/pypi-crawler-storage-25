import asyncpg
from datetime import datetime
from typing import List, Dict, Any
from inkreach_sync_data.lib.sds.config import (
    SYNC_DATA_POSTGRE_HOST,
    SYNC_DATA_POSTGRE_PORT,
    SYNC_DATA_POSTGRE_USER,
    SYNC_DATA_POSTGRE_PASSWORD,
    SYNC_DATA_POSTGRE_DATABASE,
    SYNC_DATA_SQL_MAX_BATCH,
)
from sds_mng.util import logger


async def upsert_orders(orders_data: List[Dict[str, Any]], pool: asyncpg.Pool):
    if not orders_data:
        return

    columns = list(set(key for order in orders_data for key in order.keys()))

    def convert_order(order: Dict) -> tuple:
        row = []
        for col in columns:
            val = order.get(col)
            if col in (
                "paid_date",
                "confirmed_at",
                "completed_date",
                "created_at",
                "ordered_at",
                "completed_at",
            ):
                if val and isinstance(val, str):
                    val = datetime.fromisoformat(val)
            row.append(val)
        return tuple(row)

    values = [convert_order(order) for order in orders_data]

    placeholders = ", ".join(f"${i + 1}" for i in range(len(columns)))
    update_set = ", ".join(
        f"{col} = EXCLUDED.{col}"
        for col in columns
        if col not in ("production_no", "order_no")
    )

    upsert_sql = f"""
        INSERT INTO orders ({", ".join(columns)})
        VALUES ({placeholders})
        ON CONFLICT (production_no, order_no) DO UPDATE SET {update_set}
    """

    count = 0
    for i in range(0, len(orders_data), SYNC_DATA_SQL_MAX_BATCH):
        batch = orders_data[i : i + SYNC_DATA_SQL_MAX_BATCH]
        logger.info(f"正在更新/插入第{count + 1}批次，总共{len(batch)}条数据")
        values = [convert_order(order) for order in batch]

        async with pool.acquire() as conn:
            await conn.executemany(upsert_sql, values)
            logger.info(f"已更新/插入第{count + 1}批次，总共{len(batch)}条数据")
            count = count + 1


async def create_pool():
    return await asyncpg.create_pool(
        host=SYNC_DATA_POSTGRE_HOST,
        port=SYNC_DATA_POSTGRE_PORT,
        user=SYNC_DATA_POSTGRE_USER,
        password=SYNC_DATA_POSTGRE_PASSWORD,
        database=SYNC_DATA_POSTGRE_DATABASE,
        min_size=5,
        max_size=20,
    )
