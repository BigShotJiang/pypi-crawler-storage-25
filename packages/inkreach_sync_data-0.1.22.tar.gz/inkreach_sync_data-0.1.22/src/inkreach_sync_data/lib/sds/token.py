import os
from dotenv import set_key
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed
from sds_mng.auth.get_token import get_token
from sds_mng.exception import UnauthorizedError
from aiohttp import ClientError


def maybe_refresh_token(retry_state):
    exception = retry_state.outcome.exception()
    if isinstance(exception, UnauthorizedError):
        try:
            new_token = get_token(
                os.environ.get("SDS_MNG_USERNAME"), os.environ.get("SDS_MNG_PASSWORD")
            )
            os.environ["SDS_MNG_TOKEN"] = new_token
            set_key(os.environ.get("ENV_PATH") or ".env", "SDS_MNG_TOKEN", new_token)
            print("Token refreshed before retry.")
        except Exception as e:
            print(f"Failed to refresh token: {e}")
            raise e("账号密码错误！")


def get_token_retry_decorator():
    return retry(
        stop=stop_after_attempt(3),
        wait=wait_fixed(2),
        retry=retry_if_exception_type((UnauthorizedError, ClientError)),
        before_sleep=maybe_refresh_token,
        reraise=True,
    )
