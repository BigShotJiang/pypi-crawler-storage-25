from inkreach_sync_data.cli import cli

if __name__ == "__main__":
    cli()
