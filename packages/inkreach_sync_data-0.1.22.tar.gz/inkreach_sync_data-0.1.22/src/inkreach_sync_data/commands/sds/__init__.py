import click

from inkreach_sync_data.commands.sds.sync_recent import cli as sync_recent
from inkreach_sync_data.commands.sds.refresh import cli as refresh
from inkreach_sync_data.commands.sds.sync_incremental import cli as sync_incremental


@click.group(name="sds")
def cli():
    """SDS系统相关命令"""
    pass


cli.add_command(sync_recent)
cli.add_command(refresh)
cli.add_command(sync_incremental)
