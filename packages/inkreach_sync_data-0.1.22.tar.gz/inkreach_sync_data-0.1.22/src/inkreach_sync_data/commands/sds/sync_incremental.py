import click
import asyncio
import arrow

from inkreach_sync_data.utils import fetch_sds_order, upsert_orders, create_pool


@click.command(name="sync-incremental")
def cli():
    """增量同步订单"""

    async def run():
        pool = await create_pool()

        async with pool.acquire() as conn:
            row = await conn.fetchrow(
                "SELECT MAX(paid_date) as latest_ordered_at FROM orders"
            )
            latest = row["latest_ordered_at"]

        if latest:
            start = arrow.get(latest).floor("hour")
        else:
            start = arrow.now().shift(days=-2).floor("day")

        click.echo(f"SDS最新支付时间为 {start.format('YYYY-MM-DD HH:mm:ss')}")

        end = arrow.now().ceil("day")

        data = await fetch_sds_order(
            start.format("YYYY-MM-DD HH:mm:ss"),
            end.format("YYYY-MM-DD HH:mm:ss"),
        )

        if data:
            await upsert_orders(data, pool)
            click.echo(f"成功同步 {len(data)} 条订单")
        else:
            click.echo("没有新订单")

    asyncio.run(run())
