import click
import asyncio
import arrow

from inkreach_sync_data.utils import fetch_sds_order, upsert_orders, create_pool


@click.command(name="sync-recent")
@click.option("-s", "--start", "start", help="开始时间，格式为 YYYY-MM-DD HH:mm:ss")
@click.option("-e", "--end", "end", help="结束时间，格式为 YYYY-MM-DD HH:mm:ss")
@click.option("-d", "--days", "days", type=int, default=1, help="近期几日 (默认: 1)")
def cli(start, end, days):
    """同步近期订单"""
    arrow.default_tz = "Asia/Shanghai"

    if start and end:
        start_time = start
        end_time = end
    elif start and not end:
        start_time = start
        end_time = arrow.now().ceil("day").format("YYYY-MM-DD HH:mm:ss")
    elif not start and end:
        start_time = (
            arrow.now().shift(days=-days).floor("day").format("YYYY-MM-DD HH:mm:ss")
        )
        end_time = end
    else:
        start_time = (
            arrow.now().shift(days=-days).floor("day").format("YYYY-MM-DD HH:mm:ss")
        )
        end_time = arrow.now().ceil("day").format("YYYY-MM-DD HH:mm:ss")

    click.echo(f"同步订单时间范围: {start_time} ~ {end_time}")

    async def run():
        pool = await create_pool()
        data = await fetch_sds_order(start_time, end_time)
        if data:
            await upsert_orders(data, pool)
            click.echo(f"成功同步 {len(data)} 条订单")
        else:
            click.echo("没有订单数据")

    asyncio.run(run())
