import click
import asyncio
from pprint import pprint

from inkreach_sync_data.utils import (
    fetch_sds_order,
    upsert_orders,
    create_pool,
    SDS_QUERY_MAX_BATCH,
    SYNC_DATA_MAX_CONCURRENT,
)


@click.command(name="refresh")
@click.option("-s", "--sql", "sql", required=True, help="获取订单号的SQL语句")
@click.option(
    "-d",
    "--delete",
    "delete_before_insert",
    is_flag=True,
    default=False,
    help="更新前是否删除原数据",
)
def cli(sql, delete_before_insert):
    """刷新特定订单"""
    click.echo(f"SQL: {sql}")
    click.echo(f"删除后更新: {delete_before_insert}")

    async def run():
        pool = await create_pool()

        async with pool.acquire() as conn:
            rows = await conn.fetch(sql)
            order_nos = [r["order_no"] for r in rows]

        pprint(order_nos)

        if not order_nos:
            click.echo("没有订单号")
            return

        batches = [
            order_nos[i : i + SDS_QUERY_MAX_BATCH]
            for i in range(0, len(order_nos), SDS_QUERY_MAX_BATCH)
        ]
        semaphore = asyncio.Semaphore(SYNC_DATA_MAX_CONCURRENT)

        async def process_batch(batch):
            async with semaphore:
                keywords = "\n".join(batch)
                latest_data = await fetch_sds_order(filters={"keywords": keywords})
                if not latest_data:
                    return

                async with pool.acquire() as conn:
                    async with conn.transaction():
                        if delete_before_insert:
                            await conn.execute(
                                "DELETE FROM orders WHERE order_no = ANY($1::text[])",
                                batch,
                            )

                await upsert_orders(latest_data, pool)

        await asyncio.gather(*[process_batch(batch) for batch in batches])
        click.echo(f"刷新完成")

    asyncio.run(run())
