"""Click CLI entrypoint for jetfit."""

import json
import os
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich import box

from jetfit.hardware import SystemInfo, detect_hardware
from jetfit.profiles import PROFILES, HardwareProfile
from jetfit.fit import (
    FitLevel, FitResult, ModelSpec, KNOWN_MODELS,
    recommend, best_fit, QUANT_LADDER,
)

console = Console()

_FIT_COLORS: dict[FitLevel, str] = {
    FitLevel.PERFECT:   "bright_green",
    FitLevel.GOOD:      "green",
    FitLevel.MARGINAL:  "yellow",
    FitLevel.TOO_TIGHT: "red",
}

_CALIBRATION_PATH = Path.home() / ".config" / "jetfit" / "calibration.json"


def _load_efficiency(profile_key: str) -> Optional[float]:
    if _CALIBRATION_PATH.exists():
        try:
            data = json.loads(_CALIBRATION_PATH.read_text())
            return data.get(profile_key, {}).get("efficiency")
        except Exception:
            pass
    return None


def _fmt_tps(tps: float) -> str:
    return f"{tps:6.1f}"


def _fit_badge(level: FitLevel) -> str:
    color = _FIT_COLORS[level]
    return f"[{color}]{level.value}[/{color}]"


@click.group(invoke_without_command=True)
@click.version_option()
@click.pass_context
def main(ctx: click.Context) -> None:
    """jetfit — LLM model advisor for NVIDIA Jetson and DGX Spark."""
    if ctx.invoked_subcommand is None:
        from jetfit.tui import JetfitApp
        JetfitApp().run()


# ---------------------------------------------------------------------------
# system
# ---------------------------------------------------------------------------

@main.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def system(as_json: bool) -> None:
    """Show detected hardware information."""
    info = detect_hardware()

    if as_json:
        out = {
            "profile_key": info.profile_key,
            "name": info.profile.name,
            "total_memory_gb": info.total_memory_gb,
            "available_memory_gb": info.available_memory_gb,
            "bandwidth_gbs": info.profile.bandwidth_gbs,
            "has_dla": info.profile.has_dla,
            "has_fp4": info.profile.has_fp4,
            "jetpack_version": info.jetpack_version,
            "device_model": info.device_model,
            "is_simulated": info.is_simulated,
        }
        click.echo(json.dumps(out, indent=2))
        return

    table = Table(title="Detected Hardware", box=box.ROUNDED, show_header=False)
    table.add_column("Field", style="cyan", no_wrap=True)
    table.add_column("Value")

    def row(k: str, v: str) -> None:
        table.add_row(k, v)

    row("Platform",      info.profile.name + (" [dim](simulated)[/dim]" if info.is_simulated else ""))
    row("Total memory",  f"{info.total_memory_gb:.0f} GB")
    row("Available",     f"{info.available_memory_gb:.1f} GB")
    row("Bandwidth",     f"{info.profile.bandwidth_gbs:.1f} GB/s")
    row("Accelerator",   ("DLA+CUDA" if info.profile.has_dla else "") + ("FP4+CUDA" if info.profile.has_fp4 else ""))
    row("JetPack",       info.jetpack_version or "N/A")
    row("Device model",  info.device_model or "N/A")

    console.print(table)


# ---------------------------------------------------------------------------
# recommend
# ---------------------------------------------------------------------------

@main.command(name="recommend")
@click.option("--model", "model_filter", default=None,
              help="Filter by model name substring.")
@click.option("--min-tps", default=None, type=float,
              help="Only show results with estimated tok/s ≥ this value.")
@click.option("--quant", default=None,
              type=click.Choice([q for q, _, _ in QUANT_LADDER]),
              help="Fix a specific quantization level.")
@click.option("--available-gb", default=None, type=float,
              help="Override available memory (GB).")
@click.option("--profile", "profile_key", default=None,
              type=click.Choice(list(PROFILES.keys())),
              help="Override hardware profile.")
@click.option("--all-quants", is_flag=True,
              help="Show all quant levels, not just best fit.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def recommend_cmd(
    model_filter: Optional[str],
    min_tps: Optional[float],
    quant: Optional[str],
    available_gb: Optional[float],
    profile_key: Optional[str],
    all_quants: bool,
    as_json: bool,
) -> None:
    """Recommend LLM quant levels for current (or specified) hardware."""
    info = detect_hardware()

    if profile_key:
        hw = PROFILES[profile_key]
        avail = available_gb or hw.total_memory_gb
    else:
        hw = info.profile
        avail = available_gb or info.available_memory_gb
        profile_key = info.profile_key

    efficiency = _load_efficiency(profile_key)

    models = KNOWN_MODELS
    if model_filter:
        models = [m for m in models if model_filter.lower() in m.name.lower()]
        if not models:
            console.print(f"[red]No models matching '{model_filter}'[/red]")
            sys.exit(1)

    rows: list[dict] = []
    for model in models:
        if quant:
            from jetfit.fit import score_model
            result = score_model(model, quant, hw, avail, efficiency)
            candidates = [result]
        elif all_quants:
            candidates = recommend(model, hw, avail, efficiency)
        else:
            bf = best_fit(model, hw, avail, efficiency)
            candidates = [bf] if bf else []

        for r in candidates:
            if min_tps and r.estimated_tps < min_tps:
                continue
            rows.append({
                "model": r.model.name,
                "quant": r.quant,
                "size_gb": r.model_size_gb,
                "eff_gb": r.effective_size_gb,
                "fit": r.fit_level.value,
                "mem_pct": r.memory_utilization * 100,
                "tps": r.estimated_tps,
            })

    if as_json:
        click.echo(json.dumps(rows, indent=2))
        return

    sim_note = " [dim](simulated)[/dim]" if info.is_simulated else ""
    title = f"Recommendations — {hw.name}{sim_note}  |  {avail:.1f} GB available"
    if efficiency:
        title += f"  |  eff={efficiency:.2f} [dim](calibrated)[/dim]"

    table = Table(title=title, box=box.SIMPLE_HEAD)
    table.add_column("Model",    style="bold", no_wrap=True)
    table.add_column("Quant",    style="cyan")
    table.add_column("Size GB",  justify="right")
    table.add_column("Eff GB",   justify="right")
    table.add_column("Fit",      justify="center")
    table.add_column("Mem %",    justify="right")
    table.add_column("tok/s",    justify="right", style="bright_yellow")

    for r in rows:
        color = _FIT_COLORS[FitLevel(r["fit"])]
        table.add_row(
            r["model"],
            r["quant"],
            f"{r['size_gb']:.2f}",
            f"{r['eff_gb']:.2f}",
            f"[{color}]{r['fit']}[/{color}]",
            f"{r['mem_pct']:.0f}%",
            _fmt_tps(r["tps"]),
        )

    if not rows:
        console.print("[yellow]No models fit the criteria.[/yellow]")
    else:
        console.print(table)


@main.command(name="tui")
def tui_cmd() -> None:
    """Launch the interactive TUI (default when no subcommand given)."""
    from jetfit.tui import JetfitApp
    JetfitApp().run()
