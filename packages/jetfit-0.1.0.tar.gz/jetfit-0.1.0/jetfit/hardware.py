"""Platform detection for Jetson and DGX Spark devices."""

import os
import re
import subprocess
from dataclasses import dataclass
from typing import Optional

try:
    from jtop import jtop  # type: ignore
    _JTOP_AVAILABLE = True
except Exception:
    _JTOP_AVAILABLE = False

from jetfit.profiles import HardwareProfile, PROFILES


@dataclass
class SystemInfo:
    profile_key: str
    profile: HardwareProfile
    available_memory_gb: float
    total_memory_gb: float
    jetpack_version: Optional[str]
    tegra_release: Optional[str]
    device_model: Optional[str]
    is_simulated: bool = False  # True when running on non-Jetson (Mac/Linux dev)


def _read_file(path: str) -> Optional[str]:
    try:
        with open(path) as f:
            return f.read()
    except OSError:
        return None


def _detect_via_tegra_release() -> Optional[str]:
    content = _read_file("/etc/nv_tegra_release")
    if content:
        return content.strip()
    return None


def _detect_device_tree_compatible() -> Optional[str]:
    content = _read_file("/proc/device-tree/compatible")
    if content:
        return content.replace("\x00", " ").strip()
    return None


def _detect_device_tree_model() -> Optional[str]:
    content = _read_file("/proc/device-tree/model")
    if content:
        return content.replace("\x00", "").strip()
    return None


def _parse_meminfo_available_gb() -> float:
    content = _read_file("/proc/meminfo")
    if not content:
        return 0.0
    for line in content.splitlines():
        if line.startswith("MemAvailable:"):
            kb = int(line.split()[1])
            return kb / (1024 * 1024)
    return 0.0


def _get_tegrastats_memory_gb() -> Optional[float]:
    """Run tegrastats once and parse unified RAM available."""
    try:
        result = subprocess.run(
            ["tegrastats", "--once"],
            capture_output=True, text=True, timeout=5
        )
        # Example: RAM 3124/15831MB ...
        m = re.search(r"RAM\s+(\d+)/(\d+)MB", result.stdout)
        if m:
            used_mb = int(m.group(1))
            total_mb = int(m.group(2))
            available_mb = total_mb - used_mb
            return available_mb / 1024.0
    except Exception:
        pass
    return None


def _get_jtop_memory_gb() -> Optional[float]:
    if not _JTOP_AVAILABLE:
        return None
    try:
        with jtop() as jetson:
            mem = jetson.memory
            total = mem.get("RAM", {}).get("tot", 0)
            used = mem.get("RAM", {}).get("used", 0)
            return (total - used) / 1024.0
    except Exception:
        return None


def _match_profile_from_model(model_str: str) -> Optional[str]:
    """Map device-tree model string to a profile key."""
    m = model_str.lower()
    # ── Thor ─────────────────────────────────────────────────────────────────
    if "thor" in m:
        if "t4000" in m:
            return "jetson_thor_t4000"
        return "jetson_thor_t5000"
    # ── DGX Spark ─────────────────────────────────────────────────────────────
    if "dgx" in m or "grace" in m or "gb10" in m:
        return "dgx_spark"
    # ── AGX Orin ──────────────────────────────────────────────────────────────
    if "agx orin" in m or "agx-orin" in m:
        if "industrial" in m:
            return "jetson_agx_orin_industrial"
        if "64" in m:
            return "jetson_agx_orin_64gb"
        return "jetson_agx_orin_32gb"
    # ── Orin NX ───────────────────────────────────────────────────────────────
    if "orin nx" in m or "orin-nx" in m:
        if "8" in m:
            return "jetson_orin_nx_8gb"
        return "jetson_orin_nx_16gb"
    # ── Orin Nano ─────────────────────────────────────────────────────────────
    if "orin nano" in m or "orin-nano" in m:
        if "4" in m:
            return "jetson_orin_nano_4gb"
        return "jetson_orin_nano_8gb"
    # ── AGX Xavier ────────────────────────────────────────────────────────────
    if "agx xavier" in m or "agx-xavier" in m:
        if "industrial" in m:
            return "jetson_agx_xavier_industrial"
        if "64" in m:
            return "jetson_agx_xavier_64gb"
        if "32" in m:
            return "jetson_agx_xavier_32gb"
        return "jetson_agx_xavier_16gb"
    # ── Xavier NX ─────────────────────────────────────────────────────────────
    if "xavier nx" in m or "xavier-nx" in m:
        if "16" in m:
            return "jetson_xavier_nx_16gb"
        return "jetson_xavier_nx_8gb"
    # ── TX2 ───────────────────────────────────────────────────────────────────
    if "tx2 nx" in m or "tx2-nx" in m:
        return "jetson_tx2_nx"
    if "tx2i" in m or "tx2-i" in m:
        return "jetson_tx2i"
    if "tx2" in m:
        if "4gb" in m or "4 gb" in m:
            return "jetson_tx2_4gb"
        return "jetson_tx2"
    # ── Nano ──────────────────────────────────────────────────────────────────
    if "nano" in m:
        return "jetson_nano"
    return None


def _match_profile_from_compatible(compat: str) -> Optional[str]:
    c = compat.lower()
    if "nvidia,grace" in c or "dgx" in c:
        return "dgx_spark"
    if "thor" in c:
        return "jetson_thor_t5000"
    if "agx-orin" in c or "agx_orin" in c:
        return "jetson_agx_orin_64gb"
    if "orin-nx" in c or "orin_nx" in c:
        return "jetson_orin_nx_16gb"
    if "orin-nano" in c or "orin_nano" in c:
        return "jetson_orin_nano_8gb"
    if "agx-xavier" in c or "agx_xavier" in c:
        return "jetson_agx_xavier_16gb"
    if "xavier-nx" in c or "xavier_nx" in c:
        return "jetson_xavier_nx_8gb"
    if "tx2" in c:
        return "jetson_tx2"
    if "nano" in c:
        return "jetson_nano"
    return None


def detect_hardware() -> SystemInfo:
    """Detect the current Jetson/DGX hardware and return a SystemInfo."""
    tegra_release = _detect_via_tegra_release()
    compatible = _detect_device_tree_compatible()
    model_str = _detect_device_tree_model()

    profile_key: Optional[str] = None
    is_simulated = False

    # Priority 1: device-tree model (most specific)
    if model_str:
        profile_key = _match_profile_from_model(model_str)

    # Priority 2: compatible string
    if not profile_key and compatible:
        if "nvidia,grace" in compatible.lower():
            profile_key = "dgx_spark"
        if not profile_key:
            profile_key = _match_profile_from_compatible(compatible)

    # Priority 3: tegra release exists → it's some Jetson
    if not profile_key and tegra_release:
        profile_key = "jetson_orin_nx_16gb"  # sensible fallback for unknown Jetson

    # Fallback: running on a dev machine (Mac/Linux without Jetson hardware)
    if not profile_key:
        is_simulated = True
        profile_key = "jetson_orin_nx_16gb"

    profile = PROFILES[profile_key]

    # Memory: jtop > tegrastats > /proc/meminfo
    available_gb = _get_jtop_memory_gb()
    if available_gb is None:
        available_gb = _get_tegrastats_memory_gb()
    if available_gb is None:
        available_gb = _parse_meminfo_available_gb()
    if available_gb == 0.0:
        # No memory source available (e.g. Mac dev machine); fall back to profile total
        available_gb = profile.total_memory_gb

    # Cap available to profile total (tegrastats can over-report on some JetPacks)
    available_gb = min(available_gb, profile.total_memory_gb)

    return SystemInfo(
        profile_key=profile_key,
        profile=profile,
        available_memory_gb=available_gb,
        total_memory_gb=profile.total_memory_gb,
        jetpack_version=profile.jetpack_version,
        tegra_release=tegra_release,
        device_model=model_str,
        is_simulated=is_simulated,
    )
