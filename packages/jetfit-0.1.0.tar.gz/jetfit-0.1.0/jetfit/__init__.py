"""jetfit — LLM model advisor for NVIDIA Jetson and DGX Spark."""

__version__ = "0.1.0"
