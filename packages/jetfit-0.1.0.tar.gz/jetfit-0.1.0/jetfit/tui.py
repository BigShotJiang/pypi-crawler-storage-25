"""Textual TUI — jetfit interactive model advisor (llmfit-style design)."""

from __future__ import annotations

import json
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from rich.text import Text
from textual import on, events
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, ScrollableContainer
from textual.message import Message
from textual.reactive import reactive
from textual.screen import ModalScreen, Screen
from textual.theme import Theme as TuiTheme
from textual.widget import Widget
from textual.widgets import DataTable, Input, Select, Static

from jetfit.fit import (
    FitLevel, FitResult, ModelSpec, KNOWN_MODELS, QUANT_LADDER,
    best_fit, recommend, score_model,
)
from jetfit.hardware import SystemInfo, detect_hardware
from jetfit.profiles import PROFILES, HardwareProfile

# ---------------------------------------------------------------------------
# Theme system — uses Textual 8.x Theme API for full CSS coverage
# ---------------------------------------------------------------------------

_CALIBRATION_PATH = Path.home() / ".config" / "jetfit" / "calibration.json"
_THEME_PATH       = Path.home() / ".config" / "jetfit" / "theme"
_FIT_ORDER   = [FitLevel.PERFECT, FitLevel.GOOD, FitLevel.MARGINAL, FitLevel.TOO_TIGHT]
_QUANT_NAMES = [q for q, _, _ in QUANT_LADDER]

# Each TuiTheme drives Textual CSS variables: $background $panel $surface $boost
# $primary $accent $success $warning $error $foreground + custom $overlay0 etc.
_TEXTUAL_THEMES: dict[str, TuiTheme] = {
    "Mocha": TuiTheme(
        name="Mocha", dark=True,
        primary="#94e2d5", secondary="#cba6f7",
        background="#1e1e2e", surface="#313244", panel="#181825", boost="#45475a",
        foreground="#cdd6f4",
        success="#a6e3a1", warning="#f9e2af", error="#f38ba8", accent="#b4befe",
        variables={"overlay0":"#6c7086","overlay1":"#7f849c","subtext0":"#a6adc8","mauve":"#cba6f7"},
    ),
    "Dracula": TuiTheme(
        name="Dracula", dark=True,
        primary="#8be9fd", secondary="#ff79c6",
        background="#282a36", surface="#44475a", panel="#21222c", boost="#6272a4",
        foreground="#f8f8f2",
        success="#50fa7b", warning="#f1fa8c", error="#ff5555", accent="#bd93f9",
        variables={"overlay0":"#6272a4","overlay1":"#7970a9","subtext0":"#9aadce","mauve":"#ff79c6"},
    ),
    "Nord": TuiTheme(
        name="Nord", dark=True,
        primary="#88c0d0", secondary="#b48ead",
        background="#2e3440", surface="#3b4252", panel="#272c36", boost="#434c5e",
        foreground="#eceff4",
        success="#a3be8c", warning="#ebcb8b", error="#bf616a", accent="#81a1c1",
        variables={"overlay0":"#4c566a","overlay1":"#677691","subtext0":"#d8dee9","mauve":"#b48ead"},
    ),
    "Gruvbox": TuiTheme(
        name="Gruvbox", dark=True,
        primary="#83a598", secondary="#d3869b",
        background="#282828", surface="#3c3836", panel="#1d2021", boost="#504945",
        foreground="#ebdbb2",
        success="#b8bb26", warning="#fabd2f", error="#fb4934", accent="#d3869b",
        variables={"overlay0":"#928374","overlay1":"#a89984","subtext0":"#d5c4a1","mauve":"#d3869b"},
    ),
    "Macchiato": TuiTheme(
        name="Macchiato", dark=True,
        primary="#8bd5ca", secondary="#c6a0f6",
        background="#24273a", surface="#363a4f", panel="#1e2030", boost="#494d64",
        foreground="#cad3f5",
        success="#a6da95", warning="#eed49f", error="#ed8796", accent="#b7bdf8",
        variables={"overlay0":"#6e738d","overlay1":"#8087a2","subtext0":"#a5adcb","mauve":"#c6a0f6"},
    ),
}
_THEME_CYCLE = list(_TEXTUAL_THEMES.keys())
_C: dict[str, str] = {}  # Rich markup colors — synced on every theme change


def _sync_colors(t: TuiTheme) -> None:
    """Populate the module-level _C dict from a TuiTheme (for Rich markup)."""
    v = t.variables or {}
    _C.update({
        "base":     t.background  or "#1e1e2e",
        "mantle":   t.panel       or "#181825",
        "surface0": t.surface     or "#313244",
        "surface1": t.boost       or "#45475a",
        "text":     t.foreground  or "#cdd6f4",
        "teal":     t.primary,
        "green":    t.success     or "#a6e3a1",
        "yellow":   t.warning     or "#f9e2af",
        "red":      t.error       or "#f38ba8",
        "lavender": t.accent      or "#b4befe",
        "mauve":    t.secondary   or "#cba6f7",
        "overlay0": v.get("overlay0",  "#6c7086"),
        "overlay1": v.get("overlay1",  "#7f849c"),
        "subtext0": v.get("subtext0",  "#a6adc8"),
    })


def _load_theme_name() -> str:
    if _THEME_PATH.exists():
        n = _THEME_PATH.read_text().strip()
        if n in _TEXTUAL_THEMES:
            return n
    return "Mocha"


def _save_theme_name(name: str) -> None:
    try:
        _THEME_PATH.parent.mkdir(parents=True, exist_ok=True)
        _THEME_PATH.write_text(name)
    except OSError:
        pass


# Initialise _C with the saved (or default) theme before any widgets render
_sync_colors(_TEXTUAL_THEMES[_load_theme_name()])

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class AppMode(Enum):
    NORMAL = "NORMAL"
    VISUAL = "VISUAL"


def _load_efficiency(profile_key: str) -> Optional[float]:
    if _CALIBRATION_PATH.exists():
        try:
            data = json.loads(_CALIBRATION_PATH.read_text())
            return data.get(profile_key, {}).get("efficiency")
        except Exception:
            pass
    return None


_FAMILIES = ["All", "Llama", "Mistral", "Phi", "Gemma", "Qwen", "DeepSeek", "SmolLM",
             "Yi", "Command", "InternLM", "Falcon", "StarCoder"]
_SIZES    = ["All", "Tiny", "Small", "Medium", "Large", "Huge"]

# Quant quality 0-100 (higher = less lossy)
_QUANT_QUALITY: dict[str, int] = {
    "Q8_0": 100, "Q6_K": 87, "Q5_K_M": 78, "Q4_K_M": 66,
    "Q3_K_M": 45, "Q2_K": 22,
}


def _model_family(name: str) -> str:
    n = name.lower()
    if "llama" in n or "tinyllama" in n: return "Llama"
    if "mistral"  in n or "mixtral" in n or "codestral" in n: return "Mistral"
    if "phi"      in n: return "Phi"
    if "gemma"    in n: return "Gemma"
    if "qwen"     in n: return "Qwen"
    if "deepseek" in n: return "DeepSeek"
    if "smollm"   in n: return "SmolLM"
    if "yi-"      in n: return "Yi"
    if "command"  in n: return "Command"
    if "internlm" in n: return "InternLM"
    if "falcon"   in n: return "Falcon"
    if "starcoder" in n: return "StarCoder"
    return "Other"


def _model_size_label(params_b: float) -> str:
    if params_b < 1:  return "Tiny"
    if params_b < 7:  return "Small"
    if params_b < 14: return "Medium"
    if params_b < 70: return "Large"
    return "Huge"


def _fit_style(level: FitLevel) -> str:
    if level in (FitLevel.PERFECT, FitLevel.GOOD):
        return _C["green"]
    return _C["yellow"] if level == FitLevel.MARGINAL else _C["red"]


def _fit_markup(level: FitLevel) -> str:
    c = _fit_style(level)
    return f"[{c}]{level.value}[/{c}]"


def _hw_bar_markup(info: SystemInfo, efficiency: Optional[float]) -> str:
    sim   = f" [{_C['overlay0']}](sim)[/{_C['overlay0']}]" if info.is_simulated else ""
    accel = "DLA+CUDA" if info.profile.has_dla else ("FP4+CUDA" if info.profile.has_fp4 else "CUDA")
    cal   = f"  [{_C['teal']}]✓ cal[/{_C['teal']}]" if efficiency else ""
    jp      = info.profile.jetpack_version or "N/A"
    jp_label = "Min JP:" if info.is_simulated else "JP:"
    t, s, o = _C["teal"], _C["surface1"], _C["overlay0"]
    return (
        f"[bold {_C['text']}]jetfit[/bold {_C['text']}]"
        f"  [{s}]│[/{s}]  "
        f"[{t}]Platform:[/{t}] [{_C['text']}]{info.profile.name}[/{_C['text']}]{sim}"
        f"  [{s}]│[/{s}]  "
        f"[{t}]RAM:[/{t}] [{_C['green']}]{info.available_memory_gb:.1f} GB avail[/{_C['green']}]"
        f" [{o}]/[/{o}] [{_C['subtext0']}]{info.total_memory_gb:.0f} GB[/{_C['subtext0']}]"
        f"  [{s}]│[/{s}]  "
        f"[{t}]Accel:[/{t}] [{_C['text']}]{accel}[/{_C['text']}]"
        f"  [{s}]│[/{s}]  "
        f"[{t}]{jp_label}[/{t}] [{_C['text']}]{jp}[/{_C['text']}]{cal}"
    )

# ---------------------------------------------------------------------------
# InlineField widget
# ---------------------------------------------------------------------------

class InlineField(Widget, can_focus=True):
    """llmfit-style inline editable field: `Label: value unit`."""

    class Changed(Message):
        def __init__(self, field: "InlineField", value: str) -> None:
            self.field = field; self.value = value; super().__init__()

    DEFAULT_CSS = "InlineField { height: 1; background: transparent; }"

    def __init__(self, label: str, value: str, unit: str = "",
                 choices: list[str] | None = None, widget_id: str = "") -> None:
        super().__init__(id=widget_id or None)
        self._label = label; self._unit = unit
        self._choices = choices or []
        if self._choices:
            idx = self._choices.index(value) if value in self._choices else 0
            self._choice_idx = idx; self._value = self._choices[idx]
            self._buffer = ""; self._cursor = 0
        else:
            self._value = value; self._buffer = value
            self._cursor = len(value); self._choice_idx = 0

    @property
    def value(self) -> str:
        return self._value

    def render(self) -> Text:
        focused = self.has_focus
        t = Text()
        t.append(f"{self._label}: ", style=f"bold {_C['teal']}")
        if focused and self._choices:
            t.append("◀ ", style=_C["overlay1"])
            t.append(self._value, style=f"bold {_C['text']}")
            t.append(" ▶", style=_C["overlay1"])
        elif focused:
            buf = self._buffer
            before = buf[: self._cursor]
            at     = buf[self._cursor : self._cursor + 1] or " "
            after  = buf[self._cursor + 1 :]
            t.append(before, style=_C["text"])
            t.append(at,     style=f"reverse {_C['text']}")
            t.append(after,  style=_C["text"])
        else:
            t.append(self._value, style=_C["subtext0"])
        if self._unit:
            t.append(f" {self._unit}", style=_C["overlay0"])
        return t

    def on_focus(self)  -> None:
        if not self._choices:
            self._buffer = self._value; self._cursor = len(self._buffer)
        self.refresh()

    def on_blur(self) -> None:
        if not self._choices:
            self._value = self._buffer or self._value
        self.refresh()

    def on_key(self, event: events.Key) -> None:
        if self._choices:
            if event.key in ("left", "up"):
                self._choice_idx = (self._choice_idx - 1) % len(self._choices)
                self._value = self._choices[self._choice_idx]
                self.post_message(self.Changed(self, self._value)); self.refresh(); event.stop()
            elif event.key in ("right", "down"):
                self._choice_idx = (self._choice_idx + 1) % len(self._choices)
                self._value = self._choices[self._choice_idx]
                self.post_message(self.Changed(self, self._value)); self.refresh(); event.stop()
        else:
            if event.character and event.character.isprintable():
                self._buffer = self._buffer[: self._cursor] + event.character + self._buffer[self._cursor :]
                self._cursor += 1; self._value = self._buffer
                self.post_message(self.Changed(self, self._value)); self.refresh(); event.stop()
            elif event.key == "backspace":
                if self._cursor > 0:
                    self._buffer = self._buffer[: self._cursor - 1] + self._buffer[self._cursor :]
                    self._cursor -= 1; self._value = self._buffer
                    self.post_message(self.Changed(self, self._value)); self.refresh()
                event.stop()
            elif event.key == "left":
                self._cursor = max(0, self._cursor - 1); self.refresh(); event.stop()
            elif event.key == "right":
                self._cursor = min(len(self._buffer), self._cursor + 1); self.refresh(); event.stop()
            elif event.key == "ctrl+a":
                self._cursor = 0; self.refresh(); event.stop()
            elif event.key == "ctrl+e":
                self._cursor = len(self._buffer); self.refresh(); event.stop()

# ---------------------------------------------------------------------------
# HelpScreen
# ---------------------------------------------------------------------------

class HelpScreen(ModalScreen):
    BINDINGS = [Binding("escape", "dismiss", "Close"),
                Binding("h", "dismiss", "Close"), Binding("q", "dismiss", "Close")]
    CSS = """
    HelpScreen { align: center middle; }
    HelpScreen #hbox {
        width: 64; height: 30;
        border: solid $primary; background: $background; padding: 0 1;
        border-title-color: $primary; border-title-style: bold;
    }
    HelpScreen #hscroll { height: 1fr; padding: 1 1; }
    HelpScreen #hfoot   { height: 1; background: $panel; padding: 0 1; }
    """

    def compose(self) -> ComposeResult:
        with Container(id="hbox"):
            with ScrollableContainer(id="hscroll"):
                yield Static(self._build_text(), markup=True)
            yield Static(
                f"[{_C['overlay0']}]j/k:scroll  h/q/Esc:close[/{_C['overlay0']}]",
                id="hfoot", markup=True)

    def on_mount(self) -> None:
        self.query_one("#hbox").border_title = "Help"

    def _build_text(self) -> str:
        t = _C["teal"]; tx = _C["text"]; s = _C["subtext0"]
        themes = " → ".join(_THEME_CYCLE)
        def kv(k: str, v: str) -> str:
            return f"  [{tx}]{k:<14}[/{tx}]  [{s}]{v}[/{s}]"
        return "\n".join([
            f"[bold {t}]Navigation[/bold {t}]",
            kv("j / ↓",        "Move down"),
            kv("k / ↑",        "Move up"),
            kv("g",            "Jump top/bottom"),
            "",
            f"[bold {t}]Views[/bold {t}]",
            kv("Enter",        "Detail view"),
            kv("p",            "Plan view"),
            kv("c",            "Compare marked models"),
            "",
            f"[bold {t}]Mark & Compare[/bold {t}]",
            kv("m",            "Mark / unmark"),
            kv("v",            "Visual mode (range select)"),
            kv("x",            "Clear all marks"),
            "",
            f"[bold {t}]Filters[/bold {t}]",
            kv("/",            "Search"),
            kv("f",            "Cycle fit filter"),
            kv("s",            "Cycle sort"),
            kv("F",            "Filter popup (params/mem range)"),
            "",
            f"[bold {t}]Hardware & Config[/bold {t}]",
            kv("S",            "Simulate hardware profile"),
            kv("A",            "Advanced config (efficiency)"),
            kv("t",            f"Cycle theme  [{_C['overlay0']}]{themes}[/{_C['overlay0']}]"),
            kv("h",            "This help"),
            kv("q / Esc",      "Quit / back"),
        ])

    def on_key(self, event: events.Key) -> None:
        sc = self.query_one("#hscroll", ScrollableContainer)
        if event.key in ("j", "down"):   sc.scroll_down(); event.stop()
        elif event.key in ("k", "up"):   sc.scroll_up();   event.stop()

# ---------------------------------------------------------------------------
# SimulationScreen
# ---------------------------------------------------------------------------

class SimulationScreen(Screen):
    BINDINGS = [Binding("escape", "app.pop_screen", "Back"),
                Binding("q",     "app.pop_screen", "Back")]
    CSS = """
    SimulationScreen { background: $background; }
    SimulationScreen #sim-hw  { height: 1; background: $background; padding: 0 1; }
    SimulationScreen #sim-box {
        height: 1fr; margin: 0 1;
        border: solid $primary; border-title-color: $primary; border-title-style: bold;
    }
    SimulationScreen DataTable { height: 1fr; background: $background; color: $foreground; }
    SimulationScreen DataTable > .datatable--header { background: $panel; color: $primary; text-style: bold; }
    SimulationScreen DataTable > .datatable--cursor { background: $secondary; color: $background; text-style: bold; }
    SimulationScreen #sim-status { height: 1; background: $panel; padding: 0 1; }
    """

    def __init__(self, info: SystemInfo, efficiency: Optional[float] = None) -> None:
        super().__init__()
        self._info = info; self._efficiency = efficiency
        self._items: list[Optional[str]] = [None] + sorted(
            PROFILES.keys(),
            key=lambda k: (
                PROFILES[k].jetpack_version is None,
                PROFILES[k].bandwidth_gbs,
                PROFILES[k].total_memory_gb,
                PROFILES[k].name,
            ))

    def compose(self) -> ComposeResult:
        yield Static(_hw_bar_markup(self._info, self._efficiency), id="sim-hw", markup=True)
        with Container(id="sim-box"):
            yield DataTable(id="sim-table", cursor_type="row", zebra_stripes=False)
        dim = _C["overlay0"]
        yield Static(
            f"[bold on {_C['teal']}]  SIM  [/bold on {_C['teal']}]"
            f"  [{dim}]j/k:nav  Enter:select  r:reset  q:back[/{dim}]",
            id="sim-status", markup=True)

    def on_mount(self) -> None:
        self.query_one("#sim-box").border_title = "Simulate Hardware — pick a profile"
        table = self.query_one("#sim-table", DataTable)
        table.add_column("",        key="cur",  width=2)
        table.add_column("Profile", key="name", width=28)
        table.add_column("RAM",     key="ram",  width=8)
        table.add_column("BW",      key="bw",   width=10)
        table.add_column("Accel",   key="acc",  width=10)
        t, o = _C["teal"], _C["overlay0"]
        is_sim  = self._info.is_simulated; cur_key = self._info.profile_key
        for key in self._items:
            if key is None:
                mk = "▶" if not is_sim else " "
                table.add_row(
                    Text(mk, style=t if not is_sim else o),
                    Text("Real Hardware (reset)",  style=_C["text"] if not is_sim else o),
                    Text("—", style=o), Text("—", style=o), Text("—", style=o),
                    key="__real__")
            else:
                p = PROFILES[key]; is_cur = (key == cur_key) and is_sim
                mk = "▶" if is_cur else " "
                accel = "DLA+CUDA" if p.has_dla else ("FP4" if p.has_fp4 else "CUDA")
                st = _C["text"] if is_cur else _C["subtext0"]
                table.add_row(
                    Text(mk, style=t if is_cur else o),
                    Text(p.name, style=st),
                    Text(f"{p.total_memory_gb:.0f} GB", style=st),
                    Text(f"{p.bandwidth_gbs:.0f} GB/s", style=_C["teal"] if is_cur else o),
                    Text(accel, style=_C["overlay1"]),
                    key=key)
        table.focus()

    def on_key(self, event: events.Key) -> None:
        table = self.query_one("#sim-table", DataTable)
        if event.key in ("j",):
            table.move_cursor(row=table.cursor_row + 1); event.stop()
        elif event.key in ("k",):
            table.move_cursor(row=max(0, table.cursor_row - 1)); event.stop()
        elif event.key == "enter":
            row_idx = table.cursor_row
            key = self._items[row_idx] if row_idx < len(self._items) else None
            self.app._apply_simulation(key)  # type: ignore[attr-defined]
            self.app.pop_screen(); event.stop()
        elif event.key == "r":
            self.app._apply_simulation(None)  # type: ignore[attr-defined]
            self.app.pop_screen(); event.stop()

# ---------------------------------------------------------------------------
# FilterPopupScreen
# ---------------------------------------------------------------------------

class FilterPopupScreen(ModalScreen):
    BINDINGS = [Binding("escape", "dismiss", "Cancel")]
    CSS = """
    FilterPopupScreen { align: center middle; }
    FilterPopupScreen #fbox {
        width: 52; height: auto;
        border: solid $primary; background: $background; padding: 1 2;
        border-title-color: $primary; border-title-style: bold;
    }
    FilterPopupScreen .f-hdr { color: $primary; text-style: bold; margin-top: 1; }
    FilterPopupScreen #ffoot { height: 1; background: $panel; padding: 0 1; margin-top: 1; }
    """

    def __init__(self, params_min: str, params_max: str,
                 mem_min: str, mem_max: str) -> None:
        super().__init__()
        self._pm = params_min; self._px = params_max
        self._mm = mem_min;    self._mx = mem_max

    def compose(self) -> ComposeResult:
        with Container(id="fbox"):
            yield Static("Params (B)", classes="f-hdr", markup=False)
            yield InlineField("Min", self._pm, unit="B", widget_id="f-pm")
            yield InlineField("Max", self._px, unit="B", widget_id="f-px")
            yield Static("Mem %", classes="f-hdr", markup=False)
            yield InlineField("Min", self._mm, unit="%", widget_id="f-mm")
            yield InlineField("Max", self._mx, unit="%", widget_id="f-mx")
            yield Static(
                f"[{_C['overlay0']}]Tab:field  Enter:apply  Esc:cancel[/{_C['overlay0']}]",
                id="ffoot", markup=True)

    def on_mount(self) -> None:
        self.query_one("#fbox").border_title = "Filter"
        self.query_one("#f-pm", InlineField).focus()

    def on_key(self, event: events.Key) -> None:
        if event.key == "enter":
            self.dismiss((
                self.query_one("#f-pm", InlineField).value,
                self.query_one("#f-px", InlineField).value,
                self.query_one("#f-mm", InlineField).value,
                self.query_one("#f-mx", InlineField).value,
            )); event.stop()
        elif event.key in ("tab", "shift+tab"):
            fields = list(self.query(InlineField))
            for i, f in enumerate(fields):
                if f.has_focus:
                    delta = -1 if "shift" in event.key else 1
                    fields[(i + delta) % len(fields)].focus(); break
            event.stop()

# ---------------------------------------------------------------------------
# AdvConfigScreen
# ---------------------------------------------------------------------------

class AdvConfigScreen(ModalScreen):
    BINDINGS = [Binding("escape", "dismiss", "Cancel")]
    CSS = """
    AdvConfigScreen { align: center middle; }
    AdvConfigScreen #abox {
        width: 48; height: auto;
        border: solid $primary; background: $background; padding: 1 2;
        border-title-color: $primary; border-title-style: bold;
    }
    AdvConfigScreen .a-note { color: $foreground; text-style: italic; margin-bottom: 1; }
    AdvConfigScreen #afoot  { height: 1; background: $panel; padding: 0 1; margin-top: 1; }
    """

    def __init__(self, efficiency: str) -> None:
        super().__init__(); self._eff = efficiency

    def compose(self) -> ComposeResult:
        with Container(id="abox"):
            yield Static("Scales the tok/s estimate. 1.0 = default.",
                         classes="a-note", markup=False)
            yield InlineField("Efficiency", self._eff, widget_id="a-eff")
            yield Static(
                f"[{_C['overlay0']}]Enter:apply  Esc:cancel[/{_C['overlay0']}]",
                id="afoot", markup=True)

    def on_mount(self) -> None:
        self.query_one("#abox").border_title = "Advanced Config"
        self.query_one("#a-eff", InlineField).focus()

    def on_key(self, event: events.Key) -> None:
        if event.key == "enter":
            self.dismiss(self.query_one("#a-eff", InlineField).value); event.stop()

# ---------------------------------------------------------------------------
# CompareScreen
# ---------------------------------------------------------------------------

class CompareScreen(Screen):
    BINDINGS = [Binding("escape", "app.pop_screen", "Back"),
                Binding("q",     "app.pop_screen", "Back")]
    CSS = """
    CompareScreen { background: $background; }
    CompareScreen #cmp-hw  { height: 1; background: $background; padding: 0 1; }
    CompareScreen #cmp-box {
        height: 1fr; margin: 0 1;
        border: solid $primary; border-title-color: $primary; border-title-style: bold;
    }
    CompareScreen DataTable { height: 1fr; background: $background; color: $foreground; }
    CompareScreen DataTable > .datatable--header { background: $panel; color: $primary; text-style: bold; }
    CompareScreen DataTable > .datatable--cursor { background: $secondary; color: $background; text-style: bold; }
    CompareScreen DataTable > .datatable--hover  { background: $surface; }
    CompareScreen #cmp-status { height: 1; background: $panel; padding: 0 1; }
    """

    def __init__(self, models: list[ModelSpec], info: SystemInfo,
                 efficiency: Optional[float] = None) -> None:
        super().__init__()
        self._models = models[:6]; self._info = info; self._efficiency = efficiency

    def compose(self) -> ComposeResult:
        yield Static(_hw_bar_markup(self._info, self._efficiency), id="cmp-hw", markup=True)
        with Container(id="cmp-box"):
            yield DataTable(id="cmp-table", cursor_type="row", zebra_stripes=True)
        dim = _C["overlay0"]
        yield Static(
            f"[bold on {_C['mauve']}]  COMPARE  [/bold on {_C['mauve']}]"
            f"  [{dim}]q/Esc:back[/{dim}]",
            id="cmp-status", markup=True)

    def on_mount(self) -> None:
        self.query_one("#cmp-box").border_title = f"Compare — {len(self._models)} models"
        table = self.query_one("#cmp-table", DataTable)
        table.add_column("Attribute", key="attr", width=14)
        for m in self._models:
            table.add_column(m.name[:18], key=m.name, width=20)
        results = {
            m.name: best_fit(m, self._info.profile, self._info.available_memory_gb, self._efficiency)
            for m in self._models
        }
        def row(label: str, vals: list) -> None:
            table.add_row(Text(label, style=_C["overlay1"]), *vals)
        def cell(text: str, style: str) -> Text:
            return Text(text, style=style)
        row("Params",    [cell(f"{m.params_b:.1f}B", _C["subtext0"]) for m in self._models])
        row("Best Quant",[cell(r.quant if r else "—", _C["text"])
                          for m in self._models for r in [results[m.name]]])
        row("Fit",       [cell(r.fit_level.value if r else "TooTight",
                               _fit_style(r.fit_level) if r else _C["red"])
                          for m in self._models for r in [results[m.name]]])
        row("Mem %",     [cell(f"{r.memory_utilization*100:.0f}%" if r else ">100%",
                               _C["teal"] if r and r.memory_utilization < 0.9 else _C["yellow"])
                          for m in self._models for r in [results[m.name]]])
        row("Est. TPS",  [cell(f"{r.estimated_tps:.1f}" if r else "—", _C["green"])
                          for m in self._models for r in [results[m.name]]])
        row("Size (GB)", [cell(f"{r.model_size_gb:.2f}" if r else "—", _C["overlay0"])
                          for m in self._models for r in [results[m.name]]])
        row("Context",   [cell(f"{m.context_len // 1024}k" if m.context_len >= 1024 else str(m.context_len), _C["subtext0"]) for m in self._models])

# ---------------------------------------------------------------------------
# PlanScreen
# ---------------------------------------------------------------------------

class PlanScreen(Screen):
    BINDINGS = [Binding("escape", "app.pop_screen", "Back"),
                Binding("q",     "app.pop_screen", "Back")]
    CSS = """
    PlanScreen { background: $background; }
    PlanScreen #phw-bar { height: 1; background: $background; padding: 0 1; }
    PlanScreen #plan-container {
        height: 1fr; border: solid $primary; margin: 0 1;
        border-title-color: $primary; border-title-style: bold;
    }
    PlanScreen #plan-scroll { height: 1fr; padding: 1 2; }
    PlanScreen .note  { color: $foreground; text-style: italic; margin-bottom: 1; }
    PlanScreen .s-hdr { color: $primary; text-style: bold; margin-top: 1; margin-bottom: 0; }
    PlanScreen InlineField { height: 1; }
    PlanScreen InlineField:focus { background: $surface; }
    PlanScreen #plan-results { margin-top: 1; }
    PlanScreen #pstatus { height: 1; background: $panel; padding: 0 1; }
    """

    def __init__(self, model: ModelSpec, info: SystemInfo,
                 efficiency: Optional[float] = None) -> None:
        super().__init__()
        self._model = model; self._info = info; self._efficiency = efficiency
        bf = best_fit(model, info.profile, info.available_memory_gb, efficiency)
        self._init_quant = bf.quant if bf else _QUANT_NAMES[3]

    def compose(self) -> ComposeResult:
        yield Static(_hw_bar_markup(self._info, self._efficiency), id="phw-bar", markup=True)
        with Container(id="plan-container"):
            with ScrollableContainer(id="plan-scroll"):
                yield Static("Estimate-based using jetfit bandwidth/efficiency heuristics.",
                             classes="note")
                yield Static("Inputs", classes="s-hdr")
                yield InlineField("Context",    "4096",           unit="tokens",  widget_id="ctx-field")
                yield InlineField("Quant",      self._init_quant, choices=_QUANT_NAMES, widget_id="quant-field")
                yield InlineField("Target TPS", "10",             unit="tok/s",   widget_id="tps-field")
                yield Static("", id="plan-results", markup=True)
        dim = _C["overlay0"]
        yield Static(
            f"[bold on {_C['teal']}]  PLAN  [/bold on {_C['teal']}]"
            f"  [{dim}]Tab:field  ←→:quant  type:edit  Esc/q:back[/{dim}]",
            id="pstatus", markup=True)

    def on_mount(self) -> None:
        self.query_one("#plan-container").border_title = f"Plan: {self._model.name}"
        self._update_results()
        self.query_one("#ctx-field", InlineField).focus()

    @on(InlineField.Changed)
    def _recompute(self, _: object) -> None:
        self._update_results()

    def _update_results(self) -> None:
        try:
            quant   = self.query_one("#quant-field", InlineField).value
            tps_raw = self.query_one("#tps-field",   InlineField).value
        except Exception:
            return
        try:
            target_tps = float(tps_raw)
        except ValueError:
            target_tps = 10.0
        model, info, eff = self._model, self._info, self._efficiency
        current = score_model(model, quant, info.profile, info.available_memory_gb, eff)
        min_key: Optional[str] = None; rec_key: Optional[str] = None
        for key, profile in sorted(PROFILES.items(), key=lambda x: x[1].total_memory_gb):
            r = score_model(model, quant, profile, profile.total_memory_gb, eff)
            if min_key is None and r.fit_level != FitLevel.TOO_TIGHT:
                min_key = key
            if rec_key is None and r.fit_level in (FitLevel.PERFECT, FitLevel.GOOD):
                rec_key = key
        gpu_fits = current.fit_level != FitLevel.TOO_TIGHT
        gpu_tps  = current.estimated_tps if gpu_fits else 0.0
        dla_tps: Optional[float] = gpu_tps * 0.35 if (info.profile.has_dla and gpu_fits) else None
        cpu_tps: Optional[float] = max(0.2, gpu_tps * 0.05) if gpu_fits else None
        deltas: list[tuple[float, str, FitLevel]] = []
        for key, profile in sorted(PROFILES.items(), key=lambda x: x[1].total_memory_gb):
            if profile.total_memory_gb <= info.total_memory_gb: continue
            r = score_model(model, quant, profile, profile.total_memory_gb, eff)
            if _FIT_ORDER.index(r.fit_level) < _FIT_ORDER.index(current.fit_level):
                deltas.append((profile.total_memory_gb - info.total_memory_gb, profile.name, r.fit_level))
            if len(deltas) >= 3: break
        def tc(tps: float) -> str:
            return _C["green"] if tps >= target_tps else _C["yellow"]
        lines: list[str] = []
        lines.append(f"[bold {_C['teal']}]Minimum Hardware[/bold {_C['teal']}]")
        if min_key:
            p = PROFILES[min_key]
            lines.append(f"  Mem: [white]{p.total_memory_gb:.0f} GB[/white]  BW: {p.bandwidth_gbs:.0f} GB/s  [dim]({p.name})[/dim]")
        else:
            lines.append(f"  [{_C['red']}]Cannot fit on any known hardware[/{_C['red']}]")
        lines += ["", f"[bold {_C['teal']}]Recommended Hardware[/bold {_C['teal']}]"]
        if rec_key:
            p = PROFILES[rec_key]
            lines.append(f"  Mem: [white]{p.total_memory_gb:.0f} GB[/white]  BW: {p.bandwidth_gbs:.0f} GB/s  [dim]({p.name})[/dim]")
        else:
            lines.append(f"  [{_C['yellow']}]No Perfect/Good profile at this quant[/{_C['yellow']}]")
        lines += ["", f"[bold {_C['teal']}]Run Paths[/bold {_C['teal']}]"]
        if gpu_fits:
            lines.append(f"  [dim]GPU (unified):[/dim]  [{_C['green']}]yes[/{_C['green']}]  tps=[{tc(gpu_tps)}]{gpu_tps:.1f}[/{tc(gpu_tps)}]  fit={_fit_markup(current.fit_level)}")
        else:
            lines.append(f"  [dim]GPU (unified):[/dim]  [{_C['red']}]no[/{_C['red']}]  (TooTight)")
        if info.profile.has_dla:
            if dla_tps is not None:
                lines.append(f"  [dim]DLA-offload:  [/dim]  [{_C['green']}]yes[/{_C['green']}]  tps=[{tc(dla_tps)}]{dla_tps:.1f}[/{tc(dla_tps)}]")
            else:
                lines.append(f"  [dim]DLA-offload:  [/dim]  [{_C['red']}]no[/{_C['red']}]")
        else:
            lines.append("  [dim]DLA-offload:   N/A (no DLA)[/dim]")
        if cpu_tps is not None:
            lines.append(f"  [dim]CPU-only:      [/dim]  [{_C['green']}]yes[/{_C['green']}]  tps=[{tc(cpu_tps)}]{cpu_tps:.1f}[/{tc(cpu_tps)}]  [dim](est.)[/dim]")
        else:
            lines.append(f"  [dim]CPU-only:      [/dim]  [{_C['red']}]no[/{_C['red']}]")
        lines += ["", f"[bold {_C['teal']}]Power Modes[/bold {_C['teal']}]"]
        for label, factor in [("10W", 0.65), ("15W", 1.00), ("25W", 1.25)]:
            scaled = gpu_tps * factor if gpu_fits else 0.0
            lines.append(f"  [dim]{label:5s}[/dim]  tps=[{tc(scaled)}]{scaled:.1f}[/{tc(scaled)}]")
        if deltas:
            lines += ["", f"[bold {_C['teal']}]Upgrade Deltas[/bold {_C['teal']}]"]
            for delta, pname, flevel in deltas:
                fc = _fit_style(flevel)
                lines.append(f"  +{delta:.0f} GB  →  [{fc}]{flevel.value}[/{fc}]  [dim]({pname})[/dim]")
        self.query_one("#plan-results", Static).update("\n".join(lines))

# ---------------------------------------------------------------------------
# DetailScreen
# ---------------------------------------------------------------------------

class DetailScreen(Screen):
    BINDINGS = [
        Binding("escape", "app.pop_screen", "Back"),
        Binding("q",      "app.pop_screen", "Back"),
        Binding("j",      "quant_next",     "Next quant",  show=False),
        Binding("k",      "quant_prev",     "Prev quant",  show=False),
        Binding("down",   "quant_next",     "Next quant",  show=False),
        Binding("up",     "quant_prev",     "Prev quant",  show=False),
    ]
    CSS = """
    DetailScreen { background: $background; }
    DetailScreen #dhw-bar { height: 1; background: $background; padding: 0 1; }
    DetailScreen #detail-outer { height: 1fr; margin: 0 1; }
    DetailScreen #left-panel {
        width: 1fr; margin-right: 1;
        border: solid $primary; border-title-color: $primary; border-title-style: bold;
        padding: 1 2;
    }
    DetailScreen #right-panel {
        width: 1fr;
        border: solid $primary; border-title-color: $primary; border-title-style: bold;
        padding: 1 2;
    }
    DetailScreen #dstatus { height: 1; background: $panel; padding: 0 1; }
    """

    def __init__(self, model: ModelSpec, info: SystemInfo,
                 efficiency: Optional[float] = None) -> None:
        super().__init__()
        self._model = model; self._info = info; self._efficiency = efficiency
        bf = best_fit(model, info.profile, info.available_memory_gb, efficiency)
        self._best_quant = bf.quant if bf else _QUANT_NAMES[0]
        self._sel_idx    = _QUANT_NAMES.index(self._best_quant)

    @property
    def _sel_quant(self) -> str:
        return _QUANT_NAMES[self._sel_idx]

    def action_quant_next(self) -> None:
        self._sel_idx = min(self._sel_idx + 1, len(_QUANT_NAMES) - 1)
        self._render_panels()

    def action_quant_prev(self) -> None:
        self._sel_idx = max(self._sel_idx - 1, 0)
        self._render_panels()

    def compose(self) -> ComposeResult:
        yield Static(_hw_bar_markup(self._info, self._efficiency), id="dhw-bar", markup=True)
        with Horizontal(id="detail-outer"):
            yield Static("", id="left-panel",  markup=True)
            yield Static("", id="right-panel", markup=True)
        dim = _C["overlay0"]
        yield Static("", id="dstatus", markup=True)

    def on_mount(self) -> None:
        self.query_one("#left-panel").border_title  = "Model Info"
        self.query_one("#right-panel").border_title = "Quant Scores"
        self._render_panels()

    def _render_panels(self) -> None:
        model = self._model; info = self._info; eff = self._efficiency
        sel   = self._sel_quant
        bf    = best_fit(model, info.profile, info.available_memory_gb, eff)
        t  = _C["teal"]; tx = _C["text"]; o0 = _C["overlay0"]; o1 = _C["overlay1"]
        hi = _C["yellow"]; gr = _C["green"]

        # Selected quant's FitResult
        cur = score_model(model, sel, info.profile, info.available_memory_gb, eff)
        is_best_sel = (sel == self._best_quant)

        def kv(k: str, v: str, note: str = "") -> str:
            n = f"  [{o0}]{note}[/{o0}]" if note else ""
            return f"[{t}]{k:<14}[/{t}][{tx}]{v}[/{tx}]{n}"

        accel    = "DLA+CUDA" if info.profile.has_dla else ("FP4+CUDA" if info.profile.has_fp4 else "CUDA")
        run_mode = "DLA+GPU"  if info.profile.has_dla else ("FP4+GPU"  if info.profile.has_fp4 else "GPU")
        if cur.fit_level == FitLevel.TOO_TIGHT:
            run_mode = "CPU-only"

        # ── Score breakdown (for selected quant) ────────────────────────────
        all_results = recommend(model, info.profile, info.available_memory_gb, eff)
        result_map  = {r.quant: r for r in all_results}
        global_max  = max(
            (best_fit(m, info.profile, info.available_memory_gb, eff).estimated_tps
             for m in KNOWN_MODELS
             if best_fit(m, info.profile, info.available_memory_gb, eff) is not None),
            default=1.0,
        )
        def _score_parts(r: Optional[FitResult]) -> tuple[int,int,int,int]:
            if r is None or r.fit_level == FitLevel.TOO_TIGHT:
                return 0, 0, 0, 0
            spd  = min(100, int(r.estimated_tps / max(global_max, 0.01) * 100))
            fit  = {FitLevel.PERFECT: 100, FitLevel.GOOD: 70, FitLevel.MARGINAL: 35}[r.fit_level]
            qual = _QUANT_QUALITY.get(r.quant, 50)
            return int(spd * 0.45 + fit * 0.35 + qual * 0.20), spd, fit, qual

        scores_all = sorted(
            [_score_parts(best_fit(m, info.profile, info.available_memory_gb, eff))[0]
             for m in KNOWN_MODELS],
            reverse=True,
        )
        my_score, spd_sc, fit_sc, qual_sc = _score_parts(cur)
        rank = scores_all.index(my_score) + 1 if my_score in scores_all else len(scores_all)

        # ── Minimum hardware (for selected quant) ───────────────────────────
        min_hw = None
        for key, profile in sorted(PROFILES.items(), key=lambda x: x[1].total_memory_gb):
            r = score_model(model, sel, profile, profile.total_memory_gb, eff)
            if r.fit_level != FitLevel.TOO_TIGHT:
                min_hw = profile.name
                break

        # ── Left panel ───────────────────────────────────────────────────────
        left: list[str] = [
            kv("Model",    model.name),
            kv("Family",   _model_family(model.name)),
            kv("Params",   f"{model.params_b:.1f}B", "billion parameters"),
            kv("Platform", info.profile.name),
            kv("Accel",    accel, "hardware accelerator type"),
            kv("RAM",      f"{info.available_memory_gb:.1f} / {info.total_memory_gb:.0f} GB",
               "available / total"),
            "",
        ]

        if not is_best_sel:
            left.append(f"  [{o0}]★ recommended: {self._best_quant}[/{o0}]")

        fc      = _fit_style(cur.fit_level)
        free_gb = info.available_memory_gb - cur.total_memory_gb
        label   = "Best Quant" if is_best_sel else "Viewing"
        note    = ("highest quality that fits" if is_best_sel else "manually selected")
        left += [
            kv(label,       sel, note),
            kv("Fit",       f"[{fc}]{cur.fit_level.value}[/{fc}]", "memory fit level"),
            kv("Mem Total", f"{cur.memory_utilization*100:.0f}%  ({cur.total_memory_gb:.1f} GB)",
               f"of {info.available_memory_gb:.0f} GB avail"),
            kv("  Weights", f"{cur.effective_size_gb:.1f} GB",
               "model weights (FP4 halved)" if info.profile.has_fp4 else "model weights"),
            kv("  KV Cache",f"{cur.kv_cache_gb:.1f} GB", f"fp16 @ 4k ctx  (max {model.context_len//1024}k)"),
            kv("  Free",    f"[{gr if free_gb >= 0 else _C['red']}]{free_gb:.1f} GB[/]",
               "headroom after load"),
            kv("Speed",     f"[{t}]{cur.estimated_tps:.1f} tok/s[/{t}]",
               "bandwidth÷size estimate"),
            kv("Run Mode",  run_mode, "inference execution path"),
        ]
        if info.profile.has_dla:
            left.append(kv("DLA Speed", f"{cur.estimated_tps * 0.35:.1f} tok/s",
                           "NVDLA core only (35% of GPU)"))

        if my_score > 0:
            sc_color = hi if my_score >= 75 else (t if my_score >= 50 else o1)
            left += [
                "",
                f"[{o1}]── Score ──────────────────────[/{o1}]",
                kv("Overall", f"[{sc_color}]{my_score}[/{sc_color}] / 100",
                   f"rank #{rank} of {len(KNOWN_MODELS)}"),
                kv("  Speed", f"{spd_sc}", "tok/s vs fastest on hw  ×0.45"),
                kv("  Fit",   f"{fit_sc}", "memory fit level        ×0.35"),
                kv("  Quant", f"{qual_sc}", "quantization quality    ×0.20"),
            ]
        if min_hw:
            left += ["", kv("Min HW", min_hw, "smallest platform that runs this")]
        if eff:
            left += ["", f"[{o0}]✓ calibrated  efficiency={eff:.2f}[/{o0}]"]

        self.query_one("#left-panel", Static).update("\n".join(left))

        # ── Right panel: quant table + hardware fit ──────────────────────────
        right: list[str] = [
            f"[{o1}]{'Quant':<10}{'Total%':>6}{'Total GB':>9}{'TPS':>7}  {'Quality':>7}  Fit[/{o1}]",
            f"[{_C['surface1']}]{'─'*56}[/{_C['surface1']}]",
        ]
        for qname in _QUANT_NAMES:
            r     = result_map.get(qname) or score_model(model, qname, info.profile, info.available_memory_gb, eff)
            fc    = _fit_style(r.fit_level)
            qual  = _QUANT_QUALITY.get(r.quant, 50)
            qc    = gr if qual >= 80 else (hi if qual >= 55 else o1)
            is_sel  = (r.quant == sel)
            is_best = (r.quant == self._best_quant)
            if is_sel and is_best:
                mk = "▶★"
            elif is_sel:
                mk = "▶ "
            elif is_best:
                mk = " ★"
            else:
                mk = "  "
            bar_filled = round(qual / 10)
            bar  = f"[{qc}]{'█' * bar_filled}[/{qc}][{o0}]{'░' * (10 - bar_filled)}[/{o0}]"
            if is_sel:
                qcol = f"[bold {hi}]{mk}{r.quant:<8}[/bold {hi}]"
            elif is_best:
                qcol = f"[bold {tx}]{mk}{r.quant:<8}[/bold {tx}]"
            else:
                qcol = f"[{o0}]{mk}{r.quant:<8}[/{o0}]"
            right.append(
                f"{qcol}[{o1}]{r.memory_utilization*100:>5.0f}%[/{o1}]"
                f"[{o0}]{r.total_memory_gb:>8.2f}[/{o0}]"
                f"[{t}]{r.estimated_tps:>7.1f}[/{t}]"
                f"  {bar}  [{fc}]{r.fit_level.value}[/{fc}]"
            )
        right += ["", f"[bold {t}]── Hardware Fit ({sel}) ──[/bold {t}]"]
        for key, profile in sorted(PROFILES.items(), key=lambda x: x[1].total_memory_gb):
            r   = score_model(model, sel, profile, profile.total_memory_gb, eff)
            fc  = _fit_style(r.fit_level)
            cur_tag = f" [{t}]◀ current[/{t}]" if key == info.profile_key else ""
            right.append(
                f"  [{o0}]{profile.total_memory_gb:>4.0f} GB[/{o0}]"
                f"  [{fc}]{r.fit_level.value:<9}[/{fc}]"
                f"[{o1}]{profile.name}[/{o1}]{cur_tag}"
            )
        self.query_one("#right-panel", Static).update("\n".join(right))

        # ── Status bar ───────────────────────────────────────────────────────
        dim = _C["overlay0"]
        rec_note = f"  [{dim}]★={self._best_quant} recommended[/{dim}]" if not is_best_sel else ""
        self.query_one("#dstatus", Static).update(
            f"[bold on {_C['mauve']}]  DETAIL  [/bold on {_C['mauve']}]"
            f"  [{dim}]j/k:quant  Esc/q:back[/{dim}]{rec_note}"
        )

# ---------------------------------------------------------------------------
# Main App
# ---------------------------------------------------------------------------

class JetfitApp(App[None]):
    TITLE     = "jetfit"
    SUB_TITLE = ""
    CSS_PATH  = None

    # All CSS uses Textual theme variables so every registered theme auto-updates
    CSS = """
    Screen { background: $background; }
    #hw-bar     { height: 1; background: $panel; padding: 0 1; }
    #filter-bar { height: 3; background: $background; padding: 0 1 0 1; }
    .fpanel {
        border: solid $primary; border-title-color: $primary; border-title-style: bold;
        background: $background; height: 3; padding: 0 1;
    }
    .fpanel:focus-within { border: solid $accent; border-title-color: $accent; }
    #search-panel    { width: 1fr; margin-right: 1; }
    .filter-panel    { width: 16; margin-right: 1; }
    .filter-panel-sm { width: 13; margin-right: 1; }
    #search-panel Input  { height: 1; background: transparent; border: none; color: $foreground; padding: 0; }
    .fpanel Select       { height: 1; background: $background; color: $foreground; width: 100%; border: none; }
    #models-container {
        height: 1fr; border: solid $primary;
        border-title-color: $primary; border-title-style: bold; margin: 0 1;
    }
    DataTable { height: 1fr; background: $background; color: $foreground; }
    DataTable > .datatable--header { background: $panel; color: $primary; text-style: bold; }
    DataTable > .datatable--cursor { background: $secondary; color: $background; text-style: bold; }
    DataTable > .datatable--hover  { background: $surface; }
    #status-bar { height: 1; background: $panel; padding: 0 1; color: $foreground; }
    """

    search_text:   reactive[str] = reactive("",    init=False)
    fit_filter:    reactive[str] = reactive("All", init=False)
    sort_order:    reactive[str]  = reactive("score", init=False)
    sort_desc:     reactive[bool] = reactive(True,    init=False)
    family_filter: reactive[str]  = reactive("All",   init=False)
    size_filter:   reactive[str]  = reactive("All",   init=False)

    def __init__(self) -> None:
        super().__init__()
        self._info: SystemInfo = detect_hardware()
        self._sim_info: Optional[SystemInfo] = None
        self._efficiency: Optional[float] = _load_efficiency(self._info.profile_key)
        self._eff_override: Optional[float] = None
        self._filtered: list[ModelSpec] = list(KNOWN_MODELS)
        self._marked: set[str] = set()
        self._mode: AppMode = AppMode.NORMAL
        self._visual_start: int = 0
        self._params_min: Optional[float] = None
        self._params_max: Optional[float] = None
        self._mem_min: Optional[float] = None
        self._mem_max: Optional[float] = None
        self._theme_name: str = _load_theme_name()

    # ── Theme ────────────────────────────────────────────────────────────────

    def watch_theme(self, theme: str) -> None:
        """Textual calls this whenever app.theme changes."""
        if theme in _TEXTUAL_THEMES:
            self._theme_name = theme
            _sync_colors(_TEXTUAL_THEMES[theme])
            _save_theme_name(theme)
        # Re-render all Rich markup widgets and sync Theme selector
        try:
            self._update_hw_bar()
            self._refresh_table()
            self._update_status()
            self.query_one("#theme-select", Select).value = self._theme_name
        except Exception:
            pass

    # ── effective hardware / efficiency ──────────────────────────────────────
    @property
    def _hw(self) -> SystemInfo:
        return self._sim_info if self._sim_info else self._info

    @property
    def _eff(self) -> Optional[float]:
        return self._eff_override if self._eff_override is not None else self._efficiency

    # ── Compose ──────────────────────────────────────────────────────────────

    def compose(self) -> ComposeResult:
        yield Static("", id="hw-bar", markup=True)
        with Horizontal(id="filter-bar"):
            with Container(id="search-panel", classes="fpanel"):
                yield Input(placeholder="", id="search-input")
            with Container(classes="fpanel filter-panel"):
                yield Select(
                    options=[(f, f) for f in _FAMILIES],
                    value="All", id="family-select", allow_blank=False, compact=True)
            with Container(classes="fpanel filter-panel-sm"):
                yield Select(
                    options=[(s, s) for s in _SIZES],
                    value="All", id="size-select", allow_blank=False, compact=True)
            with Container(classes="fpanel filter-panel-sm", id="sort-panel"):
                yield Select(
                    options=[("Score","score"),("tok/s","tps"),("Mem %","mem"),("Params","params"),("Model","name")],
                    value="score", id="sort-select", allow_blank=False, compact=True)
            with Container(classes="fpanel filter-panel-sm"):
                yield Select(
                    options=[("All","All"),("Perfect","Perfect"),
                              ("Good","Good"),("Marginal","Marginal")],
                    value="All", id="fit-select", allow_blank=False, compact=True)
            with Container(classes="fpanel filter-panel-sm", id="theme-panel"):
                yield Select(
                    options=[(n, n) for n in _THEME_CYCLE],
                    value=self._theme_name, id="theme-select", allow_blank=False, compact=True)
        with Container(id="models-container"):
            yield DataTable(id="model-table", cursor_type="row", zebra_stripes=False)
        yield Static("", id="status-bar", markup=True)

    def on_mount(self) -> None:
        # Register all themes with Textual
        for t in _TEXTUAL_THEMES.values():
            self.register_theme(t)
        # Apply saved theme (triggers watch_theme)
        self.theme = self._theme_name

        panels = list(self.query(".fpanel").results())
        if len(panels) >= 6:
            panels[0].border_title = "Search"
            panels[1].border_title = "Provider [r]"
            panels[2].border_title = "Size [b]"
            panels[3].border_title = "Sort [s]"
            panels[4].border_title = "Fit [f]"
            panels[5].border_title = "Theme [t]"

        table = self.query_one("#model-table", DataTable)
        self._ck: dict[str, Any] = {}
        self._ck["accel"]  = table.add_column("",        key="accel",  width=2)
        self._ck["name"]   = table.add_column("Model",   key="name",   width=22)
        self._ck["params"] = table.add_column("Params",  key="params", width=7)
        self._ck["score"]  = table.add_column("Score",   key="score",  width=6)
        self._ck["tps"]    = table.add_column("tok/s",   key="tps",    width=7)
        self._ck["quant"]  = table.add_column("Quant",   key="quant",  width=8)
        self._ck["mem"]    = table.add_column("Mem %",   key="mem",    width=7)
        self._ck["fit"]    = table.add_column("Fit",     key="fit",    width=10)
        self._refresh_table()
        self._update_status()
        table.focus()

    # ── Table rendering ───────────────────────────────────────────────────────

    def _refresh_table(self) -> None:
        table = self.query_one("#model-table", DataTable)
        saved_row = table.cursor_row
        table.clear()
        hw, eff = self._hw, self._eff
        search = self.search_text.lower()
        scored: list[tuple[ModelSpec, Optional[FitResult]]] = []
        for m in KNOWN_MODELS:
            if search and search not in m.name.lower(): continue
            if self.family_filter != "All" and _model_family(m.name) != self.family_filter: continue
            if self.size_filter   != "All" and _model_size_label(m.params_b) != self.size_filter: continue
            if self._params_min is not None and m.params_b < self._params_min: continue
            if self._params_max is not None and m.params_b > self._params_max: continue
            r = best_fit(m, hw.profile, hw.available_memory_gb, eff)
            if self.fit_filter != "All":
                if r is None or r.fit_level.value != self.fit_filter: continue
            if self._mem_min is not None and (r is None or r.memory_utilization * 100 < self._mem_min): continue
            if self._mem_max is not None and (r is None or r.memory_utilization * 100 > self._mem_max): continue
            scored.append((m, r))
        sort = self.sort_order
        desc = self.sort_desc
        # Pre-calculate scores (normalized to fitted models only)
        max_tps = max((r.estimated_tps for _, r in scored if r), default=1.0)
        def _calc_score(r: Optional[FitResult]) -> int:
            if r is None or r.fit_level == FitLevel.TOO_TIGHT:
                return 0
            speed = min(100, int(r.estimated_tps / max(max_tps, 0.01) * 100))
            fit   = {FitLevel.PERFECT: 100, FitLevel.GOOD: 70, FitLevel.MARGINAL: 35}[r.fit_level]
            qual  = _QUANT_QUALITY.get(r.quant, 50)
            return int(speed * 0.45 + fit * 0.35 + qual * 0.20)
        scores = [_calc_score(r) for _, r in scored]
        if sort == "score":
            paired = sorted(zip(scored, scores), key=lambda x: x[1], reverse=desc)
            scored = [s for s, _ in paired]
            scores = [sc for _, sc in paired]
        elif sort == "tps":
            scored.sort(key=lambda x: (x[1].estimated_tps if x[1] else 0.0), reverse=desc)
            scores = [_calc_score(r) for _, r in scored]
        elif sort == "mem":
            scored.sort(key=lambda x: (x[1].memory_utilization if x[1] else 999.0), reverse=desc)
            scores = [_calc_score(r) for _, r in scored]
        elif sort == "params":
            scored.sort(key=lambda x: x[0].params_b, reverse=desc)
            scores = [_calc_score(r) for _, r in scored]
        elif sort == "name":
            scored.sort(key=lambda x: x[0].name, reverse=desc)
            scores = [_calc_score(r) for _, r in scored]
        self._filtered = [m for m, _ in scored]
        # Visual mode range
        cur = saved_row; v_lo = v_hi = -1
        if self._mode == AppMode.VISUAL:
            v_lo = min(self._visual_start, cur); v_hi = max(self._visual_start, cur)
        cal_mark   = "*" if eff else ""
        _fit_dot_color = {
            FitLevel.PERFECT:   _C["green"],
            FitLevel.GOOD:      _C["teal"],
            FitLevel.MARGINAL:  _C["yellow"],
            FitLevel.TOO_TIGHT: _C["red"],
        }
        for idx, ((model, result), sc) in enumerate(zip(scored, scores)):
            is_marked  = model.name in self._marked
            in_visual  = (self._mode == AppMode.VISUAL and v_lo <= idx <= v_hi)
            if is_marked:
                accel_char = "◆"; ac_style = _C["lavender"]
            elif in_visual:
                accel_char = "▷"; ac_style = _C["yellow"]
            else:
                accel_char = "●"
                ac_style   = (_fit_dot_color[result.fit_level] if result
                              else _C["red"])
            sc_style   = (_C["yellow"] if sc >= 75 else
                          (_C["teal"]  if sc >= 50 else
                           (_C["overlay1"] if sc > 0 else _C["overlay0"])))
            if result is None:
                table.add_row(
                    Text(accel_char,               style=ac_style),
                    Text(model.name[:22],           style=_C["overlay1"]),
                    Text(f"{model.params_b:.1f}B",  style=_C["overlay0"]),
                    Text("—",  style=_C["overlay0"]),
                    Text("—",  style=_C["overlay0"]), Text("—", style=_C["overlay0"]),
                    Text(">100%", style=_C["red"]), Text("TooTight", style=_C["red"]),
                    key=model.name)
            else:
                fit_color = _fit_dot_color[result.fit_level]
                table.add_row(
                    Text(accel_char,                                  style=ac_style),
                    Text(model.name[:22],                              style=_C["text"]),
                    Text(f"{model.params_b:.1f}B",                    style=_C["subtext0"]),
                    Text(str(sc),                                      style=sc_style),
                    Text(f"{result.estimated_tps:.1f}{cal_mark}",     style=_C["teal"]),
                    Text(result.quant,                                style=_C["subtext0"]),
                    Text(f"{result.memory_utilization*100:.0f}%",     style=_C["overlay1"]),
                    Text(result.fit_level.value,                      style=fit_color),
                    key=model.name)
        total = len(KNOWN_MODELS); shown = len(scored)
        marks = f"  [{_C['lavender']}]{len(self._marked)} marked[/{_C['lavender']}]" if self._marked else ""
        try:
            self.query_one("#models-container").border_title = f"Models ({shown}/{total}){marks}"
        except Exception:
            pass
        if table.row_count > 0:
            table.move_cursor(row=min(saved_row, table.row_count - 1))
        self._update_sort_header()

    def _update_sort_header(self) -> None:
        """Highlight the active sort column header using stored ColumnKey objects."""
        try:
            table = self.query_one("#model-table", DataTable)
            col_labels: dict[str, tuple[str, str | None]] = {
                "name":   ("Model",  "name"),
                "params": ("Params", "params"),
                "score":  ("Score",  "score"),
                "tps":    ("tok/s",  "tps"),
                "quant":  ("Quant",  None),
                "mem":    ("Mem %",  "mem"),
                "fit":    ("Fit",    None),
            }
            hi   = _C["yellow"]
            norm = _C["teal"]
            for key_str, (label, sort_key) in col_labels.items():
                ck = self._ck.get(key_str)
                if ck is None or ck not in table.columns:
                    continue
                col = table.columns[ck]
                if sort_key and sort_key == self.sort_order:
                    arrow = "↓" if self.sort_desc else "↑"
                    col.label = Text(f"{label} {arrow}", style=f"bold {hi}")
                else:
                    col.label = Text(label, style=f"bold {norm}")
            table.refresh(layout=True)
        except Exception:
            pass

    def _update_hw_bar(self) -> None:
        try:
            self.query_one("#hw-bar", Static).update(_hw_bar_markup(self._hw, self._eff))
        except Exception:
            pass

    def _update_status(self) -> None:
        dim = _C["overlay1"]
        if self._mode == AppMode.VISUAL:
            table = self.query_one("#model-table", DataTable)
            cur = table.cursor_row
            n_sel = abs(self._visual_start - cur) + 1
            text = (
                f"[bold on {_C['yellow']}]  VISUAL  [/bold on {_C['yellow']}]"
                f"  [{_C['yellow']}]{n_sel} rows[/{_C['yellow']}]"
                f"  [{dim}]j/k:extend  m:mark  c:compare  v/Esc:exit[/{dim}]"
            )
        else:
            sim_note = f"  [{_C['yellow']}]SIM:{self._sim_info.profile.name}[/{_C['yellow']}]" if self._sim_info else ""
            text = (
                f"[bold black on {_C['green']}]  NORMAL  [/bold black on {_C['green']}]"
                f"  [{dim}]jk:nav  ⏎:detail  p:plan  m:mark  c:cmp  v:vis[/{dim}]"
                f"  [{dim}]/:srch  r:prov  b:size  f:fit  s:sort  -:flip↑↓  F:filter  S:sim  A:adv  t:theme  h:help  q:quit[/{dim}]"
                f"{sim_note}"
            )
        try:
            self.query_one("#status-bar", Static).update(text)
        except Exception:
            pass

    # ── Reactive watchers ─────────────────────────────────────────────────────

    def watch_search_text  (self, _: str)  -> None: self._refresh_table()
    def watch_fit_filter   (self, _: str)  -> None: self._refresh_table()
    def watch_sort_order   (self, _: str)  -> None: self._refresh_table()
    def watch_sort_desc    (self, _: bool) -> None: self._refresh_table()
    def watch_family_filter(self, _: str)  -> None: self._refresh_table()
    def watch_size_filter  (self, _: str)  -> None: self._refresh_table()

    # ── Select events ─────────────────────────────────────────────────────────

    @on(Input.Changed, "#search-input")
    def _on_search(self, e: Input.Changed) -> None:
        self.search_text = e.value

    @on(Select.Changed, "#family-select")
    def _on_family(self, e: Select.Changed) -> None:
        if e.value is not False: self.family_filter = str(e.value)

    @on(Select.Changed, "#size-select")
    def _on_size(self, e: Select.Changed) -> None:
        if e.value is not False: self.size_filter = str(e.value)

    @on(Select.Changed, "#fit-select")
    def _on_fit(self, e: Select.Changed) -> None:
        if e.value is not False: self.fit_filter = str(e.value)

    @on(Select.Changed, "#sort-select")
    def _on_sort(self, e: Select.Changed) -> None:
        if e.value is not False: self.sort_order = str(e.value)

    @on(Select.Changed, "#theme-select")
    def _on_theme_select(self, e: Select.Changed) -> None:
        if e.value is not False: self.theme = str(e.value)

    # ── Key handler ───────────────────────────────────────────────────────────

    def on_key(self, event: events.Key) -> None:
        if len(self.screen_stack) > 1:
            return
        if isinstance(self.focused, Input):
            if event.key == "escape":
                self.query_one("#search-input", Input).value = ""
                self.query_one("#model-table", DataTable).focus()
                event.stop()
            elif event.key in ("enter", "tab", "down"):
                # Keep search text, move focus to table
                self.query_one("#model-table", DataTable).focus()
                event.stop()
            return
        table = self.query_one("#model-table", DataTable)

        if self._mode == AppMode.VISUAL:
            if event.key == "j":
                table.move_cursor(row=table.cursor_row + 1)
                self._refresh_table(); self._update_status(); event.stop()
            elif event.key == "k":
                table.move_cursor(row=max(0, table.cursor_row - 1))
                self._refresh_table(); self._update_status(); event.stop()
            elif event.key == "m":
                self._mark_visual_range(); self._exit_visual(); event.stop()
            elif event.key == "c":
                self._compare_visual_range(); self._exit_visual(); event.stop()
            elif event.key in ("v", "escape"):
                self._exit_visual(); event.stop()
            return

        if event.key == "j":
            table.move_cursor(row=table.cursor_row + 1); event.stop()
        elif event.key == "k":
            table.move_cursor(row=max(0, table.cursor_row - 1)); event.stop()
        elif event.key == "g":
            table.move_cursor(row=0 if table.cursor_row != 0 else table.row_count - 1); event.stop()
        elif event.key == "enter":
            self._open_detail(); event.stop()
        elif event.key == "p":
            self._open_plan(); event.stop()
        elif event.key == "m":
            self._toggle_mark(); event.stop()
        elif event.key == "c":
            self._open_compare(); event.stop()
        elif event.key == "x":
            self._marked.clear(); self._refresh_table(); event.stop()
        elif event.key == "v":
            self._enter_visual(); event.stop()
        elif event.key == "slash":
            self.query_one("#search-input", Input).focus(); event.stop()
        elif event.key == "r":
            self._cycle_family(); event.stop()
        elif event.key == "b":
            self._cycle_size(); event.stop()
        elif event.key == "f":
            self._cycle_fit(); event.stop()
        elif event.key == "s":
            self._cycle_sort(); event.stop()
        elif event.key == "minus":
            self.sort_desc = not self.sort_desc; event.stop()
        elif event.key == "S":
            self._open_simulation(); event.stop()
        elif event.key == "F":
            self._open_filter(); event.stop()
        elif event.key == "S":
            self._open_simulation(); event.stop()
        elif event.key == "A":
            self._open_adv_config(); event.stop()
        elif event.key == "t":
            self._cycle_theme(); event.stop()
        elif event.key == "h":
            self.push_screen(HelpScreen()); event.stop()
        elif event.key == "q":
            self.exit(); event.stop()

    def on_screen_resume(self) -> None:
        try:
            self.query_one("#model-table", DataTable).focus()
            self._update_hw_bar()
            self._refresh_table()
            self._update_status()
        except Exception:
            pass

    # ── Action helpers ────────────────────────────────────────────────────────

    def _selected_model(self) -> Optional[ModelSpec]:
        table = self.query_one("#model-table", DataTable)
        idx = table.cursor_row
        return self._filtered[idx] if self._filtered and 0 <= idx < len(self._filtered) else None

    def _open_detail(self) -> None:
        m = self._selected_model()
        if m: self.push_screen(DetailScreen(m, self._hw, self._eff))

    def _open_plan(self) -> None:
        m = self._selected_model()
        if m: self.push_screen(PlanScreen(m, self._hw, self._eff))

    def _toggle_mark(self) -> None:
        m = self._selected_model()
        if m:
            self._marked.discard(m.name) if m.name in self._marked else self._marked.add(m.name)
            self._refresh_table()

    def _open_compare(self) -> None:
        if len(self._marked) < 2:
            self.notify("Mark 2+ models with [m] first", title="Compare", severity="warning")
            return
        models = [m for m in KNOWN_MODELS if m.name in self._marked]
        self.push_screen(CompareScreen(models, self._hw, self._eff))

    def _enter_visual(self) -> None:
        self._visual_start = self.query_one("#model-table", DataTable).cursor_row
        self._mode = AppMode.VISUAL
        self._refresh_table(); self._update_status()

    def _exit_visual(self) -> None:
        self._mode = AppMode.NORMAL
        self._refresh_table(); self._update_status()

    def _mark_visual_range(self) -> None:
        cur = self.query_one("#model-table", DataTable).cursor_row
        lo = min(self._visual_start, cur); hi = max(self._visual_start, cur)
        for i in range(lo, min(hi + 1, len(self._filtered))):
            self._marked.add(self._filtered[i].name)

    def _compare_visual_range(self) -> None:
        cur = self.query_one("#model-table", DataTable).cursor_row
        lo = min(self._visual_start, cur); hi = max(self._visual_start, cur)
        models = [self._filtered[i] for i in range(lo, min(hi + 1, len(self._filtered)))]
        if len(models) >= 2:
            self.push_screen(CompareScreen(models, self._hw, self._eff))

    def _cycle_family(self) -> None:
        idx = _FAMILIES.index(self.family_filter) if self.family_filter in _FAMILIES else 0
        self.family_filter = _FAMILIES[(idx + 1) % len(_FAMILIES)]
        try:
            self.query_one("#family-select", Select).value = self.family_filter
        except Exception:
            pass

    def _cycle_size(self) -> None:
        idx = _SIZES.index(self.size_filter) if self.size_filter in _SIZES else 0
        self.size_filter = _SIZES[(idx + 1) % len(_SIZES)]
        try:
            self.query_one("#size-select", Select).value = self.size_filter
        except Exception:
            pass

    def _cycle_fit(self) -> None:
        opts = ["All", "Perfect", "Good", "Marginal"]
        self.fit_filter = opts[(opts.index(self.fit_filter) + 1) % len(opts)]
        try:
            self.query_one("#fit-select", Select).value = self.fit_filter
        except Exception:
            pass

    def _cycle_sort(self) -> None:
        opts = ["score", "tps", "mem", "params", "name"]
        idx = opts.index(self.sort_order) if self.sort_order in opts else 0
        self.sort_order = opts[(idx + 1) % len(opts)]
        # Default direction: ascending for name/params, descending for others
        self.sort_desc = self.sort_order not in ("name",)
        try:
            self.query_one("#sort-select", Select).value = self.sort_order
        except Exception:
            pass

    def _open_filter(self) -> None:
        def handle(result: tuple | None) -> None:
            if result is None: return
            def p(s: str) -> Optional[float]:
                try: return float(s) if s.strip() else None
                except ValueError: return None
            self._params_min, self._params_max = p(result[0]), p(result[1])
            self._mem_min,    self._mem_max    = p(result[2]), p(result[3])
            self._refresh_table()
        self.push_screen(FilterPopupScreen(
            str(self._params_min or ""), str(self._params_max or ""),
            str(self._mem_min or ""),   str(self._mem_max or ""),
        ), handle)

    def _open_adv_config(self) -> None:
        def handle(result: str | None) -> None:
            if result is None: return
            try:
                v = float(result)
                self._eff_override = None if v == 1.0 else v
            except ValueError:
                pass
            self._refresh_table(); self._update_hw_bar()
        self.push_screen(AdvConfigScreen(
            str(self._eff_override if self._eff_override is not None else 1.0)
        ), handle)

    def _open_simulation(self) -> None:
        self.push_screen(SimulationScreen(self._hw, self._eff))

    def _apply_simulation(self, profile_key: Optional[str]) -> None:
        if profile_key is None:
            self._sim_info = None
            self._eff_override = None
        else:
            p = PROFILES[profile_key]
            self._sim_info = SystemInfo(
                profile_key=profile_key, profile=p,
                available_memory_gb=p.total_memory_gb, total_memory_gb=p.total_memory_gb,
                jetpack_version=p.jetpack_version,
                tegra_release=None, device_model=None, is_simulated=True,
            )
        try:
            self._update_hw_bar()
            self._refresh_table()
            self._update_status()
        except Exception:
            pass

    def _cycle_theme(self) -> None:
        idx = _THEME_CYCLE.index(self._theme_name)
        self.theme = _THEME_CYCLE[(idx + 1) % len(_THEME_CYCLE)]


def run() -> None:
    JetfitApp().run()
