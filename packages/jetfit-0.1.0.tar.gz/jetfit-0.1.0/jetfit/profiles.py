"""Hardware profile database for Jetson and DGX Spark devices."""

from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class HardwareProfile:
    name: str
    total_memory_gb: float
    bandwidth_gbs: float
    has_dla: bool
    has_fp4: bool
    default_efficiency: float
    jetpack_version: Optional[str]
    # Estimated power envelope in watts for tps scaling
    power_tdp_w: float = 15.0

    def __str__(self) -> str:
        accel = []
        if self.has_dla:
            accel.append("DLA")
        if self.has_fp4:
            accel.append("FP4")
        accel_str = "+".join(accel) if accel else "CUDA"
        return f"{self.name} ({self.total_memory_gb:.0f}GB, {self.bandwidth_gbs:.1f} GB/s, {accel_str})"


# Canonical hardware profiles ordered from smallest to largest
PROFILES: dict[str, HardwareProfile] = {
    # ── Jetson Nano (legacy, JetPack 4.x) ────────────────────────────────────
    "jetson_nano": HardwareProfile(
        name="Jetson Nano",
        total_memory_gb=4.0,
        bandwidth_gbs=25.6,       # 64-bit LPDDR4
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="4.x",
        power_tdp_w=10.0,
    ),
    # ── Jetson TX2 series (Pascal GPU, no DLA, JetPack 4.x) ──────────────────
    "jetson_tx2_nx": HardwareProfile(
        name="Jetson TX2 NX",
        total_memory_gb=4.0,
        bandwidth_gbs=51.2,       # 128-bit LPDDR4 @ 1600 MHz
        has_dla=False,
        has_fp4=False,
        default_efficiency=0.45,
        jetpack_version="5.x",
        power_tdp_w=15.0,
    ),
    "jetson_tx2_4gb": HardwareProfile(
        name="Jetson TX2 4GB",
        total_memory_gb=4.0,
        bandwidth_gbs=51.2,       # 128-bit LPDDR4 @ 1600 MHz
        has_dla=False,
        has_fp4=False,
        default_efficiency=0.45,
        jetpack_version="4.x",
        power_tdp_w=15.0,
    ),
    "jetson_tx2": HardwareProfile(
        name="Jetson TX2",
        total_memory_gb=8.0,
        bandwidth_gbs=59.7,       # 128-bit LPDDR4 @ 1866 MHz
        has_dla=False,
        has_fp4=False,
        default_efficiency=0.45,
        jetpack_version="4.x",
        power_tdp_w=15.0,
    ),
    "jetson_tx2i": HardwareProfile(
        name="Jetson TX2i",
        total_memory_gb=8.0,
        bandwidth_gbs=51.2,       # 128-bit LPDDR4 @ 1600 MHz (ECC, industrial)
        has_dla=False,
        has_fp4=False,
        default_efficiency=0.45,
        jetpack_version="4.x",
        power_tdp_w=20.0,
    ),
    # ── Jetson Xavier NX (2× DLA, JetPack 4/5) ───────────────────────────────
    "jetson_xavier_nx_8gb": HardwareProfile(
        name="Jetson Xavier NX 8GB",
        total_memory_gb=8.0,
        bandwidth_gbs=59.7,       # 128-bit LPDDR4x
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.48,
        jetpack_version="5.x",
        power_tdp_w=15.0,
    ),
    "jetson_xavier_nx_16gb": HardwareProfile(
        name="Jetson Xavier NX 16GB",
        total_memory_gb=16.0,
        bandwidth_gbs=59.7,       # 128-bit LPDDR4x
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.48,
        jetpack_version="5.x",
        power_tdp_w=15.0,
    ),
    # ── Jetson AGX Xavier (2× DLA, JetPack 4/5) ───────────────────────────────
    "jetson_agx_xavier_16gb": HardwareProfile(
        name="Jetson AGX Xavier 16GB",
        total_memory_gb=16.0,
        bandwidth_gbs=136.5,      # 256-bit LPDDR4x (official: 136.5 GB/s)
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="5.x",
        power_tdp_w=30.0,
    ),
    "jetson_agx_xavier_32gb": HardwareProfile(
        name="Jetson AGX Xavier 32GB",
        total_memory_gb=32.0,
        bandwidth_gbs=136.5,      # 256-bit LPDDR4x (official: 136.5 GB/s)
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="5.x",
        power_tdp_w=30.0,
    ),
    "jetson_agx_xavier_64gb": HardwareProfile(
        name="Jetson AGX Xavier 64GB",
        total_memory_gb=64.0,
        bandwidth_gbs=136.5,      # 256-bit LPDDR4x (official: 136.5 GB/s)
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="5.x",
        power_tdp_w=30.0,
    ),
    "jetson_agx_xavier_industrial": HardwareProfile(
        name="Jetson AGX Xavier Industrial",
        total_memory_gb=64.0,
        bandwidth_gbs=136.5,      # 256-bit LPDDR4x ECC (official: 136.5 GB/s)
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="5.x",
        power_tdp_w=40.0,
    ),
    # ── Jetson Orin Nano (no DLA; cost-optimised Orin) ────────────────────────
    "jetson_orin_nano_4gb": HardwareProfile(
        name="Jetson Orin Nano 4GB",
        total_memory_gb=4.0,
        bandwidth_gbs=51.2,       # 64-bit LPDDR5 @ 6400 MT/s (official: 51 GB/s)
        has_dla=False,
        has_fp4=False,
        default_efficiency=0.45,
        jetpack_version="6.x",
        power_tdp_w=10.0,
    ),
    "jetson_orin_nano_8gb": HardwareProfile(
        name="Jetson Orin Nano 8GB",
        total_memory_gb=8.0,
        bandwidth_gbs=102.4,      # 128-bit LPDDR5 (official: 102 GB/s; current = Super)
        has_dla=False,
        has_fp4=False,
        default_efficiency=0.48,
        jetpack_version="6.x",
        power_tdp_w=25.0,
    ),
    # ── Jetson Orin NX (1× DLA) ───────────────────────────────────────────────
    "jetson_orin_nx_8gb": HardwareProfile(
        name="Jetson Orin NX 8GB",
        total_memory_gb=8.0,
        bandwidth_gbs=102.4,      # 128-bit LPDDR5 (was wrongly 68.3)
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="6.x",
        power_tdp_w=10.0,
    ),
    "jetson_orin_nx_16gb": HardwareProfile(
        name="Jetson Orin NX 16GB",
        total_memory_gb=16.0,
        bandwidth_gbs=102.4,      # 128-bit LPDDR5
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="6.x",
        power_tdp_w=15.0,
    ),
    # ── Jetson AGX Orin (2× DLA) ──────────────────────────────────────────────
    "jetson_agx_orin_32gb": HardwareProfile(
        name="Jetson AGX Orin 32GB",
        total_memory_gb=32.0,
        bandwidth_gbs=204.8,      # 256-bit LPDDR5 (was wrongly 102.4)
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="6.x",
        power_tdp_w=25.0,
    ),
    "jetson_agx_orin_64gb": HardwareProfile(
        name="Jetson AGX Orin 64GB",
        total_memory_gb=64.0,
        bandwidth_gbs=204.8,      # 256-bit LPDDR5
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="6.x",
        power_tdp_w=60.0,
    ),
    "jetson_agx_orin_industrial": HardwareProfile(
        name="Jetson AGX Orin Industrial",
        total_memory_gb=64.0,
        bandwidth_gbs=204.8,      # 256-bit LPDDR5 ECC, extended temp
        has_dla=True,
        has_fp4=False,
        default_efficiency=0.50,
        jetpack_version="6.x",
        power_tdp_w=75.0,
    ),
    # ── Jetson Thor (Blackwell GB10, FP4, no DLA) ─────────────────────────────
    "jetson_thor_t4000": HardwareProfile(
        name="Jetson AGX Thor T4000",
        total_memory_gb=64.0,
        bandwidth_gbs=273.0,      # GB10 unified memory
        has_dla=False,
        has_fp4=True,
        default_efficiency=0.55,
        jetpack_version="6.x",
        power_tdp_w=70.0,
    ),
    "jetson_thor_t5000": HardwareProfile(
        name="Jetson AGX Thor T5000",
        total_memory_gb=128.0,
        bandwidth_gbs=273.0,      # GB10 unified memory
        has_dla=False,
        has_fp4=True,
        default_efficiency=0.55,
        jetpack_version="6.x",
        power_tdp_w=130.0,
    ),
    # ── DGX Spark (GB10, FP4, datacenter) ────────────────────────────────────
    "dgx_spark": HardwareProfile(
        name="DGX Spark (GB10)",
        total_memory_gb=128.0,
        bandwidth_gbs=273.0,
        has_dla=False,
        has_fp4=True,
        default_efficiency=0.55,
        jetpack_version=None,
        power_tdp_w=60.0,
    ),
}


def get_profile(key: str) -> Optional[HardwareProfile]:
    return PROFILES.get(key)


def all_profiles() -> list[HardwareProfile]:
    return list(PROFILES.values())
