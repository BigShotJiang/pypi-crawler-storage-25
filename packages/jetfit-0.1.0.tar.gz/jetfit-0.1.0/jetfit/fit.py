"""Scoring engine: bandwidth-based tok/s estimates, quant ladder, fit levels."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional

from jetfit.profiles import HardwareProfile


class FitLevel(Enum):
    PERFECT = "Perfect"      # memory usage ≤ 70%
    GOOD = "Good"            # 71–90%
    MARGINAL = "Marginal"    # 91–100%
    TOO_TIGHT = "TooTight"   # > 100%


# (quant_name, bits_per_weight, speed_multiplier_relative_to_q8)
QUANT_LADDER: list[tuple[str, float, float]] = [
    ("Q8_0",   8.0, 1.00),
    ("Q6_K",   6.0, 1.08),
    ("Q5_K_M", 5.0, 1.17),
    ("Q4_K_M", 4.0, 1.30),
    ("Q3_K_M", 3.0, 1.50),
    ("Q2_K",   2.0, 1.80),
]

# Bytes overhead per parameter beyond the raw weight bits
# (k-quants have small codebook overhead; this is an approximation)
_QUANT_BYTES_PER_PARAM: dict[str, float] = {
    "Q8_0":   8.5 / 8,
    "Q6_K":   6.6 / 8,
    "Q5_K_M": 5.5 / 8,
    "Q4_K_M": 4.6 / 8,
    "Q3_K_M": 3.4 / 8,
    "Q2_K":   2.6 / 8,
}


@dataclass
class ModelSpec:
    name: str
    params_b: float       # billions of parameters
    context_len: int = 4096

    @property
    def size_at_quant_gb(self) -> dict[str, float]:
        sizes: dict[str, float] = {}
        for quant, bpp in _QUANT_BYTES_PER_PARAM.items():
            sizes[quant] = self.params_b * 1e9 * bpp / (1024 ** 3)
        return sizes

    def kv_cache_gb(self, context_len: Optional[int] = None) -> float:
        """fp16 KV cache estimate: 0.000008 * params_b * ctx (llmfit fallback formula).
        Defaults to _KV_CACHE_DEFAULT_CTX (4096) — a typical inference context —
        not the model's max context_len, which would over-estimate memory."""
        ctx = context_len if context_len is not None else _KV_CACHE_DEFAULT_CTX
        return 0.000008 * self.params_b * ctx


_RUNTIME_OVERHEAD_GB  = 0.5   # CUDA/Metal context + buffers
_KV_CACHE_DEFAULT_CTX = 4096  # typical inference context for memory estimates


@dataclass
class FitResult:
    model: ModelSpec
    quant: str
    model_size_gb: float
    effective_size_gb: float  # after FP4 halving
    kv_cache_gb: float        # fp16 KV cache at model's context length
    total_memory_gb: float    # effective_size_gb + kv_cache + overhead
    fit_level: FitLevel
    memory_utilization: float  # total_memory_gb / available, 0–1+
    estimated_tps: float
    available_memory_gb: float


def _fit_level(utilization: float) -> FitLevel:
    if utilization <= 0.70:
        return FitLevel.PERFECT
    if utilization <= 0.90:
        return FitLevel.GOOD
    if utilization <= 1.00:
        return FitLevel.MARGINAL
    return FitLevel.TOO_TIGHT


def score_model(
    model: ModelSpec,
    quant: str,
    profile: HardwareProfile,
    available_memory_gb: float,
    efficiency: Optional[float] = None,
) -> FitResult:
    """Compute tok/s estimate and fit level for a single (model, quant) pair."""
    eff = efficiency if efficiency is not None else profile.default_efficiency

    bpp = _QUANT_BYTES_PER_PARAM[quant]
    model_size_gb = model.params_b * 1e9 * bpp / (1024 ** 3)

    effective_size_gb = model_size_gb
    if profile.has_fp4:
        effective_size_gb *= 0.5

    kv_cache = model.kv_cache_gb()
    total_memory_gb = effective_size_gb + kv_cache + _RUNTIME_OVERHEAD_GB

    speed_mult = next(m for n, _, m in QUANT_LADDER if n == quant)
    tps = (profile.bandwidth_gbs / effective_size_gb) * eff * speed_mult

    utilization = total_memory_gb / available_memory_gb
    level = _fit_level(utilization)

    return FitResult(
        model=model,
        quant=quant,
        model_size_gb=model_size_gb,
        effective_size_gb=effective_size_gb,
        kv_cache_gb=kv_cache,
        total_memory_gb=total_memory_gb,
        fit_level=level,
        memory_utilization=utilization,
        estimated_tps=tps,
        available_memory_gb=available_memory_gb,
    )


def recommend(
    model: ModelSpec,
    profile: HardwareProfile,
    available_memory_gb: float,
    efficiency: Optional[float] = None,
) -> list[FitResult]:
    """Return fit results for all quant levels, best first.

    Only includes quants where the model fits (TooTight excluded),
    sorted by descending estimated_tps (higher quality quant preferred).
    """
    results: list[FitResult] = []
    for quant, _, _ in QUANT_LADDER:
        r = score_model(model, quant, profile, available_memory_gb, efficiency)
        results.append(r)

    # Sort: fits first (by quality desc = lower quant index first), then too-tight
    fits = [r for r in results if r.fit_level != FitLevel.TOO_TIGHT]
    too_tight = [r for r in results if r.fit_level == FitLevel.TOO_TIGHT]
    # Within fits, preserve quant ladder order (Q8_0 first = highest quality)
    return fits + too_tight


def best_fit(
    model: ModelSpec,
    profile: HardwareProfile,
    available_memory_gb: float,
    efficiency: Optional[float] = None,
) -> Optional[FitResult]:
    """Return the highest-quality quant where total memory (weights + KV cache + overhead)
    fits within available_memory_gb."""
    for quant, _, _ in QUANT_LADDER:
        r = score_model(model, quant, profile, available_memory_gb, efficiency)
        if r.fit_level != FitLevel.TOO_TIGHT:
            return r
    return None


# Well-known model catalog used by recommend command
KNOWN_MODELS: list[ModelSpec] = [
    # ── Llama (Meta) ─────────────────────────────────────────────────────────
    ModelSpec("Llama-3.2-1B",              1.0,   131072),
    ModelSpec("Llama-3.2-3B",              3.0,   131072),
    ModelSpec("Llama-3.2-11B",            11.0,   131072),
    ModelSpec("Llama-3.1-8B",              8.0,   131072),
    ModelSpec("Llama-3.1-70B",            70.0,   131072),
    ModelSpec("Llama-3.1-405B",          405.0,   131072),
    ModelSpec("Llama-3.3-70B",            70.0,   131072),
    ModelSpec("TinyLlama-1.1B",            1.1,     2048),
    # ── Mistral / Mistral AI ─────────────────────────────────────────────────
    ModelSpec("Mistral-7B",                7.0,    32768),
    ModelSpec("Mistral-Nemo-12B",         12.0,   131072),
    ModelSpec("Mistral-Small-22B",        22.0,    32768),
    ModelSpec("Codestral-22B",            22.0,    32768),
    ModelSpec("Mistral-Large-123B",      123.0,   131072),
    # ── Phi (Microsoft) ──────────────────────────────────────────────────────
    ModelSpec("Phi-3-mini-3.8B",           3.8,   131072),
    ModelSpec("Phi-3.5-mini-3.8B",         3.8,   131072),
    ModelSpec("Phi-3-medium-14B",         14.0,   131072),
    ModelSpec("Phi-4-mini-3.8B",           3.8,   131072),
    ModelSpec("Phi-4-14B",                14.0,    16384),
    # ── Gemma (Google) ───────────────────────────────────────────────────────
    ModelSpec("Gemma-2-2B",                2.0,     8192),
    ModelSpec("Gemma-2-9B",                9.0,     8192),
    ModelSpec("Gemma-2-27B",              27.0,     8192),
    ModelSpec("Gemma-3-1B",                1.0,    32768),
    ModelSpec("Gemma-3-4B",                4.0,   131072),
    ModelSpec("Gemma-3-12B",              12.0,   131072),
    ModelSpec("Gemma-3-27B",              27.0,   131072),
    # ── Qwen 2.5 (Alibaba) ───────────────────────────────────────────────────
    ModelSpec("Qwen2.5-0.5B",              0.5,   131072),
    ModelSpec("Qwen2.5-1.5B",              1.5,   131072),
    ModelSpec("Qwen2.5-3B",                3.0,   131072),
    ModelSpec("Qwen2.5-7B",                7.0,   131072),
    ModelSpec("Qwen2.5-14B",              14.0,   131072),
    ModelSpec("Qwen2.5-32B",              32.0,   131072),
    ModelSpec("Qwen2.5-72B",              72.0,   131072),
    ModelSpec("Qwen2.5-Coder-1.5B",        1.5,   131072),
    ModelSpec("Qwen2.5-Coder-3B",          3.0,   131072),
    ModelSpec("Qwen2.5-Coder-7B",          7.0,   131072),
    ModelSpec("Qwen2.5-Coder-14B",        14.0,   131072),
    ModelSpec("Qwen2.5-Coder-32B",        32.0,   131072),
    # ── Qwen 3 (Alibaba) ─────────────────────────────────────────────────────
    ModelSpec("Qwen3-0.6B",                0.6,   131072),
    ModelSpec("Qwen3-1.7B",                1.7,   131072),
    ModelSpec("Qwen3-4B",                  4.0,   131072),
    ModelSpec("Qwen3-8B",                  8.0,   131072),
    ModelSpec("Qwen3-14B",                14.0,   131072),
    ModelSpec("Qwen3-32B",                32.0,   131072),
    ModelSpec("Qwen3-30B-A3B",            30.0,   131072),  # MoE, active 3B
    ModelSpec("Qwen3-235B-A22B",         235.0,   262144),  # MoE, active 22B; 256k ctx
    # ── DeepSeek ─────────────────────────────────────────────────────────────
    ModelSpec("DeepSeek-R1-Distill-1.5B",  1.5,   131072),
    ModelSpec("DeepSeek-R1-Distill-7B",    7.0,   131072),
    ModelSpec("DeepSeek-R1-Distill-8B",    8.0,   131072),
    ModelSpec("DeepSeek-R1-Distill-14B",  14.0,   131072),
    ModelSpec("DeepSeek-R1-Distill-32B",  32.0,   131072),
    ModelSpec("DeepSeek-R1-Distill-70B",  70.0,   131072),
    ModelSpec("DeepSeek-R1-671B",        671.0,   131072),
    ModelSpec("DeepSeek-V3-671B",        671.0,   131072),
    # ── SmolLM (HuggingFace) ─────────────────────────────────────────────────
    ModelSpec("SmolLM2-135M",              0.135,   8192),
    ModelSpec("SmolLM2-360M",              0.36,    8192),
    ModelSpec("SmolLM2-1.7B",              1.7,     8192),
    # ── Others ───────────────────────────────────────────────────────────────
    ModelSpec("Yi-1.5-6B",                 6.0,     4096),
    ModelSpec("Yi-1.5-9B",                 9.0,     4096),
    ModelSpec("Yi-1.5-34B",               34.0,    16384),
    ModelSpec("Command-R-35B",            35.0,   131072),
    ModelSpec("Command-R-Plus-104B",     104.0,   131072),
    ModelSpec("InternLM2.5-7B",            7.0,    32768),
    ModelSpec("InternLM2.5-20B",          20.0,    32768),
    ModelSpec("Falcon3-7B",                7.0,    32768),
    ModelSpec("Falcon3-10B",              10.0,    32768),
    ModelSpec("Starcoder2-7B",             7.0,    16384),
    ModelSpec("Starcoder2-15B",           15.0,    16384),
]
