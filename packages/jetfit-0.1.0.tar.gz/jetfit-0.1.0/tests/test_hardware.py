"""Tests for hardware.py — platform detection logic."""

import importlib
from unittest.mock import patch, MagicMock

import pytest

import jetfit.hardware as hw_mod
from jetfit.hardware import (
    _match_profile_from_model,
    _match_profile_from_compatible,
    _parse_meminfo_available_gb,
    detect_hardware,
    SystemInfo,
)
from jetfit.profiles import PROFILES


# ---------------------------------------------------------------------------
# _match_profile_from_model
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("model_str, expected_key", [
    # AGX Orin
    ("NVIDIA Jetson AGX Orin 64GB",               "jetson_agx_orin_64gb"),
    ("NVIDIA Jetson AGX Orin 32GB",               "jetson_agx_orin_32gb"),
    ("NVIDIA Jetson AGX Orin Industrial",          "jetson_agx_orin_industrial"),
    # Orin NX
    ("NVIDIA Jetson Orin NX 16GB",                "jetson_orin_nx_16gb"),
    ("NVIDIA Jetson Orin NX 8GB",                 "jetson_orin_nx_8gb"),
    # Orin Nano
    ("NVIDIA Jetson Orin Nano 8GB",               "jetson_orin_nano_8gb"),
    ("NVIDIA Jetson Orin Nano 4GB",               "jetson_orin_nano_4gb"),
    # AGX Xavier
    ("NVIDIA Jetson AGX Xavier 64GB",             "jetson_agx_xavier_64gb"),
    ("NVIDIA Jetson AGX Xavier 32GB",             "jetson_agx_xavier_32gb"),
    ("NVIDIA Jetson AGX Xavier 16GB",             "jetson_agx_xavier_16gb"),
    ("NVIDIA Jetson AGX Xavier Industrial",       "jetson_agx_xavier_industrial"),
    # Xavier NX
    ("NVIDIA Jetson Xavier NX 16GB",              "jetson_xavier_nx_16gb"),
    ("NVIDIA Jetson Xavier NX 8GB",               "jetson_xavier_nx_8gb"),
    # TX2
    ("NVIDIA Jetson TX2 NX",                      "jetson_tx2_nx"),
    ("NVIDIA Jetson TX2 4GB",                     "jetson_tx2_4gb"),
    ("NVIDIA Jetson TX2",                         "jetson_tx2"),
    ("NVIDIA Jetson TX2i",                        "jetson_tx2i"),
    # Nano
    ("NVIDIA Jetson Nano",                        "jetson_nano"),
    # Thor
    ("NVIDIA Jetson AGX Thor T5000",              "jetson_thor_t5000"),
    ("NVIDIA Jetson AGX Thor T4000",              "jetson_thor_t4000"),
    # DGX Spark
    ("NVIDIA DGX Spark GB10",                     "dgx_spark"),
    ("nvidia,grace",                              "dgx_spark"),
])
def test_match_profile_from_model(model_str, expected_key):
    assert _match_profile_from_model(model_str) == expected_key


def test_match_profile_from_model_unknown():
    assert _match_profile_from_model("Some Unknown Board") is None


# ---------------------------------------------------------------------------
# _match_profile_from_compatible
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("compat, expected_key", [
    ("nvidia,grace linux,dummy",        "dgx_spark"),
    ("nvidia,p3737-0000 nvidia,orin-nx", "jetson_orin_nx_16gb"),
    ("nvidia,jetson-nano",              "jetson_nano"),
])
def test_match_profile_from_compatible(compat, expected_key):
    assert _match_profile_from_compatible(compat) == expected_key


# ---------------------------------------------------------------------------
# _parse_meminfo_available_gb
# ---------------------------------------------------------------------------

FAKE_MEMINFO = """\
MemTotal:       16384000 kB
MemFree:         1024000 kB
MemAvailable:    8192000 kB
Buffers:          512000 kB
"""


def test_parse_meminfo_available_gb(tmp_path, monkeypatch):
    meminfo = tmp_path / "meminfo"
    meminfo.write_text(FAKE_MEMINFO)

    # Patch _read_file to return our fake content only for /proc/meminfo
    original_read = hw_mod._read_file

    def patched_read(path: str):
        if path == "/proc/meminfo":
            return FAKE_MEMINFO
        return original_read(path)

    monkeypatch.setattr(hw_mod, "_read_file", patched_read)
    result = _parse_meminfo_available_gb()
    assert abs(result - 8192000 / (1024 * 1024)) < 0.01


# ---------------------------------------------------------------------------
# detect_hardware — full integration (with file reads mocked)
# ---------------------------------------------------------------------------

def test_detect_hardware_orin_nx_16gb(monkeypatch):
    """Simulate running on a Jetson Orin NX 16GB."""
    def fake_read(path: str):
        if path == "/etc/nv_tegra_release":
            return "# R35 (release), REVISION: 4.1"
        if path == "/proc/device-tree/model":
            return "NVIDIA Jetson Orin NX 16GB"
        if path == "/proc/device-tree/compatible":
            return "nvidia,p3767-0003 nvidia,orin-nx"
        if path == "/proc/meminfo":
            return "MemAvailable: 12000000 kB\n"
        return None

    monkeypatch.setattr(hw_mod, "_read_file", fake_read)
    monkeypatch.setattr(hw_mod, "_get_tegrastats_memory_gb", lambda: None)
    monkeypatch.setattr(hw_mod, "_get_jtop_memory_gb", lambda: None)

    info = detect_hardware()

    assert info.profile_key == "jetson_orin_nx_16gb"
    assert info.total_memory_gb == 16.0
    assert info.profile.bandwidth_gbs == pytest.approx(102.4)
    assert info.profile.has_dla is True
    assert info.is_simulated is False
    # available is capped to 16 GB (meminfo says ~11.4 GB < 16)
    assert info.available_memory_gb <= 16.0


def test_detect_hardware_dgx_spark(monkeypatch):
    def fake_read(path: str):
        if path == "/proc/device-tree/compatible":
            return "nvidia,grace linux,dummy"
        if path == "/proc/device-tree/model":
            return "NVIDIA DGX Spark GB10"
        return None

    monkeypatch.setattr(hw_mod, "_read_file", fake_read)
    monkeypatch.setattr(hw_mod, "_get_tegrastats_memory_gb", lambda: None)
    monkeypatch.setattr(hw_mod, "_get_jtop_memory_gb", lambda: None)

    info = detect_hardware()

    assert info.profile_key == "dgx_spark"
    assert info.profile.has_fp4 is True
    assert info.profile.total_memory_gb == 128.0


def test_detect_hardware_mac_fallback(monkeypatch):
    """On Mac (no Jetson files) should return simulated Orin NX 16GB."""
    monkeypatch.setattr(hw_mod, "_read_file", lambda _: None)
    monkeypatch.setattr(hw_mod, "_get_tegrastats_memory_gb", lambda: None)
    monkeypatch.setattr(hw_mod, "_get_jtop_memory_gb", lambda: None)

    info = detect_hardware()

    assert info.is_simulated is True
    assert info.profile_key == "jetson_orin_nx_16gb"


def test_detect_hardware_tegrastats_memory(monkeypatch):
    """tegrastats-reported memory takes precedence over /proc/meminfo."""
    monkeypatch.setattr(hw_mod, "_read_file", lambda _: None)
    monkeypatch.setattr(hw_mod, "_get_tegrastats_memory_gb", lambda: 10.5)
    monkeypatch.setattr(hw_mod, "_get_jtop_memory_gb", lambda: None)

    info = detect_hardware()

    assert info.available_memory_gb == pytest.approx(10.5)


# ---------------------------------------------------------------------------
# Regression: _hw_bar_markup must not raise KeyError for any profile
# (previously crashed with KeyError: 'background' in _update_status)
# ---------------------------------------------------------------------------

from jetfit.tui import _hw_bar_markup, _sync_colors, _TEXTUAL_THEMES


@pytest.mark.parametrize("profile_key", list(PROFILES.keys()))
def test_hw_bar_markup_all_profiles_no_crash(profile_key):
    """_hw_bar_markup must succeed for every profile in both real and simulated mode."""
    _sync_colors(_TEXTUAL_THEMES["Mocha"])
    profile = PROFILES[profile_key]
    for is_simulated in (False, True):
        info = SystemInfo(
            profile_key=profile_key,
            profile=profile,
            available_memory_gb=profile.total_memory_gb * 0.6,
            total_memory_gb=profile.total_memory_gb,
            jetpack_version=profile.jetpack_version,
            tegra_release=None,
            device_model=None,
            is_simulated=is_simulated,
        )
        markup = _hw_bar_markup(info, efficiency=None)
        assert isinstance(markup, str)
        assert len(markup) > 0


@pytest.mark.parametrize("theme_name", list(_TEXTUAL_THEMES.keys()))
def test_hw_bar_markup_all_themes_no_crash(theme_name):
    """_hw_bar_markup must succeed for every built-in theme."""
    _sync_colors(_TEXTUAL_THEMES[theme_name])
    profile_key = "jetson_orin_nx_16gb"
    profile = PROFILES[profile_key]
    for is_simulated in (False, True):
        info = SystemInfo(
            profile_key=profile_key,
            profile=profile,
            available_memory_gb=8.0,
            total_memory_gb=profile.total_memory_gb,
            jetpack_version=profile.jetpack_version,
            tegra_release=None,
            device_model=None,
            is_simulated=is_simulated,
        )
        markup = _hw_bar_markup(info, efficiency=0.55)
        assert isinstance(markup, str)


def test_c_dict_has_no_background_key():
    """_C must not contain a 'background' key — that key never existed and caused a crash."""
    from jetfit.tui import _C
    _sync_colors(_TEXTUAL_THEMES["Mocha"])
    assert "background" not in _C, (
        "'background' key found in _C — this would cause KeyError in _update_status()"
    )
