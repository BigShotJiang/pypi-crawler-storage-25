"""Tests for fit.py — scoring engine."""

import pytest

from jetfit.fit import (
    FitLevel, FitResult, ModelSpec,
    QUANT_LADDER, _fit_level, score_model, recommend, best_fit, KNOWN_MODELS,
)
from jetfit.profiles import PROFILES


ORIN_NX_16 = PROFILES["jetson_orin_nx_16gb"]
DGX_SPARK   = PROFILES["dgx_spark"]


# ---------------------------------------------------------------------------
# FitLevel thresholds
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("util, expected", [
    (0.0,   FitLevel.PERFECT),
    (0.70,  FitLevel.PERFECT),
    (0.701, FitLevel.GOOD),
    (0.90,  FitLevel.GOOD),
    (0.901, FitLevel.MARGINAL),
    (1.00,  FitLevel.MARGINAL),
    (1.001, FitLevel.TOO_TIGHT),
])
def test_fit_level_thresholds(util, expected):
    assert _fit_level(util) == expected


# ---------------------------------------------------------------------------
# score_model
# ---------------------------------------------------------------------------

def test_score_model_basic():
    model = ModelSpec("TestModel", 7.0)
    result = score_model(model, "Q4_K_M", ORIN_NX_16, available_memory_gb=16.0)

    assert result.quant == "Q4_K_M"
    assert result.model_size_gb == pytest.approx(7.0 * 1e9 * (4.6 / 8) / (1024 ** 3), rel=1e-3)
    assert result.effective_size_gb == result.model_size_gb   # no FP4 on Orin
    assert result.estimated_tps > 0
    assert isinstance(result.fit_level, FitLevel)


def test_score_model_fp4_halves_effective_size():
    model = ModelSpec("BigModel", 70.0)
    r_no_fp4 = score_model(model, "Q8_0", ORIN_NX_16, available_memory_gb=64.0)
    r_fp4    = score_model(model, "Q8_0", DGX_SPARK,  available_memory_gb=128.0)

    assert r_fp4.effective_size_gb == pytest.approx(r_no_fp4.effective_size_gb * 0.5, rel=1e-3)


def test_score_model_custom_efficiency():
    model = ModelSpec("TestModel", 7.0)
    r_default = score_model(model, "Q4_K_M", ORIN_NX_16, available_memory_gb=16.0)
    r_custom  = score_model(model, "Q4_K_M", ORIN_NX_16, available_memory_gb=16.0, efficiency=0.80)

    assert r_custom.estimated_tps == pytest.approx(r_default.estimated_tps * (0.80 / 0.50), rel=1e-3)


def test_score_model_too_tight():
    model = ModelSpec("HugeModel", 100.0)
    r = score_model(model, "Q8_0", ORIN_NX_16, available_memory_gb=16.0)
    assert r.fit_level == FitLevel.TOO_TIGHT


def test_score_model_tps_formula():
    """tok/s = (bw / eff_size) * efficiency * speed_mult."""
    model = ModelSpec("M", 7.0)
    quant = "Q4_K_M"
    eff = 0.50
    speed_mult = next(m for n, _, m in QUANT_LADDER if n == quant)
    bpp = 4.6 / 8
    size_gb = 7.0 * 1e9 * bpp / (1024 ** 3)
    expected_tps = (ORIN_NX_16.bandwidth_gbs / size_gb) * eff * speed_mult

    r = score_model(model, quant, ORIN_NX_16, available_memory_gb=16.0)
    assert r.estimated_tps == pytest.approx(expected_tps, rel=1e-4)


# ---------------------------------------------------------------------------
# recommend
# ---------------------------------------------------------------------------

def test_recommend_returns_fits_first():
    model = ModelSpec("Llama-3.1-8B", 8.0)
    results = recommend(model, ORIN_NX_16, available_memory_gb=16.0)

    fits    = [r for r in results if r.fit_level != FitLevel.TOO_TIGHT]
    tights  = [r for r in results if r.fit_level == FitLevel.TOO_TIGHT]

    # All fits come before tights
    if fits and tights:
        last_fit_idx  = max(results.index(r) for r in fits)
        first_tight_idx = min(results.index(r) for r in tights)
        assert last_fit_idx < first_tight_idx


def test_recommend_all_quants_present():
    model = ModelSpec("Llama-3.1-8B", 8.0)
    results = recommend(model, ORIN_NX_16, available_memory_gb=16.0)
    returned_quants = {r.quant for r in results}
    all_quants = {q for q, _, _ in QUANT_LADDER}
    assert returned_quants == all_quants


def test_recommend_tiny_memory_all_too_tight():
    model = ModelSpec("LargeModel", 200.0)
    results = recommend(model, ORIN_NX_16, available_memory_gb=4.0)
    assert all(r.fit_level == FitLevel.TOO_TIGHT for r in results)


# ---------------------------------------------------------------------------
# best_fit
# ---------------------------------------------------------------------------

def test_best_fit_returns_highest_quality():
    model = ModelSpec("Llama-3.1-8B", 8.0)
    result = best_fit(model, ORIN_NX_16, available_memory_gb=16.0)
    assert result is not None
    # Q8_0 should fit an 8B model on 16GB
    assert result.quant == "Q8_0"


def test_best_fit_none_when_too_large():
    model = ModelSpec("HugeModel", 500.0)
    result = best_fit(model, ORIN_NX_16, available_memory_gb=16.0)
    assert result is None


def test_best_fit_dgx_fp4_allows_larger_model():
    model = ModelSpec("Llama-3.1-70B", 70.0)
    # Without DGX, 70B Q8_0 won't fit on 16 GB
    r_orin = best_fit(model, ORIN_NX_16, available_memory_gb=16.0)
    # On DGX Spark with FP4, 70B should fit even at high quant
    r_dgx = best_fit(model, DGX_SPARK, available_memory_gb=128.0)
    assert r_dgx is not None
    if r_orin:
        # DGX should get a better quant or same
        quant_order = [q for q, _, _ in QUANT_LADDER]
        assert quant_order.index(r_dgx.quant) <= quant_order.index(r_orin.quant)


# ---------------------------------------------------------------------------
# KNOWN_MODELS sanity
# ---------------------------------------------------------------------------

def test_known_models_non_empty():
    assert len(KNOWN_MODELS) > 0


def test_known_models_have_positive_params():
    for m in KNOWN_MODELS:
        assert m.params_b > 0, f"{m.name} has non-positive params_b"


def test_known_models_size_at_quant():
    model = ModelSpec("Test", 7.0)
    sizes = model.size_at_quant_gb
    # Q8_0 should be larger than Q4_K_M
    assert sizes["Q8_0"] > sizes["Q4_K_M"]
