"""Avatar video generation operation."""
