"""Avatar creation provider modules."""
