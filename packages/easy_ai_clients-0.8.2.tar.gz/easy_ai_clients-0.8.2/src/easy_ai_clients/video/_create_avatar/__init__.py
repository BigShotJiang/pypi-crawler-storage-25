"""Avatar creation operation package."""
