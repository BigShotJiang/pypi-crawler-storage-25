# -*- coding: utf-8 -*-
"""
账户数据查询接口
"""
from typing                  import Optional
from fastapi                 import APIRouter, HTTPException, Depends
from pydantic                import BaseModel
from .Evaluate                import EvaluateAccData ,NeedGroupData # 直接从包导入
from LOG                     import log
from .                       import get_conbase

acc_router = APIRouter()

class AccountQuery(BaseModel):
    strategy_name: str
    db_name: str
    tbl_name: str
    date_start: Optional[str] = None
    date_end: Optional[str] = None

@acc_router.post("/accounts")
async def get_account_data(query: AccountQuery, conbase = Depends(get_conbase)):
    """
    获取账户表数据，支持按交易日期范围筛选
    """
    try:
        conn = conbase.connect(query.strategy_name)
        sql = f"SELECT * FROM {query.db_name}.{query.tbl_name} WHERE 1=1 "
        if query.date_start:
            sql += f" AND TradeDate >= '{query.date_start}'"
        if query.date_end:
            sql += f" AND TradeDate <= '{query.date_end}'"
        df = conn.GetData(sql)
        conn.Close()
        acc_code_data = {}
        # df.fillna(0, inplace=True)
        # if len(df['AccName'].unique()) >1:
        #     # acc_code_data = {acc_name:{"AccData": df_acc.to_dict(orient="records"),
        #     #                       "Evaluate": EvaluateAccData(df_acc),} 
        #     #                       for acc_name,df_acc in df.groupby("AccName")}
        #     df = NeedGroupData(df)
        #     df.fillna(0, inplace=True)
        return {"AccData": df.to_dict(orient="records"),"Evaluate": EvaluateAccData(df),"AccCode":acc_code_data}
    except Exception as e:
        raise HTTPException(500, detail=str(e))
