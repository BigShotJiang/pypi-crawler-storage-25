from typing                  import Optional
from fastapi                 import APIRouter, HTTPException, Depends
from pydantic                import BaseModel
from .                       import get_conbase

order_router = APIRouter()

class OrderQuery(BaseModel):
    strategy_name: str
    db_name : str
    tbl_name: str
    order_id: Optional[str] = None
    account_id: Optional[str] = None
    code: Optional[str] = None
    type: Optional[int] = None
    status: Optional[int] = None
    create_stime: Optional[str] = None
    create_etime: Optional[str] = None
    update_stime: Optional[str] = None
    update_etime: Optional[str] = None


@order_router.post("/orders")
async def get_orders(query: OrderQuery, conbase = Depends(get_conbase)):
    """
    按条件筛选订单数据，策略名称和筛选条件均在请求体中传递。
    """
    try:
        conn = conbase.connect(query.strategy_name)
        sql = f"SELECT * FROM {query.db_name}.{query.tbl_name} WHERE 1=1"
        if query.order_id:
            sql += f" AND OrderID = '{query.order_id}'"
        if query.account_id:
            sql += f" AND AccountID = '{query.account_id}'"
        if query.code:
            sql += f" AND Code = '{query.code}'"
        if query.type is not None:
            sql += f" AND Type = '{query.type}'"
        if query.status is not None:
            sql += f" AND Status = '{query.status}'"
        if query.create_stime:
            sql += f" AND CreateTime >= '{query.create_stime}'"
        if query.create_etime:
            sql += f" AND CreateTime <= '{query.create_etime}'"
        if query.update_stime:
            sql += f" AND UpdateTime >= '{query.update_stime}'"
        if query.update_etime:
            sql += f" AND UpdateTime <= '{query.update_etime}'"
        ### 添加limit 1000
        sql += "order by CreateTime desc LIMIT 2500"
        df = conn.GetData(sql)
        conn.Close()
        return df.to_dict(orient="records")
    except Exception as e:
        raise HTTPException(500, detail=str(e))