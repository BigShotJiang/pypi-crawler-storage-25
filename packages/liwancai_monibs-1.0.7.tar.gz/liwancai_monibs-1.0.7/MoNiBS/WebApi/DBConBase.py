from PyDBLinks.DBDuck                   import DuckDB
from PyTools.Dict                       import DictGETKEY    
from DirsFile                           import EndWithPath,SplitDir
class DBConBase:
    def __init__(self, cfg):
        defaultcfg = {
            'SaveDataPath': './',
            'db_path': './',  # 数据库文件夹路径
            'db_name': 'test.db',          # 数据库文件名
            'memory_limit': '2GB',         # 内存限制
            'threads': 4,                   # 线程数
            'temp_directory': './tmp/',     # 临时目录
            'read_only': True              # 是否只读
            }
        cfg = {**defaultcfg,**cfg} ### 合并默认配置和用户配置
        DBCfg = EndWithPath(cfg["SaveDataPath"],[".db"])
        DBCfg = [ {**cfg,'db_path':SplitDir(x)[0],'db_name':SplitDir(x)[1],
                    'temp_directory':SplitDir(x)[0]+"/tmp",} for x in DBCfg]
        self.DBCfg = {x['db_name']:x for x in DBCfg}
    def getStrategyNames(self):
        return DictGETKEY(self.DBCfg)
    def connect(self, StrategyName):
        return DuckDB(self.DBCfg[StrategyName])
    def getDBNames(self,duckdb:DuckDB):
        DBNames = [x for x in duckdb.GetDBs() if x != "main"]
        return DBNames
    def getTblNames(self,duckdb:DuckDB,db_name:str=None):
        return duckdb.GetTbls(db_name)
 