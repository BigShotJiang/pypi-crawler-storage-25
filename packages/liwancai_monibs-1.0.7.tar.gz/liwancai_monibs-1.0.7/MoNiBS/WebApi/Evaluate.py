# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
from typing                     import  Dict
from fastapi                    import  HTTPException
 
def NeedGroupData(df: pd.DataFrame):
    """
    如果有多个账户，需要按TradeTime分组聚合数据
    """
    if len(df['AccName'].unique()) >1:
        tradeTimes = df['TradeTime'].unique()
        codedata = {}
        rst =[]
        for TradeTime in tradeTimes:
            data = df[df['TradeTime']==TradeTime]
            for code  in data['AccName']:
                codedata[code] = data[data['AccName']==code].to_dict(orient="records")[0]
            sumdata ={
                    'AccName': "total",
                    'AccountID': "total_account",
                    'TradeTime': TradeTime,
                    'TradeDate': TradeTime[:10],
                    'FundsOut': 0,
                    'FundsInit': 0,
                    'FundsSum': 0,
                    'FundsHold': 0,
                    'FundsAble': 0,
                    'HoldEarn': 0,
                    'FundsEarnSum': 0,
                    'FundsUseRatio': 0,### 需要计算 
                    'FeesSum': 0}
            for code in codedata:
                sumdata['FundsOut'] += codedata[code]['FundsOut']
                sumdata['FundsInit'] += codedata[code]['FundsInit']
                sumdata['FundsSum'] += codedata[code]['FundsSum']
                sumdata['FundsHold'] += codedata[code]['FundsHold']
                sumdata['FundsAble'] += codedata[code]['FundsAble']
                sumdata['HoldEarn'] += codedata[code]['HoldEarn']
                sumdata['FundsEarnSum'] += codedata[code]['FundsEarnSum']
                sumdata['FeesSum'] += codedata[code]['FeesSum']
                sumdata['FundsUseRatio'] = sumdata['FundsHold'] / sumdata['FundsSum']
            rst.append(sumdata)
        return pd.DataFrame(rst)
    return df
 
    

def EvaluateAccData(data: pd.DataFrame,risk_free_rate: float = 0.03,benchmark_returns=[],benchmark_dates: list = []):
    df = NeedGroupData(data)
    # 数据预处理 - 按日期+时间排序确保时序正确
    df["TradeDate"] = pd.to_datetime(df["TradeDate"])
    df["TradeTime"] = pd.to_datetime(df["TradeTime"])
    df.sort_values(["TradeDate", "TradeTime"], inplace=True)
    df.reset_index(drop=True, inplace=True)
    # 计算日收益率
    df["DailyReturn"] = df["FundsSum"].pct_change().fillna(0)
    daily_returns = df["DailyReturn"]
    # 基础数据
    initial_funds = df.iloc[0]["FundsInit"]
    final_funds = df.iloc[-1]["FundsSum"]
    total_return = (final_funds - initial_funds) / initial_funds
    trading_days = len(df)
    # 年化收益率
    annual_return = (1 + total_return) ** (252 / trading_days) - 1 if trading_days > 0 else 0
    # 最大回撤信息（含持续时间）- 使用TradeTime作为时间序列
    dd_info = calc_drawdown_info(df["FundsSum"], df["TradeTime"])
    # 年化波动率（仅保留此项，删除日度标准差避免重复）
    daily_volatility = daily_returns.std()
    annual_volatility = daily_volatility * np.sqrt(252)
    # 风险调整收益指标
    sharpe_ratio = calc_sharpe_ratio(daily_returns, risk_free_rate)
    sortino_ratio = calc_sortino_ratio(daily_returns,risk_free_rate)
    calmar_ratio = calc_calmar_ratio(daily_returns, dd_info["最大回撤比例"] / 100)
    # 基准相关指标（如果提供了真实基准序列）
    information_ratio = 0.0
    alpha, beta = 0.0, 0.0
    benchmark_series = None
    if benchmark_returns :
        # 基准序列长度必须与回测数据一致
        if len(benchmark_returns) != len(df):
            raise HTTPException(400, "基准收益率序列长度必须与回测数据一致")
        benchmark_series = pd.Series(benchmark_returns)
        # 信息比率
        information_ratio = calc_information_ratio(daily_returns, benchmark_series)
        # Alpha/Beta
        alpha, beta = calc_alpha_beta(daily_returns, benchmark_series)
    # VaR和CVaR
    var_95, cvar_95 = calc_var_cvar(daily_returns, 0.95)
    # 交易统计（日频）
    trade_stats = calc_trade_stats(df)
    # 连续盈亏天数
    cont_stats = calc_continuous_stats(daily_returns)
    # 月度正收益占比 - 使用TradeTime提取月份
    monthly_win_ratio = calc_monthly_win_ratio(df["TradeTime"], daily_returns)
    # 资金利用率与成本
    avg_utilization = df["FundsUseRatio"].mean() * 100 if "FundsUseRatio" in df else 0.0
    total_fee = df["FeesSum"].iloc[-1] if "FeesSum" in df else 0
    fee_ratio = total_fee / initial_funds * 100 if initial_funds != 0 else 0.0
    # 峰度（Kurtosis）
    kurtosis = float(daily_returns.kurtosis())
    # 最大/最小日收益率（百分比）
    max_daily_return = float(daily_returns.max() * 100)
    min_daily_return = float(daily_returns.min() * 100)
    # 累计收益金额
    total_profit_amount = final_funds - initial_funds
    # 时间范围 - 使用TradeTime获取精确时间
    start_date = df["TradeTime"].min().strftime("%Y-%m-%d")
    end_date = df["TradeTime"].max().strftime("%Y-%m-%d")
    # ================== 组装结果（中文key） ==================
    result = {
        # 基础收益指标
        "基础收益指标": {
            "初始资金": float(initial_funds),
            "最终资金": float(final_funds),
            "累计收益金额": float(total_profit_amount),
            "累计收益率_%": float(total_return * 100),
            "年化收益率_%": float(annual_return * 100),
            "平均日收益率_%": float(daily_returns.mean() * 100),
            "交易天数": int(trading_days),
            "最大日收益率_%": max_daily_return,
            "最小日收益率_%": min_daily_return,
            "总手续费占比_%": round(fee_ratio, 3)
        },
        # 风险调整收益指标
        "风险调整收益指标": {
            "夏普比率": round(sharpe_ratio, 3),
            "索提诺比率": round(sortino_ratio, 3),
            "卡玛比率": round(calmar_ratio, 3),
            "信息比率": round(information_ratio, 3) if benchmark_returns else None
        },

        # 风险指标
        "风险指标": {
            "最大回撤比例_%": round(dd_info["最大回撤比例"], 2),
            "最大回撤金额": round(dd_info["最大回撤金额"], 2),
            "最大回撤开始日期": dd_info["最大回撤开始日期"],
            "最大回撤结束日期": dd_info["最大回撤结束日期"],
            "最大回撤持续时间_天": dd_info["最大回撤持续时间"],
            "回撤恢复时间_天": dd_info["回撤恢复时间"],
            "年化波动率_%": round(annual_volatility * 100, 2),
            "VaR_95_%": round(var_95, 2),
            "CVaR_95_%": round(cvar_95, 2),
            "峰度": round(kurtosis, 3)
        },

        # 交易统计指标（日频）
        "交易统计指标": {
            "胜率_日_%": round(trade_stats["胜率_日"], 1),
            "盈利天数": trade_stats["盈利天数"],
            "亏损天数": trade_stats["亏损天数"],
            "盈亏比_日": round(trade_stats["盈亏比_日"], 2),
            "最大连续盈利天数": cont_stats["最大连续盈利天数"],
            "最大连续亏损天数": cont_stats["最大连续亏损天数"],
            "正收益月份占比_%": round(monthly_win_ratio, 1)
        },

        # 资金效率与成本
        "资金效率与成本": {
            "平均资金利用率_%": round(avg_utilization, 2),
            "总手续费占比_%": round(fee_ratio, 2)
        },

        # 高级统计指标
        "高级统计指标": {
            "Alpha_年化_%": round(alpha * 100, 3) if benchmark_returns else None,
            "Beta": round(beta, 3) if benchmark_returns else None,
            "偏度": round(daily_returns.skew(), 3),
            "峰度": round(kurtosis, 3)
        },

        # 时间相关指标
        "时间相关指标": {
            "数据开始日期": start_date,
            "数据结束日期": end_date,
        }
    }
    return result
# ================== 指标计算辅助函数 ==================

def calc_drawdown_info(funds_series: pd.Series, time_series: pd.Series):
    """
    计算回撤信息，包括回撤金额、回撤比例、最大回撤起止日期、回撤持续时间、回撤恢复时间
    参数:
        funds_series: 资金序列
        time_series: 时间序列(TradeTime)，用于确定回撤起止时间点
    """
    running_max = funds_series.cummax()
    drawdown_amount = running_max - funds_series
    drawdown_ratio = drawdown_amount / running_max

    max_dd_amount = drawdown_amount.max()
    max_dd_ratio = drawdown_ratio.max()

    if max_dd_amount <= 0:
        return {
            "最大回撤金额": 0.0,
            "最大回撤比例": 0.0,
            "最大回撤开始日期": None,
            "最大回撤结束日期": None,
            "最大回撤持续时间": 0,
            "回撤恢复时间": 0
        }

    # 使用位置索引(iloc)而非标签索引(loc)确保准确性
    # 找到最大回撤比例的位置
    end_pos = drawdown_ratio.values.argmax()
    # 找到该位置之前running_max等于当前running_max的最后一个位置
    current_max = running_max.iloc[end_pos]
    peak_pos = end_pos
    for i in range(end_pos, -1, -1):
        if running_max.iloc[i] == current_max:
            peak_pos = i
        elif running_max.iloc[i] < current_max:
            break

    # 回撤持续时间 = 低谷位置 - 高峰位置 (交易日数)
    dd_duration = end_pos - peak_pos

    # 计算回撤恢复时间（从低谷恢复到前期高点所需交易日数）
    recovery_days = 0
    if end_pos < len(funds_series) - 1:
        for i in range(end_pos + 1, len(funds_series)):
            if funds_series.iloc[i] >= current_max:
                recovery_days = i - end_pos
                break

    start_time = time_series.iloc[peak_pos]
    end_time = time_series.iloc[end_pos]

    return {
        "最大回撤金额": float(max_dd_amount),
        "最大回撤比例": float(max_dd_ratio * 100),
        "最大回撤开始日期": start_time.strftime("%Y-%m-%d") if hasattr(start_time, 'strftime') else str(start_time)[:10],
        "最大回撤结束日期": end_time.strftime("%Y-%m-%d") if hasattr(end_time, 'strftime') else str(end_time)[:10],
        "最大回撤持续时间": int(dd_duration),
        "回撤恢复时间": int(recovery_days)
    }


def calc_sharpe_ratio(returns: pd.Series, risk_free_rate: float = 0.03) -> float:
    """计算夏普比率"""
    excess_returns = returns - risk_free_rate / 252
    if excess_returns.std() == 0:
        return 0.0
    return float(excess_returns.mean() / excess_returns.std() * np.sqrt(252))


def calc_sortino_ratio(returns: pd.Series, risk_free_rate: float = 0.03) -> float:
    """计算索提诺比率（只考虑下行波动）"""
    excess_returns = returns - risk_free_rate / 252
    downside_returns = excess_returns[excess_returns < 0]
    if len(downside_returns) == 0 or downside_returns.std() == 0:
        return 0.0
    downside_std = downside_returns.std() * np.sqrt(252)
    return float(excess_returns.mean() * 252 / downside_std)


def calc_calmar_ratio(returns: pd.Series, max_drawdown_ratio: float) -> float:
    """计算卡玛比率（年化收益/最大回撤）"""
    if max_drawdown_ratio == 0:
        return 0.0
    annual_return = returns.mean() * 252
    return float(annual_return / abs(max_drawdown_ratio))


def calc_information_ratio(returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """计算信息比率（超额收益/跟踪误差），需要真实基准序列"""
    active_returns = returns - benchmark_returns
    if active_returns.std() == 0:
        return 0.0
    return float(active_returns.mean() / active_returns.std() * np.sqrt(252))


def calc_var_cvar(returns: pd.Series, confidence: float = 0.95) -> tuple:
    """计算VaR和CVaR（风险价值）"""
    var = np.percentile(returns, (1 - confidence) * 100)
    cvar = returns[returns <= var].mean() if len(returns[returns <= var]) > 0 else var
    return float(var * 100), float(cvar * 100)


def calc_alpha_beta(returns: pd.Series, benchmark_returns: pd.Series) -> tuple:
    """计算Alpha（年化）和Beta，需要真实基准序列"""
    if len(returns) != len(benchmark_returns) or benchmark_returns.std() == 0:
        return 0.0, 0.0

    covariance = np.cov(returns, benchmark_returns)[0, 1]
    benchmark_variance = benchmark_returns.var()

    if benchmark_variance == 0:
        beta = 0.0
    else:
        beta = covariance / benchmark_variance

    alpha = returns.mean() - beta * benchmark_returns.mean()
    return float(alpha * 252), float(beta)


def calc_continuous_stats(returns: pd.Series) -> Dict:
    """计算最大连续盈利天数和最大连续亏损天数"""
    sign = returns.apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
    # 连续盈利
    win_streaks = (sign == 1).astype(int).groupby((sign != 1).cumsum()).cumsum()
    max_win_streak = win_streaks.max() if len(win_streaks) > 0 else 0
    # 连续亏损
    loss_streaks = (sign == -1).astype(int).groupby((sign != -1).cumsum()).cumsum()
    max_loss_streak = loss_streaks.max() if len(loss_streaks) > 0 else 0
    return {
        "最大连续盈利天数": int(max_win_streak),
        "最大连续亏损天数": int(max_loss_streak)
    }


def calc_monthly_win_ratio(dates: pd.Series, returns: pd.Series) -> float:
    """正收益月份占比（基于月度收益率）"""
    df = pd.DataFrame({"date": dates, "return": returns})
    df["month"] = df["date"].dt.to_period("M")
    monthly_ret = df.groupby("month")["return"].apply(lambda x: (1 + x).prod() - 1)
    if len(monthly_ret) == 0:
        return 0.0
    positive_months = (monthly_ret > 0).sum()
    return positive_months / len(monthly_ret) * 100


def calc_trade_stats(df: pd.DataFrame) -> Dict:
    """计算基于日收益率的交易统计指标（不含资金利用率等）"""
    if "DailyReturn" not in df.columns:
        df["DailyReturn"] = df["FundsSum"].pct_change().fillna(0)

    daily_returns = df["DailyReturn"]

    winning_days = (daily_returns > 0).sum()
    losing_days = (daily_returns < 0).sum()
    total_trading_days = winning_days + losing_days
    win_rate = (winning_days / total_trading_days * 100) if total_trading_days > 0 else 0.0

    avg_profit = daily_returns[daily_returns > 0].mean() if winning_days > 0 else 0
    avg_loss = abs(daily_returns[daily_returns < 0].mean()) if losing_days > 0 else 0
    profit_loss_ratio = avg_profit / avg_loss if avg_loss != 0 else 0.0

    return {
        "胜率_日": float(win_rate),
        "盈利天数": int(winning_days),
        "亏损天数": int(losing_days),
        "盈亏比_日": float(profit_loss_ratio),
    }

