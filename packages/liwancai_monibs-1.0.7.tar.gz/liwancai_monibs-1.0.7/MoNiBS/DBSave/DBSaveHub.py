
import os
import pandas                       as pd
from LOG                            import log
from DirsFile                       import Mkdir
from typing                         import List,Dict
from PyDBLinks.DBDuck               import DuckDB

class DBSaveHub:
    def __init__(self,cfg:dict):
        '''
        初始化数据库保存中心
        :param cfg: 配置字典
        :param cfg["StrategyName"]: 策略名称
        :param cfg["TblName"]: 表名
        :param cfg["SaveDataPath"]: 保存数据路径
        :return: None

        {'SaveDataPath':"./",
         'StrategyName':'CL_001',
         'TblName':'tbl_CL_001',
         'DuckDB_Read_only':False,
         'DuckDB_MemoryLimit':'2GB',
         'DuckDB_TempPath':'./tmp',
         'AccountDBName':'AccountDB',
         'HoldINFODBName':'HoldINFODB',
         'OrderDBName':'OrderDB',
         }
   
        '''
        self.StrategyName   = cfg["StrategyName"]
        self.TblName        = cfg.get("TblName",f"tbl_{self.StrategyName}")
        self.SaveDataPath   = os.path.join(cfg.get("SaveDataPath","./"),self.StrategyName)
        Mkdir(self.SaveDataPath)
        self.duckdb             :DuckDB  = None  # DuckDB 连接对象
        ### 初始化 DDL 映射字典
        self.AccDDLDict         :dict  = None  # 表名 到 DDL 的映射
        self.HoldDDLDict        :dict  = None  # 表名 到 DDL 的映射
        self.OrderDDLDict       :dict  = None  # 表名 到 DDL 的映射
        ### 初始化数据库名称
        self.AccDBName          = cfg.get('AccountDBName','AccountDB')
        self.HoldDBName         = cfg.get('HoldINFODBName','HoldINFODB')
        self.OrderDBName        = cfg.get('OrderDBName','OrderDB')
        ### 初始化数据库连接 并完成数据库创建
        self.InitDBSave(cfg)
    def getDBNames(self):
        '''
        获取所有数据库名称
        :return: 数据库名称列表
        '''
        return [self.AccDBName,self.HoldDBName,self.OrderDBName]
    def getTblName(self):
        '''
        获取所有表名
        :return: 表名列表
        '''
        return self.TblName
    def __enter__(self):
        return self
    def Close(self):
        if self.duckdb:
            self.duckdb.Close()
            log.Info(f"Close DB {self.Duckdbfile}")
            self.duckdb = None
    def InitDBSave(self,cfg:dict, read_only=False):
        '''
        初始化数据库连接 并完成数据库创建
        :param cfg: 配置字典
        :param read_only: 是否只读模式
        :return: DuckDB 连接对象
        '''
        defaultcfg = {
            'db_path': self.SaveDataPath,  # 数据库文件夹路径
            'db_name': f"{self.StrategyName}.db",          # 数据库文件名
            'memory_limit':cfg.get('DuckDB_MemoryLimit','2GB'),         # 内存限制
            'threads': cfg.get('DuckDB_Threads',4),                   # 线程数
            'temp_directory': cfg.get('DuckDB_TempPath','./tmp'),     # 临时目录
            'read_only': cfg.get('DuckDB_Read_only',read_only)              # 是否只读
            }
        self.duckdb = DuckDB(defaultcfg)
        ### 创建数据库
        ok = self.duckdb.CreateDB(self.AccDBName)
        log.Info(f"Create DB {self.AccDBName}:{ok}")
        ok = self.duckdb.CreateDB(self.HoldDBName)
        log.Info(f"Create DB {self.HoldDBName}:{ok}")
        ok = self.duckdb.CreateDB(self.OrderDBName)
        log.Info(f"Create DB {self.OrderDBName}:{ok}")
        return self.duckdb
    def SaveAccData(self,results:List[Dict] ):
        '''
        保存账户数据到DuckDB
        '''
        data = pd.DataFrame(results)
        if  data.empty: return
        if self.AccDDLDict is None:
            self.AccDDLDict = self.duckdb.getDDL(data)
            ok = self.duckdb.CreateTbl(self.TblName, 
                DDL     =   self.AccDDLDict,
                Mkey    =   ['AccountID','TradeTime'],
                dbname  =   self.AccDBName )
            log.Info(f"Create Table {self.TblName} in DB {self.AccDBName}:{ok}")
        self.duckdb.SaveDF(data , self.TblName , dbname = self.AccDBName  )
    def SaveHoldData(self,results:List[Dict] ):
        '''
        保存持仓数据到DuckDB
        '''
        data = pd.DataFrame(results)
        if  data.empty: return
        if self.HoldDDLDict is None:
            self.HoldDDLDict     = self.duckdb.getDDL(data)
            ok = self.duckdb.CreateTbl(self.TblName, 
                DDL     =   self.HoldDDLDict,
                Mkey    =   ['Code','AccountID','HoldType','TradeTime','HoldNum'],
                dbname  =   self.HoldDBName )
            log.Info(f"Create Table {self.TblName} in DB {self.HoldDBName}:{ok}")
        self.duckdb.SaveDF(data , self.TblName , dbname = self.HoldDBName  )
    def SaveOrderData(self,results:List[Dict] ):
        '''
        保存订单数据到DuckDB
        '''
        data = pd.DataFrame(results)
        if  data.empty: return
        if self.OrderDDLDict is None:
            self.OrderDDLDict     = self.duckdb.getDDL(data)
            ok = self.duckdb.CreateTbl(self.TblName, 
                DDL     =   self.OrderDDLDict,
                Mkey    =   ['OrderID','Code','AccountID','UpdateTime','SystemTime'],
                dbname  =   self.OrderDBName )
            log.Info(f"Create Table {self.TblName} in DB {self.OrderDBName}:{ok}")
        self.duckdb.SaveDF(data , self.TblName , dbname = self.OrderDBName  )
 
    