
import re

def ParsePGFH(ADJ: str, HoldNum: float) -> tuple[float, float]:
    """
    解析分红配股字符串并计算持仓变化
    :param ADJ: 分红配股字符串
    :param HoldNum: 当前持仓数量(股)
    :return: 新增加持仓数量(股), 获得的现金分红(元)
    """
    if not ADJ: return 0.0, 0.0
    # 初始化变量
    sendShares = 0.0      # 送股数量 (每10股送X股)
    transferShares = 0.0  # 转增股数量 (每10股转增X股)
    cashPGFH = 0.0        # 现金分红 (每10股派X元)
    # 清理字符串
    cleaned_str = ADJ.strip().replace(" ", "")
    cleaned_str = cleaned_str.replace("元", "")
    cleaned_str = cleaned_str.replace("转增", "转")
    # 解析送股
    match_send = re.search(r"送(\d+\.?\d*)", cleaned_str)
    if match_send:
        try:
            sendShares = float(match_send.group(1))
        except ValueError:
            pass

    # 解析转增股
    match_transfer = re.search(r"转(\d+\.?\d*)", cleaned_str)
    if match_transfer:
        try:
            transferShares = float(match_transfer.group(1))
        except ValueError:
            pass

    # 解析现金分红
    match_cash = re.search(r"派(\d+\.?\d*)", cleaned_str)
    if match_cash:
        try:
            cashPGFH = float(match_cash.group(1))
        except ValueError:
            pass

    # 计算新持仓和现金
    addHoldNum = 0.0
    cashReceived = 0.0

    # 送股
    if sendShares > 0:
        addHoldNum += HoldNum * sendShares / 10.0

    # 转增股
    if transferShares > 0:
        addHoldNum += HoldNum * transferShares / 10.0

    # 现金分红
    if cashPGFH > 0:
        cashReceived = abs(HoldNum) * cashPGFH / 10.0

    return addHoldNum, cashReceived