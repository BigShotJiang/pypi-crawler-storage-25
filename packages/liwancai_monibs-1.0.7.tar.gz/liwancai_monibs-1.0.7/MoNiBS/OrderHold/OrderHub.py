from LOG                         import log
from .Order           import OrderN 
from .Hold            import HoldN, Hold 
from .Type            import BSType,IsK,IsP,getBSTypeGroup
from .Type            import OrderStatus
from PyTools.TimeDate            import NowTime
from ..utils.DataType            import KLineN
from ..MgrData.CodeFees          import CodeFeesN
from .OrderDeal       import getBaseMargin
from .OrderPGFH       import ParsePGFH

class OrderHub:
    def __init__(self):
        # 初始化只做：注册动态订单方法
        self.Holds  : dict[str, HoldN]  = {}### 持仓管理器，键为Code，值为持仓 HoldN 对象
        self.Orders : dict[str, OrderN] = {}### 订单管理器，键为订单ID，值为订单OrderN对象
    def Order_Add(self, Order: OrderN):
        '''添加订单'''
        if Order.OrderID in self.Orders:
            log.Warn(f"订单ID {Order.OrderID} 已存在:\n{self.Orders[Order.OrderID]}")
            return False
        self.Orders[Order.OrderID] = Order### 添加订单
        log.Info(f"订单ID {Order.OrderID} 提交成功:\n{Order}")
        return True
    def FlashHoldNumNDs(self):
        '''
        更新持仓可平仓数量容器 使用位置代码案例:👇
        def Run(self,SDate="",EDate=""):
            self.MgrData.getDoDateTime(SDate,EDate) ### 获取交易日列表 交易时间列表
            Tqdm = TqdmN(len(self.MgrData.KDates))
            for Tradedate in self.MgrData.KDates:
                Tqdm.update(Tradedate)
        👉      self.Order.FlashHoldNumNDs()   ###   每个交易日开始 更新可平仓数量 ### 👈
                for Time  in self.MgrData.KTimes:
                    ### 获取行情数据 --> 发送给策略处理
                    TradeTime = f"{Tradedate} {Time}"
        '''
        for key in self.Holds.keys(): 
            if self.Holds[key].BSTDNum <= 0: 
                self.Holds[key].HoldNumNDs = []
                self.Holds[key].AblePNum  = self.Holds[key].HoldNum
                continue
            self.Holds[key].HoldNumNDs.append(0.0)
            self.Holds[key].HoldNumNDs= self.Holds[key].HoldNumNDs[-self.Holds[key].BSTDNum:]
            self.Holds[key].AblePNum  = self.Holds[key].HoldNum - sum(self.Holds[key].HoldNumNDs)### 可平数量
    def Set_OrderStatus(self, OrderID: str, Status: OrderStatus,UpdateTime: str='') -> bool:
        '''
        设置订单状态
        应用场景:对订单进行编辑处理时
        '''
        if OrderID in self.Orders:
            self.Orders[OrderID].Status     = Status### 订单状态更新
            self.Orders[OrderID].UpdateTime = UpdateTime ### 订单更新时间更新
            self.Orders[OrderID].SystemTime = NowTime()### 订单更新时间更新
            return True
        return False
    def Order_Cancel(self, OrderID: str,UpdateTime: str|int='') -> bool:
        '''
        取消订单
        应用场景:撤单
        '''
        if OrderID in self.Orders:
            self.Orders[OrderID].Status = OrderStatus.Canceled### 订单状态更新
            self.Orders[OrderID].UpdateTime = UpdateTime ### 订单更新时间更新
            self.Orders[OrderID].SystemTime = NowTime()### 订单更新时间更新
            return True
        return False
    def Order_Del(self, OrderID: str) -> OrderN:
        '''
        删除订单
        只在每个交易日结束后执行 用于清除哪些无效的订单
        '''
        if OrderID in self.Orders:
            del self.Orders[OrderID]### 删除订单
            return True
        return None
    def Hold_Del(self, Code: str,BSType:BSType,key:str=None) -> HoldN:
        '''删除持仓
        清仓后持仓为0 
        '''
        if key is None: 
            key =  self.getHoldKey(Code,BSType)
        if key in self.Holds:
            del self.Holds[key]### 删除持仓
            return True
        return None
    def Order_Get(self, OrderID: str) -> OrderN:
        '''获取订单'''
        if OrderID in self.Orders:
            return self.Orders[OrderID]
        return None
    def Hold_Get(self,Code: str=None,BSType:BSType=None) -> dict[str, HoldN]|HoldN:
        '''获取持仓'''
        if Code is None: return self.Holds
        key =  self.getHoldKey(Code,BSType)
        if key in self.Holds:return self.Holds[key]
        return None
    def Hold_GetAdd(self,codeOrder:OrderN, Kline:KLineN ):
        '''如果不存在 就添加持仓 '''
        key =  self.getHoldKey(codeOrder.Code,codeOrder.Type)
        if key not in self.Holds: ###  持仓不存在就创建新持仓
            self.Holds[key] = Hold(codeOrder.AccountID,Kline,codeOrder.Type,codeOrder.BSTDNum)
        return self.Holds[key]
    def getHoldKey(self,Code:str,BSType:BSType) -> str:
        '''获取持仓的键值'''
        return f"{Code}_{getBSTypeGroup(BSType)}"
    def FlashFQPGFH(self,key:str,Kline:KLineN):
        ### 当分红配股的时候 更新持仓及盈亏
        if self.Holds[key].Hfq != Kline.hfq  :### 说明有分红配股
            if Kline.ADJ:
                ### 更新持仓数量 和资金 
                addHoldNum, cashReceived = ParsePGFH(Kline.ADJ,self.Holds[key].HoldNum)
                # 如果有送股或转增股，需要调整成本价
                if addHoldNum > 0:
                    # 送股/转增股后，总成本不变，但持仓数量增加，需要重新计算成本价
                    total_cost = self.Holds[key].HoldCost * self.Holds[key].HoldNum
                    new_hold_num = self.Holds[key].HoldNum + addHoldNum
                    self.Holds[key].HoldCost = total_cost / new_hold_num if new_hold_num > 0 else self.Holds[key].HoldCost
                self.Holds[key].HoldNum += addHoldNum
                self.Holds[key].EarnSum += cashReceived### 结算盈亏更新
            else:
                if self.Holds[key].Hfq!=0:
                    # 根据后复权值调整持仓数量时，需要同时更新成本价
                    ratio = Kline.hfq / self.Holds[key].Hfq
                    self.Holds[key].HoldNum *= ratio
                    if ratio != 1.0 and ratio != 0.0: self.Holds[key].HoldCost /= ratio# 成本价按反比例调整
            self.Holds[key].Hfq      = Kline.hfq### 最新市场价格
    def Hold_Update(self,key:str,Kline:KLineN,codeFees: CodeFeesN):
        if key not in self.Holds: return False### 持仓不存在 不处理
        self.Holds[key].UpdateTime = Kline.trade_time### 更新时间
        self.Holds[key].TradeDate  = Kline.trade_date### 交易日期    
        self.Holds[key].TradeTime  = Kline.trade_time### 交易时间
        self.Holds[key].Price      = Kline.close### 最新市场价格
        self.FlashFQPGFH(key,Kline)    ### 复权 分红 配股 处理
        BaseMargin = getBaseMargin(Kline.close,self.Holds[key].HoldType,codeFees) ### 以收盘价计算占用保证金
        self.Holds[key].HoldFunds  = BaseMargin * abs(self.Holds[key].HoldNum) ### 持仓资金|占用保证金
        self.Holds[key].HoldEarn   = self.Holds[key].HoldNum *(Kline.close - self.Holds[key].HoldCost)### 未清仓时的浮动盈亏
        return True
    def Hold_BS_Update(self,Kline:KLineN,
                codeOrder:OrderN,codeFees: CodeFeesN,
                BSPrice:float,BSNum:float,KFees:float=0.0):
        ### 更新持仓信息 
        key =  self.getHoldKey(codeOrder.Code,codeOrder.Type)### 获取持仓Key
        if IsP(codeOrder.Type) and (key not in self.Holds): return False### 平仓订单 持仓不存在 不处理
        if key not in self.Holds: ### 如果是开仓订单 持仓不存在就创建新持仓
            self.Holds[key] = Hold(codeOrder.AccountID,Kline,codeOrder.Type,codeOrder.BSTDNum)
        if self.Holds[key].HoldNum == 0 and self.Holds[key].EarnSum != 0.0: 
            log.Notice(f"[持仓交易更新]:持仓 {key} 清仓后盈亏不为0.0 为避免重复统计,重置为0.0")
            self.Holds[key].EarnSum= 0.0### 冗余设计 检查持仓数量是否为清仓状态 如果有为清理的结算盈亏就重置为0.0
        ### 完成持仓信息的更新 
        self.Holds[key].UpdateTime = Kline.trade_time### 更新时间
        self.Holds[key].TradeDate  = Kline.trade_date### 交易日期    
        self.Holds[key].TradeTime  = Kline.trade_time### 交易时间
        self.Holds[key].Price      = Kline.close### 最新市场价格
        ### 只汇总记录 交易产生时刻的手续费 汇总完毕后清零
        if BSNum!=0: self.Holds[key].BSFees += KFees 
        ### 该笔交易是否是清仓结果  
        rstNum = self.Holds[key].HoldNum + BSNum ### 前置计算最新持仓数量 用于成本计算 盈亏计算
        if rstNum!=0:### 不是清仓 更新持仓成本
            self.Holds[key].HoldCost = ( self.Holds[key].HoldCost * self.Holds[key].HoldNum + BSPrice*BSNum) / rstNum
            self.Holds[key].HoldEarn = rstNum*(Kline.close - self.Holds[key].HoldCost)### 未清仓时的浮动盈亏
        else:### 如果是清仓 则需要计算最终盈亏
            self.Holds[key].HoldEarn = 0.0### 未清仓时的浮动盈亏 清仓交易后清零
            self.Holds[key].EarnSum += self.Holds[key].HoldNum * (BSPrice - self.Holds[key].HoldCost)### 清仓计算最终盈亏
        self.Holds[key].FeesSum         += KFees ### 持仓期间手续费总和
        self.Holds[key].HoldNum          = rstNum### 持仓数量更新 
        ### 更新持仓资金
        BaseMargin = getBaseMargin(Kline.close,codeOrder.Type,codeFees) ### 以收盘价计算占用保证金
        self.Holds[key].HoldFunds = BaseMargin * abs(self.Holds[key].HoldNum) ### 持仓资金|占用保证金
        ### 更新可平仓数量容器
        if IsK(codeOrder.Type) and len(self.Holds[key].HoldNumNDs) > 0: ### 属于T+N才有容器空间 
            self.Holds[key].HoldNumNDs[0]   += BSNum  ### 开仓的订单 需要更新最新交易日容器的值
        ### 更新可平仓数量容器
        self.Holds[key].AblePNum  = self.Holds[key].HoldNum - sum(self.Holds[key].HoldNumNDs)### 可平数量
        self.Order_Update(codeOrder.OrderID,Kline,BSNum)### 更新订单状态信息
        return True
    def Order_Update(self,OrderID:str,Kline:KLineN,BSNum:float):
        '''更新订单信息'''
        ### 订单状态不是处理中 不处理
        if self.Orders[OrderID].Status != OrderStatus.Processing: return
        self.Orders[OrderID].OkQty     += BSNum
        if self.Orders[OrderID].Qty - self.Orders[OrderID].OkQty ==0: ### 订单完成状态
            self.Orders[OrderID].Status = OrderStatus.Completed
            self.Orders[OrderID].UpdateTime = Kline.trade_time
            self.Orders[OrderID].SystemTime = NowTime()
        else:
            self.Orders[OrderID].Status = OrderStatus.Pending### 未完全成交 则修改回 待处理 状态
            self.Orders[OrderID].UpdateTime = Kline.trade_time
            self.Orders[OrderID].SystemTime = NowTime()
        