
from dataclasses                     import dataclass
from enum                            import IntEnum

@dataclass
class CodeFeesN:
    Code                            :str              
    VolumeMultiple                  :float    ### 乘数
    ###  保证金信息
    LongMarginRatioByMoney          :float    ### 多头保证金率
    LongMarginRatioByVolume         :float    ### 多头保证金费
    ShortMarginRatioByMoney         :float    ### 空头保证金率
    ShortMarginRatioByVolume        :float    ### 空头保证金费
    ### 手续费信息
    OpenRatioByMoney              :float    ### 开仓手续费率
    OpenRatioByVolume             :float    ### 开仓手续费
    CloseRatioByMoney             :float    ### 平仓手续费率
    CloseRatioByVolume            :float    ### 平仓手续费
    CloseTodayRatioByMoney        :float    ### 平今手续费率
    CloseTodayRatioByVolume       :float    ### 平今手续费费
    ### 最小开仓数量
    MinOpenVolume                   :int    ### 最小开仓数量
def CodeFees(Code):
    codefees = CodeFeesN(
        Code=Code,
        VolumeMultiple=1.0,
        LongMarginRatioByMoney=1,### 多头保证金率
        LongMarginRatioByVolume=0,### 多头保证金费
        ShortMarginRatioByMoney=1,### 空头保证金率
        ShortMarginRatioByVolume=0,### 空头保证金费

        OpenRatioByMoney=0.0,#1.5/1000,### 开仓手续费率
        OpenRatioByVolume=0.0,### 开仓手续费
        CloseRatioByMoney=0.0,#1.5/1000,### 平仓手续费率
        CloseRatioByVolume=0.0,### 平仓手续费
        CloseTodayRatioByMoney=0.0,#1.5/1000,### 平今手续费率
        CloseTodayRatioByVolume=0.0,### 平今手续费费
        MinOpenVolume=100,### 最小开仓数量
    )
    return codefees
