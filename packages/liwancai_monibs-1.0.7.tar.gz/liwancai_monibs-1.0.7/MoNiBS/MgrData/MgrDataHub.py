from typing                                 import Any
from .Client                                import DataClient
from .CodeFees                              import CodeFees
from PyTools                                import DFToType
import pandas                               as pd
import io

class MgrDataHub:
    def __init__(self,cfg:dict = None):
        self.Periods   = cfg.get("Periods",[1440])### 客户端订阅的周期列表
        self.MinPeriod = min(self.Periods)### 最小周期
        self.KDates         = []### 客户端订阅的时间列表 ["20230101","20230102"]
        self.KTimes         = []### 客户端订阅的时间列表 [093100 093200 093300 093400] 
        self.PeriodTimes    = {}### 各周期的时间列表 {1440:[093100 093200 093300 093400],1440:[150000]}

        self.STCodeList      :list             = []   # ST股票代码列表
        self.DaysUPDWDict    :dict             = {}   # 涨停价格数据
        self.CodeBasicDict   :dict             = {}   # 股票上市基础信息
        self.CodeInfoDict    :dict             = {}   # 股票行业等基础信息
        self.DaysMetricsDict :dict             = {}   # 基础指标:pe pb 流通市值 换手率等
        self.client          :DataClient       = None # 数据接口客户端
        self.InitClient(cfg.get("URL","https://api.liwancai.com"),
                        cfg.get("Username",""), cfg.get("Password",""))
    def InitClient(self,URL:str , Username:str ,Password:str ):
        '''
        初始化ApiGroupClient
        '''
        self.client:DataClient  = DataClient(URL)
        self.client.Login(phone=Username,password=Password)
        return self.client 
    def SetPeriods(self,Periods:list):
        self.Periods = [int(x) for x in Periods]
        self.MinPeriod = min(self.Periods)
    def getDoDateTime(self,SDate="",EDate=""):
        for period in self.Periods:
            KDates = self.client.api.KLs.AbleDates( period=period )
            self.KDates.extend(KDates)
            KTimes = self.client.api.KLs.AbleTimes( period=period )
            KTimes.sort()
            self.PeriodTimes[period] = KTimes
            if period == self.MinPeriod: self.KTimes = KTimes
        self.KDates = list[Any](set(self.KDates))### 去重
        if  SDate!="":  self.KDates = [ x  for x in self.KDates if x >= SDate.replace("-","")]
        if  EDate!="":  self.KDates = [ x  for x in self.KDates if x <= EDate.replace("-","")]
        self.KDates.sort()### 排序 升序
    def FlashSTZTInfo(self,trade_date:str=""):
        '''
        获取昨日ST股票列表, 涨停价格数据
        '''
        _,self.STCodeList         = self.client.api.GPs.DaysIsst(trade_date=trade_date)### 获取昨日ST股票列表
        self.DaysUPDWDict         = self.client.api.GPs.DaysUpdw(trade_date=trade_date)### 获取涨停价格数据
    def getBaseInfo(self):
        '''
        获取股票基础信息: 上市日期等
        '''
        self.CodeBasicDict = self.client.api.GPs.getCodeBasic()### 包含上市日期等基础信息
        self.CodeInfoDict  = self.client.api.GPs.getCodeInfo()### 包含行业等基础信息
    

    def getDaysKlines(self,trade_time,period=1440):
        '''
        获取K线数据
        '''
        df = self.client.api.KLs.DaysKline(trade_time=trade_time,period=period)### 获取K线数据
        df = pd.read_parquet(io.BytesIO(df))
        df.rename(columns={x:x.replace("name=","") for x in df.columns},inplace=True)
        DFToType(df,['hfq','REFclose','close','open','high','low'],float)
        DFToType(df,['trade_time','trade_date'],str)
        return df.to_dict(orient='records')
    def getPersMetrics(self,trade_date:str=""):
        '''
        获取N周期后的相对涨幅, 基础指标:pe pb 流通市值 换手率等
        '''
        # self.DaysPersDict           = self.client.api.GPs.DaysPers(trade_date=trade_date)### N周期后的相对涨幅
        self.DaysMetricsDict        = self.client.api.GPs.DaysMetrics(trade_date=trade_date)### 基础指标:pe pb 流通市值 换手率等
        return self.DaysMetricsDict 
    def Fees_Get(self,code):
        '''
        获取手续费
        '''
        # 从接口获取手续费 待实现
        return CodeFees(code)