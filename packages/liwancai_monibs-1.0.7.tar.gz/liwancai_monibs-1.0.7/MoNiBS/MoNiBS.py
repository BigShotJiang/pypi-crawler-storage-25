

import inspect,copy
from   types                                    import MethodType
### 工具包 ###
from LOG                                        import log
from PyTools.Tools                              import TqdmN 
from PyTools.List                               import SetList
### 模块包 ###
from .OrderHold.OrderHub        import OrderHub
from .DBSave.DBSaveHub          import DBSaveHub
from .MgrData.MgrDataHub        import MgrDataHub
from .Account.AccountHub        import AccountHub
from .OrderHold.OrderDeal       import OrderDeal_getKNum,OrderDeal_getPNum
from .OrderHold.OrderDeal       import OrderDeal_getBSPrice,OrderDeal_checkOrder
from .Account.AccountHub        import Account
from .OrderHold.Help            import OrderHelp
from .OrderHold.Order           import Order,OrderStatus
from .utils.DataType            import KLine,KLineN,TickN
from .OrderHold.Type            import BSType,BSTypeString


class MoNiBS:
    def __init__(self,cfg:dict):
        ###初始化主要功能模块###
        self.Order  :OrderHub    = OrderHub()### 订单管理器
        self.Acc    :AccountHub  = AccountHub(cfg)### 账户管理器
        self.DB     :DBSaveHub   = DBSaveHub(cfg)### 数据库保存器
        self.MgrData:MgrDataHub  = MgrDataHub(cfg)### 数据管理器
        ###初始化其他模块###
        self._register_order_methods()### 注册订单方法
    # ====================== 核心：独立注册方法（优雅解耦）======================
    def _register_order_methods(self):
        """
        自动注册所有 BSType 交易方法：KB, KS, PB, PS, KBB, KSS..
        最终效果：self.KB(), self.KS() ..
        """
        def _make_method(bs_type: BSType):
            """内部工厂：生成对应交易类型的订单方法"""
            def order_method(self, *args, **kwargs) -> bool:
                kwargs["BSType"] = bs_type  # 自动注入交易类型
                sig = inspect.signature(Order)
                bound_args = sig.bind(*args, **kwargs)
                bound_args.apply_defaults()
                return self.Order.Order_Add(Order(**bound_args.arguments))
            # 给方法加名字，IDE 友好
            order_method.__name__ = BSTypeString[bs_type]
            return order_method

        # 遍历所有交易类型，批量绑定到 self
        for bs_type in BSType:
            if bs_type == BSType.ND:
                continue  # 跳过无交易类型
            method = _make_method(bs_type)
            setattr(self, BSTypeString[bs_type], MethodType(method, self))
    def OnOrderBS(self,KLs:dict[str, KLineN] ,TKs: dict[str, TickN]):
        keys = self.Order.Orders.keys()### 获取所有的订单 ID
        POrder = [ x for x in keys if int(x.split('_')[0])<0]### 平仓订单ID
        KOrder = [ x for x in keys if int(x.split('_')[0])>0]### 开仓订单ID
        self.OnAccFlash(KLs)### 更新账户信息 -- Hold_Update -- FlashFQPGFH 完成配股分红数据更新及资产入账
        self.OnOrderP(POrder,KLs,TKs)### 先平仓 并完成平仓订单状态更新 -- Hold_BS_Update 完成持仓信息更新
        self.OnAccFlash(KLs)### 更新账户信息 -- Hold_Update  更新及资产入账
        self.OnOrderK(KOrder,KLs,TKs)### 再开仓 并完成开仓订单状态更新 -- Hold_BS_Update 完成持仓信息更新
        self.OnAccFlash(KLs)### 更新账户信息 -- Hold_Update  更新及资产入账
    def OnAccFlash(self,KLs:dict[str, KLineN]):
        accSumDict = {} ###用于汇总 必要账户数据                
        for key in self.Order.Holds.keys() :### 更新账户信息
            Kline = KLs.get(self.Order.Holds[key].Code,None)
            if Kline is None : continue ### 没有K线 有可能停牌 跳过
            codeFees = self.MgrData.Fees_Get(Kline.code)
            self.Order.Hold_Update(key,Kline,codeFees)### 更新持仓信息
            ### 我要汇总散落在各Code的持仓信息中的占用保证金|持仓资金市值  
            ### 需要知道该持仓是由哪一个账户创建的 就汇总到哪一个账户中去
            AccountID = self.Order.Holds[key].AccountID
            ### 如果不存在就创建一个AccountID为key 空的用于汇总 
            accSumDict[AccountID] = accSumDict.get(AccountID,Account(AccountID,0))### 创建账户实例
            accSumDict[AccountID].FundsHold += self.Order.Holds[key].HoldFunds### 汇总该账户下所有持仓占用保证金|持仓市值
            accSumDict[AccountID].FeesSum += self.Order.Holds[key].BSFees### 汇总该账户下所有最新产生的手续费
            self.Order.Holds[key].BSFees   = 0.0###汇总完手续费即刻清零 避免重复汇总
            accSumDict[AccountID].FundsEarnSum += self.Order.Holds[key].EarnSum### 汇总该账户下所有清仓结算盈亏
            self.Order.Holds[key].EarnSum = 0.0### 汇总完盈亏即刻清零 避免重复汇总
            accSumDict[AccountID].HoldEarn += self.Order.Holds[key].HoldEarn### 汇总该账户下所有浮动盈亏
            accSumDict[AccountID].TradeTime = max(accSumDict[AccountID].TradeTime,Kline.trade_time)
            accSumDict[AccountID].TradeDate = max(accSumDict[AccountID].TradeDate,Kline.trade_date)
            
        ### 更新账户值
        for AccountID in accSumDict.keys():
            Acc = self.Acc.Get_Account(AccID=AccountID)
            Acc.TradeTime = accSumDict[AccountID].TradeTime### 覆盖交易时间
            Acc.TradeDate = accSumDict[AccountID].TradeDate### 覆盖交易日期
            Acc.HoldEarn  = accSumDict[AccountID].HoldEarn ### 覆盖浮动盈亏
            Acc.FundsHold = accSumDict[AccountID].FundsHold ### 覆盖持仓资金|占用保证金 和
            Acc.FeesSum  += accSumDict[AccountID].FeesSum   ### 累计到总手续费
            Acc.FundsEarnSum += accSumDict[AccountID].FundsEarnSum### 累计到 清仓结算收益
            ### 计算账户总资金 
            Acc.FundsSum  = ( Acc.FundsInit - Acc.FundsOut ) + (Acc.HoldEarn + Acc.FundsEarnSum ) - Acc.FeesSum
            Acc.FundsAble = Acc.FundsSum - Acc.FundsHold
            Acc.FundsUseRatio = Acc.FundsHold / Acc.FundsSum

    def OnOrderP(self,POrder:list[str],KLs:dict[str, KLineN] ,TKs: dict[str, TickN]):
        for OrderID in POrder:### 先平仓 再开仓
            Kline = KLs.get(self.Order.Orders[OrderID].Code,None)
            Tick  = TKs.get(self.Order.Orders[OrderID].Code,None)
            if Kline is None : continue ### 没有K线订单依然有效 跳过
            if not OrderDeal_checkOrder(self.Order.Orders[OrderID],Kline,Tick):continue### 订单无效或非待处理
            ### 获取模拟的触发交易价格
            BSPrice = OrderDeal_getBSPrice(self.Order.Orders[OrderID],Kline,Tick)
            if BSPrice < 0: 
                self.Order.Set_OrderStatus(OrderID,OrderStatus.Pending,Kline.trade_time)
                log.Warn(f"订单ID {OrderID} 价格 未触发")
                continue### 未触发订单
            ### 获取平仓数量
            codeOrder = self.Order.Orders[OrderID]
            codeHold  = self.Order.Hold_Get(codeOrder.Code,codeOrder.Type)
            codeFees = self.MgrData.Fees_Get(codeOrder.Code)
            if codeHold is None: 
                self.Order.Set_OrderStatus(OrderID,OrderStatus.Failed,Kline.trade_time)
                log.Error(f"订单ID {OrderID} 持仓不存在")
                continue### 持仓不存在
            
            PNum,PFees = OrderDeal_getPNum(codeOrder,codeHold,codeFees,BSPrice)
            if PNum is None: 
                self.Order.Set_OrderStatus(OrderID,OrderStatus.Failed,Kline.trade_time)
                log.Error(f"订单ID {OrderID} 无效")
                continue### 平仓数量无效
            ok = self.Order.Hold_BS_Update(Kline,codeOrder,codeFees,BSPrice,PNum,PFees)### 更新持仓信息
            if not ok: 
                self.Order.Set_OrderStatus(OrderID,OrderStatus.Failed,Kline.trade_time)
                log.Error(f"订单ID {OrderID} 更新持仓信息失败")
                continue### 更新持仓信息失败
    def OnOrderK(self,KOrder:list[str],KLs:dict[str, KLineN] ,TKs: dict[str, TickN]):
        for OrderID in KOrder:### 开仓订单
            Kline = KLs.get(self.Order.Orders[OrderID].Code,None)
            Tick  = TKs.get(self.Order.Orders[OrderID].Code,None)
            if Kline is None : continue ### 没有K线订单依然有效 跳过
            ### 订单检查 -- 是否？ 订单无效或非待处理
            if not OrderDeal_checkOrder(self.Order.Orders[OrderID],Kline,Tick):continue
            ### 获取模拟触发的交易价格
            BSPrice = OrderDeal_getBSPrice(self.Order.Orders[OrderID],Kline,Tick)
            if BSPrice < 0: 
                self.Order.Set_OrderStatus(OrderID,OrderStatus.Pending,Kline.trade_time)
                log.Warn(f"订单ID {OrderID} 价格 未触发")
                continue### 未触发订单
            ### 获取开仓数量
            codeOrder = self.Order.Orders[OrderID]
            account  = self.Acc.Get_Account(codeOrder.Code,codeOrder.AccountID)
            codeFees = self.MgrData.Fees_Get(codeOrder.Code)
            KNum,KFees = OrderDeal_getKNum(codeOrder,account,Kline,BSPrice,codeFees)
            if KNum is None or KNum == 0: 
                self.Order.Set_OrderStatus(OrderID,OrderStatus.Failed,Kline.trade_time)
                log.Error(f"订单ID {OrderID} 无效")
                continue### 开仓数量无效
            ok = self.Order.Hold_BS_Update(Kline,codeOrder,codeFees,BSPrice,KNum,KFees)
            if not ok: 
                self.Order.Set_OrderStatus(OrderID,OrderStatus.Failed,Kline.trade_time)
                log.Error(f"订单ID {OrderID} 更新持仓信息失败")
                continue### 更新持仓信息失败
    def Run(self,SDate="",EDate=""):
        self.MgrData.getDoDateTime(SDate,EDate)### 获取交易日列表 交易时间列表
        Tqdm = TqdmN(len(self.MgrData.KDates))
        for Tradedate in self.MgrData.KDates:
            Tqdm.update(Tradedate)
            self.Order.FlashHoldNumNDs()   ###   每个交易日开始 更新可平仓数量 
            for Time  in self.MgrData.KTimes:
                ### 获取行情数据 --> 发送给策略处理
                TradeTime = f"{Tradedate} {Time}"
                PeriodKLs ={}
                for period in self.MgrData.Periods:
                    if Time in self.MgrData.PeriodTimes[period]:
                        klines =  self.MgrData.getDaysKlines(TradeTime,period)
                        KLs = {x['code']:KLine(**x) for x in klines}### 转换为KLineN类型
                        PeriodKLs[period] =KLs ### 按周期记录
                self.OnBar(TradeTime,PeriodKLs,{})### 发送K线数据给策略处理
                self.OnOrderBS(PeriodKLs[self.MgrData.MinPeriod],{})
             ### DataSave 保存回测数据
            self.SaveData() ### 
       
    def SaveData(self ):
        ### ============================ 保存持仓数据 ============================ ###
        Holds  = []### 持仓数据列表
        AccIDs = []### 账户ID列表
        holds_to_delete = []# 先收集需要删除的持仓键，避免在迭代时修改字典
        ### 遍历持仓信息，记录持仓数据和账户ID列表
        log.Info(f"当前持仓列表：{self.Order.Holds.keys()} 持仓数量{len(self.Order.Holds.keys())}")
        for key in self.Order.Holds.keys():
            Holds.append(copy.deepcopy(self.Order.Holds[key].__dict__))### 深度拷贝持仓数据
            AccountID = self.Order.Holds[key].AccountID
            AccIDs.append(AccountID)### 记录账户ID
            if self.Order.Holds[key].HoldNum == 0:### 持仓为0 说明已经清仓 待删除该记录
                holds_to_delete.append(key)###记录完后删除 清仓后的持仓信息
        # 统一删除清仓后的持仓信息
        for key in holds_to_delete:  del self.Order.Holds[key] 
        self.DB.SaveHoldData(Holds)### 保存持仓数据
        ### ============================ 保存账户数据 ============================ ###
        ### 去重账户ID列表
        Accs   = []### 账户数据列表
        AccIDs = SetList(AccIDs)
        for AccountID in AccIDs:### 遍历账户ID列表
            Accs.append(copy.deepcopy(self.Acc.Get_Account(None,AccountID).__dict__))### 深度拷贝账户数据
        self.DB.SaveAccData(Accs)### 保存账户数据
        ### ============================ 保存订单数据 ============================ ###
        orders =[]
        # 先收集需要删除的订单ID，避免在迭代时修改字典
        keys_to_delete = []
        for key in self.Order.Orders.keys():
            orders.append(copy.deepcopy(self.Order.Orders[key].__dict__))
            if self.Order.Orders[key].Status > 1:
                keys_to_delete.append(key)
        self.DB.SaveOrderData(orders)### 保存订单数据
        for key in keys_to_delete: self.Order.Order_Del(key) # 统一删除无效的订单
        ### ============================ 数据保存完成 ============================ ###
    def OnBar(self, TradeTime:str,KLsDict:dict[str, dict[str, KLineN]] ,TKs:dict=None):
        # 处理新数据
        pass
    def OnTick(self, tick):
        # 处理新Tick
        pass
    def OrderHelp(self):
        '''订单帮助'''
        return OrderHelp()




 
  