# Copyright (c) Meta Platforms, Inc. and affiliates.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# pyre-strict
"""
Dataset utilities for shadow model training.

This module provides functions for loading datasets and creating shadow datasets
for privacy attack experiments.
"""

from pathlib import Path
from typing import cast, List, Optional, Protocol, Sequence, Tuple, TypeVar, Union

import numpy as np
import torch
from torch.utils.data import Dataset, Subset
from torchvision import transforms
from torchvision.datasets import CIFAR10
from typing_extensions import Sized


class SizedDataset(Protocol):
    """Protocol for datasets that have a __len__ method."""

    def __len__(self) -> int: ...
    def __getitem__(self, index: int) -> object: ...


T: TypeVar = TypeVar("T")
DatasetT: TypeVar = TypeVar("DatasetT", bound=Dataset)


class CustomDataset(Dataset):
    """A general-purpose dataset wrapper for user-provided data.

    Wraps numpy arrays or PyTorch tensors into a PyTorch Dataset that is
    compatible with the PrivacyGuard pipeline (shadow model training,
    membership inference attacks, etc.).

    Args:
        data: Feature data as a numpy array or PyTorch tensor.
              Shape should be (n_samples, ...) where ... represents
              any feature dimensions (e.g., (n, d) for tabular data
              or (n, c, h, w) for images).
        targets: Labels as a numpy array or PyTorch tensor.
                 Shape should be (n_samples,).
        transform: Optional callable applied to each data sample
                   when __getitem__ is called.

    Example:
        >>> import numpy as np
        >>> X = np.random.randn(1000, 10).astype(np.float32)
        >>> y = np.random.randint(0, 3, size=1000)
        >>> dataset = CustomDataset(X, y)
        >>> data, label = dataset[0]
    """

    def __init__(
        self,
        data: Union[np.ndarray, torch.Tensor],
        targets: Union[np.ndarray, torch.Tensor],
        transform: Optional[object] = None,
    ) -> None:
        if isinstance(data, np.ndarray):
            self.data: torch.Tensor = torch.from_numpy(data)
        else:
            self.data = data

        if isinstance(targets, np.ndarray):
            self.targets: torch.Tensor = torch.from_numpy(targets).long()
        else:
            self.targets = targets.long()

        if len(self.data) != len(self.targets):
            raise ValueError(
                f"data and targets must have the same length, "
                f"got {len(self.data)} and {len(self.targets)}"
            )

        if len(self.data) == 0:
            raise ValueError("data must not be empty")

        self.transform = transform

    def __len__(self) -> int:
        return len(self.data)

    def __getitem__(self, index: int) -> Tuple[torch.Tensor, torch.Tensor]:
        sample = self.data[index]
        target = self.targets[index]

        if self.transform is not None and callable(self.transform):
            sample = self.transform(sample)

        return cast(torch.Tensor, sample), target

    @property
    def num_classes(self) -> int:
        """Return the number of unique classes in the dataset."""
        return int(self.targets.unique().numel())

    @property
    def input_shape(self) -> torch.Size:
        """Return the shape of a single data sample (excluding batch dim)."""
        return self.data.shape[1:]


def get_cifar10_transforms() -> Tuple[transforms.Compose, transforms.Compose]:
    """
    Get transforms for CIFAR-10 dataset.

    Returns:
        A tuple containing (train_transform, test_transform)
    """
    train_transform = transforms.Compose(
        [
            transforms.RandomHorizontalFlip(),
            transforms.RandomCrop(32, padding=4),
            transforms.ToTensor(),
            # Normalize using CIFAR-10 mean and std values per RGB channel
            # These are the standard values used in the PyTorch community for CIFAR-10
            transforms.Normalize([0.4914, 0.4822, 0.4465], [0.2470, 0.2435, 0.2616]),
        ]
    )

    test_transform = transforms.Compose(
        [
            transforms.ToTensor(),
            # Normalize using CIFAR-10 mean and std values per RGB channel
            transforms.Normalize([0.4914, 0.4822, 0.4465], [0.2470, 0.2435, 0.2616]),
        ]
    )

    return train_transform, test_transform


def load_cifar10(data_dir: Optional[Path] = None) -> Tuple[CIFAR10, CIFAR10]:
    """
    Load CIFAR-10 dataset.

    Args:
        data_dir: Optional custom directory for dataset storage.
                 Defaults to ~/opt/data/cifar if not specified.

    Returns:
        A tuple containing (train_dataset, test_dataset)
    """
    if data_dir is None:
        data_dir = Path.home() / "opt/data/cifar"

    train_transform, test_transform = get_cifar10_transforms()

    train_dataset = CIFAR10(
        root=data_dir, train=True, download=True, transform=train_transform
    )
    test_dataset = CIFAR10(
        root=data_dir, train=False, download=True, transform=test_transform
    )

    return train_dataset, test_dataset


def create_shadow_datasets(
    train_dataset: Dataset, n_shadows: int = 16, pkeep: float = 0.5, seed: int = 0
) -> Tuple[List[Tuple[Subset, np.ndarray]], Tuple[Subset, np.ndarray]]:
    """
    Create shadow model datasets.

    Args:
        train_dataset: The full training dataset
        n_shadows: Number of shadow models
        pkeep: Fraction of data to keep for each shadow model
        seed: Random seed for reproducibility

    Returns:
        List of (train_subsets, keep) tuples for each shadow model and the target model
    """
    np.random.seed(seed)
    dataset_size = len(cast(Sized, train_dataset))

    # Generate random values for each example and shadow model
    random_values = np.random.uniform(0, 1, size=(n_shadows, dataset_size))

    # Sort values to determine which examples are kept for each shadow model
    sorted_indices = random_values.argsort(axis=0)

    # Create a boolean mask for each shadow model
    keep_mask = sorted_indices < int(pkeep * n_shadows)

    shadow_datasets = []
    for shadow_index in range(n_shadows):
        # Get indices for examples included in this shadow model
        included_indices = np.where(keep_mask[shadow_index])[0]

        # Create subsets for in examples (members)
        shadow_subset = Subset(train_dataset, list(included_indices))

        shadow_datasets.append((shadow_subset, keep_mask[shadow_index]))

    return shadow_datasets[:-1], shadow_datasets[-1]


def create_rmia_datasets(
    train_dataset: Dataset,
    test_dataset: Dataset,
    num_references: int,
    population_size: int = 10000,
) -> Tuple[
    List[Tuple[Subset, np.ndarray]],
    Tuple[Subset, np.ndarray],
    Subset,
]:
    """
    Creates reference datasets, target dataset, and population dataset for RMIA.

    Args:
        train_dataset: The training dataset
        test_dataset: The test dataset
        num_references: Number of reference models to create
        population_size: Size of the population dataset

    Returns:
        Tuple containing:
        - reference_datasets: List of tuples with reference datasets and their labels
        - target_dataset: Tuple with target dataset and its labels
        - population_dataset: Dataset used for population estimation
    """

    assert num_references >= 3, (
        "Number of references must be at least 3 (2 shadows + 1 target)"
    )
    # Create reference datasets and target dataset
    reference_datasets: List[Tuple[Subset, np.ndarray]]
    target_dataset: Tuple[Subset, np.ndarray]
    reference_datasets, target_dataset = create_shadow_datasets(
        train_dataset, n_shadows=num_references
    )

    # Create population dataset (using test data as population for this example)
    # In practice, this should be a separate dataset not used for training or testing
    population_indices: Sequence[int] = np.random.choice(
        len(cast(Sized, test_dataset)), population_size, replace=False
    ).tolist()
    population_dataset: Subset = Subset(test_dataset, population_indices)

    # Print dataset sizes
    for i, (ref_in, _) in enumerate(reference_datasets):
        print(f"Reference {i}: {len(ref_in)} in-samples")

    print(f"Target: {len(target_dataset[0])} in-samples")
    print(f"Population: {len(population_dataset)} samples")

    return reference_datasets, target_dataset, population_dataset
