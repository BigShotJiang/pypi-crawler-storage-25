# Copyright (c) Meta Platforms, Inc. and affiliates.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# pyre-strict
import difflib
import string
from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Callable, cast, Dict, List, Optional, Tuple

import pandas as pd
import textdistance
from privacy_guard.analysis.base_analysis_node import BaseAnalysisNode
from privacy_guard.analysis.base_analysis_output import BaseAnalysisOutput
from privacy_guard.analysis.extraction.text_inclusion_analysis_input import (
    LCSBoundConfig,
    TextInclusionAnalysisInput,
)
from tqdm import tqdm

tqdm.pandas()


@dataclass
class TextInclusionAnalysisNodeOutput(BaseAnalysisOutput):
    """A dataclass to encapsulate the outputs of TextInclusionAnalysisNode."""

    # TODO separate TextInclusionAnalysisNode into multiple analysis classes.

    num_samples: int
    exact_match: pd.Series
    inclusion_score: pd.Series
    longest_common_substring: Optional[pd.Series]
    longest_common_substring_false_pos: Optional[pd.Series]
    decision_targets_lcs: Optional[pd.Series]
    decision_targets_lcs_len: Optional[pd.Series]
    edit_similarity: Optional[pd.Series]
    edit_similarity_score: Optional[pd.Series]
    filtered_true_positive_list: list[str] | None
    augmented_output_dataset: pd.DataFrame
    char_level_longest_common_subsequence: Optional[pd.Series]
    word_level_longest_common_subsequence: Optional[pd.Series]

    analysis_input: TextInclusionAnalysisInput | None = (
        None  # Include for future reference
    )

    def format_single_word_level_lcs_result(
        self,
        num_matched_words: int,
        matched_string: str,
        augmented_row: Dict[str, Any],
        analysis_input: TextInclusionAnalysisInput,
    ) -> Dict[str, Any]:
        prompt = augmented_row[analysis_input.prompt_key]
        prediction = augmented_row[analysis_input.generation_key]

        target = augmented_row[analysis_input.target_key]
        # The method here should set remove_consecutive_whitespace based on analysis input
        clean_target_len = len(_clean_text_remove_consecutive_whitespace(text=target))

        matched_string_char_length = len(matched_string)
        word_level_lcs_result_dict = {
            "Count of matched words": num_matched_words,
            "Length of matched words": matched_string_char_length,
            "Matched consecutive sequence": matched_string,
            "% target extracted": "N/A"
            if clean_target_len == 0
            else 100 * matched_string_char_length / clean_target_len,
            analysis_input.prompt_key: prompt,
            analysis_input.target_key: target,
            analysis_input.generation_key: prediction,
        }

        return word_level_lcs_result_dict

    def word_level_lcs_result_formatted(self) -> pd.DataFrame:
        """Returns a interpretble dataframe of the word level results."""
        if self.word_level_longest_common_subsequence is None:
            raise ValueError("No lcs results to display.")
        if self.analysis_input is None:
            raise ValueError("No analysis input, can't id keys for formatting")

        word_level_longest_common_subsequence_list = list(
            self.word_level_longest_common_subsequence
        )

        displays: List[Dict[str, Any]] = []

        for word_level_tuple, augmented_row in zip(
            word_level_longest_common_subsequence_list,
            self.augmented_output_dataset.T.to_dict().values(),
        ):
            num_matched_words = word_level_tuple[0]
            matched_string = word_level_tuple[1]
            displays.append(
                self.format_single_word_level_lcs_result(
                    num_matched_words=num_matched_words,
                    matched_string=matched_string,
                    augmented_row=augmented_row,
                    analysis_input=self.analysis_input,  # pyre-ignore
                )
            )

        return pd.DataFrame(displays)

    def format_single_lcs_result(
        self,
        lcs_dict: Dict[str, Any],
        augmented_row: Dict[str, Any],
        display_lcs_match: bool,
        analysis_input: TextInclusionAnalysisInput,
    ) -> Dict[str, Any]:
        lcs_target = list(lcs_dict.keys())[0]

        prompt = augmented_row[analysis_input.prompt_key]
        prediction = augmented_row[analysis_input.generation_key]

        target = augmented_row[analysis_input.target_key]

        lcs_result_dict = {
            "lcs": lcs_dict[lcs_target],
            "% target extracted": "N/A"
            if len(lcs_target) == 0
            else 100 * lcs_dict[lcs_target] / len(lcs_target),
            analysis_input.prompt_key: prompt,
            analysis_input.generation_key: prediction,
            analysis_input.target_key: target,
        }

        if display_lcs_match:
            _, matched_text = _char_level_longest_common_substring_with_matched_text(
                _clean_text(text=target), _clean_text(text=prediction)
            )
            lcs_result_dict["lcs_match"] = matched_text
        return lcs_result_dict

    def lcs_result_formatted(self, display_lcs_match: bool) -> pd.DataFrame:
        """Returns a interpretble dataframe of the lcs results.
        display_lcs_match: whether to display the matched text in the lcs result. Recomputes
            on the fly
        """
        if self.longest_common_substring is None:
            raise ValueError("No lcs results to display.")
        if self.analysis_input is None:
            raise ValueError("No analysis input, can't id keys for formatting")

        longest_common_substring_list = list(self.longest_common_substring)

        displays: List[Dict[str, Any]] = []

        for lcs_dict, augmented_row in zip(
            longest_common_substring_list,
            self.augmented_output_dataset.T.to_dict().values(),
        ):
            displays.append(
                self.format_single_lcs_result(
                    lcs_dict=lcs_dict,
                    augmented_row=augmented_row,
                    display_lcs_match=display_lcs_match,
                    analysis_input=self.analysis_input,  # pyre-ignore
                )
            )

        return pd.DataFrame(displays)


def _clean_text(text: str) -> str:
    """Normalizes text.

    - Lowercases
    - Removes punctuation
    - Turn newlines and tabs into spaces
    - Strips leading and trailing whitespace
    """
    # Lowercase
    text = text.lower()

    # Remove punctuation
    punctuation_remover = str.maketrans("", "", string.punctuation)
    cleaned_text = text.translate(punctuation_remover)

    # Turn newlines and tabs into spaces
    space_translator = str.maketrans("\n\t\r", "   ")
    cleaned_text = cleaned_text.translate(space_translator)

    # Strip leading and trailing whitespace
    cleaned_text = cleaned_text.strip()
    return cleaned_text


def _clean_text_remove_consecutive_whitespace(text: str) -> str:
    """Normalizes text.

    - Lowercases
    - Removes punctuation
    - Turn newlines and tabs into spaces
    - Strips leading and trailing whitespace
    - Removes consecutive whitespace
    """
    cleaned_text = _clean_text(text=text)
    cleaned_text = " ".join(cleaned_text.split())
    return cleaned_text


def _word_level_longest_common_subsequence_helper(
    s1: str, s2: str, autojunk: bool = True
) -> Tuple[int, str]:
    """
    Implementation of the longest common subsequence at word level.

    Output: number of words contained in the longest common subsequence.
    """

    # Split the string to words
    s1_list = s1.split()
    s2_list = s2.split()

    # Find matching blocks
    matcher = difflib.SequenceMatcher(None, s1_list, s2_list, autojunk=autojunk)
    matching_blocks = matcher.get_matching_blocks()

    # Initialize the length of matched words count
    matched_words_count = 0
    matched_words = []
    for block in matching_blocks:
        if block.size > 0:
            matched_words_count += block.size
            matched_words.extend(s1_list[block.a : block.a + block.size])
    reconstructed_match = " ".join(matched_words)
    return (matched_words_count, reconstructed_match)


def _char_level_longest_common_subsequence_helper(
    s1: str, s2: str, autojunk: bool = True
) -> int:
    """
    Implementation of the longest common subsequence at character level.

    Output: number of characters contained in the longest common subsequence.
    """

    # Find matching blocks
    matcher = difflib.SequenceMatcher(None, s1, s2, autojunk=autojunk)
    matching_blocks = matcher.get_matching_blocks()

    # Initialize the length of matched chars count
    matched_chars_count = 0
    for block in matching_blocks:
        if block.size > 0:
            matched_chars_count += block.size
    return matched_chars_count


def _char_level_longest_common_substring_helper_bound(
    s1: str, s2: str, target: int = 150
) -> int:
    """
    To save on computation, check existance of a common substring of length target.
    Different from longest common subsequence (commonly known as LCS), longest common substring is the longest common CONSECUTIVE subsequence. Please use with caution.
    """

    max_length = 0
    # Iterate over the characters in the first string
    for i in range(len(s1)):
        j = target

        substring = s1[i : i + j]

        # Check if the current substring is in the second string and is longer
        # than the previous longest substring
        if substring in s2 and len(substring) > max_length:
            # Update the longest substring and its length
            max_length = len(substring)

            if max_length >= target:
                return max_length

    return 0


def _char_level_longest_common_substring_with_matched_text(
    s1: str, s2: str
) -> Tuple[int, str]:
    """
    Implementation of the longest common substring at character level.
    Different from longest common subsequence (commonly known as LCS), longest common substring is the longest common CONSECUTIVE subsequence. Please use with caution.
    """

    # Initialize variables to store the longest common substring and its length

    max_length = 0
    max_substring = ""
    # Iterate over the characters in the first string
    for i in range(len(s1)):
        # Iterate over the possible lengths of substrings
        for j in range(i + 1, len(s1) + 1):
            # Extract the current substring
            substring = s1[i:j]
            # Check if the current substring is in the second string and is longer
            # than the previous longest substring
            if substring in s2 and len(substring) > max_length:
                # Update the longest substring and its length
                max_length = len(substring)
                max_substring = substring

    return max_length, max_substring


def _char_level_longest_common_substring_helper(s1: str, s2: str) -> int:
    max_length, _ = _char_level_longest_common_substring_with_matched_text(s1, s2)

    return max_length


def _normalize_by_target_len(
    scores: pd.Series,
    targets: pd.Series,
    clean_text_method: Callable[[str], str] = _clean_text,
) -> pd.Series:
    """Normalized similarity metrics by target length."""
    lengths = targets.progress_apply(lambda x: len(clean_text_method(x)))
    return scores / lengths


class TextInclusionAnalysisNode(BaseAnalysisNode):
    """TextInclusionAnalysisNode class for PrivacyGuard.

    Takes in a single dataframe containing prompt, target, and generation columns, and computes different inclusion scores
    such as "exact_match", "longest_common_substring".

    Additionally supports filtering true positives, in situations
    where the target is errantly included in the prompt text.

    NOTE: exact match and similarity are currently supported for single target only.

    Args:
        text_inclusion_analysis_input: AnalysisInputObject containing the
            prompt, target, and output_text columns.
    """

    LCS_METRIC_KEYS = [
        "lcs",
        "lcs_score",
        "fp",
        "fp_score",
        "decision_targets_lcs",
        "decision_targets_lcs_len",
    ]

    def __init__(self, analysis_input: TextInclusionAnalysisInput) -> None:
        """
        args:
            user_aggregation: specifies user aggregation strategy
        """
        self.prompt_key: str = analysis_input.prompt_key
        self.generation_key: str = analysis_input.generation_key

        self.target_key: str = analysis_input.target_key
        self.target_set_key: str = self.target_key + "_set"
        self.generation_df: pd.DataFrame = analysis_input.generation_df

        self.generation_df[self.target_set_key] = self.generation_df[
            self.target_key
        ].apply(lambda x: {x} if isinstance(x, str) else set(x))

        self.generation_df["num_unique_targets"] = self.generation_df[
            self.target_set_key
        ].apply(lambda x: len(x))

        self.clean_text_method = (
            _clean_text
            if not analysis_input.remove_consecutive_whitespace
            else _clean_text_remove_consecutive_whitespace
        )

        super().__init__(analysis_input=analysis_input)

    def _compute_word_level_longest_common_subsequence_helper(
        self, row: pd.Series, s1_column: str | None = None, s2_column: str | None = None
    ) -> Tuple[int, str]:
        """Compute char level longest common subsequence between target and generation text.
        Text are cleaned first.

        Returns:
            int: Number of shared words between the two strings.
        """
        s1 = self.clean_text_method(row[s1_column or self.target_key])
        s2 = self.clean_text_method(row[s2_column or self.generation_key])
        return _word_level_longest_common_subsequence_helper(s1, s2)

    def _compute_char_level_longest_common_subsequence_helper(
        self, row: pd.Series, s1_column: str | None = None, s2_column: str | None = None
    ) -> int:
        """Compute word level longest common subsequence between target and generation text.
        Text are cleaned first.

        Returns:
            int: Number of shared words between the two strings.
        """
        s1 = self.clean_text_method(row[s1_column or self.target_key])
        s2 = self.clean_text_method(row[s2_column or self.generation_key])
        return _char_level_longest_common_subsequence_helper(s1, s2)

    def _compute_edit_similarity(
        self, row: pd.Series, s1_column: str | None = None, s2_column: str | None = None
    ) -> int:
        """Compute edit similarity between target and generation text. Texts are cleaned first.
        Currently not supported for multi target mode.

        Args:
            row (pd.Series): A row of a DataFrame containing the s1 and s2 columns.

        Returns:
            int: Edit similarity between the two strings.
        """
        s1 = self.clean_text_method(row[s1_column or self.target_key])
        s2 = self.clean_text_method(row[s2_column or self.generation_key])
        levenshtein = textdistance.levenshtein.similarity(s1, s2)
        return levenshtein

    def _compute_exact_match(self, row: pd.Series) -> bool:
        """Returns true if ANY target is exactly the same as the output_text.

        Texts are NOT cleaned first except for stripping leading and trailing whitespace.

        Args:
            row (pd.Series): A row of a DataFrame containing the self.target_key and self.generation_key columns.

        Returns:
            bool: True if the target is exactly the same as the output_text, False otherwise.
        """
        return row[self.target_key].strip() == row[self.generation_key].strip()

    def _compute_inclusion_score(self, row: pd.Series) -> bool:
        """Returns true if the target is included in the output_text. Texts are cleaned first.

        Args:
            row (pd.Series): A row of a DataFrame containing the self.target_key and self.generation_key columns.

        Returns:
            bool: True if the target is included in the output_text, False otherwise.
        """
        s1 = self.clean_text_method(row[self.target_key])
        s2 = self.clean_text_method(row[self.generation_key])
        return s1 in s2

    def get_compute_longest_common_substring_map(
        self,
        comparison_key: str = "output_text",
        false_positive_key: str = "prompt",
        lcs_bound_config: LCSBoundConfig | None = None,
    ) -> Callable[
        [pd.Series],
        Dict[str, Dict[str, List[float] | List[int] | List[Tuple[float, float]]]],
    ]:
        """Produces the lcs function for a target against the comparison column, and the
        false positive column.

        Args:
            comparison_key (str): The key for the value to compare against the target(s)
            false_positive_key (str): The key for the value to check against false positive
            lcs_bound_config LCSBoundConfig | None: whether to bound LCS computation
                for computational efficiency. If none, LCS is not bounded.

        Returns:
            Callable method to produce Dict containing:
                lcs (Dict[str, int]): Dict mapping from target to longest common substring
                lcs_score (Dict[str, float]): Dict mapping from target to longest_common_substring scores
                fp (Dict[str, int]): Dict mapping from target to lcs w/ prompt
                fp_score (Dict[str, float]): Dict mapping from target to false positive lcs scores
                decision_targets_lcs (Dict[str, float]): Dict mapping from target to (lcs, fp) scores
                decision_targets_lcs_len (Dict[str, float]): Dict mapping from target to (lcs, fp)
        """

        def _compute_longest_common_substring_map(
            row: pd.Series,
        ) -> Dict[str, Dict[str, List[float] | List[int] | List[Tuple[float, float]]]]:
            """Find the longest common substring between two strings. Texts are cleaned first.

            Args:
                row (pd.Series): A row of a DataFrame containing the prompt, target, and generation columns.

            Returns Dict containing:
                lcs (Dict[str, float]): Dict mapping from target to longest common substring
                lcs_score (Dict[str, float]): Dict mapping from target to longest_common_substring scores
                fp (Dict[str, float]): Dict mapping from target to lcs w/ prompt
                fp_score (Dict[str, float]): Dict mapping from target to false positive lcs scores
                decision_targets_lcs (Dict[str, float]): Dict mapping from target to (lcs, fp)
                decision_targets_lcs_len (Dict[str, float]): Dict mapping from target to (lcs, fp)
            """
            output_dict = defaultdict(dict)

            target_set = row[self.target_set_key]

            comparison_text = self.clean_text_method(row[comparison_key])
            fp_text = self.clean_text_method(row[false_positive_key])

            for target in target_set:
                clean_target = self.clean_text_method(target)

                if lcs_bound_config is not None:
                    lcs = _char_level_longest_common_substring_helper_bound(
                        s1=clean_target,
                        s2=comparison_text,
                        target=lcs_bound_config.lcs_len_target,
                    )
                else:
                    lcs = _char_level_longest_common_substring_helper(
                        s1=clean_target, s2=comparison_text
                    )
                output_dict["lcs"][clean_target] = lcs
                lcs_score = -1 if len(clean_target) <= 0 else lcs / len(clean_target)
                output_dict["lcs_score"][clean_target] = lcs_score

                if lcs_bound_config is not None:
                    fp = _char_level_longest_common_substring_helper_bound(
                        s1=clean_target,
                        s2=fp_text,
                        target=lcs_bound_config.fp_len_target,
                    )
                else:
                    fp = _char_level_longest_common_substring_helper(
                        s1=clean_target, s2=fp_text
                    )
                output_dict["fp"][clean_target] = fp

                fp_score = -1 if len(clean_target) <= 0 else fp / len(clean_target)
                output_dict["fp_score"][clean_target] = fp_score

                output_dict["decision_targets_lcs"][clean_target] = (
                    lcs_score,
                    fp_score,
                )
                output_dict["decision_targets_lcs_len"][clean_target] = (
                    lcs,
                    fp,
                )

            return dict(output_dict)

        return _compute_longest_common_substring_map

    def run_analysis(self) -> TextInclusionAnalysisNodeOutput:
        analysis_input: TextInclusionAnalysisInput = cast(
            TextInclusionAnalysisInput, self.analysis_input
        )
        generation_df = analysis_input.generation_df

        # Exact match
        if not analysis_input.disable_exact_match:
            exact_match = generation_df.progress_apply(
                self._compute_exact_match, axis=1
            )
            # Inclusion score
            inclusion_score = generation_df.progress_apply(
                self._compute_inclusion_score, axis=1
            )
        else:
            exact_match = pd.Series()
            inclusion_score = pd.Series()

        outputs = TextInclusionAnalysisNodeOutput(
            num_samples=len(generation_df),
            exact_match=exact_match,
            inclusion_score=inclusion_score,
            longest_common_substring=None,
            longest_common_substring_false_pos=None,
            decision_targets_lcs=None,
            decision_targets_lcs_len=None,
            edit_similarity=None,
            edit_similarity_score=None,
            filtered_true_positive_list=None,
            augmented_output_dataset=generation_df,
            word_level_longest_common_subsequence=None,
            char_level_longest_common_subsequence=None,
            analysis_input=analysis_input,
        )

        if not analysis_input.disable_longest_common_substring:
            # Longest common substring

            lcs_result = generation_df.progress_apply(
                self.get_compute_longest_common_substring_map(
                    comparison_key=analysis_input.generation_key,
                    false_positive_key=analysis_input.prompt_key,
                    lcs_bound_config=analysis_input.lcs_bound_config,
                ),
                axis=1,
            )

            for lcs_metric_key in self.LCS_METRIC_KEYS:
                generation_df[lcs_metric_key] = lcs_result.progress_apply(
                    lambda lcs_result, metric_key=lcs_metric_key: lcs_result[metric_key]
                )

            outputs.decision_targets_lcs = generation_df["decision_targets_lcs"]
            outputs.decision_targets_lcs_len = generation_df["decision_targets_lcs_len"]
            outputs.longest_common_substring = generation_df["lcs"]
            outputs.longest_common_substring_false_pos = generation_df["fp"]

        if not analysis_input.disable_similarity:
            # Edit similarity
            generation_df["edit_similarity"] = generation_df.progress_apply(
                self._compute_edit_similarity, axis=1
            )
            generation_df["edit_similarity_score"] = _normalize_by_target_len(
                generation_df["edit_similarity"],
                generation_df["target"],
                self.clean_text_method,
            )

            outputs.edit_similarity = generation_df["edit_similarity"]
            outputs.edit_similarity_score = generation_df["edit_similarity_score"]

        if not analysis_input.disable_word_level_longest_common_subsequence:
            generation_df["word_level_longest_common_subsequence"] = (
                generation_df.progress_apply(
                    self._compute_word_level_longest_common_subsequence_helper, axis=1
                )
            )

            outputs.word_level_longest_common_subsequence = generation_df[
                "word_level_longest_common_subsequence"
            ]

        if not analysis_input.disable_char_level_longest_common_subsequence:
            generation_df["char_level_longest_common_subsequence"] = (
                generation_df.progress_apply(
                    self._compute_char_level_longest_common_subsequence_helper, axis=1
                )
            )

            outputs.char_level_longest_common_subsequence = generation_df[
                "char_level_longest_common_subsequence"
            ]

        return outputs
