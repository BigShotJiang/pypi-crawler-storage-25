"""
tests/test_analysis.py
======================
Unit tests for process capability and tolerance stack-up modules.
"""

import pytest
from tolerix.analysis import process_capability, tolerance_stackup
from tolerix.analysis.capability import CapabilityResult
from tolerix.analysis.stackup import StackupResult


# ── Process Capability Tests ──────────────────────────────

class TestProcessCapability:

    def test_returns_capability_result(self):
        result = process_capability(
            nominal=25.0, tolerance=0.05, seed=42
        )
        assert isinstance(result, CapabilityResult)

    def test_cp_formula(self):
        """Cp = (USL - LSL) / 6σ = (2 * tolerance) / (6 * tolerance/3) = 1.0"""
        result = process_capability(
            nominal=25.0, tolerance=0.05, seed=42
        )
        assert result.cp == pytest.approx(1.0, abs=0.001)

    def test_cpk_equals_cp_when_centered(self):
        """When process mean == nominal, Cpk should equal Cp."""
        result = process_capability(
            nominal=25.0,
            tolerance=0.05,
            process_mean=25.0,
            seed=42
        )
        assert result.cpk == pytest.approx(result.cp, abs=0.001)

    def test_cpk_lower_when_off_center(self):
        """Cpk must be lower than Cp when process is off-center."""
        result = process_capability(
            nominal=25.0,
            tolerance=0.05,
            process_mean=25.03,
            seed=42
        )
        assert result.cpk < result.cp

    def test_excellent_rating(self):
        result = process_capability(
            nominal=25.0,
            tolerance=0.10,
            process_std=0.01,
            seed=42
        )
        assert result.rating == "EXCELLENT"

    def test_failing_rating(self):
        result = process_capability(
            nominal=25.0,
            tolerance=0.01,
            process_std=0.02,
            seed=42
        )
        assert result.rating == "FAILING"

    def test_within_spec_near_100_when_capable(self):
        result = process_capability(
            nominal=25.0,
            tolerance=0.10,
            process_std=0.01,
            seed=42
        )
        assert result.within_spec_pct > 99.9

    def test_usl_lsl_correct(self):
        result = process_capability(
            nominal=25.0, tolerance=0.05, seed=42
        )
        assert result.usl == pytest.approx(25.05)
        assert result.lsl == pytest.approx(24.95)

    def test_summary_is_string(self):
        result = process_capability(
            nominal=25.0, tolerance=0.05, seed=42
        )
        assert isinstance(result.summary(), str)
        assert "Cp" in result.summary()
        assert "Cpk" in result.summary()


# ── Tolerance Stack-Up Tests ──────────────────────────────

class TestToleranceStackup:

    def test_returns_stackup_result(self):
        result = tolerance_stackup([
            (50.0, 0.05, "A"),
            (30.0, 0.03, "B"),
        ])
        assert isinstance(result, StackupResult)

    def test_mean_gap_is_sum_of_nominals(self):
        result = tolerance_stackup([
            (50.0, 0.05, "A"),
            (30.0, 0.03, "B"),
            (20.0, 0.02, "C"),
        ])
        assert result.mean_gap == pytest.approx(100.0)

    def test_worst_case_max(self):
        result = tolerance_stackup([
            (50.0, 0.05, "A"),
            (30.0, 0.03, "B"),
        ])
        # max = (50+30) + (0.05+0.03) = 80.08
        assert result.worst_case_max == pytest.approx(80.08)

    def test_worst_case_min(self):
        result = tolerance_stackup([
            (50.0, 0.05, "A"),
            (30.0, 0.03, "B"),
        ])
        # min = 80 - 0.08 = 79.92
        assert result.worst_case_min == pytest.approx(79.92)

    def test_rss_tolerance(self):
        """RSS = sqrt(0.05² + 0.03²) = sqrt(0.0034) ≈ 0.05831"""
        result = tolerance_stackup([
            (50.0, 0.05, "A"),
            (30.0, 0.03, "B"),
        ])
        import numpy as np
        expected = float(np.sqrt(0.05**2 + 0.03**2))
        assert result.rss_tolerance == pytest.approx(expected, abs=0.0001)

    def test_fewer_than_2_raises(self):
        with pytest.raises(ValueError, match="at least 2"):
            tolerance_stackup([(50.0, 0.05, "A")])

    def test_risk_level_valid(self):
        result = tolerance_stackup([
            (50.0, 0.05, "A"),
            (30.0, 0.03, "B"),
        ])
        assert result.risk_level in ("LOW", "MEDIUM", "HIGH")

    def test_summary_is_string(self):
        result = tolerance_stackup([
            (50.0, 0.05, "A"),
            (30.0, 0.03, "B"),
        ])
        s = result.summary()
        assert isinstance(s, str)
        assert "RSS" in s
        assert "Worst Case" in s


# ── PDF Report Tests ──────────────────────────────────────

class TestPDFReport:

    def test_pdf_generates(self, tmp_path):
        from tolerix import monte_carlo_fit
        from tolerix.intelligence import generate_pdf_report

        fit = monte_carlo_fit(
            shaft=(20.00, 0.02),
            hole=(20.05, 0.01),
            samples=10_000,
            seed=42,
        )
        path = generate_pdf_report(
            output_path=str(tmp_path / "test_report.pdf"),
            fit_result=fit,
            project_name="Test Project",
            engineer="Test Engineer",
        )
        import os
        assert os.path.exists(path)
        assert path.endswith(".pdf")
        assert os.path.getsize(path) > 10_000

    def test_pdf_requires_at_least_one_result(self, tmp_path):
        from tolerix.intelligence import generate_pdf_report
        with pytest.raises(ValueError, match="At least one"):
            generate_pdf_report(
                output_path=str(tmp_path / "empty.pdf")
            )