"""
tests/test_simulation.py
========================
Unit tests for the Tolerix Monte Carlo simulation engine.
Tests cover correctness, edge cases, and engineering logic.
"""

import pytest
from tolerix import monte_carlo_fit, Dimension, FitResult


# ── Dimension Tests ───────────────────────────────────────

class TestDimension:
    """Tests for the core Dimension data model."""

    def test_basic_creation(self):
        d = Dimension(nominal=20.0, tolerance=0.02)
        assert d.nominal == 20.0
        assert d.tolerance == 0.02

    def test_upper_lower_limits(self):
        d = Dimension(nominal=20.0, tolerance=0.02)
        assert d.upper == pytest.approx(20.02)
        assert d.lower == pytest.approx(19.98)

    def test_total_band(self):
        d = Dimension(nominal=20.0, tolerance=0.02)
        assert d.total_band == pytest.approx(0.04)

    def test_negative_tolerance_raises(self):
        with pytest.raises(ValueError, match="non-negative"):
            Dimension(nominal=20.0, tolerance=-0.01)

    def test_zero_nominal_raises(self):
        with pytest.raises(ValueError, match="positive"):
            Dimension(nominal=0.0, tolerance=0.01)

    def test_name_label(self):
        d = Dimension(nominal=10.0, tolerance=0.01, name="shaft")
        assert d.name == "shaft"
        assert "shaft" in repr(d)

    def test_repr_contains_key_info(self):
        d = Dimension(nominal=20.0, tolerance=0.02)
        r = repr(d)
        assert "20.0000" in r
        assert "0.0200" in r


# ── Monte Carlo Simulation Tests ──────────────────────────

class TestMonteCarloFit:
    """Tests for the monte_carlo_fit simulation engine."""

    def test_returns_fit_result(self):
        result = monte_carlo_fit(
            shaft=(20.00, 0.02),
            hole=(20.05, 0.01),
            samples=10_000
        )
        assert isinstance(result, FitResult)

    def test_probabilities_sum_to_one(self):
        result = monte_carlo_fit(
            shaft=(20.00, 0.02),
            hole=(20.05, 0.01),
            samples=10_000,
            seed=42
        )
        total = result.clearance_probability + result.interference_probability
        assert total == pytest.approx(1.0, abs=1e-9)

    def test_clearance_fit_detected(self):
        """Hole clearly larger than shaft — should be clearance fit."""
        result = monte_carlo_fit(
            shaft=(18.00, 0.01),
            hole=(20.00, 0.01),
            samples=10_000,
            seed=42
        )
        assert result.clearance_probability > 0.99
        assert result.fit_type == "CLEARANCE FIT"

    def test_interference_fit_detected(self):
        """Shaft clearly larger than hole — should be interference fit."""
        result = monte_carlo_fit(
            shaft=(20.00, 0.01),
            hole=(19.00, 0.01),
            samples=10_000,
            seed=42
        )
        assert result.interference_probability > 0.99
        assert result.fit_type == "INTERFERENCE FIT"

    def test_mean_clearance_is_correct(self):
        """Mean clearance should be close to hole_nominal - shaft_nominal."""
        result = monte_carlo_fit(
            shaft=(20.00, 0.02),
            hole=(20.05, 0.01),
            samples=100_000,
            seed=42
        )
        expected_mean = 20.05 - 20.00  # = 0.05 mm
        assert result.mean_clearance == pytest.approx(expected_mean, abs=0.005)

    def test_seed_gives_reproducible_results(self):
        """Same seed must always give identical results."""
        r1 = monte_carlo_fit(shaft=(20.00, 0.02), hole=(20.05, 0.01),
                             samples=10_000, seed=99)
        r2 = monte_carlo_fit(shaft=(20.00, 0.02), hole=(20.05, 0.01),
                             samples=10_000, seed=99)
        assert r1.mean_clearance == r2.mean_clearance
        assert r1.clearance_probability == r2.clearance_probability

    def test_risk_level_is_valid(self):
        result = monte_carlo_fit(
            shaft=(20.00, 0.02),
            hole=(20.05, 0.01),
            samples=10_000,
            seed=42
        )
        assert result.risk_level in ("LOW", "MEDIUM", "HIGH")

    def test_high_risk_interference(self):
        """Shaft larger than hole should trigger HIGH risk."""
        result = monte_carlo_fit(
            shaft=(20.10, 0.01),
            hole=(20.00, 0.01),
            samples=10_000,
            seed=42
        )
        assert result.risk_level == "HIGH"

    def test_samples_too_low_raises(self):
        with pytest.raises(ValueError, match="1000"):
            monte_carlo_fit(
                shaft=(20.00, 0.02),
                hole=(20.05, 0.01),
                samples=500
            )

    def test_summary_is_string(self):
        result = monte_carlo_fit(
            shaft=(20.00, 0.02),
            hole=(20.05, 0.01),
            samples=10_000,
            seed=42
        )
        summary = result.summary()
        assert isinstance(summary, str)
        assert "TOLERIX" in summary
        assert "Risk Level" in summary

    def test_warnings_list_exists(self):
        result = monte_carlo_fit(
            shaft=(20.00, 0.02),
            hole=(20.05, 0.01),
            samples=10_000,
            seed=42
        )
        assert isinstance(result.warnings, list)

    def test_shaft_name_appears_in_summary(self):
        result = monte_carlo_fit(
            shaft=(20.00, 0.02),
            hole=(20.05, 0.01),
            samples=10_000,
            shaft_name="MainShaft",
            hole_name="BearingHole",
            seed=42
        )
        summary = result.summary()
        assert "MainShaft" in summary
        assert "BearingHole" in summary