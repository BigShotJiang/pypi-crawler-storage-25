# tolerix 🔧

**Professional Engineering Analytics & Simulation Toolkit**

Tolerix is a Python library for tolerance analysis, Monte Carlo simulation,
and manufacturing variation analysis. It combines calculation, simulation,
visualization, and intelligent engineering interpretation into one clean API.

---
## Features

- Shaft-hole fit analysis (clearance / interference / transition)
- Monte Carlo tolerance simulation (up to 1M+ samples)
- Probability of assembly failure
- Engineering risk classification (LOW / MEDIUM / HIGH)
- Intelligent warnings and recommendations
- Professional dark-themed visualization
- Clean, type-hinted, documented API

---

## Installation

    pip install tolerix


---

## Quick Start

    from tolerix import monte_carlo_fit
    from tolerix.visualization import plot_fit_distribution

    result = monte_carlo_fit(
        shaft=(20.00, 0.02),
        hole=(20.05, 0.01),
        samples=100_000,
        shaft_name="Motor Shaft",
        hole_name="Bearing Bore",
    )

    print(result.summary())
    plot_fit_distribution(result)

---

## Output

    ────────────────────────────────────────────────
      TOLERIX — Fit Analysis Report
    ────────────────────────────────────────────────
      Shaft       : Dimension('Motor Shaft' 20.0000 ± 0.0200 mm [19.9800 – 20.0200])
      Hole        : Dimension('Bearing Bore' 20.0500 ± 0.0100 mm [20.0400 – 20.0600])
    ────────────────────────────────────────────────
      Fit Type    : CLEARANCE FIT
      Clearance   : 100.0%
      Interference: 0.0%
      Mean Gap    : 0.0500 mm
      Std Dev     : 0.0075 mm
      Samples     : 100,000
    ────────────────────────────────────────────────
      Risk Level  : LOW
      Insight     : Tolerance range is stable for standard CNC manufacturing.
    ────────────────────────────────────────────────

---

## Real-World Scenarios

| Scenario | Fit Type | Risk | Clearance |
|---|---|---|---|
| Bearing Assembly | CLEARANCE FIT | LOW | 100.0% |
| Gearbox Shaft | TRANSITION FIT | MEDIUM | 95.2% |
| Press Fit Pin | INTERFERENCE FIT | HIGH | 0.0% |

---

## API Reference

### monte_carlo_fit

Runs a Monte Carlo simulation of shaft-hole fit variation.

| Parameter | Type | Description |
|---|---|---|
| shaft | tuple[float, float] | (nominal, tolerance) in mm |
| hole | tuple[float, float] | (nominal, tolerance) in mm |
| samples | int | Number of simulation samples (default 100,000) |
| shaft_name | str | Optional label for shaft |
| hole_name | str | Optional label for hole |
| seed | int or None | Random seed for reproducibility |

Returns a `FitResult` object.

---

### FitResult.summary()

Returns a formatted multi-line engineering report string.

---

### plot_fit_distribution

Generates a professional histogram of the clearance distribution.

| Parameter | Type | Description |
|---|---|---|
| result | FitResult | Output from monte_carlo_fit() |
| bins | int | Histogram bins (default 80) |
| show | bool | Display plot window (default True) |
| save_path | str or None | Save figure to file path |

---
## License

MIT License — see LICENSE file for details.

---

## Author

Built with precision by Subiksha Thiyagarajan.
Designed for real engineering, not toy examples.