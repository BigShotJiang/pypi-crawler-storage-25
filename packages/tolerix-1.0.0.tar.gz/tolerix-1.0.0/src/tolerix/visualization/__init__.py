"""
tolerix.visualization
=====================
Engineering visualization for tolerance and fit analysis.
Generates professional histogram plots of clearance distributions.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from tolerix.core import FitResult


def plot_fit_distribution(
    result: FitResult,
    bins: int = 80,
    show: bool = True,
    save_path: str | None = None,
    figsize: tuple[float, float] = (10, 6),
) -> plt.Figure:
    """
    Plots a professional histogram of the clearance distribution
    from a Monte Carlo fit simulation.

    The plot shows:
    - Clearance zone (green bars) — safe assembly region
    - Interference zone (red bars) — failure region
    - Mean clearance line
    - Zero clearance boundary
    - Risk level and probability annotations

    Args:
        result: A FitResult object from monte_carlo_fit().
        bins: Number of histogram bins. Default 80.
        show: If True, displays the plot. Default True.
        save_path: If provided, saves the figure to this path.
                   Example: 'output/fit_report.png'
        figsize: Figure size as (width, height) in inches.

    Returns:
        matplotlib Figure object (can be embedded or saved).

    Example:
        >>> from tolerix import monte_carlo_fit
        >>> from tolerix.visualization import plot_fit_distribution
        >>> result = monte_carlo_fit(shaft=(20.00, 0.02), hole=(20.05, 0.01))
        >>> plot_fit_distribution(result)
    """
    # ── Rebuild clearance samples from result statistics ──
    # We use a seeded normal distribution matching result parameters
    rng = np.random.default_rng(seed=0)
    clearance_samples = rng.normal(
        loc=result.mean_clearance,
        scale=result.std_clearance,
        size=result.samples
    )

    # ── Figure setup ──────────────────────────────────────
    fig, ax = plt.subplots(figsize=figsize)
    fig.patch.set_facecolor("#0f1117")
    ax.set_facecolor("#1a1d27")

    # ── Split samples into clearance / interference zones ─
    clearance_vals = clearance_samples[clearance_samples > 0]
    interference_vals = clearance_samples[clearance_samples <= 0]

    # ── Plot histogram bars ───────────────────────────────
    if len(clearance_vals) > 0:
        ax.hist(
            clearance_vals,
            bins=bins,
            color="#00c853",
            alpha=0.85,
            label=f"Clearance ({result.clearance_probability*100:.1f}%)",
            edgecolor="#004d20",
            linewidth=0.4,
        )

    if len(interference_vals) > 0:
        ax.hist(
            interference_vals,
            bins=bins,
            color="#ff1744",
            alpha=0.85,
            label=f"Interference ({result.interference_probability*100:.1f}%)",
            edgecolor="#7f0000",
            linewidth=0.4,
        )

    # ── Zero boundary line ────────────────────────────────
    ax.axvline(
        x=0,
        color="#ffffff",
        linewidth=1.8,
        linestyle="--",
        alpha=0.9,
        label="Zero Clearance Boundary",
        zorder=5,
    )

    # ── Mean clearance line ───────────────────────────────
    ax.axvline(
        x=result.mean_clearance,
        color="#ffd600",
        linewidth=1.8,
        linestyle="-",
        alpha=0.95,
        label=f"Mean Gap: {result.mean_clearance:.4f} mm",
        zorder=5,
    )

    # ── Risk level badge ──────────────────────────────────
    risk_colors = {"LOW": "#00c853", "MEDIUM": "#ff9100", "HIGH": "#ff1744"}
    risk_color = risk_colors.get(result.risk_level, "#ffffff")

    ax.text(
        0.98, 0.95,
        f"Risk: {result.risk_level}",
        transform=ax.transAxes,
        fontsize=13,
        fontweight="bold",
        color=risk_color,
        ha="right", va="top",
        bbox=dict(
            boxstyle="round,pad=0.4",
            facecolor="#1a1d27",
            edgecolor=risk_color,
            linewidth=1.5,
        )
    )

    # ── Fit type annotation ───────────────────────────────
    ax.text(
        0.02, 0.95,
        result.fit_type,
        transform=ax.transAxes,
        fontsize=11,
        fontweight="bold",
        color="#90caf9",
        ha="left", va="top",
    )

    # ── Styling ───────────────────────────────────────────
    shaft_label = result.shaft.name or "Shaft"
    hole_label = result.hole.name or "Hole"

    ax.set_title(
        f"Tolerix — Clearance Distribution\n"
        f"{shaft_label} ({result.shaft.nominal}±{result.shaft.tolerance} mm)  "
        f"→  {hole_label} ({result.hole.nominal}±{result.hole.tolerance} mm)",
        color="#e0e0e0",
        fontsize=13,
        fontweight="bold",
        pad=14,
    )
    ax.set_xlabel("Clearance (mm)  [ + = gap,  − = interference ]",
                  color="#9e9e9e", fontsize=11)
    ax.set_ylabel(f"Frequency  (n = {result.samples:,})",
                  color="#9e9e9e", fontsize=11)

    ax.tick_params(colors="#9e9e9e")
    for spine in ax.spines.values():
        spine.set_edgecolor("#333648")

    ax.grid(
        True,
        color="#2a2d3e",
        linewidth=0.6,
        linestyle="--",
        alpha=0.7,
    )

    legend = ax.legend(
        loc="upper left" if result.mean_clearance > 0 else "upper right",
        facecolor="#1a1d27",
        edgecolor="#444766",
        labelcolor="#e0e0e0",
        fontsize=9.5,
        framealpha=0.9,
    )

    plt.tight_layout()

    # ── Save if requested ─────────────────────────────────
    if save_path:
        fig.savefig(
            save_path,
            dpi=150,
            bbox_inches="tight",
            facecolor=fig.get_facecolor(),
        )

    if show:
        plt.show()

    return fig