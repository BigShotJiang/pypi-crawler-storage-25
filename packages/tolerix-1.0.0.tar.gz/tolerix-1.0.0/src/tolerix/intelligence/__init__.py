"""
tolerix.intelligence
====================
Engineering intelligence module.
Generates PDF reports combining all tolerix analyses
into a single professional engineering document.
"""

from tolerix.intelligence.reporter import generate_pdf_report

__all__ = ["generate_pdf_report"]