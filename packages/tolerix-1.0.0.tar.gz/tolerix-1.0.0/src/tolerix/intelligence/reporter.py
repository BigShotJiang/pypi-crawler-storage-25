"""
tolerix.intelligence.reporter
==============================
Professional PDF report generator for Tolerix analyses.
Combines fit analysis, process capability, and stack-up
results into a single engineering document.
"""

import io
import os
from datetime import datetime
from typing import Optional

import matplotlib
matplotlib.use("Agg")  # Non-interactive backend for PDF rendering
import matplotlib.pyplot as plt
import numpy as np

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    HRFlowable,
    Image,
    PageBreak,
)
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT

from tolerix.core import FitResult
from tolerix.analysis.capability import CapabilityResult
from tolerix.analysis.stackup import StackupResult


# ── Colour palette ────────────────────────────────────────
DARK_BG    = colors.HexColor("#0f1117")
PANEL_BG   = colors.HexColor("#1a1d27")
ACCENT     = colors.HexColor("#00c853")
DANGER     = colors.HexColor("#ff1744")
WARNING    = colors.HexColor("#ff9100")
TEXT_MAIN  = colors.HexColor("#e0e0e0")
TEXT_DIM   = colors.HexColor("#9e9e9e")
BORDER     = colors.HexColor("#333648")
YELLOW     = colors.HexColor("#ffd600")
BLUE       = colors.HexColor("#90caf9")
WHITE      = colors.white
BLACK      = colors.black


def _risk_color(risk: str):
    return {
        "LOW":    ACCENT,
        "MEDIUM": WARNING,
        "HIGH":   DANGER,
    }.get(risk, TEXT_MAIN)


def _make_styles():
    """Build and return all paragraph styles."""
    base = getSampleStyleSheet()

    title = ParagraphStyle(
        "TolerixTitle",
        parent=base["Title"],
        fontSize=26,
        textColor=WHITE,
        spaceAfter=4,
        alignment=TA_CENTER,
        fontName="Helvetica-Bold",
    )
    subtitle = ParagraphStyle(
        "TolerixSubtitle",
        parent=base["Normal"],
        fontSize=11,
        textColor=TEXT_DIM,
        spaceAfter=2,
        alignment=TA_CENTER,
        fontName="Helvetica",
    )
    section = ParagraphStyle(
        "TolerixSection",
        parent=base["Normal"],
        fontSize=13,
        textColor=ACCENT,
        spaceBefore=14,
        spaceAfter=6,
        fontName="Helvetica-Bold",
    )
    body = ParagraphStyle(
        "TolerixBody",
        parent=base["Normal"],
        fontSize=9,
        textColor=TEXT_MAIN,
        spaceAfter=4,
        fontName="Helvetica",
        leading=14,
    )
    insight = ParagraphStyle(
        "TolerixInsight",
        parent=base["Normal"],
        fontSize=9,
        textColor=BLUE,
        spaceAfter=4,
        fontName="Helvetica-Oblique",
        leading=14,
    )
    warning_style = ParagraphStyle(
        "TolerixWarning",
        parent=base["Normal"],
        fontSize=9,
        textColor=WARNING,
        spaceAfter=3,
        fontName="Helvetica",
        leading=13,
    )
    footer = ParagraphStyle(
        "TolerixFooter",
        parent=base["Normal"],
        fontSize=8,
        textColor=TEXT_DIM,
        alignment=TA_CENTER,
        fontName="Helvetica",
    )
    return {
        "title": title,
        "subtitle": subtitle,
        "section": section,
        "body": body,
        "insight": insight,
        "warning": warning_style,
        "footer": footer,
    }


def _dark_table_style(extra=None):
    """Returns a dark-themed TableStyle."""
    base = [
        ("BACKGROUND",   (0, 0), (-1, 0),  PANEL_BG),
        ("BACKGROUND",   (0, 1), (-1, -1), DARK_BG),
        ("TEXTCOLOR",    (0, 0), (-1, 0),  ACCENT),
        ("TEXTCOLOR",    (0, 1), (-1, -1), TEXT_MAIN),
        ("FONTNAME",     (0, 0), (-1, 0),  "Helvetica-Bold"),
        ("FONTNAME",     (0, 1), (-1, -1), "Helvetica"),
        ("FONTSIZE",     (0, 0), (-1, -1), 9),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [DARK_BG, PANEL_BG]),
        ("GRID",         (0, 0), (-1, -1), 0.4, BORDER),
        ("LEFTPADDING",  (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING",   (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING",(0, 0), (-1, -1), 5),
        ("VALIGN",       (0, 0), (-1, -1), "MIDDLE"),
    ]
    if extra:
        base.extend(extra)
    return TableStyle(base)


def _build_fit_chart(result: FitResult) -> io.BytesIO:
    """Renders the clearance distribution chart to an in-memory PNG."""
    rng = np.random.default_rng(seed=0)
    clearance = rng.normal(
        loc=result.mean_clearance,
        scale=result.std_clearance,
        size=result.samples,
    )

    fig, ax = plt.subplots(figsize=(8, 3.5))
    fig.patch.set_facecolor("#0f1117")
    ax.set_facecolor("#1a1d27")

    c_vals = clearance[clearance > 0]
    i_vals = clearance[clearance <= 0]

    if len(c_vals):
        ax.hist(c_vals, bins=80, color="#00c853", alpha=0.85,
                label=f"Clearance ({result.clearance_probability*100:.1f}%)",
                edgecolor="#004d20", linewidth=0.3)
    if len(i_vals):
        ax.hist(i_vals, bins=80, color="#ff1744", alpha=0.85,
                label=f"Interference ({result.interference_probability*100:.1f}%)",
                edgecolor="#7f0000", linewidth=0.3)

    ax.axvline(0, color="white", linewidth=1.5, linestyle="--",
               label="Zero Boundary")
    ax.axvline(result.mean_clearance, color="#ffd600", linewidth=1.5,
               label=f"Mean: {result.mean_clearance:.4f} mm")

    ax.tick_params(colors="#9e9e9e")
    ax.set_xlabel("Clearance (mm)", color="#9e9e9e", fontsize=9)
    ax.set_ylabel("Frequency", color="#9e9e9e", fontsize=9)
    ax.set_title("Clearance Distribution", color="#e0e0e0",
                 fontsize=10, fontweight="bold")

    for spine in ax.spines.values():
        spine.set_edgecolor("#333648")
    ax.grid(True, color="#2a2d3e", linewidth=0.5,
            linestyle="--", alpha=0.6)
    ax.legend(facecolor="#1a1d27", edgecolor="#444766",
              labelcolor="#e0e0e0", fontsize=8)

    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=150,
                bbox_inches="tight", facecolor=fig.get_facecolor())
    plt.close(fig)
    buf.seek(0)
    return buf


def generate_pdf_report(
    output_path: str,
    fit_result: Optional[FitResult] = None,
    capability_result: Optional[CapabilityResult] = None,
    stackup_result: Optional[StackupResult] = None,
    project_name: str = "Engineering Analysis",
    engineer: str = "Tolerix User",
) -> str:
    """
    Generates a professional PDF engineering report combining
    fit analysis, process capability, and stack-up results.

    Args:
        output_path: File path to save the PDF.
                     Example: 'reports/tolerix_report.pdf'
        fit_result: FitResult from monte_carlo_fit(). Optional.
        capability_result: CapabilityResult from process_capability(). Optional.
        stackup_result: StackupResult from tolerance_stackup(). Optional.
        project_name: Project or assembly name for the report header.
        engineer: Engineer name shown in the report footer.

    Returns:
        Absolute path to the saved PDF file.

    Raises:
        ValueError: If no results are provided.

    Example:
        >>> from tolerix.intelligence import generate_pdf_report
        >>> generate_pdf_report(
        ...     output_path="report.pdf",
        ...     fit_result=result,
        ...     project_name="Motor Assembly",
        ...     engineer="J. Smith",
        ... )
    """
    if not any([fit_result, capability_result, stackup_result]):
        raise ValueError(
            "At least one result (fit, capability, or stackup) "
            "must be provided to generate a report."
        )

    os.makedirs(os.path.dirname(output_path) if
                os.path.dirname(output_path) else ".", exist_ok=True)

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        leftMargin=18*mm,
        rightMargin=18*mm,
        topMargin=18*mm,
        bottomMargin=18*mm,
    )

    S = _make_styles()
    story = []
    W = A4[0] - 36*mm  # usable width

    # ── Cover header ──────────────────────────────────────
    story.append(Spacer(1, 10*mm))
    story.append(Paragraph("TOLERIX", S["title"]))
    story.append(Paragraph(
        "Professional Engineering Analysis Report", S["subtitle"]))
    story.append(Spacer(1, 2*mm))
    story.append(HRFlowable(width="100%", thickness=1,
                             color=ACCENT, spaceAfter=4))

    meta = [
        ["Project",   project_name,
         "Date", datetime.now().strftime("%d %b %Y")],
        ["Engineer",  engineer,
         "Version", "tolerix v0.1.0"],
    ]
    meta_table = Table(meta, colWidths=[30*mm, W/2-30*mm, 25*mm, W/2-25*mm])
    meta_table.setStyle(_dark_table_style())
    story.append(meta_table)
    story.append(Spacer(1, 6*mm))

    # ── Fit Analysis Section ──────────────────────────────
    if fit_result:
        story.append(HRFlowable(width="100%", thickness=0.5,
                                 color=BORDER, spaceAfter=2))
        story.append(Paragraph("1. Shaft–Hole Fit Analysis", S["section"]))

        # Dimension table
        dim_data = [
            ["Parameter", "Shaft", "Hole"],
            ["Name",
             fit_result.shaft.name or "Shaft",
             fit_result.hole.name or "Hole"],
            ["Nominal (mm)",
             f"{fit_result.shaft.nominal:.4f}",
             f"{fit_result.hole.nominal:.4f}"],
            ["Tolerance ± (mm)",
             f"{fit_result.shaft.tolerance:.4f}",
             f"{fit_result.hole.tolerance:.4f}"],
            ["Upper Limit (mm)",
             f"{fit_result.shaft.upper:.4f}",
             f"{fit_result.hole.upper:.4f}"],
            ["Lower Limit (mm)",
             f"{fit_result.shaft.lower:.4f}",
             f"{fit_result.hole.lower:.4f}"],
        ]
        dim_table = Table(
            dim_data,
            colWidths=[W*0.36, W*0.32, W*0.32]
        )
        dim_table.setStyle(_dark_table_style())
        story.append(dim_table)
        story.append(Spacer(1, 4*mm))

        # Results table
        rc = _risk_color(fit_result.risk_level)
        results_data = [
            ["Metric", "Value"],
            ["Fit Type",          fit_result.fit_type],
            ["Clearance Prob.",   f"{fit_result.clearance_probability*100:.2f}%"],
            ["Interference Prob.",f"{fit_result.interference_probability*100:.2f}%"],
            ["Mean Clearance",    f"{fit_result.mean_clearance:.4f} mm"],
            ["Std Deviation",     f"{fit_result.std_clearance:.4f} mm"],
            ["Samples",           f"{fit_result.samples:,}"],
            ["Risk Level",        fit_result.risk_level],
        ]
        res_table = Table(results_data, colWidths=[W*0.45, W*0.55])
        res_style = _dark_table_style([
            ("TEXTCOLOR", (1, 7), (1, 7), rc),
            ("FONTNAME",  (1, 7), (1, 7), "Helvetica-Bold"),
        ])
        res_table.setStyle(res_style)
        story.append(res_table)
        story.append(Spacer(1, 3*mm))

        story.append(Paragraph(
            f"Engineering Insight: {fit_result.insight}", S["insight"]))

        if fit_result.warnings:
            for w in fit_result.warnings:
                story.append(Paragraph(f"⚠  {w}", S["warning"]))

        story.append(Spacer(1, 4*mm))

        # Chart
        chart_buf = _build_fit_chart(fit_result)
        chart_img = Image(chart_buf, width=W, height=W * 0.42)
        story.append(chart_img)
        story.append(Spacer(1, 4*mm))

    # ── Process Capability Section ────────────────────────
    if capability_result:
        story.append(HRFlowable(width="100%", thickness=0.5,
                                 color=BORDER, spaceAfter=2))
        story.append(Paragraph(
            "2. Process Capability (Cp / Cpk)", S["section"]))

        rc = _risk_color(
            "LOW" if capability_result.cpk >= 1.33
            else "MEDIUM" if capability_result.cpk >= 1.0
            else "HIGH"
        )
        cap_data = [
            ["Metric", "Value"],
            ["USL",          f"{capability_result.usl:.4f} mm"],
            ["LSL",          f"{capability_result.lsl:.4f} mm"],
            ["Process Mean", f"{capability_result.mean:.4f} mm"],
            ["Std Deviation",f"{capability_result.std:.4f} mm"],
            ["Cp",           f"{capability_result.cp:.3f}"],
            ["Cpk",          f"{capability_result.cpk:.3f}"],
            ["Within Spec",  f"{capability_result.within_spec_pct:.2f}%"],
            ["Rating",       capability_result.rating],
        ]
        cap_table = Table(cap_data, colWidths=[W*0.45, W*0.55])
        cap_style = _dark_table_style([
            ("TEXTCOLOR", (1, 8), (1, 8), rc),
            ("FONTNAME",  (1, 8), (1, 8), "Helvetica-Bold"),
        ])
        cap_table.setStyle(cap_style)
        story.append(cap_table)
        story.append(Spacer(1, 3*mm))
        story.append(Paragraph(
            f"Engineering Insight: {capability_result.insight}",
            S["insight"]))
        story.append(Spacer(1, 4*mm))

    # ── Stack-Up Section ──────────────────────────────────
    if stackup_result:
        story.append(HRFlowable(width="100%", thickness=0.5,
                                 color=BORDER, spaceAfter=2))
        story.append(Paragraph(
            "3. Tolerance Stack-Up Analysis", S["section"]))

        # Contributing dimensions
        dim_rows = [["#", "Dimension", "Nominal (mm)", "Tolerance ± (mm)"]]
        for i, d in enumerate(stackup_result.dimensions, 1):
            dim_rows.append([
                str(i),
                d.name or f"Dim {i}",
                f"{d.nominal:.4f}",
                f"{d.tolerance:.4f}",
            ])
        dim_t = Table(
            dim_rows,
            colWidths=[W*0.08, W*0.36, W*0.28, W*0.28]
        )
        dim_t.setStyle(_dark_table_style())
        story.append(dim_t)
        story.append(Spacer(1, 3*mm))

        rc = _risk_color(stackup_result.risk_level)
        stack_data = [
            ["Metric", "Value"],
            ["Mean Gap",        f"{stackup_result.mean_gap:.4f} mm"],
            ["Worst Case Max",  f"{stackup_result.worst_case_max:.4f} mm"],
            ["Worst Case Min",  f"{stackup_result.worst_case_min:.4f} mm"],
            ["Worst Case Band", f"{stackup_result.worst_case_band:.4f} mm"],
            ["RSS Tolerance",   f"± {stackup_result.rss_tolerance:.4f} mm"],
            ["Risk Level",      stackup_result.risk_level],
        ]
        stack_table = Table(stack_data, colWidths=[W*0.45, W*0.55])
        stack_style = _dark_table_style([
            ("TEXTCOLOR", (1, 6), (1, 6), rc),
            ("FONTNAME",  (1, 6), (1, 6), "Helvetica-Bold"),
        ])
        stack_table.setStyle(stack_style)
        story.append(stack_table)
        story.append(Spacer(1, 3*mm))
        story.append(Paragraph(
            f"Engineering Insight: {stackup_result.insight}",
            S["insight"]))
        story.append(Spacer(1, 4*mm))

    # ── Footer ────────────────────────────────────────────
    story.append(HRFlowable(width="100%", thickness=1,
                             color=BORDER, spaceAfter=4))
    story.append(Paragraph(
        f"Generated by Tolerix v0.1.0  •  {engineer}  •  "
        f"{datetime.now().strftime('%d %b %Y %H:%M')}  •  "
        "Professional Engineering Simulation Toolkit",
        S["footer"]
    ))

    doc.build(story)
    return os.path.abspath(output_path)