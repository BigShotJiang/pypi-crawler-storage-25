"""
tolerix.core
============
Core data models for the Tolerix engineering toolkit.
Defines the fundamental types used across all modules.
"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Dimension:
    """
    Represents a physical dimension with a nominal value and tolerance.

    Attributes:
        nominal: The target/design dimension in mm.
        tolerance: The allowed variation (±) in mm.
        name: Optional label for this dimension (e.g. 'shaft_diameter').

    Example:
        >>> shaft = Dimension(nominal=20.00, tolerance=0.02, name="shaft")
        >>> shaft.upper
        20.02
        >>> shaft.lower
        19.98
    """
    nominal: float
    tolerance: float
    name: Optional[str] = None

    def __post_init__(self):
        if self.tolerance < 0:
            raise ValueError(
                f"Tolerance must be non-negative. Got: {self.tolerance}"
            )
        if self.nominal <= 0:
            raise ValueError(
                f"Nominal dimension must be positive. Got: {self.nominal}"
            )

    @property
    def upper(self) -> float:
        """Upper limit of the dimension (nominal + tolerance)."""
        return self.nominal + self.tolerance

    @property
    def lower(self) -> float:
        """Lower limit of the dimension (nominal - tolerance)."""
        return self.nominal - self.tolerance

    @property
    def total_band(self) -> float:
        """Total tolerance band (2 × tolerance)."""
        return 2 * self.tolerance

    def __repr__(self) -> str:
        label = f"'{self.name}' " if self.name else ""
        return (
            f"Dimension({label}{self.nominal:.4f} "
            f"± {self.tolerance:.4f} mm "
            f"[{self.lower:.4f} – {self.upper:.4f}])"
        )


@dataclass
class FitResult:
    """
    Stores the result of a shaft-hole fit analysis.

    Attributes:
        shaft: The shaft Dimension used in analysis.
        hole: The hole Dimension used in analysis.
        clearance_probability: Probability of clearance fit (0.0 to 1.0).
        interference_probability: Probability of interference fit (0.0 to 1.0).
        mean_clearance: Expected mean clearance (negative = interference).
        std_clearance: Standard deviation of the clearance distribution.
        samples: Number of Monte Carlo samples used.
        fit_type: Dominant fit classification string.
        risk_level: Engineering risk level ('LOW', 'MEDIUM', 'HIGH').
        insight: Engineering interpretation message.
        warnings: List of engineering warnings generated.
    """
    shaft: Dimension
    hole: Dimension
    clearance_probability: float
    interference_probability: float
    mean_clearance: float
    std_clearance: float
    samples: int
    fit_type: str
    risk_level: str
    insight: str
    warnings: list[str] = field(default_factory=list)

    def summary(self) -> str:
        """
        Returns a formatted engineering summary of the fit analysis.

        Returns:
            A multi-line string with all key results and insights.
        """
        sep = "─" * 48
        lines = [
            sep,
            "  TOLERIX — Fit Analysis Report",
            sep,
            f"  Shaft       : {self.shaft}",
            f"  Hole        : {self.hole}",
            sep,
            f"  Fit Type    : {self.fit_type}",
            f"  Clearance   : {self.clearance_probability * 100:.1f}%",
            f"  Interference: {self.interference_probability * 100:.1f}%",
            f"  Mean Gap    : {self.mean_clearance:.4f} mm",
            f"  Std Dev     : {self.std_clearance:.4f} mm",
            f"  Samples     : {self.samples:,}",
            sep,
            f"  Risk Level  : {self.risk_level}",
            f"  Insight     : {self.insight}",
        ]
        if self.warnings:
            lines.append(sep)
            lines.append("  ⚠ Warnings:")
            for w in self.warnings:
                lines.append(f"    • {w}")
        lines.append(sep)
        return "\n".join(lines)

    def __repr__(self) -> str:
        return (
            f"FitResult(fit_type='{self.fit_type}', "
            f"clearance={self.clearance_probability * 100:.1f}%, "
            f"risk='{self.risk_level}')"
        )