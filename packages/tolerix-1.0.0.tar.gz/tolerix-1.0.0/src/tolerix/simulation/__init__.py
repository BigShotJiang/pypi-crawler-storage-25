"""
tolerix.simulation
==================
Monte Carlo simulation engine for tolerance and fit analysis.
Generates statistical distributions of shaft-hole clearance
based on normally distributed manufacturing variation.
"""

import numpy as np
from tolerix.core import Dimension, FitResult


def _classify_fit(clearance_prob: float, interference_prob: float) -> str:
    """
    Classifies the dominant fit type based on probabilities.

    Args:
        clearance_prob: Probability of clearance (0.0 to 1.0).
        interference_prob: Probability of interference (0.0 to 1.0).

    Returns:
        Fit classification string.
    """
    if clearance_prob >= 0.99:
        return "CLEARANCE FIT"
    elif interference_prob >= 0.99:
        return "INTERFERENCE FIT"
    elif clearance_prob >= 0.50:
        return "TRANSITION FIT (Clearance Dominant)"
    else:
        return "TRANSITION FIT (Interference Dominant)"


def _assess_risk(
    interference_prob: float,
    std_clearance: float
) -> str:
    """
    Assigns an engineering risk level based on interference
    probability and variation spread.

    Args:
        interference_prob: Probability of interference (0.0 to 1.0).
        std_clearance: Standard deviation of clearance distribution.

    Returns:
        Risk level string: 'LOW', 'MEDIUM', or 'HIGH'.
    """
    if interference_prob > 0.10:
        return "HIGH"
    elif interference_prob > 0.02 or std_clearance > 0.05:
        return "MEDIUM"
    else:
        return "LOW"


def _generate_insight(
    fit_type: str,
    risk_level: str,
    mean_clearance: float,
    interference_prob: float
) -> str:
    """
    Generates a human-readable engineering interpretation.

    Args:
        fit_type: Classified fit type string.
        risk_level: Assessed risk level string.
        mean_clearance: Mean clearance value in mm.
        interference_prob: Probability of interference.

    Returns:
        Engineering insight string.
    """
    if risk_level == "LOW":
        return (
            "Tolerance range is stable for standard CNC manufacturing. "
            "Assembly success rate is high under normal process conditions."
        )
    elif risk_level == "MEDIUM":
        return (
            f"Interference risk detected at {interference_prob * 100:.1f}%. "
            "Consider tightening shaft tolerance or reviewing process capability."
        )
    else:
        return (
            f"HIGH interference risk ({interference_prob * 100:.1f}%). "
            "Current tolerances are not suitable for reliable assembly. "
            "Immediate design review recommended."
        )


def _generate_warnings(
    shaft: Dimension,
    hole: Dimension,
    interference_prob: float,
    mean_clearance: float
) -> list[str]:
    """
    Generates a list of engineering warnings based on simulation results.

    Args:
        shaft: Shaft Dimension object.
        hole: Hole Dimension object.
        interference_prob: Probability of interference.
        mean_clearance: Mean clearance in mm.

    Returns:
        List of warning strings. Empty list if no warnings.
    """
    warnings = []

    if shaft.nominal >= hole.nominal:
        warnings.append(
            "Shaft nominal >= Hole nominal. Interference is by design "
            "or a dimension input error may exist."
        )

    if interference_prob > 0.05:
        warnings.append(
            f"Interference probability exceeds 5% ({interference_prob*100:.1f}%). "
            "Assembly failures likely without process control."
        )

    if shaft.tolerance > hole.tolerance * 3:
        warnings.append(
            "Shaft tolerance is significantly wider than hole tolerance. "
            "Consider balancing tolerances for better fit control."
        )

    if mean_clearance < 0.005 and mean_clearance > 0:
        warnings.append(
            "Mean clearance is extremely small (< 0.005 mm). "
            "Surface finish and thermal expansion effects may dominate."
        )

    return warnings


def monte_carlo_fit(
    shaft: tuple[float, float],
    hole: tuple[float, float],
    samples: int = 100_000,
    shaft_name: str = "Shaft",
    hole_name: str = "Hole",
    seed: int | None = None
) -> FitResult:
    """
    Runs a Monte Carlo simulation of shaft-hole fit variation.

    Models both shaft and hole dimensions as normally distributed
    random variables, where the tolerance represents ±3σ (99.73%
    of parts fall within spec). Computes clearance distribution
    and derives engineering metrics.

    Args:
        shaft: Tuple of (nominal, tolerance) in mm.
               Example: (20.00, 0.02) → 20.00 ± 0.02 mm
        hole: Tuple of (nominal, tolerance) in mm.
              Example: (20.05, 0.01) → 20.05 ± 0.01 mm
        samples: Number of Monte Carlo samples. Default 100,000.
                 Higher = more accurate probability estimates.
        shaft_name: Optional label for the shaft dimension.
        hole_name: Optional label for the hole dimension.
        seed: Optional random seed for reproducibility.

    Returns:
        FitResult object containing all analysis results.

    Raises:
        ValueError: If nominal or tolerance values are invalid.
        ValueError: If samples < 1000 (statistically unreliable).

    Example:
        >>> result = monte_carlo_fit(
        ...     shaft=(20.00, 0.02),
        ...     hole=(20.05, 0.01),
        ...     samples=100000
        ... )
        >>> print(result.summary())
    """
    if samples < 1000:
        raise ValueError(
            f"samples must be >= 1000 for statistical reliability. "
            f"Got: {samples}"
        )

    # Build typed Dimension objects
    shaft_dim = Dimension(
        nominal=shaft[0],
        tolerance=shaft[1],
        name=shaft_name
    )
    hole_dim = Dimension(
        nominal=hole[0],
        tolerance=hole[1],
        name=hole_name
    )

    # Tolerance is treated as ±3σ (standard engineering convention)
    # So σ = tolerance / 3
    shaft_sigma = shaft_dim.tolerance / 3.0
    hole_sigma = hole_dim.tolerance / 3.0

    # Set random seed if provided (for reproducibility)
    rng = np.random.default_rng(seed)

    # Generate normally distributed samples for each dimension
    shaft_samples = rng.normal(
        loc=shaft_dim.nominal,
        scale=shaft_sigma,
        size=samples
    )
    hole_samples = rng.normal(
        loc=hole_dim.nominal,
        scale=hole_sigma,
        size=samples
    )

    # Clearance = Hole - Shaft
    # Positive = clearance (hole bigger than shaft) ✅
    # Negative = interference (shaft bigger than hole) ❌
    clearance = hole_samples - shaft_samples

    # Compute statistics
    mean_clearance = float(np.mean(clearance))
    std_clearance = float(np.std(clearance))
    clearance_prob = float(np.mean(clearance > 0))
    interference_prob = float(np.mean(clearance <= 0))

    # Classify, assess, interpret
    fit_type = _classify_fit(clearance_prob, interference_prob)
    risk_level = _assess_risk(interference_prob, std_clearance)
    insight = _generate_insight(
        fit_type, risk_level, mean_clearance, interference_prob
    )
    warnings = _generate_warnings(
        shaft_dim, hole_dim, interference_prob, mean_clearance
    )

    return FitResult(
        shaft=shaft_dim,
        hole=hole_dim,
        clearance_probability=clearance_prob,
        interference_probability=interference_prob,
        mean_clearance=mean_clearance,
        std_clearance=std_clearance,
        samples=samples,
        fit_type=fit_type,
        risk_level=risk_level,
        insight=insight,
        warnings=warnings,
    )