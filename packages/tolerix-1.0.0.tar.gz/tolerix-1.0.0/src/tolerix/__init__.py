"""
tolerix
=======
A professional engineering analytics and simulation toolkit.
"""
version = "1.0.0"
__author__ = "Subiksha T"
__license__ = "MIT"

from tolerix.core import Dimension, FitResult
from tolerix.simulation import monte_carlo_fit
from tolerix.visualization import plot_fit_distribution
from tolerix.analysis import process_capability, tolerance_stackup
from tolerix.intelligence import generate_pdf_report

__all__ = [
    "Dimension",
    "FitResult",
    "monte_carlo_fit",
    "plot_fit_distribution",
    "process_capability",
    "tolerance_stackup",
    "generate_pdf_report",
    "__version__",
    "__author__",
    "__license__",
]