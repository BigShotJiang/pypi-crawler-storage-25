"""
tolerix.analysis.stackup
=========================
Tolerance stack-up analysis for assemblies with
multiple contributing dimensions.
"""

from dataclasses import dataclass, field
import numpy as np
from tolerix.core import Dimension


@dataclass
class StackupResult:
    """
    Result of a tolerance stack-up analysis.

    Attributes:
        dimensions: List of contributing Dimension objects.
        worst_case_max: Maximum possible stack-up gap.
        worst_case_min: Minimum possible stack-up gap.
        worst_case_band: Total worst-case variation band.
        rss_tolerance: Root Sum Square combined tolerance.
        mean_gap: Nominal sum of all dimensions.
        risk_level: Engineering risk assessment.
        insight: Engineering interpretation.
    """
    dimensions: list[Dimension]
    worst_case_max: float
    worst_case_min: float
    worst_case_band: float
    rss_tolerance: float
    mean_gap: float
    risk_level: str
    insight: str

    def summary(self) -> str:
        """Returns a formatted stack-up analysis report."""
        sep = "─" * 48
        lines = [
            sep,
            "  TOLERIX — Tolerance Stack-Up Report",
            sep,
        ]
        for i, dim in enumerate(self.dimensions, 1):
            label = dim.name or f"Dimension {i}"
            lines.append(f"  [{i}] {label:<16}: "
                        f"{dim.nominal:.4f} ± {dim.tolerance:.4f} mm")
        lines += [
            sep,
            f"  Worst Case Max  : {self.worst_case_max:.4f} mm",
            f"  Worst Case Min  : {self.worst_case_min:.4f} mm",
            f"  Worst Case Band : {self.worst_case_band:.4f} mm",
            f"  RSS Tolerance   : ± {self.rss_tolerance:.4f} mm",
            f"  Mean Gap        : {self.mean_gap:.4f} mm",
            sep,
            f"  Risk Level      : {self.risk_level}",
            f"  Insight         : {self.insight}",
            sep,
        ]
        return "\n".join(lines)


def tolerance_stackup(
    dimensions: list[tuple[float, float, str]],
) -> StackupResult:
    """
    Performs worst-case and RSS tolerance stack-up analysis
    for a chain of contributing dimensions in an assembly.

    Args:
        dimensions: List of (nominal, tolerance, name) tuples.
                    Each represents one contributing dimension.

    Returns:
        StackupResult with worst-case and RSS analysis.

    Raises:
        ValueError: If fewer than 2 dimensions are provided.

    Example:
        >>> from tolerix.analysis import tolerance_stackup
        >>> result = tolerance_stackup([
        ...     (50.0, 0.05, "Plate A"),
        ...     (30.0, 0.03, "Plate B"),
        ...     (20.0, 0.02, "Spacer"),
        ... ])
        >>> print(result.summary())
    """
    if len(dimensions) < 2:
        raise ValueError(
            "Stack-up analysis requires at least 2 dimensions."
        )

    dim_objects = [
        Dimension(nominal=n, tolerance=t, name=name)
        for n, t, name in dimensions
    ]

    nominals = np.array([d.nominal for d in dim_objects])
    tolerances = np.array([d.tolerance for d in dim_objects])

    # Mean gap — sum of all nominals
    mean_gap = float(np.sum(nominals))

    # Worst case — all tolerances add up directly
    total_wc_tolerance = float(np.sum(tolerances))
    worst_case_max = mean_gap + total_wc_tolerance
    worst_case_min = mean_gap - total_wc_tolerance
    worst_case_band = 2 * total_wc_tolerance

    # RSS — Root Sum Square (statistical method)
    # More realistic than worst case for many dimensions
    rss_tolerance = float(np.sqrt(np.sum(tolerances ** 2)))

    # Risk assessment based on worst-case band
    if total_wc_tolerance / mean_gap > 0.01:
        risk_level = "HIGH"
        insight = (
            "Worst-case stack-up exceeds 1% of nominal assembly dimension. "
            "Consider tightening individual tolerances or redesigning stack."
        )
    elif total_wc_tolerance / mean_gap > 0.005:
        risk_level = "MEDIUM"
        insight = (
            "Stack-up variation is moderate. RSS method suggests acceptable "
            "performance under normal manufacturing conditions."
        )
    else:
        risk_level = "LOW"
        insight = (
            "Stack-up variation is well controlled. Assembly dimensions "
            "are stable across the full tolerance range."
        )

    return StackupResult(
        dimensions=dim_objects,
        worst_case_max=round(worst_case_max, 6),
        worst_case_min=round(worst_case_min, 6),
        worst_case_band=round(worst_case_band, 6),
        rss_tolerance=round(rss_tolerance, 6),
        mean_gap=round(mean_gap, 6),
        risk_level=risk_level,
        insight=insight,
    )