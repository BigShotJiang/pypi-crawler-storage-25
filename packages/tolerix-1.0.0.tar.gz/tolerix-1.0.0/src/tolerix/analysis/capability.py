"""
tolerix.analysis.capability
============================
Process capability analysis (Cp and Cpk).
Measures how well a manufacturing process fits within
its specification limits.
"""

from dataclasses import dataclass
from typing import Optional
import numpy as np


@dataclass
class CapabilityResult:
    """
    Stores the result of a process capability analysis.

    Attributes:
        cp: Process capability index (spread only).
        cpk: Process capability index (spread + centering).
        mean: Sample mean of the process.
        std: Sample standard deviation.
        usl: Upper specification limit.
        lsl: Lower specification limit.
        within_spec_pct: Percentage of parts within spec.
        rating: Engineering rating string.
        insight: Human-readable interpretation.
    """
    cp: float
    cpk: float
    mean: float
    std: float
    usl: float
    lsl: float
    within_spec_pct: float
    rating: str
    insight: str

    def summary(self) -> str:
        """Returns a formatted process capability report."""
        sep = "─" * 48
        lines = [
            sep,
            "  TOLERIX — Process Capability Report",
            sep,
            f"  USL         : {self.usl:.4f} mm",
            f"  LSL         : {self.lsl:.4f} mm",
            f"  Mean        : {self.mean:.4f} mm",
            f"  Std Dev     : {self.std:.4f} mm",
            sep,
            f"  Cp          : {self.cp:.3f}",
            f"  Cpk         : {self.cpk:.3f}",
            f"  Within Spec : {self.within_spec_pct:.2f}%",
            sep,
            f"  Rating      : {self.rating}",
            f"  Insight     : {self.insight}",
            sep,
        ]
        return "\n".join(lines)


def _rate_cpk(cpk: float) -> tuple[str, str]:
    """
    Rates process capability based on Cpk value.
    Industry standard thresholds.

    Args:
        cpk: Process capability index.

    Returns:
        Tuple of (rating string, insight string).
    """
    if cpk >= 1.67:
        return (
            "EXCELLENT",
            "Process is highly capable. Suitable for safety-critical "
            "manufacturing. Six Sigma level performance."
        )
    elif cpk >= 1.33:
        return (
            "GOOD",
            "Process is capable and meets industry standard requirements. "
            "Suitable for most precision manufacturing."
        )
    elif cpk >= 1.00:
        return (
            "MARGINAL",
            "Process is minimally capable. Some defects expected. "
            "Process improvement recommended."
        )
    elif cpk >= 0.67:
        return (
            "POOR",
            "Process is not capable. Significant defect rate expected. "
            "Immediate process review required."
        )
    else:
        return (
            "FAILING",
            "Process is critically incapable. High defect rate. "
            "Stop production and investigate root cause."
        )


def process_capability(
    nominal: float,
    tolerance: float,
    samples: int = 100_000,
    process_mean: Optional[float] = None,
    process_std: Optional[float] = None,
    seed: Optional[int] = None,
) -> CapabilityResult:
    """
    Calculates Cp and Cpk process capability indices.

    Models the manufacturing process as a normal distribution
    and evaluates how well it fits within the specification limits.

    Args:
        nominal: Target dimension in mm.
        tolerance: Allowed variation (±) in mm. Defines USL and LSL.
        samples: Monte Carlo sample count. Default 100,000.
        process_mean: Actual process mean. Defaults to nominal.
        process_std: Actual process std dev. Defaults to tolerance/3.
        seed: Random seed for reproducibility.

    Returns:
        CapabilityResult with Cp, Cpk, rating, and insight.

    Example:
        >>> from tolerix.analysis import process_capability
        >>> result = process_capability(nominal=25.0, tolerance=0.05)
        >>> print(result.summary())
    """
    usl = nominal + tolerance
    lsl = nominal - tolerance

    mean = process_mean if process_mean is not None else nominal
    std = process_std if process_std is not None else tolerance / 3.0

    # Generate process samples
    rng = np.random.default_rng(seed)
    data = rng.normal(loc=mean, scale=std, size=samples)

    # Cp — pure spread capability (ignores centering)
    cp = (usl - lsl) / (6.0 * std)

    # Cpk — accounts for both spread AND centering
    cpu = (usl - mean) / (3.0 * std)
    cpl = (mean - lsl) / (3.0 * std)
    cpk = min(cpu, cpl)

    # Percentage within spec
    within_spec = np.sum((data >= lsl) & (data <= usl))
    within_spec_pct = float(within_spec / samples * 100)

    rating, insight = _rate_cpk(cpk)

    return CapabilityResult(
        cp=round(cp, 4),
        cpk=round(cpk, 4),
        mean=round(mean, 4),
        std=round(std, 4),
        usl=usl,
        lsl=lsl,
        within_spec_pct=round(within_spec_pct, 4),
        rating=rating,
        insight=insight,
    )