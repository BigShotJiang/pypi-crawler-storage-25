"""AxiomCliBridge — runs axiomai chat in a hidden PTY and exposes a .chat() method."""
from __future__ import annotations

import errno
import os
import pty
import re
import select
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

# The prompt in repl_ui.py is: "(\u30c4\u00bb "  which is  "(ツ» "
# prompt_toolkit may render it differently through a PTY, so we try multiple variants.
_PROMPT_VARIANTS = [
    "(\u30c4\u00bb ",       # exact: (ツ»
    "(\u30c4) \u00bb ",     # (ツ) »
    "\u00bb ",              # fallback: just »
]
MODEL_PROMPT_MARKER = "Enter model number to select (or Enter to keep current): "
RAW_BEGIN = "--- RAW BEGIN ---"
RAW_END = "--- RAW END ---"
ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_DEBUG_BRIDGE = os.environ.get("AXIOM_BRIDGE_DEBUG", "").lower() in ("1", "on", "true")

WEB_DIR = Path(__file__).resolve().parent
REPO_ROOT = WEB_DIR.parent


def _strip_ansi(text: str) -> str:
    return ANSI_RE.sub("", text).replace("\r", "")




def _ensure_tutorial_guard() -> None:
    tutorial_flag = Path.home() / ".aye" / ".tutorial_ran"
    tutorial_flag.parent.mkdir(parents=True, exist_ok=True)
    tutorial_flag.touch(exist_ok=True)


class _PtySession:
    def __init__(self, command: list[str], *, cwd: Path, env: dict[str, str], timeout: float = 180.0) -> None:
        self._timeout = timeout
        self._buffer = ""
        self._master_fd, slave_fd = pty.openpty()
        self._proc = subprocess.Popen(
            command,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            cwd=str(cwd),
            env=env,
            close_fds=True,
        )
        os.close(slave_fd)

    @property
    def alive(self) -> bool:
        return self._proc.poll() is None

    def write(self, text: str) -> None:
        # prompt_toolkit expects \r (Carriage Return) as the Enter key, not \n
        if text.endswith('\n'):
            text = text[:-1] + '\r'
        os.write(self._master_fd, text.encode("utf-8"))

    def read_until(self, marker: str, *, timeout: float | None = None) -> str:
        deadline = time.monotonic() + (timeout if timeout is not None else self._timeout)

        while True:
            # Search in the ANSI-cleaned buffer so escape codes don't break marker matching
            clean = _strip_ansi(self._buffer)
            marker_index = clean.find(marker)
            if marker_index != -1:
                # Found marker in cleaned text. Extract everything before it.
                result = clean[:marker_index]
                # Now we need to advance the raw buffer past the marker.
                # Walk through raw buffer, stripping ANSI, counting clean chars
                # until we've consumed marker_index + len(marker) clean chars.
                target_clean_len = int(marker_index + len(marker))
                raw_pos = 0
                clean_counted = 0
                while raw_pos < len(self._buffer) and clean_counted < target_clean_len:
                    # Check if current position starts an ANSI sequence
                    if self._buffer[raw_pos] == '\x1b':
                        m = ANSI_RE.match(self._buffer, raw_pos)
                        if m:
                            raw_pos = int(m.end())
                            continue
                    # Count as a clean character
                    if self._buffer[raw_pos] == '\r':
                        raw_pos += 1
                        continue
                    clean_counted += 1
                    raw_pos += 1
                self._buffer = self._buffer[raw_pos:]
                return result

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                if _DEBUG_BRIDGE:
                    import sys as _sys
                    _sys.stderr.write(f"[bridge] TIMEOUT buffer ({len(self._buffer)} chars): {clean[-500:]!r}\n")
                raise TimeoutError(f"Timed out waiting for {marker!r}")

            if self._proc.poll() is not None:
                raise RuntimeError(_strip_ansi(self._buffer) or "Axiom CLI exited unexpectedly.")

            readable, _, _ = select.select([self._master_fd], [], [], min(0.1, remaining))
            if not readable:
                continue

            try:
                data = os.read(self._master_fd, 4096)
            except OSError as exc:
                if exc.errno in {errno.EIO, errno.EBADF}:
                    raise RuntimeError(_strip_ansi(self._buffer) or "Axiom CLI closed the terminal unexpectedly.") from exc
                raise

            if not data:
                continue

            self._buffer = str(self._buffer) + data.decode("utf-8", errors="replace")
            if _DEBUG_BRIDGE:
                import sys as _sys
                _sys.stderr.write(f"[bridge] +{len(data)}b buf={len(self._buffer)} last80={clean[-80:]!r}\n")

    def terminate(self) -> None:
        try:
            if self.alive:
                self.write("exit\n")
                self._proc.wait(timeout=2.0)
        except Exception:
            try:
                self._proc.terminate()
            except Exception:
                pass
        finally:
            try:
                os.close(self._master_fd)
            except Exception:
                pass


class AxiomCliBridge:
    """Manages a hidden axiomai chat session and sends messages to it."""

    def __init__(self, *, project_root: Path, models: list[dict[str, Any]]) -> None:
        self.project_root = project_root
        self.models = models
        self._lock = threading.RLock()
        self._session: _PtySession | None = None
        self._active_model_id: str | None = None
        self._custom_model_counter = 0

    def reset(self) -> None:
        with self._lock:
            if self._session is not None:
                self._session.terminate()
            self._session = None
            self._active_model_id = None

    def interrupt(self) -> None:
        """Send Ctrl+C (\x03) to the PTY to interrupt current generation/operation."""
        with self._lock:
            if self._session is not None and self._session.alive:
                if _DEBUG_BRIDGE:
                    import sys as _sys
                    _sys.stderr.write("[bridge] Sending Interrupt (Ctrl+C)...\n")
                    _sys.stderr.flush()
                # \x03 is the ASCII code for Ctrl+C (ETX)
                os.write(self._session._master_fd, b"\x03")

    def _read_until_prompt(self, timeout: float = 240.0) -> str:
        """Read from the PTY until any known prompt variant is found."""
        assert self._session is not None
        deadline = time.monotonic() + timeout

        import sys as _sys
        if _DEBUG_BRIDGE:
            _sys.stderr.write(f"[bridge] _read_until_prompt started (timeout={timeout})\n")
            _sys.stderr.flush()

        while True:
            # Check the cleaned buffer for any prompt variant
            clean_buf = _strip_ansi(self._session._buffer)
            for variant in _PROMPT_VARIANTS:
                if variant in clean_buf:
                    # Found it! Use read_until which handles ANSI stripping
                    if _DEBUG_BRIDGE:
                        _sys.stderr.write(f"[bridge] Found prompt variant: {variant!r}. Calling read_until...\n")
                        _sys.stderr.flush()
                    remaining_time = max(1.0, deadline - time.monotonic())
                    return self._session.read_until(variant, timeout=remaining_time)

            remaining = deadline - time.monotonic()
            if remaining <= 0:
                if _DEBUG_BRIDGE:
                    _sys.stderr.write(f"[bridge] prompt TIMEOUT. buf tail: {clean_buf[-300:]!r}\n")
                    _sys.stderr.flush()
                raise TimeoutError("Timed out waiting for Axiom prompt")

            if self._session._proc.poll() is not None:
                raise RuntimeError(_strip_ansi(self._session._buffer) or "Axiom CLI exited unexpectedly.")

            readable, _, _ = select.select([self._session._master_fd], [], [], min(0.2, remaining))
            if readable:
                try:
                    data = os.read(self._session._master_fd, 4096)
                    if data:
                        self._session._buffer = str(self._session._buffer) + data.decode("utf-8", errors="replace")
                        if _DEBUG_BRIDGE:
                            _sys.stderr.write(f"[bridge] +{len(data)}b total={len(self._session._buffer)}\n")
                            _sys.stderr.flush()
                except OSError as exc:
                    if exc.errno in {errno.EIO, errno.EBADF}:
                        raise RuntimeError("Axiom CLI closed unexpectedly.") from exc
                    raise

    def chat(self, message: str, model_id: str) -> str:
        with self._lock:
            import sys as _sys
            if _DEBUG_BRIDGE:
                _sys.stderr.write(f"\n[bridge] chat() called with message={message[:20]!r} model={model_id}\n")
                _sys.stderr.flush()

            if self._session is None or self._active_model_id != model_id or not self._session.alive:
                if _DEBUG_BRIDGE:
                    _sys.stderr.write(f"[bridge] Starting new session...\n")
                    _sys.stderr.flush()
                self._start_session(model_id)

            assert self._session is not None
            # prompt_toolkit is single-line by default, internal newlines might break it
            clean_message = message.replace('\r\n', ' ').replace('\n', ' ')
            
            if _DEBUG_BRIDGE:
                _sys.stderr.write(f"[bridge] Sending message: {clean_message[:20]!r}...\n")
                _sys.stderr.flush()
                
            self._session.write(f"{clean_message}\n")
            
            if _DEBUG_BRIDGE:
                _sys.stderr.write(f"[bridge] Waiting for assistant output...\n")
                _sys.stderr.flush()
                
            assistant_output = self._read_until_prompt(timeout=240.0)

            if _DEBUG_BRIDGE:
                _sys.stderr.write(f"[bridge] Sending 'raw' command...\n")
                _sys.stderr.flush()
                
            self._session.write("raw\n")
            raw_output = self._read_until_prompt(timeout=120.0)
            raw_text = self._extract_raw_text(raw_output)
            
            if _DEBUG_BRIDGE:
                _sys.stderr.write(f"[bridge] Returning from chat().\n")
                _sys.stderr.flush()
                
            if raw_text:
                return raw_text

            fallback_text = self._extract_last_block(assistant_output)
            if fallback_text:
                return fallback_text

            raise RuntimeError("Axiom CLI returned an empty response.")

    def _find_model_index_in_list(self, model_list_text: str, model_id: str) -> int | None:
        """Parse the numbered model list output and find the 1-based index for model_id.

        The list looks like:
          1. kullanicimodel1
          2. xAI: Grok Code Fast 1
          ...

        We match by checking the model name against our known models list,
        or by matching 'kullanicimodel1' (our custom model placeholder name).
        """
        lines = model_list_text.strip().splitlines()
        # Build a set of target names to search for
        target_names: set[str] = set()
        for m in self.models:
            if m.get("id") == model_id:
                target_names.add(m.get("name", ""))
                break
        # Also match our placeholder names used for custom models (kullanicimodel1, kullanicimodel2, ...)
        for i in range(1, self._custom_model_counter + 2):
            target_names.add(f"kullanicimodel{i}")
        target_names.discard("")

        for line in lines:
            line = line.strip()
            # Match lines like "  3. xAI: Grok 4.2"
            match = re.match(r"(\d+)\.\s+(.+)", line)
            if not match:
                continue
            index = int(match.group(1))
            name = match.group(2).strip()
            # Strip size info like "[4.7GB download]"
            name_clean = re.sub(r"\s*\[.*?\]\s*$", "", name).strip()

            if name_clean in target_names:
                return index
            # Also try matching by model_id directly in the name
            if model_id in name_clean.lower():
                return index

        return None

    def _add_custom_model_via_pty(self, model_id: str) -> None:
        """Run 'model add' in the PTY to register an unknown model."""
        assert self._session is not None
        import sys as _sys

        self._custom_model_counter += 1
        model_name = f"kullanicimodel{self._custom_model_counter}"

        if _DEBUG_BRIDGE:
            _sys.stderr.write(f"[bridge] Adding custom model: {model_id} as {model_name}\n")
            _sys.stderr.flush()

        self._session.write("model add\n")
        # Wait for "Model ID" prompt
        self._session.read_until("Model ID (e.g., openai/gpt-5): ", timeout=30.0)
        self._session.write(f"{model_id}\n")
        # Wait for "Model Name" prompt
        self._session.read_until("Model Name (e.g., My Custom GPT): ", timeout=30.0)
        self._session.write(f"{model_name}\n")
        # Wait for "Model Type" prompt
        self._session.read_until("Model Type [chat/image] (default: chat): ", timeout=30.0)
        self._session.write("chat\n")
        # Wait for prompt to return
        self._read_until_prompt(timeout=60.0)

        if _DEBUG_BRIDGE:
            _sys.stderr.write(f"[bridge] Custom model added: {model_id} as {model_name}\n")
            _sys.stderr.flush()

    def _select_model_by_parsing_list(self, model_id: str) -> None:
        """Send 'model', parse the list, and select the correct index."""
        assert self._session is not None
        import sys as _sys

        self._session.write("model\n")
        model_list_output = self._session.read_until(MODEL_PROMPT_MARKER, timeout=60.0)
        clean_list = _strip_ansi(model_list_output)

        if _DEBUG_BRIDGE:
            _sys.stderr.write(f"[bridge] Model list:\n{clean_list[-500:]}\n")
            _sys.stderr.flush()

        # Find the correct index in the actual CLI list
        index = self._find_model_index_in_list(clean_list, model_id)

        if index is None:
            # Model not found in list — cancel selection and add it
            self._session.write("\n")  # Press Enter to keep current
            self._read_until_prompt(timeout=30.0)

            # Add the model
            self._add_custom_model_via_pty(model_id)

            # Now re-list and find it
            self._session.write("model\n")
            model_list_output = self._session.read_until(MODEL_PROMPT_MARKER, timeout=60.0)
            clean_list = _strip_ansi(model_list_output)
            index = self._find_model_index_in_list(clean_list, model_id)

            if index is None:
                # Last resort: the newly added model should be #1
                index = 1

            if _DEBUG_BRIDGE:
                _sys.stderr.write(f"[bridge] After add, selecting index {index}\n")
                _sys.stderr.flush()

        if _DEBUG_BRIDGE:
            _sys.stderr.write(f"[bridge] Selecting model index {index} for {model_id}\n")
            _sys.stderr.flush()

        self._session.write(f"{index}\n")
        self._read_until_prompt(timeout=240.0)

    def _start_session(self, model_id: str) -> None:
        self.reset()
        _ensure_tutorial_guard()

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        env["AYE_TELEMETRY_OPT_IN"] = "off"
        env.setdefault("AYE_FEEDBACK_OPT_IN", "off")
        env["TERM"] = "dumb"  # Minimize ANSI escape sequences
        env["NO_COLOR"] = "1"  # Disable colors if supported

        import shutil
        axiomai_bin = shutil.which("axiomai")
        if axiomai_bin:
            command = [axiomai_bin, "chat", "--root", str(self.project_root)]
        else:
            # Fallback: try python -m axiomai (works if installed in same env)
            command = [sys.executable, "-m", "axiomai", "chat", "--root", str(self.project_root)]
        session = _PtySession(command, cwd=REPO_ROOT, env=env)

        if _DEBUG_BRIDGE:
            import sys as _sys
            _sys.stderr.write(f"[bridge] Started axiomai chat, waiting for prompt...\n")

        try:
            self._session = session
            self._read_until_prompt(timeout=240.0)
            # Start a fresh chat session so old conversation history doesn't bleed in
            session.write("new\n")
            self._read_until_prompt(timeout=30.0)
            self._select_model_by_parsing_list(model_id)
        except Exception:
            session.terminate()
            self._session = None
            raise

        self._active_model_id = model_id
        if _DEBUG_BRIDGE:
            import sys as _sys
            _sys.stderr.write(f"[bridge] Session ready, model={model_id}\n")

    def _extract_raw_text(self, text: str) -> str:
        cleaned = _strip_ansi(text)
        begin = cleaned.find(RAW_BEGIN)
        end = cleaned.find(RAW_END)
        if begin == -1 or end == -1 or end <= begin:
            return cleaned.strip()

        return cleaned[begin + len(RAW_BEGIN):end].strip()

    def _extract_last_block(self, text: str) -> str:
        cleaned = _strip_ansi(text).strip()
        if not cleaned:
            return ""
        blocks = [block.strip() for block in cleaned.split("\n\n") if block.strip()]
        return blocks[-1] if blocks else cleaned


class BridgePool:
    """Manages a pool of AxiomCliBridge instances for concurrency and multi-project support."""

    def __init__(self, models: list[dict[str, Any]]) -> None:
        self.models = models
        self._free_bridges: dict[str, list[AxiomCliBridge]] = {}
        self._busy_bridges: dict[str, list[AxiomCliBridge]] = {}
        self._lock = threading.Lock()

    def acquire(self, project_root: Path) -> AxiomCliBridge:
        root_str = str(project_root.resolve())
        with self._lock:
            if root_str not in self._free_bridges:
                self._free_bridges[root_str] = []
            if root_str not in self._busy_bridges:
                self._busy_bridges[root_str] = []

            if self._free_bridges[root_str]:
                bridge = self._free_bridges[root_str].pop()
            else:
                bridge = AxiomCliBridge(project_root=project_root, models=self.models)

            self._busy_bridges[root_str].append(bridge)
            return bridge

    def release(self, bridge: AxiomCliBridge) -> None:
        root_str = str(bridge.project_root.resolve())
        with self._lock:
            if root_str in self._busy_bridges and bridge in self._busy_bridges[root_str]:
                self._busy_bridges[root_str].remove(bridge)
                self._free_bridges[root_str].append(bridge)

    def interrupt_project(self, project_root: Path) -> int:
        """Interrupt all currently busy bridges for a specific project. Returns count interrupted."""
        root_str = str(project_root.resolve())
        count = 0
        with self._lock:
            busy_list = self._busy_bridges.get(root_str, [])
            # Make a copy to safely iterate while sending interrupts
            bridges_to_interrupt = list(busy_list)
            
        for bridge in bridges_to_interrupt:
            bridge.interrupt()
            count += 1
            
        return count

    def shutdown(self) -> None:
        """Terminate all sessions."""
        with self._lock:
            for bridge_list in self._free_bridges.values():
                for bridge in bridge_list:
                    bridge.reset()
            for bridge_list in self._busy_bridges.values():
                for bridge in bridge_list:
                    bridge.reset()
            self._free_bridges.clear()
            self._busy_bridges.clear()
