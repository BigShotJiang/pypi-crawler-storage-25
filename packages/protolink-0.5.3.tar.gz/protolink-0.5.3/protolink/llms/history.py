from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import uuid4


class LLMMessageRole(str, Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"


@dataclass(slots=True)
class LLMMessage:
    """
    Canonical message format used internally across all LLM providers.
    """

    role: LLMMessageRole
    content: str

    # Optional but strongly recommended
    name: str | None = None  # tool name / function name
    metadata: dict[str, Any] = field(default_factory=dict)

    # Observability & tracing
    id: str = field(default_factory=lambda: str(uuid4()))
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    # provider specific fields
    tool_calls: dict[str, Any] = field(default_factory=dict)
    tool_name: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert message to a JSON-serializable dictionary."""
        return {
            "role": self.role.value,
            "content": self.content,
            "name": self.name,
            "metadata": self.metadata,
            "id": self.id,
            "created_at": self.created_at.isoformat(),
            "tool_calls": self.tool_calls,
            "tool_name": self.tool_name,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LLMMessage:
        """Create a message from a dictionary."""
        return cls(
            role=LLMMessageRole(data["role"]),
            content=data["content"],
            name=data.get("name"),
            metadata=data.get("metadata", {}),
            id=data.get("id", str(uuid4())),
            created_at=datetime.fromisoformat(data["created_at"])
            if "created_at" in data
            else datetime.now(timezone.utc),
            tool_calls=data.get("tool_calls", {}),
            tool_name=data.get("tool_name"),
        )


class ConversationHistory:
    """
    Manages conversation state in a provider-agnostic way.
    """

    __slots__ = ("_messages",)

    def __init__(self, system_prompt: str | None = None):
        self._messages: list[LLMMessage] = []
        if system_prompt:
            self.add_system(system_prompt)

    # ----------------------------------------------------------------------
    # append helpers
    # ----------------------------------------------------------------------

    def add_system(self, content: str) -> None:
        self._messages.append(
            LLMMessage(
                role=LLMMessageRole.SYSTEM,
                content=content,
            )
        )

    def add_user(self, content: str, **metadata: Any) -> None:
        self._messages.append(
            LLMMessage(
                role=LLMMessageRole.USER,
                content=content,
                metadata=metadata,
            )
        )

    def add_assistant(self, content: str, **metadata: Any) -> None:
        self._messages.append(
            LLMMessage(
                role=LLMMessageRole.ASSISTANT,
                content=content,
                metadata=metadata,
            )
        )

    def add_tool(
        self,
        content: str,
        tool_name: str,
        **metadata: Any,
    ) -> None:
        self._messages.append(
            LLMMessage(
                role=LLMMessageRole.TOOL,
                content=content,
                name=tool_name,
                metadata=metadata,
            )
        )

    def add_raw(self, message: dict[str, Any]) -> None:
        """Add a raw message to the conversation history."""
        self._messages.append(
            LLMMessage(
                role=LLMMessageRole(message["role"]),
                content=message.get("content", ""),
                tool_calls=message.get("tool_calls", {}),
            )
        )

    def reset_to_system(self, content: str) -> None:
        """Reset the conversation history to only include the system prompt."""
        self._messages = [
            LLMMessage(
                role=LLMMessageRole.SYSTEM,
                content=content,
            )
        ]

    def set_system(self, content: str) -> None:
        """Set or update the system prompt without wiping the rest of the history.
        If a system message exists at the beginning, it is updated.
        Otherwise, a new system message is prepended.
        """
        if self._messages and self._messages[0].role == LLMMessageRole.SYSTEM:
            self._messages[0] = LLMMessage(
                role=LLMMessageRole.SYSTEM,
                content=content,
            )
        else:
            self._messages.insert(
                0,
                LLMMessage(
                    role=LLMMessageRole.SYSTEM,
                    content=content,
                ),
            )

    # ----------------------------------------------------------------------
    # accessors
    # ----------------------------------------------------------------------

    def messages_raw(self) -> list[LLMMessage]:
        """Return a shallow copy to prevent mutation."""
        return list(self._messages)

    @property
    def messages(self) -> list[dict[str, Any]]:
        """Convert messages to standard LLM readable format.

        Returns:
            List of dictionaries in the format expected by most LLM APIs:
            [{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]
        """
        return [
            {"role": msg.role.value, "content": msg.content, **({"name": msg.name} if msg.name else {})}
            for msg in self._messages
        ]

    def to_list(self) -> list[dict[str, Any]]:
        """Convert entire history to a list of full message dictionaries."""
        return [msg.to_dict() for msg in self._messages]

    @classmethod
    def from_list(cls, messages_data: list[dict[str, Any]]) -> ConversationHistory:
        """Create a history instance from a list of full message dictionaries."""
        history = cls()
        history._messages = [LLMMessage.from_dict(m) for m in messages_data]
        return history

    def __iter__(self) -> Iterable[LLMMessage]:
        return iter(self._messages)

    def __len__(self) -> int:
        return len(self._messages)

    # ----------------------------------------------------------------------
    # advanced controls
    # ----------------------------------------------------------------------

    def truncate(self, max_messages: int) -> None:
        """
        Truncate history while ALWAYS preserving the system prompt.
        """
        if max_messages < 2:
            raise ValueError("max_messages must be >= 2")

        system = self._messages[0]
        rest = self._messages[1:][-(max_messages - 1) :]
        self._messages = [system, *rest]
