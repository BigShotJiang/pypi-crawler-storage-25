"""Official ManyWe project bootstrap placeholder package reserved on PyPI."""

__all__ = ["PACKAGE_NAME", "__version__", "placeholder_notice"]

PACKAGE_NAME = "create-manywe"
__version__ = "0.0.1"

def placeholder_notice() -> str:
    return (
        "create-manywe is an official ManyWe placeholder package on PyPI. "
        "The public Python implementation is not available yet."
    )
