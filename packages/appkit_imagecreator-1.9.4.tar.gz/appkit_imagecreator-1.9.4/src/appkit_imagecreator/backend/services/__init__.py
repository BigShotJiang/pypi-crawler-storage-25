"""Image creator backend services."""
