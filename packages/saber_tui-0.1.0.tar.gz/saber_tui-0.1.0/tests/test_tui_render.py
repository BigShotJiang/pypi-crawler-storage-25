from saber_tui.tui import CURSOR_MARKER, TUI
from tests.virtual_terminal import VirtualTerminal


class StaticComponent:
    def __init__(self, lines: list[str]) -> None:
        self.lines = lines

    def render(self, width: int) -> list[str]:
        return self.lines

    def invalidate(self) -> None:
        return None


class CountingComponent(StaticComponent):
    def __init__(self, lines: list[str]) -> None:
        super().__init__(lines)
        self.render_calls = 0

    def render(self, width: int) -> list[str]:
        self.render_calls += 1
        return super().render(width)


def test_request_render_is_scheduled_until_flush() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    component = StaticComponent(["one"])
    tui = TUI(terminal)
    tui.add_child(component)
    tui.start()
    tui.flush_render()
    terminal.clear_writes()

    component.lines = ["two"]
    tui.request_render()

    assert terminal.get_viewport()[0] == "one"
    tui.flush_render()
    assert terminal.get_viewport()[0] == "two"


def test_multiple_request_render_calls_coalesce_to_one_render() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    component = CountingComponent(["one"])
    tui = TUI(terminal)
    tui.add_child(component)
    tui.start()
    tui.flush_render()
    component.render_calls = 0

    component.lines = ["two"]
    tui.request_render()
    component.lines = ["three"]
    tui.request_render()
    tui.flush_render()

    assert component.render_calls == 1
    assert terminal.get_viewport()[0] == "three"


def test_start_renders_children() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    tui = TUI(terminal)
    tui.add_child(StaticComponent(["hello", "world"]))

    tui.start()

    assert terminal.get_viewport()[0] == "hello"
    assert terminal.get_viewport()[1] == "world"


def test_request_render_updates_changed_line() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    component = StaticComponent(["one"])
    tui = TUI(terminal)
    tui.add_child(component)
    tui.start()
    terminal.clear_writes()

    component.lines = ["two"]
    tui.request_render()
    tui.flush_render()

    assert terminal.get_viewport()[0] == "two"
    assert any("two" in write for write in terminal.writes)


def test_incremental_offscreen_change_preserves_visible_viewport() -> None:
    terminal = VirtualTerminal(columns=20, rows=3)
    component = StaticComponent(["offscreen", "visible 1", "visible 2", "visible 3"])
    tui = TUI(terminal)
    tui.add_child(component)
    tui.start()
    terminal.clear_writes()

    component.lines = ["changed offscreen", "visible 1", "visible 2", "visible 3"]
    tui.request_render()

    assert terminal.get_viewport() == ["visible 1", "visible 2", "visible 3"]
    assert "changed offscreen" not in "\n".join(terminal.get_viewport())


def test_appending_below_viewport_scrolls_without_full_clear() -> None:
    terminal = VirtualTerminal(columns=20, rows=3)
    component = StaticComponent(["one", "two", "three"])
    tui = TUI(terminal)
    tui.add_child(component)
    tui.start()
    terminal.clear_writes()

    component.lines = ["one", "two", "three", "four"]
    tui.request_render()
    tui.flush_render()

    assert terminal.get_viewport() == ["two", "three", "four"]
    assert not any("\x1b[2J" in write for write in terminal.writes)


def test_mixed_edit_and_append_scrolls_terminal_instead_of_rewriting_viewport() -> None:
    terminal = VirtualTerminal(columns=20, rows=4)
    component = StaticComponent(["header", "old 1", "old 2", "old 3", "input: x", "footer"])
    tui = TUI(terminal)
    tui.add_child(component)
    tui.start()
    terminal.clear_writes()

    component.lines = ["header", "old 1", "old 2", "old 3", "input:", "footer", "new 1", "new 2"]
    tui.request_render()
    tui.flush_render()

    assert terminal.get_viewport() == ["input:", "footer", "new 1", "new 2"]
    joined = "".join(terminal.writes)
    assert "\x1b[1;1H" not in joined
    assert "\r\n" in joined


def test_deleting_trailing_lines_moves_viewport_without_full_clear() -> None:
    terminal = VirtualTerminal(columns=20, rows=3)
    component = StaticComponent(["one", "two", "three", "four"])
    tui = TUI(terminal)
    tui.add_child(component)
    tui.start()
    terminal.clear_writes()

    component.lines = ["one", "two", "three"]
    tui.request_render()
    tui.flush_render()

    assert terminal.get_viewport() == ["one", "two", "three"]
    assert not any("\x1b[2J" in write for write in terminal.writes)


def test_clear_on_shrink_full_clears_stale_work_area() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    component = StaticComponent(["one", "two", "three"])
    tui = TUI(terminal)
    tui.set_clear_on_shrink(True)
    tui.add_child(component)
    tui.start()
    terminal.clear_writes()

    component.lines = ["one"]
    tui.request_render()
    tui.flush_render()

    assert terminal.get_viewport()[0] == "one"
    assert any("\x1b[2J\x1b[H\x1b[3J" in write for write in terminal.writes)


def test_cursor_marker_is_stripped_from_output() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    tui = TUI(terminal, show_hardware_cursor=True)
    tui.add_child(StaticComponent([f"ab{CURSOR_MARKER}cd"]))

    tui.start()

    assert CURSOR_MARKER not in "\n".join(terminal.get_viewport())


def test_hardware_cursor_position_respects_existing_terminal_rows() -> None:
    terminal = VirtualTerminal(columns=20, rows=8)
    terminal.write("shell prompt\r\n")
    tui = TUI(terminal, show_hardware_cursor=True)
    tui.add_child(StaticComponent(["header", "body", f"edit:{CURSOR_MARKER}", "footer"]))

    tui.start()

    assert terminal.get_viewport()[3].startswith("edit:")
    assert terminal._screen.cursor.x == 5
    assert terminal._screen.cursor.y == 3


def test_cursor_marker_above_viewport_is_stripped_from_writes() -> None:
    terminal = VirtualTerminal(columns=20, rows=3)
    tui = TUI(terminal, show_hardware_cursor=True)
    tui.add_child(StaticComponent([f"hidden{CURSOR_MARKER}", "line 2", "line 3", "line 4"]))

    tui.start()

    assert CURSOR_MARKER not in "".join(terminal.writes)
    assert CURSOR_MARKER not in "\n".join(terminal.get_viewport())


def test_first_render_does_not_clear_screen() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    tui = TUI(terminal)
    tui.add_child(StaticComponent(["hello"]))

    tui.start()

    assert not any("\x1b[2J\x1b[H" in write for write in terminal.writes)


def test_forced_render_still_clears_screen() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    tui = TUI(terminal)
    tui.add_child(StaticComponent(["hello"]))
    tui.start()
    terminal.clear_writes()

    tui.request_render(force=True)
    tui.flush_render()

    assert any("\x1b[2J\x1b[H\x1b[3J" in write for write in terminal.writes)


def test_clear_on_shrink_can_be_configured() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    tui = TUI(terminal)

    assert tui.get_clear_on_shrink() is False
    tui.set_clear_on_shrink(True)
    assert tui.get_clear_on_shrink() is True
    tui.set_clear_on_shrink(False)
    assert tui.get_clear_on_shrink() is False


def test_hardware_cursor_can_be_toggled_at_runtime() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    tui = TUI(terminal)
    tui.add_child(StaticComponent([f"ab{CURSOR_MARKER}cd"]))
    tui.start()
    terminal.clear_writes()

    assert tui.get_show_hardware_cursor() is False
    tui.set_show_hardware_cursor(True)
    tui.flush_render()

    assert tui.get_show_hardware_cursor() is True
    assert "\x1b[3G" in terminal.writes
    assert terminal.writes[-1] == "\x1b[?25h"

    terminal.clear_writes()
    tui.set_show_hardware_cursor(False)

    assert tui.get_show_hardware_cursor() is False
    assert terminal.writes == ("\x1b[?25l",)


def test_stop_cancels_pending_render_and_places_cursor_after_content() -> None:
    terminal = VirtualTerminal(columns=20, rows=5)
    component = StaticComponent(["one", "two"])
    tui = TUI(terminal)
    tui.add_child(component)
    tui.start()
    terminal.clear_writes()

    component.lines = ["changed"]
    tui.request_render()
    tui.stop()

    joined = "".join(terminal.writes)
    assert "changed" not in joined
    assert "\r\n" in joined
    assert "\x1b[?25h" in joined


def test_debug_redraw_log_records_full_redraw(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("SABER_TUI_DEBUG_REDRAW", "1")
    monkeypatch.setenv("SABER_TUI_DEBUG_DIR", str(tmp_path))
    terminal = VirtualTerminal(columns=20, rows=5)
    tui = TUI(terminal)
    tui.add_child(StaticComponent(["hello"]))
    tui.start()

    tui.request_render(force=True)
    tui.flush_render()

    log_path = tmp_path / "saber-tui-debug.log"
    assert log_path.read_text(encoding="utf-8").count("fullRender") >= 1


def test_overwide_render_writes_crash_log(monkeypatch, tmp_path) -> None:
    monkeypatch.setenv("SABER_TUI_DEBUG_DIR", str(tmp_path))
    terminal = VirtualTerminal(columns=5, rows=5)
    tui = TUI(terminal)
    tui.add_child(StaticComponent(["too wide"]))

    try:
        tui.start()
    except ValueError as error:
        assert "Rendered line exceeds terminal width" in str(error)
    else:
        raise AssertionError("expected overwide render to fail")

    crash_log = tmp_path / "saber-tui-crash.log"
    assert "too wide" in crash_log.read_text(encoding="utf-8")
