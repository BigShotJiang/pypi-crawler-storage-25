"""
antaris-suite — Complete AI memory, routing, safety, and context management suite.

Quick start:
    pip install antaris-suite          # core
    pip install antaris-suite[mcp]     # + MCP server tools
    pip install antaris-suite[pro]     # + MCP + semantic search

Usage:
    from parsica_memory import MemorySystem
    from antaris_guard import PromptGuard
    from antaris_context import ContextManager
"""

__version__ = "5.5.0"
