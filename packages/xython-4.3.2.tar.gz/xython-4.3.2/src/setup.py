# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name='xython',
    version='4.3.0',
    url='https://www.xython.co.kr',
    install_requires=[
        "screeninfo",
        "pyperclip",
        "pywinauto",
        "psutil",
        "pywin32",
        "PyGetWindow",
        "pyautogui",
        "matplotlib",
        "folium",
        "arrow",
        "korean-lunar-calendar",
        "python-dateutil",
        "selenium",
    ],
    download_url='https://github.com/sjpark/xython/archive/v4.3.0.tar.gz',
    author='s.j.park',
    author_email='sjpkorea@naver.com',
    description="win32com + python + Office Automation = xython",
    packages=find_packages("src"),
    package_dir={"": "src"},
    include_package_data=True,
    package_data={
        "xython": ["*.*"],
    },
    long_description_content_type="text/markdown",
    long_description=open('README.md', "r", encoding='UTF8').read(),
    python_requires='>=3.8',
    zip_safe=False,
    classifiers=[
        'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
    ],
    project_urls={
        'Documentation': 'https://sjpkorea.github.io/xython.github.io/',
        'Link 1': 'https://www.xython.co.kr',
    }
)