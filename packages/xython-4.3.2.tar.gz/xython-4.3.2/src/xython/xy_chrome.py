import copy
from html.parser import HTMLParser
from xython import xy_util, xy_excel, xy_re
import os
import time

from DrissionPage import ChromiumPage, ChromiumOptions
from DrissionPage.common import By
from DrissionPage.common import Actions, Keys


class TableParser(HTMLParser):
    def __init__(self):
        # convert_charrefs=True 로 HTML 엔티티 자동 변환 (html.unescape 이중 처리 불필요)
        super().__init__(convert_charrefs=True)
        self.tables = []
        self.current_table = []
        self.current_row = []
        self.current_cell = []
        self.in_table = False
        self.in_row = False
        self.in_cell = False

    def handle_starttag(self, tag, attrs):
        if tag == 'table':
            self.in_table = True
            self.current_table = []
        elif tag == 'tr' and self.in_table:
            self.in_row = True
            self.current_row = []
        elif tag in ['td', 'th'] and self.in_row:
            self.in_cell = True
            self.current_cell = []

    def handle_endtag(self, tag):
        if tag == 'table' and self.in_table:
            if self.current_table:
                self.tables.append(self.current_table)
            self.in_table = False
            self.current_table = []
        elif tag == 'tr' and self.in_row:
            if self.current_row:
                self.current_table.append(self.current_row)
            self.in_row = False
            self.current_row = []
        elif tag in ['td', 'th'] and self.in_cell:
            cell_text = ''.join(self.current_cell).strip()
            self.current_row.append(cell_text)
            self.in_cell = False
            self.current_cell = []

    def handle_data(self, data):
        if self.in_cell:
            self.current_cell.append(data)

class xy_chrome:
    """
    drissionpage - subprocess 제거 및 네이티브 실행 방식으로 변경
    디버그 모드 크롬 자동 감지 및 연결
    """

    def __init__(self, url=None, port=9222, auto_connect=True):
        """
        url: 열 URL (기본값: None)
        port: 디버그 포트 (기본값: 9222)
        auto_connect: True = 자동으로 연결/실행, False = 수동
        """
        # 공통 변수 설정
        self.xyutil = xy_util.xy_util()
        self.xyre = xy_re.xy_re()

        self.chrome_paths = self._find_chrome_paths()

        self.port = port
        self.url = url
        if self.url and not self.url.startswith(('http://', 'https://')):
            self.url = 'https://' + self.url
        self.browser = None
        self.page = None        # [FIX] self.page 미초기화 문제 해결 — __init__에서 명시적으로 None 설정
        self.tab_obj = None
        self.new_browser_opened = False  # [FIX] 오타 수정: "opend" → "opened"

        # 자동 연결
        if auto_connect:
            self.connect_or_start()

    @property
    def _active(self) -> ChromiumPage:
        """
        [FIX] self.page / self.browser 혼용 문제 해결용 프로퍼티.
        self.page 가 설정되어 있으면 그것을, 아니면 self.browser 를 반환한다.
        click_by_text_2, click_by_xpath_1, click_by_full_css_path,
        close_all_popups_1, get_all_title_for_tab_1, get_caret_position 등
        기존에 self.page 를 참조하던 메서드들이 이 프로퍼티를 통해 안전하게 동작한다.
        """
        return self.page if self.page is not None else self.browser

    @staticmethod
    def _find_chrome_paths() -> list:
        """
        시스템에서 Chrome 실행 파일 경로를 자동으로 탐색합니다.
        1) 레지스트리(Windows)에서 설치 경로 읽기
        2) 일반적인 설치 경로 목록 확인
        3) PATH 환경 변수에서 chrome / google-chrome 탐색
        """
        candidates = []

        # ── 1. Windows 레지스트리 탐색 ──────────────────────────
        try:
            import winreg
            reg_keys = [
                (winreg.HKEY_LOCAL_MACHINE,
                 r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"),
                (winreg.HKEY_CURRENT_USER,
                 r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe"),
            ]
            for hive, subkey in reg_keys:
                try:
                    with winreg.OpenKey(hive, subkey) as key:
                        path, _ = winreg.QueryValueEx(key, "")
                        if path and os.path.isfile(path):
                            candidates.append(path)
                except FileNotFoundError:
                    pass
        except ImportError:
            pass  # Windows 가 아닌 환경

        # ── 2. 고정 경로 목록 (Windows / macOS / Linux) ─────────
        fixed_paths = [
            # Windows
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
            os.path.expandvars(r"%PROGRAMFILES(X86)%\Google\Chrome\Application\chrome.exe"),
            # macOS
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            # Linux
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium-browser",
            "/usr/bin/chromium",
            "/snap/bin/chromium",
        ]
        for p in fixed_paths:
            if os.path.isfile(p):
                candidates.append(p)

        # ── 3. PATH 환경 변수 탐색 ──────────────────────────────
        import shutil
        for name in ("chrome", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
            found = shutil.which(name)
            if found:
                candidates.append(found)

        # 중복 제거, 순서 유지
        seen = set()
        result = []
        for p in candidates:
            if p not in seen:
                seen.add(p)
                result.append(p)

        if result:
            print(f"✓ Chrome 경로 발견: {result[0]}")
        else:
            print("⚠ Chrome 경로를 자동으로 찾지 못했습니다. DrissionPage 기본값으로 시도합니다.")

        return result

    def is_debug_chrome_running(self, port=None):
        """디버그 모드 크롬이 실행 중인지 확인"""
        if port is None:
            port = self.port
        try:
            import socket
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex(('127.0.0.1', port))
            sock.close()
            return result == 0
        except Exception as e:
            print(f"포트 확인 실패: {e}")
            return False

    def connect_opened_chrome(self, port=None):
        """열려있는 디버그 크롬에 연결"""
        if port is None:
            port = self.port
        try:
            self.browser = ChromiumPage(addr_or_opts=f'127.0.0.1:{port}')
            self.page = self.browser   # [FIX] 연결 시 self.page 도 동기화
            print(f"✓ 기존 디버그 크롬에 연결 성공!")
            return self.browser
        except Exception as e:
            print(f"✗ 연결 실패: {e}")
            return None

    def connect_or_start(self, port=None):
        """디버그 크롬이 있으면 연결, 없으면 새로 실행"""
        if port is None:
            port = self.port

        if self.is_debug_chrome_running(port):
            print(f"✓ 디버그 크롬 발견! (포트 {port})\n")
            self.browser = self.connect_opened_chrome(port)
            if self.browser:
                return self.browser
            else:
                print(f"연결 실패, 새로 실행합니다...\n")
        else:
            print(f"디버그 크롬 없음 (포트 {port})\n")

        self.browser = self.start(port)
        self.new_browser_opened = True

        if self.url and self.browser:
            print(f"URL로 이동: {self.url}")
            self.browser.get(self.url)

        return self.browser

    def start(self, port=None):
        """ChromiumOptions를 사용해 안전하게 Chrome 실행"""
        if port is None:
            port = self.port

        co = ChromiumOptions()
        co.set_local_port(port)
        co.set_user_data_path(r'C:\chrome_debug_temp')

        # Chrome 경로가 발견된 경우에만 명시적으로 지정
        # 없으면 DrissionPage 가 알아서 시스템 Chrome 을 탐색
        if self.chrome_paths:
            chrome_exe = self.chrome_paths[0]
            print(f"크롬 경로: {chrome_exe}\n")
            co.set_browser_path(chrome_exe)
        else:
            print("크롬 경로를 직접 찾지 못해 DrissionPage 기본 탐색을 사용합니다.\n")

        co.set_argument('--start-maximized')
        co.set_argument('--ignore-certificate-errors')
        co.set_argument('--allow-running-insecure-content')
        co.set_argument('--disable-web-security')
        co.set_argument('--ignore-ssl-errors')
        co.set_argument('--disable-features=InsecureFormSubmissionWarning')
        co.set_argument('--disable-popup-blocking')

        self.browser = ChromiumPage(co)
        self.page = self.browser
        print(f"✓ 새 크롬 실행 성공!")
        return self.browser

    def run_chrome(self, headless: bool = False) -> ChromiumPage:
        """
        일반 모드로 Chrome 브라우저를 실행합니다.
        Args: headless: True 이면 headless 모드로 실행
        Returns: ChromiumPage 인스턴스
        """
        options = ChromiumOptions()
        if headless:
            options.headless()
        self.page = ChromiumPage(options)
        self.browser = self.page   # [FIX] run_chrome 호출 시 self.browser 도 동기화
        return self.page

    def close(self):
        """브라우저 완전히 종료"""
        if self.browser:
            self.browser.quit()

    def check_tab(self, input_value=None):
        """
        조건에 따라 탭 반환
            input_value: "active" = 현재 활성 탭
                         None / "" = 화면에 보이는 탭
                         int       = 인덱스로 탭 선택 (0-based)
                         str       = 제목으로 탭 검색
        """
        try:
            if input_value == "pass":
                return self.tab_obj

            elif input_value == "active" or input_value == "activate" :
                print(f"✓ 현재 활성 탭 선택")
                self.tab_obj = self.browser.get_tab()
                return self.tab_obj

            elif input_value == "" or input_value is None:
                # [FIX] 보이는 탭이 없을 경우 return None 명시
                tabs = self.browser.get_tabs()
                for tab in tabs:
                    is_visible = tab.run_js("return document.visibilityState === 'visible'")
                    if is_visible:
                        self.tab_obj = tab
                        return self.tab_obj
                print("✗ 화면에 보이는 탭을 찾을 수 없습니다.")
                return None

            elif isinstance(input_value, int):
                tabs = self.browser.get_tabs()
                if 0 <= input_value < len(tabs):
                    print(f"✓ 탭 선택 (인덱스: {input_value})")
                    self.tab_obj = tabs[input_value]
                    return self.tab_obj
                else:
                    print(f"✗ 인덱스 범위 초과 (0~{len(tabs) - 1})")
                    return None

            elif isinstance(input_value, str):
                tabs = self.browser.get_tabs()
                for tab in tabs:
                    if input_value.lower() in tab.title.lower():
                        self.tab_obj = tab
                        return self.tab_obj
                print(f"✗ '{input_value}' 제목을 가진 탭을 찾을 수 없습니다.")
                return None

        except Exception as e:
            print(f"✗ 탭 가져오기 실패: {e}")
            return None

    def switch_to_latest_tab(self):
        """가장 최근에 열린 탭으로 전환"""
        try:
            if hasattr(self.browser, 'latest_tab'):
                self.browser.latest_tab.set_tab()
                print(f"✓ 최신 탭으로 전환됨")
                return True
        except Exception:
            pass

        try:
            tab_count = len(self.browser.tabs)
            if tab_count > 1:
                self.browser.tabs[-1].set_tab()
                print(f"✓ 마지막 탭으로 전환 (총 {tab_count}개)")
                return True
        except Exception:
            pass

        try:
            tabs = self.browser.get_tabs()
            if len(tabs) > 1:
                self.browser.set_tab(tabs[-1])
                print(f"✓ 탭 전환 완료")
                return True
        except Exception:
            pass

        return False

    def get_visible_tab(self):
        """현재 화면에 보이는 탭 반환"""
        tabs = self.browser.get_tabs()
        for tab in tabs:
            try:
                is_visible = tab.run_js("return document.visibilityState === 'visible'")
                if is_visible:
                    return tab
            except Exception:
                continue
        return None

    def get_title(self, tab_name):
        self.check_tab(tab_name)
        return self.tab_obj.title

    def get_all_title_for_tab(self):
        result = []
        for tab_id in self.browser.tab_ids:
            tab = self.browser.get_tab(tab_id)
            result.append(tab.title)
        return result

    def get_all_title_for_tab_1(self):
        """
        현재 브라우저에 열린 모든 탭의 제목과 URL 을 반환합니다.
        Returns:
            [{"index": 0, "title": "...", "url": "..."}, ...]
        """
        tabs_info = []
        tabs = self._active.get_tabs()  # [FIX] self.page → self._active

        for idx, tab in enumerate(tabs):
            try:
                title = tab.title
                url   = tab.url
            except Exception as e:
                title = f"(읽기 오류: {e})"
                url   = ""
            tabs_info.append({"index": idx, "title": title, "url": url})
            print(f"  탭[{idx}]  제목: {title}  URL: {url}")

        return tabs_info

    def get_activate_tab_by_title(self, keyword, input_text):
        """
        열려있는 모든 탭 중, 제목에 keyword 가 포함된 탭을 찾아 활성화 후 버튼 클릭
        """
        tabs = self.browser.get_tabs()

        for i, tab in enumerate(tabs):
            # [FIX] current_tab 변수 제거 (사용하지 않던 불필요한 get_tab(i) 호출 제거)
            time.sleep(0.1)
            tab.set.activate()
            print(f"현재 활성화 : {tab.title}")

            if keyword.lower() in tab.title.lower():
                print(f"찾음 [{i}] ==> {tab.title}")
                target_button = tab.ele(f'text={input_text}')
                target_button.click()
                print(f"✓ 활성화 완료: {tab.title}")
                print(f"✓ 현재 URL: {tab.url}")
                return True

        print(f"✗ '{keyword}'를 포함한 탭을 찾지 못했습니다.")
        return False

    def select_last_tab(self):
        # [FIX] 외부 page 인자 제거 → self.browser 사용으로 통일
        tabs = self.browser.get_tabs()
        return tabs[-1]

    def open_new_tab_by_url(self, tab_name, input_url):
        """현재 탭에서 URL로 이동"""
        self.check_tab(tab_name)
        self.tab_obj.get(input_url)

    def open_new_tab_by_url_1(self, url: str):
        """새로운 탭을 열고 해당 URL로 이동"""
        try:
            new_tab = self.browser.new_tab(url)
            time.sleep(1)
            return new_tab
        except Exception as e:
            print(f"✗ 새 탭 생성 실패: {e}\n")
            return None

    def click_by_text(self, tab_name, input_text):
        self.check_tab(tab_name)
        element = self.tab_obj.ele(f'text:{input_text}')
        if element:
            if element.states.is_displayed:
                try:
                    element.click(by_js=True)
                except Exception:
                    pass

    def click_by_text_1(self, tab_name, input_text):
        self.check_tab(tab_name)
        text_element = self.tab_obj.ele(f'text:{input_text}')
        text_element.click()

    def click_by_text_2(self, text: str, exact: bool = False, timeout: float = 5.0, scroll_to: bool = True) -> bool:
        """
        현재 페이지에서 주어진 텍스트가 포함된 첫 번째 요소를 찾아 클릭합니다.

        Args:
            text     : 찾을 텍스트
            exact    : True 이면 완전 일치, False 이면 부분 일치
            timeout  : 요소 대기 시간(초)
            scroll_to: 클릭 전 요소로 스크롤 여부

        Returns:
            클릭 성공 시 True, 실패 시 False
        """
        try:
            if exact:
                locator = f'xpath://*[normalize-space(text())="{text}"]'
            else:
                locator = f'text:{text}'

            element = self._active.ele(locator, timeout=timeout)  # [FIX] self.page → self._active
            if element is None:
                print(f"[텍스트 검색 실패] '{text}' 를 찾지 못했습니다.")
                return False

            if scroll_to:
                element.scroll.to_see()
                time.sleep(0.3)

            element.click()
            print(f"[텍스트 클릭 성공] '{text}'")
            return True

        except Exception as e:
            print(f"[텍스트 클릭 오류] '{text}' → {e}")
            return False

    def click_by_text_in_iframe(self, tab_name, target_text, iframe_id, search_in_iframe=True, wait_time=1):
        """
        특정 텍스트를 찾아서 클릭

        Args:
            tab_name       : 탭 식별값
            target_text    : 찾을 텍스트
            iframe_id      : iframe ID (iframe 내부를 검색할 경우)
            search_in_iframe: iframe 내부를 검색할지 여부
            wait_time      : 클릭 후 대기 시간
        """
        self.check_tab(tab_name)
        try:
            if search_in_iframe:
                print(f"1. iframe 찾기: {iframe_id}")
                context = self.tab_obj.ele(f'@id={iframe_id}', timeout=0.5)
                if not context:
                    print(f"iframe을 찾을 수 없음, 메인 페이지에서 검색...")
                    context = self.tab_obj
            else:
                context = self.tab_obj

            print(f"2. 텍스트 검색: '{target_text}'")

            try:
                element = context.ele(f'text={target_text}', timeout=1)
                if element:
                    print(f"찾음 (정확한 매칭)")
                    element.click()
                    print("클릭 완료")
                    time.sleep(wait_time)
                    return True
            except Exception as e:
                print(f"방법 1 실패: {e}")

            # [FIX] 방법 1 실패 시 명시적으로 False 반환
            print(f"✗ '{target_text}' 클릭 실패")
            return False

        except Exception as e:
            print(f"오류: {e}")
            import traceback
            traceback.print_exc()
            return False

    def click_by_xpath(self, tab_name, full_xpath):
        self.check_tab(tab_name)
        element = self.tab_obj.ele(f'xpath:{full_xpath}')
        element.click(by_js=True)

    def click_by_xpath_1(self, xpath: str, timeout: float = 5.0, scroll_to: bool = True, index: int = 1) -> bool:
        """
        XPath 로 요소를 찾아 클릭합니다.

        Args:
            xpath    : XPath 문자열 (예: '//button[@id="submit"]')
            timeout  : 요소 대기 시간(초)
            scroll_to: 클릭 전 스크롤 여부
            index    : 동일 XPath 결과가 여러 개일 때 선택할 순번 (1-based)
        """
        try:
            locator = f'xpath:{xpath}'
            if index > 1:
                elements = self._active.eles(locator, timeout=timeout)  # [FIX] self.page → self._active
                if len(elements) < index:
                    print(f"[XPath 클릭 실패] index={index} 이지만 요소가 {len(elements)}개뿐입니다.")
                    return False
                element = elements[index - 1]
            else:
                element = self._active.ele(locator, timeout=timeout)    # [FIX] self.page → self._active

            if element is None:
                print(f"[XPath 클릭 실패] 요소를 찾지 못했습니다: {xpath}")
                return False

            if scroll_to:
                element.scroll.to_see()
                time.sleep(0.3)

            element.click()
            print(f"[XPath 클릭 성공] {xpath}")
            return True

        except Exception as e:
            print(f"[XPath 클릭 오류] {xpath} → {e}")
            return False

    def click_by_xpath_2(self, tab_name, xpath, max_wait=30, check_interval=1):
        """
        요소가 나타날 때까지 기다렸다가 클릭

        Args:
            tab_name      : 탭 식별값
            xpath         : 전체 XPath 경로
            max_wait      : 최대 대기 시간 (초)
            check_interval: 확인 간격 (초)
        """
        self.check_tab(tab_name)
        try:
            start_time = time.time()

            while time.time() - start_time < max_wait:
                try:
                    element = self.tab_obj.ele(f'xpath:{xpath}', timeout=check_interval)
                    if element:
                        element.click()
                        return True
                except Exception:
                    elapsed = int(time.time() - start_time)
                    print(f"   대기 중... ({elapsed}/{max_wait}초)")

            print(f"시간 초과: {max_wait}초 동안 요소를 찾을 수 없음")
            return False

        except Exception as e:
            print(f"오류 발생: {e}")
            return False

    def click_by_xpath_3(self, tab_name, input_xpath):
        self.check_tab(tab_name)
        element = self.tab_obj.ele(f'xpath:{input_xpath}')
        element.click()

    def click_by_id(self, tab_name, element_id):
        self.check_tab(tab_name)
        element = self.tab_obj.ele(f'#{element_id}')
        if element:
            if element.states.is_displayed:
                try:
                    element.click(by_js=True)
                    return True
                except Exception as e:
                    print(f"ID [{element_id}] 클릭 중 에러가 발생했습니다: {e}")
            else:
                print(f"요소를 찾았으나, 현재 화면에 숨겨져 있어 클릭할 수 없습니다.")
        else:
            print(f"화면에서 ID가 [{element_id}]인 요소를 찾을 수 없습니다.")
        return False

    def click_by_full_xpath(self, tab_name, xpath, wait_before_click=0.5, wait_after_click=0.5):
        """
        Full XPath로 요소를 찾아서 클릭

        Args:
            tab_name        : 탭 식별값
            xpath           : 전체 XPath 경로 (예: /html/body/div[1]/div[2]/button)
            wait_before_click: 클릭 전 대기 시간 (초)
            wait_after_click : 클릭 후 대기 시간 (초)
        """
        self.check_tab(tab_name)
        try:
            element = self.tab_obj.ele(f'xpath:{xpath}', timeout=10)

            try:
                tag  = element.tag
                text = element.text[:50] if element.text else ''
                print(f"요소 확인: <{tag}> '{text}'")
            except Exception:
                pass

            if wait_before_click > 0:
                time.sleep(wait_before_click)

            element.click()
            print(f"클릭 완료!")

            if wait_after_click > 0:
                time.sleep(wait_after_click)

            return True

        except Exception as e:
            print(f"오류 발생: {e}")
            import traceback
            traceback.print_exc()
            return False

    def click_by_full_path(self, tab_name, full_xpath):
        self.check_tab(tab_name)
        element = self.tab_obj.ele(f'xpath:{full_xpath}')
        element.click()

    def click_by_full_css_path(self, css_path: str, timeout: float = 5.0, scroll_to: bool = True) -> bool:
        """
        CSS 전체 경로(Full CSS Selector)로 요소를 찾아 클릭합니다.
        Chrome DevTools의 'Copy > Copy selector' 결과를 그대로 사용할 수 있습니다.

        Args:
            css_path : CSS 선택자 전체 경로
                       예: '#app > div.header > nav > ul > li:nth-child(2) > a'
            timeout  : 요소 대기 시간(초)
            scroll_to: 클릭 전 스크롤 여부
        """
        try:
            locator = f'css:{css_path}'
            element = self._active.ele(locator, timeout=timeout)  # [FIX] self.page → self._active

            if element is None:
                print(f"[CSS Path 클릭 실패] 요소를 찾지 못했습니다: {css_path}")
                return False

            if scroll_to:
                element.scroll.to_see()
                time.sleep(0.3)

            element.click()
            print(f"[CSS Path 클릭 성공] {css_path}")
            return True

        except Exception as e:
            print(f"[CSS Path 클릭 오류] {css_path} → {e}")
            return False

    def click_by_class_name(self, tab_name, class_name):
        self.check_tab(tab_name)
        element = self.tab_obj.ele(f'.{class_name}')
        element.click()

    def click_nth_by_class(self, tab_name, class_name, index=1, timeout=3):
        """동일한 클래스를 가진 요소 중 N번째 요소를 클릭하는 함수"""
        self.check_tab(tab_name)
        elements = self.tab_obj.eles(f'.{class_name}', timeout=timeout)

        if not elements:
            print(f"'{class_name}' 클래스를 찾을 수 없습니다.")
            return False

        if len(elements) < index:
            print(f"'{class_name}' 클래스가 {len(elements)}개 밖에 없습니다. ({index}번째 클릭 불가)")
            return False

        elements[index - 1].click()
        print(f"'{class_name}' 클래스의 {index}번째 요소 클릭 성공!")
        return True

    def click_link_and_handle_warning(self, link_selector, wait_time=2):
        """
        링크 클릭 후 보안 경고 자동 처리

        Args:
            link_selector: 클릭할 링크의 선택자
            wait_time    : 경고 팝업 대기 시간 (초)
        """
        try:
            initial_tab_count = len(self.browser.tabs)
            print(f"현재 탭 수: {initial_tab_count}")

            link = self.tab_obj.ele(link_selector, timeout=10)
            if not link:
                print(f"링크를 찾을 수 없음: {link_selector}")
                return False

            print(f"✓ 링크 발견, 클릭 중...")
            link.click()
            time.sleep(wait_time)

            current_tab_count = len(self.browser.tabs)
            print(f"현재 탭 수: {current_tab_count}")

            if current_tab_count > initial_tab_count:
                print("✓ 새 탭이 생성됨")
                self.switch_to_latest_tab()
                time.sleep(0.5)
            else:
                print("새 탭 생성 안됨 (같은 탭에서 열림)")

            self.handle_security_warning(timeout=3)
            return True

        except Exception as e:
            print(f"링크 클릭 중 오류: {e}")
            import traceback
            traceback.print_exc()
            return False

    def safe_click(self, selector, handle_warning=True, wait_time=2):
        """
        안전하게 요소를 클릭하고 보안 경고를 자동 처리

        Args:
            selector      : 클릭할 요소의 선택자
            handle_warning: 보안 경고 자동 처리 여부 (현재 항상 처리)
            wait_time     : 대기 시간
        """
        return self.click_link_and_handle_warning(selector, wait_time)

    def close_all_popups_1(self):
        """
        현재 작업 중인 화면(메인 탭)을 제외한 모든 팝업창(새 탭/새 창)을 닫습니다.
        """
        main_tab_id = self.tab_obj.tab_id
        all_tab_ids = self.browser.tab_ids
        closed_count = 0

        for t_id in all_tab_ids:
            if t_id != main_tab_id:
                self.browser.close_tabs(t_id)
                closed_count += 1

        self.browser.get_tab(main_tab_id)
        print(f"불필요한 팝업(새 창/탭) {closed_count}개를 닫았습니다.")
        return closed_count

    def close_all_popups(self, accept: bool = True) -> int:
        """
        현재 열려 있는 모든 브라우저 팝업(alert / confirm / prompt)을 닫습니다.
        """
        closed = 0
        for _ in range(20):
            try:
                alert = self._active.handle_alert(accept=accept, timeout=0.5)  # [FIX] self.page → self._active
                if alert is None:
                    break
                print(f"[팝업 닫기] 텍스트: '{alert}'  accept={accept}")
                closed += 1
            except Exception:
                break

        if len(self._active.get_tabs()) > 1:  # [FIX] self.page → self._active
            for tab in self._active.get_tabs()[1:]:
                try:
                    tab.close()
                    closed += 1
                    print("[팝업 탭 닫기] 추가 탭 제거")
                except Exception:
                    pass

        print(f"[팝업 닫기 완료] 총 {closed}개 처리")
        return closed

    def close_layer_popups(self):
        """
        페이지 내부에 떠 있는 레이어 팝업(광고, 공지사항 등)을 강제로 찾아 닫습니다.
        """
        close_keywords = [
            'text=오늘 하루 보지 않기',
            'text=다시 보지 않기',
            'text=일주일간 보지 않기',
            'text=닫기',
            '@aria-label=Close',
            '.close',
            '.btn_close',
        ]

        closed_count = 0

        for keyword in close_keywords:
            elements = self.tab_obj.eles(keyword)
            for ele in elements:
                if ele.states.is_displayed:
                    try:
                        ele.click(by_js=True)
                        closed_count += 1
                        time.sleep(0.2)  # [FIX] self.browser.wait(0.2) → time.sleep(0.2) (DrissionPage API 불일치 수정)
                    except Exception:
                        pass

        if closed_count > 0:
            print(f"화면을 가리는 내부 레이어 팝업 {closed_count}개를 찾아 닫았습니다.")

        return closed_count

    def handle_security_warning(self, timeout=5):
        """보안 경고 팝업이 나타나면 자동으로 '무시하고 보내기' 버튼 클릭"""
        try:
            print("보안 경고 확인 중...")
            selectors = [
                "t:무시하고 보내기",
                "text=무시하고 보내기",
                "xpath://button[contains(text(), '무시하고 보내기')]",
                "xpath://input[contains(@value, '무시하고 보내기')]",
                "xpath://*[contains(text(), '무시하고 보내기')]",
                "css:button:contains('무시하고 보내기')",
            ]

            for selector in selectors:
                try:
                    button = self.tab_obj.ele(selector, timeout=timeout)
                    if button:
                        print(f"✓ 버튼 발견: {selector}")
                        button.click()
                        print("✓ '무시하고 보내기' 버튼 클릭 완료")
                        time.sleep(0.5)
                        return True
                except Exception:
                    continue

            print("'무시하고 보내기' 버튼을 찾을 수 없음")
            return False

        except Exception as e:
            print(f"오류 발생: {e}")
            return False

    def write_by_xpath(self, tab_name, input_full_xpath, input_text, enter_tf=False):
        self.check_tab(tab_name)
        element = self.tab_obj.ele(f'xpath:{input_full_xpath}')
        element.input(input_text, clear=True)
        if enter_tf:
            element.input('\n')  # [FIX] element.click() → Enter 키 입력으로 수정

    def write_by_id(self, tab_name, input_id, input_text, enter_tf=False):
        self.check_tab(tab_name)
        element = self.tab_obj.ele(f'#{input_id}')
        element.input(input_text, clear=True)
        if enter_tf:
            element.input('\n')  # [FIX] element.click() → Enter 키 입력으로 수정

    def write_by_id_1(self, tab_name, element_id, text) -> bool:
        """
        ID로 요소를 찾아서 텍스트 입력

        Args:
            tab_name  : 탭 식별값
            element_id: 요소의 id 속성값
            text      : 입력할 텍스트

        Returns:
            bool: 성공 여부
        """
        self.check_tab(tab_name)
        try:
            element = self.tab_obj.ele(f'#{element_id}', timeout=5)

            if not element:
                print(f"요소를 찾을 수 없음 (id: {element_id})")
                return False

            element.clear()
            element.input(text)
            return True  # [FIX] 성공 시 return True 누락 수정

        except Exception as e:
            print(f"오류 발생: {e}")
            return False  # [FIX] 예외 시 return False 누락 수정

    def select_option_by_id_and_index(self, tab_name, select_id, option_index):
        """
        ID로 select 요소를 찾아서 인덱스로 옵션 선택

        Args:
            tab_name    : 탭 식별값
            select_id   : select 요소의 id 속성값
            option_index: 선택할 옵션의 인덱스 (1부터 시작)

        Returns:
            bool: 성공 여부
        """
        self.check_tab(tab_name)
        try:
            print(f"select 요소 찾는 중... (id: {select_id})")
            select_element = self.tab_obj.ele(f'#{select_id}', timeout=5)

            if not select_element:
                print(f"select 요소를 찾을 수 없음 (id: {select_id})")
                return False

            print(f"✓ select 요소 발견!")
            select_element.select(option_index)
            print(f"옵션 선택 완료: {option_index}번째 항목")
            return True

        except Exception as e:
            print(f"오류 발생: {e}")
            import traceback
            traceback.print_exc()
            return False

    def select_option_by_id_and_index_advanced(self, tab_name, select_id, option_index):
        """
        ID로 select 요소를 찾아서 인덱스로 옵션 선택 (고급 버전 - 여러 방법 시도)

        Args:
            tab_name    : 탭 식별값
            select_id   : select 요소의 id 속성값
            option_index: 선택할 옵션의 인덱스 (1부터 시작)

        Returns:
            bool: 성공 여부
        """
        self.check_tab(tab_name)
        try:
            print(f"select 요소 찾는 중... (id: {select_id})")
            select_element = self.tab_obj.ele(f'#{select_id}', timeout=5)

            if not select_element:
                print(f"select 요소를 찾을 수 없음 (id: {select_id})")
                return False

            print(f"✓ select 요소 발견!")

            options = select_element.eles('tag:option')
            print(f"옵션 개수: {len(options)}")

            for i, opt in enumerate(options, 1):
                try:
                    text  = opt.text
                    value = opt.attr('value')
                    print(f"  {i}. text: '{text}', value: '{value}'")
                except Exception:
                    pass

            if option_index < 1 or option_index > len(options):
                print(f"잘못된 인덱스: {option_index} (1~{len(options)} 범위)")
                return False

            try:
                print(f"\n[방법 1] select() 메서드 사용...")
                select_element.select(option_index)
                print(f"  성공!")
                return True
            except Exception as e1:
                print(f"  실패: {e1}")

            try:
                print(f"\n[방법 2] option 직접 클릭...")
                target_option = options[option_index - 1]
                target_option.click()
                print(f"  성공!")
                return True
            except Exception as e2:
                print(f"  실패: {e2}")

            try:
                print(f"\n[방법 3] JavaScript 사용...")
                js_code = f"""
                    var select = document.getElementById('{select_id}');
                    select.selectedIndex = {option_index - 1};
                    select.dispatchEvent(new Event('change', {{ bubbles: true }}));
                """
                self.tab_obj.run_js(js_code)
                print(f"  성공!")
                return True
            except Exception as e3:
                print(f"  실패: {e3}")

            try:
                print(f"\n[방법 4] value로 선택...")
                target_option = options[option_index - 1]
                value = target_option.attr('value')
                select_element.select(value)
                print(f"  성공!")
                return True
            except Exception as e4:
                print(f"  실패: {e4}")

            print("\n모든 방법 실패")
            return False

        except Exception as e:
            print(f"오류 발생: {e}")
            import traceback
            traceback.print_exc()
            return False

    def get_html_code(self, url):
        """
        [FIX] port_* 메서드들이 호출하던 누락된 메서드 추가.
        get_html_code_by_url 의 alias.
        """
        return self.get_html_code_by_url(url)

    def get_html_code_by_url(self, url):
        try:
            self.browser.get(url)
            html_code = self.browser.html
            return html_code
        except Exception as e:
            print(f"에러 발생: {e}")
            return None

    def html_tables_to_list(self, html_string):
        """
        [FIX] port_* 메서드들이 호출하던 누락된 메서드 추가.
        get_table_list_by_html_code 의 alias.
        """
        return self.get_table_list_by_html_code(html_string)

    def get_table_list_by_html_code(self, html_string):
        """
        HTML 문자열에서 모든 테이블을 추출하여 3차원 리스트로 반환.
        convert_charrefs=True 설정으로 HTML 파서가 이미 엔티티를 처리하므로
        html.unescape() 이중 호출 불필요.
        """
        parser = TableParser()
        parser.feed(html_string)
        return parser.tables

    def get_all_tables_by_url(self, url, wait, include_header_tf=True):
        """
        주어진 URL 페이지의 모든 <table> 을 파싱하여 3차원 리스트로 반환합니다.

        구조:
            result[테이블 인덱스][행 인덱스][열 인덱스] = 셀 텍스트

        Args:
            url             : 파싱할 페이지 URL
            wait            : 페이지 로드 후 대기 시간(초)
            include_header_tf: True 이면 <thead> 포함, False 이면 제외

        Returns:
            list[list[list[str]]]
        """
        self.browser.get(url)
        time.sleep(wait)

        incl = "true" if include_header_tf else "false"
        js = f"""
        (() => {{
            const tables   = document.querySelectorAll('table');
            const result   = [];
            const inclHead = {incl};

            tables.forEach(table => {{
                const rows2d = [];
                const trList = inclHead
                    ? table.querySelectorAll('tr')
                    : table.querySelectorAll('tbody tr');

                trList.forEach(tr => {{
                    const cells = [];
                    tr.querySelectorAll('th, td').forEach(cell => {{
                        cells.push(cell.innerText.trim());
                    }});
                    if (cells.length > 0) rows2d.push(cells);
                }});

                if (rows2d.length > 0) result.push(rows2d);
            }});

            return result;
        }})()
        """

        tables_3d: list[list[list[str]]] = self.browser.run_js(js) or []

        print(f"[테이블 추출] URL: {url}")
        print(f"  → 총 {len(tables_3d)}개 테이블 발견")
        for i, table in enumerate(tables_3d):
            print(f"  테이블[{i}]: {len(table)}행 × {max(len(r) for r in table) if table else 0}열")

        return tables_3d

    def get_text_by_copy_action(self, url):
        """URL 접속 후 Ctrl+A로 전체 선택하여 텍스트 데이터를 가져옵니다."""
        try:
            self.browser.get(url)
            self.browser.wait.load_start()
            self.browser.actions.key_down('control').type('a').key_up('control')
            selected_text = self.browser.ele('tag:body').text
            return selected_text
        except Exception as e:
            print(f"오류 발생: {e}")
            return None

    def get_text(self, tab_name, selector):
        """원하는 요소의 텍스트 가져오기"""
        self.check_tab(tab_name)
        element = self.tab_obj.ele(selector)
        if element:
            return element.text
        else:
            return "값을 찾을 수 없습니다."

    def get_mouse_curser_position(self, monitor_width: int = 1920) -> dict:
        """
        현재 마우스 커서 위치를 두 모니터 기준으로 반환합니다.
        의존 패키지: pip install pyautogui
        """
        try:
            import pyautogui
        except ImportError:
            raise ImportError("pyautogui 가 필요합니다: pip install pyautogui")

        x, y = pyautogui.position()
        monitor = 1 if x < monitor_width else 2
        local_x = x if monitor == 1 else x - monitor_width

        info = {"x": x, "y": y, "monitor": monitor, "local_x": local_x, "local_y": y}
        print(f"[마우스 위치] 절대({x}, {y})  →  모니터 {monitor}번  로컬({local_x}, {y})")
        return info

    def get_caret_position(self, monitor_width: int = 1920) -> dict:
        """
        현재 포커스된 input/textarea 요소에서 텍스트 캐럿(|) 위치를 스크린 좌표로 반환합니다.
        포커스된 입력 요소가 없으면 None 반환.
        """
        js = """
        (() => {
            const el = document.activeElement;
            if (!el || (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA')) {
                return null;
            }

            const idx = el.selectionStart ?? 0;

            let vx = 0, vy = 0;
            try {
                const mirror = document.createElement('span');
                const computed = window.getComputedStyle(el);

                ['font', 'fontSize', 'fontFamily', 'fontWeight',
                 'letterSpacing', 'textTransform', 'padding',
                 'border', 'boxSizing'].forEach(p => {
                    mirror.style[p] = computed[p];
                });
                mirror.style.position   = 'absolute';
                mirror.style.visibility = 'hidden';
                mirror.style.whiteSpace = 'pre';
                mirror.textContent = el.value.substring(0, idx) || '\u200b';
                document.body.appendChild(mirror);

                const eRect = el.getBoundingClientRect();
                vx = eRect.left + mirror.scrollWidth;
                vy = eRect.top  + eRect.height / 2;

                document.body.removeChild(mirror);
            } catch(e) {
                const r = el.getBoundingClientRect();
                vx = r.left; vy = r.top;
            }

            return {
                tag        : el.tagName,
                caretIndex : idx,
                viewportX  : Math.round(vx),
                viewportY  : Math.round(vy),
                screenX    : Math.round(vx + window.screenX + window.outerWidth  - window.innerWidth),
                screenY    : Math.round(vy + window.screenY + window.outerHeight - window.innerHeight),
            };
        })()
        """

        result = self._active.run_js(js)  # [FIX] self.page → self._active
        if result is None:
            print("[캐럿 위치] 포커스된 input/textarea 요소가 없습니다.")
            return None

        sx, sy = result["screenX"], result["screenY"]
        monitor = 1 if sx < monitor_width else 2
        local_x = sx if monitor == 1 else sx - monitor_width

        info = {
            "element_tag": result["tag"],
            "caret_index": result["caretIndex"],
            "viewport_x":  result["viewportX"],
            "viewport_y":  result["viewportY"],
            "screen_x": sx,
            "screen_y": sy,
            "monitor":  monitor,
            "local_x":  local_x,
            "local_y":  sy,
        }
        print(
            f"[캐럿 위치] 태그={info['element_tag']}  "
            f"인덱스={info['caret_index']}  "
            f"스크린({sx}, {sy})  →  모니터 {monitor}번  로컬({local_x}, {sy})"
        )
        return info

    def run_js_on_visible_tab(self, js_code):
        """현재 화면에 보이는 탭에서 JavaScript 실행"""
        visible_tab = self.get_visible_tab()
        result = visible_tab.run_js(js_code)
        return result

    def make_list_for_1(self, input_list):
        result = []
        # index 0 = 선사명(신선대), index 10 = 선사명(감만) → 나머지 1~9, 11~19 가 데이터 컬럼
        COMPANY_COL_INDICES = {0, 10}   # [FIX] 매직 넘버 10 → 상수로 명시
        basic_l2d = [
            [],
            ["신선대", "GP/DC",       20], ["신선대", "GP/DC",       40], ["신선대", "OT/UT",       20],
            ["신선대", "OT/UT",       40], ["신선대", "FL/PL/FC/FR", 20], ["신선대", "FL/PL/FC/FR", 40],
            ["신선대", "HQ/HC",       20], ["신선대", "HQ/HC",       40], ["신선대", "HQ/HC",       45],
            [],
            ["감만",   "GP/DC",       20], ["감만",   "GP/DC",       40], ["감만",   "OT/UT",       20],
            ["감만",   "OT/UT",       40], ["감만",   "FL/PL/FC/FR", 20], ["감만",   "FL/PL/FC/FR", 40],
            ["감만",   "HQ/HC",       20], ["감만",   "HQ/HC",       40], ["감만",   "HQ/HC",       45],
        ]
        for l1d in input_list[0][3:]:
            company = None
            for index, value in enumerate(l1d):
                if index in COMPANY_COL_INDICES:
                    company = l1d[index]
                else:
                    temp = copy.deepcopy(basic_l2d[index])
                    temp.append(company)
                    temp.append(l1d[index])
                    result.append(temp)
        return result

    def make_list_7(self, input_list):
        result = []
        basic_l2d = [
            [],
            ["선광신", "DRY", 20],   ["선광신", "DRY", 40],   ["선광신", "DRY", "40H"],
            ["선광신", "DRY", 45],   ["선광신", "RF",  20],   ["선광신", "RF",  40],
            ["선광신", "FR",  20],   ["선광신", "FR",  40],   ["선광신", "OT",  20],
            ["선광신", "OT",  40],   ["선광신", "TK",  20],   ["선광신", "TK",  40],
        ]
        for l1d in input_list[0]:
            company = None
            for index, value in enumerate(l1d):
                if index == 0:
                    company = l1d[index]
                else:
                    temp = copy.deepcopy(basic_l2d[index])
                    temp.append(company)
                    temp.append(l1d[index])
                    result.append(temp)
        return result

    def port_1(self):
        html_code = self.get_html_code("https://info.bptc.co.kr/content/od/frame/yard_new_empty_frame_od_kr.jsp?p_id=EMPT_NE_KR&snb_num=8&snb_div=service&pop_ok=Y")
        l3d = self.html_tables_to_list(html_code)
        result = self.make_list_for_1(l3d)
        self.xyutil.print_one_by_one(result)
        return result

    def port_2(self):
        html_code = self.get_html_code("https://svc.pncport.com/info/Main.do")
        l2d = self.html_tables_to_list(html_code)[0]
        port = "부산신항"
        result = []
        for l1d in l2d[1:]:
            con_size = l1d[0][:2]
            con_type = l1d[0][2:]
            for index, value in enumerate(l1d[1:]):
                result.append([port, con_type, con_size, l2d[0][index + 1], value])
        self.xyutil.print_one_by_one(result)
        return result

    def port_3(self):
        html_code = self.get_html_code("https://www.pnitl.com/infoservice/main/mainPage.jsp")
        l2d = self.html_tables_to_list(html_code)[-1]
        port = "부산신항1"
        result = []
        for l1d in l2d[1:]:
            if len(l1d) > 3:
                for index, value in enumerate(l1d[1:]):
                    con_size = l2d[0][index + 1][:2]
                    con_type = l2d[0][index + 1][2:]
                    result.append([port, con_type, con_size, l1d[0], value])
        self.xyutil.print_one_by_one(result)
        return result

    def port_4(self):
        html_code = self.get_html_code("https://www.hpnt.co.kr/infoservice/main/mainPage.jsp")
        l2d = self.html_tables_to_list(html_code)[-1]
        port = "부산신항2"
        result = []
        for l1d in l2d[1:]:
            if len(l1d) > 3:
                for index, value in enumerate(l1d[1:]):
                    con_size = l2d[0][index + 1][:2]
                    con_type = l2d[0][index + 1][2:]
                    result.append([port, con_type, con_size, l1d[0], value])
        self.xyutil.print_one_by_one(result)
        return result

    def port_5(self):
        html_code = self.get_html_code("http://www.e1ct.co.kr/info/terminal/emptyContainer")
        l2d = self.html_tables_to_list(html_code)[-1]
        print(l2d)
        port = "인천"
        result = []
        for l1d in l2d[1:]:
            if len(l1d) > 3:
                for index, value in enumerate(l1d[1:-1]):
                    con_size = l2d[0][index + 1][:2]
                    con_type = l2d[0][index + 1][2:]
                    result.append([port, con_type, con_size, l1d[0], value])
        self.xyutil.print_one_by_one(result)
        return result

    def port_6(self):
        html_code = self.get_html_code("http://www.gwct.co.kr/e-service")
        l2d = self.html_tables_to_list(html_code)[-1]
        print(l2d)
        port = "광양"
        result = []
        for l1d in l2d[1:]:
            if len(l1d) > 3:
                for index, value in enumerate(l1d[1:]):
                    con_size = l2d[0][index + 1]
                    con_type = ""
                    result.append([port, con_type, con_size, l1d[0], value])
        self.xyutil.print_one_by_one(result)
        return result

    def port_7(self):
        html_code = self.get_html_code("https://snct.sun-kwang.co.kr/infoservice/webpage/main/mainPage_iframe.jsp?type=IFRAME_EMPTY_ALL")
        l2d = self.html_tables_to_list(html_code)[-1]
        result = self.make_list_7(l2d)
        self.xyutil.print_one_by_one(result)
        return result

    def port_9(self):
        self.get_html_code("https://www.hjit.co.kr/kor/Main.do#")
        aaa = "/html/body/div/section[4]/article/div[1]/div[3]"
        element = self._active.ele(f'xpath:{aaa}')  # [FIX] self.page → self._active
        text = element.text
        print(text)
        print(repr(text))
        return text

    def port_10(self):
        code = self.get_text_by_copy_action("https://info.bnctkorea.com/esvc")
        multi_lines = str(code).splitlines()
        time.sleep(1)
        tag = False
        result = []
        l2d = []
        for one_line in multi_lines:
            if tag and str(one_line).startswith("부산시"):
                break
            if str(one_line).startswith("OPR") or tag:
                tag = True
                l2d.append(str(one_line).split("\t"))
        for no in range(1, len(l2d[0])):
            result.append(["style10", l2d[2][no], l2d[1][no], l2d[0][no], l2d[3][no]])
        self.xyutil.print_one_by_one(result)
        return result

    def port_11(self):
        code = self.get_text_by_copy_action("https://www.psa-ict.co.kr/")
        multi_lines = str(code).splitlines()
        time.sleep(1)
        tag = False
        result = []
        l2d = []
        for one_line in multi_lines:
            if tag and str(one_line).startswith("* 컨테이너"):
                break
            if str(one_line).startswith("OPER") or tag:
                tag = True
                l2d.append(str(one_line).split("\t"))
        for l1d in l2d[1:]:
            con_size = l1d[0][:2]
            con_type = l1d[0][2:]
            for index, value in enumerate(l1d[1:]):
                result.append(["style11", con_type, con_size, l2d[0][index + 1], value])
        self.xyutil.print_one_by_one(result)
        return result

    def port_12(self):
        code = self.get_text_by_copy_action("https://info.kitl.com/jsp/T05/banchul_allow.jsp")
        multi_lines = str(code).splitlines()
        print(multi_lines)
        time.sleep(1)
        tag = False
        result = []
        l2d = []
        for one_line in multi_lines:
            if tag and str(one_line).startswith("CFS 접수 안내"):
                break
            # [FIX 1] '20\\t40\\t40HQ\\t45' → '20\t40\t40HQ\t45' (이스케이프 오류 수정)
            if str(one_line).startswith('20\t40\t40HQ\t45') or tag:
                tag = True
                l2d.append(str(one_line).split("\t"))

        # [FIX 2] result에 데이터를 담는 로직 추가 (기존 코드는 l2d만 구성하고 result에 넣지 않음)
        for l1d in l2d[1:]:
            if len(l1d) < 2:
                continue
            for index, value in enumerate(l1d):
                result.append(["style12", "", l2d[0][index] if index < len(l2d[0]) else "", l1d[0], value])

        self.xyutil.print_one_by_one(result)
        return result

    def port_13(self):
        code = self.get_text_by_copy_action("https://www.hjnc.co.kr/esvc")
        multi_lines = str(code).splitlines()
        time.sleep(1)
        tag = False
        result = []
        l2d = []
        for one_line in multi_lines:
            if tag and str(one_line).startswith("선석 작업현황"):
                break
            if str(one_line).startswith("Operator") or tag:
                tag = True
                l2d.append(str(one_line).split("\t"))
        for l1d in l2d[2:]:
            con_size = l1d[0][:2]
            con_type = l1d[0][2:]
            for index, value in enumerate(l1d[1:]):
                # [FIX] 기존: ["style13", "DRY", l2d[1][index], l1d[0], value]
                #       수정: con_size, con_type 을 정상 사용, 선사는 l2d[1][index+1]
                result.append(["style13", con_type, con_size, l2d[1][index + 1] if (index + 1) < len(l2d[1]) else "", value])
        self.xyutil.print_one_by_one(result)
        return result

    def port_15(self):
        self.get_html_code("https://info.bct2-4.com/infoservice/index.html")
        aaa = "/html/body/div[2]/div/div/div[2]/div/div[2]/div/div[2]/div/div/div[1]/div/div[2]/div/div/div[1]"
        element = self._active.ele(f'xpath:{aaa}')
        text = element.text
        print(text)
        return text


    def get_table_data_by_xpath_v2(self, xpath, tab_name=None):
        # DrissionPage의 요소 메서드를 사용한 추출

        if tab_name:
            self.check_tab(tab_name)
        try:
            # XPath로 테이블 요소 찾기
            table = self.tab_obj.ele(f"xpath:{xpath}")
            if not table:
                print(f"테이블을 찾을 수 없습니다: {xpath}")
                return []
            result =[]

            #모든 행 찾기
            rows = table.eles("tag:tr")
            print(f"{len(rows)}개 행 발견")
            for row_icx, row in enumerate(rows):
                row_data =[]
                #각 행의 셀 찾기 (th, td 모두)
                cells = row.eles("tag:td")
                for cell in cells:
                    # 텍스트 추출
                    text =cell.text.strip0 if cell.text else ''
                    row_data.append(text)
                if row_data: #빈 행이 아니면 추가
                    result.append(row_data)
            print(f"x 데이터 추출 완료: {len(result)}행")
            return result
        except Exception as e:
            print(f"오류 발생: {e}")
            return []

    def select_option_by_class_and_index(self, tab_name, select_class, option_index):
        # class로 select 요소를 찾아서 인덱스로 옵션 선택
        self.check_tab(tab_name)
        try:
            select_element = self.tab_obj.ele(f".{select_class}", timeout=5)

            if not select_element:
                print(f"select 요소를 찾을 수 없음 (class:{select_class})")
                return False

            select_element.select(option_index)
            print(f'옵션 선택 완료 : {option_index}번째 항목')
            return True
        except Exception as e:
            print(f"오류 발생: {e}")
            return False

    def select_option_by_name_and_index(self, tab_name, select_name, option_index):
        # name으로 select 요소를 찾아서 인덱스로 옵션 선택
        self.check_tab(tab_name)
        try:
            select_element = self.tab_obj.ele(f"@name={select_name}", timeout=5)

            if not select_element:
                print(f"select 요소를 찾을 수 없음 (name:{select_name})")
                return False

            select_element.select(option_index)
            print(f'옵션 선택 완료 : {option_index}번째 항목')
            return True
        except Exception as e:
            print(f"오류 발생: {e}")
            return False


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ResultWrapper 지원
#  · xy.excel.some_method().to("변수명")  으로 결과 저장
#  · 기존 방식 result = xy.excel.some_method() 도 100% 동일 작동
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    _result_ns: dict = {}
    _use_caller_globals: bool = True

    def set_namespace(self, ns: dict, use_caller: bool = False) -> None:
        """
        .to() 가 값을 저장할 네임스페이스를 지정합니다.
        기본값은 호출자의 globals() 를 자동 감지합니다.

        Examples:
            xy.excel.set_namespace(globals())
        """
        xy_chrome._result_ns          = ns
        xy_chrome._use_caller_globals = use_caller

    def __getattribute__(self, name: str):
        """
        xy_chrome 에 직접 정의된 public 메서드 호출 결과만 ResultWrapper 로 포장.

        래핑: 클래스 외부(사용자 코드)에서 호출한 경우
        통과: _로 시작하는 이름 / 인스턴스 속성 / 내부 self.xxx() 호출
        """
        import inspect, functools

        # _로 시작하는 내부/특수 이름은 즉시 통과
        if name.startswith('_'):
            return object.__getattribute__(self, name)

        obj = object.__getattribute__(self, name)

        # 클래스 __dict__ 에 직접 def 로 정의된 것만 래핑 후보
        # → 인스턴스 속성(xlapp 등)은 __dict__ 에 없으므로 그대로 반환
        cls = object.__getattribute__(self, '__class__')
        if name not in cls.__dict__:
            return obj

        raw_def = cls.__dict__[name]
        if not (inspect.isfunction(raw_def) or
                isinstance(raw_def, (classmethod, staticmethod))):
            return obj   # 클래스 변수(_result_ns 등) 통과

        # ── 핵심: 내부 self 호출(재귀)이면 래핑 안 함 ──────────
        # 호출자 프레임의 지역변수에 self 와 동일한 객체가 있으면
        # xy_chrome 메서드 내부에서 self.xxx() 로 호출한 것
        caller_frame = inspect.currentframe().f_back
        if caller_frame is not None:
            if caller_frame.f_locals.get('self') is self:
                return obj

        # ── 외부 호출: ResultWrapper 로 포장 ───────────────────
        @functools.wraps(obj)
        def _wrapped(*args, **kwargs):
            raw = obj(*args, **kwargs)
            return ResultWrapper(raw, name)

        return _wrapped

class ResultWrapper:
    """
    xy_chrome 메서드 반환값 래퍼.
    · result = xy.excel.some_func()          # 기존 방식 그대로
    · xy.excel.some_func().to("result")      # 새 방식: 변수에 자동 저장
    · xy.excel.some_func().to("a").to("b")   # 체이닝
    · wrapped.value                          # 원본값 직접 접근
    """
    __slots__ = ("_value", "_method_name")

    def __init__(self, value, method_name: str = ""):
        object.__setattr__(self, "_value",       value)
        object.__setattr__(self, "_method_name", method_name)

    def to(self, var_name: str, ns: dict | None = None) -> "ResultWrapper":
        import inspect

        if ns is not None:
            target = ns
        elif xy_chrome._use_caller_globals and not xy_chrome._result_ns:
            frame  = inspect.stack()[1].frame
            target = frame.f_globals
        else:
            target = xy_chrome._result_ns
        target[var_name] = object.__getattribute__(self, "_value")
        return self

    @property
    def value(self):        return object.__getattribute__(self, "_value")
    def __repr__(self):
        v = object.__getattribute__(self, "_value")
        m = object.__getattribute__(self, "_method_name")
        return f"ResultWrapper({m!r} → {v!r})"

    def __str__(self):        return str(object.__getattribute__(self, "_value"))
    def _v(self):             return object.__getattribute__(self, "_value")
    def _u(self, other):      return other._v() if isinstance(other, ResultWrapper) else other
    def __eq__(self, other):  return self._v() == self._u(other)
    def __ne__(self, other):  return self._v() != self._u(other)
    def __lt__(self, other):  return self._v() <  self._u(other)
    def __le__(self, other):  return self._v() <= self._u(other)
    def __gt__(self, other):  return self._v() >  self._u(other)
    def __ge__(self, other):  return self._v() >= self._u(other)
    def __bool__(self):       return bool(object.__getattribute__(self, "_value"))
    def __len__(self):        return len(object.__getattribute__(self, "_value"))
    def __iter__(self):       return iter(object.__getattribute__(self, "_value"))
    def __getitem__(self, key):        return object.__getattribute__(self, "_value")[key]
    def __contains__(self, item):        return item in object.__getattribute__(self, "_value")
    def __add__(self, other):        return self._v() + self._u(other)
    def __radd__(self, other):        return other + self._v()

    def __hash__(self):
        try:    return hash(self._v())
        except: return id(self)

    # ── 속성/메서드를 내부 값으로 위임 (.split(), .upper() 등) ─
    def __getattr__(self, name: str):
        v = object.__getattribute__(self, "_value")
        return getattr(v, name)
