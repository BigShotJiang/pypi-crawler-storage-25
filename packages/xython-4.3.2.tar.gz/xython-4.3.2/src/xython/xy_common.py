import datetime

class xy_common:

	def __init__(self):
		"""
		check~~~ : 어떤 기본적인 값을 확인하기 위한 자료
		a_vs_b : 키값이 a이고 그결과값이 b인것을 알아내는것
		a_vs_enum : 키값이 a이고 그결과값이 enum의 값을 알아내는것
		위의 내용이 없는것은 리스트 형식을 나타내는 것

		기본적으로 자료는 여러개의 자료가 들어있읍니다
		그래서, 아무표시가 없으면, 기본자료형은 list형입니다
		사전의 경우는  a_vs_b 의 형태로 사용하며
		"""
		self.varx = {}
		self.varx["data"] = {}
		self.varx["term"]={
			"no": "1부터 시작하는 번호",
			"index": "0부터시작하는 번호",
			"nth": "n번째의 , 0부터 시작하는 것",
			"nea": "n개의",
			"change": "현재 자료가 자체를 바꿀때",
			"to": "현재 자료는 바뀌지 않고, 결과만 돌려주는 것",
			"color_style": "파스텔 톤과 같은것",
			"scolor": "색을 blu와 같이 3글자의 영문 시작 색이름으로 하고, 그 농도를 숫자나 +-기호로 변경하는것, 예 (blu++, blu55)",
			"pccs_style": "일본색체연구서가 발표한 12가지 색으로 구분한것, 톤에 대한 12가지 구분, 연한, 밝은회색, 회색, 어두운회색, 옅은, 부드러운, 탁한, 어두운, 밝은, 강한, 짙은, 선명한",
			"hsl": "색을 표현하는 기법중 하나, HSL(hue, saturation, lightness, 즉 색상, 채도, 밝기)",
			"56color": "엑셀의 기본 56가지색",
			"rgbint": "rgb값을 정수로 변경한것",
			"control": "입력으로 들어오는 값의 형태는 같으면서, 조건에따라서 변경을 하는것",
			"level1": "0~1까지의 값변화로 조정하는 것",
			"level100": "0~100까지의 값변화로 조정하는 것",
			"plusminus100": "++, --, 70등의 값이 들어오면 변화를 시켜주는 것",
			"data_로_시작_되는_단어": "주로 사용되는 자료들을 쉽게 읽어올수있도록 만든것",
			"step_by_aaa": "aaa에 대한 일정 간격마다",
			"rgb": "[빨강의 농도, 초록의 농도, 파랑의 농도],",
			"dt_obj": "datetime 객체",
			"timestamp": "utc기준으로 1970년 1월1일부터 1초마다 숫자를 더해서 사용",
			"한 주의 시작": "'월'요일 부터",
			"utc": "1970.1.1을 1초로 시작",
			"datetime": "1900.1.1을 1초로 시작, date 클래스의 isoformat() - YYYY-MM-DD의 형태를 말합니다",
			"add": "기존것에 추가하는 것",
			"insert": "새로운 뭔가를 만드는 것",
			"new": "어떤 객체를 하나 만들때 사용",
			"action_name": "action id를 이렇게 말하자",
			"parameter_name": "각 action에 연결된 parameter의 번호, parameter id와 같은 개념",
			"parameter_item": "1개의 파라미터",
			"parameter_item_set":" all parameter element, parameter id의 모든 파라미타 들",
			"parameter_item_option_set": "한개의 parameter_item 의 option 사항들",
			"char": "공백도 1개의 글자임",
			"커서": "캐롯의 의미",
			"커서의 위치": "선택영역에서, 제일 앞부분의 글자위치",
			"단어": "(단어+ 뒤의공백)까지를 포함한것",
			"글": "커서 뒤의 글자",
			"sentence": "표현이 완결된 단위, 그 자체로 하나의 서술된 문장이 되는 것",
			"paragraph": "줄바꿈이 이루어지기 전까지의 자료",
			"object": "객체를 뜻하는 것",
			"obj": "object의 짧은 사용법",
			"search": "결과물이 1개가아닌 리스트나 듀플의 형태로, 다른 정보까지 있을때",
			"get": "관련된 1개의 결과만 돌려줄 때",
			"ComputeStatistics": "워드에서 특정 텍스트나 문서 전체에 대한 다양한 정보를 얻을 수 있는 기능",
			"list": "문자들이 구분되어져서 따로 형태를 가질수있는 영역의 구분",
			"listdb의 형태": "[[y_name-1, y_name_2.....],[[a1, a2, a3...], [b1, b2, b3...], ]]",
			"listdb": "series형태로된 리스트의 묶음, 일반 list_2d와는 가로세로가 반대로 되어있다",
			"l1d": "1차원의 리스트자료",
			"l2d": "2차원의 리스트자료",
			"dicdb": "사전형으로 된 database형",
			"xyrange": "이런형태로 일반적인 리스트나 xylist형태인 도 사용가능한 방법 ['2~3':'4~5'], ['1~2'],['2~3':'~5']",
			"xy": "[1,2]의 형태 (1개의 리스트 자료)",
			"x_y": "1,2의 형태 (2개의 자료)",
			}

		self.varx["css"]={}
		self.varx["font"]={}

		self.varx["알파벳"] = self.varx["alphabet"] = "abcdefghijklmnopqrstuvwxyz"
		self.varx["자음"]= self.varx["first_letter"] = "ㄱㄴㄷㄹㅁㅂㅅㅇㅈㅊㅋㅌㅍㅎ"
		self.varx["모음"] = self.varx["second_letter"] ="ㅏㅑㅓㅕㅗㅛㅜㅠㅡㅣ"
		self.varx["받침"] = self.varx["third_letter"] = ["", "ㄱ", "ㄲ", "ㄳ", "ㄴ", "ㄵ", "ㄶ", "ㄷ", "ㄹ", "ㄺ", "ㄻ", "ㄼ", "ㄽ", "ㄾ", "ㄿ", "ㅀ", "ㅁ", "ㅂ", "ㅄ", "ㅅ", "ㅆ", "ㅇ", "ㅈ", "ㅊ", "ㅋ", "ㅌ", "ㅍ", "ㅎ"]  # 28 글자, 없는것 포함
		self.varx["가~하"] = "가나다라마바사아자차카타파하"
		self.varx["0~9"] = self.varx["list_숫자"]= "1234567890"
		self.varx["그리스문자"] = "αβγδεζήθικλμνξόπρΣτ"
		self.varx["로마숫자"] = "ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩ"
		self.varx["원ㄱ~ㅎ"] = "㉠㉡㉢㉣㉤㉥㉦㉧㉨㉩㉪㉫㉬㉭"
		self.varx["원가~하"] = "㉮㉯㉰㉱㉲㉳㉴㉵㉶㉷㉸㉹㉺㉻"
		self.varx["원a~z"] = "ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏ"
		self.varx["원0~50"] = "⓪①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳㉑㉒㉓㉔㉕㉖㉗㉘㉙㉚㉛㉜㉝㉞㉟㊱㊲㊳㊴㊵㊶㊷㊸㊹㊺㊻㊼㊽㊾㊿"
		self.varx["web_site"] = "www.xython.co.kr"
		self.varx["wb_count"] = 1
		self.varx["timezone"] = "seoul"
		self.varx["year_sec"] = 60 * 60 * 24 * 365
		self.varx["month_sec"] = 60 * 60 * 24 * 30
		self.varx["day_sec"] = 60 * 60 * 24

		self.varx["색조정_+-"] = self.varx["color_step_+-"] = ["+++++", "++++", "+++", "++", "+", "", "-", "--", "---", "----", "-----"]

		self.varx["color12"] = ['red', 'ora', 'yel', 'gre_yel', 'gre', 'gre_cya', 'cya', 'blu_cya', 'blu', 'blu_mag', 'mag', 'red_mag']
		self.varx["color15"] = ["red", "ora", "yel", "gre_yel", "gre", "gre_cya", "cya", "blu_cya", "blu", "blu_mag", "mag", "red_mag", "gra", "whi", "bla"]
		self.varx["color15_short"] = ["r", "o", "y", "gre_yel", "g", "gre_cya", "c", "blu_cya", "b", "blu_mag", "m", "red_mag", "g", "w", "bl"]
		self.varx["color12_kor"] = ['빨강', '주황', '노랑', '연두', '초록', '연초록', '하늘', '군청', '파랑', '남색', '핑크', '자주']
		self.varx["color15_kor"] = ["빨강", "주황", "노랑", "연두", "초록", "연초록", "하늘", "군청", "파랑", "남색", "핑크", "자주", "회색", "흰색", "검정"]

		self.varx["color_vs_hsl"] = {
			"gra": [0, 0, 50], "whi": [0, 0, 100], "bla": [0, 0, 0], "red": [0, 100, 50],
			"ora": [30, 100, 50], "yel": [60, 100, 50], "gre_yel": [90, 100, 50], "gre": [120, 100, 50],
			"gre_cya": [150, 100, 50], "cya": [180, 100, 50], "blu_cya": [210, 100, 50], "blu": [240, 100, 50],
			"blu_mag": [270, 100, 50], "mag": [300, 100, 50], "red_mag": [330, 100, 50], "pin": [326, 75, 56],
			"bro": [30, 100, 40], "sca": [181, 0, 16], "pal_pin": [348, 95, 84], "sul_yel": [150, 75, 0],
		}
		self.varx["color_vs_rgb"] = {
			"gra": [128, 128, 128], "whi": [255, 255, 255], "bla": [0, 0, 0], "red": [255, 0, 0],
			"ora": [255, 127, 0], "yel": [255, 255, 0], "gre_yel": [127, 255, 0], "gre": [1, 255, 1],
			"gre_cya": [0, 255, 128], "cya": [0, 254, 255], "blu_cya": [0, 126, 255], "blu": [0, 0, 255],
			"blu_mag": [127, 0, 255], "mag": [254, 0, 253], "red_mag": [255, 0, 126], "pin": [227, 59, 153],
			"bro": [204, 102, 0], "sca": [192, 0, 32], "pal_pin": [253, 175, 190], "sul_yel": [241, 222, 55], }
		self.varx["color_vs_h"] = {"red": 0, "ora": 30, "yel": 60, "gre_yel": 90, "gre": 120, "gre_cya": 150, "cya": 180, "blu_cya": 210, "blu": 240, "blu_mag": 270, "mag": 300,
								   "red_mag": 330, "gra": 0, "whi": 0, "bla": 0, "pin": 326, }
		self.varx["color_vs_index"] = {"red": 0, "ora": 1, "yel": 2, "gre_yel": 3, "gre": 4, "gre_cya": 5, "cya": 6, "blu_cya": 7, "blu": 8, "blu_mag": 9, "mag": 10,
									   "red_mag": 11, "gra": 12, "whi": 13, "bla": 14}
		self.varx["color_short_vs_index"] = {"red": 0, "ora": 1, "yel": 2, "yg": 3, "gre": 4, "gre_cya": 5, "cya": 6, "cb": 7, "blu": 8, "blu_mag": 9, "mag": 10, "mr": 11, "gra": 12, "whi": 13,
											 "bla": 14}
		self.varx["color_vs_degree"] = {"red": 0, "ora": 30, "yel": 60, "gre_yel": 90, "gre": 120, "gre_cya": 150, "cya": 180, "blu_cya": 210, "blu": 240, "blu_mag": 270,
										"mag": 300, "red_mag": 330, "gra": 0, "whi": 0, "bla": 0, }
		self.varx["excel46_vs_rgb"] = {
			1: [0, 0, 0], 2: [255, 255, 255], 3: [255, 0, 0], 4: [0, 255, 0], 5: [0, 0, 255],
			6: [255, 255, 0], 7: [255, 0, 255], 8: [0, 255, 255], 9: [128, 0, 0], 10: [0, 128, 0],
			11: [0, 0, 128], 12: [128, 128, 0], 13: [128, 0, 128], 14: [0, 128, 128], 15: [192, 192, 192],
			16: [128, 128, 128], 17: [153, 153, 255], 18: [153, 51, 102], 19: [255, 255, 204], 20: [204, 255, 255],
			21: [102, 0, 102], 22: [255, 128, 128], 23: [0, 102, 204], 24: [204, 204, 255], 25: [0, 0, 128],
			26: [255, 0, 255], 27: [255, 255, 0], 28: [0, 255, 255], 29: [128, 0, 128], 30: [128, 0, 0],
			31: [0, 128, 128], 32: [0, 0, 255], 33: [0, 204, 255], 34: [204, 255, 255], 35: [204, 255, 204],
			36: [255, 255, 153], 37: [153, 204, 255], 38: [255, 153, 204], 39: [204, 153, 255], 40: [255, 204, 153],
			41: [51, 102, 255], 42: [51, 204, 204], 43: [153, 204, 0], 44: [255, 204, 0], 45: [255, 153, 0],
			46: [255, 102, 0]}

		self.varx["excel56_vs_rgb"] = {
			1: [0, 0, 0], 2: [255, 255, 255], 3: [255, 0, 0], 4: [0, 255, 0], 5: [0, 0, 255],
			6: [255, 255, 0], 7: [255, 0, 255], 8: [0, 255, 255], 9: [128, 0, 0], 10: [0, 128, 0],
			11: [0, 0, 128], 12: [128, 128, 0], 13: [128, 0, 128], 14: [0, 128, 128], 15: [192, 192, 192],
			16: [128, 128, 128], 17: [153, 153, 255], 18: [153, 51, 102], 19: [255, 255, 204], 20: [204, 255, 255],
			21: [102, 0, 102], 22: [255, 128, 128], 23: [0, 102, 204], 24: [204, 204, 255], 25: [0, 0, 128],
			26: [255, 0, 255], 27: [255, 255, 0], 28: [0, 255, 255], 29: [128, 0, 128], 30: [128, 0, 0],
			31: [0, 128, 128], 32: [0, 0, 255], 33: [0, 204, 255], 34: [204, 255, 255], 35: [204, 255, 204],
			36: [255, 255, 153], 37: [153, 204, 255], 38: [255, 153, 204], 39: [204, 153, 255], 40: [255, 204, 153],
			41: [51, 102, 255], 42: [51, 204, 204], 43: [153, 204, 0], 44: [255, 204, 0], 45: [255, 153, 0],
			46: [255, 102, 0], 47: [102, 102, 153], 48: [150, 150, 150], 49: [0, 51, 102], 50: [51, 153, 102],
			51: [0, 51, 0], 52: [51, 51, 0], 53: [153, 51, 0], 54: [153, 51, 102], 55: [51, 51, 153],
			56: [51, 51, 51], }

		self.varx["excel56_vs_color_kor"] = {
			1: "검정색", 2: "흰색", 3: "빨강색", 5: "파랑색", 6: "노랑색",
			7: "핑크색", 46: "오렌지", 13: "보라색", 14: "청록색", 19: "옅은노랑",
			20: "옅은하늘", 18: "매실색", 8: "밝은하늘", 4: "연두색", 15: "회색20",
			48: "회색40", 16: "회색60", 56: "회색80", 9: "진한적색", 10: "진한녹색",
			11: "진한청색", 12: "진한황색", 21: "진한보라", 33: "진한하늘", 49: "진한산호색",
			17: "담자색", 45: "토황색", 35: "취람색", 36: "송화색", 40: "두록색",
			22: "주색", 23: "청현색", 24: "회보라색", 37: "밝은벽청색", 38: "선홍색", 47: "치색",
		}

		self.varx["color_kor_vs_excel56"] = {
			"bla": 1, "whi": 2, "blu": 5, "yel": 6,
			"pin": 7, "ora": 46, "pur": 13, "gre": 14, "gra": 15,
			"검정색": 1, "흰색": 2, "빨강색": 3, "파랑색": 5, "노랑색": 6,
			"핑크색": 7, "오렌지": 46, "보라색": 13, "청록색": 14, "옅은노랑": 19,
			"옅은하늘": 20, "매실색": 18, "밝은하늘": 8, "연두색": 4, "회색20": 15,
			"회색40": 48, "회색60": 16, "회색80": 56, "진한적색": 9, "진한녹색": 10,
			"진한청색": 11, "진한황색": 12, "진한보라": 21, "진한하늘": 33, "진한산호색": 49,
			"담자색": 17, "토황색": 45, "취람색": 35, "송화색": 36, "두록색": 40,
			"주색": 22, "청현색": 23, "회보라색": 24, "밝은벽청색": 37, "선홍색": 38, "치색": 47,
			"black": 1, "white": 2, "red": 3, "blue": 5, "yellow": 6,
			"pink": 7, "orange": 46, "purple": 13, "green": 14, "gray": 15,
			"검정": 1, "빨강": 3, "파랑": 5, "노랑": 6,
			"핑크": 7, "보라": 13, "청록": 14, "회색": 15,
		}

		self.varx["rgb_46_for_엑셀46"] = self.varx["rgb_46_for_excel46"] = list(self.varx["excel46_vs_rgb"].values())

		self.varx["rgb_56_for_엑셀56"] = self.varx["rgb_56_for_excel56"] = list(self.varx["excel56_vs_rgb"].values())

		self.varx["johannes_to_hsl"] = [
			[[0, 100, 0], [0, 100, 10], [0, 100, 20], [0, 100, 30], [0, 100, 40], [0, 100, 50], [0, 100, 60], [0, 100, 70],
			 [0, 100, 80], [0, 100, 90], [0, 100, 100]],
			[[30, 100, 0], [30, 100, 10], [30, 100, 20], [30, 100, 30], [30, 100, 40], [30, 100, 50], [30, 100, 60],
			 [30, 100, 70], [30, 100, 80], [30, 100, 90], [30, 100, 100]],
			[[60, 100, 0], [60, 100, 10], [60, 100, 20], [60, 100, 30], [60, 100, 40], [60, 100, 50], [60, 100, 60],
			 [60, 100, 70], [60, 100, 80], [60, 100, 90], [60, 100, 100]],
			[[90, 100, 0], [90, 100, 10], [90, 100, 20], [90, 100, 30], [90, 100, 40], [90, 100, 50], [90, 100, 60],
			 [90, 100, 70], [90, 100, 80], [90, 100, 90], [90, 100, 100]],
			[[120, 100, 0], [120, 100, 10], [120, 100, 20], [120, 100, 30], [120, 100, 40], [120, 100, 50], [120, 100, 60],
			 [120, 100, 70], [120, 100, 80], [120, 100, 90], [120, 100, 100]],
			[[150, 100, 0], [150, 100, 10], [150, 100, 20], [150, 100, 30], [150, 100, 40], [150, 100, 50], [150, 100, 60],
			 [150, 100, 70], [150, 100, 80], [150, 100, 90], [150, 100, 100]],
			[[180, 100, 0], [180, 100, 10], [180, 100, 20], [180, 100, 30], [180, 100, 40], [180, 100, 50], [180, 100, 60],
			 [180, 100, 70], [180, 100, 80], [180, 100, 90], [180, 100, 100]],
			[[210, 100, 0], [210, 100, 10], [210, 100, 20], [210, 100, 30], [210, 100, 40], [210, 100, 50], [210, 100, 60],
			 [210, 100, 70], [210, 100, 80], [210, 100, 90], [210, 100, 100]],
			[[240, 100, 0], [240, 100, 10], [240, 100, 20], [240, 100, 30], [240, 100, 40], [240, 100, 50], [240, 100, 60],
			 [240, 100, 70], [240, 100, 80], [240, 100, 90], [240, 100, 100]],
			[[270, 100, 0], [270, 100, 10], [270, 100, 20], [270, 100, 30], [270, 100, 40], [270, 100, 50], [270, 100, 60],
			 [270, 100, 70], [270, 100, 80], [270, 100, 90], [270, 100, 100]],
			[[300, 100, 0], [300, 100, 10], [300, 100, 20], [300, 100, 30], [300, 100, 40], [300, 100, 50], [300, 100, 60],
			 [300, 100, 70], [300, 100, 80], [300, 100, 90], [300, 100, 100]],
			[[330, 100, 0], [330, 100, 10], [330, 100, 20], [330, 100, 30], [330, 100, 40], [330, 100, 50], [330, 100, 60],
			 [330, 100, 70], [330, 100, 80], [330, 100, 90], [330, 100, 100]]]

		self.varx["highlight_vs_rgb"] = {"none": [255, 255, 255], "yel": [255, 255, 0], "gre_b": [0, 255, 0], " ": [0, 255, 255], "pin": [255, 0, 255], "blu": [0, 0, 255], "red": [255, 0, 0],
										 "blu_d": [0, 0, 139], "gre_d": [0, 128, 128], "gre": [0, 128, 0], "pur": [139, 0, 0], "red_d": [139, 0, 0], "yel_d": [128, 128, 0], "gra_50": [128, 128, 128],
										 "gra_b": [192, 192, 192], "bla": [0, 0, 0]}

		self.varx["highlight_vs_enum"] = {"none": 0, "yel": 1, "gre_b": 2, " ": 3, "pin": 4, "blu": 5, "red": 6, "blu_d": 7, "gre_d": 8, "gre": 9, "pur": 10, "red_d": 11, "yel_d": 12, "gra_50": 13,
										  "gra_b": 14, "bla": 15, }
		self.varx["highlight_colorindex"] = {"red": 6, "bla": 1, "blu": 2, "basic": 0, "": 0, "gra": 16, "gre": 11, "pin": 5, "vio": 12, "whi": 8, "yel": 7, }

		self.varx["check_color"] = {
			"빨": "red", "적": "red", "빨강": "red", "red": "red", "r": "red", "빨간색": "red", "빨강색": "red",
			"주": "ora", "주황": "ora", "주황색": "ora", "오렌지": "ora", "yr": "ora", "yellowred": "ora", "yellow_red": "ora", "yel_red": "ora", "yellow red": "ora", "o": "ora", "orange": "ora", "ora": "ora",
			"노": "yel", "노랑": "yel", "노랑색": "yel", "황색": "yel", "y": "yel", "yellow": "yel", "yel": "yel",
			"연": "gre_yel", "연두": "gre_yel", "연두색": "gre_yel", "gre_yel": "gre_yel", "gy": "gre_yel", "greenyellow": "gre_yel", "green_yellow": "gre_yel", "green yellow": "gre_yel",
			"green-yellow": "gre_yel", "yg": "gre_yel",
			"초": "gre", "초록": "gre", "초록색": "gre", "g": "gre", "green": "gre", "gre": "gre", "녹색": "gre",
			"연초록": "gre_cya", "gre_cya": "gre_cya", "greencyan": "gre_cya", "green_cyan": "gre_cya", "green cyan": "gre_cya", "cg": "gre_cya", "gc": "gre_cya",
			"옥": "cya", "옥색": "cya", "하늘색": "cya", "하늘": "cya", "c": "cya", "cya": "cya", "cyan": "cya",
			"청록": "blu_cya", "청록색": "blu_cya", "청": "blu_cya", "군청색": "blu_cya", "군청": "blu_cya", "청색": "blu_cya", "blu_cya": "blu_cya", "bluecyan": "blu_cya", "blue_cyan": "blu_cya",
			"blue cyan": "blu_cya",
			"cb": "blu_cya", "bg": "blu_cya", "bluegreen": "blu_cya", "bc": "blu_cya",
			"파": "blu", "파랑": "blu", "파랑색": "blu", "b": "blu", "blue": "blu", "blu": "blu",
			"남": "blu_mag", "남색": "blu_mag", "blu_mag": "blu_mag", "bluemagenta": "blu_mag", "blue_magenta": "blu_mag", "blue magenta": "blu_mag", "bm": "blu_mag", "pb": "blu_mag",
			"purpleblue": "blu_mag", "purple_blue": "blu_mag", "purple blue": "blu_mag",
			"pur_blu": "blu_mag",
			"핑크": "pin", "핑크색": "pin", "분홍": "pin", "분홍색": "pin", "pink": "pin", "pin": "pin",
			"자홍": "red_mag", "자주": "red_mag", "자주색": "red_mag", "redmagenta": "red_mag", "red_mag": "red_mag", "red_magenta": "red_mag", "red magenta": "red_mag", "rm": "red_mag", "mr": "red_mag",
			"보": "mag", "보라": "mag", "보라색": "mag", "magenta": "mag", "m": "mag", "mag": "mag", "purple": "mag", "자색": "mag", "violet": "mag", "vio": "mag",
			"회": "gra", "회색": "gra", "gra": "gra", "gray": "gra",
			"흰": "whi", "하양": "whi", "하양색": "whi", "하얀색": "whi", "흰색": "whi", "white": "whi", "whi": "whi",
			"검": "bla", "검정": "bla", "검정색": "bla", "흑": "bla", "흑색": "bla", "black": "bla", "bla": "bla",
			"갈색": "bro", "brown": "bro", "bro": "bro",
			"주홍": "sca", "sca": "sca", "scarlet": "sca", "주홍색": "sca", "선홍색": "sca", "선홍": "sca",
			"연분홍": "pal_pin", "pale_pink": "pal_pin", "pal_pin": "pal_pin",
			"유황색": "sul_yel", "유황": "sul_yel", "sul_yel": "sul_yel", "sulphur_yellow": "sul_yel",
			"군청": "blu_cya",
		}

		self.varx["check_color_kor"] = {
			"빨": "빨강", "적": "빨강", "red": "빨강", "r": "빨강", "빨간색": "빨강", "빨강색": "빨강", "빨강": "빨강",
			"주": "오렌지", "주황": "오렌지", "주황색": "오렌지", "ora": "오렌지", "yr": "오렌지", "yellowred": "오렌지", "yellow_red": "오렌지", "yel_red": "오렌지", "yellow red": "오렌지", "o": "오렌지", "orange": "오렌지",
			"노": "노랑", "노랑": "노랑", "노랑색": "노랑", "황색": "노랑", "y": "노랑", "yellow": "노랑", "yel": "노랑",
			"연": "연두", "연두": "연두", "연두색": "연두", "gy": "연두", "greenyellow": "연두", "green_yellow": "연두", "gre_yel": "연두", "green yellow": "연두", "green-yellow": "연두", "yg": "연두",
			"초": "초록", "초록": "초록", "초록색": "초록", "g": "초록", "녹색": "초록",
			"연초록": "연초록", "greencyan": "연초록", "green_cyan": "연초록", "gre_cya": "연초록", "green cyan": "연초록", "cg": "연초록", "gc": "연초록",
			"옥": "하늘", "옥색": "하늘", "하늘색": "하늘", "하늘": "하늘", "c": "하늘", "cya": "하늘", "cyan": "하늘",
			"청록": "군청", "청록색": "군청", "청": "군청", "군청색": "군청", "청색": "군청", "bluecyan": "군청", "blue_cyan": "군청", "blu_cya": "군청", "blue cyan": "군청", "cb": "군청", "bg": "군청", "bluegreen": "군청",
			"파": "파랑", "파랑": "파랑", "파랑색": "파랑", "b": "파랑", "blue": "파랑", "blu": "파랑",
			"남": "남색", "남색": "남색", "bluemagenta": "남색", "blue_magenta": "남색", "blu_mag": "남색", "blue magenta": "남색", "bm": "남색", "pb": "남색", "purpleblue": "남색", "purple_blue": "남색", "pur_blu": "남색",
			"purple blue": "남색",
			"핑크": "핑크", "핑크색": "핑크", "분홍": "핑크", "분홍색": "핑크", "pink": "핑크",
			"자홍": "자주", "자주": "자주", "자주색": "자주", "redmagenta": "자주", "red_mag": "자주", "red_magenta": "자주", "red magenta": "자주", "rm": "자주", "mr": "자주",
			"보": "보라", "보라": "보라", "보라색": "보라", "magenta": "보라", "m": "보라", "mag": "보라", "purple": "보라", "자색": "보라", "violet": "보라", "vio": "보라",
			"회": "회색", "회색": "회색", "gra": "회색", "gray": "회색",
			"흰": "하양", "하양": "하양", "하양색": "하양", "하얀색": "하양", "흰색": "하양", "white": "하양", "whi": "하양",
			"검": "검정", "검정": "검정", "검정색": "검정", "흑": "검정", "흑색": "검정", "black": "검정", "bla": "검정",
			"갈색": "갈색", "brown": "갈색", "bro": "갈색",
			"주홍": "주홍", "scarlet": "주홍", "sca": "주홍", "주홍색": "주홍", "선홍색": "주홍", "선홍": "주홍",
			"연분홍": "연분홍", "pale_pink": "연분홍", "pal_pin": "연분홍",
			"유황색": "유황", "유황": "유황", "sulphur_yellow": "유황", "sul_yel": "유황",
		}

		self.varx["tone10"] = ["white", "pale", "light", "soft", "vivid", "dull", "deep", "dark", "black", "gray"]
		self.varx["tone10_kor"] = ["연한", "밝은", "흐린", "선명한", "기본", "탁한", "진한", "어두운", "회색", "검은", "검정"]
		self.varx["tone12"] = ["pale", "light_grayish", "grayish", "dark_grayish", "light", "soft", "dull", "dark", "bright", "strong", "deep", "vivid"]
		self.varx["tone12_short"] = ["p", "ltg", "g", "dkg", "lt", "sf", "d", "dk", "s", "b", "dp", "v"]
		self.varx["tone12_kor"] = ["연한", "밝은회색", "회색", "어두운회색", "옅은", "부드러운", "탁한", "어두운", "기본", "밝은", "짙은", "선명한"]
		self.varx["tone15_kor"] = ["연한", "밝은회색", "회색", "어두운회색", "옅은", "부드러운", "탁한", "어두운", "기본", "밝은", "짙은", "선명한", "검은", "하얀", "파스텔"]
		self.varx["tone15_short"] = ["p", "ltg", "g", "dkg", "lt", "sf", "d", "dk", "s", "b", "dp", "v", "bla", "whi", "pas"]
		self.varx["tone_vs_sl"] = {"pastel": [100, 85], "p": [25, 85], "ltg": [25, 65], "g": [25, 35], "dkg": [25, 15], "lt": [50, 80], "sf": [50, 60],
								   "d": [50, 40], "dk": [50, 20], "s": [70, 50], "b": [75, 75], "dp": [75, 25], "v": [90, 50], }
		self.varx["tone12_kor_vs_index"] = {"연한": 0, "밝은회색": 1, "회색": 2, "어두운회색": 3, "옅은": 4, "부드러운": 5, "탁한": 6, "어두운": 7, "기본": 8, "밝은": 9, "짙은": 10, "선명한": 11}
		self.varx["tone12_vs_index"] = {"v": 0, "b": 1, "s": 2, "dp": 3, "lt": 4, "sf": 5, "d": 6, "dk": 7, "p": 8, "ltg": 9, "g": 10, "dkg": 11, }
		self.varx["tone15_short_vs_sl"] = {"p": [25, 85], "ltg": [25, 65], "g": [25, 35], "dkg": [25, 15], "lt": [50, 80], "sf": [50, 60], "d": [50, 40], "dk": [50, 20],
										   "s": [70, 50], "b": [75, 75], "dp": [75, 25], "v": [90, 50], "bla": [100, 0], "whi": [0, 100], "pas": [100, 80]}
		self.varx["check_tone"] = {
			"p": "p", "pale": "p", "pal": "p", "연한": "p",
			"ltg": "ltg", "lightgrayish": "ltg", "gra+": "ltg", "밝은회색조": "ltg", "light_grayish": "ltg", "밝은회색": "ltg",
			"g": "g", "grayish": "g", "gra": "g", "회색조": "g", "회색": "g", "gray": "g",
			"dkg": "dkg", "darkgrayish": "dkg", "gra-": "dkg", "어두운회색조": "dkg", "dark_grayish": "dkg", "어두운회색": "dkg",
			"lt": "lt", "light": "lt", "lig": "lt", "옅은": "lt", "흐린": "lt",
			"sf": "sf", "soft": "sf", "sof": "sf", "부드러운": "sf",
			"d": "d", "dull": "d", "dul": "d", "둔한": "d", "탁한": "d",
			"dk": "dk", "dark": "dk", "dar": "dk", "어두운": "dk",
			"s": "s", "str": "s", "strong": "s", "강한": "s", "기본": "s",
			"b": "b", "bright": "b", "bri": "b", "밝은": "b",
			"dp": "dp", "deep": "dp", "dee": "dp", "짙은": "dp", "진한": "dp",
			"v": "v", "vivid": "v", "viv": "v", "선명한": "v",
			"black": "bla", "검정": "bla", "검은": "bla",
			"white": "whi", "하얀": "whi", "흰": "whi", "하양": "whi",
			"파스텔": "pas", "pastel": "pas", "pas": "pas",
		}

		self.varx["h_for_color12"] = [0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330]
		self.varx["sl_6_for_faber_스타일"] = self.varx["sl_no_for_faber_style"] = [[[100, 0], [100, 50], [0, 0]], [[0, 0], [0, 75], [0, 100]], [[100, 0], [25, 75], [0, 100]],
																				[[25, 0], [10, 50], [0, 75]],
																				[[100, 0], [0, 0], [0, 100]], [[25, 0], [10, 50], [0, 75], [25, 75]], ]
		self.varx["sl_9_by_큰step"] = [[100, 80], [100, 77], [100, 68], [100, 59], [100, 50], [90, 41], [80, 32], [70, 23], [60, 14]]
		self.varx["sl_10_by_작은step"] = [[0, 12], [0, 9], [0, 6], [0, 3], [0, 0], [0, -3], [0, -6], [0, -9], [0, -12], [0, -14]]
		self.varx["sl10"] = [[100, 0], [90, 10], [80, 20], [70, 30], [60, 40], [50, 50], [40, 60], [30, 70], [10, 80], [10, 90], [0, 100]]
		self.varx["sl11"] = [[100, 0], [100, 10], [100, 20], [100, 30], [100, 40], [100, 50], [100, 60], [100, 70], [100, 80], [100, 90], [100, 100]]
		self.varx["sl_for_tone12"] = [[90, 50], [80, 30], [80, 50], [80, 70], [50, 20], [50, 40], [50, 60], [50, 80], [20, 20], [20, 40], [20, 60], [20, 80]]
		self.varx["sl값_큰단계_vs_sl값"] = self.varx["num_slstep"] = {"1": [100, 80], "2": [100, 77], "3": [100, 68], "4": [100, 59], "5": [100, 50], "6": [90, 41], "7": [80, 32], "8": [70, 23],
																 "9": [60, 14]}
		self.varx["sl값_작은단계_vs_sl값"] = self.varx["num_slstep_small"] = {"1": [0, 12], "2": [0, 9], "3": [0, 6], "4": [0, 3], "5": [0, 0], "6": [0, -3], "7": [0, -6], "8": [0, -9], "9": [0, -12],
																		"0": [0, -14], }
		self.varx["rgb_for_color12"] = [[255, 0, 0], [255, 128, 0], [255, 255, 0], [128, 255, 0], [0, 255, 0], [0, 255, 128], [0, 255, 255], [0, 128, 255], [0, 0, 255],
										[128, 0, 255], [255, 0, 255], [255, 0, 128], ]
		self.varx["hsl_for_color12"] = [[0, 100, 50], [30, 100, 50], [60, 100, 50], [90, 100, 50], [120, 100, 50], [150, 100, 50], [180, 100, 50], [210, 100, 50],
										[240, 100, 50], [270, 100, 50], [300, 100, 50], [330, 100, 50]]
		self.varx["hsl_for_color18"] = [[0, 100, 50], [20, 100, 50], [40, 100, 50], [60, 100, 50], [80, 100, 50], [100, 100, 50],
										[120, 100, 50], [140, 100, 50], [160, 100, 50], [180, 100, 50], [200, 100, 50], [220, 100, 50],
										[240, 100, 50], [260, 100, 50], [280, 100, 50], [300, 100, 50], [320, 100, 50], [340, 100, 50], ]
		self.varx["색강도_vs_sl값"] = self.varx["+-_value_vs_sl_no"] = {"+++++": [0, 15], "++++": [0, 12], "+++": [0, 9], "++": [0, 6], "+": [0, 3], "-": [0, -3], "--": [0, -6], "---": [0, -9],
																	"----": [0, -12], "-----": [0, -14], }
		self.varx["번호_vs_s단계"] = self.varx["num_sstep"] = {"1": [10], "2": [20], "3": [30], "4": [40], "5": [50], "6": [60], "7": [70], "8": [80], "9": [90], }
		self.varx["번호_vs_l단계"] = self.varx["num_lstep"] = {"1": [10], "2": [20], "3": [30], "4": [40], "5": [50], "6": [60], "7": [70], "8": [80], "9": [90], }

		self.varx["basic_font_parameter_vs_value"] = {"size": 10, "bold": False, "italic": False, "name": "Arial", "strikethrough": False, "subscript": False, "superscript": False, "underline": False,
													  "color": "bla"}
		self.varx["color_step"] = ["++++++++++", "+++++++++", "++++++++", "+++++++", "++++++", "+++++", "++++", "+++", "++", "+",
								   "", "-", "--", "---", "----", "-----", "------", "-------", "--------", "---------"]
		self.varx["color_step_vs_sl"] = {"+++++": [0, 15], "++++": [0, 12], "+++": [0, 9], "++": [0, 6], "+": [0, 3], "-": [0, -3],
										 "--": [0, -6], "---": [0, -9], "----": [0, -12], "-----": [0, -14], }
		self.varx["color_vs_24bit"] = {"aqu": 13421619, "": -16777216, "bla": 0, "blu": 16711680, "bro": 13209, "gre": 32768, "ind": 10040115, "ora": 26367, "pin": 16711935, "red": 255,
									   "vio": 8388736, "whi": 16777215, "yel": 65535}

		self.varx["check_font"] = {"bold": "bold", "진하게": "bold",
								   "색": "color", "색깔": "color", "색상": "color", "color": "color",
								   "크기": "size", "사이즈": "size", "size": "size",
								   "밑줄": "underline", "underline": "underline",
								   "취소": "strikethrough", "취소선": "strikethrough", "strike": "strikethrough", "strikethrough": "strikethrough",
								   "이름": "name", "폰트": "name", "폰트명": "name", "name": "name",
								   "italic": "italic", "이탈릭채": "italic", "기울게": "italic", "이탈릭": "italic",
								   "윗첨자": "superscript", "superscript": "superscript",
								   "아래첨자": "subscript", "subscript": "subscript",
								   "투명도": "alpha", "alpha": "alpha", "알파": "alpha", "알파값": "alpha",
								   "수직정렬": "align_v", "수직": "align_v", "align_v": "align_v",
								   "수평정렬": "align_h", "수평": "align_h", "align_h": "align_h",
								   "style": "style", "스타일": "style", "type": "style",
								   "너비": "width", "넓이": "width", "width": "width", "w": "width", "길이": "width",
								   "높이": "height", "height": "height", "h": "height",
								   "이탤릭": "italic", "이태릭": "italic",
								   "line": "underline",
								   "중간": 1, "middle": 1, "왼쪽": 0, "left": 0, "오른쪽": 2, "right": 2, "l": 0, "m": 1, "r": 2,
								   }

		self.varx["line_style_dic"] = {"solid": "solid", "dotted": "dotted", "dot": "dotted", "dashed": "dashed", "dash": "dashed",
									   "double": "double", "outset": "outset", "inset": "inset", "groove": "groove", "ridge": "ridge",
									   "": "solid", ".": "dotted", "--": "dashed", "=": "double"}

		self.varx["check_color_step"] = self.varx["색강도_vs_기본값"] = {
			0: "0", "0": "0", "l5": "0", "+++++": "0", "pale": "0", "p": "0", "pastel": "0", "파스텔": "0", "d5": "0",
			1: "1", "1": "1", "l4": "1", "++++": "1", "light_grayish": "1", "ltg": "1", "밝은회색": "1", "d4": "1",
			2: "2", "2": "2", "l3": "2", "+++": "2", "light": "2", "lt": "2", "흐린": "2", "옅은": "2", "d3": "2",
			3: "3", "3": "3", "l2": "3", "++": "3", "soft": "3", "sf": "3", "부드러운": "3", "d2": "3",
			4: "4", "4": "4", "l1": "4", "+": "4", "bright": "4", "b": "4", "밝은": "4", "d1": "4",
			5: "5", "5": "5", "l0": "5", "": "5", "strong": "5", "s": "5", "강한": "5", "d0": "5",
			6: "6", "6": "6", "l-1": "6", "-": "6", "deep": "6", "dp": "6", "진한": "6", "d-1": "6",
			7: "7", "7": "7", "l-2": "7", "--": "7", "dull": "7", "d": "7", "탁한": "7", "d-2": "7",
			8: "8", "8": "8", "l-3": "8", "---": "8", "dark": "8", "dk": "8", "어두운": "8", "d-3": "8",
			9: "9", "9": "9", "l-4": "9", "----": "9", "grayish": "9", "g": "9", "회색": "9", "잿빛": "9", "d-4": "9",
			10: "10", "10": "10", "l-5": "10", "-----": "10", "dark_grayish": "10", "dkg": "10", "어두운회색": "10", "d-5": "10",
			55: "55", "55": "55", "ls": "55", "기준": "55",
			"light grayish": "1",
			"가벼운": "2",
			"연한": "3",
			"vivid": "5", "v": "5", "선명한": "5", "basic": "5", "기본": "5",
			"회색빛": "9",
			"dark grayish": "10", "어두운 회색": "10",
			11: "11", "11": "11", "l11": "11", "+++++++++": "11",
		}

		self.varx["color_vs_enum"] = {"red": 6, "bla": 1, "blu": 2, "basic": 0, "": 0, "gra": 16, "gre": 11, "pin": 5, "vio": 12, "whi": 8, "yel": 7}

		self.varx["color_vs_24bit"] = {"aqu": 13421619, "": -16777216, "bla": 0, "blu": 16711680, "bro": 13209, "gre": 32768, "ind": 10040115
			, "ora": 26367, "pin": 16711935, "red": 255, "vio": 8388736, "whi": 16777215, "yel": 65535}

		self.varx["line_width"] = {"yel": 7,"25": 2,"50": 4,"75": 6,"100": 8,"150": 12,"225": 18,"300": 24,"450": 36,"600": 48,"---": 2,"--": 4 ,"-": 6,"basic": 8,"": 8,"+": 12,"++": 18,"+++": 24,"++++": 36,"+++++": 48}
		self.varx["currency_eng_last"] = ['no', 'one', 'dollars']
		self.varx["num_last_cent"] = ['only', 'and one cent', 'and', 'cents']
		self.varx["숫자1~9_영어"] = self.varx["list_getdigit"] = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine']
		self.varx["숫자_10단뒤_영어"] = self.varx["list_num_eng_00digit"] = ['ten','twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety']
		self.varx["숫자_10~19_영어"] = self.varx["list_num_eng_10"] = ['ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'eighteen', 'nineteen']
		self.varx["숫자_1000_단위_영어"] = self.varx["list_num_eng_unit_1000"] = ['thousand', 'million', 'billion', 'trillion']
		self.varx["자음_vs_index"] = self.varx["first_letter_vs_index"] = {"ㄱ":0, "ㄲ":1, "ㄴ":2, "ㄷ":3, "ㄸ":4, "ㄹ":5, "ㅁ":6, "ㅂ":7, "ㅃ":8, "ㅅ":9, "ㅆ":10, "ㅇ":11, "ㅈ":12, "ㅉ":13, "ㅊ":14, "ㅋ":15, "ㅌ":16, "ㅍ":17, "ㅎ":18}  # 19 글자
		self.varx["모음_vs_index"] = self.varx["second_letter_vs_index"] = {"ㅏ":0, "ㅐ":1, "ㅑ":2, "ㅒ":3, "ㅓ":4, "ㅔ":5, "ㅕ":6, "ㅖ":7, "ㅗ":8, "ㅘ":9, "ㅙ":10, "ㅚ":11, "ㅛ":12, "ㅜ":13, "ㅝ":14, "ㅞ":15, "ㅟ":16, "ㅠ":17, "ㅡ":18, "ㅢ":19, "ㅣ":20}  # 21 글자
		self.varx["받침_vs_index"] = self.varx["third_letter_vs_index"] = {"":0, "ㄱ":1, "ㄲ":2, "ㄳ":3, "ㄴ":4, "ㄵ":5, "ㄶ":6, "ㄷ":7, "ㄹ":8, "ㄺ":9, "ㄻ":10, "ㄼ":11, "ㄽ":12, "ㄾ":13, "ㄿ":14, "ㅀ":15,"ㅁ":16, "ㅂ":17, "ㅄ":18, "ㅅ":19, "ㅆ":20, "ㅇ":21, "ㅈ":22, "ㅊ":23, "ㅋ":24, "ㅌ":25, "ㅍ":26, "ㅎ":27}  # 28 글자, 없는것 포함
		self.varx["영어서수_1~31"] = ['1ST', '2ND', '3RD', '4TH', '5TH', '6TH', '7TH', '8TH', '9TH', '10TH', '11TH', '12TH', '13TH', '14TH', '15TH', '16TH', '17TH', '18TH', '19TH', '20TH', '21ST', '22ND', '23RD', '24TH', '25TH', '26TH', '27TH', '28TH', '29TH', '30TH', '31ST']
		self.varx["영어서수_vs_no"] = self.varx["num_th_vs_no"] = {'1st': 1, '2nd': 2, '3rd': 3, '4th': 4, '5th': 5, '6th': 6, '7th': 7, '8th': 8, '9th': 9, '10th': 10,
		          '11th': 11, '12th': 12, '13th': 13, '14th': 14, '15th': 15, '16th': 16, '17th': 17, '18th': 18,
		          '19th': 19, '20th': 20, '21st': 21, '22nd': 22, '23RD': 23, '24th': 24, '25th': 25, '26th': 26,
		          '27th': 27, '28th': 28, '29th': 29, '30th': 30, '31st': 31}
		self.varx["num_vs_day_th"] = {1: '1st', 2: '2nd', 3: '3rd', 22:'22nd', 23: '23RD'}

		self.varx["text_option"] = {"scolor": "", "size": "", "underline": "", "italic": "", "bold": "",
									"strikethrough": "",
									"name": "", "align": "", "subscript": "", "superscript": ""}

		self.varx["direction_vs_enum"] = {"": 1, "first": 1, "last": -1, "next": 2, "previous": 3, "relative": 2,
										  "absolute": 1, }

		self.varx["line_vs_enum"] = {"-.": 5, "-..": 6, ".": 2, "=": 7, "-": 1}

		self.varx["linewidth_vs_enum"] = {"yel": 7, "25": 2, "50": 4, "75": 6, "100": 8, "150": 12, "225": 18, "300":
			24, "450": 36, "600": 48, "---": 2, "--": 4, "-": 6, "basic": 8,
										  "": 8, "+": 12, "++": 18, "+++": 24, "++++": 36, "+++++": 48}

		self.varx["base_cell_data"] = {
			"sheet_name": "",
			"xyxy": [100, 100, 0, 0],
			"color": 10058239,
			"line_style": "-.",
			"thickness": 0.5,
			"transparency": 0,
			"head_style": ">",
			"head_length": "0",
			"head_width": "0",
			"tail_style": ">",
			"tail_length": "0",
			"tail_width": "0",
		}

		self.varx["shape_type_dic"] = {
			# 1. 기본 도형
			"rectangle": 1, "rounded_rect": 5, "oval": 9, "diamond": 4, "triangle": 7, "right_triangle": 8, "hexagon": 10,
			"rect": 1, "둥근사각형": 5, "circle": 9, "마름모": 4, "삼각형": 7, "직각삼각형": 8, "육각형": 10,
			"사각형": 1, "네모": 1, "모서리가둥근직사각형": 5, "원": 9, "동그라미": 9, "타원": 9, "이등변삼각형": 7,
			# 2. 화살표 (BlOCK Arrows)
			"arrow": 33, "화살표": 33, "arrow_right": 33, "오른쪽화살표": 33, "arrow_left": 34, "왼쪽화살표": 34, "arrow_up": 35,
			"위쪽화살표": 35, "arrow_down": 36, "아래쪽화살표": 36,
			# 3. 멸 및 현수막
			"star_5": 92, "speech_bubble": 2, "별": 92, "말풍선": 2, "별5": 92,
			# 4. 수식/흐름도 기흐
			"plus": 11, "minus": 11, "no_symbol": 19, "더하기": 11, "십자가": 11, "금지": 19, "원형금지": 19,
			# 5. 도형 설명선 (텍스트 상자 형태)
			"rect_callout": 105, "사각형설명선": 105, "네모설명선": 105, "설명선": 105, "rounded_callout": 106, "둥근설명선": 106,
			"둥근사각형설명선": 106, "oval_callout": 107, "원형설명선": 107, "타원설명선": 107, "동그라미설명선": 107, "cloud_callout": 108,
			"구름설명선": 108, "구름": 108, "생각풍선": 108,
			# 6. 선형 설명선 (테두리만 있거나 선으로 연결된 형태)
			"line_callout _1": 109, "선설명선1": 109, "직선설명선": 109,
			# 7.직선 꼬리
			"line_callout_2": 113, "선설명선2": 113, "꺾인선설명선": 113,
			# 8.한번 격인 꼬리
			"line_callout_3": 117, "선설명선3": 117,  # 두번 꺾인 꼬리
			# 9. 텍스트 강조용 (가장자리가 없는 설명선 등)
			"no_border_callout": 110, "테두리없는설명선": 110}

		self.varx["line_style_vs_enum"] = self.varx["check_line_style"] = {"실선": 1, "일반": 1, "_": 1, "basic": 1, "": 1,
																		   "-": -4115, "-.": 4, "-..": 5, ".": -4118, "점선": -4118,
																		   "=": -4119, "no": -4142, "/": 13, }

		self.varx["chart_element_vs_enum"] = {
			"ChartFloorNone": 1200, "ChartFloorShow": 1201, "ChartTitleAboveChart": 2, "ChartTitleCenteredOverlay": 1,
			"ChartTitleNone": 0, "ChartWallNone": 1100, "ChartWallShow": 1101, "DataLabelBestFit": 210,
			"DataLabelBottom": 209, "DataLabelCallout": 211, "DataLabelCenter": 202, "DataLabelInsideBase": 204,
			"DataLabelInsideEnd": 203, "DataLabelLeft": 206, "DataLabelNone": 200,
			"DataLabelOutSideEnd": 205, "DataLabelRight": 207, "DataLabelShow": 201,
			"DataLabelTop": 208, "DataTableNone": 500, "DataTableShow": 501,
			"DataTableWithLegendKeys": 502, "ErrorBarNone": 700, "ErrorBarPercentage": 702,
			"ErrorBarStandardDeviation": 703, "ErrorBarStandardError": 701, "LegendBottom": 104,
			"LegendLeft": 103, "LegendLeftOverlay": 106,
			"LegendNone": 100, "LegendRight": 101,
			"LegendRightOverlay": 105, "LegendTop": 102,
			"LineDropHiLoLine": 804, "LineDropLine": 801,
			"LineHiLoLine": 802, "LineNone": 800,
			"LineSeriesLine": 803, "PlotAreaNone": 1000,
			"PlotAreaShow": 1001, "PrimaryCategoryAxisBillions": 374,
			"PrimaryCategoryAxisLogScale": 375, "PrimaryCategoryAxisMillions": 373, "PrimaryCategoryAxisNone": 348,
			"PrimaryCategoryAxisReverse": 351, "PrimaryCategoryAxisShow": 349, "PrimaryCategoryAxisThousands": 372,
			"PrimaryCategoryAxisTitleAdjacentToAxis": 301, "PrimaryCategoryAxisTitleBelowAxis": 302, "PrimaryCategoryAxisTitleHorizontal": 305,
			"PrimaryCategoryAxisTitleNone": 300, "PrimaryCategoryAxisTitleRotated": 303,
			"PrimaryCategoryAxisTitleVertical": 304, "PrimaryCategoryAxisWithoutLabels": 350,
			"PrimaryCategoryGridLinesMajor": 334, "PrimaryCategoryGridLinesMinor": 333,
			"PrimaryCategoryGridLinesMinorMajor": 335, "PrimaryCategoryGridLinesNone": 332,
			"PrimaryValueAxisBillions": 356, "PrimaryValueAxisLogScale": 357,
			"PrimaryValueAxisMillions": 355, "PrimaryValueAxisNone": 352,
			"PrimaryValueAxisShow": 353, "PrimaryValueAxisThousands": 354,
			"PrimaryValueAxisTitleAdjacentToAxis": 307, "PrimaryValueAxisTitleBelowAxis": 308,
			"PrimaryValueAxisTitleHorizontal": 311, "PrimaryValueAxisTitleNone": 306,
			"PrimaryValueAxisTitleRotated": 309, "PrimaryValueAxisTitleVertical": 310,
			"PrimaryValueGridLinesMajor": 330, "PrimaryValueGridLinesMinor": 329,
			"PrimaryValueGridLinesMinorMajor": 331, "PrimaryValueGridLinesNone": 328, "SecondaryCategoryAxisBillions": 378,
			"SecondaryCategoryAxisLogScale": 379, "SecondaryCategoryAxisMillions": 377,
			"SecondaryCategoryAxisNone": 358, "SecondaryCategoryAxisReverse": 361,
			"SecondaryCategoryAxisShow": 359, "SecondaryCategoryAxisThousands": 376,
			"SecondaryCategoryAxisTitleAdjacentToAxis": 313, "SecondaryCategoryAxisTitleBelowAxis": 314,
			"SecondaryCategoryAxisTitleHorizontal": 317, "SecondaryCategoryAxisTitleNone": 312,
			"SecondaryCategoryAxisTitleRotated": 315, "SecondaryCategoryAxisTitleVertical": 316,
			"SecondaryCategoryAxisWithoutLabels": 360, "SecondaryCategoryGridLinesMajor": 342,
			"SecondaryCategoryGridLinesMinor": 341, "SecondaryCategoryGridLinesMinorMajor": 343,
			"SecondaryCategoryGridLinesNone": 340, "SecondaryValueAxisBillions": 366,
			"SecondaryValueAxisLogScale": 367, "SecondaryValueAxisMillions": 365,
			"SecondaryValueAxisNone": 362, "SecondaryValueAxisShow": 363,
			"SecondaryValueAxisThousands": 364, "SecondaryValueAxisTitleAdjacentToAxis": 319,
			"SecondaryValueAxisTitleBelowAxis": 320, "SecondaryValueAxisTitleHorizontal": 323,
			"SecondaryValueAxisTitleNone": 318, "SecondaryValueAxisTitleRotated": 321,
			"SecondaryValueAxisTitleVertical": 322, "SecondaryValueGridLinesMajor": 338,
			"SecondaryValueGridLinesMinor": 337, "SecondaryValueGridLinesMinorMajor": 339,
			"SecondaryValueGridLinesNone": 336, "SeriesAxisGridLinesMajor": 346,
			"SeriesAxisGridLinesMinor": 345, "SeriesAxisGridLinesMinorMajor": 347,
			"SeriesAxisGridLinesNone": 344, "SeriesAxisNone": 368,
			"SeriesAxisReverse": 371, "SeriesAxisShow": 369,
			"SeriesAxisTitleHorizontal": 327, "SeriesAxisTitleNone": 324,
			"SeriesAxisTitleRotated": 325, "SeriesAxisTitleVertical": 326,
			"SeriesAxisWithoutLabeling": 370, "TrendlineAddExponential": 602,
			"TrendlineAddLinear": 601, "TrendlineAddLinearForecast": 603,
			"TrendlineAddTwoPeriodMovingAverage": 604, "TrendlineNone": 600,
			"UpDownBarsNone": 900, "UpDownBarsShow": 901,
		}

		self.varx["chart_style_vs_enum"] = {
			"3DArea": -4098, "3DAreaStacked": 78, "3DAreaStacked100": 79,
			"3DBarClustered": 60, "3DBarStacked": 61, "3DBarStacked100": 62,
			"3DColumn": -4100, "3DColumnClustered": 54, "3DColumnStacked": 55,
			"3DColumnStacked100": 56, "3DLine": -4101, "3DPie": -4102,
			"3DPieExploded": 70, "Area": 1, "AreaStacked": 76,
			"AreaStacked100": 77, "BarClustered": 57, "BarOfPie": 71,
			"BarStacked": 58, "BarStacked100": 59, "Bubble": 15,
			"Bubble3DEffect": 87, "ColumnClustered": 51, "ColumnStacked": 52,
			"ColumnStacked100": 53, "ConeBarClustered": 102, "ConeBarStacked": 103,
			"ConeBarStacked100": 104, "ConeCol": 105, "ConeColClustered": 99,
			"ConeColStacked": 100, "ConeColStacked100": 101, "CylinderBarClustered": 95,
			"CylinderBarStacked": 96, "CylinderBarStacked100": 97, "CylinderCol": 98,
			"CylinderColClustered": 92, "CylinderColStacked": 93, "CylinderColStacked100": 94,
			"Doughnut": -4120, "DoughnutExploded": 80, "Line": 4,
			"LineMarkers": 65, "LineMarkersStacked": 66, "LineMarkersStacked100": 67,
			"LineStacked": 63, "LineStacked100": 64, "Pie": 5,
			"PieExploded": 69, "PieOfPie": 68, "PyramidBarClustered": 109,
			"PyramidBarStacked": 110, "PyramidBarStacked100": 111, "PyramidCol": 112,
			"PyramidColClustered": 106, "PyramidColStacked": 107, "PyramidColStacked100": 108,
			"Radar": -4151, "RadarFilled": 82, "RadarMarkers": 81,
			"RegionMap": 140, "StockHLC": 88, "StockOHLC": 89,
			"StockVHLC": 90, "StockVOHLC": 91, "Surface": 83,
			"SurfaceTopView": 85, "SurfaceTopViewWireframe": 86, "SurfaceWireframe": 84,
			"XYScatter": -4169, "XYScatterLines": 74, "XYScatterLinesNoMarkers": 75,
			"XYScatterSmooth": 72, "XYScatterSmoothNoMarkers": 73, }

		self.varx["shape_name_vs_enum"] = {
			"mixed": -2, "rectangle": 1, "직사각형": 1, "parallelogram": 2, "평행사변형": 2,
			"trapezoid": 3, "사다리꼴": 3, "diamond": 4, "다이아몬드": 4, "roundedrectangle": 5,
			"둥근모서리사각형": 5, "octagon": 6, "팔각형": 6, "isoscelestriangle": 7,
			"이등변삼각형": 7, "righttriangle": 8, "직각삼각형": 8, "oval": 9, "타원": 9,
			"hexagon": 10, "육각형": 10, "cross": 11, "십자형": 11, "regularpentagon": 12,
			"오각형": 12, "can": 13, "원통형": 13, "cube": 14, "정육면체": 14, "bevel": 15,
			"빗면사각형": 15, "foldedcorner": 16, "모서리접힌사각형": 16,
			"smileyface": 17, "웃는얼굴": 17, "donut": 18,
			"원형": 18, "nosymbol": 19, "blockarc": 20,
			"막힌원호": 20, "heart": 21, "하트": 21,
			"lightningbolt": 22, "번개": 22, "sun": 23,
			"해": 23, "moon": 24, "달": 24,
			"arc": 25, "원호": 25, "doublebracket": 26,
			"양쪽대괄호": 26, "doublebrace": 27, "양쪽중괄호": 27,
			"plaque": 28, "배지": 28, "leftbracket": 29,
			"왼쪽대괄호": 29, "rightbracket": 30, "오른쪽대괄호": 30,
			"leftbrace": 31, "왼쪽중괄호": 31, "rightbrace": 32,
			"오른쪽중괄호": 32, "rightarrow": 33, "오른쪽화살표": 33,
			"leftarrow": 34, "왼쪽화살표": 34, "uparrow": 35,
			"위쪽화살표": 35, "downarrow": 36, "아래쪽화살표": 36,
			"leftrightarrow": 37, "왼쪽오른쪽화살표": 37, "updownarrow": 38,
			"위쪽아래쪽화살표": 38, "quadarrow": 39, "상하좌우화살표": 39,
			"leftrightuparrow": 40, "상좌우화살표": 40, "bentarrow": 41,
			"굽음화살표": 41, "uturnarrow": 42, "u턴화살표": 42,
			"leftuparrow": 43, "좌상화살표": 43, "bentuparrow": 44,
			"위로굽음화살표": 44, "curvedrightarrow": 45, "curvedleftarrow": 46,
			"curveduparrow": 47, "curveddownarrow": 48, "stripedrightarrow": 49,
			"notchedrightarrow": 50, "pentagon": 51, "chevron": 52,
			"rightarrowcallout": 53, "leftarrowcallout": 54, "uparrowcallout": 55,
			"downarrowcallout": 56, "leftrightarrowcallout": 57, "updownarrowcallout": 58,
			"quadarrowcallout": 59, "circulararrow": 60, "flowchartprocess": 61,
			"flowchartalternateprocess": 62, "flowchartdecision": 63, "flowchartdata": 64,
			"flowchartpredefinedprocess": 65, "flowchartinternalstorage": 66, "flowchartdocument": 67,
			"flowchartmultidocument": 68, "flowchartterminator": 69, "flowchartpreparation": 70,
			"flowchartmanualinput": 71, "flowchartmanualoperation": 72, "flowchartconnector": 73,
			"flowchartoffpageconnector": 74, "flowchartcard": 75, "flowchartpunchedtape": 76,
			"flowchartsummingjunction": 77, "flowchartor": 78, "flowchartcollate": 79,
			"flowchartsort": 80, "flowchartextract": 81, "flowchartmerge": 82,
			"flowchartstoreddata": 83, "flowchartdelay": 84, "flowchartsequentialaccessstorage": 85,
			"flowchartmagneticdisk": 86, "flowchartdirectaccessstorage": 87, "flowchartdisplay": 88,
			"explosion1": 89, "explosion2": 90, "4pointstar": 91,
			"5pointstar": 92, "8pointstar": 93, "16pointstar": 94,
			"24pointstar": 95, "32pointstar": 96, "upribbon": 97,
			"downribbon": 98, "curvedupribbon": 99, "curveddownribbon": 100,
			"verticalscroll": 101, "horizontalscroll": 102, "wave": 103,
			"doublewave": 104, "rectangularcallout": 105, "roundedrectangularcallout": 106,
			"ovalcallout": 107, "cloudcallout": 108, "linecallout1": 109, "linecallout2": 110,
			"linecallout3": 111, "linecallout4": 112, "linecallout1accentbar": 113,
			"linecallout2accentbar": 114, "linecallout3accentbar": 115, "linecallout4accentbar": 116,
			"linecallout1noborder": 117, "linecallout2noborder": 118, "linecallout3noborder": 119,
			"linecallout4noborder": 120, "linecallout1borderandaccentbar": 121, "linecallout2borderandaccentbar": 122,
			"linecallout3borderandaccentbar": 123, "linecallout4borderandaccentbar": 124, "actionbuttoncustom": 125,
			"actionbuttonhome": 126, "actionbuttonhelp": 127, "actionbuttoninformation": 128,
			"actionbuttonbackorprevious": 129, "actionbuttonforwardornext": 130, "actionbuttonbeginning": 131,
			"actionbuttonend": 132, "actionbuttonreturn": 133, "actionbuttondocument": 134,
			"actionbuttonsound": 135, "actionbuttonmovie": 136, "balloon": 137,
			"notprimitive": 138, "flowchartofflinestorage": 139, "leftrightribbon": 140,
			"diagonalstripe": 141, "pie": 142, "nonisoscelestrapezoid": 143,
			"decagon": 144, "heptagon": 145, "dodecagon": 146,
			"6pointstar": 147, "7pointstar": 148, "10pointstar": 149,
			"12pointstar": 150, "round1rectangle": 151, "round2samerectangle": 152,
			"sniproundrectangle": 154, "snip1rectangle": 155, "snip2samerectangle": 156,
			"round2diagrectangle": 157, "snip2diagrectangle": 157, "frame": 158,
			"halfframe": 159, "tear": 160, "chord": 161,
			"corner": 162, "mathplus": 163, "mathminus": 164,
			"mathmultiply": 165, "mathdivide": 166, "mathequal": 167,
			"mathnotequal": 168, "cornertabs": 169, "squaretabs": 170,
			"plaquetabs": 171, "gear6": 172, "gear9": 173,
			"funnel": 174, "piewedge": 175, "leftcirculararrow": 176,
			"leftrightcirculararrow": 177, "swoosharrow": 178, "cloud": 179,
			"chartx": 180, "chartstar": 181, "chartplus": 182,
			"lineinverse": 183, "star": 147, "별": 147,
			"마름모": 4, "풍선": 137, "캔": 13,
			"구름": 179, "x": 11, "엑스": 11, "큐브": 14,
			"도넛": 18, "gear": 173, "기어": 173, "심장": 21,
			"십각형": 10, "arrow": 34, "화살": 34, "brace": 31,
			"대괄호": 31, "bracket": 29, "중괄호": 29, "원": 9,
			"파이": 142, "사각형": 1, "태양": 23, "눈물": 160,
			"파도": 103,

		}

		self.varx["check_line_position"] = {
			"\\": [5], "대각선왼쪽": [5],
			"/": [6], "대각선오른쪽": [6],
			"left": [7], "왼쪽": [7],
			"t": [8], "top": [8], "위쪽": [8],
			"b": [9], "bottom": [9], "아래쪽": [9],
			"r": [10], "right": [10], "오른쪽": [10],
			"|": [11], "h": [11], "inside-h": [11], "inh": [11], "안쪽세로": [11], "hor": [11],
			"-": [12], "v": [12], "inside-v": [12], "inv": [12], "안쪽가로": [12], "ver": [12],
			"in": [11, 12],
			"o": [7, 8, 9, 10], "테두리": [7, 8, 9, 10], "out": [7, 8, 9, 10], "outside": [7, 8, 9, 10],
			"a": [7, 8, 9, 10, 11, 12], "all": [7, 8, 9, 10, 11, 12], "전부": [7, 8, 9, 10, 11, 12],
			"total": [5, 6, 7, 8, 9, 10, 11, 12],
			"l": [7],
			"": [7, 8, 9, 10], "basic": [7, 8, 9, 10],
			"사각": [7, 8, 9, 10], "외곽": [7, 8, 9, 10],
		}

		self.varx["line_end_style_vs_enum"] = {
			"msoArrowheadNone": 1, "msoArrowheadTriangle": 2, "msoArrowheadOpen": 3, "msoArrowheadStealth": 4,
			"msoArrowheadDiamond": 5, "msoArrowheadOval": 6,
			"": 1, "<": 2, ">o": 3, ">>": 4, ">": 2, "<>": 5, "o": 6,
			"basic": 1, "none": 1, "triangle": 2, "open": 3, "stealth": 4, "diamond": 5, "oval": 6,
			"msoArrowheadNarrow": 1, "msoArrowheadWidthMedium": 2, "msoArrowheadWide": 3,
			"msoArrowheadShort": 1, "msoArrowheadLengthMedium": 2, "msoArrowheadLong": 3,
			"short": 1, "narrow": 1, "medium": 2, "long": 3, "wide": 3,
			"-1": 1, "0": 2, "1": 3,
			"dash": 4, "dashdot": 5, "dashdotdot": 6, "rounddot": 3, "longdash": 7, "longdashdot": 8,
			"longdashdotdot": 9, "squaredot": 2, }

		self.varx["table_line_position_vs_enum"] = {"bottom": -3, "diagonaldown": -7, "diagonalup": -8, "left": -2,
													"insideh": -5, "insidev": -6, "top": -1, "right": -4,
													"b": -3, "\\": -7, "//": -8, "l": -2, "h": -5, "v": -6, "t": -1, "r": -4}

		self.varx["table_line_style_vs_enum"] = {"-.": 5, "-..": 6, "-": 3, ".": 2, "=": 7, "no": 0, "None": 0,
												 "basic": 1, "": 1}

		self.varx["position_vs_enum"] = {"all": ["l", "r", "t", "b", "v", "h", "\\", "//"], "b": ["b"], "\\": ["\\"],
										 "//": ["//"],
										 "left": ["l"], "horizontal": ["h"], "vertical": ["v"], "top": ["t"],
										 "right": ["r"], "bottom": ["b"], "hori": ["h"], "ver": ["v"],
										 "l": ["l"], "h": ["h"], "v": ["v"], "t": ["t"], "r": ["r"],
										 "out": ["l", "r", "t", "b"], "basic": ["l", "r", "t", "b", "v", "h"],
										 "": ["l", "r", "t", "b", "v", "h"], }

		self.varx["check_line_thickness"] = {"hairline": 1, "t-2": 1, '매우가는': 1, "매우가는선": 1,
											 "thin": 2, '가는': 2, "t-1": 2, "basic": -4138,
											 "thickness": -4138, "기본두께": -4138, "기본굵기": -4138, "기본선": -4138, "t0": -4138, "t": -4138,
											 "thick": 4, "굵은선": 4, "굵은": 4, "t1": 4, }

		self.varx["base_cell_data"] = {
			"sheet_name": "",
			"xyxy": [100, 100, 0, 0],
			"color": 10058239,
			"line_style": "-.",
			"thickness": 0.5,
			"transparency": 0,
			"head_style": ">",
			"head_length": "0",
			"head_width": "0",
			"tail_style": ">",
			"tail_length": "0",
			"tail_width": "0",
		}
		self.varx["letter_type_dic"] = {"line": "line", "줄": "line", "한줄": "line", "라인": "line",
								"paragraph": "paragraph", "패러그래프": "paragraph", "문단": "paragraph", "para": "paragraph",
								"word": "word", "단어": "word", "워드": "word",
								"sentence": "sentence", "문장": "sentence",
								"char": "char", "글자": "char", "문자": "char", "character": "char",
								"cell": "cell",
								"column": "column", "col": "column",
								"row": "row",
								"item": "item",
								"셀": "cell", "컬럼": "column", "아이템": "item", "파라그래프": "paragraph",
								"파라": "paragraph", "가로": "row", "섹션": "section", "스토리": "story",
								"section": "section", "story": "story", "table": "table", "테이블": "table",
								}

		self.varx["line"] = {"-.": 5, "-..": 6, "." :2, "=": 7, "-": 1}
		self.varx["color_index"] = {"red":6	, "bla":1,"blu":2, "basic":0, "":0, "gra":16, "gre":11, "pin":5,"vio":12,"whi":8,"yel":7}
		self.varx["color_24bit"] = {"aqu":13421619,"":-16777216,"bla":0,"blu":16711680,"bro":13209
											,"gre":32768,"ind":10040115,"ora":26367,"pin":16711935,"red":255
											,"vio":8388736,"whi":16777215,"yel":65535}
		self.varx["line_width"] = {"yel":7,"25":2,"50":4,"75":6,"100":8,"150":12,"225":18,"300":24,"450":36
										   ,"600":48,"---":2,"--":4,"-":6,"basic":8,"":8,"+":12,"++":18
										   ,"+++":24,"++++":36,"+++++":48}
		self.varx["letter_type_vs_enum"] = self.varx["letter_type"] = {"cell": 12, "char":1, "word":2, "line":5, "sentence" : 3, "para": 4,
									"character":1,"column":9,"item":16,"paragraph":4,"row":10,"section":8,"story":6,"table":15,
											"wdCell": 12, "wdColumn": 9, "wdRow": 10, "wdTable": 15, "wdCharacte": 1,
											"wdWord": 2,
											"wdCharacterFormatting": 13, "wdItem": 16, "wdLine": 5, "wdSentence": 3,
											"wdParagraph": 4,
											"wdParagraphFormatting": 14, "wdScreen": 7, "wdSection": 8, "wdStory": 6,
											"wdWindow": 11,
											}
		self.varx["goto"] = {"wdGoToAbsolute": 1,"wdGoToFirst": 1,"wdGoToLast": -1,"wdGoToNext": 2
			,"wdGoToPrevious": 3,"wdGoToRelative": 2 ,"wdGoToBookmark": -1 ,"wdGoToComment": 6,"wdGoToEndnote": 5,
			"wdGoToEquation": 10,"wdGoToField": 7,"wdGoToFootnote": 4,"wdGoToGrammaticalError": 14,"wdGoToGraphic": 8
		,"wdGoToHeading": 11,"wdGoToLine": 3,"wdGoToObject": 9,"wdGoToPage": 1,"wdGoToPercent": 12,"wdGoToProofreadingError": 15
		,"wdGoToSection": 0,"wdGoToSpellingError": 13,"wdGoToTable": 2}

		self.varx["goto_vs_enum"] = {
			"wdGoToAbsolute": 1, "wdGoToFirst": 1, "wdGoToLast": -1, "wdGoToNext": 2
			, "wdGoToPrevious": 3, "wdGoToRelative": 2, "wdGoToBookmark": -1, "wdGoToComment": 6, "wdGoToEndnote": 5,
			"wdGoToEquation": 10, "wdGoToField": 7, "wdGoToFootnote": 4, "wdGoToGrammaticalError": 14,
			"wdGoToGraphic": 8
			, "wdGoToHeading": 11, "wdGoToLine": 3, "wdGoToObject": 9, "wdGoToPage": 1, "wdGoToPercent": 12,
			"wdGoToProofreadingError": 15
			, "wdGoToSection": 0, "wdGoToSpellingError": 13, "wdGoToTable": 2,
			"absolute": 1, "first": 1, "Last": -1, "next": 2
			, "previous": 3, "relative": 2, "bookmark": -1, "comment": 6, "endnote": 5,
			"equation": 10, "field": 7, "footnote": 4, "grammaticalerror": 14, "graphic": 8
			, "heading": 11, "line": 3, "object": 9, "page": 1, "percent": 12, "proofreadingerror": 15
			, "section": 0, "spellingError": 13, "table": 2
		}

		self.varx["holiday_list"] = self.varx["휴일"] = [
			[1988, 9, 17, 1, "양", "", "", "임시공휴일"],
			[2006, 9, 6, 1, "양", "", "", "임시공휴일"],
			[2015, 8, 14, 1, "양", "", "", "임시공휴일"],
			[2016, 5, 6, 1, "양", "", "", "임시공휴일"],
			[2017, 10, 2, 1, "양", "", "", "임시공휴일"],
			[2020, 8, 17, 1, "양", "", "", "임시공휴일"],
			[2025, 1, 27, 1, "양", "", "", "임시공휴일"],
			[1948, 7, 20, 1, "양", "", "", "대통령선거"],
			[1952, 8, 5, 1, "양", "", "", "대통령선거"],
			[1956, 5, 15, 1, "양", "", "", "대통령선거"],
			[1960, 3, 15, 1, "양", "", "", "대통령선거"],
			[1960, 8, 12, 1, "양", "", "", "대통령선거"],
			[1963, 10, 15, 1, "양", "", "", "대통령선거"],
			[1967, 5, 3, 1, "양", "", "", "대통령선거"],
			[1971, 4, 27, 1, "양", "", "", "대통령선거"],
			[1972, 12, 23, 1, "양", "", "", "대통령선거"],
			[1978, 7, 6, 1, "양", "", "", "대통령선거"],
			[1979, 12, 6, 1, "양", "", "", "대통령선거"],
			[1980, 8, 27, 1, "양", "", "", "대통령선거"],
			[1981, 2, 25, 1, "양", "", "", "대통령선거"],
			[1987, 12, 16, 1, "양", "", "", "대통령선거"],
			[1992, 12, 18, 1, "양", "", "", "대통령선거"],
			[1997, 12, 18, 1, "양", "", "", "대통령선거"],
			[2002, 12, 19, 1, "양", "", "", "대통령선거"],
			[2007, 12, 19, 1, "양", "", "", "대통령선거"],
			[2012, 12, 19, 1, "양", "", "", "대통령선거"],
			[2017, 5, 9, 1, "양", "", "", "대통령선거"],
			[2022, 3, 9, 1, "양", "", "", "대통령선거"],
			[2025, 6, 3, 1, "양", "", "", "대통령선거"],
			[1948, 5, 10, 1, "양", "", "", "국회의원선거"],
			[1950, 5, 30, 1, "양", "", "", "국회의원선거"],
			[1954, 5, 20, 1, "양", "", "", "국회의원선거"],
			[1958, 5, 2, 1, "양", "", "", "국회의원선거"],
			[1960, 7, 29, 1, "양", "", "", "국회의원선거"],
			[1963, 11, 26, 1, "양", "", "", "국회의원선거"],
			[1967, 6, 8, 1, "양", "", "", "국회의원선거"],
			[1973, 2, 27, 1, "양", "", "", "국회의원선거"],
			[1978, 12, 12, 1, "양", "", "", "국회의원선거"],
			[1981, 3, 25, 1, "양", "", "", "국회의원선거"],
			[1985, 2, 12, 1, "양", "", "", "국회의원선거"],
			[1988, 4, 26, 1, "양", "", "", "국회의원선거"],
			[1992, 3, 24, 1, "양", "", "", "국회의원선거"],
			[1996, 4, 11, 1, "양", "", "", "국회의원선거"],
			[2000, 4, 13, 1, "양", "", "", "국회의원선거"],
			[2004, 4, 15, 1, "양", "", "", "국회의원선거"],
			[2008, 4, 9, 1, "양", "", "", "국회의원선거"],
			[2012, 4, 11, 1, "양", "", "", "국회의원선거"],
			[2016, 4, 13, 1, "양", "", "", "국회의원선거"],
			[2020, 4, 15, 1, "양", "", "", "국회의원선거"],
			[2024, 4, 10, 1, "양", "", "", "국회의원선거"],
			[1995, 6, 27, 1, "양", "", "", "전국동시지방선거"],
			[1998, 6, 4, 1, "양", "", "", "전국동시지방선거"],
			[2002, 6, 13, 1, "양", "", "", "전국동시지방선거"],
			[2006, 5, 31, 1, "양", "", "", "전국동시지방선거"],
			[2010, 6, 2, 1, "양", "", "", "전국동시지방선거"],
			[2014, 6, 4, 1, "양", "", "", "전국동시지방선거"],
			[2016, 4, 13, 1, "양", "", "", "전국동시지방선거"],
			[2018, 6, 13, 1, "양", "", "", "전국동시지방선거"],
			[2022, 6, 1, 1, "양", "", "", "전국동시지방선거"],
			[2026, 6, 3, 1, "양", "", "", "전국동시지방선거"],
			[2030, 6, 12, 1, "양", "", "", "전국동시지방선거"], ]

		self.varx["solar_holiday_list"] = self.varx["기간-양력휴일"] = [
			[[1949, 1990], 1, 1, 1, "양", "", "", "양력설"],
			[[1949, 1990], 1, 2, 1, "양", "", "", "양력설"],
			[[1949, 1990], 1, 3, 1, "양", "", "", "양력설"],
			[[1991, 1999], 1, 1, 1, "양", "", "", "양력설"],
			[[1991, 1999], 1, 2, 1, "양", "", "", "양력설"],
			[[2013, 9999], 1, 1, 1, "양", "", "", "새해 첫날"],
			[[1949, 1959], 4, 5, 1, "양", "", "", "식목일"],
			[[1960, 1960], 3, 15, 1, "양", "", "", "사방의날"],
			[[1961, 2006], 4, 15, 1, "양", "", "", "식목일"],
			[[1949, 2008], 7, 17, 1, "양", "", "", "제헌절"],
			[[1950, 1975], 10, 24, 1, "양", "", "", "유엔의날"],
			[[1976, 1991], 10, 1, 1, "양", "", "", "국군의날"],
			[[1949, 2012], 3, 1, 1, "양", "", "", "3.1절"],
			[[2013, 9999], 3, 1, 1, "양", "", "토일", "3.1절"],
			[[1975, 2012], 5, 5, 1, "양", "", "", "어린이날"],
			[[2013, 9999], 5, 5, 1, "양", "", "토일", "어린이날"],
			[[1956, 9999], 6, 6, 1, "양", "", "", "현충일"],
			[[1949, 2012], 8, 15, 1, "양", "", "", "광복절"],
			[[2013, 9999], 8, 15, 1, "양", "", "토일", "광복절"],
			[[1949, 2012], 10, 3, 1, "양", "", "", "개천절"],
			[[2013, 9999], 10, 3, 1, "양", "", "토일", "개천절"],
			[[1946, 1989], 10, 9, 1, "양", "", "", "한글날"],
			[[2013, 9999], 10, 9, 1, "양", "", "토일", "한글날"],
			[[1994, 2012], 12, 25, 1, "양", "", "", "기독탄신일"],
			[[2013, 9999], 12, 25, 1, "양", "", "토일", "기독탄신일"], ]

		self.varx["lunar_holiday_list"] = self.varx["기간-음력휴일"] = [
			[[1985, 1988], 1, 1, 1, "음", "평달", "", "설날"],
			[[1989, 2012], 12, "말일", 1, "음", "윤달", "", "설날"],
			[[1989, 2012], 1, 1, 1, "음", "평달", "", "설날"],
			[[1989, 2012], 1, 2, 1, "음", "평달", "", "설날"],
			[[2013, 9999], 12, "말일", 1, "음", "윤달", "일", "설날"],
			[[2013, 9999], 1, 1, 1, "음", "평달", "일", "설날"],
			[[2013, 9999], 1, 2, 1, "음", "평달", "일", "설날"],
			[[1975, 9999], 4, 8, 1, "음", "평달", "토일", "부처님 오신 날"],
			[[1986, 1988], 8, 15, 1, "음", "평달", "", "추석"],
			[[1986, 1988], 8, 16, 1, "음", "평달", "", "추석"],
			[[1989, 2012], 8, 14, 1, "음", "평달", "", "추석", ""],
			[[1989, 2012], 8, 15, 1, "음", "평달", "", "추석", ""],
			[[1989, 2012], 8, 16, 1, "음", "평달", "", "추석", ""],
			[[2013, 9999], 8, 14, 1, "음", "평달", "일", "추석"],
			[[2013, 9999], 8, 15, 1, "음", "평달", "일", "추석"],
			[[2013, 9999], 8, 16, 1, "음", "평달", "일", "추석"],
		]

		self.varx["월_영어_short"] = self.varx["list_month_eng_short"] = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']
		self.varx["월_영어"] = self.varx["month"] = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december']
		self.varx["월_영어_vs_no"] = self.varx["month_vs_no"] = {'january': 1, 'february': 2, 'march': 3, 'april': 4, 'may': 5, 'june': 6, 'july': 7, 'august': 8, 'september': 9, 'october': 10,
															  'november': 11, 'december': 12}
		self.varx["월_영어_short_vs_no"] = self.varx["mon_vs_no"] = {'jan': 1, 'feb': 2, 'mar': 3, 'apr': 4, 'jun': 6, 'jul': 7, 'aug': 8, 'sep': 9, 'oct': 10, 'nov': 11, 'dec': 12}
		self.varx["월_영어_all_vs_no"] = self.varx["mon_eng_vs_no"] = self.varx["월_영어_vs_no"].update(self.varx["월_영어_short_vs_no"])
		self.varx["no_vs_월_영어"] = self.varx["no_vs_month"] = {1: 'january', 2: 'february', 3: 'march', 4: 'april', 5: 'may', 6: 'june', 7: 'july', 8: 'august', 9: 'september', 10: 'october',
															  11: 'november', 12: 'december'}
		self.varx["num_vs_day_th"] = {1: '1st', 2: '2nd', 3: '3rd', 22: '22nd', 23: '23RD'}
		self.varx["keyboard_name_vs_hex"] = {"LBUTTON" : 0x01 ,"RBUTTON" :  0x02 ,"CANCEL" :  0x03 ,
								"MBUTTON" :  0x04 ,"XBUTTON1" :  0x05 ,"XBUTTON2" :  0x06 ,"BACK" :  0x08 ,"TAB" :  0x09 ,"CLEAR" :  0x0C ,
								"RETURN" :  0x0D ,"SHIFT" :  0x10 ,"CONTROL" :  0x11 ,"MENU" :  0x12 ,"PAUSE" :  0x13 ,"CAPITAL" :  0x14 ,
								"HANGUEL" :  0x15 ,"KANA" :  0x15 ,"JUNJA" :  0x17 ,"FINAL" :  0x18 ,"KANJI" :  0x19 ,"HANJA" :  0x19 ,
								"ESCAPE" :  0x1B ,"CONVERT" :  0x1C ,"NONCONVERT" :  0x1D ,"ACCEPT" :  0x1E ,"MODECHANGE" :  0x1F ,"SPACE" :  0x20 ,
								"PRIOR" :  0x21,"NEXT" :  0x22 ,"END" :  0x23 ,"HOME" :  0x24 ,"LEFT" :  0x25 ,"UP" :  0x26 ,
								"RIGHT" :  0x27 ,"DOWN" :  0x28 ,"SELECT" :  0x29 ,"PRINT" :  0x2A ,"EXECUTE" :  0x2B ,"SNAPSHOT" :  0x2C ,
								"INSERT" :  0x2D ,"DELETE" :  0x2E ,"HELP" :  0x2F ,"LWIN" :  0x5B ,"RWIN" :  0x5C ,"APPS" :  0x5D ,
								"SLEEP" :  0x5F ,"NUMPAD0" :  0x60 ,"NUMPAD1" :  0x61 ,"NUMPAD2" :  0x62 ,"NUMPAD3" :  0x63 ,"NUMPAD4" :  0x64 ,
								"NUMPAD5" :  0x65 ,"NUMPAD6" :  0x66 ,"NUMPAD7" :  0x67 ,"NUMPAD8" :  0x68 ,"NUMPAD9" :  0x69 ,"MULTIPLY" :  0x6A ,
								"ADD" :  0x6B,"SEPARATOR" :  0x6C ,"SUBTRACT" :  0x6D ,"DECIMAL" :  0x6E ,"DEVIDE" :  0x6F ,"F1" :  0x70,
								"F2" :  0x71 ,"F3" :  0x72 ,"F4" :  0x73 ,"F5" :  0x74 ,"F6" :  0x75 ,"F7" :  0x76 ,
								"F8" :  0x77 ,"F9" :  0x78 ,"F10" :  0x79 ,"F11" :  0x7A ,"F12" :  0x7B ,"F13" :  0x7C ,
								"F14" :  0x7D ,"F15" :  0x7E ,"F16" :  0x7F ,"F17" :  0x80 ,"F18" :  0x81 ,"F19" :  0x82 ,
								"F20" :  0x83 ,"F21" :  0x84 ,"F22" :  0x85 ,"F23" :  0x86 ,"F24" :  0x87 ,"NUMLOCK" :  0x90 ,
								"SCROLL" :  0x91,"LSHIFT" :  0xA0 ,"RSHIFT" :  0xA1 ,"LCONTROL" :  0xA2 ,"RCONTROL" :  0xA3 ,"LMENU" :  0xA4 ,"RMENU" :  0xA5 }

		self.varx["keyboard_action_list_short"] = [
			'f1', 'f10', 'f11', 'f12', 'f2', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9',	'fn',
			'left', 'right','up', 'down','end', 'home','space', 'tab',
			'alt', 'altleft', 'altright', 'ctrl', 'ctrlleft', 'ctrlright','shift', 'shiftleft', 'shiftright', 'win', 'winleft', 'winright',
			'capslock', 'del', 'delete','backspace', 'enter', 'esc', 'escape', 'insert','numlock',
			'pagedown', 'pageup', 'pgdn', 'pgup',
			'hanguel', 'hangul', 'hanja',
			'printscreen', 'prtscr',
			]

		self.varx["key_dic"] = {
			"a": 0x41, "b": 0x42, "c": 0x43, "d": 0x44, "e": 0x45, "f": 0x46, "g": 0x47, "h": 0x48, "i": 0x49, "j": 0x4A, "k": 0x4B, "I": 0x4C, "m": 0x4D, "n": 0x4E, "o": 0x4F, "p": 0x50, "q": 0x51,
			"r": 0x52, "s": 0x53, "t": 0x54, "u": 0x55, "v": 0x56, "w": 0x57, "x": 0x58, "y": 0x59, "z": 0x5A, "alt": 0x12, "ctrl": 0x11, "shift": 0x10, "back": 0x08, "left": 0x25, "0": 0x30,
			"1": 0x31,
			"2": 0x32, "3": 0x33, "4": 0x34, "5": 0x35, "6": 0x36, "7": 0x37, "8": 0x38, "9": 0x39, "f1": 0x70, "f2": 0x71, "f3": 0x72, "f4": 0x73, "f5": 0x74, "f6": 0x75, "f7": 0x76, "f8": 0x77,
			"f9": 0x78, "f10": 0x79, "f11": 0x7A, "f12": 0x7B}
		self.varx["요일_한글"] = self.varx["week_kor"] ="월화수목금토일"
		self.varx["요일_영어"] = self.varx["week"] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
		self.varx["week_vs_enum"] = self.varx["요일_vs_no"] = self.varx["check_week_vs_no"] = {'monday': 1, 'tuesday': 2, 'wendsday': 3, 'thursday': 4, 'friday': 5, 'saturday': 6, 'sunday': 7,
										  'mon': 1, 'tue': 2, 'wen': 3, 'thu': 4, 'fri': 5,  'sat': 6, 'sun': 7,
										  '월요일': 1, '화요일': 2, '수요일': 3, '목요일': 4, '금요일': 5,  '토요일': 6, '일요일': 7,
										  '월': 1, '화': 2, '수': 3, '목': 4, '금': 5,  '토': 6, '일': 7
										  }
		self.varx["요일_한글_vs_no"] = self.varx["week_kor_vs_no"] = {'월요일': 1, '화요일': 2, '수요일': 3, '목요일': 4, '금요일': 5,  '토요일': 6, '일요일': 7}
		self.varx["요일_한글_short_vs_no"] = self.varx["week_kor_short_vs_no"] = { '월': 1, '화': 2, '수': 3, '목': 4, '금': 5,  '토': 6, '일': 7 }
		self.varx["요일_영어_vs_no"] = self.varx["week_vs_no"] = {'monday': 1, 'tuesday': 2, 'wendsday': 3, 'thursday': 4, 'friday': 5, 'saturday': 6, 'sunday': 7}
		self.varx["요일_영어_short_vs_no"] = self.varx["week_short_vs_no"] = {'mon': 1, 'tue': 2, 'wen': 3, 'thu': 4, 'fri': 5,  'sat': 6, 'sun': 7}


		self.varx["data"]["d1d_기계명한글_vs_기계명영어"] = {"밸브": "valve", "교반기": "agitator", "아지테이터": "agitator",
										   "송풍기": "blower", "블로어": "blower", "s/p": "spare part",
										   "케이블": "cable", "스페어파트": "spare part", "컨트롤밸브": "control valve",
										   "컨테이너": "container", "배터리": "battery", "차저": "charger", "액츄에이터": "actuator",
										   "다이아프램": "diaphgram", "압축기": "compressor", "컨트롤valve": "control valve",
										   "볼밸브": "ball valve", "호이스트": "hoist",
										   "판넬": "panel", "배관재": "piping", "파이프": "pipe",
										   "펌프": "pump", "보일러": "boiler",
										   "변압기": "transformer", "티타늄": "titanium", "라인드": "linned",
										   "탱크": "tank", "피팅류": "fitting", "컨트롤": "control",
										   "글로브": "globe", "열교환기": "heat exchanger",
										   "인버터판넬": "invertor panel", "스위치": "switch",
										   "산소측정기": "o2 analyzer", "수분분석기": "h20 analyzer",
										   "분석기": "analyzer", "인버터": "invertor",
										   "가스감지기": "gas detector", "가스검지기": "gas detector",
										   "가스켓": "gasket", "가스탐지기": "gas detector",
										   }

		self.varx["data"]["d2d_국가별정보_01"] = {
			"1번째열": {'Country': 'Russia', 'Capital': 'Moscow', 'Area(Sq.Miles)': 6601670, 'Population': 146171015},
			"2번째열": {'Country': 'Canada', 'Capital': 'Ottawa', 'Area(Sq.Miles)': 3855100, 'Population': 38048738},
			"3번째열": {'Country': 'China', 'Capital': 'Beijing', 'Area(Sq.Miles)': 3705407, 'Population': 1400050000},
			"4번째열": {'Country': 'United States of America', 'Capital': 'Washington, D.C.',
					 'Area(Sq.Miles)': 3796742, 'Population': 331449281},
			"5번째열": {'Country': 'Brazil', 'Capital': 'Brasília', 'Area(Sq.Miles)': 3287956,
					 'Population': 210147125},
			"6번째열": {'Country': 'Russia', 'Capital': 'Moscow', 'Area(Sq.Miles)': 6601670, 'Population': 146171015},
			"7번째열": {'Country': 'Canada', 'Capital': 'Ottawa', 'Area(Sq.Miles)': 3855100, 'Population': 38048738},
			"8번째열": {'Country': 'China', 'Capital': 'Beijing', 'Area(Sq.Miles)': 3705407, 'Population': 1400050000},
			"9번째열": {'Country': 'United States of America', 'Capital': 'Washington, D.C.',
					 'Area(Sq.Miles)': 3796742, 'Population': 331449281},
			"10번째열": {'Country': 'Brazil', 'Capital': 'Brasília', 'Area(Sq.Miles)': 3287956,
					  'Population': 210147125}
		}

		self.varx["data"]["d2d_엑셀영역자료_01"] = [
			{"x": 2, "y": 1, "kind_1": "basic", "kind_2": "date", "value": datetime.datetime(2002, 2, 2)},
			{"x": 2, "y": 3, "kind_1": "basic", "kind_2": "basic", "text": "값"},
			{"x": 2, "y": 5, "kind_1": "basic", "kind_2": "basic", "text": "값"},
			{"x": 2, "y": 7, "kind_1": "basic", "kind_2": "date", "value": datetime.datetime(2002, 2, 2)},
			{"x": 2, "y": 6, "kind_1": "tool_tip", "text": "tool_tip", "tool_tip": "툴팁입니다"},
			{"x": 5, "y": 3, "kind_1": "widget", "kind_2": "combo", "value": [1, 2, 3, 4, 5]},
			{"x": 5, "y": 5, "kind_1": "widget", "kind_2": "check_box", "checked": 1, "text": "check"},
			{"x": 5, "y": 7, "kind_1": "widget", "kind_2": "progress_bar", "value": 30},
			{"x": 5, "y": 8, "kind_1": "widget", "kind_2": "button", "caption": "button_1", "action": "action_def"},
			{"x": 10, "y": 10, "kind_1": "memo", "value": "memo memo"},
			{"x": 2, "y": 2, "kind_1": "memo", "value": "memo memo"},
			{"x": 7, "y": 3, "kind_1": "font_color", "value": [255, 63, 24]},
			{"x": 7, "y": 5, "kind_1": "background_color", "value": [255, 63, 24]}, ]

		self.varx["data"]["l1d_사전형식리스트_01"] = ["1: 가나다", "2: 라마바", "3: 사아자", "4: 차카파", "5: 가나다라마바", "17.: 사아자차카파파하", "8888: ABC 가나다라마", "9: 카파파하 BCD"]

		self.varx["data"]["l1d_전체자료형_01"] = ["1번째열_2번째", 'A1', "", None, [], (), '러시아_인가?', 'Capital', 'Moscow', '면적---', 6601670, '인구', "14617_1015"]

		self.varx["data"]["l1d_전체자료형_data_02"] = [12345, 12345.67, "1234567", 'A1B2', "가나다#$%@", None, [], (), 'abcd=efgh', 'Capital', 'Moscow', '면적---', 6601670, '인구', "14617_1015"]

		self.varx["data"]["l1d_문자형_날짜시간_01"] = [
			"20230301",
			'02/28/2023 02:30 PM',
			'180919 015519',
			'18/09/19 01:55:19',
			'2019-02-02 15:56:15.197103-05:00',
			'2018-06-29 08:15:27.243860',
			'2018-03-12T10:12:45Z',
			'2018-03-12',
			'2018-06-29 17:08:00.586525+00:00',
			'2018-06-29 17:08:00.586525+05:00',
			'Jun 28 2018 7:40AM',
			'Jun 28 2018 at 7:40AM',
			'September 18, 2017, 22:19:55',
			'Sun, 05/12/1999, 12:30PM',
			'Mon, 21 March, 2015',
			'Tuesday , 6th September, 2017 at 4:30pm'
		]

		self.varx["data"]["l1d_기계명영어_01"] = ['fitting', 'ball', 'flowmeter', 'on-off', 'battery', 'flange',
									 'electric', 'cable', 'gasket', 'seal', 'invertor', 'plate',
									 'level', 'gauge', 'gas', 'meter', 'centrifugal',
									 'magnetic', 'psv', 'titanium', 'pressure', 'motor',
									 'boiler', 'globe', 'gate', 'transformer',
									 'charger', 'blower', 'inverter',
									 'orifice', 'ph', 'ebd', 'mass', 'plug',
									 'diaphragm', 'dcs', 'detector', 'heater',
									 'hv', 'scale', 'instrument', 'ups',
									 'pg', 'reactor', 'compressor', 'vessel',
									 'butterfly', 'mechanical', 'element',
									 'tube', 'bellows', 'mixer', 'agitator',
									 'hose', 'diaphgram', 'separator', 'mcc',
									 'plc', 'frp', 'cooler', 'rubber',
									 'ngr', 'bolt', 'nut', 'rtd', 'bolt/nut',
									 'graphite', 'drum', 'relay', 'LV',
									 'palstic', 'rotary', 'sensor', 'microwave',
									 'column', 'screen', 'manual', 'balance',
									 'bundle', 'plastivc', 'acb',
									 'carbon', 'change', 'cell', 'strainer',
									 'type', 'cover', 'tg', 'membrane', 'prv',
									 'ptfe', 'check', 'nickel', 'analyzer',
									 'oil', 'water', 'temperature', 'glove',
									 'channel', 'ring', 'etfe', 'sheet', 'tms',
									 'scrubber', 'lift', 'oven', 'holder',
									 'container', 'cctv', 'vcb', 'condensor',
									 'casting', 'metal', 'rupture', 'disc',
									 'gear', 'screw', 'leak', '3-way', 'canned',
									 'package', 'dryer', 'feeder', '양극전극', 'bag',
									 'air', '농도계', 'pin', 'impeller', 'metering',
									 'kit', 'actuator', 'aircon',
									 'column', 'compressor', 'concentration',
									 'condenser', 'conductivity',
									 'connector', 'contcnrator',
									 'contol', 'control', 'control ball valve',
									 'control-valve', 'convection',
									 'conveyor', 'cooler', 'cover', 'crusher',
									 'cryogel', 'cw', 'cyclone', 'cylinder', 'd/p']

		self.varx["data"]["l1d_국가명_한글_01"] = ['가나', '가봉', '가이아나', '감비아', '과테말라', '그레나다', '그루지야',
									  '그리스', '기니', '기니비사우', '나미비아', '나우루', '나이지리아',
									  '남수단', '남아프리카 공화국', '네덜란드', '네팔', '노르웨이',
									  '뉴질랜드', '니제르', '니카라과', '대한민국', '덴마크', '도미니카 연방',
									  '도미니카 공화국', '독일', '동티모르', '라오스', '라이베리아', '라트비아',
									  '러시아', '레바논', '레소토', '루마니아', '룩셈부르크',
									  '르완다', '리비아', '리투아니아', '리히텐슈타인', '마다가스카르',
									  '마셜 제도', '말라위', '말레이시아', '말리', '멕시코', '모나코', '모로코', '모리셔스',
									  '모리타니', '모잠비크', '몬테네그로', '몰도바', '몰디브', '몰타', '몽골', '미국',
									  '미얀마', '미크로네시아 연방', '바누아투', '바레인', '바베이도스',
									  '바티칸', '바하마', '방글라데시', '베네수엘라', '베냉', '베트남',
									  '벨기에', '벨라루스', '벨리즈', '보스니아 헤르체고비나', '보츠와나',
									  '볼리비아', '부룬디', '부르키나파소', '부탄', '북마케도니아',
									  '북한', '불가리아', '브라질', '브루나이', '산마리노', '사모아',
									  '사우디아라비아', '상투메 프린시페',
									  '세네갈', '세르비아', '세이셸', '세인트루시아', '세인트빈센트 그레나딘',
									  '세인트키츠 네비스', '소말리아', '솔로몬 제도', '수단', '수리남',
									  '스리랑카', '스웨덴', '스위스', '스페인', '슬로바키아',
									  '슬로베니아', '시리아', '시에라리온',
									  '싱가포르', '아랍에미리트', '아르메니아', '아르헨티나',
									  '아이슬란드', '아이티', '아일랜드', '아제르바이잔',
									  '아프가니스탄', '안도라', '알바니아',
									  '알제리', '앙골라', '앤티가 바부다', '에스와티니', '에콰도르',
									  '에리트레아', '에스토니아', '에티오피아', '엘살바도르', '영국',
									  '예멘', '오만', '오스트레일리아', '오스트리아', '온두라스', '요르단',
									  '우간다', '우루과이', '우즈베키스탄', '우크라이나', '이라크',
									  '이란', '이스라엘', '이집트', '이탈리아', '인도', '인도네시아',
									  '일본', '자메이카', '잠비아', '적도 기니', '중앙아프리카공화국',
									  '중화인민공화국', '지부티', '짐바브웨', '차드', '체코', '칠레',
									  '카메룬', '카자흐스탄', '카보베르데', '카타르', '캄보디아', '캐나다',
									  '케냐', '코모로', '코스타리카', '코트디부아르', '쿠바', '쿠웨이트',
									  '콜롬비아', '콩고인민공화국', '콩고민주공화국', '크로아티아',
									  '키르기스스탄', '키리바시', '키프로스', '타지키스탄', '탄자니아', '태국',
									  '토고', '통가', '투르크메니스탄', '투발루', '튀니지', '튀르키예',
									  '트리니다드 토바고', '파나마', '파라과이', '파키스탄', '파푸아뉴기니',
									  '팔라우', '페루', '포르투갈', '폴란드', '프랑스', '피지',
									  '핀란드', '필리핀', '헝가리']

		self.varx["data"]["l1d_키보드_이름들_01"] = ['\\t', '\\n', '\\r', ' ', '!', '"', '#', '$', '%', '&', "'", '(',
									   ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7',
									   '8', '9', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`',
									   'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
									   'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~',
									   'accept', 'add', 'alt', 'altleft', 'altright', 'apps', 'backspace',
									   'browserback', 'browserfavorites', 'browserforward', 'browserhome',
									   'browserrefresh', 'browsersearch', 'browserstop', 'capslock', 'clear',
									   'convert', 'ctrl', 'ctrlleft', 'ctrlright', 'decimal', 'del', 'delete',
									   'divide', 'down', 'end', 'enter', 'esc', 'escape', 'execute', 'f1', 'f10',
									   'f11', 'f12', 'f13', 'f14', 'f15', 'f16', 'f17', 'f18', 'f19', 'f2', 'f20',
									   'f21', 'f22', 'f23', 'f24', 'f3', 'f4', 'f5', 'f6', 'f7', 'f8', 'f9',
									   'final', 'fn', 'hanguel', 'hangul', 'hanja', 'help', 'home', 'insert', 'junja',
									   'kana', 'kanji', 'launchapp1', 'launchapp2', 'launchmail',
									   'launchmediaselect', 'left', 'modechange', 'multiply', 'nexttrack',
									   'nonconvert', 'num0', 'num1', 'num2', 'num3', 'num4', 'num5', 'num6',
									   'num7', 'num8', 'num9', 'numlock', 'pagedown', 'pageup', 'pause', 'pgdn',
									   'pgup', 'playpause', 'prevtrack', 'print', 'printscreen', 'prntscrn',
									   'prtsc', 'prtscr', 'return', 'right', 'scrolllock', 'select', 'separator',
									   'shift', 'shiftleft', 'shiftright', 'sleep', 'space', 'stop', 'subtract', 'tab',
									   'up', 'volumedown', 'volumemute', 'volumeup', 'win', 'winleft', 'winright', 'yen',
									   'command', 'option', 'optionleft', 'optionright']

		self.varx["data"]["l1d_회사명_종류들_01"] = ["한강주식회사", "한강 주식회사", "한강㈜", "㈜한강", "한강(유)", "한강유한회사", "고려", "고구려", "백제", "신라", "고조선"]

		self.varx["data"]["l2d_기계명_영어_01"] = [
			['fitting', 'ball', 'flowmeter', 'on-off', 'battery', 'flange', 'electric', 'cable', 'gasket', 'seal', ],
			['invertor', None, 'level', 'gauge', 'gas', 'meter', 'centrifugal', 'magnetic', 'psv', 'titanium', ],
			['pressure', 'motor', 'boiler', 'globe', 'gate', 'transformer', 'charger', 'blower', 'inverter', ],
			['', 'ph', 'ebd', 'mass', 'plug', 'diaphragm', 'dcs', 'detector', 'heater', 'hv', 'scale', ],
			['', 'ups', 'pg', 'reactor', '', 'vessel', 'butterfly', 'mechanical', 'element', ],
			['tube', 'bellows', 'mixer', '', 'hose', 'diaphgram', 'separator', 'mcc', 'plc', 'frp', ],
			['', 'rubber', 'ngr', 'bolt', '', 'rtd', 'bolt/nut', 'graphite', 'drum', 'relay', 'LV', ],
			[None, 'rotary', 'sensor', None, 'column', 'screen', 'manual', 'balance', 'bundle', ],
			['plastivc', 'acb', 'carbon', None, 'cell', 'strainer', 'type', 'cover', 'tg', 'membrane', 'prv', ],
			['ptfe', 'check', 'nickel', 'analyzer', 'oil', 'water', 'temperature', 'glove', 'channel', 'ring', ],
			['etfe', 'sheet', 'tms', 'scrubber', 'lift', 'oven', 'holder', 'container', 'cctv', 'vcb', 'condensor', ],
			['casting', 'metal', 'rupture', 'disc', 'gear', 'screw', 'leak', '3-way', 'canned', 'package', 'dryer', ],
			['feeder', '양극전극', 'bag', 'air', '농도계', 'pin', 'impeller', 'metering', 'kit', 'actuator', 'aircon', ],
			['column', 'compressor', 'concentration', 'condenser', 'conductivity', 'connector', 'contcnrator', ],
			['contol', 'control', 'control ball valve', 'control-valve', 'convection', 'conveyor', 'cooler', ],
			['cover', 'crusher', 'cryogel', 'cw', 'cyclone', 'cylinder', 'd/p']]

		self.varx["data"]["l2d_함수실행용_자료_01"] = [["엑셀", "쓰기", "3333셀(2,2)에 값넣기", """excel.write_value_in_cell("", [2, 2], "테스트입니다")"""],
										["엑셀", "색칠하기", "셀(2,3)에 빨간색 넣기", """excel.paint_scolor_in_cell("", [2, 3], "red")"""],
										["엑셀", "색칠하기", "셀(3,3)에 빨간색 넣기", """excel.paint_scolor_in_cell("", [2, 3], "red")"""],
										["엑셀123", "색칠하기", "셀(3,3)에 빨간색 넣기", """excel.paint_scolor_in_cell("", [2, 3], "red")"""],
										["기타", "삭제", "선택영역에서 전체가 빈 모든 x열 삭제", """excel.delete_empty_xline_in_range("",[1,1,10,10])"""],
										["기타", "삭제", "선택영역에서 전체가 빈 모든 y열 삭제", """excel.delete_empty_yline_in_range("",[1,1,10,10])"""],
										]

		self.varx["data"]["l2d_국가명_한글_01"] = [['가나', '가봉', '가이아나', '감비아', '과테말라', '그레나다', '그루지야'],
									  ['그리스', '기니', '기니비사우', '나미비아', '나우루', '나이지리아', '남수단', '남아프리카 공화국'],
									  ['네덜란드', '네팔', '노르웨이', '뉴질랜드', '니제르', '니카라과', '덴마크', '도미니카 연방'],
									  ['도미니카 공화국', '독일', '동티모르', '라오스', '라이베리아', '라트비아', '러시아', '레바논'],
									  ['레소토', '루마니아', '룩셈부르크', '르완다', '리비아', '리투아니아', '리히텐슈타인', '마다가스카르'],
									  ['마셜 제도', '말라위', '말레이시아', '말리', '멕시코', '모나코', '모로코', '모리셔스'],
									  ['모리타니', '모잠비크', '몬테네그로', '몰도바', '몰디브', '몰타', '몽골', '미국'],
									  ['미얀마', '미크로네시아 연방', '바누아투', '바레인', '바베이도스', '바티칸', '바하마', '방글라데시'],
									  ['베네수엘라', '베냉', '베트남', '벨기에', '벨라루스', '벨리즈', '보스니아 헤르체고비나', '보츠와나'],
									  ['볼리비아', '부룬디', '부르키나파소', '부탄', '북마케도니아', '북조선(북한)', '불가리아', '브라질'],
									  ['브루나이', '산마리노', '사모아', '사우디아라비아', '상투메 프린시페', '세네갈', '세르비아', '세이셸'],
									  ['세인트루시아', '세인트빈센트 그레나딘', '세인트키츠 네비스', '소말리아', '솔로몬 제도', '수단', '수리남'],
									  ['스리랑카', '스웨덴', '스위스', '스페인(에스파냐)', '슬로바키아', '슬로베니아', '시리아', '시에라리온'],
									  ['싱가포르', '아랍에미리트', '아르메니아', '아르헨티나', '아이슬란드', '아이티', '아일랜드', '아제르바이잔'],
									  ['아프가니스탄', '안도라', '알바니아', '알제리', '앙골라', '앤티가 바부다', '에스와티니', '에콰도르'],
									  ['에리트레아', '에스토니아', '에티오피아', '엘살바도르', '영국', '예멘', '오만', '오스트레일리아'],
									  ['오스트리아', '온두라스', '요르단', '우간다', '우루과이', '우즈베키스탄', '우크라이나', '이라크'],
									  ['이란', '이스라엘', '이집트', '이탈리아', '인도', '인도네시아', '일본', '자메이카', '잠비아'],
									  ['적도 기니', '중앙아프리카공화국', '중화인민공화국', '지부티', '짐바브웨', '차드', '체코', '칠레'],
									  ['카메룬', '카자흐스탄', '카보베르데', '카타르', '캄보디아', '캐나다', '케냐', '코모로', '코스타리카'],
									  ['코트디부아르', '쿠바', '쿠웨이트', '콜롬비아', '콩고인민공화국', '콩고민주공화국', '크로아티아'],
									  ['키르기스스탄', '키리바시', '키프로스', '타지키스탄', '탄자니아', '태국', '토고', '통가', '투르크메니스탄'],
									  ['투발루', '튀니지', '튀르키예', '트리니다드 토바고', '파나마', '파라과이', '파키스탄', '파푸아뉴기니'],
									  ['팔라우', '페루', '포르투갈', '폴란드', '프랑스', '피지', '핀란드', '필리핀', '한국', '헝가리']]

		self.varx["data"]["l2d_기계명한글_기계명영어_묶음_01"] = [
			["드럼", "drum"], ["펄프밀", "pulp mill"], ["슬러리", "slury"], ["펄프분쇄기", "pulp mill"], ["엘레먼트", "element"],
			["가스캐비넷", "gas cabinet"], ["공기 compressor", "air compressor"], ["고압", "high voltage"], ["건조기", "dryer"],
			["가스감지기", "gas detector"], ["가스검지기", "gas detector"], ["가스탐지기", "gas detector"], ["게이트", "gate"],
			["컴프레서", "compressor"], ["쿨러", "cooler"], ["톤백", "ton bag"], ["체크", "check"], ["저압", "low voltage"],
			["판형", "plate type"], ["플라스틱", "plastic"], ["티타늄", "titanium"], ["믹서", "mixer"],
			["파이프", "pipe"], ["튜브", "tube"], ["번들", "bunddle"], ["피팅", "fitting"], ["플러그", "plug"],
			["핀튜브", "pin tube"], ["럽쳐디스크", "rupture disc"], ["라인드체크", "lined check"],
			["라인드", "lined"], ["플랜지", "flange"], ["케이블", "cable"], ["보일러", "boiler"], ["원심", "centrifugal"],
			["전기히터", "electric heater"], ["호스가스켓", "hose gasket"], ["가스켓", "gasket"],
			["반응기", "reactor"], ["쿨링타워", "cooling tower"], ["스페어", "spare"], ["모니터링", "monitoring"],
			["필터", "filter"], ["온도", "temperature"], ["진공", "vaccum"], ["교반기", "mixer"], ["호스", "hose"],
			["모터", "motor"], ["유량계", "floemeter"], ["탱크", "tank"], ["변압기", "tranformer"], ["로딩암", "loading arm"],
			["판넬", "panel"], ["배관", "piping"], ["오리피스", "orificr"], ["열교환기", "heat exchanger"], ["펌프", "pump"],
			["배터리", "battery"], ["터보블로어", "turbo blower"], ["패키지", "package"], ["버너", "bunner"], ["오링", "oring"],
			["인버터", "inverter"], ["호퍼", "hopper"], ["토너", "tonner"], ["분석기", "anayzer"], ["액츄에이터", "actuator"],
			["저울", "scale"], ["컨트롤", "control"], ["글로브", "glove"], ["컨트롤벨브", "control valve"],
			["아지테이터", "agitator"], ["송풍기", "blower"], ["블로어", "blower"], ["볼 valve", "ball valve"],
			["컴프레셔", "compressor"], ["압축기", "compressor"], ["호이스트", "hoist"], ["메카니카씰", "mechanical seal"],
			["메카니칼", "mechanical"], ["메카니컬", "mechanical"], ["밸브", "valve"], ["벨브", "valve"], ["그라파이트", "graphite"],
			["언로딩시스템", "unloading system"], ["플레어스택", "flare stack"], ["센서", "sensor"], ["발전기", "generator"],
			["온오프", "on-off"], ["질량", "mass"], ["마그네틱", "magnetic"], ["임펠러", "impellar"], ["컨테이너", "container"],
			["전기", "electric"], ["스크러버", "scrubber"], ["무정전저원장치", "ups"], ["메커미널 씰", "mechanical seal"],
		]

		self.varx["data"]["l2d_테이블_형식자료_01"] = [
			["입사일", '퇴사일', '근무년월일수', '근무년수', '정답'],
			["2000-2-10", "2010-1-31", "10년0월0일", '10년', 10.0],
			["2000-2-11", "2001-1-31", '1년0월0일', '1년', 1.0],
			["2000-2-13", "2030-1-31", '30년0월0일', '30년', 30.0],
			["2000-2-21", "2009-1-31", '9년0월0일', '9년', 9.0],
			["2000-3-1", "2008-1-31", '8년0월0일', '8년', 8.0],
			["2000-2-10", "2007-1-31", '7년0월0일', '7년', 7.0],
			["2000-2-18", "2006-2-1", '6년0월1일', '7년', 7.0]
		]

		self.varx["data"]["l2d_기자재영어에_none_포함_01"] = [
			['fitting', 'ball', 'flowmeter', 'on-off', 'battery', 'flange', 'electric', 'cable', 'gasket', 'seal', ],
			['invertor', None, 'level', 'gauge', 'gas', 'meter', 'centrifugal', 'magnetic', 'psv', 'titanium', ],
			['pressure', 'motor', 'boiler', 'globe', 'gate', 'transformer', 'charger', 'blower', 'inverter', ],
			['', 'ph', 'ebd', 'mass', 'plug', 'diaphragm', 'dcs', 'detector', 'heater', 'hv', 'scale', ],
			['', 'ups', 'pg', 'reactor', '', 'vessel', 'butterfly', 'mechanical', 'element', ],
			['tube', 'bellows', 'mixer', '', 'hose', 'diaphgram', 'separator', 'mcc', 'plc', 'frp', ],
			['', 'rubber', 'ngr', 'bolt', '', 'rtd', 'bolt/nut', 'graphite', 'drum', 'relay', 'LV', ],
			[None, 'rotary', 'sensor', None, 'column', 'screen', 'manual', 'balance', 'bundle', ],
			['plastivc', 'acb', 'carbon', None, 'cell', 'strainer', 'type', 'cover', 'tg', 'membrane', 'prv', ],
			['ptfe', 'check', 'nickel', 'analyzer', 'oil', 'water', 'temperature', 'glove', 'channel', 'ring', ],
			['etfe', 'sheet', 'tms', 'scrubber', 'lift', 'oven', 'holder', 'container', 'cctv', 'vcb', 'condensor', ],
			['casting', 'metal', 'rupture', 'disc', 'gear', 'screw', 'leak', '3-way', 'canned', 'package', 'dryer', ],
			['feeder', '양극전극', 'bag', 'air', '농도계', 'pin', 'impeller', 'metering', 'kit', 'actuator', 'aircon', ],
			['column', 'compressor', 'concentration', 'condenser', 'conductivity', 'connector', 'contcnrator', ],
			['contol', 'control', 'control ball valve', 'control-valve', 'convection', 'conveyor', 'cooler', ],
			['cover', 'crusher', 'cryogel', 'cw', 'cyclone', 'cylinder', 'd/p']]

		self.varx["data"]["l2d_숫자자료들_01"] = [[11, 12, 13, 14, 15, 16, 17, 18, 19],
									 [21, 22, 23, 24, 25, 26, 27, 28, 29],
									 [31, 32, 33, 34, 35, 36, 37, 38, 39],
									 [41, 42, 43, 44, 45, 46, 47, 48, 49],
									 [51, 52, 53, 54, 55, 56, 57, 58, 59],
									 [61, 62, 63, 64, 65, 66, 67, 68, 69],
									 [71, 72, 73, 74, 75, 76, 77, 78, 79],
									 [81, 82, 83, 84, 85, 86, 87, 88, 89],
									 [91, 92, 93, 94, 95, 96, 97, 98, 99]]

		self.varx["data"]["l2d_숫자안에_다른것들_넣은것_01"] = [[11, 12, 13, 14, 15, 16, 17, 18, 19],
											 [21, 22, 23, 24, 25, 26, 27, 28, 29],
											 [31, 32, 33, "abc", 35, 36, 37, 38, "zzz"],
											 [41, 42, 43, 44, 45, 46, 47, 48, ""],
											 [51, 52, 53, 54, 55, 56, 57, 58, 59],
											 [61, 62, 63, " ", " space ", 66, 67, 68, 69],
											 [71, 72, 73, 74, 275, 76, 77, 78, 79],
											 [81, 82, 83, 84, " space ", 88886, 87, 88, 89],
											 [91, 92, 93, 94, -23, 96, 97, 98, 99],
											 ["abc", "abc", 13, 14, 15, 16, 17, 18, 19],
											 ["abc", 22, 23, "abc", 25, 26, 27, 28, "zzz"],
											 [31, 32, 33, "abc", "abc", 36, 37, 38, "zzz"],
											 ["3/1", 42, 43, "3/1", "3/1", 46, 47, 48, ""],
											 [51, "가나다", "3/1", 54, 55, 56, 57, 58, 59],
											 [61, 61, 61, " ", " space ", 66, 67, 68, 69],
											 [71, 72, 73, 74, "space", 76, 77, 78, 79],
											 [81, 82, "가나다", 84, " space ", 88886, 87, 88, 89],
											 [91, 100, "가나다", 94, -23, 96, 97, 98, 99]]

		self.varx["data"]["l2d_테이블형식자료_02"] = [
			["", "y1", "y2", "y3", "y4", "y5", "y6", "y7""y8", "y9"],
			["x1", 21, 22, 23, 24, 25, 26, 27, 28, 29],
			["x2", 31, 32, 33, 123, 35, 36, 37, 38, 254],
			["x3", 41, 42, 43, 44, 45, 46, 47, 48, 123],
			["x4", 51, 52, 53, 54, 55, 56, 57, 58, 59],
			["x5", 61, 62, 63, 55, 122, 66, 67, 68, 69],
			["x6", 71, 72, 73, 74, 275, 76, 77, 78, 79],
			["x7", 81, 82, 83, 84, 432, 886, 87, 88, 89],
			["x8", 91, 92, 93, 94, 23, 96, 97, 98, 99],
			["x9", 61, 61, 61, 323, 234, 66, 67, 68, 69],
			["x10", 71, 72, 73, 74, 534, 76, 77, 78, 79],
			["x11", 81, 82, 13, 84, 324, 888, 87, 88, 89],
			["x12", 91, 100, 132, 94, 23, 96, 97, 98, 99]]

		self.varx["data"]["l2d_특수문자_숫자_섞은자료_01"] = [
			["1111", 2, 3, 4, 5, 6, 7, 8, 9],
			["_2", "", 3, 4, "", 6, "", 8, ""],
			["  3", 2, "", 4, "", 6, "", 8, ""],
			["1234", "가123", 3, 4, "나", 6, "", 8, ""],
			["??5", "가가345", 3, 4, "나", 6, "", 8, ""],
			["**6", "가가abc", 3, 4, "나", 6, "", 8, ""],
			["*7", "가가나나다", 3, 4, "나", 6, "", 8, ""],
			[" 8", "가가 가가멜", 3, 4, "나", 6, "", 8, ""],
		]

		self.varx["data"]["l2d_컨트롤시트용자료_01"] = [['번호', '업체명', 'REQ_NO', '수량', '단위', 'payment', 'payment status', 'REVISION', ' AMOUNT ', 'LI_DATE', 'ITEM', 'CONDITION', '통화단위', '대분류'],
										['1001', '산본', 'Fz-F01', '1 ', 'SET', '100-45', '100', '0', '            24,159.38 ', '2010-01-31', 'FRP TANK', 'FOT', 'KWON', 'VESSEL'],
										['1002', '산본', 'LP-01', '1 ', 'LOT', '90-10-90', 'PAR', '0', '        3,581,118.00 ', '2010-05-10', 'ELECTRIC MATERIAL', 'FOT', 'KWON', 'PIPING'],
										['1003', '산본', 'LP-01', '1 ', 'LOT', '90-10-90', 'PAR', '0', '          397,902.00 ', '2010-05-10', 'ELECTRIC MATERIAL', 'FOT', 'KWON', 'PIPING'],
										['1004', '산본', 'LP-01', '1 ', 'LOT', '90-10-90', '100', '0', '        3,979,020.00 ', '2010-10-25', 'ELECTRIC MATERIAL', 'FOT', 'KWON', 'PIPING'],
										['1005', '산본', 'NNN-01', '3 ', 'SETS', '100-30', '100', '0', '            29,750.00 ', '2010-05-10', 'CONTROL VALVE', 'FOT', 'JPY', 'PIPING'],
										['1006', '산본', 'NNN-01', '3 ', 'SETS', '100-30-CASH', '100', '0', '            29,750.00 ', '2010-05-10', 'CONTROL VALVE', 'FOT', 'JPY', 'PIPING'],
										['1007', '대원', 'zS-O-01', '1 ', 'SET', '100-30-CASH', '100', '0', '          340,000.00 ', '2010-03-04', 'STACK', 'FOT', 'KWON', 'VESSEL'],
										['1008', '안양', 'DNN-001', '1 ', 'SET', '100-30-CASH', '100', '0', '             3,400.00 ', '2010-11-08', 'COLLECTOR LAMINAR', 'FOB', 'JPY', 'VESSEL'],
										['1009', '삼성', 'NNzL-001', '25 ', 'SETS', '100-30-CASH', 'PAR', '0', '          311,397.36 ', '2010-02-21', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1010', '삼성', 'NNzL-001', '25 ', 'SETS', '100-30-CASH', 'PAR', '0', '            94,664.62 ', '2010-02-21', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1011', '삼성', 'NNzL-001', '25 ', 'SETS', '100-30-CASH', 'PAR', '0', '            56,057.50 ', '2010-02-21', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1012', '삼성', 'NNzL-001', '25 ', 'SETS', '100-30-CASH', 'PAR', '0', '            45,118.00 ', '2010-02-21', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1013', '삼성', 'NNzL-001', '25 ', 'SETS', '100-30-CASH', '100', '0', '          451,180.00 ', '2010-02-21', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1014', '삼성', 'GNNL-05', '7 ', 'SETS', '100-30-CASH', 'PAR', '0', '          123,019.65 ', '2011-05-08', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1015', '삼성', 'GNNL-05', '7 ', 'SETS', '100-30-CASH', 'PAR', '0', '            54,460.35 ', '2011-05-08', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1016', '삼성', 'GNNL-05', '7 ', 'SETS', '100-30-CASH', 'PAR', '0', '            20,111.00 ', '2011-05-08', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1017', '삼성', 'GNNL-05', '7 ', 'SETS', '100-30-CASH', 'PAR', '0', '            19,720.00 ', '2011-05-08', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1018', '삼성', 'GNNL-05', '7 ', 'SETS', '100-30-CASH', '100', '0', '          197,200.00 ', '2010-02-21', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1019', '삼성', 'GNNL-05', '1 ', 'LOT', '100-30-CASH', '100', '0', '            25,075.00 ', '2011-05-08', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1020', '삼성', 'GNNL-05', '1 ', 'LOT', '100-30-CASH', '100', '0', '            21,250.00 ', '2011-09-27', 'ROTOR ASSEMBLY', 'FOT', 'KWON', 'PIPING'],
										['1021', '삼성', 'GNNL-05', '1 ', 'LOT', '100-30-CASH', '100', '0', '            15,261.75 ', '2011-04-16', 'ROTOR ASSEMBLY', 'FOT', 'KWON', 'PIPING'],
										['1022', '삼성', 'GNNL-04', '39 ', 'SETS', '100-30-CASH', 'PAR', '0', '          697,680.00 ', '2010-02-25', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1023', '삼성', 'GNNL-04', '39 ', 'SETS', '100-30-CASH', 'PAR', '0', '            77,520.00 ', '2010-02-25', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1024', '삼성', 'GNNL-04', '39 ', 'SETS', '100-30-CASH', 'PAR', '0', '            76,245.00 ', '2010-02-25', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1025', '삼성', 'GNNL-04', '39 ', 'SETS', '100-30-CASH', '100', '0', '          775,200.00 ', '2010-02-21', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1026', '군포', 'FNN-L-01NN', '15 ', 'SET', '100-30-CASH', '100', '0', '        1,022,550.00 ', '2010-01-19', 'CS VESSELS', 'FOT', 'KWON', 'VESSEL'],
										['1027', '군포', 'ENNG02NNSP', '1 ', 'SET', '100-30-CASH', '100', '0', '            23,800.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1028', '군포', 'ENN-G-02NN', '15 ', 'SET', '100-30-CASH', '100', '0', '        2,295,000.00 ', '2010-01-19', 'SUS H/EX', 'FOT', 'KWON', 'VESSEL'],
										['1029', '강원도', 'ME-02', '1 ', 'LOT', '100-30-CASH', 'PAR', '0', '        1,304,112.43 ', '2010-07-14', 'TRANSFORMER', 'FOT', 'KWON', 'PIPING'],
										['1030', '강원도', 'ME-02', '1 ', 'LOT', '100-30-CASH', 'PAR', '0', '            68,637.50 ', '2010-07-14', 'TRANSFORMER', 'FOT', 'KWON', 'PIPING'],
										['1031', '강원도', 'ME-02', '1 ', 'LOT', '100-30-CASH', '100', '0', '        1,372,750.00 ', '2010-09-26', 'TRANSFORMER', 'FOT', 'KWON', 'PIPING'],
										['1032', '가을여행', 'ME-02', '1 ', 'LOT', '100-30-CASH', '100', '0', '        1,071,000.00 ', '2010-07-14', 'UPS', 'FOT', 'KWON', 'PIPING'],
										['1033', '가을여행', 'GNNL-03', '3 ', 'SETS', '100-30-CASH', 'PAR', '1', '        1,528,427.57 ', '2010-07-14', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1034', '가을여행', 'GNNL-03', '3 ', 'SETS', '100-30-CASH', 'PAR', '1', '          169,745.00 ', '2010-07-14', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1035', '가을여행', 'GNNL-03', '14 ', 'SETS', '100-30-CASH', 'PAR', '1', '             3,782.50 ', '2010-07-14', 'SPARE PARTS', 'FOT', 'KWON', 'PIPING'],
										['1036', '가을여행', 'GNNL-03', '3 ', 'SETS', '100-30-CASH', '100', '1', '        1,701,955.00 ', '2010-07-14', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1037', '가을여행', 'GNNL-02', '14 ', 'SETS', '100-30-CASH', 'PAR', '1', '          336,982.50 ', '2010-02-25', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1038', '가을여행', 'GNNL-02', '14 ', 'SETS', '100-30-CASH', 'PAR', '1', '            37,570.00 ', '2010-02-25', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1039', '가을여행', 'GNNL-02', '14 ', 'SETS', '100-30-CASH', 'PAR', '1', '            32,784.50 ', '2010-02-25', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1040', '가을여행', 'GNNL-02', '3 ', 'SETS', '100-30-CASH', 'PAR', '1', '            10,993.05 ', '2010-02-25', 'SPARE PARTS', 'FOT', 'KWON', 'PIPING'],
										['1041', '가을여행', 'GNNL-02', '14 ', 'SETS', '100-30-CASH', '100', '1', '          418,330.05 ', '2010-07-14', 'PUMP', 'FOT', 'KWON', 'PIPING'],
										['1042', '황해도', 'ENN-G-04', '4 ', 'SET', '100-30-CASH', '100', '0', '          263,500.00 ', '2010-02-25', 'DUSUPERHEATER', 'FOT', 'KWON', 'VESSEL'],
										['1043', '군포', 'JP-01', '3 ', 'SET', '100-30-CASH', '100', '0', '            89,250.00 ', '2010-02-25', 'STATIC MIXER', 'FOT', 'KWON', 'VESSEL'],
										['1044', '황해도', 'DL-L-01L', '1 ', 'SET', '100-30-CASH', '100', '0', '            25,500.00 ', '2010-02-15', 'STRAINER', 'FOB', 'JPY', 'VESSEL'],
										['1045', '황해도', 'DL-L-01z', '1 ', 'LOT', '100-30-CASH', '100', '0', '            25,500.00 ', '2010-02-15', 'Mixer', 'DDU', 'JPY', 'VESSEL'],
										['1046', '강원도', 'GLL-01', '12 ', 'SETS', '100-30-CASH', 'PAR', '0', '          410,184.50 ', '2011-06-15', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1047', '강원도', 'GLL-01', '12 ', 'SETS', '100-30-CASH', 'PAR', '0', '          117,130.00 ', '2011-06-15', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1048', '강원도', 'GLL-01', '12 ', 'SETS', '100-30-CASH', 'PAR', '0', '            58,590.50 ', '2011-06-15', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1049', '강원도', 'GLL-01', '12 ', 'SETS', '100-30-CASH', '100', '1', '          585,905.00 ', '2010-07-10', 'Flange', 'FOT', 'KWON', 'PIPING'],
										['1050', '강원도', 'NNO-02', '2 ', 'SETS', '100-30-CASH', '100', '0', '             1,530.00 ', '2011-06-15', 'REVISION INDUCER', 'FOB', 'USD', 'PIPING'],
										['1051', '강원도', 'NNO-02', '6 ', 'SETS', '100-30-CASH', '100', '1', '          151,130.00 ', '2010-07-26', 'PIPE', 'FOT', 'JPY', 'PIPING'],
										['1052', '강원도', 'NNO-02', '17 ', 'SETS', '100-30-CASH', '100', '1', '            47,043.25 ', '2010-07-26', 'PIPE', 'FOT', 'JPY', 'PIPING'],
										['1053', '강원도', 'NNzL-001', '2 ', 'SETS', '100-30-CASH', '100', '1', '            16,757.75 ', '2010-07-26', 'Forged Valve', 'FOT', 'JPY', 'PIPING'],
										['1054', '경상일보', 'NNO-02', '2 ', 'SETS', '100-30-CASH', '100', '2', '          101,295.35 ', '2010-07-24', 'Forged Valve', 'FOT', 'KWON', 'PIPING'],
										['1055', '경상일보', 'DD-11', '13 ', 'SETS', '100-30-CASH', '100', '2', '          136,135.15 ', '2010-07-24', 'Fitting', 'FOT', 'KWON', 'PIPING'],
										['1056', '경상일보', 'DNN-P01', '5 ', 'SET', '100-30-CASH', '100', '0', '          469,200.00 ', '2010-01-17', 'PACKING', 'FOB', 'JPY', 'VESSEL'],
										['1057', '제주도', 'GLL-01', '3 ', 'SETS', '100-30-CASH', 'PAR', '1', '        3,789,606.00 ', '2010-07-10', 'REFRIGERATOR', 'FOT', 'KWON', 'PIPING'],
										['1058', '제주도', 'GLL-01', '3 ', 'SETS', '100-30-CASH', 'PAR', '1', '        1,541,594.00 ', '2010-07-10', 'REFRIGERATOR', 'FOT', 'KWON', 'PIPING'],
										['1059', '제주도', 'GLL-01', '3 ', 'SETS', '100-30-CASH', 'PAR', '1', '        1,315,800.00 ', '2010-07-10', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1060', '제주도', 'GLL-01', '1 ', 'LOT', '100-30-CASH', 'PAR', '1', '          297,500.00 ', '2010-07-10', 'REFRIGERATOR', 'FOT', 'KWON', 'PIPING'],
										['1061', '제주도', 'GLL-01', '3 ', 'SETS', '100-30-CASH', '100', '1', '        6,647,000.00 ', '2010-07-10', 'REFRIGERATOR', 'FOT', 'KWON', 'PIPING'],
										['1062', '충청회사', 'GzL-04', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '          126,225.00 ', '2010-10-04', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1063', '충청회사', 'GzL-04', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '             9,775.00 ', '2010-10-04', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1064', '충청회사', 'GzL-04', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '             1,105.00 ', '2010-10-04', 'MMA', 'FOB', 'USD', 'PIPING'],
										['1065', '충청회사', 'GzL-04', '2 ', 'SETS', '100-30-CASH', '100', '1', '          137,105.00 ', '2010-07-10', 'Fitting', 'FOT', 'KWON', 'PIPING'],
										['1066', '엘지', 'LP-01', '1 ', 'LOT', '100-30-CASH', 'PAR', '0', '        6,740,840.00 ', '2010-01-13', 'MCC & SWGR', 'FOT', 'KWON', 'PIPING'],
										['1067', '엘지', 'LP-01', '1 ', 'LOT', '100-30-CASH', 'PAR', '0', '          842,605.00 ', '2010-01-13', 'MCC & SWGR', 'FOT', 'KWON', 'PIPING'],
										['1068', '엘지', 'LP-01', '1 ', 'LOT', '100-30-CASH', 'PAR', '0', '          842,605.00 ', '2010-01-13', 'MCC & SWGR', 'FOT', 'KWON', 'PIPING'],
										['1069', '엘지', 'LP-01', '1 ', 'LOT', '100-30-CASH', '100', '0', '        8,426,049.73 ', '2010-10-04', 'MCC & SWGR', 'FOT', 'KWON', 'PIPING'],
										['1070', '경상일보', 'ENN-S01', '27 ', 'SET', '100-30-CASH', '100', '0', '          299,691.71 ', '2010-01-13', 'SPIRAL H/E', 'FOB', 'JPY', 'VESSEL'],
										['1071', '전라회사', 'GzL-03', '7 ', 'SETS', '100-30-CASH', 'PAR', '0', '          442,000.00 ', '2010-07-10', 'COMPRESSOR', 'FOT', 'KWON', 'PIPING'],
										['1072', '전라회사', 'GzL-03', '7 ', 'SETS', '100-30-CASH', 'PAR', '0', '          110,500.00 ', '2010-07-10', 'COMPRESSOR', 'FOT', 'KWON', 'PIPING'],
										['1073', '전라회사', 'GzL-03', '7 ', 'SETS', '100-30-CASH', 'PAR', '0', '            71,094.00 ', '2010-07-10', 'COMPRESSOR', 'FOT', 'KWON', 'PIPING'],
										['1074', '전라회사', 'GzL-03', '7 ', 'SETS', '100-30-CASH', '100', '1', '          559,215.00 ', '2010-07-10', 'COMPRESSOR', 'FOT', 'KWON', 'PIPING'],
										['1075', '전라회사', 'GzL-01', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '          494,360.00 ', '2011-01-31', 'COMPRESSOR', 'FOT', 'KWON', 'PIPING'],
										['1076', '전라회사', 'GzL-01', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '          123,590.00 ', '2011-01-31', 'COMPRESSOR', 'FOT', 'KWON', 'PIPING'],
										['1077', '전라회사', 'GzL-01', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '            29,412.98 ', '2011-01-31', 'COMPRESSOR', 'FOT', 'KWON', 'PIPING'],
										['1078', '전라회사', 'GzL-01', '2 ', 'SETS', '100-30-CASH', '100', '1', '          647,362.99 ', '2010-07-10', 'COMPRESSOR', 'FOT', 'KWON', 'PIPING'],
										['1079', '마음기업', 'EE-O-01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '             7,480.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1080', '마음기업', 'EE-O-01NN', '8 ', 'SET', '100-30-CASH', '100', '0', '          467,500.00 ', '2010-10-17', 'CONDENSER', 'FOT', 'KWON', 'VESSEL'],
										['1081', '마음기업', 'EE-O-01', '30 ', 'SET', '100-30-CASH', '100', '0', '          790,500.00 ', '2010-03-08', 'EJECTOR', 'FOT', 'KWON', 'VESSEL'],
										['1082', '배2', 'DNN-T01', '6 ', 'SET', '100-30-CASH', '100', '0', '          425,000.00 ', '2010-01-21', 'SIEVE TRAY', 'FOT', 'KWON', 'VESSEL'],
										['1083', '배2', 'DNN-P01NN', '8 ', 'SET', '100-30-CASH', '100', '0', '          663,000.00 ', '2010-02-09', 'TOWER INTERNAL', 'FOT', 'KWON', 'VESSEL'],
										['1084', '귤회사', 'DP-01', '7 ', 'SET', '100-30-CASH', '100', '0', '          174,250.00 ', '2010-01-31', 'SILENCER', 'FOT', 'KWON', 'VESSEL'],
										['1085', '귤회사', 'FD-O02SP', '1 ', 'SET', '100-30-CASH', '100', '0', '             2,465.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1086', '귤회사', 'FD-O02', '4 ', 'SET', '100-30-CASH', '100', '0', '          935,000.00 ', '2010-01-21', 'MIST SEPARATOR', 'FOT', 'KWON', 'VESSEL'],
										['1087', '마음기업', 'FNN-S01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '            36,975.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1088', '마음기업', 'FNN-S01', '35 ', 'SET', '100-30-CASH', '100', '0', '        2,465,000.00 ', '2010-01-28', 'SUS VESSELS', 'FOT', 'KWON', 'VESSEL'],
										['1089', '마음기업', 'ENN-L01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '            18,275.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1090', '마음기업', 'ENN-L01', '4 ', 'SET', '100-30-CASH', '100', '0', '        1,672,800.00 ', '2010-01-12', 'CS H/EX', 'FOT', 'KWON', 'VESSEL'],
										['1091', '여름회사', 'FD-O01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '          316,727.00 ', '2011-02-13', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1092', '여름회사', 'FD-O01', '8 ', 'SET', '100-30-CASH', '100', '0', '          578,000.00 ', '2010-01-20', 'FILTER', 'FOT', 'KWON', 'VESSEL'],
										['1093', '봄회사', 'FNN-L01zSP', '1 ', 'SET', '100-30-CASH', '100', '0', '            11,900.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1094', '봄회사', 'FNN-L01z', '1 ', 'SET', '100-30-CASH', '100', '0', '        1,572,500.00 ', '2010-01-12', 'CS PRESSURE VESSELS', 'FOT', 'KWON', 'VESSEL'],
										['1095', '봄회사', 'DNN-S01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '            41,650.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1096', '봄회사', 'DNN-S01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '             3,570.00 ', '2011-01-31', 'ANALYZER', 'FOT', 'KWON', 'VESSEL'],
										['1097', '봄회사', 'DNN-S01', '5 ', 'SET', '100-30-CASH', '100', '0', '        6,200,750.27 ', '2017-12-24', 'TOWER', 'FOT', 'KWON', 'VESSEL'],
										['1098', '최고당', 'ENN-P02', '45786 ', 'SET', '100-30-CASH', '100', '0', '          410,688.45 ', '2017-12-24', 'PLATE TYPE H/EX', 'FOB', 'JPY', 'VESSEL'],
										['1099', '최고당', 'NNN-01', '37 ', 'SETS', '100-30-CASH', '100', '0', '            14,875.00 ', '2010-05-10', 'CONTROL VALVE', 'FOB', 'JPY', 'PIPING'],
										['1100', '최고당', 'ENN-F01', '1 ', 'SET', '100-30-CASH', '100', '0', '          412,675.00 ', '2010-01-12', 'HEATER (FIN TUBE)', 'FOB', 'JPY', 'VESSEL'],
										['1101', '무한상사', 'DL-L-01', '3 ', 'SET', '100-30-CASH', '100', '0', '          654,500.00 ', '2010-03-24', 'REACTOR', 'FOT', 'KWON', 'VESSEL'],
										['1102', '여기물산', 'GzL-02', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '        1,032,750.00 ', '2010-02-08', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1103', '여기물산', 'GzL-02', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '          114,750.00 ', '2010-02-08', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1104', '여기물산', 'GzL-02', '2 ', 'SETS', '100-30-CASH', 'PAR', '0', '             1,836.00 ', '2010-02-08', 'MMA', 'FOB', 'USD', 'PIPING'],
										['1105', '여기물산', 'GzL-02', '2 ', 'SETS', '100-30-CASH', '100', '1', '        1,149,336.00 ', '2010-04-20', 'Battery Charge', 'FOT', 'KWON', 'PIPING'],
										['1106', '거기', 'EF-L01', '2 ', 'SET', '100-30-CASH', '100', '0', '        1,616,190.00 ', '2010-02-08', 'COOLING TOWER', 'FOT', 'KWON', 'VESSEL'],
										['1107', '갑회사', 'GDL-01', '12 ', 'SETS', '100-30-CASH', 'PAR', '1', '          319,149.50 ', '2010-10-20', 'AGITATOR', 'FOT', 'KWON', 'PIPING'],
										['1108', '갑회사', 'GDL-01', '12 ', 'SETS', '100-30-CASH', 'PAR', '1', '          112,931.00 ', '2010-10-20', 'AGITATOR', 'FOT', 'KWON', 'PIPING'],
										['1109', '갑회사', 'GDL-01', '12 ', 'SETS', '100-30-CASH', 'PAR', '1', '            35,419.50 ', '2010-10-20', 'AGITATOR', 'FOT', 'KWON', 'PIPING'],
										['1110', '갑회사', 'GDL-01', '12 ', 'SETS', '100-30-CASH', 'PAR', '1', '             9,197.00 ', '2010-10-20', 'SPARE PARTS', 'FOT', 'KWON', 'PIPING'],
										['1111', '갑회사', 'GDL-01', '12 ', 'SETS', '100-30-CASH', '100', '1', '          476,697.00 ', '2010-04-20', 'AGITATOR', 'FOT', 'KWON', 'PIPING'],
										['1112', '사과', 'LP-01', '1 ', 'SET', '100-30-CASH', '100', '0', '             2,635.00 ', '2010-10-20', 'ANALYZER', 'FOT', 'JPY', 'PIPING'],
										['1113', '바나나기업', 'LP-02', '1 ', 'LOT', '100-30-CASH', '100', '0', '             3,570.00 ', '2011-02-09', 'PROGRAMMING', 'FOT', 'JPY', 'PIPING'],
										['1114', '홍길동', 'ME-02', '1 ', 'SET', '100-30-30', '100', '0', '            35,530.00 ', '2011-12-12', 'MODIFICATION Charge', 'SITE', 'KWON', 'VESSEL'],
										['1115', '홍길동', 'ENN-G02z', '3 ', 'SET', '100-30-CASH', '100', '0', '        3,740,000.00 ', '2010-01-12', 'SUS H/EX', 'FOT', 'KWON', 'VESSEL'],
										['1116', '홍길동', 'ENN-G01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '          152,065.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1117', '홍길동', 'ENN-G01', '5 ', 'SET', '100-30-CASH', '100', '0', '        2,082,500.00 ', '2010-01-12', 'SUS H/EX', 'FOT', 'KWON', 'VESSEL'],
										['1118', '홍길동', 'DL-L-01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '               935.00 ', '2011-01-31', '1YSP', 'FOB', 'USD', 'VESSEL'],
										['1119', '무능일지', 'ME-10', '1 ', 'LOT', '100-30-CASH', '100', '0', '          361,165.00 ', '2011-01-05', 'MECHANICAL SEAL', 'FOT', 'KWON', 'PIPING'],
										['1120', '가나상사', 'JP-01', '1 ', 'LOT', '100-30-CASH', '100', '0', '          784,125.00 ', '2010-04-07', 'PLATFORM & LADDER', 'FOT', 'KWON', 'VESSEL'],
										['1121', '가나상사', 'JP-01', '1 ', 'LOT', '100-30-CASH', '100', '0', '            65,875.00 ', '2010-04-07', 'INTER CONN. PIPING', 'FOT', 'KWON', 'VESSEL'],
										['1122', '회상일보', 'zNN-O01SP', '1 ', 'SET', '100-30-CASH', '100', '0', '             3,740.00 ', '2011-01-31', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1123', '회상일보', 'zNN-001', '1 ', 'SET', '100-30-CASH', '100', '0', '          926,500.00 ', '2010-01-14', 'HOT OIL HEATER', 'FOT', 'KWON', 'VESSEL'],
										['1124', '회상일보', 'zNN-001', '1 ', 'LOT', '100-30-CASH', '100', '0', '            34,000.00 ', '2011-01-03', 'ADDITIONAL PRICE', 'FOT', 'KWON', 'VESSEL'],
										['1125', '아사히', 'FD-O03', '2 ', 'SET', '100-30-CASH', '100', '0', '          489,065.35 ', '2010-01-24', 'FILTER', 'FOB', 'JPY', 'VESSEL'],
										['1126', '아사히', 'FD-D03NN', '1 ', 'LOT', '100-30-CASH', '100', '0', '             4,320.39 ', '2010-11-27', 'SUPERVISION SERVICE', 'SITE', 'JPY', 'VESSEL'],
										['1127', '아산', 'ENN-G-03', '5 ', 'SET', '100-30-CASH', '100', '0', '            34,000.00 ', '2010-04-06', 'SAMPLING COOLER', 'FOT', 'KWON', 'VESSEL'],
										['1128', '가나다', 'DFL-01', '1 ', 'SET', '100-30-CASH', '100', '2', '        1,013,200.00 ', '2010-10-13', 'DRUM FILLING MACHINE', 'FOT', 'KWON', 'PIPING'],
										['1129', '쌍용', 'DD-11', '1 ', 'SET', '100-30-CASH', 'PAR', '1', '            15,725.00 ', '2011-03-05', 'Gas detector', 'FOT', 'KWON', 'PIPING'],
										['1130', '쌍용', 'DD-11', '1 ', 'SET', '100-30-CASH', 'PAR', '1', '             2,975.00 ', '2011-03-05', 'Gas detector', 'FOT', 'KWON', 'PIPING'],
										['1131', '쌍용', 'DD-11', '1 ', 'SET', '100-30-CASH', '100', '1', '            18,700.00 ', '2010-07-10', 'DP Transmitter', 'FOT', 'KWON', 'PIPING'],
										['1132', '현대', 'FNNL01NNSP', '1 ', 'SET', '100-30-CASH', '100', '0', '             1,923.55 ', '2011-03-05', '1YSP', 'FOT', 'KWON', 'VESSEL'],
										['1133', '이순신', 'ENN-L01NN', '4 ', 'SET', '100-30-CASH', '100', '0', '            11,050.00 ', '2010-06-16', 'SINENCER', 'FOT', 'JPY', 'VESSEL'],
										['1134', '영풍', 'GNNL-01', '22 ', 'SETS', '100-30-CASH', 'PAR', '0', '          942,446.00 ', '2010-05-04', 'CENTRIFUGAL PUMP', 'FOT', 'KWON', 'PIPING'],
										['1135', '영풍', 'GNNL-01', '22 ', 'SETS', '100-30-CASH', 'PAR', '0', '          203,439.00 ', '2010-05-04', 'CENTRIFUGAL PUMP', 'FOT', 'KWON', 'PIPING'],
										['1136', '영풍', 'GNNL-01', '22 ', 'SETS', '100-30-CASH', 'PAR', '0', '          124,032.00 ', '2010-05-04', 'CENTRIFUGAL PUMP', 'FOT', 'KWON', 'PIPING'],
										['1137', '영풍', 'GNNL-01', '22 ', 'SETS', '100-30-CASH', '100', '2', '        1,269,917.00 ', '2010-07-11', 'CENTRIFUGAL PUMP', 'FOT', 'KWON', 'PIPING'],
										['1138', '금융', 'JFL-01', '1 ', 'SET', '100-30-CASH', 'PAR', '0', '          321,767.50 ', '2010-01-31', 'Material Handling', 'FOT', 'KWON', 'PIPING'],
										['1139', '금융', 'JFL-01', '1 ', 'SET', '100-30-CASH', 'PAR', '0', '            35,700.00 ', '2010-01-31', 'MMA', 'FOT', 'KWON', 'PIPING'],
										['1140', '금융', 'JFL-01', '1 ', 'SET', '100-30-CASH', '100', '1', '          357,467.50 ', '2010-05-04', 'Material Handling', 'FOT', 'KWON', 'PIPING'],
										['1141', 'ABC', 'LP-702SP', '1 ', 'SET', '100-30-CASH', '100', '0', '               807.50 ', '2011-02-21', '1YSP', 'FOB', 'USD', 'VESSEL'],
										['1142', 'ABC', 'LP-001', '1 ', 'LOT', '100-30-CASH', '100', '0', '            39,950.00 ', '2010-07-05', 'CONTROL PANNEL', 'FOT', 'KWON', 'VESSEL'],
										['1143', '갑회사', 'ME-10', '61 ', 'PCS', '100-14-CASH', '100', '0', '          119,000.00 ', '2012-07-05', 'TUBE MATERIAL', 'FOT', 'KWON', 'VESSEL'],
										['1144', '갑회사', 'ME-10', '1 ', 'LOT', '60-40-30', '100', '0', '          297,500.00 ', '2012-07-16', 'BOILER REPLACEMENT INCLUDING BODY', 'FOT', 'KWON',
										 'VESSEL'],
										['1145', '갑회사', 'ME-10', '1 ', 'LOT', '60-40-30', 'PAR-60', '0', '          178,500.00 ', '2012-07-16', 'BOILER REPLACEMENT INCLUDING BODY', 'FOT', 'KWON',
										 'VESSEL'],
										['1146', '갑회사', 'ME-10', '1 ', 'LOT', '60-40-30', 'PAR-40', '0', '          119,000.00 ', '2012-07-16', 'BOILER REPLACEMENT INCLUDING BODY', 'FOT', 'KWON',
										 'VESSEL']]

		self.varx["data"]["t2d_시_님의침묵"] = """한용운의 시, 님의 침묵

님은 갔습니다. 아아, 사랑하는 나의 님은 갔습니다.  
푸른 산빛을 깨치고 단풍나무 숲을 향하여 난 작은 길을 걸어서 차마 떨치고 갔습니다.  
황금의 꽃같이 굳고 빛나던 옛 맹세는 차디찬 티끌이 되어서 한숨의 미풍에 날려 갔습니다.

날카로운 첫키스의 추억은 나의 운명의 지침을 돌려 놓고 뒷걸음쳐서 사라졌습니다.  
나는 향기로운 님의 말소리에 귀먹고, 꽃다운 님의 얼굴에 눈멀었습니다.  
사랑도 사람의 일이라 만날 때에 미리 떠날 것을 염려하고 경계하지 아니한 것은 아니지만, 
이별은 뜻밖의 일이 되고 놀란 가슴은 새로운 슬픔에 터집니다.

기와 승의 표현상의 특징과 효과점층적 반복을 통해 상황의 절박감을 강조하였다.

그러나 이별을 쓸데없는 눈물의 원천을 만들고 마는 것은 스스로 사랑을 깨치는 것인 줄 아는 까닭에 
걷잡을 수 없는 슬픔의 힘을 옮겨서 새 희망의 정수박이에 들어부었습니다.  
우리는 만날 때에 떠날 것을 염려하는 것과 같이 떠날 때에 다시 만날 것을 믿습니다.

아아, 님은 갔지마는 나는 님을 보내지 아니하였습니다.  
제 곡조를 못 이기는 사랑의 노래는 님의 침묵을 휩싸고 돕니다"""

		self.varx["data"]["t2d_123가나다_01"] = """1: 1234567890가나다라마바사아자차카파파하
2: 1234567890가나다라마바사아자차카파파하
3: 1234567890가나다라마바사아자차카파파하
4: 1234567890가나다라마바사아자차카파파하
5: 1234567890가나다라마바사아자차카파파하
6: 1234567890가나다라마바사아자차카파파하
7: 1234567890가나다라마바사아자차카파파하
8: 1234567890가나다라마바사아자차카파파하
9: 1234567890가나다라마바사아자차카파파하
"""

		self.varx["data"]["t2d_paint_for_max_01"] = """
#선택한 영역의 가로줄에서 가장 큰값에 색칠하는 것

xyxy = excelx.read_address_for_selection()
excelx.paint_max_value_in_range_in_each_xline("", xyxy)
"""

		self.varx["data"]["t2d_paint_for_min_01"] = """
#선택한 영역의 가로줄에서 가장 큰값에 색칠하는 것

xyxy = excelx.read_address_for_selection()
excelx.paint_min_value_in_range_in_each_xline("", xyxy)
"""

		self.varx["data"]["d1d_자모_vs_알파벳"] = {
			"ㄱ": "a", "ㄲ": "aa", "ㄴ": "b", "ㄷ": "c", "ㄸ": "cc",
			"ㄹ": "d", "ㅁ": "e", "ㅂ": "f", "ㅃ": "ff",
			"ㅅ": "g", "ㅆ": "gg", "ㅇ": "h", "ㅈ": "i",
			"ㅉ": "ii", "ㅊ": "j", "ㅋ": "k", "ㅌ": "l", "ㅍ": "m", "ㅎ": "n",

			"ㄳ": "ag", "ㄵ": "bi", "ㄶ": "bn", "ㄺ": "da",
			"ㄻ": "de", "ㄼ": "df", "ㄽ": "dg", "ㄾ": "dl",
			"ㄿ": "dm", "ㅀ": "dn", "ㅄ": "fg",

			"ㅏ": "o", "ㅐ": "ox", "ㅑ": "p", "ㅒ": "px", "ㅓ": "q",
			"ㅔ": "gx", "ㅕ": "r", "ㅖ": "rx", "ㅗ": "s", "ㅘ": "so",
			"ㅙ": "sox", "ㅚ": "sx", "ㅛ": "t", "ㅜ": "u", "ㅝ": "ug",
			"ㅞ": "ugx", "ㅟ": "ux", "ㅠ": "v", "ㅡ": "w", "ㅢ": "wx", "ㅣ": "x",

			"": "", "_": "z",
		}

		self.varx["data"]["d1d_알파벳_vs_자모"] = {
			'a': 'ㄱ', 'aa': 'ㄲ', 'b': 'ㄴ', 'c': 'ㄷ', 'cc': 'ㄸ', 'd': 'ㄹ',
			'e': 'ㅁ', 'f': 'ㅂ', 'ff': 'ㅃ', 'g': 'ㅅ', 'gg': 'ㅆ', 'h': 'ㅇ',
			'i': 'ㅈ', 'ii': 'ㅉ', 'j': 'ㅊ', 'k': 'ㅋ', 'l': 'ㅌ', 'm': 'ㅍ',
			'n': 'ㅎ', 'ag': 'ㄳ', 'bi': 'ㄵ', 'bn': 'ㄶ', 'da': 'ㄺ', 'de': 'ㄻ',
			'df': 'ㄼ', 'dg': 'ㄽ', 'dl': 'ㄾ', 'dm': 'ㄿ', 'dn': 'ㅀ', 'fg': 'ㅄ',
			'o': 'ㅏ', 'ox': 'ㅐ', 'p': 'ㅑ', 'px': 'ㅒ', 'q': 'ㅓ', 'gx': 'ㅔ',
			'r': 'ㅕ', 'rx': 'ㅖ', 's': 'ㅗ', 'so': 'ㅘ', 'sox': 'ㅙ', 'sx': 'ㅚ',
			't': 'ㅛ', 'u': 'ㅜ', 'ug': 'ㅝ', 'ugx': 'ㅞ', 'ux': 'ㅟ', 'v': 'ㅠ',
			'w': 'ㅡ', 'wx': 'ㅢ', 'x': 'ㅣ', '': '', 'z': '_'}

		self.varx["data"]["l2d_짝자료_영어단어_자모"] = [
			[['sox', 'ㅙ'], ['ugx', 'ㅞ'], ],
			[['ox', 'ㅐ'], ['px', 'ㅒ'], ['gx', 'ㅔ'], ['rx', 'ㅖ'], ['so', 'ㅘ'], ['sx', 'ㅚ'], ['wx', 'ㅢ'], ['ug', 'ㅝ'], ['ux', 'ㅟ'], ],
			[['a', 'ㄱ'], ['b', 'ㄴ'], ['c', 'ㄷ'], ['d', 'ㄹ'], ['e', 'ㅁ'], ['f', 'ㅂ'], ['g', 'ㅅ'], ['h', 'ㅇ'], ['i', 'ㅈ'], ['j', 'ㅊ'], ['k', 'ㅋ'], ['l', 'ㅌ'], ['m', 'ㅍ'], ['n', 'ㅎ']],
			[['aa', 'ㄲ'], ['cc', 'ㄸ'], ['ff', 'ㅃ'], ['gg', 'ㅆ'], ['ii', 'ㅉ'], ['ag', 'ㄳ'], ['bi', 'ㄵ'], ['bn', 'ㄶ'], ['da', 'ㄺ'], ['de', 'ㄻ'], ['df', 'ㄼ'], ['dg', 'ㄽ'], ['dl', 'ㄾ'], ['dm', 'ㄿ'],
			 ['dn', 'ㅀ'], ['fg', 'ㅄ'], ],
			[['o', 'ㅏ'], ['p', 'ㅑ'], ['q', 'ㅓ'], ['r', 'ㅕ'], ['s', 'ㅗ'], ['t', 'ㅛ'], ['u', 'ㅜ'], ['v', 'ㅠ'], ['w', 'ㅡ'], ['x', 'ㅣ'], ],
			[['z', '_']],
		]

		self.varx["data"]["table2d_전국_인구수_변화_2000_2023"] = [
			[None, '서울', '부산', '대구', '인천', '광주', '대전', '울산', '세종', '경기', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'],
			[2000.0, 10078.0, 3733.0, 2529.0, 2522.0, 1382.0, 1397.0, 1036.0, 0, 9146.0, 1516.0, 1494.0, 1879.0, 1927.0, 2035.0, 2773.0, 3036.0, 524.0],
			[2001.0, 10091.0, 3716.0, 2535.0, 2551.0, 1402.0, 1418.0, 1047.0, 0, 9451.0, 1517.0, 1499.0, 1882.0, 1916.0, 2012.0, 2757.0, 3048.0, 529.0],
			[2002.0, 10049.0, 3685.0, 2531.0, 2572.0, 1422.0, 1434.0, 1057.0, 0, 9814.0, 1510.0, 1496.0, 1877.0, 1896.0, 1963.0, 2737.0, 3070.0, 534.0],
			[2003.0, 10041.0, 3649.0, 2532.0, 2573.0, 1432.0, 1453.0, 1062.0, 0, 10149.0, 1501.0, 1491.0, 1872.0, 1871.0, 1929.0, 2705.0, 3095.0, 537.0],
			[2004.0, 10052.0, 3624.0, 2533.0, 2571.0, 1445.0, 1461.0, 1067.0, 0, 10416.0, 1497.0, 1491.0, 1892.0, 1843.0, 1881.0, 2670.0, 3102.0, 539.0],
			[2005.0, 10029.0, 3590.0, 2509.0, 2581.0, 1445.0, 1470.0, 1071.0, 0, 10625.0, 1489.0, 1485.0, 1918.0, 1817.0, 1851.0, 2652.0, 3110.0, 542.0],
			[2006.0, 10057.0, 3563.0, 2490.0, 2607.0, 1448.0, 1481.0, 1076.0, 0, 10853.0, 1482.0, 1487.0, 1943.0, 1801.0, 1830.0, 2653.0, 3123.0, 544.0],
			[2007.0, 10069.0, 3538.0, 2484.0, 2643.0, 1456.0, 1494.0, 1079.0, 0, 11057.0, 1476.0, 1494.0, 1973.0, 1792.0, 1806.0, 2643.0, 3137.0, 543.0],
			[2008.0, 10112.0, 3514.0, 2481.0, 2689.0, 1465.0, 1501.0, 1092.0, 0, 11267.0, 1480.0, 1509.0, 2013.0, 1788.0, 1794.0, 2639.0, 3166.0, 544.0],
			[2009.0, 10139.0, 3497.0, 2482.0, 2700.0, 1479.0, 1508.0, 1098.0, 0, 11413.0, 1485.0, 1517.0, 2040.0, 1792.0, 1785.0, 2634.0, 3192.0, 546.0],
			[2010.0, 10089.0, 3477.0, 2480.0, 2723.0, 1494.0, 1515.0, 1099.0, 0, 11619.0, 1489.0, 1524.0, 2078.0, 1796.0, 1777.0, 2630.0, 3217.0, 548.0],
			[2011.0, 10072.0, 3476.0, 2483.0, 2755.0, 1502.0, 1528.0, 1112.0, 0, 11825.0, 1498.0, 1545.0, 2108.0, 1809.0, 1779.0, 2645.0, 3245.0, 554.0],
			[2012.0, 10036.0, 3462.0, 2480.0, 2794.0, 1504.0, 1540.0, 1125.0, 102.0, 11974.0, 1504.0, 1553.0, 2043.0, 1817.0, 1782.0, 2656.0, 3265.0, 561.0],
			[2013.0, 9990.0, 3456.0, 2476.0, 2830.0, 1504.0, 1545.0, 1137.0, 118.0, 12126.0, 1506.0, 1565.0, 2062.0, 1821.0, 1784.0, 2661.0, 3278.0, 570.0],
			[2014.0, 9975.0, 3452.0, 2475.0, 2862.0, 1505.0, 1553.0, 1151.0, 132.0, 12282.0, 1510.0, 1578.0, 2088.0, 1829.0, 1792.0, 2671.0, 3307.0, 583.0],
			[2015.0, 9941.0, 3452.0, 2469.0, 2883.0, 1506.0, 1542.0, 1164.0, 187.0, 12423.0, 1517.0, 1589.0, 2103.0, 1835.0, 1797.0, 2678.0, 3330.0, 599.0],
			[2016.0, 9843.0, 3447.0, 2461.0, 2907.0, 1502.0, 1536.0, 1166.0, 234.0, 12600.0, 1521.0, 1601.0, 2126.0, 1835.0, 1798.0, 2683.0, 3338.0, 618.0],
			[2017.0, 9766.0, 3424.0, 2458.0, 2924.0, 1495.0, 1528.0, 1159.0, 266.0, 12786.0, 1521.0, 1609.0, 2153.0, 1829.0, 1795.0, 2675.0, 3339.0, 635.0],
			[2018.0, 9697.0, 3403.0, 2449.0, 2936.0, 1488.0, 1513.0, 1153.0, 302.0, 13027.0, 1521.0, 1618.0, 2177.0, 1823.0, 1796.0, 2675.0, 3351.0, 655.0],
			[2019.0, 9657.0, 3381.0, 2437.0, 2952.0, 1489.0, 1503.0, 1146.0, 329.0, 13241.0, 1520.0, 1629.0, 2189.0, 1812.0, 1793.0, 2671.0, 3350.0, 664.0],
			[2020.0, 9618.0, 3356.0, 2414.0, 2951.0, 1480.0, 1492.0, 1139.0, 348.0, 13452.0, 1519.0, 1631.0, 2177.0, 1806.0, 1793.0, 2652.0, 3340.0, 669.0],
			[2021.0, 9508.0, 3334.0, 2396.0, 2950.0, 1476.0, 1482.0, 1125.0, 361.0, 13611.0, 1520.0, 1626.0, 2175.0, 1792.0, 1785.0, 2641.0, 3315.0, 672.0],
			[2022.0, 9421.0, 3303.0, 2372.0, 2975.0, 1470.0, 1472.0, 1114.0, 380.0, 13690.0, 1527.0, 1623.0, 2186.0, 1777.0, 1775.0, 2626.0, 3287.0, 675.0],
			[2023.0, 9400.0, 3284.0, 2360.0, 3009.0, 1463.0, 1474.0, 1106.0, 387.0, 13781.0, 1525.0, 1627.0, 2204.0, 1768.0, 1768.0, 2611.0, 3267.0, 677.0],
		]

		self.varx["data"]["d2d_우리나라_시도_vs_좌표"] = {
			"서울": [37.540705, 126.956764],
			"부산": [35.198362, 129.053922],
			"대구": [35.798838, 128.583052],
			"인천": [37.469221, 126.573234],
			"광주": [35.126033, 126.831302],
			"대전": [36.321655, 127.378953],
			"울산": [35.519301, 129.239078],
			"세종": [36.48056, 127.28889],
			"경기": [37.567167, 127.190292],
			"강원": [37.555837, 128.209315],
			"충북": [36.628503, 127.929344],
			"충남": [36.557229, 126.779757],
			"전북": [35.716705, 127.144185],
			"전남": [34.819400, 126.893113],
			"경북": [36.248647, 128.664734],
			"경남": [35.259787, 128.664734],
			"제주": [33.364805, 126.542671], }

		self.varx["data"]["d2d_기자재_한글_vs_영어"] = {"밸브": "valve", "교반기": "agitator", "아지테이터": "agitator",
										 "송풍기": "blower", "블로어": "blower", "s/p": "spare part",
										 "케이블": "cable", "스페어파트": "spare part", "컨트롤밸브": "control valve", "컨트롤벨브": "control valve",
										 "컨테이너": "container", "정화관": "", "배터리": "battery", "차저": "charger", "액츄에이터": "actuator",
										 "토너공장": "", "환경운영": "", "다이아프램": "diaphgram", "압축기": "compressor", "컨트롤valve": "control valve",
										 "볼valve": "ball valve", "그린소재": "", "메셀로스": "", "신설": "", "개선": "",
										 "완제품": "", "호이스트": "hoist", "확보용": "", "보수재": "", "작업용": "",
										 "시운전": "", "노후장치교체": "", "환경설비": "", "변경": "", "기존품": "",
										 "교체관련": "", "교쳬": "", "호환": "", "판넬": "panel", "배관재": "piping", "파이프": "pipe",
										 "펌프": "pump", "배관담당": "", "보수용": "", "보일러": "boiler", "자동화": "",
										 "변압기": "transformer", "티타늄": "titanium", "라인드": "linned",
										 "탱크": "tank", "피팅류": "fitting", "컨트롤": "control",
										 "글로브": "globe", "열교환기": "heat exchanger",
										 "인버터판넬": "invertor panel", "스위치": "switch",
										 "산소농도측정기": "o2 analyzer", "수분분석기": "h20 analyzer",
										 "분석기": "analyzer", "인버터": "invertor", "가구": "", "가성소다": "",
										 "가스감지기": "gas detector", "가스검지기": "gas detector",
										 "가스켓": "gasket", "가스탐지기": "gas detector", "감지": "", "검사장비": "", "경고표지": "", "계단": "",
										 "교체": "", "구공장": "", "구동부": "", "구매": "", "구매요청건": "", "구축": "", "구축용": "", "기계담당": "",
										 "기업용": "", "기존": "", "기초물성": "", "냉매합리화": "", "노후": "", "노후panel": "", "단관": "",
										 "담당": "", "등": "", "等": "", "마곡연구소": "", "메인": "", "목": "", "및": "", "보수": "", "보완": "",
										 "부속10종": "", "비용정산": "", "상부": "", "선입고": "", "설치": "", "순환": "", "순환식": "", "스티커": "",
										 "신규": "", "신규제작": "", "연구1팀": "", "연구부문": "", "연구소": "", "이동": "", "이물": "", "이송": "",
										 "일반": "", "일반형": "", "전해c": "", "전해c공장": "", "전해공장용": "", "주요": "", "철거": "", "추가": "",
										 "추가부품": "", "추가정산": "", "투자": "", "투자관련": "", "포함": "", "한국요꼬가와전기": "", "한중유화": "",
										 "합리화": "", "합성공정": "", "협력사": "", }

		self.varx["data"]["d2d_열이름_vs_나라자료"] = {
			"1번째열": {'Country': 'Russia', 'Capital': 'Moscow', 'Area(Sq.Miles)': 6601670, 'Population': 146171015},
			"2번째열": {'Country': 'Canada', 'Capital': 'Ottawa', 'Area(Sq.Miles)': 3855100, 'Population': 38048738},
			"3번째열": {'Country': 'China', 'Capital': 'Beijing', 'Area(Sq.Miles)': 3705407, 'Population': 1400050000},
			"4번째열": {'Country': 'United States of America', 'Capital': 'Washington, D.C.',
					 'Area(Sq.Miles)': 3796742, 'Population': 331449281},
			"5번째열": {'Country': 'Brazil', 'Capital': 'Brasília', 'Area(Sq.Miles)': 3287956,
					 'Population': 210147125},
			"6번째열": {'Country': 'Russia', 'Capital': 'Moscow', 'Area(Sq.Miles)': 6601670, 'Population': 146171015},
			"7번째열": {'Country': 'Canada', 'Capital': 'Ottawa', 'Area(Sq.Miles)': 3855100, 'Population': 38048738},
			"8번째열": {'Country': 'China', 'Capital': 'Beijing', 'Area(Sq.Miles)': 3705407, 'Population': 1400050000},
			"9번째열": {'Country': 'United States of America', 'Capital': 'Washington, D.C.',
					 'Area(Sq.Miles)': 3796742, 'Population': 331449281},
			"10번째열": {'Country': 'Brazil', 'Capital': 'Brasília', 'Area(Sq.Miles)': 3287956,
					  'Population': 210147125}
		}

		self.varx["data"]["d2d_복합자료형태"] = {
			1: {'dic_type': 'Russia'},
			"2번째열": 12345,
			"3번째열": "abcde",
			"4번째열": 456.789,
			"5번째열": ['list_type', 'Brazil', 'Capital', 210147125],
			"6번째열": ('tuple_type', 'Russia', 'Population', 146171015),
			7: {'Country': 'Canada', 'Population': 38048738},
			"8번째열": {'Country': 'Brazil', 'Capital': 'Brasília', 'Population': 210147125}
		}

		self.varx["data"]["t2d_님의침묵_시"] = """한용운의 시, 님의 침묵

님은 갔습니다. 아아, 사랑하는 나의 님은 갔습니다.  
푸른 산빛을 깨치고 단풍나무 숲을 향하여 난 작은 길을 걸어서 차마 떨치고 갔습니다.  
황금의 꽃같이 굳고 빛나던 옛 맹세는 차디찬 티끌이 되어서 한숨의 미풍에 날려 갔습니다.

날카로운 첫키스의 추억은 나의 운명의 지침을 돌려 놓고 뒷걸음쳐서 사라졌습니다.  
나는 향기로운 님의 말소리에 귀먹고, 꽃다운 님의 얼굴에 눈멀었습니다.  
사랑도 사람의 일이라 만날 때에 미리 떠날 것을 염려하고 경계하지 아니한 것은 아니지만, 
이별은 뜻밖의 일이 되고 놀란 가슴은 새로운 슬픔에 터집니다.

기와 승의 표현상의 특징과 효과점층적 반복을 통해 상황의 절박감을 강조하였다.

그러나 이별을 쓸데없는 눈물의 원천을 만들고 마는 것은 스스로 사랑을 깨치는 것인 줄 아는 까닭에 
걷잡을 수 없는 슬픔의 힘을 옮겨서 새 희망의 정수박이에 들어부었습니다.  
우리는 만날 때에 떠날 것을 염려하는 것과 같이 떠날 때에 다시 만날 것을 믿습니다.

아아, 님은 갔지마는 나는 님을 보내지 아니하였습니다.  
제 곡조를 못 이기는 사랑의 노래는 님의 침묵을 휩싸고 돕니다"""

		self.varx["data"]["t2d_번호가있는_님의침묵_시"] = """1. 한용운의 시, 님의 침묵
2. 
3. 님은 갔습니다. 아아, 사랑하는 나의 님은 갔습니다.  
4. 푸른 산빛을 깨치고 단풍나무 숲을 향하여 난 작은 길을 걸어서 차마 떨치고 갔습니다.  
5. 황금의 꽃같이 굳고 빛나던 옛 맹세는 차디찬 티끌이 되어서 한숨의 미풍에 날려 갔습니다.
6. 
7. 날카로운 첫키스의 추억은 나의 운명의 지침을 돌려 놓고 뒷걸음쳐서 사라졌습니다.  
8. 나는 향기로운 님의 말소리에 귀먹고, 꽃다운 님의 얼굴에 눈멀었습니다.  
9. 사랑도 사람의 일이라 만날 때에 미리 떠날 것을 염려하고 경계하지 아니한 것은 아니지만, 
10.이별은 뜻밖의 일이 되고 놀란 가슴은 새로운 슬픔에 터집니다.
11.
12.기와 승의 표현상의 특징과 효과점층적 반복을 통해 상황의 절박감을 강조하였다.
13.
14.그러나 이별을 쓸데없는 눈물의 원천을 만들고 마는 것은 스스로 사랑을 깨치는 것인 줄 아는 까닭에 
15.걷잡을 수 없는 슬픔의 힘을 옮겨서 새 희망의 정수박이에 들어부었습니다.  
16.우리는 만날 때에 떠날 것을 염려하는 것과 같이 떠날 때에 다시 만날 것을 믿습니다.
17.
18.아아, 님은 갔지마는 나는 님을 보내지 아니하였습니다.  
19.제 곡조를 못 이기는 사랑의 노래는 님의 침묵을 휩싸고 돕니다"""

		self.varx["data"]["l2d_2차원_복합자료_001"] = [[11, 12, 13, 14, 15, 16, 17, 18, 19],
										 [21, 22, 23, 24, 25, 26, 27, 28, 29],
										 [31, 32, 33, "abc", 35, 36, 37, 38, "zzz"],
										 [41, 42, 43, 44, 45, 46, 47, 48, ""],
										 [51, 52, 53, 54, 55, 56, 57, 58, 59],
										 [61, 62, 63, " ", " space ", 66, 67, 68, 69],
										 [71, 72, 73, 74, 275, 76, 77, 78, 79],
										 [81, 82, 83, 84, " space ", 88886, 87, 88, 89],
										 [91, 92, 93, 94, -23, 96, 97, 98, 99],
										 ["abc", "abc", 13, 14, 15, 16, 17, 18, 19],
										 ["abc", 22, 23, "abc", 25, 26, 27, 28, "zzz"],
										 [31, 32, 33, "abc", "abc", 36, 37, 38, "zzz"],
										 ["3/1", 42, 43, "3/1", "3/1", 46, 47, 48, ""],
										 [51, "가나다", "3/1", 54, 55, 56, 57, 58, 59],
										 [61, 61, 61, " ", " space ", 66, 67, 68, 69],
										 [71, 72, 73, 74, "space", 76, 77, 78, 79],
										 [81, 82, "가나다", 84, " space ", 88886, 87, 88, 89],
										 [91, 100, "가나다", 94, -23, 96, 97, 98, 99]]

		self.varx["data"]["table2d_2차원_복합자료_002"] = [
			["", "y1", "y2", "y3", "y4", "y5", "y6", "y7", "y8", "y9"],
			["x1", 21, 22, 23, 24, 25, 26, 27, 28, 29],
			["x2", 31, 32, 33, 123, 35, 36, 37, 38, 254],
			["x3", 41, 42, 43, 44, 45, 46, 47, 48, 123],
			["x4", 51, 52, 53, 54, 55, 56, 57, 58, 59],
			["x5", 61, 62, 63, 55, 122, 66, 67, 68, 69],
			["x6", 71, 72, 73, 74, 275, 76, 77, 78, 79],
			["x7", 81, 82, 83, 84, 432, 886, 87, 88, 89],
			["x8", 91, 92, 93, 94, 23, 96, 97, 98, 99],
			["x9", 61, 61, 61, 323, 234, 66, 67, 68, 69],
			["x10", 71, 72, 73, 74, 534, 76, 77, 78, 79],
			["x11", 81, 82, 13, 84, 324, 888, 87, 88, 89],
			["x12", 91, 100, 132, 94, 23, 96, 97, 98, 99]]

		self.varx["data"]["l2d_비교자료형_숫자묶음"] = [[11, 12, 13, 14, 15, 16, 17, 18, 19],
									   [21, 22, 23, 24, 25, 26, 27, 28, 29],
									   [31, 32, 33, "abc", 35, 36, 37, 38, "zzz"],
									   [41, 42, 43, 44, 45, 46, 47, 48, ""],
									   [51, 52, 53, 54, 55, 56, 57, 58, 59],
									   [61, 62, 63, " ", " space ", 66, 67, 68, 69],
									   [71, 72, 73, 74, 275, 76, 77, 78, 79],
									   [81, 82, 83, 84, " space ", 88886, 87, 88, 89],
									   [91, 92, 93, 94, -23, 96, 97, 98, 99]]

		self.varx["data"]["l2d_근무기간용_자료"] = [
			["입사일", '퇴사일', '근무년월일수', '근무년수', '정답'],
			["2000-2-10", "2010-1-31", "10년0월0일", '10년', 10.0],
			["2000-2-11", "2001-1-31", '1년0월0일', '1년', 1.0],
			["2000-2-13", "2030-1-31", '30년0월0일', '30년', 30.0],
			["2000-2-21", "2009-1-31", '9년0월0일', '9년', 9.0],
			["2000-3-1", "2008-1-31", '8년0월0일', '8년', 8.0],
			["2000-2-10", "2007-1-31", '7년0월0일', '7년', 7.0],
			["2000-2-18", "2006-2-1", '6년0월1일', '7년', 7.0]
		]

		self.varx["data"]["d2d_정규표현식_여러샘플"] = {
			"1개이상의 공백없애기": "[공백:2~10]",
			"괄호안의 글자만 추출": "([문자:1~20])",
			"숫자만 추출": "[공백:1~3][영어:1~10]-[숫자:1~10][영어:0~10][공백:1~5]",
			"영어와 숫자만 추출": "실시간시세",
			"~~용으로 끝나는 단어": "실시간시세",
			"핸드폰번호": "[시작][숫자:4~4]-[숫자:1~2]-[숫자:1~2][끝]",
			"한글만": "[한글:1~20]",
			"복잡한 생년월일": "([0-9]{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[1,2][0-9]|3[0,1]))-[1-4][0-9]{6}",
			"이메일": r"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$",
			"abc중 c만 1번이상 반복되는것 찾기": [4, "abc[1~]", "type_z0"],
			"abc중 bc만 1번이상 반복되는것 찾기": [4, "a(bc)[1~]", "type_z0"],
			"a와 b와 c를 제외한 모든 문자와 매치": [4, "[^abc]", "type_z0"],
			"한글로 3~5개의 글자로 된것을 그룹명 짖기": [4, "(?P<그룹명>[한글:3~5])", "type_z0"],
			"a와 b사이의 모든문자 찾기": [4, "a[문자:1~]b", "type_z0"],
			"a또는b또는c": [4, "a[또는]b[또는]c", "type_z0"],
			"전방탐색 : .+(?=:) => :앞의 모든 문자": [4, ".+(?=:)", "type_z0"],
			r"후방탐색 : (?<=\$)[0-9.]+ => $뒤의 숫자": [4, r"(?<=\$)[0-9.]+", "type_z0"],
			r"Html태그중 <H숫자>찾을문자<\H숫자>안의 글자": [4, r"<H(0-30])>.*?</H\\1>", "type_z0"],
			"문장중 핸드폰번호 찾기": [4, "0[1~1][숫자:2~2]-[0~1][숫자:3~4]-[0~1][숫자:4~4]", "type_z0"],
			"2022-01-01형식의 날짜찾기": [4, "[0-9]{4})-([0-9]{2})-([0-9]{2}", "type_z0"],
			"이메일찾기": [4, r"[\w\.-]+@[\w\.-]+", "type_z0"],
			"괄호안의 숫자 찾기": [4, "([모든문자:0~])", "type_z0"],
			"지역 전화번호 찾기": [4, r"0(2|31|32|33|41|42|43|44|51|52|53|54|55|61|62|63|64)\-{0,1}\d{3,4}\-{0,1}\d{4}", "type_z0"],
			"주민등록번호": [4, "[0-9]{2}0[1-9]|1[0-2]0[1-9]|[1,2][0-9]|3[0,1]-[1-4][0-9]{6}", "type_z0"],
			"금액": [4, "[숫자,][1~][원:0~1]", "type_z0"],
			"중복된 단어 찾기": [4, "\\b(\\w+)\\s+\\1\\b", "type_z0"],
		}

		self.varx["data"]["d2d_엑셀용자료_02"] = [{"x": 2, "y": 1, "kind_1": "basic", "kind_2": "date", "value": datetime.datetime(2002, 2, 2)},
									 {"x": 2, "y": 3, "kind_1": "basic", "kind_2": "basic", "text": "값"},
									 {"x": 2, "y": 5, "kind_1": "basic", "kind_2": "basic", "text": "값"},
									 {"x": 2, "y": 7, "kind_1": "basic", "kind_2": "date", "value": datetime.datetime(2002, 2, 2)},
									 {"x": 2, "y": 6, "kind_1": "tool_tip", "text": "tool_tip", "tool_tip": "툴팁입니다"},
									 {"x": 5, "y": 3, "kind_1": "widget", "kind_2": "combo", "value": [1, 2, 3, 4, 5]},
									 {"x": 5, "y": 5, "kind_1": "widget", "kind_2": "check_box", "checked": 1, "text": "check"},
									 {"x": 5, "y": 7, "kind_1": "widget", "kind_2": "progress_bar", "value": 30},
									 {"x": 5, "y": 8, "kind_1": "widget", "kind_2": "button", "caption": "button_1", "action": "action_def"},
									 {"x": 10, "y": 10, "kind_1": "memo", "value": "memo memo"},
									 {"x": 2, "y": 2, "kind_1": "memo", "value": "memo memo"},
									 {"x": 7, "y": 3, "kind_1": "font_color", "value": [255, 63, 24]},
									 {"x": 7, "y": 5, "kind_1": "background_color", "value": [255, 63, 24]}, ]

		self.varx["data"]["t2d_번호가있는_시_나로부터_시작"] = """ 1. 어릴 때는 나보다 중요한 사람이 없었고,
 2. 나이 들면 나만큼 대단한 사람이 없으며,
 3. 늙고 나면 나보다 못한 사람이 없다.
 4.  
 5. 돈을 맞춰 일하면 직업이고,
 6. 돈을 넘어 일하면 소명이다.
 7. 직업으로 일하면 월급을 받고,
 8. 소명으로 일하면 선물을 받는다.
 9. 
10. 칭찬에 익숙하면 비난에 마음이 흔들리고,
11. 대접에 익숙하면 푸대접에 마음이 상한다.
12. 문제는 익숙해져 길들여진 내 마음이다.
13.  
14. 집은 좁아도 같이 살 수 있지만,
15. 사람 속이 좁으면 절대같이 못 산다.
16.  
17. 내 힘으로 할 수 없는 일에 도전하지 않으면,
18. 내 힘으로 갈 수 없는 곳에 이를 수 없다.
19. 사실 나를 넘어서야 이곳을 떠나고,
20. 나를 이겨내야 그곳에 이른다.
21. 갈 만큼 갔다고 생각하는 곳에서
22. 얼마나 더 갈 수 있는지 아무도 모르고,
23. 참을 만큼 참았다고 생각하는 곳에서
24. 얼마나 더 참을 수 있는지 누구도 모른다.
25.  
26. 지옥을 만드는 방법은 간단하다.
27. 가까이 있는 사람을 미워하면 된다.
28. 천국을 만드는 방법도 간단하다.
29. 가까이 있는 사람을 사랑하면 된다.
30. 
31. 모든 것이 다 가까이에서 시작된다.
32. 상처를 받을 것인지 말 것인지
33. 내가 결정한다.
34. 그 사람 행동은 어쩔 수 없지만
35. 반응은 언제나 내 몫이다.
36.  
37. 산고를 겪어야 새 생명이 태어나고
38. 꽃샘추위를 겪어야 봄이 오며,
39. 어둠이 지나야 새벽이 온다.
40. 
41. 거칠게 말할수록 거칠어지고
42. 사납게 말할수록 사나워진다.
43. 결국 모든 것이 나로부터
44. 시작되는 것이다.
45. 
46. 모든 것은 나 자신에게 달려 있다
47. 
48. 백범 김구"""

		self.varx["data"]["l2d_주소와_좌표자료"] = [
			['강원도', '강릉시', '', '주문진읍', '삼교리', 37.883431, 128.73366],
			['강원도', '강릉시', '', '주문진읍', '장덕리', 37.878328, 128.784153],
			['강원도', '강릉시', '', '주문진읍', '주문리', 37.897511, 128.82772],
			['강원도', '강릉시', '', '주문진읍', '향호리', 37.9049, 128.80247],
			['강원도', '강릉시', '', '주문진읍', '', 37.886673, 128.762214],
			['강원도', '강릉시', '', '강동면', '모전리', 37.71792, 128.964641],
			['강원도', '강릉시', '', '강동면', '산성우리', 37.676072, 129.014238],
			['강원도', '강릉시', '', '강동면', '상시동리', 37.727487, 128.949515],
			['강원도', '강릉시', '', '강동면', '심곡리', 37.666622, 129.051145],
			['강원도', '강릉시', '', '강동면', '안인리', 37.728447, 128.976768],
			['강원도', '강릉시', '', '강동면', '안인진리', 37.732926, 128.986718],
			['강원도', '강릉시', '', '강동면', '언별리', 37.695747, 128.936773],
			['강원도', '강릉시', '', '강동면', '임곡리', 37.674761, 128.969167],
			['강원도', '강릉시', '', '강동면', '정동진리', 37.688528, 129.031673],
			['강원도', '강릉시', '', '강동면', '하시동리', 37.73852, 128.960559],
			['강원도', '강릉시', '', '구정면', '구정리', 37.707571, 128.871891],
			['강원도', '강릉시', '', '구정면', '금광리', 37.709722, 128.915797],
			['강원도', '강릉시', '', '구정면', '덕현리', 37.710876, 128.929309],
			['강원도', '강릉시', '', '구정면', '어단리', 37.695746, 128.904671],
			['강원도', '강릉시', '', '구정면', '여찬리', 37.721853, 128.877571],
			['강원도', '강릉시', '', '구정면', '제비리', 37.721402, 128.857699],
			['강원도', '강릉시', '', '구정면', '학산리', 37.708848, 128.892825],
			['강원도', '강릉시', '', '구정면', '', 37.698503, 128.885032],
			['강원도', '강릉시', '', '사천면', '노동리', 37.813098, 128.830469],
			['강원도', '강릉시', '', '사천면', '덕실리', 37.812046, 128.842263],
			['강원도', '강릉시', '', '사천면', '미노리', 37.825944, 128.857105],
			['강원도', '강릉시', '', '사천면', '방동리', 37.820893, 128.863786],
			['강원도', '강릉시', '', '사천면', '사기막리', 37.791322, 128.811454],
			['강원도', '강릉시', '', '사천면', '사천진리', 37.839524, 128.873287],
			['경기도', '안양시', '만안구', '박달1동', '', 37.403573, 126.909114],
			['경기도', '안양시', '만안구', '박달2동', '', 37.401675, 126.901687],
			['경기도', '안양시', '동안구', '비산1동', '', 37.399865, 126.933349],
			['경기도', '안양시', '동안구', '비산2동', '', 37.397081, 126.941395],
			['경기도', '안양시', '동안구', '비산3동', '', 37.404401, 126.94476],
			['경기도', '안양시', '동안구', '비산동', '', 37.40422, 126.946599],
			['경기도', '안양시', '동안구', '신촌동', '', 37.381933, 126.956423],
			['경기도', '안양시', '동안구', '평안동', '', 37.390399, 126.964245],
			['경기도', '안양시', '동안구', '평촌동', '', 37.388738, 126.967983],
			['서울특별시', '', '성동구', '상왕십리동', '', 37.569332, 127.025349],
			['서울특별시', '', '성동구', '성수1가제1동', '', 37.543511, 127.042746],
			['서울특별시', '', '성동구', '성수1가제2동', '', 37.543511, 127.042746],
			['서울특별시', '', '성동구', '성수2가제1동', '', 37.540855, 127.056517],
			['서울특별시', '', '성동구', '성수2가제3동', '', 37.540855, 127.056517],
			['서울특별시', '', '성동구', '송정동', '', 37.553181, 127.062066],
			['서울특별시', '', '성동구', '송정동', '', 37.552124, 127.067652],
			['서울특별시', '', '노원구', '상계8동', '', 37.666726, 127.051548],
			['서울특별시', '', '노원구', '상계9동', '', 37.66449, 127.063818],
			['서울특별시', '', '노원구', '상계동', '', 37.6671, 127.072189],
		]

		self.varx["data"]["l1d_시_먼후일"] = ["먼 훗날 당신이 찾으시면",
								  "그때에 내 말이 잊었노라",
								  "당신이 속으로 나무라면",
								  "무척 그리다가 잊었노라",
								  "그래도 당신이 나무라면",
								  "믿기지 않아서 잊었노라",
								  "오늘도 어제도 아니 잊고",
								  "먼 훗날 그때에 잊었노라", ]

		self.varx["data"]["l2d_시_먼후일"] = [["먼 훗날", "당신이", "찾으시면"],
								  ["그때에", "내 말이", "잊었노라"],
								  ["당신이", "속으로", "나무라면"],
								  ["무척", "그리다가", "잊었노라"],
								  ["그래도", "당신이", "나무라면"],
								  ["믿기지", "않아서", "잊었노라"],
								  ["오늘도", "어제도", "아니 잊고"],
								  ["먼 훗날", "그때에", "잊었노라"], ]


		self.varx["data"]["l2d_연습용_같은자료포함_01"] = [
			['강원도', '강릉시', '밑에가 빈자료', '주문진읍', '삼교리', 1234, 128.73366, "2025-12-31"],
			['강원도', '강릉시', '밑에가 빈자료', '주문진읍', '장덕리', 1234, 128.784153, "2025-12-31"],
			['강원도', '강릉시', '밑에가 빈자료', '주문진읍', '주문리', 1234, 128.82772, "2025-12-31"],
			['강원도', '강릉시', '', '주문진읍', '향호리', 1234, 128.80247, "2025-12-31"],
			['강원도', '강릉시', '', '주문진읍', '', 1234, 128.762214, "2025-12-31"],
			['강원도', '강릉시', '', '강동면', '모전리', '   왼쪽이 공백', 128.964641, "2025-12-31"],
			['강원도', '강릉시', '', '강동면', '산성우리', '   왼쪽이 공백', 129.014238, "2026-06-06"],
			['강원도', '강릉시1', '', '강동면', '상시동리', '   왼쪽이 공백', 128.964641, "2026-06-06"],
			['강원도', '강릉시2', '', '강동면', '심곡리', '   왼쪽이 공백', 129.964641, "2026-06-06"],
			['강원도', '강릉시3', '', '구정면', '어단리', 37.695746, 128.904671, "2026-06-06"],
			['강원도', '강릉시4', '', '구정면', '여찬리', 37.721853, 128.877571, "2026-06-06"],
			['강원도', '강릉시5', '여기도 빈자료', '구정면', '제비리', 37.721402, 128.964641, "2026-06-06"],
			['강원도', '강릉시6', '', '구정면', '학산리', ' 1234가나다abc ', 128.964641, "2026-06-06"],
			['강원도', '강릉시7', '', '구정면', '', ' 1234가나다abc ', 128.964641, "2027-10-10"],
			['강원도', '강릉시8', '특수문자포함(#$%)', '사천면', '노동리', ' 1234가나다abc ', 128.964641, "2027-10-10"],
			['강원도', '강릉시', '특수문자포함(#$%)', '사천면', '덕실리', 37.812046, 128.842263, "2027-10-10"],
			['강원도', '강릉시', '특수문자포함(#$%)', '사천면', '미노리', ' 1234가나다abc ', 128.857105, "2027-10-10"],
			['강원도', '강릉시', '특수문자포함(#$%)', '사천면', '방동리', ' 1234 가나다 abc ', 128.863786, "2027-10-10"],
			['강원도', '강릉시', '특수문자포함(#$%)', '사천면', '사기막리', 37.791322, 128.811454, "2027-10-10"],
			['강원도', '강릉시', '', '사천면', '사천진리', ' 1234 가나다 abc ', 128.873287, "2027-10-10"],
			['경기도', '안양시', '만안구', '박달1동', '', ' 1234 가나다 abc ', 126.909114, "2020-02-02"],
			['경기도', '안양시', '만안구', '박달2동', '', ' 1234 가나다 abc ', 126.901687, "2020-02-02"],
			['경기도', '안양시', '동안구', '비산동', '', ' 1234 가나다 abc ', 126.946599, "2020-02-02"],
			['경기도', '안양시', '동안구', '신촌동', '', ' 1234 (가나다) abc ', 126.956423, "2020-02-02"],
			['경기도', '안양시', '동안구', '평안동', '', ' 1234 (가나다) abc ', 126.964245, "2020-02-02"],
			['경기도', '안양시', '동안구', '평촌동', '', ' 1234 (가나다) abc ', 126.967983, "2020-02-02"],
			['서울특별시', '', '성동구', '상왕십리동', '', ' 1234 (가나다) abc ', 127.025349, "1968-06-28"],
			['서울특별시', '', '성동구', '성수2가제1동', '', ' 1234 (가나다) abc ', 127.056517, "1968-06-28"],
			['서울특별시', '', '성동구', '성수2가제3동', '', '오른쪽이 공백   ', 127.056517, "1968-06-28"],
			['서울특별시', '', '성동구', '송정동', '', '오른쪽이 공백   ', 127.062066, "1968-06-28"],
			['서울특별시', '', '노원구', '상계9동', '', '오른쪽이 공백   ', 127.063818, "1968-06-28"],
			['서울특별시', '', '노원구', '상계동', '', '오른쪽이 공백   ', 127.072189, "1968-06-28"],
		]


