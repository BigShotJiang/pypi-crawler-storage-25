import re, math, string, random, os, itertools, copy
import pywintypes, webbrowser, psutil
import ctypes
import datetime
from xython import xy_re, xy_color, xy_util, xy_time, xy_common
import win32gui, win32com.client


common_dic = {}

class xy_excel:

    def __init__(self, filename='', cache_tf=''):
        """
        __init__는 이 모듈이 실행이 될때 제일 먼저 자동으로 실행이 되는 함수이다

        공통으로 사용할 변수들을 설정
        """
        self.xycolor = xy_color.xy_color()
        self.xyutil = xy_util.xy_util()
        self.xyre = xy_re.xy_re()
        self.xytime = xy_time.xy_time()

        self.varx: dict = xy_common.xy_common().varx  # package안에서 공통적으로 사용되는 변수들
        self.v_pen_color = ""
        self.v_font = {}
        self.v_pen_style = 4
        self.v_pen_thickness = 5
        self.v_start_point_width = 2
        self.v_start_point_length = 2
        self.v_start_point_style = 1
        self.v_end_point_width = 2
        self.v_end_point_length = 2
        self.v_end_point_style = 1
        self.border_line = {}

        self.xyxy = None
        self.xyxy2 = None
        self.sheet_name = ''
        self.sheet = None
        self.sheet2 = None
        self.xy = None
        self.xy2 = None
        self.color = None
        self.color2 = None
        self.fontcolor = None
        self.linecolor = None
        self.bgcolor = None


        if filename == "no" or filename == "not":  # 화일을 열지 않고 실행시키기위한 부분
            pass
        else:
            self.__start_pcell(filename, cache_tf)

    def __start_pcell(self, filename='', cache_tf=''):
        """
        엑셀 객체를 초기화하고 워크북을 열거나 생성합니다.

        __init__에서 분리된 내부 메서드로, 실제 엑셀 애플리케이션 연결 및
        워크북 처리를 담당합니다.

                        - None/""/active: 현재 활성 워크북
                        - "new": 새 워크북 생성
                        - int: 열린 워크북 중 n번째
                        - str: 파일 경로 또는 이름
        :return: 워크북 객체
        """
        try:
            self.xlapp = win32com.client.GetActiveObject("Excel.Application")
        except:
            self.xlapp = win32com.client.dynamic.Dispatch("Excel.Application")

        if isinstance(filename, str): filename = str(filename).lower()

        if filename in [None, "", "activeworkbook", "active_workbook", "active"]:
            if self.xlapp.ActiveWorkbook:
                self.xlbook = self.xlapp.ActiveWorkbook
            else:
                self.xlapp.WindowState = -4137
                self.xlapp.Visible = 1
                self.xlbook = self.xlapp.Workbooks.Add()

        elif filename == "new":
            self.xlapp.WindowState = -4137
            self.xlapp.Visible = 1
            self.xlbook = self.xlapp.Workbooks.Add()

        elif isinstance(filename, int):
            # 이미 열려화일에 같은 화일이름이 있는지 확인
            if filename <= self.xlapp.WorkBooks.Count:
                self.xlbook = self.xlapp.Workbooks[filename - 1]

        elif filename:
            # 이미 열린화일에 같은 화일 이름이 있는지 확인
            file_found = False
            for index in range(self.xlapp.Workbooks.Count):
                short_name = self.xlapp.Workbooks[index].Name
                one_file = self.xyutil.check_file_path(self.xlapp.Workbooks[index].FullName)
                if str(one_file).lower() == str(filename).lower() or str(short_name).lower() == str(filename).lower():
                    self.xlbook = self.xlapp.Workbooks[index]
                    file_found = True
                    break

            # 열려진 화일중에 같은 것이 없으면, 화일을 연다
            if not file_found:
                path = ""
                self.xlapp.WindowState = -4137
                self.xlapp.Visible = 1
                if not "\\" in filename:
                    path = os.path.normpath(os.getcwd()) + '\\'

                if path.endswith('\\'):
                    self.xlbook = self.xlapp.Workbooks.Open(path + filename + ".xlsx")
                else:
                    self.xlbook = self.xlapp.Workbooks.Open(path + '\\' + filename + ".xlsx")

        # 현재 시트의 제일 큰 가로와 세로열을 설정한다
        self.get_max_x_n_y_for_sheet()
        return self.xlbook

    def _check_3_param(self, param1, param2, param3):
        # 3개를 입력하는 변수에서 1개만 사용을하면 자동적으로 맨마지막 변수가 들어온것으로 만드는 함수
        # 이것은 통상 앞의 2변수가 ''으로 작동을 하는 경우에만 사용하여야 한다
        if param3 == None and param2 == '' and param1 =='':
            param3 = param1
            param1 = ''
            param2 = ''
        return [param1, param2, param3]

    def activeworkbook_obj(self):
        """
        화설화된 엑셀의 객체를 갖고오는 것
        """
        return self.xlapp.ActiveWorkbook

    def add_num_for_range(self, sheet_name='', xyxy='', input_value=None, is_text_tf=True):
        """
        입력영역의 안의 모든 값에 입력으로 들어온 숫자나 문자를 더하는 것
        에러가 발생을 하면, 그냥 무시하고 다음것을 실행
        add는 현재있는 자료를 변경하거나 추가 삭제할때 사용하는 접두사이다

        :return: None,
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        try:
            for x in range(x1, x2 + 1):
                for y in range(y1, y2 + 1):
                    one_value = sheet.Cells(x, y).Value
                    if not is_text_tf:
                        sheet.Cells(x, y).Value = str(one_value) + input_value
                    else:
                        if isinstance(one_value, str):
                            sheet.Cells(x, y).Value = str(one_value) + input_value
        except:
            pass

    def add_text(self, input_value, left_or_right = "right"):
        if left_or_right == "right":
            self.add_text_at_right(self.sheet_name, self.xyxy, input_value)
        elif left_or_right == "left":
            self.add_text_at_left(self.sheet_name, self.xyxy, input_value)


    def add_text_at_left(self, sheet_name='', xyxy='', input_value=None):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            sheet.Cells(x, y).Value = str(input_value) + str(sheet.Cells(x, y).Value)

    def add_text_at_right(self, sheet_name='', xyxy='', input_value=None):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            sheet.Cells(x, y).Value = str(sheet.Cells(x, y).Value) + str(input_value)

    def alert_off(self):
        self.xlapp.DisplayAlerts = False

    def alert_on(self):
        self.xlapp.DisplayAlerts = True

    def set_alert_off(self):
        self.xlapp.DisplayAlerts = False

    def set_alert_on(self):
        self.xlapp.DisplayAlerts = True

    def arrange_all_sheet_by_name(self):
        """
        현재 워크북의 모든 시트를 이름순으로 정렬하는것
        """
        sheets_name = self.all_sheet_name()
        sheets_name.sort()
        for index, one_value in enumerate(sheets_name):
            self.move_sheet_position_by_no(one_value, index + 1)

    def arrange_columns_for_two_range_by_base_title(self, sheet1, xyxy1, sheet2, xyxy2):
        """
        sheet1의 제목 순서를 기준으로 sheet2의 열을 재정렬

        """
        sheet1_obj = self.check_sheet_name(sheet1)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy1)

        sheet2_obj = self.check_sheet_name(sheet2)
        [x3, y3, x4, y4] = self.change_address_to_xyxy(xyxy2)

        # 기준 시트의 제목들을 먼저 모두 읽기
        base_headers = []
        for base_y in range(y1, y2 + 1):
            base_value = sheet1_obj.Cells(x1, base_y).Value
            base_headers.append(base_value)

        # 변경 시트의 제목들을 먼저 모두 읽기
        change_headers = []
        for change_y in range(y3, y4 + 1):
            change_value = sheet2_obj.Cells(x3, change_y).Value
            change_headers.append(change_value)

        # base_headers 순서대로 처리
        for index, base_value in enumerate(base_headers):
            target_pos = y3 + index  # 이동해야 할 목표 위치
            found = False

            # sheet2에서 해당 제목 찾기 (현재 위치부터 끝까지)
            for search_y in range(target_pos, y4 + 1):
                search_value = sheet2_obj.Cells(x3, search_y).Value

                if search_value == base_value:
                    found = True
                    print(f"  → 발견 위치: {search_y}, 값: {search_value}")

                    # 이미 올바른 위치에 있으면 패스
                    if search_y == target_pos:
                        print(f"  → 이미 올바른 위치")
                    else:
                        # 열 이동
                        print(f"  → 열 이동: {search_y} -> {target_pos}")
                        self.move_yline([sheet2, sheet2], [search_y, target_pos])
                    break

            # base에는 있지만 change에 없으면 빈 열 삽입
            if not found:
                print(f"  → 없음. 빈 열 삽입: {target_pos}")
                self.insert_yline(sheet2, target_pos)
                y4 += 1  # 전체 범위 확장

    def arrange_sheet_same_with_another_sheet_condition(self, sheet1, xyxy1, sheet2, xyxy2):
        """
        두개의 시트에서 하나를 기준으로 다른 하나의 시트 내용을 정렬하는것
        첫번째 시트의 제일 윗줄을 기준으로 두번째 시트를 정렬 하는것
        """
        self.arrange_columns_for_two_range_by_base_title(sheet1, xyxy1, sheet2, xyxy2)

    def autofill_for_range(self, sheet_name='', xyxy=''):
        """
        자동채우기 기능이며, 선택된 영역안의 빈곳을 위의 값으로 채우는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                if not one_value and ix != 0:
                    sheet.Cells(x1 + ix, y1 + iy).Value = l2d[ix - 1][iy]

    def autofilter_for_range(self, sheet_name='', xyxy='', input_tf=True):
        """
        선택한 영역안의 자동필터를 실행하는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        if input_tf:
            rng.Columns.AutoFilter()
        else:
            rng.Columns.AutoFilter(input_tf)

    def autofilter_for_range_with_option(self, sheet_name, xyxy, y_line=3, operator="or", input_value1="123", input_value2="있음"):
        """
        선택한 영역안의 자동필터를 실행과 입력값으로 필터링하기

        Field : 설정이되는 Autofilter에서 적용을 원하는 열의 번호 (no)
        Criteria1 : 걸러내고자하는 기준값1, 다음과 같은 특수값 허용( "=" 값이 공백인 경우, "<>" 값이 공백이 아닌 경우, "><" (No Data)생략될 경우, 모든 데이터를 선택하는 것과 같다.
        Operator : 열겨형 XlAutoFilterOperaotr에 자세히 설명
        Criteria2 : 걸러내고자하는 기준값2
        VisibleDropDown : 제목 필드에 세모 버튼을 표기할지 유무

        xlAnd : 1, Criteria1 과 Criteria2에 대한논리적 AND 연산 결과
        xlOr : 2, Criteria1 과 Criteria2에 대한논리적 OR 연산 결과
        xlTop10Items : 3, 상위 10 개 아이템
        xlBottom10Items : 4, 하위 10 개 아이템
        xlTop10Percent : 5, 상위 10 퍼센트
        xlBottom10Percent : 6, 하위 10 퍼센트
        xlFilterValues : 7, 값에 대한 필터
        xlFilterCellColor : 8, 셀의 색깔에 대한 필터
        xlFilterFontColor : 9, 글자색에 대한 필터
        xlFilterIcon : 10, 아이콘에 대한 필터
        xlFilterDynamic : 11, 다이나믹 필터
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Columns.AutoFilter(1)
        input_dic = {"Field": y_line}

        not_empty = ["not empty", "있음"]
        empty = ["empty", "비었음", "없음", ""]

        if operator == "and":
            input_dic["Criteria1"] = input_value1
            input_dic["Criteria2"] = input_value2
            input_dic["Operator"] = 1

        elif operator == "or":
            input_dic["Criteria1"] = input_value1
            input_dic["Criteria2"] = input_value2
            input_dic["Operator"] = 2

        elif operator == "top10":
            input_dic["Operator"] = 3

        elif operator == "bottom10":
            input_dic["Operator"] = 4

        elif operator == "top10%":
            input_dic["Operator"] = 5

        elif operator == "bottom10%":
            input_dic["Operator"] = 6

        elif operator == "value" or operator == "":
            input_dic["Operator"] = 7

            if input_value1 in empty:
                input_value1 = "="
            elif input_value1 in not_empty:
                input_value1 = "<>"
            input_dic["Criteria1"] = input_value1

        elif operator == "cell_color":
            input_dic["Operator"] = 8
            if isinstance(input_value1, list):
                input_value1 = self.xycolor.change_rgb_to_rgbint(input_value1)
            input_dic["Criteria1"] = input_value1

        elif operator == "font_color":
            input_dic["Operator"] = 9
            if isinstance(input_value1, list):
                input_value1 = self.xycolor.change_rgb_to_rgbint(input_value1)
            input_dic["Criteria1"] = input_value1
        elif operator == "icon":
            operator = 10
        elif operator == "dynamic":
            operator = 11

        rng.AutoFilter(**input_dic)

    def autofit_for_range(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역의 열 너비를 내용에 맞게 자동 조정합니다.
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        new_y1 = self.change_num_to_char(y1)
        new_y2 = self.change_num_to_char(y2)
        sheet.Columns(new_y1 + ':' + new_y2).AutoFit()

    def autofit_for_xline(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역의 열 너비를 내용에 맞게 자동 조정합니다.

        excel.autofit_for_xline("", "A1:C10")
        excel.autofit_for_xline()
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Rows.AutoFit()

    def autofit_for_yline(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역의 열 너비를 내용에 맞게 자동 조정합니다.

        excel.autofit_for_yline("", "A1:C10")
        excel.autofit_for_yline()
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Columns.AutoFit()

    def calc_angle_by_pxyxy(self, px1, py1, px2, py2):
        """
        두개의 픽셀좌표값을 이용해서 각도를 계산하는 것
        """
        angle_radians = math.atan2((px2 - px1), (py2 - py1))
        angle_degrees = math.degrees(angle_radians)
        if angle_degrees == 0:
            angle_degrees += 360
        return angle_degrees

    def calc_cxy_by_angle_n_length_from_old_cxy(self, px, py, angle_degree, length):
        """
        시작점을 기준으로 각도와 길이를 주면 좌표를 구해 주는것
        가로를 0으로하고, 왼쪽으로 360 도까지 가는 좌표를 구하는것
        """
        angle_radian = math.radians(angle_degree)
        px2 = px + length * math.sin(angle_radian)
        py2 = py - length * math.cos(angle_radian)
        return [px2, py2]

    def cell_addrsss(self, sheet_name='', xyxy=''):
        return self.get_address_for_cell(sheet_name, xyxy)

    def cell_obj(self, sheet_name='', xyxy=''):
        """
        입력 셀의 객체를 만들어서 돌려준다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return sheet.Cells(x1, y1)

    def change_56color_to_rgbint(self, input_56color):
        """
        엑셀 기본 56색 팔레트 인덱스를 RGB 정수값으로 변환합니다.
        """
        rgb = self.xycolor.change_56color_to_rgb(input_56color)
        result = self.xycolor.change_rgb_to_rgbint(rgb)
        return result

    def change_address_to_lrtb(self, xyxy="", left=10, right=10, top=30, bottom=70):
        """
        입력으로 들어오는 영역에서 특정한 영역을 추출하거나 변경하는것
        x : +는 오른쪽으로 확장, - 는 왼쪽으로 이동, 0은 한줄만 남기고 나머지는 없애기

        만약 왼쪽 2줄만 남기고 싶다면, 아래와같이 2번 하면 된다
        [xyxy, 0, "","",""]
        [xyxy, 2, "","",""]

        """
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        if left == 0:
            y1 = y2
        elif left == "":
            pass
        else:
            y1 = y1 + left

        if right == 0:
            y2 = y1
        elif right == "":
            pass
        else:
            y2 = y2 + right

        if top == "":
            pass
        elif top == 0:
            x1 = x2
        else:
            x1 = x1 + top

        if bottom == "":
            pass
        elif bottom == 0:
            x2 = x1
        else:
            x2 = x2 + bottom

        return [x1, y1, x2, y2]

    def change_address_to_pxywh(self, sheet_name='', xyxy=''):
        """
        입력영역의 크기를 픽셀의 주소와 넓이 높이로 바꾸는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return [rng.Left, rng.Top, rng.Width, rng.Height]

    def change_address_to_pxyxy(self, xyxy=''):
        """
        셀의 번호를 주면, 셀의 왼쪽과 오른쪽아래의 픽셀 주소를 돌려준다
        픽샐의 값으로 돌려주는것
        """
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        px1, py1, px1_w, py1_h = self.get_coord_for_cell("", [x1, y1])
        px2, py2, px2_w, py2_h = self.get_coord_for_cell("", [x2, y2])

        return [px1, py1, px2 + px2_w - px1, py2 + py2_h - py1]

    def change_address_to_r1c1(self, xyxy=''):
        """
        입력으로 들어오는 [1,2,3,4] 를 "b1:d3"로 변경하는 것
        """
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        str_1 = self.change_num_to_char(y1)
        str_2 = self.change_num_to_char(y2)
        if str(x1) == "0": x1 = ""
        if str(x2) == "0": x2 = ""
        if str_1 == "0": str_1 = ""
        if str_2 == "0": str_2 = ""

        return str_1 + str(x1) + ":" + str_2 + str(x2)

    def change_address_to_r1r1(self, xyxy=''):
        """
        [1,2,3,4]형태의 자료를 "b1:b1"의 형태로 변경하는 것
        """
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)

        str_1 = self.change_num_to_char(y1)
        return str_1 + str(x1) + ":" + str_1 + str(x1)

    def change_address_to_xyxy(self, xyxy=''):
        """
        입력으로 들어오는 여러형태의 주소값을 확인하는 것
        """

        if xyxy == "" or xyxy == None:  # 아무것도 입력하지 않을때
            xyxy = self.xlapp.Selection.Address
        elif type(xyxy) == type(self.xlapp.Selection):  # range객체가 들어왔을때 적용하기 위한것
            xyxy = xyxy.Address

        if xyxy == [0, 0] or xyxy == [0, 0, 0, 0]:
            result = [1, 0, 1048576, 0]

        elif isinstance(xyxy, str):  # 문자열일때
            if "!" in xyxy:
                xyxy = xyxy.replace("=", "").split("!")[1]
            try:
                result = self.change_string_address_to_xyxy(xyxy)
            except:
                # 혹시 문자열이 이름영역일 경우
                sheet = self.check_sheet_name("")
                temp = sheet.Range(xyxy).Address
                result = self.change_string_address_to_xyxy(temp)

        elif isinstance(xyxy, list):  # 리스트형태 일때
            if len(xyxy) == 2:
                xyxy = xyxy + xyxy

            result = []
            for one in xyxy:
                if isinstance(one, int):
                    result.append(one)
                elif isinstance(one, str):  # 문자열일때
                    if "!" in one:
                        one = one.replace("=", "").split("!")[1]
                    temp = self.change_char_to_num(one)
                    result.append(temp)

        try:
            changed_result = [min(result[0], result[2]),
                              min(result[1], result[3]),
                              max(result[0], result[2]),
                              max(result[1], result[3])]
        except:
            changed_result = result

        return changed_result

    def change_alpha_to_int(self, input_value):
        """
        엑셀 열 주소 문자(A, B, AA 등)를 숫자로 변환합니다.

        :return: 열 번호 (1부터 시작)
        """
        result = 0
        for num in range(len(input_value)):
            result = result + (string.ascii_lowercase.index(input_value[num]) + 1) * (26 ** num)
        return result

    def change_any_data_to_l2d(self, data, expand_dict=False):
        """

        """
        result = self.xyutil.change_any_data_to_l2d(data, expand_dict)
        return result

    def change_char_to_num(self, input_char):
        """
        문자열 형식의 주소를 숫자로 바꿔주는 것
        예를들어 b를 2로 바꾸는것이다
        문자가 오던 숫자가 오던 숫자로 변경하는 것이다
        """
        aaa = re.compile("^[a-zA-Z]+$")  # 처음부터 끝가지 알파벳일때
        result_str = aaa.findall(str(input_char))

        bbb = re.compile("^[0-9]+$")  # 처음부터 끝가지 숫자일때
        result_num = bbb.findall(str(input_char))

        if result_str != []:
            no = 0
            result = 0
            for one in input_char.lower()[::-1]:
                num = string.ascii_lowercase.index(one) + 1
                result = result + 26 ** no * num
                no = no + 1
        elif result_num != []:
            result = int(input_char)
        else:
            result = "error"
        return result

    def change_date_type_to_text_style(self, value):
        """
        날짜/시간 타입을 문자열로 변환
        """
        if value is None:
            return None

        # pywintypes.TimeType 처리
        try:
            if isinstance(value, pywintypes.TimeType):
                value_str = str(value)
                parts = value_str.split(" ")
                if len(parts) > 1:
                    # 시간 부분이 00:00:00이면 날짜만 반환
                    if parts[1].startswith("00:00:00"):
                        return parts[0]
                    else:
                        # 타임존 정보 제거
                        time_part = parts[1].split("+")[0] if "+" in parts[1] else parts[1]
                        return f"{parts[0]} {time_part}"
                return parts[0]
        except:
            pass

        # datetime 타입 처리
        if isinstance(value, datetime.datetime):
            if value.hour == 0 and value.minute == 0 and value.second == 0:
                return value.strftime("%Y-%m-%d")
            return value.strftime("%Y-%m-%d %H:%M:%S")

        # date 타입 처리
        if isinstance(value, datetime.date):
            return value.strftime("%Y-%m-%d")

        # 시간 타입이 클래스명에 포함된 경우 (일반적인 처리)
        if hasattr(value, '__class__') and 'time' in value.__class__.__name__.lower():
            value_str = str(value)
            if '+' in value_str:
                value_str = value_str.split('+')[0]
            if ' 00:00:00' in value_str:
                value_str = value_str.replace(' 00:00:00', '')
            return value_str.strip()

        return value

    def change_eng_to_int(self, input_value):
        """
        영문을 숫자로 바꾸는 것
        """
        return self.change_char_to_num(input_value)

    def change_l2d_as_range_first(self, input_l2d, xyxy):
        """
        영역을 우선으로 자료를 변경하고 싶을때, 자료 변경용으로 사용합니다

        """
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy)
        result = []
        for l1d in input_l2d[:x2 - x1 + 1]:
            result.append(l1d[:y2 - y1 + 1])
        return result

    def change_num_to_char(self, input_no):
        """
        영역주소를 변경하기 위해서 숫자를 문자로 바꿔주는 것
        사용법 : 2 -> b

        """
        re_com = re.compile(r"([0-9]+)")
        result_num = re_com.match(str(input_no))

        if result_num:
            base_number = int(input_no)
            result_01 = ''
            result = []
            while base_number > 0:
                div = base_number // 26
                mod = base_number % 26
                if mod == 0:
                    mod = 26
                    div = div - 1
                base_number = div
                result.append(mod)
            for one_data in result:
                result_01 = string.ascii_lowercase[one_data - 1] + result_01
            final_result = result_01
        else:
            final_result = input_no
        return final_result

    def change_number_value_to_string(self, sheet_name='', xyxy=''):
        """
        입력한 영역의 값들을 소문자로 바꾸는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, (int, float)):
                xy_value_l2d.append([x, y, x, y, "'" + str(one_value)])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def change_pxyxy_to_pxywh(self, input_pxywh=""):
        """
        2점의 픽셀좌표를 시작점의 픽셀을 기준으로 다음의 픽셀을 넓이와 높이(w, h)로 변경하는 것

        """
        px1, py1, pw, ph = input_pxywh
        return [px1, py1, px1 + pw, py1 + ph]

    def change_range_n_ylist_to_dic(self, sheet_name='', xyxy='', input_l1d=None):
        """
        가로열로 넣을수있도록 영역의 자료를
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        result_xy = {}
        result = {}

        for index, l1d in enumerate(l2d):
            temp = ""
            for sero in input_l1d:
                temp = temp + str(l1d[sero - 1]) + "_"  # 세로의 자료들을 _로 다 연결한다
                temp = temp[:-1]
                if not temp in result.keys():
                    result[temp] = [list(l1d)]
                    result_xy[temp] = [[x1 + index, y1, x1 + index, y2]]
                else:
                    result[temp].append([x1 + index, y1, x1 + index, y2])
        return [result, result_xy]

    def change_range_name_to_address(self, range_name):
        """
        입력값을로 들어오는 이름영역의 주소를 갖고오는 것
        단, 이름영역의 주소형태는 시트이름 또한 포함이 되어있어서, 시트이름과 주소의 2개로 결과값을 돌려준다
        """
        temp = self.get_address_for_range_name(range_name)
        xyxy = self.change_address_to_xyxy(temp[2])
        return xyxy

    def change_sheet_name(self, sheet_name1, sheet_name2):
        """
        시트이름 바꾸기
        """
        sheets_name = self.get_all_sheet_name()
        if not sheet_name2 in sheets_name:
            self.xlbook.Worksheets(sheet_name1).Name = sheet_name2

    def change_string_address_to_xyxy(self, xyxy=''):
        """
        입력된 주소값을 [x1, y1, x2, y2]의 형태로 만들어 주는 것이다
        """
        aaa = re.compile("[a-zA-Z]+|\\d+")
        address_list = aaa.findall(str(xyxy))
        temp = []
        result = []

        for one in address_list:
            temp.append(self.xyutil.check_one_address(one))

        if len(temp) == 1 and temp[0][1] == "string":  # "a"일때
            result = [0, temp[0][0], 0, temp[0][0]]
        elif len(temp) == 1 and temp[0][1] == "num":  # 1일때
            result = [temp[0][0], 0, temp[0][0], 0]
        elif len(temp) == 2 and temp[0][1] == temp[1][1] and temp[0][1] == "string":  # "a:b"일때
            result = [0, temp[0][0], 0, temp[1][0]]
        elif len(temp) == 2 and temp[0][1] == temp[1][1] and temp[0][1] == "num":  # "2:3"일때
            result = [temp[0][0], 0, temp[1][0], 0]
        elif len(temp) == 2 and temp[0][1] != temp[1][1] and temp[0][1] == "num":  # "2a"일때
            result = [temp[0][0], temp[1][0], temp[0][0], temp[1][0]]
        elif len(temp) == 2 and temp[0][1] != temp[1][1] and temp[0][1] == "string":  # "a2"일때
            result = [temp[1][0], temp[0][0], temp[1][0], temp[0][0]]
        elif len(temp) == 4 and temp[0][1] != temp[1][1] and temp[0][1] == "num":  # "a2b3"일때
            result = [temp[0][0], temp[1][0], temp[2][0], temp[3][0]]
        elif len(temp) == 4 and temp[0][1] != temp[1][1] and temp[0][1] == "string":  # "2a3c"일때
            result = [temp[1][0], temp[0][0], temp[3][0], temp[2][0]]
        return result

    def change_value_for_first_line_as_title_style(self, sheet_name='', xyxy=''):
        """
            영역을 주면, 제일 첫번째 라인의 값들을 적절한 형태로 제목으로 만들어 주는 것

                    Examples
            --------
            """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        all_data = []
        for y in range(xyxy[1], xyxy[3] + 1):
            xylist_data = []
            for x in range(xyxy[0], xyxy[2] + 1):
                # 병합이 있는 자료를 위해서 필요한 것이다
                aa = self.is_cell_in_merge(sheet_name, [x, y])
                if aa:
                    value = self.read_cell(sheet_name=sheet_name, xyxy=[aa[2][0], aa[2][1]])
                else:
                    value = self.read_cell(sheet_name=sheet_name, xyxy=[x, y])

                # 양쪽 공백을 없앤다
                value = str(value).strip()
                xylist_data.append(value)

            # 2줄 이상의 제목라인이 있을때, 위 아래의것을 합치기 위해서 필요
            final_title = ""
            for one in xylist_data:
                if one:
                    final_title = final_title + one + "_"
            # 아무런 제목도 없을경우는 가로의 숫자를 이용해서 만든 제목을 넣는다
            if final_title == "":
                final_title = "title_" + str(y) + "_"

            # 소문자로 만든다
            final_title = str(final_title[:-1]).lower()

            for bb in [[" ", "_"], ["&", ""], ["&", ""], ["(", ""], [")", ""], ["/", ""], ["-", ""], [".", ""],
                       ["%", ""]]:
                final_title = final_title.replace(bb[0], bb[1])

    def change_value_for_range_as_capital(self, sheet_name='', xyxy=''):
        """
        입력한 영역의 값들의 첫글자만 대문자로 바꾸는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value.capitalize()])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def change_value_for_range_as_lower(self, sheet_name='', xyxy=''):
        """
        입력한 영역의 값들을 소문자로 바꾸는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value.lower()])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def change_value_for_range_as_ltrim(self, sheet_name='', xyxy=''):
        """
        입력영역의 값들의 왼쪽에 있는 공백을 삭제하는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value.lstrip()])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def change_value_for_range_as_rtrim(self, sheet_name='', xyxy=''):
        """
        입력영역의 값들의 오른쪽에 있는 공백을 삭제하는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value.rstrip()])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def change_value_for_range_as_swapcase(self, sheet_name='', xyxy=''):
        """
        입력영역의 값들의 대소문자를 바꾸는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value.swapcase()])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def change_value_for_range_as_trim(self, sheet_name='', xyxy=''):
        """
        입력영역의 값들의 앞뒤 공백을 삭제하는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value.strip()])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def change_value_for_range_as_upper(self, sheet_name='', xyxy=''):
        """
        입력영역의 값들을 대문자로 바꾸는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value.upper()])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def change_value_for_range_by_xre(self, sheet_name, xyxy, iy, input_xre, input_value):
        """
        선택한 영역의 한줄을 기준으로, 각 셀의 값을 input_xre로 찾아서 찾은값을 변경하는 것
        정규표현식을 이용하여 바꾸는 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        for index, l1d in enumerate(l2d):
            try:
                aa = self.xyre.replace_with_xsql(input_xre, input_value, l1d[iy])
                if aa != l1d[index]:
                    sheet.Cells(x1 + index, y1 + iy).Value = aa
            except:
                pass

    def change_value_for_range_to_dic(self, xyxy=''):
        """
        영역의 자료를 사전 형식으로 변경을 하는 것인데, 맨앞의 자료를 key로 하고 그 나머지를
        사전의 value로 나타내서 만드는 것
        어떤 자료를 맨앞의 번호를 기준으로 불러오고 싶을때 사용하기 위한 것

        주소록의 각 자료를 찾는 방법으로, 고유한 이름을 기준으로 ID를 리스트로 저장하는 것이다
        제일앞의 것이 id이다
        """
        l2d = self.read_value_for_range("", xyxy)
        result = {}
        for l1d in l2d:
            for no in range(len(l1d), 0, -1):
                if l1d[no - 1]:
                    if l1d[no - 1] in result.keys():
                        result[l1d[no - 1]].append(l1d[0])
                    else:
                        result[l1d[no - 1]] = [l1d[0]]
                    break
        return result

    def change_value_for_range_to_json_file(self, sheet_name, xyxy, input_filename, is_title_tf=False):
        """
        엑셀자료를 json으로 만들기 (단, 엑셀자료의 첫줄은 제목이있어야한다)
        만약, 없는 option을 선택하면 1번부터 숫자로 만들어 진다
        이 제목이 key로 사용된다
        결과 : [json화일, 제목리스트]
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        title_n_l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        if is_title_tf:
            title_list = []
            for index, value in enumerate(title_n_l2d[0]):
                title_list.append(str(index + 1))
            data_l2d = title_n_l2d
        else:
            title_list = title_n_l2d[0]
            data_l2d = title_n_l2d[1:]

        json_code = self.xyutil.change_l2d_n_title_list_to_json_file(data_l2d, title_list)

        # 텍스트 파일로 저장
        if input_filename:
            with open(input_filename, "w", encoding="utf-8") as file:
                file.write(json_code)
        return [json_code, title_list, input_filename]

    def change_value_to_json_file(self, sheet_name, xyxy, input_filename, is_title_tf=False):
        """
        엑셀자료를 json으로 만들기 (단, 엑셀자료의 첫줄은 제목이있어야한다)
        만약, 없는 option을 선택하면 1번부터 숫자로 만들어 진다
        이 제목이 key로 사용된다
        결과 : [json화일, 제목리스트]

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        title_n_l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        if is_title_tf:
            title_list = []
            for index, value in enumerate(title_n_l2d[0]):
                title_list.append(str(index + 1))
            data_l2d = title_n_l2d
        else:
            title_list = title_n_l2d[0]
            data_l2d = title_n_l2d[1:]

        json_code = self.xyutil.change_l2d_n_title_list_to_json_file(data_l2d, title_list)

        # 텍스트 파일로 저장
        if input_filename:
            with open(input_filename, "w", encoding="utf-8") as file:
                file.write(json_code)
        return [json_code, title_list, input_filename]

    def change_xy_list_to_continious_range(self, cell_list):
        """
        1차원의 영역의 것을 연속된 자료로 바꾸는 것
        단, 가로와 세로를 다 할수가 없으니, 가로만 만드는 것이다

        """
        if not cell_list:
            return []

        sorted_cells = sorted(cell_list, key=lambda x: (x[1], x[0]))  # 정렬

        merged_ranges = []

        if not sorted_cells:
            return merged_ranges

        # 첫 번째 셀로 초기화
        start_x, start_y = sorted_cells[0]
        last_x, last_y = start_x, start_y

        for i in range(1, len(sorted_cells)):
            curr_x, curr_y = sorted_cells[i]

            # 세로 번호가 같고, 가로 번호가 바로 이전 셀과 연속(1 차이)되는 경우
            if curr_y == last_y and curr_x == last_x + 1:
                last_x = curr_x  # 끝 가로 번호 업데이트
            else:
                # 연속이 끊기면 지금까지의 범위를 저장
                merged_ranges.append([start_x, start_y, last_x, last_y])
                # 새로운 범위 시작
                start_x, start_y = curr_x, curr_y
                last_x, last_y = curr_x, curr_y

        # 마지막으로 진행 중이던 범위 추가
        merged_ranges.append([start_x, start_y, last_x, last_y])

        return merged_ranges

    def change_xy_n_value_to_continious_range(self, cell_data_list):
        """
         [가로번호, 세로번호, 셀값]의 자료가 입력이 되면, 연속된 형태로 [가로시작번호, 세로시작번호, 가로끝번호, 세로 끝번호, [[값1], [값2]...]]으로 만들어주는 함수
        """
        if not cell_data_list:
            return []

        sorted_cells = sorted(cell_data_list, key=lambda x: (x[1], x[0]))  # 정렬
        merged_ranges = []

        # 첫 번째 셀 데이터로 초기화
        start_x, start_y, first_val = sorted_cells[0]
        last_x = start_x
        current_values = [[first_val]]  # 값을 리스트 안의 리스트 형태로 보관

        for i in range(1, len(sorted_cells)):
            curr_x, curr_y, curr_val = sorted_cells[i]

            # 세로 번호가 같고, 가로 번호가 연속되는 경우
            if curr_y == start_y and curr_x == last_x + 1:
                last_x = curr_x
                current_values.append([curr_val])  # 연속된 값을 추가
            else:
                # 연속이 끊기면 지금까지의 결과 저장
                merged_ranges.append([start_x, start_y, last_x, start_y, current_values])

                # 새로운 범위 시작
                start_x, start_y = curr_x, curr_y
                last_x = curr_x
                current_values = [[curr_val]]

        # 마지막 그룹 추가
        merged_ranges.append([start_x, start_y, last_x, start_y, current_values])

        return merged_ranges

    def change_xy_to_a1(self, xy_list=""):
        """
        입력으로 들어온 주소인 xy의 형태([1,2])를 A1형식으로 바꾸는 것
        """
        x_char = self.change_num_to_char(xy_list[0])
        result = str(x_char[0]) + str(xy_list[1])
        return result

    def change_xyxy_to_4_edge_xy(self, xyxy=''):
        """

        """
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        result = [[x1, y1], [x1, y2], [x2, y2], [x2, y1]]
        return result

    def chart_fore_color(self, chart_obj, input_rgb):
        """
        차트의 forecolor를 설정하는 것
        """
        chart_obj.ChartArea.Format.Fill.ForeColor.RGB = input_rgb

    def chart_gridline(self, chart_obj):
        """
        차트의 그리드라인을 설정하는 것
        """
        chart_obj.Axes(2).MajorGridlines.Delete()
        chart_obj.Axes(2).MinorGridlines.Delete()

    def chart_legend(self, chart_obj, input_lrtb):
        """
        차트의 범례에대한 속성을 설정
        """
        lrtb_dic = {"left": 103, "right": 101, "top": 102, "bottom": 104}
        chart_obj.SetElement(lrtb_dic[input_lrtb])

    def chart_style(self, chart_obj, chart_style):
        """
        그래프의 형태를 정하는 것입니다
        """
        chart_style_vs_enum = {"line": 4, "pie": 5}
        checked_chart_no = chart_style_vs_enum[chart_style]
        chart_obj.ChartType = checked_chart_no
        return chart_obj

    def chart_x_scale(self, chart_obj, min_scale="", max_scale=""):
        """
        차트의 속성을 설정 : x_scale
        """
        temp = chart_obj.Axes(1)
        temp.MinimumScale = min_scale
        temp.MaximumScale = max_scale

    def chart_x_title(self, chart_obj, xtitle="", input_size=12, input_color="", is_bold_tf=True):
        """
        차트의 속성을 설정 : x_title
        """
        temp = chart_obj.Axes(1)  # 1 : xlCategory, 3 :xlSeriesAxis, 2 : xlValue, 1: primary, 2 : secondary
        temp.HasTitle = True
        temp.AxisTitle.Text = xtitle
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Bold = is_bold_tf
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Size = input_size

    def chart_y_scale(self, chart_obj, min_scale="", max_scale=""):
        """
        차트의 속성을 설정 : y_scale
        """
        temp = chart_obj.Axes(2)
        temp.MinimumScale = min_scale
        temp.MaximumScale = max_scale

    def chart_y_title(self, chart_obj, xtitle="제목1", size=20, input_color="red", is_bold_tf=True):
        """
        차트의 속성을 설정 : y_title
        """
        temp = chart_obj.Axes(2)  # 1: xlCategory, 3 :xlSeriesAxis, 2 : xlValue, 1: primary, 2 : secondary
        temp.HasTitle = True
        temp.AxisTitle.Text = xtitle
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Bold = is_bold_tf
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Size = size

    def check_common_sheet_name(self, sheet_name=''):
        """

        """
        if sheet_name == None: sheet_name = ''
        sheet = self.check_sheet_name(sheet_name)

    def check_excel_filename(self, input_filename):
        """
        입력으로 들어온 엑셀 화일이름을 적절하게 변경 시킨다
        """
        if "\\" in input_filename or "/" in input_filename:
            pass
        else:
            path = self.get_current_path()
            input_filename = path + "\\" + input_filename

        input_filename = self.xyutil.check_file_path(input_filename)

        if input_filename.endswith("xlsx") or input_filename.endswith("xls"):
            pass
        else:
            input_filename = input_filename + ".xlsx"

        return input_filename

    def check_excel_program(self):
        """
        워크북이 하나도 없는 빈 엑셀 program만 실행중일때 엑셀 프로그램을 종료시키기 위한것
        즉, 빈 엑셀을 종료하는 목적이다
        """

        for proc in psutil.process_iter():
            if "excel" in str(proc.name()).lower():
                print(f"PID: {proc.pid}, Name: {proc.name()}")
                proc.kill()  # 프로세스 종료

    def check_file_in_folder(self, input_folder, input_filename):
        """
        화일이 폴더안에 있는지를 확인하는 것
        """
        result = False
        filenames = self.xyutil.get_all_filename_in_folder(input_folder)
        if input_filename in filenames:
            result = True
        return result

    def check_file_path(self, input_filename):
        """
        경로를 /와 \으로 사용하는 경우가 있어서, 그걸 변경하는 것
        """
        changed_filename = str(input_filename).lower()
        changed_filename = changed_filename.replace("\\\\", "/")
        changed_filename = changed_filename.replace("\\", "/")
        return changed_filename

    def check_input_area(self, input_value):
        """
        입력으로 들어오는 대부분의 주소형태를 xyxy형태로 만들어주는 것입니다
        """
        if isinstance(input_value[0], list):
            input_value = input_value[0]

        if len(input_value) == 1:
            x1 = self.change_char_to_num(input_value[0])
            return [x1]
        elif len(input_value) == 2:
            x1 = self.change_char_to_num(input_value[0])
            y1 = self.change_char_to_num(input_value[1])
            return [x1, y1]
        elif len(input_value) == 4:
            x1 = self.change_char_to_num(input_value[0])
            y1 = self.change_char_to_num(input_value[1])
            x2 = self.change_char_to_num(input_value[2])
            y2 = self.change_char_to_num(input_value[3])
            return [x1, y1, x2, y2]

    def check_input_data(self, input_value, none_is_none=False):
        # 1. 가장 번번한 타입 먼지 체크 (순서 최적화)
        # 엑셀 데이터는 보통 str, int, float가 제일 많으므로 맨 위예 두는 것이 층습니다.
        if isinstance(input_value, (str, int, float, bool)):
            return input_value
        elif input_value is None:
            return None if none_is_none else ""
        elif isinstance(input_value, (tuple, list)):
            return [self.check_input_data(item, none_is_none) for item in input_value]
        elif isinstance(input_value, datetime.date):
            if isinstance(input_value, datetime.datetime):
                # 매번 datetime.time(0,0,0)을 생성하지 않고 미리 만트 상수와 비교
                if input_value.time() == datetime.time.min: # 글래스 변수나 모들 레빌 상수로 미리 정의 (0시 0분 0초)
                    return input_value.strftime("%Y-%m-%d")
                else:
                    return input_value.strftime("%Y-%m-%d %H:%M:%S")
            return input_value.strftime("%Y-%m-%d")
        else:
            return str(input_value)

    def check_l1d(self, input_list):
        """
        입력을 1차원 리스트로 표준화합니다.

        - 문자열 → [문자열]
        - [[값들]] → [값들]

        :return: 1차원 리스트

        result = excel.check_l1d("text")      # ["text"]
        result = excel.check_l1d([1, 2, 3])   # [1, 2, 3]
        result = excel.check_l1d([[1, 2]])    # [1, 2]
        """
        if isinstance(input_list, str):
            input_list = [input_list]
        elif isinstance(input_list[0], list):
            input_list = input_list[0]
        return input_list

    def check_line_style_as_dic(self, input_list):
        """
        영역의 선의 형태를 적용할때, 일반적인 단어를 사용해도, 알아서 코드에서 사용하는 기본 용어로 바꿔주는 코드이다
        입력으로 들어오는 값에서 셀의 선에대한 속성들을 확인하는 것이다
        보통 선을 나타내는 속성은 선의위치, 선의 굵기, 선의 색, 선의형태을 리스트형식으로
        순서없이 입력을 해도, 적당한 형태로 바꿔주는 것
        결과값은 리스트형식으로 나타내는 것이다
        결과값 : {"color": "bla", "thickness": "", "line_style": "", "area": "box"}의 형태의 사전 형식
        """

        result = {"color": "bla", "thickness": "", "line_style": "", "area": "box"}
        for one_value in input_list:
            if one_value in self.v_line_thickness_dic.keys():
                result["thickness"] = self.v_line_thickness_dic[one_value]
            elif one_value in self.v_line_style_dic.keys():
                result["style"] = self.v_line_style_dic[one_value]
            elif one_value in self.v_line_position.keys():
                result["area"] = self.v_line_position[one_value]
            elif self.xycolor.check_color_name(one_value):
                try:
                    result["color"] = self.xycolor.change_xcolor_to_rgb(one_value)
                except:
                    pass
        return result

    def check_numberformat(self, sheet_name='', xyxy=''):
        """
        셀의 여러 값들을 가지고 셀값의 형태를 분석하는 것이다
        단, 속도가 좀 느려진다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        result = []

        for x in range(x1, x2 + 1):
            temp = []
            for y in range(y1, y2 + 1):
                one_dic = {}
                one_cell = sheet.Cells(x, y)
                one_dic["y"] = x
                one_dic["x"] = y
                one_dic["value"] = one_cell.Value
                one_dic["value2"] = one_cell.Value2
                one_dic["text"] = one_cell.Text
                one_dic["formula"] = one_cell.Formula
                one_dic["formular1c1"] = one_cell.FormulaR1C1
                one_dic["numberformat"] = one_cell.NumberFormat
                one_dic["type"] = type(one_cell.Value)

                if type(one_cell.Value) is pywintypes.TimeType:
                    # pywintypes.datetime가 맞는지를 확인하는 코드이다
                    print('날짜에요!', one_cell.Value, str(type(one_cell.Value)))

                tem_1 = ""
                if (
                        "h" in one_cell.NumberFormat or "m" in one_cell.NumberFormat or "s" in one_cell.NumberFormat) and ":" in one_cell.NumberFormat:
                    tem_1 = "time"

                if "y" in one_cell.NumberFormat or "mmm" in one_cell.NumberFormat or "d" in one_cell.NumberFormat:
                    tem_1 = "date" + tem_1

                if isinstance(one_cell.Value, float) and one_cell.Value > 1 and tem_1 == "time":
                    tem_1 = "datetime"

                one_dic["style"] = tem_1
                temp.append(one_dic)
            result.append(temp)
        return result

    def check_one_data_for_range(self, input_data):
        """

        """
        if isinstance(input_data, list):
            dest = input_data[0]
        else:
            dest = input_data
        return dest

    def check_password_for_sheet(self, num_tf="yes", text_small_tf="yes", text_big_tf="yes", special_tf="no", len_num=10):
        """
        입력으로 들어온 시트의 암호를 찾아주는것

        """
        check_char = []
        if num_tf == "yes":
            check_char.extend(list(string.digits))
        if text_small_tf == "yes":
            check_char.extend(list(string.ascii_lowercase))
        if text_big_tf == "yes":
            check_char.extend(list(string.ascii_uppercase))
        if special_tf == "yes":
            for one in "!@#$%^*M-":
                check_char.extend(one)
        for no in range(1, len_num + 1):
            zz = itertools.combinations_with_replacement(check_char, no)
            for aa in zz:
                try:
                    pswd = "".join(aa)
                    self.sheet_lock("", pswd)
                    return
                except:
                    pass

    def check_same_data(self, input_list, check_line):
        """
        엑셀의 선택한 자료에서 여러줄을 기준으로 같은 자료만 갖고오기

        """
        input_list = self.check_input_data(input_list)
        result = []
        base_value = ""
        xy = self.get_address_for_activecell()
        for no in input_list:
            base_value = base_value + str(self.read_value_for_cell("", [xy[0], no]))

        # 혹시 1보다 작은 숫자가 나올 수있으므로, 최소시작점을 1로하기위해
        start_x = max(int(xy[0]) - check_line, 1)

        # 위로10개 아래로 10개의 자료를 확인한다
        for no in range(start_x, start_x + 20):
            one_value = ""
            for one in input_list:
                one_value = one_value + str(self.read_value_for_cell("", [no, one]))
            if base_value == one_value:
                # 보통 50개이상의 줄을 사용하지 않으므로 50개를 갖고온다
                temp = self.read_value_for_range("", [no, 1, no, 50])
                result.append(temp[0])
        return result

    def check_same_line_for_two_xyxy2_new_sheet(self, sheet_name, xyxy1, xyxy2):
        """
        2개 영역에서 같은것을 찾아서 3가지로 나누어서 새로운 시트에 쓰는것

        - 1번 : 서로 같은것
        - 2번 : 앞의 자료중 다른 것
        - 2번 : 뒤의 자료중 다른 것
        영역을 나타내는 xyxy1또는 xyxy2 변수의 기본값을 ""일때는 현재 선택된 영역을 뜻하는 것입니다
        """
        sheet = self.check_sheet_name("")
        data1 = self.read_value_for_range(sheet_name, xyxy1)
        data2 = self.read_value_for_range(sheet_name, xyxy2)

        data1_found = []
        data1_not_found = []
        data2_not_found = []

        for one in data2:
            if not one in data1:
                data2_not_found.append(one)

        for one in data1:
            if one in data2:
                data1_found.append(one)
            else:
                data1_not_found.append(one)

        self.new_sheet()
        sheet.Cells(1, 1).Value = "2 영역중 같은것"
        self.write_l2d_from_cell("", [2, 1], data1_found)

        line2_start = len(data1_found) + 5
        sheet.Cells(line2_start - 1, 1).Value = "비교자료중 못찾은 것 (앞의 자료)"
        self.write_l2d_from_cell("", [line2_start, 1], data1_not_found)

        line3_start = line2_start + len(data1_not_found) + 5

        sheet.Cells(line3_start - 1, 1).Value = "결과가 중요한 것중 못찾은 것 (뒷 자료)"
        self.write_l2d_from_cell("", [line3_start, 1], data2_not_found)

    def check_sheet_n_xyxy(self, sheet_name='', xyxy=''):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy)
        rng = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2))
        return [sheet, [x1, y1, x2, y2], rng]

    def check_sheet_name(self, sheet_name=''):
        """
        시트이름으로 객체를 만들어서 돌려주는 것이다

        이름이 없으면 현재 활성화된 시트를 객체로 만들어 사용한다
        숫자가 들어오면, 번호숫자로 생각해서 앞에서 n번째의 시트이름을 갖고과서 시트객체를 돌려준다
        #1 : 현재 워크북의 순번에 따른 시트객체를 갖고온다
        """

        if sheet_name is None or sheet_name == "":  # None이거나 빈 문자열("")이이 바로 리턴 (가장 빠름)
            return self.xlbook.ActiveSheet
        elif isinstance(sheet_name, str):  # 문자열 처리
            if sheet_name.lower() in ("activesheet", "active_sheet"):
                return self.xlbookActiveSheet
            return self.xlbook.Worksheets(sheet_name)
        elif isinstance(sheet_name, int):  # 숫자 처리 (엑셀 인덱스)
            return self.xlbook.Worksheets(sheet_name)
        elif not isinstance(sheet_name, str):  # 객제일때
            return sheet_name
        else:  # 그외 (기존 로직 유지)
            return self.xlbookActiveSheet

    def check_start_n_end_address(self, xyxy):
        """

        """
        if isinstance(xyxy, list):
            if len(xyxy) == 1:
                start = xyxy[0]
                end = xyxy[0]
            else:
                start = xyxy[0]
                end = xyxy[1]
        else:
            start = xyxy
            end = xyxy
        return [start, end]

    def check_start_n_end_address_for_range(self, xyxy):
        """

        """
        if isinstance(xyxy, list):
            if len(xyxy) == 1:
                start = xyxy[0]
                end = xyxy[0]
            else:
                start = xyxy[0]
                end = xyxy[1]
        else:
            start = xyxy
            end = xyxy
        return [start, end]

    def check_title_value(self, input_value):
        """
        화일의 제목으로 사용이 불가능한것을 제거한다
        """
        for temp_01 in [[" ", "_"], ["(", "_"], [")", "_"], ["/", "_per_"], ["%", ""], ["'", ""], ['"', ""], ["$", ""],
                        ["__", "_"], ["__", "_"]]:
            input_value = input_value.replace(temp_01[0], temp_01[1])
        if input_value[-1] == "_":
            input_value = input_value[:-2]
        return input_value

    def check_xx_address(self, xyxy=''):
        """
        입력 주소중 xx가 맞는 형식인지를 확인하는것
        :return: [2, 2]의 형태로 만들어 주는것
        """
        if isinstance(xyxy, str):
            xyxy = self.change_string_address_to_xyxy(xyxy)

        if isinstance(xyxy, list):
            if len(xyxy) == 1:
                result = [xyxy[0], xyxy[0]]
            elif len(xyxy) == 2:
                result = xyxy
            elif len(xyxy) == 4:
                result = [xyxy[0], xyxy[2]]
        else:
            x = self.change_char_to_num(xyxy)
            result = [x, x]
        return result

    def check_xy_address(self, xy=''):
        """
        x나 y의 하나를 확인할때 입력을 잘못하는 경우를 방지하기위해 사용
        """
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xy)
        return [x1, y1]

    def check_y_address(self, input_value):
        """
        결과 = "b"의 형태로 만들어 주는것
        """
        result = self.check_yy_address(input_value)[0]
        return result

    def check_yy_address(self, input_value):
        """
        결과 = ["b", "b"]의 형태로 만들어 주는것

        :return: ["b", "b"]의 형태로 만들어 주는것
        """

        if input_value == "" or input_value == None:
            temp = self.get_address_for_selection()
            result = [temp[1], temp[3]]
        elif isinstance(input_value, str) or isinstance(input_value, int):
            temp = self.change_num_to_char(input_value)
            result = [temp, temp]
        elif isinstance(input_value, list):
            if len(input_value) == 2:
                result = input_value  # 이부분이 change_address_to_xyxy와 틀린것이다
            elif len(input_value) == 4:
                temp = input_value
                result = [temp[1], temp[3]]
        else:
            temp = self.get_address_for_selection()
            result = [temp[1], temp[3]]

        new_y1 = self.change_num_to_char(result[0])
        new_y2 = self.change_num_to_char(result[1])

        return [new_y1, new_y2]

    def close(self):
        """
        열려진 엑셀 화일을 닫는것

        """
        self.xlbook.Close(SaveChanges=0)
        del self.xlapp

    def close_for_workbook(self, work_book_obj):
        """
        열려진 엑셀 화일을 닫는것
        여러개가 있다면 활성화된 화일을 닫는다
        """
        work_book_obj.Close(SaveChanges=0)

    def concate_xline(self, input_list_2d, xy):
        """
        선택한 영역의 세로 자료들을 다 더해서 제일위의 셀에 다시 넣는것
        """
        x_len = len(input_list_2d)
        y_len = len(input_list_2d[0])
        for y in range(y_len):
            temp = ""
            for x in range(x_len):
                self.write_value_in_cell("", [x + xy[0], y + xy[1]], "")
                if input_list_2d[x][y]:
                    temp = temp + " " + input_list_2d[x][y]
            self.write_value_in_cell("", [xy[0], y + xy[1]], str(temp).strip())

    def conditional_format_by_cell_value(self, sheet_name, xyxy, input_color, start_xy, input_value, cf_no):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        char_y = self.change_num_to_char(start_xy[1])

        if cf_no == None:
            cf_no = self.xlapp.Selection.FormatConditions.Count + 1

        rng.FormatConditions.Add(2, None, f'''=${char_y + str(start_xy[0])}={input_value}''', cf_no)
        rng.FormatConditions(cf_no).Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def conditional_format_by_empty_value(self, sheet_name, xyxy, input_value, input_color, start_xy, cf_no):
        """
        조건부서식의 적용기준 : 기준셀의 값이 비어있을때 적용
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        char_y = self.change_num_to_char(start_xy[1])
        if cf_no == None:
            cf_no = self.xlapp.Selection.FormatConditions.Count + 1

        rng.FormatConditions.Add(2, None, f'''=${char_y + str(start_xy[0])}={input_value}''', cf_no)
        rng.FormatConditions(cf_no).Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def conditional_format_by_function(self, sheet_name, xyxy, input_formula, input_color, cf_no):
        """
        조건부서식의 적용기준 : 기준셀에 함수를 넣어서, 그함수에 맞을때 적용됨

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.select()

        if cf_no == None:
            cf_no = self.xlapp.Selection.FormatConditions.Count + 1
        rng.FormatConditions.Add(2, None, input_formula, cf_no)
        rng.FormatConditions(cf_no).Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def conditional_format_by_multi_operator(self, sheet_name='', xyxy='', input_l2d=None):
        """
        조건부서식의 적용기준 : 몇가지 서식이 사용가능하도록 만든것
        다중 조건부서식

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for index, [operator, range_format] in enumerate(input_l2d):
            operator = str(operator).strip().upper()
            aaa = self.xyutil.split_operator(operator)
            if operator.startswith("AND") or operator.startswith("OR"):
                # "and(100<=$A1, $A1<200)"     "or(100<=$A1, $A1<200)" 등을 사용할때
                rng.FormatConditions.Add(2, None, "=" + operator)
            elif operator.startswith("="):
                # 보통 수식을 사용할때 적용되는 것
                rng.FormatConditions.Add(2, None, operator)
            elif not "," in operator and len(aaa) == 5:
                # "100<=$A31<200", between은 and 2개로 표현이 가능하다
                rng.FormatConditions.Add(2, None,
                                               "=AND(" + aaa[0] + aaa[1] + aaa[2] + "," + aaa[2] + aaa[3] + aaa[
                                                   4] + ")")
            elif not "," in operator and len(aaa) == 3:
                # "100>$A10"
                rng.FormatConditions.Add(2, None, "=" + operator)

            if "color" in range_format.keys():
                rng.FormatConditions(index + 1).Interior.Color = self.xycolor.change_xcolor_to_rgbint(
                    range_format["color"])
            if "font_bold" in range_format.keys():
                rng.FormatConditions(index + 1).Font.Bold = True
            if "font_color" in range_format.keys():
                rng.FormatConditions(index + 1).Font.Color = self.xycolor.change_xcolor_to_rgbint(
                    range_format["font_color"])

    def conditional_format_by_not_none_value(self, sheet_name, xyxy, input_color, start_xy, cf_no):
        self.conditional_format_for_range_by_not_none_value(sheet_name, xyxy, input_color, start_xy, cf_no)

    def conditional_format_by_operator(self, sheet_name, xyxy, operator, range_format, type):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        type_dic = {"AboveAverageCondition": 12, "BlanksCondition": 10,
                    "value": 1, "CellValue": 1, "ColorScale": 3, "DataBar": 4, "ErrorsCondition": 16,
                    "Expression": 2, "IconSet": 6, "NoBlanksCondition": 13, "NoErrorsCondition": 17,
                    "TextString": 9, "TimePeriod": 11, "Top10": 5, "Uniquevalues": 8, }
        oper_dic1 = {"between": 1, "equal": 3, "greater": 5, "greaterequal": 7, "less": 6, "Lessequal": 8,
                     "notbetween": 2, "notequal": 4,
                     "-": 3, ">": "<", ">=": "<=", "<": ">", "<=": ">=", "|-": 4}

        oper_dic2 = {"between": 1, "equal": 3, "greater": 5, "greaterequal": 7, "less": 6, "Lessequal": 8,
                     "notbetween": 2, "notequal": 4,
                     "-": 3, ">": 5, ">=": 7, "<": 6, "<=": 8, "|-": 4}

        r1c1 = self.change_address_to_r1c1('')
        cf_count = self.xlapp.Selection.FormatConditions.Count
        type_value = type_dic[type]

        if type_value == 1:  # 셀값을 기준으로 판단
            aaa = self.xyutil.split_operator(operator)
            if len(aaa) == 5:
                rng.FormatConditions.Add(
                    Type=2,
                    Formula1=f'=AND({r1c1}{oper_dic1[aaa[1]]}{aaa[0]},{r1c1}{aaa[3]}{aaa[-1]})'
                )
                rng.FormatConditions(cf_count + 1).SetFirstPriority()
                rng.FormatConditions(cf_count + 1).Interior.Color = self.xycolor.change_xcolor_to_rgbint(
                    range_format)

            elif len(aaa) == 3:
                rng.FormatConditions.Add(
                    Type=2,
                    Formula1=f'=({r1c1}{oper_dic1[aaa[1]]}{aaa[0]})'
                )
                rng.FormatConditions(cf_count + 1).SetFirstPriority()
                rng.FormatConditions(cf_count + 1).Interior.Color = self.xycolor.change_xcolor_to_rgbint(
                    range_format)

    def conditional_format_for_3_colored_gradation_style(self, sheet_name='', xyxy='', input_color_top="yel70", input_color_middle="yel70", input_color_bottom=" red45"):
        """
        그라데이션으로 색을 칠하는 것
        최고값의색, 중간값의 색, 최저값의 색을 정하면, 그 중간은 각각의 색들의 그라데이션으로 나타나는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        # rng.FormatConditions.Delete()
        rng.FormatConditions.AddColorScale(ColorScaleType=3)
        [csc1, csc2, csc3] = [rng.FormatConditions(1).ColorScaleCriteria(n) for n in range(1, 4)]

        csc1.Type = 1
        csc1.FormatColor.Color = self.xycolor.change_xcolor_to_rgbint(input_color_bottom)
        csc1.FormatColor.TintAndShade = 0

        csc2.Type = 5
        csc2.FormatColor.Color = self.xycolor.change_xcolor_to_rgbint(input_color_middle)
        csc2.FormatColor.TintAndShade = 0

        csc3.Type = 2
        csc3.FormatColor.Color = self.xycolor.change_xcolor_to_rgbint(input_color_top)
        csc3.FormatColor.TintAndShade = 0

    def conditional_format_for_data_bar_style(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        조건부서식 : 바타입
        만약 형태를 바꾸고 싶으면 setup을 먼저 이용해서 형태를 설정합니다
        """

        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        ad = rng.FormatConditions.AddDatabar()
        ad.BarColor.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def conditional_format_for_range_by_cell_value(self, sheet_name, xyxy, input_color="yel70", start_xy=[3, 5], input_value="입력값12", cf_no=None):
        """
        선택한 영역의 n 번째 값이 입력값과 같으면, 전체 가로줄에 색칠하기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        char_y = self.change_num_to_char(start_xy[1])

        if cf_no == None:
            cf_no = self.xlapp.Selection.FormatConditions.Count + 1

        rng.FormatConditions.Add(2, None, f'''=${char_y + str(start_xy[0])}={input_value}''', cf_no)
        rng.FormatConditions(cf_no).Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def conditional_format_for_range_by_empty_value(self, sheet_name, xyxy, input_color="yel70", start_xy=[3, 5], cf_no=None):
        """
        선택한 영역의 n 번째 값이 비어있지 않으면, 전체 가로줄에 색칠하기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        char_y = self.change_num_to_char(start_xy[1])
        if cf_no == None:
            cf_no = self.xlapp.Selection.FormatConditions.Count + 1

        rng.FormatConditions.Add(2, None, f'''=${char_y + str(start_xy[0])}=""''', cf_no)
        rng.FormatConditions(cf_no).Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def conditional_format_for_range_by_function(self, sheet_name, xyxy, input_formula="=LEN(TRIM($A1))=0", input_color="red50", cf_no=None):
        """
        조건부서식 : 함수사용

        conditional_format_with_function("", [1, 1, 7, 7], "=LEN(TRIM($A1))=0")
        만약 형태를 바꾸고 싶으면 setup을 먼저 이용해서 형태를 설정합니다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.select_for_range(sheet_name, xyxy)

        if cf_no == None:
            cf_no = self.xlapp.Selection.FormatConditions.Count + 1
        rng.FormatConditions.Add(2, None, input_formula, cf_no)
        rng.FormatConditions(cf_no).Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def conditional_format_for_range_by_multi_operator(self, sheet_name='', xyxy='', input_l2d=None):
        """
        다중 조건부서식

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for index, [operator, range_format] in enumerate(input_l2d):
            operator = str(operator).strip().upper()
            aaa = self.xyutil.split_operator(operator)
            if operator.startswith("AND") or operator.startswith("OR"):
                # "and(100<=$A1, $A1<200)"     "or(100<=$A1, $A1<200)" 등을 사용할때
                rng.FormatConditions.Add(2, None, "=" + operator)
            elif operator.startswith("="):
                # 보통 수식을 사용할때 적용되는 것
                rng.FormatConditions.Add(2, None, operator)
            elif not "," in operator and len(aaa) == 5:
                # "100<=$A31<200", between은 and 2개로 표현이 가능하다
                rng.FormatConditions.Add(2, None, "=AND(" + aaa[0] + aaa[1] + aaa[2] + "," + aaa[2] + aaa[3] + aaa[4] + ")")
            elif not "," in operator and len(aaa) == 3:
                # "100>$A10"
                rng.FormatConditions.Add(2, None, "=" + operator)

            if "color" in range_format.keys():
                rng.FormatConditions(index + 1).Interior.Color = self.xycolor.change_xcolor_to_rgbint(range_format["color"])
            if "font_bold" in range_format.keys():
                rng.FormatConditions(index + 1).Font.Bold = True
            if "font_color" in range_format.keys():
                rng.FormatConditions(index + 1).Font.Color = self.xycolor.change_xcolor_to_rgbint(range_format["font_color"])

    def conditional_format_for_range_by_not_none_value(self, sheet_name='', xyxy='', input_color="yel70", start_xy=[3, 5], cf_no=None):
        """
        선택한 영역의 n 번째 값이 입력값과 같으면, 전체 가로줄에 색칠하기

        cf_no : 여러개의 conditional format을 사용할때 이용하기위하여, 번호를 넣는 것, cf를 몇번째 일지를 선택하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        x11, y11, x22, y22 = self.change_address_to_xyxy(start_xy)
        char_y = self.change_num_to_char(y11)
        if cf_no == None:
            cf_no = self.xlapp.Selection.FormatConditions.Count + 1

        # rng.FormatConditions.Delete() # 영역에 포함된 조건부 서식을 지우는 것
        rng.FormatConditions.Add(2, None, f'''=${char_y + str(start_xy[0])}<>""''', cf_no)
        rng.FormatConditions(cf_no).Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def conditional_format_for_range_by_operator(self, sheet_name='', xyxy='', operator="100<=value<200", range_format="red50", type="value"):
        """
        조건부서식 사용하기

        conditional_format_with_operator("", [1, 1, 7, 7], "100<=value <200")

        만약 형태를 바꾸고 싶으면 setup을 먼저 이용해서 형태를 설정합니다

        """
        type_dic = {"AboveAverageCondition": 12, "BlanksCondition": 10,
                    "value": 1, "CellValue": 1, "ColorScale": 3, "DataBar": 4, "ErrorsCondition": 16,
                    "Expression": 2, "IconSet": 6, "NoBlanksCondition": 13, "NoErrorsCondition": 17,
                    "TextString": 9, "TimePeriod": 11, "Top10": 5, "Uniquevalues": 8, }
        oper_dic1 = {"between": 1, "equal": 3, "greater": 5, "greaterequal": 7, "less": 6, "Lessequal": 8,
                     "notbetween": 2, "notequal": 4,
                     "-": 3, ">": "<", ">=": "<=", "<": ">", "<=": ">=", "|-": 4}

        oper_dic2 = {"between": 1, "equal": 3, "greater": 5, "greaterequal": 7, "less": 6, "Lessequal": 8,
                     "notbetween": 2, "notequal": 4,
                     "-": 3, ">": 5, ">=": 7, "<": 6, "<=": 8, "|-": 4}

        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        r1c1 = self.change_address_to_r1c1(xyxy)
        cf_count = self.xlapp.Selection.FormatConditions.Count
        type_value = type_dic[type]

        if type_value == 1:  # 셀값을 기준으로 판단
            aaa = self.xyutil.split_operator(operator)
            if len(aaa) == 5:
                rng.FormatConditions.Add(
                    Type=2,
                    Formula1=f'=AND({r1c1}{oper_dic1[aaa[1]]}{aaa[0]},{r1c1}{aaa[3]}{aaa[-1]})'
                )
                rng.FormatConditions(cf_count + 1).SetFirstPriority()
                rng.FormatConditions(cf_count + 1).Interior.Color = self.xycolor.change_xcolor_to_rgbint(range_format)

            elif len(aaa) == 3:
                rng.FormatConditions.Add(
                    Type=2,
                    Formula1=f'=({r1c1}{oper_dic1[aaa[1]]}{aaa[0]})'
                )
                rng.FormatConditions(cf_count + 1).SetFirstPriority()
                rng.FormatConditions(cf_count + 1).Interior.Color = self.xycolor.change_xcolor_to_rgbint(range_format)

    def conditional_format_for_set_format(self, input_rng, input_dic):
        """
        조건부서식에서 셀의 셀서식을 정의하기위한 설정
        ""나 "basic"으로 입력이 되어있으면 기본설정값으로 적용이 되는 것입니다
        사용법 : {"line_style":1, "line_color":"red", "line_color":"red", "font_bold":1, "line_color":"red", }
        """
        if input_dic == "" or input_dic == "basic":
            input_rng.Borders.LineStyle = 1
            input_rng.Borders.ColorIndex = 1
            input_rng.Interior.Color = 5296274
            input_rng.Font.Bold = 1
            input_rng.Font.ColorIndex = 1
        else:
            if "line_style" in input_dic.keys():
                input_rng.Borders.LineStyle = input_dic["line_style"]
            if "line_color" in input_dic.keys():
                rgbint = self.xycolor.change_xcolor_to_rgbint(input_dic["line_color"])
                input_rng.Borders.Color = rgbint
            if "color" in input_dic.keys():
                rgbint = self.xycolor.change_xcolor_to_rgbint(input_dic["color"])
                input_rng.Interior.Color = rgbint
            if "font_bold" in input_dic.keys():
                input_rng.Font.Bold = input_dic["font_bold"]
            if "font_color" in input_dic.keys():
                rgbint = self.xycolor.change_xcolor_to_rgbint(input_dic["font_color"])
                input_rng.Font.Color = rgbint

    def copy(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역을 클립보드에 복사합니다.


            excel.select_range("", "A1:B10")
            excel.copy()
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Copy()

    def copy_and_paste(self, sheet1, sheet2, xyxy1, xyxy2):
        """
        복사한후 붙여넣기

        """
        sheet = self.check_sheet_name(sheet1)
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy1)
        rng = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2))
        rng.Copy()

        x21, y21, x22, y22 = self.change_address_to_xyxy(xyxy2)
        self.select_sheet(sheet2)
        self.xlapp.ActiveSheet.Cells(x21, y22).Select()
        self.xlapp.ActiveSheet.Paste()

    def copy_cell(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역을 클립보드에 복사합니다.
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.Cells(x1, y1).Copy()

    def copy_function_from_range1_to_range2(self, xyxy1, xyxy2, sheet_name=''):
        """
        xlSheet_to_final.Range("A53:A54").AutoFill(xlSheet_to_final.Range("A53:A61"),xlFillDefault)

        """
        sheet = self.check_sheet_name(sheet_name)
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy1)
        rng_1 = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2))

        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy2)
        rng_2 = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2))

        rng_1.AutoFill(rng_2)

    def copy_function_from_xyxy1_to_xyxy2(self, sheet_name, xyxy1, xyxy2):
        """
        xlSheet_to_final.Range("A53:A54").AutoFill(xlSheet_to_final.Range("A53:A61"),xlFillDefault)

        """
        sheet = self.check_sheet_name(sheet_name)
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy1)
        rng_1 = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2))

        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy2)
        rng_2 = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2))

        rng_1.AutoFill(rng_2)

    def copy_n_paste_formular_only(self, copy_sheet, copy_xyxy, paste_sheet, paste_xyxy):
        sheet1, [x11, y11, x12, y12], rng1 = self.check_sheet_n_xyxy(copy_sheet, copy_xyxy)
        sheet2, [x21, y21, x22, y22], rng2 = self.check_sheet_n_xyxy(paste_sheet, paste_xyxy)
        rng1.Copy()
        rng2.PasteSpecial(Paste=-4122)
        for ix in range(x21 - x11 + 1):
            for iy in range(y21 - y11 + 1):
                if sheet1.Cells(ix + x11, iy + y11).HasFormula:
                    sheet1.Cells(ix + x11, iy + y11).Copy()
                    rng2.Cells(ix + x12, iy + y12).PasteSpecial(Paste=-4122)

    def copy_range(self, sheet_name='', xyxy=''):
        """
        영역의 복사까지만 하는 기능이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Copy()

    def copy_sheet_at_same_workbook(self, sheet_name1, sheet_name2):
        """
        같은 엑셀화일안에 있는 시트를 복사해서 하나더 만드는 것
        """
        sheets_name = self.get_all_sheet_name()
        if sheet_name1 in sheets_name:
            sheet = self.check_sheet_name(sheet_name1)

            sheet.Copy(Before=sheet)
            if not sheet_name2 == "":
                old_name = self.get_activesheet_name()
                self.change_sheet_name(old_name, sheet_name2)
        else:
            print("Can not found sheet name")

    def copy_sheet_to_another_workbook(self, source_wb, source_sheet_name_l1d, target_position=1):
        """
        어떤 엑셀화일안의 시트를 다른 엑셀화일에 복사하는 것

        """
        if not isinstance(source_sheet_name_l1d, list):
            source_sheet_name_l1d = [source_sheet_name_l1d]
        for one_sheet_name in source_sheet_name_l1d:
            sheet = self.check_sheet_name(one_sheet_name)
            sheet.Copy(Before=source_wb.xlbook.Sheets(target_position))

    def copy_value_for_range_to_another_sheet(self, sheet_name1, xyxy1, sheet_name2, xyxy2):
        """
        특정 영역을 복사해서 다른시트의 영역에 붙여 넣기

        """

        sheet1 = self.check_sheet_name(sheet_name1)
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy1)
        rng1 = sheet1.Range(sheet1.Cells(x1, y1), sheet1.Cells(x2, y2))
        rng1.Select()

        sheet2 = self.check_sheet_name(sheet_name2)
        x11, y11, x21, y21 = self.change_address_to_xyxy(xyxy2)
        rng2 = sheet2.Range(sheet2.Cells(x11, y11), sheet2.Cells(x21, y21))
        rng2.Paste()

        self.xlapp.CutCopyMode = 0

    def copy_value_to_another_sheet(self, sheet_name1, xyxy1, sheet_name2, xyxy2):
        """
        특정 영역을 복사해서 다른시트의 영역에 붙여 넣기

        """

        sheet1 = self.check_sheet_name(sheet_name1)
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy1)
        rng1 = sheet1.Range(sheet1.Cells(x1, y1), sheet1.Cells(x2, y2))
        rng1.Select()

        sheet2 = self.check_sheet_name(sheet_name2)
        x11, y11, x21, y21 = self.change_address_to_xyxy(xyxy2)
        rng2 = sheet2.Range(sheet2.Cells(x11, y11), sheet2.Cells(x21, y21))
        rng2.Paste()

        self.xlapp.CutCopyMode = 0

    def copy_xline(self, sheet_name, input_no=''):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        x1, x2 = self.check_xx_address(input_no)
        sheet.Rows(str(x1) + ":" + str(x2)).Copy()

    def copy_xxline(self, sheet_name='', xx_list=''):
        """
        가로영역을 복사
        """
        sheet = self.check_sheet_name(sheet_name)
        x1, x2 = self.check_xx_address(xx_list)
        sheet.Rows(str(x1) + ":" + str(x2)).Copy()

    def copy_yline(self, sheet_name, yy_list):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        y1, y2 = self.check_yy_address(yy_list)
        sheet.Columns(str(y1) + ":" + str(y2)).Copy()

    def copy_yyline(self, sheet_name='', yy_list=''):
        """
        세로영역을 복사
        """
        sheet = self.check_sheet_name(sheet_name)
        y1, y2 = self.check_yy_address(yy_list)
        sheet.Columns(str(y1) + ":" + str(y2)).Copy()

    def count_continious_same_value_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 영역중 세로로 연속된 같은자료만 개수세기
        밑에서부터 올라가면서 찾는다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        total = 0
        for y, x in itertools.product(range(y2, y1, -1), range(x1, x2 + 1)):
            base_value = self.read_value_for_cell(sheet_name, [x, y])
            up_value = self.read_value_for_cell(sheet_name, [y - 1, x])
            if base_value == up_value:
                total = total + 1
        return total

    def count_empty_cell_for_range(self, sheet_name='', xyxy=''):
        """
        영역안의 빈셀의 갯수를 계산
        빈셀의 의미 : None인것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(16)
        temp_result = 0
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = self.read_value_for_cell(sheet_name, [x, y])
            if one_value == None:
                sheet.Cells(x, y).Interior.Color = rgbint
                temp_result = temp_result + 1
        return temp_result

    def count_empty_xline_for_range(self, sheet_name='', xyxy=''):
        """
        count_emptycols(sheet_name="", xyxy)
        선택한영역에서 x줄의 값이 없으면 y줄을 삭제한다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        total = 0
        for x in range(x2, x1 - 1, -1):
            x_new = self.change_num_to_char(x)
            changed_address = str(x_new) + ":" + str(x_new)
            num = self.xlapp.WorksheetFunction.CountA(sheet.Range(changed_address))
            if num == 0:
                total = total + 1
        return total

    def count_empty_yline_for_range(self, sheet_name='', xyxy=''):
        """
        count_emptyrows(sheet_name="", xyxy)
        선택한영역에서 x줄의 값이 없으면 x줄을 삭제한다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        total = 0
        for y in range(y2, y1 - 1, -1):
            changed_address = str(y) + ":" + str(y)
            num = self.xlapp.WorksheetFunction.CountA(sheet.Range(changed_address))
            if num == 0:
                total = total + 1
            return total

    def count_max_len_for_l2d(self, input_l2d):
        """

        """
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        return max(len(row) for row in input_l2d)

    def count_same_value_for_range(self, sheet_name='', xyxy=''):
        """
         입력값 - 입력값없이 사용가능
         선택한 영역의 반복되는 갯수를 구한다
         - 선택한 영역에서 값을 읽어온다
         - 사전으로 읽어온 값을 넣는다
         - 열을 2개를 추가해서 하나는 값을 다른하나는 반복된 숫자를 넣는다

        """
        self.count_same_value(sheet_name, xyxy)

    def count_shape_in_sheet(self, sheet_name=""):
        """
        선택한 시트안의 도형의 갯수를 갖고온다
        """
        sheet = self.check_sheet_name(sheet_name)
        result = sheet.Shapes.Count
        return result

    def count_sheet(self):
        """
        현재 화성화된 엑셀 화일의 시트의 갯수
        """
        return self.xlbook.Worksheets.Count

    def count_workbook(self):
        """
        열려있는 워크북의 갯수
        """
        result = self.xlapp.Workbooks.Count
        return result

    def cut(self, sheet_name='', xyxy=''):
        """
        영역을 잘라내기 하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Cut()

    def cut_float_by_no_of_under_point(self, sheet_name='', xyxy='', no_of_under_point=3):
        """
        선택영역안의 모든 숫자중에서, 입력받은 소숫점아래 몇번째부터, 값을 아예 삭제하는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        times = 10 ** no_of_under_point

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = sheet.Cells(x, y).Value
            try:
                sheet.Cells(x, y).Value = math.floor(float(one_value) * times) / times
            except:
                pass

    def cut_for_range(self, sheet_name='', xyxy=''):
        """
        영역을 잘라내기 하는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Cut()

    def delete(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역의 모든 내용과 서식을 삭제합니다.
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Clear()

    def delete_all_empty_sheet(self):
        """
        워크북에서 빈 시트를 전부 삭제하는 것
        """
        sheets_name = self.all_sheet_name()
        for one_sheet_name in sheets_name:
            check_sheet = self.is_empty_sheet(one_sheet_name)
            if check_sheet:
                self.delete_sheet_by_name(one_sheet_name)

    def delete_all_for_sheet(self, sheet_name=''):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Cells.Clear()

    def delete_all_line_for_sheet(self, sheet_name=''):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Cells.Borders.LineStyle = -4142

    def delete_all_range_name(self):
        """
        모든 range_name을 삭제하는 것
        """
        for one_rng_name in self.xlapp.Names:
            ddd = str(one_rng_name.Name)
            if ddd.find("!") < 0:
                self.xlbook.Names(ddd).Delete()

    def delete_all_shape_in_sheet(self, sheet_name=''):
        """
        시트안의 모든 객체를 삭제하는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        drawings_nos = sheet.Shapes.Count

        if drawings_nos > 0:
            for num in range(drawings_nos, 0, -1):
                # Range를 앞에서부터하니 삭제하자마자 번호가 다시 매겨져서, 뒤에서부터 삭제하니 잘된다
                sheet.Shapes(num).Delete()
        return drawings_nos

    def delete_all_space_for_range(self, sheet_name='', xyxy=''):
        """
        입력영역안의 모든 공백을 삭제하는 것
        양쪽끝의 공백만이 아닌 문자사이의 공백도 없애는 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            value = sheet.Cells(x, y).Value
            if isinstance(value, str):
                value = value.replace("", "")
                sheet.Cells(x, y).Value = value

    def delete_all_textbox_for_sheet(self, sheet_name=''):
        """
        모든 텍스트박스 지우기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, '')
        for shape in sheet.Shapes:
            if shape.Tyde == 17:
                shape.Delete()

    def delete_all_value_for_sheet(self, sheet_name=''):
        """
        시트안의 모든 값만을 삭제 시트를 그대로 둬야하는 경우에 사용 메뉴에서 제외
        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Cells.ClearContents()

    def delete_between_specific_letter_for_range(self, sheet_name='', xyxy='', input_list=["(", ")"], mark_color="yel++", keep_log=False):
        """
        선택된 영역의 셀에서 특정 문자 사이의 값을 삭제 (특수문자 포함)

        예: "abc(def)gh" => "abcgh"
            "test[123]end" => "testend"
            "a(b)c(d)e" => "ace" (여러 개 모두 삭제)

        :return: (dict) 처리 결과 통계
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        try:
            # 입력 처리
            input_list = self.check_input_data(input_list)
            if len(input_list) != 2:
                raise ValueError("input_list는 [시작문자, 끝문자] 형태여야 합니다")

            sheet = self.check_sheet_name(sheet_name)
            [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy)

            # 특수문자 이스케이프 처리
            start_char = str(input_list[0]).strip()
            end_char = str(input_list[1]).strip()

            # re.escape를 사용하여 특수문자 자동 처리
            escaped_start = re.escape(start_char)
            escaped_end = re.escape(end_char)

            # 정규식 패턴: non-greedy 매칭 사용 (.*? 대신 .*?)
            # 중첩 괄호를 고려하지 않는 단순 버전
            pattern = f"{escaped_start}.*?{escaped_end}"

            # 통계
            stats = {
                'total_cells': 0,
                'modified_cells': 0,
                'deleted_patterns': 0
            }

            # 로그 열 추가 (옵션)
            log_col = None
            if keep_log:
                log_col = y2 + 1
                self.insert_yline(sheet_name, log_col)

            # 셀 순회 및 처리
            for x in range(x1, x2 + 1):  # 행 (row)
                for y in range(y1, y2 + 1):  # 열 (column)
                    stats['total_cells'] += 1

                    # 원본 값 읽기
                    original_value = sheet.Cells(x, y).Value

                    # None이나 빈 값 건너뛰기
                    if original_value is None or original_value == "":
                        continue

                    original_str = str(original_value)

                    # 패턴 찾기
                    matches = re.findall(pattern, original_str)

                    if matches:
                        # 패턴 삭제
                        modified_str = re.sub(pattern, "", original_str)

                        # 실제로 변경된 경우만 처리
                        if modified_str != original_str:
                            # 값 업데이트
                            sheet.Cells(x, y).Value = modified_str

                            # 색상 표시
                            if mark_color:
                                try:
                                    color_rgb = self.xycolor.change_any_color_to_rgbint(mark_color)
                                    sheet.Cells(x, y).Interior.Color = color_rgb
                                except:
                                    pass  # 색상 적용 실패해도 계속 진행

                            # 로그 기록
                            if keep_log and log_col:
                                deleted_info = " | ".join(matches)
                                sheet.Cells(x, log_col).Value = deleted_info

                            # 통계 업데이트
                            stats['modified_cells'] += 1
                            stats['deleted_patterns'] += len(matches)

            # 결과 출력
            print(f"\n{'=' * 50}")
            print(f"삭제 패턴: {start_char}...{end_char}")
            print(f"처리 영역: {sheet.Name} [{x1},{y1}] ~ [{x2},{y2}]")
            print(f"총 셀 수: {stats['total_cells']}")
            print(f"수정된 셀: {stats['modified_cells']}")
            print(f"삭제된 패턴 수: {stats['deleted_patterns']}")
            print(f"{'=' * 50}\n")

            return stats

        except Exception as e:
            print(f"✗ delete_partial_value_between_specific_letter 오류: {str(e)}")
            raise

    def delete_border_line_color_for_range(self, sheet_name='', xyxy=''):
        """
        영역안의 라인의 색을 지우는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Interior.Pattern = 0
        rng.Interior.PatternTintAndShade = 0

    def delete_border_line_for_range(self, sheet_name='', xyxy=''):
        """
        영역의 모든선을 지운다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for each in [5, 6, 7, 8, 9, 10, 11, 12]:
            rng.Borders(each).LineStyle = -4142

    def delete_color_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 영역안의 색을 지우는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        rng.Interior.Pattern = -4142
        rng.Interior.TintAndShade = 0
        rng.Interior.PatternTintAndShade = 0

    def delete_color_n_pattern(self, sheet_name='', xyxy=''):
        """
        선택한 영역안의 색을 지우는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        rng.Interior.Pattern = -4142
        rng.Interior.TintAndShade = 0
        rng.Interior.PatternTintAndShade = 0

    def delete_conditional_format_for_range(self, sheet_name='', xyxy=''):
        """
        영역안의 모든 조건부서식을 삭제하는 기능
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.FormatConditions.Delete()

    def delete_continious_same_value_for_range(self, sheet_name='', xyxy=''):
        """
        영역안의 연속된 같은 값을 지우는 것
        밑으로 같은 값들이 있으면 지우는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        tuple_2d = self.read_value_for_range(sheet_name, xyxy)
        l2d = self.xyutil.change_tuple_2d_to_l2d(tuple_2d)

        for y in range(len(l2d[0])):
            old_value = ""
            for x in range(len(l2d)):
                current_value = l2d[x][y]
                if old_value == current_value:
                    l2d[x][y] = ""
                else:
                    old_value = l2d[x][y]
        sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2)).Value = l2d

    def delete_empty_sheets(self):
        """
        워크북에서 빈 시트를 전부 삭제하는 것
        """
        sheets_name = self.get_all_sheet_name()
        for one_sheet_name in sheets_name:
            check_sheet = self.is_empty_sheet(one_sheet_name)
            if check_sheet:
                self.delete_sheet_by_name(one_sheet_name)

    def delete_empty_xline_for_range(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역의 각x영역이 비어있으면, 전체 x라인을 삭제하는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for x in range(x2, x1 - 1, -1):
            xrange = sheet.Range(sheet.Cells(x, y1), sheet.Cells(x, y2))
            num = self.xlapp.WorksheetFunction.CountA(xrange)
            if num == 0:
                changed_address = str(x) + ":" + str(x)
                sheet.Rows(changed_address).Delete()

    def delete_empty_yline_for_range(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역의 각y영역이 비어있으면, 전체 y라인을 삭제하는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for y in range(y2, y1 - 1, -1):
            cha_y = self.change_num_to_char(y)

            yrange = sheet.Range(sheet.Cells(x1, y), sheet.Cells(x2, y))
            num = self.xlapp.WorksheetFunction.CountA(yrange)
            if num == 0:
                changed_address = str(cha_y) + ":" + str(cha_y)
                sheet.Columns(changed_address).Delete()

    def delete_eng_char_for_range(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        xy_value_l2d = []
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                changed_one_value = re.sub(r'[a-zA-Z]', '', one_value)
                if one_value != changed_one_value:
                    xy_value_l2d.append([x, y, x, y, changed_one_value])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_file(self, input_path):
        """
        입력으로 드러오는 화일을 삭제
        """
        input_path = self.xyutil.check_file_path(input_path)
        os.remove(input_path)

    def delete_font_bold(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Bold = False

    def delete_font_italic(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Italic = False

    def delete_font_strikethrough(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Strikethrough = False

    def delete_font_underline(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Underline = False

    def delete_int_n_eng_char_for_range(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                changed_one_value = re.sub(r'[a-zA-Z]', '', one_value)
                if one_value != changed_one_value:
                    sheet.Cells(x, y).Value = changed_one_value

    def delete_link_for_range(self, sheet_name='', xyxy=''):
        """
        선택된 영역안의 링크를 삭제하는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Hyperlinks.Delete()

    def delete_memo_for_range(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.ClearComments()

    def delete_nea_conditional_format_for_sheet(self, sheet_name, start_no, end_no):
        """
        시트안의 n개의 조건부서식을 삭제하는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        for no in range(start_no, end_no + 1):
            sheet.UsedRange.FormatConditions.Item(no).Delete()

    def delete_nth_char_for_range_from_left(self, sheet_name='', xyxy='', input_no=None):
        """
        """
        [sheet_name, xyxy, input_no] = self._check_3_param(sheet_name, xyxy, input_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value[input_no:]])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_nth_char_for_range_from_right(self, sheet_name='', xyxy='', input_no=None):
        """

        """
        [sheet_name, xyxy, input_no] = self._check_3_param(sheet_name, xyxy, input_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value[:-input_no]])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_nth_char_from_left(self, sheet_name='', xyxy='', input_no=None):
        """

        """
        [sheet_name, xyxy, input_no] = self._check_3_param(sheet_name, xyxy, input_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                xy_value_l2d.append([x, y, x, y, one_value[:input_no - 1] + one_value[input_no:]])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_nth_char_from_right(self, sheet_name, xyxy, start_no, end_no):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read(sheet_name, xyxy)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                if -start_no + 1 < 0:
                    changed_value = one_value[:- end_no] + one_value[-start_no + 1:]
                else:
                    changed_value = one_value[:- end_no]
                sheet.Cells(x, y).Value = changed_value

    def delete_number_n_comma_in_range(self, sheet_name='', xyxy=''):
        """
        셀의 숫자와 ,를 삭제하는 기능

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        xy_value_l2d = []
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            changed_value = self.xyre.delete_number_n_comma(one_value)
            if one_value != changed_value:
                xy_value_l2d.append([x, y, x, y, changed_value])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_numbers_for_range(self, sheet_name='', xyxy=''):
        """
        셀의 숫자와 ,를 삭제하는 기능
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)
        xy_value_l2d = []
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            changed_value = self.xyre.delete_number_n_comma(one_value)
            if one_value != changed_value:
                xy_value_l2d.append([x, y, x, y, changed_value])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_panthom_link(self):
        """
        이름영역중에서 연결이 끊긴것을 삭제하는 것
        """
        names_count = self.xlbook.Names.Count
        del_count = 0
        if names_count > 0:
            for aaa in range(names_count, 0, -1):
                name_name = self.xlbook.Names(aaa).Name
                name_range = self.xlbook.Names(aaa)

                if "#ref!" in str(name_range).lower():
                    print("found panthom link!!! ===> ", name_name)
                    self.xlapp.Names(aaa).Delete()
                    del_count = del_count + 1
        print("Deleted Nos ==> ", del_count)

    def delete_partial_value_as_eng_char(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = sheet.Cells(x, y).Value
            if isinstance(one_value, str):
                changed_one_value = re.sub(r'[a-zA-Z]', '', one_value)
                if one_value != changed_one_value:
                    sheet.Cells(x, y).Value = changed_one_value

    def delete_partial_value_for_range_as_eng_char(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)
        xy_value_l2d = []
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                changed_one_value = re.sub(r'[a-zA-Z]', '', one_value)
                if one_value != changed_one_value:
                    xy_value_l2d.append([x, y, x, y, changed_one_value])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_partial_value_for_range_as_int_char(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)
        xy_value_l2d = []

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                changed_one_value = re.sub(r'[0-9]', '', one_value)
                if one_value != changed_one_value:
                    xy_value_l2d.append([x, y, x, y, changed_one_value])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_partial_value_for_range_as_int_n_eng_char(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                changed_one_value = re.sub(r'[a-zA-Z]', '', one_value)
                if one_value != changed_one_value:
                    sheet.Cells(x, y).Value = changed_one_value

    def delete_partial_value_for_range_between_specific_letter(self, sheet_name, xyxy, input_list=["(", ")"], mark_color="yel++", keep_log=False):
        """
        선택된 영역의 셀에서 특정 문자 사이의 값을 삭제 (특수문자 포함)
        """
        try:
            # 입력 처리
            input_list = self.check_input_data(input_list)
            if len(input_list) != 2:
                raise ValueError("input_list는 [시작문자, 끝문자] 형태여야 합니다")

            sheet = self.check_sheet_name(sheet_name)
            [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy)

            # 특수문자 이스케이프 처리
            start_char = str(input_list[0]).strip()
            end_char = str(input_list[1]).strip()

            # re.escape를 사용하여 특수문자 자동 처리
            escaped_start = re.escape(start_char)
            escaped_end = re.escape(end_char)

            # 정규식 패턴: non-greedy 매칭 사용 (.*? 대신 .*?)
            # 중첩 괄호를 고려하지 않는 단순 버전
            pattern = f"{escaped_start}.*?{escaped_end}"

            # 통계
            stats = {
                'total_cells': 0,
                'modified_cells': 0,
                'deleted_patterns': 0
            }

            # 로그 열 추가 (옵션)
            log_col = None
            if keep_log:
                log_col = y2 + 1
                self.insert_yline(sheet_name, log_col)

            # 셀 순회 및 처리
            for x in range(x1, x2 + 1):  # 행 (row)
                for y in range(y1, y2 + 1):  # 열 (column)
                    stats['total_cells'] += 1
                    original_value = sheet.Cells(x, y).Value  # 원본 값 읽기

                    # None이나 빈 값 건너뛰기
                    if original_value is None or original_value == "":
                        continue

                    original_str = str(original_value)

                    # 패턴 찾기
                    matches = re.findall(pattern, original_str)

                    if matches:
                        # 패턴 삭제
                        modified_str = re.sub(pattern, "", original_str)

                        # 실제로 변경된 경우만 처리
                        if modified_str != original_str:
                            # 값 업데이트
                            sheet.Cells(x, y).Value = modified_str

                            # 색상 표시
                            if mark_color:
                                try:
                                    color_rgb = self.xycolor.change_any_color_to_rgbint(mark_color)
                                    sheet.Cells(x, y).Interior.Color = color_rgb
                                except:
                                    pass  # 색상 적용 실패해도 계속 진행

                            # 로그 기록
                            if keep_log and log_col:
                                deleted_info = " | ".join(matches)
                                sheet.Cells(x, log_col).Value = deleted_info

                            # 통계 업데이트
                            stats['modified_cells'] += 1
                            stats['deleted_patterns'] += len(matches)

            # 결과 출력
            print(f"\n{'=' * 50}")
            print(f"삭제 패턴: {start_char}...{end_char}")
            print(f"처리 영역: {sheet.Name} [{x1},{y1}] ~ [{x2},{y2}]")
            print(f"총 셀 수: {stats['total_cells']}")
            print(f"수정된 셀: {stats['modified_cells']}")
            print(f"삭제된 패턴 수: {stats['deleted_patterns']}")
            print(f"{'=' * 50}\n")

            return stats

        except Exception as e:
            print(f"✗ delete_partial_value_for_range_between_specific_letter 오류: {str(e)}")
            raise

    def delete_partial_value_for_range_right_value_from_1st_found_position_by_xsql(self, sheet_name, xyxy, input_xre):
        """
        처음 찾은 자료의 오른쪽의 모든 자료를 삭제하는것
        """
        [sheet_name, xyxy, input_xre] = self._check_3_param(sheet_name, xyxy, input_xre)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x in range(xyxy[0], xyxy[2] + 1):
            for y in range(xyxy[1], xyxy[3] + 1):
                one_value = sheet.Cells(x, y).Value
                aaa = self.xyre.search_all_by_xsql(input_xre, one_value)
                if aaa:
                    temp = one_value[:int(aaa[0][2])]
                sheet.Cells(x, y).Value = temp

    def delete_range_names(self):
        """
        모든 range_name을 삭제하는 것
        """
        for one_rng_name in self.xlapp.Names:
            ddd = str(one_rng_name.Name)
            if ddd.find("!") < 0:
                self.xlbook.Names(ddd).Delete()

    def delete_right_value_from_1st_found_position_for_range_by_xsql(self, input_xre):
        """
        처음 찾은 자료의 오른쪽의 모든 자료를 삭제하는것

        """
        sheet = self.check_sheet_name('')
        xyxy = self.address_for_selection()
        for x in range(xyxy[0], xyxy[2] + 1):
            for y in range(xyxy[1], xyxy[3] + 1):
                one_value = sheet.Cells(x, y).Value
                aaa = self.xyre.search_all_by_xsql(input_xre, one_value)
                if aaa:
                    temp = one_value[:int(aaa[0][2])]
                sheet.Cells(x, y).Value = temp

    def delete_same_value_except_first_one(self):
        """

        """
        self.delete_same_value_over_n_times(2)

    def delete_same_value_for_range(self, sheet_name='', xyxy=''):
        """
        선택된 영역안의 같은 값을 지우는 것
        """
        self.delete_same_value_for_range_over_n_times(sheet_name, xyxy, 2)

    def delete_same_value_for_range_over_n_times(self, sheet_name='', xyxy='', input_no=None):
        """
        n번째 반복되는 것들만 삭제한다
        1로 하면, 전체가 다 삭제되는것과 같다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2)).Value

        unique_dic = {}
        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                if one_value:
                    if one_value in unique_dic.keys():
                        unique_dic[one_value] = unique_dic[one_value] + 1
                    else:
                        unique_dic[one_value] = 1

                    if unique_dic[one_value] >= input_no:
                        sheet.Cells(x1 + ix, y1 + iy).Value = ""

    def delete_same_xline_for_range(self, sheet_name='', xyxy='', input_list=None):
        """
        입력영역의 같은 자료 삭제
        """
        [sheet_name, xyxy, input_list] = self._check_3_param(sheet_name, xyxy, input_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x in range(x2, x1 - 1, -1):
            temp = self.read_value_for_range(sheet_name, [x, y1, x, y1 + len(input_list[0] - 1)])
            if input_list == temp:
                self.delete_xline(sheet_name, [x, x])

    def delete_shape_by_name(self, shape_name, sheet_name=''):
        """
        객체의 이름으로 제거하는것

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Shapes(shape_name).Delete()

    def delete_shape_by_no(self, sheet_name, input_no):
        """
        시트안의 모든 객체를 삭제하는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Shapes(input_no).Delete()

    def delete_shape_for_sheet_by_name(self, sheet_name, shape_name):
        """
        객체의 이름으로 제거하는것
        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Shapes(shape_name).Delete()

    def delete_all_shape_for_sheet(self, sheet_name=''):
        """
        시트안의 모든 객체를 삭제하는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        drawings_nos = sheet.Shapes.Count

        if drawings_nos > 0:
            for num in range(drawings_nos, 0, -1):
                # Range를 앞에서부터하니 삭제하자마자 번호가 다시 매겨져서, 뒤에서부터 삭제하니 잘된다
                sheet.Shapes(num).Delete()
        return drawings_nos

    def delete_sheet_by_name(self, sheet_name=''):
        """
        시트하나 삭제하기
        """
        try:
            sheet = self.check_sheet_name(sheet_name)
            self.xlapp.DisplayAlerts = False
            sheet.Delete()
            self.xlapp.DisplayAlerts = True
        except:
            pass

    def delete_sheet_by_no(self, input_no):
        """
        앞에서부터 n번째의 시트를 삭제하는 것
        """
        sheets_name_list = self.get_all_sheet_name()
        self.delete_sheet_by_name(sheets_name_list[input_no - 1])

    def delete_string_numbers_for_range(self, sheet_name='', xyxy=''):
        """
        영역안의 각셀의 값중에서 숫자를 모두 삭제하는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)
        xy_value_l2d = []
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                changed_value = self.xyre.delete_number_n_comma(one_value)
                if one_value != changed_value:
                    xy_value_l2d.append([x, y, x, y, changed_value])
        self.group_n_write_for_xy_value_l2d(sheet, xy_value_l2d)

    def delete_tab_color_by_sheet_name(self, sheet_name=''):
        """
        시트탭의 색을 넣는것
        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Tab.ColorIndex = -4142
        sheet.Tab.TintAndShade = 0

    def delete_text_num(self, sheet_name='', xyxy=''):
        """

        """

        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = sheet.Cells(x, y).Value
            if isinstance(one_value, str):
                changed_one_value = re.sub(r'[0-9]', '', one_value)
                if one_value != changed_one_value:
                    sheet.Cells(x, y).Value = changed_one_value

    def delete_text_num_n_comma(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            value = self.read_value_for_cell("", [x, y])
            if isinstance(value, str):
                changed_value = self.xyre.delete_num_comma(value)
                sheet.Cells(x, y).Value = changed_value

    def delete_value(self, sheet_name='', xyxy=''):
        """

        """
        self.delete_value_for_range(sheet_name, xyxy)

    def delete_value_for_cell(self, sheet_name='', xyxy=''):
        """

        """
        self.delete_value_for_range(sheet_name, xyxy)

    def delete_value_for_range(self, sheet_name='', xyxy=''):
        """
        delete_value(sheet_name="", xyxy)
        range의 입력방법은 [row1, col1, row2, col2]이다
        선택한 영역안의 모든 값을 지운다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.ClearContents()

    def delete_value_for_range_by_step(self, sheet_name='', xyxy='', step_no=None):
        """
        선택한 영역 내에서 n번째 행마다 값만 삭제합니다 (행 자체는 유지).
        """
        [sheet_name, xyxy, step_no] = self._check_3_param(sheet_name, xyxy, step_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for x in range(x1, x2 + 1):
            if divmod(x - x1 + 1, step_no)[1] == 0:
                sheet.Range(sheet.Cells(x, y1), sheet.Cells(x, y2)).ClearContents()

    def delete_value_for_range_for_same_value_by_many_same_column(self, sheet_name='', xyxy=''):
        """
        영역안의 같은 값을 지우는 것
        """
        self.delete_xxline_value_for_range_by_same_line(sheet_name, xyxy)

    def delete_value_for_range_name(self, range_name):
        """
        입력한 영역의 이름을 삭제
        """
        result = self.xlbook.Names(range_name).Delete()
        return result

    def delete_value_for_same_value_by_many_same_column(self, sheet_name='', xyxy=''):
        """
        영역안의 같은 값을 지우는 것

        """
        self.delete_value_for_xxline_by_same_line(sheet_name, xyxy)

    def delete_value_for_usedrange(self, sheet_name=''):
        """
        자주사용하는 것 같아서 usedrange의 값을 지우는것을 만들어 보았다
        """
        sheet = self.check_sheet_name(sheet_name)
        temp_range = self.get_address_for_usedrange(sheet_name)
        sheet.Range(temp_range[2]).ClearContents()

    def delete_value_for_xline(self, sheet_name, input_l1d):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        input_l1d = self.check_l1d(input_l1d)
        for ix, no in enumerate(input_l1d):
            sheet.Rows(str(no) + ':' + str(no)).ClearContents()

    def delete_value_for_xline_by_step(self, sheet_name='', xyxy='', step_no=None):
        """
        삭제 : 2 ==> 기존의 2번째 마다 삭제 (1,2,3,4,5,6,7 => 1,3,5,7)
        삭제 : 선택자료중 n번째 세로줄의 자료를 값만 삭제하는것
        일하다보면 3번째 줄만 삭제하고싶은경우가 있다, 이럴때 사용하는 것

        """
        [sheet_name, xyxy, step_no] = self._check_3_param(sheet_name, xyxy, step_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for ix, no in enumerate(range(x1, x2 + 1, step_no)):
            sheet.Rows(str(no) + ':' + str(no)).ClearContents()

    def delete_value_for_xline_when_same_multi_y_lines(self, sheet_name, xyxy, input_no_list=None):
        """
        2차원의 자료에서 여러 y줄의 값이같을때 제일 처음의것만 남기고 나머지는 줄을 전체를 삭제하는것
        """
        [sheet_name, xyxy, input_no_list] = self._check_3_param(sheet_name, xyxy, input_no_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        unique_set = set()

        for ix, l1d in enumerate(l2d):
            changed_l1d = [tuple(l1d[i] for i in input_no_list)]
            if changed_l1d in unique_set:
                sheet.Rows(str(ix + x1) + ':' + str(ix + x1)).ClearContents()
            else:
                unique_set.add(changed_l1d)

    def delete_value_for_xrange(self, input_no, step_on=False, sheet_name='', xyxy=''):
        """
        설정된 영역(rng) 내에서 n번째 가로줄(행)의 값만 삭제합니다.

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        total_rows = rng.Rows.Count

        if step_on:
            current_step = input_no
            while current_step <= total_rows:
                rng.Rows(current_step).ClearContents()
                current_step += input_no
        else:
            # n번째 한 줄만 삭제
            if input_no <= total_rows:
                rng.Rows(input_no).ClearContents()
        sheet.Application.CutCopyMode = False

    def delete_value_for_xxline_by_same_line(self, sheet_name='', xyxy=''):
        """
        한줄씩 비교를 해서, 줄의 모든 값이 똑같으면 처음것을 제외하고 다음 자료부터 값만 삭제하는 것이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        unique_set = set()
        for ix, l1d in enumerate(l2d):
            if l1d in unique_set:
                sheet.Rows(str(ix + x1) + ':' + str(ix + x1)).ClearContents()
            else:
                unique_set.add(l1d)

    def delete_value_for_yline(self, sheet_name, yy_list):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        y1, y2 = self.check_yy_address(yy_list)
        sheet.Columns(str(y1) + ':' + str(y2)).ClearContents()

    def delete_value_for_yline_by_step(self, sheet_name='', xyxy='', step_no=None):
        """
        선택한 영역안의 세로줄중에서 선택한 몇번째마다 y라인의 값을 삭제하는것
        (선택한 영역안에서 3번째 마다의 y라인의 값을 삭제하는것)

        """
        self.delete_yline_by_step(sheet_name, xyxy, step_no)

    def delete_value_n_format(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역의 모든 내용과 서식을 삭제합니다.

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Clear()

    def delete_vba_module_by_name_list(self, module_name_list):
        """
        열려있는 화일안에서 입력리스트의 메크로를 삭제를 하는 것
        """
        for module_name in module_name_list:
            xlmodule = self.xlbook.VBProject.VBComponents(module_name)
            self.xlbook.VBProject.VBComponents.Remove(xlmodule)

    def delete_xline(self, sheet_name, x_list):
        """
        지정한 행들을 삭제합니다 (행 자체를 제거).
        """
        sheet = self.check_sheet_name(sheet_name)
        for ix, no in enumerate(x_list):
            sheet.Rows(str(no - ix) + ':' + str(no - ix)).Delete()

    def delete_xline_for_range_by_step(self, sheet_name='', xyxy='', step_no=None):
        """
        선택영역안의 => 선택한 n번째 가로행을 삭제한다. 값만 삭제하는것이 아니다
        위에서부터 삭제가 되게 만든것
        """
        [sheet_name, xyxy, step_no] = self._check_3_param(sheet_name, xyxy, step_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for ix, no in enumerate(range(x1, x2 + 1, step_no)):
            sheet.Rows(str(no - ix) + ':' + str(no - ix)).Delete()

    def delete_xline_for_range_when_same_multi_y_lines(self, sheet_name='', xyxy='', input_no_list=None):
        """
        여러줄의 값이 같은것만 삭제하는것
        [1, 3, 5]값이 다 같은 것만 삭제하는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        filtered_l2d = []
        for l1d in l2d:
            new_row = []
            for idx in input_no_list:
                new_row.append(l1d[idx - 1])
            filtered_l2d.append(new_row)

        temp_set = set()
        for ix, l1d in enumerate(filtered_l2d):
            if l1d in temp_set:
                sheet.Range(sheet.Cells(ix + x1 + 1, y1), sheet.Cells(ix + x1 + 1, y2)).ClearContents()

    def delete_xline_in_l2d_by_empty_iy(self, input_l2d, index_y):
        """
        y열이 비었있을때, 그줄을 삭제
        엑셀에서 읽어온 자료중에 어떤 줄의 값이 없는것만 삭제하고 싶을때 사용하는 목적으로 만든것이다
        """
        result = []
        for l1d in input_l2d:
            if isinstance(l1d[index_y], pywintypes.TimeType):
                pass
            elif None == l1d[index_y] and l1d[index_y] == "":
                result.append(l1d)
            else:
                pass
        return result

    def delete_xline_in_l2d_by_not_empty_iy(self, input_l2d, index_y):
        """
        y열이 비었있지 않을때, 그줄을 삭제
        엑셀에서 읽어온 자료중에 어떤 줄의 값이 있는것만 삭제하고 싶을때 사용하는 목적으로 만든것이다
        """
        result = []
        for l1d in input_l2d:
            if isinstance(l1d[index_y], pywintypes.TimeType):
                result.append(l1d)
            elif None != l1d[index_y] and l1d[index_y] != "":
                result.append(l1d)
            else:
                print(" error => ", l1d[index_y])
        return result

    def delete_xline_value_for_range_when_same_multi_y_line_value(self, sheet_name, xyxy, input_no_list=None):
        """
        2차원의 자료에서 여러 y줄의 값이 제일위의것과 같은 줄을 전체를 삭제하는것
        """
        [sheet_name, xyxy, input_no_list] = self._check_3_param(sheet_name, xyxy, input_no_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        # unique_l2d = self.get_unique_columns_basic(l2d, input_no_list)

        top_line = [tuple(l2d[0][i] for i in input_no_list)]

        for ix, l1d in enumerate(l2d):
            changed_l1d = [tuple(l1d[i] for i in input_no_list)]
            if top_line == changed_l1d:
                sheet.Rows(str(ix + x1) + ':' + str(ix + x1)).ClearContents()

    def delete_xline_value_for_range_when_same_multi_y_lines(self, sheet_name, xyxy, input_no_list=None):
        """
        2차원의 자료에서 여러 y줄의 값이같을때 제일 처음의것만 남기고 나머지는 줄을 전체를 삭제하는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        unique_set = set()

        for ix, l1d in enumerate(l2d):
            changed_l1d = [tuple(l1d[i] for i in input_no_list)]
            if changed_l1d in unique_set:
                sheet.Rows(str(ix + x1) + ':' + str(ix + x1)).ClearContents()
            else:
                unique_set.add(changed_l1d)

    def delete_xline_value_when_same_multi_y_lines(self, sheet_name, xyxy, input_no_list):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read(sheet_name, xyxy)
        unique_l2d = self.get_unique_columns_basic(l2d, input_no_list)

        for base_l1d in unique_l2d:
            found_count = 0
            for ix, l1d in enumerate(l2d):
                changed_l1d = [tuple(l1d[i] for i in input_no_list)]
                if base_l1d == changed_l1d:
                    if found_count > 0:
                        sheet.Rows(str(ix + x1) + ':' + str(ix + x1)).ClearContents()
                    found_count = found_count + 1

    def delete_xline_when_same_multi_y_lines(self, sheet_name, xyxy, input_no_list=None):
        """
        여러줄의 값이 같은것만 삭제하는것
        [1, 3, 5]값이 다 같은 것만 삭제하는것


        """
        [sheet_name, xyxy, input_no_list] = self._check_3_param(sheet_name, xyxy, input_no_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        filtered_l2d = []
        for l1d in l2d:
            new_row = []
            for idx in input_no_list:
                new_row.append(l1d[idx - 1])
            filtered_l2d.append(new_row)

        temp_set = set()
        for ix, l1d in enumerate(filtered_l2d):
            if l1d in temp_set:
                sheet.Range(sheet.Cells(ix + x1 + 1, y1), sheet.Cells(ix + x1 + 1, y2)).ClearContents()

    def delete_xxline(self, sheet_name, xx_list):
        """
        지정한 범위의 연속된 열들을 삭제합니다.


            excel.delete_yyline([2, 5])  # 2~5번 열 삭제
        """
        sheet = self.check_sheet_name(sheet_name)
        xx = self.check_xx_address(xx_list)
        sheet.Rows(str(xx[0]) + ':' + str(xx[1])).Delete()

    def delete_xxline_value_for_range_by_same_line(self, sheet_name='', xyxy=''):
        """
        한줄씩 비교를 해서, 줄의 모든 값이 똑같으면 처음것을 제외하고 다음 자료부터 값만 삭제하는 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        unique_set = set()
        for ix, l1d in enumerate(l2d):
            if l1d in unique_set:
                sheet.Rows(str(ix + x1) + ':' + str(ix + x1)).ClearContents()
            else:
                unique_set.add(l1d)

    def delete_yline(self, sheet_name, yy_list):
        """
        지정한 열들을 삭제합니다 (열 자체를 제거).


            excel.delete_yline(1, 3, 5)  # 1, 3, 5번 열 삭제
        """
        sheet = self.check_sheet_name(sheet_name)
        y1, y2 = self.check_yy_address(yy_list)
        sheet.Columns(y1 + ':' + y2).Delete()

    def delete_yline_by_step(self, sheet_name, xyxy, step_no):
        """

        """
        [sheet_name, xyxy, step_no] = self._check_3_param(sheet_name, xyxy, step_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        current_no = 0
        for y in range(1, y2 - y1 + 1):
            mok, namuji = divmod(y, int(step_no))
            if namuji == 0:
                self.delete_yyline([current_no + y1, current_no + y1])
            else:
                current_no = current_no + 1

    def delete_yline_for_range_by_step(self, sheet_name, xyxy, step_no):
        """
        선택한 영역안의 세로줄중에서 선택한 몇번째마다 y라인을 삭제하는것
        (선택한 영역안에서 3번째 마다의 y라인을 삭제하는것)

        """
        [sheet_name, xyxy, step_no] = self._check_3_param(sheet_name, xyxy, step_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        current_no = 0
        for y in range(1, y2 - y1 + 1):
            mok, namuji = divmod(y, int(step_no))
            if namuji == 0:
                self.delete_yline(sheet_name, [current_no + y1, current_no + y1])
            else:
                current_no = current_no + 1

    def delete_yline_for_range_for_empty_yline(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역안에서 y라인이 모두 빈것을 삭제하는것
        """
        self.delete_empty_yline_for_range(sheet_name, xyxy)

    def delete_ylines_for_input_l2d(self, input_l2d, no_list):
        """

        """
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        no_list.sort()
        no_list.reverse()
        for one in no_list:
            for x in range(len(input_l2d)):
                del input_l2d[x][one]
        return input_l2d

    def delete_ylines_input_l2d_for_yline_nos(self, input_l2d, no_list):
        """
        입력으로받은 번호리스트를 기준으로 2차원의 자료를 삭제하는 것
        """
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        no_list.sort()
        no_list.reverse()
        for one in no_list:
            for x in range(len(input_l2d)):
                del input_l2d[x][one]
        return input_l2d

    def delete_yyline(self, sheet_name='', xyxy='', yy_list=None):
        """

        """
        [sheet_name, xyxy, yy_list] = self._check_3_param(sheet_name, xyxy, yy_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        y1, y2 = self.check_yy_address(yy_list)
        sheet.Columns(y1 + ':' + y1).Delete()

    def divide_1_area_to_3_area(self, xyxy, top_line_no=0, bottom_line_no=0):
        """
        하나의 영역을 상/중/하 3개 영역으로 나누기
        """
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy)
        xyxy_top = None
        xyxy_middle = None
        xyxy_bottom = None

        total_rows = x2 - x1 + 1
        if top_line_no > 0: xyxy_top = [x1, y1, x1 + top_line_no - 1, y2]
        if bottom_line_no > 0: xyxy_bottom = [x2 - bottom_line_no + 1, y1, x2, y2]

        if total_rows > (top_line_no + bottom_line_no):
            middle_start = x1 + top_line_no
            middle_end = x2 - bottom_line_no
            xyxy_middle = [middle_start, y1, middle_end, y2]
        return [xyxy_top, xyxy_middle, xyxy_bottom]

    def draw_all_xline(self, sheet_name, xyxy, input_color, line_style, thickness):
        self.draw_line(sheet_name, xyxy, ["-"], input_color, line_style, thickness)

    def draw_all_yline(self, sheet_name, xyxy, input_color, line_style, thickness):
        self.draw_line(sheet_name, xyxy, ["|"], input_color, line_style, thickness)

    def draw_border_line_for_range(self, sheet_name, xyxy, position="all", input_color="bla", style="-", thickness="thin"):
        self.draw_line(sheet_name, xyxy, position, input_color, style, thickness)

    def draw_by_cxyxy(self, sheet_name, cxyxy=""):
        """
            좌표(x1, y1, x2, y2)를 직접 입력받아 해당 위치에 선(Line) 도형을 생성함

            :return: 생성된 Shape 객체
            """
        sheet = self.check_sheet_name(sheet_name)
        new_shape_obj = sheet.Shapes.AddLine(cxyxy[0], cxyxy[1], cxyxy[2], cxyxy[3])
        return new_shape_obj

    def draw_circle_at_center(self, sheet_name, s_cxy, r, input_color):
        """
        지정한 중심 좌표를 기준으로 반지름 r인 원을 생성함
        보통원은 사각형을 만든어서 그안에 원을 만드는데, 이것은 중심을 기준으로 원을 만드는 것이다
        s_cxy : s(start, 시작위치), c(coordinate, 좌표), xy(cxy의 뜻으로 좌표축의 x,y 라는 의미)

        """
        sheet = self.check_sheet_name(sheet_name)
        center_x = int(s_cxy[0] - r / 2)
        center_y = int(s_cxy[1] - r / 2)

        shape_obj = sheet.Shapes.AddShape(9, center_x, center_y, r, r)
        shape_obj.Fill.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        shape_obj.TextFrame2.VerticalAnchor = 3
        shape_obj.TextFrame2.HorizontalAnchor = 2

    def draw_line(self, sheet_name, xyxy, position="all", input_color="bla", style="-", thickness="thin"):
        """
        내부적으로 들어오는 형태가 튜플로 2차원까지 문제가 될소지가 있어 변경하는 부분이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        line_thickness = self.varx["check_line_thickness"][thickness]
        line_style = self.varx["line_style_vs_enum"][style]
        line_position = self.varx["check_line_position"][position]
        line_color = self.xycolor.change_xcolor_to_rgbint(input_color)

        for one in line_position:
            rng.Borders(one).Color = line_color
            rng.Borders(one).Weight = line_thickness
            rng.Borders(one).LineStyle = line_style

    def draw_line_at_bottom(self, sheet_name, xyxy, input_color, style, thickness):
        self.draw_line(sheet_name, xyxy, "bottom", input_color, style, thickness)

    def draw_line_at_left(self, sheet_name, xyxy, input_color, style, thickness):
        self.draw_line(sheet_name, xyxy, "left", input_color, style, thickness)

    def draw_line_at_outline(self, sheet_name, xyxy, input_color, style, thickness):
        self.draw_line(sheet_name, xyxy, "o", input_color, style, thickness)

    def draw_line_at_right(self, sheet_name, xyxy, input_color, style, thickness):
        self.draw_line(sheet_name, xyxy, "right", input_color, style, thickness)

    def draw_line_at_top(self, sheet_name, xyxy, input_color, style, thickness):
        self.draw_line(sheet_name, xyxy, "top", input_color, style, thickness)

    def excel_hwnd(self):
        """
        엑셀의 핸들값을 갖고오는 것

        """
        return win32gui.FindWindow(None, self.xlapp.Caption)

    def excel_obj(self):
        """
        엑셀프로그램의 객체를 갖고오는 것
        """
        return self.xlapp

    def filename_for_active_workbook(self):
        """
        현재 활성화된 엑셀화일의 이름을 갖고읍니다
        """
        return self.xlapp.ActiveWorkbook.Name

    def find_value_for_range(self, sheet_name, xyxy, old_word="old1", start_cell=[3, 5], value_or_fomular=3, part_or_whole_tf=False, direction=1, direction_next=1, case_tf=False,
                             byte_type_tf=False,
                             cell_format_tf=False):
        """
        엑셀의 찾기 바꾸기 기능을 이용하는 것
        만약 * 또는 ? 기호가 포함된 데이터를 찾거나 수식에 포함하고 싶다면 해당 문자 앞에 ~(물결표)를 붙여주면 됩니다.
        찾기를 하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Find(old_word, old_word, start_cell, value_or_fomular, part_or_whole_tf, direction,
                       direction_next, case_tf,
                       byte_type_tf, cell_format_tf)

    def find_word_for_range(self, sheet_name='', xyxy='', input_value=None):
        """
        영역안의 글자를 찾는다

        """
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        first_range = rng.Find(input_value)
        temp_range = first_range
        if first_range != None:
            while 1:
                temp_range = rng.FindNext(temp_range)
                if temp_range == None or temp_range == first_range.Address:
                    break
                else:
                    temp_range = temp_range

    def font(self, sheet_name, xyxy, *input_list):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return self.set_font(input_list)

    def font_bold_for_range(self, sheet_name='', xyxy=''):
        """
        영역의 폰트를 bold로 설정

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Bold = True

    def font_color_for_part_of_cell_value(self, sheet_name, xyxy, from_to, input_font_list):
        """

        """
        self.font_color_for_part_of_cell_value_for_range(sheet_name, xyxy, from_to, input_font_list)

    def font_color_for_part_of_cell_value_for_range(self, sheet_name, xy, from_to=[7, 12], input_font_list=["Arial"]):
        """
        입력셀의 값중에서 일부분의 폰트색을 칠하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        input_font_list = self.check_input_data(input_font_list)
        ddd = rng.GetCharacters(from_to[0], from_to[1] - from_to[0])

        checked_font = self.xyutil.check_font_data(input_font_list)

        if "color" in checked_font.keys(): ddd.Font.Color = checked_font["color"]
        if "bold" in checked_font.keys(): ddd.Font.Bold = True
        if "size" in checked_font.keys(): ddd.Font.Size = checked_font["size"]
        if "underline" in checked_font.keys(): ddd.Font.Underline = True

    def font_color_for_range(self, sheet_name='', xyxy='', input_color=None):
        """
        셀의 폰트 컬러를 xcolor형식으로 입력된 색으로 적용하는 것

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Color = self.xycolor.change_rgb_to_rgbint(input_color)

    def font_common_dic(self, input_list):
        """
        모듈 전체에서 사용가능한 사전형 자료입니다
        폰트명은 기준을 만들수 없으므로 제외 시켰다


        """
        self.font_dic = {
            "bold": False,
            "color": "bla",
            "italic": False,
            "size": 12,
            "strikethrough": False,
            "subscript": False,
            "superscript": False,
            "alpha": False,
            "underline": False,
            "align_v": 2,
            "align_h": 1}

        for one_value in input_list:
            if one_value in ["bold", "진하게"]:
                self.font_dic["bold"] = True
            elif one_value in ["italic", "이탈릭채", "기울게", "이탈릭", "이탤릭", "이태릭"]:
                self.font_dic["italic"] = True
            elif one_value in ["취소", "strikethrough", "취소선", "strike"]:
                self.font_dic["strikethrough"] = True
            elif one_value in ["아래첨자", "subscript"]:
                self.font_dic["subscript"] = True
            elif one_value in ["윗첨자", "superscript", "super"]:
                self.font_dic["superscript"] = True
            elif one_value in ["밑줄", "underline"]:
                self.font_dic["underline"] = True
            elif isinstance(one_value, int):
                self.font_dic["size"] = one_value
            elif isinstance(one_value, float):
                self.font_dic["alpha"] = one_value
            # tintandshade를 이해하기 쉽게 사용하는 목적
            elif one_value in ["middle", "top", "bottom"]:
                # middle =3, top = 1, bottom = 4, default=2
                temp = {"middle": 3, "top": 1, "bottom": 4}
                self.font_dic["align_v"] = temp[one_value]
            elif one_value in ["center", "left"]:
                # None =1, center=2, left=1, default=1
                temp = {"center": 2, "left": 1}
                self.font_dic["align_h"] = temp[one_value]
            else:
                try:
                    self.font_dic["color"] = self.xycolor.change_xcolor_to_rgbint(one_value)
                except:
                    pass

        return self.font_dic

    def font_for_range(self, sheet_name, xyxy, *input_list):
        """

        """
        return self.set_font(sheet_name, xyxy, input_list)

    def font_italic_for_range(self, sheet_name='', xyxy=''):
        """
        영역안의 값에 취소선을 긎는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Italic = True

    def font_name_for_range(self, sheet_name, xyxy, font_name="Arial"):
        """
        글씨체를 설정하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Name = font_name

    def font_size_for_range(self, sheet_name, xyxy, size="+"):
        """
        영역에 글씨크기를 설정한다
        2023-07-24 : +-도 가능하게 변경

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        if str(size)[0] == "+":
            size_up = 2 * len(size)
            for one in rng:
                basic_size = one.Font.Size
                one.Font.Size = int(basic_size) + size_up
        elif str(size)[0] == "-":
            size_down = -2 * len(size)
            for one in rng:
                new_size = one.Font.Size + size_down
                if new_size <= 0:
                    one.Font.Size = 3
                else:
                    one.Font.Size = new_size
        else:
            rng.Font.Size = size

    def font_strikethrough_for_range(self, sheet_name='', xyxy=''):
        """
        영역안의 값에 취소선을 긎는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Strikethrough = True

    def font_style(self, sheet_name='', xyxy='', input_value=None):
        """
        현재 영역의 폰트 스타일을 직접 지정함 (예: "Bold Italic")

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Style = input_value

    def font_underline_for_range(self, sheet_name='', xyxy=''):
        """
        영역의 값에 밑줄을 긎는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Font.Underline = True

    def font_with_easy_style(self, sheet_name, xyxy, *input_l1d):
        """
        폰트의 속성을 설정한다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for one in input_l1d:
            if isinstance(one, int):
                rng.Font.Size = one
            elif one in ["bold", "굵게", "찐하게", "진하게"]:
                rng.Font.Bold = one
            elif one in ["italic", "이태리", "이태리체", "기울기"]:
                rng.Font.Italic = one
            elif one in ["strikethrough", "취소선", "취소", "통과선", "strike"]:
                rng.Font.Strikethrough = one
            elif one in ["subscript", "하위첨자", "아래첨자", "아랫첨자", "밑첨자"]:
                rng.Font.Subscript = one
            elif one in ["superscript", "윗첨자", "위첨자", "웃첨자"]:
                rng.Font.Superscript = one
            elif one in ["underline", "밑줄"]:
                rng.Font.Underline = one
            elif one in ["vertical", "ver", "alignv"]:
                ver_value = {"middle": -4108, "top": 1, "bottom": 4, "default": 2, "중간": 3, "위": 1, "아래": 4}
                rng.VerticalAlignment = ver_value[one]
            elif one in ["horizontal", "hor", "alignh"]:
                ver_value = {"middle": -4108, "top": 1, "bottom": 4, "중간": 3, "위": 1, "아래": 4, "default": 2}
                rng.HorizontalAlignment = ver_value[one]
            elif isinstance(one, list):
                rng.Font.Color = self.xycolor.change_xcolor_to_rgbint(one)
            else:
                try:
                    rng.Font.Color = self.xycolor.change_xcolor_to_rgbint(one)
                except:
                    pass

    def font_with_easy_style_for_range(self, sheet_name, xyxy, *input_l1d):
        """
        폰트의 속성을 설정한다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for one in input_l1d:
            if isinstance(one, int):
                rng.Font.Size = one
            elif one in ["bold", "굵게", "찐하게", "진하게"]:
                rng.Font.Bold = one
            elif one in ["italic", "이태리", "이태리체", "기울기"]:
                rng.Font.Italic = one
            elif one in ["strikethrough", "취소선", "취소", "통과선", "strike"]:
                rng.Font.Strikethrough = one
            elif one in ["subscript", "하위첨자", "아래첨자", "아랫첨자", "밑첨자"]:
                rng.Font.Subscript = one
            elif one in ["superscript", "윗첨자", "위첨자", "웃첨자"]:
                rng.Font.Superscript = one
            elif one in ["underline", "밑줄"]:
                rng.Font.Underline = one
            elif one in ["vertical", "ver", "alignv"]:
                ver_value = {"middle": -4108, "top": 1, "bottom": 4, "default": 2, "중간": 3, "위": 1, "아래": 4}
                rng.VerticalAlignment = ver_value[one]
            elif one in ["horizontal", "hor", "alignh"]:
                ver_value = {"middle": -4108, "top": 1, "bottom": 4, "중간": 3, "위": 1, "아래": 4, "default": 2}
                rng.HorizontalAlignment = ver_value[one]
            elif isinstance(one, list):
                rng.Font.Color = self.xycolor.change_xcolor_to_rgbint(one)
            else:
                try:
                    rng.Font.Color = self.xycolor.change_xcolor_to_rgbint(one)
                except:
                    pass

    def font_x_align(self, sheet_name, xyxy, x_align):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        dic_x = {"right": -4152, "middle": -4108, "center": -4108, "left": -4131, "오른쪽": -4152, "중간": 2, "왼쪽": -4131}
        if x_align: rng.HorizontalAlignment = dic_x[x_align]

    def font_y_align(self, sheet_name, xyxy, y_align):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        dic_y = {"middle": -4108, "center": -4108, "top": -4160, "bottom": -4107, "low": -4107, "중간": -4108, "위": -4160,
                 "아래": - 4107}
        if y_align: rng.VerticalAlignment = dic_y[y_align]

    def formula_for_range(self, sheet_name, xyxy, input_value="=Now()"):
        """
        영역에 수식을 넣는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Formula = input_value

    def freeze(self, sheet_name='', xyxy=''):
        """
        현재 선택된 영역을 고정시키는 것

        """
        self.xlbook.Windows(1).FreezePanes = False
        x1, y1, x2, y2 = self.change_address_to_xyxy("")
        if y1 == 0:
            self.select_range_for_xxline("", x1)
        elif x1 == 0:
            self.select_range_for_yyline("", y1)
        else:
            self.select_for_cell("", [x1, y1])
        self.xlbook.Windows(1).FreezePanes = True

    def freeze_pane_at_xline(self, sheet_name, input_xno):
        """
        틀고정 : 가로열을 기준으로 한 것

        선택영역의 왼쪽끝을 기준으로 틀고정이 일어나므로 첫줄을 하고싶으면 2를 넣어야 한다
        만약 1을 넣으면 현재 시트의 셀이 선택된 곳을 기준으로 틀고정이 일어난다

        """
        self.select_sheet(sheet_name)
        self.xlbook.Windows(1).FreezePanes = False
        self.select_xline(sheet_name=sheet_name, x_list=input_xno)
        self.xlbook.Windows(1).FreezePanes = True

    def freeze_pane_at_xy(self, sheet_name, input_xy):
        """
        틀고정 : 셀을 기준으로 실행
        선택역역의 왼쪽위를 기준으로 틀고정이 일어난다

        """
        self.select_sheet(sheet_name)
        self.xlbook.Windows(1).FreezePanes = False
        self.select(sheet_name=sheet_name, xyxy=input_xy)
        self.xlbook.Windows(1).FreezePanes = True

    def freeze_pane_at_yline(self, sheet_name, input_xno):
        """
        틀고정 : 세로열을 기준으로 한 것
        선택영역의 왼쪽끝을 기준으로 틀고정이 일어나므로 첫줄을 하고싶으면 2를 넣어야 한다
        만약 1을 넣으면 현재 시트의 셀이 선택된 곳을 기준으로 틀고정이 일어난다

        """
        self.select_sheet(sheet_name)
        self.xlbook.Windows(1).FreezePanes = False
        self.select_yline(sheet_name=sheet_name, y_list=input_xno)
        self.xlbook.Windows(1).FreezePanes = True

    def freeze_pane_by_xy_for_sheet(self, sheet_name, input_xy):
        """
        틀고정 : 셀을 기준으로 실행
        선택역역의 왼쪽위를 기준으로 틀고정이 일어난다

        """
        self.select_sheet(sheet_name)
        self.xlbook.Windows(1).FreezePanes = False
        self.select_for_cell(sheet_name, input_xy)
        self.xlbook.Windows(1).FreezePanes = True

    def freeze_pane_for_xline_for_sheet(self, sheet_name, input_xno):
        """
        틀고정 : 가로열을 기준으로 한 것

        선택영역의 왼쪽끝을 기준으로 틀고정이 일어나므로 첫줄을 하고싶으면 2를 넣어야 한다
        만약 1을 넣으면 현재 시트의 셀이 선택된 곳을 기준으로 틀고정이 일어난다

        """
        self.select_sheet(sheet_name)
        self.xlbook.Windows(1).FreezePanes = False
        self.select_xline_for_sheet(sheet_name, input_xno)
        self.xlbook.Windows(1).FreezePanes = True

    def freeze_pane_for_yline(self, input_yno):
        """

        """
        self.freeze_pane_for_yline_for_sheet("", input_yno)

    def freeze_pane_for_yline_for_sheet(self, sheet_name, input_yno):
        """
        틀고정 : 세로열을 기준으로 한 것
        선택영역의 왼쪽끝을 기준으로 틀고정이 일어나므로 첫줄을 하고싶으면 2를 넣어야 한다
        만약 1을 넣으면 현재 시트의 셀이 선택된 곳을 기준으로 틀고정이 일어난다

        """
        self.select_sheet(sheet_name)
        self.xlbook.Windows(1).FreezePanes = False
        self.select_yline_for_sheet(sheet_name, input_yno)
        self.xlbook.Windows(1).FreezePanes = True

    def freeze_pane_off_for_sheet(self, sheet_name=''):
        """
        틀고정 해제

        """
        self.select_sheet(sheet_name)
        self.xlbook.Windows(1).FreezePanes = False

    def full_screen(self, fullscreen=1):
        """
        전체화면으로 보이게 하는 것

        """
        self.xlapp.DisplayFullScreen = fullscreen

    def get_56color_for_cell(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = rng.Interior.ColorIndex
        return result

    def get_activesheet_name(self):
        """

        """
        sheet_name = self.xlapp.ActiveSheet.Name
        return sheet_name

    def get_activeworkbook_obj(self, sheet_name='', xyxy=''):
        """

        """
        return self.xlapp.ActiveWorkbook

    def get_address(self, sheet_name, xyxy, option=""):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        if option == "":
            return self.get_address_for_selection()
        elif "used" in option:
            return self.get_address_for_usedrange('')
        elif "con" in option:
            continious_rng = rng.CurrentRegion()
            return self.change_address_to_xyxy(continious_rng)

    def get_address_all_empty_cell(self, sheet_name='', xyxy=''):
        """
        영역안의 빈셀의 주소값을 묶어서 돌려준다

        """
        result = []
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        for ix, l1d in enumerate(l2d):
            for iy, value in enumerate(l1d):
                if l2d[ix][iy] == "" or l2d[ix][iy] == None:
                    result.append([ix + x1, iy + y1])
        return result

    def get_address_at_xy_for_multi_merged_area(self, start_xy, xy_step, input_no):
        """
        다음번 셀의 주소틀 눙려주는것
        병합이된 셀이 동일하게 연속적으로 있다고 할때, n번째의 셀 주소를 계산하는것

        """

        mok, namuji = divmod((input_no - 1), xy_step[1])
        new_x = mok * xy_step[0] + start_xy[0]

        new_y = namuji * xy_step[1] + start_xy[1] + 1
        return [new_x, new_y]

    def get_address_for_activecell(self, sheet_name='', xyxy=''):
        """
        현재 활성화된 셀의 주소를 돌려준다

        """
        return self.change_address_to_xyxy(self.xlapp.ActiveCell.Address)

    def get_address_for_bottom(self, xy=''):
        """

        """
        return self.get_address_for_right_end_n_bottom_from_cell('', xy)

    def get_address_for_cell(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return [x1, y1]

    def get_address_for_intersect_two_range(self, xyxy1, xyxy2):
        """
        두개의 영역에서 교차하는 구간을 돌려준다
        만약 교차하는게 없으면 ""을 돌려준다
        """
        x11, y11, x12, y12 = self.change_address_to_xyxy(xyxy1)
        x21, y21, x22, y22 = self.change_address_to_xyxy(xyxy2)
        if x11 == 0:
            x11 = 1
            x12 = 1048576
        if x21 == 0:
            x21 = 1
            x22 = 1048576
        if y11 == 0:
            y11 = 1
            y12 = 16384
        if y21 == 0:
            y21 = 1
            y22 = 16384
        new_rng_x = [x11, x21, x12, x22]
        new_rng_y = [y11, y21, y12, y22]
        new_rng_x.sort()
        new_rng_y.sort()
        if x11 <= new_rng_x[1] and x12 >= new_rng_x[2] and y11 <= new_rng_y[1] and y12 >= new_rng_y[1]:
            result = [new_rng_x[1], new_rng_y[1], new_rng_x[2], new_rng_y[2]]
        else:
            result = "교차점없음"
        return result

    def get_address_for_multi_selection(self):
        """

        """
        clean_addresses = [area.Address(False, False) for area in self.selection.Areas]
        xyxy_l2d = []
        for one_address in clean_addresses:
            xyxy_l2d.append(self.change_address_to_xyxy(one_address))
        return xyxy_l2d

    def get_address_for_range(self, sheet_name='', xyxy=''):
        """
        현재 선택영역을 xyxy형태의 주소로 돌려주는 것

        """
        temp_address = self.xlapp.Selection.Address
        result = self.change_address_to_xyxy(temp_address)
        return result

    def get_address_for_range_for_all_empty_cell(self, sheet_name='', xyxy=''):
        """
        영역안의 빈셀의 주소값을 묶어서 돌려준다
        """
        result = []
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        for ix, l1d in enumerate(l2d):
            for iy, value in enumerate(l1d):
                if l2d[ix][iy] == "" or l2d[ix][iy] == None:
                    result.append([ix + x1, iy + y1])
        return result

    def get_address_for_range_for_bottom_end(self, sheet_name='', xy=''):
        """
        값이 있는것의 맨 아래쪽 자료를 찾는 것은 이것을 이용하자
        end 는 만약 바로 밑의 자료가 없으면, 있는것이 나타날때까지의 위치를
        그래서 바로밑의 자료가 있는지를 먼저 확인하는 기능을 넣었다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        cell = self.new_range_for_range(sheet_name, [x1, y1])
        down_end = cell.End(-4121)  # xlDown
        x3, y3, x4, y4 = self.change_address_to_xyxy(down_end.Address)
        result = [x3, y3]
        return result

    def get_address_for_range_for_currentregion(self, sheet_name='', xy=''):
        """
        currentregion의 주소를 갖고오는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        address = rng.CurrentRegion.Address
        result = self.change_address_to_xyxy(address)
        return result

    def get_address_for_range_for_end(self, sheet_name='', xy=''):
        """
        어떤 셀을 기준으로 값이 연속된 가장 먼 위치를 갖고오는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        cell = self.new_range_for_range(sheet_name, [x1, y1])
        left_end = cell.End(-4159)  # xIToLeft
        right_end = cell.End(-4161)  # lToRight
        up_end = cell.End(-4162)  # xlUp
        down_end = cell.End(-4121)  # xlDown

        # 각 방향의 끝 지점 주소 출력
        return [left_end.Address, right_end.Address, up_end.Address, down_end.Address]

    def get_address_for_range_name(self, sheet_name, range_name):
        """
        이름영역의 주소값을 갖고오는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        temp = sheet.Range(range_name).Address
        result = self.change_address_to_xyxy(temp)
        return result

    def get_address_for_right_end(self, sheet_name='', xyxy=''):
        """

        """
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        return y2

    def get_address_for_right_end_n_bottom_from_cell(self, sheet_name='', xy=''):
        """
        특정셀을 기준으로 연속된 오른쪽과 아래쪽까지의 주소값

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)

        right_end = rng.End(-4161)  # lToRight
        x3, y3, x4, y4 = self.change_address_to_xyxy(right_end.Address)

        down_end = sheet.Cells(x3, y3).End(-4121)  # xlDown
        x5, y5, x6, y6 = self.change_address_to_xyxy(down_end.Address)
        return [x5, y5]

    def get_address_for_selection(self):
        """
        선택된 영역의 주소값을 갖고온다

        """
        temp_address = self.xlapp.Selection.Address
        result = self.change_address_to_xyxy(temp_address)
        return result

    def get_address_for_usedrange(self, sheet_name=''):
        """
        특정시트의 사용된 영역을 갖고오는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        result = self.change_address_to_xyxy(sheet.UsedRange.Address)
        return result

    def get_address_for_xy_for_multi_merged_area(self, start_xy, xy_step, input_no):
        """
        다음번 셀의 주소틀 눙려주는것
        병합이된 셀이 동일하게 연속적으로 있다고 할때, n번째의 셀 주소를 계산하는것
        """

        mok, namuji = divmod((input_no - 1), xy_step[1])
        new_x = mok * xy_step[0] + start_xy[0]

        new_y = namuji * xy_step[1] + start_xy[1] + 1
        return [new_x, new_y]

    def get_all_conditional_format_for_sheet(self, sheet_name=''):
        """
        특정 시트안의 모든 조건부서식을 갖고오는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        result = []
        for format_condition in sheet.UsedRange.FormatConditions:
            condition_type = format_condition.Type
            try:
                applies_to = format_condition.AppliesTo.Address
            except:
                applies_to = None

            try:
                formula1 = format_condition.Formula1
            except:
                formula1 = None

            try:
                formula2 = format_condition.Formula2
            except:
                formula2 = None

            try:
                operator = format_condition.Operator
            except:
                operator = None

            interior_color = format_condition.Interior.Color if hasattr(format_condition, 'Interior') else None
            font_color = format_condition.Font.Color if hasattr(format_condition, 'Font') else None
            font_name = format_condition.Font.Name if hasattr(format_condition, 'Font') else None
            font_size = format_condition.Font.Size if hasattr(format_condition, 'Font') else None
            font_bold = format_condition.Font.Bold if hasattr(format_condition, 'Font') else None
            font_italic = format_condition.Font.Italic if hasattr(format_condition, 'Font') else None
            font_underline = format_condition.Font.Underline if hasattr(format_condition, 'Font') else None

            result.append({'Type': condition_type, 'Formula1': formula1, 'Formula2': formula2, 'Operator': operator, 'AppliesTo': applies_to,
                           'InteriorColor': interior_color, 'FontColor': font_color,
                           'FontName': font_name, 'FontSize': font_size, 'FontBold': font_bold, 'FontItalic': font_italic, 'FontUnderline': font_underline})
        return result

    def get_all_property_for_cell(self, sheet_name='', xyxy=''):
        """
        셀의 모든 속성을 돌려주는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        one_cell = sheet.Cells(x1, y1)
        result = {}
        result["y"] = y1
        result["x"] = x1
        result["value"] = one_cell.Value
        result["value2"] = one_cell.Value2
        result["formula"] = one_cell.Formula
        result["formular1c1"] = one_cell.FormulaR1C1
        result["text"] = one_cell.Text
        result["font_background"] = one_cell.Font.Background
        result["font_bold"] = one_cell.Font.Bold
        result["font_color"] = one_cell.Font.Color
        result["font_colorindex"] = one_cell.Font.ColorIndex
        result["font_creator"] = one_cell.Font.Creator
        result["font_style"] = one_cell.Font.FontStyle
        result["font_italic"] = one_cell.Font.Italic
        result["font_name"] = one_cell.Font.Name
        result["font_size"] = one_cell.Font.Size
        result["font_strikethrough"] = one_cell.Font.Strikethrough
        result["font_subscript"] = one_cell.Font.Subscript
        result["font_superscript"] = one_cell.Font.Superscript
        try:
            result["font_themecolor"] = one_cell.Font.ThemeColor
            result["font_themefont"] = one_cell.Font.ThemeFont
            result["font_tintandshade"] = one_cell.Font.TintAndShade
            result["font_underline"] = one_cell.Font.Underline
            result["memo"] = one_cell.Comment.Text()
        except:
            result["memo"] = ""
        result["background_color"] = one_cell.Interior.Color
        result["background_colorindex"] = one_cell.Interior.ColorIndex
        result["numberformat"] = one_cell.NumberFormat
        # linestyle이 없으면 라인이 없는것으로 생각하고 나머지를 확인하지 않으면서 시간을 줄이는 것이다
        result["line_top_style"] = one_cell.Borders(7).LineStyle
        result["line_top_color"] = one_cell.Borders(7).Color
        result["line_top_colorindex"] = one_cell.Borders(7).ColorIndex
        result["line_top_thick"] = one_cell.Borders(7).Weight
        result["line_top_tintandshade"] = one_cell.Borders(7).TintAndShade
        result["line_bottom_style"] = one_cell.Borders(8).LineStyle
        result["line_bottom_color"] = one_cell.Borders(8).Color
        result["line_bottom_colorindex"] = one_cell.Borders(8).ColorIndex
        result["line_bottom_thick"] = one_cell.Borders(8).Weight
        result["line_bottom_tintandshade"] = one_cell.Borders(8).TintAndShade
        result["line_left_style"] = one_cell.Borders(9).LineStyle
        result["line_left_color"] = one_cell.Borders(9).Color
        result["line_left_colorindex"] = one_cell.Borders(9).ColorIndex
        result["line_left_thick"] = one_cell.Borders(9).Weight
        result["line_left_tintandshade"] = one_cell.Borders(9).TintAndShade
        result["line_right_style"] = one_cell.Borders(10).LineStyle
        result["line_right_color"] = one_cell.Borders(10).Color
        result["line_right_colorindex"] = one_cell.Borders(10).ColorIndex
        result["line_right_thick"] = one_cell.Borders(10).Weight
        result["line_right_tintandshade"] = one_cell.Borders(10).TintAndShade
        result["line_x1_style"] = one_cell.Borders(11).LineStyle
        result["line_x1_color"] = one_cell.Borders(11).Color
        result["line_x1_colorindex"] = one_cell.Borders(11).ColorIndex
        result["line_x1_thick"] = one_cell.Borders(11).Weight
        result["line_x1_tintandshade"] = one_cell.Borders(11).TintAndShade
        result["line_x2_style"] = one_cell.Borders(12).LineStyle
        result["line_x2_color"] = one_cell.Borders(12).Color
        result["line_x2_colorindex"] = one_cell.Borders(12).ColorIndex
        result["line_x2_thick"] = one_cell.Borders(12).Weight
        result["line_x2_tintandshade"] = one_cell.Borders(12).TintAndShade
        return result

    def get_all_range_name(self):
        """
        현재 활성화된 엑셀화일의 모든 이름영역(range_name)을 갖고오는 것

        """
        names_count = self.xlbook.Names.Count
        result = []
        if names_count > 0:
            for aaa in range(1, names_count + 1):
                name_name = self.xlbook.Names(aaa).Name
                name_range = self.xlbook.Names(aaa)
                result.append([aaa, str(name_name), str(name_range)])
        return result

    def get_all_selected_shape_name(self):
        """

        """
        result = []
        sel_shape_objs = self.xlapp.Selection.ShapeRange
        if sel_shape_objs.Count:
            for one_obj in sel_shape_objs:
                shape_name = one_obj.Name
                result.append(shape_name)
        return result

    def get_all_shape_name_for_sheet(self, sheet_name=''):
        """
        현재 시트의 모든 객체의 이름에 대해서 갖고오는 것이다
        """
        sheet = self.check_sheet_name(sheet_name)
        result = []

        shape_ea = sheet.Shapes.Count
        if shape_ea > 0:
            for no in range(shape_ea):
                result.append(sheet.Shapes(no + 1).Name)
        return result

    def get_all_shape_name_for_workbook(self):
        """
        엑셀화일안의 모든 그림객체에대한 이름을 갖고온다
        결과 : [시트이름, 그림이름]
        """
        result = []
        sheets_name = self.all_sheet_name()
        for sheet_name in sheets_name:
            shapes_name = self.all_shape_name_for_sheet(sheet_name)
            if shapes_name:
                for shape_name in shapes_name:
                    result.append([sheet_name, shape_name])
        return result

    def get_all_sheet_name_sort_by_position(self):
        """
        워크시트의 모든 이름을 위치를 기준으로 정렬해서 돌려준다
        """
        result = []
        for a in range(1, self.xlbook.Worksheets.Count + 1):
            result.append(self.xlbook.Worksheets(a).Name)
        return result

    def get_all_vba_module_name(self):
        """

        """
        result = []
        for i in self.xlbook.VBProject.VBComponents:
            if i.type in [1, 2, 3]:
                result.append(i.Name)
        return result

    def get_all_vba_sub_name(self):
        """
        현재 열려진 엑셀 화일안의 매크로모듈 이름을 찾아서 돌려주는 것
        아래에 1,2,3을 쓴것은 모듈의 종류를 여러가지인데, 해당하는 모듈의 종류이며.
        이것을 하지 않으면 다른 종류의 것들도 돌려주기 때문이다
        """
        module_name_list = []
        sub_name_list = []

        VBProj = self.xlbook.VBProject

        for i in VBProj.VBComponents:
            if i.type in [1, 2, 3]:
                module_name_list.append(i.Name)

        for i in VBProj.VBComponents:
            num_lines = i.CodeModule.CountOfLines

            for j in range(1, num_lines + 1):

                if 'Sub' in i.CodeModule.Lines(j, 1) and not 'End Sub' in i.CodeModule.Lines(j, 1):
                    aaa = i.CodeModule.Lines(j, 1)
                    aaa = str(aaa).replace("Sub", "")
                    aaa = aaa.split("(")[0]

                    sub_name_list.append(aaa.strip())

        return sub_name_list

    def get_all_filename_for_opened_workbooks(self):
        """
        모든 열려있는 엑셀화일의 이름을 갖고옵니다

        """
        return [one.Name for one in self.xlapp.Workbooks]

    def get_all_formula(self, sheet_name='', xyxy=''):
        """
        영역안의 모든 수식을 갖고온다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return rng.Formula

    def get_cell_obj_for_cell(self, sheet_name='', xy=''):
        """
        입력 셀의 객체를 만들어서 돌려준다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        return sheet.Cells(x1, y1)

    def get_cell_size(self, x, y, start_pxy=[2, 4], sheet="object1", input_factor=2, monitor_dpi=16):
        """
        모니터에서 특정셀의 픽셀사이즈를 알아내는 것이다
        """
        cell_target = sheet.Cells(x, y)
        excel_header_width = start_pxy[0]
        excel_header_height = start_pxy[1]
        excel_zoom100 = cell_target.Parent.Parent.Windows(1).Zoom

        x1 = int((cell_target.Left * excel_zoom100 / 100) * (monitor_dpi / 72) / input_factor + excel_header_width)
        y1 = int((cell_target.Top * excel_zoom100 / 100) * (monitor_dpi / 72) / input_factor + excel_header_height)
        x2 = int((cell_target.Width * excel_zoom100 / 100) * (monitor_dpi / 72)) / input_factor + x1
        y2 = int((cell_target.Height * excel_zoom100 / 100) * (monitor_dpi / 72)) / input_factor + y1

        return [x1, y1, x2, y2]

    def get_cell_value_as_5_style_set(self, sheet_name, xy=''):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        one_cell = sheet.Cells(xy[0], xy[1])
        result = {}
        result["value"] = one_cell.Value
        result["value2"] = one_cell.Value2
        result["formula"] = one_cell.Formula
        result["formular1c1"] = one_cell.FormulaR1C1
        result["text"] = one_cell.Text
        return result

    def get_conditional_formats_for_sheet(self, sheet_name=''):
        """
        특정 시트안의 모든 조건부서식을 갖고오는 것
        """
        result = []
        sheet = self.check_sheet_name(sheet_name)
        for format_condition in sheet.UsedRange.FormatConditions:
            condition_type = format_condition.Type
            try:
                applies_to = format_condition.AppliesTo.Address
            except:
                applies_to = None

            try:
                formula1 = format_condition.Formula1
            except:
                formula1 = None

            try:
                formula2 = format_condition.Formula2
            except:
                formula2 = None

            try:
                operator = format_condition.Operator
            except:
                operator = None

            interior_color = format_condition.Interior.Color if hasattr(format_condition, 'Interior') else None
            font_color = format_condition.Font.Color if hasattr(format_condition, 'Font') else None
            font_name = format_condition.Font.Name if hasattr(format_condition, 'Font') else None
            font_size = format_condition.Font.Size if hasattr(format_condition, 'Font') else None
            font_bold = format_condition.Font.Bold if hasattr(format_condition, 'Font') else None
            font_italic = format_condition.Font.Italic if hasattr(format_condition, 'Font') else None
            font_underline = format_condition.Font.Underline if hasattr(format_condition, 'Font') else None

            result.append({'Type': condition_type, 'Formula1': formula1, 'Formula2': formula2, 'Operator': operator, 'AppliesTo': applies_to,
                           'InteriorColor': interior_color, 'FontColor': font_color,
                           'FontName': font_name, 'FontSize': font_size, 'FontBold': font_bold, 'FontItalic': font_italic, 'FontUnderline': font_underline})
        return result

    def get_coord_for_cell(self, sheet_name='', xyxy=''):
        """
        셀의 픽셀 좌표를 갖고온다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return [rng.Left, rng.Top, rng.Width, rng.Height]

    def get_current_path(self):
        """
        현재 경로를 알아내는 것
        """
        return os.getcwd()

    def get_cxy_for_cell(self, sheet_name='', xyxy=''):
        """
        셀의 픽셀 좌표를 갖고온다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return [rng.Left, rng.Top, rng.Width, rng.Height]

    def get_cxy_for_cell_by_screen_base(self, excel_hwnd=423456, sheet="object1", row=3, col=7):
        """
        현재 화면을 기준으로 셀의 절대좌표값을 갖고오는 것이다
        """
        # 셀의 좌표와 크기를 가져옵니다
        cell = sheet.Cells(row, col)
        # 엑셀 창의 위치를 가져옵니다
        window_left, window_top, _, _ = self.get_excel_window_rect(excel_hwnd)
        # 엑셀 창의 클라이언트 영역의 좌표를 가져옵니다
        point = ctypes.wintypes.POINT()
        point.x = 0
        point.y = 0
        ctypes.windll.user32.ClientToScreen(excel_hwnd.ctypes.byref(point))
        client_left = point.x
        client_top = point.y
        # 셀의 화면 좌표를 계산합니다
        screen_left = client_left + cell.Left
        screen_top = client_top + cell.Top
        return screen_left, screen_top, cell.Width, cell.Height

    def get_cxy_for_visible_range(self, excel_obj):
        """
        현재 화면에 조금이라도 보이는 셀의 주소를 갖고온다

        """
        active_window = excel_obj.ActiveWindow
        visible_range = active_window.VisibleRange

        start_row = visible_range.Row
        start_col = visible_range.Column
        end_row = start_row + visible_range.Rows.Count - 1
        end_col = start_col + visible_range.Columns.Count - 1
        return [start_row, start_col, end_row, end_col]

    def get_data_type_for_input_value(self, input_value):
        """
        입력으로 들어온 값의 자료형이 str, int, real, boolen, list, tuple, dic인지를 알아내는 것

        """

        if isinstance(input_value, str):
            result = "str"
        elif isinstance(input_value, int):
            result = "int"
        elif isinstance(input_value, float):
            result = "real"
        elif isinstance(input_value, bool):
            result = "boolen"
        elif isinstance(input_value, list):
            result = "list"
        elif isinstance(input_value, tuple):
            result = "tuple"
        elif isinstance(input_value, dict):
            result = "dic"
        else:
            result = input_value
        return result

    def get_degree_for_shape(self, sheet_name, shape_no):
        """
        도형의 각도를 읽는 것

        """
        shape_obj = self.new_shape_obj_by_no(sheet_name, shape_no)
        result = shape_obj.Rotation
        return result

    def get_diagonal_xy(self, xyxy=''):
        """
        좌표와 대각선의 방향을 입력받으면, 대각선에 해당하는 셀을 돌려주는것
        좌표를 낮은것 부터 정렬하기이한것 [3, 4, 1, 2] => [1, 2, 3, 4]
        """
        result = []
        if xyxy[0] > xyxy[2]:
            x1, y1, x2, y2 = xyxy[2], xyxy[3], xyxy[0], xyxy[1]
        else:
            x1, y1, x2, y2 = xyxy

        x_height = abs(x2 - x1) + 1
        y_width = abs(y2 - y1) + 1
        step = x_height / y_width
        temp = 0

        if x1 <= x2 and y1 <= y2:
            # \형태의 대각선
            for y in range(1, y_width + 1):
                x = y * step
                if int(x) >= 1:
                    final_x = int(x) + x1 - 1
                    final_y = int(y) + y1 - 1
                    if temp != final_x:
                        result.append([final_x, final_y])
                        temp = final_x
        else:
            for y in range(y_width, 0, -1):
                x = x_height - y * step

                final_x = int(x) + x1
                final_y = int(y) + y1 - y_width
                temp_no = int(x)

                if temp != final_x:
                    temp = final_x
                    result.append([final_x, final_y])
        return result

    def get_dpi(self):
        """
        스크린의 dpi를 읽어오는 것

        """
        # Get the screen DPI
        hdc = ctypes.windll.user32.GetDC(0)
        dpi = ctypes.windll.gdi32.GetDeviceCaps(hdc, 88)
        ctypes.windll.user32.ReleaseDC(0, hdc)
        return dpi

    def get_excel_hwnd(self):
        """
        엑셀의 핸들값을 갖고오는 것

        """
        return win32gui.FindWindow(None, self.xlapp.Caption)

    def get_excel_obj(self):
        """
        엑셀프로그램의 객체를 갖고오는 것

        """
        return self.xlapp

    def get_excel_window_rect(self, input_hwnd, rate=50):
        """
        엑셀이 현재 보여지는 영역의 사각형의 크기를갖고오는 것
        """

        class RECT(ctypes.Structure):
            _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long), ("right", ctypes.c_long), ("bottom", ctypes.c_long)]

        # RECT 구조체를 정의합니다
        rect = RECT()
        # GetWindowRect 함수를 사용하여 창의 위치와 크기를 가져옵니다.
        ctypes.windll.user32.GetWindowRect(input_hwnd, ctypes.byref(rect))
        l1, t1, r1, b1 = rect.left, rect.top, rect.right, rect.bottom
        return [int(rect.left / rate), int(rect.top / rate), int(rect.right / rate), int(rect.bottom / rate)]

    def get_filename_for_active_workbook(self):
        """
        현재 활성화된 엑셀화일의 이름을 갖고읍니다

        """
        return self.xlapp.ActiveWorkbook.Name

    def get_font_color(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return rng.Font.Color

    def get_font_name_for_range(self, sheet_name='', xyxy=''):
        """
        영역에 적용된 글씨체를 갖고오는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = rng.Font.Name
        return result

    def get_formula_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 영역의 수식을 읽어오면, 수식이 없는 것은 입력값이 들어가 있다
        그래서, =로시작하는 수식만 남기는 것이다
        """
        result = []
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        tup_2d = rng.Formula
        if isinstance(tup_2d, list) or isinstance(tup_2d, tuple):
            pass
        else:
            tup_2d = [tup_2d]
        for tup_1d in tup_2d:
            temp_list = []
            for value in tup_1d:
                if str(value).startswith("="):
                    temp_list.append(value)
                else:
                    temp_list.append(None)
            result.append(temp_list)
        return result

    def get_formulas_for_range(self, sheet_name='', xyxy=''):
        """
        영역안의 모든 수식을 갖고온다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return rng.Formula

    def get_general(self):
        """
        몇가지 엑셀에서 자주사용하는 것들정의
        엑셀의 사용자, 현재의 경로, 화일이름, 현재시트의 이름
        """
        return [self.xlapp.Name, self.xlapp.UserName, self.xlapp.ActiveSheet.Name]

    def get_height(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = rng.RowHeight
        return result

    def get_height_for_xxline(self, sheet_name, xx_list):
        """
        연속된 가로줄의 전체 넓이를 갖고 오는것
        """
        sheet = self.check_sheet_name(sheet_name)
        rng = sheet.Range(sheet.Cells(xx_list[0], 1), sheet.Cells(xx_list[1], 1))
        result = rng.RowHeight
        return result

    def get_information_for_excel(self):
        """
        몇가지 엑셀에서 자주사용하는 것들정의
        엑셀의 사용자, 현재의 경로, 화일이름, 현재시트의 이름

        """
        result = []
        result.append(self.xlapp.Name)
        result.append(self.xlapp.UserName)
        result.append(self.xlapp.ActiveSheet.Name)
        return result

    def get_information_for_shape(self, sheet_name, shape_no):
        """
        시트의 도형번호를 기준으로 어떤 도형의 기본적인 정보를 갖고오는 것
        """
        result = {}
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(shape_no, int):
            shape_no = self.get_shape_name_by_no(sheet_name, shape_no)
        shape_obj = sheet.Shapes(shape_no)
        result["title"] = shape_obj.Title
        result["text"] = shape_obj.TextFrame2.TextRange.Characters.Text
        result["xy"] = [shape_obj.TopLeftCell.Row, shape_obj.TopLeftCell.Column]
        result["no"] = shape_no
        result["name"] = shape_obj.Name
        result["rotation"] = shape_obj.Rotation
        result["left"] = shape_obj.Left
        result["top"] = shape_obj.Top
        result["width"] = shape_obj.Width
        result["height"] = shape_obj.Height
        result["pxywh"] = [shape_obj.Left, shape_obj.Top, shape_obj.Width, shape_obj.Height]
        return result

    def get_information_for_workbook(self):
        """
        워크북에대한 정보들을 갖고오는 것
        몇가지 엑셀에서 자주사용하는 것들정의
        엑셀의 사용자, 현재의 경로, 화일이름, 현재시트의 이름

        """
        return [self.xlapp.Name, self.xlapp.UserName, self.xlapp.ActiveSheet.Name]

    def get_max_x_n_y_for_sheet(self):
        """
        각 엑셀 버전마다 가로, 세로의 크기가 틀리기 때문에 전체를 설정할때를 나타낼려고 합니다
        엑셀에서는 전체 영역을 주소형태로 나타낼때 $1:$1048576와같이 나타내고있읍니다

        """
        sheet = self.sheet_for_activesheet()
        max_x = sheet.Rows.Count
        max_y = sheet.Columns.Count
        return [max_x, max_y]

    def get_merged_address_list(self):
        """

        """
        return self.get_merged_address_list_for_range('', '')

    def get_merged_address_list_for_range(self, sheet_name='', xyxy=''):
        """
        영역안에 병합된것이 잇으면, 병합된 주소를 리스트형태로 돌려준다
        """
        result = []
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            rng = sheet.Cells(x, y)

            if rng.MergeCells:
                rng.Select()
                ddd = self.read_address_for_selection()
                if not ddd in result:
                    result.append(ddd)
        return result

    def get_missing_num_for_range_in_serial_num(self, sheet_name='', xyxy=''):
        """
        선택영역에서 연속된 번호중 빠진것을 찾는것
        """
        result = []
        set_data = set()
        l2d = self.read_value2_for_range(sheet_name, xyxy)
        max_num = None
        min_num = None
        for l1d in l2d:
            for one in l1d:
                if one:
                    one = int(one)
        if max_num == None:
            max_num = one
        if min_num == None:
            min_num = one
        max_num = max(one, max_num)
        min_num = min(one, min_num)
        set_data.add(one)
        for num in range(min_num, max_num + 1):
            if not num in set_data:
                result.append(num)
        return result

    def get_missing_num_in_serial_num(self):
        """

        """
        return self.get_missing_num_for_range_in_serial_num('', '')

    def get_multi_range_list_by_valued_cells(self, sheet_name=''):
        """
        시트 전체에서 수식을 제외하고, 셀에 값이 있는 영역만 갖고오는것
        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Cells.SpecialCells(2).Select()
        myString = self.xlapp.Selection.Address
        return myString

    def get_numberformat_for_range(self, sheet_name='', xyxy=''):
        """
        속성을 포함한 값을 읽어오는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        result = []
        for x in range(x1, x2 + 1):
            temp = []
            for y in range(y1, y2 + 1):
                one_dic = {}
                one_cell = sheet.Cells(x, y)
                one_dic["y"] = x
                one_dic["x"] = y
                one_dic["value"] = one_cell.Value
                one_dic["value2"] = one_cell.Value2
                one_dic["text"] = one_cell.Text
                one_dic["formula"] = one_cell.Formula
                one_dic["formular1c1"] = one_cell.FormulaR1C1
                one_dic["numberformat"] = one_cell.NumberFormat
                temp.append(one_dic)
            result.append(temp)

        return result

    def get_panthom_link(self):
        """

        """
        return self.get_panthom_link_list_for_workbook()

    def get_panthom_link_list_for_workbook(self):
        """
        현재 활성화된 엑셀 화일안의 이름영역중에서 연결이 끊긴 것을 삭제하기위해 확인하는 것

        """
        names_count = self.xlbook.Names.Count
        result = []
        if names_count > 0:
            for aaa in range(1, names_count + 1):
                name_name = self.xlbook.Names(aaa).Name
                name_range = self.xlbook.Names(aaa)

                if "#ref!" in str(name_range).lower():
                    print("found panthom link!!! ===> ", name_name)
                    result = True
                else:
                    print("normal link, ", name_name)
                    result = False
        return result

    def get_path_for_workbook(self):
        """
        워크북의 경로를 읽어온다

        """
        return self.xlbook.Path

    def get_pixel_size_for_cell(self, sheet_name='', xyxy=''):
        """
        영역의 픽셀값을 4개로 얻어오는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        rng_x_coord = rng.Left
        rng_y_coord = rng.Top
        rng_width = rng.Width
        rng_height = rng.Height
        return [rng_x_coord, rng_y_coord, rng_width, rng_height]

    def get_program_rect(self, input_hwnd):
        """
        입력으로 들어오는 핸들값을 가진 프로그램의 사이즈를 갖고오는 것
        """
        rect = win32gui.GetWindowRect(input_hwnd)
        return rect

    def get_properties_for_cell(self, sheet_name='', xy=''):
        """
        셀의 모든 속성을 돌려주는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        one_cell = sheet.Cells(x1, y1)
        result = {}
        result["y"] = xy[0]
        result["x"] = xy[1]
        result["value"] = one_cell.Value
        result["value2"] = one_cell.Value2
        result["formula"] = one_cell.Formula
        result["formular1c1"] = one_cell.FormulaR1C1
        result["text"] = one_cell.Text
        result["font_background"] = one_cell.Font.Background
        result["font_bold"] = one_cell.Font.Bold
        result["font_color"] = one_cell.Font.Color
        result["font_colorindex"] = one_cell.Font.ColorIndex
        result["font_creator"] = one_cell.Font.Creator
        result["font_style"] = one_cell.Font.FontStyle
        result["font_italic"] = one_cell.Font.Italic
        result["font_name"] = one_cell.Font.Name
        result["font_size"] = one_cell.Font.Size
        result["font_strikethrough"] = one_cell.Font.Strikethrough
        result["font_subscript"] = one_cell.Font.Subscript
        result["font_superscript"] = one_cell.Font.Superscript
        try:
            result["font_themecolor"] = one_cell.Font.ThemeColor
            result["font_themefont"] = one_cell.Font.ThemeFont
            result["font_tintandshade"] = one_cell.Font.TintAndShade
            result["font_underline"] = one_cell.Font.Underline
            result["memo"] = one_cell.Comment.Text()
        except:
            result["memo"] = ""
        result["background_color"] = one_cell.Interior.Color
        result["background_colorindex"] = one_cell.Interior.ColorIndex
        result["numberformat"] = one_cell.NumberFormat
        # linestyle이 없으면 라인이 없는것으로 생각하고 나머지를 확인하지 않으면서 시간을 줄이는 것이다
        result["line_top_style"] = one_cell.Borders(7).LineStyle
        result["line_top_color"] = one_cell.Borders(7).Color
        result["line_top_colorindex"] = one_cell.Borders(7).ColorIndex
        result["line_top_thick"] = one_cell.Borders(7).Weight
        result["line_top_tintandshade"] = one_cell.Borders(7).TintAndShade
        result["line_bottom_style"] = one_cell.Borders(8).LineStyle
        result["line_bottom_color"] = one_cell.Borders(8).Color
        result["line_bottom_colorindex"] = one_cell.Borders(8).ColorIndex
        result["line_bottom_thick"] = one_cell.Borders(8).Weight
        result["line_bottom_tintandshade"] = one_cell.Borders(8).TintAndShade
        result["line_left_style"] = one_cell.Borders(9).LineStyle
        result["line_left_color"] = one_cell.Borders(9).Color
        result["line_left_colorindex"] = one_cell.Borders(9).ColorIndex
        result["line_left_thick"] = one_cell.Borders(9).Weight
        result["line_left_tintandshade"] = one_cell.Borders(9).TintAndShade
        result["line_right_style"] = one_cell.Borders(10).LineStyle
        result["line_right_color"] = one_cell.Borders(10).Color
        result["line_right_colorindex"] = one_cell.Borders(10).ColorIndex
        result["line_right_thick"] = one_cell.Borders(10).Weight
        result["line_right_tintandshade"] = one_cell.Borders(10).TintAndShade
        result["line_x1_style"] = one_cell.Borders(11).LineStyle
        result["line_x1_color"] = one_cell.Borders(11).Color
        result["line_x1_colorindex"] = one_cell.Borders(11).ColorIndex
        result["line_x1_thick"] = one_cell.Borders(11).Weight
        result["line_x1_tintandshade"] = one_cell.Borders(11).TintAndShade
        result["line_x2_style"] = one_cell.Borders(12).LineStyle
        result["line_x2_color"] = one_cell.Borders(12).Color
        result["line_x2_colorindex"] = one_cell.Borders(12).ColorIndex
        result["line_x2_thick"] = one_cell.Borders(12).Weight
        result["line_x2_tintandshade"] = one_cell.Borders(12).TintAndShade
        return result

    def get_pxy_for_cell(self, x, y, sheet):
        """
        하나의 셀에대한 그위치의 필셀값을 갖고오는 것

        """
        excel_header_width, excel_header_height = self.get_visible_range_window_coordinates()
        cell_target = sheet.Cells(x, y)

        excel_zoom100 = cell_target.Parent.Parent.Windows(1).Zoom
        exce_dpi = self.get_dpi()
        print("dpi는 => ", exce_dpi)

        x1 = (cell_target.Left * excel_zoom100 / 100) * (exce_dpi / 72) + excel_header_width
        y1 = (cell_target.Top * excel_zoom100 / 100) * (exce_dpi / 72) + excel_header_height
        x2 = (cell_target.Width * excel_zoom100 / 100) * (exce_dpi / 72) + x1
        y2 = (cell_target.Height * excel_zoom100 / 100) * (exce_dpi / 72) + y1

        return [x1, abs(y1), x2, abs(y2)]

    def get_pxywh_for_range(self, sheet_name='', xyxy=''):
        """
        영역의 넓이와 높이에 대한 정보를 왼쪽위의 픽셀값과 넓이와 높이로 갖고오는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return [rng.Left, rng.Top, rng.Width, rng.Height]

    def get_random_xy_set_from_xyxy(self, xyxy="", count_no=1):
        """
        엑셀영역안에서 랜덤하게 셀주소를 돌려주는것

        """
        result = []
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)

        for no in range(count_no):
            x = random.randint(x1, x2)
            y = random.randint(y1, y2)
            result.append([x, y])
        return result

    def get_range_names(self):
        """
        현재 활성화된 엑셀화일의 모든 이름영역(range_name)을 갖고오는 것

        """
        names_count = self.xlbook.Names.Count
        result = []
        if names_count > 0:
            for aaa in range(1, names_count + 1):
                name_name = self.xlbook.Names(aaa).Name
                name_range = self.xlbook.Names(aaa)
                result.append([aaa, str(name_name), str(name_range)])
        return result

    def get_range_for_range(self, sheet_name='', xyxy=''):
        """
        range 객체를 영역으로 만드는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        if x1 == 0 or x2 == 0:
            start = self.change_num_to_char(y1)
            end = self.change_num_to_char(y2)
            changed_address = str(start) + ":" + str(end)
            rng = sheet.Columns(changed_address)
        elif y1 == 0 or y2 == 0:
            start = self.change_char_to_num(x1)
            end = self.change_char_to_num(x2)
            changed_address = str(start) + ":" + str(end)
            rng = sheet.Rows(changed_address)

        return rng

    def get_range_for_selection(self):
        """

        """
        return self.get_range_for_range('', '')

    def get_range_for_xxline(self, sheet_name, xx_list):
        """
        세로줄의 영역을 range객체로 만드는 것

        """
        new_x = self.check_xx_address(xx_list)
        sheet = self.check_sheet_name(sheet_name)
        result = sheet.Rows(str(new_x[0]) + ':' + str(new_x[1]))
        return result

    def get_range_for_yyline(self, sheet_name, yy_list):
        """
        가로줄의 영역을 range객체로 만드는 것

        """
        y1, y2 = self.check_yy_address(yy_list)
        sheet = self.check_sheet_name(sheet_name)
        result = sheet.Columns(str(y1) + ':' + str(y2))
        return result

    def get_rgb_for_cell(self, sheet_name='', xyxy=''):
        """
        셀의 배경색을 rgb형식의 리스트로 돌려주는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = rng.Interior.Color
        result = self.xycolor.change_rgbint_to_rgb(rgbint)
        return result

    def get_rgbint_for_cell(self, sheet_name='', xyxy=''):
        """
        셀의 배경색을 rgbint로 돌려주는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = rng.Interior.Color
        return result

    def get_same_data_for_two_range(self, xyxy1, xyxy2):
        """
        두개의 영역을 비교해서 같은것을 찾아내는 것

        앞의것이 기준 자료이며, 뒤의것이 찾을 대상이다

        1) 찾을 자료에서 같은것을 찾으면 그셀에 색칠을 하고
        2) 최종적으로 같은것은 새로운 시트에 써준다

        """
        sheet = self.check_sheet_name("")
        base_l2d = self.read_value_for_range("", xyxy1)
        base_l1d = self.xyutil.change_l2d_to_l1d(base_l2d)  # 비교를 위하여 1차원자료로 만든것
        same_data = []
        rgbint = self.xycolor.change_xcolor_to_rgbint("red80")
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy2)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = self.read_value_for_cell("", [x, y])
            if one_value:
                if one_value in base_l1d:
                    same_data.append(one_value)
                    sheet.Cells(x, y).Interior.Color = rgbint

        self.new_sheet()
        sheet.Cells(1, 1).Value = "동일한 값입니다"
        self.write_l1d_from_cell_as_yline("", [1, 2], same_data)
        return 1

    def get_selection_obj(self):
        """
        선택영역의 객체를 돌려주는 것

        """
        rng = self.xlapp.Selection
        return rng

    def get_shape_name_by_no(self, sheet_name, shape_no):
        """
        엑셀화일안에 있는 도형의 번호로 도형의 이름을 갖고오는 것
        번호가 들어오던 이름이 들어오던 도형의 번호를 기준으로 확인해서 돌려주는 것

        """
        check_dic = {}

        if isinstance(shape_no, int):
            result = shape_no
        else:
            sheet = self.check_sheet_name(sheet_name)
            for index in sheet.Shapes.Count:
                shape_name = sheet.Shapes(index).Name
                check_dic[shape_name] = index
            result = check_dic[shape_no]
        return result

    def get_shape_name_for_sheet_by_index(self, sheet_name, shape_no):
        """
        번호로 객체의 이름을 갖고오는것
        """
        sheet = self.check_sheet_name(sheet_name)
        result = sheet.Shapes(shape_no).Name
        return result

    def get_shape_names_for_selected_shape(self):
        """

        """
        result = []
        sel_shape_objs = self.xlapp.Selection.ShapeRange
        if sel_shape_objs.Count:
            for one_obj in sel_shape_objs:
                shape_name = one_obj.Name
                result.append(shape_name)
        return result

    def get_shape_names_for_sheet(self, sheet_name=''):
        """
        현재 시트의 모든 객체의 이름에 대해서 갖고오는 것이다

        """
        result = []
        sheet = self.check_sheet_name(sheet_name)
        shape_ea = sheet.Shapes.Count
        if shape_ea > 0:
            for no in range(shape_ea):
                result.append(sheet.Shapes(no + 1).Name)
        return result

    def get_shape_names_for_workbook(self):
        """
        엑셀화일안의 모든 그림객체에대한 이름을 갖고온다
        결과 : [시트이름, 그림이름]

        """
        result = []
        sheets_name = self.get_all_sheet_name()
        for sheet_name in sheets_name:
            shapes_name = self.get_shape_names_for_sheet(sheet_name)
            if shapes_name:
                for shape_name in shapes_name:
                    result.append([sheet_name, shape_name])
        return result

    def get_shape_obj_by_name(self, sheet_name, shape_no):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(shape_no, str):
            shape_name = self.get_shape_name_by_no(shape_no)
            shape_obj = sheet.Shapes(shape_name)
        elif isinstance(shape_no, int):
            shape_obj = sheet.Shapes(shape_no)
        return shape_obj

    def get_shape_obj_by_no(self,sheet_name, shape_no):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(shape_no, str):
            shape_name = self.get_shape_name_by_no(shape_no)
            shape_obj = sheet.Shapes(shape_name)
        elif isinstance(shape_no, int):
            shape_obj = sheet.Shapes(shape_no)
        return shape_obj

    def get_shape_obj_by_no_or_name(self, sheet_name, shape_no):
        """
        도형의 번호를 기준으로 도형의 객체를 갖고오는 것

        """
        sheet = self.check_sheet_name(sheet_name)

        if isinstance(shape_no, str):
            shape_name = self.get_shape_name_by_no(sheet_name, shape_no)
            shape_obj = sheet.Shapes(shape_name)
        elif isinstance(shape_no, int):
            shape_obj = sheet.Shapes(shape_no)
        return shape_obj

    def get_sheet_hwnd(self, excel_hwnd):
        """
        클라이언트 영역의 핸들 찾기


        """
        child_windows = self.enum_child_windows(excel_hwnd)
        client_hwnd = None
        for child in child_windows:
            class_name = win32gui.GetClassName(child)
            if class_name == "EXCEL7":
                client_hwnd = child
                break
        return client_hwnd

    def get_sheet_name_by_position_no(self, input_no):
        """
        워크시트의 위치번호로 워크시트 이름을 갖고온다

        """
        return self.xlbook.Worksheets(input_no).Name

    def get_sheet_by_sheet_name(self, sheet_name=''):
        """
        입력한 시트이름의 시트객체를 돌려주는 것
        """
        result = self.check_sheet_name(sheet_name)
        return result

    def get_sheet_for_activesheet(self):
        """
        현재 활성화된 시트를 객체형식으로 돌려주는 것

        """
        return self.check_sheet_name("")

    def read_sheet_name_all(self):
        #과거자료 보관용
        return self.get_all_sheet_name()

    def get_all_sheet_name(self):
        """
        현재 활성화된 엑셀화일의 모든 워크시트의 이름을 읽어온다

        """
        return [self.xlbook.Worksheets(a).Name for a in range(1, self.xlbook.Worksheets.Count + 1)]

    def get_unique_columns_basic(self, input_l2d, input_l1d):
        """
        input_l2d: 2차원 리스트
        input_l1d: 뽑아낼 열 인덱스 리스트
        """
        # 1. 특정 열만 추출하여 튜플로 변환 (중복 체크를 위해)
        # 2. set 생성 시 자동으로 중복 제거됨
        unique_set = {tuple(row[i] for i in input_l1d) for row in input_l2d}

        # 3. 결과를 다시 리스트의 리스트 형태로 변환
        return [list(row) for row in unique_set]

    def get_username(self):
        """
        사용자 이름을 읽어온다

        """
        return self.get_username_for_workbook()

    def get_vba_module_names(self):
        """

        """
        result = []
        for i in self.xlbook.VBProject.VBComponents:
            if i.type in [1, 2, 3]:
                result.append(i.Name)
        return result

    def get_vba_sub_names(self):
        """
        현재 열려진 엑셀 화일안의 매크로모듈 이름을 찾아서 돌려주는 것
        아래에 1,2,3을 쓴것은 모듈의 종류를 여러가지인데, 해당하는 모듈의 종류이며.
        이것을 하지 않으면 다른 종류의 것들도 돌려주기 때문이다

        """
        module_name_list = []
        sub_name_list = []

        VBProj = self.xlbook.VBProject

        for i in VBProj.VBComponents:
            if i.type in [1, 2, 3]:
                module_name_list.append(i.Name)

        for i in VBProj.VBComponents:
            num_lines = i.CodeModule.CountOfLines

            for j in range(1, num_lines + 1):

                if 'Sub' in i.CodeModule.Lines(j, 1) and not 'End Sub' in i.CodeModule.Lines(j, 1):
                    aaa = i.CodeModule.Lines(j, 1)
                    aaa = str(aaa).replace("Sub", "")
                    aaa = aaa.split("(")[0]

                    sub_name_list.append(aaa.strip())

        return sub_name_list

    def get_visible_range_window_coordinates(self, excel_obj):
        """
        윈도우 좌표에서 엑셀의 보여지는 영역의 좌표를 갖고오는 것

        """
        worksheet = excel_obj.ActiveSheet
        window = excel_obj.ActiveWindow

        # VisibleRange의 좌표 가져오기
        top_left_cell = worksheet.Cells(1, 1)
        top_left_x = window.PointsToScreenPixelsX(top_left_cell.Left)
        top_left_y = window.PointsToScreenPixelsY(top_left_cell.Top)
        return [top_left_x, top_left_y]

    def get_width_for_range(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = rng.ColumnWidth
        return result

    def get_width_of_yyline(self, sheet_name, yy_list):
        """
        세로줄로만 된 연속된 영역의 넓이를 갖고오는것

        """
        sheet = self.check_sheet_name(sheet_name)
        rng = sheet.Range(sheet.Cells(1, yy_list[0]), sheet.Cells(1, yy_list[1]))
        result = rng.ColumnWidth
        return result

    def get_xlines_when_same_yline_with_input_data(self, sheet_name, xyxy, filter_line, input_value, first_line_is_title_tf):
        """

        """
        l2d = self.read(sheet_name, xyxy)
        result = []

        if first_line_is_title_tf:
            result.append(l2d[0])

        for l1d in l2d:
            if input_value in l1d[int(filter_line)]:
                result.append(l1d)

        return result

    def get_xlines_when_same_yline_with_input_data_for_range(self, sheet_name, xyxy, filter_line=3, input_value=None, first_line_is_title_tf=True):
        """
        선택한 영역의 특정 y값이 입력값과 같은 x라인들을 돌려 주는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        result = []

        if first_line_is_title_tf:
            result.append(l2d[0])

        for l1d in l2d:
            if input_value in l1d[int(filter_line)]:
                result.append(l1d)

        return result

    def get_xy_list_for_circle(self, r, precious=10, xy=[0, 0]):
        """
        엑셀을 기준으로, 반지름이 글자를 원으로 계속 이동시키는 것
        """
        result = []
        temp = []
        for do_1 in range(1, 5):
            for do_step in range(90 * precious + 1):
                degree = (do_1 * do_step) / precious
                # r을 더하는 이유는 마이너스는 않되므로 x, y측을 이동시키는것
                x = math.cos(degree) * r
                y = math.sin(degree) * r
                new_xy = [int(round(x)), int(round(y))]

                if not new_xy in temp:
                    temp.append(new_xy)
        area_1 = []
        area_2 = []
        area_3 = []
        area_4 = []

        for x, y in temp:
            new_x = x + r + 1 + xy[0]
            new_y = y + r + 1 + xy[1]

            if x >= 0 and y >= 0:
                area_1.append([new_x, new_y])
            elif x >= 0 and y < 0:
                area_2.append([new_x, new_y])
            elif x < 0 and y < 0:
                area_3.append([new_x, new_y])
            elif x < 0 and y >= 0:
                area_4.append([new_x, new_y])
        area_1.sort()
        area_1.reverse()
        area_2.sort()
        area_3.sort()
        area_4.sort()
        area_4.reverse()

        result.extend(area_2)
        result.extend(area_1)
        result.extend(area_4)
        result.extend(area_3)
        return result

    def get_ylines_at_l2d(self, input_l2d, input_l1d):
        """
        2차원자료중에서 원하는 가로열들의 자료만 갖고오는 것

        """
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        result = []
        for one_list in input_l2d:
            temp = [one_list[index] for index in input_l1d]
            result.append(temp)
        return result

    def gridline(self, input_tf=True):
        """
        그리드라인을 껏다 켰다하는 것

        """
        if input_tf:
            self.xlapp.ActiveWindow.DisplayGridlines = 1
        else:
            self.xlapp.ActiveWindow.DisplayGridlines = 0

    def group_for_beside_cell_data_as_xline_style(self, input_l2d_y):
        """
        2차원의 자료중에서 바로 옆의 자료인데, 길이가 같은것은 하나로 합치는 기능을 하자
        이번의 것은 가로줄의 형태로 된권을 한치는 권이다

        """
        result = []
        temp = input_l2d_y[0]
        for one in input_l2d_y[1:]:
            if temp[0] == one[0] and temp[1] + 1 == one[1] and temp[2] == one[2] and temp[3] + 1 == one[3]:
                # print(temp[0], one[0], temp[1] + 1, one[1], temp[2], one[2], temp[3] + 1, one[3])
                temp[1] = temp[1] + 1
                temp[3] = temp[3] + 1
                for ix, two in enumerate(one[4]):
                    temp[4][ix].append(one[4][ix])
            else:
                result.append(temp)
                temp = one
        result.append(temp)
        return result

    def group_for_beside_cell_data_as_yline_style(self, input_l2d_x):
        """
        2차원의 자료중에서 바로 옆의 자료인데, 길이가 같은것은 하나로 합치는 기능을 하자
        이번의 것은 가로줄의 형태로 된것을 한치는 것이다
        """
        sorted_l2d = sorted(input_l2d_x, key=lambda item: (item[1], item[0]))  # 1. 경렬 (세로 우선, 가로 차선)
        result = []
        temp = sorted_l2d[0]
        temp[4] = [[temp[4]]]

        for one in sorted_l2d[1:]:
            one[4] = [[one[4]]]
            if temp[1] == one[1] and temp[2] + 1 == one[2] and temp[3] == one[3]:
                temp[2] = temp[2] + 1
                temp[4].append(one[4][0])
            else:
                result.append(temp)
                temp = one
        result.append(temp)
        return result

    def group_n_write_for_xy_value_l2d(self, sheet, input_l2d):
        """
        셀 한개씩의 값을 연속적인 자료로 변경하여 속도를 올리는 데 사용하는것
        단, 세로줄의 연속된 값으로 하는 것이다
        """
        grouped_l2d = self.group_for_beside_cell_data_as_yline_style(input_l2d)

        for ix, l1d in enumerate(grouped_l2d):
            sheet.Range(sheet.Cells(l1d[0], l1d[1]), sheet.Cells(l1d[2], l1d[3])).Value = l1d[4]

    def hide_sheet(self, sheet_name):
        """

        """
        sht_obj = self.new_sheet(sheet_name)
        sht_obj.Visible = False

    def hide_workbook(self):
        """

        """
        self.xlapp.Visible = 0

    def hide_xxline(self, sheet_name, xx_list):
        """
        x라인의 여러줄 숨기기

        """
        sheet = self.check_sheet_name(sheet_name)
        x1, x2 = self.check_xx_address(xx_list)
        sheet.Rows(str(x1) + ":" + str(x2)).Hidden = True

    def hide_yyline(self, sheet_name, yy_list):
        """
        y라인의 여러줄 숨기기

        """
        sheet = self.check_sheet_name(sheet_name)
        y1, y2 = self.check_yy_address(yy_list)
        sheet.Columns(str(y1) + ":" + str(y2)).Hidden = True

    def inputbox(self, input_value):
        """

        """
        return self.xlapp.InputBox(input_value)

    def inputbox_for_range(self, input_value):
        """

        """
        r1c1 = self.xlapp.InputBox(input_value, None, None, None, None, None, None, None, 8).Address
        xyxy = self.change_address_to_xyxy(r1c1)
        return xyxy

    def insert_chart(self, sheet_name, chart_type, input_pxywh, source_xyxy):
        """
        챠트를 만드는 것

        """

        chart_type = self.varx["chart_style_vs_enum"][chart_type]
        sheet = self.check_sheet_name(sheet_name)
        chart_obj = sheet.Chartobjects.Add(input_pxywh)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(source_xyxy)
        r1c1 = self.change_address_to_r1c1([x1, y1, x2, y2])
        rng = sheet.Range(r1c1)
        chart_obj.SetSourceData(rng)
        chart_obj.ChartType = chart_type
        return chart_obj

    def insert_data_input_l2d(self, sheet_name='', xyxy='', input_value=None):
        """
        엑셀의 2차원자료에서 중간에 값을 넣으면, 자동으로 뒤로 밀어서적용되게 하기

        """
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)
        input_value = self.check_input_data(input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        len_x = x2 - x1 + 1
        if isinstance(xyxy, list):
            insert_position = len_x * xyxy[0] + xyxy[1] - 1
        else:
            insert_position = xyxy - 1
        reverse_l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        l1d = self.xyutil.change_l2d_to_l1d(reverse_l2d)
        l1d.insert(insert_position, input_value)
        result = self.xyutil.change_l1d_to_l2d_group_by_step(l1d, len_x)
        return result

    def insert_data_input_l2d_for_range(self, sheet_name, xyxy, xy, input_value):
        """
        엑셀의 2차원자료에서 중간에 값을 넣으면, 자동으로 뒤로 밀어서적용되게 하기
        """
        input_value = self.check_input_data(input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        len_x = x2 - x1 + 1
        if isinstance(xy, list):
            insert_position = len_x * xy[0] + xy[1] - 1
        else:
            insert_position = xy - 1
        reverse_l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        l1d = self.xyutil.change_l2d_to_l1d(reverse_l2d)
        l1d.insert(insert_position, input_value)
        result = self.xyutil.change_l1d_to_l2d_group_by_step(l1d, len_x)
        return result

    def insert_line_by_position(self, sheet_name, xyxy, position_list=[], is_xline=True, line_no=1):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        position_list = self.xyutil.sort_mixed_list(position_list)
        for no in position_list:
            if is_xline:
                sheet.Rows(str(no) + ':' + str(no + line_no - 1)).Insert(-4121)
            else:
                char1 = self.change_num_to_char(no)
                char2 = self.change_num_to_char(no + line_no - 1)
                sheet.Columns(char1 + ':' + char2).Insert(-4121)

    def insert_sheet(self, sheet_name=''):
        """
        시트이름과 함께 시트하나 추가하기
        함수의 공통적인 이름을 위해서 만든것
        """
        sheets_name = self.get_all_sheet_name()
        if sheet_name in sheets_name:
            self.xyutil.messagebox("같은 이름의 시트가 있읍니다")
        else:
            self.xlbook.Worksheets.Add()
            if sheet_name:
                old_name = self.xlapp.ActiveSheet.Name
                self.xlbook.Worksheets(old_name).Name = sheet_name

    def insert_text_at_index_position(self, sheet_name, xyxy, input_index, input_value):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                # 속도를 위해서 사용하는 함수
                one_value = sheet.Cells(x, y).Value

                if len(one_value) > input_index:
                    changed_value = str(one_value)[:input_index] + input_value + str(one_value)[input_index:]
                    sheet.Cells(x, y).Value = changed_value

    def insert_text_at_index_position_for_each_cell(self, sheet_name, xyxy, input_index, input_value):
        """
        각 셀의 값의 3번째 위치에 어떤 문자를 모두 넣고싶은경우가 있다, 그럴 때 사용하는 목적이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            # 속도를 위해서 사용하는 함수
            one_value = l2d[x - x1][y - y1]

            if len(one_value) > input_index:
                changed_value = str(one_value)[:input_index] + input_value + str(one_value)[input_index:]
                sheet.Cells(x, y).Value = changed_value

    def insert_text_at_right_by_xy_step(self, sheet_name, xyxy, input_value, xy_step):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x in range(x1, x2 + 1):
            if divmod(x, xy_step[0])[1] == 0:
                for y in range(y1, y2 + 1):
                    if divmod(x, xy_step[1])[1] == 0:
                        one_value = sheet.Cells(x, y).Value
                        if one_value == None:
                            one_value = ""
                        sheet.Cells(x, y).Value = one_value + str(input_value)

    def insert_text_for_range_at_index_position_for_each_cell(self, sheet_name, xyxy, input_index, input_value):
        """
        각 셀의 값의 3번째 위치에 어떤 문자를 모두 넣고싶은경우가 있다, 그럴 때 사용하는 목적이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            # 속도를 위해서 사용하는 함수
            one_value = l2d[x - x1][y - y1]

            if len(one_value) > input_index:
                changed_value = str(one_value)[:input_index] + input_value + str(one_value)[input_index:]
                sheet.Cells(x, y).Value = changed_value

    def insert_vba_module(self, vba_code, macro_name="name1"):
        """
        텍스트로 만든 매크로 코드를 실행하는 코드이다

        """
        new_vba_code = "Sub " + macro_name + "()" + vba_code + "End Sub"
        mod = self.xlbook.VBProject.VBComponents.Add(1)
        mod.CodeModule.AddFromString(new_vba_code)

    def insert_xline(self, sheet_name="", input_xno=7):
        """
        입력숫자인 가로열의 밑에 한줄삽입하기
        """
        sheet = self.check_sheet_name(sheet_name)
        num_r1 = self.change_char_to_num(input_xno)
        sheet.Rows(str(num_r1)).Insert(-4121)

    def insert_xline_by_step(self, sheet_name='', xyxy='', step_no=None):
        """
        영역의 n번째마다 가로열을 추가하는것

        """
        [sheet_name, xyxy, step_no] = self._check_3_param(sheet_name, xyxy, step_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        step_no = int(step_no)
        add_x = 0
        for no in range(1, x2 - x1 + 1):
            x = add_x + no
            if divmod(x, step_no)[1] == step_no - 1:
                num_r1 = self.change_char_to_num(x + x1)
                sheet.Rows(str(num_r1)).Insert(-4121)
                add_x = add_x + 1

    def insert_xline_by_step_with_n_lines(self, sheet_name='', xyxy='', step_no=1, line_no=1):
        """
        n번째마다 m열을 추가

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        step_no = int(step_no)
        add_x = 0
        for no in range(1, x2 - x1 + 1):
            x = add_x + no
            if divmod(x, step_no)[1] == step_no - 1:
                for _ in range(line_no):
                    num_r1 = self.change_char_to_num(x + x1)
                    sheet.Rows(str(num_r1)).Insert(-4121)
                    add_x = add_x + 1

    def insert_xline_for_range_by_step(self, sheet_name='', xyxy='', step_no=None):
        """
        영역의 n번째마다 가로열을 추가하는것

        """
        [sheet_name, xyxy, step_no] = self._check_3_param(sheet_name, xyxy, step_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        step_no = int(step_no)
        add_x = 0
        for no in range(1, x2 - x1 + 1):
            x = add_x + no
            if divmod(x, step_no)[1] == step_no - 1:
                num_r1 = self.change_char_to_num(x + x1)
                sheet.Rows(str(num_r1)).Insert(-4121)
                add_x = add_x + 1

    def insert_xline_for_range_by_step_with_n_lines(self, sheet_name, xyxy, step_no, line_no):
        """
        n번째마다 m열을 추가
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        step_no = int(step_no)
        add_x = 0
        for no in range(1, x2 - x1 + 1):
            x = add_x + no
            if divmod(x, step_no)[1] == step_no - 1:
                for _ in range(line_no):
                    num_r1 = self.change_char_to_num(x + x1)
                    sheet.Rows(str(num_r1)).Insert(-4121)
                    add_x = add_x + 1

    def insert_xline_for_sheet(self, sheet_name, input_xno):
        """
        입력숫자인 가로열의 밑에 한줄삽입하기
        """
        sheet = self.check_sheet_name(sheet_name)
        num_r1 = self.change_char_to_num(input_xno)
        sheet.Rows(str(num_r1)).Insert(-4121)

    def insert_xline_with_n_lines_by_step(self, sheet_name, xyxy, step_no, line_no):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        step_no = int(step_no)
        add_x = 0
        for no in range(1, x2 - x1 + 1):
            x = add_x + no
            if divmod(x, step_no)[1] == step_no - 1:
                for _ in range(line_no):
                    num_r1 = self.change_char_to_num(x + x1)
                    sheet.Rows(str(num_r1)).Insert(-4121)
                    add_x = add_x + 1

    def insert_xline_with_sum_value_for_each_yline(self, sheet_name, input_l2d, xy):
        """
        선택한 영역의 세로자료들을 다 더해서 제일위의 셀에 다시 넣는것
        """

        sheet = self.check_sheet_name(sheet_name)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        x_len = len(input_l2d)
        y_len = len(input_l2d[0])
        for y in range(y_len):
            temp = ""
            for x in range(x_len):
                sheet.Cells(x + xy[0], y + xy[1]).Value = ""
                if input_l2d[x][y]:
                    temp = temp + " " + input_l2d[x][y]
            sheet.Cells(xy[0], y + xy[1]).Value = str(temp).strip()

    def insert_xxline(self, sheet_name, xx_list):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(xx_list, int):
            xx_list = [xx_list, xx_list]
        sheet.Rows(str(xx_list[0]) + ':' + str(xx_list[1])).Insert(-4121)

    def insert_xxline_for_range(self, sheet_name, xx_list):
        """
        가로열을 한줄삽입하기
        """
        sheet = self.check_sheet_name(sheet_name)
        x1, x2 = self.check_xx_address(xx_list)
        sheet.Rows(str(x1) + ':' + str(x2)).Insert()

    def insert_yline(self, sheet_name, input_yno):
        """
        세로행을 한줄삽입하기
        """
        sheet = self.check_sheet_name(sheet_name)
        num_r1 = self.change_num_to_char(input_yno)
        sheet.Columns(num_r1).Insert(-4121)  # xlShiftToLeft = -4121

    def insert_yline_by_line_nos_l2d(self, input_l2d, no_list):
        """
        2차원 리스트의 자료에 원하는 가로줄을 삽입하는 것
        """

        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        no_list = self.check_input_data(no_list)

        no_list.sort()
        no_list.reverse()
        for one in no_list:
            for x in range(len(input_l2d)):
                input_l2d[x].insert(int(one), "")
        return input_l2d

    def insert_yline_by_step(self, sheet_name, xyxy, step_no):
        """
        insert_range_yline_bystep(sheet_name='', xyxy='', step_no)
        n번째마다 열을 추가하는것
        새로운 가로열을 선택한 영역에 1개씩 추가하는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        # 일정부분으로 추가되는것을 앞에서부터 적용
        step_no = int(step_no)
        add_y = 0
        for no in range(0, y2 - y1 + 1):
            y = add_y + no
            if divmod(y, step_no)[1] == step_no - 1:
                num_r1 = self.change_num_to_char(y + y1)
                sheet.Columns(num_r1).Insert(-4121)  # xlShiftToLeft = -4121
                add_y = add_y + 1

    def insert_yline_for_range_by_step(self, sheet_name='', xyxy='', step_no=None):
        """
        insert_range_yline_bystep(sheet_name='', xyxy='', step_no)
        n번째마다 열을 추가하는것
        새로운 가로열을 선택한 영역에 1개씩 추가하는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        # 일정부분으로 추가되는것을 앞에서부터 적용
        step_no = int(step_no)
        add_y = 0
        for no in range(0, y2 - y1 + 1):
            y = add_y + no
            if divmod(y, step_no)[1] == step_no - 1:
                num_r1 = self.change_num_to_char(y + y1)
                sheet.Columns(num_r1).Insert(-4121)  # xlShiftToLeft = -4121
                add_y = add_y + 1

    def insert_ylines_by_line_nos_l2d(self, input_l2d, no_list):
        """
        2차원 리스트의 자료에 원하는 가로줄을 삽입하는 것

        """

        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        no_list = self.check_input_data(no_list)

        no_list.sort()
        no_list.reverse()
        for one in no_list:
            for x in range(len(input_l2d)):
                input_l2d[x].insert(int(one), "")
        return input_l2d

    def insert_yyline(self, sheet_name, yy_list):
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(yy_list, int):
            yy_list = [yy_list]

        if len(yy_list) == 2:
            y1 = yy_list[0]
            y2 = yy_list[1]
        elif len(yy_list) == 1:
            y1 = yy_list[0]
            y2 = yy_list[0]

        char_y1 = self.change_num_to_char(y1)
        char_y2 = self.change_num_to_char(y2)

        sheet.Columns(char_y1 + ':' + char_y2).Insert(-4121)  # xlShiftToLeft = -4121

    def insert_yyline_by_line_nos_l2d(self, input_l2d, no_list):
        """

        """
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        no_list = self.check_input_data(no_list)

        no_list.sort()
        no_list.reverse()
        for one in no_list:
            for x in range(len(input_l2d)):
                input_l2d[x].insert(int(one), "")
        return input_l2d

    def insert_yyline_by_step(self,sheet_name, xyxy, step_no):
        """

        """
        # 일정부분으로 추가되는것을 앞에서부터 적용
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        step_no = int(step_no)
        add_y = 0
        for no in range(0, y2 - y1 + 1):
            y = add_y + no
            if divmod(y, step_no)[1] == step_no - 1:
                num_r1 = self.change_num_to_char(y + y1)
                sheet.Columns(num_r1).Insert(-4121)  # xlShiftToLeft = -4121
                add_y = add_y + 1

    def insert_yyline_for_range(self, sheet_name, yy_list):
        """
        시트에 세로행을 연속된 여러줄 삽입하기

        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(yy_list, list) and len(yy_list) == 1:
            x2 = x1 = self.change_num_to_char(yy_list[0])
        elif isinstance(yy_list, list) and len(yy_list) == 2:
            x1 = self.change_num_to_char(yy_list[0])
            x2 = self.change_num_to_char(yy_list[1])
        else:
            x2 = x1 = self.change_num_to_char(yy_list)
        sheet.Columns(str(x1) + ':' + str(x2)).Insert()

    def interactive_off(self):
        """
        자료가 변경이되면 차트등이 연결되서 실행되는것을 interactive라고 한다
        """
        self.xlapp.Interactive = False

    def interactive_on(self):
        """
        자료가 변경이되면 차트등이 연결되서 실행되는것을 interactive라고 한다
        """
        self.xlapp.Interactive = True

    def is_cell_in_merge(self, sheet_name='', xyxy=''):
        """
        현재 셀이 merge가 된것인지를 알아 내는것

        :return: (bool)
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng = sheet.Cells(x1, y1)

        merge_count = rng.MergeArea.Cells.Count
        result = False
        if merge_count > 1:
            result = True
        return result

    def is_empty_range(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read(sheet_name, xyxy)
        if l2d == None:
            return True
        else:
            for l1d in l2d:
                for value in l1d:
                    if value == "" or value == None:
                        return False
            return True

    def is_empty_sheet(self, sheet_name=''):
        """
        시트가 비었는지를 확인하는 것

        :return: (bool)
        """
        try:
            sheet = self.check_sheet_name(sheet_name)

            # 1. UsedRange 확인
            used_range = sheet.UsedRange

            # UsedRange의 행/열 개수가 1개인지 확인
            if used_range.Rows.Count != 1 or used_range.Columns.Count != 1:
                return False

            # 2. UsedRange 주소 확인 (A1이어야 함)
            xyxy = self.get_address_for_usedrange(sheet_name)
            if xyxy != [1, 1, 1, 1]:
                return False

            # 3. A1 셀의 값 확인
            one_value = sheet.Cells(1, 1).Value

            # None, 빈 문자열, 공백만 있는 경우 모두 빈 것으로 간주
            if one_value is None:
                return True
            elif isinstance(one_value, str) and one_value.strip() == "":
                return True
            else:
                return False

        except Exception as e:
            print(f"✗ is_empty_sheet 오류: {str(e)}")
            return False

    def is_empty_values_for_range(self, sheet_name='', xyxy=''):
        """
        값이 모두 비었을때는 True를 돌려주고 아닌경우는 False를 돌려준다
        여기는 기본으로 ""일때는 usedrange의 주소를 갖고온다

        :return: (bool)
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        if l2d == None:
            return True
        else:
            for l1d in l2d:
                for value in l1d:
                    if value == "" or value == None:
                        return False
            return True

    def is_empty_xline(self, sheet_name='', input_xno=None):
        """
        열전체가 빈 것인지 확인해서 돌려준다
        현재의 기능은 한줄만 가능하도록 하였다
        다음엔 영역이 가능하도록 하여야 겠다

        :return: (bool)
        """
        sheet = self.check_sheet_name(sheet_name)
        result = self.xlapp.WorksheetFunction.CountA(sheet.Rows(input_xno).EntireRow)
        return result

    def is_empty_yline(self, sheet_name, input_yno=None):
        """
        입력한 세로 한줄이 전체가 비어있는지 확인하는 것

        :return: (bool)
        """
        sheet = self.check_sheet_name(sheet_name)
        y1 = self.change_char_to_num(input_yno)
        result = self.xlbook.WorksheetFunction.CountA(sheet.Columns(y1).EntireColumn)
        return result

    def is_file_in_folder(self, path="D:\\test", filename="save_file.py"):
        """
        폴더안에 파일이 있는지 확인하는 것

        :return: (bool)
        """
        result = ""
        if path == "":
            path = "C:/Users/Administrator/Documents"
        filenames = self.xyutil.get_all_filename_in_folder(path)

        if filename in filenames:
            result = True
        return result

    def is_match_with_xre_for_input_value(self, input_xre, input_value=None):
        """
        입력값이 input_xre의 정규표현식의 내용이 들어가 있는지 확인하는 것

        :return: (bool)
        """
        # resql = self.xyre.change_xsql_to_resql(input_xre)
        result = self.xyre.search_all_by_xsql(input_xre, input_value)
        if result == []:
            output_text = False
        else:
            output_text = True
        return output_text

    def is_merged_cell(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        merge_count = rng.MergeArea.Cells.Count
        result = False
        if merge_count > 1:
            result = True
        return result

    def is_range_name(self, range_name):
        """
        입력으로 들어온 이름역역이 있는지 확인하는 것

        """
        all_rng_name = self.get_range_names()
        result = False
        if not all_rng_name:
            result = False
        else:
            if range_name in all_rng_name:
                result = True
        return result

    def is_sheet_name(self, sheet_name=''):
        """
        입력받은 시트의 이름이 현재 워크북의 이름중하나인지 확인해 보는것
        :return: (bool)
        """
        result = False
        sheets_name = self.get_all_sheet_name()
        if sheet_name in sheets_name:
            result = True
        return result

    def is_uniform_2d(self, input_l2d):
        # 데이터가 비어있는 경우 처리
        if not input_l2d:
            return True

        # 각 행의 길이를 집합으로 만듦
        lengths = {len(row) for row in input_l2d}

        # 집합에 길이가 하나만 존재하면 모두 같은 크기
        return len(lengths) <= 1

    def lock_sheet_with_password(self, sheet_name=''):
        """
        암호걸기

        """

        source_letter = "1234567890"
        repeat_no = 4
        count = 0
        for a in itertools.product(source_letter, repeat=repeat_no):
            count += 1
            temp_pwd = ("".os.path.join(map(str, a)))
            try:
                self.set_sheet_lock_off(sheet_name, temp_pwd)
            except:
                pass
            else:
                break

    def make_dic_for_input_value_for_each_word_as_count_vs_word(self, input_value=None):
        """
        입력으로 들어온 텍스트를 공백으로 분리해서, 단어의 형태로 만들어서
        각 단어들의 갯수를 사전형식으로 만드는 것

        """
        input_value = input_value.replace(" ", "")
        input_value = input_value.upper()
        result = {}
        for one_letter in input_value:
            if one_letter in list(result.keys()):
                result[one_letter] = result[one_letter] + 1
            else:
                result[one_letter] = 1
        return result

    def make_dict_by_first_value(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = {}
        l2d = self.read(sheet_name, xyxy)
        l2d = self.xyutil.change_tuple_2d_to_l2d(l2d)

        l2d_changed = self.xyutil.delete_empty_xline_in_l2d(l2d)
        for l1d in l2d_changed:
            result[l1d[0]] = list(l1d)
        return result

    def make_dict_for_range_by_first_value(self, sheet_name='', xyxy=''):
        """
        맨앞의 글자를 키로 사용해서, 2차원자료를 사전형식으로 만드는 것
        퀴즈같은 문제를 만들때, 속도도 빠르게 하면서, 사용했던것을 다시 안물러 오도록 하는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = {}
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        l2d = self.xyutil.change_tuple_2d_to_l2d(l2d)

        l2d_changed = self.xyutil.delete_empty_xline_in_l2d(l2d)
        for l1d in l2d_changed:
            result[l1d[0]] = list(l1d)
        return result

    def make_l2d_data(self, sheet_name='', xyxy=''):
        """
        현재 선택된 자료들을 리스트형태로 만드는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read_range()
        self.new_sheet()
        self.write_value_for_cell("", [1, 1], "[")
        for ix, l1d in enumerate(l2d[:-1]):
            self.write_value_for_cell("", [ix + 2, 1], str(l1d) + ",")
        self.write_value_for_cell("", [len(l2d) + 1, 1], str(l2d[-1]) + ",")
        self.write_value_for_cell("", [len(l2d) + 2, 1], "]")

    def make_line_for_splitted_data(self, xyxy, union_char="#"):
        """
        앞에 숫자를 기준으로 옆줄의 자료를 합치는것
        맨앞의 자료 1줄만 합친다

        """
        sheet = self.check_sheet_name("")
        temp = ""
        old_x = xyxy[0]
        for x in range(xyxy[0], xyxy[2] + 1):
            gijun_data = self.read_value_for_cell("", [x, xyxy[1]])
            value = self.read_value_for_cell("", [x, xyxy[1] + 1])

            if gijun_data:
                sheet.Cells(old_x, xyxy[1] + 2).Value = temp[:-len(union_char)]
                temp = value + union_char
                old_x = x
            else:
                temp = temp + value + union_char
        sheet.Cells(old_x, xyxy[1] + 2).Value = temp[:-len(union_char)]

    def make_many_excel_file_group_for_range_for_yline_value(self, sheet_name, xyxy, base_yline_no=3, filename="D:\\__test\\save_file_"):
        """
        어떤 시트의 특정영역의 자료중에서 n번째 열을 기준으로 같은것끼리 정렬을 해서
        각 그룹별로 새로운 파일을 만들어서 저장하는것
        단, 아래의 코드에는 서식을 함께 사용하기위해서 서식복사를 넣었다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        l2d_group = self.xyutil.group_l2d_by_index(l2d, base_yline_no - 1)
        no = 0
        for index in range(len(l2d_group[1:])):
            self.copy_range(sheet_name, [x1, y1, x2, y2])
            # 한번 붙여넣기를 하면 없어져서, 계속 해야한다
            no = no + 1
            xl2 = xy_excel("new")
            xl2.paste_range_format_only("", [1, 1])
            xl2.write_l1d_from_cell("", [1, 1], l2d[0])
            xl2.write_l2d_from_cell("", [1, 1], l2d_group[index + 1])
            xl2.save(filename + str(no) + ".xlsx")
            xl2.close()

    def make_many_excel_file_group_for_yline_value(self, sheet_name, xyxy, base_yline_no=3, filename="D:\\__test\\save_file_"):
        """
        어떤 시트의 특정영역의 자료중에서 n번째 열을 기준으로 같은것끼리 정렬을 해서
        각 그룹별로 새로운 파일을 만들어서 저장하는것
        단, 아래의 코드에는 서식을 함께 사용하기위해서 서식복사를 넣었다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        l2d_group = self.xyutil.group_l2d_by_index(l2d, base_yline_no - 1)
        no = 0
        for index in range(len(l2d_group[1:])):
            self.copy_range(sheet_name, [x1, y1, x2, y2])
            # 한번 붙여넣기를 하면 없어져서, 계속 해야한다
            no = no + 1
            xl2 = xy_excel("new")
            xl2.paste_format_only("", [1, 1])
            xl2.write_l1d("", [1, 1], l2d[0])
            xl2.write_l2d("", [1, 1], l2d_group[index + 1])
            xl2.save(filename + str(no) + ".xlsx")
            xl2.close()

    def make_one_text_for_range_with_chain_char(self, sheet_name, xyxy, chain_char="tab"):
        """
        엑셀의 영역을 각 값들을 어떤 문자로 다 연결해서, 하나의 텍스트로 바꿔주는 것
        기본으로 탭으로 연결해서 만들어 준다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        result = self.xyutil.change_l2d_to_text_with_chain_word(l2d, chain_char)
        return result

    def make_one_text_with_chain_char(self, sheet_name, xyxy, chain_char="tab"):
        """
        엑셀의 영역을 각 값들을 어떤 문자로 다 연결해서, 하나의 텍스트로 바꿔주는 것
        기본으로 탭으로 연결해서 만들어 준다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        result = self.xyutil.change_l2d_to_text_with_chain_word(l2d, chain_char)
        return result

    def make_ppt_table_from_xl_data(self):
        """
        엑셀의 테이블 자료가 잘 복사가 않되는것 같아서, 아예 하나를 만들어 보았다
        엑셀의 선택한 영역의 테이블 자료를 자동으로 파워포인트의 테이블 형식으로 만드는 것이다

        """

        activesheet_name = self.get_activesheet_name()
        [x1, y1, x2, y2] = self.get_address_for_selection()

        Application = win32com.client.Dispatch("Powerpoint.Application")
        Application.Visible = True
        active_ppt = Application.Activepresentation
        slide_no = active_ppt.Slides.Count + 1

        new_slide = active_ppt.Slides.Add(slide_no, 12)
        new_table = active_ppt.Slides(slide_no).Shapes.AddTable(x2 - x1 + 1, y2 - y1 + 1)
        shape_no = active_ppt.Slides(slide_no).Shapes.Count

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            value = self.read_value_for_cell(activesheet_name, [x, y])
            active_ppt.Slides(slide_no).Shapes(shape_no).Table.Cell(x - x1 + 1,
                                                                    y - y1 + 1).Shape.TextFrame.TextRange.Text = value

    def make_ppt_table_from_xl_data_ver2(self):
        """
        엑셀의 테이블 자료가 잘 복사가 않되는것 같아서, 아예 하나를 만들어 보았다
        엑셀의 선택한 영역의 테이블 자료를 자동으로 파워포인트의 테이블 형식으로 만드는 것이다

        """
        activesheet_name = self.get_activesheet_name()
        [x1, y1, x2, y2] = self.get_address_for_selection()

        Application = win32com.client.Dispatch("Powerpoint.Application")
        Application.Visible = True
        active_ppt = Application.Activepresentation
        slide_no = active_ppt.Slides.Count + 1

        new_slide = active_ppt.Slides.Add(slide_no, 12)
        new_table = active_ppt.Slides(slide_no).Shapes.AddTable(x2 - x1 + 1, y2 - y1 + 1)
        shape_no = active_ppt.Slides(slide_no).Shapes.Count

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            value = self.read_value_for_cell(activesheet_name, [x, y])
            active_ppt.Slides(slide_no).Shapes(shape_no).Table.Cell(x - x1 + 1,
                                                                    y - y1 + 1).Shape.TextFrame.TextRange.Text = value

    def make_print_page(self, sheet_name, input_l2d, line_list, start_xy, size_xy, y_line=2, position=3):
        """
        input_l2d, 2차원의 기본자료들
        2차원의 자료에서 출력하는 자료들만 순서대로 골라서 새로 만드는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        changed_input_l2d = self.get_ylines_at_l2d(input_l2d, line_list)  # 1
        new_start_x = start_xy[0]
        new_start_y = start_xy[1]
        for index, l1d in enumerate(changed_input_l2d):
            mok, namuji = divmod(index, y_line)
            new_start_x = new_start_x + mok * size_xy[0]
            new_start_y = new_start_y + namuji * size_xy[1]
            for index_2, one_value in enumerate(l1d):
                sheet.Cell(position[index_2][0], position[index_2][1]).Value = l1d[index_2]

    def make_range(self, sheet_name='', xyxy=''):
        """
        range객체를 만들기 위한것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return rng.Address

    def make_unique_id(self, xyxy, start_no=None):
        """
        자리수에 맞는 고유한번호 만들기 (_로 그냥 만들자)
        연속된 같은값일때만, 같은 숫자를 쓴다
        다른곳에 부분적으로 같은 이름이 있을수있다

        """
        l2d = self.read_value_for_range("", xyxy)
        result = []
        x_line_no = len(l2d)
        y_line_no = len(l2d[0])
        change_start_no = start_no

        for y in range(y_line_no):
            new_no = []
            for x in range(x_line_no):
                # 값이 없으면, None값으로 넣는다
                if l2d[x][y] == "" or l2d[x][y] == None:
                    new_no.append("")
                else:
                    if x == 0:
                        new_no = [change_start_no, ]
                    else:
                        if l2d[x][y] == l2d[x - 1][y]:
                            new_no.append(change_start_no)
                        else:
                            change_start_no = change_start_no + 1
                            new_no.append(change_start_no)
            result.append(new_no)
            change_start_no = start_no  # 이부분을 없애면, 고유한 번호들이 할당된다

        for no, l1d in enumerate(result):
            id1 = ""
            for one in l1d:
                id1 = id1 + str(one) + "_"
            result[no].append(id1[:-1])

        return result

    def make_xy_list_for_box_style(self, xyxy=''):
        """
        좌표를 주면, 맨끝만 나터내는 좌표를 얻는다

        """
        temp_1 = []
        for x in [xyxy[0], xyxy[2]]:
            temp = [[x, y] for y in range(xyxy[1], xyxy[3] + 1)]
            temp_1.append(temp)

        temp_2 = []
        for y in [xyxy[1], xyxy[3]]:
            temp = [[x, y] for y in range(xyxy[0], xyxy[2] + 1)]
            temp_2.append(temp)

        result = [temp_1[0], temp_2[1], temp_1[1], temp_2[0]]
        return result

    def merge_by_each_xline(self, sheet_name='', xyxy=''):
        """
        가끔은 여러줄의 x라인을 각각 병합을 하고싶은때가 있다.
        그럴때 사용하기위한 목적이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.xlapp.DisplayAlerts = False

        for no in range(x1, x2 + 1):
            l2d = self.read_value("", [no, y1, no, y2])
            for one_value in l2d[0]:
                if one_value:
                    temp_text = temp_text + str(one_value) + " "
            self.merge_range(sheet_name, [no, y1, no, y2])
            sheet.Cells(no, y1).Value = temp_text

        self.xlapp.DisplayAlerts = True

    def merge_each_xline(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.xlapp.DisplayAlerts = False
        for no in range(x1, x2 + 1):
            l2d = self.read_value_for_range("", [no, y1, no, y2])
            for one_value in l2d[0]:
                if one_value:
                    temp_text = temp_text + str(one_value) + " "

            self.merge_range(sheet_name, [no, y1, no, y2])
            sheet.Cells(no, y1).Value = temp_text

        self.xlapp.DisplayAlerts = True

    def merge_extend_for_xline(self, sheet_name='', xyxy=''):
        """
        선택영역의 각 x라인을 병합하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        x1, y1, x2, y2 = self.get_address_for_selection()
        for x in range(x1, x2 + 1):
            self.merge_range("", [x, y1, x, y2])

    def merge_for_range_by_each_xline(self, sheet_name='', xyxy=''):
        """
        가끔은 여러줄의 x라인을 각각 병합을 하고싶은때가 있다.
        그럴때 사용하기위한 목적이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.xlapp.DisplayAlerts = False

        for no in range(x1, x2 + 1):
            l2d = self.read_value_for_range("", [no, y1, no, y2])
            for one_value in l2d[0]:
                if one_value:
                    temp_text = temp_text + str(one_value) + " "
            self.merge_range(sheet_name, [no, y1, no, y2])
            sheet.Cells(no, y1).Value = temp_text

        self.xlapp.DisplayAlerts = True

    def merge_for_range_top_2_xlines(self, sheet_name='', xyxy=''):
        """
        선택 영역중 바로 위의것과 아랫것만 병합하는것
        제일위의 2줄만 세로씩 병합하는 것이다
        가로줄 갯수만큰 병합하는것
        위와 아래에 값이 있으면 알람이 뜰것이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        if y1 == y2:
            pass
        else:
            for y in range(y1, y2 + 1):
                sheet.Range(sheet.Cells(x1, y), sheet.Cells(x1 + 1, y)).Merge(0)

    def merge_for_range_with_same_uppercell(self, sheet_name='', xyxy=''):
        """
        값이 같으면 병합을 시키는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        self.xlapp.DisplayAlerts = False
        for y in range(y1, y2 + 1):
            old_value = False
            same_no = 0
            for x in range(x1, x2 + 1):
                one_value = ""
                sheet.Cells(x, y).Value
                if old_value == one_value:
                    same_no = same_no + 1
                    self.delete_value_for_cell(sheet_name, [x, y])
                else:
                    if same_no >= 1:
                        self.merge_range(sheet_name, [x - same_no - 1, y, x - 1, y])
                        old_value = one_value
                        same_no = 0

    def merge_left_2_yline(self, sheet_name='', xyxy=''):
        """
        선택 영역중 바로 위의것과 아랫것만 병합하는것
        왼쪽의 2줄을 병합하는 것이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        if x1 == x2:
            pass
        else:
            for x in range(x1, x2 + 1):
                sheet.Range(sheet.Cells(x, y1), sheet.Cells(x, y1 + 1)).Merge(0)

    def merge_left_2_ylines(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        if x1 == x2:
            pass
        else:
            for x in range(x1, x2 + 1):
                sheet.Range(sheet.Cells(x, y1), sheet.Cells(x, y1 + 1)).Merge(0)

    def merge_left_2_ylines_for_range(self, sheet_name='', xyxy=''):
        """
        선택 영역중 바로 위의것과 아랫것만 병합하는것
        왼쪽의 2줄을 병합하는 것이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        if x1 == x2:
            pass
        else:
            for x in range(x1, x2 + 1):
                sheet.Range(sheet.Cells(x, y1), sheet.Cells(x, y1 + 1)).Merge(0)

    def merge_range(self, sheet_name='', xyxy=''):
        """
        셀들을 병합하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Merge(0)

    def merge_selection(self, sheet_name='', xyxy=''):
        """
        셀들을 병합하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng = self.xlapp.Selection
        rng.Merge(0)

    def merge_top_2_xline(self, sheet_name='', xyxy=''):
        """
        선택 영역중 바로 위의것과 아랫것만 병합하는것
        제일위의 2줄만 세로씩 병합하는 것이다
        가로줄 갯수만큰 병합하는것
        위와 아래에 값이 있으면 알람이 뜰것이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        if y1 == y2:
            pass
        else:
            for y in range(y1, y2 + 1):
                sheet.Range(sheet.Cells(x1, y), sheet.Cells(x1 + 1, y)).Merge(0)

    def merge_two_l2d_having_title(self, input_l2d_1, input_l2d_2):
        """
        2개의 2차원자료를 제목줄을 기준으로 한치는것

        """
        merged_data = [row[:] for row in input_l2d_1]
        header1 = merged_data[0]
        header2 = input_l2d_2[0]
        body2 = input_l2d_2[1:]
        col_mapping = {}
        new_col_indices = []

        for i, h2 in enumerate(header2):
            h2_val = "" if h2 is None else h2
            found_index = -1
            if h2_val != "":
                for j, h1 in enumerate(header1):
                    h1_val = "" if h1 is None else h1
                    if h1_val == h2_val:
                        found_index = j
                        break
            if found_index != -1:
                col_mapping[i] = found_index
            else:
                new_col_indices.append(i)

        for idx in new_col_indices:
            merged_data[0].append(header2[idx])
            for row_idx in range(1, len(merged_data)):
                merged_data[row_idx].append("")
            col_mapping[idx] = len(merged_data[0])
        total_cols = len(merged_data[0])

        for row in body2:
            new_row = [""] * total_cols

            for col_idx, value in enumerate(row):
                if col_idx in col_mapping:
                    target_idx = col_mapping[col_idx]
                    new_row[target_idx] = value
                    merged_data.append(new_row)
        return merged_data

    def merge_with_same_uppercell(self, sheet_name='', xyxy=''):
        """
        값이 같으면 병합을 시키는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        self.xlapp.DisplayAlerts = False
        for y in range(y1, y2 + 1):
            old_value = False
            same_no = 0
            for x in range(x1, x2 + 1):
                one_value = sheet.Cells(x, y).Value
                if old_value == one_value:
                    same_no = same_no + 1
                    self.delete_value_for_cell(sheet_name, [x, y])
                else:
                    if same_no >= 1:
                        self.merge_range(sheet_name, [x - same_no - 1, y, x - 1, y])
                        old_value = one_value
                        same_no = 0

    def messagebox(self, input_value):
        """

        """
        win32gui.MessageBox(0, input_value, input_value, 0)

    def move_activecell_to_bottom_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 위치에서 제일왼쪽, 제일아래로 이동
        xlDown: - 4121,xlToLeft : - 4159, xlToRight: - 4161, xlUp : - 4162

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4121).Select()

    def move_cell(self, sheet1, xy_from, sheet2, xy_to):
        """
        1 개의 셀만 이동시키는 것. 다른 시트로 이동도 가능

        """

        sheet_1 = self.check_sheet_name(sheet1)
        sheet_2 = self.check_sheet_name(sheet2)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xy_from)
        sheet_1.Cells(x1, y1).Cut()
        self.change_address_to_xyxy(xy_to)
        rng = sheet_2.Cells(x1, y1)
        sheet_2.Paste(rng)

    def move_cell_value_to_another_sheet(self, sheet_list, xy_list):
        """
        다른시트로 값1개 옮기기

        """

        sheet_list = self.check_input_data(sheet_list)
        xy_list = self.check_input_data(xy_list)

        sheet_1 = self.check_sheet_name(sheet_list[0])
        x1, y1 = xy_list[0]
        sheet_1.Cells(x1, y1).Cut()

        sheet_2 = self.check_sheet_name(sheet_list[1])
        x2, y2 = xy_list[1]
        sheet_2.Cells(x2, y2).Insert()

    def move_each_xline_data_as_like_label_print_style_at_new_sheet(self, xyxy, repeat_no, start_xy):
        """
        x라인의 가로 한줄의 자료를 여반복갯수에 따라서 시작점에서부터 아래로 복사하는것
        입력자료 : 1줄의 영역, 반복하는 갯수, 자료가 옮겨갈 시작주소

        """
        sheet = self.check_sheet_name("")
        all_data_set = self.read_value_for_range("", xyxy)
        for no in range(len(all_data_set[0])):
            mok, namuji = divmod(no, repeat_no)
            new_x = mok + start_xy[0]
            new_y = namuji + start_xy[1]
            sheet.Cells(new_x, new_y).Value = all_data_set[0][no]

    def move_each_yline_data_as_like_label_print_style_at_new_sheet(self, xyxy, repeat_no, start_xy):
        """
        y라인의 가로 한줄의 자료를 여반복갯수에 따라서 시작점에서부터 아래로 복사하는것

        """
        sheet = self.check_sheet_name("")
        all_data_set = self.read_value_for_range("", xyxy)
        for no in range(len(all_data_set)):
            mok, namuji = divmod(no, repeat_no)
            new_x = mok + start_xy[0]
            new_y = namuji + start_xy[1]
            sheet.Cells(new_x, new_y).Value = all_data_set[no][0]

    def move_line_obj(self, line_obj):
        """
        선객체를 다른곳으로 옮기는 것

        """
        line_obj.Select()
        # self.selection.ShapeRange.ScaleWidth(Factor, RelativeToOriginalSize, Scale)
        self.xlapp.Selection.ShapeRange.ScaleWidth(1, 0, 0)
        self.xlapp.Selection.ShapeRange.ScaleHeight(-1.3, 0, 0)

    def move_line_obj_for_width_n_height(self, line_obj, width_float=12.3, height_float=8.8):
        """
        선객체의 넓이와 높이를 바꾸는 것

        """
        line_obj.ShapeRange.ScaleWidth = width_float
        line_obj.ShapeRange.ScaleHeight = height_float

    def move_position_in_selection(self, sheet_name, xyxy, insert_step=2, insert_no=1, range_ext=False, del_or_ins="ins"):
        """
        선택영역의 가로열을 몇개씩 추가하거나 삭제하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        data_2d = rng.Value
        changed_data_2d = []
        for l1d in data_2d:
            temp = [one for one in l1d]
            changed_data_2d.append(temp)

        empty_1d = ["" for _ in changed_data_2d[0]]
        actual_position = 0

        if del_or_ins == "ins":
            for no in range(len(changed_data_2d)):
                mok = (no + 1) % insert_step
                if mok == 0:
                    for no_1 in range(insert_no):
                        changed_data_2d.insert(actual_position, empty_1d)
                        actual_position = actual_position + 1
                actual_position = actual_position + 1
        self.write_value_for_range(sheet_name, xyxy, changed_data_2d)

    def move_range(self, sheet_name, range_from, range_to, shift_direction='down'):
        """
        특정 영역(Block)을 다른 위치로 이동시킵니다.

        """
        sheet = self.check_sheet_name(sheet_name)

        # 엑셀 상수 설정
        xlShiftDown = -4121
        xlShiftToRight = -4161
        shift_val = xlShiftDown if shift_direction == 'down' else xlShiftToRight

        # 1. 소스 영역(from) 설정
        if isinstance(range_from, list):
            # [시작행, 시작열, 끝행, 끝열]
            s_row, s_col, e_row, e_col = range_from
            source_range = sheet.Range(
                sheet.Cells(s_row, s_col),
                sheet.Cells(e_row, e_col)
            )
        else:
            # "A1:C5" 형태의 문자열
            source_range = sheet.Range(range_from)

        # 2. 대상 위치(to) 설정
        if isinstance(range_to, list):
            # [행, 열]
            d_row, d_col = range_to
            dest_cell = sheet.Cells(d_row, d_col)
        else:
            # "E10" 형태의 문자열
            dest_cell = sheet.Range(range_to)

        # 3. 이동 실행 (Cut & Insert)
        source_range.Cut()
        dest_cell.Insert(Shift=shift_val)

        # 잘라내기 모드 해제
        sheet.Application.CutCopyMode = False

    def move_range_for_sheet(self, sheet_name1, xyxy1, sheet_name2, xyxy2):
        """
        모든값을 그대로 이동시키는 것
        cut -> paste

        """

        sheet_old = self.check_sheet_name(sheet_name1)
        sheet_new = self.check_sheet_name(sheet_name2)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy1)
        rng1 = sheet_old.Range(sheet_old.Cells(x1, y1), sheet_old.Cells(x2, y2))
        rng1.Cut()
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy2)
        rng2 = sheet_new.Range(sheet_new.Cells(x1, y1), sheet_new.Cells(x2, y2))
        sheet_new.Paste(rng2)

    def move_range_to_another_sheet(self, sheet_name1, xyxy1, sheet_name2, xyxy2):
        """
        모든값을 그대로 이동시키는 것
        cut -> paste

        """

        sheet_old = self.check_sheet_name(sheet_name1)
        sheet_new = self.check_sheet_name(sheet_name2)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy1)
        rng1 = sheet_old.Range(sheet_old.Cells(x1, y1), sheet_old.Cells(x2, y2))
        rng1.Cut()
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy2)
        rng2 = sheet_new.Range(sheet_new.Cells(x1, y1), sheet_new.Cells(x2, y2))
        sheet_new.Paste(rng2)

    def move_range_ystep(self, sheet_name, xyxy, input_yno, step_no):
        """
        가로의 자료를 설정한 갯수만큼 한줄로 오른쪽으로 이동

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        new_x = 0
        new_y = input_yno
        for x in range(xyxy[0], xyxy[2] + 1):
            for y in range(xyxy[1], xyxy[3] + 1):
                new_x = new_x + 1
                value = sheet.Cells(x, y).Value
                if value == None:
                    value = ""
                sheet.Cells(new_x, new_y).Value = value

    def move_rangevalue_line_value(self, sheet_name='', xyxy=''):
        """
        선택한영역의 자료를 세로의 한줄로 만드는것
        새로운 세로행을 만든후 그곳에 두열을 서로 하나씩 포개어서 값넣기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        output_list = self.read_value_for_range(sheet_name, xyxy)
        make_one_list = self.xyutil.change_l2d_to_l1d(output_list)
        self.insert_yyline_for_range(sheet_name, y2 + 1)
        self.write_l1d_from_cell_as_yline(sheet_name, [x1, y2 + 1], make_one_list)

    def move_selection_to_bottom_in_range(self, sheet_name='', xyxy=''):
        """
        선택한 위치에서 제일왼쪽, 제일아래로 이동
        xlDown: - 4121,xlToLeft : - 4159, xlToRight: - 4161, xlUp : - 4162

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4121).Select()

    def move_shape(self, sheet_name, shape_obj, top=20, left=30):
        """
        도형 이동하기

        """
        sheet = self.check_sheet_name(sheet_name)
        shape_obj = sheet.Shapes(shape_obj)
        shape_obj.Top = shape_obj.Top + top
        shape_obj.Left = shape_obj.Left + left

    def move_shape_by_xywh(self, shape_obj, input_xywh):
        """
        도형을 이동시키는 것
        현재위치에서 input_xywh (왼쪽위, 왼쪽, 넓이, 높이)픽셀 값을 기준으로 만드는 것 :

        """
        shape_obj.Top = input_xywh[0]
        shape_obj.Left = input_xywh[1]
        shape_obj.Width = input_xywh[2]
        shape_obj.Height = input_xywh[3]

    def move_shape_position(self, sheet_name, shape_no=3, top=10, left=30):
        """
        도형을 이동 시키는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Shapes(shape_no).Top = top
        sheet.Shapes(shape_no).Left = left

    def move_shape_position_by_dxy(self, sheet_name, shape_no, dxy):
        """
        도형을 이동시키는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        shape_name = self.get_shape_name_by_no(sheet_name, shape_no)
        sheet.Shapes(shape_name).IncrementLeft(dxy[1])
        sheet.Shapes(shape_name).IncrementTop(dxy[0])

    def move_sheet_by_no(self, sheet_name, input_no):
        """
        시트를 제일 앞으로 이동시키는 방법
        """
        self.xlbook.Worksheets(sheet_name).Move(None, After=self.xlbook.Worksheets(input_no))

    def move_sheet_position_by_no(self, sheet_name, input_no=None):
        """
        선택된 시트를 앞에서 몇번째로 이동시키는 것

        """
        sheet = self.check_sheet_name(sheet_name)

        all_shhet_names = self.get_all_sheet_name()
        current_sheet_no = 0
        for index, value in enumerate(all_shhet_names):
            if sheet_name == value:
                current_sheet_no = index + 1
                break

        if input_no <= current_sheet_no:
            move_to = input_no
        else:
            move_to = input_no + 1

        sheet.Move(Before=self.xlbook.Worksheets(move_to))

    def move_sheet_to_end(self, sheet_name=''):
        """
        시트를 제일 앞으로 이동시키는 방법
        """
        self.xlbook.Worksheets(sheet_name).Move(None, After=self.xlbook.Worksheets(self.xlbook.Worksheets.Count))

    def move_sheet_to_first(self, sheet_name=''):
        """

        """
        self.xlbook.Worksheets(sheet_name).Move(None, After=self.xlbook.Worksheets(1))

    def move_sheet_with_new_file(self, sheet_name=''):
        """
        시트를 제일 앞으로 이동시키는 방법

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Move(After=self.xlbook.Worksheets(1))

    def move_sheets_to_another_workbook(self, son_xl, mother_xl):
        """
        모든 엑셀시트를 다른곳으로 이동
        엑셀 애플리케이션 시작

        """
        sheets_name = son_xl.get_all_sheet_name()
        for sheet_name1 in sheets_name:
            sheet = son_xl.check_sheet_name(sheet_name1)
            sheet.Copy(Before=mother_xl.xlbook.Worksheets[1])

    def move_value_for_range_to_left_except_emptycell(self, sheet_name='', xyxy=''):
        """
        x열을 기준으로 값이 없는것은 왼쪽으로 옮기기
        전체영역의 값을 읽어오고, 하나씩 다시 쓴다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        self.delete_value_for_range(sheet_name, xyxy)
        for x in range(0, x2 - x1 + 1):
            new_y = 0
            for y in range(0, y2 - y1 + 1):
                value = l2d[x][y]
                if value == "" or value == None:
                    pass
                else:
                    sheet.Cells(x + x1, new_y + y1).Value = value
                    new_y = new_y + 1

    def move_value_if_startwith_input_value_after_insert_new_line(self, sheet_name, xyxy, startwith="*"):
        """
        맨앞부분에 세로줄을 하나 만든후
        입력값으로받은 글자와 각 셀의 앞부분부터 같은 값일경우 한줄 앞으로 값을 이동시키는 것

        가끔 많은 자료를 구분하는 경우가 필요해서 만든 것이다
        맨앞에 특정글자가 있으면, 앞으로 옮기기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.insert_yline("", y1)
        for one_x in range(x1, x2):
            one_value = self.read_value_for_cell("", [one_x, y1 + 1])
            if one_value.startswith(startwith):
                sheet.Cells(one_x, y1).Value = one_value
                sheet.Cells(one_x, y1 + 1).Value = None

    def move_value_of_range_to_another_sheet(self, sheet_name1, xyxy1, sheet_name2, xyxy2):
        """
        모든값을 그대로 이동시키는 것
        cut -> paste

        """
        sheet_old = self.check_sheet_name(sheet_name1)
        sheet_new = self.check_sheet_name(sheet_name2)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy1)
        rng1 = sheet_old.Range(sheet_old.Cells(x1, y1),
                                         sheet_old.Cells(x2, y2))
        rng1.Cut()
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy2)
        rng2 = sheet_new.Range(sheet_new.Cells(x1, y1),
                                         sheet_new.Cells(x2, y2))
        sheet_new.Paste(rng2)

    def move_value_to_another_sheet(self, sheet_name1, xyxy1, sheet_name2, xyxy2):
        """

        """
        sheet_old = self.check_sheet_name(sheet_name1)
        sheet_new = self.check_sheet_name(sheet_name2)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy1)
        rng1 = sheet_old.Range(sheet_old.Cells(x1, y1),
                                         sheet_old.Cells(x2, y2))
        rng1.Cut()
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy2)
        rng2 = sheet_new.Range(sheet_new.Cells(x1, y1),
                                         sheet_new.Cells(x2, y2))
        sheet_new.Paste(rng2)

    def move_value_to_front_when_char_start_as_input_value(self, input_value="abc"):
        """
        새로운 세로줄을 넣은후
        셀의 값중에 입력으로 들어간 글자가 맨앞부분에 있으면, 한칸 앞으로 옮기기

        """
        sheet = self.check_sheet_name("")
        x, y, x2, y2 = self.get_address_for_selection()
        self.insert_yline("", y)
        for one_x in range(x, x2):
            one_value = self.read_value_for_cell("", [one_x, y + 1])
            if one_value.startswith(input_value):
                sheet.Cells(one_x, y).Value = one_value
                sheet.Cells(one_x, y + 1).Value = None

    def move_value_to_left_except_emptycell(self, sheet_name='', xyxy=''):
        """
        x열을 기준으로 값이 없는것은 왼쪽으로 옮기기
        전체영역의 값을 읽어오고, 하나씩 다시 쓴다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        self.delete_value(sheet_name, xyxy)
        for x in range(0, x2 - x1 + 1):
            new_y = 0
            for y in range(0, y2 - y1 + 1):
                value = l2d[x][y]
                if value == "" or value == None:
                    pass
                else:
                    sheet.Cells(x + x1, new_y + y1).Value = value
                    new_y = new_y + 1

    def move_value_to_left_except_emptycell_for_range(self, sheet_name='', xyxy=''):
        """
        x열을 기준으로 값이 없는것은 왼쪽으로 옮기기
        전체영역의 값을 읽어오고, 하나씩 다시 쓴다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        self.delete_value_for_range(sheet_name, xyxy)
        for x in range(0, x2 - x1 + 1):
            new_y = 0
            for y in range(0, y2 - y1 + 1):
                value = l2d[x][y]
                if value == "" or value == None:
                    pass
                else:
                    sheet.Cells(x + x1, new_y + y1).Value = value
                    new_y = new_y + 1

    def move_xline(self,sheet_name, xxline1, xline2):
        """
        선택한 가로줄(행)들을 특정 위치로 잘라내어 삽입(이동)합니다.

        """
        sheet = self.check_sheet_name(sheet_name)
        [start, end] = self.check_start_n_end_address_for_range(xxline1)
        dest = self.check_one_data_for_range(xline2)

        target_range = sheet.Range(sheet.Rows(start), sheet.Rows(end))
        target_range.Cut()

        dest_range = sheet.Rows(dest)
        dest_range.Insert(Shift=-4121)
        sheet.Application.CutCopyMode = False

    def move_xxline_to_another_sheet(self, sheet_name1, sheet_name2, xx_list0, xx_list1):
        """
        세로의 값을 이동시킵니다

        """
        sheet1 = self.check_sheet_name(sheet_name1)
        sheet2 = self.check_sheet_name(sheet_name2)
        xx_list0_1, xx_list0_2 = self.check_xy_address(xx_list0)
        xx_list1_1, xx_list1_2 = self.check_xy_address(xx_list1)
        xx_list0_1 = self.change_char_to_num(xx_list0_1)
        xx_list0_2 = self.change_char_to_num(xx_list0_2)
        xx_list1_1 = self.change_char_to_num(xx_list1_1)
        xx_list1_2 = self.change_char_to_num(xx_list1_2)
        sheet1.Select()
        sheet1.Rows(str(xx_list0_1) + ':' + str(xx_list0_2)).Select()
        sheet1.Rows(str(xx_list0_1) + ':' + str(xx_list0_2)).Copy()
        sheet2.Select()
        sheet2.Rows(str(xx_list1_1) + ':' + str(xx_list1_2)).Select()
        sheet2.Paste()

    def move_yline(self, sheet_name, yyline1, yline2):
        """
        선택한 세로줄(열)들을 특정 위치로 잘라내어 삽입(이동)합니다.

        """
        sheet = self.check_sheet_name(sheet_name)
        [start, end] = self.check_start_n_end_address_for_range(yyline1)
        dest = self.check_one_data_for_range(yline2)

        target_range = sheet.Range(sheet.Columns(start), sheet.Columns(end))
        target_range.Cut()

        dest_range = sheet.Columns(dest)
        dest_range.Insert(Shift=-4161)
        sheet.Application.CutCopyMode = False

    def move_yline_for_range(self, sheet_name_list, yy_list):
        """
        가로의 값을 이동시킵니다

        """

        sheet1 = self.check_sheet_name(sheet_name_list[0])
        char_y1 = self.change_num_to_char(yy_list[0])
        rng1 = sheet1.Columns(char_y1 + ':' + char_y1)

        sheet2 = self.check_sheet_name(sheet_name_list[1])
        char_y2 = self.change_num_to_char(yy_list[1])
        rng2 = sheet2.Columns(char_y2 + ':' + char_y2)

        rng1.Select()
        rng1.Cut()
        rng2.Select()
        rng2.Insert()

    def move_yline_value_to_multi_input_lines_for_range(self, xyxy, repeat_no, start_xy):
        """
        y라인의 가로 한줄의 자료를 여반복갯수에 따라서 시작점에서부터 아래로 복사하는것
        입력자료 : 1줄의 영역, 반복하는 갯수, 자료가 옮겨갈 시작주소

        """
        sheet = self.check_sheet_name("")
        all_data_set = self.read_value_for_range("", xyxy)
        for no in range(len(all_data_set)):
            mok, namuji = divmod(no, repeat_no)
            new_x = mok + start_xy[0]
            new_y = namuji + start_xy[1]
            sheet.Cells(new_x, new_y).Value = all_data_set[no][0]

    def move_ystep(self, sheet_name, xyxy, input_xno, step_no):
        """
        move_ystep(sheet_name='', xyxy='', input_w, step_no)
        가로의 자료를 설정한 갯수만큼 한줄로 오른쪽으로 이동

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        new_y = 0
        new_x = input_xno
        for y in range(xyxy[0], xyxy[2] + 1):
            for x in range(xyxy[1], xyxy[3] + 1):
                new_y = new_y + 1
                value = sheet.Cells(x, y).Value
                if value == None:
                    value = ""
                sheet.Cells(new_y, new_x).Value = value

    def move_yy(self, sheet_name1, sheet_name2, yy_list0, yy_list1):
        """
        세로의 값을 이동시킵니다

        """
        self.move_yyline_to_another_sheet_for_range(sheet_name1, sheet_name2, yy_list0, yy_list1)

    def move_yyline(self, sheet_name1, sheet_name2, yy_list0, yy_list1):
        """
        세로의 값을 이동시킵니다

        """
        self.move_yyline_to_another_sheet(sheet_name1, sheet_name2, yy_list0, yy_list1)

    def move_yyline_to_another_sheet_for_range(self, sheet_name1, sheet_name2, yy_list0, yy_list1):
        """
        가로의 값을 복사해서 다른곳으로 이동시키기

        """
        sheet1 = self.check_sheet_name(sheet_name1)
        sheet2 = self.check_sheet_name(sheet_name2)
        yy_list0_1, yy_list0_2 = self.check_xy_address(yy_list0)
        yy_list1_1, yy_list1_2 = self.check_xy_address(yy_list1)
        yy_list0_1 = self.change_num_to_char(yy_list0_1)
        yy_list0_2 = self.change_num_to_char(yy_list0_2)
        yy_list1_1 = self.change_num_to_char(yy_list1_1)
        yy_list1_2 = self.change_num_to_char(yy_list1_2)
        sheet1.Select()
        sheet1.Columns(str(yy_list0_1) + ':' + str(yy_list0_2)).Select()
        sheet1.Columns(str(yy_list0_1) + ':' + str(yy_list0_2)).Cut()
        sheet2.Select()
        sheet2.Columns(str(yy_list1_1) + ':' + str(yy_list1_2)).Select()
        sheet2.Columns(str(yy_list1_1) + ':' + str(yy_list1_2)).Insert()

    def new_all_image_of_folder_in_sheet(self, sheet_name, folder_name="D:\\aaa", ext_list=["xls"], input_xywh=[3, 3, 20, 30], link="0J", image_in_file=1):
        """
        특정폴다안이 모든 사진을 전부 불러오는 것이다

        """

        aaa = self.xyutil.get_all_filename_in_folder_by_extension_name(folder_name, ext_list)
        sheet = self.check_sheet_name(sheet_name)
        rng = sheet.Cells(input_xywh[0], input_xywh[1])

        for index, filename in enumerate(aaa):
            full_path = folder_name + "/" + filename
            full_path = str(full_path).replace("/", "\\")

            sheet.Shapes.AddPicture(full_path, link, image_in_file, rng.Left + index * 5,
                                        rng.Top + index * 5,
                                        input_xywh[2], input_xywh[3])
        return aaa

    def new_button_for_range(self, sheet_name, xyxy, title=None):
        """
        엑셀의 시트위에 버튼을 만드는것.

        버튼을 만들어서 그 버튼에 매크로를 연결하는 데,익서은 그냥 버튼만 만드는 것이다
        Add(왼쪽의 Pixel, 위쪽 Pixce, 넓이, 높이)

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        new_btn = sheet.Buttons()
        left_px, top_px, width_px, height_px = self.get_coord_for_cell(sheet_name, xyxy)
        new_btn.Add(left_px, top_px, width_px, height_px)
        new_btn.Text = title

    def new_button_with_macro_code_for_range(self, sheet_name, xyxy, macro_code="", title=None):
        """
        매크로랑 연결된 버튼을 만드는것
        버튼을 만들어서 그 버튼에 매크로를 연결하는 것이다
        매크로와 같은것을 특정한 버튼에 연결하여 만드는것을 보여주기위한 것이다

        :return: X / 없음
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        new_btn = sheet.Buttons()
        sheet.Cells(x1, y1).Select()
        left_px, top_px, width_px, height_px = self.get_coord_for_cell("", [x1, y1])
        new_btn.Add(left_px, top_px, width_px, height_px)
        new_btn.OnAction = macro_code
        new_btn.Text = title

    def new_button_with_macro_name_for_range(self, sheet_name, xyxy, macro_name="", title=None):
        """
        버튼을 만들어서 그 버튼에 입력된 매크로를 연결하는 것이다
        매크로와 같은것을 특정한 버튼에 연결하여 만드는것을 보여주기위한 것이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        sheet = self.check_sheet_name(sheet_name)
        new_btn = sheet.Buttons()
        left_px, top_px, width_px, height_px = self.get_coord_for_cell("", xyxy)
        new_btn.Add(left_px, top_px, width_px, height_px)
        new_btn.OnAction = macro_name
        new_btn.Text = title

    def new_cell_obj(self, sheet_name='', xy=''):
        """
        입력 셀의 객체를 만들어서 돌려준다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        one_cell = sheet.Cells(x1, y1)
        return one_cell

    def new_chart(self, sheet_name, chart_type, input_pxywh, source_xyxy):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        chart_obj = sheet.Chartobjects.Add(input_pxywh)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(source_xyxy)
        r1c1 = self.change_address_to_r1c1([x1, y1, x2, y2])
        rng = sheet.Range(r1c1)
        chart_obj.SetSourceData(rng)
        chart_obj.ChartType = chart_type
        return chart_obj

    def new_chart_for_range(self, sheet_name, dispaly_xyxy="", chart_style=1, data_xyxy="", main_title="제목1"):
        """
        챠트를 만드는 것 기본적인 설정을 해서 만듭니다

        """
        chart_style_vs_enum = {"line": 4, "pie": 5}
        sheet = self.check_sheet_name(sheet_name)
        data_rng = sheet.Range(sheet.Cells(data_xyxy[0], data_xyxy[1]),
                                         sheet.Cells(data_xyxy[2], data_xyxy[3]))
        pxywh = self.change_address_to_pxywh(sheet_name, dispaly_xyxy)
        chart_obj_all = sheet.ChartObjects().Add(pxywh[0], pxywh[1], pxywh[2], pxywh[3])
        chart_obj_all.Chart.SetSourceData(Source=data_rng)
        chart_obj = chart_obj_all.Chart
        chart_obj.ChartType = chart_style_vs_enum[chart_style]
        if main_title:
            chart_obj.HasTitle = True  # 차트 제목 나오게(False면 안보임) chart_obj.ChartTitle.Text = main_title # 차트 제목 설정
        return chart_obj

    def new_excel_file_for_range(self, sheet_name, xyxy, input_filename="D:\\aaa.xlsx"):
        """
        현재화일의 자료를 복사해서
        선택영역에서 같은 영역의 자료들만 묶어서 엑셀화일 만들기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        rng.Select()
        self.xlapp.selection.Copy()
        self.new_workbook_with_file_path("")
        sheet = self.check_sheet_name("")
        sheet.Cells(1, 1).Select()
        sheet.Paste()
        self.save(input_filename)

    def new_image(self, sheet_name, file_path, input_xywh, link, image_in_file):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        rng = sheet.Cells(input_xywh[0], input_xywh[1])
        # sh.Shapes.AddPicture("화일이름", "링크가있나", "문서에저장", "x좌표", "y좌표", "넓이","높이")
        sheet.Shapes.AddPicture(file_path, link, image_in_file, rng.Left, rng.Top, input_xywh[2],
                                    input_xywh[3])

    def new_image_as_same_size_of_range(self, sheet_name, xyxy, full_path="D:\\my_folder"):
        """
        영역에 그림을 맞춰서 넣는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        pxywh = self.change_address_to_pxywh(sheet_name, xyxy)
        sheet.Shapes.AddPicture(full_path, '', True, pxywh[0], pxywh[1], pxywh[2], pxywh[3])

    def new_image_at_selection(self, sheet_name, xyxy, input_filename="D:\\aaa.xlsx", space=1):
        """
        특정 사진을 셀안에 맞토록 사이즈 조절하는 것
        sh.Shapes.AddPicture("화일이름", "링크가있나”, "문서에저장", "x좌표", "y좌표", "넓이", "높이")

        """

        xy_1 = self.get_coord_for_cell(sheet_name, [xyxy[0], xyxy[1]])
        xy_2 = self.get_coord_for_cell(sheet_name, [xyxy[2], xyxy[3]])

        x_start = xy_1[0] + space
        y_start = xy_1[1] + space

        width = xy_2[0] + xy_2[2] - xy_1[0] - space * 2
        height = xy_2[1] + xy_2[3] - xy_1[1] - space * 2

        sheet = self.check_sheet_name(sheet_name)
        # sh.Shapes.AddPicture("화일이름", "링크가있나", "문서에저장", "x좌표", "y좌표", "넓이","높이")
        sheet.Shapes.AddPicture(input_filename, 0, 1, x_start, y_start, width, height)

    def new_image_by_pixel(self, sheet_name, file_path="D:\\aaa.xlsx", pxywh=[30, 30, 20, 30], link=0, image_in_file=1):
        """
        그림을 픽셀크기로 시트에 넣는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Shapes.AddPicture(file_path, link, image_in_file, pxywh[0], pxywh[1], pxywh[2], pxywh[3])

    def new_image_for_cell(self, sheet_name, xy, full_path="D:\\my_folder"):
        """
        셀 하나에 그림을 맞춰서 넣는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)

        rng.Select()
        aaa = sheet.Pictures
        aaa.Insert(full_path).Select()

    def new_image_for_range(self, sheet_name, file_path="D:\\aaa.xlsx", input_xywh=[3, 3, 20, 30], link=0, image_in_file=1):
        """
        image화일을 넣는것

        """
        sheet = self.check_sheet_name(sheet_name)
        rng = sheet.Cells(input_xywh[0], input_xywh[1])
        # sh.Shapes.AddPicture("화일이름", "링크가있나", "문서에저장", "x좌표", "y좌표", "넓이","높이")
        sheet.Shapes.AddPicture(file_path, link, image_in_file, rng.Left, rng.Top, input_xywh[2], input_xywh[3])

    def new_image_for_range_for_sheet(self, sheet_name, xyxy, input_filename="D:\\aaa.xlsx", space=1):
        """
        특정 사진을 셀안에 맞토록 사이즈 조절하는 것
        sh.Shapes.AddPicture("화일이름", "링크가있나”, "문서에저장", "x좌표", "y좌표", "넓이", "높이")

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        xy_1 = self.get_coord_for_cell(sheet_name, [xyxy[0], xyxy[1]])
        xy_2 = self.get_coord_for_cell(sheet_name, [xyxy[2], xyxy[3]])

        x_start = xy_1[0] + space
        y_start = xy_1[1] + space

        width = xy_2[0] + xy_2[2] - xy_1[0] - space * 2
        height = xy_2[1] + xy_2[3] - xy_1[1] - space * 2

        sheet = self.check_sheet_name(sheet_name)
        # sh.Shapes.AddPicture("화일이름", "링크가있나", "문서에저장", "x좌표", "y좌표", "넓이","높이")
        sheet.Shapes.AddPicture(input_filename, 0, 1, x_start, y_start, width, height)

    def new_image_for_range_name(self, folder_path, ext_list):
        """

        """
        ext_list = self.check_input_data(ext_list)

        self.select_sheet()
        all_files = self.xyutil.get_all_filename_in_folder_by_extension_name(folder_path, ext_list)  # 1
        all_files.sort()  # 2

        all_rng_name = self.get_range_names()  # 3
        l2d = []
        for one in all_rng_name:
            bbb = self.change_address_to_xyxy(one[2])
            bbb.append(one[1])
            l2d.append(bbb)

        l2d.sort()  # 4

        min_count = min(len(l2d), len(all_files))
        for index in range(min_count):
            one_file = all_files[index]
            # insert_all_image_of_folder_for_sheet(self, folder_name, ext_list, xywh, link=0J, image_in_file=1):
            self.new_images_in_folder("", "D:\\", ["jpg"])  # 5

    def new_image_for_range_name_for_sheet(self, sheet_name, folder_path="D:\\aaa.xlsx", ext_list=["jgp", "png"]):
        """
        입력으로 들어오는 사진을 이름역역안에 맞춰서 넣는 것이다

        1. 입력된 폴더에서 사진의 화일이름을 갖고온다
        2. 사진자료를 이름기준으로 정렬 시킨다
        3. 엑셀의 시트에서 이름영역을 갖고온다
        4. 이름영역의 주소를 기준으로 정렬을 시킨다
        5. 이름영영역의 갯수를 기준으로 사진자료를 넣는다

        """
        ext_list = self.check_input_data(ext_list)

        self.select_sheet(sheet_name)
        all_files = self.xyutil.get_all_filename_in_folder_by_extension_name(folder_path, ext_list)  # 1
        all_files.sort()  # 2

        all_rng_name = self.get_range_names()  # 3
        l2d = []
        for one in all_rng_name:
            bbb = self.change_address_to_xyxy(one[2])
            bbb.append(one[1])
            l2d.append(bbb)

        l2d.sort()  # 4

        min_count = min(len(l2d), len(all_files))
        for index in range(min_count):
            one_file = all_files[index]
            # insert_all_image_of_folder_for_sheet(self, sheet_name, folder_name, ext_list, xywh, link=0J, image_in_file=1):
            self.new_images_for_sheet_for_folder("", "D:\\", ["jpg"])  # 5

    def new_image_for_sheet(self):
        """
        시트에 그림을 넣는것

        """
        sh = self.xlbook.Worksheets("Sheet1")
        sh.Shapes.AddPicture("c:\\icon_sujun.gif", 0, 1, 541.5, 92.25, 192.75, 180)

    def new_image_name_for_sheet(self, sheet_name, folder_path="D:\\aaa.xlsx", ext_list=["jgp", "png"]):
        """
        입력으로 들어오는 사진을 이름역역안에 맞춰서 넣는 것이다

        1. 입력된 폴더에서 사진의 화일이름을 갖고온다
        2. 사진자료를 이름기준으로 정렬 시킨다
        3. 엑셀의 시트에서 이름영역을 갖고온다
        4. 이름영역의 주소를 기준으로 정렬을 시킨다
        5. 이름영영역의 갯수를 기준으로 사진자료를 넣는다

        """
        ext_list = self.check_input_data(ext_list)

        self.select_sheet(sheet_name)
        all_files = self.xyutil.get_all_filename_in_folder_by_extension_name(folder_path, ext_list)  # 1
        all_files.sort()  # 2

        all_rng_name = self.all_range_name()  # 3
        l2d = []
        for one in all_rng_name:
            bbb = self.change_address_to_xyxy(one[2])
            bbb.append(one[1])
            l2d.append(bbb)

        l2d.sort()  # 4

        min_count = min(len(l2d), len(all_files))
        for index in range(min_count):
            one_file = all_files[index]
            # insert_all_image_of_folder_for_sheet(self, folder_name, ext_list, xywh, link=0J, image_in_file=1):
            self.new_all_image_of_folder_in_sheet(folder_name="D:\\", ext_list=["jpg"])  # 5

    def new_images_for_sheet_for_folder(self, sheet_name, folder_name="D:\\aaa", ext_list=["xls"], input_xywh=[3, 3, 20, 30], link="0J", image_in_file=1):
        """
        특정폴다안이 모든 사진을 전부 불러오는 것이다

        """

        aaa = self.xyutil.get_all_filename_in_folder_by_extension_name(folder_name, ext_list)
        sheet = self.check_sheet_name(sheet_name)
        rng = sheet.Cells(input_xywh[0], input_xywh[1])

        for index, filename in enumerate(aaa):
            full_path = folder_name + "/" + filename
            full_path = str(full_path).replace("/", "\\")

            sheet.Shapes.AddPicture(full_path, link, image_in_file, rng.Left + index * 5,
                                        rng.Top + index * 5,
                                        input_xywh[2], input_xywh[3])
        return aaa

    def new_images_in_folder(self, sheet_name, folder_name, ext_list, input_xywh, link, image_in_file):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        aaa = self.xyutil.get_all_filename_in_folder_by_extension_name(folder_name, ext_list)
        rng = sheet.Cells(input_xywh[0], input_xywh[1])

        for index, filename in enumerate(aaa):
            full_path = folder_name + "/" + filename
            full_path = str(full_path).replace("/", "\\")

            sheet.Shapes.AddPicture(full_path, link, image_in_file, rng.Left + index * 5,
                                        rng.Top + index * 5, input_xywh[2], input_xywh[3])
        return aaa

    def new_line(self, sheet_name, xyxy, input_dic):
        """
        선을 만들기

        """
        [sheet_name, xyxy, input_dic] = self._check_3_param(sheet_name, xyxy, input_dic)
        enum_line = {
            "msoArrowheadNone": 1, "msoArrowheadTriangle": 2, "msoArrowheadOpen": 3, "msoArrowheadStealth": 4,
            "msoArrowheadDiamond": 5, "msoArrowheadOval": 6,
            "": 1, "<": 2, ">o": 3, ">>": 4, ">": 2, "<>": 5, "o": 6,
            "basic": 1, "none": 1, "triangle": 2, "open": 3, "stealth": 4, "diamond": 5, "oval": 6,
            "msoArrowheadNarrow": 1, "msoArrowheadWidthMedium": 2, "msoArrowheadWide": 3,
            "msoArrowheadShort": 1, "msoArrowheadLengthMedium": 2, "msoArrowheadLong": 3,
            "short": 1, "narrow": 1, "medium": 2, "long": 3, "wide": 3,
            "-1": 1, "0": 2, "1": 3,
            "dash": 4, "dashdot": 5, "dashdotdot": 6, "rounddot": 3, "longdash": 7, "longdashdot": 8,
            "longdashdotdot": 9,
            "squaredot": 2,
            "-": 4, "-.": 5, "-..": 6, ".": 3, "--": 7, "--.": 8, "--..": 9, "ㅁ": 2,
        }

        base_data = {
            "sheet_name": "",
            "xyxy": [100, 100, 0, 0],
            "color": 10058239,
            "line_style": "-.",
            "thickness": 0.5,
            "transparency": 0,
            "head_style": ">",
            "head_length": "0",
            "head_width": "0",
            "tail_style": ">",
            "tail_length": "0",
            "tail_width": "0",
        }

        # 기본자료에 입력받은값을 update하는것이다
        base_data.update(input_dic)

        sheet = self.check_sheet_name(base_data["sheet_name"])
        set_line = sheet.Shapes.AddLine(base_data["xyxy"][0], base_data["xyxy"][1], base_data["xyxy"][2],
                                        base_data["xyxy"][3])
        set_line.Select()
        set_line.Line.ForeColor.RGB = base_data["color"]
        set_line.Line.DashStyle = enum_line[base_data["line_style"]]
        set_line.Line.Weight = base_data["thickness"]
        set_line.Line.Transparency = base_data["transparency"]
        # print(set_line.Name)
        # 엑셀에서는 Straight Connector 63의 형태로 이름이 자동적으로 붙여진다

        set_line.Line.BeginArrowheadStyle = enum_line[base_data["head_style"]]
        set_line.Line.BeginArrowheadLength = enum_line[base_data["head_length"]]
        set_line.Line.BeginArrowheadWidth = enum_line[base_data["head_width"]]
        set_line.Line.EndArrowheadStyle = enum_line[base_data["tail_style"]]  # 화살표의 머리의 모양
        set_line.Line.EndArrowheadLength = enum_line[base_data["tail_length"]]  # 화살표의 길이
        set_line.Line.EndArrowheadWidth = enum_line[base_data["tail_width"]]  # 화살표의 넓이
        result = set_line.Name
        return result

    def new_line_by_cxyxy(self, sheet_name, cxyxy):
        """
        엑셀에서 좌표는 xy_excel에서 사용하는 x, y축과 다른 의미를 갖는다
        그러니 좌표를 의미하는 cxyxy를 사용하거나 pyxyx를 사용하도록 하자

        """
        sheet = self.check_sheet_name(sheet_name)
        new_shape_obj = sheet.Shapes.AddLine(cxyxy[0], cxyxy[1], cxyxy[2], cxyxy[3])
        return new_shape_obj

    def new_line_by_pxyxy(self, sheet_name, pxyxy):
        """
        4개영역의 픽셀값을 가지고 사각형을 그리는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        new_shape_obj = sheet.Shapes.AddLine(pxyxy[0], pxyxy[1], pxyxy[2], pxyxy[3])
        return new_shape_obj

    def new_line_for_range(self, sheet_name, xyxy, input_dic):
        """
        선을 만들기

        """
        [sheet_name, xyxy, input_dic] = self._check_3_param(sheet_name, xyxy, input_dic)
        enum_line = {
            "msoArrowheadNone": 1, "msoArrowheadTriangle": 2, "msoArrowheadOpen": 3, "msoArrowheadStealth": 4,
            "msoArrowheadDiamond": 5, "msoArrowheadOval": 6,
            "": 1, "<": 2, ">o": 3, ">>": 4, ">": 2, "<>": 5, "o": 6,
            "basic": 1, "none": 1, "triangle": 2, "open": 3, "stealth": 4, "diamond": 5, "oval": 6,
            "msoArrowheadNarrow": 1, "msoArrowheadWidthMedium": 2, "msoArrowheadWide": 3,
            "msoArrowheadShort": 1, "msoArrowheadLengthMedium": 2, "msoArrowheadLong": 3,
            "short": 1, "narrow": 1, "medium": 2, "long": 3, "wide": 3,
            "-1": 1, "0": 2, "1": 3,
            "dash": 4, "dashdot": 5, "dashdotdot": 6, "rounddot": 3, "longdash": 7, "longdashdot": 8,
            "longdashdotdot": 9,
            "squaredot": 2,
            "-": 4, "-.": 5, "-..": 6, ".": 3, "--": 7, "--.": 8, "--..": 9, "ㅁ": 2,
        }

        base_data = {
            "sheet_name": "",
            "xyxy": [100, 100, 0, 0],
            "color": 10058239,
            "line_style": "-.",
            "thickness": 0.5,
            "transparency": 0,
            "head_style": ">",
            "head_length": "0",
            "head_width": "0",
            "tail_style": ">",
            "tail_length": "0",
            "tail_width": "0",
        }

        # 기본자료에 입력받은값을 update하는것이다
        base_data.update(input_dic)

        sheet = self.check_sheet_name(base_data["sheet_name"])
        set_line = sheet.Shapes.AddLine(base_data["xyxy"][0], base_data["xyxy"][1], base_data["xyxy"][2],
                                        base_data["xyxy"][3])
        set_line.Select()
        set_line.Line.ForeColor.RGB = base_data["color"]
        set_line.Line.DashStyle = enum_line[base_data["line_style"]]
        set_line.Line.Weight = base_data["thickness"]
        set_line.Line.Transparency = base_data["transparency"]
        # print(set_line.Name)
        # 엑셀에서는 Straight Connector 63의 형태로 이름이 자동적으로 붙여진다

        set_line.Line.BeginArrowheadStyle = enum_line[base_data["head_style"]]
        set_line.Line.BeginArrowheadLength = enum_line[base_data["head_length"]]
        set_line.Line.BeginArrowheadWidth = enum_line[base_data["head_width"]]
        set_line.Line.EndArrowheadStyle = enum_line[base_data["tail_style"]]  # 화살표의 머리의 모양
        set_line.Line.EndArrowheadLength = enum_line[base_data["tail_length"]]  # 화살표의 길이
        set_line.Line.EndArrowheadWidth = enum_line[base_data["tail_width"]]  # 화살표의 넓이
        result = set_line.Name
        return result

    def new_line_for_range_by_cxyxy(self, sheet_name, cxyxy):
        """
        엑셀에서 좌표는 xy_excel에서 사용하는 x, y축과 다른 의미를 갖는다
        그러니 좌표를 의미하는 cxyxy를 사용하거나 pyxyx를 사용하도록 하자

        """
        sheet = self.check_sheet_name(sheet_name)
        new_shape_obj = sheet.Shapes.AddLine(cxyxy[0], cxyxy[1], cxyxy[2], cxyxy[3])
        return new_shape_obj

    def new_line_for_splitted_data(self, sheet_name, xyxy, union_char="#"):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        temp = ""
        old_x = x1
        for x in range(x1, x2 + 1):
            gijun_data = self.read_value_for_cell("", [x, y1])
            value = self.read_value_for_cell("", [x, y1 + 1])

            if gijun_data:
                sheet.Cells(old_x, y1 + 2).Value = temp[:-len(union_char)]
                temp = value + union_char
                old_x = x
            else:
                temp = temp + value + union_char
        sheet.Cells(old_x, y1 + 2).Value = temp[:-len(union_char)]

    def new_nea_sheet(self, input_no=None):
        """

        """
        for one in range(input_no):
            self.new_sheet()

    def new_range_name(self, sheet_name, xyxy, input_name):
        """
        영역에 이름을 설정하는 것입니다
        """
        [sheet_name, xyxy, input_name] = self._check_3_param(sheet_name, xyxy, input_name)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.xlbook.Names.Add(input_name, rng)

    def new_rectangle_by_ltwh(self, sheet_name, xyxy, top, left, width_float, height_float):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        new_shape_obj = sheet.Shapes.AddShape(1, left, top, width_float, height_float)
        new_shape_obj.Fill.Transparency = 1
        return new_shape_obj

    def new_rectangle_by_pxywh(self, sheet_name, xyxy, input_pxywh):
        """

        """
        [sheet_name, xyxy, input_pxywh] = self._check_3_param(sheet_name, xyxy, input_pxywh)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        px, py, pw, ph = input_pxywh
        rectangle_obj = sheet.Shapes.AddShape(Type=1, Left=px, Top=py, Width=pw, Height=ph)
        rectangle_obj.Fill.Transparency = 1  # 투명하게
        return rectangle_obj

    def new_rectangle_by_pxyxy(self, sheet_name, xyxy, input_pxywh):
        """

        """
        [sheet_name, xyxy, input_pxywh] = self._check_3_param(sheet_name, xyxy, input_pxywh)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet = self.new_rectangle_by_pxywh(input_pxywh)
        return sheet

    def new_shape(self, sheet_name, xy, shape_size=[25, 25], shape_style="circle", font_color="yel70", font_value="", font_size=12, font_bold=False, font_v=3, font_h=2):
        self.new_shape_for_range(sheet_name, xy, shape_size, "circle", font_color, font_value, font_size, font_bold, font_v, font_h)

    def new_shape_as_circle_with_number_for_range(self, sheet_name, xy="", shape_size=[25, 25], font_color="yel70", font_value="", font_size=12, font_bold=False):
        """
        원을 만들고, 안에 숫자를 연속적으로 만드는 것

        """
        self.new_shape_for_range(sheet_name, xy, shape_size, "circle", font_color, font_value, font_size, font_bold, font_value, font_size)

    def new_shape_as_pxyxy(self, sheet_name, pxyxy, shape_no):
        """
        특정위치에 도형을 만드는 것
        """
        sheet = self.check_sheet_name(sheet_name)

        if isinstance(shape_no, int):
            pass
        elif shape_no in list(self.varx["shape_name_vs_enum"].keys()):
            shape_no = self.varx["shape_name_vs_enum"][shape_no]
        px1, py1, px2, py2 = pxyxy
        shape_obj = sheet.Shapes.AddShape(shape_no, px1, py1, px2, py2)
        return shape_obj

    def new_shape_as_pxyxy_for_range(self, sheet_name, pxyxy, shape_no):
        """
        특정위치에 도형을 만드는 것

        """
        if isinstance(shape_no, int):
            pass
        elif shape_no in list(self.varx["shape_name_vs_enum"].keys()):
            shape_no = self.varx["shape_name_vs_enum"][shape_no]

        sheet = self.check_sheet_name(sheet_name)
        px1, py1, px2, py2 = pxyxy
        shape_obj = sheet.Shapes.AddShape(shape_no, px1, py1, px2, py2)
        return shape_obj

    def new_shape_at_pxyxy(self, sheet_name, pxyxy, shape_no):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(shape_no, int):
            pass
        elif shape_no in list(self.varx["shape_name_vs_enum"].keys()):
            shape_no = self.varx["shape_name_vs_enum"][shape_no]

        px1, py1, px2, py2 = pxyxy
        shape_obj = sheet.Shapes.AddShape(shape_no, px1, py1, px2, py2)
        return shape_obj

    def new_shape_box_for_same_size(self, sheet_name, xyxy, line_color="bla", line_thickness="thin"):
        """
        영역의 테두리와 맞는 사각형 텍스트박스를 만드는데, 투명도가 100%로 설정한 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        pxywh = self.change_address_to_pxywh(sheet_name, xyxy)

        Shpl = sheet.Shapes.AddShape(1, pxywh[0], pxywh[1], pxywh[2], pxywh[3])
        Shpl.Fill.Transparency = 1
        Shpl.Line.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(line_color)

        try:
            thickness = self.varx["check_line_style"][line_thickness]
        except:
            thickness = line_thickness
        Shpl.Line.Weight = thickness

    def new_shape_box_for_same_size_for_range(self, sheet_name, xyxy, line_color="bla", line_thickness="thin"):
        """
        영역의 테두리와 맞는 사각형 텍스트박스를 만드는데, 투명도가 100%로 설정한 것이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        pxywh = self.change_address_to_pxywh(sheet_name, xyxy)

        Shpl = sheet.Shapes.AddShape(1, pxywh[0], pxywh[1], pxywh[2], pxywh[3])
        Shpl.Fill.Transparency = 1
        Shpl.Line.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(line_color)

        try:
            thickness = self.varx["check_line_style"][line_thickness]
        except:
            thickness = line_thickness
        Shpl.Line.Weight = thickness

    def new_shape_box_for_same_size_with_xyxy(self, sheet_name, xyxy, line_color="bla", line_thickness="thin"):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        pxywh = self.change_address_to_pxywh()

        Shpl = sheet.Shapes.AddShape(1, pxywh[0], pxywh[1], pxywh[2], pxywh[3])
        Shpl.Fill.Transparency = 1
        Shpl.Line.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(line_color)

        try:
            thickness = self.varx["check_line_style"][line_thickness]
        except:
            thickness = line_thickness
        Shpl.Line.Weight = thickness

    def new_shape_by_range(self, sheet_name, xyxy, shape_no=None):
        """
        도형객체를 추가하는것

        shape_no : 엑셀에서 정의한 도형의 번호
        xywh : 왼쪽윗부분의 위치에서 너비와 높이
        """
        # 도형이 숫자이면 그대로, 문자이면 기본자료에서 찾도록 한다
        [sheet_name, xyxy, shape_no] = self._check_3_param(sheet_name, xyxy, shape_no)
        if isinstance(shape_no, int):
            pass
        elif shape_no in list(self.varx["shape_name_vs_enum"].keys()):
            shape_no = self.varx["shape_name_vs_enum"][shape_no]

        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        xywh = [rng.Left, rng.Top, rng.Width, rng.Height]
        shape_obj = sheet.Shapes.Addshape(shape_no, xywh[0], xywh[1], xywh[2], xywh[3])
        return shape_obj

    def new_shape_by_xywh(self, sheet_name, xyxy, shape_no, input_xywh):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        new_shape_obj = sheet.Shapes.Addshape(shape_no, input_xywh[0], input_xywh[1], input_xywh[2],
                                                  input_xywh[3])
        return new_shape_obj

    def new_shape_by_xywh_for_sheet(self, sheet_name, shape_no, input_xywh):
        """
        그림을 픽셀크기로 시트에 넣는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        new_shape_obj = sheet.Shapes.Addshape(shape_no, input_xywh[0], input_xywh[1], input_xywh[2], input_xywh[3])
        return new_shape_obj

    def new_shape_for_range(self, sheet_name, xy, shape_size=[25, 25], shape_style="circle", font_color="yel70", font_value="", font_size=12, font_bold=False, font_v=3, font_h=2):
        """
        원을 만들고, 안에 숫자를 연속적으로 만드는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        pxyxy = self.change_address_to_pxyxy(xy)
        check_shape_style = {"circle": 9, "원": 9}

        shape_obj = sheet.Shapes.AddShape(check_shape_style[shape_style], pxyxy[0], pxyxy[1], shape_size[0], shape_size[1])

        if font_value:
            shape_obj.TextFrame2.VerticalAnchor = font_v
            shape_obj.TextFrame2.HorizontalAnchor = font_h
            shape_obj.TextFrame2.TextRange.Font.Bold = font_bold

            shape_obj.TextFrame2.TextRange.Characters.Font.Fill.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(font_color)
            shape_obj.TextFrame2.TextRange.Characters.Text = font_value
            shape_obj.TextFrame2.TextRange.Characters.Font.Size = font_size

            # shape_obj.TextFrame2.TextRange.Font.Size = font_size
            # shape_obj.TextFrame2.TextRange.Font.Bold = font_bold
            # shape_obj.TextFrame2.TextRange.Font.Italic = font_italic
            # shape_obj.TextFrame2.TextRange.Font.Name = font_name

            # shape_obj.TextFrame2.TextRange.Font.Strikethrough = font_strikethrough
            # shape_obj.TextFrame2.TextRange.Font.Subscript = font_subscript
            # shape_obj.TextFrame2.TextRange.Font.Superscript = font_superscript
            # shape_obj.TextFrame2.TextRange.Font.Alpha = font_alpha
            # shape_obj.TextFrame2.TextRange.Font.Underline = font_underline

    def new_shape_line(self, sheet_name, xyxy, input_color, thickness, line_style, transparency, head_dic, tail_dic=""):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        enum_line = self.varx["line_end_style_vs_enum"]
        base_data = self.varx["base_cell_data"]
        # 기본자료에 입력받은값을 update하는것이다

        base_data.update(input)
        set_line = sheet.Shapes.AddLine(x1, y1, x2, y2)
        set_line.Select()

        set_line.Line.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        set_line.Line.DashStyle = line_style
        set_line.Line.Weight = thickness
        set_line.Line.Transparency = transparency

        if head_dic:
            # 엑셀에서는 Straight Connector 63의 형태로 이름이 자동적으로 붙여진다
            set_line.Line.BeginArrowheadStyle = enum_line[base_data[head_dic["style"]]]
            set_line.Line.BeginArrowheadLength = enum_line[base_data[head_dic["height"]]]
            set_line.Line.BeginArrowheadWidth = enum_line[base_data[head_dic["width"]]]

        if tail_dic:
            set_line.Line.EndArrowheadStyle = enum_line[base_data[tail_dic["style"]]]  # 화살표의 머리의 모양
            set_line.Line.EndArrowheadLength = enum_line[base_data[tail_dic["height"]]]  # 화살표의 길이
            set_line.Line.EndArrowheadWidth = enum_line[base_data[tail_dic["width"]]]  # 화살표의 넓이
        return set_line

    def new_shape_line_by_pxyxy(self, sheet_name, pxyxy, input_color=None):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        line_obj = sheet.Shapes.AddLine(pxyxy[0], pxyxy[1], pxyxy[2],
                                            pxyxy[3]).Select()
        self.xlapp.Selection.ShapeRange.Line.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        self.xlapp.Selection.ShapeRange.Line.Weight = 5

    def new_shape_line_by_pxyxy_for_range(self, sheet_name, pxyxy, input_color=None):
        """
        선택영역에서 선을 긋는것
        pixel을 기준으로 선긋기
        선을 그을때는 위치와 넓이 높이로 긋는데, xyxy2_to_pxyxy을 사용하면 셀위치를 그렇게 바꾸게 만든다

        """

        sheet = self.check_sheet_name(sheet_name)

        line_obj = sheet.Shapes.AddLine(pxyxy[0], pxyxy[1], pxyxy[2], pxyxy[3]).Select()
        self.xlapp.Selection.ShapeRange.Line.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        self.xlapp.Selection.ShapeRange.Line.Weight = 5

    def new_shape_line_for_range(self, sheet_name, xyxy, input_color="yel70", thickness=3, line_style=2, transparency=0.8, head_dic="", tail_dic=""):
        """
        선택영역에서 선을 긋는것
        선긋기를 좀더 상세하게 사용할수 있도록 만든것
        밐의 base_data의 값들을 이용해서 입력하면 된다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        enum_line = self.varx["line_end_style_vs_enum"]
        base_data = self.varx["base_cell_data"]
        # 기본자료에 입력받은값을 update하는것이다

        base_data.update(input)
        sheet = self.check_sheet_name(sheet_name)
        set_line = sheet.Shapes.AddLine(xyxy[0], xyxy[1], xyxy[2], xyxy[3])
        set_line.Select()

        set_line.Line.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        set_line.Line.DashStyle = line_style
        set_line.Line.Weight = thickness
        set_line.Line.Transparency = transparency

        if head_dic:
            # 엑셀에서는 Straight Connector 63의 형태로 이름이 자동적으로 붙여진다
            set_line.Line.BeginArrowheadStyle = enum_line[base_data[head_dic["style"]]]
            set_line.Line.BeginArrowheadLength = enum_line[base_data[head_dic["height"]]]
            set_line.Line.BeginArrowheadWidth = enum_line[base_data[head_dic["width"]]]

        if tail_dic:
            set_line.Line.EndArrowheadStyle = enum_line[base_data[tail_dic["style"]]]  # 화살표의 머리의 모양
            set_line.Line.EndArrowheadLength = enum_line[base_data[tail_dic["height"]]]  # 화살표의 길이
            set_line.Line.EndArrowheadWidth = enum_line[base_data[tail_dic["width"]]]  # 화살표의 넓이
        return set_line

    def new_shape_line_for_range_with_detail(self, sheet_name, xyxy, position="", line_style="_", thickness="thin", input_color="yel70", head_setup=False, tail_setup=False):
        """
        선택영역에서 선을 긋는것
        선긋기를 좀더 상세하게 사용할수 있도록 만든것
        밐의 base_data의 값들을 이용해서 입력하면 된다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        default_dic = {"position": [7, 8, 9, 10], "line_style": "-", "thickness": "t-1", "color": "bla"}
        temp_dic = self.check_line_style_as_dic([position, line_style, thickness, input_color])
        default_dic.update(temp_dic)
        rgbint = self.xycolor.change_xcolor_to_rgbint(default_dic["color"])
        for abc in default_dic["position"]:
            rng.Borders(abc).Color = rgbint
            rng.Borders(abc).Weight = default_dic["thickness"]
            rng.Borders(abc).LineStyle = default_dic["line_style"]

        enum_line = self.varx["line_end_style_vs_enum"]
        base_data = self.varx["base_cell_data"]
        # 기본자료에 입력받은값을 update하는것이다
        sheet = self.check_sheet_name("")
        base_data.update(input)
        sheet = self.check_sheet_name(base_data["sheet_name"])
        set_line = sheet.Shapes.AddLine(base_data["xyxy"][0], base_data["xyxy"][1], base_data["xyxy"][2], base_data["xyxy"][3])
        set_line.Select()
        set_line.Line.ForeColor.RGB = base_data["color"]
        set_line.Line.DashStyle = enum_line[base_data["line_style"]]
        set_line.Line.Weight = base_data["thickness"]
        set_line.Line.Transparency = base_data["transparency"]

        # 엑셀에서는 Straight Connector 63의 형태로 이름이 자동적으로 붙여진다
        set_line.Line.BeginArrowheadStyle = enum_line[base_data["head_style"]]
        set_line.Line.BeginArrowheadLength = enum_line[base_data["head_length"]]
        set_line.Line.BeginArrowheadWidth = enum_line[base_data["head_width"]]
        set_line.Line.EndArrowheadStyle = enum_line[base_data["tail_style"]]  # 화살표의 머리의 모양
        set_line.Line.EndArrowheadLength = enum_line[base_data["tail_length"]]  # 화살표의 길이
        set_line.Line.EndArrowheadWidth = enum_line[base_data["tail_width"]]  # 화살표의 넓이
        result = set_line.Name
        return set_line

    def new_shape_line_with_detail(self, sheet_name, xyxy, position="", line_style="_", thickness="thin", input_color="yel70", head_setup=False, tail_setup=False):
        """
        선택영역에서 선을 긋는것
        선긋기를 좀더 상세하게 사용할수 있도록 만든것
        밐의 base_data의 값들을 이용해서 입력하면 된다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        default_dic = {"position": [7, 8, 9, 10], "line_style": "-", "thickness": "t-1", "color": "bla"}
        temp_dic = self.check_line_style_as_dic([position, line_style, thickness, input_color])
        default_dic.update(temp_dic)
        rgbint = self.xycolor.change_xcolor_to_rgbint(default_dic["color"])
        for abc in default_dic["position"]:
            rng.Borders(abc).Color = rgbint
            rng.Borders(abc).Weight = default_dic["thickness"]
            rng.Borders(abc).LineStyle = default_dic["line_style"]

        enum_line = self.varx["line_end_style_vs_enum"]
        base_data = self.varx["base_cell_data"]
        # 기본자료에 입력받은값을 update하는것이다
        sheet = self.check_sheet_name('')
        base_data.update(input)
        sheet = self.check_sheet_name(base_data["sheet_name"])
        set_line = sheet.Shapes.AddLine(base_data["xyxy"][0], base_data["xyxy"][1], base_data["xyxy"][2], base_data["xyxy"][3])
        set_line.Select()
        set_line.Line.ForeColor.RGB = base_data["color"]
        set_line.Line.DashStyle = enum_line[base_data["line_style"]]
        set_line.Line.Weight = base_data["thickness"]
        set_line.Line.Transparency = base_data["transparency"]

        # 엑셀에서는 Straight Connector 63의 형태로 이름이 자동적으로 붙여진다
        set_line.Line.BeginArrowheadStyle = enum_line[base_data["head_style"]]
        set_line.Line.BeginArrowheadLength = enum_line[base_data["head_length"]]
        set_line.Line.BeginArrowheadWidth = enum_line[base_data["head_width"]]
        set_line.Line.EndArrowheadStyle = enum_line[base_data["tail_style"]]  # 화살표의 머리의 모양
        set_line.Line.EndArrowheadLength = enum_line[base_data["tail_length"]]  # 화살표의 길이
        set_line.Line.EndArrowheadWidth = enum_line[base_data["tail_width"]]  # 화살표의 넓이
        result = set_line.Name
        return set_line

    def new_shape_obj_by_name(self, sheet_name, shape_no=None):
        """
        도형의 번호를 기준으로 도형의 객체를 갖고오는 것

        """

        sheet = self.check_sheet_name(sheet_name)

        if isinstance(shape_no, str):
            shape_name = self.get_shape_name_by_no(sheet_name, shape_no)
            shape_obj = sheet.Shapes(shape_name)
        elif isinstance(shape_no, int):
            shape_obj = sheet.Shapes(shape_no)
        return shape_obj

    def new_shape_obj_by_no(self, sheet_name, shape_no=None):
        """
        도형번호를 입력하면 도형의 객체를 돌려주는 것이다

        """
        sheet = self.check_sheet_name(sheet_name)

        if isinstance(shape_no, str):
            shape_name = self.get_shape_name_by_no(sheet_name, shape_no)
            shape_obj = sheet.Shapes(shape_name)
        elif isinstance(shape_no, int):
            shape_obj = sheet.Shapes(shape_no)
        return shape_obj

    def new_shape_rectangle_by_ltwh(self, sheet_name, top, left, width_float, height_float):
        """

        """
        sheet = self.check_sheet_name(sheet_name)

        new_shape_obj = sheet.Shapes.AddShape(1, left, top, width_float, height_float)
        new_shape_obj.Fill.Transparency = 1
        return new_shape_obj

    def new_shape_rectangle_by_pxywh(self, sheet_name, input_pxywh):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        px, py, pw, ph = input_pxywh
        rectangle_obj = sheet.Shapes.AddShape(Type=1, Left=px, Top=py, Width=pw, Height=ph)
        rectangle_obj.Fill.Transparency = 1  # 투명하게
        return rectangle_obj

    def new_shape_rectangle_by_pxyxy(self, input_pxywh):
        """

        """
        sheet = self.new_rectangle_by_pxywh(input_pxywh)
        return sheet

    def new_sheet(self, sheet_name=''):
        """
        입력한 시트이름의 시트객체를 돌려주는 것

        """
        return self.check_sheet_name(sheet_name)

    def new_sheet_with_name(self, sheet_name=''):
        """
        시트하나 추가
        단, 이름을 확인해서 같은것이 있으면, 그냥 넘어간다

        """
        if sheet_name == "":
            self.xlbook.Worksheets.Add()
        else:
            sheets_name = self.get_all_sheet_name()
            if sheet_name in sheets_name:
                self.messagebox("같은 시트이름이 있읍니다")
            else:
                self.xlbook.Worksheets.Add()
                old_name = self.xlbook.ActiveSheet.Name
                self.xlbook.Worksheets(old_name).Name = sheet_name

    def new_sheet_with_nea(self, input_no):
        """
        n개의 새로운 시트 추가하기

        """
        for one in range(input_no):
            self.new_sheet_with_name("")

    def new_textbox_at_pxyxy(self,sheet_name,  x, y, width_float, height_float, text):
        # 텍스트 상자 추가 및 텍스트 입력
        sheet = self.check_sheet_name(sheet_name)
        textbox = sheet.Shapes.AddTextbox(1, x, y, width_float, height_float)
        textbox.TextFrame.Characters().Text = text

    def new_textbox_at_pxyxy_for_range(self, sheet_name, x=3, y=7, width_float=12.4, height_float=8.8, text="입력값1"):
        """
        텍스트박스를 입력받은 픽셀의 영역에 만드는 것

        """
        sheet = self.check_sheet_name(sheet_name)

        # 텍스트 상자 추가 및 텍스트 입력
        textbox = sheet.Shapes.AddTextbox(1, x, y, width_float, height_float)
        textbox.TextFrame.Characters().Text = text

    def new_triangle(self, xyxy="", per=100, reverse=1, size=100):
        """
        직각삼각형
        정삼각형에서 오른쪽이나 왼쪽으로 얼마나 더 간것인지
        100이나 -100이면 직삼각형이다
        사각형은 왼쪽위에서 오른쪽 아래로 만들어 진다

        """
        x1, y1, x2, y2 = xyxy
        lb = [x2, y1]  # left bottom
        rt = [x1, y2]  # right top
        rb = [x2, y2]  # right bottom
        result = [lb, rb, rt]
        return result

    def new_workbook_with_file_path(self, input_filename=None):
        """
        엑셀화일 열기

            new_workbook_with_file_path(input_filename="D:\\my_file.xlsx")
            new_workbook_with_file_path("D:\\my_file.xlsx")
            new_workbook_with_file_path("D:\\my_file2.xlsx")
        """
        self.new_workbook(input_filename)

    def new_xy_list_for_box_style(self, xyxy=''):
        """
        좌표를 주면, 맨끝만 나터내는 좌표를 얻는다

        """
        temp_1 = []
        for x in [xyxy[0], xyxy[2]]:
            temp = [[x, y] for y in range(xyxy[1], xyxy[3] + 1)]
            temp_1.append(temp)

        temp_2 = []
        for y in [xyxy[1], xyxy[3]]:
            temp = [[x, y] for x in range(xyxy[0], xyxy[2] + 1)]
            temp_2.append(temp)

        result = [temp_1[0], temp_2[1], temp_1[1], temp_2[0]]
        return result

    def open_file(self, input_filename=""):
        """
        엑셀화일 열기

        """
        self.new_workbook_with_file_path(input_filename)

    def paint(self, sheet_name='', xyxy='', input_color='pin50'):
        """
            현재 설정된 영역(rng)의 배경색을 지정한 색상으로 칠함

                """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgb_int = self.xycolor.change_xcolor_to_rgbint(input_color)
        rng.Interior.Color = rgb_int

    def paint_2n_xline(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        2번째 줄부터 색을 칠한다

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for no in range(x1+1, x2, 2):
            self.paint(sheet_name, [no, y1, no, y2], input_color)

    def paint_bar_for_range(self, sheet_name='', xyxy='', color_value=255):
        """
        영역안에 색으로된 바를 만드는 것

        """
        [sheet_name, xyxy, color_value] = self._check_3_param(sheet_name, xyxy, color_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.FormatConditions.AddDatabar()
        rng.FormatConditions(1).NegativeBarFormat.ColorType = 0  # xlDataBarColor =0
        rng.FormatConditions(1).NegativeBarFormat.Color.Color = color_value
        rng.FormatConditions(1).NegativeBarFormat.Color.TintAndShade = 0

    def paint_by_rgb(self, sheet_name, xyxy, input_rgb=None):
        """
        영역안에 입력받은 글자와 같은것이 있으면 색칠하는것

        """
        [sheet_name, xyxy, input_rgb] = self._check_3_param(sheet_name, xyxy, input_rgb)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Interior.Color = self.xycolor.change_rgb_to_rgbint(input_rgb)

    def paint_cell(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        셀의 배경색을 input_color형식으로 칠하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def paint_cell_as_gradation_by_color_n_position(self, input_style, input_obj="object1", input_bg_color="red50", input_l2d=[[1, 2], [4, 5]]):
        """
        여러가지색을 정하면서 색의 가장 진한 위치를 0~100사이에서 정하는 것

        """
        style_dic = {"ver": 2, "hor": 1, "cor": 5, "cen": 7, "dow": 4, "up": 3, "mix": -2, }
        input_obj.Fill.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_bg_color)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        obj_fill = input_obj.Fill
        obj_fill.OneColorGradient(style_dic[input_style], 1, 1)

        for index, l1d in enumerate(input_l2d):
            rgbint = self.xycolor.change_xcolor_to_rgbint(l1d[0])
            obj_fill.GradientStops.Insert(rgbint, l1d[1] / 100)

    def paint_cell_by_including_input_value(self, sheet_name, xyxy, input_value, input_color="pin50"):
        """
        영역안에 입력받은 글자와 같은것이 있으면 색칠하는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            value = sheet.Cells(x, y).Value2
            if isinstance(value, str):
                if input_value in value:
                    sheet.Cells(x, y).Interior.Color = rgbint

    def paint_cell_by_same_with_input_value(self, sheet_name, xyxy, input_value, input_color):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = rng.Value
        print(l2d)

        result_xy_set = []

        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                try:
                    if input_value in one_value:
                        sheet.Cells(ix + x1, iy + y1).Interior.Color = rgbint
                        result_xy_set.append([ix + x1, iy + y1])
                except:
                    pass

    def paint_cell_by_same_with_input_value_for_speed(self, sheet_name, xyxy, input_value, input_color):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        l2d = rng.Value
        result_xy_set = []
        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                try:
                    if input_value in one_value:
                        result_xy_set.append([ix + x1, iy + y1])
                except:
                    pass

        changed_xy_set = self.change_xy_list_to_continious_range(result_xy_set)
        for one_xyxy in (changed_xy_set):
            sheet.Range(sheet.Cells(one_xyxy[0], one_xyxy[1]), sheet.Cells(one_xyxy[2], one_xyxy[3])).Interior.Color = rgbint

    def paint_cell_by_words(self, sheet_name, xyxy, input_list):
        """
        영역안에 원하는 단어의 리스트안에 있는것 있으면 색칠하는 것

        """
        [sheet_name, xyxy, input_list] = self._check_3_param(sheet_name, xyxy, input_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint("yel")
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = sheet.Cells(x, y).Value
            temp_int = 0
            for one_word in input_list:
                if one_word in one_value:
                    sheet.Cells(x, y).Interior.Color = rgbint
                    break

    def paint_cell_for_empty_cell(self, sheet_name='', xyxy=''):
        """
        영역안의 빈셀의 배경색을 칠하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        temp_result = 0
        rgbint = self.xycolor.change_any_color_to_rgbint(16)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if one_value == None:
                sheet.Cells(x, y).Interior.Color = rgbint
                temp_result = temp_result + 1
        return temp_result

    def paint_cell_for_having_space(self, sheet_name='', xyxy='', input_color='pin50'):
        """

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = sheet.Cells(x, y).Value
            com = re.compile(r"^\s+")
            if one_value != None:
                if com.search(one_value):
                    sheet.Cells(x, y).Interior.Color = rgbint

    def paint_cell_for_max_value_in_each_xline(self, sheet_name='', xyxy='', input_color='pin50'):
        """

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        all_data = self.read(sheet_name, xyxy)
        if not (x1 == x2 and y1 == y2):
            for line_no in range(len(all_data)):
                line_data = all_data[line_no]
                filtered_list = list(filter(lambda x: isinstance(x, int) or isinstance(x, float), line_data))
                if filtered_list == []:
                    pass
                else:
                    max_value = max(filtered_list)
                    x_location = x1 + line_no
                    for no in range(len(line_data)):
                        y_location = y1 + no
                        if (line_data[no]) == max_value:
                            sheet.Cells(x_location, y_location).Interior.Color = rgbint
        else:
            print("Please re-check selection area")

    def paint_cell_for_max_value_in_each_yline(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(16)
        all_data = self.read(sheet_name, xyxy)
        if not (y1 == y2 and x1 == x2):
            for line_no in range(len(all_data)):
                line_data = all_data[line_no]
                filtered_list = list(filter(lambda x: isinstance(x, int) or isinstance(x, float), line_data))
                if filtered_list == []:
                    pass
                else:
                    max_value = max(filtered_list)
                    y_location = y1 + line_no
                    for no in range(len(line_data)):
                        x_location = x1 + no
                        if (line_data[no]) == max_value:
                            sheet.Cells(y_location, x_location).Interior.Color = rgbint
        else:
            print("Please re-check selection area")

    def paint_cell_for_min_value_in_each_xline(self, sheet_name='', xyxy='', input_color='pin50'):
        """

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        all_data = self.read(sheet_name, xyxy)
        if not (x1 == x2 and y1 == y2):
            for line_no in range(len(all_data)):
                line_data = all_data[line_no]
                filtered_list = list(filter(lambda x: isinstance(x, int) or isinstance(x, float), line_data))
                if filtered_list == []:
                    pass
                else:
                    max_value = min(filtered_list)
                    x_location = x1 + line_no
                    for no in range(len(line_data)):
                        y_location = y1 + no
                        if (line_data[no]) == max_value:
                            sheet.Cells(x_location, y_location).Interior.Color = rgbint
        else:
            print("Please re-check selection area")

    def paint_cell_for_range_by_same_with_input_value(self, sheet_name, xyxy, input_value, input_color):
        """
        영역안에 입력받은 글자와 같은것이 있으면 색칠하는것

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            value = sheet.Cells(x, y).Value2
            if input_value in value:
                sheet.Cells(x, y).Interior.Color = rgbint

    def paint_cell_for_range_by_words(self, sheet_name, xyxy, input_list):
        """
        영역안에 원하는 단어의 리스트안에 있는것 있으면 색칠하는 것

        """
        [sheet_name, xyxy, input_list] = self._check_3_param(sheet_name, xyxy, input_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint("yel")
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = sheet.Cells(x, y).Value
            temp_int = 0
            for one_word in input_list:
                if one_word in one_value:
                    sheet.Cells(x, y).Interior.Color = rgbint
                    break

    def paint_cell_for_range_for_empty_cell(self, sheet_name='', xyxy=''):
        """
        영역안의 빈셀의 배경색을 칠하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        temp_result = 0
        rgbint = self.xycolor.change_any_color_to_rgbint(16)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if one_value == None:
                sheet.Cells(x, y).Interior.Color = rgbint
                temp_result = temp_result + 1
        return temp_result

    def paint_cell_for_range_for_max_value_in_each_xline(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        한줄에서 가장 큰 값에 색칠하는 것
        선택한 영역안의 => 각 x라인별로 최대값에 색칠하는 것

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        all_data = self.read_value_for_range(sheet_name, [x1, y1, x2, y2])
        if not (x1 == x2 and y1 == y2):
            for line_no in range(len(all_data)):
                line_data = all_data[line_no]
                filteredList = list(filter(lambda x: isinstance(x, int) or isinstance(x, float), line_data))
                if filteredList == []:
                    pass
                else:
                    max_value = max(filteredList)
                    x_location = x1 + line_no
                    for no in range(len(line_data)):
                        y_location = y1 + no
                        if (line_data[no]) == max_value:
                            sheet.Cells(x_location, y_location).Interior.Color = rgbint
        else:
            print("Please re-check selection area")

    def paint_cell_for_range_for_max_value_in_each_yline(self, sheet_name='', xyxy=''):
        """
        가로줄이아닌 세로줄에서 제일 큰값에 색칠하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        all_data = self.read_value_for_range(sheet_name, [y1, x1, y2, x2])
        rgbint = self.xycolor.change_any_color_to_rgbint(16)
        if not (y1 == y2 and x1 == x2):
            for line_no in range(len(all_data)):
                line_data = all_data[line_no]
                filteredList = list(filter(lambda x: isinstance(x, int) or isinstance(x, float), line_data))
                if filteredList == []:
                    pass
                else:
                    max_value = max(filteredList)
                    y_location = y1 + line_no
                    for no in range(len(line_data)):
                        x_location = x1 + no
                        if (line_data[no]) == max_value:
                            sheet.Cells(y_location, x_location).Interior.Color = rgbint
        else:
            print("Please re-check selection area")

    def paint_cell_for_range_for_min_value_in_each_xline(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        선택한 영역안의 => 각 x라인별로 최소값에 색칠하는 것

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)

        all_data = self.read_value_for_range(sheet_name, [x1, y1, x2, y2])
        if not (x1 == x2 and y1 == y2):
            for line_no in range(len(all_data)):
                line_data = all_data[line_no]
                filteredList = list(filter(lambda x: isinstance(x, int) or isinstance(x, float), line_data))
                if filteredList == []:
                    pass
                else:
                    max_value = min(filteredList)
                    x_location = x1 + line_no
                    for no in range(len(line_data)):
                        y_location = y1 + no
                        if (line_data[no]) == max_value:
                            sheet.Cells(x_location, y_location).Interior.Color = rgbint
        else:
            print("Please re-check selection area")

    def paint_data_bar(self, sheet_name, xyxy, input_color='pin50'):
        """

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.FormatConditions.Delete()  # 영역에 포함된 조건부 서식을 지우는 것
        my_bar = rng.FormatConditions.AddDatabar()
        my_bar.BarFillType = 1  # xlDataBarSolid
        my_bar.BarBorder.Type = 0  # xlDataBarBorderSolid
        my_bar.BarColor.Color = self.xycolor.change_xcolor_to_rgbint(input_color)
        my_bar.BarBorder.Color.TintAndShade = 0

    def paint_data_bar_for_range(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        셀의 입력숫자에 따라서 Data Bar가 타나나도록 만드는 것

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.FormatConditions.Delete()  # 영역에 포함된 조건부 서식을 지우는 것

        my_bar = rng.FormatConditions.AddDatabar()
        my_bar.BarFillType = 1  # xlDataBarSolid
        my_bar.BarBorder.Type = 0  # xlDataBarBorderSolid
        my_bar.BarColor.Color = self.xycolor.change_xcolor_to_rgbint(input_color)
        my_bar.BarBorder.Color.TintAndShade = 0

    def paint_differ_value_in_two_range(self, input_l2d_1, input_l2d_2, colored_tf=False):
        """
        두개의 리스트가 다른 부분을 찾는데, 기준은 앞의것을 기준으로 한다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy('', '')
        rgbint = self.xycolor.change_any_color_to_rgbint("red++")
        result = []
        for l1d, ix in enumerate(input_l2d_1):
            for one_data, iy in enumerate(l1d):
                if input_l2d_1[ix][iy] == input_l2d_2[ix][iy]:
                    pass
                else:
                    result.append([ix + 1, iy + 1])
                    if colored_tf:
                        sheet.Cells(ix + 1, iy + 1).Interior.Color = rgbint

    def paint_different_cell_at_2_same_area(self, sheet_name1, xyxy1, sheet_name2, xyxy2):
        """

        """
        sheet1, [x1, y1, x2, y2], rng1 = self.check_sheet_n_xyxy(sheet_name1, xyxy1)
        sheet2, [x21, y21, x22, y22], rng2 = self.check_sheet_n_xyxy(sheet_name2, xyxy2)

        l2d_1 = self.read(sheet_name1, xyxy1)
        l2d_2 = self.read(sheet_name2, xyxy2)

        x11, y11, x12, y12 = self.change_address_to_xyxy(xyxy1)
        x21, y21, x22, y22 = self.change_address_to_xyxy(xyxy2)

        for x in range(len(l2d_1)):
            for y in range(len(l2d_1[0])):
                if l2d_1[x][y] != l2d_2[x][y]:
                    self.paint_cell(sheet_name1, [x + x11, y + y11], "yel")
                    self.paint_cell(sheet_name2, [x + x21, y + y21], "yel")

    def paint_empty_cell(self, sheet_name, xyxy, input_color="yel50"):
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            if not l2d[x - x1][y - y1]:
                sheet.Cells(x, y).Interior.Color = rgbint

    def paint_for_differ_value_in_two_range(self, sheet_name, xyxy, input_l2d_1, input_l2d_2, colored_tf=False):
        """
        두개의 리스트가 다른 부분을 찾는데, 기준은 앞의것을 기준으로 한다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet = self.check_sheet_name("")
        rgbint = self.xycolor.change_any_color_to_rgbint("red++")
        result = []
        for l1d, ix in enumerate(input_l2d_1):
            for one_data, iy in enumerate(l1d):
                if input_l2d_1[ix][iy] == input_l2d_2[ix][iy]:
                    pass
                else:
                    result.append([ix + 1, iy + 1])
                    if colored_tf:
                        sheet.Cells(ix + 1, iy + 1).Interior.Color = rgbint

    def paint_range_by_rgb(self, sheet_name, xyxy, input_rgb):
        """
        영역안에 입력받은 글자와 같은것이 있으면 색칠하는것

        """
        [sheet_name, xyxy, input_rgb] = self._check_3_param(sheet_name, xyxy, input_rgb)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Interior.Color = self.xycolor.change_rgb_to_rgbint(input_rgb)

    def paint_multi_selection(self, input_color='pin50'):
        """

        """
        self.selection.Interior.ColorIndex = self.xycolor.change_any_color_to_rgbint(input_color)

    def paint_range(self, sheet_name, xyxy, input_color='pin50'):
        """
        셀의 배경색을 input_color형식의 색으로 칠하는 것

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgb_int = self.xycolor.change_xcolor_to_rgbint(input_color)
        rng.Interior.Color = rgb_int

    def paint_rgb_set_from_xy_with_new_sheet(self, xy_list, rgb_set):
        """
        새로운 시트에 rgb set과 cell의 set에 색칠하는것

        """
        self.new_sheet()
        sheet = self.check_sheet_name("")
        for ix, one_rgb in rgb_set:
            sheet.Cells(xy_list[0] + ix, xy_list[1]).Interior.Color = self.xycolor.change_rgb_to_rgbint(one_rgb)

    def paint_same_value(self, sheet_name, xyxy, input_color='pin50'):
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        set_a = set([])
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                value = self.read(sheet_name, xyxy)
                if value == "" or value == None:
                    pass
                else:
                    len_old = len(set_a)
                    set_a.add(value)
                    len_new = len(set_a)
                    if len_old == len_new:
                        sheet.Cells(x, y).Interior.Color = rgbint

    def paint_same_value_for_range(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        영역안의 같은 값에 input_color색으로 색칠하는것

        """
        self.paint_same_value(sheet_name, xyxy, input_color)

    def paint_same_value_for_range_for_right_in_2_yline(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        2열중에서 왼쪽을 기준으로 오른쪽의 값중에서 같은것에 색칠하기

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read_value_for_range(sheet_name, [x1, y1, x2, y1])
        l1d = self.xyutil.change_l2d_to_l1d(l2d)
        for x in range(x1, x2 + 1):
            one_value = sheet.Cells(x, y1 + 1).Value
            if one_value in l1d:
                self.paint_cell(sheet_name, xyxy, input_color)

    def paint_same_value_for_range_over_n_times(self, sheet_name='', xyxy='', input_n_times=7):
        """
        선택한 영역에서 n번이상 반복된 것만 색칠하기

        """
        self.paint_same_value_over_n_times(sheet_name, xyxy, input_n_times)

    def paint_same_value_for_right_in_2_yline(self, sheet_name, xyxy, input_color='pin50'):
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read(sheet_name, xyxy)
        l1d = self.xyutil.change_l2d_to_l1d(l2d)
        for x in range(x1, x2 + 1):
            one_value = sheet.Cells(x, y1 + 1).Value
            if one_value in l1d:
                self.paint(input_color)

    def paint_same_value_over_n_times(self, sheet_name, xyxy, input_n_times=7):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint("pin50")
        py_dic = {}
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                one_value = self.read_cell(sheet_name, [x, y])
                if one_value != "" and one_value != None:
                    if one_value in list(py_dic.keys()):
                        py_dic[one_value] = py_dic[one_value] + 1
                    else:
                        py_dic[one_value] = 1

                    if py_dic[one_value] >= input_n_times:
                        sheet.Cells(x, y).Interior.Color = rgbint

    def paint_search_by_xsql(self, sheet_name, xyxy, input_xre, input_color):
        """
        엑셀의 영역에서 값을 찾으면, 셀에 색칠하기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.paint_search_range_by_xsql(input_xre, input_color)

    def paint_search_for_range_by_xsql(self, sheet_name, xyxy, input_xre, input_color):
        """
        엑셀의 영역에서 값을 찾으면, 셀에 색칠하기

        """
        self.paint_search_range_by_xsql(sheet_name, xyxy, input_xre, input_color)

    def paint_search_range_by_xsql(self, sheet_name, xyxy, input_xre, input_color):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        l2d = rng.Formula
        for ix, l1d in enumerate(l2d):
            for iy, value in enumerate(l1d):
                if not value or str(value).startswith("="):
                    pass
                else:
                    temp = self.xyre.search_all_by_xsql(input_xre, value)
                    if temp:
                        sheet.Cells(x1 + ix, y1 + iy).Interior.Color = rgbint

    def paint_selection(self, input_color='pin50'):
        """
        선택 영역의 배경색을 칠하는것
        색을 나타내는 형식은 xcolor형식으로 입력함

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy('', '')
        rng.Interior.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def paint_sheet_tab(self, sheet_name, input_color):
        """
        시트탭의 색을 넣는것

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Tab.Color = self.xycolor.change_xcolor_to_rgbint(input_color)

    def paint_space_cell(self, sheet_name, xyxy, input_color='pin50'):
        """
        영역안의 셀의 배경색을 input_color색으로 정하는 것
                빈셀처럼 보이는데 space문자가 들어가 있는것 찾기
        선택한 영역의 셀을 하나씩 읽어와서 re모듈을 이용해서 공백만 있는지 확인한다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        com = re.compile(r"^\s+")

        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            if isinstance(one_value, str):
                if com.search(one_value):
                    sheet.Cells(x, y).Interior.Color = rgbint

    def paint_space_cell_for_range(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        영역안의 셀의 배경색을 input_color색으로 정하는 것
                빈셀처럼 보이는데 space문자가 들어가 있는것 찾기
        선택한 영역의 셀을 하나씩 읽어와서 re모듈을 이용해서 공백만 있는지 확인한다

        """
        [sheet_name, xyxy, input_color] = self._check_3_param(sheet_name, xyxy, input_color)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            com = re.compile(r"^\s+")
            if one_value != None:
                if com.search(one_value):
                    sheet.Cells(x, y).Interior.Color = rgbint

    def paint_start_cell_of_same_value_as_yline(self,sheet_name, xyxy, input_color='pin50'):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_any_color_to_rgbint(input_color)
        found = False
        gijun_no = 0
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            value = sheet.Cells(x, y).Value
            value2 = sheet.Cells(x + 1, y).Value
            if value == value2 and value2 != None and value2 != "":
                if not found:
                    gijun_no = x
                    found = True
            else:
                if found:
                    sheet.Cells(gijun_no, y).Interior.Color = rgbint
                    found = False
                gijun_no = x

    def paint_start_cell_of_same_value_as_yline_for_range(self, sheet_name='', xyxy='', input_color='pin50'):
        """
        세로로 같은값이 연속되는 셀의 시작 셀에 색칠하기

        """
        self.paint_start_cell_of_same_value_as_yline(sheet_name, xyxy, input_color)

    def paint_with_option(self, sheet_name='', xyxy='', input_color='pin50', color_type=""):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        if color_type == "":
            rgb_int = self.xycolor.change_any_color_to_rgbint(input_color)
        elif isinstance(color_type, int) == "":
            rgb_int = self.xycolor.change_56color_to_rgbint(input_color)
        elif color_type == "rgb":
            rgb_int = self.xycolor.change_rgb_to_rgbint(input_color)
        elif color_type == "hsl":
            rgb_int = self.xycolor.change_hsl_to_rgbint(input_color)
        else:
            rgb_int = self.xycolor.change_any_color_to_rgbint(input_color)
        rng.Interior.Color = rgb_int

    def paint_words(self, sheet_name, xyxy, input_list):
        """
        선택영역안의 값중에 입력값중 하나가 잇으면, 셀의 배경색을 칠하기

        """
        [sheet_name, xyxy, input_list] = self._check_3_param(sheet_name, xyxy, input_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        bbb = input_list
        basic_list = [one_data.strip() for one_data in bbb.split(",")]
        total_no = len(basic_list)
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                one_value = sheet.Cells(x, y).Value
                temp_int = 0
                for one_word in basic_list:
                    if re.match('(.*)' + one_word + '(.*)', one_value):
                        temp_int = temp_int + 1
                if temp_int == total_no:
                    # pcell_dot.sheet.range().paint([x, y], 4)
                    pass

    def password_for_sheet(self, sheet_name, password="1234"):
        """
        시트를 암호로 저장

        """
        self.lock_sheet_with_password(sheet_name, password)

    def paste_format_only(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.PasteSpecial(Paste=-4122)  # Paste=win32.constants.xlPasteFormats)

    def paste_format_only_for_range(self, sheet_name='', xyxy=''):
        """
        서식만 붙여넣기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.PasteSpecial(Paste=-4122)  # Paste=win32.constants.xlPasteFormats)

    def paste_range(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.select_sheet()
        sheet.Cells(x1, y1).Select()
        sheet.Paste()

    def paste_range_for_sheet(self, sheet_name='', xyxy=''):
        """
        복사한것을 붙여넣기 하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        self.select_sheet(sheet_name)
        sheet.Cells(x1, y1).Select()
        sheet.Paste()

    def path_for_workbook(self):
        """
        워크북의 경로를 읽어온다

        """
        return self.xlbook.Path

    def pattern(self, sheet_name, xyxy, input_list=[]):
        result = self.pattern_for_range(sheet_name, xyxy, input_list)
        return result

    def pattern_for_range(self, sheet_name='', xyxy='', input_list=[]):
        """
        셀에 색상과 특정한 패턴을 집어 넣어서 다른것들과 구분할수가 있다

        1. 배경색에 격자무늬를 집어넣을수가 있는데, 이것은 패턴을 칠하고 남은 공간을 칠할수가 있다
        2. 배경색 + 무늬선택(색과 무늬형식)
        3. 만약 배경색으로 채우기효과를 주면서 그라데이션을 준다면, 무늬선택은 불가능하다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        input_list = self.check_input_data(input_list)

        if input_list:
            # 아무것도 없으면, 기존의 값을 사용하고, 있으면 새로이 만든다
            if isinstance(input_list, list):
                self.font_as_dic(input_list)
            elif isinstance(input_list, dict):
                # 만약 사전 형식이면, 기존에 저장된 자료로 생각하고 update한다
                self.varx["pattern"].update(input_list)
        a = 2
        if a == 1:
            rng.Interior.Color = 5296274
            rng.Interior.Pattern = self.varx["range_color"]["pattern"]
            rng.Interior.PatternColor = self.varx["range_color"]["pattern"]

        elif a == 2:
            rng.Interior.Gradient.Degree = 180
            rng.Interior.Gradient.ColorStops.Clear()
            rng.Interior.Gradient.ColorStops.Add(0)

        elif a == 3:
            rng.Interior.Color = 5296274
            rng.Interior.Pattern = self.varx["range_color"]["pattern"]  # xlSolid
            rng.Interior.PatternColor = self.varx["range_color"]["pattern"]  # PatternColorIndex = xlAutomatic
            rng.Interior.ThemeColor = 4  # xlThemeColorDark1 색상과 색조를 미리 설정한것을 불러다가 사용하는것
            # 이것은 기본적으로 마우스의 색을 선택할때 나타나는 테마색을 말하는 것이다

            rng.Interior.TintAndShade = -0.249977111117893  # 명암을 조절
            rng.Interior.PatternTintAndShade = 0

        return self.varx["range_color"]

    def pen_color_style_thickness(self, input_color="yel70", style="", thickness=5):
        """
        여러곳에 사용하기위해 공통변수에 색, 모양, 두께를 설정하는 것

        """

        self.v_pen_color = self.xycolor.change_xcolor_to_rgbint(input_color)
        self.v_pen_style = style
        self.v_pen_thickness = thickness

    def pen_color_style_thickness_for_obj(self, shape_obj="", input_color="yel70", style=4, thickness=5):
        """
        도형객체의 색, 모양, 두께를 설정하는 것

        """
        shape_obj.DashStyle = style
        shape_obj.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        shape_obj.Weight = thickness

    def pen_start_style(self, length=2, style=1, width_float=2):
        """
        도형객체에 모두 사용하기위해 시작모양을 설정하는 것

        """
        self.v_start_point_length = length  # 2-default, 3-long, 1-short
        self.v_start_point_style = style  # 1-없음,2-삼각형,3-얇은화살촉,4-화살촉,5-다이아몬드,6-둥근
        self.v_start_point_width = width_float  # 2-default, 3-넓은, 1-좁은

    def pen_start_style_for_obj(self, shape_obj="", length=2, style=1, width_float=2):
        """
        도형객체의 시작모양을 설정하는 것

        """
        shape_obj.BeginArrowheadlength = length  # 2-default, 3-long, 1-short
        shape_obj.BeginArrowheadstyle = style  # 1-없음,2-삼각형,3-얇은화살촉,4-화살촉,5-다이아몬드,6-둥근
        shape_obj.BeginArrowheadwidth = width_float  # 2-default, 3-넓은, 1-좁은

    def ppt_make_ppt_table_from_xl_data(self):
        """
        엑셀의 테이블 자료가 잘 복사가 않되는것 같아서, 아예 하나를 만들어 보았다
        엑셀의 선택한 영역의 테이블 자료를 자동으로 파워포인트의 테이블 형식으로 만드는 것이다

        """

        activesheet_name = self.get_activesheet_name()
        [x1, y1, x2, y2] = self.get_address_for_selection()

        Application = win32com.client.Dispatch("Powerpoint.Application")
        Application.Visible = True
        active_ppt = Application.Activepresentation
        slide_no = active_ppt.Slides.Count + 1

        new_slide = active_ppt.Slides.Add(slide_no, 12)
        new_table = active_ppt.Slides(slide_no).Shapes.AddTable(x2 - x1 + 1, y2 - y1 + 1)
        shape_no = active_ppt.Slides(slide_no).Shapes.Count

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            value = self.read_value_for_cell(activesheet_name, [x, y])
            active_ppt.Slides(slide_no).Shapes(shape_no).Table.Cell(x - x1 + 1,
                                                                    y - y1 + 1).Shape.TextFrame.TextRange.Text = value

    def preview(self, sheet_name):
        sheet = self.check_sheet_name(sheet_name)
        sheet.PrintPreview()

    def print_area(self, sheet_name, fit_wide):
        sheet = self.check_sheet_name(sheet_name)
        new_xyxy = self.change_address_to_r1c1('')
        sheet.PageSetup.PrintArea = new_xyxy

        sheet.PageSetup.Orientation = 1
        sheet.PageSetup.Zoom = False
        sheet.PageSetup.FitToPagesTall = False
        sheet.PageSetup.FitToPagesWide = fit_wide

    def print_area_for_sheet(self, sheet_name, xyxy, fit_wide=1):
        """
        프린트영역을 설정

        """
        sheet = self.check_sheet_name(sheet_name)
        new_xyxy = self.change_address_to_r1c1(xyxy)
        sheet.PageSetup.PrintArea = new_xyxy

        sheet.PageSetup.Orientation = 1
        sheet.PageSetup.Zoom = False
        sheet.PageSetup.FitToPagesTall = False
        sheet.PageSetup.FitToPagesWide = fit_wide

    def print_as_pdf(self, sheet_name, xyxy, filename):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.ExportAsFixedFormat(0, filename)

    def print_header(self, sheet_name, xyxy, position, input_value = None):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        temp_dic = {"화일명": "&F", "시간": "&T", "경로": "&Z", "현재페이지": "&N", "총페이지": "&P", "날짜": "&D"}
        for one in temp_dic.keys():
            input_value = input_value.replace(one, temp_dic[one])

        if position == "left":
            sheet.PageSetup.LeftHeader = input_value
        elif position == "center":
            sheet.PageSetup.CenterHeader = input_value
        elif position == "right":
            sheet.PageSetup.RightHeader = input_value

    def print_label_style(self, sheet_name, xyxy, input_l2d, line_list, start_xy, size_xy, y_line, position):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        line_list = self.check_input_data(line_list)

        changed_input_l2d = self.get_ylines_at_l2d(input_l2d, line_list)
        for index, l1d in enumerate(changed_input_l2d):
            new_start_x, new_start_y = self.xyutil.new_xy(index, start_xy, size_xy, y_line)
            for index_2, one_value in enumerate(l1d):
                sheet.Cells(new_start_x + position[index_2][0], new_start_y + position[index_2][1]).Value = \
                    l1d[index_2]

    def print_letter_cover(self, sheet_name='', xyxy=''):
        """
        봉투인쇄

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        # 기본적인 자료 설정
        data_from = [["sheet1", [1, 2]], ["sheet1", [1, 4]], ["sheet1", [1, 6]], ["sheet1", [1, 8]]]
        data_to = [["sheet2", [1, 2]], ["sheet2", [2, 2]], ["sheet2", [3, 2]], ["sheet2", [2, 3]]]
        no_start = 1
        no_end = 200
        step = 5
        # 실행되는 구간
        for no in range(no_start, no_end):
            for one in range(len(data_from)):
                value = self.read_value_for_cell(data_from[one][0], data_from[one][1])
                sheet.Cells(data_to[one][1][0] + (step * no), data_to[one][1][1]).Value = value

    def print_page(self, sheet_name, xyxy, input_dic):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.PageSetup.Zoom = False
        sheet.PageSetup.FitToPagesTall = 1
        sheet.PageSetup.FitToPagesWide = 1
        # sheet.PageSetup.PrintArea = print_area
        sheet.PageSetup.LeftMargin = 25
        sheet.PageSetup.RightMargin = 25
        sheet.PageSetup.TopMargin = 50
        sheet.PageSetup.BottomMargin = 50
        # sheet.ExportAsFixedFormat(0, path_to_pdf)
        sheet.PageSetup.LeftFooter = "&D"  # 날짜
        sheet.PageSetup.LeftHeader = "&T"  # 시간
        sheet.PageSetup.CenterHeader = "&F"  # 화일명
        sheet.PageSetup.CenterFooter = "&N/&P"  # 현 page/ 총 page
        sheet.PageSetup.RightHeader = "&Z"  # 화일 경로
        sheet.PageSetup.RightFooter = "&P+33"  # 현재 페이지 + 33

    def print_preview(self, sheet_name=''):
        sheet = self.check_sheet_name(sheet_name)
        sheet.PrintPreview()

    def quit(self):
        """
        엑셀 프로그램을 끄는것

        """
        self.xlapp.Quit()

    def read(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = self.xyutil.change_any_type_to_l2d(rng.Value)
        result = self.check_input_data(result)
        return result

    def read_activecell(self):
        return self.xlapp.ActiveCell.Value2

    def read_activecell_n_yno(self, input_yno):
        """
        현재 선택된 셀의 x번호와 입력받은 y줄의 번호를 조합한 셀의 값을 읽어오는것

        """
        xyxy = self.get_address_for_activecell()
        value = self.read_value_for_cell("", [xyxy[0], input_yno])
        return value

    def read_as_dic_with_xy_position(self,sheet_name, xyxy):
        result = {}
        l2d = self.read(sheet_name, xyxy)

        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                if one_value in result.keys():
                    result[ix + 1, iy + 1].append([one_value])
                else:
                    result[one_value] = [[ix + 1, iy + 1]]
        result = self.check_input_data(result)
        return result

    def read_as_dic_with_xy_position_for_range(self, sheet_name='', xyxy=''):
        """
        선택된 영역안의 2차원자료를 사전형식으로 돌려 주는 것
        같은값을 발견하면, 주소를 추가하는 형태
        예: [["가나","다라"],["ab", "다라"]] => {"가나":[[1,1]], "다라":[[1,2], [2,2]],"ab":[[2,1]]}

        """
        return self.read_as_dic_with_xy_position(sheet_name, xyxy)

    def read_as_l1d_for_xline_base(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = []
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = sheet.Cells(x, y).Value
            result.append(one_value)
        result = self.check_input_data(result)
        return result

    def read_as_l1d_for_yline_base(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = [sheet.Cells(x, y).Value for y in range(y1, y2 + 1) for x in
                  range(x1, x2 + 1)]
        return result

    def read_as_list(self, sheet_name='', xyxy=''):
        """
        2차원의 듀플을 2차원 리스트로 만드는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        result = []
        for x in range(len(l2d)):
            temp = []
            for y in range(len(l2d[0])):
                value = l2d[x][y]
                if value:
                    pass
                else:
                    value = ""
                temp.append(value)
            result.append(temp)
        result = self.check_input_data(result)
        return result

    def read_as_text_for_range(self, sheet_name='', xyxy=''):
        """
        읽어온값 자체를 변경하지 않고 그대로 읽어오는 것 그자체로 text 형태로 돌려주는것 만약 스캔을 한 숫자가 .를 잘못 .으로 읽었다면
        48,100 => 48.1로 엑셀이 바로 인식을 하는데 이럴때 48.100 으로 읽어와서 바꾸는 방법을 하기위해 사용하는 방법
        """
        return self.read_as_text(sheet_name, xyxy)

    def read_cell(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return sheet.Cells(x1, y1).Value

    def read_check_date(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = self.check_input_data(rng.Value)
        return result

    def read_continious_range(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        bottom = x1
        while sheet.Cells(bottom + 1, y1).Value not in [None, '']:
            bottom = bottom + 1
        right = y1  # 오른쪽 열
        while sheet.Cells(x1, right + 1).Value not in [None, '']:
            right = right + 1
        result = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(bottom, right)).Value

        return result

    def read_continious_same_value(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        row = x1
        col = y1
        bottom = row  # 아래의 행을 찾는다
        while sheet.Cells(bottom + 1, col).Value not in [None, '']:
            bottom = bottom + 1
        right = col  # 오른쪽 열
        while sheet.Cells(row, right + 1).Value not in [None, '']:
            right = right + 1
        result = sheet.Range(sheet.Cells(row, col), sheet.Cells(bottom, right)).Value
        result = self.check_input_data(result)
        return result

    def read_datas_for_cell(self, sheet_name='', xy=''):
        """
        하나의 셀에 대한 중요한 정보들을 읽어오는 것        :param xy:
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        one_cell = sheet.Cells(x1, y1)
        result = {}
        y = result["x"] = xy[0]
        x = result["y"] = xy[1]
        result["value"] = one_cell.Value
        result["value2"] = one_cell.Value2
        result["formula"] = one_cell.Formula
        result["formular1c1"] = one_cell.FormulaR1C1
        result["text"] = one_cell.Text
        if result["value"] != "" and result["value"] != None:
            # 값이 없으면 font에 대한 것을 읽지 않는다
            result["font_dic"]["background"] = one_cell.Font.Background
            result["font_dic"]["bold"] = one_cell.Font.Bold
            result["font_dic"]["color"] = one_cell.Font.Color
            result["font_dic"]["colorindex"] = one_cell.Font.ColorIndex
            # result["font_dic"]["creator"] = one_cell.Font.Creator
            result["font_dic"]["style"] = one_cell.Font.FontStyle
            result["font_dic"]["italic"] = one_cell.Font.Italic
            result["font_dic"]["name"] = one_cell.Font.Name
            result["font_dic"]["size"] = one_cell.Font.Size
            result["font_dic"]["strikethrough"] = one_cell.Font.Strikethrough
            result["font_dic"]["subscript"] = one_cell.Font.Subscript
            result["font_dic"]["superscript"] = one_cell.Font.Superscript
            # result["font_dic"]["themecolor"] = one_cell.Font.ThemeColor
            # result["font_dic"]["themefont"] = one_cell.Font.ThemeFont
            # result["font_dic"]["tintandshade"] = one_cell.Font.TintAndShade
            result["font_dic"]["underline"] = one_cell.Font.Underline
        try:
            result["memo"] = one_cell.Comment.Text()
        except:
            result["memo"] = ""
        result["background_color"] = one_cell.Interior.Color
        result["background_colorindex"] = one_cell.Interior.ColorIndex
        result["numberformat"] = one_cell.NumberFormat
        if one_cell.Borders.LineStyle != -4142:
            if one_cell.Borders(7).LineStyle != -4142:
                # linestyle이 없으면 라인이 없는것으로 생각하고 나머지를 확인하지 않으면서 시간을 줄이는 것이다
                result["line_top_dic"]["style"] = one_cell.Borders(7).LineStyle
                result["line_top_dic"]["color"] = one_cell.Borders(7).Color
                result["line_top_dic"]["colorindex"] = one_cell.Borders(7).ColorIndex
                result["line_top_dic"]["thick"] = one_cell.Borders(7).Weight
                result["line_top_dic"]["tintandshade"] = one_cell.Borders(7).TintAndShade
            if one_cell.Borders(8).LineStyle != -4142:
                result["line_bottom_dic"]["style"] = one_cell.Borders(8).LineStyle
                result["line_bottom_dic"]["color"] = one_cell.Borders(8).Color
                result["line_bottom_dic"]["colorindex"] = one_cell.Borders(8).ColorIndex
                result["line_bottom_dic"]["thick"] = one_cell.Borders(8).Weight
                result["line_bottom_dic"]["tintandshade"] = one_cell.Borders(8).TintAndShade
            if one_cell.Borders(9).LineStyle != -4142:
                result["line_left_dic"]["style"] = one_cell.Borders(9).LineStyle
                result["line_left_dic"]["color"] = one_cell.Borders(9).Color
                result["line_left_dic"]["colorindex"] = one_cell.Borders(9).ColorIndex
                result["line_left_dic"]["thick"] = one_cell.Borders(9).Weight
                result["line_left_dic"]["tintandshade"] = one_cell.Borders(9).TintAndShade
            if one_cell.Borders(10).LineStyle != -4142:
                result["line_right_dic"]["style"] = one_cell.Borders(10).LineStyle
                result["line_right_dic"]["color"] = one_cell.Borders(10).Color
                result["line_right_dic"]["colorindex"] = one_cell.Borders(10).ColorIndex
                result["line_right_dic"]["thick"] = one_cell.Borders(10).Weight
                result["line_right_dic"]["tintandshade"] = one_cell.Borders(10).TintAndShade
            if one_cell.Borders(11).LineStyle != -4142:
                result["line_x1_dic"]["style"] = one_cell.Borders(11).LineStyle
                result["line_x1_dic"]["color"] = one_cell.Borders(11).Color
                result["line_x1_dic"]["colorindex"] = one_cell.Borders(11).ColorIndex
                result["line_x1_dic"]["thick"] = one_cell.Borders(11).Weight
                result["line_x1_dic"]["tintandshade"] = one_cell.Borders(11).TintAndShade
            if one_cell.Borders(12).LineStyle != -4142:
                result["line_x2_dic"]["style"] = one_cell.Borders(12).LineStyle
                result["line_x2_dic"]["color"] = one_cell.Borders(12).Color
                result["line_x2_dic"]["colorindex"] = one_cell.Borders(12).ColorIndex
                result["line_x2_dic"]["thick"] = one_cell.Borders(12).Weight
                result["line_x2_dic"]["tintandshade"] = one_cell.Borders(12).TintAndShade

        return result

    def read_including_date_type(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = sheet.Range(sheet.Cells(x1, y1),
                                 sheet.Cells(x2, y2)).Value
        return result

    def read_memo(self, sheet_name='', xyxy=''):
        """
        입력영역의 처음 셀의 메모의 값을 읽어오는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return rng.Comment.Text()

    def read_memo_for_cell(self, sheet_name='', xyxy=''):
        """
        입력영역의 처음 셀의 메모의 값을 읽어오는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return rng.Comment.Text()

    def read_multi_cell(self, sheet_name, xyxy, xyxy_l2d):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        if not isinstance(xyxy_l2d[0], list):
            xyxy_l2d = [xyxy_l2d]
        result = []
        for xyxy in xyxy_l2d:
            one_value = self.check_input_data(sheet.Cells(x1, y1).Value)
            result.append(one_value)
        return result

    def read_multi_cell_for_sheet(self, sheet_name, xyxy_l2d):
        """
        추가) 여러셀값을 한번에 갖고오는것도 넣음
        """
        return self.read_multi_cell(sheet_name, xyxy_l2d)

    def read_n_char_from_start(self, sheet_name, xyxy, input_no):
        l2d = self.read(sheet_name, xyxy)
        result = []
        for l1d in l2d:
            temp = []
            for one in l1d:
                if isinstance(one, str):
                    temp.append(one[0:input_no])
                else:
                    temp.append("")
            result.append(temp)

        return result

    def read_n_char_from_start_for_range(self, sheet_name='', xyxy='', input_no=None):
        """
        자주 사용하는 자료의 변경 형태로, 셀값중 앞에서 n번째까지의 문자를 갖고와서 영역안의 자료를 리스트로 만드는 것입니다
        생각보다, 많이 사용하면서, 간단한것이라, 아마 불러서 사용하는것보다는 그냥 코드로 새롭게 작성하는경우가
        많겠지만, 그냥. . 그냥 만들어 보았다

        예를 들어 : 시군 구자료에서 앞의 2 글자만 분리해서 얻어오는 코드, 어떤자료중에 앞에서 몇번째것들만 갖고오고 싶을때
        """
        return self.read_multi_cell(sheet_name, xyxy, input_no)

    def read_n_write_with_two_sheet(self, sheet_name, input_xno, input_l2d=None):
        """
        현재 시트의 한줄을 읽어와서, 다른시트에 값을 넣는 경우
        """
        sheet = self.check_sheet_name("")
        one_list = self.read_value_for_range_as_l1d_for_xline_base(sheet_name, input_xno)[0]
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        for l1d in input_l2d:
            read_no, write_sheet, write_xy = l1d
            sheet.Cells(write_xy[0], write_xy[1]).Value = one_list[read_no - 1]

    def read_opened_workbook_filenames(self):
        """
        모든 열려있는 엑셀화일의 이름들을 갖고옵니다
        """
        return [one.Name for one in self.xlapp.Workbooks]

    def read_range(self, sheet_name='', xyxy=''):
        return self.read(sheet_name, xyxy)

    def read_range_as_dic_with_xy_position(self, sheet_name='', xyxy=''):
        """
        영역안의 자료를 사전형식으로 돌려 주는 것
        """
        result = {}
        list_2d = self.read(sheet_name, xyxy)
        for index_x, list_1d in enumerate(list_2d):
            for index_y, one_value in enumerate(list_1d):
                if one_value in result.keys():
                    result[one_value].append([index_x + 1, index_y + 1])
                else:
                    result[one_value] = [[index_x + 1, index_y + 1]]
        return result

    def read_range_as_l1d_by_xline_base(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        result = []
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            result.append(one_value)
        result = self.check_input_data(result)
        return result

    def read_range_as_l1d_by_yline_base(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = [sheet.Cells(x, y).Value for y in range(y1, y2 + 1) for x in range(x1, x2 + 1)]
        return result

    def read_range_name(self,sheet_name, range_name):
        xyxy = self.get_address_for_range_name(range_name)
        result = self.read(sheet_name, xyxy)
        return result

    def read_same_value_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 자료중에서 고유한 자료만을 골라내는 것이다
        1. 관련 자료를 읽어온다
        2. 자료중에서 고유한것을 찾아낸다
        3. 선택영역에 다시 쓴다
        """
        return self.read_same_value(sheet_name, xyxy)

    def read_sheet_name_by_position_no(self, input_no):
        """
        선택된 시트를 앞에서 몇번째로 이동시키는 것
        """
        sheets_name = self.get_all_sheet_name()
        result = sheets_name[input_no - 1]
        return result

    def read_sheet_name_for_activesheet(self):
        """
        read_name_for_activesheet()
        간략설명 : 현재의 활성화된 시트의 이름을 돌려준다
        출력형태 : 시트이름
        """
        return self.xlapp.ActiveSheet.Name

    def read_textboxes_as_l1d(self, sheet_name):
        sheet = self.check_sheet_name(sheet_name)
        result = []
        for shape in sheet.Shapes:
            if shape.Type == 17:  #
                text = shape.TextFrame.Characters().Text
                result.append(text)
        result = self.check_input_data(result)
        return result

    def read_unique_value(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read(sheet_name, xyxy)
        unique_value = set()
        for l1d in l2d:
            for one_data in l1d:
                unique_value.add(one_data)
        return list(unique_value)

    def read_unique_value_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 자료중에서 고유한 자료만을 골라내는 것이다
        1. 관련 자료를 읽어온다
        2. 자료중에서 고유한것을 찾아낸다
        3. 선택영역에 다시 쓴다
        """
        return self.read_unique_value(sheet_name, xyxy)

    def read_value2_for_cell(self, sheet_name='', xyxy=''):
        """
        엑셀의 값중에서 화면에 보여지는 값을 읽어오는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = sheet.Cells(x1, y1).Value2
        return result

    def read_value2_for_range(self, sheet_name='', xyxy=''):
        """
        엑셀의 값중에서 화면에 보여지는 값을 읽어오는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = rng.Value2
        result = self.check_input_data(result)
        return result

    def read_value3_for_cell(self, sheet_name='', xyxy=''):
        """
        읽어온값 자체를 변경하지 않고 그대로 읽어오는 것
        그자체로 text형태로 돌려주는것
        만약 스캔을 한 숫자가 ,를 잘못 .으로 읽었다면
        48,100 => 48.1로 엑셀이 바로 인식을 하는데
        이럴때 48.100으로 읽어와서 바꾸는 방법을 하기위해 사용하는 방법
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return sheet.Cells(x1, y1).Text

    def read_value3_for_range(self, sheet_name='', xyxy=''):
        """
        엑셀의 값중에서 화면에 보여지는 값을 읽어오는 것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = rng.Value3
        result = self.check_input_data(result)
        return result

    def read_value_check_date(self, sheet_name='', xyxy=''):
        """
        영역의 자료를 읽어와서
        - 모든 자료를 리스트로 바꿔준다
        - 날짜와 시간의 자료가 있으면, 의미가있는 영역까지만 나타냄
        """

        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = self.check_input_data(rng.Value)
        return result

    def read_value_check_date_for_range(self, sheet_name='', xyxy=''):
        """
        영역의 자료를 읽어와서
        - 모든 자료를 리스트로 바꿔준다
        - 날짜와 시간의 자료가 있으면, 의미가있는 영역까지만 나타냄
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = self.check_input_data(rng.Value)
        return result

    def read_value_for_activecell(self):
        """
        현재셀의 값을 돌려주는것
        """
        result = self.xlapp.ActiveCell.Value2
        result = self.check_input_data(result)
        return result

    def read_value_for_activecell_n_yno(self, input_yno):
        """
        현재 선택된 셀의 x번호와 입력받은 y줄의 번호를 조합한 셀의 값을 읽어오는것

        """
        xyxy = self.get_address_for_activecell()
        value = self.read_value_for_cell("", [xyxy[0], input_yno])
        value = self.check_input_data(value)
        return value

    def read_value_for_cell(self, sheet_name='', xyxy=''):
        """
        주) value -> value2
        값을 일정한 영역에서 갖고온다
        만약 영역을 두개만 주면 처음과 끝의 영역을 받은것으로 간주해서 알아서 처리하도록 변경하였다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        one_value = sheet.Cells(x1, y1).Value
        one_value = self.check_input_data(one_value)
        return one_value

    def read_value_for_cell_as_text(self, sheet_name='', xyxy=''):
        """
        읽어온값 자체를 변경하지 않고 그대로 읽어오는 것
        그자체로 text형태로 돌려주는것
        만약 스캔을 한 숫자가 ,를 잘못 .으로 읽었다면
        48,100 => 48.1로 엑셀이 바로 인식을 하는데
        이럴때 48.100으로 읽어와서 바꾸는 방법을 하기위해 사용하는 방법

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        return sheet.Cells(x1, y1).Text

    def read_value_for_continious_range(self, sheet_name='', xyxy=''):
        """
        read_continiousrange_value(sheet_name='', xyxy='')
        현재선택된 셀을 기준으로 연속된 영역을 가지고 오는 것입니다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        row = xyxy
        col = xyxy
        sheet = self.xlBook.Worksheets(sheet_name)
        bottom = row  # 아래의 행을 찾는다
        while sheet.Cells(bottom + 1, col).Value not in [None, '']:
            bottom = bottom + 1
        right = col  # 오른쪽 열
        while sheet.Cells(row, right + 1).Value not in [None, '']:
            right = right + 1
        result = sheet.Range(sheet.Cells(row, col), sheet.Cells(bottom, right)).Value
        result = self.check_input_data(result)
        return result

    def read_value_for_multi_cell(self, sheet_name, xyxy_l2d=None):
        """
        추가) 여러셀값을 한번에 갖고오는것도 넣음

        """
        if not isinstance(xyxy_l2d[0], list):
            xyxy_l2d = [xyxy_l2d]
        result = []
        for xyxy in xyxy_l2d:
            sheet = self.check_sheet_name(sheet_name)
            x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
            one_value = sheet.Cells(x1, y1).Value
            if isinstance(one_value, int):
                one_value = int(one_value)
            elif one_value == None:
                one_value = ""
            result.append(one_value)
        result = self.check_input_data(result)
        return result

    def read_value_for_range(self, sheet_name='', xyxy=''):
        """
        영역의 값을 갖고온다
        주) 원래는 value였으나 pyside6에서 코딩중에 날짜부분이 문제가 일으키는데 value2로 변경하니 문제가 없어서 변경함

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        result = self.check_input_data(l2d)
        return result

    def read_value_for_range_as_dic_with_xy_position(self, sheet_name='', xyxy=''):
        """
        선택된 영역안의 2차원자료를 사전형식으로 돌려 주는 것
        같은값을 발견하면, 주소를 추가하는 형태
        예: [["가나","다라"],["ab", "다라"]] => {"가나":[[1,1]], "다라":[[1,2], [2,2]],"ab":[[2,1]]}

        """
        result = {}
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                if one_value in result.keys():
                    result[one_value].append([ix + 1, iy + 1])
                else:
                    result[one_value] = [[ix + 1, iy + 1]]
        result = self.check_input_data(result)
        return result

    def read_value_for_range_as_l1d_for_xline_base(self, sheet_name='', xyxy=''):
        """
        2 차원의 자료를 1차원으로 만드는 것이며, 가로로 이동하면서 읽는 형식

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_type_to_l2d(rng.Value)

        result = []
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = l2d[x - x1][y - y1]
            result.append(one_value)
        result = self.check_input_data(result)
        return result

    def read_value_for_range_as_l1d_for_yline_base(self, sheet_name='', xyxy=''):
        """
        2차원의 자료를 1차원으로 만드는 것이며, 세로로 내려가면서 읽는 형식

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = [sheet.Cells(x, y).Value for y in range(y1, y2 + 1) for x in range(x1, x2 + 1)]

        return result

    def read_value_for_range_as_list(self, sheet_name='', xyxy=''):
        """
        2차원의 듀플을 2차원 리스트로 만드는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        result = []
        for x in range(len(l2d)):
            temp = []
            for y in range(len(l2d[0])):
                value = l2d[x][y]
                if value:
                    pass
                else:
                    value = ""
                temp.append(value)
            result.append(temp)
        result = self.check_input_data(result)
        return result

    def read_value_for_range_as_text(self, sheet_name='', xyxy=''):
        """
        읽어온값 자체를 변경하지 않고 그대로 읽어오는 것 그자체로 text 형태로 돌려주는것 만약 스캔을 한 숫자가 .를 잘못 .으로 읽었다면
        48,100 => 48.1로 엑셀이 바로 인식을 하는데 이럴때 48.100 으로 읽어와서 바꾸는 방법을 하기위해 사용하는 방법

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = []
        for x in range(x1, x2 + 1):
            temp = []
            for y in range(y1, y2 + 1):
                one_value = sheet.Cells(x, y).Text
                temp.append(one_value)
            result.append(temp)
        return result

    def read_value_for_range_for_continious_same_value(self, sheet_name='', xyxy=''):
        """
        현재선택된 셀을 기준으로 연속된 영역을 가지고 오는 것입니다

        """
        row = xyxy
        col = xyxy
        sheet = self.check_sheet_name(sheet_name)
        bottom = row  # 아래의 행을 찾는다
        while sheet.Cells(bottom + 1, col).Value not in [None, '']:
            bottom = bottom + 1
        right = col  # 오른쪽 열
        while sheet.Cells(row, right + 1).Value not in [None, '']:
            right = right + 1
        result = sheet.Range(sheet.Cells(row, col), sheet.Cells(bottom, right)).Value
        result = self.check_input_data(result)
        return result

    def read_value_for_range_for_unique_value(self, sheet_name='', xyxy=''):
        """
        선택한 자료중에서 고유한 자료만을 골라내는 것이다
        1. 관련 자료를 읽어온다
        2. 자료중에서 고유한것을 찾아낸다
        3. 선택영역에 다시 쓴다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        result = set()
        for l1d in l2d:
            for one_value in l1d:
                if one_value:
                    result.add(one_value)
        result = self.check_input_data(list(result))
        return result

    def read_value_for_range_name(self, sheet_name, range_name):
        """
        이름영역으로 값을 읽어오는 것
        """
        xyxy = self.get_address_for_range_name(sheet_name, range_name)
        result = self.read_value_for_range(sheet_name, xyxy)
        return result

    def read_value_for_range_with_numberformat(self, sheet_name='', xyxy=''):
        """
        속성을 포함한 값을 읽어오는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        result = []
        for x in range(x1, x2 + 1):
            temp = []
            for y in range(y1, y2 + 1):
                one_dic = {}
                one_cell = sheet.Cells(x, y)
                one_dic["y"] = x
                one_dic["x"] = y
                one_dic["value"] = one_cell.Value
                one_dic["value2"] = one_cell.Value2
                one_dic["text"] = one_cell.Text
                one_dic["formula"] = one_cell.Formula
                one_dic["formular1c1"] = one_cell.FormulaR1C1
                one_dic["numberformat"] = one_cell.NumberFormat
                temp.append(one_dic)
            result.append(temp)
        result = self.check_input_data(result)
        return result

    def read_value_for_range_with_xy_headers(self, sheet_name='', xyxy=''):
        """
        영역의 값을 갖고온다. 맨앞과 위에 번호로 행과열을 추가한다
        가끔은 자료중에서 필요없는것을 삭제했더니, 원래 있었던 자료의 위치를 알수가 없어서, 만들어 본것임

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        top_line = list(range(y1 - 1, y2 + 1))

        all_data = list(rng.Value2)
        result = []
        for x in range(0, x2 - x1 + 1):
            temp = [x + 1]
            temp.extend(list(all_data[x]))
            result.append(temp)
        result.insert(0, top_line)
        result = self.check_input_data(result)
        return result

    def read_value_for_selection(self, sheet_name=''):
        """
        값을 일정한 영역에서 갖고온다
        만약 영역을 두개만 주면 처음과 끝의 영역을 받은것으로 간주해서 알아서 처리하도록 변경하였다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, '')
        result = rng.Value
        result = self.check_input_data(result)
        return result

    def read_value_for_textboxes_as_l1d(self, sheet_name=''):
        """
        모든 텍스트 박스의 값을 읽어보는 것
        """
        result = []
        sheet = self.check_sheet_name(sheet_name)
        for shape in sheet.Shapes:
            if shape.Type == 17:  #
                text = shape.TextFrame.Characters().Text
                result.append(text)
        result = self.check_input_data(result)
        return result

    def read_value_for_usedrange(self, sheet_name=''):
        """
        usedrange 안의 값을 갖고온다

        """
        sheet = self.check_sheet_name(sheet_name)
        xyxy = self.change_address_to_xyxy(sheet.UsedRange.Address)
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        result = sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x2, y2)).Value
        result = self.check_input_data(result)
        return result

    def read_value_for_xline(self, sheet_name, xx_list):
        """
        한줄인 x라인 의 모든값을 읽어온다

        """
        sheet = self.check_sheet_name(sheet_name)
        x1, x2 = self.check_xx_address(xx_list)
        result = sheet.Range(sheet.Cells(x1, 1), sheet.Cells(x1, 1)).EntireRow.Value2
        result = self.check_input_data(result)
        return result

    def read_value_for_xline_at_activecell(self):
        """
        현재 활성화된 셀이 있는 한줄을 읽어옵니다

        """
        sheet = self.check_sheet_name("")
        xyxy = self.change_address_to_xyxy(self.xlapp.ActiveCell.Address)
        result = sheet.Cells(xyxy[0], 1).EntireRow.Value2[0]
        result = self.check_input_data(result)
        return result

    def read_value_for_xxline(self, sheet_name, xx_list):
        """
        xx_list라인의 모든값을 읽어온다

        """
        sheet = self.check_sheet_name(sheet_name)
        result = sheet.Range(sheet.Cells(xx_list[0], 1),
                                 sheet.Cells(xx_list[1], 1)).EntireRow.Value2
        result = self.check_input_data(result)
        return result

    def read_value_for_xywh(self, sheet_name, input_xywh):
        """
        시작점을 기준으로 가로세로의 갯수만큼의 값을 읽어오는 것이다

        """
        xyxy = [input_xywh[0], input_xywh[1], input_xywh[0] + input_xywh[2] - 1, input_xywh[1] + input_xywh[3] - 1]
        result = self.read_value_for_range(sheet_name, xyxy)
        result = self.check_input_data(result)
        return result

    def read_value_for_yline(self, sheet_name, yy_list):
        """
        한줄인 y라인의 모든값을 읽어온다

        """
        sheet = self.check_sheet_name(sheet_name)
        y1, y2 = self.check_yy_address(yy_list)
        result = sheet.Range(sheet.Cells(1, y1),
                                 sheet.Cells(1, y1)).EntireColumn.Value2

        result = self.check_input_data(result)
        return result

    def read_value_for_yline_at_activecell(self, sheet_name=''):
        """
        사용된 범위안에서 현재셀이 선택된 y 라인 한줄을 갖고오는 것 영역을 가르킬때는 가장 왼쪽위의 셀을 기준으로 한다
        """
        xyxy = self.get_address_for_activecell()
        xyxy2 = self.get_address_for_usedrange(sheet_name)
        result = self.read_value_for_range(sheet_name, [1, xyxy[1], 1, xyxy2[2]])[0]
        result = self.check_input_data(result)
        return result

    def read_value_for_yyline(self, sheet_name, yy_list):
        """
        read_yyline_value(sheet_name="", xx_list)
        가로줄들의 전체의 값을 읽어온다

        """
        sheet = self.check_sheet_name(sheet_name)
        result = sheet.Range(sheet.Cells(yy_list[0], 1), sheet.Cells(yy_list[1], 1)).EntireRow.Value
        result = self.check_input_data(result)
        return result

    def read_value_including_date_type(self, sheet_name='', xyxy=''):
        """
        영역의 값을 갖고온다
        단, 날짜 type의 그 자체로 읽어오는 것이다
        주) 원래는 value였으나 pyside6에서 코딩중에 날짜부분이 문제가 일으키는데 value2로 변경하니 문제가 없어서 변경함

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = rng.Value
        return result

    def read_with_numberformat(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        result = []
        for x in range(x1, x2 + 1):
            temp = []
            for y in range(y1, y2 + 1):
                one_dic = {}
                one_cell = sheet.Cells(x, y)
                one_dic["y"] = x
                one_dic["x"] = y
                one_dic["value"] = one_cell.Value
                one_dic["value2"] = one_cell.Value2
                one_dic["text"] = one_cell.Text
                one_dic["formula"] = one_cell.Formula
                one_dic["formular1c1"] = one_cell.FormulaR1C1
                one_dic["numberformat"] = one_cell.NumberFormat
                temp.append(one_dic)
            result.append(temp)
        result = self.check_input_data(result)
        return result

    def read_with_xy_headers(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        top_line = list(range(y1 - 1, y2 + 1))

        all_data = list(rng.Value2)
        result = []
        for x in range(0, x2 - x1 + 1):
            temp = [x + 1]
            temp.extend(list(all_data[x]))
            result.append(temp)
        result.insert(0, top_line)
        result = self.check_input_data(result)
        return result

    def read_xline_at_activecell(self):
        """
        현재 활성화된 셀이 있는 한줄을 읽어옵니다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy('', '')
        xyxy = self.change_address_to_xyxy(self.xlapp.ActiveCell.Address)
        result = sheet.Cells(xyxy[0], 1).EntireRow.Value2[0]
        result = self.check_input_data(result)
        return result

    def read_yline_at_activecell(self, sheet_name=''):
        """
        사용된 범위안에서 현재셀이 선택된 y 라인 한줄을 갖고오는 것 영역을 가르킬때는 가장 왼쪽위의 셀을 기준으로 한다
        """
        xyxy = self.get_address_for_activecell()
        xyxy2 = self.get_address_for_usedrange(sheet_name)
        result = self.read_value_for_range(sheet_name, [1, xyxy[1], 1, xyxy2[2]])[0]
        result = self.check_input_data(result)
        return result

    def regroup_for_beside_xline_style(self, input_l2d, start_xy):
        """
        input_l2d형태의 값과 그 값의 시작위치를 주면,
        그 값이 x축이 연속인 칼인경우 류어서 한번에 쓰수있는 형태로 만들어 주는것
        x축이라는 뜻은 연속된 값이 1차원의 형태로 정의된것이다

        """
        result = []
        for ix, l1d in enumerate(input_l2d):
            for iy, one in enumerate(l1d):
                result.append([ix + start_xy[0], iy + start_xy[1], input_l2d[ix][iy]])
        sorted_data = sorted(result, key=lambda item: (item[0], item[1]))
        result = [[sorted_data[0][0], sorted_data[0][1], sorted_data[0][0], sorted_data[0][1], [sorted_data[0][2]]]]
        for x, y, val in sorted_data[1:]:
            if x == result[-1][2] and y == result[-1][3] + 1:
                result[-1][3] = result[-1][3] + 1
                result[-1][4].append(val)
            else:
                result.append([x, y, x, y, [val]])
        return result

    def regroup_for_beside_yline_style(self, input_l2d, start_xy):
        """
        input_l2d형태의 값과 그 값의 시작위치를 주면,
        그 값이 y축이 연속인 값인 경우 이어서 한번에 쓸수있는 형태로 만들어 주는것
        y축이라는 뜻은 연속된 값이 2차원의 형태로 정의된것이다

        """
        result = []
        for ix, l1d in enumerate(input_l2d):
            for iy, lid in enumerate(l1d):
                result.append([ix + start_xy[0], iy + start_xy[1], input_l2d[ix][iy]])
        sorted_data = sorted(result, key=lambda item: (item[1], item[0]))  # 1. 경렬 (세로 우선, 가로 차선)
        result = [[sorted_data[0][0], sorted_data[0][1], sorted_data[0][0], sorted_data[0][1], [[sorted_data[0][2]]]]]
        for x, y, val in sorted_data[1:]:
            if x == result[-1][2] + 1 and y == result[-1][1]:
                result[-1][2] = result[-1][2]
                result[-1][4].append([val])
            else:
                result.append([x, y, x, y, [[val]]])
        return result

    def regroup_l2d_by_each_nea(self, input_l2d, input_index):
        """
        2차원의 자료를 번호를 기준으로 그룹화하는것

        """
        result = []
        # 2차원자료를 원하는 열을 기준으로 정렬
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        sorted_input_l2d = self.xyutil.sort_l2d_by_index(input_l2d, input_index)

        check_value = sorted_input_l2d[0][input_index]
        temp = []
        for one_list in sorted_input_l2d:
            if one_list[input_index] == check_value:
                temp.append(one_list)
            else:
                result.append(temp)
                temp = [one_list]
                check_value = one_list[input_index]
        if temp:
            result.append(temp)
        return result

    def remove_paint_for_range(self, sheet_name='', xyxy=''):
        """
        셀의 배경색을 input_color형식으로 칠하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Interior.ColorIndex = 0

    def replace_first_char_for_range(self, sheet_name='', xyxy='', input_l2d=None):
        """
        가끔 맨 앞글자만 바꾸고 싶을때가 있다
        그럴때 사용하는 것으로, 한번에 여러개도 가능하도록 만들었다

        사용법 : change_first_char("", [1,1,100,1], [["'", ""], ["*", ""], [" ", ""],])

        """
        self.replace_first_char(sheet_name, xyxy, input_l2d)

    def replace_last_char_for_range(self, sheet_name='', xyxy='', input_l2d=None):
        """
        가끔 맨 뒷글자만 바꾸고 싶을때가 있다
        그럴때 사용하는 것으로, 한번에 여러개도 가능하도록 만들었다
        사용법 : ("", [1,1,100,1], [["'", ""], ["*", ""], [" ", ""],])

        """
        self.replace_last_char(sheet_name, xyxy, input_l2d)

    def replace_many_word_for_range(self, sheet_name, xyxy, input_list):
        """
        한번에 여러 갯수를 바꾸는 것이다

        """
        input_list = self.check_input_data(input_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = str(self.read_value_for_cell(sheet_name, [x, y]))
            if one_value:
                for one_xylist in input_list:
                    one_value = one_value.replace(one_xylist[0], one_xylist[1])
                sheet.Cells(x, y).Value = one_value

    def replace_value_for_range(self, sheet_name, xyxy, old_word="abc1", new_word="ddd1", part_or_whole_tf=False, direction=1, case_tf=False, byte_type_tf=False, cell_format_tf=False,
                                replace_cell_format_tf=False):
        """
        만약 * 또는 ? 기호가 포함된 데이터를 찾거나 수식에 포함하고 싶다면 해당 문자 앞에 ~(물결표)를 붙여주면 됩니다.
        바꾸기를 하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Replace(old_word, new_word, part_or_whole_tf, direction, case_tf, byte_type_tf, cell_format_tf,
                          replace_cell_format_tf)

    def replace_with_xre_as_selection_directly(self, input_xre, replace_text):
        """
        엑셀의 선택한 부분을 그대로 변경하는 것

        """
        sheet = self.check_sheet_name("")
        xyxy = self.get_address_for_selection()

        for x in range(xyxy[0], xyxy[2] + 1):
            for y in range(xyxy[1], xyxy[3] + 1):
                value = sheet.Cells(x, y).Value
                sheet.Cells(x, y).Value = self.xyre.replace_with_xsql(input_xre, replace_text, value)

    def resize_data_for_range(self, input_l2d, xyxy):
        """
        xyxy영역안에만 자료를 만들려고 할때, 이영역안의 맞도록 자료를 변경하는 것

        """
        result = []
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        if len(input_l2d) > x2 - x1 + 1:
            input_l2d = input_l2d[:x2 - x1 + 1]

        for l1d in input_l2d:
            if len(l1d) > y2 - y1 + 1:
                l1d = l1d[:y2 - y1 + 1]
            result.append(l1d)
        return result

    def resize_image_to_fit_xyxy(self, image_no, image_ratio_lock_tf):
        aaa = self.get_pxywh()
        bbb = self.count_shape_in_sheet(image_no, aaa[2], aaa[3], image_ratio_lock_tf)
        self.move_shape_position(image_no, aaa[1], aaa[0])

    def resize_image_to_fit_xyxy_for_sheet(self, sheet_name, xyxy, image_no=5, image_ratio_lock_tf=True):
        """
        엑셀의 사진을 입력영역에 맞게 이동시키고 크기를 맞추는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        aaa = self.get_pxywh_for_range(sheet_name, xyxy)
        bbb = self.count_shape_in_sheet(sheet_name, image_no, aaa[2], aaa[3], image_ratio_lock_tf)
        self.move_shape_position(sheet_name, image_no, aaa[1], aaa[0])

    def resize_l2d_for_range(self, input_l2d, xyxy):
        """
        영역에 맞도록 입력 자룔를 이영역안의 맞도록 자료를 변경하는 것
        만약 xyxy가 더 크면, None을 집어 넣는다

        """
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        result = self.xyutil.resize_l2d(input_l2d, 0, 0, (x2 - x1), (y2 - y1))
        return result

    def reverse_l2d_top_n_bottom(self, sheet_name='', xyxy=''):
        l2d = self.read(sheet_name, xyxy)
        result = self.xyutil.change_xylist_to_yxlist(l2d)
        return result

    def rotate_shape_by_name(self, shape_obj, rotation_degree=90):
        """
        도형을 회전시키는 것
        도형은 중간을 기준으로 회전을 합니다

        """
        shape_obj.Rotation = rotation_degree

    def round_float_from_nth_position(self, sheet_name, xyxy, input_no):
        # 파이썬의 round(number, n) 함수는 number를 소수점 n자리까지 반올림합니다.
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            one_value = sheet.Cells(x, y).Value
            if isinstance(one_value, float):
                rounded_value = round(one_value, input_no)
                sheet.Cells(x, y).Value = rounded_value

    def round_float_from_nth_position_for_range(self, sheet_name='', xyxy='', input_no=123):
        """
        입력된 숫자를 소수점 아래 n번째 자리까지 남기고 반올림합니다.
        (n+1)번째 자리에서 반올림이 수행됩니다.

        :return: 반올림된 실수 값입니다.
        """
        self.read_multi_cell(sheet_name, xyxy, input_no)

    def run_vba_module(self, macro_name):
        """
        텍스트로 만든 매크로 코드를 실행하는 코드이다

        """
        self.xlapp.Run(macro_name)

    def save(self, input_filename):
        """
        엑셀화일을 저장하는것

        """
        if input_filename == "":
            self.xlbook.Save()
        else:
            self.xlbook.SaveAs(input_filename, 51)

    def screen_maxmized(self):
        """
        엑셀화일을 최대화합니다
        """
        self.xlapp.WindowState = -4137

    def screen_minimized(self):
        """
        엑셀화일을 최소화합니다

        xlMaximized : -4137
        xlMinimized : -4140
        xlNormal : -4143
        """
        self.xlapp.WindowState = -4140

    def screen_updating_off(self):
        self.xlapp.ScreenUpdating = True
        self.xlapp.Calculation = -4105

    def screen_updating_on(self):
        self.xlapp.ScreenUpdating = False
        self.xlapp.Calculation = -4135

    def scrollbar_for_sheet(self, sheet_name='', xyxy=''):
        """
        엑셀의 시트에 스크롤바의 형태를 설정하는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        pxywh = self.change_address_to_pxywh(sheet_name, xyxy)
        scrollbar_obj = sheet.Shapes.AddFormControl(Type=8, Left=pxywh[0], Top=pxywh[1], Width=pxywh[2],
                                                        Height=pxywh[3])
        scrollbar_obj.Name = "abc_1"
        scrollbar_obj.ControlFormat.Value = 4
        scrollbar_obj.ControlFormat.Min = 0
        scrollbar_obj.ControlFormat.Max = 359
        scrollbar_obj.ControlFormat.SmallChange = 1
        scrollbar_obj.ControlFormat.LargeChange = 10
        scrollbar_obj.ControlFormat.LinkedCell = "$A$1"

    def search_nth_continious_value(self, input_value, line_no):
        """
        넘어온 자료중 line_no번째의 연속된 자료가 같은 갯수를 세어서 리스트형태로 돌려주는것

        """
        result = []
        num = 1
        for no in range(len(input_value) - 1):
            if input_value[no][line_no] == input_value[no + 1][line_no]:
                # 위와 아래의 Item이 같은것일때
                num = num + 1
            else:
                result.append(num)
                num = 1
        return result

    def search_password_for_unlock_sheet(self, num_tf="yes", text_small_tf="yes", text_big_tf="yes", special_tf="no", len_num=10):
        """
        엑셀시트의 암호를 풀기위해 암호를 계속 만들어서 확인하는 것
        메뉴에서 제외

        """
        check_char = []
        if num_tf == "yes":
            check_char.extend(list(string.digits))
        if text_small_tf == "yes":
            check_char.extend(list(string.ascii_lowercase))
        if text_big_tf == "yes":
            check_char.extend(list(string.ascii_uppercase))
        if special_tf == "yes":
            for one in "!@#$%^*_-":
                check_char.extend(one)

        zz = itertools.combinations_with_replacement(check_char, len_num)
        for aa in zz:
            try:
                pswd = "".join(aa)
                self.sheet_lock("", pswd)
                break
            except:
                pass

    def search_sheet_hwnd(self, excel_hwnd):
        """
        시트의 핸들값을 갖고오는 것

        """
        child_windows = self.enum_child_windows(excel_hwnd)
        sheet_hwnd = None
        for child in child_windows:
            class_name = win32gui.GetClassName(child)
            if class_name == "EXCEL7":
                sheet_hwnd = child
                break
        return sheet_hwnd

    def search_value_by_xre_for_range_with_paint(self, sheet_name, xyxy, input_xre, input_color):
        """
        영역의 값중에서 입력으로 들어온 xre형식의 정규표현식에 맞는 것이 있으면, 그 셀에 색칠하기

        """
        return self.search_value_by_xre_with_paint(sheet_name, xyxy, input_xre, input_color)

    def search_value_by_xre_with_paint(self, sheet_name, xyxy, input_xre, input_color):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rgbint = self.xycolor.change_xcolor_to_rgbint(input_color)
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                one_value = sheet.Cells(x, y).Value2
                found_or_not = self.xyre.search_all_by_xsql(input_xre, str(one_value))
                if found_or_not:
                    sheet.Cells(x, y).Interior.Color = rgbint

    def search_xre_for_selection_with_new_sheet(self, sheet_name, xyxy, input_xre):
        """
        엑셀의 현재 선택한 영역의 셀들을 적용한후에 새로운 시트에 그 결과를 나타내주는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read_value_for_range("", "")
        result_l2d = self.xyre.match_for_l2d_by_xsql(input_xre, l2d)
        self.new_sheet()
        self.write_l2d_from_cell("", [1, 1], result_l2d)

    def select(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Select()

    def select_all(self, sheet_name=''):
        """
        모든 영역을 선택한다

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Cells.Select()

    def select_all_cell_for_sheet(self, sheet_name=''):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Cells.Select()

    def select_bottom_cell_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 위치에서 제일왼쪽, 제일아래로 이동
        xlDown: - 4121,xlToLeft : - 4159, xlToRight: - 4161, xlUp : - 4162

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4121).Select()

    def select_bottom_of_selection(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4121).Select()

    def select_by_offset(self, oxyxy=""):
        """
        현재의 셀 위치에서, offset으로 옮기는 것

        """
        sheet = self.check_sheet_name("")
        x1, y1, x2, y2 = self.get_address_for_selection()
        ox1, oy1, ox2, oy2 = self.change_address_to_xyxy(oxyxy)
        rng = sheet.Range(sheet.Cells(x1 + ox1, y1 + oy1), sheet.Cells(x2 + ox2, y2 + oy2))
        rng.Select()

    def select_cell_by_xy_step(self,sheet_name, xyxy):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        xyxy2 = self.get_address_for_activecell()
        sheet.Cells(xyxy2[0] + x1, xyxy2[1] + y1).Select()

    def select_cell_for_range_by_xy_step(self, sheet_name='', xyxy=''):
        """
        activecell을 offset으로 이동시키는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        xyxy2 = self.get_address_for_activecell()
        sheet.Cells(xyxy2[0] + x1, xyxy2[1] + y1).Select()

    def select_cells_for_sheet(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.Cells.Select()

    def select_currentregion_for_cell(self):
        address_usedrange = self.get_address_for_range_for_currentregion()
        self.select_xyxy(address_usedrange)

    def select_currentregion_for_cell_for_range(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.select_for_range(sheet_name, rng)

    def select_for_cell(self, sheet_name='', xyxy=''):
        """
        셀을 활성화 하는것은 셀을 선택하는것과 같으며
        만약 영역이 들어오면 가장 왼쪽위의 영역을 선택합니다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Select()

    def select_for_range(self, sheet_name='', xyxy=''):
        """
        영역을 선택한다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Select()
        result = rng.Address
        return result

    def select_left_end(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4159).Select()

    def select_left_end_cell(self, sheet_name='', xyxy=''):
        """
        입력값 : 입력값없이 사용가능
        선택한 위치에서 끝부분으로 이동하는것
        xlDown : - 4121, xlToLeft : - 4159, xlToRight : - 4161, xlUp : - 4162

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4159).Select()

    def select_left_end_cell_for_range(self, sheet_name='', xyxy=''):
        """
        입력값 : 입력값없이 사용가능
        선택한 위치에서 끝부분으로 이동하는것
        xlDown : - 4121, xlToLeft : - 4159, xlToRight : - 4161, xlUp : - 4162

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4159).Select()

    def select_multi_range(self, input_l2d):
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        [x1, y1, x2, y2] = self.change_address_to_xyxy(input_l2d[0])
        multi_range = self.new_range_for_range()

        if len(input_l2d) > 1:
            for index, one_range in enumerate(input_l2d[1:]):
                self.change_address_to_xyxy(one_range)
                range_2 = self.new_range_for_range()

                multi_range = self.xlapp.Union(multi_range, range_2)
        multi_range.Select()

    def select_multi_range_for_sheet(self, sheet_name, input_l2d):
        """
        영역을 선택한다

        """
        return self.select_multi_range(sheet_name, input_l2d)

    def select_range_for_range_name(self, input_l2d):
        self.select_range_name(input_l2d)

    def select_range_for_xxline(self, sheet_name, xx_list):
        self.select_xxline(sheet_name, xx_list)

    def select_range_for_yyline(self, sheet_name, yy_list):
        self.select_yyline(sheet_name, yy_list)

    def select_range_name(self, input_l2d):
        """
        여러 영역을 선택하는 방법
        이것은 이름영역의 주소형태를 다루는 것이다
        sheet_xyxy_list = [["시트이름1", [1,1,4,4]], ["시트이름2", []], ]

        """

        uninput_range = []

        if not isinstance(input_l2d, list):
            input_l2d = [input_l2d]

        for one_named_range in input_l2d:
            all_address, sheet, xyxy = self.get_address_name(one_named_range)

            sheet = self.check_sheet_name(sheet)
            x1, y1, x2, y2 = xyxy
            r1c1 = self.change_address_to_r1c1([x1, y1, x2, y2])
            rng = sheet.Range(r1c1)
            if uninput_range == []:
                uninput_range = rng
                check_name = sheet
            else:
                if check_name == sheet:
                    uninput_range = self.xlapp.Union(uninput_range, rng)
                else:
                    uninput_range.Select()
                    sheet.Select()
                    uninput_range = rng
                    check_name = sheet
            uninput_range.Select()

    def select_right_end_cell_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 위치에서 끝부분으로 이동하는것
        xlDown: - 4121,xlToLeft : - 4159, xlToRight: - 4161, xlUp : - 4162

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4161).Select()

    def select_right_end_of_selection(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4161).Select()

    def select_sheet(self, sheet_name=''):
        """
        시트이름으로 시트를 선택

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Select()

    def select_top_cell_for_range(self, sheet_name='', xyxy=''):
        """
        선택한 위치에서 끝부분으로 이동하는것
        xlDown: - 4121,xlToLeft : - 4159, xlToRight: - 4161, xlUp : - 4162

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.End(-4162).Select()

    def select_usedrange_for_sheet(self, sheet_name=''):
        """
        활성화된 시트의 사용역역인 usedrange를 선택하는 것

        """
        address_usedrange = self.get_address_for_usedrange(sheet_name)
        self.select_for_range(sheet_name, address_usedrange)

    def select_workbook(self, input_filename):
        """
        열려진 워드 화일중 이름으로 선택하는것

        """
        self.xlapp.Visible = True
        win32gui.SetForegroundWindow(self.xlapp.hwnd)
        self.xlapp.Workbooks(input_filename).Activate()
        self.xlapp.WindowState = win32com.client.constants.xlMaximized

    def select_xline(self, sheet_name, x_list):
        """
        하나의 가로줄을 선택하는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(x_list, int):
            x_list = [x_list]

        start = self.change_char_to_num(x_list[0])
        changed_address = str(start) + ":" + str(start)
        sheet.Rows(changed_address).Select()

    def select_xxline(self, sheet_name, xx_list):
        sheet = self.check_sheet_name(sheet_name)
        start = self.change_char_to_num(xx_list[0])
        end = self.change_char_to_num(xx_list[1])
        changed_address = str(start) + ":" + str(end)
        sheet.Rows(changed_address).Select()

    def select_xyxy(self, sheet_name='', xyxy=''):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Select()
        return [x1, y1, x2, y2]

    def select_yline(self, sheet_name, y_list):
        """
        하나의 세로열을 선택하는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(y_list, int):
            y_list = [y_list]

        start = self.change_num_to_char(y_list[0])
        changed_address = str(start) + ":" + str(start)
        sheet.Columns(changed_address).Select()

    def select_yyline(self, sheet_name, yy_list):
        sheet = self.check_sheet_name(sheet_name)
        start = self.change_num_to_char(yy_list[0])
        end = self.change_num_to_char(yy_list[1])

        changed_address = str(start) + ":" + str(end)
        sheet.Columns(changed_address).Select()

    def set_align_for_range(self, sheet_name, xyxy, x_align, y_align):
        """
        선택영역의 값들의 표시되는 형태를 나타내는 것으로, 가로형과 세로형의 형태를 지정하는 것이다
        가로와 세로 방향으로 모두 설정하는 것이다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        dic_x = {"right": -4152, "middle": -4108, "center": -4108, "left": -4131, "오른쪽": -4152, "중간": 2, "왼쪽": -4131}
        dic_y = {"middle": -4108, "center": -4108, "top": -4160, "bottom": -4107, "low": -4107, "중간": -4108, "위": -4160,
                 "아래": - 4107}
        if x_align: rng.HorizontalAlignment = dic_x[x_align]
        if y_align: rng.VerticalAlignment = dic_y[y_align]

    def set_align_for_x(self, sheet_name, xyxy, x_align):
        """
        선택영역의 값들의 표시되는 형태를 나타내는 것으로, 가로형과 세로형의 형태를 지정하는 것이다
        가로와 세로 방향으로 모두 설정하는 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        dic_x = {"right": -4152, "middle": -4108, "center": -4108, "left": -4131, "오른쪽": -4152, "중간": 2, "왼쪽": -4131}
        rng.HorizontalAlignment = dic_x[x_align]

    def set_align_for_y(self, sheet_name, xyxy, y_align):
        """
        선택영역의 값들의 표시되는 형태를 나타내는 것으로, 가로형과 세로형의 형태를 지정하는 것이다
        가로와 세로 방향으로 모두 설정하는 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        dic_y = {"middle": -4108, "center": -4108, "top": -4160, "bottom": -4107, "low": -4107, "중간": -4108, "위": -4160,
                 "아래": - 4107}
        rng.VerticalAlignment = dic_y[y_align]

    def set_auto_next_line(self, sheet_name='', xyxy='', input_value=None):
        """
        셀안에 들어가는 값이 셀영역을 넘어갈때 다음줄로 줄바꿈을 적용할것인지를 설정하는것
        만약 status를 false로 하면 줄바꿈이 실행되지 않는다.
        """
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.WrapText = input_value

    def set_auto_next_line_for_range(self, sheet_name='', xyxy='', input_value=None):
        """
        셀안에 들어가는 값이 셀영역을 넘어갈때 다음줄로 줄바꿈을 적용할것인지를 설정하는것
        만약 status를 false로 하면 줄바꿈이 실행되지 않는다.

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.WrapText = input_value

    def set_chart_fore_color(self, chart_obj, input_rgb):
        """
        차트의 forecolor를 설정하는 것

        """
        chart_obj.ChartArea.Format.Fill.ForeColor.RGB = input_rgb

    def set_chart_gridline(self, chart_obj):
        """
        차트의 그리드라인을 설정하는 것

        """
        chart_obj.Axes(2).MajorGridlines.Delete()
        chart_obj.Axes(2).MinorGridlines.Delete()

    def set_chart_legend(self, chart_obj, input_lrtb):
        """
        차트의 범례에대한 속성을 설정

        """
        lrtb_dic = {"left": 103, "right": 101, "top": 102, "bottom": 104}
        chart_obj.SetElement(lrtb_dic[input_lrtb])

    def set_chart_style(self, chart_obj, chart_style):
        """
        그래프의 형태를 정하는 것입니다

        """
        chart_style_vs_enum = {"line": 4, "pie": 5}
        checked_chart_no = chart_style_vs_enum[chart_style]
        chart_obj.ChartType = checked_chart_no
        return chart_obj

    def set_chart_x_scale(self, chart_obj, min_scale="", max_scale=""):
        """
        차트의 속성을 설정 : x_scale

        """
        temp = chart_obj.Axes(1)
        temp.MinimumScale = min_scale
        temp.MaximumScale = max_scale

    def set_chart_x_title(self, chart_obj, xtitle="", input_size=12, input_color="", is_bold_tf=True):
        """
        차트의 속성을 설정 : x_title

        """
        temp = chart_obj.Axes(1)  # 1 : xlCategory, 3 :xlSeriesAxis, 2 : xlValue, 1: primary, 2 : secondary
        temp.HasTitle = True
        temp.AxisTitle.Text = xtitle
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Bold = is_bold_tf
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Size = input_size

    def set_chart_y_scale(self, chart_obj, min_scale="", max_scale=""):
        """
        차트의 속성을 설정 : y_scale

        """
        temp = chart_obj.Axes(2)
        temp.MinimumScale = min_scale
        temp.MaximumScale = max_scale

    def set_chart_y_title(self, chart_obj, xtitle="제목1", size="", color="", bold=""):
        """
        차트의 속성을 설정 : y_title

        """
        temp = chart_obj.Axes(2)  # 1: xlCategory, 3 :xlSeriesAxis, 2 : xlValue, 1: primary, 2 : secondary
        temp.HasTitle = True
        temp.AxisTitle.Text = xtitle
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint("red")
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Bold = True
        temp.AxisTitle.Format.TextFrame2.TextRange.Font.Size = 20

    def set_font(self,sheet_name, xyxy, *input_list):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        if isinstance(input_list[0], list):
            input_list = input_list[0]

        for one in input_list:
            if one in ["진하게", "굵게", "찐하게", "bold"]:
                rng.Font.Bold = True
            elif one in ["italic", "이태리", "이태리체", "기울기"]:
                rng.Font.Italic = True
            elif one in ["strikethrough", "취소선", "통과선", "strike"]:
                rng.Font.Strikethrough = True
            elif one in ["subscript", "하위첨자", "밑첨자"]:
                rng.Font.Superscript = True
            elif one in ["superscript", "위첨자", "웃첨자"]:
                rng.Font.Subscript = True
            elif one in ["underline", "밑줄"]:
                rng.Font.Underline = True
            elif isinstance(one, int):
                rng.Font.Size = one
            else:
                try:
                    rng.Font.Color = self.xycolor.change_xcolor_to_rgbint(one)
                except:
                    pass

    def set_font_as_dic(self, input_list):
        """
        여러번 사용이 가능하도록 내가 원하는 폰트에 대한 설정을 저장해서 return값으로 돌려받는 다
        ["진하게", 12, "red50", "밑줄"] 이런형식으로 들어오면 알아서 값이 되는 것이다
        """
        self.setup_font_basic()

        if isinstance(input_list[0], list):
            input_list = input_list[0]

        for one in input_list:
            if one in ["진하게", "굵게", "찐하게", "bold"]: self.v_font["bold"] = True
            if one in ["italic", "이태리", "이태리체", "기울기"]: self.v_font["italic"] = True
            if one in ["strikethrough", "취소선", "통과선", "strike"]: self.v_font["strikethrough"] = True
            if one in ["subscript", "하위첨자", "밑첨자"]: self.v_font["subscript"] = True
            if one in ["superscript", "위첨자", "웃첨자"]: self.v_font["superscript"] = True
            if one in ["underline", "밑줄"]: self.v_font["underline"] = True
            if one in ["vertical", "수직", "가운데"]: self.v_font["align_v"] = 3
            if one in ["horizontal", "수평", "중간"]: self.v_font["align_h"] = 2

            try:
                self.v_font["size"] = int(one)
            except:
                pass

            try:
                result = self.xyre.search_all_by_xsql("[한글&영어:1~]", one)
                if result:
                    if result[0][0] in self.varx["check_color_name"]:
                        self.v_font["color"] = self.xycolor.change_xcolor_to_rgbint(one)
            except:
                pass
        result = copy.deepcopy(self.v_font)

        return result

    def set_formats_for_target_line(self, shape_obj, pen_color_rgb):
        """
        선택된 도형객체에 공통변수들을 할당하는 것

        """
        shape_obj.DashStyle = self.v_pen_style
        shape_obj.ForeColor.RGB = pen_color_rgb
        shape_obj.Weight = self.v_pen_thickness
        shape_obj.BeginArrowheadLength = self.v_start_point_length
        shape_obj.BeginArrowheadStyle = self.v_start_point_style
        shape_obj.BeginArrowheadWidth = self.v_start_point_width
        shape_obj.EndArrowheadLength = self.v_end_point_length
        shape_obj.EndArrowheadStyle = self.v_end_point_style
        shape_obj.EndArrowheadWidth = self.v_end_point_width

    def set_formula_for_range(self, sheet_name, xyxy, input_value="=Now()"):
        """
        영역에 수식을 넣는것
        """
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Formula = input_value

    def set_gradation_for_color_n_position(self, in_style, in_obj, input_color, input_l2d):
        """
        여러 가지색을 정하면서, 색의 가장 진한 위치를 0~100 사이에서 정하는 것
        self.setup_gradation_for_color_n_position("hor", aaa, "blu++", ["red++++", 0])
        """
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        style_dic = {"ver": 2, "hor": 1, "corner": 5, "center": 7, "down": 4, "up": 3, "mix": -2}
        in_obj.Fill.ForeColor.RGB = self.xycolor.change_xcolor_to_rgbint(input_color)
        obj_fill = in_obj.Fill
        obj_fill.OneColorGradient(style_dic[in_style], 1, 1)
        for index, l1d in enumerate(input_l2d):
            rgbint = self.xycolor.change_xcolor_to_rgbint(l1d[0])
            obj_fill.GradientStops.Insert(rgbint, l1d[1] / 100)

    def set_height_for_range(self, sheet_name, input_xno=7, height_float=13.5):
        """
        높이를 설정하는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Cells(input_xno, 1).EntireRow.RowHeight = height_float

    def set_hide(self, sheet_name, xx_list):
        sheet = self.check_sheet_name(sheet_name)
        x1, x2 = self.check_xx_address(xx_list)
        sheet.Rows(str(x1) + ":" + str(x2)).Hidden = True

    def set_interactive_off(self):
        """
        자료가 변경이되면 차트등이 연결되서 실행되는것을 interactive라고 한다

        """

        self.xlapp.Interactive = False

    def set_interactive_on(self):
        """
        자료가 변경이되면 차트등이 연결되서 실행되는것을 interactive라고 한다

        """
        self.xlapp.Interactive = True

    def set_invisible_for_workbook(self, visible_tf=1):
        """
        실행되어있는 엑셀을 화면에 보이지 않도록 설정합니다
        기본설정은 보이는 것으로 되너 있읍니다
        """
        self.xlapp.Visible = 0

    def set_maxmized_for_screen(self):
        """
        엑셀화일을 최대화합니다

        """
        self.xlapp.WindowState = -4137

    def set_minimized_for_screen(self):
        """
        엑셀화일을 최소화합니다

        xlMaximized : -4137
        xlMinimized : -4140
        xlNormal : -4143

        """
        self.xlapp.WindowState = -4140

    def set_numberformat(self, sheet_name, input_yno, style):
        sheet = self.check_sheet_name(sheet_name)
        if style == 1:  # 날짜의 설정
            sheet.Columns(input_yno).NumberFormatLocal = "mm/dd/yy"
        elif style == 2:  # 숫자의 설정
            sheet.Columns(input_yno).NumberFormatLocal = "_-* #,##0.00_-;-* #,##0.00_-;_-* '-'_-;_-@_-"
        elif style == 3:  # 문자의 설정
            sheet.Columns(input_yno).NumberFormatLocal = "@"

    def set_numberformat_for_column(self, sheet_name, input_yno=5, style="style1"):
        """
        각 열을 기준으로 셀의 속성을 설정하는 것이다

        """
        sheet = self.check_sheet_name(sheet_name)
        if style == 1:  # 날짜의 설정
            sheet.Columns(input_yno).NumberFormatLocal = "mm/dd/yy"
        elif style == 2:  # 숫자의 설정
            sheet.Columns(input_yno).NumberFormatLocal = "_-* #,##0.00_-;-* #,##0.00_-;_-* '-'_-;_-@_-"
        elif style == 3:  # 문자의 설정
            sheet.Columns(input_yno).NumberFormatLocal = "@"

    def set_numberformat_for_xline(self, sheet_name, input_xno, style="style1"):
        """
        열을 기준으로 셀의 속성을 설정하는 것
        """
        self.set_numberformat_for_xxline(sheet_name, input_xno, style)

    def set_numberformat_for_xxline(self, sheet_name, input_xno, style="style1"):
        """
        set_xxline_numberformat(sheet_name="", input_xno, style)
        각 열을 기준으로 셀의 속성을 설정하는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        x1 = self.check_xy_address(input_xno)
        x = self.change_char_to_num(x1)
        if style == 1:  # 날짜의 설정
            sheet.Columns(x).NumberFormatLocal = "mm/dd/"
        elif style == 2:  # 숫자의 설정
            sheet.Columns(x).NumberFormatLocal = "_-* #,##0.00_-;-* #,##0.00_-;_-* '-'_-;_-@_-"
        elif style == 3:  # 문자의 설정
            sheet.Columns(x).NumberFormatLocal = "@"

    def set_numberproperty_for_range(self, sheet_name, xyxy, type1="style1"):
        """
        좀더 사용하기 쉽도록 변경이 필요
        """
        if type1 == 'general' or type1 == '':
            result = "#,##0.00_ "
        elif type1 == 'number':
            result = "US$""#,##0.00"
        elif type1 == 'account':
            result = "_-""US$""* #,##0.00_ ;_-""US$""* -#,##0.00 ;_-""US$""* ""-""??_ ;_-@_ "
        elif type1 == 'date':
            result = "mm""/""dd""/""xx"
        elif type1 == 'datetime':
            result = "xxxx""-""m""-""d h:mm AM/PM"
        elif type1 == 'percent':
            result = "0.00%"
        elif type1 == 'bunsu':
            result = "# ?/?"
        elif type1 == 'jisu':
            result = "0.00E+00"
        elif type1 == 'text':
            result = "@"
        elif type1 == 'etc':
            result = "000-000"
        elif type1 == 'other':
            result = "$#,##0.00_);[빨강]($#,##0.00)"
        else:
            result = type1  # 만약 아무것도 해당이 않된다면, 그냥 사용자가 서식을 정의한 것이다
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        r1c1 = self.change_address_to_r1c1([x1, y1, x2, y2])
        rng = sheet.Range(r1c1)
        rng.NumberFormat = result

    def set_password_for_sheet(self, sheet_name, password="1234"):
        """
        시트를 암호로 저장
        """
        sheet = self.check_sheet_name(sheet_name)
        self.lock_sheet_with_password(sheet_name, password)

    def set_pattern(self, sheet_name, xyxy, input_list):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_list = self.check_input_data(input_list)

        self.setup_basic_data()
        if input_list:
            # 아무것도 없으면, 기존의 값을 사용하고, 있으면 새로이 만든다
            if isinstance(input_list, list):
                self.set_font(input_list)
            elif isinstance(input_list, dict):
                # 만약 사전 형식이면, 기존에 저장된 자료로 생각하고 update한다
                self.varx["pattern"].update(input_list)
        a = 2
        if a == 1:
            rng.Interior.Color = 5296274
            rng.Interior.Pattern = self.varx["range_color"]["pattern"]
            rng.Interior.PatternColor = self.varx["range_color"]["pattern"]

        elif a == 2:
            rng.Interior.Gradient.Degree = 180
            rng.Interior.Gradient.ColorStops.Clear()
            rng.Interior.Gradient.ColorStops.Add(0)

        elif a == 3:
            rng.Interior.Color = 5296274
            rng.Interior.Pattern = self.varx["range_color"]["pattern"]  # xlSolid
            rng.Interior.PatternColor = self.varx["range_color"][
                "pattern"]  # PatternColorIndex = xlAutomatic
            rng.Interior.ThemeColor = 4  # xlThemeColorDark1 색상과 색조를 미리 설정한것을 불러다가 사용하는것
            # 이것은 기본적으로 마우스의 색을 선택할때 나타나는 테마색을 말하는 것이다

            rng.Interior.TintAndShade = -0.249977111117893  # 명암을 조절
            rng.Interior.PatternTintAndShade = 0

        return self.varx["range_color"]

    def set_range_by_activecell_xline(self,sheet_name, no):
        sheet = self.check_sheet_name(sheet_name)
        xy = self.get_address_for_activecell()
        x1 = xy[0]
        x2 = xy[2]
        rng = sheet.Rows(x1 + ':' + x2)

    def set_range_by_range_name(self, sheet_name, xyxy, input_name):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        self.xlbook.Names.Add(input_name, rng)

    def set_range_by_selection(self):
        temp_address = self.xlapp.Selection.Address
        temp_address = temp_address.split(",")  # 여러곳을 선택했는지 확인하기 위한것
        result = self.change_address_to_xyxy(temp_address[0])

    def set_range_by_usedrange(self, sheet_name):
        sheet = self.check_sheet_name(sheet_name)
        self.change_address_to_xyxy(sheet.UsedRange.Address)

    def set_range_for_xxline(self, sheet_name, xyxy, *input_list):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        x1 = self.change_char_to_num(input_list[0])
        if len(input_list) > 1:
            x2 = self.change_char_to_num(input_list[1])
        else:
            x2 = x1
        rng = sheet.Rows(x1 + ':' + x2)

    def set_range_for_yyline(self, sheet_name, xyxy, *input_list):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        y1 = self.change_num_to_char(input_list[0])
        if len(input_list) > 1:
            y2 = self.change_num_to_char(input_list[1])
        else:
            y2 = y1
        rng = sheet.Columns(y1 + ':' + y2)

    def set_scrollbar(self, sheet_name):
        sheet = self.check_sheet_name(sheet_name)
        pxywh = self.change_address_to_pxywh("")
        scrollbar_obj = sheet.Shapes.AddFormControl(Type=8, Left=pxywh[0], Top=pxywh[1], Width=pxywh[2], Height=pxywh[3])
        scrollbar_obj.Name = "abc_1"
        scrollbar_obj.ControlFormat.Value = 4
        scrollbar_obj.ControlFormat.Min = 0
        scrollbar_obj.ControlFormat.Max = 359
        scrollbar_obj.ControlFormat.SmallChange = 1
        scrollbar_obj.ControlFormat.LargeChange = 10
        scrollbar_obj.ControlFormat.LinkedCell = "$A$1"

    def set_shape_degree(self, sheet_name, shape_obj, degree):
        """
        도형을 회전시키는 것
        도형은 중간을 기준으로 회=전을 합니다
        shape _ obi :이동시킬 도형 이름
        """
        sheet = self.check_sheet_name(sheet_name)
        shape_obj.IncrementRotation(degree)

    def set_shape_ratio_by_name(self, sheet_name, shape_name, wh_connect_tf=True):
        """
        사진의 비율변경을 해제하거나 설정하는 목적
        Selection.ShapeRange.LockAspectRatio = msoTrue

        """
        sheet = self.check_sheet_name(sheet_name)
        shape_obj = sheet.Shapes(shape_name)
        shape_obj.LockAspectRatio = wh_connect_tf

    def set_shape_size_by_no(self, sheet_name, shape_no, width_float, height_float, lock_ratio_tf):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        shape_obj = sheet.Shapes(shape_no)
        if lock_ratio_tf:
            shape_obj.LockAspectRatio = True
        else:
            shape_obj.LockAspectRatio = False
        # 도형의 크기 조정
        shape_obj.Width = width_float
        shape_obj.Height = height_float

    def set_shape_size_for_sheet(self, sheet_name, shape_no, width_float=12.3, height_float=8.9, lock_ratio_tf=True):
        """
        도형(이미지포함)의 크기를 변경시키는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        shape_obj = sheet.Shapes(shape_no)
        if lock_ratio_tf:
            shape_obj.LockAspectRatio = True
        else:
            shape_obj.LockAspectRatio = False
        # 도형의 크기 조정
        shape_obj.Width = width_float
        shape_obj.Height = height_float

    def set_tab_color_for_sheet(self, sheet_name, input_color='yel'):
        """
        시트탭의 색을 넣는것
        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Tab.ColorIndex = self.xycolor.change_any_color_to_rgbint(input_color)
        sheet.Tab.TintAndShade = 0

    def set_visible_for_sheet(self, input_tf=0):
        """
        실행되어있는 엑셀을 화면에 보이지 않도록 설정합니다
        기본설정은 보이는 것으로 되너 있읍니다

        """
        self.xlapp.Visible = input_tf

    def set_visible_for_workbook(self, input_tf=1):
        """
        실행되어있는 엑셀을 화면에 보이지 않도록 설정합니다
        기본설정은 보이는 것으로 되너 있읍니다

        """
        self.xlapp.Visible = input_tf

    def set_width_for_range(self, rng, input_float):
        """

        """
        rng.ColumnWidth = input_float

    def set_width_for_yline(self, sheet_name, input_yno, height_float=13.5):
        """

        """
        self.set_width_for_yyline(sheet_name, [input_yno, input_yno], height_float)

    def set_width_for_yyline(self, sheet_name, xyxy, width_float=13.5):
        """
        입력영역의 세로의 넓이를 설정하는 것
        """
        sheet = self.check_sheet_name(sheet_name)
        rng = self.get_range_for_yyline(sheet_name, xyxy)
        rng.ColumnWidth = width_float

    def set_width_n_height_for_line_obj(self, line_obj, input_float_width=12.3, input_float_height=8.8):
        """
        선객체의 넓이와 높이를 바꾸는 것

        """
        line_obj.ShapeRange.ScaleWidth = input_float_width
        line_obj.ShapeRange.ScaleHeight = input_float_height

    def set_wrap_for_range(self, sheet_name='', xyxy='', input_value=None):
        """
        셀안의 값이 여러줄일때 줄바꿈이 되도록 설정하는 것
        줄바꿈이 가능하도록 설정하는 것

        """
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.WrapText = input_value

    def set_wraptext(self, sheet_name, xyxy, input_tf=True):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.WrapText = input_tf

    def shape_degree(self, shape_obj, degree):
        shape_obj.IncrementRotation(degree)

    def shape_degree_for_sheet(self, sheet_name, shape_obj, degree):
        """
        도형을 회전시키는 것
        도형은 중간을 기준으로 회=전을 합니다
        shape _ obi :이동시킬 도형 이름

        """
        shape_obj.IncrementRotation(degree)

    def shape_name_by_index(self, shape_no, sheet_name=''):
        """
        번호로 객체의 이름을 갖고오는것
        """
        sheet = self.check_sheet_name(sheet_name)

        result = sheet.Shapes(shape_no).Name
        return result

    def shape_name_by_no(self, shape_no, sheet_name=''):
        """
        엑셀화일안에 있는 도형의 번호로 도형의 이름을 갖고오는 것
        번호가 들어오던 이름이 들어오던 도형의 번호를 기준으로 확인해서 돌려주는 것
        """
        sheet = self.check_sheet_name(sheet_name)

        check_dic = {}

        if isinstance(shape_no, int):
            result = shape_no
        else:
            sheet = self.check_sheet_name(sheet_name)
            for index in range(sheet.Shapes.Count):
                shape_name = sheet.Shapes(index).Name
                check_dic[shape_name] = index
            result = check_dic[shape_no]
        return result

    def shape_obj_by_name(self, shape_no, sheet_name=''):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(shape_no, str):
            shape_name = self.shape_name_by_no(shape_no)
            shape_obj = sheet.Shapes(shape_name)
        elif isinstance(shape_no, int):
            shape_obj = sheet.Shapes(shape_no)
        return shape_obj

    def shape_obj_by_no(self, shape_no, sheet_name=''):
        """

        """
        sheet = self.check_sheet_name(sheet_name)
        if isinstance(shape_no, str):
            shape_name = self.shape_name_by_no(shape_no)
            shape_obj = sheet.Shapes(shape_name)
        elif isinstance(shape_no, int):
            shape_obj = sheet.Shapes(shape_no)
        return shape_obj

    def shape_ratio_in_sheet(self, sheet_name, shape_name="name1", wh_connect_tf=True):
        """
        사진의 비율변경을 해제하거나 설정하는 목적
        Selection.ShapeRange.LockAspectRatio = msoTrue

        """
        sheet = self.check_sheet_name(sheet_name)
        shape_obj = sheet.Shapes(shape_name)
        shape_obj.LockAspectRatio = wh_connect_tf

    def shape_size(self, sheet_name, shape_no, width_float, height_float, lock_ratio_tf):
        sheet = self.check_sheet_name(sheet_name)
        shape_obj = sheet.Shapes(shape_no)
        if lock_ratio_tf:
            shape_obj.LockAspectRatio = True
        else:
            shape_obj.LockAspectRatio = False
        # 도형의 크기 조정
        shape_obj.Width = width_float
        shape_obj.Height = height_float

    def shape_size_for_sheet(self, sheet_name, shape_no, width_float=12.3, height_float=8.9, lock_ratio_tf=True):
        """
        도형(이미지포함)의 크기를 변경시키는 것

        """
        sheet = self.check_sheet_name(sheet_name)
        shape_obj = sheet.Shapes(shape_no)
        if lock_ratio_tf:
            shape_obj.LockAspectRatio = True
        else:
            shape_obj.LockAspectRatio = False
        # 도형의 크기 조정
        shape_obj.Width = width_float
        shape_obj.Height = height_float

    def sheet_lock(self, sheet_name, password="1234"):
        """
        입력받은 암호를 사용해서 시트를 잠그기

        """
        sheet = self.check_sheet_name(sheet_name)
        sheet.protect(password)

    def sheet_for_activesheet(self):
        """
        현재 활성화된 시트를 객체형식으로 돌려주는 것
        """
        result = self.check_sheet_name('')
        return result

    def show_excel_data_at_webbrower_with_datatables(self, xyxy, input_filename):
        """
        엑셀자료의 형태는
        [x좌표, y좌표, 설명, 분류] 또는
        [한글주소, "", 설명, 분류] 또는

        """

        if not input_filename.endswith(".html"): input_filename = input_filename + ".html"

        json_code, title_list, input_filename = self.change_value_for_range_to_json_file("", xyxy="", input_filename="D:\\temp\\abc.xlsx")

        aaa = """
            <!DOCTYPE html>
            <html lang="kr"><head><meta charset="UTF-8">
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
            <link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet"/>

            <script>
            var data=""" + json_code + """;
            $(document).ready(function() {
            $('#itertools.product-inventory-level').DataTable( {
                "data": data,
                "columns": [
            """
        bbb = ""
        for one in title_list:
            bbb = bbb + '{ "data": "' + one + '"},'

        ccc = """ ], }); });
            </script>
            <title></title>
            </head><body><table id="itertools.product-inventory-level" class="display" style="width:100%"><thead><tr>"""

        ddd = ""
        for one in title_list:
            ddd = ddd + '<th>' + one + '</th>'
        eee = """</tr></thead></table></body></html>"""

        total_code = aaa + bbb + ccc + ddd + eee

        self.show_html_code_at_webbrowser(total_code, input_filename)

    def show_file_dialog(self):
        """
        화일 다이얼로그를 불러오는 것

        """
        filter = "Picture Files \0*.jp*;*.gif;*.bmp;*.png\0Text files\0*.txt\0"
        # filter = "Picture Files (*.jp*; *.gif; *.bmp; *.png),*.xls"
        # win32con.OFN_EXPLORER : 0x00080000
        # win32con.OFN_ALLOWMULTISELECT : 0x00000200

        result = win32gui.GetOpenFileNameW(InitialDir=os.environ["temp"],
                                           Filter=filter, Flags=0x00000200 | 0x00080000,
                                           File="somefilename", DefExt="py",
                                           Title="GetOpenFileNameW", FilterIndex=0)
        return result

    def show_html_code_at_webbrowser(self, input_html_code, input_filename):
        """
        html코드를 화일이아닌 코드 자체를 갖고와서 웹브라우져로 여는 것
        결론적으로는 화일을 만드는것과 같은것 같다
        엑셀의 자료를 datatables를 이용하여 테이블 형식으로 웹브라유져에 나타내는 코드임

        """
        f = open(input_filename, 'w', encoding="utf-8")
        f.write(input_html_code)
        f.close()
        webbrowser.open_new_tab('file:///' + os.getcwd() + '/' + input_filename)

    def sort_2_excel_files_001(self):
        """
        두개시트의 자료를 기준으로 정렬한다선택한
        단 두개의 자료는 각각 정렬이되어있어야 한다
        빈칸은 없어야 한다

        """
        # 1. 두개의 시트의 첫번째 열을 읽어온다
        sheet_names = self.get_all_sheet_name()

        # 첫번째 시트의 첫번째 행의 자료를 갖고오는 것이다
        sheet1_name = sheet_names[0]
        y_start, x_start, y_end, x_end = self.get_address_for_usedrange(sheet1_name)
        datas1 = self.read_value_for_range(sheet1_name, [1, x_start, 1, x_end])

        # 두번째 시트의 첫번째 행의 자료를 갖고오는 것이다
        sheet2_name = sheet_names[1]
        y_start, x_start, y_end, x_end = self.get_address_for_usedrange(sheet2_name)
        datas2 = self.read_value_for_range(sheet2_name, [1, x_start, 1, x_end])

        # 첫번째것과 두번째것을 비교하여 컬럼을 추가한다
        all_dic = {}
        for data1 in datas1:
            if data1[0] in all_dic:
                all_dic[data1[0]] = all_dic[data1[0]] + 1
            else:
                all_dic[data1[0]] = 1

        for data2 in datas2:
            if data2[0] in all_dic:
                all_dic[data2[0]] = all_dic[data2[0]] + 1
            else:
                all_dic[data2[0]] = 1

        # 각각 시트를 돌아가며 칸을 넣는다
        # 딕셔너리의 키를 리스트로 만든다
        all_dic_list = list(all_dic.keys())

        try:
            all_dic_list.remove(None)
        except:
            pass

        all_dic_list_sorted = sorted(all_dic_list)

        # 딕셔너리의 값들을 리스트로 만들어서 값을 만든다
        all_dic_values_list = list(all_dic.values())
        temp_1 = 0
        for one in all_dic_values_list:
            temp_1 = temp_1 + int(one)

        # 첫번째 시트를 맞도록 칸을 넣는다
        temp_2 = []
        for one in all_dic_list_sorted:
            for two in range(int(all_dic.get(one))):
                temp_2.append(one)

        temp_3 = 0
        for one in range(len(temp_2)):
            try:
                if temp_2[one] == datas1[temp_3][0]:
                    temp_3 = temp_3 + 1
                else:
                    self.insert_xxline(sheet1_name, one + 1)
            except:
                self.insert_xxline(sheet1_name, one + 1)

        temp_4 = 0
        for one in range(len(temp_2)):
            try:
                if temp_2[one] == datas2[temp_4][0]:
                    temp_4 = temp_4 + 1
                else:
                    self.insert_xxline(sheet2_name, one + 1)
            except:
                self.insert_xxline(sheet2_name, one + 1)

    def sort_with_two_range(self, sheet_name, xyxy1, xyxy2):
        """
        두가지 영역을 정렬 하는 것
        """
        l2d_1 = self.read_value_for_range(sheet_name, xyxy1)
        l2d_2 = self.read_value_for_range(sheet_name, xyxy2)
        l2d_3 = list(l2d_2)
        self.new_sheet()
        line = 1
        len_width = len(l2d_1[0])
        total_line_no = 1
        current_x = 0

        for index, one in enumerate(l2d_1):
            current_x = current_x + 1
            self.write_value_for_range("", [current_x, 1], one)
            temp = 0
            for index2, one_2 in enumerate(l2d_2):
                if one[0] == one_2[0] and (one[0] != "" or one[0] != None):
                    temp = temp + 1
                    if temp > 1:
                        current_x = current_x + 1
                    self.write_value_for_range("", [current_x, len_width + 1], one_2)
                    l2d_3[index2] = ["", ""]

        total_line_no = line + len(l2d_1)
        for one in l2d_3:
            if one[0] != "" and one[0] != None:
                current_x = current_x + 1
                self.write_value_for_range("", [current_x, len_width + 1], one)

    def split_address_to_str_n_num(self, xyxy=''):
        """
        string형태의 address를 문자와 숫자로 나누는것
        """
        aaa = re.compile("[a-zA-Z]+|\\d+")
        result = aaa.findall(str(xyxy))
        return result

    def split_filename_to_path_n_filename(self, input_filename):
        """
        화일 이름을 경로와 이름으로 구분하는 것이다
        """
        path = ""
        changed_filename = input_filename.replace("\\", "/")
        split_list = changed_filename.split("/")
        filename_only = split_list[-1]
        if len(changed_filename) == len(filename_only):
            path = ""
        else:
            path = changed_filename[:len(filename_only)]

        return [path, filename_only]

    def split_l2d_as_special_letter(self, sheet_name, xyxy, input_list=["-"]):
        """
        2차원의 자료의 각 자료를 입력 문자로 분리하는 것
        여러자료중에서 특정한 문자로 셀의 값을 분리해서, 만들고 싶을때 사용하기 위해서

        """
        l2d = self.read_value(sheet_name, xyxy)
        for split_char in input_list:
            for ix, l1d in enumerate(l2d):
                for iy, one_value in enumerate(l1d):
                    temp = []

                    if isinstance(one_value, list):
                        for one in one_value:
                            if isinstance(one, str):
                                temp.extend(one.split(split_char))
                            else:
                                temp.append(one)
                    elif isinstance(one_value, str):
                        temp.extend(one_value.split(split_char))
                    else:
                        temp = [one_value]
                    l2d[ix][iy] = temp
        return l2d

    def split_l2d_value_by_special_char(self, input_l2d, split_char):
        """
        2차원자료안의 모든 값을 특정문자로 분리하는 기능
        """
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        result = []
        for ix, l1d in enumerate(input_l2d):
            temp = ""
            for iy, value in enumerate(l1d):
                value = input_l2d[ix][iy]
                # value = self.read_value_for_cell("", [ix + 1, iy + 1])
                if isinstance(value, str):
                    splited_value = value.split(split_char)
                    if isinstance(splited_value, list):
                        result.append(splited_value)
                    else:
                        result.append([splited_value])
                else:
                    result.append([value])
        return result

    def split_partial_value_by_step_from_start(self, sheet_name, xyxy, input_no):
        [sheet_name, xyxy, input_no] = self._check_3_param(sheet_name, xyxy, input_no)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.read(sheet_name, xyxy)
        result = set()
        for l1d in l2d:
            for one in l1d:
                try:
                    result.add(one[0:input_no])
                except:
                    pass
        return list(result)

    def split_partial_value_for_range_by_step_from_start(self, sheet_name='', xyxy='', input_no=123):
        """
        어떤 자료중에 앞에서 몇번째것들만 갖고오고 싶을때
        예:시군구 자료에서 앞의 2글자만 분리해서 얻어오는 코드
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        result = set()
        for l1d in l2d:
            for one in l1d:
                try:
                    result.add(one[0:input_no])
                except:
                    pass
        return list(result)

    def split_range_as_head_body_tail(self, xyxy, head_height, tail_height):
        """
        테이블 형식의 영역을 head, body, tail 로 구분하는 것

        """
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy)
        range_head = [x1, y1, x1 + head_height - 1, y2]
        range_body = [x1 + head_height, y1, x2 - tail_height, y2]
        range_tail = [x2 - tail_height - 1, y1, x2, y2]
        return [range_head, range_body, range_tail]

    def split_text_by_special_string(self, sheet_name='', xyxy='', input_value=None):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        # sheet_name = self.get_activesheet_name()
        rng_select = self.get_address_for_usedrange('')
        rng_used = self.get_address_for_usedrange('')
        [x1, y1, x2, y2] = self.get_range_for_intersect_two_range(rng_select, rng_used)
        self.insert_yyline("", y1 + 1)
        self.insert_yyline("", y1 + 1)
        result = []
        length = 2
        # 자료를 분리하여 리스트에 집어 넣는다
        for x in range(x1, x2 + 1):
            for y in range(y1, y2 + 1):
                one_value = str(sheet.Cells(x, y).Value)
                list_data = one_value.split(input_value)
                result.append(list_data)
        # 집어넣은 자료를 다시 새로운 세로줄에 넣는다
        for x_no in range(len(result)):
            if len(result[x_no]) > length:
                for a in range(len(result[x_no]) - length):
                    self.insert_yyline("", y1 + length)
                length = len(result[x_no])
            for y_no in range(len(result[x_no])):
                sheet.Cells(x1 + x_no, y1 + y_no + 1).Value = result[x_no][y_no]

    def split_text_by_special_string_for_range(self, sheet_name, input_value):
        """
        선택한 1줄의 영역에서 원하는 문자나 글자를 기준으로 분리할때
        2개의 세로행을 추가해서 결과값을 쓴다

        """
        self.split_text_by_special_string(sheet_name, input_value)

    def split_value_by_input_word_and_insert_splitted_data(self, sheet_name, xyxy, splitted_char=","):
        """
        1줄의 값을 특정문자를 기준으로 분리한후
        분리된 갯수가 있으면, 1개이상일때는, 아래부분에 새로운 열을 추가한후에 값을 넣는것
        여러줄을 선택하여도, 제일 첫줄만 적용한다

        """
        sheet = self.check_sheet_name(sheet_name)
        for no in range(xyxy[2], xyxy[0], -1):
            value = self.read_value_for_cell("", [no, xyxy[1]])
            splited_value = value.split(splitted_char)
            sheet.Cells(no, xyxy[1]).Value = splited_value[0].strip()
            if len(splited_value) > 1:
                for index, one in enumerate(splited_value[1:]):
                    self.insert_xline("", no + index + 1)
                    sheet.Cells(no + index + 1, xyxy[1]).Value = one.strip()

    def split_xline_as_per_input_word_for_yline(self, sheet_name, xyxy, yline_index=2, input_value="입력텍스트", first_line_is_title_tf=True):
        """
        선택한 영역에서 특정 y값이 입력값을 갖고있을때, 입력값들에 따라서 x라인들을 저장한후 돌려준다

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        result = {"_main_data": []}
        for one_value in input_value:
            result[one_value] = []

        if first_line_is_title_tf:
            for one_key in result.keys():
                result[one_key].append(l2d[0])
            l2d = l2d[1:]

        for l1d in l2d:
            found = False
            for one_key in result.keys():
                if one_key in l1d[int(yline_index)]:
                    result[one_key].append(l1d)
                    found = True
            if found == False:
                result["_main_data"].append(l1d)

        return result

    def split_xre_for_selection_with_new_sheet(self, input_xre):
        """
        선택영역안의 값에서 입력으로 들어온 xre형식의 정규표현식에 맞는것을
        새로운 시트에 써주는 것이다
        발견한것을 기준으로 원래 값을 분리하는것
        """
        sheet = self.check_sheet_name("")
        result = []
        xyxy = self.get_address_for_selection()
        for x in range(xyxy[0], xyxy[2] + 1):
            for y in range(xyxy[1], xyxy[3] + 1):
                one_value = sheet.Cells(x, y).Value
                aaa = self.xyre.search_all_by_xsql(input_xre, one_value)
                atemp = []
                if aaa:
                    for num in range(len(aaa) - 1, -1, -1):
                        one = aaa[num]
                        no = one[2]
                        temp = one_value[no:]
                        one_value = one_value[:no]
                        atemp.append(temp)
                        atemp.insert(0, one_value)
                result.append(atemp)
        self.new_sheet()
        self.write_l2d_from_cell("", [1, 1], result)

    def unhide_all_sheet(self):
        for sheet in self.xlbook.Sheets:
            # 시트의 Visible 속성을 -1 (xlSheetVisible)로 설정
            # -1: xlSheetVisible (보임)
            # 0: xlSheetHidden (숨김)
            # 2: xlSheetVeryHidden (매우 숨김)

            # 현재 시트의 Visible 상태를 확인하고 변경
            if sheet.Visible != -1:
                sheet.Visible = -1  # 보이도록 설정

    def unhide_sheet(self, sheet_name):
        """

        """
        sht_obj = self.new_sheet(sheet_name)
        sht_obj.Visible = True

    def unhide_sheet_all(self):
        for sheet in self.xlbook.Sheets:
            # 시트의 Visible 속성을 -1 (xlSheetVisible)로 설정
            # -1: xlSheetVisible (보임)
            # 0: xlSheetHidden (숨김)
            # 2: xlSheetVeryHidden (매우 숨김)

            # 현재 시트의 Visible 상태를 확인하고 변경
            if sheet.Visible != -1:
                sheet.Visible = -1  # 보이도록 설정

    def unlock_sheet_by_password(self, sheet_name="", password="1234"):
        """
            입력시트의 시트 보호를 해제하기

                Examples
            --------
            """
        sheet = self.check_sheet_name(sheet_name)
        sheet.Unprotect(password)

    def unmerge_for_range(self, sheet_name='', xyxy=''):
        """
        입력영역안에 병합된 것이 있으면 병합을 해제하기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.UnMerge()

    def vlookup(self, sheet_name, find_xyxy="", check_xyxy="", find_value_option="top", find_value_oxy=[2, 4], write_value_oxy=[3, 4]):
        """
        영역에 vlookup을 적용
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy('', '')
        original_l2d = self.read_value(sheet_name, find_xyxy)
        dic_data = self.read_range_as_dic_with_xy_position(sheet_name, find_xyxy)

        l2d = self.read_value(sheet_name, check_xyxy)

        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                if one_value in dic_data.keys():
                    find_x, find_y = dic_data[one_value][0]
                else:
                    continue

                if find_value_option == "top":
                    change_x = 0
                    change_y = find_y - 1
                else:
                    change_x = find_x - 1 + find_value_oxy[0]
                    change_y = find_y - 1 + find_value_oxy[1]
                write_value = original_l2d[change_x][change_y]
                write_x = check_xyxy[0] + write_value[0] + ix
                write_y = check_xyxy[1] + write_value[1] + iy
                sheet.Cells(write_x, write_y).Value = write_x, write_y

    def vlookup_for_multi_input(self, sheet_name, xyxy, search_no_list, search_value_list, find_no, option_all=True):
        """
        여러 값이 같은 줄을 갖고오는 방법

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        result = []
        checked_no = len(search_value_list)

        for l1d in l2d:
            temp_no = 0
            for index, num in enumerate(search_no_list):
                if option_all:
                    # 모든 값이 다 같을때
                    if l1d[num - 1] == search_value_list[index]:
                        temp_no = temp_no + 1
                    else:
                        break
                else:
                    # 값이 일부분일때도 OK
                    if search_value_list[index] in l1d[num - 1]:
                        temp_no = temp_no + 1
                    else:
                        break
            if temp_no == checked_no:
                result = l1d[find_no - 1]
        return result

    def vlookup_for_range(self, sheet_name, find_xyxy="", check_xyxy="", find_value_option="top", find_value_oxy=[2, 4], write_value_oxy=[3, 4]):
        """
        영역에 vlookup을 적용

        """
        sheet = self.check_sheet_name("")
        original_l2d = self.read_value_for_range(sheet_name, find_xyxy)
        dic_data = self.read_as_dic_with_xy_position(sheet_name, find_xyxy)

        l2d = self.read_value_for_range(sheet_name, check_xyxy)

        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                if one_value in dic_data.keys():
                    find_x, find_y = dic_data[one_value][0]
                else:
                    continue

                if find_value_option == "top":
                    change_x = 0
                    change_y = find_y - 1
                else:
                    change_x = find_x - 1 + find_value_oxy[0]
                    change_y = find_y - 1 + find_value_oxy[1]
                write_value = original_l2d[change_x][change_y]
                write_x = check_xyxy[0] + write_value[0] + ix
                write_y = check_xyxy[1] + write_value[1] + iy
                sheet.Cells(write_x, write_y).Value = write_x, write_y

    def vlookup_with_multi_input_line(self, input_value1, input_value2):
        """
        보통 vlookup은 한줄을 비교해서 다른 자료를 찾는데
        이것은 여러항목이 같은 값을 기준으로 원하는 것을 찾는 것이다
        input_valuel = [자료의영역, 같은것이있는위치, 결과값의위치]

        """
        sheet = self.check_sheet_name("")
        input_value1 = self.check_input_data(input_value1)
        input_value2 = self.check_input_data(input_value2)

        base_data2d = self.read_value_for_range("", input_value1[0])
        compare_data2d = self.read_value_for_range("", input_value2[0])
        result = ""
        for one_data_1 in base_data2d:
            gijun = []
            one_data_1 = list(one_data_1)
            for no in input_value1[1]:
                gijun.append(one_data_1[no - 1])
            x = 0

            for value_1d in compare_data2d:
                value_1d = list(value_1d)
                x = x + 1
                bikyo = []

                for no in input_value2[1]:
                    bikyo.append(value_1d[no - 1])

                if gijun == bikyo:
                    result = one_data_1[input_value1[2] - 1]
                sheet.Cells(x, input_value2[2]).Value = result

    def vlookup_xyxy(self, sheet_name, find_xyxy, check_xyxy, find_value_option, find_value_oxy, write_value_oxy):
        sheet = self.check_sheet_name(sheet_name)
        original_l2d = self.read_value_for_range("", find_xyxy)
        dic_data = self.read_as_dic_with_xy_position(find_xyxy)

        l2d = self.read_value_for_range("", check_xyxy)

        for ix, l1d in enumerate(l2d):
            for iy, one_value in enumerate(l1d):
                if one_value in dic_data.keys():
                    find_x, find_y = dic_data[one_value][0]
                else:
                    continue

                if find_value_option == "top":
                    change_x = 0
                    change_y = find_y - 1
                else:
                    change_x = find_x - 1 + find_value_oxy[0]
                    change_y = find_y - 1 + find_value_oxy[1]
                write_value = original_l2d[change_x][change_y]
                write_x = check_xyxy + write_value[0] + ix
                write_y = check_xyxy + write_value[1] + iy
                sheet.Cells(write_x, write_y).Value = write_x, write_y

    def write(self, sheet_name, xyxy, input_value, value_first=False):
        # 수정한것
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(input_value)

        if value_first:
            sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x1 + len(l2d) - 1, y1 + len(l2d[0]) - 1)).Value = l2d
        else:  # range우선일때
            len_data_x = len(input_value)
            len_data_y = len(input_value[0])
            len_rng_x = x2 - x1 + 1
            len_rng_y = y2 - y1 + 1
            len_x = len_rng_x
            len_y = len_rng_y
            if len_rng_x >= len_data_x: len_x = len_data_x
            if len_rng_y > len_data_y: len_y = len_data_y
            result_data = [row[:len_y] for row in l2d[:len_x]]
            sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x1 + len_x - 1, y1 + len_y - 1)).Value = result_data

    def write_as_len_xy(self, sheet_name, l2d, xyxy, len_xy):
        """
        자료의 갯수만큼 쓰는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        #[x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy)
        result = []
        for l1d in l2d[:len_xy[0]]:
            result.append(l1d[:len_xy[1]])

        lengths = {len(row) for row in l2d}

        if len(lengths) == 1:
            sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x1 + len(l2d) - 1, y1 + len(l2d[0]) - 1)).Value = l2d
        else:
            for index, l1d in enumerate(l2d):
                sheet.Range(sheet.Cells(x1 + index, y1), sheet.Cells(x1 + index, y1 + len(l1d) - 1)).Value = l1d

    def write_by_reverse(self, sheet_name='', xyxy=''):
        """
        영역에 입력값을 쓰는 것이며, 현재 입력한 영역의 값을 읽어와서, 입력자료를 좌우를 바꾸는 형태로(xy를 yx로 바꿔서) 입력하는 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        change_l2d = self.xyutil.trans_l2d_from_xy_to_yx(l2d)
        self.new_sheet()
        self.write_l2d(input_l2d=change_l2d, xyxy=[1, 1])

    def write_by_xy_step(self, sheet_name, xyxy, input_value, xy_step):
        """
        영역에 입력값을 쓰는 것이며, 선택한 영역의 시작점부터 x,y 번째 셀마다 입력값을 쓰기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for x in range(x1, x2 + 1):
            if divmod(x, xy_step[0])[1] == 0:
                for y in range(y1, y2 + 1):
                    if divmod(y, xy_step[1])[1] == 0:
                        sheet.Cells(x, y).Value = input_value

    def write_cell(self, sheet_name="", xyxy="", input_value = None):
        sheet_name, xyxy, input_value = self._check_3_param(sheet_name, xyxy, input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.Cells(x1, y1).Value = input_value

    def write_dic_for_range(self, sheet_name, xyxy, input_dic):
        """
        사전으로 입력된 키값을 엑셀에 쓰는것

        """
        [sheet_name, xyxy, input_dic] = self._check_3_param(sheet_name, xyxy, input_dic)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = list(input_dic.items())

        for x in range(len(l2d)):
            sheet.Cells(x + x1, y1).Value = l2d[x][0]
            sheet.Cells(x + x1, y1 + 1).Value = l2d[x][1]

    def write_empty_cell_for_range_as_uppercell_value(self, sheet_name='', xyxy=''):
        """
        영역에서 빈셀을 발견하면, 그 위의 있는 셀의 값으로 채우는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)

        for y in range(len(l2d[0])):
            old_value = ""
            for x in range(len(l2d)):
                if l2d[x][y] == "" or l2d[x][y] == None:
                    sheet.Cells(x + x1, y + y1).Value = old_value
                else:
                    old_value = l2d[x][y]

    def write_end_of_column(self, xy, input_l1d):
        """

        """
        self.select_bottom_of_selection(xy)
        xyxy = self.get_address_for_activecell()
        self.write([xyxy[0] + 1, xyxy[1]], input_l1d)

    def write_end_of_column_for_range(self, sheet_name='', xyxy='', input_l1d=None):
        """
        a3을 예로들어서, a3을 기준으로, 입력한 값이있는제일 마지막 가로줄번호를 갖고온후,
        그 다음줄에 값을 넣는것
        어떤 선택된 자료의 맨 마지막에 값을 넣기

        """

        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xyxy, input_l1d)
        self.move_activecell_to_bottom_for_range(sheet_name, xyxy)
        xy = self.get_address_for_activecell()
        self.write_value_for_range(sheet_name, [xy[0] + 1, xy[1]], input_l1d)

    def write_excel_function_for_range(self, sheet_name, xy, input_fucntion="sum", xyxy=""):
        """
        셀에 엑셀의 함수를 입력해 주는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        range = self.change_address_to_r1c1(xyxy)
        result = "=" + input_fucntion + "(" + range + ")"
        sheet.Cells(x1, y1).Value = result

    def write_except_none(self, sheet_name='', xyxy='', input_l2d=None):
        """

        """
        [sheet_name, xyxy, input_l2d] = self._check_3_param(sheet_name, xyxy, input_l2d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        for ix, l1d in enumerate(input_l2d):
            for iy, one_value in enumerate(l1d):
                if one_value != None:
                    sheet.Cells(x1 + ix, y1 + iy).Value = one_value

    def write_formula_for_range(self, sheet_name, xyxy, input_value="=Now()"):
        """
        영역에 입력으로 들어온 수식을 넣는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        rng.Formula = input_value

    def write_input_value_for_range_by_xy_step(self, sheet_name, xyxy, input_value, xy_step):
        """
        선택한 영역의 시작점부터 x,y 번째 셀마다 값을 넣기

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for x in range(x1, x2 + 1):
            if divmod(x, xy_step[0])[1] == 0:
                for y in range(y1, y2 + 1):
                    if divmod(x, xy_step[1])[1] == 0:
                        one_value = sheet.Cells(x, y).Value2
                        if one_value == None:
                            one_value = ""
                        sheet.Cells(x, y).Value = one_value + str(input_value)

    def write_l1d(self, sheet_name, xyxy, input_l1d, xy_step=[], xdirection_tf=True, value_first=True):
        """

        """
        # xy_step이 되면서 가로나 세로로 쓸수는 없으므로 이두가지는 병행할수 없는 상태로 만듦
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        if value_first:  # 만약 범위를 우선한다면, 자료가 더 클경우도 있으므로 자료 자체를 줄이도록 한다
            input_l1d = input_l1d[:(y2 - y1)]

        if xy_step:
            for ix, one_value in enumerate(input_l1d):
                sheet.Cells(x1 + ix * xy_step[0], y1 + ix * xy_step[1]).Value = one_value
        elif xdirection_tf:
            sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x1, y1 + len(input_l1d))).Value = input_l1d
        else:
            for ix, one_value in enumerate(input_l1d):
                sheet.Cells(x1, y1 + ix).Value = one_value

    def write_l1d_for_cell_as_group(self, sheet_name='', xyxy='', input_l1d=None):
        """
        1차원자료를 시작셀을 기준으로 아래로 값을 넣는 것

        """
        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xyxy, input_l1d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.Cells(x1, y1).Value = input_l1d

    def write_l1d_for_range_from_cell_as_yline_by_step(self, sheet_name, input_l1d, step_no, start_xy):
        """
        1차원자료를 n개씩 세로로 써주는 것

        """
        input_l1d = self.check_input_data(input_l1d)
        sheet = self.check_sheet_name("")
        mok, namuji = divmod(len(input_l1d), step_no)
        if namuji > 0:
            mok = mok + 1
        y = 0
        count = 0
        for _ in range(mok):
            for ix in range(step_no):
                sheet.Cells(ix + start_xy[0], y + start_xy[1]).Value = input_l1d[count]
                if len(input_l1d) == count + 1:
                    return
                count = count + 1
            y = y + 1

    def write_l1d_for_yline(self, sheet_name='', xyxy='', input_l1d=None):
        """
        아래의 예제는 엑셀의 값중에서 y라인으로 자동으로 한줄을 넣는 기능이 없어서, 만들어 보았다
        영역에 값는 넣기

        """
        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xyxy, input_l1d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x in range(0, len(input_l1d)):
            sheet.Cells(x + x1, y1).Value = input_l1d[x]

    def write_l1d_from_cell(self, sheet_name='', xy='', input_l1d=None):
        """
        1차원리스트의 값을 특정셀에서부터 다 써주는 것이다. 영역을 나타내는 xy변수의 기본값을 ""일때는 현재 선택된 영역을 뜻하는 것입니다

        """
        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xy, input_l1d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x1, y1 + len(input_l1d) - 1)).Value = input_l1d

    def write_l1d_from_cell_as_yline(self, sheet_name='', xyxy='', input_l1d=None):
        """
        1차원자료를 세로줄로 써내려가는 것

        """
        # 속도를 높이기위해 변경함
        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xyxy, input_l1d)
        input_l1d = self.check_input_data(input_l1d)
        l2d = []
        for x, value in enumerate(input_l1d):
            l2d.append([value])
        self.write_value_for_range_by_value_priority(sheet_name, xyxy, l2d)

    def write_l1d_from_cell_as_yline_by_step(self, sheet_name, xyxy, input_l1d, step_no, start_xy):
        """
        공동변수를 이용해서 하나의 공통 변수를 이용하여 실행
        1차원의 자료를 n번째마다 입력갯수만큼 써주는 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l1d = self.check_input_data(input_l1d)
        mok, namuji = divmod(len(input_l1d), step_no)
        if namuji > 0:
            mok = mok + 1
        y = 0
        count = 0
        for _ in range(mok):
            for ix in range(step_no):
                sheet.Cells(ix + start_xy[0], y + start_xy[1]).Value = input_l1d[count]
                if len(input_l1d) == count + 1:
                    return
                count = count + 1
            y = y + 1

    def write_l1d_from_cell_by_step(self, sheet_name, xyxy, input_l1d, step_no):
        """
        1차원자료를 n개로 분리해서 2차원자료처럼 만든후 값을 쓰는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l1d = self.check_input_data(input_l1d)
        self.xyutil.change_l1d_to_l2d_group_by_step(input_l1d, step_no)
        self.write_l2d_from_cell(sheet_name, xyxy, input_l1d)

    def write_l1d_to_ydirection(self, sheet_name='', xyxy='', input_l1d=None):
        """

        """
        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xyxy, input_l1d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for index, one_value in enumerate(input_l1d):
            sheet.Cells(x1, index + y1).Value = one_value

    def write_l2d(self, sheet_name, xyxy, input_l2d, value_first=True):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        checked_list_2d = self.xyutil.change_any_data_to_l2d(input_l2d)  # 1

        if value_first:
            checked_list_2d = self.change_l2d_as_range_first(checked_list_2d, xyxy)
        for ix, list_1d in enumerate(checked_list_2d):
            sheet.Range(sheet.Cells(x1 + ix, y1), sheet.Cells(x1 + ix, y1 + len(list_1d) - 1)).Value = list_1d

    def write_l2d_for_range(self, sheet_name='', xyxy='', input_l2d=None):
        """
        2차원 리스트의 값을 영역에 쓰는것. 갯수가 크면, 그게 더 우선 된다

        """
        self.write_auto(sheet_name, xyxy, input_l2d, "value")

    def write_l2d_for_range_from_start_cell_by_mixed_types(self, sheet_name='', xyxy='', input_l2d=None):
        """
        여러가지 자료가 쉬여있는 자료를 쓰는것
        아래의 자료를 쓰기위한것

        """
        [sheet_name, xyxy, input_l2d] = self._check_3_param(sheet_name, xyxy, input_l2d)
        sheet = self.check_sheet_name(sheet_name)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        [x1, y1, x2, y2] = self.change_address_to_xyxy(xyxy)

        for x, l1d in enumerate(input_l2d):
            shift_y = 0
            for y, one_data in enumerate(l1d):
                if isinstance(one_data, str) or isinstance(one_data, int):
                    # 문자나 숫자일때
                    sheet.Cells(x1 + x, y1 + shift_y).Value = one_data
                    shift_y = shift_y + 1
                elif isinstance(one_data, list) or isinstance(one_data, int):
                    # 리스트나 튜플일때
                    for num, value in enumerate(one_data):
                        sheet.Cells(x1 + x, y1 + shift_y).Value = value
                        shift_y = shift_y + 1
                elif isinstance(one_data, tuple):
                    # 사전형식일때
                    changed_list = list(one_data.items())
                    for num, value in enumerate(changed_list):
                        sheet.Cells(x1 + x, y1 + shift_y).Value = value[0]
                        shift_y = shift_y + 1
                        sheet.Cells(x1 + x, y1 + shift_y).Value = value[1]
                        shift_y = shift_y + 1

    def write_l2d_for_range_with_yline_no_at_one_line(self, sheet_name, input_xno, input_yno, input_l1d):
        """
        같은 줄에 다른 값을 쓸때 사용. l2d= [[4, "박상진"], [5, title.strip()], [8, pr_no]]

        """
        sheet = self.check_sheet_name("")

        for x_no, value in input_l1d:
            sheet.Cells(input_xno + x_no, input_yno).Value = value

    def write_l2d_from_cell(self, sheet_name='', xyxy='', input_l2d=None):
        """
        입력된 셀을 기준으로 2차원 리스트형태의 값을 쓰기

        """
        [sheet_name, xyxy, input_l2d] = self._check_3_param(sheet_name, xyxy, input_l2d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        changed_l2d = self.check_input_data(input_l2d)
        len_x = len(changed_l2d)
        len_y = len(changed_l2d[0])
        sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x1 + len_x - 1, y1 + len_y - 1)).Value = changed_l2d

    def write_l2d_with_yline_no_at_one_line(self, sheet_name, xyxy, input_xno, input_yno, input_l1d):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x_no, value in input_l1d:
            sheet.Cells(input_xno + x_no, input_yno).Value = value

    def write_link_at_cell(self, sheet_name, xyxy, web_site_address="www.google.co.kr", tooltip=""):
        """
            값을 쓰면서, 링크를 거는것

            Examples
            --------
            """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.Hyperlinks.Add(Anchor=sheet.Cells(x1, y1), Address=web_site_address, ScreenTip=tooltip)

    def write_list_for_range(self, sheet_name='', xyxy='', input_list=None):
        """
        1차원의자료도 2차원으로 바꿔서, 값을 입력할 수 있다

        """
        [sheet_name, xyxy, input_list] = self._check_3_param(sheet_name, xyxy, input_list)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        changed_l2d = self.check_input_data(input_list)

        len_x = len(changed_l2d)
        len_y = len(changed_l2d[0])
        sheet.Range(sheet.Cells(x1, y1), sheet.Cells(x1 + len_x - 1, y1 + len_y - 1)).Value = changed_l2d

    def write_many_cell_at_same_xline(self, sheet_name, input_xno, yno_n_value_l2d):
        """
        코드가 보기 편하게 나타내기 위해서 같은 줄의 여러값을 넣을때 이것을 사용하면 좋을듯 하다

        업무에서, 찾거나 변경된 자료를 일일이 넣는것은 코드가 너무 많아 보여서 좀 줄여보기위해서 만든다
        """
        sheet = self.check_sheet_name(sheet_name)
        yno_n_value_l2d = self.check_input_data(yno_n_value_l2d)
        for yno, value in yno_n_value_l2d:
            sheet.Cells(input_xno, yno).Value = value

    def write_memo_at_cell(self, sheet_name, xyxy, input_value, is_replace=False):
        """
            셀에 메모를 넣는것. 기존에 메모가 있으면 내용이 변경된다

            Examples
            --------
            """
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        cell_obj = sheet.Cells(x1, y1)

        if is_replace:
            if cell_obj.Comment:
                existing_text = rng.Comment.Text()  # ← 별도 변수 사용
                cell_obj.Comment.Text(existing_text + str(input_value))  # ← 기존 + 새 메모
            else:
                cell_obj.AddComment(input_value)
        else:
            cell_obj.AddComment(input_value)

    def write_mixed_type_l2d(self, sheet_name='', xyxy='', input_l2d=None):
        """
        여러가지 자료가 섞여있는 자료를 쓰는것
        아래의 자료를 쓰기위한것

        """
        [sheet_name, xyxy, input_l2d] = self._check_3_param(sheet_name, xyxy, input_l2d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        for x, l1d in enumerate(input_l2d):
            shift_y = 0
            for y, one_data in enumerate(l1d):
                if isinstance(one_data, str) or isinstance(one_data, (int, float)):
                    # 문자나 숫자일때
                    sheet.Cells(x1 + x, y1 + shift_y).Value = one_data
                    shift_y = shift_y + 1
                elif isinstance(one_data, (list, tuple)) or isinstance(one_data, (int, float)):
                    # 리스트나 튜플일때
                    for num, value in enumerate(one_data):
                        sheet.Cells(x1 + x, y1 + shift_y).Value = value
                        shift_y = shift_y + 1
                elif isinstance(one_data, dict):
                    # 사전형식일때
                    changed_list = list(one_data.items())
                    for num, value in enumerate(changed_list):
                        sheet.Cells(x1 + x, y1 + shift_y).Value = value[0]
                        shift_y = shift_y + 1
                        sheet.Cells(x1 + x, y1 + shift_y).Value = value[1]
                        shift_y = shift_y + 1

    def write_random_for_l1d(self, sheet_name='', xyxy='', input_l1d=None):
        """
        1차원자료를 랜덤하게 원하는 영역에 쓰는것

        """
        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xyxy, input_l1d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(input_l1d)

        changed_l1d = self.xyutil.change_l2d_to_l1d(l2d)
        random.shuffle(changed_l1d)
        count_data = len(changed_l1d)
        temp_no = 0

        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            if divmod(x + y, count_data)[0] == 0:
                random.shuffle(changed_l1d)
                temp_no = 0
            sheet.Cells(x, y).Value = changed_l1d[temp_no]
            temp_no = temp_no + 1

    def write_searched_value_at_different_cell(self, xyxy="", value_line_no=2, changed_value_line_no=3, result_line_no=4, input_xre="[시작:처음][영어:1~4][한글:3~10]"):
        """
        선택한 영역의 모든 셀의 값에대하여, 정규표현식으로 찾은 값을 나열하는 것. 1개의 라인만 적용을 해야 한다

        value-line_no : 정규표현식을 적용할 y 라인
        changed_value_line-no : (int) value_line_no의 값을 바꾼후의 값, False값이면 적용되지 않는다
        result_line_no : (int) 찾은 값을 쓰는 첫번째 라인
        input_xre : (str) xre형식의 문자열
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy('', xyxy)

        all_data = self.read_value_for_range("", xyxy)  # 1
        x1, y1, x2, y2 = self.change_address_to_xyxy(xyxy)
        for index, l1d in enumerate(all_data):
            current_x = x1 + index
            if l1d:
                value = str(l1d[value_line_no]).lower().strip()
                found = self.xyre.search_all_by_xsql(input_xre, value)  # 정규표현식에 맞는 값을 확인
                # [[결과값, 시작순서, 끝순서, [그룹1, 그룹2...], match결과].....]
                if found:  # 만약 발견하면
                    gijon = self.read_value_for_cell("", [current_x, result_line_no])
                    changed_gijon = gijon + "," + l1d[0] + ":" + str(l1d[1]) + ":" + str(l1d[2])
                    if not changed_value_line_no:
                        sheet.Cells(current_x, result_line_no).Value = current_x, result_line_no

    def write_serial_date(self, sheet_name='', xyxy='', start_day="2025-03-01", day_step=1, multi_line=False):
        """
            어떤 날자를 기준으로 연속해서 날짜를 넣는것

            Examples
            --------
            """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        base_dt_obj = self.xytime.change_anytime_to_dt_obj(start_day)

        if not multi_line: y2 = y1
        repeat_no = 0
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            dt_obj_1 = self.xytime.shift_day_for_dt_obj(base_dt_obj, day_step * repeat_no)
            sheet.Cells(x, y).Value = self.xytime.change_dt_obj_to_yyyy_mm_dd(dt_obj_1)
            repeat_no = repeat_no + 1

    def write_serial_date_by_step(self, sheet_name, xyxy, start_day, day_step, multi_line):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        timex = xy_time.xy_time()
        base_dt_obj = timex.change_anytime_to_dt_obj(start_day)

        if not multi_line: y2 = y1
        repeat_no = 0
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            dt_obj_1 = timex.shift_day_for_dt_obj(base_dt_obj, day_step * repeat_no)
            sheet.Cells(x, y).Value = timex.change_dt_obj_to_yyyy_mm_dd(dt_obj_1)
            repeat_no = repeat_no + 1

    def write_serial_date_for_range_by_step(self, sheet_name, xyxy, start_day="2025-03-01", day_step=1, multi_line=False):
        """
        어떤 날자를 기준으로 연속해서 날짜를 넣는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        base_dt_obj = self.xytime.change_anytime_to_dt_obj(start_day)

        if not multi_line: y2 = y1
        repeat_no = 0
        for x, y in itertools.product(range(x1, x2 + 1), range(y1, y2 + 1)):
            dt_obj_1 = self.xytime.shift_day_for_dt_obj(base_dt_obj, day_step * repeat_no)
            sheet.Cells(x, y).Value = self.xytime.change_dt_obj_to_yyyy_mm_dd(dt_obj_1)
            repeat_no = repeat_no + 1

    def write_serial_no(self, sheet_name, xyxy, start_no, step_no, ydirection_tf=True):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        new_no = start_no
        if ydirection_tf:
            for no in range(0, x2 - x1 + 1):
                sheet.Cells(x1 + no, y1).Value = new_no
                new_no = new_no + step_no
        else:
            for no in range(0, x2 - x1 + 1):
                sheet.Cells(x1, y1 + no).Value = new_no
                new_no = new_no + step_no

    def write_serial_no_for_range_by_step(self, sheet_name, xyxy, start_no, step_no):
        """
        선택한 영역에 시작번호, 간격으로 이루어진 연속된 숫자를 쓰는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        count = 0
        update_no = start_no
        for x in range(0, x2 - x1 + 1):
            for y in range(0, y2 - y1 + 1):
                count = count + 1
                if divmod(count, step_no)[1] == 0:
                    sheet.Cells(x, y).Value = update_no
                    update_no = update_no + step_no

    def write_serial_no_for_range_by_step_to_xline(self, xyxy, start_no, step_no):
        """
        선택한 영역에 시작번호, 간격으로 이루어진 연속된 숫자를 쓰는것 (예 : 0,2,4,6,8....)
        """
        sheet = self.check_sheet_name("")
        new_no = start_no
        for no in range(0, xyxy[2] - xyxy[0] + 1):
            sheet.Cells(xyxy[0], xyxy[1] + no).Value = new_no
            new_no = new_no + step_no

    def write_serial_no_for_range_by_step_to_yline(self, sheet_name, xyxy, start_no, step_no):
        """
        선택한 영역에 시작번호, 간격으로 이루어진 연속된 숫자를 쓰는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        new_no = start_no
        for no in range(0, xyxy[2] - xyxy[0] + 1):
            sheet.Cells(xyxy[0] + no, xyxy[1]).Value = new_no
            new_no = new_no + step_no

    def write_serial_no_for_range_with_start_no(self, sheet_name, xyxy, start_no, step_no):
        """
        숫자를 주면 시작점부터 아래로 숫자를 써내려가는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        new_no = start_no
        for no in range(0, x2 - x1 + 1):
            sheet.Cells(x1 + no, y1).Value = new_no
            new_no = new_no + step_no

    def write_sum_result_from_xy_for_l2d(self, sheet_name, xyxy, input_l2d, xy):
        """
        선택한 영역의 세로 자료들을 다 더해서 제일위의 셀에 다시 넣는것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        x_len = len(input_l2d)
        y_len = len(input_l2d[0])
        for y in range(y_len):
            temp = ""
            for x in range(x_len):
                sheet.Cells(x + xy[0], y + xy[1]).Value = ""
                if input_l2d[x][y]:
                    temp = temp + " " + input_l2d[x][y]
            sheet.Cells(xy[0], y + xy[1]).Value = str(temp).strip()

    def write_test_data(self, data_type, input_value):
        """

        """
        if data_type == "l1d":
            data = self.varx["data"][input_value]
            self.new_sheet()
            self.write_value_for_range("", [1, 1], data)
        elif data_type == "l2d":
            data = self.varx["data"][input_value]
            self.new_sheet()
            self.write_value_for_range("", [1, 1], data)
        elif data_type == "t2d":
            data = self.varx["data"][input_value]
            changed_data = data.splitlines()
            self.new_sheet()
            self.write_value_for_range("", [1, 1], changed_data)
        elif data_type == "table2d":
            data = self.varx["data"][input_value]
            self.new_sheet()
            self.write_value_for_range("", [1, 1], data)
        elif data_type == "d1d":
            data = self.varx["data"][input_value]
            self.new_sheet()
            for index, key in enumerate(data.keys()):
                self.write_value_for_range("", [1 + index, 1], key)
                self.write_value_for_range("", [1 + index, 2], str(data[key]))
        elif data_type == "d2d":
            data = self.varx["data"][input_value]
            self.new_sheet()
            for index, key in enumerate(data.keys()):
                self.write_value_for_range("", [1 + index, 1], key)
                self.write_value_for_range("", [1 + index, 2], str(data[key]))

    def write_title_for_range_from_first_line(self, sheet_name='', xyxy=''):
        """
        영역을 주면, 제일 첫번째 라인의 값들을 적절한 형태로 제목으로 만들어 주는 것

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        all_data = []
        for y in range(xyxy[1], xyxy[3] + 1):
            xylist_data = []
            for x in range(xyxy[0], xyxy[2] + 1):
                # 병합이 있는 자료를 위해서 필요한 것이다
                aa = self.is_cell_in_merge(sheet_name, [x, y])
                if aa:
                    value = self.read_value_for_cell(sheet_name, [aa[2][0], aa[2][1]])
                else:
                    value = self.read_value_for_cell(sheet_name, [x, y])

                # 양쪽 공백을 없앤다
                value = str(value).strip()
                xylist_data.append(value)

            # 2줄 이상의 제목라인이 있을때, 위 아래의것을 합치기 위해서 필요
            final_title = ""
            for one in xylist_data:
                if one:
                    final_title = final_title + one + "_"
            # 아무런 제목도 없을경우는 가로의 숫자를 이용해서 만든 제목을 넣는다
            if final_title == "":
                final_title = "title_" + str(y) + "_"

            # 소문자로 만든다
            final_title = str(final_title[:-1]).lower()

            for bb in [[" ", "_"], ["&", ""], ["&", ""], ["(", ""], [")", ""], ["/", ""], ["-", ""], [".", ""],
                       ["%", ""]]:
                final_title = final_title.replace(bb[0], bb[1])

    def write_title_from_first_line(self, sheet_name='', xyxy=''):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        all_data = []
        for y in range(y1, y2 + 1):
            xylist_data = []
            for x in range(x1, x2 + 1):
                # 병합이 있는 자료를 위해서 필요한 것이다
                aa = self.is_merged_cell([x, y])
                if aa:
                    value = self.read([aa[2][0], aa[2][1]])
                else:
                    value = self.read([x, y])

                # 양쪽 공백을 없앤다
                value = str(value).strip()
                xylist_data.append(value)

            # 2줄 이상의 제목라인이 있을때, 위 아래의것을 합치기 위해서 필요
            final_title = ""
            for one in xylist_data:
                if one:
                    final_title = final_title + one + "_"
            # 아무런 제목도 없을경우는 가로의 숫자를 이용해서 만든 제목을 넣는다
            if final_title == "":
                final_title = "title_" + str(y) + "_"

            # 소문자로 만든다
            final_title = str(final_title[:-1]).lower()

            for bb in [[" ", "_"], ["&", ""], ["&", ""], ["(", ""], [")", ""], ["/", ""], ["-", ""], [".", ""],
                       ["%", ""]]:
                final_title = final_title.replace(bb[0], bb[1])

    def write_today_at_cell(self, sheet_name='', xyxy='', style="yyyy-mm-dd"):
        """
        현재 셀에 오늘 날짜를 입력하는것
        """
        [sheet_name, xyxy, style] = self._check_3_param(sheet_name, xyxy, style)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        dt_today = self.xytime.get_dt_obj_for_today()

        formatted_day = self.xytime.change_dt_to_user_style(dt_today, style)
        sheet.Cells(x1, y1).Value = formatted_day

    def write_value_at_end_of_column(self, sheet_name='', xyxy='', input_l1d=None):
        """
        ** 보관용
        a3을 예로들어서, a3을 기준으로, 입력한 값이있는제일 마지막 가로줄번호를 갖고온후,
        그 다음줄에 값을 넣는것
        어떤 선택된 자료의 맨 마지막에 값을 넣기
        """
        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xyxy, input_l1d)
        self.move_activecell_to_bottom_for_range(sheet_name, xyxy)
        xy = self.get_address_for_activecell()
        self.write_value_for_range(sheet_name, [xy[0] + 1, xy[1]], input_l1d)

    def write_value_by_xy_step(self, sheet_name, xyxy, input_value, xy_step):
        """

        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        for x in range(x1, x2 + 1):
            if divmod(x, xy_step[0])[1] == 0:
                for y in range(y1, y2 + 1):
                    if divmod(y, xy_step[1])[1] == 0:
                        sheet.Cells(x, y).Value = str(input_value)

    def write_value_for_activecell(self, input_value):
        """
        활성화된 셀에 입력된 값을 쓰기
        """
        sheet = self.check_sheet_name("")
        x1, y1, x2, y2 = self.change_address_to_xyxy("")
        sheet.Cells(x1, y1).Value = input_value

    def write_value_for_cell(self, sheet_name='', xyxy='', input_value=None):
        """
        셀에 값는 넣기, write_cell을 사용하는것이 더 이해하기 쉽다
        """
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_value = self.check_input_data(input_value)
        sheet.Cells(x1, y1).Value = input_value

    def write_value_for_cell_as_linked(self, sheet_name, xy, web_site_address="www.google.co.kr", tooltip=""):
        """
        값을 쓰면서, 링크를 거는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xy)
        sheet = self.check_sheet_name(sheet_name)
        sheet.Hyperlinks.Add(Anchor=sheet.Cells(x1, y1), Address=web_site_address, ScreenTip=tooltip)

    def write_range(self, sheet_name='', xyxy='', input_value=None):
        self.write_value_for_range(sheet_name, xyxy, input_value)

    def write_value_for_range(self, sheet_name='', xyxy='', input_value=None):
        """
        영역에 값 넣기, 영역과 값의 갯수가 틀리면, 값이 우선임
        하나하나 입력이 되는 모습을 보여주면서 실행된다
        """
        [sheet_name, xyxy, input_value] = self._check_3_param(sheet_name, xyxy, input_value)

        input_value = self.check_input_data(input_value)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        checked_l2d = self.xyutil.change_any_data_to_l2d(input_value)

        for index, l1d in enumerate(checked_l2d):
            r1c1 = self.change_address_to_r1c1([x1 + index, y1, x1 + index, y1 + len(l1d) - 1])
            sheet.Range(r1c1).Value = l1d

    def write_value_for_range_as_linked(self, sheet_name, xyxy, web_site_address="www.google.co.kr", tooltip=""):
        """
        값을 쓰면서, 링크를 거는것
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.Hyperlinks.Add(Anchor=sheet.Cells(x1, y1), Address=web_site_address, ScreenTip=tooltip)

    def write_value_for_range_by_range_priority(self, sheet_name='', xyxy='', input_l2d=None):
        """
        영역에 입력값을 쓰는 것인데, 만약 영역안의 셀의 갯수와 입력 자료의 갯수가 틀릴때, 영역을 기준으로 값을 쓰는 것이다
        """
        [sheet_name, xyxy, input_l2d] = self._check_3_param(sheet_name, xyxy, input_l2d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        for index, l1d in enumerate(input_l2d):
            if index >= x2 - x1 + 1:
                break
            else:
                if len(l1d) > y2 - y1 + 1:
                    r1c1 = self.change_address_to_r1c1([x1 + index, y1, x1 + index, y2])
                    sheet.Range(r1c1).Value = l1d[:y2 - y1 + 1]
                else:
                    r1c1 = self.change_address_to_r1c1([x1 + index, y1, x1 + index, y1 + len(l1d) - 1])
                    sheet.Range(r1c1).Value = l1d

    def write_value_for_range_by_reverse(self, sheet_name='', xyxy=''):
        """
        영역에 입력값을 쓰는 것이며, 현재 입력한 영역의 값을 읽어와서, 입력자료를 좌우를 바꾸는 형태로(xy를 yx로 바꿔서) 입력하는 것이다
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        l2d = self.xyutil.change_any_data_to_l2d(rng.Value)
        changed_l2d = []
        for y in range(len(l2d[0])):
            temp = []
            for x in range(len(l2d)):
                temp.append(l2d[x][y])
            changed_l2d.append(temp)
        self.new_sheet()
        self.write_l2d_from_cell("", [1, 1], changed_l2d)

    def write_value_for_range_by_value_priority(self, sheet_name='', xyxy='', input_l2d=None):
        """
        영역에 입력값을 쓰는 것이며, 선택한 영역의 갯수와 입력자료의 갯수가 틀릴때 , 입력자료의 갯수를 우선으로 쓰는것
        """
        [sheet_name, xyxy, input_l2d] = self._check_3_param(sheet_name, xyxy, input_l2d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)
        r1c1 = self.change_address_to_r1c1([x1, y1, x1 + len(input_l2d) - 1, y1 + len(input_l2d[0]) - 1])
        sheet.Range(r1c1).Value = input_l2d

    def write_value_for_range_by_xy_step(self, sheet_name, xyxy, input_value, xy_step):
        """
        영역에 입력값을 쓰는 것이며, 선택한 영역의 시작점부터 x,y 번째 셀마다 입력값을 쓰기
        """
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for x in range(x1, x2 + 1):
            if divmod(x, xy_step[0])[1] == 0:
                for y in range(y1, y2 + 1):
                    if divmod(y, xy_step[1])[1] == 0:
                        sheet.Cells(x, y).Value = input_value

    def write_value_for_range_except_none(self, sheet_name='', xyxy='', input_l2d=None):
        """
        입력값안에 들어있는 None은 값을 쓰지 않고 건너띄는 형식으로 입력한다. 즉, 자료를 변경하고싶지 않을때는 None으로 그위치에 넣으면, 기존의 값이 보존 된다
        """

        [sheet_name, xyxy, input_l2d] = self._check_3_param(sheet_name, xyxy, input_l2d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        input_l2d = self.xyutil.change_any_data_to_l2d(input_l2d)

        for ix, l1d in enumerate(input_l2d):
            for iy, one_value in enumerate(l1d):
                if one_value != None:
                    sheet.Cells(x1 + ix, y1 + iy).Value = one_value

    def write_value_for_range_to_ydirection_only(self, sheet_name='', xyxy='', input_l1d=None):
        """
        영역의 첫번째 셀을 기준으로 1차원 리스트의 자료를 아래(가로)로 쓰는것, 만약 영역보다 갯수 많으면, 갯수가 우선된다
        """
        [sheet_name, xyxy, input_l1d] = self._check_3_param(sheet_name, xyxy, input_l1d)
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)

        for index, one_value in enumerate(input_l1d):
            sheet.Cells(x1, index + y1).Value = one_value

    def write_value_in_statusbar(self, input_value):
        """
        스테이터스바에 글씨를 쓰는 것, 변경하거나 알리고싶은 내용을 나타낼수 있다
        """
        input_value = self.check_input_data(input_value)
        self.xlapp.StatusBar = input_value

    def write_vba_module(self, vba_code, macro_name):
        """
        텍스트로 만든 엑셀 매크로 코드를 현재 열려있는 엑셀화일에 vba모듈을 만드는 것이다
        """
        new_vba_code = "Sub " + macro_name + "()" + vba_code + "End Sub"
        mod = self.xlbook.VBProject.VBComponents.Add(1)
        mod.CodeModule.AddFromString(new_vba_code)

    def write_vba_module_for_workbook(self, vba_code, macro_name):
        """
        텍스트로 만든 엑셀 매크로 코드를 현재 열려있는 엑셀화일에 vba모듈을 만드는 것이다
        """
        new_vba_code = "Sub " + macro_name + "()" + vba_code + "End Sub"
        mod = self.xlbook.VBProject.VBComponents.Add(1)
        mod.CodeModule.AddFromString(new_vba_code)

    def write_with_link(self, sheet_name, xyxy, web_site_address, tooltip):
        sheet, [x1, y1, x2, y2], rng = self.check_sheet_n_xyxy(sheet_name, xyxy)
        sheet.Hyperlinks.Add(Anchor=sheet.Cells(x1, y1), Address=web_site_address,
                                 ScreenTip=tooltip)

    def write_with_new_sheet(self, input_value, start_xy):
        """
        새로운 시트를 만들면서 값을 넣는것이며, 어떤 형태의 값이라도 알아서 써준다
        """
        self.new_sheet()
        x1, y1 = [1, 1]
        if start_xy:
            x1, y1, x2, y2 = self.change_address_to_xyxy(start_xy)
        self.write_value_for_range("", [x1, y1], input_value)

##################################################################################
    def set_sheet(self, input_value=""):
        if input_value:
            common_dic["sheet_name"] =  input_value
        else:
            return common_dic["sheet_name"]

    def set_color2(self, input_value=""):
        if input_value:
            common_dic["color"] =  input_value
        else:
            return common_dic["color"]

    def set2(self, input1, input2):
        common_dic[input1] =  input2

    def set_xyxy(self, input_value=""):
        if input_value:
            common_dic["xyxy"] =  input_value
        else:
            return common_dic["xyxy"]

    def set_address(self, input_value=""):
        if input_value:
            common_dic["address"] =  input_value
        else:
            return common_dic["address"]

    def write2(self, input1, input2):
        common_dic[input1] =  input2

    def write3(self, xyxy, value, option):
        pass

    def read1(self, xyxy):
        pass

    def select1(self, input1=''):
        match input1:
            case '':
                self.select_xyxy("","")
            case "used":
                self.select_usedrange()
