# -*- coding: utf-8 -*-
import win32com.client  # pywin32의 모듈
import pythoncom
import xy_color, xy_time, xy_common

class xy_hwp:
	"""
	아래아 한글을 쉽게 사용이 가능하도록 만든 모듈
	"""
	def __history(self):
		"""
		2025-03-30 : 전체적으로 손을 봄
		"""
		pass
	def ___terms___(self):
		"""
		현재의 용어는 가능하면 cursor로 사용한다 (커서가 있는곳을 의미)

		:return:
		"""
		pass

	def __check_hwp_obj(self):
		"""
		현재 오픈된 한글 문서가 있으면, 그 객체를 갖고온다

		:return:
		"""
		result = False
		context = pythoncom.CreateBindCtx(0)
		running_coms = pythoncom.GetRunningObjectTable()
		monikers = running_coms.EnumRunning()
		for moniker in monikers:
			name = moniker.GetDisplayName(context, moniker)
			if "hwpobject" in str(name).lower():
				#print("실행중인 한글 프로그램", name)
				result = True
				obje = running_coms.GetObject(moniker)
				# 만약 실행중일때는 기존의 프로그램을 self.han_program으로 할당하는 것이다
				self.han_program = win32com.client.Dispatch(obje.QueryInterface(pythoncom.IID_IDispatch))
				#print("is visible => ", self.han_program.XHwpWindows.Active_XHwpWindow.Visible, name)

		#if result:
		#	print('한글 application이 실행중이네요 (O)')
		#else:
		#	print('한글 application이 실행중이지 않네에요 (X)')
		return result

	def __init__(self, file_name=""):
		"""
		기본적인 변수들을 설정합니다

		:param file_name:
		"""
		self.varx = xy_common.xy_common().varx  # package안에서 공통적으로 사용되는 변수들
		self.han_program = ""
		self.var_action_name_vs_parameter_set_id = self.varx["action_name_vs_parameter_set_id"]
		self.var_action_name_vs_manual = self.varx["action_name_vs_manual"]
		self.current = {}


		self.varx["action_name_vs_manual"] = {
			'SplitAll': '창 가로 세로 나누기',
			'NoSplit': '창 나누지 않음',
			'SplitVert': '창 세로로 나누기',
			'SplitHorz': '창 가로로 나누기',
			'SplitMemo': '메모창 보이기-감추기',
			'SplitMainActive': '메모창 활성화',
			'SplitMemoOpen': '메모창 열기',
			'SplitMemoClose': '메모창 닫기',
			'WindowPrevTab': '이전 창 활성화',
			'WindowNextTab': '다음 창 활성화',
			'WindowNextPane': '다음 분할창 활성화',
			'ShowNLPTab': '글 도우미 작업창 보이기',
			'WindowList': '창 목록',
			'WindowAlignCascade': '창 겹치게 배열',
			'WindowAlignTileHorz': '창 가로로 배열',
			'WindowAlignTileVert': '창 세로로 배열',
			'WindowMinimizeAll': '창 모두 아이콘으로 배열',
			'CharShapeHeight': '글자 크기',
			'CharShapeSpacing': '글자 자간',
			'CharShapeWidth': '글자 장평',
			'StyleCombo': '글자 스타일',
			'CharShapeLang': '글자 언어',
			'CharShapTypeface': '글자 모양',
			'ParaShapeLineSpace': '문단 모양',
			'ViewZoomRibon': '화면 확대',
			'MasterPageType': '바탕쪽 종류',
			'TableDrawPenStyle': '표 그리기 선 모양',
			'TableDrawPenWidth': '표 그리기 선 굵기',
			'NoteNumShape': '주석 번호 모양',
			'NotePosition': '각주 위치',
			'NoteLineLength': '주석 구분선 길이',
			'NoteLineShape': '주석 구분선 모양',
			'NoteLineWeight': '주석 구분선 굵기',
			'NoteLineColor': '주석 구분선 색',
			'EasyFind': '쉬운 찾기',
			'MarkPenColor': '형광펜 색',
			'TopTabFrameClose': '위쪽 작업창 감추기',
			'BottomTabFrameClose': '아래쪽 작업창 감추기',
			'LeftTabFrameClose': '왼쪽 작업창 감추기',
			'RightTabFrameClose': '오른쪽 작업창 감추기',
			'ShowFloatTabFrame': '플로팅 작업창 보이기-감추기',
			'SetWorkSpaceView': '작업창 보기 설정',
			'ShowTopWorkspace': '위쪽 작업창 보이기-감추기',
			'ShowLeftWorkspace': '왼쪽 작업창 보이기-감추기',
			'ShowBottomWorkspace': '아래쪽 작업창 보이기-감추기',
			'ShowRightWorkspace': '오른쪽 작업창 보이기-감추기',
			'HelpAbout': '글 2005 정보',
			'HancomRoom': '한컴 계약방',
			'PstGradientType': '프리젠테이션 그라데이션 형태',
			'PstScrChangeType': '프리젠테이션 화면 전환 형태',
			'PstBlackToWhite': '프리젠테이션 검은색 글자를 흰색으로 변경',
			'PstAutoPlay': '프리젠테이션 자동 시연',
			'PstSetupPrevSec': '프리젠테이션 앞 구역 설정',
			'PstSetupNextSec': '프리젠테이션 뒤 구역 설정',
			'CustRestBtn': '툴바 버튼 처음 상태로 되돌리기',
			'CustRenameBtn': '툴바 버튼 이름 바꾸기',
			'CustViewNameBtn': '툴바 버튼 이름만 보이기',
			'CustViewIconBtn': '툴바 버튼 아이콘만 보이기',
			'CustViewIconNameBtn': '툴바 버튼 이름과 아이콘 보이기',
			'CustInsSepBtn': '툴바 버튼에 구분선 넣기',
			'CustCopyBtn': '툴바 버튼 복사하기',
			'CustCutBtn': '툴바 버튼 오려두기',
			'CustEraseBtn': '툴바 버튼 지우기',
			'CustPasteBtn': '툴바 버튼 붙여기',
			'HelpContents': '내용',
			'HelpIndex': '찾아보기',
			'HelpWeb': '온라인 고객 지원',
			'MasterWsItemOnOff': '바탕쪽 작업창 보이기-감추기',
			'AppAbout': '글 2005 정보',
			'FileNew': '새 글',
			'FileNewTab': '새 탭',
			'FileSaveAsDRM': '배포용 문서로 저장하기',
			'FileClose': '문서 닫기',
			'TabClose': '현재탭 닫기',
			'FileQuit': '종료',
			'FileFind': '문서 찾기',
			'RecentEmpty': '최근 목록 지우기',
			'RecentNoExistDel': '최근 목록에서 존재하지 않는 아이템 지우기',
			'FileNextVersionDiff': '버전 비교 :   앞으로 이동',
			'FilePrevVersionDiff': '버전 비교 : 뒤로 이동',
			'FileVersionDiffChangeAlign': '버전 비교 : 비교화면 배열 변경 (좌우↔상하)',
			'FileVersionDiffSameAlign': '버전 비교 : 비교화면 다시 정렬',
			'FileVersionDiffSyncScroll': '버전 비교 : 비교화면 동시에 이동',
			'CustomizeToolbar': '도구상자 사용자 설정',
			'FrameFullScreen': '전체 화면',
			'FrameFullScreenEnd': '전체 화면 닫기',
			'FrameHRuler': '가로축 눈금자 보이기-감추기',
			'FrameVRuler': '세로축 눈금자 보이기-감추기',
			'FrameStatusBar': '상태바 보이기-감추기',
			'HorzScrollbar': '가로축 스크롤바 보이기-감추기',
			'VertScrollbar': '세로축 스크롤바 보이기-감추기',
			'ViewTabButton': '문서탭 보이기-감추기',
			'HwpViewType': '문서창 모양 설정',
			'ChangeSkin': '스킨 바꾸기',
			'ShowAttributeTab': '속성 작업창 보이기-감추기',
			'ShowScriptTab': '스크립트 작업창 보이기-감추기',
			'FrameViewZoomRibon': '화면 확대-축소',
			'HwpTabViewHwpDic': '사전 검색 작업창',
			'HwpTabViewNLP': '글 도우미 작업창',
			'HwpTabViewOutline': '개요 보기 작업창',
			'HwpTabViewMasterPage': '바탕쪽 보기 작업창',
			'HwpTabViewAction': '빠른 실행 작업창',
			'HwpTabViewDistant': '쪽모양 보기 작업창',
			'HwpTabViewClipboard': '클립보드 작업창',
			'HwpTabViewAttribute': '양식 개체 속성 작업창',
			'HwpTabViewScript': '스크립트 작업창',
			'HwpTabViewXMLTree': 'XML 문서 트리 작업창',
			'HwpTabViewXMLSchema': 'XML 문서 구조 작업창',
			'HwpWSDic': '사전 검색 작업창 (Shift + F12)',
			'SendBrowserText': '브라우저로 보내기',
			'ASendBrowserText': '웹브라우저로 보내기',
			'MoveLeft': '왼쪽으로 캐럿 이동',
			'MoveRight': '오른쪽으로 캐럿 이동',
			'MoveUp': '위쪽으로 캐럿 이동',
			'MoveDown': '아래쪽으로 캐럿 이동',
			'MoveSelLeft': '블록 설정 상태로 왼쪽으로 이동',
			'MoveSelRight': '블록 설정 상태로 오른쪽으로 이동',
			'MoveSelUp': '블록 설정 상태로 위쪽으로 이동',
			'MoveSelDown': '블록 설정 상태로 아래쪽으로 이동',
			'MovePrevChar': '한 글자 앞 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveNextChar': '한 글자 뒤로 이동,현재 리스트만을 대상으로 동작한다.',
			'MovePrevPos': '한 글자 앞으로 이동, 서브 리스트를 옮겨 다닐 수 있다.',
			'MoveNextPos': '한 글자 뒤로 이동,서브 리스트를 옮겨 다닐 수 있다.',
			'MovePrevPosEx': '한 글자 앞으로 이동,서브 리스트를 옮겨 다닐 수 있다. (머리말, 꼬리말, 각주, 미주, 글상자 포함)',
			'MoveNextPosEx': '한 글자 뒤로 이동,서브 리스트를 옮겨 다닐 수 있다,(머리말, 꼬리말, 각주, 미주, 글상자 포함)',
			'MovePrevWord': '한 단어 앞으로 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveNextWord': '한 단어 뒤로 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveWordBegin': '현재 위치한 단어의 시작으로 이동. 현재 리스트만을 대상으로 동작한다.',
			'MoveWordEnd': '현재 위치한 단어의 끝으로 이동. 현재 리스트만을 대상으로 동작한다.',
			'MoveDocBegin': '만약  셀렉션을  확장하는  경우에는 LIST_BEGIN-END와 동일하다,문서의 시작으로 이동. 현재 서브 리 스트 내에 있으면 빠져나간다.',
			'MoveDocEnd': '만약  셀렉션을  확장하는  경우에는 LIST_BEGIN-END와 동일하다,문서의 끝으로 이동. 현재 서브 리스 트 내에 있으면 빠져나간다.',
			'MoveLineBegin': '현재 위치한 줄의 시작-끝으로 이동',
			'MoveLineEnd': '현재 위치한 줄의 시작-끝으로 이동',
			'MoveParaBegin': '현재 위치한 문단의 시작-끝으로 이 동',
			'MoveParaEnd': '현재 위치한 문단의 시작-끝으로 이 동',
			'MovePageUp': '앞-뒤 페이지의 시작으로 이동,현재 탑 레벨 리스트가 아니면 탑 레 벨 리스트로 빠져나온다.',
			'MovePageDown': '앞-뒤 페이지의 시작으로 이동,현재 탑 레벨 리스트가 아니면 탑 레 벨 리스트로 빠져나온다.',
			'MovePageBegin': '쪽 맨 처음으로',
			'MovePageEnd': '쪽 맨 끝으로',
			'MoveListBegin': '현재 리스트의 시작으로 이동',
			'MoveListEnd': '현재 리스트의 끝으로 이동',
			'MoveTopLevelBegin': '탑 레벨 리스트의 시작으로 이동',
			'MoveTopLevelEnd': '탑 레벨 리스트의 끝으로 이동',
			'MovePrevParaEnd': '앞 문단의 끝-다음 문단의 시작으로 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveNextParaBegin': '앞 문단의 끝-다음 문단의 시작으로 이동,현재 리스트만을 대상으로 동작한다.',
			'MovePrevParaBegin': '앞 문단의 시작으로 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveSectionUp': '앞-뒤 섹션으로 이동,현재 루트 리스트가 아니면 루트 리 스트로 빠져나온다.',
			'MoveSectionDown': '앞-뒤 섹션으로 이동,현재 루트 리스트가 아니면 루트 리스트로 빠져나온다.',
			'MoveParentList 3': '한 레벨 상위-탑 레벨-루트 리스트로 이동한다. 현재 루트 리스트에 위치 해 있어 더 이상 상위 리스트가 없을 때는 위치 이동 없이 리턴 한다.',
			'MoveTopLevelList': '한 레벨 상위-탑 레벨-루트 리스트로 이동한다. 현재 루트 리스트에 위치 해 있어 더 이상 상위 리스트가 없을 때는 위치 이동 없이 리턴한다,이동한 후의 위치는 상위 리스트에서 서브리스트가 속한 컨트롤 코드가 위 치한 곳이다. 위치 이동시 셀렉션은 무조건 풀린다.',
			'MoveRootList': '한 레벨 상위-탑 레벨-루트 리스트로 이동한다. 현재 루트 리스트에 위치 해 있어 더 이상 상위 리스트가 없을 때는 위치 이동 없이 리턴 한다,이동한 후의 위치는 상위 리스트에서 서브리스트가 속한 컨트롤 코드가 위 치한 곳이다. 위치 이동시 셀렉션은 무조건 풀린다.',
			'MoveSelPrevChar': '셀렉션: 이전 글자',
			'MoveSelNextChar': '셀렉션: 다음 글자',
			'MoveSelPrevPos': '셀렉션: 이전 위치',
			'MoveSelNextPos': '셀렉션: 다음 위치',
			'MoveSelPrevWord': '셀렉션: 이전 단어',
			'MoveSelNextWord': '셀렉션: 다음 단어',
			'MoveSelWordBegin': '셀렉션: 단어 처음',
			'MoveSelWordEnd': '셀렉션: 단어 끝',
			'MoveSelDocBegin': '셀렉션: 문서 처음',
			'MoveSelDocEnd': '셀렉션: 문서 끝',
			'MoveSelLineBegin': '셀렉션: 줄 처음',
			'MoveSelLineEnd': '셀렉션: 줄 끝',
			'MoveSelParaBegin': '셀렉션: 문단 처음',
			'MoveSelParaEnd': '셀렉션: 문단 끝',
			'MoveSelPageUp': '셀렉션: 페이지 업',
			'MoveSelPageDown': '셀렉션: 페이지 다운',
			'MoveSelListBegin': '셀렉션: 리스트 처음',
			'MoveSelListEnd': '셀렉션: 리스트 끝',
			'MoveSelTopLevelBegin': '셀렉션: 처음',
			'MoveSelTopLevelEnd': '셀렉션: 끝',
			'MoveSelPrevParaEnd': '셀렉션: 이전 문단 끝',
			'MoveSelNextParaBegin': '셀렉션: 다음 문단 처음',
			'MoveSelPrevParaBegin': '셀렉션: 이전 문단 시작',
			'MoveLineUp': '한 줄 위-아래로 이동한다.',
			'MoveLineDown': '한 줄 위-아래로 이동한다.',
			'MoveViewUp': '현재 뷰의 크기만큼 위-아래로 이동한다. PgUp-PgDn 키의 기능이다.',
			'MoveViewDown': '현재 뷰의 크기만큼 위-아래로 이동 한다. PgUp-PgDn 키의 기능이다.',
			'MoveViewBegin': '현재 뷰의 시작-끝에 위치한 곳으로 이동',
			'MoveViewEnd': '현재 뷰의 시작-끝에 위치한 곳으로 이동',
			'MovePrevColumn': '앞 단으로 이동',
			'MoveNextColumn': '뒤 단으로 이동',
			'MoveColumnBegin': '단의 처음으로 이동',
			'MoveColumnEnd': '단의 끝으로 이동',
			'MoveScrollPrev': '이전 방향으로 스크롤하면서 이동',
			'MoveScrollNext': '다음 방향으로 스크롤하면서 이동',
			'MoveScrollUp': '위 방향으로 스크롤하면서 이동',
			'MoveScrollDown': '아래 방향으로 스크롤하면서 이동',
			'MoveSelLineUp': '셀렉션: 한줄 위',
			'MoveSelLineDown': '셀렉션: 한줄 아래',
			'MoveSelViewUp': '셀렉션: 위',
			'MoveSelViewDown': '셀렉션: 아래',
			'Close': '레퍼런스 포인트가 등록되어 있으면 그 포인트로, 없으면 루트 리스트로 이동한다,나머지특성은 MoveRootList와 동일',
			'CloseEx': '레퍼런스 포인트가 등록되어 있으면 그 포인트로, 없으면 루트 리스트로 이동한다.  이동할 때 캐럿이 위치할 수 있는 곳을 찾아서 리스트를 빠져 나간다,나머지특성은 MoveRootList와 동일',
			'TableLeftCell': '셀이동: 셀 왼쪽',
			'TableRightCell': '셀이동: 셀 오른쪽',
			'TableRightCellAppend': '셀이동: 셀 오른쪽에 이어서',
			'TableUpperCell': '셀이동: 셀 위',
			'TableLowerCell': '셀이동: 셀 아래',
			'TableColBegin': '셀이동: 열 시작',
			'TableColEnd': '셀이동: 열 끝',
			'TableColPageUp': '셀이동: 페이지 업',
			'TableColPageDown': '셀이동: 페이지 다운',
			'TableResizeLeft': '셀 크기 변경',
			'TableResizeRight': '셀 크기 변경',
			'TableResizeUp': '셀 크기 변경',
			'TableResizeDown': '셀 크기 변경',
			'TableResizeCellLeft': '셀 크기 변경: 셀 왼쪽',
			'TableResizeCellRight': '셀 크기 변경: 셀 오른쪽',
			'TableResizeCellUp': '셀 크기 변경: 셀 위',
			'TableResizeCellDown': '셀 크기 변경: 셀 아래',
			'TableResizeLineLeft': '셀 크기 변경: 선 왼쪽',
			'TableResizeLineRight': '셀 크기 변경: 선 오른쪽',
			'TableResizeLineUp': '셀 크기 변경: 선 위',
			'TableResizeLineDown': '셀 크기 변경: 선 아래',
			'HiddenCredits': '인터넷 정보',
			'Undo': '되살리기',
			'Redo': '다시 실행',
			'PasteSpecial': '골라 붙이기',
			'SelectAll': '모두 선택',
			'Select': '블록 설정',
			'SelectColumn': '칸 블록 설정',
			'Delete': 'Delete',
			'DeleteBack': 'Backspace',
			'DeleteLine': 'CTRL-Y (한줄 지우기)',
			'DeleteLineEnd': '현재 캐럿 이후 지우기',
			'DeleteWord': '단어 지우기 CTRL-T',
			'DeleteWordBack': '왼쪽 단어 지우기 CTRL-BS',
			'ToggleOverwrite': '삽입-수정',
			'Cancel': '취소 ESC',
			'FindForeBackFind': '앞뒤로 찾아가기 : 찾기',
			'FindForeBackPage': '앞뒤로 찾아가기 : 쪽',
			'FindForeBackSection': '앞뒤로 찾아가기 : 구역',
			'FindForeBackLine': '앞뒤로 찾아가기 : 줄',
			'FindForeBackStyle': '앞뒤로 찾아가기 : 스타일',
			'FindForeBackCtrl': '앞뒤로 찾아가기 : 조판부호',
			'FindForeBackBookmark': '앞뒤로 찾아가기 : 책갈피',
			'FindForeBackSelectCtrl': '앞뒤로  찾아가기  :  조판  부호  찾기(선택)',
			'ReturnPrevPos': '직전위치로 돌아가기',
			'ModifyShapeObject': '고치기-개체 속성',
			'ModifyCtrl': '고치기-컨트롤',
			'ModifyLineProperty': '고치기(선 속성 탭으로)',
			'ModifyFillProperty': '고치기(채우기 속성 탭으로)',
			'SelectCtrlReverse': '개체선택 역방향',
			'SelectCtrlFront': '개체선택 정방향',
			'CharShapeNormal': '보통모양 ALT+SHIFT+C',
			'CharShapeBold': '단축키: Alt+L(글자 진하게)',
			'CharShapeItalic': '이탤릭 ALT + SHIFT + I',
			'CharShapeUnderline': '밑줄 ALT+SHIFT+U',
			'CharShapeCenterline': '취소선',
			'CharShapeOutline': '외곽선',
			'CharShapeShadow': '그림자',
			'CharShapeEmboss': '양각',
			'CharShapeEngrave': '음각',
			'CharShapeSuperscript': '위첨자 ALT+SHIFT+P',
			'CharShapeSubscript': '아래첨자 ALT+SHIFT+S',
			'CharShapeSuperSubscript': '첨자 위첨자→아래첨자→보통 반복',
			'CharShapeHeightIncrease': '크기 크게 ALT+SHIFT+E',
			'CharShapeHeightDecrease': '크기 작게 ALT+SHIFT+R',
			'CharShapeWidthIncrease': '장평 넓게 ALT+SHIFT+K',
			'CharShapeWidthDecrease': '장평 좁게 ALT+SHIFT+J',
			'CharShapeSpacingIncrease': '자간 넓게 ALT+SHIFT+W',
			'CharShapeSpacingDecrease': '자간 좁게 ALT+SHIFT+N',
			'CharShapeNextFaceName': '다음 글꼴 ALT+SHIFT+F',
			'CharShapePrevFaceName': '이전 글꼴 ALT+SHIFT+G',
			'ParagraphShapeAlignJustify': '양쪽 정렬',
			'ParagraphShapeAlignLeft': '왼쪽 정렬',
			'ParagraphShapeAlignRight': '오른쪽 정렬',
			'ParagraphShapeAlignCenter': '가운데 정렬',
			'ParagraphShapeAlignDistribute': '배분 정렬',
			'ParagraphShapeAlignDivision': '나눔 정렬',
			'ParagraphShapeWithNext': '다음 문단과 함께',
			'ParagraphShapeProtect': '문단 보호',
			'ParagraphShapeIncreaseLeftMargin': '왼쪽 여백 키우기',
			'ParagraphShapeDecreaseLeftMargin': '왼쪽 여백 줄이기',
			'ParagraphShapeDecreaseRightMargin': '오른쪽 여백 키우기',
			'ParagraphShapeIncreaseRightMargin': '오른쪽 여백 줄이기',
			'ParagraphShapeIndentAtCaret': '첫 줄 내어 쓰기',
			'ParagraphShapeIndentNegative': '첫 줄을 한 글자 내어 씀',
			'ParagraphShapeIndentPositive': '첫 줄을 한 글자 들여 씀',
			'ParagraphShapeDecreaseLineSpacing': '줄 간격을 점점 좁힘',
			'ParagraphShapeIncreaseLineSpacing': '줄 간격을 점점 넓힘',
			'ParagraphShapeIncreaseMargin': '왼쪽-오른쪽 여백 키우기',
			'ParagraphShapeDecreaseMargin': '왼쪽-오른쪽 여백 줄이기',
			'StyleShortcut1': '스타일 단축키(<Ctrl + 1>',
			'StyleShortcut2': '스타일 단축키(<Ctrl + 2>',
			'StyleShortcut3': '스타일 단축키(<Ctrl + 3>',
			'StyleShortcut4': '스타일 단축키(<Ctrl + 4>',
			'StyleShortcut5': '스타일 단축키(<Ctrl + 5>',
			'StyleShortcut6': '스타일 단축키(<Ctrl + 6>',
			'StyleShortcut7': '스타일 단축키(<Ctrl + 7>',
			'StyleShortcut8': '스타일 단축키(<Ctrl + 8>',
			'StyleShortcut9': '스타일 단축키(<Ctrl + 9>',
			'StyleShortcut10': '스타일 단축키(<Ctrl + 0>',
			'StyleClearCharStyle': '글자 스타일 해제',
			'MasterPagePrevSection': '앞 구역 바탕쪽 사용',
			'MasterPageExcept': '첫 쪽 제외',
			'MPSectionToPrevious': '이전 구역으로',
			'MPSectionToNext': '이후 구역으로',
			'MasterPageToPrevious': '이전 바탕쪽',
			'MasterPageToNext': '이후 바탕쪽',
			'MasterPageDelete': '바탕쪽 삭제',
			'MasterPageDuplicate': '기존 바탕쪽과 겹침',
			'MasterPageFront': '바탕쪽 앞으로 보내기',
			'HeaderFooterToPrev': '이전 머리말',
			'HeaderFooterDelete': '머리말 지우기',
			'HeaderFooterModify': '머리말-꼬리말 고치기',
			'BreakPage': '쪽 나누기',
			'BreakColumn': '단 나누기',
			'BreakSection': '구역 나누기',
			'BreakLine': '줄 나눔',
			'BreakPara': '문단 나누기',
			'BreakColDef': '단 정의 삽입',
			'InsertPageNum': '쪽 번호 넣기',
			'CharShapeTextColorBlack': '글자색을 검정',
			'CharShapeTextColorRed': '글자색을 빨강',
			'CharShapeTextColorBlue': '글자색을 파랑',
			'CharShapeTextColorViolet': '글자색을 자주',
			'CharShapeTextColorGreen': '글자색을 초록',
			'CharShapeTextColorYellow': '글자색을 노랑',
			'CharShapeTextColorBluish': '글자색을 청록',
			'CharShapeTextColorWhite': '글자색을 흰색',
			'ViewOptionPaper': '쪽 윤곽 보기',
			'ViewOptionGuideLine': '안내선 보기',
			'ViewOptionPicture': '그림 보기',
			'ViewOptionMemo': '메모 보기',
			'ViewOptionMemoGuideline': '메모 안내선 보기',
			'ViewOptionParaMark': '문단 부호 보기',
			'ViewOptionCtrlMark': '조판 부호 보기',
			'InputCodeChange': '문자 코드 변환',
			'InsertDateCode': '상용구 코드 넣기 : 만든 날짜',
			'InsertCpNo': '상용구 코드 넣기 : 현재 쪽 번호',
			'InsertTpNo': '상용구 코드 넣기 : 현재 쪽수',
			'InsertCpTpNo': '상용구 코드 넣기 : 현재 쪽-전체 쪽 수',
			'InsertDocInfo': '상용구 코드 넣기 : 만든 사람, 현재 쪽 번호, 만든 날짜',
			'InsertLastSaveDate': '상용구  코드  넣기  :  마지막  저장한 날짜',
			'InsertLastSaveBy': '상용구  코드  넣기  :  마지막  저장한 사람',
			'InsertLastPrintDate': '상용구  코드  넣기  :  마지막  인쇄한날짜',
			'HimKbdChange': '바꾸기',
			'Soft Keyboard': '보기',
			'RunUserKeyLayout': '사용자 글자판 제작 툴',
			'Him Config': '입력기 언어별 환경 설정',
			'InsertFootnote': '각주 입력',
			'InsertEndnote': '미주 입력',
			'NoteNumProperty': '주석 번호 속성',
			'NoteToPrev': '주석 앞으로 이동',
			'NoteToNext': '주석 다음으로 이동',
			'NoteDelete': '주석 지우기',
			'NoteModify': '주석 고치기',
			'InsertAutoNum': '번호 다시 넣기',
			'Comment': '숨은 설명',
			'CommentModify': '숨은 설명 고치기',
			'CommentDelete': '숨은 설명 지우기',
			'HyperlinkBackward': '하이퍼링크 뒤로',
			'HyperlinkForward': '하이퍼링크 앞으로',
			'ReturnKeyInField': '캐럿이  필드  안에  위치한  상태에서Return Key에 대한 액션 분기',
			'QuickMarkInsert0': '쉬운 책갈피 - 삽입 0',
			'QuickMarkInsert1': '쉬운 책갈피 - 삽입 1',
			'QuickMarkInsert2': '쉬운 책갈피 - 삽입 2',
			'QuickMarkInsert3': '쉬운 책갈피 - 삽입 3',
			'QuickMarkInsert4': '쉬운 책갈피 - 삽입 4',
			'QuickMarkInsert5': '쉬운 책갈피 - 삽입 5',
			'QuickMarkInsert6': '쉬운 책갈피 - 삽입 6',
			'QuickMarkInsert7': '쉬운 책갈피 - 삽입 7',
			'QuickMarkInsert8': '쉬운 책갈피 - 삽입 8',
			'QuickMarkInsert9': '쉬운 책갈피 - 삽입 9',
			'QuickMarkMove0': '쉬운 책갈피 - 이동 0',
			'QuickMarkMove1': '쉬운 책갈피 - 이동 1',
			'QuickMarkMove2': '쉬운 책갈피 - 이동 2',
			'QuickMarkMove3': '쉬운 책갈피 - 이동 3',
			'QuickMarkMove4': '쉬운 책갈피 - 이동 4',
			'QuickMarkMove5': '쉬운 책갈피 - 이동 5',
			'QuickMarkMove6': '쉬운 책갈피 - 이동 6',
			'QuickMarkMove7': '쉬운 책갈피 - 이동 7',
			'QuickMarkMove8': '쉬운 책갈피 - 이동 8',
			'QuickMarkMove9': '쉬운 책갈피 - 이동 9',
			'InsertFieldMemo': '메모 넣기',
			'DeleteFieldMemo': '메모 지우기',
			'InsertTab': '탭 삽입',
			'InsertSoftHyphen': '하이픈 삽입',
			'InsertNonBreakingSpace': '묶음 빈칸 삽입',
			'InsertFixedWidthSpace': '고정 폭 빈칸 삽입',
			'RightShiftBlock': '텍스트 블록 상태에서 블록이 문단의 시작위치에서 시작할 경우 블록 왼쪽 에 탭을 삽입한다.',
			'LeftShiftBlock': '텍스트  블록  상태에서  블록  왼쪽에 있는 탭 또는 공백을 지운다.',
			'PictureToOriginal': '그림 원래 그림으로',
			'PictureSave': '그림 빼내기',
			'PictureScissor': '그림 자르기',
			'InsertLine': '선 넣기',
			'ShapeObjAttachCaption': '캡션 넣기',
			'ShapeObjInsertCaptionNum': '캡션 번호 넣기',
			'ShapeObjDetachCaption': '캡션 없애기',
			'AutoChangeRun': '동작',
			'AutoChangeHangul': '낱자모 우선',
			'ManualChangeHangul': '한영 수동 전환',
			'MakeIndex': '찾아보기 만들기',
			'MarkTitle': '제목 차례 표시',
			'HideTitle': '제목 차례 숨기기',
			'MacroRepeat': '키 매크로 실행',
			'MacroPause': '키 매크로 실행 일시 중지 (정의-실 행)',
			'MacroStop': '키 매크로 실행 중지 (정의-실행)',
			'MacroPlay1': '키 매크로 1',
			'MacroPlay2': '키 매크로 2',
			'MacroPlay3': '키 매크로 3',
			'MacroPlay4': '키 매크로 4',
			'MacroPlay5': '키 매크로 5',
			'MacroPlay6': '키 매크로 6',
			'MacroPlay7': '키 매크로 7',
			'MacroPlay8': '키 매크로 8',
			'MacroPlay9': '키 매크로 9',
			'MacroPlay10': '키 매크로 10',
			'MacroPlay11': '키 매크로 11',
			'ScrMacroRepeat': '스크립트 매크로 실행',
			'ScrMacroPause': '스크립트 매크로 실행 일시 중지 (정 의-실행)',
			'ScrMacroStop': '스크립트 매크로 실행 중지 (정의-실행)',
			'ScrMacroPlay1': '스크립트 매크로 1',
			'ScrMacroPlay2': '스크립트 매크로 2',
			'ScrMacroPlay3': '스크립트 매크로 3',
			'ScrMacroPlay4': '스크립트 매크로 4',
			'ScrMacroPlay5': '스크립트 매크로 5',
			'ScrMacroPlay6': '스크립트 매크로 6',
			'ScrMacroPlay7': '스크립트 매크로 7',
			'ScrMacroPlay8': '스크립트 매크로 8',
			'ScrMacroPlay9': '스크립트 매크로 9',
			'ScrMacroPlay10': '스크립트 매크로 10',
			'ScrMacroPlay11': '스크립트 매크로 11',
			'LabelAdd': '라벨 추가',
			'CaptureHandler': '갈무리 시작',
			'CaptureDialog': '갈무리 끝',
			'MailMergeField': '메일 머지 필드(표시달기 or 고치기)',
			'TableFormulaSumHor': '가로 합계',
			'TableFormulaSumVer': '세로 합계',
			'TableFormulaAvgHor': '가로 평균',
			'TableFormulaAvgVer': '세로 평균',
			'TableFormulaProHor': '가로 곱',
			'TableFormulaProVer': '세로 곱',
			'TableFormulaSumAuto': '블록 합계',
			'TableFormulaAvgAuto': '블록 평균',
			'TableFormulaProAuto': '블록 곱',
			'TableCellBlock': '셀 블록',
			'TableCellBlockExtend': '셀 블록 연장(F5 + F5)',
			'TableCellBlockExtendAbs': '셀 블록 연장(SHIFT + F5)',
			'TableCellBlockCol': '셀 블록 (칸)',
			'TableCellBlockRow': '셀 블록 (줄)',
			'TableMergeCell': '셀 합치기',
			'TableVAlignTop': '셀 세로 정렬 위',
			'TableVAlignCenter': '셀 세로정렬 가운데',
			'TableVAlignBottom': '셀 세로정렬 아래',
			'TableDistributeCellWidth': '셀 너비를 같게',
			'TableDistributeCellHeight': '셀 높이를 같게',
			'TableSplitTable': '표 나누기',
			'TableMergeTable': '표 붙이기',
			'TableAutoFill': '자동 채우기',
			'TableAutoFillDlg': '자동 채우기 내용',
			'TableCellAlignLeftTop': '셀 왼쪽 위 정렬',
			'TableCellAlignLeftCenter': '셀 왼쪽 가운데 정렬',
			'TableCellAlignLeftBottom': '셀 왼쪽 아래 정렬',
			'TableCellAlignCenterTop': '셀 가운데 위 정렬',
			'TableCellAlignCenterCenter': '셀 가운데 정렬',
			'TableCellAlignCenterBottom': '셀 가운데 아래 정렬',
			'TableCellAlignRightTop': '셀 가운데 오른쪽 정렬',
			'TableCellAlignRightCenter': '셀 오른쪽 가운데 정렬',
			'TableCellAlignRightBottom': '셀 오른쪽 아래 정렬',
			'ShapeObjLineProperty': '고치기 대화상자중 line tab',
			'ShapeObjFillProperty': '고치기 대화상자중 fill tab',
			'FormObjCreatorPushButton': '양식 개체 푸쉬 버튼 넣기',
			'FormObjCreatorRadioButton': '양식 개체 라디오 버튼 넣기',
			'FormObjCreatorCheckButton': '양식 개체 체크 박스 넣기',
			'FormObjCreatorComboBox': '양식 개체 콤보 박스 넣기',
			'FormObjCreatorEdit': '양식 개체 에디트 박스 넣기',
			'FormDesignMode': '양식 개체 디자인 모드 변경',
			'FormObjRadioGroup': '양식 개체 라디오 버튼 그룹 묶기',
			'DrawObjCancelOneStep': '다각형(곡선) 그리는 중 이전 선 지우기',
			'ShapeObjRotater': '자유 각 회전(회전 중심 고정)',
			'ShapeObjRightAngleRotater': '90도 회전',
			'DrawObjEditDetail': '그리기 개체 편집',
			'ShapeObjSelect': '튼 선택 도구',
			'ShapeObjNorm': '기본 도형 설정',
			'ShapeObjGroup': '틀 묶기',
			'ShapeObjUngroup': '틀 풀기',
			'ShapeObjBringToFront': '맨 앞으로',
			'ShapeObjSendToBack': '맨 뒤로',
			'ShapeObjBringForward': '앞으로',
			'ShapeObjSendBack': '뒤로',
			'ShapeObjBringInFrontOfText': '글 앞으로',
			'ShapeObjCtrlSendBehindText': '글 뒤로',
			'ShapeObjWrapTopAndBottom': '자리 차지',
			'ShapeObjWrapSquare': '직사각형',
			'ShapeObjPrevObject': '이전 개체로 이동(shift + tab키)',
			'ShapeObjNextObject': '이후 개채로 이동(tab키)',
			'ShapeObjHorzFlip': '그리기 개체 좌우 뒤집기',
			'ShapeObjVertFlip': '그리기 개체 상하 뒤집기',
			'ShapeObjLock': '개체 Lock',
			'ShapeObjUnlockAll': '개체 Unlock All',
			'ShapeObjAlignTop': '위로 정렬',
			'ShapeObjAlignMiddle': '중간 정렬',
			'ShapeObjAlignBottom': '아래로 정렬',
			'ShapeObjAlignLeft': '왼쪽으로 정렬',
			'ShapeObjAlignCenter': '가운데로 정렬',
			'ShapeObjAlignRight': '오른쪽으로 정렬',
			'ShapeObjAlignVertSpacing': '위-아래 일정한 비율로 정렬',
			'ShapeObjAlignHorzSpacing': '왼쪽-오른쪽 일정한 비율로 정렬',
			'ShapeObjAlignWidth': '폭 맞춤',
			'ShapeObjAlignHeight': '높이 맞춤',
			'ShapeObjAlignSize': '폭-높이 맞춤',
			'ShapeObjMoveLeft': '키로 움직이기(왼쪽)',
			'ShapeObjMoveRight': '키로 움직이기(오른쪽)',
			'ShapeObjMoveUp': '키로 움직이기(위)',
			'ShapeObjMoveDown': '키로 움직이기(아래)',
			'ShapeObjResizeLeft': '키로 크기 조절(shift + 왼쪽)',
			'ShapeObjResizeRight': '키로 크기 조절(shift + 오른쪽)',
			'ShapeObjResizeUp': '키로 크기 조절(shift + 위)',
			'ShapeObjResizeDown': '키로 크기 조절(shift + 아래)',
			'DrawObjTemplateSave': '그리기 마당에 등록',
			'ShapeObjAttachTextBox': '글상자로 만들기',
			'ShapeObjDetachTextBox': '글상자 속성 없애기',
			'ShapeObjTextBoxEdit': '글상자 선택상태에서 편집모드로 들어가기',
			'ShapeObjTableSelCell': '테이블 선택 상태에서 첫 번째 셀 선 택하기',
			'DrawObjOpenClosePolygon': '다각형 열기-닫기',
			'ImageFindPath': '그림 경로 찾기',
			'FillColorShadeInc': '면색 음영 비율 증가',
			'FillColorShadeDec': '면색 음영 비율 감소',
			'FileOpen': '불러오기',
			'FileSave': '저장하기',
			'FileOpenMRU': '최근 작업 문서',
			'FileSaveAs': '다른 이름으로 저장하기',
			'FileSaveAsHwp97': '글 97문서로 저장하기',
			'FilePreview': '미리 보기',
			'FileVersionOpen': '버전 불러오기',
			'FileVersionDiff': '버전 비교',
			'ACreateSchema': 'XML 문서 구조 불러오기',
			'AOpenXMLDoc': 'XML 문서 불러오기',
			'ASaveXMLDoc': 'XML 문서 저장하기',
			'FileTemplate': '문서마당',
			'DocSummaryInfo': '문서 정보',
			'DocumentInfo': '현재 문서에 대한 정보',
			'LinkDocument': '문서 연결',
			'Print': '인쇄',
			'Preference': '환경 설정',
			'SendMailAttach': '편지 보내기-첨부 파일로',
			'SendMailText': '편지 보내기-본문으로',
			'PrintToImage': '그림으로 저장하기',
			'PrintToFax': 'UMS(fax)로 인쇄하기',
			'PrintToPDF': 'Adobe PDF로 인쇄하기',
			'FtpUpload': '웹 서버로 올리기',
			'FilePassword': '문서 암호',
			'FileSecurity': '배포용 문서로 저장하기',
			'SaveBlockAction': '블록 저장하기',
			'VersionInfo': '버전 관리',
			'VersionSave': '새 버전으로 저장',
			'ALoadUserInfoFile': '사용자 환경 파일 읽어오기',
			'Cut': '오려 두기',
			'Copy': '복사하기',
			'Erase': '지우기',
			'Paste': '붙이기',
			'FindDlg': '찾기',
			'RepeatFind': '다시 찾기',
			'ReverseFind': '거꾸로 찾기',
			'ForwardFind': '앞으로 찾기',
			'BackwardFind': '뒤로 찾기',
			'ReplaceDlg': '찾아 바꾸기',
			'ExecReplace': '바꾸기(실행)',
			'AllReplace': '모두 바꾸기',
			'DocFindInit': '문서 찾기 초기화',
			'DocFindNext': '문서 찾기 계속',
			'DocFindEnd': '문서 찾기 종료',
			'Goto': '찾아가기',
			'GotoStyle': '찾아가기-스타일(찾기-바꾸기 대화상자에서 사용)',
			'ConvertToHangul': '한글로',
			'ConvertHiraGata': '일어 바꾸기',
			'ConvertJianFan': '간체-번체 바꾸기',
			'ConvertCase': '대소문자 바꾸기',
			'ConvertFullHalfWidth': '전각 반각 바꾸기',
			'GetSectionApplyString': '유틸리티 액션',
			'GetSectionApplyTo': '유틸리티 액션',
			'GetDocFilters': '유틸리티 액션',
			'PasteHtmlDialog': 'HTML 문서 붙이기',
			'CharShapeDialog': '글자 모양 대화상자(내부 구현용)',
			'CharShape': '글자 모양',
			'MarkPenShape': '형광펜 모양',
			'ParaShapeDialog': '문단 모양 대화상자(내부 구현용)',
			'ParagraphShape': '문단 모양',
			'ParaNumberBullet': '문단번호-글머리표',
			'OutlineNumber': '개요 번호',
			'ParaNumberBulletLevelUp': '문단번호-글머리표 한 수준 위로',
			'ParaNumberBulletLevelDown': '문단번호-글머리표 한 수준 아래로',
			'PutParaNumber': '문단번호 달기',
			'PutNewParaNumber': '문단번호 새 번호 시작하기',
			'PutBullet': '글머리표 달기',
			'PutOutlineNumber': '개요 번호 닫기',
			'GetDefaultParaNumber': '문단 번호 디폴트 값',
			'GetDefaultBullet': '글머리표 디폴트 값',
			'StyleParaNumberBullet': '문단번호-글머리표',
			'PageBorder': '쪽 테두리-배경',
			'DropCap': '문단 첫 글자 장식',
			'ShapeCopyPaste': '모양 복사',
			'Style': '스타일',
			'StyleTemplate': '스타일 마당',
			'PageSetup': '편집 용지',
			'ModifySection': '구역',
			'MasterPage': '바탕쪽 Entry',
			'MasterPageEntry': '바탕쪽',
			'MasterPageTypeDlg': '바탕쪽 종류 다이얼로그 띄움',
			'HeaderFooter': '머리말-꼬리말',
			'HeaderFooterInsField': '코드 넣기',
			'HeaderFooterToNext': '이후 머리말',
			'MultiColumn': '다단',
			'PageHiding': '감추기',
			'PageHidingModify': '감추기 고치기',
			'PageNumPos': '쪽 번호 매기기',
			'PageNumPosModify': '쪽 번호 매기기',
			'NewNumber': '새 번호로 시작',
			'NewNumberModify': '새 번호 고치기',
			'ViewZoom': '화면 확대(Ribbon)',
			'ViewZoomNormal': '화면 확대: 정상',
			'ViewZoomFitPage': '화면 확대: 페이지에 맞춤',
			'ViewZoomFitWidth': '화면 확대: 폭에 맞춤',
			'ViewGridOption': '격자',
			'ViewShowGrid': '격자 보이기',
			'Idiom': '상용구',
			'ViewIdiom': '상용구 보기',
			'InsertIdiom': '상용구 등록',
			'InputDateStyle': '날짜-시간 기본 형식 지정',
			'InsertUserName': '상용구 코드 넣기 : 만든 사람',
			'InsertFileName': '상용구 코드 넣기 : 파일 이름',
			'InsertFilePath': '상용구 코드 넣기 : 파일 경로',
			'InsertDocTitle': '상용구 코드 넣기 : 문서 제목',
			'ComposeChars': '글자 겹침',
			'DutmalChars': '덧말 넣기',
			'AddHanjaWord': '한자 단어 등록',
			'EquationCreate': '수식 만들기',
			'EquationPropertyDialog': '수식 고치기 (대화상자)',
			'EquationModify': '수식 고치기',
			'FootnoteOption': '각주-미주 모양',
			'ExchangeFootnoteEndnote': '각주-미주 변환',
			'SaveFootnote': '주석 저장',
			'Bookmark': '책갈피',
			'ModifyBookmark': '책갈피 고치기',
			'Hyperlink': '캐럿이 필드 안에 위치했는지 여부에 따라 Insert 또는 Modify 하이퍼 링크 액션',
			'InsertHyperlink': '하이퍼링크 만들기',
			'ModifyHyperlink': '하이퍼링크 고치기',
			'HyperlinkJump': '하이퍼링크 이동',
			'InsertCrossReference': '상호 참조 넣기',
			'ModifyCrossReference': '상호 참조 고치기',
			'InsertFieldTemplate': '문서마당 정보',
			'ModifyFieldClickhere': '누름틀 정보 고치기',
			'ModifyFieldUserInfo': '개인 정보 필드 고치기',
			'ModifyFieldSummary': '문서 요약 필드 고치기',
			'ModifyFieldDate': '날짜 필드 고치기',
			'ModifyFieldPath': '문서 경로 필드 고치기',
			'InsertFile': '끼워 넣기',
			'MemoShape': '메모 모양',
			'InsertText': '텍스트 삽입',
			'InsertSpace': '공백 삽입',
			'OleCreateNew': '개체 삽입',
			'InsertVoice': '음성 삽입',
			'InsertFlash': '플래쉬 삽입',
			'InsertMoive': '동영상 삽입',
			'PictureInsertDialog': '그림 넣기 (대화상자를 띄워 선택한 이미지 파일을 문서에 삽입하는 액션: API용)',
			'ShapeObjDialog': '환경 설정',
			'DrawObjTemplateLoad': '그리기 마당에서 불러오기',
			'DrawObjCreatorTextBox': '글상자',
			'DrawObjCreatorConnectLine': '개체 연결선 만들기',
			'PictureEffect1': '그림 그레이 스케일',
			'PictureEffect2': '그림 흑백으로',
			'PictureEffect3': '그림 워터마크',
			'PictureEffect4': '그림 효과 없음',
			'PictureEffect5': '그림 밝기 증가',
			'PictureEffect6': '그림 밝기 감소',
			'PictureEffect7': '그림 명암 증가',
			'PictureEffect8': '그림 명암 감소',
			'PictureLinkedToEmbedded': '연결된 그림을 모두 삽입 그림으로',
			'QuickCorrect': '빠른 교정',
			'QuickCorrect Edit': '빠른 교정 - 내용 편집',
			'QuickCorrect Run': '빠른 교정 동작',
			'QuickCorrect Sound': '빠른   교정   -   메뉴에서   효과음On-Off',
			'ChangeRome': '로마자 변환',
			'ChangeRome String': '로마자변환 - 입력받은 스트링 변환',
			'GetRome String': '로마자 변환 - 입력 받은 스트링 변 환을 로마자로 변환해서 넘겨줌',
			'ChangeRome User': '로마자 사용자 데이터',
			'ChangeRome User String': '로마자 사용자 데이터 추가',
			'SearchForeign': '외래어 사전 검색',
			'SearchAddress': '주소 검색',
			'IndexMark': '찾아보기 표시',
			'MakeContents': '차례 만들기',
			'IndexMarkModify': '찾아보기 표시 고치기',
			'MacroDefine': '키 매크로 정의',
			'MacroRepeatDlg': '키 매크로 실행(대화상자)',
			'ScrMacroDefine': '스크립트 매크로 정의',
			'ScrMacroRepeatDlg': '스크립트 매크로 실행',
			'LabelTemplate': '라벨 문서 만들기',
			'ManuScriptTemplate': '원고지 쓰기',
			'Presentation': '프레젠테이션',
			'PresentationSetup': '프레젠테이션 설정',
			'MailMergeInsert': '메일 머지 표시 달기',
			'MailMergeModify': '메일 머지 고치기',
			'MailMergeGenerate': '메일 머지 만들기',
			'Sort': '소트',
			'Sum': '블록 합계',
			'Average': '블록 평균',
			'QuickCommand Run': '입력 자동 명령 동작 - 메뉴에서 동작 체크 On-Off',
			'AQcommandMerge': '입력 장동 명령',
			'TableCreate': '표 만들기',
			'TableFormula': '계산식',
			'TablePropertyDialog': '표 고치기',
			'TableSplitCell': '셀 나누기',
			'TableSplitCellRow2': '셀 줄 나누기',
			'TableSplitCellCol2': '셀 칸 나누기',
			'TableDeleteRowColumn': '줄-칸 지우기',
			'TableDeleteColumn': '칸 지우기',
			'TableDeleteRow': '줄-칸 지우기',
			'TableInsertRowColumn': '줄-칸 삽입',
			'TableInsertLeftColumn': '왼쪽 칸 삽입',
			'TableInsertRightColumn': '오른쪽 칸 삽입',
			'TableInsertUpperRow': '위쪽 줄 삽입',
			'TableInsertLowerRow': '아래쪽 줄 삽입',
			'TableAppendRow': '줄 추가',
			'TableSubtractRow': '줄 제거',
			'CellBorderFill': '셀 테두리 배경',
			'CellBorder': '셀 테두리 배경',
			'CellFill': '셀 배경',
			'CellZoneBorderFill': '여러 셀에 걸쳐 적용',
			'CellZoneBorder': '셀 테두리 적용',
			'CellZoneFill': '셀 배경에 적용',
			'TableDrawPen': '표 그리기',
			'TableEraser': '표 지우개',
			'TableDeleteCell': '셀 삭제',
			'TableAutoDrawPenStyleWidthDlg': '선 모양',
			'TableCellShadeInc': '셀 음영 비율 증가',
			'TableCellShadeDec': '셀 음영 비율 감소',
			'TableTableToString': '표를 문자열로',
			'TableStringToTable': '문자열을 표로',
			'TableTemplate': '표 마당',
			'InsertChart': '차트 만들기',
			'TableSwap': '표 뒤집기',
			'ShapeObjAttrDialog': '특 속성 환경 설정',
			'DrawObjCreatorLine': '선 그리기',
			'DrawObjCreatorRectangle': '사각형 그리기',
			'DrawObjCreatorEllipse': '원 그리기',
			'DrawObjCreatorArc': '호 그리기',
			'DrawObjCreatorPolygon': '다각형 그리기',
			'DrawObjCreatorCurve': '곡선 그리기',
			'DrawObjCreatorFreeDrawing': '펜',
			'FormObjectPropertyDialog': '양식 개체 고치기',
			'FormObjCharShape': '양식 개체 글자 모양 속성 변경',
			'FormObjInputCodeTable': '양식 개체 Edit에서만 사용하는 문자 표',
			'FormObjInputHanja': '양식 개체 Edit에서만 사용하는 한자 로 바꾸기',
			'FormObjHanjaBusu': '양식 개체 Edit에서만 사용하는 한자 부수 입력',
			'FormObjHanjaMean': '양식 개체 Edit에서만 사용하는 한자 새김 입력',
			'FormObjInputIdiom': '양식 개체 Edit에서만 사용하는 상용 구 입력',
			'DrawObjCreatorMultiLine': '반복해서 선 그리기',
			'DrawObjCreatorMultiRectangle': '반복해서 사각형 그리기',
			'DrawObjCreatorMultiEllipse': '반복해서 원 그리기',
			'DrawObjCreatorMultiArc': '반복해서 호 그리기',
			'DrawObjCreatorMultiPolygon': '반복해서 다각형 그리기',
			'DrawObjCreatorMultiCurve': '반복해서 곡선 그리기',
			'DrawObjCreatorMultiFreeDrawing': '반복해서 펜 그리기',
			'DrawObjCreatorMultiTextBox': '반복해서 글상자 그리기',
			'ShapeObjRandomAngleRotater': '자유 각 회전',
			'ShapeObjShear': '기울이기',
			'ShapeObjSaveAsPicture': '그리기개체를 그림으로 저장하기',
			'MessageBox': '메시지 박스',
		}
		self.varx["parameter_vs_manual"] = {
			'AutoFillSection': ['자동 채우기 섹션', 'unsigned int'],
			'AutoFillItem': ['섹션의 아이템 인덱스', 'unsigned int'],
			'NumType': ['번호 종류', 'unsigned char'],
			'NewNumber': ['새 시작 번호 (1 .. n)', 'unsigned short'],
			'Name': ['책갈피 이름', 'string'],
			'Type': ['책갈피 종류', 'unsigned int'],
			'Command': ['책갈피 명령의 종류', 'unsigned int'],
			'BorderTypeLeft': ['4방향 테두리 종류', 'unsigned short'],
			'BorderTypeRight': ['4방향 테두리 종류', 'unsigned short'],
			'BorderTypeTop': ['4방향 테두리 종류', 'unsigned short'],
			'BorderTypeBottom': ['4방향 테두리 종류', 'unsigned short'],
			'BorderWidthLeft': ['4방향 테두리 두께', 'unsigned char'],
			'BorderWidthRight': ['4방향 테두리 두께', 'unsigned char'],
			'BorderWidthTop': ['4방향 테두리 두께', 'unsigned char'],
			'BorderWidthBottom': ['4방향 테두리 두께', 'unsigned char'],
			'BorderCorlorLeft': ['4방향 테두리 색깔', 'unsigned long'],
			'BorderColorRight': ['4방향 테두리 색깔', 'unsigned long'],
			'BorderColorTop': ['4방향 테두리 색깔', 'unsigned long'],
			'BorderColorBottom': ['4방향 테두리 색깔 :아래, RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
			'SlashFlag': ['슬래쉬 대각선 플래그', 'unsigned short'],
			'BackSlashFlag': ['백슬래쉬 대각선 플래그', 'unsigned short'],
			'DiagonalType': ['선 종류', 'unsigned short'],
			'DiagonalWidth': ['선 굵기', 'unsigned char'],
			'DiagonalColor': ['선 색상, RGB-32비트 (0x00BBGGRR)셀에서는 대각선), 표에서는 자동으로 나눠진 경계선에서 사용', 'unsigned long'],
			'BorderFill3D': ['3차원 효과', 'unsigned char'],
			'Shadow': ['그림자 효과', 'unsigned char'],
			'FillAttr': ['배경 채우기 속성', 'set'],
			'CrookedSlashFlag': ['꺾인 대각선 플래그 (bit 0, 1이 각각 slash, back slash의 가 운데 대각선이 꺾인 대각선임을 나타낸다.)', 'unsigned short'],
			'BreakCellSeparateLine': ['자동으로 나뉜 표의 경계선 설정', 'unsigned char'],
			'CounterSlashFlag': ['슬래쉬 대각선의 역방향 플래그(우상향 대각선)', 'unsigned char'],
			'CounterBackSlashFlag': ['역슬래쉬 대각선의 역방향 플래그(좌상향 대각선)', 'unsigned char'],
			'CenterLineFlag': ['중심선', 'unsigned char'],
			'CrookedSlashFlag1': [
				'Low Byte CrookedSlashFlag (슬래쉬 대각선의 꺾임 여부) (CrookedSlashFlag를 쓰기 편하도록 CrookedSlashFlag1/2로 나눔)',
				'unsigned char'],
			'CrookedSlashFlag2': [
				'High Byte CrookedSlashFlag (역슬래쉬 대각선의 꺾임 여부) (CrookedSlashFlag를 쓰기 편하도록 CrookedSlashFlag1/2로 나눔)',
				'unsigned char'],
			'TypeHorz': ['중앙선 종류', 'unsigned short'],
			'TypeVert': ['중앙선 종류', 'unsigned short'],
			'WidthHorz': ['중앙선 두께', 'unsigned char'],
			'WidthVert': ['중앙선 두께', 'unsigned char'],
			'ColorHorz': ['중앙선 색깔', 'unsigned long'],
			'ColorVert': ['중앙선 색깔', 'unsigned long'],
			'HasCharShape': ['자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
			'CharShape': ['글자 모양 (HasCharShape가 1일 경우에만 사용)', 'set'],
			'WidthAdjust': ['번호 너비 보정 값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'TextOffset': ['본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'Alignment': ['번호 정렬', 'unsigned char'],
			'UseInstWidth': ['번호 너비를 문서 내 문자열의 너비에 따를지 여부 ', 'unsigned char'],
			'AutoIndent': ['번호 너비 자동 들여쓰기 여부', 'unsigned char'],
			'TextOffsetType': ['본문과의 거리 종류', 'unsigned char'],
			'BulletChar': ['불릿 문자 코드', 'unsigned short'],
			'HasImage': ['그림 글머리표 여부', 'unsigned char'],
			'BulletImage': ['글머리표 이미지', 'set'],
			'Side': ['방향', 'unsigned char'],
			'Width': ['캡션 폭 (가로 방향일 때만 사용됨. 단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며), 1inch는 7200HWPUNIT)', 'int'],
			'Gap': ['캡션과 틀 사이 간격( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'CapFullSize': ['캡션 폭에 여백을 포함할지 여부 (세로 방향일 때만 사용됨)', 'unsigned char'],
			'BeginX': ['시작점과 X 좌표(페이지 X좌표)', 'int'],
			'BeginY': ['시작점과 Y 좌표(페이지 Y좌표)', 'int'],
			'EndX': ['끝점의 X 좌표(페이지 X좌표)', 'int'],
			'EndY': ['끝점의 Y 좌표(페이지 Y좌표)', 'int'],
			'PageNum': ['페이지 번호', 'unsigned int'],
			'HasMargin': ['테이블의 기본 셀 여백 대신 자체 셀 여백을 적용할지 여부. ', 'unsigned char'],
			'Protected': ['사용자 편집을 막을지 여부', 'unsigned char'],
			'Header': ['제목 셀인지 여부', 'unsigned char'],
			'Height': ['셀의 높이 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며), 1inch는 7200HWPUNIT)', 'long'],
			'Editable': ['양식모드에서 편집 가능 여부', 'unsigned char'],
			'Dirty': ['초기화 상태인지 수정된 상태인지 여부', 'unsigned char'],
			'CellCtrlData': ['셀 데이터 (글2007에 새로 추가)', 'set'],
			'ApplyTo': ['적용 대상', 'unsigned char'],
			'NoNeighborCell': ['주변 셀에 선 모양을 적용하지 않을지 여부 (1이면 적용하지 않는 다)', 'unsigned char'],
			'TableBorderFill': ['표 테두리/배경', 'set'],
			'AllCellsBorderFill': ['전체 셀의 테두리/배경', 'set'],
			'SelCellsBorderFill': ['선택된 셀의 테두리/배경', 'set'],
			'Option': ['변환옵션', 'unsigned char'],
			'HanString': ['변경시킬 또는 변경된 한글문자', 'string'],
			'FaceNameHangul': ['글꼴 이름 (한글)', 'string'],
			'FaceNameLatin': ['글꼴 이름 (영문)', 'string'],
			'FaceNameHanja': ['글꼴 이름 (한자)', 'string'],
			'FaceNameJapanese': ['글꼴 이름 (일본어)', 'string'],
			'FaceNameOther': ['글꼴 이름 (기타)', 'string'],
			'FaceNameSymbol': ['글꼴 이름 (심벌)', 'string'],
			'FaceNameUser': ['글꼴 이름 (사용자)', 'string'],
			'FontTypeHangul': ['폰트 종류 (한글)', 'unsigned char'],
			'FontTypeLatin': ['폰트 종류 (영문)', 'unsigned char'],
			'FontTypeHanja': ['폰트 종류 (한자)', 'unsigned char'],
			'FontTypeJapanese': ['폰트 종류 (일본어)', 'unsigned char'],
			'FontTypeOther': ['폰트 종류 (기타)', 'unsigned char'],
			'FontTypeSymbol': ['폰트 종류 (심벌)', 'unsigned char'],
			'FontTypeUser': ['폰트 종류 (사용자)', 'unsigned char'],
			'SizeHangul': ['각 언어별 크기 비율. (한글) 10% - 250%', 'unsigned char'],
			'SizeLatin': ['각 언어별 크기 비율. (영문) 10% - 250%', 'unsigned char'],
			'SizeHanja': ['각 언어별 크기 비율. (한자) 10% - 250%', 'unsigned char'],
			'SizeJapanese': ['각 언어별 크기 비율. (일본어) 10% - 250%', 'unsigned char'],
			'SizeOther': ['각 언어별 크기 비율. (기타) 10% - 250%', 'unsigned char'],
			'SizeSymbol': ['각 언어별 크기 비율. (심벌) 10% - 250%', 'unsigned char'],
			'SizeUser': ['각 언어별 크기 비율. (사용자) 10% - 250%', 'unsigned char'],
			'RatioHangul': ['각 언어별 장평 비율. (한글) 50% - 200%', 'unsigned char'],
			'RatioLatin': ['각 언어별 장평 비율. (영문) 50% - 200%', 'unsigned char'],
			'RatioHanja': ['각 언어별 장평 비율. (한자) 50% - 200%', 'unsigned char'],
			'RatioJapanese': ['각 언어별 장평 비율. (일본어) 50% - 200%', 'unsigned char'],
			'RatioOther': ['각 언어별 장평 비율. (기타) 50% - 200%', 'unsigned char'],
			'RatioSymbol': ['각 언어별 장평 비율. (심벌) 50% - 200%', 'unsigned char'],
			'RatioUser': ['각 언어별 장평 비율. (사용자) 50% - 200%', 'unsigned char'],
			'SpacingHangul': ['각 언어별 자간. (한글) -50% - 50%', 'char'],
			'SpacingLatin': ['각 언어별 자간. (영문) -50% - 50%', 'char'],
			'SpacingHanja': ['각 언어별 자간. (한자) -50% - 50%', 'char'],
			'SpacingJapanese': ['각 언어별 자간. (일본어) -50% - 50%', 'char'],
			'SpacingOther': ['각 언어별 자간. (기타) -50% - 50%', 'char'],
			'SpacingSymbol': ['각 언어별 자간. (심벌) -50% - 50%', 'char'],
			'SpacingUser': ['각 언어별 자간. (사용자) -50% - 50%', 'char'],
			'OffsetHangul': ['각 언어별 오프셋. (한글) -100% - 100%', 'char'],
			'OffsetLatin': ['각 언어별 오프셋. (영문) -100% - 100%', 'char'],
			'OffsetHanja': ['각 언어별 오프셋. (한자) -100% - 100%', 'char'],
			'OffsetJapanese': ['각 언어별 오프셋. (일본어) -100% - 100%', 'char'],
			'OffsetOther': ['각 언어별 오프셋. (기타) -100% - 100%', 'char'],
			'OffsetSymbol': ['각 언어별 오프셋. (심벌) -100% - 100%', 'char'],
			'OffsetUser': ['각 언어별 오프셋. (사용자) -100% - 100%', 'char'],
			'Bold': ['Bold', 'unsigned char'],
			'Italic': ['Italic', 'unsigned char'],
			'SmallCaps': ['Small Caps', 'unsigned char'],
			'Emboss': ['Emboss', 'unsigned char'],
			'Engrave': ['Engrave', 'unsigned char'],
			'SuperScript': ['Superscript', 'unsigned char'],
			'SubScript': ['Subscript', 'unsigned char'],
			'UnderlineType': ['밑줄 종류', 'unsigned char'],
			'OutlineType': ['외곽선 종류', 'unsigned char'],
			'ShadowType': ['그림자 종류', 'unsigned char'],
			'TextColor': ['글자색. (COLORREF) RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
			'ShadeColor': ['음영색. (COLORREF) RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
			'UnderlineShape': ['밑줄 모양', 'unsigned char'],
			'UnderlineColor': ['밑줄 색 (COLORREF)', 'unsigned long'],
			'ShadowOffsetX': ['그림자 간격 (X 방향) -100% - 100%', 'char'],
			'ShadowOffsetY': ['그림자 간격 (Y 방향) -100% - 100%', 'char'],
			'ShadowColor': ['그림자 색 (COLORREF) RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
			'StrikeOutType': ['취소선 종류', 'unsigned char'],
			'DiacSymMark': ['강조점 종류', 'unsigned char'],
			'UseFontSpace': ['글꼴에 어울리는 빈칸', 'unsigned char'],
			'UseKerning': ['커닝', 'unsigned char'],
			'BorderFill': ['테두리/배경 (글2007에 새로 추가)', 'set'],
			'Chars': ['겹쳐질 글자들', 'string'],
			'Text': ['삽입될 스트링', 'string'],
			'Count': ['단 개수. 1-255까지.', 'unsigned char'],
			'SameSize': ['단의 너비를 같도록 할지 여부', 'unsigned char'],
			'SameGap': ['단 사이 간격( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT) SAME_SIZE가 1일 때만 사용된다.',
						'long'],
			'WidthGap': [
				'각 단의 너비와 간격( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), col*2:단의 폭, col*2 + 1:단 사이 간격., 영역 전체의 폭을 Column ratio base (=32768)로 보았을 때의 비율로 환산한다., SameSize가 0일 때만 사용된다., 배열의 아이템의 개수는 Count*2-1과 같아 한다.',
				'array'],
			'Layout': ['단 방향 지정', 'unsigned char'],
			'LineType': ['선 종류.', 'unsigned char'],
			'LineWidth': ['선 굵기.', 'unsigned char'],
			'LineColor': ['선 색깔. (COLORREF), RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
			'ApplyClass': ['적용범위의 분류. 아래 값의 조합이다. 0x0001:선택된 다단, 0x0002:선택된 문자열', 'unsigned char'],
			'Number': ['변경 대상에 숫자를 추가할지 여부', 'unsigned int'],
			'Alpha': ['변경 대상에 영문자를 추가할지 여부', 'unsigned int'],
			'Symbol': ['변경 대상에 기호를 추가할지 여부', 'unsigned int'],
			'Gata': ['변경 대상에 가타가나를 추가할지 여부', 'unsigned int'],
			'HGJamo': ['변경 대상에 한글자모를 추가할지 여부', 'unsigned int'],
			'Hanja': ['한자를 한글로 변경할지 여부', 'unsigned int'],
			'Hira': ['히라가나를 한글로 변경할지 여부', 'unsigned int'],
			'Gu': ['구결을 한글로 변경할지 여부', 'unsigned int'],
			'DeleteCtrlType': ['지울 개체 목록', 'array'],
			'DocFilters': ['문자로 분리된 필터 리스트 스트링(MFC 와 같은 방법)을 가져옴', 'string'],
			'Format': ['필터 리스트를 string array형태로 가져옴 (Export시에만)', 'array'],
			'ListID': ['현재 위치한 리스트', 'unsigned int'],
			'ParaID': ['현재 위치한 문단', 'unsigned int'],
			'Pos': ['현재 위치한 글자', 'unsigned int'],
			'CurPara': ['현재 위치한 문단', 'unsigned int'],
			'CurPos': ['현재 위치한 오프셋', 'unsigned int'],
			'CurParaLen': ['현재 위치한 문단의 길이', 'unsigned int'],
			'CurCtrl': ['현재 리스트의 종류', 'unsigned int'],
			'CurParaCount': ['현재 리스트의 문단 수', 'unsigned int'],
			'RootPara': ['루트 리스트의 현재 문단', 'unsigned int'],
			'RootPos': ['루트 리스트의 현재 오프셋', 'unsigned int'],
			'RootParaCout': ['루트 리스트의 문단 수', 'unsigned int'],
			'DetailInfo': ['자세한 정보를 구할지 여부, Detail~ 로 시작하는 아이템의 정보를 얻기 위해서는 이 값을 1로 넣어준 후에 액션을 실행해준다.', 'char'],
			'DetailCharCount': ['문서에 포함된 글자 수', 'unsigned int'],
			'DetailWordCount': ['문서에 포함된 어절 수', 'unsigned int'],
			'DetailLineCount': ['문서에 포함된 줄 수', 'unsigned int'],
			'DetailPageCount': ['문서에 포함된 쪽 수', 'unsigned int'],
			'DetailCurPage': ['현재 쪽 번호', 'unsigned int'],
			'DetailCurPrtPage': ['현재 쪽 번호 (인쇄 번호)', 'unsigned int'],
			'SectionInfo': ['구역의 속성까지 구할지 여부, SecDef 아이템은 이 값을 1로 넣어준 후 액션을 실행한 후에 얻을 수 있다.', 'unsigned int'],
			'SecDef': ['구역의 속성 (글2007에 새로 추가)', 'set'],
			'Interval': ['확장타원(호)에서 호의 시작점과 끝점을 나타내게 한다.', 'array'],
			'Point': ['좌표 Array (X1,Y1), (X2,Y2), ..., (Xn,Yn)', 'array'],
			'Line': ['선 속성 Array(곡선에서만 쓰임)', 'array'],
			'Index': ['고칠 점의 인덱스', 'unsigned int'],
			'PointX': ['점의 X 좌표', 'int'],
			'PointY': ['점의 Y 좌표', 'int'],
			'GradationType': ['배경 유형이 그러데이션일 때 그러데이션 형태, 1:줄무늬형, 2:원형, 3:원뿔형, 4:사각형', 'int'],
			'GradationAngle': ['그러데이션의 기울임(시작각)', 'int'],
			'GradationCenterX': ['그러데이션의 가로중심(중심 X 좌표)', 'int'],
			'GradationCenterY': ['그러데이션의 가로중심(중심 Y 좌표)', 'int'],
			'GradationStep': ['그러데이션 번짐 정도 (0..100)', 'int'],
			'GradationColorNum': ['그러데이션의 색 수', 'int'],
			'GradationColor': ['그러데이션의 색깔(시작색, 중간색1,..중간색 n-2, 끝색) 2<= n <=10', 'array'],
			'GradationIndexPos': ['그러데이션 다음 색깔과의 거리(얼마나 번지고 나서 다음색깔로 가 는가)', 'array'],
			'GradationStepCenter': ['그러데이션 번짐 정도의 중심 (0..100)', 'unsigned char'],
			'GradationAlpha': ['그러데이션 투명도 (글2007에새로추가)', 'unsigned char'],
			'WinBrushFaceColor': ['면 색 (RGB 0x00BBGGRR) (글2007에새로추가)', 'unsigned int'],
			'WinBrushHatchColor': ['무늬 색 (RGB 0x00BBGGRR) (글2007에 새로 추가)', 'unsigned int'],
			'WinBrushAlpha': ['면/무늬 색 투명도 (글2007에 새로 추가)', 'unsigned int'],
			'FileName': ['ShapeObject의 배경을 그림으로 선택했을 경우. 또는 그림개체일 경우의 그림파일 경로', 'string'],
			'Embedded': ['그림이 문서에 직접 삽입(TRUE) / 파일로 연결(FALSE)', 'unsigned char'],
			'PicEffect': ['그림 효과', 'unsigned char'],
			'Brightness': ['명도 (-100 ~ 100)', 'char'],
			'Contrast': ['밝기 (-100 ~ 100)', 'char'],
			'Reverse': ['반전 유무', 'unsigned char'],
			'DrawFillImageType': ['ShapeObject의 배경일 경우에만 의미있는 아이템배경을 채우는 방식을 결정],그림개체에는해당사항없음', 'int'],
			'SkipLeft': ['그림 개체일 경우에만 의미 있는 아이템, 왼쪽 자르기', 'unsigned int'],
			'SkipRight': ['그림 개체일 경우에만 의미 있는 아이템, 오른쪽 자르기', 'unsigned int'],
			'SkipTop': ['그림 개체일 경우에만 의미 있는 아이템, 위 자르기', 'unsigned int'],
			'SkipBottom': ['그림 개체일 경우에만 의미 있는 아이템, 아래 자르기', 'unsigned int'],
			'OriginalSizeX': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 원본 크기 X size', 'unsigned int'],
			'OriginalSizeY': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 원본 크기 Y size', 'unsigned int'],
			'InsideMarginLeft': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (왼쪽)', 'long'],
			'InsideMarginRight': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (오른 쪽)', 'long'],
			'InsideMarginTop': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (위)', 'long'],
			'InsideMarginBottom': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (아래)', 'long'],
			'WindowsBrush': ['현재 선택된 brush의 type이 면/무늬 브러시인가를 나타냄', 'unsigned char'],
			'GradationBrush': ['현재 선택된 brush의 type이 그러데이션 브러시인가를 나타냄', 'unsigned char'],
			'ImageBrush': ['현재 선택된 brush의 type이 그림 브러시인가를 나타냄', 'unsigned char'],
			'ImageCreateOnDrag': ['그림 개체 생성 시 마우스로 끌어 생성할지 여부, (글2007에 새로 추가)', 'unsigned char'],
			'ImageAlpha': ['그림 개체/배경 투명도 (글2007에 새로 추가)', 'unsigned char'],
			'InsideMarginBotto m': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (아래)', 'long'],
			'Xoffset': ['자를 x축 오프셋', 'int'],
			'Yoffset': ['자를 y축 오프셋', 'int'],
			'HandleIndex': ['Reserved', 'unsigned int'],
			'CreateNumPt': ['생성할 점의 수', 'unsigned int'],
			'CreatePt': ['생성할 점의 위치정보, POINT(x,y)로 계산되므로 CreateNumPt*2의 개수로 구성 됨.', 'array'],
			'CurveSegmentInfo': ['곡선 세그먼트 정보', 'array'],
			'Color': ['선 색깔 RGB-32비트 (0x00BBGGRR)', 'PMT_UINT32'],
			'Style': ['선의 style', 'int'],
			'EndCap': ['선의 endcap', 'int'],
			'HeadStyle': ['선의 시작 화살표 모양', 'int'],
			'TailStyle': ['선의 끝 화살표 모양', 'int'],
			'HeadSize': ['선의 시작 화살표 크기', 'int'],
			'TailSize': ['선의 끝 화살표 크기', 'int'],
			'HeadFill': ['선의 시작 화살표 채움 유무', 'blooen'],
			'TailFill': ['선의 끝 화살표 채움 유무', 'blooen'],
			'OutLineStyle': ['선두께 외부/내부/일반 적용', 'unsigned int'],
			'Mode': ['Reserved', 'unsigned int'],
			'CenterX': ['회전 중심의 X 좌표', 'int'],
			'CenterY': ['회전 중심의 Y 좌표', 'int'],
			'ObjectCenterX': ['그리기 개체의 중심 X 좌표', 'int'],
			'ObjectCenterY': ['그리기 개체의 중심 Y 좌표', 'int'],
			'Angle': ['회전 각', 'int'],
			'RotateImage': ['그림 회전 여부 (글2007에 새로 추가)', 'unsigned char'],
			'RotateCenterX': ['회전 중심 X 좌표', 'long'],
			'RotateCenterY': ['회전 중심 Y 좌표', 'long'],
			'RotateAngel': ['회전각', 'int'],
			'HorzFlip': ['수평 flip (좌우 뒤집기)', 'unsigned int'],
			'VertFlip': ['수직 flip (상하 뒤집기)', 'unsigned int'],
			'ShadowAlpha': ['그림자 투명도', 'unsigned char'],
			'XFactor': ['X축 기울이기 각도', 'int'],
			'YFactor': ['Y축 기울이기 각도', 'int'],
			'String': ['글맵시에 넣을 문자열 내용', 'string'],
			'FontName': ['글꼴', 'string'],
			'FontStyle': ['속성. 값은 항상 0(Regular)이다.', 'string'],
			'FontType': ['폰트 종류', 'unsigned char'],
			'LineSpacing': ['줄 간격 (50 ~ 500)', 'long'],
			'CharSpacing': ['글자간격 (50 ~ 500)', 'long'],
			'AlignType': ['정렬 방식', 'unsigned char'],
			'Shape': ['형태 (0 ~ 54)', 'unsigned char'],
			'NumberOfLines': ['글맵시에 넣을 문자열 내용의 줄 수', 'unsigned char'],
			'FaceName': ['글꼴', 'string'],
			'LineStyle': ['선 스타일', 'int'],
			'LineWeight': ['선 굵기', 'unsigned int'],
			'FaceColor': ['글꼴 색, RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
			'Spacing': ['본문과의 간격', 'int'],
			'ResultText': ['본말', 'string'],
			'SubText': ['덧말', 'string'],
			'PosType': ['덧말 위치', 'unsigned char'],
			'FsizeRatio': ['덧말 크기 Percent. 0=이면 기본 50%.', 'unsigned char'],
			'StyleNo': ['스타일번호 (옵션이 켜있을 때)', 'unsigned char'],
			'Align': ['덧말의 좌우 Align', 'unsigned char'],
			'Delete': ['덧말 지움 (글2007에 새로 추가)', 'unsigned char'],
			'Modify': ['덧말 편집 모드 여부 (글2007에 새로 추가)', 'unsigned char'],
			'DoAnyCursorEdit': ['마우스로 두 번 누르기 한곳에 입력가능', 'unsigned char'],
			'DoOutLineStyle': ['개요 번호 삽입 문단에 개요 스타일 자동 적용', 'unsigned char'],
			'InsertLock': ['삽입 잠금', 'unsigned char'],
			'TabMoveCell': ['표 안에서 <Tab>으로 셀 이동', 'unsigned char'],
			'FaxDriver': ['팩스 드라이버', 'string'],
			'PDFDriver': ['PDF 드라이버', 'string'],
			'EnableAutoSpell': ['맞춤법 도우미 작동', 'unsigned char'],
			'BaseUnit': ['수식이 삽입되는 앞의 글자와 같은 높이 (기본 값은 POINT 10 )', 'long'],
			'LineMode': ['줄 단위를 사용할지의 여부 (글2007에 새로 추가)', 'long'],
			'Version': ['수식 스크립트 버전 정보 (글2007에 새로 추가)', 'string'],
			'Flag': ['', 'unsigned char'],
			'FieldDirty': ['필드가 초기화 상태인지 수정되어 있는 상태인지 여부, (글2007에 새로 추가)', 'unsigned char'],
			'CtrlData': ['필드 이름 저장을 위한 영역', 'set'],
			'SrcFileList': ['Source 파일 리스트', 'array'],
			'DestFileList': ['Destination 파일 리스트', 'array'],
			'VersionStr': ['파일의 버전 문자열, ex)5.0.0.3', 'string'],
			'VersionNum': ['파일의 버전], ex) 0x05000003', 'unsigned long'],
			'Encrypted': ['암호 여부', 'long'],
			'OpenFileName': [
				'파일 이름 (OpenFileName과 SaveFileName은 같은 아이템을 공 유한다. 즉 OpenFileName과 SaveFileName은 이름만 다를 뿐 동 일한 아이템이다)',
				'string'],
			'SaveFileName': [''],
			'OpenFormat': ['파일 형식', 'string'],
			'SaveFormat': [''],
			'OpenReadOnly': ['읽기 전용', 'unsigned char'],
			'OpenFlag': ['', 'unsigned char'],
			'SaveOverWrite': ['덮어 쓰기', 'unsigned char'],
			'ModifiedFlag': ['Modify 플래그', 'unsigned char'],
			'Argument': ['Argument', 'string'],
			'SaveCMFDoc30': ['97 호환 저장 (글2007에 새로 추가)', 'unsigned char'],
			'SaveHwp97': ['97 문서로 저장 (글2007에 새로 추가)', 'unsigned char'],
			'SaveDistribute': ['배포용 문서로 저장 (글2007에 새로 추가)', 'unsigned char'],
			'SaveDRMDoc': ['보안 문서로 저장 (글2007에 새로 추가)', 'unsigned char'],
			'To': ['받는 사람', 'string'],
			'Subject': ['제목', 'string'],
			'Filepath': ['사용자가 직접 입력한 파일 (이 아이템은 Type 아이템이 1(첨부파 일)로 설정되어 있을 때만 유효하다) (글2007에 새로 추가)', 'string'],
			'Password': ['배포용 문서 암호(7자리 이상 가능)', 'string'],
			'NoPrint': ['프린트 가능한 배포용 문서를 만들지의 여부', 'unsigned char'],
			'NoCopy': ['문서 내용 복사가 가능한 배포용 문서를 만들지의 여부', 'unsigned char'],
			'FindString': ['찾을 문자열', 'string'],
			'ReplaceString': ['바꿀 문자열', 'string'],
			'Direction': ['찾을 방향', 'unsigned char'],
			'MatchCase': ['대소문자 구별 ', 'unsigned char'],
			'AllWordForms': ['문자열 결합 ', 'unsigned char'],
			'SeveralWords': ['여러 단어 찾기 ', 'unsigned char'],
			'UseWildCards': ['아무개 문자 ', 'unsigned char'],
			'WholeWordOnly': ['온전한 낱말 ', 'unsigned char'],
			'AutoSpell': ['토씨 자동 교정 ', 'unsigned char'],
			'ReplaceMode': ['찾아 바꾸기 모드 ', 'unsigned char'],
			'IgnoreFindString': ['찾을 문자열 무시 ', 'unsigned char'],
			'IgnoreReplaceStrin g': ['바꿀 문자열 무시 ', 'unsigned char'],
			'FindCharShape': ['찾을 글자 모양', 'set'],
			'FindParaShape': ['찾을 문단 모양', 'set'],
			'ReplaceCharShape': ['바꿀 글자 모양', 'set'],
			'ReplaceParaShape': ['바꿀 문단 모양', 'set'],
			'FindStyle': ['찾을 스타일', 'string'],
			'ReplaceStyle': ['바꿀 스타일', 'string'],
			'IgnoreMessage': ['메시지박스 표시 안함. ', 'unsigned char'],
			'HanjaFromHangul': ['한글임으로 한자 차기', 'unsigned char'],
			'FindJaso': ['자소로 찾기 ', 'unsigned char'],
			'FindRegExp': ['정규식(조건식)으로 찾기 (on/off) (ver:0x06050107)', 'unsigned char'],
			'FindType': ['다시 찾기를 할 때 마지막으로 실행한 (찾기 TRUE)를 할 것인가, (찾아가기 FALSE)할 것인가의 여부 (ver:0x06050110)', 'unsigned char'],
			'Base': ['경로의 Base', 'string'],
			'Qulaity': ['재생 품질', 'string'],
			'Scale': ['스케일', 'string'],
			'WMode': ['윈도우 모드', 'string'],
			'AutoPlay': ['자동 재생 여부', 'unsigned char'],
			'LoopPlay': ['반복 재생 여부', 'unsigned char'],
			'ShowMenu': ['메뉴 보이기', 'unsigned char'],
			'BgColor': ['배경색 (COLORREF)', 'unsigned long'],
			'NumberFormat': ['번호모양', 'unsigned char'],
			'UserChar': ['사용자 기호 (WCHAR)', 'unsigned short'],
			'PrefixChar': ['앞 장식 문자 (WCHAR)', 'unsigned short'],
			'Suffix': ['뒤 장식 문자 (WCHAR)', 'unsigned short'],
			'PlaceAt': ['위치, - 각주용 옵션 (한 페이지 내에서 각주를 다단에 어떻게 위치시킬 지)', 'unsigned char'],
			'Restart': ['번호 매기기', 'unsigned char'],
			'LineLength': ['구분선 길이 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'SpaceAboveLine': ['구분선 위 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'SpaceBelowLine': ['구분선 아래 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'SpaceBetweenNotes': ['주석 사이 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'BeneathText': ['텍스트에 이어 바로 출력할지 여부 ', 'unsigned char'],
			'Server': ['Ftp 서버 내임', 'string'],
			'UserName': ['사용자 이름', 'string'],
			'Directory': ['디렉터리', 'string'],
			'SiteName': ['사이트 이름', 'array'],
			'SaveType': ['저장할 포맷', 'unsigned int'],
			'SetSelectionIndex': ['현재 선택되어 있는 라디오 값 (글2007에 새로 추가)', 'unsigned char'],
			'DialogResult': ['대화상자의 반환값 (글2007에 새로 추가)', 'unsigned int'],
			'Method': ['격자 방식', 'unsigned char'],
			'HorzAlign': ['격자 기준 가로 offset (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'VertAlign': ['격자 기준 세로 offset (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'HorzSpan': ['가로 간격 (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'unsigned int'],
			'VertSpan': ['세로 간격 (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'unsigned int'],
			'HorzRange': ['가로 자석 범위 (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'PIT_U'],
			'VertRange': ['세로 자석 범위 (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'PIT_U'],
			'Show': ['격자 보이기 ', 'unsigned char'],
			'ZOrder': ['격자 위치(글 위/글 아래) (ZOrder)', 'unsigned char'],
			'ViewLine': ['선격자 보이기 종류 (글2007에 새로 추가)', 'unsigned char'],
			'DialogOption': ['머리말/꼬리말 대화상자를 실행할 때 편집버튼을 보일 것인지 말 것인지 지정한다., 1:편집버튼 보이기, 그 외:편집버튼 안보이기', 'unsigned int'],
			'CtrlType': ['머리말/꼬리말 여부', 'unsigned int'],
			'HeaderFooterCtrlType': ['머리말/꼬리말 종류', 'unsigned int'],
			'HeaderFooterStyle': ['머리말/꼬리말 마당 스타일', 'unsigned int'],
			'NoLInk': ['연결 안함 여부', 'int'],
			'ShapeObject': ['그림 및 그리기객체가 Selection되어 있는지 여부', 'int'],
			'DirectInsert': ['현재 캐럿 위치에 무조건 하이퍼링크 삽입 여부 (블록지정 상태면 블록해제 후 삽입) (글2007에 새로 추가)', 'int'],
			'Source': ['Source에 대한 Object Path', 'string'],
			'Target': ['이동할 Target에 대한 Object Path', 'string'],
			'InputText': ['삽입될 스트링/끼워 넣을 파일', 'string'],
			'InputType': ['입력기 상용구/한글 상용구', 'unsigned char'],
			'First': ['첫 번째 키', 'string'],
			'Second': ['두 번째 키', 'string'],
			'DateStyleType': ['문자열로 넣기/코드로 넣기', 'unsigned char'],
			'DateStyleDataForm': ['필드 컨트롤의 안내문/지시문', 'string'],
			'ShowSingle': ['문서마당 정보 대화상자에서 페이지(탭) 보이기 옵션 :, -1:모든 페이지 보이기', 'int'],
			'TemplateDirection': ['필드 컨트롤의 안내문/지시문', 'string'],
			'TemplateHelp': ['필드 컨트롤의 도움말', 'string'],
			'TemplateName': ['필드 이름 (name)', 'string'],
			'TemplateType': ['필드의 종류.TemplateDirection/Help/Name의 값이 실제로 적용되는 위치', 'unsigned char'],
			'FileFormat': ['삽입할 파일의 확장자', 'string'],
			'FileArg': ['삽입할 파일의 Argument', 'string'],
			'KeepSection': ['끼워 넣을 문서를 구역으로 나누어 쪽 모양을 유지할지 여부 on/off (ver:0x0605010E)', 'unsigned char'],
			'KeepCharshape': ['끼워 넣을 문서의 글자 모양을 유지할지 여부 on/off (글2007에 새로 추가)', 'unsigned char'],
			'KeepParashape': ['끼워 넣을 문서의 문단 모양을 유지할지 여부 on / onff (글2007에 새로 추가)', 'unsigned char'],
			'KeepStyle': ['끼워 넣을 문서의 스타일을 유지할지 여부 on / onff (글2010에 새로 추가)', 'unsigned char'],
			'OpenUrlWhere': ['웹브라우저로 불러오거나 한글 문서로 불러오기', 'unsigned int'],
			'OpenUrlString': ['불러올 문서가 존재하는 URL', 'string'],
			'RepeatCount': ['실행 반복 횟수', 'int'],
			'PageInherit': ['TRUE:쪽 번호 잇기, FALSE:쪽 번호 잇지 않기.', 'unsigned char'],
			'FootnoteInherit': ['TRUE:각주 번호 잇기, FALSE:각주 번호 잇지 않기.', 'unsigned char'],
			'List': ['현재 위치한 리스트', 'unsigned int'],
			'Para': ['현재 위치한 문단', 'unsigned int'],
			'TextDirection': ['글자 방향. (세부 스펙은 미정)', 'unsigned char'],
			'LineWrap': ['경계에서 줄 나눔 방식', 'unsigned char'],
			'MarginLeft': ['각 방향 여백', 'long'],
			'MarginRight': ['각 방향 여백', 'long'],
			'MarginTop': ['각 방향 여백', 'long'],
			'MarginBottom': ['각 방향 여백', 'long'],
			'Input': ['자료 종류', 'unsigned char'],
			'HwpPath': ['Hwp 문서 경로.', 'string'],
			'HwpId': ['Hwp 문서 ID', 'unsigned int'],
			'DbfPath': ['dbf file path', 'string'],
			'DbfCode': ['dbf file codepage', 'unsigned char'],
			'Output': ['출력 방향', 'unsigned char'],
			'Continue': ['쪽번호 잇기', 'unsigned char'],
			'PrintSet': ['인쇄 선택 사항', 'set'],
			'Field': ['메일 주소 필드', 'string'],
			'FieldUpdate': ['필드 단위 업데이트 (글2007에 새로 추가)', 'unsigned char'],
			'NxlPath': ['넥셀 파일 경로 (글2007에 새로 추가)', 'string'],
			'Make': ['생성할 차례의 종류, 다음의 값들의 조합이다', 'unsigned int'],
			'Level': ['개요 수준', 'int'],
			'AutoTabRight': ['문단 오른쪽 끝 자동 탭 여부', 'char'],
			'Leader': ['오른쪽 끝 탭 채울 모양(선 종류)', 'unsigned int'],
			'OutlineNumber': ['개요 문단 모으기', 'char'],
			'Styles': ['모을 스타일 목록', 'array'],
			'StyleName': ['모을 스타일 이름들', 'string'],
			'OutFileName': ['만들 파일 이름. 이면 현재 문서에 생성', 'string'],
			'Position': ['만들 위치. 반드시 0이어 한다. (글 컨트롤은 탭이 없으므로) (글2007에 새로 추가)', 'string'],
			'Duplicate': ['기존 바탕쪽과 겹침 (On/Off) (글2007에 새로 추가)', 'unsigned char'],
			'Front': ['바탕쪽과 앞으로 보내기 (On/Off) (글2007에 새로 추가)', 'unsigned char'],
			'FillColor': ['채우기 색깔 (COLORREF)', 'unsigned long'],
			'ActiveFillColor': ['활성화된 채우기 색깔 (COLORREF)', 'unsigned long'],
			'MemoType': ['메모 종류 - 현재 사용안 함', 'unsigned long'],
			'XRelTo': ['가로 상대적 기준', 'unsigned long'],
			'YRelTo': ['세로 상대적 기준', 'unsigned long'],
			'Page': ['페이지 번호 ( 0 based)', 'unsigned long'],
			'X': ['가로 클릭한 위치 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'Y': ['세로 클릭한 위치 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'Caption': ['자막 파일의 경로', 'string'],
			'AutoRewind': ['되감기 여부', 'unsigned char'],
			'ShowCtrlPanel': ['컨트롤 패널 보이기', 'unsigned char'],
			'ShowPosCtrl': ['위치 컨트롤 보이기', 'unsigned char'],
			'EnablePos': ['위치 컨트롤 조절 여부', 'unsigned char'],
			'ShowTrackBar': ['음량 조절막대(Track Bar) 보이기', 'unsigned char'],
			'EnableTrack': ['음량 조절 여부', 'unsigned char'],
			'ShowChaption': ['자막 보이기', 'unsigned char'],
			'ShowAudio': ['오디오 설정 보이기', 'unsigned char'],
			'ShowStatus': ['상태바 보기 (진행시간 등을 표시)', 'unsigned char'],
			'HasCharShapeLevel0': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
			'HasCharShapeLevel1': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
			'HasCharShapeLevel2': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
			'HasCharShapeLevel3': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
			'HasCharShapeLevel4': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
			'HasCharShapeLevel5': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
			'HasCharShapeLevel6': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
			'CharShapeLevel0': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
			'CharShapeLevel1': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
			'CharShapeLevel2': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
			'CharShapeLevel3': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
			'CharShapeLevel4': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
			'CharShapeLevel5': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
			'CharShapeLevel6': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
			'WidthAdjustLevel0': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
								  'int'],
			'WidthAdjustLevel1': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
								  'int'],
			'WidthAdjustLevel2': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
								  'int'],
			'WidthAdjustLevel3': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
								  'int'],
			'WidthAdjustLevel4': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
								  'int'],
			'WidthAdjustLevel5': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
								  'int'],
			'WidthAdjustLevel6': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
								  'int'],
			'TextOffsetLevel0': [
				'7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'TextOffsetLevel1': [
				'7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'TextOffsetLevel2': [
				'7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'TextOffsetLevel3': [
				'7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'TextOffsetLevel4': [
				'7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'TextOffsetLevel5': [
				'7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'TextOffsetLevel6': [
				'7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
			'AlignmentLevel0': ['7개 수준별 번호 정렬', 'unsigned char'],
			'AlignmentLevel1': ['7개 수준별 번호 정렬', 'unsigned char'],
			'AlignmentLevel2': ['7개 수준별 번호 정렬', 'unsigned char'],
			'AlignmentLevel3': ['7개 수준별 번호 정렬', 'unsigned char'],
			'AlignmentLevel4': ['7개 수준별 번호 정렬', 'unsigned char'],
			'AlignmentLevel5': ['7개 수준별 번호 정렬', 'unsigned char'],
			'AlignmentLevel6': ['7개 수준별 번호 정렬', 'unsigned char'],
			'UseInstWidthLevel0': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
			'UseInstWidthLevel1': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
			'UseInstWidthLevel2': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
			'UseInstWidthLevel3': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
			'UseInstWidthLevel4': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
			'UseInstWidthLevel5': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
			'UseInstWidthLevel6': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
			'AutoIndentLevel0': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
			'AutoIndentLevel1': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
			'AutoIndentLevel2': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
			'AutoIndentLevel3': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
			'AutoIndentLevel4': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
			'AutoIndentLevel5': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
			'AutoIndentLevel6': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
			'TextOffsetTypeLevel0': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
			'TextOffsetTypeLevel1': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
			'TextOffsetTypeLevel2': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
			'TextOffsetTypeLevel3': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
			'TextOffsetTypeLevel4': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
			'TextOffsetTypeLevel5': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
			'TextOffsetTypeLevel6': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
			'StrFormatLevel0': ['7개 수준별 포맷 문자열', 'string'],
			'StrFormatLevel1': ['7개 수준별 포맷 문자열', 'string'],
			'StrFormatLevel2': ['7개 수준별 포맷 문자열', 'string'],
			'StrFormatLevel3': ['7개 수준별 포맷 문자열', 'string'],
			'StrFormatLevel4': ['7개 수준별 포맷 문자열', 'string'],
			'StrFormatLevel5': ['7개 수준별 포맷 문자열', 'string'],
			'StrFormatLevel6': ['7개 수준별 포맷 문자열', 'string'],
			'NumFormatLevel0': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
			'NumFormatLevel1': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
			'NumFormatLevel2': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
			'NumFormatLevel3': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
			'NumFormatLevel4': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
			'NumFormatLevel5': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
			'NumFormatLevel6': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
			'StartNumber': ['시작 번호 (0:앞 구역에 이어, n:지정한 번호로 시작)* 0은 구역의 개요 정의에만 사용된다.', 'unsigned short'],
			'NewList': [
				'새로운 번호 목록을 시작할지 여부, * 문단 모양(ParaShap)의 서브셋으로 포함될 때만 의미 있다., * get일 때는 이 아이템은 아예 생성되지 않으며, set일 때는 TRUE가 아니면 NumberingShape 서브셋 전체가 지정되지 않은 것 처럼 무시된다.',
				'unsigned char'],
			'Clsid': ['클래스 ID 새로 개체 생성 일 때 사용', 'string'],
			'Path': ['파일 경로(‘파일로 링크된 개체 생성’, ‘파일로부터 개체 생성’일 때 사용)', 'string'],
			'Aspect': ['생성된 OLE 개체를 아이콘으로 표시할지 여부', 'int'],
			'IconMetafile': ['Aspect가 아이콘일 때 적용할 아이콘 데이터', 'any'],
			'IconMM': ['Aspect가 아이콘일 때 아이콘 매핑모드', 'int'],
			'IconXext': ['Aspect가 아이콘일 때 X축 매핑단위', 'int'],
			'IconYext': ['Aspect가 아이콘일 때 Y축 매핑단위', 'int'],
			'InnerOCX': ['글 내부에서 사용되는 OCX인지 여부 (예: 글의 Chart OLE)', 'int'],
			'SoProperties': ['초기 shape object 속성', 'set'],
			'FlashProperties': ['플래시 파일 삽입 시 필요한 옵션 셋 (글2007에 새로 추가)', 'set'],
			'MovieProperties': ['동영상 파일 삽입 시 필요한 옵션 셋 (글2007에 새로 추가)', 'set'],
			'TextBorder': ['TRUE:본문 기준, FALSE:종이 기준', 'unsigned char'],
			'HeaderInside': ['머리말 포함 ', 'unsigned char'],
			'FooterInside': ['꼬리말 포함 ', 'unsigned char'],
			'FillArea': ['채울 영역', 'unsigned char'],
			'OffsetLeft': ['4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT),왼쪽', 'int'],
			'OffsetRight': ['4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT),오른쪽', 'int'],
			'OffsetTop': ['4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT),위', 'int'],
			'OffsetBottom': ['4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 아래', 'int'],
			'PaperWidth': ['용지 가로 크기 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'PaperHeight': ['용지 세로 크기 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'Landscape': ['용지 방향', 'long'],
			'LeftMargin': ['왼쪽 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'RightMargin': ['오른쪽 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'TopMargin': ['위 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'BottomMargin': ['아래 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'HeaderLen': ['머리말 길이 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'FooterLen': ['꼬리말 길이 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'GutterLen': ['제본 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
			'GutterType': ['편집 방법', 'unsigned char'],
			'Fields': ['감출 대상 비트 필드. 0x01:머리말', 'unsigned int'],
			'PageStartsOn': ['페이지 번호 적용 옵션', 'unsigned char'],
			'SuffixChar': ['뒤 장식 문자(WCHAR). 글2007에선 더 이상 사용하지 않는다.', 'unsigned short'],
			'SideChar': ['양쪽 옆 장식 문자(WCHAR). L-만 사용할 수 있다.', 'unsigned short'],
			'DrawPos': ['번호 위치', 'unsigned char'],
			'Indentation': ['들여쓰기/내어 쓰기 (URC)', 'long'],
			'PrevSpacing': ['문단 간격 위 (URC)', 'long'],
			'NextSpacing': ['문단 간격 아래 (URC)', 'long'],
			'LineSpacingType': ['줄 간격 종류 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
								'unsigned char'],
			'BreakLatinWord': ['줄 나눔 단위 (라틴 문자)', 'unsigned char'],
			'BreakNonLatinWord': ['단위 (비 라틴 문자)', 'unsigned char'],
			'SnapToGrid': ['편집 용지의 줄 격자 사용 ', 'unsigned char'],
			'Condense': ['공백 최소값 (0 - 75%)', 'unsigned char'],
			'WidowOrphan': ['외톨이줄 보호 ', 'unsigned char'],
			'KeepWithNext': ['다음 문단과 함께 ', 'unsigned char'],
			'KeepLinesTogether': ['문단 보호 ', 'unsigned char'],
			'PagebreakBefore': ['문단 앞에서 항상 쪽 나눔 ', 'unsigned char'],
			'TextAlignment': ['세로 정렬', 'unsigned char'],
			'FontLineHeight': ['글꼴에 어울리는 줄 높이 ', 'unsigned char'],
			'HeadingType': ['문단 머리 모양', 'unsigned char'],
			'BorderConnect': ['문단 테두리/배경 - 테두리 연결 ', 'unsigned char'],
			'BorderText': ['문단 테두리/배경 - 여백 무시', 'unsigned char'],
			'BorderOffsetLeft': ['문단 테두리/배경 - 4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 왼쪽',
								 'int'],
			'BorderOffsetRight': [
				'문단 테두리/배경 - 4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 오른쪽', 'int'],
			'BorderOffsetTop': ['문단 테두리/배경 - 4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 위',
								'int'],
			'BorderOffsetBotto m': [
				'문단 테두리/배경 - 4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 아래', 'int'],
			'TailType': ['문단 꼬리 모양 (마지막 꼬리 줄 적용) ', 'unsigned char'],
			'TabDef': ['탭 정의', 'set'],
			'Numbering': ['문단 번호, 문단 머리 모양(HeadingType)이 ‘개요’, ‘번호’ 일 때 사용', 'set'],
			'Bullet': ['불릿 모양, 문단 머리 모양(HeadingType)이 ‘불릿’(글머리표) 일 때 사용', 'set'],
			'FullRange': ['TRUE:유니코드/모든 문자를 사용, FALSE:영문자만 사용', 'unsigned char'],
			'Ask': ['', 'unsigned', {0: '문서 암호를 확인', 1: '문서 암호를 설정'}],
			'ShowSinglePage': ['환경 설정 PropertySheet에 표시할 PropertyPage 번호, (하나만 선택)', 'int'],
			'ApplyLinkAttr': ['하이퍼링크 글자 속성 문서 전체에 적용하기 여부 (on/off) (글2007에 새로 추가)', 'unsigned char'],
			'ApplyForbidden': ['(금칙 처리) 새 문서에 기본 값으로 설정 (on/off) (글2007에 새로 추가)', 'string'],
			'StartForbiddenStr': ['(금칙 처리) 새 문서에 적용할 줄 앞 금칙 문자열, (글2007에 새로 추가)', 'string'],
			'EndForbiddenStr': ['(금칙 처리) 새 문서에 적용할 줄 뒤 금칙 문자열, (글2007에 새로 추가)', 'string'],
			'Effect': ['화면 전환 효과', 'unsigned int'],
			'Sound': ['효과음', 'any'],
			'InvertText': ['검은색 글자를 흰색으로', 'int'],
			'ShowMode': ['자동 전환 모드 (글2007에 새로 추가)', 'int'],
			'ShowPage': ['현재 쪽', 'unsigned int'],
			'ShowTime': ['전환 시간 (초)', 'unsigned int'],
			'Range': ['인쇄 범위', 'unsigned char'],
			'RangeCustom': ['사용자가 직접 입력한 인쇄 범위', 'string'],
			'RangeIncludeLinkedDoc': ['연결된 문서 포함', 'unsigned char'],
			'NumCopy': ['인쇄 매수', 'unsigned short'],
			'Collate': ['한 부씩 찍기', 'unsigned char'],
			'PrintMethod': ['인쇄 방법', 'unsigned char'],
			'PrinterPaperSize': ['공급용지 종류(DEVMODE.dmPaperSize)', 'int'],
			'PrinterPaperWidth': ['공급용지 종류(DEVMODE.dmPaperWidth)', 'int'],
			'PrinterPaperLength': ['공급용지 종류(DEVMODE.dmPaperLength)', 'int'],
			'PrintAutoHeadNote': ['머리말 자동 인쇄', 'unsigned char'],
			'PrintAutoFootNote': ['꼬리말 자동 인쇄', 'unsigned char'],
			'PrintAutoHeadnoteLtext': ['자동 머리말의 왼쪽 String', 'string'],
			'PrintAutoHeadnoteCtext': ['자동 머리말의 가운데 String', 'string'],
			'PrintAutoHeadnoteRtext': ['자동 머리말의 오른쪽 String', 'string'],
			'PrintAutoFootnoteLtext': ['자동 꼬리말의 왼쪽 String', 'string'],
			'PrintAutoFootnoteCtext': ['자동 꼬리말의 가운데 String', 'string'],
			'PrintAutoFootnoteRtext': ['자동 꼬리말의 오른쪽 String', 'string'],
			'PrinterName': ['프린터', 'string'],
			'PrintToFile': ['인쇄 결과를 파일로 저장', 'unsigned char'],
			'ReverseOrder': ['역순 인쇄', 'unsigned char'],
			'Pause': ['끊어 찍기 매수', 'unsigned short'],
			'PrintImage': ['그림 개체', 'unsigned char'],
			'PrintDrawObj': ['그리기 개체', 'unsigned char'],
			'PrintClickHere': ['누름틀', 'unsigned char'],
			'PrintCropMark': ['편집 용지 표시', 'unsigned char'],
			'IdcPrintWallPaper': ['배경 그림', 'unsigned char'],
			'LastBlankPage': ['빈 마지막 쪽', 'unsigned char'],
			'BinderHoleType': ['바인더 구멍', 'unsigned char'],
			'EvenOddPageType': ['홀짝 인쇄', 'unsigned char'],
			'ZoomX': ['가로 확대', 'unsigned short'],
			'ZoomY': ['세로 확대', 'unsigned short'],
			'StartPageNum': ['시작 번호/쪽 번호', 'unsigned int'],
			'StartFootNoteNum': ['시작 번호/각주 번호', 'unsigned int'],
			'Flags': ['문제 해결을 위한 고급 선택 사항', 'unsigned int'],
			'Device': ['인쇄 방향(장치)', 'unsigned char'],
			'PrintFormObj': ['양식 개체 출력여부 (글2007에 새로 추가)', 'unsigned char'],
			'PrintMarkPen': ['형광펜 출력여부 (글2007에 새로 추가)', 'unsigned char'],
			'PrintMemo': ['메모 출력여부 (글2007에 새로 추가)', 'unsigned char'],
			'PrintMemoContents': ['메모 내용 출력여부 (글2007에 새로 추가)', 'unsigned char'],
			'PrintRevision': ['교정부호 출력여부 (글2007에 새로 추가)', 'unsigned char'],
			'PrintWatermark': ['인쇄워터마크 (글2007에 새로 추가)', 'set'],
			'ColorDepth': ['색상수 (bits: 8], 16...)', 'unsigned char'],
			'Resolution': ['해상도', 'unsigned short'],
			'WatermarkType': ['현재 선택된 워터마크의 유형을 나타냄', 'unsigned int'],
			'PosPage': ['워터마크의 위치 기준', 'unsigned char'],
			'TextWrap': ['워터마크의 배치', 'unsigned char'],
			'AlphaText': ['글자 투명도 (0 ~ 255)', 'unsigned char'],
			'AlphaImage': ['그림 투명도 (0 ~ 255)', 'unsigned char'],
			'FontSize': ['글꼴 크기 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT', 'int'],
			'FontColor': ['글자색 (COLORREF)', 'unsigned long'],
			'RotateAngle': ['회전각도 (-360 ~ 360)', 'int'],
			'WaterMarkEff': ['워터마크 효과', 'unsigned char'],
			'LauncherKey': ['빠른 교정을 실행한 키 정보 (글2007에 새로 추가)', 'unsigned char'],
			'HyperLinkRunKey': ['', 'uRL 또는 email 하이퍼링크 작성 키 정보 (글2007에 새로 추가)', 'unsigned char'],
			'SignType': ['교정부호 종류', 'unsigned int'],
			'Margin': ['여백( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT). 오른자리 옮김표와 왼자리 옮김표일 경우에만 적용.',
					   'long'],
			'BeginPos': [
				'시작위치( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT). 오른자리 옮김표와 왼자리 옮김표일 경우에만 적용.',
				'long'],
			'Detail': ['매크로 설명', 'string'],
			'StartsOn': ['구역 나눔으로 새 페이지가 생길 때의 페이지 번호 적용 옵션', 'unsigned char'],
			'LineGrid': ['세로로 줄맞춤을 할지 여부', 'long'],
			'CharGrid': ['가로로 줄맞춤을 할지 여부', 'long'],
			'PageDef': ['용지 설정 정보', 'set'],
			'HideEmptyLine': ['빈 줄 감춤 ', 'unsigned char'],
			'SpaceBetweenColumns': ['동일한 페이지에서 서로 다른 단 사이의 간격', 'long'],
			'TabStop': ['기본 탭 간격', 'long'],
			'FootnoteShape': ['각주 모양', 'set'],
			'EndnoteShape': ['미주 모양', 'set'],
			'HideHeader': ['구역의 첫 쪽에만 머리말 감추기 옵션 ', 'unsigned char'],
			'HideFooter': ['구역의 첫 쪽에만 꼬리말 감추기 옵션 ', 'unsigned char'],
			'HideMasterPage': ['구역의 첫 쪽에만 바탕쪽 감추기 옵션 ', 'unsigned char'],
			'HideBorder': ['구역의 첫 쪽에만 테두리 감추기 옵션 ', 'unsigned char'],
			'HideFill': ['구역의 첫 쪽에만 배경 감추기 옵션 ', 'unsigned char'],
			'HidePageNumPos': ['구역의 첫 쪽에만 쪽번호 감추기 옵션 ', 'unsigned char'],
			'FirstBorder': ['구역의 첫 쪽에만 테두리 표시 옵션 ', 'unsigned char'],
			'FirstFill': ['구역의 첫 쪽에만 배경 표시 옵션 ', 'unsigned char'],
			'OutlineShape': ['개요 번호', 'set'],
			'PageBorderFillBoth': ['쪽 테두리/배경  (양쪽)', 'set'],
			'PageBorderFillEven': ['쪽 테두리/배경  (짝수)', 'set'],
			'PageBorderFillOdd': ['쪽 테두리/배경  (홀수)', 'set'],
			'PageNumber': ['쪽 시작 번호', 'unsigned short'],
			'FigureNumber': ['그림 시작 번호', 'unsigned short'],
			'TableNumber': ['표 시작 번호', 'unsigned short'],
			'EquationNumber': ['수식 시작 번호', 'unsigned short'],
			'WongojiFormat': ['원고지 방식의 포맷팅. CHAR_GRID가 지정되어 함.', 'unsigned char'],
			'MemoShape': ['메모 모양 (글2007에 새로 추가)', 'set'],
			'TextVerticalWidthHead': ['머리말/꼬리말 세로쓰기 여부 (글2007에 새로 추가)', 'int'],
			'ApplyToPageBorderFill': ['채울 영역 분류 (PageBorder 액션에서 사용)', 'unsigned char'],
			'ConvAplly2Index': ['ApplyTo값을 ComboBox의 Index로 변환할지 여부, FALSE이면 IndexToApply로 변환이 이루어진다. (반대변환)', 'int'],
			'Category': [
				'적용범위 분류(ApplyClass)를 사용자가 직접 설정할 때 사용. 아이템이  없으면  글이  현재  상태에  맞춰  적용범위  분류 (ApplyClass)를 설정한다. (일반적으로 설정하지 않고 사용)',
				'int'],
			'CellAttr': ['셀 모양 복사', 'unsigned char'],
			'CellBorder': ['선 모양 복사', 'unsigned char'],
			'CellFill': ['셀 배경 복사', 'unsigned char'],
			'TypeBodyAndCellOnly': ['본문과 셀 모양 둘 다 복사 or 셀 모양만 복사, (글2007에 새로 추가)', 'int'],
			'TreatAsChar': ['글자처럼 취급 ', 'unsigned char'],
			'AffectsLine': ['줄 간격에 영향을 줄지 여부 on/off (TreatAsChar가 TRUE일 경우에만 사용된다)', 'unsigned char'],
			'VertRelTo': ['세로 위치의 기준', 'unsigned char'],
			'VertOffset': [
				'VertRelTo와  VertAlign을  기준으로  한  Y축  위치  오프셋  값.  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위.',
				'long'],
			'HorzRelTo': ['가로 위치의 기준', 'unsigned char'],
			'HorzOffset': [
				'HorzRelTo와  HorzAlign을  기준으로  한  X축  위치  오프셋  값.  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위.',
				'long'],
			'FlowWithText': ['그리기 개체의 세로 위치를 쪽 영역 안쪽으로 제한할지 여부 on/off, VertRelTo값이 2(문단영역)일 경우에만 의미가 있다.', 'unsigned char'],
			'AllowOverlap': [
				'다른 개체와 겹치는 것을 허용할지 여부 on/offTreatAsChar가 FALSE일 때만 의미가 있으며, FlowWithText가 TRUE이면 AllowOverlap은 항상 FALSE로 간주한다.',
				'unsigned char'],
			'WidthRelTo': ['개체 너비 기준', 'unsigned char'],
			'HeightRelTo': ['개체 높이 기준', 'unsigned char'],
			'ProtectSize': ['크기 보호 ', 'unsigned char'],
			'TextFlow': ['그리기  개체의  좌/우  어느  쪽에  글을  배치할지  지정하는  옵션. TextWrap의 값이 0일 때만 유효하다', 'unsigned char'],
			'OutsideMarginLeft': ['개체의 바깥 여백. (왼쪽)  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위',
								  'long'],
			'OutsideMarginRight': ['개체의 바깥 여백. (오른쪽)  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위',
								   'long'],
			'OutsideMarginTop': ['개체의 바깥 여백. (위)  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위',
								 'long'],
			'OutsideMarginBottom': ['개체의 바깥 여백. (아래)  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위',
									'long'],
			'NumberingType': ['이 개체가 속하는 번호 범주', 'unsigned char'],
			'LayoutWidth': ['개체가 페이지에 배열될 때 계산되는 폭의 값', 'long'],
			'LayoutHeight': ['개체가 페이지에 배열될 때 계산되는 높이 값', 'long'],
			'Lock': ['개체 보호하기 ', 'unsigned char'],
			'HoldAnchorObj': ['쪽 나눔 방지 on/off (글2007에 새로 추가)', 'unsigned char'],
			'AdjustSelection': ['개체 Selection 상태 TRUE/FASLE (글2007에 새로 추가)', 'unsigned char'],
			'AdjustTextBox': ['글상자로 TRUE/FASLE (글2007에 새로 추가)', 'unsigned char'],
			'AdjustPrevObjAttr': ['앞개체 속성 따라가기 TRUE/FASLE (글2007에 새로 추가)', 'unsigned char'],
			'ShapeDrawLayOut': ['그리기 개체의 Layout', 'set'],
			'ShapeDrawLineAttr': ['그리기 개체의 Line 속성', 'set'],
			'ShapeDrawFillAttr': ['그리기 개체의 Fill 속성', 'set'],
			'ShapeDrawImageAttr': ['그림 개체 속성', 'set'],
			'ShapeDrawRectType': ['사각형 그리기 개체 유형', 'set'],
			'ShapeDrawArcType': ['호 그리기 개체 유형', 'set'],
			'ShapeDrawResize': ['그리기 개체 리사이징', 'set'],
			'ShapeDrawRotate': ['그리기 개체 회전', 'set'],
			'ShapeDrawEditDetail': ['그리기 개체 EditDetail', 'set'],
			'ShapeDrawImageScissoring': ['그림 개체 자르기', 'set'],
			'ShapeDrawScAction': ['그리기 개체 회전', 'set'],
			'ShapeDrawCtrlHyperlink': ['그리기 개체 하이퍼링크', 'set'],
			'ShapeDrawCoordInfo': ['그리기 개체 좌표정보', 'set'],
			'ShapeDrawShear': ['그리기 개체 기울이기', 'set'],
			'ShapeDrawTextart': ['글맵시', 'set'],
			'ShapeDrawShadow': ['그림자', 'set'],
			'ShapeTableCell': ['셀 정보', 'set'],
			'ShapeListProperties': ['서브 list 속성', 'set'],
			'ShapeCaption': ['캡션', 'set'],
			'ShapeFormGeneral': ['양식개체 일반', 'set'],
			'ShapeFormCommonAttr': ['양식개체 공통속성', 'set'],
			'ShapeFormCharshapeattr': ['양식개체 글자모양 속성', 'set'],
			'ShapeFormButtonAttr': ['양식개체 버튼 속성', 'set'],
			'ShapeFormComboboxAttr': ['양식개체 콤보박스 속성', 'set'],
			'ShapeFormEditAttr': ['양식개체 에디트박스 속성', 'set'],
			'ShapeFormScrollbarAttr': ['양식개체 스크롤바 속성', 'set'],
			'ShapeFormListBoxAttr': ['양식개체 리스트박스 속성', 'set'],
			'ShapeType': ['TablePropertyDialog 의 종류', 'unsigned char'],
			'ShapeCellSize': ['셀 크기 적용 여부 ', 'unsigned char'],
			'ShapeCreationType': ['그리기 개체 형태 (DrawObjCreatorObject에서 사용)', 'unsigned char'],
			'ShapeCreationMode': ['마우스로 그리기 여부 (on/off) (DrawObjCreatorObject에서 사용)', 'unsigned char'],
			'ShapeObjectLine': ['그리기 선 모양 복사', 'unsigned int'],
			'ShapeObjectFill': ['그리기 채우기 복사', 'unsigned char'],
			'ShapeObjectSize': ['그리기 개체 크기 복사', 'unsigned char'],
			'ShapeObjectShadow': ['그리기 개체 그림자 복사', 'unsigned char'],
			'ShapeObjectPicEffect': ['그림 효과 복사', 'unsigned char'],
			'KeyOption': ['키 콤보에서 선택된 키를 저장함.', 'array'],
			'CheckJasoReverse': ['자소 단위 비교 Flag - 종], 중], 초', 'unsigned char'],
			'DelimiterType': ['필드 구분 기호 형식', 'unsigned char'],
			'DelimiterChars': ['필드 구분 기호들. DelimiterType이 3(사용자 정의)일 경우에만 유효', 'string'],
			'IgnoreMultiDelimiter': ['연속되는 구분기호 무시 Flag', 'unsigned char'],
			'CheckFromRear': ['단어 뒤에서 부터 비교 Flag', 'unsigned char'],
			'CheckExtendYear': ['두 자리 년도 확장 check Flag', 'unsigned char'],
			'YearBase': ['두 자리 년도 시작 년도', 'unsigned int'],
			'LangOrderType': ['사전언어순서 값', 'unsigned char'],
			'CheckJaso': ['자소 단위 비교 Flag - 초, 중, 종', 'unsigned char'],
			'Apply': ['적용할 스타일 인덱스', 'int'],
			'Alternation': ['대체할 스타일 인덱스', 'int'],
			'Sum': ['합', 'string'],
			'Average': ['평균', 'string'],
			'LineCount': ['줄 수', 'string'],
			'Comma': ['세 자리마다 쉼표로 자리 구분 ', 'unsigned char'],
			'Title': ['제목', 'string'],
			'Author': ['지은이', 'string'],
			'Date': ['날짜', 'string'],
			'KeyWords': ['키워드', 'string'],
			'Comments': ['기타', 'string'],
			'CreationTimeLow': ['작성한 날짜 (low)', 'unsigned long'],
			'CreationTimeHigh': ['작성한 날짜 (high)', 'unsigned long'],
			'ModifiedTimeLow': ['마지막 수정한 날짜 (low)', 'unsigned long'],
			'ModifiedTimeHigh': ['마지막 수정한 날짜 (high)', 'unsigned long'],
			'PrintedTimeLow': ['마지막 인쇄한 날짜 (low)', 'unsigned int'],
			'PrintedTimeHigh': ['마지막 인쇄한 날짜 (high)', 'unsigned long'],
			'LastSavedBy': ['마지막 저장한 사람', 'string'],
			'Characters': ['문서분량 (글자)', 'int'],
			'Words': ['문서분량 (낱말)', 'int'],
			'Lines': ['문서분량 (줄)', 'int'],
			'Paragraphs': ['문서분량 (문단)', 'int'],
			'Pages': ['문서분량 (쪽)', 'int'],
			'CopyPapers': ['문서분량 (원고지)', 'int'],
			'Etcetera': ['문서분량 (표], 그림 등)', 'int'],
			'DocVersion': ['문서 파일 버전 (글2007에 새로 추가)', 'string'],
			'HwpVersion': ['문서를 생성한 글 워드프로그램의 버전 (글2007에 새로 추가)', 'string'],
			'HanjaChar': ['문서분량 (한자 수) (글2007에 새로 추가)', 'char'],
			'AutoTabLeft': ['문단 왼쪽 끝 탭 ', 'unsigned char'],
			'TabItem': ['각각의 탭 정의.], 하나의 탭 아이템은 세 개의 인수로 표현되어 있음. (n * 3 + 0) - PIT_I', 'array'],
			'PageBreak': ['표가 페이지 경계에 걸렸을 때의 처리 방식', 'unsigned char'],
			'RepeatHeader': ['제목 행을 반복할지 여부. ', 'unsigned char'],
			'CellSpacing': ['셀 간격(HTML의 셀 간격과 동일 의미.  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)',
							'unsigned long'],
			'CellMarginLeft': ['기본 셀 안쪽 여백(왼쪽)', 'long'],
			'CellMarginRight': ['기본 셀 안쪽 여백(오른쪽)', 'long'],
			'CellMarginTop': ['기본 셀 안쪽 여백(위쪽)', 'long'],
			'CellMarginBottom': ['기본 셀 안쪽 여백(아래쪽)', 'long'],
			'TableCharInfo': ['표와 연결된 차트 정보 - 차트 미완성', 'set'],
			'Cell': ['셀 속성', 'set'],
			'Rows': ['행 수 (생략하면 5)', 'unsigned short'],
			'Cols': ['칼럼 수 (생략하면 5)', 'unsigned short'],
			'RowHeight': ['행의 디폴트 높이 (PIT_I4)', 'array'],
			'ColWidth': ['칼럼의 디폴트 폭 (PIT_I4)', 'array'],
			'CellInfo': ['정보가 없는 셀은 디폴트값을 따라가므로 모든 셀에 대해 정보를 줄 필요는 없다.', 'array'],
			'WidthType': ['너비', 'unsigned char'],
			'HeightType': ['높이', 'unsigned char'],
			'WidthValue': ['너비 값', 'int'],
			'HeightValue': ['높이 값', 'int'],
			'TableTemplateValue': ['표 마당 적용 여부 (글2007에 새로 추가)', 'unsigned char'],
			'TableProperties': ['초기 표 속성', 'set'],
			'TableTemplate': ['표마당 적용 속성 (글2007에 새로 추가)', 'set'],
			'TableDrawProperties': ['마우스로 선을 그릴 때 속성 (글2007에 새로 추가)', 'set'],
			'DistributeHeight': ['줄 높이를 같게', 'unsigned char'],
			'Merge': ['나누기 전에 합치기', 'unsigned char'],
			'Mode2': ['셀 나누기 모드 2], 셀 나누기를 할 때], adjust를 생략하고 셀이 어 긋나는 것을 방지한다. (글2007에 새로 추가)', 'unsigned char'],
			'UserDefine': ['사용자 정의 필드 구분 기호', 'string'],
			'AutoOrDefine': ['자동으로 할 것인지 분리 문자를 지정 할 것인지를 결정', 'unsigned char'],
			'KeepSeperator': ['선택 사항 (구분자 유지)', 'unsigned char'],
			'DelimiterEtc': ['기타 문자 필드 구분 기호', 'string'],
			'SwapMargin': ['여백 뒤집기 지원여부', 'unsigned char'],
			'ApplyTarger': ['적용 대상. 다음 값의 조합으로 구성된다', 'unsigned int'],
			'CreateMode': ['표 만들기 모드 (표 만들기에서 제목줄에 제목 속성 넣기 위해)', 'unsigned char'],
			'Landscope': ['용지 방향', 'unsigned char'],
			'Save': ['저장', 'long'],
			'LoadType': ['로드 방법', 'long'],
			'SourcePath': ['버전 비교용 소스 패스', 'string'],
			'TargetPath': ['버전 비교용 타겟 패스', 'string'],
			'ItemStartIndex': ['버전 비교를 보여줄 시작 히스토리 인덱스', 'unsigned char'],
			'ItemEndIndex': ['버전 비교를 보여줄 마지막 히스토리 인덱스', 'unsigned char'],
			'ItemOverWrite': ['히스토리  정보를  저장할  때  마지막  버전으로  덮어쓰는  플랙, ', 'unsigned char'],
			'ItemSaveDescription': ['히스토리 정보를 저장할 때 설명을 입력하는 대화상자를 띄우는 플 랙 ', 'unsigned char'],
			'TempFilePath': ['버전 비교용 임시파일 경로', 'array'],
			'ItemInfoIndex': ['버전 정보 얻어오기 및 삭제 시 사용될 인덱스', 'unsigned long'],
			'SaveFilePath': ['버전 저장 파일 경로(OCX 컨트롤용)', 'string'],
			'ItemInfoWriter': ['작성자 정보', 'string'],
			'ItemInfoDescription': ['해당 버전에 대한 설명', 'string'],
			'ItemInfoTimeHi': ['날짜 정보, FILETIME의 HIWORD', 'unsigned long'],
			'ItemInfoTimeLo': ['날짜 정보, FILETIME의 LOWORD', 'unsigned long'],
			'ItemInfoLock': ['히스토리 정보 수정 플랙', 'unsigned char'],
			'OptionFlag': ['뷰 옵션 플랙. 여러 개를 OR연산하여 지정할 수 있음', 'unsigned int'],
			'ZoomType': ['화면 확대 종류', 'unsigned char'],
			'ZoomRatio': ['화면 확대 종류가 사용자 정의인 경우 화면 확대 비율. 10% ~ 500%', 'unsigned short'],
			'ZoomCntX': ['화면 확대 종류가 여러 쪽인 경우 가로 페이지 수., 1 ~ 8', 'unsigned char'],
			'ZoomCntY': ['화면 확대 종류가 여러 쪽인 경우 세로 페이지 수., 1 ~ 8', 'unsigned char'],
			'ZoomMirror': ['맞쪽 보기. 페이지 수가 2의 배수일 때만 동작, (글2007에 새로 추가)', 'unsigned char'],
			'ViewPosX': ['현재 뷰의 X값', 'long'],
			'ViewPosY': ['현재 뷰의 Y값', 'long'],

		}

		self.varx["parameter_vs_parameter_option"] = {
			'AutoFillSection': {0: '기본', 1: '사용자 정의', "default": 0},
			'NumType': {0: '쪽 번호', 1: '각주 번호', 2: '미주 번호', 3: '그림 번호', 4: '표 번호', 5: '수식 번호'},
			'Type': {0: '일반 책갈피', 1: '블록 책갈피'},
			'Command': {0: '책갈피 생성', 1: '책갈피로 이동', 2: '책갈피 수정'},
			'SlashFlag': {0: '하단 대각선 bit', 1: '중앙 대각선 bit', 2: '상단 대각선'},
			'BackSlashFlag': {0: '하단 대각선 bit', 1: '중앙 대각선 bit', 2: '상단 대각선'},
			'BorderFill3D': {0: 'off', 1: 'on'},
			'Shadow': {0: 'off', 1: 'on'},
			'BreakCellSeparateLine': {0: '경계선 설정을 기본 값에 따름', 1: '사용자가 경계선 설정'},
			'CounterSlashFlag': {0: '순방향', 1: '역방향'},
			'CounterBackSlashFlag': {0: '순방향', 1: '역방향'},
			'CenterLineFlag': {0: '중심선 없음', 1: '중심선 있음'},
			'HasCharShape': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
			'Alignment': {0: '왼쪽 정렬', 1: '가운데 정렬', 2: '오른쪽 정렬'},
			'UseInstWidth': {0: 'off', 1: 'on'},
			'AutoIndent': {0: '들여쓰기 안함', 1: '들여쓰기'},
			'TextOffsetType': {0: 'percent', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
			'HasImage': {0: '일반 글머리표', 1: '그림 글머리표'},
			'Side': {0: '왼쪽', 1: '오른쪽', 2: '위', 3: '아래'},
			'HasMargin': {0: 'off', 1: 'on'},
			'Protected': {0: 'off', 1: 'on'},
			'Header': {0: 'off', 1: 'on'},
			'Editable': {0: 'off', 1: 'on'},
			'Dirty': {0: 'off', 1: 'on (글2007에 새로 추가)'},
			'ApplyTo': {0: '선택된 셀', 1: '전체 셀', 2: '여러 셀에 걸쳐 적용'},
			'FontTypeHangul': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
			'FontTypeLatin': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
			'FontTypeHanja': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
			'FontTypeJapanese': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
			'FontTypeOther': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
			'FontTypeSymbol': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
			'FontTypeUser': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
			'Bold': {0: 'off', 1: 'on'},
			'Italic': {0: 'off', 1: 'on'},
			'SmallCaps': {0: 'off', 1: 'on'},
			'Emboss': {0: 'off', 1: 'on'},
			'Engrave': {0: 'off', 1: 'on'},
			'SuperScript': {0: 'off', 1: 'on'},
			'SubScript': {0: 'off', 1: 'on'},
			'UnderlineType': {0: 'none', 1: 'bottom', 2: 'center', 3: 'top'},
			'OutlineType': {0: 'none', 1: 'solid', 2: 'dot', 3: 'thick', 4: 'dash', 5: 'dashdot', 6: 'dashdotdot'},
			'ShadowType': {0: 'none', 1: 'drop', 2: 'continuous'},
			'StrikeOutType': {0: 'none', 1: 'red single', 2: 'red double', 3: 'text single', 4: 'text double'},
			'DiacSymMark': {0: 'none', 1: '검정 동그라미', 2: '속 빈 동그라미'},
			'UseFontSpace': {0: 'off', 1: 'on'},
			'UseKerning': {0: 'off', 1: 'on'},
			'SameSize': {0: '단 너비 각자 지정', 1: '단 너비 동일'},
			'Layout': {0: '왼쪽부터', 1: '오른쪽부터', 2: '맞쪽'},
			'Number': {0: 'off', 1: 'on'},
			'Alpha': {0: 'off', 1: 'on'},
			'Symbol': {0: 'off', 1: 'on'},
			'Gata': {0: 'off', 1: 'on'},
			'HGJamo': {0: 'off', 1: 'on'},
			'Hanja': {0: 'off', 1: 'on'},
			'Hira': {0: 'off', 1: 'on 확장 또는 변환 액션 간 파라메터셋의 호환을 위해 선언됨.'},
			'Gu': {0: 'off', 1: 'on'},
			'CurCtrl': {0: '일반 텍스트', 1: '글상자', '기타': '컨트롤 ID'},
			'PicEffect': {0: '실제 이미지 그대로', 1: '그레이스케일', 2: '흑백 효과'},
			'DrawFillImageType': {0: '바둑판식으로', 1: '가로-위만 바둑판식으로 배열', 2: '가로-아래만 바둑판식으로 배열', 3: '세로-왼쪽만 바둑판식으로 배열',
								  4: '세로 오른쪽만 바둑판식으로 배열', 5: '크기에 맞추어', 6: '가운데로', 7: '가운데 위로', 8: '가운데 아래로', 9: '왼쪽 가운데로',
								  10: '왼쪽 위로', 11: '왼쪽 아래로', 12: '오른쪽 가운데로', 13: '오른쪽 위로', 14: '오른쪽 아래로'},
			'RotateImage': {0: '회전 안 함', 1: '회전함'},
			'FontType': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
			'PosType': {0: '위', 1: '아래'},
			'Align': {0: '양쪽 정렬', 1: '왼쪽 정렬', 2: '오른쪽 정렬', 3: '가운데 정렬', 4: '배분 정렬', 5: '나눔 정렬'},
			'Flag': {0: '모든 각주를 미주로 바꾸기', 1: '모든 미주를 각주로 바꾸기', 2: '각주와 미주를 서로 바꾸기'},
			'OpenFlag': {0: '새 창으로 열기', 1: '현재 창의 새 탭에 열기', 2: '현재 창의 현재 탭에 열기', 3: '위 세 값의 mask',
						 4: '이미 열려진 문서일 때 다시 load할지 뭍을 것인지', 8: '초기 모드를 최근 작업 문서 상태로, 0x10:문서 마당'},
			'NoPrint': {0: '프린트 가능', 1: '프린트 가능하지 않음'},
			'NoCopy': {0: '복사 가능', 1: '복사 가능하지 않음'},
			'Direction': {0: '아래쪽', 1: '위쪽', 2: '문서 전체'},
			'MatchCase': {0: 'off', 1: 'on'},
			'AllWordForms': {0: 'off', 1: 'on'},
			'SeveralWords': {0: 'off', 1: 'on'},
			'UseWildCards': {0: 'off', 1: 'on'},
			'WholeWordOnly': {0: 'off', 1: 'on'},
			'AutoSpell': {0: 'off', 1: 'on'},
			'ReplaceMode': {0: 'off', 1: 'on'},
			'IgnoreFindString': {0: 'off', 1: 'on'},
			'IgnoreReplaceStrin g': {0: 'off', 1: 'on'},
			'IgnoreMessage': {0: 'off', 1: 'on'},
			'FindJaso': {0: 'off', 1: 'on'},
			'FindRegExp': {0: 'off', 1: 'on'},
			'AutoPlay': {0: 'off', 1: 'on'},
			'LoopPlay': {0: 'off', 1: 'on'},
			'ShowMenu': {0: 'Hide', 1: 'Show'},
			'PlaceAt': {0: '각 단마다 따로 배열', 1: '통단으로 배열',
						2: '가장 오른쪽 단에 배열, - 미주용 옵션 (문서 내에서 미주를 어디에 위치시킬지), {0:문서의 마지막, 1:구역의 마지막'},
			'Restart': {0: '앞 구역에 이어서', 1: '현재 구역부터 새로 시작', 2: '쪽마다 새로 시작 (각주 전용)'},
			'BeneathText': {0: 'off', 1: 'on'},
			'SaveType': {0: 'HTML', 1: 'HWP'},
			'Method': {0: '격자와 상관없이', 1: '격자 자석효과', 2: '격자에만 붙음'},
			'Show': {0: 'off', 1: 'on'},
			'ZOrder': {0: '글 아래', 1: '글 위'},
			'ViewLine': {0: '모두', 1: '수평격자만', 2: '수직격자만'},
			'CtrlType': {0: '머리말', 1: '꼬리말'},
			'HeaderFooterCtrlType': {0: '머리말', 1: '꼬리말'},
			'ShowSingle': {0: '누름틀 페이지만 보이기', 1: '개인 정보 페이지만 보이기', 2: '문서 요약 페이지만 보이기', 3: '만든 날짜 페이지만 보이기',
						   4: '파일 경로 페이지만 보이기'},
			'TemplateType': {0: '누름틀', 1: '개인 정보', 2: '문서 요약', 3: '만든 날짜', 4: '파일 경로'},
			'LineWrap': {0: '일반적인 줄 바꿈', 1: '줄을 바꾸지 않음', 2: '자간을 조정하여 한 줄을 유지'},
			'Input': {0: 'WAB', 1: 'OAB', 2: 'HWP', 3: 'DBF'},
			'DbfCode': {0: 'KS', 1: 'KSSM', 2: 'GB', 3: 'BIG5', 4: 'SJIS'},
			'Output': {0: 'PRINTER', 1: 'PREVIEW', 2: 'FILE', 3: 'MAIL'},
			'Make': {1: '제목 차례', 2: '표 차례', 4: '그림 차례', 8: '수식 차례, 제목 차례를 지정한 경우에는 다음의 값을 추가로 지정할 수 있다', 16: '개요 문단으로 모으기',
					 32: '스타일로 모으기', 64: '차례코드로 모으기'},
			'AutoTabRight': {0: '자동 탭 사용안함', 1: '자동 탭 사용'},
			'Position': {0: '현재 문서', 1: '새 탭으로'},
			'Duplicate': {0: 'off', 1: 'on'},
			'Front': {0: 'off', 1: 'on'},
			'MemoType': {1: '메모 넣기', 2: '메모 지우기', 3: '메모 고치기'},
			'XRelTo': {0: '종이', 1: '쪽'},
			'YRelTo': {0: '종이', 1: '쪽'},
			'AutoRewind': {0: 'off', 1: 'on'},
			'ShowCtrlPanel': {0: 'Hide', 1: 'Show'},
			'ShowPosCtrl': {0: 'Hide', 1: 'Show'},
			'EnablePos': {0: 'Disable', 1: 'Enable'},
			'ShowTrackBar': {0: 'Hide', 1: 'Show'},
			'EnableTrack': {0: 'Disable', 1: 'Enable'},
			'ShowChaption': {0: 'Hide', 1: 'Show'},
			'ShowAudio': {0: 'Hide', 1: 'Show'},
			'ShowStatus': {0: 'Hide', 1: 'Show'},
			'HasCharShapeLevel0': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
			'HasCharShapeLevel1': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
			'HasCharShapeLevel2': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
			'HasCharShapeLevel3': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
			'HasCharShapeLevel4': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
			'HasCharShapeLevel5': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
			'HasCharShapeLevel6': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
			'AlignmentLevel0': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
			'AlignmentLevel1': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
			'AlignmentLevel2': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
			'AlignmentLevel3': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
			'AlignmentLevel4': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
			'AlignmentLevel5': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
			'AlignmentLevel6': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
			'TextOffsetTypeLevel0': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
			'TextOffsetTypeLevel1': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
			'TextOffsetTypeLevel2': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
			'TextOffsetTypeLevel3': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
			'TextOffsetTypeLevel4': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
			'TextOffsetTypeLevel5': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
			'TextOffsetTypeLevel6': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
			'Aspect': {0: '내용으로 표시', 1: '아이콘으로 표시'},
			'IconMM': {1: 'MM_TEXT', 2: 'MM_LOMETRIC', 3: 'MM_HIMETRIC', 4: 'MM_LOENGLISH', 5: 'MM_HIENGLISH',
					   6: 'MM_TWIPS', 7: 'MM_ISOTROPIC', 8: 'MM_ANISOTROPIC'},
			'HeaderInside': {0: 'off', 1: 'on'},
			'FooterInside': {0: 'off', 1: 'on'},
			'FillArea': {0: '종이', 1: '쪽', 2: '테두리'},
			'Landscape': {0: '좁게', 1: '넓게'},
			'GutterType': {0: '한쪽 편집', 1: '맞쪽 편집', 2: '위로 넘기기'},
			'Fields': {2: '꼬리말', 4: '바탕쪽', 8: '테두리', 16: '배경', 32: '쪽번호 위치'},
			'PageStartsOn': {0: '양쪽', 1: '짝수쪽', 2: '홀수쪽'},
			'DrawPos': {0: '쪽 번호 없음', 1: '왼쪽 위', 2: '가운데 위', 3: '오른쪽 위', 4: '왼쪽 아래', 5: '가운데 아래', 6: '오른쪽 아래', 7: '바깥쪽 위',
						8: '바깥쪽 아래', 9: '안쪽 위', 10: '안쪽 아래'},
			'LineSpacingType': {0: '글자에 따라', 1: '고정 값', 2: '여백만 지정'},
			'BreakLatinWord': {0: '단어', 1: '하이픈', 2: '글자'},
			'BreakNonLatinWord': {True: '글자', False: '어절'},
			'SnapToGrid': {0: 'off', 1: 'on'},
			'WidowOrphan': {0: 'off', 1: 'on'},
			'KeepWithNext': {0: 'off', 1: 'on'},
			'KeepLinesTogether': {0: 'off', 1: 'on'},
			'PagebreakBefore': {0: 'off', 1: 'on'},
			'TextAlignment': {0: '글꼴기준', 1: '위', 2: '가운데', 3: '아래'},
			'FontLineHeight': {0: 'off', 1: 'on'},
			'HeadingType': {0: '없음', 1: '개요', 2: '번호', 3: '불릿'},
			'BorderConnect': {0: 'off', 1: 'on'},
			'BorderText': {0: '단', 1: '텍스트'},
			'TailType': {0: 'off', 1: 'on'},
			'Ask': {0: '문서 암호를 확인', 1: '문서 암호를 설정'},
			'ApplyLinkAttr': {0: 'off', 1: 'on'},
			'ApplyForbidden': {0: 'off', 1: 'on'},
			'Range': {0: '문서전체 (연결된 문서 포함)', 1: '현재 쪽', 2: '현재부터', 3: '현재까지', 4: '일부분', 5: '선택한 쪽만',
					  6: '현재 문서 (연결된 문서 미포함)', 7: '현재 구역'},
			'PrintMethod': {0: '자동 인쇄', 1: '공급 용지에 맞추어', 2: '나눠 찍기', 3: '자동으로 모아 찍기', 4: '2쪽씩 모아 찍기', 5: '3쪽씩 모아 찍기',
							6: '4쪽씩 모아 찍기', 7: '6쪽씩 모아 찍기', 8: '8쪽씩 모아 찍기', 9: '9쪽씩 모아 찍기', 10: '16쪽씩 모아 찍기'},
			'Device': {0: '프린터', 1: '팩스', 2: '그림으로 저장', 3: 'PDF 파일로 저장', 4: '미리보기'},
			'WatermarkType': {0: '워터마크 없음', 1: '그림 워터마크', 2: '글자 워터마크'},
			'PosPage': {0: '종이 기준', 1: '쪽 기준'},
			'TextWrap': {0: '글 뒤로', 1: '글 앞으로'},
			'WaterMarkEff': {0: 'off', 1: 'on'},
			'SignType': {0: '교정부호 없음', 13: '줄표', 1: '띄움표', 14: '부호 넣음표', 2: '줄 바꿈표', 15: '넣음표', 3: '줄 비움표', 16: '고침표',
						 4: '메모형 고침표', 17: '자리 바꿈표', 5: '지움표', 18: '오른자리 옮김표', 6: '붙임표', 19: '자료연결', 7: '뺌표', 20: '왼자리 옮김표',
						 8: '줄 이음표', 21: '부분자리 옮김표', 9: '줄 붙임표', 22: '줄 서로 바꿈표', 10: '톱니표', 23: '자리바꿈 나눔표(내부용)', 11: '생각표',
						 24: '줄 서로 바꿈 나눔표(내부용)', 12: '칭찬표'},
			'StartsOn': {0: '이어서', 1: '홀수', 2: '짝수', 3: '임의 값'},
			'LineGrid': {0: 'off', 1: '간격을  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위로 지정'},
			'CharGrid': {0: 'off', 1: '간격을  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위로 지정'},
			'HideEmptyLine': {0: 'off', 1: 'on'},
			'HideHeader': {0: 'off', 1: 'on'},
			'HideFooter': {0: 'off', 1: 'on'},
			'HideMasterPage': {0: 'off', 1: 'on'},
			'HideBorder': {0: 'off', 1: 'on'},
			'HideFill': {0: 'off', 1: 'on'},
			'HidePageNumPos': {0: 'off', 1: 'on'},
			'FirstBorder': {0: 'off', 1: 'on'},
			'FirstFill': {0: 'off', 1: 'on'},
			'PageNumber': {0: '앞 구역에 이어', 'n': '새 번호로 시작'},
			'FigureNumber': {0: '앞 구역에 이어', 'n': '새 번호로 시작'},
			'TableNumber': {0: '앞 구역에 이어', 'n': '새 번호로 시작'},
			'EquationNumber': {0: '앞 구역에 이어', 'n': '새 번호로 시작'},
			'ApplyToPageBorderFill': {0: '종이', 1: '쪽', 2: '테두리 (글2007에 새로 추가)'},
			'TreatAsChar': {0: 'off', 1: 'on'},
			'VertRelTo': {0: '종이 영역(Paper)', 1: '쪽 영역(Page)', 2: '문단 영역(Paragraph), (TreatAsChar가 FALSE일 경우에만 사용된다)'},
			'HorzRelTo': {0: '종이 영역(Paper)', 1: '쪽 영역(Page)', 2: '다단 영역(Column)',
						  3: '문단 영역(Paragraph), (TreatAsChar가 FALSE일 경우에만 사용된다)'},
			'WidthRelTo': {0: '종이(Paper)', 1: '쪽(Page)', 2: '다단(Column)', 3: '문단(Paragraph)', 4: '고정 값(Absolute)'},
			'HeightRelTo': {0: '종이(Paper)', 1: '쪽(Page)', 2: '고정 값(Absolute)'},
			'ProtectSize': {0: 'off', 1: 'on'},
			'TextFlow': {0: '양쪽 모두(Both)', 1: '왼쪽만(Left Only)', 2: '오른쪽만(Right Only)', 3: '왼쪽과 오른쪽 중 넓은 쪽(Largest Only)'},
			'NumberingType': {0: '없음', 1: '그림', 2: '표', 3: '수식'},
			'Lock': {0: 'off', 1: 'on'},
			'HoldAnchorObj': {0: 'off', 1: 'on'},
			'AdjustSelection': {0: 'off', 1: 'on'},
			'AdjustTextBox': {0: 'off', 1: 'on'},
			'AdjustPrevObjAttr': {0: 'off', 1: 'on'},
			'ShapeCellSize': {0: 'off', 1: 'on'},
			'ShapeCreationMode': {0: 'off', 1: 'on'},
			'DelimiterType': {0: '탭(Tab)', 1: '콤마', 2: '빈칸(Space)', 3: '사용자 정의'},
			'Comma': {0: 'off', 1: 'on'},
			'AutoTabLeft': {0: 'off', 1: 'on'},
			'TabItem': {0: '왼쪽', 1: '오른쪽', 2: '가운데', 3: '소수점'},
			'PageBreak': {0: '나누지 않는다', 1: '테이블은 나누지만 셀은 나누지 않는다', 2: '셀 내의 텍스트도 나눈다.'},
			'RepeatHeader': {0: 'off', 1: 'on'},
			'ApplyTarger': {1: '제목 줄', 2: '마지막 줄', 4: '첫째 칸', 8: '마지막 칸'},
			'Landscope': {0: '좁게', 1: '넓게'},
			'ItemOverWrite': {0: 'off', 1: 'on'},
			'ItemSaveDescription': {0: 'off', 1: 'on'},
			'OptionFlag': {1: 'off', 2: '공백과 폭이 없는 컨트롤을 기호로', 4: '문단 마크 기호로', 8: '안내선', 16: '그리기 격자', 32: '그림 감춤'},
			'ZoomType': {0: '사용자 정의', 1: '쪽 맞춤', 2: '폭 맞춤', 3: '여러 쪽'},
			'Option': {0: '일반', 1: '주소', 2: '사람이름', 3: '한글복원', "default": 0},
		}

		self.varx["all_properties_list"] = ["Actions",
								"AlternateRecipientAllowed","Application","Attachments","AutoForwarded",
								"AutoResolvedWinner","BCC","BillingInformation","Body","BodyFormat",
								"Categories","CC","Class","Companies","Conflicts","ConversationID",
								"ConversationIndex","ConversationTopic","CreationTime","DeferredDeliveryTime","DeleteAfterSubmit",
								"DownloadState","EntryID","ExpiryTime","FlagRequest","FormDescription","GetInspector",
								"HTMLBody","Importance","InternetCodepage","IsConflict","IsMarkedAsTask","ItemProperties",
								"LastModificationTime","MarkForDownload","MessageClass","Mileage","NoAging","OriginatorDeliveryReportRequested",
								"OutlookInternalVersion","OutlookVersion","Parent","Permission","PermissionService","PermissionTemplateGuid",
								"PropertyAccessor","ReadReceiptRequested","ReceivedByEntryID","ReceivedByName","ReceivedOnBehalfOfEntryID",
								"ReceivedOnBehalfOfName","ReceivedTime","RecipientReassignmentProhibited","Recipients","ReminderOverrideDefault",
								"ReminderPlaySound","ReminderSet","ReminderSoundFile","ReminderTime","RemoteStatus","ReplyRecipientNames",
								"ReplyRecipients","RetentionExpirationDate","RetentionPolicyName","RTFBody","Saved","SaveSentMessageFolder",
								"Sender","SenderEmailAddress","SenderEmailType","SenderName","SendUsingAccount","Sensitivity",
								"Sent","SentOn","SentOnBehalfOfName","Session","Size","Subject","Submitted","TaskCompletedDate",
								"TaskDueDate","TaskStartDate","TaskSubject","To","ToDoTaskOrdinal","UnRead","UserProperties","VotingOptions","VotingResponse"]

		self.varx["action_name_vs_parameter_set_id"] = {
			'AddHanjaWord': None, 'AllReplace': 'FindReplace', 'AQcommandMerge': 'UserQCommandFile',
			'AutoChangeHangul': None, 'AutoChangeRun': None, 'AutoSpellRun': None, 'AutoSpellSelect1': None,
			'AutoSpellSelect2': None, 'AutoSpellSelect3': None, 'AutoSpellSelect4': None, 'AutoSpellSelect5': None,
			'AutoSpellSelect6': None, 'AutoSpellSelect7': None, 'AutoSpellSelect8': None, 'AutoSpellSelect9': None,
			'AutoSpellSelect10': None, 'AutoSpellSelect11': None, 'AutoSpellSelect12': None, 'AutoSpellSelect13': None,
			'AutoSpellSelect14': None, 'AutoSpellSelect15': None, 'AutoSpellSelect16': None, 'Average': 'Sum',
			'BackwardFind': 'FindReplace', 'Bookmark': 'BookMark', 'BreakColDef': None, 'BreakColumn': None,
			'BreakLine': None, 'BreakPage': None, 'BreakPara': None, 'BreakSection': None, 'Cancel': None,
			'CaptureDialog': None, 'CaptureHandler': None, 'CellBorder': 'CellBorderFill',
			'CellBorderFill': 'CellBorderFill', 'CellFill': 'CellBorderFill', 'CellZoneBorder': 'CellBorderFill',
			'CellZoneBorderFill': 'CellBorderFill', 'CellZoneFill': 'CellBorderFill', 'ChangeRome': None,
			'ChangeRomeString': None, 'ChangeRomeUser': None, 'ChangeRomeUserString': None, 'CharShape': 'CharShape',
			'CharShapeBold': None, 'CharShapeCenterline': None, 'CharShapeDialog': 'CharShape',
			'CharShapeDialogWithoutBorder': 'CharShape', 'CharShapeEmboss': None, 'CharShapeEngrave': None,
			'CharShapeHeight': None, 'CharShapeHeightDecrease': None, 'CharShapeHeightIncrease': None,
			'CharShapeItalic': None, 'CharShapeLang': None, 'CharShapeNextFaceName': None, 'CharShapeNormal': None,
			'CharShapeOutline': None, 'CharShapePrevFaceName': None, 'CharShapeShadow': None, 'CharShapeSpacing': None,
			'CharShapeSpacingDecrease': None, 'CharShapeSpacingIncrease': None, 'CharShapeSubscript': None,
			'CharShapeSuperscript': None, 'CharShapeSuperSubscript': None, 'CharShapeTextColorBlack': None,
			'CharShapeTextColorBlue': None, 'CharShapeTextColorBluish': None, 'CharShapeTextColorGreen': None,
			'CharShapeTextColorRed': None, 'CharShapeTextColorViolet': None, 'CharShapeTextColorWhite': None,
			'CharShapeTextColorYellow': None, 'CharShapeTypeFace': None, 'CharShapeUnderline': None, 'CharShapeWidth': None,
			'CharShapeWidthDecrease': None, 'CharShapeWidthIncrease': None, 'Close': None, 'CloseEx': None, 'Comment': None,
			'CommentDelete': None, 'CommentModify': None, 'ComposeChars': 'ChCompose', 'ConvertCase': 'ConvertCase',
			'ConvertFullHalfWidth': 'ConvertFullHalf', 'ConvertHiraGata': 'ConvertHiraToGata',
			'ConvertJianFan': 'ConvertJianFan', 'ConvertToHangul': 'ConvertToHangul', 'Copy': None, 'Cut': None,
			'Delete': None, 'DeleteBack': None, 'DeleteCtrls': 'DeleteCtrls', 'DeleteDutmal': None, 'DeleteField': None,
			'DeleteFieldMemo': None, 'DeleteLine': None, 'DeleteLineEnd': None, 'DeleteWord': None, 'DeleteWordBack': None,
			'DocFindEnd': 'FindReplace', 'DocFindInit': 'FindReplace', 'DocFindNext': 'DocFindInfo',
			'DocSummaryInfo': 'SummaryInfo', 'DocumentInfo': 'DocumentInfo', 'DrawObjCancelOneStep': None,
			'DrawObjCreatorArc': 'ShapeObject', 'DrawObjCreatorCanvas': 'ShapeObject', 'DrawObjCreatorCurve': 'ShapeObject',
			'DrawObjCreatorEllipse': 'ShapeObject', 'DrawObjCreatorFreeDrawing': 'ShapeObject',
			'DrawObjCreatorLine': 'ShapeObject', 'DrawObjCreatorMultiArc': 'ShapeObject',
			'DrawObjCreatorMultiCanvas': 'ShapeObject', 'DrawObjCreatorMultiCurve': 'ShapeObject',
			'DrawObjCreatorMultiEllipse': 'ShapeObject', 'DrawObjCreatorMultiFreeDrawing': 'ShapeObject',
			'DrawObjCreatorMultiLine': 'ShapeObject', 'DrawObjCreatorMultiPolygon': 'ShapeObject',
			'DrawObjCreatorMultiRectangle': 'ShapeObject', 'DrawObjCreatorMultiTextBox': 'ShapeObject',
			'DrawObjCreatorObject': 'ShapeObject', 'DrawObjCreatorPolygon': 'ShapeObject',
			'DrawObjCreatorRectangle': 'ShapeObject', 'DrawObjCreatorTextBox': 'ShapeObject', 'DrawObjEditDetail': None,
			'DrawObjOpenClosePolygon': None, 'DrawObjTemplateLoad': 'ShapeObject', 'DrawObjTemplateSave': None,
			'DrawShapeObjShadow': 'ShapeObject', 'DropCap': 'DropCap', 'DutmalChars': 'Dutmal', 'EditFieldMemo': None,
			'EquationCreate': 'EqEdit', 'EquationModify': 'EqEdit', 'EquationPropertyDialog': 'ShapeObject', 'Erase': None,
			'ExchangeFootnoteEndnote': 'ExchangeFootnoteEnd Note', 'ExecReplace': 'FindReplace', 'FileClose': None,
			'FileNew': None, 'FileOpen': None, 'FileOpenMRU': None, 'FilePassword': 'Password', 'FilePreview': None,
			'FileQuit': None, 'FileSave': None, 'FileSaveAs': None, 'FileSetSecurity': 'FileSetSecurity',
			'FileTemplate': 'FileOpen', 'FindAll': 'FindReplace', 'FindDlg': 'FindReplace', 'FindForeBackBookmark': None,
			'FindForeBackCtrl': None, 'FindForeBackFind': None, 'FindForeBackLine': None, 'FindForeBackPage': None,
			'FindForeBackSection': None, 'FindForeBackStyle': None, 'FootnoteOption': 'SecDef',
			'ForwardFind': 'FindReplace', 'FrameStatusBar': None, 'FtpUpload': 'FtpUpload', 'FtpDownload': 'FtpDownload',
			'GetDefaultBullet': 'ParaShape', 'GetDefaultParaNumber': 'ParaShape', 'GetDocFilters': 'DocFilters',
			'GetRomeString': 'ChangeRome', 'GetSectionApplyString': 'SectionApply', 'GetSectionApplyTo': 'SectionApply',
			'GetVersionItemInfo': 'VersionInfo', 'Goto': 'GotoE', 'GotoStyle': 'GotoE', 'HanThDIC': None,
			'HeaderFooter': 'HeaderFooter', 'HeaderFooterDelete': None, 'HeaderFooterInsField': 'HeaderFooter',
			'HeaderFooterModify': None, 'HeaderFooterToNext': None, 'HeaderFooterToPrev': None, 'HiddenCredits': None,
			'HideTitle': None, 'HimConfig': None, 'HimKbdChange': None, 'HwpCtrlEquationCreate97': None,
			'HwpCtrlFileNew': None, 'HwpCtrlFileOpen': None, 'HwpCtrlFileSave': None, 'HwpCtrlFileSaveAs': None,
			'HwpCtrlFileSaveAsAutoBlock': None, 'HwpCtrlFileSaveAutoBlock': None, 'HwpCtrlFindDlg': None,
			'HwpCtrlReplaceDlg': None, 'HwpDic': None, 'Hyperlink': 'HyperLink', 'HyperlinkBackward': None,
			'HyperlinkForward': None, 'HyperlinkJump': 'HyperlinkJump', 'Idiom': 'Idiom', 'ImageFindPath': None,
			'IndexMark': 'IndexMark', 'IndexMarkModify': 'IndexMark', 'InputCodeChange': None,
			'InputCodeTable': 'CodeTable', 'InputDateStyle': 'InputDateStyle', 'InputHanja': None, 'InputHanjaBusu': None,
			'InputHanjaMean': None, 'InsertAutoNum': None, 'InsertCCLMark': 'HyperLink', 'InsertChart': 'OleCreation',
			'InsertConnectLineArcBoth': 'ShapeObject', 'InsertConnectLineArcNoArrow': 'ShapeObject',
			'InsertConnectLineArcOneWay': 'ShapeObject', 'InsertConnectLineMultiArcBoth': 'ShapeObject',
			'InsertConnectLineMultiArcNoArrow': 'ShapeObject', 'InsertConnectLineMultiArcOneWay': 'ShapeObject',
			'InsertConnectLineMultiStraightBoth': 'ShapeObject', 'InsertConnectLineMultiStraightNoArrow': 'ShapeObject',
			'InsertConnectLineMultiStraightOneWay': 'ShapeObject', 'InsertConnectLineMultiStrokeBoth': 'ShapeObject',
			'InsertConnectLineMultiStrokeNoArrow': 'ShapeObject', 'InsertConnectLineMultiStrokeOneWay': 'ShapeObject',
			'InsertConnectLineStraightBoth': 'ShapeObject', 'InsertConnectLineStraightNoArrow': 'ShapeObject',
			'InsertConnectLineStraightOneWay': 'ShapeObject', 'InsertConnectLineStrokeBoth': 'ShapeObject',
			'InsertConnectLineStrokeNoArrow': 'ShapeObject', 'InsertConnectLineStrokeOneWay': 'ShapeObject',
			'InsertCpNo': None, 'InsertCpTpNo': None, 'InsertCrossReference': 'ActionCrossRef', 'InsertDateCode': None,
			'InsertDocInfo': None, 'InsertDocTitle': 'InsertFieldTemplate', 'InsertEndnote': None,
			'InsertFieldDateTime': None, 'InsertFieldFileName': 'InsertFieldTemplate', 'InsertFieldMemo': None,
			'InsertFieldRevisionChagne': None, 'InsertFieldTemplate': 'InsertFieldTemplate', 'InsertFile': 'InsertFile',
			'InsertFileName': 'InsertFieldTemplate', 'InsertFilePath': 'InsertFieldTemplate', 'InsertFixedWidthSpace': None,
			'InsertFootnote': None, 'InsertHyperlink': 'HyperlinkJump', 'InsertIdiom': 'Idiom', 'InsertLastPrintDate': None,
			'InsertLastSaveBy': None, 'InsertLastSaveDate': None, 'InsertLine': None, 'InsertNonBreakingSpace': None,
			'InsertPageNum': None, 'InsertRevision': 'RevisionDef', 'InsertRevisionAttach': 'RevisionDef',
			'InsertRevisionClipping': 'RevisionDef', 'InsertRevisionDelete': 'RevisionDef',
			'InsertRevisionHyperlink': 'HyperLink', 'InsertRevisionInsert': 'RevisionDef',
			'InsertRevisionLeftMove': 'RevisionDef', 'InsertRevisionLine': 'RevisionDef',
			'InsertRevisionLineAttach': 'RevisionDef', 'InsertRevisionLineInsert': 'RevisionDef',
			'InsertRevisionLineLink': 'RevisionDef', 'InsertRevisionLineSeparate': 'RevisionDef',
			'InsertRevisionLineTransfer': 'RevisionDef', 'InsertRevisionLineTransferSplit': 'RevisionDef',
			'InsertRevisionPraise': 'RevisionDef', 'InsertRevisionRightMove': 'RevisionDef',
			'InsertRevisionSawTooth': 'RevisionDef', 'InsertRevisionSimpleChange': 'RevisionDef',
			'InsertRevisionSpace': 'RevisionDef', 'InsertRevisionSymbol': 'RevisionDef',
			'InsertRevisionThinking': 'RevisionDef', 'InsertRevisionTransfer': 'RevisionDef',
			'InsertRevisionTransferSplit': 'RevisionDef', 'InsertSoftHyphen': None, 'InsertSpace': None,
			'InsertStringDateTime': None, 'InsertTab': None, 'InsertText': 'InsertText', 'InsertTpNo': None,
			'InsertUserName': 'InsertFieldTemplate', 'InsertVoice': 'OleCreation', 'Jajun': None, 'LabelAdd': None,
			'LabelTemplate': None, 'LinkDocument': 'LinkDocument', 'LinkTextBox': None, 'MacroDefine': 'KeyMacro',
			'MacroPause': None, 'MacroPlay1': None, 'MacroPlay10': None, 'MacroPlay11': None, 'MacroPlay2': None,
			'MacroPlay3': None, 'MacroPlay4': None, 'MacroPlay5': None, 'MacroPlay6': None, 'MacroPlay7': None,
			'MacroPlay8': None, 'MacroPlay9': None, 'MacroRepeat': None, 'MacroRepeatDlg': 'KeyMacro', 'MacroStop': None,
			'MailMergeField': None, 'MailMergeGenerate': 'MailMergeGenerate', 'MailMergeInsert': 'FieldCtrl',
			'MailMergeModify': 'FieldCtrl', 'MakeAllVersionDiffs': 'VersionInfo', 'MakeContents': 'MakeContents',
			'MakeIndex': None, 'ManualChangeHangul': None, 'ManuScriptTemplate': 'FileOpen', 'MarkPenShape': 'MarkpenShape',
			'MarkTitle': None, 'MasterPage': 'MasterPage', 'MasterPageDelete': 'MasterPage', 'MasterPageDuplicate': None,
			'MasterPageEntry': 'MasterPage', 'MasterPageExcept': None, 'MasterPageFront': None,
			'MasterPagePrevSection': None, 'MasterPageToNext': None, 'MasterPageToPrevious': None,
			'MasterPageTypeDlg': 'MasterPage', 'MemoShape': 'SecDef', 'MessageBox': None, 'ModifyBookmark': 'BookMark',
			'ModifyComposeChars': None, 'ModifyCrossReference': 'ActionCrossRef', 'ModifyCtrl': None, 'ModifyDutmal': None,
			'ModifyFieldClickhere': 'InsertFieldTemplate', 'ModifyFieldDate': 'InsertFieldTemplate',
			'ModifyFieldDateTime': 'InputDateStyle', 'ModifyFieldPath': 'InsertFieldTemplate',
			'ModifyFieldSummary': 'InsertFieldTemplate', 'ModifyFieldUserInfo': 'InsertFieldTemplate',
			'ModifyFillProperty': None, 'ModifyHyperlink': 'HyperLink', 'ModifyLineProperty': None,
			'ModifyRevision': 'RevisionDef', 'ModifyRevisionHyperlink': 'HyperLink', 'ModifySection': 'SecDef',
			'ModifyShapeObject': None, 'MoveColumnBegin': None, 'MoveColumnEnd': None, 'MoveDocBegin': None,
			'MoveDocEnd': None, 'MoveDown': None, 'MoveLeft': None, 'MoveLineBegin': None, 'MoveLineDown': None,
			'MoveLineEnd': None, 'MoveLineUp': None, 'MoveListBegin': None, 'MoveListEnd': None, 'MoveNextChar': None,
			'MoveNextColumn': None, 'MoveNextParaBegin': None, 'MoveNextPos': None, 'MoveNextPosEx': None,
			'MoveNextWord': None, 'MovePageBegin': None, 'MovePageDown': None, 'MovePageEnd': None, 'MovePageUp': None,
			'MoveParaBegin': None, 'MoveParaEnd': None, 'MoveParentList': None, 'MovePrevChar': None,
			'MovePrevColumn': None, 'MovePrevParaBegin': None, 'MovePrevParaEnd': None, 'MovePrevPos': None,
			'MovePrevPosEx': None, 'MovePrevWord': None, 'MoveRight': None, 'MoveRootList': None, 'MoveScrollDown': None,
			'MoveScrollNext': None, 'MoveScrollPrev': None, 'MoveScrollUp': None, 'MoveSectionDown': None,
			'MoveSectionUp': None, 'MoveSelDocBegin': None, 'MoveSelDocEnd': None, 'MoveSelDown': None, 'MoveSelLeft': None,
			'MoveSelLineBegin': None, 'MoveSelLineDown': None, 'MoveSelLineEnd': None, 'MoveSelLineUp': None,
			'MoveSelListBegin': None, 'MoveSelListEnd': None, 'MoveSelNextChar': None, 'MoveSelNextParaBegin': None,
			'MoveSelNextPos': None, 'MoveSelNextWord': None, 'MoveSelPageDown': None, 'MoveSelPageUp': None,
			'MoveSelParaBegin': None, 'MoveSelParaEnd': None, 'MoveSelPrevChar': None, 'MoveSelPrevParaBegin': None,
			'MoveSelPrevParaEnd': None, 'MoveSelPrevPos': None, 'MoveSelPrevWord': None, 'MoveSelRight': None,
			'MoveSelTopLevelBegin': None, 'MoveSelTopLevelEnd': None, 'MoveSelUp': None, 'MoveSelViewDown': None,
			'MoveSelViewUp': None, 'MoveSelWordBegin': None, 'MoveSelWordEnd': None, 'MoveTopLevelBegin': None,
			'MoveTopLevelEnd': None, 'MoveTopLevelList': None, 'MoveUp': None, 'MoveViewBegin': None, 'MoveViewDown': None,
			'MoveViewEnd': None, 'MoveViewUp': None, 'MoveWordBegin': None, 'MoveWordEnd': None, 'MPSectionToNext': None,
			'MPSectionToPrevious': None, 'MultiColumn': 'ColDef', 'NewNumber': 'AutoNum', 'NewNumberModify': 'AutoNum',
			'NextTextBoxLinked': None, 'NoteDelete': None, 'NoteModify': None, 'NoteNumProperty': None, 'NoteToNext': None,
			'NoteToPrev': None, 'OleCreateNew': 'OleCreation', 'OutlineNumber': 'SecDef', 'PageBorder': 'SecDef',
			'PageHiding': 'PageHiding', 'PageHidingModify': 'PageHiding', 'PageNumPos': 'PageNumPos',
			'PageNumPosModify': 'PageNumPos', 'PageSetup': 'SecDef', 'ParagraphShape': 'ParaShape',
			'ParagraphShapeAlignCenter': None, 'ParagraphShapeAlignDistribute': None, 'ParagraphShapeAlignDivision': None,
			'ParagraphShapeAlignJustify': None, 'ParagraphShapeAlignLeft': None, 'ParagraphShapeAlignRight': None,
			'ParagraphShapeDecreaseLeftMargin': None, 'ParagraphShapeDecreaseLineSpacing': None,
			'ParagraphShapeDecreaseMargin': None, 'ParagraphShapeDecreaseRightMargin': None,
			'ParagraphShapeIncreaseLeftMargin': None, 'ParagraphShapeIncreaseLineSpacing': None,
			'ParagraphShapeIncreaseMargin': None, 'ParagraphShapeIncreaseRightMargin': None,
			'ParagraphShapeIndentAtCaret': None, 'ParagraphShapeIndentNegative': None, 'ParagraphShapeIndentPositive': None,
			'ParagraphShapeProtect': None, 'ParagraphShapeWithNext': None, 'ParaNumberBullet': 'ParaShape',
			'ParaNumberBulletLevelDown': 'ParaShape', 'ParaNumberBulletLevelUp': 'ParaShape',
			'ParaShapeDialog': 'ParaShape', 'Paste': None, 'PasteSpecial': None, 'PictureEffect1': None,
			'PictureEffect2': None, 'PictureEffect3': None, 'PictureEffect4': None, 'PictureEffect5': None,
			'PictureEffect6': None, 'PictureEffect7': None, 'PictureEffect8': None, 'PictureInsertDialog': None,
			'PictureLinkedToEmbedded': None, 'PictureSave': None, 'PictureScissor': None, 'PictureToOriginal': None,
			'Preference': 'Preference', 'Presentation': 'Presentation', 'PresentationSetup': 'Presentation',
			'PrevTextBoxLinked': None, 'Print': 'Print', 'PrintToImage': 'PrintToImage', 'PutBullet': 'ParaShape',
			'PutNewParaNumber': 'ParaShape', 'PutOutlineNumber': 'ParaShape', 'PutParaNumber': 'ParaShape',
			'QuickCommandRun': None, 'QuickCorrect': None, 'QuickCorrectEdit': 'QCorrect', 'QuickCorrectRun': None,
			'QuickCorrectSound': None, 'QuickMarkInsert0': None, 'QuickMarkInsert1': None, 'QuickMarkInsert2': None,
			'QuickMarkInsert3': None, 'QuickMarkInsert4': None, 'QuickMarkInsert5': None, 'QuickMarkInsert6': None,
			'QuickMarkInsert7': None, 'QuickMarkInsert8': None, 'QuickMarkInsert9': None, 'QuickMarkMove0': None,
			'QuickMarkMove1': None, 'QuickMarkMove2': None, 'QuickMarkMove3': None, 'QuickMarkMove4': None,
			'QuickMarkMove5': None, 'QuickMarkMove6': None, 'QuickMarkMove7': None, 'QuickMarkMove8': None,
			'QuickMarkMove9': None, 'RecalcPageCount': None, 'RecentCode': None, 'Redo': None, 'RepeatFind': 'FindReplace',
			'ReplaceDlg': 'FindReplace', 'ReturnKeyInField': None, 'ReturnPrevPos': None, 'ReverseFind': 'FindReplace',
			'SaveBlockAction': 'FileSaveBlock', 'SaveFootnote': 'SaveFootnote', 'SaveHistoryItem': 'VersionInfo',
			'ScrMacroDefine': 'ScriptMacro', 'ScrMacroPause': None, 'ScrMacroPlay1': None, 'ScrMacroPlay2': None,
			'ScrMacroPlay3': None, 'ScrMacroPlay4': None, 'ScrMacroPlay5': None, 'ScrMacroPlay6': None,
			'ScrMacroPlay7': None, 'ScrMacroPlay8': None, 'ScrMacroPlay9': None, 'ScrMacroPlay10': None,
			'ScrMacroPlay11': None, 'ScrMacroRepeatDlg': 'ScriptMacro', 'ScrMacroSecurityDlg': None, 'ScrMacroStop': None,
			'SearchAddress': None, 'SearchForeign': None, 'Select': None, 'SelectAll': None, 'SelectColumn': None,
			'SelectCtrlFront': None, 'SelectCtrlReverse': None, 'SendBrowserText': None, 'SendMailAttach': 'FileSendMail',
			'SendMailText': 'FileSendMail', 'ShapeCopyPaste': 'ShapeCopyPaste', 'ShapeObjAlignBottom': None,
			'ShapeObjAlignCenter': None, 'ShapeObjAlignHeight': None, 'ShapeObjAlignHorzSpacing': None,
			'ShapeObjAlignLeft': None, 'ShapeObjAlignMiddle': None, 'ShapeObjAlignRight': None, 'ShapeObjAlignSize': None,
			'ShapeObjAlignTop': None, 'ShapeObjAlignVertSpacing': None, 'ShapeObjAlignWidth': None,
			'ShapeObjAttachCaption': None, 'ShapeObjAttachTextBox': None, 'ShapeObjAttrDialog': 'ShapeObject',
			'ShapeObjBringForward': None, 'ShapeObjBringInFrontOfText': None, 'ShapeObjBringToFront': None,
			'ShapeObjCtrlSendBehindText': None, 'ShapeObjDetachCaption': None, 'ShapeObjDetachTextBox': None,
			'ShapeObjDialog': 'ShapeObject', 'ShapeObjectCopy': 'ShapeObjectCopyPaste',
			'ShapeObjectPaste': 'ShapeObjectCopyPaste', 'ShapeObjFillProperty': None, 'ShapeObjGroup': None,
			'ShapeObjHorzFlip': None, 'ShapeObjHorzFlipOrgState': None, 'ShapeObjInsertCaptionNum': None,
			'ShapeObjLineProperty': None, 'ShapeObjLock': None, 'ShapeObjMoveDown': None, 'ShapeObjMoveLeft': None,
			'ShapeObjMoveRight': None, 'ShapeObjMoveUp': None, 'ShapeObjNextObject': None, 'ShapeObjNorm': None,
			'ShapeObjPrevObject': None, 'ShapeObjRandomAngleRotater': 'ShapeObject', 'ShapeObjResizeDown': None,
			'ShapeObjResizeLeft': None, 'ShapeObjResizeRight': None, 'ShapeObjResizeUp': None,
			'ShapeObjRightAngleRotater': None, 'ShapeObjRightAngleRotaterAnticlockwise': None, 'ShapeObjRotater': None,
			'ShapeObjSaveAsPicture': None, 'ShapeObjSelect': None, 'ShapeObjSendBack': None, 'ShapeObjSendToBack': None,
			'ShapeObjShadowEnlarge': None, 'ShapeObjShadowMoveDown': None, 'ShapeObjShadowMoveLeft': None,
			'ShapeObjShadowMoveRight': None, 'ShapeObjShadowMoveUp': None, 'ShapeObjShadowNarrow': None,
			'ShapeObjShadowParellelLeftBottom': None, 'ShapeObjShadowParellelLeftTop': None,
			'ShapeObjShadowParellelRightBottom': None, 'ShapeObjShadowParellelRightTop': None,
			'ShapeObjShadowShearLeftBottom': None, 'ShapeObjShadowShearLeftTop': None,
			'ShapeObjShadowShearRightBottom': None, 'ShapeObjShadowShearRightTop': None, 'ShapeObjShear': 'ShapeObject',
			'ShapeObjTableSelCell': None, 'ShapeObjTextBoxEdit': None, 'ShapeObjUngroup': None, 'ShapeObjUnlockAll': None,
			'ShapeObjVertFlip': None, 'ShapeObjVertFlipOrgState': None, 'ShapeObjWrapSquare': None,
			'ShapeObjWrapTopAndBottom': None, 'SoftKeyboard': None, 'Sort': 'Sort', 'SpellingCheck': None,
			'SplitMemoOpen': None, 'Style': 'Style', 'StyleAdd': 'Style', 'StyleClearCharStyle': None,
			'StyleDelete': 'StyleDelete', 'StyleEdit': 'Style', 'StyleEx': 'Style', 'StyleParaNumberBullet': 'ParaShape',
			'StyleShortcut1': None, 'StyleShortcut10': None, 'StyleShortcut2': None, 'StyleShortcut3': None,
			'StyleShortcut4': None, 'StyleShortcut5': None, 'StyleShortcut6': None, 'StyleShortcut7': None,
			'StyleShortcut8': None, 'StyleShortcut9': None, 'StyleTemplate': 'StyleTemplate', 'Sum': 'Sum',
			'TableAppendRow': None, 'TableAutoDrawPenStyleWidthDlg': 'TableDrawPen', 'TableAutoFill': 'AutoFill',
			'TableAutoFillDlg': 'AutoFill', 'TableCellBlock': None, 'TableCellBlockCol': None, 'TableCellBlockExtend': None,
			'TableCellBlockExtendAbs': None, 'TableCellBlockRow': None, 'TableCellBorderAll': None,
			'TableCellBorderBottom': None, 'TableCellBorderDiagonalDown': None, 'TableCellBorderDiagonalUp': None,
			'TableCellBorderInside': None, 'TableCellBorderInsideHorz': None, 'TableCellBorderInsideVert': None,
			'TableCellBorderLeft': None, 'TableCellBorderNo': None, 'TableCellBorderOutside': None,
			'TableCellBorderRight': None, 'TableCellBorderTop': None, 'TableCellShadeDec': 'CellBorderFill',
			'TableCellShadeInc': 'CellBorderFill', 'TableColBegin': None, 'TableColEnd': None, 'TableColPageDown': None,
			'TableColPageUp': None, 'TableCreate': 'TableCreation', 'TableDeleteCell': None,
			'TableDeleteColumn': 'TableDeleteLine', 'TableDeleteRow': 'TableDeleteLine',
			'TableDeleteRowColumn': 'TableDeleteLine', 'TableDistributeCellHeight': None, 'TableDistributeCellWidth': None,
			'TableDrawPen': None, 'TableEraser': None, 'TableFormula': 'FieldCtrl', 'TableFormulaAvgAuto': None,
			'TableFormulaAvgHor': None, 'TableFormulaAvgVer': None, 'TableFormulaProAuto': None, 'TableFormulaProHor': None,
			'TableFormulaProVer': None, 'TableFormulaSumAuto': None, 'TableFormulaSumHor': None, 'TableFormulaSumVer': None,
			'TableInsertLeftColumn': 'TableInsertLine', 'TableInsertLowerRow': 'TableInsertLine',
			'TableInsertRightColumn': 'TableInsertLine', 'TableInsertRowColumn': 'TableInsertLine',
			'TableInsertUpperRow': 'TableInsertLine', 'TableLeftCell': None, 'TableLowerCell': None, 'TableMergeCell': None,
			'TableMergeTable': None, 'TablePropertyDialog': 'ShapeObject', 'TableResizeCellDown': None,
			'TableResizeCellLeft': None, 'TableResizeCellRight': None, 'TableResizeCellUp': None, 'TableResizeDown': None,
			'TableResizeExDown': None, 'TableResizeExLeft': None, 'TableResizeExRight': None, 'TableResizeExUp': None,
			'TableResizeLeft': None, 'TableResizeLineDown': None, 'TableResizeLineLeft': None, 'TableResizeLineRight': None,
			'TableResizeLineUp': None, 'TableResizeRight': None, 'TableResizeUp': None, 'TableRightCell': None,
			'TableRightCellAppend': None, 'TableSplitCell': 'TableSplitCell', 'TableSplitCellCol2': 'TableSplitCell',
			'TableSplitCellRow2': 'TableSplitCell', 'TableSplitTable': None, 'TableStringToTable': 'TableStrToTbl',
			'TableSubtractRow': 'TableDeleteLine', 'TableSwap': 'TableSwap', 'TableTableToString': 'TableTblToStr',
			'TableTemplate': 'TableTemplate', 'TableUpperCell': None, 'TableVAlignBottom': None, 'TableVAlignCenter': None,
			'TableVAlignTop': None, 'TextArtCreate': None, 'TextArtModify': None, 'TextArtShadow': None,
			'ToggleOverwrite': None, 'Undo': None, 'UnlinkTextBox': None, 'UserAutoFill': 'AutoFill',
			'VersionDelete': 'VersionInfo', 'VersionDeleteAll': None, 'VersionInfo': 'VersionInfo',
			'VersionSave': 'VersionInfo', 'VerticalText': 'TextVertical', 'ViewGridOption': 'GridInfo', 'ViewIdiom': None,
			'ViewOptionCtrlMark': None, 'ViewOptionGuideLine': None, 'ViewOptionMemo': None,
			'ViewOptionMemoGuideline': None, 'ViewOptionPaper': None, 'ViewOptionParaMark': None, 'ViewOptionPicture': None,
			'ViewOptionRevision': None, 'ViewShowGrid': 'GridInfo', 'ViewZoom': 'ViewProperties',
			'ViewZoomFitPage': 'ViewProperties', 'ViewZoomFitWidth': 'ViewProperties', 'ViewZoomNormal': 'ViewProperties',
			'VoiceCommand': None, 'VoiceCommandConfig': None, 'VoiceCommandResume': None, 'VoiceCommandStop': None,
			'VoiceCommandView': None}

		self.varx["parameter_set_id_vs_parameters"] = {
			'AutoFill': ['AutoFillSection', 'AutoFillItem'],
			'AutoNum': ['NumType', 'NewNumber'],
			'BookMark': ['Name', 'Type', 'Command'],
			'BorderFill': ['BorderTypeLeft', 'BorderTypeRight', 'BorderTypeTop', 'BorderTypeBottom', 'BorderWidthLeft',
						   'BorderWidthRight', 'BorderWidthTop', 'BorderWidthBottom',
						   'BorderCorlorLeft', 'BorderColorRight', 'BorderColorTop', 'BorderColorBottom', 'SlashFlag',
						   'BackSlashFlag', 'DiagonalType', 'DiagonalWidth', 'DiagonalColor',
						   'BorderFill3D', 'Shadow', 'FillAttr', 'CrookedSlashFlag', 'BreakCellSeparateLine',
						   'CounterSlashFlag', 'CounterBackSlashFlag', 'CenterLineFlag',
						   'CrookedSlashFlag1', 'CrookedSlashFlag2'],
			'BorderFillExt': ['TypeHorz', 'TypeVert', 'WidthHorz', 'WidthVert', 'ColorHorz', 'ColorVert', 'HasCharShape'],
			'BulletShape': ['CharShape', 'WidthAdjust', 'TextOffset', 'Alignment', 'UseInstWidth', 'AutoIndent',
							'TextOffsetType', 'BulletChar', 'HasImage', 'BulletImage'],
			'Caption': ['Side', 'Width', 'Gap', 'CapFullSize'],
			'CaptureEnd': ['BeginX', 'BeginY', 'EndX', 'EndY', 'PageNum'],
			'Cell': ['HasMargin', 'Protected', 'Header', 'Width', 'Height', 'Editable', 'Dirty', 'CellCtrlData'],
			'CellBorderFill': ['ApplyTo', 'NoNeighborCell', 'TableBorderFill', 'AllCellsBorderFill', 'SelCellsBorderFill'],
			'ChangeRome': ['Option', 'HanString'],
			'CharShape': ['FaceNameHangul', 'FaceNameLatin', 'FaceNameHanja', 'FaceNameJapanese', 'FaceNameOther',
						  'FaceNameSymbol', 'FaceNameUser', 'FontTypeHangul', 'FontTypeLatin',
						  'FontTypeHanja', 'FontTypeJapanese', 'FontTypeOther', 'FontTypeSymbol', 'FontTypeUser',
						  'SizeHangul', 'SizeLatin', 'SizeHanja', 'SizeJapanese', 'SizeOther',
						  'SizeSymbol', 'SizeUser', 'RatioHangul', 'RatioLatin', 'RatioHanja', 'RatioJapanese',
						  'RatioOther', 'RatioSymbol', 'RatioUser', 'SpacingHangul', 'SpacingLatin',
						  'SpacingHanja', 'SpacingJapanese', 'SpacingOther', 'SpacingSymbol', 'SpacingUser', 'OffsetHangul',
						  'OffsetLatin', 'OffsetHanja', 'OffsetJapanese', 'OffsetOther',
						  'OffsetSymbol', 'OffsetUser', 'Bold', 'Italic', 'SmallCaps', 'Emboss', 'Engrave', 'SuperScript',
						  'SubScript', 'UnderlineType', 'OutlineType', 'ShadowType',
						  'TextColor', 'ShadeColor', 'UnderlineShape', 'UnderlineColor', 'ShadowOffsetX', 'ShadowOffsetY',
						  'ShadowColor', 'StrikeOutType', 'DiacSymMark', 'UseFontSpace',
						  'UseKerning', 'Height', 'BorderFill'],
			'ChCompose': ['Chars'],
			'CodeTable': ['Text'],
			'ColDef': ['Type', 'Count', 'SameSize', 'SameGap', 'WidthGap', 'Layout', 'LineType', 'LineWidth', 'LineColor',
					   'ApplyTo', 'ApplyClass'],
			'ConvertCase': ['Type'],
			'ConvertFullHalf': ['Type', 'Number', 'Alpha', 'Symbol', 'Gata', 'HGJamo'],
			'ConvertHiraToGata': ['Type'],
			'ConvertJianFan': ['Type'],
			'ConvertToHangul': ['Type', 'Hanja', 'Hira', 'Gata', 'Gu'],
			'CtrlData': ['Name'],
			'DeleteCtrls': ['DeleteCtrlType'],
			'DocFilters': ['DocFilters', 'Format', 'Type'],
			'DocFindInfo': ['ListID', 'ParaID', 'Pos'],
			'DocumentInfo': ['CurPara', 'CurPos', 'CurParaLen', 'CurCtrl', 'CurParaCount', 'RootPara', 'RootPos',
							 'RootParaCout', 'DetailInfo', 'DetailCharCount', 'DetailWordCount',
							 'DetailLineCount', 'DetailPageCount', 'DetailCurPage', 'DetailCurPrtPage', 'SectionInfo',
							 'SecDef'],
			'DrawArcType': ['Type', 'Interval'],
			'DrawCoordInfo': ['Count', 'Point', 'Line'],
			'DrawCtrlHyperlink': ['Command'],
			'DrawEditDetail': ['Command', 'Index', 'PointX', 'PointY'],
			'DrawFillAttr': ['Type', 'GradationType', 'GradationAngle', 'GradationCenterX', 'GradationCenterY',
							 'GradationStep', 'GradationColorNum', 'GradationColor', 'GradationIndexPos',
							 'GradationStepCenter', 'GradationAlpha', 'WinBrushFaceColor', 'WinBrushHatchColor',
							 'WinBrushAlpha', 'FileName', 'Embedded', 'PicEffect', 'Brightness',
							 'Contrast', 'Reverse', 'DrawFillImageType', 'SkipLeft', 'SkipRight', 'SkipTop', 'SkipBottom',
							 'OriginalSizeX', 'OriginalSizeY', 'InsideMarginLeft',
							 'InsideMarginRight', 'InsideMarginTop', 'InsideMarginBottom', 'WindowsBrush', 'GradationBrush',
							 'ImageBrush', 'ImageCreateOnDrag', 'ImageAlpha'],
			'DrawImageAttr': ['FileName', 'Embedded', 'PicEffect', 'Brightness', 'Contrast', 'Reverse', 'DrawFillImageType',
							  'SkipLeft', 'SkipRight', 'SkipTop', 'SkipBottom',
							  'OriginalSizeX', 'OriginalSizeY', 'InsideMarginLeft', 'InsideMarginRight', 'InsideMarginTop',
							  'InsideMarginBotto m', 'WindowsBrush', 'GradationBrush',
							  'ImageBrush', 'ImageCreateOnDrag'],
			'DrawImageScissoring': ['Xoffset', 'Yoffset', 'HandleIndex'],
			'DrawLayOut': ['CreateNumPt', 'CreatePt', 'CurveSegmentInfo'],
			'DrawLineAttr': ['Color', 'Style', 'Width', 'EndCap', 'HeadStyle', 'TailStyle', 'HeadSize', 'TailSize',
							 'HeadFill', 'TailFill', 'OutLineStyle', 'Alpha'],
			'DrawRectType': ['Type'],
			'DrawResize': ['Xoffset', 'Yoffset', 'HandleIndex', 'Mode'],
			'DrawRotate': ['Command', 'CenterX', 'CenterY', 'ObjectCenterX', 'ObjectCenterY', 'Angle', 'RotateImage'],
			'DrawScAction': ['RotateCenterX', 'RotateCenterY', 'RotateAngel', 'HorzFlip', 'VertFlip'],
			'DrawShadow': ['ShadowType', 'ShadowColor', 'ShadowOffsetX', 'ShadowOffsetY', 'ShadowAlpha'],
			'DrawShear': ['XFactor', 'YFactor'],
			'DrawTextart': ['String', 'FontName', 'FontStyle', 'FontType', 'LineSpacing', 'CharSpacing', 'AlignType',
							'Shape', 'ShadowType', 'ShadowOffsetX', 'ShadowOffsetY', 'ShadowColor', 'NumberOfLines'],
			'DropCap': ['Style', 'FaceName', 'LineStyle', 'LineWeight', 'LineColor', 'FaceColor', 'Spacing'],
			'Dutmal': ['ResultText', 'SubText', 'PosType', 'FsizeRatio', 'Option', 'StyleNo', 'Align', 'Delete', 'Modify'],
			'EngineProperties': ['DoAnyCursorEdit', 'DoOutLineStyle', 'InsertLock', 'TabMoveCell', 'FaxDriver', 'PDFDriver',
								 'EnableAutoSpell'],
			'EqEdit': ['String', 'BaseUnit', 'Color', 'LineMode', 'Version', 'ApplyTo'],
			'ExchangeFootnoteEndNote': ['Flag'],
			'FieldCtrl': ['Command', 'Editable', 'FieldDirty', 'CtrlData'],
			'FileConvert': ['Format', 'SrcFileList', 'DestFileList'],
			'FileInfo': ['Format', 'VersionStr', 'VersionNum', 'Encrypted'],
			'FileOpen': ['OpenFileName', 'SaveFileName', 'OpenFormat', 'SaveFormat', 'OpenReadOnly', 'OpenFlag',
						 'SaveOverWrite', 'ModifiedFlag', 'Argument', 'SaveCMFDoc30',
						 'SaveHwp97', 'SaveDistribute', 'SaveDRMDoc'],
			'FileSaveAs': ['OpenFileName', 'SaveFileName', 'OpenFormat', 'SaveFormat', 'OpenReadOnly', 'OpenFlag',
						   'SaveOverWrite', 'ModifiedFlag', 'Argument', 'SaveCMFDoc30',
						   'SaveHwp97', 'SaveDistribute', 'SaveDRMDoc'],
			'FileSaveBlock': ['FileName', 'Format', 'Argument'],
			'FileSendMail': ['To', 'Type', 'Subject', 'Filepath'],
			'FileSetSecurity': ['Password', 'NoPrint', 'NoCopy'],
			'FindReplace': ['FindString', 'ReplaceString', 'Direction', 'MatchCase', 'AllWordForms', 'SeveralWords',
							'UseWildCards', 'WholeWordOnly', 'AutoSpell', 'ReplaceMode',
							'IgnoreFindString', 'IgnoreReplaceStrin g', 'FindCharShape', 'FindParaShape',
							'ReplaceCharShape', 'ReplaceParaShape', 'FindStyle', 'ReplaceStyle',
							'IgnoreMessage', 'HanjaFromHangul', 'FindJaso', 'FindRegExp', 'FindType'],
			'FlashProperties': ['Base', 'Qulaity', 'Scale', 'WMode', 'AutoPlay', 'LoopPlay', 'ShowMenu', 'BgColor'],
			'FootnoteShape': ['NumberFormat', 'UserChar', 'PrefixChar', 'Suffix', 'PlaceAt', 'Restart', 'NewNumber',
							  'LineLength', 'LineType', 'LineWidth',
							  'SpaceAboveLine', 'SpaceBelowLine', 'SpaceBetweenNotes', 'SuperScript', 'BeneathText',
							  'ApplyTo', 'ApplyClass'],
			'EndnoteShape': ['NumberFormat', 'UserChar', 'PrefixChar', 'Suffix', 'PlaceAt', 'Restart', 'NewNumber',
							 'LineLength', 'LineType', 'LineWidth',
							 'SpaceAboveLine', 'SpaceBelowLine', 'SpaceBetweenNotes', 'SuperScript', 'BeneathText',
							 'ApplyTo', 'ApplyClass'],
			'FtpUpload': ['Server', 'UserName', 'Password', 'Directory', 'FileName', 'SiteName', 'SaveType'],
			'FtpDownload': ['Server', 'UserName', 'Password', 'Directory', 'FileName', 'SaveType'],
			'GotoE': ['SetSelectionIndex', 'DialogResult'],
			'GridInfo': ['Method', 'Align', 'HorzAlign', 'VertAlign', 'Type', 'HorzSpan', 'VertSpan', 'HorzRange',
						 'VertRange', 'Show', 'ZOrder', 'ViewLine'],
			'HeaderFooter': ['DialogOption', 'DialogResult', 'CtrlType', 'Type', 'HeaderFooterCtrlType',
							 'HeaderFooterStyle', 'Type'],
			'HyperLink': ['Text', 'Command', 'NoLInk', 'ShapeObject', 'DirectInsert'],
			'HyperlinkJump': ['Source', 'Target'],
			'Idiom': ['InputText', 'InputType'],
			'IndexMark': ['First', 'Second'],
			'InputDateStyle': ['DateStyleType', 'DateStyleDataForm'],
			'InsertFieldTemplate': ['ShowSingle', 'TemplateDirection', 'TemplateHelp', 'TemplateName', 'TemplateType',
									'Editable'],
			'InsertFile': ['FileName', 'FileFormat', 'FileArg', 'KeepSection', 'KeepCharshape', 'KeepParashape',
						   'KeepStyle'],
			'InsertText': ['Text'],
			'Internet': ['OpenUrlWhere', 'OpenUrlString'],
			'KeyMacro': ['Index', 'RepeatCount', 'Name'],
			'LinkDocument': ['Name', 'PageInherit', 'FootnoteInherit'],
			'ListParaPos': ['List', 'Para', 'Pos'],
			'ListProperties': ['TextDirection', 'LineWrap', 'VertAlign', 'MarginLeft', 'MarginRight', 'MarginTop',
							   'MarginBottom'],
			'MailMergeGenerate': ['Input', 'HwpPath', 'HwpId', 'DbfPath', 'DbfCode', 'Output', 'FileName', 'Continue',
								  'PrintSet', 'Subject', 'Type', 'Field', 'FieldUpdate', 'NxlPath'],
			'MakeContents': ['Make', 'Level', 'AutoTabRight', 'Leader', 'OutlineNumber', 'Styles', 'StyleName',
							 'OutFileName', 'Position'],
			'MarkpenShape': ['Color'],
			'MasterPage': ['Type', 'Duplicate', 'Front', 'ApplyTo'],
			'MemoShape': ['Width', 'LineType', 'LineWidth', 'LineColor', 'FillColor', 'ActiveFillColor', 'MemoType'],
			'MousePos': ['XRelTo', 'YRelTo', 'Page', 'X', 'Y'],
			'MovieProperties': ['Base', 'Caption', 'AutoPlay', 'AutoRewind', 'ShowMenu', 'ShowCtrlPanel', 'ShowPosCtrl',
								'EnablePos', 'ShowTrackBar', 'EnableTrack', 'ShowChaption', 'ShowAudio', 'ShowStatus'],

			'NumberingShape': ['HasCharShapeLevel0', 'HasCharShapeLevel1', 'HasCharShapeLevel2', 'HasCharShapeLevel3',
							   'HasCharShapeLevel4', 'HasCharShapeLevel5', 'HasCharShapeLevel6',
							   'CharShapeLevel0', 'CharShapeLevel1', 'CharShapeLevel2', 'CharShapeLevel3',
							   'CharShapeLevel4', 'CharShapeLevel5', 'CharShapeLevel6',
							   'WidthAdjustLevel0', 'WidthAdjustLevel1', 'WidthAdjustLevel2', 'WidthAdjustLevel3',
							   'WidthAdjustLevel4', 'WidthAdjustLevel5', 'WidthAdjustLevel6',
							   'TextOffsetLevel0', 'TextOffsetLevel1', 'TextOffsetLevel2', 'TextOffsetLevel3',
							   'TextOffsetLevel4', 'TextOffsetLevel5', 'TextOffsetLevel6',
							   'AlignmentLevel0', 'AlignmentLevel1', 'AlignmentLevel2', 'AlignmentLevel3',
							   'AlignmentLevel4', 'AlignmentLevel5', 'AlignmentLevel6',
							   'UseInstWidthLevel0', 'UseInstWidthLevel1', 'UseInstWidthLevel2', 'UseInstWidthLevel3',
							   'UseInstWidthLevel4', 'UseInstWidthLevel5', 'UseInstWidthLevel6',
							   'AutoIndentLevel0', 'AutoIndentLevel1', 'AutoIndentLevel2', 'AutoIndentLevel3',
							   'AutoIndentLevel4', 'AutoIndentLevel5', 'AutoIndentLevel6',
							   'TextOffsetTypeLevel0', 'TextOffsetTypeLevel1', 'TextOffsetTypeLevel2',
							   'TextOffsetTypeLevel3', 'TextOffsetTypeLevel4', 'TextOffsetTypeLevel5',
							   'TextOffsetTypeLevel6',
							   'StrFormatLevel0', 'StrFormatLevel1', 'StrFormatLevel2', 'StrFormatLevel3',
							   'StrFormatLevel4', 'StrFormatLevel5', 'StrFormatLevel6',
							   'NumFormatLevel0', 'NumFormatLevel1', 'NumFormatLevel2', 'NumFormatLevel3',
							   'NumFormatLevel4', 'NumFormatLevel5', 'NumFormatLevel6',
							   'StartNumber', 'NewList'],

			'OleCreation': ['Type', 'Clsid', 'Path', 'Aspect', 'IconMetafile', 'IconMM', 'IconXext', 'IconYext', 'InnerOCX',
							'SoProperties', 'FlashProperties', 'MovieProperties'],
			'PageBorderFill': ['TextBorder', 'HeaderInside', 'FooterInside', 'FillArea', 'OffsetLeft', 'OffsetRight',
							   'OffsetTop', 'OffsetBottom'],
			'PageDef': ['PaperWidth', 'PaperHeight', 'Landscape', 'LeftMargin', 'RightMargin', 'TopMargin', 'BottomMargin',
						'HeaderLen', 'FooterLen', 'GutterLen', 'GutterType', 'ApplyTo', 'ApplyClass'],
			'PageHiding': ['Fields'],
			'PageNumCtrl': ['PageStartsOn'],
			'PageNumPos': ['NumberFormat', 'UserChar', 'PrefixChar', 'SuffixChar', 'SideChar', 'DrawPos'],
			'ParaShape': ['LeftMargin', 'RightMargin', 'Indentation', 'PrevSpacing', 'NextSpacing', 'LineSpacingType',
						  'LineSpacing', 'AlignType', 'BreakLatinWord', 'BreakNonLatinWord',
						  'SnapToGrid', 'Condense', 'WidowOrphan', 'KeepWithNext', 'KeepLinesTogether', 'PagebreakBefore',
						  'TextAlignment', 'FontLineHeight', 'HeadingType', 'Level',
						  'BorderConnect', 'BorderText', 'BorderOffsetLeft', 'BorderOffsetRight', 'BorderOffsetTop',
						  'BorderOffsetBottom', 'TailType', 'LineWrap', 'TabDef', 'Numbering',
						  'Bullet', 'BorderFill'],
			'Password': ['DialogResult', 'String', 'FullRange', 'Ask', 'String', 'FullRange', 'Ask', 'Level'],
			'Preference': ['ShowSinglePage', 'ApplyLinkAttr', 'ApplyForbidden', 'StartForbiddenStr', 'EndForbiddenStr'],
			'Presentation': ['DialogResult', 'Effect', 'Sound', 'InvertText', 'ShowMode', 'ShowPage', 'ShowTime'],
			'Print': ['DialogOption', 'DialogResult', 'Range', 'RangeCustom', 'RangeIncludeLinkedDoc', 'NumCopy', 'Collate',
					  'PrintMethod', 'PrinterPaperSize', 'PrinterPaperWidth',
					  'PrinterPaperLength', 'PrintAutoHeadNote', 'PrintAutoFootNote', 'PrintAutoHeadnoteLtext',
					  'PrintAutoHeadnoteCtext', 'PrintAutoHeadnoteRtext', 'PrintAutoFootnoteLtext',
					  'PrintAutoFootnoteCtext', 'PrintAutoFootnoteRtext', 'PrinterName', 'PrintToFile', 'FileName',
					  'ReverseOrder', 'Pause', 'PrintImage', 'PrintDrawObj', 'PrintClickHere',
					  'PrintCropMark', 'IdcPrintWallPaper', 'LastBlankPage', 'BinderHoleType', 'EvenOddPageType', 'ZoomX',
					  'ZoomY', 'StartPageNum', 'StartFootNoteNum', 'Flags', 'Device',
					  'PrintFormObj', 'PrintMarkPen', 'PrintMemo', 'PrintMemoContents', 'PrintRevision', 'PrintWatermark'],
			'PrintToImage': ['Format', 'FileName', 'ColorDepth', 'Resolution'],
			'PrintWatermark': ['WatermarkType', 'PosPage', 'TextWrap', 'AlphaText', 'AlphaImage', 'FileName', 'PicEffect',
							   'Brightness', 'Contrast', 'DrawFillImageType', 'String', 'FontName',
							   'FontType', 'FontSize', 'ShadowType', 'ShadowOffsetX', 'ShadowOffsetY', 'ShadowColor',
							   'FontColor', 'RotateAngle', 'WaterMarkEff'],
			'QCorrect': ['LauncherKey', 'HyperLinkRunKey'],
			'RevisionDef': ['SignType', 'SubText', 'Margin', 'BeginPos'],
			'SaveFootnote': ['FileName', 'Flag'],
			'ScriptMacro': ['Index', 'RepeatCount', 'Name', 'Detail'],
			'SecDef': ['TextDirection', 'StartsOn', 'LineGrid', 'CharGrid', 'PageDef', 'HideEmptyLine',
					   'SpaceBetweenColumns', 'TabStop', 'FootnoteShape', 'EndnoteShape', 'HideHeader',
					   'HideFooter', 'HideMasterPage', 'HideBorder', 'HideFill', 'HidePageNumPos', 'FirstBorder',
					   'FirstFill', 'OutlineShape', 'PageBorderFillBoth', 'PageBorderFillEven',
					   'PageBorderFillOdd', 'PageNumber', 'FigureNumber', 'TableNumber', 'EquationNumber', 'WongojiFormat',
					   'MemoShape', 'TextVerticalWidthHead', 'ApplyTo', 'ApplyClass', 'ApplyToPageBorderFill'],
			'SectionApply': ['ApplyTo', 'String', 'Index', 'ConvAplly2Index', 'Category'],
			'ShapeCopyPaste': ['Type', 'CellAttr', 'CellBorder', 'CellFill', 'TypeBodyAndCellOnly'],
			'ShapeObject': ['TreatAsChar', 'AffectsLine', 'VertRelTo', 'VertAlign', 'VertOffset', 'HorzRelTo', 'HorzAlign',
							'HorzOffset', 'FlowWithText', 'AllowOverlap', 'WidthRelTo',
							'Width', 'HeightRelTo', 'Height', 'ProtectSize', 'TextWrap', 'TextFlow', 'OutsideMarginLeft',
							'OutsideMarginRight', 'OutsideMarginTop', 'OutsideMarginBottom',
							'NumberingType', 'LayoutWidth', 'LayoutHeight', 'Lock', 'HoldAnchorObj', 'PageNumber',
							'AdjustSelection', 'AdjustTextBox', 'AdjustPrevObjAttr', 'ShapeDrawLayOut',
							'ShapeDrawLineAttr', 'ShapeDrawFillAttr', 'ShapeDrawImageAttr', 'ShapeDrawRectType',
							'ShapeDrawArcType', 'ShapeDrawResize', 'ShapeDrawRotate', 'ShapeDrawEditDetail',
							'ShapeDrawImageScissoring', 'ShapeDrawScAction', 'ShapeDrawCtrlHyperlink', 'ShapeDrawCoordInfo',
							'ShapeDrawShear', 'ShapeDrawTextart', 'ShapeDrawShadow',
							'ShapeTableCell', 'ShapeListProperties', 'ShapeCaption', 'ShapeFormGeneral',
							'ShapeFormCommonAttr', 'ShapeFormCharshapeattr', 'ShapeFormButtonAttr', 'ShapeFormComboboxAttr',
							'ShapeFormEditAttr', 'ShapeFormScrollbarAttr', 'ShapeFormListBoxAttr', 'ShapeType',
							'ShapeCellSize', 'ShapeCreationType', 'ShapeCreationMode'],
			'ShapeObjectCopyPaste': ['Type', 'ShapeObjectLine', 'ShapeObjectFill', 'ShapeObjectSize', 'ShapeObjectShadow',
									 'ShapeObjectPicEffect'],
			'Sort': ['KeyOption', 'CheckJasoReverse', 'DelimiterType', 'DelimiterChars', 'IgnoreMultiDelimiter',
					 'CheckFromRear', 'CheckExtendYear', 'YearBase', 'LangOrderType', 'CheckJaso'],
			'Style': ['Apply'],
			'StyleDelete': ['Target', 'Alternation'],
			'StyleTemplate': ['FileName'],
			'Sum': ['Sum', 'Average', 'LineCount', 'Comma', 'Option'],
			'SummaryInfo': ['Title', 'Subject', 'Author', 'Date', 'KeyWords', 'Comments', 'CreationTimeLow',
							'CreationTimeHigh', 'ModifiedTimeLow', 'ModifiedTimeHigh', 'PrintedTimeLow',
							'PrintedTimeHigh', 'LastSavedBy', 'Characters', 'Words', 'Lines', 'Paragraphs', 'Pages',
							'CopyPapers', 'Etcetera', 'DocVersion', 'HwpVersion', 'HanjaChar'],
			'TabDef': ['AutoTabLeft', 'AutoTabRight', 'TabItem'],
			'Table': ['PageBreak', 'RepeatHeader', 'CellSpacing', 'CellMarginLeft', 'CellMarginRight', 'CellMarginTop',
					  'CellMarginBottom', 'BorderFill', 'TableCharInfo', 'TableBorderFill', 'Cell'],
			'TableCreation': ['Rows', 'Cols', 'RowHeight', 'ColWidth', 'CellInfo', 'WidthType', 'HeightType', 'WidthValue',
							  'HeightValue', 'TableTemplateValue', 'TableProperties', 'TableTemplate',
							  'TableDrawProperties'],
			'TableDeleteLine': ['Type'],
			'TableDrawPen': ['Style', 'Width', 'Color'],
			'TableInsertLine': ['Side', 'Count'],
			'TableSplitCell': ['Cols', 'Rows', 'DistributeHeight', 'Merge', 'Mode2'],
			'TableStrToTbl': ['DelimiterType', 'UserDefine', 'AutoOrDefine', 'KeepSeperator', 'DelimiterEtc'],
			'TableSwap': ['Type', 'SwapMargin'],
			'TableTblToStr': ['DelimiterType', 'UserDefine'],
			'TableTemplate': ['Format', 'ApplyTarger', 'FileName', 'CreateMode'],
			'TextCtrl': ['CtrlData', 'Landscope'],
			'TextVertical': ['TextDirection', 'TextVerticalWidthHead', 'ApplyTo', 'ApplyClass'],
			'UserQCommandFile': ['Save', 'FileName', 'LoadType'],
			'VersionInfo': ['SourcePath', 'TargetPath', 'ItemStartIndex', 'ItemEndIndex', 'ItemOverWrite',
							'ItemSaveDescription', 'TempFilePath', 'ItemInfoIndex', 'SaveFilePath', 'ItemInfoWriter',
							'ItemInfoDescription', 'ItemInfoTimeHi', 'ItemInfoTimeLo', 'ItemInfoLock'],
			'ViewProperties': ['OptionFlag', 'ZoomType', 'ZoomRatio', 'ZoomCntX', 'ZoomCntY', 'ZoomMirror']}

		self.varx["action_name_vs_manual"] = {
			'SplitAll': '창 가로 세로 나누기',
			'NoSplit': '창 나누지 않음',
			'SplitVert': '창 세로로 나누기',
			'SplitHorz': '창 가로로 나누기',
			'SplitMemo': '메모창 보이기-감추기',
			'SplitMainActive': '메모창 활성화',
			'SplitMemoOpen': '메모창 열기',
			'SplitMemoClose': '메모창 닫기',
			'WindowPrevTab': '이전 창 활성화',
			'WindowNextTab': '다음 창 활성화',
			'WindowNextPane': '다음 분할창 활성화',
			'ShowNLPTab': '글 도우미 작업창 보이기',
			'WindowList': '창 목록',
			'WindowAlignCascade': '창 겹치게 배열',
			'WindowAlignTileHorz': '창 가로로 배열',
			'WindowAlignTileVert': '창 세로로 배열',
			'WindowMinimizeAll': '창 모두 아이콘으로 배열',
			'CharShapeHeight': '글자 크기',
			'CharShapeSpacing': '글자 자간',
			'CharShapeWidth': '글자 장평',
			'StyleCombo': '글자 스타일',
			'CharShapeLang': '글자 언어',
			'CharShapTypeface': '글자 모양',
			'ParaShapeLineSpace': '문단 모양',
			'ViewZoomRibon': '화면 확대',
			'MasterPageType': '바탕쪽 종류',
			'TableDrawPenStyle': '표 그리기 선 모양',
			'TableDrawPenWidth': '표 그리기 선 굵기',
			'NoteNumShape': '주석 번호 모양',
			'NotePosition': '각주 위치',
			'NoteLineLength': '주석 구분선 길이',
			'NoteLineShape': '주석 구분선 모양',
			'NoteLineWeight': '주석 구분선 굵기',
			'NoteLineColor': '주석 구분선 색',
			'EasyFind': '쉬운 찾기',
			'MarkPenColor': '형광펜 색',
			'TopTabFrameClose': '위쪽 작업창 감추기',
			'BottomTabFrameClose': '아래쪽 작업창 감추기',
			'LeftTabFrameClose': '왼쪽 작업창 감추기',
			'RightTabFrameClose': '오른쪽 작업창 감추기',
			'ShowFloatTabFrame': '플로팅 작업창 보이기-감추기',
			'SetWorkSpaceView': '작업창 보기 설정',
			'ShowTopWorkspace': '위쪽 작업창 보이기-감추기',
			'ShowLeftWorkspace': '왼쪽 작업창 보이기-감추기',
			'ShowBottomWorkspace': '아래쪽 작업창 보이기-감추기',
			'ShowRightWorkspace': '오른쪽 작업창 보이기-감추기',
			'HelpAbout': '글 2005 정보',
			'HancomRoom': '한컴 계약방',
			'PstGradientType': '프리젠테이션 그라데이션 형태',
			'PstScrChangeType': '프리젠테이션 화면 전환 형태',
			'PstBlackToWhite': '프리젠테이션 검은색 글자를 흰색으로 변경',
			'PstAutoPlay': '프리젠테이션 자동 시연',
			'PstSetupPrevSec': '프리젠테이션 앞 구역 설정',
			'PstSetupNextSec': '프리젠테이션 뒤 구역 설정',
			'CustRestBtn': '툴바 버튼 처음 상태로 되돌리기',
			'CustRenameBtn': '툴바 버튼 이름 바꾸기',
			'CustViewNameBtn': '툴바 버튼 이름만 보이기',
			'CustViewIconBtn': '툴바 버튼 아이콘만 보이기',
			'CustViewIconNameBtn': '툴바 버튼 이름과 아이콘 보이기',
			'CustInsSepBtn': '툴바 버튼에 구분선 넣기',
			'CustCopyBtn': '툴바 버튼 복사하기',
			'CustCutBtn': '툴바 버튼 오려두기',
			'CustEraseBtn': '툴바 버튼 지우기',
			'CustPasteBtn': '툴바 버튼 붙여기',
			'HelpContents': '내용',
			'HelpIndex': '찾아보기',
			'HelpWeb': '온라인 고객 지원',
			'MasterWsItemOnOff': '바탕쪽 작업창 보이기-감추기',
			'AppAbout': '글 2005 정보',
			'FileNew': '새 글',
			'FileNewTab': '새 탭',
			'FileSaveAsDRM': '배포용 문서로 저장하기',
			'FileClose': '문서 닫기',
			'TabClose': '현재탭 닫기',
			'FileQuit': '종료',
			'FileFind': '문서 찾기',
			'RecentEmpty': '최근 목록 지우기',
			'RecentNoExistDel': '최근 목록에서 존재하지 않는 아이템 지우기',
			'FileNextVersionDiff': '버전 비교 :   앞으로 이동',
			'FilePrevVersionDiff': '버전 비교 : 뒤로 이동',
			'FileVersionDiffChangeAlign': '버전 비교 : 비교화면 배열 변경 (좌우↔상하)',
			'FileVersionDiffSameAlign': '버전 비교 : 비교화면 다시 정렬',
			'FileVersionDiffSyncScroll': '버전 비교 : 비교화면 동시에 이동',
			'CustomizeToolbar': '도구상자 사용자 설정',
			'FrameFullScreen': '전체 화면',
			'FrameFullScreenEnd': '전체 화면 닫기',
			'FrameHRuler': '가로축 눈금자 보이기-감추기',
			'FrameVRuler': '세로축 눈금자 보이기-감추기',
			'FrameStatusBar': '상태바 보이기-감추기',
			'HorzScrollbar': '가로축 스크롤바 보이기-감추기',
			'VertScrollbar': '세로축 스크롤바 보이기-감추기',
			'ViewTabButton': '문서탭 보이기-감추기',
			'HwpViewType': '문서창 모양 설정',
			'ChangeSkin': '스킨 바꾸기',
			'ShowAttributeTab': '속성 작업창 보이기-감추기',
			'ShowScriptTab': '스크립트 작업창 보이기-감추기',
			'FrameViewZoomRibon': '화면 확대-축소',
			'HwpTabViewHwpDic': '사전 검색 작업창',
			'HwpTabViewNLP': '글 도우미 작업창',
			'HwpTabViewOutline': '개요 보기 작업창',
			'HwpTabViewMasterPage': '바탕쪽 보기 작업창',
			'HwpTabViewAction': '빠른 실행 작업창',
			'HwpTabViewDistant': '쪽모양 보기 작업창',
			'HwpTabViewClipboard': '클립보드 작업창',
			'HwpTabViewAttribute': '양식 개체 속성 작업창',
			'HwpTabViewScript': '스크립트 작업창',
			'HwpTabViewXMLTree': 'XML 문서 트리 작업창',
			'HwpTabViewXMLSchema': 'XML 문서 구조 작업창',
			'HwpWSDic': '사전 검색 작업창 (Shift + F12)',
			'SendBrowserText': '브라우저로 보내기',
			'ASendBrowserText': '웹브라우저로 보내기',
			'MoveLeft': '왼쪽으로 캐럿 이동',
			'MoveRight': '오른쪽으로 캐럿 이동',
			'MoveUp': '위쪽으로 캐럿 이동',
			'MoveDown': '아래쪽으로 캐럿 이동',
			'MoveSelLeft': '블록 설정 상태로 왼쪽으로 이동',
			'MoveSelRight': '블록 설정 상태로 오른쪽으로 이동',
			'MoveSelUp': '블록 설정 상태로 위쪽으로 이동',
			'MoveSelDown': '블록 설정 상태로 아래쪽으로 이동',
			'MovePrevChar': '한 글자 앞 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveNextChar': '한 글자 뒤로 이동,현재 리스트만을 대상으로 동작한다.',
			'MovePrevPos': '한 글자 앞으로 이동, 서브 리스트를 옮겨 다닐 수 있다.',
			'MoveNextPos': '한 글자 뒤로 이동,서브 리스트를 옮겨 다닐 수 있다.',
			'MovePrevPosEx': '한 글자 앞으로 이동,서브 리스트를 옮겨 다닐 수 있다. (머리말, 꼬리말, 각주, 미주, 글상자 포함)',
			'MoveNextPosEx': '한 글자 뒤로 이동,서브 리스트를 옮겨 다닐 수 있다,(머리말, 꼬리말, 각주, 미주, 글상자 포함)',
			'MovePrevWord': '한 단어 앞으로 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveNextWord': '한 단어 뒤로 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveWordBegin': '현재 위치한 단어의 시작으로 이동. 현재 리스트만을 대상으로 동작한다.',
			'MoveWordEnd': '현재 위치한 단어의 끝으로 이동. 현재 리스트만을 대상으로 동작한다.',
			'MoveDocBegin': '만약  셀렉션을  확장하는  경우에는 LIST_BEGIN-END와 동일하다,문서의 시작으로 이동. 현재 서브 리 스트 내에 있으면 빠져나간다.',
			'MoveDocEnd': '만약  셀렉션을  확장하는  경우에는 LIST_BEGIN-END와 동일하다,문서의 끝으로 이동. 현재 서브 리스 트 내에 있으면 빠져나간다.',
			'MoveLineBegin': '현재 위치한 줄의 시작-끝으로 이동',
			'MoveLineEnd': '현재 위치한 줄의 시작-끝으로 이동',
			'MoveParaBegin': '현재 위치한 문단의 시작-끝으로 이 동',
			'MoveParaEnd': '현재 위치한 문단의 시작-끝으로 이 동',
			'MovePageUp': '앞-뒤 페이지의 시작으로 이동,현재 탑 레벨 리스트가 아니면 탑 레 벨 리스트로 빠져나온다.',
			'MovePageDown': '앞-뒤 페이지의 시작으로 이동,현재 탑 레벨 리스트가 아니면 탑 레 벨 리스트로 빠져나온다.',
			'MovePageBegin': '쪽 맨 처음으로',
			'MovePageEnd': '쪽 맨 끝으로',
			'MoveListBegin': '현재 리스트의 시작으로 이동',
			'MoveListEnd': '현재 리스트의 끝으로 이동',
			'MoveTopLevelBegin': '탑 레벨 리스트의 시작으로 이동',
			'MoveTopLevelEnd': '탑 레벨 리스트의 끝으로 이동',
			'MovePrevParaEnd': '앞 문단의 끝-다음 문단의 시작으로 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveNextParaBegin': '앞 문단의 끝-다음 문단의 시작으로 이동,현재 리스트만을 대상으로 동작한다.',
			'MovePrevParaBegin': '앞 문단의 시작으로 이동,현재 리스트만을 대상으로 동작한다.',
			'MoveSectionUp': '앞-뒤 섹션으로 이동,현재 루트 리스트가 아니면 루트 리 스트로 빠져나온다.',
			'MoveSectionDown': '앞-뒤 섹션으로 이동,현재 루트 리스트가 아니면 루트 리스트로 빠져나온다.',
			'MoveParentList 3': '한 레벨 상위-탑 레벨-루트 리스트로 이동한다. 현재 루트 리스트에 위치 해 있어 더 이상 상위 리스트가 없을 때는 위치 이동 없이 리턴 한다.',
			'MoveTopLevelList': '한 레벨 상위-탑 레벨-루트 리스트로 이동한다. 현재 루트 리스트에 위치 해 있어 더 이상 상위 리스트가 없을 때는 위치 이동 없이 리턴한다,이동한 후의 위치는 상위 리스트에서 서브리스트가 속한 컨트롤 코드가 위 치한 곳이다. 위치 이동시 셀렉션은 무조건 풀린다.',
			'MoveRootList': '한 레벨 상위-탑 레벨-루트 리스트로 이동한다. 현재 루트 리스트에 위치 해 있어 더 이상 상위 리스트가 없을 때는 위치 이동 없이 리턴 한다,이동한 후의 위치는 상위 리스트에서 서브리스트가 속한 컨트롤 코드가 위 치한 곳이다. 위치 이동시 셀렉션은 무조건 풀린다.',
			'MoveSelPrevChar': '셀렉션: 이전 글자',
			'MoveSelNextChar': '셀렉션: 다음 글자',
			'MoveSelPrevPos': '셀렉션: 이전 위치',
			'MoveSelNextPos': '셀렉션: 다음 위치',
			'MoveSelPrevWord': '셀렉션: 이전 단어',
			'MoveSelNextWord': '셀렉션: 다음 단어',
			'MoveSelWordBegin': '셀렉션: 단어 처음',
			'MoveSelWordEnd': '셀렉션: 단어 끝',
			'MoveSelDocBegin': '셀렉션: 문서 처음',
			'MoveSelDocEnd': '셀렉션: 문서 끝',
			'MoveSelLineBegin': '셀렉션: 줄 처음',
			'MoveSelLineEnd': '셀렉션: 줄 끝',
			'MoveSelParaBegin': '셀렉션: 문단 처음',
			'MoveSelParaEnd': '셀렉션: 문단 끝',
			'MoveSelPageUp': '셀렉션: 페이지 업',
			'MoveSelPageDown': '셀렉션: 페이지 다운',
			'MoveSelListBegin': '셀렉션: 리스트 처음',
			'MoveSelListEnd': '셀렉션: 리스트 끝',
			'MoveSelTopLevelBegin': '셀렉션: 처음',
			'MoveSelTopLevelEnd': '셀렉션: 끝',
			'MoveSelPrevParaEnd': '셀렉션: 이전 문단 끝',
			'MoveSelNextParaBegin': '셀렉션: 다음 문단 처음',
			'MoveSelPrevParaBegin': '셀렉션: 이전 문단 시작',
			'MoveLineUp': '한 줄 위-아래로 이동한다.',
			'MoveLineDown': '한 줄 위-아래로 이동한다.',
			'MoveViewUp': '현재 뷰의 크기만큼 위-아래로 이동한다. PgUp-PgDn 키의 기능이다.',
			'MoveViewDown': '현재 뷰의 크기만큼 위-아래로 이동 한다. PgUp-PgDn 키의 기능이다.',
			'MoveViewBegin': '현재 뷰의 시작-끝에 위치한 곳으로 이동',
			'MoveViewEnd': '현재 뷰의 시작-끝에 위치한 곳으로 이동',
			'MovePrevColumn': '앞 단으로 이동',
			'MoveNextColumn': '뒤 단으로 이동',
			'MoveColumnBegin': '단의 처음으로 이동',
			'MoveColumnEnd': '단의 끝으로 이동',
			'MoveScrollPrev': '이전 방향으로 스크롤하면서 이동',
			'MoveScrollNext': '다음 방향으로 스크롤하면서 이동',
			'MoveScrollUp': '위 방향으로 스크롤하면서 이동',
			'MoveScrollDown': '아래 방향으로 스크롤하면서 이동',
			'MoveSelLineUp': '셀렉션: 한줄 위',
			'MoveSelLineDown': '셀렉션: 한줄 아래',
			'MoveSelViewUp': '셀렉션: 위',
			'MoveSelViewDown': '셀렉션: 아래',
			'Close': '레퍼런스 포인트가 등록되어 있으면 그 포인트로, 없으면 루트 리스트로 이동한다,나머지특성은 MoveRootList와 동일',
			'CloseEx': '레퍼런스 포인트가 등록되어 있으면 그 포인트로, 없으면 루트 리스트로 이동한다.  이동할 때 캐럿이 위치할 수 있는 곳을 찾아서 리스트를 빠져 나간다,나머지특성은 MoveRootList와 동일',
			'TableLeftCell': '셀이동: 셀 왼쪽',
			'TableRightCell': '셀이동: 셀 오른쪽',
			'TableRightCellAppend': '셀이동: 셀 오른쪽에 이어서',
			'TableUpperCell': '셀이동: 셀 위',
			'TableLowerCell': '셀이동: 셀 아래',
			'TableColBegin': '셀이동: 열 시작',
			'TableColEnd': '셀이동: 열 끝',
			'TableColPageUp': '셀이동: 페이지 업',
			'TableColPageDown': '셀이동: 페이지 다운',
			'TableResizeLeft': '셀 크기 변경',
			'TableResizeRight': '셀 크기 변경',
			'TableResizeUp': '셀 크기 변경',
			'TableResizeDown': '셀 크기 변경',
			'TableResizeCellLeft': '셀 크기 변경: 셀 왼쪽',
			'TableResizeCellRight': '셀 크기 변경: 셀 오른쪽',
			'TableResizeCellUp': '셀 크기 변경: 셀 위',
			'TableResizeCellDown': '셀 크기 변경: 셀 아래',
			'TableResizeLineLeft': '셀 크기 변경: 선 왼쪽',
			'TableResizeLineRight': '셀 크기 변경: 선 오른쪽',
			'TableResizeLineUp': '셀 크기 변경: 선 위',
			'TableResizeLineDown': '셀 크기 변경: 선 아래',
			'HiddenCredits': '인터넷 정보',
			'Undo': '되살리기',
			'Redo': '다시 실행',
			'PasteSpecial': '골라 붙이기',
			'SelectAll': '모두 선택',
			'Select': '블록 설정',
			'SelectColumn': '칸 블록 설정',
			'Delete': 'Delete',
			'DeleteBack': 'Backspace',
			'DeleteLine': 'CTRL-Y (한줄 지우기)',
			'DeleteLineEnd': '현재 캐럿 이후 지우기',
			'DeleteWord': '단어 지우기 CTRL-T',
			'DeleteWordBack': '왼쪽 단어 지우기 CTRL-BS',
			'ToggleOverwrite': '삽입-수정',
			'Cancel': '취소 ESC',
			'FindForeBackFind': '앞뒤로 찾아가기 : 찾기',
			'FindForeBackPage': '앞뒤로 찾아가기 : 쪽',
			'FindForeBackSection': '앞뒤로 찾아가기 : 구역',
			'FindForeBackLine': '앞뒤로 찾아가기 : 줄',
			'FindForeBackStyle': '앞뒤로 찾아가기 : 스타일',
			'FindForeBackCtrl': '앞뒤로 찾아가기 : 조판부호',
			'FindForeBackBookmark': '앞뒤로 찾아가기 : 책갈피',
			'FindForeBackSelectCtrl': '앞뒤로  찾아가기  :  조판  부호  찾기(선택)',
			'ReturnPrevPos': '직전위치로 돌아가기',
			'ModifyShapeObject': '고치기-개체 속성',
			'ModifyCtrl': '고치기-컨트롤',
			'ModifyLineProperty': '고치기(선 속성 탭으로)',
			'ModifyFillProperty': '고치기(채우기 속성 탭으로)',
			'SelectCtrlReverse': '개체선택 역방향',
			'SelectCtrlFront': '개체선택 정방향',
			'CharShapeNormal': '보통모양 ALT+SHIFT+C',
			'CharShapeBold': '단축키: Alt+L(글자 진하게)',
			'CharShapeItalic': '이탤릭 ALT + SHIFT + I',
			'CharShapeUnderline': '밑줄 ALT+SHIFT+U',
			'CharShapeCenterline': '취소선',
			'CharShapeOutline': '외곽선',
			'CharShapeShadow': '그림자',
			'CharShapeEmboss': '양각',
			'CharShapeEngrave': '음각',
			'CharShapeSuperscript': '위첨자 ALT+SHIFT+P',
			'CharShapeSubscript': '아래첨자 ALT+SHIFT+S',
			'CharShapeSuperSubscript': '첨자 위첨자→아래첨자→보통 반복',
			'CharShapeHeightIncrease': '크기 크게 ALT+SHIFT+E',
			'CharShapeHeightDecrease': '크기 작게 ALT+SHIFT+R',
			'CharShapeWidthIncrease': '장평 넓게 ALT+SHIFT+K',
			'CharShapeWidthDecrease': '장평 좁게 ALT+SHIFT+J',
			'CharShapeSpacingIncrease': '자간 넓게 ALT+SHIFT+W',
			'CharShapeSpacingDecrease': '자간 좁게 ALT+SHIFT+N',
			'CharShapeNextFaceName': '다음 글꼴 ALT+SHIFT+F',
			'CharShapePrevFaceName': '이전 글꼴 ALT+SHIFT+G',
			'ParagraphShapeAlignJustify': '양쪽 정렬',
			'ParagraphShapeAlignLeft': '왼쪽 정렬',
			'ParagraphShapeAlignRight': '오른쪽 정렬',
			'ParagraphShapeAlignCenter': '가운데 정렬',
			'ParagraphShapeAlignDistribute': '배분 정렬',
			'ParagraphShapeAlignDivision': '나눔 정렬',
			'ParagraphShapeWithNext': '다음 문단과 함께',
			'ParagraphShapeProtect': '문단 보호',
			'ParagraphShapeIncreaseLeftMargin': '왼쪽 여백 키우기',
			'ParagraphShapeDecreaseLeftMargin': '왼쪽 여백 줄이기',
			'ParagraphShapeDecreaseRightMargin': '오른쪽 여백 키우기',
			'ParagraphShapeIncreaseRightMargin': '오른쪽 여백 줄이기',
			'ParagraphShapeIndentAtCaret': '첫 줄 내어 쓰기',
			'ParagraphShapeIndentNegative': '첫 줄을 한 글자 내어 씀',
			'ParagraphShapeIndentPositive': '첫 줄을 한 글자 들여 씀',
			'ParagraphShapeDecreaseLineSpacing': '줄 간격을 점점 좁힘',
			'ParagraphShapeIncreaseLineSpacing': '줄 간격을 점점 넓힘',
			'ParagraphShapeIncreaseMargin': '왼쪽-오른쪽 여백 키우기',
			'ParagraphShapeDecreaseMargin': '왼쪽-오른쪽 여백 줄이기',
			'StyleShortcut1': '스타일 단축키(<Ctrl + 1>',
			'StyleShortcut2': '스타일 단축키(<Ctrl + 2>',
			'StyleShortcut3': '스타일 단축키(<Ctrl + 3>',
			'StyleShortcut4': '스타일 단축키(<Ctrl + 4>',
			'StyleShortcut5': '스타일 단축키(<Ctrl + 5>',
			'StyleShortcut6': '스타일 단축키(<Ctrl + 6>',
			'StyleShortcut7': '스타일 단축키(<Ctrl + 7>',
			'StyleShortcut8': '스타일 단축키(<Ctrl + 8>',
			'StyleShortcut9': '스타일 단축키(<Ctrl + 9>',
			'StyleShortcut10': '스타일 단축키(<Ctrl + 0>',
			'StyleClearCharStyle': '글자 스타일 해제',
			'MasterPagePrevSection': '앞 구역 바탕쪽 사용',
			'MasterPageExcept': '첫 쪽 제외',
			'MPSectionToPrevious': '이전 구역으로',
			'MPSectionToNext': '이후 구역으로',
			'MasterPageToPrevious': '이전 바탕쪽',
			'MasterPageToNext': '이후 바탕쪽',
			'MasterPageDelete': '바탕쪽 삭제',
			'MasterPageDuplicate': '기존 바탕쪽과 겹침',
			'MasterPageFront': '바탕쪽 앞으로 보내기',
			'HeaderFooterToPrev': '이전 머리말',
			'HeaderFooterDelete': '머리말 지우기',
			'HeaderFooterModify': '머리말-꼬리말 고치기',
			'BreakPage': '쪽 나누기',
			'BreakColumn': '단 나누기',
			'BreakSection': '구역 나누기',
			'BreakLine': '줄 나눔',
			'BreakPara': '문단 나누기',
			'BreakColDef': '단 정의 삽입',
			'InsertPageNum': '쪽 번호 넣기',
			'CharShapeTextColorBlack': '글자색을 검정',
			'CharShapeTextColorRed': '글자색을 빨강',
			'CharShapeTextColorBlue': '글자색을 파랑',
			'CharShapeTextColorViolet': '글자색을 자주',
			'CharShapeTextColorGreen': '글자색을 초록',
			'CharShapeTextColorYellow': '글자색을 노랑',
			'CharShapeTextColorBluish': '글자색을 청록',
			'CharShapeTextColorWhite': '글자색을 흰색',
			'ViewOptionPaper': '쪽 윤곽 보기',
			'ViewOptionGuideLine': '안내선 보기',
			'ViewOptionPicture': '그림 보기',
			'ViewOptionMemo': '메모 보기',
			'ViewOptionMemoGuideline': '메모 안내선 보기',
			'ViewOptionParaMark': '문단 부호 보기',
			'ViewOptionCtrlMark': '조판 부호 보기',
			'InputCodeChange': '문자 코드 변환',
			'InsertDateCode': '상용구 코드 넣기 : 만든 날짜',
			'InsertCpNo': '상용구 코드 넣기 : 현재 쪽 번호',
			'InsertTpNo': '상용구 코드 넣기 : 현재 쪽수',
			'InsertCpTpNo': '상용구 코드 넣기 : 현재 쪽-전체 쪽 수',
			'InsertDocInfo': '상용구 코드 넣기 : 만든 사람, 현재 쪽 번호, 만든 날짜',
			'InsertLastSaveDate': '상용구  코드  넣기  :  마지막  저장한 날짜',
			'InsertLastSaveBy': '상용구  코드  넣기  :  마지막  저장한 사람',
			'InsertLastPrintDate': '상용구  코드  넣기  :  마지막  인쇄한날짜',
			'HimKbdChange': '바꾸기',
			'Soft Keyboard': '보기',
			'RunUserKeyLayout': '사용자 글자판 제작 툴',
			'Him Config': '입력기 언어별 환경 설정',
			'InsertFootnote': '각주 입력',
			'InsertEndnote': '미주 입력',
			'NoteNumProperty': '주석 번호 속성',
			'NoteToPrev': '주석 앞으로 이동',
			'NoteToNext': '주석 다음으로 이동',
			'NoteDelete': '주석 지우기',
			'NoteModify': '주석 고치기',
			'InsertAutoNum': '번호 다시 넣기',
			'Comment': '숨은 설명',
			'CommentModify': '숨은 설명 고치기',
			'CommentDelete': '숨은 설명 지우기',
			'HyperlinkBackward': '하이퍼링크 뒤로',
			'HyperlinkForward': '하이퍼링크 앞으로',
			'ReturnKeyInField': '캐럿이  필드  안에  위치한  상태에서Return Key에 대한 액션 분기',
			'QuickMarkInsert0': '쉬운 책갈피 - 삽입 0',
			'QuickMarkInsert1': '쉬운 책갈피 - 삽입 1',
			'QuickMarkInsert2': '쉬운 책갈피 - 삽입 2',
			'QuickMarkInsert3': '쉬운 책갈피 - 삽입 3',
			'QuickMarkInsert4': '쉬운 책갈피 - 삽입 4',
			'QuickMarkInsert5': '쉬운 책갈피 - 삽입 5',
			'QuickMarkInsert6': '쉬운 책갈피 - 삽입 6',
			'QuickMarkInsert7': '쉬운 책갈피 - 삽입 7',
			'QuickMarkInsert8': '쉬운 책갈피 - 삽입 8',
			'QuickMarkInsert9': '쉬운 책갈피 - 삽입 9',
			'QuickMarkMove0': '쉬운 책갈피 - 이동 0',
			'QuickMarkMove1': '쉬운 책갈피 - 이동 1',
			'QuickMarkMove2': '쉬운 책갈피 - 이동 2',
			'QuickMarkMove3': '쉬운 책갈피 - 이동 3',
			'QuickMarkMove4': '쉬운 책갈피 - 이동 4',
			'QuickMarkMove5': '쉬운 책갈피 - 이동 5',
			'QuickMarkMove6': '쉬운 책갈피 - 이동 6',
			'QuickMarkMove7': '쉬운 책갈피 - 이동 7',
			'QuickMarkMove8': '쉬운 책갈피 - 이동 8',
			'QuickMarkMove9': '쉬운 책갈피 - 이동 9',
			'InsertFieldMemo': '메모 넣기',
			'DeleteFieldMemo': '메모 지우기',
			'InsertTab': '탭 삽입',
			'InsertSoftHyphen': '하이픈 삽입',
			'InsertNonBreakingSpace': '묶음 빈칸 삽입',
			'InsertFixedWidthSpace': '고정 폭 빈칸 삽입',
			'RightShiftBlock': '텍스트 블록 상태에서 블록이 문단의 시작위치에서 시작할 경우 블록 왼쪽 에 탭을 삽입한다.',
			'LeftShiftBlock': '텍스트  블록  상태에서  블록  왼쪽에 있는 탭 또는 공백을 지운다.',
			'PictureToOriginal': '그림 원래 그림으로',
			'PictureSave': '그림 빼내기',
			'PictureScissor': '그림 자르기',
			'InsertLine': '선 넣기',
			'ShapeObjAttachCaption': '캡션 넣기',
			'ShapeObjInsertCaptionNum': '캡션 번호 넣기',
			'ShapeObjDetachCaption': '캡션 없애기',
			'AutoChangeRun': '동작',
			'AutoChangeHangul': '낱자모 우선',
			'ManualChangeHangul': '한영 수동 전환',
			'MakeIndex': '찾아보기 만들기',
			'MarkTitle': '제목 차례 표시',
			'HideTitle': '제목 차례 숨기기',
			'MacroRepeat': '키 매크로 실행',
			'MacroPause': '키 매크로 실행 일시 중지 (정의-실 행)',
			'MacroStop': '키 매크로 실행 중지 (정의-실행)',
			'MacroPlay1': '키 매크로 1',
			'MacroPlay2': '키 매크로 2',
			'MacroPlay3': '키 매크로 3',
			'MacroPlay4': '키 매크로 4',
			'MacroPlay5': '키 매크로 5',
			'MacroPlay6': '키 매크로 6',
			'MacroPlay7': '키 매크로 7',
			'MacroPlay8': '키 매크로 8',
			'MacroPlay9': '키 매크로 9',
			'MacroPlay10': '키 매크로 10',
			'MacroPlay11': '키 매크로 11',
			'ScrMacroRepeat': '스크립트 매크로 실행',
			'ScrMacroPause': '스크립트 매크로 실행 일시 중지 (정 의-실행)',
			'ScrMacroStop': '스크립트 매크로 실행 중지 (정의-실행)',
			'ScrMacroPlay1': '스크립트 매크로 1',
			'ScrMacroPlay2': '스크립트 매크로 2',
			'ScrMacroPlay3': '스크립트 매크로 3',
			'ScrMacroPlay4': '스크립트 매크로 4',
			'ScrMacroPlay5': '스크립트 매크로 5',
			'ScrMacroPlay6': '스크립트 매크로 6',
			'ScrMacroPlay7': '스크립트 매크로 7',
			'ScrMacroPlay8': '스크립트 매크로 8',
			'ScrMacroPlay9': '스크립트 매크로 9',
			'ScrMacroPlay10': '스크립트 매크로 10',
			'ScrMacroPlay11': '스크립트 매크로 11',
			'LabelAdd': '라벨 추가',
			'CaptureHandler': '갈무리 시작',
			'CaptureDialog': '갈무리 끝',
			'MailMergeField': '메일 머지 필드(표시달기 or 고치기)',
			'TableFormulaSumHor': '가로 합계',
			'TableFormulaSumVer': '세로 합계',
			'TableFormulaAvgHor': '가로 평균',
			'TableFormulaAvgVer': '세로 평균',
			'TableFormulaProHor': '가로 곱',
			'TableFormulaProVer': '세로 곱',
			'TableFormulaSumAuto': '블록 합계',
			'TableFormulaAvgAuto': '블록 평균',
			'TableFormulaProAuto': '블록 곱',
			'TableCellBlock': '셀 블록',
			'TableCellBlockExtend': '셀 블록 연장(F5 + F5)',
			'TableCellBlockExtendAbs': '셀 블록 연장(SHIFT + F5)',
			'TableCellBlockCol': '셀 블록 (칸)',
			'TableCellBlockRow': '셀 블록 (줄)',
			'TableMergeCell': '셀 합치기',
			'TableVAlignTop': '셀 세로 정렬 위',
			'TableVAlignCenter': '셀 세로정렬 가운데',
			'TableVAlignBottom': '셀 세로정렬 아래',
			'TableDistributeCellWidth': '셀 너비를 같게',
			'TableDistributeCellHeight': '셀 높이를 같게',
			'TableSplitTable': '표 나누기',
			'TableMergeTable': '표 붙이기',
			'TableAutoFill': '자동 채우기',
			'TableAutoFillDlg': '자동 채우기 내용',
			'TableCellAlignLeftTop': '셀 왼쪽 위 정렬',
			'TableCellAlignLeftCenter': '셀 왼쪽 가운데 정렬',
			'TableCellAlignLeftBottom': '셀 왼쪽 아래 정렬',
			'TableCellAlignCenterTop': '셀 가운데 위 정렬',
			'TableCellAlignCenterCenter': '셀 가운데 정렬',
			'TableCellAlignCenterBottom': '셀 가운데 아래 정렬',
			'TableCellAlignRightTop': '셀 가운데 오른쪽 정렬',
			'TableCellAlignRightCenter': '셀 오른쪽 가운데 정렬',
			'TableCellAlignRightBottom': '셀 오른쪽 아래 정렬',
			'ShapeObjLineProperty': '고치기 대화상자중 line tab',
			'ShapeObjFillProperty': '고치기 대화상자중 fill tab',
			'FormObjCreatorPushButton': '양식 개체 푸쉬 버튼 넣기',
			'FormObjCreatorRadioButton': '양식 개체 라디오 버튼 넣기',
			'FormObjCreatorCheckButton': '양식 개체 체크 박스 넣기',
			'FormObjCreatorComboBox': '양식 개체 콤보 박스 넣기',
			'FormObjCreatorEdit': '양식 개체 에디트 박스 넣기',
			'FormDesignMode': '양식 개체 디자인 모드 변경',
			'FormObjRadioGroup': '양식 개체 라디오 버튼 그룹 묶기',
			'DrawObjCancelOneStep': '다각형(곡선) 그리는 중 이전 선 지우기',
			'ShapeObjRotater': '자유 각 회전(회전 중심 고정)',
			'ShapeObjRightAngleRotater': '90도 회전',
			'DrawObjEditDetail': '그리기 개체 편집',
			'ShapeObjSelect': '튼 선택 도구',
			'ShapeObjNorm': '기본 도형 설정',
			'ShapeObjGroup': '틀 묶기',
			'ShapeObjUngroup': '틀 풀기',
			'ShapeObjBringToFront': '맨 앞으로',
			'ShapeObjSendToBack': '맨 뒤로',
			'ShapeObjBringForward': '앞으로',
			'ShapeObjSendBack': '뒤로',
			'ShapeObjBringInFrontOfText': '글 앞으로',
			'ShapeObjCtrlSendBehindText': '글 뒤로',
			'ShapeObjWrapTopAndBottom': '자리 차지',
			'ShapeObjWrapSquare': '직사각형',
			'ShapeObjPrevObject': '이전 개체로 이동(shift + tab키)',
			'ShapeObjNextObject': '이후 개채로 이동(tab키)',
			'ShapeObjHorzFlip': '그리기 개체 좌우 뒤집기',
			'ShapeObjVertFlip': '그리기 개체 상하 뒤집기',
			'ShapeObjLock': '개체 Lock',
			'ShapeObjUnlockAll': '개체 Unlock All',
			'ShapeObjAlignTop': '위로 정렬',
			'ShapeObjAlignMiddle': '중간 정렬',
			'ShapeObjAlignBottom': '아래로 정렬',
			'ShapeObjAlignLeft': '왼쪽으로 정렬',
			'ShapeObjAlignCenter': '가운데로 정렬',
			'ShapeObjAlignRight': '오른쪽으로 정렬',
			'ShapeObjAlignVertSpacing': '위-아래 일정한 비율로 정렬',
			'ShapeObjAlignHorzSpacing': '왼쪽-오른쪽 일정한 비율로 정렬',
			'ShapeObjAlignWidth': '폭 맞춤',
			'ShapeObjAlignHeight': '높이 맞춤',
			'ShapeObjAlignSize': '폭-높이 맞춤',
			'ShapeObjMoveLeft': '키로 움직이기(왼쪽)',
			'ShapeObjMoveRight': '키로 움직이기(오른쪽)',
			'ShapeObjMoveUp': '키로 움직이기(위)',
			'ShapeObjMoveDown': '키로 움직이기(아래)',
			'ShapeObjResizeLeft': '키로 크기 조절(shift + 왼쪽)',
			'ShapeObjResizeRight': '키로 크기 조절(shift + 오른쪽)',
			'ShapeObjResizeUp': '키로 크기 조절(shift + 위)',
			'ShapeObjResizeDown': '키로 크기 조절(shift + 아래)',
			'DrawObjTemplateSave': '그리기 마당에 등록',
			'ShapeObjAttachTextBox': '글상자로 만들기',
			'ShapeObjDetachTextBox': '글상자 속성 없애기',
			'ShapeObjTextBoxEdit': '글상자 선택상태에서 편집모드로 들어가기',
			'ShapeObjTableSelCell': '테이블 선택 상태에서 첫 번째 셀 선 택하기',
			'DrawObjOpenClosePolygon': '다각형 열기-닫기',
			'ImageFindPath': '그림 경로 찾기',
			'FillColorShadeInc': '면색 음영 비율 증가',
			'FillColorShadeDec': '면색 음영 비율 감소',
			'FileOpen': '불러오기',
			'FileSave': '저장하기',
			'FileOpenMRU': '최근 작업 문서',
			'FileSaveAs': '다른 이름으로 저장하기',
			'FileSaveAsHwp97': '글 97문서로 저장하기',
			'FilePreview': '미리 보기',
			'FileVersionOpen': '버전 불러오기',
			'FileVersionDiff': '버전 비교',
			'ACreateSchema': 'XML 문서 구조 불러오기',
			'AOpenXMLDoc': 'XML 문서 불러오기',
			'ASaveXMLDoc': 'XML 문서 저장하기',
			'FileTemplate': '문서마당',
			'DocSummaryInfo': '문서 정보',
			'DocumentInfo': '현재 문서에 대한 정보',
			'LinkDocument': '문서 연결',
			'Print': '인쇄',
			'Preference': '환경 설정',
			'SendMailAttach': '편지 보내기-첨부 파일로',
			'SendMailText': '편지 보내기-본문으로',
			'PrintToImage': '그림으로 저장하기',
			'PrintToFax': 'UMS(fax)로 인쇄하기',
			'PrintToPDF': 'Adobe PDF로 인쇄하기',
			'FtpUpload': '웹 서버로 올리기',
			'FilePassword': '문서 암호',
			'FileSecurity': '배포용 문서로 저장하기',
			'SaveBlockAction': '블록 저장하기',
			'VersionInfo': '버전 관리',
			'VersionSave': '새 버전으로 저장',
			'ALoadUserInfoFile': '사용자 환경 파일 읽어오기',
			'Cut': '오려 두기',
			'Copy': '복사하기',
			'Erase': '지우기',
			'Paste': '붙이기',
			'FindDlg': '찾기',
			'RepeatFind': '다시 찾기',
			'ReverseFind': '거꾸로 찾기',
			'ForwardFind': '앞으로 찾기',
			'BackwardFind': '뒤로 찾기',
			'ReplaceDlg': '찾아 바꾸기',
			'ExecReplace': '바꾸기(실행)',
			'AllReplace': '모두 바꾸기',
			'DocFindInit': '문서 찾기 초기화',
			'DocFindNext': '문서 찾기 계속',
			'DocFindEnd': '문서 찾기 종료',
			'Goto': '찾아가기',
			'GotoStyle': '찾아가기-스타일(찾기-바꾸기 대화상자에서 사용)',
			'ConvertToHangul': '한글로',
			'ConvertHiraGata': '일어 바꾸기',
			'ConvertJianFan': '간체-번체 바꾸기',
			'ConvertCase': '대소문자 바꾸기',
			'ConvertFullHalfWidth': '전각 반각 바꾸기',
			'GetSectionApplyString': '유틸리티 액션',
			'GetSectionApplyTo': '유틸리티 액션',
			'GetDocFilters': '유틸리티 액션',
			'PasteHtmlDialog': 'HTML 문서 붙이기',
			'CharShapeDialog': '글자 모양 대화상자(내부 구현용)',
			'CharShape': '글자 모양',
			'MarkPenShape': '형광펜 모양',
			'ParaShapeDialog': '문단 모양 대화상자(내부 구현용)',
			'ParagraphShape': '문단 모양',
			'ParaNumberBullet': '문단번호-글머리표',
			'OutlineNumber': '개요 번호',
			'ParaNumberBulletLevelUp': '문단번호-글머리표 한 수준 위로',
			'ParaNumberBulletLevelDown': '문단번호-글머리표 한 수준 아래로',
			'PutParaNumber': '문단번호 달기',
			'PutNewParaNumber': '문단번호 새 번호 시작하기',
			'PutBullet': '글머리표 달기',
			'PutOutlineNumber': '개요 번호 닫기',
			'GetDefaultParaNumber': '문단 번호 디폴트 값',
			'GetDefaultBullet': '글머리표 디폴트 값',
			'StyleParaNumberBullet': '문단번호-글머리표',
			'PageBorder': '쪽 테두리-배경',
			'DropCap': '문단 첫 글자 장식',
			'ShapeCopyPaste': '모양 복사',
			'Style': '스타일',
			'StyleTemplate': '스타일 마당',
			'PageSetup': '편집 용지',
			'ModifySection': '구역',
			'MasterPage': '바탕쪽 Entry',
			'MasterPageEntry': '바탕쪽',
			'MasterPageTypeDlg': '바탕쪽 종류 다이얼로그 띄움',
			'HeaderFooter': '머리말-꼬리말',
			'HeaderFooterInsField': '코드 넣기',
			'HeaderFooterToNext': '이후 머리말',
			'MultiColumn': '다단',
			'PageHiding': '감추기',
			'PageHidingModify': '감추기 고치기',
			'PageNumPos': '쪽 번호 매기기',
			'PageNumPosModify': '쪽 번호 매기기',
			'NewNumber': '새 번호로 시작',
			'NewNumberModify': '새 번호 고치기',
			'ViewZoom': '화면 확대(Ribbon)',
			'ViewZoomNormal': '화면 확대: 정상',
			'ViewZoomFitPage': '화면 확대: 페이지에 맞춤',
			'ViewZoomFitWidth': '화면 확대: 폭에 맞춤',
			'ViewGridOption': '격자',
			'ViewShowGrid': '격자 보이기',
			'Idiom': '상용구',
			'ViewIdiom': '상용구 보기',
			'InsertIdiom': '상용구 등록',
			'InputDateStyle': '날짜-시간 기본 형식 지정',
			'InsertUserName': '상용구 코드 넣기 : 만든 사람',
			'InsertFileName': '상용구 코드 넣기 : 파일 이름',
			'InsertFilePath': '상용구 코드 넣기 : 파일 경로',
			'InsertDocTitle': '상용구 코드 넣기 : 문서 제목',
			'ComposeChars': '글자 겹침',
			'DutmalChars': '덧말 넣기',
			'AddHanjaWord': '한자 단어 등록',
			'EquationCreate': '수식 만들기',
			'EquationPropertyDialog': '수식 고치기 (대화상자)',
			'EquationModify': '수식 고치기',
			'FootnoteOption': '각주-미주 모양',
			'ExchangeFootnoteEndnote': '각주-미주 변환',
			'SaveFootnote': '주석 저장',
			'Bookmark': '책갈피',
			'ModifyBookmark': '책갈피 고치기',
			'Hyperlink': '캐럿이 필드 안에 위치했는지 여부에 따라 Insert 또는 Modify 하이퍼 링크 액션',
			'InsertHyperlink': '하이퍼링크 만들기',
			'ModifyHyperlink': '하이퍼링크 고치기',
			'HyperlinkJump': '하이퍼링크 이동',
			'InsertCrossReference': '상호 참조 넣기',
			'ModifyCrossReference': '상호 참조 고치기',
			'InsertFieldTemplate': '문서마당 정보',
			'ModifyFieldClickhere': '누름틀 정보 고치기',
			'ModifyFieldUserInfo': '개인 정보 필드 고치기',
			'ModifyFieldSummary': '문서 요약 필드 고치기',
			'ModifyFieldDate': '날짜 필드 고치기',
			'ModifyFieldPath': '문서 경로 필드 고치기',
			'InsertFile': '끼워 넣기',
			'MemoShape': '메모 모양',
			'InsertText': '텍스트 삽입',
			'InsertSpace': '공백 삽입',
			'OleCreateNew': '개체 삽입',
			'InsertVoice': '음성 삽입',
			'InsertFlash': '플래쉬 삽입',
			'InsertMoive': '동영상 삽입',
			'PictureInsertDialog': '그림 넣기 (대화상자를 띄워 선택한 이미지 파일을 문서에 삽입하는 액션: API용)',
			'ShapeObjDialog': '환경 설정',
			'DrawObjTemplateLoad': '그리기 마당에서 불러오기',
			'DrawObjCreatorTextBox': '글상자',
			'DrawObjCreatorConnectLine': '개체 연결선 만들기',
			'PictureEffect1': '그림 그레이 스케일',
			'PictureEffect2': '그림 흑백으로',
			'PictureEffect3': '그림 워터마크',
			'PictureEffect4': '그림 효과 없음',
			'PictureEffect5': '그림 밝기 증가',
			'PictureEffect6': '그림 밝기 감소',
			'PictureEffect7': '그림 명암 증가',
			'PictureEffect8': '그림 명암 감소',
			'PictureLinkedToEmbedded': '연결된 그림을 모두 삽입 그림으로',
			'QuickCorrect': '빠른 교정',
			'QuickCorrect Edit': '빠른 교정 - 내용 편집',
			'QuickCorrect Run': '빠른 교정 동작',
			'QuickCorrect Sound': '빠른   교정   -   메뉴에서   효과음On-Off',
			'ChangeRome': '로마자 변환',
			'ChangeRome String': '로마자변환 - 입력받은 스트링 변환',
			'GetRome String': '로마자 변환 - 입력 받은 스트링 변 환을 로마자로 변환해서 넘겨줌',
			'ChangeRome User': '로마자 사용자 데이터',
			'ChangeRome User String': '로마자 사용자 데이터 추가',
			'SearchForeign': '외래어 사전 검색',
			'SearchAddress': '주소 검색',
			'IndexMark': '찾아보기 표시',
			'MakeContents': '차례 만들기',
			'IndexMarkModify': '찾아보기 표시 고치기',
			'MacroDefine': '키 매크로 정의',
			'MacroRepeatDlg': '키 매크로 실행(대화상자)',
			'ScrMacroDefine': '스크립트 매크로 정의',
			'ScrMacroRepeatDlg': '스크립트 매크로 실행',
			'LabelTemplate': '라벨 문서 만들기',
			'ManuScriptTemplate': '원고지 쓰기',
			'Presentation': '프레젠테이션',
			'PresentationSetup': '프레젠테이션 설정',
			'MailMergeInsert': '메일 머지 표시 달기',
			'MailMergeModify': '메일 머지 고치기',
			'MailMergeGenerate': '메일 머지 만들기',
			'Sort': '소트',
			'Sum': '블록 합계',
			'Average': '블록 평균',
			'QuickCommand Run': '입력 자동 명령 동작 - 메뉴에서 동작 체크 On-Off',
			'AQcommandMerge': '입력 장동 명령',
			'TableCreate': '표 만들기',
			'TableFormula': '계산식',
			'TablePropertyDialog': '표 고치기',
			'TableSplitCell': '셀 나누기',
			'TableSplitCellRow2': '셀 줄 나누기',
			'TableSplitCellCol2': '셀 칸 나누기',
			'TableDeleteRowColumn': '줄-칸 지우기',
			'TableDeleteColumn': '칸 지우기',
			'TableDeleteRow': '줄-칸 지우기',
			'TableInsertRowColumn': '줄-칸 삽입',
			'TableInsertLeftColumn': '왼쪽 칸 삽입',
			'TableInsertRightColumn': '오른쪽 칸 삽입',
			'TableInsertUpperRow': '위쪽 줄 삽입',
			'TableInsertLowerRow': '아래쪽 줄 삽입',
			'TableAppendRow': '줄 추가',
			'TableSubtractRow': '줄 제거',
			'CellBorderFill': '셀 테두리 배경',
			'CellBorder': '셀 테두리 배경',
			'CellFill': '셀 배경',
			'CellZoneBorderFill': '여러 셀에 걸쳐 적용',
			'CellZoneBorder': '셀 테두리 적용',
			'CellZoneFill': '셀 배경에 적용',
			'TableDrawPen': '표 그리기',
			'TableEraser': '표 지우개',
			'TableDeleteCell': '셀 삭제',
			'TableAutoDrawPenStyleWidthDlg': '선 모양',
			'TableCellShadeInc': '셀 음영 비율 증가',
			'TableCellShadeDec': '셀 음영 비율 감소',
			'TableTableToString': '표를 문자열로',
			'TableStringToTable': '문자열을 표로',
			'TableTemplate': '표 마당',
			'InsertChart': '차트 만들기',
			'TableSwap': '표 뒤집기',
			'ShapeObjAttrDialog': '특 속성 환경 설정',
			'DrawObjCreatorLine': '선 그리기',
			'DrawObjCreatorRectangle': '사각형 그리기',
			'DrawObjCreatorEllipse': '원 그리기',
			'DrawObjCreatorArc': '호 그리기',
			'DrawObjCreatorPolygon': '다각형 그리기',
			'DrawObjCreatorCurve': '곡선 그리기',
			'DrawObjCreatorFreeDrawing': '펜',
			'FormObjectPropertyDialog': '양식 개체 고치기',
			'FormObjCharShape': '양식 개체 글자 모양 속성 변경',
			'FormObjInputCodeTable': '양식 개체 Edit에서만 사용하는 문자 표',
			'FormObjInputHanja': '양식 개체 Edit에서만 사용하는 한자 로 바꾸기',
			'FormObjHanjaBusu': '양식 개체 Edit에서만 사용하는 한자 부수 입력',
			'FormObjHanjaMean': '양식 개체 Edit에서만 사용하는 한자 새김 입력',
			'FormObjInputIdiom': '양식 개체 Edit에서만 사용하는 상용 구 입력',
			'DrawObjCreatorMultiLine': '반복해서 선 그리기',
			'DrawObjCreatorMultiRectangle': '반복해서 사각형 그리기',
			'DrawObjCreatorMultiEllipse': '반복해서 원 그리기',
			'DrawObjCreatorMultiArc': '반복해서 호 그리기',
			'DrawObjCreatorMultiPolygon': '반복해서 다각형 그리기',
			'DrawObjCreatorMultiCurve': '반복해서 곡선 그리기',
			'DrawObjCreatorMultiFreeDrawing': '반복해서 펜 그리기',
			'DrawObjCreatorMultiTextBox': '반복해서 글상자 그리기',
			'ShapeObjRandomAngleRotater': '자유 각 회전',
			'ShapeObjShear': '기울이기',
			'ShapeObjSaveAsPicture': '그리기개체를 그림으로 저장하기',
			'MessageBox': '메시지 박스',
		}

		#파라미터에대한 설명
		self.varx["parameter_vs_manual"] = {
				'AutoFillSection': ['자동 채우기 섹션', 'unsigned int'],
				'AutoFillItem': ['섹션의 아이템 인덱스', 'unsigned int'],
				'NumType': ['번호 종류', 'unsigned char'],
				'NewNumber': ['새 시작 번호 (1 .. n)', 'unsigned short'],
				'Name': ['책갈피 이름','string'],
				'Type': ['책갈피 종류', 'unsigned int'],
				'Command': ['책갈피 명령의 종류', 'unsigned int'],
				'BorderTypeLeft': ['4방향 테두리 종류', 'unsigned short'],
				'BorderTypeRight': ['4방향 테두리 종류', 'unsigned short'],
				'BorderTypeTop': ['4방향 테두리 종류', 'unsigned short'],
				'BorderTypeBottom': ['4방향 테두리 종류', 'unsigned short'],
				'BorderWidthLeft': ['4방향 테두리 두께', 'unsigned char'],
				'BorderWidthRight': ['4방향 테두리 두께', 'unsigned char'],
				'BorderWidthTop': ['4방향 테두리 두께', 'unsigned char'],
				'BorderWidthBottom': ['4방향 테두리 두께', 'unsigned char'],
				'BorderCorlorLeft': ['4방향 테두리 색깔', 'unsigned long'],
				'BorderColorRight': ['4방향 테두리 색깔', 'unsigned long'],
				'BorderColorTop': ['4방향 테두리 색깔', 'unsigned long'],
				'BorderColorBottom': ['4방향 테두리 색깔 :아래, RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
				'SlashFlag': ['슬래쉬 대각선 플래그', 'unsigned short'],
				'BackSlashFlag': ['백슬래쉬 대각선 플래그', 'unsigned short'],
				'DiagonalType': ['선 종류', 'unsigned short'],
				'DiagonalWidth': ['선 굵기', 'unsigned char'],
				'DiagonalColor': ['선 색상, RGB-32비트 (0x00BBGGRR)셀에서는 대각선), 표에서는 자동으로 나눠진 경계선에서 사용', 'unsigned long'],
				'BorderFill3D': ['3차원 효과', 'unsigned char'],
				'Shadow': ['그림자 효과', 'unsigned char'],
				'FillAttr': ['배경 채우기 속성','set'],
				'CrookedSlashFlag': ['꺾인 대각선 플래그 (bit 0, 1이 각각 slash, back slash의 가 운데 대각선이 꺾인 대각선임을 나타낸다.)', 'unsigned short'],
				'BreakCellSeparateLine': ['자동으로 나뉜 표의 경계선 설정', 'unsigned char'],
				'CounterSlashFlag': ['슬래쉬 대각선의 역방향 플래그(우상향 대각선)', 'unsigned char'],
				'CounterBackSlashFlag': ['역슬래쉬 대각선의 역방향 플래그(좌상향 대각선)', 'unsigned char'],
				'CenterLineFlag': ['중심선', 'unsigned char'],
				'CrookedSlashFlag1': ['Low Byte CrookedSlashFlag (슬래쉬 대각선의 꺾임 여부) (CrookedSlashFlag를 쓰기 편하도록 CrookedSlashFlag1/2로 나눔)', 'unsigned char'],
				'CrookedSlashFlag2': ['High Byte CrookedSlashFlag (역슬래쉬 대각선의 꺾임 여부) (CrookedSlashFlag를 쓰기 편하도록 CrookedSlashFlag1/2로 나눔)', 'unsigned char'],
				'TypeHorz': ['중앙선 종류', 'unsigned short'],
				'TypeVert': ['중앙선 종류', 'unsigned short'],
				'WidthHorz': ['중앙선 두께', 'unsigned char'],
				'WidthVert': ['중앙선 두께', 'unsigned char'],
				'ColorHorz': ['중앙선 색깔', 'unsigned long'],
				'ColorVert': ['중앙선 색깔', 'unsigned long'],
				'HasCharShape': ['자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
				'CharShape': ['글자 모양 (HasCharShape가 1일 경우에만 사용)', 'set'],
				'WidthAdjust': ['번호 너비 보정 값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'TextOffset': ['본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'Alignment': ['번호 정렬', 'unsigned char'],
				'UseInstWidth': ['번호 너비를 문서 내 문자열의 너비에 따를지 여부 ', 'unsigned char'],
				'AutoIndent': ['번호 너비 자동 들여쓰기 여부', 'unsigned char'],
				'TextOffsetType': ['본문과의 거리 종류', 'unsigned char'],
				'BulletChar': ['불릿 문자 코드', 'unsigned short'],
				'HasImage': ['그림 글머리표 여부', 'unsigned char'],
				'BulletImage': ['글머리표 이미지', 'set'],
				'Side': ['방향', 'unsigned char'],
				'Width': ['캡션 폭 (가로 방향일 때만 사용됨. 단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며), 1inch는 7200HWPUNIT)', 'int'],
				'Gap': ['캡션과 틀 사이 간격( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'CapFullSize': ['캡션 폭에 여백을 포함할지 여부 (세로 방향일 때만 사용됨)', 'unsigned char'],
				'BeginX': ['시작점과 X 좌표(페이지 X좌표)','int'],
				'BeginY': ['시작점과 Y 좌표(페이지 Y좌표)', 'int'],
				'EndX': ['끝점의 X 좌표(페이지 X좌표)', 'int'],
				'EndY': ['끝점의 Y 좌표(페이지 Y좌표)', 'int'],
				'PageNum': ['페이지 번호', 'unsigned int'],
				'HasMargin': ['테이블의 기본 셀 여백 대신 자체 셀 여백을 적용할지 여부. ', 'unsigned char'],
				'Protected': ['사용자 편집을 막을지 여부', 'unsigned char'],
				'Header': ['제목 셀인지 여부', 'unsigned char'],
				'Height': ['셀의 높이 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며), 1inch는 7200HWPUNIT)', 'long'],
				'Editable': ['양식모드에서 편집 가능 여부', 'unsigned char'],
				'Dirty': ['초기화 상태인지 수정된 상태인지 여부', 'unsigned char'],
				'CellCtrlData': ['셀 데이터 (글2007에 새로 추가)', 'set'],
				'ApplyTo': ['적용 대상', 'unsigned char'],
				'NoNeighborCell': ['주변 셀에 선 모양을 적용하지 않을지 여부 (1이면 적용하지 않는 다)', 'unsigned char'],
				'TableBorderFill': ['표 테두리/배경', 'set'],
				'AllCellsBorderFill': ['전체 셀의 테두리/배경', 'set'],
				'SelCellsBorderFill': ['선택된 셀의 테두리/배경', 'set'],
				'Option': ['변환옵션', 'unsigned char'],
				'HanString': ['변경시킬 또는 변경된 한글문자', 'string'],
				'FaceNameHangul': ['글꼴 이름 (한글)', 'string'],
				'FaceNameLatin': ['글꼴 이름 (영문)', 'string'],
				'FaceNameHanja': ['글꼴 이름 (한자)', 'string'],
				'FaceNameJapanese': ['글꼴 이름 (일본어)', 'string'],
				'FaceNameOther': ['글꼴 이름 (기타)', 'string'],
				'FaceNameSymbol': ['글꼴 이름 (심벌)', 'string'],
				'FaceNameUser': ['글꼴 이름 (사용자)', 'string'],
				'FontTypeHangul': ['폰트 종류 (한글)', 'unsigned char'],
				'FontTypeLatin': ['폰트 종류 (영문)', 'unsigned char'],
				'FontTypeHanja': ['폰트 종류 (한자)', 'unsigned char'],
				'FontTypeJapanese': ['폰트 종류 (일본어)', 'unsigned char'],
				'FontTypeOther': ['폰트 종류 (기타)', 'unsigned char'],
				'FontTypeSymbol': ['폰트 종류 (심벌)', 'unsigned char'],
				'FontTypeUser': ['폰트 종류 (사용자)', 'unsigned char'],
				'SizeHangul': ['각 언어별 크기 비율. (한글) 10% - 250%', 'unsigned char'],
				'SizeLatin': ['각 언어별 크기 비율. (영문) 10% - 250%', 'unsigned char'],
				'SizeHanja': ['각 언어별 크기 비율. (한자) 10% - 250%', 'unsigned char'],
				'SizeJapanese': ['각 언어별 크기 비율. (일본어) 10% - 250%', 'unsigned char'],
				'SizeOther': ['각 언어별 크기 비율. (기타) 10% - 250%', 'unsigned char'],
				'SizeSymbol': ['각 언어별 크기 비율. (심벌) 10% - 250%', 'unsigned char'],
				'SizeUser': ['각 언어별 크기 비율. (사용자) 10% - 250%', 'unsigned char'],
				'RatioHangul': ['각 언어별 장평 비율. (한글) 50% - 200%', 'unsigned char'],
				'RatioLatin': ['각 언어별 장평 비율. (영문) 50% - 200%', 'unsigned char'],
				'RatioHanja': ['각 언어별 장평 비율. (한자) 50% - 200%', 'unsigned char'],
				'RatioJapanese': ['각 언어별 장평 비율. (일본어) 50% - 200%', 'unsigned char'],
				'RatioOther': ['각 언어별 장평 비율. (기타) 50% - 200%', 'unsigned char'],
				'RatioSymbol': ['각 언어별 장평 비율. (심벌) 50% - 200%', 'unsigned char'],
				'RatioUser': ['각 언어별 장평 비율. (사용자) 50% - 200%', 'unsigned char'],
				'SpacingHangul': ['각 언어별 자간. (한글) -50% - 50%', 'char'],
				'SpacingLatin': ['각 언어별 자간. (영문) -50% - 50%', 'char'],
				'SpacingHanja': ['각 언어별 자간. (한자) -50% - 50%', 'char'],
				'SpacingJapanese': ['각 언어별 자간. (일본어) -50% - 50%', 'char'],
				'SpacingOther': ['각 언어별 자간. (기타) -50% - 50%', 'char'],
				'SpacingSymbol': ['각 언어별 자간. (심벌) -50% - 50%', 'char'],
				'SpacingUser': ['각 언어별 자간. (사용자) -50% - 50%', 'char'],
				'OffsetHangul': ['각 언어별 오프셋. (한글) -100% - 100%', 'char'],
				'OffsetLatin': ['각 언어별 오프셋. (영문) -100% - 100%', 'char'],
				'OffsetHanja': ['각 언어별 오프셋. (한자) -100% - 100%', 'char'],
				'OffsetJapanese': ['각 언어별 오프셋. (일본어) -100% - 100%', 'char'],
				'OffsetOther': ['각 언어별 오프셋. (기타) -100% - 100%', 'char'],
				'OffsetSymbol': ['각 언어별 오프셋. (심벌) -100% - 100%', 'char'],
				'OffsetUser': ['각 언어별 오프셋. (사용자) -100% - 100%', 'char'],
				'Bold': ['Bold', 'unsigned char'],
				'Italic': ['Italic', 'unsigned char'],
				'SmallCaps': ['Small Caps', 'unsigned char'],
				'Emboss': ['Emboss', 'unsigned char'],
				'Engrave': ['Engrave', 'unsigned char'],
				'SuperScript': ['Superscript', 'unsigned char'],
				'SubScript': ['Subscript', 'unsigned char'],
				'UnderlineType': ['밑줄 종류', 'unsigned char'],
				'OutlineType': ['외곽선 종류', 'unsigned char'],
				'ShadowType': ['그림자 종류', 'unsigned char'],
				'TextColor': ['글자색. (COLORREF) RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
				'ShadeColor': ['음영색. (COLORREF) RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
				'UnderlineShape': ['밑줄 모양', 'unsigned char'],
				'UnderlineColor': ['밑줄 색 (COLORREF)', 'unsigned long'],
				'ShadowOffsetX': ['그림자 간격 (X 방향) -100% - 100%', 'char'],
				'ShadowOffsetY': ['그림자 간격 (Y 방향) -100% - 100%', 'char'],
				'ShadowColor': ['그림자 색 (COLORREF) RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
				'StrikeOutType': ['취소선 종류', 'unsigned char'],
				'DiacSymMark': ['강조점 종류', 'unsigned char'],
				'UseFontSpace': ['글꼴에 어울리는 빈칸', 'unsigned char'],
				'UseKerning': ['커닝', 'unsigned char'],
				'BorderFill': ['테두리/배경 (글2007에 새로 추가)', 'set'],
				'Chars': ['겹쳐질 글자들', 'string'],
				'Text': ['삽입될 스트링', 'string'],
				'Count': ['단 개수. 1-255까지.', 'unsigned char'],
				'SameSize': ['단의 너비를 같도록 할지 여부', 'unsigned char'],
				'SameGap': ['단 사이 간격( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT) SAME_SIZE가 1일 때만 사용된다.', 'long'],
				'WidthGap': ['각 단의 너비와 간격( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), col*2:단의 폭, col*2 + 1:단 사이 간격., 영역 전체의 폭을 Column ratio base (=32768)로 보았을 때의 비율로 환산한다., SameSize가 0일 때만 사용된다., 배열의 아이템의 개수는 Count*2-1과 같아 한다.', 'array'],
				'Layout': ['단 방향 지정', 'unsigned char'],
				'LineType': ['선 종류.', 'unsigned char'],
				'LineWidth': ['선 굵기.', 'unsigned char'],
				'LineColor': ['선 색깔. (COLORREF), RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
				'ApplyClass': ['적용범위의 분류. 아래 값의 조합이다. 0x0001:선택된 다단, 0x0002:선택된 문자열', 'unsigned char'],
				'Number': ['변경 대상에 숫자를 추가할지 여부', 'unsigned int'],
				'Alpha': ['변경 대상에 영문자를 추가할지 여부', 'unsigned int'],
				'Symbol': ['변경 대상에 기호를 추가할지 여부', 'unsigned int'],
				'Gata': ['변경 대상에 가타가나를 추가할지 여부', 'unsigned int'],
				'HGJamo': ['변경 대상에 한글자모를 추가할지 여부', 'unsigned int'],
				'Hanja': ['한자를 한글로 변경할지 여부', 'unsigned int'],
				'Hira': ['히라가나를 한글로 변경할지 여부', 'unsigned int'],
				'Gu': ['구결을 한글로 변경할지 여부', 'unsigned int'],
				'DeleteCtrlType': ['지울 개체 목록', 'array'],
				'DocFilters': ['문자로 분리된 필터 리스트 스트링(MFC 와 같은 방법)을 가져옴', 'string'],
				'Format': ['필터 리스트를 string array형태로 가져옴 (Export시에만)', 'array'],
				'ListID': ['현재 위치한 리스트', 'unsigned int'],
				'ParaID': ['현재 위치한 문단', 'unsigned int'],
				'Pos': ['현재 위치한 글자', 'unsigned int'],
				'CurPara': ['현재 위치한 문단', 'unsigned int'],
				'CurPos': ['현재 위치한 오프셋', 'unsigned int'],
				'CurParaLen': ['현재 위치한 문단의 길이', 'unsigned int'],
				'CurCtrl': ['현재 리스트의 종류', 'unsigned int'],
				'CurParaCount': ['현재 리스트의 문단 수', 'unsigned int'],
				'RootPara': ['루트 리스트의 현재 문단', 'unsigned int'],
				'RootPos': ['루트 리스트의 현재 오프셋', 'unsigned int'],
				'RootParaCout': ['루트 리스트의 문단 수', 'unsigned int'],
				'DetailInfo': ['자세한 정보를 구할지 여부, Detail~ 로 시작하는 아이템의 정보를 얻기 위해서는 이 값을 1로 넣어준 후에 액션을 실행해준다.', 'char'],
				'DetailCharCount': ['문서에 포함된 글자 수', 'unsigned int'],
				'DetailWordCount': ['문서에 포함된 어절 수', 'unsigned int'],
				'DetailLineCount': ['문서에 포함된 줄 수', 'unsigned int'],
				'DetailPageCount': ['문서에 포함된 쪽 수', 'unsigned int'],
				'DetailCurPage': ['현재 쪽 번호', 'unsigned int'],
				'DetailCurPrtPage': ['현재 쪽 번호 (인쇄 번호)', 'unsigned int'],
				'SectionInfo': ['구역의 속성까지 구할지 여부, SecDef 아이템은 이 값을 1로 넣어준 후 액션을 실행한 후에 얻을 수 있다.', 'unsigned int'],
				'SecDef': ['구역의 속성 (글2007에 새로 추가)', 'set'],
				'Interval': ['확장타원(호)에서 호의 시작점과 끝점을 나타내게 한다.', 'array'],
				'Point': ['좌표 Array (X1,Y1), (X2,Y2), ..., (Xn,Yn)', 'array'],
				'Line': ['선 속성 Array(곡선에서만 쓰임)', 'array'],
				'Index': ['고칠 점의 인덱스', 'unsigned int'],
				'PointX': ['점의 X 좌표', 'int'],
				'PointY': ['점의 Y 좌표', 'int'],
				'GradationType': ['배경 유형이 그러데이션일 때 그러데이션 형태, 1:줄무늬형, 2:원형, 3:원뿔형, 4:사각형', 'int'],
				'GradationAngle': ['그러데이션의 기울임(시작각)', 'int'],
				'GradationCenterX': ['그러데이션의 가로중심(중심 X 좌표)', 'int'],
				'GradationCenterY': ['그러데이션의 가로중심(중심 Y 좌표)', 'int'],
				'GradationStep': ['그러데이션 번짐 정도 (0..100)', 'int'],
				'GradationColorNum': ['그러데이션의 색 수', 'int'],
				'GradationColor': ['그러데이션의 색깔(시작색, 중간색1,..중간색 n-2, 끝색) 2<= n <=10', 'array'],
				'GradationIndexPos': ['그러데이션 다음 색깔과의 거리(얼마나 번지고 나서 다음색깔로 가 는가)', 'array'],
				'GradationStepCenter': ['그러데이션 번짐 정도의 중심 (0..100)', 'unsigned char'],
				'GradationAlpha': ['그러데이션 투명도 (글2007에새로추가)', 'unsigned char'],
				'WinBrushFaceColor': ['면 색 (RGB 0x00BBGGRR) (글2007에새로추가)', 'unsigned int'],
				'WinBrushHatchColor': ['무늬 색 (RGB 0x00BBGGRR) (글2007에 새로 추가)', 'unsigned int'],
				'WinBrushAlpha': ['면/무늬 색 투명도 (글2007에 새로 추가)', 'unsigned int'],
				'FileName': ['ShapeObject의 배경을 그림으로 선택했을 경우. 또는 그림개체일 경우의 그림파일 경로', 'string'],
				'Embedded': ['그림이 문서에 직접 삽입(TRUE) / 파일로 연결(FALSE)', 'unsigned char'],
				'PicEffect': ['그림 효과', 'unsigned char'],
				'Brightness': ['명도 (-100 ~ 100)', 'char'],
				'Contrast': ['밝기 (-100 ~ 100)', 'char'],
				'Reverse': ['반전 유무', 'unsigned char'],
				'DrawFillImageType': ['ShapeObject의 배경일 경우에만 의미있는 아이템배경을 채우는 방식을 결정],그림개체에는해당사항없음', 'int'],
				'SkipLeft': ['그림 개체일 경우에만 의미 있는 아이템, 왼쪽 자르기', 'unsigned int'],
				'SkipRight': ['그림 개체일 경우에만 의미 있는 아이템, 오른쪽 자르기', 'unsigned int'],
				'SkipTop': ['그림 개체일 경우에만 의미 있는 아이템, 위 자르기', 'unsigned int'],
				'SkipBottom': ['그림 개체일 경우에만 의미 있는 아이템, 아래 자르기', 'unsigned int'],
				'OriginalSizeX': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 원본 크기 X size', 'unsigned int'],
				'OriginalSizeY': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 원본 크기 Y size', 'unsigned int'],
				'InsideMarginLeft': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (왼쪽)', 'long'],
				'InsideMarginRight': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (오른 쪽)', 'long'],
				'InsideMarginTop': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (위)', 'long'],
				'InsideMarginBottom': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (아래)', 'long'],
				'WindowsBrush': ['현재 선택된 brush의 type이 면/무늬 브러시인가를 나타냄', 'unsigned char'],
				'GradationBrush': ['현재 선택된 brush의 type이 그러데이션 브러시인가를 나타냄', 'unsigned char'],
				'ImageBrush': ['현재 선택된 brush의 type이 그림 브러시인가를 나타냄', 'unsigned char'],
				'ImageCreateOnDrag': ['그림 개체 생성 시 마우스로 끌어 생성할지 여부, (글2007에 새로 추가)', 'unsigned char'],
				'ImageAlpha': ['그림 개체/배경 투명도 (글2007에 새로 추가)', 'unsigned char'],
				'InsideMarginBotto m': ['그림 개체일 경우에만 의미 있는 아이템, 이미지 안쪽 여백. (아래)', 'long'],
				'Xoffset': ['자를 x축 오프셋', 'int'],
				'Yoffset': ['자를 y축 오프셋', 'int'],
				'HandleIndex': ['Reserved', 'unsigned int'],
				'CreateNumPt': ['생성할 점의 수', 'unsigned int'],
				'CreatePt': ['생성할 점의 위치정보, POINT(x,y)로 계산되므로 CreateNumPt*2의 개수로 구성 됨.', 'array'],
				'CurveSegmentInfo': ['곡선 세그먼트 정보', 'array'],
				'Color': ['선 색깔 RGB-32비트 (0x00BBGGRR)', 'PMT_UINT32'],
				'Style': ['선의 style', 'int'],
				'EndCap': ['선의 endcap', 'int'],
				'HeadStyle': ['선의 시작 화살표 모양', 'int'],
				'TailStyle': ['선의 끝 화살표 모양', 'int'],
				'HeadSize': ['선의 시작 화살표 크기', 'int'],
				'TailSize': ['선의 끝 화살표 크기', 'int'],
				'HeadFill': ['선의 시작 화살표 채움 유무', 'blooen'],
				'TailFill': ['선의 끝 화살표 채움 유무', 'blooen'],
				'OutLineStyle': ['선두께 외부/내부/일반 적용', 'unsigned int'],
				'Mode': ['Reserved', 'unsigned int'],
				'CenterX': ['회전 중심의 X 좌표', 'int'],
				'CenterY': ['회전 중심의 Y 좌표', 'int'],
				'ObjectCenterX': ['그리기 개체의 중심 X 좌표', 'int'],
				'ObjectCenterY': ['그리기 개체의 중심 Y 좌표', 'int'],
				'Angle': ['회전 각', 'int'],
				'RotateImage': ['그림 회전 여부 (글2007에 새로 추가)', 'unsigned char'],
				'RotateCenterX': ['회전 중심 X 좌표', 'long'],
				'RotateCenterY': ['회전 중심 Y 좌표', 'long'],
				'RotateAngel': ['회전각', 'int'],
				'HorzFlip': ['수평 flip (좌우 뒤집기)', 'unsigned int'],
				'VertFlip': ['수직 flip (상하 뒤집기)', 'unsigned int'],
				'ShadowAlpha': ['그림자 투명도', 'unsigned char'],
				'XFactor': ['X축 기울이기 각도', 'int'],
				'YFactor': ['Y축 기울이기 각도', 'int'],
				'String': ['글맵시에 넣을 문자열 내용', 'string'],
				'FontName': ['글꼴', 'string'],
				'FontStyle': ['속성. 값은 항상 0(Regular)이다.', 'string'],
				'FontType': ['폰트 종류', 'unsigned char'],
				'LineSpacing': ['줄 간격 (50 ~ 500)', 'long'],
				'CharSpacing': ['글자간격 (50 ~ 500)', 'long'],
				'AlignType': ['정렬 방식', 'unsigned char'],
				'Shape': ['형태 (0 ~ 54)', 'unsigned char'],
				'NumberOfLines': ['글맵시에 넣을 문자열 내용의 줄 수', 'unsigned char'],
				'FaceName': ['글꼴', 'string'],
				'LineStyle': ['선 스타일', 'int'],
				'LineWeight': ['선 굵기', 'unsigned int'],
				'FaceColor': ['글꼴 색, RGB-32비트 (0x00BBGGRR)', 'unsigned long'],
				'Spacing': ['본문과의 간격', 'int'],
				'ResultText': ['본말', 'string'],
				'SubText': ['덧말', 'string'],
				'PosType': ['덧말 위치', 'unsigned char'],
				'FsizeRatio': ['덧말 크기 Percent. 0=이면 기본 50%.', 'unsigned char'],
				'StyleNo': ['스타일번호 (옵션이 켜있을 때)', 'unsigned char'],
				'Align': ['덧말의 좌우 Align', 'unsigned char'],
				'Delete': ['덧말 지움 (글2007에 새로 추가)', 'unsigned char'],
				'Modify': ['덧말 편집 모드 여부 (글2007에 새로 추가)', 'unsigned char'],
				'DoAnyCursorEdit': ['마우스로 두 번 누르기 한곳에 입력가능', 'unsigned char'],
				'DoOutLineStyle': ['개요 번호 삽입 문단에 개요 스타일 자동 적용', 'unsigned char'],
				'InsertLock': ['삽입 잠금', 'unsigned char'],
				'TabMoveCell': ['표 안에서 <Tab>으로 셀 이동', 'unsigned char'],
				'FaxDriver': ['팩스 드라이버', 'string'],
				'PDFDriver': ['PDF 드라이버', 'string'],
				'EnableAutoSpell': ['맞춤법 도우미 작동', 'unsigned char'],
				'BaseUnit': ['수식이 삽입되는 앞의 글자와 같은 높이 (기본 값은 POINT 10 )', 'long'],
				'LineMode': ['줄 단위를 사용할지의 여부 (글2007에 새로 추가)', 'long'],
				'Version': ['수식 스크립트 버전 정보 (글2007에 새로 추가)', 'string'],
				'Flag': ['', 'unsigned char'],
				'FieldDirty': ['필드가 초기화 상태인지 수정되어 있는 상태인지 여부, (글2007에 새로 추가)', 'unsigned char'],
				'CtrlData': ['필드 이름 저장을 위한 영역', 'set'],
				'SrcFileList': ['Source 파일 리스트', 'array'],
				'DestFileList': ['Destination 파일 리스트', 'array'],
				'VersionStr': ['파일의 버전 문자열, ex)5.0.0.3', 'string'],
				'VersionNum': ['파일의 버전], ex) 0x05000003', 'unsigned long'],
				'Encrypted': ['암호 여부', 'long'],
				'OpenFileName': ['파일 이름 (OpenFileName과 SaveFileName은 같은 아이템을 공 유한다. 즉 OpenFileName과 SaveFileName은 이름만 다를 뿐 동 일한 아이템이다)', 'string'],
				'SaveFileName': [''],
				'OpenFormat': ['파일 형식', 'string'],
				'SaveFormat': [''],
				'OpenReadOnly': ['읽기 전용', 'unsigned char'],
				'OpenFlag': ['', 'unsigned char'],
				'SaveOverWrite': ['덮어 쓰기', 'unsigned char'],
				'ModifiedFlag': ['Modify 플래그', 'unsigned char'],
				'Argument': ['Argument', 'string'],
				'SaveCMFDoc30': ['97 호환 저장 (글2007에 새로 추가)', 'unsigned char'],
				'SaveHwp97': ['97 문서로 저장 (글2007에 새로 추가)', 'unsigned char'],
				'SaveDistribute': ['배포용 문서로 저장 (글2007에 새로 추가)', 'unsigned char'],
				'SaveDRMDoc': ['보안 문서로 저장 (글2007에 새로 추가)', 'unsigned char'],
				'To': ['받는 사람', 'string'],
				'Subject': ['제목', 'string'],
				'Filepath': ['사용자가 직접 입력한 파일 (이 아이템은 Type 아이템이 1(첨부파 일)로 설정되어 있을 때만 유효하다) (글2007에 새로 추가)', 'string'],
				'Password': ['배포용 문서 암호(7자리 이상 가능)', 'string'],
				'NoPrint': ['프린트 가능한 배포용 문서를 만들지의 여부', 'unsigned char'],
				'NoCopy': ['문서 내용 복사가 가능한 배포용 문서를 만들지의 여부', 'unsigned char'],
				'FindString': ['찾을 문자열', 'string'],
				'ReplaceString': ['바꿀 문자열', 'string'],
				'Direction': ['찾을 방향', 'unsigned char'],
				'MatchCase': ['대소문자 구별 ', 'unsigned char'],
				'AllWordForms': ['문자열 결합 ', 'unsigned char'],
				'SeveralWords': ['여러 단어 찾기 ', 'unsigned char'],
				'UseWildCards': ['아무개 문자 ', 'unsigned char'],
				'WholeWordOnly': ['온전한 낱말 ', 'unsigned char'],
				'AutoSpell': ['토씨 자동 교정 ', 'unsigned char'],
				'ReplaceMode': ['찾아 바꾸기 모드 ', 'unsigned char'],
				'IgnoreFindString': ['찾을 문자열 무시 ', 'unsigned char'],
				'IgnoreReplaceStrin g': ['바꿀 문자열 무시 ', 'unsigned char'],
				'FindCharShape': ['찾을 글자 모양', 'set'],
				'FindParaShape': ['찾을 문단 모양', 'set'],
				'ReplaceCharShape': ['바꿀 글자 모양', 'set'],
				'ReplaceParaShape': ['바꿀 문단 모양', 'set'],
				'FindStyle': ['찾을 스타일', 'string'],
				'ReplaceStyle': ['바꿀 스타일', 'string'],
				'IgnoreMessage': ['메시지박스 표시 안함. ', 'unsigned char'],
				'HanjaFromHangul': ['한글임으로 한자 차기', 'unsigned char'],
				'FindJaso': ['자소로 찾기 ', 'unsigned char'],
				'FindRegExp': ['정규식(조건식)으로 찾기 (on/off) (ver:0x06050107)', 'unsigned char'],
				'FindType': ['다시 찾기를 할 때 마지막으로 실행한 (찾기 TRUE)를 할 것인가, (찾아가기 FALSE)할 것인가의 여부 (ver:0x06050110)', 'unsigned char'],
				'Base': ['경로의 Base', 'string'],
				'Qulaity': ['재생 품질', 'string'],
				'Scale': ['스케일', 'string'],
				'WMode': ['윈도우 모드', 'string'],
				'AutoPlay': ['자동 재생 여부', 'unsigned char'],
				'LoopPlay': ['반복 재생 여부', 'unsigned char'],
				'ShowMenu': ['메뉴 보이기', 'unsigned char'],
				'BgColor': ['배경색 (COLORREF)', 'unsigned long'],
				'NumberFormat': ['번호모양', 'unsigned char'],
				'UserChar': ['사용자 기호 (WCHAR)', 'unsigned short'],
				'PrefixChar': ['앞 장식 문자 (WCHAR)', 'unsigned short'],
				'Suffix': ['뒤 장식 문자 (WCHAR)', 'unsigned short'],
				'PlaceAt': ['위치, - 각주용 옵션 (한 페이지 내에서 각주를 다단에 어떻게 위치시킬 지)', 'unsigned char'],
				'Restart': ['번호 매기기', 'unsigned char'],
				'LineLength': ['구분선 길이 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'SpaceAboveLine': ['구분선 위 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'SpaceBelowLine': ['구분선 아래 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'SpaceBetweenNotes': ['주석 사이 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'BeneathText': ['텍스트에 이어 바로 출력할지 여부 ', 'unsigned char'],
				'Server': ['Ftp 서버 내임', 'string'],
				'UserName': ['사용자 이름', 'string'],
				'Directory': ['디렉터리', 'string'],
				'SiteName': ['사이트 이름', 'array'],
				'SaveType': ['저장할 포맷', 'unsigned int'],
				'SetSelectionIndex': ['현재 선택되어 있는 라디오 값 (글2007에 새로 추가)', 'unsigned char'],
				'DialogResult': ['대화상자의 반환값 (글2007에 새로 추가)', 'unsigned int'],
				'Method': ['격자 방식', 'unsigned char'],
				'HorzAlign': ['격자 기준 가로 offset (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'VertAlign': ['격자 기준 세로 offset (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'HorzSpan': ['가로 간격 (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'unsigned int'],
				'VertSpan': ['세로 간격 (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'unsigned int'],
				'HorzRange': ['가로 자석 범위 (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'PIT_U'],
				'VertRange': ['세로 자석 범위 (단위  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'PIT_U'],
				'Show': ['격자 보이기 ', 'unsigned char'],
				'ZOrder': ['격자 위치(글 위/글 아래) (ZOrder)', 'unsigned char'],
				'ViewLine': ['선격자 보이기 종류 (글2007에 새로 추가)', 'unsigned char'],
				'DialogOption': ['머리말/꼬리말 대화상자를 실행할 때 편집버튼을 보일 것인지 말 것인지 지정한다., 1:편집버튼 보이기, 그 외:편집버튼 안보이기', 'unsigned int'],
				'CtrlType': ['머리말/꼬리말 여부', 'unsigned int'],
				'HeaderFooterCtrlType': ['머리말/꼬리말 종류', 'unsigned int'],
				'HeaderFooterStyle': ['머리말/꼬리말 마당 스타일', 'unsigned int'],
				'NoLInk': ['연결 안함 여부', 'int'],
				'ShapeObject': ['그림 및 그리기객체가 Selection되어 있는지 여부', 'int'],
				'DirectInsert': ['현재 캐럿 위치에 무조건 하이퍼링크 삽입 여부 (블록지정 상태면 블록해제 후 삽입) (글2007에 새로 추가)', 'int'],
				'Source': ['Source에 대한 Object Path', 'string'],
				'Target': ['이동할 Target에 대한 Object Path', 'string'],
				'InputText': ['삽입될 스트링/끼워 넣을 파일', 'string'],
				'InputType': ['입력기 상용구/한글 상용구', 'unsigned char'],
				'First': ['첫 번째 키', 'string'],
				'Second': ['두 번째 키', 'string'],
				'DateStyleType': ['문자열로 넣기/코드로 넣기', 'unsigned char'],
				'DateStyleDataForm': ['필드 컨트롤의 안내문/지시문', 'string'],
				'ShowSingle': ['문서마당 정보 대화상자에서 페이지(탭) 보이기 옵션 :, -1:모든 페이지 보이기', 'int'],
				'TemplateDirection': ['필드 컨트롤의 안내문/지시문', 'string'],
				'TemplateHelp': ['필드 컨트롤의 도움말', 'string'],
				'TemplateName': ['필드 이름 (name)', 'string'],
				'TemplateType': ['필드의 종류.TemplateDirection/Help/Name의 값이 실제로 적용되는 위치', 'unsigned char'],
				'FileFormat': ['삽입할 파일의 확장자', 'string'],
				'FileArg': ['삽입할 파일의 Argument', 'string'],
				'KeepSection': ['끼워 넣을 문서를 구역으로 나누어 쪽 모양을 유지할지 여부 on/off (ver:0x0605010E)', 'unsigned char'],
				'KeepCharshape': ['끼워 넣을 문서의 글자 모양을 유지할지 여부 on/off (글2007에 새로 추가)', 'unsigned char'],
				'KeepParashape': ['끼워 넣을 문서의 문단 모양을 유지할지 여부 on / onff (글2007에 새로 추가)', 'unsigned char'],
				'KeepStyle': ['끼워 넣을 문서의 스타일을 유지할지 여부 on / onff (글2010에 새로 추가)', 'unsigned char'],
				'OpenUrlWhere': ['웹브라우저로 불러오거나 한글 문서로 불러오기', 'unsigned int'],
				'OpenUrlString': ['불러올 문서가 존재하는 URL', 'string'],
				'RepeatCount': ['실행 반복 횟수', 'int'],
				'PageInherit': ['TRUE:쪽 번호 잇기, FALSE:쪽 번호 잇지 않기.', 'unsigned char'],
				'FootnoteInherit': ['TRUE:각주 번호 잇기, FALSE:각주 번호 잇지 않기.', 'unsigned char'],
				'List': ['현재 위치한 리스트', 'unsigned int'],
				'Para': ['현재 위치한 문단', 'unsigned int'],
				'TextDirection': ['글자 방향. (세부 스펙은 미정)', 'unsigned char'],
				'LineWrap': ['경계에서 줄 나눔 방식', 'unsigned char'],
				'MarginLeft': ['각 방향 여백', 'long'],
				'MarginRight': ['각 방향 여백', 'long'],
				'MarginTop': ['각 방향 여백', 'long'],
				'MarginBottom': ['각 방향 여백', 'long'],
				'Input': ['자료 종류', 'unsigned char'],
				'HwpPath': ['Hwp 문서 경로.', 'string'],
				'HwpId': ['Hwp 문서 ID', 'unsigned int'],
				'DbfPath': ['dbf file path', 'string'],
				'DbfCode': ['dbf file codepage', 'unsigned char'],
				'Output': ['출력 방향', 'unsigned char'],
				'Continue': ['쪽번호 잇기', 'unsigned char'],
				'PrintSet': ['인쇄 선택 사항', 'set'],
				'Field': ['메일 주소 필드', 'string'],
				'FieldUpdate': ['필드 단위 업데이트 (글2007에 새로 추가)', 'unsigned char'],
				'NxlPath': ['넥셀 파일 경로 (글2007에 새로 추가)', 'string'],
				'Make': ['생성할 차례의 종류, 다음의 값들의 조합이다', 'unsigned int'],
				'Level': ['개요 수준', 'int'],
				'AutoTabRight': ['문단 오른쪽 끝 자동 탭 여부', 'char'],
				'Leader': ['오른쪽 끝 탭 채울 모양(선 종류)', 'unsigned int'],
				'OutlineNumber': ['개요 문단 모으기', 'char'],
				'Styles': ['모을 스타일 목록', 'array'],
				'StyleName': ['모을 스타일 이름들', 'string'],
				'OutFileName': ['만들 파일 이름. 이면 현재 문서에 생성', 'string'],
				'Position': ['만들 위치. 반드시 0이어 한다. (글 컨트롤은 탭이 없으므로) (글2007에 새로 추가)', 'string'],
				'Duplicate': ['기존 바탕쪽과 겹침 (On/Off) (글2007에 새로 추가)', 'unsigned char'],
				'Front': ['바탕쪽과 앞으로 보내기 (On/Off) (글2007에 새로 추가)', 'unsigned char'],
				'FillColor': ['채우기 색깔 (COLORREF)', 'unsigned long'],
				'ActiveFillColor': ['활성화된 채우기 색깔 (COLORREF)', 'unsigned long'],
				'MemoType': ['메모 종류 - 현재 사용안 함', 'unsigned long'],
				'XRelTo': ['가로 상대적 기준', 'unsigned long'],
				'YRelTo': ['세로 상대적 기준', 'unsigned long'],
				'Page': ['페이지 번호 ( 0 based)', 'unsigned long'],
				'X': ['가로 클릭한 위치 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'Y': ['세로 클릭한 위치 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'Caption': ['자막 파일의 경로', 'string'],
				'AutoRewind': ['되감기 여부', 'unsigned char'],
				'ShowCtrlPanel': ['컨트롤 패널 보이기', 'unsigned char'],
				'ShowPosCtrl': ['위치 컨트롤 보이기', 'unsigned char'],
				'EnablePos': ['위치 컨트롤 조절 여부', 'unsigned char'],
				'ShowTrackBar': ['음량 조절막대(Track Bar) 보이기', 'unsigned char'],
				'EnableTrack': ['음량 조절 여부', 'unsigned char'],
				'ShowChaption': ['자막 보이기', 'unsigned char'],
				'ShowAudio': ['오디오 설정 보이기', 'unsigned char'],
				'ShowStatus': ['상태바 보기 (진행시간 등을 표시)', 'unsigned char'],
				'HasCharShapeLevel0': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
				'HasCharShapeLevel1': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
				'HasCharShapeLevel2': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
				'HasCharShapeLevel3': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
				'HasCharShapeLevel4': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
				'HasCharShapeLevel5': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
				'HasCharShapeLevel6': ['7개 수준별 자체적인 글자 모양을 사용할지 여부', 'unsigned char'],
				'CharShapeLevel0': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
				'CharShapeLevel1': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
				'CharShapeLevel2': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
				'CharShapeLevel3': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
				'CharShapeLevel4': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
				'CharShapeLevel5': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
				'CharShapeLevel6': ['7개 수준별 HasCharShapeLevel이 TRUE일 때만 사용되는 글자 모 양 정의', 'set'],
				'WidthAdjustLevel0': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'WidthAdjustLevel1': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'WidthAdjustLevel2': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'WidthAdjustLevel3': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'WidthAdjustLevel4': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'WidthAdjustLevel5': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'WidthAdjustLevel6': ['7개 수준별 번호 너비 보정값 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'TextOffsetLevel0': ['7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'TextOffsetLevel1': ['7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'TextOffsetLevel2': ['7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'TextOffsetLevel3': ['7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'TextOffsetLevel4': ['7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'TextOffsetLevel5': ['7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'TextOffsetLevel6': ['7개 수준별 본문과의 거리 (percent or  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'int'],
				'AlignmentLevel0': ['7개 수준별 번호 정렬', 'unsigned char'],
				'AlignmentLevel1': ['7개 수준별 번호 정렬', 'unsigned char'],
				'AlignmentLevel2': ['7개 수준별 번호 정렬', 'unsigned char'],
				'AlignmentLevel3': ['7개 수준별 번호 정렬', 'unsigned char'],
				'AlignmentLevel4': ['7개 수준별 번호 정렬', 'unsigned char'],
				'AlignmentLevel5': ['7개 수준별 번호 정렬', 'unsigned char'],
				'AlignmentLevel6': ['7개 수준별 번호 정렬', 'unsigned char'],
				'UseInstWidthLevel0': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
				'UseInstWidthLevel1': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
				'UseInstWidthLevel2': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
				'UseInstWidthLevel3': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
				'UseInstWidthLevel4': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
				'UseInstWidthLevel5': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
				'UseInstWidthLevel6': ['7개 수준별 번호 너비를 문서 내 문자열의 너비에 따를지 여부', 'unsigned char'],
				'AutoIndentLevel0': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
				'AutoIndentLevel1': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
				'AutoIndentLevel2': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
				'AutoIndentLevel3': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
				'AutoIndentLevel4': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
				'AutoIndentLevel0': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
				'AutoIndentLevel6': ['7개 번호 너비 자동 들여쓰기 여부', 'unsigned char'],
				'TextOffsetTypeLevel0': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
				'TextOffsetTypeLevel1': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
				'TextOffsetTypeLevel2': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
				'TextOffsetTypeLevel3': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
				'TextOffsetTypeLevel4': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
				'TextOffsetTypeLevel5': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
				'TextOffsetTypeLevel6': ['7개 수준별 본문과의 거리 종류 ', 'unsigned char'],
				'StrFormatLevel0': ['7개 수준별 포맷 문자열', 'string'],
				'StrFormatLevel1': ['7개 수준별 포맷 문자열', 'string'],
				'StrFormatLevel2': ['7개 수준별 포맷 문자열', 'string'],
				'StrFormatLevel3': ['7개 수준별 포맷 문자열', 'string'],
				'StrFormatLevel4': ['7개 수준별 포맷 문자열', 'string'],
				'StrFormatLevel5': ['7개 수준별 포맷 문자열', 'string'],
				'StrFormatLevel6': ['7개 수준별 포맷 문자열', 'string'],
				'NumFormatLevel0': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
				'NumFormatLevel1': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
				'NumFormatLevel2': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
				'NumFormatLevel3': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
				'NumFormatLevel4': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
				'NumFormatLevel5': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
				'NumFormatLevel6': ['7개 수준별 번호 모양 번호모양', 'unsigned char'],
				'StartNumber': ['시작 번호 (0:앞 구역에 이어, n:지정한 번호로 시작)* 0은 구역의 개요 정의에만 사용된다.', 'unsigned short'],
				'NewList': ['새로운 번호 목록을 시작할지 여부, * 문단 모양(ParaShap)의 서브셋으로 포함될 때만 의미 있다., * get일 때는 이 아이템은 아예 생성되지 않으며, set일 때는 TRUE가 아니면 NumberingShape 서브셋 전체가 지정되지 않은 것 처럼 무시된다.', 'unsigned char'],
				'Clsid': ['클래스 ID 새로 개체 생성 일 때 사용', 'string'],
				'Path': ['파일 경로(‘파일로 링크된 개체 생성’, ‘파일로부터 개체 생성’일 때 사용)', 'string'],
				'Aspect': ['생성된 OLE 개체를 아이콘으로 표시할지 여부', 'int'],
				'IconMetafile': ['Aspect가 아이콘일 때 적용할 아이콘 데이터', 'any'],
				'IconMM': ['Aspect가 아이콘일 때 아이콘 매핑모드', 'int'],
				'IconXext': ['Aspect가 아이콘일 때 X축 매핑단위', 'int'],
				'IconYext': ['Aspect가 아이콘일 때 Y축 매핑단위', 'int'],
				'InnerOCX': ['글 내부에서 사용되는 OCX인지 여부 (예: 글의 Chart OLE)', 'int'],
				'SoProperties': ['초기 shape object 속성', 'set'],
				'FlashProperties': ['플래시 파일 삽입 시 필요한 옵션 셋 (글2007에 새로 추가)', 'set'],
				'MovieProperties': ['동영상 파일 삽입 시 필요한 옵션 셋 (글2007에 새로 추가)', 'set'],
				'TextBorder': ['TRUE:본문 기준, FALSE:종이 기준', 'unsigned char'],
				'HeaderInside': ['머리말 포함 ', 'unsigned char'],
				'FooterInside': ['꼬리말 포함 ', 'unsigned char'],
				'FillArea': ['채울 영역', 'unsigned char'],
				'OffsetLeft': ['4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT),왼쪽', 'int'],
				'OffsetRight': ['4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT),오른쪽', 'int'],
				'OffsetTop': ['4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT),위', 'int'],
				'OffsetBottom': ['4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 아래', 'int'],
				'PaperWidth': ['용지 가로 크기 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'PaperHeight': ['용지 세로 크기 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'Landscape': ['용지 방향', 'long'],
				'LeftMargin': ['왼쪽 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'RightMargin': ['오른쪽 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'TopMargin': ['위 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'BottomMargin': ['아래 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'HeaderLen': ['머리말 길이 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'FooterLen': ['꼬리말 길이 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'GutterLen': ['제본 여백 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'long'],
				'GutterType': ['편집 방법', 'unsigned char'],
				'Fields': ['감출 대상 비트 필드. 0x01:머리말', 'unsigned int'],
				'PageStartsOn': ['페이지 번호 적용 옵션', 'unsigned char'],
				'SuffixChar': ['뒤 장식 문자(WCHAR). 글2007에선 더 이상 사용하지 않는다.', 'unsigned short'],
				'SideChar': ['양쪽 옆 장식 문자(WCHAR). L-만 사용할 수 있다.', 'unsigned short'],
				'DrawPos': ['번호 위치', 'unsigned char'],
				'Indentation': ['들여쓰기/내어 쓰기 (URC)', 'long'],
				'PrevSpacing': ['문단 간격 위 (URC)', 'long'],
				'NextSpacing': ['문단 간격 아래 (URC)', 'long'],
				'LineSpacingType': ['줄 간격 종류 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'unsigned char'],
				'BreakLatinWord': ['줄 나눔 단위 (라틴 문자)', 'unsigned char'],
				'BreakNonLatinWord': ['단위 (비 라틴 문자)', 'unsigned char'],
				'SnapToGrid': ['편집 용지의 줄 격자 사용 ', 'unsigned char'],
				'Condense': ['공백 최소값 (0 - 75%)', 'unsigned char'],
				'WidowOrphan': ['외톨이줄 보호 ', 'unsigned char'],
				'KeepWithNext': ['다음 문단과 함께 ', 'unsigned char'],
				'KeepLinesTogether': ['문단 보호 ', 'unsigned char'],
				'PagebreakBefore': ['문단 앞에서 항상 쪽 나눔 ', 'unsigned char'],
				'TextAlignment': ['세로 정렬', 'unsigned char'],
				'FontLineHeight': ['글꼴에 어울리는 줄 높이 ', 'unsigned char'],
				'HeadingType': ['문단 머리 모양', 'unsigned char'],
				'BorderConnect': ['문단 테두리/배경 - 테두리 연결 ', 'unsigned char'],
				'BorderText': ['문단 테두리/배경 - 여백 무시', 'unsigned char'],
				'BorderOffsetLeft': ['문단 테두리/배경 - 4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 왼쪽', 'int'],
				'BorderOffsetRight': ['문단 테두리/배경 - 4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 오른쪽', 'int'],
				'BorderOffsetTop': ['문단 테두리/배경 - 4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 위', 'int'],
				'BorderOffsetBotto m': ['문단 테두리/배경 - 4방향 간격 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT), 아래', 'int'],
				'TailType': ['문단 꼬리 모양 (마지막 꼬리 줄 적용) ', 'unsigned char'],
				'TabDef': ['탭 정의', 'set'],
				'Numbering': ['문단 번호, 문단 머리 모양(HeadingType)이 ‘개요’, ‘번호’ 일 때 사용', 'set'],
				'Bullet': ['불릿 모양, 문단 머리 모양(HeadingType)이 ‘불릿’(글머리표) 일 때 사용', 'set'],
				'FullRange': ['TRUE:유니코드/모든 문자를 사용, FALSE:영문자만 사용', 'unsigned char'],
				'Ask': ['','unsigned', {0: '문서 암호를 확인', 1: '문서 암호를 설정'}],
				'ShowSinglePage': ['환경 설정 PropertySheet에 표시할 PropertyPage 번호, (하나만 선택)', 'int'],
				'ApplyLinkAttr': ['하이퍼링크 글자 속성 문서 전체에 적용하기 여부 (on/off) (글2007에 새로 추가)', 'unsigned char'],
				'ApplyForbidden': ['(금칙 처리) 새 문서에 기본 값으로 설정 (on/off) (글2007에 새로 추가)', 'string'],
				'StartForbiddenStr': ['(금칙 처리) 새 문서에 적용할 줄 앞 금칙 문자열, (글2007에 새로 추가)', 'string'],
				'EndForbiddenStr': ['(금칙 처리) 새 문서에 적용할 줄 뒤 금칙 문자열, (글2007에 새로 추가)', 'string'],
				'Effect': ['화면 전환 효과', 'unsigned int'],
				'Sound': ['효과음', 'any'],
				'InvertText': ['검은색 글자를 흰색으로', 'int'],
				'ShowMode': ['자동 전환 모드 (글2007에 새로 추가)', 'int'],
				'ShowPage': ['현재 쪽', 'unsigned int'],
				'ShowTime': ['전환 시간 (초)', 'unsigned int'],
				'Range': ['인쇄 범위', 'unsigned char'],
				'RangeCustom': ['사용자가 직접 입력한 인쇄 범위', 'string'],
				'RangeIncludeLinkedDoc': ['연결된 문서 포함', 'unsigned char'],
				'NumCopy': ['인쇄 매수', 'unsigned short'],
				'Collate': ['한 부씩 찍기', 'unsigned char'],
				'PrintMethod': ['인쇄 방법', 'unsigned char'],
				'PrinterPaperSize': ['공급용지 종류(DEVMODE.dmPaperSize)', 'int'],
				'PrinterPaperWidth': ['공급용지 종류(DEVMODE.dmPaperWidth)', 'int'],
				'PrinterPaperLength': ['공급용지 종류(DEVMODE.dmPaperLength)', 'int'],
				'PrintAutoHeadNote': ['머리말 자동 인쇄', 'unsigned char'],
				'PrintAutoFootNote': ['꼬리말 자동 인쇄', 'unsigned char'],
				'PrintAutoHeadnoteLtext': ['자동 머리말의 왼쪽 String', 'string'],
				'PrintAutoHeadnoteCtext': ['자동 머리말의 가운데 String', 'string'],
				'PrintAutoHeadnoteRtext': ['자동 머리말의 오른쪽 String', 'string'],
				'PrintAutoFootnoteLtext': ['자동 꼬리말의 왼쪽 String', 'string'],
				'PrintAutoFootnoteCtext': ['자동 꼬리말의 가운데 String', 'string'],
				'PrintAutoFootnoteRtext': ['자동 꼬리말의 오른쪽 String', 'string'],
				'PrinterName': ['프린터', 'string'],
				'PrintToFile': ['인쇄 결과를 파일로 저장', 'unsigned char'],
				'ReverseOrder': ['역순 인쇄', 'unsigned char'],
				'Pause': ['끊어 찍기 매수', 'unsigned short'],
				'PrintImage': ['그림 개체', 'unsigned char'],
				'PrintDrawObj': ['그리기 개체', 'unsigned char'],
				'PrintClickHere': ['누름틀', 'unsigned char'],
				'PrintCropMark': ['편집 용지 표시', 'unsigned char'],
				'IdcPrintWallPaper': ['배경 그림', 'unsigned char'],
				'LastBlankPage': ['빈 마지막 쪽', 'unsigned char'],
				'BinderHoleType': ['바인더 구멍', 'unsigned char'],
				'EvenOddPageType': ['홀짝 인쇄', 'unsigned char'],
				'ZoomX': ['가로 확대', 'unsigned short'],
				'ZoomY': ['세로 확대', 'unsigned short'],
				'StartPageNum': ['시작 번호/쪽 번호', 'unsigned int'],
				'StartFootNoteNum': ['시작 번호/각주 번호', 'unsigned int'],
				'Flags': ['문제 해결을 위한 고급 선택 사항', 'unsigned int'],
				'Device': ['인쇄 방향(장치)', 'unsigned char'],
				'PrintFormObj': ['양식 개체 출력여부 (글2007에 새로 추가)', 'unsigned char'],
				'PrintMarkPen': ['형광펜 출력여부 (글2007에 새로 추가)', 'unsigned char'],
				'PrintMemo': ['메모 출력여부 (글2007에 새로 추가)', 'unsigned char'],
				'PrintMemoContents': ['메모 내용 출력여부 (글2007에 새로 추가)', 'unsigned char'],
				'PrintRevision': ['교정부호 출력여부 (글2007에 새로 추가)', 'unsigned char'],
				'PrintWatermark': ['인쇄워터마크 (글2007에 새로 추가)', 'set'],
				'ColorDepth': ['색상수 (bits: 8], 16...)', 'unsigned char'],
				'Resolution': ['해상도', 'unsigned short'],
				'WatermarkType': ['현재 선택된 워터마크의 유형을 나타냄', 'unsigned int'],
				'PosPage': ['워터마크의 위치 기준', 'unsigned char'],
				'TextWrap': ['워터마크의 배치', 'unsigned char'],
				'AlphaText': ['글자 투명도 (0 ~ 255)', 'unsigned char'],
				'AlphaImage': ['그림 투명도 (0 ~ 255)', 'unsigned char'],
				'FontSize': ['글꼴 크기 ( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT', 'int'],
				'FontColor': ['글자색 (COLORREF)', 'unsigned long'],
				'RotateAngle': ['회전각도 (-360 ~ 360)', 'int'],
				'WaterMarkEff': ['워터마크 효과', 'unsigned char'],
				'LauncherKey': ['빠른 교정을 실행한 키 정보 (글2007에 새로 추가)', 'unsigned char'],
				'HyperLinkRunKey': ['', 'uRL 또는 email 하이퍼링크 작성 키 정보 (글2007에 새로 추가)', 'unsigned char'],
				'SignType': ['교정부호 종류', 'unsigned int'],
				'Margin': ['여백( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT). 오른자리 옮김표와 왼자리 옮김표일 경우에만 적용.', 'long'],
				'BeginPos': ['시작위치( HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT). 오른자리 옮김표와 왼자리 옮김표일 경우에만 적용.', 'long'],
				'Detail': ['매크로 설명', 'string'],
				'StartsOn': ['구역 나눔으로 새 페이지가 생길 때의 페이지 번호 적용 옵션', 'unsigned char'],
				'LineGrid': ['세로로 줄맞춤을 할지 여부', 'long'],
				'CharGrid': ['가로로 줄맞춤을 할지 여부', 'long'],
				'PageDef': ['용지 설정 정보', 'set'],
				'HideEmptyLine': ['빈 줄 감춤 ', 'unsigned char'],
				'SpaceBetweenColumns': ['동일한 페이지에서 서로 다른 단 사이의 간격', 'long'],
				'TabStop': ['기본 탭 간격', 'long'],
				'FootnoteShape': ['각주 모양', 'set'],
				'EndnoteShape': ['미주 모양', 'set'],
				'HideHeader': ['구역의 첫 쪽에만 머리말 감추기 옵션 ', 'unsigned char'],
				'HideFooter': ['구역의 첫 쪽에만 꼬리말 감추기 옵션 ', 'unsigned char'],
				'HideMasterPage': ['구역의 첫 쪽에만 바탕쪽 감추기 옵션 ', 'unsigned char'],
				'HideBorder': ['구역의 첫 쪽에만 테두리 감추기 옵션 ', 'unsigned char'],
				'HideFill': ['구역의 첫 쪽에만 배경 감추기 옵션 ', 'unsigned char'],
				'HidePageNumPos': ['구역의 첫 쪽에만 쪽번호 감추기 옵션 ', 'unsigned char'],
				'FirstBorder': ['구역의 첫 쪽에만 테두리 표시 옵션 ', 'unsigned char'],
				'FirstFill': ['구역의 첫 쪽에만 배경 표시 옵션 ', 'unsigned char'],
				'OutlineShape': ['개요 번호', 'set'],
				'PageBorderFillBoth': ['쪽 테두리/배경  (양쪽)', 'set'],
				'PageBorderFillEven': ['쪽 테두리/배경  (짝수)', 'set'],
				'PageBorderFillOdd': ['쪽 테두리/배경  (홀수)', 'set'],
				'PageNumber': ['쪽 시작 번호', 'unsigned short'],
				'FigureNumber': ['그림 시작 번호', 'unsigned short'],
				'TableNumber': ['표 시작 번호', 'unsigned short'],
				'EquationNumber': ['수식 시작 번호', 'unsigned short'],
				'WongojiFormat': ['원고지 방식의 포맷팅. CHAR_GRID가 지정되어 함.', 'unsigned char'],
				'MemoShape': ['메모 모양 (글2007에 새로 추가)', 'set'],
				'TextVerticalWidthHead': ['머리말/꼬리말 세로쓰기 여부 (글2007에 새로 추가)', 'int'],
				'ApplyToPageBorderFill': ['채울 영역 분류 (PageBorder 액션에서 사용)', 'unsigned char'],
				'ConvAplly2Index': ['ApplyTo값을 ComboBox의 Index로 변환할지 여부, FALSE이면 IndexToApply로 변환이 이루어진다. (반대변환)', 'int'],
				'Category': ['적용범위 분류(ApplyClass)를 사용자가 직접 설정할 때 사용. 아이템이  없으면  글이  현재  상태에  맞춰  적용범위  분류 (ApplyClass)를 설정한다. (일반적으로 설정하지 않고 사용)', 'int'],
				'CellAttr': ['셀 모양 복사', 'unsigned char'],
				'CellBorder': ['선 모양 복사', 'unsigned char'],
				'CellFill': ['셀 배경 복사', 'unsigned char'],
				'TypeBodyAndCellOnly': ['본문과 셀 모양 둘 다 복사 or 셀 모양만 복사, (글2007에 새로 추가)', 'int'],
				'TreatAsChar': ['글자처럼 취급 ', 'unsigned char'],
				'AffectsLine': ['줄 간격에 영향을 줄지 여부 on/off (TreatAsChar가 TRUE일 경우에만 사용된다)', 'unsigned char'],
				'VertRelTo': ['세로 위치의 기준', 'unsigned char'],
				'VertOffset': ['VertRelTo와  VertAlign을  기준으로  한  Y축  위치  오프셋  값.  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위.', 'long'],
				'HorzRelTo': ['가로 위치의 기준', 'unsigned char'],
				'HorzOffset': ['HorzRelTo와  HorzAlign을  기준으로  한  X축  위치  오프셋  값.  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위.', 'long'],
				'FlowWithText': ['그리기 개체의 세로 위치를 쪽 영역 안쪽으로 제한할지 여부 on/off, VertRelTo값이 2(문단영역)일 경우에만 의미가 있다.', 'unsigned char'],
				'AllowOverlap': ['다른 개체와 겹치는 것을 허용할지 여부 on/offTreatAsChar가 FALSE일 때만 의미가 있으며, FlowWithText가 TRUE이면 AllowOverlap은 항상 FALSE로 간주한다.', 'unsigned char'],
				'WidthRelTo': ['개체 너비 기준', 'unsigned char'],
				'HeightRelTo': ['개체 높이 기준', 'unsigned char'],
				'ProtectSize': ['크기 보호 ', 'unsigned char'],
				'TextFlow': ['그리기  개체의  좌/우  어느  쪽에  글을  배치할지  지정하는  옵션. TextWrap의 값이 0일 때만 유효하다', 'unsigned char'],
				'OutsideMarginLeft': ['개체의 바깥 여백. (왼쪽)  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위', 'long'],
				'OutsideMarginRight': ['개체의 바깥 여백. (오른쪽)  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위', 'long'],
				'OutsideMarginTop': ['개체의 바깥 여백. (위)  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위', 'long'],
				'OutsideMarginBottom': ['개체의 바깥 여백. (아래)  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위', 'long'],
				'NumberingType': ['이 개체가 속하는 번호 범주', 'unsigned char'],
				'LayoutWidth': ['개체가 페이지에 배열될 때 계산되는 폭의 값', 'long'],
				'LayoutHeight': ['개체가 페이지에 배열될 때 계산되는 높이 값', 'long'],
				'Lock': ['개체 보호하기 ', 'unsigned char'],
				'HoldAnchorObj': ['쪽 나눔 방지 on/off (글2007에 새로 추가)', 'unsigned char'],
				'AdjustSelection': ['개체 Selection 상태 TRUE/FASLE (글2007에 새로 추가)', 'unsigned char'],
				'AdjustTextBox': ['글상자로 TRUE/FASLE (글2007에 새로 추가)', 'unsigned char'],
				'AdjustPrevObjAttr': ['앞개체 속성 따라가기 TRUE/FASLE (글2007에 새로 추가)', 'unsigned char'],
				'ShapeDrawLayOut': ['그리기 개체의 Layout', 'set'],
				'ShapeDrawLineAttr': ['그리기 개체의 Line 속성', 'set'],
				'ShapeDrawFillAttr': ['그리기 개체의 Fill 속성', 'set'],
				'ShapeDrawImageAttr': ['그림 개체 속성', 'set'],
				'ShapeDrawRectType': ['사각형 그리기 개체 유형', 'set'],
				'ShapeDrawArcType': ['호 그리기 개체 유형', 'set'],
				'ShapeDrawResize': ['그리기 개체 리사이징', 'set'],
				'ShapeDrawRotate': ['그리기 개체 회전', 'set'],
				'ShapeDrawEditDetail': ['그리기 개체 EditDetail', 'set'],
				'ShapeDrawImageScissoring': ['그림 개체 자르기', 'set'],
				'ShapeDrawScAction': ['그리기 개체 회전', 'set'],
				'ShapeDrawCtrlHyperlink': ['그리기 개체 하이퍼링크', 'set'],
				'ShapeDrawCoordInfo': ['그리기 개체 좌표정보', 'set'],
				'ShapeDrawShear': ['그리기 개체 기울이기', 'set'],
				'ShapeDrawTextart': ['글맵시', 'set'],
				'ShapeDrawShadow': ['그림자', 'set'],
				'ShapeTableCell': ['셀 정보', 'set'],
				'ShapeListProperties': ['서브 list 속성', 'set'],
				'ShapeCaption': ['캡션', 'set'],
				'ShapeFormGeneral': ['양식개체 일반', 'set'],
				'ShapeFormCommonAttr': ['양식개체 공통속성', 'set'],
				'ShapeFormCharshapeattr': ['양식개체 글자모양 속성', 'set'],
				'ShapeFormButtonAttr': ['양식개체 버튼 속성', 'set'],
				'ShapeFormComboboxAttr': ['양식개체 콤보박스 속성', 'set'],
				'ShapeFormEditAttr': ['양식개체 에디트박스 속성', 'set'],
				'ShapeFormScrollbarAttr': ['양식개체 스크롤바 속성', 'set'],
				'ShapeFormListBoxAttr': ['양식개체 리스트박스 속성', 'set'],
				'ShapeType': ['TablePropertyDialog 의 종류', 'unsigned char'],
				'ShapeCellSize': ['셀 크기 적용 여부 ', 'unsigned char'],
				'ShapeCreationType': ['그리기 개체 형태 (DrawObjCreatorObject에서 사용)', 'unsigned char'],
				'ShapeCreationMode': ['마우스로 그리기 여부 (on/off) (DrawObjCreatorObject에서 사용)', 'unsigned char'],
				'ShapeObjectLine': ['그리기 선 모양 복사', 'unsigned int'],
				'ShapeObjectFill': ['그리기 채우기 복사', 'unsigned char'],
				'ShapeObjectSize': ['그리기 개체 크기 복사', 'unsigned char'],
				'ShapeObjectShadow': ['그리기 개체 그림자 복사', 'unsigned char'],
				'ShapeObjectPicEffect': ['그림 효과 복사', 'unsigned char'],
				'KeyOption': ['키 콤보에서 선택된 키를 저장함.', 'array'],
				'CheckJasoReverse': ['자소 단위 비교 Flag - 종], 중], 초', 'unsigned char'],
				'DelimiterType': ['필드 구분 기호 형식', 'unsigned char'],
				'DelimiterChars': ['필드 구분 기호들. DelimiterType이 3(사용자 정의)일 경우에만 유효', 'string'],
				'IgnoreMultiDelimiter': ['연속되는 구분기호 무시 Flag', 'unsigned char'],
				'CheckFromRear': ['단어 뒤에서 부터 비교 Flag', 'unsigned char'],
				'CheckExtendYear': ['두 자리 년도 확장 check Flag', 'unsigned char'],
				'YearBase': ['두 자리 년도 시작 년도', 'unsigned int'],
				'LangOrderType': ['사전언어순서 값', 'unsigned char'],
				'CheckJaso': ['자소 단위 비교 Flag - 초, 중, 종', 'unsigned char'],
				'Apply': ['적용할 스타일 인덱스', 'int'],
				'Alternation': ['대체할 스타일 인덱스', 'int'],
				'Sum': ['합', 'string'],
				'Average': ['평균', 'string'],
				'LineCount': ['줄 수', 'string'],
				'Comma': ['세 자리마다 쉼표로 자리 구분 ', 'unsigned char'],
				'Title': ['제목', 'string'],
				'Author': ['지은이', 'string'],
				'Date': ['날짜', 'string'],
				'KeyWords': ['키워드', 'string'],
				'Comments': ['기타', 'string'],
				'CreationTimeLow': ['작성한 날짜 (low)', 'unsigned long'],
				'CreationTimeHigh': ['작성한 날짜 (high)', 'unsigned long'],
				'ModifiedTimeLow': ['마지막 수정한 날짜 (low)', 'unsigned long'],
				'ModifiedTimeHigh': ['마지막 수정한 날짜 (high)', 'unsigned long'],
				'PrintedTimeLow': ['마지막 인쇄한 날짜 (low)', 'unsigned int'],
				'PrintedTimeHigh': ['마지막 인쇄한 날짜 (high)', 'unsigned long'],
				'LastSavedBy': ['마지막 저장한 사람', 'string'],
				'Characters': ['문서분량 (글자)', 'int'],
				'Words': ['문서분량 (낱말)', 'int'],
				'Lines': ['문서분량 (줄)', 'int'],
				'Paragraphs': ['문서분량 (문단)', 'int'],
				'Pages': ['문서분량 (쪽)', 'int'],
				'CopyPapers': ['문서분량 (원고지)', 'int'],
				'Etcetera': ['문서분량 (표], 그림 등)', 'int'],
				'DocVersion': ['문서 파일 버전 (글2007에 새로 추가)', 'string'],
				'HwpVersion': ['문서를 생성한 글 워드프로그램의 버전 (글2007에 새로 추가)', 'string'],
				'HanjaChar': ['문서분량 (한자 수) (글2007에 새로 추가)', 'char'],
				'AutoTabLeft': ['문단 왼쪽 끝 탭 ', 'unsigned char'],
				'TabItem': ['각각의 탭 정의.], 하나의 탭 아이템은 세 개의 인수로 표현되어 있음. (n * 3 + 0) - PIT_I', 'array'],
				'PageBreak': ['표가 페이지 경계에 걸렸을 때의 처리 방식', 'unsigned char'],
				'RepeatHeader': ['제목 행을 반복할지 여부. ', 'unsigned char'],
				'CellSpacing': ['셀 간격(HTML의 셀 간격과 동일 의미.  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT)', 'unsigned long'],
				'CellMarginLeft': ['기본 셀 안쪽 여백(왼쪽)', 'long'],
				'CellMarginRight': ['기본 셀 안쪽 여백(오른쪽)', 'long'],
				'CellMarginTop': ['기본 셀 안쪽 여백(위쪽)', 'long'],
				'CellMarginBottom': ['기본 셀 안쪽 여백(아래쪽)', 'long'],
				'TableCharInfo': ['표와 연결된 차트 정보 - 차트 미완성', 'set'],
				'Cell': ['셀 속성', 'set'],
				'Rows': ['행 수 (생략하면 5)', 'unsigned short'],
				'Cols': ['칼럼 수 (생략하면 5)', 'unsigned short'],
				'RowHeight': ['행의 디폴트 높이 (PIT_I4)', 'array'],
				'ColWidth': ['칼럼의 디폴트 폭 (PIT_I4)', 'array'],
				'CellInfo': ['정보가 없는 셀은 디폴트값을 따라가므로 모든 셀에 대해 정보를 줄 필요는 없다.', 'array'],
				'WidthType': ['너비', 'unsigned char'],
				'HeightType': ['높이', 'unsigned char'],
				'WidthValue': ['너비 값', 'int'],
				'HeightValue': ['높이 값', 'int'],
				'TableTemplateValue': ['표 마당 적용 여부 (글2007에 새로 추가)', 'unsigned char'],
				'TableProperties': ['초기 표 속성', 'set'],
				'TableTemplate': ['표마당 적용 속성 (글2007에 새로 추가)', 'set'],
				'TableDrawProperties': ['마우스로 선을 그릴 때 속성 (글2007에 새로 추가)', 'set'],
				'DistributeHeight': ['줄 높이를 같게', 'unsigned char'],
				'Merge': ['나누기 전에 합치기', 'unsigned char'],
				'Mode2': ['셀 나누기 모드 2], 셀 나누기를 할 때], adjust를 생략하고 셀이 어 긋나는 것을 방지한다. (글2007에 새로 추가)', 'unsigned char'],
				'UserDefine': ['사용자 정의 필드 구분 기호', 'string'],
				'AutoOrDefine': ['자동으로 할 것인지 분리 문자를 지정 할 것인지를 결정', 'unsigned char'],
				'KeepSeperator': ['선택 사항 (구분자 유지)', 'unsigned char'],
				'DelimiterEtc': ['기타 문자 필드 구분 기호', 'string'],
				'SwapMargin': ['여백 뒤집기 지원여부', 'unsigned char'],
				'ApplyTarger': ['적용 대상. 다음 값의 조합으로 구성된다', 'unsigned int'],
				'CreateMode': ['표 만들기 모드 (표 만들기에서 제목줄에 제목 속성 넣기 위해)', 'unsigned char'],
				'Landscope': ['용지 방향', 'unsigned char'],
				'Save': ['저장', 'long'],
				'LoadType': ['로드 방법', 'long'],
				'SourcePath': ['버전 비교용 소스 패스', 'string'],
				'TargetPath': ['버전 비교용 타겟 패스', 'string'],
				'ItemStartIndex': ['버전 비교를 보여줄 시작 히스토리 인덱스', 'unsigned char'],
				'ItemEndIndex': ['버전 비교를 보여줄 마지막 히스토리 인덱스', 'unsigned char'],
				'ItemOverWrite': ['히스토리  정보를  저장할  때  마지막  버전으로  덮어쓰는  플랙, ', 'unsigned char'],
				'ItemSaveDescription': ['히스토리 정보를 저장할 때 설명을 입력하는 대화상자를 띄우는 플 랙 ', 'unsigned char'],
				'TempFilePath': ['버전 비교용 임시파일 경로', 'array'],
				'ItemInfoIndex': ['버전 정보 얻어오기 및 삭제 시 사용될 인덱스', 'unsigned long'],
				'SaveFilePath': ['버전 저장 파일 경로(OCX 컨트롤용)', 'string'],
				'ItemInfoWriter': ['작성자 정보', 'string'],
				'ItemInfoDescription': ['해당 버전에 대한 설명', 'string'],
				'ItemInfoTimeHi': ['날짜 정보, FILETIME의 HIWORD', 'unsigned long'],
				'ItemInfoTimeLo': ['날짜 정보, FILETIME의 LOWORD', 'unsigned long'],
				'ItemInfoLock': ['히스토리 정보 수정 플랙', 'unsigned char'],
				'OptionFlag': ['뷰 옵션 플랙. 여러 개를 OR연산하여 지정할 수 있음', 'unsigned int'],
				'ZoomType': ['화면 확대 종류', 'unsigned char'],
				'ZoomRatio': ['화면 확대 종류가 사용자 정의인 경우 화면 확대 비율. 10% ~ 500%', 'unsigned short'],
				'ZoomCntX': ['화면 확대 종류가 여러 쪽인 경우 가로 페이지 수., 1 ~ 8', 'unsigned char'],
				'ZoomCntY': ['화면 확대 종류가 여러 쪽인 경우 세로 페이지 수., 1 ~ 8', 'unsigned char'],
				'ZoomMirror': ['맞쪽 보기. 페이지 수가 2의 배수일 때만 동작, (글2007에 새로 추가)', 'unsigned char'],
				'ViewPosX': ['현재 뷰의 X값', 'long'],
				'ViewPosY': ['현재 뷰의 Y값', 'long'],

		}

		#action용 파리미터 그룹의 이름에 있는 파라미터들
		self.varx["parameter_vs_parameter_option"]={
					'AutoFillSection': {0: '기본', 1: '사용자 정의', "default":0},
					'NumType': {0: '쪽 번호', 1: '각주 번호', 2: '미주 번호', 3: '그림 번호', 4: '표 번호', 5: '수식 번호'},
					'Type': {0: '일반 책갈피', 1: '블록 책갈피'},
					'Command': {0: '책갈피 생성', 1: '책갈피로 이동', 2: '책갈피 수정'},
					'SlashFlag': {0: '하단 대각선 bit', 1: '중앙 대각선 bit', 2: '상단 대각선'},
					'BackSlashFlag': {0: '하단 대각선 bit', 1: '중앙 대각선 bit', 2: '상단 대각선'},
					'BorderFill3D': {0: 'off', 1: 'on'},
					'Shadow': {0: 'off', 1: 'on'},
					'BreakCellSeparateLine': {0: '경계선 설정을 기본 값에 따름', 1: '사용자가 경계선 설정'},
					'CounterSlashFlag': {0: '순방향', 1: '역방향'},
					'CounterBackSlashFlag': {0: '순방향', 1: '역방향'},
					'CenterLineFlag': {0: '중심선 없음', 1: '중심선 있음'},
					'HasCharShape': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
					'Alignment': {0: '왼쪽 정렬', 1: '가운데 정렬', 2: '오른쪽 정렬'},
					'UseInstWidth': {0: 'off', 1: 'on'},
					'AutoIndent': {0: '들여쓰기 안함', 1: '들여쓰기'},
					'TextOffsetType': {0: 'percent', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
					'HasImage': {0: '일반 글머리표', 1: '그림 글머리표'},
					'Side': {0: '왼쪽', 1: '오른쪽', 2: '위', 3: '아래'},
					'HasMargin': {0: 'off', 1: 'on'},
					'Protected': {0: 'off', 1: 'on'},
					'Header': {0: 'off', 1: 'on'},
					'Editable': {0: 'off', 1: 'on'},
					'Dirty': {0: 'off', 1: 'on (글2007에 새로 추가)'},
					'ApplyTo': {0: '선택된 셀', 1: '전체 셀', 2: '여러 셀에 걸쳐 적용'},
					'FontTypeHangul': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
					'FontTypeLatin': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
					'FontTypeHanja': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
					'FontTypeJapanese': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
					'FontTypeOther': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
					'FontTypeSymbol': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
					'FontTypeUser': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
					'Bold': {0: 'off', 1: 'on'},
					'Italic': {0: 'off', 1: 'on'},
					'SmallCaps': {0: 'off', 1: 'on'},
					'Emboss': {0: 'off', 1: 'on'},
					'Engrave': {0: 'off', 1: 'on'},
					'SuperScript': {0: 'off', 1: 'on'},
					'SubScript': {0: 'off', 1: 'on'},
					'UnderlineType': {0: 'none', 1: 'bottom', 2: 'center', 3: 'top'},
					'OutlineType': {0: 'none', 1: 'solid', 2: 'dot', 3: 'thick', 4: 'dash', 5: 'dashdot', 6: 'dashdotdot'},
					'ShadowType': {0: 'none', 1: 'drop', 2: 'continuous'},
					'StrikeOutType': {0: 'none', 1: 'red single', 2: 'red double', 3: 'text single', 4: 'text double'},
					'DiacSymMark': {0: 'none', 1: '검정 동그라미', 2: '속 빈 동그라미'},
					'UseFontSpace': {0: 'off', 1: 'on'},
					'UseKerning': {0: 'off', 1: 'on'},
					'SameSize': {0: '단 너비 각자 지정', 1: '단 너비 동일'},
					'Layout': {0: '왼쪽부터', 1: '오른쪽부터', 2: '맞쪽'},
					'Number': {0: 'off', 1: 'on'},
					'Alpha': {0: 'off', 1: 'on'},
					'Symbol': {0: 'off', 1: 'on'},
					'Gata': {0: 'off', 1: 'on'},
					'HGJamo': {0: 'off', 1: 'on'},
					'Hanja': {0: 'off', 1: 'on'},
					'Hira': {0: 'off', 1: 'on 확장 또는 변환 액션 간 파라메터셋의 호환을 위해 선언됨.'},
					'Gu': {0: 'off', 1: 'on'},
					'CurCtrl': {0: '일반 텍스트', 1: '글상자', '기타': '컨트롤 ID'},
					'PicEffect': {0: '실제 이미지 그대로', 1: '그레이스케일', 2: '흑백 효과'},
					'DrawFillImageType': {0: '바둑판식으로', 1: '가로-위만 바둑판식으로 배열', 2: '가로-아래만 바둑판식으로 배열', 3: '세로-왼쪽만 바둑판식으로 배열', 4: '세로 오른쪽만 바둑판식으로 배열', 5: '크기에 맞추어', 6: '가운데로', 7: '가운데 위로', 8: '가운데 아래로', 9: '왼쪽 가운데로', 10: '왼쪽 위로', 11: '왼쪽 아래로', 12: '오른쪽 가운데로', 13: '오른쪽 위로', 14: '오른쪽 아래로'},
					'RotateImage': {0: '회전 안 함', 1: '회전함'},
					'FontType': {0: 'do not care', 1: 'TTF', 2: 'HFT'},
					'PosType': {0: '위', 1: '아래'},
					'Align': {0: '양쪽 정렬', 1: '왼쪽 정렬', 2: '오른쪽 정렬', 3: '가운데 정렬', 4: '배분 정렬', 5: '나눔 정렬'},
					'Flag': {0: '모든 각주를 미주로 바꾸기', 1: '모든 미주를 각주로 바꾸기', 2: '각주와 미주를 서로 바꾸기'},
					'OpenFlag': {0: '새 창으로 열기', 1: '현재 창의 새 탭에 열기', 2: '현재 창의 현재 탭에 열기', 3: '위 세 값의 mask', 4: '이미 열려진 문서일 때 다시 load할지 뭍을 것인지', 8: '초기 모드를 최근 작업 문서 상태로, 0x10:문서 마당'},
					'NoPrint': {0: '프린트 가능', 1: '프린트 가능하지 않음'},
					'NoCopy': {0: '복사 가능', 1: '복사 가능하지 않음'},
					'Direction': {0: '아래쪽', 1: '위쪽', 2: '문서 전체'},
					'MatchCase': {0: 'off', 1: 'on'},
					'AllWordForms': {0: 'off', 1: 'on'},
					'SeveralWords': {0: 'off', 1: 'on'},
					'UseWildCards': {0: 'off', 1: 'on'},
					'WholeWordOnly': {0: 'off', 1: 'on'},
					'AutoSpell': {0: 'off', 1: 'on'},
					'ReplaceMode': {0: 'off', 1: 'on'},
					'IgnoreFindString': {0: 'off', 1: 'on'},
					'IgnoreReplaceStrin g': {0: 'off', 1: 'on'},
					'IgnoreMessage': {0: 'off', 1: 'on'},
					'FindJaso': {0: 'off', 1: 'on'},
					'FindRegExp': {0: 'off', 1: 'on'},
					'AutoPlay': {0: 'off', 1: 'on'},
					'LoopPlay': {0: 'off', 1: 'on'},
					'ShowMenu': {0: 'Hide', 1: 'Show'},
					'PlaceAt': {0: '각 단마다 따로 배열', 1: '통단으로 배열', 2: '가장 오른쪽 단에 배열, - 미주용 옵션 (문서 내에서 미주를 어디에 위치시킬지), {0:문서의 마지막, 1:구역의 마지막'},
					'Restart': {0: '앞 구역에 이어서', 1: '현재 구역부터 새로 시작', 2: '쪽마다 새로 시작 (각주 전용)'},
					'BeneathText': {0: 'off', 1: 'on'},
					'SaveType': {0: 'HTML', 1: 'HWP'},
					'Method': {0: '격자와 상관없이', 1: '격자 자석효과', 2: '격자에만 붙음'},
					'Show': {0: 'off', 1: 'on'},
					'ZOrder': {0: '글 아래', 1: '글 위'},
					'ViewLine': {0: '모두', 1: '수평격자만', 2: '수직격자만'},
					'CtrlType': {0: '머리말', 1: '꼬리말'},
					'HeaderFooterCtrlType': {0: '머리말', 1: '꼬리말'},
					'ShowSingle': {0: '누름틀 페이지만 보이기', 1: '개인 정보 페이지만 보이기', 2: '문서 요약 페이지만 보이기', 3: '만든 날짜 페이지만 보이기', 4: '파일 경로 페이지만 보이기'},
					'TemplateType': {0: '누름틀', 1: '개인 정보', 2: '문서 요약', 3: '만든 날짜', 4: '파일 경로'},
					'LineWrap': {0: '일반적인 줄 바꿈', 1: '줄을 바꾸지 않음', 2: '자간을 조정하여 한 줄을 유지'},
					'Input': {0: 'WAB', 1: 'OAB', 2: 'HWP', 3: 'DBF'},
					'DbfCode': {0: 'KS', 1: 'KSSM', 2: 'GB', 3: 'BIG5', 4: 'SJIS'},
					'Output': {0: 'PRINTER', 1: 'PREVIEW', 2: 'FILE', 3: 'MAIL'},
					'Make': {1: '제목 차례', 2: '표 차례', 4: '그림 차례', 8: '수식 차례, 제목 차례를 지정한 경우에는 다음의 값을 추가로 지정할 수 있다', 16: '개요 문단으로 모으기', 32: '스타일로 모으기', 64: '차례코드로 모으기'},
					'AutoTabRight': {0: '자동 탭 사용안함', 1: '자동 탭 사용'},
					'Position': {0: '현재 문서', 1: '새 탭으로'},
					'Duplicate': {0: 'off', 1: 'on'},
					'Front': {0: 'off', 1: 'on'},
					'MemoType': {1: '메모 넣기', 2: '메모 지우기', 3: '메모 고치기'},
					'XRelTo': {0: '종이', 1: '쪽'},
					'YRelTo': {0: '종이', 1: '쪽'},
					'AutoRewind': {0: 'off', 1: 'on'},
					'ShowCtrlPanel': {0: 'Hide', 1: 'Show'},
					'ShowPosCtrl': {0: 'Hide', 1: 'Show'},
					'EnablePos': {0: 'Disable', 1: 'Enable'},
					'ShowTrackBar': {0: 'Hide', 1: 'Show'},
					'EnableTrack': {0: 'Disable', 1: 'Enable'},
					'ShowChaption': {0: 'Hide', 1: 'Show'},
					'ShowAudio': {0: 'Hide', 1: 'Show'},
					'ShowStatus': {0: 'Hide', 1: 'Show'},
					'HasCharShapeLevel0': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
					'HasCharShapeLevel1': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
					'HasCharShapeLevel2': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
					'HasCharShapeLevel3': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
					'HasCharShapeLevel4': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
					'HasCharShapeLevel5': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
					'HasCharShapeLevel6': {0: '스타일을 따라감', 1: '자체 모양을 가짐'},
					'AlignmentLevel0': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
					'AlignmentLevel1': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
					'AlignmentLevel2': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
					'AlignmentLevel3': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
					'AlignmentLevel4': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
					'AlignmentLevel5': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
					'AlignmentLevel6': {0: '왼쪽', 1: '가운데', 2: '오른쪽'},
					'TextOffsetTypeLevel0': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
					'TextOffsetTypeLevel1': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
					'TextOffsetTypeLevel2': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
					'TextOffsetTypeLevel3': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
					'TextOffsetTypeLevel4': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
					'TextOffsetTypeLevel5': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
					'TextOffsetTypeLevel6': {0: '퍼센트', 1: 'HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT'},
					'Aspect': {0: '내용으로 표시', 1: '아이콘으로 표시'},
					'IconMM': {1: 'MM_TEXT', 2: 'MM_LOMETRIC', 3: 'MM_HIMETRIC', 4: 'MM_LOENGLISH', 5: 'MM_HIENGLISH', 6: 'MM_TWIPS', 7: 'MM_ISOTROPIC', 8: 'MM_ANISOTROPIC'},
					'HeaderInside': {0: 'off', 1: 'on'},
					'FooterInside': {0: 'off', 1: 'on'},
					'FillArea': {0: '종이', 1: '쪽', 2: '테두리'},
					'Landscape': {0: '좁게', 1: '넓게'},
					'GutterType': {0: '한쪽 편집', 1: '맞쪽 편집', 2: '위로 넘기기'},
					'Fields': {2: '꼬리말', 4: '바탕쪽', 8: '테두리', 16: '배경', 32: '쪽번호 위치'},
					'PageStartsOn': {0: '양쪽', 1: '짝수쪽', 2: '홀수쪽'},
					'DrawPos': {0: '쪽 번호 없음', 1: '왼쪽 위', 2: '가운데 위', 3: '오른쪽 위', 4: '왼쪽 아래', 5: '가운데 아래', 6: '오른쪽 아래', 7: '바깥쪽 위', 8: '바깥쪽 아래', 9: '안쪽 위', 10: '안쪽 아래'},
					'LineSpacingType': {0: '글자에 따라', 1: '고정 값', 2: '여백만 지정'},
					'BreakLatinWord': {0: '단어', 1: '하이픈', 2: '글자'},
					'BreakNonLatinWord': {True: '글자', False: '어절'},
					'SnapToGrid': {0: 'off', 1: 'on'},
					'WidowOrphan': {0: 'off', 1: 'on'},
					'KeepWithNext': {0: 'off', 1: 'on'},
					'KeepLinesTogether': {0: 'off', 1: 'on'},
					'PagebreakBefore': {0: 'off', 1: 'on'},
					'TextAlignment': {0: '글꼴기준', 1: '위', 2: '가운데', 3: '아래'},
					'FontLineHeight': {0: 'off', 1: 'on'},
					'HeadingType': {0: '없음', 1: '개요', 2: '번호', 3: '불릿'},
					'BorderConnect': {0: 'off', 1: 'on'},
					'BorderText': {0: '단', 1: '텍스트'},
					'TailType': {0: 'off', 1: 'on'},
					'Ask': {0: '문서 암호를 확인', 1: '문서 암호를 설정'},
					'ApplyLinkAttr': {0: 'off', 1: 'on'},
					'ApplyForbidden': {0: 'off', 1: 'on'},
					'Range': {0: '문서전체 (연결된 문서 포함)', 1: '현재 쪽', 2: '현재부터', 3: '현재까지', 4: '일부분', 5: '선택한 쪽만', 6: '현재 문서 (연결된 문서 미포함)', 7: '현재 구역'},
					'PrintMethod': {0: '자동 인쇄', 1: '공급 용지에 맞추어', 2: '나눠 찍기', 3: '자동으로 모아 찍기', 4: '2쪽씩 모아 찍기', 5: '3쪽씩 모아 찍기', 6: '4쪽씩 모아 찍기', 7: '6쪽씩 모아 찍기', 8: '8쪽씩 모아 찍기', 9: '9쪽씩 모아 찍기', 10: '16쪽씩 모아 찍기'},
					'Device': {0: '프린터', 1: '팩스', 2: '그림으로 저장', 3: 'PDF 파일로 저장', 4: '미리보기'},
					'WatermarkType': {0: '워터마크 없음', 1: '그림 워터마크', 2: '글자 워터마크'},
					'PosPage': {0: '종이 기준', 1: '쪽 기준'},
					'TextWrap': {0: '글 뒤로', 1: '글 앞으로'},
					'WaterMarkEff': {0: 'off', 1: 'on'},
					'SignType': {0: '교정부호 없음', 13: '줄표', 1: '띄움표', 14: '부호 넣음표', 2: '줄 바꿈표', 15: '넣음표', 3: '줄 비움표', 16: '고침표', 4: '메모형 고침표', 17: '자리 바꿈표', 5: '지움표', 18: '오른자리 옮김표', 6: '붙임표', 19: '자료연결', 7: '뺌표', 20: '왼자리 옮김표', 8: '줄 이음표', 21: '부분자리 옮김표', 9: '줄 붙임표', 22: '줄 서로 바꿈표', 10: '톱니표', 23: '자리바꿈 나눔표(내부용)', 11: '생각표', 24: '줄 서로 바꿈 나눔표(내부용)', 12: '칭찬표'},
					'StartsOn': {0: '이어서', 1: '홀수', 2: '짝수', 3: '임의 값'},
					'LineGrid': {0: 'off', 1: '간격을  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위로 지정'},
					'CharGrid': {0: 'off', 1: '간격을  HWPUNIT - 한글기본 단위. 1mm는 283.465HWPUNIT 이며, 1inch는 7200HWPUNIT 단위로 지정'},
					'HideEmptyLine': {0: 'off', 1: 'on'},
					'HideHeader': {0: 'off', 1: 'on'},
					'HideFooter': {0: 'off', 1: 'on'},
					'HideMasterPage': {0: 'off', 1: 'on'},
					'HideBorder': {0: 'off', 1: 'on'},
					'HideFill': {0: 'off', 1: 'on'},
					'HidePageNumPos': {0: 'off', 1: 'on'},
					'FirstBorder': {0: 'off', 1: 'on'},
					'FirstFill': {0: 'off', 1: 'on'},
					'PageNumber': {0: '앞 구역에 이어', 'n': '새 번호로 시작'},
					'FigureNumber': {0: '앞 구역에 이어', 'n': '새 번호로 시작'},
					'TableNumber': {0: '앞 구역에 이어', 'n': '새 번호로 시작'},
					'EquationNumber': {0: '앞 구역에 이어', 'n': '새 번호로 시작'},
					'ApplyToPageBorderFill': {0: '종이', 1: '쪽', 2: '테두리 (글2007에 새로 추가)'},
					'TreatAsChar': {0: 'off', 1: 'on'},
					'VertRelTo': {0: '종이 영역(Paper)', 1: '쪽 영역(Page)', 2: '문단 영역(Paragraph), (TreatAsChar가 FALSE일 경우에만 사용된다)'},
					'HorzRelTo': {0: '종이 영역(Paper)', 1: '쪽 영역(Page)', 2: '다단 영역(Column)', 3: '문단 영역(Paragraph), (TreatAsChar가 FALSE일 경우에만 사용된다)'},
					'WidthRelTo': {0: '종이(Paper)', 1: '쪽(Page)', 2: '다단(Column)', 3: '문단(Paragraph)', 4: '고정 값(Absolute)'},
					'HeightRelTo': {0: '종이(Paper)', 1: '쪽(Page)', 2: '고정 값(Absolute)'},
					'ProtectSize': {0: 'off', 1: 'on'},
					'TextFlow': {0: '양쪽 모두(Both)', 1: '왼쪽만(Left Only)', 2: '오른쪽만(Right Only)', 3: '왼쪽과 오른쪽 중 넓은 쪽(Largest Only)'},
					'NumberingType': {0: '없음', 1: '그림', 2: '표', 3: '수식'},
					'Lock': {0: 'off', 1: 'on'},
					'HoldAnchorObj': {0: 'off', 1: 'on'},
					'AdjustSelection': {0: 'off', 1: 'on'},
					'AdjustTextBox': {0: 'off', 1: 'on'},
					'AdjustPrevObjAttr': {0: 'off', 1: 'on'},
					'ShapeCellSize': {0: 'off', 1: 'on'},
					'ShapeCreationMode': {0: 'off', 1: 'on'},
					'DelimiterType': {0: '탭(Tab)', 1: '콤마', 2: '빈칸(Space)', 3: '사용자 정의'},
					'Comma': {0: 'off', 1: 'on'},
					'AutoTabLeft': {0: 'off', 1: 'on'},
					'TabItem': {0: '왼쪽', 1: '오른쪽', 2: '가운데', 3: '소수점'},
					'PageBreak': {0: '나누지 않는다', 1: '테이블은 나누지만 셀은 나누지 않는다', 2: '셀 내의 텍스트도 나눈다.'},
					'RepeatHeader': {0: 'off', 1: 'on'},
					'ApplyTarger': {1: '제목 줄', 2: '마지막 줄', 4: '첫째 칸', 8: '마지막 칸'},
					'Landscope': {0: '좁게', 1: '넓게'},
					'ItemOverWrite': {0: 'off', 1: 'on'},
					'ItemSaveDescription': {0: 'off', 1: 'on'},
					'OptionFlag': {1: 'off', 2: '공백과 폭이 없는 컨트롤을 기호로', 4: '문단 마크 기호로', 8: '안내선', 16: '그리기 격자', 32: '그림 감춤'},
					'ZoomType': {0: '사용자 정의', 1: '쪽 맞춤', 2: '폭 맞춤', 3: '여러 쪽'},
					'Option': {0: '일반', 1: '주소', 2: '사람이름', 3: '한글복원', "default":0},
					'Flag': {0: '모든 각주를 미주로 바꾸기', 1: '모든 미주를 각주로 바꾸기', 2: '각주와 미주를 서로 바꾸기'},
					'OpenFlag': {0: '새 창으로 열기', 1: '현재 창의 새 탭에 열기', 2: '현재 창의 현재 탭에 열기', 3: '위 세 값의 mask',
													   4: '이미 열려진 문서일 때 다시 load할지 뭍을 것인지', 8: '초기 모드를 최근 작업 문서 상태로, 0x10:문서 마당'},
		}

		#action에대한 파라미터 그룹 이름
		self.varx["action_name_vs_parameter_set_id"] = {
			'AddHanjaWord': None, 'AllReplace': 'FindReplace',
			'AQcommandMerge': 'UserQCommandFile', 'AutoChangeHangul': None, 'AutoChangeRun': None, 'AutoSpellRun': None, 'AutoSpellSelect1': None, 'AutoSpellSelect2': None, 'AutoSpellSelect3': None, 'AutoSpellSelect4': None, 'AutoSpellSelect5': None, 'AutoSpellSelect6': None, 'AutoSpellSelect7': None, 'AutoSpellSelect8': None, 'AutoSpellSelect9': None, 'AutoSpellSelect10': None, 'AutoSpellSelect11': None, 'AutoSpellSelect12': None, 'AutoSpellSelect13': None, 'AutoSpellSelect14': None, 'AutoSpellSelect15': None, 'AutoSpellSelect16': None, 'Average': 'Sum', 'BackwardFind': 'FindReplace', 'Bookmark': 'BookMark', 'BreakColDef': None, 'BreakColumn': None, 'BreakLine': None, 'BreakPage': None, 'BreakPara': None, 'BreakSection': None, 'Cancel': None, 'CaptureDialog': None, 'CaptureHandler': None, 'CellBorder': 'CellBorderFill', 'CellBorderFill': 'CellBorderFill', 'CellFill': 'CellBorderFill', 'CellZoneBorder': 'CellBorderFill', 'CellZoneBorderFill': 'CellBorderFill', 'CellZoneFill': 'CellBorderFill', 'ChangeRome': None, 'ChangeRomeString': None, 'ChangeRomeUser': None, 'ChangeRomeUserString': None, 'CharShape': 'CharShape', 'CharShapeBold': None, 'CharShapeCenterline': None, 'CharShapeDialog': 'CharShape', 'CharShapeDialogWithoutBorder': 'CharShape', 'CharShapeEmboss': None, 'CharShapeEngrave': None, 'CharShapeHeight': None, 'CharShapeHeightDecrease': None, 'CharShapeHeightIncrease': None, 'CharShapeItalic': None, 'CharShapeLang': None, 'CharShapeNextFaceName': None, 'CharShapeNormal': None, 'CharShapeOutline': None, 'CharShapePrevFaceName': None, 'CharShapeShadow': None, 'CharShapeSpacing': None, 'CharShapeSpacingDecrease': None, 'CharShapeSpacingIncrease': None, 'CharShapeSubscript': None, 'CharShapeSuperscript': None, 'CharShapeSuperSubscript': None, 'CharShapeTextColorBlack': None, 'CharShapeTextColorBlue': None, 'CharShapeTextColorBluish': None, 'CharShapeTextColorGreen': None, 'CharShapeTextColorRed': None, 'CharShapeTextColorViolet': None, 'CharShapeTextColorWhite': None, 'CharShapeTextColorYellow': None, 'CharShapeTypeFace': None, 'CharShapeUnderline': None, 'CharShapeWidth': None, 'CharShapeWidthDecrease': None, 'CharShapeWidthIncrease': None, 'Close': None, 'CloseEx': None, 'Comment': None, 'CommentDelete': None, 'CommentModify': None, 'ComposeChars': 'ChCompose', 'ConvertCase': 'ConvertCase', 'ConvertFullHalfWidth': 'ConvertFullHalf', 'ConvertHiraGata': 'ConvertHiraToGata', 'ConvertJianFan': 'ConvertJianFan', 'ConvertToHangul': 'ConvertToHangul', 'Copy': None, 'Cut': None, 'Delete': None, 'DeleteBack': None, 'DeleteCtrls': 'DeleteCtrls', 'DeleteDutmal': None, 'DeleteField': None, 'DeleteFieldMemo': None, 'DeleteLine': None, 'DeleteLineEnd': None, 'DeleteWord': None, 'DeleteWordBack': None, 'DocFindEnd': 'FindReplace', 'DocFindInit': 'FindReplace', 'DocFindNext': 'DocFindInfo', 'DocSummaryInfo': 'SummaryInfo', 'DocumentInfo': 'DocumentInfo', 'DrawObjCancelOneStep': None, 'DrawObjCreatorArc': 'ShapeObject', 'DrawObjCreatorCanvas': 'ShapeObject', 'DrawObjCreatorCurve': 'ShapeObject', 'DrawObjCreatorEllipse': 'ShapeObject', 'DrawObjCreatorFreeDrawing': 'ShapeObject', 'DrawObjCreatorLine': 'ShapeObject', 'DrawObjCreatorMultiArc': 'ShapeObject', 'DrawObjCreatorMultiCanvas': 'ShapeObject', 'DrawObjCreatorMultiCurve': 'ShapeObject', 'DrawObjCreatorMultiEllipse': 'ShapeObject', 'DrawObjCreatorMultiFreeDrawing': 'ShapeObject', 'DrawObjCreatorMultiLine': 'ShapeObject', 'DrawObjCreatorMultiPolygon': 'ShapeObject', 'DrawObjCreatorMultiRectangle': 'ShapeObject', 'DrawObjCreatorMultiTextBox': 'ShapeObject', 'DrawObjCreatorObject': 'ShapeObject', 'DrawObjCreatorPolygon': 'ShapeObject', 'DrawObjCreatorRectangle': 'ShapeObject', 'DrawObjCreatorTextBox': 'ShapeObject', 'DrawObjEditDetail': None, 'DrawObjOpenClosePolygon': None, 'DrawObjTemplateLoad': 'ShapeObject', 'DrawObjTemplateSave': None, 'DrawShapeObjShadow': 'ShapeObject', 'DropCap': 'DropCap', 'DutmalChars': 'Dutmal', 'EditFieldMemo': None, 'EquationCreate': 'EqEdit', 'EquationModify': 'EqEdit', 'EquationPropertyDialog': 'ShapeObject', 'Erase': None, 'ExchangeFootnoteEndnote': 'ExchangeFootnoteEnd Note', 'ExecReplace': 'FindReplace', 'FileClose': None, 'FileNew': None, 'FileOpen': None, 'FileOpenMRU': None, 'FilePassword': 'Password', 'FilePreview': None, 'FileQuit': None, 'FileSave': None, 'FileSaveAs': None, 'FileSetSecurity': 'FileSetSecurity', 'FileTemplate': 'FileOpen', 'FindAll': 'FindReplace', 'FindDlg': 'FindReplace', 'FindForeBackBookmark': None, 'FindForeBackCtrl': None, 'FindForeBackFind': None, 'FindForeBackLine': None, 'FindForeBackPage': None, 'FindForeBackSection': None, 'FindForeBackStyle': None, 'FootnoteOption': 'SecDef', 'ForwardFind': 'FindReplace', 'FrameStatusBar': None, 'FtpUpload': 'FtpUpload', 'FtpDownload': 'FtpDownload', 'GetDefaultBullet': 'ParaShape', 'GetDefaultParaNumber': 'ParaShape', 'GetDocFilters': 'DocFilters', 'GetRomeString': 'ChangeRome', 'GetSectionApplyString': 'SectionApply', 'GetSectionApplyTo': 'SectionApply', 'GetVersionItemInfo': 'VersionInfo', 'Goto': 'GotoE', 'GotoStyle': 'GotoE', 'HanThDIC': None, 'HeaderFooter': 'HeaderFooter', 'HeaderFooterDelete': None, 'HeaderFooterInsField': 'HeaderFooter', 'HeaderFooterModify': None, 'HeaderFooterToNext': None, 'HeaderFooterToPrev': None, 'HiddenCredits': None, 'HideTitle': None, 'HimConfig': None, 'HimKbdChange': None, 'HwpCtrlEquationCreate97': None, 'HwpCtrlFileNew': None, 'HwpCtrlFileOpen': None, 'HwpCtrlFileSave': None, 'HwpCtrlFileSaveAs': None, 'HwpCtrlFileSaveAsAutoBlock': None, 'HwpCtrlFileSaveAutoBlock': None, 'HwpCtrlFindDlg': None, 'HwpCtrlReplaceDlg': None, 'HwpDic': None, 'Hyperlink': 'HyperLink', 'HyperlinkBackward': None, 'HyperlinkForward': None, 'HyperlinkJump': 'HyperlinkJump', 'Idiom': 'Idiom', 'ImageFindPath': None, 'IndexMark': 'IndexMark', 'IndexMarkModify': 'IndexMark', 'InputCodeChange': None, 'InputCodeTable': 'CodeTable', 'InputDateStyle': 'InputDateStyle', 'InputHanja': None, 'InputHanjaBusu': None, 'InputHanjaMean': None, 'InsertAutoNum': None, 'InsertCCLMark': 'HyperLink', 'InsertChart': 'OleCreation', 'InsertConnectLineArcBoth': 'ShapeObject', 'InsertConnectLineArcNoArrow': 'ShapeObject', 'InsertConnectLineArcOneWay': 'ShapeObject', 'InsertConnectLineMultiArcBoth': 'ShapeObject', 'InsertConnectLineMultiArcNoArrow': 'ShapeObject', 'InsertConnectLineMultiArcOneWay': 'ShapeObject', 'InsertConnectLineMultiStraightBoth': 'ShapeObject', 'InsertConnectLineMultiStraightNoArrow': 'ShapeObject', 'InsertConnectLineMultiStraightOneWay': 'ShapeObject', 'InsertConnectLineMultiStrokeBoth': 'ShapeObject', 'InsertConnectLineMultiStrokeNoArrow': 'ShapeObject', 'InsertConnectLineMultiStrokeOneWay': 'ShapeObject', 'InsertConnectLineStraightBoth': 'ShapeObject', 'InsertConnectLineStraightNoArrow': 'ShapeObject', 'InsertConnectLineStraightOneWay': 'ShapeObject', 'InsertConnectLineStrokeBoth': 'ShapeObject', 'InsertConnectLineStrokeNoArrow': 'ShapeObject', 'InsertConnectLineStrokeOneWay': 'ShapeObject', 'InsertCpNo': None, 'InsertCpTpNo': None, 'InsertCrossReference': 'ActionCrossRef', 'InsertDateCode': None, 'InsertDocInfo': None, 'InsertDocTitle': 'InsertFieldTemplate', 'InsertEndnote': None, 'InsertFieldDateTime': None, 'InsertFieldFileName': 'InsertFieldTemplate', 'InsertFieldMemo': None, 'InsertFieldRevisionChagne': None, 'InsertFieldTemplate': 'InsertFieldTemplate', 'InsertFile': 'InsertFile', 'InsertFileName': 'InsertFieldTemplate', 'InsertFilePath': 'InsertFieldTemplate', 'InsertFixedWidthSpace': None, 'InsertFootnote': None, 'InsertHyperlink': 'HyperlinkJump', 'InsertIdiom': 'Idiom', 'InsertLastPrintDate': None, 'InsertLastSaveBy': None, 'InsertLastSaveDate': None, 'InsertLine': None, 'InsertNonBreakingSpace': None, 'InsertPageNum': None, 'InsertRevision': 'RevisionDef', 'InsertRevisionAttach': 'RevisionDef', 'InsertRevisionClipping': 'RevisionDef', 'InsertRevisionDelete': 'RevisionDef', 'InsertRevisionHyperlink': 'HyperLink', 'InsertRevisionInsert': 'RevisionDef', 'InsertRevisionLeftMove': 'RevisionDef', 'InsertRevisionLine': 'RevisionDef', 'InsertRevisionLineAttach': 'RevisionDef', 'InsertRevisionLineInsert': 'RevisionDef', 'InsertRevisionLineLink': 'RevisionDef', 'InsertRevisionLineSeparate': 'RevisionDef', 'InsertRevisionLineTransfer': 'RevisionDef', 'InsertRevisionLineTransferSplit': 'RevisionDef', 'InsertRevisionPraise': 'RevisionDef', 'InsertRevisionRightMove': 'RevisionDef', 'InsertRevisionSawTooth': 'RevisionDef', 'InsertRevisionSimpleChange': 'RevisionDef', 'InsertRevisionSpace': 'RevisionDef', 'InsertRevisionSymbol': 'RevisionDef', 'InsertRevisionThinking': 'RevisionDef', 'InsertRevisionTransfer': 'RevisionDef', 'InsertRevisionTransferSplit': 'RevisionDef', 'InsertSoftHyphen': None, 'InsertSpace': None, 'InsertStringDateTime': None, 'InsertTab': None, 'InsertText': 'InsertText', 'InsertTpNo': None, 'InsertUserName': 'InsertFieldTemplate', 'InsertVoice': 'OleCreation', 'Jajun': None, 'LabelAdd': None, 'LabelTemplate': None, 'LinkDocument': 'LinkDocument', 'LinkTextBox': None, 'MacroDefine': 'KeyMacro', 'MacroPause': None, 'MacroPlay1': None, 'MacroPlay10': None, 'MacroPlay11': None, 'MacroPlay2': None, 'MacroPlay3': None, 'MacroPlay4': None, 'MacroPlay5': None, 'MacroPlay6': None, 'MacroPlay7': None, 'MacroPlay8': None, 'MacroPlay9': None, 'MacroRepeat': None, 'MacroRepeatDlg': 'KeyMacro', 'MacroStop': None, 'MailMergeField': None, 'MailMergeGenerate': 'MailMergeGenerate', 'MailMergeInsert': 'FieldCtrl', 'MailMergeModify': 'FieldCtrl', 'MakeAllVersionDiffs': 'VersionInfo', 'MakeContents': 'MakeContents', 'MakeIndex': None, 'ManualChangeHangul': None, 'ManuScriptTemplate': 'FileOpen', 'MarkPenShape': 'MarkpenShape', 'MarkTitle': None, 'MasterPage': 'MasterPage', 'MasterPageDelete': 'MasterPage', 'MasterPageDuplicate': None, 'MasterPageEntry': 'MasterPage', 'MasterPageExcept': None, 'MasterPageFront': None, 'MasterPagePrevSection': None, 'MasterPageToNext': None, 'MasterPageToPrevious': None, 'MasterPageTypeDlg': 'MasterPage', 'MemoShape': 'SecDef', 'MessageBox': None, 'ModifyBookmark': 'BookMark', 'ModifyComposeChars': None, 'ModifyCrossReference': 'ActionCrossRef', 'ModifyCtrl': None, 'ModifyDutmal': None, 'ModifyFieldClickhere': 'InsertFieldTemplate', 'ModifyFieldDate': 'InsertFieldTemplate', 'ModifyFieldDateTime': 'InputDateStyle', 'ModifyFieldPath': 'InsertFieldTemplate', 'ModifyFieldSummary': 'InsertFieldTemplate', 'ModifyFieldUserInfo': 'InsertFieldTemplate', 'ModifyFillProperty': None, 'ModifyHyperlink': 'HyperLink', 'ModifyLineProperty': None, 'ModifyRevision': 'RevisionDef', 'ModifyRevisionHyperlink': 'HyperLink', 'ModifySection': 'SecDef', 'ModifyShapeObject': None, 'MoveColumnBegin': None, 'MoveColumnEnd': None, 'MoveDocBegin': None, 'MoveDocEnd': None, 'MoveDown': None, 'MoveLeft': None, 'MoveLineBegin': None, 'MoveLineDown': None, 'MoveLineEnd': None, 'MoveLineUp': None, 'MoveListBegin': None, 'MoveListEnd': None, 'MoveNextChar': None, 'MoveNextColumn': None, 'MoveNextParaBegin': None, 'MoveNextPos': None, 'MoveNextPosEx': None, 'MoveNextWord': None, 'MovePageBegin': None, 'MovePageDown': None, 'MovePageEnd': None, 'MovePageUp': None, 'MoveParaBegin': None, 'MoveParaEnd': None, 'MoveParentList': None, 'MovePrevChar': None, 'MovePrevColumn': None, 'MovePrevParaBegin': None, 'MovePrevParaEnd': None, 'MovePrevPos': None, 'MovePrevPosEx': None, 'MovePrevWord': None, 'MoveRight': None, 'MoveRootList': None, 'MoveScrollDown': None, 'MoveScrollNext': None, 'MoveScrollPrev': None, 'MoveScrollUp': None, 'MoveSectionDown': None, 'MoveSectionUp': None, 'MoveSelDocBegin': None, 'MoveSelDocEnd': None, 'MoveSelDown': None, 'MoveSelLeft': None, 'MoveSelLineBegin': None, 'MoveSelLineDown': None, 'MoveSelLineEnd': None, 'MoveSelLineUp': None, 'MoveSelListBegin': None, 'MoveSelListEnd': None, 'MoveSelNextChar': None, 'MoveSelNextParaBegin': None, 'MoveSelNextPos': None, 'MoveSelNextWord': None, 'MoveSelPageDown': None, 'MoveSelPageUp': None, 'MoveSelParaBegin': None, 'MoveSelParaEnd': None, 'MoveSelPrevChar': None, 'MoveSelPrevParaBegin': None, 'MoveSelPrevParaEnd': None, 'MoveSelPrevPos': None, 'MoveSelPrevWord': None, 'MoveSelRight': None, 'MoveSelTopLevelBegin': None, 'MoveSelTopLevelEnd': None, 'MoveSelUp': None, 'MoveSelViewDown': None, 'MoveSelViewUp': None, 'MoveSelWordBegin': None, 'MoveSelWordEnd': None, 'MoveTopLevelBegin': None, 'MoveTopLevelEnd': None, 'MoveTopLevelList': None, 'MoveUp': None, 'MoveViewBegin': None, 'MoveViewDown': None, 'MoveViewEnd': None, 'MoveViewUp': None, 'MoveWordBegin': None, 'MoveWordEnd': None, 'MPSectionToNext': None, 'MPSectionToPrevious': None, 'MultiColumn': 'ColDef', 'NewNumber': 'AutoNum', 'NewNumberModify': 'AutoNum', 'NextTextBoxLinked': None, 'NoteDelete': None, 'NoteModify': None, 'NoteNumProperty': None, 'NoteToNext': None, 'NoteToPrev': None, 'OleCreateNew': 'OleCreation', 'OutlineNumber': 'SecDef', 'PageBorder': 'SecDef', 'PageHiding': 'PageHiding', 'PageHidingModify': 'PageHiding', 'PageNumPos': 'PageNumPos', 'PageNumPosModify': 'PageNumPos', 'PageSetup': 'SecDef', 'ParagraphShape': 'ParaShape', 'ParagraphShapeAlignCenter': None, 'ParagraphShapeAlignDistribute': None, 'ParagraphShapeAlignDivision': None, 'ParagraphShapeAlignJustify': None, 'ParagraphShapeAlignLeft': None, 'ParagraphShapeAlignRight': None, 'ParagraphShapeDecreaseLeftMargin': None, 'ParagraphShapeDecreaseLineSpacing': None, 'ParagraphShapeDecreaseMargin': None, 'ParagraphShapeDecreaseRightMargin': None, 'ParagraphShapeIncreaseLeftMargin': None, 'ParagraphShapeIncreaseLineSpacing': None, 'ParagraphShapeIncreaseMargin': None, 'ParagraphShapeIncreaseRightMargin': None, 'ParagraphShapeIndentAtCaret': None, 'ParagraphShapeIndentNegative': None, 'ParagraphShapeIndentPositive': None, 'ParagraphShapeProtect': None, 'ParagraphShapeWithNext': None, 'ParaNumberBullet': 'ParaShape', 'ParaNumberBulletLevelDown': 'ParaShape', 'ParaNumberBulletLevelUp': 'ParaShape', 'ParaShapeDialog': 'ParaShape', 'Paste': None, 'PasteSpecial': None, 'PictureEffect1': None, 'PictureEffect2': None, 'PictureEffect3': None, 'PictureEffect4': None, 'PictureEffect5': None, 'PictureEffect6': None, 'PictureEffect7': None, 'PictureEffect8': None, 'PictureInsertDialog': None, 'PictureLinkedToEmbedded': None, 'PictureSave': None, 'PictureScissor': None, 'PictureToOriginal': None, 'Preference': 'Preference', 'Presentation': 'Presentation', 'PresentationSetup': 'Presentation', 'PrevTextBoxLinked': None, 'Print': 'Print', 'PrintToImage': 'PrintToImage', 'PutBullet': 'ParaShape', 'PutNewParaNumber': 'ParaShape', 'PutOutlineNumber': 'ParaShape', 'PutParaNumber': 'ParaShape', 'QuickCommandRun': None, 'QuickCorrect': None, 'QuickCorrectEdit': 'QCorrect', 'QuickCorrectRun': None, 'QuickCorrectSound': None, 'QuickMarkInsert0': None, 'QuickMarkInsert1': None, 'QuickMarkInsert2': None, 'QuickMarkInsert3': None, 'QuickMarkInsert4': None, 'QuickMarkInsert5': None, 'QuickMarkInsert6': None, 'QuickMarkInsert7': None, 'QuickMarkInsert8': None, 'QuickMarkInsert9': None, 'QuickMarkMove0': None, 'QuickMarkMove1': None, 'QuickMarkMove2': None, 'QuickMarkMove3': None, 'QuickMarkMove4': None, 'QuickMarkMove5': None, 'QuickMarkMove6': None, 'QuickMarkMove7': None, 'QuickMarkMove8': None, 'QuickMarkMove9': None, 'RecalcPageCount': None, 'RecentCode': None, 'Redo': None, 'RepeatFind': 'FindReplace', 'ReplaceDlg': 'FindReplace', 'ReturnKeyInField': None, 'ReturnPrevPos': None, 'ReverseFind': 'FindReplace', 'SaveBlockAction': 'FileSaveBlock', 'SaveFootnote': 'SaveFootnote', 'SaveHistoryItem': 'VersionInfo', 'ScrMacroDefine': 'ScriptMacro', 'ScrMacroPause': None, 'ScrMacroPlay1': None, 'ScrMacroPlay2': None, 'ScrMacroPlay3': None, 'ScrMacroPlay4': None, 'ScrMacroPlay5': None, 'ScrMacroPlay6': None, 'ScrMacroPlay7': None, 'ScrMacroPlay8': None, 'ScrMacroPlay9': None, 'ScrMacroPlay10': None, 'ScrMacroPlay11': None, 'ScrMacroRepeatDlg': 'ScriptMacro', 'ScrMacroSecurityDlg': None, 'ScrMacroStop': None, 'SearchAddress': None, 'SearchForeign': None, 'Select': None, 'SelectAll': None, 'SelectColumn': None, 'SelectCtrlFront': None, 'SelectCtrlReverse': None, 'SendBrowserText': None, 'SendMailAttach': 'FileSendMail', 'SendMailText': 'FileSendMail', 'ShapeCopyPaste': 'ShapeCopyPaste', 'ShapeObjAlignBottom': None, 'ShapeObjAlignCenter': None, 'ShapeObjAlignHeight': None, 'ShapeObjAlignHorzSpacing': None, 'ShapeObjAlignLeft': None, 'ShapeObjAlignMiddle': None, 'ShapeObjAlignRight': None, 'ShapeObjAlignSize': None, 'ShapeObjAlignTop': None, 'ShapeObjAlignVertSpacing': None, 'ShapeObjAlignWidth': None, 'ShapeObjAttachCaption': None, 'ShapeObjAttachTextBox': None, 'ShapeObjAttrDialog': 'ShapeObject', 'ShapeObjBringForward': None, 'ShapeObjBringInFrontOfText': None, 'ShapeObjBringToFront': None, 'ShapeObjCtrlSendBehindText': None, 'ShapeObjDetachCaption': None, 'ShapeObjDetachTextBox': None, 'ShapeObjDialog': 'ShapeObject', 'ShapeObjectCopy': 'ShapeObjectCopyPaste', 'ShapeObjectPaste': 'ShapeObjectCopyPaste', 'ShapeObjFillProperty': None, 'ShapeObjGroup': None, 'ShapeObjHorzFlip': None, 'ShapeObjHorzFlipOrgState': None, 'ShapeObjInsertCaptionNum': None, 'ShapeObjLineProperty': None, 'ShapeObjLock': None, 'ShapeObjMoveDown': None, 'ShapeObjMoveLeft': None, 'ShapeObjMoveRight': None, 'ShapeObjMoveUp': None, 'ShapeObjNextObject': None, 'ShapeObjNorm': None, 'ShapeObjPrevObject': None, 'ShapeObjRandomAngleRotater': 'ShapeObject', 'ShapeObjResizeDown': None, 'ShapeObjResizeLeft': None, 'ShapeObjResizeRight': None, 'ShapeObjResizeUp': None, 'ShapeObjRightAngleRotater': None, 'ShapeObjRightAngleRotaterAnticlockwise': None, 'ShapeObjRotater': None, 'ShapeObjSaveAsPicture': None, 'ShapeObjSelect': None, 'ShapeObjSendBack': None, 'ShapeObjSendToBack': None, 'ShapeObjShadowEnlarge': None, 'ShapeObjShadowMoveDown': None, 'ShapeObjShadowMoveLeft': None, 'ShapeObjShadowMoveRight': None, 'ShapeObjShadowMoveUp': None, 'ShapeObjShadowNarrow': None, 'ShapeObjShadowParellelLeftBottom': None, 'ShapeObjShadowParellelLeftTop': None, 'ShapeObjShadowParellelRightBottom': None, 'ShapeObjShadowParellelRightTop': None, 'ShapeObjShadowShearLeftBottom': None, 'ShapeObjShadowShearLeftTop': None, 'ShapeObjShadowShearRightBottom': None, 'ShapeObjShadowShearRightTop': None, 'ShapeObjShear': 'ShapeObject', 'ShapeObjTableSelCell': None, 'ShapeObjTextBoxEdit': None, 'ShapeObjUngroup': None, 'ShapeObjUnlockAll': None, 'ShapeObjVertFlip': None, 'ShapeObjVertFlipOrgState': None, 'ShapeObjWrapSquare': None, 'ShapeObjWrapTopAndBottom': None, 'SoftKeyboard': None, 'Sort': 'Sort', 'SpellingCheck': None, 'SplitMemoOpen': None, 'Style': 'Style', 'StyleAdd': 'Style', 'StyleClearCharStyle': None, 'StyleDelete': 'StyleDelete', 'StyleEdit': 'Style', 'StyleEx': 'Style', 'StyleParaNumberBullet': 'ParaShape', 'StyleShortcut1': None, 'StyleShortcut10': None, 'StyleShortcut2': None, 'StyleShortcut3': None, 'StyleShortcut4': None, 'StyleShortcut5': None, 'StyleShortcut6': None, 'StyleShortcut7': None, 'StyleShortcut8': None, 'StyleShortcut9': None, 'StyleTemplate': 'StyleTemplate', 'Sum': 'Sum', 'TableAppendRow': None, 'TableAutoDrawPenStyleWidthDlg': 'TableDrawPen', 'TableAutoFill': 'AutoFill', 'TableAutoFillDlg': 'AutoFill', 'TableCellBlock': None, 'TableCellBlockCol': None, 'TableCellBlockExtend': None, 'TableCellBlockExtendAbs': None, 'TableCellBlockRow': None, 'TableCellBorderAll': None, 'TableCellBorderBottom': None, 'TableCellBorderDiagonalDown': None, 'TableCellBorderDiagonalUp': None, 'TableCellBorderInside': None, 'TableCellBorderInsideHorz': None, 'TableCellBorderInsideVert': None, 'TableCellBorderLeft': None, 'TableCellBorderNo': None, 'TableCellBorderOutside': None, 'TableCellBorderRight': None, 'TableCellBorderTop': None, 'TableCellShadeDec': 'CellBorderFill', 'TableCellShadeInc': 'CellBorderFill', 'TableColBegin': None, 'TableColEnd': None, 'TableColPageDown': None, 'TableColPageUp': None, 'TableCreate': 'TableCreation', 'TableDeleteCell': None, 'TableDeleteColumn': 'TableDeleteLine', 'TableDeleteRow': 'TableDeleteLine', 'TableDeleteRowColumn': 'TableDeleteLine', 'TableDistributeCellHeight': None, 'TableDistributeCellWidth': None, 'TableDrawPen': None, 'TableEraser': None, 'TableFormula': 'FieldCtrl', 'TableFormulaAvgAuto': None, 'TableFormulaAvgHor': None, 'TableFormulaAvgVer': None, 'TableFormulaProAuto': None, 'TableFormulaProHor': None, 'TableFormulaProVer': None, 'TableFormulaSumAuto': None, 'TableFormulaSumHor': None, 'TableFormulaSumVer': None, 'TableInsertLeftColumn': 'TableInsertLine', 'TableInsertLowerRow': 'TableInsertLine', 'TableInsertRightColumn': 'TableInsertLine', 'TableInsertRowColumn': 'TableInsertLine', 'TableInsertUpperRow': 'TableInsertLine', 'TableLeftCell': None, 'TableLowerCell': None, 'TableMergeCell': None, 'TableMergeTable': None, 'TablePropertyDialog': 'ShapeObject', 'TableResizeCellDown': None, 'TableResizeCellLeft': None, 'TableResizeCellRight': None, 'TableResizeCellUp': None, 'TableResizeDown': None, 'TableResizeExDown': None, 'TableResizeExLeft': None, 'TableResizeExRight': None, 'TableResizeExUp': None, 'TableResizeLeft': None, 'TableResizeLineDown': None, 'TableResizeLineLeft': None, 'TableResizeLineRight': None, 'TableResizeLineUp': None, 'TableResizeRight': None, 'TableResizeUp': None, 'TableRightCell': None, 'TableRightCellAppend': None, 'TableSplitCell': 'TableSplitCell', 'TableSplitCellCol2': 'TableSplitCell', 'TableSplitCellRow2': 'TableSplitCell', 'TableSplitTable': None, 'TableStringToTable': 'TableStrToTbl', 'TableSubtractRow': 'TableDeleteLine', 'TableSwap': 'TableSwap', 'TableTableToString': 'TableTblToStr', 'TableTemplate': 'TableTemplate', 'TableUpperCell': None, 'TableVAlignBottom': None, 'TableVAlignCenter': None, 'TableVAlignTop': None, 'TextArtCreate': None, 'TextArtModify': None, 'TextArtShadow': None, 'ToggleOverwrite': None, 'Undo': None, 'UnlinkTextBox': None, 'UserAutoFill': 'AutoFill', 'VersionDelete': 'VersionInfo', 'VersionDeleteAll': None, 'VersionInfo': 'VersionInfo', 'VersionSave': 'VersionInfo', 'VerticalText': 'TextVertical', 'ViewGridOption': 'GridInfo', 'ViewIdiom': None, 'ViewOptionCtrlMark': None, 'ViewOptionGuideLine': None, 'ViewOptionMemo': None, 'ViewOptionMemoGuideline': None, 'ViewOptionPaper': None, 'ViewOptionParaMark': None, 'ViewOptionPicture': None, 'ViewOptionRevision': None, 'ViewShowGrid': 'GridInfo', 'ViewZoom': 'ViewProperties', 'ViewZoomFitPage': 'ViewProperties', 'ViewZoomFitWidth': 'ViewProperties', 'ViewZoomNormal': 'ViewProperties', 'VoiceCommand': None, 'VoiceCommandConfig': None, 'VoiceCommandResume': None, 'VoiceCommandStop': None, 'VoiceCommandView': None}

		#파라미터그룹이름안의 모든 파라미터이름들
		self.varx["parameter_set_id_vs_parameters"] = {'AutoFill': ['AutoFillSection', 'AutoFillItem'],
													'AutoNum': ['NumType', 'NewNumber'],
													'BookMark': ['Name', 'Type', 'Command'],
													'BorderFill': ['BorderTypeLeft', 'BorderTypeRight', 'BorderTypeTop', 'BorderTypeBottom', 'BorderWidthLeft', 'BorderWidthRight', 'BorderWidthTop', 'BorderWidthBottom',
																   'BorderCorlorLeft', 'BorderColorRight', 'BorderColorTop', 'BorderColorBottom', 'SlashFlag', 'BackSlashFlag', 'DiagonalType', 'DiagonalWidth', 'DiagonalColor',
																   'BorderFill3D', 'Shadow', 'FillAttr', 'CrookedSlashFlag', 'BreakCellSeparateLine', 'CounterSlashFlag', 'CounterBackSlashFlag', 'CenterLineFlag',
																   'CrookedSlashFlag1', 'CrookedSlashFlag2'],
													'BorderFillExt': ['TypeHorz', 'TypeVert', 'WidthHorz', 'WidthVert', 'ColorHorz', 'ColorVert', 'HasCharShape'],
													'BulletShape': ['CharShape', 'WidthAdjust', 'TextOffset', 'Alignment', 'UseInstWidth', 'AutoIndent', 'TextOffsetType', 'BulletChar', 'HasImage', 'BulletImage'],
													'Caption': ['Side', 'Width', 'Gap', 'CapFullSize'],
													'CaptureEnd': ['BeginX', 'BeginY', 'EndX', 'EndY', 'PageNum'],
													'Cell': ['HasMargin', 'Protected', 'Header', 'Width', 'Height', 'Editable', 'Dirty', 'CellCtrlData'],
													'CellBorderFill': ['ApplyTo', 'NoNeighborCell', 'TableBorderFill', 'AllCellsBorderFill', 'SelCellsBorderFill'],
													'ChangeRome': ['Option', 'HanString'],
													'CharShape': ['FaceNameHangul', 'FaceNameLatin', 'FaceNameHanja', 'FaceNameJapanese', 'FaceNameOther', 'FaceNameSymbol', 'FaceNameUser', 'FontTypeHangul', 'FontTypeLatin',
																  'FontTypeHanja', 'FontTypeJapanese', 'FontTypeOther', 'FontTypeSymbol', 'FontTypeUser', 'SizeHangul', 'SizeLatin', 'SizeHanja', 'SizeJapanese', 'SizeOther',
																  'SizeSymbol', 'SizeUser', 'RatioHangul', 'RatioLatin', 'RatioHanja', 'RatioJapanese', 'RatioOther', 'RatioSymbol', 'RatioUser', 'SpacingHangul', 'SpacingLatin',
																  'SpacingHanja', 'SpacingJapanese', 'SpacingOther', 'SpacingSymbol', 'SpacingUser', 'OffsetHangul', 'OffsetLatin', 'OffsetHanja', 'OffsetJapanese', 'OffsetOther',
																  'OffsetSymbol', 'OffsetUser', 'Bold', 'Italic', 'SmallCaps', 'Emboss', 'Engrave', 'SuperScript', 'SubScript', 'UnderlineType', 'OutlineType', 'ShadowType',
																  'TextColor', 'ShadeColor', 'UnderlineShape', 'UnderlineColor', 'ShadowOffsetX', 'ShadowOffsetY', 'ShadowColor', 'StrikeOutType', 'DiacSymMark', 'UseFontSpace',
																  'UseKerning', 'Height', 'BorderFill'],
													'ChCompose': ['Chars'],
													'CodeTable': ['Text'],
													'ColDef': ['Type', 'Count', 'SameSize', 'SameGap', 'WidthGap', 'Layout', 'LineType', 'LineWidth', 'LineColor', 'ApplyTo', 'ApplyClass'],
													'ConvertCase': ['Type'],
													'ConvertFullHalf': ['Type', 'Number', 'Alpha', 'Symbol', 'Gata', 'HGJamo'],
													'ConvertHiraToGata': ['Type'],
													'ConvertJianFan': ['Type'],
													'ConvertToHangul': ['Type', 'Hanja', 'Hira', 'Gata', 'Gu'],
													'CtrlData': ['Name'],
													'DeleteCtrls': ['DeleteCtrlType'],
													'DocFilters': ['DocFilters', 'Format', 'Type'],
													'DocFindInfo': ['ListID', 'ParaID', 'Pos'],
													'DocumentInfo': ['CurPara', 'CurPos', 'CurParaLen', 'CurCtrl', 'CurParaCount', 'RootPara', 'RootPos', 'RootParaCout', 'DetailInfo', 'DetailCharCount', 'DetailWordCount',
																	 'DetailLineCount', 'DetailPageCount', 'DetailCurPage', 'DetailCurPrtPage', 'SectionInfo', 'SecDef'],
													'DrawArcType': ['Type', 'Interval'],
													'DrawCoordInfo': ['Count', 'Point', 'Line'],
													'DrawCtrlHyperlink': ['Command'],
													'DrawEditDetail': ['Command', 'Index', 'PointX', 'PointY'],
													'DrawFillAttr': ['Type', 'GradationType', 'GradationAngle', 'GradationCenterX', 'GradationCenterY', 'GradationStep', 'GradationColorNum', 'GradationColor', 'GradationIndexPos',
																	 'GradationStepCenter', 'GradationAlpha', 'WinBrushFaceColor', 'WinBrushHatchColor', 'WinBrushAlpha', 'FileName', 'Embedded', 'PicEffect', 'Brightness',
																	 'Contrast', 'Reverse', 'DrawFillImageType', 'SkipLeft', 'SkipRight', 'SkipTop', 'SkipBottom', 'OriginalSizeX', 'OriginalSizeY', 'InsideMarginLeft',
																	 'InsideMarginRight', 'InsideMarginTop', 'InsideMarginBottom', 'WindowsBrush', 'GradationBrush', 'ImageBrush', 'ImageCreateOnDrag', 'ImageAlpha'],
													'DrawImageAttr': ['FileName', 'Embedded', 'PicEffect', 'Brightness', 'Contrast', 'Reverse', 'DrawFillImageType', 'SkipLeft', 'SkipRight', 'SkipTop', 'SkipBottom',
																	  'OriginalSizeX', 'OriginalSizeY', 'InsideMarginLeft', 'InsideMarginRight', 'InsideMarginTop', 'InsideMarginBotto m', 'WindowsBrush', 'GradationBrush',
																	  'ImageBrush', 'ImageCreateOnDrag'], 'DrawImageScissoring': ['Xoffset', 'Yoffset', 'HandleIndex'],
													'DrawLayOut': ['CreateNumPt', 'CreatePt', 'CurveSegmentInfo'],
													'DrawLineAttr': ['Color', 'Style', 'Width', 'EndCap', 'HeadStyle', 'TailStyle', 'HeadSize', 'TailSize', 'HeadFill', 'TailFill', 'OutLineStyle', 'Alpha'],
													'DrawRectType': ['Type'],
													'DrawResize': ['Xoffset', 'Yoffset', 'HandleIndex', 'Mode'],
													'DrawRotate': ['Command', 'CenterX', 'CenterY', 'ObjectCenterX', 'ObjectCenterY', 'Angle', 'RotateImage'],
													'DrawScAction': ['RotateCenterX', 'RotateCenterY', 'RotateAngel', 'HorzFlip', 'VertFlip'],
													'DrawShadow': ['ShadowType', 'ShadowColor', 'ShadowOffsetX', 'ShadowOffsetY', 'ShadowAlpha'],
													'DrawShear': ['XFactor', 'YFactor'],
													'DrawTextart': ['String', 'FontName', 'FontStyle', 'FontType', 'LineSpacing', 'CharSpacing', 'AlignType', 'Shape', 'ShadowType', 'ShadowOffsetX', 'ShadowOffsetY', 'ShadowColor', 'NumberOfLines'],
													'DropCap': ['Style', 'FaceName', 'LineStyle', 'LineWeight', 'LineColor', 'FaceColor', 'Spacing'],
													'Dutmal': ['ResultText', 'SubText', 'PosType', 'FsizeRatio', 'Option', 'StyleNo', 'Align', 'Delete', 'Modify'],
													'EngineProperties': ['DoAnyCursorEdit', 'DoOutLineStyle', 'InsertLock', 'TabMoveCell', 'FaxDriver', 'PDFDriver', 'EnableAutoSpell'],
													'EqEdit': ['String', 'BaseUnit', 'Color', 'LineMode', 'Version', 'ApplyTo'],
													'ExchangeFootnoteEndNote': ['Flag'],
													'FieldCtrl': ['Command', 'Editable', 'FieldDirty', 'CtrlData'],
													'FileConvert': ['Format', 'SrcFileList', 'DestFileList'],
													'FileInfo': ['Format', 'VersionStr', 'VersionNum', 'Encrypted'],
													'FileOpen': ['OpenFileName', 'SaveFileName', 'OpenFormat', 'SaveFormat', 'OpenReadOnly', 'OpenFlag', 'SaveOverWrite', 'ModifiedFlag', 'Argument', 'SaveCMFDoc30',
																 'SaveHwp97', 'SaveDistribute', 'SaveDRMDoc'],
													'FileSaveAs': ['OpenFileName', 'SaveFileName', 'OpenFormat', 'SaveFormat', 'OpenReadOnly', 'OpenFlag', 'SaveOverWrite', 'ModifiedFlag', 'Argument', 'SaveCMFDoc30',
																   'SaveHwp97', 'SaveDistribute', 'SaveDRMDoc'],
													'FileSaveBlock': ['FileName', 'Format', 'Argument'],
													'FileSendMail': ['To', 'Type', 'Subject', 'Filepath'],
													'FileSetSecurity': ['Password', 'NoPrint', 'NoCopy'],
													'FindReplace': ['FindString', 'ReplaceString', 'Direction', 'MatchCase', 'AllWordForms', 'SeveralWords', 'UseWildCards', 'WholeWordOnly', 'AutoSpell', 'ReplaceMode',
																	'IgnoreFindString', 'IgnoreReplaceStrin g', 'FindCharShape', 'FindParaShape', 'ReplaceCharShape', 'ReplaceParaShape', 'FindStyle', 'ReplaceStyle',
																	'IgnoreMessage', 'HanjaFromHangul', 'FindJaso', 'FindRegExp', 'FindType'],
													'FlashProperties': ['Base', 'Qulaity', 'Scale', 'WMode', 'AutoPlay', 'LoopPlay', 'ShowMenu', 'BgColor'],
													'FootnoteShape': ['NumberFormat', 'UserChar', 'PrefixChar', 'Suffix', 'PlaceAt', 'Restart', 'NewNumber', 'LineLength', 'LineType', 'LineWidth',
																					 'SpaceAboveLine', 'SpaceBelowLine', 'SpaceBetweenNotes', 'SuperScript', 'BeneathText', 'ApplyTo', 'ApplyClass'],
													'EndnoteShape': ['NumberFormat', 'UserChar', 'PrefixChar', 'Suffix', 'PlaceAt', 'Restart', 'NewNumber', 'LineLength', 'LineType', 'LineWidth',
																					 'SpaceAboveLine', 'SpaceBelowLine', 'SpaceBetweenNotes', 'SuperScript', 'BeneathText', 'ApplyTo', 'ApplyClass'],
													'FtpUpload': ['Server', 'UserName', 'Password', 'Directory', 'FileName', 'SiteName', 'SaveType'],
													'FtpDownload': ['Server', 'UserName', 'Password', 'Directory', 'FileName', 'SaveType'],
													'GotoE': ['SetSelectionIndex', 'DialogResult'],
													'GridInfo': ['Method', 'Align', 'HorzAlign', 'VertAlign', 'Type', 'HorzSpan', 'VertSpan', 'HorzRange', 'VertRange', 'Show', 'ZOrder', 'ViewLine'],
													'HeaderFooter': ['DialogOption', 'DialogResult', 'CtrlType', 'Type', 'HeaderFooterCtrlType', 'HeaderFooterStyle', 'Type'],
													'HyperLink': ['Text', 'Command', 'NoLInk', 'ShapeObject', 'DirectInsert'],
													'HyperlinkJump': ['Source', 'Target'],
													'Idiom': ['InputText', 'InputType'],
													'IndexMark': ['First', 'Second'],
													'InputDateStyle': ['DateStyleType', 'DateStyleDataForm'],
													'InsertFieldTemplate': ['ShowSingle', 'TemplateDirection', 'TemplateHelp', 'TemplateName', 'TemplateType', 'Editable'],
													'InsertFile': ['FileName', 'FileFormat', 'FileArg', 'KeepSection', 'KeepCharshape', 'KeepParashape', 'KeepStyle'],
													'InsertText': ['Text'],
													'Internet': ['OpenUrlWhere', 'OpenUrlString'],
													'KeyMacro': ['Index', 'RepeatCount', 'Name'],
													'LinkDocument': ['Name', 'PageInherit', 'FootnoteInherit'],
													'ListParaPos': ['List', 'Para', 'Pos'],
													'ListProperties': ['TextDirection', 'LineWrap', 'VertAlign', 'MarginLeft', 'MarginRight', 'MarginTop', 'MarginBottom'],
													'MailMergeGenerate': ['Input', 'HwpPath', 'HwpId', 'DbfPath', 'DbfCode', 'Output', 'FileName', 'Continue', 'PrintSet', 'Subject', 'Type', 'Field', 'FieldUpdate', 'NxlPath'],
													'MakeContents': ['Make', 'Level', 'AutoTabRight', 'Leader', 'OutlineNumber', 'Styles', 'StyleName', 'OutFileName', 'Position'],
													'MarkpenShape': ['Color'],
													'MasterPage': ['Type', 'Duplicate', 'Front', 'ApplyTo'],
													'MemoShape': ['Width', 'LineType', 'LineWidth', 'LineColor', 'FillColor', 'ActiveFillColor', 'MemoType'],
													'MousePos': ['XRelTo', 'YRelTo', 'Page', 'X', 'Y'],
													'MovieProperties': ['Base', 'Caption', 'AutoPlay', 'AutoRewind', 'ShowMenu', 'ShowCtrlPanel', 'ShowPosCtrl', 'EnablePos', 'ShowTrackBar', 'EnableTrack', 'ShowChaption', 'ShowAudio', 'ShowStatus'],


													'NumberingShape': ['HasCharShapeLevel0', 'HasCharShapeLevel1','HasCharShapeLevel2','HasCharShapeLevel3','HasCharShapeLevel4','HasCharShapeLevel5','HasCharShapeLevel6',
																	   'CharShapeLevel0', 'CharShapeLevel1', 'CharShapeLevel2', 'CharShapeLevel3', 'CharShapeLevel4', 'CharShapeLevel5', 'CharShapeLevel6',
																	   'WidthAdjustLevel0', 'WidthAdjustLevel1', 'WidthAdjustLevel2', 'WidthAdjustLevel3', 'WidthAdjustLevel4', 'WidthAdjustLevel5', 'WidthAdjustLevel6',
																	   'TextOffsetLevel0', 'TextOffsetLevel1', 'TextOffsetLevel2', 'TextOffsetLevel3', 'TextOffsetLevel4', 'TextOffsetLevel5', 'TextOffsetLevel6',
																	   'AlignmentLevel0', 'AlignmentLevel1', 'AlignmentLevel2', 'AlignmentLevel3', 'AlignmentLevel4', 'AlignmentLevel5', 'AlignmentLevel6',
																	   'UseInstWidthLevel0', 'UseInstWidthLevel1', 'UseInstWidthLevel2', 'UseInstWidthLevel3', 'UseInstWidthLevel4', 'UseInstWidthLevel5', 'UseInstWidthLevel6',
																	   'AutoIndentLevel0', 'AutoIndentLevel1', 'AutoIndentLevel2', 'AutoIndentLevel3', 'AutoIndentLevel4', 'AutoIndentLevel5', 'AutoIndentLevel6',
																	   'TextOffsetTypeLevel0', 'TextOffsetTypeLevel1', 'TextOffsetTypeLevel2', 'TextOffsetTypeLevel3', 'TextOffsetTypeLevel4', 'TextOffsetTypeLevel5', 'TextOffsetTypeLevel6',
																	   'StrFormatLevel0', 'StrFormatLevel1', 'StrFormatLevel2', 'StrFormatLevel3', 'StrFormatLevel4', 'StrFormatLevel5', 'StrFormatLevel6',
																	   'NumFormatLevel0', 'NumFormatLevel1', 'NumFormatLevel2', 'NumFormatLevel3', 'NumFormatLevel4', 'NumFormatLevel5', 'NumFormatLevel6',
																	   'StartNumber', 'NewList'],

													'OleCreation': ['Type', 'Clsid', 'Path', 'Aspect', 'IconMetafile', 'IconMM', 'IconXext', 'IconYext', 'InnerOCX', 'SoProperties', 'FlashProperties', 'MovieProperties'],
													'PageBorderFill': ['TextBorder', 'HeaderInside', 'FooterInside', 'FillArea', 'OffsetLeft', 'OffsetRight', 'OffsetTop', 'OffsetBottom'],
													'PageDef': ['PaperWidth', 'PaperHeight', 'Landscape', 'LeftMargin', 'RightMargin', 'TopMargin', 'BottomMargin', 'HeaderLen', 'FooterLen', 'GutterLen', 'GutterType', 'ApplyTo', 'ApplyClass'],
													'PageHiding': ['Fields'],
													'PageNumCtrl': ['PageStartsOn'],
													'PageNumPos': ['NumberFormat', 'UserChar', 'PrefixChar', 'SuffixChar', 'SideChar', 'DrawPos'],
													'ParaShape': ['LeftMargin', 'RightMargin', 'Indentation', 'PrevSpacing', 'NextSpacing', 'LineSpacingType', 'LineSpacing', 'AlignType', 'BreakLatinWord', 'BreakNonLatinWord',
																  'SnapToGrid', 'Condense', 'WidowOrphan', 'KeepWithNext', 'KeepLinesTogether', 'PagebreakBefore', 'TextAlignment', 'FontLineHeight', 'HeadingType', 'Level',
																  'BorderConnect', 'BorderText', 'BorderOffsetLeft', 'BorderOffsetRight', 'BorderOffsetTop', 'BorderOffsetBottom', 'TailType', 'LineWrap', 'TabDef', 'Numbering',
																  'Bullet', 'BorderFill'],
													'Password': ['DialogResult', 'String', 'FullRange', 'Ask', 'String', 'FullRange', 'Ask', 'Level'],
													'Preference': ['ShowSinglePage', 'ApplyLinkAttr', 'ApplyForbidden', 'StartForbiddenStr', 'EndForbiddenStr'],
													'Presentation': ['DialogResult', 'Effect', 'Sound', 'InvertText', 'ShowMode', 'ShowPage', 'ShowTime'],
													'Print': ['DialogOption', 'DialogResult', 'Range', 'RangeCustom', 'RangeIncludeLinkedDoc', 'NumCopy', 'Collate', 'PrintMethod', 'PrinterPaperSize', 'PrinterPaperWidth',
															  'PrinterPaperLength', 'PrintAutoHeadNote', 'PrintAutoFootNote', 'PrintAutoHeadnoteLtext', 'PrintAutoHeadnoteCtext', 'PrintAutoHeadnoteRtext', 'PrintAutoFootnoteLtext',
															  'PrintAutoFootnoteCtext', 'PrintAutoFootnoteRtext', 'PrinterName', 'PrintToFile', 'FileName', 'ReverseOrder', 'Pause', 'PrintImage', 'PrintDrawObj', 'PrintClickHere',
															  'PrintCropMark', 'IdcPrintWallPaper', 'LastBlankPage', 'BinderHoleType', 'EvenOddPageType', 'ZoomX', 'ZoomY', 'StartPageNum', 'StartFootNoteNum', 'Flags', 'Device',
															  'PrintFormObj', 'PrintMarkPen', 'PrintMemo', 'PrintMemoContents', 'PrintRevision', 'PrintWatermark'],
													'PrintToImage': ['Format', 'FileName', 'ColorDepth', 'Resolution'],
													'PrintWatermark': ['WatermarkType', 'PosPage', 'TextWrap', 'AlphaText', 'AlphaImage', 'FileName', 'PicEffect', 'Brightness', 'Contrast', 'DrawFillImageType', 'String', 'FontName',
																	   'FontType', 'FontSize', 'ShadowType', 'ShadowOffsetX', 'ShadowOffsetY', 'ShadowColor', 'FontColor', 'RotateAngle', 'WaterMarkEff'],
													'QCorrect': ['LauncherKey', 'HyperLinkRunKey'],
													'RevisionDef': ['SignType', 'SubText', 'Margin', 'BeginPos'],
													'SaveFootnote': ['FileName', 'Flag'],
													'ScriptMacro': ['Index', 'RepeatCount', 'Name', 'Detail'],
													'SecDef': ['TextDirection', 'StartsOn', 'LineGrid', 'CharGrid', 'PageDef', 'HideEmptyLine', 'SpaceBetweenColumns', 'TabStop', 'FootnoteShape', 'EndnoteShape', 'HideHeader',
															   'HideFooter', 'HideMasterPage', 'HideBorder', 'HideFill', 'HidePageNumPos', 'FirstBorder', 'FirstFill', 'OutlineShape', 'PageBorderFillBoth', 'PageBorderFillEven',
															   'PageBorderFillOdd', 'PageNumber', 'FigureNumber', 'TableNumber', 'EquationNumber', 'WongojiFormat', 'MemoShape', 'TextVerticalWidthHead', 'ApplyTo', 'ApplyClass', 'ApplyToPageBorderFill'],
													'SectionApply': ['ApplyTo', 'String', 'Index', 'ConvAplly2Index', 'Category'],
													'ShapeCopyPaste': ['Type', 'CellAttr', 'CellBorder', 'CellFill', 'TypeBodyAndCellOnly'],
													'ShapeObject': ['TreatAsChar', 'AffectsLine', 'VertRelTo', 'VertAlign', 'VertOffset', 'HorzRelTo', 'HorzAlign', 'HorzOffset', 'FlowWithText', 'AllowOverlap', 'WidthRelTo',
																	'Width', 'HeightRelTo', 'Height', 'ProtectSize', 'TextWrap', 'TextFlow', 'OutsideMarginLeft', 'OutsideMarginRight', 'OutsideMarginTop', 'OutsideMarginBottom',
																	'NumberingType', 'LayoutWidth', 'LayoutHeight', 'Lock', 'HoldAnchorObj', 'PageNumber', 'AdjustSelection', 'AdjustTextBox', 'AdjustPrevObjAttr', 'ShapeDrawLayOut',
																	'ShapeDrawLineAttr', 'ShapeDrawFillAttr', 'ShapeDrawImageAttr', 'ShapeDrawRectType', 'ShapeDrawArcType', 'ShapeDrawResize', 'ShapeDrawRotate', 'ShapeDrawEditDetail',
																	'ShapeDrawImageScissoring', 'ShapeDrawScAction', 'ShapeDrawCtrlHyperlink', 'ShapeDrawCoordInfo', 'ShapeDrawShear', 'ShapeDrawTextart', 'ShapeDrawShadow',
																	'ShapeTableCell', 'ShapeListProperties', 'ShapeCaption', 'ShapeFormGeneral', 'ShapeFormCommonAttr', 'ShapeFormCharshapeattr', 'ShapeFormButtonAttr', 'ShapeFormComboboxAttr',
																	'ShapeFormEditAttr', 'ShapeFormScrollbarAttr', 'ShapeFormListBoxAttr', 'ShapeType', 'ShapeCellSize', 'ShapeCreationType', 'ShapeCreationMode'],
													'ShapeObjectCopyPaste': ['Type', 'ShapeObjectLine', 'ShapeObjectFill', 'ShapeObjectSize', 'ShapeObjectShadow', 'ShapeObjectPicEffect'],
													'Sort': ['KeyOption', 'CheckJasoReverse', 'DelimiterType', 'DelimiterChars', 'IgnoreMultiDelimiter', 'CheckFromRear', 'CheckExtendYear', 'YearBase', 'LangOrderType', 'CheckJaso'],
													'Style': ['Apply'],
													'StyleDelete': ['Target', 'Alternation'],
													'StyleTemplate': ['FileName'],
													'Sum': ['Sum', 'Average', 'LineCount', 'Comma', 'Option'],
													'SummaryInfo': ['Title', 'Subject', 'Author', 'Date', 'KeyWords', 'Comments', 'CreationTimeLow', 'CreationTimeHigh', 'ModifiedTimeLow', 'ModifiedTimeHigh', 'PrintedTimeLow',
																	'PrintedTimeHigh', 'LastSavedBy', 'Characters', 'Words', 'Lines', 'Paragraphs', 'Pages', 'CopyPapers', 'Etcetera', 'DocVersion', 'HwpVersion', 'HanjaChar'],
													'TabDef': ['AutoTabLeft', 'AutoTabRight', 'TabItem'],
													'Table': ['PageBreak', 'RepeatHeader', 'CellSpacing', 'CellMarginLeft', 'CellMarginRight', 'CellMarginTop', 'CellMarginBottom', 'BorderFill', 'TableCharInfo', 'TableBorderFill', 'Cell'] ,
													'TableCreation': ['Rows', 'Cols', 'RowHeight', 'ColWidth', 'CellInfo', 'WidthType', 'HeightType', 'WidthValue', 'HeightValue', 'TableTemplateValue', 'TableProperties', 'TableTemplate', 'TableDrawProperties'],
													'TableDeleteLine': ['Type'],
													'TableDrawPen': ['Style', 'Width', 'Color'],
													'TableInsertLine': ['Side', 'Count'],
													'TableSplitCell': ['Cols', 'Rows', 'DistributeHeight', 'Merge', 'Mode2'],
													'TableStrToTbl': ['DelimiterType', 'UserDefine', 'AutoOrDefine', 'KeepSeperator', 'DelimiterEtc'],
													'TableSwap': ['Type', 'SwapMargin'],
													'TableTblToStr': ['DelimiterType', 'UserDefine'],
													'TableTemplate': ['Format', 'ApplyTarger', 'FileName', 'CreateMode'],
													'TextCtrl': ['CtrlData', 'Landscope'],
													'TextVertical': ['TextDirection', 'TextVerticalWidthHead', 'ApplyTo', 'ApplyClass'],
													'UserQCommandFile': ['Save', 'FileName', 'LoadType'],
													'VersionInfo': ['SourcePath', 'TargetPath', 'ItemStartIndex', 'ItemEndIndex', 'ItemOverWrite', 'ItemSaveDescription', 'TempFilePath', 'ItemInfoIndex', 'SaveFilePath', 'ItemInfoWriter',
																	'ItemInfoDescription', 'ItemInfoTimeHi', 'ItemInfoTimeLo', 'ItemInfoLock'],
													'ViewProperties': ['OptionFlag', 'ZoomType', 'ZoomRatio', 'ZoomCntX', 'ZoomCntY', 'ZoomMirror']}

		#모든 액션이름들
		self.varx["all_action_name"] = list(self.varx["action_name_vs_manual"].keys())

		#모든 파라미터그룹이름들
		self.varx["all_parameter_set_id"] = list(self.varx["parameter_set_id_vs_parameters"].keys())



		# 한글 application이 실행중인지 확인한다
		if self.__check_hwp_obj():
			if not self.han_program:
				self.han_program = win32com.client.Dispatch("HWPFrame.HwpObject")
			if file_name == "":
				#print("실행1 : 한글프로그램 실행중 + ''")
				self.han_program.XHwpWindows.Active_XHwpWindow.Visible = 1  # 혹시 hidden으로 되어있을지 몰라서 show로 만드는 것
			elif file_name == "new":
				#print("실행2 : 한글프로그램 실행중 + 'new'")
				self.one_hwp = self.han_program.XHwpDocuments.Add(0)
				self.han_program.XHwpWindows.Active_XHwpWindow.Visible = 1  # 혹시 hidden으로 되어있을지 몰라서 show로 만드는 것
			else:
				self.han_program.Open(file_name)
		else:
			if file_name == "" or file_name == "new":
				#print("실행3 : 한글프로그램 실행 X + '' 또는 'new'")
				self.han_program = win32com.client.gencache.EnsureDispatch("HWPFrame.HwpObject")
				self.han_program.RegisterModule("FilePathCheckDLL", "AutomationModule")  # 보안모둘 실행
				self.han_program.XHwpWindows.Active_XHwpWindow.Visible = 1
			else:
				self.han_program.Open(file_name)

	def active_doc(self):
		"""
		현재 오픈된 한글 문서의 객체를 갖고온다

		:return:
		"""
		context = pythoncom.CreateBindCtx(0)
		running_coms = pythoncom.GetRunningObjectTable()
		monikers = running_coms.EnumRunning()
		for moniker in monikers:
			name = moniker.GetDisplayName(context, moniker)
			if "hwp" in str(name).lower():
				obje = running_coms.GetObject(moniker)
				self.han_program = win32com.client.Dispatch(obje.QueryInterface(pythoncom.IID_IDispatch))
				self.han_program.RegisterModule("FilePathCheckDLL", "AutomationModule")  # 보안모둘 실행
				self.han_program.XHwpWindows.Item(0).Visible = 1

		return self.han_program

	def apply_font_style_for_selection(self, my_range):
		"""
		선택영역에 대한 공동폰트로 설정한것을 적용

		:param my_range:
		:return:
		"""
		if self.varx["basic_underline"]:
			my_range.Font.Underline = 1
		if self.varx["basic_size"]:
			my_range.Font.Size = self.varx["basic_size"]
		if self.varx["basic_bold"]:
			my_range.Font.Bold = 1
		if self.varx["rgb_int"]:
			my_range.Font.TextColor.RGB = self.varx["rgb_int"]

	def check_action_name(self, input_action):
		"""
		입력으로 드렁온 글자가 있는 모든 action name을 확인하는 것입니다

		:param input_action:action 이름
		:return:
		"""
		result = []

		for a_action in self.var_action_name_vs_parameter_set_id.keys():
			if str(input_action).lower() in str(a_action).lower():
				result.append(a_action)
			try:
				manual = self.var_action_name_vs_manual[a_action]
				if input_action in manual:
					result.append(a_action)
			except:
				pass

		return result

	def check_action_name_as_dic(self, input_action_name):
		"""
		별도의 입력값없이 결과만 갖고오는 action id에대한 모든 결과값을 dic형태로 갖고오는것

		:param input_action_name:
		:return:
		"""
		result = {}

		parameter_name = self.varx["action_name_vs_parameter_set_id"][input_action_name]

		action_obj = self.han_program.CreateAction(input_action_name)
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)
		action_obj.Execute(parameter_set_obj)

		for one in self.varx["parameter_set_id_vs_parameters"][parameter_name]:
			result[one] = parameter_set_obj.Item(one)
		return result

	def check_information_for_doc(self):
		"""
		현재 열려져있는 문서의 기본 정보를 갖고옵니다

		:return:
		"""
		action_obj = self.han_program.CreateAction("DocumentInfo")
		# 변수를 넣는 변수객체를 만든다
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)

		# 결과를 얻고싶은 변수를 넣읍니다
		parameter_set_obj.SetItem("DetailInfo", 1)
		action_obj.Execute(parameter_set_obj)

		result = {}
		para_id_set = ["CurPos", "CurParaLen", "CurCtrl", "CurParaCount",
					   "RootPara", "RootPos", "RootParaCout", "DetailInfo", "DetailCharCount", "DetailWordCount",
					   "DetailLineCount", "DetailPageCount", "DetailCurPage", "DetailCurPrtPage",
					   "SectionInfo", "SecDef", ]

		for one_id in para_id_set:
			result[one_id] = parameter_set_obj.Item(one_id)

		return result

	def check_options(self, input_parameter):
		"""
		입력요소에 대하여 확인하는 것

		:param input_parameter:
		:return:
		"""
		# all_data = basic_data_for_han.basic_data().xvar
		try:
			result = self.varx["parameter_vs_parameter_option"][input_parameter]
		except:
			result = "없음"
		if not result:
			result = "없음"
		return result

	def check_parameter_set_id(self, input_action):
		"""
		액션이름이 들어오면 parameter_set_id를 돌려주는 것
		all_data = basic_data_for_han.basic_data().xvar

		:param input_action:action 이름
		:return:
		"""
		result = "없음"
		try:
			result = self.varx['action_name_vs_parameter_set_id'][input_action]
		except:
			pass
		return result

	def check_parameters(self, input_parameter_set_id):
		"""
		입력 parameters에 대하여 확인하는 것

		:param input_parameter_set_id:
		:return:
		"""
		# all_data = basic_data_for_han.basic_data().xvar
		try:
			result = self.varx["parameter_set_id_vs_parameters"][input_parameter_set_id]
		except:
			result = "없음"
		if not result:
			result = "없음"
		return result

	def close(self):
		"""
		현재 활성화가된 한글 객체를 닫는다

		:return:
		"""
		self.han_program.Clear(3)
		self.han_program.Quit()

	def close_all(self):
		"""
		열려져있는 모든 한글 객체를 닫는다

		:return:
		"""
		context = pythoncom.CreateBindCtx(0)
		running_coms = pythoncom.GetRunningObjectTable()
		monikers = running_coms.EnumRunning()
		for moniker in monikers:
			name = moniker.GetDisplayName(context, moniker)
			if "hwpobject" in str(name).lower():
				#print(name)
				obje = running_coms.GetObject(moniker)
				self.han_program = win32com.client.Dispatch(obje.QueryInterface(pythoncom.IID_IDispatch))
				self.han_program.RegisterModule("FilePathCheckDLL", "AutomationModule")  # 보안모둘 실행
				self.han_program.Clear(3)
				self.han_program.Quit()

	def copy(self):
		"""
		복사하기

		:return:
		"""
		self.han_program.HAction.Run('Copy')

	def copy_for_selection(self):
		"""
		복사 : 선택한 영역을 복사

		:return:
		"""
		self.han_program.HAction.Run('Copy')

	def count_char_in_doc(self):
		"""
		갯수 : 현재 선택된 문서의 전체 글자수

		:return:
		"""
		result = self.check_information_for_doc()["DetailCharCount"]
		return result

	def count_char_for_selection(self):
		"""
		갯수 : 선택영역의 전체 글자갯수 (공백도 1개의 글자임)

		:return:
		"""

		aaa = self.read_value_for_selection()
		result = len(str(aaa))
		return result

	def count_doc(self):
		"""
		갯수 : 열려져있는 문서의 총 갯수를 돌려준다

		:return:
		"""
		result = self.han_program.XHwpWindows.Count  # 총문서 갯수
		return result

	def count_hwp_obj(self):
		"""
		갯수 : 현재 오픈된 한글 문서가 있으면, 그 객체를 갖고온다

		:return:
		"""
		result = []
		context = pythoncom.CreateBindCtx(0)
		running_coms = pythoncom.GetRunningObjectTable()
		monikers = running_coms.EnumRunning()
		for moniker in monikers:
			name = moniker.GetDisplayName(context, moniker)
			if "hwp" in str(name).lower():
				#print(name)
				result.append(name)

		#print("갯수는 => ", len(result), len)
		return result

	def count_line_in_doc(self):
		"""
		갯수 : 현재 문서의 전체 줄수

		:return:
		"""
		action_obj = self.han_program.CreateAction("DocumentInfo")
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)
		parameter_set_obj.SetItem("DetailInfo", 1)
		action_obj.Execute(parameter_set_obj)
		result = parameter_set_obj.Item("DetailLineCount")
		return result

	def count_page_in_doc(self):
		"""
		갯수 : 현재 선택된 문서의 총 페이지수

		:return:
		"""
		result = self.check_information_for_doc()["DetailPageCount"]
		return result

	def count_para_in_doc(self):
		"""
		갯수 : 현재 선택된 문서의 총 문단수

		:return:
		"""
		pass

	def count_shape_in_doc(self):
		"""
		갯수 : 현재 선택된 문서의 총 그리기 개체수
		첫번째 컨트롤(HaedCtrl)를 사용해서 탐색 시작할수있다

		:return:
		"""
		ctrl = self.han_program.HeadCtrl
		count = 0
		while ctrl != None:
			nextctrl = ctrl.Next
			if ctrl.CtrlID == "gso":
				count += 1
			ctrl = nextctrl
		return count

	def count_table_in_doc(self):
		"""
		갯수 : 현재 선택된 문서의 총 테이블수
		첫번째 컨트롤(HaedCtrl)부터 탐색 시작
		"""
		ctrl = self.han_program.HeadCtrl
		count = 0
		while ctrl != None:
			nextctrl = ctrl.Next
			if ctrl.CtrlID == "tbl":
				count += 1
			ctrl = nextctrl
		return count

	def count_word_in_doc(self):
		"""
		갯수 : 현재 선택된 문서의 총 단어수

		:return:
		"""
		action_obj = self.han_program.CreateAction("DocumentInfo")
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)
		parameter_set_obj.SetItem("DetailInfo", 1)
		action_obj.Execute(parameter_set_obj)

		result = parameter_set_obj.Item("DetailWordCount")
		return result

	def count_word_for_selection(self):
		"""
		갯수 : 선택영역안의 단어수

		:return:
		"""
		aaa = self.read_text_for_selection()
		result = len(str(aaa).split(" "))
		return result

	def data_control_id(self):
		"""
		control의 id

		:return:
		"""
		aaa = {
			"cold": ["ColDef", "단"],
			"secd": ["SecDef", "구역"],
			"fn": ["FootnoteShape", "각주"],
			"en": ["FootnoteShape", "미주"],
			"tbl": ["Table", "표"],
			"eqed": ["EqEdit", "수식"],
			"gso": ["ShapeObject", "그리기 개체"],
			"atno": ["AutoNum", "번호 넣기"],
			"nwno": ["AutoNum", "새 번호로"],
			"pgct": ["PageNumCtrl", "페이지 번호 제어 "],
			"pghd": ["PageHiding", "감추기"],
			"pgnp": ["PageNumPos", "쪽 번호 위치"],
			"head": ["HeaderFooter", "머리말"],
			"foot": ["HeaderFooter", "꼬리말"],
			"%dte": ["FieldCtrl", "현재의 날짜/시간 필드"],
			"%ddt": ["FieldCtrl", "파일 작성 날짜/시간 필드"],
			"%pat": ["FieldCtrl", "문서 경로 필드"],
			"%bmk": ["FieldCtrl", "블록 책갈피"],
			"%mmg": ["FieldCtrl", "메일 머지"],
			"%xrf": ["FieldCtrl", "상호 참조"],
			"%fmu": ["FieldCtrl", "계산식"],
			"%clk": ["FieldCtrl", "누름틀"],
			"%smr": ["FieldCtrl", "문서 요약 정보 필드"],
			"%usr": ["FieldCtrl", "사용자 정보 필드"],
			"%hlk": ["FieldCtrl", "하이퍼링크"],
			"bokm": ["TextCtrl", "책갈피"],
			"idxm": ["IndexMark", "찾아보기"],
			"tdut": ["Dutmal", "덧말"],
			"tcmt": ["없음", "주석"], }
		return aaa

	def delete_all_in_doc(self):
		"""
		삭제 : 문서의 모든 것을 삭제

		:return:
		"""
		self.han_program.Run('SelectAll')
		self.han_program.HAction.Run("Delete")

	def delete_all_in_document(self):
		"""
		삭제 : 문서의 모든 것을 삭제

		:return:
		"""
		self.han_program.Run('SelectAll')
		self.han_program.HAction.Run("Delete")

	def delete_char_by_no(self, input_no):
		"""
		삭제 : 문서의 시작에서부터 n번째의 문자를 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char_from_begin_of_doc(input_no - 1)
		self.select_nth_char_from_selection(1)
		self.han_program.HAction.Run("Delete")

	def delete_char_from_cursor_to_end_of_line(self):
		"""
		삭제 : 현재 커서에서 줄끝가지의 글자를 삭제
		selection이 있으면 실행이 되지 않는다

		:return:
		"""
		self.move_cursor_to_begin_of_selection()
		self.han_program.HAction.Run("DeleteLineEnd")

	def delete_char_from_cursor_to_nth_char(self, input_no):
		"""
		삭제 : 현재 커서에서 n번째 글자까지 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_char_from_selection(input_no - 1)
		self.han_program.HAction.Run("Delete")

	def delete_current_line_at_cursor(self):
		"""
		삭제 : 현재 커서가있는 라인의 삭제

		:return:
		"""
		self.han_program.HAction.Run("DeleteLine")

	def delete_header_footer(self):
		"""
		삭제 : 현재 선택된 문서의 머릿글과 꼬릿글을 삭제

		:return:
		"""
		return self.han_program.HAction.Run("HeaderFooterDelete")

	def delete_line_at_cursor(self):
		"""
		삭제 : 현재 커서가 있는 라인 삭제

		:return:
		"""
		self.han_program.HAction.Run("DeleteLine")

	def delete_line_by_no(self, input_no):
		"""
		삭제 : 줄번호로 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_line_from_begin_of_doc(input_no - 1)
		self.han_program.HAction.Run("DeleteLine")

	def delete_nth_char_from_start_of_doc(self, input_no):
		"""
		삭제 : 문서의 시작에서 부터 n번째의 글자를 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char_from_begin_of_doc(input_no - 1)
		self.select_nth_char_from_selection(1)
		self.han_program.HAction.Run("Delete")

	def delete_nth_line_from_start_of_doc(self, input_no):
		"""
		삭제 : 문서시작에서 n번째 라인을 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_line_from_begin_of_doc(input_no - 1)
		self.han_program.HAction.Run("DeleteLine")

	def delete_nth_para_from_start_of_doc(self, input_no):
		"""
		삭제 : 문서시작에서 n번째 문단을 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_para_from_begin_of_doc(input_no - 1)
		self.select_current_para()
		self.han_program.HAction.Run("Delete")

	def delete_nth_shape_from_start_of_doc(self, input_no):
		"""
		삭제 : 문서시작에서 n번째 그리기 객체 번호로 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		ctrl = self.han_program.HeadCtrl  # 첫번째 컨트롤(HaedCtrl)부터 탐색 시작.
		count = 0

		while ctrl != None:
			nextctrl = ctrl.Next
			if ctrl.CtrlID == "gso":
				count += 1
				if input_no == count:
					# self.han_program.SetPosBySet(ctrl.GetAnchorPos(0))
					# self.han_program.FindCtrl()
					self.han_program.DeleteCtrl(ctrl)
					break
			ctrl = nextctrl

	def delete_nth_table_from_start_of_doc(self, input_no):
		"""
		삭제 : 문서시작에서 n번째 테이블 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		ctrl = self.han_program.HeadCtrl  # 첫번째 컨트롤(HaedCtrl)부터 탐색 시작.
		count = 0

		while ctrl != None:
			nextctrl = ctrl.Next
			if ctrl.CtrlID == "tbl":
				count += 1
				if input_no == count:
					# self.han_program.SetPosBySet(ctrl.GetAnchorPos(0))
					# self.han_program.FindCtrl()
					self.han_program.DeleteCtrl(ctrl)
					break
			ctrl = nextctrl

	def delete_nth_word_from_selection(self):
		"""
		삭제 : 선택한 영역을 기준으로 왼쪽 여역을 기준으로 n번째 단어 삭제

		:return:
		"""
		self.han_program.HAction.Run("DeleteWordBack")

	def delete_nth_word_from_start_of_doc(self, input_no):
		"""
		삭제 : 문서처음에서부터 n번째 단어 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_word_from_begin_of_doc(input_no - 1)
		self.han_program.HAction.Run("Delete")

	def delete_one_word_at_cursor(self):
		"""
		삭제 : 커서에서 단어1개 삭제

		:return:
		"""
		self.han_program.HAction.Run("DeleteWord")

	def delete_para_by_no(self, input_no):
		"""
		삭제 : 문단번호로 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_para_by_no(input_no - 1)
		self.select_current_para()
		self.han_program.HAction.Run("Delete")

	def delete_previous_word_from_cursor(self):
		"""
		삭제 : 현재커서의 전 단어 삭제

		:return:
		"""
		self.han_program.HAction.Run("DeleteWordBack")

	def delete_selection(self):
		"""
		삭제 : 선택영역 삭제

		:return:
		"""
		self.han_program.HAction.Run("Delete")

	def delete_shape_by_no(self, input_no):
		"""
		삭제 : 그리기 객체 번호로 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		ctrl = self.han_program.HeadCtrl  # 첫번째 컨트롤(HaedCtrl)부터 탐색 시작.
		count = 0

		while ctrl != None:
			nextctrl = ctrl.Next
			if ctrl.CtrlID == "gso":
				# print(ctrl.CtrlID,count )
				count += 1
				if input_no == count:
					# self.han_program.SetPosBySet(ctrl.GetAnchorPos(0))
					# self.han_program.FindCtrl()
					self.han_program.DeleteCtrl(ctrl)
					break
			ctrl = nextctrl

	def delete_table_by_no(self, input_no):
		"""
		삭제 : 테이블 번호로 삭제

		:param input_no: 숫자(정수)
		:return:
		"""
		ctrl = self.han_program.HeadCtrl  # 첫번째 컨트롤(HaedCtrl)부터 탐색 시작.
		count = 0

		while ctrl != None:
			nextctrl = ctrl.Next
			if ctrl.CtrlID == "tbl":
				# print(ctrl.CtrlID,count )
				count += 1
				if input_no == count:
					# self.han_program.SetPosBySet(ctrl.GetAnchorPos(0))
					# self.han_program.FindCtrl()
					self.han_program.DeleteCtrl(ctrl)
					break
			ctrl = nextctrl

	def delete_word_at_cursor(self):
		"""
		삭제 : 커서가 있는 단어1개 삭제하는데, 만약 영역이 선택되었다면, 제일 왼쪽의 단어가 삭제된다

		:return:
		"""
		self.han_program.HAction.Run("DeleteWord")

	def delete_word_by_no(self, input_no):
		"""
		삭제 : 전체문장에서 n번째 단어를 삭제하는 것입니다

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_word_from_begin_of_doc(input_no - 1)
		self.han_program.HAction.Run("Delete")

	def delete_xline_in_table(self, table_no, x):
		"""
		삭제 : 현재 문서의 n번째 테이블의 x번째 가로줄 하나를 삭제

		:param table_no: 테이블 번호
		:param x:
		:return:
		"""
		self.select_table_obj_by_no(table_no)
		for no in range(x - 1):
			self.han_program.Run("TableLowerCell")
		self.han_program.CreateAction("DeleteLine")

	def delete_yline_in_table(self, table_no, y):
		"""
		삭제 : 현재 문서의 n번째 테이블의 y번째 세로줄 하나를 삭제

		:param table_no: 테이블 번호
		:param y:
		:return:
		"""
		self.select_table_obj_by_no(table_no)
		self.han_program.Run("ShapeObjTableSelCell")
		for no in range(y - 1):
			self.han_program.Run("TableRightCell")
		self.han_program.CreateAction("SelectColumn")
		self.han_program.CreateAction("Delete")

	def doc_info(self):
		"""
		문서의 정보

		:return:
		"""
		self.han_program.HAction.GetDefault("DocumentInfo", self.han_program.HParameterSet.HDocumentInfo.HSet)
		self.han_program.HParameterSet.HDocumentInfo.HSet("DetailInfo", 1)
		self.han_program.HAction.Execute("DocumentInfo", self.han_program.HParameterSet.HDocumentInfo.HSet)
		#print(self.han_program.HParameterSet.HDocumentInfo.DetailCharCount)
		result = self.han_program.HParameterSet.HDocumentInfo.Item("DetailCharCount")
		return result

	def draw_outline_for_selection(self):
		"""
		선택영역의 테두리 그리기

		:return:
		"""
		self.han_program.CreateAction("CharShapeOutline")

	def filter_all_action_name_by_input_text(self, input_text):
		"""
		모든 액션 리스트중 입력값과 같은 이름이 들어간것을 갖고오는것

		:return:
		"""
		result = []
		for one_action_name in list(self.varx['action_name_vs_manual'].keys()):
			if str(input_text).lower() in str(one_action_name).lower():
				result.append(one_action_name)
		return result

	def free_basic_font_style(self):
		"""
		기본 font로 저장된 자료들을 초기화하는 것이다

		:return:
		"""
		self.varx["apply_basic_font"] = False
		self.varx["basic_underline"] = False
		self.varx["basic_size"] = False
		self.varx["basic_bold"] = False
		self.varx["rgb_int"] = False

	def get_all_action_name(self):
		"""
		모든 액션의 리스트를 갖고옵니다
		아래아한글은 action이라는 형태로 메소드의 기능을 할당하는데, 어떤 메소드들이 가능한지를 갖고오는 것입니다

		:return:
		"""
		result = list(self.varx['action_name_vs_manual'].keys())
		return result

	def get_all_document_information(self):
		"""
		기본 문서의 정보를 돌려줍니다

		:return:
		"""
		action = self.han_program.CreateAction("DocumentInfo")
		para_set = action.CreateSet()
		action.GetDefault(para_set)
		para_set.SetItem("SectionInfo", 1)
		result = action.Execute(para_set)
		return result

	def get_all_information_for_current_cursor(self):
		"""
		커서의 모든 정보를 알아 보은 것

		:return:
		"""
		lpp = self.han_program.GetPosBySet()
		result = {}
		result["para_no"] = lpp["Para"] + 1
		result["line_no"] = self.get_current_line_no()
		result["char_no"] = lpp["Pos"]

		return result

	def get_all_parameter_data_for_action_name(self, input_action_name):
		"""
		모든 액션의 리스트를 갖고옵니다

		:param input_action_name:
		:return:
		"""
		result = {}
		result["action_name"] = input_action_name
		result["parameter_name"] = self.get_parameter_name_for_action_name(input_action_name)
		result["parameter_items"] = None
		result["parameter_option"] = {}
		if result["parameter_name"]:
			result["parameter_items"] = self.get_all_parameter_item_by_parameter_name(result["parameter_name"])
			if result["parameter_items"]:
				for one_item in result["parameter_items"]:
					result["parameter_option"][one_item] = {}
					result["parameter_option"][one_item] = self.get_parameter_option_for_paramater_item(one_item)

		return result

	def get_all_parameter_item_by_parameter_name(self, input_parameter_set_id):
		"""
		parameter_name : 각 action에 연결된 parameter의 번호, parameter id와 같은 개념
		parameter_item_set : all parameter element, parameter id의 모든 파라미타 들
		parameter_item_option_set : 한개의 parameter_item 의 option 사항들

		:param input_parameter_set_id:
		:return:
		"""
		result = None

		try:
			result = self.varx["parameter_set_id_vs_parameters"][input_parameter_set_id]
		except:
			pass
		return result

	def get_char_no_at_cursor(self):
		"""
		커서위치를 문단과 문단에서의 위치로 나타낸다
		GetPos : 문단의 번호 + 문단의 시작에서 몇번째 위치

		:return:
		"""
		result = self.han_program.KeyIndicator()[6]
		return result

	def get_char_no_for_end_of_selection(self):
		"""
		선택영역의 오른쪽 끝의 글자번호

		:return:
		"""
		no1 = self.get_char_no_at_cursor()
		no2 = self.count_char_for_selection()
		return no1 + no2 - 1

	def get_char_no_for_start_of_selection(self):
		"""
		선택영역의 시작 글자가 전체 문서에서 몇번째 글자인지를 알아내는 것

		:return:
		"""
		result = self.get_char_no_at_cursor()
		return result

	def get_current_line_no(self):
		"""
		현재 커서가 위치한곳의 줄번호

		:return:
		"""
		result = self.han_program.KeyIndicator()[5]  # 줄
		return result

	def get_current_page_no(self):
		"""
		현재 커서가 위치한곳의 페이지번호

		:return:
		"""
		result = self.han_program.Item(0).XHwpDocumentInfo.CurrentPage
		return result

	def get_current_pos(self):
		"""
		list : 캐럿이 위치한 문서내 리스트 ID
		para : 캐럿이 위치한 문단 번호
		pso : 캐럿이 위치한 문단내 글자위치

		:return:
		"""
		result = self.han_program.Getpos()
		return result

	def get_current_xy_in_table(self):
		"""
		테이블안의 어느곳에있는 커서의 xy번호를 알아내는 것

		:return:
		"""
		# aaa = self.han_program.KeyIndicator()
		# cell_a1 = aaa.Split('(', ')')[1]

		if not self.han_program.CellShape:  # 표 안에 있을 때만 CellShape 오브젝트를 리턴함
			raise AttributeError("현재 캐럿이 표 안에 있지 않습니다.")
		return self.han_program.KeyIndicator()[-1][1:].split(")")[0]

	def get_docsummaryinfo_as_dic(self):
		"""
		문서 전체의 정보를 갖고온다

		:return:
		"""
		result = self.check_action_name_as_dic("DocSummaryInfo")
		return result

	def get_documentinfo_as_dic(self):
		"""
		문서 전체의 정보를 갖고온다

		:return:
		"""
		result = self.check_action_name_as_dic("DocumentInfo")
		return result

	def get_end_char_no_of_selection(self):
		"""
		현재 선택한 영역에서 오른쪽 끝의 글자의 번호를 돌려준다

		:return:
		"""
		no1 = self.get_char_no_at_cursor()
		no2 = self.count_char_for_selection()
		return no1 + no2 - 1

	def get_information_for_current_cursor(self):
		"""
		커서의 모든 정보를 알아 보은 것

		:return:
		"""
		lpp = self.han_program.GetPosBySet()
		result = {}
		result["para_no"] = lpp["Para"] + 1
		result["line_no"] = self.get_line_no_at_cursor()
		result["char_no"] = lpp["Pos"]

		return result

	def get_information_for_doc(self):
		"""
		기본 문서의 정보

		:return:
		"""
		action_obj = self.han_program.CreateAction("DocumentInfo")
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)
		parameter_set_obj.SetItem("SectionInfo", 1)
		result = action_obj.Execute(parameter_set_obj)
		return result

	def get_information_for_selection(self):
		"""
		GetSelectedPos함수의 결과값

		slist : 설정된 블록의 시작 리스트 아이디.
		spara : 설정된 블록의 시작 문단 아이디.
		spos : 설정된 블록의 문단 내 시작 글자 단위 위치.
		elist : 설정된 블록의 끝 리스트 아이디.
		epara : 설정된 블록의 끝 문단 아이디.
		epos : 설정된 블록의 문단 내 끝 글자 단위 위치.

		bcbc => [block_start, char_start,block_end, char_end]

		:return:
		"""
		result = {"ok_or_no": "", "sel_list_start_no": "", "sel_para_start_no": "", "sel_char_start_no": "", "sel_list_end_no": "", "sel_para_end_no": "", "sel_char_end_no": ""}

		[result["ok_or_no"], result["sel_list_start_no"], result["sel_para_start_no"], result["sel_char_start_no"],
		 result["sel_list_end_no"], result["sel_para_end_no"], result["sel_char_end_no"]] = self.han_program.GetSelectedPos()
		aaa = self.get_information_for_statusbar()
		result.update(aaa)

		return result

	def get_information_for_statusbar(self):
		"""
		statusbar에 나타나는 정보들
		기본적으로 information은 dic형식의 결과로 돌려준다

		:return:
		"""
		result = {"ok_or_no": "", "section_no_total": "총구역", "section_no": "현재구역", "page_no": "쪽",
				  "col_no": "단", "line_no": "줄", "char_no": "칸", "over": "", "ctrl_name": "컨트롤이름"}

		[result["ok_or_no"], result["section_no_total"], result["section_no"], result["page_no"], result["col_no"], result["line_no"],
		 result["char_no"], result["over"], result["ctrl_name"]] = self.han_program.KeyIndicator()
		return result

	def get_information_for_statusbar_old(self):
		"""
		statusbar에 나타나는 정보들

		:return:
		"""
		parameter_set_obj = self.han_program.KeyIndicator()
		result = {}
		result["성공/실패"] = parameter_set_obj[0]
		result["총구역"] = parameter_set_obj[1]
		result["현재구역"] = parameter_set_obj[2]
		result["쪽"] = parameter_set_obj[3]
		result["단"] = parameter_set_obj[4]
		result["줄"] = parameter_set_obj[5]
		result["칸"] = parameter_set_obj[6]  # 한글은 1글자가 2칸을 차지한다
		result["삽입/겹침"] = parameter_set_obj[7]
		result["컨트롤 종류"] = parameter_set_obj[8]
		return result

	def get_line_no_at_cursor(self):
		"""
		커서의 줄번호
		마지막의 커서위치이다

		:return:
		"""
		result = self.han_program.KeyIndicator()[5]  # 줄
		return result

	def get_line_no_for_start_of_selection(self):
		"""
		선택영역의 첫번째 줄이 전체 문서에서 몇번째 줄번호 인지를 확인하는 것
		잘못됨, 다시 확인해야 함

		:return:
		"""
		result = self.get_line_no_at_cursor()
		return result

	def get_page_no_at_cursor(self):
		"""
		현재커서의 페이지 번호

		:return:
		"""
		result = self.han_program.Item(0).XHwpDocumentInfo.CurrentPage
		return result

	def get_page_no_for_start_of_selection(self):
		"""
		선택영역의 시작 페이지 번호

		:return:
		"""
		result = self.get_page_no_at_cursor()
		return result

	def get_para_no_at_cursor(self):
		"""
		현재커서의 문단 번호

		:return:
		"""
		result = self.han_program.GetPos()[1]
		# result = self.han_program.KeyIndicator()[4]  # 단
		return result

	def get_parameter_name_for_action_name(self, input_action):
		"""
		액션이름이 들어오면 parameter_set_id를 돌려주는 것
		all_data = basic_data_for_han.basic_data().xvar

		:param input_action:action 이름
		:return:
		"""
		result = None
		try:
			result = self.varx['action_name_vs_parameter_set_id'][input_action]
		except:
			pass
		return result

	def get_parameter_option_for_paramater_item(self, input_parameter):
		"""
		입력변수는 option들이 있는데, 어떤 옵션이 있는지 확인해 주는 것입니다

		:param input_parameter:
		:return:
		"""
		result = None

		try:
			result = self.varx["parameter_vs_parameter_option"][input_parameter]
		except:
			pass
		return result

	def get_parameters_for_parameter_set_id(self, input_parameter_set_id):
		"""
		parameter_set_id에대한 parameter를 알아내는 것

		:param input_parameter_set_id:
		:return:
		"""
		result = None
		try:
			result = self.varx['parameter_set_id_vs_parameters'][input_parameter_set_id]
		except:
			pass
		return result

	def get_pos_at_cursor(self):
		"""
		현재 커서의 아래 정보를 알아내는 것
		list : 캐럿이 위치한 문서내 리스트 ID
		para : 캐럿이 위치한 문단 번호
		pso : 캐럿이 위치한 문단내 글자위치

		:return:
		"""
		result = self.han_program.GetPos()
		return result

	def get_pos_for_selection(self):
		"""
		API로 갖고오는 정보
		:return:

		slist : 시작 리스트 번호
		spara : 시작 문단 번호
		spos : 문단내의 시작 글자 단위 위치
		elist : 끝 작리스트 번호
		epara : 끝  문단 번호
		epos : 문단내의 끝 글자 단위 위치

		:return:
		"""
		_, slist, spara, spos, elist, epara, epos = self.han_program.GetSelectedPos()
		return slist, spara, spos, elist, epara, epos

	def get_shape_obj_by_no(self, input_no):
		"""
		그리기 개개체를 번호로 선택하기

		:param input_no: 숫자(정수)
		:return:
		"""
		ctrl = self.han_program.HeadCtrl  # 첫번째 컨트롤(HaedCtrl)부터 탐색 시작.
		count = 0
		result = False

		while ctrl != None:
			nextctrl = ctrl.Next
			if ctrl.CtrlID == "gso":
				count += 1
				if input_no == count:
					self.han_program.SetPosBySet(ctrl.GetAnchorPos(0))
					self.han_program.FindCtrl()
					break
			ctrl = nextctrl
		return result

	def get_start_char_no_of_selection(self):
		"""
		선택영역의 시작 글자의 번호

		:return:
		"""
		result = self.get_char_no_at_cursor()
		return result

	def get_start_line_no_of_selection(self):
		"""
		선택영역의 첫번째 줄이 전체 문서에서 몇번째 줄번호 인지를 확인하는 것

		:return:
		"""
		result = self.get_line_no_at_cursor()
		return result

	def get_start_page_no_of_selection(self):
		"""
		선택영역의 시작 페이지 번호

		:return:
		"""
		result = self.get_page_no_at_cursor()
		return result

	def insert_left_line_at_end_of_table(self):
		"""
		테이블의 맨 왼쪽에 새로운 한줄 삽입

		:return:
		"""
		self.han_program.CreateAction("TableInsertLeftColumn")

	def insert_lower_line_at_end_of_table(self):
		"""
		테이블의 맨 아레쪽에 새로운 한줄 삽입

		:return:
		"""
		self.han_program.CreateAction("TableInsertLowerRow")

	def insert_multi_xline_in_table(self, input_no):
		"""
		테이블의 아래쪽에 새로운 n개의 여러줄 삽입

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.CreateAction("TableInsertLowerRow")

	def insert_new_line(self, repeat_no=1):
		"""
		현재 커서가있는 위치에 새로운 라인을 삽입

		:param repeat_no: 반복횟수
		:return:
		"""
		for one in range(repeat_no):
			self.han_program.Run("BreakLine")

	def insert_new_page(self):
		"""
		새로운 페이지를 삽입

		:return:
		"""
		self.han_program.Run("BreakPage")

	def insert_new_para(self):
		"""
		새로운 문서를 삽입

		:return:
		"""
		self.han_program.Run("BreakPara")

	def insert_new_section(self):
		"""
		새로운 문단을 삽입

		:return:
		"""
		self.han_program.Run("BreakSection")

	def insert_next_line_at_cusor(self, input_no=1):
		"""
		입력한 숫자만큼 다음줄을 만든다

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(int(input_no)):
			self.han_program.HAction.Run("BreakPara")  # 줄바꾸기

	def insert_right_line_at_end_of_table(self):
		"""
		테이블의 오른쪽끝에 새로운 한줄 삽입

		:return:
		"""
		self.han_program.CreateAction("TableInsertRightColumn")

	def insert_table_x_line_at_cusor(self):
		"""
		테이블의 아래쪽에 가로 한줄 삽입

		:return:
		"""
		self.han_program.HAction.Run("TableInsertLowerRow")  # 줄추가

	def insert_upper_line_at_end_of_table(self):
		"""
		테이블의 위쪽에 한줄 삽입

		:return:
		"""
		self.han_program.CreateAction("TableInsertUpperRow")

	def is_empty(self):
		"""
		빈 화일인지 확인하는 것

		:return:
		"""
		return self.han_program.IsEmpty

	def is_modified(self) -> bool:
		"""

		:return:
		"""
		return self.han_program.IsModified

	def is_selection(self):
		"""
		선택한 영역인지 확인하는 것

		:return:
		"""
		result = self.han_program.SelectionMode
		return result

	def make_table(self, x, y):
		"""
		현재 커서에 새로운 x,y개의 테이블을 만드는 것

		:param x:
		:param y:
		:return:
		"""
		# self.han_program.HParameterSet.HTableCreation.HSet = {}
		self.han_program.HAction.GetDefault("TableCreate", self.han_program.HParameterSet.HTableCreation.HSet)
		self.han_program.HParameterSet.HTableCreation.Rows = x
		self.han_program.HParameterSet.HTableCreation.Cols = y
		# self.han_program.HParameterSet.HTableCreation.WidthType = 2
		# self.han_program.HParameterSet.HTableCreation.HeightType = 1
		self.han_program.HParameterSet.HTableCreation.WidthValue = self.han_program.MiliToHwpUnit(148.0)
		self.han_program.HParameterSet.HTableCreation.HeightValue = self.han_program.MiliToHwpUnit(150)
		# self.han_program.HParameterSet.HTableCreation.CreateItemArray("ColWidth", x)
		# self.han_program.HParameterSet.HTableCreation.CreateItemArray("RowHeight", y)
		self.han_program.HParameterSet.HTableCreation.TableProperties.TreatAsChar = 1  # 글자처럼 취급
		# self.han_program.HParameterSet.HTableCreation.TableProperties.Width = self.han_program.MiliToHwpUnit(148)
		self.han_program.InsertCtrl("tbl", self.han_program.HParameterSet.HTableCreation.HSet)

	def make_table_old(self, x, y):
		"""

		:param x:
		:param y:
		:return:
		"""
		parameter_set_obj = self.han_program.CreateSet("Table")
		parameter_set_obj.SetItem("Rows", x)
		parameter_set_obj.SetItem("Cols", y)
		result = self.han_program.InsertCtrl("tbl", parameter_set_obj)
		return result


	def move_1(self, a, b, c):
		"""

		:param a:
		:param b:
		:param c:
		:return:
		"""
		self.han_program.MovePos(2, 0, 0)
		self.han_program.MovePos(a, b, c)

	def move_begin_cell_of_table(self):
		"""
		테이블의 처음으로 커서 옮기기

		:return:
		"""
		self.han_program.HAction.Run("ShapeObjTableSelCell")

	def move_begin_of_xline_for_table(self):
		"""
		테이블의 가로줄의 처음르로 커서 옮기기

		:return:
		"""
		self.han_program.HAction.Run("TableRowBegin")

	def move_begin_of_yline_for_table(self):
		"""
		테이블의 세로줄의 처음르로 커서 옮기기

		:return:
		"""
		self.han_program.HAction.Run("TableColBegin")

	def move_cell_to_begin_of_xline_at_table(self):
		"""
		테이블의 가로줄의 처음르로 커서 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=104)

	def move_cell_to_begin_of_yline_at_table(self):
		"""
		테이블의 세로줄의 처음르로 커서 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=106)

	def move_cell_to_end_of_xline_at_table(self):
		"""
		테이블의 오른쪽으로 끝칸으로 커서 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=105)

	def move_cell_to_end_of_yline_at_table(self):
		"""
		테이블의 아래쪽으로 끝칸으로 커서 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=107)

	def move_cell_to_one_down_at_table(self):
		"""
		테이블의 아래로 한칸 커서 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=103)

	def move_cell_to_one_left_at_table(self):
		"""
		테이블의 왼쪽으로 한칸 커서 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=100)

	def move_cell_to_one_right_at_table(self):
		"""
		테이블의 오른쪽으로 한칸 커서 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=101)

	def move_cell_to_one_up_at_table(self):
		"""
		테이블의 한칸위로 커서 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=102)

	def move_cursor_by_filed_name(self, filed_name):
		"""
		필드이름으로 커서를 옮기기

		:param filed_name: 필드이름
		:return:
		"""
		self.han_program.MoveToField(filed_name, True, True, True)

	def move_cursor_nth_char_from_current_para(self, input_no):
		"""
		현재 문단의 n번째 글자로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		return self.han_program.MovePos(pos=input_no)

	def move_cursor_to_begin_of_current_line(self):
		"""
		현재라인의 시작으로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=22)

	def move_cursor_to_begin_of_current_para(self):
		"""
		현재 문단의 시작으로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=6)

	def move_cursor_to_begin_of_current_word(self):
		"""
		현재 단어의 시작으로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=8)

	def move_cursor_to_begin_of_doc(self):
		"""
		현재 문서의 시작으로 커서를 옮기기

		:return:
		"""
		self.han_program.MovePos(2)

	def move_cursor_to_begin_of_line_no(self, input_no):
		"""
		줄번호의 위치로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		self.move_cursor_to_nth_line_from_selection(input_no)

	def move_cursor_to_begin_of_next_para(self):
		"""
		커서이동 : 다음 문잔의 시작으로

		:return:
		"""
		self.han_program.MovePos(moveID=10)

	def move_cursor_to_begin_of_selection(self):
		"""
		선택영역의 시작 위치로 커서를 옮기기

		:return:
		"""
		self.han_program.HAction.Run("MoveListBegin")

	def move_cursor_to_end_of_current_line(self):
		"""
		현재 줄의 끝위치로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=23)

	def move_cursor_to_end_of_current_para(self):
		"""
		현재 문단의 끝위치로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=7)

	def move_cursor_to_end_of_current_word(self):
		"""
		현재 단어의 끝으로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=9)

	def move_cursor_to_end_of_doc(self):
		"""
		현재 문서의 끝위치로 커서를 옮기기

		:return:
		"""
		self.han_program.MovePos(moveID=3)

	def move_cursor_to_end_of_previous_para(self):
		"""
		전 문단의 끝으로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=11)

	def move_cursor_to_end_of_range(self):
		"""
		영역의 끝으로 커서를 이동

		:return:
		"""
		self.han_program.HAction.Run("MoveListEnd")

	def move_cursor_to_end_of_selection(self):
		"""
		선택영역의 끝 위치로 커서를 옮기기

		:return:
		"""
		self.han_program.HAction.Run("MoveListEnd")

	def move_cursor_to_left_cell_of_table(self):
		"""
		테이블의 한칸 왼쪽셀로 커서를 옮기기

		:return:
		"""
		self.han_program.HAction.Run("TableLeftCell")

	def move_cursor_to_next_char(self):
		"""
		한 글자뒤로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=12)

	def move_cursor_to_next_char_from_selection(self):
		"""
		선택영역에서 한글자 뒤로 커서를 옮기기

		:return:
		"""
		self.han_program.HAction.Run("MoveNextChar")

	def move_cursor_to_next_line(self):
		"""
		선택영역에서 한줄 뒤로 커서를 옮기기

		이것은 오류가 남
		self.han_program.HAction.Run("moveNextLine")
		"""
		self.han_program.HAction.Run("MoveLineDown")

	def move_cursor_to_next_line_from_selection(self):
		"""
		선택영역에서 다음 단어로 커서를 옮기기

		:return:
		"""
		self.han_program.HAction.Run("MoveLineDown")

	def move_cursor_to_next_para_from_selection(self):
		"""
		선택영역에서 n번째 문단 뒤로 커서를 옮기기

		:return:
		"""
		self.han_program.MovePos(10)

	def move_cursor_to_next_shape_obj(self):
		"""
		다음 그리기객체로 커서이동

		:return:
		"""
		return self.han_program.HAction.Run("ShapeObjNextObject")

	def move_cursor_to_next_word(self):
		"""
		커서이동 : 다음단어로

		:return:
		"""
		self.han_program.HAction.Run("MoveNextWord")

	def move_cursor_to_next_word_from_selection(self):
		"""
		선택영역에서 다음 단어로 커서를 옮기기

		:return:
		"""
		self.han_program.HAction.Run("MoveNextWord")

	def move_cursor_to_nth_char(self, input_no=1):
		"""
		커서이동 : 현재에서 n번째 이후 문자로 이동

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.HAction.Run("MoveNextChar")

	def move_cursor_to_nth_char_from_begin_of_doc(self, input_no):
		"""
		문서의 n번째 글자로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		self.move_cursor_to_nth_char_from_selection(input_no)

	def move_cursor_to_nth_char_from_begin_of_doc_1(self, input_no):
		"""
		문서의 n번째 글자로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		for no in range(input_no):
			self.han_program.HAction.Run("MoveNextChar")

	def move_cursor_to_nth_char_from_current_para(self, input_no):
		"""
		현재 문단의 n번째 글자로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		return self.han_program.MovePos(pos=input_no)

	def move_cursor_to_nth_char_from_selection(self, input_no):
		"""
		선택영역에서 n번째 글자 뒤로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		if input_no > 0:
			for no in range(input_no):
				self.han_program.HAction.Run("MoveNextChar")
		else:
			for no in range(input_no):
				self.han_program.HAction.Run("MoveNextChar")

	def move_cursor_to_nth_line(self, input_no=1):
		"""

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.HAction.Run("MoveLineDown")

	def move_cursor_to_nth_line_from_begin_of_doc(self, input_no):
		"""
		문서의 n번째 줄로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		for no in range(input_no - 1):
			self.han_program.HAction.Run("MoveLineDown")

	def move_cursor_to_nth_line_from_selection(self, input_no):
		"""
		선택영역에서 n번째 줄뒤로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		if input_no > 0:
			for no in range(input_no + 1):
				self.han_program.HAction.Run("MoveNextLine")
		else:
			for no in range(input_no + 1):
				self.han_program.HAction.Run("MovePrevLine")

	def move_cursor_to_nth_next_char(self, input_no=1):
		"""
		현재 커서를 n번째 문자뒤로 이동한다

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char(input_no)

	def move_cursor_to_nth_next_line(self, input_no=1):
		"""
		현재 커서를 n번째 라인뒤로 이동한다

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_line(input_no)

	def move_cursor_to_nth_next_para(self, input_no=1):
		"""
		현재 커서를 n번째 문단뒤로 이동한다

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_para(input_no)

	def move_cursor_to_nth_next_para_1(self, input_no):
		"""
		n번째 문단으로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		return self.han_program.MovePos(Para=input_no)

	def move_cursor_to_nth_next_word(self, input_no=1):
		"""

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_word(input_no)

	def move_cursor_to_nth_para(self, input_no=1):
		"""

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.MovePos(10)

	def move_cursor_to_nth_para_from_begin_of_doc(self, input_no):
		"""

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		for no in range(input_no):
			self.han_program.MovePos(10)

	def move_cursor_to_nth_para_from_selection(self, input_no):
		"""
		선택영역에서 n번째 문단 뒤로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		position_obj = self.han_program.GetPos()
		self.han_program.SetPos(position_obj.list, position_obj.para + input_no, position_obj.pos)

	def move_cursor_to_nth_word(self, input_no=1):
		"""

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.HAction.Run("MoveNextWord")

	def move_cursor_to_nth_word_from_begin_of_doc(self, input_no):
		"""

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		for no in range(input_no):
			self.han_program.HAction.Run("MoveNextWord")

	def move_cursor_to_nth_word_from_selection(self, input_no):
		"""
		선택영역에서 n번째 단어 뒤로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.HAction.Run("MoveNextWord")

	def move_cursor_to_nth_word_from_selection_old(self, input_no):
		"""

		:param input_no: 숫자(정수)
		:return:
		"""
		if input_no > 0:
			for no in range(input_no):
				self.han_program.HAction.Run("MoveNextWord")
		else:
			for no in range(input_no):
				self.han_program.HAction.Run("MoveNextWord")

	def move_cursor_to_para_by_no(self, input_no):
		"""
		n번째 문단으로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		return self.han_program.MovePos(Para=input_no)

	def move_cursor_to_previous_char(self):
		"""
		바로전 글자로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=13)

	def move_cursor_to_previous_line(self):
		"""
		바로전 줄로 커서를 옮기기

		:return:
		"""
		return self.han_program.MovePos(moveID=21)

	def move_cursor_to_previous_nth_char_from_selection(self, input_no):
		"""
		선택영역에서 n번째전 글자로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.MovePos(moveID=13)

	def move_cursor_to_previous_nth_line_from_selection(self, input_no):
		"""
		선택영역에서 n번째전 줄로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.MovePos(moveID=21)

	def move_cursor_to_previous_nth_para_from_selection(self, input_no):
		"""
		선택영역에서 n번째전 문단으로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		if input_no > 0:
			for no in range(input_no):
				self.han_program.HAction.Run("MoveUp")
		else:
			for no in range(input_no):
				self.han_program.HAction.Run("MoveUp")

	def move_cursor_to_previous_nth_word_from_selection(self, input_no):
		"""
		선택영역에서 n번째전 단어로 커서를 옮기기

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.HAction.Run("MovePrevWord")

	def move_cursor_to_previous_para(self):
		"""
		커서이동 : 앞 para로 이동

		:return:
		"""
		self.move_cursor_to_previous_nth_para_from_selection(1)

	def move_cursor_to_previous_word(self):
		"""
		커서이동 : 앞 단어로 이동

		:return:
		"""
		return self.han_program.HAction.Run("MovePrevWord")

	def move_cursor_to_start_of_next_para(self):
		"""
		다음 분단이 올때까지 이동

		:return:
		"""
		self.han_program.HAction.Run("MoveParaEnd")

	def move_cursor_to_start_of_range(self):
		"""
		커서이동 : range의 시작으로 이동

		:return:
		"""
		self.han_program.HAction.Run("MoveListBegin")

	def move_page(self, input_no):
		"""
		5페이지로 이동

		:param input_no: 숫자(정수)
		:return:
		"""
		target_page = input_no
		self.han_program.HAction.Run("MoveDocBegin")  # 문서 시작으로 이동
		for _ in range(target_page - 1):
			self.han_program.HAction.Run("MovePageDown")  # 문서 시작으로 이동
		self.han_program.InitScan(...)

	def move_to_previous_char_from_selection(self):
		"""
		현재 선택한 영역을 기준으로 앞쪽글자로 하나 이동한다
		보통, 한문자씩 이동하면서 어떤것을 확인할때 사용한다

		:return:
		"""
		self.han_program.HAction.Run("MoveSelPrevChar")

	def new_doc(self):
		"""
		새로운 문서 open

		:return:
		"""
		self.han_program.XHwpDocuments.Add(0)

	def new_tab(self):
		"""
		새로운 탭만들기

		:return:
		"""
		self.han_program.XHwpDocuments.Add(1)

	def new_table_at_cursor(self, x, y):
		"""
		새로운 테이블 만들기

		:param x:
		:param y:
		:return:
		"""
		self.han_program.HParameterSet.HTableCreation.Rows = x
		self.han_program.HParameterSet.HTableCreation.Cols = y
		self.han_program.HParameterSet.HTableCreation.WidthType = 2
		self.han_program.HParameterSet.HTableCreation.HeightType = 1
		self.han_program.HParameterSet.HTableCreation.WidthValue = self.han_program.MiliToHwpUnit(148.0)
		self.han_program.HParameterSet.HTableCreation.HeightValue = self.han_program.MiliToHwpUnit(150)
		self.han_program.HParameterSet.HTableCreation.TableProperties.Width = self.han_program.MiliToHwpUnit(148)
		self.han_program.HAction.Execute("TableCreate", self.han_program.HParameterSet.HTableCreation.HSet)

	def page_break(self):
		"""
		페이지 바꾸기

		:return:
		"""
		self.han_program.HAction.Run("BreakPage")  # 쪽나눔

	def paint_border_for_selection_with_pen(self):
		"""
		형광펜

		:return:
		"""
		self.select_current_line()
		action_obj = self.han_program.CreateAction("MarkPenShape")
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)
		parameter_set_obj.SetItem("Color", 65535)
		action_obj.Execute(parameter_set_obj)

	def paint_font_red_color_for_selection(self):
		"""
		선택영역을 빨간색으로 칠하기

		:return:
		"""
		self.han_program.HAction.Run("CharShapeTextColorRed")  # 선택한 텍스트의 색을 빨간색으로 만든다

	def paint_highlight_for_selection(self):
		"""
		형광펜

		:return:
		"""
		self.select_current_line()
		action_obj = self.han_program.CreateAction("MarkPenShape")
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)
		parameter_set_obj.SetItem("Color", 65535)
		action_obj.Execute(parameter_set_obj)

	def paint_table(self):
		"""
		테이블의 색을 칠하는 것

		:return:
		"""
		action_obj = self.han_program.CreateAction("CellFill")
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)
		fillattrSet = parameter_set_obj.CreateItemSet("FillAttr", "DrawFillAttr")

		fillattrSet.SetItem("Type", 1)
		fillattrSet.SetItem("WinBrushFaceStyle", 0xffffffff)
		fillattrSet.SetItem("WinBrushHatchColor", 0x00000000)
		fillattrSet.SetItem("WinBrushFaceColor", self.han_program.RGBColor(153, 153, 153))
		action_obj.Execute(parameter_set_obj)

	def quit(self):
		"""
		종료

		:return:
		"""
		return self.han_program.Quit()

	def read_all_text_for_one_page(self, input_page_no):
		"""
		한페이지의 모든 text를 갖고온다

		:param input_page_no: 페이지 번호
		:return:
		"""
		return self.han_program.GetPageText(pgno=input_page_no)

	def read_table_index_for_selection(self):
		"""
		선택된곳의 테이블의 index값을 갖고온다

		:return:
		"""
		result = None
		if self.selection.Information(12) == False:
			pass
		else:
			lngStart = self.selection.Range.Start
			lngEnd = self.selection.Range.End

			# get the numbers for the END of the selection range
			iSelectionRowEnd = self.selection.Information(14)
			iSelectionColumnEnd = self.selection.Information(17)

			# collapse the selection range
			self.selection.Collapse(Direction=1)

			# get the numbers for the END of the selection range
			# now of course the START of the previous selection
			iSelectionRowStart = self.selection.Information(14)
			iSelectionColumnStart = self.selection.Information(17)

			# RESELECT the same range
			self.selection.MoveEnd(Unit=1, Count=lngEnd - lngStart)

			tabnum = self.active_word_file.Range(0, self.selection.Tables(1).Range.End).Tables.Count

			# display the range of cells covered by the selection
			if self.selection.Cells.Count:
				#print(tabnum, self.selection.Cells.Count, iSelectionRowStart, iSelectionColumnStart, iSelectionRowEnd, iSelectionColumnEnd)
				result = tabnum
		return result

	def read_text_for_current_line(self):
		"""
		현재 커서가 있는 라인의 text를 갖고오는 것

		:return:
		"""
		self.select_current_line()
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_for_current_para(self):
		"""
		현재 커서가 있는 문단의 text를 갖고오는 것

		:return:
		"""
		self.move_cursor_to_begin_of_current_para()
		self.select_current_para()
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_for_current_word(self):
		"""
		현재 커서가 있는 단어의 text를 갖고오는 것

		:return:
		"""
		self.select_current_word()
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_all_text_for_doc(self):
		"""
		문서의 모든 text를 갖고오는 것

		:return:
		"""
		self.select_all()
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_for_nth_char_from_start_of_doc(self, input_no):
		"""
		문서처음에서 n번째 글자를 갖고오는 것

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_char_from_begin_of_doc(input_no)
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_for_nth_line_from_start_of_doc(self, input_no):
		"""
		문서처음에서 n번째 라인의 text갖고오기

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_line_from_begin_of_doc(input_no)
		self.select_current_line()
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_for_nth_para_from_start_of_doc(self, input_no):
		"""
		문서처음에서 n번째 문단의 text갖고오기

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		self.select_nth_para_from_begin_of_doc(input_no)
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_for_nth_word_from_start_of_doc(self, input_no):
		"""
		문서처음에서 n번째 단어의 text갖고오기

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_word_from_begin_of_doc(input_no)
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_for_para_no(self, input_no):
		"""
		문단번호로 text갖고오기

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		self.select_nth_para_from_begin_of_doc(input_no)
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_from_index1_to_index2(self, input_no1, input_no2):
		"""
		문서처음을 0으로해서, 글자번호 두개사이의 text갖고오기

		:param input_no1: 숫자(정수)
		:param input_no2: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char_from_begin_of_doc(input_no1)
		self.select_nth_char_from_selection(input_no2)
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_for_selection(self):
		"""
		선택영역의 text갖고오기

		:return:
		"""
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_text_in_table_by_xy(self, table_obj, x, y):
		"""
		테이블의 위치로 셀의 text갖고오기

		:param table_obj:
		:param x:
		:param y:
		:return:
		"""
		table_obj.Run("ShapeObjTableSelCell")

		for no in range(y - 1):
			table_obj.Run("TableRightCell")

		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def read_value_for_selection(self):
		"""
		선택영역의 text갖고오기

		:return:
		"""
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def rgb_color(self, red, green, blue):
		"""
		rgb값

		:param red:
		:param green:
		:param blue:
		:return:
		"""
		return self.han_program.RGBColor(red=red, green=green, blue=blue)

	def save(self, file_name=""):
		"""
		저장

		:param file_name:
		:return:
		"""
		self.han_program.SaveAs(file_name)
		self.han_program.Quit()

	def search_action(self, input_action):
		"""
		모든 액션 번호에서 입력받은 단어가 포함된 액션을 찾는 것

		:param input_action:action 이름
		:return:
		"""
		action_name_list = self.check_action_name(input_action)
		for index, a_action in enumerate(action_name_list):
			parameter_set_id = self.get_parameter_name_for_action_name(a_action)
			if parameter_set_id == "없음":
				print(f"{a_action}의 Parameter들은 ==> ", "없음")
			else:
				parameters = self.get_parameters_for_parameter_set_id(parameter_set_id)
				print(f"{a_action}의 Parameter들은 ==> ", parameters)
				for a_parameter in parameters:
					print("                                 Parameter는 ==> ", a_parameter)
					option = self.get_parameter_option_for_paramater_item(a_parameter)
					print("                                             Parameter의 Option은 ==> ", option)

	def select_1st_line_of_selection(self):
		"""
		선택영역의 첫번째 라인을 선택

		:return:
		"""
		self.han_program.HAction.Run('MoveSelLineBegin')

	def select_1st_para_of_selection(self):
		"""
		선택영역의 첫번째 문단을 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelParaBegin")

	def select_1st_word_of_selection(self):
		"""
		선택영역의 첫번째 단어를 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelWordEnd")

	def select_all(self):
		"""
		문서의 모든 것을 선택

		:return:
		"""
		self.han_program.Run('SelectAll')

	def select_char_from_no1_to_no2_from_begin_of_doc(self, input_no1, input_no2):
		"""
		두 글자번호 사이를 선택

		:param input_no1: 숫자(정수)
		:param input_no2: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char_from_begin_of_doc(input_no1)
		self.select_nth_char_from_selection(input_no2 - input_no1)

	def select_current_char(self):
		"""
		현재 선택한것의 첫번째 글자나 공백을 선택한다

		:return:
		"""
		self.move_cursor_to_nth_char_from_selection(0)

	def select_current_line(self):
		"""
		커서가 있는 현재 라인을 선태

		:return:
		"""
		self.select_line_at_current()

	def select_current_para(self):
		"""
		커서가 있는 현재 문단을 선태

		:return:
		"""
		self.select_para_at_current()

	def select_current_word(self):
		"""
		커서가 있는 현재 단어를 선태

		:return:
		"""
		self.select_word_at_current()

	def select_end_of_line_from_selection(self):
		"""
		현재 선택영역에서 줄의 끝까지 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelLineEnd")

	def select_end_of_para_from_selection(self):
		"""
		현재 선택영역에서 문단의 끝까지 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelParaEnd")

	def select_first_cell_of_table(self, table_no):
		"""
		테이블의 처음 셀을 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_table_obj_by_no(table_no)
		self.han_program.Run("ShapeObjTableSelCell")

	def select_from_begin_of_doc_to_nth_char(self, input_no):
		"""
		문서의 시작에서부터 n번째 글짜까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_char_from_begin_of_doc(input_no)

	def select_from_begin_of_doc_to_nth_line(self, input_no):
		"""
		문서의 시작에서부터 n번째 줄까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.han_program.Run("Select")
		for no in range(input_no):
			self.han_program.HAction.Run("MoveNextLine")
		self.han_program.HAction.Run("MoveSelLineEnd")

	def select_from_begin_of_doc_to_nth_para(self, input_no):
		"""
		문서의 시작에서부터 n번째 문단까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_para_from_selection(input_no)

	def select_from_begin_of_doc_to_nth_word(self, input_no):
		"""
		문서의 시작에서부터 n번째 단어까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_word_from_begin_of_doc(input_no)

	def select_from_char_no1_to_no2_from_begin_of_doc(self, input_no1, input_no2):
		"""
		두 글자번호 사이를 선택

		:param input_no1: 숫자(정수)
		:param input_no2: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char_from_begin_of_doc(input_no1)
		self.select_nth_char_from_selection(input_no2 - input_no1)

	def select_from_cursor_to_nth_char(self, input_no):
		"""
		현재커서에서 n번째 글자까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_char_from_selection(input_no)

	def select_from_cursor_to_nth_word(self, input_no):
		"""
		현재커서에서 n번째 단어까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_word_from_selection(input_no - 1)

	def select_from_cursor_to_previous_nth_char(self, input_no):
		"""
		현재커서에서 n번째 앞의 글자까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		for one in range(input_no):
			self.move_cursor_to_previous_char()

	def select_from_cursor_to_previous_nth_word(self, input_no):
		"""
		현재커서에서 n번째 앞의 단어까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_previous_nth_word_from_selection(input_no)
		self.select_current_word()

	def select_from_line_no1_to_no2_from_selection(self, input_no1, input_no2):
		"""
		두 줄사이를 선택

		:param input_no1: 숫자(정수)
		:param input_no2: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_line_from_selection(input_no1)
		self.select_nth_line_from_selection(input_no2 - input_no1)

	def select_from_para_no1_to_no2_from_selection(self, input_no1, input_no2):
		"""
		두 문단사이를 선택

		:param input_no1: 숫자(정수)
		:param input_no2: 숫자(정수)
		:return:
		"""
		self.select_nth_para_from_selection(input_no2 - input_no1)

	def select_line_at_current(self):
		"""
		현재 줄을 선택
		# self.han_program.Run("Select")
		# self.han_program.HAction.Run("MoveLineEnd")

		:return:
		"""
		self.move_cursor_to_begin_of_current_line()
		self.han_program.HAction.Run("MoveSelLineEnd")

	def select_line_at_end_of_selection(self):
		"""
		현재 선택영역에서 줄의 끝까지 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelLineEnd")

	def select_line_by_no(self, input_no):
		"""
		줄번호로 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_line_from_begin_of_doc(input_no)
		self.select_current_line()

	def select_line_by_no_from_begin_of_doc(self, input_no):
		"""
		줄번호로 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_line_from_begin_of_doc(input_no - 1)
		self.select_current_line()

	def select_line_from_no1_to_no2_from_selection(self, input_no1, input_no2):
		"""
		두 줄사이를 선택

		:param input_no1:
		:param input_no2:
		:return:
		"""
		self.move_cursor_to_nth_line_from_selection(input_no1)
		self.select_nth_line_from_selection(input_no2 - input_no1)

	def select_line_of_begin_of_selection(self):
		"""
		선택영역의 첫번째 라인을 선택

		:return:
		"""
		self.han_program.HAction.Run('MoveSelLineBegin')

	def select_next_char_from_selection(self, input_no):
		"""
		선택영역에서 n번째 글짜를 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char_from_selection(1)

	def select_next_line_from_selection(self):
		"""
		선택영역에서 다음 줄을 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelNextLine")

	def select_next_para_from_selection(self):
		"""
		선택영역에서 n번째 문단을 선택

		:return:
		"""
		self.move_cursor_to_next_para_from_selection()
		self.select_current_para()

	def select_next_word_from_selection(self):
		"""
		선택영역에서 n번째 단어을 선택

		:return:
		"""
		self.select_nth_word_from_selection(1)

	def select_nth_char_from_begin_of_doc(self, input_no):
		"""
		문서의 시작에서부터 n번째 글짜까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_char_from_begin_of_doc(input_no)

	def select_nth_char_from_begin_of_doc_1(self, input_no):
		"""
		n번째 글자를 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char_from_begin_of_doc(input_no)

	def select_nth_char_from_selection(self, input_no):
		"""
		선택영역에서 n번째 글짜까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_char_from_selection(input_no)

	def select_nth_line_from_begin_of_doc(self, input_no):
		"""
		n번째 줄을 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_line_from_begin_of_doc(input_no)
		self.select_current_line()

	def select_nth_line_from_begin_of_doc_1(self, input_no):
		"""
		문서의 시작에서부터 n번째 줄까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.han_program.Run("Select")
		for no in range(input_no):
			self.han_program.HAction.Run("MoveNextLine")
		self.han_program.HAction.Run("MoveSelLineEnd")

	def select_nth_line_from_cursor(self, input_no):
		"""
		선택영역에서 n번째 줄까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		for one in range(input_no):
			self.han_program.HAction.Run("MoveNextLine")
		self.select_current_line()

	def select_nth_line_from_selection(self, input_no):
		"""
		선택영역에서 n번째 글짜까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		for no in range(input_no):
			self.han_program.HAction.Run("MoveSelNextLine")

	def select_nth_para_from_begin_of_doc(self, input_no):
		"""
		n번째 문단을 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_para_from_begin_of_doc(input_no - 1)
		self.select_current_para()

	def select_nth_para_from_begin_of_doc_1(self, input_no):
		"""
		문서의 시작에서부터 n번째 문단까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_para_from_selection(input_no)

	def select_nth_para_from_selection(self, input_no):
		"""
		선택영역에서 n번째 문단을 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.move_cursor_to_nth_para_from_selection(input_no)
		self.select_current_para()

	def select_nth_word_from_begin_of_doc(self, input_no):
		"""
		n번째 단어를 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_word_from_begin_of_doc(input_no)

	def select_nth_word_from_begin_of_doc_1(self, input_no):
		"""
		문서의 시작에서부터 n번째 단어까지 선택

		:param input_no: 숫자(정수)
		:return:
		"""
		self.select_nth_word_from_begin_of_doc(input_no)

	def select_nth_word_from_selection(self, input_no):
		"""
		선택영역에서 n번째 단어를 선택

		:return:
		"""
		for no in range(input_no):
			self.han_program.HAction.Run("MoveNextWord")
		self.han_program.HAction.Run("MoveSelNextWord")

	def select_para_at_current(self):
		"""
		현재 문단 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveParaBegin")
		self.han_program.Run("Select")
		self.han_program.HAction.Run("MoveParaEnd")

	def select_para_at_end_of_selection(self):
		"""
		현재 선택영역에서 문단의 끝까지 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelParaEnd")

	def select_para_from_no1_to_no2_from_selection(self, input_no1, input_no2):
		"""
		두 문단사이를 선택

		:param input_no1: 숫자(정수)
		:param input_no2: 숫자(정수)
		:return:
		"""
		self.select_nth_para_from_selection(input_no2 - input_no1)

	def select_para_of_begin_of_selection(self):
		"""
		선택영역의 첫번째 문단을 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelParaBegin")

	def select_previous_char_from_selection(self):
		"""
		선택영역에서 앞으로 n번째 글자를 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelPrevPos")

	def select_previous_line_from_selection(self):
		"""
		선택영역에서 앞 줄을 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelLineUp")

	def select_previous_nth_line_from_selection(self, input_no):
		"""
		선택영역에서 앞으로 n번째 줄을 선택
		
		:param input_no: 숫자(정수)
		:return: 
		"""
		for no in range(input_no):
			self.han_program.HAction.Run("MovePrevLine")

	def select_previous_nth_para_from_selection(self):
		"""
		선택영역에서 앞으로 n번째 문단을 선택

		:return:
		"""
		self.move_cursor_to_previous_nth_para_from_selection(1)
		self.select_current_para()

	def select_previous_nth_word_from_selection(self):
		"""
		선택영역에서 앞으로 n번째 단어를 선택

		:return:
		"""
		self.move_cursor_to_previous_nth_word_from_selection(1)
		self.select_current_word()

	def select_previous_para_from_selection(self):
		"""
		선택영역에서 앞 문단을 선택

		:return:
		"""
		self.han_program.HAction.Run("MovePrevPara")
		self.han_program.HAction.Run("MoveParaBegin")
		self.han_program.Run("Select")
		self.han_program.HAction.Run("MoveParaEnd")

	def select_previous_word_from_selection(self):
		"""
		선택영역에서 앞 단어를 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelPrevWord")

	def select_start(self):
		"""
		선택 시작

		:return:
		"""
		self.han_program.HAction.Run("Select")

	def select_start_of_list_from_selection(self):
		"""
		선택영역의 리스트의 시작 번호

		:return:
		"""
		self.han_program.HAction.Run('MoveSelListBegin')

	def select_table_obj_by_no(self, input_no):
		"""
		한글에서는 객체를 넘겨주는 부분이 아니고
		원하는 객체를 문서 젠체에서 사용가능한 선택을 하고, 다른곳에서 선택한것을 가지고 무엇인가 한다

		:param input_no: 숫자(정수)
		:return:
		"""
		ctrl = self.han_program.HeadCtrl  # 첫번째 컨트롤(HaedCtrl)부터 탐색 시작.
		count = 0
		while ctrl != None:
			nextctrl = ctrl.Next
			if ctrl.CtrlID == "tbl":
				count += 1
				if input_no == count:
					self.han_program.SetPosBySet(ctrl.GetAnchorPos(0))
					self.han_program.FindCtrl()  # 객체를 선택하는 것
					break
			ctrl = nextctrl

	def select_word_at_current(self):
		"""
		현재 단어 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveWordBegin")
		self.han_program.Run("Select")
		self.han_program.HAction.Run("MoveWordEnd")

	def select_word_from_no1_to_no2_from_begin_of_doc(self, input_no1, input_no2):
		"""
		두 글자번호 사이를 선택

		:param input_no1:
		:param input_no2:
		:return:
		"""
		self.move_cursor_to_nth_word_from_begin_of_doc(input_no1)
		self.select_nth_word_from_selection(input_no2 - input_no1)

	def select_word_of_begin_of_selection(self):
		"""
		선택영역의 첫번째 단어를 선택

		:return:
		"""
		self.han_program.HAction.Run("MoveSelWordEnd")

	def select_xline_in_table(self, table_no, x_no):
		"""
		선택한 테이블의 n번째 가로줄 선택

		:param table_no: 테이블 번호
		:param x_no:
		:return:
		"""
		self.select_table_obj_by_no(table_no)
		self.han_program.Run("ShapeObjTableSelCell")
		for no in range(x_no - 1):
			self.han_program.Run("TableLowerCell")
		self.han_program.CreateAction("SelectRow")

	def select_yline_in_table(self, table_no, y):
		"""
		선택한 테이블의 n번째 세로줄 선택

		:param table_no: 테이블 번호
		:param y:
		:return:
		"""
		self.select_table_obj_by_no(table_no)
		self.han_program.Run("ShapeObjTableSelCell")
		for no in range(y - 1):
			self.han_program.Run("TableRightCell")
		self.han_program.CreateAction("SelectColumn")

	def selection_value(self):
		"""
		선택영역의 텍스트

		:return:
		"""
		result = self.han_program.GetTextFile("TEXT", "saveblock")
		return result

	def set_alignment_left_for_current_para(self):
		"""
		왼쪽 정렬

		:return:
		"""
		self.han_program.HAction.Run("ParagraphShapeAlignLeft")

	def set_basic_font_style(self, **input_dic):
		"""

		:param input_dic:
		:return:
		"""
		colorx = xy_color.xy_color()
		self.varx["apply_basic_font"] = True

		if "size" in input_dic.keys():
			self.varx["basic_size"] = input_dic["size"]
		if "color" in input_dic.keys():
			self.varx["rgb_int"] = colorx.change_xcolor_to_rgbint(input_dic["color"])
		if "bold" in input_dic.keys():
			self.varx["basic_bold"] = True
		if "underline" in input_dic.keys():
			self.varx["basic_underline"] = True
		if "italic" in input_dic.keys():
			self.varx["basic_italic"] = True

	def set_cur_field_name(self, field_name):
		"""
		현재 캐럿이 있는 곳의 필드이름을 설정

		:param field_name:
		:return:
		"""
		return self.han_program.SetCurFieldName(Field=field_name)

	def set_font_bold_for_selection(self):
		"""
		진하게 적용

		:return:
		"""
		self.han_program.HAction.Run("CharShapeBold")

	def set_font_border_for_selection(self):
		"""
		테두리 그리기

		:return:
		"""
		self.han_program.CreateAction("CharShapeOutline")

	def set_font_center_for_selection(self):
		"""
		가운데 정렬

		:return:
		"""
		self.han_program.HAction.Run("ParagraphShapeAlignCenter")

	def set_font_color_as_red_for_selection(self):
		"""
		글자를 빨간색으로 색칠하기
		선택한 텍스트의 색을 빨간색으로 만든다

		:return:
		"""
		self.han_program.HAction.Run("CharShapeTextColorRed")

	def set_font_color_for_selection_by_rgb(self, input_rgb):
		"""
		선택영역 rgb값으로 색칠하기

		:param input_rgb: rgb값
		:return:
		"""
		rgb_value = self.han_program.RGBColor(red=input_rgb[0], green=input_rgb[1], blue=input_rgb[2])
		action_obj = self.han_program.CreateAction("CharShape")
		cs = action_obj.CreateSet()
		action_obj.GetDefault(cs)
		cs.SetItem("TextColor", rgb_value)
		action_obj.Execute(cs)

	def set_font_color_for_selection_by_xcolor(self, input_xcolor):
		"""
		선택영역 xcolor형식으로 색칠하기

		:param input_xcolor: xcolor형식의 색깔
		:return:
		"""
		colorx = xy_color.xy_color()
		input_rgb = colorx.change_xcolor_to_rgb(input_xcolor)
		self.set_font_color_for_selection_by_rgb(input_rgb)

	def set_font_left_for_selection(self):
		"""
		왼쪽 정렬

		:return:
		"""
		self.han_program.HAction.Run("ParagraphShapeAlignLeft")

	def set_font_right_for_selection(self):
		"""
		오른쪽 정렬

		:return:
		"""
		self.han_program.HAction.Run("ParagraphShapeAlignRight")

	def set_font_shadow_for_selection(self):
		"""
		그림자

		:return:
		"""
		self.han_program.HAction.Run("CharShapeShadow")

	def set_font_size_down_for_selection(self, input_step=1):
		"""
		폰트크기 n단계 줄이기

		:param input_step:
		:return:
		"""
		for no in range(input_step):
			self.han_program.HAction.Run("CharShapeHeightDecrease")

	def set_font_size_up_for_selection(self, input_step=1):
		"""
		폰트크기 n단계 키우기

		:param input_step:
		:return:
		"""
		for no in range(input_step):
			self.han_program.HAction.Run("CharShapeHeightIncrease")

	def set_font_strikethrough_for_selection(self):
		"""
		선택영역의 글자들에 대해서 취소선

		:return:
		"""
		self.han_program.CreateAction("CharShapeCenterline")

	def set_font_style_for_selection(self, my_range):
		"""
		선택영역의 글자들에 대해서 폰트 스타일을 설정하는것

		:param my_range:
		:return:
		"""
		if self.varx["basic_underline"]:
			my_range.Font.Underline = 1
		if self.varx["basic_size"]:
			my_range.Font.Size = self.varx["basic_size"]
		if self.varx["basic_bold"]:
			my_range.Font.Bold = 1
		if self.varx["rgb_int"]:
			my_range.Font.TextColor.RGB = self.varx["rgb_int"]

	def set_font_underline_for_selection(self):
		"""
		선택영역의 글자들에 대해서 밑줄적용

		:return:
		"""
		self.han_program.CreateAction("CharShapeUnderline")

	def set_pos_for_cursor(self, input_list, input_para, input_pos):
		"""
		현재 커서의 아래 정보를 설정하는 것
		list : 캐럿이 위치한 문서내 리스트 ID
		para : 캐럿이 위치한 문단 번호
		pso : 캐럿이 위치한 문단내 글자위치
		
		:param input_list: 
		:param input_para: 
		:param input_pos: 
		:return: 
		"""
		result = self.han_program.SetPos(input_list, input_para, input_pos)
		return result

	def set_table_cell_address(self, addr):
		"""
		셀번호를 a1형태로 돌려준다

		:param addr:
		:return:
		"""
		init_addr = self.han_program.KeyIndicator()[-1][1:].split(")")[0]  # 함수를 실행할 때의 주소를 기억.
		if not self.han_program.CellShape:  # 표 안에 있을 때만 CellShape 오브젝트를 리턴함
			raise AttributeError("현재 캐럿이 표 안에 있지 않습니다.")
		if addr == self.han_program.KeyIndicator()[-1][1:].split(")")[0]:  # 시작하자 마자 해당 주소라면
			return  # 바로 종료
		self.han_program.HAction.Run("CloseEx")  # 그렇지 않다면 표 밖으로 나가서
		self.han_program.FindCtrl()  # 표를 선택한 후
		self.han_program.HAction.Run("ShapeObjTableSelCell")  # 표의 첫 번째 셀로 이동함(A1으로 이동하는 확실한 방법 & 셀선택모드)
		while True:
			current_addr = self.han_program.KeyIndicator()[-1][1:].split(")")[0]  # 현재 주소를 기억해둠
			self.han_program.HAction.Run("TableRightCell")  # 우측으로 한 칸 이동(우측끝일 때는 아래 행 첫 번째 열로)
			if current_addr == self.han_program.KeyIndicator()[-1][1:].split(")")[0]:  # 이동했는데 주소가 바뀌지 않으면?(표 끝 도착)
				# == 한 바퀴 돌았는데도 목표 셀주소가 안 나타났다면?(== addr이 표 범위를 벗어난 경우일 것)
				self.set_table_cell_address(init_addr)  # 최초에 저장해둔 init_addr로 돌려놓고
				self.han_program.HAction.Run("Cancel")  # 선택모드 해제
				raise AttributeError("입력한 셀주소가 현재 표의 범위를 벗어납니다.")
			if addr == self.han_program.KeyIndicator()[-1][1:].split(")")[0]:  # 목표 셀주소에 도착했다면?
				return  # 함수 종료

	def write_text_at_begin_of_line_no(self, input_no, input_text):
		"""
		줄번호의 시작에 텍스트입력

		:param input_no: 숫자(정수)
		:param input_text: 입력 문자
		:return:
		"""
		self.move_cursor_to_begin_of_doc()
		self.move_cursor_to_nth_line_from_begin_of_doc(input_no)
		self.move_cursor_to_begin_of_current_line()
		self.write_text_at_cursor(input_text, True)

	def write_text_at_begin_of_selection(self, input_value):
		"""
		선택영역 시작에 텍스트입력

		:param input_value: 입력값
		:return:
		"""
		self.move_cursor_to_begin_of_selection()
		self.write_text_at_cursor(input_value)

	def write_text_at_cursor(self, input_value, next_line=False):
		"""
		커서위치에 텍스트입력

		:param input_value: 입력값
		:param next_line:
		:return:
		"""
		try:
			changed_text = input_value.split("\n")
			for one_text in changed_text:
				action_obj = self.han_program.CreateAction("InsertText")
				parameter_set_obj = action_obj.CreateSet()
				parameter_set_obj.SetItem("Text", one_text)
				action_obj.Execute(parameter_set_obj)
				if next_line:
					self.han_program.Run("BreakLine")
		except:
			pass

		self.han_program.HAction.GetDefault("InsertText", self.han_program.HParameterSet.HInsertText.HSet)
		#self.han_program.HParameterSet.HInsertText.Text = "개는 멍멍멍"
		#self.han_program.HAction.Execute("InsertText", self.han_program.HParameterSet.HInsertText.HSet)

	def write_text_at_end_of_doc(self, input_text, new_line=False):
		"""
		문서의 끝에 텍스트입력

		:param input_text: 입력 문자
		:param new_line:
		:return:
		"""
		self.move_cursor_to_end_of_doc()
		self.write_text_at_cursor(input_text, new_line)

	def write_text_at_end_of_selection(self, input_text):
		"""
		선택영역의 끝에 텍스트입력

		:param input_text: 입력 문자
		:return:
		"""
		self.move_cursor_to_end_of_selection()
		self.write_text_at_cursor(input_text)

	def write_text_at_nth_cell_in_table(self, table_no, cell_no, input_text):
		"""
		테이블의 순번째에 텍스트입력

		:param table_no: 테이블 번호
		:param cell_no: 셀번호
		:param input_text: 입력 문자
		:return:
		"""
		self.select_table_obj_by_no(table_no)
		self.han_program.Run("ShapeObjTableSelCell")
		for no in range(cell_no - 1):
			self.han_program.Run("TableRightCell")

		self.write_text_at_cursor(input_text)

	def write_text_at_start_of_selection(self, input_text):
		"""
		선택영역의 처음에 텍스트입력

		:param input_text: 입력 문자
		:return:
		"""
		self.move_cursor_to_begin_of_selection()
		self.write_text_at_cursor(input_text)

	def write_text_in_table_by_xy(self, table_no, x, y, input_text, next_line=True):
		"""
		선택영역의 처음에 텍스트입력

		:param table_no: 테이블 번호
		:param x:
		:param y:
		:param input_text: 입력 문자
		:param next_line:
		:return:
		"""
		self.select_table_obj_by_no(table_no)
		self.han_program.Run("ShapeObjTableSelCell")
		for no in range(x - 1):
			self.han_program.Run("TableLowerCell")

		for no in range(y - 1):
			self.han_program.Run("TableRightCell")
		self.write_text_at_cursor(input_text, next_line)

	def write_text_with_new_line_at_end_of_doc(self, input_text):
		"""
		문서의 끝에 새로운 라인으로 텍스트입력

		:param input_text: 입력 문자
		:return:
		"""
		self.move_cursor_to_end_of_doc()
		self.insert_next_line_at_cusor()
		self.write_text_at_cursor(input_text)

	def write_value_at_end_of_para_no(self, input_text):
		"""
		특정 문단의 끝에 텍스트입력

		:param input_text: 입력 문자
		:return:
		"""
		self.move_cursor_to_end_of_current_para()
		self.write_text_at_cursor(input_text)

	def zzz_test_001(self):
		"""
		HwpCtrl API를 사용한 경우

		:return:
		"""
		action_obj = self.han_program.CreateAction("InsertText")
		parameter_set_obj = action_obj.CreateSet()
		parameter_set_obj.SetItem("Text", "가나다라마바사아")
		action_obj.Execute(parameter_set_obj)

		# HAction을 사용한 경우
		self.han_program.HAction.GetDefault("InsertText", self.han_program.HParameterSet.HInsertText.HSet)
		self.han_program.HParameterSet.HInsertText.Text = "123456789"
		self.han_program.HAction.Execute("InsertText", self.han_program.HParameterSet.HInsertText.HSet)

	def paint_background_for_selection_by_xcolor(self, input_xcolor="red50"):
		"""
		색칠하기 : 선택영역을 빨간색으로 칠하기

		:return:
		"""
		colorx = xy_color.xy_color()

		input_rgb = colorx.change_xcolor_to_rgb(input_xcolor)
		rgb_value = self.han_program.RGBColor(red=input_rgb[0], green=input_rgb[1], blue=input_rgb[2])

		action_obj = self.han_program.CreateAction("MarkPenShape")
		parameter_set_obj = action_obj.CreateSet()
		action_obj.GetDefault(parameter_set_obj)
		parameter_set_obj.SetItem("Color", rgb_value)
		action_obj.Execute(parameter_set_obj)

	def paint_font_for_selection_by_xcolor(self, input_xcolor="red50"):
		"""
		선택영역 xcolor형식으로 색칠하기

		:param input_xcolor: xcolor형식의 색깔
		:return:
		"""
		colorx = xy_color.xy_color()
		input_rgb = colorx.change_xcolor_to_rgb(input_xcolor)
		self.set_font_color_for_selection_by_rgb(input_rgb)
		"""
		hwp.set_font()의 파라미터 목록

		
		DiacSymMark: 강조점(0~12)
		Emboss: 양각(True/False)
		Engrave: 음각(True/False)
		FaceName: 서체 이름
		FontType: 1(TTF, 기본값)
		Height: 글자크기(pt, 0.1 ~ 4096)
		
		Offset: 글자위치-상하오프셋(-100 ~ 100)
		OutLineType: 외곽선타입(0~6)
		Ratio: 장평(50~200)
		ShadeColor: 음영색(RGB, 0x000000 ~ 0xffffff) ~= hwp.rgb_color(255,255,255), 취소는 0xffffffff(4294967295)
		ShadowColor: 그림자색(RGB, 0x0~0xffffff) ~= hwp.rgb_color(255,255,255), 취소는 0xffffffff(4294967295)
		ShadowOffsetX: 그림자 X오프셋(-100 ~ 100)
		ShadowOffsetY: 그림자 Y오프셋(-100 ~ 100)
		ShadowType: 그림자 유형(0: 없음, 1: 비연속, 2:연속)
		Size: 글자크기 축소확대%(10~250)
		Spacing: 자간(-50 ~ 50)
		StrikeOutColor: 취소선 색(RGB, 0x0~0xffffff) ~= hwp.rgb_color(255,255,255), 취소는 0xffffffff(4294967295)
		StrikeOutShape: 취소선 모양(0~12, 0이 일반 취소선)
		StrikeOutType: 취소선 유무(True/False)
		SubScript: 아래첨자(True/False)
		SuperScript: 위첨자(True/False)
		TextColor: 글자색(RGB, 0x0~0xffffff) ~= hwp.rgb_color(255,255,255), 기본값은 0xffffffff(4294967295)
		UnderlineColor: 밑줄색(RGB, 0x0~0xffffff) ~= hwp.rgb_color(255,255,255), 기본값은 0xffffffff(4294967295)
		UnderlineShape: 밑줄형태(0~12)
		UnderlineType: 밑줄위치(0:없음, 1:하단, 3:상단)
		UseFontSpace: 글꼴에 어울리는 빈칸 적용여부(True/False)
		"""

	def set_font_underline_for_selection_with_xcolor(self, input_xcolor="bla", underline_position = 1):
		"""
		선택영역 rgb값으로 색칠하기

		:param input_xcolor:  xcolor형식의 색깔
		:param underline_position:
		:return:
		"""
		colorx = xy_color.xy_color()
		input_rgb = colorx.change_xcolor_to_rgb(input_xcolor)
		rgb_value = self.han_program.RGBColor(red=input_rgb[0], green=input_rgb[1], blue=input_rgb[2])

		action_obj = self.han_program.CreateAction("CharShape")
		cs = action_obj.CreateSet()
		action_obj.GetDefault(cs)
		cs.SetItem("UnderlineType", underline_position)
		cs.SetItem("UnderlineColor", rgb_value)
		action_obj.Execute(cs)

	def replace_all_in_doc(self, input_text, replace_text):
		"""
		바꾸기 : 문서안의 모든것을 바꾸는 것

		:param input_text: 입력 문자
		:param replace_text: 바꿀 문자
		:return:
		"""
		pset = self.han_program.HParameterSet.HFindReplace
		pset.Direction = self.han_program.FindDir("AllDoc")
		pset.FindString = input_text
		pset.ReplaceString = replace_text
		pset.IgnoreMessage = 1
		self.han_program.HAction.Execute("AllReplace", pset.HSet)

	def replace_one_time_in_doc(self, input_text, replace_text):
		"""
		바꾸기 : 문서에서 찾은것을 1번만 바꾸기

		:param input_text: 찾을 문자
		:param replace_text: 바꿀 문자
		:return: 
		"""
		pset = self.han_program.HParameterSet.HFindReplace
		pset.Direction = 0 # 0: 아래쪽
		pset.FindString = input_text
		pset.ReplaceString = replace_text
		pset.IgnoreMessage = 1
		self.han_program.HAction.Execute("ExecReplace", pset.HSet)

	def find_one_time_in_doc(self, input_text):
		"""
		찾기 : 현재 커서의 우치에서 아래쪽으로 입력문자를 찾는 것

		:param input_text: 찾을 문자
		:return:
		"""

		action_obj = self.han_program.CreateAction("ReverseFind")
		cs = action_obj.CreateSet()
		action_obj.GetDefault(cs)
		cs.SetItem("Direction", 1)
		cs.SetItem("FindString", input_text)
		cs.SetItem("IgnoreMessage", 1)
		action_obj.Execute(cs)
		"""
		아래와같은 형식으로 도 가능하다
		pset = self.han_program.HParameterSet.HFindReplace
		pset.Direction = 2 # 0: 아래쪽, 2:문서전체
		pset.FindString = input_text
		pset.IgnoreMessage = 1
		self.han_program.HAction.Execute("BackwardFind", pset.HSet)
		"""

	def get_font_bold_for_selection(self):
		"""
		Bold: 진하게 적용(True/False)

		:return:
		"""
		result = self.han_program.CharShape.Item("Bold")
		return result

	def get_font_italic_for_selection(self):
		"""
		Italic: 이탤릭(True/False)

		:return:
		"""
		result = self.han_program.CharShape.Item("Italic")
		return result

	def get_font_underline_for_selection(self):
		"""
		UnderlineType: 밑줄위치(0:없음, 1:하단, 3:상단)

		:return:
		"""
		result = self.han_program.CharShape.Item("UnderlineType")
		return result

	def get_font_color_for_selection(self):
		"""
		TextColor: 글자색(RGB, 0x0~0xffffff) ~= hwp.rgb_color(255,255,255), 기본값은 0xffffffff(4294967295)

		:return:
		"""
		result = self.han_program.CharShape.Item("TextColor")
		return result

	def get_font_name_for_selection(self):
		"""
		FaceNameHangul: 한글폰트이름
		FaceNameLatin: 영어폰트이름

		:return:
		"""
		result1 = self.han_program.CharShape.Item("FaceNameHangul")
		result2 = self.han_program.CharShape.Item("FaceNameLatin")
		return [result1,result2]

	def insert_picture_at_selection_end(self, file_full_name="D:/my_code/icons/bibi2.png", input_w=100, input_h=100):
		"""
		이미지 삽입
		
		:param file_full_name: 파일이름
		:param input_w: 이미지의 넒이
		:param input_h: 이미지의 높이
		:return: 
		"""
		self.han_program.InsertPicture(file_full_name, Embedded=True,  sizeoption=1, width=input_w, height=input_h)  


	def set_page_no_at_header(self, left_text="", right_start_no=1):
		"""
		
		:param left_text: 
		:param right_start_no: 
		:return: 
		"""
		action_obj = self.han_program.CreateAction("InsertPageNum")
		#parameter_set_obj = action_obj.CreateSet()
		#action_obj.GetDefault(parameter_set_obj)
		#parameter_set_obj.SetItem("Color", rgb_value)
		#action_obj.Execute(parameter_set_obj)

	def write_today_at_cursor(self):
		"""
		현재 커서에 yyyy-mm-dd를 넣는 것

		:return:
		"""
		timex = xy_time.xy_time()
		yyyymmdd = timex.get_yyyy_mm_dd_for_today()
		self.write_text_at_cursor(yyyymmdd)


	def set_page_with_margin(self, input_left=15, input_right=15):
		"""
		왼쪽과 오른쪽의 마진을 설정하는 것
		
		:param input_left: 왼쪽 마진용 숫자
		:param input_right: 오른쪽 마진용 숫자
		:return:
		"""
		action_obj = self.han_program.CreateAction("PageSetup")
		cs = action_obj.PageDef.CreateSet()
		cs.SetItem("LeftMargin", input_left)
		cs.SetItem("RightMargin", input_right)

		"""
		Act = hwp.CreateAction("PageSetup")
		Set = Act.CreateSet()
		Act.GetDefault(Set)
		Set.SetItem("ApplyTo", 3)  # 2:현재구역, 3:문서전체, 4:새구역으로
		Pset = Set.CreateItemSet("PageDef", "PageDef")
		Pset.SetItem("TopMargin", 0)
		Pset.SetItem("BottomMargin", 0)
		Pset.SetItem("LeftMargin", hwp.MiliToHwpUnit(30))
		Pset.SetItem("RightMargin", hwp.MiliToHwpUnit(30))
		Pset.SetItem("HeaderLen", 0)
		Pset.SetItem("FooterLen", 0)
		Pset.SetItem("GutterLen", 0)
		"""

	def find(self, input_text):
		"""
		찾기
		
		:param input_text: 찾을 문자
		:return: 
		"""

		action_obj = self.han_program.CreateAction("RepeatFind")
		cs = action_obj.CreateSet()
		action_obj.GetDefault(cs)
		cs.SetItem("Direction", self.han_program.FindDir("Forward")) # 1 : self.han_program.FindDir("Forward")
		cs.SetItem("FindString", input_text)
		cs.SetItem("IgnoreMessage", 1)
		cs.SetItem("FindType", 1)
		action_obj.Execute(cs)
		print(self.han_program.GetPos())


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ResultWrapper 지원
#  · xy.excel.some_method().to("변수명")  으로 결과 저장
#  · 기존 방식 result = xy.excel.some_method() 도 100% 동일 작동
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

	_result_ns: dict = {}
	_use_caller_globals: bool = True

	def set_namespace(self, ns: dict, use_caller: bool = False) -> None:
		"""
		.to() 가 값을 저장할 네임스페이스를 지정합니다.
		기본값은 호출자의 globals() 를 자동 감지합니다.

		Examples:
			xy.excel.set_namespace(globals())
		"""
		xy_hwp._result_ns		  = ns
		xy_hwp._use_caller_globals = use_caller

	def __getattribute__(self, name: str):
		"""
		xy_hwp 에 직접 정의된 public 메서드 호출 결과만 ResultWrapper 로 포장.

		래핑: 클래스 외부(사용자 코드)에서 호출한 경우
		통과: _로 시작하는 이름 / 인스턴스 속성 / 내부 self.xxx() 호출
		"""
		import inspect, functools

		# _로 시작하는 내부/특수 이름은 즉시 통과
		if name.startswith('_'):
			return object.__getattribute__(self, name)

		obj = object.__getattribute__(self, name)

		# 클래스 __dict__ 에 직접 def 로 정의된 것만 래핑 후보
		# → 인스턴스 속성(xlapp 등)은 __dict__ 에 없으므로 그대로 반환
		cls = object.__getattribute__(self, '__class__')
		if name not in cls.__dict__:
			return obj

		raw_def = cls.__dict__[name]
		if not (inspect.isfunction(raw_def) or
				isinstance(raw_def, (classmethod, staticmethod))):
			return obj   # 클래스 변수(_result_ns 등) 통과

		# ── 핵심: 내부 self 호출(재귀)이면 래핑 안 함 ──────────
		# 호출자 프레임의 지역변수에 self 와 동일한 객체가 있으면
		# xy_hwp 메서드 내부에서 self.xxx() 로 호출한 것
		caller_frame = inspect.currentframe().f_back
		if caller_frame is not None:
			if caller_frame.f_locals.get('self') is self:
				return obj

		# ── 외부 호출: ResultWrapper 로 포장 ───────────────────
		@functools.wraps(obj)
		def _wrapped(*args, **kwargs):
			raw = obj(*args, **kwargs)
			return ResultWrapper(raw, name)

		return _wrapped

class ResultWrapper:
	"""
	xy_hwp 메서드 반환값 래퍼.
	· result = xy.excel.some_func()		  # 기존 방식 그대로
	· xy.excel.some_func().to("result")	  # 새 방식: 변수에 자동 저장
	· xy.excel.some_func().to("a").to("b")   # 체이닝
	· wrapped.value						  # 원본값 직접 접근
	"""
	__slots__ = ("_value", "_method_name")

	def __init__(self, value, method_name: str = ""):
		object.__setattr__(self, "_value",	   value)
		object.__setattr__(self, "_method_name", method_name)

	def to(self, var_name: str, ns: dict | None = None) -> "ResultWrapper":
		import inspect

		if ns is not None:
			target = ns
		elif xy_hwp._use_caller_globals and not xy_hwp._result_ns:
			frame  = inspect.stack()[1].frame
			target = frame.f_globals
		else:
			target = xy_hwp._result_ns
		target[var_name] = object.__getattribute__(self, "_value")
		return self

	@property
	def value(self):		return object.__getattribute__(self, "_value")
	def __repr__(self):
		v = object.__getattribute__(self, "_value")
		m = object.__getattribute__(self, "_method_name")
		return f"ResultWrapper({m!r} → {v!r})"

	def __str__(self):		return str(object.__getattribute__(self, "_value"))
	def _v(self):			 return object.__getattribute__(self, "_value")
	def _u(self, other):	  return other._v() if isinstance(other, ResultWrapper) else other
	def __eq__(self, other):  return self._v() == self._u(other)
	def __ne__(self, other):  return self._v() != self._u(other)
	def __lt__(self, other):  return self._v() <  self._u(other)
	def __le__(self, other):  return self._v() <= self._u(other)
	def __gt__(self, other):  return self._v() >  self._u(other)
	def __ge__(self, other):  return self._v() >= self._u(other)
	def __bool__(self):	   return bool(object.__getattribute__(self, "_value"))
	def __len__(self):		return len(object.__getattribute__(self, "_value"))
	def __iter__(self):	   return iter(object.__getattribute__(self, "_value"))
	def __getitem__(self, key):		return object.__getattribute__(self, "_value")[key]
	def __contains__(self, item):		return item in object.__getattribute__(self, "_value")
	def __add__(self, other):		return self._v() + self._u(other)
	def __radd__(self, other):		return other + self._v()

	def __hash__(self):
		try:	return hash(self._v())
		except: return id(self)

	# ── 속성/메서드를 내부 값으로 위임 (.split(), .upper() 등) ─
	def __getattr__(self, name: str):
		v = object.__getattribute__(self, "_value")
		return getattr(v, name)
