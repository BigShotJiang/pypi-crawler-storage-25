"""
Xython Easy Import - Auto Generated
"""
from typing import TYPE_CHECKING, cast

if TYPE_CHECKING:
    from .xy_excel import xy_excel as Xy_ExcelType
    from .xy_word import xy_word as Xy_WordType
    from .xy_hwp import xy_hwp as Xy_HwpType
    from .xy_time import xy_time as Xy_TimeType
    from .xy_outlook import xy_outlook as Xy_OutlookType
    from .xy_db import xy_db as Xy_DbType
    from .xy_map import xy_map as Xy_MapType
    from .xy_util import xy_util as Xy_UtilType
    from .xy_color import xy_color as Xy_ColorType
    from .xy_re import xy_re as Xy_ReType
    from .xy_auto import xy_auto as Xy_AutoType

class EasyLoader:
    def __init__(self):
        self._cache = {}

    @property
    def excel(self):
        """
        Excel 조작 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.excel
        """
        if 'excel' not in self._cache:
            from .xy_excel import xy_excel
            self._cache['excel'] = xy_excel()

        if TYPE_CHECKING:
            return cast('Xy_ExcelType', self._cache['excel'])
        return self._cache['excel']


    @property
    def word(self):
        """
        워드 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.word
        """
        if 'word' not in self._cache:
            from .xy_word import xy_word
            self._cache['word'] = xy_word()

        if TYPE_CHECKING:
            return cast('Xy_WordType', self._cache['word'])
        return self._cache['word']


    @property
    def hwp(self):
        """
        아래아한글 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.hwp
        """
        if 'hwp' not in self._cache:
            from .xy_hwp import xy_hwp
            self._cache['hwp'] = xy_hwp()

        if TYPE_CHECKING:
            return cast('Xy_HwpType', self._cache['hwp'])
        return self._cache['hwp']


    @property
    def time(self):
        """
        시간 처리 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.time
        """
        if 'time' not in self._cache:
            from .xy_time import xy_time
            self._cache['time'] = xy_time()

        if TYPE_CHECKING:
            return cast('Xy_TimeType', self._cache['time'])
        return self._cache['time']


    @property
    def outlook(self):
        """
        Outlook 이메일 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.outlook
        """
        if 'outlook' not in self._cache:
            from .xy_outlook import xy_outlook
            self._cache['outlook'] = xy_outlook()

        if TYPE_CHECKING:
            return cast('Xy_OutlookType', self._cache['outlook'])
        return self._cache['outlook']


    @property
    def db(self):
        """
        데이터베이스 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.db
        """
        if 'db' not in self._cache:
            from .xy_db import xy_db
            self._cache['db'] = xy_db()

        if TYPE_CHECKING:
            return cast('Xy_DbType', self._cache['db'])
        return self._cache['db']


    @property
    def map(self):
        """
        지도만드는 것 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.map
        """
        if 'map' not in self._cache:
            from .xy_map import xy_map
            self._cache['map'] = xy_map()

        if TYPE_CHECKING:
            return cast('Xy_MapType', self._cache['map'])
        return self._cache['map']


    @property
    def util(self):
        """
        유틸리티 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.util
        """
        if 'util' not in self._cache:
            from .xy_util import xy_util
            self._cache['util'] = xy_util()

        if TYPE_CHECKING:
            return cast('Xy_UtilType', self._cache['util'])
        return self._cache['util']


    @property
    def color(self):
        """
        색관리 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.color
        """
        if 'color' not in self._cache:
            from .xy_color import xy_color
            self._cache['color'] = xy_color()

        if TYPE_CHECKING:
            return cast('Xy_ColorType', self._cache['color'])
        return self._cache['color']


    @property
    def re(self):
        """
        정규표현식 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.re
        """
        if 're' not in self._cache:
            from .xy_re import xy_re
            self._cache['re'] = xy_re()

        if TYPE_CHECKING:
            return cast('Xy_ReType', self._cache['re'])
        return self._cache['re']


    @property
    def auto(self):
        """
        자동화용 모듈

        Examples:
            >>> from xython.starter import xy
            >>> xy.auto
        """
        if 'auto' not in self._cache:
            from .xy_auto import xy_auto
            self._cache['auto'] = xy_auto()

        if TYPE_CHECKING:
            return cast('Xy_AutoType', self._cache['auto'])
        return self._cache['auto']


xy = EasyLoader()

if TYPE_CHECKING:
    xy: EasyLoader

__all__ = ['xy', 'EasyLoader']
