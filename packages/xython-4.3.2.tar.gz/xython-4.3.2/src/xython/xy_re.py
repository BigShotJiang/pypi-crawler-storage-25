import re #내장모듈

class xy_re:

    def __init__(self):
        # 공통으로 사용할 변수들을 설정하는 것

        self.setup_is_on = False
        self.setup = {}

    def _change_xsql_to_resql(self, input_text=""):
        """
        기본적으로 xsql -> resql형식으로 만들어 주는것
        """
        if self.setup_is_on:
            setup_text = self.setup_for_maxsearch_ignorecase_multiline_dotall()
            input_text = setup_text + input_text

        if self.setup:
            for one in self.setup.keys():
                if one == "ignorecase":
                    input_text = "(대소문자무시)" + input_text
                elif one == "multiline":
                    input_text = "(여러줄)" + input_text
                elif one == "dotall":
                    input_text = "(개행문자포함)" + input_text
                elif one == "min_search":
                    input_text = "(최소찾기)" + input_text
                elif one == "begin":
                    input_text = "[begin]" + input_text
                elif one == "end":
                    input_text = input_text + "[end]"

        resql = input_text.replace(" ", "")

        aaa = self.match_with_resql(r"단어\(([^)]*)\)", resql)
        if aaa:
            one_text = aaa[0][0]
            changed_text = one_text.replace(",", "|")
            resql = resql.replace(one_text, changed_text)


        setup_list = [
            ["(대소문자무시)", r"(?i)"],  # re.IGNORECASE 대소문자 무시
            ["(여러줄)", r"(?m)"],  # re.MULITILINE 여러줄도 실행
            ["(개행문자포함)", r"(?s)"],  # re.DOTALL 개행문자도 포함
        ]

        for one in setup_list:
            resql = resql.replace(one[0], one[1])

        basic_list = [
            [r"[\[](\d+)[~](\d*)[\]]", r"{\1,\2}"],  # [3~4] ==> {3,4}
            [r":(\d+)[~](\d*)[\]]", r"]{\1,\2}"],  # :3~4] ==> ]{3,4}

            [r"\(back_ok(.*)\)", r"(?=\1)"],  # (뒤에있음(abc)) => (?=abc)
            [r"\(back_no(.*)\)", r"(?!\1)"],  # (뒤에없음(abc)) => (?!abc)
            [r"\(front_ok(.*)\)", r"(?<=\1)"],  # (앞에있음(abc)) => (?<=abc)
            [r"\(front_no(.*)\)", r"(?<!\1)"],  # (앞에없음(abc)) => (?<!abc)

            [r"\(뒤에있음(.*)\)", r"(?=\1)"],  # (뒤에있음(abc)) => (?=abc) ,2024-08-08 (:을 제거)
            [r"\(뒤에없음(.*)\)", r"(?!\1)"],  # (뒤에없음(abc)) => (?!abc),2024-08-08 (:을 제거)
            [r"\(앞에있음(.*)\)", r"(?<=\1)"],  # (앞에있음(abc)) => (?<=abc),2024-08-08 (:을 제거)
            [r"\(앞에없음(.*)\)", r"(?<!\1)"],  # (앞에없음(abc)) => (?<!abc),2024-08-08 (:을 제거)

            [r"([\[]?)[&]?영어대문자[&]?([\]]?)", r"\1A-Z\2"],
            [r"([\[]?)[&]?영어소문자[&]?([\]]?)", r"\1a-z\2"],
            [r"([\[]?)[&]?특수문자[&]?([\]]?)", r"\1~!@#\$%\^&\*\(\)_\+{}|:\"<>\?\`\-=\[\]\\;',\./\2"],
            [r"([\[]?)[&]?한글모음[&]?([\]]?)", r"\1ㅏ-ㅣ\2"],  # [ㅏ-ㅣ]
            [r"([\[]?)[&]?모든문자[&]?([\]]?)", r"\1.\n\2"],
            [r"([\[]?)[&]?일본어[&]?([\]]?)", r"\1ぁ-ゔ|ァ-ヴー|々〆〤\2"],
            [r"([\[]?)[&]?한글[&]?([\]]?)", r"\1ㄱ-ㅎ|ㅏ-ㅣ|가-힣\2"],
            [r"([\[]?)[&]?숫자[&]?([\]]?)", r"\1\\d\2"],
            [r"([\[]?)[&]?영어[&]?([\]]?)", r"\1a-zA-Z\2"],
            [r"([\[]?)[&]?한자[&]?([\]]?)", r"\1一-龥\2"],
            [r"([\[]?)[&]?문자[&]?([\]]?)", r"\1.\2"],
            [r"([\[]?)[&]?공백[&]?([\]]?)", r"\1\\s\2"],

            [r"([\[]?)[&]?eng_big[&]?([\]]?)", r"\1A-Z\2"],
            [r"([\[]?)[&]?eng_sma[&]?([\]]?)", r"\1a-z\2"],
            [r"([\[]?)[&]?special[&]?([\]]?)", r"\1~!@#\$%\^&\*\(\)_\+{}|:\"<>\?\`\-=\[\]\\;',\./\2"],
            [r"([\[]?)[&]?mo[&]?([\]]?)", r"\1ㅏ-ㅣ\2"],  # [ㅏ-ㅣ]
            [r"([\[]?)[&]?all_char[&]?([\]]?)", r"\1.\n\2"],
            [r"([\[]?)[&]?jpn[&]?([\]]?)", r"\1ぁ-ゔ|ァ-ヴー|々〆〤\2"],
            [r"([\[]?)[&]?kor[&]?([\]]?)", r"\1ㄱ-ㅎ|ㅏ-ㅣ|가-힣\2"],
            [r"([\[]?)[&]?num[&]?([\]]?)", r"\1\\d\2"],
            [r"([\[]?)[&]?eng[&]?([\]]?)", r"\1a-zA-Z\2"],
            [r"([\[]?)[&]?chi[&]?([\]]?)", r"\1一-龥\2"],
            [r"([\[]?)[&]?cha[&]?([\]]?)", r"\1.\2"],
            [r"([\[]?)[&]?space[&]?([\]]?)", r"\1\\s\2"],

            [r"[\[]단어([(].*?[)])([\]]?)", r"\1"],
            [r"[\[]또는([(].*?[)])([\]]?)", r"\1|"],
            [r"[\(]이름<(.+?)>(.+?)[\)]", r"?P<\1>\2"],  # [이름<abc>표현식]
        ]

        #[또는:가나다, 마바사, 자차카]
        #,를 |로 바꾸는것
        # "\[또는.*?\]"

        for one in basic_list:
            resql = re.sub(one[0], one[1], resql)
            resql = resql.replace(" ", "")

        simple_list = [
            ['[begin]', '^'],
            ['[처음]', '^'], ['[맨앞]', '^'], ['[시작]', '^'],
            ['[맨뒤]', '$'], ['[맨끝]', '$'], ['[끝]', '$'],
            ['[end]', '$'],
            ['[또는]', '|'], ['또는', '|'], ['or', '|'],
            ['not', '^'], ['[최소찾기]', '(최소찾기)'],
        ]

        for one in simple_list:
            resql = resql.replace(one[0], one[1])

        # 최대탐색을 할것인지 최소탐색을 할것인지 설정하는 것이다
        if "(최소찾기)" in resql:
            resql = resql.replace("{1,}", "+")
            resql = resql.replace("{0,}", "*")

            resql = resql.replace("+", "+?")
            resql = resql.replace("*", "*?")
            resql = resql.replace("(최소찾기)", "")

        # 이단계를 지워도 실행되는데는 문제 없으며, 실행 시키지 않았을때가 약간 더 읽기는 편하다
        high_list = [
            [r'[^a-zA-Z0-9]', r'\W'],
            [r'[^0-9a-zA-Z]', r'\W'],
            [r'[a-zA-Z0-9]', r'\w'],
            [r'[0-9a-zA-Z]', r'\w'],
            [r'[^0-9]', r'\D'],
            [r'[0-9]', r'\d'],
            [r'{0,}', r'*'],
            [r'{1,}', r'+'],
        ]

        for one in high_list:
            resql = resql.replace(one[0], one[1])

        # print ("result ==> ", result)

        if "[.]" in resql:
            resql = resql.replace("[.]", ".")
        self.setup_is_on = False
        return resql

    def change_html_tag_to_resql(self, one_tag, option_tag_show=False):
        """
        htm태그안의 값을 갖고오는 것

        :param one_tag:
        :param option_tag_show:
        :return:
        """
        new_tag = ""
        for one in one_tag:
            new_tag = new_tag + "[" + str(one).upper() + str(one).lower() + "]"
        if option_tag_show:
            change_sql = "<" + new_tag + ">.*<\\/" + new_tag + ">"
        else:
            change_sql = "(?<=<" + new_tag + ">).*(?= <\\/" + new_tag + ">)"
        result = change_sql
        return result

    def change_xsql_to_resql (self, input_xsql):
        """
        input_xsql을 regex스타일로 바꾸는것

        :param input_xsql: 정규표현식을 쉽게 만들도록 변경한 형태의 문장
        :return:
        """
        result = self._change_xsql_to_resql(input_xsql)
        return result

    def change_number_to_tel_style(self, input_value):
       """
       전화번호나 핸드폰 번호 스타일을 바꿔주는것
       전화번호를 21345678 =>02-134-5678 로 변경하는 것
       :param input_value:
       :return:
       """

       result = input_value
       value = str(int(input_value))
       if len(value) == 8 and value[0] == "2":
          # 22345678 => 02-234-5678
          result = "0" + value[0:1] + "-" + value[1:4] + "-" + value[4:]
       elif len(value) == 9:
          if value[0:2] == "2":
             # 223456789 => 02-2345-6789
             result = "0" + value[0:1] + "-" + value[1:5] + "-" + value[5:]
          elif value[0:2] == "11":
             # 113456789 => 011-345-6789
             result = "0" + value[0:2] + "-" + value[2:5] + "-" + value[5:]
          else:
             # 523456789 => 052-345-6789
             result = "0" + value[0:2] + "-" + value[2:5] + "-" + value[5:]
       elif len(value) == 10:
          # 5234567890 => 052-3456-7890
          # 1034567890 => 010-3456-7890
          result = "0" + value[0:2] + "-" + value[2:6] + "-" + value[6:]
       return result

    def check_or(self, input_text):
        """
        input_text = "[또는:가나다, 마바사]"
        aaa = check_or(input_text)
        print(aaa)

        :return:
        """
        result = []
        resql = r"\[또는:(.*?)\]"
        temp = self.search_with_resql(resql, input_text)

        if not temp:
            resql = r"\[or:(.*?)\]"
            temp = self.search_with_resql(resql, input_text)

        if temp:
            find_text = temp[0][3][0]
            changed_text = "("
            for one in find_text.split(","):
                changed_text = changed_text + str(one).strip() + "|"

            changed_text = changed_text[:-1] + ")"

            result.append(temp[0][1])
            result.append(temp[0][2])
            result.append(changed_text)
        return result

    def data_for_example_set_001(self):
        """
        잘 사용하는 re코드들
        """
        result = {
            r"1개이상의 공백없애기": r"[공백:2~10]",
            r"괄호안의 글자만 추출": r"([문자:1~20])",
            r"숫자만 추출": r"[공백:1~3][영어:1~10]-[숫자:1~10][영어:0~10][공백:1~5]",
            r"핸드폰번호": r"[시작][숫자:4~4]-[숫자:1~2]-[숫자:1~2][끝]",  # "^\d{4}-\d{1,2}-\d{1,2}$"]
            r"복잡한 생년월일": r"([0-9]{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[1,2][0-9]|3[0,1]))-[1-4][0-9]{6}",
            r"이메일": r"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$",
            r"영어와 숫자만 추출": r"실시간시세",
            r"~~용으로 끝나는 단어": r"실시간시세",
            r"한글만": r"[한글:1~20]",
            r"abc중 c만 1번이상 반복되는것 찾기": r"abc[1~]",
            r"abc중 bc만 1번이상 반복되는것 찾기": r"a(bc)[1~]",
            r"a와 b와 c를 제외한 모든 문자와 매치": r"[^abc]",
            r"한글로 3~5개의 글자로 된것을 그룹명 짖기": r"(?P<그룹명>[한글:3~5])",
            r"a와 b사이의 모든문자 찾기": r"a[문자:1~]b",
            r"a또는b또는c": r"a[또는]b[또는]c",
            r"전방탐색 : .+(?=:) => :앞의 모든 문자": r".+(?=:)",
            r"후방탐색 : (?<=\$)[0-9.]+ => $뒤의 숫자": r"(?<=\$)[0-9.]+",
            r"Html태그중 <H숫자>찾을문자<\H숫자>안의 글자": r"<H(0-30])>.*?</H\\1>",
            r"문장중 핸드폰번호 찾기": r"0[1~1][숫자:2~2]-[0~1][숫자:3~4]-[0~1][숫자:4~4]",
            r"2022-01-01형식의 날짜찾기": r"[0-9]{4})-([0-9]{2})-([0-9]{2}",
            r"이메일찾기": r"[\w\.-]+@[\w\.-]+",
            r"괄호안의 숫자 찾기": r"([모든문자:0~])",
            r"지역 전화번호 찾기": r"0(2|31|32|33|41|42|43|44|51|52|53|54|55|61|62|63|64)\-{0,1}\d{3,4}\-{0,1}\d{4}",
            r"주민등록번호": r"[0-9]{2}0[1-9]|1[0-2]0[1-9]|[1,2][0-9]|3[0,1]-[1-4][0-9]{6}",
            r"금액": r"[숫자,][1~][원:0~1]",
            r"중복된 단어 찾기": r"\\b(\\w+)\\s+\\1\\b", }

        return result

    def data_for_special_char_set(self):
        """
        특수문자들을 돌려준다

        :return:
        """
        result = r".^$*+?{}[]\\|()"
        return result

    def delete_all_except_num_n_eng_n_underbar(self, input_text):
        """
        영문과 숫자와 공백을 제외하고 다 제거를 하는것

        :param input_text: 입력되는 text문장
        :return:
        """
        result = []
        for one_data in input_text:
            temp = ""
            for one in one_data:
                if str(one) in ' 0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_':
                    temp = temp + str(one)
            result.append(temp)
        return result

    def delete_all_explanation_in_python_code(self, input_text):
        """
        py화일의 설명문의 줄들을 제거하는 코드

        :param input_text: 입력되는 text문장
        :return:
        """
        input_text = re.sub(re.compile(r"[\s]*#.*[\n]"), "\\n", input_text)
        input_text = re.sub(re.compile(r"[\s]*'''.*?'''", re.DOTALL | re.MULTILINE), "\n", input_text)
        input_text = re.sub(re.compile(r'[\s]*""".*?"""', re.DOTALL | re.MULTILINE), "\n", input_text)
        input_text = re.sub(re.compile(r'^[\s]*[\n]'), "", input_text)
        return input_text

    def delete_eng_n_num(self, input_text):
        """
        알파벳과 숫자만 삭제하는것

        :param input_text: 입력되는 text문장
        :return:
        """
        re_com = re.compile(r"[A-Za-z0-9]*")
        if (re_com.search(input_text) == None):
            new_text = input_text
        else:
            new_text = re_com.sub("", input_text)
        return new_text

    def delete_except_special_char(self, input_text):
        """
        공백과 특수문자등을 제외하고 같으면 새로운 y열에 1을 넣는 함수
        리스트의 사이즈를 조정한다

        :param input_text: 입력되는 text문장
        :return:
        """
        re_com = re.compile(r"[^\s!@#$%^*()\-_=+\\\|\[\]{};:'\",.<>\/?]*")
        if (re_com.search(input_text) == None):
            new_text = input_text
        else:
            new_text = re_com.sub("", input_text)
        return new_text

    def delete_from_0_to_start_of_searched_value(self, input_xsql, input_text, include_serarched_value=True):
        """
        찾는자료 앞의 모든 자료를 삭제하기
        옵션으로 찾은 자료를 포함할지 아닐지를 선택한다

        :param input_xsql: 정규표현식을 쉽게 만들도록 변경한 형태의 문장, 예: [한글:3~4]
        :param input_text: 입력되는 text문장
        :param include_serarched_value:
        :return:
        """
        found_data = self.search_with_xsql(input_xsql, input_text)
        start_x= 0
        if found_data:
            if include_serarched_value:
                start_x = found_data[0][1]
            else:
                start_x = found_data[0][2]
        result = input_text[start_x:]
        return result

    def delete_from_end_of_searched_value_to_end_of_text(self, input_xsql, input_text, include_serarched_value=True):
        """
        찾는 자료뒤의 모든 자료를 삭제하기
        옵션으로 찾은 자료를 포함할지 아닐지를 선택한다

        :param input_xsql: 정규표현식을 쉽게 만들도록 변경한 형태의 문장, 예: [한글:3~4]
        :param input_text: 입력되는 text문장
        :param include_serarched_value:
        :return:
        """
        found_data = self.search_with_xsql(input_xsql, input_text)
        start_x=0
        if found_data:
            if include_serarched_value:
                start_x = found_data[0][2]
            else:
                start_x = found_data[0][1]
        result = input_text[:start_x]
        return result

    def delete_kor_eng_num(self, input_text):
        """
        한글, 영어, 숫자만 지우는 것

        :param input_text: 입력되는 text문장
        :return:
        """
        re_com = re.compile(r"[A-Za-z0-9ㄱ-ㅎㅏ-ㅣ가-힣]*")
        if (re_com.search(input_text) == None):
            new_text = input_text
        else:
            new_text = re_com.sub("", input_text)
        return new_text

    def delete_no_meaning_words(self, input_list, change_word_dic):
        """
        문장에서 자주 사용하는 삭제해도 되는 일반적인 것들을 삭제하는 기능이다

        :param input_list:
        :param change_word_dic:
        :return:
        """
        sql_1 = r"[시작][숫자&특수문자:1~][끝]"  # 숫자만 있는 것을 삭제
        sql_2 = r"[시작][숫자:1:5][영어&한글:1:1][끝]"  # 1223개 와 같은것 삭제
        sql_3 = r"[시작][한글:1~][끝]"  #
        sql_4 = r"[\(][문자:1~][\)]"  # 괄호안의 글자

        result = []
        for one in input_list:
            one = str(one).strip()
            if self.is_fullmatch_with_xsql(sql_3, one):
                if one in list(change_word_dic.keys()):
                    one = change_word_dic[one]

            if self.is_fullmatch_with_xsql(sql_4, one):
                one = self.delete_with_xsql(sql_4, one)

            if len(one) <= 1:
                one = ""
            elif self.is_fullmatch_with_xsql(sql_1, one):
                one = ""
            elif self.is_fullmatch_with_xsql(sql_2, one):
                one = ""

            if one != "":
                result.append(one)

            result_unique = list(set(result))
        return result_unique

    def delete_num_comma(self, input_text):
        """
        숫자중에서 콤마(,)를 포함해서 모두 삭제하는것
        2번으로 나누어서 처리를 한다
        - 숫자안의 콤마만 삭제 : 1,234,567 => 1234567
        - 숫자 삭제
        """
        re_com = re.compile(r"[0-9,]*\.?[0-9]*")
        new_text = re_com.sub("", input_text)
        result = re.sub(r'\d', '', new_text)
        return result

    def delete_over_2_empty_lines(self, input_text):
        """
        줄이 2줄이상 떨어진것을 2줄만 남기고 나머지는 삭제하는것
        여러줄의 빈줄을 삭제하는게 목적이다

        :param input_text: 입력되는 text문장
        :return:
        """
        input_text = re.sub(r"(\s*\n){2,}", "\n", input_text)
        return input_text

    def delete_special_char(self, input_text):
        """
        공백과 특수문자등을 제외하고 같으면 새로운 y열에 1을 넣는 함수
        리스트의 사이즈를 조정한다

        :param input_text: 입력되는 text문장
        :return:
        """
        re_com = re.compile(r"[\s!@#$%^*()\-_=+\\\|\[\]{};:'\",.<>\/?]*")
        if (re_com.search(input_text) == None):
            new_text = input_text
        else:
            new_text = re_com.sub("", input_text)
        return new_text

    def delete_special_letter(self, input_list):
        """
        입력받은 텍스트로된 리스트의 자료를 전부 특수문자를 없앤후 돌려주는 것이다
        입력된 자료가 1차원 리스트인지 판단한다

        :param input_list:
        :return:
        """
        result = []
        if type(input_list) == type([]) and type(input_list[0]) != type([]):
            for one in input_list:
                if one != "" and one != None:
                    temp = self.delete_except_special_char(one)
                    result.append(temp)
        return result

    def delete_by_xsql (self, input_xsql, input_text):
        """
        입력자료중 input_xsql에 맞는 형식을 삭제하는것

        :param input_xsql: 정규표현식을 쉽게 만들도록 변경한 형태의 문장
        :param input_text: 입력되는 text문장
        :return:
        """
        resql = self._change_xsql_to_resql(input_xsql)
        result = re.sub(resql, "", input_text)
        return result

    def get_nth_matched_text_for_resql(self, re_sgl, text, n):
        """
        정규표현식을 컴파일합니다

        :param re_sgl:
        :param text:
        :param n:
        :return:
        """
        regex = re.compile(re_sgl)
        # finditer 를 사용하여 매칭 결과를 순회합니다.
        matches = regex.finditer(text)
        # n번째 매칭 결과를 찾습니다.
        for i, match in enumerate(matches, start=1):
            if i == n:
                return match.group()

    def get_nth_result_with_resql(self, resql, input_no, input_text):
        """
        입력자료중에서 정규표현식과 맞는것중에서 n번째의 위치와 값을 돌료주는 것

        :param resql:
        :param input_no:
        :param input_text: 입력되는 text문장
        :return:
        """
        re_com = re.compile(resql)
        result_match = re_com.match(input_text)
        result_finditer = re_com.finditer(input_text)
        final_result = []
        num = 0
        for index, one_iter in enumerate(result_finditer):
            if index + 1 == input_no:
                temp = []
                # 찾은 결과값과 시작과 끝의 번호를 넣는다
                temp.append(one_iter.group())
                temp.append(one_iter.start())
                temp.append(one_iter.end())

                # 그룹으로 된것을 넣는것이다
                temp_sub = []
                if len(one_iter.group()):
                    for one in one_iter.groups():
                        temp_sub.append(one)
                    temp.append(temp_sub)
                else:
                    temp.append(temp_sub)
                # 제일 첫번째 결과값에 match 랑 같은 결과인지 넣는것
                if num == 0: temp.append(result_match)
                final_result.append(temp)
                num += 1
        return final_result

    def is_fullmatch(self,input_xsql,input_text):
        """
        입력값이 정규표현식과 전체 입력값이 같을때 True를 돌려줌

        :param input_xsql: 정규표현식을 쉽게 만들도록 변경한 형태의 문장, 예: [한글:3~4]
        :param input_text: 입력되는 text문장
        :return:
        """
        result = False
        resql = self._change_xsql_to_resql(input_xsql)
        re_com = re.compile(resql)
        result_match = re_com.fullmatch(input_text)
        if result_match:
            result = True
        return result

    def is_handphone_num(self, input_text):
        """
        특수문자가들어가있는지

        :param input_text: 입력되는 text문장
        :return:
        """
        re_basic = r"^(010|019|011)-\d{4}-\d{4}+$"
        result = False
        temp = re.match(re_basic, input_text)
        if temp : result = True
        return result

    def is_have_special_char(self, input_text):
        """
        특수문자가들어가있는지

        :param input_text: 입력되는 text문장
        :return:
        """
        re_basic = r"^[a-zA-Z0-9]+$"
        result = False
        temp = re.match(re_basic, input_text)
        if temp:
            result = False  # 특수문자 없음
        else:
            result = True  # 특수문자 있음
        return result

    def is_korean_only(self, input_text):
        """
        모두 한글인지

        :param input_text: 입력되는 text문장
        :return:
        """
        re_basic = r"^[ㄱ-ㅎ|ㅏ-ㅣ|가-힣]+$"
        result = False
        temp = re.match(re_basic, input_text)
        if temp : result = True
        return result

    def is_match (self,input_xsql, input_text):
        """
        정규표현식의 결과물이 있을때 True를 돌려준다

        :param input_xsql: 정규표현식을 쉽게 만들도록 변경한 형태의 문장, 예: [한글:3~4]
        :param input_text: 입력되는 text문장
        :return:
        """
        result= False
        resql = self._change_xsql_to_resql(input_xsql)
        re_com = re.compile(resql)

        result_match = re_com.match(input_text)
        if result_match:
            result = result_match
        return result

    def is_number_only(self, input_text):
        """
        소슷점까지는 포함한것이다

        :param input_text: 입력되는 text문장
        :return:
        """
        result = False
        temp = re.match(r"^[0-9.]+$", input_text)
        if temp:
            result = True
        return result

    def match (self, input_xsql, input_text):
        """
        결과가 여러개 일때는 2차원의 결과가 나타난다
        [[찾은글자, 찾은글자의 처음 위치 번호, 끝위치 번호, [그룹1, 그룹2], .........]

        :param input_xsql: 찾을 구문
        :param input_text: 찾고자하는 문장
        :return:
        """

        resql = self._change_xsql_to_resql(input_xsql)
        re_com = re.compile(resql)
        result_match = re_com.match(input_text)
        result_finditer = re_com.finditer(input_text)

        final_result = []
        num=0
        for one_iter in result_finditer:
            temp=[]
            #찾은 결과값과 시작과 끝의 번호를 넣는다
            temp.append(one_iter.group())
            temp.append(one_iter.start())
            temp.append(one_iter.end())

            #그룹으로 된것을 넣는것이다
            temp_sub = []
            if len(one_iter.group()):
                for one in one_iter.groups():
                    temp_sub.append(one)
                temp.append(temp_sub)
            else:
                temp.append(temp_sub)

            #제일 첫번째 결과값에 match랑 같은 결과인지 넣는것
            if num == 0: temp.append(result_match)
            final_result.append(temp)
            num+=1
        return final_result

    def replace (self, input_xsql, replace_word, input_text):
        """
        입력자료를 원하는 문자로 바꾸는것

        :param input_xsql: 정규표현식으로 만들어진 형태
        :param replace_word:
        :param input_text: 입력되는 text문장
        :return:
        """
        resql = self._change_xsql_to_resql(input_xsql)
        result = re.sub(resql, replace_word, input_text, flags=re.MULTILINE)
        return result

    def search (self, input_xsql, input_text):
        """
        입력으로 들어온 정규표현시과 값중에 맞는것을 찾는 것

        :param input_xsql: 정규표현식을 쉽게 만들도록 변경한 형태의 문장, 예: [한글:3~4]
        :param input_text: 입력되는 text문장
        :return:
        """
        result = self.search_with_xsql(input_xsql, input_text)
        return result

    def search_again_for_searched_result(self, result_l2d, input_xsql):
        """
        결과값으로 넘어온 자료를 다시 검색하해서 결과를 알려주는 것

        :param result_l2d:
        :param input_xsql: 정규표현식을 쉽게 만들도록 변경한 형태의 문장
        :return:
        """
        result = []
        for l1d in result_l2d:
            start_no = l1d[1]
            temp_2d = self.search_with_xsql(input_xsql, l1d[0])
            if temp_2d:
                for l1d in temp_2d:
                    l1d[1] = l1d[1] + start_no
                    l1d[2] = l1d[2] + start_no
                    result.append(l1d)
        return result

    def search_between_bracket1_and_bracket2(self, input_text):
        r"""
        괄호안의 문자 갖고오기
        괄호 내부 내용만 추출 : '\(([^)]+)'
        앞 뒤 괄호까지 포함 : '\([^)]+\)'

        :param input_text: 입력되는 text문장
        :return:
        """

        resql = r"(?<=\()(.*?)(?=\))"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_between_char1_and_char2(self, input_text, start_char, end_char):
        """
        첫글자와 마지막글자인 것을 찾아내는 것

        :param input_text: 입력되는 text문장
        :param start_char:
        :param end_char:
        :return:
        """
        start_found = 0
        end_found = 0
        temp = ""
        result = []
        ""
        temp_list = ["", 0]
        for index, one in enumerate(input_text):
            if one == start_char:
                start_found = 1
                temp_list[1] = index
            elif one == end_char:
                end_found = 1
            if start_found and not end_found:
                temp = temp + one
            elif start_found and end_found:
                temp_list[0] = temp + one
                result.append(temp_list)
                temp_list = ["", 0]
                temp = ""
                start_found = 0
                end_found = 0
        return result

    def search_between_text1_and_text2(self, input_data, text_a, text_b):
        """
        입력된 자료에서 두개문자사이의 글자를 갖고오는것

        :param input_data:
        :param text_a:
        :param text_b:
        :return:
        """
        replace_lists=[
            [r"(",r"\("],
            [r")", r"\)"],
        ]
        origin_a = text_a
        origin_b = text_b

        for one_list in replace_lists:
            text_a = text_a.replace(one_list[0], one_list[1])
            text_b = text_b.replace(one_list[0], one_list[1])
        re_basic =text_a+"[^"+str(origin_b)+"]*"+text_b
        result = re.findall(re_basic, input_data)
        return result

    def search_between_word1_and_word2(self, input_text, word_a, word_b):
        """
        두 단어사이의 글자를 갖고오는 것

        :param word_a:
        :param word_b:
        :param input_text: 입력되는 text문장
        :return:
        """
        re_basic = r"(?<=\\" + str(word_a) + ")(.*?)(?="+str(word_b) + ")"
        resql = self._change_xsql_to_resql(re_basic)
        result = self.search_with_resql(re_basic, input_text)
        return result

    def search_by_resql_for_file(self, resql, file_name):
        """
        텍스트화일을 읽어서 re에 맞도록 한것을 리스트로 만드는 것이다
        함수인 def를 기준으로 저장을 하며, [[공백을없앤자료, 원래자료, 시작줄번호].....]

        :param resql: 정규표현식으로 만들어진 형태
        :param file_name:
        :return:
        """
        re_com = re.compile(resql)
        f = open(file_name, 'r', encoding='UTF8')
        lines = f.readlines()
        num = 0
        temp = ""
        temp_original = ""
        result = []
        for one_line in lines:
            aaa = re.findall(re_com, str(one_line))
            original_line = one_line
            changed_line = one_line.replace(" ", "")
            changed_line = changed_line.replace("\n", "")

            if aaa:
                result.append([temp, temp_original, num])
                temp = changed_line
                temp_original = original_line
            else:
                temp = temp + changed_line
                temp_original = temp_original + one_line
        return result

    def search_for_capital_text(self, input_text):
        """
        모두 알파벳대문자를 찾아내는 것

        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"^[A-Z]+$"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_for_dashed_date(self, input_text):
        """
        입력된값 전체가 -로 연결된 날짜의 자료를 찾아내는 것입니다

        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"^\d{4}-\d{1,2}-\d{1,2}$"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_for_email_address(self, input_text):
        """
        입력된값 전체가 이메일주소 입력

        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_for_eng(self, input_text):
        """
        입력된값 전체가 모두 영문인것을 찾아내는 것입니다

        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"^[a-zA-Z]+$"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_for_handphone_num(self, input_text):
        """
        입력된값 전체가 핸드폰의 형식인것을 찾아내는것
        예: 010-1234-5678

        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"^(010|019|011)-\d{4}-\d{4}"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_for_ip_address(self, input_text):
        """
        IP주소를 찾아내는 것

        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"((?:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d?\d))"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_for_korean(self, input_text):
        """
        한글인것만 찾아내는 것

        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"[ㄱ-ㅣ가-힣]"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_for_num(self, input_text):
        """
        단어중에 나와있는 숫자만 분리하는기능

        :param input_text: 입력되는 text문장
        :return:
        """
        re_compile = re.compile(r"([0-9]+)")
        result = re_compile.findall(input_text)
        new_result = []
        for dim1_data in result:
            for dim2_data in dim1_data:
                new_result.append(dim2_data)
        return new_result

    def search_for_special_char(self, input_text):
        """
        특수문자가들어가있는지

        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"^[a-zA-Z0-9]"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_num_between_len1_and_len2(self, len1, len2, input_text):
        """
        m,n개사이인 것만 추출

        :param len1:
        :param len2:
        :param input_text: 입력되는 text문장
        :return:
        """
        resql = r"^\d{" + str(len1) + "," + str(len2) + "}$"
        result = self.search_with_resql(resql, input_text)
        return result

    def search_num_from_begin(self, input_text):
        """
        맨앞에서부터 숫자를 검사하는 것
        :param input_text: 입력되는 text문장
        :return:
        """
        input_xsql = r"[시작][숫자:1~]"
        searched_data = self.search_all_by_xsql(input_xsql, input_text)
        if searched_data:
            result = searched_data[0][0]
        else:
            result = False
        return result

    def search_text_between_len1_and_len2(self, m, n , input_text):
        """
        문자수제한 : m다 크고 n보다 작은 문자

        :param m:
        :param n:
        :param input_text: 입력되는 text문장
        :return:
        """
        resql = "^.{" + str(m) + "," + str(n) + "}$"
        result = self.search_with_resql(resql, input_text)
        return result

    def setup_for_maxsearch_ignorecase_multiline_dotall(self, min_search = False, ignorecase = False, multiline=False, dotall=False):
        """
        이렇게 설정부분을 아예 이름안에 넣어서 하면 더 편하지 않을까??
        글로쓰기 힘든부분을 설정으로 만드는것

        :param min_search:
        :param ignorecase:
        :param multiline:
        :param dotall:
        :return:
        """
        self.setup["ignorecase"] = ignorecase
        self.setup["multiline"] = multiline
        self.setup["dotall"] = dotall
        self.setup["min_search"] = min_search

    def split_text_by_input_text(self, main_text, input_text):
        """
        첫번째로 찾은것을 기준으로 자료를 분리하는 것
        여러개를 찾을수있지만, 제일 처음것을 기준으로 분리한다
        결과 : [찾은 문자의 시작까지의 문자, 찾을 문자, 찾은 문자의 끝에서부터 문자 끝까지]
        """
        searched_data = self.search_all_by_xsql(input_text, main_text)
        if searched_data:
            start_idx = searched_data[0][1]
            end_idx = searched_data[0][2]
            result = [main_text[0:start_idx], main_text[start_idx:end_idx], main_text[end_idx:]]
        else:
            result = False

        return result

    def get_first_match_position(self, input_xsql, input_text):
        """
        맨처음에 찾은 문자의 위치를 돌려주는 것

        :param input_xsql:
        :param input_text:
        :return:
        """
        resql = self.change_xsql_to_resql(input_xsql)
        pattern = re.compile(resql)
        match = pattern.search(input_text)
        result = match.start() if match else -1
        return result

    def search_nth_result_with_resql(self, resql, input_no, input_text):
        """
        정규표현식으로 찾은 n개의 결과값을 갖고오는 것
        :param resql:
        :param input_no:
        :param input_text:
        :return:
        """
        re_com = re.compile(resql)
        result_match = re_com.match(input_text)
        result_finditer = re_com.finditer(input_text)
        final_result = []
        num = 0
        for index, one_iter in enumerate(result_finditer):
            if index + 1 == input_no:
                temp = []
                # 찾은 결과값과 시작과 끝의 번호를 넣는다
                temp.append(one_iter.group())
                temp.append(one_iter.start())
                temp.append(one_iter.end())

                # 그룹으로 된것을 넣는것이다
                temp_sub = []
                if len(one_iter.group()):
                    for one in one_iter.groups():
                        temp_sub.append(one)
                        temp.append(temp_sub)
                else:
                    temp.append(temp_sub)
                # 제일 첫번째 결과값에 match 랑 같은 결과인지 넣는것
                if num == 0: temp.append(result_match)
                final_result.append(temp)
                num += 1
        return final_result

    def replace_many_times_with_xsql(self, xsql_list, replace_word_list, input_text):
        """
        하나의 값을 여러 sql로 계속 값을 변경하는 것

        :param xsql_list:
        :param replace_word_list:
        :param input_text:
        :return:
        """
        resql_list = []
        for one in xsql_list:
            resql_list.append(self._change_xsql_to_resql(one))
        for index, one_resql in enumerate(resql_list):
            input_text = re.sub(one_resql, replace_word_list[index], input_text, flags=re.MULTILINE)
        return input_text

    def match_in_last_n(self, text, target_word, n, replacement_word = None):
        # 마지막 n개의 글자안에서 원하는것을 찾는 방법
        escape_word = re.escape(target_word)
        pattern = rf"(?=.{{0,{n}}}$){escape_word}"
        if replacement_word is not None:
            return re.sub(pattern, replacement_word, text, flags=re.DOTALL)
        else:
            matches = re.finditer(pattern, text, flags=re.DOTALL)
            return [match.span() for match in matches]

    def process_word_n_to_m(self, text, target_word, n, m, replacement_word=None):
        # 앞에서 n~ m개의 글자 사이에 문자를 찾아서 변경도 가능하게 한것
        escape_word = re.escape(target_word)
        pattern = escape_word
        if replacement_word is not None:
            def replacer(match):
                start_pos, end_pos = match.span()
                if start_pos >= n and end_pos <=m:
                    return replacement_word
                else:
                    return match.group()
            return re.sub(pattern, replacer, text, flags=re.DOTALL)
        else:
            matches = re.finditer(pattern, text, flags=re.DOTALL)
            return [
                match.span() for match in matches
                if match.start() >= n and match.end() <= m
            ]


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ResultWrapper 지원
#  · xy.excel.some_method().to("변수명")  으로 결과 저장
#  · 기존 방식 result = xy.excel.some_method() 도 100% 동일 작동
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    _result_ns: dict = {}
    _use_caller_globals: bool = True

    def set_namespace(self, ns: dict, use_caller: bool = False) -> None:
        """
        .to() 가 값을 저장할 네임스페이스를 지정합니다.
        기본값은 호출자의 globals() 를 자동 감지합니다.

        Examples:
            xy.excel.set_namespace(globals())
        """
        xy_re._result_ns          = ns
        xy_re._use_caller_globals = use_caller

    def __getattribute__(self, name: str):
        """
        xy_re 에 직접 정의된 public 메서드 호출 결과만 ResultWrapper 로 포장.

        래핑: 클래스 외부(사용자 코드)에서 호출한 경우
        통과: _로 시작하는 이름 / 인스턴스 속성 / 내부 self.xxx() 호출
        """
        import inspect, functools

        # _로 시작하는 내부/특수 이름은 즉시 통과
        if name.startswith('_'):
            return object.__getattribute__(self, name)

        obj = object.__getattribute__(self, name)

        # 클래스 __dict__ 에 직접 def 로 정의된 것만 래핑 후보
        # → 인스턴스 속성(xlapp 등)은 __dict__ 에 없으므로 그대로 반환
        cls = object.__getattribute__(self, '__class__')
        if name not in cls.__dict__:
            return obj

        raw_def = cls.__dict__[name]
        if not (inspect.isfunction(raw_def) or
                isinstance(raw_def, (classmethod, staticmethod))):
            return obj   # 클래스 변수(_result_ns 등) 통과

        # ── 핵심: 내부 self 호출(재귀)이면 래핑 안 함 ──────────
        # 호출자 프레임의 지역변수에 self 와 동일한 객체가 있으면
        # xy_re 메서드 내부에서 self.xxx() 로 호출한 것
        caller_frame = inspect.currentframe().f_back
        if caller_frame is not None:
            if caller_frame.f_locals.get('self') is self:
                return obj

        # ── 외부 호출: ResultWrapper 로 포장 ───────────────────
        @functools.wraps(obj)
        def _wrapped(*args, **kwargs):
            raw = obj(*args, **kwargs)
            return ResultWrapper(raw, name)

        return _wrapped

class ResultWrapper:
    """
    xy_re 메서드 반환값 래퍼.
    · result = xy.excel.some_func()          # 기존 방식 그대로
    · xy.excel.some_func().to("result")      # 새 방식: 변수에 자동 저장
    · xy.excel.some_func().to("a").to("b")   # 체이닝
    · wrapped.value                          # 원본값 직접 접근
    """
    __slots__ = ("_value", "_method_name")

    def __init__(self, value, method_name: str = ""):
        object.__setattr__(self, "_value",       value)
        object.__setattr__(self, "_method_name", method_name)

    def to(self, var_name: str, ns: dict | None = None) -> "ResultWrapper":
        import inspect

        if ns is not None:
            target = ns
        elif xy_re._use_caller_globals and not xy_re._result_ns:
            frame  = inspect.stack()[1].frame
            target = frame.f_globals
        else:
            target = xy_re._result_ns
        target[var_name] = object.__getattribute__(self, "_value")
        return self

    @property
    def value(self):        return object.__getattribute__(self, "_value")
    def __repr__(self):
        v = object.__getattribute__(self, "_value")
        m = object.__getattribute__(self, "_method_name")
        return f"ResultWrapper({m!r} → {v!r})"

    def __str__(self):        return str(object.__getattribute__(self, "_value"))
    def _v(self):             return object.__getattribute__(self, "_value")
    def _u(self, other):      return other._v() if isinstance(other, ResultWrapper) else other
    def __eq__(self, other):  return self._v() == self._u(other)
    def __ne__(self, other):  return self._v() != self._u(other)
    def __lt__(self, other):  return self._v() <  self._u(other)
    def __le__(self, other):  return self._v() <= self._u(other)
    def __gt__(self, other):  return self._v() >  self._u(other)
    def __ge__(self, other):  return self._v() >= self._u(other)
    def __bool__(self):       return bool(object.__getattribute__(self, "_value"))
    def __len__(self):        return len(object.__getattribute__(self, "_value"))
    def __iter__(self):       return iter(object.__getattribute__(self, "_value"))
    def __getitem__(self, key):        return object.__getattribute__(self, "_value")[key]
    def __contains__(self, item):        return item in object.__getattribute__(self, "_value")
    def __add__(self, other):        return self._v() + self._u(other)
    def __radd__(self, other):        return other + self._v()

    def __hash__(self):
        try:    return hash(self._v())
        except: return id(self)

    # ── 속성/메서드를 내부 값으로 위임 (.split(), .upper() 등) ─
    def __getattr__(self, name: str):
        v = object.__getattribute__(self, "_value")
        return getattr(v, name)
