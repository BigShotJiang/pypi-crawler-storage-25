import os, time, winreg, socket
from html.parser import HTMLParser
from xython import xy_util, xy_re
from DrissionPage import ChromiumPage, ChromiumOptions

class TableParser(HTMLParser):
    def __init__(self):
        # convert_charrefs=True 로 HTML 엔티티 자동 변환 (html.unescape 이중 처리 불필요)
        super().__init__(convert_charrefs=True)
        self.tables = []
        self.current_pagele = []
        self.current_row = []
        self.current_cell = []
        self.in_pagele = False
        self.in_row = False
        self.in_cell = False

    def handle_starttag(self, tag, attrs):
        if tag == 'table':
            self.in_pagele = True
            self.current_pagele = []
        elif tag == 'tr' and self.in_pagele:
            self.in_row = True
            self.current_row = []
        elif tag in ['td', 'th'] and self.in_row:
            self.in_cell = True
            self.current_cell = []

    def handle_endtag(self, tag):
        if tag == 'table' and self.in_pagele:
            if self.current_pagele:
                self.tables.append(self.current_pagele)
            self.in_pagele = False
            self.current_pagele = []
        elif tag == 'tr' and self.in_row:
            if self.current_row:
                self.current_pagele.append(self.current_row)
            self.in_row = False
            self.current_row = []
        elif tag in ['td', 'th'] and self.in_cell:
            cell_text = ''.join(self.current_cell).strip()
            self.current_row.append(cell_text)
            self.in_cell = False
            self.current_cell = []

    def handle_data(self, data):
        if self.in_cell:
            self.current_cell.append(data)

class xy_edge:

    def __init__(self, url=None, port=9222, auto_connect=True):
        """
        url: 열 URL (기본값: None)
        port: 디버그 포트 (기본값: 9222)
        auto_connect: True = 자동으로 연결/실행, False = 수동
        """
        # 공통 변수 설정
        self.utilx = xy_util.xy_util()
        self.rex = xy_re.xy_re()

        self.edge_paths = self._find_edge_paths()

        self.port = port
        self.url = url
        if self.url and not self.url.startswith(('http://', 'https://')):
            self.url = 'https://' + self.url

        self.page = None
        self.browser = None
        self.new_browser_opened = False

        # 자동 연결
        if auto_connect:
            self.connect_or_start()

    @property
    def _active(self) -> ChromiumPage:
        """
        활성 페이지 반환
        """
        return self.page

    def _find_edge_paths(self) -> list:
        """
        시스템에서 Edge 실행 파일 경로를 자동으로 탐색합니다.
        """
        candidates = []

        # ── 1. Windows 레지스트리 탐색 ──────────────────────────
        if winreg:
            reg_keys = [
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe"),
            ]
            for hive, subkey in reg_keys:
                try:
                    with winreg.OpenKey(hive, subkey) as key:
                        path, _ = winreg.QueryValueEx(key, "")
                        if path and os.path.isfile(path):
                            candidates.append(path)
                except FileNotFoundError:
                    pass

        # ── 2. 고정 경로 목록 (Windows) ─────────
        fixed_paths = [
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        ]
        for p in fixed_paths:
            if os.path.isfile(p):
                candidates.append(p)

        # ── 3. PATH 환境 변수 탐색 ──────────────────────────────
        import shutil
        for name in ("msedge", "microsoft-edge", "microsoft-edge-stable"):
            found = shutil.which(name)
            if found:
                candidates.append(found)

        # 중복 제거
        seen = set()
        result = []
        for p in candidates:
            if p not in seen:
                seen.add(p)
                result.append(p)

        if result:
            print(f"✓ Edge 경로 발견: {result[0]}")
        else:
            print("⚠ Edge 경로를 자동으로 찾지 못했습니다.")

        return result

    def _is_port_open(self, port):
        """지정된 포트가 열려있는지 확인 (디버그 브라우저 실행 중인지 체크)"""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(1)
                result = sock.connect_ex(('127.0.0.1', port))
                return result == 0
        except:
            return False

    def connect_or_start(self, port=None):
        """기존에 디버그 Edge가 있으면 연결, 없으면 새로 실행"""
        if port is None:
            port = self.port

        # ─────────────────────────────────────────────────────
        # 🔍 1단계: 포트 확인 - 기존 디버그 브라우저가 실행중인가?
        # ─────────────────────────────────────────────────────
        if self._is_port_open(port):
            try:
                print(f"✓ 포트 {port}에서 실행 중인 디버그 브라우저 발견! 연결 시도...")
                self.page = ChromiumPage(addr_or_opts=f'127.0.0.1:{port}')
                self.browser = self.page.browser
                print(f"✓ 기존 브라우저 연결 성공!\n")

                # URL이 지정되어 있으면 이동
                if self.url:
                    print(f"→ URL로 이동: {self.url}")
                    self.page.get(self.url)

                return  # 연결 성공, 함수 종료
            except Exception as e:
                print(f"✗ 연결 실패: {e}")
                print(f"→ 새 브라우저를 실행합니다...\n")

        # ─────────────────────────────────────────────────────
        # 🚀 2단계: 새 Edge 브라우저 실행
        # ─────────────────────────────────────────────────────
        print(f"→ 포트 {port}에 실행 중인 브라우저가 없습니다.")
        print(f"→ 새로운 Edge 브라우저를 실행합니다...\n")

        co = ChromiumOptions()
        co.set_local_port(port)
        co.set_user_data_path(r'C:\edge_debug_temp')

        # Edge 경로 지정
        if self.edge_paths:
            print(f"→ Edge 경로 설정: {self.edge_paths[0]}")
            co.set_browser_path(self.edge_paths[0])
        else:
            print("⚠ Edge 경로를 찾지 못해 시스템 기본 브라우저를 사용합니다.")

        # 옵션 설정
        co.set_argument('--test-type')
        co.set_argument('--start-maximized')
        co.set_argument('--ignore-certificate-errors')
        co.set_argument('--allow-running-insecure-content')
        co.set_argument('--disable-web-security')
        co.set_argument('--ignore-ssl-errors')
        co.set_argument('--disable-features=InsecureFormSubmissionWarning')
        co.set_argument('--disable-popup-blocking')
        co.set_argument('--disable-infobars')
        co.set_argument('--suppress-message-center-popups')
        chrome_path = r'C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe'
        co.set_browser_path(chrome_path)

        try:
            self.page = ChromiumPage(co)
            self.browser = self.page.browser
            self.new_browser_opened = True
            print(f"✓ 새 Edge 브라우저 실행 성공!\n")

            # URL이 지정되어 있으면 이동
            if self.url:
                print(f"→ URL로 이동: {self.url}")
                self.page.get(self.url)

        except Exception as e:
            print(f"✗ Edge 실행 실패: {e}")
            raise

    def close(self):
        """브라우저 종료"""
        if self.page and self.new_browser_opened:
            try:
                self.page.quit()
                print("브라우저를 종료했습니다.")
            except:
                pass

    def select_page_as_visible_page(self):
        # 현재 보이는 화면으로 page를 설정하는 것
        all_tabs = self.browser.get_tabs()
        for tab in all_tabs:
            is_visible = tab.run_js("return document.visibilityState === 'visible'")
            if is_visible:
                self.page = tab
                return

    def select_page_as_index(self,input_index):
        # page를 tab의 index로 설정
        self.page = self.browser.get_tab(input_index)

    def select_page_as_no(self, input_no):
        # page를 tab의 no로 설정
        self.page = self.browser.get_tab(input_no-1)

    def select_page_as_latest_page(self):
        # 현재 보이는 화면으로 page를 설정하는 것
        try:
            if hasattr(self.page, 'latest_page'):
                self.page.latest_page.set_page()
                print(f"✓ 최신 탭으로 전환됨")
                return True
        except Exception:
            pass

        try:
            tab_count = len(self.page.tabs)
            if tab_count > 1:
                self.page.tabs[-1].set_page()
                print(f"✓ 마지막 탭으로 전환 (총 {tab_count}개)")
                return True
        except Exception:
            pass

    def select_page_with_new_url(self, input_url):
        new_page = self.page.new_page(input_url)

    def select_page_by_title(self, input_title):
        tabs = self.page.get_tabs()
        for tab in tabs:
            if input_title.lower() in tab.title.lower():
                self.page = tab
                return self.page

    def check_page(self, input_value=None, is_active=True):
        """
        page를 선택하는것으 무조건 활성화를 하는것은 아니다
        그래서, 활성화를 할지 않할지를 선택해야 한다
        """
        if input_value  in ["", None]:
            pass

        elif input_value in ["visible", "active", "activate"]:  # 현재 보이는 화면의 tab
            self.select_page_as_visible_page()

        elif input_value == "pass":  # 현재 상태그대로 사용
            pass

        elif isinstance(input_value, int):
            self.select_page_as_no(input_value)

        elif isinstance(input_value, str):
            self.select_page_by_title(input_value)

        else:
            pass

        if is_active:
            self.page.set.activate()

    def get_title(self, input_title=""):
        self.check_page(input_title)
        return self.page.title

    def get_all_title(self):
        result = []
        for tab_id in self.page.tab_ids:
            tab = self.page.get_page(tab_id)
            result.append(tab.title)
        return result

    def get_all_information_for_each_page(self):
        """
        현재 브라우저에 열린 모든 탭의 제목과 URL 을 반환합니다.
        Returns:
            [{"index": 0, "title": "...", "url": "..."}, ...]
        """
        tabs_info = []
        tabs = self.page.get_tabs()  # [FIX] self.page → self._active

        for idx, tab in enumerate(tabs):
            try:
                title = tab.title
                url   = tab.url
            except Exception as e:
                title = f"(읽기 오류: {e})"
                url   = ""
            tabs_info.append({"index": idx, "title": title, "url": url})
            print(f"  탭[{idx}]  제목: {title}  URL: {url}")

        return tabs_info

    def click_by_text(self, input_text):
        text_element = self.page.ele(f'text:{input_text}')
        text_element.click()

    def click_by_text_in_iframe(self, target_text, iframe_id, search_in_iframe=True, wait_time=1):
        """
        특정 텍스트를 찾아서 클릭

        Args:
            target_text    : 찾을 텍스트
            iframe_id      : iframe ID (iframe 내부를 검색할 경우)
            search_in_iframe: iframe 내부를 검색할지 여부
            wait_time      : 클릭 후 대기 시간
        """
        try:
            if search_in_iframe:
                print(f"1. iframe 찾기: {iframe_id}")
                context = self.page.ele(f'@id={iframe_id}', timeout=0.5)
                if not context:
                    print(f"iframe을 찾을 수 없음, 메인 페이지에서 검색...")
                    context = self.page
            else:
                context = self.page

            print(f"2. 텍스트 검색: '{target_text}'")

            try:
                element = context.ele(f'text={target_text}', timeout=1)
                if element:
                    print(f"찾음 (정확한 매칭)")
                    element.click()
                    print("클릭 완료")
                    time.sleep(wait_time)
                    return True
            except Exception as e:
                print(f"방법 1 실패: {e}")

            # [FIX] 방법 1 실패 시 명시적으로 False 반환
            print(f"✗ '{target_text}' 클릭 실패")
            return False

        except Exception as e:
            print(f"오류: {e}")
            import traceback
            traceback.print_exc()
            return False

    def click_by_xpath(self, full_xpath):
        element = self.page.ele(f'xpath:{full_xpath}')
        try:
            element.click(by_js=True)
        except:
            element.click()

    def click_by_id(self, element_id):
        element = self.page.ele(f'#{element_id}')
        if element:
            if element.states.is_displayed:
                try:
                    element.click(by_js=True)
                    return True
                except Exception as e:
                    print(f"ID [{element_id}] 클릭 중 에러가 발생했습니다: {e}")
        return False

    def click_by_full_xpath(self, tab_name, xpath, wait_before_click=0.5, wait_after_click=0.5):
        """
        Full XPath로 요소를 찾아서 클릭

        Args:
            tab_name        : 탭 식별값
            xpath           : 전체 XPath 경로 (예: /html/body/div[1]/div[2]/button)
            wait_before_click: 클릭 전 대기 시간 (초)
            wait_after_click : 클릭 후 대기 시간 (초)
        """
        self.check_page(tab_name)
        try:
            element = self.page.ele(f'xpath:{xpath}', timeout=10)

            try:
                tag  = element.tag
                text = element.text[:50] if element.text else ''
                print(f"요소 확인: <{tag}> '{text}'")
            except Exception:
                pass

            if wait_before_click > 0:
                time.sleep(wait_before_click)

            element.click()
            print(f"클릭 완료!")

            if wait_after_click > 0:
                time.sleep(wait_after_click)

            return True

        except Exception as e:
            print(f"오류 발생: {e}")
            import traceback
            traceback.print_exc()
            return False

    def click_by_full_path(self, full_xpath):
        self.click_by_xpath(full_xpath)

    def click_by_full_css_path(self, css_path: str, timeout: float = 5.0, scroll_to: bool = True) -> bool:
        """
        CSS 전체 경로(Full CSS Selector)로 요소를 찾아 클릭합니다.
        edge DevTools의 'Copy > Copy selector' 결과를 그대로 사용할 수 있습니다.

        Args:
            css_path : CSS 선택자 전체 경로
                       예: '#app > div.header > nav > ul > li:nth-child(2) > a'
            timeout  : 요소 대기 시간(초)
            scroll_to: 클릭 전 스크롤 여부
        """
        try:
            locator = f'css:{css_path}'
            element = self._active.ele(locator, timeout=timeout)  # [FIX] self.page → self._active

            if element is None:
                print(f"[CSS Path 클릭 실패] 요소를 찾지 못했습니다: {css_path}")
                return False

            if scroll_to:
                element.scroll.to_see()
                time.sleep(0.3)

            element.click()
            print(f"[CSS Path 클릭 성공] {css_path}")
            return True

        except Exception as e:
            print(f"[CSS Path 클릭 오류] {css_path} → {e}")
            return False

    def click_by_class_name(self, class_name):
        element = self.page.eles(f'.{class_name}')
        print(len(element))
        element.click()

    def click_by_nth_class_name(self, class_name, index=1, timeout=3):
        """동일한 클래스를 가진 요소 중 N번째 요소를 클릭하는 함수"""
        elements = self.page.eles(f'.{class_name}', timeout=timeout)

        if not elements:
            print(f"'{class_name}' 클래스를 찾을 수 없습니다.")
            return False

        if len(elements) < index:
            print(f"'{class_name}' 클래스가 {len(elements)}개 밖에 없습니다. ({index}번째 클릭 불가)")
            return False

        elements[index - 1].click()
        print(f"'{class_name}' 클래스의 {index}번째 요소 클릭 성공!")
        return True

    def click_link_and_handle_warning(self, link_selector, wait_time=2):
        """
        링크 클릭 후 보안 경고 자동 처리

        Args:
            link_selector: 클릭할 링크의 선택자
            wait_time    : 경고 팝업 대기 시간 (초)
        """
        try:
            initial_page_count = len(self.page.tabs)
            print(f"현재 탭 수: {initial_page_count}")

            link = self.page.ele(link_selector, timeout=10)
            if not link:
                print(f"링크를 찾을 수 없음: {link_selector}")
                return False

            print(f"✓ 링크 발견, 클릭 중...")
            link.click()
            time.sleep(wait_time)

            current_page_count = len(self.page.tabs)
            print(f"현재 탭 수: {current_page_count}")

            if current_page_count > initial_page_count:
                print("✓ 새 탭이 생성됨")
                self.select_page_as_latest_page()
                time.sleep(0.5)
            else:
                print("새 탭 생성 안됨 (같은 탭에서 열림)")

            self.handle_security_warning(timeout=3)
            return True

        except Exception as e:
            print(f"링크 클릭 중 오류: {e}")
            import traceback
            traceback.print_exc()
            return False

    def safe_click(self, selector, handle_warning=True, wait_time=2):
        """
        안전하게 요소를 클릭하고 보안 경고를 자동 처리

        Args:
            selector      : 클릭할 요소의 선택자
            handle_warning: 보안 경고 자동 처리 여부 (현재 항상 처리)
            wait_time     : 대기 시간
        """
        return self.click_link_and_handle_warning(selector, wait_time)

    def close_all_popups_1(self):
        """
        현재 작업 중인 화면(메인 탭)을 제외한 모든 팝업창(새 탭/새 창)을 닫습니다.
        """
        main_page_id = self.page.tab_id
        all_page_ids = self.page.tab_ids
        closed_count = 0

        for t_id in all_page_ids:
            if t_id != main_page_id:
                self.page.close_pages(t_id)
                closed_count += 1

        self.page.get_page(main_page_id)
        print(f"불필요한 팝업(새 창/탭) {closed_count}개를 닫았습니다.")
        return closed_count

    def close_all_popups(self, accept: bool = True) -> int:
        """
        현재 열려 있는 모든 브라우저 팝업(alert / confirm / prompt)을 닫습니다.
        """
        closed = 0
        for _ in range(20):
            try:
                alert = self._active.handle_alert(accept=accept, timeout=0.5)  # [FIX] self.page → self._active
                if alert is None:
                    break
                print(f"[팝업 닫기] 텍스트: '{alert}'  accept={accept}")
                closed += 1
            except Exception:
                break

        if len(self.page.get_tabs()) > 1:  # [FIX] self.page → self._active
            for tab in self.page.get_tabs()[1:]:
                try:
                    tab.close()
                    closed += 1
                    print("[팝업 탭 닫기] 추가 탭 제거")
                except Exception:
                    pass

        print(f"[팝업 닫기 완료] 총 {closed}개 처리")
        return closed

    def close_layer_popups(self):
        """
        페이지 내부에 떠 있는 레이어 팝업(광고, 공지사항 등)을 강제로 찾아 닫습니다.
        """
        close_keywords = [
            'text=오늘 하루 보지 않기',
            'text=다시 보지 않기',
            'text=일주일간 보지 않기',
            'text=닫기',
            '@aria-label=Close',
            '.close',
            '.btn_close',
        ]

        closed_count = 0

        for keyword in close_keywords:
            elements = self.page.eles(keyword)
            for ele in elements:
                if ele.states.is_displayed:
                    try:
                        ele.click(by_js=True)
                        closed_count += 1
                        time.sleep(0.2)  # [FIX] self.page.wait(0.2) → time.sleep(0.2) (DrissionPage API 불일치 수정)
                    except Exception:
                        pass

        if closed_count > 0:
            print(f"화면을 가리는 내부 레이어 팝업 {closed_count}개를 찾아 닫았습니다.")

        return closed_count

    def handle_security_warning(self, timeout=5):
        """보안 경고 팝업이 나타나면 자동으로 '무시하고 보내기' 버튼 클릭"""
        try:
            print("보안 경고 확인 중...")
            selectors = [
                "t:무시하고 보내기",
                "text=무시하고 보내기",
                "xpath://button[contains(text(), '무시하고 보내기')]",
                "xpath://input[contains(@value, '무시하고 보내기')]",
                "xpath://*[contains(text(), '무시하고 보내기')]",
                "css:button:contains('무시하고 보내기')",
            ]

            for selector in selectors:
                try:
                    button = self.page.ele(selector, timeout=timeout)
                    if button:
                        print(f"✓ 버튼 발견: {selector}")
                        button.click()
                        print("✓ '무시하고 보내기' 버튼 클릭 완료")
                        time.sleep(0.5)
                        return True
                except Exception:
                    continue

            print("'무시하고 보내기' 버튼을 찾을 수 없음")
            return False

        except Exception as e:
            print(f"오류 발생: {e}")
            return False

    def select_option_by_id_and_index(self, select_id, option_index):
        """
        ID로 select 요소를 찾아서 인덱스로 옵션 선택

        Args:
            select_id   : select 요소의 id 속성값
            option_index: 선택할 옵션의 인덱스 (1부터 시작)

        Returns:
            bool: 성공 여부
        """
        try:
            print(f"select 요소 찾는 중... (id: {select_id})")
            select_element = self.page.ele(f'#{select_id}', timeout=5)

            if not select_element:
                print(f"select 요소를 찾을 수 없음 (id: {select_id})")
                return False

            print(f"✓ select 요소 발견!")
            select_element.select(option_index)
            print(f"옵션 선택 완료: {option_index}번째 항목")
            return True

        except Exception as e:
            print(f"오류 발생: {e}")
            import traceback
            traceback.print_exc()
            return False

    def select_option_by_id_and_index_advanced(self, tab_name, select_id, option_index):
        """
        ID로 select 요소를 찾아서 인덱스로 옵션 선택 (고급 버전 - 여러 방법 시도)

        Args:
            tab_name    : 탭 식별값
            select_id   : select 요소의 id 속성값
            option_index: 선택할 옵션의 인덱스 (1부터 시작)

        Returns:
            bool: 성공 여부
        """
        self.check_page(tab_name)
        try:
            print(f"select 요소 찾는 중... (id: {select_id})")
            select_element = self.page.ele(f'#{select_id}', timeout=5)

            if not select_element:
                print(f"select 요소를 찾을 수 없음 (id: {select_id})")
                return False

            print(f"✓ select 요소 발견!")

            options = select_element.eles('tag:option')
            print(f"옵션 개수: {len(options)}")

            for i, opt in enumerate(options, 1):
                try:
                    text  = opt.text
                    value = opt.attr('value')
                    print(f"  {i}. text: '{text}', value: '{value}'")
                except Exception:
                    pass

            if option_index < 1 or option_index > len(options):
                print(f"잘못된 인덱스: {option_index} (1~{len(options)} 범위)")
                return False

            try:
                print(f"\n[방법 1] select() 메서드 사용...")
                select_element.select(option_index)
                print(f"  성공!")
                return True
            except Exception as e1:
                print(f"  실패: {e1}")

            try:
                print(f"\n[방법 2] option 직접 클릭...")
                target_option = options[option_index - 1]
                target_option.click()
                print(f"  성공!")
                return True
            except Exception as e2:
                print(f"  실패: {e2}")

            try:
                print(f"\n[방법 3] JavaScript 사용...")
                js_code = f"""
                    var select = document.getElementById('{select_id}');
                    select.selectedIndex = {option_index - 1};
                    select.dispatchEvent(new Event('change', {{ bubbles: true }}));
                """
                self.page.run_js(js_code)
                print(f"  성공!")
                return True
            except Exception as e3:
                print(f"  실패: {e3}")

            try:
                print(f"\n[방법 4] value로 선택...")
                target_option = options[option_index - 1]
                value = target_option.attr('value')
                select_element.select(value)
                print(f"  성공!")
                return True
            except Exception as e4:
                print(f"  실패: {e4}")

            print("\n모든 방법 실패")
            return False

        except Exception as e:
            print(f"오류 발생: {e}")
            import traceback
            traceback.print_exc()
            return False

    def get_html_code_by_url(self, url):
        try:
            self.page.get(url)
            html_code = self.page.html
            return html_code
        except Exception as e:
            print(f"에러 발생: {e}")
            return None

    def get_page_list_by_html_code(self, html_string):
        """
        HTML 문자열에서 모든 테이블을 추출하여 3차원 리스트로 반환.
        convert_charrefs=True 설정으로 HTML 파서가 이미 엔티티를 처리하므로
        html.unescape() 이중 호출 불필요.
        """
        parser = TableParser()
        parser.feed(html_string)
        return parser.tables

    def get_all_page_by_url(self, url, wait, include_header_tf=True):
        """
        주어진 URL 페이지의 모든 <table> 을 파싱하여 3차원 리스트로 반환합니다.

        구조:
            result[테이블 인덱스][행 인덱스][열 인덱스] = 셀 텍스트

        Args:
            url             : 파싱할 페이지 URL
            wait            : 페이지 로드 후 대기 시간(초)
            include_header_tf: True 이면 <thead> 포함, False 이면 제외

        Returns:
            list[list[list[str]]]
        """
        self.page.get(url)
        time.sleep(wait)

        incl = "true" if include_header_tf else "false"
        js = f"""
        (() => {{
            const tables   = document.querySelectorAll('table');
            const result   = [];
            const inclHead = {incl};

            tables.forEach(table => {{
                const rows2d = [];
                const trList = inclHead
                    ? table.querySelectorAll('tr')
                    : table.querySelectorAll('tbody tr');

                trList.forEach(tr => {{
                    const cells = [];
                    tr.querySelectorAll('th, td').forEach(cell => {{
                        cells.push(cell.innerText.trim());
                    }});
                    if (cells.length > 0) rows2d.push(cells);
                }});

                if (rows2d.length > 0) result.push(rows2d);
            }});

            return result;
        }})()
        """

        tables_3d: list[list[list[str]]] = self.page.run_js(js) or []

        print(f"[테이블 추출] URL: {url}")
        print(f"  → 총 {len(tables_3d)}개 테이블 발견")
        for i, table in enumerate(tables_3d):
            print(f"  테이블[{i}]: {len(table)}행 × {max(len(r) for r in table) if table else 0}열")

        return tables_3d

    def get_text_by_copy_action(self, url):
        """URL 접속 후 Ctrl+A로 전체 선택하여 텍스트 데이터를 가져옵니다."""
        try:
            self.page.get(url)
            self.page.wait.load_start()
            self.page.actions.key_down('control').type('a').key_up('control')
            selected_text = self.page.ele('tag:body').text
            return selected_text
        except Exception as e:
            print(f"오류 발생: {e}")
            return None

    def get_text(self, tab_name, selector):
        """원하는 요소의 텍스트 가져오기"""
        self.check_page(tab_name)
        element = self.page.ele(selector)
        if element:
            return element.text
        else:
            return "값을 찾을 수 없습니다."

    def get_mouse_curser_position(self, monitor_width: int = 1920) -> dict:
        """
        현재 마우스 커서 위치를 두 모니터 기준으로 반환합니다.
        의존 패키지: pip install pyautogui
        """
        try:
            import pyautogui
        except ImportError:
            raise ImportError("pyautogui 가 필요합니다: pip install pyautogui")

        x, y = pyautogui.position()
        monitor = 1 if x < monitor_width else 2
        local_x = x if monitor == 1 else x - monitor_width

        info = {"x": x, "y": y, "monitor": monitor, "local_x": local_x, "local_y": y}
        print(f"[마우스 위치] 절대({x}, {y})  →  모니터 {monitor}번  로컬({local_x}, {y})")
        return info

    def get_caret_position(self, monitor_width: int = 1920) -> dict:
        """
        현재 포커스된 input/textarea 요소에서 텍스트 캐럿(|) 위치를 스크린 좌표로 반환합니다.
        포커스된 입력 요소가 없으면 None 반환.
        """
        js = """
        (() => {
            const el = document.activeElement;
            if (!el || (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA')) {
                return null;
            }

            const idx = el.selectionStart ?? 0;

            let vx = 0, vy = 0;
            try {
                const mirror = document.createElement('span');
                const computed = window.getComputedStyle(el);

                ['font', 'fontSize', 'fontFamily', 'fontWeight',
                 'letterSpacing', 'textTransform', 'padding',
                 'border', 'boxSizing'].forEach(p => {
                    mirror.style[p] = computed[p];
                });
                mirror.style.position   = 'absolute';
                mirror.style.visibility = 'hidden';
                mirror.style.whiteSpace = 'pre';
                mirror.textContent = el.value.substring(0, idx) || '\u200b';
                document.body.appendChild(mirror);

                const eRect = el.getBoundingClientRect();
                vx = eRect.left + mirror.scrollWidth;
                vy = eRect.top  + eRect.height / 2;

                document.body.removeChild(mirror);
            } catch(e) {
                const r = el.getBoundingClientRect();
                vx = r.left; vy = r.top;
            }

            return {
                tag        : el.tagName,
                caretIndex : idx,
                viewportX  : Math.round(vx),
                viewportY  : Math.round(vy),
                screenX    : Math.round(vx + window.screenX + window.outerWidth  - window.innerWidth),
                screenY    : Math.round(vy + window.screenY + window.outerHeight - window.innerHeight),
            };
        })()
        """

        result = self._active.run_js(js)  # [FIX] self.page → self._active
        if result is None:
            print("[캐럿 위치] 포커스된 input/textarea 요소가 없습니다.")
            return None

        sx, sy = result["screenX"], result["screenY"]
        monitor = 1 if sx < monitor_width else 2
        local_x = sx if monitor == 1 else sx - monitor_width

        info = {
            "element_tag": result["tag"],
            "caret_index": result["caretIndex"],
            "viewport_x":  result["viewportX"],
            "viewport_y":  result["viewportY"],
            "screen_x": sx,
            "screen_y": sy,
            "monitor":  monitor,
            "local_x":  local_x,
            "local_y":  sy,
        }
        print(
            f"[캐럿 위치] 태그={info['element_tag']}  "
            f"인덱스={info['caret_index']}  "
            f"스크린({sx}, {sy})  →  모니터 {monitor}번  로컬({local_x}, {sy})"
        )
        return info

    def run_js_on_visible_page(self, js_code):
        """현재 화면에 보이는 탭에서 JavaScript 실행"""
        self.select_page_as_visible_page()
        result = self.page.run_js(js_code)
        return result

    def get_page_data_by_xpath_v2(self, xpath, tab_name=None):
        # DrissionPage의 요소 메서드를 사용한 추출

        if tab_name:
            self.check_page(tab_name)
        try:
            # XPath로 테이블 요소 찾기
            table = self.page.ele(f"xpath:{xpath}")
            if not table:
                print(f"테이블을 찾을 수 없습니다: {xpath}")
                return []
            result =[]

            #모든 행 찾기
            rows = table.eles("tag:tr")
            print(f"{len(rows)}개 행 발견")
            for row_icx, row in enumerate(rows):
                row_data =[]
                #각 행의 셀 찾기 (th, td 모두)
                cells = row.eles("tag:td")
                for cell in cells:
                    # 텍스트 추출
                    text =cell.text.strip0 if cell.text else ''
                    row_data.append(text)
                if row_data: #빈 행이 아니면 추가
                    result.append(row_data)
            print(f"x 데이터 추출 완료: {len(result)}행")
            return result
        except Exception as e:
            print(f"오류 발생: {e}")
            return []

    def select_option_by_class_and_index(self, select_class, option_index):
        # class로 select 요소를 찾아서 인덱스로 옵션 선택
        try:
            select_element = self.page.ele(f".{select_class}", timeout=5)

            if not select_element:
                print(f"select 요소를 찾을 수 없음 (class:{select_class})")
                return False

            select_element.select(option_index)
            print(f'옵션 선택 완료 : {option_index}번째 항목')
            return True
        except Exception as e:
            print(f"오류 발생: {e}")
            return False

    def select_option_by_name_and_index(self, select_name, option_index):
        # name으로 select 요소를 찾아서 인덱스로 옵션 선택
        try:
            select_element = self.page.ele(f"@name={select_name}", timeout=5)

            if not select_element:
                print(f"select 요소를 찾을 수 없음 (name:{select_name})")
                return False

            select_element.select(option_index)
            print(f'옵션 선택 완료 : {option_index}번째 항목')
            return True
        except Exception as e:
            print(f"오류 발생: {e}")
            return False

    def get_quotation_data(self):
        l2d = [
            ["c_1_0", "c_1_7", "c_1_8", "c_1_10", "c_1_13", "c_1_14"],
            ["c_2_0", "c_2_7", "c_2_8", "c_2_10", "c_2_13", "c_2_14"],
            ["c_3_0", "c_3_7", "c_3_8", "c_3_10", "c_3_13", "c_3_14"],
            ["c_4_0", "c_4_7", "c_4_8", "c_4_10", "c_4_13", "c_4_14"],
            ["c_5_0", "c_5_7", "c_5_8", "c_5_10", "c_5_13", "c_5_14"],
            ["c_6_0", "c_6_7", "c_6_8", "c_6_10", "c_6_13", "c_6_14"],
            ["c_7_0", "c_7_7", "c_7_8", "c_7_10", "c_7_13", "c_7_14"],
            ["c_8_0", "c_8_7", "c_8_8", "c_8_10", "c_8_13", "c_8_14"],
            ["c_9_0", "c_9_7", "c_9_8", "c_9_10", "c_9_13", "c_9_14"],
        ]

        result_l2d = []
        for l1d in l2d:
            temp_l1d = []
            for id in l1d:
                many = self.get_data_by_id(id)
                if many:
                    temp_l1d.append(many[-1])
                else:
                    temp_l1d.append(None)
            if temp_l1d[-1] in ["Y", "N"]:
                result_l2d.append(temp_l1d)
            else:
                return result_l2d
        return result_l2d

    def get_data_by_id(self, element_id):
        result = []
        targets = self.page.eles(f'#{element_id}')
        for target in targets:
            #value = target.text
            #tab_name = target.parent().attr('class')  # 임시 적용 (실제 사이트에 맞게 수정 필요)
            #is_active = target.states.is_displayed
            result.append(target.text)
        return result

    def drop_file_to_element(self, file_path, target_locator):
        try:
            # 0. 🚨 가장 중요한 부분: 실제 파일이 존재하는지 먼저 확인합니다.
            if not os.path.exists(file_path):
                print(f"❌ 오류: 파일을 찾을 수 없습니다. 경로를 다시 확인해 주세요!\n입력된 경로: {file_path}")
                return False

            # 1. 파이썬(DrissionPage) 단에서 먼저 타겟 요소를 찾습니다.
            target_ele = self.page.ele(target_locator)
            if not target_ele:
                print("❌ 오류: 타겟 요소를 찾을 수 없습니다. XPath나 선택자를 확인하세요.")
                return False

            # 2. 페이지에 임시로 가짜 파일 입력창 생성
            # (display: none 대신 화면 밖으로 밀어내어 브라우저 보안 우회)
            js_create_input = """
            let oldInput = document.getElementById('fake_drop_input');
            if (oldInput) oldInput.remove();

            let input = document.createElement('input');
            input.type = 'file';
            input.id = 'fake_drop_input';
            // display: none; 대신 아래 방식을 써서 브라우저가 인식하도록 만듦
            input.style.position = 'absolute';
            input.style.top = '-9999px'; 
            input.style.left = '-9999px';
            document.body.appendChild(input);
            """
            self.page.run_js(js_create_input)
            time.sleep(0.2)  # DOM 생성 대기

            # 3. DrissionPage를 이용해 가짜 입력창에 실제 파일 경로 입력
            self.page.ele('#fake_drop_input').input(file_path)
            time.sleep(1.0)  # ⏳ 브라우저가 파일을 인식하고 메모리에 올릴 충분한 시간 (0.5 -> 1.0초로 늘림)

            # 4. 가짜 입력창의 파일을 가져와 타겟 요소에 Drop 이벤트 발생
            js_trigger_drop = """
            const targetElement = this; 
            const fakeInput = document.getElementById('fake_drop_input');

            if (!fakeInput || fakeInput.files.length === 0) {
                return "error: 파일이 정상적으로 입력되지 않았습니다.";
            }

            // 마우스로 파일을 잡고 있는 상태(DataTransfer)를 가짜로 만듦
            const dataTransfer = new DataTransfer();
            dataTransfer.items.add(fakeInput.files[0]);

            // 드래그 앤 드롭 이벤트 연속 발생 (진입 -> 위에 머뭄 -> 놓음)
            const events = ['dragenter', 'dragover', 'drop'];
            events.forEach(eventName => {
                const event = new DragEvent(eventName, {
                    bubbles: true,
                    cancelable: true,
                    dataTransfer: dataTransfer
                });
                targetElement.dispatchEvent(event);
            });

            // 작업 끝난 가짜 요소 삭제
            fakeInput.remove();
            return "success";
            """

            # JS 실행
            result = target_ele.run_js(js_trigger_drop)

            if result == "success":
                return True
            else:
                print(f"❌ 드롭 실패 원인: {result}")
                return False

        except Exception as e:
            print(f"❌ 함수 실행 중 오류 발생: {e}")
            return False

    def read_by_full_xpath(self, full_xpath):
        target = self.page.eles(f'xpath:{full_xpath}')
        print(len(target))

        return target[-1].text

    def read_by_class_name(self, class_name):
        target = self.page.eles(f'.{class_name}')
        print(len(target))

        return target[-1].text

    def get_readonly_text(self, input_text=None):
        """
        클래스 이름이 "dhxform_textarea dhxform_readonly"인 요소의 텍스트(value)를 가져오는 함수
        :return: 요소안의 텍스트 (요소가 없으면 None 반환)
        """
        # 1. 클래스가 정확히 일치하는 요소를 찾습니다.
        # 태그가 input인지 textarea인지 확실치 않다면 태그명 없이 속성만으로 찾을 수 있습니다.
        locator = '@class=dhxform_textarea dhxform_readonly'
        if input_text:
            locator = input_text

        # 2. 요소를 찾습니다.
        element = self.page.ele(locator)

        # 3. 요소가 존재한다면 텍스트(value)를 반환합니다.
        if element:
            # input이나 textarea의 텍스트는 .value로 가져옵니다.
            return element.value
        else:
            print("해당 요소를 찾을 수 없습니다.")
            return None

    def read_text_in_selector(self, selector, input_value):
        """
        선택자 종류와 입력값을 바탕으로 요소를 찾고,
        태그의 종류에 따라 자동으로 text 또는 value를 추출하는 만능 함수

        :param selector: 선택자 종류 ("xpath", "full_xpath", "class_name", "id", "name", "css" 등)
        :param input_value: 선택자의 실제 값 (예: '//*[@id="main"]', 'my-class' 등)
        :return: 추출된 텍스트 또는 값 (요소가 없으면 None)
        """

        # 1. 입력받은 selector를 DrissionPage의 문법(Locator)으로 변환
        selector = selector.lower().strip()

        if selector in ['xpath', 'full_xpath']:
            locator = f"xpath:{input_value}"
        elif selector == 'id':
            locator = f"#{input_value}"
        elif selector in ['class', 'class_name']:
            # 클래스명이 띄어쓰기를 포함해 정확히 일치해야 하는 경우를 위해 @class 사용
            locator = f"@class={input_value}"
        elif selector == 'name':
            locator = f"@name={input_value}"
        elif selector == 'css':
            locator = f"css:{input_value}"
        else:
            # 알 수 없는 selector인 경우 DrissionPage의 자동 판별에 맡김
            locator = input_value

        # 2. 요소 찾기
        element = self.page.ele(locator)

        # 요소를 찾지 못한 경우
        if not element:
            print(f"[경고] 요소를 찾을 수 없습니다: {selector} = {input_value}")
            return None

        # 3. 태그 종류에 따라 '알아서' 값 추출하기
        tag_name = element.tag.lower()

        # Case A: 값을 입력받는 태그들 (input, textarea, select) -> .value 사용
        if tag_name in ['input', 'textarea', 'select']:
            return element.value

        # Case B: 이미지 태그 (img) -> 대체 텍스트(alt) 사용
        elif tag_name == 'img':
            return element.attr('alt') or ""

        # Case C: 그 외 일반적인 태그들 (div, span, p, a, h1 등) -> .text 사용
        else:
            text_content = element.text

            # [예외 처리] 일반 태그인데 .text가 비어있고, value 속성이 존재하는 특이한 경우
            if not text_content and element.attr('value'):
                return element.attr('value')

            # [예외 처리] 텍스트가 완전히 숨겨져 있어서 .text로 안 잡히는 경우 innerHTML에서 텍스트만 추출할지 결정
            # 기본적으로는 DrissionPage의 .text를 반환
            return text_content

    def get_html_code_for_current_page(self):
        try:
            html_code = self.page.html
            return html_code
        except Exception as e:
            print(f"에러 발생: {e}")
            return None

    def download_attachments(self, save_folder):
        """
        현재 페이지에서 'PopListSingleForm' 자바스크립트가 걸린 첨부파일을
        모두 찾아 지정된 폴더에 다운로드하는 함수
        """

        # 1. 저장할 폴더가 없으면 생성
        if not os.path.exists(save_folder):
            os.makedirs(save_folder)

        # 2. DrissionPage의 기본 다운로드 경로를 지정한 폴더로 변경
        self.page.set.download_path(save_folder)

        # 3. 첨부파일 링크 찾기
        # DrissionPage 문법: <a> 태그 중 href 속성에 'PopListSingleForm'이 포함된 모든 요소를 찾음
        attachments = self.page.eles('tag:a@@href:PopListSingleForm')

        if not attachments:
            print("현재 페이지에 다운로드할 첨부파일이 없습니다.")
            return

        print(f"총 {len(attachments)}개의 첨부파일을 발견했습니다. 다운로드를 시작합니다...")

        # 4. 발견된 첨부파일들을 순회하며 클릭 (다운로드 실행)
        for i, attachment in enumerate(attachments, 1):
            file_name = attachment.text  # 링크의 텍스트(예: 진공 이송 CONTROLLER.png) 가져오기
            print(f"[{i}/{len(attachments)}] 다운로드 요청: {file_name}")

            # 링크 클릭 (자바스크립트가 실행되며 다운로드가 시작됨)
            attachment.click()

            # 서버에 무리를 주지 않기 위해 클릭 사이에 약간의 대기 (선택 사항)
            self.page.wait(1)

            # 5. [중요]: 모든 다운로드가 완전히 끝날 때까지 대기
        # 이 코드가 없으면 대용량 파일(13MB 등)이 다운로드 되기 전에 프로그램이 종료될 수 있습니다.
        print("다운로드가 완료될 때까지 대기 중...")
        self.page.wait.downloads_done()

        print(f"모든 파일이 '{save_folder}' 폴더에 성공적으로 저장되었습니다!")

    def print_as_pdf(self, save_path: str):
        """
        현재 페이지의 전체 높이를 계산하여 잘림 없이 1장의 PDF로 저장하는 함수
        """

        import base64

        # 1. 자바스크립트를 실행하여 페이지의 실제 전체 너비와 높이를 픽셀(px)로 가져옵니다.
        # 내용이 가장 긴 부분의 높이를 안전하게 가져옵니다.
        width_px = self.page.run_js('return Math.max(document.body.scrollWidth, document.documentElement.scrollWidth);')
        height_px = self.page.run_js('return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);')

        # 2. 웹 브라우저의 기본 해상도(96 DPI)를 기준으로 픽셀(px)을 인치(inch)로 변환합니다.
        # 여백 없이 깔끔하게 담기 위해 약간의 여유(예: +0.2)를 줄 수도 있지만 기본 변환만으로도 충분합니다.
        paper_width = width_px / 96.0
        paper_height = height_px / 96.0

        # 3. 크롬 CDP에 맞춤형 용지 크기(인치)를 전달하여 PDF 생성
        pdf_data = self.page.run_cdp(
            'Page.printToPDF',
            printBackground=True,  # 배경색 유지
            displayHeaderFooter=False,  # 머리글/바닥글 제거
            paperWidth=paper_width,  # 계산된 전체 너비 적용
            paperHeight=paper_height,  # 계산된 전체 높이 적용 (핵심!)
            marginTop=0,  # 상하좌우 여백을 0으로 설정하여 잘림 방지
            marginBottom=0,
            marginLeft=0,
            marginRight=0
        )

        # 4. Base64 디코딩 및 파일 저장
        pdf_base64 = pdf_data.get('data')

        if pdf_base64:
            with open(save_path, 'wb') as f:
                f.write(base64.b64decode(pdf_base64))
            print(f"✅ 1장짜리 PDF 저장 성공: {save_path}")
        else:
            print("❌ PDF 데이터를 생성하지 못했습니다.")



# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  ResultWrapper 지원
#  · xy.excel.some_method().to("변수명")  으로 결과 저장
#  · 기존 방식 result = xy.excel.some_method() 도 100% 동일 작동
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    _result_ns: dict = {}
    _use_caller_globals: bool = True

    def set_namespace(self, ns: dict, use_caller: bool = False) -> None:
        """
        .to() 가 값을 저장할 네임스페이스를 지정합니다.
        기본값은 호출자의 globals() 를 자동 감지합니다.

        Examples:
            xy.excel.set_namespace(globals())
        """
        xy_edge._result_ns          = ns
        xy_edge._use_caller_globals = use_caller

    def __getattribute__(self, name: str):
        """
        xy_edge 에 직접 정의된 public 메서드 호출 결과만 ResultWrapper 로 포장.

        래핑: 클래스 외부(사용자 코드)에서 호출한 경우
        통과: _로 시작하는 이름 / 인스턴스 속성 / 내부 self.xxx() 호출
        """
        import inspect, functools

        # _로 시작하는 내부/특수 이름은 즉시 통과
        if name.startswith('_'):
            return object.__getattribute__(self, name)

        obj = object.__getattribute__(self, name)

        # 클래스 __dict__ 에 직접 def 로 정의된 것만 래핑 후보
        # → 인스턴스 속성(xlapp 등)은 __dict__ 에 없으므로 그대로 반환
        cls = object.__getattribute__(self, '__class__')
        if name not in cls.__dict__:
            return obj

        raw_def = cls.__dict__[name]
        if not (inspect.isfunction(raw_def) or
                isinstance(raw_def, (classmethod, staticmethod))):
            return obj   # 클래스 변수(_result_ns 등) 통과

        # ── 핵심: 내부 self 호출(재귀)이면 래핑 안 함 ──────────
        # 호출자 프레임의 지역변수에 self 와 동일한 객체가 있으면
        # xy_edge 메서드 내부에서 self.xxx() 로 호출한 것
        caller_frame = inspect.currentframe().f_back
        if caller_frame is not None:
            if caller_frame.f_locals.get('self') is self:
                return obj

        # ── 외부 호출: ResultWrapper 로 포장 ───────────────────
        @functools.wraps(obj)
        def _wrapped(*args, **kwargs):
            raw = obj(*args, **kwargs)
            return ResultWrapper(raw, name)

        return _wrapped

    def write_by_xpath(self, tab_name, input_full_xpath, input_text, enter_tf=False):
        self.check_page(tab_name)
        element = self.page.ele(f'xpath:{input_full_xpath}')
        element.input(input_text, clear=True)
        if enter_tf:
            element.input('\n')  # [FIX] element.click() → Enter 키 입력으로 수정

    def write_by_id(self, tab_name, input_id, input_text, enter_tf=False):
        self.check_page(tab_name)
        element = self.page.ele(f'#{input_id}')
        element.input(input_text, clear=True)
        if enter_tf:
            element.input('\n')  # [FIX] element.click() → Enter 키 입력으로 수정


class ResultWrapper:
    """
    xy_edge 메서드 반환값 래퍼.
    · result = xy.excel.some_func()          # 기존 방식 그대로
    · xy.excel.some_func().to("result")      # 새 방식: 변수에 자동 저장
    · xy.excel.some_func().to("a").to("b")   # 체이닝
    · wrapped.value                          # 원본값 직접 접근
    """
    __slots__ = ("_value", "_method_name")

    def __init__(self, value, method_name: str = ""):
        object.__setattr__(self, "_value",       value)
        object.__setattr__(self, "_method_name", method_name)

    def to(self, var_name: str, ns: dict | None = None) -> "ResultWrapper":
        import inspect

        if ns is not None:
            target = ns
        elif xy_edge._use_caller_globals and not xy_edge._result_ns:
            frame  = inspect.stack()[1].frame
            target = frame.f_globals
        else:
            target = xy_edge._result_ns
        target[var_name] = object.__getattribute__(self, "_value")
        return self

    @property
    def value(self):        return object.__getattribute__(self, "_value")
    def __repr__(self):
        v = object.__getattribute__(self, "_value")
        m = object.__getattribute__(self, "_method_name")
        return f"ResultWrapper({m!r} → {v!r})"

    def __str__(self):        return str(object.__getattribute__(self, "_value"))
    def _v(self):             return object.__getattribute__(self, "_value")
    def _u(self, other):      return other._v() if isinstance(other, ResultWrapper) else other
    def __eq__(self, other):  return self._v() == self._u(other)
    def __ne__(self, other):  return self._v() != self._u(other)
    def __lt__(self, other):  return self._v() <  self._u(other)
    def __le__(self, other):  return self._v() <= self._u(other)
    def __gt__(self, other):  return self._v() >  self._u(other)
    def __ge__(self, other):  return self._v() >= self._u(other)
    def __bool__(self):       return bool(object.__getattribute__(self, "_value"))
    def __len__(self):        return len(object.__getattribute__(self, "_value"))
    def __iter__(self):       return iter(object.__getattribute__(self, "_value"))
    def __getitem__(self, key):        return object.__getattribute__(self, "_value")[key]
    def __contains__(self, item):        return item in object.__getattribute__(self, "_value")
    def __add__(self, other):        return self._v() + self._u(other)
    def __radd__(self, other):        return other + self._v()

    def __hash__(self):
        try:    return hash(self._v())
        except: return id(self)

    # ── 속성/메서드를 내부 값으로 위임 (.split(), .upper() 등) ─
    def __getattr__(self, name: str):
        v = object.__getattribute__(self, "_value")
        return getattr(v, name)
