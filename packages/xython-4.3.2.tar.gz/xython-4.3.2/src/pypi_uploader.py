import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, filedialog
import threading
import subprocess
import os
import sys
import time
import re
import shutil
import queue
from pathlib import Path
from datetime import datetime

# ── 기본 경로 ────────────────────────────────────────────────────────────────
DEFAULT_PKG_ROOT = r"G:\my_code\xython"
LOG_Q = queue.Queue()

# ── PyCharm 실행파일 후보 경로 ───────────────────────────────────────────────
PYCHARM_CANDIDATES = [
    r"C:\Program Files\JetBrains\PyCharm Community Edition\bin\pycharm64.exe",
    r"C:\Program Files\JetBrains\PyCharm Professional Edition\bin\pycharm64.exe",
    r"C:\Program Files\JetBrains\PyCharm\bin\pycharm64.exe",
    r"C:\Program Files (x86)\JetBrains\PyCharm\bin\pycharm64.exe",
]


def find_pycharm() -> str:
    """설치된 PyCharm 경로를 자동으로 탐색. 없으면 빈 문자열."""
    for p in PYCHARM_CANDIDATES:
        if os.path.exists(p):
            return p
    # JetBrains Toolbox 경로도 탐색
    toolbox_base = os.path.expandvars(r"%LOCALAPPDATA%\JetBrains\Toolbox\apps")
    if os.path.exists(toolbox_base):
        for root, dirs, files in os.walk(toolbox_base):
            for f in files:
                if f.lower() == "pycharm64.exe":
                    return os.path.join(root, f)
    return ""


# ══════════════════════════════════════════════════════════════════════════════
# 유틸 함수
# ══════════════════════════════════════════════════════════════════════════════

def log(msg: str, tag: str = "info"):
    ts = datetime.now().strftime("%H:%M:%S")
    LOG_Q.put((f"[{ts}] {msg}", tag))


def open_in_pycharm(pycharm_exe: str, file_paths: list[str]):
    """변경된 파일들을 PyCharm 에서 열기"""
    if not pycharm_exe or not os.path.exists(pycharm_exe):
        log("PyCharm 경로가 설정되지 않았습니다. 설정에서 경로를 지정해주세요.", "warn")
        return
    for fp in file_paths:
        if os.path.exists(fp):
            try:
                subprocess.Popen(
                    [pycharm_exe, fp],
                    creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
                )
                log(f"PyCharm에서 열림: {Path(fp).name}", "ok")
            except Exception as e:
                log(f"PyCharm 열기 실패: {e}", "err")


def get_version(pkg_root: str) -> str:
    root = Path(pkg_root)
    for fname in ("pyproject.toml", "setup.py", "setup.cfg"):
        fpath = root / fname
        if not fpath.exists():
            continue
        text = fpath.read_text(encoding="utf-8")
        m = re.search(r'version\s*=\s*["\']([^"\']+)["\']', text)
        if m:
            return m.group(1)
    return "알 수 없음"


def bump_version(pkg_root: str, new_ver: str) -> bool:
    root = Path(pkg_root)
    for fname in ("pyproject.toml", "setup.py", "setup.cfg"):
        fpath = root / fname
        if not fpath.exists():
            continue
        text = fpath.read_text(encoding="utf-8")
        new_text = re.sub(
            r'(version\s*=\s*)["\']([^"\']+)["\']',
            lambda m: m.group(1) + f'"{new_ver}"',
            text, count=1
        )
        if new_text != text:
            fpath.write_text(new_text, encoding="utf-8")
            log(f"버전 업데이트: {fname} → {new_ver}", "ok")
            return True
    log("버전을 업데이트할 파일을 찾지 못했습니다.", "warn")
    return False


def run_cmd(cmd: list, cwd: str) -> bool:
    log("$ " + " ".join(cmd), "cmd")
    try:
        proc = subprocess.Popen(
            cmd, cwd=cwd,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
        )
        for line in proc.stdout:
            line = line.rstrip()
            if line:
                tag = "err" if any(w in line.lower() for w in ("error", "failed", "traceback")) else "info"
                log(line, tag)
        proc.wait()
        return proc.returncode == 0
    except FileNotFoundError as e:
        log(f"명령을 찾을 수 없습니다: {e}", "err")
        return False


# ══════════════════════════════════════════════════════════════════════════════
# 빌드 & 업로드
# ══════════════════════════════════════════════════════════════════════════════

def ensure_packages():
    """build / twine 이 없으면 자동으로 pip 설치"""
    import importlib
    for pkg, import_name in [("build", "build"), ("twine", "twine")]:
        try:
            importlib.import_module(import_name)
        except ImportError:
            log(f"{pkg} 패키지가 없습니다. 자동 설치 중...", "warn")
            ok = run_cmd([sys.executable, "-m", "pip", "install", pkg], cwd=".")
            if ok:
                log(f"{pkg} 설치 완료!", "ok")
            else:
                log(f"{pkg} 설치 실패 — cmd 에서 직접: pip install {pkg}", "err")
                return False
    return True


def do_upload(pkg_root: str, pypi_token: str, test_pypi: bool, new_ver: str | None, on_done):
    try:
        root = Path(pkg_root)
        if new_ver:
            bump_version(pkg_root, new_ver)

        dist_dir = root / "dist"
        if dist_dir.exists():
            shutil.rmtree(dist_dir)
            log("기존 dist/ 폴더 삭제", "warn")

        # ── STEP 0: 필요 패키지 자동 설치 ─────────────────────────────────────
        if not ensure_packages():
            on_done(False); return

        # ── STEP 1: 빌드 ───────────────────────────────────────────────────────
        log("━━━ STEP 1 : 패키지 빌드 ━━━", "ok")

        # 방법 A: python -m build (권장)
        ok = run_cmd([sys.executable, "-m", "build"], cwd=str(root))

        # 방법 B: build 가 __main__ 없을 때 직접 호출 (fallback)
        if not ok:
            log("build 직접 호출 방식으로 재시도...", "warn")
            ok = run_cmd(
                [sys.executable, "-c",
                 "import build, build.__main__; build.__main__.main()"],
                cwd=str(root)
            )

        # 방법 C: setup.py 가 있으면 레거시 방식 시도
        if not ok and (root / "setup.py").exists():
            log("setup.py 방식으로 재시도...", "warn")
            ok = run_cmd(
                [sys.executable, "setup.py", "sdist", "bdist_wheel"],
                cwd=str(root)
            )

        if not ok:
            log("빌드 실패! 아래 명령을 cmd 에서 직접 실행해보세요:", "err")
            log(f"  cd {root}", "err")
            log(f"  {sys.executable} -m pip install build", "err")
            log(f"  {sys.executable} -m build", "err")
            on_done(False); return

        # ── STEP 2: 업로드 ─────────────────────────────────────────────────────
        log("━━━ STEP 2 : PyPI 업로드 ━━━", "ok")
        repo_url = ("https://test.pypi.org/legacy/" if test_pypi
                    else "https://upload.pypi.org/legacy/")
        whl_files = list(dist_dir.glob("*.whl")) + list(dist_dir.glob("*.tar.gz"))
        if not whl_files:
            log("dist/ 에 빌드 결과물이 없습니다.", "err")
            on_done(False); return

        cmd = [
            sys.executable, "-m", "twine", "upload",
            "--repository-url", repo_url,
            "--username", "__token__",
            "--password", pypi_token,
        ] + [str(f) for f in whl_files]

        ok = run_cmd(cmd, cwd=str(root))
        log("━━━ 업로드 완료! ━━━" if ok else "업로드 실패.", "ok" if ok else "err")
        on_done(ok)

    except Exception as e:
        log(f"예외 발생: {e}", "err")
        on_done(False)


# ══════════════════════════════════════════════════════════════════════════════
# 파일 감시
# ══════════════════════════════════════════════════════════════════════════════

class SrcWatcher:
    def __init__(self, src_dir: str, callback):
        self.src_dir = Path(src_dir)
        self.callback = callback
        self._stop = threading.Event()
        self._snapshots: dict[str, float] = {}
        self._thread = threading.Thread(target=self._loop, daemon=True)

    def start(self):
        self._snapshots = self._snapshot()
        self._thread.start()
        log(f"파일 감시 시작: {self.src_dir}", "ok")

    def stop(self):
        self._stop.set()

    def _snapshot(self) -> dict:
        snap = {}
        if self.src_dir.exists():
            for f in self.src_dir.rglob("*.py"):
                snap[str(f)] = f.stat().st_mtime
        return snap

    def _loop(self):
        while not self._stop.is_set():
            time.sleep(2)
            new_snap = self._snapshot()
            changed = [k for k, v in new_snap.items() if self._snapshots.get(k) != v]
            added   = [k for k in new_snap if k not in self._snapshots]
            removed = [k for k in self._snapshots if k not in new_snap]
            if changed or added or removed:
                for f in changed: log(f"변경: {Path(f).name}", "warn")
                for f in added:   log(f"추가: {Path(f).name}", "warn")
                for f in removed: log(f"삭제: {Path(f).name}", "warn")
                self._snapshots = new_snap
                self.callback(changed + added)   # removed 파일은 열지 않음


# ══════════════════════════════════════════════════════════════════════════════
# GUI
# ══════════════════════════════════════════════════════════════════════════════

class PyPIUploaderApp(tk.Tk):
    COLOR = {
        "bg":      "#1a1a2e",
        "panel":   "#16213e",
        "card":    "#0f3460",
        "accent":  "#e94560",
        "accent2": "#53d8fb",
        "text":    "#eaeaea",
        "muted":   "#7a8ba0",
        "ok":      "#4ade80",
        "warn":    "#fbbf24",
        "err":     "#f87171",
        "cmd":     "#93c5fd",
    }

    def __init__(self):
        super().__init__()
        self.title("PyPI 자동 업로더  ─  xython")
        self.geometry("900x740")
        self.configure(bg=self.COLOR["bg"])
        self.resizable(True, True)

        self._watcher: SrcWatcher | None = None
        self._watching = False
        self._busy = False

        self._build_ui()
        self._poll_log()

        self._token_file = Path(__file__).parent / ".pypi_token"
        self._pycharm_file = Path(__file__).parent / ".pycharm_path"
        self._load_saved_token()
        self._load_saved_pycharm()

    # ── UI 구성 ────────────────────────────────────────────────────────────

    def _build_ui(self):
        C = self.COLOR

        # 헤더
        hdr = tk.Frame(self, bg=C["card"], height=56)
        hdr.pack(fill="x")
        tk.Label(hdr, text="⬆  PyPI 자동 업로더", font=("Consolas", 16, "bold"),
                 bg=C["card"], fg=C["accent2"]).pack(side="left", padx=20, pady=12)
        self._ver_lbl = tk.Label(hdr, text="ver: —", font=("Consolas", 11),
                                  bg=C["card"], fg=C["muted"])
        self._ver_lbl.pack(side="right", padx=20)

        # 패키지 루트
        row = tk.Frame(self, bg=C["bg"], pady=8)
        row.pack(fill="x", padx=16)
        tk.Label(row, text="패키지 루트:", bg=C["bg"], fg=C["muted"],
                 font=("Consolas", 10), width=12, anchor="w").pack(side="left")
        self._path_var = tk.StringVar(value=DEFAULT_PKG_ROOT)
        tk.Entry(row, textvariable=self._path_var, bg=C["panel"], fg=C["text"],
                 insertbackground=C["text"], font=("Consolas", 10),
                 relief="flat", bd=4, width=52).pack(side="left", padx=6)
        tk.Button(row, text="📁", bg=C["card"], fg=C["text"], relief="flat",
                  activebackground=C["accent"], cursor="hand2",
                  command=self._browse_root).pack(side="left")
        tk.Button(row, text="↺ 버전 새로고침", bg=C["card"], fg=C["accent2"],
                  relief="flat", font=("Consolas", 9), cursor="hand2",
                  activebackground=C["card"],
                  command=self._refresh_version).pack(side="left", padx=8)

        # ★ PyCharm 경로 설정 행
        pc_row = tk.Frame(self, bg=C["bg"], pady=4)
        pc_row.pack(fill="x", padx=16)
        tk.Label(pc_row, text="PyCharm 경로:", bg=C["bg"], fg=C["muted"],
                 font=("Consolas", 10), width=12, anchor="w").pack(side="left")
        self._pycharm_var = tk.StringVar()
        tk.Entry(pc_row, textvariable=self._pycharm_var, bg=C["panel"], fg=C["accent2"],
                 insertbackground=C["text"], font=("Consolas", 9),
                 relief="flat", bd=4, width=52).pack(side="left", padx=6)
        tk.Button(pc_row, text="📁", bg=C["card"], fg=C["text"], relief="flat",
                  activebackground=C["accent"], cursor="hand2",
                  command=self._browse_pycharm).pack(side="left")
        tk.Button(pc_row, text="🔍 자동탐색", bg=C["card"], fg=C["warn"],
                  relief="flat", font=("Consolas", 9), cursor="hand2",
                  activebackground=C["card"],
                  command=self._auto_find_pycharm).pack(side="left", padx=4)
        tk.Button(pc_row, text="💾 저장", bg=C["card"], fg=C["muted"],
                  relief="flat", font=("Consolas", 9), cursor="hand2",
                  activebackground=C["card"],
                  command=self._save_pycharm).pack(side="left", padx=4)

        # ★ PyCharm 자동열기 옵션
        pc_opt_row = tk.Frame(self, bg=C["bg"], pady=2)
        pc_opt_row.pack(fill="x", padx=16)
        self._open_pycharm_var = tk.BooleanVar(value=True)
        tk.Checkbutton(pc_opt_row,
                       text="파일 변경 감지 시 → PyCharm 에서 자동으로 열기",
                       variable=self._open_pycharm_var,
                       bg=C["bg"], fg=C["accent2"], selectcolor=C["panel"],
                       activebackground=C["bg"], font=("Consolas", 10),
                       cursor="hand2").pack(side="left")

        # 토큰
        tok_row = tk.Frame(self, bg=C["bg"], pady=4)
        tok_row.pack(fill="x", padx=16)
        tk.Label(tok_row, text="PyPI 토큰:   ", bg=C["bg"], fg=C["muted"],
                 font=("Consolas", 10), width=12, anchor="w").pack(side="left")
        self._token_var = tk.StringVar()
        self._token_entry = tk.Entry(tok_row, textvariable=self._token_var,
                                      bg=C["panel"], fg=C["text"],
                                      insertbackground=C["text"],
                                      font=("Consolas", 10), relief="flat", bd=4,
                                      width=52, show="•")
        self._token_entry.pack(side="left", padx=6)
        self._show_tok = False
        tk.Button(tok_row, text="👁", bg=C["card"], fg=C["text"], relief="flat",
                  cursor="hand2", activebackground=C["accent"],
                  command=self._toggle_token_vis).pack(side="left")
        tk.Button(tok_row, text="💾 저장", bg=C["card"], fg=C["warn"],
                  relief="flat", font=("Consolas", 9), cursor="hand2",
                  activebackground=C["card"],
                  command=self._save_token).pack(side="left", padx=8)

        # 버전 & Test PyPI
        opt_row = tk.Frame(self, bg=C["bg"], pady=6)
        opt_row.pack(fill="x", padx=16)
        tk.Label(opt_row, text="새 버전:      ", bg=C["bg"], fg=C["muted"],
                 font=("Consolas", 10), width=12, anchor="w").pack(side="left")
        self._newver_var = tk.StringVar()
        tk.Entry(opt_row, textvariable=self._newver_var, bg=C["panel"],
                 fg=C["accent2"], insertbackground=C["text"],
                 font=("Consolas", 10), relief="flat", bd=4, width=14).pack(side="left", padx=6)
        tk.Label(opt_row, text="(비워두면 현재 버전 유지)", bg=C["bg"],
                 fg=C["muted"], font=("Consolas", 9)).pack(side="left")
        self._testpypi_var = tk.BooleanVar(value=False)
        tk.Checkbutton(opt_row, text="Test PyPI 사용", variable=self._testpypi_var,
                       bg=C["bg"], fg=C["warn"], selectcolor=C["panel"],
                       activebackground=C["bg"], font=("Consolas", 10),
                       cursor="hand2").pack(side="left", padx=20)

        # 버튼 행
        btn_row = tk.Frame(self, bg=C["bg"], pady=8)
        btn_row.pack(fill="x", padx=16)
        self._watch_btn = tk.Button(
            btn_row, text="🔍 src/ 감시 시작", font=("Consolas", 11, "bold"),
            bg=C["card"], fg=C["accent2"], relief="flat", padx=16, pady=8,
            cursor="hand2", activebackground=C["accent"],
            command=self._toggle_watch)
        self._watch_btn.pack(side="left", padx=(0, 8))

        self._upload_btn = tk.Button(
            btn_row, text="⬆  지금 업로드", font=("Consolas", 11, "bold"),
            bg=C["accent"], fg="white", relief="flat", padx=20, pady=8,
            cursor="hand2", activebackground="#c73652",
            command=self._manual_upload)
        self._upload_btn.pack(side="left")

        # ★ PyCharm 에서 프로젝트 열기 버튼
        tk.Button(btn_row, text="🧠 PyCharm 열기", font=("Consolas", 10),
                  bg=C["card"], fg=C["ok"], relief="flat", padx=12, pady=8,
                  cursor="hand2", activebackground=C["card"],
                  command=self._open_project_in_pycharm).pack(side="left", padx=8)

        tk.Button(btn_row, text="🗑 로그 지우기", font=("Consolas", 9),
                  bg=C["panel"], fg=C["muted"], relief="flat", padx=10,
                  cursor="hand2", activebackground=C["card"],
                  command=self._clear_log).pack(side="right")

        # 상태 표시줄
        self._status_var = tk.StringVar(value="대기 중")
        tk.Label(self, textvariable=self._status_var, bg=C["card"],
                 fg=C["muted"], font=("Consolas", 9), anchor="w",
                 padx=12).pack(fill="x")

        # 로그 창
        self._log = scrolledtext.ScrolledText(
            self, bg="#0d0d1a", fg=C["text"], insertbackground=C["text"],
            font=("Consolas", 10), relief="flat", bd=0,
            state="disabled", wrap="word")
        self._log.pack(fill="both", expand=True, padx=12, pady=(4, 12))

        for tag, color in [("ok", C["ok"]), ("warn", C["warn"]),
                            ("err", C["err"]), ("cmd", C["cmd"]), ("info", C["text"])]:
            self._log.tag_configure(tag, foreground=color)

        self._refresh_version()

    # ── PyCharm 관련 ──────────────────────────────────────────────────────

    def _browse_pycharm(self):
        p = filedialog.askopenfilename(
            title="PyCharm 실행파일 선택",
            filetypes=[("실행파일", "*.exe"), ("모든 파일", "*.*")],
            initialdir=r"C:\Program Files\JetBrains"
        )
        if p:
            self._pycharm_var.set(p)

    def _auto_find_pycharm(self):
        found = find_pycharm()
        if found:
            self._pycharm_var.set(found)
            log(f"PyCharm 자동 탐색 성공: {found}", "ok")
        else:
            log("PyCharm을 자동으로 찾지 못했습니다. 직접 경로를 지정해주세요.", "warn")

    def _save_pycharm(self):
        p = self._pycharm_var.get().strip()
        if p:
            self._pycharm_file.write_text(p, encoding="utf-8")
            log("PyCharm 경로가 저장되었습니다.", "ok")

    def _load_saved_pycharm(self):
        if self._pycharm_file.exists():
            p = self._pycharm_file.read_text(encoding="utf-8").strip()
            self._pycharm_var.set(p)
            log(f"저장된 PyCharm 경로: {p}", "info")
        else:
            # 저장된 게 없으면 자동탐색 시도
            found = find_pycharm()
            if found:
                self._pycharm_var.set(found)
                log(f"PyCharm 자동 탐색: {found}", "ok")

    def _open_project_in_pycharm(self):
        """프로젝트 루트 폴더 자체를 PyCharm 에서 열기"""
        pycharm = self._pycharm_var.get().strip()
        pkg_root = self._path_var.get().strip()
        if not pycharm or not os.path.exists(pycharm):
            messagebox.showerror("오류", "PyCharm 경로가 올바르지 않습니다.")
            return
        try:
            subprocess.Popen(
                [pycharm, pkg_root],
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            )
            log(f"PyCharm 에서 프로젝트 열기: {pkg_root}", "ok")
        except Exception as e:
            log(f"PyCharm 열기 실패: {e}", "err")

    # ── 이벤트 핸들러 ──────────────────────────────────────────────────────

    def _browse_root(self):
        p = filedialog.askdirectory(initialdir=self._path_var.get())
        if p:
            self._path_var.set(p)
            self._refresh_version()

    def _refresh_version(self):
        ver = get_version(self._path_var.get())
        self._ver_lbl.config(text=f"현재 버전: {ver}")

    def _toggle_token_vis(self):
        self._show_tok = not self._show_tok
        self._token_entry.config(show="" if self._show_tok else "•")

    def _save_token(self):
        tok = self._token_var.get().strip()
        if tok:
            self._token_file.write_text(tok, encoding="utf-8")
            log("토큰이 로컬에 저장되었습니다.", "ok")

    def _load_saved_token(self):
        if self._token_file.exists():
            tok = self._token_file.read_text(encoding="utf-8").strip()
            self._token_var.set(tok)
            log("저장된 토큰을 불러왔습니다.", "info")

    def _toggle_watch(self):
        if self._watching: self._stop_watch()
        else: self._start_watch()

    def _start_watch(self):
        src_dir = str(Path(self._path_var.get()) / "src")
        if not Path(src_dir).exists():
            messagebox.showerror("오류", f"src/ 폴더가 없습니다:\n{src_dir}")
            return
        self._watcher = SrcWatcher(src_dir, self._on_file_change)
        self._watcher.start()
        self._watching = True
        self._watch_btn.config(text="⏹ 감시 중지", fg=self.COLOR["err"])
        self._status_var.set(f"감시 중: {src_dir}")

    def _stop_watch(self):
        if self._watcher:
            self._watcher.stop()
            self._watcher = None
        self._watching = False
        self._watch_btn.config(text="🔍 src/ 감시 시작", fg=self.COLOR["accent2"])
        self._status_var.set("감시 중지됨")
        log("파일 감시를 중지했습니다.", "warn")

    def _on_file_change(self, changed_files: list[str]):
        log(f"변경 감지 ({len(changed_files)}개 파일)", "warn")

        # ★ 변경된 파일을 PyCharm 에서 자동으로 열기
        if self._open_pycharm_var.get():
            pycharm = self._pycharm_var.get().strip()
            threading.Thread(
                target=open_in_pycharm,
                args=(pycharm, changed_files),
                daemon=True
            ).start()

        log("→ 자동 업로드 시작", "warn")
        self._run_upload()

    def _manual_upload(self):
        log("수동 업로드 요청", "info")
        self._run_upload()

    def _run_upload(self):
        if self._busy:
            log("이미 업로드 중입니다. 잠시 기다려주세요.", "warn")
            return
        token = self._token_var.get().strip()
        if not token:
            messagebox.showerror("토큰 없음", "PyPI 토큰을 입력해주세요.")
            return

        self._busy = True
        self._upload_btn.config(state="disabled", text="업로드 중...")
        self._status_var.set("빌드 & 업로드 진행 중...")

        threading.Thread(
            target=do_upload,
            args=(self._path_var.get(), token,
                  self._testpypi_var.get(),
                  self._newver_var.get().strip() or None,
                  self._on_upload_done),
            daemon=True
        ).start()

    def _on_upload_done(self, success: bool):
        self._busy = False
        self.after(0, self._upload_btn.config, {"state": "normal", "text": "⬆  지금 업로드"})
        self.after(0, self._status_var.set,
                   "✅ 업로드 완료!" if success else "❌ 업로드 실패 — 로그 확인")
        self.after(0, self._refresh_version)

    def _clear_log(self):
        self._log.config(state="normal")
        self._log.delete("1.0", "end")
        self._log.config(state="disabled")

    def _poll_log(self):
        while not LOG_Q.empty():
            msg, tag = LOG_Q.get_nowait()
            self._log.config(state="normal")
            self._log.insert("end", msg + "\n", tag)
            self._log.see("end")
            self._log.config(state="disabled")
        self.after(100, self._poll_log)

    def on_close(self):
        if self._watcher:
            self._watcher.stop()
        self.destroy()


# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    app = PyPIUploaderApp()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()
