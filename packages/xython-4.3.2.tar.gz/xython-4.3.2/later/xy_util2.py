# -*- coding: utf-8 -*-
import cv2, pickle
import sys, screeninfo #기본모듈
import numpy as np
from konlpy.tag import Komoran
from PIL import ImageFont
import paho.mqtt.client as mqtt
from unittest.mock import patch
import sounddevice
import pyaudio
import wave
import chardet

import win32con, win32com, win32com.client, win32gui, win32api  # pywin32의 모듈
with patch("ctypes.windll.user32.SetProcessDPIAware", autospec=True):
	import pyautogui

import xy_re, xy_common  # xython 모듈

class xy_util2():
	"""
	여러가지 사무용에 사용할 만한 메소드들을 만들어 놓은것이며,
	좀더 특이한 것은 youtil2로 만들어서 사용할 예정입니다
	"""

	def __init__(self):
		self.rex = xy_re.xy_re()
		self.varx = xy_common.xy_common().varx

		# 가끔 사용하다보면, css를 좀더 쉽게 사용했으면 할때가 있다
		self.varx["line_style_dic"] = {"solid": "solid", "dotted": "dotted", "dot": "dotted", "dashed": "dashed",
									   "dash": "dashed",
									   "double": "double", "outset": "outset", "inset": "inset", "groove": "groove",
									   "ridge": "ridge",
									   "": "solid", ".": "dotted", "--": "dashed", "=": "double"}

	def get_pxy_for_same_position_for_picture_vs_monitor_screen(self, search_picture="D://epro_x_button.jpg"):
		"""
		스크린 캡쳐를 해서, 네이버의 처음 화면을 naver_big이란 이름으로 저장
		스크린 캡쳐한것을 흑백화면으로 변경
		찾을 화면 naver_small_q을 흑백으로 변경
		화일이 들중에 하나라도 없으면, 중지
		원본화면이 가로세로의 픽셀이 얼마나 인지를 계산해서, 비교를 하기 위한것이다
		두영상의 같은위치에 존재하는 픽셀값을 더하는것
		두영상을 비교한 결과를 그레이 스케일로 나타내는 것
		"""
		current_screen = "D:/naver_big_1.jpg"
		pyautogui.screenshot(current_screen)  # 1
		current_screen_gray = cv2.imread(current_screen, cv2.IMREAD_GRAYSCALE)  # 2
		search_screen_gray = cv2.imread(search_picture, cv2.IMREAD_GRAYSCALE)  # 3
		if current_screen_gray is None or search_screen_gray is None: sys.exit()  # 3-1
		result_table = np.zeros(current_screen_gray.shape, np.int32)  # 4
		changed_current_screen = cv2.add(current_screen_gray, result_table, dtype=cv2.CV_8UC3)  # 6
		match_result = cv2.matchTemplate(changed_current_screen, search_screen_gray, cv2.TM_CCOEFF_NORMED)  # 7
		_, maxv, _, maxloc = cv2.minMaxLoc(match_result)  # 9
		cv2.waitKey()  # m
		cv2.destroyAllWindow()
		return [maxloc[0], maxloc[1]]

	def make_table(self, style, title_list, data_l2d):
		"""

		:param style:
		:param title_list:
		:param data_l2d:
		:return:
		"""
		table_style_id = ""
		if style != "":
			table_style_id = " id=" + '"' + style + '"'

		table_html = "<table" + table_style_id + ">"
		for one in title_list:
			table_html = table_html + f"<th>{one}</th>"
		for l1d in data_l2d:
			table_html = table_html + "<tr>"
			for value in l1d:
				if value == None:
					value = ""
				if isinstance(value, pywintypes.TimeType):
					value = str(value)[:10]
				table_html = table_html + f"<td>{value}</td>"
			table_html = table_html + "</tr>"
		table_html = table_html + "</table>"
		return table_html


	def make_html_table_with_l2d(self, title_list, input_l2d):
		"""
		2차원 자료를 html형식의 table로 마드는 것

		:param style:
		:param title_list:
		:param input_l2d:
		:return:
		"""
		import pywintypes
		table_style_id = ""

		table_html = "<table" + table_style_id + ">Wn"

		for one in title_list:
			table_html = table_html + f"<th> {one}</th>"
		for l1d in input_l2d:
			table_html = table_html + "<tr>"
			for value in l1d:
				if value == None:
					value = ""
				if isinstance(value, pywintypes.TimeType):
					value = str(value)[:10]
				table_html = table_html + f"<td>{value}</td>"
			table_html = table_html + "</tr>"
		table_html = table_html + "</table>"
		return table_html

	def change_file_ecoding_type(self, path, filename, original_type="EUC-KR", new_type="UTF-8", new_filename=""):
		"""
		텍스트가 안 읽혀져서 확인해보니 인코딩이 달라서 안되어져서
		파일이 인코딩 형식으로 쉽게 바꿀수 있도록 하기 위한것
		이것으로 전체를 변경하기위해 만듦

		:param path:
		:param filename:
		:param original_type:
		:param new_type:
		:param new_filename:
		:return:
		"""
		full_path = path + "\\" + filename
		full_path_changed = path + "\\" + new_filename + filename
		try:
			aaa = open(full_path, 'rb')
			result = chardet.detect(aaa.read())
			print(result['encoding'], filename)
			aaa.close()

			if result['encoding'] == original_type:
				print("화일의 인코딩은 ======> {}, 화일이름은 {} 입니다".format(original_type, filename))
				aaa = open(full_path, "r", encoding=original_type)
				file_read = aaa.readlines()
				aaa.close()

				new_file = open(full_path_changed, mode='w', encoding=new_type)
				for one in file_read:
					new_file.write(one)
				new_file.close()
		except:
			print("화일이 읽히지 않아요=====>", filename)

		path = "C:\Python39-32\Lib\site-packages\myez_xl\myez_xl_test_codes"
		file_lists = os.listdir(path)
		for one_file in file_lists:
			self.change_file_ecoding_type(path, one_file, "EUC-KR", "UTF-8", "_changed")

	def change_encoding_type_for_file(self, path, filename, original_type="EUC-KR", new_type="utf-8", new_filename=""):
		"""
		텍스트가 안 읽혀져서 확인해보니 인코딩이 달라서 안되어져서
		이것으로 전체를 변경하기위해 만듦

		:param path:
		:param filename:
		:param original_type:
		:param new_type:
		:param new_filename:
		:return:
		"""
		full_path = path + "\\" + filename
		full_path_changed = path + "\\" + new_filename + filename
		try:
			aaa = open(full_path, 'rb')
			result = chardet.detect(aaa.read())
			aaa.close()

			if result['encoding'] == original_type:
				aaa = open(full_path, "r", encoding=original_type)
				file_read = aaa.readlines()
				aaa.close()

				new_file = open(full_path_changed, mode='w', encoding=new_type)
				for one in file_read:
					new_file.write(one)
				new_file.close()
		except:
			print("화일이 읽히지 않아요=====>", filename)

		path = "C:\Python39-32\Lib\site-packages\myez_xl\myez_xl_test_codes"
		file_lists = os.listdir(path)
		for one_file in file_lists:
			self.change_encoding_type_for_file(path, one_file, "EUC-KR", "utf-8", "_changed")

	def save_voice_as_file(self, file_name="output.wav", mic_index_no=1, record_second=15):
		CHUNK = 1024
		FORMAT = pyaudio.paInt32
		RATE = 44100
		p = pyaudio.PyAudio()
		if not file_name.endswith(".wav"):
			file_name = file_name + ".wav"

		stream = p.open(format=FORMAT,
						channels=mic_index_no,
						rate=RATE,
						input=True,
						frames_per_buffer=CHUNK)

		print("Start to record the audio.")

		frames = []

		for i in range(0, int(RATE / CHUNK * record_second)):
			data = stream.read(CHUNK)
			frames.append(data)

		print("Recording is finished.")

		stream.stop_stream()
		stream.close()
		p.terminate()

		wf = wave.open(file_name, 'wb')
		wf.setnchannels(mic_index_no)
		wf.setsampwidth(p.get_sample_size(FORMAT))
		wf.setframerate(RATE)
		wf.writeframes(b''.join(frames))
		wf.close()


	def get_active_mic_devices(self):
		"""
		현재 컴퓨터내 등록된 오디오 입력 장치 중
		실제로 오디오 스트림을 열 수 있는 마이크 목록을 반환
		"""
		print("사용 가능한 오디오 입력 장치를 확인 중...")

		active_devices = []
		all_devices = sounddevice.query_devices()

		for i, device in enumerate(all_devices):
			if device['max_input_channels'] > 0:  # 입력 채널이 있는 장치만 고려
				try:
					# 스트림을 열어보고 즉시 닫아서 장치 접근 가능성 확인
					# 블록 사이즈는 작게 설정하여 빠르게 열고 닫음
					with sounddevice.InputStream(samplerate=16000, channels=1, device=i, blocksize=512):
						# 스트림이 성공적으로 열렸다면 (에러가 발생하지 않았다면)

						print(f"[OK] 사용 가능 ==> 인덱스: {i}, 이름: {device['name']}, 채널: {device['max_input_channels']}")
						active_devices.append({
							'index': i,
							'name': device['name'],
							'input_channels': device['max_input_channels']
						})
				except Exception as e:	# 스트림을 여는 데 실패했을때
					print(f"[FAIL] 접근 불가 ==> 인덱스: {i}, 이름: {device['name']}, 채널: {device['max_input_channels']}")
					#print(f"    -> [FAIL] 접근 불가: {e}")
		if not active_devices:
			print("접근 가능한 오디오 입력 장치를 찾을 수 없습니다.")
			print("블루투스 헤드셋의 경우, 노트북에 올바르게 연결되어 있고 시스템 설정에서 마이크가 활성화되어 있는지 확인해주세요.")

		return active_devices

	def get_pxy_for_same_position_for_picture_vs_monitor_screen_1(self, file_target):
		"""
		현재 화면에서 같은 그림의 위치를 돌려주는 것

		:param file_target:
		:return:
		"""
		pyautogui.screenshot('D:/naver_big_1.jpg')
		src = cv2.imread('D:/naver_big_1.jpg', cv2.IMREAD_GRAYSCALE)  # 흑백으로 색을 읽어온다
		# 에제를 위해서, 네이버의 검색란을 스크린 캡쳐해서 naver_small_q란 이름으로 저장하는 것이다
		templ = cv2.imread(file_target, cv2.IMREAD_GRAYSCALE)

		if src is None or templ is None:
			print('Image load failed!')
			sys.exit()

		noise = np.zeros(src.shape, np.int32)  # zeros함수는 만든 갯수만큼 0이 들어간 행렬을 만드는것
		cv2.randn(noise, 50, 10)
		src = cv2.add(src, noise, dtype=cv2.CV_8UC3)

		res = cv2.matchTemplate(src, templ, cv2.TM_CCOEFF_NORMED)  # 여기서 최댓값 찾기
		res_norm = cv2.normalize(res, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)
		_, maxv, _, maxloc = cv2.minMaxLoc(res)

		th, tw = templ.shape[:2]
		dst = cv2.cvtColor(src, cv2.COLOR_GRAY2BGR)
		cv2.rectangle(dst, maxloc, (maxloc[0] + tw, maxloc[1] + th), (0, 0, 255), 2)

		cv2.waitKey()  # msec시간 단위, 공란 또는 0일 경우엔 무한정으로 대기
		cv2.destroyAllWindows()  # 모든 이미지 창을 닫음

		pyautogui.moveTo(maxloc[0] + 45, maxloc[1] + 15)
		pyautogui.mouseDown(button='left')
		return [maxloc[0] + 45, maxloc[1] + 15]

	def get_pxy_for_same_position_for_two_image_file(self, img_big, img_small):
		"""
		그림 두개의 같은 위치를 찾아내는것

		:param img_big:
		:param img_small:
		:return:
		"""
		src = cv2.imread(img_big, cv2.IMREAD_GRAYSCALE)
		templ = cv2.imread(img_small, cv2.IMREAD_GRAYSCALE)

		noise = np.zeros(src.shape, np.int32)
		cv2.randn(noise, 50, 10)
		src = cv2.add(src, noise, dtype=cv2.CV_8UC3)
		res = cv2.matchTemplate(src, templ, cv2.TM_CCOEFF_NORMED)
		res_norm = cv2.normalize(res, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)
		_, maxv, _, maxloc = cv2.minMaxLoc(res)
		print('maxv : ', maxv)
		print('maxloc : ', maxloc)

		if maxv > 0.85:
			print("found")
			result = maxloc
		else:
			pass
			result = ""
		return result

	def search_same_picture_xy(self, file_target):
		"""
		현재 화면에서 같은 그림의 위치를 돌려주는 것

		:param file_target:
		:return:
		"""
		pyautogui.screenshot('D:/naver_big_1.jpg')
		src = cv2.imread('D:/naver_big_1.jpg', cv2.IMREAD_GRAYSCALE)  # 흑백으로 색을 읽어온다
		# 에제를 위해서, 네이버의 검색란을 스크린 캡쳐해서 naver_small_q란 이름으로 저장하는 것이다
		templ = cv2.imread(file_target, cv2.IMREAD_GRAYSCALE)

		if src is None or templ is None:
			print('Image load failed!')
			sys.exit()

		noise = np.zeros(src.shape, np.int32)  # zeros함수는 만든 갯수만큼 0이 들어간 행렬을 만드는것
		cv2.randn(noise, 50, 10)
		src = cv2.add(src, noise, dtype=cv2.CV_8UC3)

		res = cv2.matchTemplate(src, templ, cv2.TM_CCOEFF_NORMED)  # 여기서 최댓값 찾기
		res_norm = cv2.normalize(res, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)
		_, maxv, _, maxloc = cv2.minMaxLoc(res)

		th, tw = templ.shape[:2]
		dst = cv2.cvtColor(src, cv2.COLOR_GRAY2BGR)
		cv2.rectangle(dst, maxloc, (maxloc[0] + tw, maxloc[1] + th), (0, 0, 255), 2)

		cv2.waitKey()  # msec시간 단위, 공란 또는 0일 경우엔 무한정으로 대기
		cv2.destroyAllWindows()  # 모든 이미지 창을 닫음

		pyautogui.moveTo(maxloc[0] + 45, maxloc[1] + 15)
		pyautogui.mouseDown(button='left')
		return [maxloc[0] + 45, maxloc[1] + 15]

	def template_matching(self, img_big, img_small):
		"""
		큰사진안에서 작은사진이 맞는지를 확인하는 것

		:param img_big:
		:param img_small:
		:return:
		"""
		src = cv2.imread(img_big, cv2.IMREAD_GRAYSCALE)
		templ = cv2.imread(img_small, cv2.IMREAD_GRAYSCALE)

		noise = np.zeros(src.shape, np.int32)
		cv2.randn(noise, 50, 10)
		src = cv2.add(src, noise, dtype=cv2.CV_8UC3)
		res = cv2.matchTemplate(src, templ, cv2.TM_CCOEFF_NORMED)
		res_norm = cv2.normalize(res, None, 0, 255, cv2.NORM_MINMAX, cv2.CV_8U)
		_, maxv, _, maxloc = cv2.minMaxLoc(res)
		print('maxv : ', maxv)
		print('maxloc : ', maxloc)

		if maxv > 0.85:
			print("found")
			result = maxloc
		else:
			pass
			result = ""
		return result


	def write_value_in_df_by_jfinderv1(self, df, xy, value):
		"""
		dataframe에 좌표로 값을 저장

		:param df: dataframe
		:param xy:
		:param value:
		:return:
		"""
		x_max = df.index.size
		y_max = df.columns.size
		if xy[1] > y_max:
			for no in range(y_max, xy[1]):
				df[len(df.columns)] = np.NaN
		if xy[0] > x_max:
			data_set = [(lambda x: np.NaN)(a) for a in range(len(df.columns))]
			for no in range(xy[0] - x_max):
				df.loc[len(df.index)] = data_set
		df.iat[int(xy[0]), int(xy[1])] = value




	def calc_pixel_size(self, input_text, font_size, font_name):
		"""
		폰트와 글자를 주면, 필셀의 크기를 돌려준다

		:param input_text:
		:param font_size:
		:param font_name:
		:return:
		"""
		font = ImageFont.truetype(font_name, font_size)
		size = font.getsize(input_text)
		return size

	def get_pixel_size_for_text(self, input_text, font_size, font_name):
		"""
		폰트와 글자를 주면, 필셀의 크기를 돌려준다
		"""
		font = ImageFont.truetype(font_name, font_size)
		size = font.getsize(input_text)
		return size

	def calculate_pixel_size_for_input_text(self, input_text, font_size, font_name):
		"""
		폰트와 글자를 주면, 필셀의 크기를 돌려준다
		"""
		font = ImageFont.truetype(font_name, font_size)
		size = font.getsize(input_text)
		return size


	def search_korean_in_text(self, input_text):
		"""
		문장을 갖고와서 단어별로 품사를 나누는 것이다
		"""
		komoran = Komoran(userdic="C:\\Python38-32/sjpark_dic.txt")

		input_text = input_text.replace("\n", ", ")
		input_text = input_text.replace(" ", ", ")
		input_text = input_text.strip()

		result = komoran.pos(input_text)
		return result
	def split_calue_성공한것_한글_품사로_나누기(self, input_text):
		"""
		문장을 갖고와서 단어별로 품사를 나누는 것이다
		"""
		komoran = Komoran(userdic="C:\\Python38-32/sjpark_dic.txt")

		input_text = input_text.replace("\n", ", ")
		input_text = input_text.replace(" ", ", ")
		input_text = input_text.strip()

		split_value = komoran.pos(input_text)
		print(split_value)

		#Save pickle
		with open("data.pickle", "wb") as fw:
			pickle.dump(split_value, fw)

	def split_kor_words(self, input_text):
		"""
		문장을 갖고와서 단어별로 품사를 나누는 것이다

		:param input_text:
		:return:
		"""
		komoran = Komoran(userdic="C:\\Python38-32/sjpark_dic.txt")

		input_text = input_text.replace("\n", ", ")
		input_text = input_text.replace(" ", ", ")
		input_text = input_text.strip()

		split_value = komoran.pos(input_text)
		print(split_value)

		# Save pickle
		with open("data.pickle", "wb") as fw:
			pickle.dump(split_value, fw)


	def split_word_in_text_as_word_type(self, input_text):
		"""
		문장을 갖고와서 단어별로 품사를 나누는 것이다
		"""
		komoran = Komoran(userdic="C:\\Python38-32/sjpark_dic.txt")

		input_text = input_text.replace("\n", ", ")
		input_text = input_text.replace(" ", ", ")
		input_text = input_text.strip()

		split_value = komoran.pos(input_text)
		print(split_value)

		# Save pickle
		with open("data.pickle", "wb") as fw:
			pickle.dump(split_value, fw)


	def value_split_성공한것_한글_품사로_나누기(self, input_text):
		"""
		문장을 갖고와서 단어별로 품사를 나누는 것이다
		"""
		komoran = Komoran(userdic="C:\\Python38-32/sjpark_dic.txt")

		input_text = input_text.replace("\n", ", ")
		input_text = input_text.replace(" ", ", ")
		input_text = input_text.strip()

		split_value = komoran.pos(input_text)
		print(split_value)

		#Save pickle
		with open("data.pickle", "wb") as fw:
			pickle.dump(split_value, fw)

	def calculate_text_pixel(self, input_text, target_pixel, font_name="malgun.ttf", font_size=12, fill_char=" "):
		"""
		원하는 길이만큼 텍스트를 근처의 픽셀값으로 만드는것
		원래자료에 붙이는 문자의 픽셀값
		"""
		fill_px = self.get_pixel_size_for_text(fill_char, font_size, font_name)[0]
		total_length = 0
		for one_text in input_text:
			# 한글자씩 필셀값을 계산해서 다 더한다
			one_length = self.get_pixel_size_for_text(fill_char, font_size, font_name)[0]
			total_length = total_length + one_length

		# 원하는 길이만큼 부족한 것을 몇번 넣을지 게산하는것
		times = round((target_pixel - total_length) / fill_px)
		result = input_text + " " * times

		# 최종적으로 넣은 텍스트의 길이를 한번더 구하는것
		length = self.get_pixel_size_for_text(result, font_size, font_name)[0]

		# [최종변경문자, 총 길이, 몇번을 넣은건지]
		return [result, length, times]

	def calculate_value_text_pixel(self, input_text, target_pixel, font_name="malgun.ttf", font_size=12, fill_char=" "):
		"""
		원하는 길이만큼 텍스트를 근처의 픽셀값으로 만드는것
		원래자료에 붙이는 문자의 픽셀값
		"""
		fill_px = self.calc_pixel_size(fill_char, font_size, font_name)[0]
		total_length = 0
		for one_text in input_text:
			# 한글자씩 필셀값을 계산해서 다 더한다
			one_length = self.calc_pixel_size(fill_char, font_size, font_name)[0]
			total_length = total_length + one_length

		# 원하는 길이만큼 부족한 것을 몇번 넣을지 게산하는것
		times = round((target_pixel - total_length) / fill_px)
		result = input_text + " " * times

		# 최종적으로 넣은 텍스트의 길이를 한번더 구하는것
		length = self.calc_pixel_size(result, font_size, font_name)[0]

		# [최종변경문자, 총 길이, 몇번을 넣은건지]
		return [result, length, times]


	def get_text_pixel_for_input_text(self, input_text, target_pixel, font_name="malgun.ttf", font_size=12, fill_char=" "):
		"""
		원하는 길이만큼 텍스트를 근처의 픽셀값으로 만드는것
		원래자료에 붙이는 문자의 픽셀값
		"""
		fill_px = self.get_pixel_size_for_text(fill_char, font_size, font_name)[0]
		total_length = 0
		for one_text in input_text:
			# 한글자씩 필셀값을 계산해서 다 더한다
			one_length = self.get_pixel_size_for_text(fill_char, font_size, font_name)[0]
			total_length = total_length + one_length

		# 원하는 길이만큼 부족한 것을 몇번 넣을지 게산하는것
		times = round((target_pixel - total_length) / fill_px)
		result = input_text + " " * times

		# 최종적으로 넣은 텍스트의 길이를 한번더 구하는것
		length = self.get_pixel_size_for_text(result, font_size, font_name)[0]

		# [최종변경문자, 총 길이, 몇번을 넣은건지]
		return [result, length, times]

	def get_monitors_properties(self):
		"""
		연결된 모니터들의 속성을 알려준다

		:return:
		"""
		result = {}
		sub_result = {}
		num = 0
		for m in screeninfo.get_monitors():
			num = num + 1
			# print(m)
			sub_result["x"] = m.x
			sub_result["y"] = m.y
			sub_result["height_mm"] = m.height_mm
			sub_result["width_mm"] = m.width_mm
			sub_result["height"] = m.height
			sub_result["width"] = m.width
			sub_result["primary"] = m.is_primary
			sub_result["name"] = m.name
			name = "monitor" + str(num)
			result[name] = sub_result
		return result



	def search_objs_by_visited_a_tag(self):
		pass


	def search_objs_by_2_near_tags(self):
		pass


	def search_objs_by_mother_n_son_tags(self):
		pass


	def search_objs_by_tag_n_attr(self):
		pass


	def search_objs_by_tag_n_attr_n_value_as_same(self):
		pass


	def search_objs_by_tag_n_attr_n_value_as_in(self):
		pass


	def search_objs_by_tag_n_attr_n_value_as_start(self):
		pass


	def search_objs_by_tag_n_attr_n_value_as_end(self):
		pass


	def search_objs_by_checked_radio(self):
		pass


	def search_first_obj_by_tag(self):
		pass


	def search_nth_child_obj_by_tag(self):
		pass


	def search_nth_last_child_obj_by_tag(self):
		pass


	def search_nth_of_type_obj_by_tag(self):
		pass

	def search_nth_last_of_type_obj_by_tag(self):
		pass

	def search_first_child_obj_by_tag(self):
		pass

	def search_last_child_obj_by_tag(self):
		pass

	def search_only_child_obj_by_tag(self):
		pass

	def search_only_of_type_obj_by_tag(self):
		pass

	def search_first_of_type_obj_by_tag(self):
		pass


	def mqtt_connect(self, client, userdata, flags, rc):
		"""
		connect_mqtt

		:param client:
		:param userdata:
		:param flags:
		:param rc:
		:return:
		"""
		if rc == 0:
			print("connected OK")
		else:
			print("Bad connection Returned code=", rc)

	def mqtt_receive_data(self, topic='halmoney/data001'):
		"""
		mqtt의 서버에서 자료받기

		:param topic:
		:return:
		"""
		self.topic = topic
		client = mqtt.Client()
		client.on_connect = self.on_connect
		client.on_disconnect = self.on_disconnect
		client.on_subscribe = self.on_subscribe
		client.on_message = self.on_message

		client.connect(self.broker, self.port, 60)
		client.subscribe(self.topic, 1)
		client.loop_forever()

	def mqtt_send_data(self, input_text="no message", topic='halmoney/data001'):
		"""

		:param input_text:
		:param topic:
		:return:
		"""
		self.topic = topic
		client = mqtt.Client()
		# 새로운 클라이언트 생성

		# 콜백 함수 설정 on_connect(브로커에 접속), on_disconnect(브로커에 접속중료), on_publish(메세지 발행)
		client.on_connect = self.on_connect
		client.on_disconnect = self.on_disconnect
		client.on_publish = self.on_publish
		client.connect(self.broker, self.port)
		client.loop_start()

		client.publish(self.topic, str(input_text), self.qos)
		client.loop_stop()
		client.disconnect()

	def mqtt_start(self, broker="broker.hivemq.com", port=1883, qos=0):
		"""

		:param broker:
		:param port:
		:param qos:
		:return:
		"""
		self.broker = broker
		self.port = port
		self.qos = qos


	def dialog_for_search_file_with_image_type(self, file_type=""):
		"""
		일반적인 이미지를 불러오는 메세지박스를 나타낸다

		:return:
		"""
		if file_type == "":
			filter = r"Picture Files \*.*"
		else:
			filter = "Picture Files \0*.jp*;*.gif;*.bmp;*.png\0Text files\0*.txt\0"
		# filter = "Picture Files (*.jp*; *.gif; *.bmp; *.png),*.xls"
		result = win32gui.GetOpenFileNameW(InitialDir=os.environ["temp"],
										   Filter=filter,
										   Flags=win32con.OFN_ALLOWMULTISELECT | win32con.OFN_EXPLORER,
										   File="somefilename", DefExt="py",
										   Title="GetOpenFileNameW",
										   FilterIndex=0)

		return result


	def dialog_for_messagebox_with_time(self, input_text, second, title="www.xython.co.kr"):
		"""
		몇초후에 팝업창이 자동으로 사라지는것

		:param input_text: 팝업창에 나타나는 문구
		:param second: 팝업창이 존재하는 초
		"""
		shell = win32com.client.Dispatch('WScript.Shell')
		intReturn = shell.Popup(input_text, second, title)




	def dialog_for_messagebox(self, input_text="입력필요", input_title="xython.co.kr"):
		"""
		사용하기 편하게 이름을 바꿈
		original : write_value_in_messagebox

		:param input_text:
		:param input_title:
		:return:
		"""
		win32api.MessageBox(0, input_text, input_title, 16)



	def dialog_for_search_file(self):
		"""
		일반적인 메세지박스를 만드는 것이다

		:return:
		"""
		result = win32gui.GetOpenFileNameW(DefExt="*.*")
		return result



	def dialog_for_search_folder(self):
		"""
		일반적인 메세지박스를 만드는 것이다
		# 폴더 선택 대화 상자 열기
		# folder_path = shell.SpecialFolders("Desktop")  # 초기 디렉토리를 바탕화면으로 설정
		# folder = shell.Folder(folder_path)
		# folder_id_list = folder.self.Persist()

		# 폴더 선택 대화 상자 옵션 설정 (필요에 따라 추가)
		# 예: BIF_RETURNONLYFSDIRS (파일 시스템 디렉토리만 반환)
		#      BIF_NEWDIALOGSTYLE (새로운 스타일의 대화 상자)

		:return:
		"""

		shell = win32com.client.Dispatch("WScript.Shell")
		result = shell.BrowseForFolder(0, "폴더 선택", 0)
		return result


	def get_all_file_n_folder_in_recycle_bin_as_dic(self, show_hidden_files = False):
		"""
		휴지통안의 파일과 폴더이름을 나누어서 갖고오는것
		기본으로 숨긴화일은 안보이도록 한다

		:param show_hidden_files:
		:return:
		"""
		shell = win32com.client.Dispatch("Shell.Application")
		recycle_bin = shell.NameSpace(10) #10은 휴지통의 ShellFolder ID 입니다
		items = recycle_bin.ltems()
		files =[]
		folder =[]
		result={}
		for item in items:
			if not show_hidden_files and str(item.Name).startswith("$"):
				pass
			else:
				if item.isFolder:
					folder.append(item.Name)
				else:
					files.append(item.Name)
		result["file"] = files
		result["folder"] = folder
		return result


	def get_all_selected_file_at_explorer(self):
		"""
		화일탐색기에서 선택한 화일들의 이름을 갖고오는 것

		:return:
		"""
		shell = win32com.client.dynamic.Dispatch("Shell.Application")
		# 현재 열려 있는 탐색기 창 가져오기
		explorer = shell.Windows()
		result = []

		for window in explorer:
			# 탐색기 창이 폴더를 표시하는지 확인
			if window.Name in ["Windows 탐색기", "File Explorer", "파일 탐색기"]:
				folder_view = window.Document
				selected_items = folder_view.Selecteditems()

				# 선택된 파일의 경로 출력
				for item in selected_items:
					if not str(item.Type).lower() in ["파일 폴더", "folder", "file folder"]:
						temp = []
						temp.append(item.Path)
						temp.extend(os.path.split(item.Path))
						##temp_dic["type"] = item.Type
						##temp_dic["name"] = item.Name
						result.append(temp)
		return result

	def get_all_selected_file_n_folder_at_explorer(self):
		"""

		:return:
		"""
		# Shell.Application COM 객체 생성
		shell = win32com.client.dynamic.Dispatch("Shell.Application")
		# 현재 열려 있는 탐색기 창 가져오기
		windows = shell.Windows()
		result = []

		for window in windows:
			# 탐색기 창이 폴더를 표시하는지 확인
			if window.Name in ["Windows 탐색기", "File Explorer", "파일 탐색기"]:
				folder_view = window.Document
				selected_items = folder_view.Selecteditems()

				# 선택된 파일의 경로 출력
				for item in selected_items:
					temp_dic = {}
					temp_dic["path"] = item.Path
					temp_dic["type"] = item.Type
					temp_dic["name"] = item.Name
					result.append(temp_dic)
		return result

	def get_all_selected_folder_at_explorer(self):
		"""

		:return:
		"""
		shell = win32com.client.dynamic.Dispatch("Shell.Application")
		# 현재 열려 있는 탐색기 창 가져오기
		windows = shell.Windows()
		result = []

		for window in windows:
			# 탐색기 창이 폴더를 표시하는지 확인
			if window.Name in ["Windows 탐색기", "File Explorer", "파일 탐색기"]:
				folder_view = window.Document
				selected_items = folder_view.Selecteditems()

				# 선택된 파일의 경로 출력
				for item in selected_items:
					if str(item.Type).lower() in ["파일 폴더", "folder", "file folder"]:
						temp_dic = {}
						temp_dic["path"] = item.Path
						temp_dic["type"] = item.Type
						temp_dic["name"] = item.Name
						result.append(temp_dic)
		return result

	def get_all_selected_path_n_file_at_explorer(self):
		"""

		:return:
		"""
		shell = win32com.client.dynamic.Dispatch("Shell.Application")
		# 현재 열려 있는 탐색기 창 가져오기
		windows = shell.Windows()
		result = []

		for window in windows:
			# 탐색기 창이 폴더를 표시하는지 확인
			if window.Name in ["Windows 탐색기", "File Explorer", "파일 탐색기"]:
				folder_view = window.Document
				selected_items = folder_view.Selecteditems()

				# 선택된 파일의 경로 출력
				for item in selected_items:
					if not str(item.Type).lower() in ["파일 폴더", "folder", "file folder"]:
						result.append(os.path.split(item.Path))
		return result


	def open_notepad_and_paste_clipboard(self):
		"""
		노트패드를 실행시키고
		붙여넣기를 실행시키는 것이다
		노트패드는 com인터페이스가 없다
		"""
		shell = win32com.client.Dispatch("WScript.Shell")
		shell.Run("notepad")
		shell.AppActivate("notepad")
		shell.SendKeys("^v", 0)

	def popup_notification(self, input_text, second):
		"""
		몇초후에 팝업창이 자동으로 사라지는것

		:param input_text:
		:param second:
		:return:
		"""
		shell = win32com.client.Dispatch('WScript.Shell')
		shell.Popup(input_text, second)
	def select_files_in_explorer(self, file_l1d):
		"""
		화일탐색기에서 입력으로 들어온 화일들을 선택하는 것

		:param file_l1d:
		:return:
		"""
		#화일을 탐색기에서 선택하는 것
		shell= win32com.client.dynamic.Dispatch("Shell.Application")
		explorer = shell.Windows()
		for window in explorer:
			if window.Name in ["Windows 탐색기", "File Explorer", "파일 탐색기", "Windows Explorer"]:
				folder_view = window.Document
				#print(folder_view)
				#folder_view.SelectNone()
				folder_view.SelectItem(file_l1d[0], 4)
				for index, file in enumerate(file_l1d):
					folder_view.SelectItem(file, 1)
	def get_font_list_for_window(self):
		"""
		윈도우에서 설치된 font리스트를 갖고온다

		:return:
		"""
		font_names = []
		hdc = win32gui.GetDC(None)
		win32gui.EnumFontFamilies(hdc, None, self.callback, font_names)
		win32gui.ReleaseDC(hdc, None)
		return font_names
	def get_window_font_list(self):
		"""
		윈도우에서 설치된 font의 리스트를 갖고온다

		:return:
		"""
		font_names = []
		hdc = win32gui.GetDC(None)
		win32gui.EnumFontFamilies(hdc, None, self.callback, font_names)
		win32gui.ReleaseDC(hdc, None)
		return font_names
	def get_computer_name(self):
		"""
		win32api 를 사용하는 방법

		:return:
		"""
		result = []
		result.append(win32api.GetComputerName())
		result.append(win32api.GetLocalTime())
		result.append(win32api.GetCursorPos())
		result.append(win32api.GetSystemDirectory())
		result.append(win32api.GetDiskFreeSpace())
		result.append(win32api.GetSystemFileCacheSize())
		result.append(win32api.GlobalMemoryStatus())
		result.append(win32api.GetSystemDirectory())
		result.append(win32api.GetSystemDirectory())
		result.append(win32api.GetSystemDirectory())
		result.append(win32api.GetSystemDirectory())
		return result
	def get_pxy_for_cursor(self):
		"""
		커서의 위치를 갖고오는 것
		:return:
		"""
		pos = win32api.GetCursorPos()

	def get_pxy_for_mouse(self):
		"""
		현재 마우스의 위치를 돌려조는 것

		다른방법
		xy = pyautogui.position()
		return (xy.x, xy.y)

		:return:
		"""
		# 현재 마우스의 위치를 읽어온다
		result = win32api.GetCursorPos()
		return result
	def read_screen_size(self):
		"""
		화면 사이즈를 읽어오는 것

		:return:
		"""
		result = win32api.GetSystemMetrics()
		return result

	def set_limitation_for_mouse(self, xyxy_list):
		"""
		(left, top, right, bottom) 영역으로 마우스 커서 제한하기
		win32api.ClipCursor((200, 200, 700, 700))

		마우스 커서 제한 해제하기
		win32api.ClipCursor((0, 0, 0, 0))
		win32api.ClipCursor()

		:return:
		"""
		win32api.ClipCursor(xyxy_list)

	def set_pos_for_cursor(self):
		"""
		커서의 옮기는 것
		:return:
		"""
		pos = (200, 200)
		win32api.SetCursorPos(pos)

	def sound_beep(self, sec=1000, hz=500):
		"""
		beep 음을 내는 것
		메뉴에서 제외

		:param sec:
		:param hz:
		:return:
		"""
		win32api.Beep(hz, sec)


