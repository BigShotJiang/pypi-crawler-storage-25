"""Session transcript storage.

Append-only JSONL transcript per session. Large content blobs are stored
separately and referenced by hash from transcript entries.
"""

from __future__ import annotations

import contextlib
import hashlib
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from shisad.core.types import SessionId, TaintLabel


class TranscriptEntry(BaseModel):
    """A single transcript entry for a session."""

    role: str
    content_hash: str
    taint_labels: list[TaintLabel] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    blob_ref: str | None = None
    content_preview: str = ""
    evidence_ref_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class TranscriptStore:
    """Append-only transcript store with content-addressed blob references."""

    def __init__(self, root_dir: Path, *, blob_threshold_bytes: int = 4096) -> None:
        self._root_dir = root_dir
        self._blob_threshold_bytes = blob_threshold_bytes
        self._transcript_dir = root_dir / "transcripts"
        self._blob_dir = root_dir / "blobs"
        self._transcript_dir.mkdir(parents=True, exist_ok=True)
        self._blob_dir.mkdir(parents=True, exist_ok=True)
        self._ensure_dir_permissions(self._transcript_dir)
        self._ensure_dir_permissions(self._blob_dir)

    def append(
        self,
        session_id: SessionId,
        *,
        role: str,
        content: str,
        taint_labels: set[TaintLabel] | None = None,
        metadata: dict[str, Any] | None = None,
        evidence_ref_id: str | None = None,
        timestamp: datetime | None = None,
    ) -> TranscriptEntry:
        """Append a transcript entry for a session."""
        raw = content.encode("utf-8")
        content_hash = hashlib.sha256(raw).hexdigest()
        entry_timestamp = self._normalize_timestamp(timestamp)
        entry_metadata = dict(metadata or {})
        entry_metadata["timestamp_utc"] = entry_timestamp.isoformat()
        if evidence_ref_id:
            entry_metadata.setdefault("evidence_ref_id", evidence_ref_id)

        blob_ref: str | None = None
        preview = content
        if len(raw) > self._blob_threshold_bytes:
            blob_ref = content_hash
            preview = content[:200]
            blob_path = self._blob_dir / f"{content_hash}.txt"
            if not blob_path.exists():
                blob_path.write_text(content)
            self._ensure_file_permissions(blob_path)

        entry = TranscriptEntry(
            role=role,
            content_hash=content_hash,
            taint_labels=sorted(taint_labels or set()),
            timestamp=entry_timestamp,
            blob_ref=blob_ref,
            content_preview=preview,
            evidence_ref_id=evidence_ref_id,
            metadata=entry_metadata,
        )

        transcript_path = self._transcript_dir / f"{session_id}.jsonl"
        with transcript_path.open("a", encoding="utf-8") as handle:
            handle.write(entry.model_dump_json() + "\n")
        self._ensure_file_permissions(transcript_path)

        return entry

    def list_entries(self, session_id: SessionId) -> list[TranscriptEntry]:
        """Return transcript entries for a session."""
        path = self._transcript_dir / f"{session_id}.jsonl"
        if not path.exists():
            return []

        entries: list[TranscriptEntry] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            entries.append(TranscriptEntry.model_validate_json(line))
        return entries

    def truncate(self, session_id: SessionId, *, keep_entries: int) -> int:
        """Keep only the first ``keep_entries`` transcript rows for a session."""
        path = self._transcript_dir / f"{session_id}.jsonl"
        if not path.exists():
            return 0

        entries = self.list_entries(session_id)
        normalized_keep = max(0, int(keep_entries))
        if normalized_keep >= len(entries):
            return 0

        kept = entries[:normalized_keep]
        removed = len(entries) - len(kept)
        with path.open("w", encoding="utf-8") as handle:
            for entry in kept:
                handle.write(entry.model_dump_json() + "\n")
        self._ensure_file_permissions(path)
        return removed

    def delete_session(self, session_id: SessionId) -> None:
        path = self._transcript_dir / f"{session_id}.jsonl"
        with contextlib.suppress(OSError):
            path.unlink()

    def read_blob(self, content_hash: str) -> str | None:
        """Read a large blob by its content hash."""
        path = self._blob_dir / f"{content_hash}.txt"
        if not path.exists():
            return None
        return path.read_text(encoding="utf-8")

    @staticmethod
    def _ensure_dir_permissions(path: Path) -> None:
        with contextlib.suppress(OSError):
            os.chmod(path, 0o700)

    @staticmethod
    def _ensure_file_permissions(path: Path) -> None:
        with contextlib.suppress(OSError):
            os.chmod(path, 0o600)

    @staticmethod
    def _normalize_timestamp(timestamp: datetime | None) -> datetime:
        if timestamp is None:
            return datetime.now(UTC)
        if timestamp.tzinfo is None:
            return timestamp.replace(tzinfo=UTC)
        return timestamp.astimezone(UTC)
