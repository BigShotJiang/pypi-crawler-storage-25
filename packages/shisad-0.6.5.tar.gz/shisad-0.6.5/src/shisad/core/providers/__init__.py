"""Provider implementations and adapters."""
