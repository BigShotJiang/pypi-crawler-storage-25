"""Shared test helpers."""
