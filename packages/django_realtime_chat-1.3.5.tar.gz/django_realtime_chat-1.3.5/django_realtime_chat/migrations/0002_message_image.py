# Generated migration for adding image field to Message

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('django_realtime_chat', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='message',
            name='image',
            field=models.ImageField(blank=True, null=True, upload_to='chat_images/'),
        ),
    ]

