import json
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.db import models
from django.contrib.auth import get_user_model

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser
from rest_framework.permissions import IsAuthenticated

from .models import Conversation, Message, UserKey
from . import __version__

User = get_user_model()


@login_required
def chat_home(request):
    """Page principale : liste les conversations de l'utilisateur connecté."""
    user = request.user
    conversations = Conversation.objects.filter(
        models.Q(user1=user) | models.Q(user2=user)
    ).select_related("user1", "user2").order_by("-updated_at")

    # Enrichir chaque conversation avec l'interlocuteur et le dernier message
    for conv in conversations:
        conv.other_user = conv.user2 if conv.user1 == user else conv.user1
        conv.last_message = conv.messages.order_by("-created_at").first()

    all_users = User.objects.exclude(id=user.id)

    return render(request, "django_realtime_chat/chat.html", {
        "conversations": conversations,
        "all_users": all_users,
        "current_user_id": user.id,
        "current_username": user.username,
        "plugin_version": __version__,
    })


@login_required
def start_conversation(request, user_id):
    """Démarre ou récupère une conversation avec un autre utilisateur."""
    other_user = get_object_or_404(User, id=user_id)
    user = request.user

    # Chercher dans les deux sens
    conv = Conversation.objects.filter(
        models.Q(user1=user, user2=other_user) |
        models.Q(user1=other_user, user2=user)
    ).first()

    if not conv:
        conv = Conversation.objects.create(user1=user, user2=other_user)

    return redirect("django_realtime_chat:chat_home")


@login_required
def message_history(request, conversation_id):
    """Retourne l'historique JSON des messages d'une conversation."""
    user = request.user
    conversation = get_object_or_404(
        Conversation,
        id=conversation_id,
        **{"user1": user} if Conversation.objects.filter(id=conversation_id, user1=user).exists()
        else {"user2": user}
    )

    # Récupérer la conversation en vérifiant que l'utilisateur y participe
    conversation = Conversation.objects.filter(
        id=conversation_id
    ).filter(
        models.Q(user1=user) | models.Q(user2=user)
    ).first()

    if not conversation:
        return JsonResponse({"error": "Conversation introuvable"}, status=404)

    messages = conversation.messages.select_related("sender", "reply_to__sender").order_by("created_at")
    data = [
        {
            "id": msg.id,
            "sender_id": msg.sender.id,
            "sender_username": msg.sender.username,
            "content": msg.content,
            "file_url": msg.file.url if msg.file else None,
            "file_type": msg.file_type,
            "created_at": msg.created_at.isoformat(),
            "reply_to_id": msg.reply_to.id if msg.reply_to else None,
            "reply_to_content": msg.reply_to.content if msg.reply_to else None,
            "reply_to_sender_username": msg.reply_to.sender.username if msg.reply_to else None,
            "reply_to_sender_id": msg.reply_to.sender.id if msg.reply_to else None,
        }
        for msg in messages
    ]
    return JsonResponse({"messages": data, "conversation_id": conversation_id})


@login_required
def user_list(request):
    """Retourne la liste des utilisateurs (hors soi-même) en JSON."""
    users = User.objects.exclude(id=request.user.id).values("id", "username")
    return JsonResponse({"users": list(users)})


class UserKeyView(APIView):
    """Gère la clé publique de l'utilisateur."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """Retourne la clé publique de l'utilisateur."""
        try:
            user_key = UserKey.objects.get(user=request.user)
            return Response({"public_key": user_key.get_public_key_data()})
        except UserKey.DoesNotExist:
            return Response({"error": "Clé publique non trouvée"}, status=404)

    def post(self, request):
        """Définit ou met à jour la clé publique de l'utilisateur."""
        public_key_data = request.data.get("public_key")
        if not public_key_data:
            return Response({"error": "public_key requis"}, status=400)

        user_key, created = UserKey.objects.get_or_create(user=request.user)
        user_key.set_public_key_data(public_key_data)
        user_key.save()

        return Response({"status": "ok", "created": created})


class PublicKeyView(APIView):
    """Obtient la clé publique d'un autre utilisateur."""
    permission_classes = [IsAuthenticated]

    def get(self, request, user_id):
        """Retourne la clé publique d'un utilisateur spécifique."""
        try:
            user = User.objects.get(id=user_id)
            user_key = UserKey.objects.get(user=user)
            return Response({"public_key": user_key.get_public_key_data()})
        except User.DoesNotExist:
            return Response({"error": "Utilisateur non trouvé"}, status=404)
        except UserKey.DoesNotExist:
            return Response({"error": "Clé publique non trouvée"}, status=404)


class FileUploadView(APIView):
    """Upload d'un fichier ou d'une image dans une conversation."""
    parser_classes = [MultiPartParser]
    permission_classes = [IsAuthenticated]

    def post(self, request):
        file = request.FILES.get("file")
        receiver_id = request.data.get("receiver_id")
        upload_type = request.data.get("upload_type", "file")  # 'image' ou 'file'

        if not receiver_id:
            return Response({"error": "receiver_id requis"}, status=400)

        if not file:
            return Response({"error": "Fichier requis"}, status=400)

        sender = request.user
        receiver = get_object_or_404(User, id=receiver_id)

        conv, _ = Conversation.objects.get_or_create_between(sender, receiver)

        try:
            if upload_type == "image":
                msg = Message.objects.create(
                    conversation=conv,
                    sender=sender,
                    image=file,
                )
                return Response({
                    "status": "ok",
                    "type": "image",
                    "image_url": request.build_absolute_uri(msg.image.url),
                    "message_id": msg.id,
                    "conversation_id": conv.id,
                    "created_at": msg.created_at.isoformat(),
                })
            else:
                msg = Message.objects.create(
                    conversation=conv,
                    sender=sender,
                    file=file,
                    file_type=file.content_type,
                )
                return Response({
                    "status": "ok",
                    "type": "file",
                    "file_url": request.build_absolute_uri(msg.file.url),
                    "file_name": file.name,
                    "message_id": msg.id,
                    "conversation_id": conv.id,
                    "created_at": msg.created_at.isoformat(),
                })
        except Exception as e:
            return Response({"error": str(e)}, status=400)
