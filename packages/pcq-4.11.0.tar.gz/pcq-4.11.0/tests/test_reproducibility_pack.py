"""build_code_object / build_seeds_object / build_data_ref_object 단위 테스트
+ BL-1/2/4 회귀 방어 + S1~S5 시나리오 — T-PCQRP-6.

각 테스트는 spec/SPEC.md ## Reproducibility Pack (R5~R8, R15) 및
pcq-reproducibility-pack 비평 BL-1, BL-2, BL-4 에 대응한다.

AAA 구조(Arrange / Act / Assert), 한국어 docstring, 영어 식별자.
테스트 간 공유 상태 없음 — tmp_path / monkeypatch 픽스처로 격리.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

import pcq
from pcq.contract import (
    _INTEGRITY_HASHED_FIELDS,
    build_code_object,
    build_data_ref_object,
    build_integrity_object,
    build_seeds_object,
)
from pcq.agent.describe import describe_run


# ─────────────────────────────────────────────────────────────────────────────
# 공통 헬퍼
# ─────────────────────────────────────────────────────────────────────────────

CONFORMANCE_FIXTURE = (
    Path(__file__).parent
    / "conformance"
    / "pcq.describe_run.record"
    / "pcq-2x-full"
    / "fixtures"
    / "output"
    / "run_record.json"
)


def _setup_cfg(tmp_path: Path, **extra: object) -> Path:
    """테스트용 CQ_CONFIG_JSON 파일 생성."""
    cfg: dict = {"output_dir": str(tmp_path), "seed": 42}
    cfg.update(extra)
    p = tmp_path / "cfg.json"
    p.write_text(json.dumps(cfg))
    return p


def _canonical_hash(subset: dict) -> str:
    """R15 canonical form — build_integrity_object 와 동일한 byte 순서.

    json.dumps(indent=2, sort_keys=True, default=str) → sha256 → 'sha256:<hex>'.
    build_integrity_object 를 호출하지 않는 독립 구현이어야 한다.
    """
    canonical = json.dumps(subset, indent=2, sort_keys=True, default=str)
    hex_digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    return f"sha256:{hex_digest}"


def _resolve_dotted(payload: dict, path: str) -> object:
    """점(.) 구분 경로로 payload 에서 값을 추출한다.

    build_integrity_object 내부 구현과 동일한 로직이지만 테스트 독립 복제본.
    """
    parts = path.split(".")
    cur: object = payload
    for part in parts:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(part)  # type: ignore[assignment]
    return cur


# ─────────────────────────────────────────────────────────────────────────────
# A. Builder 단위 테스트 — build_code_object
# ─────────────────────────────────────────────────────────────────────────────

def test_build_code_object_with_valid_inputs_returns_dict():
    """유효한 content_sha256 + scope 를 전달하면 code dict 가 반환되고 경고가 없어야 한다.

    Arrange: 올바른 sha256 접두사 + entry_script scope
    Act: build_code_object(...)
    Assert: dict 반환, warnings 빈 목록, 각 필드 값 일치
    """
    # Arrange
    sha = "sha256:" + "a" * 64
    scope = {"kind": "entry_script", "files": ["train.py"], "root": None}

    # Act
    result, warnings = build_code_object(content_sha256=sha, scope=scope)

    # Assert
    assert result is not None, "유효한 입력에서 None 반환됨"
    assert isinstance(result, dict)
    assert result["content_sha256"] == sha
    assert result["scope"] == scope
    assert warnings == [], f"유효한 입력에서 경고 발생: {warnings}"


def test_build_code_object_with_all_none_returns_none_and_empty_warnings():
    """content_sha256 과 scope 모두 None 이면 None 과 빈 warnings 를 반환한다 (NOTE-3).

    omit-not-null 규칙: 모든 입력이 None 이면 code 필드를 생략한다.

    Arrange: 두 인자 모두 None
    Act: build_code_object(None, None)
    Assert: result is None, warnings == []
    """
    # Act
    result, warnings = build_code_object(content_sha256=None, scope=None)

    # Assert
    assert result is None, f"두 인자 None 시 None 반환 기대, 실제: {result!r}"
    assert warnings == [], f"None 입력에서 경고 발생: {warnings}"


def test_build_code_object_with_invalid_content_sha_prefix_emits_format_warning_but_keeps_value():
    """sha256: 접두사 없는 content_sha256 은 형식 경고를 발생시키지만 원본 값을 유지한다.

    경고는 발생하되 값은 버리지 않는다 — downstream schema 검증에 위임.

    Arrange: 잘못된 prefix (md5: ...) 를 가진 해시 문자열
    Act: build_code_object(...)
    Assert: CODE_CONTENT_SHA_FORMAT_INVALID 경고 포함, result["content_sha256"] == 원본값
    """
    # Arrange
    bad_sha = "md5:00000000000000000000000000000000"
    scope = {"kind": "file_list", "files": ["train.py"], "root": None}

    # Act
    result, warnings = build_code_object(content_sha256=bad_sha, scope=scope)

    # Assert
    codes = [w.get("code") for w in warnings]
    assert "CODE_CONTENT_SHA_FORMAT_INVALID" in codes, (
        f"CODE_CONTENT_SHA_FORMAT_INVALID 경고 없음: {warnings}"
    )
    assert result is not None
    # 원본 값 유지 확인
    assert result["content_sha256"] == bad_sha, (
        f"원본 sha256 값이 유지되어야 함: {result['content_sha256']!r}"
    )


def test_build_code_object_with_invalid_scope_kind_emits_warning_and_nulls_kind():
    """허용 열거형에 없는 scope.kind 는 경고를 발생시키고 kind 를 None 으로 처리한다.

    나머지 scope 필드는 유지된다.

    Arrange: kind="unknown_kind" 인 scope
    Act: build_code_object(...)
    Assert: CODE_SCOPE_KIND_INVALID 경고 포함, result["scope"]["kind"] is None
    """
    # Arrange
    sha = "sha256:" + "b" * 64
    scope = {"kind": "unknown_kind", "files": ["train.py"], "root": None}

    # Act
    result, warnings = build_code_object(content_sha256=sha, scope=scope)

    # Assert
    codes = [w.get("code") for w in warnings]
    assert "CODE_SCOPE_KIND_INVALID" in codes, (
        f"CODE_SCOPE_KIND_INVALID 경고 없음: {warnings}"
    )
    assert result is not None
    assert result["scope"] is not None
    assert result["scope"]["kind"] is None, (
        f"잘못된 kind 는 None 으로 처리되어야 함: {result['scope']['kind']!r}"
    )


def test_build_code_object_with_non_dict_scope_emits_malformed_warning():
    """dict 가 아닌 scope 는 CODE_SCOPE_MALFORMED 경고를 발생시키고 scope 를 None 으로 처리한다.

    Arrange: scope 인자가 문자열 (dict 아님)
    Act: build_code_object(...)
    Assert: CODE_SCOPE_MALFORMED 경고 포함, result["scope"] is None
    """
    # Arrange
    sha = "sha256:" + "c" * 64

    # Act
    result, warnings = build_code_object(
        content_sha256=sha,
        scope="not_a_dict",  # type: ignore[arg-type]
    )

    # Assert
    codes = [w.get("code") for w in warnings]
    assert "CODE_SCOPE_MALFORMED" in codes, (
        f"CODE_SCOPE_MALFORMED 경고 없음: {warnings}"
    )
    assert result is not None
    assert result["scope"] is None, (
        f"dict 아닌 scope 는 None 처리되어야 함: {result['scope']!r}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# A. Builder 단위 테스트 — build_seeds_object
# ─────────────────────────────────────────────────────────────────────────────

def test_build_seeds_object_with_multi_seed_dict_returns_sorted_dict():
    """다중 시드 dict 가 R15 결정론적 직렬화를 위해 키가 정렬된 dict 로 반환된다.

    Arrange: 순서 없는 다중 시드 dict
    Act: build_seeds_object(...)
    Assert: 반환 dict 키 순서 == sorted(keys), warnings 빈 목록
    """
    # Arrange
    seeds = {"torch": 67890, "main": 42, "numpy": 12345, "dataloader": 7}

    # Act
    result, warnings = build_seeds_object(seeds=seeds)

    # Assert
    assert result is not None, "유효한 multi-seed dict 에서 None 반환됨"
    assert warnings == [], f"유효한 시드 dict 에서 경고 발생: {warnings}"
    # R15: 키 정렬 확인
    assert list(result.keys()) == sorted(seeds.keys()), (
        f"키 정렬 순서가 맞지 않음: {list(result.keys())!r}"
    )
    # 값 보존 확인
    for key, val in seeds.items():
        assert result[key] == val, f"seeds[{key!r}] 값 불일치"


def test_build_seeds_object_with_empty_returns_none():
    """None 또는 빈 dict 는 (None, []) 를 반환한다 (omit-not-null 규칙).

    Arrange: 빈 dict
    Act: build_seeds_object(seeds={})
    Assert: result is None, warnings == []
    """
    # Act — 빈 dict
    result_empty, warnings_empty = build_seeds_object(seeds={})
    # Act — None
    result_none, warnings_none = build_seeds_object(seeds=None)

    # Assert
    assert result_empty is None, f"빈 dict 에서 None 반환 기대: {result_empty!r}"
    assert warnings_empty == []
    assert result_none is None, f"None 입력에서 None 반환 기대: {result_none!r}"
    assert warnings_none == []


def test_build_seeds_object_with_invalid_value_type_drops_key_and_emits_warning():
    """int 또는 str 이 아닌 seed 값은 해당 키를 제거하고 SEEDS_VALUE_INVALID_TYPE 경고를 발생시킨다.

    Arrange: 유효한 main=42 + 잘못된 타입의 bad_seed=3.14
    Act: build_seeds_object(...)
    Assert: SEEDS_VALUE_INVALID_TYPE 경고 포함, result 에 bad_seed 키 없음, main 은 보존
    """
    # Arrange
    seeds = {"main": 42, "bad_seed": 3.14}  # float 은 허용 안 됨

    # Act
    result, warnings = build_seeds_object(seeds=seeds)

    # Assert
    codes = [w.get("code") for w in warnings]
    assert "SEEDS_VALUE_INVALID_TYPE" in codes, (
        f"SEEDS_VALUE_INVALID_TYPE 경고 없음: {warnings}"
    )
    assert result is not None, "유효 키가 있으므로 None 이 아니어야 함"
    assert "bad_seed" not in result, "잘못된 타입 키가 result 에 남아 있음"
    assert result.get("main") == 42, "유효한 main 시드가 제거됨"


# ─────────────────────────────────────────────────────────────────────────────
# A. Builder 단위 테스트 — build_data_ref_object
# ─────────────────────────────────────────────────────────────────────────────

def test_build_data_ref_object_with_all_general_fields_emits_dict():
    """일반 도메인 (general) 에서 uri + content_sha256 + size_bytes 가 모두 dict 에 포함된다.

    Arrange: general 도메인 + 유효한 sha256 prefix
    Act: build_data_ref_object(...)
    Assert: dict 반환, 세 필드 모두 값 보존, warnings 빈 목록
    """
    # Arrange
    uri = "s3://example-bucket/dataset/iris.csv"
    sha = "sha256:" + "d" * 64
    size = 150528

    # Act
    result, warnings = build_data_ref_object(
        uri=uri,
        content_sha256=sha,
        size_bytes=size,
        domain="general",
    )

    # Assert
    assert result is not None, "유효한 입력에서 None 반환됨"
    assert result["uri"] == uri
    assert result["content_sha256"] == sha
    assert result["size_bytes"] == size
    assert warnings == [], f"일반 도메인 유효 입력에서 경고 발생: {warnings}"


@pytest.mark.parametrize("phi_domain", ["medical", "financial", "regulated"])
def test_build_data_ref_object_with_PHI_domain_strips_content_sha256_and_emits_warning(
    phi_domain: str,
):
    """PHI 도메인(medical/financial/regulated)에서 content_sha256 이 강제 null 처리되고 경고가 발생한다.

    R5/R5b PHI 게이트: 도메인이 PHI 대상이면 content_sha256 emit 금지.
    uri 와 size_bytes 는 PHI 도메인에서도 허용된다.

    Arrange: PHI 도메인 + 유효한 content_sha256
    Act: build_data_ref_object(domain=phi_domain, ...)
    Assert: DATA_REF_CONTENT_SHA_SUPPRESSED_PHI 경고 포함, result["content_sha256"] is None
    """
    # Arrange
    uri = "cq://datasets/patient-records@abc123"
    sha = "sha256:" + "e" * 64
    size = 1024

    # Act
    result, warnings = build_data_ref_object(
        uri=uri,
        content_sha256=sha,
        size_bytes=size,
        domain=phi_domain,
    )

    # Assert
    codes = [w.get("code") for w in warnings]
    assert "DATA_REF_CONTENT_SHA_SUPPRESSED_PHI" in codes, (
        f"domain={phi_domain!r} 에서 PHI 경고 없음: {warnings}"
    )
    assert result is not None
    assert result["content_sha256"] is None, (
        f"PHI 도메인 {phi_domain!r} 에서 content_sha256 이 null 처리되어야 함: "
        f"{result['content_sha256']!r}"
    )
    # uri 와 size_bytes 는 보존
    assert result["uri"] == uri, "PHI 도메인에서 uri 가 제거됨 (허용되어야 함)"
    assert result["size_bytes"] == size, "PHI 도메인에서 size_bytes 가 제거됨 (허용되어야 함)"


def test_build_data_ref_object_with_invalid_sha_prefix_emits_format_warning_but_keeps_value():
    """sha256: 접두사 없는 content_sha256 은 형식 경고를 발생시키지만 원본 값을 유지한다.

    Arrange: 잘못된 prefix 를 가진 해시 문자열, 일반 도메인
    Act: build_data_ref_object(...)
    Assert: DATA_REF_CONTENT_SHA_FORMAT_INVALID 경고 포함, result["content_sha256"] == 원본값
    """
    # Arrange
    bad_sha = "notsha256:0000000000000000000000000000000000000000000000000000000000000000"
    uri = "file:///tmp/dataset.csv"

    # Act
    result, warnings = build_data_ref_object(
        uri=uri,
        content_sha256=bad_sha,
        size_bytes=None,
        domain="general",
    )

    # Assert
    codes = [w.get("code") for w in warnings]
    assert "DATA_REF_CONTENT_SHA_FORMAT_INVALID" in codes, (
        f"DATA_REF_CONTENT_SHA_FORMAT_INVALID 경고 없음: {warnings}"
    )
    assert result is not None
    assert result["content_sha256"] == bad_sha, (
        f"원본 sha256 값이 유지되어야 함: {result['content_sha256']!r}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# B. R15 결정론적 검증 — 4-pack 포함 완전 payload 의 byte-identical hash
# ─────────────────────────────────────────────────────────────────────────────

def test_build_integrity_with_new_4pack_fields_is_byte_identical_to_independent_recompute():
    """R15: code + seeds + data_ref 포함 payload 의 content_hash 가 독립적 재계산과 byte 동일.

    build_integrity_object 가 계산한 hash 를 직접 hashlib 로 재현하여 동일성 확인.
    이 테스트는 build_integrity_object 를 재계산 경로에서 호출하지 않는 진짜 독립 검증이다.

    _INTEGRITY_HASHED_FIELDS 목록과 동일한 absent-leaf drop(None → 제외) 규칙 적용.
    anti-recursion 제외 경로("attribution.signature", "integrity") 동일하게 적용.

    Arrange: intent + code + seeds + data_ref + config + contract_version 포함 payload
    Act: build_integrity_object(payload) 호출
    Assert: content_hash 가 독립 재계산 값과 byte 완전 일치
    """
    # Arrange
    payload: dict = {
        "intent": {
            "goal": "baseline_reproduction",
            "expected_baseline": {"metric": "eval_acc", "value": 0.95},
            "tolerance": {"direction": "higher_is_better", "margin": 0.02},
        },
        "code": {
            "content_sha256": "sha256:" + "f" * 64,
            "scope": {"kind": "entry_script", "files": ["train.py"], "root": None},
        },
        "seeds": {"dataloader": 7, "main": 42, "numpy": 12345},
        "data_ref": {
            "uri": "s3://bucket/dataset.csv",
            "content_sha256": "sha256:" + "a" * 64,
            "size_bytes": 1048576,
        },
        "config": {"lr": 0.001, "batch_size": 32},
        "contract_version": "2.0",
        "metrics": {"loss": 0.3},
        "worker_spec": None,  # None → absent-leaf drop
        "attribution": {
            "author": {"kind": "human", "id": "alice"},
            "committer": None,
            "operator": "alice",
            "signature": "sig-should-be-excluded",  # anti-recursion
        },
        "integrity": {"content_hash": "sha256:old", "hashed_fields": []},  # anti-recursion
    }

    # Act — build_integrity_object 호출 (DEFAULT _INTEGRITY_HASHED_FIELDS 사용)
    result, warnings = build_integrity_object(payload)

    # 독립 재계산 — build_integrity_object 를 호출하지 않는다
    _EXCLUDED = frozenset({"attribution.signature", "integrity"})
    fields_to_use = [f for f in _INTEGRITY_HASHED_FIELDS if f not in _EXCLUDED]
    subset = {
        path: _resolve_dotted(payload, path)
        for path in fields_to_use
        if _resolve_dotted(payload, path) is not None
    }
    expected_hash = _canonical_hash(subset)

    # Assert
    assert result is not None, "build_integrity_object 가 None 반환됨"
    assert warnings == [], f"예상치 않은 경고 발생: {warnings}"
    assert result["content_hash"] == expected_hash, (
        f"R15 byte-identical 불일치:\n"
        f"  build_integrity_object: {result['content_hash']!r}\n"
        f"  독립 재계산:            {expected_hash!r}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# C. BL-4: absent-leaf drop — data_ref 전체 부재 vs. content_sha256 만 None
# ─────────────────────────────────────────────────────────────────────────────

def test_integrity_hash_identical_when_data_ref_absent_vs_data_ref_content_sha_stripped():
    """BL-4: data_ref 전체 부재 레코드와 data_ref.content_sha256 이 None 인 레코드는 동일 hash.

    _INTEGRITY_HASHED_FIELDS 에서 data_ref 의 hash 입력은 data_ref.content_sha256 leaf 뿐이다.
    이 leaf 가 None 이면 subset 에서 제외(absent-leaf drop) → 전체 부재와 동일 hash 산출.

    Arrange:
      record_A = {intent, config, metrics} (data_ref 키 자체 없음)
      record_B = record_A + data_ref={uri="x", content_sha256=None, size_bytes=None}
    Act: build_integrity_object 각각 호출
    Assert: hash_A == hash_B
    """
    # Arrange
    base: dict = {
        "intent": {"goal": "ablation", "expected_baseline": None, "tolerance": None},
        "config": {"lr": 0.01},
        "metrics": {"loss": 0.5},
        "contract_version": "2.0",
    }
    record_a = dict(base)
    record_b = {
        **base,
        "data_ref": {
            "uri": "x",
            "content_sha256": None,  # PHI stripped 또는 미제공
            "size_bytes": None,
        },
    }

    # Act
    result_a, _ = build_integrity_object(record_a)
    result_b, _ = build_integrity_object(record_b)

    # Assert
    assert result_a is not None
    assert result_b is not None
    assert result_a["content_hash"] == result_b["content_hash"], (
        "BL-4 위반: data_ref.content_sha256 가 None 일 때 "
        "전체 data_ref 부재 레코드와 hash 가 달라야 하지 않음.\n"
        f"  hash_A (data_ref 없음): {result_a['content_hash']!r}\n"
        f"  hash_B (data_ref None):  {result_b['content_hash']!r}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# D. BL-2: 변조 탐지 — code / seeds / data_ref 각각 변조 시 hash 변경
# ─────────────────────────────────────────────────────────────────────────────

def _make_full_4pack_payload() -> dict:
    """BL-2 변조 탐지 테스트용 공통 payload 팩토리."""
    return {
        "intent": {"goal": "ablation", "expected_baseline": None, "tolerance": None},
        "code": {
            "content_sha256": "sha256:" + "0" * 64,
            "scope": {"kind": "entry_script", "files": ["train.py"], "root": None},
        },
        "seeds": {"main": 42, "numpy": 99},
        "data_ref": {
            "uri": "s3://bucket/data.csv",
            "content_sha256": "sha256:" + "1" * 64,
            "size_bytes": 1024,
        },
        "config": {"lr": 0.001},
        "contract_version": "2.0",
    }


def test_integrity_detects_code_content_sha_tampering():
    """BL-2: code.content_sha256 변조 시 integrity hash 가 변경된다.

    Arrange: 유효 payload 로 hash 계산
    Act: code.content_sha256 변경 후 재계산
    Assert: 두 hash 불일치 (변조 탐지)
    """
    # Arrange
    payload = _make_full_4pack_payload()
    result_before, _ = build_integrity_object(payload)
    assert result_before is not None

    # Act — code.content_sha256 변조
    tampered = _make_full_4pack_payload()
    tampered["code"]["content_sha256"] = "sha256:" + "FFFF" + "0" * 60
    result_after, _ = build_integrity_object(tampered)
    assert result_after is not None

    # Assert
    assert result_before["content_hash"] != result_after["content_hash"], (
        "BL-2 위반: code.content_sha256 변조가 integrity hash 에 반영되지 않음"
    )


def test_integrity_detects_code_scope_tampering():
    """BL-2 + NOTE-5: code.scope 변조 시 integrity hash 가 변경된다.

    scope 전체가 hashed_fields 에 포함되므로 scope.kind 변경도 hash 를 바꿔야 한다.

    Arrange: 유효 payload 로 hash 계산
    Act: code.scope.kind 변경 후 재계산
    Assert: 두 hash 불일치
    """
    # Arrange
    payload = _make_full_4pack_payload()
    result_before, _ = build_integrity_object(payload)
    assert result_before is not None

    # Act — scope.kind 변조
    tampered = _make_full_4pack_payload()
    tampered["code"]["scope"]["kind"] = "repo_subset"
    result_after, _ = build_integrity_object(tampered)
    assert result_after is not None

    # Assert
    assert result_before["content_hash"] != result_after["content_hash"], (
        "BL-2/NOTE-5 위반: code.scope.kind 변조가 integrity hash 에 반영되지 않음"
    )


def test_integrity_detects_seeds_tampering():
    """BL-2: seeds 값 변조 시 integrity hash 가 변경된다.

    Arrange: 유효 payload 로 hash 계산
    Act: seeds.main 값 변경 후 재계산
    Assert: 두 hash 불일치
    """
    # Arrange
    payload = _make_full_4pack_payload()
    result_before, _ = build_integrity_object(payload)
    assert result_before is not None

    # Act — seeds.main 변조
    tampered = _make_full_4pack_payload()
    tampered["seeds"]["main"] = 9999  # 42 → 9999
    result_after, _ = build_integrity_object(tampered)
    assert result_after is not None

    # Assert
    assert result_before["content_hash"] != result_after["content_hash"], (
        "BL-2 위반: seeds.main 변조가 integrity hash 에 반영되지 않음"
    )


def test_integrity_detects_data_ref_content_sha_tampering():
    """BL-2: data_ref.content_sha256 변조 시 integrity hash 가 변경된다 (일반 도메인).

    Arrange: 유효 payload 로 hash 계산
    Act: data_ref.content_sha256 변경 후 재계산
    Assert: 두 hash 불일치
    """
    # Arrange
    payload = _make_full_4pack_payload()
    result_before, _ = build_integrity_object(payload)
    assert result_before is not None

    # Act — data_ref.content_sha256 변조
    tampered = _make_full_4pack_payload()
    tampered["data_ref"]["content_sha256"] = "sha256:" + "2" * 64  # 1*64 → 2*64
    result_after, _ = build_integrity_object(tampered)
    assert result_after is not None

    # Assert
    assert result_before["content_hash"] != result_after["content_hash"], (
        "BL-2 위반: data_ref.content_sha256 변조가 integrity hash 에 반영되지 않음"
    )


# ─────────────────────────────────────────────────────────────────────────────
# E. BL-1: 확장 조건 + R6 backward-compat 회귀 방어
# ─────────────────────────────────────────────────────────────────────────────

def test_finalize_run_with_no_4pack_or_intent_omits_contract_version_and_integrity(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    """R6 CRITICAL: 4-pack 필드(code/seeds/data_ref) 와 intent 모두 없으면
    run_record 에 contract_version 과 integrity 가 나타나지 않는다.

    이 테스트는 BL-1 수정이 1.x 호환 경로를 깨뜨리지 않음을 보장하는
    핵심 회귀 방어 가드이다.

    Arrange: CQ_CONFIG_JSON 설정, 4-pack 인자 없이 save_all 호출
    Act: run_record.json 읽기
    Assert: 'contract_version', 'intent', 'integrity' 키 없음
    """
    # Arrange
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))
    history = [{"epoch": 0, "eval_loss": 0.6}]

    # Act
    pcq.save_all(history=history)
    rr = json.loads((tmp_path / "run_record.json").read_text())

    # Assert — 1.x 레코드 조건: 세 필드 모두 부재
    assert "contract_version" not in rr, (
        f"R6 위반: 1.x 경로에서 contract_version 이 나타남: {rr.get('contract_version')!r}"
    )
    assert "intent" not in rr, (
        "R6 위반: 1.x 경로에서 intent 가 나타남"
    )
    assert "integrity" not in rr, (
        "R6 위반: 1.x 경로에서 integrity 가 나타남"
    )
    assert "code" not in rr, "R6 위반: 1.x 경로에서 code 가 나타남"
    assert "seeds" not in rr, "R6 위반: 1.x 경로에서 seeds 가 나타남"
    assert "data_ref" not in rr, "R6 위반: 1.x 경로에서 data_ref 가 나타남"


def test_finalize_run_with_only_code_no_intent_emits_contract_version_and_integrity(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    """BL-1 확장: code 만 있고 intent 없어도 contract_version='2.0' 과 integrity 가 emit 된다.

    BL-1 수정 전에는 intent 가 없으면 contract_version 이 나타나지 않았다.
    수정 후: code / seeds / data_ref 중 하나라도 있으면 2.x 로 처리.

    Arrange: code_content_sha256 만 전달, intent_goal 없음
    Act: save_all → run_record 읽기
    Assert: contract_version=='2.0', code 존재, integrity 존재
    """
    # Arrange
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))
    sha = "sha256:" + "a" * 64

    # Act
    pcq.save_all(
        history=[{"epoch": 0, "eval_loss": 0.5}],
        code_content_sha256=sha,
        # intent_goal 없음 — BL-1 확장 경로
    )
    rr = json.loads((tmp_path / "run_record.json").read_text())

    # Assert
    assert rr.get("contract_version") == "2.0", (
        f"BL-1 위반: code 만 있을 때 contract_version '2.0' 없음: {rr.get('contract_version')!r}"
    )
    assert "code" in rr, "code 필드가 run_record 에 없음"
    assert "integrity" in rr, "integrity 필드가 run_record 에 없음"
    assert rr["integrity"]["content_hash"].startswith("sha256:")


def test_finalize_run_with_only_seeds_no_intent_emits_contract_version_and_integrity(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    """BL-1 확장: seeds 만 있고 intent 없어도 contract_version='2.0' 과 integrity 가 emit 된다.

    Arrange: seeds 만 전달, intent_goal 없음
    Act: save_all → run_record 읽기
    Assert: contract_version=='2.0', seeds 존재, integrity 존재
    """
    # Arrange
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))

    # Act
    pcq.save_all(
        history=[{"epoch": 0, "eval_loss": 0.5}],
        seeds={"main": 42},
        # intent_goal 없음 — BL-1 확장 경로
    )
    rr = json.loads((tmp_path / "run_record.json").read_text())

    # Assert
    assert rr.get("contract_version") == "2.0", (
        f"BL-1 위반: seeds 만 있을 때 contract_version '2.0' 없음: {rr.get('contract_version')!r}"
    )
    assert "seeds" in rr, "seeds 필드가 run_record 에 없음"
    assert "integrity" in rr, "integrity 필드가 run_record 에 없음"


def test_finalize_run_with_only_data_ref_no_intent_emits_contract_version_and_integrity(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    """BL-1 확장: data_ref 만 있고 intent 없어도 contract_version='2.0' 과 integrity 가 emit 된다.

    Arrange: data_ref_uri 만 전달, intent_goal 없음
    Act: save_all → run_record 읽기
    Assert: contract_version=='2.0', data_ref 존재, integrity 존재
    """
    # Arrange
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))

    # Act
    pcq.save_all(
        history=[{"epoch": 0, "eval_loss": 0.5}],
        data_ref_uri="cq://datasets/iris@v1",
        # intent_goal 없음 — BL-1 확장 경로
    )
    rr = json.loads((tmp_path / "run_record.json").read_text())

    # Assert
    assert rr.get("contract_version") == "2.0", (
        f"BL-1 위반: data_ref 만 있을 때 contract_version '2.0' 없음: {rr.get('contract_version')!r}"
    )
    assert "data_ref" in rr, "data_ref 필드가 run_record 에 없음"
    assert "integrity" in rr, "integrity 필드가 run_record 에 없음"


# ─────────────────────────────────────────────────────────────────────────────
# F. NOTE-1 conformance shadow guard — fixture hash 독립 재계산
# ─────────────────────────────────────────────────────────────────────────────

def test_conformance_pcq_2x_full_fixture_integrity_hash_matches_canonical_recompute():
    """NOTE-1: pcq-2x-full conformance fixture 의 integrity.content_hash 가
    canonical 재계산 값과 일치한다.

    NOTE-1 이 지적한 placeholder-hides-ordering-bug 위험을 감지하는 shadow guard.
    이 테스트가 실패하면 fixture 의 content_hash 가 실제 계산값과 다르다 —
    순서 버그 또는 absent-leaf drop 불일치를 의미한다.

    Arrange: conformance fixture run_record.json 로드 + hashed_fields 추출
    Act: 동일 subset 으로 독립 재계산 (build_integrity_object 미호출)
    Assert: stored content_hash == 독립 재계산 hash
    """
    # Arrange
    assert CONFORMANCE_FIXTURE.exists(), (
        f"conformance fixture 가 없음: {CONFORMANCE_FIXTURE}"
    )
    rr = json.loads(CONFORMANCE_FIXTURE.read_text(encoding="utf-8"))
    stored_hash = rr["integrity"]["content_hash"]
    hashed_fields = rr["integrity"]["hashed_fields"]

    # 독립 재계산 — build_integrity_object 를 호출하지 않는다
    _EXCLUDED = frozenset({"attribution.signature", "integrity"})
    fields_to_use = [f for f in hashed_fields if f not in _EXCLUDED]
    subset = {
        path: _resolve_dotted(rr, path)
        for path in fields_to_use
        if _resolve_dotted(rr, path) is not None
    }
    computed_hash = _canonical_hash(subset)

    # Assert
    assert stored_hash == computed_hash, (
        "NOTE-1 shadow guard 실패: fixture 의 integrity.content_hash 가 "
        "독립 재계산값과 다름.\n"
        f"  stored:   {stored_hash!r}\n"
        f"  computed: {computed_hash!r}\n"
        "fixture 를 재생성하거나 build_integrity_object 의 canonical form 을 확인하세요."
    )


# ─────────────────────────────────────────────────────────────────────────────
# G. S5 시나리오: describe_run 이 4-pack 필드를 nested + flat 모두 노출
# ─────────────────────────────────────────────────────────────────────────────

def test_describe_run_with_4pack_record_exposes_nested_and_flat_fields(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    """S5: describe_run 이 code / seeds / data_ref 를 nested 와 flat 표면 모두 노출한다.

    T-PCQRP-5 구현 검증: describe_run 이 run_record 에서 4-pack 필드를 읽어
    RunDescription 의 중첩 속성(code, seeds, data_ref)과 플랫 속성
    (code_content_sha256, seeds_main, seeds_count, data_ref_uri) 을 모두 채워야 한다.

    Arrange: code + seeds + data_ref 포함 run_record.json 수동 작성
    Act: describe_run(tmp_path)
    Assert: nested 속성(dict) + flat 속성(scalar) 모두 올바른 값
    """
    # Arrange — 최소 run_record 작성 (save_all 미사용 — 격리 목적)
    sha_code = "sha256:" + "c" * 64
    sha_data = "sha256:" + "d" * 64
    rr: dict = {
        "schema_version": 1,
        "run": {"id": "test-s5-run", "status": "completed"},
        "execution": {"cmd": "uv run python train.py"},
        "source": {},
        "environment": {},
        "metrics": {"declared": [], "history_path": "metrics.json"},
        "artifacts": [],
        "validation": {"status": "pass", "report_path": "validation_report.json"},
        "code": {
            "content_sha256": sha_code,
            "scope": {"kind": "file_list", "files": ["train.py", "model.py"], "root": None},
        },
        "seeds": {"main": 42, "numpy": 99},
        "data_ref": {
            "uri": "cq://datasets/iris@abc123",
            "content_sha256": sha_data,
            "size_bytes": 4096,
        },
        "contract_version": "2.0",
    }
    rr_path = tmp_path / "run_record.json"
    rr_path.write_text(json.dumps(rr))

    # Act
    desc = describe_run(tmp_path)

    # Assert — nested 속성
    assert desc.code is not None, "describe_run: code nested dict 가 None"
    assert desc.code["content_sha256"] == sha_code
    assert desc.seeds is not None, "describe_run: seeds nested dict 가 None"
    assert desc.data_ref is not None, "describe_run: data_ref nested dict 가 None"

    # Assert — flat 표면 (에이전트 쿼리 편의)
    assert desc.code_content_sha256 == sha_code, (
        f"describe_run.code_content_sha256 불일치: {desc.code_content_sha256!r}"
    )
    assert desc.seeds_main == 42, (
        f"describe_run.seeds_main 불일치: {desc.seeds_main!r}"
    )
    assert desc.seeds_count == 2, (
        f"describe_run.seeds_count 불일치: {desc.seeds_count!r}"
    )
    assert desc.data_ref_uri == "cq://datasets/iris@abc123", (
        f"describe_run.data_ref_uri 불일치: {desc.data_ref_uri!r}"
    )

    # Assert — contract_version 존재 (2.x 레코드 확인)
    assert desc.contract_version == "2.0", (
        f"describe_run.contract_version 불일치: {desc.contract_version!r}"
    )


# ─────────────────────────────────────────────────────────────────────────────
# S1 보완: 4-pack 전체 일반 emit 시나리오 (save_all 통합)
# ─────────────────────────────────────────────────────────────────────────────

def test_save_all_with_full_4pack_general_domain_emits_all_fields_in_run_record(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    """S1: code + seeds + data_ref (일반 도메인) 포함 save_all 이
    run_record 에 모든 4-pack 필드와 integrity 를 올바르게 기록한다.

    Arrange: code + seeds + data_ref 인자 포함 save_all 호출
    Act: run_record.json 읽기
    Assert: code / seeds / data_ref / integrity / contract_version 모두 존재하고
            data_ref.content_sha256 가 보존됨
    """
    # Arrange
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))
    sha_code = "sha256:" + "0" * 64
    sha_data = "sha256:" + "1" * 64

    # Act
    pcq.save_all(
        history=[{"epoch": 0, "eval_acc": 0.99}],
        code_content_sha256=sha_code,
        code_scope={"kind": "entry_script", "files": ["train.py"], "root": None},
        seeds={"main": 42, "numpy": 777},
        data_ref_uri="s3://bucket/dataset.csv",
        data_ref_content_sha256=sha_data,
        data_ref_size_bytes=2048,
    )
    rr = json.loads((tmp_path / "run_record.json").read_text())

    # Assert — 4-pack 필드 존재
    assert "code" in rr, "code 필드 없음"
    assert "seeds" in rr, "seeds 필드 없음"
    assert "data_ref" in rr, "data_ref 필드 없음"
    assert "integrity" in rr, "integrity 필드 없음"
    assert rr.get("contract_version") == "2.0"

    # content_sha256 보존 (일반 도메인)
    assert rr["code"]["content_sha256"] == sha_code
    assert rr["data_ref"]["content_sha256"] == sha_data, (
        "일반 도메인에서 data_ref.content_sha256 이 보존되어야 함"
    )
    # seeds 정렬 (R15)
    assert list(rr["seeds"].keys()) == sorted(rr["seeds"].keys())


# ─────────────────────────────────────────────────────────────────────────────
# S2 보완: PHI 도메인 data_ref content_sha256 strip 통합 (save_all 경로)
# ─────────────────────────────────────────────────────────────────────────────

def test_save_all_with_phi_domain_strips_data_ref_content_sha256_in_run_record(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    """S2: medical 도메인 fingerprint 존재 시 save_all 이
    data_ref.content_sha256 을 null 로 처리한다.

    R5/R5b PHI 게이트: save_all → build_data_ref_object 에 domain 전달.
    fingerprint domain='medical' 이면 data_ref.content_sha256 null 처리.

    Arrange: medical fingerprint + data_ref_content_sha256 포함 save_all 호출
    Act: run_record.json 읽기
    Assert: data_ref.content_sha256 is None
    """
    # Arrange
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))
    sha_data = "sha256:" + "2" * 64

    # medical 도메인 fingerprint 를 직접 환경변수로 주입
    # (pcq.fingerprint() 를 호출하지 않고 core 캐시를 직접 세팅하는 방법 대신
    #  build_data_ref_object 단위 게이트만 검증하는 것으로 대체 — 통합 경로에서는
    #  finalize_run BL-3 gate 가 보호하므로 finalize_run 직접 호출로 검증)
    from pcq.contract import finalize_run

    # 단일 호출: fingerprint 포함 finalize_run 경로로 직접 검증
    sha_code = "sha256:" + "3" * 64
    code_obj, _ = build_code_object(content_sha256=sha_code, scope=None)
    data_ref_obj_with_sha, _ = build_data_ref_object(
        uri="cq://medical/patient-data@v1",
        content_sha256=sha_data,
        size_bytes=512,
        domain="general",  # builder 에는 general 전달 — lifecycle gate 테스트
    )
    fingerprint_medical = {"domain": "medical", "modality": "tabular"}

    finalize_run(
        output_dir=tmp_path,
        run_code=code_obj,
        run_data_ref=data_ref_obj_with_sha,  # sha 포함
        fingerprint=fingerprint_medical,     # BL-3 방어 게이트 트리거
    )
    rr = json.loads((tmp_path / "run_record.json").read_text())

    # Assert — BL-3 lifecycle gate 가 sha 를 null 로 처리해야 함
    assert "data_ref" in rr, "data_ref 필드 없음"
    assert rr["data_ref"]["content_sha256"] is None, (
        f"S2/BL-3 위반: medical domain 에서 data_ref.content_sha256 이 null 이 아님: "
        f"{rr['data_ref']['content_sha256']!r}"
    )
