"""SPEC.md 불변 조건 — R8 한계 문장 등 mechanical guard.

문서 drift 방지: spec/SPEC.md에 명시된 핵심 invariant 문자열이
사람의 손에 의해 의도치 않게 사라지지 않도록 보장한다.
"""
from __future__ import annotations

from pathlib import Path


SPEC_PATH = Path(__file__).resolve().parent.parent / "spec" / "SPEC.md"


def test_spec_R8_code_attestation_limitation_sentence_present() -> None:
    """R8: code.content_sha256 한계 문장이 SPEC.md에 정확히 존재해야 한다."""
    required = (
        "code.content_sha256은 어떤 코드가 기록되었는지만 증명한다. "
        "그 코드가 실제로 실행되어 이 출력을 만들었는지는 증명하지 않는다. "
        "인과 attestation은 별도."
    )
    text = SPEC_PATH.read_text(encoding="utf-8")
    assert required in text, (
        f"R8 한계 문장이 spec/SPEC.md에 없습니다. 정확한 문자열로 박혀 있어야 합니다.\n"
        f"필요: {required!r}"
    )


def test_spec_intent_reframe_assertion_sentence_present() -> None:
    """① 정체성 정합: intent 재프레이밍 한 문장이 SPEC.md에 정확히 존재해야 한다."""
    required = (
        "intent는 *기록자의 주장*을 보존한다 — pcq는 그 주장의 진위를 판단하지 않는다. "
        "주장 내용이 의견이어도 *주장이 있었다는 것은 사실*이다."
    )
    text = SPEC_PATH.read_text(encoding="utf-8")
    assert required in text, (
        f"intent 재프레이밍 한 문장이 spec/SPEC.md에 없습니다. 정확한 문자열로 박혀 있어야.\n"
        f"필요: {required!r}"
    )
