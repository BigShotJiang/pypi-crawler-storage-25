"""pcq.log_config — declared hyperparam을 config evidence 본문으로 노출 (P5)."""
import json

import pytest

import pcq


@pytest.fixture(autouse=True)
def _reset_collected_config():
    # log_config 모듈-state를 테스트 간 격리한다.
    from pcq.core import _reset_collected_config as reset

    reset()
    yield
    reset()


def _setup_cfg(tmp_path, **extra):
    cfg = {"output_dir": str(tmp_path), "seed": 42}
    cfg.update(extra)
    p = tmp_path / "cfg.json"
    p.write_text(json.dumps(cfg))
    return p


def test_log_config_declared_hyperparam_appears_in_config_evidence(tmp_path, monkeypatch):
    """log_config로 선언한 hyperparam은 RunRecord.config.hyperparams 본문에 노출된다."""
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))
    pcq.log_config(lr=0.001, batch_size=64)
    pcq.save_all(history=[{"epoch": 0, "eval_acc": 0.5}])
    rr = json.loads((tmp_path / "run_record.json").read_text())
    assert rr["config"]["hyperparams"]["lr"] == 0.001
    assert rr["config"]["hyperparams"]["batch_size"] == 64


def test_log_config_when_secret_keyword_then_blocked_from_evidence(tmp_path, monkeypatch):
    """시크릿 키워드(key/token 등)는 선언해도 본문 노출되지 않는다 (heuristic 차단)."""
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))
    pcq.log_config(lr=0.001, api_key="sk-secret", hf_token="hf_xxx")
    pcq.save_all(history=[{"epoch": 0, "eval_acc": 0.5}])
    rr = json.loads((tmp_path / "run_record.json").read_text())
    hp = rr["config"]["hyperparams"]
    assert hp["lr"] == 0.001
    assert "api_key" not in hp
    assert "hf_token" not in hp


def test_config_evidence_when_no_log_config_then_hash_only(tmp_path, monkeypatch):
    """log_config 미호출 시 hyperparams 키 없이 기존 hash-only 표현을 유지한다."""
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))
    pcq.save_all(history=[{"epoch": 0, "eval_acc": 0.5}])
    rr = json.loads((tmp_path / "run_record.json").read_text())
    assert "hyperparams" not in rr["config"]
    assert rr["config"]["config_json_sha256"]


def test_describe_run_exposes_logged_hyperparams(tmp_path, monkeypatch):
    """describe_run의 reproducibility_evidence.config가 선언된 hyperparam을 노출한다."""
    monkeypatch.setenv("CQ_CONFIG_JSON", str(_setup_cfg(tmp_path)))
    pcq.log_config(lr=0.001, batch_size=64)
    pcq.save_all(history=[{"epoch": 0, "eval_acc": 0.5}])
    data = pcq.describe_run(tmp_path).to_dict()
    hp = data["reproducibility_evidence"]["config"]["hyperparams"]
    assert hp["lr"] == 0.001
    assert hp["batch_size"] == 64
