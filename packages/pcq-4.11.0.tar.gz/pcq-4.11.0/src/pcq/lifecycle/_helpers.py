"""pcq.lifecycle._helpers — lifecycle-private helper 함수 모음.

T-PCQA-LH: contract.py에서 분리된 ~25개 lifecycle-private helpers.
save_*/finalize_run 전용 내부 구현. public surface 변경 없음 (all underscore-private).
contract.py에서 re-export로 backward-compat 100% 유지.

이 모듈은 pcq.contract를 import하지 않는다 (circular import 방지).
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# manifest schema v2 enrich 시 sha256 계산 chunk 크기 (1 MiB).
_SHA256_CHUNK_SIZE = 1 << 20


# manifest 자동 검출 시 확장자 → kind 매핑.
_KIND_BY_SUFFIX: dict[str, str] = {
    ".pt": "model",
    ".pth": "model",
    ".pkl": "model",
    ".joblib": "model",
    ".safetensors": "model",
    ".bin": "model",
    ".onnx": "model",
    ".ckpt": "checkpoint",
}

# 특수 파일명 → kind. None 이면 manifest 에서 제외 (자기참조 회피).
_SPECIAL_FILES: dict[str, str | None] = {
    "metrics.json": "metrics",
    "config.json": "config",
    "run_summary.json": "summary",
    "manifest.json": None,
}

_LOCKFILE_NAMES: tuple[str, ...] = (
    "uv.lock", "poetry.lock", "pdm.lock", "conda-lock.yml",
    "Pipfile.lock", "requirements.lock",
)
# Walk up at most this many ancestor directories looking for a lockfile.
_LOCKFILE_ANCESTOR_LIMIT = 8


def _run_git(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    """Run git with a bounded timeout. Callers handle return codes."""
    return subprocess.run(
        ["git", *args],
        cwd=str(cwd) if cwd is not None else None,
        capture_output=True,
        text=True,
        timeout=5,
    )


def _git_sha(cwd: Path | None = None) -> str:
    """현재 git HEAD sha. git 없거나 timeout 이면 빈 문자열."""
    try:
        out = _run_git(["rev-parse", "HEAD"], cwd=cwd)
        return out.stdout.strip() if out.returncode == 0 else ""
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""


def _pcq_version() -> str:
    """cq 패키지 __version__. 실패 시 'unknown'."""
    try:
        from pcq import __version__

        return __version__
    except ImportError:
        return "unknown"


def _cq_config_available() -> bool:
    """CQ_CONFIG_JSON env var 가 설정되어 있는지."""

    return bool(os.environ.get("CQ_CONFIG_JSON"))


def _classify_exception(exc: BaseException) -> tuple[str, str, dict]:
    """(error_code, category, evidence) 자동 분류 (v2.11).

    명시 pcq.save_all(failure={...}) 가 우선. 자동 분류는 unhandled exception
    폴백용 — caller 가 except 블록에서 호출.

    pcq 은 enum + structured field 만 발급. suggested_fix 자연어 생성은
    하지 않는다 (agent 정책 영역).
    """
    if isinstance(exc, ImportError):
        # exc.name (3.6+) 우선, fallback 으로 exception 메시지.
        module = getattr(exc, "name", None) or str(exc)
        return (
            "ERR_MISSING_DEPENDENCY",
            "missing_dependency",
            {"module": str(module), "exception_type": type(exc).__name__},
        )
    if isinstance(exc, MemoryError):
        return (
            "ERR_OUT_OF_MEMORY",
            "oom",
            {"exception_type": type(exc).__name__},
        )
    if isinstance(exc, TimeoutError):
        return (
            "ERR_TIMEOUT",
            "timeout",
            {"exception_type": type(exc).__name__},
        )
    if isinstance(exc, FileNotFoundError):
        return (
            "ERR_DATASET_UNAVAILABLE",
            "dataset_missing",
            {
                "exception_type": type(exc).__name__,
                "path": str(getattr(exc, "filename", "") or ""),
            },
        )
    return (
        "ERR_RUNTIME",
        "unknown_exception",
        {"exception_type": type(exc).__name__},
    )


def _normalize_failure(failure: dict | None) -> dict | None:
    """failure dict 를 v2.11 FailureInfo schema 로 정규화.

    - error_code 미지정 + category 있으면 derive (category_to_error_code).
    - evidence 미지정이면 빈 dict 보장.
    - suggested_fix 는 agent 영역 — 손대지 않는다 (자연어 보존).
    """
    if not failure:
        return failure
    from pcq.agent.run_record import FailureInfo

    info = FailureInfo.from_dict(failure)
    # FailureInfo.to_dict 는 빈 값 제거 — 그러나 evidence 는 의미 있으면 명시 보존.
    out = info.to_dict()
    # caller 가 명시한 추가 키 (예: agent 가 추가한 future-proof 필드) 보존.
    for k, v in failure.items():
        if k in ("error_code", "category", "message", "evidence", "suggested_fix"):
            continue
        out[k] = v
    # evidence 가 빈 dict 라도 enum 명시면 노출 (agent 가 키 존재 여부로 분기).
    if "error_code" in out and "evidence" not in out:
        out["evidence"] = {}
    return out


def _resolve_write_context(
    cfg: dict | None = None,
    output_dir: str | Path | None = None,
    project_root: str | Path | None = None,
):
    """contract helper용 RunContext — write-side mkdir 단일 경로.

    Priority for output_dir: explicit output_dir → explicit cfg["output_dir"]
    → CQ_CONFIG_JSON → cq.yaml.configs.output_dir → project_root/output.
    cfg 가 명시되면 그것의 output_dir 이 RunContext 의 output_dir 로 override
    된다.
    """
    from pcq.agent.resolver import resolve_run_context

    explicit_out = output_dir
    if explicit_out is None and cfg is not None and "output_dir" in cfg:
        explicit_out = cfg["output_dir"]
    return resolve_run_context(
        path=project_root,
        output_dir=explicit_out,
        ensure_output_dir=True,
    )


def _autodetect_files(out_dir: Path) -> list[dict]:
    """output_dir 스캔 + extension 기반 kind heuristic."""
    files: list[dict] = []
    for p in sorted(out_dir.iterdir()):
        if not p.is_file():
            continue
        name = p.name
        if name in _SPECIAL_FILES:
            kind = _SPECIAL_FILES[name]
            if kind is None:
                # manifest.json 자기 자신 제외
                continue
        else:
            kind = _KIND_BY_SUFFIX.get(p.suffix, "other")
        files.append({"path": name, "kind": kind})
    return files


def _sha256_file(path: Path, chunk_size: int = _SHA256_CHUNK_SIZE) -> str:
    """파일의 sha256 hex digest. 1MB chunked read 로 메모리 효율 유지."""
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _file_metadata(out_dir: Path, rel_path: str) -> dict:
    """schema v2 enrich 용 sha256 + size_bytes + created_at 계산.

    파일이 존재하지 않으면 빈 dict 반환 (caller 가 안전하게 spread 가능).
    """
    full_path = out_dir / rel_path
    if not full_path.exists():
        return {}
    stat = full_path.stat()
    # mtime 기반 ISO-8601 UTC. 'Z' suffix 로 RFC3339 형태 정규화.
    created_at = (
        datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)
        .isoformat()
        .replace("+00:00", "Z")
    )
    return {
        "sha256": _sha256_file(full_path),
        "size_bytes": stat.st_size,
        "created_at": created_at,
    }


def _find_best(
    history: list[dict], monitor: str, mode: str
) -> dict | None:
    """history 에서 monitor key 가 있는 entry 들 중 best 선택."""
    eligible = [(i, e) for i, e in enumerate(history) if monitor in e]
    if not eligible:
        return None
    if mode == "min":
        idx, entry = min(eligible, key=lambda x: x[1][monitor])
    else:
        idx, entry = max(eligible, key=lambda x: x[1][monitor])
    return {
        "epoch": int(entry.get("epoch", idx)),
        "metrics": {
            k: float(v)
            for k, v in entry.items()
            if k != "epoch" and isinstance(v, (int, float))
        },
        "checkpoint": "best.ckpt",
    }


def _last_epoch(history: list[dict]) -> dict | None:
    """history 의 마지막 epoch entry 요약."""
    if not history:
        return None
    e = history[-1]
    return {
        "epoch": int(e.get("epoch", len(history) - 1)),
        "metrics": {
            k: float(v)
            for k, v in e.items()
            if k != "epoch" and isinstance(v, (int, float))
        },
        "checkpoint": "last.ckpt",
    }


def _git_dirty(cwd: Path | None = None) -> bool:
    """`git status --porcelain` 비어있지 않으면 True (dirty repo).

    git 없거나 timeout 이면 False (보수적 — clean 으로 본다).
    """
    try:
        out = _run_git(["status", "--porcelain"], cwd=cwd)
        return bool(out.stdout.strip()) if out.returncode == 0 else False
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _git_changed_files(cwd: Path | None = None) -> list[str]:
    """`git status --porcelain` 기반 변경 파일 목록.

    `git diff --name-only`와 달리 untracked 파일도 포함한다. rename 은 새
    경로를 기록한다.
    """
    try:
        out = _run_git(["status", "--porcelain"], cwd=cwd)
        if out.returncode != 0:
            return []
        files: list[str] = []
        for line in out.stdout.splitlines():
            if not line.strip():
                continue
            path = line[3:].strip()
            if " -> " in path:
                path = path.split(" -> ", 1)[1].strip()
            if path:
                files.append(path)
        return sorted(set(files))
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def _git_patch_sha256(cwd: Path | None = None) -> str | None:
    """`git diff HEAD` 의 sha256 — patch identity. 변경 없으면 None."""
    try:
        out = _run_git(["diff", "HEAD"], cwd=cwd)
        if out.returncode != 0 or not out.stdout:
            return None
        return hashlib.sha256(out.stdout.encode("utf-8")).hexdigest()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def _find_lockfile(start: Path | None = None) -> tuple[str, Path] | None:
    """start부터 ancestor 디렉토리를 walk-up하며 lockfile 탐색.

    project root marker(.git, pyproject.toml)에 도달하면 stop —
    nested project가 부모 project의 lockfile을 잘못 가져오지 않도록.

    Returns:
        (lockfile_name, absolute_path) 또는 None.
    """
    cwd = (start or Path.cwd()).resolve()
    ancestors = [cwd, *cwd.parents][:_LOCKFILE_ANCESTOR_LIMIT]
    for d in ancestors:
        for name in _LOCKFILE_NAMES:
            p = d / name
            if p.exists():
                return name, p
        # 같은 디렉토리에서 lockfile 없으면 project root marker 검사 후 stop.
        if (d / ".git").exists() or (d / "pyproject.toml").exists():
            return None
    return None


def _environment_snapshot(project_root: Path | None = None) -> dict:
    """python 버전 + platform + lockfile sha256 (자동 감지).

    lockfile은 cwd부터 ancestor를 walk-up하며 탐색 (uv.lock > poetry.lock >
    Pipfile.lock > requirements.lock 우선순위). project root (.git 또는
    pyproject.toml 있는 디렉토리)에 도달하면 ascent 중단 — nested project가
    부모 project의 lockfile을 잘못 가져오지 않도록.
    """
    out: dict[str, Any] = {
        "python": sys.version.split()[0],
        "platform": f"{platform.system()}-{platform.machine()}",
        "pcq_version": _pcq_version(),
    }
    try:
        import torch

        cuda_available = bool(torch.cuda.is_available())
        out["torch_version"] = str(torch.__version__)
        out["cuda_available"] = cuda_available
        out["cuda_version"] = getattr(torch.version, "cuda", None)
        out["device"] = "cuda" if cuda_available else "cpu"
        if cuda_available:
            out["gpu_count"] = int(torch.cuda.device_count())
            if torch.cuda.device_count() > 0:
                out["gpu_model"] = str(torch.cuda.get_device_name(0))
    except Exception:  # noqa: BLE001 — torch import/runtime probing is best-effort
        out["device"] = "unknown"

    world_size = os.environ.get("WORLD_SIZE")
    if world_size:
        try:
            out["world_size"] = int(world_size)
        except ValueError:
            pass

    found = _find_lockfile(project_root)
    if found is not None:
        name, p = found
        out["lockfile"] = name
        out["lockfile_sha256"] = _sha256_file(p)
    return out


def _relative_path(path: Path, root: Path | None) -> str:
    if root is None:
        return str(path)
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def _source_snapshot(
    record_patch: bool = False,
    project_root: Path | None = None,
    cq_yaml_path: Path | None = None,
) -> dict:
    """git_sha + dirty (+ optional patch_sha256, changed_files)."""
    sha = _git_sha(project_root)
    dirty = _git_dirty(project_root)
    out: dict[str, Any] = {"git_sha": sha, "dirty": dirty}
    if dirty:
        out["changed_files"] = _git_changed_files(project_root)
        if record_patch:
            out["patch_sha256"] = _git_patch_sha256(project_root)
    if cq_yaml_path is not None and cq_yaml_path.exists():
        out["cq_yaml_path"] = _relative_path(cq_yaml_path, project_root)
        out["cq_yaml_sha256"] = _sha256_file(cq_yaml_path)
    return out


def _read_cq_yaml_inputs_and_metrics() -> tuple[dict, list[dict]]:
    """cq.yaml 의 inputs section + metrics schema declarations 추출.

    cq.yaml 이 없거나 파싱 실패하면 (빈 dict, []) 반환.
    Inputs 의 cq:// URI 등은 opaque 하게 그대로 유지.
    """
    cq_yaml_path = Path("cq.yaml")
    if not cq_yaml_path.exists():
        return {}, []
    try:
        from pcq.agent.yaml_io import read_yaml

        cqy = read_yaml(cq_yaml_path)
    except Exception:  # noqa: BLE001 — yaml read 다양한 예외, opaque
        return {}, []
    if not isinstance(cqy, dict):
        return {}, []

    raw_inputs = cqy.get("inputs", {})
    inputs = (
        {str(k): _flatten_yaml_value(v) for k, v in raw_inputs.items()}
        if isinstance(raw_inputs, dict)
        else {}
    )

    metrics_decl: list[dict] = []
    mraw = cqy.get("metrics", [])
    if isinstance(mraw, dict):
        for name, schema in mraw.items():
            entry: dict[str, Any] = {"name": str(name)}
            if isinstance(schema, dict):
                for k in ("mode", "split", "aggregation", "sample_count"):
                    if k in schema:
                        entry[k] = schema[k]
            metrics_decl.append(entry)
    elif isinstance(mraw, list):
        for name in mraw:
            metrics_decl.append({"name": str(name)})

    return inputs, metrics_decl


def _flatten_yaml_value(value: Any) -> Any:
    """ruamel CommentedMap/CommentedSeq → 일반 dict/list (JSON 직렬화)."""
    if isinstance(value, dict):
        return {str(k): _flatten_yaml_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_flatten_yaml_value(v) for v in value]
    return value


# config evidence 본문 노출 시 차단할 시크릿 키워드 (대소문자 무시 부분 일치).
# fingerprint PII heuristic(R5b)과 같은 다층 패턴, config 도메인 키워드.
_SECRET_KEYWORDS: frozenset[str] = frozenset(
    {
        "secret",
        "token",
        "password",
        "passwd",
        "credential",
        "apikey",
        "api_key",
        "access_key",
        "private_key",
        "auth",
    }
)


def _is_secret_key(name: str) -> bool:
    # 키 이름에 시크릿 키워드가 부분 일치하면 evidence 노출 차단.
    low = name.lower()
    return any(kw in low for kw in _SECRET_KEYWORDS)


def _config_evidence_snapshot(rc: Any, cfg: dict, output_dir: Path) -> dict:
    """RunRecord.config evidence.

    Stores identity, not the full resolved config, so records stay compact and
    secrets accidentally injected through config are not copied again.

    log_config 로 선언된 hyperparam 은 본문(`hyperparams`)으로 노출하되, 시크릿
    키워드를 포함한 키는 차단한다 (declared 화이트리스트 + heuristic 안전망).
    """
    out: dict[str, Any] = {}
    project_root = rc.project_root
    cq_yaml_path = rc.cq_yaml_path
    if cq_yaml_path is not None and cq_yaml_path.exists():
        out["cq_yaml_path"] = _relative_path(cq_yaml_path, project_root)
        out["cq_yaml_sha256"] = _sha256_file(cq_yaml_path)
    config_json = output_dir / "config.json"
    if config_json.exists():
        out["config_json_path"] = "config.json"
        out["config_json_sha256"] = _sha256_file(config_json)
    seed = cfg.get("seed", cfg.get("random_seed"))
    if seed is not None:
        out["seed"] = seed
    if "strictness" in cfg:
        out["strictness"] = cfg.get("strictness")
    out["output_dir"] = _relative_path(output_dir, project_root)

    # log_config 로 선언된 hyperparam 본문 노출 (시크릿 키워드는 차단).
    from pcq.core import _collected_config_snapshot

    declared = _collected_config_snapshot()
    hyperparams = {k: v for k, v in declared.items() if not _is_secret_key(k)}
    if hyperparams:
        out["hyperparams"] = hyperparams
    return out


def _input_evidence_summary(inputs: dict) -> dict:
    """Compact input identity coverage for validators and agents."""
    identity: dict[str, dict[str, bool]] = {}
    for name, meta in inputs.items():
        if not isinstance(meta, dict):
            identity[str(name)] = {
                "has_uri": False,
                "has_path": False,
                "has_sha256": False,
                "has_manifest": False,
                "opaque": False,
            }
            continue
        identity[str(name)] = {
            "has_uri": bool(meta.get("uri")),
            "has_path": bool(meta.get("path")),
            "has_sha256": bool(meta.get("sha256")),
            "has_manifest": bool(meta.get("manifest")),
            "opaque": bool(meta.get("opaque")),
        }
    return {
        "count": len(inputs),
        "names": sorted(str(k) for k in inputs),
        "identity": identity,
    }


def _now_utc_iso() -> str:
    """ISO-8601 UTC string with 'Z' suffix (RFC3339 normalized)."""
    return datetime.now(tz=timezone.utc).isoformat().replace("+00:00", "Z")


def _atomic_write_json(target: Path, payload: dict) -> None:
    """Atomic JSON dump via tmp + os.replace.

    Readers are guaranteed to see either the previous valid JSON or the new one
    — never a half-written file. Uses unique tmp suffix to avoid concurrent
    finalize collisions.
    """
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp = target.parent / f".{target.name}.tmp.{uuid.uuid4().hex[:8]}"
    tmp.write_text(
        json.dumps(payload, indent=2, sort_keys=True, default=str), encoding="utf-8"
    )
    os.replace(str(tmp), str(target))
