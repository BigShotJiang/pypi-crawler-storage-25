"""pcq.lifecycle — record write lifecycle (save_*, finalize_run, save_all).

T-PCQA-LC에서 contract.py에서 분리. record 작성 경로 핵심.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pcq.lifecycle._helpers import (
    _resolve_write_context, _atomic_write_json, _file_metadata,
    _autodetect_files, _find_best, _last_epoch, _relative_path, _source_snapshot,
    _config_evidence_snapshot, _input_evidence_summary,
    _normalize_failure,
    _environment_snapshot,
    _git_sha,
    _pcq_version, _now_utc_iso,
)
from pcq.builders import (
    build_attribution_object, build_intent_object, build_integrity_object,
    build_worker_spec_object, build_fingerprint_object,
    build_code_object, build_seeds_object, build_data_ref_object,
    _PHI_DOMAINS,
)


def save_config_snapshot(
    extra: dict | None = None,
    cfg: dict | None = None,
    output_dir: str | Path | None = None,
    project_root: str | Path | None = None,
) -> Path:
    """cfg + provenance 를 output_dir/config.json 에 저장.

    추가 metadata: _git_sha, _pcq_version. extra 가 주어지면 merge.

    Args:
        extra: 추가 metadata (예: {"_recipe": "...", "_overrides": [...]}).
        cfg: 명시 cfg dict. None 이면 RunContext 의 cfg (cq.yaml.configs +
             CQ_CONFIG_JSON merge) 사용. Experiment 처럼 in-memory cfg 가
             권위 있는 경우 명시 전달.

    Returns:
        config.json Path.
    """
    ctx = _resolve_write_context(
        cfg, output_dir=output_dir, project_root=project_root
    )
    if cfg is None:
        cfg = dict(ctx.cfg)
    snapshot = dict(cfg)
    snapshot.setdefault("output_dir", str(ctx.output_dir))
    snapshot["_git_sha"] = _git_sha()
    snapshot["_pcq_version"] = _pcq_version()
    if extra:
        snapshot.update(extra)
    path = ctx.output_dir / "config.json"
    path.write_text(
        json.dumps(snapshot, indent=2, default=str), encoding="utf-8"
    )
    return path


def save_metrics(
    history: list[dict],
    output_dir: str | Path | None = None,
    project_root: str | Path | None = None,
) -> Path:
    """epoch 별 metrics history 를 output_dir/metrics.json 에 저장.

    Args:
        history: list of dicts. 각 entry 는 {"epoch": int, ...metric_key: value}.

    Returns:
        metrics.json Path.
    """
    ctx = _resolve_write_context(
        output_dir=output_dir, project_root=project_root
    )
    path = ctx.output_dir / "metrics.json"
    path.write_text(
        json.dumps({"history": history}, indent=2), encoding="utf-8"
    )
    return path



def save_manifest(
    files: list | None = None,
    enrich: bool | None = None,
    output_dir: str | Path | None = None,
    project_root: str | Path | None = None,
) -> Path:
    """artifact manifest 를 output_dir/manifest.json 에 저장.

    Args:
        files: explicit list — [(path_str, kind_str), ...] 또는
               [{"path": ..., "kind": ...}, ...]. None 이면 output_dir
               자동 스캔 + heuristic kind 추정.
        enrich: True 면 schema_version=2 — 각 entry 에 sha256/size_bytes/
                created_at 추가. False 면 schema_version=1 (path + kind 만).
                None 이면 cfg["manifest_checksums"] (default True) 따름.

    Returns:
        manifest.json Path.
    """
    ctx = _resolve_write_context(
        output_dir=output_dir, project_root=project_root
    )
    out = ctx.output_dir

    # enrich 결정 — 명시값 우선, 없으면 cfg, 그것도 없으면 default True.
    if enrich is None:
        enrich = bool(ctx.cfg.get("manifest_checksums", True))

    if files is None:
        files = _autodetect_files(out)

    normalized: list[dict] = []
    for entry in files:
        if isinstance(entry, tuple):
            base: dict = {"path": str(entry[0]), "kind": str(entry[1])}
        elif isinstance(entry, dict):
            base = {
                "path": str(entry["path"]),
                "kind": str(entry.get("kind", "other")),
            }
        else:
            continue
        if enrich:
            meta = _file_metadata(out, base["path"])
            if meta:
                base.update(meta)
        normalized.append(base)

    schema_version = 2 if enrich else 1
    manifest = {"schema_version": schema_version, "files": normalized}
    path = out / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return path



def save_run_summary(
    history: list[dict],
    status: str = "completed",
    artifacts: dict[str, str] | None = None,
    failure: dict | None = None,
    recipe: str | None = None,
    early_stopped_at: int | None = None,
    overrides: list | None = None,
    output_dir: str | Path | None = None,
    project_root: str | Path | None = None,
) -> Path:
    """run_summary.json 저장 — best/last 자동 계산.

    monitor 와 mode 는 cfg["monitor"], cfg["mode"] 에서 인식
    (default eval_loss/min). best/last 는 history + monitor 에서 자동 도출.
    git_sha + pcq_version 은 자동 추가.

    Args:
        history: epoch 별 metric dict 리스트.
        status: "completed" | "failed" | "partial".
        artifacts: {"model": "model.pkl", ...} 형태의 artifact 경로 딕셔너리.
        failure: 실패 시 {"category": ..., "message": ..., "suggested_fix": ...}.
        recipe: recipe 이름 (cfg._recipe 가 우선).
        early_stopped_at: early stop epoch (Experiment.fit 호환).
        overrides: provenance.overrides 명시값. None 이면 cfg["_overrides"] 사용.

    Returns:
        run_summary.json Path.
    """
    ctx = _resolve_write_context(
        output_dir=output_dir, project_root=project_root
    )
    cfg = dict(ctx.cfg)
    out = ctx.output_dir
    monitor_name = cfg.get("monitor", "eval_loss")
    mode = cfg.get("mode", "min")

    best = _find_best(history, monitor_name, mode) if history else None
    last = _last_epoch(history) if history else None

    resolved_overrides = (
        list(overrides) if overrides is not None
        else list(cfg.get("_overrides", []))
    )

    # v1.17: failure category 자동 분류 (이미 명시 카테고리가 있으면 유지).
    # v2.11: failure dict 를 FailureInfo 로 정규화 — error_code/evidence 추가.
    if failure:
        from pcq.agent.failure_classifier import enrich_failure

        failure = enrich_failure(failure)
        failure = _normalize_failure(failure)

    summary: dict[str, Any] = {
        "schema_version": 1,
        "status": status,
        "recipe": recipe or cfg.get("_recipe"),
        "monitor": {"name": monitor_name, "mode": mode},
        "target": {"name": monitor_name, "mode": mode},
        "best": best,
        "last": last,
        "artifacts": artifacts or {},
        "provenance": {
            "git_sha": _git_sha(),
            "pcq_version": _pcq_version(),
            "overrides": resolved_overrides,
        },
        "early_stopped_at": early_stopped_at,
        "warnings": [],
        "failure": failure,
    }
    # None 제거 (단, monitor/target/artifacts/provenance/warnings 은 유지)
    summary = {k: v for k, v in summary.items() if v is not None}
    path = out / "run_summary.json"
    path.write_text(
        json.dumps(summary, indent=2, default=str), encoding="utf-8"
    )
    return path



def _build_run_record(
    *,
    ctx: Any,
    status: str,
    started_at: str | None,
    finished_at: str | None,
    record_patch: bool,
    plan_id: str | None,
    intent: str | None,
    parent_run_id: str | None,
    parent_run_path: str | None,
    partial: bool,
    last_updated_at: str | None,
):
    """Build a RunRecord from the resolved context + already-written artifacts.

    Single source of truth shared by finalize_run() (status: completed/failed/
    partial) and save_partial_run_record() (status: running/checkpointed).

    Reads optional artifacts from ctx.output_dir if they exist:
      manifest.json → artifacts list
      run_summary.json → summary {target_metric, best, last} + monitor fallback

    Returns the assembled RunRecord (not yet written).
    """
    from pcq.agent.run_record import (
        AgentInfo,
        EnvironmentInfo,
        ExecutionInfo,
        MetricsInfo,
        RunInfo,
        RunRecord,
        SourceInfo,
        ValidationInfo,
    )

    rc = ctx.rc
    cfg = ctx.cfg
    out = ctx.output_dir

    # 1. run
    run_id = cfg.get("run_id") or (
        f"run_{datetime.now(tz=timezone.utc).strftime('%Y%m%d_%H%M%S')}_"
        f"{uuid.uuid4().hex[:6]}"
    )
    # v2.3: cq.yaml top-level `name:` 도 RunInfo.name 의 fallback 으로 사용.
    # 우선순위: configs.name > resolver.name (cq.yaml top-level) > "".
    run_name = cfg.get("name") or rc.name or ""
    # v1.18 lineage: 명시 인자 > cfg._parent_run_id > cfg.parent_run_id.
    resolved_parent_id = (
        parent_run_id
        or cfg.get("_parent_run_id")
        or cfg.get("parent_run_id")
    )
    resolved_parent_path = (
        parent_run_path
        or cfg.get("_parent_run_path")
        or cfg.get("parent_run_path")
    )
    run = RunInfo(
        id=str(run_id),
        name=str(run_name) if run_name else "",
        status=status,
        started_at=started_at,
        finished_at=finished_at,
        parent_run_id=str(resolved_parent_id) if resolved_parent_id else None,
        parent_run_path=str(resolved_parent_path) if resolved_parent_path else None,
        last_updated_at=last_updated_at,
        partial=partial,
    )

    # 2. execution
    execution = ExecutionInfo(
        cmd=str(cfg.get("_cmd") or rc.cmd or ""),
        cwd=".",
        config_path=(
            _relative_path(rc.cq_yaml_path, rc.project_root)
            if rc.cq_yaml_path is not None
            else "cq.yaml"
        ),
    )

    # 3. source
    source = SourceInfo(**_source_snapshot(
        record_patch=record_patch,
        project_root=rc.project_root,
        cq_yaml_path=rc.cq_yaml_path,
    ))

    # 4. environment
    environment = EnvironmentInfo(**_environment_snapshot(rc.project_root))

    # 5. inputs (from pcq.yaml.inputs — opaque) + metrics declared.
    inputs = dict(rc.inputs)
    input_summary = _input_evidence_summary(inputs)
    config_evidence = _config_evidence_snapshot(rc, cfg, out)
    metrics_schema_decl: list[dict] = []
    if rc.metrics_schema:
        for mname, mschema in rc.metrics_schema.items():
            entry: dict[str, Any] = {"name": str(mname)}
            for k in ("mode", "split", "aggregation", "sample_count"):
                if k in mschema:
                    entry[k] = mschema[k]
            metrics_schema_decl.append(entry)
    elif rc.declared_metrics:
        metrics_schema_decl = [{"name": n} for n in rc.declared_metrics]

    # 7. artifacts — manifest.json files entry (있으면)
    artifacts_list: list[dict] = []
    manifest_path = out / "manifest.json"
    if manifest_path.exists():
        try:
            m = json.loads(manifest_path.read_text(encoding="utf-8"))
            artifacts_list = m.get("files", []) or []
        except json.JSONDecodeError:
            pass

    # 8. summary — run_summary.json 의 best/last/monitor (있으면)
    summary: dict[str, Any] = {}
    rs_path = out / "run_summary.json"
    rs_data: dict | None = None
    if rs_path.exists():
        try:
            rs = json.loads(rs_path.read_text(encoding="utf-8"))
            rs_data = rs
            target_metric = (rs.get("monitor") or {}).get("name")
            summary_raw = {
                "target_metric": target_metric,
                "best": rs.get("best"),
                "last": rs.get("last"),
            }
            summary = {k: v for k, v in summary_raw.items() if v}
        except json.JSONDecodeError:
            pass

    # 6. metrics — cq.yaml 에 declared 가 없으면 run_summary.monitor 로 합성.
    if not metrics_schema_decl and rs_data is not None:
        monitor = rs_data.get("monitor") or {}
        mname = monitor.get("name")
        mmode = monitor.get("mode")
        if mname:
            entry = {"name": str(mname)}
            if mmode in ("min", "max"):
                entry["mode"] = mmode
            metrics_schema_decl = [entry]
    metrics = MetricsInfo(
        declared=metrics_schema_decl, history_path="metrics.json"
    )

    # 9. agent
    agent = AgentInfo(
        plan_id=plan_id or cfg.get("_plan_id"),
        intent=intent or cfg.get("_plan_intent"),
        recipe=cfg.get("_recipe"),
        overrides=list(cfg.get("_overrides", []) or []),
    )

    # 10. validation — placeholder, post-validation 후 patch (finalize 시).
    validation = ValidationInfo(
        status="unknown", report_path="validation_report.json"
    )

    return RunRecord(
        run=run,
        execution=execution,
        source=source,
        environment=environment,
        config=config_evidence,
        inputs=inputs,
        input_summary=input_summary,
        metrics=metrics,
        artifacts=artifacts_list,
        summary=summary,
        agent=agent,
        validation=validation,
    )



def save_partial_run_record(
    history: list[dict] | None = None,
    *,
    output_dir: str | Path | None = None,
    project_root: str | Path | None = None,
    status: str = "running",
    intent: str | None = None,
    plan_id: str | None = None,
    parent_run_id: str | None = None,
    parent_run_path: str | None = None,
) -> Path:
    """Atomic partial dump of RunRecord while training is still in progress.

    Writes ``output_dir/run_record.json`` via tmp+rename. Sets:

      - ``run.status = status`` (default "running"; "checkpointed" also valid)
      - ``run.partial = True``
      - ``run.last_updated_at = <ISO-8601 UTC now>``

    On a subsequent ``finalize_run()`` the same file is rewritten with
    ``run.partial = False`` and ``run.status`` set to the final state.

    Concurrency: the tmp file + ``os.replace`` ensures readers always observe a
    fully-written JSON document — no partial reads. Multiple writers should
    serialize their calls; pcq does not enforce a lock.

    The ``history`` argument is accepted for API symmetry with
    ``save_run_summary()`` / ``finalize_run()`` but is not currently consumed —
    metrics are read from ``metrics.json`` if present. Pass it for forward
    compatibility.

    Args:
        history: epoch metrics so far (currently advisory).
        output_dir: explicit output_dir; resolved via RunContext otherwise.
        project_root: explicit project root; ancestor walk otherwise.
        status: "running" (default) | "checkpointed".
        intent, plan_id, parent_run_id, parent_run_path: same agent provenance
            inputs as ``finalize_run()``.

    Returns:
        Path to ``output_dir/run_record.json`` (post-write).
    """
    # 지연 import — 순환 회피.
    from pcq.agent.resolver import resolve_run_context

    if status not in ("running", "checkpointed"):
        # 다른 status 도 받지만 권고 (caller가 finalize_run을 사용해야 함).
        # 의미 흐림 방지를 위해 명시적으로 reject.
        raise ValueError(
            f"save_partial_run_record status must be 'running' or "
            f"'checkpointed' (got {status!r}); use finalize_run() for "
            f"completed/failed/partial."
        )

    ctx = resolve_run_context(
        path=project_root,
        output_dir=output_dir,
        ensure_output_dir=True,
    )
    cfg = ctx.cfg
    out = ctx.output_dir
    record_patch = bool(cfg.get("record_patch", False))
    now = _now_utc_iso()

    record = _build_run_record(
        ctx=ctx,
        status=status,
        started_at=cfg.get("_started_at"),
        finished_at=None,
        record_patch=record_patch,
        plan_id=plan_id,
        intent=intent,
        parent_run_id=parent_run_id,
        parent_run_path=parent_run_path,
        partial=True,
        last_updated_at=now,
    )

    rr_path = out / "run_record.json"
    _atomic_write_json(rr_path, record.to_dict())
    return rr_path



def finalize_run(
    history: list[dict] | None = None,
    status: str = "completed",
    artifacts: dict[str, str] | None = None,
    failure: dict | None = None,
    plan_id: str | None = None,
    intent: str | None = None,
    started_at: str | None = None,
    record_patch: bool | None = None,
    parent_run_id: str | None = None,
    parent_run_path: str | None = None,
    output_dir: str | Path | None = None,
    project_root: str | Path | None = None,
    attribution: dict | None = None,
    worker_spec: dict | None = None,
    worker_spec_warnings: list[dict] | None = None,
    fingerprint: dict | None = None,
    fingerprint_warnings: list[dict] | None = None,
    run_intent: dict | None = None,
    run_intent_warnings: list[dict] | None = None,
    run_integrity: dict | None = None,
    run_integrity_warnings: list[dict] | None = None,
    run_code: dict | None = None,
    run_code_warnings: list[dict] | None = None,
    run_seeds: dict | None = None,
    run_seeds_warnings: list[dict] | None = None,
    run_data_ref: dict | None = None,
    run_data_ref_warnings: list[dict] | None = None,
) -> Path:
    """run_record.json + validation_report.json 작성.

    이미 작성된 contract artifacts (config.json, metrics.json, manifest.json,
    run_summary.json) 를 읽어 RunRecord 합성.

    Args:
        history: optional, metrics.json 없을 때 fallback (현재 직접 사용 X).
        status, artifacts, failure: run_summary 합성용 (호환성).
        plan_id, intent: agent provenance.
        started_at: started_at ISO timestamp (None 이면 비움).
        record_patch: dirty repo 시 patch_sha256 + changed_files 기록.
                       None 이면 cfg["record_patch"] 따름 (default False).
        parent_run_id: v1.18 lineage — parent run의 semantic id. 명시되면
                       cfg._parent_run_id / parent_run_id 보다 우선.
        parent_run_path: v1.18 lineage — parent output_dir 경로. 로컬 path
                         또는 cq:// URI (pcq은 opaque로만 보존).
        output_dir: v2.5 — explicit output_dir override (CLI finalize 에서
                    chdir/env tmp 트릭 제거). 없으면 RunContext 가 결정.
        project_root: v2.5 — explicit project_root override. cwd ancestor
                      walk-up 결과를 무시하고 이 디렉토리에서 cq.yaml 탐색.
        attribution: v3.0 — build_attribution_object() 반환값 또는 동일 형태
                     dict. run_record 의 attribution 필드로 그대로 전달.
                     None 이면 attribution 필드 생략.
        worker_spec: T-WSPEC-4 — build_worker_spec_object() 반환값 또는 동일 형태
                     dict. run_record 의 worker_spec 필드로 그대로 전달.
                     None 이면 worker_spec 필드 생략 (옛 record 호환).
        worker_spec_warnings: build_worker_spec_object() 에서 반환된 warnings 목록.
                              None 또는 [] 이면 validation_report 에 추가 없음.
        fingerprint: T-WFP-4 — build_fingerprint_object() 반환값 또는 동일 형태
                     dict. run_record 의 fingerprint 필드로 그대로 전달.
                     None 이면 fingerprint 필드 생략 (옛 record 호환).
        fingerprint_warnings: build_fingerprint_object() 에서 반환된 warnings 목록.
                              None 또는 [] 이면 validation_report 에 추가 없음.
        run_intent: T-PCQ2X-3 — build_intent_object() 반환값 또는 동일 형태 dict.
                    run_record 의 top-level intent 필드로 전달. None 이면 생략 (1.x 호환).
        run_intent_warnings: build_intent_object() 에서 반환된 warnings 목록.
        run_integrity: T-PCQ2X-3 — build_integrity_object() 반환값 또는 동일 형태 dict.
                       run_record 의 top-level integrity 필드로 전달. None 이면 생략 (1.x 호환).
        run_integrity_warnings: build_integrity_object() 에서 반환된 warnings 목록.
        run_code: T-PCQRP-4 — build_code_object() 반환값. None 이면 생략 (1.x 호환).
        run_code_warnings: build_code_object() 에서 반환된 warnings 목록.
        run_seeds: T-PCQRP-4 — build_seeds_object() 반환값. None 이면 생략.
        run_seeds_warnings: build_seeds_object() 에서 반환된 warnings 목록.
        run_data_ref: T-PCQRP-4 — build_data_ref_object() 반환값. None 이면 생략.
        run_data_ref_warnings: build_data_ref_object() 에서 반환된 warnings 목록.

    Returns:
        run_record.json Path.
    """
    # 지연 import — 순환 회피.
    from pcq.agent.resolver import resolve_run_context

    # v2.5: 단일 RunContext entry point — read+write semantics 통합.
    ctx = resolve_run_context(
        path=project_root,
        output_dir=output_dir,
        ensure_output_dir=True,
    )
    cfg = ctx.cfg
    out = ctx.output_dir

    # record_patch: 명시값 > cfg > default False
    if record_patch is None:
        record_patch = bool(cfg.get("record_patch", False))

    finished_at = _now_utc_iso()

    record = _build_run_record(
        ctx=ctx,
        status=status,
        started_at=started_at,
        finished_at=finished_at,
        record_patch=record_patch,
        plan_id=plan_id,
        intent=intent,
        parent_run_id=parent_run_id,
        parent_run_path=parent_run_path,
        partial=False,                   # finalize 는 항상 partial=False
        last_updated_at=finished_at,     # finalize 시점 = last_updated.
    )

    rr_path = out / "run_record.json"
    # attribution 필드를 run_record dict 에 추가 (있을 때만).
    record_dict = record.to_dict()
    if attribution is not None:
        record_dict["attribution"] = attribution
    # T-WSPEC-4: worker_spec 필드를 run_record dict 에 추가 (있을 때만).
    if worker_spec is not None:
        record_dict["worker_spec"] = worker_spec
    # T-WFP-4: fingerprint 필드를 run_record dict 에 추가 (있을 때만).
    if fingerprint is not None:
        record_dict["fingerprint"] = fingerprint
    # T-PCQ2X-3: intent, integrity, contract_version 추가 (additive — 1.x 호환).
    # T-PCQRP-4: code / seeds / data_ref 신규 필드 추가.
    # BL-2: MUST be before build_integrity_object so hash covers them
    # (T-PCQ2X-5b precedent; _INTEGRITY_HASHED_FIELDS lists these leaves).
    if run_intent is not None:
        record_dict["intent"] = run_intent
    if run_code is not None:
        record_dict["code"] = run_code
    if run_seeds is not None:
        record_dict["seeds"] = run_seeds

    # BL-3 이중 PHI 게이트 (belt-and-suspenders) — build_data_ref_object 내부 1차 게이트의 보조.
    # 호출자가 builder 를 우회하거나 domain 불일치 상태로 직접 dict 를 전달할 수 있으므로
    # lifecycle 레이어에서 2차 방어선을 적용한다.
    # domain 출처: fingerprint 파라미터의 "domain" 키 — build_fingerprint_object 가
    # 항상 "domain" 을 최상위 키로 포함하며, save_all → finalize_run 전달 경로가 동일 객체를
    # 사용하므로 fingerprint["domain"] 이 가장 권위 있는 도메인 출처.
    # (core.py:_REGULATED_DOMAINS 와 같은 집합인 _PHI_DOMAINS 로 판별.)
    if (
        run_data_ref is not None
        and isinstance(run_data_ref, dict)
        and run_data_ref.get("content_sha256") is not None
    ):
        _dr_effective_domain: str | None = None
        if fingerprint is not None and isinstance(fingerprint, dict):
            _dr_effective_domain = fingerprint.get("domain")
        if _dr_effective_domain in _PHI_DOMAINS:
            run_data_ref = dict(run_data_ref)  # 호출자 dict 변형 방지
            run_data_ref["content_sha256"] = None
            run_data_ref_warnings = list(run_data_ref_warnings or []) + [{
                "code": "DATA_REF_CONTENT_SHA_STRIPPED_DEFENSIVE_PHI",
                "message": (
                    f"data_ref.content_sha256 가 lifecycle 방어 게이트(BL-3)에 의해 null 처리됩니다. "
                    f"domain={_dr_effective_domain!r} 는 PHI 도메인입니다. "
                    "builder 를 통하지 않은 직접 dict 전달을 감지한 2차 방어선입니다 (R5/R5b, DEC-004)."
                ),
                "field": "data_ref.content_sha256",
            }]

    if run_data_ref is not None:
        record_dict["data_ref"] = run_data_ref

    # BL-1 확장 조건: intent 뿐 아니라 code / seeds / data_ref 중 하나라도 있으면 "2.0" emit.
    # contract_version "2.0" 은 reproducibility pack 필드 존재 시 항상 emit.
    # 무결성 해시 계산 전에 설정해야 content_hash 가 contract_version 을 포함함.
    _has_repro_pack = (
        run_intent is not None
        or run_integrity is not None
        or run_code is not None
        or run_seeds is not None
        or run_data_ref is not None
    )
    if _has_repro_pack:
        record_dict["contract_version"] = "2.0"

    # T-PCQ2X-5 (BL-1 확장): integrity 자동 계산 — run_integrity 가 명시 전달되지 않고
    # intent / code / seeds / data_ref 중 하나라도 있을 때 auto-compute.
    # record_dict 가 완전히 조립된 후 (신규 필드 + contract_version 포함, integrity 제외) 해시 계산.
    # anti-recursion 은 build_integrity_object 내부가 보장 ("integrity" 키 제외).
    _auto_integrity: dict | None = None
    _auto_integrity_warnings: list[dict] = []
    if run_integrity is None and _has_repro_pack:
        _auto_integrity, _auto_integrity_warnings = build_integrity_object(record_dict)
        run_integrity = _auto_integrity
        run_integrity_warnings = list(run_integrity_warnings or []) + _auto_integrity_warnings

    if run_integrity is not None:
        record_dict["integrity"] = run_integrity
    # v2.11: atomic write — partial RunRecord 와 동일한 보장.
    _atomic_write_json(rr_path, record_dict)

    # post-run validation 실행 후 validation_report.json + run_record.validation patch
    # fingerprint_warnings 를 extra_warnings 에 포함 (worker_spec_warnings + intent + integrity 합산).
    combined_extra_warnings = (
        list(worker_spec_warnings or [])
        + list(fingerprint_warnings or [])
        + list(run_intent_warnings or [])
        + list(run_integrity_warnings or [])
        + list(run_code_warnings or [])
        + list(run_seeds_warnings or [])
        + list(run_data_ref_warnings or [])
    )
    _run_post_validation_and_patch(
        out,
        rr_path,
        strictness=cfg.get("strictness"),
        extra_warnings=combined_extra_warnings,
    )

    return rr_path


def _run_post_validation_and_patch(
    output_dir: Path,
    run_record_path: Path,
    strictness: int | None = None,
    extra_warnings: list[dict] | None = None,
) -> None:
    """post-run validation 실행 → validation_report.json + run_record.validation 갱신.

    Args:
        extra_warnings: worker_spec_warnings 등 추가 warning 목록. validation_report
                        의 warning_codes 에 code 를 추가합니다.
    """
    from pcq.agent.validate_run import validate_run

    report = validate_run(output_dir, strictness=strictness)

    # worker_spec 등 extra_warnings 를 validation_report 에 합류.
    if extra_warnings:
        report_dict = report.to_dict()
        existing_codes: list = report_dict.get("warning_codes", [])
        for w in extra_warnings:
            code = w.get("code")
            if code and code not in existing_codes:
                existing_codes.append(code)
        report_dict["warning_codes"] = existing_codes
        vr_path = output_dir / "validation_report.json"
        vr_path.write_text(json.dumps(report_dict, indent=2), encoding="utf-8")
    else:
        vr_path = output_dir / "validation_report.json"
        vr_path.write_text(
            json.dumps(report.to_dict(), indent=2), encoding="utf-8"
        )

    # run_record.validation 갱신.
    try:
        rr = json.loads(run_record_path.read_text(encoding="utf-8"))
        rr["validation"] = {
            "status": report.status,
            "report_path": "validation_report.json",
        }
        run_record_path.write_text(
            json.dumps(rr, indent=2), encoding="utf-8"
        )
    except (json.JSONDecodeError, OSError):
        pass


def save_all(
    history: list[dict],
    status: str = "completed",
    artifacts: dict[str, str] | None = None,
    files: list | None = None,
    failure: dict | None = None,
    recipe: str | None = None,
    config_extra: dict | None = None,
    early_stopped_at: int | None = None,
    overrides: list | None = None,
    finalize: bool = True,
    plan_id: str | None = None,
    intent: str | None = None,
    parent_run_id: str | None = None,
    parent_run_path: str | None = None,
    output_dir: str | Path | None = None,
    project_root: str | Path | None = None,
    operator: str | None = None,
    author_id: str | None = None,
    author_kind: str | None = None,
    committer_id: str | None = None,
    committer_kind: str | None = None,
    session_id: str | None = None,
    persona_id_author: str | None = None,
    persona_id_committer: str | None = None,
    # T-PCQ2X-5: intent 2.x 입력 — 명시 인자 우선, 없으면 CQ_INTENT_* 환경변수 폴백,
    # 그 다음 cq.yaml의 intent.* 섹션. 셋 모두 없으면 build_intent_object 가 None 반환.
    intent_goal: str | None = None,
    intent_expected_baseline: dict | None = None,
    intent_tolerance: dict | None = None,
    # T-PCQRP-4: reproducibility pack 입력 — 명시 인자 우선, 없으면 CQ_CODE_* / CQ_SEEDS_JSON /
    # CQ_DATA_REF_* 환경변수 폴백, 그 다음 cq.yaml code/seeds/data_ref 섹션.
    code_content_sha256: str | None = None,
    code_scope: dict | None = None,
    seeds: dict | None = None,
    data_ref_uri: str | None = None,
    data_ref_content_sha256: str | None = None,
    data_ref_size_bytes: int | None = None,
) -> dict[str, Path]:
    """5+ 개 표준 artifact 묶음 작성. contract script 마지막 한 줄로 사용.

    순서: config → metrics → run_summary → manifest → (finalize) run_record
    + validation_report.

    v1.16: finalize=True (default) 면 run_record.json + validation_report.json
    까지 생성. False 로 하면 v1.15 동작 유지.
    v1.18: parent_run_id / parent_run_path 인자 — finalize_run 으로 그대로 전달.
    v2.5: output_dir / project_root 명시 인자 — finalize_run 으로 그대로 전달.
    v3.0: attribution 인자 — build_attribution_object() 로 결정 후 finalize_run 에 전달.
          명시 인자 없으면 환경변수(CQ_ATTRIBUTION_*) 자동 폴백. 둘 다 없으면 생략.
    T-PCQ2X-5: intent_goal/intent_expected_baseline/intent_tolerance — build_intent_object()
          로 결정 후 finalize_run 에 전달. 명시 인자 없으면 CQ_INTENT_* 환경변수 폴백,
          없으면 cq.yaml intent.* 섹션. 셋 모두 null 이면 intent 생략 (1.x 호환).
    T-PCQRP-4: code_content_sha256/code_scope/seeds/data_ref_* — build_code_object(),
          build_seeds_object(), build_data_ref_object() 로 결정 후 finalize_run 에 전달.
          명시 인자 없으면 CQ_CODE_*/CQ_SEEDS_JSON/CQ_DATA_REF_* 환경변수 폴백,
          없으면 cq.yaml code/seeds/data_ref 섹션. 전부 null 이면 생략 (1.x 호환).

    Returns:
        {"config", "metrics", "manifest", "run_summary"} 항상.
        finalize=True 면 추가로 {"run_record", "validation_report"}.
    """
    paths: dict[str, Path] = {
        "config": save_config_snapshot(
            extra=config_extra,
            output_dir=output_dir,
            project_root=project_root,
        ),
        "metrics": save_metrics(
            history, output_dir=output_dir, project_root=project_root
        ),
        "run_summary": save_run_summary(
            history=history,
            status=status,
            artifacts=artifacts,
            failure=failure,
            recipe=recipe,
            early_stopped_at=early_stopped_at,
            overrides=overrides,
            output_dir=output_dir,
            project_root=project_root,
        ),
        "manifest": save_manifest(
            files=files, output_dir=output_dir, project_root=project_root
        ),
    }
    if finalize:
        # v3.0: attribution 객체를 한 번만 결정한 뒤 finalize_run 에 전달.
        attribution_obj = build_attribution_object(
            operator=operator,
            author_id=author_id,
            author_kind=author_kind,
            committer_id=committer_id,
            committer_kind=committer_kind,
            session_id=session_id,
            persona_id_author=persona_id_author,
            persona_id_committer=persona_id_committer,
        )
        # T-WSPEC-5: worker_spec 객체를 env + cfg 에서 자동 픽업.
        # save_all 호출자는 별도 인자 없이 build_worker_spec_object 가 처리.
        try:
            from pcq.agent.resolver import resolve_run_context as _resolve_rc
            _wspec_ctx = _resolve_rc(
                path=project_root,
                output_dir=output_dir,
                ensure_output_dir=False,
            )
            _wspec_cfg = _wspec_ctx.cfg
        except Exception:  # noqa: BLE001
            _wspec_cfg = {}
        worker_spec_obj, worker_spec_warnings = build_worker_spec_object(
            cli_args=None,
            cfg=_wspec_cfg,
        )
        # T-WFP-5: fingerprint 캐시 자동 픽업 (pcq.fingerprint() 호출 결과).
        # 호출된 적 없으면 None → build_fingerprint_object 가 cfg declared 만 사용.
        try:
            from pcq.core import _fingerprint_cache as _fp_cache
            from pcq.core import _fingerprint_warnings as _fp_warnings
        except ImportError:
            _fp_cache = None
            _fp_warnings = []
        fingerprint_obj, fingerprint_warnings = build_fingerprint_object(
            cli_args=None,
            cfg=_wspec_cfg,
            detected_cache=_fp_cache,
        )
        # detected_cache 의 warnings 는 build_fingerprint_object 가 이미 수집하므로
        # 중복 방지를 위해 _fp_warnings 는 별도 병합하지 않음

        # T-PCQ2X-5: intent 2.x 객체 결정.
        # 우선순위: 명시 인자 > CQ_INTENT_* 환경변수 > cq.yaml intent.* 섹션.
        _intent_cfg: dict = {}
        if isinstance(_wspec_cfg.get("intent"), dict):
            _intent_cfg = _wspec_cfg["intent"]

        _resolved_goal = (
            intent_goal
            or os.environ.get("CQ_INTENT_GOAL")
            or _intent_cfg.get("goal")
            or None
        )
        # expected_baseline: 명시 인자 > 환경변수(metric+value 조합) > cfg
        _resolved_baseline: dict | None = intent_expected_baseline
        if _resolved_baseline is None:
            _eb_metric = os.environ.get("CQ_INTENT_EXPECTED_BASELINE_METRIC")
            _eb_value_str = os.environ.get("CQ_INTENT_EXPECTED_BASELINE_VALUE")
            if _eb_metric and _eb_value_str:
                try:
                    _resolved_baseline = {"metric": _eb_metric, "value": float(_eb_value_str)}
                except (ValueError, TypeError):
                    _resolved_baseline = None
        if _resolved_baseline is None and isinstance(_intent_cfg.get("expected_baseline"), dict):
            _resolved_baseline = _intent_cfg["expected_baseline"]

        # tolerance: 명시 인자 > 환경변수(direction+margin 조합) > cfg
        _resolved_tolerance: dict | None = intent_tolerance
        if _resolved_tolerance is None:
            _tol_dir = os.environ.get("CQ_INTENT_TOLERANCE_DIRECTION")
            _tol_margin_str = os.environ.get("CQ_INTENT_TOLERANCE_MARGIN")
            if _tol_dir and _tol_margin_str:
                try:
                    _resolved_tolerance = {"direction": _tol_dir, "margin": float(_tol_margin_str)}
                except (ValueError, TypeError):
                    _resolved_tolerance = None
        if _resolved_tolerance is None and isinstance(_intent_cfg.get("tolerance"), dict):
            _resolved_tolerance = _intent_cfg["tolerance"]

        intent_obj, intent_warnings = build_intent_object(
            goal=_resolved_goal,
            expected_baseline=_resolved_baseline,
            tolerance=_resolved_tolerance,
        )

        # T-PCQRP-4: reproducibility pack 객체 결정.
        # 우선순위: 명시 인자 > CQ_CODE_*/CQ_SEEDS_JSON/CQ_DATA_REF_* 환경변수 > cq.yaml 섹션.

        # code: 명시 인자 > 환경변수 > cfg
        _code_cfg: dict = {}
        if isinstance(_wspec_cfg.get("code"), dict):
            _code_cfg = _wspec_cfg["code"]
        _resolved_code_sha = (
            code_content_sha256
            or os.environ.get("CQ_CODE_CONTENT_SHA256")
            or _code_cfg.get("content_sha256")
            or None
        )
        _resolved_code_scope: dict | None = code_scope
        if _resolved_code_scope is None:
            _code_scope_json = os.environ.get("CQ_CODE_SCOPE_JSON")
            if _code_scope_json:
                try:
                    _resolved_code_scope = json.loads(_code_scope_json)
                except (ValueError, TypeError):
                    _resolved_code_scope = None
        if _resolved_code_scope is None and isinstance(_code_cfg.get("scope"), dict):
            _resolved_code_scope = _code_cfg["scope"]
        code_obj, code_warnings = build_code_object(
            content_sha256=_resolved_code_sha,
            scope=_resolved_code_scope,
        )

        # seeds: 명시 인자 > 환경변수(JSON) > cfg
        _seeds_cfg: dict | None = None
        if isinstance(_wspec_cfg.get("seeds"), dict):
            _seeds_cfg = _wspec_cfg["seeds"]
        _resolved_seeds: dict | None = seeds
        if _resolved_seeds is None:
            _seeds_json = os.environ.get("CQ_SEEDS_JSON")
            if _seeds_json:
                try:
                    _resolved_seeds = json.loads(_seeds_json)
                except (ValueError, TypeError):
                    _resolved_seeds = None
        if _resolved_seeds is None and _seeds_cfg is not None:
            _resolved_seeds = _seeds_cfg
        seeds_obj, seeds_warnings = build_seeds_object(seeds=_resolved_seeds)

        # data_ref: 명시 인자 > 환경변수 > cfg
        _dr_cfg: dict = {}
        if isinstance(_wspec_cfg.get("data_ref"), dict):
            _dr_cfg = _wspec_cfg["data_ref"]
        _resolved_dr_uri = (
            data_ref_uri
            or os.environ.get("CQ_DATA_REF_URI")
            or _dr_cfg.get("uri")
            or None
        )
        _resolved_dr_sha = (
            data_ref_content_sha256
            or os.environ.get("CQ_DATA_REF_CONTENT_SHA256")
            or _dr_cfg.get("content_sha256")
            or None
        )
        _resolved_dr_size: int | None = data_ref_size_bytes
        if _resolved_dr_size is None:
            _dr_size_str = os.environ.get("CQ_DATA_REF_SIZE_BYTES")
            if _dr_size_str:
                try:
                    _resolved_dr_size = int(_dr_size_str)
                except (ValueError, TypeError):
                    _resolved_dr_size = None
        if _resolved_dr_size is None and _dr_cfg.get("size_bytes") is not None:
            try:
                _resolved_dr_size = int(_dr_cfg["size_bytes"])
            except (ValueError, TypeError):
                _resolved_dr_size = None
        # domain: fingerprint_obj 가 있으면 그 domain 사용 (BL-3 dual gate 와 동일 출처).
        _dr_domain: str = "general"
        if fingerprint_obj is not None and isinstance(fingerprint_obj, dict):
            _dr_domain = fingerprint_obj.get("domain") or "general"
        data_ref_obj, data_ref_warnings = build_data_ref_object(
            uri=_resolved_dr_uri,
            content_sha256=_resolved_dr_sha,
            size_bytes=_resolved_dr_size,
            domain=_dr_domain,
        )

        rr_path = finalize_run(
            history=history,
            status=status,
            artifacts=artifacts,
            failure=failure,
            plan_id=plan_id,
            intent=intent,
            parent_run_id=parent_run_id,
            parent_run_path=parent_run_path,
            output_dir=output_dir,
            project_root=project_root,
            attribution=attribution_obj,
            worker_spec=worker_spec_obj,
            worker_spec_warnings=worker_spec_warnings,
            fingerprint=fingerprint_obj,
            fingerprint_warnings=fingerprint_warnings,
            run_intent=intent_obj,
            run_intent_warnings=intent_warnings,
            run_code=code_obj,
            run_code_warnings=code_warnings,
            run_seeds=seeds_obj,
            run_seeds_warnings=seeds_warnings,
            run_data_ref=data_ref_obj,
            run_data_ref_warnings=data_ref_warnings,
        )
        paths["run_record"] = rr_path
        vr_path = rr_path.parent / "validation_report.json"
        if vr_path.exists():
            paths["validation_report"] = vr_path
    return paths
