"""pcq.contract — CQ contract artifact helpers.

Framework-agnostic. Use these from any project-local script (HF Trainer,
sklearn, XGBoost, custom code) to produce standard pcq artifacts:
config.json, metrics.json, manifest.json, run_summary.json,
run_record.json (v1.16+), validation_report.json (v1.16+).

These helpers do NOT depend on pcq.Experiment or pcq.Trainer. They write the
same files that Experiment.fit() writes, so contract scripts and Experiment
runs produce indistinguishable output to CQ.
"""
from __future__ import annotations

# 6 builders 분리됨 (T-PCQA-A-1) + worker_spec 분리됨 (T-PCQA-W) + fingerprint_builder 분리됨 (T-PCQA-FB).
# re-export로 backward-compat 100% 유지.
from pcq.builders import (  # noqa: F401
    build_attribution_object,
    build_code_object,
    build_data_ref_object,
    build_fingerprint_object,
    build_intent_object,
    build_integrity_object,
    build_seeds_object,
    build_worker_spec_object,
    _INTEGRITY_HASHED_FIELDS,
    _PHI_DOMAINS,
    _VALID_INTENT_GOALS,
    _resolve_dotted_path,
)

# T-PCQA-LH: lifecycle helpers 분리. 외부 테스트/agent가 from pcq.contract import _X 형태로
# underscore-private 직접 import하는 사이트가 있어 re-export 유지 필요.
from pcq.lifecycle._helpers import (  # noqa: F401
    _atomic_write_json,
    _autodetect_files,
    _classify_exception,
    _config_evidence_snapshot,
    _cq_config_available,
    _environment_snapshot,
    _file_metadata,
    _find_best,
    _find_lockfile,
    _flatten_yaml_value,
    _git_changed_files,
    _git_dirty,
    _git_patch_sha256,
    _git_sha,
    _input_evidence_summary,
    _last_epoch,
    _normalize_failure,
    _now_utc_iso,
    _pcq_version,
    _read_cq_yaml_inputs_and_metrics,
    _relative_path,
    _resolve_write_context,
    _run_git,
    _sha256_file,
    _source_snapshot,
    _KIND_BY_SUFFIX,
    _SHA256_CHUNK_SIZE,
    _SPECIAL_FILES,
    _LOCKFILE_NAMES,
    _LOCKFILE_ANCESTOR_LIMIT,
)

# T-PCQA-LC: lifecycle core 분리. save_*/finalize_run/save_all → pcq.lifecycle.
# re-export로 backward-compat 100% 유지 (pcq/__init__.py 무변경 — transitive).
from pcq.lifecycle import (  # noqa: F401
    save_config_snapshot,
    save_metrics,
    save_manifest,
    save_run_summary,
    save_partial_run_record,
    save_all,
    finalize_run,
    _build_run_record,
    _run_post_validation_and_patch,
)
