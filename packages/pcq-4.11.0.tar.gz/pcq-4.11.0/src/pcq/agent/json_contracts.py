"""Stable JSON output contracts for agent-facing pcq surfaces.

The contracts here intentionally describe the minimum stable surface, not every
field a command may emit. Within ``schema_version == 1`` these required fields
are additive-only: callers may depend on them, and pcq may add more fields.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any


JSON_CONTRACT_VERSION = 1


JSON_CONTRACTS: dict[str, dict[str, Any]] = {
    "pcq.run.envelope": {
        "schema_version": JSON_CONTRACT_VERSION,
        "description": "pcq run --json envelope for executed or config-only runs",
        "additive_only": True,
        "required": {
            "schema_version": "int",
            "status": "string",
            "project_root": "string",
            "runtime_cfg_path": "string",
            "cmd": "string",
        },
        "optional": {
            "exit_code": "int",
            "stdout_path": "string",
            "stderr_path": "string",
            "stdout_tail": "string",
            "stderr_tail": "string",
            "stdout_tail_truncated": "boolean",
            "stderr_tail_truncated": "boolean",
            "error": "string",
            # attribution 패스스루 필드 (T-PCQ-ATTR-3 additive)
            # describe-run 스키마의 attribution 객체와 동일한 형태로 전달됨
            "attribution": "object",
            # worker_spec 패스스루 필드 (T-WSPEC-3 additive)
            # describe-run 스키마의 worker_spec 객체와 동일한 중첩 형태로 전달됨
            "worker_spec": "object",
            # fingerprint 패스스루 필드 (T-WFP-3 additive)
            # describe-run 스키마의 fingerprint 객체와 동일한 중첩 형태로 전달됨
            "fingerprint": "object",
            # intent 패스스루 필드 (T-PCQ2X-2 additive)
            # describe-run 스키마의 intent 객체와 동일한 형태로 전달됨
            "intent": "object",
            # integrity 패스스루 필드 (T-PCQ2X-2 additive)
            # describe-run 스키마의 integrity 객체와 동일한 형태로 전달됨
            "integrity": "object",
            # contract_version 패스스루 필드 (T-PCQ2X-2 additive)
            "contract_version": "string",
            # code 패스스루 필드 (T-PCQRP-2 additive) — 코드 범위 및 콘텐츠 해시
            "code": "object",
            # seeds 패스스루 필드 (T-PCQRP-2 additive) — 난수 시드 맵
            "seeds": "object",
            # data_ref 패스스루 필드 (T-PCQRP-2 additive) — 데이터셋 식별 정보
            "data_ref": "object",
            # code 플랫 표면 — code.content_sha256 최상위 노출
            "code_content_sha256": "string",
            # seeds 플랫 표면 — 주 시드 최상위 노출
            "seeds_main": "string",
            # seeds_count: 다중 시드 개수 (NOTE-6 — 다중 시드 정보 보존)
            "seeds_count": "int",
            # data_ref 플랫 표면 — data_ref.uri 최상위 노출
            "data_ref_uri": "string",
        },
        # worker_spec / fingerprint 풀 JSON Schema — describe_run.record의 property_overrides와 동일한 구조
        "property_overrides": {
            "worker_spec": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "schema_version": {"type": "integer", "const": 1},
                    "cpu": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "model": {"type": ["string", "null"]},
                            "cores_physical": {"type": ["integer", "null"]},
                            "cores_logical": {"type": ["integer", "null"]},
                            "max_freq_mhz": {"type": ["integer", "null"]},
                        },
                    },
                    "memory": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "total_gb": {"type": ["number", "null"]},
                        },
                    },
                    "accelerator": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {
                                "type": "string",
                                "enum": ["mps", "cuda", "cpu"],
                            },
                            "gpus": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "additionalProperties": False,
                                    "properties": {
                                        "model": {"type": "string"},
                                        "vram_gb": {"type": ["number", "null"]},
                                        "cuda_version": {"type": ["string", "null"]},
                                        "torch_ordinal": {"type": ["integer", "null"]},
                                    },
                                    "required": ["model"],
                                },
                            },
                            "visible_devices": {"type": ["string", "null"]},
                        },
                        "required": ["kind", "gpus"],
                    },
                    "os": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "system": {"type": "string"},
                            "machine": {"type": "string"},
                            "release": {"type": ["string", "null"]},
                        },
                    },
                    "container": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {
                                "type": "string",
                                "enum": ["none", "docker", "k8s", "other"],
                            },
                            "image": {"type": ["string", "null"]},
                            "detector_hint": {"type": ["string", "null"]},
                        },
                        "required": ["kind"],
                    },
                    "source": {
                        "type": "string",
                        "enum": ["detected", "declared", "merged"],
                    },
                },
                "required": ["schema_version", "accelerator", "container", "source"],
            },
            # intent 패스스루 풀 JSON Schema (T-PCQ2X-2) — describe_run.record의 intent와 동일한 구조
            # C1: goal은 null 허용 (SPEC + build_intent_object 동작과 일치) — required에서 제거.
            "intent": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "goal": {
                        "type": ["string", "null"],
                        "enum": [
                            "baseline_reproduction",
                            "sota_challenge",
                            "ablation",
                            "hyperparam_sweep",
                            "exploration",
                            None,
                        ],
                    },
                    "expected_baseline": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "metric": {"type": "string"},
                            "value": {"type": "number"},
                        },
                    },
                    "tolerance": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "direction": {
                                "type": "string",
                                "enum": ["higher_is_better", "lower_is_better"],
                            },
                            "margin": {"type": "number"},
                        },
                    },
                },
            },
            # integrity 패스스루 풀 JSON Schema (T-PCQ2X-2)
            "integrity": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "content_hash": {"type": "string"},
                    "hashed_fields": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
                "required": ["content_hash", "hashed_fields"],
            },
            # contract_version 패스스루 (null 허용)
            "contract_version": {"type": ["string", "null"]},
            # code 패스스루 풀 JSON Schema (T-PCQRP-2) — 코드 범위 + 콘텐츠 해시
            # scope는 구조화된 객체 (BL-5 비판 반영 — 자유 문자열 금지)
            "code": {
                "type": ["object", "null"],
                "properties": {
                    "content_sha256": {"type": "string", "pattern": "^sha256:"},
                    "scope": {
                        "type": "object",
                        "properties": {
                            "kind": {
                                "type": "string",
                                "enum": ["entry_script", "file_list", "repo_subset"],
                            },
                            "files": {"type": "array", "items": {"type": "string"}},
                            "root": {"type": ["string", "null"]},
                        },
                        "required": ["kind"],
                    },
                },
                "required": ["content_sha256", "scope"],
            },
            # seeds 패스스루 풀 JSON Schema (T-PCQRP-2) — 난수 시드 맵 (키 자유, 값 int|str)
            "seeds": {
                "type": ["object", "null"],
                "additionalProperties": {"oneOf": [{"type": "integer"}, {"type": "string"}]},
            },
            # data_ref 패스스루 풀 JSON Schema (T-PCQRP-2) — 데이터셋 식별 정보
            # content_sha256: PHI 게이트 적용 시 null 필수 (R5/R5b)
            "data_ref": {
                "type": ["object", "null"],
                "properties": {
                    "uri": {"type": "string"},
                    "content_sha256": {
                        "type": ["string", "null"],
                        "pattern": "^(sha256:.*)?$",
                    },
                    "size_bytes": {"type": ["integer", "null"]},
                },
                "required": ["uri"],
            },
            # 플랫 표면 오버라이드 (null 허용 — 기존 레코드 하위 호환)
            "code_content_sha256": {"type": ["string", "null"], "pattern": "^(sha256:.*)?$"},
            "seeds_main": {"type": ["integer", "string", "null"]},
            "seeds_count": {"type": ["integer", "null"], "minimum": 0},
            "data_ref_uri": {"type": ["string", "null"]},
            # fingerprint 패스스루 풀 JSON Schema (T-WFP-3) — describe_run.record의 fingerprint와 동일한 구조
            "fingerprint": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "schema_version": {"type": "integer", "const": 1},
                    "modality": {
                        "type": "string",
                        "enum": [
                            "tabular",
                            "image",
                            "text",
                            "time_series",
                            "audio",
                            "graph",
                            "other",
                        ],
                    },
                    "task_kind": {
                        "type": "string",
                        "enum": [
                            "classification",
                            "regression",
                            "segmentation",
                            "detection",
                            "seq2seq",
                            "generation",
                            "forecasting",
                            "anomaly_detection",
                            "clustering",
                            "other",
                        ],
                    },
                    "n_samples": {"type": ["integer", "null"]},
                    "size_class": {
                        "type": "string",
                        "enum": ["small", "medium", "large", "huge"],
                    },
                    "tabular": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "n_columns": {"type": ["integer", "null"]},
                            "type_counts": {
                                "type": ["object", "null"],
                                "additionalProperties": False,
                                "properties": {
                                    "numeric": {"type": ["integer", "null"]},
                                    "categorical": {"type": ["integer", "null"]},
                                    "datetime": {"type": ["integer", "null"]},
                                    "text": {"type": ["integer", "null"]},
                                },
                            },
                            "target_balance": {"type": ["number", "null"]},
                            "n_classes": {"type": ["integer", "null"]},
                            "missing_ratio_max": {"type": ["number", "null"]},
                            "sampled_rows": {"type": ["integer", "null"]},
                        },
                    },
                    "image": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "input_shape": {
                                "type": ["array", "null"],
                                "items": {"type": "integer"},
                            },
                            "n_classes": {"type": ["integer", "null"]},
                        },
                    },
                    "text": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "avg_token_len": {"type": ["number", "null"]},
                            "vocab_kind": {
                                "type": ["string", "null"],
                                "enum": [
                                    "english",
                                    "korean",
                                    "multilingual",
                                    "code",
                                    "other",
                                    None,
                                ],
                            },
                        },
                    },
                    "time_series": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "seq_len": {"type": ["integer", "null"]},
                            "freq": {"type": ["string", "null"]},
                        },
                    },
                    "audio": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "sample_rate": {"type": ["integer", "null"]},
                            "avg_duration_sec": {"type": ["number", "null"]},
                        },
                    },
                    "graph": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "n_nodes": {"type": ["integer", "null"]},
                            "n_edges": {"type": ["integer", "null"]},
                            "n_node_features": {"type": ["integer", "null"]},
                        },
                    },
                    "other": {
                        "type": ["object", "null"],
                        "additionalProperties": True,
                        "properties": {
                            "hint": {"type": ["string", "null"]},
                            "payload": {
                                "type": ["object", "null"],
                                "additionalProperties": True,
                            },
                        },
                    },
                    "domain": {
                        "type": "string",
                        "enum": [
                            "general",
                            "medical",
                            "financial",
                            "regulated",
                            "other",
                        ],
                    },
                    "source": {
                        "type": "string",
                        "enum": [
                            "detected",
                            "detected_sampled",
                            "declared",
                            "merged",
                        ],
                    },
                },
                "required": [
                    "schema_version",
                    "modality",
                    "task_kind",
                    "domain",
                    "source",
                ],
            },
        },
        "enums": {
            "status": ["completed", "failed", "config_only", "error"],
        },
    },
    "pcq.run.event": {
        "schema_version": JSON_CONTRACT_VERSION,
        "description": "pcq run --jsonl newline-delimited event",
        "additive_only": True,
        "required": {
            "schema_version": "int",
            "seq": "int",
            "time": "string",
            "event": "string",
        },
        "optional": {
            "status": "string",
            "cmd": "string",
            "project_root": "string",
            "runtime_cfg_path": "string",
            "stream": "string",
            "text": "string",
            "raw": "string",
            "metrics": "object",
            "exit_code": "int",
            "stdout_path": "string",
            "stderr_path": "string",
            "events_path": "string",
            "error": "string",
        },
        "enums": {
            "event": [
                "run.started",
                "run.completed",
                "run.failed",
                "run.error",
                "run.config_only",
                "stdout",
                "stderr",
                "metric",
            ],
        },
    },
    "pcq.describe_run.record": {
        "schema_version": JSON_CONTRACT_VERSION,
        "description": "pcq describe-run --json for a readable RunRecord",
        "additive_only": True,
        "required": {
            "schema_version": "int",
            "status": "string",
            "output_dir": "string",
            "epochs_completed": "int",
            "partial": "boolean",
            "dirty": "boolean",
            "validation_status": "string",
            "decision_facts": "object",
        },
        "optional": {
            "run_id": "string",
            "name": "string",
            "cmd": "string",
            "target_metric": "string",
            "mode": "string",
            "best": "object",
            "best_value": "number",
            "best_epoch": "int",
            "last": "object",
            "last_value": "number",
            "last_epoch": "int",
            "duration_seconds": "number",
            "parent_run_id": "string",
            "parent_run_path": "string",
            "git_sha": "string",
            "python": "string",
            "platform": "string",
            "metrics_declared": "array",
            "artifacts": "array",
            "artifacts_summary": "object",
            "validation_report_path": "string",
            "reproducibility_evidence": "object",
            "failure": "object",
            # attribution 중첩 객체 (Phase 1 — 서명 제외)
            "attribution": "object",
            # attribution 플랫 표면 — 에이전트가 쿼리하기 쉽도록 최상위 노출
            "attribution_author_kind": "string",
            "attribution_committer_kind": "string",
            "attribution_operator": "string",
            "attribution_session_id": "string",
            # worker_spec 중첩 객체 (R13 additive)
            "worker_spec": "object",
            # worker_spec 플랫 표면 — 에이전트가 쿼리하기 쉽도록 최상위 노출
            "worker_spec_cpu_model": "string",
            "worker_spec_memory_gb": "number",
            "worker_spec_accelerator_kind": "string",
            "worker_spec_gpu_model_0": "string",
            # fingerprint 중첩 객체 (T-WFP-2 additive)
            "fingerprint": "object",
            # fingerprint 플랫 표면 — 에이전트가 쿼리하기 쉽도록 최상위 노출
            "fingerprint_modality": "string",
            "fingerprint_task_kind": "string",
            "fingerprint_n_samples": "int",
            "fingerprint_size_class": "string",
            # intent 중첩 객체 (T-PCQ2X-2 additive) — 실험 목표/기대치 선언
            "intent": "object",
            # intent 플랫 표면 — 에이전트가 쿼리하기 쉽도록 최상위 노출
            "intent_goal": "string",
            # integrity 중첩 객체 (T-PCQ2X-2 additive) — 레코드 무결성 해시
            "integrity": "object",
            # integrity 플랫 표면
            "integrity_content_hash": "string",
            # contract_version: 이 레코드를 생성한 pcq 컨트랙트 버전
            "contract_version": "string",
            # code 중첩 객체 (T-PCQRP-2 additive) — 코드 범위 및 콘텐츠 해시
            "code": "object",
            # seeds 중첩 객체 (T-PCQRP-2 additive) — 난수 시드 맵
            "seeds": "object",
            # data_ref 중첩 객체 (T-PCQRP-2 additive) — 데이터셋 식별 정보
            "data_ref": "object",
            # code 플랫 표면 — code.content_sha256 최상위 노출
            "code_content_sha256": "string",
            # seeds 플랫 표면 — 주 시드 최상위 노출
            "seeds_main": "string",
            # seeds_count: 다중 시드 개수 (NOTE-6 — 다중 시드 정보 보존)
            "seeds_count": "int",
            # data_ref 플랫 표면 — data_ref.uri 최상위 노출
            "data_ref_uri": "string",
        },
        # attribution 및 worker_spec 필드의 상세 JSON Schema — property_overrides가 단순 타입 표기를 덮어씀
        "property_overrides": {
            "attribution": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "schema_version": {"type": "integer", "const": 1},
                    "author": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {"type": "string", "enum": ["human", "agent"]},
                            "id": {"type": "string"},
                            "persona_id": {"type": ["string", "null"]},
                        },
                        "required": ["kind", "id"],
                    },
                    "committer": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {"type": "string", "enum": ["human", "agent"]},
                            "id": {"type": "string"},
                            "persona_id": {"type": ["string", "null"]},
                        },
                        "required": ["kind", "id"],
                    },
                    "operator": {"type": "string"},
                    "session_id": {"type": ["string", "null"]},
                },
                "required": ["schema_version", "author", "committer", "operator"],
            },
            "attribution_author_kind": {"type": ["string", "null"]},
            "attribution_committer_kind": {"type": ["string", "null"]},
            "attribution_operator": {"type": ["string", "null"]},
            "attribution_session_id": {"type": ["string", "null"]},
            # worker_spec 풀 JSON Schema (R13)
            "worker_spec": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "schema_version": {"type": "integer", "const": 1},
                    "cpu": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "model": {"type": ["string", "null"]},
                            "cores_physical": {"type": ["integer", "null"]},
                            "cores_logical": {"type": ["integer", "null"]},
                            "max_freq_mhz": {"type": ["integer", "null"]},
                        },
                    },
                    "memory": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "total_gb": {"type": ["number", "null"]},
                        },
                    },
                    "accelerator": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {
                                "type": "string",
                                "enum": ["mps", "cuda", "cpu"],
                            },
                            "gpus": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "additionalProperties": False,
                                    "properties": {
                                        "model": {"type": "string"},
                                        "vram_gb": {"type": ["number", "null"]},
                                        "cuda_version": {"type": ["string", "null"]},
                                        "torch_ordinal": {"type": ["integer", "null"]},
                                    },
                                    "required": ["model"],
                                },
                            },
                            "visible_devices": {"type": ["string", "null"]},
                        },
                        "required": ["kind", "gpus"],
                    },
                    "os": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "system": {"type": "string"},
                            "machine": {"type": "string"},
                            "release": {"type": ["string", "null"]},
                        },
                    },
                    "container": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "kind": {
                                "type": "string",
                                "enum": ["none", "docker", "k8s", "other"],
                            },
                            "image": {"type": ["string", "null"]},
                            "detector_hint": {"type": ["string", "null"]},
                        },
                        "required": ["kind"],
                    },
                    "source": {
                        "type": "string",
                        "enum": ["detected", "declared", "merged"],
                    },
                },
                "required": ["schema_version", "accelerator", "container", "source"],
            },
            # worker_spec 플랫 표면 오버라이드 (null 허용)
            "worker_spec_cpu_model": {"type": ["string", "null"]},
            "worker_spec_memory_gb": {"type": ["number", "null"]},
            "worker_spec_accelerator_kind": {"type": ["string", "null"]},
            "worker_spec_gpu_model_0": {"type": ["string", "null"]},
            # fingerprint 풀 JSON Schema (T-WFP-2)
            "fingerprint": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "schema_version": {"type": "integer", "const": 1},
                    "modality": {
                        "type": "string",
                        "enum": [
                            "tabular",
                            "image",
                            "text",
                            "time_series",
                            "audio",
                            "graph",
                            "other",
                        ],
                    },
                    "task_kind": {
                        "type": "string",
                        "enum": [
                            "classification",
                            "regression",
                            "segmentation",
                            "detection",
                            "seq2seq",
                            "generation",
                            "forecasting",
                            "anomaly_detection",
                            "clustering",
                            "other",
                        ],
                    },
                    "n_samples": {"type": ["integer", "null"]},
                    "size_class": {
                        "type": "string",
                        "enum": ["small", "medium", "large", "huge"],
                    },
                    "tabular": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "n_columns": {"type": ["integer", "null"]},
                            "type_counts": {
                                "type": ["object", "null"],
                                "additionalProperties": False,
                                "properties": {
                                    "numeric": {"type": ["integer", "null"]},
                                    "categorical": {"type": ["integer", "null"]},
                                    "datetime": {"type": ["integer", "null"]},
                                    "text": {"type": ["integer", "null"]},
                                },
                            },
                            "target_balance": {"type": ["number", "null"]},
                            "n_classes": {"type": ["integer", "null"]},
                            "missing_ratio_max": {"type": ["number", "null"]},
                            "sampled_rows": {"type": ["integer", "null"]},
                        },
                    },
                    "image": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "input_shape": {
                                "type": ["array", "null"],
                                "items": {"type": "integer"},
                            },
                            "n_classes": {"type": ["integer", "null"]},
                        },
                    },
                    "text": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "avg_token_len": {"type": ["number", "null"]},
                            "vocab_kind": {
                                "type": ["string", "null"],
                                "enum": [
                                    "english",
                                    "korean",
                                    "multilingual",
                                    "code",
                                    "other",
                                    None,
                                ],
                            },
                        },
                    },
                    "time_series": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "seq_len": {"type": ["integer", "null"]},
                            "freq": {"type": ["string", "null"]},
                        },
                    },
                    "audio": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "sample_rate": {"type": ["integer", "null"]},
                            "avg_duration_sec": {"type": ["number", "null"]},
                        },
                    },
                    "graph": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "n_nodes": {"type": ["integer", "null"]},
                            "n_edges": {"type": ["integer", "null"]},
                            "n_node_features": {"type": ["integer", "null"]},
                        },
                    },
                    "other": {
                        "type": ["object", "null"],
                        "additionalProperties": True,
                        "properties": {
                            "hint": {"type": ["string", "null"]},
                            "payload": {
                                "type": ["object", "null"],
                                "additionalProperties": True,
                            },
                        },
                    },
                    "domain": {
                        "type": "string",
                        "enum": [
                            "general",
                            "medical",
                            "financial",
                            "regulated",
                            "other",
                        ],
                    },
                    "source": {
                        "type": "string",
                        "enum": [
                            "detected",
                            "detected_sampled",
                            "declared",
                            "merged",
                        ],
                    },
                },
                "required": [
                    "schema_version",
                    "modality",
                    "task_kind",
                    "domain",
                    "source",
                ],
            },
            # fingerprint 플랫 표면 오버라이드 (null 허용)
            "fingerprint_modality": {"type": ["string", "null"]},
            "fingerprint_task_kind": {"type": ["string", "null"]},
            "fingerprint_n_samples": {"type": ["integer", "null"]},
            "fingerprint_size_class": {"type": ["string", "null"]},
            # intent 풀 JSON Schema (T-PCQ2X-2) — 실험 목표/기대치/허용오차
            # C1: goal은 null 허용 (SPEC + build_intent_object 동작과 일치) — required에서 제거.
            "intent": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "goal": {
                        "type": ["string", "null"],
                        "enum": [
                            "baseline_reproduction",
                            "sota_challenge",
                            "ablation",
                            "hyperparam_sweep",
                            "exploration",
                            None,
                        ],
                    },
                    "expected_baseline": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "metric": {"type": "string"},
                            "value": {"type": "number"},
                        },
                    },
                    "tolerance": {
                        "type": ["object", "null"],
                        "additionalProperties": False,
                        "properties": {
                            "direction": {
                                "type": "string",
                                "enum": ["higher_is_better", "lower_is_better"],
                            },
                            "margin": {"type": "number"},
                        },
                    },
                },
            },
            # intent 플랫 표면 오버라이드 (null 허용)
            "intent_goal": {"type": ["string", "null"]},
            # integrity 풀 JSON Schema (T-PCQ2X-2) — 레코드 무결성 해시
            "integrity": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "properties": {
                    "content_hash": {"type": "string"},
                    "hashed_fields": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                },
                "required": ["content_hash", "hashed_fields"],
            },
            # integrity 플랫 표면 오버라이드 (null 허용)
            "integrity_content_hash": {"type": ["string", "null"]},
            # contract_version: null 허용 (옛 1.x record 하위 호환)
            "contract_version": {"type": ["string", "null"]},
            # code 풀 JSON Schema (T-PCQRP-2) — 코드 범위 + 콘텐츠 해시
            # scope는 구조화된 객체 (BL-5 비판 반영 — 자유 문자열 금지)
            "code": {
                "type": ["object", "null"],
                "properties": {
                    "content_sha256": {"type": "string", "pattern": "^sha256:"},
                    "scope": {
                        "type": "object",
                        "properties": {
                            "kind": {
                                "type": "string",
                                "enum": ["entry_script", "file_list", "repo_subset"],
                            },
                            "files": {"type": "array", "items": {"type": "string"}},
                            "root": {"type": ["string", "null"]},
                        },
                        "required": ["kind"],
                    },
                },
                "required": ["content_sha256", "scope"],
            },
            # seeds 풀 JSON Schema (T-PCQRP-2) — 난수 시드 맵 (키 자유, 값 int|str)
            "seeds": {
                "type": ["object", "null"],
                "additionalProperties": {"oneOf": [{"type": "integer"}, {"type": "string"}]},
            },
            # data_ref 풀 JSON Schema (T-PCQRP-2) — 데이터셋 식별 정보
            # content_sha256: PHI 게이트 적용 시 null 필수 (R5/R5b)
            "data_ref": {
                "type": ["object", "null"],
                "properties": {
                    "uri": {"type": "string"},
                    "content_sha256": {
                        "type": ["string", "null"],
                        "pattern": "^(sha256:.*)?$",
                    },
                    "size_bytes": {"type": ["integer", "null"]},
                },
                "required": ["uri"],
            },
            # 플랫 표면 오버라이드 (null 허용 — 기존 레코드 하위 호환)
            "code_content_sha256": {"type": ["string", "null"], "pattern": "^(sha256:.*)?$"},
            "seeds_main": {"type": ["integer", "string", "null"]},
            "seeds_count": {"type": ["integer", "null"], "minimum": 0},
            "data_ref_uri": {"type": ["string", "null"]},
        },
        "nested_required": {
            "decision_facts": {
                "run_completed": "boolean",
                "run_failed": "boolean",
                "run_partial": "boolean",
                "validation_passed": "boolean",
                "validation_failed": "boolean",
                "has_failure": "boolean",
                "has_target_metric": "boolean",
                "has_best": "boolean",
                "has_last": "boolean",
                "has_parent": "boolean",
                "artifact_count": "int",
                "metric_count": "int",
                "input_count": "int",
                "dirty_source": "boolean",
                "has_lockfile": "boolean",
                "has_cq_yaml_hash": "boolean",
            },
        },
    },
    "pcq.compare_runs.diff": {
        "schema_version": JSON_CONTRACT_VERSION,
        "description": "pcq compare-runs --json for two readable RunRecords",
        "additive_only": True,
        "required": {
            "schema_version": "int",
            "a_run_id": "string",
            "b_run_id": "string",
            "target_metric": "string",
            "a_target_metric": "string",
            "b_target_metric": "string",
            "mode": "string",
            "metric_direction": "string",
            "best": "object",
            "last": "object",
            "validation": "object",
            "artifacts": "object",
            "decision_facts": "object",
            "a_status": "string",
            "b_status": "string",
            "a_is_ancestor_of_b": "boolean",
            "b_is_ancestor_of_a": "boolean",
        },
        "optional": {
            "metric_delta": "number",
            "last_metric_delta": "number",
            "last_metric_direction": "string",
            "epochs_a": "int",
            "epochs_b": "int",
            "best_epoch_a": "int",
            "best_epoch_b": "int",
            "config_changes": "array",
            "input_changes": "array",
            "failure": "object",
            "source": "object",
            "notes": "array",
            # attribution diff 필드 (T-PCQ-ATTR-3 additive)
            "attribution_diff": "object",
            "attribution_author_changed": "boolean",
            "attribution_committer_changed": "boolean",
            "attribution_operator_changed": "boolean",
            # worker_spec diff 필드 (T-WSPEC-3 additive)
            # True: 두 run의 worker_spec 객체가 다름 (하드웨어/컨테이너 환경 불일치)
            "worker_spec_changed": "boolean",
            # fingerprint diff 필드 (T-WFP-3 additive)
            # True: 두 run의 fingerprint 객체가 다름 (데이터 형태 불일치)
            "fingerprint_changed": "boolean",
            # intent diff 필드 (T-PCQ2X-2 additive)
            # True: 두 run의 intent 객체가 다름 (실험 목표/기대치 불일치)
            "intent_changed": "boolean",
            # integrity diff 필드 (T-PCQ2X-2 additive)
            # True: 두 run의 integrity 해시가 다름 (레코드 내용 불일치)
            "integrity_changed": "boolean",
            # code diff 필드 (T-PCQRP-2 additive)
            # True: 두 run의 code 객체가 다름 (코드 변경 감지)
            "code_changed": "boolean",
            # seeds diff 필드 (T-PCQRP-2 additive)
            # True: 두 run의 seeds 맵이 다름 (시드 변경 감지)
            "seeds_changed": "boolean",
            # data_ref diff 필드 (T-PCQRP-2 additive)
            # True: 두 run의 data_ref가 다름 (데이터셋 변경 감지)
            "data_ref_changed": "boolean",
        },
        "nested_required": {
            "decision_facts": {
                "comparable": "boolean",
                "same_target_metric": "boolean",
                "best_improved": "boolean",
                "best_regressed": "boolean",
                "best_tied": "boolean",
                "last_improved": "boolean",
                "last_regressed": "boolean",
                "last_tied": "boolean",
                "candidate_completed": "boolean",
                "candidate_failed": "boolean",
                "candidate_validated": "boolean",
                "candidate_validation_failed": "boolean",
                "config_changed": "boolean",
                "input_changed": "boolean",
                "artifact_count_changed": "boolean",
                "source_changed": "boolean",
                "same_cq_yaml": "boolean",
                "has_lineage_relation": "boolean",
            },
        },
        "enums": {
            "mode": ["min", "max"],
            "metric_direction": ["improved", "regressed", "tied", "incomparable"],
        },
    },
    "pcq.validation_report": {
        "schema_version": JSON_CONTRACT_VERSION,
        "description": "pcq validate/validate-run --json ValidationReport",
        "additive_only": True,
        "required": {
            "schema_version": "int",
            "status": "string",
            "checks": "array",
            "blocking_count": "int",
            "warning_count": "int",
        },
        "optional": {
            "strictness": "int",
            "strictness_name": "string",
            # operator_required: L2+ strictness에서 attribution.operator 필수 게이트
            # 미설정 시 PII_PATTERN_DETECTED 경고 발생 가능 (R10 additive)
            "operator_required": "boolean",
            # warning_codes: 이번 보고서에서 발생한 경고 코드 목록
            # 포함 가능 코드: "PII_PATTERN_DETECTED"
            "warning_codes": "array",
        },
        "array_item_required": {
            "checks": {
                "id": "string",
                "status": "string",
                "severity": "string",
                "detail": "string",
            },
        },
        # warning_codes 아이템 스키마 — items 열거형으로 알려진 코드를 문서화
        # additionalItems: true — 미래 코드는 하위 호환으로 허용
        "property_overrides": {
            "warning_codes": {
                "type": "array",
                "items": {
                    "type": "string",
                    # 알려진 경고 코드 목록 (추가 코드는 하위 호환으로 허용)
                    "description": (
                        "알려진 경고 코드: "
                        "PII_PATTERN_DETECTED — attribution.operator에 PII 패턴 감지; "
                        "WORKER_PSUTIL_MISSING — psutil 미설치로 CPU/메모리 정보 수집 불가; "
                        "WORKER_PSUTIL_PARTIAL — psutil 설치됐으나 일부 정보 누락 (권한 부족 등); "
                        "WORKER_TORCH_MISSING — torch 미설치로 GPU 정보 수집 불가; "
                        "WORKER_CGROUP_DENIED — cgroup 접근 거부로 컨테이너 메모리 한도 확인 불가; "
                        "WORKER_CONTAINER_AMBIGUOUS — 컨테이너 탐지 결과 불확실 (복수 힌트 충돌); "
                        "WORKER_DECLARED_PII_LIKE — declared worker_spec에 PII 패턴 의심값 포함; "
                        "FINGERPRINT_EMPTY_DATA — pcq.fingerprint() 호출 시 X/y가 None 또는 비어있음 (R11); "
                        "FINGERPRINT_DECLARED_PII_LIKE — declared/merged 경로 자유 문자열에 PII 패턴 의심 (R14); "
                        "FINGERPRINT_DOMAIN_GATE_SKIP — domain 게이트 적용으로 자동 감지 비활성 (R5); "
                        "FINGERPRINT_DOMAIN_SUSPECTED_MEDICAL — domain=medical 의심으로 게이트 활성; "
                        "FINGERPRINT_DOMAIN_SUSPECTED_FINANCIAL — domain=financial 의심으로 게이트 활성; "
                        "FINGERPRINT_SAMPLED — 대용량 데이터로 인한 샘플링 적용 (통계 근사값); "
                        "INTENT_GOAL_INVALID — intent.goal 값이 알려진 열거형에 없음 (T-PCQ2X-2); "
                        "INTENT_TOLERANCE_MALFORMED — intent.tolerance 구조가 유효하지 않음 (T-PCQ2X-2); "
                        "INTEGRITY_HASH_UNCOMPUTABLE — 레코드 무결성 해시 계산 불가 (T-PCQ2X-2)"
                    ),
                    "x-pcq-known-values": [
                        "PII_PATTERN_DETECTED",
                        "WORKER_PSUTIL_MISSING",
                        "WORKER_PSUTIL_PARTIAL",
                        "WORKER_TORCH_MISSING",
                        "WORKER_CGROUP_DENIED",
                        "WORKER_CONTAINER_AMBIGUOUS",
                        "WORKER_DECLARED_PII_LIKE",
                        "FINGERPRINT_EMPTY_DATA",
                        "FINGERPRINT_DECLARED_PII_LIKE",
                        "FINGERPRINT_DOMAIN_GATE_SKIP",
                        "FINGERPRINT_DOMAIN_SUSPECTED_MEDICAL",
                        "FINGERPRINT_DOMAIN_SUSPECTED_FINANCIAL",
                        "FINGERPRINT_SAMPLED",
                        "INTENT_GOAL_INVALID",
                        "INTENT_TOLERANCE_MALFORMED",
                        "INTEGRITY_HASH_UNCOMPUTABLE",
                    ],
                },
            },
        },
        "enums": {
            "status": ["pass", "warn", "fail"],
        },
    },
    "pcq.agent_install.result": {
        "schema_version": JSON_CONTRACT_VERSION,
        "description": "pcq agent install --json result",
        "additive_only": True,
        "required": {
            "schema_version": "int",
            "project_root": "string",
            "target": "string",
            "dry_run": "boolean",
            "force": "boolean",
            "files_created": "array",
            "files_updated": "array",
            "files_skipped": "array",
            "warnings": "array",
            "operations": "array",
        },
        "array_item_required": {
            "operations": {
                "path": "string",
                "action": "string",
                "kind": "string",
                "agent": "string",
                "reason": "string",
            },
        },
        "enums": {
            "target": ["codex", "claude", "both"],
        },
    },
    "pcq.agent_status.result": {
        "schema_version": JSON_CONTRACT_VERSION,
        "description": "pcq agent status --json read-only result",
        "additive_only": True,
        "required": {
            "schema_version": "int",
            "project_root": "string",
            "target": "string",
            "status": "string",
            "assets": "array",
            "repair_command": "string",
        },
        "array_item_required": {
            "assets": {
                "path": "string",
                "agent": "string",
                "kind": "string",
                "status": "string",
                "detail": "string",
                "suggested_fix": "string",
            },
        },
        "enums": {
            "target": ["codex", "claude", "both"],
            "status": [
                "missing",
                "installed",
                "partial",
                "stale",
                "unmanaged",
                "divergent",
            ],
        },
    },
}


_TYPE_MAP = {
    "object": dict,
    "array": list,
    "string": str,
    "boolean": bool,
}


def get_json_contracts() -> dict[str, dict[str, Any]]:
    """Return a JSON-serializable copy of the public contract registry."""
    return deepcopy(JSON_CONTRACTS)


def validate_json_contract(name: str, payload: Any) -> list[str]:
    """Validate ``payload`` against a named minimum JSON contract.

    This is deliberately a tiny stdlib validator rather than a full JSON Schema
    engine. It exists to freeze pcq's public agent surface without adding a
    runtime dependency.
    """
    spec = JSON_CONTRACTS.get(name)
    if spec is None:
        return [f"unknown contract: {name}"]
    if not isinstance(payload, dict):
        return [f"{name}: payload must be object"]

    errors: list[str] = []
    _validate_fields(errors, payload, spec.get("required", {}), required=True)
    _validate_fields(errors, payload, spec.get("optional", {}), required=False)
    _validate_enums(errors, payload, spec.get("enums", {}))
    _validate_nested_required(errors, payload, spec.get("nested_required", {}))
    _validate_array_items(errors, payload, spec.get("array_item_required", {}))
    return errors


def _validate_fields(
    errors: list[str],
    payload: dict[str, Any],
    fields: dict[str, str],
    *,
    required: bool,
    prefix: str = "",
) -> None:
    for key, type_name in fields.items():
        path = f"{prefix}{key}"
        if key not in payload:
            if required:
                errors.append(f"missing required field: {path}")
            continue
        if not _matches_type(payload[key], type_name):
            errors.append(
                f"{path}: expected {type_name}, got "
                f"{type(payload[key]).__name__}"
            )


def _validate_enums(
    errors: list[str],
    payload: dict[str, Any],
    enums: dict[str, list[Any]],
    *,
    prefix: str = "",
) -> None:
    for key, allowed in enums.items():
        if key in payload and payload[key] not in allowed:
            errors.append(
                f"{prefix}{key}: expected one of {allowed}, got {payload[key]!r}"
            )


def _validate_nested_required(
    errors: list[str],
    payload: dict[str, Any],
    nested: dict[str, dict[str, str]],
) -> None:
    for key, fields in nested.items():
        value = payload.get(key)
        if not isinstance(value, dict):
            errors.append(f"{key}: expected object for nested contract")
            continue
        _validate_fields(errors, value, fields, required=True, prefix=f"{key}.")


def _validate_array_items(
    errors: list[str],
    payload: dict[str, Any],
    arrays: dict[str, dict[str, str]],
) -> None:
    for key, fields in arrays.items():
        value = payload.get(key)
        if value is None:
            continue
        if not isinstance(value, list):
            errors.append(f"{key}: expected array")
            continue
        for idx, item in enumerate(value):
            if not isinstance(item, dict):
                errors.append(f"{key}[{idx}]: expected object")
                continue
            _validate_fields(
                errors, item, fields, required=True, prefix=f"{key}[{idx}]."
            )


def _matches_type(value: Any, type_name: str) -> bool:
    if type_name == "any":
        return True
    if type_name == "int":
        return type(value) is int
    if type_name == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    expected = _TYPE_MAP.get(type_name)
    if expected is None:
        return False
    return isinstance(value, expected)
