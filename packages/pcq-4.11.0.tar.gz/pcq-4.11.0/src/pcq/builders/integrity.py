"""pcq.builders.integrity — integrity 객체 빌더 (T-PCQA-A-1).

contract.py 에서 분리됨. 외부 사용자: `from pcq.contract import build_integrity_object`
(re-export) 또는 `from pcq.builders import build_integrity_object` (신규 권장).

_EXCLUDED 는 function-local 유지 (BL-4 critique fix — 본래 모듈 레벨이 아니었음).
"""
from __future__ import annotations

import hashlib
import json


# integrity 계산 시 해시 입력에 포함할 최상위 경로 목록 (anti-recursion 제외 적용).
# "attribution.signature" 와 "integrity" 자체는 제외 — 순환 방지.
_INTEGRITY_HASHED_FIELDS: list[str] = [
    "intent",
    "code.content_sha256",
    "code.scope",
    "config",
    "contract_version",
    "data_fingerprint",
    "data_ref.content_sha256",
    "metrics",
    "seeds",
    "worker_spec",
    "attribution.author",
    "attribution.committer",
    "attribution.operator",
]


def _resolve_dotted_path(payload: dict, path: str) -> object:
    """점(.) 구분 경로로 payload 에서 값을 추출합니다.

    예: "attribution.operator" → payload["attribution"]["operator"].
    중간 키가 없거나 None 이면 None 반환.
    """
    parts = path.split(".")
    current: object = payload
    for part in parts:
        if not isinstance(current, dict):
            return None
        current = current.get(part)
    return current


def build_integrity_object(
    payload: dict,
    hashed_fields: list[str] | None = None,
) -> tuple[dict | None, list[dict]]:
    """integrity 객체를 생성하고 반환합니다.

    payload 에서 hashed_fields 경로 목록에 해당하는 값을 추출하여
    canonical JSON 직렬화 후 sha256 해시를 계산합니다.

    Anti-recursion:
      - "attribution.signature" 는 hashed_fields 에 있어도 제거합니다 (Phase 2 예약).
      - "integrity" 자체는 hashed_fields 에 있어도 제거합니다 (순환 방지).

    Hash canonical form: json.dumps(subset, indent=2, sort_keys=True, default=str)
    → _atomic_write_json 과 동일한 형식.

    Args:
        payload: 해시 계산 대상 run_record dict.
        hashed_fields: 포함할 경로 목록. None 이면 _INTEGRITY_HASHED_FIELDS 사용.

    Returns:
        (integrity_dict, warnings) 튜플.
        integrity_dict: {"content_hash": "sha256:...", "hashed_fields": [...]} 또는
                        계산 실패 시 None.
        warnings: [{code, message}] 목록.
    """
    warnings: list[dict] = []

    # anti-recursion 제외 경로.
    _EXCLUDED: frozenset[str] = frozenset({"attribution.signature", "integrity"})

    fields_to_use = list(hashed_fields) if hashed_fields is not None else list(_INTEGRITY_HASHED_FIELDS)
    # 제외 경로 필터링 — 순서 유지.
    fields_to_use = [f for f in fields_to_use if f not in _EXCLUDED]

    try:
        # payload 에서 각 경로 값을 추출하여 부분집합 dict 구성.
        # 경로가 점 구분이면 중첩 조회, 아니면 단순 키 조회.
        # 부재 리프(absent leaf) 동작: _resolve_dotted_path 가 None 을 반환하면
        # subset 에서 해당 키를 완전히 제거한다 — null 로 포함하지 않는다.
        # 이로 인해 (a) data_ref 전체 부재 레코드와 (b) PHI 게이트로
        # data_ref.content_sha256 이 None 으로 stripped 된 레코드가,
        # 나머지 해시 입력이 동일하면 동일한 integrity hash 를 산출한다.
        subset: dict = {
            path: _resolve_dotted_path(payload, path)
            for path in fields_to_use
            if _resolve_dotted_path(payload, path) is not None
        }

        # canonical 직렬화 — _atomic_write_json 과 동일한 형식.
        canonical = json.dumps(subset, indent=2, sort_keys=True, default=str)
        hex_digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        content_hash = f"sha256:{hex_digest}"
    except Exception:  # noqa: BLE001
        warnings.append({
            "code": "INTEGRITY_HASH_UNCOMPUTABLE",
            "message": "integrity content_hash 계산에 실패했습니다.",
        })
        return None, warnings

    return {
        "content_hash": content_hash,
        "hashed_fields": fields_to_use,
    }, warnings
