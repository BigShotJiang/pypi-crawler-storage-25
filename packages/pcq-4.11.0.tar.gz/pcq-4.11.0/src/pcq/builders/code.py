"""pcq.builders.code — code 객체 빌더 (T-PCQA-A-1).

contract.py 에서 분리됨. 외부 사용자: `from pcq.contract import build_code_object`
(re-export) 또는 `from pcq.builders import build_code_object` (신규 권장).
"""
from __future__ import annotations


# code.scope.kind 허용 열거형.
_VALID_CODE_SCOPE_KINDS: frozenset[str] = frozenset({
    "entry_script",
    "file_list",
    "repo_subset",
})


def build_code_object(
    content_sha256: str | None,
    scope: dict | None,
) -> tuple[dict | None, list[dict]]:
    """code content sha + structured scope 객체를 조립합니다.

    실험에 사용된 코드 범위와 그 content hash 를 기록합니다.
    모든 입력이 None 이면 (None, []) 반환 — 호출자가 unconditional 호출 가능.

    Args:
        content_sha256: 코드 content 해시 (권장 형식: "sha256:<hex>").
                        형식 위반 시 경고 발생 후 원본 값 유지.
        scope: {"kind": str, ...} 형태 dict. kind 가 허용 열거형 밖이면 경고.
               dict 가 아닌 경우 CODE_SCOPE_MALFORMED 경고 후 scope None 처리.

    Returns:
        (code_dict | None, warnings) 튜플.
        code_dict: {"content_sha256": ..., "scope": ...} 또는
                   두 입력 모두 None 이면 None.
        warnings: [{code, message, field?}] 목록.
    """
    warnings: list[dict] = []

    # 두 입력 모두 None → 생략 (NOTE-3).
    if content_sha256 is None and scope is None:
        return None, []

    # content_sha256 형식 검증 — sha256: 접두사 확인.
    resolved_sha: str | None = content_sha256
    if content_sha256 is not None and not content_sha256.startswith("sha256:"):
        warnings.append({
            "code": "CODE_CONTENT_SHA_FORMAT_INVALID",
            "message": (
                f"code.content_sha256 값이 'sha256:' 접두사로 시작하지 않습니다: {content_sha256!r}. "
                "스키마 검증에서 거부될 수 있습니다. 원본 값을 유지합니다."
            ),
            "field": "code.content_sha256",
        })
        # 원본 값 유지 — 스키마 검증이 downstream 에서 처리하도록 위임.

    # scope 검증.
    resolved_scope: dict | None = None
    if scope is not None:
        if not isinstance(scope, dict):
            # dict 가 아니면 malformed — scope None 처리.
            warnings.append({
                "code": "CODE_SCOPE_MALFORMED",
                "message": (
                    f"code.scope 가 dict 가 아닙니다: {type(scope).__name__!r}. "
                    "scope 를 None 으로 처리합니다."
                ),
                "field": "code.scope",
            })
        else:
            kind = scope.get("kind")
            if kind not in _VALID_CODE_SCOPE_KINDS:
                # kind 유효하지 않으면 경고 + kind None 처리, 나머지 필드 유지.
                warnings.append({
                    "code": "CODE_SCOPE_KIND_INVALID",
                    "message": (
                        f"code.scope.kind 값이 허용 열거형에 없습니다: {kind!r}. "
                        f"허용값: {sorted(_VALID_CODE_SCOPE_KINDS)!r}. "
                        "kind 를 None 으로 처리합니다."
                    ),
                    "field": "code.scope.kind",
                })
                resolved_scope = {**scope, "kind": None}
            else:
                resolved_scope = scope

    return {
        "content_sha256": resolved_sha,
        "scope": resolved_scope,
    }, warnings
