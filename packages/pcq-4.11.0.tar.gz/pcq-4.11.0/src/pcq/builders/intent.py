"""pcq.builders.intent — intent 객체 빌더 (T-PCQA-A-1).

contract.py 에서 분리됨. 외부 사용자: `from pcq.contract import build_intent_object`
(re-export) 또는 `from pcq.builders import build_intent_object` (신규 권장).
"""
from __future__ import annotations


# goal 열거형 — json_contracts.py property_overrides 와 동일하게 유지.
_VALID_INTENT_GOALS: frozenset[str] = frozenset({
    "baseline_reproduction",
    "sota_challenge",
    "ablation",
    "hyperparam_sweep",
    "exploration",
})


def build_intent_object(
    goal: str | None = None,
    expected_baseline: dict | None = None,
    tolerance: dict | None = None,
) -> tuple[dict | None, list[dict]]:
    """intent 객체를 조립합니다. (재프레이밍: intent는 *기록자의 주장*의 사실 기록.)

    pcq는 intent 내용의 진위를 판단하지 않는다. 주장 내용이 의견(예: "AUC 0.84 이상이면
    성공")이어도 *그런 주장이 있었다는 것 자체는 사실*. pcq positioning #3 "Evidence,
    not opinion"은 *pcq가 의견을 내지 않는다*는 뜻이지, 사용자의 주장을 못 적는다는
    뜻이 아니다.

    실험 실행 전 목적을 기록합니다. 모든 필드는 null 허용 (전부 None 이면 None 반환).

    Args:
        goal: 실험 목적 열거형 ("baseline_reproduction" | "sota_challenge" |
              "ablation" | "hyperparam_sweep" | "exploration") 또는 None.
              알 수 없는 값은 경고를 발생시키고 None 으로 처리.
        expected_baseline: {"metric": str, "value": number} 형태 dict 또는 None.
                           구조가 올바르지 않으면 경고 발생.
        tolerance: {"direction": str, "margin": number} 형태 dict 또는 None.
                   구조가 올바르지 않으면 경고 발생.

    Returns:
        (intent_dict | None, warnings) 튜플.
        intent_dict: goal/expected_baseline/tolerance 를 포함한 dict, 또는
                     세 필드 모두 None 이면 None.
        warnings: [{code, message, field?}] 목록.
    """
    warnings: list[dict] = []

    # goal 검증 — 알 수 없는 값은 None 처리 + 경고 (예외 미발생).
    resolved_goal: str | None = goal
    if goal is not None and goal not in _VALID_INTENT_GOALS:
        warnings.append({
            "code": "INTENT_GOAL_INVALID",
            "message": (
                f"intent.goal 값이 알려진 열거형에 없습니다: {goal!r}. "
                f"허용값: {sorted(_VALID_INTENT_GOALS)!r}"
            ),
            "field": "intent.goal",
        })
        resolved_goal = None

    # expected_baseline 검증 — {metric: str, value: number} 구조 확인.
    resolved_baseline: dict | None = None
    if expected_baseline is not None:
        metric = expected_baseline.get("metric") if isinstance(expected_baseline, dict) else None
        value = expected_baseline.get("value") if isinstance(expected_baseline, dict) else None
        if isinstance(metric, str) and isinstance(value, (int, float)):
            resolved_baseline = {"metric": metric, "value": value}
        else:
            warnings.append({
                "code": "INTENT_TOLERANCE_MALFORMED",
                "message": (
                    "intent.expected_baseline 구조가 유효하지 않습니다. "
                    '{"metric": str, "value": number} 형태가 필요합니다.'
                ),
                "field": "intent.expected_baseline",
            })

    # tolerance 검증 — {direction: str, margin: number} 구조 확인.
    resolved_tolerance: dict | None = None
    if tolerance is not None:
        direction = tolerance.get("direction") if isinstance(tolerance, dict) else None
        margin = tolerance.get("margin") if isinstance(tolerance, dict) else None
        if isinstance(direction, str) and isinstance(margin, (int, float)):
            resolved_tolerance = {"direction": direction, "margin": margin}
        else:
            warnings.append({
                "code": "INTENT_TOLERANCE_MALFORMED",
                "message": (
                    "intent.tolerance 구조가 유효하지 않습니다. "
                    '{"direction": str, "margin": number} 형태가 필요합니다.'
                ),
                "field": "intent.tolerance",
            })

    # 세 필드 모두 None 이면 intent 생략.
    if resolved_goal is None and resolved_baseline is None and resolved_tolerance is None:
        return None, warnings

    return {
        "goal": resolved_goal,
        "expected_baseline": resolved_baseline,
        "tolerance": resolved_tolerance,
    }, warnings
