"""pcq.builders — record builder functions, split from contract.py (T-PCQA-A-1).

contract.py god module(~2,659줄) 축소: 6 builder + 관련 상수만 이 패키지로.
lifecycle/git/env/file helper는 contract.py 유지.

외부 사용자: `from pcq.contract import build_*` 100% 작동 (re-export).
신규 권장: `from pcq.builders import build_*` (직접).

NOTE: pcq.builders.fingerprint_builder ≠ pcq.fingerprint:
- pcq.fingerprint = 모달리티별 데이터 통계 추출 (extract_tabular, extract_image 등)
- pcq.builders.fingerprint_builder = validation frozensets + 객체 조립 (build_fingerprint_object)
두 모듈은 양방향 독립 (zero cross-imports — 검증됨).
"""
from pcq.builders.attribution import build_attribution_object
from pcq.builders.intent import build_intent_object, _VALID_INTENT_GOALS
from pcq.builders.integrity import (
    build_integrity_object,
    _resolve_dotted_path,
    _INTEGRITY_HASHED_FIELDS,
)
from pcq.builders.code import build_code_object
from pcq.builders.seeds import build_seeds_object
from pcq.builders.data_ref import build_data_ref_object, _PHI_DOMAINS
from pcq.builders.fingerprint_builder import build_fingerprint_object
from pcq.builders.worker_spec import build_worker_spec_object

# _PHI_DOMAINS는 underscore prefix지만 contract.py finalize_run의 BL-3 dual gate가
# 사용하므로 의도적 cross-package 노출 (BL-5 option a). external API 의도 아님 —
# PyPI v4.10.0 surface 그대로 유지 (re-export로 외부엔 변화 0).
__all__ = [
    "build_attribution_object",
    "build_code_object",
    "build_data_ref_object",
    "build_fingerprint_object",
    "build_intent_object",
    "build_integrity_object",
    "build_seeds_object",
    "build_worker_spec_object",
    "_INTEGRITY_HASHED_FIELDS",
    "_PHI_DOMAINS",
    "_VALID_INTENT_GOALS",
    "_resolve_dotted_path",
]
