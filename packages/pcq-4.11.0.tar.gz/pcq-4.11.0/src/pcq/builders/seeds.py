"""pcq.builders.seeds — seeds 객체 빌더 (T-PCQA-A-1).

contract.py 에서 분리됨. 외부 사용자: `from pcq.contract import build_seeds_object`
(re-export) 또는 `from pcq.builders import build_seeds_object` (신규 권장).
"""
from __future__ import annotations


def build_seeds_object(seeds: dict | None) -> tuple[dict | None, list[dict]]:
    """seeds dict (multi-seed 지원, {name: int|str}) 를 검증·조립합니다.

    난수 시드를 이름 → 값 매핑으로 기록합니다.
    None 또는 빈 dict 이면 (None, []) 반환.
    각 값이 int 또는 str 이 아니면 해당 키를 제거하고 경고를 발생시킵니다.

    Args:
        seeds: {"main": 42, "numpy": 42, ...} 형태 dict 또는 None.

    Returns:
        (seeds_dict | None, warnings) 튜플.
        seeds_dict: 정렬된 키를 가진 dict (R15 결정론적 직렬화) 또는 None.
        warnings: [{code, message, field?}] 목록.
    """
    warnings: list[dict] = []

    # None 또는 빈 dict → 생략.
    if not seeds:
        return None, []

    # 각 값 타입 검증 — int 또는 str 만 허용.
    valid: dict = {}
    for key, value in seeds.items():
        if isinstance(value, (int, str)):
            valid[key] = value
        else:
            warnings.append({
                "code": "SEEDS_VALUE_INVALID_TYPE",
                "message": (
                    f"seeds[{key!r}] 값이 int 또는 str 이 아닙니다: "
                    f"{type(value).__name__!r} ({value!r}). 해당 키를 제거합니다."
                ),
                "field": f"seeds.{key}",
            })

    # 유효한 키가 없으면 None 반환.
    if not valid:
        return None, warnings

    # R15 결정론적 직렬화를 위해 키 정렬.
    return dict(sorted(valid.items())), warnings
