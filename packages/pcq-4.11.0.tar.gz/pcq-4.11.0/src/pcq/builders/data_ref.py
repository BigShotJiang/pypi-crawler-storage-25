"""pcq.builders.data_ref — data_ref 객체 빌더 (T-PCQA-A-1).

contract.py 에서 분리됨. 외부 사용자: `from pcq.contract import build_data_ref_object`
(re-export) 또는 `from pcq.builders import build_data_ref_object` (신규 권장).

_PHI_DOMAINS 는 builders/__init__.py 를 통해 의도적으로 cross-package 노출됨 (BL-5).
contract.py finalize_run 의 lifecycle 2차 게이트가 이를 사용.
"""
from __future__ import annotations


# data_ref PHI 게이트 대상 도메인 — DEC-004.
_PHI_DOMAINS: frozenset[str] = frozenset({
    "medical",
    "financial",
    "regulated",
})


def build_data_ref_object(
    uri: str | None,
    content_sha256: str | None,
    size_bytes: int | None,
    *,
    domain: str = "general",
) -> tuple[dict | None, list[dict]]:
    """data 참조 객체를 조립합니다. PHI 도메인은 content_sha256 stripped.

    실험에 사용된 데이터셋의 URI, content hash, 크기를 기록합니다.
    PHI 도메인(medical / financial / regulated)에서는 content_sha256 을
    강제 null 로 처리합니다 — re-identification 보조 신호 제거 (R5/R5b, DEC-004).

    Args:
        uri: 데이터셋 식별자 (opaque string; "cq://", "s3://", "file://", 임의 URI).
        content_sha256: 데이터셋 content 해시 (권장 형식: "sha256:<hex>").
                        형식 위반 시 경고 발생 후 원본 값 유지.
        size_bytes: 바이트 단위 크기.
        domain: fingerprint.domain 값. PHI 도메인 판별에 사용.
                기본값 "general" (비 PHI).

    Returns:
        (data_ref_dict | None, warnings) 튜플.
        data_ref_dict: {"uri": ..., "content_sha256": ..., "size_bytes": ...} 또는
                       세 입력 모두 None 이면 None.
        warnings: [{code, message, field?}] 목록.
    """
    warnings: list[dict] = []

    # 세 입력 모두 None → 생략.
    if uri is None and content_sha256 is None and size_bytes is None:
        return None, []

    resolved_sha: str | None = content_sha256

    # PHI 게이트 (DEC-004) — 내부 1차 방어선. T-PCQRP-4 lifecycle 에서 2차 게이트.
    if domain in _PHI_DOMAINS and resolved_sha is not None:
        warnings.append({
            "code": "DATA_REF_CONTENT_SHA_SUPPRESSED_PHI",
            "message": (
                f"data_ref.content_sha256 가 PHI 도메인({domain!r})으로 인해 null 로 처리됩니다. "
                "content hash 는 re-identification 보조 신호가 될 수 있어 emit 이 금지됩니다 (R5/R5b)."
            ),
            "field": "data_ref.content_sha256",
        })
        resolved_sha = None

    # content_sha256 형식 검증 — PHI 게이트 적용 후 잔존하는 값만 검사.
    if resolved_sha is not None and not resolved_sha.startswith("sha256:"):
        warnings.append({
            "code": "DATA_REF_CONTENT_SHA_FORMAT_INVALID",
            "message": (
                f"data_ref.content_sha256 값이 'sha256:' 접두사로 시작하지 않습니다: {resolved_sha!r}. "
                "스키마 검증에서 거부될 수 있습니다. 원본 값을 유지합니다."
            ),
            "field": "data_ref.content_sha256",
        })
        # 원본 값 유지 — 스키마 검증이 downstream 에서 처리.

    return {
        "uri": uri,
        "content_sha256": resolved_sha,
        "size_bytes": size_bytes,
    }, warnings
