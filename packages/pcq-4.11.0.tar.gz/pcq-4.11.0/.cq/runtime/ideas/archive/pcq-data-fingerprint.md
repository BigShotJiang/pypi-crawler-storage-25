# pcq data fingerprint — 문제(데이터) 형태를 양식에 박기

> pcq 1.x에 `fingerprint` 객체 additive 추가. TheCommons 매치메이커 3-축의 *마지막*.
> PII-safe 자동 + cq.yaml declared + **agent가 자동 삽입** (Wiki+봇 모델 완성).

## 한 줄 비전

> **모든 pcq run_record가 *어떤 데이터 형태*에서 실행됐는지 PII 없이 1급으로 기록한다.**

## TheCommons 매치메이커 3-축 완성

| 축 | 사이클 | 상태 |
|---|---|---|
| 행위자 (Who) | pcq-agent-attribution | ✅ 완료 (8 commits, R-1~8 APPROVE) |
| 컴퓨터 (Where) | pcq-worker-spec | ✅ 완료 (8 commits, R-1~8 APPROVE) |
| **문제 (What)** | **pcq-data-fingerprint (이번)** | ← 진행 |

세 축 모두 **에이전트가 자동 채울 수 있음** — 사용자는 *의도*만, 에이전트가 모든 메타를 박는다. 이게 Wikipedia+봇 모델의 *행동 기반* 완성.

## 확정 결정 (사용자와 직접 결정)

- **PII 정책 = 옵션 A**: 안전 자동 + 의료/금융 declared-only 게이트
- **자동 메커니즘 = (a) + (b) 조합**:
  - **(a)** `pcq.fingerprint(X, y, modality=...)` API — 사용자(또는 에이전트)가 train.py에 한 줄 추가, pcq가 안전 추출
  - **(b)** `cq.yaml.fingerprint:` declared — 의료/금융 또는 사용자 명시 선호
- **agent 자동 삽입** — pcq agent install이 train.py 템플릿에 pcq.fingerprint() 자리 마련, Claude Code/Codex가 자동 채움
- **자동 안전 필드**: modality, n_samples, input shape, type_counts (이름 X, 개수만), task_kind, target_balance 비율, missing_ratio_max
- **자동 절대 금지**: column 이름, raw value, value distribution top-N, sample preview
- **도메인 게이트**: `domain ∈ {medical, financial, regulated}` 시 자동 감지 비활성, declared만
- **R14 PII pattern check** (worker_spec 패턴 그대로): declared/merged 경로의 자유 문자열에 hostname/email/SSN-shape 패턴 시 L3+ warn
- **3-축 결합**: run_record 최상위 sibling 셋 (attribution / worker_spec / fingerprint)

## 핵심 설계

### fingerprint 객체 (Standard 1.0)

```json
"fingerprint": {
  "schema_version": 1,
  "modality": "tabular"|"image"|"text"|"time_series"|"audio"|"graph"|"other",
  "task_kind": "classification"|"regression"|"segmentation"|"detection"|"seq2seq"|"generation"|"forecasting"|"anomaly_detection"|"clustering"|"other",
  "n_samples": 50000,                  // int|null
  "size_class": "small"|"medium"|"large"|"huge",  // <10k / <1M / <100M / 이상
  "tabular": {                          // modality=tabular 시
    "n_columns": 25,                    // int|null
    "type_counts": {                    // 이름 X, 개수만
      "numeric": 20, "categorical": 5, "datetime": 0, "text": 0
    },
    "target_balance": 0.91,             // majority class ratio | null
    "n_classes": 2,                     // int|null (classification만)
    "missing_ratio_max": 0.15           // float|null
  },
  "image": {                            // modality=image 시
    "input_shape": [512, 512, 3],
    "n_classes": 1000                   // int|null
  },
  "text": {                             // modality=text 시
    "avg_token_len": 128,
    "vocab_kind": "english"|"korean"|"multilingual"|"code"|"other"
  },
  "time_series": {
    "seq_len": 365,
    "freq": "daily"|"hourly"|"irregular"|"other"
  },
  "audio": {
    "sample_rate": 16000,
    "avg_duration_sec": 5.0
  },
  "graph": {
    "n_nodes": 10000,
    "n_edges": 50000,
    "n_node_features": 8
  },
  "domain": "general"|"medical"|"financial"|"regulated"|"other",  // 도메인 게이트
  "source": "detected"|"declared"|"merged"
}
```

### Flat surface (4개, attribution/worker_spec 패턴)

- `fingerprint_modality` — string|null
- `fingerprint_task_kind` — string|null
- `fingerprint_n_samples` — int|null
- `fingerprint_size_class` — string|null (가장 매칭 친화)

### `pcq.fingerprint()` API (a)

```python
import pcq

X_train, y_train = load_data()

# 단순 호출 — pcq가 안전 추출
pcq.fingerprint(X_train, y_train, modality="tabular", task_kind="classification")

# 또는 image:
pcq.fingerprint(images, labels, modality="image", task_kind="classification")
```

내부 동작:
1. modality 인자로 어떤 추출 함수 사용할지 결정
2. type_counts·shape·target_balance 등 *안전 통계*만 계산 (column 이름·값 X)
3. 결과를 contract 내부에 캐시 (finalize_run 시 run_record.fingerprint로)
4. domain ∈ {medical, financial, regulated} 시 자동 추출 비활성, declared만 수용

### cq.yaml declared 경로 (b)

```yaml
fingerprint:
  modality: tabular
  task_kind: binary_classification
  n_samples: 50000
  domain: medical    # 자동 게이트 트리거
  tabular:
    n_columns: 25
    type_counts: { numeric: 20, categorical: 5 }
    target_balance: 0.91
  source: declared
```

### Agent 자동 삽입 (R9 패턴 확장)

`pcq agent install` 시 templates/AGENTS.pcq.md에 *fingerprint 호출 자동 삽입 가이드*:

```markdown
## Fingerprint (agent-managed)

When you write train.py, after data load, ADD ONE LINE:

```python
import pcq
X_train, y_train = load_data()
pcq.fingerprint(X_train, y_train, modality="tabular", task_kind="classification")
# ... rest of training
```

Detection rules for agents:
- pandas DataFrame → modality="tabular"
- numpy array with shape [N, H, W, C] → modality="image"
- list[str] → modality="text"
- ...
```

## 차별점 — 기존 시도와 공백

| 시도 | 한계 | 우리 |
|---|---|---|
| HuggingFace dataset_info | sample 포함, PII 위험 | sample 0, 통계만 |
| pandas-profiling | column 이름·값 그대로 | 이름 X, type 개수만 |
| MLflow data | 매칭 친화 X | 매칭 1급 |
| Great Expectations | 형식만, 분포 X | 형식 + 분포 모먼트 |
| DVC dvc.lock | content hash만 | 형태 정보 |
| Data Card (Google) | 사람용 문서 | 기계용 JSON |
| Croissant 표준 | 풍부하지만 PII 분리 약함 | PII layered policy |

**공백**: *PII-free + 매칭 친화 + cross-modality + agent-fillable* 표준. 우리 자리.

## 요구사항 (EARS)

### 기능 요구사항

- **R1** WHEN pcq writes a run_record.json, the system shall include an optional
  `fingerprint` object conforming to the schema defined.
- **R2** WHERE the fingerprint object is present, `modality`, `task_kind`,
  `domain`, and `source` shall be populated. All other fields MAY be null.
- **R3** WHEN user calls `pcq.fingerprint(X, y, modality=...)`, the system
  shall extract *safe statistics only* (shape, type counts, target balance
  ratio, missing ratio) and emit `source: "detected"` (or "merged" if cfg
  also declares).
- **R4** WHEN `cq.yaml.fingerprint:` declares fields without `pcq.fingerprint()`
  call, the system shall use those values and emit `source: "declared"`.
- **R5** WHERE `cq.yaml.fingerprint.domain ∈ {medical, financial, regulated}`,
  the auto-detection path of `pcq.fingerprint()` shall be DISABLED — only
  declared values from cq.yaml are accepted; calling `pcq.fingerprint(X, y)`
  on such project shall emit only modality/task_kind hints (no statistics).
- **R6** WHERE `pcq describe-run --json` outputs the record, fingerprint
  shall be exposed both as a nested object AND as 4 flat fields
  (`fingerprint_modality`, `fingerprint_task_kind`, `fingerprint_n_samples`,
  `fingerprint_size_class`).
- **R7** WHEN existing run_records without a `fingerprint` field are read,
  pcq shall treat them as valid. Both `fingerprint: null` and key absent
  shall be valid representations.
- **R8** WHEN fingerprint is added, sibling schemas shall passthrough it:
  `pcq.compare_runs.diff` shall expose `fingerprint_changed: boolean`,
  `pcq.run.envelope` shall carry fingerprint.
- **R9** WHEN pcq.agent.json_contracts registers fingerprint, two golden
  conformance pairs shall be added: (a) with-fingerprint-tabular,
  (b) without-fingerprint.
- **R10** IF auto-detection (R3 path) encounters column names, raw values,
  or value-level distributions, the system shall NEVER emit them. R10 is
  format-layer prohibition on detection path.
- **R11** IF `pcq.fingerprint(X, y)` is called but X/y are None or empty,
  the system shall emit partial fingerprint (modality/task_kind from args,
  stats null) + validation_report warning `FINGERPRINT_EMPTY_DATA`.
- **R12** IF the modality argument is not in the enum, the system shall
  raise ValueError. Same for task_kind, domain, size_class enums.
- **R13** WHERE pcq agent install writes agent runtime assets, the assets
  shall include guidance for inserting `pcq.fingerprint(X, y, modality=...)`
  one-line call after data load + modality auto-detection hints.
- **R14** IF source ∈ {"declared", "merged"} AND a free-string field
  (any custom modality-specific string fields, future extensions) matches
  hostname/email/SSN-shape pattern, validate_run at strictness L3+ shall
  emit `FINGERPRINT_DECLARED_PII_LIKE` warning (warn only).

### 비기능

- **Additive only**: 옛 record fingerprint 부재/null 모두 valid.
- **PII layered**: R10 (detection-level prohibition) + R5 (domain gate) + R14 (declared pattern warn)
- **Agent-fillable**: agent install asset에 modality detection rules + 1-line call 가이드
- **No new dep**: pure numpy/pandas inspection (이미 user가 가짐). torch.is_tensor도 stdlib 수준.
- **Graceful**: data load 실패해도 fingerprint 누락은 학습 중단 X (warning만).

### 범위 외

- raw value distribution / histogram bins (Phase 2 with k-anonymity)
- column 이름 emit (영원히 X — R10)
- sample preview (영원히 X — R10)
- TheCommons 측 fingerprint 인덱싱 (TC 빌드)
- domain enum 확장 (1.0은 5개; legal/biotech 등은 Phase 2)
- multi-target (tabular에 target 2개 이상) — 1.0은 단일 target

## 리스크

| 리스크 | 심각도 | 대응 |
|---|---|---|
| domain 게이트 우회 (사용자가 medical인데 general로 선언) | 중 | R10/R14 layered + docs 강조 |
| pcq.fingerprint(X, y) 호출 누락 → fingerprint 빈약 | 중 | agent install asset가 자동 삽입 권고 (R13) |
| modality 자동 감지 어려움 (DataLoader 같은 객체) | 중 | 사용자가 modality 인자 명시 강제, auto-modality는 Phase 2 |
| target_balance 추출이 의료 데이터에서 PII 누설? | 낮 | majority ratio만 (값 자체 X), 게이트 추가 안전 |
| psutil/torch 없는 환경에서 pure-numpy fallback | 낮 | numpy만으로도 통계 추출 가능 (대부분) |

## 변경 파일 (예상, attribution/worker_spec 패턴 그대로)

| 파일 | 변경 |
|---|---|
| `src/pcq/contract.py` | build_fingerprint_object + finalize_run param |
| `src/pcq/core.py` | save_all 통합 + `pcq.fingerprint()` public API |
| `src/pcq/fingerprint.py` (신규) | modality별 추출 함수 (tabular/image/text/time-series/audio/graph) |
| `src/pcq/agent/json_contracts.py` | registry + flat surface |
| `src/pcq/agent/describe.py` | nested + 4 flat 노출 |
| `src/pcq/agent/validate.py` | R14 L3+ PII pattern + R5 domain gate |
| `spec/schemas/*.json` | 4개 schema additive (describe_run + compare_runs + envelope + validation_report) |
| `spec/SPEC.md` | ## Fingerprint 섹션 |
| `spec/JSON_CONTRACTS.md` | fingerprint contract |
| `spec/VERSIONING.md` | env precedence + domain gate + PII layered |
| `tests/test_fingerprint.py` | R1-R14 unit tests |
| `tests/conformance/pcq.describe_run.record/{with-fingerprint-tabular,without-fingerprint}/` | 2 golden pairs |
| `templates/AGENTS.pcq.md` | R13 — agent 자동 삽입 가이드 |
| `skills/pcq/SKILL.md` | fingerprint jq 예제 + modality detection hints |
| `CHANGELOG.md` | [4.6.0] 항목 |

## 다음 사이클 후보 (3-축 완성 후)

1. **TheCommons ingestion API** — 3-축이 모인 evidence를 TC가 받는 표면
2. **TC 매치메이커 엔진 1.0** — 3-축 + 코퍼스로 추천 생성
3. **Inference 메트릭 표준** — latency/throughput/memory_peak
4. **k-anonymity / DP noise** (fingerprint Phase 2)
5. **R10 PII validation runner** — attribution 사이클 잔재 (T-6 skip 활성화)

## 관련

- [[pcq-agent-attribution]] — 1-축
- [[pcq-worker-spec]] — 2-축
- [[the-commons-vision]] — 매치메이커 비전
- [[pcq-spec-foundation]] — additive-only

---

*Generated by /pi on 2026-05-13 — 매치메이커 3-축 마지막. agent-fillable 정체성 완성.*
