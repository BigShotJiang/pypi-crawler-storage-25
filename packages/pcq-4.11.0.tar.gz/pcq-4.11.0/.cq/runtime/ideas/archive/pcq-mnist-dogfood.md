# pcq MNIST Dogfood — First External Evidence

> evidence-first 라이브러리가 자기 evidence 0건인 메타 모순을 깬다. ML→DL evolution을 Claude Code agent가 per-gen fresh session으로 운영하며 pcq의 모든 핵심 표면(install/inspect/validate/apply-plan/validate-run/lineage/compare/PlanSet)을 한 번씩 가동시킨다.

## 왜 이 아이디어인가

pcq은 v2.0 → v2.11까지 12 minor release를 1 세션에 빌드. 외부 사용자 0명, dogfood 0건. ROADMAP 5/7 완료라는 진행도는 builder가 builder를 채점한 결과 — 외부 척도가 0개. agent ML automation 시장은 1-2년 안에 W&B/Modal/HuggingFace 중 하나가 점령할 가능성 높은데 pcq은 PyPI 미발행 + 사례 0개. evidence-first 정체성 자체가 외부 evidence 없이 만들어졌다는 메타 모순을 풀어야 다음 우선순위가 추론이 아닌 실측에 기반한다.

## 풀고자 하는 문제

- **누가**: pcq builder + 미래의 fresh agent (Claude Code)
- **어떤 고통**:
  1. pcq의 어느 표면이 실제 갭인지 추론으로만 알고 있음
  2. agent가 RunRecord/lineage만 보고 다음 plan 결정 가능한지 미검증
  3. `pcq agent install` / `init-experiment` / `AGENT_OPERATING_GUIDE`가 진짜 fresh user를 도와주는지 미검증
  4. Lightning+W&B 대비 시간/가치 비교 0건
- **언제**: dogfood 끝나면 pcq의 다음 우선순위(Phase 6 MCP vs PyPI 발행 vs 또 다른 갭)가 실측에 기반

## 기존 대안과 차이

| 대안 | 한계 | 우리가 다른 점 |
|------|------|--------------|
| Lightning + W&B | 사람 친화 — agent가 ad-hoc parsing | RunRecord JSON SSOT |
| MLflow | sha256/lockfile evidence 약함 | 5 evidence chain + sha256 verify |
| DVC | data versioning 강점, agent loop 약함 | lineage + compare-runs + PlanSet |

이 dogfood가 "pcq은 ML→DL framework 전환을 same contract으로 흡수"라는 약속을 sklearn → torch 넘나들며 검증.

## 요구사항 (EARS)

### 운영 요구사항

- **시스템은 항상** GitLab private repo `mnist-dogfood`에서 dogfood를 운영한다.
- **시스템은 항상** ML→DL evolution 패턴(8 generation)을 따른다.
- **WHEN** gen 0 시작 시 **THEN** builder가 pcq setup을 직접 수행한다 (`pcq agent install --target claude`, `pcq init-experiment --agent claude --with-pyproject`).
- **WHEN** gen 1-2 진행 시 **THEN** Claude Code agent가 plan을 제안하고 builder가 sanity check 1회 수행한다 (hybrid warmup).
- **WHEN** gen 3-8 진행 시 **THEN** 매 generation 새 Claude Code session(per-gen fresh)이 lineage chain + RunRecord + AGENT_OPERATING_GUIDE만 입력으로 받아 결정한다. builder는 emergency stop만 수행한다.
- **시스템은 항상** 매 generation 끝나면 dogfood-log.md에 측정 entry를 추가한다.

### 측정 요구사항

매 generation 일지에 다음을 기록한다:

- session 메타 (id, 시작/종료 시각, wall time)
- agent decision plan (set_atom / set_config / fork)
- pcq 명령 호출 횟수 (resolve / inspect / validate / apply-plan / validate-run / describe-run / compare-runs / lineage)
- 막힌 지점 (pcq issue 후보)
- 부차 metric (eval_acc + train_time + param_count + ECE)
- "이 결정이 RunRecord 어떤 필드 보고 내려졌나"
- "Lightning+W&B였으면 N분?" 추정
- pcq 도구가 진짜 가치 준 순간 (있었나? 몇 번?)

### 답해야 할 5가지 질문 (dogfood 종료 시)

1. cq.yaml 작성 시작부터 첫 학습 완료까지 시간 — Lightning+W&B 대비
2. agent가 막힌 지점 N개 — 어떤 명령/문서/필드가 부족했나
3. 5 evidence(source/env/config/inputs/lineage) 중 실제 결정에 쓴 것은?
4. agent가 다음 plan 만드는 데 평균 N분 / N개 명령
5. "pcq 없었으면?" 자기 답 — Lightning+W&B+git tag 조합으로 충분한가

### 진화 패턴 (확정)

```
gen 0  sklearn LogReg                    baseline (builder setup)
gen 1  sklearn 안에서 model 축 (hybrid)  (LogReg → SVM)
gen 2  sklearn 안에서 model 축 (hybrid)  (SVM → XGBoost)
gen 3  ML → DL 전환 (pure fresh)         (XGBoost → MLP) ← framework freedom 시험
gen 4  DL model 축 (pure fresh)          (MLP → SmallCNN)
gen 5  DL model 축 (pure fresh)          (SmallCNN → ResNet18)
gen 6  optim/sched 축 (pure fresh)       (best 모델 + cosine + warmup)
gen 7  augmentation/PlanSet (pure fresh) (RandomCrop / Mixup grid via PlanSet)
gen 8  agent 자율 결정 (pure fresh)      (다음 axis는 agent 결정)
```

### 위험 + Mitigation

| 위험 | mitigation |
|------|-----------|
| MNIST saturation (모두 99%대) | 부차 metric (train_time, param_count, ECE, robustness) 추적 |
| toy 자기증명 약함 | 매 gen 일지에 "Lightning+W&B였으면" 별도 추정 기록 |
| builder ↔ agent 흐림 | gen 3 이후 builder는 emergency stop만, plan 결정 금지 |
| pcq P0 버그 발견 | gen 1-2 hybrid에서 발견되면 그 자리에서 pcq v2.x 패치 |
| dogfood 동력 빠짐 | 5-7일 hard limit. 8 gen 못 마쳐도 일지 자체가 산출물 |

### 범위 외 (Out of Scope)

- HMR 등 실제 research dogfood — 이번엔 toy로 cycle 빠르게
- 외부 사용자 모집 — 후속 단계
- CQ service Phase 6 — 별도 트랙
- PyPI 발행 — dogfood 완료 후 결정

## 산출물

1. `mnist-dogfood` repo (GitLab private) — RunRecord lineage chain 8 depth
2. `dogfood-log.md` (gen별 일지) — pcq의 첫 외부 evidence 1호
3. pcq issue 후보 list (막힌 지점) — v2.12 또는 v3.0 입력
4. 다음 우선순위 결정 입력 (Phase 6 / PyPI / 다른 갭)

## 탐구 중 발견한 인사이트

1. **evidence-first 라이브러리의 메타 모순** — pcq은 "evidence를 강제하는 도구"이면서 자기 가치 evidence는 0건. 이걸 dogfood로 깨야 다음 정당성 확보.
2. **agent 자율도가 dogfood 깊이를 결정** — pure fresh per-gen이 가장 강한 시험. 단 첫 1-2 gen은 hybrid로 pcq 표면 매끄러움 보장.
3. **ML→DL evolution은 pcq의 framework-agnostic 약속을 직접 시험** — sklearn → torch 전환이 한 contract으로 흡수되는지가 핵심.
4. **MNIST saturation은 부차 metric으로 보정 가능** — train_time, param_count, ECE가 다음 plan 결정에 정보 줌.
5. **dogfood 일지 자체가 외부 evidence** — repo commit 단위로 누적되면 외부 공유 가능한 첫 자료.

## 확정된 설계 결정 요약

| 항목 | 결정 |
|---|---|
| Scope | gen 8까지, 5-7일 hard limit |
| 위치 | GitLab private repo `mnist-dogfood` (pcq 외부) |
| Agent 자율도 | gen 0 builder setup → gen 1-2 hybrid → gen 3-8 per-gen fresh |
| 진화 패턴 | sklearn(LogReg/SVM/XGBoost) → DL(MLP/SmallCNN/ResNet) → optim/sched/aug/PlanSet |
| 측정 | 일지 매 gen, 5 종료 질문 |
| Out-of-scope | HMR / 외부 사용자 / CQ MCP / PyPI |

## 참고 자료

- 부모 idea: `/Users/changmin/git/cq_ml/.cq/runtime/ideas/cq-python-library-v1.md`
- pcq ROADMAP: `/Users/changmin/git/cq_ml/docs/PCQ_COMPLETION_ROADMAP.md`
- pcq AGENT_OPERATING_GUIDE: `/Users/changmin/git/cq_ml/docs/AGENT_OPERATING_GUIDE.md`
- pcq release line: v2.0.0 → v2.11.0 (12 release, 1 세션)

---

## Dogfood 종료 결과 — 2026-05-08

### 9-Gen Evolution

| gen | axis | model/aug | eval_acc | wall_time |
|-----|------|----------|---------|----------|
| 0 | baseline | sklearn LogReg | 0.9583 | 0.04s |
| 1 | sklearn nonlinear | SVC rbf | 0.9944 | 0.01s |
| 2 | sklearn ensemble | GBT | 0.9667 (regressed) | 5.7s |
| 3 | ML→DL | torch MLP | 0.9889 | 3.5s |
| 4 | DL spatial | CNN-2block | 0.9944 (co-best, param 73% 적음) | 11s |
| 5 | DL depth | DeeperCNN | 0.9889 (regressed) | 22s |
| 6 | optim/sched | CNN+OneCycle+AdamW | 0.9944 (tied) | 13s |
| 7-b | augmentation | CNN+RandomAffine (PlanSet 4-variant) | 0.9972 (ceiling 깸) | 16s |
| 8 | TTA | CNN+Affine+TTA-7 | **1.0000** (360/360) | 11s |

### 검증된 pcq 가치 (실측)

- ✅ **lineage auto-tracking depth 9** — 모든 gen agent가 즉시 사용
- ✅ **validate-run strictness 3 (5 evidence)** — sha256 corruption verify
- ✅ **compare-runs direction** — improved/regressed/tied 매 gen 즉시 정성 판정
- ✅ **plan validate 사전 차단** — gen 1 G1-2 학습 전 fail 검출
- ✅ **failed variants도 evidence 보존** — gen 2/5/7-d로 다음 agent 학습
- ✅ **framework freedom (sklearn → torch)** — gen 3 같은 contract 무변경
- ✅ **PlanSet 한 번에 4-variant expand** — gen 7 sweep 표현

### 누적 갭 21건 — 추론 아닌 실측

| 우선순위 | ID | 핵심 |
|----------|-----|------|
| **P0** | G7-5 | `cq.config()` cq.yaml fallback 안 함. PlanSet expand 시 N×배 |
| **P1** | G0-2 | `pcq run` 명령 부재 |
| **P1** | G1-2 | output_dir 재사용 시 manifest stale lock-in |
| **P1** | G1-4 | compare-runs config_changes=0 |
| **P1** | G7-1 | apply-planset relative output_dir → double nesting |
| **P2** | G0-3 | describe-run JSON 누락 |
| **P2** | G0-4 | output 안 임시 파일 manifest 흡수 |
| **P2** | G1-1 | plan에 train.py 변경 op 부재 |
| **P2** | G1-3=G7-3 | apply-plan/planset artifacts glob 동기화 안 함 |
| **P2** | G3-1=G5-2 | apply-plan inputs 섹션 손상 |
| **P2** | G4-1 | compare-runs metric_delta -0.0 |
| **P2** | G7-2 | validate --planset exit code conflation |
| **P2** | G7-4 | apply-planset train.py 자동 복사 안 함 |
| P3 | G3-2/G5-1/G6-1 | structural ceiling 가설 |
| P3 | G8-1/G8-2 | TTA 측정 미세 갭 |

### 5 종료 질문 답 (agent 솔직)

| Q | 답 |
|---|---|
| Q1 setup vs Lightning+W&B | pcq 첫 run 15분 vs W&B "instantly without G0-1 friction". G0-1/G7-5 누적 24-40분 추가 |
| Q2 막힌 지점 | **21건** 발견 (추론 0%, 실측 100%) |
| Q3 5 evidence 실제 사용 | git_sha ✅ / lockfile ✅ / cq_yaml_sha256 ✅ / inputs ❌ (sklearn builtin) / **lineage ✅ — 가장 가치** |
| Q4 plan 결정 평균 | 7-8분/gen (plan 5분 + apply 10s + G0-1 우회 2분 + train + validate 30s×3) |
| Q5 pcq vs alternative | "**G0-1이 8 gen 모두 #1 pain point. pcq run이 v2.11에 있었으면 manual overhead 30% 감소**. PlanSet은 'metadata contract without execution contract'" |

### 메타 모순 해결

> "evidence-first 라이브러리가 자기 evidence 0건"이라는 v2.10까지의 메타 모순이 깨짐. 21 gap 발견은 12 release × 0 사용자 추론으로는 못 본 것. 다음 우선순위가 추론이 아닌 실측에 기반.

### 산출물

- `mnist-dogfood` repo (9 commits, depth-9 lineage)
- `mnist-dogfood/dogfood-log.md` (gen별 일지 500+ 줄)
- 21 pcq gap (P0~P3 우선순위)
- 첫 정량 비교 (Lightning+W&B 대비 manual overhead 30%)

### 다음 우선순위 (실측 기반)

1. **v2.12 hotfix**: P0 + P1 4건 묶어 release
   - `pcq run` 명령 (G0-2 + G7-5 동시 해결)
   - apply-planset absolute output_dir (G7-1)
   - compare-runs config_changes detect (G1-4)
   - manifest rescan / 새 output_dir 정책 (G1-2)
2. **v2.13**: P2 8건 (apply-plan inputs 보존, artifacts glob 동기화 등)
3. **외부 공유**: mnist-dogfood repo GitLab push + pcq docs/case-studies 참조

---
*Generated by /pi on 2026-05-08, dogfood termination 2026-05-08*
