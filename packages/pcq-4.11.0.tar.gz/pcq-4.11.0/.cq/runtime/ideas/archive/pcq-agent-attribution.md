# pcq agent attribution — Wiki+봇 정체성을 양식에 박기

> pcq 1.x에 `agent` 필드 추가 (additive). TheCommons "Wikipedia + 봇" 권한 모델의
> 행동 기반 구현. 모든 run_record가 *누가 만들었나*를 1급으로 표현하게 함.

## 한 줄 비전

> **모든 pcq run_record가 *누구의 의도*와 *누구의 실행*인지 1급으로 기록한다.**

## 왜 이 아이디어인가 (TheCommons 비전과의 연결)

TheCommons 비전 사이클에서 *Wikipedia + 봇* 권한 모델을 확정했다 (사람·에이전트
같은 surface, 다른 책임). 그러나 pcq 양식에는 *행위자(agent) 표현이 없다*:

- `run_record.json` 에 platform/python/git_sha 등 *환경*은 있지만 *주체* 없음
- contract.py 주석에 "agent provenance"라는 단어는 있으나 실제 필드 없음
- 이대로면 TheCommons 도서관에 evidence가 쌓여도 *누가 기여했는지* 모름

이게 풀리지 않으면:
- *평판 시스템*(persona) 작동 불가 — 어느 evidence가 어느 persona의 것인지 모름
- *Multi-author* 표현 불가 — 사람과 에이전트가 협업한 잡을 표현 못 함
- *legal 책임 추적* 불가 — operator가 누구인지 spec에 없음
- *audit trail* 불가 — Wikipedia 모델의 행동 기반 핵심

따라서 attribution은 *모든 후속 작업의 전제*. fingerprint·worker spec·inference
메트릭은 attribution 위에서 의미가 생긴다.

## TheCommons 비전이 요구하는 pcq 변경 7가지 — 우선순위

| # | 항목 | 우선순위 | 본 사이클 |
|---|---|---|---|
| 1 | **Agent / persona attribution** | **1순위** | ✅ 이번 |
| 2 | Data fingerprint (통계 모먼트, raw X) | 2순위 | 다음 |
| 3 | Inference 메트릭 표준 키 | 3순위 | 다음 |
| 4 | Worker spec 확장 | 3순위 | 다음 |
| 5 | Failure 카테고리 | 4순위 | 나중 |
| 6 | Recipe / Recommendation 양식 | 4순위 | 나중 |
| 7 | Cycle membership 명시 | 4순위 | derived 가능 |

## 핵심 설계

> **CRITIQUE 반영 (2026-05-13)**: 직전 안은 새 객체를 `agent` 키로 두었으나,
> 기존 `run_record.agent.{plan_id, intent, recipe, overrides}` 시맨틱과 충돌.
> 새 객체 키 = **`attribution`** 으로 분리. signature 필드는 schema에 박지 않음
> (Phase 2 도입 시 minor 증분과 함께). describe-run은 nested + flat 양면 노출.

### Multi-author 모델 — Git author/committer 패턴

한 잡에 여러 행위자가 자연스럽게 생긴다. Git의 author(의도)/committer(실행)
분리와 일치하는 패턴 채택:

```json
"attribution": {
  "schema_version": 1,
  "author":    { "kind": "human"|"agent", "id": "...", "persona_id": "..."|null },
  "committer": { "kind": "human"|"agent", "id": "...", "persona_id": "..."|null },
  "operator":  "...",         // legal·평판 주체, 항상 사람/조직 (pseudonym 권장)
  "session_id": "..."|null
  // signature 는 schema에 박지 않음 — Phase 2 reserved name (SPEC.md에 명시만)
}
```

### env 우선순위

CLI > `CQ_ATTRIBUTION_*` env > cfg(`cq.yaml.attribution.*`) > auto-infer > NULL

- **author**: "이거 하자"고 한 주체 (의도)
- **committer**: 실제로 잡을 만들고 제출한 주체 (실행)
- **operator**: 평판·법적 책임이 누적되는 legal 주체 — 항상 사람/조직으로 환원
- **session_id**: 추적 보조 (옵션)
- **signature**: Phase 2 cryptographic 보증용 예약 필드

단일 행위자면 셋이 같음.

### 위조 방지 — Phase별 모델

- **Phase 1 (지금)**: 단순 자가 신고 + audit log. Wikipedia 모델 — 위조는
  평판으로 자정. operator를 끝까지 추적 가능하면 충분.
- **Phase 2 (나중)**: `agent.signature` 필드 활성화. operator key로 서명.
  cryptographic 보증.

Phase 1에서는 *위조 가능성을 spec 차원에서 풀지 않는다*. Phase 2 자리를 비워둠.

### Additive 변경 — pcq 1.x 안에서 가능

- run_record schema에 `agent` 객체 추가 (옵션 필드, NULL 허용)
- 옛 record는 `agent: null` — 외부 호환 깨짐 0
- schema_version 미세 증분 (현재 spec foundation의 additive-only 정책 준수)

## 요구사항 (EARS)

### 기능 요구사항

- **R1** WHEN pcq writes a `run_record.json`, the record SHALL contain an
  optional `agent` object conforming to the schema above.
- **R2** WHERE the agent object is present, `author`, `committer`, and
  `operator` SHALL all be populated. `session_id` and `persona_id` MAY be NULL.
- **R3** WHEN a single human user runs pcq directly via CLI without any agent
  in the loop, `author.kind = committer.kind = "human"` and all three roles
  refer to the same operator.
- **R4** WHEN an agent (e.g., Claude Code) authors and commits the job on
  behalf of a human, `author.kind = "agent"` (or "human" depending on origin
  of intent), `committer.kind = "agent"`, and `operator` is the human/org.
- **R5** WHERE `pcq describe-run --json` outputs the record, the `agent`
  object SHALL be exposed verbatim (no redaction at the format layer).
- **R6** WHEN existing run_records without an `agent` field are read, pcq
  SHALL treat them as valid (backward compatible) and surface `agent: null`.
- **R7** WHEN pcq_agent.json_contracts registers the new field, a new
  golden conformance pair SHALL be added (sklearn-baseline with agent +
  one without).
- **R8** WHERE `pcq agent install` writes agent runtime assets to a project,
  the installed assets SHALL include guidance for setting `agent.author`
  and `agent.committer` (so Claude Code / Codex populate it).

### 비기능 요구사항

- **Additive only** — schema_version 미세 증분. 외부 호환 깨짐 0. 옛 record
  계속 valid.
- **No breaking change to 14 MCP tools** — describe_run·compare_runs·lineage
  등이 옵션 필드로 그대로 흡수.
- **No PII enforcement at format layer** — operator 값 자체가 PII일 수 있음.
  format은 *형식*만 정의, 사용 정책은 cq/TC가 결정.
- **Phase 2 호환** — `signature` 필드 자리만 미리 확보, 알고리즘 정의는 미룸.

### 범위 외

- Data fingerprint (다음 사이클)
- Worker spec 확장 (다음 사이클)
- Inference 메트릭 표준 키 (다음 사이클)
- TC 측 attribution 인덱싱 (TheCommons 빌드 단계)
- Phase 2 signature 알고리즘 (별도 결정)
- agent.id의 *공식 네임스페이스*(예: model registry) — Phase 1엔 자유 문자열

## 변경되는 파일 (예상)

| 파일 | 변경 |
|---|---|
| `src/pcq/contract.py` | `agent` 객체 빌드·삽입 로직 |
| `src/pcq/core.py` | run_record 작성 시 agent 포함 |
| `src/pcq/agent/json_contracts.py` | `pcq.describe_run.record` contract에 agent 필드 |
| `spec/schemas/pcq.describe_run.record.schema.json` | additive 필드 |
| `spec/SPEC.md` | agent attribution 섹션 신설 |
| `spec/JSON_CONTRACTS.md` | agent 객체 문서화 |
| `spec/VERSIONING.md` | schema_version 미세 증분 정책 적용 |
| `tests/conformance/pcq.describe_run.record/` | agent 포함/미포함 golden pair 추가 |
| `templates/AGENTS.pcq.md` | author/committer 설정 가이드 |
| `skills/pcq/SKILL.md` | agent attribution 사용 패턴 |
| `CHANGELOG.md` | 변경 기록 |

## 리스크

| 리스크 | 심각도 | 대응 |
|---|---|---|
| schema_version 증분이 외부 conformance 깨뜨림 | 중 | additive-only 검증 + conformance test로 보장. 옛 record `agent: null` 허용. |
| operator 값에 PII 포함되어 외부 공개 시 문제 | 중 | format 차원에서 강제하지 않음. cq/TC가 노출 정책 결정. README에 권고만. |
| Phase 1 위조 가능성 | 낮 | Wikipedia 모델로 자정 가능. Phase 2 signature 자리 예약. |
| agent.id 네임스페이스 혼란 | 낮 | Phase 1엔 자유 문자열. 예: "claude-opus-4-7", "human:changmin", "agent:custom-bot". 공식화는 나중. |
| 14 MCP tool들이 옵션 필드 처리 못 함 | 낮 | additive라 기본 무시. describe_run만 명시적 노출. 회귀 테스트로 보장. |

## 다음 사이클 후보

1. **Data fingerprint** — 통계 모먼트·schema 메타. 옆 세션도 식별한 결정.
2. **Worker spec 확장** — CPU 모델·RAM 등. manifest 확장.
3. **Inference 메트릭 표준 키** — latency/throughput/memory_peak. 문서화만.
4. **Failure 카테고리** — OOM/diverged/time-budget 분류.

## 관련

- [[the-commons-vision]] — 시스템 비전 (Wiki+봇 권한 모델 출처)
- [[pcq-positioning]] — pcq 정체성 (직전 사이클)
- [[pcq-spec-foundation]] — additive-only 정책 출처

---

*Generated by /pi on 2026-05-13 — agent attribution as the foundation of Wiki+bots model*
