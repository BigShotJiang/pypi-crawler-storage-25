# pcq 2.x canonical — TC Proposal 흡수, 정본은 pcq spec/

> TC가 docs/pcq-2.x.md에 vendored한 "Input Format Proposal"을 pcq spec/이 *정본*으로
> 단일화한다. 핵심 규칙: **"실험 기술이면 pcq, evidence 관리면 TC."**

## 한 줄 비전

> **pcq 2.x = 1.x + `intent` + top-level `integrity` + fingerprint band 옵션. 가짜
> 실험(synthetic)은 TC, pcq는 real 실험만. 정체성 안 흔들림.**

## 문제 (한 문장)

TC가 pcq 1.x로 부족한 필드를 자기 멋대로 "pcq 2.x" 초안으로 만들었는데, 우리 pcq
4.x와 4군데 충돌: ① attribution 키 충돌 ② 정확값 vs band 철학 충돌 ③ synthetic
정체성 충돌 ④ 버전 축 혼란.

## 해결 — 가르는 질문 하나

> **"이 필드는 *실험을 기술*하는가, *evidence를 관리*하는가?"**

| 필드 | 실험 기술? | 소속 |
|---|---|---|
| intent (goal/expected_baseline/tolerance) | ✅ | **pcq 2.x** (신규) |
| data_fingerprint (modality·band·moments) | ✅ | **pcq 2.x** (= 우리 fingerprint v4.6 + band) |
| config / metrics | ✅ | pcq (이미 있음) |
| worker_spec | ✅ | pcq (우리 v4.5, superset 유지) |
| attribution (who: author/committer/operator) | ✅ | pcq (우리 v4.4 그대로) |
| integrity (content_hash, 무결성) | ✅ 기록 무결성 | **pcq 2.x** (top-level, attribution 밖) |
| tier (real/synthetic) | ❌ | **TC** (pcq엔 없음) |
| synthetic_source | ❌ | **TC** |
| evidence_id / outreach_origin | ❌ | **TC** |

## synthetic 정체성 — 핵심 단순화

> **pcq는 *real 실험*만 기록한다. 실험은 정의상 real. synthetic(LLM 증류 가짜
> evidence)은 실험이 아니므로 pcq 양식이 아니다 — TC가 자기 corpus에서 별도 관리.**

결과:
- pcq run_record에 **tier 없음**. 모든 pcq evidence = real.
- `integrity` 해시가 pcq 2.x 전체 커버 → real evidence 무결성 100%.
- synthetic은 TC가 별개 산출물로 자기 형식·자기 해시 관리. pcq 무관.
- 위험(synthetic→real 위조)이 *애초에 발생 안 함*.
- pcq positioning ("framework-neutral ML experiment contract") **그대로 유지**.

## 확정 결정

1. **경계**: pcq 2.x = 실험 양식 (intent + data_fingerprint + config + metrics +
   worker_spec + attribution(who) + integrity). tier/synthetic_source/evidence_id/
   outreach_origin = TC Evidence wrapper (pcq 무관).
2. **attribution 충돌 해소**: content_hash → top-level `integrity` 필드로 *재배치*.
   우리 attribution(author/committer/operator/session_id/signature) **무변경**.
   TC가 원한 created_at/contributor_id/pcq_version은:
   - created_at → 기존 run_record timestamp 재사용 (last_updated_at 등)
   - contributor_id → 우리 attribution.operator와 동일 개념 (TC가 매핑)
   - pcq_version → 신규 `contract_version` 필드 (아래 #4)
3. **fingerprint band**: 우리 fingerprint(v4.6) sub-object에 band 표현 *additive*.
   - 정확값(n_samples 등) 유지 + band(sample_count_band "1k-10k") 옵션 추가
   - **일반(general) 도메인**: 정확값 + band 모두 emit (둘 다 제공).
   - **PHI 도메인(medical/financial/regulated)**: R5 게이트가 `core.fingerprint()`를
     완전 차단 → hints-only (modality/task_kind만) + FINGERPRINT_DOMAIN_GATE_SKIP 워닝.
     auto-derived band **없음**. band는 `cq.yaml` fingerprint 선언 경로로만 제공 가능
     (이번 사이클 scope 밖). "band 강제" = 선언 경로에만 적용, auto-extraction 경로에서는
     아무것도 emit 안 함.
4. **버전 축 분리**: run_record에 `contract_version: "2.0"` 신규 필드.
   - 패키지 버전 (PyPI, 4.x) — 독립
   - JSON_CONTRACT_VERSION (MCP tool 계약, 1) — 독립
   - contract_version (Evidence 양식, "2.0") — 신규 축
   - 세 축이 각자 진화. 문서에 3축 매핑 표 명시.
5. **intent 신규**: top-level `intent` { goal(enum), expected_baseline, tolerance }.
   **전부 null 허용** (contributor 부담 최소). null intent는 corpus weight 감쇠는
   TC 책임 (pcq는 형식만).
6. **TC 회신**: tier/synthetic/evidence_id/outreach_origin 100% TC.
   pcq 2.x는 실험 양식만. content_hash → integrity 재배치. TC는 정본 vendoring.

## 기존 사이클과 정합성

| 사이클 | 이번과 관계 |
|---|---|
| pcq-positioning | "ML experiment contract" 정체성 — synthetic 배제로 *유지* |
| the-commons-vision | 3-layer (pcq=양식, TC=소비자) — 경계 규칙이 이를 곧게 적용 |
| pcq-spec-foundation | additive-only + SSOT 단일 — 2.x도 additive, spec/이 SSOT |
| pcq-agent-attribution | attribution(who) 무변경, content_hash만 분리 |
| pcq-worker-spec | worker_spec superset 유지 (TC flat은 부분집합) |
| pcq-data-fingerprint | fingerprint에 band additive — 큰 재설계 0 |

## 요구사항 (EARS)

- **R1** WHEN pcq 2.x run_record가 작성될 때, top-level `intent` 객체(옵션, null
  허용)를 포함한다. { goal: enum, expected_baseline: {metric, value}|null,
  tolerance: {direction, margin}|null }.
- **R2** WHEN pcq 2.x run_record가 작성될 때, top-level `integrity` 객체를
  포함한다. { content_hash: "sha256:...", hashed_fields: [...] }. attribution
  밑이 아니라 top-level. attribution(v4.4)은 무변경.
- **R3** WHERE fingerprint sub-object가 존재할 때, 정확값 필드와 함께 band 표현
  (sample_count_band, *_band moments)을 옵션으로 둔다. additive.
- **R4** WHERE domain ∈ {medical, financial, regulated} (기존 R5 게이트),
  `core.fingerprint()` auto-extraction은 hints-only + FINGERPRINT_DOMAIN_GATE_SKIP 워닝으로
  완전 차단된다. auto-derived band **없음**. 정확값도 없음. band는 선언(declared) 경로
  (`cq.yaml` fingerprint 블록)로만 제공 가능하며, 그 경우에도 정확값 노출은 운영자 책임.
- **R5** WHEN pcq 2.x run_record가 작성될 때, top-level `contract_version: "2.0"`
  문자열을 포함한다. 패키지 버전·JSON_CONTRACT_VERSION과 독립 축.
- **R6** WHEN 옛 1.x run_record (contract_version 부재, integrity 부재, intent
  부재)를 읽을 때, valid로 처리한다 (backward compatible). 부재 = 1.x.
- **R7** WHERE describe-run --json이 출력될 때, intent/integrity/contract_version
  + fingerprint band가 노출된다 (nested + 필요한 flat surface).
- **R8** WHEN pcq.agent.json_contracts가 새 필드를 등록할 때, conformance pair
  2개 추가 (2.x-full, 1.x-legacy).
- **R9** WHERE spec/이 2.x를 정의할 때, TC docs/pcq-2.x.md Proposal의 tier/
  synthetic_source/evidence_id/outreach_origin은 *명시적으로 pcq scope 밖*임을
  spec에 기록한다 (TC Evidence wrapper 책임).
- **R10** IF 어떤 spec/docs가 synthetic/tier를 pcq 2.x 필수 필드로 기술하면,
  리뷰에서 차단한다. pcq scope = real 실험 양식만.
- **R11** WHEN TC 회신 문서가 필요할 때, pcq spec/이 정본임 + content_hash→
  integrity 재배치 + tier/synthetic은 TC wrapper임을 명시한 짧은 노트를
  docs/ 또는 메모리에 남긴다 (TC vendoring 사이클 입력).

### 비기능
- additive_only: 옛 1.x record 전부 valid (contract_version/intent/integrity 부재 = 1.x)
- ssot_single: 정본은 pcq spec/. TC docs/pcq-2.x.md는 vendored 사본.
- positioning_preserved: "ML experiment contract" 유지 (synthetic 배제)
- mcp_compat: 14 MCP tool 회귀 0
- tone_neutral: 매치메이커/TheCommons를 pcq feature로 광고 X

### 범위 외
- tier / synthetic_source / evidence_id / outreach_origin 구현 (TC wrapper)
- TC ingestion module 변경 (TC 세션 책임)
- cq M4 2.x emission (별 작업, 정본 단일화 *이후*)
- 1.x→2.x 자동 마이그레이션 도구 (Phase 2)
- TC vendoring 자동화 (TC 세션이 정본 fetch)

## 리스크

| 리스크 | 심각도 | 대응 |
|---|---|---|
| TC가 tier를 여전히 pcq에 원함 | 중 | R9/R11로 명시 경계 + 회신. synthetic은 TC 산출물이라 논리적으로 분리 |
| band 강제가 일반 ML 정보 손실 | 중 | 정확값 유지 + band 옵션 (둘 다). PHI 도메인만 band 강제 (R4) |
| 3 버전 축 사용자 혼란 | 중 | spec에 3축 매핑 표 명시 (R5) |
| 2층(pcq+TC wrapper) 재분기 | 중 | 정본=pcq spec/ 단일 못박음. TC는 vendoring만 (R9) |
| content_hash 계산 범위 모호 | 낮 | integrity.hashed_fields로 *무엇을 해시했나* 명시 |

## 다음 사이클 후보

1. cq M4 — 2.x emission (정본 단일화 후, cq 세션)
2. TC vendoring 사이클 (TC 세션이 pcq 정본 fetch)
3. 1.x→2.x 마이그레이션 도구 (Phase 2)
4. fingerprint Phase 2 (k-anonymity, 직전 보류)

## 관련

- [[the-commons-vision]] — 3-layer 원칙 (경계 규칙의 출처)
- [[pcq-positioning]] — ML experiment contract 정체성
- [[pcq-spec-foundation]] — additive-only + SSOT
- [[pcq-agent-attribution]] — attribution(who), content_hash 분리 대상
- [[pcq-data-fingerprint]] — fingerprint, band additive 대상

---

*Generated by /pi on 2026-05-19 — TC Proposal 흡수, 정본 단일화. 규칙: 실험이면 pcq, 관리면 TC.*
