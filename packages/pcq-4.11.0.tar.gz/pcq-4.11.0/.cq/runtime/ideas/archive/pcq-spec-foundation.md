# pcq-spec foundation — 1·2·3 묶음 토대

> spec 분리 + schema versioning + conformance test의 **첫 PR**: spec/ 디렉토리 신설, 명세 문서 통합, versioning/conformance 정책 명문화, JSON Schema 자동 export, golden conformance pair 2개. 코드 로직 변경 0.

## 왜 이 아이디어인가

pcq는 v4에서 "framework-neutral evidence and control layer"라는 정체성을 잡았고, 14개 MCP tool이 frozen JSON contract(`src/pcq/agent/json_contracts.py`)를 따르고 있다. 그러나 SoT가 둘로 갈라져 있다 — Python registry(`JSON_CONTRACTS`)는 검증/실행 계층, 마크다운 명세 5개(`docs/{SPEC,JSON_CONTRACTS,CQ_YAML_RUNTIME_CONTRACT,STRICTNESS,CQ_MCP_SPEC}.md`)는 인간이 읽는 계층. 둘이 어긋나도 잡을 메커니즘이 없고, JSON Schema(.json) 형태가 없어 타 언어 client가 못 쓴다.

지금 시점에 (1) spec을 한 곳에 모으고 (2) schema versioning 정책을 명문화하고 (3) conformance test 슈트의 *틀*을 깔아두면, 이후 외부 구현(Go/JS client, third-party orchestrator)이나 CQ Go service의 정합성 검증이 가능해진다. **첫 PR은 토대만**: 코드 로직 변경 0, 모두 "이동·인덱싱·정책 문서·자동화" 카테고리.

## 풀고자 하는 문제

- **누가**: pcq 자체 + CQ Go service + 미래 third-party client(Python/Go/JS) 구현자.
- **고통**:
  - SoT 분기 — Python registry와 마크다운 명세가 어긋나도 못 잡음.
  - JSON Schema 부재 — 타 언어 도구(jsonschema-validator 등)가 못 씀.
  - schema_version 변경 정책 미문서화 — `1 → 2`가 무엇을 깨고/유지하는지 불명.
  - "이 구현이 conformant한가?" 묻는 슈트 부재 — 골든 입출력 페어 0.

## 기존 대안과 차이

| 대안 | 한계 | 우리 접근 |
|------|------|--------|
| 마크다운 산문 명세만 | 기계 검증 불가, 타 언어 사용 불가 | 산문 + JSON Schema(자동 export) 병행 |
| Python registry만 | 타 언어 import 불가, 산문 설명 부재 | Registry를 SoT로 두고 산문/JSON Schema가 그것에서 파생 |
| 별도 리포(`pcq-spec`) 분리 | 릴리즈 파이프라인 추가, 동기화 복잡 | 모노레포 안 `spec/` 디렉토리 — 단일 PR로 시작, 향후 별도 리포 옵션 보존 |
| OpenAPI/AsyncAPI 도입 | 우리는 HTTP/WebSocket API가 없음 — over-engineered | JSON Schema(있는 도구) + 마크다운(인간) 두 형식만 |

## 요구사항 (EARS)

### 기능 요구사항

- **R1** WHERE pcq spec assets are referenced (docs, code, README, site), THEN they shall live under a single `spec/` directory at the repository root with `spec/INDEX.md` as the entry point.
- **R2** WHEN one of the existing five spec documents (`docs/SPEC.md`, `docs/JSON_CONTRACTS.md`, `docs/CQ_YAML_RUNTIME_CONTRACT.md`, `docs/STRICTNESS.md`, `docs/CQ_MCP_SPEC.md`) is requested, the file at the original `docs/` path shall continue to resolve, redirecting/linking to the new `spec/` location (a 1-line redirect file).
- **R3** WHEN `schema_version` policy is needed, `spec/VERSIONING.md` shall define: the semver mapping, what counts as breaking, deprecation period, and how agent runtimes discover supported versions.
- **R4** WHEN a third party wants to verify "we follow pcq contract", `spec/CONFORMANCE.md` shall describe the format of golden input/output pairs, where they live, and how to run the suite.
- **R5** WHERE a JSON contract exists in `src/pcq/agent/json_contracts.py:JSON_CONTRACTS`, a generated JSON Schema file shall exist at `spec/schemas/<contract_name>.schema.json`, produced by `scripts/export_schemas.py` (run in CI on PR + locally via `make spec`).
- **R6** WHEN conformance is established for the two highest-traffic contracts (`pcq.describe_run.record`, `pcq.run.envelope`), at least one golden input/output pair per contract shall exist under `tests/conformance/<contract>/`.
- **R7** WHEN the README, the site (`#roadmap`), or the agent-manifest.json reference the spec, they shall point at the new `spec/` directory and `spec/INDEX.md`.

### 비기능 요구사항

- **로직 변경 0**: 이번 PR은 *이동·인덱싱·정책·자동화*만. `src/pcq/`의 동작 변경 0. 기존 테스트 모두 통과.
- **링크 보존**: 외부 인용 깨짐 방지 — 옛 docs 위치 5개에 redirect 파일.
- **CI**: `scripts/export_schemas.py` 실행 결과가 commit된 `spec/schemas/*.json`과 일치하는지 CI에서 검증(drift 방지).
- **경량**: 새 외부 의존성 0. JSON Schema export는 표준 라이브러리만으로 가능(또는 `jsonschema` — 기존 deps에 있는지 확인 후 결정).

### 범위 외

- pcq-spec을 별도 PyPI 패키지/리포로 분리 (다음 PR)
- conformance 슈트의 모든 contract 커버 (이번엔 2개만)
- Go/JS reference client (다음 PR)
- versioning policy의 자동화된 strict-deprecation 알림
- breaking change CI 검출(JSON Schema diff 도구)
- OpenAPI/AsyncAPI 도입

## 리스크

| 리스크 | 심각도 | 초기 대응 |
|--------|--------|----------|
| 5개 docs 파일 이동으로 외부 인용 깨짐 | 중 | 옛 위치에 1줄 redirect (`> Moved to spec/<name>.md`) 파일 유지 |
| JSON Schema export가 frozen registry와 어긋남 | 중 | export script에 dry-run 비교 + CI에서 drift 검증 |
| conformance pair가 환경 의존(timestamps/git_sha) | 중 | site의 tools-catalog와 동일한 정책 — volatile 필드는 placeholder("...") + matcher로 무시 |
| versioning 정책이 너무 엄격 → 향후 진화 막음 | 낮 | 첫 버전은 *명문화만*. 자동 enforce는 다음 PR |
| spec/ 디렉토리 + docs/ 둘다 spec 보유 → 혼란 | 낮 | docs/는 사용 가이드(`MCP_INTEGRATION.md`, `AGENT_OPERATING_GUIDE.md` 등)만, spec/는 명세만으로 명확 분리 |

## 탐구 중 발견한 인사이트

- `JSON_CONTRACT_VERSION = 1` 이 이미 코드에 박혀 있음. additive-only 정책도 docstring에 명시. 이건 자산 — `spec/VERSIONING.md`에 옮겨서 SoT화.
- 5개 문서 합계 ~1630줄. 이동만으로 구조 큰 개선.
- `CQ_MCP_SPEC.md` 514줄 — 가장 큰 spec 자산. spec/으로 옮겨야 자연스러움.
- `MCP_INTEGRATION.md`는 사용 가이드(install, .mcp.json) — spec 아님. docs/에 남김.

## 참고 자료

- 직전 사이클: `.cq/runtime/ideas/site-trust-and-compare.md`
- frozen registry: `src/pcq/agent/json_contracts.py`
- 기존 spec 문서 5개: `docs/{SPEC,JSON_CONTRACTS,CQ_YAML_RUNTIME_CONTRACT,STRICTNESS,CQ_MCP_SPEC}.md`
- 같은 카테고리 OSS의 spec 분리: protobuf `.proto` + `protoc-gen`, OpenAPI `.yaml` + Swagger Codegen, JSON Schema 자체 `https://json-schema.org/`

---
*Generated by /pi on 2026-05-10 — start of "1·2·3 foundation" arc*
