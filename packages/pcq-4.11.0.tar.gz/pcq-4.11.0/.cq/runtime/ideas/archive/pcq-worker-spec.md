# pcq worker_spec — 컴퓨터를 양식에 박기

> pcq 1.x에 `worker_spec` 객체 additive 추가. TheCommons 매치메이커가 evidence를
> *어떤 사양의 PC에서 나왔는지* 인덱싱할 수 있게 한다.

## 한 줄 비전

> **모든 pcq run_record가 *어떤 컴퓨터에서 실행됐는지*를 1급으로 기록한다.**

## 왜 이 아이디어인가

직전 attribution 사이클이 *행위자(누가)*를 양식에 박았다. 이번은 *컴퓨터(어디서)*.
TheCommons 매치메이커의 핵심 입력은:

1. **문제 형태** (다음 사이클 — data fingerprint)
2. **행위자** ✅ attribution (직전 사이클 완료)
3. **컴퓨터 사양** ← 이번 사이클

이 셋이 모이면 매치메이커가 "이 문제 + 이 사양 → 추천 풀이"를 만들 수 있다.
지금 pcq는 `platform`, `gpu_count`, `gpu_model`만 자동 감지 — *부족*. RAM·CPU 모델·
VRAM·CUDA 버전 없이는 추천 불가.

## TheCommons 비전이 요구하는 7개 pcq 변경 중 #2

| 순위 | 항목 | 상태 |
|---|---|---|
| 1 | Agent attribution | ✅ 완료 |
| **2** | **Worker spec 확장 (이번)** | **진행** |
| 3 | Data fingerprint | 다음 |
| 3 | Inference 메트릭 표준 키 | 다음 |
| 4 | Failure 카테고리·Recipe·Cycle membership | 나중 |

## 확정 결정

- **수집 방식**: 자동 우선 + cfg override (`cq.yaml.worker.*`)
- **자동 감지 라이브러리**: psutil (CPU/RAM, cross-platform), torch (CUDA, 이미 있음),
  optional GPUtil (CUDA 보조). 새 dep = psutil (pure Python, 안전).
- **필드 범위**: Standard 22 필드 + critique 반영 추가 (detector_hint, visible_devices, torch_ordinal)
- **저장 위치**: run_record 최상위 `worker_spec` 객체 (attribution 패턴 그대로)
- **flat surface**: 4개 (cpu_model, memory_gb, accelerator_kind, gpu_model_0)
- **정적 only**: 동적 벤치마크는 Phase 2 (코퍼스 evidence가 그 역할 대체)
- **PII 차단**: hostname/IP/MAC/사용자명 절대 emit 안 함 (R10)

### Critique 반영 (2026-05-13) — v2

- **R11 4분기 정밀화**: WORKER_PSUTIL_MISSING / _PARTIAL / WORKER_TORCH_MISSING /
  WORKER_CGROUP_DENIED 각각 별도 warning code. try/except는 필드 단위만.
- **R12 신설 (container 모호)**: enum에 "other" 추가 + detector_hint 필드 +
  WORKER_CONTAINER_AMBIGUOUS warning. Podman/LXC/WSL/nspawn 모두 cover.
- **R13 신설 (gpus[] 결정성)**: NVML PCI bus_id 오름차순. torch_ordinal + visible_devices audit.
- **R14 신설 (declared PII 백도어)**: declared/merged 경로의 자유 문자열에 hostname-shape 패턴 시
  validation_report L3+ warn (WORKER_DECLARED_PII_LIKE). R10은 detection-only로 한정.
- **cgroups 1.0 out-of-scope** (DEC-011): host view only. declared override로 사용자 신고 가능.
- **wheel matrix 검증** (T-1 DoD): manylinux/musllinux/macos arm64/win amd64·arm64 모두 확인.

## 핵심 설계 — worker_spec 객체

```json
"worker_spec": {
  "schema_version": 1,
  "cpu": {
    "model": "Apple M2 Pro",
    "cores_physical": 10,
    "cores_logical": 10,
    "max_freq_mhz": 3500
  },
  "memory": {
    "total_gb": 32
  },
  "accelerator": {
    "kind": "mps"|"cuda"|"cpu",       // enum, 항상 존재
    "gpus": [                         // [] when cpu/mps
      { "model": "RTX 4070", "vram_gb": 12, "cuda_version": "12.1" }
    ]
  },
  "os": {
    "system": "Darwin",
    "machine": "arm64",
    "release": "23.6.0"|null          // 커널 버전, 옵션
  },
  "container": {
    "kind": "none"|"docker"|"k8s",
    "image": "..."|null
  },
  "source": "detected"|"declared"|"merged"  // 어디서 왔는지 audit
}
```

### Flat surface (4개, attribution 패턴 따름)

- `worker_spec_cpu_model` — string|null
- `worker_spec_memory_gb` — number|null
- `worker_spec_accelerator_kind` — string|null
- `worker_spec_gpu_model_0` — string|null (첫 GPU; [] 이면 null)

### 수집 우선순위 (attribution 패턴)

```
1. CLI args (--worker-cpu-model 등 — 옵션, 거의 안 씀)
2. cq.yaml.worker.* 명시
3. 자동 감지 (psutil + torch + optional GPUtil)
4. 부분 부재 → 필드 null
5. 전부 부재 → worker_spec 자체 null (옛 record 호환)
```

### source audit 의미

| source | 의미 |
|---|---|
| `detected` | 모든 필드 자동 감지로 채움 |
| `declared` | cfg가 모든 필드 명시 (사용자 신고) |
| `merged` | 일부는 자동, 일부는 cfg (override) |

## 기존 시도와 차별

| 시도 | 한계 | 우리 접근 |
|---|---|---|
| BOINC `<host_info>` | ML GPU 의식 약함 | ML 친화 (CUDA, MPS, VRAM) |
| MLPerf hardware card | 슈퍼컴 지향 | 노트북·일반 PC 포함 |
| PassMark/UserBenchmark | ML 컨텍스트 0 | evidence에 곧장 연결 |
| HF `accelerate env` | 사양 정보 약함 | 표준 JSON, 인덱싱 가능 |
| k8s NodeStatus | 클러스터 지향 | 단일 PC |

**공백 채움**: ML 친화 + 노트북·일반 PC + 표준 JSON + 인덱싱 친화.

## 요구사항 (EARS)

### 기능 요구사항

- **R1** WHEN pcq writes a run_record.json, the system shall include an optional
  `worker_spec` object conforming to the schema defined below.
- **R2** WHERE the worker_spec object is present, `accelerator.kind` and `source`
  shall be populated. All other fields MAY be null.
- **R3** WHEN pcq is invoked without any worker overrides, the system shall
  auto-detect cpu/memory/accelerator/os via psutil + torch (+ optional GPUtil)
  and emit `source: "detected"`.
- **R4** WHEN `cq.yaml.worker.*` declares all fields, the system shall use those
  values and emit `source: "declared"`.
- **R5** WHEN cfg declares some fields and auto-detection fills the rest, the
  system shall emit `source: "merged"`.
- **R6** WHERE `pcq describe-run --json` outputs the record, worker_spec shall
  be exposed both as a nested object AND as 4 flat surface fields
  (`worker_spec_cpu_model`, `worker_spec_memory_gb`,
  `worker_spec_accelerator_kind`, `worker_spec_gpu_model_0`).
- **R7** WHEN existing run_records without a `worker_spec` field are read, pcq
  shall treat them as valid (backward compatible) and surface `worker_spec: null`.
- **R8** WHEN attribution is added, sibling schemas shall passthrough worker_spec:
  `pcq.compare_runs.diff` shall expose `worker_spec_changed: boolean`,
  `pcq.run.envelope` shall carry worker_spec.
- **R9** WHEN pcq.agent.json_contracts registers worker_spec, two golden
  conformance pairs shall be added: (a) with-worker-spec (full detected),
  (b) without-worker-spec (옛 record case).
- **R10** WHERE auto-detection runs, the system shall NEVER emit hostname, IP,
  MAC address, or user name. These are explicitly forbidden at the format layer.
- **R11** WHEN psutil import fails or any auto-detection step fails, pcq shall
  emit partial worker_spec with null fields (NOT crash) and add a warning to
  validation_report.

### 비기능 요구사항

- **Additive only**: 옛 record `worker_spec` 부재 또는 `null` 모두 valid.
  외부 호환 깨짐 0.
- **새 dep = psutil only**: pure Python, cross-platform, BSD 라이선스. torch는
  이미 옵션 dep.
- **No PII**: hostname/IP/MAC/user 명시적 금지 (R10).
- **No dynamic benchmark**: 1.0은 정적만. matmul TFLOPS 같은 측정은 Phase 2.
- **Graceful degradation**: 감지 실패 시 null + warning, 절대 crash X (R11).
- **MCP compat**: 14 MCP tool 회귀 0. describe_run nested + flat 양면.

### 범위 외

- 디스크 종류·여유 (1.0 외, 다음 사이클)
- 네트워크 대역폭 (1.0 외)
- 동적 벤치마크 (Phase 2)
- swap 정보
- multi-user quota (cgroups CPU limit 등)
- TheCommons 측 worker_spec 인덱싱 프로토콜 (TC 빌드 단계)

## 리스크

| 리스크 | 심각도 | 대응 |
|---|---|---|
| psutil이 일부 환경에서 부정확 (컨테이너 안의 cgroups limit 미반영) | 중 | R11 graceful degradation + source=detected 표기로 *추론 신뢰도* 노출 |
| torch 미설치 환경에서 GPU 감지 0 | 중 | torch 옵션 import, 없으면 accelerator.kind="cpu" |
| MPS 감지가 plaform 의존 | 중 | torch.backends.mps.is_available() 활용 |
| 옛 record와 호환 (R7 implicit null vs explicit null) | 낮 | T-6 unit test 양면 검증 |
| cfg override 형식이 사용자에게 복잡 | 낮 | docs에 단순 예제 제공 (T-7) |
| 컨테이너 감지 false positive | 낮 | docker/k8s detection 보수적 (확실한 신호만, 그 외 "none") |

## 변경되는 파일 (예상)

| 파일 | 변경 |
|---|---|
| `src/pcq/contract.py` | `build_worker_spec_object()` 신설 + finalize_run 시그니처에 worker_spec 추가 |
| `src/pcq/core.py` | save_all 통합 |
| `src/pcq/agent/json_contracts.py` | registry에 worker_spec + flat surface + sibling passthrough |
| `src/pcq/agent/describe.py` | nested + flat 노출 |
| `spec/schemas/*.json` | 4개 schema (describe_run + compare_runs.diff + envelope + validation_report) additive |
| `spec/SPEC.md` | Worker Spec 섹션 |
| `spec/JSON_CONTRACTS.md` | worker_spec contract |
| `spec/VERSIONING.md` | worker.* env/cfg precedence (CLI > CQ_WORKER_* > cfg > auto > null) |
| `tests/test_worker_spec.py` | R1-R11 unit tests |
| `tests/conformance/pcq.describe_run.record/{with-worker-spec,without-worker-spec}/` | 2 golden pairs |
| `pyproject.toml` | psutil dep 추가 |
| `templates/AGENTS.pcq.md` | worker_spec 섹션 + env/cfg 예제 |
| `skills/pcq/SKILL.md` | worker_spec jq 예제 |
| `CHANGELOG.md` | 변경 기록 |

## 다음 사이클 후보

1. **Data fingerprint** — 통계 모먼트·schema 메타 (이제 정말 다음 차례)
2. **Inference 메트릭 표준 키** — latency/throughput/memory_peak
3. **Failure 카테고리** — OOM/diverged/time-budget
4. **R10 PII validation runner** — attribution 사이클의 T-6 skip 활성화

## 관련

- [[pcq-agent-attribution]] — 직전 사이클 (행위자 표준화), 같은 패턴 모방
- [[the-commons-vision]] — Wiki+봇 권한 모델 + 매치메이커
- [[pcq-spec-foundation]] — additive-only 정책

---

*Generated by /pi on 2026-05-13 — worker spec as the second pillar (after attribution) of TheCommons matchmaking input*
