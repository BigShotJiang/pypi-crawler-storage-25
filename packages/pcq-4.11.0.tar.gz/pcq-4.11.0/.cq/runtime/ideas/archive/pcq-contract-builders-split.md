# pcq contract.py builders/ 분리

> 단순화 audit (A 가닥). 2,659줄 god module에서 7 builder + integrity helpers를
> 새 `src/pcq/builders/` 패키지로 분리. 외부 import 경로는 re-export로 살림 (breaking 0).
> 매 사이클 +300줄씩 누적되는 압력을 해소.

## 한 줄 비전

> **god module 분리, 외부 surface 무변경.** 7 builder + 무결성 헬퍼를 builders/ 패키지로.
> `from pcq.contract import build_*` 그대로 작동. 책임 명확, 다음 사이클 builder 추가는 자기 파일에.

## 문제

contract.py 2,659줄 / 50 def에 5종 책임 섞임 (git helpers / env snapshot / sha+file IO /
6개 builder / lifecycle). 매 cycle attribution(v4.4) → worker_spec(v4.5) → fingerprint(v4.6)
→ intent/integrity/contract_version(v4.9) → code/seeds/data_ref(v4.10)로 300+줄씩 누적.
god module 압력 (no-god-objects.md 룰의 ~9배). 다음 cycle (cq M4 emit, future builder)이
또 contract.py에 추가하면 가속화.

## 해결 — 책임 분리, 외부 무변경

**한 가지만 한다**: builder 7개 + 무결성 로직 분리. lifecycle/git/env/file helper는 그대로
(긴급도 낮음, 위험 ↑). 외부 import 경로(`pcq.contract.build_*`)는 re-export로 유지 →
breaking 0.

## 새 구조

```
src/pcq/builders/
  __init__.py        # __all__ = 7 builders + _INTEGRITY_HASHED_FIELDS, _PHI_DOMAINS (re-export 표면)
  attribution.py     # build_attribution_object
  worker_spec.py     # build_worker_spec_object
  intent.py          # build_intent_object + _VALID_INTENT_GOALS
  integrity.py       # build_integrity_object + _resolve_dotted_path + _INTEGRITY_HASHED_FIELDS + _EXCLUDED
  code.py            # build_code_object
  seeds.py           # build_seeds_object
  data_ref.py        # build_data_ref_object + _PHI_DOMAINS
```

contract.py:
```python
# 상단에 re-export — 외부 사용자 무영향
from pcq.builders import (
    build_attribution_object, build_worker_spec_object, build_intent_object,
    build_integrity_object, build_code_object, build_seeds_object, build_data_ref_object,
    _INTEGRITY_HASHED_FIELDS, _PHI_DOMAINS,
)
# lifecycle (save_*, finalize_run), git/env/file helpers, error 분류 등은 그대로
```

contract.py: 2,659 → ~2,000줄 (-25%). builders/ 패키지: 신규 ~700줄 (이동).

## 확정 결정

1. **분리 범위 = builder + integrity만**. lifecycle/git/env/file은 *별 사이클* (긴급도 낮음).
2. **atomic 1 commit**: 분할 중간 상태(양쪽에 같은 함수) 위험 방지. T-1 single atomic commit.
3. **re-export 의무**: `from pcq.contract import build_*` 살아있어야. PyPI semver 무영향.
4. **integrity 의미론 byte-identical 보존**: BL-2 ordering / BL-3 dual PHI gate / BL-4 absent-leaf drop / BL-5 code.scope hash / R15 결정성 / anti-recursion(_EXCLUDED) 전부 동일 동작 강제.
5. **_PHI_DOMAINS 위치**: builders/data_ref.py에. finalize_run lifecycle 2차 게이트는 `from pcq.builders.data_ref import _PHI_DOMAINS` (또는 `from pcq.builders import _PHI_DOMAINS`).
6. **critique 1 round 강제**: ≤3 task라 자동 skip이지만 위험 큼 — architect-reviewer pre-mortem 명시 실행. 지난 사이클들이 정확히 같은 코드 영역(integrity/PHI gate/ordering)에서 REJECT 잡힌 자리.
7. **회귀 가드 = 기존 584 + 30 conformance 그대로**. test_intent_integrity / test_reproducibility_pack 변경 0 (import path 그대로라 무변경 통과해야 함).

## 정체성 정합 체크

- **"Evidence, not opinion"** (positioning #3): 분리는 책임 명확화 — 의미 변경 0. ✓
- **framework-neutral**: builder API 시그니처 무변경. ✓
- **R6 backward-compat**: 외부 import 경로 유지, schema/wire format 무영향. ✓
- **integrity semantics**: byte-identical 보존 (R15 + BL 누적 결정 전부). ✓

## 요구사항 (EARS)

- **R1** WHEN src/pcq/builders/ 패키지가 신규 생성될 때, attribution/worker_spec/intent/integrity/code/seeds/data_ref 7개 파일에 각 builder 함수와 관련 상수가 이동된다.
- **R2** WHERE `pcq.builders.__init__`이 정의될 때, 7 builder + `_INTEGRITY_HASHED_FIELDS` + `_PHI_DOMAINS`을 명시적 `__all__`로 re-export한다.
- **R3** WHERE pcq.contract.py에서 옮긴 함수가 제거될 때, 동시에 `from pcq.builders import ...` re-export를 contract.py 상단에 추가한다 — `from pcq.contract import build_*` 외부 import 경로 100% 유지.
- **R4** WHEN finalize_run lifecycle이 builder + integrity 호출할 때, 의미론 byte-identical (BL-2 ordering, BL-3 dual PHI gate, BL-4 absent-leaf drop, BL-5 code.scope hash, R15 결정성, anti-recursion `_EXCLUDED`) 보존.
- **R5** WHEN 분리 commit 후 회귀 가드를 실행할 때, 기존 584 passed 3 skipped + 30 conformance 그대로. test_intent_integrity / test_reproducibility_pack 변경 0.
- **R6** WHEN 분리 commit 후 schema --check 실행할 때, OK no drift.
- **R7** WHERE 분리는 atomic 1 commit — 분할 중간 상태(중복 정의) 위험 0.
- **R8** WHEN critique loop 실행 시 architect-reviewer pre-mortem 1 round 강제 — ≤3 task 자동 skip 우회. 위험 catalog (1-7) 사전 검증 후 진행.

### 비기능
- **breaking_zero**: `from pcq.contract import build_*` 외부 사용자 100% 무영향. PyPI semver 4.10.x 유지.
- **integrity_semantics_preserved**: byte-identical (R15 + BL 전부)
- **mcp_compat**: 14 MCP tool 회귀 0
- **conformance_unchanged**: 30 passed, hashed_fields 결과 동일
- **additive_test_zero**: 회귀 가드는 *기존 테스트*가 잡음 — 새 테스트 추가 X (의미 변경 0이므로)
- **single_commit_atomic**: T-1 1 commit. 분할 X.

### 범위 외 (명시적)
- lifecycle (save_*, finalize_run, save_all) 분리 — 별 사이클
- git helpers / env snapshot / file IO helper 분리 — 별 사이클
- error 분류 (_classify_exception) 분리 — 별 사이클
- 새 기능 추가 — A는 *재배치만*
- 새 테스트 추가 — 기존 회귀 가드로 충분 (의미 변경 0)
- contract_version bump — PyPI 패키지 패치도 X (4.10.0 그대로)

## Critique Round 1 수렴 (2026-05-20)

Pre-mortem critique이 plan 가정을 깸. 결과: **scope α로 축소 + critique BLOCKING 6건 task DoD에 인라인 인코딩**.

**축소된 scope**: 6 builders만 — attribution / intent / integrity / code / seeds / data_ref. **worker_spec과 fingerprint는 별 사이클 후보로 deferred** (worker_spec은 8 detection helper + 3 frozenset ~430줄 동반 재구조화, fingerprint는 _VALID_* 상수 + modality 추출 로직과의 경계 정리 필요 — 둘 다 신중한 별 사이클 가치).

**Critique BLOCKING 6건 task DoD 반영**:
- BL-1: build_fingerprint_object는 *별 사이클* (scope α). 이 사이클은 6 builders만.
- BL-2: build_worker_spec_object는 *별 사이클* (scope α). 이 사이클은 6 builders만.
- BL-3: import-graph smoke test (`python -c "import pcq.contract; import pcq.builders; from pcq.contract import build_integrity_object; from pcq.builders import build_integrity_object as b; assert b is build_integrity_object"`)을 R-1 첫 검증으로 강제.
- BL-4: `_EXCLUDED`는 function-local — move list에서 제거. 본래 옮길 게 없음.
- BL-5: `_PHI_DOMAINS` re-export option (a) — contract.py에서 명시 re-export. builders/__init__.py `__all__`에 underscore 노출 정당화 주석.
- BL-6: re-export 형식 강제 — `from pcq.builders import (...)` 만 허용 (`import pcq.builders` 단독 X). finalize_run의 bare name 호출 보장.

**NOTE 반영**:
- N-1: re-export `from pcq.builders import _INTEGRITY_HASHED_FIELDS` 동일 객체 binding 확인 (Python import 의미론).
- N-2: `src/pcq/__init__.py` `__all__`에 `build_*` 없음 확인됨 — 변경 불필요.
- N-3: lazy import 6 사이트(cli.py:494 / agent/validate.py:506,669,678 / validate_run.py:485 / mcp/tools.py:690) 모두 re-export 통과 — R-1에서 grep 확인.
- N-5: R-1 reviewer 명시 checklist — git diff --stat mv only, builders 본문 == 옮기기 전 byte-identical (sed range diff), conformance fixture content_hash sha256:b4889af6... 변경 0.

## 위험 catalog (사전 critique 대상)

| 위험 | 심각도 | 대응 |
|---|---|---|
| integrity 의미론 byte-identical 깨짐 (BL-4 absent-leaf 등) | 매우 높음 | R4 강제 + 기존 test_intent_integrity/test_reproducibility_pack 회귀 가드 |
| PHI gate 위치 결정 (_PHI_DOMAINS 어디) | 중 | DEC: builders/data_ref.py 내. lifecycle 2차 게이트는 import |
| finalize_run 호출 site 깨짐 | 중 | contract.py re-export로 내부 호출도 같은 이름 유지 |
| 외부 import 경로 깨짐 (PyPI 사용자) | 매우 높음 | R3 강제 re-export + 분리 commit이 정확히 backward-compat 검증 |
| atomic 1 commit 너무 큼 (review 부담) | 낮 | 700줄 mv는 review 가능 범위 (mv는 단순 식별) |
| circular import (builders ↔ contract) | 중 | builders는 contract import 안 함 — 단방향. 사전 검증 |
| _resolve_dotted_path 등 공통 헬퍼 위치 | 낮 | builders/integrity.py 내부 — 다른 builder가 사용 안 함 |

## 기존 사이클과 정합성

| 사이클 | 이번과 관계 |
|---|---|
| pcq-positioning | "Evidence, not opinion" — 의미 변경 0, 위반 0 |
| pcq-2x-canonical / pcq-reproducibility-pack | 분리 대상의 *컨텐츠* — 이미 정착됨, 재배치만 |
| pcq-archive-ideas-and-docs (직전 사이클) | 인지 부담 청소 완료 → 이번 큰 작업 진입 환경 ↑ |

## 다음 사이클 후보

1. **C** (legacy 'output' fallback 제거)
2. **F** (summary.py fold)
3. **lifecycle 분리** (save_*/finalize_run을 src/pcq/lifecycle.py로) — A 정착 후
4. **TC BL-1 골든 vector** — cq M4 cycle에 자연 합칠 가능성
5. **intent.tolerance 재프레이밍** (의견 → 사실)

## 관련

- [[pcq-positioning]] — 정체성 보존
- [[pcq-2x-canonical]] — integrity/intent/contract_version (이동 대상)
- [[pcq-reproducibility-pack]] — code/seeds/data_ref (이동 대상)
- [[pcq-archive-ideas-and-docs]] — 직전 housekeeping (인지 청소 → 큰 작업 환경)

---

*Generated by /pi on 2026-05-20 — 단순화 audit (A 가닥), god module 분리 + 외부 무변경.*
