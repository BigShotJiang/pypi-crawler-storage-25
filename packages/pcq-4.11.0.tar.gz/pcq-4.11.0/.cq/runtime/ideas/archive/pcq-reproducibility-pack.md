# pcq reproducibility pack — code sha + seeds + data ref

> pcq 양식에 *재현 가능성 substrate*를 박는다. 위조 방지는 못 한다 — *검증을 가능*하게
> 만든다. 양식은 substrate, 검증은 누구든 (사용자/cq/TC 매치메이커/peer reviewer).

## 한 줄 비전

> **재현으로 검증 가능하게.** code sha + seeds + data ref 슬롯 3개 (+ 기존 config) =
> "최소 재현 가능 4-pack". 막진 못해도 *catch는 가능*하게.

## 문제 (한 문장)

지금 pcq는 git_sha만 있어서 거짓말 가능하고, 다른 사람이 받은 run_record를 *재현해서
숫자를 다시 만들어볼* 재료가 부족하다.

## 해결 — substrate vs verification 분리

> **pcq는 검증하지 않는다. pcq는 검증을 가능하게 만든다.** (SRP대로 — pcq양식만 / 검증은 외부.)

100% 방지(prevention)는 2026 기술로 불가:
- TEE: H100 confidential compute 비현실
- ZK-ML: 학습은 frontier, 10-1000배 오버헤드
- 재현 합의: 데이터 공유·인센티브 문제
- 신뢰 제공자: 중앙화 (Commons 정신 충돌)

대신 *catch 가능성*만 양식이 보장. Wikipedia 모델 — vandalism 못 막지만 diff 보이게
만들어 revert 가능. 가짜 만드는 비용 ↑, 들통날 확률 ↑로 *경제학 문제*로 전환.

## 핵심 결정

1. **3 신규 필드** (전부 top-level, optional, additive):
   - `code` = `{content_sha256, scope}` — *무엇이* 해시되었는지 자기 기술
   - `seeds` = `{<name>: int|str, ...}` — multi-seed 케이스 대응 (numpy/torch/dataloader)
   - `data_ref` = `{uri, content_sha256, size_bytes}` — content sha는 결정적
2. **PHI 게이트 정합**: gated 도메인은 `data_ref.content_sha256` emit 금지 (기존 R5 Layer-2와 정합 — content sha가 re-identification 보조 신호 위험). `uri` + 기존 fingerprint hints-only만.
3. **integrity 결합**: 새 필드를 `_INTEGRITY_HASHED_FIELDS` leaf-allowlist에 추가 — 변조 시 integrity hash 깨짐. anti-recursion 패턴 동일 (integrity 자신 + attribution.signature 제외 유지).
4. **describe-run dual exposure**: nested + flat (`code_content_sha256`, `seeds_main` or `seed`, `data_ref_uri`) — 기존 attribution/worker_spec/fingerprint 패턴 따라.
5. **한계 명시 강제**: SPEC.md + README에 *"code sha는 어떤 코드인지만 증명, 그 코드가 이 결과를 만들었는지는 증명 안 함. 인과 attestation은 별도"* 문장 박음. 과대주장 차단.
6. **contract_version "2.0" 유지** — additive 2.x 진화, major bump 아님. R6 backward-compat (옛 record 전부 valid).

## 정체성 정합 체크

- **"Evidence, not opinion"** (positioning #3): code sha/seeds/data ref 전부 *사실*. ① intent 같은 의견 0. **위반 없음.**
- **"pcq operates the boundary, not the model"**: code 내용·data 내용 자체는 pcq 밖, pcq는 *해시·식별자·범위 descriptor*만 표준화. **boundary만 다룸.**
- **framework-neutral**: PyTorch든 sklearn이든 코드 해시는 도구 중립.

## 요구사항 (EARS)

- **R1** WHEN pcq run_record가 작성될 때, 선택적 top-level `code` 객체 `{content_sha256, scope}`를 포함할 수 있다. additive — 부재 = 기존 1.x/2.x, valid.
- **R2** WHERE `code.content_sha256`가 emit될 때, cq.yaml에 선언된 코드 범위(또는 디폴트: 진입 스크립트 + cq.yaml + 명시 의존)에 대한 결정적·byte-identical sha (R15 canonical form). `code.scope`는 무엇이 해시되었는지 자기 기술.
- **R3** WHEN pcq run_record가 작성될 때, 선택적 top-level `seeds` 객체 `{<name>: int|str, ...}`를 포함할 수 있다 (multi-seed; 단일 시드도 `{"main": N}` 형태). additive.
- **R4** WHEN pcq run_record가 작성될 때, 선택적 top-level `data_ref` 객체 `{uri, content_sha256, size_bytes}`를 포함할 수 있다. additive.
- **R5** WHERE domain ∈ {medical, financial, regulated} (PHI), `data_ref.content_sha256`는 emit 금지 (re-identification 보조 신호 위험, 기존 R5 Layer-2 정합). `uri` + 기존 fingerprint hints-only만 허용.
- **R6** WHERE pcq 2.x `integrity.hashed_fields` leaf-allowlist에, 새 필드 `code.content_sha256` / `seeds` / `data_ref.content_sha256`(non-PHI 시) 추가. 변조 시 integrity hash 깨짐.
- **R7** WHERE describe-run --json 출력 시, code/seeds/data_ref가 nested + 필요한 flat surface(`code_content_sha256`, `seed` 또는 `seeds_main`, `data_ref_uri`)로 노출.
- **R8** WHEN spec/SPEC.md가 새 필드를 기술할 때, 한계 문장 필수: *"code.content_sha256은 어떤 코드가 기록되었는지만 증명한다. 그 코드가 실제로 실행되어 이 출력을 만들었는지는 증명하지 않는다. 인과 attestation은 별도."*

### 비기능
- additive_only: 옛 record 전부 valid
- contract_version "2.0" 유지 (additive 2.x 진화, major bump 아님)
- positioning_preserved: "Evidence, not opinion" — 4-pack 전부 사실
- mcp_compat: 14 MCP tool 회귀 0
- conformance: pcq-2x-full fixture에 새 필드 추가, pcq-1x-legacy 부재 유지로 R6 증명
- limit_documented: R8 한계 문장 + README 짧은 언급 (과대주장 차단)

### 범위 외 (명시적)
- attestation slot (TEE/ZK/sigstore) — 별 사이클
- provenance_chain (cq 서명된 origin 주장) — 별 사이클
- lockfile/container env sha — 별 사이클, future optional
- ① intent 처리(의견 필드 재프레이밍/이동/삭제) — 별 사이클
- 자동 재현 도구(`pcq reproduce` CLI 등) — 별 사이클, 양식이 substrate / 도구는 후행
- 데이터 콘텐츠 해시 알고리즘 표준화 (Merkle vs concat) — 코드는 디폴트 권장, 데이터는 사용자 결정

## 기존 사이클과 정합성

| 사이클 | 이번과 관계 |
|---|---|
| pcq-positioning | "Evidence, not opinion" — 4-pack 전부 사실, 위반 0 |
| pcq-2x-canonical | additive 2.x 진화. integrity.hashed_fields 확장 |
| pcq-data-fingerprint | fingerprint(stats) ↔ data_ref(content sha) 보완. PHI 게이트 동일 정합 |
| pcq-agent-attribution | attribution(who) ↔ code/seeds/data(what). signature anti-recursion 유지 |
| the-commons-vision | TC 매치메이커가 이 4-pack으로 추천 전 재현 시도. catch 메커니즘의 substrate |

## 리스크

| 리스크 | 심각도 | 대응 |
|---|---|---|
| "code sha = attestation"으로 오해 | 중 | R8 한계 문장 + 문서·README에서 반복 |
| "code" 범위 모호 (train.py vs repo vs env) | 중 | `scope` descriptor로 위임, 디폴트 권장(entry script + cq.yaml + 명시 deps) |
| PHI 데이터 콘텐츠 해시 누출 | 중 | R5 게이트 — gated 도메인 content_sha256 emit 금지 |
| 슬롯이 *영원히 비어* — 아무도 안 채움 | 낮 | optional — 비어도 valid. cq 같은 적극적 emit자가 채움. additive라 비용 거의 0 |
| ML 비결정성으로 재현해도 숫자 불일치 → "catch" 가 모호 | 중 | tolerance 개념 필요 — 별 사이클(① 재프레이밍에서 회수 가능) |

## 다음 사이클 후보

1. **attestation slot + provenance_chain** — TEE/ZK/sigstore/cq 서명 등 *모든 강도의 attestation*을 channel할 봉투 슬롯 (이번에 분리한 것)
2. **① intent 재프레이밍** — "주장 vs 사실" 경계 정리; tolerance를 "사용자 원하는 기준"(opinion) vs "관측된 stochastic variance"(fact)로 분리
3. **lockfile/container env hash** — env 해시 optional 슬롯
4. **`pcq reproduce` CLI** — 4-pack을 받아 재현 시도하는 도구 (cq/TC 둘 다 호출 가능)
5. **TC matchmaker pre-promotion re-run** — 추천 전 재현 검증 정책 (TC scope)

## 관련

- [[pcq-2x-canonical]] — additive 2.x 진화 토대
- [[pcq-positioning]] — Evidence-not-opinion 정체성 (4-pack은 위반 0)
- [[pcq-data-fingerprint]] — fingerprint(stats) vs data_ref(content sha) 보완
- [[pcq-agent-attribution]] — attribution(who) ↔ code/seeds/data(what)
- [[the-commons-vision]] — Wikipedia 모델 catch 메커니즘의 substrate

---

*Generated by /pi on 2026-05-20 — substrate for reproducibility-based verification. 막진 못해도 catch 가능하게.*
