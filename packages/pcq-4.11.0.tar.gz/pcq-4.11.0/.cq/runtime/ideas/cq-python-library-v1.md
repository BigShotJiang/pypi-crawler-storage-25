# cq Python Library v1

> cq.yaml 컨트랙트 위에서 동작하는, **검증된 레시피로 시작해서 atom으로 다듬는** ML authoring 라이브러리.

## 왜 이 아이디어인가

cq는 원격 GPU 실험을 위한 orchestrator를 갖추었지만, 실제 학습 스크립트(`train.py`)는 아직 raw PyTorch + 환경변수 boilerplate. cq.yaml에 메트릭과 아티팩트가 선언돼도, Python 쪽은 매번 같은 셋업(seed, output_dir, stdout `@key=value`, config 로드)을 손으로 쓰고 있다. 이 boilerplate가 cq의 ML 사용 문턱을 만든다.

동시에 ML 생태계는 timm·Lightning·HF Trainer·PyCaret 등 흩어진 추상화로 넘쳐난다. 사용자는 매번 "이 라이브러리는 어떤 인터페이스로 부르더라"를 다시 학습한다. cq에서 한 번 정한 패턴이 저레벨~고레벨까지 일관되면, 사용자는 한 번 배우고 모든 레이어를 오갈 수 있다.

## 풀고자 하는 문제

- **누가**: cq를 쓰는 ML 실험자 (데이터는 worker에 준비돼 있고, cq.yaml로 잡을 던지는 사용자).
- **어떤 고통**:
  1. cq 컨트랙트 boilerplate (CQ_CONFIG_JSON 파싱, output_dir 생성, stdout `@key=value` 출력) 매번 수작업.
  2. 학습 루프 표준이 없어서 실험마다 train.py가 갈라짐 → 코드 리뷰·재현 어려움.
  3. "가벼운 cifar10 baseline 한 번 돌리고 싶다"가 100줄 셋업.
  4. multi-GPU 시 DDP/FSDP 셋업이 또 다른 진입장벽.
- **언제**: 데이터 준비 + cq.yaml 작성 시점부터 첫 학습 실행까지.

## 기존 대안과 차이

| 대안 | 한계 | 우리가 다른 점 |
|------|------|--------------|
| **raw PyTorch + cq.yaml** | boilerplate 100줄 | 저레벨 5개 함수로 압축 |
| **PyTorch Lightning** | LightningModule 패턴 학습 비용, cq 컨트랙트와 별개 | cq.yaml 컨트랙트 일급, accelerate underlying |
| **HF Trainer** | transformers 생태계 락인, 일반 vision/MLP에 무거움 | task-agnostic, 가벼운 trainer |
| **PyCaret** | tabular ML 중심, DL/GPU 워크플로 약함 | DL 우선, recipe로 vision/NLP 확장 |
| **timm** | vision 모델 카탈로그만, 학습 루프·trainer 없음 | atom + recipe + trainer 한 패키지 |
| **Hydra + composer** | config 추상화는 강력, atom-level API 인체공학 떨어짐 | Python first, recipe = atom 조합의 alias |

**한 줄 차별점**: timm 카탈로그 × Lightning 학습 루프 × cq.yaml 컨트랙트가 한 라이브러리에 있고, 모든 레이어가 동일한 atom을 공유.

## 요구사항 (EARS)

### 기능 요구사항 — 저레벨 API

- **시스템은 항상** `cq.config()`로 `CQ_CONFIG_JSON`을 읽어 dict를 반환한다.
- **IF** `CQ_CONFIG_JSON` 환경변수가 없으면 **THEN** 시스템은 명확한 `RuntimeError`를 던진다.
- **WHEN** `cq.log(**values)` 호출 시 **THEN** 시스템은 finite numeric 값만 stdout에 `@key=value` 형식으로 출력한다.
- **WHEN** `cq.log()`에 bool/string/NaN/inf가 전달되면 **THEN** 시스템은 그 key를 출력에서 제외한다.
- **WHEN** `cq.log()`에 cq.yaml.metrics에 선언되지 않은 key가 전달되면 **THEN** 시스템은 첫 1회 stderr 경고 + 종료 시 요약. `strict=True` 모드에서는 즉시 raise.
- **시스템은 항상** `cq.output_dir()`로 config의 `output_dir` 또는 `"output"`을 만들고 `Path`를 반환한다.
- **시스템은 항상** `cq.input_dir(name)`으로 worker가 fetch한 데이터 디렉토리 경로를 반환한다 (환경변수 reader, 단순).
- **시스템은 항상** `cq.seed_everything(seed)`로 numpy/torch/random 시드를 고정한다.

### 기능 요구사항 — 중레벨 API (`cq.Experiment`)

- **시스템은 항상** `Experiment`에 `cfg`, `device`, `output_dir`, `history` 속성을 제공한다.
- **시스템은 항상** 기본 split으로 `train`, `eval`을 인식한다.
- **시스템은 항상** single model + single optimizer + train/eval epoch 루프를 기본 제공한다.
- **WHEN** 사용자가 `training_step`/`eval_step`이 dict를 반환하면 **THEN** 시스템은 dict key를 메트릭 이름으로 그대로 사용한다.
- **WHEN** `fit()` 종료 시 **THEN** 시스템은 `output_dir/model.pt`, `output_dir/config.json`, `output_dir/metrics.json`, `output_dir/last.ckpt`, `output_dir/best.ckpt`를 저장한다.
- **WHERE** 사용자가 필요하면 `fit()` 전체를 override할 수 있다.
- **WHERE** `accelerate`가 환경에 설치되어 있으면 시스템은 multi-GPU 경로로 분기한다.

### 기능 요구사항 — 고레벨 API (`cq.Trainer`)

- **시스템은 항상** `cq.Trainer(preset=...)`으로 검증된 레시피를 한 줄에 실행 가능하게 한다.
- **시스템은 항상** preset의 atom을 부분 override 가능하게 한다 (`cq.Trainer(preset=..., sched=cq.sched.cosine(...))`).
- **시스템은 항상** preset 없이 atom만으로 조립 가능하게 한다.
- **v1 지원 범위**: task=`classification`, dataset=`fake`/`cifar10`, model=`mlp`/`small_cnn`, loss=`cross_entropy`, optim=`adamw`, sched=optional `cosine`.

### 기능 요구사항 — Resume

- **WHEN** `CQ_CONFIG_JSON.configs.resume_from`이 명시되면 **THEN** 시스템은 해당 경로의 체크포인트를 로드해 resume한다.
- **WHEN** `resume_from`이 없으면 **THEN** 시스템은 자동 resume하지 않고 fresh start.

### 기능 요구사항 — 카탈로그

- **시스템은 항상** atom과 recipe를 단일 패키지(`src/cq/`)에서 제공한다 (Monolith).
- **시스템은 항상** recipe를 Python 함수로 정의한다 (`def vit_b16_finetune() -> dict`). YAML 아님.
- **시스템은 항상** preset/recipe 내용을 사용자가 print해 검사 가능하게 한다 (학습 자료성).
- **WHERE** 무거운 의존성(timm/transformers)은 optional extras로 분리한다 (`cq-python[vision]`, `cq-python[nlp]`).

### 비기능 요구사항

- **의존성**: 기본 설치는 torch + numpy + stdlib만. accelerate/timm/transformers는 extras.
- **테스트**: 모든 저레벨 API + Experiment fake dataset CPU smoke + Trainer fake/cifar10 한 epoch.
- **재현성**: seed 고정 시 동일 결과. config + git SHA를 metrics.json에 기록.
- **관측**: stdout `@key=value`로 cq Hub의 MetricWriter와 호환.

### 범위 외 (Out of Scope) — v1

- **Drive/Hub 직접 호출** (별도 세션에서 다룸. v1은 worker가 미리 준비한 데이터만).
- **아티팩트 자동 업로드** (별도 세션).
- **Lightning interop** (자체 luckup만. `from_lightning(...)` adapter는 v2).
- **자동 resume** (resume_from 명시 only).
- **Distributed strategy 직접 구현** (accelerate에 위임).
- **AutoML / 하이퍼파라미터 sweep** (v1 non-goal).
- **고레벨 카탈로그 확장** (vision recipe 5개+ 등은 v2).
- **Recipe-as-YAML, Plugin namespace, Copy-paste 배포** (모두 v2 검토).

## 리스크

| 리스크 | 심각도 | 초기 대응 |
|--------|--------|----------|
| Monolith 패키지의 dep 비대화 | 중 | optional extras로 분리, v1.x 종료 시 size 측정 → v2 namespace package 분리 트리거 |
| Recipe 카탈로그 빈약 시 가치 미달 | 높 | v1은 SPEC 그대로 좁게(1-2개), atom 조합 패턴 박아두고 v2에서 vision/NLP 5+ 추가 |
| accelerate detection 부재 시 multi-GPU 사용자 혼란 | 중 | `cq-python[dist]` extras 명시 + 미설치 시 명확한 안내 메시지 |
| 메트릭 schema 경고가 시끄럽거나 무시됨 | 저 | 첫 1회 + 종료 요약, strict=True 옵션으로 CI에서 강제 |
| cq.yaml 컨트랙트 변경 시 라이브러리 호환성 깨짐 | 중 | 저레벨 함수 5개를 컨트랙트 경계로 고정, 그 위는 자유롭게 진화 |
| Resume이 명시적이라 사용자가 잊을 수 있음 | 저 | spot-kill 발생 시 cq worker가 재시작 시 `resume_from=output_dir/last.ckpt`를 자동 주입하는 정책 권장 (별도 세션에서) |

## 탐구 중 발견한 인사이트

1. **저레벨의 진짜 가치는 "PyTorch wrapper"가 아니라 "cq 컨트랙트 어댑터"**. PyTorch는 빌려쓰는 의존성, cq.yaml + stdout 메트릭이 진짜 인터페이스.
2. **(C) Hybrid의 핵심은 "recipe = atom 조합의 alias"**. 마법이 없어야 사용자가 print로 학습 가능. timm/Hydra의 디버깅 어려움을 회피.
3. **레이어 간 atom 공유**가 시스템 일관성의 핵심. 고레벨 사용자가 중레벨로 내려갈 때 같은 `cq.models.vit_b16()`을 그대로 쓸 수 있어야 학습 곡선이 매끄러움.
4. **메트릭 schema 경고 + strict 옵션**은 CI/CD 환경에서 무성의한 메트릭 누락을 차단하는 저비용 게이트.
5. **(가) Library = client only** 결정 덕에 라이브러리는 cq.yaml을 모름 → preset/recipe는 모두 Python 코드 안에서만. 이게 SSOT를 명확하게 유지.
6. **resume 명시 정책**은 단순하지만 spot-kill 환경에선 worker 재시작 정책과 함께 가야 효과. 라이브러리 단독으로는 절반의 해법.

## 확정된 설계 결정 요약

| 항목 | 결정 |
|---|---|
| Scope | "데이터 준비 + cq.yaml 있음 → 실행"만 |
| cq.yaml 관계 | (가) Library = client only |
| API 3-tier | 저(컨트랙트 어댑터) / 중(Experiment) / 고(Trainer) |
| Tailwind 해석 | (C) Hybrid = preset + atom override |
| Preset 거버넌스 | (a) Monolith. 분리는 v2 |
| 분산 | accelerate underlying, optional extras |
| 메트릭 schema | 미선언 key 경고. strict 옵션 |
| Resume | 명시적 (`resume_from` config key). 자동 X |
| Lightning interop | v1 non-goal |
| 카탈로그 v1 | SPEC 그대로 좁게 (mlp/small_cnn × fake/cifar10) |

## 참고 자료

- 부모 SPEC: `/Users/changmin/git/cq_ml/docs/SPEC.md`
- cq runtime contract: `/Users/changmin/git/cq/SPEC.md`
- 기존 cq.yaml 예시: `/Users/changmin/git/cqtest/cq.yaml`
- Tailwind 비유 출처: timm (atom 카탈로그), Hydra (composition), shadcn/ui (copy-paste alternative — 거부됨)

---
*Generated by /pi on 2026-05-05*
