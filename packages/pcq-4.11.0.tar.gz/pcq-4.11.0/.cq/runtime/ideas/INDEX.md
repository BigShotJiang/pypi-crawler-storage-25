# pcq idea cards — index

Last reviewed: 2026-05-20 (rev 2 — 4 simplification + reframe cycles added).

## Active

- [pcq-build-run-record](pcq-build-run-record.md) — **재정렬됨(불필요로 판명)**. 정본 ingest는 이미 `describe_run→describe_to_evidence 어댑터`. describe_run이 어댑터에 충분함을 코드 검증, P5가 마지막 조각. build_run_record(raw)는 토이 경로 전용 → 보류.
- [pcq-positioning](pcq-positioning.md) — 메시징 카드. "The contract for agent-run ML experiments" 슬로건 및 청중별 1줄 변형. site/README 정체성 동기화는 영구 참조.
- [the-commons-vision](the-commons-vision.md) — 3-layer(pcq/cq/TC) 시스템 비전. TC repo 분리됐지만 pcq 측 참조 표면(매치메이커 설계 원칙, Wikipedia+봇 모델) 유지.
- [cq-python-library-v1](cq-python-library-v1.md) — cq.yaml 컨트랙트 위 ML authoring 라이브러리 (cq.Trainer/cq.Experiment). pcq scope 밖(cq 프로젝트)이라 deferred — 향후 별도 세션 후보.

## Archived (참조)

### Completed — core spec / implementation milestones

- [pcq-spec-foundation](archive/pcq-spec-foundation.md) — completed @ v4.3.0 — spec/ 디렉토리, JSON Schema export, conformance suite 토대
- [pcq-agent-attribution](archive/pcq-agent-attribution.md) — completed @ v4.4.0 — attribution(who) 객체, author/committer/operator 3-role
- [pcq-worker-spec](archive/pcq-worker-spec.md) — completed @ v4.5.0 — worker_spec(where) 객체, psutil 자동 감지, PII 차단
- [pcq-data-fingerprint](archive/pcq-data-fingerprint.md) — completed @ v4.6.0 — fingerprint(what) 객체, modality/task_kind/PII 도메인 게이트, 매치메이커 3-축 완성
- [pcq-2x-canonical](archive/pcq-2x-canonical.md) — completed @ v4.9.0 — intent + integrity + contract_version "2.0" + fingerprint band, TC 경계 규칙 spec에 박힘
- [pcq-reproducibility-pack](archive/pcq-reproducibility-pack.md) — completed @ v4.10.0 — code/seeds/data_ref 3-pack, integrity hashed_fields 확장

### Completed — contract identity / external surfaces

- [contract-identity-lockin](archive/contract-identity-lockin.md) — completed @ commit 2cbdd44 — README/agent-manifest/llms.txt/llms-full.txt 외부 진입점 "pcq is the contract" 정렬
- [contract-identity-evidence](archive/contract-identity-evidence.md) — completed @ v4.3.0 — live conformance(실제 pcq 호출), IMPLEMENTATIONS.md 2 reference impl 등록

### Completed — release / infra

- [release-trust](archive/release-trust.md) — completed @ v4.3.0 — SECURITY.md + GitHub Actions sigstore + SLSA provenance 자동 발급
- [glama-registration-dockerfile](archive/glama-registration-dockerfile.md) — completed @ commit 3defd78 — Dockerfile(python:3.12-slim, pcq mcp serve), awesome-mcp-servers PR gate 통과

### Completed — site

- [site-agent-first-revamp](archive/site-agent-first-revamp.md) — completed @ commit e6b3acb — Connect cards + Tools Catalog 실제 JSON 응답, agent-first 1차 청중 정렬
- [site-trust-and-compare](archive/site-trust-and-compare.md) — completed @ commit 5638456 — trust badges + #compare + #case-studies + #roadmap 추가
- [site-korean-page](archive/site-korean-page.md) — completed @ commit 3742095 — site/index.ko.html + hreflang 양방향 라우팅

### Completed — examples / dogfood

- [examples-pytorch-lightning-hf](archive/examples-pytorch-lightning-hf.md) — completed @ commit 4e5ab5f — PyTorch/Lightning/HuggingFace Trainer 예제 6파일 추가
- [pcq-mnist-dogfood](archive/pcq-mnist-dogfood.md) — completed @ 2026-05-08 — 9-gen dogfood(sklearn→torch), 21 gap 실측, 메타 모순 해결

### Completed — housekeeping

- [pcq-archive-ideas-and-docs](archive/pcq-archive-ideas-and-docs.md) — completed @ T-PCQA-1 — 이 사이클 자체 (idea card 분류·archive·INDEX 신설)
- [pcq-cleanup-c-f](archive/pcq-cleanup-c-f.md) — completed @ 2026-05-20 — legacy 'output' fallback + summary.py audit, 둘 다 conservative-preserve (도달 가능성 확인)

### Completed — contract.py god module decomposition (단순화 audit)

- [pcq-contract-builders-split](archive/pcq-contract-builders-split.md) — completed @ commit 2ecfade — 6 builders(attribution/intent/integrity/code/seeds/data_ref) → src/pcq/builders/ 패키지 (-489 lines)
- [pcq-contract-rest-split](archive/pcq-contract-rest-split.md) — completed @ commits 597489c/425969d/bb04761/10cbb6c — worker_spec + fingerprint_builder + lifecycle helpers + lifecycle core 4 atomic commits, contract.py 2659→78 (-97%)

### Completed — positioning / identity

- [pcq-intent-reframe](archive/pcq-intent-reframe.md) — completed @ commit 7e6e339 — ① 균열 해소 의미적 재프레이밍 (intent는 주장의 사실 기록, pcq는 진위 판단 X)
