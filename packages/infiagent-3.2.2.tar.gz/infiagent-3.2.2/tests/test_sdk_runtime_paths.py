#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import signal
import json
import tempfile
import time
import unittest
import warnings
from pathlib import Path
from unittest.mock import patch

from infiagent import infiagent
from core.hierarchy_manager import get_hierarchy_manager
from tool_server_lite.tools.skill_tools import FreshTool
from tool_server_lite.tools.task_tools import AddMessageTool, ListTaskIdsTool, TaskShareContextPathTool
from utils.config_loader import ConfigLoader
from utils.runtime_control import pop_fresh_request, register_running_task, unregister_running_task
from utils.task_runtime import append_task_message
from utils.user_paths import get_context_settings, get_runtime_settings, runtime_env_scope


class SDKRuntimePathTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.base = Path(self.temp_dir.name)

    def test_default_root_semantics_follow_current_env(self):
        root = (self.base / "default_root").resolve()
        task_id = str((self.base / "default_task").resolve())

        with runtime_env_scope({"MLA_USER_DATA_ROOT": str(root)}):
            agent = infiagent()
            result = agent.add_message("default root message", task_id=task_id)
            self.assertEqual(result["status"], "success")
            self.assertTrue(result["share_context_path"].startswith(str(root / "conversations")))

            listed = agent.list_task_ids()
            self.assertTrue(any(item["task_id"] == task_id for item in listed["tasks"]))

            share_paths = agent.task_share_context_path(task_id=task_id)
            self.assertTrue(share_paths["share_context_path"].startswith(str(root / "conversations")))
            self.assertTrue(share_paths["stack_path"].startswith(str(root / "conversations")))
            self.assertTrue((root / "config" / "app_config.json").exists())

    def test_custom_user_data_root_applies_to_sdk_and_runtime_control(self):
        root = (self.base / "custom_root").resolve()
        task_id = str((self.base / "custom_task").resolve())
        agent = infiagent(user_data_root=str(root))

        result = agent.add_message("sdk scoped message", task_id=task_id)
        self.assertEqual(result["status"], "success")
        self.assertTrue(result["share_context_path"].startswith(str(root / "conversations")))

        with agent._runtime_scope():
            register_running_task(task_id, "alpha_agent", "hello", "OpenCowork")
            try:
                fresh_result = agent.fresh(task_id=task_id, reason="sdk-test-fresh")
                self.assertEqual(fresh_result["status"], "success")
                runtime_root = root / "runtime"
                self.assertTrue((runtime_root / "running_tasks").exists())
                self.assertEqual(pop_fresh_request(task_id), "sdk-test-fresh")
            finally:
                unregister_running_task(task_id)

    def test_task_tools_follow_custom_user_data_root(self):
        root = (self.base / "tool_root").resolve()
        task_id = str((self.base / "tool_task").resolve())

        with runtime_env_scope({"MLA_USER_DATA_ROOT": str(root)}):
            add_tool = AddMessageTool()
            add_result = add_tool.execute(task_id, {"message": "tool message", "source": "agent"})
            self.assertEqual(add_result["status"], "success")
            self.assertTrue(add_result["share_context_path"].startswith(str(root / "conversations")))

            path_tool = TaskShareContextPathTool()
            path_result = path_tool.execute(task_id, {})
            self.assertEqual(path_result["status"], "success")
            self.assertTrue(path_result["share_context_path"].startswith(str(root / "conversations")))

            list_tool = ListTaskIdsTool()
            list_result = list_tool.execute(task_id, {})
            self.assertEqual(list_result["status"], "success")
            self.assertTrue(any(item["task_id"] == task_id for item in list_result["tasks"]))

            fresh_tool = FreshTool()
            fresh_signal = fresh_tool.execute(task_id, {})
            self.assertEqual(fresh_signal["status"], "success")
            self.assertEqual(fresh_signal["_fresh_task_id"], task_id)

    def test_user_data_root_alone_is_enough_for_agent_library_loading(self):
        root = (self.base / "config_root").resolve()
        agent = infiagent(user_data_root=str(root))

        with agent._runtime_scope():
            loader = ConfigLoader("OpenCowork")
            config = loader.get_tool_config("alpha_agent")
            for tool_name in [
                "fresh",
                "add_message",
                "start_background_task",
                "task_share_context_path",
                "list_task_ids",
                "task_history_search",
            ]:
                self.assertIn(tool_name, loader.all_tools)

        self.assertEqual(config.get("type"), "llm_call_agent")
        self.assertTrue((root / "agent_library" / "OpenCowork").exists())

    def test_sdk_requires_explicit_task_id(self):
        agent = infiagent()
        with self.assertRaises(ValueError):
            agent.run("missing task id", task_id="")

    def test_runtime_settings_support_new_reasoning_fields(self):
        root = (self.base / "runtime_settings_root").resolve()
        with runtime_env_scope({"MLA_USER_DATA_ROOT": str(root)}):
            app_config_path = root / "config" / "app_config.json"
            payload = {
                "runtime": {
                    "thinking_enabled": False,
                    "thinking_steps": 12,
                    "no_tool_retry_limit": 9,
                    "action_window_steps": 30,
                    "thinking_interval": 30,
                    "max_turns": 321,
                },
                "context": {
                    "user_history_recent_items": 11,
                    "user_history_compress_threshold_tokens": 1700,
                },
            }
            app_config_path.parent.mkdir(parents=True, exist_ok=True)
            app_config_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

            for key in [
                "MLA_THINKING_ENABLED",
                "MLA_THINKING_STEPS",
                "MLA_NO_TOOL_RETRY_LIMIT",
                "MLA_MAX_TURNS",
                "MLA_USER_HISTORY_COMPRESS_THRESHOLD_TOKENS",
                "MLA_USER_HISTORY_RECENT_ITEMS",
            ]:
                os.environ.pop(key, None)

            runtime = get_runtime_settings()
            context = get_context_settings()

            self.assertFalse(runtime["thinking_enabled"])
            self.assertEqual(runtime["thinking_steps"], 12)
            self.assertEqual(runtime["no_tool_retry_limit"], 9)
            self.assertEqual(runtime["max_turns"], 321)
            self.assertEqual(context["user_history_recent_items"], 11)
            self.assertEqual(context["user_history_compress_threshold_tokens"], 1700)

    def test_sdk_build_launch_config_includes_visible_skills_and_reasoning_fields(self):
        root = (self.base / "sdk_reasoning_root").resolve()
        agent = infiagent(
            user_data_root=str(root),
            thinking_enabled=False,
            thinking_steps=8,
            no_tool_retry_limit=6,
            user_history_recent_items=5,
            visible_skills=["skill_a", "skill_b"],
        )

        launch_config = agent._build_launch_config()
        self.assertFalse(launch_config["thinking_enabled"])
        self.assertEqual(launch_config["thinking_steps"], 8)
        self.assertEqual(launch_config["no_tool_retry_limit"], 6)
        self.assertEqual(launch_config["user_history_recent_items"], 5)
        self.assertEqual(launch_config["visible_skills"], ["skill_a", "skill_b"])

    def test_run_explicit_reasoning_overrides_take_priority(self):
        root = (self.base / "run_override_root").resolve()
        task_id = str((self.base / "run_override_task").resolve())
        captured = {}

        class DummyManager:
            def _load_context(self):
                return {"current": {}, "history": []}

            def _save_context(self, _context):
                return None

            def _save_stack(self, _stack):
                return None

            def start_new_instruction(self, _instruction):
                return "instruction_demo"

        class DummyLoader:
            def __init__(self, _system):
                self.agent_system_name = "OpenCowork"

            def get_tool_config(self, _agent_name):
                return {"type": "llm_call_agent", "available_tools": []}

        class DummyExecutor:
            def __init__(self, **kwargs):
                captured["runtime"] = get_runtime_settings()
                captured["context"] = get_context_settings()
                captured["agent_name"] = kwargs.get("agent_name")

            def run(self, _task_id, _user_input):
                return {"status": "success", "output": "ok"}

        agent = infiagent(
            user_data_root=str(root),
            thinking_enabled=True,
            thinking_steps=30,
            no_tool_retry_limit=7,
            user_history_recent_items=0,
        )

        with patch("infiagent.sdk.is_task_running", return_value=False), \
             patch("infiagent.sdk.clean_before_start", return_value=None), \
             patch("infiagent.sdk.ConfigLoader", DummyLoader), \
             patch("infiagent.sdk.get_hierarchy_manager", return_value=DummyManager()), \
             patch("infiagent.sdk.AgentExecutor", DummyExecutor):
            result = agent.run(
                "override demo",
                task_id=task_id,
                thinking_enabled=False,
                thinking_steps=4,
                no_tool_retry_limit=9,
                user_history_recent_items=2,
            )

        self.assertEqual(result["status"], "success")
        self.assertEqual(captured["agent_name"], "alpha_agent")
        self.assertFalse(captured["runtime"]["thinking_enabled"])
        self.assertEqual(captured["runtime"]["thinking_steps"], 4)
        self.assertEqual(captured["runtime"]["no_tool_retry_limit"], 9)
        self.assertEqual(captured["context"]["user_history_recent_items"], 2)

    def test_sdk_instances_do_not_leak_user_data_roots(self):
        root_a = (self.base / "root_a").resolve()
        root_b = (self.base / "root_b").resolve()
        task_a = str((self.base / "task_a").resolve())
        task_b = str((self.base / "task_b").resolve())

        agent_a = infiagent(user_data_root=str(root_a))
        agent_b = infiagent(user_data_root=str(root_b))

        result_a = agent_a.add_message("message for a", task_id=task_a)
        result_b = agent_b.add_message("message for b", task_id=task_b)

        self.assertTrue(result_a["share_context_path"].startswith(str(root_a / "conversations")))
        self.assertTrue(result_b["share_context_path"].startswith(str(root_b / "conversations")))

        list_a = agent_a.list_task_ids()
        list_b = agent_b.list_task_ids()

        self.assertTrue(any(item["task_id"] == task_a for item in list_a["tasks"]))
        self.assertFalse(any(item["task_id"] == task_b for item in list_a["tasks"]))
        self.assertTrue(any(item["task_id"] == task_b for item in list_b["tasks"]))
        self.assertFalse(any(item["task_id"] == task_a for item in list_b["tasks"]))

    def test_run_returns_busy_when_task_already_running(self):
        root = (self.base / "busy_root").resolve()
        task_id = str((self.base / "busy_task").resolve())
        agent = infiagent(user_data_root=str(root))
        with agent._runtime_scope():
            register_running_task(task_id, "alpha_agent", "hello", "OpenCowork")
            try:
                result = agent.run("new request", task_id=task_id)
            finally:
                unregister_running_task(task_id)
        self.assertEqual(result["status"], "busy")
        self.assertEqual(result["task_id"], task_id)

    def test_background_task_launch_uses_user_data_root(self):
        root = (self.base / "launch_root").resolve()
        task_id = str((self.base / "launch_task").resolve())
        llm_config = str((Path(__file__).resolve().parent / "llm_config_dummy.yaml").resolve())
        agent = infiagent(user_data_root=str(root), llm_config_path=llm_config)

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ResourceWarning)
            result = agent.start_background_task(
                task_id=task_id,
                user_input="background launch smoke test",
                force_new=True,
            )
        self.assertEqual(result["status"], "success")
        self.assertTrue(result["log_path"].startswith(str(root / "runtime" / "launched_tasks")))

        pid = result.get("pid")
        self.assertIsInstance(pid, int)
        time.sleep(0.5)
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        else:
            for _ in range(20):
                try:
                    waited_pid, _ = os.waitpid(pid, os.WNOHANG)
                except ChildProcessError:
                    break
                if waited_pid == pid:
                    break
                time.sleep(0.1)

    def test_task_snapshot_falls_back_to_history_final_output(self):
        root = (self.base / "history_root").resolve()
        task_id = str((self.base / "history_task").resolve())
        agent = infiagent(user_data_root=str(root))

        with agent._runtime_scope():
            manager = get_hierarchy_manager(task_id)
            context = manager._load_context()
            context["history"] = [{
                "instructions": [],
                "hierarchy": {"worker_agent_demo": {"parent": None, "children": [], "level": 0}},
                "agents_status": {
                    "worker_agent_demo": {
                        "agent_name": "worker_agent",
                        "status": "completed",
                        "thinking_updated_at": "2026-03-10T10:00:00+08:00",
                        "latest_thinking": "done thinking",
                        "final_output": "done output",
                        "end_time": "2026-03-10T10:05:00+08:00",
                    }
                },
                "start_time": "2026-03-10T10:00:00+08:00",
                "completion_time": "2026-03-10T10:05:00+08:00",
            }]
            context["current"] = {
                "instructions": [],
                "hierarchy": {},
                "agents_status": {},
                "start_time": "2026-03-10T10:06:00+08:00",
                "last_updated": "2026-03-10T10:06:00+08:00",
            }
            manager._save_context(context)

        snapshot = agent.task_snapshot(task_id=task_id)
        self.assertEqual(snapshot["status"], "success")
        self.assertEqual(snapshot["last_final_output"], "done output")
        self.assertEqual(snapshot["last_final_output_at"], "2026-03-10T10:05:00+08:00")
        self.assertEqual(snapshot["latest_thinking"], "done thinking")

    def test_tool_hooks_are_exposed_in_launch_config(self):
        callback = str((self.base / "hook.py").resolve()) + ":on_tool_event"
        hooks = [{
            "name": "demo",
            "when": "after",
            "tool_names": ["final_output"],
            "callback": callback,
            "result_filters": {"status": "success"},
        }]
        agent = infiagent(user_data_root=str((self.base / "hook_root").resolve()), tool_hooks=hooks)
        launch_config = agent._build_launch_config()
        self.assertEqual(launch_config["tool_hooks"], hooks)

    def test_context_hooks_are_exposed_in_launch_config(self):
        callback = str((self.base / "ctx_hook.py").resolve()) + ":on_context"
        hooks = [{
            "name": "ctx-demo",
            "when": "after_build",
            "callback": callback,
        }]
        agent = infiagent(user_data_root=str((self.base / "ctx_hook_root").resolve()), context_hooks=hooks)
        launch_config = agent._build_launch_config()
        self.assertEqual(launch_config["context_hooks"], hooks)
        self.assertTrue(launch_config["seed_builtin_resources"])

    def test_max_turns_is_exposed_in_launch_config(self):
        agent = infiagent(
            user_data_root=str((self.base / "max_turns_root").resolve()),
            max_turns=321,
        )
        launch_config = agent._build_launch_config()
        self.assertEqual(launch_config["max_turns"], 321)
        runtime = agent.describe_runtime()
        self.assertEqual(runtime["max_turns"], 321)

    def test_add_message_resume_if_needed_uses_resume_when_stack_exists(self):
        root = (self.base / "resume_root").resolve()
        task_id = str((self.base / "resume_task").resolve())

        with runtime_env_scope({"MLA_USER_DATA_ROOT": str(root)}):
            manager = get_hierarchy_manager(task_id)
            manager.set_runtime_metadata(
                agent_system="OpenCowork",
                agent_name="alpha_agent",
                user_input="previous input",
            )
            manager._save_stack([{
                "agent_id": "alpha_agent_demo",
                "agent_name": "alpha_agent",
                "parent_id": None,
                "level": 0,
                "user_input": "previous input",
                "start_time": "2026-03-25T10:00:00+08:00",
            }])

            with patch("utils.task_runtime.resume_task_with_fresh", return_value=(True, "resumed")) as resume_mock:
                with patch("utils.task_runtime.launch_task_process") as launch_mock:
                    ok, payload = append_task_message(
                        task_id=task_id,
                        message="resume me",
                        source="user",
                        resume_if_needed=True,
                        fallback_agent_system="OpenCowork",
                    )

        self.assertTrue(ok)
        self.assertTrue(payload["resumed"])
        self.assertFalse(payload["launched"])
        resume_mock.assert_called_once()
        launch_mock.assert_not_called()

    def test_add_message_resume_if_needed_launches_new_task_when_stack_empty(self):
        root = (self.base / "launch_after_add_root").resolve()
        task_id = str((self.base / "launch_after_add_task").resolve())

        with runtime_env_scope({"MLA_USER_DATA_ROOT": str(root), "MLA_MAX_TURNS": "77"}):
            manager = get_hierarchy_manager(task_id)
            manager.set_runtime_metadata(
                agent_system="OpenCowork",
                agent_name="alpha_agent",
                user_input="previous input",
            )
            manager._save_stack([])

            with patch("utils.task_runtime.launch_task_process", return_value=(True, {
                "message": f"已在后台启动任务: {task_id}",
                "task_id": task_id,
                "pid": 4321,
                "log_path": str(root / "runtime" / "launched_tasks" / "demo.log"),
                "agent_system": "OpenCowork",
                "agent_name": "alpha_agent",
            })) as launch_mock:
                ok, payload = append_task_message(
                    task_id=task_id,
                    message="please continue",
                    source="user",
                    resume_if_needed=True,
                    fallback_agent_system="OpenCowork",
                    env_overrides={"MLA_USER_DATA_ROOT": str(root), "MLA_MAX_TURNS": "77"},
                )

        self.assertTrue(ok)
        self.assertFalse(payload["resumed"])
        self.assertTrue(payload["launched"])
        launch_mock.assert_called_once()
        kwargs = launch_mock.call_args.kwargs
        self.assertEqual(kwargs["task_id"], task_id)
        self.assertEqual(kwargs["user_input"], "please continue")
        self.assertEqual(kwargs["agent_system"], "OpenCowork")
        self.assertEqual(kwargs["agent_name"], "alpha_agent")
        self.assertEqual(kwargs["config"]["user_data_root"], str(root))
        self.assertEqual(kwargs["config"]["max_turns"], 77)


if __name__ == "__main__":
    unittest.main()
