# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

VERSION = '0.0.5'

setup(
    name="easyWechatpy",  # package name
    version=VERSION,  # package version
    author="Lei Cui",
    author_email="cuilei798@qq.com",
    maintainer="Lei Cui",
    maintainer_email="cuilei798@qq.com",
    license="MIT License",
    platforms=["linux"],
    url="https://github.com/xleizi/easyWechatpy",
    description="微信 iLink Bot API 客户端 —— 扫码登录、收发消息、桥接 Agent。",
    long_description=open("README.md").read(),
    packages=find_packages(),
    zip_safe=False,
    entry_points={
        "console_scripts": [
            "easywechatpy-ilink=easyWechatpy.ilink.cli:main",
        ],
    },
    install_requires=[
        "requests",
        "qrcode",
    ],
    package_data={"Utils": ["Utils/*"]},
    classifiers=[
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
    python_requires=">=3",
)
