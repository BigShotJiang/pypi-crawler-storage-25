# -*- coding: utf-8 -*-
"""
微信 iLink 状态管理：保存/加载 bot_token、游标、用户信息。
状态目录: ~/.easywechat/
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

DEFAULT_BASE_URL = "https://ilinkai.weixin.qq.com"
DEFAULT_BOT_TYPE = "3"


def resolve_state_dir(env_name: str = "EASYWECHAT_STATE_DIR") -> Path:
    env = os.environ.get(env_name)
    if env:
        return Path(env).resolve()
    return Path.home() / ".easywechat"


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class PendingLogin:
    qrcode: str = ""
    qrcode_url: str = ""
    bot_type: str = DEFAULT_BOT_TYPE
    started_at: str = ""
    refresh_count: int = 0


@dataclass
class WechatState:
    """微信 iLink 账号状态（单账号，JSON 文件持久化）。"""
    token: str = ""
    account_id: str = ""
    user_id: str = ""
    base_url: str = DEFAULT_BASE_URL
    route_tag: str = ""
    pending_login: PendingLogin | None = None
    updated_at: str = ""

    def to_dict(self) -> dict:
        return {
            "token": self.token,
            "account_id": self.account_id,
            "user_id": self.user_id,
            "base_url": self.base_url,
            "route_tag": self.route_tag,
            "pending_login": {
                "qrcode": self.pending_login.qrcode,
                "qrcode_url": self.pending_login.qrcode_url,
                "bot_type": self.pending_login.bot_type,
                "started_at": self.pending_login.started_at,
                "refresh_count": self.pending_login.refresh_count,
            } if self.pending_login else None,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "WechatState":
        pending = d.get("pending_login")
        return cls(
            token=d.get("token", ""),
            account_id=d.get("account_id", ""),
            user_id=d.get("user_id", ""),
            base_url=d.get("base_url", DEFAULT_BASE_URL),
            route_tag=d.get("route_tag", ""),
            pending_login=PendingLogin(**pending) if pending else None,
            updated_at=d.get("updated_at", ""),
        )


class StateStore:
    """管理 easywechatpy 的持久化状态。"""

    def __init__(self, state_dir: Path | str | None = None) -> None:
        self._dir = Path(state_dir).resolve() if state_dir else resolve_state_dir()

    @property
    def dir(self) -> Path:
        self._dir.mkdir(parents=True, exist_ok=True)
        return self._dir

    @property
    def account_file(self) -> Path:
        return self.dir / "account.json"

    @property
    def cursor_file(self) -> Path:
        return self.dir / "cursor.txt"

    # ---- account ----

    def load_account(self) -> WechatState:
        try:
            if not self.account_file.exists():
                return WechatState()
            raw = self.account_file.read_text("utf-8")
            return WechatState.from_dict(json.loads(raw))
        except Exception:
            return WechatState()

    def save_account(self, state: WechatState) -> None:
        state.updated_at = utc_now_iso()
        payload = state.to_dict()
        self.account_file.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), "utf-8"
        )
        try:
            os.chmod(self.account_file, 0o600)
        except Exception:
            pass

    # ---- cursor ----

    def load_cursor(self) -> str:
        try:
            if not self.cursor_file.exists():
                return ""
            return self.cursor_file.read_text("utf-8").strip()
        except Exception:
            return ""

    def save_cursor(self, cursor: str) -> None:
        self.cursor_file.write_text(cursor.strip(), "utf-8")

    def clear_cursor(self) -> None:
        try:
            if self.cursor_file.exists():
                self.cursor_file.unlink()
        except Exception:
            pass
