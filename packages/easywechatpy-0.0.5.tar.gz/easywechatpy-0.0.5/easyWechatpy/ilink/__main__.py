"""允许通过 python -m easywechatpy.ilink 运行 CLI。"""
from .cli import main

main()
