# -*- coding: utf-8 -*-
"""
微信 iLink Bot API 客户端 —— 纯 HTTP/JSON 协议实现。
参考: @tencent-weixin/openclaw-weixin (官方插件) 及 wechat-claw-cli (社区实现)。

核心流程:
  1. login      → get_bot_qrcode → 轮询 get_qrcode_status → 拿到 bot_token
  2. poll       → getupdates 长轮询，游标 get_updates_buf 循环
  3. send-text  → sendmessage，必须带回 context_token
"""

from __future__ import annotations

import json
import os
import secrets
import time
from base64 import b64encode
from dataclasses import dataclass
from typing import Any

import requests

from .state import WechatState, StateStore

# ---- 版本 ----
__version__ = "0.0.5"

# ---- 常量 ----
SESSION_TIMEOUT_ERRCODE = -14
DEFAULT_API_TIMEOUT = 15
DEFAULT_LONGPOLL_TIMEOUT = 35


def normalize_base_url(url: str) -> str:
    s = url.strip()
    return s if s.endswith("/") else f"{s}/"


def random_wechat_uin() -> str:
    raw = str(secrets.randbits(32)).encode("utf-8")
    return b64encode(raw).decode("ascii")


def build_base_info() -> dict:
    return {"channel_version": __version__}


# ---- 异常 ----

class ApiError(Exception):
    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        ret: int | None = None,
        errcode: int | None = None,
        payload: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.ret = ret
        self.errcode = errcode
        self.payload = payload


# ---- 核心 API ----

class WechatILinkAPI:
    """微信 iLink Bot API 客户端。

    用法:
        api = WechatILinkAPI(base_url="https://ilinkai.weixin.qq.com", token="...")
        # 或从本地状态恢复
        store = StateStore()
        state = store.load_account()
        api = WechatILinkAPI(base_url=state.base_url, token=state.token)
    """

    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        route_tag: str | None = None,
    ) -> None:
        self.base_url = normalize_base_url(base_url)
        self.token = token
        self.route_tag = route_tag
        self._session = requests.Session()

    # -- 内部工具 --

    def _url(self, endpoint: str, params: dict | None = None) -> str:
        url = self.base_url.rstrip("/") + "/" + endpoint.lstrip("/")
        if params:
            from urllib.parse import urlencode
            qs = urlencode({k: v for k, v in params.items() if v is not None})
            if qs:
                url = f"{url}?{qs}"
        return url

    def _headers(self, body_bytes: bytes | None = None) -> dict:
        h = {
            "Accept": "application/json",
            "X-WECHAT-UIN": random_wechat_uin(),
        }
        if body_bytes is not None:
            h["Content-Type"] = "application/json"
            h["AuthorizationType"] = "ilink_bot_token"
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        if self.route_tag:
            h["SKRouteTag"] = self.route_tag
        return h

    @staticmethod
    def _parse_json(raw: bytes, endpoint: str) -> dict:
        text = raw.decode("utf-8").strip()
        if not text:
            return {}
        try:
            obj = json.loads(text)
        except json.JSONDecodeError as e:
            raise ApiError(f"{endpoint} 返回非 JSON: {e}")
        if not isinstance(obj, dict):
            raise ApiError(f"{endpoint} 返回格式异常")
        return obj

    @staticmethod
    def _coerce_int(v: Any) -> int | None:
        return v if isinstance(v, int) else None

    def _raise_on_error(self, endpoint: str, payload: dict) -> None:
        ret = self._coerce_int(payload.get("ret"))
        errcode = self._coerce_int(payload.get("errcode"))
        if ret and ret != 0:
            raise ApiError(f"{endpoint} ret={ret}", ret=ret, errcode=errcode, payload=payload)
        if errcode and errcode != 0:
            raise ApiError(f"{endpoint} errcode={errcode}", ret=ret, errcode=errcode, payload=payload)

    def _request(
        self,
        method: str,
        endpoint: str,
        params: dict | None = None,
        body: dict | None = None,
        timeout: int = DEFAULT_API_TIMEOUT,
    ) -> dict:
        body_bytes = json.dumps(body, ensure_ascii=False).encode("utf-8") if body else None
        url = self._url(endpoint, params)
        headers = self._headers(body_bytes)

        try:
            resp = self._session.request(
                method=method.upper(),
                url=url,
                data=body_bytes,
                headers=headers,
                timeout=max(1, timeout),
            )
        except requests.Timeout:
            raise
        except requests.ConnectionError as e:
            raise ApiError(f"{endpoint} 网络错误: {e}")

        try:
            payload = self._parse_json(resp.content, endpoint)
        except Exception:
            payload = {}

        if not resp.ok:
            raise ApiError(
                f"{endpoint} HTTP {resp.status_code}",
                status_code=resp.status_code,
                payload=payload,
            )

        return payload

    # === 登录 ===

    def get_bot_qrcode(self, bot_type: str = "3") -> dict:
        """获取登录二维码。

        Returns: {"qrcode": "...", "qrcode_img_content": "https://..."}
        """
        payload = self._request(
            "GET",
            "ilink/bot/get_bot_qrcode",
            params={"bot_type": bot_type},
            timeout=DEFAULT_API_TIMEOUT,
        )
        self._raise_on_error("get_bot_qrcode", payload)
        return payload

    def get_qrcode_status(self, qrcode: str, timeout: int = DEFAULT_LONGPOLL_TIMEOUT) -> dict:
        """长轮询扫码状态。

        Returns: {"status": "wait|scaned|confirmed|expired|need_verifycode|...", "bot_token": "...", ...}
        """
        try:
            payload = self._request(
                "GET",
                "ilink/bot/get_qrcode_status",
                params={"qrcode": qrcode},
                timeout=timeout + 5,
            )
        except (requests.Timeout, requests.exceptions.ReadTimeout):
            return {"status": "wait"}
        self._raise_on_error("get_qrcode_status", payload)
        return payload

    # === 消息 ===

    def get_updates(self, get_updates_buf: str = "", timeout: int = DEFAULT_LONGPOLL_TIMEOUT) -> dict:
        """长轮询拉取新消息。

        Returns: {"ret": 0, "msgs": [...], "get_updates_buf": "..."}
        """
        try:
            payload = self._request(
                "POST",
                "ilink/bot/getupdates",
                body={
                    "get_updates_buf": get_updates_buf,
                    "base_info": build_base_info(),
                },
                timeout=timeout + 5,
            )
        except (requests.Timeout, requests.exceptions.ReadTimeout):
            return {"ret": 0, "msgs": [], "get_updates_buf": get_updates_buf}
        self._raise_on_error("getupdates", payload)
        return payload

    def send_text_message(
        self,
        to_user_id: str,
        text: str,
        context_token: str | None = None,
    ) -> dict:
        """发送文本消息。

        必须携带 context_token 才能正确维持对话上下文。
        """
        import uuid
        client_id = f"easywechatpy-{uuid.uuid4().hex[:12]}"
        msg: dict = {
            "from_user_id": "",
            "to_user_id": to_user_id,
            "client_id": client_id,
            "message_type": 2,   # BOT
            "message_state": 2,  # FINISH
            "item_list": [
                {"type": 1, "text_item": {"text": text}}
            ],
        }
        if context_token:
            msg["context_token"] = context_token

        body = {"msg": msg, "base_info": build_base_info()}
        payload = self._request(
            "POST",
            "ilink/bot/sendmessage",
            body=body,
            timeout=DEFAULT_API_TIMEOUT,
        )
        if payload:
            self._raise_on_error("sendmessage", payload)
        return {"client_id": client_id, "response": payload}

    def get_config(self, ilink_user_id: str, context_token: str | None = None) -> dict:
        """拉取 bot 配置（含 typing_ticket）。"""
        body: dict = {"ilink_user_id": ilink_user_id, "base_info": build_base_info()}
        if context_token:
            body["context_token"] = context_token
        payload = self._request("POST", "ilink/bot/getconfig", body=body, timeout=DEFAULT_API_TIMEOUT)
        self._raise_on_error("getconfig", payload)
        return payload

    def send_typing(self, ilink_user_id: str, typing_ticket: str, status: int = 1) -> dict:
        """发送「正在输入」状态 (status=1) 或取消 (status=2)。"""
        body = {
            "ilink_user_id": ilink_user_id,
            "typing_ticket": typing_ticket,
            "status": status,
            "base_info": build_base_info(),
        }
        payload = self._request("POST", "ilink/bot/sendtyping", body=body, timeout=DEFAULT_API_TIMEOUT)
        if payload:
            self._raise_on_error("sendtyping", payload)
        return payload
