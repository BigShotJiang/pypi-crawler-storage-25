# -*- coding: utf-8 -*-
"""
微信 iLink Bot CLI —— 命令行登录、收发消息、桥接 Agent。

用法:
  python -m easywechatpy.ilink login          # 扫码登录
  python -m easywechatpy.ilink whoami         # 查看状态
  python -m easywechatpy.ilink poll           # 长轮询收消息
  python -m easywechatpy.ilink send-text ...  # 发送文本
  python -m easywechatpy.ilink reply-text ... # 带上下文回复
  python -m easywechatpy.ilink bridge ...     # 桥接到 Agent
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from .api import (
    WechatILinkAPI,
    ApiError,
    DEFAULT_LONGPOLL_TIMEOUT,
    SESSION_TIMEOUT_ERRCODE,
)
from .state import (
    WechatState,
    PendingLogin,
    StateStore,
    DEFAULT_BASE_URL,
    DEFAULT_BOT_TYPE,
)


# ---- 环境变量 ----

def _env_route_tag() -> str | None:
    return (os.environ.get("EASYWECHAT_ROUTE_TAG") or "").strip() or None


# ---- 工具 ----

def _print_qr_terminal(content: str) -> None:
    """在终端打印二维码，用 ██/空格 双字符保证对齐。"""
    try:
        import qrcode  # type: ignore

        qr = qrcode.QRCode(border=2)
        qr.add_data(content)
        qr.make(fit=True)

        modules = qr.get_matrix()
        print("请用微信扫描以下二维码：")
        print()
        for row in modules:
            line = "".join("██" if cell else "  " for cell in row)
            print(line)
        print()
        return

    except ImportError:
        pass
    print(f"扫码链接: {content}")


def _build_api_from_state(store: StateStore) -> WechatILinkAPI:
    state = store.load_account()
    if not state.token:
        raise ValueError("未登录，请先运行 login")
    return WechatILinkAPI(
        base_url=state.base_url,
        token=state.token,
        route_tag=state.route_tag or _env_route_tag(),
    )


def _resolve_user_id(explicit: str | None, state: WechatState) -> str:
    uid = (explicit or state.user_id or "").strip()
    if not uid:
        raise ValueError("无法确定目标用户 ID，请先登录或传入 --to-user-id")
    return uid


def _extract_text(message: dict) -> str:
    items = message.get("item_list") or []
    parts = []
    for item in items:
        if not isinstance(item, dict):
            continue
        if item.get("type") == 1:
            text = str((item.get("text_item") or {}).get("text") or "").strip()
            if text:
                parts.append(text)
    return "\n".join(parts)


# ---- 命令实现 ----

def cmd_login(args: argparse.Namespace) -> int:
    store = StateStore(args.state_dir)
    state = store.load_account()

    base_url = (args.base_url or state.base_url or DEFAULT_BASE_URL).strip()
    route_tag = (args.route_tag or state.route_tag or _env_route_tag() or "").strip() or None
    api = WechatILinkAPI(base_url=base_url, route_tag=route_tag)

    # 1. 获取二维码
    resp = api.get_bot_qrcode(bot_type=args.bot_type)
    qrcode = str(resp.get("qrcode") or "").strip()
    qrcode_url = str(resp.get("qrcode_img_content") or "").strip()
    if not qrcode or not qrcode_url:
        print("获取二维码失败：返回缺少字段", file=sys.stderr)
        return 1

    state.base_url = base_url
    state.route_tag = route_tag
    state.pending_login = PendingLogin(
        qrcode=qrcode,
        qrcode_url=qrcode_url,
        bot_type=args.bot_type,
        started_at=datetime.now().isoformat(),
    )
    store.save_account(state)

    if not args.json:
        _print_qr_terminal(qrcode_url)
        print(f"\nqrcode: {qrcode}")
        print(f"状态目录: {store.dir}")

    # 2. 轮询等待扫码
    return _wait_login(api, store, args)


def _wait_login(api: WechatILinkAPI, store: StateStore, args: argparse.Namespace) -> int:
    state = store.load_account()
    pending = state.pending_login
    if not pending:
        print("没有待确认的二维码", file=sys.stderr)
        return 1

    deadline = time.monotonic() + max(1, args.timeout_seconds)
    scanned_printed = False

    while time.monotonic() < deadline:
        remaining = max(1, int(deadline - time.monotonic()))
        resp = api.get_qrcode_status(
            qrcode=pending.qrcode,
            timeout=min(args.request_timeout_seconds, remaining),
        )
        status = str(resp.get("status") or "").strip()

        if status == "wait":
            if args.verbose:
                sys.stderr.write(".")
                sys.stderr.flush()
            time.sleep(1)
            continue

        if status == "scaned":
            if not scanned_printed:
                print("\n已扫码，请在微信中确认...", file=sys.stderr)
                scanned_printed = True
            time.sleep(1)
            continue

        if status == "expired":
            pending.refresh_count += 1
            if pending.refresh_count > args.max_refreshes:
                print("\n二维码多次过期，请重新运行 login", file=sys.stderr)
                return 1
            print(f"\n二维码已过期，正在刷新 ({pending.refresh_count}/{args.max_refreshes})...", file=sys.stderr)
            new_resp = api.get_bot_qrcode(bot_type=pending.bot_type)
            pending.qrcode = str(new_resp.get("qrcode") or "").strip()
            pending.qrcode_url = str(new_resp.get("qrcode_img_content") or "").strip()
            pending.started_at = datetime.now().isoformat()
            state.pending_login = pending
            store.save_account(state)
            _print_qr_terminal(pending.qrcode_url)
            scanned_printed = False
            continue

        if status == "confirmed":
            bot_token = str(resp.get("bot_token") or "").strip() or None
            account_id = str(resp.get("ilink_bot_id") or "").strip() or None
            user_id = str(resp.get("ilink_user_id") or "").strip() or None
            new_base_url = str(resp.get("baseurl") or api.base_url).strip() or api.base_url

            if not bot_token or not account_id:
                print("登录确认但缺少 bot_token / ilink_bot_id", file=sys.stderr)
                return 1

            state.token = bot_token
            state.account_id = account_id
            state.user_id = user_id or state.user_id
            state.base_url = new_base_url
            state.pending_login = None
            store.save_account(state)
            store.clear_cursor()

            if args.json:
                print(json.dumps({
                    "connected": True,
                    "account_id": account_id,
                    "user_id": user_id,
                    "base_url": new_base_url,
                    "state_dir": str(store.dir),
                }, ensure_ascii=False, indent=2))
                return 0

            print("\n✅ 登录成功！")
            print(f" account_id: {account_id}")
            print(f" user_id:    {user_id}")
            print(f" base_url:   {new_base_url}")
            return 0

        # 未知状态
        print(f"\n未知状态: {status}", file=sys.stderr)
        time.sleep(1)

    print("\n等待扫码超时", file=sys.stderr)
    return 1


def cmd_whoami(args: argparse.Namespace) -> int:
    store = StateStore(args.state_dir)
    state = store.load_account()
    cursor = store.load_cursor()

    if args.json:
        print(json.dumps({
            "logged_in": bool(state.token),
            "base_url": state.base_url,
            "account_id": state.account_id,
            "user_id": state.user_id,
            "has_cursor": bool(cursor),
        }, ensure_ascii=False, indent=2))
        return 0

    print(f"状态目录:    {store.dir}")
    print(f"已登录:      {'是' if state.token else '否'}")
    print(f"base_url:    {state.base_url}")
    print(f"account_id:  {state.account_id or '-'}")
    print(f"user_id:     {state.user_id or '-'}")
    print(f"route_tag:   {state.route_tag or '-'}")
    print(f"已存游标:    {'是' if cursor else '否'}")
    return 0


def cmd_poll(args: argparse.Namespace) -> int:
    store = StateStore(args.state_dir)
    api = _build_api_from_state(store)

    if args.clear_cursor:
        store.clear_cursor()

    cursor = store.load_cursor()

    try:
        while True:
            resp = api.get_updates(
                get_updates_buf=cursor,
                timeout=args.timeout_seconds,
            )
            next_cursor = str(resp.get("get_updates_buf") or "").strip()
            if next_cursor:
                store.save_cursor(next_cursor)
                cursor = next_cursor

            msgs = resp.get("msgs") or []
            if not msgs and args.once:
                print("暂无新消息")

            for msg in msgs:
                if not isinstance(msg, dict):
                    continue
                _print_message(msg, fmt=args.format)

            if args.once:
                return 0

    except KeyboardInterrupt:
        print("\n已停止轮询", file=sys.stderr)
        return 130


def _print_message(msg: dict, fmt: str = "summary") -> None:
    if fmt == "message-json":
        print(json.dumps(msg, ensure_ascii=False, indent=2))
        return

    ts = msg.get("create_time_ms")
    if isinstance(ts, int):
        created = datetime.fromtimestamp(ts / 1000).strftime("%Y-%m-%d %H:%M:%S")
    else:
        created = "-"

    print(f"[{created}] from: {msg.get('from_user_id', '-')}")
    print(f"  message_state: {msg.get('message_state')}")
    print(f"  context_token: {msg.get('context_token', '-')}")

    text = _extract_text(msg)
    if text:
        print(f"  内容: {text}")
    else:
        # 检查附件类型
        for item in (msg.get("item_list") or []):
            t = item.get("type")
            if t == 2: print("  [图片]")
            elif t == 3: print("  [语音]")
            elif t == 4: print("  [文件]")
            elif t == 5: print("  [视频]")
    print("-" * 40)


def cmd_send_text(args: argparse.Namespace) -> int:
    store = StateStore(args.state_dir)
    state = store.load_account()
    api = _build_api_from_state(store)

    to_user = _resolve_user_id(args.to_user_id, state)
    text = _read_text(args)

    resp = api.send_text_message(
        to_user_id=to_user,
        text=text,
        context_token=args.context_token or None,
    )

    if args.json:
        print(json.dumps({"ok": True, "to_user_id": to_user, "client_id": resp["client_id"]}, ensure_ascii=False))
        return 0

    print(f"发送成功 → {to_user}")
    print(f"client_id: {resp['client_id']}")
    return 0


def cmd_reply_text(args: argparse.Namespace) -> int:
    if not args.context_token:
        print("reply-text 必须传 --context-token", file=sys.stderr)
        return 1
    return cmd_send_text(args)


def _read_text(args: argparse.Namespace) -> str:
    if args.stdin:
        return sys.stdin.read()
    if args.text_file:
        return Path(args.text_file).read_text("utf-8")
    text = (args.text or "").strip()
    if not text:
        raise ValueError("文本为空，请传 --text / --stdin / --text-file")
    return text


def cmd_get_config(args: argparse.Namespace) -> int:
    store = StateStore(args.state_dir)
    state = store.load_account()
    api = _build_api_from_state(store)

    uid = _resolve_user_id(args.ilink_user_id, state)
    resp = api.get_config(ilink_user_id=uid, context_token=args.context_token or None)

    if args.json:
        print(json.dumps(resp, ensure_ascii=False, indent=2))
        return 0

    print(f"typing_ticket: {resp.get('typing_ticket', '-')}")
    return 0


def cmd_send_typing(args: argparse.Namespace) -> int:
    store = StateStore(args.state_dir)
    state = store.load_account()
    api = _build_api_from_state(store)

    uid = _resolve_user_id(args.ilink_user_id, state)
    ticket = (args.typing_ticket or "").strip()
    if not ticket and args.fetch_ticket:
        config = api.get_config(ilink_user_id=uid, context_token=args.context_token or None)
        ticket = str(config.get("typing_ticket") or "").strip()
    if not ticket:
        print("需要 --typing-ticket 或 --fetch-ticket", file=sys.stderr)
        return 1

    status_val = 1 if args.status == "typing" else 2
    api.send_typing(ilink_user_id=uid, typing_ticket=ticket, status=status_val)

    if args.json:
        print(json.dumps({"ok": True, "status": args.status}))
        return 0
    print(f"typing 状态已发送: {args.status}")
    return 0


# ---- 桥接 ----

def cmd_bridge(args: argparse.Namespace) -> int:
    """将微信消息桥接到一个外部命令（如 Claude Code、自定义脚本）。"""
    store = StateStore(args.state_dir)
    state = store.load_account()
    api = _build_api_from_state(store)
    to_user = _resolve_user_id(None, state)

    if args.clear_cursor:
        store.clear_cursor()

    cursor = store.load_cursor()

    print(f"[bridge] 监听中... 命令: {args.cmd}", file=sys.stderr)

    try:
        while True:
            resp = api.get_updates(get_updates_buf=cursor, timeout=args.timeout_seconds)
            next_cursor = str(resp.get("get_updates_buf") or "").strip()
            if next_cursor:
                store.save_cursor(next_cursor)
                cursor = next_cursor

            for msg in (resp.get("msgs") or []):
                if not isinstance(msg, dict):
                    continue
                # 只处理用户文本消息
                if msg.get("message_type") != 1 or msg.get("message_state") != 2:
                    continue

                from_user = str(msg.get("from_user_id") or "").strip()
                ctx_token = str(msg.get("context_token") or "").strip()
                text = _extract_text(msg)

                if not from_user or not ctx_token or not text:
                    continue

                print(f"\n[{datetime.now().strftime('%H:%M:%S')}] {from_user}: {text[:100]}{'...' if len(text) > 100 else ''}")

                # 调用外部命令
                reply = _run_bridge_command(args.cmd, text, from_user)
                if reply:
                    api.send_text_message(to_user_id=from_user, text=reply, context_token=ctx_token)

    except KeyboardInterrupt:
        print("\n[bridge] 已停止", file=sys.stderr)
        return 130


def _run_bridge_command(cmd: str, text: str, user_id: str) -> str | None:
    """执行桥接命令，通过 stdin 传入消息文本，stdout 读取回复。"""
    import subprocess
    try:
        result = subprocess.run(
            cmd,
            input=text,
            capture_output=True,
            text=True,
            timeout=300,
            shell=True,
            env={**os.environ, "EASYWECHAT_FROM_USER": user_id},
        )
        if result.returncode != 0:
            err = result.stderr.strip()
            return f"命令执行失败: {err}" if err else f"命令返回码: {result.returncode}"
        return result.stdout.strip() or None
    except subprocess.TimeoutExpired:
        return "处理超时"
    except FileNotFoundError:
        return f"命令不存在: {cmd}"
    except Exception as e:
        return f"执行异常: {e}"


# ---- CLI 构建 ----

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m easywechatpy.ilink",
        description="微信 iLink Bot 命令行工具",
    )
    parser.add_argument("--state-dir", default=None, help="状态目录 (默认 ~/.easywechat/)")

    sub = parser.add_subparsers(dest="command")

    # login
    p = sub.add_parser("login", help="扫码登录微信 Bot")
    p.add_argument("--base-url", default=None, help=f"API 地址 (默认 {DEFAULT_BASE_URL})")
    p.add_argument("--route-tag", default=None, help="SKRouteTag")
    p.add_argument("--bot-type", default=DEFAULT_BOT_TYPE, help=f"bot_type (默认 {DEFAULT_BOT_TYPE})")
    p.add_argument("--timeout-seconds", type=int, default=480, help="等待扫码总秒数")
    p.add_argument("--request-timeout-seconds", type=int, default=DEFAULT_LONGPOLL_TIMEOUT, help="单次轮询秒数")
    p.add_argument("--max-refreshes", type=int, default=3, help="二维码过期后最多刷新次数")
    p.add_argument("--json", action="store_true", help="JSON 输出")
    p.add_argument("--verbose", action="store_true", help="详细输出")
    p.set_defaults(func=cmd_login)

    # whoami
    p = sub.add_parser("whoami", help="查看当前登录状态")
    p.add_argument("--json", action="store_true", help="JSON 输出")
    p.set_defaults(func=cmd_whoami)

    # poll
    p = sub.add_parser("poll", help="长轮询接收消息")
    p.add_argument("--once", action="store_true", help="只拉取一次")
    p.add_argument("--timeout-seconds", type=int, default=DEFAULT_LONGPOLL_TIMEOUT, help="单次长轮询秒数")
    p.add_argument("--format", choices=("summary", "message-json"), default="summary", help="输出格式")
    p.add_argument("--clear-cursor", action="store_true", help="清空游标")
    p.set_defaults(func=cmd_poll)

    # send-text
    p = sub.add_parser("send-text", help="发送文本消息")
    p.add_argument("--to-user-id", default=None, help="目标用户 ID")
    p.add_argument("--text", default=None, help="消息文本")
    p.add_argument("--text-file", default=None, help="从文件读取文本")
    p.add_argument("--stdin", action="store_true", help="从标准输入读取")
    p.add_argument("--context-token", default=None, help="上下文 token（非回复可省略）")
    p.add_argument("--json", action="store_true", help="JSON 输出")
    p.set_defaults(func=cmd_send_text)

    # reply-text
    p = sub.add_parser("reply-text", help="带上下文 token 回复消息")
    p.add_argument("--to-user-id", default=None, help="目标用户 ID")
    p.add_argument("--context-token", required=True, help="原消息的 context_token")
    p.add_argument("--text", default=None, help="回复文本")
    p.add_argument("--text-file", default=None, help="从文件读取文本")
    p.add_argument("--stdin", action="store_true", help="从标准输入读取")
    p.add_argument("--json", action="store_true", help="JSON 输出")
    p.set_defaults(func=cmd_reply_text)

    # get-config
    p = sub.add_parser("get-config", help="获取 bot 配置 (typing_ticket)")
    p.add_argument("--ilink-user-id", default=None, help="用户 ID")
    p.add_argument("--context-token", default=None, help="上下文 token")
    p.add_argument("--json", action="store_true", help="JSON 输出")
    p.set_defaults(func=cmd_get_config)

    # send-typing
    p = sub.add_parser("send-typing", help="发送「正在输入」状态")
    p.add_argument("--ilink-user-id", default=None, help="用户 ID")
    p.add_argument("--typing-ticket", default=None, help="直接提供 typing_ticket")
    p.add_argument("--context-token", default=None, help="配合 --fetch-ticket 使用")
    p.add_argument("--fetch-ticket", action="store_true", help="自动拉取 typing_ticket")
    p.add_argument("--status", choices=("typing", "cancel"), default="typing", help="状态")
    p.add_argument("--json", action="store_true", help="JSON 输出")
    p.set_defaults(func=cmd_send_typing)

    # bridge
    p = sub.add_parser("bridge", help="桥接微信消息到外部命令")
    p.add_argument("cmd", help="外部命令（消息通过 stdin 传入，回复从 stdout 读取）")
    p.add_argument("--timeout-seconds", type=int, default=DEFAULT_LONGPOLL_TIMEOUT, help="长轮询秒数")
    p.add_argument("--clear-cursor", action="store_true", help="启动前清空游标")
    p.set_defaults(func=cmd_bridge)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 1

    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\n已中断", file=sys.stderr)
        return 130
    except ApiError as e:
        if e.errcode == SESSION_TIMEOUT_ERRCODE:
            print("会话已过期 (errcode=-14)，请重新登录", file=sys.stderr)
            return 1
        print(f"请求失败: {e}", file=sys.stderr)
        return 1
    except (ValueError, TimeoutError) as e:
        print(f"错误: {e}", file=sys.stderr)
        return 1
