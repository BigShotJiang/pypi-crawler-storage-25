"""AuthenticatedAgent class for AuthPI IdP SDK."""

from __future__ import annotations

import time
from enum import Enum

from pydantic import BaseModel, ConfigDict, Field

from authpi_idp.scopes import has_access as check_scope_access
from authpi_idp.types import Organization, TokenSet


class PrincipalType(str, Enum):
    """Principal types identifying how the caller authenticated."""

    USER = "user"
    PERSONAL_TOKEN = "personal_token"
    API_KEY = "api_key"
    AGENT = "agent"


# Backwards compatibility alias
AgentType = PrincipalType


class AuthenticatedAgent(BaseModel):
    """
    Pure data object representing an authenticated entity.
    No network operations - all authorization checks are local.
    """

    model_config = ConfigDict(frozen=True)

    id: str = Field(description="Subject ID (usr_xxx, tok_xxx, key_xxx, or agt_xxx)")
    type: PrincipalType = Field(description="Principal type")
    email: str | None = Field(default=None, description="Email from ID token (if available)")
    email_verified: bool | None = Field(default=None, description="Whether email is verified")
    tokens: TokenSet = Field(description="Tokens for storage")
    organizations: list[Organization] = Field(default_factory=list, description="Organizations from ID token")

    @property
    def expires_at(self) -> int:
        """Unix timestamp when the access token expires."""
        return self.tokens.expires_at

    @property
    def expires_in(self) -> int:
        """Seconds until the access token expires (negative if already expired)."""
        now = int(time.time())
        return self.tokens.expires_at - now

    def is_expired(self, buffer_seconds: int = 30) -> bool:
        """
        Check if tokens are expired.

        Args:
            buffer_seconds: Consider expired if within this many seconds of expiry

        Returns:
            True if expired
        """
        return self.expires_in <= buffer_seconds

    def get_scopes_for(self, org_id: str) -> list[str]:
        """
        Get scopes for a specific organization.

        Args:
            org_id: Organization ID

        Returns:
            List of scopes for the organization
        """
        for org in self.organizations:
            if org.id == org_id:
                return org.scopes
        return []

    def has_access(self, action: str, resource: str) -> bool:
        """
        Check access across all organizations.
        For agents (client_credentials), falls back to token-level scopes.

        Args:
            action: The action being performed (e.g., "read", "write")
            resource: The resource being accessed (e.g., "users", "users.verifiers")

        Returns:
            True if access is granted in any organization or via token scopes
        """
        # Check organization scopes (users, personal tokens, API keys)
        for org in self.organizations:
            if check_scope_access(org.scopes, action, resource):
                return True
        # Fallback: check token-level scopes (agents via client_credentials)
        if not self.organizations and self.tokens.scope:
            token_scopes = [s for s in self.tokens.scope.split(" ") if s]
            return check_scope_access(token_scopes, action, resource)
        return False

    def has_access_in(self, org_id: str, action: str, resource: str) -> bool:
        """
        Check access in a specific organization.

        Args:
            org_id: Organization ID
            action: The action being performed (e.g., "read", "write")
            resource: The resource being accessed (e.g., "users", "users.verifiers")

        Returns:
            True if access is granted in the specified organization
        """
        scopes = self.get_scopes_for(org_id)
        return check_scope_access(scopes, action, resource)

    def is_owner_of(self, org_id: str) -> bool:
        """
        Check if user is owner of organization.

        Args:
            org_id: Organization ID

        Returns:
            True if user has "owner" scope in the organization
        """
        scopes = self.get_scopes_for(org_id)
        return "owner" in scopes

    def is_admin_of(self, org_id: str) -> bool:
        """
        Check if user is admin of organization.

        Args:
            org_id: Organization ID

        Returns:
            True if user has "admin" scope in the organization
        """
        scopes = self.get_scopes_for(org_id)
        return "admin" in scopes

    def is_member_of(self, org_id: str) -> bool:
        """
        Check if user is member of organization.

        Args:
            org_id: Organization ID

        Returns:
            True if user has any membership in the organization
        """
        return any(org.id == org_id for org in self.organizations)
