"""Type definitions for AuthPI IdP SDK."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class AuthorizationUrl(BaseModel):
    """Result of creating an authorization URL."""

    model_config = ConfigDict(frozen=True)

    url: str = Field(description="Full authorization URL to redirect to")
    code_verifier: str = Field(description="PKCE code verifier (store securely)")
    state: str = Field(description="State value (verify on callback)")
    nonce: str = Field(description="Nonce value (verify against ID token nonce claim)")


class TokenSet(BaseModel):
    """Token set returned from token endpoint."""

    model_config = ConfigDict(frozen=True)

    access_token: str = Field(description="Access token (OPAQUE - do not parse)")
    token_type: str = Field(default="Bearer", description="Token type (always 'Bearer')")
    expires_at: int = Field(description="Unix timestamp when access token expires")
    refresh_token: str | None = Field(default=None, description="Refresh token (OPAQUE)")
    id_token: str | None = Field(default=None, description="ID token (JWT - parsed for claims)")
    scope: str | None = Field(default=None, description="Space-separated scopes")


class Organization(BaseModel):
    """Organization membership."""

    model_config = ConfigDict(frozen=True)

    id: str = Field(description="Organization ID (org_xxx)")
    title: str | None = Field(default=None, description="User's title in this org")
    scopes: list[str] = Field(default_factory=list, description="Authorization scopes")
    joined_at: int = Field(default=0, description="Unix timestamp when user joined")


class LogoutOptions(BaseModel):
    """Options for logout URL."""

    model_config = ConfigDict(frozen=True)

    id_token_hint: str | None = Field(default=None, description="ID token for logout hint")
    post_logout_redirect_uri: str | None = Field(default=None, description="Where to redirect after logout")
    state: str | None = Field(default=None, description="State for logout callback")


class UserInfo(BaseModel):
    """User info from userinfo endpoint."""

    model_config = ConfigDict(frozen=True, extra="allow")

    sub: str = Field(description="Subject identifier")
    email: str | None = Field(default=None)
    email_verified: bool | None = Field(default=None)
    name: str | None = Field(default=None)
    given_name: str | None = Field(default=None)
    family_name: str | None = Field(default=None)
    picture: str | None = Field(default=None)
    locale: str | None = Field(default=None)
    phone_number: str | None = Field(default=None)
    phone_number_verified: bool | None = Field(default=None)
    organizations: list[Organization] | None = Field(default=None, description="AuthPI extension")
    created_at: int | None = Field(default=None, description="AuthPI extension")
    updated_at: int | None = Field(default=None, description="AuthPI extension")


class TokenIntrospection(BaseModel):
    """Token introspection response."""

    model_config = ConfigDict(frozen=True)

    active: bool = Field(description="Whether token is valid")
    sub: str | None = Field(default=None, description="Subject")
    client_id: str | None = Field(default=None, description="Client that requested token")
    scope: str | None = Field(default=None, description="Token scopes")
    exp: int | None = Field(default=None, description="Expiration timestamp")
    iat: int | None = Field(default=None, description="Issued at timestamp")
    token_type: str | None = Field(default=None, description="Token type")


class ParsedScope(BaseModel):
    """Parsed scope with resource and action."""

    model_config = ConfigDict(frozen=True)

    resource: str = Field(description="Resource path (e.g., 'users', 'users.verifiers')")
    action: str = Field(description="Action (e.g., 'read', 'write', '*', '**')")


# Callback types for sync client (sync-only callbacks)
OnRefreshSync = Callable[[dict[str, Any]], None]
OnRefreshErrorSync = Callable[[Exception], None]

# Callback types for async client (support both sync and async callbacks)
OnRefreshAsync = Callable[[dict[str, Any]], None] | Callable[[dict[str, Any]], Awaitable[None]]
OnRefreshErrorAsync = Callable[[Exception], None] | Callable[[Exception], Awaitable[None]]
