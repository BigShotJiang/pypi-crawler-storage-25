"""Scope parsing and evaluation utilities for AuthPI IdP SDK."""

from __future__ import annotations

from authpi_idp.types import ParsedScope


def parse_scope(scope: str) -> ParsedScope | None:
    """
    Parse a scope string into resource and action parts.

    Args:
        scope: Scope string (e.g., "users:read", "projects:**")

    Returns:
        Parsed scope or None if invalid

    Examples:
        >>> parse_scope("users:read")
        ParsedScope(resource='users', action='read')
        >>> parse_scope("users.verifiers:write")
        ParsedScope(resource='users.verifiers', action='write')
        >>> parse_scope("invalid")
        None
    """
    if not scope:
        return None

    colon_index = scope.rfind(":")
    if colon_index == -1:
        return None

    resource = scope[:colon_index]
    action = scope[colon_index + 1 :]

    if not resource or not action:
        return None

    return ParsedScope(resource=resource, action=action)


def _scope_grants_access(parsed: ParsedScope, requested_action: str, requested_resource: str) -> bool:
    """
    Check if a scope grants access for a specific action on a resource.

    Args:
        parsed: Parsed scope
        requested_action: The action being performed (e.g., "read", "write")
        requested_resource: The resource being accessed (e.g., "users", "users.verifiers")

    Returns:
        True if access is granted
    """
    scope_resource = parsed.resource
    scope_action = parsed.action

    # Check action match
    action_matches = scope_action == requested_action or scope_action == "*" or scope_action == "**"

    if not action_matches:
        return False

    # Check resource match
    if scope_resource == "*":
        # * matches any single-level resource (no dots)
        if scope_action == "**":
            # *:** matches everything
            return True
        # *:action only matches top-level resources
        return "." not in requested_resource

    if scope_resource == requested_resource:
        # Exact match
        return True

    # Check hierarchical match for ** action
    if scope_action == "**":
        # users:** matches users, users.verifiers, users.verifiers.backup
        if requested_resource.startswith(scope_resource + "."):
            return True

    return False


def has_access(scopes: list[str], action: str, resource: str) -> bool:
    """
    Check if the given scopes grant access for an action on a resource.

    Args:
        scopes: Array of scope strings
        action: The action being performed (e.g., "read", "write")
        resource: The resource being accessed (e.g., "users", "users.verifiers")

    Returns:
        True if access is granted

    Examples:
        >>> has_access(["users:read", "projects:**"], "read", "users")
        True
        >>> has_access(["users:read", "projects:**"], "write", "projects.tasks")
        True
        >>> has_access(["users:read"], "write", "users")
        False
    """
    for scope in scopes:
        parsed = parse_scope(scope)
        if parsed is None:
            continue

        if _scope_grants_access(parsed, action, resource):
            return True

    return False
