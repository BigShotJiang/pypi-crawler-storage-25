"""Error classes for AuthPI IdP SDK."""

from __future__ import annotations


class ConfigurationError(Exception):
    """Error thrown when configuration is invalid."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class OAuthError(Exception):
    """Base error for OAuth operations."""

    def __init__(self, error: str, error_description: str | None = None) -> None:
        super().__init__(error_description or error)
        self.error = error
        self.error_description = error_description


class TokenExpiredError(OAuthError):
    """Error thrown when token is expired and cannot be refreshed."""

    def __init__(self, message: str = "Access token expired and no refresh token available") -> None:
        super().__init__("token_expired", message)


class RefreshError(OAuthError):
    """Error thrown when token refresh fails."""

    def __init__(self, error: str, error_description: str | None = None, status_code: int | None = None) -> None:
        super().__init__(error, error_description)
        self.status_code = status_code


class TokenParseError(OAuthError):
    """Error thrown when ID token cannot be parsed."""

    def __init__(self, message: str = "Failed to parse ID token") -> None:
        super().__init__("invalid_token", message)


class SubjectMismatchError(OAuthError):
    """Error thrown when subject mismatch is detected (potential security issue)."""

    def __init__(self, expected_sub: str, actual_sub: str) -> None:
        super().__init__(
            "subject_mismatch",
            f"Refreshed token subject ({actual_sub}) does not match original agent ({expected_sub})",
        )
        self.expected_sub = expected_sub
        self.actual_sub = actual_sub


class InsufficientScopeError(OAuthError):
    """Error when token lacks required scope (RFC 6750)."""

    def __init__(self, message: str = "Token lacks required scope") -> None:
        super().__init__("insufficient_scope", message)


class SessionExpiredError(OAuthError):
    """Error when server-side session has timed out."""

    def __init__(self, message: str = "Session expired") -> None:
        super().__init__("session_expired", message)


class UserBlockedError(OAuthError):
    """Error when a blocked user attempts authentication."""

    def __init__(self, message: str = "User is blocked") -> None:
        super().__init__("user_blocked", message)


class AccountLinkingRequiredError(OAuthError):
    """Error when OAuth identity needs manual linking."""

    def __init__(self, message: str = "Account linking required") -> None:
        super().__init__("account_linking_required", message)


class InteractionRequiredError(OAuthError):
    """Authorization endpoint: silent auth failed, user interaction needed."""

    def __init__(self, message: str = "User interaction required") -> None:
        super().__init__("interaction_required", message)


class LoginRequiredError(OAuthError):
    """Authorization endpoint: no active session, user must log in."""

    def __init__(self, message: str = "Login required") -> None:
        super().__init__("login_required", message)


class ConsentRequiredError(OAuthError):
    """Authorization endpoint: user has not consented to requested scopes."""

    def __init__(self, message: str = "Consent required") -> None:
        super().__init__("consent_required", message)
