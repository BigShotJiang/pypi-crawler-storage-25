"""Shared base class and helpers for IdpClient implementations."""

from __future__ import annotations

import base64
import hashlib
import json
import secrets
from typing import Any
from urllib.parse import urlencode

import httpx

from authpi_idp.agent import PrincipalType, AuthenticatedAgent
from authpi_idp.errors import ConfigurationError, OAuthError, TokenParseError
from authpi_idp.types import AuthorizationUrl, LogoutOptions, Organization, TokenSet


def _validate_url(url: str, field_name: str) -> None:
    """Validate that a string is a valid URL."""
    try:
        parsed = httpx.URL(url)
        if not parsed.scheme or not parsed.host:
            raise ConfigurationError(f"{field_name} must be a valid URL")
    except Exception as e:
        if isinstance(e, ConfigurationError):
            raise
        raise ConfigurationError(f"{field_name} must be a valid URL") from e


def _generate_code_verifier() -> str:
    """
    Generate a cryptographically secure code verifier for PKCE.
    RFC 7636 recommends 32 bytes (256 bits) of entropy minimum.
    """
    return _base64url_encode(secrets.token_bytes(32))


def _generate_code_challenge(verifier: str) -> str:
    """Generate S256 code challenge from verifier."""
    digest = hashlib.sha256(verifier.encode("utf-8")).digest()
    return _base64url_encode(digest)


def _generate_state() -> str:
    """Generate a random state value."""
    return _base64url_encode(secrets.token_bytes(32))


def _base64url_encode(data: bytes) -> str:
    """Base64URL encode bytes (RFC 4648, no padding)."""
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _parse_jwt_payload(jwt: str) -> dict[str, Any] | None:
    """
    Parse JWT payload without signature verification.
    (Signature verification is done server-side during token exchange)
    """
    try:
        parts = jwt.split(".")
        if len(parts) != 3:
            return None

        # Decode payload (second part)
        payload = parts[1]
        # Add padding if needed
        padding = 4 - len(payload) % 4
        if padding != 4:
            payload += "=" * padding

        # Handle base64url
        payload = payload.replace("-", "+").replace("_", "/")
        json_bytes = base64.b64decode(payload)
        return json.loads(json_bytes.decode("utf-8"))
    except Exception:
        return None


def _get_agent_type(sub: str) -> PrincipalType:
    """Determine principal type from subject ID prefix."""
    if sub.startswith("agt_"):
        return PrincipalType.AGENT
    if sub.startswith("key_"):
        return PrincipalType.API_KEY
    if sub.startswith("tok_"):
        return PrincipalType.PERSONAL_TOKEN
    return PrincipalType.USER


def _parse_organizations(orgs: dict[str, Any] | None) -> list[Organization]:
    """Parse organizations claim from ID token or userinfo."""
    if not orgs or not isinstance(orgs, dict):
        return []

    result = []
    for org_id, data in orgs.items():
        if not isinstance(data, dict):
            continue
        result.append(
            Organization(
                id=org_id,
                title=data.get("title"),
                scopes=data.get("scopes", []),
                joined_at=data.get("joined_at", 0),
            )
        )
    return result


def _coerce_token_set(tokens: dict[str, Any] | TokenSet) -> TokenSet:
    """Coerce a dict or TokenSet into a TokenSet.

    Args:
        tokens: A dict with token fields or a TokenSet instance.

    Returns:
        TokenSet instance.

    Raises:
        TypeError: If tokens is not a dict or TokenSet.
        ValidationError: If required fields are missing from a dict.
    """
    if isinstance(tokens, TokenSet):
        return tokens
    if isinstance(tokens, dict):
        return TokenSet(**tokens)
    raise TypeError(f"tokens must be a dict or TokenSet, got {type(tokens).__name__}")


class _IdpClientBase:
    """Shared non-IO logic for IdpClient and IdpClientSync."""

    def __init__(
        self,
        issuer_url: str,
        client_id: str,
        redirect_uri: str | None = None,
        client_secret: str | None = None,
        auto_refresh: bool = True,
        refresh_buffer_seconds: int = 60,
    ) -> None:
        # Validate required fields (strip whitespace)
        if not issuer_url or not issuer_url.strip():
            raise ConfigurationError("issuer_url is required")
        if not client_id or not client_id.strip():
            raise ConfigurationError("client_id is required")

        # Validate URLs
        _validate_url(issuer_url, "issuer_url")
        if redirect_uri:
            _validate_url(redirect_uri, "redirect_uri")

        # Normalize issuer_url (remove trailing slash)
        self._issuer_url = issuer_url.rstrip("/")
        self._client_id = client_id
        self._client_secret = client_secret
        self._redirect_uri = redirect_uri
        self._auto_refresh = auto_refresh
        self._refresh_buffer_seconds = refresh_buffer_seconds

    def create_authorization_url(
        self,
        scopes: list[str],
        state: str | None = None,
        nonce: str | None = None,
    ) -> AuthorizationUrl:
        """
        Create an authorization URL for OAuth flow.

        Args:
            scopes: OAuth scopes (must include "openid")
            state: CSRF state (auto-generated if not provided)
            nonce: ID token nonce

        Returns:
            AuthorizationUrl with url, code_verifier, and state

        Raises:
            OAuthError: If scopes are invalid
        """
        if not self._redirect_uri:
            raise ConfigurationError("redirect_uri is required for authorization code flow")

        # Validate scopes
        if not scopes:
            raise OAuthError("invalid_request", "scopes are required")
        if "openid" not in scopes:
            raise OAuthError("invalid_request", "openid scope is required")

        # Generate PKCE code verifier and challenge
        code_verifier = _generate_code_verifier()
        code_challenge = _generate_code_challenge(code_verifier)

        # Generate or use provided state
        state = state or _generate_state()

        # Generate or use provided nonce
        nonce = nonce or _generate_state()

        # Build authorization URL
        params = {
            "client_id": self._client_id,
            "redirect_uri": self._redirect_uri,
            "response_type": "code",
            "scope": " ".join(scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "nonce": nonce,
        }

        url = f"{self._issuer_url}/authorize?{urlencode(params)}"

        return AuthorizationUrl(url=url, code_verifier=code_verifier, state=state, nonce=nonce)

    def _build_agent_from_tokens(self, tokens: TokenSet) -> AuthenticatedAgent:
        """
        Build agent from tokens without auto-refresh.
        Used by exchange_code (tokens are fresh) and create_agent (handles refresh separately).
        """
        if not tokens.id_token:
            # No ID token — client_credentials agent, reconstruct from client_id
            return AuthenticatedAgent(
                id=self._client_id,
                type=_get_agent_type(self._client_id),
                tokens=tokens,
                organizations=[],
            )

        # Parse ID token
        payload = _parse_jwt_payload(tokens.id_token)
        if payload is None:
            raise TokenParseError("Failed to parse ID token")

        # Validate required claims
        sub = payload.get("sub")
        if not isinstance(sub, str) or not sub:
            raise TokenParseError("ID token missing subject claim")

        # Determine agent type from subject prefix
        agent_type = _get_agent_type(sub)

        # Parse organizations claim
        organizations = _parse_organizations(payload.get("organizations"))

        return AuthenticatedAgent(
            id=sub,
            type=agent_type,
            email=payload.get("email") if isinstance(payload.get("email"), str) else None,
            email_verified=payload.get("email_verified") if isinstance(payload.get("email_verified"), bool) else None,
            tokens=tokens,
            organizations=organizations,
        )

    def create_logout_url(self, options: LogoutOptions | None = None) -> str:
        """
        Create logout URL.

        Args:
            options: Logout options

        Returns:
            Logout URL
        """
        params: dict[str, str] = {}

        if options:
            if options.id_token_hint:
                params["id_token_hint"] = options.id_token_hint
            if options.post_logout_redirect_uri:
                params["post_logout_redirect_uri"] = options.post_logout_redirect_uri
            if options.state:
                params["state"] = options.state

        url = f"{self._issuer_url}/logout"
        if params:
            url += f"?{urlencode(params)}"

        return url
