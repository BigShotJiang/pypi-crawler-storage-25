"""IdpClient implementations for AuthPI IdP SDK."""

from __future__ import annotations

import inspect
import time
from typing import Any

import httpx

from authpi_idp._version import SDK_VERSION
from authpi_idp.user_agent import build_user_agent

_USER_AGENT = build_user_agent(SDK_VERSION)

from authpi_idp.agent import AuthenticatedAgent
from authpi_idp.base import (
    _coerce_token_set,
    _get_agent_type,
    _IdpClientBase,
    _parse_organizations,
)
from authpi_idp.errors import (
    ConfigurationError,
    OAuthError,
    RefreshError,
    SubjectMismatchError,
    TokenExpiredError,
)
from authpi_idp.types import (
    OnRefreshAsync,
    OnRefreshErrorAsync,
    OnRefreshErrorSync,
    OnRefreshSync,
    TokenSet,
    UserInfo,
)


class IdpClient(_IdpClientBase):
    """
    Main entry point for OAuth/OIDC operations (async).

    Example:
        ```python
        idp = IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            redirect_uri="https://app.example.com/callback",
        )

        # Create authorization URL
        auth = idp.create_authorization_url(scopes=["openid", "profile"])

        # Exchange code for agent
        agent = await idp.exchange_code(code, auth.code_verifier)
        ```
    """

    def __init__(
        self,
        issuer_url: str,
        client_id: str,
        redirect_uri: str | None = None,
        client_secret: str | None = None,
        auto_refresh: bool = True,
        refresh_buffer_seconds: int = 60,
    ) -> None:
        """
        Initialize IdpClient.

        Args:
            issuer_url: OIDC issuer URL (e.g., "https://idp.authpi.com/iss_xxx")
            client_id: OAuth client ID
            redirect_uri: OAuth redirect URI (required for authorization code flow)
            client_secret: Client secret (optional for public clients)
            auto_refresh: Automatically refresh expired tokens in create_agent()
            refresh_buffer_seconds: Buffer in seconds before actual expiry
        """
        super().__init__(
            issuer_url=issuer_url,
            client_id=client_id,
            redirect_uri=redirect_uri,
            client_secret=client_secret,
            auto_refresh=auto_refresh,
            refresh_buffer_seconds=refresh_buffer_seconds,
        )
        self._http: httpx.AsyncClient | None = None

    async def _get_http(self) -> httpx.AsyncClient:
        """Get or create HTTP client."""
        if self._http is None:
            self._http = httpx.AsyncClient(timeout=30.0, headers={"User-Agent": _USER_AGENT})
        return self._http

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._http is not None:
            await self._http.aclose()
            self._http = None

    async def __aenter__(self) -> IdpClient:
        """Async context manager entry."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        await self.close()

    async def client_credentials(self, scopes: list[str] | None = None) -> AuthenticatedAgent:
        """
        Authenticate using client credentials (machine-to-machine).

        No user interaction required. Returns an agent with scopes from the token response.

        Args:
            scopes: Requested scopes (authorization scopes, not OIDC scopes)

        Returns:
            AuthenticatedAgent with tokens

        Raises:
            ConfigurationError: If client_secret is not configured
            OAuthError: If authentication fails
        """
        if not self._client_secret:
            raise ConfigurationError("client_secret is required for client_credentials flow")

        http = await self._get_http()
        token_endpoint = f"{self._issuer_url}/token"

        data = {
            "grant_type": "client_credentials",
            "client_id": self._client_id,
            "client_secret": self._client_secret,
        }
        if scopes:
            data["scope"] = " ".join(scopes)

        response = await http.post(
            token_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if response.status_code != 200:
            try:
                error_data = response.json()
                raise OAuthError(
                    error_data.get("error", "token_error"),
                    error_data.get("error_description", "Client credentials authentication failed"),
                )
            except (ValueError, KeyError):
                raise OAuthError("token_error", "Client credentials authentication failed")

        token_data = response.json()
        tokens = TokenSet(
            access_token=token_data["access_token"],
            token_type=token_data.get("token_type", "Bearer"),
            expires_at=int(time.time()) + token_data.get("expires_in", 3600),
            refresh_token=token_data.get("refresh_token"),
            id_token=token_data.get("id_token"),
            scope=token_data.get("scope"),
        )

        return AuthenticatedAgent(
            id=self._client_id,
            type=_get_agent_type(self._client_id),
            tokens=tokens,
            organizations=[],
        )

    async def exchange_code(self, code: str, code_verifier: str) -> AuthenticatedAgent:
        """
        Exchange authorization code for tokens.

        Args:
            code: Authorization code from callback
            code_verifier: PKCE code verifier from create_authorization_url

        Returns:
            AuthenticatedAgent with tokens and claims

        Raises:
            ConfigurationError: If redirect_uri is not configured
            OAuthError: If code exchange fails
        """
        if not self._redirect_uri:
            raise ConfigurationError("redirect_uri is required for authorization code flow")

        http = await self._get_http()
        token_endpoint = f"{self._issuer_url}/token"

        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self._redirect_uri,
            "client_id": self._client_id,
            "code_verifier": code_verifier,
        }

        if self._client_secret:
            data["client_secret"] = self._client_secret

        response = await http.post(
            token_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if response.status_code != 200:
            try:
                error_data = response.json()
                raise OAuthError(
                    error_data.get("error", "token_error"),
                    error_data.get("error_description", "Failed to exchange code"),
                )
            except (ValueError, KeyError):
                raise OAuthError("token_error", "Failed to exchange code")

        token_data = response.json()

        tokens = TokenSet(
            access_token=token_data["access_token"],
            token_type=token_data.get("token_type", "Bearer"),
            expires_at=int(time.time()) + token_data.get("expires_in", 3600),
            refresh_token=token_data.get("refresh_token"),
            id_token=token_data.get("id_token"),
            scope=token_data.get("scope"),
        )

        return self._build_agent_from_tokens(tokens)

    async def create_agent(
        self,
        tokens: dict[str, Any] | TokenSet,
        *,
        on_refresh: OnRefreshAsync | None = None,
        on_refresh_error: OnRefreshErrorAsync | None = None,
        auto_refresh: bool | None = None,
    ) -> AuthenticatedAgent:
        """
        Create an agent from stored tokens.

        If auto_refresh is enabled (default), automatically refreshes expired tokens.
        Use the on_refresh callback to persist new tokens to your storage.

        Args:
            tokens: Stored tokens (dict or TokenSet)
            on_refresh: Called with a dict when tokens are refreshed. Persist the new tokens.
            on_refresh_error: Called when token refresh fails.
            auto_refresh: Override the client's auto_refresh setting for this call.

        Returns:
            AuthenticatedAgent

        Raises:
            TokenExpiredError: If tokens are expired and no refresh token available
            RefreshError: If refresh fails

        Example:
            ```python
            tokens = session.get("tokens")
            agent = await idp.create_agent(
                tokens,
                on_refresh=lambda new_tokens: session.update({"tokens": new_tokens}),
            )
            ```
        """
        token_set = _coerce_token_set(tokens)
        agent = self._build_agent_from_tokens(token_set)

        # Check if auto-refresh is enabled and tokens are expired/expiring
        should_auto_refresh = auto_refresh if auto_refresh is not None else self._auto_refresh

        if should_auto_refresh and agent.is_expired(self._refresh_buffer_seconds):
            if not token_set.refresh_token:
                error = TokenExpiredError()
                if on_refresh_error:
                    result = on_refresh_error(error)
                    if inspect.isawaitable(result):
                        await result
                raise error

            try:
                agent = await self.refresh(agent)

                # Notify caller so they can persist new tokens
                if on_refresh:
                    result = on_refresh(agent.tokens.model_dump())
                    if inspect.isawaitable(result):
                        await result
            except Exception as e:
                if on_refresh_error:
                    result = on_refresh_error(e)
                    if inspect.isawaitable(result):
                        await result
                raise

        return agent

    async def refresh(self, agent: AuthenticatedAgent) -> AuthenticatedAgent:
        """
        Refresh tokens and return new agent.

        Args:
            agent: Agent with refresh token

        Returns:
            New agent with fresh tokens

        Raises:
            TokenExpiredError: If no refresh token available
            RefreshError: If refresh fails
            SubjectMismatchError: If refreshed token belongs to different user
        """
        if not agent.tokens.refresh_token:
            raise TokenExpiredError("No refresh token available")

        http = await self._get_http()
        token_endpoint = f"{self._issuer_url}/token"

        data = {
            "grant_type": "refresh_token",
            "refresh_token": agent.tokens.refresh_token,
            "client_id": self._client_id,
        }

        if self._client_secret:
            data["client_secret"] = self._client_secret

        response = await http.post(
            token_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if response.status_code != 200:
            try:
                error_data = response.json()
                raise RefreshError(
                    error_data.get("error", "refresh_error"),
                    error_data.get("error_description", "Failed to refresh tokens"),
                    response.status_code,
                )
            except (ValueError, KeyError):
                raise RefreshError("refresh_error", "Failed to refresh tokens", response.status_code)

        token_data = response.json()

        tokens = TokenSet(
            access_token=token_data["access_token"],
            token_type=token_data.get("token_type", "Bearer"),
            expires_at=int(time.time()) + token_data.get("expires_in", 3600),
            refresh_token=token_data.get("refresh_token") or agent.tokens.refresh_token,
            id_token=token_data.get("id_token"),
            scope=token_data.get("scope") or agent.tokens.scope,
        )

        # If no ID token returned, fetch fresh organizations from userinfo
        if not tokens.id_token:
            user_info = await self._get_user_info_with_token(tokens.access_token)

            # Security: Verify the subject matches to prevent identity confusion
            if user_info.sub != agent.id:
                raise SubjectMismatchError(agent.id, user_info.sub)

            # Use userinfo organizations if present (even if empty list), else preserve agent orgs
            # This ensures we don't keep stale orgs if user was removed from all orgs
            organizations = user_info.organizations if user_info.organizations is not None else agent.organizations

            return AuthenticatedAgent(
                id=user_info.sub,
                type=_get_agent_type(user_info.sub),
                email=user_info.email or agent.email,
                email_verified=user_info.email_verified if user_info.email_verified is not None else agent.email_verified,
                tokens=tokens,
                organizations=organizations,
            )

        # ID token is present - build agent from it but verify subject matches
        new_agent = self._build_agent_from_tokens(tokens)

        # Security: Verify the subject matches to prevent identity confusion
        if new_agent.id != agent.id:
            raise SubjectMismatchError(agent.id, new_agent.id)

        return new_agent

    async def get_user_info(self, agent: AuthenticatedAgent) -> UserInfo:
        """
        Fetch user info from userinfo endpoint.

        Args:
            agent: Authenticated agent

        Returns:
            User info
        """
        return await self._get_user_info_with_token(agent.tokens.access_token)

    async def _get_user_info_with_token(self, access_token: str) -> UserInfo:
        """Fetch user info with a specific access token."""
        http = await self._get_http()
        userinfo_endpoint = f"{self._issuer_url}/userinfo"

        response = await http.get(
            userinfo_endpoint,
            headers={"Authorization": f"Bearer {access_token}"},
        )

        if response.status_code != 200:
            raise OAuthError("userinfo_error", "Failed to fetch user info")

        data = response.json()

        # Extract known fields + pass remaining as custom claims
        known_fields = {
            "sub": data["sub"],
            "email": data.get("email"),
            "email_verified": data.get("email_verified"),
            "name": data.get("name"),
            "given_name": data.get("given_name"),
            "family_name": data.get("family_name"),
            "picture": data.get("picture"),
            "locale": data.get("locale"),
            "phone_number": data.get("phone_number"),
            "phone_number_verified": data.get("phone_number_verified"),
            "organizations": _parse_organizations(data.get("organizations")),
            "created_at": data.get("created_at"),
            "updated_at": data.get("updated_at"),
        }

        # Add custom claims (fields not in the known set)
        known_keys = {
            "sub", "email", "email_verified", "name", "given_name", "family_name",
            "picture", "locale", "phone_number", "phone_number_verified",
            "organizations", "created_at", "updated_at",
        }
        custom_claims = {k: v for k, v in data.items() if k not in known_keys}

        return UserInfo(**known_fields, **custom_claims)

    async def revoke_token(self, token: str, token_type_hint: str | None = None) -> None:
        """
        Revoke a token.

        Args:
            token: Token to revoke
            token_type_hint: Hint about token type ("access_token" or "refresh_token")
        """
        http = await self._get_http()
        revoke_endpoint = f"{self._issuer_url}/revoke"

        data = {
            "token": token,
            "client_id": self._client_id,
        }

        if token_type_hint:
            data["token_type_hint"] = token_type_hint
        if self._client_secret:
            data["client_secret"] = self._client_secret

        response = await http.post(
            revoke_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        # RFC 7009: revocation endpoint should return 200 even for invalid tokens
        if response.status_code != 200:
            try:
                error_data = response.json()
                raise OAuthError(
                    error_data.get("error", "revocation_error"),
                    error_data.get("error_description", "Failed to revoke token"),
                )
            except (ValueError, KeyError):
                raise OAuthError("revocation_error", "Failed to revoke token")


class IdpClientSync(_IdpClientBase):
    """
    Main entry point for OAuth/OIDC operations (sync).

    Example:
        ```python
        idp = IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            redirect_uri="https://app.example.com/callback",
        )

        # Create authorization URL
        auth = idp.create_authorization_url(scopes=["openid", "profile"])

        # Exchange code for agent
        agent = idp.exchange_code(code, auth.code_verifier)
        ```
    """

    def __init__(
        self,
        issuer_url: str,
        client_id: str,
        redirect_uri: str | None = None,
        client_secret: str | None = None,
        auto_refresh: bool = True,
        refresh_buffer_seconds: int = 60,
    ) -> None:
        """
        Initialize IdpClientSync.

        Args:
            issuer_url: OIDC issuer URL (e.g., "https://idp.authpi.com/iss_xxx")
            client_id: OAuth client ID
            redirect_uri: OAuth redirect URI (required for authorization code flow)
            client_secret: Client secret (optional for public clients)
            auto_refresh: Automatically refresh expired tokens in create_agent()
            refresh_buffer_seconds: Buffer in seconds before actual expiry
        """
        super().__init__(
            issuer_url=issuer_url,
            client_id=client_id,
            redirect_uri=redirect_uri,
            client_secret=client_secret,
            auto_refresh=auto_refresh,
            refresh_buffer_seconds=refresh_buffer_seconds,
        )
        self._http: httpx.Client | None = None

    def _get_http(self) -> httpx.Client:
        """Get or create HTTP client."""
        if self._http is None:
            self._http = httpx.Client(timeout=30.0, headers={"User-Agent": _USER_AGENT})
        return self._http

    def close(self) -> None:
        """Close the HTTP client."""
        if self._http is not None:
            self._http.close()
            self._http = None

    def __enter__(self) -> IdpClientSync:
        """Context manager entry."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Context manager exit."""
        self.close()

    def client_credentials(self, scopes: list[str] | None = None) -> AuthenticatedAgent:
        """
        Authenticate using client credentials (machine-to-machine).

        No user interaction required. Returns an agent with scopes from the token response.

        Args:
            scopes: Requested scopes (authorization scopes, not OIDC scopes)

        Returns:
            AuthenticatedAgent with tokens

        Raises:
            ConfigurationError: If client_secret is not configured
            OAuthError: If authentication fails
        """
        if not self._client_secret:
            raise ConfigurationError("client_secret is required for client_credentials flow")

        http = self._get_http()
        token_endpoint = f"{self._issuer_url}/token"

        data = {
            "grant_type": "client_credentials",
            "client_id": self._client_id,
            "client_secret": self._client_secret,
        }
        if scopes:
            data["scope"] = " ".join(scopes)

        response = http.post(
            token_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if response.status_code != 200:
            try:
                error_data = response.json()
                raise OAuthError(
                    error_data.get("error", "token_error"),
                    error_data.get("error_description", "Client credentials authentication failed"),
                )
            except (ValueError, KeyError):
                raise OAuthError("token_error", "Client credentials authentication failed")

        token_data = response.json()
        tokens = TokenSet(
            access_token=token_data["access_token"],
            token_type=token_data.get("token_type", "Bearer"),
            expires_at=int(time.time()) + token_data.get("expires_in", 3600),
            refresh_token=token_data.get("refresh_token"),
            id_token=token_data.get("id_token"),
            scope=token_data.get("scope"),
        )

        return AuthenticatedAgent(
            id=self._client_id,
            type=_get_agent_type(self._client_id),
            tokens=tokens,
            organizations=[],
        )

    def exchange_code(self, code: str, code_verifier: str) -> AuthenticatedAgent:
        """
        Exchange authorization code for tokens.

        Args:
            code: Authorization code from callback
            code_verifier: PKCE code verifier from create_authorization_url

        Returns:
            AuthenticatedAgent with tokens and claims

        Raises:
            ConfigurationError: If redirect_uri is not configured
            OAuthError: If code exchange fails
        """
        if not self._redirect_uri:
            raise ConfigurationError("redirect_uri is required for authorization code flow")

        http = self._get_http()
        token_endpoint = f"{self._issuer_url}/token"

        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self._redirect_uri,
            "client_id": self._client_id,
            "code_verifier": code_verifier,
        }

        if self._client_secret:
            data["client_secret"] = self._client_secret

        response = http.post(
            token_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if response.status_code != 200:
            try:
                error_data = response.json()
                raise OAuthError(
                    error_data.get("error", "token_error"),
                    error_data.get("error_description", "Failed to exchange code"),
                )
            except (ValueError, KeyError):
                raise OAuthError("token_error", "Failed to exchange code")

        token_data = response.json()

        tokens = TokenSet(
            access_token=token_data["access_token"],
            token_type=token_data.get("token_type", "Bearer"),
            expires_at=int(time.time()) + token_data.get("expires_in", 3600),
            refresh_token=token_data.get("refresh_token"),
            id_token=token_data.get("id_token"),
            scope=token_data.get("scope"),
        )

        return self._build_agent_from_tokens(tokens)

    def create_agent(
        self,
        tokens: dict[str, Any] | TokenSet,
        *,
        on_refresh: OnRefreshSync | None = None,
        on_refresh_error: OnRefreshErrorSync | None = None,
        auto_refresh: bool | None = None,
    ) -> AuthenticatedAgent:
        """
        Create an agent from stored tokens.

        If auto_refresh is enabled (default), automatically refreshes expired tokens.
        Use the on_refresh callback to persist new tokens to your storage.

        Args:
            tokens: Stored tokens (dict or TokenSet)
            on_refresh: Called with a dict when tokens are refreshed. Persist the new tokens.
            on_refresh_error: Called when token refresh fails.
            auto_refresh: Override the client's auto_refresh setting for this call.

        Returns:
            AuthenticatedAgent

        Raises:
            TokenExpiredError: If tokens are expired and no refresh token available
            RefreshError: If refresh fails
        """
        token_set = _coerce_token_set(tokens)
        agent = self._build_agent_from_tokens(token_set)

        # Check if auto-refresh is enabled and tokens are expired/expiring
        should_auto_refresh = auto_refresh if auto_refresh is not None else self._auto_refresh

        if should_auto_refresh and agent.is_expired(self._refresh_buffer_seconds):
            if not token_set.refresh_token:
                error = TokenExpiredError()
                if on_refresh_error:
                    on_refresh_error(error)
                raise error

            try:
                agent = self.refresh(agent)

                # Notify caller so they can persist new tokens
                if on_refresh:
                    on_refresh(agent.tokens.model_dump())
            except Exception as e:
                if on_refresh_error:
                    on_refresh_error(e)
                raise

        return agent

    def refresh(self, agent: AuthenticatedAgent) -> AuthenticatedAgent:
        """
        Refresh tokens and return new agent.

        Args:
            agent: Agent with refresh token

        Returns:
            New agent with fresh tokens

        Raises:
            TokenExpiredError: If no refresh token available
            RefreshError: If refresh fails
            SubjectMismatchError: If refreshed token belongs to different user
        """
        if not agent.tokens.refresh_token:
            raise TokenExpiredError("No refresh token available")

        http = self._get_http()
        token_endpoint = f"{self._issuer_url}/token"

        data = {
            "grant_type": "refresh_token",
            "refresh_token": agent.tokens.refresh_token,
            "client_id": self._client_id,
        }

        if self._client_secret:
            data["client_secret"] = self._client_secret

        response = http.post(
            token_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        if response.status_code != 200:
            try:
                error_data = response.json()
                raise RefreshError(
                    error_data.get("error", "refresh_error"),
                    error_data.get("error_description", "Failed to refresh tokens"),
                    response.status_code,
                )
            except (ValueError, KeyError):
                raise RefreshError("refresh_error", "Failed to refresh tokens", response.status_code)

        token_data = response.json()

        tokens = TokenSet(
            access_token=token_data["access_token"],
            token_type=token_data.get("token_type", "Bearer"),
            expires_at=int(time.time()) + token_data.get("expires_in", 3600),
            refresh_token=token_data.get("refresh_token") or agent.tokens.refresh_token,
            id_token=token_data.get("id_token"),
            scope=token_data.get("scope") or agent.tokens.scope,
        )

        # If no ID token returned, fetch fresh organizations from userinfo
        if not tokens.id_token:
            user_info = self._get_user_info_with_token(tokens.access_token)

            # Security: Verify the subject matches to prevent identity confusion
            if user_info.sub != agent.id:
                raise SubjectMismatchError(agent.id, user_info.sub)

            # Use userinfo organizations if present (even if empty list), else preserve agent orgs
            # This ensures we don't keep stale orgs if user was removed from all orgs
            organizations = user_info.organizations if user_info.organizations is not None else agent.organizations

            return AuthenticatedAgent(
                id=user_info.sub,
                type=_get_agent_type(user_info.sub),
                email=user_info.email or agent.email,
                email_verified=user_info.email_verified if user_info.email_verified is not None else agent.email_verified,
                tokens=tokens,
                organizations=organizations,
            )

        # ID token is present - build agent from it but verify subject matches
        new_agent = self._build_agent_from_tokens(tokens)

        # Security: Verify the subject matches to prevent identity confusion
        if new_agent.id != agent.id:
            raise SubjectMismatchError(agent.id, new_agent.id)

        return new_agent

    def get_user_info(self, agent: AuthenticatedAgent) -> UserInfo:
        """
        Fetch user info from userinfo endpoint.

        Args:
            agent: Authenticated agent

        Returns:
            User info
        """
        return self._get_user_info_with_token(agent.tokens.access_token)

    def _get_user_info_with_token(self, access_token: str) -> UserInfo:
        """Fetch user info with a specific access token."""
        http = self._get_http()
        userinfo_endpoint = f"{self._issuer_url}/userinfo"

        response = http.get(
            userinfo_endpoint,
            headers={"Authorization": f"Bearer {access_token}"},
        )

        if response.status_code != 200:
            raise OAuthError("userinfo_error", "Failed to fetch user info")

        data = response.json()

        # Extract known fields + pass remaining as custom claims
        known_fields = {
            "sub": data["sub"],
            "email": data.get("email"),
            "email_verified": data.get("email_verified"),
            "name": data.get("name"),
            "given_name": data.get("given_name"),
            "family_name": data.get("family_name"),
            "picture": data.get("picture"),
            "locale": data.get("locale"),
            "phone_number": data.get("phone_number"),
            "phone_number_verified": data.get("phone_number_verified"),
            "organizations": _parse_organizations(data.get("organizations")),
            "created_at": data.get("created_at"),
            "updated_at": data.get("updated_at"),
        }

        # Add custom claims (fields not in the known set)
        known_keys = {
            "sub", "email", "email_verified", "name", "given_name", "family_name",
            "picture", "locale", "phone_number", "phone_number_verified",
            "organizations", "created_at", "updated_at",
        }
        custom_claims = {k: v for k, v in data.items() if k not in known_keys}

        return UserInfo(**known_fields, **custom_claims)

    def revoke_token(self, token: str, token_type_hint: str | None = None) -> None:
        """
        Revoke a token.

        Args:
            token: Token to revoke
            token_type_hint: Hint about token type ("access_token" or "refresh_token")
        """
        http = self._get_http()
        revoke_endpoint = f"{self._issuer_url}/revoke"

        data = {
            "token": token,
            "client_id": self._client_id,
        }

        if token_type_hint:
            data["token_type_hint"] = token_type_hint
        if self._client_secret:
            data["client_secret"] = self._client_secret

        response = http.post(
            revoke_endpoint,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        # RFC 7009: revocation endpoint should return 200 even for invalid tokens
        if response.status_code != 200:
            try:
                error_data = response.json()
                raise OAuthError(
                    error_data.get("error", "revocation_error"),
                    error_data.get("error_description", "Failed to revoke token"),
                )
            except (ValueError, KeyError):
                raise OAuthError("revocation_error", "Failed to revoke token")
