"""Build a User-Agent header string for the IdP SDK.

Format: ``authpi-idp-py/<sdk-version> Python/<python-version> (<platform>; <arch>)``

Example: ``authpi-idp-py/0.2.0 Python/3.11.5 (linux; x86_64)``
"""

from __future__ import annotations

import platform
import sys

_SDK_NAME = "authpi-idp-py"


def build_user_agent(sdk_version: str) -> str:
    """Build the User-Agent string for this SDK."""
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    system = platform.system().lower()
    machine = platform.machine().lower()
    return f"{_SDK_NAME}/{sdk_version} Python/{py_version} ({system}; {machine})"
