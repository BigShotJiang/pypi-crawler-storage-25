"""Tests for AuthenticatedAgent."""

import time

import pytest

from authpi_idp.agent import PrincipalType, AuthenticatedAgent
from authpi_idp.types import Organization, TokenSet


class TestAgentConstruction:
    """Tests for agent construction."""

    def test_creates_agent_with_all_properties(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            email="user@example.com",
            email_verified=True,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.id == "usr_123"
        assert agent.type == PrincipalType.USER
        assert agent.email == "user@example.com"
        assert agent.email_verified is True
        assert agent.tokens == mock_tokens
        assert agent.organizations == mock_organizations

    def test_creates_agent_with_minimal_properties(self, mock_tokens: TokenSet) -> None:
        agent = AuthenticatedAgent(
            id="key_456",
            type=PrincipalType.API_KEY,
            tokens=mock_tokens,
            organizations=[],
        )

        assert agent.id == "key_456"
        assert agent.type == PrincipalType.API_KEY
        assert agent.email is None
        assert agent.email_verified is None
        assert agent.organizations == []

    def test_creates_personal_token_agent(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="tok_789",
            type=PrincipalType.PERSONAL_TOKEN,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.type == PrincipalType.PERSONAL_TOKEN


class TestTokenExpiration:
    """Tests for token expiration."""

    def test_expires_at_returns_token_expiration_timestamp(self) -> None:
        tokens = TokenSet(
            access_token="test",
            token_type="Bearer",
            expires_at=1700000000,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )

        assert agent.expires_at == 1700000000

    def test_expires_in_returns_positive_seconds_when_token_is_valid(self) -> None:
        now = int(time.time())
        tokens = TokenSet(
            access_token="test",
            token_type="Bearer",
            expires_at=now + 3600,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )

        assert agent.expires_in >= 3599
        assert agent.expires_in <= 3601

    def test_expires_in_returns_negative_seconds_when_token_is_expired(self) -> None:
        now = int(time.time())
        tokens = TokenSet(
            access_token="test",
            token_type="Bearer",
            expires_at=now - 100,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )

        assert agent.expires_in <= -99
        assert agent.expires_in >= -101

    def test_is_expired_returns_false_when_token_is_valid(self) -> None:
        tokens = TokenSet(
            access_token="test",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )

        assert agent.is_expired() is False

    def test_is_expired_returns_true_when_token_is_expired(self) -> None:
        tokens = TokenSet(
            access_token="test",
            token_type="Bearer",
            expires_at=int(time.time()) - 100,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )

        assert agent.is_expired() is True

    def test_is_expired_returns_true_when_token_is_about_to_expire_within_buffer(self) -> None:
        # Token expires in 30 seconds, but we consider it expired with 60s buffer
        tokens = TokenSet(
            access_token="test",
            token_type="Bearer",
            expires_at=int(time.time()) + 30,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )

        assert agent.is_expired(60) is True
        assert agent.is_expired(0) is False

    def test_default_clock_skew_buffer(self) -> None:
        """Token expiring in 20s should be considered expired with 30s default buffer."""
        tokens = TokenSet(
            access_token="test",
            token_type="Bearer",
            expires_at=int(time.time()) + 20,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )
        assert agent.is_expired() is True


class TestGetScopesFor:
    """Tests for get_scopes_for method."""

    def test_returns_scopes_for_existing_organization(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.get_scopes_for("org_admin") == ["users:read", "users:write", "projects:**"]

    def test_returns_empty_array_for_non_existent_organization(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.get_scopes_for("org_unknown") == []


class TestHasAccessAcrossAllOrganizations:
    """Tests for has_access method (across all organizations)."""

    def test_returns_true_if_any_organization_grants_access(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.has_access("read", "users") is True
        assert agent.has_access("write", "users") is True

    def test_returns_true_for_recursive_wildcard_in_any_org(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        # org_owner has *:**
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.has_access("delete", "anything") is True

    def test_returns_false_if_no_organization_grants_access(self, mock_tokens: TokenSet) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=[
                Organization(id="org_1", title=None, scopes=["users:read"], joined_at=1700000000),
            ],
        )

        assert agent.has_access("delete", "users") is False

    def test_returns_false_for_agent_with_no_organizations(self, mock_tokens: TokenSet) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=[],
        )

        assert agent.has_access("read", "users") is False


class TestHasAccessInSpecificOrganization:
    """Tests for has_access_in method (specific organization)."""

    def test_returns_true_if_organization_grants_access(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.has_access_in("org_admin", "read", "users") is True
        assert agent.has_access_in("org_admin", "write", "users") is True

    def test_returns_false_if_organization_does_not_grant_access(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.has_access_in("org_admin", "delete", "users") is False

    def test_returns_false_for_non_existent_organization(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.has_access_in("org_unknown", "read", "users") is False

    def test_respects_recursive_wildcard(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.has_access_in("org_admin", "read", "projects") is True
        assert agent.has_access_in("org_admin", "write", "projects.tasks") is True

    def test_org_with_super_admin_grants_everything(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.has_access_in("org_owner", "delete", "anything") is True
        assert agent.has_access_in("org_owner", "manage", "deep.nested.resource") is True


class TestRoleChecks:
    """Tests for role check methods."""

    def test_is_owner_of_returns_true_if_user_has_owner_scope(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.is_owner_of("org_owner") is True

    def test_is_owner_of_returns_false_if_user_does_not_have_owner_scope(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.is_owner_of("org_admin") is False
        assert agent.is_owner_of("org_member") is False

    def test_is_owner_of_returns_false_for_non_existent_organization(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.is_owner_of("org_unknown") is False

    def test_is_admin_of_returns_true_if_user_has_admin_scope(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.is_admin_of("org_owner") is True

    def test_is_admin_of_returns_false_if_user_does_not_have_admin_scope(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.is_admin_of("org_admin") is False
        assert agent.is_admin_of("org_member") is False

    def test_is_admin_of_returns_false_for_non_existent_organization(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.is_admin_of("org_unknown") is False

    def test_is_member_of_returns_true_if_user_has_any_membership(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.is_member_of("org_owner") is True
        assert agent.is_member_of("org_admin") is True
        assert agent.is_member_of("org_member") is True

    def test_is_member_of_returns_false_for_non_existent_organization(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        assert agent.is_member_of("org_unknown") is False


class TestSerialization:
    """Tests for serialization."""

    def test_tokens_are_accessible_for_storage(
        self, mock_tokens: TokenSet, mock_organizations: list[Organization]
    ) -> None:
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=mock_tokens,
            organizations=mock_organizations,
        )

        # Tokens should be serializable
        serialized = agent.tokens.model_dump_json()
        assert "access_token_value" in serialized
        assert "refresh_token_value" in serialized
