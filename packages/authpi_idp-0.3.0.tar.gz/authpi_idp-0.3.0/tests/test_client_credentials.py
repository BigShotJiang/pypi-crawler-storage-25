"""Tests for client_credentials flow in both async and sync clients."""

from __future__ import annotations

import time

import pytest
from pytest_httpx import HTTPXMock

from authpi_idp.agent import AuthenticatedAgent, PrincipalType
from authpi_idp.client import IdpClient, IdpClientSync
from authpi_idp.errors import ConfigurationError, OAuthError
from authpi_idp.types import TokenSet


# --- Async client tests ---


class TestIdpClientCredentialsAsync:
    """Tests for IdpClient.client_credentials (async)."""

    @pytest.mark.anyio
    async def test_authenticates_via_client_credentials(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "agent_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "scope": "users:read users:write",
            },
        )

        async with IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret_value",
        ) as client:
            agent = await client.client_credentials(scopes=["users:read", "users:write"])

        assert isinstance(agent, AuthenticatedAgent)
        assert agent.id == "cli_xxx"
        assert agent.tokens.access_token == "agent_access_token"
        assert agent.tokens.scope == "users:read users:write"
        assert agent.organizations == []

        # Verify the request
        request = httpx_mock.get_request()
        assert request is not None
        body = request.content.decode()
        assert "grant_type=client_credentials" in body
        assert "client_id=cli_xxx" in body
        assert "client_secret=secret_value" in body
        assert "scope=users%3Aread+users%3Awrite" in body or "scope=users:read+users:write" in body

    @pytest.mark.anyio
    async def test_requires_client_secret(self) -> None:
        client = IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
        )
        with pytest.raises(ConfigurationError, match="client_secret is required"):
            await client.client_credentials()

    @pytest.mark.anyio
    async def test_works_without_scopes(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "agent_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
            },
        )

        async with IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret_value",
        ) as client:
            agent = await client.client_credentials()

        assert isinstance(agent, AuthenticatedAgent)
        assert agent.id == "cli_xxx"

        # Verify no scope was sent
        request = httpx_mock.get_request()
        assert request is not None
        body = request.content.decode()
        assert "scope=" not in body

    @pytest.mark.anyio
    async def test_handles_error_responses(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            status_code=401,
            json={
                "error": "invalid_client",
                "error_description": "Client authentication failed",
            },
        )

        async with IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret_value",
        ) as client:
            with pytest.raises(OAuthError, match="Client authentication failed"):
                await client.client_credentials()

    @pytest.mark.anyio
    async def test_sets_agent_type_from_client_id(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "agent_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "scope": "users:read",
            },
        )

        async with IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="agt_abc123",
            client_secret="secret_value",
        ) as client:
            agent = await client.client_credentials()

        assert agent.type == PrincipalType.AGENT


# --- Sync client tests ---


class TestIdpClientCredentialsSync:
    """Tests for IdpClientSync.client_credentials (sync)."""

    def test_authenticates_via_client_credentials(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "agent_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "scope": "users:read users:write",
            },
        )

        with IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret_value",
        ) as client:
            agent = client.client_credentials(scopes=["users:read", "users:write"])

        assert isinstance(agent, AuthenticatedAgent)
        assert agent.id == "cli_xxx"
        assert agent.tokens.access_token == "agent_access_token"
        assert agent.tokens.scope == "users:read users:write"
        assert agent.organizations == []

    def test_requires_client_secret(self) -> None:
        client = IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
        )
        with pytest.raises(ConfigurationError, match="client_secret is required"):
            client.client_credentials()

    def test_works_without_scopes(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "agent_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
            },
        )

        with IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret_value",
        ) as client:
            agent = client.client_credentials()

        assert isinstance(agent, AuthenticatedAgent)
        assert agent.id == "cli_xxx"

    def test_handles_error_responses(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            status_code=401,
            json={
                "error": "invalid_client",
                "error_description": "Client authentication failed",
            },
        )

        with IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret_value",
        ) as client:
            with pytest.raises(OAuthError, match="Client authentication failed"):
                client.client_credentials()

    def test_sets_agent_type_from_client_id(self, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "agent_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "scope": "users:read",
            },
        )

        with IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="agt_abc123",
            client_secret="secret_value",
        ) as client:
            agent = client.client_credentials()

        assert agent.type == PrincipalType.AGENT


# --- Agent has_access tests for token-level scopes ---


class TestAgentHasAccessTokenScopes:
    """Tests for has_access using token-level scopes (agents via client_credentials)."""

    def test_uses_token_scopes_when_no_organizations(self) -> None:
        agent = AuthenticatedAgent(
            id="cli_xxx",
            type=PrincipalType.USER,
            tokens=TokenSet(
                access_token="access_token",
                token_type="Bearer",
                expires_at=int(time.time()) + 3600,
                scope="users:read users:write projects:**",
            ),
            organizations=[],
        )

        assert agent.has_access("read", "users") is True
        assert agent.has_access("write", "users") is True
        assert agent.has_access("read", "projects") is True
        assert agent.has_access("write", "projects.tasks") is True
        assert agent.has_access("delete", "users") is False

    def test_does_not_use_token_scopes_when_has_organizations(self) -> None:
        from authpi_idp.types import Organization

        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=TokenSet(
                access_token="access_token",
                token_type="Bearer",
                expires_at=int(time.time()) + 3600,
                scope="users:delete",
            ),
            organizations=[
                Organization(id="org_1", title=None, scopes=["users:read"], joined_at=1700000000),
            ],
        )

        # Organization scopes should be used, not token scopes
        assert agent.has_access("read", "users") is True
        assert agent.has_access("delete", "users") is False  # token scope ignored

    def test_returns_false_when_no_organizations_and_no_token_scope(self) -> None:
        agent = AuthenticatedAgent(
            id="cli_xxx",
            type=PrincipalType.USER,
            tokens=TokenSet(
                access_token="access_token",
                token_type="Bearer",
                expires_at=int(time.time()) + 3600,
            ),
            organizations=[],
        )

        assert agent.has_access("read", "users") is False

    def test_has_access_in_returns_false_for_agents(self) -> None:
        agent = AuthenticatedAgent(
            id="cli_xxx",
            type=PrincipalType.USER,
            tokens=TokenSet(
                access_token="access_token",
                token_type="Bearer",
                expires_at=int(time.time()) + 3600,
                scope="users:read users:write",
            ),
            organizations=[],
        )

        assert agent.has_access_in("org_xxx", "read", "users") is False

    def test_is_member_of_returns_false_for_agents(self) -> None:
        agent = AuthenticatedAgent(
            id="cli_xxx",
            type=PrincipalType.USER,
            tokens=TokenSet(
                access_token="access_token",
                token_type="Bearer",
                expires_at=int(time.time()) + 3600,
                scope="users:read",
            ),
            organizations=[],
        )

        assert agent.is_member_of("org_xxx") is False


class TestCreateAgentFromStoredM2MTokens:
    """Test that M2M agents can be persisted and restored via create_agent."""

    @pytest.mark.anyio
    async def test_restore_m2m_agent_from_stored_tokens_async(self) -> None:
        client = IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="agt_machine1",
            client_secret="secret",
        )

        stored_tokens = TokenSet(
            access_token="access_token_value",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            scope="users:read users:write",
        )

        agent = await client.create_agent(stored_tokens)
        assert agent.id == "agt_machine1"
        assert agent.type == PrincipalType.AGENT
        assert agent.tokens.access_token == "access_token_value"
        assert agent.organizations == []
        assert agent.has_access("read", "users") is True

    def test_restore_m2m_agent_from_stored_tokens_sync(self) -> None:
        client = IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="agt_machine1",
            client_secret="secret",
        )

        stored_tokens = TokenSet(
            access_token="access_token_value",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            scope="users:read users:write",
        )

        agent = client.create_agent(stored_tokens)
        assert agent.id == "agt_machine1"
        assert agent.type == PrincipalType.AGENT
        assert agent.organizations == []
