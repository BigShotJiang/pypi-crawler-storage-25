"""Edge case tests for AuthPI IdP SDK."""

from __future__ import annotations

import time

import pytest

from authpi_idp.agent import PrincipalType, AuthenticatedAgent
from authpi_idp.base import _coerce_token_set, _get_agent_type, _parse_jwt_payload, _parse_organizations
from authpi_idp.client import IdpClient
from authpi_idp.errors import TokenParseError
from authpi_idp.scopes import has_access, parse_scope
from authpi_idp.types import Organization, TokenSet
from tests.conftest import create_mock_jwt


class TestScopeEdgeCases:
    """Edge case tests for scope parsing and evaluation."""

    def test_scope_with_multiple_colons(self) -> None:
        # Should split on last colon
        result = parse_scope("a:b:read")
        assert result is not None
        assert result.resource == "a:b"
        assert result.action == "read"

    def test_scope_with_unicode_characters(self) -> None:
        # Unicode in resource name
        result = parse_scope("用户:read")
        assert result is not None
        assert result.resource == "用户"
        assert result.action == "read"

    def test_deeply_nested_resource(self) -> None:
        result = parse_scope("a.b.c.d.e.f.g:read")
        assert result is not None
        assert result.resource == "a.b.c.d.e.f.g"
        assert result.action == "read"

    def test_has_access_with_deeply_nested_wildcard(self) -> None:
        assert has_access(["a:**"], "read", "a.b.c.d.e.f.g") is True

    def test_case_sensitivity(self) -> None:
        # Scopes should be case-sensitive
        assert has_access(["Users:read"], "read", "users") is False
        assert has_access(["users:Read"], "Read", "users") is True
        assert has_access(["users:read"], "READ", "users") is False

    def test_whitespace_in_scope(self) -> None:
        # Whitespace should not be trimmed
        result = parse_scope(" users :read")
        assert result is not None
        assert result.resource == " users "
        assert result.action == "read"

    def test_empty_scopes_list(self) -> None:
        assert has_access([], "read", "users") is False

    def test_all_invalid_scopes(self) -> None:
        assert has_access(["invalid", "also-invalid", "no-colon"], "read", "users") is False

    def test_injection_style_scope(self) -> None:
        # These should parse but not grant unexpected access
        # users:* grants all actions on users (including literal "**" action)
        assert has_access(["users:*"], "**", "users") is True
        # but doesn't grant access to sub-resources
        assert has_access(["users:*"], "read", "users.verifiers") is False
        # ** as resource is NOT valid (only * is a valid resource wildcard)
        # ** is only valid as an action, not a resource
        assert has_access(["**:read"], "read", "users") is False
        # * as resource with :read grants read on any top-level resource
        assert has_access(["*:read"], "read", "users") is True
        # but * as resource doesn't match nested resources (unless action is **)
        assert has_access(["*:read"], "read", "users.verifiers") is False

    def test_resource_starting_with_dot(self) -> None:
        result = parse_scope(".hidden:read")
        assert result is not None
        assert result.resource == ".hidden"
        assert result.action == "read"


class TestJwtParsingEdgeCases:
    """Edge case tests for JWT parsing."""

    def test_jwt_with_only_two_parts(self) -> None:
        result = _parse_jwt_payload("header.payload")
        assert result is None

    def test_jwt_with_four_parts(self) -> None:
        result = _parse_jwt_payload("a.b.c.d")
        assert result is None

    def test_jwt_with_invalid_base64_payload(self) -> None:
        result = _parse_jwt_payload("header.!!!invalid!!!.signature")
        assert result is None

    def test_jwt_with_non_json_payload(self) -> None:
        import base64
        encoded = base64.urlsafe_b64encode(b"not json").rstrip(b"=").decode()
        result = _parse_jwt_payload(f"header.{encoded}.signature")
        assert result is None

    def test_jwt_with_valid_base64_but_invalid_json(self) -> None:
        import base64
        encoded = base64.urlsafe_b64encode(b"{invalid json}").rstrip(b"=").decode()
        result = _parse_jwt_payload(f"header.{encoded}.signature")
        assert result is None

    def test_jwt_with_empty_string(self) -> None:
        result = _parse_jwt_payload("")
        assert result is None

    def test_jwt_with_only_dots(self) -> None:
        result = _parse_jwt_payload("..")
        assert result is None


class TestPrincipalTypeDetection:
    """Edge case tests for agent type detection."""

    def test_user_prefix(self) -> None:
        assert _get_agent_type("usr_123") == PrincipalType.USER

    def test_api_key_prefix(self) -> None:
        assert _get_agent_type("key_123") == PrincipalType.API_KEY

    def test_personal_token_prefix(self) -> None:
        assert _get_agent_type("tok_123") == PrincipalType.PERSONAL_TOKEN

    def test_agent_prefix(self) -> None:
        assert _get_agent_type("agt_123") == PrincipalType.AGENT

    def test_unknown_prefix_defaults_to_user(self) -> None:
        assert _get_agent_type("unknown_123") == PrincipalType.USER
        assert _get_agent_type("") == PrincipalType.USER
        assert _get_agent_type("12345") == PrincipalType.USER

    def test_prefix_at_end_defaults_to_user(self) -> None:
        assert _get_agent_type("123_key") == PrincipalType.USER
        assert _get_agent_type("abc_tok") == PrincipalType.USER


class TestOrganizationsParsingEdgeCases:
    """Edge case tests for organizations claim parsing."""

    def test_none_organizations(self) -> None:
        result = _parse_organizations(None)
        assert result == []

    def test_empty_dict_organizations(self) -> None:
        result = _parse_organizations({})
        assert result == []

    def test_non_dict_organizations(self) -> None:
        result = _parse_organizations("not a dict")
        assert result == []
        result = _parse_organizations(123)
        assert result == []
        result = _parse_organizations([])
        assert result == []

    def test_organizations_with_missing_fields(self) -> None:
        orgs = {
            "org_1": {},  # All fields missing
            "org_2": {"title": "Admin"},  # Only title
            "org_3": {"scopes": ["read"]},  # Only scopes
        }
        result = _parse_organizations(orgs)
        assert len(result) == 3

        org1 = next(o for o in result if o.id == "org_1")
        assert org1.title is None
        assert org1.scopes == []
        assert org1.joined_at == 0

        org2 = next(o for o in result if o.id == "org_2")
        assert org2.title == "Admin"
        assert org2.scopes == []

        org3 = next(o for o in result if o.id == "org_3")
        assert org3.scopes == ["read"]

    def test_organizations_with_non_dict_values(self) -> None:
        orgs = {
            "org_1": "not a dict",  # Should be skipped
            "org_2": {"title": "Admin", "scopes": ["read"]},  # Valid
        }
        result = _parse_organizations(orgs)
        assert len(result) == 1
        assert result[0].id == "org_2"


class TestClientConfigurationEdgeCases:
    """Edge case tests for client configuration."""

    def test_issuer_url_with_multiple_trailing_slashes(self) -> None:
        client = IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx///",
            client_id="cli",
            redirect_uri="https://example.com",
        )
        # URL should be normalized
        assert client is not None

    def test_issuer_url_with_path(self) -> None:
        client = IdpClient(
            issuer_url="https://auth.example.com/v1/oidc",
            client_id="cli",
            redirect_uri="https://example.com",
        )
        assert client is not None

    def test_issuer_url_with_port(self) -> None:
        client = IdpClient(
            issuer_url="https://localhost:8080",
            client_id="cli",
            redirect_uri="https://example.com",
        )
        assert client is not None

    def test_redirect_uri_with_query_params(self) -> None:
        client = IdpClient(
            issuer_url="https://example.com",
            client_id="cli",
            redirect_uri="https://app.example.com/callback?foo=bar",
        )
        assert client is not None

    def test_empty_client_secret(self) -> None:
        # Empty string should be treated as no secret (public client)
        client = IdpClient(
            issuer_url="https://example.com",
            client_id="cli",
            redirect_uri="https://example.com",
            client_secret="",
        )
        assert client is not None


class TestTokenSetEdgeCases:
    """Edge case tests for TokenSet."""

    def test_token_with_zero_expires_at(self) -> None:
        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=0,
        )
        assert tokens.expires_at == 0

    def test_token_with_negative_expires_at(self) -> None:
        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=-1000,
        )
        assert tokens.expires_at == -1000


class TestAuthenticatedAgentEdgeCases:
    """Edge case tests for AuthenticatedAgent."""

    def test_agent_with_empty_organizations(self) -> None:
        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )

        assert agent.has_access("read", "anything") is False
        assert agent.has_access_in("org_xxx", "read", "anything") is False
        assert agent.is_owner_of("org_xxx") is False
        assert agent.is_admin_of("org_xxx") is False
        assert agent.is_member_of("org_xxx") is False
        assert agent.get_scopes_for("org_xxx") == []

    def test_agent_with_organization_having_empty_scopes(self) -> None:
        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[Organization(id="org_xxx", title=None, scopes=[], joined_at=0)],
        )

        assert agent.is_member_of("org_xxx") is True
        assert agent.has_access_in("org_xxx", "read", "anything") is False

    def test_agent_is_immutable(self) -> None:
        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
        )
        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=tokens,
            organizations=[],
        )

        # Pydantic frozen models should be immutable
        with pytest.raises(Exception):  # ValidationError for frozen model
            agent.id = "different_id"  # type: ignore


class TestIdTokenClaimsEdgeCases:
    """Edge case tests for ID token claims handling."""

    @pytest.fixture
    def client(self) -> IdpClient:
        return IdpClient(
            issuer_url="https://example.com",
            client_id="cli",
            redirect_uri="https://example.com",
            auto_refresh=False,
        )

    async def test_email_as_number_is_ignored(self, client: IdpClient) -> None:
        # email claim should be string, number should be ignored
        id_token = create_mock_jwt({
            "sub": "usr_123",
            "email": 12345,  # Invalid type
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        })

        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=id_token,
        )

        agent = await client.create_agent(tokens)
        assert agent.email is None

    async def test_email_verified_as_string_is_ignored(self, client: IdpClient) -> None:
        id_token = create_mock_jwt({
            "sub": "usr_123",
            "email_verified": "true",  # Should be boolean
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        })

        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=id_token,
        )

        agent = await client.create_agent(tokens)
        assert agent.email_verified is None

    async def test_sub_as_null_throws_error(self, client: IdpClient) -> None:
        id_token = create_mock_jwt({
            "sub": None,
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        })

        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=id_token,
        )

        with pytest.raises(TokenParseError, match="missing subject"):
            await client.create_agent(tokens)

    async def test_sub_as_empty_string_throws_error(self, client: IdpClient) -> None:
        id_token = create_mock_jwt({
            "sub": "",
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        })

        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=id_token,
        )

        with pytest.raises(TokenParseError, match="missing subject"):
            await client.create_agent(tokens)

    async def test_sub_as_number_throws_error(self, client: IdpClient) -> None:
        id_token = create_mock_jwt({
            "sub": 12345,  # Should be string
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        })

        tokens = TokenSet(
            access_token="token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=id_token,
        )

        with pytest.raises(TokenParseError, match="missing subject"):
            await client.create_agent(tokens)


class TestAuthorizationUrlEdgeCases:
    """Edge case tests for authorization URL generation."""

    @pytest.fixture
    def client(self) -> IdpClient:
        return IdpClient(
            issuer_url="https://example.com",
            client_id="cli",
            redirect_uri="https://example.com/callback",
        )

    def test_scopes_with_special_characters(self, client: IdpClient) -> None:
        result = client.create_authorization_url(
            scopes=["openid", "profile:read", "users/**"]
        )
        # Should URL-encode properly
        assert result.url is not None

    def test_state_with_special_characters(self, client: IdpClient) -> None:
        result = client.create_authorization_url(
            scopes=["openid"],
            state="state=with&special+chars"
        )
        assert result.state == "state=with&special+chars"

    def test_nonce_with_special_characters(self, client: IdpClient) -> None:
        result = client.create_authorization_url(
            scopes=["openid"],
            nonce="nonce=with&special+chars"
        )
        assert "nonce=" in result.url


class TestDictToTokenSetCoercion:
    """Edge case tests for _coerce_token_set."""

    def test_passes_through_token_set_unchanged(self) -> None:
        ts = TokenSet(access_token="tok", token_type="Bearer", expires_at=1234)
        result = _coerce_token_set(ts)
        assert result is ts

    def test_converts_valid_dict(self) -> None:
        d = {"access_token": "tok", "token_type": "Bearer", "expires_at": 1234}
        result = _coerce_token_set(d)
        assert isinstance(result, TokenSet)
        assert result.access_token == "tok"

    def test_extra_keys_ignored(self) -> None:
        d = {"access_token": "tok", "token_type": "Bearer", "expires_at": 1234, "custom_field": "ignored"}
        result = _coerce_token_set(d)
        assert isinstance(result, TokenSet)
        assert result.access_token == "tok"

    def test_missing_required_fields_raises(self) -> None:
        with pytest.raises(Exception):  # Pydantic ValidationError
            _coerce_token_set({"token_type": "Bearer"})

    def test_invalid_type_raises_type_error(self) -> None:
        with pytest.raises(TypeError, match="tokens must be a dict or TokenSet"):
            _coerce_token_set("not a dict")  # type: ignore

        with pytest.raises(TypeError, match="tokens must be a dict or TokenSet"):
            _coerce_token_set(123)  # type: ignore

        with pytest.raises(TypeError, match="tokens must be a dict or TokenSet"):
            _coerce_token_set(None)  # type: ignore
