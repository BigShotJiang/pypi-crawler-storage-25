"""Tests for AuthPI IdP SDK."""
