"""Tests for IdpClient and IdpClientSync."""

from __future__ import annotations

import time
from typing import Any

import pytest
from pytest_httpx import HTTPXMock

from authpi_idp.agent import AuthenticatedAgent, PrincipalType
from authpi_idp.client import IdpClient, IdpClientSync
from authpi_idp.errors import (
    ConfigurationError,
    OAuthError,
    RefreshError,
    SubjectMismatchError,
    TokenExpiredError,
    TokenParseError,
)
from authpi_idp.types import LogoutOptions, TokenSet
from tests.conftest import create_mock_jwt

# Test configuration
VALID_CONFIG = {
    "issuer_url": "https://idp.authpi.com/iss_xxx",
    "client_id": "cli_xxx",
    "client_secret": "secret",
    "redirect_uri": "https://app.example.com/callback",
}


class TestIdpClientConstructor:
    """Tests for IdpClient constructor."""

    def test_creates_client_with_valid_config(self) -> None:
        client = IdpClient(**VALID_CONFIG)
        assert client is not None

    def test_creates_client_without_client_secret_public_client(self) -> None:
        config = {**VALID_CONFIG, "client_secret": None}
        client = IdpClient(**config)
        assert client is not None

    def test_throws_if_issuer_url_is_missing(self) -> None:
        with pytest.raises(ConfigurationError, match="issuer_url is required"):
            IdpClient(issuer_url="", client_id="cli", redirect_uri="https://example.com")

    def test_throws_if_issuer_url_is_whitespace(self) -> None:
        with pytest.raises(ConfigurationError, match="issuer_url is required"):
            IdpClient(issuer_url="   ", client_id="cli", redirect_uri="https://example.com")

    def test_throws_if_client_id_is_missing(self) -> None:
        with pytest.raises(ConfigurationError, match="client_id is required"):
            IdpClient(issuer_url="https://example.com", client_id="", redirect_uri="https://example.com")

    def test_creates_client_without_redirect_uri_for_client_credentials(self) -> None:
        client = IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret",
        )
        assert client is not None

    def test_throws_if_issuer_url_is_not_valid_url(self) -> None:
        with pytest.raises(ConfigurationError, match="issuer_url must be a valid URL"):
            IdpClient(issuer_url="not-a-url", client_id="cli", redirect_uri="https://example.com")

    def test_throws_if_redirect_uri_is_not_valid_url(self) -> None:
        with pytest.raises(ConfigurationError, match="redirect_uri must be a valid URL"):
            IdpClient(issuer_url="https://example.com", client_id="cli", redirect_uri="not-a-url")

    def test_normalizes_issuer_url_removes_trailing_slash(self) -> None:
        client = IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx/",
            client_id="cli",
            redirect_uri="https://example.com",
        )
        # We verify this works correctly in authorization URL tests
        assert client is not None


class TestIdpClientSyncConstructor:
    """Tests for IdpClientSync constructor."""

    def test_creates_client_with_valid_config(self) -> None:
        client = IdpClientSync(**VALID_CONFIG)
        assert client is not None

    def test_creates_client_without_redirect_uri_for_client_credentials(self) -> None:
        client = IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret",
        )
        assert client is not None

    def test_throws_if_issuer_url_is_missing(self) -> None:
        with pytest.raises(ConfigurationError, match="issuer_url is required"):
            IdpClientSync(issuer_url="", client_id="cli")


class TestCreateAuthorizationUrl:
    """Tests for create_authorization_url method."""

    @pytest.fixture
    def client(self) -> IdpClient:
        return IdpClient(**VALID_CONFIG)

    @pytest.fixture
    def sync_client(self) -> IdpClientSync:
        return IdpClientSync(**VALID_CONFIG)

    def test_returns_url_code_verifier_state_and_nonce(self, client: IdpClient) -> None:
        result = client.create_authorization_url(scopes=["openid", "profile"])

        assert result.url is not None
        assert result.code_verifier is not None
        assert result.state is not None
        assert result.nonce is not None

    def test_generates_valid_authorization_url(self, client: IdpClient) -> None:
        result = client.create_authorization_url(scopes=["openid", "profile"])

        assert "https://idp.authpi.com/iss_xxx/authorize" in result.url

    def test_includes_required_oauth_parameters(self, client: IdpClient) -> None:
        result = client.create_authorization_url(scopes=["openid", "profile"])

        assert "client_id=cli_xxx" in result.url
        assert "redirect_uri=" in result.url
        assert "response_type=code" in result.url
        assert "scope=openid+profile" in result.url or "scope=openid%20profile" in result.url

    def test_includes_pkce_code_challenge_s256(self, client: IdpClient) -> None:
        result = client.create_authorization_url(scopes=["openid"])

        assert "code_challenge=" in result.url
        assert "code_challenge_method=S256" in result.url

    def test_generates_cryptographically_secure_code_verifier(self, client: IdpClient) -> None:
        result = client.create_authorization_url(scopes=["openid"])

        # PKCE spec: code_verifier must be 43-128 characters
        assert len(result.code_verifier) >= 43
        assert len(result.code_verifier) <= 128

    def test_generates_unique_code_verifier_each_time(self, client: IdpClient) -> None:
        result1 = client.create_authorization_url(scopes=["openid"])
        result2 = client.create_authorization_url(scopes=["openid"])

        assert result1.code_verifier != result2.code_verifier

    def test_generates_unique_state_each_time(self, client: IdpClient) -> None:
        result1 = client.create_authorization_url(scopes=["openid"])
        result2 = client.create_authorization_url(scopes=["openid"])

        assert result1.state != result2.state

    def test_uses_provided_state_if_given(self, client: IdpClient) -> None:
        result = client.create_authorization_url(
            scopes=["openid"],
            state="custom_state_123",
        )

        assert result.state == "custom_state_123"
        assert "state=custom_state_123" in result.url

    def test_auto_generates_nonce_when_not_provided(self, client: IdpClient) -> None:
        result = client.create_authorization_url(scopes=["openid"])

        assert result.nonce is not None
        assert len(result.nonce) > 0
        assert f"nonce={result.nonce}" in result.url

    def test_uses_provided_nonce_when_given(self, client: IdpClient) -> None:
        result = client.create_authorization_url(
            scopes=["openid"],
            nonce="custom_nonce_value",
        )

        assert result.nonce == "custom_nonce_value"
        assert "nonce=custom_nonce_value" in result.url

    def test_generates_unique_nonce_each_time(self, client: IdpClient) -> None:
        result1 = client.create_authorization_url(scopes=["openid"])
        result2 = client.create_authorization_url(scopes=["openid"])

        assert result1.nonce != result2.nonce

    def test_throws_if_openid_scope_is_not_included(self, client: IdpClient) -> None:
        with pytest.raises(OAuthError, match="openid scope is required"):
            client.create_authorization_url(scopes=["profile"])

    def test_throws_if_scopes_array_is_empty(self, client: IdpClient) -> None:
        with pytest.raises(OAuthError, match="scopes are required"):
            client.create_authorization_url(scopes=[])

    def test_throws_configuration_error_if_redirect_uri_not_configured(self) -> None:
        client = IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret",
        )
        with pytest.raises(ConfigurationError, match="redirect_uri is required for authorization code flow"):
            client.create_authorization_url(scopes=["openid"])

    def test_sync_throws_configuration_error_if_redirect_uri_not_configured(self) -> None:
        client = IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret",
        )
        with pytest.raises(ConfigurationError, match="redirect_uri is required for authorization code flow"):
            client.create_authorization_url(scopes=["openid"])

    # Sync client tests
    def test_sync_returns_url_code_verifier_state_and_nonce(self, sync_client: IdpClientSync) -> None:
        result = sync_client.create_authorization_url(scopes=["openid", "profile"])

        assert result.url is not None
        assert result.code_verifier is not None
        assert result.state is not None
        assert result.nonce is not None


class TestCreateAgent:
    """Tests for create_agent method."""

    @pytest.fixture
    def client(self) -> IdpClient:
        # Disable auto-refresh for unit tests
        return IdpClient(**VALID_CONFIG, auto_refresh=False)

    @pytest.fixture
    def sync_client(self) -> IdpClientSync:
        return IdpClientSync(**VALID_CONFIG, auto_refresh=False)

    async def test_creates_agent_from_valid_tokenset_with_id_token(self, client: IdpClient) -> None:
        id_token_payload = {
            "sub": "usr_123",
            "email": "user@example.com",
            "email_verified": True,
            "organizations": {
                "org_xxx": {
                    "title": "Admin",
                    "scopes": ["users:read", "users:write"],
                    "joined_at": 1700000000,
                },
            },
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        }

        id_token = create_mock_jwt(id_token_payload)

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            refresh_token="refresh_token",
            id_token=id_token,
            scope="openid profile email",
        )

        agent = await client.create_agent(tokens)

        assert agent.id == "usr_123"
        assert agent.email == "user@example.com"
        assert agent.email_verified is True
        assert len(agent.organizations) == 1
        assert agent.organizations[0].id == "org_xxx"
        assert agent.organizations[0].scopes == ["users:read", "users:write"]

    async def test_creates_agent_from_dict_input(self, client: IdpClient) -> None:
        """Test that create_agent accepts a plain dict."""
        id_token_payload = {
            "sub": "usr_123",
            "email": "user@example.com",
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        }

        tokens_dict = {
            "access_token": "access_token",
            "token_type": "Bearer",
            "expires_at": int(time.time()) + 3600,
            "refresh_token": "refresh_token",
            "id_token": create_mock_jwt(id_token_payload),
            "scope": "openid profile email",
        }

        agent = await client.create_agent(tokens_dict)

        assert agent.id == "usr_123"
        assert agent.email == "user@example.com"

    async def test_falls_back_to_client_credentials_agent_when_id_token_missing(self, client: IdpClient) -> None:
        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            scope="openid",
        )

        agent = await client.create_agent(tokens)
        assert agent.id == "cli_xxx"
        assert agent.organizations == []

    async def test_throws_if_id_token_is_malformed(self, client: IdpClient) -> None:
        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token="not.a.valid.jwt",
            scope="openid",
        )

        with pytest.raises(TokenParseError):
            await client.create_agent(tokens)

    async def test_throws_if_id_token_is_missing_sub_claim(self, client: IdpClient) -> None:
        id_token_payload = {
            "email": "user@example.com",
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        }

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=create_mock_jwt(id_token_payload),
            scope="openid",
        )

        with pytest.raises(TokenParseError, match="missing subject"):
            await client.create_agent(tokens)

    async def test_handles_id_token_without_organizations_claim(self, client: IdpClient) -> None:
        id_token_payload = {
            "sub": "usr_123",
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        }

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=create_mock_jwt(id_token_payload),
            scope="openid",
        )

        agent = await client.create_agent(tokens)
        assert agent.organizations == []

    async def test_determines_agent_type_from_subject_prefix(self, client: IdpClient) -> None:
        user_token = create_mock_jwt({"sub": "usr_123", "exp": 9999999999, "iat": 1})
        api_key_token = create_mock_jwt({"sub": "key_456", "exp": 9999999999, "iat": 1})
        personal_token = create_mock_jwt({"sub": "tok_789", "exp": 9999999999, "iat": 1})
        agent_token = create_mock_jwt({"sub": "agt_abc", "exp": 9999999999, "iat": 1})

        base_tokens = {
            "access_token": "access",
            "token_type": "Bearer",
            "expires_at": 9999999999,
            "scope": "openid",
        }

        user_agent = await client.create_agent(TokenSet(**base_tokens, id_token=user_token))
        api_key_agent = await client.create_agent(TokenSet(**base_tokens, id_token=api_key_token))
        personal_agent = await client.create_agent(TokenSet(**base_tokens, id_token=personal_token))
        agent_agent = await client.create_agent(TokenSet(**base_tokens, id_token=agent_token))

        assert user_agent.type == PrincipalType.USER
        assert api_key_agent.type == PrincipalType.API_KEY
        assert personal_agent.type == PrincipalType.PERSONAL_TOKEN
        assert agent_agent.type == PrincipalType.AGENT

    # Sync client tests
    def test_sync_creates_agent_from_valid_tokenset(self, sync_client: IdpClientSync) -> None:
        id_token_payload = {
            "sub": "usr_123",
            "email": "user@example.com",
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        }

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=create_mock_jwt(id_token_payload),
            scope="openid",
        )

        agent = sync_client.create_agent(tokens)
        assert agent.id == "usr_123"

    def test_sync_creates_agent_from_dict_input(self, sync_client: IdpClientSync) -> None:
        """Test that sync create_agent accepts a plain dict."""
        id_token_payload = {
            "sub": "usr_123",
            "email": "user@example.com",
            "exp": int(time.time()) + 3600,
            "iat": int(time.time()),
        }

        tokens_dict = {
            "access_token": "access_token",
            "token_type": "Bearer",
            "expires_at": int(time.time()) + 3600,
            "id_token": create_mock_jwt(id_token_payload),
            "scope": "openid",
        }

        agent = sync_client.create_agent(tokens_dict)
        assert agent.id == "usr_123"


class TestExchangeCode:
    """Tests for exchange_code method."""

    @pytest.fixture
    def client(self) -> IdpClient:
        return IdpClient(**VALID_CONFIG)

    async def test_throws_configuration_error_if_redirect_uri_not_configured(self) -> None:
        client = IdpClient(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret",
        )
        with pytest.raises(ConfigurationError, match="redirect_uri is required for authorization code flow"):
            await client.exchange_code("auth_code", "code_verifier")

    def test_sync_throws_configuration_error_if_redirect_uri_not_configured(self) -> None:
        client = IdpClientSync(
            issuer_url="https://idp.authpi.com/iss_xxx",
            client_id="cli_xxx",
            client_secret="secret",
        )
        with pytest.raises(ConfigurationError, match="redirect_uri is required for authorization code flow"):
            client.exchange_code("auth_code", "code_verifier")

    async def test_exchanges_code_for_agent(
        self, client: IdpClient, httpx_mock: HTTPXMock, valid_token_response: dict[str, Any]
    ) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json=valid_token_response,
        )

        agent = await client.exchange_code("auth_code", "code_verifier")

        assert agent.id == "usr_123"
        assert agent.email == "user@example.com"

    async def test_throws_oauth_error_on_failure(self, client: IdpClient, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            status_code=400,
            json={"error": "invalid_grant", "error_description": "Code expired"},
        )

        with pytest.raises(OAuthError, match="Code expired"):
            await client.exchange_code("auth_code", "code_verifier")


class TestRefresh:
    """Tests for refresh method."""

    @pytest.fixture
    def client(self) -> IdpClient:
        return IdpClient(**VALID_CONFIG, auto_refresh=False)

    async def test_refreshes_tokens_and_returns_new_agent(
        self, client: IdpClient, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "new_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "refresh_token": "new_refresh_token",
                "id_token": valid_id_token,
            },
        )

        old_tokens = TokenSet(
            access_token="old_access_token",
            token_type="Bearer",
            expires_at=int(time.time()) - 100,  # Expired
            refresh_token="old_refresh_token",
            id_token=valid_id_token,
        )
        old_agent = await client.create_agent(old_tokens)

        new_agent = await client.refresh(old_agent)

        assert new_agent.tokens.access_token == "new_access_token"
        assert new_agent.tokens.refresh_token == "new_refresh_token"

    async def test_throws_token_expired_if_no_refresh_token(self, client: IdpClient, valid_id_token: str) -> None:
        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=valid_id_token,
        )
        agent = await client.create_agent(tokens)

        with pytest.raises(TokenExpiredError, match="No refresh token available"):
            await client.refresh(agent)

    async def test_throws_refresh_error_on_failure(
        self, client: IdpClient, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            status_code=400,
            json={"error": "invalid_grant", "error_description": "Refresh token expired"},
        )

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            refresh_token="refresh_token",
            id_token=valid_id_token,
        )
        agent = await client.create_agent(tokens)

        with pytest.raises(RefreshError, match="Refresh token expired"):
            await client.refresh(agent)

    async def test_fetches_userinfo_if_no_id_token_returned_on_refresh(
        self, client: IdpClient, httpx_mock: HTTPXMock, valid_id_token: str, valid_userinfo_response: dict[str, Any]
    ) -> None:
        # First call returns no id_token
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "new_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "refresh_token": "new_refresh_token",
                # No id_token
            },
        )

        # Second call to userinfo
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/userinfo",
            method="GET",
            json=valid_userinfo_response,
        )

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            refresh_token="refresh_token",
            id_token=valid_id_token,
        )
        agent = await client.create_agent(tokens)

        new_agent = await client.refresh(agent)

        assert new_agent.id == "usr_123"
        assert new_agent.tokens.access_token == "new_access_token"

    async def test_throws_subject_mismatch_on_different_sub(
        self, client: IdpClient, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        # Token refresh without id_token
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "new_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
            },
        )

        # Userinfo returns different sub
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/userinfo",
            method="GET",
            json={"sub": "usr_different"},
        )

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            refresh_token="refresh_token",
            id_token=valid_id_token,
        )
        agent = await client.create_agent(tokens)

        with pytest.raises(SubjectMismatchError):
            await client.refresh(agent)

    async def test_throws_subject_mismatch_when_id_token_has_different_sub(
        self, client: IdpClient, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        """Security: Verify subject mismatch is detected when refresh returns id_token with different sub."""
        # Create an id_token with a different subject
        different_sub_token = create_mock_jwt({
            "sub": "usr_different",
            "email": "other@example.com",
            "email_verified": True,
        })

        # Token refresh returns id_token with different sub
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "new_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "id_token": different_sub_token,
            },
        )

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            refresh_token="refresh_token",
            id_token=valid_id_token,
        )
        agent = await client.create_agent(tokens)

        with pytest.raises(SubjectMismatchError):
            await client.refresh(agent)

    async def test_clears_orgs_when_userinfo_returns_empty_list(
        self, client: IdpClient, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        """Security: User removed from all orgs should have empty organizations, not stale ones."""
        # Token refresh without id_token
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "new_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "refresh_token": "new_refresh_token",
                # No id_token
            },
        )

        # Userinfo returns empty organizations (user was removed from all orgs)
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/userinfo",
            method="GET",
            json={
                "sub": "usr_123",
                "email": "user@example.com",
                "organizations": {},  # Empty - user removed from all orgs
            },
        )

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            refresh_token="refresh_token",
            id_token=valid_id_token,  # Original token has organizations
        )
        agent = await client.create_agent(tokens)
        # Verify agent starts with organizations
        assert len(agent.organizations) > 0

        new_agent = await client.refresh(agent)

        # Security: Organizations should be empty, not preserved from old token
        assert new_agent.organizations == []


class TestRefreshSync:
    """Tests for refresh method on sync client - security edge cases."""

    @pytest.fixture
    def client(self) -> IdpClientSync:
        return IdpClientSync(**VALID_CONFIG, auto_refresh=False)

    def test_sync_throws_subject_mismatch_when_id_token_has_different_sub(
        self, client: IdpClientSync, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        """Security: Verify subject mismatch is detected when refresh returns id_token with different sub."""
        # Create an id_token with a different subject
        different_sub_token = create_mock_jwt({
            "sub": "usr_different",
            "email": "other@example.com",
            "email_verified": True,
        })

        # Token refresh returns id_token with different sub
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "new_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "id_token": different_sub_token,
            },
        )

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            refresh_token="refresh_token",
            id_token=valid_id_token,
        )
        agent = client.create_agent(tokens)

        with pytest.raises(SubjectMismatchError):
            client.refresh(agent)

    def test_sync_clears_orgs_when_userinfo_returns_empty_list(
        self, client: IdpClientSync, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        """Security: User removed from all orgs should have empty organizations, not stale ones."""
        # Token refresh without id_token
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "new_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "refresh_token": "new_refresh_token",
                # No id_token
            },
        )

        # Userinfo returns empty organizations (user was removed from all orgs)
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/userinfo",
            method="GET",
            json={
                "sub": "usr_123",
                "email": "user@example.com",
                "organizations": {},  # Empty - user removed from all orgs
            },
        )

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            refresh_token="refresh_token",
            id_token=valid_id_token,  # Original token has organizations
        )
        agent = client.create_agent(tokens)
        # Verify agent starts with organizations
        assert len(agent.organizations) > 0

        new_agent = client.refresh(agent)

        # Security: Organizations should be empty, not preserved from old token
        assert new_agent.organizations == []


class TestAutoRefresh:
    """Tests for auto-refresh behavior."""

    async def test_auto_refreshes_expired_tokens(
        self, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        # Enable auto-refresh
        client = IdpClient(**VALID_CONFIG, auto_refresh=True, refresh_buffer_seconds=60)

        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            json={
                "access_token": "new_access_token",
                "token_type": "Bearer",
                "expires_in": 3600,
                "refresh_token": "new_refresh_token",
                "id_token": valid_id_token,
            },
        )

        # Create tokens that are about to expire (within buffer)
        tokens = TokenSet(
            access_token="old_access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 30,  # Expires in 30s, buffer is 60s
            refresh_token="refresh_token",
            id_token=valid_id_token,
        )

        refreshed_tokens: list[dict[str, Any]] = []

        agent = await client.create_agent(
            tokens,
            on_refresh=lambda t: refreshed_tokens.append(t),
        )

        assert agent.tokens.access_token == "new_access_token"
        assert len(refreshed_tokens) == 1
        assert refreshed_tokens[0]["access_token"] == "new_access_token"

    async def test_does_not_auto_refresh_if_disabled(self, valid_id_token: str) -> None:
        client = IdpClient(**VALID_CONFIG, auto_refresh=False)

        # Create expired tokens
        tokens = TokenSet(
            access_token="old_access_token",
            token_type="Bearer",
            expires_at=int(time.time()) - 100,  # Already expired
            refresh_token="refresh_token",
            id_token=valid_id_token,
        )

        # Should not throw, just return the agent with expired tokens
        agent = await client.create_agent(tokens)
        assert agent.tokens.access_token == "old_access_token"

    async def test_calls_on_refresh_error_callback_on_failure(
        self, httpx_mock: HTTPXMock, valid_id_token: str
    ) -> None:
        client = IdpClient(**VALID_CONFIG, auto_refresh=True, refresh_buffer_seconds=60)

        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/token",
            method="POST",
            status_code=400,
            json={"error": "invalid_grant", "error_description": "Token revoked"},
        )

        tokens = TokenSet(
            access_token="old_access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 30,
            refresh_token="refresh_token",
            id_token=valid_id_token,
        )

        errors: list[Exception] = []

        with pytest.raises(RefreshError):
            await client.create_agent(
                tokens,
                on_refresh_error=lambda e: errors.append(e),
            )

        assert len(errors) == 1
        assert isinstance(errors[0], RefreshError)


class TestGetUserInfo:
    """Tests for get_user_info method."""

    @pytest.fixture
    def client(self) -> IdpClient:
        return IdpClient(**VALID_CONFIG, auto_refresh=False)

    async def test_fetches_user_info(
        self, client: IdpClient, httpx_mock: HTTPXMock, valid_id_token: str, valid_userinfo_response: dict[str, Any]
    ) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/userinfo",
            method="GET",
            json=valid_userinfo_response,
        )

        tokens = TokenSet(
            access_token="access_token",
            token_type="Bearer",
            expires_at=int(time.time()) + 3600,
            id_token=valid_id_token,
        )
        agent = await client.create_agent(tokens)

        userinfo = await client.get_user_info(agent)

        assert userinfo.sub == "usr_123"
        assert userinfo.email == "user@example.com"
        assert userinfo.name == "Test User"

    async def test_preserves_custom_claims_from_userinfo(self, client: IdpClient, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/userinfo",
            method="GET",
            json={
                "sub": "usr_123",
                "email": "test@example.com",
                "custom_field": "custom_value",
                "department": "engineering",
            },
        )

        agent = AuthenticatedAgent(
            id="usr_123",
            type=PrincipalType.USER,
            tokens=TokenSet(access_token="token", token_type="Bearer", expires_at=9999999999),
            organizations=[],
        )

        user_info = await client.get_user_info(agent)
        assert user_info.sub == "usr_123"
        assert user_info.custom_field == "custom_value"
        assert user_info.department == "engineering"


class TestCreateLogoutUrl:
    """Tests for create_logout_url method."""

    @pytest.fixture
    def client(self) -> IdpClient:
        return IdpClient(**VALID_CONFIG)

    def test_returns_logout_url(self, client: IdpClient) -> None:
        url = client.create_logout_url()
        assert "iss_xxx/logout" in url

    def test_includes_id_token_hint_if_provided(self, client: IdpClient) -> None:
        url = client.create_logout_url(LogoutOptions(id_token_hint="id_token_value"))
        assert "id_token_hint=id_token_value" in url

    def test_includes_post_logout_redirect_uri_if_provided(self, client: IdpClient) -> None:
        url = client.create_logout_url(
            LogoutOptions(post_logout_redirect_uri="https://app.example.com/logged-out")
        )
        assert "post_logout_redirect_uri=" in url

    def test_includes_state_if_provided(self, client: IdpClient) -> None:
        url = client.create_logout_url(LogoutOptions(state="logout_state"))
        assert "state=logout_state" in url


class TestRevokeToken:
    """Tests for revoke_token method."""

    @pytest.fixture
    def client(self) -> IdpClient:
        return IdpClient(**VALID_CONFIG)

    async def test_revokes_token(self, client: IdpClient, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/revoke",
            method="POST",
            status_code=200,
        )

        # Should not raise
        await client.revoke_token("some_token", "refresh_token")

    async def test_throws_on_revocation_failure(self, client: IdpClient, httpx_mock: HTTPXMock) -> None:
        httpx_mock.add_response(
            url="https://idp.authpi.com/iss_xxx/revoke",
            method="POST",
            status_code=500,
            json={"error": "server_error", "error_description": "Internal error"},
        )

        with pytest.raises(OAuthError, match="Internal error"):
            await client.revoke_token("some_token")


class TestContextManager:
    """Tests for context manager support."""

    async def test_async_context_manager(self) -> None:
        async with IdpClient(**VALID_CONFIG) as client:
            result = client.create_authorization_url(scopes=["openid"])
            assert result.url is not None

    def test_sync_context_manager(self) -> None:
        with IdpClientSync(**VALID_CONFIG) as client:
            result = client.create_authorization_url(scopes=["openid"])
            assert result.url is not None
