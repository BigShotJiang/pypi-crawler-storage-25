"""Test fixtures and helpers for AuthPI IdP SDK tests."""

from __future__ import annotations

import base64
import json
import time
from typing import Any

import pytest

from authpi_idp.types import Organization, TokenSet


def create_mock_jwt(payload: dict[str, Any]) -> str:
    """Create a mock JWT (header.payload.signature) for testing."""
    header = {"alg": "RS256", "typ": "JWT"}
    encoded_header = base64url_encode(json.dumps(header))
    encoded_payload = base64url_encode(json.dumps(payload))
    signature = "mock_signature"
    return f"{encoded_header}.{encoded_payload}.{signature}"


def base64url_encode(data: str) -> str:
    """Base64URL encode a string."""
    return base64.urlsafe_b64encode(data.encode()).rstrip(b"=").decode()


@pytest.fixture
def mock_organizations() -> list[Organization]:
    """Mock organizations for testing."""
    return [
        Organization(
            id="org_admin",
            title="Admin",
            scopes=["users:read", "users:write", "projects:**"],
            joined_at=1700000000,
        ),
        Organization(
            id="org_member",
            title=None,
            scopes=["member"],
            joined_at=1700000001,
        ),
        Organization(
            id="org_owner",
            title="Founder",
            scopes=["owner", "admin", "*:**"],
            joined_at=1700000002,
        ),
    ]


@pytest.fixture
def mock_tokens() -> TokenSet:
    """Mock token set for testing."""
    return TokenSet(
        access_token="access_token_value",
        token_type="Bearer",
        expires_at=int(time.time()) + 3600,  # 1 hour from now
        refresh_token="refresh_token_value",
        id_token="id_token_value",
        scope="openid profile email",
    )


@pytest.fixture
def valid_id_token() -> str:
    """Create a valid mock ID token."""
    payload = {
        "sub": "usr_123",
        "email": "user@example.com",
        "email_verified": True,
        "organizations": {
            "org_xxx": {
                "title": "Admin",
                "scopes": ["users:read", "users:write"],
                "joined_at": 1700000000,
            },
        },
        "exp": int(time.time()) + 3600,
        "iat": int(time.time()),
    }
    return create_mock_jwt(payload)


@pytest.fixture
def valid_token_response(valid_id_token: str) -> dict[str, Any]:
    """Create a valid token response from the token endpoint."""
    return {
        "access_token": "access_token_value",
        "token_type": "Bearer",
        "expires_in": 3600,
        "refresh_token": "refresh_token_value",
        "id_token": valid_id_token,
        "scope": "openid profile email",
    }


@pytest.fixture
def valid_userinfo_response() -> dict[str, Any]:
    """Create a valid userinfo response."""
    return {
        "sub": "usr_123",
        "email": "user@example.com",
        "email_verified": True,
        "name": "Test User",
        "given_name": "Test",
        "family_name": "User",
        "organizations": {
            "org_xxx": {
                "title": "Admin",
                "scopes": ["users:read", "users:write"],
                "joined_at": 1700000000,
            },
        },
    }
