"""Tests for error types."""

import pytest

from authpi_idp import (
    OAuthError,
    InsufficientScopeError,
    SessionExpiredError,
    UserBlockedError,
    AccountLinkingRequiredError,
    InteractionRequiredError,
    LoginRequiredError,
    ConsentRequiredError,
)


def test_insufficient_scope_error():
    err = InsufficientScopeError("Need users:write")
    assert isinstance(err, OAuthError)
    assert err.error == "insufficient_scope"


def test_session_expired_error():
    err = SessionExpiredError()
    assert isinstance(err, OAuthError)
    assert err.error == "session_expired"


def test_user_blocked_error():
    err = UserBlockedError()
    assert isinstance(err, OAuthError)
    assert err.error == "user_blocked"


def test_account_linking_required_error():
    err = AccountLinkingRequiredError()
    assert isinstance(err, OAuthError)
    assert err.error == "account_linking_required"


def test_interaction_required_error():
    err = InteractionRequiredError()
    assert isinstance(err, OAuthError)
    assert err.error == "interaction_required"


def test_login_required_error():
    err = LoginRequiredError()
    assert isinstance(err, OAuthError)
    assert err.error == "login_required"


def test_consent_required_error():
    err = ConsentRequiredError()
    assert isinstance(err, OAuthError)
    assert err.error == "consent_required"
