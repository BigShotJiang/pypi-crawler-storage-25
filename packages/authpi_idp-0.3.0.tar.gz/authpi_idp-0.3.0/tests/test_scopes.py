"""Tests for scope parsing and evaluation."""

import pytest

from authpi_idp.scopes import has_access, parse_scope


class TestParseScope:
    """Tests for parse_scope function."""

    def test_parses_simple_scope(self) -> None:
        result = parse_scope("users:read")
        assert result is not None
        assert result.resource == "users"
        assert result.action == "read"

    def test_parses_nested_resource(self) -> None:
        result = parse_scope("users.verifiers:write")
        assert result is not None
        assert result.resource == "users.verifiers"
        assert result.action == "write"

    def test_parses_wildcard_action(self) -> None:
        result = parse_scope("projects:*")
        assert result is not None
        assert result.resource == "projects"
        assert result.action == "*"

    def test_parses_recursive_wildcard_action(self) -> None:
        result = parse_scope("projects:**")
        assert result is not None
        assert result.resource == "projects"
        assert result.action == "**"

    def test_parses_global_wildcard(self) -> None:
        result = parse_scope("*:**")
        assert result is not None
        assert result.resource == "*"
        assert result.action == "**"

    def test_returns_none_for_invalid_scope_no_colon(self) -> None:
        assert parse_scope("invalid") is None

    def test_returns_none_for_empty_string(self) -> None:
        assert parse_scope("") is None

    def test_returns_none_for_scope_with_empty_action(self) -> None:
        assert parse_scope("users:") is None

    def test_returns_none_for_scope_with_empty_resource(self) -> None:
        assert parse_scope(":read") is None


class TestHasAccessExactMatches:
    """Tests for exact scope matching."""

    def test_matches_exact_scope(self) -> None:
        assert has_access(["users:read"], "read", "users") is True

    def test_does_not_match_different_action(self) -> None:
        assert has_access(["users:read"], "write", "users") is False

    def test_does_not_match_different_resource(self) -> None:
        assert has_access(["users:read"], "read", "projects") is False

    def test_matches_nested_resource_exactly(self) -> None:
        assert has_access(["users.verifiers:read"], "read", "users.verifiers") is True


class TestHasAccessSingleWildcard:
    """Tests for single wildcard (*) - same level only."""

    def test_matches_any_action_on_exact_resource(self) -> None:
        assert has_access(["users:*"], "read", "users") is True
        assert has_access(["users:*"], "write", "users") is True
        assert has_access(["users:*"], "delete", "users") is True
        assert has_access(["users:*"], "manage", "users") is True

    def test_does_not_match_sub_resources(self) -> None:
        assert has_access(["users:*"], "read", "users.verifiers") is False

    def test_does_not_match_different_resource(self) -> None:
        assert has_access(["users:*"], "read", "projects") is False

    def test_matches_when_resource_has_single_wildcard(self) -> None:
        assert has_access(["*:read"], "read", "users") is True
        assert has_access(["*:read"], "read", "projects") is True

    def test_resource_wildcard_does_not_match_nested_resources(self) -> None:
        assert has_access(["*:read"], "read", "users.verifiers") is False


class TestHasAccessRecursiveWildcard:
    """Tests for recursive wildcard (**) - all sub-resources."""

    def test_matches_exact_resource(self) -> None:
        assert has_access(["users:**"], "read", "users") is True

    def test_matches_direct_sub_resource(self) -> None:
        assert has_access(["users:**"], "read", "users.verifiers") is True

    def test_matches_deeply_nested_sub_resource(self) -> None:
        assert has_access(["users:**"], "read", "users.verifiers.backup") is True

    def test_matches_any_action_on_resource_and_sub_resources(self) -> None:
        assert has_access(["users:**"], "read", "users") is True
        assert has_access(["users:**"], "write", "users") is True
        assert has_access(["users:**"], "delete", "users.verifiers") is True
        assert has_access(["users:**"], "manage", "users.verifiers.backup") is True

    def test_does_not_match_unrelated_resource(self) -> None:
        assert has_access(["users:**"], "read", "projects") is False

    def test_does_not_match_parent_resource(self) -> None:
        assert has_access(["users.verifiers:**"], "read", "users") is False


class TestHasAccessSuperAdmin:
    """Tests for super admin (*:**) scope."""

    def test_matches_any_resource_and_action(self) -> None:
        assert has_access(["*:**"], "read", "users") is True
        assert has_access(["*:**"], "write", "projects") is True
        assert has_access(["*:**"], "delete", "organizations") is True

    def test_matches_nested_resources(self) -> None:
        assert has_access(["*:**"], "read", "users.verifiers") is True
        assert has_access(["*:**"], "write", "users.verifiers.backup") is True


class TestHasAccessMultipleScopes:
    """Tests for multiple scope evaluation."""

    def test_matches_if_any_scope_grants_access(self) -> None:
        scopes = ["users:read", "projects:write"]
        assert has_access(scopes, "read", "users") is True
        assert has_access(scopes, "write", "projects") is True

    def test_does_not_match_if_no_scope_grants_access(self) -> None:
        scopes = ["users:read", "projects:write"]
        assert has_access(scopes, "delete", "users") is False
        assert has_access(scopes, "read", "organizations") is False

    def test_wildcard_scope_takes_precedence(self) -> None:
        scopes = ["users:read", "users:**"]
        assert has_access(scopes, "delete", "users") is True
        assert has_access(scopes, "write", "users.verifiers") is True


class TestHasAccessEdgeCases:
    """Tests for edge cases."""

    def test_returns_false_for_empty_scopes_array(self) -> None:
        assert has_access([], "read", "users") is False

    def test_ignores_invalid_scopes(self) -> None:
        assert has_access(["invalid", "users:read"], "read", "users") is True
        assert has_access(["invalid"], "read", "users") is False

    def test_handles_scopes_with_special_characters_in_resource_name(self) -> None:
        assert has_access(["api-keys:read"], "read", "api-keys") is True
