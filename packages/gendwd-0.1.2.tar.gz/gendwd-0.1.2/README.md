# genDWD: Generalized Distance Weighted Discrimination

**genDWD** is a high-performance Python implementation of the Generalized Distance Weighted Discrimination (DWD) algorithm. 

While **Support Vector Machines (SVM)** are widely used, they often suffer from the "data piling" phenomenon in **HDLSS (High Dimensional Low Sample Size)** settings, where many data points project onto the same location on the decision boundary, leading to poor generalization. DWD was specifically developed to overcome this by accounting for the relative distance of all data points, providing better robustness in high-dimensional spaces.

Originally formulated for binary classification, this implementation extends the algorithm's utility by featuring built-in **Multiclass classification** support, enabling its application to complex, real-world datasets with multiple categories. It is designed to handle these tasks efficiently using the sGS-ADMM framework for large-scale optimization.

---

## Core Research Basis

This implementation is strictly constructed based on the numerical procedures described in the following scientific paper:

> **"Fast algorithms for large scale generalized distance weighted discrimination"**
>
> *Xin Yee Lam, J.S. Marron, Defeng Sun, and Kim-Chuan Toh (September 5, 2018)*

## Key Features

- **Automatic Detection**: Automatically switches between Binary and Multiclass (One-vs-One) logic.
- **Adaptive Solvers**: Dynamically selects between Cholesky Decomposition, Sherman-Morrison-Woodbury (SMW) formula, or PSQMR based on n (data) and d (features).
- **sGS-ADMM Framework**: Ensures fast convergence using Symmetric Gauss-Seidel ADMM.
- **Penalty Tuning**: Automatic C parameter calculation using median inter-class distance.

## Quick Start

1. Install the package:
```bash
pip install genDWD
```

## Implementation Guide

To use the `genDWD` class in your project, follow the instructions below. The model follows the standard `.fit()` and `.predict()` pattern.

### 1. Basic Initialization
You can customize the model during initialization. The parameter `C='auto'` is recommended as it calculates the penalty based on the dataset's geometry.

```python
from gendwd import genDWD

model = genDWD(C='auto')
```

### 2. Model Training and Prediction

The model follows the familiar `.fit()` and `.predict()` workflow. It automatically handles both binary and multiclass data.

#### Training the Model
To train the model, pass your feature matrix `X` and label vector `y`. The algorithm will automatically detect if it should use a binary or multiclass (One-vs-One) strategy.

##### Example:

```python
from sklearn.datasets import load_breast_cancer

#Load Breast Cancer Dataset
data = load_breast_cancer()
X, y = data.data, data.target

model.fit(X, y)

y_pred = model.predict(X) 

print(f"Accuracy : {np.mean(y_pred==y)*100} %")
```

# Acknowledgments

I would like to express my sincere gratitude to the following individuals for their invaluable support and guidance during the development of this project:

* **Adilan Widyawan Mahdiyasa, S.Si., M.Si., Ph.D.**, for the academic guidance, mentorship, and insights into the mathematical foundations of optimization and discrimination algorithms.
* **Ika Widya Palupi, Marshanda Nalurita Serlaloy, Puan Amalia Islamiati, and Radithya Rizky Syandana**, for their unwavering support, meaningful discussions, and generous contributions of time and effort throughout the coding, debugging, and testing phases of this project.

Their contributions have been instrumental in making this implementation of the genDWD algorithm possible.