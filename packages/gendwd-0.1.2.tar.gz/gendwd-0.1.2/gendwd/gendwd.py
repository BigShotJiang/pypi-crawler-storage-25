import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.spatial.distance import cdist

class genDWD:
    def __init__(self, C='auto', q=1, maxIter=2000):
       
        self.C = C
        self.q = q
        self.maxIter = maxIter
        
  
        
        self.is_multiclass = False
        self.classes_ = None
        self.w_ = None
        self.beta_ = None
        self.history_ = None
        self.models_ = None
        
    def _Newton_Method(self, a, q, sigma, s_old, max_iter=20, tol=1e-8):
        s = np.maximum(s_old, 1e-10)
        inv_sigma = 1.0 / sigma
        c1 = q * (q + 2) * inv_sigma
        c2 = q * (q + 1) * inv_sigma

        for i in range(max_iter):
            s_safe = np.minimum(s, 1e10)
            s_q1 = s_safe**(q + 1)
            s_q2 = s_safe**(q + 2)

            numerator = c1 + a * s_q1
            denominator = c2 + s_q2

            s_next = s * (numerator / (denominator + 1e-15))
            s_next = np.maximum(1e-10, s_next)

            if np.max(np.abs(s_next - s)) < tol:
                return s_next

            s = s_next
        return s

    def _penalty_parameter(self, X, y, expon=1, rmzeroFea=True, scaleFea=True):
        dim, n = X.shape 
        if rmzeroFea:
            normX = np.sqrt(np.sum(X**2, axis=1))
            nzrow = np.where(normX > 0)[0]
            if len(nzrow) < len(normX):
                X = X[nzrow, :]
                dim = X.shape[0]

        if scaleFea:
            if dim > 0.5 * n:
                normX = np.sqrt(np.sum(X**2, axis=1))
                if np.max(normX) > 2 * np.min(normX):
                    if dim > 3 * n:
                        scaling_vec = 1.0 / np.maximum(1, np.sqrt(normX))
                    else:
                        scaling_vec = 1.0 / np.maximum(1, normX)
                    X = X * scaling_vec[:, np.newaxis]

        positive = np.where(y == 1)[0]
        negative = np.where(y == -1)[0]

        limit = 100 if (dim > 1e4 and n > 1e4) else 200

        if len(positive) > limit:
            positive = np.random.choice(positive, limit, replace=False)
        if len(negative) > limit:
            negative = np.random.choice(negative, limit, replace=False)

        posX = X[:, positive].T 
        negX = X[:, negative].T 

        ddist = cdist(negX, posX, metric='euclidean')
        dd = np.median(ddist)

        if expon == 1:
            const = np.log(n) * (max(1000, dim)**(1/3))
        else:
            const = 10 * np.log(n) * (max(1000, dim)**(1/3))

        C = (10**(expon + 1)) * max(1, const / (dd**(expon + 1)))
        return C

    def _matvec_A(self, x, Z, y, const):
        dim = Z.shape[0] 
        n = Z.shape[1]   
        
        x = x.reshape(-1, 1)
        w_part = x[:dim, :]      
        beta_part = x[dim:, :]   

        Ztw = Z.T @ w_part       
        ZZtw = Z @ Ztw           
        y_vec = y.reshape(-1, 1) 
        Zy_beta = Z @ (y_vec * beta_part) 
        
        upper = ZZtw + (const * w_part) + Zy_beta
        lower_left = y_vec.T @ Ztw
        lower_right = (y_vec.T @ y_vec) * beta_part
        lower = lower_left + lower_right 

        return np.vstack((upper, lower))

    def _psqmr_solver(self, Z, y, rhs, x0, const, tol=1e-6, max_iter=100):
        r = rhs - self._matvec_A(x0, Z, y, const)
        q = r.copy()
        tau = np.linalg.norm(q)
        theta = 0.0
        d = np.zeros_like(x0)
        x = x0.copy()
        
        for k in range(1, max_iter + 1):
            Aq = self._matvec_A(q, Z, y, const)
            num = r.T @ r
            den = q.T @ Aq
            alpha_k = num / (den + 1e-12)
            
            r_next = r - alpha_k * Aq
            theta_next = np.linalg.norm(r_next) / (tau + 1e-12)
            c_k = 1.0 / np.sqrt(1 + theta_next**2)
            
            tau_next = tau * theta_next * c_k
            d = (c_k**2 * theta**2) * d + (c_k**2 * alpha_k) * q
            x = x + d
            
            if tau_next < tol: 
                break
                
            beta_k = (r_next.T @ r_next) / (num + 1e-12)
            q = r_next + beta_k * q
            r, theta, tau = r_next, theta_next, tau_next
            
        return x

    def _binary_fit(self, X, y, C_val):
       
        X = X.T
        dim, n = X.shape

        if C_val == 'auto':
            C_val = self._penalty_parameter(X, y)
            

        Zscale = np.linalg.norm(X, 'fro')
        Z = X * y.reshape(1, -1) / Zscale

        sigma = min(10 * C_val, n)**self.q
        normZ = 1 + np.sqrt(np.max(np.sum(Z * Z, axis=0)))

        r = np.ones((n, 1))
        wbeta = np.zeros((dim+1, 1))
        u = np.zeros((dim, 1))
        xi = np.zeros((n, 1))
        alpha = np.zeros((n, 1))
        p = np.zeros((dim, 1))
        tau = 1.618
        const = 1.0
        tol = 1e-5

        

        use_psqmr = (dim > 3000 and n > 3000) 
        use_smw = (dim > 3000 and n <= 3000)  
        use_cholesky = not use_psqmr and not use_smw

       

        if use_cholesky:
            A1 = Z @ Z.T + const * np.eye(dim)
            A2 = Z @ y.reshape(-1, 1)
            A3 = A2.T
            A4 = y.reshape(1, -1) @ y.reshape(-1, 1)
            A = np.block([[A1, A2], [A3, A4]]) 
            A += 1e-9 * np.eye(A.shape[0]) 
            A_factor = cho_factor(A)
        elif use_smw:
            D_inv = 1.0 / const
            norm_y_sq = np.sum(y**2)
            J_utama = np.eye(n) + D_inv * (Z.T @ Z)
            J_factor = cho_factor(J_utama)
            y_vec = y.flatten()
            J_inv_y = cho_solve(J_factor, y_vec)
            denom_smw = 1.0 + (1.0 / norm_y_sq) * (y_vec @ J_inv_y) - 1.0
            inv_D_hat = np.concatenate([np.full(dim, D_inv), [1.0 / norm_y_sq]])

        def solver_system(r_val, xi_val, alpha_val, u_val, p_val, sigma, wbeta):
            tmp = r_val - xi_val + alpha_val / sigma
            rhs1 = Z @ tmp + const * u_val + p_val / sigma
            rhs2 = y.T @ tmp
            rhs = np.vstack((rhs1, rhs2))

            if use_cholesky:
                sol = cho_solve(A_factor, rhs)
            elif use_smw:
                h_hat = inv_D_hat.reshape(-1, 1) * rhs
                norm_y = np.sqrt(norm_y_sq)
                Ut_h_hat = np.zeros((n + 1, 1))
                Ut_h_hat[:n] = Z.T @ h_hat[:dim] + y.reshape(-1, 1) * h_hat[dim:]
                Ut_h_hat[n] = norm_y * h_hat[dim:]
                v = Ut_h_hat.flatten()
                J_inv_v = np.zeros(n + 1)
                J_inv_v[:n] = cho_solve(J_factor, v[:n])
                J_inv_v[n] = -v[n]
                y_bar = np.append(y_vec / norm_y, 1.0)
                y_bar_t_J_inv_v = y_bar @ J_inv_v
                y_bar_t_J_inv_y_bar = y_bar @ np.append(J_inv_y / norm_y, -1.0)
                H_inv_Ut_h_hat = J_inv_v - (y_bar_t_J_inv_v / (1.0 + y_bar_t_J_inv_y_bar)) * np.append(J_inv_y / norm_y, -1.0)
                U_res = np.zeros((dim + 1, 1))
                U_res[:dim] = Z @ H_inv_Ut_h_hat[:n].reshape(-1, 1)
                U_res[dim:] = y.reshape(1, -1) @ H_inv_Ut_h_hat[:n].reshape(-1, 1) + norm_y * H_inv_Ut_h_hat[n]
                sol = h_hat - inv_D_hat.reshape(-1, 1) * U_res
            elif use_psqmr:
                sol = self._psqmr_solver(Z, y, rhs, wbeta, const, tol=1e-4, max_iter=50)
            return sol[:dim], sol[dim:]

        for iter in range(1, self.maxIter + 1):
            rold, wbetaold, uold = r.copy(), wbeta.copy(), u.copy()
            xiold, alphaold, pold = xi.copy(), alpha.copy(), p.copy()

            w, beta = solver_system(rold, xiold, alphaold, uold, pold, sigma, wbetaold)

            ZTwpbetay = Z.T @ w + beta * y.reshape(-1, 1)
            cc = ZTwpbetay + xiold - alphaold / sigma
            r = self._Newton_Method(cc, self.q, sigma, rold)
            r = np.maximum(r, 0)

            doublecompute_measure = normZ * np.linalg.norm(r - rold) * (iter**1.5)
            if doublecompute_measure > 10 or iter < 50:
                w, beta = solver_system(rold, xiold, alphaold, uold, pold, sigma, wbetaold)
                ZTwpbetay = Z.T @ w + beta * y.reshape(-1, 1)

            uinput = w - pold / (const * sigma)
            u_norm = np.linalg.norm(uinput)
            u = Zscale * uinput / max(Zscale, u_norm)

            xiinput = r - ZTwpbetay + (alphaold - C_val) / sigma
            xi = np.maximum(xiinput, 0)

            Rp = ZTwpbetay + xi - r
            alpha = alphaold - tau * sigma * Rp
            p = pold - (tau * sigma * const) * (w - u)

            alpha_f = alpha.flatten()
            xi_f = xi.flatten()
            r_f = r.flatten()
            y_f = y.flatten()
            rexpon1 = np.maximum(r_f, 1e-10)**(self.q + 1)

            eta_c1 = np.abs(np.dot(y_f, alpha_f))
            eta_c2 = np.abs(np.dot(xi_f, (C_val - alpha_f)))
            term_comp3_a = np.linalg.norm(alpha_f * rexpon1 - self.q)
            term_comp3_b = np.linalg.norm(alpha_f - self.q / rexpon1)**2
            eta_c3 = min(term_comp3_a, term_comp3_b)
            eta_c = max(eta_c1, eta_c2, eta_c3) / (1 + C_val)

            eta_p1 = np.linalg.norm(Rp)
            eta_p2 = np.linalg.norm(w - u)
            eta_p3 = max(np.linalg.norm(w) - Zscale, 0)
            eta_p = max(eta_p1, eta_p2, eta_p3) / (1 + C_val)

            eta_d = max(np.linalg.norm(np.minimum(0, alpha_f)),
                        np.linalg.norm(np.maximum(alpha_f - C_val, 0))) / (1 + C_val)

            primobj = np.sum(r_f / rexpon1) + np.sum(C_val * xi_f) + 1e-8
            kappa = ((self.q + 1) / self.q) * (self.q**(1 / (self.q + 1)))
            term_dual1 = kappa * np.sum(np.maximum(0, alpha_f)**(self.q / (self.q + 1)))
            term_dual2 = np.linalg.norm(Z @ alpha.reshape(-1, 1))

            dualobj = term_dual1 - term_dual2
            eta_gap = abs(primobj - dualobj) / (1 + abs(primobj) + abs(dualobj))

            kondisi1 = max(eta_p, eta_d)
            kondisi2 = min(eta_gap, eta_c)
            kondisi3 = max(eta_gap, eta_c)

            
            
            if kondisi1 < tol and kondisi2 < np.sqrt(tol) and kondisi3 < 0.05:
                break

            if iter % 20 == 0:
                ratio = max(eta_p, 0.2 * tol) / max(eta_d, 0.2 * tol)
                if ratio > 5:
                    sigma = min(sigma * 2.2, 1e6)
                elif 1 / ratio > 5:
                    sigma = max(sigma / 1.65, 1e-3)

            
 
        w = w / Zscale
        
        return w, beta

    def fit(self, X, y):
        self.classes_ = np.sort(np.unique(y))
        
        if len(self.classes_) == 2:
            # Mode Biner
            self.is_multiclass = False
            self.c_neg, self.c_pos = self.classes_[0], self.classes_[1]
            y_bin = np.where(y == self.c_pos, 1, -1)
            
            res = self._binary_fit(X, y_bin, self.C)
            
            self.w_, self.beta_ = res
                
        elif len(self.classes_) > 2:
            # Mode Multi-kelas (One-vs-One)
            self.is_multiclass = True
            self.models_ = {}
            
            
            for i in range(len(self.classes_)):
                for j in range(i + 1, len(self.classes_)):
                    c_i = self.classes_[i]
                    c_j = self.classes_[j]
                    
                    
                        
                    mask = (y == c_i) | (y == c_j)
                    y_mask = np.where(y[mask] == c_i, -1, 1)
                    
                    
                    res = self._binary_fit(X[mask], y_mask, self.C)
                    
                    w_bin, b_bin = res
                        
                    self.models_[(c_i, c_j)] = (w_bin, b_bin)
        else:
            raise ValueError("Data label 'y' hanya memiliki 1 kelas. Tidak dapat diklasifikasi.")
            
        return self

    def predict(self, X):
        if not self.is_multiclass:
            # Prediksi Biner
            proyeksi = np.dot(X, self.w_) + self.beta_
            y_pred_bin = np.where(proyeksi > 0, 1, -1).flatten()
            return np.where(y_pred_bin == 1, self.c_pos, self.c_neg)
            
        else:
            # Prediksi Multi-kelas (Voting / Akumulasi Skor)
            n_samples = X.shape[0]
            n_classes = len(self.classes_)
            accumulated_scores = np.zeros((n_samples, n_classes), dtype=float)

            for (c_i, c_j), (w, b) in self.models_.items():
                score = np.dot(X, w) + b
                score = score.reshape(-1)

                idx_i = np.where(self.classes_ == c_i)[0][0]
                idx_j = np.where(self.classes_ == c_j)[0][0]

                accumulated_scores[:, idx_j] += score  
                accumulated_scores[:, idx_i] -= score  

            final_indices = np.argmax(accumulated_scores, axis=1)
            return self.classes_[final_indices]