from setuptools import setup, find_packages

setup(
    name="genDWD",
    version="0.1.2",
    author="Thoriq Al Mahdi",
    author_email="mahdialthoriq@gmail.com",
    description="Generalized Distance Weighted Discrimination (DWD) with sGS-ADDM",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "scipy",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
)