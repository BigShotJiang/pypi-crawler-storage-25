class AftabBaseMixin:
    pass
