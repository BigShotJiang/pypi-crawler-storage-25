# aegis-sdk

Python SDK for the **AEGIS** real-time child safety moderation API. Protects minors in gaming platforms against cartel recruitment and grooming, with <50ms latency per message.

## Install

```bash
pip install aegis-sdk
```

## Quickstart

```python
from aegis import AEGISClient

client = AEGISClient(
    base_url="https://aegis-production-b461.up.railway.app",
    api_key="your-api-key",
)

result = client.analyze(
    message="ey bro entra al clan, hay buen jale",
    player_id="player_123",
    target_id="player_456",
    game_id="free-fire-mx",
)

print(result.action)   # "block" | "warn" | "allow"
print(result.level)    # "high" | "medium" | "low"
print(result.reason)   # human-readable explanation
```

## Async

```python
from aegis import AEGISAsyncClient

async with AEGISAsyncClient(api_key="your-api-key") as client:
    result = await client.analyze("mensaje", "p1", "p2")
```

## Real-time WebSocket

```python
from aegis import AEGISRealtime

rt = AEGISRealtime(
    server_url="wss://aegis-production-b461.up.railway.app",
    api_key="your-api-key",
    room_id="sala-1",
    player_id="player_123",
)

rt.on_alert(lambda alert: print(f"ALERTA: {alert.reason}"))
rt.connect()
rt.send("hola, cómo vas?")
```

## API Reference

| Method | Description |
|---|---|
| `client.analyze(message, player_id, target_id)` | Analyze one message, returns `AnalysisResult` |
| `client.is_safe(message, ...)` | Returns `True` if message is safe |
| `client.should_block(message, ...)` | Returns `True` if message should be blocked |
| `client.stats()` | Real-time moderation stats |
| `client.health()` | Check API availability |

## License

MIT
