import curses
import sys
from pathlib import Path


MENU_ITEMS = ["INIT", "RUN", "VALIDATE", "STATUS", "HISTORY", "UNDO", "EXIT"]

COLOR_NORMAL = 1
COLOR_SELECTED = 2
COLOR_SUCCESS = 3
COLOR_ERROR = 4
COLOR_WARNING = 5
COLOR_TITLE = 6


def init_colors():
    curses.start_color()
    curses.use_default_colors()
    curses.init_pair(COLOR_NORMAL, curses.COLOR_WHITE, -1)
    curses.init_pair(COLOR_SELECTED, curses.COLOR_BLACK, curses.COLOR_WHITE)
    curses.init_pair(COLOR_SUCCESS, curses.COLOR_GREEN, -1)
    curses.init_pair(COLOR_ERROR, curses.COLOR_RED, -1)
    curses.init_pair(COLOR_WARNING, curses.COLOR_YELLOW, -1)
    curses.init_pair(COLOR_TITLE, curses.COLOR_CYAN, -1)


def draw_box(win, y, x, h, w):
    win.attron(curses.color_pair(COLOR_NORMAL))
    win.addch(y, x, curses.ACS_ULCORNER)
    win.addch(y, x + w - 1, curses.ACS_URCORNER)
    win.addch(y + h - 1, x, curses.ACS_LLCORNER)
    win.addch(y + h - 1, x + w - 1, curses.ACS_LRCORNER)
    for i in range(1, w - 1):
        win.addch(y, x + i, curses.ACS_HLINE)
        win.addch(y + h - 1, x + i, curses.ACS_HLINE)
    for i in range(1, h - 1):
        win.addch(y + i, x, curses.ACS_VLINE)
        win.addch(y + i, x + w - 1, curses.ACS_VLINE)
    win.attroff(curses.color_pair(COLOR_NORMAL))


def draw_main_menu(stdscr, selected):
    stdscr.clear()
    h, w = stdscr.getmaxyx()

    box_w = 40
    box_h = len(MENU_ITEMS) + 4
    box_y = h // 2 - box_h // 2
    box_x = w // 2 - box_w // 2

    title = "✦ IRIS"
    stdscr.attron(curses.color_pair(COLOR_TITLE) | curses.A_BOLD)
    stdscr.addstr(box_y - 2, w // 2 - len(title) // 2, title)
    stdscr.attroff(curses.color_pair(COLOR_TITLE) | curses.A_BOLD)

    draw_box(stdscr, box_y, box_x, box_h, box_w)

    for i, item in enumerate(MENU_ITEMS):
        label = "  ▶  " + item
        y = box_y + 2 + i
        x = box_x + 2

        if i == selected:
            stdscr.attron(curses.color_pair(COLOR_SELECTED) | curses.A_BOLD)
            stdscr.addstr(y, x, label.ljust(box_w - 4))
            stdscr.attroff(curses.color_pair(COLOR_SELECTED) | curses.A_BOLD)
        else:
            stdscr.attron(curses.color_pair(COLOR_NORMAL))
            stdscr.addstr(y, x, label)
            stdscr.attroff(curses.color_pair(COLOR_NORMAL))

    hint = "↑↓ navigate   Enter select   Ctrl+C exit"
    stdscr.attron(curses.color_pair(COLOR_WARNING))
    stdscr.addstr(box_y + box_h + 1, w // 2 - len(hint) // 2, hint)
    stdscr.attroff(curses.color_pair(COLOR_WARNING))

    stdscr.refresh()


def draw_list_picker(stdscr, items, selected, title, subtitle=None):
    stdscr.clear()
    h, w = stdscr.getmaxyx()

    box_w = 54
    box_h = min(len(items), 10) + 4
    box_y = h // 2 - box_h // 2
    box_x = w // 2 - box_w // 2

    stdscr.attron(curses.color_pair(COLOR_TITLE) | curses.A_BOLD)
    try:
        stdscr.addstr(box_y - 2, w // 2 - len(title) // 2, title)
    except curses.error:
        pass
    stdscr.attroff(curses.color_pair(COLOR_TITLE) | curses.A_BOLD)

    if subtitle:
        stdscr.attron(curses.color_pair(COLOR_NORMAL))
        try:
            stdscr.addstr(box_y - 1, w // 2 - len(subtitle) // 2, subtitle)
        except curses.error:
            pass
        stdscr.attroff(curses.color_pair(COLOR_NORMAL))

    draw_box(stdscr, box_y, box_x, box_h, box_w)

    visible = items[max(0, selected - 7):selected + 3]
    offset = max(0, selected - 7)

    for i, item in enumerate(visible):
        label = "  ▶  " + item
        y = box_y + 2 + i
        x = box_x + 2
        real_i = offset + i

        if real_i == selected:
            stdscr.attron(curses.color_pair(COLOR_SELECTED) | curses.A_BOLD)
            stdscr.addstr(y, x, label.ljust(box_w - 4))
            stdscr.attroff(curses.color_pair(COLOR_SELECTED) | curses.A_BOLD)
        else:
            stdscr.attron(curses.color_pair(COLOR_NORMAL))
            stdscr.addstr(y, x, label)
            stdscr.attroff(curses.color_pair(COLOR_NORMAL))

    hint = "↑↓ navigate   Enter select   Esc back"
    stdscr.attron(curses.color_pair(COLOR_WARNING))
    try:
        stdscr.addstr(box_y + box_h + 1, w // 2 - len(hint) // 2, hint)
    except curses.error:
        pass
    stdscr.attroff(curses.color_pair(COLOR_WARNING))

    stdscr.refresh()


def get_line_color(line):
    l = line.upper()
    if any(x in l for x in ("[ERROR]", "[BLOCKED]")):
        return COLOR_ERROR
    if any(x in l for x in ("[WARN]",)):
        return COLOR_WARNING
    if any(x in l for x in ("[WRITTEN]", "[RESTORED]", "[OK]", "[REPORT]")):
        return COLOR_SUCCESS
    if any(x in l for x in ("[TIPS]", "[HINT]", "> ")):
        return COLOR_WARNING
    if any(x in l for x in ("[MODEL]",)):
        return COLOR_TITLE
    return COLOR_NORMAL


def draw_output_screen(stdscr, title, lines):
    stdscr.clear()
    h, w = stdscr.getmaxyx()

    box_w = min(w - 4, 80)
    box_h = h - 6
    box_y = 2
    box_x = w // 2 - box_w // 2

    stdscr.attron(curses.color_pair(COLOR_TITLE) | curses.A_BOLD)
    try:
        stdscr.addstr(0, w // 2 - len(title) // 2, title)
    except curses.error:
        pass
    stdscr.attroff(curses.color_pair(COLOR_TITLE) | curses.A_BOLD)

    draw_box(stdscr, box_y, box_x, box_h, box_w)

    max_lines = box_h - 2
    visible_lines = lines[-max_lines:] if len(lines) > max_lines else lines

    for i, line in enumerate(visible_lines):
        y = box_y + 1 + i
        x = box_x + 2
        text = line[:box_w - 4]
        color = get_line_color(line)
        try:
            stdscr.attron(curses.color_pair(color))
            stdscr.addstr(y, x, text)
            stdscr.attroff(curses.color_pair(color))
        except curses.error:
            pass

    hint = "Press any key to return to menu..."
    stdscr.attron(curses.color_pair(COLOR_WARNING))
    try:
        stdscr.addstr(h - 2, w // 2 - len(hint) // 2, hint)
    except curses.error:
        pass
    stdscr.attroff(curses.color_pair(COLOR_WARNING))

    stdscr.refresh()


def capture_and_display(stdscr, title, fn, *args):
    lines = []

    class LiveStream:
        def write(self, text):
            for part in text.split("\n"):
                if part.strip():
                    lines.append(part)
            draw_output_screen(stdscr, title, lines)

        def flush(self):
            pass

    old_stdout = sys.stdout
    sys.stdout = LiveStream()

    try:
        fn(*args)
    except SystemExit:
        pass
    except Exception as e:
        lines.append("[ERROR] " + str(e))
    finally:
        sys.stdout = old_stdout

    draw_output_screen(stdscr, title, lines)
    stdscr.getch()


def get_yaml_files(base_path):
    if not base_path or not base_path.exists():
        return []
    return sorted([f.name for f in base_path.glob("*.yaml")])


def pick_from_list(stdscr, items, title, subtitle=None):
    if not items:
        return None

    selected = 0
    while True:
        draw_list_picker(stdscr, items, selected, title, subtitle)
        key = stdscr.getch()

        if key == curses.KEY_UP and selected > 0:
            selected -= 1
        elif key == curses.KEY_DOWN and selected < len(items) - 1:
            selected += 1
        elif key in (curses.KEY_ENTER, 10, 13):
            return items[selected]
        elif key == 27:
            return None


def tui_input(stdscr, prompt):
    h, w = stdscr.getmaxyx()
    stdscr.clear()

    stdscr.attron(curses.color_pair(COLOR_TITLE) | curses.A_BOLD)
    try:
        stdscr.addstr(h // 2 - 2, w // 2 - len(prompt) // 2, prompt)
    except curses.error:
        pass
    stdscr.attroff(curses.color_pair(COLOR_TITLE) | curses.A_BOLD)

    curses.echo()
    curses.curs_set(1)
    result = stdscr.getstr(h // 2, w // 2 - 20, 60).decode("utf-8").strip()
    curses.noecho()
    curses.curs_set(0)

    return result


def tui_init(stdscr):
    from core.config import PROFILES, save_config

    profile_names = list(PROFILES.keys())
    profile_labels = [name + " — " + PROFILES[name]["description"] for name in profile_names]

    chosen_label = pick_from_list(stdscr, profile_labels, "Select a profile", "Choose your project type")
    if not chosen_label:
        return

    profile = profile_names[profile_labels.index(chosen_label)]
    project_path = tui_input(stdscr, "Enter project path:")

    if not project_path:
        return

    path = Path(project_path)
    if path.exists():
        save_config(path, profile)
        draw_output_screen(stdscr, "INIT", [
            "Project saved: " + str(path),
            "Profile:       " + profile,
            "Now run: iris run <file.yaml>"
        ])
    else:
        draw_output_screen(stdscr, "INIT", [
            "[ERROR] Path does not exist: " + project_path
        ])

    stdscr.getch()


def tui_main(stdscr):
    from core.config import get_project_path
    from iris import run, undo, status, history, validate

    init_colors()
    curses.curs_set(0)

    selected = 0

    while True:
        draw_main_menu(stdscr, selected)
        key = stdscr.getch()

        if key == curses.KEY_UP and selected > 0:
            selected -= 1
        elif key == curses.KEY_DOWN and selected < len(MENU_ITEMS) - 1:
            selected += 1
        elif key in (curses.KEY_ENTER, 10, 13):
            choice = MENU_ITEMS[selected]

            if choice == "EXIT":
                break

            elif choice == "INIT":
                tui_init(stdscr)

            elif choice == "STATUS":
                capture_and_display(stdscr, "STATUS", status)

            elif choice == "HISTORY":
                capture_and_display(stdscr, "HISTORY", history)

            elif choice == "UNDO":
                capture_and_display(stdscr, "UNDO", undo)

            elif choice == "RUN":
                base_path = get_project_path()
                yaml_files = get_yaml_files(base_path)
                yaml_file = pick_from_list(stdscr, yaml_files, "Select YAML to run")
                if yaml_file:
                    capture_and_display(stdscr, "RUN — " + yaml_file, run, yaml_file)

            elif choice == "VALIDATE":
                base_path = get_project_path()
                yaml_files = get_yaml_files(base_path)
                yaml_file = pick_from_list(stdscr, yaml_files, "Select YAML to validate")
                if yaml_file:
                    capture_and_display(stdscr, "VALIDATE — " + yaml_file, validate, yaml_file)


def start():
    try:
        curses.wrapper(tui_main)
    except KeyboardInterrupt:
        pass