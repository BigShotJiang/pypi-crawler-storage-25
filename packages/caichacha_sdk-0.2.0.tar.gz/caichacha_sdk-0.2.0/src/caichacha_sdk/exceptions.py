"""SDK 异常定义"""


class CaichachaSDKError(Exception):
    """SDK 基础异常类"""

    def __init__(self, message: str, code: int = None):
        self.message = message
        self.code = code
        super().__init__(self.message)


class APIError(CaichachaSDKError):
    """API 调用异常"""

    def __init__(self, message: str, code: int = None, response_data: dict = None):
        super().__init__(message, code)
        self.response_data = response_data


class ValidationError(CaichachaSDKError):
    """参数校验异常"""
    pass


class NetworkError(CaichachaSDKError):
    """网络请求异常"""
    pass
