"""
财查查基金筛选 SDK

提供基金筛选相关接口的 Python SDK，支持 fundFilterV2 等多种筛选条件组合查询。

示例:
    >>> from caichacha_sdk import FundFilterClient
    >>> from caichacha_sdk.models import FundFilterRequest, FundFilterRangeV2DTO
    >>>
    >>> client = FundFilterClient(base_url="http://192.168.90.209:6098")
    >>> request = FundFilterRequest(
    ...     page_num=1,
    ...     page_size=20,
    ...     company_code_list=["80000248"]
    ... )
    >>> response = client.fund_filter_v2(request)
    >>> print(response.data.list)
"""

__version__ = "0.2.0"
__author__ = "Thinkive"
__email__ = "dev@thinkive.com"

from caichacha_sdk.client import FundFilterClient
from caichacha_sdk.exceptions import (
    CaichachaSDKError,
    APIError,
    ValidationError,
    NetworkError,
)

__all__ = [
    "FundFilterClient",
    "CaichachaSDKError",
    "APIError",
    "ValidationError",
    "NetworkError",
]
