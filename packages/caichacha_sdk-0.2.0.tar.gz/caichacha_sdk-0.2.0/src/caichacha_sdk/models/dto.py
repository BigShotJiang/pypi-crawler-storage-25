"""DTO (Data Transfer Object) 数据模型"""
from decimal import Decimal
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field


def decimal_serializer(v: Any) -> Any:
    """Decimal 序列化器"""
    if v is None:
        return None
    if isinstance(v, Decimal):
        return float(v)
    return v


class FundFilterRangeV2DTO(BaseModel):
    """
    范围筛选对象

    用于表示数值型范围筛选条件，如基金规模、成立年限、起购金额等。

    Attributes:
        min_value: 最小值，null表示不限制下限
        max_value: 最大值，null表示不限制上限

    Example:
        >>> FundFilterRangeV2DTO(min_value=10, max_value=100)
    """
    model_config = ConfigDict(
        populate_by_name=True,
        ser_json_bytes="utf8",
    )

    min_value: Optional[Decimal] = Field(
        None,
        alias="minValue",
        description="最小值，null表示不限制下限"
    )
    max_value: Optional[Decimal] = Field(
        None,
        alias="maxValue",
        description="最大值，null表示不限制上限"
    )


class FundOrderRankValueV2DTO(BaseModel):
    """
    排序排名值对象

    用于表示需要按时间区间筛选的数值条件，如收益率、排名等。

    Attributes:
        code: 业务代码（时间区间代码）
        min_value: 最小值
        max_value: 最大值

    Example:
        >>> FundOrderRankValueV2DTO(code="5", min_value=10, max_value=50)
        # 表示筛选近一年收益率在10%到50%之间的基金
    """
    model_config = ConfigDict(
        populate_by_name=True,
        ser_json_bytes="utf8",
    )

    code: str = Field(
        ...,
        description="业务代码（时间区间代码）"
    )
    min_value: Optional[Decimal] = Field(
        None,
        alias="minValue",
        description="最小值"
    )
    max_value: Optional[Decimal] = Field(
        None,
        alias="maxValue",
        description="最大值"
    )
