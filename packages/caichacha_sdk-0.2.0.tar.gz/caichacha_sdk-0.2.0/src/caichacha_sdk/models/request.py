"""请求参数模型"""
from decimal import Decimal
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from caichacha_sdk.models.dto import FundFilterRangeV2DTO, FundOrderRankValueV2DTO


class FundFilterRequest(BaseModel):
    model_config = ConfigDict(
        populate_by_name=True,
        ser_json_bytes="utf8",
    )
    """
    基金筛选v2请求参数

    与 fundFilterV2 接口的入参完全一致，支持多种筛选条件组合查询基金列表。

    Attributes:
        # 基础参数
        merchant_no: 商户编号
        user_id: 用户编号
        page_num: 当前页码，从1开始
        page_size: 每页数量
        sort_by: 排序字段
        sort_type: 排序顺序：ASC(升序)、DESC(降序)

        # 基金基本信息筛选
        company_code_list: 基金公司代码集合
        fund_sub_type_list: 基金子类型代码列表
        risk_level_list: 风险等级列表
        apply_state_list: 申购状态
        open_type_list: 开放类型
        other_list: 其他属性

        # 规模与时间筛选
        fund_specification_list: 基金规模区间（单位：亿元）
        establish_year_list: 基金成立年限区间
        sub_amount_list: 起购金额区间

        # 收益率相关筛选
        ret_list: 收益率筛选
        ret_rank_list: 收益排名筛选
        year_ret_list: 年度收益率筛选
        year_rank_list: 年度收益排名筛选
        dsfof_ret_list: 定投收益率筛选
        dsfof_ret_rank_list: 定投收益排名筛选
        annual_ret_list: 年化收益率筛选
        annual_ret_rank_list: 年化收益排名筛选
        active_ret_list: 超额收益率筛选
        active_ret_rank_list: 超额收益排名筛选

        # 风险指标筛选
        draw_down_list: 最大回撤筛选
        draw_down_rank_list: 最大回撤排名筛选
        stddev_list: 区间波动率筛选
        stddev_rank_list: 区间波动率排名筛选
        down_risk_list: 区间下行风险筛选
        down_risk_rank_list: 区间下行风险排名筛选

        # 比率排名筛选
        sharperatio_rank_list: 夏普比率同类排名筛选
        kama_rank_list: 卡玛比率同类排名筛选
        info_rank_list: 信息比率同类排名筛选

        # 持仓相关筛选
        industry_list: 持仓行业偏好筛选
        style_list: 持仓风格偏好筛选
        stock_list: 重仓集中度筛选
        turnover_list: 换手率筛选
        not_industry_code_list: 行业风格不持有集合
        org_proportion_list: 机构占比筛选

        # 基金经理相关筛选
        mgr_code_list: 基金经理代码列表
        mgr_awards_num: 经理是否获奖：1-是，0-否
        mgr_fund_specification_list: 经理管理规模筛选
        mgr_employ_year_list: 经理从业年限筛选
        mgr_fund_employ_year_list: 当前在管时长筛选
        mgr_fund_year_ret_list: 经理任期年化回报筛选

    Example:
        >>> request = FundFilterRequest(
        ...     page_num=1,
        ...     page_size=20,
        ...     company_code_list=["80000248"],
        ...     risk_level_list=["R3", "R4"],
        ...     fund_specification_list=[FundFilterRangeV2DTO(min_value=10, max_value=100)],
        ...     ret_list=[FundOrderRankValueV2DTO(code="5", min_value=10, max_value=50)],
        ...     sort_by="per1y",
        ...     sort_type="DESC"
        ... )
    """

    # 基础参数
    merchant_no: Optional[str] = Field(
        "thinkive",
        alias="merchantNo",
        description="商户编号"
    )
    user_id: Optional[str] = Field(
        "thinkive",
        alias="userId",
        description="用户编号"
    )
    page_num: int = Field(
        1,
        alias="pageNum",
        description="当前页码，从1开始"
    )
    page_size: int = Field(
        20,
        alias="pageSize",
        description="每页数量"
    )
    sort_by: Optional[str] = Field(
        "dailyChange",
        alias="sortBy",
        description="排序字段"
    )
    sort_type: Optional[str] = Field(
        "DESC",
        alias="sortType",
        description="排序顺序：ASC(升序)、DESC(降序)"
    )

    # 基金基本信息筛选
    company_code_list: Optional[List[str]] = Field(
        None,
        alias="companyCodeList",
        description="基金公司代码集合"
    )
    fund_sub_type_list: Optional[List[str]] = Field(
        None,
        alias="fundSubTypeList",
        description="基金子类型代码列表"
    )
    risk_level_list: Optional[List[str]] = Field(
        None,
        alias="riskLevelList",
        description="风险等级列表"
    )
    apply_state_list: Optional[List[str]] = Field(
        None,
        alias="applyStateList",
        description="申购状态：1-新发认购，2-开放申购，3-限制大额申购"
    )
    open_type_list: Optional[List[str]] = Field(
        None,
        alias="openTypeList",
        description="开放类型：1-全开型，2-定期开放，3-锁定持有，4-滚动持有"
    )
    other_list: Optional[List[str]] = Field(
        None,
        alias="otherList",
        description="其他属性：1-ETF场内，2-ETF联接，3-LOF，4-指数型"
    )

    # 规模与时间筛选
    fund_specification_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="fundSpecificationList",
        description="基金规模区间（单位：亿元）"
    )
    establish_year_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="establishYearList",
        description="基金成立年限区间"
    )
    sub_amount_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="subAmountList",
        description="起购金额区间"
    )

    # 收益率相关筛选
    ret_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="retList",
        description="收益率筛选"
    )
    ret_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="retRankList",
        description="收益排名筛选"
    )
    year_ret_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="yearRetList",
        description="年度收益率筛选"
    )
    year_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="yearRankList",
        description="年度收益排名筛选"
    )
    dsfof_ret_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="dsfofRetList",
        description="定投收益率筛选"
    )
    dsfof_ret_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="dsfofRetRankList",
        description="定投收益排名筛选"
    )
    annual_ret_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="annualRetList",
        description="年化收益率筛选"
    )
    annual_ret_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="annualRetRankList",
        description="年化收益排名筛选"
    )
    active_ret_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="activeRetList",
        description="超额收益率筛选"
    )
    active_ret_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="activeRetRankList",
        description="超额收益排名筛选"
    )

    # 风险指标筛选
    draw_down_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="drawDownList",
        description="最大回撤筛选"
    )
    draw_down_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="drawDownRankList",
        description="最大回撤排名筛选"
    )
    stddev_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="stddevList",
        description="区间波动率筛选"
    )
    stddev_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="stddevRankList",
        description="区间波动率排名筛选"
    )
    down_risk_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="downRiskList",
        description="区间下行风险筛选"
    )
    down_risk_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="downRiskRankList",
        description="区间下行风险排名筛选"
    )

    # 比率排名筛选
    sharperatio_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="sharperatioRankList",
        description="夏普比率同类排名筛选"
    )
    kama_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="kamaRankList",
        description="卡玛比率同类排名筛选"
    )
    info_rank_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="infoRankList",
        description="信息比率同类排名筛选"
    )

    # 持仓相关筛选
    industry_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="industryList",
        description="持仓行业偏好筛选"
    )
    style_list: Optional[List[FundOrderRankValueV2DTO]] = Field(
        None,
        alias="styleList",
        description="持仓风格偏好筛选"
    )
    stock_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="stockList",
        description="重仓集中度筛选"
    )
    turnover_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="turnoverList",
        description="换手率筛选"
    )
    not_industry_code_list: Optional[List[str]] = Field(
        None,
        alias="notIndustryCodeList",
        description="行业风格不持有集合"
    )
    org_proportion_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="orgProportionList",
        description="机构占比筛选"
    )

    # 基金经理相关筛选
    mgr_code_list: Optional[List[str]] = Field(
        None,
        alias="mgrCodeList",
        description="基金经理代码列表"
    )
    mgr_awards_num: Optional[int] = Field(
        None,
        alias="mgrAwardsNum",
        description="经理是否获奖：1-是，0-否"
    )
    mgr_fund_specification_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="mgrFundSpecificationList",
        description="经理管理规模筛选"
    )
    mgr_employ_year_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="mgrEmployYearList",
        description="经理从业年限筛选"
    )
    mgr_fund_employ_year_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="mgrFundEmployYearList",
        description="当前在管时长筛选"
    )
    mgr_fund_year_ret_list: Optional[List[FundFilterRangeV2DTO]] = Field(
        None,
        alias="mgrFundYearRetList",
        description="经理任期年化回报筛选"
    )
