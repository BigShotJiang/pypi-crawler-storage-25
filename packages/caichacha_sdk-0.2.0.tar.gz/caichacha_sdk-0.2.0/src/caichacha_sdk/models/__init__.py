"""
数据模型模块

包含 fundFilterV2 接口的所有请求参数和响应数据模型。
"""

from caichacha_sdk.models.dto import (
    FundFilterRangeV2DTO,
    FundOrderRankValueV2DTO,
)
from caichacha_sdk.models.request import FundFilterRequest
from caichacha_sdk.models.response import (
    FundOrderListV2VO,
    PageVO,
    FundOrderRangeRetYearVO,
    FndSelection,
    FundFilterResponse,
)
from caichacha_sdk.models.enums import (
    TimeRangeCode,
    FundType,
    FundSubType,
    RiskLevel,
    ApplyState,
    OpenType,
    OtherAttribute,
    Currency,
)

__all__ = [
    # DTO
    "FundFilterRangeV2DTO",
    "FundOrderRankValueV2DTO",
    # Request
    "FundFilterRequest",
    # Response
    "FundOrderListV2VO",
    "PageVO",
    "FundOrderRangeRetYearVO",
    "FndSelection",
    "FundFilterResponse",
    # Enums
    "TimeRangeCode",
    "FundType",
    "FundSubType",
    "RiskLevel",
    "ApplyState",
    "OpenType",
    "OtherAttribute",
    "Currency",
]
