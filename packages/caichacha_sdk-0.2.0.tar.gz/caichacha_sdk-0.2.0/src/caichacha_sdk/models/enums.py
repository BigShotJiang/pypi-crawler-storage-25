"""枚举类型定义"""
from enum import Enum


class TimeRangeCode(str, Enum):
    """时间区间代码"""
    REALTIME = "0"          # 实时
    ONE_WEEK = "1"          # 近一周
    ONE_MONTH = "2"         # 近一个月
    THREE_MONTH = "3"       # 近三个月
    SIX_MONTH = "4"         # 近半年
    ONE_YEAR = "5"          # 近一年
    TWO_YEAR = "6"          # 近两年
    THREE_YEAR = "7"        # 近三年
    FIVE_YEAR = "8"         # 近五年
    TEN_YEAR = "9"          # 近十年
    SINCE_ESTABLISH = "10"  # 成立以来
    YEAR_TO_DATE = "11"     # 今年以来


class FundType(str, Enum):
    """基金一级分类"""
    STOCK = "10"        # 股票型
    BOND = "20"         # 债券型
    HYBRID = "30"       # 混合型
    MONEY = "40"        # 货币型
    QDII = "50"         # QDII型
    ALTERNATIVE = "60"  # 另类投资
    COMMODITY = "70"    # 商品型
    FOF = "80"          # FOF型


class FundSubType(str, Enum):
    """基金二级分类"""
    STOCK_GENERAL = "1001"      # 股票型-普通股票型
    STOCK_INDEX = "1002"        # 股票型-被动指数型
    BOND_LONG = "2001"          # 债券型-中长期纯债
    BOND_SHORT = "2002"         # 债券型-短期纯债
    BOND_HYBRID = "2003"        # 债券型-混合债基
    BOND_CONVERTIBLE = "2004"   # 债券型-可转债
    BOND_INDEX = "2005"         # 债券型-指数债基
    HYBRID_STOCK = "3001"       # 混合型-偏股混合型
    HYBRID_BOND = "3002"        # 混合型-偏债混合型
    HYBRID_BALANCE = "3003"     # 混合型-平衡混合型
    HYBRID_FLEXIBLE = "3004"    # 混合型-灵活配置型
    HYBRID_ABSOLUTE = "3005"    # 混合型-绝对收益型
    HYBRID_QUANT = "3006"       # 混合型-量化对冲型
    HYBRID_TARGET_DATE = "3007" # 混合型-目标日期型
    HYBRID_TARGET_RISK = "3008" # 混合型-目标风险型
    ALT_LONG_SHORT = "6001"     # 另类投资-股票多空
    ALT_COMMODITY = "6002"      # 另类投资-商品型
    ALT_REITS = "6003"          # 另类投资-REITs


class RiskLevel(str, Enum):
    """风险等级"""
    R1 = "R1"  # 低风险
    R2 = "R2"  # 中低风险
    R3 = "R3"  # 中风险
    R4 = "R4"  # 中高风险
    R5 = "R5"  # 高风险


class ApplyState(str, Enum):
    """申购状态"""
    NEW = "1"           # 新发认购
    OPEN = "2"          # 开放申购
    LIMIT_LARGE = "3"   # 限制大额申购


class OpenType(str, Enum):
    """开放类型"""
    FULL = "1"      # 全开型
    REGULAR = "2"   # 定期开放
    LOCKED = "3"    # 锁定持有
    ROLLING = "4"   # 滚动持有


class OtherAttribute(str, Enum):
    """其他属性"""
    ETF = "1"           # ETF场内
    ETF_LINK = "2"      # ETF联接
    LOF = "3"           # LOF
    INDEX = "4"         # 指数型


class Currency(str, Enum):
    """发行币种"""
    CNY = "CNY"  # 人民币
    HKD = "HKD"  # 港币
    USD = "USD"  # 美元


class SortBy(str, Enum):
    """排序字段"""
    DAILY_CHANGE = "dailyChange"
    PER_1Y = "per1y"
    PER_3Y = "per3y"
    FUND_SPECIFICATION = "fundSpecification"


class SortType(str, Enum):
    """排序顺序"""
    ASC = "ASC"
    DESC = "DESC"
