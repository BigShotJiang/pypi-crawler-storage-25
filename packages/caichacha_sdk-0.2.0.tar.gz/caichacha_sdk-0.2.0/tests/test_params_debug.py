"""
基金筛选接口参数独立测试 - 用于调试

每个参数都有独立的测试方法，方便单独调试
运行方式:
    pytest tests/test_params_debug.py -v -s
    pytest tests/test_params_debug.py::TestBasicParams::test_page_num -v -s
"""
import pytest
import json
from decimal import Decimal
from datetime import date

from caichacha_sdk import FundFilterClient
from caichacha_sdk.models import (
    FundFilterRequest,
    FundFilterRangeV2DTO,
    FundOrderRankValueV2DTO,
    TimeRangeCode,
    RiskLevel,
    ApplyState,
    OpenType,
    OtherAttribute,
)


def format_response(response):
    """将 response 格式化为 JSON 字符串"""
    def serialize(obj):
        """自定义序列化函数"""
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, date):
            return obj.isoformat()
        if hasattr(obj, 'model_dump'):
            return obj.model_dump()
        raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")
    
    if hasattr(response, 'model_dump'):
        data = response.model_dump()
        return json.dumps(data, indent=2, ensure_ascii=False, default=serialize)
    return str(response)


def print_response_json(response, max_funds=3):
    """打印 response 的 JSON 格式，限制基金数量"""
    if not response.is_success:
        print(f"响应失败: code={response.code}, msg={response.msg}")
        return
    
    # 构建简化的响应数据
    result = {
        "code": response.code,
        "msg": response.msg,
        "is_success": response.is_success,
    }
    
    if response.data:
        result["data"] = {
            "page_num": response.data.page_num,
            "page_size": response.data.page_size,
            "total": response.data.total,
            "pages": response.data.pages,
            "fund_count": len(response.fund_list),
            "funds": []
        }
        
        # 只取前 max_funds 只基金
        for fund in response.fund_list[:max_funds]:
            fund_data = {
                "fund_code": fund.fund_code,
                "fund_sname": fund.fund_sname,
                "fund_type": fund.fund_type,
                "fund_type_txt": fund.fund_type_txt,
                "company_name": fund.company_name,
                "risk_level": fund.risk_level,
                "daily_change": float(fund.daily_change) if fund.daily_change else None,
                "per_1y": float(fund.per_1y) if fund.per_1y else None,
                "fund_specification": float(fund.fund_specification) if fund.fund_specification else None,
                "fund_managers": fund.fund_managers,
            }
            result["data"]["funds"].append(fund_data)
        
        if len(response.fund_list) > max_funds:
            result["data"]["note"] = f"还有 {len(response.fund_list) - max_funds} 只基金未显示"
    
    print("\n【Response JSON】")
    print(json.dumps(result, indent=2, ensure_ascii=False))


@pytest.fixture
def client():
    """创建客户端"""
    return FundFilterClient()


class TestBasicParams:
    """基础参数测试 - 分页、排序等"""

    def test_page_num(self, client):
        """测试页码参数"""
        print("\n【测试参数】page_num")
        request = FundFilterRequest(page_num=2, page_size=5)
        response = client.fund_filter_v2(request)

        print(f"请求参数: page_num={request.page_num}, page_size={request.page_size}")
        print(f"响应结果: code={response.code}, msg={response.msg}")

        if response.is_success and response.data:
            print(f"分页信息: pageNum={response.data.page_num}, total={response.data.total}")
            assert response.data.page_num == 2
        else:
            print(f"警告: {response.msg}")

    def test_page_size(self, client):
        """测试每页数量参数"""
        print("\n【测试参数】page_size")
        request = FundFilterRequest(page_num=1, page_size=10)
        response = client.fund_filter_v2(request)

        print(f"请求参数: page_size={request.page_size}")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.data:
            print(f"返回数量: {len(response.fund_list)} (请求{request.page_size}条)")
            assert len(response.fund_list) <= request.page_size

    def test_sort_by_daily_change(self, client):
        """测试排序字段 - 日涨跌幅"""
        print("\n【测试参数】sort_by=dailyChange")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            sort_by="dailyChange",
            sort_type="DESC"
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: sort_by={request.sort_by}, sort_type={request.sort_type}")

        if response.is_success and response.fund_list:
            first_fund = response.fund_list[0]
            print(f"第一条基金: {first_fund.fund_sname}, 日涨跌幅={first_fund.daily_change}%")

    def test_sort_by_per1y(self, client):
        """测试排序字段 - 近一年收益"""
        print("\n【测试参数】sort_by=per1y")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            sort_by="per1y",
            sort_type="DESC"
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: sort_by={request.sort_by}")

        if response.is_success and response.fund_list:
            first_fund = response.fund_list[0]
            print(f"第一条基金: {first_fund.fund_sname}, 近一年收益={first_fund.per_1y}%")

    def test_sort_type_asc(self, client):
        """测试排序方向 - 升序"""
        print("\n【测试参数】sort_type=ASC")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            sort_by="dailyChange",
            sort_type="ASC"
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: sort_type={request.sort_type}")

        if response.is_success and response.fund_list:
            first_fund = response.fund_list[0]
            print(f"第一条基金: {first_fund.fund_sname}, 日涨跌幅={first_fund.daily_change}%")

    def test_merchant_no(self, client):
        """测试商户编号参数"""
        print("\n【测试参数】merchant_no")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            merchant_no="test_merchant"
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: merchant_no={request.merchant_no}")
        print(f"响应结果: code={response.code}")

    def test_user_id(self, client):
        """测试用户编号参数"""
        print("\n【测试参数】user_id")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            user_id="test_user"
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: user_id={request.user_id}")
        print(f"响应结果: code={response.code}")


class TestCompanyParams:
    """基金公司参数测试"""

    def test_company_code_list_single(self, client):
        """测试单个基金公司代码"""
        print("\n【测试参数】company_code_list (单值)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            company_code_list=["80000248"]  # 易方达
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: company_code_list={request.company_code_list}")
        print(f"响应结果: code={response.code}, msg={response.msg}")

        if response.is_success and response.fund_list:
            print(f"返回基金数量: {len(response.fund_list)}")
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname} | 公司: {fund.company_name}")

    def test_company_code_list_multiple(self, client):
        """测试多个基金公司代码"""
        print("\n【测试参数】company_code_list (多值)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            company_code_list=["97657c16943edbb375d4d55bc06dea27"]  
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: company_code_list={request.company_code_list}")
        
        # 使用 JSON 格式打印响应
        print_response_json(response, max_funds=3)


class TestRiskLevelParams:
    """风险等级参数测试"""

    def test_risk_level_list_r1(self, client):
        """测试低风险"""
        print("\n【测试参数】risk_level_list=[R1]")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            risk_level_list=[RiskLevel.R1]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: risk_level_list={request.risk_level_list}")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname} | 风险: {fund.risk_level}")

    def test_risk_level_list_r3(self, client):
        """测试中风险"""
        print("\n【测试参数】risk_level_list=[R3]")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            risk_level_list=[RiskLevel.R3]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: risk_level_list={request.risk_level_list}")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname} | 风险: {fund.risk_level}")

    def test_risk_level_list_multiple(self, client):
        """测试多个风险等级"""
        print("\n【测试参数】risk_level_list=[R3, R4]")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            risk_level_list=[RiskLevel.R3, RiskLevel.R4]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: risk_level_list={request.risk_level_list}")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            print(f"返回基金数量: {len(response.fund_list)}")


class TestFundTypeParams:
    """基金类型参数测试"""

    def test_fund_sub_type_list_money(self, client):
        """测试货币型基金"""
        print("\n【测试参数】fund_sub_type_list=[40] (货币型)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            fund_sub_type_list=["40"]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: fund_sub_type_list={request.fund_sub_type_list}")
        print(f"响应结果: code={response.code}, msg={response.msg}")

        if response.is_success and response.fund_list:
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname} | 类型: {fund.fund_type_txt}")

    def test_fund_sub_type_list_hybrid(self, client):
        """测试混合型基金"""
        print("\n【测试参数】fund_sub_type_list=[30] (混合型)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            fund_sub_type_list=["30"]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: fund_sub_type_list={request.fund_sub_type_list}")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname} | 类型: {fund.fund_type_txt}")


class TestApplyStateParams:
    """申购状态参数测试"""

    def test_apply_state_list_open(self, client):
        """测试开放申购"""
        print("\n【测试参数】apply_state_list=[OPEN]")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            apply_state_list=[ApplyState.OPEN]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: apply_state_list={request.apply_state_list}")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            for fund in response.fund_list[:3]:
                status = "开放" if fund.buy_status == 1 else "暂停"
                print(f"  - {fund.fund_sname} | 申购状态: {status}")


class TestFundSpecificationParams:
    """基金规模参数测试"""

    def test_fund_specification_list_range(self, client):
        """测试基金规模范围"""
        print("\n【测试参数】fund_specification_list (范围)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=10, max_value=100)
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: fund_specification_list=[10-100亿]")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname} | 规模: {fund.fund_specification}亿元")

    def test_fund_specification_list_min_only(self, client):
        """测试基金规模最小值"""
        print("\n【测试参数】fund_specification_list (仅最小值)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=50)
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: fund_specification_list=[>50亿]")
        print(f"响应结果: code={response.code}")

    def test_fund_specification_list_max_only(self, client):
        """测试基金规模最大值"""
        print("\n【测试参数】fund_specification_list (仅最大值)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            fund_specification_list=[
                FundFilterRangeV2DTO(max_value=10)
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: fund_specification_list=[<10亿]")
        print(f"响应结果: code={response.code}")


class TestReturnParams:
    """收益率参数测试"""

    def test_ret_list_one_year(self, client):
        """测试近一年收益率"""
        print("\n【测试参数】ret_list (近一年)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=20
                )
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: ret_list=[code=5(近一年), minValue=20%]")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname} | 近一年收益: {fund.per_1y}%")

    def test_ret_list_three_month(self, client):
        """测试近三月收益率"""
        print("\n【测试参数】ret_list (近三月)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.THREE_MONTH,
                    min_value=5
                )
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: ret_list=[code=3(近三月), minValue=5%]")
        print(f"响应结果: code={response.code}")

    def test_ret_list_with_max(self, client):
        """测试收益率范围"""
        print("\n【测试参数】ret_list (范围)")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=10,
                    max_value=50
                )
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: ret_list=[code=5, minValue=10%, maxValue=50%]")
        print(f"响应结果: code={response.code}")


class TestDrawDownParams:
    """最大回撤参数测试"""

    def test_draw_down_list(self, client):
        """测试最大回撤"""
        print("\n【测试参数】draw_down_list")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            draw_down_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=-30,
                    max_value=0
                )
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: draw_down_list=[code=5, minValue=-30%, maxValue=0%]")
        print(f"响应结果: code={response.code}")


class TestStdDevParams:
    """波动率参数测试"""

    def test_stddev_list(self, client):
        """测试区间波动率"""
        print("\n【测试参数】stddev_list")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            stddev_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=5,
                    max_value=25
                )
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: stddev_list=[code=5, minValue=5%, maxValue=25%]")
        print(f"响应结果: code={response.code}")


class TestSharpeRatioParams:
    """夏普比率参数测试"""

    def test_sharperatio_rank_list(self, client):
        """测试夏普比率排名"""
        print("\n【测试参数】sharperatio_rank_list")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            sharperatio_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=100
                )
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: sharperatio_rank_list=[code=5, minValue=1, maxValue=100]")
        print(f"响应结果: code={response.code}")


class TestManagerParams:
    """基金经理参数测试"""

    def test_mgr_awards_num(self, client):
        """测试经理获奖筛选"""
        print("\n【测试参数】mgr_awards_num=1")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            mgr_awards_num=1
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: mgr_awards_num={request.mgr_awards_num}")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname} | 经理: {fund.fund_managers} | 金牛奖: {fund.number_of_taurus_awards}次")

    def test_mgr_employ_year_list(self, client):
        """测试经理从业年限"""
        print("\n【测试参数】mgr_employ_year_list")
        request = FundFilterRequest(
            page_num=1,
            page_size=5,
            mgr_employ_year_list=[
                FundFilterRangeV2DTO(min_value=5)
            ]
        )
        response = client.fund_filter_v2(request)

        print(f"请求参数: mgr_employ_year_list=[>5年]")
        print(f"响应结果: code={response.code}")


class TestComplexParams:
    """复杂组合参数测试"""

    def test_complex_combination(self, client):
        """测试多条件组合"""
        print("\n【测试参数】多条件组合")
        request = FundFilterRequest(
            page_num=1,
            page_size=10,
            risk_level_list=[RiskLevel.R3, RiskLevel.R4],
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=10, max_value=100)
            ],
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=10
                )
            ],
            sort_by="per1y",
            sort_type="DESC"
        )
        response = client.fund_filter_v2(request)

        print("请求参数:")
        print(f"  - risk_level_list: {request.risk_level_list}")
        print(f"  - fund_specification_list: 10-100亿")
        print(f"  - ret_list: 近一年>10%")
        print(f"  - sort_by: {request.sort_by}")
        print(f"响应结果: code={response.code}")

        if response.is_success and response.fund_list:
            print(f"返回基金数量: {len(response.fund_list)}")
            for fund in response.fund_list[:3]:
                print(f"  - {fund.fund_sname}")
                print(f"    风险: {fund.risk_level} | 规模: {fund.fund_specification}亿 | 收益: {fund.per_1y}%")


if __name__ == "__main__":
    # 方式1: 运行所有测试
    # pytest.main([__file__, "-v", "-s"])
    
    # 方式2: 只运行指定测试 (将测试路径拼接在文件后面)
    pytest.main([f"{__file__}::TestCompanyParams::test_company_code_list_multiple", "-v", "-s"])
    
    # 方式3: 使用 -k 参数按关键字匹配
    # pytest.main([__file__, "-v", "-s", "-k", "test_company_code_list_multiple"])
