"""数据模型测试"""
from ast import main
import pytest
from decimal import Decimal

from caichacha_sdk.models import (
    FundFilterRangeV2DTO,
    FundOrderRankValueV2DTO,
    FundFilterRequest,
    FundOrderListV2VO,
    PageVO,
    FundFilterResponse,
)


class TestFundFilterRangeV2DTO:
    """测试 FundFilterRangeV2DTO"""

    def test_create_with_min_max(self):
        dto = FundFilterRangeV2DTO(min_value=10, max_value=100)
        assert dto.min_value == 10
        assert dto.max_value == 100

    def test_create_with_only_min(self):
        dto = FundFilterRangeV2DTO(min_value=10)
        assert dto.min_value == 10
        assert dto.max_value is None

    def test_create_with_only_max(self):
        dto = FundFilterRangeV2DTO(max_value=100)
        assert dto.min_value is None
        assert dto.max_value == 100

    def test_serialization(self):
        dto = FundFilterRangeV2DTO(min_value=Decimal("10.5"), max_value=Decimal("100.5"))
        data = dto.model_dump(by_alias=True)
        assert data["minValue"] == 10.5
        assert data["maxValue"] == 100.5


class TestFundOrderRankValueV2DTO:
    """测试 FundOrderRankValueV2DTO"""

    def test_create(self):
        dto = FundOrderRankValueV2DTO(code="5", min_value=10, max_value=50)
        assert dto.code == "5"
        assert dto.min_value == 10
        assert dto.max_value == 50

    def test_serialization(self):
        dto = FundOrderRankValueV2DTO(code="5", min_value=Decimal("10.5"))
        data = dto.model_dump(by_alias=True)
        assert data["code"] == "5"
        assert data["minValue"] == 10.5


class TestFundFilterRequest:
    """测试 FundFilterRequest"""

    def test_default_values(self):
        request = FundFilterRequest()
        assert request.page_num == 1
        assert request.page_size == 20
        assert request.merchant_no == "thinkive"
        assert request.user_id == "thinkive"
        assert request.sort_by == "dailyChange"
        assert request.sort_type == "DESC"

    def test_custom_values(self):
        request = FundFilterRequest(
            page_num=2,
            page_size=50,
            company_code_list=["80000248"],
            risk_level_list=["R3", "R4"]
        )
        assert request.page_num == 2
        assert request.page_size == 50
        assert request.company_code_list == ["80000248"]
        assert request.risk_level_list == ["R3", "R4"]

    def test_with_dto_fields(self):
        request = FundFilterRequest(
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=10, max_value=100)
            ],
            ret_list=[
                FundOrderRankValueV2DTO(code="5", min_value=10, max_value=50)
            ]
        )
        assert len(request.fund_specification_list) == 1
        assert len(request.ret_list) == 1

    def test_serialization(self):
        request = FundFilterRequest(
            page_num=1,
            page_size=20,
            company_code_list=["80000248"]
        )
        data = request.model_dump(by_alias=True, exclude_none=True)
        assert data["pageNum"] == 1
        assert data["pageSize"] == 20
        assert data["companyCodeList"] == ["80000248"]


class TestFundFilterResponse:
    """测试 FundFilterResponse"""

    def test_success_response(self):
        response_data = {
            "code": 0,
            "msg": "成功",
            "data": {
                "list": [
                    {
                        "fundCode": "012920",
                        "fundSname": "测试基金",
                        "dailyChange": 1.5
                    }
                ],
                "pageNum": 1,
                "pageSize": 20,
                "pages": 1,
                "total": 1
            }
        }
        response = FundFilterResponse(**response_data)
        assert response.is_success is True
        assert response.code == 0
        assert response.msg == "成功"
        assert len(response.fund_list) == 1
        assert response.data.total == 1

    def test_error_response(self):
        response_data = {
            "code": 500,
            "msg": "系统错误",
            "data": None
        }
        response = FundFilterResponse(**response_data)
        assert response.is_success is False
        assert response.code == 500
        assert response.msg == "系统错误"

    def test_empty_list(self):
        response_data = {
            "code": 0,
            "msg": "成功",
            "data": {
                "list": [],
                "pageNum": 1,
                "pageSize": 20,
                "pages": 0,
                "total": 0
            }
        }
        response = FundFilterResponse(**response_data)
        assert response.is_success is True
        assert len(response.fund_list) == 0


# def main():
#     request = FundFilterRequest(
#             page_num=2,
#             page_size=50,
#             company_code_list=["80000248"],
#             risk_level_list=["R3", "R4"]
#         )
#     assert request.page_num == 2
#     assert request.page_size == 50
#     assert request.company_code_list == ["80000248"]
#     assert request.risk_level_list == ["R3", "R4"]


# if __name__ == "__main__":
#     main()
