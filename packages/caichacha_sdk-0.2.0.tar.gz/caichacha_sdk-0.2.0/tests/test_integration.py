"""集成测试 - 测试所有接口参数"""
import pytest
from decimal import Decimal

from caichacha_sdk import FundFilterClient
from caichacha_sdk.models import (
    FundFilterRequest,
    FundFilterRangeV2DTO,
    FundOrderRankValueV2DTO,
    TimeRangeCode,
    RiskLevel,
    ApplyState,
    OpenType,
    OtherAttribute,
    Currency,
    FundType,
    FundSubType,
)


@pytest.fixture
def client():
    """创建客户端"""
    return FundFilterClient()


class TestBasicParams:
    """测试基础参数"""

    def test_default_params(self, client):
        """测试默认参数"""
        request = FundFilterRequest()
        assert request.page_num == 1
        assert request.page_size == 20
        assert request.merchant_no == "thinkive"
        assert request.user_id == "thinkive"
        assert request.sort_by == "dailyChange"
        assert request.sort_type == "DESC"

    def test_custom_page_params(self, client):
        """测试自定义分页参数"""
        request = FundFilterRequest(
            page_num=2,
            page_size=50
        )
        assert request.page_num == 2
        assert request.page_size == 50

    def test_custom_merchant_user(self, client):
        """测试自定义商户和用户"""
        request = FundFilterRequest(
            merchant_no="custom_merchant",
            user_id="custom_user"
        )
        assert request.merchant_no == "custom_merchant"
        assert request.user_id == "custom_user"

    def test_sort_params(self, client):
        """测试排序参数"""
        request = FundFilterRequest(
            sort_by="per1y",
            sort_type="ASC"
        )
        assert request.sort_by == "per1y"
        assert request.sort_type == "ASC"


class TestFundBasicInfoFilter:
    """测试基金基本信息筛选"""

    def test_company_code_list(self, client):
        """测试基金公司代码筛选"""
        request = FundFilterRequest(
            company_code_list=["80000248", "80000249", "80000250"]
        )
        assert request.company_code_list == ["80000248", "80000249", "80000250"]

    def test_fund_sub_type_list(self, client):
        """测试基金子类型筛选"""
        request = FundFilterRequest(
            fund_sub_type_list=[
                FundSubType.STOCK_GENERAL,
                FundSubType.HYBRID_STOCK,
                FundSubType.BOND_LONG
            ]
        )
        assert FundSubType.STOCK_GENERAL in request.fund_sub_type_list
        assert FundSubType.HYBRID_STOCK in request.fund_sub_type_list

    def test_risk_level_list(self, client):
        """测试风险等级筛选"""
        request = FundFilterRequest(
            risk_level_list=[RiskLevel.R3, RiskLevel.R4, RiskLevel.R5]
        )
        assert RiskLevel.R3 in request.risk_level_list
        assert RiskLevel.R4 in request.risk_level_list
        assert len(request.risk_level_list) == 3

    def test_apply_state_list(self, client):
        """测试申购状态筛选"""
        request = FundFilterRequest(
            apply_state_list=[ApplyState.OPEN, ApplyState.NEW]
        )
        assert ApplyState.OPEN in request.apply_state_list
        assert ApplyState.NEW in request.apply_state_list

    def test_open_type_list(self, client):
        """测试开放类型筛选"""
        request = FundFilterRequest(
            open_type_list=[OpenType.FULL, OpenType.REGULAR]
        )
        assert OpenType.FULL in request.open_type_list
        assert OpenType.REGULAR in request.open_type_list

    def test_other_list(self, client):
        """测试其他属性筛选"""
        request = FundFilterRequest(
            other_list=[OtherAttribute.ETF, OtherAttribute.LOF, OtherAttribute.INDEX]
        )
        assert OtherAttribute.ETF in request.other_list
        assert OtherAttribute.LOF in request.other_list


class TestScaleAndTimeFilter:
    """测试规模与时间筛选"""

    def test_fund_specification_list(self, client):
        """测试基金规模筛选"""
        request = FundFilterRequest(
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=10, max_value=100)
            ]
        )
        assert len(request.fund_specification_list) == 1
        assert request.fund_specification_list[0].min_value == 10
        assert request.fund_specification_list[0].max_value == 100

    def test_fund_specification_min_only(self, client):
        """测试基金规模仅设置最小值"""
        request = FundFilterRequest(
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=50)
            ]
        )
        assert request.fund_specification_list[0].min_value == 50
        assert request.fund_specification_list[0].max_value is None

    def test_fund_specification_max_only(self, client):
        """测试基金规模仅设置最大值"""
        request = FundFilterRequest(
            fund_specification_list=[
                FundFilterRangeV2DTO(max_value=200)
            ]
        )
        assert request.fund_specification_list[0].min_value is None
        assert request.fund_specification_list[0].max_value == 200

    def test_establish_year_list(self, client):
        """测试成立年限筛选"""
        request = FundFilterRequest(
            establish_year_list=[
                FundFilterRangeV2DTO(min_value=3, max_value=10)
            ]
        )
        assert request.establish_year_list[0].min_value == 3
        assert request.establish_year_list[0].max_value == 10

    def test_sub_amount_list(self, client):
        """测试起购金额筛选"""
        request = FundFilterRequest(
            sub_amount_list=[
                FundFilterRangeV2DTO(min_value=1, max_value=10000)
            ]
        )
        assert request.sub_amount_list[0].min_value == 1
        assert request.sub_amount_list[0].max_value == 10000


class TestReturnFilter:
    """测试收益率相关筛选"""

    def test_ret_list(self, client):
        """测试收益率筛选"""
        request = FundFilterRequest(
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=10,
                    max_value=50
                )
            ]
        )
        assert len(request.ret_list) == 1
        assert request.ret_list[0].code == TimeRangeCode.ONE_YEAR
        assert request.ret_list[0].min_value == 10
        assert request.ret_list[0].max_value == 50

    def test_ret_list_multiple_time_ranges(self, client):
        """测试多时间区间收益率筛选"""
        request = FundFilterRequest(
            ret_list=[
                FundOrderRankValueV2DTO(code=TimeRangeCode.ONE_YEAR, min_value=10),
                FundOrderRankValueV2DTO(code=TimeRangeCode.THREE_YEAR, min_value=30),
                FundOrderRankValueV2DTO(code=TimeRangeCode.FIVE_YEAR, min_value=50)
            ]
        )
        assert len(request.ret_list) == 3

    def test_ret_rank_list(self, client):
        """测试收益排名筛选"""
        request = FundFilterRequest(
            ret_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=100
                )
            ]
        )
        assert request.ret_rank_list[0].code == TimeRangeCode.ONE_YEAR

    def test_year_ret_list(self, client):
        """测试年度收益率筛选"""
        request = FundFilterRequest(
            year_ret_list=[
                FundOrderRankValueV2DTO(
                    code="2023",
                    min_value=5,
                    max_value=30
                )
            ]
        )
        assert request.year_ret_list[0].code == "2023"

    def test_year_rank_list(self, client):
        """测试年度收益排名筛选"""
        request = FundFilterRequest(
            year_rank_list=[
                FundOrderRankValueV2DTO(
                    code="2023",
                    min_value=1,
                    max_value=50
                )
            ]
        )
        assert request.year_rank_list[0].min_value == 1

    def test_dsfof_ret_list(self, client):
        """测试定投收益率筛选"""
        request = FundFilterRequest(
            dsfof_ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=5,
                    max_value=40
                )
            ]
        )
        assert len(request.dsfof_ret_list) == 1

    def test_dsfof_ret_rank_list(self, client):
        """测试定投收益排名筛选"""
        request = FundFilterRequest(
            dsfof_ret_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=200
                )
            ]
        )
        assert request.dsfof_ret_rank_list[0].max_value == 200

    def test_annual_ret_list(self, client):
        """测试年化收益率筛选"""
        request = FundFilterRequest(
            annual_ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.SINCE_ESTABLISH,
                    min_value=8,
                    max_value=20
                )
            ]
        )
        assert request.annual_ret_list[0].code == TimeRangeCode.SINCE_ESTABLISH

    def test_annual_ret_rank_list(self, client):
        """测试年化收益排名筛选"""
        request = FundFilterRequest(
            annual_ret_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.THREE_YEAR,
                    min_value=1,
                    max_value=100
                )
            ]
        )
        assert request.annual_ret_rank_list[0].code == TimeRangeCode.THREE_YEAR

    def test_active_ret_list(self, client):
        """测试超额收益率筛选"""
        request = FundFilterRequest(
            active_ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=-5,
                    max_value=20
                )
            ]
        )
        assert request.active_ret_list[0].min_value == -5

    def test_active_ret_rank_list(self, client):
        """测试超额收益排名筛选"""
        request = FundFilterRequest(
            active_ret_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=100
                )
            ]
        )
        assert len(request.active_ret_rank_list) == 1


class TestRiskIndicatorFilter:
    """测试风险指标筛选"""

    def test_draw_down_list(self, client):
        """测试最大回撤筛选"""
        request = FundFilterRequest(
            draw_down_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=-30,
                    max_value=0
                )
            ]
        )
        assert request.draw_down_list[0].min_value == -30
        assert request.draw_down_list[0].max_value == 0

    def test_draw_down_rank_list(self, client):
        """测试最大回撤排名筛选"""
        request = FundFilterRequest(
            draw_down_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=100
                )
            ]
        )
        assert request.draw_down_rank_list[0].code == TimeRangeCode.ONE_YEAR

    def test_stddev_list(self, client):
        """测试区间波动率筛选"""
        request = FundFilterRequest(
            stddev_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=5,
                    max_value=25
                )
            ]
        )
        assert request.stddev_list[0].min_value == 5

    def test_stddev_rank_list(self, client):
        """测试区间波动率排名筛选"""
        request = FundFilterRequest(
            stddev_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=50
                )
            ]
        )
        assert len(request.stddev_rank_list) == 1

    def test_down_risk_list(self, client):
        """测试区间下行风险筛选"""
        request = FundFilterRequest(
            down_risk_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=0,
                    max_value=15
                )
            ]
        )
        assert request.down_risk_list[0].max_value == 15

    def test_down_risk_rank_list(self, client):
        """测试区间下行风险排名筛选"""
        request = FundFilterRequest(
            down_risk_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=100
                )
            ]
        )
        assert request.down_risk_rank_list[0].code == TimeRangeCode.ONE_YEAR


class TestRatioRankFilter:
    """测试比率排名筛选"""

    def test_sharperatio_rank_list(self, client):
        """测试夏普比率同类排名筛选"""
        request = FundFilterRequest(
            sharperatio_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=30
                )
            ]
        )
        assert request.sharperatio_rank_list[0].min_value == 1
        assert request.sharperatio_rank_list[0].max_value == 30

    def test_kama_rank_list(self, client):
        """测试卡玛比率同类排名筛选"""
        request = FundFilterRequest(
            kama_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=50
                )
            ]
        )
        assert len(request.kama_rank_list) == 1

    def test_info_rank_list(self, client):
        """测试信息比率同类排名筛选"""
        request = FundFilterRequest(
            info_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=100
                )
            ]
        )
        assert request.info_rank_list[0].code == TimeRangeCode.ONE_YEAR


class TestHoldingFilter:
    """测试持仓相关筛选"""

    def test_industry_list(self, client):
        """测试持仓行业偏好筛选"""
        request = FundFilterRequest(
            industry_list=[
                FundOrderRankValueV2DTO(
                    code="technology",
                    min_value=20,
                    max_value=100
                )
            ]
        )
        assert request.industry_list[0].code == "technology"

    def test_style_list(self, client):
        """测试持仓风格偏好筛选"""
        request = FundFilterRequest(
            style_list=[
                FundOrderRankValueV2DTO(
                    code="growth",
                    min_value=30,
                    max_value=100
                )
            ]
        )
        assert request.style_list[0].code == "growth"

    def test_stock_list(self, client):
        """测试重仓集中度筛选"""
        request = FundFilterRequest(
            stock_list=[
                FundFilterRangeV2DTO(min_value=30, max_value=80)
            ]
        )
        assert request.stock_list[0].min_value == 30

    def test_turnover_list(self, client):
        """测试换手率筛选"""
        request = FundFilterRequest(
            turnover_list=[
                FundFilterRangeV2DTO(min_value=50, max_value=300)
            ]
        )
        assert request.turnover_list[0].max_value == 300

    def test_not_industry_code_list(self, client):
        """测试行业风格不持有集合"""
        request = FundFilterRequest(
            not_industry_code_list=["real_estate", "coal"]
        )
        assert "real_estate" in request.not_industry_code_list
        assert "coal" in request.not_industry_code_list

    def test_org_proportion_list(self, client):
        """测试机构占比筛选"""
        request = FundFilterRequest(
            org_proportion_list=[
                FundFilterRangeV2DTO(min_value=10, max_value=90)
            ]
        )
        assert request.org_proportion_list[0].min_value == 10


class TestManagerFilter:
    """测试基金经理相关筛选"""

    def test_mgr_code_list(self, client):
        """测试基金经理代码筛选"""
        request = FundFilterRequest(
            mgr_code_list=["M001", "M002", "M003"]
        )
        assert "M001" in request.mgr_code_list
        assert "M002" in request.mgr_code_list
        assert len(request.mgr_code_list) == 3

    def test_mgr_awards_num_yes(self, client):
        """测试经理获奖筛选：是"""
        request = FundFilterRequest(
            mgr_awards_num=1
        )
        assert request.mgr_awards_num == 1

    def test_mgr_awards_num_no(self, client):
        """测试经理获奖筛选：否"""
        request = FundFilterRequest(
            mgr_awards_num=0
        )
        assert request.mgr_awards_num == 0

    def test_mgr_fund_specification_list(self, client):
        """测试经理管理规模筛选"""
        request = FundFilterRequest(
            mgr_fund_specification_list=[
                FundFilterRangeV2DTO(min_value=50, max_value=500)
            ]
        )
        assert request.mgr_fund_specification_list[0].min_value == 50

    def test_mgr_employ_year_list(self, client):
        """测试经理从业年限筛选"""
        request = FundFilterRequest(
            mgr_employ_year_list=[
                FundFilterRangeV2DTO(min_value=5, max_value=20)
            ]
        )
        assert request.mgr_employ_year_list[0].min_value == 5

    def test_mgr_fund_employ_year_list(self, client):
        """测试当前在管时长筛选"""
        request = FundFilterRequest(
            mgr_fund_employ_year_list=[
                FundFilterRangeV2DTO(min_value=2, max_value=10)
            ]
        )
        assert request.mgr_fund_employ_year_list[0].max_value == 10

    def test_mgr_fund_year_ret_list(self, client):
        """测试经理任期年化回报筛选"""
        request = FundFilterRequest(
            mgr_fund_year_ret_list=[
                FundFilterRangeV2DTO(min_value=8, max_value=25)
            ]
        )
        assert request.mgr_fund_year_ret_list[0].min_value == 8


class TestComplexFilter:
    """测试复杂组合筛选"""

    def test_multiple_conditions(self, client):
        """测试多条件组合"""
        request = FundFilterRequest(
            page_num=1,
            page_size=20,
            company_code_list=["80000248"],
            risk_level_list=[RiskLevel.R3, RiskLevel.R4],
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=10, max_value=100)
            ],
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=10,
                    max_value=50
                )
            ],
            draw_down_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=-20,
                    max_value=0
                )
            ],
            sharperatio_rank_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=1,
                    max_value=30
                )
            ],
            mgr_code_list=["M001"],
            sort_by="per1y",
            sort_type="DESC"
        )

        # 验证所有条件
        assert request.page_num == 1
        assert request.page_size == 20
        assert "80000248" in request.company_code_list
        assert RiskLevel.R3 in request.risk_level_list
        assert request.fund_specification_list[0].min_value == 10
        assert request.ret_list[0].code == TimeRangeCode.ONE_YEAR
        assert request.draw_down_list[0].min_value == -20
        assert request.sharperatio_rank_list[0].max_value == 30
        assert "M001" in request.mgr_code_list
        assert request.sort_by == "per1y"

    def test_all_time_range_codes(self, client):
        """测试所有时间区间代码"""
        time_codes = [
            TimeRangeCode.REALTIME,
            TimeRangeCode.ONE_WEEK,
            TimeRangeCode.ONE_MONTH,
            TimeRangeCode.THREE_MONTH,
            TimeRangeCode.SIX_MONTH,
            TimeRangeCode.ONE_YEAR,
            TimeRangeCode.TWO_YEAR,
            TimeRangeCode.THREE_YEAR,
            TimeRangeCode.FIVE_YEAR,
            TimeRangeCode.TEN_YEAR,
            TimeRangeCode.SINCE_ESTABLISH,
            TimeRangeCode.YEAR_TO_DATE,
        ]

        for code in time_codes:
            request = FundFilterRequest(
                ret_list=[FundOrderRankValueV2DTO(code=code, min_value=0)]
            )
            assert request.ret_list[0].code == code

    def test_decimal_values(self, client):
        """测试 Decimal 值处理"""
        request = FundFilterRequest(
            fund_specification_list=[
                FundFilterRangeV2DTO(
                    min_value=Decimal("10.5"),
                    max_value=Decimal("100.75")
                )
            ],
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=Decimal("15.25"),
                    max_value=Decimal("50.50")
                )
            ]
        )

        assert request.fund_specification_list[0].min_value == Decimal("10.5")
        assert request.ret_list[0].min_value == Decimal("15.25")


class TestRequestSerialization:
    """测试请求序列化"""

    def test_serialization_with_alias(self, client):
        """测试带别名的序列化"""
        request = FundFilterRequest(
            page_num=2,
            page_size=50,
            company_code_list=["80000248"],
            risk_level_list=[RiskLevel.R3]
        )

        data = request.model_dump(by_alias=True, exclude_none=True)

        # 验证别名
        assert "pageNum" in data
        assert "pageSize" in data
        assert "companyCodeList" in data
        assert "riskLevelList" in data

        # 验证值
        assert data["pageNum"] == 2
        assert data["pageSize"] == 50
        assert data["companyCodeList"] == ["80000248"]

    def test_serialization_excludes_none(self, client):
        """测试排除 None 值"""
        request = FundFilterRequest(
            page_num=1,
            page_size=20
        )

        data = request.model_dump(by_alias=True, exclude_none=True)

        # 基础参数应该存在
        assert "pageNum" in data
        assert "pageSize" in data

        # None 值应该被排除
        assert "companyCodeList" not in data
        assert "riskLevelList" not in data

    def test_serialization_with_dto(self, client):
        """测试包含 DTO 的序列化"""
        request = FundFilterRequest(
            fund_specification_list=[
                FundFilterRangeV2DTO(min_value=10, max_value=100)
            ],
            ret_list=[
                FundOrderRankValueV2DTO(
                    code=TimeRangeCode.ONE_YEAR,
                    min_value=15,
                    max_value=50
                )
            ]
        )

        data = request.model_dump(by_alias=True, exclude_none=True)

        assert "fundSpecificationList" in data
        assert "retList" in data
        assert data["fundSpecificationList"][0]["minValue"] == 10
        assert data["retList"][0]["code"] == TimeRangeCode.ONE_YEAR
