"""客户端测试"""
import pytest
from unittest.mock import Mock, patch

from caichacha_sdk import FundFilterClient
from caichacha_sdk.exceptions import APIError, NetworkError, ValidationError
from caichacha_sdk.models import FundFilterRequest, FundFilterResponse


class TestFundFilterClient:
    """测试 FundFilterClient"""

    def test_init_default(self):
        client = FundFilterClient()
        assert client.base_url == "http://192.168.90.209:6098"
        assert client.timeout == 30

    def test_init_custom(self):
        client = FundFilterClient(
            base_url="http://custom.url",
            timeout=60,
            headers={"X-Custom": "value"}
        )
        assert client.base_url == "http://custom.url"
        assert client.timeout == 60
        assert client.session.headers["X-Custom"] == "value"

    def test_init_trailing_slash(self):
        client = FundFilterClient(base_url="http://example.com/")
        assert client.base_url == "http://example.com"

    @patch('caichacha_sdk.client.requests.Session.post')
    def test_fund_filter_v2_success(self, mock_post):
        # 模拟成功响应
        mock_response = Mock()
        mock_response.json.return_value = {
            "code": 0,
            "msg": "成功",
            "data": {
                "list": [],
                "pageNum": 1,
                "pageSize": 20,
                "pages": 0,
                "total": 0
            }
        }
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response

        client = FundFilterClient()
        request = FundFilterRequest(page_num=1, page_size=20)
        response = client.fund_filter_v2(request)

        assert response.is_success is True
        assert response.code == 0
        mock_post.assert_called_once()

    @patch('caichacha_sdk.client.requests.Session.post')
    def test_fund_filter_v2_api_error(self, mock_post):
        # 模拟 API 错误响应
        mock_response = Mock()
        mock_response.json.return_value = {
            "code": 500,
            "msg": "系统错误",
            "data": None
        }
        mock_response.raise_for_status.return_value = None
        mock_post.return_value = mock_response

        client = FundFilterClient()
        request = FundFilterRequest()
        response = client.fund_filter_v2(request)

        assert response.is_success is False
        assert response.code == 500

    @patch('caichacha_sdk.client.requests.Session.post')
    def test_fund_filter_v2_network_error(self, mock_post):
        # 模拟网络错误
        import requests
        mock_post.side_effect = requests.Timeout()

        client = FundFilterClient()
        request = FundFilterRequest()

        with pytest.raises(NetworkError) as exc_info:
            client.fund_filter_v2(request)

        assert "超时" in str(exc_info.value.message)

    def test_context_manager(self):
        with FundFilterClient() as client:
            assert isinstance(client, FundFilterClient)

    @patch('caichacha_sdk.client.requests.Session.close')
    def test_close(self, mock_close):
        client = FundFilterClient()
        client.close()
        mock_close.assert_called_once()


class TestFundFilterClientIntegration:
    """集成测试（可选）"""

    @pytest.mark.skip(reason="需要实际 API 环境")
    def test_real_api_call(self):
        """测试真实 API 调用"""
        client = FundFilterClient()
        request = FundFilterRequest(
            page_num=1,
            page_size=10
        )
        response = client.fund_filter_v2(request)

        assert response.is_success is True
        assert response.data is not None
        assert isinstance(response.fund_list, list)
