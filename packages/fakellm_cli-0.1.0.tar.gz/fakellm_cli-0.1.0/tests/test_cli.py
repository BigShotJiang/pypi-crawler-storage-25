"""Tests for fakellm-cli.

These build a realistic .fakellm/judgments/judgments.json by hand (matching the
schema fakellm-assert writes) and exercise each command through main(), so the
argparse wiring is covered too. No network, no fakellm-assert import required.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from fakellm_cli.cli import main
from fakellm_cli import core


def _record(fp, criterion, verdict, *, model="gpt-4o-mini", reasoning="because reasons", excerpt="Sorry for the delay."):
    return {
        "fingerprint": fp,
        "criterion": criterion,
        "verdict": verdict,
        "reasoning": reasoning,
        "judge_model": model,
        "response_excerpt": excerpt,
        "judged_at": "2026-05-24T21:00:00+00:00",
    }


@pytest.fixture
def store(tmp_path: Path) -> Path:
    d = tmp_path / ".fakellm" / "judgments"
    d.mkdir(parents=True)
    data = {
        "aaaa1111": _record("aaaa1111", "apologizes for the delay", "pass"),
        "bbbb2222": _record("bbbb2222", "offers a refund", "fail", reasoning="no refund mentioned"),
        "cccc3333": _record("cccc3333", "responds in character as a dwarf", "pass", model="claude-3-5-sonnet"),
    }
    (d / "judgments.json").write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", "utf-8")
    return d / "judgments.json"


def test_list(capsys, store):
    rc = main(["list", "--store", str(store)])
    out = capsys.readouterr().out
    assert rc == 0
    assert "3 frozen verdict(s)" in out
    assert "apologizes for the delay" in out
    assert "offers a refund" in out


def test_list_json(capsys, store):
    rc = main(["list", "--store", str(store), "--json"])
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert len(payload) == 3
    assert {r["criterion"] for r in payload} >= {"offers a refund", "apologizes for the delay"}


def test_list_filter_verdict(capsys, store):
    main(["list", "--store", str(store), "--verdict", "fail", "--json"])
    payload = json.loads(capsys.readouterr().out)
    assert len(payload) == 1
    assert payload[0]["criterion"] == "offers a refund"


def test_list_missing_store(capsys, tmp_path):
    rc = main(["list", "--store", str(tmp_path / "nope")])
    err = capsys.readouterr().err
    assert rc == 2
    assert "no snapshot store" in err


def test_show_by_fingerprint(capsys, store):
    rc = main(["show", "--store", str(store), "bbbb"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "offers a refund" in out
    assert "no refund mentioned" in out
    assert "FAIL" in out


def test_show_by_criterion(capsys, store):
    rc = main(["show", "--store", str(store), "dwarf"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "responds in character as a dwarf" in out


def test_show_ambiguous(capsys, store):
    # substring "o" matches multiple criteria
    rc = main(["show", "--store", str(store), "o"])
    assert rc == 1
    assert "matches" in capsys.readouterr().out


def test_show_no_match(capsys, store):
    rc = main(["show", "--store", str(store), "zzzz"])
    assert rc == 1
    assert "no verdict matches" in capsys.readouterr().err


def test_verify_clean(capsys, store):
    rc = main(["verify", "--store", str(store)])
    assert rc == 0
    assert "no integrity problems" in capsys.readouterr().out


def test_verify_detects_bad_verdict(capsys, tmp_path):
    d = tmp_path / "j"
    d.mkdir()
    bad = {"x1": _record("x1", "crit", "maybe")}  # invalid verdict
    (d / "judgments.json").write_text(json.dumps(bad), "utf-8")
    rc = main(["verify", "--store", str(d)])
    assert rc == 1
    assert "not 'pass'/'fail'" in capsys.readouterr().out


def test_verify_detects_key_mismatch(capsys, tmp_path):
    d = tmp_path / "j"
    d.mkdir()
    bad = {"keyA": _record("fingerprintB", "crit", "pass")}
    (d / "judgments.json").write_text(json.dumps(bad), "utf-8")
    rc = main(["verify", "--store", str(d)])
    assert rc == 1
    assert "does not match" in capsys.readouterr().out


def test_prune_dry_run_default(capsys, store):
    rc = main(["prune", "--store", str(store), "--verdict", "fail"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "would remove" in out
    # nothing actually deleted
    data = json.loads(store.read_text())
    assert len(data) == 3


def test_prune_applies_with_yes(capsys, store):
    rc = main(["prune", "--store", str(store), "--verdict", "fail", "--yes"])
    out = capsys.readouterr().out
    assert rc == 0
    assert "removed 1 verdict" in out
    data = json.loads(store.read_text())
    assert len(data) == 2
    assert "bbbb2222" not in data


def test_prune_refuses_without_filter(capsys, store):
    rc = main(["prune", "--store", str(store)])
    assert rc == 2
    assert "refusing to prune" in capsys.readouterr().err
    assert len(json.loads(store.read_text())) == 3


def test_prune_by_fingerprint(capsys, store):
    rc = main(["prune", "--store", str(store), "--fingerprint", "aaaa", "--yes"])
    assert rc == 0
    data = json.loads(store.read_text())
    assert "aaaa1111" not in data


def test_diff_flip(capsys, tmp_path):
    a = tmp_path / "a"
    b = tmp_path / "b"
    a.mkdir()
    b.mkdir()
    (a / "judgments.json").write_text(json.dumps({"f1": _record("f1", "apologizes", "pass")}), "utf-8")
    # same criterion+model, different verdict and (realistically) different fp
    (b / "judgments.json").write_text(json.dumps({"f2": _record("f2", "apologizes", "fail")}), "utf-8")
    rc = main(["diff", str(a), str(b)])
    out = capsys.readouterr().out
    assert rc == 1  # flips are a non-zero exit
    assert "flipped" in out and "pass" in out and "fail" in out


def test_diff_identical(capsys, tmp_path):
    a = tmp_path / "a"
    a.mkdir()
    (a / "judgments.json").write_text(json.dumps({"f1": _record("f1", "apologizes", "pass")}), "utf-8")
    rc = main(["diff", str(a), str(a)])
    assert rc == 0
    assert "identical" in capsys.readouterr().out


def test_init_creates_scaffold(capsys, tmp_path):
    rc = main(["init", "--root", str(tmp_path)])
    assert rc == 0
    assert (tmp_path / ".fakellm" / "judgments").is_dir()
    assert (tmp_path / ".fakellm" / "judgments" / ".gitkeep").exists()
    assert (tmp_path / "conftest.py").exists()
    assert "CallableJudge" in (tmp_path / "conftest.py").read_text()


def test_init_skips_existing_conftest(capsys, tmp_path):
    (tmp_path / "conftest.py").write_text("# mine\n", "utf-8")
    main(["init", "--root", str(tmp_path)])
    assert (tmp_path / "conftest.py").read_text() == "# mine\n"  # untouched


def test_init_force_overwrites(capsys, tmp_path):
    (tmp_path / "conftest.py").write_text("# mine\n", "utf-8")
    main(["init", "--root", str(tmp_path), "--force"])
    assert "CallableJudge" in (tmp_path / "conftest.py").read_text()


def test_resolve_store_path_accepts_dir_or_file(tmp_path):
    as_file = core.resolve_store_path(str(tmp_path / "x" / "judgments.json"))
    as_dir = core.resolve_store_path(str(tmp_path / "x"))
    assert as_file.name == "judgments.json"
    assert as_dir.name == "judgments.json"


def test_no_command_prints_help(capsys):
    rc = main([])
    assert rc == 0
    assert "usage" in capsys.readouterr().out.lower()
