"""Snapshot access layer for the fakellm-assert judgment store.

This is the one module that touches the on-disk format, so it is written to
stay faithful to ``fakellm-assert`` rather than reinvent it. When the library
is installed we reuse its ``Judgment`` dataclass and ``SnapshotStore`` directly,
which means the CLI cannot silently drift from the format the library writes.
When it is *not* installed (someone just wants to inspect a checked-in
``.fakellm/`` directory), we fall back to a small reader over the same JSON
schema.

The store layout, per fakellm-assert v0:

    .fakellm/judgments/judgments.json   # one JSON object, fingerprint -> record

Each record is a serialized ``Judgment``::

    {
      "fingerprint":       "<sha256 hex>",
      "criterion":         "apologizes for the delay",
      "verdict":           "pass" | "fail",
      "reasoning":         "<one sentence from the judge>",
      "judge_model":       "gpt-4o-mini",
      "response_excerpt":  "<first 280 chars of the response>",
      "judged_at":         "2026-05-24T21:00:00+00:00"
    }
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

# Default location, mirroring fakellm_assert.judge._Config.snapshot_dir.
DEFAULT_SNAPSHOT_DIR = ".fakellm/judgments"
SNAPSHOT_FILENAME = "judgments.json"

# Fields we expect in every record. Used by the fallback reader and by
# `verify` to detect schema drift.
REQUIRED_FIELDS = (
    "fingerprint",
    "criterion",
    "verdict",
    "reasoning",
    "judge_model",
    "response_excerpt",
    "judged_at",
)


# ---------------------------------------------------------------------------
# Optional reuse of the library's own types.
# ---------------------------------------------------------------------------

try:  # pragma: no cover - exercised by whichever environment runs the tests
    from fakellm_assert.store import Judgment as _LibJudgment  # type: ignore
    from fakellm_assert.store import SnapshotStore as _LibSnapshotStore  # type: ignore

    HAVE_LIB = True
except Exception:  # ImportError, or a future rename — degrade gracefully.
    _LibJudgment = None  # type: ignore
    _LibSnapshotStore = None  # type: ignore
    HAVE_LIB = False


@dataclass
class JudgmentRecord:
    """A CLI-side view of one frozen verdict.

    Intentionally a plain dataclass with the same fields as the library's
    ``Judgment`` so the CLI works whether or not fakellm-assert is importable.
    """

    fingerprint: str
    criterion: str
    verdict: str
    reasoning: str
    judge_model: str
    response_excerpt: str
    judged_at: str

    @property
    def passed(self) -> bool:
        return self.verdict == "pass"

    @classmethod
    def from_dict(cls, record: dict) -> "JudgmentRecord":
        # Tolerate unknown/extra keys so a newer library schema doesn't crash
        # an older CLI; only pull the fields we know about.
        return cls(**{k: record.get(k, "") for k in REQUIRED_FIELDS})


class SnapshotFileNotFound(FileNotFoundError):
    """Raised when the resolved snapshot file does not exist."""


def resolve_store_path(
    snapshot_dir: Optional[str] = None,
    *,
    root: Optional[Path] = None,
) -> Path:
    """Return the path to the judgments JSON file.

    ``snapshot_dir`` may be either the directory holding ``judgments.json`` or
    the JSON file itself, so ``--store .fakellm/judgments/judgments.json`` and
    ``--store .fakellm/judgments`` both work.
    """
    base = Path(root) if root is not None else Path.cwd()
    raw = snapshot_dir or DEFAULT_SNAPSHOT_DIR
    candidate = (base / raw) if not Path(raw).is_absolute() else Path(raw)
    if candidate.suffix == ".json":
        return candidate
    return candidate / SNAPSHOT_FILENAME


def load_raw(path: Path) -> dict[str, dict]:
    """Load the fingerprint->record mapping. Empty dict if the file is absent."""
    if not path.exists():
        raise SnapshotFileNotFound(path)
    try:
        data = json.loads(path.read_text("utf-8"))
    except (json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"{path} is not valid JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"{path} should contain a JSON object, got {type(data).__name__}")
    return data


def load_records(path: Path) -> list[JudgmentRecord]:
    """Load all judgments as CLI records, sorted by criterion then model."""
    raw = load_raw(path)
    records = [JudgmentRecord.from_dict(r) for r in raw.values()]
    records.sort(key=lambda r: (r.criterion.lower(), r.judge_model, r.fingerprint))
    return records


def write_raw(path: Path, data: dict[str, dict]) -> None:
    """Write the mapping back using the same diff-friendly format the library
    uses (indent=2, sorted keys, trailing newline)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(data, indent=2, sort_keys=True) + "\n"
    path.write_text(serialized, "utf-8")


def fingerprints_for(
    records: Iterable[JudgmentRecord],
    *,
    criterion_substr: Optional[str] = None,
    verdict: Optional[str] = None,
    model: Optional[str] = None,
) -> list[str]:
    """Filter records and return their fingerprints (used by `prune`)."""
    out: list[str] = []
    for r in records:
        if criterion_substr and criterion_substr.lower() not in r.criterion.lower():
            continue
        if verdict and r.verdict != verdict:
            continue
        if model and r.judge_model != model:
            continue
        out.append(r.fingerprint)
    return out
