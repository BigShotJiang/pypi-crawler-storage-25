"""fakellm-cli: inspect and manage fakellm-assert frozen judgment snapshots.

    $ fakellm-cli list
    $ fakellm-cli show "apologizes for the delay"
    $ fakellm-cli verify
    $ fakellm-cli prune --verdict fail --yes
    $ fakellm-cli diff main-snapshots/ feature-snapshots/
    $ fakellm-cli init

Part of the fakellm family. The CLI manages the artifacts that
`pytest --fakellm-update` produces; it never judges live itself.
"""

from __future__ import annotations

__version__ = "0.1.0"

from .cli import main

__all__ = ["main", "__version__"]
