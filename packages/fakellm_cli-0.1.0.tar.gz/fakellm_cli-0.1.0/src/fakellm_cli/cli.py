"""``fakellm-cli`` — inspect and manage frozen judgment snapshots.

A companion to ``fakellm-assert``. It operates on the ``.fakellm/judgments``
store the library writes: list, show, verify, prune, and diff frozen verdicts,
plus scaffold a new project.

Note on scope: this tool deliberately does NOT re-judge responses. Once a
verdict is frozen, the store keeps only a short response excerpt, not the full
text needed to recompute a fingerprint — and re-judging is a live model call
that belongs in an explicit, reviewed `pytest --fakellm-update` run, where the
real responses exist. The CLI manages the artifacts; pytest produces them.
"""

from __future__ import annotations

import argparse
import sys
from typing import Optional, Sequence

from . import __version__
from . import commands as cmd


def _add_store_arg(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--store",
        metavar="PATH",
        default=None,
        help="Path to the judgments dir or judgments.json "
        "(default: .fakellm/judgments).",
    )


def _add_json_arg(p: argparse.ArgumentParser) -> None:
    p.add_argument(
        "--json",
        dest="as_json",
        action="store_true",
        help="Emit machine-readable JSON instead of formatted text.",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="fakellm-cli",
        description="Inspect and manage fakellm-assert frozen judgment snapshots.",
    )
    parser.add_argument("--version", action="version", version=f"fakellm-cli {__version__}")
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    # list
    p_list = sub.add_parser("list", help="List frozen verdicts.")
    _add_store_arg(p_list)
    _add_json_arg(p_list)
    p_list.add_argument("--verdict", choices=("pass", "fail"), help="Only show this verdict.")
    p_list.add_argument("--model", help="Only show verdicts from this judge model.")

    # show
    p_show = sub.add_parser("show", help="Show one verdict in full (reasoning + excerpt).")
    _add_store_arg(p_show)
    _add_json_arg(p_show)
    p_show.add_argument("selector", help="Fingerprint prefix or criterion substring.")

    # verify
    p_verify = sub.add_parser("verify", help="Check store integrity (schema, verdict values, key match).")
    _add_store_arg(p_verify)
    _add_json_arg(p_verify)

    # prune
    p_prune = sub.add_parser("prune", help="Remove frozen verdicts matching a filter (dry-run by default).")
    _add_store_arg(p_prune)
    p_prune.add_argument("--criterion", help="Match by criterion substring.")
    p_prune.add_argument("--verdict", choices=("pass", "fail"), help="Match by verdict.")
    p_prune.add_argument("--model", help="Match by judge model.")
    p_prune.add_argument("--fingerprint", help="Match by fingerprint prefix.")
    p_prune.add_argument("--yes", action="store_true", help="Actually delete (otherwise dry run).")

    # diff
    p_diff = sub.add_parser("diff", help="Compare two stores; report added/removed/flipped verdicts.")
    _add_json_arg(p_diff)
    p_diff.add_argument("store_a", help="First store (dir or json).")
    p_diff.add_argument("store_b", help="Second store (dir or json).")

    # init
    p_init = sub.add_parser("init", help="Scaffold .fakellm/ and a conftest.py judge stub.")
    p_init.add_argument("--root", default=None, help="Project root (default: cwd).")
    p_init.add_argument("--no-conftest", action="store_true", help="Don't write a conftest.py stub.")
    p_init.add_argument("--force", action="store_true", help="Overwrite an existing conftest.py.")

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 0

    if args.command == "list":
        return cmd.cmd_list(
            args.store, as_json=args.as_json, verdict=args.verdict, model=args.model
        )
    if args.command == "show":
        return cmd.cmd_show(args.store, args.selector, as_json=args.as_json)
    if args.command == "verify":
        return cmd.cmd_verify(args.store, as_json=args.as_json)
    if args.command == "prune":
        return cmd.cmd_prune(
            args.store,
            criterion=args.criterion,
            verdict=args.verdict,
            model=args.model,
            fingerprint=args.fingerprint,
            dry_run=not args.yes,
        )
    if args.command == "diff":
        return cmd.cmd_diff(args.store_a, args.store_b, as_json=args.as_json)
    if args.command == "init":
        return cmd.cmd_init(
            root=args.root, write_conftest=not args.no_conftest, force=args.force
        )

    parser.print_help()
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
