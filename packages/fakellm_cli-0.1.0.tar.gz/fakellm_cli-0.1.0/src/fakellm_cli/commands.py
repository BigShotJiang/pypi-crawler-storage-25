"""Command implementations.

Each command is a plain function returning an exit code, kept separate from the
argparse wiring in ``cli.py`` so it can be unit-tested without spawning a
process. Output goes through small helpers so ``--json`` can be honored
uniformly.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Optional, Sequence

from .core import (
    DEFAULT_SNAPSHOT_DIR,
    REQUIRED_FIELDS,
    JudgmentRecord,
    SnapshotFileNotFound,
    fingerprints_for,
    load_raw,
    load_records,
    resolve_store_path,
    write_raw,
)

# ANSI helpers. Disabled automatically when stdout is not a TTY so piped/CI
# output stays clean.
_USE_COLOR = sys.stdout.isatty()


def _c(code: str, text: str) -> str:
    if not _USE_COLOR:
        return text
    return f"\033[{code}m{text}\033[0m"


def _green(t: str) -> str:
    return _c("32", t)


def _red(t: str) -> str:
    return _c("31", t)


def _dim(t: str) -> str:
    return _c("2", t)


def _bold(t: str) -> str:
    return _c("1", t)


def _verdict_badge(verdict: str) -> str:
    return _green("PASS") if verdict == "pass" else _red("FAIL")


def _short_fp(fp: str, n: int = 12) -> str:
    return fp[:n]


def _print_err(msg: str) -> None:
    print(_red("error:") + " " + msg, file=sys.stderr)


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------

def cmd_list(
    store: Optional[str],
    *,
    as_json: bool = False,
    verdict: Optional[str] = None,
    model: Optional[str] = None,
) -> int:
    path = resolve_store_path(store)
    try:
        records = load_records(path)
    except SnapshotFileNotFound:
        _print_err(f"no snapshot store at {path}. Run `fakellm-cli init` or judge with `pytest --fakellm-update`.")
        return 2
    except ValueError as exc:
        _print_err(str(exc))
        return 2

    if verdict:
        records = [r for r in records if r.verdict == verdict]
    if model:
        records = [r for r in records if r.judge_model == model]

    if as_json:
        print(json.dumps([_record_as_dict(r) for r in records], indent=2))
        return 0

    if not records:
        print(_dim("(no frozen verdicts match)"))
        return 0

    n_pass = sum(1 for r in records if r.passed)
    n_fail = len(records) - n_pass
    print(_bold(f"{len(records)} frozen verdict(s)") + _dim(f"  ({n_pass} pass, {n_fail} fail)  {path}"))
    print()
    for r in records:
        crit = r.criterion if len(r.criterion) <= 68 else r.criterion[:65] + "..."
        print(f"  {_verdict_badge(r.verdict)}  {_dim(_short_fp(r.fingerprint))}  {crit}")
        print(f"        {_dim(r.judge_model + '  ·  ' + r.judged_at)}")
    return 0


# ---------------------------------------------------------------------------
# show
# ---------------------------------------------------------------------------

def cmd_show(store: Optional[str], selector: str, *, as_json: bool = False) -> int:
    path = resolve_store_path(store)
    try:
        records = load_records(path)
    except SnapshotFileNotFound:
        _print_err(f"no snapshot store at {path}.")
        return 2
    except ValueError as exc:
        _print_err(str(exc))
        return 2

    matches = [
        r
        for r in records
        if r.fingerprint.startswith(selector) or selector.lower() in r.criterion.lower()
    ]
    if not matches:
        _print_err(f"no verdict matches {selector!r} (by fingerprint prefix or criterion substring).")
        return 1
    if len(matches) > 1 and not as_json:
        print(_dim(f"{len(matches)} matches for {selector!r}:"))
        for r in matches:
            print(f"  {_short_fp(r.fingerprint)}  {r.criterion}")
        print(_dim("\nnarrow the selector (e.g. a longer fingerprint prefix) to show one."))
        return 1

    if as_json:
        print(json.dumps([_record_as_dict(r) for r in matches], indent=2))
        return 0

    r = matches[0]
    print(_bold("criterion  ") + " " + r.criterion)
    print(_bold("verdict    ") + " " + _verdict_badge(r.verdict))
    print(_bold("judge      ") + " " + r.judge_model)
    print(_bold("judged_at  ") + " " + r.judged_at)
    print(_bold("fingerprint") + " " + _dim(r.fingerprint))
    print()
    print(_bold("reasoning"))
    print("  " + r.reasoning)
    print()
    print(_bold("response excerpt"))
    for line in (r.response_excerpt or "").splitlines() or ["(empty)"]:
        print("  " + _dim(line))
    return 0


# ---------------------------------------------------------------------------
# prune
# ---------------------------------------------------------------------------

def cmd_prune(
    store: Optional[str],
    *,
    criterion: Optional[str] = None,
    verdict: Optional[str] = None,
    model: Optional[str] = None,
    fingerprint: Optional[str] = None,
    dry_run: bool = True,
) -> int:
    """Remove frozen verdicts matching a filter.

    Defaults to a dry run: nothing is deleted unless ``--yes`` (dry_run=False)
    is passed. This is destructive — a pruned verdict must be re-judged with
    `pytest --fakellm-update`.
    """
    path = resolve_store_path(store)
    try:
        raw = load_raw(path)
    except SnapshotFileNotFound:
        _print_err(f"no snapshot store at {path}.")
        return 2
    except ValueError as exc:
        _print_err(str(exc))
        return 2

    records = [JudgmentRecord.from_dict(r) for r in raw.values()]

    if fingerprint:
        targets = [fp for fp in raw if fp.startswith(fingerprint)]
    else:
        targets = fingerprints_for(
            records, criterion_substr=criterion, verdict=verdict, model=model
        )

    if not (criterion or verdict or model or fingerprint):
        _print_err("refusing to prune with no filter; pass --criterion/--verdict/--model/--fingerprint.")
        return 2

    if not targets:
        print(_dim("nothing matches the filter; nothing to prune."))
        return 0

    target_set = set(targets)
    for fp in target_set:
        rec = JudgmentRecord.from_dict(raw[fp])
        verb = "would remove" if dry_run else "removing"
        print(f"  {verb}  {_verdict_badge(rec.verdict)}  {_short_fp(fp)}  {rec.criterion}")

    if dry_run:
        print()
        print(_dim(f"dry run — {len(target_set)} verdict(s) would be removed. Re-run with --yes to apply."))
        return 0

    for fp in target_set:
        del raw[fp]
    write_raw(path, raw)
    print()
    print(_bold(f"removed {len(target_set)} verdict(s).") + _dim(" Re-judge with `pytest --fakellm-update`."))
    return 0


# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------

def cmd_verify(store: Optional[str], *, as_json: bool = False) -> int:
    """Structural integrity check on the store.

    Catches the failure modes a human review would want flagged: malformed
    records, bad verdict values, fingerprint/key mismatches, empty reasoning on
    a FAIL. Does NOT and cannot re-run the judge — see the note in the README
    about why live re-judging stays in pytest.
    """
    path = resolve_store_path(store)
    try:
        raw = load_raw(path)
    except SnapshotFileNotFound:
        _print_err(f"no snapshot store at {path}.")
        return 2
    except ValueError as exc:
        _print_err(str(exc))
        return 2

    problems: list[str] = []
    for key, record in raw.items():
        if not isinstance(record, dict):
            problems.append(f"{key}: record is not an object")
            continue
        missing = [f for f in REQUIRED_FIELDS if f not in record]
        if missing:
            problems.append(f"{_short_fp(key)}: missing field(s): {', '.join(missing)}")
        verdict = record.get("verdict")
        if verdict not in ("pass", "fail"):
            problems.append(f"{_short_fp(key)}: verdict {verdict!r} is not 'pass'/'fail'")
        if record.get("fingerprint") and record["fingerprint"] != key:
            problems.append(f"{_short_fp(key)}: key does not match record fingerprint {_short_fp(record['fingerprint'])}")
        if verdict == "fail" and not (record.get("reasoning") or "").strip():
            problems.append(f"{_short_fp(key)}: FAIL verdict has empty reasoning")

    if as_json:
        print(json.dumps({"store": str(path), "count": len(raw), "problems": problems}, indent=2))
        return 0 if not problems else 1

    if not problems:
        print(_green("ok") + f"  {len(raw)} verdict(s) in {path}, no integrity problems.")
        return 0

    print(_red(f"{len(problems)} problem(s) in {path}:"))
    for p in problems:
        print("  - " + p)
    return 1


# ---------------------------------------------------------------------------
# diff
# ---------------------------------------------------------------------------

def cmd_diff(store_a: str, store_b: str, *, as_json: bool = False) -> int:
    """Compare two stores (e.g. a feature branch's vs main's), reporting which
    criteria were added, removed, or flipped pass<->fail."""
    pa, pb = resolve_store_path(store_a), resolve_store_path(store_b)
    try:
        ra = {r.fingerprint: r for r in load_records(pa)}
        rb = {r.fingerprint: r for r in load_records(pb)}
    except SnapshotFileNotFound as exc:
        _print_err(f"missing store: {exc}")
        return 2
    except ValueError as exc:
        _print_err(str(exc))
        return 2

    # Match on criterion+model so we can detect verdict flips even though the
    # fingerprint (which includes response text) differs between the two.
    def by_crit(recs: dict[str, JudgmentRecord]) -> dict[tuple[str, str], JudgmentRecord]:
        return {(r.criterion, r.judge_model): r for r in recs.values()}

    ca, cb = by_crit(ra), by_crit(rb)
    added = sorted(set(cb) - set(ca))
    removed = sorted(set(ca) - set(cb))
    flipped = sorted(k for k in (set(ca) & set(cb)) if ca[k].verdict != cb[k].verdict)

    if as_json:
        print(json.dumps({
            "a": str(pa), "b": str(pb),
            "added": [{"criterion": c, "model": m} for c, m in added],
            "removed": [{"criterion": c, "model": m} for c, m in removed],
            "flipped": [
                {"criterion": c, "model": m, "from": ca[(c, m)].verdict, "to": cb[(c, m)].verdict}
                for c, m in flipped
            ],
        }, indent=2))
        return 0 if not flipped else 1

    print(_bold("diff") + _dim(f"  {pa}  →  {pb}"))
    if not (added or removed or flipped):
        print(_dim("  identical (by criterion + model)"))
        return 0
    for c, m in flipped:
        print(f"  {_red('~')} flipped {ca[(c,m)].verdict}→{cb[(c,m)].verdict}  {c}  {_dim(m)}")
    for c, m in added:
        print(f"  {_green('+')} added   {c}  {_dim(m)}")
    for c, m in removed:
        print(f"  {_red('-')} removed {c}  {_dim(m)}")
    return 1 if flipped else 0


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------

_CONFTEST_STUB = '''\
"""fakellm-assert judge wiring. Generated by `fakellm-cli init`.

The judge is only ever called during `pytest --fakellm-update`. In normal
(replay) runs it is never invoked, so CI stays offline. Swap the body of
run_judge for whichever model you want to grade your fuzzy assertions.
"""

from fakellm_assert import configure, CallableJudge


def run_judge(prompt: str) -> str:
    # TODO: call your model here and return its raw text. For example, with
    # the OpenAI SDK:
    #
    #     from openai import OpenAI
    #     client = OpenAI()
    #     return client.chat.completions.create(
    #         model="gpt-4o-mini",
    #         messages=[{"role": "user", "content": prompt}],
    #     ).choices[0].message.content
    raise NotImplementedError("wire fakellm-cli init's run_judge to your model")


configure(judge=CallableJudge(run_judge, model_name="gpt-4o-mini"))
'''


def cmd_init(*, root: Optional[str] = None, write_conftest: bool = True, force: bool = False) -> int:
    base = Path(root) if root else Path.cwd()
    snap_dir = base / DEFAULT_SNAPSHOT_DIR
    created: list[str] = []
    skipped: list[str] = []

    snap_dir.mkdir(parents=True, exist_ok=True)
    created.append(str(snap_dir) + "/")

    # A .gitkeep so the empty dir is committable before the first verdict.
    gitkeep = snap_dir / ".gitkeep"
    if not gitkeep.exists():
        gitkeep.write_text("", "utf-8")
        created.append(str(gitkeep))

    if write_conftest:
        conftest = base / "conftest.py"
        if conftest.exists() and not force:
            skipped.append(str(conftest) + _dim("  (exists; pass --force to overwrite)"))
        else:
            conftest.write_text(_CONFTEST_STUB, "utf-8")
            created.append(str(conftest))

    for c in created:
        print(_green("created") + "  " + c)
    for s in skipped:
        print(_dim("skipped") + "  " + s)
    print()
    print(_dim("next: edit conftest.py's run_judge, then `pytest --fakellm-update` to freeze verdicts."))
    return 0


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _record_as_dict(r: JudgmentRecord) -> dict:
    return {
        "fingerprint": r.fingerprint,
        "criterion": r.criterion,
        "verdict": r.verdict,
        "reasoning": r.reasoning,
        "judge_model": r.judge_model,
        "response_excerpt": r.response_excerpt,
        "judged_at": r.judged_at,
    }
