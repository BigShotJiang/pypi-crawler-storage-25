import requests
from pokeclient.utils import download_image, safe_request, format_stats

class PokeClient:
    BASE_URL = "https://pokeapi.co/api/v2/"

    # --- Funções básicas ---
    def get_pokemon(self, name_or_id):
        url = f"{self.BASE_URL}pokemon/{name_or_id}"
        return safe_request(url)

    def get_pokemon_name(self, name_or_id):
        return self.get_pokemon(name_or_id).get("name", None)

    def get_pokemon_types(self, name_or_id):
        data = self.get_pokemon(name_or_id)
        return [t["type"]["name"] for t in data.get("types", [])]

    def get_pokemon_list(self, limit=10, offset=0):
        url = f"{self.BASE_URL}pokemon?limit={limit}&offset={offset}"
        data = safe_request(url)
        return [p["name"] for p in data["results"]] if data else None

    # --- Imagens ---
    def get_pokemon_image_url(self, name_or_id, shiny=False):
        data = self.get_pokemon(name_or_id)
        return data["sprites"]["front_shiny"] if shiny else data["sprites"]["front_default"]

    def get_pokemon_animated_sprite(self, name_or_id):
        data = self.get_pokemon(name_or_id)
        try:
            return data["sprites"]["versions"]["generation-v"]["black-white"]["animated"]["front_default"]
        except KeyError:
            return None

    def get_pokemon_official_artwork(self, name_or_id):
        data = self.get_pokemon(name_or_id)
        try:
            return data["sprites"]["other"]["official-artwork"]["front_default"]
        except KeyError:
            return None

    def download_pokemon_artwork(self, name_or_id, folder="images"):
        url = self.get_pokemon_official_artwork(name_or_id)
        return download_image(url, f"{name_or_id}_artwork.png", folder)

    def download_pokemon_animated(self, name_or_id, folder="images"):
        url = self.get_pokemon_animated_sprite(name_or_id)
        return download_image(url, f"{name_or_id}_animated.gif", folder)

    # --- Dados avançados ---
    def get_pokemon_stats(self, name_or_id):
        data = self.get_pokemon(name_or_id)
        stats = {s["stat"]["name"]: s["base_stat"] for s in data.get("stats", [])}
        return format_stats(stats)

    def get_pokemon_abilities(self, name_or_id):
        data = self.get_pokemon(name_or_id)
        return [a["ability"]["name"] for a in data.get("abilities", [])]

    def get_evolution_chain(self, name_or_id):
        species_url = f"{self.BASE_URL}pokemon-species/{name_or_id}"
        species_data = safe_request(species_url)
        evo_url = species_data["evolution_chain"]["url"]
        evo_data = safe_request(evo_url)

        chain = []
        def parse_chain(chain_data):
            chain.append(chain_data["species"]["name"])
            for evo in chain_data.get("evolves_to", []):
                parse_chain(evo)

        parse_chain(evo_data["chain"])
        return chain

    def get_generation(self, generation_id):
        url = f"{self.BASE_URL}generation/{generation_id}"
        return safe_request(url)

    def get_region(self, region_id):
        url = f"{self.BASE_URL}region/{region_id}"
        return safe_request(url)
