import requests
import os

def download_image(url, filename, folder="images"):
    """Baixa qualquer imagem a partir de uma URL"""
    if url:
        response = requests.get(url)
        if response.status_code == 200:
            os.makedirs(folder, exist_ok=True)
            filepath = os.path.join(folder, filename)
            with open(filepath, "wb") as f:
                f.write(response.content)
            return filepath
    return None

def format_stats(stats_dict):
    """Formata estatísticas em uma string legível"""
    return "\n".join([f"{stat.capitalize()}: {value}" for stat, value in stats_dict.items()])

def format_list(items, title="Lista"):
    """Formata listas de forma amigável"""
    return f"{title}:\n" + "\n".join([f"- {item}" for item in items])

def safe_request(url):
    """Faz requisições com tratamento de erro"""
    try:
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        print(f"Erro na requisição: {e}")
    return None
