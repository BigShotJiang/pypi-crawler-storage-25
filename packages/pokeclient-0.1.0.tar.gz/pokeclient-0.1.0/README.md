# pokeclient

Biblioteca Python para acessar a [PokéAPI](https://pokeapi.co/) de forma simples e organizada.

## Instalação

Se você usa **uv**:

```bash
uv init
uv add requests
uv pip install .

```

from pokeclient.client import PokeClient

client = PokeClient()

print(client.get_pokemon_name("gengar"))         # gengar
print(client.get_pokemon_types("lucario"))       # ["fighting", "steel"]
print(client.get_pokemon_stats("charizard"))     # HP: 78, Attack: 84, ...
print(client.get_pokemon_abilities("pikachu"))   # ["static", "lightning-rod"]
print(client.get_evolution_chain("eevee"))       # ["eevee", "vaporeon", "jolteon", ...]

print(client.get_pokemon_official_artwork("mewtwo")) # link da artwork grande
print(client.get_pokemon_animated_sprite("pikachu")) # link do GIF animado
print(client.get_generation(1)["pokemon_species"])   # lista da geração 1
print(client.get_region(1)["locations"])             # locais da região Kanto



```cli 
# Consultar nome
python pokecli.py pikachu

# Consultar tipos
python pokecli.py charizard --types

# Consultar estatísticas
python pokecli.py bulbasaur --stats

# Consultar habilidades
python pokecli.py gengar --abilities

# Consultar cadeia evolutiva
python pokecli.py eevee --evolution

# Consultar artwork oficial
python pokecli.py mewtwo --artwork

# Consultar sprite animada
python pokecli.py pikachu --animated

