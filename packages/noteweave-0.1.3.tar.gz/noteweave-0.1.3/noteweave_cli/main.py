"""
NoteWeave CLI — Terminal client.

HTTP for: auth, health, chat (SSE streaming)
WebSocket for: full ReACT agent pipeline

Slash commands:
  /login, /logout         — auth
  /health, /status        — server status
  /voice                  — hold-to-record voice input
  /files [pattern]        — list workspace files
  /read <path>            — read and display a file
  /add <path>             — add file to context for next message
  /context                — show attached context files
  /clear                  — clear context + chat history
  /workspace              — show workspace path
  /help                   — show all commands
  /quit                   — exit

@ file mentions:
  @filename.py            — attach file to context (tab-completion)
  @                       — browse all workspace files
"""
from __future__ import annotations

import argparse
import asyncio
import glob
import os

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from noteweave_cli.theme import (
    NW_THEME, PRIMARY, PRIMARY_LT, MUTED, CREAM,
    SUCCESS, ERROR, CYAN, YELLOW, BLUE,
    print_welcome,
)

console = Console(theme=NW_THEME)

# ── Environment configs ──────────────────────────────────────────────────────

ENVS = {
    "local": {
        "server": "http://localhost:7432",
        "dashboard": "http://localhost:3000",
    },
    "prod": {
        "server": "https://api.noteweave.io",
        "dashboard": "https://apps.noteweave.io",
    },
}
WEBSITE = "https://www.noteweave.io"


def cli_main() -> None:
    parser = argparse.ArgumentParser(prog="noteweave", description="NoteWeave CLI")
    # Dev-only flags — hidden from --help
    parser.add_argument("--local", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--server", default=None, help=argparse.SUPPRESS)
    parser.add_argument("command", nargs="?", default=None)

    args = parser.parse_args()

    if args.server:
        env = {"server": args.server, "dashboard": ENVS["prod"]["dashboard"]}
    elif args.local:
        env = ENVS["local"]
    else:
        env = ENVS["prod"]

    # Everything happens inside the REPL
    asyncio.run(_repl(env))


async def _repl(env: dict) -> None:
    from noteweave_cli.auth import is_logged_in, login, auth_headers, verify_token

    server = env["server"]
    dashboard = env["dashboard"]

    os.system("clear" if os.name == "posix" else "cls")

    if not is_logged_in():
        print_welcome(console)
        console.print(f"[{YELLOW}]You need to log in first.[/]\n")
        if not login(server, dashboard):
            return

    # Get user info for welcome banner
    headers = auth_headers()
    user_info = verify_token(server) or {}
    user_email = user_info.get("email", "")
    user_plan = user_info.get("plan", "")

    print_welcome(console, user_email=user_email, plan=user_plan)

    from noteweave_cli.client import NoteWeaveClient
    client = NoteWeaveClient(server, headers, console)

    if client.health() == "unreachable":
        console.print(f"[{ERROR}]Server not reachable. Check your connection.[/]")
        return

    console.print(f"[{SUCCESS}]Connected.[/]")

    # ── Workspace setup ──────────────────────────────────────────────────
    workspace = _setup_workspace()
    os.chdir(workspace)

    # Initialize terminal session (tmux if available)
    from noteweave_cli.executor import init_terminal
    init_terminal(workspace)

    # Scan workspace for existing files and prior context
    _scan_workspace(workspace)

    # Session state
    chat_history: list[dict] = []
    context_files: list[str] = []  # paths of attached files
    ws_connected = False

    while True:
        try:
            # Show context indicator in prompt
            ctx_indicator = f" [{CYAN}]({len(context_files)} files)[/]" if context_files else ""
            user_input = await asyncio.get_event_loop().run_in_executor(
                None, lambda: console.input(f"[{PRIMARY_LT}]noteweave >[/]{ctx_indicator} ")
            )
        except (KeyboardInterrupt, EOFError):
            console.print(f"\n[{MUTED}]Goodbye.[/]")
            break

        text = user_input.strip()
        if not text:
            continue

        low = text.lower()

        # ── Slash commands ────────────────────────────────────────────────
        if low in ("/quit", "/exit", "quit", "exit"):
            console.print(f"[{MUTED}]Goodbye.[/]")
            break

        if low in ("/help", "?"):
            _print_help()
            continue

        if low == "/login":
            from noteweave_cli.auth import login as do_login
            if do_login(server, dashboard):
                headers = auth_headers()
                client = NoteWeaveClient(server, headers, console)
                console.print(f"[{SUCCESS}]Logged in.[/]")
            continue

        if low == "/logout":
            from noteweave_cli.auth import logout
            logout()
            console.print(f"[{MUTED}]Logged out. Use /login to sign in again.[/]")
            continue

        if low in ("/status", "/health"):
            console.print(f"[{MUTED}]{client.health()}[/]")
            continue

        if low == "/explore":
            # Switch to exploration mode — prefix message to route to exploration
            console.print(f"[bold {PRIMARY}]Exploration mode[/] [{MUTED}]— search papers, analyze, build research brief[/]")
            console.print(f"[{MUTED}]Type your research topic or question:[/]")
            topic = await asyncio.get_event_loop().run_in_executor(
                None, lambda: console.input(f"[{PRIMARY_LT}]explore >[/] ")
            )
            if topic.strip():
                text = f"[DIRECT:exploration] {topic.strip()}"
                # Fall through to pipeline send below
            else:
                continue

        if low == "/execution":
            console.print(f"[{YELLOW}]Execution agent — coming soon.[/]")
            console.print(f"[{MUTED}]This will run experiments, write code, and execute plans.[/]")
            continue

        if low == "/tools":
            _print_tools()
            continue

        if low == "/voice":
            from noteweave_cli.voice import record_and_transcribe
            transcribed = await record_and_transcribe(server, headers, console)
            if transcribed:
                console.print(f"[{MUTED}]Transcribed:[/] {transcribed}")
                console.print(f"[{MUTED}]Press Enter to send, or edit below:[/]")
                edited = await asyncio.get_event_loop().run_in_executor(
                    None, lambda: console.input(f"[{PRIMARY_LT}]>[/] ") or transcribed
                )
                text = edited.strip() or transcribed
                # Fall through to chat/pipeline handling below
            else:
                continue

        if low == "/workspace":
            console.print(f"[{MUTED}]{workspace}[/]")
            continue

        if low.startswith("/workspace set "):
            new_path = os.path.expanduser(text[15:].strip())
            if not os.path.isabs(new_path):
                new_path = os.path.abspath(new_path)
            os.makedirs(new_path, exist_ok=True)
            workspace = new_path
            os.chdir(workspace)
            console.print(f"[{SUCCESS}]Workspace set to: {workspace}[/]")
            continue

        if low.startswith("/workspace create "):
            name = text[18:].strip()
            new_path = os.path.join(os.path.expanduser("~/noteweave_workspaces"), name)
            os.makedirs(new_path, exist_ok=True)
            workspace = new_path
            os.chdir(workspace)
            console.print(f"[{SUCCESS}]Created workspace: {workspace}[/]")
            continue

        if low.startswith("/bash ") or low.startswith("! "):
            cmd = text[6:].strip() if low.startswith("/bash ") else text[2:].strip()
            if cmd:
                from noteweave_cli.executor import run_code
                run_code(cmd, workspace)
            continue

        if low.startswith("/files"):
            pattern = text[6:].strip() or "**/*"
            _list_files(workspace, pattern)
            continue

        if low.startswith("/read "):
            path = text[6:].strip()
            _read_file(workspace, path)
            continue

        if low.startswith("/add "):
            path = text[5:].strip()
            matches = _resolve_path(workspace, path)
            if matches:
                for m in matches:
                    if m not in context_files:
                        context_files.append(m)
                        console.print(f"[{SUCCESS}]+ {m}[/]")
                    else:
                        console.print(f"[{MUTED}]Already added: {m}[/]")
            else:
                console.print(f"[{ERROR}]No files match: {path}[/]")
            continue

        if low == "/context":
            if context_files:
                console.print(f"[bold {CREAM}]Attached context files:[/]")
                for f in context_files:
                    console.print(f"  [{CYAN}]{f}[/]")
            else:
                console.print(f"[{MUTED}]No files attached. Use /add <path> or @filename[/]")
            continue

        if low == "/clear":
            context_files.clear()
            chat_history.clear()
            console.print(f"[{MUTED}]Context and chat history cleared.[/]")
            continue

        # ── @ file mentions ───────────────────────────────────────────────
        if "@" in text:
            text, new_files = _extract_at_mentions(workspace, text)
            for f in new_files:
                if f not in context_files:
                    context_files.append(f)
                    console.print(f"[{SUCCESS}]+ {f}[/]")
            if not text:
                continue

        # ── Send message to agent pipeline (WS) ─────────────────────────
        if not ws_connected:
            session_id = f"cli_{os.getpid()}"
            ws_connected = await client.connect_ws(session_id)
            if not ws_connected:
                continue

        message = text
        if context_files:
            file_context = _build_file_context(workspace, context_files)
            message = f"{file_context}\n\n{text}"

        await client.run_pipeline(message)

    if ws_connected:
        await client.disconnect_ws()


# ── Workspace setup ───────────────────────────────────────────────────────────

WORKSPACE_CONFIG = os.path.expanduser("~/.noteweave/workspace")

def _setup_workspace() -> str:
    """Interactive workspace setup on first run, or load saved workspace."""
    # Check for saved workspace
    if os.path.isfile(WORKSPACE_CONFIG):
        saved = open(WORKSPACE_CONFIG).read().strip()
        if os.path.isdir(saved):
            return saved

    console.print(f"\n[bold {CREAM}]Workspace Setup[/]")
    console.print(f"[{MUTED}]Where should NoteWeave store research files?[/]\n")
    console.print(f"  [bold]1.[/] Use current directory: [{CYAN}]{os.getcwd()}[/]")
    console.print(f"  [bold]2.[/] Create new workspace")
    console.print(f"  [bold]3.[/] Enter custom path\n")

    from rich.prompt import Prompt
    choice = Prompt.ask("Choose", choices=["1", "2", "3"], default="1")

    if choice == "1":
        ws = os.getcwd()
    elif choice == "2":
        name = Prompt.ask("Workspace name", default="my-research")
        ws = os.path.join(os.path.expanduser("~/noteweave_workspaces"), name)
        os.makedirs(ws, exist_ok=True)
        console.print(f"[{SUCCESS}]Created: {ws}[/]")
    else:
        path = Prompt.ask("Path")
        ws = os.path.expanduser(path)
        os.makedirs(ws, exist_ok=True)

    # Save for next time
    os.makedirs(os.path.dirname(WORKSPACE_CONFIG), exist_ok=True)
    with open(WORKSPACE_CONFIG, "w") as f:
        f.write(ws)

    return ws


def _scan_workspace(workspace: str) -> None:
    """Scan workspace and show what's there — like a checkpoint resume."""
    nw_dir = os.path.join(workspace, ".noteweave")
    has_context = os.path.isdir(nw_dir) and any(
        f.startswith("context_") for f in os.listdir(nw_dir) if os.path.isfile(os.path.join(nw_dir, f))
    )

    console.print(f"\n[bold {CREAM}]Workspace:[/] [{CYAN}]{workspace}[/]")

    if has_context:
        console.print(f"[{SUCCESS}]Prior NoteWeave work found:[/]")
        stages = {"exploration": "~", "execution": "#"}
        for stage, icon in stages.items():
            ctx_file = os.path.join(nw_dir, f"context_{stage}.md")
            if os.path.isfile(ctx_file):
                size = os.path.getsize(ctx_file)
                console.print(f"  [{PRIMARY}]{icon}[/] {stage}: [{SUCCESS}]done[/] ({size:,} bytes)")
            else:
                console.print(f"  [{PRIMARY}]{icon}[/] {stage}: [{MUTED}]pending[/]")
        console.print(f"[{MUTED}]Agents will auto-load prior context to continue where you left off.[/]")
    else:
        # Count files in workspace
        file_count = sum(1 for _ in glob.iglob(os.path.join(workspace, "**/*"), recursive=True)
                         if os.path.isfile(_) and ".git" not in _ and "__pycache__" not in _)
        if file_count > 0:
            console.print(f"[{MUTED}]{file_count} files found — agents will use them as context.[/]")
        else:
            console.print(f"[{MUTED}]Empty workspace — fresh start.[/]")
    console.print()


# ── File utilities ────────────────────────────────────────────────────────────

def _list_files(workspace: str, pattern: str = "**/*") -> None:
    """List files matching a glob pattern in the workspace."""
    matches = sorted(glob.glob(os.path.join(workspace, pattern), recursive=True))
    # Filter out common noise
    filtered = [
        os.path.relpath(m, workspace) for m in matches
        if os.path.isfile(m)
        and "node_modules" not in m
        and "__pycache__" not in m
        and ".git/" not in m
        and not m.endswith(".pyc")
    ][:50]

    if not filtered:
        console.print(f"[{MUTED}]No files found.[/]")
        return

    t = Table(title=f"Files ({len(filtered)} shown)", show_header=False, padding=(0, 1))
    t.add_column(style=CYAN)
    for f in filtered:
        t.add_row(f)
    console.print(t)


def _read_file(workspace: str, path: str) -> None:
    """Read and display a file with syntax highlighting."""
    full = os.path.join(workspace, path) if not os.path.isabs(path) else path
    if not os.path.isfile(full):
        console.print(f"[{ERROR}]File not found: {path}[/]")
        return

    try:
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read(10_000)

        ext = os.path.splitext(path)[1].lstrip(".")
        lexer = {"py": "python", "js": "javascript", "ts": "typescript", "json": "json",
                 "yaml": "yaml", "yml": "yaml", "md": "markdown", "txt": "text"}.get(ext, ext or "text")

        console.print(Panel(
            Syntax(content, lexer, theme="monokai", line_numbers=True),
            title=f"[{CYAN}]{path}[/]",
            border_style=PRIMARY,
        ))
    except Exception as e:
        console.print(f"[{ERROR}]Error reading {path}: {e}[/]")


def _resolve_path(workspace: str, pattern: str) -> list[str]:
    """Resolve a path/glob pattern to matching files."""
    # Try exact match first
    full = os.path.join(workspace, pattern)
    if os.path.isfile(full):
        return [pattern]

    # Try glob
    matches = glob.glob(os.path.join(workspace, pattern), recursive=True)
    return [os.path.relpath(m, workspace) for m in matches if os.path.isfile(m)][:10]


def _extract_at_mentions(workspace: str, text: str) -> tuple[str, list[str]]:
    """Extract @filename mentions from text. Returns (cleaned_text, file_paths)."""
    import re
    files = []
    cleaned = text

    # Match @path/to/file.ext patterns
    for match in re.finditer(r'@([\w./\-]+\.\w+)', text):
        path = match.group(1)
        full = os.path.join(workspace, path)
        if os.path.isfile(full):
            files.append(path)
            cleaned = cleaned.replace(f"@{path}", "")

    return cleaned.strip(), files


def _build_file_context(workspace: str, paths: list[str]) -> str:
    """Build a context block from attached files (same format as extension)."""
    sections = []
    for path in paths[:6]:
        full = os.path.join(workspace, path)
        try:
            with open(full, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read(4000)
            sections.append(f"### {path}\n```\n{content}\n```")
        except OSError:
            pass
    if sections:
        return "Attached files:\n\n" + "\n\n".join(sections)
    return ""


# ── UI helpers ────────────────────────────────────────────────────────────────

def _print_help() -> None:
    t = Table.grid(padding=(0, 3))
    t.add_column(style=f"bold {PRIMARY_LT}")
    t.add_column(style=MUTED)

    t.add_row(f"[bold {CREAM}]Chat[/]", "")
    t.add_row("  Any message", "Send to the research agent")
    t.add_row("  @file.py message", "Attach file as context")

    t.add_row("", "")
    t.add_row(f"[bold {CREAM}]Agents[/]", "")
    t.add_row("  /explore", "Exploration — search, analyze, build brief")
    t.add_row(f"  /execution", f"[{YELLOW}]Coming soon[/]")
    t.add_row("  /tools", "Show exploration agent tools")

    t.add_row("", "")
    t.add_row(f"[bold {CREAM}]Voice[/]", "")
    t.add_row("  /voice", "Record audio and transcribe to text")

    t.add_row("", "")
    t.add_row(f"[bold {CREAM}]Files[/]", "")
    t.add_row("  /files [pattern]", "List workspace files (glob)")
    t.add_row("  /read <path>", "Read and display a file")
    t.add_row("  /add <path>", "Add file to context")
    t.add_row("  /context", "Show attached files")
    t.add_row("  /clear", "Clear context + history")

    t.add_row("", "")
    t.add_row(f"[bold {CREAM}]Shell[/]", "")
    t.add_row("  /bash <command>", "Run shell command in workspace")
    t.add_row("  ! <command>", "Shorthand for /bash")

    t.add_row("", "")
    t.add_row(f"[bold {CREAM}]Workspace[/]", "")
    t.add_row("  /workspace", "Show current workspace path")
    t.add_row("  /workspace set <path>", "Change workspace")
    t.add_row("  /workspace create <name>", "Create new workspace")

    t.add_row("", "")
    t.add_row(f"[bold {CREAM}]System[/]", "")
    t.add_row("  /login", "Sign in")
    t.add_row("  /logout", "Sign out")
    t.add_row("  /status", "Server health")
    t.add_row("  /help", "This help")
    t.add_row("  /quit", "Exit")

    console.print(Panel(t, title=f"[{PRIMARY}]noteweave[/] [{MUTED}]commands[/]", border_style=PRIMARY, padding=(1, 2)))


def _print_tools() -> None:
    """Show tools available to the exploration agent."""
    t = Table.grid(padding=(0, 3))
    t.add_column(style=f"bold {PRIMARY_LT}")
    t.add_column(style=MUTED)

    t.add_row(f"[bold {CREAM}]Exploration Agent Tools[/]", "")
    t.add_row("", "")
    t.add_row("  search_papers", "Search Semantic Scholar + arXiv for papers")
    t.add_row("  download_and_read", "Download PDF and extract full text")
    t.add_row("  deep_analysis", "Run E3 two-pass critic on a paper")
    t.add_row("  search_datasets", "Find datasets on HuggingFace + Kaggle")
    t.add_row("  finalize_brief", "Lock in the research brief")
    t.add_row("  write_instructions", "Generate experimental plan from findings")
    t.add_row("  ask_user", "Ask you a clarifying question")

    console.print(Panel(t, title=f"[{PRIMARY}]noteweave[/] [{MUTED}]tools[/]", border_style=PRIMARY, padding=(1, 2)))
