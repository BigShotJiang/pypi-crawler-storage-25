"""
theme.py — NoteWeave CLI brand colors, Rich theme, and welcome banner.

Rosemary/terracotta palette — matches the VS Code extension (media/style.css).
"""
from __future__ import annotations

from rich.theme import Theme

# ── Brand colors (rosemary/terracotta) ───────────────────────────────────────

PRIMARY = "#B75D57"       # terracotta — the core brand color
PRIMARY_LT = "#E6A3A6"   # light rosemary pink
PRIMARY_DK = "#80413D"    # deep rosemary
SURFACE = "#1a1010"       # dark warm brown
TEXT = "#F6F6F6"          # off-white
MUTED = "#d5d1d1"         # warm gray
CREAM = "#FFFCF6"         # warm white
SUCCESS = "#9a9b5e"       # olive
ERROR = "#cf6e68"         # soft red
CYAN = "#a8e8ea"
YELLOW = "#FEF4B5"
BLUE = "#6a9fd4"

VERSION = "0.1.3"

# ── Rich theme ───────────────────────────────────────────────────────────────

NW_THEME = Theme({
    "nw.primary":     f"bold {PRIMARY}",
    "nw.primary.lt":  PRIMARY_LT,
    "nw.dim":         MUTED,
    "nw.text":        TEXT,
    "nw.success":     SUCCESS,
    "nw.error":       f"bold {ERROR}",
    "nw.cyan":        CYAN,
    "nw.yellow":      YELLOW,
    "nw.blue":        BLUE,
    "nw.agent":       f"bold {PRIMARY}",
    "nw.tool":        f"dim {YELLOW}",
    "nw.prompt":      f"bold {PRIMARY_LT}",
    "nw.heading":     f"bold {CREAM}",
})

# ── Pixel-art mascot — wave creature ─────────────────────────────────────────
# A small pixel-art soundwave character matching the NoteWeave wave icon

MASCOT = """\
        ╭╮
  ╭╮   ╱  ╲
 ╱  ╲ ╱    ╲
╯    ╰      ╰"""


def print_welcome(console, user_email: str = "", plan: str = "") -> None:
    """Print a Claude Code-style welcome banner: left=greeting+mascot, right=tips."""
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    # ── Left cell: greeting + mascot ──
    left = Text()
    if user_email:
        left.append("  Welcome back!\n", style=f"bold {CREAM}")
    else:
        left.append("  Welcome to NoteWeave!\n", style=f"bold {CREAM}")
    left.append("\n")
    for line in MASCOT.splitlines():
        left.append(f"   {line}\n", style=PRIMARY_LT)
    left.append("\n")
    if user_email:
        left.append(f"  {user_email}\n", style=PRIMARY_LT)
    if plan:
        left.append(f"  {plan} plan\n", style=MUTED)

    # ── Right cell: tips + quick start ──
    right = Text()
    right.append("Tips\n", style=f"bold {PRIMARY}")
    right.append("  /help     ", style=PRIMARY_LT)
    right.append("Show all commands\n", style=MUTED)
    right.append("  /voice    ", style=PRIMARY_LT)
    right.append("Record & transcribe\n", style=MUTED)
    right.append("  /status   ", style=PRIMARY_LT)
    right.append("Server & auth status\n", style=MUTED)
    right.append("\n")
    right.append("Quick start\n", style=f"bold {PRIMARY}")
    right.append("  Just type what you want to research.\n", style=MUTED)
    right.append("  The agent handles the rest.\n", style=MUTED)

    # Force side-by-side with a Table (won't wrap like Columns)
    grid = Table.grid(padding=(0, 1))
    grid.add_column(ratio=1)
    grid.add_column(ratio=1)
    grid.add_row(left, right)

    console.print(Panel(
        grid,
        title=f"[bold {PRIMARY}]NoteWeave[/] [{MUTED}]v{VERSION}[/]",
        border_style=PRIMARY,
        padding=(1, 2),
    ))
    console.print()
