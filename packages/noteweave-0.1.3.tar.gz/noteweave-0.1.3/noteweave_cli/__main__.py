"""Allow running as: python -m cli [command]"""
from noteweave_cli.main import cli_main

cli_main()
