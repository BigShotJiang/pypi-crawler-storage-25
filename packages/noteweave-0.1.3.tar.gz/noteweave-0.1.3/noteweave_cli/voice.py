"""
voice.py — Voice recording and transcription for the CLI.

Mirrors the VS Code extension mic button flow:
1. Record audio via arecord (Linux ALSA) or ffmpeg (PulseAudio fallback)
2. Send WAV to backend POST /transcribe
3. Return transcribed text

Audio format: 16kHz mono WAV (S16_LE) — optimized for Whisper.
"""
from __future__ import annotations

import os
import shutil
import signal
import subprocess
import tempfile
import time

import requests
from rich.console import Console

from noteweave_cli.theme import PRIMARY, PRIMARY_LT, MUTED, ERROR, SUCCESS, YELLOW


def _find_recorder() -> str | None:
    """Detect available audio recorder: arecord or ffmpeg."""
    if shutil.which("arecord"):
        return "arecord"
    if shutil.which("ffmpeg"):
        return "ffmpeg"
    return None


def _start_recording(recorder: str, wav_path: str) -> subprocess.Popen:
    """Start recording audio to a WAV file."""
    if recorder == "arecord":
        return subprocess.Popen(
            ["arecord", "-f", "S16_LE", "-r", "16000", "-c", "1", "-t", "wav", wav_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    else:
        # ffmpeg with PulseAudio default device
        return subprocess.Popen(
            [
                "ffmpeg", "-y",
                "-f", "pulse", "-i", "default",
                "-ar", "16000", "-ac", "1",
                "-acodec", "pcm_s16le",
                wav_path,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )


def _stop_recording(proc: subprocess.Popen) -> None:
    """Gracefully stop the recording process."""
    try:
        proc.send_signal(signal.SIGTERM)
        proc.wait(timeout=2)
    except (subprocess.TimeoutExpired, ProcessLookupError):
        proc.kill()
    # Extra wait for file flush
    time.sleep(0.3)


def _transcribe(server_url: str, headers: dict, wav_path: str) -> str | None:
    """Send WAV file to backend /transcribe and return text."""
    try:
        with open(wav_path, "rb") as f:
            resp = requests.post(
                f"{server_url}/transcribe",
                headers={k: v for k, v in headers.items() if k == "Authorization"},
                files={"file": ("recording.wav", f, "audio/wav")},
                timeout=30,
            )
        if resp.status_code == 200:
            data = resp.json()
            if data.get("error"):
                return None
            return data.get("text", "").strip() or None
        return None
    except Exception:
        return None


async def record_and_transcribe(
    server_url: str, headers: dict, console: Console
) -> str | None:
    """
    Interactive voice recording flow:
    1. Check for recorder availability
    2. Prompt user to press Enter to start
    3. Record until user presses Enter again
    4. Transcribe and return text
    """
    import asyncio

    recorder = _find_recorder()
    if not recorder:
        console.print(f"[{ERROR}]No audio recorder found. Install arecord (alsa-utils) or ffmpeg.[/]")
        return None

    console.print(f"[{PRIMARY_LT}]Press Enter to start recording...[/]")
    await asyncio.get_event_loop().run_in_executor(None, input)

    wav_path = tempfile.mktemp(suffix=".wav", prefix="nw_voice_")

    console.print(f"[bold {PRIMARY}]Recording...[/] [{MUTED}]Press Enter to stop[/]")
    proc = _start_recording(recorder, wav_path)

    await asyncio.get_event_loop().run_in_executor(None, input)
    _stop_recording(proc)

    # Validate file
    if not os.path.isfile(wav_path) or os.path.getsize(wav_path) < 5000:
        console.print(f"[{YELLOW}]Recording too short or failed. Try again.[/]")
        _cleanup(wav_path)
        return None

    console.print(f"[{MUTED}]Transcribing...[/]")
    text = _transcribe(server_url, headers, wav_path)
    _cleanup(wav_path)

    if text:
        console.print(f"[{SUCCESS}]Got it.[/]")
        return text
    else:
        console.print(f"[{ERROR}]Transcription failed. Check server connection.[/]")
        return None


def _cleanup(path: str) -> None:
    try:
        os.unlink(path)
    except OSError:
        pass
