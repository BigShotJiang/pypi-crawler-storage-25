"""
auth.py — Login/logout and token verification.

Auth flow: user signs in on the NoteWeave dashboard (web), generates an
extension token (nw_ext_*), and pastes it here. No email/password in CLI.
"""
from __future__ import annotations

import os
import webbrowser
from pathlib import Path

import requests
from rich.console import Console
from rich.prompt import Prompt

from noteweave_cli.theme import NW_THEME, PRIMARY, PRIMARY_LT, MUTED, SUCCESS, ERROR, YELLOW, CYAN

TOKEN_DIR = Path.home() / ".noteweave"
TOKEN_FILE = TOKEN_DIR / "token"

console = Console(theme=NW_THEME)


def get_token() -> str | None:
    if TOKEN_FILE.is_file():
        return TOKEN_FILE.read_text().strip()
    return None


def auth_headers() -> dict[str, str]:
    token = get_token()
    if not token:
        return {}
    return {"Authorization": f"Bearer {token}"}


def is_logged_in() -> bool:
    return get_token() is not None


def _store_token(token: str) -> None:
    TOKEN_DIR.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(token)
    TOKEN_FILE.chmod(0o600)


def verify_token(server_url: str, token: str | None = None) -> dict | None:
    token = token or get_token()
    if not token:
        return None
    try:
        resp = requests.post(
            f"{server_url}/auth/verify-token",
            headers={"Authorization": f"Bearer {token}"},
            timeout=10,
        )
        if resp.status_code == 200:
            return resp.json()
        return None
    except requests.ConnectionError:
        return None


def login(server_url: str, dashboard_url: str = "https://apps.noteweave.io") -> bool:
    """Interactive login — open dashboard or paste token."""
    console.print(f"\n[bold {PRIMARY}]noteweave[/] [{MUTED}]login[/]\n")
    console.print(f"  Sign in on the NoteWeave dashboard, generate an extension")
    console.print(f"  token, and paste it below.\n")

    # Offer to open dashboard
    open_browser = Prompt.ask(
        f"  Open dashboard in browser?",
        choices=["yes", "no"],
        default="yes",
    )
    if open_browser == "yes":
        url = f"{dashboard_url}/login"
        console.print(f"  Opening [{CYAN}]{url}[/] ...")
        webbrowser.open(url)
        console.print(f"  [{MUTED}]Sign in > Dashboard > Extension Tokens > Generate > Copy[/]\n")

    # Prompt for token
    token = Prompt.ask(f"  [{PRIMARY_LT}]Paste extension token[/]")
    if not token or not token.startswith("nw_ext_"):
        console.print(f"\n  [{ERROR}]Invalid token — must start with nw_ext_[/]")
        console.print(f"  [{MUTED}]Get one from the dashboard: Extension Tokens > Generate[/]\n")
        return False

    info = verify_token(server_url, token)
    if info and info.get("valid"):
        _store_token(token)
        console.print(f"\n  [{SUCCESS}]Connected as {info['email']}[/]")
        console.print(f"  [{MUTED}]Plan: {info.get('plan', 'free')} | Usage: {info.get('tokens_used', 0):,}/{info.get('tokens_limit', 0):,}[/]\n")
        return True
    else:
        console.print(f"\n  [{ERROR}]Token is invalid or expired.[/]")
        console.print(f"  [{MUTED}]Generate a new one from the dashboard.[/]\n")
        return False


def status(server_url: str) -> None:
    """Show current auth status and usage."""
    token = get_token()
    if not token:
        console.print(f"  [{YELLOW}]Not logged in.[/] Run /login to connect.\n")
        return

    info = verify_token(server_url, token)
    if info and info.get("valid"):
        console.print(f"  [{SUCCESS}]Connected as {info['email']}[/]")
        console.print(f"  [{MUTED}]Name:[/] {info.get('name', '-')}")
        console.print(f"  [{MUTED}]Org:[/]  {info.get('organization', '-')}")
        console.print(f"  [{MUTED}]Plan:[/] {info.get('plan', 'free')}")
        console.print(f"  [{MUTED}]Usage:[/] {info.get('tokens_used', 0):,} / {info.get('tokens_limit', 0):,}\n")
    else:
        console.print(f"  [{ERROR}]Token is invalid or expired.[/] Run /login to reconnect.\n")


def logout() -> None:
    if TOKEN_FILE.is_file():
        TOKEN_FILE.unlink()
    console.print(f"  [{SUCCESS}]Logged out.[/]")
