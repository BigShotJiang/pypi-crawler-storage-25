"""
client.py — HTTP + WebSocket client to the NoteWeave server.

HTTP for: auth, health, simple chat (SSE)
WebSocket for: full ReACT agent pipeline
"""
from __future__ import annotations

import asyncio
import json
import os

import requests
import websockets
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt

from noteweave_cli.executor import write_file, run_code, read_file
from noteweave_cli.context import gather_workspace_context
from noteweave_cli.bfts_runner import BftsRunner
from noteweave_cli.theme import PRIMARY, PRIMARY_LT, MUTED, SUCCESS, ERROR, CYAN, YELLOW


class NoteWeaveClient:
    """Client that talks to the NoteWeave server via HTTP + WS."""

    def __init__(self, server_url: str, headers: dict, console: Console) -> None:
        self.server_url = server_url.rstrip("/")
        self.headers = headers
        self.console = console
        self.ws = None
        self._workspace = os.getcwd()
        self._bfts_runner: BftsRunner | None = None

    # ── HTTP ──────────────────────────────────────────────────────────────────

    def health(self) -> str:
        try:
            return requests.get(f"{self.server_url}/health", timeout=5).text
        except requests.ConnectionError:
            return "unreachable"

    def chat(self, message: str, history: list[dict] | None = None) -> str:
        """Chat via SSE streaming — renders response as formatted markdown."""
        resp = requests.post(
            f"{self.server_url}/chat",
            json={"message": message, "history": history or []},
            headers=self.headers, stream=True, timeout=120,
        )
        if resp.status_code == 401:
            self.console.print(f"[{ERROR}]Auth failed. Run /login[/]")
            return ""
        if resp.status_code != 200:
            self.console.print(f"[{ERROR}]Error: {resp.status_code}[/]")
            return ""

        full = ""
        with Live(Markdown(""), console=self.console, refresh_per_second=8, vertical_overflow="visible") as live:
            for line in resp.iter_lines(decode_unicode=True):
                if line.startswith("data: "):
                    chunk = line[6:]
                    if chunk == "[DONE]":
                        break
                    full += chunk
                    live.update(Markdown(full))

        return full

    # ── WebSocket (ReACT pipeline) ────────────────────────────────────────────

    async def connect_ws(self, session_id: str) -> bool:
        ws_url = self.server_url.replace("http://", "ws://").replace("https://", "wss://")
        token = self.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        url = f"{ws_url}/ws/{session_id}?token={token}"
        try:
            self.ws = await websockets.connect(url, ping_interval=30)
            return True
        except Exception as e:
            self.console.print(f"[{ERROR}]WS connection failed:[/] {e}")
            return False

    async def disconnect_ws(self) -> None:
        if self.ws:
            await self.ws.close()

    async def send_ws(self, msg: dict) -> None:
        if self.ws:
            await self.ws.send(json.dumps(msg))

    async def run_pipeline(self, message: str) -> None:
        """Send a message and handle the full ReACT agent loop."""
        await self.send_ws({
            "type": "workspace_path",
            "path": self._workspace,
            "workspace_summary": self._scan_workspace(),
        })
        await self.send_ws({"type": "message", "text": message})
        await self._drain()

    async def _drain(self) -> None:
        """Process server messages until done/error."""
        try:
            while True:
                raw = await asyncio.wait_for(self.ws.recv(), timeout=300)
                msg = json.loads(raw)
                done = await self._handle(msg)
                if done:
                    return
        except asyncio.TimeoutError:
            self.console.print(f"[{YELLOW}]Timed out waiting for server.[/]")
        except websockets.ConnectionClosed:
            self.console.print(f"[{ERROR}]Connection lost.[/]")

    async def _handle(self, msg: dict) -> bool:
        """Handle one server message. Returns True if pipeline is done."""
        t = msg.get("type")

        if t == "agent_switch":
            self.console.print(
                f"\n[bold {PRIMARY}]● {msg['agent']}[/] "
                f"[{MUTED}]{msg.get('description', '')}[/]"
            )

        elif t == "thought":
            # Show agent reasoning
            text = msg.get("text", "")
            # Extract just the Thought line for cleaner display
            for line in text.split("\n"):
                line = line.strip()
                if line.startswith("Thought:"):
                    self.console.print(f"[dim italic]{line}[/]")
                elif line.startswith("Action:"):
                    self.console.print(f"[{YELLOW}]{line}[/]")

        elif t == "action":
            tool = msg.get("tool", "")
            args = msg.get("args", {})

            if tool == "ask_user":
                # Server is asking user a question
                question = args.get("question", "")
                self.console.print(f"\n[bold]{question}[/]")
                answer = Prompt.ask(f"[{PRIMARY_LT}]>[/]")
                await self.send_ws({"type": "message", "text": answer})

            elif tool == "write_file":
                path = args.get("path", "")
                content = args.get("content", "")
                write_file(path, content, self._workspace)
                await self.send_ws({
                    "type": "observation", "tool": "write_file",
                    "result": json.dumps({"success": True}),
                })

            elif tool in ("run_code", "bash"):
                command = args.get("command", "")
                result = run_code(command, self._workspace)
                await self.send_ws({
                    "type": "observation", "tool": tool,
                    "result": json.dumps(result),
                })

            elif tool == "run_bfts":
                exp_dir = args.get("experiment_dir", ".")
                config_path = args.get("config", "bfts_config.yaml")
                token = self.headers.get("Authorization", "").replace("Bearer ", "")
                self._bfts_runner = BftsRunner(
                    server_url=self.server_url,
                    auth_token=token,
                    workspace=self._workspace,
                    send_ws=self.send_ws,
                    python_path=args.get("python_path", "python3"),
                )
                result = await self._bfts_runner.start(config_path, exp_dir)
                await self.send_ws({
                    "type": "observation", "tool": "run_bfts",
                    "result": json.dumps(result),
                })

            elif tool == "bfts_stop":
                if self._bfts_runner and self._bfts_runner.is_running:
                    self._bfts_runner.send_stop()
                    await self.send_ws({
                        "type": "observation", "tool": "bfts_stop",
                        "result": json.dumps({"stopped": True}),
                    })
                else:
                    await self.send_ws({
                        "type": "observation", "tool": "bfts_stop",
                        "result": json.dumps({"stopped": False, "reason": "BFTS not running"}),
                    })

            elif tool == "bfts_query":
                target = args.get("target", "journal")
                if self._bfts_runner and self._bfts_runner.is_running:
                    self._bfts_runner.send_query(target, **{k: v for k, v in args.items() if k != "target"})
                    # Response will come through the BFTS stdout → _process_stdout → send_ws
                else:
                    await self.send_ws({
                        "type": "observation", "tool": "bfts_query",
                        "result": json.dumps({"error": "BFTS not running"}),
                    })

            elif tool == "list_files":
                dir_path = args.get("path", ".")
                full = os.path.join(self._workspace, dir_path) if not os.path.isabs(dir_path) else dir_path
                try:
                    entries = sorted(os.listdir(full))
                    # Mark directories with /
                    listing = []
                    for e in entries:
                        if e.startswith(".") and e != ".noteweave":
                            continue
                        if e in ("__pycache__", "node_modules", ".venv", ".git"):
                            continue
                        fp = os.path.join(full, e)
                        listing.append(f"{e}/" if os.path.isdir(fp) else e)
                    await self.send_ws({
                        "type": "observation", "tool": "list_files",
                        "result": "\n".join(listing) if listing else "(empty directory)",
                    })
                except OSError as err:
                    await self.send_ws({
                        "type": "observation", "tool": "list_files",
                        "result": f"Error: {err}",
                    })

            elif tool == "read_file":
                path = args.get("path", "")
                offset = int(args.get("offset", 0))
                limit = int(args.get("limit", 4000))
                full = os.path.join(self._workspace, path) if not os.path.isabs(path) else path
                try:
                    with open(full, "r", encoding="utf-8", errors="ignore") as f:
                        if offset:
                            f.seek(offset)
                        content = f.read(limit)
                    result_text = content if content else "(file empty or not found)"
                except OSError:
                    result_text = "(file not found)"
                await self.send_ws({
                    "type": "observation", "tool": "read_file",
                    "result": result_text,
                })

            elif tool == "grep_file":
                path = args.get("path", "")
                pattern = args.get("pattern", "").lower()
                full = os.path.join(self._workspace, path) if not os.path.isabs(path) else path
                try:
                    with open(full, "r", encoding="utf-8", errors="ignore") as f:
                        lines = f.readlines()
                    matches = []
                    for i, line in enumerate(lines, 1):
                        if pattern in line.lower():
                            matches.append(f"L{i}: {line.rstrip()}")
                    result_text = "\n".join(matches[:30]) if matches else f"(no matches for '{pattern}')"
                except OSError:
                    result_text = "(file not found)"
                await self.send_ws({
                    "type": "observation", "tool": "grep_file",
                    "result": result_text,
                })

            else:
                # Server-side tool — just show it's happening
                self.console.print(f"[{YELLOW}]⚙ {tool}[/]")

        elif t == "stream":
            self.console.print(msg.get("text", ""), end="", highlight=False)

        elif t == "draft_section":
            self.console.print(Panel(
                msg.get("content", "")[:500],
                title=f"[{CYAN}]§ {msg.get('section_title', '')}[/]",
                border_style=PRIMARY,
            ))

        elif t == "done":
            self.console.print(f"\n[bold {SUCCESS}]✓ {msg.get('message', 'Done.')}[/]\n")
            return True

        elif t == "error":
            self.console.print(f"\n[bold {ERROR}]✗ {msg.get('message', 'Error')}[/]\n")
            return True

        return False

    def _scan_workspace(self) -> str:
        """Scan local workspace and build summary for the server."""
        import glob as _glob
        ws = self._workspace
        lines = [f"## Workspace: {ws}\n"]

        nw_dir = os.path.join(ws, ".noteweave")
        if os.path.isdir(nw_dir):
            found_stages = []
            for stage in ("exploration", "execution"):
                ctx_file = os.path.join(nw_dir, f"context_{stage}.md")
                if os.path.isfile(ctx_file):
                    found_stages.append(stage)
                    with open(ctx_file, "r", errors="ignore") as f:
                        content = f.read(500)
                    lines.append(f"### Prior {stage} context\n{content}\n")
            if found_stages:
                lines.insert(1, f"**Prior work found:** {', '.join(found_stages)}\n")
            else:
                lines.insert(1, "**Fresh workspace** — no prior NoteWeave context.\n")
        else:
            lines.insert(1, "**Fresh workspace** — no .noteweave directory.\n")

        for ftype, pattern in [("Python", "**/*.py"), ("Markdown", "**/*.md"), ("JSON", "**/*.json")]:
            files = _glob.glob(os.path.join(ws, pattern), recursive=True)
            filtered = [os.path.relpath(f, ws) for f in files
                        if "__pycache__" not in f and ".venv" not in f and "node_modules" not in f][:10]
            if filtered:
                lines.append(f"**{ftype} files:** {', '.join(filtered)}")

        return "\n".join(lines)
