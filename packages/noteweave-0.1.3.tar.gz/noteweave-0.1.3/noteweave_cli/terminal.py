"""
terminal.py — Live terminal integration using tmux.

Instead of capturing command output silently, opens a real terminal pane
in the workspace where the user can watch commands execute live.

Usage:
    term = TerminalSession(workspace="/home/user/project")
    term.start()            # Creates tmux session
    result = term.run("pip install numpy")  # Sends to terminal, captures output
    term.stop()             # Kills tmux session

Falls back to subprocess if tmux is not available.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import time
import tempfile


class TerminalSession:
    """Manages a tmux session for live command execution."""

    def __init__(self, workspace: str, session_name: str = "noteweave") -> None:
        self.workspace = workspace
        self.session_name = session_name
        self._has_tmux = shutil.which("tmux") is not None
        self._active = False

    def start(self) -> bool:
        """Start a tmux session. Returns True if successful."""
        if not self._has_tmux:
            return False

        # Kill existing session if any
        subprocess.run(
            ["tmux", "kill-session", "-t", self.session_name],
            capture_output=True,
        )

        # Create new session
        result = subprocess.run(
            ["tmux", "new-session", "-d", "-s", self.session_name, "-c", self.workspace],
            capture_output=True,
        )
        self._active = result.returncode == 0
        return self._active

    def stop(self) -> None:
        """Kill the tmux session."""
        if self._active:
            subprocess.run(["tmux", "kill-session", "-t", self.session_name], capture_output=True)
            self._active = False

    def run(self, command: str, timeout: int = 300) -> dict:
        """
        Send a command to the tmux session and capture output.

        Uses a temp file to capture stdout/stderr since tmux send-keys
        doesn't return output directly.
        """
        if not self._active:
            # Fallback to regular subprocess
            return self._fallback_run(command, timeout)

        # Create temp file for output capture
        out_file = tempfile.mktemp(suffix=".noteweave.out")

        # Wrap command to capture output
        wrapped = f"{{ {command} ; }} > {out_file} 2>&1 ; echo \"__NW_EXIT_$?__\" >> {out_file}"

        # Send to tmux
        subprocess.run(
            ["tmux", "send-keys", "-t", self.session_name, wrapped, "Enter"],
            capture_output=True,
        )

        # Wait for completion (poll the output file for exit marker)
        start = time.time()
        while time.time() - start < timeout:
            time.sleep(0.5)
            if os.path.isfile(out_file):
                try:
                    content = open(out_file).read()
                    if "__NW_EXIT_" in content:
                        # Extract exit code and output
                        parts = content.rsplit("__NW_EXIT_", 1)
                        stdout = parts[0].strip()
                        exit_code = int(parts[1].strip().rstrip("__")) if len(parts) > 1 else 0
                        os.unlink(out_file)
                        return {"stdout": stdout, "stderr": "", "exit_code": exit_code}
                except (ValueError, OSError):
                    pass

        # Timeout
        try:
            os.unlink(out_file)
        except OSError:
            pass
        return {"stdout": "", "stderr": f"Timeout after {timeout}s", "exit_code": -1}

    def send_keys(self, keys: str) -> None:
        """Send raw keystrokes to the tmux session (for interactive commands)."""
        if self._active:
            subprocess.run(
                ["tmux", "send-keys", "-t", self.session_name, keys, "Enter"],
                capture_output=True,
            )

    def is_active(self) -> bool:
        return self._active

    def _fallback_run(self, command: str, timeout: int) -> dict:
        """Regular subprocess execution when tmux isn't available."""
        try:
            result = subprocess.run(
                command, shell=True, cwd=self.workspace,
                capture_output=True, text=True, timeout=timeout,
                executable="/bin/bash",
            )
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode,
            }
        except subprocess.TimeoutExpired:
            return {"stdout": "", "stderr": f"Timeout after {timeout}s", "exit_code": -1}
        except Exception as e:
            return {"stdout": "", "stderr": str(e), "exit_code": -1}
