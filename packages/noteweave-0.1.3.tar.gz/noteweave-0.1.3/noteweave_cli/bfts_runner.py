"""
bfts_runner.py — Manages a noteweave-bfts subprocess on the client side.

Responsibilities:
1. Check if noteweave-bfts is installed, install if missing
2. Spawn the BFTS process with control protocol (JSON lines on stdin/stdout)
3. Forward LLM requests from BFTS → NoteWeave backend (POST /bfts/llm)
4. Forward status updates from BFTS → backend (WS observation messages)
5. Handle control commands from backend (query, stop, resume)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import shutil
import subprocess
import sys
import threading
from typing import Any, Callable, Awaitable

import requests
from rich.console import Console

logger = logging.getLogger("bfts-runner")
console = Console()


class BftsRunner:
    """
    Manages the noteweave-bfts subprocess lifecycle.

    The runner acts as a bridge between:
    - The BFTS process (JSON lines on stdin/stdout)
    - The NoteWeave backend (HTTP for LLM, WS for status/control)
    """

    def __init__(
        self,
        server_url: str,
        auth_token: str,
        workspace: str,
        send_ws: Callable[[dict], Awaitable[None]],
        python_path: str = "python3",
    ) -> None:
        self.server_url = server_url.rstrip("/")
        self.auth_token = auth_token
        self.workspace = workspace
        self.send_ws = send_ws
        # Resolve relative python paths against workspace
        if python_path and not os.path.isabs(python_path) and python_path not in ("python3", "python"):
            self.python_path = os.path.join(workspace, python_path)
        else:
            self.python_path = python_path
        self._proc: subprocess.Popen | None = None
        self._stdout_thread: threading.Thread | None = None
        self._running = False

    # ── Package management ───────────────────────────────────────────────────

    def ensure_installed(self) -> bool:
        """Check if noteweave-bfts is installed, install if missing."""
        try:
            result = subprocess.run(
                [self.python_path, "-c", "import noteweave_bfts; print(noteweave_bfts.__version__)"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                version = result.stdout.strip()
                console.print(f"[dim]noteweave-bfts v{version} found[/dim]")
                return True
        except Exception:
            pass

        console.print("[yellow]noteweave-bfts not found, installing...[/yellow]")
        try:
            # Detect if uv is available — prefer it over pip
            has_uv = shutil.which("uv") is not None

            # Try: 1) local dev package, 2) GitHub
            local_pkg = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "..", "..", "..", "noteweave-bfts",
            )
            is_local = os.path.exists(os.path.join(local_pkg, "pyproject.toml"))
            source = local_pkg if is_local else "git+https://github.com/Sj0605-DataSci/noteweave-bfts.git"

            if has_uv:
                console.print("[dim]Using uv for installation[/dim]")
                install_args = ["uv", "pip", "install", "--python", self.python_path]
                if is_local:
                    install_args.append("-e")
                install_args.append(source)
            else:
                install_args = [self.python_path, "-m", "pip", "install"]
                if is_local:
                    install_args.append("-e")
                install_args.append(source)

            result = subprocess.run(
                install_args,
                capture_output=True, text=True, timeout=300,
            )
            if result.returncode == 0:
                console.print("[green]noteweave-bfts installed successfully[/green]")
                return True
            else:
                console.print(f"[red]Failed to install noteweave-bfts: {result.stderr[:500]}[/red]")
                return False
        except Exception as e:
            console.print(f"[red]Install error: {e}[/red]")
            return False

    # ── Process lifecycle ────────────────────────────────────────────────────

    async def start(self, config_path: str, experiment_dir: str = ".") -> dict:
        """
        Start the BFTS process. Returns when BFTS completes.

        Args:
            config_path: Path to bfts_config.yaml (relative to experiment_dir)
            experiment_dir: Working directory for BFTS
        """
        if not self.ensure_installed():
            return {"success": False, "error": "Failed to install noteweave-bfts"}

        cwd = os.path.join(self.workspace, experiment_dir)
        cmd = [
            self.python_path, "-m", "noteweave_bfts",
            "--config", config_path,
            "--mode", "noteweave",
        ]

        env = os.environ.copy()
        env["NOTEWEAVE_BFTS_BACKEND"] = "noteweave"
        env["NOTEWEAVE_SERVER_URL"] = self.server_url
        env["NOTEWEAVE_AUTH_TOKEN"] = self.auth_token

        console.print(f"[bold yellow]▶ Starting BFTS: {' '.join(cmd)}[/bold yellow]")
        console.print(f"[dim]  cwd: {cwd}[/dim]")

        self._proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=cwd,
            env=env,
        )
        self._running = True

        # Start stderr reader (goes to console)
        stderr_thread = threading.Thread(
            target=self._read_stderr, daemon=True,
        )
        stderr_thread.start()

        # Process stdout (control protocol) in async loop
        result = await self._process_stdout()

        self._running = False
        self._proc = None
        return result

    async def _process_stdout(self) -> dict:
        """
        Read JSON lines from BFTS stdout and handle them.
        Runs in the async event loop using a thread executor for blocking reads.
        """
        loop = asyncio.get_event_loop()
        final_result: dict = {"success": False, "error": "Process ended unexpectedly"}

        while self._running and self._proc and self._proc.poll() is None:
            try:
                line = await asyncio.wait_for(
                    loop.run_in_executor(None, self._proc.stdout.readline),
                    timeout=None,  # No timeout — wait indefinitely
                )
            except asyncio.TimeoutError:
                continue

            if not line:
                break

            line = line.strip()
            if not line:
                continue

            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue

            msg_type = msg.get("type")

            if msg_type == "status":
                # Forward status to backend
                await self.send_ws({
                    "type": "observation",
                    "tool": "bfts_status",
                    "result": json.dumps(msg),
                })
                console.print(
                    f"[dim cyan]  BFTS: stage={msg.get('stage')} "
                    f"node={msg.get('node_id')} "
                    f"metric={msg.get('metric')}[/dim cyan]"
                )

            elif msg_type == "log":
                level = msg.get("level", "info")
                message = msg.get("message", "")
                if level == "error":
                    console.print(f"[red]  BFTS: {message}[/red]")
                else:
                    console.print(f"[dim]  BFTS: {message}[/dim]")

            elif msg_type == "llm_request":
                # Forward to backend /bfts/llm and send response back
                await self._handle_llm_request(msg)

            elif msg_type == "query_result":
                # Forward to backend
                await self.send_ws({
                    "type": "observation",
                    "tool": "bfts_query",
                    "result": json.dumps(msg),
                })

            elif msg_type == "done":
                final_result = {
                    "success": msg.get("success", False),
                    "summary": msg.get("summary", {}),
                }

            elif msg_type == "error":
                console.print(f"[red]  BFTS error: {msg.get('message')}[/red]")

        # Wait for process to finish
        if self._proc:
            self._proc.wait(timeout=10)

        return final_result

    async def _handle_llm_request(self, msg: dict) -> None:
        """Forward LLM request to backend /bfts/llm and send response back to BFTS."""
        req_id = msg.get("req_id", "")
        try:
            resp = requests.post(
                f"{self.server_url}/bfts/llm",
                json={
                    "system": msg.get("system"),
                    "user": msg.get("user"),
                    "model": msg.get("model", ""),
                    "temperature": msg.get("temperature", 0.7),
                    "func_spec": msg.get("func_spec"),
                    "max_tokens": msg.get("max_tokens"),
                },
                headers={
                    "Authorization": f"Bearer {self.auth_token}",
                    "Content-Type": "application/json",
                },
                timeout=600,
            )

            if resp.ok:
                data = resp.json()
                content = data.get("content", "")
            else:
                content = f"Error: LLM proxy returned {resp.status_code}: {resp.text[:200]}"

        except Exception as e:
            content = f"Error: LLM request failed: {e}"

        # Send response back to BFTS process stdin
        self._send_to_process({
            "type": "llm_response",
            "req_id": req_id,
            "content": content,
        })

    def _send_to_process(self, msg: dict) -> None:
        """Send a JSON message to the BFTS process via stdin."""
        if self._proc and self._proc.stdin and self._proc.poll() is None:
            try:
                line = json.dumps(msg) + "\n"
                self._proc.stdin.write(line)
                self._proc.stdin.flush()
            except (BrokenPipeError, OSError):
                pass

    def _read_stderr(self) -> None:
        """Read BFTS stderr and print to console."""
        if not self._proc or not self._proc.stderr:
            return
        for line in self._proc.stderr:
            if line.strip():
                console.print(f"[dim]{line.rstrip()}[/dim]")

    # ── Control commands (called by client.py when backend sends them) ───────

    def send_stop(self) -> None:
        """Send stop command to BFTS process."""
        self._send_to_process({"type": "command", "action": "stop"})

    def send_query(self, target: str, **kwargs) -> None:
        """Send query command to BFTS process."""
        self._send_to_process({"type": "command", "action": "query", "target": target, **kwargs})

    @property
    def is_running(self) -> bool:
        return self._running and self._proc is not None and self._proc.poll() is None
