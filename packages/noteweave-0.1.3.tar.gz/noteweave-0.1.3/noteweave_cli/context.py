"""
context.py — Local file reading and context gathering.

The CLI gathers context from the user's workspace and sends it
to the server along with the user's message.
"""
from __future__ import annotations

import os
from pathlib import Path


def read_file(path: str, max_chars: int = 8000) -> str:
    """Read a local file, truncated to max_chars."""
    try:
        full = Path(path).expanduser().resolve()
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(max_chars)
    except OSError:
        return ""


def read_files(paths: list[str], max_chars_each: int = 4000) -> list[dict]:
    """Read multiple files and return as [{path, content}]."""
    results = []
    for p in paths[:6]:  # cap at 6 files
        content = read_file(p, max_chars_each)
        if content:
            results.append({"path": p, "content": content})
    return results


def gather_workspace_context(workspace: str, max_files: int = 10) -> str:
    """Scan workspace for key files and return a summary."""
    ws = Path(workspace)
    if not ws.is_dir():
        return ""

    sections = []

    # Check for common project files
    for name in ["README.md", "requirements.txt", "pyproject.toml", "package.json"]:
        f = ws / name
        if f.is_file():
            content = f.read_text(errors="ignore")[:1000]
            sections.append(f"### {name}\n```\n{content}\n```")

    # List top-level files
    top_files = sorted([f.name for f in ws.iterdir() if f.is_file()])[:20]
    if top_files:
        sections.append(f"### Files\n{', '.join(top_files)}")

    return "\n\n".join(sections)


def find_plots(workspace: str) -> list[str]:
    """Find plot images in workspace."""
    import glob
    plots = []
    for ext in ("*.png", "*.jpg", "*.jpeg", "*.svg"):
        plots.extend(glob.glob(os.path.join(workspace, "**", ext), recursive=True))
    return plots[:20]
