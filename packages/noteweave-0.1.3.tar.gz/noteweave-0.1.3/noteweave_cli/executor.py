"""
executor.py — Local code execution and file writing.

Uses tmux for live terminal when available, falls back to subprocess.
Handles tool calls that the server delegates back to the CLI:
- write_file: write content to local workspace
- run_code/bash: execute shell commands locally
- read_file: read local files to send back to server
"""
from __future__ import annotations

import os
import subprocess

from rich.console import Console

console = Console()

# Global terminal session — initialized by CLI main.py
_terminal = None


def init_terminal(workspace: str) -> None:
    """Initialize tmux terminal session for live command execution."""
    global _terminal
    from noteweave_cli.terminal import TerminalSession
    _terminal = TerminalSession(workspace)
    if _terminal.start():
        console.print("[dim]Terminal session started (tmux). Commands will run in live terminal.[/dim]")
    else:
        console.print("[dim]tmux not available — commands run in background subprocess.[/dim]")


def write_file(path: str, content: str, workspace: str = "") -> bool:
    """Write content to a file in the workspace."""
    try:
        full = os.path.join(workspace, path) if not os.path.isabs(path) else path
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as f:
            f.write(content)
        console.print(f"[dim green]  wrote {path}[/dim green]")
        return True
    except OSError as e:
        console.print(f"[red]  Failed to write {path}: {e}[/red]")
        return False


def run_code(command: str, cwd: str = "", timeout: int = 300) -> dict:
    """Execute a command — uses tmux if available, else subprocess."""
    console.print(f"\n[bold yellow]> {command[:200]}[/bold yellow]")

    # Use tmux terminal if active
    if _terminal and _terminal.is_active():
        result = _terminal.run(command, timeout)
    else:
        # Fallback to subprocess
        try:
            proc = subprocess.run(
                command, shell=True, cwd=cwd or None,
                capture_output=True, text=True, timeout=timeout,
                executable="/bin/bash",
            )
            result = {"stdout": proc.stdout, "stderr": proc.stderr, "exit_code": proc.returncode}
        except subprocess.TimeoutExpired:
            result = {"stdout": "", "stderr": f"Timeout after {timeout}s", "exit_code": -1}
        except Exception as e:
            result = {"stdout": "", "stderr": str(e), "exit_code": -1}

    stdout = result.get("stdout", "")
    stderr = result.get("stderr", "")
    exit_code = result.get("exit_code", -1)

    if stdout:
        console.print(f"[dim]{stdout[:500]}[/dim]")
    if stderr:
        console.print(f"[dim red]{stderr[:300]}[/dim red]")
    console.print(f"[dim]exit: {exit_code}[/dim]")

    return result


def read_file(path: str, workspace: str = "", max_chars: int = 50_000) -> str:
    """Read a file from the workspace."""
    full = os.path.join(workspace, path) if not os.path.isabs(path) else path
    try:
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(max_chars)
    except OSError:
        return ""
