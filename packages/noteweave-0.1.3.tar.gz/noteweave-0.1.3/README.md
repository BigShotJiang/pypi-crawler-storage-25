# NoteWeave CLI

AI research assistant in your terminal. Search papers, analyze findings, and build research plans — all from the command line.

## Install

```bash
pip install noteweave
```

or

```bash
uv pip install noteweave
```

## Usage

```bash
noteweave
```

On first run you'll be prompted to log in. Sign in at [apps.noteweave.io](https://apps.noteweave.io), generate an extension token, and paste it.

Then just type what you want to research. The agent handles the rest.

## Commands

| Command | Description |
|---------|-------------|
| `/explore` | Start a research exploration |
| `/execution` | Run experiments *(coming soon)* |
| `/tools` | Show available agent tools |
| `/voice` | Record and transcribe audio |
| `/files` | List workspace files |
| `/read <path>` | Read a file |
| `/add <path>` | Attach file as context |
| `/help` | Show all commands |

## Links

- Website: [noteweave.io](https://www.noteweave.io)
- Dashboard: [apps.noteweave.io](https://apps.noteweave.io)
- VS Code Extension: [marketplace](https://marketplace.visualstudio.com/items?itemName=noteweave.noteweave)
