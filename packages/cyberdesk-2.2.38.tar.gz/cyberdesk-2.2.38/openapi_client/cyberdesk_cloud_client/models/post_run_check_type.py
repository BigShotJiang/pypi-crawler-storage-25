from enum import Enum


class PostRunCheckType(str, Enum):
    OUTPUT_DATA_AGENTIC_CHECK = "output_data_agentic_check"
    OUTPUT_DATA_PASSES_SCHEMA_VALIDATION = "output_data_passes_schema_validation"
    RUN_ATTACHMENT_EXISTS = "run_attachment_exists"
    RUN_ATTACHMENT_IMAGE_CHECK = "run_attachment_image_check"

    def __str__(self) -> str:
        return str(self.value)
