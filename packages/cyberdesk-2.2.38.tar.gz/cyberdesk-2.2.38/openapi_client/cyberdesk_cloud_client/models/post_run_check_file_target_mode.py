from enum import Enum


class PostRunCheckFileTargetMode(str, Enum):
    EXACT = "exact"
    LOOP_ITEMS = "loop_items"
    REGEX = "regex"

    def __str__(self) -> str:
        return str(self.value)
