from enum import Enum


class PostRunCheckStatus(str, Enum):
    CANCELLED = "cancelled"
    FAILED = "failed"
    INFRA_ERROR = "infra_error"
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"

    def __str__(self) -> str:
        return str(self.value)
