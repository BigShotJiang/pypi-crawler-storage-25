from http import HTTPStatus
from typing import Any
from urllib.parse import quote
from uuid import UUID

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.workflow_response_with_includes import WorkflowResponseWithIncludes
from ...types import UNSET, Response, Unset


def _get_kwargs(
    workflow_id: UUID,
    *,
    include: None | str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_include: None | str | Unset
    if isinstance(include, Unset):
        json_include = UNSET
    else:
        json_include = include
    params["include"] = json_include

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/workflows/{workflow_id}".format(
            workflow_id=quote(str(workflow_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | WorkflowResponseWithIncludes | None:
    if response.status_code == 200:
        response_200 = WorkflowResponseWithIncludes.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | WorkflowResponseWithIncludes]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    workflow_id: UUID,
    *,
    client: AuthenticatedClient,
    include: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | WorkflowResponseWithIncludes]:
    """Get Workflow

     Get a specific workflow by ID.

    The workflow must belong to the authenticated organization.

    Args:
        workflow_id (UUID):
        include (None | str | Unset): Comma-separated list of related resources to include.
            Allowed values: tags, post_run_checks. Defaults to tags and post_run_checks when omitted.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkflowResponseWithIncludes]
    """

    kwargs = _get_kwargs(
        workflow_id=workflow_id,
        include=include,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    workflow_id: UUID,
    *,
    client: AuthenticatedClient,
    include: None | str | Unset = UNSET,
) -> HTTPValidationError | WorkflowResponseWithIncludes | None:
    """Get Workflow

     Get a specific workflow by ID.

    The workflow must belong to the authenticated organization.

    Args:
        workflow_id (UUID):
        include (None | str | Unset): Comma-separated list of related resources to include.
            Allowed values: tags, post_run_checks. Defaults to tags and post_run_checks when omitted.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkflowResponseWithIncludes
    """

    return sync_detailed(
        workflow_id=workflow_id,
        client=client,
        include=include,
    ).parsed


async def asyncio_detailed(
    workflow_id: UUID,
    *,
    client: AuthenticatedClient,
    include: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | WorkflowResponseWithIncludes]:
    """Get Workflow

     Get a specific workflow by ID.

    The workflow must belong to the authenticated organization.

    Args:
        workflow_id (UUID):
        include (None | str | Unset): Comma-separated list of related resources to include.
            Allowed values: tags, post_run_checks. Defaults to tags and post_run_checks when omitted.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | WorkflowResponseWithIncludes]
    """

    kwargs = _get_kwargs(
        workflow_id=workflow_id,
        include=include,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    workflow_id: UUID,
    *,
    client: AuthenticatedClient,
    include: None | str | Unset = UNSET,
) -> HTTPValidationError | WorkflowResponseWithIncludes | None:
    """Get Workflow

     Get a specific workflow by ID.

    The workflow must belong to the authenticated organization.

    Args:
        workflow_id (UUID):
        include (None | str | Unset): Comma-separated list of related resources to include.
            Allowed values: tags, post_run_checks. Defaults to tags and post_run_checks when omitted.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | WorkflowResponseWithIncludes
    """

    return (
        await asyncio_detailed(
            workflow_id=workflow_id,
            client=client,
            include=include,
        )
    ).parsed
