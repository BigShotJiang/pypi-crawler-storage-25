"""
REST 客户端（基于 ``httpx.AsyncClient``）

职责：

- 注入认证 / 身份 / 自定义 header
- 统一解包 ``{code, msg, data, requestId}``，非 0 抛 ``APIError``
- 超时：``asyncio.wait_for`` + ``httpx.TimeoutException``
- 重试：指数退避 + ±20% 抖动；由 ``retry_on(err, ctx)`` 统一决策
- 日志：对齐 Anthropic Python SDK —— 日志行不带自造 ID，只带**服务端
  request_id** 作为定位 ID；"是否在重试 / 第几次重试" 通过独立的
  ``attempt=N/M`` 字段表达，而非自造 log_id/retryOf 链
- 脱敏：``on_request`` / ``on_response`` 钩子 + debug 日志里的 headers 自动脱敏

**取消语义**（Pythonic）：

调用方直接 ``task.cancel()`` 即会传播 ``asyncio.CancelledError`` 到 httpx 层，
httpx 会中止在途请求，异常向上抛出——不需要额外的 signal/token 机制。
``RequestOptions.cancel`` 仅用于"我已经 await 住了但想从外部中止"的场景，
内部通过 ``asyncio.wait`` 监听。
"""

from __future__ import annotations

import asyncio
import json
import random
import time
import uuid
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar

import httpx

from cloud_agent_sdk.errors import (
    AcpProtocolError,
    APIAuthError,
    APIError,
    APINetworkError,
    APINotFoundError,
    APITimeoutError,
    APIValidationError,
)
from cloud_agent_sdk.internal.log import logger_for
from cloud_agent_sdk.internal.redact import redact_body, redact_headers
from cloud_agent_sdk.opts import (
    RequestHookInfo,
    RequestOptions,
    ResponseHookInfo,
    RetryContext,
    RetryOn,
    RetryOptions,
)

if TYPE_CHECKING:
    from cloud_agent_sdk.opts import ConnectionOptions

__all__ = ["RestClient", "default_retry_on"]


T = TypeVar("T")


DEFAULT_BASE_URL = "https://www.codebuddy.cn/v2/agentos"
DEFAULT_TIMEOUT_MS = 30_000
_MAX_BACKOFF_MS = 30_000


# ─── default_retry_on ────────────────────────────────


def default_retry_on(err: BaseException, ctx: RetryContext) -> bool:
    """SDK 内置的默认重试判定。

    传 ``retry=RetryOptions(retry_on=...)`` 会**完全替换**这里的规则（不叠加）。

    公开此函数以便用户在自定义 ``retry_on`` 中回落到默认::

        def my_retry_on(err, ctx):
            if isinstance(err, APITimeoutError) and "/upload" in ctx.url:
                return False
            return default_retry_on(err, ctx)
    """
    # 用户主动取消
    if isinstance(err, asyncio.CancelledError | KeyboardInterrupt):
        return False

    # SDK 业务错误：按类型决定
    if isinstance(err, APIAuthError | APINotFoundError | APIValidationError | AcpProtocolError):
        return False

    # 超时：仅幂等方法（GET）重试
    if isinstance(err, APITimeoutError):
        return ctx.method == "GET"

    # 网络错误：所有方法都可重试
    if isinstance(err, APINetworkError):
        return True

    # 其他未知错误：保守重试
    return True


_DEFAULT_RETRY = RetryOptions()


# ─── 内部请求上下文 ────────────────────────────────


class _RequestCtx:
    """跨 ``_do_request`` / ``_with_retry`` 复用的上下文。

    只跟踪 attempt 编号：首次=1，每次重试 +1。日志里用它区分"第几次"。
    """

    __slots__ = ("attempt", "start_time")

    def __init__(self) -> None:
        self.attempt: int = 1
        self.start_time: float = 0.0


# ─── RestClient ────────────────────────────────


class RestClient:
    """SDK 的 REST 客户端。仅由 ``CloudAgentClient`` / ``Runtime`` / ``Session`` 使用。"""

    def __init__(self, opts: ConnectionOptions) -> None:
        self._opts = opts
        self._logger = logger_for(opts)
        # 是否由 SDK 自己创建了 http client（需要在 aclose 时释放）
        self._owned_http = opts.http_client is None
        self._http = opts.http_client if opts.http_client is not None else httpx.AsyncClient()

    async def aclose(self) -> None:
        """关闭 SDK 持有的 httpx client。外部注入的 client 不会被关闭。"""
        if self._owned_http:
            await self._http.aclose()

    # ─── 公共方法 ────────────────────────────────

    async def get(
        self,
        path: str,
        query: Mapping[str, str] | None = None,
        opts: RequestOptions | None = None,
    ) -> Any:
        return await self._request("GET", path, query=query, body=None, opts=opts)

    async def post(
        self,
        path: str,
        body: Any = None,
        opts: RequestOptions | None = None,
    ) -> Any:
        return await self._request("POST", path, query=None, body=body, opts=opts)

    async def patch(
        self,
        path: str,
        body: Any = None,
        opts: RequestOptions | None = None,
    ) -> Any:
        return await self._request("PATCH", path, query=None, body=body, opts=opts)

    async def delete(
        self,
        path: str,
        opts: RequestOptions | None = None,
    ) -> Any:
        return await self._request("DELETE", path, query=None, body=None, opts=opts)

    # ─── 内部实现 ────────────────────────────────

    def _build_url(self, path: str, query: Mapping[str, str] | None = None) -> str:
        base = (self._opts.base_url or DEFAULT_BASE_URL).rstrip("/")
        full_path = path if path.startswith("/") else f"/{path}"
        url = f"{base}{full_path}"
        if query:
            filtered = {k: v for k, v in query.items() if v is not None and v != ""}
            if filtered:
                qp = httpx.QueryParams(filtered)
                return f"{url}?{qp}"
        return url

    def _build_headers(self, opts: RequestOptions | None) -> dict[str, str]:
        """构建请求 headers（含认证、身份、trace、自定义）。"""
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

        # pt_ 前缀的幻影令牌必须通过 Authorization: Bearer 传递（网关 phantom-token 插件仅从该 header 提取）
        # ck_ 等其他前缀继续使用 x-api-key header
        if self._opts.api_key:
            if self._opts.api_key.startswith("pt_"):
                headers["Authorization"] = f"Bearer {self._opts.api_key}"
            else:
                headers["X-Api-Key"] = self._opts.api_key

        if self._opts.source_app:
            headers["X-Source-App"] = self._opts.source_app
        if self._opts.source_tenant_id:
            headers["X-Source-Tenant-Id"] = self._opts.source_tenant_id
        if self._opts.user_id:
            headers["X-User-Id"] = self._opts.user_id

        if self._opts.headers:
            headers.update(self._opts.headers)

        if opts is not None and opts.headers:
            headers.update(opts.headers)

        headers["X-Request-Id"] = (
            opts.request_id if opts is not None and opts.request_id else str(uuid.uuid4())
        )

        return headers

    async def _request(
        self,
        method: str,
        path: str,
        *,
        query: Mapping[str, str] | None,
        body: Any,
        opts: RequestOptions | None,
    ) -> Any:
        """发起请求（含超时 + 重试 + 日志 + 脱敏 + hooks）。"""
        url = self._build_url(path, query)

        # 确定重试策略。优先级：per-request > 全局 > DEFAULT。传 False 关闭重试。
        shouldretry: RetryOptions | Literal[False]
        if opts is not None and opts.retry is not None:
            shouldretry = opts.retry
        elif self._opts.retry is not None:
            shouldretry = self._opts.retry
        else:
            shouldretry = _DEFAULT_RETRY

        ctx = _RequestCtx()

        async def do_request() -> Any:
            return await self._do_single_request(method, url, body, opts, ctx)

        if shouldretry is False:
            return await do_request()

        return await self._with_retry(do_request, shouldretry, ctx, method, url)

    async def _do_single_request(
        self,
        method: str,
        url: str,
        body: Any,
        opts: RequestOptions | None,
        ctx: _RequestCtx,
    ) -> Any:
        """单次请求（不含重试）。抛 ``APIError`` 或 ``asyncio.CancelledError``。"""
        ctx.start_time = time.monotonic()
        timeout_ms = (
            opts.timeout_ms
            if opts is not None and opts.timeout_ms is not None
            else self._opts.timeout_ms or DEFAULT_TIMEOUT_MS
        )
        headers = self._build_headers(opts)
        request_id = headers["X-Request-Id"]

        redacted_req_headers = redact_headers(headers)

        if self._opts.on_request is not None:
            try:
                self._opts.on_request(
                    RequestHookInfo(method=method, url=url, headers=dict(redacted_req_headers))
                )
            except Exception:
                # hook 异常不影响主流程
                pass

        # 对齐 Anthropic SDK：debug 行两段 —— 发出 + 响应。
        # 首次请求不带 attempt 前缀（减噪音）；重试时用独立日志行在 _with_retry 里提示。
        self._logger.debug(
            "Sending HTTP Request: %s %s | headers=%s body=%s",
            method,
            url,
            redacted_req_headers,
            _truncate(redact_body(body)) if body is not None else None,
        )

        # 构造请求 coroutine
        timeout_s = timeout_ms / 1000.0 if timeout_ms > 0 else None
        content = (
            json.dumps(body, default=_json_default).encode("utf-8") if body is not None else None
        )
        request_coro = self._http.request(method, url, headers=headers, content=content)

        # 把 opts.cancel event 也当作中止条件（如果设置了）
        cancel_event = opts.cancel if opts is not None else None

        try:
            response = await _await_with_cancel(request_coro, timeout_s, cancel_event)
        except asyncio.CancelledError:
            self._logger.debug(
                "Request cancelled after %dms: %s %s",
                int((time.monotonic() - ctx.start_time) * 1000),
                method,
                url,
            )
            raise
        except asyncio.TimeoutError as e:
            msg = f"Request timed out after {timeout_ms}ms: {method} {url}"
            self._logger.debug("%s", msg)
            raise APITimeoutError(msg, cause=e) from e
        except httpx.TimeoutException as e:
            msg = f"Request timed out after {timeout_ms}ms: {method} {url}"
            self._logger.debug("%s", msg)
            raise APITimeoutError(msg, cause=e) from e
        except httpx.HTTPError as e:
            msg = f"Network error: {method} {url} - {e}"
            self._logger.debug("%s", msg)
            raise APINetworkError(msg, cause=e) from e

        duration_ms = int((time.monotonic() - ctx.start_time) * 1000)

        response_headers = dict(response.headers)
        redacted_res_headers = redact_headers(response_headers)

        if self._opts.on_response is not None:
            try:
                self._opts.on_response(
                    ResponseHookInfo(
                        status=response.status_code,
                        url=url,
                        headers=dict(redacted_res_headers),
                    )
                )
            except Exception:
                pass

        server_req_id = response.headers.get("x-request-id") or request_id
        # 对齐 Anthropic：两条 debug
        #   HTTP Response: POST <url> "201 Created" durationMs=...
        #   request_id: <serverReqId>
        self._logger.debug(
            'HTTP Response: %s %s "%d %s" durationMs=%d headers=%s',
            method,
            url,
            response.status_code,
            response.reason_phrase,
            duration_ms,
            redacted_res_headers,
        )
        if server_req_id:
            self._logger.debug("request_id: %s", server_req_id)

        return self._unwrap(response, server_req_id)

    # ─── 解包 ────────────────────────────────

    def _unwrap(self, response: httpx.Response, server_req_id: str | None) -> Any:
        """解包 ``{code, msg, data, requestId}`` → ``data`` 或抛错。"""
        if response.status_code == 204:
            return None

        raw_text = response.text
        try:
            body = json.loads(raw_text)
        except (ValueError, json.JSONDecodeError):
            # 非 JSON 响应
            if not response.is_success:
                raise self._http_status_to_error(
                    response.status_code,
                    f"HTTP {response.status_code}",
                    request_id=server_req_id,
                ) from None
            return raw_text

        if not isinstance(body, dict):
            if not response.is_success:
                raise self._http_status_to_error(
                    response.status_code,
                    f"HTTP {response.status_code}",
                    request_id=server_req_id,
                )
            return body

        # 服务端 requestId 两个来源（详见 Node 版注释）：
        # - body.requestId：middleware 写入，业务层值
        # - response header X-Request-Id：RequestIDMiddleware 直接回显
        # 正常路径下两者一致。优先 body 是因为 body 是服务端"明确意图"返回的字段。
        effective_request_id: str | None = body.get("requestId") or server_req_id

        if not response.is_success:
            raise self._http_status_to_error(
                response.status_code,
                body.get("msg") or f"HTTP {response.status_code}",
                request_id=effective_request_id,
                code=body.get("code"),
            )

        code = body.get("code")
        if code != 0:
            raise self._code_to_error(
                code if isinstance(code, int) else -1,
                body.get("msg") or "business error",
                request_id=effective_request_id,
                http_status=response.status_code,
            )

        return body.get("data")

    # ─── 错误映射 ────────────────────────────────

    def _http_status_to_error(
        self,
        status: int,
        message: str,
        *,
        request_id: str | None,
        code: int | None = None,
    ) -> APIError:
        kwargs: dict[str, Any] = {
            "http_status": status,
            "request_id": request_id,
        }
        if code is not None:
            kwargs["code"] = code

        if status == 400:
            return APIValidationError(message, **kwargs)
        if status in (401, 403):
            return APIAuthError(message, **kwargs)
        if status == 404:
            return APINotFoundError(message, **kwargs)
        if status in (408, 504):
            return APITimeoutError(message, **kwargs)
        if status == 429:
            return APINetworkError(message, **kwargs)
        if status >= 500:
            return APINetworkError(message, **kwargs)
        return APIError(message, **kwargs)

    def _code_to_error(
        self,
        code: int,
        message: str,
        *,
        request_id: str | None,
        http_status: int | None,
    ) -> APIError:
        kwargs: dict[str, Any] = {
            "code": code,
            "http_status": http_status,
            "request_id": request_id,
        }

        if code == 10001:
            return APIValidationError(message, **kwargs)
        if code in (10034, 10085):
            return APIAuthError(message, **kwargs)
        if code in (10064, 10065, 10067, 10000):
            return APINetworkError(message, **kwargs)
        if code == 10084:
            return APINotFoundError(message, **kwargs)
        if code == 10094:
            return APITimeoutError(message, **kwargs)
        return APIError(message, **kwargs)

    # ─── 重试 ────────────────────────────────

    async def _with_retry(
        self,
        fn: Any,
        retry_opts: RetryOptions,
        req_ctx: _RequestCtx,
        method: str,
        url: str,
    ) -> Any:
        """重试循环。``retry_on`` 完全替换 SDK 默认判定（不叠加）。"""
        max_attempts = retry_opts.max_attempts
        backoff_ms = retry_opts.backoff_ms
        backoff_factor = retry_opts.backoff_factor
        jitter = retry_opts.jitter
        retry_on: RetryOn = retry_opts.retry_on or default_retry_on

        last_error: BaseException | None = None

        for attempt in range(1, max_attempts + 1):
            req_ctx.attempt = attempt
            try:
                return await fn()
            except asyncio.CancelledError:
                raise
            except BaseException as err:
                last_error = err

                if not retry_on(err, RetryContext(attempt=attempt, method=method, url=url)):
                    raise

                if attempt >= max_attempts:
                    break

                delay_ms = _backoff_ms(attempt, backoff_ms, backoff_factor, jitter)
                # 对齐 Anthropic："Retrying request to ... in N seconds"
                self._logger.warning(
                    "Retrying request to %s %s in %dms (attempt %d/%d): %s: %s",
                    method,
                    url,
                    delay_ms,
                    attempt,
                    max_attempts,
                    type(err).__name__,
                    err,
                )
                await asyncio.sleep(delay_ms / 1000.0)

        assert last_error is not None
        raise last_error


# ─── 工具函数 ────────────────────────────────


async def _await_with_cancel(
    coro: Any,
    timeout_s: float | None,
    cancel_event: asyncio.Event | None,
) -> Any:
    """执行 coroutine，同时监听超时和 cancel event。

    - 无 timeout、无 cancel_event：直接 await
    - 有 timeout、无 cancel_event：``asyncio.wait_for``
    - 有 cancel_event：用 ``asyncio.wait`` 监听两个 future

    抛 ``asyncio.TimeoutError`` / ``asyncio.CancelledError`` / coro 自身的异常。
    """
    if cancel_event is None:
        if timeout_s is None:
            return await coro
        return await asyncio.wait_for(coro, timeout=timeout_s)

    # 有 cancel_event：创建 task，同时等待 cancel
    task = asyncio.ensure_future(coro)
    cancel_task = asyncio.ensure_future(cancel_event.wait())

    try:
        done, _ = await asyncio.wait(
            {task, cancel_task},
            timeout=timeout_s,
            return_when=asyncio.FIRST_COMPLETED,
        )
    finally:
        cancel_task.cancel()

    if not done:
        task.cancel()
        raise asyncio.TimeoutError()

    if cancel_task in done and task not in done:
        task.cancel()
        raise asyncio.CancelledError()

    # task 完成，拿结果或抛异常
    return task.result()


def _backoff_ms(attempt: int, base_ms: int, factor: float, jitter: bool) -> int:
    """计算退避时间（含抖动），最大 30s。"""
    base = min(base_ms * (factor ** (attempt - 1)), _MAX_BACKOFF_MS)
    if not jitter:
        return round(base)
    # ±20% 抖动
    return round(base * (1 + 0.2 * (random.random() * 2 - 1)))


def _truncate(value: Any, max_chars: int = 500) -> str:
    """截断超长 body 用于 debug 日志。"""
    try:
        s = value if isinstance(value, str) else json.dumps(value, default=_json_default)
    except Exception:
        return "[unserializable]"
    if len(s) <= max_chars:
        return s
    return f"{s[:max_chars]}…(truncated, total {len(s)} chars)"


def _json_default(obj: Any) -> Any:
    """兼容 Pydantic 模型 / dataclass 的 JSON 序列化。"""
    if hasattr(obj, "model_dump"):
        return obj.model_dump(by_alias=True, exclude_none=True)
    if hasattr(obj, "__dataclass_fields__"):
        from dataclasses import asdict

        return asdict(obj)
    return obj
