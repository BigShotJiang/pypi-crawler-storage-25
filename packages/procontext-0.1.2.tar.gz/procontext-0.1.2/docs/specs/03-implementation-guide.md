# ProContext: Implementation Guide

> **Document**: 03-implementation-guide.md
> **Status**: Draft v3
> **Last Updated**: 2026-03-20
> **Depends on**: 01-functional-spec.md, 02-technical-spec.md

---

## Table of Contents

- [1. Project Structure](#1-project-structure)
  - [1.1 Source Layout](#11-source-layout)
  - [1.2 Module Responsibilities](#12-module-responsibilities)
- [2. Dependencies](#2-dependencies)
- [3. Coding Conventions](#3-coding-conventions)
  - [3.1 General Rules](#31-general-rules)
  - [3.2 Protocol Interfaces](#32-protocol-interfaces)
  - [3.3 AppState and Dependency Injection](#33-appstate-and-dependency-injection)
  - [3.4 Error Handling](#34-error-handling)
  - [3.5 Logging](#35-logging)
- [4. Module Acceptance Criteria](#4-module-acceptance-criteria)
  - [4.1 Resolver](#41-resolver)
  - [4.2 Fetcher & Cache](#42-fetcher--cache)
  - [4.3 Parser](#43-parser)
  - [4.4 Search](#44-search)
  - [4.5 HTTP Transport](#45-http-transport)
  - [4.6 Registry Updates](#46-registry-updates)
  - [4.7 Outline](#47-outline)
- [5. Testing Strategy](#5-testing-strategy)
- [6. CI/CD](#6-cicd)
  - [Commit Message Convention](#commit-message-convention)
  - [ci.yml — Test Pipeline](#ciyml--test-pipeline)
  - [release.yml — Release Pipeline](#releaseyml--release-pipeline)
- [7. Local Development Setup](#7-local-development-setup)

---

## 1. Project Structure

### 1.1 Source Layout

The repository layout should be read as a pattern, not a frozen snapshot. Exact filenames may move as a domain grows from a single module into a package, but the responsibilities below should remain stable.

```text
procontext/
├── pyproject.toml
├── README.md
├── procontext.example.yaml
├── docs/
│   ├── specs/                        # Functional, technical, security, and API contracts
│   └── cli/                          # CLI-facing operator and maintainer docs
├── src/procontext/
│   ├── __init__.py
│   ├── py.typed
│   ├── cli/
│   │   ├── main.py                   # argparse dispatcher
│   │   ├── cmd_*.py                  # top-level CLI workflows
│   │   └── <command packages>/       # helpers when a command outgrows one file
│   ├── mcp/
│   │   ├── server.py                 # FastMCP instance and tool registrations
│   │   ├── lifespan.py               # resource creation/teardown, stdout guard
│   │   └── startup.py                # legacy shim to the CLI entrypoint
│   ├── models/                       # Pydantic models shared across layers
│   ├── tools/                        # one module per MCP tool + shared helpers
│   ├── registry/                     # local loading, persistence, and update flow
│   ├── page/                         # page retrieval/orchestration services
│   ├── <service modules>.py          # resolver, fetcher, cache, parser, outline, search, etc.
│   └── <support modules>.py          # config, state, protocols, errors, logging, normalization, identity
├── tests/
│   ├── unit/                         # internal algorithm and module tests
│   └── integration/                  # tool, transport, startup, and CLI contract tests
└── .github/workflows/
```

**Structural rule**: keep the top-level package shallow until a domain clearly needs its own namespace. For example, the registry flow and doctor helpers now live in dedicated packages (`registry/`, `cli/doctor/`), while smaller cross-cutting concerns still remain as flat modules (`normalization.py`, `identity.py`, `errors.py`).

### 1.2 Module Responsibilities

The structure enforces a strict layering. Violations (e.g., a tool importing from `cache.py` directly) indicate a missing abstraction.

| Layer              | Modules                                                                 | Rule                                                                                   |
| ------------------ | ----------------------------------------------------------------------- | -------------------------------------------------------------------------------------- |
| **Entrypoint**     | `cli/main.py`, `cli/cmd_*.py`, `cli/<command packages>/`, `mcp/*.py`   | CLI dispatch, command workflows, server bootstrap, tool registration, and lifecycle. No domain logic beyond orchestration. |
| **Tools**          | `tools/*.py`                                                            | One module per MCP tool. Receives `AppState`, returns output dicts, raises `ProContextError`. |
| **Services**       | `page/`, `resolver.py`, `fetcher.py`, `cache.py`, `parser.py`, `outline.py`, `search.py` | Pure business logic. No MCP imports. Typed against protocols or plain values, not concrete runtime state. |
| **Infrastructure** | `registry/`, `config.py`, `http_transport.py`, `schedulers.py`, `logging_config.py` | Setup, persistence, security middleware, scheduling, and runtime wiring.               |
| **Shared**         | `models/`, `errors.py`, `protocols.py`, `state.py`, `normalization.py`, `identity.py` | Low-level types and utilities that can be imported widely without pulling in transport-specific code. |

**Adding a new tool**: Create `tools/new_tool.py`, register it in `mcp/server.py`. No other files change.

**Swapping the cache backend**: Provide a new class implementing `CacheProtocol`, inject it into `AppState`. No tool code changes.

---

## 2. Dependencies

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/procontext"]

[project]
name = "procontext"
version = "0.1.0"
description = "MCP server for accurate, up-to-date library documentation"
readme = "README.md"
requires-python = ">=3.12"
license = { text = "MIT" }

dependencies = [
    "mcp>=1.26.0,<2.0.0",                   # FastMCP — official MCP Python SDK
    "httpx>=0.28.0,<1.0.0",                  # Async HTTP client
    "aiosqlite>=0.19.0,<1.0.0",              # Async SQLite
    "anyio>=4.0.0,<5.0.0",                  # Structured concurrency
    "pydantic>=2.5.0,<3.0.0",               # Data validation
    "pydantic-settings>=2.2.0,<3.0.0",      # YAML config + env var overrides
    "pyjwt>=2.12.0",                        # Declared runtime dependency in pyproject.toml
    "pyyaml>=6.0.1,<7.0.0",                 # YAML parser (required by pydantic-settings)
    "rapidfuzz>=3.6.0,<4.0.0",              # Levenshtein fuzzy matching
    "platformdirs>=4.0.0,<5.0.0",           # Platform-aware config/data directories
    "structlog>=24.1.0,<26.0.0",            # Structured logging
    "uvicorn>=0.34.0,<1.0.0",               # ASGI server for HTTP transport
]

[project.scripts]
procontext = "procontext.cli.main:main"

[dependency-groups]
dev = [
    "pytest>=8.0.0",
    "pytest-asyncio>=1.0.0",
    "pytest-mock>=3.12.0",
    "pytest-cov>=7.0.0",                        # Coverage measurement and enforcement
    "respx>=0.21.0",                            # httpx request mocking
    "ruff>=0.11.0",
    "pyright>=1.1.400",                         # Type checking (also run in CI)
    "pip-audit>=2.7.0,<3.0.0",                 # Dependency vulnerability scanning
    "python-semantic-release>=9.0.0,<10.0.0",  # Changelog generation + PyPI publishing
]

[tool.pytest.ini_options]
asyncio_mode = "auto"          # All async test functions run without explicit decorator
testpaths = ["tests"]          # Explicit — avoids discovery surprises when run from subdirs

[tool.ruff]
target-version = "py312"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B", "SIM", "TCH", "T20"]

[tool.ruff.lint.flake8-type-checking]
runtime-evaluated-base-classes = ["pydantic.BaseModel", "pydantic_settings.BaseSettings"]

[tool.pyright]
pythonVersion = "3.12"
typeCheckingMode = "standard"
include = ["src"]
```

**`[build-system]`**: Required to build a wheel with `pip wheel .` or `uvx`. Without it, the package cannot be packaged or distributed. `hatchling` is the default backend for projects created with `uv init`.

**`py.typed`**: An empty file at `src/procontext/py.typed`. Its presence tells pyright and mypy that this package ships type annotations and they should be honoured. Without it, type checkers silently ignore the package's types when it is imported.

**`pyright` in dev extras**: Keeps the type checker version pinned and consistent between local dev and CI.

**`testpaths`**: Prevents pytest from discovering tests in unexpected locations (e.g., inside `src/`) when run from the project root.

**Version pinning**: Minor version upper bounds (`<2.0.0`) on all dependencies. Tighten to patch bounds only if a dependency has a documented history of breaking minor releases.

**Version floors**: Since this is a new project with no legacy consumers, version floors should track reasonably close to the latest stable release at the time of writing. There is no reason to support old versions that nobody is using yet. Review and bump floors at the start of each implementation phase — stale floors accumulate silently and can mask behavioural differences between the version you test against and the version the floor permits.

**Dependency footprint**: ProContext keeps a deliberately small runtime dependency set (currently 12 packages in `pyproject.toml`). Each is justified by a capability that would require significantly more code to replicate correctly (async HTTP with SSRF-safe redirect control, async SQLite, fuzzy string matching, structured logging, validated settings). Zero-dependency is a virtue but not at the cost of correctness or maintainability. Before adding any new runtime dependency, verify that the same capability cannot be covered by an existing dependency or the Python standard library.

**License compatibility**: All runtime dependencies use permissive licenses compatible with MIT. Verified at last review (2026-02-24):

| Package             | License           | Notes                                            |
| ------------------- | ----------------- | ------------------------------------------------ |
| `mcp`               | MIT               | Official MCP Python SDK by Anthropic             |
| `httpx`             | BSD-3-Clause      |                                                  |
| `aiosqlite`         | MIT               |                                                  |
| `anyio`             | MIT               | Structured concurrency (used by MCP SDK and tests) |
| `pydantic`          | MIT               |                                                  |
| `pydantic-settings` | MIT               |                                                  |
| `pyjwt`             | MIT               | Declared runtime dependency in the current `pyproject.toml` |
| `pyyaml`            | MIT               |                                                  |
| `rapidfuzz`         | MIT               |                                                  |
| `platformdirs`      | MIT               | Platform-aware config/data directories           |
| `structlog`         | MIT OR Apache-2.0 | Dual-licensed; both permissive                   |
| `uvicorn`           | BSD-3-Clause      |                                                  |

Re-verify this table whenever a dependency is added or its major version is bumped. MIT, BSD-3-Clause, and Apache-2.0 are all permissive licenses with no copyleft obligations.

---

## 3. Coding Conventions

### 3.1 General Rules

**Async throughout.** Every I/O operation (SQLite, HTTP) is async. Tool handlers are `async def`. The only synchronous code is in-memory computation (index lookups, string normalisation, heading parsing).

**Type hints on every function signature.** Return types included. Use `X | None` union syntax (Python 3.10+), not `Optional[X]`.

```python
# Correct
async def get_page(self, url_hash: str) -> PageCacheEntry | None: ...

# Incorrect
async def get_page(self, url_hash: str) -> Optional[PageCacheEntry]: ...
```

**Pydantic at all external boundaries.** Tool inputs are validated via Pydantic models before any processing. Registry JSON is parsed into `RegistryEntry` models on load. Never pass raw dicts between modules — use typed models.

**Platform-aware data paths.** All filesystem defaults use `platformdirs` — never hardcode Unix paths like `~/.local/share/`. Registry files are resolved via `Settings.data_dir` (default `platformdirs.user_data_dir("procontext")`). Cache uses `Settings.cache.db_path` (default `platformdirs.user_data_dir("procontext")/cache.db`), and remains independently configurable.

### 3.2 Protocol Interfaces

Swappable components (`Cache`, `Fetcher`) are typed against `typing.Protocol` interfaces defined in `protocols.py`. Tool handlers and `AppState` reference the protocol, not the concrete class. This has two benefits:

1. **Tests** can use lightweight in-memory implementations without instantiating SQLite or real HTTP clients.
2. **Future backends** (Redis cache, enterprise auth-aware fetcher) can be swapped by injecting a different implementation — no tool code changes.

```python
# protocols.py
from typing import Protocol
from procontext.models import PageCacheEntry

class CacheProtocol(Protocol):
    async def get_page(self, url_hash: str) -> PageCacheEntry | None: ...
    async def set_page(
        self,
        url: str,
        url_hash: str,
        content: str,
        outline: str,
        ttl_hours: int,
        *,
        discovered_domains: frozenset[str] = frozenset(),
    ) -> None: ...
    async def load_discovered_domains(self) -> frozenset[str]: ...
    async def cleanup_if_due(self, interval_hours: int) -> None: ...
    async def cleanup_expired(self) -> None: ...

class FetcherProtocol(Protocol):
    async def fetch(self, url: str, allowlist: frozenset[str]) -> str: ...
```

The concrete `Cache` (SQLite) and `Fetcher` (httpx) classes implement these protocols implicitly — no `class Cache(CacheProtocol)` inheritance needed. Python's structural subtyping handles it.

### 3.3 AppState and Dependency Injection

All shared state lives in `AppState` (`state.py`), instantiated once at startup and injected into every tool call. This makes tests straightforward — pass a test `AppState` with mock implementations.

```python
# state.py
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING
import httpx

if TYPE_CHECKING:
    from procontext.config import Settings
    from procontext.models.registry import RegistryIndexes
    from procontext.protocols import CacheProtocol, FetcherProtocol

@dataclass
class AppState:
    # Core
    settings: Settings

    # Registry & Resolution
    indexes: RegistryIndexes
    registry_version: str = ""
    registry_path: Path | None = None           # Path to known-libraries.json on disk
    registry_state_path: Path | None = None     # Path to registry-state.json on disk

    # Fetcher & Cache
    http_client: httpx.AsyncClient | None = None
    cache: CacheProtocol | None = None          # Typed as protocol, not concrete Cache
    fetcher: FetcherProtocol | None = None      # Typed as protocol, not concrete Fetcher
    allowlist: frozenset[str] = field(default_factory=frozenset)
```

`AppState` is passed into the server via FastMCP's lifespan context and flows into tool handlers through the MCP `Context` object:

```python
# mcp/lifespan.py + mcp/server.py
from contextlib import asynccontextmanager
from mcp.server.fastmcp import FastMCP, Context

@asynccontextmanager
async def lifespan(server: FastMCP):
    state = await _create_app_state()
    yield state                    # Available as ctx.request_context.lifespan_context
    await state.http_client.aclose()

mcp = FastMCP("procontext", lifespan=lifespan)

@mcp.tool()
async def resolve_library(query: str, ctx: Context) -> dict:
    state: AppState = ctx.request_context.lifespan_context
    return await tools.resolve_library.handle(query, state)
```

Tool modules receive `AppState` as a plain argument. They have no knowledge of FastMCP or the MCP protocol.

```python
# tools/resolve_library.py
async def handle(query: str, state: AppState) -> dict:
    ...
```

### 3.4 Error Handling

**Raise `ProContextError`, never return error dicts.** Tool handlers raise `ProContextError`. `mcp/server.py` catches it and serialises it into the MCP error response. Business logic modules never return `{"error": ...}` dicts.

```python
# Correct
if response.status_code == 404:
    raise ProContextError(
        code=ErrorCode.PAGE_NOT_FOUND,
        message=f"Page not found: {url}",
        suggestion="Check the URL is correct. Use resolve_library to find valid documentation URLs.",
        recoverable=False,
    )

# Incorrect
if response.status_code == 404:
    return {"error": {"code": "PAGE_NOT_FOUND", ...}}
```

### 3.5 Logging

**Bind log context at the start of each handler.** Use `structlog.get_logger().bind(...)` to attach the tool name and key inputs to every log line in a handler, without passing a logger argument through every function call.

```python
# tools/search_page.py
import structlog

async def handle(url: str, query: str, state: AppState) -> dict:
    url_hash = sha256_hex(url)
    log = structlog.get_logger().bind(tool="search_page", url_hash=url_hash)
    log.info("handler_called")
    ...
    log.info("cache_hit")
    ...
```

**Log at decision points, not at every line.** The goal is to be able to reconstruct what happened from the logs without drowning in noise. A good rule of thumb: log wherever the code makes a branching decision that would matter when debugging a production issue.

Mandatory log points:

- Server startup and shutdown (transport mode, registry version, entry count)
- Every tool call entry (tool name + key input — already provided by the bound context)
- Cache outcome: hit, stale hit, or miss (one line each; avoid logging on every cache read)
- Network fetch start and completion (URL, status code, response size)
- Any `ProContextError` raised — log before raising with `WARNING` level and the error code
- Background task outcomes: registry update (new version or already current), cache cleanup (rows deleted)

Do not log:

- Inside tight loops (heading parsing, index building) — these are in-memory and fast
- Successful intermediate steps with no branching significance (e.g., "entering normalise_query", "regex matched")
- Redundant context already captured by the bound logger

**Exceptions must include `exc_info=True`.** Any `except` block that logs and continues (e.g., background tasks that swallow errors to stay alive) must pass `exc_info=True` so the full traceback is captured.

```python
# Correct — full traceback in the log
except Exception:
    log.warning("stale_refresh_failed", url=url, exc_info=True)

# Incorrect — traceback is lost
except Exception as e:
    log.warning("stale_refresh_failed", url=url, error=str(e))
```

`ProContextError` raised in tool handlers does not need `exc_info=True` — these are expected, handled errors. Reserve `exc_info=True` for unexpected exceptions that are caught and suppressed.

---

## 4. Module Acceptance Criteria

Each subsection defines the expected behaviours for a module. These serve as the verification checklist for code review and testing — a module is complete when every listed behaviour has a passing test.

---

### 4.1 Resolver

**Modules**: `resolver.py`, `registry/`, `tools/resolve_library.py`

**Expected behaviours**:

- `"langchain-openai"` → resolves via package name to `"langchain"`
- `"langchain[openai]>=0.3"` → returns empty matches with `UNSUPPORTED_QUERY_SYNTAX`
- `"LangChain"` → lowercase normalised, resolves via ID
- `"langchan"` → fuzzy match to `"langchain"` with relevance < 1.0
- `"xyzzy-nonexistent"` → empty matches list, no error

---

### 4.2 Fetcher & Cache

**Modules**: `fetcher.py`, `cache.py`, `page/service.py`, `tools/read_page.py`

**Expected behaviours**:

- First call fetches from network, stores in cache, returns content
- Second call returns from cache, no network request made
- Stale entry (TTL expired) returns stale content immediately with `stale: true` and spawns a background refresh
- After the background refresh completes, a subsequent call returns fresh content with `stale: false`
- Concurrent calls to the same stale URL do not spawn duplicate refresh tasks, and recently checked stale entries respect the cooldown window
- Cache read failure (`aiosqlite.Error`): treated as cache miss, falls back to network fetch, returns content with `cached: false`
- Cache write failure (`aiosqlite.Error`): fetched content still returned normally, error logged
- SSRF: private IP URL raises `URL_NOT_ALLOWED`
- SSRF: redirect to another public domain is followed after the initial allowlisted URL passes validation
- SSRF: redirect to private IP still raises `URL_NOT_ALLOWED`
- Page is cached on first fetch; subsequent calls with different offsets are served from cache without re-fetch
- `content_hash` is stable while content is unchanged and changes when the underlying cached content changes
- `offset`, `limit`, and optional `before` correctly window the content
- `outline` returned by `read_page` is compacted to ≤ 50 entries; if irreducible, replaced by a status message directing the agent to `read_outline`

---

### 4.3 Parser

**Module**: `parser.py`

**Expected behaviours**:

- H1–H6 headings detected with correct 1-based line numbers
- ATX headings accept a space, tab, or end-of-line after the hash marker (`# Title`, `#\tTitle`, and `##` all parse)
- Plain setext headings are detected outside fenced code blocks and normalized to synthetic `#` / `##` entries at the title line number
- Blockquote headings (`> ## Section`) are captured
- Fence opener/closer lines are emitted so the agent knows where code blocks start/end
- Fence closers must match the opener character/length and may only have trailing spaces or tabs; lines like ````python` inside a fenced block remain content
- Headings inside code blocks are captured as-is (agent infers context from surrounding fence lines)
- 4-space indented lines are not treated as fence openers
- 4-space indented heading-like lines outside fences are ignored as structural headings

---

### 4.4 Search

**Modules**: `search.py`, `tools/search_page.py`

**Expected behaviours**:

- Literal search returns correct matching lines with 1-based line numbers
- Regex search compiles and matches; invalid regex raises `INVALID_INPUT`
- Smart case: all-lowercase query → case-insensitive; mixed/upper → case-sensitive
- `whole_word: true` wraps pattern in `\b...\b`
- Pagination: `offset` skips lines, `max_results` limits output, `has_more`/`next_offset` enable continuation
- Zero matches → empty outline string
- Small outlines (≤50 entries after empty-fence stripping) are returned unchanged so parent headings are preserved
- Oversized outlines are trimmed to the match range (first match line → last match line) before compaction
- Outline compaction uses the same progressive reduction as `read_page` (≤ 50 entries target)
- Page fetch uses the dedicated page service (`fetch_or_cached_page`) (same cache as `read_page`)

---

### 4.5 HTTP Transport

**Modules**: `http_transport.py`, `mcp/startup.py`

**Expected behaviours**:

- `auth_enabled=true` + explicit `auth_key` + valid bearer key → 200
- `auth_enabled=true` + explicit `auth_key` + missing `Authorization` header → 401
- `auth_enabled=true` + explicit `auth_key` + incorrect bearer key → 401
- `auth_enabled=true` + empty `auth_key` → key auto-generated at startup and logged
- `auth_enabled=false` → auth disabled; requests without `Authorization` can proceed
- `auth_enabled=false` → startup warning is logged
- POST to `/mcp` with valid origin → 200
- POST to `/mcp` with non-loopback origin → 403
- POST to `/mcp` with unknown `MCP-Protocol-Version` header → 400
- `transport = "http"` in config starts uvicorn, `transport = "stdio"` starts stdio mode

---

### 4.6 Registry Updates

**Modules**: `registry/`, `schedulers.py`, `mcp/lifespan.py`

**Expected behaviours**:

- Registry metadata fetch happens at startup (mocked in test)
- If remote version matches local: no download
- If remote version differs: download, validate checksum, rebuild indexes
- Checksum mismatch: log warning, keep existing registry
- Successful update persists both `known-libraries.json` and `registry-state.json`
- When metadata advertises additional-info, setup/update attempts to persist `additional-info.json` best-effort; failure warns but does not fail the main registry update
- Additional-info metadata changes are applied even when the main registry version does not change
- Local registry pair (`known-libraries.json` + `registry-state.json`) is validated at startup; missing/invalid pair exits immediately with actionable setup guidance
- `save_registry_to_disk()` uses temp files + fsync + atomic replace (no partially written destination files)
- Simulated interrupted write leaves startup in a safe state (either previous valid pair or a clean startup failure with setup guidance)
- HTTP mode scheduler: successful checks run every 24 hours
- HTTP mode scheduler: transient failures use exponential backoff + jitter (1 minute to 60 minutes cap)
- HTTP mode scheduler: after 8 consecutive transient failures, counter and backoff reset, cadence returns to 24 hours; next round gets a fresh set of fast-retry attempts
- HTTP mode scheduler: semantic failures (checksum/metadata/schema) do not fast-retry and return to 24-hour cadence

---

### 4.7 Outline

**Modules**: `outline.py`, `tools/read_outline.py`

**Expected behaviours**:

- `parse_outline_entries()` converts a raw outline string into structured `OutlineEntry` objects with correct `line_number`, `text`, `depth`, `is_fence`, and `in_fence` attributes
- Fence tracking follows CommonMark rules: closer must use the same character as the opener and be at least as long; simple boolean toggle with char/length state
- `strip_empty_fences()` removes fence pairs that contain zero heading entries
- `strip_empty_fences()` runs before compaction and removes fence pairs that contain zero heading entries
- `compact_outline()` progressively strips H6 → H5 → fenced content (fence markers + headings inside fences) → H4 → H3, stopping as soon as entries ≤ 50
- `compact_outline()` returns `None` if the outline cannot be reduced to ≤ 50 entries after all compaction stages
- `trim_outline_to_range()` filters entries to those between a start and end line number (inclusive); used by `search_page` to trim to match range
- `format_outline()` converts structured entries back to the formatted string (`"line_number:content\nline_number2:content2..."`)
- `read_outline` tool returns stripped outline entries within a page-line window (offset = 1-based page line, limit = forward page-line span, optional `before` = backward page-line context)
- `read_outline` with offset beyond the last page line containing any outline entry returns empty outline with correct metadata, not an error
- `read_page` compacted outline replaces full outline in output; if irreducible, output contains status string `"[Outline too large (N entries). Use read_outline for paginated access.]"`
- `search_page` returns the full outline for small pages; oversized pages are range-trimmed then compacted; zero matches → empty string

---

## 5. Testing Strategy

**Framework**: `pytest` with `pytest-asyncio` (`asyncio_mode = "auto"` — all async test functions run without an explicit decorator). Async test helpers should use anyio primitives (`anyio.sleep`, `anyio.Event`, `anyio.fail_after`) rather than asyncio equivalents. See Rule 19 in `docs/coding-guidelines.md`.

**HTTP mocking**: `respx` for mocking `httpx` requests. Never make real network calls in tests.

**Database**: Each test that touches SQLite uses an in-memory database (`aiosqlite.connect(":memory:")`), created fresh per test via a fixture. No shared database state between tests.

**Directory split**:

- `tests/unit/` — Tests for individual internal modules (resolver, parser, fetcher, cache). No tool pipeline, no FastMCP. Run alone for fast feedback (`pytest tests/unit`).
- `tests/integration/` — Full tool pipeline tests. Uses a complete `AppState` with mocked HTTP and in-memory SQLite.

**Contract tests vs. implementation tests**:

The **integration suites** are the contract tests — the tool-focused files (`test_resolve_library.py`, `test_read_page*.py`, `test_search_page.py`, `test_read_outline.py`) plus the wire-level and startup suites (`test_mcp_wire_contract.py`, `test_mcp_error_envelope.py`, `test_stdout_guard.py`, `test_startup_errors.py`). They exercise the observable behaviour an MCP client or operator cares about. A complete internal rewrite (e.g., swapping the cache backend, changing the resolver algorithm) must not break those integration tests.

`tests/unit/` contains **implementation tests** — they call internal functions directly and verify algorithmic correctness (normalisation edge cases, parser rules, SSRF logic). These tests are permitted to break during refactoring, because they test the implementation, not the contract. Their purpose is fast feedback during development, not stability guarantees. Do not treat a failing unit test as a sign the public API is broken — check the integration tests for that.

**Top-level fixtures** (`tests/conftest.py`):

```python
import pytest
from procontext.models.registry import RegistryEntry, RegistryPackages
from procontext.registry import build_indexes

@pytest.fixture
def sample_entries() -> list[RegistryEntry]:
    return [
        RegistryEntry(
            id="langchain",
            name="LangChain",
            description="Framework for building LLM-powered applications.",
            languages=["python"],
            packages=RegistryPackages(pypi=["langchain", "langchain-openai", "langchain-core"]),
            aliases=["lang-chain"],
            llms_txt_url="https://docs.langchain.com/llms.txt",
        ),
        RegistryEntry(
            id="pydantic",
            name="Pydantic",
            description="Data validation using Python type annotations.",
            languages=["python"],
            packages=RegistryPackages(pypi=["pydantic", "pydantic-settings"]),
            aliases=[],
            llms_txt_url="https://docs.pydantic.dev/latest/llms.txt",
        ),
    ]

@pytest.fixture
def indexes(sample_entries):
    return build_indexes(sample_entries)
```

**Unit fixtures** (`tests/unit/conftest.py`):

```python
import pytest
import aiosqlite
from procontext.cache import Cache
from procontext.config import Settings

@pytest.fixture
def settings() -> Settings:
    return Settings()  # All defaults

@pytest.fixture
async def cache():
    async with aiosqlite.connect(":memory:") as db:
        c = Cache(db)
        await c.init_db()
        yield c
```

**Integration fixtures** (`tests/integration/conftest.py`):

```python
import pytest
import respx
import httpx
import aiosqlite
from procontext.state import AppState
from procontext.cache import Cache
from procontext.fetcher import Fetcher, build_allowlist
from procontext.config import Settings

@pytest.fixture
async def app_state(indexes, sample_entries):
    """Full AppState with mocked HTTP and in-memory SQLite."""
    async with aiosqlite.connect(":memory:") as db:
        cache = Cache(db)
        await cache.init_db()

        async with httpx.AsyncClient() as client:
            fetcher = Fetcher(client)
            allowlist = build_allowlist(sample_entries)
            state = AppState(
                settings=Settings(),
                indexes=indexes,
                registry_version="test",
                http_client=client,
                cache=cache,
                fetcher=fetcher,
                allowlist=allowlist,
            )
            yield state
```

**What each test file covers**:

`tests/unit/test_resolver.py`

- Input validation boundaries and whitespace trimming
- Exact package, library ID, and alias matches
- Fuzzy match behavior and score ordering
- Unsupported dependency syntax returns no resolver match
- No match → empty list
- Edge case: dependency specifiers are rejected (`"langchain[openai]"`, `"langchain>=0.1"`)
- Edge case: monorepo packages (`"langchain-core"` → `"langchain"`)

`tests/unit/test_fetcher.py`

- SSRF: private IPv4 ranges blocked
- SSRF: private IPv6 blocked
- SSRF: redirect to another public domain is followed after the initial allowlisted hop
- SSRF: redirect to private IP blocked
- Successful fetch: returns content
- 404 response: raises `PAGE_NOT_FOUND`
- Network error: raises `PAGE_FETCH_FAILED`
- Too many redirects: raises `TOO_MANY_REDIRECTS`

`tests/unit/test_cache.py`

- Fresh entry: returned, `stale=False`
- Expired entry: returned with `stale=True`
- Missing entry: returns `None`
- Write then read: round-trip correctness
- Cleanup: entries beyond TTL + 7 days are deleted
- Read failure (`aiosqlite.Error` raised by DB): returns `None`, does not raise
- Write failure (`aiosqlite.Error` raised by DB): returns normally, does not raise

`tests/unit/test_parser.py`

- H1–H6 headings detected with correct 1-based line numbers
- ATX headings support tab-separated markers and empty headings
- Plain setext headings normalized to synthetic `#` / `##` entries; blockquote setext remains unsupported
- Blockquote headings (`> ## Section`) are captured; deeply nested (`>> ##`) are not
- Fence openers/valid closers emitted as-is; fence-like lines with trailing info text inside a fence do not close it
- Headings inside code blocks captured with original indentation
- 4-space indented lines not treated as fence openers
- 4-space indented heading-like lines outside fences not captured
- Lines with 7+ hashes not captured
- BOM (`\ufeff`) on line 1 does not prevent heading detection

`tests/unit/test_search.py`

- Literal search: exact matches found, non-matches excluded
- Regex search: valid patterns match correctly
- Regex search: invalid pattern raises `re.error` (caught as `INVALID_INPUT` in handler)
- Smart case: all-lowercase query is case-insensitive; mixed-case query is case-sensitive
- `whole_word: true`: matches whole words only, not substrings
- Offset: lines before offset are skipped
- Pagination: `max_results` limits matches; `has_more` and `next_offset` are correct
- Edge case: no matches → empty list, `has_more=False`, `next_offset=None`
- Edge case: empty content → empty list

`tests/unit/test_outline.py`

- `parse_outline_entries()`: structured entries with correct depth, fence state
- Fence tracking: CommonMark rules (same char, at least as long)
- `strip_empty_fences()`: empty fence pairs removed, non-empty fence pairs preserved
- `compact_outline()`: progressive reduction respects stage order; stops at ≤ 50
- `compact_outline()`: returns `None` when irreducible
- `trim_outline_to_range()`: filters to line range, empty input → empty output
- `format_outline()`: round-trips correctly from parsed entries

`tests/integration/`

- `test_resolve_library.py`: full resolver contract, unsupported-input hints, language sorting
- `test_read_page.py`, `test_read_page_md_probe.py`, `test_read_page_compaction.py`: cache behaviour, `.md` probing, compaction, redirect limits, allowlist enforcement
- `test_read_outline.py`: paginated outline browsing and metadata
- `test_search_page.py`: shared-cache search flow, regex validation, small-vs-oversized outline behaviour
- `test_mcp_wire_contract.py`, `test_mcp_error_envelope.py`: MCP wire contract, output schemas, structured tool errors
- `test_cli.py`, `test_stdout_guard.py`, `test_startup_errors.py`: CLI surface, stdout protection, startup failure paths

**Coverage target**: 90% branch coverage (`branch = true` in `[tool.coverage.run]`). Branches covering network errors, cache misses, and config validation failures are explicitly tested via mocking — not left to chance.

---

## 6. CI/CD

### Commit Message Convention

All commits must follow [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>[optional scope]: <description>

[optional body]

[optional footer: BREAKING CHANGE: <description>]
```

Common types: `feat` (new feature), `fix` (bug fix), `docs`, `refactor`, `test`, `chore`. Breaking changes must include `BREAKING CHANGE:` in the footer — this is what drives major version bumps and ensures the changelog correctly marks breaking changes.

### ci.yml — Test Pipeline

Runs on every push and pull request to `main`.

```yaml
# .github/workflows/ci.yml
name: CI

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

permissions:
  contents: read

concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"

      - name: Install uv
        uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock

      - name: Install dependencies
        run: uv sync --dev --frozen

      - name: Lint
        run: uv run ruff check src/ tests/

      - name: Format check
        run: uv run ruff format --check src/ tests/

      - name: Type check
        run: uv run pyright src/

  test:
    runs-on: ubuntu-latest
    needs: validate
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock
      - run: uv sync --dev --frozen

      - name: Tests with coverage
        run: |
          uv run pytest tests/ \
            --cov=src/procontext \
            --cov-report=term-missing \
            --cov-fail-under=90

  package-smoke:
    runs-on: ubuntu-latest
    needs: validate
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock
      - run: uv sync --dev --frozen
      - run: uv build
      - run: |
          python -m venv .pkg-smoke
          ./.pkg-smoke/bin/pip install dist/*.whl
          ./.pkg-smoke/bin/procontext --help
          ./.pkg-smoke/bin/procontext doctor --help

  smoke-platform:
    strategy:
      matrix:
        os: [macos-latest, windows-latest]
    runs-on: ${{ matrix.os }}
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock
      - run: uv sync --frozen
      - run: uv run procontext --help

  audit:
    runs-on: ubuntu-latest
    needs: validate
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock
      - run: uv sync --dev --frozen
      - run: uv run pip-audit --skip-editable
```

Validation, tests, packaging smoke, and cross-platform smoke now run as separate jobs. This keeps the feedback loop faster than a single serialized pipeline while preserving the required gates on Linux. Every job installs from the committed `uv.lock` in frozen mode, so CI and local debugging resolve the same dependency graph.

### release.yml — Release Pipeline

Runs on manual trigger (`workflow_dispatch`) while the release process is still maturing. The workflow now reruns the same validation gates as CI and adds a package smoke check before any version bump or publish step. This prevents manual dispatch from bypassing lint, type-checking, tests, or packaging sanity.

PyPI publishing is additionally guarded by a protected GitHub Actions environment named `pypi`. The validation and smoke jobs still run automatically, but the final publish job pauses for environment approval before `semantic-release` pushes the release tag and `uv publish` uploads artifacts. That keeps publishing manual twice: once at dispatch time and once at the final approval boundary.

```yaml
# .github/workflows/release.yml
name: Release

on:
  workflow_dispatch:

concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: false

jobs:
  validate:
    runs-on: ubuntu-latest
    permissions:
      contents: read

    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0 # Full history required for semantic-release

      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"

      - name: Install uv
        uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock

      - name: Install dependencies
        run: uv sync --dev --frozen

      - name: Lint
        run: uv run ruff check src/ tests/

      - name: Format check
        run: uv run ruff format --check src/ tests/

      - name: Type check
        run: uv run pyright src/

      - name: Tests with coverage
        run: |
          uv run pytest tests/ \
            --cov=src/procontext \
            --cov-report=term-missing \
            --cov-fail-under=90

      - name: Dependency audit
        run: uv run pip-audit --skip-editable

  package-smoke:
    runs-on: ubuntu-latest
    needs: validate
    permissions:
      contents: read
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock
      - run: uv sync --dev --frozen
      - run: uv build
      - run: |
          python -m venv .pkg-smoke
          ./.pkg-smoke/bin/pip install dist/*.whl
          ./.pkg-smoke/bin/procontext --help
          ./.pkg-smoke/bin/procontext doctor --help

  release:
    runs-on: ubuntu-latest
    needs: [validate, package-smoke]
    environment:
      name: pypi
    permissions:
      id-token: write
      contents: write
      attestations: write
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
          token: ${{ secrets.GITHUB_TOKEN }}
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock
      - run: uv sync --dev --frozen

      - name: Bump version and push tag
        env:
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        run: uv run semantic-release version

      - name: Build package
        run: uv build

      - name: Attest build provenance
        uses: actions/attest-build-provenance@v1
        with:
          subject-path: dist/

      - name: Publish to PyPI
        run: uv publish --trusted-publishing always
```

`semantic-release version` inspects commit history since the last tag, determines the next version (patch/minor/major), updates the project version, creates a release commit, and pushes a Git tag. The workflow then builds the wheel/sdist with `uv build`, generates a provenance attestation for `dist/`, and publishes to PyPI with trusted publishing. Because the validation and smoke jobs run first, the release job is gated on the same checks used in CI. The protected `pypi` environment adds one more safeguard: the publish job must be explicitly approved in GitHub before any tag push or PyPI upload proceeds.

### audit.yml — Scheduled Security Audit

Runs weekly and on manual dispatch. This separates the slower recurring dependency audit from developer-triggered CI while still keeping the audit command easy to run on demand.

```yaml
# .github/workflows/audit.yml
name: Security Audit

on:
  schedule:
    - cron: "0 6 * * 1"
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - uses: astral-sh/setup-uv@v5
        with:
          enable-cache: true
          cache-dependency-glob: uv.lock
      - run: uv sync --dev --frozen
      - run: uv run pip-audit --skip-editable
```

`actions/attest-build-provenance` generates a signed SLSA provenance attestation — a cryptographic record proving which source commit produced which artifact, via which build pipeline. This is attached to the GitHub release and is verifiable via `gh attestation verify`. Enterprise consumers increasingly require provenance before adopting a dependency.

`python-semantic-release` and its `[tool.semantic_release]` config in `pyproject.toml` are added once the release pipeline is needed — not required during initial development.

```toml
# Already present in pyproject.toml [dependency-groups].dev:
# "python-semantic-release>=9.0.0,<10.0.0",  # Changelog generation + PyPI publishing

[tool.semantic_release]
version_toml = ["pyproject.toml:project.version"]
changelog_file = "CHANGELOG.md"
build_command = "uv build"
```

---

## 7. Local Development Setup

```bash
# 1. Clone and install
git clone https://github.com/procontexthq/procontext.git
cd procontext
uv sync --extra dev

# 2. Run in stdio mode (default)
uv run procontext

# 3. Run in HTTP mode
PROCONTEXT__SERVER__TRANSPORT=http uv run procontext
# or: copy procontext.example.yaml → procontext.yaml, set transport: http

# 4. Run all tests
uv run pytest

# 5. Run only unit tests (fast feedback during development)
uv run pytest tests/unit

# 6. Run with coverage
uv run pytest --cov=src/procontext --cov-report=html
open htmlcov/index.html

# 7. Lint and format
uv run ruff check src/ tests/
uv run ruff format src/ tests/
```

**Development config** (copy `procontext.example.yaml` to `procontext.yaml` and adjust):

```yaml
server:
  transport: http
  host: "127.0.0.1"
  port: 8080

logging:
  level: DEBUG
  format: text # Human-readable for local dev
```
