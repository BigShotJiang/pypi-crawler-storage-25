# ProContext: Technical Specification

> **Document**: 02-technical-spec.md
> **Status**: Draft v2
> **Last Updated**: 2026-03-20
> **Depends on**: 01-functional-spec.md

---

## Table of Contents

- [1. System Architecture](#1-system-architecture)
  - [1.1 Component Overview](#11-component-overview)
  - [1.2 Request Flow](#12-request-flow)
- [2. Technology Stack](#2-technology-stack)
- [3. Data Models](#3-data-models)
  - [3.1 Registry Models](#31-registry-models)
  - [3.2 Cache Models](#32-cache-models)
  - [3.3 Tool Input/Output Models](#33-tool-inputoutput-models)
  - [3.4 Error Model](#34-error-model)
- [4. Library Resolution](#4-library-resolution)
  - [4.1 In-Memory Indexes](#41-in-memory-indexes)
  - [4.2 Resolution Algorithm](#42-resolution-algorithm)
  - [4.3 Fuzzy Matching](#43-fuzzy-matching)
  - [4.4 Query Normalisation](#44-query-normalisation)
- [5. Documentation Fetcher](#5-documentation-fetcher)
  - [5.1 HTTP Client](#51-http-client)
  - [5.2 SSRF Prevention](#52-ssrf-prevention)
  - [5.3 Redirect Handling](#53-redirect-handling)
- [6. Cache](#6-cache)
  - [6.1 SQLite Schema](#61-sqlite-schema)
  - [6.2 Stale-While-Revalidate](#62-stale-while-revalidate)
- [7. Outline Parser](#7-outline-parser)
  - [7.1 Algorithm](#71-algorithm)
- [7A. Search](#7a-search)
  - [7A.1 Pattern Compilation](#7a1-pattern-compilation)
  - [7A.2 Line Scanning](#7a2-line-scanning)
- [8. Transport Layer](#8-transport-layer)
  - [8.1 stdio Transport](#81-stdio-transport)
  - [8.2 HTTP Transport](#82-http-transport)
- [8A. CLI](#8a-cli)
  - [8A.1 Dispatcher](#8a1-dispatcher)
  - [8A.2 Doctor Command](#8a2-doctor-command)
- [9. Registry Updates](#9-registry-updates)
  - [9.1 Registry Files](#91-registry-files)
  - [9.2 procontext setup](#92-procontext-setup)
  - [9.3 Startup Sequence](#93-startup-sequence)
  - [9.4 Two-URL Design](#94-two-url-design)
  - [9.5 Outcome Classification](#95-outcome-classification)
  - [9.6 Background Update Check](#96-background-update-check)
  - [9.7 In-Memory Hot-Swap](#97-in-memory-hot-swap)
  - [9.8 Atomic Persistence of Local Registry Pair](#98-atomic-persistence-of-local-registry-pair)
  - [9.9 Scheduling Policy](#99-scheduling-policy)
- [10. Configuration](#10-configuration)
- [11. Logging](#11-logging)

---

## 1. System Architecture

### 1.1 Component Overview

```
┌─────────────────────────────────────────────────────┐
│                 MCP Client                          │
│  (Claude Code, Cursor, Windsurf, custom)            │
└──────────────┬──────────────────┬───────────────────┘
               │ stdio            │ Streamable HTTP
               ▼                  ▼
┌─────────────────────────────────────────────────────┐
│              ProContext MCP Server                  │
│                                                     │
│  ┌──────────────────────────────────────────────┐   │
│  │  Tools                                       │   │
│  │  resolve_library │ read_page │ search_page │ read_outline │   │
│  └────────────────────────┬─────────────────────┘   │
│                           │                         │
│  ┌────────────────────────▼─────────────────────┐   │
│  │  Core                                        │   │
│  │  ┌──────────────┐  ┌────────────────────┐   │   │
│  │  │  Resolver    │  │  Fetcher           │   │   │
│  │  │  (in-memory) │  │  (httpx + SSRF)    │   │   │
│  │  └──────────────┘  └─────────┬──────────┘   │   │
│  │                              │              │   │
│  │  ┌───────────────────────────▼──────────┐   │   │
│  │  │  Cache (SQLite, WAL mode)            │   │   │
│  │  └──────────────────────────────────────┘   │   │
│  └──────────────────────────────────────────────┘   │
│                                                     │
│  ┌──────────────────────────────────────────────┐   │
│  │  Infrastructure                               │   │
│  │  Config │ Logger │ Errors │ Registry Loader   │   │
│  └──────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────┘
```

### 1.2 Request Flow

```
resolve_library("langchain-openai")
  │
  ├─ Normalize package key: trim + lowercase
  ├─ Index 1 (package → IDs): "langchain-openai" → ["langchain"]  ✓
  └─ Return [{ library_id: "langchain", index_url: "...", matched_via: "package_name", relevance: 1.0 }]

read_page("https://python.langchain.com/llms.txt")
  │
  ├─ SSRF check: domain in allowlist?
  ├─ Cache check: url_hash = sha256(url)
  │    HIT (fresh)  → return cached content + outline
  │    HIT (stale)  → return stale immediately; spawn background refresh
  │    MISS         → continue
  ├─ Fetch: HTTP GET url (30s timeout, initial URL allowlisted; private IPs blocked on redirect hops)
  ├─ Store: page_cache (TTL 24h)
  ├─ Parse: extract outline (H1–H6, fence lines, line numbers)
  ├─ Compact outline (progressive depth reduction → ≤max_entries AND ≤max_chars, or status message)
  └─ Return: { outline: "...", content: "...", has_more: bool }

search_page("https://python.langchain.com/llms.txt", "streaming")
  │
  ├─ SSRF check: domain in allowlist?
  ├─ Cache check: url_hash = sha256(url) — shared cache with read_page
  │    HIT  → use cached content
  │    MISS → fetch and cache (same path as read_page)
  ├─ Build matcher from query + mode + case_mode + whole_word
  ├─ Scan lines from offset, collect up to max_results matches
  ├─ If outline is already small (≤max_entries AND ≤max_chars after empty-fence stripping), return it unchanged
  ├─ Otherwise trim outline to match range (first match line → last match line)
  ├─ Compact the oversized trimmed outline (progressive depth reduction → ≤max_entries AND ≤max_chars)
  └─ Return: { outline: "...", matches: [...], has_more: bool }

read_outline("https://python.langchain.com/llms.txt", offset=1, limit=1000)
  │
  ├─ SSRF check: domain in allowlist?
  ├─ Cache check: url_hash = sha256(url) — shared cache with read_page/search_page
  │    HIT  → use cached outline
  │    MISS → fetch and cache (same path as read_page)
  ├─ Parse outline string into structured entries
  ├─ Strip empty fences (fence pairs with no headings inside)
  ├─ Paginate: slice entries by offset/limit
  └─ Return: { outline: "...", total_entries: int, has_more: bool }
```

---

## 2. Technology Stack

| Component          | Choice                | Version | Rationale                                                                     |
| ------------------ | --------------------- | ------- | ----------------------------------------------------------------------------- |
| Language           | Python                | 3.12+   | Modern asyncio, improved error messages, per-interpreter GIL                  |
| Package manager    | uv                    | latest  | Fast installs, lock files, `uvx` for tool distribution                        |
| MCP framework      | FastMCP (mcp package) | ≥1.26   | Official Python MCP SDK; handles protocol, tool registration, transport       |
| HTTP client        | httpx                 | ≥0.28   | Async-native, connection pooling, manual redirect control (required for SSRF) |
| SQLite driver      | aiosqlite             | ≥0.19   | Async wrapper over sqlite3; WAL mode for concurrent reads                     |
| Data validation    | pydantic v2           | ≥2.5    | Fast validation, settings management, serialisation                           |
| Fuzzy matching     | rapidfuzz             | ≥3.6    | C extension, Levenshtein distance for resolve_library fuzzy step              |
| Logging            | structlog             | ≥24.1   | Structured JSON logs; context binding per request                             |
| Config             | pydantic-settings     | ≥2.2    | YAML config with env var overrides, validated at startup                      |
| Config parsing     | pyyaml                | ≥6.0    | YAML parser required by pydantic-settings `YamlConfigSettingsSource`          |
| ASGI server        | uvicorn               | ≥0.34   | HTTP transport; ASGI lifespan support                                         |
| Linting/formatting | ruff                  | ≥0.11   | Single tool for lint + format, replaces flake8/black/isort                    |

---

## 3. Data Models

All models use pydantic v2. Models are defined in the `src/procontext/models/` package, split by domain (`registry.py`, `cache.py`, `tools.py`). All public models are re-exported from `models/__init__.py` so callers can import from either `procontext.models` or the specific submodule.

### 3.1 Registry Models

```python
from pydantic import BaseModel, field_validator

class PackageEntry(BaseModel):
    """A single package ecosystem entry within a registry library."""
    ecosystem: Literal["pypi", "npm", "conda", "jsr"]
    languages: list[str]           # e.g. ["python"], ["javascript", "typescript"]
    package_names: list[str]       # e.g. ["langchain", "langchain-core", "langchain-openai"]
    readme_url: str | None = None  # URL to the library's README (typically raw content from GitHub)
    repo_url: str | None = None    # URL to the source repository

class RegistryEntry(BaseModel):
    """Single entry in known-libraries.json"""
    id: str
    name: str
    description: str = ""
    packages: list[PackageEntry] = []
    aliases: list[str] = []
    llms_txt_url: str

    @field_validator("id")
    @classmethod
    def validate_id(cls, v: str) -> str:
        import re
        if not re.match(r"^[a-z0-9][a-z0-9_-]*$", v):
            raise ValueError(f"Invalid library ID: {v!r}")
        return v

class LibraryMatch(BaseModel):
    """Single result from resolve_library"""
    library_id: str
    name: str
    description: str               # Short description of what the library does
    index_url: str                  # URL to the library's llms.txt documentation index
    packages: list[PackageEntry]    # Package ecosystem entries (languages, readme, repo live here)
    matched_via: Literal["package_name", "library_id", "name", "alias", "fuzzy"]
    relevance: float               # 0.0–1.0
```

### 3.2 Cache Models

```python
from datetime import datetime
from pydantic import BaseModel

class PageCacheEntry(BaseModel):
    url: str
    url_hash: str             # SHA-256 of url (primary key)
    content: str              # Full page markdown (llms.txt, README, or docs)
    outline: str              # Plain-text structural outline: "<line>:<emitted outline text>\n..."
    fetched_at: datetime
    expires_at: datetime
    last_checked_at: datetime | None = None  # Last background refresh attempt
    stale: bool = False
    discovered_domains: frozenset[str] = frozenset()  # Base domains extracted from content URLs
```

All fetched content — llms.txt indexes, README files, and documentation pages — is stored in a single `page_cache` table. All three page tools (`read_page`, `search_page`, `read_outline`) share this cache.

### 3.3 Tool Input/Output Models

```python
from procontext.normalization import normalize_doc_url

class ResolveLibraryInput(BaseModel):
    query: str
    language: str | None = None   # Optional language preference; sorts (not filters) results

    @field_validator("query")
    @classmethod
    def validate_query(cls, v: str) -> str:
        v = v.strip()
        if len(v) < 3:
            raise ValueError("query must be at least 3 characters")
        if len(v) > 500:
            raise ValueError("query must not exceed 500 characters")
        return v

class ResolveHint(BaseModel):
    code: Literal["UNSUPPORTED_QUERY_SYNTAX", "FUZZY_FALLBACK_USED"]
    message: str

class ResolveLibraryOutput(BaseModel):
    matches: list[LibraryMatch]
    hint: ResolveHint | None = None

class ReadPageInput(BaseModel):
    url: str
    offset: int = 1
    limit: int = 500
    before: int = 0
    include_outline: bool = True

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        url = normalize_doc_url(v)
        if len(url) > 2048:
            raise ValueError("url must not exceed 2048 characters")
        if not url.startswith(("http://", "https://")):
            raise ValueError("url must use http or https scheme")
        return url

    @field_validator("offset")
    @classmethod
    def validate_offset(cls, v: int) -> int:
        if v < 1:
            raise ValueError("offset must be >= 1")
        return v

    @field_validator("limit")
    @classmethod
    def validate_limit(cls, v: int) -> int:
        if v < 1:
            raise ValueError("limit must be >= 1")
        return v

    @field_validator("before")
    @classmethod
    def validate_before(cls, v: int) -> int:
        if v < 0:
            raise ValueError("before must be >= 0")
        return v

class ReadPageOutput(BaseModel):
    url: str
    outline: str | None       # Compacted outline, status message if too large, or None when include_outline=False
    total_lines: int
    offset: int               # Actual first returned content line after applying before
    limit: int                # Forward lines requested from the input offset
    content: str              # Page markdown for the returned window
    has_more: bool             # True if more content exists beyond the current window
    next_offset: int | None    # Line number to pass as offset to continue; None if no more
    content_hash: str          # Truncated SHA-256 (12 hex chars) of full page content
    cached: bool
    cached_at: datetime | None
    stale: bool = False

class SearchPageInput(BaseModel):
    url: str
    query: str
    target: Literal["content", "outline"] = "content"
    mode: Literal["literal", "regex"] = "literal"
    case_mode: Literal["smart", "insensitive", "sensitive"] = "smart"
    whole_word: bool = False
    offset: int = 1
    max_results: int = 20

    @field_validator("url")
    @classmethod
    def validate_url(cls, v: str) -> str:
        url = normalize_doc_url(v)
        if len(url) > 2048:
            raise ValueError("url must not exceed 2048 characters")
        if not url.startswith(("http://", "https://")):
            raise ValueError("url must use http or https scheme")
        return url

    @field_validator("query")
    @classmethod
    def validate_query(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("query must not be empty")
        if len(v) > 200:
            raise ValueError("query must not exceed 200 characters")
        return v

    @field_validator("offset")
    @classmethod
    def validate_offset(cls, v: int) -> int:
        if v < 1:
            raise ValueError("offset must be >= 1")
        return v

    @field_validator("max_results")
    @classmethod
    def validate_max_results(cls, v: int) -> int:
        if v < 1:
            raise ValueError("max_results must be >= 1")
        return v

class SearchPageOutput(BaseModel):
    url: str
    query: str
    outline: str              # Content-mode outline context; empty if no matches or target="outline"
    matches: str              # Matching lines as "line_number:content"; outline mode returns matching outline entries in the same format
    total_lines: int
    has_more: bool
    next_offset: int | None   # Line number for next search call; None if no more matches
    content_hash: str          # Truncated SHA-256 (12 hex chars) of full page content
    cached: bool
    cached_at: datetime | None

class ReadOutlineInput(BaseModel):
    url: str
    offset: int = 1           # 1-based page line number
    limit: int = 1000         # Forward page-line span from offset
    before: int = 0           # Backward page-line context before offset

    # Same url validator as ReadPageInput
    # offset >= 1, limit >= 1, before >= 0

class ReadOutlineOutput(BaseModel):
    url: str
    outline: str              # Paginated outline entries: "<line>:<text>\n..."
    total_entries: int        # Total entries after stripping empty fences
    has_more: bool
    next_offset: int | None   # Page line number to continue; None if no more
    content_hash: str          # Truncated SHA-256 (12 hex chars) of full page content
    cached: bool
    cached_at: datetime | None
    stale: bool = False
```

### 3.4 Error Model

```python
from enum import StrEnum
from pydantic import BaseModel

class ErrorCode(StrEnum):
    PAGE_NOT_FOUND        = "PAGE_NOT_FOUND"
    PAGE_FETCH_FAILED     = "PAGE_FETCH_FAILED"
    TOO_MANY_REDIRECTS    = "TOO_MANY_REDIRECTS"
    URL_NOT_ALLOWED       = "URL_NOT_ALLOWED"
    INVALID_INPUT         = "INVALID_INPUT"

class ProContextError(Exception):
    """Base exception for all ProContext errors.

    Raised by tool handlers. FastMCP catches it automatically and converts
    it into an MCP tool result with isError=true. No explicit serialisation
    method is needed — the framework handles the wire format.
    """
    def __init__(
        self,
        code: ErrorCode,
        message: str,
        suggestion: str,
        recoverable: bool = False,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.suggestion = suggestion
        self.recoverable = recoverable
```

---

## 4. Library Resolution

### 4.1 In-Memory Indexes

Loaded from `known-libraries.json` at startup. Four lookup structures are rebuilt in a single pass (<100ms for 1,000 entries):

```python
@dataclass
class RegistryIndexes:
    # Index 1: package name (lowercase, as published) → library IDs
    by_package_exact: dict[str, list[str]]

    # Index 2: library ID → full RegistryEntry
    by_id: dict[str, RegistryEntry]

    # Index 3: normalized text → exact text hits from library_id, name, alias
    by_text_exact: dict[str, list[ExactTextHit]]

    # Flat list of unique (normalized_term, library_id) pairs for fuzzy matching
    fuzzy_corpus: list[tuple[str, str]]

def build_indexes(entries: list[RegistryEntry]) -> RegistryIndexes:
    by_package_exact_seen: dict[str, dict[str, None]] = {}
    by_id: dict[str, RegistryEntry] = {}
    by_text_exact_seen: dict[str, dict[str, ExactTextHit]] = {}
    fuzzy_corpus_seen: dict[tuple[str, str], None] = {}

    for entry in entries:
        by_id[entry.id] = entry
        # add text, package, and fuzzy terms with build-time dedupe

    return RegistryIndexes(
        by_package_exact=...,
        by_id=by_id,
        by_text_exact=...,
        fuzzy_corpus=list(fuzzy_corpus_seen.keys()),
    )
```

Build-time dedupe rules:

- Package indexes keep one entry per `(key, library_id)` while preserving registry order.
- Text index keeps one entry per `(key, library_id)` and upgrades weaker hits using the priority `library_id` → `name` → `alias`.
- Fuzzy corpus keeps one entry per `(normalized_term, library_id)`.

### 4.2 Resolution Algorithm

Three tiers in priority order. Exact package and exact text lookup always run before fuzzy.

```
Step 0: Detect unsupported input (see Section 4.4)
        - source refs / URLs
        - dependency modifiers such as extras, version specifiers, or npm tags
        - if unsupported: return { matches: [], hint: UNSUPPORTED_QUERY_SYNTAX }

Step 1: Exact package tier
        indexes.by_package_exact.get(normalized_package_query)

Step 2: Exact text tier
        indexes.by_text_exact.get(normalized_text_query)
        returns exact library_id, name, or alias matches in that priority order

Step 3: Merge exact hits
        - dedupe by library_id
        - if the same library appears in both tiers, keep the stronger match type
        - package_name > library_id > name > alias
        - order package hits before text hits
        - if merged exact set is non-empty: return it

Step 4: Fuzzy match (Levenshtein)
        rapidfuzz.process.extract against fuzzy_corpus terms
        "langchan" → "langchain" (distance 1)  ✓
        Returns ALL matches above threshold, ranked by relevance
        May attach hint FUZZY_FALLBACK_USED

Step 5: No match → return empty list
```

### 4.3 Fuzzy Matching

```python
from rapidfuzz import process, fuzz

def fuzzy_search(
    query: str,
    corpus: list[tuple[str, str]],  # (normalized_term, library_id)
    limit: int = 5,
) -> list[LibraryMatch]:
    terms = [term for term, _ in corpus]
    results = process.extract(
        query,
        terms,
        scorer=fuzz.ratio,
        limit=limit,
        score_cutoff=70,          # Reject matches below 70% similarity
    )

    seen: set[str] = set()
    matches: list[LibraryMatch] = []

    for term, score, idx in results:
        _, library_id = corpus[idx]
        if library_id in seen:    # Deduplicate: one result per library
            continue
        seen.add(library_id)
        matches.append(
            LibraryMatch(
                library_id=library_id,
                relevance=round(score / 100, 2),
                matched_via="fuzzy",
                # ... other fields from by_id lookup
            )
        )

    return sorted(matches, key=lambda m: m.relevance, reverse=True)
```

The same fuzzy-normalization helper is applied both when the corpus is built and when the incoming query reaches the fuzzy tier:

- trim outer whitespace
- lowercase
- collapse repeated internal whitespace

**Score cutoff rationale**: 70% rejects clearly wrong matches while catching common typos (`"fastapi"` → `"fasapi"`, `"langchain"` → `"langchan"`). Exact matches in steps 1–2 always score `1.0`.

### 4.4 Query Normalisation

Applied before every resolution attempt:

```python
def normalize_package_key(raw: str) -> str:
    query = raw.strip()
    return query.lower()

def normalize_text_key(raw: str) -> str:
    return " ".join(raw.strip().lower().split())
```

Unsupported-input detection is explicit and does not rewrite the query:

- Source refs / URLs: `https://github.com/...`, `git+https://...`, `github:user/repo`, `name @ https://...`
- Dependency modifiers: Python extras/version specifiers and npm `@version` / `@tag` suffixes

Hint policy:

- `UNSUPPORTED_QUERY_SYNTAX` for unsupported dependency/source syntax; caller should retry with only the plain package or library name
- `FUZZY_FALLBACK_USED` when the resolver returns fuzzy results instead of an exact match
- no hint for exact multi-match results; those are valid exact outcomes and are left for the caller to interpret

---

## 5. Documentation Fetcher

All network I/O goes through a single `Fetcher` instance shared across tool calls. Defined in `src/procontext/fetcher.py`.

### 5.1 HTTP Client

```python
import httpx

def build_http_client(settings: FetcherSettings | None = None) -> httpx.AsyncClient:
    read_timeout = settings.request_timeout_seconds if settings is not None else 30.0
    connect_timeout = settings.connect_timeout_seconds if settings is not None else 5.0
    return httpx.AsyncClient(
        follow_redirects=False,       # Manual redirect handling (SSRF requirement)
        timeout=httpx.Timeout(read_timeout, connect=connect_timeout),
        headers={"User-Agent": f"procontext/{__version__}"},
        limits=httpx.Limits(
            max_connections=10,
            max_keepalive_connections=5,
        ),
    )
```

The client is created once at startup and closed on shutdown. It is never re-created per request.

### 5.2 SSRF Prevention

The SSRF allowlist is built at startup from the loaded registry. In HTTP mode, if a background registry update succeeds, a new allowlist is rebuilt from the updated registry and swapped in-memory together with the new indexes. It stores **base domains** (the last two DNS labels: `langchain.com`, `pydantic.dev`) rather than exact hostnames. This allows any subdomain of a registered documentation domain — including subdomains not explicitly listed in the registry — to be used as the initial fetch URL.

```python
from urllib.parse import urlparse
import ipaddress

PRIVATE_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
]

def _base_domain(hostname: str) -> str:
    """Return the last two DNS labels: 'api.langchain.com' → 'langchain.com'."""
    parts = hostname.rstrip(".").split(".")
    return ".".join(parts[-2:]) if len(parts) >= 2 else hostname

def build_allowlist(
    entries: list[RegistryEntry],
    extra_domains: list[str] | None = None,
) -> frozenset[str]:
    """Build the SSRF domain allowlist from registry entries and optional extra domains."""
    base_domains: set[str] = set()
    for entry in entries:
        if entry.llms_txt_url:
            hostname = urlparse(entry.llms_txt_url).hostname or ""
            if hostname:
                base_domains.add(_base_domain(hostname))
    for domain in extra_domains or []:
        domain = domain.strip().lower()
        if domain:
            base_domains.add(_base_domain(domain))
    return frozenset(base_domains)

def extract_base_domains_from_content(content: str) -> frozenset[str]:
    """Extract base domains from all http/https URLs found in content.

    Used for runtime allowlist expansion from any fetched documentation content.
    """
    domains: set[str] = set()
    for match in _URL_RE.finditer(content):
        hostname = urlparse(match.group()).hostname or ""
        if hostname:
            domains.add(_base_domain(hostname))
    return frozenset(domains)

def expand_allowlist_from_content(
    content: str,
    state: AppState,
) -> frozenset[str]:
    """Extract discovered domains from content and optionally expand the live allowlist.

    Always returns the full set of discovered domains for cache persistence,
    regardless of expansion configuration. Only mutates ``state.allowlist`` when
    ``settings.fetcher.allowlist_expansion == "discovered"``.

    Called by the shared fetch helper used by read_page, search_page, and
    read_outline after any successful fetch.
    """
    discovered_domains = extract_base_domains_from_content(content)
    if state.settings.fetcher.allowlist_expansion == "discovered":
        new_domains = discovered_domains - state.allowlist
        if new_domains:
            state.allowlist = state.allowlist | new_domains
            log.info("allowlist_expanded", added_domains=len(new_domains))
    return discovered_domains

def is_url_allowed(
    url: str,
    allowlist: frozenset[str],
    *,
    check_private_ips: bool = True,
    check_domain: bool = True,
) -> bool:
    parsed = urlparse(url)
    hostname = parsed.hostname or ""

    if check_private_ips:
        try:
            addr = ipaddress.ip_address(hostname)
            if any(addr in net for net in PRIVATE_NETWORKS):
                return False
        except ValueError:
            pass

    if not check_domain:
        return True

    return _base_domain(hostname) in allowlist
```

**SSRF controls are configurable** via `FetcherSettings` (see Section 10):

- **`ssrf_private_ip_check`** (default `true`): blocks all requests to private/internal IP ranges. Strongly recommended to keep enabled.
- **`ssrf_domain_check`** (default `true`): enforces the domain allowlist. When `false`, any public domain is reachable — only appropriate for isolated/air-gapped environments.
- **`allowlist_expansion`** (default `"registry"`): controls whether the allowlist is expanded at runtime beyond the registry (see below).
- **`extra_allowed_domains`**: manually specified domains always merged into the allowlist at startup, regardless of expansion setting. Ships with `["github.com", "githubusercontent.com"]` as defaults.

**Runtime allowlist expansion** (reactive, not pre-fetched):

- **`"registry"`** (default): allowlist is fixed at startup — only registry domains + `extra_allowed_domains`.
- **`"discovered"`**: after any page tool fetches content (llms.txt, README, or documentation page), all URLs in the content have their base domains extracted and merged into `state.allowlist`. Enables following cross-domain links found in documentation.

When expansion is `"discovered"`, it is monotonic (domains are only added, never removed). The allowlist resets to the registry baseline on each registry update. In long-running HTTP mode, the allowlist may grow across sessions until the next registry update.

**Cross-restart persistence**: `discovered_domains` are always extracted from fetched content and written to the SQLite cache — even when expansion is `"registry"` — so they are available if the operator later enables `"discovered"` expansion. At startup, `Cache.load_discovered_domains()` reads all `discovered_domains` from `page_cache` and merges them into the initial allowlist (subject to `allowlist_expansion` setting). This ensures that cached pages from a previous session remain reachable after a server restart, and avoids the performance cost of re-running domain extraction on every server start.

**Known limitation**: Two-label base domain extraction is a simplification of proper eTLD+1 calculation. For shared hosting platforms like `github.io` or `readthedocs.io`, the base domain would be `github.io` or `readthedocs.io` — permitting all projects hosted there, not just the registered library. This is an acceptable trade-off for v1; a future version could adopt the `tldextract` library for accurate Public Suffix List-based matching.

### 5.3 Redirect Handling

The initial request URL is validated against the allowlist. Redirect hops continue to enforce the private-IP guard and the redirect limit, but they do not re-apply the domain allowlist:

```python
async def fetch(
    self,
    url: str,
    allowlist: frozenset[str],
    max_redirects: int = 3,
) -> str:
    """Returns response text on success. Raises ProContextError on failure."""
    current_url = url

    for hop in range(max_redirects + 1):
        check_domain = self._settings.ssrf_domain_check and hop == 0
        if not is_url_allowed(
            current_url,
            allowlist,
            check_private_ips=self._settings.ssrf_private_ip_check,
            check_domain=check_domain,
        ):
            raise ProContextError(
                code=ErrorCode.URL_NOT_ALLOWED,
                message=f"URL not in allowlist: {current_url}",
                suggestion="Only URLs from known documentation domains are permitted.",
                recoverable=False,
            )

        response = await self.client.get(current_url)

        if response.is_redirect:
            if hop == max_redirects:
                raise ProContextError(
                    code=ErrorCode.TOO_MANY_REDIRECTS,
                    message=f"Too many redirects fetching {url}",
                    suggestion="The documentation URL has an unusually long redirect chain.",
                    recoverable=False,
                )
            location = response.headers["location"]
            current_url = urljoin(current_url, location)  # resolves relative redirects
            continue

        if not response.is_success:
            # ... raise PAGE_NOT_FOUND (404) or PAGE_FETCH_FAILED (other)

        return response.text

    raise ProContextError(  # unreachable but satisfies type checker
        code=ErrorCode.TOO_MANY_REDIRECTS,
        message="Redirect loop",
        suggestion="",
        recoverable=False,
    )
```

This asymmetry is deliberate in the current implementation: the registry-derived allowlist constrains the initial URL, while redirect hops are only prevented from reaching private/internal IP space.

The return type is `str` (response text), not `httpx.Response`. This keeps `httpx` out of the tool layer — tool handlers and `FetcherProtocol` consumers never touch `httpx` types directly.

---

## 6. Cache

### 6.1 SQLite Schema

Single database at `cache.db_path` (default: `platformdirs.user_data_dir("procontext")/cache.db`). This default is intentionally independent from `data_dir` overrides. WAL mode is set once at connection time and persists — it does not need to be re-applied on subsequent opens.

```sql
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS page_cache (
    url_hash           TEXT PRIMARY KEY,             -- SHA-256(url)
    url                TEXT NOT NULL UNIQUE,
    content            TEXT NOT NULL,
    outline            TEXT NOT NULL DEFAULT '',     -- Plain-text structural outline
    discovered_domains TEXT NOT NULL DEFAULT '',     -- Space-separated base domains extracted from content
    fetched_at         TEXT NOT NULL,                -- ISO 8601
    expires_at         TEXT NOT NULL                 -- ISO 8601
);

CREATE INDEX IF NOT EXISTS idx_page_expires  ON page_cache(expires_at);

CREATE TABLE IF NOT EXISTS server_metadata (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
```

The `server_metadata` table stores operational state such as the last cleanup timestamp. It is a simple key-value store.

All fetched content — llms.txt indexes, README files, and documentation pages — is stored in a single `page_cache` table. All three page tools (`read_page`, `search_page`, `read_outline`) share this cache.

**Why TEXT for timestamps**: SQLite has no native datetime type. ISO 8601 strings (`"2026-02-23T10:00:00Z"`) sort lexicographically as datetimes, making range queries on `expires_at` correct without any conversion.

**`discovered_domains` column**: Stores the base domains (`example.com`, `docs.dev`) extracted from fetched content by `extract_base_domains_from_content`. Serialised as a space-separated string (base domains never contain spaces). Written unconditionally on every cache write — regardless of the current `allowlist_expansion` config — so the data is always available if the operator later enables `"discovered"` expansion. At startup, `Cache.load_discovered_domains()` reads all non-empty `discovered_domains` values from `page_cache` and merges them back into the in-memory allowlist (subject to `allowlist_expansion`). This restores cross-restart continuity for the runtime-expanded allowlist.

**Cleanup**: A periodic task (runs at startup and every 6 hours thereafter) deletes entries where `expires_at < now() - 7 days`. Stale entries are kept up to 7 days to serve as fallback when the source is temporarily unreachable.

### 6.2 Stale-While-Revalidate

`Cache.get_page()` marks the entry as stale but does **not** handle the re-fetch — that responsibility belongs to the tool layer, which has the full `AppState` (fetcher, allowlist, settings) needed to do the re-fetch.

```python
# In Cache.get_page() — marks stale, returns entry
async def get_page(self, url_hash: str) -> PageCacheEntry | None:
    entry = await self.db.fetch_page(url_hash)
    if entry is None:
        return None
    if entry.expires_at < datetime.now(UTC):
        entry.stale = True
    return entry

# In page/service.py — shared service used by read_page, search_page, read_outline
page = await state.cache.get_page(url_hash)
if page is not None and page.stale:
    _maybe_spawn_refresh(url, url_hash, state, page)  # background refresh
    return FetchResult(..., stale=True)  # return stale content immediately
```

All page tools use a dedicated page service (`fetch_or_cached_page`) that encapsulates the full cache-check → fetch → cache-write → stale-refresh flow. When a cached entry has expired, the stale content is returned immediately with `stale: true`, and a background task is spawned to refresh the cache. The next call to the same URL will get fresh content if the background refresh has completed.

**Background refresh guards**: Two mechanisms prevent redundant work:
- **In-memory `_refreshing` set** on `AppState`: Tracks URL hashes with in-flight refresh tasks. A second call to the same stale URL while a refresh is running does not spawn a duplicate task.
- **`last_checked_at` timestamp** in the cache: Updated on every refresh attempt (success or failure). URLs checked within the last 15 minutes are not re-checked, preventing rapid retries when the source is persistently unreachable.

**Content hash for pagination consistency**: Every response from `read_page`, `read_outline`, and `search_page` includes a `content_hash` field — a truncated SHA-256 (12 hex chars) of the full page content. If a background refresh updates the cache between paginated calls, the `content_hash` will change, allowing the agent to detect the inconsistency and restart from `offset=1`.

**`stale: true` semantics**: The `stale` field in the response means the cache entry has expired and a background refresh has been triggered. The agent is receiving cached content that is past its TTL. The next call may return fresh content (if the background refresh has completed) with a potentially different `content_hash`.

### 6.3 Cache Error Handling

`aiosqlite` exceptions must never escape the `Cache` class boundary. Tool handlers must not need to import or handle `sqlite3`/`aiosqlite` errors directly — this would leak infrastructure details through the abstraction.

**Read failures** (`get_page`): If the SQLite read raises `aiosqlite.Error`, catch it, log a warning with `exc_info=True`, and return `None`. The caller treats `None` as a cache miss and falls back to a network fetch. The agent receives a valid response with `cached: false`.

**Write failures** (`set_page`): If the SQLite write raises `aiosqlite.Error`, catch it, log a warning with `exc_info=True`, and return normally. The content was already fetched successfully — failure to persist it is non-fatal. The agent receives the fetched content; the next request will simply be a cache miss again.

**Cleanup failures** (`cleanup_expired`): Catch `aiosqlite.Error`, log a warning, and continue. Cleanup is a background maintenance task — failure to delete expired rows is non-critical.

```python
# Example: read failure degrades gracefully to cache miss
async def get_page(self, url_hash: str) -> PageCacheEntry | None:
    try:
        entry = await self.db.fetch_page(url_hash)
        ...
        return entry
    except aiosqlite.Error:
        log.warning("cache_read_error", key=f"page:{url_hash}", exc_info=True)
        return None  # Caller treats as cache miss

# Example: write failure is non-fatal
async def set_page(self, url: str, url_hash: str, ...) -> None:
    try:
        await self.db.upsert_page(...)
    except aiosqlite.Error:
        log.warning("cache_write_error", key=f"page:{url_hash}", exc_info=True)
        # Return normally — content was fetched successfully
```

---

## 7. Outline Parser & Compaction

The outline parser produces a plain-text structural map with 1-based line numbers for headings and fenced code block boundaries. The raw outline is generated by `src/procontext/parser.py` and cached alongside page content. Outline compaction and formatting are handled by `src/procontext/outline.py`.

The output format is a newline-separated string where each line is `<line_number>:<emitted outline text>`, e.g.:

```
1:# Authenticate
5:## OpenAPI
7:````yaml https://api.example.com/openapi.json
14:    ## Authentication
22:````
25:## Next Section
```

Fence opener/closer lines are included so the agent can determine which heading-like lines belong to code block content vs. structural page sections. The agent reads line numbers from the map and passes them as `offset` to `read_page` for targeted section reads.

### 7.1 Algorithm

Single pass with one-line lookahead: emit fence lines, emit ATX headings, and normalize supported setext heading pairs to synthetic ATX lines anchored to the title line number.

**Pattern 1 — Fence lines**

```python
_FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})")
```

Matched against the original `line`. The `^ {0,3}` indentation constraint ensures that 4-space indented lines (CommonMark indented code blocks) are not treated as fences.

**Pattern 2 — Heading lines**

```python
_HEADING_RE = re.compile(r"(?:>\s*)?(#{1,6})(?:[ \t]+|$)")
```

Used through fence-aware heading matching:
- Outside fenced code blocks, the parser removes up to 3 leading spaces before matching. Lines with 4+ leading spaces are treated as indented code, not structural headings.
- Inside fenced code blocks, the parser matches against `line.strip()` so heading-like content such as `    ## Host` is preserved in the outline.
- The optional `(?:>\s*)?` prefix still handles blockquote headings (`> ## Section`).

ATX headings are recognized when the hash marker is followed by a space, a tab, or end-of-line. This means empty ATX headings such as `##` are preserved in the outline, and tab-separated forms such as `#\tTitle` are accepted.

**Pattern 3 — Conservative setext headings**

```python
_SETEXT_RE = re.compile(r"^ {0,3}(=+|-+)\s*$")
```

Applied only when:
- the current title line is non-empty,
- the next line matches `_SETEXT_RE`,
- the parser is not currently inside a fenced code block,
- the title line is not itself an ATX heading, fence line, or blockquote,
- the title line has at most 3 leading spaces.

When matched, the pair is normalized to a synthetic ATX entry at the title line number:
- `Title` + `====` → `# Title`
- `Section` + `----` → `## Section`

```python
while index < len(raw_lines):
    if not in_fence and _FENCE_RE.match(line):
        lines.append(f"{lineno}:{line}")
    elif in_fence and _is_matching_fence_closer(line, fence_char, fence_len):
        lines.append(f"{lineno}:{line}")
    elif _match_heading(line, in_fence=in_fence):
        lines.append(f"{lineno}:{line}")
    elif not in_fence and _normalized_setext_heading(line, raw_lines[index + 1]):
        lines.append(f"{lineno}:{synthetic_heading}")
```

Fence closing follows CommonMark-style rules: the closer must use the same fence character as the opener, be at least as long, and contain only trailing spaces or tabs after the fence run. Lines such as ````python` inside a fenced block are preserved as content, not treated as closers.

**What is deliberately excluded**:

- Lines with 7+ hashes (`#######`): Not valid in CommonMark; only H1–H6 exist
- HTML headings (`<h2>`): Essentially absent from markdown documentation pages
- Deeply nested blockquotes (`>> ## heading`): The `(?:>\s*)?` prefix matches a single `>` only
- Blockquote setext headings (`> Title` + `> ---`): Excluded in this conservative implementation
- Setext inside fenced code blocks: excluded to avoid treating code samples as structure

### 7.2 Structured Outline Entries

The raw outline string is parsed into structured entries for compaction and filtering. Defined in `src/procontext/outline.py`.

```python
@dataclass(frozen=True)
class OutlineEntry:
    line_number: int      # 1-based line number in the source content
    text: str             # Emitted outline text (original line for ATX/fences; synthetic for setext)
    depth: int | None     # 1 for H1, 2 for H2, ... 6 for H6; None for fence lines
    is_fence: bool        # True for fence opener/closer
    in_fence: bool        # True if this entry is inside a fenced code block
```

`parse_outline_entries(outline_string: str) -> list[OutlineEntry]` parses the cached `"<lineno>:<emitted outline text>"` format into structured entries in a single pass:

1. Split the outline string by newlines
2. For each line, extract `line_number` by splitting on the first `:`
3. Determine `is_fence` by matching `_FENCE_RE` against the text
4. Determine `depth` by reusing the parser's fence-aware heading matcher and counting `#` characters; `None` for fence lines and non-heading content
5. Track fence state using CommonMark rules: when a fence opener is seen, record its character (`` ` `` or `~`) and length. A closer must use the same character and be at least as long. This enables `in_fence` tagging on each entry.

### 7.3 Empty Fence Stripping

`strip_empty_fences(entries: list[OutlineEntry]) -> list[OutlineEntry]`

Pre-processing step used by both compaction (read_page, search_page) and the read_outline tool. Fence markers exist in the outline solely to disambiguate headings inside code blocks from structural headings. Fence pairs that contain zero heading entries add no navigational value and are removed.

Algorithm: single pass, tracking fence opener positions. When a closer is found, check if any heading entries exist between the opener and closer. If none, remove the opener, closer, and any entries between them (there shouldn't be any, but guard against it).

### 7.4 Outline Compaction

`compact_outline(entries: list[OutlineEntry], *, max_entries: int = 50, max_chars: int = 4000) -> list[OutlineEntry] | None`

Progressive reduction applied to the outline for `read_page` and `search_page` responses. Both constraints are active: compaction continues until entry count ≤ `max_entries` **AND** formatted string length ≤ `max_chars`. Removes entries in priority order, stopping as soon as both constraints are satisfied:

1. Remove entries where `depth == 6` (H6 headings)
2. Remove entries where `depth == 5` (H5 headings)
3. Remove all entries where `in_fence == True` (headings inside fenced blocks) and their enclosing fence markers
4. Remove entries where `depth == 4` (H4 headings)
5. Remove entries where `depth == 3` (H3 headings)

After each stage, the formatted outline is checked against both constraints via `_formatted_outline_size(entries)`, which counts characters in the `"<lineno>:<text>"` format. If both constraints are satisfied, compaction stops.

If the entry count still exceeds `max_entries` OR the formatted string exceeds `max_chars` after all reductions (only H1/H2 remain), returns `None`. The caller renders a status message: `"[Outline too large (N entries). Use read_outline for paginated access.]"`

These limits are configurable via `settings.outline.max_entries` and `settings.outline.max_chars` (defaults: 50 entries, 4000 characters).

### 7.5 Match-Range Trimming

`trim_outline_to_range(entries: list[OutlineEntry], first_line: int, last_line: int) -> list[OutlineEntry]`

Used by `search_page` before compaction. Filters entries to those with `line_number` between `first_line` and `last_line` (inclusive). When zero matches are found, the caller skips trimming and compaction entirely and returns an empty outline string.

### 7.6 Formatting

`format_outline(entries: list[OutlineEntry]) -> str`

Converts structured entries back to the `"<lineno>:<text>"` format, joined by newlines. Used at the output boundary for all tools that return outline content.

---

## 7A. Search

The search module is used exclusively by `search_page`. It compiles a search pattern from the tool input parameters and scans page content line by line. Defined in `src/procontext/search.py`.

### 7A.1 Pattern Compilation

```python
import re

def build_matcher(
    query: str,
    mode: Literal["literal", "regex"],
    case_mode: Literal["smart", "insensitive", "sensitive"],
    whole_word: bool,
) -> re.Pattern[str]:
    if mode == "literal":
        pattern = re.escape(query)
    else:
        pattern = query  # raw regex — validated at search time, not input time

    if whole_word:
        pattern = rf"\b{pattern}\b"

    flags = 0
    if case_mode == "insensitive":
        flags = re.IGNORECASE
    elif case_mode == "smart":
        if query == query.lower():
            flags = re.IGNORECASE
    # case_mode == "sensitive": no flags

    return re.compile(pattern, flags)
```

**Regex validation**: Invalid regex patterns are caught by `re.compile` raising `re.error`. This is caught at search time (not input validation time) and raised as `ProContextError(code=ErrorCode.INVALID_INPUT)`. This avoids adding latency to input validation by attempting pattern compilation before the page fetch.

**ReDoS protection**: Query length is capped at 200 characters in `SearchPageInput`. This limits the complexity of regex patterns. Catastrophic backtracking patterns typically require longer input.

### 7A.2 Line Scanning

```python
def search_lines(
    content: str,
    matcher: re.Pattern[str],
    offset: int,
    max_results: int,
) -> tuple[list[LineMatch], bool, int | None]:
    """Scan content lines from offset, return matches, has_more flag, and next_offset.

    Returns:
        (matches, has_more, next_offset)
    """
    lines = content.splitlines()
    matches: list[LineMatch] = []

    for lineno, line in enumerate(lines, start=1):
        if lineno < offset:
            continue
        if matcher.search(line):
            matches.append(LineMatch(line_number=lineno, content=line))
            if len(matches) == max_results:
                # Check if there are more matches
                for remaining_lineno, remaining_line in enumerate(
                    lines[lineno:], start=lineno + 1
                ):
                    if matcher.search(remaining_line):
                        return matches, True, lineno + 1
                return matches, False, None

    return matches, False, None
```

Stateless single-pass scan. No index, no pre-processing — the page content is already in memory from the cache read. For typical documentation pages (hundreds to low thousands of lines), a linear scan completes in under 1ms.

---

## 8. Transport Layer

### 8.1 stdio Transport

FastMCP handles stdio transport natively. The server runs as a subprocess spawned by the MCP client.

`AppState` is created in a lifespan context manager (`mcp/lifespan.py`) and flows into tool handlers via FastMCP's `Context` object. Tool business logic lives in `src/procontext/tools/` — `mcp/server.py` only registers and dispatches.

```python
# src/procontext/mcp/server.py
from contextlib import asynccontextmanager
from mcp.server.fastmcp import FastMCP, Context
from procontext.state import AppState
import procontext.tools.resolve_library as t_resolve
import procontext.tools.read_page as t_read_page
import procontext.tools.search_page as t_search_page

@asynccontextmanager
async def lifespan(server: FastMCP):
    state = await _create_app_state()
    yield state                    # accessible as ctx.request_context.lifespan_context
    await state.http_client.aclose()

mcp = FastMCP("procontext", lifespan=lifespan)

@mcp.tool()
async def resolve_library(query: str, ctx: Context) -> dict:
    state: AppState = ctx.request_context.lifespan_context
    return await t_resolve.handle(query, state)

@mcp.tool()
async def read_page(
    url: str,
    ctx: Context,
    offset: int = 1,
    limit: int = 500,
    before: int = 0,
) -> dict:
    state: AppState = ctx.request_context.lifespan_context
    return await t_read_page.handle(url, offset, limit, state, before=before)

@mcp.tool()
async def search_page(url: str, query: str, ctx: Context) -> dict:
    state: AppState = ctx.request_context.lifespan_context
    return await t_search_page.handle(url, query, ctx, state)

def main() -> None:
    mcp.run()   # defaults to stdio; HTTP mode handled via config
```

### 8.2 HTTP Transport

Implements MCP Streamable HTTP (spec 2025-11-25). A single `/mcp` endpoint handles both POST (JSON-RPC requests) and GET (SSE event streams). Session state is tracked via `MCP-Session-Id` header.

**Security middleware** runs before the MCP handler on every request.

Implemented as a **pure ASGI middleware** (not `BaseHTTPMiddleware`) so that SSE streaming responses from the MCP endpoint are never buffered by the middleware layer:

```python
from starlette.datastructures import Headers
from starlette.responses import Response
from starlette.types import ASGIApp, Receive, Scope, Send
import ipaddress
import secrets
from urllib.parse import urlparse

SUPPORTED_PROTOCOL_VERSIONS = frozenset({"2025-11-25", "2025-03-26"})

def _is_loopback_origin(origin: str) -> bool:
    parsed = urlparse(origin)
    if parsed.scheme not in {"http", "https"}:
        return False
    if parsed.params or parsed.query or parsed.fragment:
        return False
    hostname = parsed.hostname
    if hostname == "localhost":
        return True
    if hostname is None:
        return False
    try:
        return ipaddress.ip_address(hostname).is_loopback
    except ValueError:
        return False

class MCPSecurityMiddleware:
    def __init__(self, app: ASGIApp, *, auth_enabled: bool, auth_key: str | None = None):
        self.app = app
        self.auth_enabled = auth_enabled
        self.auth_key = auth_key

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "http":
            headers = Headers(scope=scope)

            # 1. Optional bearer key authentication
            if self.auth_enabled:
                auth_header = headers.get("authorization", "")
                if not auth_header.startswith("Bearer ") or auth_header[7:] != self.auth_key:
                    await Response("Unauthorized", status_code=401)(scope, receive, send)
                    return

            # 2. Origin validation — prevents DNS rebinding attacks
            origin = headers.get("origin", "")
            if origin and not _is_loopback_origin(origin):
                await Response("Forbidden", status_code=403)(scope, receive, send)
                return

            # 3. Protocol version — reject unknown versions early
            proto_version = headers.get("mcp-protocol-version", "")
            if proto_version and proto_version not in SUPPORTED_PROTOCOL_VERSIONS:
                await Response(
                    f"Unsupported protocol version: {proto_version}",
                    status_code=400,
                )(scope, receive, send)
                return

        await self.app(scope, receive, send)
```

**Authentication mode**:

- If `server.auth_enabled` is `true`, bearer-key authentication is enforced.
- If `server.auth_enabled` is `true` and `server.auth_key` is empty, the server generates a key at startup (`secrets.token_urlsafe(32)`) and logs it to stderr. The key is **not persisted to disk** — a new key is generated on every server restart. This is intentional: persistence would require file-permission and encryption-at-rest decisions that exceed the scope of this lightweight access control. MCP clients read the key from the server's startup log output and reconnect after a restart.
- If `server.auth_enabled` is `false` (default), authentication is disabled and the server logs a startup warning (regardless of host/bind address).

**Server startup** for HTTP mode:

```python
import uvicorn

def run_http_server(mcp: FastMCP, settings: Settings) -> None:
    # Logging is already configured by main() before this is called.
    http_log = log.bind(transport="http")
    auth_key: str | None = settings.server.auth_key or None

    if settings.server.auth_enabled and not auth_key:
        auth_key = secrets.token_urlsafe(32)
        http_log.warning("http_auth_key_auto_generated", auth_key=auth_key)

    if not settings.server.auth_enabled:
        http_log.warning("http_auth_disabled")

    # mcp.streamable_http_app() returns a Starlette ASGI app with the FastMCP
    # lifespan already wired in.  Wrap it directly — no add_middleware() needed.
    http_app = mcp.streamable_http_app()
    secured_app = MCPSecurityMiddleware(
        http_app,
        auth_enabled=settings.server.auth_enabled,
        auth_key=auth_key,
    )

    uvicorn.run(
        secured_app,
        host=settings.server.host,
        port=settings.server.port,
        log_config=None,         # Disable uvicorn's default logging; structlog handles it
    )
```

---

## 8A. CLI

The CLI is a thin `argparse` dispatcher in `cli/main.py` that routes to per-command modules. Each command module is self-contained — one public function, one file. The MCP server is not imported unless the default (serve) command is selected.

### 8A.1 Dispatcher

```python
# cli/main.py — simplified
parser = argparse.ArgumentParser(prog="procontext")
sub = parser.add_subparsers(dest="command")
sub.add_parser("setup")
doctor_parser = sub.add_parser("doctor")
doctor_parser.add_argument("--fix", action="store_true")
db_parser = sub.add_parser("db")
db_sub = db_parser.add_subparsers(dest="db_command")
db_sub.required = True
db_sub.add_parser("recreate")

if args.command == "setup":
    from procontext.cli.cmd_setup import run_setup
    asyncio.run(run_setup(settings))
elif args.command == "doctor":
    from procontext.cli.cmd_doctor import run_doctor
    asyncio.run(run_doctor(settings, fix=args.fix))
elif args.command == "db":
    from procontext.cli.cmd_db import run_db_recreate
    if args.db_command == "recreate":
        asyncio.run(run_db_recreate(settings))
else:
    from procontext.cli.cmd_serve import run_server
    run_server(settings)
```

Command modules are imported inside the `if/elif/else` branches to avoid loading unnecessary dependencies. `procontext doctor` does not import the MCP SDK; `procontext setup` does not import `aiosqlite`. Within `cmd_serve.py`, the project HTTP transport wrapper (`http_transport.py`) is imported only inside the HTTP branch, so stdio startup avoids loading ProContext's HTTP-specific middleware/wiring unless HTTP mode is explicitly selected. CLI commands use `print()` for user-facing output (stdout) and `structlog` for operational logs (stderr).

| Command | Module | Dependencies loaded |
|---------|--------|---------------------|
| _(default)_ | `cmd_serve.py` | MCP SDK, FastMCP, stdio server stack; ProContext's HTTP transport wrapper loads only when `transport=http` |
| `setup` | `cmd_setup.py` | httpx, registry |
| `doctor` | `cmd_doctor.py` | aiosqlite, httpx |
| `db recreate` | `cmd_db.py` | aiosqlite |

**Legacy shim**: `mcp/startup.py` delegates to `cli.main:main` for backward compatibility with `python -m procontext.mcp.startup`.

### 8A.2 Doctor Command

`procontext doctor` runs five sequential health checks and reports results. Each check is an independent async function with signature `async def check_*(settings, *, fix=False) -> CheckResult`.

**Checks (in order)**:

1. **Data directory** — existence, read/write/execute permissions, registry subdirectory
2. **Registry** — files present, JSON parseable, checksum matches state file
3. **Registry additional info** — optional `additional-info.json` present and checksum-valid when advertised by `registry-state.json`; missing/invalid sidecar is a warning, not a failure
4. **Cache database** — parent directory writable, SQLite openable, WAL mode, schema matches expected
5. **Network** — HEAD request to registry metadata URL

**`--fix` behavior**: When a check fails and is fixable, the check attempts repair before returning. Fixable: missing directories (`mkdir`), missing/corrupt registry (re-download), missing/invalid advertised additional-info sidecar (re-download sidecar only), cache journal mode drift (`PRAGMA journal_mode=WAL`), and missing cache tables/columns (create missing tables / `ALTER TABLE ... ADD COLUMN` in place). Not fixable: permission errors, unreadable/corrupt cache databases, incompatible cache column definitions, and network failures. Additional-info repair failures remain warnings. For non-fixable cache problems, doctor suggests the destructive fallback command `procontext db recreate`.

**Auto-derived schema validation**: The cache schema check creates an in-memory SQLite database, runs `Cache.init_db()`, and compares the resulting `PRAGMA table_info` against the on-disk database. This stays in sync with `cache.py` automatically — no separate schema definition to maintain.

See [docs/cli/doctor.md](../cli/doctor.md) for the full design document.

---

## 9. Registry Updates

The registry update system keeps the in-memory library index fresh without interrupting request serving. It is designed around three principles:

1. **Registry availability on disk** — the running server expects a valid local registry pair on disk. `procontext setup` is the explicit bootstrap path; the serve command never bootstraps the registry implicitly.
2. **Cheap polling** — a tiny metadata file is fetched on each poll cycle; the full registry is only downloaded when its checksum changes.
3. **Zero-downtime swap** — new registry data is applied to the live `AppState` atomically while in-flight requests continue using the previous data safely.

---

### 9.1 Registry Files

Three registry artefacts may live on disk:

| Artefact             | Location                                   | Purpose                                                                                          |
| -------------------- | ------------------------------------------ | ------------------------------------------------------------------------------------------------ |
| **Local registry**   | `<data_dir>/registry/known-libraries.json` | Downloaded by `procontext setup` and updated by the background scheduler.                        |
| **Local state file** | `<data_dir>/registry/registry-state.json`  | Stores `version`, `sha256` checksum, `updated_at`, `last_checked_at`, and optional additional-info metadata for the local registry. |
| **Additional info**  | `<data_dir>/registry/additional-info.json` | Optional sidecar containing `useful_md_probe_base_urls`, which gates `.md` probing by exact normalized origin. |

`<data_dir>` defaults to `platformdirs.user_data_dir("procontext")` and can be overridden via `PROCONTEXT__DATA_DIR`.

`registry-state.json` format:

```json
{
  "version": "2026-02-24",
  "checksum": "sha256:abc123...",
  "updated_at": "2026-02-24T07:10:00Z",
  "last_checked_at": "2026-02-25T08:00:00Z",
  "additional_info_download_url": "https://registry.example/additional-info.json",
  "additional_info_checksum": "sha256:def456..."
}
```

- `updated_at` — set only when a new registry version is actually downloaded and persisted.
- `last_checked_at` — set after every successful update check, even when the registry is already current. Used by both transports to gate checks: if the gap between now and `last_checked_at` is less than `registry.poll_interval_hours`, the startup check (stdio) or first poll (HTTP) is skipped to avoid redundant metadata fetches on frequent restarts or immediately after `procontext setup`.
- `additional_info_download_url` / `additional_info_checksum` — optional metadata advertising the registry additional-info sidecar. The sidecar is fetched best-effort during setup and background update checks. Failure to fetch or validate it never fails the main registry update; runtime `.md` probing is simply disabled until a valid local sidecar is available again.

The local registry pair (both files together) is the consistency unit. If either file is missing, cannot be parsed, or the checksum in the state file does not match `sha256(known-libraries.json)`, the pair is considered invalid and the server treats it as if no registry exists.

---

### 9.2 `procontext setup`

`procontext setup` is the explicit first-time bootstrap command for downloading the local registry pair:

```
procontext setup
# or
uvx procontext setup
```

It fetches the registry metadata, downloads the full registry, validates the checksum, and saves the local registry pair to `<data_dir>/registry/`. When the metadata also advertises `additional_info_download_url` and `additional_info_checksum`, setup attempts to download `<data_dir>/registry/additional-info.json` as well. Failure to fetch or validate that sidecar does not fail setup.

`setup` uses the same split HTTP timeout as all registry fetches: **5s to connect** (fail fast if unreachable), **5 minutes to read** (patient once the transfer has started).

---

### 9.3 Startup Sequence

```
1. Try to load local registry pair from <data_dir>/registry/
      Both files must exist, parse, and pass checksum validation.
      On success → proceed to step 3.

2. If local pair is missing or invalid →
      Exit with:
        "Registry not initialised. Run 'procontext setup' to download the registry."

3. Build in-memory indexes (RegistryIndexes) and SSRF allowlist from loaded data.
   Server is now ready to handle requests.

4. Spawn background task:
      stdio  → run_registry_startup_check()   (runs once, consults last_checked_at)
      HTTP   → run_registry_update_scheduler() (infinite loop, consults last_checked_at
                                                before first poll)
```

---

### 9.4 Two-URL Design

The update check uses two separate URLs:

- **`registry.metadata_url`** — a tiny JSON file (`~200 bytes`) containing the current `version`, `checksum`, and `download_url`. Fetched on every poll cycle.
- **`download_url`** (from metadata) — the full registry JSON (potentially hundreds of KB). Fetched only when the remote `version` differs from the local one.

This split means that on a typical poll cycle where the registry has not changed, only the small metadata file is fetched. The full registry download is triggered only when there is actually an update — reducing outbound traffic significantly in long-running HTTP deployments.

All registry HTTP requests use a **split timeout**: 5s to connect (fail fast if unreachable), 5 minutes to read (patient once the transfer has started). This avoids cutting off large downloads on slow networks while still failing quickly when the registry host is unreachable.

```
Poll cycle:
  GET metadata_url → { version, checksum, download_url }
       │
       ├─ version == local_version  → return "success" (no download needed)
       │
       └─ version != local_version  → GET download_url
                                           │
                                           ├─ sha256(body) == checksum → apply update
                                           └─ sha256(body) != checksum → return "semantic_failure"
```

---

### 9.5 Outcome Classification

`check_for_registry_update()` returns one of three outcomes, which the scheduler uses to decide the next sleep interval:

| Outcome               | Meaning                                                        | Examples                                                        |
| --------------------- | -------------------------------------------------------------- | --------------------------------------------------------------- |
| `"success"`           | Registry is up to date or was successfully updated             | Version match, clean download + checksum pass                   |
| `"transient_failure"` | Recoverable infrastructure problem — retry with backoff        | Network timeout, DNS failure, upstream 5xx/408/429              |
| `"semantic_failure"`  | Non-recoverable data problem — retrying immediately won't help | Invalid metadata shape, checksum mismatch, schema parse failure |

Transient failures are retried aggressively with exponential backoff. Semantic failures skip backoff and return to the normal poll cadence — the assumption is that a malformed registry is a publisher-side bug that will be fixed before the next scheduled check.

---

### 9.6 Background Update Check

`check_for_registry_update(state)` in `registry/update.py` (re-exported by `procontext.registry`) follows these steps:

1. Fetch `metadata_url`. Network error or 5xx/408/429 → `"transient_failure"`.
2. Parse and validate metadata fields (`version`, `checksum`, `download_url`). Invalid shape → `"semantic_failure"`.
3. Short-circuit if `remote_version == state.registry_version` → `"success"`.
4. Fetch the full registry from `download_url`. Network error → `"transient_failure"`.
5. Validate `sha256(body) == expected_checksum`. Mismatch → `"semantic_failure"`.
6. Parse registry entries. Schema error → `"semantic_failure"`.
7. Rebuild indexes and allowlist, swap atomically into `AppState` (see §9.7).
8. Persist pair to disk (non-fatal on failure, see §9.8).
9. Return `"success"`.

---

### 9.7 In-Memory Hot-Swap

When a registry update is applied (step 7 above), three `AppState` attributes are replaced simultaneously:

- `state.indexes` — the new `RegistryIndexes` (all lookup maps rebuilt from the new entries)
- `state.allowlist` — new `frozenset[str]` built from the new registry entries + `extra_allowed_domains`
- `state.registry_version` — updated to the remote version string

**Why this is safe without a lock:**

Both `RegistryIndexes` and `frozenset` are immutable once constructed. Python's GIL makes the combined attribute assignment effectively atomic at the interpreter level. Any request already in-flight that holds a reference to the old `state.allowlist` or `state.indexes` continues to work against those objects for the duration of that request — the objects themselves never change. New requests arriving after the assignment pick up the fresh data immediately.

The allowlist is always reset to the registry baseline on each successful update. Any domains that were dynamically expanded at runtime (via `allowlist_expansion = "discovered"`) are not carried forward into the new allowlist — they will be re-accumulated as pages are fetched under the new registry. Domains stored in the `discovered_domains` cache column are restored at the next server restart via `load_discovered_domains()`.

---

### 9.8 Atomic Persistence of Local Registry Pair

`save_registry_to_disk()` in `registry/storage.py` (re-exported by `procontext.registry`) writes both files with crash-safe semantics using write-to-temp-then-rename: each file is written and fsynced to a `.tmp` sibling, then renamed into place with `os.replace()`, followed by an fsync on the parent directory. Temp files are cleaned up in a `finally` block.

Crash-safety guarantees:

| Failure point                                    | Effect on disk                | Next startup behaviour                            |
| ------------------------------------------------ | ----------------------------- | ------------------------------------------------- |
| Crash during temp write                          | Destination files untouched   | Load previous valid pair                          |
| Crash after registry rename, before state rename | Registry updated, state stale | Checksum mismatch → exit with error; operator reruns `procontext setup` or `procontext doctor --fix` |
| Crash after both renames                         | Both files updated            | Load new pair normally                            |

`_fsync_directory()` is a no-op on Windows (`sys.platform == "win32"` guard) since Windows does not support `fsync` on directory handles. The write-then-rename guarantee still holds; only the directory entry durability is weaker.

---

### 9.9 Scheduling Policy

Registry update checks run differently depending on transport mode:

**stdio mode** — checks once at startup if `registry_check_is_due()` returns True, then exits. The process is typically short-lived (one agent session), so a polling loop would be wasteful.

**HTTP mode** — loops indefinitely. Before the first check, consults `registry_check_is_due()`: if the registry was checked recently (e.g. `procontext setup` just ran), sleeps for `poll_interval_hours` before the first check; otherwise checks immediately. The poll interval after a successful check is controlled by `registry.poll_interval_hours` (default 24h, configurable). Transient failures are retried with exponential backoff; semantic failures return to the normal poll cadence without backoff.

Backoff parameters (currently hardcoded, not configurable):

- `INITIAL_BACKOFF = 60s`
- `MAX_BACKOFF = 3600s`
- `MAX_TRANSIENT_BACKOFF_ATTEMPTS = 8`
- jitter: `backoff × random.uniform(0.8, 1.2)` — prevents thundering herd if multiple instances share the same registry URL

If consecutive transient failures reach `MAX_TRANSIENT_BACKOFF_ATTEMPTS`, the circuit breaker fires: the failure counter and backoff are reset, and the scheduler sleeps for the full `poll_interval_hours` before trying again.

```
Outcome → sleep before next attempt
─────────────────────────────────────────────────────────
success                          poll_interval_hours × 3600
semantic_failure                 poll_interval_hours × 3600
transient (attempt < 8)          backoff × jitter  (then backoff doubles)
transient (attempt = 8, reset)   poll_interval_hours × 3600
```

---

## 10. Configuration

Configuration is loaded from `procontext.yaml` (searched in current directory, then the platform config directory via `platformdirs.user_config_dir("procontext")`). All values have defaults — the config file is optional.

```yaml
data_dir: "" # default: platformdirs.user_data_dir("procontext"); registry path root; override via PROCONTEXT__DATA_DIR

server:
  transport: stdio # stdio | http
  host: "127.0.0.1" # HTTP mode only
  port: 8080 # HTTP mode only
  auth_enabled: false # HTTP mode only — default false
  auth_key: "" # HTTP mode only — used only when auth_enabled=true; if empty, auto-generated at startup

registry:
  metadata_url: "https://procontexthq.github.io/registry_metadata.json"
  poll_interval_hours: 24 # How often to check for a new registry version

cache:
  ttl_hours: 24
  # db_path: platform-specific default via platformdirs.user_data_dir("procontext") / "cache.db" (independent from data_dir override)
  cleanup_interval_hours: 6

fetcher:
  ssrf_private_ip_check: true # block private/internal IPs; strongly recommended
  ssrf_domain_check: true # enforce domain allowlist; set false only in isolated environments
  allowlist_expansion: "registry" # "registry" = fixed at startup | "discovered" = expand from fetched content
  extra_allowed_domains: # always trusted, merged at startup regardless of depth
    - github.com
    - githubusercontent.com
  connect_timeout_seconds: 5.0 # TCP connection timeout; fail fast so .md probes fall back quickly
  request_timeout_seconds: 30.0 # per-request read timeout for documentation fetches

resolver:
  fuzzy_score_cutoff: 70 # minimum rapidfuzz score (0–100) for a fuzzy match to count
  fuzzy_max_results: 5 # maximum number of fuzzy candidates returned

outline:
  max_entries: 50 # maximum entry count in compacted outlines (read_page, search_page)
  max_chars: 4000 # maximum character count in compacted outlines (as formatted string)

logging:
  level: INFO # DEBUG | INFO | WARNING | ERROR
  format: json # json | text (text for local dev)
```

Loaded via pydantic-settings:

```python
from typing import Any, Literal
from pydantic import BaseModel
from pydantic_settings import (
    BaseSettings,
    PydanticBaseSettingsSource,
    SettingsConfigDict,
    YamlConfigSettingsSource,
)

class ServerSettings(BaseModel):
    transport: Literal["stdio", "http"] = "stdio"
    host: str = "127.0.0.1"
    port: int = 8080
    auth_enabled: bool = False  # HTTP mode only — default false
    auth_key: str = ""  # HTTP mode only — used when auth_enabled=true; if empty, auto-generated

class RegistrySettings(BaseModel):
    metadata_url: str = "https://procontexthq.github.io/registry_metadata.json"
    poll_interval_hours: int = 24

class CacheSettings(BaseModel):
    ttl_hours: int = 24
    db_path: str = _DEFAULT_DB_PATH  # platformdirs.user_data_dir("procontext") / "cache.db" (independent from data_dir override)
    cleanup_interval_hours: int = 6

class FetcherSettings(BaseModel):
    ssrf_private_ip_check: bool = True
    ssrf_domain_check: bool = True
    allowlist_expansion: Literal["registry", "discovered"] = "registry"
    extra_allowed_domains: list[str] = ["github.com", "githubusercontent.com"]
    connect_timeout_seconds: float = 5.0
    request_timeout_seconds: float = 30.0

class ResolverSettings(BaseModel):
    fuzzy_score_cutoff: int = 70
    fuzzy_max_results: int = 5

class OutlineSettings(BaseModel):
    max_entries: int = 50 # maximum entry count in compacted outlines
    max_chars: int = 4000 # maximum character count in compacted outlines

class LoggingSettings(BaseModel):
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    format: Literal["json", "text"] = "json"

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        # Double-underscore prefix keeps env vars visually consistent:
        # all separators are __ e.g. PROCONTEXT__SERVER__PORT=9090
        env_prefix="PROCONTEXT__",
        env_nested_delimiter="__",
        yaml_file=_find_config_file(),   # Returns first existing path or None
        yaml_file_encoding="utf-8",
    )

    data_dir: str = _DEFAULT_DATA_DIR  # platformdirs.user_data_dir("procontext")
    server: ServerSettings = ServerSettings()
    registry: RegistrySettings = RegistrySettings()
    cache: CacheSettings = CacheSettings()
    fetcher: FetcherSettings = FetcherSettings()
    resolver: ResolverSettings = ResolverSettings()
    outline: OutlineSettings = OutlineSettings()
    logging: LoggingSettings = LoggingSettings()

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        **kwargs: Any,
    ) -> tuple[PydanticBaseSettingsSource, ...]:
        return (
            init_settings,                         # Constructor args (highest priority)
            env_settings,                          # Environment variables
            YamlConfigSettingsSource(settings_cls),
        )
```

`_find_config_file()` searches `procontext.yaml` in the current directory first, then the platform config directory (`platformdirs.user_config_dir("procontext")`), returning the first path that exists or `None` (config file is optional). Environment variables use the prefix `PROCONTEXT__` with `__` as the nested delimiter (e.g., `PROCONTEXT__SERVER__PORT=9090`, `PROCONTEXT__SERVER__AUTH_ENABLED=true`, `PROCONTEXT__CACHE__TTL_HOURS=48`, `PROCONTEXT__OUTLINE__MAX_CHARS=8000`).

---

## 11. Logging

Structured logging via structlog. All log entries are JSON in production, human-readable text in development (`log_format = "text"`).

```python
import structlog

log = structlog.get_logger()

# Per-request context binding
async def search_page_handler(url: str, query: str, state: AppState) -> dict:
    url_hash = sha256_hex(url)
    log = structlog.get_logger().bind(tool="search_page", url_hash=url_hash)

    log.info("cache_check")
    page = await state.cache.get_page(url_hash)

    if page is not None and not page.stale:
        log.info("cache_hit")
    elif page is not None:
        log.info("cache_hit_stale")
    else:
        log.info("cache_miss_fetching", url=url)
        content = await state.fetcher.fetch(url, state.allowlist)
        log.info("fetch_complete", content_length=len(content))
        ...
```

**Key log events and their fields**:

| Event                         | Fields                                                                               |
| ----------------------------- | ------------------------------------------------------------------------------------ |
| `server_started`              | `transport`, `version`, `registry_entries`, `registry_version`                       |
| `registry_loaded`             | `source` (`disk`), `version`, `entries`, `path` — `version` comes from `registry-state.json` |
| `registry_updated`            | `version`, `entries`                                                                 |
| `registry_local_pair_invalid` | `reason`, `path_registry`, `path_state`                                              |
| `registry_persist_failed`     | `version`, `error`                                                                   |
| `cache_hit`                   | `tool`, `library_id` or `url_hash`                                                   |
| `cache_miss_fetching`         | `tool`, `url`                                                                        |
| `fetch_complete`              | `url`, `status_code`, `content_length`                                               |
| `fetch_failed`                | `url`, `error`, `status_code`                                                        |
| `ssrf_blocked`                | `url`, `reason`                                                                      |
| `stale_refresh_started`       | `url`                                                                                |
| `stale_refresh_complete`      | `url`                                                                                |
| `stale_refresh_failed`        | `url`, `error`                                                                       |
| `stale_refresh_skipped`       | `url`, `reason` (`already_in_flight` or `cooldown`)                                  |
| `cache_read_error`            | `key`                                                                                |
| `cache_write_error`           | `key`                                                                                |
