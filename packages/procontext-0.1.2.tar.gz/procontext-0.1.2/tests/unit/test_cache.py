"""Unit tests for procontext.cache."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING

import aiosqlite

if TYPE_CHECKING:
    from procontext.cache import Cache


# ---------------------------------------------------------------------------
# Page cache
# ---------------------------------------------------------------------------


class TestPageCache:
    async def test_set_and_get_fresh(self, cache: Cache) -> None:
        await cache.set_page(
            url="https://example.com/docs/page1",
            url_hash="abc123",
            content="# Page 1",
            outline="1:# Page 1",
            ttl_hours=24,
        )
        entry = await cache.get_page("abc123")
        assert entry is not None
        assert entry.url == "https://example.com/docs/page1"
        assert entry.url_hash == "abc123"
        assert entry.content == "# Page 1"
        assert entry.outline == "1:# Page 1"
        assert entry.stale is False

    async def test_get_nonexistent_returns_none(self, cache: Cache) -> None:
        entry = await cache.get_page("nonexistent-hash")
        assert entry is None

    async def test_corrupted_fetched_at_returns_none(self, cache: Cache) -> None:
        """A non-ISO timestamp in fetched_at raises ValueError — must be caught, not crash."""
        future = (datetime.now(UTC) + timedelta(hours=24)).isoformat()
        await cache._db.execute(
            "INSERT INTO page_cache "
            "(url_hash, url, content, outline, discovered_domains, fetched_at, expires_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            ("bad-hash", "https://example.com/page", "Content", "", "", "not-a-date", future),
        )
        await cache._db.commit()

        entry = await cache.get_page("bad-hash")
        assert entry is None

    async def test_expired_entry_returns_stale(self, cache: Cache) -> None:
        await cache.set_page(
            url="https://example.com/docs/old",
            url_hash="old-hash",
            content="Old content",
            outline="",
            ttl_hours=0,
        )
        past = (datetime.now(UTC) - timedelta(hours=1)).isoformat()
        await cache._db.execute(
            "UPDATE page_cache SET expires_at = ? WHERE url_hash = ?",
            (past, "old-hash"),
        )
        await cache._db.commit()

        entry = await cache.get_page("old-hash")
        assert entry is not None
        assert entry.stale is True

    async def test_discovered_domains_persisted(self, cache: Cache) -> None:
        domains = frozenset({"foo.com", "bar.io"})
        await cache.set_page(
            url="https://example.com/docs/page1",
            url_hash="h1",
            content="# Page",
            outline="1:# Page",
            ttl_hours=24,
            discovered_domains=domains,
        )
        entry = await cache.get_page("h1")
        assert entry is not None
        assert entry.discovered_domains == domains

    async def test_discovered_domains_defaults_empty(self, cache: Cache) -> None:
        await cache.set_page(
            url="https://example.com/docs/page2",
            url_hash="h2",
            content="# Page",
            outline="",
            ttl_hours=24,
        )
        entry = await cache.get_page("h2")
        assert entry is not None
        assert entry.discovered_domains == frozenset()

    async def test_upsert_overwrites(self, cache: Cache) -> None:
        await cache.set_page(
            url="https://example.com/docs/page",
            url_hash="h1",
            content="Version 1",
            outline="",
            ttl_hours=24,
        )
        await cache.set_page(
            url="https://example.com/docs/page",
            url_hash="h1",
            content="Version 2",
            outline="",
            ttl_hours=24,
        )
        entry = await cache.get_page("h1")
        assert entry is not None
        assert entry.content == "Version 2"

    async def test_read_failure_returns_none(self, cache: Cache) -> None:
        """Simulate a database read error — should return None, not raise."""
        original_execute = cache._db.execute

        async def failing_execute(*args, **kwargs):
            raise aiosqlite.OperationalError("disk I/O error")

        cache._db.execute = failing_execute  # type: ignore[assignment]
        entry = await cache.get_page("some-hash")
        assert entry is None
        cache._db.execute = original_execute  # type: ignore[assignment]

    async def test_write_failure_does_not_raise(self, cache: Cache) -> None:
        """Simulate a database write error — should not raise."""
        original_execute = cache._db.execute

        async def failing_execute(*args, **kwargs):
            raise aiosqlite.OperationalError("disk I/O error")

        cache._db.execute = failing_execute  # type: ignore[assignment]
        await cache.set_page(
            url="https://example.com/page",
            url_hash="h1",
            content="Content",
            outline="",
            ttl_hours=24,
        )
        cache._db.execute = original_execute  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# cleanup_expired
# ---------------------------------------------------------------------------


async def _insert_expired_page(cache: Cache, url_hash: str, days_ago: int = 8) -> None:
    """Helper: insert a page_cache entry whose expires_at is days_ago days in the past."""
    expiry = (datetime.now(UTC) - timedelta(days=days_ago)).isoformat()
    now = datetime.now(UTC).isoformat()
    await cache._db.execute(
        "INSERT INTO page_cache "
        "(url_hash, url, content, outline, discovered_domains, fetched_at, expires_at) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (url_hash, f"https://example.com/{url_hash}", "Content", "", "", now, expiry),
    )
    await cache._db.commit()


class TestCleanupExpired:
    async def test_cleanup_deletes_old_page_entries(self, cache: Cache) -> None:
        """Page entries expired more than 7 days ago should be deleted."""
        await _insert_expired_page(cache, "old-hash")

        await cache.cleanup_expired()

        entry = await cache.get_page("old-hash")
        assert entry is None

    async def test_cleanup_preserves_recent_expired(self, cache: Cache) -> None:
        """Entries expired within the 7-day grace period should be kept."""
        await _insert_expired_page(cache, "recent-hash", days_ago=2)

        await cache.cleanup_expired()

        entry = await cache.get_page("recent-hash")
        assert entry is not None

    async def test_cleanup_failure_does_not_raise(self, cache: Cache) -> None:
        """Simulate a database error during cleanup — should not raise."""
        original_execute = cache._db.execute

        async def failing_execute(*args, **kwargs):
            raise aiosqlite.OperationalError("disk I/O error")

        cache._db.execute = failing_execute  # type: ignore[assignment]
        # Should not raise
        await cache.cleanup_expired()
        cache._db.execute = original_execute  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# load_discovered_domains
# ---------------------------------------------------------------------------


class TestLoadDiscoveredDomains:
    async def test_loads_page_domains(self, cache: Cache) -> None:
        await cache.set_page(
            url="https://example.com/page",
            url_hash="h1",
            content="# Page",
            outline="",
            ttl_hours=24,
            discovered_domains=frozenset({"foo.com"}),
        )
        result = await cache.load_discovered_domains()
        assert "foo.com" in result

    async def test_merges_domains_from_multiple_pages(self, cache: Cache) -> None:
        await cache.set_page(
            url="https://example.com/page1",
            url_hash="h1",
            content="# Page 1",
            outline="",
            ttl_hours=24,
            discovered_domains=frozenset({"alpha.com"}),
        )
        await cache.set_page(
            url="https://example.com/page2",
            url_hash="h2",
            content="# Page 2",
            outline="",
            ttl_hours=24,
            discovered_domains=frozenset({"beta.io"}),
        )
        result = await cache.load_discovered_domains()
        assert "alpha.com" in result
        assert "beta.io" in result

    async def test_empty_tables_returns_empty(self, cache: Cache) -> None:
        result = await cache.load_discovered_domains()
        assert result == frozenset()

    async def test_skips_entries_with_no_domains(self, cache: Cache) -> None:
        await cache.set_page(
            url="https://example.com/page",
            url_hash="h1",
            content="# Page",
            outline="",
            ttl_hours=24,
        )
        result = await cache.load_discovered_domains()
        assert result == frozenset()

    async def test_failure_returns_empty(self, cache: Cache) -> None:
        """Database errors during load should return empty frozenset, not raise."""
        original_execute = cache._db.execute

        async def failing_execute(*args, **kwargs):
            raise aiosqlite.OperationalError("disk I/O error")

        cache._db.execute = failing_execute  # type: ignore[assignment]
        result = await cache.load_discovered_domains()
        assert result == frozenset()
        cache._db.execute = original_execute  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# cleanup_if_due
# ---------------------------------------------------------------------------


class TestCleanupIfDue:
    async def test_runs_cleanup_when_no_previous_record(self, cache: Cache) -> None:
        """No last_cleanup_at in DB → cleanup runs and timestamp is written."""
        await _insert_expired_page(cache, "old-hash")

        await cache.cleanup_if_due(24)

        entry = await cache.get_page("old-hash")
        assert entry is None
        cursor = await cache._db.execute(
            "SELECT value FROM server_metadata WHERE key = 'last_cleanup_at'"
        )
        assert await cursor.fetchone() is not None

    async def test_skips_when_recently_run(self, cache: Cache) -> None:
        """Recent last_cleanup_at → cleanup is skipped, expired entries untouched."""
        await cache._db.execute(
            "INSERT INTO server_metadata (key, value) VALUES ('last_cleanup_at', ?)",
            (datetime.now(UTC).isoformat(),),
        )
        await cache._db.commit()
        await _insert_expired_page(cache, "old-hash")

        await cache.cleanup_if_due(24)

        # Expired entry should still be there — cleanup was skipped.
        entry = await cache.get_page("old-hash")
        assert entry is not None

    async def test_runs_when_interval_elapsed(self, cache: Cache) -> None:
        """Stale last_cleanup_at → cleanup runs and updates the timestamp."""
        stale = (datetime.now(UTC) - timedelta(hours=25)).isoformat()
        await cache._db.execute(
            "INSERT INTO server_metadata (key, value) VALUES ('last_cleanup_at', ?)",
            (stale,),
        )
        await cache._db.commit()
        await _insert_expired_page(cache, "old-hash")

        await cache.cleanup_if_due(24)

        entry = await cache.get_page("old-hash")
        assert entry is None
        cursor = await cache._db.execute(
            "SELECT value FROM server_metadata WHERE key = 'last_cleanup_at'"
        )
        row = await cursor.fetchone()
        assert row is not None
        # Timestamp should be newer than the stale value we wrote.
        assert datetime.fromisoformat(row[0]) > datetime.fromisoformat(stale)

    async def test_corrupted_last_cleanup_at_falls_through_to_cleanup(self, cache: Cache) -> None:
        """Corrupted last_cleanup_at timestamp raises ValueError — must fall through to cleanup."""
        await cache._db.execute(
            "INSERT INTO server_metadata (key, value) VALUES ('last_cleanup_at', ?)",
            ("not-a-date",),
        )
        await cache._db.commit()
        await _insert_expired_page(cache, "old-hash")

        # Should not raise, and should still run cleanup
        await cache.cleanup_if_due(24)
        entry = await cache.get_page("old-hash")
        assert entry is None

    async def test_metadata_read_error_falls_through_to_cleanup(self, cache: Cache) -> None:
        """aiosqlite.Error reading last_cleanup_at → cleanup still runs (fall-through)."""
        await _insert_expired_page(cache, "old-hash")

        original_execute = cache._db.execute
        call_count = 0

        async def fail_first_call(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                raise aiosqlite.OperationalError("disk error")
            return await original_execute(*args, **kwargs)

        cache._db.execute = fail_first_call  # type: ignore[assignment]
        await cache.cleanup_if_due(24)
        cache._db.execute = original_execute  # type: ignore[assignment]

        entry = await cache.get_page("old-hash")
        assert entry is None
