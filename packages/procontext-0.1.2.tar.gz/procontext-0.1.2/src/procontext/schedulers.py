"""Background scheduler coroutines for registry updates and cache cleanup."""

from __future__ import annotations

import random
from typing import TYPE_CHECKING

import anyio
import structlog

from procontext.registry import (
    REGISTRY_INITIAL_BACKOFF_SECONDS,
    REGISTRY_MAX_BACKOFF_SECONDS,
    REGISTRY_MAX_TRANSIENT_BACKOFF_ATTEMPTS,
    check_for_registry_update,
    registry_check_is_due,
)

if TYPE_CHECKING:
    from procontext.state import AppState

log = structlog.get_logger()


def _jittered_delay(base_seconds: int) -> float:
    return base_seconds * random.uniform(0.8, 1.2)


async def run_cache_startup_cleanup(state: AppState) -> None:
    """stdio mode: run a single cache cleanup pass at startup if one is due."""
    if state.cache is not None:
        await state.cache.cleanup_if_due(state.settings.cache.cleanup_interval_hours)


async def run_cache_cleanup_scheduler(state: AppState) -> None:
    """HTTP mode: run cache cleanup at startup then on a recurring interval."""
    interval_hours = state.settings.cache.cleanup_interval_hours
    if state.cache is not None:
        await state.cache.cleanup_if_due(interval_hours)
    while True:
        await anyio.sleep(interval_hours * 3600)
        if state.cache is not None:
            await state.cache.cleanup_if_due(interval_hours)


async def run_registry_startup_check(state: AppState) -> None:
    """stdio mode: check for a registry update once at startup if one is due."""
    try:
        poll_interval = state.settings.registry.poll_interval_hours
        if registry_check_is_due(state.registry_state_path, poll_interval):
            await check_for_registry_update(state)
    except Exception:
        log.warning("registry_update_scheduler_error", mode="startup_once", exc_info=True)


async def run_registry_update_scheduler(state: AppState) -> None:
    """HTTP mode: poll for registry updates on a configurable interval indefinitely."""
    poll_interval = state.settings.registry.poll_interval_hours
    poll_interval_seconds = poll_interval * 3600
    backoff_seconds = REGISTRY_INITIAL_BACKOFF_SECONDS
    consecutive_transient_failures = 0

    # Delay the first poll if the registry was checked recently (e.g. setup just
    # ran). registry_check_is_due uses last_checked_at, which save_registry_to_disk
    # always writes, so this naturally avoids a redundant fetch on first run.
    try:
        skip_first = not registry_check_is_due(state.registry_state_path, poll_interval)
    except Exception:
        log.warning("registry_update_scheduler_error", mode="http_loop", exc_info=True)
        skip_first = False
    if skip_first:
        await anyio.sleep(poll_interval_seconds)

    while True:
        try:
            outcome = await check_for_registry_update(state)
        except Exception:
            log.warning("registry_update_scheduler_error", mode="http_loop", exc_info=True)
            outcome = "semantic_failure"

        if outcome == "success":
            consecutive_transient_failures = 0
            backoff_seconds = REGISTRY_INITIAL_BACKOFF_SECONDS
            await anyio.sleep(poll_interval_seconds)
            continue

        if outcome == "transient_failure":
            consecutive_transient_failures += 1
            if consecutive_transient_failures >= REGISTRY_MAX_TRANSIENT_BACKOFF_ATTEMPTS:
                log.warning(
                    "registry_update_transient_retry_suspended",
                    consecutive_failures=consecutive_transient_failures,
                    cooldown_seconds=poll_interval_seconds,
                )
                consecutive_transient_failures = 0
                backoff_seconds = REGISTRY_INITIAL_BACKOFF_SECONDS
                await anyio.sleep(poll_interval_seconds)
                continue

            await anyio.sleep(_jittered_delay(backoff_seconds))
            backoff_seconds = min(backoff_seconds * 2, REGISTRY_MAX_BACKOFF_SECONDS)
            continue

        # semantic failure
        consecutive_transient_failures = 0
        backoff_seconds = REGISTRY_INITIAL_BACKOFF_SECONDS
        await anyio.sleep(poll_interval_seconds)
