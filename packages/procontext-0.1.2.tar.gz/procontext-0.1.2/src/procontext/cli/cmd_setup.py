"""CLI command: procontext setup — download and persist the library registry."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from procontext.config import registry_paths
from procontext.registry import (
    fetch_registry_additional_info_for_setup,
    fetch_registry_for_setup,
)

if TYPE_CHECKING:
    from procontext.config import Settings


async def attempt_registry_setup(settings: Settings) -> bool:
    """Try to fetch and persist the registry once. Returns True on success."""
    return await fetch_registry_for_setup(settings)


async def attempt_registry_additional_info_setup(settings: Settings) -> bool:
    """Try to fetch and persist registry additional-info once. Returns True on success."""
    return await fetch_registry_additional_info_for_setup(settings)


async def run_setup(settings: Settings) -> None:
    """Fetch the registry from the configured URL and save it to the data directory."""
    registry_path, _ = registry_paths(settings)
    print(  # noqa: T201 — CLI command, not MCP server
        f"Downloading registry from {settings.registry.metadata_url} ...",
        flush=True,
    )

    if await attempt_registry_setup(settings):
        print(  # noqa: T201 — CLI command, not MCP server
            f"Registry initialised (saved to: {registry_path})",
            flush=True,
        )
    else:
        print(  # noqa: T201 — CLI command, not MCP server
            "Setup failed. Check your network and try again.\n"
            "If local state looks a little unwell, summon the doctor with\n"
            "'procontext doctor --fix'.\n"
            "If the error persists, you can manually download the registry\n"
            "and configure its path in procontext.yaml",
            file=sys.stderr,
        )
        sys.exit(1)
