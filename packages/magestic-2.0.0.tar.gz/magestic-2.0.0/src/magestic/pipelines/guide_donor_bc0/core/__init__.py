"""
Core processing functions for the Guide-Donor-BC0 pipeline.
"""

from .oligo_matching import (
    load_oligo_pool,
    build_lookup_dictionaries,
    resolve_oligo_name,
    OligoMatchResult,
)

from .structure_inference import (
    NucleaseAnchors,
    NUCLEASE_ANCHORS,
    SPS_TO_LIBRARY,
    StructureInferenceResult,
    infer_amplicon_structure,
    infer_structure_from_multiple_fastqs,
    get_structure_for_nuclease,
    get_nuclease_from_sps,
    rev_comp,
    detect_nuclease_from_oligo,
)

__all__ = [
    # Oligo matching
    "load_oligo_pool",
    "build_lookup_dictionaries",
    "resolve_oligo_name",
    "OligoMatchResult",
    # Structure inference
    "NucleaseAnchors",
    "NUCLEASE_ANCHORS",
    "SPS_TO_LIBRARY",
    "StructureInferenceResult",
    "infer_amplicon_structure",
    "infer_structure_from_multiple_fastqs",
    "get_structure_for_nuclease",
    "get_nuclease_from_sps",
    "rev_comp",
    "detect_nuclease_from_oligo",
]
