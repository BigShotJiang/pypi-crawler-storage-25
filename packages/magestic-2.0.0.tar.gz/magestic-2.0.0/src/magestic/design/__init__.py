"""
magestic.design — Guide-donor oligo design for MAGESTIC libraries.

Provides functions for designing guide RNA / donor DNA oligonucleotide pairs
for MAGESTIC 3.0 libraries. Supports SpCas9 (NGG PAM) and SpG (NGNN PAM)
nucleases.

Two design workflows:
    1. VCF-based design:  generate oligos for natural variants from a VCF file
    2. Saturation design: generate all amino acid substitutions for a target ORF

Core utilities:
    guide_donor_functions — Reference data loaders, sequence utils, codon utils,
                             guide disruption checks, donor assembly
    oligo_design          — ORF-level PAM finding, Azimuth score loading,
                             restriction site avoidance, donor shifting

CLI entry points (see magestic.design._cli):
    magestic-design-vcf        — VCF-based oligo design
    magestic-design-saturation — Saturation mutagenesis oligo design
"""

from .guide_donor_functions import (
    load_codon_table,
    load_processed_guides,
    load_guides_from_fasta,
    rev_comp,
    base_match,
    hamming_distance,
    restriction_site_in_seq,
    guide_disruption,
    assemble_donor,
)

__all__ = [
    "load_codon_table",
    "load_processed_guides",
    "load_guides_from_fasta",
    "rev_comp",
    "base_match",
    "hamming_distance",
    "restriction_site_in_seq",
    "guide_disruption",
    "assemble_donor",
]
