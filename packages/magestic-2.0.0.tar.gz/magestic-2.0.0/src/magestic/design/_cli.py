"""
magestic.design._cli — CLI entry points for MAGESTIC oligo design.

Entry points registered in pyproject.toml:
    magestic-design-vcf        -> design_vcf_main()
    magestic-design-saturation -> design_saturation_main()

Author: Kevin R. Roy
"""

import argparse
import sys


def design_vcf_main():
    """
    CLI entry point: magestic-design-vcf

    Design guide-donor oligo pairs for natural variants from a VCF file.
    Supports SpCas9 (NGG PAM) and SpG (NGNN PAM) nucleases.

    Legacy script: common/scripts/guide_donor_design/
        generate_guide_donor_sequences_from_vcf_for_NGNN_PAMs.py
    """
    parser = argparse.ArgumentParser(
        prog="magestic-design-vcf",
        description="Design guide-donor oligo pairs for natural variants from a VCF file.",
    )
    parser.add_argument(
        "--vcf",
        required=True,
        metavar="VCF",
        help="Input VCF file of variants to design oligos for.",
    )
    parser.add_argument(
        "--genome",
        required=True,
        metavar="FASTA",
        help="Reference genome FASTA.",
    )
    parser.add_argument(
        "--gff",
        required=True,
        metavar="GFF",
        help="GFF3 annotation file.",
    )
    parser.add_argument(
        "--guides",
        required=True,
        metavar="TSV",
        help="Pre-computed guide target sites TSV (Azimuth scores + BLAST mismatch counts).",
    )
    parser.add_argument(
        "--sps",
        required=True,
        metavar="TXT",
        help="Subpool priming sequences file.",
    )
    parser.add_argument(
        "--nuclease",
        choices=["SpCas9", "SpG"],
        default="SpCas9",
        help="Nuclease type. SpCas9 uses NGG PAM; SpG uses NGNN PAM. (default: SpCas9)",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="TSV",
        help="Output TSV file for designed oligos.",
    )
    parser.add_argument(
        "--donor-length",
        type=int,
        default=129,
        metavar="N",
        help="Total donor length in bp. (default: 129)",
    )
    parser.add_argument(
        "--guide-length",
        type=int,
        default=20,
        metavar="N",
        help="Guide RNA length. (default: 20)",
    )
    parser.add_argument(
        "--strain",
        default="",
        metavar="STR",
        help="Strain identifier used in oligo naming.",
    )

    args = parser.parse_args()

    # Full implementation of VCF-based design is in vcf_design.py (Phase 2).
    # Until that module is complete, direct users to the legacy script.
    raise NotImplementedError(
        "magestic-design-vcf is not yet fully implemented.\n"
        "Use the legacy script:\n"
        "  common/scripts/guide_donor_design/"
        "generate_guide_donor_sequences_from_vcf_for_NGNN_PAMs.py\n"
        "Full implementation tracked in Phase 2 of the MAGESTIC 2.0 migration."
    )


def design_saturation_main():
    """
    CLI entry point: magestic-design-saturation

    Design guide-donor oligo pairs for all amino acid substitutions in a target ORF
    (saturation mutagenesis).

    Legacy script: common/scripts/guide_donor_design/
        generate_amino_acid_variant_guide_donor_oligos_for_saturation_editing_v5.py
    """
    parser = argparse.ArgumentParser(
        prog="magestic-design-saturation",
        description="Design guide-donor oligo pairs for saturation mutagenesis of a target ORF.",
    )
    parser.add_argument(
        "--gene",
        required=True,
        metavar="GENE",
        help="Gene name (systematic or common) to saturate.",
    )
    parser.add_argument(
        "--genome",
        required=True,
        metavar="FASTA",
        help="Reference genome FASTA.",
    )
    parser.add_argument(
        "--gff",
        required=True,
        metavar="GFF",
        help="GFF3 annotation file.",
    )
    parser.add_argument(
        "--codon-table",
        required=True,
        metavar="TSV",
        help="Codon-to-amino-acid table TSV.",
    )
    parser.add_argument(
        "--guides",
        required=True,
        metavar="TSV",
        help="Pre-computed guide target sites TSV (Azimuth scores + BLAST mismatch counts).",
    )
    parser.add_argument(
        "--sps",
        required=True,
        metavar="TXT",
        help="Subpool priming sequences file.",
    )
    parser.add_argument(
        "--nuclease",
        choices=["SpCas9", "SpG"],
        default="SpCas9",
        help="Nuclease type. SpCas9 uses NGG PAM; SpG uses NGNN PAM. (default: SpCas9)",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="TSV",
        help="Output TSV file for designed oligos.",
    )
    parser.add_argument(
        "--donor-length",
        type=int,
        default=129,
        metavar="N",
        help="Total donor length in bp. (default: 129)",
    )
    parser.add_argument(
        "--guide-length",
        type=int,
        default=20,
        metavar="N",
        help="Guide RNA length. (default: 20)",
    )
    parser.add_argument(
        "--include-stop-codons",
        action="store_true",
        default=True,
        help="Include stop codon substitutions. (default: True)",
    )
    parser.add_argument(
        "--mutate-stop-codon",
        action="store_true",
        default=True,
        help="Include mutation of the stop codon. (default: True)",
    )
    parser.add_argument(
        "--no-mutate-initiating-met",
        action="store_true",
        default=False,
        help="Exclude mutations of the initiating methionine.",
    )

    args = parser.parse_args()

    # Full implementation of saturation design is in saturation_design.py (Phase 2).
    # Until that module is complete, direct users to the legacy script.
    raise NotImplementedError(
        "magestic-design-saturation is not yet fully implemented.\n"
        "Use the legacy script:\n"
        "  common/scripts/guide_donor_design/"
        "generate_amino_acid_variant_guide_donor_oligos_for_saturation_editing_v5.py\n"
        "Full implementation tracked in Phase 2 of the MAGESTIC 2.0 migration."
    )
