import argparse
import os
import fnmatch
from .renderer import render_ls
from .scanner import scan_directory

def main():
    parser = argparse.ArgumentParser(description="List directory contents (ls)")
    parser.add_argument("patterns", nargs="*", default=["."], help="Directories or patterns to list (supports * wildcard)")
    args = parser.parse_args()

    for idx, pattern in enumerate(args.patterns):
        is_wildcard = any(c in pattern for c in "*?[]")
        if is_wildcard:
            dir_path = os.path.dirname(pattern) or "."
            name_pat = os.path.basename(pattern)
            entries = scan_directory(dir_path)
            filtered = [e for e in entries if fnmatch.fnmatch(e['name'], name_pat)]
            render_ls(filtered)
        else:
            parent = os.path.dirname(pattern) or "."
            name = os.path.basename(pattern)
            entries = scan_directory(parent)
            filtered = [e for e in entries if e['name'] == name]
            render_ls(filtered)

if __name__ == "__main__":
    main()
