import os
import pwd
import grp
import stat
from datetime import datetime

def _get_permission_string(mode):
    perms = []
    for who in ['USR', 'GRP', 'OTH']:
        for what in ['R', 'W', 'X']:
            if mode & getattr(stat, f'S_I{what}{who}'):
                perms.append(what.lower())
            else:
                perms.append('-')
    return ''.join(perms)

def scan_directory(path):
    try:
        entries = []
        for name in sorted(os.listdir(path)):
            full_path = os.path.join(path, name)
            st = os.lstat(full_path)
            size = st.st_size
            owner = pwd.getpwuid(st.st_uid).pw_name
            group = grp.getgrgid(st.st_gid).gr_name
            perms = _get_permission_string(st.st_mode)
            is_dir = os.path.isdir(full_path)
            mtime = datetime.fromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            entries.append({
                'name': name,
                'size': size,
                'owner': owner,
                'group': group,
                'perms': perms,
                'is_dir': is_dir,
                'mtime': mtime
            })
        return entries
    except Exception as e:
        print(f"Error: {e}")
        return []
