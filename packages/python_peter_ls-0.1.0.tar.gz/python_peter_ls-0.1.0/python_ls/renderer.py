

# ANSI color codes for each unit: small=gray, then white, yellow, magenta, red
_SIZE_COLORS = {
    'b': '\033[30m',      # Black
    'kb': '\033[90m',     # Dark grey
    'mb': '\033[93m',     # Yellow
    'gb': '\033[95m',     # Magenta
    'tb': '\033[91m',     # Red
}

def _human_size(size):
    units = ['b', 'kb', 'mb', 'gb', 'tb']
    for unit in units:
        if size < 1024 or unit == units[-1]:
            val = f"{size:.0f}{unit}" if unit == 'b' else f"{size:.1f}{unit}"
            color = _SIZE_COLORS[unit]
            return f"{color}{val}\033[0m"
        size /= 1024

def render_ls(entries):
    if not entries:
        return
    # Precompute human-readable sizes
    for e in entries:
        e['size_hr'] = _human_size(e['size'])
    name_w = max(len(e['name']) for e in entries)
    size_w = max(len(e['size_hr']) for e in entries)
    owner_group_w = max(len(f"{e['owner']}:{e['group']}") for e in entries)
    perms_w = max(len(e['perms']) for e in entries)
    mtime_w = max(len(e['mtime']) for e in entries)

    fmt = f"{{:<{name_w}}}  {{:>{size_w}}}  {{:<{owner_group_w}}}  {{:<{perms_w}}}  {{:<{mtime_w}}}"
    for entry in entries:
        plain_name = entry['name']
        name = plain_name
        if entry.get('is_dir'):
            # Blue background, white text (ANSI: 44;97)
            name = f"\033[44;97m{plain_name}\033[0m"
        # Use the plain name for padding, then replace with colored name
        line = fmt.format(plain_name, entry['size_hr'], f"{entry['owner']}:{entry['group']}", entry['perms'], entry['mtime'])
        # Replace only the name part with the colored name if needed
        if name != plain_name:
            line = line.replace(plain_name, name, 1)
        print(line)
