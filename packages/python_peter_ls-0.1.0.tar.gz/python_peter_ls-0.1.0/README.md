# python-ls

A Python implementation of the 'ls' command, inspired by the structure of python-du.

## Installation

```bash
pip install -e .
```

```
pip uninstall python-ls
```

## Usage

```bash
python-ls [path] [options]
```

If no path is given, the current directory is scanned.

## Publishing to PyPI

```
pip install build twine
python -m build
twine upload dist/*
```

When prompted, use `__token__` as the username and your PyPI API token as the password.

To skip the prompt, create a `~/.pypirc` file:

```ini
[pypi]
username = __token__
password = pypi-YOUR-TOKEN-HERE
```

> **Note:** Bump the `version` in `pyproject.toml` before each upload — PyPI rejects duplicate version numbers.

## Requirements

- Python >= 3.9
- No external dependencies