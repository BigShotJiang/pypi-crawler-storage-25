# Copyright (C) 2026 Bader Issaei / VaultBytes Innovations Ltd
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Tests for fhe_oracle.heuristics."""

from __future__ import annotations

import numpy as np
import pytest

from fhe_oracle.heuristics import (
    depth_seeker_score,
    generate_seeds,
    mult_magnifier_score,
    near_threshold_score,
)


def test_mult_magnifier_monotone_on_corner():
    """s_mm should score a box-corner higher than the midpoint."""
    midpoint = [0.0] * 8
    corner = [3.0] * 8
    assert mult_magnifier_score(corner) > mult_magnifier_score(midpoint)


def test_mult_magnifier_scales_with_magnitude():
    """Doubling magnitudes should strictly increase s_mm."""
    x = [1.0] * 6
    x2 = [2.0] * 6
    assert mult_magnifier_score(x2) > mult_magnifier_score(x)


def test_depth_seeker_box_corner_max():
    """s_ds peaks when every coordinate is jointly large."""
    origin = [0.0] * 5
    corner = [2.0] * 5
    assert depth_seeker_score(corner) > depth_seeker_score(origin)


def test_depth_seeker_geometric_mean_form():
    """s_ds on x=[1,1,1,1] = (prod(|1|+1))^(1/4) = 2^1 = 2.0."""
    x = [1.0, 1.0, 1.0, 1.0]
    assert depth_seeker_score(x) == pytest.approx(2.0, rel=1e-9)


def test_near_threshold_peaks_at_tau():
    """s_nt max is at ||x||_1 = tau."""
    tau = 3.0
    at_tau = [1.0, 1.0, 1.0]           # ||.||_1 = 3 = tau
    far = [5.0, 5.0, 5.0]              # ||.||_1 = 15 >> tau
    assert near_threshold_score(at_tau, tau) > near_threshold_score(far, tau)
    assert near_threshold_score(at_tau, tau) == pytest.approx(1.0, rel=1e-6)


def test_generate_seeds_returns_k_candidates():
    """generate_seeds returns exactly k items under all heuristics."""
    rng = np.random.default_rng(42)
    bounds = [(-3.0, 3.0)] * 8
    seeds = generate_seeds(rng, bounds, k=10, which=("mm", "ds", "nt"))
    assert len(seeds) == 10
    for s in seeds:
        assert len(s) == 8
        for xi, (lo, hi) in zip(s, bounds):
            assert lo <= xi <= hi


def test_generate_seeds_respects_which_filter():
    """Excluded heuristics do not contribute to the pool."""
    rng = np.random.default_rng(7)
    bounds = [(-1.0, 1.0)] * 4
    seeds = generate_seeds(rng, bounds, k=5, which=("mm",))
    assert len(seeds) == 5
    # All candidates come from the mm pool — a smoke check of the
    # filter, not a statistical test.


def test_generate_seeds_empty_which_returns_empty():
    rng = np.random.default_rng(1)
    bounds = [(-1.0, 1.0)] * 3
    seeds = generate_seeds(rng, bounds, k=10, which=())
    assert seeds == []


def test_generate_seeds_k_zero_returns_empty():
    rng = np.random.default_rng(1)
    bounds = [(-1.0, 1.0)] * 3
    seeds = generate_seeds(rng, bounds, k=0, which=("mm",))
    assert seeds == []


def test_generate_seeds_reproducible():
    """Same seed → same candidate set."""
    bounds = [(-2.0, 2.0)] * 6
    rng_a = np.random.default_rng(123)
    rng_b = np.random.default_rng(123)
    seeds_a = generate_seeds(rng_a, bounds, k=8, which=("mm", "ds", "nt"))
    seeds_b = generate_seeds(rng_b, bounds, k=8, which=("mm", "ds", "nt"))
    assert seeds_a == seeds_b
