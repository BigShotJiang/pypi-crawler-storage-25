# Copyright (C) 2026 Bader Issaei / VaultBytes Innovations Ltd
# SPDX-License-Identifier: AGPL-3.0-or-later
# Patent pending: PCT/IB2026/053378
"""Noise-guided seed generators for CMA-ES gen-0 injection.

Three heuristic scorers rank uniform random candidates; the top K
are injected into CMA-ES's first generation via pycma's `inject()`.

- s_mm (multiplication magnifier): push consecutive-coordinate
  products toward the box corners where CKKS multiplication noise
  grows fastest.
- s_ds (depth seeker): prefer inputs whose coordinates are jointly
  large, exercising deeper multiplication chains.
- s_nt (near-threshold explorer): cluster near polynomial-
  approximation domain boundaries (sigmoid inflection, etc.).

Implements the three heuristics described in `fhe_oracle_draft.tex`
§4.2 (eqs. 3, 4, 5). Paper claims K=10 seeds injected into
generation 0 at `tex:567-569`; `fhe_oracle/core.py` now honours that
claim when `use_heuristic_seeds=True` is passed to `FHEOracle`.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np


def mult_magnifier_score(x: np.ndarray | Sequence[float], lam: float = 0.1) -> float:
    """Eq. 3 of fhe_oracle_draft.tex:466.

    s_mm(x) = sum_i |x_i * x_{i+1}| + lambda * ||x||^2

    Higher score = larger consecutive-coordinate products, which
    drive CKKS multiplication noise upward.
    """
    arr = np.asarray(x, dtype=np.float64)
    if arr.size < 2:
        return float(lam * np.dot(arr, arr))
    return float(np.sum(np.abs(arr[:-1] * arr[1:])) + lam * np.dot(arr, arr))


def depth_seeker_score(x: np.ndarray | Sequence[float]) -> float:
    """Eq. 4 of fhe_oracle_draft.tex:484.

    s_ds(x) = (prod_i (|x_i| + 1))^(1/d)

    Geometric mean of coordinate magnitudes plus one. Peaks when
    every coordinate is jointly large — exercises deeper chains.
    """
    arr = np.asarray(x, dtype=np.float64)
    d = arr.size
    if d == 0:
        return 0.0
    return float(np.prod(np.abs(arr) + 1.0) ** (1.0 / d))


def near_threshold_score(
    x: np.ndarray | Sequence[float], tau: float
) -> float:
    """Eq. 5 of fhe_oracle_draft.tex:503.

    s_nt(x; tau) = exp(-0.5 * ((||x||_1 - tau) / sigma_tau)^2)

    Gaussian bump centred at ||x||_1 = tau. Targets the shell
    where polynomial approximations (sigmoid, Chebyshev) break
    down.
    """
    arr = np.asarray(x, dtype=np.float64)
    sigma_tau = max(1.0, 0.2 * abs(tau))
    return float(np.exp(-0.5 * ((np.linalg.norm(arr, 1) - tau) / sigma_tau) ** 2))


def _default_tau(lows: np.ndarray, highs: np.ndarray) -> float:
    """Default near-threshold radius: half the L1 box diameter."""
    return float(np.sum(highs - lows) / 4.0)


def generate_seeds(
    rng: np.random.Generator,
    bounds: Sequence[tuple[float, float]],
    k: int = 10,
    tau: float | None = None,
    which: Sequence[str] = ("mm", "ds", "nt"),
    pool_multiplier: int = 10,
) -> list[list[float]]:
    """Generate `k` heuristic seeds for CMA-ES gen-0 injection.

    Parameters
    ----------
    rng : np.random.Generator
        Independent RNG stream. Should be seeded separately from
        the CMA-ES RNG so injection is reproducible without biasing
        CMA-ES.
    bounds : sequence of (low, high)
        Per-dimension box constraints.
    k : int
        Total number of seeds to return.
    tau : float or None
        Near-threshold radius. Defaults to half the L1 diameter.
    which : sequence of {"mm", "ds", "nt"}
        Subset of heuristics to use.
    pool_multiplier : int
        Draw `pool_multiplier * k` candidates per enabled heuristic
        before selecting the top `k`.

    Returns
    -------
    list[list[float]]
        Top-scoring `k` seeds after z-normalising scores across
        each heuristic. Empty list if `which` is empty or k<=0.
    """
    if k <= 0 or not which:
        return []
    lows = np.array([b[0] for b in bounds], dtype=np.float64)
    highs = np.array([b[1] for b in bounds], dtype=np.float64)
    d = len(bounds)
    if d == 0:
        return []

    if tau is None:
        tau = _default_tau(lows, highs)

    pool_size = max(1, pool_multiplier * k)
    pool: list[tuple[float, np.ndarray]] = []

    for heuristic in which:
        cands = rng.uniform(lows, highs, size=(pool_size, d))
        if heuristic == "mm":
            scores = np.array([mult_magnifier_score(c) for c in cands])
        elif heuristic == "ds":
            scores = np.array([depth_seeker_score(c) for c in cands])
        elif heuristic == "nt":
            scores = np.array([near_threshold_score(c, tau) for c in cands])
        else:
            continue  # skip unknown
        mu = scores.mean()
        sigma = scores.std()
        if sigma < 1e-12:
            z_scores = scores - mu
        else:
            z_scores = (scores - mu) / sigma
        for z, c in zip(z_scores, cands):
            pool.append((float(z), c))

    if not pool:
        return []

    pool.sort(key=lambda t: -t[0])
    return [c.tolist() for _, c in pool[:k]]
