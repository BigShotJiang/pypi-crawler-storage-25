# Copyright (C) 2026 Bader Issaei / VaultBytes Innovations Ltd
# SPDX-License-Identifier: AGPL-3.0-or-later
# Patent pending: PCT/IB2026/053378
"""Fitness functions for adversarial FHE testing.

The fitness function directs the CMA-ES optimiser toward inputs that
expose the largest semantic divergence between a plaintext program and
its FHE-compiled counterpart.

Two modes
---------
1. Pure divergence (default): fitness = |plain(x) - fhe(x)|.
   Works without any FHE-library-specific instrumentation.

2. Noise-guided (when an FHEAdapter is provided): fitness combines
   divergence with ciphertext noise-budget consumption and
   multiplicative-depth utilisation. This is the patented heuristic
   that finds more bugs per evaluation than divergence alone.
"""

from __future__ import annotations

from typing import Callable, Optional

import numpy as np


class DivergenceFitness:
    """Pure-divergence fitness: |plaintext_fn(x) - fhe_fn(x)|.

    Parameters
    ----------
    plaintext_fn : callable
        Reference plaintext implementation.
        ``plaintext_fn(x: list[float]) -> float | list[float]``.
    fhe_fn : callable
        FHE implementation under test. Same signature as plaintext_fn.
    output_reducer : callable, optional
        Applied to the absolute difference vector (e.g. ``np.max``,
        ``np.mean``). Default ``np.max`` — most sensitive to point
        precision bugs.
    """

    def __init__(
        self,
        plaintext_fn: Callable[[list[float]], float | list[float]],
        fhe_fn: Callable[[list[float]], float | list[float]],
        output_reducer: Callable[[np.ndarray], float] = np.max,
    ) -> None:
        self._plaintext_fn = plaintext_fn
        self._fhe_fn = fhe_fn
        self._reduce = output_reducer

    def score(self, x: list[float]) -> float:
        """Return the divergence at x. Exceptions return 0.0."""
        try:
            plain = _to_array(self._plaintext_fn(x))
            fhe = _to_array(self._fhe_fn(x))
        except Exception:
            return 0.0

        if plain.shape != fhe.shape:
            n = min(plain.size, fhe.size)
            plain = plain.ravel()[:n]
            fhe = fhe.ravel()[:n]

        diff = np.abs(plain - fhe)
        if diff.size == 0:
            return 0.0
        return float(self._reduce(diff))


class NoiseGuidedFitness:
    """Noise-guided fitness combining divergence, noise, and depth.

    Used when the caller provides an FHEAdapter (openfhe/concrete/seal).
    Falls back to pure divergence if adapter probes fail.

    Weights default to ``(1.0, 0.0, 0.0)`` (pure divergence) as of
    v0.3.0. Empirical evaluation (paper §6.15) across 12+ sprints and
    20-seed replications showed the noise/depth shaping terms are inert
    on every CKKS circuit tested and actively counter-productive on
    pure-CKKS-noise circuits (Circuit 2: DIV beats FULL by 2.4x,
    p_Holm = 5.7e-4). Pass ``weights=(1.0, 0.5, 0.3)`` to restore the
    v0.2 shaping behaviour.
    """

    def __init__(
        self,
        plaintext_fn: Callable[[list[float]], float | list[float]],
        adapter,
        weights: tuple[float, float, float] = (1.0, 0.0, 0.0),
        max_noise_budget: float = 1000.0,
        max_mult_depth: int = 10,
    ) -> None:
        self._plaintext_fn = plaintext_fn
        self._adapter = adapter
        self._w_div, self._w_noise, self._w_depth = weights
        self._max_noise = max(1.0, max_noise_budget)
        self._max_depth = max(1, max_mult_depth)

    def score(self, x: list[float]) -> float:
        try:
            ct_in = self._adapter.encrypt(x)
            ct_out = self._adapter.run_fhe_program(ct_in)

            fhe_val = _to_scalar(self._adapter.decrypt(ct_out))
            plain_val = _to_scalar(self._plaintext_fn(x))
            divergence = abs(fhe_val - plain_val)

            budget_before = self._adapter.get_noise_budget(ct_in)
            budget_after = self._adapter.get_noise_budget(ct_out)
            consumed = max(0.0, budget_before - budget_after)
            noise_component = min(1.0, consumed / self._max_noise)

            depth_used = self._adapter.get_mult_depth_used(ct_out)
            depth_component = min(1.0, depth_used / self._max_depth)

            return (
                self._w_div * divergence
                + self._w_noise * noise_component
                + self._w_depth * depth_component
            )
        except Exception:
            return 0.0


def _to_array(value) -> np.ndarray:
    if isinstance(value, (int, float, np.integer, np.floating)):
        return np.array([float(value)], dtype=np.float64)
    return np.asarray(value, dtype=np.float64)


def _to_scalar(value) -> float:
    if isinstance(value, (int, float, np.integer, np.floating)):
        return float(value)
    arr = np.asarray(value).ravel()
    return float(arr[0]) if arr.size > 0 else 0.0
