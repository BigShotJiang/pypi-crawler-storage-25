"""SBI protocol tests."""
