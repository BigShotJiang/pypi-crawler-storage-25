from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


# ── Pagination ───────────────────────────────────────────────────────


class PaginatedResponse[T](BaseModel):
    items: list[T]
    total_pages: int
    total_results: int


# ── Status ───────────────────────────────────────────────────────────


class StatusResponse(BaseModel):
    status: str


# ── Auth ─────────────────────────────────────────────────────────────


class NextUrl(BaseModel):
    next: str | None = None


class AuthUrlResponse(BaseModel):
    auth_url: str


# ── Users ────────────────────────────────────────────────────────────


class UserMdl(BaseModel):
    id: int
    created_at: datetime
    email: str
    role: str
    username: str
    api_key: str | None = None


class UserInfo(BaseModel):
    id: int
    username: str
    role: str
    created_at: datetime


class CreateUserRequest(BaseModel):
    email: str
    name: str | None = None


class UserQueryRequest(BaseModel):
    name: str | None = None
    exact: bool | None = None
    limit: int | None = Field(None, ge=1, le=200)
    page: int | None = Field(None, ge=1)
    role: str | None = None


class ChangeRoleRequest(BaseModel):
    role: str

    @field_validator("role")
    @classmethod
    def validate_role(cls, v: str) -> str:
        if v not in ("User", "Admin"):
            raise ValueError("role must be 'User' or 'Admin'")
        return v


class ChangeUsernameRequest(BaseModel):
    username: str


class ApiKeyInfo(BaseModel):
    id: int
    user_id: int
    name: str
    created_at: datetime
    expires_at: datetime | None = None
    last_used_at: datetime | None = None


class ApiKeyMdl(BaseModel):
    id: int
    user_id: int
    key: str
    name: str
    created_at: datetime
    expires_at: datetime | None = None
    last_used_at: datetime | None = None


class CreateApiKeyRequest(BaseModel):
    name: str


# ── Sources ──────────────────────────────────────────────────────────


class SourceMdl(BaseModel):
    id: UUID
    created_at: datetime
    name: str


class CreateSourceRequest(BaseModel):
    name: str
    user_ids: list[int]


class SourceQueryRequest(BaseModel):
    name: str | None = None
    exact: bool | None = None
    user_id: int | None = None
    limit: int | None = Field(None, ge=1, le=200)
    page: int | None = Field(None, ge=1)


class PutSourceRequest(BaseModel):
    name: str | None = None
    user_ids: list[int] | None = None
    tags: list[str] | None = None


class SourceTagMdl(BaseModel):
    source_id: UUID
    tag: str


class SourceUserMdl(BaseModel):
    source_id: UUID
    user_id: int


# ── Commits ──────────────────────────────────────────────────────────


class CommitMdl(BaseModel):
    id: int
    created_at: datetime
    source_id: UUID
    user_id: int | None = None
    name: str | None = None
    description: str | None = None


class CommitQueryRequest(BaseModel):
    source_id: UUID | None = None
    limit: int | None = Field(None, ge=1, le=200)
    page: int | None = Field(None, ge=1)


# ── Targets ──────────────────────────────────────────────────────────


class TargetMdl(BaseModel):
    id: int
    created_at: datetime
    platform: str | None = None
    arch: str | None = None


class TargetQueryRequest(BaseModel):
    platform: str | None = None
    arch: str | None = None


# ── Symbols ──────────────────────────────────────────────────────────


class SymbolMdl(BaseModel):
    id: int
    created_at: datetime
    name: str
    symbol_class: str = Field(alias="class")
    modifier: str
    published_by: str | None = None

    model_config = {"populate_by_name": True}


class SymbolQueryRequest(BaseModel):
    name: str | None = None
    exact: bool | None = False
    limit: int | None = Field(None, ge=1, le=200)
    page: int | None = Field(None, ge=1)


# ── Functions ────────────────────────────────────────────────────────


class FunctionMdl(BaseModel):
    id: int
    created_at: datetime
    commit_id: int
    target_id: int
    source_id: UUID
    guid: UUID
    symbol_id: int
    type_id: UUID | None = None


class FunctionQueryRequest(BaseModel):
    guids: list[UUID] | None = None
    source_id: UUID | None = None
    source_tags: list[str] | None = None
    target_id: int | None = None
    commit_id: int | None = None
    symbol_id: int | None = None
    format: str | None = None
    limit: int | None = Field(None, ge=1)
    page: int | None = Field(None, ge=1)


class FunctionCommentMdl(BaseModel):
    id: int
    function_id: int
    text: str
    byte_offset: int


class FunctionConstraintMdl(BaseModel):
    id: int
    function_id: int
    guid: UUID
    byte_offset: int | None = None


# ── Types ────────────────────────────────────────────────────────────


class TypeMdl(BaseModel):
    id: UUID
    created_at: datetime
    commit_id: int
    source_id: UUID
    name: str | None = None
    data: list[int]


class TypeQueryRequest(BaseModel):
    name: str | None = None
    exact: bool | None = None
    format: str | None = None
    limit: int | None = Field(None, ge=1, le=200)
    page: int | None = Field(None, ge=1)


class DataIdsRequest(BaseModel):
    ids: list[UUID | int] = Field(default_factory=list, max_length=500)


# ── Files ────────────────────────────────────────────────────────────


class UploadFileJson(BaseModel):
    name: str
    source: UUID
    file: str
    description: str | None = None


class PushResponse(BaseModel):
    commit_id: int


# ── Search ───────────────────────────────────────────────────────────


class SearchIndexRow(BaseModel):
    kind: str
    id: str
    created_at: datetime
    name: str | None = None
    source_id: UUID | None = None
    function_guid: UUID | None = None
    symbol_id: int | None = None
    commit_id: int | None = None
    data: list[int] | None = None


class SearchResponse(BaseModel):
    total: int
    limit: int
    offset: int
    items: list[SearchIndexRow]


# ── BNDBs ────────────────────────────────────────────────────────────


class BndbMdl(BaseModel):
    id: int
    uuid: UUID
    name: str
    description: str | None = None
    user_id: int | None = None
    username: str | None = None
    size_original: int
    size_compressed: int
    sha256: str
    created_at: datetime


class BndbQueryRequest(BaseModel):
    name: str | None = None
    limit: int | None = Field(None, ge=1, le=200)
    page: int | None = Field(None, ge=1)
