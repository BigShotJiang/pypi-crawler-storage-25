import asyncio
import gzip
import hashlib
import logging
import math
from pathlib import Path
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile, status
from fastapi.responses import StreamingResponse
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from warp_server.auth import get_current_user
from warp_server.config import settings
from warp_server.database import get_db
from warp_server.models import Bndb, User
from warp_server.schemas import BndbMdl, BndbQueryRequest, PaginatedResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/bndbs", tags=["bndbs"])

CHUNK_SIZE = 256 * 1024  # 256 KB


def _storage_dir() -> Path:
    return Path(settings.bndb_storage_dir)


def _bndb_path(bndb_uuid: UUID) -> Path:
    return _storage_dir() / f"{bndb_uuid}.bndb.gz"


def _bndb_to_response(bndb: Bndb, username: str | None = None) -> BndbMdl:
    return BndbMdl(
        id=bndb.id,
        uuid=bndb.uuid,
        name=bndb.name,
        description=bndb.description,
        user_id=bndb.user_id,
        username=username,
        size_original=bndb.size_original,
        size_compressed=bndb.size_compressed,
        sha256=bndb.sha256,
        created_at=bndb.created_at,
    )


async def _stream_compress_upload(
    upload: UploadFile, dest: Path
) -> tuple[int, int, str]:
    """Stream an upload through gzip to disk.

    Returns (original_size, compressed_size, sha256_hex).
    """
    sha = hashlib.sha256()
    original_size = 0

    def _write_sync():
        nonlocal original_size
        with gzip.open(dest, "wb", compresslevel=6) as gz:
            while True:
                chunk = upload.file.read(CHUNK_SIZE)
                if not chunk:
                    break
                sha.update(chunk)
                original_size += len(chunk)
                gz.write(chunk)

    await asyncio.to_thread(_write_sync)

    compressed_size = dest.stat().st_size
    return original_size, compressed_size, sha.hexdigest()


@router.post("", response_model=BndbMdl)
async def upload_bndb(
    file: UploadFile,
    name: str = Form(...),
    description: str | None = Form(None),
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    bndb = Bndb(
        uuid=uuid4(),
        name=name,
        description=description,
        user_id=user.id,
        size_original=0,
        size_compressed=0,
        sha256="",
    )
    dest = _bndb_path(bndb.uuid)

    try:
        original, compressed, sha256_hex = await _stream_compress_upload(file, dest)
        bndb.size_original = original
        bndb.size_compressed = compressed
        bndb.sha256 = sha256_hex

        db.add(bndb)
        await db.commit()
        await db.refresh(bndb)
    except Exception:
        dest.unlink(missing_ok=True)
        raise

    logger.info(
        "BNDB upload %s: %d → %d bytes (%.0f%% compression)",
        name,
        original,
        compressed,
        (1 - compressed / original) * 100 if original else 0,
    )

    return _bndb_to_response(bndb, user.username)


@router.post("/query", response_model=PaginatedResponse[BndbMdl])
async def query_bndbs(
    body: BndbQueryRequest,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    limit = body.limit or 50
    page = body.page or 1

    query = select(Bndb, User.username).outerjoin(User, Bndb.user_id == User.id)
    count_query = select(func.count(Bndb.id))

    if body.name:
        query = query.where(Bndb.name.ilike(f"%{body.name}%"))
        count_query = count_query.where(Bndb.name.ilike(f"%{body.name}%"))

    total = (await db.execute(count_query)).scalar() or 0
    total_pages = max(1, math.ceil(total / limit))

    query = query.order_by(Bndb.created_at.desc())
    query = query.offset((page - 1) * limit).limit(limit)

    result = await db.execute(query)
    items = [_bndb_to_response(row.Bndb, row.username) for row in result.all()]

    return PaginatedResponse(items=items, total_pages=total_pages, total_results=total)


@router.get("/{bndb_uuid}", response_model=BndbMdl)
async def get_bndb(
    bndb_uuid: UUID,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(Bndb, User.username)
        .outerjoin(User, Bndb.user_id == User.id)
        .where(Bndb.uuid == bndb_uuid)
    )
    row = result.one_or_none()
    if row is None:
        raise HTTPException(status_code=404, detail="BNDB not found")
    return _bndb_to_response(row.Bndb, row.username)


@router.get("/{bndb_uuid}/download")
async def download_bndb(
    bndb_uuid: UUID,
    db: AsyncSession = Depends(get_db),
    _user: User = Depends(get_current_user),
):
    result = await db.execute(select(Bndb).where(Bndb.uuid == bndb_uuid))
    bndb = result.scalar_one_or_none()
    if bndb is None:
        raise HTTPException(status_code=404, detail="BNDB not found")

    path = _bndb_path(bndb.uuid)
    if not path.exists():
        raise HTTPException(status_code=404, detail="BNDB file missing from storage")

    def _decompress_stream():
        with gzip.open(path, "rb") as gz:
            while chunk := gz.read(CHUNK_SIZE):
                yield chunk

    filename = bndb.name if bndb.name.endswith(".bndb") else bndb.name + ".bndb"
    safe_name = filename.replace('"', "'")
    return StreamingResponse(
        _decompress_stream(),
        media_type="application/octet-stream",
        headers={
            "Content-Disposition": f'attachment; filename="{safe_name}"',
            "Content-Length": str(bndb.size_original),
        },
    )


@router.delete("/{bndb_uuid}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_bndb(
    bndb_uuid: UUID,
    db: AsyncSession = Depends(get_db),
    user: User = Depends(get_current_user),
):
    result = await db.execute(select(Bndb).where(Bndb.uuid == bndb_uuid))
    bndb = result.scalar_one_or_none()
    if bndb is None:
        raise HTTPException(status_code=404, detail="BNDB not found")

    if bndb.user_id != user.id and user.role != "Admin":
        raise HTTPException(status_code=403, detail="Only the owner or an admin can delete this BNDB")

    path = _bndb_path(bndb.uuid)
    await db.delete(bndb)
    await db.commit()

    path.unlink(missing_ok=True)
