"""Snapshot-side fluent builders.

Right now exposes ``ScanParquetQuery`` — accumulates ``local_*`` filter
steps and dispatches them server-side via ``POST /snapshots/scan``.
The server lazily scans the snapshot with ``pl.scan_parquet`` so only
the filtered subset is collected and returned, keeping client RAM
bounded by the result size rather than the full snapshot size.
"""

from __future__ import annotations

import io
from typing import TYPE_CHECKING

import httpx
import pandas as pd
import pyarrow.parquet as pq
import polars as pl

from ._http import DataProviderHTTPError
from ._query import _LocalFiltersMixin

if TYPE_CHECKING:
    from typing import Self


class ScanParquetQuery(_LocalFiltersMixin):
    """Lazy-scan a saved snapshot, applying ``local_*`` filters on the server.

    Terminal calls:
        ``as_polars()`` → ``pl.DataFrame``
        ``as_pandas()`` → ``pd.DataFrame``
        ``as_parquet(new_key)`` → server-side write under ``new_key`` (bytes
            never leave the server; uses ``LazyFrame.sink_parquet``)
    """

    def __init__(self, session: httpx.AsyncClient, base_url: str, key: str,
                 *, engine: str = 'duckdb', normalize_addresses=None):
        self._session = session
        self._base_url = base_url
        # Always send engine explicitly. Server treats absence as polars
        # (its own default), but we don't want the client default to leak
        # through silently — safer to be explicit.
        self._body: dict = {"key": key, "engine": engine}
        # normalize_addresses: None = auto-detect on the server (default).
        # Forward only when the caller explicitly set a value.
        if normalize_addresses is not None:
            self._body["normalize_addresses"] = bool(normalize_addresses)

    async def _post(self) -> bytes:
        resp = await self._session.post(
            f"{self._base_url}/snapshots/scan",
            json=self._body,
            timeout=None,
        )
        if not resp.is_success:
            try:
                err = resp.json().get("error", resp.text)
            except Exception:
                err = resp.text
            raise DataProviderHTTPError(resp.status_code, err)
        return resp.content

    async def as_polars(self) -> pl.DataFrame:
        data = await self._post()
        return pl.read_parquet(io.BytesIO(data))

    async def as_pandas(self) -> pd.DataFrame:
        data = await self._post()
        return pq.read_table(io.BytesIO(data)).to_pandas()

    async def as_parquet(self, new_key: str) -> None:
        """Save the filtered result to a new snapshot, server-side."""
        body = {**self._body, "save_key": new_key}
        resp = await self._session.post(
            f"{self._base_url}/snapshots/scan",
            json=body,
            timeout=None,
        )
        if not resp.is_success:
            try:
                err = resp.json().get("error", resp.text)
            except Exception:
                err = resp.text
            raise DataProviderHTTPError(resp.status_code, err)
