"""Tests for the Wallets client surface (data_provider 2.5.0 server)."""
from __future__ import annotations

import io
import json

import httpx
import pandas as pd
import polars as pl
import pyarrow.parquet as pq
import pytest
import respx

from horatio_data_provider import DataProviderClient

BASE = "http://test"


@pytest.fixture
def client():
    return DataProviderClient(BASE)


@respx.mock
@pytest.mark.asyncio
async def test_list_no_params(client):
    route = respx.get(f"{BASE}/wallets").mock(
        return_value=httpx.Response(
            200, json={"wallets": [{"address": "0x1"}, {"address": "0x2"}], "count": 2}
        )
    )
    result = await client.wallets.list()
    assert route.called
    # httpx encodes query params in the URL — verify defaults
    q = dict(route.calls[0].request.url.params)
    assert q["limit"] == "100"
    assert q["offset"] == "0"
    assert "category" not in q
    assert result == [{"address": "0x1"}, {"address": "0x2"}]


@respx.mock
@pytest.mark.asyncio
async def test_list_with_filters(client):
    route = respx.get(f"{BASE}/wallets").mock(
        return_value=httpx.Response(200, json={"wallets": [], "count": 0})
    )
    await client.wallets.list(
        category="exchange", entity="Binance", search="hot", limit=25, offset=50,
    )
    q = dict(route.calls[0].request.url.params)
    assert q["category"] == "exchange"
    assert q["entity"] == "Binance"
    assert q["search"] == "hot"
    assert q["limit"] == "25"
    assert q["offset"] == "50"


@respx.mock
@pytest.mark.asyncio
async def test_get_found(client):
    respx.get(f"{BASE}/wallets/0xabc").mock(
        return_value=httpx.Response(200, json={"address": "0xabc", "labels": ["x"]})
    )
    result = await client.wallets.get("0xabc")
    assert result == {"address": "0xabc", "labels": ["x"]}


@respx.mock
@pytest.mark.asyncio
async def test_get_not_found_returns_none(client):
    respx.get(f"{BASE}/wallets/0xnope").mock(
        return_value=httpx.Response(404, json={"error": "Not found"})
    )
    assert await client.wallets.get("0xnope") is None


@respx.mock
@pytest.mark.asyncio
async def test_upsert_pandas_df(client):
    df = pd.DataFrame({
        "address": ["0x1", "0x2"],
        "labels": [["a"], ["b"]],
    })
    route = respx.post(f"{BASE}/wallets").mock(
        return_value=httpx.Response(200, json={"inserted": 2, "updated": 0})
    )
    result = await client.wallets.upsert(df)
    assert route.called
    # Body should be valid parquet
    body = route.calls[0].request.content
    assert route.calls[0].request.headers["content-type"] == "application/octet-stream"
    roundtrip = pq.read_table(io.BytesIO(body)).to_pandas()
    assert list(roundtrip["address"]) == ["0x1", "0x2"]
    assert result == {"inserted": 2, "updated": 0}


@respx.mock
@pytest.mark.asyncio
async def test_upsert_polars_df(client):
    df = pl.DataFrame({"address": ["0xa"], "labels": [["x"]]})
    respx.post(f"{BASE}/wallets").mock(
        return_value=httpx.Response(200, json={"inserted": 1})
    )
    result = await client.wallets.upsert(df)
    assert result == {"inserted": 1}


@respx.mock
@pytest.mark.asyncio
async def test_upsert_bytes_passthrough(client):
    raw = b"PAR1_whatever_bytes"
    route = respx.post(f"{BASE}/wallets").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )
    await client.wallets.upsert(raw)
    assert route.calls[0].request.content == raw


@respx.mock
@pytest.mark.asyncio
async def test_delete(client):
    route = respx.delete(f"{BASE}/wallets/0xabc").mock(
        return_value=httpx.Response(200, json={"deleted": True})
    )
    result = await client.wallets.delete("0xabc")
    assert route.called
    assert result == {"deleted": True}


def test_upsert_rejects_non_df(client):
    import asyncio
    with pytest.raises(TypeError, match="pandas/polars DataFrame or bytes"):
        asyncio.get_event_loop().run_until_complete(
            client.wallets.upsert("not a dataframe")
        )
