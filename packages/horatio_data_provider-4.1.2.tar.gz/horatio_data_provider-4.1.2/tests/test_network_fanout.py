"""Client-side fan-out tests for ``network(list[str])`` on EVM queries.

Verifies:
- Single-string keeps the legacy single-fetch path (sugar).
- List form fans out to one HTTP call per network.
- ``with_network`` is auto-enabled when len(networks) > 1.
- Explicit ``with_network(False)`` is respected.
- Result is concatenated and sorted by ``time``.
- Cache flag survives the fan-out (each per-network call still has it).
"""

from __future__ import annotations

import asyncio
import datetime as _dt
from unittest.mock import patch

import pyarrow as pa
import pytest

from horatio_data_provider._query import EventQuery


def _table_for_network(net: str, t0: int = 0) -> pa.Table:
    """Tiny one-row table with a unique timestamp per network."""
    return pa.table({
        "time": pa.array([_dt.datetime(2025, 1, 1, t0)], type=pa.timestamp("ms", tz="UTC")),
        "network": [net],
        "value": [t0 * 100],
    })


def _build_query(body: dict | None = None) -> EventQuery:
    return EventQuery(session=None, base_url="http://x", path="/p/read", body=body or {})


@pytest.mark.asyncio
async def test_single_string_uses_single_fetch_path():
    q = _build_query().network("ETH").time_range("2025-01-01", "2025-01-02")
    seen = []

    async def fake(_session, _url, body):
        seen.append(body)
        return _table_for_network(body["network"], t0=1)

    with patch("horatio_data_provider._query.fetch_table", new=fake):
        df = await q.as_polars()

    # network('ETH') uses the singular path, not the fan-out.
    assert seen == [{"network": "ETH", "since": "2025-01-01T00:00:00Z",
                     "until": "2025-01-02T00:00:00Z"}]
    assert df.shape == (1, 3)


@pytest.mark.asyncio
async def test_one_element_list_fans_out_once_no_auto_with_network():
    q = _build_query().network(["ETH"]).time_range("2025-01-01", "2025-01-02")
    seen = []

    async def fake(_session, _url, body):
        seen.append(body)
        return _table_for_network(body["network"], t0=2)

    with patch("horatio_data_provider._query.fetch_table", new=fake):
        df = await q.as_polars()

    assert len(seen) == 1
    assert seen[0]["network"] == "ETH"
    # Single-element list: with_network is NOT auto-enabled (len <= 1).
    assert "with_network" not in seen[0] or seen[0].get("with_network") is False
    assert df.shape == (1, 3)


@pytest.mark.asyncio
async def test_multi_network_fans_out_with_auto_with_network():
    q = _build_query().network(["ETH", "POLYGON"]).cache().time_range("2025-01-01", "2025-01-02")
    seen = []

    async def fake(_session, _url, body):
        seen.append(body)
        return _table_for_network(body["network"], t0=int(body["network"][0], 36) % 10)

    with patch("horatio_data_provider._query.fetch_table", new=fake):
        df = await q.as_polars()

    # Two HTTP calls, one per network, both with cache=True (cache flag survives).
    assert sorted(b["network"] for b in seen) == ["ETH", "POLYGON"]
    for b in seen:
        assert b["cache"] is True
        assert b["with_network"] is True       # auto-enabled
        assert "networks" not in b              # collapsed to single-network body
    # Concat + sort by time
    assert df.shape == (2, 3)
    times = df["time"].to_list()
    assert times == sorted(times)


@pytest.mark.asyncio
async def test_min_amount_propagates_to_each_network_body():
    """Regression for the bug where _resolve_path mutated self._body AFTER the
    per-network body snapshot, so /read/min calls were sent without min_amount."""
    from horatio_data_provider.erc20 import ERC20TransfersQuery

    q = (ERC20TransfersQuery(session=None, base_url="http://x", tokens=["USDT"])
         .network(["ETH", "POLYGON"])
         .min_amount(100)
         .time_range("2025-01-01", "2025-01-02")
         .cache())
    seen = []

    async def fake(_session, url, body):
        seen.append((url, body))
        return _table_for_network(body["network"], t0=1)

    with patch("horatio_data_provider.erc20.fetch_table", new=fake):
        await q.as_polars()

    # Both fan-out calls should hit /read/min and carry min_amount in the body.
    assert len(seen) == 2
    for url, body in seen:
        assert url.endswith("/evm/erc20_transfers/read/min"), url
        assert body.get("min_amount") == 100, body


@pytest.mark.asyncio
async def test_as_parquet_multi_network_concats_then_uploads_once():
    """Regression: multi-network as_parquet previously sent save_key to every
    worker, and they all clobbered the same file (last-network-wins). The
    fixed path strips save_key, fans out as a regular fetch, concats
    client-side, then POSTs the combined bytes to /snapshots/save once."""
    import httpx
    import respx

    q = (_build_query(body={})
         .network(["ETH", "POLYGON"])
         .time_range("2025-01-01", "2025-01-02"))
    fetch_calls = []

    async def fake_fetch(_session, _url, body):
        fetch_calls.append(body)
        return _table_for_network(body["network"], t0=int(body["network"][0], 36) % 10)

    async with httpx.AsyncClient() as client:
        q._session = client
        with respx.mock(base_url="http://x", assert_all_called=True) as mock:
            save_route = mock.post("/snapshots/save").mock(
                return_value=httpx.Response(200, json={"saved": True, "key": "k"})
            )
            with patch("horatio_data_provider._query.fetch_table", new=fake_fetch):
                await q.as_parquet("k")

    # Fan-out happened once per network and NEVER carried save_key.
    assert sorted(b["network"] for b in fetch_calls) == ["ETH", "POLYGON"]
    for b in fetch_calls:
        assert "save_key" not in b
    # A single combined save call landed on /snapshots/save with the key header.
    assert save_route.call_count == 1
    assert save_route.calls.last.request.headers["X-Snapshot-Key"] == "k"
    # Body is non-empty parquet bytes.
    assert len(save_route.calls.last.request.content) > 0


@pytest.mark.asyncio
async def test_as_parquet_single_network_uses_worker_save_path():
    """Single-network as_parquet still uses the legacy save_key path."""
    q = _build_query(body={}).network("ETH").time_range("2025-01-01", "2025-01-02")
    seen = []

    async def fake(_session, _url, body):
        # snapshot the body — as_parquet del's save_key in its finally clause,
        # so a reference would lose the key by the time we assert.
        seen.append(dict(body))
        return _table_for_network(body["network"], t0=1)

    with patch("horatio_data_provider._query.fetch_table", new=fake):
        await q.as_parquet("k")

    assert len(seen) == 1
    assert seen[0]["save_key"] == "k"
    # Cleanup: save_key removed from self._body after the call.
    assert "save_key" not in q._body


@pytest.mark.asyncio
async def test_explicit_with_network_false_overrides_auto():
    q = (_build_query()
         .network(["ETH", "POLYGON"])
         .with_network(False)
         .time_range("2025-01-01", "2025-01-02"))
    seen = []

    async def fake(_session, _url, body):
        seen.append(body)
        return _table_for_network(body["network"], t0=1)

    with patch("horatio_data_provider._query.fetch_table", new=fake):
        await q.as_polars()

    # User opted out — auto-enable does NOT clobber the False.
    for b in seen:
        assert b["with_network"] is False
