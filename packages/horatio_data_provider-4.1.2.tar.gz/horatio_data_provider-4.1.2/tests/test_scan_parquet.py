"""Tests for client.scan_parquet_polars(...) and ScanParquetQuery.

The server side (POST /snapshots/scan) is exercised via the integration
tests. Here we just verify the client builder accumulates filters
correctly and dispatches them with the right shape."""

from __future__ import annotations

import io

import httpx
import polars as pl
import pyarrow.parquet as pq
import pytest
import respx

from horatio_data_provider.snapshots import ScanParquetQuery


def _sample_parquet_bytes() -> bytes:
    df = pl.DataFrame({"sender": ["0xa"], "receiver": ["0xb"], "amount": [1.0]})
    buf = io.BytesIO()
    df.write_parquet(buf)
    return buf.getvalue()


@pytest.mark.asyncio
async def test_scan_parquet_dispatches_filters_to_server():
    sent = {}

    def capture(request: httpx.Request) -> httpx.Response:
        import json as _json
        sent["body"] = _json.loads(request.content)
        return httpx.Response(200, content=_sample_parquet_bytes())

    async with httpx.AsyncClient() as session:
        with respx.mock(base_url="http://x", assert_all_called=True) as mock:
            mock.post("/snapshots/scan").mock(side_effect=capture)
            q = ScanParquetQuery(session, "http://x", "snap1") \
                .local_exclude_sender_categories(["Hot-Wallet", "Cold-Wallet"]) \
                .local_involving_entities(["Binance"])
            df = await q.as_polars()

    assert sent["body"]["key"] == "snap1"
    assert sent["body"]["local_filters"] == [
        {"op": "exclude_sender_categories", "values": ["Hot-Wallet", "Cold-Wallet"]},
        {"op": "involving_entities", "values": ["Binance"]},
    ]
    assert "save_key" not in sent["body"]
    assert isinstance(df, pl.DataFrame)
    assert df.shape == (1, 3)


@pytest.mark.asyncio
async def test_as_pandas_returns_pandas():
    import pandas as pd

    async with httpx.AsyncClient() as session:
        with respx.mock(base_url="http://x", assert_all_called=True) as mock:
            mock.post("/snapshots/scan").mock(
                return_value=httpx.Response(200, content=_sample_parquet_bytes())
            )
            df = await ScanParquetQuery(session, "http://x", "snap1").as_pandas()
    assert isinstance(df, pd.DataFrame)


@pytest.mark.asyncio
async def test_as_parquet_passes_save_key_no_bytes_returned():
    sent = {}

    def capture(request: httpx.Request) -> httpx.Response:
        import json as _json
        sent["body"] = _json.loads(request.content)
        return httpx.Response(200, json={"saved": True, "key": "filtered"})

    async with httpx.AsyncClient() as session:
        with respx.mock(base_url="http://x", assert_all_called=True) as mock:
            mock.post("/snapshots/scan").mock(side_effect=capture)
            q = ScanParquetQuery(session, "http://x", "snap1") \
                .local_exclude_sender_categories(["Hot-Wallet"])
            await q.as_parquet("filtered")

    assert sent["body"]["save_key"] == "filtered"
    assert sent["body"]["key"] == "snap1"


@pytest.mark.asyncio
async def test_404_propagates_as_http_error():
    from horatio_data_provider._http import DataProviderHTTPError

    async with httpx.AsyncClient() as session:
        with respx.mock(base_url="http://x") as mock:
            mock.post("/snapshots/scan").mock(
                return_value=httpx.Response(404, json={"error": "Snapshot not found: missing"})
            )
            with pytest.raises(DataProviderHTTPError) as ei:
                await ScanParquetQuery(session, "http://x", "missing").as_polars()
    assert ei.value.status_code == 404


@pytest.mark.asyncio
async def test_engine_default_is_duckdb():
    """The default engine is duckdb; it's always sent explicitly so the
    server never has to guess."""
    sent = {}

    def capture(request: httpx.Request) -> httpx.Response:
        import json as _json
        sent["body"] = _json.loads(request.content)
        return httpx.Response(200, content=_sample_parquet_bytes())

    async with httpx.AsyncClient() as session:
        with respx.mock(base_url="http://x") as mock:
            mock.post("/snapshots/scan").mock(side_effect=capture)
            await ScanParquetQuery(session, "http://x", "snap1").as_polars()
    assert sent["body"]["engine"] == "duckdb"


@pytest.mark.asyncio
async def test_engine_polars_explicitly_passes_through():
    sent = {}

    def capture(request: httpx.Request) -> httpx.Response:
        import json as _json
        sent["body"] = _json.loads(request.content)
        return httpx.Response(200, content=_sample_parquet_bytes())

    async with httpx.AsyncClient() as session:
        with respx.mock(base_url="http://x") as mock:
            mock.post("/snapshots/scan").mock(side_effect=capture)
            await ScanParquetQuery(session, "http://x", "snap1", engine="polars").as_polars()
    assert sent["body"]["engine"] == "polars"


@pytest.mark.asyncio
async def test_engine_duckdb_passes_through():
    sent = {}

    def capture(request: httpx.Request) -> httpx.Response:
        import json as _json
        sent["body"] = _json.loads(request.content)
        return httpx.Response(200, content=_sample_parquet_bytes())

    async with httpx.AsyncClient() as session:
        with respx.mock(base_url="http://x") as mock:
            mock.post("/snapshots/scan").mock(side_effect=capture)
            await ScanParquetQuery(session, "http://x", "snap1", engine="duckdb") \
                .local_receiver_categories(["Hot-Wallet"]).as_polars()
    assert sent["body"]["engine"] == "duckdb"
    assert sent["body"]["local_filters"] == [
        {"op": "receiver_categories", "values": ["Hot-Wallet"]},
    ]


@pytest.mark.asyncio
async def test_empty_filter_list_is_a_noop_call():
    """No filter calls → body has no local_filters key (server treats absent
    as empty list)."""
    sent = {}

    def capture(request: httpx.Request) -> httpx.Response:
        import json as _json
        sent["body"] = _json.loads(request.content)
        return httpx.Response(200, content=_sample_parquet_bytes())

    async with httpx.AsyncClient() as session:
        with respx.mock(base_url="http://x") as mock:
            mock.post("/snapshots/scan").mock(side_effect=capture)
            await ScanParquetQuery(session, "http://x", "snap1").as_polars()

    assert "local_filters" not in sent["body"]
