"""Tests for the Hyperliquid client surface (data_provider 2.5.0 server)."""
from __future__ import annotations

import json

import httpx
import pytest
import respx

from horatio_data_provider import DataProviderClient

BASE = "http://test"


@pytest.fixture
def client():
    return DataProviderClient(BASE)


# ---------------------------------------------------------------------------
# Existing endpoints — now with new fluent setters
# ---------------------------------------------------------------------------

@respx.mock
@pytest.mark.asyncio
async def test_fills_skip_hip3_and_tokens(client, parquet_bytes):
    route = respx.post(f"{BASE}/hyperliquid/fills/read").mock(
        return_value=httpx.Response(
            200, content=parquet_bytes,
            headers={"content-type": "application/octet-stream"},
        )
    )
    await (
        client.hyperliquid.fills()
        .tokens("BTC", "ETH")
        .skip_hip3(True)
        .time_range("2026-01-01", "2026-01-02")
        .as_pandas()
    )
    assert route.called
    body = json.loads(route.calls[0].request.content)
    assert body["tokens"] == ["BTC", "ETH"]
    assert body["skip_hip3"] is True
    assert body["since"] == "2026-01-01T00:00:00Z"
    assert body["until"] == "2026-01-02T00:00:00Z"


@respx.mock
@pytest.mark.asyncio
async def test_fills_skip_hip3_omitted_by_default(client, parquet_bytes):
    """When skip_hip3 isn't called, it must not appear in the body (server default)."""
    route = respx.post(f"{BASE}/hyperliquid/fills/read").mock(
        return_value=httpx.Response(
            200, content=parquet_bytes,
            headers={"content-type": "application/octet-stream"},
        )
    )
    await client.hyperliquid.fills().time_range("2026-01-01", "2026-01-02").as_pandas()
    body = json.loads(route.calls[0].request.content)
    assert "skip_hip3" not in body


# ---------------------------------------------------------------------------
# Removed endpoint
# ---------------------------------------------------------------------------

def test_positions_removed(client):
    """The legacy positions() method must no longer exist on HyperliquidNamespace."""
    assert not hasattr(client.hyperliquid, "positions")


# ---------------------------------------------------------------------------
# New endpoints (2.4.x server)
# ---------------------------------------------------------------------------

@respx.mock
@pytest.mark.asyncio
async def test_trade_history_tokens_window(client, parquet_bytes):
    route = respx.post(f"{BASE}/hyperliquid/trade_history/read").mock(
        return_value=httpx.Response(
            200, content=parquet_bytes,
            headers={"content-type": "application/octet-stream"},
        )
    )
    await (
        client.hyperliquid.trade_history()
        .tokens("BTC")
        .window("5m")
        .skip_hip3(True)
        .time_range("2026-04-15T03:00:00Z", "2026-04-15T03:15:00Z")
        .as_polars()
    )
    body = json.loads(route.calls[0].request.content)
    assert body["tokens"] == ["BTC"]
    assert body["window"] == "5m"
    assert body["skip_hip3"] is True


@respx.mock
@pytest.mark.asyncio
async def test_position_history_wallets_window(client, parquet_bytes):
    route = respx.post(f"{BASE}/hyperliquid/position_history/read").mock(
        return_value=httpx.Response(
            200, content=parquet_bytes,
            headers={"content-type": "application/octet-stream"},
        )
    )
    await (
        client.hyperliquid.position_history()
        .wallets("0xaaa", "0xbbb")
        .window("5m")
        .per_token(True)
        .market_type("perp")
        .limit(500)
        .time_range("2026-04-15T03:00:00Z", "2026-04-15T03:15:00Z")
        .as_pandas()
    )
    body = json.loads(route.calls[0].request.content)
    assert body["wallets"] == ["0xaaa", "0xbbb"]
    assert body["window"] == "5m"
    assert body["per_token"] is True
    assert body["market_type"] == "perp"
    assert body["limit"] == 500


@respx.mock
@pytest.mark.asyncio
async def test_ohlcv_tokens_window(client, parquet_bytes):
    route = respx.post(f"{BASE}/hyperliquid/ohlcv/read").mock(
        return_value=httpx.Response(
            200, content=parquet_bytes,
            headers={"content-type": "application/octet-stream"},
        )
    )
    await (
        client.hyperliquid.ohlcv()
        .tokens("BTC")
        .window("5m")
        .time_range("2026-04-15T03:00:00Z", "2026-04-15T03:15:00Z")
        .as_pandas()
    )
    body = json.loads(route.calls[0].request.content)
    assert body["tokens"] == ["BTC"]
    assert body["window"] == "5m"
