#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from hebb import hebb

Mmax, fileNrMax, subNrMax = hebb(3., 5000, '/Users/anegri/OneDrive', NMassRank=5, survey=(3.,4.,100),
     M=1e12)
