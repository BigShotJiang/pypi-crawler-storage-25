"""Tags REST API wrapper.

Covers three endpoint groups:
- ``/api/tags`` — tag CRUD and tagged-issue listing
- ``/api/issues/{id}/tags`` — add/remove tags on issues
- ``/api/articles/{id}/tags`` — add/remove tags on articles
"""

from __future__ import annotations

from kd.api.http import HttpClient
from kd.models import FieldSet, Issue, Tag

_TAG_LIST_FIELDS = str(
    FieldSet(
        "id",
        "name",
        "untagOnResolve",
        owner=FieldSet("id", "name"),
        color=FieldSet("id", "background", "foreground"),
    )
)

_TAG_DETAIL_FIELDS = str(
    FieldSet(
        "id",
        "name",
        "untagOnResolve",
        owner=FieldSet("id", "name"),
        color=FieldSet("id", "background", "foreground"),
    )
)

_TAGGED_ISSUE_FIELDS = str(
    FieldSet(
        "id",
        "idReadable",
        "summary",
        "updated",
        project=FieldSet("id", "name", "shortName"),
    )
)


class TagsAPI:
    """Tags REST API wrapper (/api/tags, /api/issues/*/tags, /api/articles/*/tags)."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    # --- Tag CRUD ---

    def list_tags(
        self,
        top: int = 50,
        skip: int = 0,
        *,
        query: str | None = None,
    ) -> list[Tag]:
        params: dict[str, object] = {"$top": top, "$skip": skip}
        if query is not None:
            params["query"] = query
        data = self._http.get(
            "/tags",
            fields=_TAG_LIST_FIELDS,
            params=params,
        )
        return [Tag.model_validate(t) for t in data]

    def get_tag(self, tag_id: str) -> Tag:
        data = self._http.get(f"/tags/{tag_id}", fields=_TAG_DETAIL_FIELDS)
        return Tag.model_validate(data)

    def create_tag(self, name: str) -> Tag:
        data = self._http.post(
            "/tags",
            json={"name": name},
            fields=_TAG_DETAIL_FIELDS,
        )
        return Tag.model_validate(data)

    def update_tag(self, tag_id: str, name: str) -> Tag:
        data = self._http.post(
            f"/tags/{tag_id}",
            json={"name": name},
            fields=_TAG_DETAIL_FIELDS,
        )
        return Tag.model_validate(data)

    def delete_tag(self, tag_id: str) -> None:
        self._http.delete(f"/tags/{tag_id}")

    # --- Tagged issues ---

    def list_tag_issues(self, tag_id: str, top: int = 50, skip: int = 0) -> list[Issue]:
        data = self._http.get(
            f"/tags/{tag_id}/issues",
            fields=_TAGGED_ISSUE_FIELDS,
            params={"$top": top, "$skip": skip},
        )
        return [Issue.model_validate(i) for i in data]

    # --- Issue tags ---

    def add_tag_to_issue(self, issue_id: str, tag_id: str) -> None:
        self._http.post(f"/issues/{issue_id}/tags", json={"id": tag_id})

    def remove_tag_from_issue(self, issue_id: str, tag_id: str) -> None:
        self._http.delete(f"/issues/{issue_id}/tags/{tag_id}")

    # --- Article tags ---

    def add_tag_to_article(self, article_id: str, tag_id: str) -> None:
        self._http.post(f"/articles/{article_id}/tags", json={"id": tag_id})

    def remove_tag_from_article(self, article_id: str, tag_id: str) -> None:
        self._http.delete(f"/articles/{article_id}/tags/{tag_id}")
