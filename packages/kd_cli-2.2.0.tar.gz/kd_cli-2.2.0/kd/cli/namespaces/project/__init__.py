"""Project namespace: /project

Commands: list, create, show, configure, delete
API layer: YouTrack REST API (/api/admin/projects)
"""

from __future__ import annotations

from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import (
    OptionDeclaration,
    OptionLayer,
    ResolvedOptions,
    project_option,
)
from kd.exceptions import ValidationError


class ProjectListCommand(Command):
    """List all projects."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List all projects",
            requires_client=True,
            usage="kd /project list",
            examples=["kd /project list", "kd /project list --output json"],
            see_also=["/project show", "/project create"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        projects = client.projects.list()
        return [
            {
                "key": p.short_name,
                "name": p.name,
                "leader": p.leader.name if p.leader else "",
                "archived": p.archived,
            }
            for p in projects
        ]


class ProjectCreateCommand(Command):
    """Create a project."""

    def __init__(self) -> None:
        super().__init__(
            "create",
            "Create a project",
            requires_client=True,
            usage="kd /project create KEY NAME",
            long_description="KEY is the project short name (max 10 chars, uppercase + digits). "
            "NAME is the full project name.",
            examples=[
                'kd /project create FB "Feedback Board"',
                "kd /project create DEMO Demo",
            ],
            see_also=["/project list", "/project show"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 2:
            raise ValidationError("Usage: kd /project create KEY NAME")
        key = args[0]
        name = " ".join(args[1:])
        project = client.projects.create(name=name, short_name=key)
        return {"key": project.short_name, "name": project.name, "id": project.id}


class ProjectShowCommand(Command):
    """Show project details."""

    def __init__(self) -> None:
        super().__init__(
            "show",
            "Show project details",
            requires_client=True,
            usage="kd /project show KEY",
            examples=["kd /project show FB", "kd /project show FB --output json"],
            see_also=["/project list", "/project configure"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /project show KEY")
        project = client.projects.get(args[0])
        return {
            "key": project.short_name,
            "name": project.name,
            "description": project.description or "",
            "leader": project.leader.name if project.leader else "",
            "archived": project.archived,
            "id": project.id,
        }


class ProjectConfigureCommand(Command):
    """Configure project settings."""

    def __init__(self) -> None:
        super().__init__(
            "configure",
            "Configure project settings",
            requires_client=True,
            usage="kd /project configure KEY --time-tracking true",
            long_description="Configure project-level settings like time tracking.",
            examples=[
                "kd /project configure FB --time-tracking true",
                "kd /project configure FB --time-tracking false",
            ],
            see_also=["/project show"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="time-tracking",
                layer=OptionLayer.COMMAND,
                type=bool,
                required=True,
                help_text="Enable or disable time tracking",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /project configure KEY --time-tracking true|false")
        key = args[0]
        enabled = options.command["time-tracking"]
        settings = client.projects.configure_time_tracking(key, enabled)
        return {"project": key, "time_tracking": settings.enabled}


class ProjectDeleteCommand(Command):
    """Delete a project."""

    def __init__(self) -> None:
        super().__init__(
            "delete",
            "Delete a project",
            requires_client=True,
            usage="kd /project delete KEY",
            examples=["kd /project delete TST"],
            see_also=["/project list"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /project delete KEY")
        key = args[0]
        client.projects.delete(key)
        return {"ok": True, "action": "delete", "project": key}


class ProjectFieldListCommand(Command):
    """List custom fields for a project."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List custom fields for a project",
            requires_client=True,
            usage="kd /project/field list KEY [-p KEY] [--field NAME]",
            examples=[
                "kd /project/field list FB",
                "kd /project/field list -p FB",
                "kd /project/field list FB --field State",
                "kd /project/field list FB --output json",
            ],
            see_also=["/project show", "/issue create", "/issue update"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Project key"))
        self.register_option(
            OptionDeclaration(
                name="field",
                layer=OptionLayer.COMMAND,
                help_text="Show only this field and its values",
            )
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        positional = args[0] if args else None
        from_option = options.command.get("project")
        key = positional or from_option
        if not key:
            raise ValidationError("Usage: kd /project/field list KEY  (or --project/-p KEY)")

        fields = client.projects.list_fields(key)

        field_name = options.command.get("field")
        if field_name is not None:
            match = [f for f in fields if f.name == field_name]
            if not match:
                names = ", ".join(f.name for f in fields)
                raise ValidationError(
                    f"No field named '{field_name}' in project {key}. Available: {names}"
                )
            fields = match

        return [
            {
                "name": f.name,
                "type": f.field_type_id,
                "required": not f.can_be_empty,
                "values": ", ".join(v.name for v in f.bundle_values) if f.bundle_values else "",
            }
            for f in fields
        ]


def create_project_namespace() -> Namespace:
    """Build the /project namespace tree."""
    ns = Namespace("project", "Project management", path="project")
    ns.register_command("list", ProjectListCommand())
    ns.register_command("create", ProjectCreateCommand())
    ns.register_command("show", ProjectShowCommand())
    ns.register_command("configure", ProjectConfigureCommand())
    ns.register_command("delete", ProjectDeleteCommand())

    field_ns = Namespace("field", "Project custom fields", path="project/field")
    field_ns.register_command("list", ProjectFieldListCommand())
    ns.register_sub_namespace(field_ns)

    return ns
