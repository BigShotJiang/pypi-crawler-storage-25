"""Primer namespace: /primer, /primer/note, /primer/article.

Project-local knowledge capsule for LLM consumers.  Stores conventions,
key article references, and do's/don'ts in ``.kd /primer.yaml``.
"""

from __future__ import annotations

from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import (
    OptionDeclaration,
    OptionLayer,
    ResolvedOptions,
    project_option,
)
from kd.cli.input import resolve_text_input
from kd.cli.output import emit_warning
from kd.exceptions import KdError, NotFoundError, ValidationError
from kd.primer import (
    add_article,
    add_note,
    add_tag,
    clear_articles,
    clear_notes,
    clear_tags,
    load_primer,
    remove_article,
    remove_note,
    remove_tag,
    update_note,
)


def _assert_workspace_project(command: Command, options: ResolvedOptions) -> None:
    """Enforce the ``--project`` assertion on workspace-scoped primer commands.

    The primer lives in ``.kd/primer.yaml`` and has no project dimension:
    every workspace owns exactly one primer, and any entity (tag, article,
    issue) from any project the token can see can be pinned from that
    workspace.  ``--project`` is therefore accepted as an **assertion** of
    which workspace's primer the caller thinks it's editing, not an
    override that selects a different primer file.  Matches
    ``default_project`` → silent no-op; mismatches → raise so an agent
    running from the wrong workspace fails loud.
    """
    asserted = options.command.get("project")
    if not asserted:
        return
    # Read commands (/primer show, /primer/*/list) declare the flag for
    # symmetry with write commands but do not declare requires_config=True
    # so they work in a fresh workspace before `kd init`.  When no config
    # is loaded the assertion silently passes — the flag is accepted, the
    # user sees no "unknown option" rejection (KDCLI-84 symptom).
    if command._resolved_config is None:
        return
    current = command.config.default_project
    if current and asserted != current:
        raise ValidationError(
            f"Primer is workspace-scoped (one .kd/primer.yaml per workspace). "
            f"--project={asserted} does not match this workspace's "
            f"default_project={current}. Primer pinning does not restrict "
            f"which project an entity can belong to — you can pin {asserted} "
            f"entities from this workspace.  To edit a *different* workspace's "
            f"primer, run from that workspace."
        )


# ---------------------------------------------------------------------------
# /primer show (root default)
# ---------------------------------------------------------------------------


class PrimerShowCommand(Command):
    """Show the full project primer."""

    def __init__(self) -> None:
        super().__init__(
            "show",
            "Show project primer",
            usage="kd /primer show",
            long_description="Displays the full project primer — notes, pinned tags, "
            "pinned articles, and all other sections.  Returns an empty primer if "
            "none exists yet.",
            examples=[
                "kd /primer show",
                "kd /primer show --output json",
            ],
            see_also=["/primer/note list", "/primer/tag list", "/primer/article list"],
        )
        self.display_hint = "primer_show"

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this shows"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        return {
            "notes": [{"#": i + 1, "note": n} for i, n in enumerate(data.notes)],
            "tags": [{"name": t.name, "summary": t.summary or ""} for t in data.tags],
            "articles": [{"id": a.id, "summary": a.summary or ""} for a in data.articles],
        }


# ---------------------------------------------------------------------------
# /primer/note
# ---------------------------------------------------------------------------


class PrimerNoteListCommand(Command):
    """List all primer notes."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List primer notes",
            usage="kd /primer/note list",
            long_description="Lists all notes in the project primer with their 1-based index.",
            examples=["kd /primer/note list"],
            see_also=["/primer/note add", "/primer/note remove"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this reads"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        return [{"index": i + 1, "note": note} for i, note in enumerate(data.notes)]


class PrimerNoteAddCommand(Command):
    """Add a note to the primer."""

    def __init__(self) -> None:
        super().__init__(
            "add",
            "Add a primer note",
            requires_config=True,
            usage="kd /primer/note add TEXT",
            long_description="Appends a note to the project primer.  TEXT can be inline, "
            "@file to read from a file, or - to read from stdin.",
            examples=[
                'kd /primer/note add "Sprint field is called Board"',
                "kd /primer/note add @conventions.txt",
            ],
            see_also=["/primer/note list", "/primer/note remove"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/note add TEXT")
        text = resolve_text_input(" ".join(args))
        if not text:
            raise ValidationError("Note text cannot be empty")
        index = add_note(text)
        return {"ok": True, "action": "add", "index": index, "note": text}


class PrimerNoteRemoveCommand(Command):
    """Remove a note by index, or all notes with --all."""

    def __init__(self) -> None:
        super().__init__(
            "remove",
            "Remove a primer note by index or all notes",
            requires_config=True,
            usage="kd /primer/note remove INDEX | --all",
            long_description="Removes the note at the given 1-based index, or all notes "
            "if --all is passed.  Use '/primer/note list' to see current indices.",
            examples=[
                "kd /primer/note remove 2",
                "kd /primer/note remove --all",
            ],
            see_also=["/primer/note list", "/primer/note add"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text="Remove all notes",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if options.command.get("all"):
            count = clear_notes()
            return {"ok": True, "action": "clear", "removed": count}
        if not args:
            raise ValidationError("Usage: kd /primer/note remove INDEX | --all")
        try:
            index = int(args[0])
        except ValueError:
            raise ValidationError(f"INDEX must be a number, got: {args[0]}") from None
        removed = remove_note(index)
        return {"ok": True, "action": "remove", "index": index, "note": removed}


class PrimerNoteUpdateCommand(Command):
    """Replace a note by index."""

    def __init__(self) -> None:
        super().__init__(
            "update",
            "Replace a primer note by index",
            requires_config=True,
            usage="kd /primer/note update INDEX TEXT",
            long_description="Replaces the note at the given 1-based index with new text.  "
            "TEXT can be inline, @file to read from a file, or - to read from stdin.  "
            "Use '/primer/note list' to see current indices.",
            examples=[
                'kd /primer/note update 1 "Updated convention"',
                "kd /primer/note update 2 @updated.txt",
            ],
            see_also=["/primer/note list", "/primer/note remove"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/note update INDEX TEXT")
        try:
            index = int(args[0])
        except ValueError:
            raise ValidationError(f"INDEX must be a number, got: {args[0]}") from None
        if len(args) < 2:
            raise ValidationError("Usage: kd /primer/note update INDEX TEXT")
        text = resolve_text_input(" ".join(args[1:]))
        if not text:
            raise ValidationError("Note text cannot be empty")
        old = update_note(index, text)
        return {"ok": True, "action": "update", "index": index, "old": old, "new": text}


# ---------------------------------------------------------------------------
# /primer/article
# ---------------------------------------------------------------------------


class PrimerArticleListCommand(Command):
    """List pinned articles."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List pinned articles",
            usage="kd /primer/article list",
            long_description="Lists all articles pinned in the project primer.",
            examples=["kd /primer/article list"],
            see_also=["/primer/article add", "/primer/article remove"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this reads"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        return [{"id": a.id, "summary": a.summary or ""} for a in data.articles]


class PrimerArticleAddCommand(Command):
    """Pin an article to the primer."""

    def __init__(self) -> None:
        super().__init__(
            "add",
            "Pin an article to the primer",
            requires_config=True,
            usage="kd /primer/article add ARTICLE_ID [--summary S]",
            long_description="Adds a YouTrack article reference to the project primer.  "
            "Use --summary to store a description alongside the ID.",
            examples=[
                "kd /primer/article add FB-A-42",
                'kd /primer/article add FB-A-42 --summary "Architecture Overview"',
            ],
            see_also=["/primer/article list", "/primer/article remove"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="summary",
                short_name="s",
                layer=OptionLayer.COMMAND,
                help_text="Description to store with the article reference",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/article add ARTICLE_ID")
        article_id = args[0]
        summary = options.command.get("summary")
        article = add_article(article_id, summary=summary)
        result: dict[str, Any] = {"ok": True, "action": "add", "id": article.id}
        if article.summary:
            result["summary"] = article.summary
        return result


class PrimerArticleRemoveCommand(Command):
    """Unpin an article by ID, or all articles with --all."""

    def __init__(self) -> None:
        super().__init__(
            "remove",
            "Unpin an article or all articles",
            requires_config=True,
            usage="kd /primer/article remove ARTICLE_ID | --all",
            long_description="Removes the article with the given ID from the primer, "
            "or all pinned articles if --all is passed.",
            examples=[
                "kd /primer/article remove FB-A-42",
                "kd /primer/article remove --all",
            ],
            see_also=["/primer/article list", "/primer/article add"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text="Remove all pinned articles",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if options.command.get("all"):
            count = clear_articles()
            return {"ok": True, "action": "clear", "removed": count}
        if not args:
            raise ValidationError("Usage: kd /primer/article remove ARTICLE_ID | --all")
        removed = remove_article(args[0])
        return {"ok": True, "action": "remove", "id": removed.id}


# ---------------------------------------------------------------------------
# /primer/tag
# ---------------------------------------------------------------------------


class PrimerTagListCommand(Command):
    """List pinned tags."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List pinned tags",
            usage="kd /primer/tag list",
            long_description="Lists all tags pinned in the project primer.  Pinned "
            "tags act as the OR scope for `kd /tag entities --primer-scope`.",
            examples=["kd /primer/tag list"],
            see_also=["/primer/tag add", "/primer/tag remove", "/tag entities"],
        )

    def _register_options(self) -> None:
        self.register_option(project_option(help_text="Assert which project's primer this reads"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        data = load_primer()
        return [{"name": t.name, "summary": t.summary or ""} for t in data.tags]


class PrimerTagAddCommand(Command):
    """Pin a tag to the primer."""

    def __init__(self) -> None:
        super().__init__(
            "add",
            "Pin a tag to the primer",
            requires_config=True,
            requires_client=True,
            usage="kd /primer/tag add TAG_NAME [--summary S]",
            long_description="Adds a tag to the project primer.  Upstream existence "
            "is validated via the tag namespace: tags not found upstream are still "
            "written but return a `tag_not_found` warning — this supports declaring "
            "tag intent before the tag is created.  A failed validation call "
            "(network / auth / timeout) writes the entry with a "
            "`tag_validation_skipped` warning so a local primer edit is not "
            "silently blocked by an unreachable server.",
            examples=[
                "kd /primer/tag add kind:incident",
                'kd /primer/tag add kind:incident --summary "Active incidents"',
            ],
            see_also=["/primer/tag list", "/primer/tag remove", "/tag entities"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="summary",
                short_name="s",
                layer=OptionLayer.COMMAND,
                help_text="Description to store with the tag reference",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if not args:
            raise ValidationError("Usage: kd /primer/tag add TAG_NAME")
        name = args[0]
        summary = options.command.get("summary")

        warning: dict[str, Any] | None = None
        try:
            client.tags.get(name)
        except NotFoundError as exc:
            warning = emit_warning(
                "tag_not_found",
                f"Tag '{name}' not found upstream — pinning anyway (declare-intent).",
                name=name,
                detail=str(exc),
            )
        except KdError as exc:
            warning = emit_warning(
                "tag_validation_skipped",
                f"Could not validate tag '{name}' upstream ({type(exc).__name__}) — "
                "pinning the entry; verify the name when the upstream is reachable.",
                name=name,
                error_code=type(exc).__name__,
                detail=str(exc),
            )

        tag = add_tag(name, summary=summary)
        result: dict[str, Any] = {"ok": True, "action": "add", "name": tag.name}
        if tag.summary:
            result["summary"] = tag.summary
        if warning is not None:
            result["warnings"] = [warning]
        return result


class PrimerTagRemoveCommand(Command):
    """Unpin a tag by name, or all tags with --all."""

    def __init__(self) -> None:
        super().__init__(
            "remove",
            "Unpin a tag or all tags",
            requires_config=True,
            usage="kd /primer/tag remove TAG_NAME | --all",
            long_description="Removes the tag with the given name from the primer, "
            "or all pinned tags if --all is passed.  Local-only edit — no upstream "
            "call.",
            examples=[
                "kd /primer/tag remove kind:incident",
                "kd /primer/tag remove --all",
            ],
            see_also=["/primer/tag list", "/primer/tag add"],
        )

    def _register_options(self) -> None:
        self.register_option(
            OptionDeclaration(
                name="all",
                layer=OptionLayer.COMMAND,
                type=bool,
                default=False,
                help_text="Remove all pinned tags",
            )
        )
        self.register_option(project_option(help_text="Assert which project's primer this edits"))

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        _assert_workspace_project(self, options)
        if options.command.get("all"):
            count = clear_tags()
            return {"ok": True, "action": "clear", "removed": count}
        if not args:
            raise ValidationError("Usage: kd /primer/tag remove TAG_NAME | --all")
        removed = remove_tag(args[0])
        return {"ok": True, "action": "remove", "name": removed.name}


# ---------------------------------------------------------------------------
# Namespace factory
# ---------------------------------------------------------------------------


def create_primer_namespace() -> Namespace:
    """Build the /primer namespace with /primer/note and /primer/article."""
    ns = Namespace(
        "primer",
        "Project primer — local knowledge for LLM consumers",
        path="primer",
    )
    ns.register_command("show", PrimerShowCommand())

    # /primer/note
    note_ns = Namespace("note", "Primer notes and conventions", path="primer/note")
    note_ns.register_command("list", PrimerNoteListCommand())
    note_ns.register_command("add", PrimerNoteAddCommand())
    note_ns.register_command("remove", PrimerNoteRemoveCommand())
    note_ns.register_command("update", PrimerNoteUpdateCommand())
    ns.register_sub_namespace(note_ns)

    # /primer/tag
    tag_ns = Namespace(
        "tag",
        "Pinned tag references",
        path="primer/tag",
    )
    tag_ns.register_command("list", PrimerTagListCommand())
    tag_ns.register_command("add", PrimerTagAddCommand())
    tag_ns.register_command("remove", PrimerTagRemoveCommand())
    ns.register_sub_namespace(tag_ns)

    # /primer/article
    article_ns = Namespace(
        "article",
        "Pinned article references",
        path="primer/article",
    )
    article_ns.register_command("list", PrimerArticleListCommand())
    article_ns.register_command("add", PrimerArticleAddCommand())
    article_ns.register_command("remove", PrimerArticleRemoveCommand())
    ns.register_sub_namespace(article_ns)

    return ns
