"""User namespace: /user

Commands: list, create, delete
API layer: Hub REST API (/hub/api/rest/users)
"""

from __future__ import annotations

from typing import Any

from kd.cli.core.command_base import Command, CommandResult
from kd.cli.core.namespaces import Namespace
from kd.cli.core.option_registry import ResolvedOptions
from kd.exceptions import ValidationError


class UserListCommand(Command):
    """List users."""

    def __init__(self) -> None:
        super().__init__(
            "list",
            "List users",
            requires_client=True,
            usage="kd /user list",
            examples=["kd /user list"],
            see_also=["/user create"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        users = client.users.list()
        return [
            {
                "login": u.login,
                "name": u.name,
                "email": u.email or "",
                "banned": u.banned,
            }
            for u in users
        ]


class UserCreateCommand(Command):
    """Create a user."""

    def __init__(self) -> None:
        super().__init__(
            "create",
            "Create a user",
            requires_client=True,
            usage="kd /user create LOGIN NAME EMAIL",
            examples=['kd /user create testbot "Test Bot" testbot@example.com'],
            see_also=["/user list", "/user delete"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if len(args) < 3:
            raise ValidationError("Usage: kd /user create LOGIN NAME EMAIL")
        user = client.users.create(login=args[0], name=args[1], email=args[2])
        return {
            "login": user.login,
            "name": user.name,
            "email": user.email or "",
        }


class UserDeleteCommand(Command):
    """Delete a user."""

    def __init__(self) -> None:
        super().__init__(
            "delete",
            "Delete a user",
            requires_client=True,
            usage="kd /user delete HUB_USER_ID",
            examples=["kd /user delete abc-123"],
            see_also=["/user list"],
        )

    def execute(
        self, args: list[str], options: ResolvedOptions, client: Any = None
    ) -> CommandResult:
        if not args:
            raise ValidationError("Usage: kd /user delete HUB_USER_ID")
        client.users.delete(args[0])
        return {"ok": True, "action": "delete", "user": args[0]}


def create_user_namespace() -> Namespace:
    """Build the /user namespace tree."""
    ns = Namespace("user", "User management", path="user")
    ns.register_command("list", UserListCommand())
    ns.register_command("create", UserCreateCommand())
    ns.register_command("delete", UserDeleteCommand())
    return ns
