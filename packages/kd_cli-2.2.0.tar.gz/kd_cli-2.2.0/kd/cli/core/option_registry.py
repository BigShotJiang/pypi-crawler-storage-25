"""Option declaration and resolution.

Two option layers for kd:
- COMMAND: command-specific options (--project, --query, --limit)
- OUTPUT: output formatting options (--output, --fields)

Options are declared per-command and resolved by the parser.
Global options (--connection, --help, --version, --debug, --reference)
are handled separately in main.py, outside the layer system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class OptionLayer(Enum):
    """Option layers — separates options by concern."""

    GLOBAL = "global"
    COMMAND = "command"
    OUTPUT = "output"


@dataclass
class OptionDeclaration:
    """Metadata for a single CLI option."""

    name: str
    layer: OptionLayer
    type: type = str
    short_name: str | None = None
    default: Any = None
    choices: list[str] | None = None
    required: bool = False
    help_text: str = ""
    is_list: bool = False
    aliases: list[str] = field(default_factory=list)


@dataclass
class ResolvedOptions:
    """Parsed and validated options, organized by layer."""

    command: dict[str, Any] = field(default_factory=dict)
    output: dict[str, Any] = field(default_factory=dict)

    def get_layer(self, layer: OptionLayer) -> dict[str, Any]:
        """Get options dict for a specific layer."""
        if layer == OptionLayer.COMMAND:
            return self.command
        return self.output


class OptionRegistry:
    """Manages option declarations and resolves raw option dicts."""

    def __init__(self) -> None:
        self._declarations: dict[str, OptionDeclaration] = {}
        self._short_names: dict[str, str] = {}  # short_name -> full name
        self._aliases: dict[str, str] = {}  # alias -> canonical name

    def register(self, declaration: OptionDeclaration) -> None:
        """Register an option declaration."""
        self._declarations[declaration.name] = declaration
        if declaration.short_name:
            self._short_names[declaration.short_name] = declaration.name
        for alias in declaration.aliases:
            self._aliases[alias] = declaration.name

    def register_all(self, declarations: list[OptionDeclaration]) -> None:
        """Register multiple declarations."""
        for decl in declarations:
            self.register(decl)

    def get_declaration(self, name: str) -> OptionDeclaration | None:
        """Look up declaration by name, short name, or alias."""
        if name in self._declarations:
            return self._declarations[name]
        full_name = self._short_names.get(name) or self._aliases.get(name)
        if full_name:
            return self._declarations[full_name]
        return None

    def resolve_name(self, name: str) -> str | None:
        """Resolve a short name or alias to its canonical name. Returns None if unknown."""
        if name in self._declarations:
            return name
        return self._short_names.get(name) or self._aliases.get(name)

    def is_boolean_flag(self, name: str) -> bool:
        """Check if an option is a boolean flag (no value expected)."""
        decl = self.get_declaration(name)
        return decl is not None and decl.type is bool

    def is_list_option(self, name: str) -> bool:
        """Check if an option is a repeatable list option."""
        decl = self.get_declaration(name)
        return decl is not None and decl.is_list

    def resolve(self, raw: dict[str, Any]) -> ResolvedOptions:
        """Resolve raw options dict into layered ResolvedOptions.

        Validates types, choices, and required options.
        Applies defaults for missing options.
        """
        result = ResolvedOptions()

        # Apply provided values
        for raw_name, value in raw.items():
            full_name = self.resolve_name(raw_name)
            if full_name is None:
                raise OptionError(f"Unknown option: --{raw_name}")
            decl = self._declarations[full_name]
            validated = self._validate_value(decl, value)
            result.get_layer(decl.layer)[decl.name] = validated

        # Apply defaults and check required
        for decl in self._declarations.values():
            layer_dict = result.get_layer(decl.layer)
            if decl.name not in layer_dict:
                if decl.required:
                    raise OptionError(f"Required option missing: --{decl.name}")
                if decl.is_list:
                    layer_dict[decl.name] = []
                elif decl.default is not None:
                    layer_dict[decl.name] = decl.default

        return result

    def _validate_value(self, decl: OptionDeclaration, value: Any) -> Any:
        """Validate and coerce an option value (single or list)."""
        if decl.is_list:
            items = value if isinstance(value, list) else [value]
            return [self._validate_single(decl, v) for v in items]
        return self._validate_single(decl, value)

    def _validate_single(self, decl: OptionDeclaration, value: Any) -> Any:
        """Validate and coerce a single option value."""
        if decl.type is bool:
            if isinstance(value, bool):
                return value
            if isinstance(value, str):
                if value.lower() in ("true", "1", "yes"):
                    return True
                if value.lower() in ("false", "0", "no"):
                    return False
            raise OptionError(f"Invalid boolean value for --{decl.name}: {value}")

        if decl.type is int:
            try:
                return int(value)
            except (ValueError, TypeError):
                raise OptionError(f"Expected integer for --{decl.name}: {value}") from None

        if decl.type is float:
            try:
                return float(value)
            except (ValueError, TypeError):
                raise OptionError(f"Expected number for --{decl.name}: {value}") from None

        # str type — check choices
        str_value = str(value)
        if decl.choices and str_value not in decl.choices:
            choices_str = ", ".join(decl.choices)
            raise OptionError(
                f"Invalid value for --{decl.name}: '{str_value}'. Choose from: {choices_str}"
            )
        return str_value


class OptionError(Exception):
    """Raised when option parsing or validation fails."""


# ---------------------------------------------------------------------------
# Shared COMMAND option builders
# ---------------------------------------------------------------------------
# Factory functions for recurring options. Commands opt in by calling the
# builder in _register_options(). Flags and short names are locked; callers
# may override help_text, required, and default.


def project_option(
    *, help_text: str = "Filter by project key", required: bool = False
) -> OptionDeclaration:
    """``--project / -p`` — project key filter."""
    return OptionDeclaration(
        name="project",
        short_name="p",
        layer=OptionLayer.COMMAND,
        help_text=help_text,
        required=required,
    )


def limit_option(
    *, default: int = 50, help_text: str = "Maximum number of results"
) -> OptionDeclaration:
    """``--limit / -l`` — result cap."""
    return OptionDeclaration(
        name="limit",
        short_name="l",
        layer=OptionLayer.COMMAND,
        type=int,
        default=default,
        help_text=help_text,
    )


def type_option(*, help_text: str = "Issue type (Bug, Task, Feature, etc.)") -> OptionDeclaration:
    """``--type / -T`` — issue type field."""
    return OptionDeclaration(
        name="type",
        short_name="T",
        layer=OptionLayer.COMMAND,
        help_text=help_text,
    )


def priority_option(
    *, help_text: str = "Priority (Critical, Major, Normal, Minor)"
) -> OptionDeclaration:
    """``--priority / -P`` — issue priority field."""
    return OptionDeclaration(
        name="priority",
        short_name="P",
        layer=OptionLayer.COMMAND,
        help_text=help_text,
    )


def state_option(
    *,
    help_text: str = "State (Submitted, Open, etc.). See: /project/field list KEY --field State",
) -> OptionDeclaration:
    """``--state / -S`` — issue state field."""
    return OptionDeclaration(
        name="state",
        short_name="S",
        layer=OptionLayer.COMMAND,
        help_text=help_text,
    )


# Standard OUTPUT options available to all commands
OUTPUT_OPTIONS: list[OptionDeclaration] = [
    OptionDeclaration(
        name="output",
        short_name="o",
        layer=OptionLayer.OUTPUT,
        type=str,
        choices=["table", "json", "yaml", "md"],
        help_text="Output format: table|json|yaml|md (default: table)",
    ),
    OptionDeclaration(
        name="fields",
        short_name="f",
        layer=OptionLayer.OUTPUT,
        type=str,
        help_text="Comma-separated field list",
    ),
]
