"""Tag models."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from kd.models.common import IdEntity, NamedEntity


class TagColor(BaseModel):
    """Tag color with hex foreground/background values."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    background: str | None = None
    foreground: str | None = None


class Tag(IdEntity):
    """YouTrack tag.

    Tags are shared entities that can be applied to both issues and articles.
    The ``owner`` field is populated when detail fields are requested.
    """

    name: str
    owner: NamedEntity | None = None
    color: TagColor | None = None
    untag_on_resolve: bool = Field(default=False, alias="untagOnResolve")
