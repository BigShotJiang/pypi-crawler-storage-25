# kd Operating Guide

This guide is the prose companion to `kd --reference`. Use `kd --reference` for the exact command catalog. Use this guide for the operating model, safe command composition, cost expectations, and YouTrack-specific gotchas that are easy to miss from syntax alone.

## What kd Is

kd is a knowledge-network tool for YouTrack-backed work. Its primary loop is:

1. Pull context from live systems.
2. Reason over that context in the operator's head or an LLM session.
3. Push focused updates back.

The primer is the canonical shape: a small local `.kd/primer.yaml` file with curated notes and pinned references that sits on top of live systems. It does not replace YouTrack. It tells the operator what matters before they start pulling issues, articles, tags, queries, and project metadata.

The CLI is SDK-first. Commands are thin wrappers over `kd.client`; business behavior belongs in the SDK and API layers. This matters for LLMs because command behavior should be predictable and repeatable across the terminal, scripts, and programmatic use.

## What kd Is Not

kd is not a migration platform, a data warehouse, or a hidden local mirror of YouTrack.

Cross-system moves should stay thin and deliberate. The default knowledge-network move is a stub or reference with a backref to the source, not a faithful copy of every field. Same-provider import/export can preserve more, but that is the corner case, not the product center.

Avoid designing workflows that turn kd into bulk synchronization, silent lossy migration, or a replacement database. If a proposed feature stops looking primer-shaped, it probably needs a proposal before implementation.

## First Read Workflow

For a fresh repository or an LLM session, start with the durable context:

```bash
kd /primer show -o yaml
kd --reference
```

Then pull live context narrowly:

```bash
kd /issue show KDCLI-42 -o yaml
kd /article show KDCLI-A-12 -o yaml
kd /tag entities kind:note --project KDCLI -o yaml
kd /tag entities --primer-scope -o yaml
```

Read the primer before deciding which live queries to run. Use pinned articles for durable background. Use pinned tags as the workspace's curated content-management pivots. `kd /tag entities --primer-scope` expands those pinned tags into an explicit OR scope across issues and articles, which is usually the fastest way to see what the workspace says matters right now. Use saved queries for recurring issue searches, not for article full-text search.

## Command Composition Rules

Prefer explicit context when composing commands:

```bash
kd -c support /issue list --project KDCLI -o json
```

Use `-o json` or `-o yaml` for LLM and script consumption. Table output is for humans. kd does not auto-switch output when stdout is piped, by design. The same command has the same output shape unless you pass a different `--output`.

Use `--fields` only as an output projection. It filters returned keys or columns; it does not request more upstream data. When a command has a separate upstream-expansion flag, such as `/issue list --with-tags`, pass that flag explicitly.

For aggregate commands, read metadata before deciding success. `/tag entities` can return partial results with exit 0 when one kind succeeds and another kind fails. Check `meta.<kind>.scanned`, `meta.<kind>.complete`, `meta.<kind>.truncated`, and `meta.<kind>.error`.

`/tag entities --primer-scope` is an explicit curated-scope shortcut. It reads tags pinned in `.kd/primer.yaml` and matches entities tagged with any pinned tag. It is mutually exclusive with positional `TAG` and repeatable `--tag` arguments because explicit tag filters use intersection semantics, while primer scope is intentionally a union.

Mutation commands return structured payloads in JSON/YAML mode. Scripts and LLMs should read `ok`, `action`, and entity IDs rather than parse prose.

Some successful commands may also return `warnings: [{code, message, context}]`. Treat warnings as advisory, not failures. The first common case is `/primer/tag add`, which may write the local primer entry while warning that upstream tag validation failed or found no current tag by that name.

## Cost And Safety Model

Not every read has the same cost.

**Direct reads** fetch one entity or one server-side page. Examples: `/issue show`, `/article show`, `/project show`, `/tag show`, `/query show`.

**Query-backed reads** rely on an upstream query or filter. Examples: `/issue list --query`, `/query issues`, `/tag issues`, `/tag list --prefix`, `/tag list --namespace`. They are usually cheap but still depend on YouTrack query semantics.

**Scan-backed reads** walk pages and filter client-side because YouTrack has no matching endpoint. Examples: `/tag articles`, the article half of `/tag entities`, article substring search in `/search`, and deep `/article tree` traversal. Use limits and project scoping.

Write-side commands do not prompt for confirmation unless their help says so. Pair destructive or broad operations with a read first:

```bash
kd /issue show KDCLI-42 -o yaml
kd /issue update KDCLI-42 --state Fixed -o yaml
```

For article push, use `--dry-run` before a risky write and inspect conflicts with `/article pull`.

## YouTrack Gotchas

YouTrack articles are not queryable like issues. `/api/articles` has no issue-style `query` parameter, and there is no server-side article-by-tag endpoint. kd article tag lookup scans article pages that include `tags(id,name)` and filters locally.

Saved queries are YouTrack issue-search objects. `/query issues` executes them directly. `/query articles` only translates supported `project:` and `tag:` fields into article scans; issue-specific fields such as state or assignee are rejected for articles.

Tag names with colons or spaces need YouTrack query literal handling. `tag: type:case` is wrong; YouTrack reads `type` as the tag value and `case` as another field. Use `tag: {type:case}` in hand-written queries. kd command paths that compose tag queries use the shared literal helper.

Repeated same-field clauses in YouTrack query syntax default to OR. `tag: A tag: B` matches either tag. kd multi-tag issue operations join tag clauses with explicit `and` when intersection is required.

Issue custom fields are project-specific and need `$type` discriminators on mutation. Prefer semantic options such as `--state`, `--type`, and `--priority` for common fields, and inspect project fields before using generic `--field NAME=VALUE`:

```bash
kd /project/field list KDCLI
```

Attachment metadata download URLs may start with `/api/`. kd handles this internally on download commands; do not assume the raw URL can be appended unchanged to an API base URL in custom scripts.

Tag existence, tag visibility, and tag sharing rights are different concerns. A visible tag may not be usable for every operation, and sharing settings are provider-specific security posture, not just display metadata.

## Primer Practices

Primer notes should capture durable project rules, not temporary status. Good notes explain naming conventions, required workflows, dangerous assumptions, and pointers to canonical references.

Do not use the primer as a session log. Avoid recording current focus, completed session lists, release-cadence details copied from a plan, or other progress facts that can become false by the next agent session. If the primer needs to point at active work, stop at the current master plan or equivalent planning document; the agent should open that document and derive the next step from there.

Pinned tags should capture the workspace's current content-management lens: the tag pivots that define what to read first, what to maintain, and where related issues and articles cluster. They are not a complete taxonomy. They are the small curated set that makes `--primer-scope` useful.

The primer stores pinned tags as a top-level `tags:` block:

```yaml
tags:
  - name: kind:incident
    summary: Active incident investigations
```

Manage that block through kd rather than editing YAML by hand:

```bash
kd /primer/tag add kind:incident --summary "Active incident investigations"
kd /primer/tag list -o yaml
kd /primer/tag remove kind:incident
```

`/primer/tag add` validates the tag name against YouTrack when a connection is configured and reachable. If the tag is not found, kd still writes the local primer entry and returns a `tag_not_found` warning so a planned taxonomy can be declared before every tag exists upstream. If validation cannot run because the server is unreachable, kd writes the entry and returns `tag_validation_skipped`. If no usable connection or token is configured, the command fails and does not edit the primer.

Pinned articles should be few and high-signal. They are starting points for reasoning, not an export of the knowledge base.

When both pinned tags and pinned articles exist, read them in order: notes tell you how to think, tags tell you where live content clusters, and articles provide the deeper durable references.

Keep the primer local and curated. If a note becomes generally true for kd, move it into docs or this guide. If it is workspace-specific, keep it in `.kd/primer.yaml`.

## Articles And Push

Use `/article show` for metadata plus rendered content. Use `/article pull` when you need raw article content on stdout; `pull` is format-agnostic and ignores `--output`.

`/article push` is an idempotent file-to-YouTrack workflow. After first push, the local file contains a `<!-- kd-meta ... -->` marker and is owned by push. Commit that marker with the file. It is the identity key that prevents duplicate articles and detects remote edits.

Do not use push for one-off web edits or broad tree migration. It is single-file by design. If the remote changed, pull, diff, merge by hand, then push again. Use `--force` only after inspecting the remote state.

## Tags And Discovery

Tags are the main YouTrack-native cross-entity discovery primitive. A namespaced taxonomy such as `kind:*`, `component:*`, and `outcome:*` gives both humans and LLMs a stable way to move across issues and articles.

Start by discovering existing tag names:

```bash
kd /tag list --namespace kind -o yaml
kd /tag list --prefix component: -o yaml
```

Then query membership:

```bash
kd /tag issues kind:note --tag component:authservice -o yaml
kd /tag articles kind:note --tag component:authservice -o yaml
kd /tag entities kind:note --tag component:authservice -o yaml
kd /tag entities --primer-scope -o yaml
```

Use `/tag entities` when the question is "what do we know about this topic across kinds?" Explicit tags mean intersection: `kind:note --tag component:authservice` finds entities that have both tags. Primer scope means union: `--primer-scope` finds entities that have any pinned tag. Use `/tag issues` or `/tag articles` when the kind is already known.

Do not treat `--primer-scope` as implicit global state. It is a deliberate flag for content-management triage and workspace orientation. When you need a precise topical intersection, pass the tags explicitly.

## Output And Debugging

For deterministic machine consumption, always pass an explicit output format:

```bash
kd /issue list --project KDCLI -o json
kd /primer show -o yaml
```

Raise debug detail progressively:

```bash
kd -D /issue list --project KDCLI
kd -DD /issue list --project KDCLI
kd -DDD /issue list --project KDCLI
```

Debug output goes to stderr and tokens are redacted. Use `-DDD` when investigating upstream API behavior because it includes request and response details.

If config resolution is confusing, inspect it directly:

```bash
kd /system/config list
kd /system/config which issue_list.limit
kd /system/config which primer_show.output
```

If a command exits 0 but includes `warnings` in JSON or YAML, keep the primary result and inspect the warning code. For example, `tag_not_found` on `/primer/tag add` means the local primer changed but the upstream tag did not resolve at validation time.

## Where To Go Next

Use these sources together:

- `kd --reference` for exact command syntax.
- `kd /primer show -o yaml` for workspace context.
- `docs/user/01-kd-usage-guide.md` for scenario-driven workflows.
- `docs/how-to/` for task-specific guides.
- `docs/knowledge/` for verified YouTrack API gotchas.
- `docs/design/architecture.md` and ADRs for architectural constraints.

---
Updated: 2026-04-18
