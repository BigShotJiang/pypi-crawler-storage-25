"""Tests for rust plugin."""
