def ML_PRG(option: int):
    """Prints a specific message based on the provided option."""
    match option:
        case 1:
            print('''
import numpy as np

# Read CSV file
data = pd.read_csv('/content/adaline.csv')

data = data.fillna(data.mean(numeric_only=True))

# Features and target
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values


from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()

X = scaler.fit_transform(X)


class Adaline:
  def __init__(self, lr=0.01, epochs=100):
    self.lr = lr
    self.epochs = epochs

  def fit(self, X, y):
    self.w = np.zeros(X.shape[1])
    self.b = 0

    for _ in range(self.epochs):
      output = np.dot(X, self.w) + self.b
      error = y - output
      self.w += self.lr* np.dot(X.T, error)
      self.b += self.lr * error.sum()

  def predict(self, X):
    output = np.dot(X, self.w)+self.b
    return np.where(output>= 0, 1,-1)



model = Adaline(lr=0.01, epochs=20)

model.fit(X, y)

pred = model.predict(X)

print("Predictions:", pred)

print("Weights:", model.w)


print("Bias:", model.b)

                    
                ''')
            


        case 2:
            print('''
import pandas as pd

# Read dataset
data = pd.read_csv('/content/finds.csv')

# Convert dataset into list
concepts = data.values.tolist()

# Initialize specific hypothesis
# 1. Initialize S to the first POSITIVE example
S = None
for row in concepts:
    if row[-1] == 'Yes':
        S = row[:-1].copy() # Get features of the first 'Yes'
        break

if S is None:
    raise ValueError("Dataset must contain at least one positive example.")


print("Initial Specific Hypothesis:")
print(S)

# Candidate Elimination Algorithm
for row in concepts:

    # Check positive example
    if row[-1] == "Yes":

        for i in range(len(S)):

            if S[i] != row[i]:

                S[i] = '?'

print("Final Specific Hypothesis:")
print(S)''')

            

        case 3:
            print('''
import pandas as pd

# Read dataset
data = pd.read_csv('/content/finds.csv')
rows = data.values.tolist()

# 1. Initialize S to the first POSITIVE example
S = None
for row in rows:
    if row[-1] == 'Yes':
        S = row[:-1].copy() # Get features of the first 'Yes'
        break

if S is None:
    raise ValueError("Dataset must contain at least one positive example.")

# 2. Initialize G to the most general hypothesis
G = [['?' for _ in range(len(S))]]

# 3. Candidate Elimination Loop
for row in rows:
    features = row[:-1]
    label = row[-1]

    # --- POSITIVE EXAMPLES ---
    if label == 'Yes':
        # Generalize S: if a feature differs, replace with '?'
        for i in range(len(S)):
            if S[i] != features[i]:
                S[i] = '?'

        # Prune G: Remove any hypothesis in G that rejects this positive example
        G = [g for g in G if all(g[i] == '?' or g[i] == features[i] for i in range(len(g)))]

    # --- NEGATIVE EXAMPLES ---
    else:
        new_G = []
        for g in G:
            # Check if this hypothesis in G already rejects the negative example
            # (It rejects it if it requires a specific feature that the negative row doesn't have)
            if any(g[i] != '?' and g[i] != features[i] for i in range(len(g))):
                new_G.append(g) # Keep it, it's already safe
            else:
                # Otherwise, specialize this hypothesis to exclude the negative example
                for i in range(len(S)):
                    # We can only specialize an attribute if S knows what it should be
                    if S[i] != '?' and S[i] != features[i]:
                        new_g = g.copy()
                        new_g[i] = S[i] # Specialize using the value from S
                        new_G.append(new_g)

        # Replace G and remove any duplicates that may have formed
        unique_G = []
        for g in new_G:
            if g not in unique_G:
                unique_G.append(g)
        G = unique_G

# Output
print("Specific Hypothesis (S):")
print(S)

print("\nGeneral Hypothesis (G):")
for g in G:
    print(g)''')
        case 4:
            print('''
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

data = pd.read_csv('/content/data.csv')


X = data.iloc[:,:-1]
y = data.iloc[:,-1]

X = pd.get_dummies(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.33, random_state=42)


model = DecisionTreeClassifier(criterion='entropy')
model.fit(X_train,y_train)
y_pred = model.predict(X_test)
accuracy_score(y_test,y_pred)''')
        case 5:
            print('''
import pandas as pd

data = pd.read_csv('/content/data.csv')

X = data.iloc[:,:-1]
y = data.iloc[:,-1]

X= pd.get_dummies(X)
X = X.astype(int)
X

from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
model = GaussianNB()

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model.fit(X_train,y_train)
y_pred = model.predict(X_test)
accuracy_score(y_test, y_pred)''')
        case 6:
            print('''
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import recall_score, precision_score, f1_score

data = pd.read_csv('/content/documents.csv')
data
X = data['text']
y = data['label']

tfidf = TfidfVectorizer()

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

X_train = tfidf.fit_transform(X_train)

X_test = tfidf.transform(X_test)

model = MultinomialNB()

model.fit(X_train, y_train)

y_pred = model.predict(X_test)

print("Accuracy :", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, pos_label='Positive'))
print("Recall   :", recall_score(y_test, y_pred, pos_label='Positive'))
print("F1 Score :", f1_score(y_test, y_pred, pos_label='Positive'))''')
            
        case 7:
            print('''

import numpy as np
import pandas as pd
from pgmpy.inference import VariableElimination
# Modern pgmpy dropped BayesianModel; use DiscreteBayesianNetwork
from pgmpy.models import DiscreteBayesianNetwork

# 1. Load the Cleveland Heart Disease Dataset
# Ensure you have 'heart.csv' in your working directory
heartDisease = pd.read_csv("heart.csv")
heartDisease = heartDisease.replace("?", np.nan).dropna()

# 2. Simple Conversion to Categorical Text Labels
# This prevents data type mismatches during Maximum Likelihood Estimation
heartDisease["age"] = pd.cut(
    heartDisease["age"].astype(float),
    bins=[0, 45, 60, 120],
    labels=["young", "middle", "old"],
)
heartDisease["chol"] = pd.cut(
    heartDisease["chol"].astype(float),
    bins=[0, 200, 240, 1000],
    labels=["normal", "high", "v_high"],
)
heartDisease["trestbps"] = pd.cut(
    heartDisease["trestbps"].astype(float),
    bins=[0, 120, 140, 500],
    labels=["normal", "borderline", "high"],
)

# Display raw samples as required by the lab manual
print("Few examples from the dataset are given below")
print(heartDisease.head())

# 3. Model Bayesian Network Structure using Modern Class Architecture
model = DiscreteBayesianNetwork(
    [
        ("age", "trestbps"),
        ("age", "fbs"),
        ("sex", "trestbps"),
        ("exang", "trestbps"),
        ("trestbps", "heartdisease"),
        ("fbs", "heartdisease"),
        ("heartdisease", "restecg"),
        ("heartdisease", "thalach"),
        ("heartdisease", "chol"),
    ]
)

# 4. Learning CPDs using Maximum Likelihood Estimators
print("Learning CPD using Maximum likelihood estimators")
# Modern pgmpy automatically applies Discrete MLE when calling fit()
model.fit(heartDisease)

# 5. Inferencing with Bayesian Network Engine
print("Inferencing with Bayesian Network:")
HeartDisease_infer = VariableElimination(model)

# Computing the Probability of HeartDisease given Age state 'young'
print("1. Probability of HeartDisease given Age=young")
q1 = HeartDisease_infer.query(
    variables=["heartdisease"], evidence={"age": "young"}
)
print(q1)

# Computing the Probability of HeartDisease given cholesterol state 'normal'
print("2. Probability of HeartDisease given cholesterol=normal")
q2 = HeartDisease_infer.query(
    variables=["heartdisease"], evidence={"chol": "high"}
)
print(q2)

''')
            


            