import math
from typing import Tuple, Optional
from .vector import Vector

class Vector3D(Vector):
    """3D Vector class with additional operations specific to 3D space."""
    
    def __init__(self, x: float, y: float, z: float):
        """Initialize 3D vector with x, y, z components."""
        super().__init__(x, y, z)
        self.x = self.components[0]
        self.y = self.components[1]
        self.z = self.components[2]
    
    @property
    def x(self) -> float:
        return self.components[0]
    
    @x.setter
    def x(self, value: float):
        comp_list = list(self.components)
        comp_list[0] = float(value)
        self.components = tuple(comp_list)
    
    @property
    def y(self) -> float:
        return self.components[1]
    
    @y.setter
    def y(self, value: float):
        comp_list = list(self.components)
        comp_list[1] = float(value)
        self.components = tuple(comp_list)
    
    @property
    def z(self) -> float:
        return self.components[2]
    
    @z.setter
    def z(self, value: float):
        comp_list = list(self.components)
        comp_list[2] = float(value)
        self.components = tuple(comp_list)
    
    def cross(self, other: 'Vector3D') -> 'Vector3D':
        """Cross product (only for 3D vectors)."""
        if not isinstance(other, Vector3D):
            raise TypeError("Cross product requires Vector3D")
        
        return Vector3D(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x
        )
    
    def scalar_triple_product(self, b: 'Vector3D', c: 'Vector3D') -> float:
        """Scalar triple product: a · (b × c)."""
        return self.dot(b.cross(c))
    
    def vector_triple_product(self, b: 'Vector3D', c: 'Vector3D') -> 'Vector3D':
        """Vector triple product: a × (b × c)."""
        return self.cross(b.cross(c))
    
    def rotate_around_axis(self, axis: 'Vector3D', angle_deg: float) -> 'Vector3D':
        """Rotate vector around given axis by angle (degrees)."""
        axis = axis.normalize()
        angle_rad = math.radians(angle_deg)
        
        # Rodrigues' rotation formula
        cos_theta = math.cos(angle_rad)
        sin_theta = math.sin(angle_rad)
        
        dot_product = self.dot(axis)
        parallel = axis * dot_product
        perpendicular = self - parallel
        
        # Rotated perpendicular component
        rotated_perp = perpendicular * cos_theta + axis.cross(perpendicular) * sin_theta
        
        return parallel + rotated_perp
    
    def rotate_x(self, angle_deg: float) -> 'Vector3D':
        """Rotate around X-axis."""
        angle_rad = math.radians(angle_deg)
        cos_theta = math.cos(angle_rad)
        sin_theta = math.sin(angle_rad)
        
        return Vector3D(
            self.x,
            self.y * cos_theta - self.z * sin_theta,
            self.y * sin_theta + self.z * cos_theta
        )
    
    def rotate_y(self, angle_deg: float) -> 'Vector3D':
        """Rotate around Y-axis."""
        angle_rad = math.radians(angle_deg)
        cos_theta = math.cos(angle_rad)
        sin_theta = math.sin(angle_rad)
        
        return Vector3D(
            self.x * cos_theta + self.z * sin_theta,
            self.y,
            -self.x * sin_theta + self.z * cos_theta
        )
    
    def rotate_z(self, angle_deg: float) -> 'Vector3D':
        """Rotate around Z-axis."""
        angle_rad = math.radians(angle_deg)
        cos_theta = math.cos(angle_rad)
        sin_theta = math.sin(angle_rad)
        
        return Vector3D(
            self.x * cos_theta - self.y * sin_theta,
            self.x * sin_theta + self.y * cos_theta,
            self.z
        )
    
    def to_spherical(self) -> Tuple[float, float, float]:
        """
        Convert to spherical coordinates (r, theta, phi).
        r: radial distance
        theta: polar angle from z-axis (0 to π)
        phi: azimuthal angle from x-axis (0 to 2π)
        """
        r = self.magnitude()
        if r == 0:
            return (0, 0, 0)
        
        theta = math.acos(self.z / r)  # Polar angle
        phi = math.atan2(self.y, self.x)  # Azimuthal angle
        
        return (r, theta, phi)
    
    def to_cylindrical(self) -> Tuple[float, float, float]:
        """
        Convert to cylindrical coordinates (rho, phi, z).
        rho: radial distance in xy-plane
        phi: azimuthal angle from x-axis
        z: height
        """
        rho = math.sqrt(self.x**2 + self.y**2)
        phi = math.atan2(self.y, self.x)
        
        return (rho, phi, self.z)
    
    @classmethod
    def from_spherical(cls, r: float, theta: float, phi: float) -> 'Vector3D':
        """Create Vector3D from spherical coordinates."""
        x = r * math.sin(theta) * math.cos(phi)
        y = r * math.sin(theta) * math.sin(phi)
        z = r * math.cos(theta)
        return cls(x, y, z)
    
    @classmethod
    def from_cylindrical(cls, rho: float, phi: float, z: float) -> 'Vector3D':
        """Create Vector3D from cylindrical coordinates."""
        x = rho * math.cos(phi)
        y = rho * math.sin(phi)
        return cls(x, y, z)
    
    def reflect(self, normal: 'Vector3D') -> 'Vector3D':
        """Reflect vector across a plane with given normal."""
        normal = normal.normalize()
        return self - (normal * 2 * self.dot(normal))
    
    def __repr__(self) -> str:
        return f"Vector3D({self.x:.4f}, {self.y:.4f}, {self.z:.4f})"