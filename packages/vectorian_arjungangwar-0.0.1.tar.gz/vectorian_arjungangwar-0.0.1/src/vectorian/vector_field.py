from typing import Callable, Union, Tuple
import math
from .vector import Vector
from .vector3d import Vector3D
from .calculus import gradient, divergence, curl

class ScalarField:
    """Scalar field f(x, y, z) with calculus operations."""
    
    def __init__(self, func: Callable[[float, float, float], float]):
        """
        Initialize scalar field.
        
        Args:
            func: Function f(x, y, z) that returns a scalar value
        """
        self.func = func
    
    def evaluate(self, x: float, y: float, z: float) -> float:
        """Evaluate scalar field at point."""
        return self.func(x, y, z)
    
    def gradient(self, x: float, y: float, z: float, h: float = 1e-6) -> Vector3D:
        """Compute gradient at point using finite differences."""
        return gradient(self.func, x, y, z, h)
    
    def laplacian(self, x: float, y: float, z: float, h: float = 1e-6) -> float:
        """Compute Laplacian at point."""
        dfxx = (self.func(x + h, y, z) - 2*self.func(x, y, z) + self.func(x - h, y, z)) / (h*h)
        dfyy = (self.func(x, y + h, z) - 2*self.func(x, y, z) + self.func(x, y - h, z)) / (h*h)
        dfzz = (self.func(x, y, z + h) - 2*self.func(x, y, z) + self.func(x, y, z - h)) / (h*h)
        return dfxx + dfyy + dfzz
    
    def directional_derivative(self, x: float, y: float, z: float, 
                               direction: Vector3D, h: float = 1e-6) -> float:
        """Compute directional derivative in given direction."""
        grad = self.gradient(x, y, z, h)
        direction = direction.normalize()
        return grad.dot(direction)

class VectorField:
    """Vector field F(x, y, z) = (P, Q, R) with calculus operations."""
    
    def __init__(self, P: Callable, Q: Callable, R: Callable):
        """
        Initialize vector field.
        
        Args:
            P: x-component function P(x, y, z)
            Q: y-component function Q(x, y, z)
            R: z-component function R(x, y, z)
        """
        self.P = P
        self.Q = Q
        self.R = R
    
    @classmethod
    def from_vector_function(cls, func: Callable[[float, float, float], Vector3D]):
        """Create vector field from function returning Vector3D."""
        def P(x, y, z): return func(x, y, z).x
        def Q(x, y, z): return func(x, y, z).y
        def R(x, y, z): return func(x, y, z).z
        return cls(P, Q, R)
    
    def evaluate(self, x: float, y: float, z: float) -> Vector3D:
        """Evaluate vector field at point."""
        return Vector3D(self.P(x, y, z), self.Q(x, y, z), self.R(x, y, z))
    
    def divergence(self, x: float, y: float, z: float, h: float = 1e-6) -> float:
        """Compute divergence at point."""
        return divergence(self.P, self.Q, self.R, x, y, z, h)
    
    def curl(self, x: float, y: float, z: float, h: float = 1e-6) -> Vector3D:
        """Compute curl at point."""
        return curl(self.P, self.Q, self.R, x, y, z, h)
    
    def laplacian(self, x: float, y: float, z: float, h: float = 1e-6) -> Vector3D:
        """Compute vector Laplacian at point."""
        def laplacian_component(func, x, y, z, h):
            dxx = (func(x + h, y, z) - 2*func(x, y, z) + func(x - h, y, z)) / (h*h)
            dyy = (func(x, y + h, z) - 2*func(x, y, z) + func(x, y - h, z)) / (h*h)
            dzz = (func(x, y, z + h) - 2*func(x, y, z) + func(x, y, z - h)) / (h*h)
            return dxx + dyy + dzz
        
        return Vector3D(
            laplacian_component(self.P, x, y, z, h),
            laplacian_component(self.Q, x, y, z, h),
            laplacian_component(self.R, x, y, z, h)
        )
    
    def is_conservative(self, x: float, y: float, z: float, h: float = 1e-6) -> bool:
        """Check if field is conservative (curl = 0) at point."""
        curl_vec = self.curl(x, y, z, h)
        return curl_vec.magnitude() < 1e-8
    
    def potential(self, x0: float, y0: float, z0: float, 
                  x: float, y: float, z: float, steps: int = 100) -> float:
        """
        Compute scalar potential (if conservative) via line integral.
        """
        if not self.is_conservative(x0, y0, z0):
            raise ValueError("Field is not conservative, potential may not exist")
        
        # Line integral from (x0,y0,z0) to (x,y,z)
        dx = (x - x0) / steps
        dy = (y - y0) / steps
        dz = (z - z0) / steps
        
        potential = 0.0
        xi, yi, zi = x0, y0, z0
        
        for i in range(steps):
            F = self.evaluate(xi, yi, zi)
            potential += F.x * dx + F.y * dy + F.z * dz
            xi += dx
            yi += dy
            zi += dz
        
        return -potential  # Negative for physical potential
    
    def field_lines(self, start_point: Vector3D, t_max: float = 10.0, 
                   steps: int = 1000) -> list:
        """
        Compute field lines using numerical integration (Runge-Kutta 4).
        """
        points = [start_point]
        dt = t_max / steps
        
        for _ in range(steps):
            current = points[-1]
            F = self.evaluate(current.x, current.y, current.z)
            
            if F.magnitude() < 1e-10:
                break
            
            # RK4 integration
            k1 = F
            k2 = self.evaluate(current.x + dt/2 * k1.x,
                              current.y + dt/2 * k1.y,
                              current.z + dt/2 * k1.z)
            k3 = self.evaluate(current.x + dt/2 * k2.x,
                              current.y + dt/2 * k2.y,
                              current.z + dt/2 * k2.z)
            k4 = self.evaluate(current.x + dt * k3.x,
                              current.y + dt * k3.y,
                              current.z + dt * k3.z)
            
            next_point = current + (dt/6) * (k1 + 2*k2 + 2*k3 + k4)
            points.append(next_point)
        
        return points