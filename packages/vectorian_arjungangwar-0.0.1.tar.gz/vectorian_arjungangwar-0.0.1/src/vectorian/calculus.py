from typing import Callable, Tuple
import math
from .vector import Vector
from .vector3d import Vector3D

def gradient(f: Callable[[float, float, float], float], 
            x: float, y: float, z: float, h: float = 1e-6) -> Vector3D:
    """Compute gradient of scalar field f at point (x,y,z)."""
    dfdx = (f(x + h, y, z) - f(x - h, y, z)) / (2 * h)
    dfdy = (f(x, y + h, z) - f(x, y - h, z)) / (2 * h)
    dfdz = (f(x, y, z + h) - f(x, y, z - h)) / (2 * h)
    
    return Vector3D(dfdx, dfdy, dfdz)

def divergence(P: Callable, Q: Callable, R: Callable,
              x: float, y: float, z: float, h: float = 1e-6) -> float:
    """Compute divergence of vector field F = (P, Q, R) at point."""
    dPdx = (P(x + h, y, z) - P(x - h, y, z)) / (2 * h)
    dQdy = (Q(x, y + h, z) - Q(x, y - h, z)) / (2 * h)
    dRdz = (R(x, y, z + h) - R(x, y, z - h)) / (2 * h)
    
    return dPdx + dQdy + dRdz

def curl(P: Callable, Q: Callable, R: Callable,
        x: float, y: float, z: float, h: float = 1e-6) -> Vector3D:
    """Compute curl of vector field F = (P, Q, R) at point."""
    dRdy = (R(x, y + h, z) - R(x, y - h, z)) / (2 * h)
    dQdz = (Q(x, y, z + h) - Q(x, y, z - h)) / (2 * h)
    dPdz = (P(x, y, z + h) - P(x, y, z - h)) / (2 * h)
    dRdx = (R(x + h, y, z) - R(x - h, y, z)) / (2 * h)
    dQdx = (Q(x + h, y, z) - Q(x - h, y, z)) / (2 * h)
    dPdy = (P(x, y + h, z) - P(x, y - h, z)) / (2 * h)
    
    curl_x = dRdy - dQdz
    curl_y = dPdz - dRdx
    curl_z = dQdx - dPdy
    
    return Vector3D(curl_x, curl_y, curl_z)

def laplacian(f: Callable[[float, float, float], float],
             x: float, y: float, z: float, h: float = 1e-6) -> float:
    """Compute Laplacian of scalar field f at point."""
    dxx = (f(x + h, y, z) - 2*f(x, y, z) + f(x - h, y, z)) / (h*h)
    dyy = (f(x, y + h, z) - 2*f(x, y, z) + f(x, y - h, z)) / (h*h)
    dzz = (f(x, y, z + h) - 2*f(x, y, z) + f(x, y, z - h)) / (h*h)
    
    return dxx + dyy + dzz

def directional_derivative(f: Callable[[float, float, float], float],
                          x: float, y: float, z: float,
                          direction: Vector3D, h: float = 1e-6) -> float:
    """Compute directional derivative in given direction."""
    grad = gradient(f, x, y, z, h)
    direction = direction.normalize()
    return grad.dot(direction)

def jacobian(P: Callable, Q: Callable, R: Callable,
            x: float, y: float, z: float, h: float = 1e-6) -> list:
    """Compute Jacobian matrix of vector field."""
    def partial_derivative(func, var, x, y, z, h):
        if var == 'x':
            return (func(x + h, y, z) - func(x - h, y, z)) / (2 * h)
        elif var == 'y':
            return (func(x, y + h, z) - func(x, y - h, z)) / (2 * h)
        elif var == 'z':
            return (func(x, y, z + h) - func(x, y, z - h)) / (2 * h)
    
    return [
        [partial_derivative(P, 'x', x, y, z, h),
         partial_derivative(P, 'y', x, y, z, h),
         partial_derivative(P, 'z', x, y, z, h)],
        [partial_derivative(Q, 'x', x, y, z, h),
         partial_derivative(Q, 'y', x, y, z, h),
         partial_derivative(Q, 'z', x, y, z, h)],
        [partial_derivative(R, 'x', x, y, z, h),
         partial_derivative(R, 'y', x, y, z, h),
         partial_derivative(R, 'z', x, y, z, h)]
    ]

def hessian(f: Callable[[float, float, float], float],
           x: float, y: float, z: float, h: float = 1e-6) -> list:
    """Compute Hessian matrix of scalar field."""
    def second_derivative(f, var1, var2, x, y, z, h):
        if var1 == 'x' and var2 == 'x':
            return (f(x + h, y, z) - 2*f(x, y, z) + f(x - h, y, z)) / (h*h)
        elif var1 == 'y' and var2 == 'y':
            return (f(x, y + h, z) - 2*f(x, y, z) + f(x, y - h, z)) / (h*h)
        elif var1 == 'z' and var2 == 'z':
            return (f(x, y, z + h) - 2*f(x, y, z) + f(x, y, z - h)) / (h*h)
        else:
            # Mixed partial derivative
            if var1 == 'x' and var2 == 'y':
                return (f(x + h, y + h, z) - f(x + h, y - h, z) - 
                       f(x - h, y + h, z) + f(x - h, y - h, z)) / (4 * h * h)
            elif var1 == 'x' and var2 == 'z':
                return (f(x + h, y, z + h) - f(x + h, y, z - h) - 
                       f(x - h, y, z + h) + f(x - h, y, z - h)) / (4 * h * h)
            elif var1 == 'y' and var2 == 'z':
                return (f(x, y + h, z + h) - f(x, y + h, z - h) - 
                       f(x, y - h, z + h) + f(x, y - h, z - h)) / (4 * h * h)
            else:
                return second_derivative(f, var2, var1, x, y, z, h)
    
    return [
        [second_derivative(f, 'x', 'x', x, y, z, h),
         second_derivative(f, 'x', 'y', x, y, z, h),
         second_derivative(f, 'x', 'z', x, y, z, h)],
        [second_derivative(f, 'y', 'x', x, y, z, h),
         second_derivative(f, 'y', 'y', x, y, z, h),
         second_derivative(f, 'y', 'z', x, y, z, h)],
        [second_derivative(f, 'z', 'x', x, y, z, h),
         second_derivative(f, 'z', 'y', x, y, z, h),
         second_derivative(f, 'z', 'z', x, y, z, h)]
    ]

from vector_field import VectorField

def line_integral(F: VectorField, 
                 start: Vector3D, end: Vector3D, 
                 steps: int = 1000) -> float:
    """Compute line integral ∫ F · dr along straight line from start to end."""
    dr = (end - start) / steps
    integral = 0.0
    
    for i in range(steps):
        t = i / steps
        point = start + t * (end - start)
        F_val = F.evaluate(point.x, point.y, point.z)
        integral += F_val.dot(dr)
    
    return integral