import math
from typing import Tuple
from .vector import Vector
from .vector3d import Vector3D

def rotation_matrix_x(angle_deg: float) -> list:
    """Create rotation matrix around X-axis."""
    angle_rad = math.radians(angle_deg)
    cos_theta = math.cos(angle_rad)
    sin_theta = math.sin(angle_rad)
    
    return [
        [1, 0, 0],
        [0, cos_theta, -sin_theta],
        [0, sin_theta, cos_theta]
    ]

def rotation_matrix_y(angle_deg: float) -> list:
    """Create rotation matrix around Y-axis."""
    angle_rad = math.radians(angle_deg)
    cos_theta = math.cos(angle_rad)
    sin_theta = math.sin(angle_rad)
    
    return [
        [cos_theta, 0, sin_theta],
        [0, 1, 0],
        [-sin_theta, 0, cos_theta]
    ]

def rotation_matrix_z(angle_deg: float) -> list:
    """Create rotation matrix around Z-axis."""
    angle_rad = math.radians(angle_deg)
    cos_theta = math.cos(angle_rad)
    sin_theta = math.sin(angle_rad)
    
    return [
        [cos_theta, -sin_theta, 0],
        [sin_theta, cos_theta, 0],
        [0, 0, 1]
    ]

def rotate_vector(v: Vector3D, axis: str, angle_deg: float) -> Vector3D:
    """Rotate vector around given axis."""
    if axis == 'x':
        return v.rotate_x(angle_deg)
    elif axis == 'y':
        return v.rotate_y(angle_deg)
    elif axis == 'z':
        return v.rotate_z(angle_deg)
    else:
        raise ValueError("Axis must be 'x', 'y', or 'z'")

def reflect_vector(v: Vector3D, normal: Vector3D) -> Vector3D:
    """Reflect vector across plane with given normal."""
    return v.reflect(normal)

def scale_vector(v: Vector, factors: Tuple[float, ...]) -> Vector:
    """Scale vector components by given factors."""
    if len(factors) != v.dimension:
        raise ValueError(f"Need {v.dimension} scaling factors")
    
    return Vector(*[v.components[i] * factors[i] for i in range(v.dimension)])

def cartesian_to_spherical(v: Vector3D) -> Tuple[float, float, float]:
    """Convert Cartesian coordinates to spherical."""
    return v.to_spherical()

def spherical_to_cartesian(r: float, theta: float, phi: float) -> Vector3D:
    """Convert spherical coordinates to Cartesian."""
    return Vector3D.from_spherical(r, theta, phi)

def cartesian_to_cylindrical(v: Vector3D) -> Tuple[float, float, float]:
    """Convert Cartesian coordinates to cylindrical."""
    return v.to_cylindrical()

def cylindrical_to_cartesian(rho: float, phi: float, z: float) -> Vector3D:
    """Convert cylindrical coordinates to Cartesian."""
    return Vector3D.from_cylindrical(rho, phi, z)

def translation_matrix(dx: float, dy: float, dz: float) -> list:
    """Create translation matrix for homogeneous coordinates."""
    return [
        [1, 0, 0, dx],
        [0, 1, 0, dy],
        [0, 0, 1, dz],
        [0, 0, 0, 1]
    ]

def homogeneous_transform(v: Vector3D, matrix: list) -> Vector3D:
    """Apply 4x4 homogeneous transformation matrix to vector."""
    v_homogeneous = [v.x, v.y, v.z, 1]
    result = [0, 0, 0, 0]
    
    for i in range(4):
        for j in range(4):
            result[i] += matrix[i][j] * v_homogeneous[j]
    
    return Vector3D(result[0], result[1], result[2])