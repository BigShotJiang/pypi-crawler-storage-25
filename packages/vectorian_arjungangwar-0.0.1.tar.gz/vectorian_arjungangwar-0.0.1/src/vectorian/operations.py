from typing import Union, List
import math
from .vector import Vector
from .vector3d import Vector3D

def dot(u: Vector, v: Vector) -> float:
    """Dot product of two vectors."""
    return u.dot(v)

def cross(u: Vector3D, v: Vector3D) -> Vector3D:
    """Cross product of two 3D vectors."""
    return u.cross(v)

def scalar_triple_product(a: Vector3D, b: Vector3D, c: Vector3D) -> float:
    """Scalar triple product: a · (b × c)."""
    return a.scalar_triple_product(b, c)

def vector_triple_product(a: Vector3D, b: Vector3D, c: Vector3D) -> Vector3D:
    """Vector triple product: a × (b × c)."""
    return a.vector_triple_product(b, c)

def projection(u: Vector, onto: Vector) -> Vector:
    """Project vector u onto vector v."""
    return u.projection(onto)

def rejection(u: Vector, onto: Vector) -> Vector:
    """Rejection of vector u from vector v (perpendicular component)."""
    return u.rejection(onto)

def angle_between(u: Vector, v: Vector, radians: bool = True) -> float:
    """Calculate angle between two vectors."""
    return u.angle(v, radians)

def are_orthogonal(u: Vector, v: Vector, tolerance: float = 1e-10) -> bool:
    """Check if vectors are orthogonal."""
    return u.is_orthogonal(v, tolerance)

def are_parallel(u: Vector, v: Vector, tolerance: float = 1e-10) -> bool:
    """Check if vectors are parallel."""
    return u.is_parallel(v, tolerance)

def are_coplanar(a: Vector3D, b: Vector3D, c: Vector3D, d: Vector3D) -> bool:
    """Check if four points (as vectors from origin) are coplanar."""
    # Vectors from a to b, c, d
    ab = b - a
    ac = c - a
    ad = d - a
    
    # Scalar triple product should be zero for coplanar points
    return abs(ab.scalar_triple_product(ac, ad)) < 1e-10

def unit_vector(v: Vector) -> Vector:
    """Return unit vector in same direction."""
    return v.normalize()

def linear_combination(coefficients: List[float], vectors: List[Vector]) -> Vector:
    """Compute linear combination of vectors."""
    if len(coefficients) != len(vectors):
        raise ValueError("Number of coefficients must match number of vectors")
    
    result = Vector.zeros(vectors[0].dimension)
    for coeff, vec in zip(coefficients, vectors):
        result += coeff * vec
    return result

def gram_schmidt(vectors: List[Vector]) -> List[Vector]:
    """Apply Gram-Schmidt orthogonalization process."""
    orthogonal = []
    for v in vectors:
        u = v
        for o in orthogonal:
            u = u - projection(v, o)
        if u.magnitude() > 1e-10:
            orthogonal.append(u.normalize())
    return orthogonal

def cross_product_matrix(v: Vector3D) -> List[List[float]]:
    """Create cross product matrix [v]× for vector v."""
    return [
        [0, -v.z, v.y],
        [v.z, 0, -v.x],
        [-v.y, v.x, 0]
    ]