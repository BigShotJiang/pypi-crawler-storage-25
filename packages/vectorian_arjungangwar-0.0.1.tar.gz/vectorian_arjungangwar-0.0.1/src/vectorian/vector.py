import math
from typing import Union, List, Tuple
import numpy as np

class Vector:
    """General N-dimensional vector class with comprehensive operations."""
    
    def __init__(self, *components: Union[int, float]):
        """
        Initialize a vector with components.
        
        Examples:
            v1 = Vector(1, 2, 3)
            v2 = Vector(1, 2, 3, 4, 5)
        """
        self.components = tuple(float(c) for c in components)
        self.dimension = len(components)
    
    @classmethod
    def zeros(cls, dimension: int) -> 'Vector':
        """Create a zero vector of given dimension."""
        return cls(*[0.0] * dimension)
    
    @classmethod
    def ones(cls, dimension: int) -> 'Vector':
        """Create a vector of ones of given dimension."""
        return cls(*[1.0] * dimension)
    
    @classmethod
    def basis(cls, dimension: int, index: int) -> 'Vector':
        """Create a basis vector (unit vector along given axis)."""
        components = [0.0] * dimension
        components[index] = 1.0
        return cls(*components)
    
    def __add__(self, other: 'Vector') -> 'Vector':
        """Vector addition."""
        self._check_dimension(other)
        return Vector(*[a + b for a, b in zip(self.components, other.components)])
    
    def __sub__(self, other: 'Vector') -> 'Vector':
        """Vector subtraction."""
        self._check_dimension(other)
        return Vector(*[a - b for a, b in zip(self.components, other.components)])
    
    def __mul__(self, scalar: Union[int, float]) -> 'Vector':
        """Scalar multiplication."""
        return Vector(*[c * scalar for c in self.components])
    
    def __rmul__(self, scalar: Union[int, float]) -> 'Vector':
        """Scalar multiplication (scalar on left)."""
        return self.__mul__(scalar)
    
    def __truediv__(self, scalar: Union[int, float]) -> 'Vector':
        """Scalar division."""
        if scalar == 0:
            raise ZeroDivisionError("Cannot divide by zero")
        return Vector(*[c / scalar for c in self.components])
    
    def __neg__(self) -> 'Vector':
        """Negation of vector."""
        return Vector(*[-c for c in self.components])
    
    def __eq__(self, other: object) -> bool:
        """Check equality with tolerance."""
        if not isinstance(other, Vector):
            return False
        if self.dimension != other.dimension:
            return False
        return all(math.isclose(a, b) for a, b in zip(self.components, other.components))
    
    def __getitem__(self, index: int) -> float:
        """Get component by index."""
        return self.components[index]
    
    def __setitem__(self, index: int, value: float):
        """Set component by index."""
        comp_list = list(self.components)
        comp_list[index] = float(value)
        self.components = tuple(comp_list)
    
    def __len__(self) -> int:
        """Return dimension of vector."""
        return self.dimension
    
    def __repr__(self) -> str:
        return f"Vector{self.components}"
    
    def __str__(self) -> str:
        return f"({', '.join(f'{c:.4f}' for c in self.components)})"
    
    def _check_dimension(self, other: 'Vector'):
        """Check if dimensions match."""
        if self.dimension != other.dimension:
            raise ValueError(f"Dimension mismatch: {self.dimension} vs {other.dimension}")
    
    def magnitude(self) -> float:
        """Calculate magnitude (length) of vector."""
        return math.sqrt(sum(c**2 for c in self.components))
    
    def norm(self, p: int = 2) -> float:
        """Calculate L-p norm of vector."""
        if p == float('inf'):
            return max(abs(c) for c in self.components)
        return sum(abs(c)**p for c in self.components) ** (1/p)
    
    def normalize(self) -> 'Vector':
        """Return normalized unit vector."""
        mag = self.magnitude()
        if mag == 0:
            raise ValueError("Cannot normalize zero vector")
        return self / mag
    
    def dot(self, other: 'Vector') -> float:
        """Dot product."""
        self._check_dimension(other)
        return sum(a * b for a, b in zip(self.components, other.components))
    
    def angle(self, other: 'Vector', radians: bool = True) -> float:
        """Calculate angle between vectors."""
        dot_product = self.dot(other)
        magnitudes = self.magnitude() * other.magnitude()
        if magnitudes == 0:
            raise ValueError("Cannot compute angle with zero vector")
        
        cos_theta = dot_product / magnitudes
        cos_theta = max(-1.0, min(1.0, cos_theta))  # Clamp to handle floating point errors
        angle_rad = math.acos(cos_theta)
        
        return angle_rad if radians else math.degrees(angle_rad)
    
    def projection(self, onto: 'Vector') -> 'Vector':
        """Project this vector onto another vector."""
        onto_norm_sq = onto.dot(onto)
        if onto_norm_sq == 0:
            raise ValueError("Cannot project onto zero vector")
        scalar = self.dot(onto) / onto_norm_sq
        return onto * scalar
    
    def rejection(self, onto: 'Vector') -> 'Vector':
        """Rejection of this vector from another vector (perpendicular component)."""
        return self - self.projection(onto)
    
    def is_orthogonal(self, other: 'Vector', tolerance: float = 1e-10) -> bool:
        """Check if vectors are orthogonal."""
        return abs(self.dot(other)) < tolerance
    
    def is_parallel(self, other: 'Vector', tolerance: float = 1e-10) -> bool:
        """Check if vectors are parallel."""
        if self.magnitude() == 0 or other.magnitude() == 0:
            return True
        cross_mag = self.cross(other).magnitude() if self.dimension == 3 else None
        if cross_mag is not None:
            return cross_mag < tolerance
        # For N-dimensional, check if one is scalar multiple of other
        ratios = []
        for i in range(self.dimension):
            if abs(self.components[i]) > tolerance:
                ratios.append(other.components[i] / self.components[i])
            elif abs(other.components[i]) > tolerance:
                return False
        if not ratios:
            return True  # Both are zero vectors
        return all(math.isclose(ratios[0], r, rel_tol=tolerance) for r in ratios)
    
    def component(self, axis: int) -> float:
        """Get component along given axis."""
        if axis >= self.dimension:
            raise IndexError(f"Axis {axis} out of range for dimension {self.dimension}")
        return self.components[axis]
    
    def direction_cosines(self) -> List[float]:
        """Calculate direction cosines."""
        mag = self.magnitude()
        if mag == 0:
            raise ValueError("Cannot compute direction cosines for zero vector")
        return [c / mag for c in self.components]
    
    def to_list(self) -> List[float]:
        """Convert to list."""
        return list(self.components)
    
    def to_tuple(self) -> Tuple[float, ...]:
        """Convert to tuple."""
        return self.components
    
    def to_numpy(self) -> np.ndarray:
        """Convert to numpy array."""
        return np.array(self.components)
    
    @staticmethod
    def from_numpy(array: np.ndarray) -> 'Vector':
        """Create vector from numpy array."""
        return Vector(*array.flatten())