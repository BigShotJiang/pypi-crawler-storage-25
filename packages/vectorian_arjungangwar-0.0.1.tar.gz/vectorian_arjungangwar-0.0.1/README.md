# Vectorian - Complete Vector Analysis Library

**Author:** Arjun Singh Gangwar  
**Email:** arjungangwariitpkd@.com

A comprehensive Python library for vector analysis covering everything from basic vector operations to advanced vector calculus and field theory.

## Features

### 📐 Basic Vector Operations
- Vector addition, subtraction, scalar multiplication
- Dot product, cross product, triple product
- Magnitude, normalization, direction cosines
- Projection and rejection

### 🔄 Advanced Operations
- Gradient, Divergence, Curl (for vector fields)
- Laplacian operator
- Directional derivatives
- Jacobian matrix

### 📊 Vector Fields
- Scalar and vector fields
- Field visualization
- Field line computation
- Conservative field detection

### 🧮 Calculus Operations
- Line integrals
- Surface integrals
- Volume integrals
- Green's theorem
- Stokes' theorem
- Divergence theorem

### 🔧 Transformations
- Rotation matrices
- Reflection
- Scaling
- Coordinate system transformations (Cartesian ↔ Spherical ↔ Cylindrical)

## Installation

```bash
pip install vectorian