import unittest
import math
from vectorian import Vector, Vector3D, VectorField, dot, cross, angle_between

class TestVector(unittest.TestCase):
    
    def setUp(self):
        self.v1 = Vector(1, 2, 3)
        self.v2 = Vector(4, 5, 6)
        self.v3d1 = Vector3D(1, 0, 0)
        self.v3d2 = Vector3D(0, 1, 0)
    
    def test_vector_addition(self):
        result = self.v1 + self.v2
        expected = Vector(5, 7, 9)
        self.assertEqual(result, expected)
    
    def test_dot_product(self):
        result = self.v1.dot(self.v2)
        self.assertEqual(result, 32)  # 1*4 + 2*5 + 3*6 = 32
    
    def test_cross_product(self):
        result = self.v3d1.cross(self.v3d2)
        expected = Vector3D(0, 0, 1)
        self.assertEqual(result, expected)
    
    def test_magnitude(self):
        v = Vector(3, 4)
        self.assertEqual(v.magnitude(), 5)
    
    def test_normalization(self):
        v = Vector(3, 4)
        normalized = v.normalize()
        self.assertAlmostEqual(normalized.magnitude(), 1.0)
    
    def test_angle_between(self):
        angle = angle_between(self.v3d1, self.v3d2)
        self.assertAlmostEqual(angle, math.pi/2)
    
    def test_scalar_multiplication(self):
        result = self.v1 * 2
        expected = Vector(2, 4, 6)
        self.assertEqual(result, expected)
    
    def test_vector_field(self):
        def P(x, y, z): return x
        def Q(x, y, z): return y
        def R(x, y, z): return z
        
        field = VectorField(P, Q, R)
        div = field.divergence(1, 1, 1)
        self.assertAlmostEqual(div, 3.0)
    
    def test_gradient(self):
        def f(x, y, z):
            return x**2 + y**2 + z**2
        
        from vectorian import gradient
        grad = gradient(f, 1, 1, 1)
        self.assertAlmostEqual(grad.x, 2.0, places=5)
        self.assertAlmostEqual(grad.y, 2.0, places=5)
        self.assertAlmostEqual(grad.z, 2.0, places=5)

if __name__ == '__main__':
    unittest.main()