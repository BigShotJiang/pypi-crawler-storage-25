"""Type utilities for dependency injection and attribute resolution.

Provides type checking and analysis utilities for the Reactor DI system.
Simplified after removing unnecessary defensive programming - Python 3.9+
type hint APIs are stable and don't require extensive error handling.

Key features:
- Alternative name generation for dependency mapping
- Primitive type detection to avoid instantiation
- Constructor source analysis for attribute assignment detection
- ``lookup`` annotation marker for parent-module dependency resolution
- ``make`` annotation marker for subtype factory generation
- Internal attribute constants for dependency tracking
"""

from __future__ import annotations

import inspect
import re
from typing import TYPE_CHECKING, Any, Final, TypeVar

# Type variables for the ``lookup`` and ``make`` annotation markers.
# These exist so that static analyzers (mypy/IDEs) accept the
# ``lookup[T]`` / ``make[B, I]`` subscripting syntax *and* erase the
# subscript to the inner type at attribute-access sites — i.e.
# ``self.x: lookup[str]`` is statically seen as ``str`` (analogous to
# how ``Final[T]`` and ``ClassVar[T]`` erase to ``T``).
#
# We achieve this by making ``lookup`` / ``make`` aliases for
# ``Annotated[_T, ...]`` under ``TYPE_CHECKING`` (which type checkers
# treat as the inner type after stripping the metadata) while keeping
# the runtime classes whose ``__class_getitem__`` produces the marker
# instances consumed by the ``@module`` / ``@law_of_demeter`` decorators.
_T = TypeVar("_T")
_B = TypeVar("_B")
_I = TypeVar("_I")

# Constants for internal attribute names
SETUP_DEPENDENCIES_ATTR: Final[str] = "_reactor_di_setup_dependencies"
DEPENDENCY_MAP_ATTR: Final[str] = "_reactor_di_dependency_map"
MODULE_INSTANCE_ATTR: Final[str] = "_reactor_di_module_instance"
REACTOR_DI_LOCK_ATTR: Final[str] = "_reactor_di_lock"


class _LookupMarker:
    """Internal wrapper returned by ``lookup[Type]`` or ``lookup[Type, "name"]``.

    Stores the inner type and an optional *source_name* override so that
    decorators can detect, unwrap, and remap the dependency.

    The class is callable (``__call__`` raises) purely so that
    ``typing._type_check`` accepts an instance as a "valid" annotation
    value when ``get_type_hints`` evaluates a stringified ``lookup[T]``
    annotation under ``from __future__ import annotations`` on Python
    3.9 / 3.10.  Those versions of ``_type_check`` accept any ``callable``
    as a fallthrough; without ``__call__`` they raise ``TypeError:
    Forward references must evaluate to types.``  Python 3.11+ relaxed
    this check.  The ``_apply_module_decorator`` annotation walker never
    invokes the marker — it detects markers via :func:`is_lookup_type`
    and unwraps them via :func:`unwrap_lookup`.
    """

    __slots__ = ("inner_type", "source_name")

    def __init__(self, inner_type: type[Any], source_name: str | None = None) -> None:
        self.inner_type = inner_type
        self.source_name = source_name

    def __repr__(self) -> str:
        name = getattr(self.inner_type, "__name__", repr(self.inner_type))
        if self.source_name is not None:
            return f'lookup[{name}, "{self.source_name}"]'
        return f"lookup[{name}]"

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        # See class docstring — this exists only to satisfy
        # ``typing._type_check`` on Python 3.9 / 3.10.  No call site in
        # this codebase invokes a marker.
        raise TypeError(
            "lookup markers are not callable — they are annotation values "
            "consumed by the @module / @law_of_demeter decorators"
        )


if TYPE_CHECKING:
    from typing import Annotated

    from typing_extensions import TypeAliasType

    # ``lookup[T]`` aliases to ``Annotated[T, ...]`` for type checkers,
    # which strip the metadata and treat the annotation as ``T`` at
    # attribute-access sites.  This mirrors the static behavior of
    # ``Final[T]`` and ``ClassVar[T]``: ``self.x: lookup[str]`` is seen as
    # ``str`` by mypy/pyright/PyCharm.  Runtime semantics are unaffected —
    # see the runtime ``lookup`` class below.
    #
    # ``TypeAliasType`` is used (rather than a bare ``Annotated[_T, ...]``)
    # to declare ``lookup`` as a generic type alias parameterized over
    # ``_T`` — this is what lets type checkers substitute ``T`` correctly
    # when users write ``lookup[T]``.
    lookup = TypeAliasType(
        "lookup", Annotated[_T, "reactor_di.lookup"], type_params=(_T,)
    )
else:

    class lookup:
        """Annotation marker for dependencies resolved from a parent module.

        Usage::

            @module(CachingStrategy.NOT_THREAD_SAFE)
            class ChildModule:
                db: lookup[DatabaseConnection]              # lookup "db" on parent
                conn: lookup[DatabaseConnection, "db"]      # lookup "db" on parent, bind to "conn"
                service: MyService                          # created locally as usual

            @law_of_demeter("_config")
            class MyComponent:
                _config: Config
                _timeout: int                               # forwarded from config
                _db: lookup[DatabaseConnection]              # from parent module, NOT forwarded

        The optional second parameter names the attribute to look up on the
        parent module.  When omitted, the annotation's own name is used.

        On a **module**, ``@module`` skips factory generation and installs a
        lightweight property so the name is visible to child-component factories.
        The actual value is injected lazily by the parent module.

        On a **component**, ``@law_of_demeter`` skips the attribute (does not
        create a forwarding property for it).  The parent module's factory
        resolves it through the standard dependency-map mechanism.  With
        ``lookup[Type, "name"]``, the factory maps from the parent's ``name``
        attribute to the component's local annotation name.

        Static-vs-runtime split
        -----------------------
        Under ``TYPE_CHECKING``, ``lookup`` is an alias for
        ``Annotated[_T, ...]`` so that ``lookup[T]`` erases to ``T`` for
        static analyzers — exactly the way ``Final[T]`` and ``ClassVar[T]``
        do.  At **runtime**, ``lookup`` is this class, and ``lookup[T]``
        invokes :meth:`__class_getitem__` to produce a :class:`_LookupMarker`
        instance which the ``@module`` / ``@law_of_demeter`` decorators
        consume to install real factories or forwarding properties on the
        decorated class.

        The two-arg form ``lookup[Type, "name"]`` mixes a type and a string
        literal, which standard generic-alias subscript can't statically
        express; that form requires a localized ``# type: ignore[type-arg]``.
        """

        def __class_getitem__(cls, params: Any) -> _LookupMarker:
            if isinstance(params, tuple):
                return _LookupMarker(*params)
            return _LookupMarker(params)

        def __init_subclass__(cls, **kwargs: Any) -> None:
            raise TypeError("lookup cannot be subclassed")

        def __init__(self) -> None:
            raise TypeError(
                "lookup is not instantiable — use as a type annotation: lookup[Type]"
            )


def is_lookup_type(annotation: Any) -> bool:
    """Return True if *annotation* is a ``lookup[X]`` marker."""
    return isinstance(annotation, _LookupMarker)


def unwrap_lookup(annotation: Any) -> Any:
    """Unwrap ``lookup[X]`` to ``X``.  Returns *annotation* unchanged otherwise."""
    if isinstance(annotation, _LookupMarker):
        return annotation.inner_type
    return annotation


class _MakeMarker:
    """Internal wrapper returned by ``make[BaseType, ImplType]``.

    Stores the base type (used for the property return annotation) and
    the implementation type (actually instantiated by the factory).

    See :class:`_LookupMarker` for the rationale behind ``__call__``
    (Python 3.9 / 3.10 ``typing._type_check`` compatibility).
    """

    __slots__ = ("base_type", "impl_type")

    def __init__(self, base_type: type[Any], impl_type: type[Any]) -> None:
        self.base_type = base_type
        self.impl_type = impl_type

    def __repr__(self) -> str:
        base = getattr(self.base_type, "__name__", repr(self.base_type))
        impl = getattr(self.impl_type, "__name__", repr(self.impl_type))
        return f"make[{base}, {impl}]"

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        raise TypeError(
            "make markers are not callable — they are annotation values "
            "consumed by the @module decorator"
        )


if TYPE_CHECKING:
    # ``make[Base, Impl]`` aliases to ``Annotated[Base, ..., Impl]`` for
    # type checkers, which strip the metadata and treat the annotation as
    # ``Base`` at attribute-access sites — analogous to ``Final[T]`` /
    # ``ClassVar[T]``.  The ``Impl`` parameter is irrelevant for static
    # typing (the runtime returns an ``Impl`` instance which IS-A ``Base``,
    # so ``Base`` is the correct static type at access sites).
    #
    # ``TypeAliasType`` declares ``make`` as a generic type alias
    # parameterized over both ``_B`` and ``_I``, which is what lets type
    # checkers accept the two-argument subscript ``make[Base, Impl]``
    # while still erasing it to ``Base``.
    make = TypeAliasType(
        "make",
        Annotated[_B, "reactor_di.make", _I],
        type_params=(_B, _I),
    )
else:

    class make:
        """Annotation marker for subtype factory generation.

        Usage::

            @module(CachingStrategy.NOT_THREAD_SAFE)
            class AppModule:
                service: make[ServiceBase, ServiceImpl]   # factory returns ServiceImpl()

        ``make[Foo, Bar]`` tells ``@module`` to generate a factory that
        instantiates ``Bar`` (a subtype of ``Foo``).  The generated code is
        equivalent to::

            @cached_property
            def service(self) -> ServiceBase:
                return ServiceImpl()

        On a **component** with ``@law_of_demeter``, ``make[Foo, Bar]`` is
        unwrapped to ``Foo`` for attribute resolution purposes.

        Static-vs-runtime split
        -----------------------
        Under ``TYPE_CHECKING``, ``make`` is an alias for
        ``Annotated[_B, ..., _I]`` so that ``make[Base, Impl]`` erases to
        ``Base`` for static analyzers.  At **runtime**, ``make`` is this
        class, and ``make[Base, Impl]`` invokes :meth:`__class_getitem__`
        to produce a :class:`_MakeMarker` instance which the ``@module``
        decorator consumes to install a real factory returning an ``Impl``.
        """

        def __class_getitem__(cls, params: Any) -> _MakeMarker:
            if not isinstance(params, tuple) or len(params) != 2:
                raise TypeError(
                    "make requires exactly two type parameters: make[BaseType, ImplType]"
                )
            return _MakeMarker(params[0], params[1])

        def __init_subclass__(cls, **kwargs: Any) -> None:
            raise TypeError("make cannot be subclassed")

        def __init__(self) -> None:
            raise TypeError(
                "make is not instantiable — use as a type annotation: make[BaseType, ImplType]"
            )


def is_make_type(annotation: Any) -> bool:
    """Return True if *annotation* is a ``make[X, Y]`` marker."""
    return isinstance(annotation, _MakeMarker)


def unwrap_make(annotation: Any) -> Any:
    """Unwrap ``make[X, Y]`` to ``X`` (base type).  Returns *annotation* unchanged otherwise."""
    if isinstance(annotation, _MakeMarker):
        return annotation.base_type
    return annotation


_PRIMITIVE_EQUIVALENT_TYPES: Final[tuple[type[Any], ...]] = (
    int,
    float,
    str,
    bool,
    bytes,
    complex,
    list,
    dict,
    tuple,
    set,
    frozenset,
)


def get_alternative_names(name: str, default_prefix: str = "_") -> list[str]:
    """Generate alternative names based on naming conventions.

    Creates a list of name variations by removing common prefixes.
    Used for matching dependencies like '_config' to 'config'.

    Args:
        name: The base name to generate alternatives for.
        default_prefix: Default prefix to try removing (default: "_").

    Returns:
        List of alternative names to try.

    Example:
        >>> get_alternative_names("_config")
        ['config', '_config']
    """
    # Always include the original name, plus unprefixed version if applicable
    return (
        [name[len(default_prefix) :], name]
        if default_prefix and name.startswith(default_prefix)
        else [name]
    )


def is_primitive_type(attr_type: type[Any]) -> bool:
    """Check if a type should be treated as primitive.

    Args:
        attr_type: The type to check.

    Returns:
        True if the type is primitive and should not be auto-instantiated.
    """
    return attr_type in _PRIMITIVE_EQUIVALENT_TYPES


def has_constructor_assignment(class_type: type[Any], attr_name: str) -> bool:
    """Check if a class constructor assigns to a specific attribute.

    Uses regex to detect attribute assignments in __init__ source code.
    Handles both standard (self.attr = value) and annotated (self.attr: Type = value)
    assignment patterns. Dynamically uses the actual first parameter name.

    Args:
        class_type: The class to check.
        attr_name: The attribute name to look for in the constructor.

    Returns:
        True if the constructor assigns to the attribute, False otherwise.

    Example:
        >>> class Config:
        ...     def __init__(self):
        ...         self.timeout = 30
        >>> has_constructor_assignment(Config, "timeout")
        True
    """
    # Get the first parameter name (usually "self" but could be anything)
    init = class_type.__init__
    self = next(iter(inspect.signature(init).parameters))

    try:
        source = inspect.getsource(init)
    except OSError:
        # Source unavailable (e.g. dataclass-generated __init__) — can't prove
        # the assignment exists, so conservatively return False.
        return False
    # Use combined regex pattern to match both assignment and type annotation
    # Matches: self.attr = value OR self.attr: Type = value
    return bool(
        re.search(rf"{re.escape(self)}\s*\.\s*{re.escape(attr_name)}\s*[=:]", source)
    )


def resolve_abstract_property_conflicts(cls: type[Any]) -> None:
    """Replace inherited abstract @properties that collide with DI annotations.

    When a class has type annotations whose names match inherited abstract
    @property methods, the property descriptor (a data descriptor) takes MRO
    priority over ``__getattr__``, preventing lazy DI resolution.  This function
    detects such collisions and installs concrete ``@property`` descriptors
    backed by ``instance.__dict__``, then removes them from
    ``__abstractmethods__`` so the class can be instantiated.

    Safe to call multiple times — skips names that are no longer abstract.
    """
    abstracts: frozenset[str] = getattr(cls, "__abstractmethods__", frozenset())
    if not abstracts:
        return

    # Gather all annotation names across the MRO
    annotations: set[str] = set()
    for klass in cls.__mro__:
        if klass is not object:
            annotations.update(getattr(klass, "__annotations__", {}))

    resolved: set[str] = set()
    for name in annotations:
        if name not in abstracts:
            continue
        # Verify the abstract method is actually a @property on a parent class
        for parent in cls.__mro__[1:]:
            if name in parent.__dict__:
                attr = parent.__dict__[name]
                if isinstance(attr, property) and getattr(
                    attr.fget, "__isabstractmethod__", False
                ):
                    _install_dict_backed_property(cls, name)
                    resolved.add(name)
                break

    if resolved:
        cls.__abstractmethods__ = abstracts - resolved


def _install_dict_backed_property(cls: type[Any], name: str) -> None:
    """Install a concrete @property on *cls* that reads/writes ``__dict__``.

    The getter checks ``__dict__`` first (fast path for already-resolved
    values).  On a miss it delegates to the class's ``__getattr__`` — which
    is typically ``_module_getattr`` installed by the ``@module`` factory —
    to perform lazy DI resolution.
    """

    def _getter(self: Any) -> Any:
        try:
            return self.__dict__[name]
        except KeyError:
            # Delegate to __getattr__ for lazy DI resolution
            ga = type(self).__dict__.get("__getattr__")
            if ga is not None:
                return ga(self, name)
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{name}'"
            ) from None

    def _setter(self: Any, value: Any) -> None:
        self.__dict__[name] = value

    setattr(cls, name, property(_getter, _setter))


def pure_hasattr(obj: Any, attr_name: str) -> bool:
    """Check if an attribute exists without side effects like triggering descriptors/properties."""
    try:
        if attr_name in obj.__dict__:
            return True
    except AttributeError:
        pass

    for cls in type(obj).__mro__:
        try:
            if attr_name in cls.__dict__:
                return True
        except AttributeError:
            pass

        try:
            if attr_name in cls.__slots__:  # type: ignore[attr-defined]
                return True
        except AttributeError:
            pass

    return False
