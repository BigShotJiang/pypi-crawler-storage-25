"""Core logic"""
