"""Sample daemons"""
