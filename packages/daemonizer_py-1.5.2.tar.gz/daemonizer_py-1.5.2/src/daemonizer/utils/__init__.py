"""Utils func"""
