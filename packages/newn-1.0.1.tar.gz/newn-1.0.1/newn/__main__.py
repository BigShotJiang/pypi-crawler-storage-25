"""
Run a .nn file from the command line:
    python -m newn myfile.nn
"""
import sys
import os
from .preprocessor import nn_exec, nn_transform
from .errors import NewnError


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m newn <file.nn>")
        print("       python -m newn --transform <file.nn>   (show generated Python)")
        sys.exit(1)

    if sys.argv[1] == '--transform':
        if len(sys.argv) < 3:
            print("Usage: python -m newn --transform <file.nn>")
            sys.exit(1)
        path = sys.argv[2]
        with open(path, encoding='utf-8') as f:
            src = f.read()
        print(nn_transform(src))
        return

    path = sys.argv[1]
    if not os.path.isfile(path):
        print(f"Error: file not found: {path!r}", file=sys.stderr)
        sys.exit(1)

    with open(path, encoding='utf-8') as f:
        src = f.read()

    try:
        nn_exec(src)
    except NewnError as e:
        print(f"Newn error: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
