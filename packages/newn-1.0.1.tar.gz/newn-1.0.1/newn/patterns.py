"""
Pattern AST, tokenizer, parser, matching, and evaluation for .nn axioms.
"""
from __future__ import annotations
import re
from typing import Any, Dict, Optional, Set
from .errors import PatternError


# ---------------------------------------------------------------------------
# Sentinel — a unique object that is never equal to any value
# Used to detect "variable not bound" without conflicting with None
# ---------------------------------------------------------------------------

_UNBOUND = object()


# ---------------------------------------------------------------------------
# Pattern AST
# ---------------------------------------------------------------------------

class Pattern:
    pass


class VarPat(Pattern):
    """Matches any value and binds it to a name."""
    def __init__(self, name: str):
        self.name = name

    def __repr__(self):
        return f"VAR({self.name})"


class PropPat(Pattern):
    """Matches a PropValue with a given prop name; matches inner value against inner pattern."""
    def __init__(self, prop_name: str, inner: Pattern):
        self.prop_name = prop_name
        self.inner = inner

    def __repr__(self):
        return f"PROP({self.prop_name}, {self.inner})"


class LitPat(Pattern):
    """Matches an exact literal number."""
    def __init__(self, value):
        self.value = value

    def __repr__(self):
        return f"LIT({self.value})"


class BinPat(Pattern):
    """Arithmetic expression — used mainly in RHS evaluation."""
    def __init__(self, left: Pattern, op: str, right: Pattern):
        self.left = left
        self.op = op
        self.right = right

    def __repr__(self):
        return f"({self.left} {self.op} {self.right})"


class NegPat(Pattern):
    """Unary negation."""
    def __init__(self, inner: Pattern):
        self.inner = inner

    def __repr__(self):
        return f"NEG({self.inner})"


class DotAccessPat(Pattern):
    """
    Matches when *value* equals a previously-bound variable's N-th arg component.

    Written as ``x.2`` in an axiom LHS — meaning "the right-hand value must
    equal x.args[1]" where x was already bound by matching the left-hand arg.
    x must be bound to an object with an ``args`` sequence (UnresolvedExpr).

    Example::

        axiom furyfire: [for all x in my_cat], x five x.2 = fuel(x.1)
        # x   is the UnresolvedExpr matched on the left of five
        # x.2 constrains the right arg: it must equal x.args[1]
        # x.1 in the RHS is transformed by _transform_arg_access → x.args[0]
    """

    def __init__(self, var_name: str, index: int):
        self.var_name = var_name  # the already-bound variable name (e.g. 'x')
        self.index    = index     # 0-based index (x.2 → index=1)

    def __repr__(self):
        return f"DOTACCESS({self.var_name}, {self.index + 1})"


class PropFamilyPat(Pattern):
    """
    Matches PropValue(f'{prefix}{N}{suffix}', inner_val) for any integer N.

    This lets one axiom cover a whole family of props.  The user declares a
    numeric wildcard variable with a plain 'for all n' quantifier, then writes
    'pn(x)' in the axiom — meaning "for any prop named p0, p1, p2, p3, …".

    Example .nn usage::

        axiom gen: [for all n, for all pn(x), for all pn(y)], pn(x) add pn(y) = pn(x + y)

    Fires for:  p0(3) add p0(5) → p0(8)
                p7(1) add p7(4) → p7(5)
    But NOT:    p0(3) add p1(5)  (n must be the same on both sides)
    """

    def __init__(self, prefix: str, suffix: str, num_var: str, inner: Pattern):
        self.prefix  = prefix   # e.g. 'p'  in 'pn'
        self.suffix  = suffix   # e.g. ''   in 'pn'  /  '_val' in 'n_val'
        self.num_var = num_var  # e.g. 'n'
        self.inner   = inner    # pattern for the PropValue's inner value

    def __repr__(self):
        return f"FAMILY({self.prefix!r}+{self.num_var}+{self.suffix!r}, {self.inner})"


# ---------------------------------------------------------------------------
# Pattern matching
# ---------------------------------------------------------------------------

def match_pattern(
    pat: Pattern,
    val: Any,
    bindings: Dict[str, Any],
    plain_vars: Optional[Set[str]] = None,
) -> Optional[Dict]:
    """
    Try to match pat against val given existing bindings.
    Returns updated bindings on success, or None on failure.
    Bindings are immutable — a new dict is returned each time.

    plain_vars: the set of variable names that are *unconstrained* in their axiom
      (declared as plain `for all x` with no category or prop constraint).
      When a plain variable is about to bind to a PropValue, the match is
      rejected — unconstrained variables only accept plain (non-wrapped) values.
      This propagates through nested PropPat matching so that e.g. `star(x)` with
      unconstrained x also rejects `star(absent(3))`.
    """
    from .core import PropValue as _PV

    if isinstance(pat, VarPat):
        name = pat.name
        # Unconstrained variable: reject PropValues and UnresolvedExprs —
        # "for all x" = plain real values only (no symbolic wrappers of any kind)
        if plain_vars and name in plain_vars:
            from .core import UnresolvedExpr as _UE
            if isinstance(val, (_PV, _UE)):
                return None
        if name in bindings:
            return bindings if _values_equal(bindings[name], val) else None
        return {**bindings, name: val}

    if isinstance(pat, PropPat):
        if not isinstance(val, _PV) or val.prop_name != pat.prop_name:
            return None
        # Propagate plain_vars into the inner match (e.g. star(x) with plain x
        # should still reject star(absent(3)))
        return match_pattern(pat.inner, val.value, bindings, plain_vars)

    if isinstance(pat, LitPat):
        return bindings if _values_equal(pat.value, val) else None

    if isinstance(pat, NegPat):
        # -x matches val by solving: x = -val
        # Guard: the pattern "-x" only matches values that are ≤ 0 (non-positive).
        # Positive values like 5 are not "negative-looking", so they fall through
        # to other axioms.  This preserves the intuitive reading of  abs_val(-x) = x
        # (only fires for negative inputs, leaving positives to a fallback axiom).
        if isinstance(val, (int, float)) and val > 0:
            return None
        try:
            negated = -val
        except TypeError:
            return None
        return match_pattern(pat.inner, negated, bindings, plain_vars)

    if isinstance(pat, BinPat):
        return _binpat_match(pat, val, bindings, plain_vars)

    if isinstance(pat, DotAccessPat):
        if pat.var_name not in bindings:
            return None  # referenced variable not yet bound
        bound = bindings[pat.var_name]
        if not hasattr(bound, 'args') or len(bound.args) <= pat.index:
            return None  # not an args-bearing object or index out of range
        expected = bound.args[pat.index]
        return bindings if _values_equal(expected, val) else None

    if isinstance(pat, PropFamilyPat):
        if not isinstance(val, _PV):
            # Non-PropValue path: only valid for bare-variable families (empty
            # prefix and suffix), i.e. patterns written as x(x) where x is a
            # plain 'for all x' variable.  This lets UnresolvedCategory check
            # x(x) membership even when the stored arg is a plain integer
            # (e.g. from a swap axiom  x(x) ching y = y ching x(x)).
            if pat.prefix == '' and pat.suffix == '':
                num_val = val
                if pat.num_var in bindings:
                    if not _values_equal(bindings[pat.num_var], num_val):
                        return None
                    new_bindings = bindings
                else:
                    new_bindings = {**bindings, pat.num_var: num_val}
                # Check inner against val itself (no PropValue.value to unpack).
                return match_pattern(pat.inner, val, new_bindings, plain_vars)
            return None
        name = val.prop_name
        if not name.startswith(pat.prefix):
            return None
        rest = name[len(pat.prefix):]
        if pat.suffix:
            if not rest.endswith(pat.suffix):
                return None
            var_str = rest[: len(rest) - len(pat.suffix)]
        else:
            var_str = rest
        # Determine the variable's bound value from the extracted string.
        # For prefixed/suffixed patterns (e.g. 'p3', 'node7') the variable part
        # is always a numeric index — non-numeric prop names don't match.
        # For bare-variable families (prefix='' suffix='', e.g. the pattern z(x)
        # where z is declared `for all z`) the variable can match any prop name,
        # including alphabetic ones like 'hot' or 'warm'.
        # Any further range/category constraint on the variable is checked by
        # the Axiom's var_constraints after the pattern match returns.
        try:
            num_val: Any = int(var_str)
        except ValueError:
            try:
                num_val = float(var_str)
            except ValueError:
                if pat.prefix == '' and pat.suffix == '':
                    # Bare-variable family: accept any prop name as a string
                    num_val = var_str
                else:
                    return None  # prefixed/suffixed pattern requires a number
        # Bind variable (or check consistency if already bound)
        if pat.num_var in bindings:
            if bindings[pat.num_var] != num_val:
                return None
            new_bindings = bindings
        else:
            new_bindings = {**bindings, pat.num_var: num_val}
        # Match the inner pattern against the PropValue's inner value
        return match_pattern(pat.inner, val.value, new_bindings, plain_vars)

    return None


def _try_eval_pat(p: Pattern, bindings: Dict[str, Any]):
    """
    Try to fully evaluate a pattern using the current bindings.
    Returns (True, value) if the sub-expression is fully determined,
    or (False, None) if it still contains unbound variables.
    """
    from .core import PropValue as _PV
    if isinstance(p, LitPat):
        return True, p.value
    if isinstance(p, VarPat):
        if p.name in bindings:
            return True, bindings[p.name]
        return False, None
    if isinstance(p, NegPat):
        ok, v = _try_eval_pat(p.inner, bindings)
        if ok:
            try:
                return True, -v
            except Exception:
                return False, None
        return False, None
    if isinstance(p, BinPat):
        ok_l, lv = _try_eval_pat(p.left, bindings)
        ok_r, rv = _try_eval_pat(p.right, bindings)
        if ok_l and ok_r:
            try:
                if p.op == '+': return True, lv + rv
                if p.op == '-': return True, lv - rv
                if p.op == '*': return True, lv * rv
                if p.op == '/': return True, lv / rv
            except Exception:
                return False, None
        return False, None
    if isinstance(p, PropPat):
        from .core import PropValue as _PV
        ok, inner_v = _try_eval_pat(p.inner, bindings)
        if ok:
            return True, _PV(p.prop_name, inner_v)
        return False, None
    return False, None


def _binpat_match(
    pat: 'BinPat',
    val: Any,
    bindings: Dict[str, Any],
    plain_vars,
) -> Optional[Dict]:
    """
    Algebraically invert a BinPat to find variable bindings:
        left_pat  op  right_pat  =  val

    Cases:
      - both sides computable → evaluate and compare
      - left side unknown     → solve:  ? op right = val
      - right side unknown    → solve:  left op ?  = val
      - both unknown          → return None (underdetermined)
    """
    ok_l, lv = _try_eval_pat(pat.left, bindings)
    ok_r, rv = _try_eval_pat(pat.right, bindings)

    if ok_l and ok_r:
        # Fully determined: just evaluate and compare
        try:
            if pat.op == '+': computed = lv + rv
            elif pat.op == '-': computed = lv - rv
            elif pat.op == '*': computed = lv * rv
            elif pat.op == '/': computed = lv / rv
            else: return None
        except Exception:
            return None
        return bindings if _values_equal(computed, val) else None

    if ok_r and not ok_l:
        # Right known, solve for left: ? op rv = val
        try:
            op = pat.op
            if op == '+':   unknown = val - rv       # ? + rv = val → ? = val - rv
            elif op == '-': unknown = val + rv       # ? - rv = val → ? = val + rv
            elif op == '*':
                if rv == 0: return None
                unknown = val / rv                   # ? * rv = val → ? = val / rv
            elif op == '/': unknown = val * rv       # ? / rv = val → ? = val * rv
            else: return None
        except Exception:
            return None
        # If the solved unknown is integer-equivalent, keep it as int
        if isinstance(unknown, float) and unknown.is_integer():
            unknown = int(unknown)
        return match_pattern(pat.left, unknown, bindings, plain_vars)

    if ok_l and not ok_r:
        # Left known, solve for right: lv op ? = val
        try:
            op = pat.op
            if op == '+':   unknown = val - lv       # lv + ? = val → ? = val - lv
            elif op == '-': unknown = lv - val       # lv - ? = val → ? = lv - val
            elif op == '*':
                if lv == 0: return None
                unknown = val / lv                   # lv * ? = val → ? = val / lv
            elif op == '/':
                if val == 0: return None
                unknown = lv / val                   # lv / ? = val → ? = lv / val
            else: return None
        except Exception:
            return None
        if isinstance(unknown, float) and unknown.is_integer():
            unknown = int(unknown)
        return match_pattern(pat.right, unknown, bindings, plain_vars)

    # Both sides unknown — can't solve uniquely
    return None


def match_cat_pattern(
    pat: Pattern,
    val: Any,
    bindings: Dict[str, Any],
) -> Optional[Dict]:
    """
    Structural membership matcher for *category* predicates.

    Like ``match_pattern`` but with one important difference:
    ``PropFamilyPat`` with an empty prefix/suffix (i.e. a plain variable used as
    a dynamic prop name, e.g. ``y(x(y))``) will match **any** PropValue and bind
    the full prop_name string to the variable — not just numeric prop names.

    This allows category definitions like::

        category nested: [for all x, for all y], y(x(y))

    to correctly identify ``PropValue('happy', PropValue('sad', 'happy'))``
    (a value whose outer prop equals its inner value) regardless of whether
    the prop names are strings or numbers.

    All other pattern types delegate to the standard ``match_pattern``.
    """
    from .core import PropValue as _PV

    if isinstance(pat, PropFamilyPat) and pat.prefix == '' and pat.suffix == '':
        # Variable-as-dynamic-prop: matches ANY PropValue, binds prop_name → var
        if not isinstance(val, _PV):
            return None
        var_name  = pat.num_var      # variable name (e.g. 'y')
        prop_name = val.prop_name    # e.g. 'happy' or '3'
        if var_name in bindings:
            if str(bindings[var_name]) != str(prop_name):
                return None
            new_bindings = bindings
        else:
            new_bindings = {**bindings, var_name: prop_name}
        return match_cat_pattern(pat.inner, val.value, new_bindings)

    if isinstance(pat, VarPat):
        name = pat.name
        if name in bindings:
            return bindings if str(bindings[name]) == str(val) else None
        return {**bindings, name: val}

    if isinstance(pat, PropPat):
        if not isinstance(val, _PV) or val.prop_name != pat.prop_name:
            return None
        return match_cat_pattern(pat.inner, val.value, bindings)

    if isinstance(pat, LitPat):
        return bindings if _values_equal(pat.value, val) else None

    # For everything else (BinPat, NegPat, numeric PropFamilyPat) use standard
    return match_pattern(pat, val, bindings)


def _values_equal(a, b) -> bool:
    try:
        return a == b
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Pattern evaluation (RHS)
# ---------------------------------------------------------------------------

def evaluate_pattern(pat: Pattern, bindings: Dict[str, Any]) -> Any:
    """Evaluate a pattern given variable bindings. Used for RHS of axioms."""
    from .core import PropValue

    if isinstance(pat, VarPat):
        if pat.name not in bindings:
            raise PatternError(f"Variable '{pat.name}' not bound during evaluation")
        return bindings[pat.name]

    if isinstance(pat, PropPat):
        inner_val = evaluate_pattern(pat.inner, bindings)
        return PropValue(pat.prop_name, inner_val)

    if isinstance(pat, LitPat):
        return pat.value

    if isinstance(pat, BinPat):
        left = evaluate_pattern(pat.left, bindings)
        right = evaluate_pattern(pat.right, bindings)
        op = pat.op
        if op == '+': return left + right
        if op == '-': return left - right
        if op == '*': return left * right
        if op == '/': return left / right
        raise PatternError(f"Unknown arithmetic op: {op!r}")

    if isinstance(pat, NegPat):
        return -evaluate_pattern(pat.inner, bindings)

    if isinstance(pat, DotAccessPat):
        if pat.var_name not in bindings:
            raise PatternError(
                f"Variable '{pat.var_name}' not bound during DotAccessPat evaluation"
            )
        bound = bindings[pat.var_name]
        if not hasattr(bound, 'args') or len(bound.args) <= pat.index:
            raise PatternError(
                f"Cannot access .{pat.index + 1} on {bound!r} — "
                f"not an UnresolvedExpr or index out of range"
            )
        return bound.args[pat.index]

    if isinstance(pat, PropFamilyPat):
        if pat.num_var not in bindings:
            raise PatternError(
                f"Numeric variable '{pat.num_var}' not bound during PropFamilyPat evaluation"
            )
        n = bindings[pat.num_var]
        prop_name = f"{pat.prefix}{n}{pat.suffix}"
        inner_val = evaluate_pattern(pat.inner, bindings)
        return PropValue(prop_name, inner_val)

    raise PatternError(f"Unknown pattern type: {type(pat).__name__}")


# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------

_TOKEN_SPEC = [
    ('NUMBER', r'\d+(?:\.\d+)?'),
    ('NAME',   r'[a-zA-Z_][a-zA-Z0-9_]*'),
    ('OP',     r'[+\-*/]'),
    ('LPAREN', r'\('),
    ('RPAREN', r'\)'),
    ('COMMA',  r','),
    ('DOT',    r'\.'),
    ('WS',     r'\s+'),
]

_MASTER_RE = re.compile('|'.join(f'(?P<{name}>{pat})' for name, pat in _TOKEN_SPEC))


def _tokenize(text: str):
    tokens = []
    for m in _MASTER_RE.finditer(text):
        kind = m.lastgroup
        val  = m.group()
        if kind != 'WS':
            tokens.append((kind, val))
    # Check for unmatched characters
    matched_span = sum(len(m.group()) for m in _MASTER_RE.finditer(text))
    if matched_span < len(text.replace(' ', '').replace('\t', '')):
        pass  # best effort — pass through
    return tokens


# ---------------------------------------------------------------------------
# Recursive descent parser
# ---------------------------------------------------------------------------

class _Parser:
    def __init__(self, tokens, variables: Set[str], props: Set[str], families: Optional[dict] = None):
        self.tokens = tokens
        self.pos = 0
        self.variables = variables
        self.props = props
        self.families = families or {}  # family_name → (prefix, suffix, num_var)

    def peek(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return ('EOF', '')

    def consume(self, expected=None):
        if self.pos >= len(self.tokens):
            raise PatternError(f"Unexpected end of expression (expected {expected})")
        tok = self.tokens[self.pos]
        if expected and tok[0] != expected:
            raise PatternError(f"Expected {expected}, got {tok[0]} ({tok[1]!r})")
        self.pos += 1
        return tok

    def parse_expr(self) -> Pattern:
        return self._additive()

    def _additive(self) -> Pattern:
        left = self._multiplicative()
        while self.peek()[0] == 'OP' and self.peek()[1] in ('+', '-'):
            op = self.consume('OP')[1]
            right = self._multiplicative()
            left = BinPat(left, op, right)
        return left

    def _multiplicative(self) -> Pattern:
        left = self._unary()
        while self.peek()[0] == 'OP' and self.peek()[1] in ('*', '/'):
            op = self.consume('OP')[1]
            right = self._unary()
            left = BinPat(left, op, right)
        return left

    def _unary(self) -> Pattern:
        if self.peek() == ('OP', '-'):
            self.consume('OP')
            inner = self._primary()
            return NegPat(inner)
        return self._primary()

    def _primary(self) -> Pattern:
        tok_type, tok_val = self.peek()

        if tok_type == 'NUMBER':
            self.consume()
            v = float(tok_val) if '.' in tok_val else int(tok_val)
            return LitPat(v)

        if tok_type == 'LPAREN':
            self.consume('LPAREN')
            expr = self.parse_expr()
            self.consume('RPAREN')
            return expr

        if tok_type == 'NAME':
            name = self.consume()[1]
            # Dot-access pattern: VAR.N  (e.g. x.2 → DotAccessPat('x', 1))
            # Used in LHS to constrain an arg to equal a bound variable's N-th component.
            if self.peek()[0] == 'DOT':
                self.consume('DOT')
                if self.peek()[0] != 'NUMBER':
                    raise PatternError(
                        f"Expected integer index after '{name}.', "
                        f"got {self.peek()[0]} ({self.peek()[1]!r})"
                    )
                idx_str = self.consume('NUMBER')[1]
                if '.' in idx_str:
                    raise PatternError(
                        f"Index in '{name}.{idx_str}' must be a plain integer, not a float"
                    )
                idx = int(idx_str) - 1  # convert 1-based to 0-based
                return DotAccessPat(name, idx)
            if self.peek()[0] == 'LPAREN':
                self.consume('LPAREN')
                args = []
                if self.peek()[0] != 'RPAREN':
                    args.append(self.parse_expr())
                    while self.peek()[0] == 'COMMA':
                        self.consume('COMMA')
                        args.append(self.parse_expr())
                self.consume('RPAREN')
                if name in self.props:
                    if len(args) != 1:
                        raise PatternError(
                            f"Prop '{name}' takes exactly 1 argument, got {len(args)}"
                        )
                    return PropPat(name, args[0])
                elif name in self.families:
                    if len(args) != 1:
                        raise PatternError(
                            f"Prop family '{name}' takes exactly 1 argument, got {len(args)}"
                        )
                    prefix, suffix, num_var = self.families[name]
                    return PropFamilyPat(prefix, suffix, num_var, args[0])
                elif name in self.variables:
                    # Variable used as a dynamic prop name: x(u) where x is 'for all x'.
                    # At match time the prop name will be whatever x resolves to.
                    # Produces PropFamilyPat('', '', name, inner) — the variable IS
                    # the entire prop name (empty prefix and suffix).
                    if len(args) != 1:
                        raise PatternError(
                            f"Dynamic prop '{name}(...)' takes exactly 1 argument, got {len(args)}"
                        )
                    return PropFamilyPat('', '', name, args[0])
                else:
                    raise PatternError(
                        f"'{name}' is not a declared prop or variable — cannot use it as a "
                        f"function in a pattern. Declare it with 'prop {name}: None' or "
                        f"add it to the 'for all' clause."
                    )
            else:
                if name in self.variables:
                    return VarPat(name)
                raise PatternError(
                    f"'{name}' is not a declared variable in this axiom's 'for all' clause"
                )

        raise PatternError(f"Unexpected token: {tok_type} ({tok_val!r})")


def parse_pattern(
    text: str,
    variables: Set[str],
    props: Set[str],
    families: Optional[dict] = None,
) -> Pattern:
    """
    Parse an expression string into a Pattern AST.

    families: optional dict mapping family_name → (prefix, suffix, num_var).
    When provided, names like 'pn' that appear in families are parsed as
    PropFamilyPat rather than PropPat or VarPat.
    """
    text = text.strip()
    if not text:
        raise PatternError("Empty expression")
    tokens = _tokenize(text)
    parser = _Parser(tokens, variables, props, families=families)
    pat = parser.parse_expr()
    if parser.pos < len(tokens):
        leftover = tokens[parser.pos:]
        raise PatternError(f"Unexpected tokens after expression: {leftover}")
    return pat
