"""
Core runtime objects for Newnumber: PropValue, UnresolvedExpr, Category, Axiom, _NNOp, AxiomEngine.
"""
from __future__ import annotations
import re
import textwrap
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from .errors import AxiomNotFoundError, NewnError, NewNumberError
from .patterns import Pattern, PropPat, PropFamilyPat, VarPat, match_pattern


# ---------------------------------------------------------------------------
# PropValue — a value wrapped with a named property/attribute
# ---------------------------------------------------------------------------

class PropValue:
    """
    A value wrapped with a named property.
    star(5) creates PropValue('star', 5).
    The meaning of the property is entirely defined by axioms.
    """

    def __init__(self, prop_name: str, value: Any):
        self.prop_name = prop_name
        self.value = value

    def __repr__(self):
        return f"{self.prop_name}({self.value!r})"

    def __str__(self):
        return repr(self)

    def __eq__(self, other):
        if isinstance(other, PropValue):
            return self.prop_name == other.prop_name and self.value == other.value
        return False

    def __hash__(self):
        try:
            return hash((self.prop_name, self.value))
        except TypeError:
            return hash((self.prop_name, id(self.value)))

    def _op_error(self, op: str, other: Any) -> None:
        from .errors import NewnError
        raise NewnError(
            f"\n  [Newn] Cannot use Python operator '{op}' on a prop value ({self!r}).\n"
            f"  Prop values must be combined through Newn ops, not Python operators.\n"
            f"  Define an op and an axiom, then write:  {self!r} your_op {other!r}"
        )

    def __add__(self, other):  self._op_error("+", other)
    def __radd__(self, other): self._op_error("+", other)
    def __sub__(self, other):  self._op_error("-", other)
    def __rsub__(self, other): self._op_error("-", other)
    def __mul__(self, other):  self._op_error("*", other)
    def __rmul__(self, other): self._op_error("*", other)
    def __truediv__(self, other):  self._op_error("/", other)
    def __rtruediv__(self, other): self._op_error("/", other)

    def __neg__(self):
        from .errors import NewnError
        raise NewnError(
            f"\n  [Newn] Cannot negate a prop value ({self!r}) with Python's unary minus.\n"
            f"  Define a 'negate' op and an axiom to give negation a meaning."
        )


# ---------------------------------------------------------------------------
# VisualDict — dict subclass that renders PropValue keys as readable strings
# ---------------------------------------------------------------------------

class VisualDict(dict):
    """
    A plain Python dict with one extra power: when you index it with a
    PropValue (the result of a Newn op), instead of raising a KeyError it
    renders the PropValue into a human-readable string by looking up each
    component in its own key-value table.

    In .nn files, dict literals are automatically wrapped with VisualDict,
    so you can write normal-looking dicts and then index them with op calls:

    Example (.nn)::

        op op: None
        op nop: None
        axiom new:  [for all x, for all y], x op  y = x(y)
        axiom new2: [for all x],             x nop x = double(x)

        d = {1: "happy", 2: "news", 3: "double"}
        print(d[1 op 3])   # → "happy(double)"
        print(d[1 nop 1])  # → "double(happy)"

    Lookup rules for each component of the PropValue:
      - If the component is an int key that exists in the dict → use that value.
      - If the component is a string that parses as an int key → use that value.
      - Otherwise use the component string representation as-is.
    """

    def __getitem__(self, key):
        if isinstance(key, PropValue):
            return self._render(key)
        return super().__getitem__(key)

    def _lookup(self, key) -> str:
        """Return the display string for a single component value.

        Lookup order:
          1. Direct key (int, str, float, or whatever was used as a dict key)
          2. ``int(key)`` coercion — handles prop_name strings like ``'3'``
          3. ``float(key)`` coercion — handles prop_name strings like ``'3.5'``
          4. Fall back to ``str(key)`` as-is
        """
        try:
            return str(super().__getitem__(key))
        except (KeyError, TypeError):
            pass
        try:
            return str(super().__getitem__(int(key)))
        except (KeyError, TypeError, ValueError):
            pass
        try:
            return str(super().__getitem__(float(key)))
        except (KeyError, TypeError, ValueError):
            pass
        return str(key)

    def _render(self, value) -> str:
        """Recursively render a PropValue using this dict's value table."""
        if isinstance(value, PropValue):
            prop_str  = self._lookup(value.prop_name)
            inner_str = self._render(value.value)
            return f"{prop_str}({inner_str})"
        return self._lookup(value)


# ---------------------------------------------------------------------------
# UnresolvedExpr — a symbolic expression that stayed symbolic via recursion guard
# ---------------------------------------------------------------------------

class UnresolvedExpr:
    """
    Returned when the recursion guard fires: an axiom's RHS calls the same op
    being computed, so the call returns symbolically rather than looping.

    Example:
        axiom sym: [for all x, for all absent(y)], x add absent(y) = x add absent(y)
        result = 9 |add| absent(3)  # → UnresolvedExpr('add', (9, absent(3)))
        print(result)               # → 9 add absent(3)
    """

    def __init__(self, op_name: str, args: tuple):
        self.op_name = op_name
        self.args = args

    def __repr__(self):
        if len(self.args) == 2:
            return f"{self.args[0]!r} {self.op_name} {self.args[1]!r}"
        if len(self.args) == 1:
            return f"{self.op_name}({self.args[0]!r})"
        arg_str = ', '.join(repr(a) for a in self.args)
        return f"{self.op_name}({arg_str})"

    def __eq__(self, other):
        return (
            isinstance(other, UnresolvedExpr)
            and self.op_name == other.op_name
            and self.args == other.args
        )


# ---------------------------------------------------------------------------
# Category — a domain of values defined by a predicate
# ---------------------------------------------------------------------------

class Category:
    """
    A named domain. A value belongs to the category if its predicate returns True.
    Supports Python's `in` operator natively: `value in category`.
    """

    def __init__(self, name: str, predicate: Callable[[Any], bool]):
        self.name = name
        self._predicate = predicate

    def contains(self, value: Any) -> bool:
        try:
            return bool(self._predicate(value))
        except Exception:
            return False

    def __contains__(self, value: Any) -> bool:
        return self.contains(value)

    def __repr__(self):
        return f"Category({self.name!r})"


class UnresolvedCategory(Category):
    """
    A category whose members are UnresolvedExpr values matching a specific
    operation name and argument shape.

    Defined with bracket syntax in a .nn file:

        category absent_present: [for all absent(x), for all y], absent(x) add y

    This creates a category that matches any value of the form:
        UnresolvedExpr('add', (absent(...), <any value>))

    In axiom RHS code, components of a matched UnresolvedExpr are accessed with
    positional dot notation (transformed by the preprocessor):

        x.1  →  x.args[0]   (first argument of the unresolved expression)
        x.2  →  x.args[1]   (second argument)
        x.3  →  x.args[2]   (and so on)

    Example axiom using the category:

        axiom flip: [for all x in absent_present, for all y], x add y = (x.2 add y) add x.1
    """

    def __init__(
        self,
        name: str,
        op_name: str,
        left_pat: Optional[Pattern],
        right_pat: Optional[Pattern],
        engine: Optional[Any] = None,
    ):
        self.op_name = op_name
        self.left_pat = left_pat
        self.right_pat = right_pat

        _op = op_name
        _lp = left_pat
        _rp = right_pat
        _eng = engine  # may be None if not registered through register_ucat_by_key

        def pred(v: Any) -> bool:
            # ── Primary check: v is a symbolic (unresolved) expression ──────
            if isinstance(v, UnresolvedExpr) and v.op_name == _op:
                args = v.args
                empty: frozenset = frozenset()
                lp_ok = True
                if _lp is not None:
                    if len(args) < 1:
                        lp_ok = False
                    elif match_pattern(_lp, args[0], {}, empty) is None:
                        lp_ok = False
                rp_ok = True
                if _rp is not None:
                    arg_idx = 1 if _lp is not None else 0
                    if len(args) <= arg_idx:
                        rp_ok = False
                    elif match_pattern(_rp, args[arg_idx], {}, empty) is None:
                        rp_ok = False
                if lp_ok and rp_ok:
                    return True

            # ── Fallback: v was produced as the resolved result of this op ──
            # (only available when engine is provided)
            if _eng is not None:
                try:
                    resolved = _eng._op_call_results.get(_op)
                    if resolved is not None:
                        try:
                            return v in resolved
                        except TypeError:
                            return any(r == v for r in resolved)
                except Exception:
                    pass

            return False

        super().__init__(name, pred)

    def __repr__(self):
        return f"UnresolvedCategory({self.name!r}, op={self.op_name!r})"


# ---------------------------------------------------------------------------
# BacktrackResult — returned by the backtracking syntax
# ---------------------------------------------------------------------------

def _nn_repr(v: Any) -> str:
    """Convert a Newn value to its source-notation string.

    PropValue('5', PropValue('7', 63)) → '5(7(63))'
    Plain int/float/str → str(v)
    """
    if isinstance(v, PropValue):
        return f"{v.prop_name}({_nn_repr(v.value)})"
    return str(v)


def _extract_lhs_from_source(source_line: str) -> str:
    """Extract just the LHS call portion from an axiom source line.

    'axiom shine: [for all a], a shine a = bright(a)' → 'a shine a'
    'axiom c: [None], 5 supad 7 = 9'                  → '5 supad 7'
    Falls back to the full stripped line if the pattern is not found.
    """
    s = source_line.strip()
    # Find the last '],' which closes the quantifier block
    bracket_end = s.rfind('],')
    if bracket_end < 0:
        return s
    rest = s[bracket_end + 2:].strip()
    # Walk forward looking for the first top-level '=' that is not ==, !=, <=, >=
    depth = 0
    for i, ch in enumerate(rest):
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif ch == '=' and depth == 0:
            prev = rest[i - 1] if i > 0 else ''
            nxt  = rest[i + 1] if i + 1 < len(rest) else ''
            if prev not in ('!', '<', '>', '=') and nxt != '=':
                return rest[:i].strip()
    return rest.strip()


# ── Structural backtracking helpers ─────────────────────────────────────────
# These support the bidirectional pattern-matching approach used by
# AxiomEngine.backtrack_structural: normalise text patterns, compare them
# structurally, and substitute variable names between the two sides.

def _extract_rhs_from_source(source_line: str) -> str:
    """Extract the raw RHS expression text from an axiom source line.

    'axiom shine: [for all a], a shine a = bright(a)' → 'bright(a)'
    Returns '' when the source line cannot be parsed.
    """
    s = source_line.strip()
    bracket_end = s.rfind('],')
    if bracket_end < 0:
        return ''
    rest = s[bracket_end + 2:].strip()
    depth = 0
    for i, ch in enumerate(rest):
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif ch == '=' and depth == 0:
            prev = rest[i - 1] if i > 0 else ''
            nxt  = rest[i + 1] if i + 1 < len(rest) else ''
            if prev not in ('!', '<', '>', '=') and nxt != '=':
                return rest[i + 1:].strip()
    return ''


def _st_normalize(text: str, var_names: set) -> Tuple[str, Dict[str, str]]:
    """
    Replace variable names in *text* with positional placeholders ``$0``,
    ``$1``, … in left-to-right order of first appearance.

    Non-variable identifiers, literals, operators, and punctuation are kept
    unchanged.  Whitespace is collapsed to single spaces so that spacing
    differences between source versions don't affect matching.

    Returns ``(normalised_text, {var_name: placeholder})``.
    """
    parts = re.split(r'([A-Za-z_][A-Za-z0-9_]*)', text)
    mapping: Dict[str, str] = {}
    counter = 0
    result: List[str] = []
    for tok in parts:
        if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', tok) and tok in var_names:
            if tok not in mapping:
                mapping[tok] = f'${counter}'
                counter += 1
            result.append(mapping[tok])
        else:
            result.append(tok)
    normalised = ' '.join(''.join(result).split())
    return normalised, mapping


def _st_structural_match(
    pat_text:   str,
    pat_vars:   set,
    target_text: str,
    target_vars: set,
) -> Optional[Dict[str, str]]:
    """
    Attempt a structural match of *pat_text* (wildcards = *pat_vars*) against
    *target_text* (wildcards = *target_vars*).

    Both texts are normalised independently — variables are replaced with
    positional placeholders in order of first appearance.  If the normalised
    forms are identical the match succeeds and a ``{axiom_var → pattern_var}``
    substitution dict is returned.  Returns ``None`` on failure.

    Example::

        _st_structural_match('x add y', {'x','y'}, 'a add b', {'a','b'})
        # → {'a': 'x', 'b': 'y'}

        _st_structural_match('hot(x)', {'x'}, 'hot(v)', {'v'})
        # → {'v': 'x'}
    """
    pat_norm, pat_map   = _st_normalize(pat_text,   pat_vars)
    tgt_norm, tgt_map   = _st_normalize(target_text, target_vars)
    if pat_norm != tgt_norm:
        return None
    # Build reverse maps: placeholder ($N) → variable name
    pat_rev = {v: k for k, v in pat_map.items()}   # $N → pat_var
    tgt_rev = {v: k for k, v in tgt_map.items()}   # $N → ax_var
    # Pair up: same placeholder used in the same position → same semantic var
    ax_to_pat: Dict[str, str] = {}
    for ph, pat_var in pat_rev.items():
        ax_var = tgt_rev.get(ph)
        if ax_var is not None:
            ax_to_pat[ax_var] = pat_var
    return ax_to_pat


def _st_apply_mapping(text: str, ax_to_pat: Dict[str, str]) -> str:
    """
    In *text*, replace each occurrence of an axiom variable name (key) with
    the corresponding pattern variable name (value).  Only whole-word
    replacements are made — no partial identifier substitutions.

    Longer variable names are substituted first to avoid partial matches
    (e.g. ``'ab'`` before ``'a'``).
    """
    for ax_var, pat_var in sorted(ax_to_pat.items(), key=lambda kv: -len(kv[0])):
        text = re.sub(
            r'(?<![A-Za-z0-9_])' + re.escape(ax_var) + r'(?![A-Za-z0-9_])',
            pat_var,
            text,
        )
    return text


class BacktrackResult:
    """
    Returned by the backtracking syntax::

        hits = {[for all x, for all y], x(y)}   ← axiom-mode
        hits = {9}                                ← value-mode

    **Axiom mode** (vars declared with ``[for all …]``)
        Prints the **LHS call** of every unique axiom whose output matches
        the declared shape, with the axiom's own variable names intact.
        Example: ``a shine a``

    **Value mode** (no vars — literal target such as ``{9}``)
        Prints the **LHS call with concrete values substituted** for every
        probe input that produced the target.
        Example: ``3 add 5``  (if the target is 8 and 3 add 5 = 8)

    Useful methods
    --------------
    ``result.values()``   — list of matched values (one per match)
    ``result.bindings()`` — list of variable-binding dicts
    ``result.sources()``  — list of axiom names / source labels
    ``result.axioms()``   — list of ``(axiom_name, lhs_text)`` for each
                            unique contributing axiom
    """

    def __init__(self, items, *, engine=None, axiom_mode: bool = False):
        # Each item is a 4-tuple (bindings, value, source, lhs_text).
        # Accept 2-, 3-, or 4-tuples for backward compatibility.
        normalised: List[Tuple[dict, Any, str, str]] = []
        for item in items:
            if len(item) == 4:
                normalised.append(tuple(item))          # type: ignore[arg-type]
            elif len(item) == 3:
                normalised.append((item[0], item[1], item[2], ''))
            else:
                normalised.append((item[0], item[1], '?', ''))
        self._items = normalised
        self._engine    = engine       # AxiomEngine, for source-line look-ups
        self._axiom_mode = axiom_mode  # True when vars were declared in {[for all …], …}

    def __iter__(self):
        """Iterate as (bindings, value) 2-tuples for backward compatibility."""
        return ((b, v) for b, v, _, _ in self._items)

    def __len__(self):
        return len(self._items)

    def __bool__(self):
        return bool(self._items)

    def values(self) -> List[Any]:
        """Return the list of matched values (one per match found)."""
        return [v for _, v, _, _ in self._items]

    def bindings(self) -> List[dict]:
        """Return the list of variable-binding dicts for each match."""
        return [b for b, _, _, _ in self._items]

    def sources(self) -> List[str]:
        """Return the list of axiom names / source labels for each match."""
        return [s for _, _, s, _ in self._items]

    def items(self) -> List[Tuple[dict, Any, str]]:
        """Return ``(bindings, value, source)`` 3-tuples (backward-compatible)."""
        return [(b, v, s) for b, v, s, _ in self._items]

    def axioms(self) -> List[Tuple[str, str]]:
        """Return ``(axiom_name, lhs_text)`` for each unique contributing axiom.

        *lhs_text* is the LHS call of the axiom as it appears in the ``.nn``
        source (variables still as declared for axiom-mode results, or with
        concrete values substituted for literal-mode results).

        ``(recorded from OP)`` helper labels are silently omitted.
        """
        seen: dict = {}
        for _, _, s, lhs in self._items:
            if s in seen:
                continue
            if s.startswith('(recorded from ') and s.endswith(')'):
                continue
            seen[s] = lhs
        return [(name, lhs) for name, lhs in seen.items()]

    def __repr__(self):
        if not self._items:
            return "BacktrackResult([])"
        if self._axiom_mode:
            # Axiom-mode: one line per unique axiom (skip recorded-result labels).
            seen: dict = {}
            for _, _, s, lhs in self._items:
                if s in seen:
                    continue
                if s.startswith('(recorded from ') and s.endswith(')'):
                    continue
                seen[s] = lhs
            if not seen:
                return "BacktrackResult([])"
            inner = ",\n  ".join(seen.values())
        else:
            # Value-mode (literal): one entry per distinct filled-LHS call.
            seen_lhs: dict = {}
            for _, v, s, lhs in self._items:
                if s.startswith('(recorded from ') and s.endswith(')'):
                    continue
                key = lhs or repr(v)
                if key not in seen_lhs:
                    seen_lhs[key] = key
            inner = ",\n  ".join(seen_lhs.values())
            if not inner:
                return "BacktrackResult([])"
        return f"BacktrackResult([\n  {inner}\n])"


# ---------------------------------------------------------------------------
# PropFactory — returned by make_prop(); callable + membership-checkable
# ---------------------------------------------------------------------------

class PropFactory:
    """
    Returned by `prop name: None`.  Supports:

      - prop_name(value)        →  PropValue(prop_name, value)   [create]
      - value in prop_name      →  True if value has that prop   [__contains__]
      - prop_name.contains(v)   →  same as above                 [explicit]
    """

    def __init__(self, prop_name: str):
        self._prop_name = prop_name
        self._is_nn_prop = True

    def __call__(self, value: Any) -> PropValue:
        return PropValue(self._prop_name, value)

    def __contains__(self, value: Any) -> bool:
        return isinstance(value, PropValue) and value.prop_name == self._prop_name

    def contains(self, value: Any) -> bool:
        return isinstance(value, PropValue) and value.prop_name == self._prop_name

    def __repr__(self):
        return f"Prop({self._prop_name!r})"


# ---------------------------------------------------------------------------
# Axiom — a single universal rule defining an operation
# ---------------------------------------------------------------------------

class Axiom:
    """
    A universal rule: [for all x, for all absent(y)], LHS = RHS.

    var_constraints: per-variable constraints — list of (var_name, predicate | None).
      - None = unconstrained (plain values only during pattern matching)
      - callable = must satisfy predicate after matching

    rhs_code: the RHS as a Python expression string (ops already pipe-transformed).
      Evaluated at call time with a namespace that includes all engine ops/props
      plus the variable bindings from pattern matching.

    source_line: the original .nn source line (for error messages).
    nn_file: the .nn file this axiom came from (for error messages).
    """

    def __init__(
        self,
        name: str,
        op_name: str,
        variables: List[str],
        category: Optional[Category],
        left_pat: Optional[Pattern],
        right_pat: Optional[Pattern],
        rhs_code: str,
        engine: 'AxiomEngine',
        var_constraints: Optional[List[Tuple[str, Optional[Callable]]]] = None,
        source_line: str = '',
        nn_file: str = '<inline>',
        nn_lineno: int = 0,
        severity: str = 'UNKNOWN',
    ):
        self.name = name
        self.op_name = op_name
        self.variables = variables
        self.category = category
        self.left_pat = left_pat
        self.right_pat = right_pat
        self.rhs_code = rhs_code
        self.engine = engine
        self.var_constraints: List[Tuple[str, Optional[Callable]]] = var_constraints or []
        self.source_line = source_line
        self.nn_file = nn_file
        self.nn_lineno = nn_lineno
        self.severity = severity
        # Cache plain_vars at construction time (not re-computed every call)
        self._plain_vars: Set[str] = self._compute_plain_vars()

    def _compute_plain_vars(self) -> Set[str]:
        """
        Return variable names that are unconstrained (declared as plain `for all x`
        with no category or prop constraint).

        These variables only accept plain (non-PropValue) values during pattern
        matching. If the global category is set, ALL vars can bind to PropValues
        (they'll be filtered by the category check post-match).
        """
        all_vars: Set[str] = set(self.variables)
        if self.category is not None:
            return set()
        constrained = {vn for vn, pred in self.var_constraints if pred is not None}
        return all_vars - constrained

    def signature(self) -> str:
        """Human-readable description of this axiom's pattern."""
        parts = []
        for var_name, pred in self.var_constraints:
            if pred is None:
                parts.append(f"plain {var_name}")
            else:
                parts.append(f"{var_name} [constrained]")
        if self.category:
            cat_note = f" [all in {self.category.name}]"
        else:
            cat_note = ""
        constraint_str = ', '.join(parts) if parts else 'unconstrained'
        left = repr(self.left_pat) if self.left_pat else '—'
        right = repr(self.right_pat) if self.right_pat else '—'
        return (
            f"axiom '{self.name}'{cat_note}: "
            f"({constraint_str}) | LHS=({left}) op='{self.op_name}' RHS-pat=({right}) "
            f"→ {self.rhs_code!r}"
        )

    def _match_patterns(
        self,
        args: tuple,
        initial_bindings: Optional[Dict] = None,
        lenient: bool = False,
    ) -> Optional[Dict]:
        """
        Run only the pattern-matching and constraint-checking steps.
        Returns the bindings dict on success, or None if the axiom doesn't match.
        Does NOT evaluate the RHS.

        initial_bindings: pre-bound variables (used by template axiom dispatch to
          inject the value extracted from the op name, e.g. x=5 for 'use5').
        lenient: when True, suppress the plain-vars restriction so that
          unconstrained variables (for all y) accept PropValues and
          UnresolvedExprs too.  Used by the recursion guard so that a
          recursive call whose arg types differ from the axiom's original
          input still triggers the guard and returns an UnresolvedExpr.
        """
        plain_vars = frozenset() if lenient else self._plain_vars
        bindings: Dict[str, Any] = dict(initial_bindings) if initial_bindings else {}

        # Upfront arity check: reject if caller passed more args than this axiom expects.
        expected_argc = (1 if self.left_pat is not None else 0) + \
                        (1 if self.right_pat is not None else 0)
        if len(args) > expected_argc:
            return None

        if self.left_pat is not None:
            if len(args) < 1:
                return None
            bindings = match_pattern(self.left_pat, args[0], bindings, plain_vars)
            if bindings is None:
                return None

        if self.right_pat is not None:
            arg_idx = 1 if self.left_pat is not None else 0
            if len(args) <= arg_idx:
                return None
            bindings = match_pattern(self.right_pat, args[arg_idx], bindings, plain_vars)
            if bindings is None:
                return None

        if self.category is not None:
            for val in bindings.values():
                if not self.category.contains(val):
                    return None

        for var_name, predicate in self.var_constraints:
            if predicate is None:
                continue
            val = bindings.get(var_name)
            if val is None:
                continue
            try:
                if not predicate(val):
                    return None
            except Exception:
                return None

        return bindings

    def matches_args(self, args: tuple, lenient: bool = False) -> bool:
        """Return True if this axiom's patterns match args (no RHS evaluation).

        lenient: when True, unconstrained (plain) variables accept any value,
          including PropValues.  Used by the recursion guard.
        """
        return self._match_patterns(args, lenient=lenient) is not None

    def try_apply(self, args: tuple, initial_bindings: Optional[Dict] = None) -> Optional[Any]:
        """
        Try to apply this axiom to the given args.
        Returns the computed result if the axiom matches, or None if it doesn't.

        NOTE: None is also a valid Python return value. To distinguish "no match"
        from "matched and returned None", try_apply returns a (_MATCHED, result)
        sentinel via the internal helper and the public interface wraps it.
        This is handled transparently — callers use the public interface only.

        initial_bindings: pre-bound variables injected before pattern matching
          (used by template axiom dispatch, e.g. x=5 for the 'use5' op call).
        """
        bindings = self._match_patterns(args, initial_bindings)
        if bindings is None:
            return None

        try:
            ns = self.engine._build_rhs_namespace(bindings)
            result = eval(self.rhs_code, {'__builtins__': __builtins__}, ns)
            return (_MATCHED, result)
        except NewnError:
            raise
        except SyntaxError:
            loc = f"{self.nn_file}:{self.nn_lineno}" if self.nn_lineno else self.nn_file
            raise NewnError(
                f"\n  [Newn] Axiom '{self.name}' ({loc}) has a syntax error in its RHS.\n"
                f"  RHS expression: {self.rhs_code}\n"
                f"  Original axiom: {self.source_line.strip()}\n"
                f"  Tip: check that all ops are declared before this axiom and\n"
                f"       that the expression is valid math (no missing operators, etc.)."
            )
        except NameError as e:
            bad = str(e).split("'")[1] if "'" in str(e) else str(e)
            loc = f"{self.nn_file}:{self.nn_lineno}" if self.nn_lineno else self.nn_file
            known_names = sorted(self.engine._props | self.engine._ops.keys())
            # Find similar names to suggest
            import difflib
            close = difflib.get_close_matches(bad, known_names, n=3, cutoff=0.6)
            suggestion = (f"\n  Did you mean: {', '.join(repr(c) for c in close)}?" if close else "")
            raise NewnError(
                f"\n  [Newn] Axiom '{self.name}' ({loc}): undefined name '{bad}' in RHS.\n"
                f"  RHS expression: {self.rhs_code}\n"
                f"  Original axiom: {self.source_line.strip()}\n"
                f"  Fix options:\n"
                f"    • Prop-call in RHS (e.g. '{bad}(x)'): just write it — Newn now\n"
                f"      auto-registers props found anywhere in axiom LHS or RHS.\n"
                f"    • Python builtin or helper: make sure it is imported / in scope.\n"
                f"    • Typo: check spelling against known names below.{suggestion}\n"
                f"  Known names: {known_names}"
            )
        except TypeError as e:
            loc = f"{self.nn_file}:{self.nn_lineno}" if self.nn_lineno else self.nn_file
            raise NewnError(
                f"\n  [Newn] Axiom '{self.name}' ({loc}): type error in RHS.\n"
                f"  RHS expression: {self.rhs_code}\n"
                f"  Original axiom: {self.source_line.strip()}\n"
                f"  Error: {e}\n"
                f"  Tip: Newn op results (PropValues) cannot be used with plain Python\n"
                f"       operators (+, -, *, /). Use a Newn op instead, e.g.\n"
                f"       write  x add y  rather than  x + y."
            )
        except AttributeError as e:
            loc = f"{self.nn_file}:{self.nn_lineno}" if self.nn_lineno else self.nn_file
            raise NewnError(
                f"\n  [Newn] Axiom '{self.name}' ({loc}): attribute error in RHS.\n"
                f"  RHS expression: {self.rhs_code}\n"
                f"  Original axiom: {self.source_line.strip()}\n"
                f"  Error: {e}\n"
                f"  Tip: .1 and .2 only work on UnresolvedExpr values (produced when\n"
                f"       an axiom calls itself). Plain numbers and PropValues do not\n"
                f"       have these attributes."
            )
        except Exception as e:
            loc = f"{self.nn_file}:{self.nn_lineno}" if self.nn_lineno else self.nn_file
            raise NewnError(
                f"\n  [Newn] Axiom '{self.name}' ({loc}): error while evaluating RHS.\n"
                f"  RHS expression: {self.rhs_code}\n"
                f"  Original axiom: {self.source_line.strip()}\n"
                f"  Error ({type(e).__name__}): {e}\n"
                f"  Tip: check that all variables are numeric or PropValues as the\n"
                f"       axiom expects, and that any Python helper functions are in scope."
            )

    def _why_not(self, args: tuple) -> str:
        """Return a human-readable explanation of why this axiom did NOT match args."""
        expected_argc = (1 if self.left_pat is not None else 0) + \
                        (1 if self.right_pat is not None else 0)
        if len(args) > expected_argc:
            return (
                f"too many arguments: axiom expects {expected_argc}, "
                f"but {len(args)} were given"
            )
        plain_vars = self._plain_vars
        bindings: Dict[str, Any] = {}

        if self.left_pat is not None:
            if len(args) < 1:
                return "needs at least 1 argument"
            b = match_pattern(self.left_pat, args[0], bindings, plain_vars)
            if b is None:
                return (
                    f"left arg {args[0]!r} did not match pattern {self.left_pat!r} "
                    f"(plain vars: {plain_vars})"
                )
            bindings = b

        if self.right_pat is not None:
            arg_idx = 1 if self.left_pat is not None else 0
            if len(args) <= arg_idx:
                return f"needs at least {arg_idx + 1} argument(s)"
            b = match_pattern(self.right_pat, args[arg_idx], bindings, plain_vars)
            if b is None:
                return (
                    f"right arg {args[arg_idx]!r} did not match pattern {self.right_pat!r} "
                    f"(plain vars: {plain_vars})"
                )
            bindings = b

        if self.category is not None:
            for var_name, val in bindings.items():
                if not self.category.contains(val):
                    return (
                        f"variable '{var_name}' = {val!r} is not in category "
                        f"'{self.category.name}'"
                    )

        for var_name, predicate in self.var_constraints:
            if predicate is None:
                continue
            val = bindings.get(var_name)
            if val is None:
                continue
            try:
                if not predicate(val):
                    return (
                        f"variable '{var_name}' = {val!r} failed its constraint"
                    )
            except Exception as e:
                return f"variable '{var_name}' constraint check raised: {e}"

        return "matched! (this axiom should have fired)"


# ---------------------------------------------------------------------------
# Internal sentinel to tell "matched and returned X" from "did not match"
# ---------------------------------------------------------------------------

class _MatchResult:
    """Wraps a successful axiom result so None can be a valid return value."""
    __slots__ = ('value',)
    def __init__(self, v): self.value = v

_MATCHED = _MatchResult  # used as: (_MATCHED, result) tuple


# ---------------------------------------------------------------------------
# MultiResult — list of all values produced when multiple axioms fire
# ---------------------------------------------------------------------------

class MultiResult(list):
    """
    Returned by an op call when more than one axiom matches the same inputs.

    Behaves exactly like a plain list of the matched values.
    Use ``first(result)`` in .nn code, or index directly (``result[0]``),
    to extract a single value when you only want the first match.

    Example::

        op score: None
        axiom fast: [for all x], x score x = x * 10
        axiom slow: [for all x], x score x = x + 1

        r = 3 score 3          # → MultiResult([30, 4])
        r[0]                   # → 30
        r[1]                   # → 4
        first(3 score 3)       # → 30
    """

    def __repr__(self) -> str:
        inner = ', '.join(repr(v) for v in self)
        return f"MultiResult([{inner}])"

    def first(self):
        """Return the first matched value, or None if empty."""
        return self[0] if self else None


def _nn_first(result: Any) -> Any:
    """
    Return the first value from a MultiResult, or the value itself if it is
    already a single result.  Used as the ``first(...)`` built-in in .nn files.
    """
    if isinstance(result, MultiResult):
        return result[0] if result else None
    return result


# ---------------------------------------------------------------------------
# _NNOp — runtime operator object (supports A |op| B infix syntax)
# ---------------------------------------------------------------------------

class _NNOp:
    """
    Wraps an operation name and delegates calls to the AxiomEngine.
    Supports three styles:
      - Infix:    A |op| B   (via __ror__ / __or__)
      - Function: op(A, B)   (via __call__)
      - One-arg:  op(A)      (via __call__)

    By default uses ``call_smart`` so that multiple matching axioms produce a
    ``MultiResult`` list.  Wrap with ``first(...)`` for single-value extraction.
    """

    def __init__(self, name: str, engine: 'AxiomEngine'):
        self.name = name
        self._engine = engine
        self._left = None
        self._has_left = False

    def __ror__(self, left):
        obj = _NNOp(self.name, self._engine)
        obj._left = left
        obj._has_left = True
        return obj

    def __or__(self, right):
        if not self._has_left:
            raise NewnError(
                f"Op '{self.name}' used with | but no left-hand value was provided"
            )
        return self._engine.call_smart(self.name, self._left, right)

    def __call__(self, *args):
        return self._engine.call_smart(self.name, *args)

    def all(self, *args) -> List[Tuple[str, Any]]:
        """
        Call this op with *args* and return **all** matching results as a list
        of ``(axiom_name, value)`` pairs — one entry per matching axiom.

        Use this when multiple axioms intentionally cover the same inputs and
        you want every possible output::

            myop.all(8, 9)
            # → [('new', PropValue('8', 9)), ('funew', PropValue('9', 8))]
        """
        return self._engine.call_all(self.name, *args)

    def __repr__(self):
        return f"Op({self.name!r})"


# ---------------------------------------------------------------------------
# AxiomEngine — central registry
# ---------------------------------------------------------------------------

class AxiomEngine:
    """
    Holds all registered props, categories, ops, and axioms for a .nn session.
    """

    def __init__(self):
        self._props: Set[str] = set()
        self._prop_factories: Dict[str, PropFactory] = {}
        self._categories: Dict[str, Category] = {}
        self._ops: Dict[str, _NNOp] = {}
        self._axioms: Dict[str, List[Axiom]] = {}
        self._pending: Dict[str, dict] = {}
        self._pending_ucats: Dict[str, dict] = {}
        self._pending_templates: Dict[str, dict] = {}
        # Category predicates built from parse_pattern for structural membership
        self._cat_preds: Dict[str, Any] = {}
        self._active_axioms: Dict[str, int] = {}   # axiom_name → recursion depth
        self._trace: bool = False
        # Bind registry: (prop_name, inner_value) → display value
        self._bindings: Dict[Tuple, Any] = {}
        # Category → prop_name: tracks which prop a category wraps (for bind)
        self._cat_props: Dict[str, str] = {}
        # Base namespace cache — rebuilt when new props/cats/ops are added
        self._base_ns_dirty: bool = True
        self._base_ns: Dict[str, Any] = {}
        # Python-backed ops: op_name → callable (bypass axiom dispatch)
        self._python_ops: Dict[str, Any] = {}
        # Last .nn source stored for export_python reconstruction
        self._last_nn_source: str = ''
        # Import bind registry: external_val → Newn PropValue
        # Direction: external world → Newn  (reverse of _bindings)
        self._import_bindings: Dict[Any, Any] = {}
        # Template axioms for family ops like 'usex' (x is a variable).
        # Each entry: {'prefix': str, 'suffix': str, 'var': str, 'axioms': List[Axiom]}
        # When call('use5', ...) is invoked, the template prefix='use'/suffix=''/var='x'
        # matches and x=5 is pre-bound before pattern matching.
        self._template_axioms: List[dict] = []
        # Tracks all non-UnresolvedExpr values produced by each op.
        # Used by UnresolvedCategory.pred to check resolved membership (T002).
        # Values are stored in a set when hashable, or a list otherwise.
        self._op_call_results: Dict[str, Any] = {}  # op_name → set or list

    def reset(self) -> None:
        """Clear all registered state. Called at the start of nn_exec for isolation."""
        self._props.clear()
        self._prop_factories.clear()
        self._categories.clear()
        self._ops.clear()
        self._axioms.clear()
        self._pending.clear()
        self._pending_ucats.clear()
        self._pending_templates.clear()
        self._cat_preds.clear()
        self._active_axioms.clear()
        self._bindings.clear()
        self._cat_props.clear()
        self._python_ops.clear()
        self._import_bindings.clear()
        self._template_axioms.clear()
        self._op_call_results.clear()
        self._last_nn_source = ''
        self._trace = False
        self._base_ns_dirty = True
        self._base_ns = {}

    # --- Bind registry ---

    # --- Export bind (Newn → external display/export) ---

    def bind_value(self, prop_name: str, inner_val: Any, display_val: Any) -> None:
        """Register an export binding: PropValue(prop_name, inner_val) prints/exports as display_val."""
        self._bindings[(prop_name, inner_val)] = display_val

    def lookup_bind(self, prop_name: str, inner_val: Any) -> Optional[Any]:
        """Return the export display value for (prop_name, inner_val), or None if unbound."""
        return self._bindings.get((prop_name, inner_val))

    # --- Import bind (external → Newn) ---

    def import_bind(self, external_val: Any, newn_val: Any) -> None:
        """
        Register an import binding: when *external_val* arrives from outside
        (e.g. from Prolog, Z3, or another language), Newn treats it as *newn_val*.

        Example::
            bind sev: 23 == [fib(8)]
            # translate_in(23)  →  fib(8)
        """
        self._import_bindings[external_val] = newn_val

    def lookup_import_bind(self, external_val: Any) -> Optional[Any]:
        """Return the Newn value for *external_val*, or None if no import bind registered."""
        return self._import_bindings.get(external_val)

    def register_category_prop(self, cat_name: str, prop_name: str) -> None:
        """Record that category cat_name wraps values of prop prop_name."""
        self._cat_props[cat_name] = prop_name

    def get_category_prop(self, cat_name: str) -> Optional[str]:
        """Return the prop name associated with cat_name, or None."""
        return self._cat_props.get(cat_name)

    # --- Props ---

    def make_prop(self, name: str) -> PropFactory:
        factory = PropFactory(name)
        self._props.add(name)
        self._prop_factories[name] = factory
        self._base_ns_dirty = True
        return factory

    def auto_prop(self, name: str) -> PropFactory:
        """
        Return the PropFactory for *name*, creating and registering it on the fly
        if it does not yet exist.

        Used by prop-family axioms: when the axiom fires for e.g. p7, auto_prop('p7')
        is called in the RHS so that p7 becomes a real registered prop even though
        it was never explicitly declared.
        """
        if name not in self._prop_factories:
            self.make_prop(name)
        return self._prop_factories[name]

    def prop_names(self) -> Set[str]:
        return set(self._props)

    # --- Categories ---

    def register_category(self, name: str, predicate: Callable) -> Category:
        cat = Category(name, predicate)
        self._categories[name] = cat
        self._base_ns_dirty = True
        return cat

    def get_category(self, name: str) -> Optional[Category]:
        return self._categories.get(name)

    def category_names(self) -> Set[str]:
        return set(self._categories.keys())

    def store_cat_pred(self, key: str, pred) -> None:
        """Store a compiled category predicate (from parse_pattern) under *key*."""
        self._cat_preds[key] = pred

    def get_cat_pred(self, key: str):
        """Retrieve a compiled category predicate stored under *key*."""
        if key not in self._cat_preds:
            raise NewnError(f"No category predicate found for key {key!r}")
        return self._cat_preds[key]

    def store_pending_ucat(self, key: str, data: dict) -> None:
        """Store an UnresolvedCategory definition keyed by a UUID, to be registered at exec time."""
        self._pending_ucats[key] = data

    def register_ucat_by_key(self, key: str) -> 'UnresolvedCategory':
        """
        Retrieve a pending UnresolvedCategory by key, register it, and return it.
        Called from the transformed Python code that the preprocessor emits.
        """
        if key not in self._pending_ucats:
            raise NewnError(f"No pending unresolved category found for key {key!r}")
        data = self._pending_ucats.pop(key)
        # Pass the engine reference so the category can check resolved membership
        cat = UnresolvedCategory(**data, engine=self)
        self._categories[cat.name] = cat
        self._base_ns_dirty = True
        return cat

    # --- Ops ---

    def register_op(self, name: str) -> _NNOp:
        op = _NNOp(name, self)
        self._ops[name] = op
        self._axioms.setdefault(name, [])
        self._base_ns_dirty = True
        return op

    def register_python_backed_op(self, name: str, fn) -> _NNOp:
        """
        Register a Python callable as a Newn op.  Calls to this op bypass
        axiom dispatch entirely and go straight to *fn*.

        Usage from .nn::
            from_python: math.sqrt as sqrt_op
            result = sqrt_op(9)   # → 3.0
        """
        if name not in self._ops:
            op = _NNOp(name, self)
            self._ops[name] = op
            self._axioms.setdefault(name, [])
            self._base_ns_dirty = True
        self._python_ops[name] = fn
        return self._ops[name]

    def op_names(self) -> Set[str]:
        """Return all known op names, including template op name templates."""
        names = set(self._ops.keys())
        for entry in self._template_axioms:
            # Show the template name (e.g. 'usex') so introspection tools can list it
            names.add(entry['tmpl'])
        return names

    # --- Axioms (direct) ---

    def register_axiom(
        self,
        name: str,
        op_name: str,
        variables: List[str],
        category: Optional[str],
        left_pat: Optional[Pattern],
        right_pat: Optional[Pattern],
        rhs_code: str,
        raw_var_constraints: Optional[List[Tuple[str, Optional[str]]]] = None,
        source_line: str = '',
        nn_file: str = '<inline>',
        nn_lineno: int = 0,
        severity: str = 'UNKNOWN',
    ) -> None:
        cat_obj: Optional[Category] = None
        if category is not None:
            cat_obj = self._categories.get(category)
            if cat_obj is None:
                raise NewnError(
                    f"Axiom '{name}': category '{category}' is not defined."
                )

        if op_name not in self._ops:
            raise NewnError(
                f"Axiom '{name}': op '{op_name}' is not defined. "
                f"Use 'op {op_name}: None' first."
            )

        def _unwrapped_by_prop_pat(pat: Optional[Pattern], var_name: str) -> bool:
            if pat is None:
                return False
            if isinstance(pat, (PropPat, PropFamilyPat)):
                if isinstance(pat.inner, VarPat) and pat.inner.name == var_name:
                    return True
                return _unwrapped_by_prop_pat(pat.inner, var_name)
            return False

        unwrapped_vars: Set[str] = {
            var_name
            for var_name, _ in (raw_var_constraints or [])
            if _unwrapped_by_prop_pat(left_pat, var_name)
            or _unwrapped_by_prop_pat(right_pat, var_name)
        }

        var_constraints: List[Tuple[str, Optional[Callable]]] = []
        for var_name, constraint_name in (raw_var_constraints or []):
            if constraint_name is None or var_name in unwrapped_vars:
                var_constraints.append((var_name, None))
            elif constraint_name in self._categories:
                cat = self._categories[constraint_name]
                var_constraints.append((var_name, cat.contains))
            elif constraint_name in self._props:
                cn = constraint_name
                var_constraints.append(
                    (var_name, lambda val, _cn=cn: isinstance(val, PropValue) and val.prop_name == _cn)
                )
            else:
                raise NewnError(
                    f"Axiom '{name}': constraint '{constraint_name}' on '{var_name}' "
                    f"is not a known prop or category."
                )

        axiom = Axiom(
            name, op_name, variables, cat_obj,
            left_pat, right_pat, rhs_code, self,
            var_constraints=var_constraints,
            source_line=source_line,
            nn_file=nn_file,
            nn_lineno=nn_lineno,
            severity=severity,
        )
        self._axioms[op_name].append(axiom)

        # Ground (no-variable) axiom: evaluate the RHS immediately and record
        # the result so backtracking / literal search can find it without needing
        # the user to call the op first.
        if not variables:
            try:
                ns = self._build_rhs_namespace({})
                ground_result = eval(axiom.rhs_code, {'__builtins__': __builtins__}, ns)
                self._record_op_result(op_name, ground_result)
            except Exception:
                pass

    def get_all_axiom_info(self) -> List[dict]:
        """
        Return metadata for every axiom (regular and template) registered in
        this engine.  Includes severity, source line, and file location.
        """
        result: List[dict] = []
        for op_name, axiom_list in self._axioms.items():
            for ax in axiom_list:
                result.append({
                    'name':        ax.name,
                    'op_name':     ax.op_name,
                    'source_line': ax.source_line.strip(),
                    'severity':    getattr(ax, 'severity', 'UNKNOWN'),
                    'nn_file':     ax.nn_file,
                    'nn_lineno':   ax.nn_lineno,
                    'variables':   list(ax.variables),
                    'is_template': False,
                })
        for entry in self._template_axioms:
            for ax in entry.get('axioms', []):
                result.append({
                    'name':        ax.name,
                    'op_name':     entry.get('tmpl', ax.op_name),
                    'source_line': ax.source_line.strip(),
                    'severity':    getattr(ax, 'severity', 'UNKNOWN'),
                    'nn_file':     ax.nn_file,
                    'nn_lineno':   ax.nn_lineno,
                    'variables':   list(ax.variables),
                    'is_template': True,
                })
        return result

    # --- Axioms (via pending registry — used by preprocessor) ---

    def store_pending_axiom(self, key: str, data: dict) -> None:
        self._pending[key] = data

    def register_axiom_by_key(self, key: str) -> None:
        if key not in self._pending:
            raise NewnError(f"No pending axiom found for key {key!r}")
        data = self._pending.pop(key)
        self.register_axiom(**data)

    # --- Template axioms (family ops like 'usex' where x is a variable) ---

    def store_pending_template_axiom(self, key: str, data: dict) -> None:
        """Store a template axiom for later registration (used by preprocessor)."""
        self._pending_templates[key] = data

    def register_template_axiom_by_key(self, key: str) -> None:
        """
        Register a template axiom from the pending registry.

        Template axioms handle ops whose names contain a variable, e.g. 'usex'
        where 'x' is declared in 'for all x'.  When call('use5', ...) is invoked,
        the engine extracts x=5 from the op name and pre-binds it before matching.

        data keys: prefix, suffix, var_name, name, op_name_template, variables,
                   category, left_pat, right_pat, rhs_code, raw_var_constraints,
                   source_line, nn_file, nn_lineno
        """
        if key not in self._pending_templates:
            raise NewnError(f"No pending template axiom found for key {key!r}")
        data = self._pending_templates.pop(key)

        prefix         = data['prefix']
        suffix         = data['suffix']
        var_name       = data['var_name']
        name           = data['name']
        op_tmpl        = data['op_name_template']
        variables      = data['variables']
        category_name  = data.get('category')
        left_pat       = data['left_pat']
        right_pat      = data['right_pat']
        rhs_code       = data['rhs_code']
        raw_vc         = data.get('raw_var_constraints') or []
        source_line    = data.get('source_line', '')
        nn_file        = data.get('nn_file', '<inline>')
        nn_lineno      = data.get('nn_lineno', 0)
        severity       = data.get('severity', 'UNKNOWN')

        cat_obj: Optional[Category] = None
        if category_name is not None:
            cat_obj = self._categories.get(category_name)
            if cat_obj is None:
                raise NewnError(
                    f"Template axiom '{name}': category '{category_name}' is not defined."
                )

        # Same as in register_axiom_by_key: if a variable is directly inside a
        # PropPat or PropFamilyPat, the pattern already enforces the prop type,
        # so the var_constraint for that variable should be None (not re-checked).
        def _unwrapped_tmpl(pat: Optional[Pattern], var_name: str) -> bool:
            if pat is None:
                return False
            if isinstance(pat, (PropPat, PropFamilyPat)):
                if isinstance(pat.inner, VarPat) and pat.inner.name == var_name:
                    return True
                return _unwrapped_tmpl(pat.inner, var_name)
            return False

        unwrapped_tmpl: Set[str] = {
            vn
            for vn, _ in raw_vc
            if _unwrapped_tmpl(left_pat, vn) or _unwrapped_tmpl(right_pat, vn)
        }

        var_constraints: List[Tuple[str, Optional[Callable]]] = []
        for vn, cn in raw_vc:
            if cn is None or vn in unwrapped_tmpl:
                var_constraints.append((vn, None))
            elif cn in self._categories:
                cat = self._categories[cn]
                var_constraints.append((vn, cat.contains))
            elif cn in self._props:
                _cn = cn
                var_constraints.append(
                    (vn, lambda val, _c=_cn: isinstance(val, PropValue) and val.prop_name == _c)
                )
            else:
                raise NewnError(
                    f"Template axiom '{name}': constraint '{cn}' on '{vn}' "
                    f"is not a known prop or category."
                )

        axiom = Axiom(
            name, op_tmpl, variables, cat_obj,
            left_pat, right_pat, rhs_code, self,
            var_constraints=var_constraints,
            source_line=source_line,
            nn_file=nn_file,
            nn_lineno=nn_lineno,
            severity=severity,
        )

        # Find or create the template entry
        for entry in self._template_axioms:
            if entry['prefix'] == prefix and entry['suffix'] == suffix and entry['var'] == var_name:
                entry['axioms'].append(axiom)
                return
        self._template_axioms.append({
            'prefix':  prefix,
            'suffix':  suffix,
            'var':     var_name,
            'tmpl':    op_tmpl,
            'axioms':  [axiom],
        })

    @staticmethod
    def _match_op_template(prefix: str, suffix: str, op_name: str):
        """
        Check whether op_name matches prefix + VAR + suffix.
        Returns the extracted variable value (int / float / str) or None on no match.
        """
        if not op_name.startswith(prefix):
            return None
        rest = op_name[len(prefix):]
        if suffix:
            if not rest.endswith(suffix):
                return None
            var_str = rest[: -len(suffix)]
        else:
            var_str = rest
        if not var_str:
            return None
        try:
            return int(var_str)
        except ValueError:
            pass
        try:
            return float(var_str)
        except ValueError:
            pass
        return var_str  # string op suffix (e.g. 'use_dog' with prefix='use_' → 'dog')

    # --- RHS eval namespace ---

    def _build_rhs_namespace(self, bindings: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build the namespace used when eval()-ing an axiom's RHS.
        Uses a cached base namespace (rebuilt only when new defs are added).

        Always includes _nn_auto_prop = self.auto_prop so that prop-family RHS
        expressions like  _nn_auto_prop('p' + str(n))(x)  work correctly.
        """
        if self._base_ns_dirty:
            ns: Dict[str, Any] = {}
            for cat_name, cat_obj in self._categories.items():
                ns[cat_name] = cat_obj
            for prop_name, factory in self._prop_factories.items():
                ns[prop_name] = factory
            for op_name, op_obj in self._ops.items():
                ns[op_name] = op_obj
            ns['_nn_auto_prop'] = self.auto_prop
            ns['_nn_engine']    = self          # needed for 5(5) → _nn_engine.auto_prop('5')(5)
            self._base_ns = ns
            self._base_ns_dirty = False
        result = dict(self._base_ns)
        result.update(bindings)
        return result

    # --- Op result recording (for resolved category membership) ---

    def _record_op_result(self, op_name: str, value: Any) -> None:
        """
        Record *value* as a result produced by *op_name*.
        Only concrete (non-UnresolvedExpr) values are recorded.
        Used by UnresolvedCategory.pred for resolved membership testing.
        """
        if isinstance(value, UnresolvedExpr):
            return  # symbolic / unresolved — not a concrete result
        bucket = self._op_call_results.get(op_name)
        if bucket is None:
            # Try set first; fall back to list for unhashable values
            try:
                s: Any = {value}
                self._op_call_results[op_name] = s
            except TypeError:
                self._op_call_results[op_name] = [value]
        else:
            if isinstance(bucket, set):
                try:
                    bucket.add(value)
                except TypeError:
                    # value is unhashable — promote to list
                    lst = list(bucket)
                    lst.append(value)
                    self._op_call_results[op_name] = lst
            else:
                if value not in bucket:
                    bucket.append(value)

    # --- Axiom source-line look-up ---

    def get_axiom_source(self, axiom_name: str) -> Optional[str]:
        """Return the stripped source line for the axiom named *axiom_name*.

        Searches both regular axiom lists and template-axiom entries.
        Returns ``None`` when no matching axiom is found.
        """
        for axiom_list in self._axioms.values():
            for ax in axiom_list:
                if ax.name == axiom_name:
                    return ax.source_line.strip() if ax.source_line else None
        for entry in self._template_axioms:
            for ax in entry['axioms']:
                if ax.name == axiom_name:
                    return ax.source_line.strip() if ax.source_line else None
        return None

    # --- Backtracking query ---

    def backtrack_pattern(
        self,
        var_names: List[str],
        matcher: 'Callable[[Any], bool]',
        binder: 'Callable[[Any], dict]',
        op_filter: Optional[str] = None,
        prop_name_must_vary: bool = False,
        max_probe_depth: int = 2,
    ) -> 'BacktrackResult':
        """
        Probe all registered ops with sample inputs and collect results that
        match *matcher*.  For each matching result, *binder* extracts variable
        bindings.  Returns a :class:`BacktrackResult`.

        Called from the transformed code produced by the backtracking syntax::

            newvar = {[for all x, for all y], x(y)}

        Parameters
        ----------
        var_names:
            Names of the quantified variables (informational, used in repr).
        matcher:
            ``matcher(value) → bool`` — True when the value fits the pattern.
        binder:
            ``binder(value) → dict`` — extract variable bindings from a matched value.
        op_filter:
            If given, only probe this specific op.  Otherwise probe all ops.
        prop_name_must_vary:
            When True (set automatically when the query's prop position is a
            free variable, e.g. ``{[for all x, for all y], x(y)}``), an axiom
            is only included if its probe results show **more than one distinct
            outer prop name**.  This excludes axioms whose RHS always produces
            the same fixed prop (e.g. ``double(x)``), which do not match a
            "variable prop" query.
        """
        # Build a probe grid of typical Newn values ──────────────────────────
        probe_ints = list(range(8))        # 0..7
        prop_names = list(self._props)[:6]  # up to 6 known props

        # Depth-1: plain ints + PropValue(prop, int)
        probe_values: List[Any] = list(probe_ints)
        for pname in prop_names:
            for v in probe_ints[:4]:
                probe_values.append(PropValue(pname, v))

        # Depth-2: PropValue(prop, PropValue(prop2, int))  — e.g. outer(inner(0))
        for pname in prop_names[:4]:
            for pname2 in prop_names[:4]:
                for v in probe_ints[:2]:
                    probe_values.append(PropValue(pname, PropValue(pname2, v)))

        # Depth-3+: extend probe grid for queries that require deeper nesting.
        # Each extra depth uses a shrinking subset of props/values to avoid
        # combinatorial explosion while still covering the essential cases.
        if max_probe_depth >= 3:
            # Collect a small sample of depth-(d-1) values to wrap
            _prev_layer: List[Any] = [
                pv for pv in probe_values
                if isinstance(pv, PropValue)
                and isinstance(pv.value, PropValue)
                and not isinstance(pv.value.value, PropValue)
            ][:6]
            for _d in range(3, max_probe_depth + 1):
                _n_props = max(1, 5 - _d)   # 2 props at d=3, 1 at d=4+
                _n_vals  = max(1, 5 - _d)   # 2 values at d=3, 1 at d=4+
                _cur_layer: List[Any] = []
                for _pn in prop_names[:_n_props]:
                    for _inner in _prev_layer[:_n_vals]:
                        _pv = PropValue(_pn, _inner)
                        probe_values.append(_pv)
                        _cur_layer.append(_pv)
                _prev_layer = _cur_layer
                if not _prev_layer:
                    break

        ops_to_probe = (
            [op_filter] if op_filter and op_filter in self._ops
            else list(self._ops.keys())
        )

        axiom_mode = bool(var_names)

        # Dedup keys differ by mode:
        #   axiom-mode  → one entry per unique axiom (key = source name)
        #   value-mode  → one entry per unique filled-LHS call (key = lhs_text)
        seen: set = set()
        items: List[Tuple[dict, Any, str, str]] = []

        # Per-axiom set of distinct outer prop names seen across ALL matching
        # probe results (tracked BEFORE dedup so the full variance picture is
        # captured even for axioms whose first match was already deduplicated).
        axiom_prop_names_seen: Dict[str, Set] = {}

        def _lhs_text(source: str, op_name: str, probe_args: tuple) -> str:
            """Compute the LHS display text for one match."""
            if axiom_mode or not probe_args:
                # Axiom-mode OR pre-recorded (no probe args): show the axiom's
                # own LHS with its original variable names, extracted from the
                # stored source line.
                ax_src = self.get_axiom_source(source)
                if ax_src:
                    return _extract_lhs_from_source(ax_src)
                return source  # fall back to axiom name
            # Value-mode with concrete probe args: fill in the actual values.
            if len(probe_args) == 2:
                return f"{_nn_repr(probe_args[0])} {op_name} {_nn_repr(probe_args[1])}"
            if len(probe_args) == 1:
                return f"{_nn_repr(probe_args[0])} {op_name}"
            return f"{op_name}({', '.join(_nn_repr(a) for a in probe_args)})"

        def _add(value: Any, source: str, op_name: str, probe_args: tuple) -> None:
            if isinstance(value, UnresolvedExpr):
                return
            try:
                matcher_ok = matcher(value)
            except Exception:
                return
            if not matcher_ok:
                return
            # Track outer prop name variance BEFORE dedup so we see all probe
            # results for every axiom (not just the first match that passed dedup).
            if isinstance(value, PropValue):
                axiom_prop_names_seen.setdefault(source, set()).add(value.prop_name)
            lhs = _lhs_text(source, op_name, probe_args)
            dedup_key = source if axiom_mode else lhs
            if dedup_key in seen:
                return
            seen.add(dedup_key)
            try:
                bdgs = binder(value)
            except Exception:
                bdgs = {}
            items.append((bdgs, value, source, lhs))

        def _add_many(pairs: List[Tuple[str, Any]], op_name: str, probe_args: tuple) -> None:
            for src, val in pairs:
                if isinstance(val, list):
                    for sub in val:
                        _add(sub, src, op_name, probe_args)
                else:
                    _add(val, src, op_name, probe_args)

        # ── Pre-recorded results (from explicit calls already made) ──────────
        # Only used in value-mode (no declared variables).  In axiom-mode the
        # user is querying structural axiom patterns; specific computed values
        # from prior calls are not relevant and can skew the variance filter.
        if not axiom_mode:
            for op_name in ops_to_probe:
                bucket = self._op_call_results.get(op_name)
                if bucket:
                    for v in bucket:
                        _add(v, f'(recorded from {op_name})', op_name, ())

        # ── Probe single-argument calls ──────────────────────────────────────
        for op_name in ops_to_probe:
            for a in probe_values:
                try:
                    pairs = self._call_all_inner(op_name, (a,))
                    _add_many(pairs, op_name, (a,))
                except Exception:
                    pass

        # ── Probe two-argument calls ─────────────────────────────────────────
        for op_name in ops_to_probe:
            for a in probe_values:
                for b in probe_values:
                    try:
                        pairs = self._call_all_inner(op_name, (a, b))
                        _add_many(pairs, op_name, (a, b))
                    except Exception:
                        pass

        # ── Prop-variance filter ──────────────────────────────────────────────
        # When the query's prop position is a free variable (e.g. x in x(y)),
        # only keep axioms whose matching probe results showed MORE THAN ONE
        # distinct outer prop name.  Axioms that always produce the same fixed
        # prop (e.g. double(x)) are not a match for a "variable prop" query.
        # Exception: when fewer than 2 distinct prop names are registered in the
        # engine, every variable-prop axiom will appear to produce the same outer
        # prop (because there's only one to probe with).  In that case we cannot
        # detect variance, so we skip the filter and include all axioms.
        if prop_name_must_vary and axiom_mode and len(prop_names) >= 2:
            items = [
                (b, v, s, l) for b, v, s, l in items
                if len(axiom_prop_names_seen.get(s, set())) > 1
            ]

        return BacktrackResult(items, engine=self, axiom_mode=axiom_mode)

    def backtrack_structural(
        self,
        var_names: List[str],
        pattern_text: str,
    ) -> 'BacktrackResult':
        """
        **Structural (bidirectional) backtracking.**

        Scans every registered axiom and tries to structurally match
        *pattern_text* (with *var_names* as wildcards) against the axiom's
        **LHS** *or* **RHS** (taken from the original ``.nn`` source line).

        *   If *pattern_text* matches the **LHS** of an axiom, the result for
            that axiom is the axiom's **RHS** expression — with the axiom's
            own variable names replaced by the corresponding pattern variable
            names.
        *   If *pattern_text* matches the **RHS** of an axiom, the result is
            the axiom's **LHS** expression, similarly substituted.

        This is purely textual/structural: no axioms are *evaluated*.  It
        works for any pattern the probe-based approach cannot reach, including
        patterns with ops inside, multi-layer prop calls, dot-access notation,
        and UnresolvedExpr-style expressions on the RHS.

        Returns a :class:`BacktrackResult` whose ``.values()`` list contains
        the opposite-side expression strings and whose ``repr`` shows
        ``matched_side  →  opposite_side`` for each hit.

        Example::

            axiom add1: [for all x], x my_add 1 = x + 1

            # Structural: match the LHS, get the RHS
            hits = eng.backtrack_structural(['x'], 'x my_add 1')
            hits.values()  # → ['x + 1']

            # Structural: match the RHS, get the LHS
            hits2 = eng.backtrack_structural(['x'], 'x + 1')
            hits2.values()  # → ['x my_add 1']
        """
        pat_vars = set(var_names)
        items: List[Tuple[dict, Any, str, str]] = []
        seen: set = set()

        def _try_axiom(axiom: 'Axiom') -> None:
            src = getattr(axiom, 'source_line', '')
            if not src:
                return
            lhs_txt = _extract_lhs_from_source(src)
            rhs_txt = _extract_rhs_from_source(src)
            ax_vars  = set(getattr(axiom, 'variables', None) or [])
            name     = axiom.name
            if name in seen:
                return

            # ── Try: pattern ≡ axiom LHS → return axiom RHS ──────────────
            if lhs_txt and rhs_txt:
                m = _st_structural_match(pattern_text, pat_vars, lhs_txt, ax_vars)
                if m is not None:
                    other   = _st_apply_mapping(rhs_txt, m)
                    display = f"{lhs_txt}  →  {other}"
                    seen.add(name)
                    items.append(({}, other, name, display))
                    return   # LHS matched; no need to also try RHS

            # ── Try: pattern ≡ axiom RHS → return axiom LHS ──────────────
            if rhs_txt and lhs_txt and name not in seen:
                m = _st_structural_match(pattern_text, pat_vars, rhs_txt, ax_vars)
                if m is not None:
                    other   = _st_apply_mapping(lhs_txt, m)
                    display = f"{rhs_txt}  →  {other}"
                    seen.add(name)
                    items.append(({}, other, name, display))

        # ── Walk all regular axioms ───────────────────────────────────────
        for axioms in self._axioms.values():
            for axiom in axioms:
                _try_axiom(axiom)

        # ── Walk all template axioms ──────────────────────────────────────
        for entry in self._template_axioms:
            for axiom in entry.get('axioms', []):
                _try_axiom(axiom)

        return BacktrackResult(items, engine=self, axiom_mode=True)

    # --- Calling operations ---

    def _call_all_inner(self, op_name: str, args: tuple) -> List[Tuple[str, Any]]:
        """
        Try every axiom for *op_name* against *args* and return ALL that match.

        Returns a list of ``(axiom_name, value)`` pairs — one entry per matching
        axiom.  Does NOT raise on no-match; returns an empty list instead.
        Python-backed ops always return exactly one entry labelled ``'(python)'``.
        """
        if op_name in self._python_ops:
            try:
                v = self._python_ops[op_name](*args)
                return [('(python)', v)]
            except Exception:
                return []

        results: List[Tuple[str, Any]] = []
        axioms = self._axioms.get(op_name)

        # ── Step 1: regular (concrete) axioms ──────────────────────────────
        if axioms is not None:
            for axiom in axioms:
                depth = self._active_axioms.get(axiom.name, 0)
                if depth >= 1:
                    if axiom.matches_args(args, lenient=True):
                        if self._trace:
                            print(f"  [trace] {op_name}: recursion guard on axiom "
                                  f"'{axiom.name}' → stays symbolic")
                        results.append((axiom.name, UnresolvedExpr(op_name, args)))
                    continue

                self._active_axioms[axiom.name] = depth + 1
                try:
                    result = axiom.try_apply(args)
                finally:
                    self._active_axioms[axiom.name] = depth

                if result is not None:
                    sentinel, value = result
                    if self._trace:
                        print(f"  [trace] {op_name}({', '.join(repr(a) for a in args)}) "
                              f"→ axiom '{axiom.name}' fired → {value!r}")
                    self._record_op_result(op_name, value)
                    results.append((axiom.name, value))

        # ── Step 2: template (family op) axioms ────────────────────────────
        for entry in self._template_axioms:
            var_val = self._match_op_template(entry['prefix'], entry['suffix'], op_name)
            if var_val is None:
                continue
            initial_bindings = {entry['var']: var_val}
            for axiom in entry['axioms']:
                depth = self._active_axioms.get(axiom.name, 0)
                if depth >= 1:
                    if axiom._match_patterns(args, initial_bindings, lenient=True) is not None:
                        if self._trace:
                            print(f"  [trace] {op_name}: recursion guard (template "
                                  f"axiom '{axiom.name}') → stays symbolic")
                        results.append((axiom.name, UnresolvedExpr(op_name, args)))
                    continue

                self._active_axioms[axiom.name] = depth + 1
                try:
                    result = axiom.try_apply(args, initial_bindings)
                finally:
                    self._active_axioms[axiom.name] = depth

                if result is not None:
                    sentinel, value = result
                    if self._trace:
                        print(f"  [trace] {op_name}({', '.join(repr(a) for a in args)}) "
                              f"→ template axiom '{axiom.name}' "
                              f"(var {entry['var']}={var_val!r}) fired → {value!r}")
                    self._record_op_result(op_name, value)
                    results.append((axiom.name, value))

        return results

    def call_all(self, op_name: str, *args) -> List[Tuple[str, Any]]:
        """
        Call *op_name* with *args* and return **all** matching results as a
        list of ``(axiom_name, value)`` pairs — one entry per matching axiom.

        Returns an empty list when the op is not defined or no axiom matches.
        Never raises.  Use this when you need every result from every axiom
        that could fire for the given arguments.

        Example::

            engine.call_all('myop', 8, 9)
            # → [('ax1', PropValue('a', 8)), ('ax2', PropValue('b', 9))]
        """
        if op_name not in self._ops and op_name not in self._python_ops:
            return []
        return self._call_all_inner(op_name, args)

    def call_smart(self, op_name: str, *args) -> Any:
        """
        Default op-call semantics used by the .nn runtime.

        * **0 matches** — raises (same error as ``call``).
        * **1 match**   — returns the single value directly (fully transparent,
          behaves identically to the old ``call``).
        * **2+ matches** — returns a ``MultiResult`` list of every matched
          value, one per axiom that fired, in declaration order.

        Use ``first(result)`` in .nn code to extract the first value from a
        ``MultiResult``.  Use ``op.all(a, b)`` when you also need axiom names.
        """
        if op_name in self._python_ops:
            return self._python_ops[op_name](*args)

        all_results = self._call_all_inner(op_name, args)

        if not all_results:
            # Delegate to call() so we get the same descriptive error message
            return self.call(op_name, *args)

        values = [v for _, v in all_results]
        if len(values) == 1:
            return values[0]          # transparent single-value path
        return MultiResult(values)    # multi-value path

    def call(self, op_name: str, *args) -> Any:
        """
        Call *op_name* with *args* using **first-match-wins** semantics.

        Returns the value from the first axiom that matches.
        To get ALL matching results (when multiple axioms can fire), use
        ``call_all`` or the op's ``.all(...)`` method.
        """
        # Python-backed ops skip axiom dispatch entirely
        if op_name in self._python_ops:
            return self._python_ops[op_name](*args)

        all_results = self._call_all_inner(op_name, args)

        if all_results:
            return all_results[0][1]

        # ── Nothing matched — build a useful error ──────────────────────────
        axioms = self._axioms.get(op_name)

        # ── Step 3: nothing matched — build a useful error ─────────────────
        if axioms is None and not self._template_axioms:
            import difflib
            known_ops = sorted(self._ops.keys())
            close_ops = difflib.get_close_matches(op_name, known_ops, n=3, cutoff=0.6)
            suggestion = (
                f"\n  Did you mean: {', '.join(repr(c) for c in close_ops)}?"
                if close_ops else
                f"\n  Defined ops: {known_ops if known_ops else '(none yet)'}"
            )
            raise AxiomNotFoundError(
                f"\n  [Newn] Op '{op_name}' is not defined.\n"
                f"  Fix: write  op {op_name}: None  before using it, or add it to a\n"
                f"  'for all' clause in an axiom to auto-register it as an op.{suggestion}"
            )

        arg_strs = ', '.join(repr(a) for a in args)
        axiom_hints = []
        all_axioms = list(axioms or [])
        for entry in self._template_axioms:
            if self._match_op_template(entry['prefix'], entry['suffix'], op_name) is not None:
                all_axioms.extend(entry['axioms'])
        for ax in all_axioms:
            why = ax._why_not(args)
            axiom_hints.append(f"    • '{ax.name}': {why}")
        hints_str = '\n'.join(axiom_hints) if axiom_hints else '    (none defined)'

        suggestions: list = []
        check_axioms = axioms or []
        if len(args) == 2:
            swapped = (args[1], args[0])
            matching = [ax for ax in check_axioms if ax.matches_args(swapped)]
            if matching:
                sw_strs = ', '.join(repr(a) for a in swapped)
                ax_names = ', '.join(f"'{ax.name}'" for ax in matching)
                suggestions.append(
                    f"  Suggestion: try the arguments in the other order — "
                    f"'{sw_strs}' matches axiom(s) {ax_names}.\n"
                    f"  In Newn: write  {repr(args[1])} {op_name} {repr(args[0])}"
                )
            single_arg = [ax for ax in check_axioms
                          if (1 if ax.left_pat is not None else 0) +
                             (1 if ax.right_pat is not None else 0) == 1
                          and ax.matches_args((args[0],))]
            if single_arg:
                ax_names = ', '.join(f"'{ax.name}'" for ax in single_arg)
                suggestions.append(
                    f"  Suggestion: axiom(s) {ax_names} only expect one argument — "
                    f"try  {op_name}({repr(args[0])})  (drop the second argument)"
                )
        if len(args) == 1:
            binary_axs = [ax for ax in check_axioms
                          if (1 if ax.left_pat is not None else 0) +
                             (1 if ax.right_pat is not None else 0) == 2]
            if binary_axs:
                ax_names = ', '.join(f"'{ax.name}'" for ax in binary_axs)
                suggestions.append(
                    f"  Suggestion: axiom(s) {ax_names} expect two arguments — "
                    f"try  {repr(args[0])} {op_name} <second_value>"
                )

        suggestion_str = ('\n' + '\n'.join(suggestions)) if suggestions else ''
        raise NewnError(
            f"\n  [Newn] No axiom matches '{op_name}({arg_strs})'.\n"
            f"  Axioms tried for '{op_name}':\n{hints_str}"
            f"{suggestion_str}"
        )

    # --- Tracing ---

    def trace_on(self) -> None:
        """Enable axiom firing trace. Every op call will print which axiom matched."""
        self._trace = True
        print("[.nn] Axiom trace enabled")

    def trace_off(self) -> None:
        """Disable axiom firing trace."""
        self._trace = False
        print("[.nn] Axiom trace disabled")

    # --- Inspection / Debug ---

    def which_axioms(self, op_name: str) -> str:
        """
        Return a human-readable summary of all axioms registered for an op.
        Useful for checking what rules apply to a given operation.
        """
        if op_name not in self._axioms:
            return f"Op '{op_name}' is not defined."
        axioms = self._axioms[op_name]
        if not axioms:
            return f"Op '{op_name}' is defined but has no axioms yet."
        lines = [f"Op '{op_name}' has {len(axioms)} axiom(s):"]
        for i, ax in enumerate(axioms, 1):
            loc = f"{ax.nn_file}:{ax.nn_lineno}" if ax.nn_lineno else ax.nn_file
            lines.append(f"  {i}. [{loc}] {ax.source_line.strip() or ax.signature()}")
            lines.append(f"       RHS: {ax.rhs_code}")
        return '\n'.join(lines)

    def explain(self, op_name: str, *args) -> str:
        """
        Show exactly which axiom would fire (or why none do) for a given call.
        Does NOT actually execute the op — purely for inspection.
        """
        if op_name not in self._axioms:
            return f"Op '{op_name}' is not defined."
        axioms = self._axioms[op_name]
        arg_strs = ', '.join(repr(a) for a in args)
        lines = [f"Explaining: {op_name}({arg_strs})"]
        for i, ax in enumerate(axioms, 1):
            why = ax._why_not(args)
            if why == "matched! (this axiom should have fired)":
                lines.append(f"  {i}. '{ax.name}' → WOULD FIRE ✓")
            else:
                lines.append(f"  {i}. '{ax.name}' → did not match ({why})")
        return '\n'.join(lines)

    def coverage(self, op_name: str) -> str:
        """
        Show a coverage summary for an op: what input types/shapes are handled.
        Highlights potential gaps (e.g. one axiom handles plain args, nothing handles PropValue args).
        """
        if op_name not in self._axioms:
            return f"Op '{op_name}' is not defined."
        axioms = self._axioms[op_name]
        if not axioms:
            return f"Op '{op_name}': no axioms defined — every call will fail."

        lines = [f"Coverage for op '{op_name}':"]
        has_plain_left = False
        has_prop_left = False
        has_plain_right = False
        has_prop_right = False
        has_one_arg = False
        has_category = False

        for ax in axioms:
            loc = f"{ax.nn_file}:{ax.nn_lineno}" if ax.nn_lineno else ax.nn_file
            left_desc = _pat_desc(ax.left_pat, ax.var_constraints, ax._plain_vars, 'left')
            right_desc = _pat_desc(ax.right_pat, ax.var_constraints, ax._plain_vars, 'right')
            if ax.category:
                has_category = True
                lines.append(f"  • '{ax.name}' [{loc}]: ALL vars in '{ax.category.name}' | {left_desc} op {right_desc}")
            else:
                lines.append(f"  • '{ax.name}' [{loc}]: {left_desc} op {right_desc}")
            if ax.left_pat is None and ax.right_pat is not None:
                has_one_arg = True
            if ax.left_pat is not None:
                if isinstance(ax.left_pat, PropPat):
                    has_prop_left = True
                else:
                    has_plain_left = True
            if ax.right_pat is not None:
                if isinstance(ax.right_pat, PropPat):
                    has_prop_right = True
                else:
                    has_plain_right = True

        lines.append("")
        lines.append("  Potential gaps:")
        gaps = []
        if has_plain_left and not has_prop_left and not has_category:
            gaps.append("    ! Left arg: axioms only cover plain values — PropValue left arg will fail")
        if has_prop_left and not has_plain_left and not has_category:
            gaps.append("    ! Left arg: axioms only cover PropValues — plain left arg will fail")
        if has_plain_right and not has_prop_right and not has_category:
            gaps.append("    ! Right arg: axioms only cover plain values — PropValue right arg will fail")
        if has_prop_right and not has_plain_right and not has_category:
            gaps.append("    ! Right arg: axioms only cover PropValues — plain right arg will fail")
        if not gaps:
            gaps.append("    None detected (static analysis only — test with real values to be sure)")
        lines.extend(gaps)
        return '\n'.join(lines)

    # --- Membership check helper ---

    def prop_contains(self, prop_name: str, value: Any) -> bool:
        return isinstance(value, PropValue) and value.prop_name == prop_name


def _pat_desc(pat, var_constraints, plain_vars, side: str) -> str:
    """Return a short description of a pattern for coverage display."""
    if pat is None:
        return f"({side}: none)"
    if isinstance(pat, PropPat):
        return f"({side}: {pat.prop_name}(...))"
    if isinstance(pat, VarPat):
        name = pat.name
        if name in plain_vars:
            return f"({side}: plain var '{name}')"
        for vn, pred in var_constraints:
            if vn == name and pred is not None:
                return f"({side}: constrained var '{name}')"
        return f"({side}: var '{name}')"
    return f"({side}: {type(pat).__name__})"


# ---------------------------------------------------------------------------
# Global engine instance
# ---------------------------------------------------------------------------

_ENGINE = AxiomEngine()
