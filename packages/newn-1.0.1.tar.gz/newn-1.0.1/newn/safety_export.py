"""
newn.safety_export — Export helpers for SafetyNet.

Functions here are called from SafetyNet methods but can also be used
directly if you prefer the functional style.
"""
from __future__ import annotations

import json
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .safety import SafetyNet


_SEVERITY_ORDER = {
    'CRITICAL': 0,
    'HIGH':     1,
    'MEDIUM':   2,
    'LOW':      3,
    'INFO':     4,
    'UNKNOWN':  5,
}


def _sorted_rules(net: 'SafetyNet'):
    """Return all rules sorted by severity (most critical first)."""
    rules = net.get_rules()
    return sorted(
        rules,
        key=lambda r: _SEVERITY_ORDER.get(r.severity.upper(), 5),
    )


def as_json_rules(net: 'SafetyNet', path: Optional[str] = None) -> str:
    """
    Serialise all axiom rules to a JSON string, sorted by severity.

    If *path* is given the result is also written to that file.
    Returns the JSON string either way.

    Schema::
        [
          {
            "name":        "axiom_name",
            "op_name":     "add",
            "source_line": "axiom ... = ...",
            "severity":    "CRITICAL",
            "nn_file":     "rules.nn",
            "nn_lineno":   12,
            "variables":   ["x", "y"],
            "is_template": false
          },
          ...
        ]
    """
    rules = _sorted_rules(net)
    payload = [r.to_dict() for r in rules]
    text = json.dumps(payload, indent=2)
    if path is not None:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(text)
    return text


def as_system_prompt(net: 'SafetyNet') -> str:
    """
    Return a plain-English system prompt that tells an LLM to obey the
    axiom rules in this safety net.

    The prompt lists CRITICAL/HIGH rules first, then the rest, and
    instructs the model to verify its outputs against them before replying.
    """
    rules = _sorted_rules(net)
    if not rules:
        return (
            "You are operating under a symbolic safety net with no rules "
            "currently loaded.  Proceed with standard guidelines."
        )

    lines = [
        "You are operating under a Symbolic Safety Net.",
        "The following axiom rules MUST be respected in every response.",
        "Before finalising any answer, verify it does not violate these rules.",
        "",
        "=== AXIOM RULES (sorted by severity) ===",
    ]

    for r in rules:
        sev  = r.severity.upper()
        mark = '[!!!]' if sev == 'CRITICAL' else f'[{sev}]'
        lines.append(f"{mark}  axiom '{r.name}'  ({r.op_name})")
        lines.append(f"      Rule:   {r.source_line}")
        if r.nn_file and r.nn_file != '<inline>':
            lines.append(f"      Source: {r.nn_file} line {r.nn_lineno}")
        lines.append("")

    lines += [
        "=== END OF RULES ===",
        "",
        "If you cannot satisfy a CRITICAL or HIGH rule, say so explicitly",
        "rather than producing an answer that violates it.",
    ]

    return '\n'.join(lines)


def as_openai_function(net: 'SafetyNet') -> dict:
    """
    Return an OpenAI function-calling schema dict.

    The function is named ``check_axiom_rules`` and accepts an expression
    string plus an optional AI-generated answer.  Call it from your tool-use
    loop to validate outputs before returning them to the user.

    Usage::
        tools = [{'type': 'function', 'function': net.as_openai_function()}]
        response = client.chat.completions.create(
            model='gpt-4o', messages=[...], tools=tools
        )

    When the model calls the function, evaluate it with::
        import json
        args   = json.loads(tool_call.function.arguments)
        result = net.check(args['expression']).report(
            ai_output=args.get('ai_output')
        )
        # Feed result back to the model as a tool message.
    """
    rules        = net.get_rules()
    rule_summary = '; '.join(
        f"{r.name}({r.severity}): {r.source_line}"
        for r in _sorted_rules(net)
    ) or 'none'

    return {
        'name':        'check_axiom_rules',
        'description': (
            'Check whether an expression and optional AI-generated answer '
            'comply with the Newn symbolic axiom rules in the safety net. '
            f'Active rules: {rule_summary}.'
        ),
        'parameters': {
            'type':       'object',
            'properties': {
                'expression': {
                    'type':        'string',
                    'description': (
                        'A Newn expression to evaluate against the axioms, '
                        'e.g. "absent(5) add present(3)".'
                    ),
                },
                'ai_output': {
                    'type':        'string',
                    'description': (
                        'Optional: the answer the AI intends to give.  '
                        'If provided, the function checks whether it agrees '
                        'with what the axioms derive.'
                    ),
                },
            },
            'required': ['expression'],
        },
    }
