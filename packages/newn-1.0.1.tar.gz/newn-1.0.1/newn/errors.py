class NewnError(Exception):
    """Base error for all Newn runtime and evaluation problems."""
    pass

class NewnSyntaxError(NewnError):
    """Raised when a .nn file or nn_exec string has a syntax or structural error."""
    pass

class AxiomNotFoundError(NewnError):
    """Raised when an op is called that has not been declared."""
    pass

class CategoryError(NewnError):
    """Raised for category-definition problems."""
    pass

class PatternError(NewnError):
    """Raised when a pattern expression cannot be parsed."""
    pass

# Backward-compatible aliases (old names still work)
NewNumberError = NewnError
NNSyntaxError  = NewnSyntaxError
