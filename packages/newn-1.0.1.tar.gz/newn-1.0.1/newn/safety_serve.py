"""
newn.safety_serve — Minimal HTTP server for SafetyNet.

Uses only the Python standard library (http.server + json).
No extra dependencies required.

Endpoints
---------
GET  /healthz              → {"status": "ok", "rules": <count>}
GET  /rules                → JSON list of all axiom rules
POST /check                → body: {"expression": "...", "ai_output": "..."}
                             response: CheckResult.report() dict
"""
from __future__ import annotations

import json
import threading
from http.server    import BaseHTTPRequestHandler, HTTPServer
from typing         import TYPE_CHECKING

if TYPE_CHECKING:
    from .safety import SafetyNet


def _make_handler(net: 'SafetyNet'):
    """Return a request-handler class bound to *net*."""

    class _Handler(BaseHTTPRequestHandler):
        _net = net

        def log_message(self, fmt, *args):
            pass

        def _send_json(self, data: dict | list, status: int = 200):
            body = json.dumps(data, indent=2).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _send_error_json(self, message: str, status: int = 400):
            self._send_json({'error': message}, status=status)

        def _read_body(self) -> bytes:
            length = int(self.headers.get('Content-Length', 0))
            return self.rfile.read(length) if length else b''

        def do_GET(self):
            path = self.path.split('?')[0]

            if path in ('/healthz', '/health'):
                rules = self._net.get_rules()
                self._send_json({'status': 'ok', 'rules': len(rules)})

            elif path == '/rules':
                rules = self._net.get_rules()
                self._send_json([r.to_dict() for r in rules])

            else:
                self._send_error_json(f'Unknown path: {path!r}', status=404)

        def do_POST(self):
            path = self.path.split('?')[0]

            if path == '/check':
                raw = self._read_body()
                try:
                    payload = json.loads(raw) if raw else {}
                except json.JSONDecodeError as exc:
                    self._send_error_json(f'Invalid JSON body: {exc}')
                    return

                expression = payload.get('expression')
                if not expression:
                    self._send_error_json('Missing required field: "expression"')
                    return

                ai_output = payload.get('ai_output')
                result    = self._net.check(expression)
                self._send_json(result.report(ai_output=ai_output))

            else:
                self._send_error_json(f'Unknown path: {path!r}', status=404)

    return _Handler


def serve(
    net: 'SafetyNet',
    host: str = 'localhost',
    port: int = 8765,
    *,
    background: bool = False,
) -> HTTPServer:
    """
    Start the SafetyNet HTTP server.

    Parameters
    ----------
    net        : SafetyNet instance to serve.
    host       : Bind address (default 'localhost').
    port       : TCP port (default 8765).
    background : If True, run in a daemon thread and return immediately.
                 If False (default), block until Ctrl-C.

    Returns the HTTPServer instance so callers can shut it down
    programmatically via ``server.shutdown()``.

    Example::
        net = SafetyNet.from_file('rules.nn')
        net.serve(port=8765)            # blocking

        # or in a test / notebook:
        server = net.serve(port=8765, background=True)
        # ... do things ...
        server.shutdown()
    """
    handler = _make_handler(net)
    server  = HTTPServer((host, port), handler)

    if background:
        t = threading.Thread(target=server.serve_forever, daemon=True)
        t.start()
        print(f"[SafetyNet] Serving on http://{host}:{port} (background)")
    else:
        print(f"[SafetyNet] Serving on http://{host}:{port}  (Ctrl-C to stop)")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
            print("[SafetyNet] Server stopped.")

    return server
