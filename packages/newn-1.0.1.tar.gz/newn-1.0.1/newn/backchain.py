"""
Backward chaining and query inference for Newn.

Two strategies:
  1. Symbolic inversion  – parse the axiom's RHS as a Pattern and use BinPat
     algebraic matching to directly compute the input variable values.
     Works for axioms whose RHS is a simple expression (x+3, absent(x), -x, …).

  2. Domain search       – brute-force: try every value from a caller-supplied
     domain and collect any inputs that produce the target.

Both strategies return a list of Solution objects.
"""
from __future__ import annotations
from typing import Any, Dict, Iterable, List, Optional, Set

from .patterns import parse_pattern, match_pattern, evaluate_pattern, _try_eval_pat
from .errors import NewnError


# ---------------------------------------------------------------------------
# Solution — one answer from a query
# ---------------------------------------------------------------------------

class Solution:
    """
    A proven way to produce a target value via one axiom.

    Attributes:
        op_name   : the operation that was queried
        inputs    : the argument(s) that produce the target
        axiom_name: which axiom fired
        bindings  : the variable bindings that were found
        strategy  : 'symbolic' | 'domain'
    """

    __slots__ = ('op_name', 'inputs', 'axiom_name', 'bindings', 'strategy')

    def __init__(self, op_name, inputs, axiom_name, bindings=None, strategy='symbolic'):
        self.op_name    = op_name
        self.inputs     = tuple(inputs)
        self.axiom_name = axiom_name
        self.bindings   = bindings or {}
        self.strategy   = strategy

    def __repr__(self):
        args = ', '.join(repr(v) for v in self.inputs)
        return (
            f"Solution({self.op_name}({args}) → {self.target_repr()}"
            f"  via axiom '{self.axiom_name}' [{self.strategy}])"
        )

    def target_repr(self):
        try:
            from .core import _ENGINE
            result = _ENGINE.call(self.op_name, *self.inputs)
            return repr(result)
        except Exception:
            return '?'

    def explain(self) -> str:
        """Return a human-readable explanation of this solution."""
        lines = [
            f"  {self.op_name}({', '.join(repr(v) for v in self.inputs)})",
            f"  Matched axiom: '{self.axiom_name}'  [{self.strategy}]",
        ]
        if self.bindings:
            bstr = ', '.join(f"{k}={v!r}" for k, v in self.bindings.items())
            lines.append(f"  Variable bindings: {bstr}")
        return '\n'.join(lines)

    def __eq__(self, other):
        return (isinstance(other, Solution)
                and self.op_name    == other.op_name
                and self.inputs     == other.inputs
                and self.axiom_name == other.axiom_name)

    def __hash__(self):
        return hash((self.op_name, self.inputs, self.axiom_name))


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _rhs_as_pattern(rhs_code: str, variables: List[str], props: Set[str]):
    """
    Try to parse the axiom's rhs_code string as a Pattern AST.
    Returns None if the RHS is too complex (contains ops, Python calls, etc.).
    """
    if not rhs_code:
        return None
    try:
        return parse_pattern(rhs_code, set(variables), props)
    except Exception:
        return None


def _reconstruct_arg(pat, bindings: dict):
    """
    Given a pattern (left_pat or right_pat) and variable bindings,
    reconstruct the concrete argument value that was matched.
    Returns None if reconstruction fails.
    """
    if pat is None:
        return None
    try:
        return evaluate_pattern(pat, bindings)
    except Exception:
        return None


def _symbolic_backchain_axiom(axiom, target: Any, props: Set[str]) -> List[Solution]:
    """
    Attempt to find variable bindings such that axiom's RHS evaluates to target,
    using algebraic pattern inversion (BinPat / NegPat / PropPat matching).

    Returns a list of Solution objects (usually 0 or 1 element for linear RHS).
    """
    rhs_pat = _rhs_as_pattern(axiom.rhs_code, axiom.variables, props)
    if rhs_pat is None:
        return []

    # Match target against the RHS pattern — this is algebraic inversion
    bindings = match_pattern(rhs_pat, target, {}, set())
    if bindings is None:
        return []

    # Check that all variables needed by the LHS patterns are bound
    needed_vars = set(axiom.variables)
    if not needed_vars.issubset(set(bindings.keys())):
        return []

    # Reconstruct the concrete input arguments from the LHS patterns
    if axiom.left_pat is not None and axiom.right_pat is not None:
        left_val  = _reconstruct_arg(axiom.left_pat,  bindings)
        right_val = _reconstruct_arg(axiom.right_pat, bindings)
        if left_val is None or right_val is None:
            return []
        inputs = (left_val, right_val)
    elif axiom.left_pat is not None:
        left_val = _reconstruct_arg(axiom.left_pat, bindings)
        if left_val is None:
            return []
        inputs = (left_val,)
    elif axiom.right_pat is not None:
        right_val = _reconstruct_arg(axiom.right_pat, bindings)
        if right_val is None:
            return []
        inputs = (right_val,)
    else:
        inputs = ()

    return [Solution(axiom.op_name, inputs, axiom.name, bindings, 'symbolic')]


def _domain_backchain_axiom(
    axiom,
    target: Any,
    domain: Iterable,
    max_results: int,
) -> List[Solution]:
    """
    Brute-force search: try all combinations of domain values as inputs
    and collect those where the axiom fires and produces target.
    """
    from .core import _ENGINE, PropValue, UnresolvedExpr

    results: List[Solution] = []
    expected = (
        (1 if axiom.left_pat is not None else 0) +
        (1 if axiom.right_pat is not None else 0)
    )

    domain_list = list(domain)

    def _try(args):
        try:
            result = _ENGINE.call(axiom.op_name, *args)
            if result == target:
                return True
        except Exception:
            pass
        return False

    if expected == 0:
        if _try(()):
            results.append(Solution(axiom.op_name, (), axiom.name, {}, 'domain'))
    elif expected == 1:
        for v in domain_list:
            args = (v,)
            if _try(args):
                results.append(Solution(axiom.op_name, args, axiom.name, {}, 'domain'))
                if len(results) >= max_results:
                    return results
    elif expected == 2:
        for lv in domain_list:
            for rv in domain_list:
                args = (lv, rv)
                if _try(args):
                    results.append(Solution(axiom.op_name, args, axiom.name, {}, 'domain'))
                    if len(results) >= max_results:
                        return results

    return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def backchain(
    engine,
    op_name: str,
    target: Any,
    max_results: int = 20,
) -> List[Solution]:
    """
    Symbolically find all inputs to *op_name* that produce *target*,
    without needing a domain.  Works for axioms whose RHS is a simple
    algebraic expression (e.g. x + 3, absent(x), x * 2, -x).

    For axioms with two free variables (e.g. x + y = target) there is no
    unique solution; those axioms are skipped unless a domain is provided
    via query().

    Returns a list of Solution objects, deduped by (inputs, axiom_name).
    """
    axioms = engine._axioms.get(op_name)
    if axioms is None:
        raise NewnError(f"[Newn] Op '{op_name}' is not defined.")

    props = engine.prop_names()
    seen:  Set[Solution] = set()
    results: List[Solution] = []

    for axiom in axioms:
        for sol in _symbolic_backchain_axiom(axiom, target, props):
            if sol not in seen:
                seen.add(sol)
                results.append(sol)
                if len(results) >= max_results:
                    return results

    return results


def query(
    engine,
    op_name: str,
    target: Any,
    domain: Optional[Iterable] = None,
    max_results: int = 50,
) -> List[Solution]:
    """
    Find all inputs to *op_name* that produce *target*.

    First tries symbolic inversion for each axiom.  Then, if *domain*
    is provided, falls back to brute-force search for axioms that
    couldn't be solved symbolically.

    Args:
        op_name    : the operation to search
        target     : the desired output value
        domain     : iterable of values to search over (optional)
        max_results: maximum number of solutions to return

    Returns a list of Solution objects.

    Example::

        results = query(engine, 'add', 10, domain=range(0, 15))
        for sol in results:
            print(sol.inputs, '→', sol.explain())
    """
    axioms = engine._axioms.get(op_name)
    if axioms is None:
        raise NewnError(f"[Newn] Op '{op_name}' is not defined.")

    props = engine.prop_names()
    seen:  Set[Solution] = set()
    results: List[Solution] = []

    for axiom in axioms:
        # 1. Symbolic pass
        for sol in _symbolic_backchain_axiom(axiom, target, props):
            if sol not in seen:
                seen.add(sol)
                results.append(sol)
                if len(results) >= max_results:
                    return results

        # 2. Domain-search pass for any remaining capacity
        if domain is not None and len(results) < max_results:
            for sol in _domain_backchain_axiom(
                axiom, target, domain, max_results - len(results)
            ):
                if sol not in seen:
                    seen.add(sol)
                    results.append(sol)
                    if len(results) >= max_results:
                        return results

    return results


def prove(
    engine,
    op_name: str,
    *args,
) -> bool:
    """
    Check whether there *exists* an axiom that can fire for these arguments,
    i.e. whether the op call is provable (produces a non-UnresolvedExpr result).

    Returns True if the call resolves to a concrete value, False otherwise.
    """
    from .core import UnresolvedExpr
    try:
        result = engine.call(op_name, *args)
        return not isinstance(result, UnresolvedExpr)
    except Exception:
        return False
