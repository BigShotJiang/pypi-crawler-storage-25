"""
newn.safety — Symbolic Safety Net for Newn axiom systems.

A SafetyNet wraps a Newn engine loaded from a .nn file or inline code.
It lets you:
  - Derive what the axioms say an expression must evaluate to.
  - Query all axioms with their severity labels.
  - Export the axiom rules as JSON, an LLM system prompt, or an
    OpenAI function-calling schema.
  - Spin up a local HTTP endpoint so external tools can query the rules.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class RuleInfo:
    """Metadata for a single axiom rule."""
    name: str
    op_name: str
    source_line: str
    severity: str
    nn_file: str
    nn_lineno: int
    variables: List[str]
    is_template: bool = False

    def to_dict(self) -> dict:
        return {
            'name':        self.name,
            'op_name':     self.op_name,
            'source_line': self.source_line,
            'severity':    self.severity,
            'nn_file':     self.nn_file,
            'nn_lineno':   self.nn_lineno,
            'variables':   self.variables,
            'is_template': self.is_template,
        }


@dataclass
class CheckResult:
    """
    Result of calling SafetyNet.check(expression).

    Attributes:
        expression  -- the original expression string
        derived     -- what the Newn axioms compute for this expression
        error       -- if evaluation raised an exception, its message
        rules       -- all rules in the safety net (for reference)
    """
    expression: str
    derived: Any
    error: Optional[str]
    rules: List[RuleInfo] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        """True when the expression evaluated without error."""
        return self.error is None

    def agrees_with(self, ai_output: Any) -> bool:
        """Return True if ai_output matches the derived value."""
        return str(self.derived) == str(ai_output)

    def report(self, ai_output: Any = None) -> dict:
        """
        Return a plain dict summarising the check.
        Optionally compare the derived result against an AI's output.
        """
        d: dict = {
            'expression': self.expression,
            'derived':    repr(self.derived),
            'ok':         self.ok,
        }
        if self.error:
            d['error'] = self.error
        if ai_output is not None:
            d['ai_output'] = repr(ai_output)
            d['agrees']    = self.agrees_with(ai_output)
            if not d['agrees']:
                relevant = [
                    r.to_dict() for r in self.rules
                    if r.severity.upper() in ('CRITICAL', 'HIGH', 'ERROR')
                ]
                d['violated_rules'] = relevant
        return d


class SafetyNet:
    """
    A symbolic safety net built from a Newn axiom system.

    Create one with:
        net = SafetyNet.from_file('rules.nn')
        net = SafetyNet.from_code('''
            op add: None
            axiom add_absent: for all x, absent(x) add y = absent(x), severity: critical
        ''')

    Then use it to:
        result = net.derive("absent(5) add 3")      # → PropValue('absent', 5)
        report = net.check("absent(5) add 3")        # → CheckResult
        rules  = net.get_rules()                     # → List[RuleInfo]
        json_s = net.as_json_rules()                 # → JSON string
        prompt = net.as_system_prompt()              # → string for LLM
        fn     = net.as_openai_function()            # → dict for OpenAI API
        net.serve(port=8765)                         # → HTTP endpoint
    """

    def __init__(self, ns: dict, source_code: str = '', source_path: str = ''):
        self._ns          = dict(ns)
        self._source_code = source_code
        self._source_path = source_path
        engine            = ns.get('_nn_engine')
        self._engine      = engine
        # Snapshot rule metadata at creation time.  The global engine is a
        # singleton that gets reset on each nn_exec call; storing a snapshot
        # here means this SafetyNet instance remains self-consistent even
        # after other .nn files or SafetyNet instances are loaded later.
        self._rules_snapshot: List[dict] = (
            engine.get_all_axiom_info() if engine is not None else []
        )

    @classmethod
    def from_code(cls, code: str) -> 'SafetyNet':
        """
        Build a SafetyNet by executing inline .nn code.

        Example::
            net = SafetyNet.from_code('''
                op mul: None
                axiom zero_absent: for all x, absent(x) mul y = absent(x)
            ''')
        """
        from .preprocessor import nn_exec
        ns = nn_exec(code)
        return cls(ns, source_code=code)

    @classmethod
    def from_file(cls, path: str) -> 'SafetyNet':
        """
        Build a SafetyNet from a .nn file on disk.

        Example::
            net = SafetyNet.from_file('physics_rules.nn')
        """
        from .preprocessor import nn_exec_file
        with open(path, encoding='utf-8') as f:
            code = f.read()
        ns = nn_exec_file(path)
        return cls(ns, source_code=code, source_path=path)

    def get_rules(self) -> List[RuleInfo]:
        """
        Return all axioms registered in this safety net.

        The list is taken from an internal snapshot captured at creation time,
        so it remains stable even after other .nn programs are loaded.
        """
        return [RuleInfo(**info) for info in self._rules_snapshot]

    def derive(self, expression: str) -> Any:
        """
        Evaluate *expression* using the axioms and return the derived value.

        The expression is evaluated as a Python expression in the namespace
        produced by the .nn file, so you can reference any prop, op, or
        Python name that was defined there.

        Example::
            result = net.derive("absent(5) add present(3)")
        """
        try:
            return eval(expression, self._ns)
        except Exception as exc:
            return None

    def check(self, expression: str) -> CheckResult:
        """
        Derive what the axioms say *expression* evaluates to and return a
        CheckResult with the value and all rule metadata.

        Example::
            r = net.check("absent(5) add present(3)")
            print(r.derived)
            print(r.ok)
        """
        error: Optional[str] = None
        derived: Any = None
        try:
            derived = eval(expression, self._ns)
        except Exception as exc:
            error = str(exc)
        return CheckResult(
            expression=expression,
            derived=derived,
            error=error,
            rules=self.get_rules(),
        )

    def as_json_rules(self, path: Optional[str] = None) -> str:
        """
        Export all axioms as a JSON string.
        If *path* is given the JSON is also written to that file.

        Returns the JSON string.
        """
        from .safety_export import as_json_rules
        return as_json_rules(self, path=path)

    def as_system_prompt(self) -> str:
        """
        Return a plain-text system prompt that instructs an LLM to respect
        the axiom rules defined in this safety net.
        """
        from .safety_export import as_system_prompt
        return as_system_prompt(self)

    def as_openai_function(self) -> dict:
        """
        Return an OpenAI function-calling schema dict that an LLM can call to
        check whether its output agrees with the axioms.

        Wire it into your OpenAI call like::
            response = client.chat.completions.create(
                model='gpt-4o',
                messages=[...],
                tools=[{'type': 'function',
                        'function': net.as_openai_function()}],
            )
        """
        from .safety_export import as_openai_function
        return as_openai_function(self)

    def serve(
        self,
        host: str = 'localhost',
        port: int = 8765,
        *,
        background: bool = False,
    ) -> None:
        """
        Start a simple HTTP server that exposes the safety net over HTTP.

        POST /check       body: {"expression": "..."} → CheckResult JSON
        GET  /rules       → all rules as JSON
        GET  /healthz     → {"status": "ok"}

        If *background* is True the server runs in a daemon thread (returns
        immediately).  Otherwise it blocks until you press Ctrl-C.
        """
        from .safety_serve import serve as _serve
        return _serve(self, host=host, port=port, background=background)
