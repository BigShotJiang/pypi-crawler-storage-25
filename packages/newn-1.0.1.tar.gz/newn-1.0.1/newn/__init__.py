"""
Newn — define new mathematical systems through properties, categories, and axioms.
Language: .nn files
"""
from .core import (
    PropValue           as PropValue,
    PropFactory         as PropFactory,
    UnresolvedExpr      as UnresolvedExpr,
    Category            as Category,
    UnresolvedCategory  as UnresolvedCategory,
    BacktrackResult     as BacktrackResult,
    MultiResult         as MultiResult,
    AxiomEngine         as AxiomEngine,
    VisualDict          as VisualDict,
    _ENGINE             as _ENGINE,
)
from .preprocessor import (
    nn_exec        as nn_exec,
    nn_exec_file   as nn_exec_file,
    nn_transform   as nn_transform,
)
from .patterns import (
    DotAccessPat as DotAccessPat,
)
from .errors import (
    NewnError          as NewnError,
    NewnSyntaxError    as NewnSyntaxError,
    AxiomNotFoundError as AxiomNotFoundError,
    CategoryError      as CategoryError,
    PatternError       as PatternError,
    NewNumberError     as NewNumberError,
    NNSyntaxError      as NNSyntaxError,
)
from .backchain import (
    Solution   as Solution,
    backchain  as backchain,
    query      as query,
    prove      as prove,
)
from .export import (
    export_prolog  as export_prolog,
    export_z3      as export_z3,
    export_pddl    as export_pddl,
    export_python  as export_python,
)
from .safety import (
    SafetyNet   as SafetyNet,
    CheckResult as CheckResult,
    RuleInfo    as RuleInfo,
)

__version__ = "1.0.1"

__all__ = [
    "PropValue",
    "PropFactory",
    "UnresolvedExpr",
    "Category",
    "UnresolvedCategory",
    "BacktrackResult",
    "MultiResult",
    "AxiomEngine",
    "_ENGINE",
    "nn_exec",
    "nn_exec_file",
    "nn_transform",
    "NewnError",
    "NewnSyntaxError",
    "AxiomNotFoundError",
    "CategoryError",
    "PatternError",
    "NewNumberError",
    "NNSyntaxError",
    "Solution",
    "backchain",
    "query",
    "prove",
    "export_prolog",
    "export_z3",
    "export_pddl",
    "export_python",
    "SafetyNet",
    "CheckResult",
    "RuleInfo",
    "VisualDict",
    "__version__",
]
