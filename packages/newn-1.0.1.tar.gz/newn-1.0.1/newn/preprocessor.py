"""
.nn → Python preprocessor.

Declarations handled (single-line):
    prop name: None
    op name: None
    category name: for all x [in catname], predicate_expr
    axiom name: for all x [, y ...] [in catname], LHS_expr = RHS_expr
    axiom name: [for all x, for all propname(y)], LHS_expr = RHS_expr

Multi-file:
    include "path/to/file.nn"          ← inline another .nn file here

Iteration:
    loop var from A to B:              ← sugar for: for var in range(A, B+1):
    Python for/while/if pass through natively.

Debug (available in nn_exec namespace):
    trace_on()                         ← print every axiom that fires
    trace_off()                        ← stop tracing
    show(value)                        ← pretty-print a value with its type
    which_axioms("op")                 ← print all axioms for an op
    explain("op", arg1, arg2)          ← which axiom would fire for these args?
    coverage("op")                     ← static coverage analysis for an op
    why_not("op", arg1, arg2)          ← why did no axiom fire?
    fold(op, [a, b, c])               ← reduce: op(op(a,b),c)
    each(op, [a, b, c])               ← map: [op(a), op(b), op(c)]

Infix op call transform:
    A opname B  →  A |opname| B
"""
from __future__ import annotations
import ast
import builtins
import os
import re
import uuid
from typing import Dict, List, Optional, Set, Tuple

# Python builtin names that must never be mistaken for Newn props.
# Used to guard RHS auto-prop scanning so that idiomatic Python calls like
# str(x), int(y), len(z) in an axiom RHS are not auto-registered as props.
_PYTHON_BUILTINS: frozenset = frozenset(dir(builtins))

from .errors import NewnError, NewnSyntaxError, NNSyntaxError
from .patterns import parse_pattern


def _sanitize_var_name(name: str) -> str:
    """
    Map any user-specified variable name to a valid Python identifier.

    Examples
    --------
    'x'    → 'x'            (already valid — unchanged)
    '%'    → '_nv_c37_'     (% is ASCII 37)
    '*'    → '_nv_c42_'
    '5'    → '_nv_c53_'
    '**'   → '_nv_c42_c42_'
    """
    if re.match(r'^[A-Za-z_]\w*$', name):
        return name  # already a valid Python identifier
    safe = '_nv_'
    for ch in name:
        if ch.isalnum() or ch == '_':
            safe += ch
        else:
            safe += f'c{ord(ch)}_'
    return safe


def _replace_user_vars(
    expr: str,
    var_map: dict,
    known_ops: 'Optional[Set[str]]' = None,
) -> str:
    """
    Replace user variable names (which may be symbols like %, *, @) with their
    sanitized Python-identifier equivalents in *expr*.

    - Longer names are replaced first (avoids partial-match problems).
    - Regular Python identifiers: word-boundary replacement.
    - Pure-digit names: replaced only when not adjacent to other digits.
    - Symbols (%, *, @, **…): state-machine replacement that distinguishes
      "value position" from "operator position" so that e.g. `*` used as a
      variable in  `* op * = * * 2`  is replaced only where it is a *value*,
      not where it is the Python multiplication operator.

    Parameters
    ----------
    expr:
        The expression string to process.
    var_map:
        Mapping of user_name → safe_python_identifier.
    known_ops:
        Set of Newn op names.  When provided, identifiers that are Newn ops
        are treated as infix operators (state transitions accordingly).
    """
    _ops: Set[str] = known_ops or set()
    for user_name, safe_name in sorted(var_map.items(), key=lambda kv: -len(kv[0])):
        if user_name == safe_name:
            continue  # No mapping needed
        if re.match(r'^[A-Za-z_]\w*$', user_name):
            # Identifier-style: use word boundaries to avoid replacing substrings
            expr = re.sub(r'\b' + re.escape(user_name) + r'\b', safe_name, expr)
        elif re.match(r'^\d+$', user_name):
            # Pure numeric name: replace only when isolated (not part of a larger number)
            expr = re.sub(
                r'(?<!\d)' + re.escape(user_name) + r'(?!\d)(?!\.)',
                safe_name, expr,
            )
        else:
            # Symbol(s): use a state-machine token scanner so that the same
            # symbol doesn't get replaced when it acts as a Python operator.
            # Example: [for all *], * op * = * * 2
            #   LHS: * op * → _nv_ op _nv_          (both are vars)
            #   RHS: * * 2  → _nv_ * 2               (first var, second operator)
            expr = _replace_symbol_token(expr, user_name, safe_name, _ops)
    return expr


def _replace_symbol_token(
    expr: str,
    symbol: str,
    safe: str,
    known_ops: 'Set[str]',
) -> str:
    """
    Replace *symbol* with *safe* in *expr* only when *symbol* appears in
    "value position" (as an operand), not in "operator position" (between
    two operands).

    Uses a simple whitespace-tokeniser with a two-state machine:

        state='value'    — the next token should be a value/identifier
        state='operator' — the next token should be an operator

    Transitions
    -----------
    - Newn op name (in known_ops) or pure Python operator → transition to 'value'
    - Any identifier / numeric literal / closing bracket  → transition to 'operator'
    - Opening bracket / comma / colon                     → transition to 'value'
    """
    # Split on whitespace, preserving spacing tokens so we can reconstruct.
    parts = re.split(r'(\s+)', expr)
    state = 'value'
    result: List[str] = []

    for part in parts:
        if not part or not part.strip():
            result.append(part)
            continue

        if part == symbol:
            # Standalone symbol token — apply state machine
            if state == 'value':
                result.append(safe)
                state = 'operator'
            else:
                # Operator position — keep the symbol as-is
                result.append(part)
                state = 'value'
        elif symbol in part:
            # Symbol is embedded inside a larger token (e.g. "foo(%)" or "(%+1)")
            # It must be in a value context (inside parens, etc.), so always replace.
            result.append(part.replace(symbol, safe))
            # After a compound token that contains the symbol as a value,
            # the overall token is still an expression — treat as 'operator' state
            # if the token ends with ')' or an identifier, else keep current.
            if part.endswith(')') or re.match(r'.*\w$', part):
                state = 'operator'
            # else leave state unchanged
        else:
            result.append(part)
            # Update state based on the role of this token
            stem = part.rstrip('(')   # strip trailing '(' for call syntax
            if stem in known_ops:
                # Newn infix op acts as a binary operator
                state = 'value'
            elif re.match(r'^[+\-*/%@^&|<>=!~]+$', part) or part in (
                'and', 'or', 'not', 'in', 'is', 'if', 'else', 'lambda',
            ):
                state = 'value'
            elif part in ('(', '[', '{', ',', ';', ':'):
                state = 'value'
            elif part in (')', ']', '}'):
                state = 'operator'
            elif re.match(r'^[\w\d.]', part):
                state = 'operator'
            else:
                state = 'value'   # safe default

    return ''.join(result)


# Matches:  prop name: None
_PROP_RE = re.compile(r'^prop\s+(\w+)\s*:\s*None\s*(?:#.*)?$')

# Matches:  op name: None
_OP_RE = re.compile(r'^op\s+(\w+)\s*:\s*None\s*(?:#.*)?$')

# Matches:  category name: for all x [, y] [in cat], predicate
_CAT_RE = re.compile(
    r'^category\s+(\w+)\s*:\s*for all\s+([\w\s,]+?)\s*(?:in\s+(\w+))?\s*,\s*(.+)$'
)

# Matches:  category name: [for all absent(x), for all y], absent(x) add y
# (bracket / unresolved-expr syntax — defines a category over UnresolvedExpr shapes)
_CAT_BRACKET_RE = re.compile(
    r'^category\s+(\w+)\s*:\s*\[(.+?)\]\s*,\s*(.+)$'
)

# Matches:  axiom name: for all x [, y] [in cat], LHS = RHS   (classic syntax)
_AXIOM_RE = re.compile(
    r'^axiom\s+(\w+)\s*:\s*for all\s+([\w\s,]+?)\s*(?:in\s+(\w+))?\s*,\s*(.+)$'
)

# Matches:  axiom name: [for all x, for all absent(y)], LHS = RHS   (per-variable syntax)
_AXIOM_BRACKET_RE = re.compile(
    r'^axiom\s+(\w+)\s*:\s*\[(.+?)\]\s*,\s*(.+)$'
)

# Matches:  include "path/to/file.nn"  or  include path/to/file.nn
_INCLUDE_RE = re.compile(r'^include\s+["\']?([^"\'#\s]+)["\']?\s*(?:#.*)?$')

# Matches:  from_python: module.submod.func as op_name
#   e.g.    from_python: math.sqrt as sqrt_op
#           from_python: numpy.random.rand as rand_op
_FROM_PYTHON_RE = re.compile(
    r'^from_python\s*:\s*([\w.]+)\s+as\s+(\w+)\s*(?:#.*)?$'
)

# Matches:  name = {[for all x, for all y], pattern, probe}
# Explicit probe-based backtracking — must be checked FIRST so the suffix
# isn't swallowed into the pattern group by the default regex.
_BACKTRACK_PROBE_RE = re.compile(
    r'^(\s*)(\w+)\s*=\s*\{\s*(\[for\s+all\s+[^\]]*\])\s*,\s*(.+?)\s*,\s*probe\s*\}\s*(?:#.*)?$'
)

# Matches:  name = {[for all x, for all y], pattern, structural}
# Explicit structural keyword — same as default, but strips ', structural'
# cleanly so it doesn't land in the pattern group.
_BACKTRACK_STRUCTURAL_RE = re.compile(
    r'^(\s*)(\w+)\s*=\s*\{\s*(\[for\s+all\s+[^\]]*\])\s*,\s*(.+?)\s*,\s*structural\s*\}\s*(?:#.*)?$'
)

# Matches the DEFAULT backtracking syntax (structural):
#   name = {[for all x, for all y], pattern_expr}
# Structural is now the default — no suffix required.
# Checked BEFORE dict/set literal detection so the outer {} is not swallowed.
_BACKTRACK_RE = re.compile(
    r'^(\s*)(\w+)\s*=\s*\{\s*(\[for\s+all\s+[^\]]*\])\s*,\s*(.+?)\s*\}\s*(?:#.*)?$'
)

# Matches:  name = {LITERAL}  — literal-value backtracking search
#   e.g.   result = {9}   or   found = {3.14}   or   hits = {-2}
# Checked BEFORE _BACKTRACK_RE and dict-literal wrapping so { } is not confused.
_BACKTRACK_LITERAL_RE = re.compile(
    r'^(\s*)(\w+)\s*=\s*\{\s*(-?\d+(?:\.\d+)?)\s*\}\s*(?:#.*)?$'
)

# Matches:  loop var from A to B:
_LOOP_RE = re.compile(r'^loop\s+(\w+)\s+from\s+(.+?)\s+to\s+(.+?):\s*(?:#.*)?$')

_SEVERITY_RE = re.compile(r',\s*severity\s*:\s*(\S+)\s*$')


def _extract_severity(equation: str):
    """
    Strip ', severity: VALUE' from the end of an axiom equation string.
    Returns (cleaned_equation, severity_string).
    If no severity tag is present the severity defaults to 'UNKNOWN'.
    """
    m = _SEVERITY_RE.search(equation)
    if m:
        return equation[:m.start()].strip(), m.group(1)
    return equation, 'UNKNOWN'


_HEADER = (
    "from newn.core import _ENGINE as _nn_engine, PropValue as _PropValue,"
    " UnresolvedExpr as _nn_UnresolvedExpr, BacktrackResult as _nn_BacktrackResult,"
    " VisualDict as _nn_vdict\n"
)

# Matches:  in range(A, B)  anywhere on a line (handles integers and floats, incl. negatives)
_RANGE_SPEC_RE = re.compile(
    r'\bin\s+range\s*\(\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*\)'
)

# ---------------------------------------------------------------------------
# Bind statement regexes
# ---------------------------------------------------------------------------

# Form 1 — point bind:  bind name: prop(val) == [display]
#   e.g.  bind fib5: fib(5) == [21]
_BIND_POINT_RE = re.compile(
    r'^bind\s+\w+\s*:\s*(\w+)\((.+?)\)\s*==\s*\[(.+)\]\s*(?:#.*)?$'
)

# Form 2 — range bind:  bind name: for all x [step=S, start=A], prop(x) == [v1, v2, ...]
#   step and start are optional (default 1).
_BIND_RANGE_RE = re.compile(
    r'^bind\s+\w+\s*:\s*for\s+all\s+(\w+)(?:\s*\[([^\]]*)\])?\s*,\s*(\w+)\((\w+)\)\s*==\s*\[(.+)\]\s*(?:#.*)?$'
)

# Form 3 — category bind:  bind name: cat_name [step=S, start=A] == [v1, v2, ...]
#   Uses the prop registered with that category (via register_category_prop).
_BIND_CAT_RE = re.compile(
    r'^bind\s+\w+\s*:\s*(\w+)(?:\s*\[([^\]]*)\])?\s*==\s*\[(.+)\]\s*(?:#.*)?$'
)

# Form 4 — import point bind:  bind name: external_val == [newn_expr]
#   Direction: external → Newn.  LHS is any Python expression WITHOUT a direct
#   prop call (e.g. a number, string, or plain expression).
#   e.g.  bind sev: 23 == [fib(8)]
#   NOTE: processed BEFORE Form 1 so that the matching order is:
#     range-export → range-import → point-export → category → point-import
_BIND_IMPORT_POINT_RE = re.compile(
    r'^bind\s+\w+\s*:\s*(?!for\s+all\s)([^()\[\]#]+?)\s*==\s*\[(.+)\]\s*(?:#.*)?$'
)

# Form 5 — import range bind:  bind name: for all x [step=S, start=A], x == [newn1, newn2, ...]
#   Direction: external → Newn.  LHS after the comma is the plain variable (no prop wrapper).
#   e.g.  bind nums: for all x [step=1, start=1], x == [fib(1), fib(2), fib(3)]
_BIND_IMPORT_RANGE_RE = re.compile(
    r'^bind\s+\w+\s*:\s*for\s+all\s+(\w+)(?:\s*\[([^\]]*)\])?\s*,\s*(\w+)\s*==\s*\[(.+)\]\s*(?:#.*)?$'
)


def _parse_bind_params(params_str: Optional[str]) -> Tuple[str, str]:
    """
    Parse 'step=X, start=Y' (or any subset) from a bracket body.
    Returns (start_expr, step_expr) as strings suitable for code generation.
    Defaults: start='1', step='1'.
    """
    start_expr = '1'
    step_expr  = '1'
    if params_str:
        for part in params_str.split(','):
            part = part.strip()
            if '=' in part:
                key, val = part.split('=', 1)
                key = key.strip().lower()
                val = val.strip()
                if key == 'start':
                    start_expr = val
                elif key == 'step':
                    step_expr = val
    return start_expr, step_expr


def _process_range_specs(code_stripped: str, known: Dict) -> Tuple[str, List[str]]:
    """
    Replace every ``in range(A, B)`` occurrence in *code_stripped* with
    an auto-generated range-category name (e.g. ``_rng_0_10_``), and return
    extra Python lines that must be emitted *before* the axiom/category line
    to register those categories in the engine.

    The range is **inclusive on both ends**: A <= x <= B.
    Works for integers and floats; handles negative bounds.
    """
    extra: List[str] = []

    def _replace(m: re.Match) -> str:
        a_str = m.group(1)
        b_str = m.group(2)
        a_val = float(a_str) if '.' in a_str else int(a_str)
        b_val = float(b_str) if '.' in b_str else int(b_str)
        # Build a safe Python identifier for the auto-category
        safe_a = a_str.replace('-', 'neg').replace('.', 'p')
        safe_b = b_str.replace('-', 'neg').replace('.', 'p')
        cat_name = f"_rng_{safe_a}_{safe_b}_"
        if cat_name not in known.get('cats', set()):
            known.setdefault('cats', set()).add(cat_name)
            extra.append(
                f"_nn_engine.register_category({cat_name!r}, "
                f"lambda _v, _a={a_val!r}, _b={b_val!r}: "
                f"isinstance(_v, (int, float)) and _a <= _v <= _b)"
            )
        return f"in {cat_name}"

    modified = _RANGE_SPEC_RE.sub(_replace, code_stripped)
    return modified, extra


def _resolve_prop_checks(pred_expr: str, var: str, props: Set[str]) -> str:
    """
    Transform prop-function notation into proper boolean expressions inside
    a category predicate.

    Two transformations are applied in order:

    1. **Union / 'and'-as-OR**:
       If the *entire* predicate is ``prop1(var) and prop2(var) [and ...]``
       with every term being a known-prop check, rewrite it as a union::

           absent(x) and star(x)  →  (x in absent) or (x in star)

       Newn's convention: writing ``and`` between prop-type checks means
       "accepts *either* type", i.e. a union category.

    2. **Membership boolean**:
       Any remaining ``propname(var)`` expression (known prop) is replaced
       by the boolean membership form ``(var in propname)`` so that
       ``or`` / ``not`` / ``and`` all work correctly as Python booleans::

           absent(x) or x > 0  →  (x in absent) or x > 0
    """
    pred_expr = pred_expr.strip()

    # --- Phase 1: detect all-prop-and union pattern ---
    parts = re.split(r'\s+and\s+', pred_expr)
    _prop_check = re.compile(rf'^(\w+)\({re.escape(var)}\)$')
    prop_names_found = []
    all_pure_prop = True
    for p in parts:
        mm = _prop_check.match(p.strip())
        if mm and mm.group(1) in props:
            prop_names_found.append(mm.group(1))
        else:
            all_pure_prop = False
            break

    if all_pure_prop and len(prop_names_found) >= 2:
        # Rewrite as OR union
        return ' or '.join(f'({var} in {pn})' for pn in prop_names_found)

    # --- Phase 2: replace individual prop checks with boolean membership ---
    result = pred_expr
    for prop_name in sorted(props, key=len, reverse=True):
        result = re.sub(
            rf'\b{re.escape(prop_name)}\({re.escape(var)}\)',
            f'({var} in {prop_name})',
            result,
        )
    return result


def transform(
    nn_code: str,
    _known: Optional[Dict[str, Set[str]]] = None,
    _base_dir: str = '.',
    _file: str = '<inline>',
) -> str:
    """
    Transform .nn source code into executable Python.
    Also registers axioms in the global _ENGINE as a side effect.

    _known:    shared dict of known props/cats/ops (used by recursive includes).
    _base_dir: directory of the current file (for resolving relative includes).
    _file:     filename label used in error messages.
    """
    from .core import _ENGINE
    lines = nn_code.split('\n')

    # Top-level call: emit the header and create a fresh known dict.
    is_top = _known is None
    known: Dict[str, Set[str]] = _known if _known is not None else {
        'props':        set(),
        'cats':         set(),
        'ops':          set(),
        'template_ops': [],   # list of (prefix, suffix) for template axiom ops
    }

    out_lines: List[str] = []
    if is_top:
        out_lines.append(_HEADER.rstrip())

    for lineno, raw_line in enumerate(lines, start=1):
        line = raw_line.rstrip()
        stripped = line.lstrip()

        if not stripped or stripped.startswith('#'):
            out_lines.append(line)
            continue

        code_part, comment = _split_comment(line)
        code_stripped = code_part.strip()

        # --- range spec pre-processing: replace 'in range(A, B)' everywhere ---
        # This runs before any regex matching so all syntax forms benefit.
        if 'range(' in code_stripped:
            code_stripped_ranged, range_extras = _process_range_specs(code_stripped, known)
            indent = _indent(line)
            for extra_line in range_extras:
                out_lines.append(f"{indent}{extra_line}")
            code_stripped = code_stripped_ranged

        # --- include ---
        m = _INCLUDE_RE.match(code_stripped)
        if m:
            path = m.group(1).strip()
            if not os.path.isabs(path):
                path = os.path.join(_base_dir, path)
            try:
                with open(path, 'r') as f:
                    included_src = f.read()
            except FileNotFoundError:
                raise NewnSyntaxError(
                    f"{_file}:{lineno}: include error — file not found: {path!r}"
                )
            except OSError as e:
                raise NewnSyntaxError(
                    f"{_file}:{lineno}: include error — could not read {path!r}: {e}"
                )
            included_dir = os.path.dirname(os.path.abspath(path))
            included_label = os.path.basename(path)
            indent = _indent(line)
            out_lines.append(f"{indent}# --- begin include: {included_label} ---")
            included_py = transform(
                included_src,
                _known=known,
                _base_dir=included_dir,
                _file=included_label,
            )
            out_lines.append(included_py)
            out_lines.append(f"{indent}# --- end include: {included_label} ---")
            continue

        # --- loop var from A to B: ---
        m = _LOOP_RE.match(code_stripped)
        if m:
            var   = m.group(1)
            start = m.group(2).strip()
            end   = m.group(3).strip()
            indent = _indent(line)
            out_lines.append(
                f"{indent}for {var} in range(int({start}), int({end}) + 1):{comment}"
            )
            continue

        # --- from_python: module.func as op_name ---
        m = _FROM_PYTHON_RE.match(code_stripped)
        if m:
            fn_path  = m.group(1)   # e.g. "math.sqrt"
            op_name  = m.group(2)   # e.g. "sqrt_op"
            parts    = fn_path.split('.')
            top_mod  = parts[0]
            uid      = uuid.uuid4().hex[:8]
            alias    = f"_nn_m_{uid}"
            fn_expr  = alias + ('.' + '.'.join(parts[1:]) if len(parts) > 1 else '')
            indent   = _indent(line)
            out_lines.append(f"{indent}import {top_mod} as {alias}{comment}")
            out_lines.append(
                f"{indent}{op_name} = _nn_engine.register_python_backed_op"
                f"({op_name!r}, {fn_expr})"
            )
            known['ops'].add(op_name)
            continue

        # --- prop ---
        m = _PROP_RE.match(code_stripped)
        if m:
            name = m.group(1)
            known['props'].add(name)
            indent = _indent(line)
            out_lines.append(f"{indent}{name} = _nn_engine.make_prop({name!r}){comment}")
            continue

        # --- op ---
        m = _OP_RE.match(code_stripped)
        if m:
            name = m.group(1)
            known['ops'].add(name)
            indent = _indent(line)
            out_lines.append(f"{indent}{name} = _nn_engine.register_op({name!r}){comment}")
            continue

        # --- category (bracket / unresolved-expr syntax) ---
        # Must be checked BEFORE _CAT_RE so that [for all ...] forms are caught first.
        m = _CAT_BRACKET_RE.match(code_stripped)
        if m:
            cat_name        = m.group(1)
            bracket_content = m.group(2).strip()
            expr            = m.group(3).strip()

            # Parse the per-variable quantifiers
            try:
                raw_var_constraints = _parse_bracket_quantifiers(
                    bracket_content, cat_name, known_props=known['props']
                )
            except NNSyntaxError:
                raise
            except Exception as e:
                raise NewnSyntaxError(
                    f"{_file}:{lineno}: category '{cat_name}': bad quantifiers — {e}"
                ) from e

            # ── Symbol-variable sanitization ────────────────────────────────
            # Variable names may be arbitrary symbols (%, *, @, 5, …).
            # Build a mapping from user names → valid Python identifiers and
            # apply it to the expression text so all downstream parsing is safe.
            _vnmap_bc = {
                vc[0]: _sanitize_var_name(vc[0])
                for vc in raw_var_constraints
                if _sanitize_var_name(vc[0]) != vc[0]
            }
            if _vnmap_bc:
                expr = _replace_user_vars(expr, _vnmap_bc)
                raw_var_constraints = [
                    (_sanitize_var_name(vc[0]), vc[1], vc[2] if len(vc) > 2 else None)
                    for vc in raw_var_constraints
                ]
            var_set = {vc[0] for vc in raw_var_constraints}
            indent = _indent(line)

            # ── Auto-register props found in the expression ─────────────────
            # e.g. 'absent(x) add y' → auto-register 'absent' if not declared.
            # Must happen before parse_pattern so the parser sees the new props.
            new_props_bc = _scan_auto_props(
                expr, var_set, known['props'], known_ops=known['ops']
            )
            for ap_name in sorted(new_props_bc):
                out_lines.append(
                    f"{indent}{ap_name} = _nn_engine.make_prop({ap_name!r})"
                    f"  # auto-inferred prop"
                )
                known['props'].add(ap_name)

            # Find the op that separates the two argument shapes (e.g. 'add' in 'absent(x) add y')
            op_found = _find_op_in_lhs(expr, known['ops'])

            if op_found is None:
                # Try auto-detecting the op from infix position before falling back
                # to predicate.  This handles structural categories like:
                #   category unresolved: [for all x, for all y], absent(x) add y
                # where 'add' hasn't been declared yet at parse time.
                op_auto_bc = _find_op_in_lhs_auto(expr, var_set, known['props'])
                if op_auto_bc is not None:
                    if op_auto_bc not in known['ops']:
                        out_lines.append(
                            f"{indent}{op_auto_bc} = _nn_engine.register_op({op_auto_bc!r})"
                            f"  # auto-inferred op"
                        )
                        known['ops'].add(op_auto_bc)
                    op_found = op_auto_bc

            if op_found is None:
                # No binary op found — treat the expression as a structural predicate.
                # Strategy:
                #   1. Detect variable-as-prop uses (e.g. y(x(y))) and register families.
                #   2. Try parse_pattern → match_pattern for structural membership check.
                #      This supports arbitrarily nested patterns like y(x(y)).
                #   3. Fall back to _build_cat_predicate for plain Python predicates.
                pred_var = raw_var_constraints[0][0] if raw_var_constraints else 'x'
                in_cat_bc = raw_var_constraints[0][1] if raw_var_constraints else None

                # ── Detect variable-as-prop uses in the expression ────────────
                dyn_prop_vars_bc = _scan_plain_var_prop_uses(
                    expr, var_set, any_depth=True
                )
                families_bc: dict = {dpv: ('', '', dpv) for dpv in dyn_prop_vars_bc}

                # ── Try structural pattern-based predicate ────────────────────
                _used_pattern_pred = False
                try:
                    from .patterns import parse_pattern as _pp, match_cat_pattern as _mcp
                    _cat_pat = _pp(expr, var_set, known['props'], families=families_bc)
                    _pred_key_bc = f"_nn_cat_{uuid.uuid4().hex}"

                    def _make_pred(p, in_c, cvar):
                        if in_c:
                            def _pred(v):
                                from newn.core import _ENGINE as _E
                                bindings = _mcp(p, v, {})
                                if bindings is None:
                                    return False
                                inner = bindings.get(cvar, v)
                                return _E.get_category(in_c).contains(inner)
                        else:
                            def _pred(v):
                                return _mcp(p, v, {}) is not None
                        return _pred

                    _ENGINE.store_cat_pred(
                        _pred_key_bc,
                        _make_pred(_cat_pat, in_cat_bc, pred_var)
                    )
                    full_pred_bc = f"_nn_engine.get_cat_pred({_pred_key_bc!r})"
                    _used_pattern_pred = True
                except Exception:
                    full_pred_bc = _build_cat_predicate(expr, pred_var, in_cat_bc, known)

                known['cats'].add(cat_name)
                if cat_name in known['props']:
                    out_lines.append(
                        f"{indent}_nn_engine.register_category({cat_name!r}, {full_pred_bc}){comment}"
                    )
                else:
                    out_lines.append(
                        f"{indent}{cat_name} = _nn_engine.register_category({cat_name!r}, {full_pred_bc}){comment}"
                    )
                # Track single-prop wrapping for bind-by-category support
                # (only meaningful when expression is a simple prop(var) check)
                if not _used_pattern_pred or not dyn_prop_vars_bc:
                    _sp_m_bc = re.fullmatch(
                        rf'(\w+)\s*\(\s*{re.escape(pred_var)}\s*\)', expr.strip()
                    )
                    if _sp_m_bc:
                        _sp_bc = _sp_m_bc.group(1)
                        if _sp_bc in known['props']:
                            out_lines.append(
                                f"{indent}_nn_engine.register_category_prop({cat_name!r}, {_sp_bc!r})"
                            )
                continue

            left_str, right_str = _split_lhs(expr, op_found)
            props = known['props']
            try:
                left_pat  = parse_pattern(left_str,  var_set, props) if left_str  else None
                right_pat = parse_pattern(right_str, var_set, props) if right_str else None
            except Exception as e:
                raise NewnSyntaxError(
                    f"{_file}:{lineno}: category '{cat_name}': {e}"
                ) from e

            key = f"_nn_ucat_{uuid.uuid4().hex}"
            _ENGINE.store_pending_ucat(key, {
                'name':      cat_name,
                'op_name':   op_found,
                'left_pat':  left_pat,
                'right_pat': right_pat,
            })

            known['cats'].add(cat_name)
            if cat_name in known['props']:
                out_lines.append(
                    f"{indent}_nn_engine.register_ucat_by_key({key!r}){comment}"
                )
            else:
                out_lines.append(
                    f"{indent}{cat_name} = _nn_engine.register_ucat_by_key({key!r}){comment}"
                )
            continue

        # --- category (classic: for all x [in cat], predicate) ---
        m = _CAT_RE.match(code_stripped)
        if m:
            cat_name  = m.group(1)
            vars_str  = m.group(2)
            in_cat    = m.group(3)
            pred_expr = m.group(4).strip()
            variables = [v.strip() for v in vars_str.split(',')]
            var0      = variables[0]
            indent = _indent(line)

            # Auto-register props found in predicate (all depths).
            # e.g. 'happy(sad(x))' → auto-register both 'happy' and 'sad'.
            _var_set_cl_cat = set(variables)
            new_props_cl_cat = _scan_auto_props(
                pred_expr, _var_set_cl_cat, known['props'], known_ops=known['ops']
            )
            for ap_name in sorted(new_props_cl_cat):
                out_lines.append(
                    f"{indent}{ap_name} = _nn_engine.make_prop({ap_name!r})"
                    f"  # auto-inferred prop"
                )
                known['props'].add(ap_name)

            # Detect variable-as-prop uses and try parse_pattern-based predicate.
            _dyn_bc_cl = _scan_plain_var_prop_uses(pred_expr, _var_set_cl_cat, any_depth=True)
            _fam_cl: dict = {dpv: ('', '', dpv) for dpv in _dyn_bc_cl}
            _used_cl_pat = False
            try:
                from .patterns import parse_pattern as _pp_cl, match_cat_pattern as _mcp_cl
                _cl_pat = _pp_cl(pred_expr, _var_set_cl_cat, known['props'], families=_fam_cl)
                _cl_key = f"_nn_cat_{uuid.uuid4().hex}"

                def _make_cl_pred(p, in_c, cvar):
                    if in_c:
                        def _pred(v):
                            from newn.core import _ENGINE as _E
                            bindings = _mcp_cl(p, v, {})
                            if bindings is None:
                                return False
                            inner = bindings.get(cvar, v)
                            return _E.get_category(in_c).contains(inner)
                    else:
                        def _pred(v):
                            return _mcp_cl(p, v, {}) is not None
                    return _pred

                _ENGINE.store_cat_pred(_cl_key, _make_cl_pred(_cl_pat, in_cat, var0))
                full_pred = f"_nn_engine.get_cat_pred({_cl_key!r})"
                _used_cl_pat = True
            except Exception:
                full_pred = _build_cat_predicate(pred_expr, var0, in_cat, known)

            known['cats'].add(cat_name)
            if cat_name in known['props']:
                out_lines.append(
                    f"{indent}_nn_engine.register_category({cat_name!r}, {full_pred}){comment}"
                )
            else:
                out_lines.append(
                    f"{indent}{cat_name} = _nn_engine.register_category({cat_name!r}, {full_pred}){comment}"
                )
            # If predicate is a single prop call (e.g. fib(x)), track which prop
            # this category wraps so bind-by-category can find it later.
            _single_prop_m = re.fullmatch(
                rf'(\w+)\s*\(\s*{re.escape(var0)}\s*\)', pred_expr.strip()
            )
            if _single_prop_m:
                _sp_name = _single_prop_m.group(1)
                if _sp_name in known['props']:
                    out_lines.append(
                        f"{indent}_nn_engine.register_category_prop({cat_name!r}, {_sp_name!r})"
                    )
            continue

        # --- bind (Form 1: point export bind)  prop(val) == [display] ---
        m = _BIND_POINT_RE.match(code_stripped)
        if m:
            prop_name   = m.group(1)
            inner_expr  = m.group(2).strip()
            display_expr = m.group(3).strip()
            indent = _indent(line)
            out_lines.append(
                f"{indent}_nn_engine.bind_value({prop_name!r}, ({inner_expr}), ({display_expr})){comment}"
            )
            continue

        # --- bind (Form 4: point import bind)  external_val == [newn_expr] ---
        # Must be tried BEFORE Form 3 (category) so that  23 == [fib(8)]  is not
        # mistaken for a category bind.
        # Guard: if the LHS is a known category/prop/op name, let Form 3 handle it.
        m = _BIND_IMPORT_POINT_RE.match(code_stripped)
        if m:
            ext_expr  = m.group(1).strip()
            newn_expr = m.group(2).strip()
            _lhs_is_name = bool(re.fullmatch(r'\w+', ext_expr))
            _is_domain_name = (
                ext_expr in known.get('cats', set())
                or ext_expr in known.get('props', set())
                or ext_expr in known.get('ops', set())
            )
            if _lhs_is_name and _is_domain_name:
                pass  # fall through to Form 3 (category bind)
            else:
                indent = _indent(line)
                out_lines.append(
                    f"{indent}_nn_engine.import_bind(({ext_expr}), ({newn_expr})){comment}"
                )
                continue

        # --- bind (Form 2: range export bind)  for all x [...], prop(x) == [...] ---
        m = _BIND_RANGE_RE.match(code_stripped)
        if m:
            _var        = m.group(1)
            _params_str = m.group(2)
            prop_name   = m.group(3)
            _prop_var   = m.group(4)
            vals_str    = m.group(5).strip()
            start_expr, step_expr = _parse_bind_params(_params_str)
            uid = uuid.uuid4().hex[:8]
            indent = _indent(line)
            out_lines.append(f"{indent}_nn_bind_vals_{uid} = [{vals_str}]{comment}")
            out_lines.append(
                f"{indent}for _nn_bi_{uid}, _nn_bv_{uid} in enumerate(_nn_bind_vals_{uid}):"
            )
            out_lines.append(
                f"{indent}    _nn_engine.bind_value({prop_name!r}, "
                f"({start_expr}) + _nn_bi_{uid} * ({step_expr}), _nn_bv_{uid})"
            )
            continue

        # --- bind (Form 5: range import bind)  for all x [...], x == [newn1, newn2, ...] ---
        m = _BIND_IMPORT_RANGE_RE.match(code_stripped)
        if m:
            _var        = m.group(1)   # loop variable name
            _params_str = m.group(2)
            _lhs_var    = m.group(3)   # must equal _var — plain variable (no prop wrap)
            vals_str    = m.group(4).strip()
            start_expr, step_expr = _parse_bind_params(_params_str)
            uid = uuid.uuid4().hex[:8]
            indent = _indent(line)
            out_lines.append(f"{indent}_nn_bind_vals_{uid} = [{vals_str}]{comment}")
            out_lines.append(
                f"{indent}for _nn_bi_{uid}, _nn_nv_{uid} in enumerate(_nn_bind_vals_{uid}):"
            )
            out_lines.append(
                f"{indent}    _nn_engine.import_bind("
                f"({start_expr}) + _nn_bi_{uid} * ({step_expr}), _nn_nv_{uid})"
            )
            continue

        # --- bind (Form 3: category bind) ---
        m = _BIND_CAT_RE.match(code_stripped)
        if m:
            cat_name_b  = m.group(1)
            _params_str = m.group(2)
            vals_str    = m.group(3).strip()
            start_expr, step_expr = _parse_bind_params(_params_str)
            uid = uuid.uuid4().hex[:8]
            indent = _indent(line)
            out_lines.append(f"{indent}_nn_bind_vals_{uid} = [{vals_str}]{comment}")
            out_lines.append(f"{indent}_nn_cp_{uid} = _nn_engine.get_category_prop({cat_name_b!r})")
            out_lines.append(f"{indent}if _nn_cp_{uid} is None:")
            out_lines.append(
                f"{indent}    raise ValueError("
                f"\"bind: category {cat_name_b!r} has no associated prop — "
                f"define it as: category {cat_name_b!r}: for all x, propname(x)\")"
            )
            out_lines.append(
                f"{indent}for _nn_bi_{uid}, _nn_bv_{uid} in enumerate(_nn_bind_vals_{uid}):"
            )
            out_lines.append(
                f"{indent}    _nn_engine.bind_value(_nn_cp_{uid}, "
                f"({start_expr}) + _nn_bi_{uid} * ({step_expr}), _nn_bv_{uid})"
            )
            continue

        # --- axiom (bracket / per-variable quantifier syntax) ---
        m = _AXIOM_BRACKET_RE.match(code_stripped)
        if m:
            ax_name         = m.group(1)
            bracket_content = m.group(2).strip()
            equation        = m.group(3).strip()

            try:
                raw_var_constraints_3 = _parse_bracket_quantifiers(
                    bracket_content, ax_name, known_props=known['props']
                )
            except NNSyntaxError:
                raise
            except Exception as e:
                raise NewnSyntaxError(f"{_file}:{lineno}: axiom '{ax_name}': bad quantifiers — {e}") from e

            # Build prop-family dict from 3-tuples where numeric_var is not None:
            #   families['pn'] = ('p', '', 'n')  — prefix, suffix, num_var
            families: Dict[str, Tuple[str, str, str]] = {}
            for inner_var, prop_name, numeric_var in raw_var_constraints_3:
                if numeric_var is not None and prop_name is not None:
                    family_info = _find_family_var(prop_name, {numeric_var})
                    if family_info is not None:
                        families[prop_name] = family_info

            # ── Symbol-variable sanitization (bracket axiom) ─────────────────
            _vnmap_ax = {
                vc[0]: _sanitize_var_name(vc[0])
                for vc in raw_var_constraints_3
                if _sanitize_var_name(vc[0]) != vc[0]
            }
            if _vnmap_ax:
                raw_var_constraints_3 = [
                    (_sanitize_var_name(vc[0]), vc[1], vc[2])
                    for vc in raw_var_constraints_3
                ]

            # All variables = all vc[0] values, in order, de-duplicated
            variables = list(dict.fromkeys(vc[0] for vc in raw_var_constraints_3))
            var_set   = set(variables)
            _check_var_names(variables, known, ax_name, _file, lineno)

            # plain_vars = variables declared with simple 'for all x' (no constraint)
            plain_vars_ax: Set[str] = {
                vc[0] for vc in raw_var_constraints_3 if vc[1] is None and vc[2] is None
            }

            # Convert to 2-tuples for register_axiom:
            #   family inner vars → unconstrained (PropFamilyPat handles the check)
            #   regular vars      → keep their prop/cat constraint
            raw_var_constraints_2: List[Tuple[str, Optional[str]]] = []
            for inner_var, prop_name, numeric_var in raw_var_constraints_3:
                if numeric_var is not None:
                    raw_var_constraints_2.append((inner_var, None))
                else:
                    raw_var_constraints_2.append((inner_var, prop_name))

            equation, ax_severity = _extract_severity(equation)

            eq_pos = _find_top_eq(equation)
            if eq_pos < 0:
                raise NewnSyntaxError(
                    f"{_file}:{lineno}: axiom '{ax_name}': no '=' found in equation: {equation!r}"
                )
            lhs_str = equation[:eq_pos].strip()
            rhs_str = equation[eq_pos + 1:].strip()

            # Apply symbol-variable substitution to the equation text.
            # Pass known_ops so the state machine can tell Newn ops from Python
            # operators when the same symbol (e.g. *) plays both roles.
            if _vnmap_ax:
                lhs_str = _replace_user_vars(lhs_str, _vnmap_ax, known_ops=known.get('ops'))
                rhs_str = _replace_user_vars(rhs_str, _vnmap_ax, known_ops=known.get('ops'))

            indent = _indent(line)

            # ── Detect plain-variable prop uses in LHS and RHS ─────────────
            # e.g. 'x(u)' where x is a plain variable → add x to families so
            # that _transform_family_calls rewrites  x(expr)  in the RHS.
            # Scan both sides: a variable may only appear in prop-call position
            # on the RHS (e.g. LHS has z(x) plain, RHS has x(x*y)).
            # Must happen BEFORE _scan_auto_props so family names are excluded.
            dyn_prop_vars = _scan_plain_var_prop_uses(lhs_str, plain_vars_ax)
            dyn_prop_vars |= _scan_plain_var_prop_uses(rhs_str, plain_vars_ax, any_depth=True)
            for dpv in dyn_prop_vars:
                if dpv not in families:
                    families[dpv] = ('', '', dpv)

            # ── Auto-register props from LHS and RHS usage ─────────────────
            # Any identifier used as name(expr) in the LHS *or RHS* that is not
            # a variable, not a known prop, and not a family template name
            # (family names look like prop-calls but are resolved at runtime).
            excluded_props = known['props'] | set(families.keys())
            new_props_ax = _scan_auto_props(lhs_str, var_set, excluded_props, known_ops=known['ops'])
            new_props_ax |= _scan_auto_props(rhs_str, var_set, excluded_props | new_props_ax | _PYTHON_BUILTINS, known_ops=known['ops'])
            for ap_name in sorted(new_props_ax):
                out_lines.append(
                    f"{indent}{ap_name} = _nn_engine.make_prop({ap_name!r})"
                    f"  # auto-inferred prop"
                )
                known['props'].add(ap_name)

            # ── Find op ────────────────────────────────────────────────────
            op_found = _find_op_in_lhs(lhs_str, known['ops'])
            if op_found is None:
                # Priority order:
                # 1. Auto-detect from LHS infix position (handles new ops like 'newadd')
                # 2. Bidirectional swap: look for a known op in the RHS
                #    (handles reversed axioms: 'result = pattern')
                # 3. Auto-detect from RHS (reversed with a new op)
                #
                # Auto-detect LHS FIRST so that when the RHS happens to contain a
                # different known op (e.g. 'x.1 add ...') we don't incorrectly
                # treat the result expression as the pattern side.
                op_cand = _find_op_in_lhs_auto(lhs_str, var_set, known['props'])
                if op_cand is not None:
                    op_found = op_cand
                    if op_found not in known['ops']:
                        out_lines.append(
                            f"{indent}{op_found} = _nn_engine.register_op({op_found!r})"
                            f"  # auto-inferred op"
                        )
                        known['ops'].add(op_found)
                else:
                    # Bidirectional: try a known op in the RHS (reversed equation)
                    op_in_rhs = _find_op_in_lhs(rhs_str, known['ops'])
                    if op_in_rhs is not None:
                        lhs_str, rhs_str = rhs_str, lhs_str
                        op_found = op_in_rhs
                    else:
                        # Auto-detect from RHS (reversed with a new op)
                        op_cand = _find_op_in_lhs_auto(rhs_str, var_set, known['props'])
                        if op_cand is not None:
                            lhs_str, rhs_str = rhs_str, lhs_str
                            op_found = op_cand
                            if op_found not in known['ops']:
                                out_lines.append(
                                    f"{indent}{op_found} = _nn_engine.register_op({op_found!r})"
                                    f"  # auto-inferred op"
                                )
                                known['ops'].add(op_found)
                        else:
                            raise NewnSyntaxError(
                                f"{_file}:{lineno}: axiom '{ax_name}': no op found in LHS or RHS.\n"
                                f"  LHS={lhs_str!r}, RHS={rhs_str!r}\n"
                                f"  Tip: declare the op with 'op name: None' before this axiom,\n"
                                f"  or ensure the op name appears in infix position between two terms.\n"
                                f"  (Unary ops like 'negate(x)' must still be pre-declared.)"
                            )

            # ── Detect family op (op name contains a variable letter) ───────
            # e.g. 'usex' with var 'x' → template op with prefix='use', suffix='', var='x'
            family_op_info: Optional[Tuple[str, str, str]] = _find_family_var(op_found, plain_vars_ax)

            props = known['props']
            left_str, right_str = _split_lhs(lhs_str, op_found)
            try:
                left_pat  = parse_pattern(left_str,  var_set, props, families=families) if left_str  else None
                right_pat = parse_pattern(right_str, var_set, props, families=families) if right_str else None
            except Exception as e:
                raise NewnSyntaxError(f"{_file}:{lineno}: axiom '{ax_name}': {e}") from e

            # ── Post-check: if the template variable also appears in the LHS
            #    argument patterns or RHS, it is being used as a real pattern
            #    variable — not just as an injected op-name value.  In that case
            #    the axiom should be registered as a regular axiom for the
            #    literal op name (e.g. 'forevey' with var 'y' in 'z(y)' is
            #    NOT a template; it's an op called 'forevey').
            if family_op_info is not None:
                _tmpl_var = family_op_info[2]
                # Only check the LHS argument strings (not the RHS).
                # A template variable may legitimately appear in the RHS (e.g.
                # 'val(v + n)' for 'fnn').  But if it appears in the LHS arg
                # patterns it is being used as a real pattern variable — the op
                # name just happens to end with that letter (e.g. 'forevey'
                # where 'y' appears in the RHS pattern 'z(y)' on the left side).
                _lhs_src = (left_str or '') + ' ' + (right_str or '')
                if re.search(r'(?<![A-Za-z0-9_])' + re.escape(_tmpl_var) + r'(?![A-Za-z0-9_])', _lhs_src):
                    # Variable appears in LHS argument patterns → treat as regular axiom
                    family_op_info = None

            # Transform RHS: arg access (x.1 → x.args[0]), numeric prop calls
            # (5(7) → auto_prop('5')(7)), op infix, then family calls.
            rhs_code = _transform_arg_access(rhs_str)
            rhs_code = _transform_numeric_prop_calls(rhs_code)
            rhs_code = _transform_ops(rhs_code, known['ops'])
            if families:
                rhs_code = _transform_family_calls(rhs_code, families)

            if family_op_info is not None:
                # ── Template (family) axiom path ────────────────────────────
                op_prefix, op_suffix, op_var = family_op_info
                # Record this template so regular lines can recognise concrete
                # instances (e.g. 'foreve7' when the template is 'forevex').
                tmpl_entry = (op_prefix, op_suffix)
                if tmpl_entry not in known['template_ops']:
                    known['template_ops'].append(tmpl_entry)
                key = f"_nn_tax_{uuid.uuid4().hex}"
                _ENGINE.store_pending_template_axiom(key, {
                    'prefix':              op_prefix,
                    'suffix':              op_suffix,
                    'var_name':            op_var,
                    'name':                ax_name,
                    'op_name_template':    op_found,
                    'variables':           variables,
                    'category':            None,
                    'left_pat':            left_pat,
                    'right_pat':           right_pat,
                    'rhs_code':            rhs_code,
                    'raw_var_constraints': raw_var_constraints_2,
                    'source_line':         stripped,
                    'nn_file':             _file,
                    'nn_lineno':           lineno,
                    'severity':            ax_severity,
                })
                out_lines.append(
                    f"{indent}_nn_engine.register_template_axiom_by_key({key!r}){comment}"
                )
            else:
                # ── Regular axiom path ──────────────────────────────────────
                key = f"_nn_ax_{uuid.uuid4().hex}"
                _ENGINE.store_pending_axiom(key, {
                    'name':                ax_name,
                    'op_name':             op_found,
                    'variables':           variables,
                    'category':            None,
                    'left_pat':            left_pat,
                    'right_pat':           right_pat,
                    'rhs_code':            rhs_code,
                    'raw_var_constraints': raw_var_constraints_2,
                    'source_line':         stripped,
                    'nn_file':             _file,
                    'nn_lineno':           lineno,
                    'severity':            ax_severity,
                })
                out_lines.append(
                    f"{indent}_nn_engine.register_axiom_by_key({key!r}){comment}"
                )
            continue

        # --- axiom (classic syntax) ---
        m = _AXIOM_RE.match(code_stripped)
        if m:
            ax_name   = m.group(1)
            vars_str  = m.group(2)
            in_cat    = m.group(3)
            equation  = m.group(4).strip()
            variables = [v.strip() for v in vars_str.split(',')]
            var_set   = set(variables)
            _check_var_names(variables, known, ax_name, _file, lineno)

            equation, ax_severity = _extract_severity(equation)

            eq_pos = _find_top_eq(equation)
            if eq_pos < 0:
                raise NewnSyntaxError(
                    f"{_file}:{lineno}: axiom '{ax_name}': no '=' found in equation: {equation!r}"
                )
            lhs_str = equation[:eq_pos].strip()
            rhs_str = equation[eq_pos + 1:].strip()

            indent_cl = _indent(line)

            # Auto-register props from LHS *and RHS* usage.
            # Exclude known ops so unary ops like negate(x) are not mistaken for props.
            new_props_cl = _scan_auto_props(lhs_str, var_set, known['props'], known_ops=known['ops'])
            new_props_cl |= _scan_auto_props(rhs_str, var_set, known['props'] | new_props_cl | _PYTHON_BUILTINS, known_ops=known['ops'])
            for ap_name in sorted(new_props_cl):
                out_lines.append(
                    f"{indent_cl}{ap_name} = _nn_engine.make_prop({ap_name!r})"
                    f"  # auto-inferred prop"
                )
                known['props'].add(ap_name)

            op_found = _find_op_in_lhs(lhs_str, known['ops'])
            if op_found is None:
                # Same priority as bracket handler: auto-detect LHS first so that
                # a known op in the RHS (e.g. inside an x.1 expression) doesn't
                # cause an incorrect bidirectional swap.
                op_cand = _find_op_in_lhs_auto(lhs_str, var_set, known['props'])
                if op_cand is not None:
                    op_found = op_cand
                    if op_found not in known['ops']:
                        out_lines.append(
                            f"{indent_cl}{op_found} = _nn_engine.register_op({op_found!r})"
                            f"  # auto-inferred op"
                        )
                        known['ops'].add(op_found)
                else:
                    # Bidirectional swap: equation written as "result = pattern"
                    op_in_rhs = _find_op_in_lhs(rhs_str, known['ops'])
                    if op_in_rhs is not None:
                        lhs_str, rhs_str = rhs_str, lhs_str
                        op_found = op_in_rhs
                    else:
                        # Auto-detect from RHS (reversed with a new op)
                        op_cand = _find_op_in_lhs_auto(rhs_str, var_set, known['props'])
                        if op_cand is not None:
                            lhs_str, rhs_str = rhs_str, lhs_str
                            op_found = op_cand
                        if op_found is None:
                            raise NewnSyntaxError(
                                f"{_file}:{lineno}: axiom '{ax_name}': no op found in LHS or RHS.\n"
                                f"  LHS={lhs_str!r}, RHS={rhs_str!r}\n"
                                f"  Tip: declare with 'op name: None' before this axiom, or ensure\n"
                                f"  the op name appears in infix position between two terms."
                            )
                        if op_found not in known['ops']:
                            out_lines.append(
                                f"{indent_cl}{op_found} = _nn_engine.register_op({op_found!r})"
                                f"  # auto-inferred op"
                            )
                            known['ops'].add(op_found)

            left_str, right_str = _split_lhs(lhs_str, op_found)
            props = known['props']
            try:
                left_pat  = parse_pattern(left_str,  var_set, props) if left_str  else None
                right_pat = parse_pattern(right_str, var_set, props) if right_str else None
            except Exception as e:
                raise NewnSyntaxError(f"{_file}:{lineno}: axiom '{ax_name}': {e}") from e

            rhs_code = _transform_arg_access(rhs_str)
            rhs_code = _transform_ops(rhs_code, known['ops'])

            # Plain variables used as prop-calls in either LHS or RHS
            # (e.g. 'x(expr)' where x is in var_set) → auto_prop(str(x))(expr)
            _plain_vars_cl = var_set - known['props'] - known['ops'] - known.get('cats', set())
            _cl_dyn_families: dict = {}
            for dpv in (_scan_plain_var_prop_uses(lhs_str, _plain_vars_cl) |
                        _scan_plain_var_prop_uses(rhs_str, _plain_vars_cl, any_depth=True)):
                _cl_dyn_families[dpv] = ('', '', dpv)
            if _cl_dyn_families:
                rhs_code = _transform_family_calls(rhs_code, _cl_dyn_families)

            key = f"_nn_ax_{uuid.uuid4().hex}"
            _ENGINE.store_pending_axiom(key, {
                'name':      ax_name,
                'op_name':   op_found,
                'variables': variables,
                'category':  in_cat,
                'left_pat':  left_pat,
                'right_pat': right_pat,
                'rhs_code':  rhs_code,
                'source_line': stripped,
                'nn_file':   _file,
                'nn_lineno': lineno,
                'severity':  ax_severity,
            })

            indent = _indent(line)
            out_lines.append(
                f"{indent}_nn_engine.register_axiom_by_key({key!r}){comment}"
            )
            continue

        # --- literal backtracking: name = {9}  (search for a concrete value) ---
        # MUST be checked before dict/set literal wrapping (would wrap {9} as a set).
        m_btl = _BACKTRACK_LITERAL_RE.match(code_stripped)
        if m_btl:
            btl_indent   = _indent(line)
            btl_var_name = m_btl.group(2)
            btl_literal  = m_btl.group(3)
            # Coerce to int or float for the generated equality check
            btl_py_val = (float(btl_literal) if '.' in btl_literal
                          else int(btl_literal))
            tab = btl_indent + '    '
            out_lines.append(
                f"{btl_indent}{btl_var_name} = _nn_engine.backtrack_pattern(\n"
                f"{tab}[],\n"
                f"{tab}lambda _bt_v: _bt_v == {btl_py_val!r},\n"
                f"{tab}lambda _bt_v: {{}},\n"
                f"{tab}op_filter=None,\n"
                f"{btl_indent})"
            )
            continue

        # --- explicit probe backtracking: name = {[for all x], pattern, probe} ---
        # Checked FIRST so ', probe' suffix isn't swallowed by the default regex.
        m_btp = _BACKTRACK_PROBE_RE.match(code_stripped)
        if m_btp:
            btp_indent   = _indent(line)
            btp_var_name = m_btp.group(2)
            btp_brackets = m_btp.group(3)
            btp_pattern  = m_btp.group(4).strip()
            btp_inner    = btp_brackets[1:-1].strip()
            try:
                btp_raw_vars = _parse_bracket_quantifiers(
                    btp_inner,
                    ax_name=f"<backtrack:{btp_var_name}>",
                    known_props=known.get('props'),
                )
            except NewnSyntaxError:
                btp_raw_vars = []
            btp_vnmap = {
                vc[0]: _sanitize_var_name(vc[0])
                for vc in btp_raw_vars
                if _sanitize_var_name(vc[0]) != vc[0]
            }
            if btp_vnmap:
                btp_pattern = _replace_user_vars(btp_pattern, btp_vnmap)
                btp_raw_vars = [
                    (_sanitize_var_name(vc[0]), vc[1], vc[2])
                    for vc in btp_raw_vars
                ]
            btp_var_names = [vc[0] for vc in btp_raw_vars]
            out_lines.append(_generate_backtrack_code(
                btp_var_name, btp_var_names, btp_pattern, known, btp_indent
            ))
            continue

        # --- explicit structural: name = {[for all x], pattern, structural} ---
        # Checked BEFORE the no-suffix default so ', structural' is stripped
        # cleanly and doesn't land in the pattern group.
        m_bts = _BACKTRACK_STRUCTURAL_RE.match(code_stripped)
        if m_bts:
            bts_indent   = _indent(line)
            bts_var_name = m_bts.group(2)
            bts_brackets = m_bts.group(3)
            bts_pattern  = m_bts.group(4).strip()
            bts_inner    = bts_brackets[1:-1].strip()
            try:
                bts_raw_vars = _parse_bracket_quantifiers(
                    bts_inner,
                    ax_name=f"<structural_backtrack:{bts_var_name}>",
                    known_props=known.get('props'),
                )
            except NewnSyntaxError:
                bts_raw_vars = []
            bts_vnmap = {
                vc[0]: _sanitize_var_name(vc[0])
                for vc in bts_raw_vars
                if _sanitize_var_name(vc[0]) != vc[0]
            }
            if bts_vnmap:
                bts_pattern = _replace_user_vars(bts_pattern, bts_vnmap)
                bts_raw_vars = [
                    (_sanitize_var_name(vc[0]), vc[1], vc[2])
                    for vc in bts_raw_vars
                ]
            bts_var_names = [vc[0] for vc in bts_raw_vars]
            out_lines.append(
                f"{bts_indent}{bts_var_name} = _nn_engine.backtrack_structural(\n"
                f"{bts_indent}    {bts_var_names!r},\n"
                f"{bts_indent}    {bts_pattern!r},\n"
                f"{bts_indent})"
            )
            continue

        # --- default backtracking (structural): name = {[for all x], pattern} ---
        # Structural is the default — no suffix required.
        # Checked before dict/set literal wrapping to avoid {} confusion.
        m_bt = _BACKTRACK_RE.match(code_stripped)
        if m_bt:
            bt_indent   = _indent(line)
            bt_var_name = m_bt.group(2)
            bt_brackets = m_bt.group(3)
            bt_pattern  = m_bt.group(4).strip()
            bt_inner    = bt_brackets[1:-1].strip()
            try:
                bt_raw_vars = _parse_bracket_quantifiers(
                    bt_inner,
                    ax_name=f"<structural_backtrack:{bt_var_name}>",
                    known_props=known.get('props'),
                )
            except NewnSyntaxError:
                bt_raw_vars = []
            bt_vnmap = {
                vc[0]: _sanitize_var_name(vc[0])
                for vc in bt_raw_vars
                if _sanitize_var_name(vc[0]) != vc[0]
            }
            if bt_vnmap:
                bt_pattern = _replace_user_vars(bt_pattern, bt_vnmap)
                bt_raw_vars = [
                    (_sanitize_var_name(vc[0]), vc[1], vc[2])
                    for vc in bt_raw_vars
                ]
            bt_var_names = [vc[0] for vc in bt_raw_vars]
            out_lines.append(
                f"{bt_indent}{bt_var_name} = _nn_engine.backtrack_structural(\n"
                f"{bt_indent}    {bt_var_names!r},\n"
                f"{bt_indent}    {bt_pattern!r},\n"
                f"{bt_indent})"
            )
            continue

        # --- regular Python line: transform infix op calls + numeric prop calls ---
        # _transform_numeric_prop_calls handles: 5(7) → _nn_engine.auto_prop('5')(7)
        # _transform_ops handles:               a forever b → a |forever| b
        # _wrap_dict_literals handles:          d = {...} → d = _nn_vdict({...})
        transformed = _transform_numeric_prop_calls(line)
        transformed = _transform_ops(transformed, known['ops'],
                                      template_patterns=known.get('template_ops'))
        transformed = _wrap_dict_literals(transformed)
        out_lines.append(transformed)

    return '\n'.join(out_lines)


def _transform_family_calls(rhs_code: str, families: dict) -> str:
    """
    Replace prop-family calls in a RHS expression string with auto-prop calls.

    For each family in *families*, e.g. 'pn' → ('p', '', 'n'):
        pn(x)   →   _nn_auto_prop('p' + str(n) + '')(x)

    This lets the RHS produce PropValues in any member of the family based
    on the runtime value of the numeric variable (e.g. n=7 → 'p7').
    """
    for fam_name, (prefix, suffix, num_var) in families.items():
        # Match  fam_name(...)  but NOT already transformed
        pat = re.compile(rf'\b{re.escape(fam_name)}\s*\(')
        replacement = f"_nn_auto_prop({prefix!r} + str({num_var}) + {suffix!r})("
        rhs_code = pat.sub(replacement, rhs_code)
    return rhs_code


def _make_builtins(engine) -> dict:
    """
    Build the dict of helper functions injected into every nn_exec namespace.
    """
    from .core import PropValue, UnresolvedExpr, _nn_first, MultiResult as _MultiResult

    def show(value):
        """Pretty-print a value with its type."""
        type_name = type(value).__name__
        if isinstance(value, PropValue):
            print(f"  {value!r}  [PropValue: prop='{value.prop_name}', inner={value.value!r}]")
        elif isinstance(value, UnresolvedExpr):
            print(f"  {value!r}  [UnresolvedExpr: op='{value.op_name}', args={value.args!r}]")
        else:
            print(f"  {value!r}  [{type_name}]")

    def trace_on():
        engine.trace_on()

    def trace_off():
        engine.trace_off()

    def which_axioms(op_name: str):
        """Print all axioms registered for an op."""
        print(engine.which_axioms(op_name))

    def explain(op_name: str, *args):
        """Show which axiom would fire for the given arguments (without executing)."""
        print(engine.explain(op_name, *args))

    def coverage(op_name: str):
        """Print a static coverage analysis for an op."""
        print(engine.coverage(op_name))

    def why_not(op_name: str, *args):
        """Explain why no axiom fired for the given arguments."""
        print(engine.explain(op_name, *args))

    def fold(op, values):
        """
        Reduce a list of values using a two-arg op.
        fold(add, [1, 2, 3])  →  add(add(1, 2), 3)
        """
        if not hasattr(values, '__iter__'):
            raise TypeError(f"fold: expected an iterable, got {type(values).__name__}")
        it = iter(values)
        try:
            acc = next(it)
        except StopIteration:
            raise ValueError("fold: cannot fold an empty list")
        for item in it:
            acc = op(acc, item)
        return acc

    def each(op, values):
        """
        Map a one-arg op over a list of values.
        each(double, [1, 2, 3])  →  [double(1), double(2), double(3)]
        """
        if not hasattr(values, '__iter__'):
            raise TypeError(f"each: expected an iterable, got {type(values).__name__}")
        return [op(item) for item in values]

    # --- backward chaining ---
    from .backchain import (
        backchain as _backchain_fn,
        query     as _query_fn,
        prove     as _prove_fn,
        Solution  as _Solution,
    )

    def query(op_name: str, target, domain=None, max_results: int = 50):
        """
        Find all inputs to op_name that produce target.
        Tries symbolic inversion first; falls back to brute-force over domain.

        Example::
            results = query('add', 10, domain=range(0, 15))
            for sol in results:
                print(sol.inputs, '→', sol.explain())
        """
        results = _query_fn(engine, op_name, target,
                            domain=domain, max_results=max_results)
        return results

    def backchain(op_name: str, target, max_results: int = 20):
        """
        Symbolically find inputs to op_name that produce target (no domain needed).
        Works for axioms whose RHS is a simple expression (x+3, absent(x), -x, ...).

        Example::
            results = backchain('double', 10)
            # Might find: Solution(double(5) → via axiom 'dbl')
        """
        return _backchain_fn(engine, op_name, target, max_results=max_results)

    def prove(op_name: str, *args):
        """
        Return True if the op call resolves to a concrete (non-symbolic) value.

        Example::
            if prove('add', 3, 7):
                print('provable!')
        """
        return _prove_fn(engine, op_name, *args)

    # --- translate_out / translate_in (bind direction utilities) ---

    def translate_out(value):
        """
        Translate a Newn value to its external/display representation.

        If *value* is a PropValue that has an export bind registered, this
        returns the bound display value.  Otherwise it returns *value*
        unchanged.

        Example::
            bind sev: fib(8) == [21]
            translate_out(fib(8))   # → 21
            translate_out(fib(99))  # → fib(99)  (no bind → unchanged)
        """
        bound = engine.lookup_bind(getattr(value, 'prop_name', None),
                                   getattr(value, 'value', None))
        return bound if bound is not None else value

    def translate_in(external_value):
        """
        Translate an external value to its Newn representation.

        If *external_value* has an import bind registered (via
        ``bind name: external_val == [newn_expr]``), this returns the
        corresponding Newn PropValue.  Otherwise it returns *external_value*
        unchanged.

        Example::
            bind sev: 21 == [fib(8)]
            translate_in(21)   # → fib(8)
            translate_in(99)   # → 99  (no bind → unchanged)
        """
        newn_val = engine.lookup_import_bind(external_value)
        return newn_val if newn_val is not None else external_value

    # --- export ---
    from .export import (
        export_prolog  as _export_prolog,
        export_z3      as _export_z3,
        export_pddl    as _export_pddl,
        export_python  as _export_python,
    )

    def export_prolog(filepath: str):
        """Export all axioms as a Prolog .pl file."""
        src = _export_prolog(filepath, engine=engine)
        print(f"  Prolog domain written to {filepath!r}  ({len(src)} chars)")
        return src

    def export_z3(filepath: str):
        """Export all axioms as a Z3 Python script."""
        src = _export_z3(filepath, engine=engine)
        print(f"  Z3 domain written to {filepath!r}  ({len(src)} chars)")
        return src

    def export_pddl(filepath: str, domain_name: str = 'newn_domain'):
        """Export all axioms as a PDDL domain file."""
        src = _export_pddl(filepath, domain_name=domain_name, engine=engine)
        print(f"  PDDL domain written to {filepath!r}  ({len(src)} chars)")
        return src

    def export_python(filepath: str):
        """
        Export all ops as a self-contained Python module.

        The generated module re-initialises the engine from the embedded .nn
        source on import, then exposes every op as a regular Python function.

        Example::
            export_python('domain_api.py')
            # then in another script:
            # from domain_api import add, double
        """
        src = _export_python(filepath, engine=engine)
        print(f"  Python API module written to {filepath!r}  ({len(src)} chars)")
        return src

    return {
        'show':         show,
        'trace_on':     trace_on,
        'trace_off':    trace_off,
        'which_axioms': which_axioms,
        'explain':      explain,
        'coverage':     coverage,
        'why_not':      why_not,
        'fold':         fold,
        'each':         each,
        # backward chaining
        'query':        query,
        'backchain':    backchain,
        'prove':        prove,
        'Solution':     _Solution,
        # bind direction utilities
        'translate_out':  translate_out,
        'translate_in':   translate_in,
        # export
        'export_prolog':  export_prolog,
        'export_z3':      export_z3,
        'export_pddl':    export_pddl,
        'export_python':  export_python,
        # structural (bidirectional) backtracking
        'structural_backtrack': engine.backtrack_structural,
        # multi-result helpers
        'first':    _nn_first,
        'MultiResult': _MultiResult,
    }


def nn_exec(
    nn_code: str,
    extra_globals: Optional[dict] = None,
    file: str = '<inline>',
    base_dir: str = '.',
) -> dict:
    """
    Execute .nn code and return the resulting namespace as a dict.

    The global engine is reset before each run so that every .nn program
    starts with a clean slate.

    file:      label used in error messages (e.g. "myfile.nn")
    base_dir:  directory used to resolve relative include paths
    """
    from .core import _ENGINE
    _ENGINE.reset()
    _ENGINE._last_nn_source = nn_code          # stored for export_python
    py_code = transform(nn_code, _file=file, _base_dir=base_dir)
    ns: dict = {}
    ns.update(_make_builtins(_ENGINE))
    if extra_globals:
        ns.update(extra_globals)
    try:
        exec(py_code, ns)
    except NewnSyntaxError:
        raise
    except NewnError:
        raise
    except SyntaxError as e:
        raise NewnSyntaxError(
            f"\n  [Newn] Syntax error in {file}.\n"
            f"  {type(e).__name__}: {e}\n"
            f"  Tip: check for mismatched brackets, missing colons, or invalid expressions."
        ) from e
    except NameError as e:
        bad = str(e).split("'")[1] if "'" in str(e) else str(e)
        raise NewnError(
            f"\n  [Newn] '{bad}' is not defined in {file}.\n"
            f"  Did you forget to declare it?  Common fixes:\n"
            f"    • To use '{bad}' as a wrapper: add  prop {bad}: None\n"
            f"    • To use '{bad}' as an operation: add  op {bad}: None\n"
            f"    • To use '{bad}' as a category: add  category {bad}: for all x, ...\n"
            f"    • To use '{bad}' as a variable: add it to an axiom's 'for all' clause"
        ) from e
    except TypeError as e:
        raise NewnError(
            f"\n  [Newn] Type error in {file}: {e}\n"
            f"  This often means two values that can't be combined were used together.\n"
            f"  Check that your axiom's RHS uses the op (e.g. x add y) rather than\n"
            f"  Python operators (+, *, etc.) when the values may be symbolic."
        ) from e
    except AttributeError as e:
        raise NewnError(
            f"\n  [Newn] Attribute error in {file}: {e}\n"
            f"  This can happen when using .1 / .2 on a value that is not an\n"
            f"  UnresolvedExpr, or when calling a prop/op that was not declared."
        ) from e
    except RecursionError as e:
        raise NewnError(
            f"\n  [Newn] Infinite recursion detected in {file}.\n"
            f"  Check that your axioms have a base case that stops the recursion."
        ) from e
    except Exception as e:
        raise NewnError(
            f"\n  [Newn] Error in {file}: {type(e).__name__}: {e}"
        ) from e
    return ns


def nn_exec_file(path: str, extra_globals: Optional[dict] = None) -> dict:
    """
    Execute a .nn file and return the resulting namespace.
    Include paths within the file are resolved relative to the file's directory.
    """
    path = os.path.abspath(path)
    base_dir = os.path.dirname(path)
    file_label = os.path.basename(path)
    with open(path, 'r') as f:
        src = f.read()
    return nn_exec(src, extra_globals=extra_globals, file=file_label, base_dir=base_dir)


def nn_transform(nn_code: str) -> str:
    """Return the transformed Python source without executing it."""
    return transform(nn_code)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _split_comment(line: str):
    """Split a line into (code_part, comment_part), respecting string literals."""
    in_str = None
    i = 0
    while i < len(line):
        ch = line[i]
        if in_str:
            if ch == '\\':
                i += 2
                continue
            if ch == in_str:
                in_str = None
        else:
            if ch in ('"', "'"):
                in_str = ch
            elif ch == '#':
                return line[:i], '  ' + line[i:]
        i += 1
    return line, ''


def _indent(line: str) -> str:
    return line[: len(line) - len(line.lstrip())]


def _find_family_var(
    prop_name: str,
    plain_vars: Set[str],
) -> Optional[Tuple[str, str, str]]:
    """
    Detect whether *prop_name* contains a single-character wildcard variable.

    Scans *prop_name* for each variable in *plain_vars* (single-character only).
    If found at position i, returns (prefix, suffix, var) where:
      prefix = prop_name[:i]
      suffix = prop_name[i+1:]
      var    = the variable letter

    When multiple variables appear in *prop_name*, the one at the latest position
    is preferred (longest non-empty prefix, e.g. 'use' in 'usex' beats '' in 'usex'
    if both 'u' and 'x' are variables).

    Returns None if no wildcard variable is found in the prop name.

    Example:
        _find_family_var('pn', {'n'})     → ('p', '', 'n')
        _find_family_var('whatx', {'x'})  → ('what', '', 'x')
        _find_family_var('x', {'x'})      → ('', '', 'x')  ← variable IS the full name
        _find_family_var('usex', {'x','u'})  → ('use', '', 'x')  ← x is later → preferred
        _find_family_var('p3', {'n'})     → None  (no 'n' in 'p3')
    """
    candidates: List[Tuple[int, str, str, str]] = []
    for var in plain_vars:
        if len(var) != 1:
            continue  # only single-character vars supported
        # Only match at the START or END of the identifier, not buried in the middle.
        # This prevents 'n' inside 'inc' from being treated as a family-variable.
        # Valid family positions:
        #   end   → prefix='p',    suffix=''   (e.g. 'pn' with var='n')
        #   start → prefix='',    suffix='add' (e.g. 'nadd' with var='n')
        #   both  → prefix='',    suffix=''    (variable IS the full name, e.g. 'x' with var='x')
        n = len(prop_name)
        if prop_name == var:
            # Variable IS the entire identifier ('x' with var='x')
            candidates.append((0, '', '', var))
        elif prop_name.endswith(var) and len(prop_name) > 1:
            idx = n - 1
            prefix = prop_name[:idx]
            suffix = ''
            candidates.append((idx, prefix, suffix, var))
        elif prop_name.startswith(var) and len(prop_name) > 1:
            idx = 0
            prefix = ''
            suffix = prop_name[1:]
            candidates.append((idx, prefix, suffix, var))
    if not candidates:
        return None
    # Prefer variable at the latest position (longest prefix = most natural template)
    candidates.sort(key=lambda c: -c[0])
    _, prefix, suffix, var = candidates[0]
    return (prefix, suffix, var)


def _parse_bracket_quantifiers(
    bracket_content: str,
    ax_name: str,
    known_props: Optional[Set[str]] = None,
) -> List[Tuple[str, Optional[str], Optional[str]]]:
    """
    Parse the content inside [...] in the per-variable quantifier syntax.

    Accepted forms per variable:
      for all x                   → unconstrained plain variable
      for all absent(x)           → x constrained to prop/category 'absent'
      for all x in absent         → x constrained to prop/category 'absent'
      for all pn(x)               → prop-family: n is a numeric wildcard variable
                                    declared earlier as  for all n
                                    (only when 'pn' is not a known declared prop)

    Input example:  "for all n, for all pn(x), for all p0(y)"
    Returns (3-tuples):
        [('n', None, None), ('x', 'pn', 'n'), ('y', 'p0', None)]
                ↑ inner_var   ↑ prop_name   ↑ numeric_var (None = regular prop)
    """
    # Special token [None] → constant/ground axiom with no variables.
    if bracket_content.strip().lower() == 'none':
        return []

    parts = _split_top_level_commas(bracket_content)
    known_p = known_props or set()

    # Pass 1: collect all plain  for all <var>  variable names.
    # Variable names may now be any non-whitespace, non-parenthesis token
    # (e.g. %, *, @, 5 — see _sanitize_var_name for the Python mapping).
    plain_vars: Set[str] = set()
    for part in parts:
        part = part.strip()
        # Plain var: "for all TOKEN" where TOKEN has no spaces/parens
        m = re.match(r'^for\s+all\s+([^\s()]+)$', part)
        if m:
            plain_vars.add(m.group(1))

    # Pass 2: parse each quantifier, detecting prop-family patterns.
    # Order matters: check specific patterns before the catch-all plain-var.
    result: List[Tuple[str, Optional[str], Optional[str]]] = []

    for part in parts:
        part = part.strip()

        # Prop-wrapper / prop-family: "for all PROP(VAR)"
        # Check BEFORE plain-var so that 'for all absent(x)' isn't
        # mistakenly captured by the plain-var pattern.
        m = re.match(r'^for\s+all\s+(\w+)\((\w+)\)$', part)
        if m:
            prop_name = m.group(1)
            inner_var = m.group(2)
            # Is this a prop-family pattern?
            if prop_name not in known_p:
                family = _find_family_var(prop_name, plain_vars)
                if family is not None:
                    # e.g. 'pn' with n in plain_vars → family ('p', '', 'n')
                    result.append((inner_var, prop_name, family[2]))
                    continue
            result.append((inner_var, prop_name, None))
            continue

        # Constrained variable: "for all VAR in CATNAME"
        m = re.match(r'^for\s+all\s+([^\s()]+)\s+in\s+(\w+)$', part)
        if m:
            result.append((m.group(1), m.group(2), None))
            continue

        # Plain variable (any non-whitespace, non-paren token): "for all TOKEN"
        m = re.match(r'^for\s+all\s+([^\s()]+)$', part)
        if m:
            result.append((m.group(1), None, None))
            continue

        raise NewnSyntaxError(
            f"Axiom '{ax_name}': cannot parse quantifier {part!r}. "
            f"Expected 'for all x', 'for all propname(x)', or 'for all x in catname'. "
            f"Variable names may be any symbol (e.g. %, *, @)."
        )

    if not result:
        raise NewnSyntaxError(f"Axiom '{ax_name}': empty quantifier list [].")

    return result


def _split_top_level_commas(s: str) -> List[str]:
    """Split string by commas that are not inside parentheses."""
    parts = []
    depth = 0
    current: List[str] = []
    for ch in s:
        if ch == '(':
            depth += 1
            current.append(ch)
        elif ch == ')':
            depth -= 1
            current.append(ch)
        elif ch == ',' and depth == 0:
            parts.append(''.join(current))
            current = []
        else:
            current.append(ch)
    if current:
        parts.append(''.join(current))
    return parts


def _build_cat_predicate(pred_expr: str, var: str, in_cat: Optional[str], known: Dict) -> str:
    pred_expr = pred_expr.strip()
    props = known.get('props', set())
    cats  = known.get('cats',  set())

    # Apply prop-check transformations: resolves boolean membership and prop-union.
    # Must happen before the single-match shortcut below.
    resolved = _resolve_prop_checks(pred_expr, var, props)

    # Shortcut: entire predicate is a single prop membership check
    # (already transformed to  (var in propname)  by _resolve_prop_checks,
    #  but handle the legacy propname(var) form too for robustness)
    m = re.match(rf'^(\w+)\(({re.escape(var)})\)$', pred_expr)
    if m:
        name = m.group(1)
        if name in props:
            base = f"isinstance(_v, _PropValue) and _v.prop_name == {name!r}"
            if in_cat:
                base += f" and _nn_engine.get_category({in_cat!r}).contains(_v.value)"
            return f"(lambda _v: {base})"

        if name in cats:
            base = f"_nn_engine.get_category({name!r}).contains(_v)"
            if in_cat:
                base += f" and _nn_engine.get_category({in_cat!r}).contains(_v)"
            return f"(lambda _v: {base})"

    # General case: use the resolved (prop-check-transformed) predicate
    if in_cat:
        return (
            f"(lambda {var}: "
            f"_nn_engine.get_category({in_cat!r}).contains({var}) "
            f"and ({resolved}))"
        )
    return f"(lambda {var}: {resolved})"


def _check_var_names(
    variables: List[str],
    known: Dict[str, Set[str]],
    ax_name: str,
    file_label: str,
    lineno: int,
) -> None:
    """
    Raise NewnSyntaxError if any variable name shadows a known op or category.

    Shadowing a PROP is now allowed: a variable named 'x' with a pre-declared
    'prop x: None' simply means you're using x as a dynamic prop name in this
    axiom — the pre-declaration is redundant but harmless.

    Shadowing an OP or CATEGORY is still an error because it would create
    a genuine naming conflict that silently corrupts the axiom's semantics.
    """
    ops  = known.get('ops',  set())
    cats = known.get('cats', set())
    for var in variables:
        if var in ops:
            raise NewnSyntaxError(
                f"{file_label}:{lineno}: axiom '{ax_name}': variable name '{var}' "
                f"shadows the op '{var}'. Choose a different name "
                f"(e.g. '{var}_val' or '{var[0]}')."
            )
        if var in cats:
            raise NewnSyntaxError(
                f"{file_label}:{lineno}: axiom '{ax_name}': variable name '{var}' "
                f"shadows the category '{var}'. Choose a different name."
            )


def _scan_plain_var_prop_uses(expr: str, plain_vars: Set[str],
                               any_depth: bool = False) -> Set[str]:
    """
    Scan *expr* for identifiers that are declared plain variables but appear
    in prop-call position — i.e. NAME( where NAME is in plain_vars.

    e.g. 'x(u) usex x(x)' with plain_vars={'x','u'}  →  {'x'}
         ('u' appears only as a plain variable, not as a prop)

    When *any_depth* is True, the scan is unrestricted — variables used as
    prop-calls at any nesting level are detected.  Use this for RHS expressions
    where nesting can be arbitrarily deep (e.g. z(x(x*y)) → both z and x).

    These variables are being used as *dynamic prop names* (the variable value
    IS the prop name at match time).  They must be added to the families dict
    so that:
      1. The pattern parser creates PropFamilyPat (already handled in patterns.py).
      2. The RHS transformer replaces x(expr) with _nn_auto_prop(str(x))(expr).
    """
    used: Set[str] = set()
    depth = 0
    i = 0
    n = len(expr)
    while i < n:
        ch = expr[i]
        if ch == '(':
            depth += 1
            i += 1
        elif ch == ')':
            depth -= 1
            i += 1
        elif (depth == 0 or any_depth) and (ch.isalpha() or ch == '_'):
            j = i
            while j < n and (expr[j].isalnum() or expr[j] == '_'):
                j += 1
            word = expr[i:j]
            rest = expr[j:].lstrip()
            if rest.startswith('(') and word in plain_vars:
                used.add(word)
            i = j
        else:
            i += 1
    return used


def _scan_auto_props(
    expr: str,
    var_set: Set[str],
    known_props: Set[str],
    known_ops: Optional[Set[str]] = None,
) -> Set[str]:
    """
    Scan *expr* for identifiers used in prop-call position (NAME followed by '(')
    that are NOT declared variables, NOT already known props, and NOT known ops.

    Scans at *all nesting depths* so that deeply-nested constructs like
    ``happy(sad(excited(x)))`` auto-register all three prop names in one pass.

    Returns the set of new prop names to auto-register.

    e.g. 'absent(x) add x' with var_set={'x'}, known_props=set(), known_ops={'add'}
         → {'absent'}

    NOTE: known_ops must be supplied to avoid erroneously auto-registering an
    op name (like 'negate') as a prop when it appears in unary-call position.
    """
    exclude = set(known_props)
    if known_ops:
        exclude |= known_ops
    new_props: Set[str] = set()
    i = 0
    n = len(expr)
    while i < n:
        ch = expr[i]
        if ch.isalpha() or ch == '_':
            j = i
            while j < n and (expr[j].isalnum() or expr[j] == '_'):
                j += 1
            word = expr[i:j]
            rest = expr[j:].lstrip()
            # Prop-call position: NAME immediately followed by '('
            if rest.startswith('(') and word not in var_set and word not in exclude:
                new_props.add(word)
                exclude.add(word)   # register in-place so we don't re-add it
            i = j
        else:
            i += 1
    return new_props


def _find_op_in_lhs_auto(
    lhs: str,
    var_set: Set[str],
    known_props: Set[str],
) -> Optional[str]:
    """
    Scan *lhs* for an identifier in infix (binary op) position that is not a
    variable, prop, or number.  Used when no pre-declared op is found.

    An infix op candidate is a NAME that:
      • appears at the top level (not inside parentheses)
      • is NOT immediately followed by '('  (that would be a unary op call or prop)
      • is NOT a declared variable
      • is NOT a known prop
      • is NOT a pure number

    Returns the longest such candidate, or None.

    NOTE: unary ops (like 'negate(x)') cannot be auto-detected this way — the
    user still needs to declare them with 'op negate: None'.
    """
    candidates: List[str] = []
    depth = 0
    i = 0
    n = len(lhs)
    while i < n:
        ch = lhs[i]
        if ch == '(':
            depth += 1
            i += 1
        elif ch == ')':
            depth -= 1
            i += 1
        elif depth == 0 and (ch.isalpha() or ch == '_'):
            j = i
            while j < n and (lhs[j].isalnum() or lhs[j] == '_'):
                j += 1
            word = lhs[i:j]
            rest = lhs[j:].lstrip()
            if (not rest.startswith('(')
                    and word not in var_set
                    and word not in known_props
                    and not word.isdigit()):
                candidates.append(word)
            i = j
        else:
            i += 1
    if not candidates:
        return None
    return max(candidates, key=len)


def _wrap_dict_literals(line: str) -> str:
    """
    If *line* is a simple Python assignment whose RHS is a plain dict literal,
    wrap the dict with ``_nn_vdict(...)`` so that VisualDict semantics apply
    when the dict is indexed with a Newn op result (PropValue).

    Examples::
        d = {1: "a", 2: "b"}          →  d = _nn_vdict({1: "a", 2: "b"})
        x = {k: v for k, v in items}  →  unchanged  (dict comprehension)
        s = {1, 2, 3}                  →  unchanged  (set literal)
    """
    code = line.strip()
    if not code or code.startswith('#'):
        return line

    try:
        tree = ast.parse(code, mode='exec')
    except SyntaxError:
        return line

    if (len(tree.body) != 1
            or not isinstance(tree.body[0], ast.Assign)
            or not isinstance(tree.body[0].value, ast.Dict)):
        return line

    eq_pos = _find_top_eq(code)
    if eq_pos < 0:
        return line

    indent = line[: len(line) - len(line.lstrip())]
    lhs    = code[:eq_pos].strip()
    rhs    = code[eq_pos + 1:].strip()
    return f"{indent}{lhs} = _nn_vdict({rhs})"


# ─────────────────────────────────────────────────────────────────────────────
# Recursive helpers for arbitrary-depth prop-call pattern parsing
# ─────────────────────────────────────────────────────────────────────────────

def _parse_prop_call_tree(
    pat: str,
    var_names: List[str],
    props: set,
    _bound: Optional[set] = None,
) -> Optional[tuple]:
    """
    Recursively parse a prop-call pattern into a tree.

    Recognised forms::

        single_word           → ('leaf', name, is_var)
        WORD(inner_pattern)   → ('call', prop, prop_is_var, prop_in_props, inner_tree)

    *inner_pattern* may itself be a prop call (any depth) or an expression leaf
    (e.g. ``x*y``).  An unrecognised inner expression is stored as::

        ('expr_leaf', expr_str, bind_var_or_None)

    where *bind_var_or_None* is the first yet-unbound declared variable.

    Returns ``None`` when the pattern cannot be parsed as a prop-call tree.
    """
    if _bound is None:
        _bound = set()
    pat = pat.strip()

    # ── Leaf: single identifier ───────────────────────────────────────────
    if re.match(r'^\w+$', pat):
        is_var = pat in var_names
        return ('leaf', pat, is_var)

    # ── Prop call: WORD(inner_pat) ────────────────────────────────────────
    m = re.match(r'^(\w+)\s*\((.+)\)$', pat)
    if not m:
        return None

    prop      = m.group(1)
    inner_pat = m.group(2).strip()

    # Verify inner_pat has balanced parentheses (guards against greedy over-match)
    depth = 0
    for ch in inner_pat:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if depth < 0:
            return None
    if depth != 0:
        return None

    prop_is_var   = prop in var_names
    prop_in_props = prop in props
    new_bound     = _bound | {prop} if prop_is_var else _bound

    inner = _parse_prop_call_tree(inner_pat, var_names, props, new_bound)
    if inner is None:
        # Expression leaf (e.g. 'x*y') — bind the first unaccounted-for var
        unbound   = [v for v in var_names if v not in new_bound]
        bind_var  = unbound[0] if unbound else None
        inner     = ('expr_leaf', inner_pat, bind_var)

    return ('call', prop, prop_is_var, prop_in_props, inner)


def _tree_depth(tree: Optional[tuple]) -> int:
    """Return the nesting depth of a parsed prop-call tree (0 for leaves)."""
    if tree is None or tree[0] in ('leaf', 'expr_leaf'):
        return 0
    return 1 + _tree_depth(tree[4])


def _tree_matcher_cond(tree: Optional[tuple], access: str = '_bt_v') -> str:
    """Build the condition string for a matcher lambda from the tree."""
    if tree is None or tree[0] in ('leaf', 'expr_leaf'):
        return 'True'
    _, prop, prop_is_var, prop_in_props, inner = tree
    conds = [f'isinstance({access}, _PropValue)']
    if not prop_is_var and prop_in_props:
        conds.append(f'{access}.prop_name == {prop!r}')
    inner_cond = _tree_matcher_cond(inner, f'{access}.value')
    if inner_cond != 'True':
        conds.append(inner_cond)
    return ' and '.join(conds)


def _tree_binder_pairs(
    tree: Optional[tuple],
    access: str = '_bt_v',
) -> List[Tuple[str, str]]:
    """Return ``[(var_name, access_expr), ...]`` pairs for a binder dict."""
    if tree is None:
        return []
    kind = tree[0]
    if kind == 'leaf':
        _, name, is_var = tree
        return [(name, access)] if is_var else []
    if kind == 'expr_leaf':
        _, _expr, bind_var = tree
        return [(bind_var, access)] if bind_var else []
    # 'call'
    _, prop, prop_is_var, _prop_in_props, inner = tree
    pairs: List[Tuple[str, str]] = []
    if prop_is_var:
        pairs.append((prop, f'{access}.prop_name'))
    pairs.extend(_tree_binder_pairs(inner, f'{access}.value'))
    return pairs


# ─────────────────────────────────────────────────────────────────────────────


def _generate_backtrack_code(
    var_name: str,
    var_names: List[str],
    pattern: str,
    known: dict,
    indent: str,
) -> str:
    """
    Generate the ``_nn_engine.backtrack_pattern(...)`` call for the
    backtracking syntax::

        result = {[for all x, for all y], x(y)}

    Analyses *pattern* and produces appropriate matcher/binder lambdas:

    - Single variable               ``z``              → matches any value
    - Prop call (any depth/mix)     ``x(y)``,          → depth-aware PropValue check
                                    ``myp(x)``,        (static and variable props at
                                    ``a(b(c(d)))``,    any nesting depth)
                                    ``hot(warm(x))``
    - Infix op pattern              ``x add y``        → UnresolvedExpr with that op
    - Fallback                      (other)            → matches any value
    """
    props = known.get('props', set())
    ops   = known.get('ops',   set())
    pat   = pattern.strip()
    tab   = indent + '    '

    # ── Case 1: Single variable ──────────────────────────────────────────
    if pat in var_names:
        matcher = "lambda _bt_v: True"
        binder  = f"lambda _bt_v: {{{pat!r}: _bt_v}}"
        return (
            f"{indent}{var_name} = _nn_engine.backtrack_pattern(\n"
            f"{tab}{var_names!r},\n"
            f"{tab}{matcher},\n"
            f"{tab}{binder},\n"
            f"{tab}op_filter=None,\n"
            f"{indent})"
        )

    # ── Case 2: Prop-call at any depth ───────────────────────────────────
    # Handles depth-1 ``x(y)``, depth-2 ``z(x(y))``, depth-3+ ``a(b(c(d)))``,
    # mixed static/variable ``hot(warm(x))``, expression leaves ``z(x(x*y))``,
    # etc.  Replaces the old separate Case 2 (depth-1) and Case 4 (depth-2).
    tree = _parse_prop_call_tree(pat, var_names, props)
    if tree is not None and tree[0] == 'call':
        depth         = _tree_depth(tree)
        outer_is_var  = tree[2]   # prop_is_var field of top-level 'call'
        cond          = _tree_matcher_cond(tree)
        pairs         = _tree_binder_pairs(tree)
        binder_body   = ', '.join(f'{k!r}: {v}' for k, v in pairs)
        binder        = f"lambda _bt_v: {{{binder_body}}}"
        prop_vary_str = "True" if outer_is_var else "False"
        return (
            f"{indent}{var_name} = _nn_engine.backtrack_pattern(\n"
            f"{tab}{var_names!r},\n"
            f"{tab}lambda _bt_v: {cond},\n"
            f"{tab}{binder},\n"
            f"{tab}op_filter=None,\n"
            f"{tab}prop_name_must_vary={prop_vary_str},\n"
            f"{tab}max_probe_depth={depth},\n"
            f"{indent})"
        )

    # ── Case 3: VAR1 op VAR2  — infix op pattern ────────────────────────
    for op in sorted(ops, key=len, reverse=True):
        m3 = re.match(
            rf'^(\w+)\s+{re.escape(op)}\s+(\w+)$', pat
        )
        if m3:
            left_part  = m3.group(1)
            right_part = m3.group(2)
            left_is_var  = left_part  in var_names
            right_is_var = right_part in var_names
            matcher = (
                f"lambda _bt_v: isinstance(_bt_v, _nn_UnresolvedExpr)"
                f" and _bt_v.op_name == {op!r}"
            )
            binder_pairs: List[str] = []
            if left_is_var:
                binder_pairs.append(f"{left_part!r}: _bt_v.args[0]")
            if right_is_var:
                binder_pairs.append(f"{right_part!r}: _bt_v.args[1]")
            binder = "lambda _bt_v: {" + ", ".join(binder_pairs) + "}"
            return (
                f"{indent}{var_name} = _nn_engine.backtrack_pattern(\n"
                f"{tab}{var_names!r},\n"
                f"{tab}{matcher},\n"
                f"{tab}{binder},\n"
                f"{tab}op_filter={op!r},\n"
                f"{indent})"
            )

    # ── Fallback: collect all concrete values from all ops ───────────────
    return (
        f"{indent}{var_name} = _nn_engine.backtrack_pattern(\n"
        f"{tab}{var_names!r},\n"
        f"{tab}lambda _bt_v: True,\n"
        f"{tab}lambda _bt_v: {{}},\n"
        f"{tab}op_filter=None,\n"
        f"{indent})"
    )


def _find_top_eq(s: str) -> int:
    """
    Find the index of a lone '=' not inside parentheses and not part of
    ==, !=, <=, >=.
    """
    depth = 0
    i = 0
    while i < len(s):
        ch = s[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif ch == '=' and depth == 0:
            # Reject ==, !=, <=, >=
            prev = s[i - 1] if i > 0 else ''
            nxt  = s[i + 1] if i + 1 < len(s) else ''
            if prev not in ('!', '<', '>', '=') and nxt != '=':
                return i
        i += 1
    return -1


def _find_op_in_lhs(lhs: str, ops: Set[str]) -> Optional[str]:
    """Find which registered op name appears as a whole word in lhs."""
    for op_name in sorted(ops, key=len, reverse=True):
        if re.search(rf'(?<!\w){re.escape(op_name)}(?!\w)', lhs):
            return op_name
    return None


def _split_lhs(lhs: str, op_name: str):
    """Split LHS string around op_name into (left_str, right_str)."""
    pat = re.compile(rf'(?<!\w){re.escape(op_name)}(?!\w)')
    parts = pat.split(lhs, 1)
    left  = parts[0].strip()
    right = parts[1].strip() if len(parts) > 1 else ''
    return left, right


_STRING_LITERAL_RE = re.compile(
    r'("""[\s\S]*?"""|\'\'\'[\s\S]*?\'\'\'|"[^"\\]*(?:\\.[^"\\]*)*"|\'[^\'\\]*(?:\\.[^\'\\]*)*\')'
)


def _transform_numeric_prop_calls(line: str) -> str:
    """
    Rewrite ``N(expr)`` (integer literal used as a prop call) into
    ``_nn_engine.auto_prop('N')(expr)``.

    This lets users write e.g. ``5(7) forever 5(9)`` in plain .nn lines,
    meaning "prop named '5' wrapping 7" and "prop named '5' wrapping 9".

    The pattern only matches a bare integer literal immediately followed by
    '(' so that Python constructs like ``range(5)`` or ``abs(-3)`` are
    unaffected.

    The transform is applied once so it also covers cases like
    ``a = 3(4) combine 3(5)`` on a single line.
    """
    # Match an integer not preceded by a letter/digit/dot (to exclude things
    # like 'p3(' → that's an identifier, not a bare number) and not followed
    # by a dot (to exclude 3.14 ← shouldn't match '3(').
    return re.sub(
        r'(?<![.\w])(\d+)\s*\(',
        lambda m: f"_nn_engine.auto_prop({m.group(1)!r})(",
        line,
    )


def _transform_arg_access(rhs_code: str) -> str:
    """
    Rewrite 1-based numeric field access on UnresolvedExpr arguments.

    Syntax: ``varname.N``  (N is a positive integer)
    is transformed to: ``varname.args[N-1]``

    This lets axiom RHS expressions unpack the two parts of an
    UnresolvedExpr without needing to call Python directly::

        axiom newtruth: [for all x in unresolved, for all y], x newadd y = x.1 add (x.2 + y)
        # x is UnresolvedExpr('add', (absent(5), 7))
        # x.1  →  absent(5)   (x.args[0])
        # x.2  →  7           (x.args[1])

    Only matches identifiers that start with a letter or underscore so that
    plain numeric literals like ``3.14`` are not touched.
    """
    return re.sub(
        r'\b([a-zA-Z_]\w*)\.([1-9][0-9]*)\b',
        lambda m: f'{m.group(1)}.args[{int(m.group(2)) - 1}]',
        rhs_code,
    )


def _transform_ops(line: str, ops: Set[str],
                   template_patterns: Optional[List[Tuple[str, str]]] = None) -> str:
    """
    Replace infix op usage:  A opname B  →  A |opname| B

    Skips:
      - String literals (op names inside strings are left untouched)
      - Direct function call form  opname(  (no space before paren)

    template_patterns: list of (prefix, suffix) from registered template axioms.
      Any identifier in the line that matches prefix + <digits> + suffix is
      treated as a registered op and piped accordingly (e.g. 'foreve7' for
      template ('foreve', '')).
    """
    # Expand ops with any concrete template instances visible in the line.
    effective_ops: Set[str] = set(ops)
    # Map template-matched op names → their register_op(...) expression so they
    # resolve correctly at runtime without a separate assignment line.
    template_inline: Dict[str, str] = {}
    if template_patterns:
        for ident in re.findall(r'\b[a-zA-Z_]\w*\b', line):
            if ident in effective_ops or ident in template_inline:
                continue
            for prefix, suffix in template_patterns:
                if not ident.startswith(prefix):
                    continue
                rest = ident[len(prefix):]
                if suffix:
                    if not rest.endswith(suffix):
                        continue
                    mid = rest[: -len(suffix)]
                else:
                    mid = rest
                if mid and mid.isdigit():
                    effective_ops.add(ident)
                    template_inline[ident] = f"_nn_engine.register_op({ident!r})"
                    break

    parts = _STRING_LITERAL_RE.split(line)
    out = []
    for i, part in enumerate(parts):
        if i % 2 == 1:
            out.append(part)
        else:
            for op_name in sorted(effective_ops, key=len, reverse=True):
                part = re.sub(
                    # Transform  A op B  to  A |op| B.
                    # Skip if:
                    #   - already surrounded by |  (already transformed)
                    #   - followed by (  → direct call form, __call__ handles it
                    #   - followed by whitespace then , or )  → passed as an argument
                    #     e.g. fold(add, values) — add is a value here, not an infix op
                    rf'(?<!\|)(?<!\w){re.escape(op_name)}(?!\w)(?!\|)(?!\()(?!\s*[,\)])',
                    f'|{op_name}|',
                    part,
                )
            # For template-matched ops (e.g. foreve7), replace the now-piped
            # name with an inline register_op(...) call so the name resolves at
            # runtime without needing a separate assignment line.
            # e.g.  |foreve7|  →  |_nn_engine.register_op('foreve7')|
            for tmpl_name, tmpl_expr in template_inline.items():
                part = part.replace(f'|{tmpl_name}|', f'|{tmpl_expr}|')
            # Transform component access notation:  x.1 → x.args[0],  x.2 → x.args[1], etc.
            # Only matches identifiers starting with a letter/underscore (avoids float literals
            # like 3.14).  x.N is not valid Python otherwise, so this transform is always safe.
            part = re.sub(
                r'\b([a-zA-Z_]\w*)\.([1-9]\d*)\b',
                lambda m: f'{m.group(1)}.args[{int(m.group(2)) - 1}]',
                part,
            )
            out.append(part)
    return ''.join(out)
