"""
Export a Newn domain to external formats for interoperability.

Supported targets:
  - Prolog  (.pl)   — classical logic programs; each axiom becomes a Horn clause
  - Z3      (.py)   — Z3 Python API; axioms become ForAll constraints
  - PDDL    (.pddl) — Planning Domain Definition Language; ops become actions
  - Python  (.py)   — clean Python module wrapping every op as a regular function

Usage::

    from newn.preprocessor import nn_exec
    from newn.export import export_prolog, export_z3, export_pddl, export_python

    ns = nn_exec('''
        prop absent: None
        op add: None
        axiom plain: for all x, for all y, x add y = x + y
        axiom absent_add: [for all x, for all absent(y)], x add absent(y) = absent(x + y)
    ''')
    export_prolog('domain.pl')
    export_z3('domain_z3.py')
    export_pddl('domain.pddl')
    export_python('domain_api.py')
"""
from __future__ import annotations
import os
import re
import textwrap
from typing import Any, List, Optional, Tuple

from .patterns import (
    Pattern, VarPat, PropPat, LitPat, BinPat, NegPat
)


# ---------------------------------------------------------------------------
# Shared variable-capitalisation helper (Prolog needs uppercase vars)
# ---------------------------------------------------------------------------

# Python builtins that should NOT be capitalised when converting to Prolog
_PY_BUILTINS = frozenset({
    'abs', 'all', 'any', 'bin', 'bool', 'chr', 'dict', 'dir', 'divmod',
    'enumerate', 'filter', 'float', 'format', 'frozenset', 'getattr',
    'hasattr', 'hash', 'hex', 'id', 'input', 'int', 'isinstance',
    'issubclass', 'iter', 'len', 'list', 'map', 'max', 'min', 'next',
    'object', 'oct', 'open', 'ord', 'pow', 'print', 'property', 'range',
    'repr', 'reversed', 'round', 'set', 'setattr', 'slice', 'sorted',
    'staticmethod', 'str', 'sum', 'super', 'tuple', 'type', 'vars', 'zip',
    'None', 'True', 'False', 'not', 'and', 'or', 'in', 'is',
})


def _cap_var(name: str) -> str:
    """Capitalise a single identifier for Prolog (skip builtins, numbers, _Tmp vars)."""
    if not name or name[0].isupper() or name[0] == '_':
        return name
    if name in _PY_BUILTINS:
        return name
    return name[0].upper() + name[1:]


def _cap_vars_in_expr(expr: str, skip_names: frozenset) -> str:
    """Capitalise all lowercase Prolog variable identifiers in an expression string."""
    def _replace(m: re.Match) -> str:
        word = m.group(0)
        if word in skip_names or word in _PY_BUILTINS:
            return word
        if word[0].islower():
            return word[0].upper() + word[1:]
        return word
    return re.sub(r'\b[a-zA-Z_]\w*\b', _replace, expr)


# ---------------------------------------------------------------------------
# Pattern → string helpers
# ---------------------------------------------------------------------------

def _pat_to_prolog(pat: Optional[Pattern], default: str = '_') -> str:
    """Convert a pattern to a Prolog term string."""
    if pat is None:
        return default
    if isinstance(pat, VarPat):
        return _cap_var(pat.name)
    if isinstance(pat, PropPat):
        inner = _pat_to_prolog(pat.inner, default)
        return f"{pat.prop_name}({inner})"
    if isinstance(pat, LitPat):
        return repr(pat.value)
    if isinstance(pat, NegPat):
        inner = _pat_to_prolog(pat.inner, default)
        return f"(-{inner})"
    if isinstance(pat, BinPat):
        l = _pat_to_prolog(pat.left, default)
        r = _pat_to_prolog(pat.right, default)
        return f"({l} {pat.op} {r})"
    return default


def _pat_to_z3(pat: Optional[Pattern], default: str = '_x') -> str:
    """Convert a pattern to a Z3 expression string (Python syntax)."""
    if pat is None:
        return default
    if isinstance(pat, VarPat):
        return pat.name
    if isinstance(pat, PropPat):
        inner = _pat_to_z3(pat.inner, default)
        return f"{pat.prop_name}_fn({inner})"
    if isinstance(pat, LitPat):
        return repr(pat.value)
    if isinstance(pat, NegPat):
        inner = _pat_to_z3(pat.inner, default)
        return f"(-{inner})"
    if isinstance(pat, BinPat):
        l = _pat_to_z3(pat.left, default)
        r = _pat_to_z3(pat.right, default)
        return f"({l} {pat.op} {r})"
    return default


# ---------------------------------------------------------------------------
# RHS code conversion helpers
# ---------------------------------------------------------------------------

def _rhs_to_prolog(
    rhs_code: str,
    op_names: frozenset,
    prop_names: frozenset,
) -> Tuple[List[str], str]:
    """
    Convert a Newn Python RHS expression to Prolog.

    Returns ``(body_goals, result_unification)`` where:
    - *body_goals*         : extra Prolog goals (list of strings) to add to the clause body
    - *result_unification* : the ``Result is …`` or ``Result = …`` goal that closes the clause

    Handles:
    - ``left |op| right``  → ``op(Left, Right, _Tmp0)`` Prolog goals  (chained too)
    - Prop calls            → ``Result = prop(Expr)``  (unification, not 'is')
    - Plain arithmetic      → ``Result is Expr``
    """
    code = rhs_code.strip()
    all_skip = frozenset(op_names | prop_names)

    # Split the expression on all |op| boundaries to get a flat token list:
    #   "x |add| absent(y) |sub| z"  →  ['x ', 'add', ' absent(y) ', 'sub', ' z']
    parts = re.split(r'\|(\w+)\|', code)

    if len(parts) == 1:
        # No |op| found — pure Python expression
        code_pl = _cap_vars_in_expr(code, all_skip)
        if any(re.search(rf'\b{re.escape(p)}\b', code) for p in prop_names):
            return [], f'Result = {code_pl}'
        return [], f'Result is {code_pl}'

    # Build a left-associative goal chain from the token list
    # parts = [expr0, op1, expr1, op2, expr2, ...]
    expressions = parts[::2]   # ['x ', ' absent(y) ', ' z']
    ops         = parts[1::2]  # ['add', 'sub']

    body_goals: List[str] = []
    prev_tmp = None

    for i, (op_raw, right_expr) in enumerate(zip(ops, expressions[1:])):
        tmp_var   = f'_Tmp{i}'
        left_expr = expressions[0].strip() if i == 0 else prev_tmp
        left_pl   = _cap_vars_in_expr(left_expr,       all_skip)
        right_pl  = _cap_vars_in_expr(right_expr.strip(), all_skip)
        body_goals.append(f'{op_raw}({left_pl}, {right_pl}, {tmp_var})')
        prev_tmp  = tmp_var

    return body_goals, f'Result = {prev_tmp}'


def _rhs_to_z3(rhs_code: str, op_names: frozenset, prop_names: frozenset) -> str:
    """
    Convert a Newn Python RHS expression to a Z3-compatible Python expression.

    Transforms:
    - ``left |op| right``  → ``op_fn(left, right)``   (chained too)
    - ``prop(expr)``        → ``prop_fn(expr)``  (since prop_fn is declared as a Z3 Function)
    """
    code = rhs_code.strip()

    # Split on all |op| boundaries and rebuild as nested function calls (left-assoc)
    parts = re.split(r'\|(\w+)\|', code)

    if len(parts) > 1:
        expressions = parts[::2]   # operands
        ops         = parts[1::2]  # operator names
        # Start from leftmost operand and fold left
        result = expressions[0].strip()
        for op_raw, right_expr in zip(ops, expressions[1:]):
            right = right_expr.strip()
            if op_raw in op_names:
                result = f'{op_raw}_fn({result}, {right})'
            else:
                result = f'{result} |{op_raw}| {right}'
        code = result

    # Replace prop(expr) with prop_fn(expr)
    for prop in sorted(prop_names, key=len, reverse=True):
        code = re.sub(
            rf'\b{re.escape(prop)}\s*\(',
            f'{prop}_fn(',
            code,
        )

    return code


def _collect_vars(axiom) -> List[str]:
    """Collect all variable names declared in an axiom."""
    return list(axiom.variables)


# ---------------------------------------------------------------------------
# Prolog export
# ---------------------------------------------------------------------------

_PROLOG_HEADER = """\
/*
 * Prolog export generated by Newn.
 *
 * Each op becomes a predicate: op(Left, Right, Result).
 * Unary ops use: op(Arg, Result).
 * Each axiom becomes one Horn clause.
 *
 * Load in SWI-Prolog:
 *   ?- consult('domain.pl').
 *   ?- add(3, 4, R).
 */
:- use_module(library(lists)).
"""


def _axiom_to_prolog(axiom, op_names: frozenset, prop_names: frozenset) -> str:
    """Convert one Axiom to a Prolog clause string."""
    op = axiom.op_name

    left_term  = _pat_to_prolog(axiom.left_pat,  'L') if axiom.left_pat  else None
    right_term = _pat_to_prolog(axiom.right_pat, 'R') if axiom.right_pat else None

    head_args = [t for t in [left_term, right_term] if t is not None]
    head_args.append('Result')
    head = f"{op}({', '.join(head_args)})"

    # Convert RHS
    extra_goals, result_unif = _rhs_to_prolog(axiom.rhs_code, op_names, prop_names)

    # Category membership checks
    cat_goals: List[str] = []
    if axiom.category is not None:
        cat_name = axiom.category.name
        for var in _collect_vars(axiom):
            cat_goals.append(f"{cat_name}({_cap_var(var)})")

    body_parts = cat_goals + extra_goals + [result_unif]
    body = ',\n    '.join(body_parts)

    comment = f"% axiom '{axiom.name}': {axiom.source_line.strip()}"
    if body:
        return f"{comment}\n{head} :-\n    {body}."
    return f"{comment}\n{head}."


def export_prolog(filepath: str, engine=None) -> str:
    """
    Export all registered Newn axioms to a Prolog .pl file.

    Args:
        filepath : destination file path (e.g. 'domain.pl')
        engine   : optional engine object; uses global _ENGINE if None

    Returns the generated Prolog source as a string (and writes the file).
    """
    if engine is None:
        from .core import _ENGINE as engine

    sections: List[str] = [_PROLOG_HEADER]

    op_names   = frozenset(engine.op_names())
    prop_names = frozenset(engine.prop_names())

    # Declare dynamic predicates
    for op_name in sorted(op_names):
        axioms = engine._axioms.get(op_name, [])
        arity  = 1  # at least Result
        for ax in axioms:
            a = (1 if ax.left_pat is not None else 0) + \
                (1 if ax.right_pat is not None else 0)
            arity = max(arity, a + 1)  # +1 for Result
        sections.append(f":- dynamic {op_name}/{arity}.")
    sections.append('')

    # Prop facts (declared as type-check predicates)
    if prop_names:
        sections.append("% ===== props (type checks) =====\n")
        for prop_name in sorted(prop_names):
            sections.append(f"% {prop_name}(Value) — true when Value is a {prop_name}-wrapped term")
            sections.append(f"{prop_name}({prop_name}(_)).")
            sections.append('')

    # Export bind facts: Newn → external display value
    if engine._bindings:
        sections.append("% ===== bind_display (Newn → external)  translate_out =====\n")
        for (prop_name, inner_val), display_val in sorted(
            engine._bindings.items(), key=lambda kv: (kv[0][0], str(kv[0][1]))
        ):
            # If the prop value itself has an export bind, use the bound display value
            sections.append(
                f"bind_display({prop_name}({inner_val!r}), {display_val!r})."
            )
        sections.append('')

    # Import bind facts: external → Newn  (translate_in)
    if engine._import_bindings:
        sections.append("% ===== bind_import (external → Newn)  translate_in =====\n")
        for ext_val, newn_val in sorted(
            engine._import_bindings.items(), key=lambda kv: str(kv[0])
        ):
            sections.append(
                f"bind_import({ext_val!r}, {newn_val!r})."
            )
        sections.append('')

    # Axioms, one section per op
    for op_name in sorted(op_names):
        axioms = engine._axioms.get(op_name, [])
        if not axioms:
            continue
        sections.append(f"% ===== op: {op_name} =====\n")
        for axiom in axioms:
            sections.append(_axiom_to_prolog(axiom, op_names, prop_names))
            sections.append('')

    source = '\n'.join(sections)

    with open(filepath, 'w') as f:
        f.write(source)

    return source


# ---------------------------------------------------------------------------
# Z3 export
# ---------------------------------------------------------------------------

_Z3_HEADER = '''\
"""
Z3 export generated by Newn.

Each op is declared as a Z3 Function; each axiom adds a ForAll constraint.
Prop checks are declared as Bool-returning Z3 Functions.

Usage::
    python {filename}
    # prints sat/unsat and a model if satisfiable
"""
from z3 import (
    Solver, Function, ForAll, IntSort, BoolSort, sat,
    Ints, Int, If, And, Or, Not,
)

s = Solver()
'''


def _axiom_to_z3(axiom, op_names: frozenset, prop_names: frozenset) -> str:
    """Convert one Axiom to Z3 Python constraint code."""
    vars_ = _collect_vars(axiom)
    lines: List[str] = []

    comment = f"    # axiom '{axiom.name}': {axiom.source_line.strip()}"
    lines.append(comment)

    # Declare symbolic Z3 Int variables for each Newn variable
    if vars_:
        var_decls = ', '.join(f"'{v}'" for v in vars_)
        lines.append(f"    {', '.join(vars_)} = Ints({var_decls})")

    # Build LHS call
    op = axiom.op_name
    left_z3  = _pat_to_z3(axiom.left_pat,  'l') if axiom.left_pat  else None
    right_z3 = _pat_to_z3(axiom.right_pat, 'r') if axiom.right_pat else None
    lhs_args = [t for t in [left_z3, right_z3] if t is not None]
    lhs = f"{op}_fn({', '.join(lhs_args)})"

    # Convert RHS
    rhs_z3 = _rhs_to_z3(axiom.rhs_code, op_names, prop_names)

    # Build constraint  ForAll([vars], lhs == rhs)
    if vars_:
        z3_vars = '[' + ', '.join(vars_) + ']'
        constraint = f"ForAll({z3_vars}, {lhs} == {rhs_z3})"
    else:
        constraint = f"{lhs} == {rhs_z3}"

    lines.append(f"    s.add({constraint})")
    return '\n'.join(lines)


def export_z3(filepath: str, engine=None) -> str:
    """
    Export all registered Newn axioms to a Z3 Python (.py) file.

    Args:
        filepath : destination file path (e.g. 'domain_z3.py')
        engine   : optional engine object; uses global _ENGINE if None

    Returns the generated Z3 source as a string (and writes the file).
    """
    if engine is None:
        from .core import _ENGINE as engine

    filename = os.path.basename(filepath)
    sections: List[str] = [_Z3_HEADER.format(filename=filename)]

    op_names   = frozenset(engine.op_names())
    prop_names = frozenset(engine.prop_names())

    # Declare Z3 Function objects for ops
    for op_name in sorted(op_names):
        axioms = engine._axioms.get(op_name, [])
        arity  = 1  # at least one arg + result
        for ax in axioms:
            a = (1 if ax.left_pat is not None else 0) + \
                (1 if ax.right_pat is not None else 0)
            arity = max(arity, a)
        # arity input args + 1 output → total arity+1 sorts
        sorts = ', '.join(['IntSort()'] * (arity + 1))
        sections.append(f"{op_name}_fn = Function('{op_name}', {sorts})")

    if op_names:
        sections.append('')

    # Props as Z3 Functions (unary Bool predicates)
    for prop_name in sorted(prop_names):
        sections.append(
            f"{prop_name}_fn = Function('{prop_name}', IntSort(), BoolSort())"
        )

    if prop_names:
        sections.append('')

    # Export bind: Newn → external display value  (translate_out)
    if engine._bindings:
        sections.append("# ===== bind_display (Newn → external)  translate_out =====")
        for (prop_name, inner_val), display_val in sorted(
            engine._bindings.items(), key=lambda kv: (kv[0][0], str(kv[0][1]))
        ):
            if isinstance(inner_val, (int, float)) and isinstance(display_val, (int, float)):
                sections.append(
                    f"s.add({prop_name}_fn({inner_val!r}) == {int(display_val)!r})"
                )
        sections.append('')

    # Import bind: external → Newn  (translate_in) — stored as a comment dict
    if engine._import_bindings:
        sections.append("# ===== bind_import (external → Newn)  translate_in =====")
        sections.append("# Lookup: external_val → Newn representation")
        sections.append("_IMPORT_BIND = {")
        for ext_val, newn_val in sorted(
            engine._import_bindings.items(), key=lambda kv: str(kv[0])
        ):
            sections.append(f"    {ext_val!r}: {newn_val!r},")
        sections.append("}")
        sections.append('')

    # Axioms
    for op_name in sorted(op_names):
        axioms = engine._axioms.get(op_name, [])
        if not axioms:
            continue
        sections.append(f"# ===== op: {op_name} =====")
        for axiom in axioms:
            sections.append("if True:")
            sections.append(_axiom_to_z3(axiom, op_names, prop_names))
            sections.append('')

    sections.append('result = s.check()')
    sections.append('print("Z3 result:", result)')
    sections.append('if result == sat:')
    sections.append('    print("Model:", s.model())')

    source = '\n'.join(sections)

    with open(filepath, 'w') as f:
        f.write(source)

    return source


# ---------------------------------------------------------------------------
# PDDL export
# ---------------------------------------------------------------------------

_PDDL_DOMAIN_TEMPLATE = """\
; PDDL domain generated by Newn.
; Each Newn op is represented as an action that transforms 'value' objects.
; Load with a PDDL planner (e.g. Fast Downward).

(define (domain {domain_name})
  (:requirements :strips :typing :numeric-fluents)

  (:types value)

  (:predicates
{predicates}
  )

  (:functions
    (numeric-value ?v - value)
  )

{actions}
)
"""


def _axiom_to_pddl_action(axiom) -> str:
    """Convert one axiom to a PDDL action block."""
    op    = axiom.op_name
    name  = f"{op}_{axiom.name}"
    vars_ = _collect_vars(axiom)

    param_parts = [f"?{v} - value" for v in vars_]
    if axiom.left_pat is not None:
        param_parts.append("?left - value")
    if axiom.right_pat is not None:
        param_parts.append("?right - value")
    param_parts.append("?result - value")
    params = ' '.join(param_parts)

    # Build numeric-value preconditions where we can infer them from LHS patterns
    preconds = []
    if axiom.left_pat is not None and isinstance(axiom.left_pat, VarPat):
        preconds.append(f"(>= (numeric-value ?left) 0)")
    if not preconds:
        preconds = ['(and)']

    precond = f"(and {' '.join(preconds)})" if len(preconds) > 1 else preconds[0]

    # Best-effort effect from rhs_code (arithmetic only)
    rhs = axiom.rhs_code.strip()
    if re.match(r'^[\w\s\+\-\*\/\(\)\.]+$', rhs) and '|' not in rhs:
        effect = f"(assign (numeric-value ?result) 0)  ; RHS: {rhs}"
    else:
        effect = f"(assign (numeric-value ?result) 0)  ; complex RHS"

    return textwrap.dedent(f"""\
  (:action {name}
   :parameters ({params})
   :precondition {precond}
   :effect {effect}
  )""")


def export_pddl(filepath: str, domain_name: str = 'newn_domain', engine=None) -> str:
    """
    Export all registered Newn axioms to a PDDL domain file.

    Note: PDDL is best suited for planning problems.  This export gives a
    structural skeleton that can be refined for specific planning tasks.

    Args:
        filepath    : destination file path (e.g. 'domain.pddl')
        domain_name : PDDL domain name (default 'newn_domain')
        engine      : optional engine object; uses global _ENGINE if None

    Returns the generated PDDL source as a string (and writes the file).
    """
    if engine is None:
        from .core import _ENGINE as engine

    op_names   = frozenset(engine.op_names())
    prop_names = frozenset(engine.prop_names())

    pred_lines = [f"    ({prop_name} ?v - value)" for prop_name in sorted(prop_names)]
    predicates = '\n'.join(pred_lines) if pred_lines else '    ; (no props defined)'

    action_blocks = []
    for op_name in sorted(op_names):
        for axiom in engine._axioms.get(op_name, []):
            action_blocks.append(_axiom_to_pddl_action(axiom))

    actions = '\n\n'.join(action_blocks) if action_blocks else '  ; (no axioms defined)'

    source = _PDDL_DOMAIN_TEMPLATE.format(
        domain_name=domain_name,
        predicates=predicates,
        actions=actions,
    )

    with open(filepath, 'w') as f:
        f.write(source)

    return source


# ---------------------------------------------------------------------------
# Python export  (new)
# ---------------------------------------------------------------------------

_PYTHON_HEADER = '''\
"""
Python API module generated by Newn.

Import this file to call Newn-defined ops as plain Python functions.
The embedded domain source is re-initialised on first import.

Usage::
    from {module_name} import {example_ops}
    print({first_op_example})
"""
from newn.core import PropValue
from newn.preprocessor import nn_exec as _nn_exec

# ── Embedded domain source ────────────────────────────────────────────────
_NN_SOURCE = {nn_source_repr}

# Initialise the Newn engine with the embedded domain.
_nn_exec(_NN_SOURCE)

from newn.core import _ENGINE as _nn_engine

# ── Prop factories ────────────────────────────────────────────────────────
# Call these to create typed values:  absent(5)  →  PropValue('absent', 5)
{prop_factories}
# ── Op wrappers ───────────────────────────────────────────────────────────
# Each function delegates to the Newn axiom engine.
{op_wrappers}
'''


def export_python(filepath: str, engine=None) -> str:
    """
    Export all registered Newn ops as a self-contained Python module.

    The generated module:
    - Re-initialises the Newn engine with the original .nn source on import.
    - Exposes every prop as a factory function: ``absent(5)`` → ``PropValue('absent', 5)``.
    - Exposes every op as a regular Python function that goes through axiom dispatch.
    - Includes all bind display mappings as a look-up table.

    Args:
        filepath : destination path (e.g. 'domain_api.py')
        engine   : optional engine object; uses global _ENGINE if None

    Returns the generated Python source as a string (and writes the file).
    """
    if engine is None:
        from .core import _ENGINE as engine

    op_names   = sorted(engine.op_names())
    prop_names = sorted(engine.prop_names())

    # ── Reconstruct .nn source from stored declarations ────────────────────
    nn_source = engine._last_nn_source.strip() if engine._last_nn_source.strip() else None

    if nn_source is None:
        # Fall back: reconstruct a minimal .nn program from the engine state
        lines = []
        for pn in prop_names:
            lines.append(f"prop {pn}: None")
        for on in op_names:
            lines.append(f"op {on}: None")
        for on in op_names:
            for ax in engine._axioms.get(on, []):
                if ax.source_line.strip():
                    lines.append(ax.source_line.strip())
        nn_source = '\n'.join(lines)

    # ── Prop factory stubs ─────────────────────────────────────────────────
    prop_lines = []
    for pn in prop_names:
        prop_lines.append(
            f"def {pn}(value):\n"
            f"    '''Create PropValue({pn!r}, value).'''\n"
            f"    return PropValue({pn!r}, value)\n"
        )
    prop_factories_str = '\n'.join(prop_lines) if prop_lines else '# (no props)\n'

    # ── Op wrapper stubs ───────────────────────────────────────────────────
    op_lines = []
    for on in op_names:
        axiom_names = [ax.name for ax in engine._axioms.get(on, [])]
        doc = f"Newn op '{on}'."
        if axiom_names:
            doc += f"  Axioms: {', '.join(axiom_names)}."
        op_lines.append(
            f"def {on}(*args):\n"
            f"    '''{doc}'''\n"
            f"    return _nn_engine.call({on!r}, *args)\n"
        )
    op_wrappers_str = '\n'.join(op_lines) if op_lines else '# (no ops)\n'

    # ── Header placeholders ────────────────────────────────────────────────
    module_name   = os.path.splitext(os.path.basename(filepath))[0]
    example_ops   = ', '.join(op_names[:3]) if op_names else 'your_op'
    first_op_example = f"{op_names[0]}(...)  # your values here" if op_names else "your_op(...)"

    source = _PYTHON_HEADER.format(
        module_name=module_name,
        example_ops=example_ops,
        first_op_example=first_op_example,
        nn_source_repr=repr(nn_source),
        prop_factories=prop_factories_str,
        op_wrappers=op_wrappers_str,
    )

    # Append export bind table (Newn → external)
    if engine._bindings:
        bind_lines = [
            "\n# ── Export bind table (Newn → external)  translate_out ───────────────────",
            "# Maps (prop_name, inner_value) → external display value",
            "_BIND_TABLE = {",
        ]
        for (pn, iv), dv in sorted(
            engine._bindings.items(), key=lambda kv: (kv[0][0], str(kv[0][1]))
        ):
            bind_lines.append(f"    ({pn!r}, {iv!r}): {dv!r},")
        bind_lines.append("}")
        source += '\n'.join(bind_lines) + '\n'

    # Append import bind table (external → Newn)
    if engine._import_bindings:
        imp_lines = [
            "\n# ── Import bind table (external → Newn)  translate_in ───────────────────",
            "# Maps external_value → Newn PropValue (represented as its repr string here)",
            "_IMPORT_BIND_TABLE = {",
        ]
        for ext_val, newn_val in sorted(
            engine._import_bindings.items(), key=lambda kv: str(kv[0])
        ):
            imp_lines.append(f"    {ext_val!r}: {newn_val!r},")
        imp_lines.append("}")
        source += '\n'.join(imp_lines) + '\n'

    # Append translate_out / translate_in helpers when at least one bind table exists
    if engine._bindings or engine._import_bindings:
        helpers = [
            "",
            "# ── Bind translation helpers ─────────────────────────────────────────────",
        ]
        if engine._bindings:
            helpers += [
                "def translate_out(value):",
                "    '''Translate a Newn PropValue to its external representation.",
                "    Returns the bound display value if one is registered; otherwise",
                "    returns *value* unchanged.",
                "    '''",
                "    key = (getattr(value, 'prop_name', None), getattr(value, 'value', None))",
                "    return _BIND_TABLE.get(key, value)",
                "",
            ]
        if engine._import_bindings:
            helpers += [
                "def translate_in(external_value):",
                "    '''Translate an external value to its Newn representation.",
                "    Returns the registered Newn PropValue repr if one is registered;",
                "    otherwise returns *external_value* unchanged.",
                "    '''",
                "    return _IMPORT_BIND_TABLE.get(external_value, external_value)",
                "",
            ]
        source += '\n'.join(helpers) + '\n'

    with open(filepath, 'w') as f:
        f.write(source)

    return source
