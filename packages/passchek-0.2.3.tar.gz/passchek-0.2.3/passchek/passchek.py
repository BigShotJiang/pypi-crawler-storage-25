#!/usr/bin/env python3
"""
Passchek is a simple cli tool, checks if your password has been compromised.

This tool utilizes the k-anonymity algorithm to query Troy Hunt's
pwnedpassword API for password breaches.

MIT License

Developed by @edyatl <edyatl@yandex.ru> April 2026
https://github.com/edyatl

"""

import getopt
import getpass
import hashlib
import os
import sys
import urllib.error
import urllib.request

try:
    from passchek._version import __version__
except ImportError:
    __version__ = "0.2.3"

_API = "https://api.pwnedpasswords.com/range/"


def usage() -> None:
    """Show usage help screen and exit."""
    print(f"""Passchek v{__version__} - checks if your password has been compromised.

Usage: {os.path.basename(__file__)} [options] [PASSWORD ...]

Options:
    -h, --help      Shows this help message and exit
    -n, --num-only  Set output without accompanying text
    -p, --pipe      For use in shell pipes, read stdin
    -s, --sha1      Shows SHA1 hash in tuple ('prefix', 'suffix') and exit
    -v, --version   Shows current version of the program and exit
""")


def hash_password(pw: str | None = None) -> tuple[str, str]:
    """Hashing raw password and split hash to prefix and suffix.

    :param pw: password in raw format
    :return: tuple (prefix of hash, suffix of hash)
    """
    pw = pw.strip() if pw else ""
    hash_pass = (
        hashlib.sha1(pw.encode("utf-8"), usedforsecurity=True).hexdigest().upper()
    )
    return hash_pass[:5], hash_pass[5:]


def reqst(prefix: str) -> str:
    """Make request to Troy Hunt's pwnedpassword API.

    :param prefix: prefix of password hash
    :return: response string of Troy Hunt's pwnedpassword API
    """
    req = urllib.request.Request(
        url=f"{_API}{prefix}",
        headers={
            "User-Agent": f"passchek {__version__} (Python)",
            "Add-Padding": "true",
        },
    )
    try:
        with urllib.request.urlopen(req) as res:
            raw: bytes = res.read()
            return raw.decode("utf-8-sig")
    except (urllib.error.HTTPError, urllib.error.URLError) as err:
        print(f"Exception found: {err}")
        sys.exit(1)


def pwned_count(pw: str | None) -> int:
    """Return how many times *pw* appears in breach data (0 = not found).

    :param pw: password in raw format
    :return: count of matches
    """
    if pw:
        prefix, suffix = hash_password(pw)
    else:
        prefix, suffix = hash_password(getpass.getpass("Enter password: "))

    for line in reqst(prefix).splitlines():
        tail, sep, count = line.partition(":")
        if tail == suffix:
            return int(count)
    return 0


def get_matches(text_output: bool = True, pw: str | None = None) -> None:
    """Print the number of pwned-password matches.

    :param text_output: Whether to print a human-readable message.
    :param pw: Password in raw format.
    """
    matches = pwned_count(pw)

    if text_output:
        print(
            f"This password has appeared {matches} times in data breaches."
            if matches
            else "This password has not appeared in any data breaches!"
        )
    else:
        print(matches)


def parse_cli(argv: list[str]) -> tuple[bool, bool, bool, list[str], bool]:
    """Parse command-line arguments into structured options."""
    try:
        opts, args = getopt.gnu_getopt(
            argv, "hnpsv", ["help", "num-only", "pipe", "sha1", "version"]
        )
    except getopt.GetoptError as err:
        print(err)
        usage()
        sys.exit(2)

    text_output: bool = True  # --num-only
    use_in_pipe: bool = False  # --pipe
    sha1_output: bool = False  # --sha1
    exit_after_parse: bool = False

    for opt, _ in opts:
        if opt in ("-h", "--help"):
            usage()
            exit_after_parse = True
        elif opt in ("-n", "--num-only"):
            text_output = False
        elif opt in ("-p", "--pipe"):
            use_in_pipe = True
        elif opt in ("-s", "--sha1"):
            sha1_output = True
        elif opt in ("-v", "--version"):
            print(f"Passchek v{__version__}")
            exit_after_parse = True

    return text_output, use_in_pipe, sha1_output, args, exit_after_parse


def main() -> None:
    """Program entry point."""
    (
        text_output,
        use_in_pipe,
        sha1_output,
        args,
        exit_after_parse,
    ) = parse_cli(sys.argv[1:])

    if exit_after_parse:
        return

    def _passwords() -> list[str]:
        if args:
            return args
        if use_in_pipe:
            return [ln.rstrip("\n") for ln in sys.stdin]
        return [getpass.getpass("Enter password: ")]

    if sha1_output:
        for pw in _passwords():
            print(hash_password(pw) if text_output else " ".join(hash_password(pw)))
        return

    for pw in _passwords():
        get_matches(text_output, pw)


if __name__ == "__main__":
    main()
