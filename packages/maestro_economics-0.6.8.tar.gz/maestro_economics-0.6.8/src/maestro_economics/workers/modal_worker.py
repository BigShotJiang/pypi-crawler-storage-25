"""Modal Cloud GPU worker for maestro-economics jobs.

R2 I/O POLICY
-------------
Two code paths touch R2 in this worker, and they MUST NOT be collapsed:

1. **User-code path** (`ctx.data_dir`, `ctx.output_dir`, `ctx.checkpoint_dir`,
   `ctx.log`) goes through the mounted CloudBucketMount at ``/r2``. Lazy
   reads of input parquet, incremental ckpt flushes, and user stdout
   chunking all benefit from FUSE semantics.

2. **Worker bookkeeping path** (copying ``output/`` to
   ``runs/TS_JOBID/``, writing ``meta.json``, archiving final
   artifacts) goes through **boto3 S3 CopyObject / PutObject** against
   R2 directly. Same bucket, server-side copy, zero data traffic
   through the worker.

Why: upstream [mountpoint-s3#785](https://github.com/awslabs/mountpoint-s3/issues/785)
returns ``OSError [Errno 116] Stale file handle`` when a long-running
job rewrites an object whose metadata is still in the 60-second cache.
That bit two of this customer's 4-hour jobs at 99 % (see
ra-suite ``docs/cases/2026-04-24-r2-cloudbucketmount-estale.md``).
The direct-S3 bookkeeping path bypasses the FUSE cache entirely.
"""

from __future__ import annotations

import json
import os
import shutil
import time
import traceback
import zipfile
from pathlib import Path
from typing import Any

import modal

from maestro_economics.runtime.handler import _CancelledError, execute_job

R2_BUCKET = "ra-compute-prod"
R2_ENDPOINT = "https://4a6e409c279e108484bed901bf0f2ddb.r2.cloudflarestorage.com"

_s3_client: Any = None


def _get_s3() -> Any:
    """Lazy-init boto3 S3 client pointed at R2.

    Credentials come from the same `modal.Secret.from_name("r2-credentials")`
    that mounts the bucket. Modal exposes those keys as the standard
    AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY env names (S3-compatible
    convention), NOT R2_ACCESS_KEY_ID. The earlier R2_-prefixed lookup
    crashed every workspace job at meta.json write with
    `KeyError: 'R2_ACCESS_KEY_ID'`; see ra-suite incident sweep
    2026-04-25 (founder@ + 10 queued zombies).

    We accept either prefix — the AWS_ pair is what Modal injects, the
    R2_ pair is what someone reading the worker code might set when
    running the worker locally for an integration test.
    """
    global _s3_client
    if _s3_client is None:
        # Resolve credentials BEFORE importing boto3 so a missing-creds
        # error surfaces with a useful message instead of a confusing
        # ModuleNotFoundError when the dev env doesn't have boto3.
        access_key = os.environ.get("AWS_ACCESS_KEY_ID") or os.environ.get("R2_ACCESS_KEY_ID")
        secret_key = os.environ.get("AWS_SECRET_ACCESS_KEY") or os.environ.get("R2_SECRET_ACCESS_KEY")
        if not access_key or not secret_key:
            raise RuntimeError(
                "R2 credentials not found. Modal secret r2-credentials should "
                "expose AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY; locally set "
                "either AWS_* or R2_* equivalents."
            )

        import boto3  # imported lazily so image builds without boto3 still work

        _s3_client = boto3.client(
            "s3",
            endpoint_url=R2_ENDPOINT,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name="auto",
        )
    return _s3_client


def _s3_copy_prefix(src_prefix: str, dst_prefix: str) -> list[str]:
    """Server-side R2 CopyObject for every key under ``src_prefix``.

    Both prefixes live in the same R2 bucket, so CopyObject is a pure
    metadata op and never leaves R2. Avoids mountpoint-s3#785 ESTALE
    entirely because no FUSE cache is in the path.

    Idempotent: re-running with the same source/destination is safe.
    Returns the list of destination keys written.
    """
    s3 = _get_s3()
    written: list[str] = []
    paginator = s3.get_paginator("list_objects_v2")
    for page in paginator.paginate(Bucket=R2_BUCKET, Prefix=src_prefix):
        for obj in page.get("Contents", []):
            src_key = obj["Key"]
            # Preserve relative layout under dst_prefix, including subdirs.
            dst_key = dst_prefix + src_key[len(src_prefix):]
            s3.copy_object(
                Bucket=R2_BUCKET,
                Key=dst_key,
                CopySource={"Bucket": R2_BUCKET, "Key": src_key},
            )
            written.append(dst_key)
    return written


def _s3_put_json(key: str, body: dict[str, Any]) -> None:
    """Direct R2 PutObject for small bookkeeping JSON (meta.json, etc.).

    Mirrors _s3_copy_prefix's motivation: do not route small control-plane
    writes through the mount, where they inherit mountpoint-s3's quirks.
    """
    s3 = _get_s3()
    s3.put_object(
        Bucket=R2_BUCKET,
        Key=key,
        Body=json.dumps(body, indent=2).encode("utf-8"),
        ContentType="application/json",
    )

#
# JAX VERSION POLICY
# ------------------
# Pinned to 0.4.38 — the last release before the compilation-hang regression
# documented in https://github.com/jax-ml/jax/issues/26767. Versions 0.5.0
# and 0.5.1 hang indefinitely during XLA HLO passes on certain complex graphs
# (customer incident: ra-suite docs/cases/2026-04-24-xla-jit-compile-hang.md).
#
# Do not bump past 0.4.x without running the R15 fixture job through the
# silent-worker reaper test. See
# ra-suite docs/plans/compute-liveness-architecture.md §6 "JAX Version Policy".
# Last verified: 2026-04-24.
#
economics_image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "jax[cuda12]==0.4.38",
        "jaxlib==0.4.38",
        "jaxopt>=0.8",
        "numpy>=1.26",
        "pandas>=2.2",
        "scipy>=1.12",
        "pyarrow>=15.0",
        "cma>=4.0",
        "httpx>=0.27",
        "boto3>=1.34",
        "psutil>=5.9",
        "fastapi[standard]",
        "statsmodels>=0.14",
        "scikit-learn>=1.4",
        "duckdb>=0.10",
        "matplotlib>=3.8",
    )
    .add_local_python_source("maestro_economics")
)

r2_bucket = modal.CloudBucketMount(
    bucket_name="ra-compute-prod",
    bucket_endpoint_url="https://4a6e409c279e108484bed901bf0f2ddb.r2.cloudflarestorage.com",
    secret=modal.Secret.from_name("r2-credentials"),
)

app = modal.App("maestro-economics", image=economics_image)

# The CloudBucketMount above consumes the r2-credentials Secret to mount
# /r2 via FUSE, but mounting does NOT expose the secret's keys as env
# vars to the function process. boto3 inside the worker (Phase 3.5
# post-execute path) needs AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY,
# so attach the same secret again to every GPU function — modal does
# the right thing and reuses the underlying secret store.
r2_env_secret = modal.Secret.from_name("r2-credentials")

R2_MOUNT = Path("/r2")
LOCAL_WORK = Path("/tmp/mecon_job")

GPU_SPECS: dict[str, tuple[str, float]] = {
    "T4": ("T4", 16.0),
    "L4": ("L4", 24.0),
    "A10G": ("A10G", 24.0),
    "L40S": ("L40S", 48.0),
    "A100": ("A100", 80.0),
    "H100": ("H100", 80.0),
}

TERMINAL_CALLBACK_STATUSES = {"completed", "timed_out", "failed", "cancelled"}
CALLBACK_MAX_ATTEMPTS = 8
CALLBACK_TERMINAL_MAX_ATTEMPTS = 20
CALLBACK_TIMEOUT_SECONDS = 30

# Phase 2 heartbeat: daemon thread posts proof-of-life every 30 s. Rides
# an OS-level thread so it keeps flowing even when the main Python thread
# is blocked inside a C++ extension (XLA compile hang, stuck CUDA launch).
# Server reaper default: 120 s threshold (two missed heartbeats = dead).
HEARTBEAT_INTERVAL_SECONDS = 30
HEARTBEAT_TIMEOUT_SECONDS = 10

# Phase 4.5 profiling: same sidecar thread samples nvidia-smi + psutil +
# JAX + cgroup every 10 s, batches, flushes to the server every 60 s.
METRICS_SAMPLE_INTERVAL = 10
METRICS_BATCH_INTERVAL = 60

WORKSPACE_CONTROL_DIRS = {
    "output",
    "runs",
    "logs",
    "checkpoints",
    ".git",
    ".mecon",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".ipynb_checkpoints",
    ".venv",
    "venv",
    "node_modules",
    "dist",
    "build",
}
WORKSPACE_SOURCE_SUFFIXES = {".py", ".json", ".yaml", ".yml", ".toml", ".txt"}
MAX_WORKSPACE_SOURCE_FILES = 2_000
MAX_WORKSPACE_SOURCE_BYTES = 64 * 1024 * 1024


def _normalise_workspace_relative_path(raw_path: str) -> Path:
    if not isinstance(raw_path, str):
        raise ValueError("workspace_files must contain only string paths")
    value = raw_path.strip().replace("\\", "/")
    if not value or value.startswith("/"):
        raise ValueError(f"Unsafe workspace path: {raw_path!r}")
    parts = tuple(part for part in value.split("/") if part and part != ".")
    if not parts or any(part == ".." for part in parts):
        raise ValueError(f"Unsafe workspace path: {raw_path!r}")
    return Path(*parts)


def _normalise_workspace_file_list(raw_files: Any) -> list[Path] | None:
    if raw_files is None:
        return None
    if not isinstance(raw_files, list):
        raise ValueError("workspace_files must be a list of relative paths")
    files = {_normalise_workspace_relative_path(path) for path in raw_files}
    return sorted(files, key=lambda path: path.as_posix())


def _should_copy_workspace_source(rel: Path) -> bool:
    parts = rel.parts
    if not parts:
        return False
    if parts[0] == "data":
        return False
    if any(part in WORKSPACE_CONTROL_DIRS or part.startswith(".") for part in parts):
        return False
    return rel.suffix.lower() in WORKSPACE_SOURCE_SUFFIXES


def _iter_workspace_sources_fallback(r2_workspace: Path) -> list[Path]:
    sources: list[Path] = []
    for root, dirs, files in os.walk(r2_workspace):
        dirs[:] = [
            dirname
            for dirname in dirs
            if dirname not in WORKSPACE_CONTROL_DIRS and not dirname.startswith(".")
        ]
        root_path = Path(root)
        for filename in files:
            rel = (root_path / filename).relative_to(r2_workspace)
            if _should_copy_workspace_source(rel):
                sources.append(rel)
            if len(sources) > MAX_WORKSPACE_SOURCE_FILES:
                raise ValueError(
                    f"Workspace source file limit exceeded ({MAX_WORKSPACE_SOURCE_FILES}). "
                    "Track only code/config files and keep generated outputs out of the workspace root."
                )
    return sorted(sources, key=lambda path: path.as_posix())


def _copy_workspace_sources(
    r2_workspace: Path,
    local_code: Path,
    raw_workspace_files: Any,
    entry: str,
) -> int:
    entry_rel = _normalise_workspace_relative_path(entry)
    manifest_files = _normalise_workspace_file_list(raw_workspace_files)
    if manifest_files is None:
        selected = _iter_workspace_sources_fallback(r2_workspace)
    else:
        selected = [rel for rel in manifest_files if _should_copy_workspace_source(rel)]

    if _should_copy_workspace_source(entry_rel) and entry_rel not in selected:
        selected.append(entry_rel)

    copied = 0
    copied_bytes = 0
    for rel in sorted(set(selected), key=lambda path: path.as_posix()):
        src = r2_workspace / rel
        if not src.exists():
            if rel == entry_rel:
                raise FileNotFoundError(f"Entry point '{entry_rel.as_posix()}' not found in R2 workspace")
            continue
        if not src.is_file():
            continue
        size = src.stat().st_size
        if copied + 1 > MAX_WORKSPACE_SOURCE_FILES:
            raise ValueError(f"Workspace source file limit exceeded ({MAX_WORKSPACE_SOURCE_FILES})")
        if copied_bytes + size > MAX_WORKSPACE_SOURCE_BYTES:
            raise ValueError(
                f"Workspace source byte limit exceeded ({MAX_WORKSPACE_SOURCE_BYTES} bytes). "
                "Move large inputs under data/ and keep source/config small."
            )
        dest = local_code / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        copied += 1
        copied_bytes += size

    script_path = local_code / entry_rel
    if not script_path.exists():
        raise ValueError(f"Entry point '{entry_rel.as_posix()}' not found in copied workspace source")
    return copied


def _derive_heartbeat_url(callback_url: str) -> str:
    """Build the heartbeat URL from the signed callback URL.

    The HMAC signature on the callback URL is scoped to `{job_id}:{expires}`,
    not to the path, so we can append `/heartbeat` and keep the same
    `expires` + `sig` query params. The server enforces the same signature
    check on both endpoints.
    """
    from urllib.parse import urlparse, urlunparse

    parts = urlparse(callback_url)
    return urlunparse(parts._replace(path=parts.path.rstrip("/") + "/heartbeat"))


def _derive_activity_url(callback_url: str) -> str:
    """Build the activity URL from the signed callback URL."""
    from urllib.parse import urlparse, urlunparse

    parts = urlparse(callback_url)
    return urlunparse(parts._replace(path=parts.path.rstrip("/") + "/activity"))


def _derive_metrics_url(callback_url: str, job_id: str) -> str:
    """Build the metrics POST URL reusing the callback's HMAC.

    Unlike heartbeat (same-path-different-suffix), the metrics endpoint
    lives at `/workers/metrics` — a shared path across all jobs, scoped
    by `job_id` query param. The same HMAC (signed on `job_id:expires`)
    authorises it.
    """
    from urllib.parse import urlparse, parse_qsl, urlencode, urlunparse

    parts = urlparse(callback_url)
    query = dict(parse_qsl(parts.query))
    query["job_id"] = job_id
    metrics_path = "/api/ra/compute/workers/metrics"
    return urlunparse(parts._replace(path=metrics_path, query=urlencode(query)))


def _sample_metrics(phase: str) -> dict[str, Any]:
    """One sample of proc-level + JAX-level metrics.

    Modal's OTel integration already gives us GPU util / CPU / RSS /
    container memory per container, so strictly we only need JAX + cgroup
    bits here. We still sample the proc basics because (a) OTel may not
    be wired, (b) having them on our side makes mecon-profile output
    self-contained (customer doesn't need a Grafana login).
    """
    import os
    import time as _time

    sample: dict[str, Any] = {
        "ts": _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime()),
        "phase": phase,
    }

    # Proc metrics — psutil is already in the image transitively.
    try:
        import psutil

        proc = psutil.Process(os.getpid())
        sample["cpu_pct"] = float(proc.cpu_percent(interval=None))
        mem = proc.memory_info()
        sample["rss_mb"] = int(mem.rss / (1024 * 1024))
        sample["thread_count"] = int(proc.num_threads())
    except Exception:
        pass

    # JAX memory_stats — single device assumed (one GPU per container).
    try:
        import jax

        devices = jax.devices()
        if devices:
            stats = devices[0].memory_stats() or {}
            jax_peak = stats.get("peak_bytes_in_use")
            if jax_peak is not None:
                sample["jax_peak_mb"] = int(int(jax_peak) / (1024 * 1024))
    except Exception:
        pass

    # cgroup v2 — the container's actual memory usage as the kernel sees it.
    # Path-based read; faster and more reliable than shelling out. memory.events
    # tells us whether the kernel saw cgroup OOM pressure before a SIGKILL.
    try:
        with open("/sys/fs/cgroup/memory.current") as fh:
            sample["cgroup_mem_mb"] = int(int(fh.read().strip()) / (1024 * 1024))
        try:
            events: dict[str, int] = {}
            with open("/sys/fs/cgroup/memory.events") as fh:
                for line in fh:
                    name, value = line.strip().split()
                    events[name] = int(value)
            sample["cgroup_oom_count"] = events.get("oom", 0)
            sample["cgroup_oom_kill_count"] = events.get("oom_kill", 0)
        except Exception:
            pass
    except Exception:
        pass

    # nvidia-smi — GPU util + VRAM. Shell-out is cheap at 10 s cadence.
    try:
        import subprocess as _sp

        out = _sp.run(
            [
                "nvidia-smi",
                "--query-gpu=utilization.gpu,memory.used,memory.total",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if out.returncode == 0 and out.stdout.strip():
            first = out.stdout.strip().splitlines()[0]
            util_str, used_str, total_str = [p.strip() for p in first.split(",")]
            sample["gpu_util_pct"] = float(util_str)
            sample["gpu_mem_used_mb"] = int(used_str)
            sample["gpu_mem_total_mb"] = int(total_str)
    except Exception:
        pass

    return sample


def _start_heartbeat(
    callback_url: str,
    job_id: str,
    stop_event: Any,
    phase_source: Any = None,
) -> Any:
    """Launch a daemon thread that POSTs heartbeats + metric samples.

    One thread carries two duties:
      * every HEARTBEAT_INTERVAL_SECONDS (30 s): POST heartbeat (Phase 2).
      * every METRICS_SAMPLE_INTERVAL (10 s): sample metrics and buffer.
      * every METRICS_BATCH_INTERVAL (60 s): POST the buffered batch.

    `phase_source` is an optional callable returning the current job
    phase ('download', 'setup', 'warmup', 'search', 'post-execute'). If
    omitted or None, samples tag phase='unknown' and the profile view
    loses that dimension.

    Errors are swallowed: the reaper family handles liveness, and metric
    loss is benign (profiling is best-effort).
    """
    import threading
    import httpx

    heartbeat_url = _derive_heartbeat_url(callback_url)
    metrics_url = _derive_metrics_url(callback_url, job_id)

    def _loop() -> None:
        buffer: list[dict[str, Any]] = []
        last_heartbeat = 0.0
        last_metric_flush = 0.0

        while not stop_event.wait(METRICS_SAMPLE_INTERVAL):
            now = time.time()
            phase: str = "unknown"
            try:
                maybe_phase = phase_source() if callable(phase_source) else None
                if isinstance(maybe_phase, str):
                    phase = maybe_phase
            except Exception:
                phase = "unknown"

            buffer.append(_sample_metrics(phase))

            if now - last_heartbeat >= HEARTBEAT_INTERVAL_SECONDS:
                try:
                    httpx.post(
                        heartbeat_url,
                        json={"job_id": job_id},
                        timeout=HEARTBEAT_TIMEOUT_SECONDS,
                    )
                except Exception:
                    pass
                last_heartbeat = now

            if now - last_metric_flush >= METRICS_BATCH_INTERVAL and buffer:
                try:
                    httpx.post(
                        metrics_url,
                        json={"samples": buffer},
                        timeout=HEARTBEAT_TIMEOUT_SECONDS,
                    )
                    buffer.clear()
                    last_metric_flush = now
                except Exception:
                    # Drop the batch on flush error — keeping buffering
                    # forever would blow worker RAM. Next batch attempt
                    # carries the next ~60 s of samples.
                    buffer.clear()
                    last_metric_flush = now

    thread = threading.Thread(target=_loop, name=f"heartbeat-{job_id[:8]}", daemon=True)
    thread.start()
    return thread

# Ceiling for every GPU-tier @app.function (Modal's documented 24h max).
# Modal has no public per-invocation timeout override, so this value is the
# hard platform cap for any single job. The user's actual requested budget
# is enforced separately inside the worker via runtime.handler._Timeout
# (SIGALRM), which raises TimeoutError -> _run_job POSTs a terminal `failed`
# callback well before Modal hits this ceiling.
GPU_FUNCTION_TIMEOUT = 86400


def _report_status(
    callback_url: str,
    job_id: str,
    status: str,
    progress: float = 0.0,
    message: str = "",
    gpu_seconds: float | None = None,
    result: dict[str, Any] | None = None,
    error: str | None = None,
) -> bool:
    import httpx

    payload: dict[str, Any] = {
        "job_id": job_id,
        "status": status,
        "progress": progress,
        "message": message,
    }
    if result is not None:
        payload["result"] = result
    if gpu_seconds is not None:
        payload["gpu_seconds"] = gpu_seconds
    if error is not None:
        payload["error"] = error

    attempts = CALLBACK_TERMINAL_MAX_ATTEMPTS if status in TERMINAL_CALLBACK_STATUSES else CALLBACK_MAX_ATTEMPTS
    last_error: Exception | None = None

    for attempt in range(1, attempts + 1):
        try:
            response = httpx.post(callback_url, json=payload, timeout=CALLBACK_TIMEOUT_SECONDS)
            response.raise_for_status()
            return True
        except Exception as exc:
            last_error = exc
            if attempt == attempts:
                break
            # Short linear backoff for progress, longer capped backoff for terminal delivery.
            if status in TERMINAL_CALLBACK_STATUSES:
                time.sleep(min(10, attempt))
            else:
                time.sleep(min(2, 0.25 * attempt))

    if status in TERMINAL_CALLBACK_STATUSES:
        raise RuntimeError(
            f"Callback delivery failed after {attempts} attempts for job {job_id} status={status}: {last_error}"
        )
    return False


def _run_job(payload: dict[str, Any]) -> dict[str, Any]:
    import signal as _signal
    import threading

    job_id: str = payload["job_id"]
    callback_url: str = payload["callback_url"]
    gpu_type: str = payload.get("gpu_type", "L4")
    timeout_sec: int = payload.get("timeout", 3600)
    config: dict[str, Any] = payload.get("config", {})
    phase = "setup"

    # Start the heartbeat sidecar as early as possible so even the download
    # phase is covered. stop_event MUST be set in every return path so the
    # daemon thread does not survive into the next warm-container job and
    # spam stale heartbeats for an old job_id (incident class 2026-04-26).
    # The whole body of _run_job is wrapped in try/finally below to guarantee
    # this even on early returns and exceptions.
    _heartbeat_stop = threading.Event()
    _start_heartbeat(callback_url, job_id, _heartbeat_stop, lambda: phase)

    # Defensive: a user run.py that did `jax.config.update("jax_compilation
    # _cache_dir", "/r2/jax_cache")` would persist compiled HLO across jobs.
    # If the user later changes the jit'd function in a way that doesn't
    # change the JAXPR shape (e.g. only mutates a closure constant), the
    # stale HLO can re-execute. Force the cache off before user code loads.
    # No-ops if jax isn't importable in this image.
    try:
        import jax as _jax  # noqa: PLC0415

        _jax.config.update("jax_compilation_cache_dir", "")
    except Exception:
        pass

    # Modal sends SIGTERM with a grace window (~30s) before SIGKILL when a
    # function hits its timeout or is cancelled. Install a handler here so the
    # download/setup phase is covered -- `execute_job` installs its own
    # SIGTERM -> _CancelledError handler once user code starts, which the
    # existing try/except around execute_job resolves. After execute_job
    # returns, the tail try/except catches anything the runtime handler
    # re-raises. Without this setup-phase handler, a SIGTERM during R2 copy
    # or zip extraction would bypass every other guard.
    def _setup_phase_sigterm_handler(signum: int, frame: Any) -> None:
        try:
            _report_status(
                callback_url,
                job_id,
                "failed",
                0.0,
                "Worker received SIGTERM during setup (Modal timeout or cancellation)",
                error="modal_sigterm_setup_phase",
            )
        finally:
            # Stop the heartbeat sidecar before re-raising SIGTERM so the
            # daemon thread is not left running into the next warm-container
            # job (incident class 2026-04-26 — leaked thread spammed stale
            # job_id heartbeats).
            _heartbeat_stop.set()
            _signal.signal(_signal.SIGTERM, _signal.SIG_DFL)
            _signal.raise_signal(_signal.SIGTERM)

    _signal.signal(_signal.SIGTERM, _setup_phase_sigterm_handler)

    _, gpu_memory = GPU_SPECS.get(gpu_type, ("L4", 24.0))

    r2_uploads = R2_MOUNT / "uploads" / job_id
    r2_job = R2_MOUNT / "jobs" / job_id
    local_code = LOCAL_WORK / "code"
    if local_code.exists():
        shutil.rmtree(local_code)
    local_code.mkdir(parents=True, exist_ok=True)

    try:
        phase = "download"
        _report_status(callback_url, job_id, "downloading", 0.0, "Loading code from R2")

        workspace_path = payload.get("workspace_path")
        r2_run_history = None
        script_path = local_code / "run.py"
        data_dir = local_code / "data"
        data_dir.mkdir(parents=True, exist_ok=True)

        if workspace_path:
            r2_workspace = R2_MOUNT / workspace_path
            entry = config.pop("entry", "run.py")
            workspace_files = config.pop("workspace_files", None)
            copied_sources = _copy_workspace_sources(r2_workspace, local_code, workspace_files, entry)
            script_path = local_code / _normalise_workspace_relative_path(entry)
            _report_status(
                callback_url,
                job_id,
                "downloading",
                0.03,
                f"Workspace source ready ({copied_sources} files)",
            )
            ws_data = r2_workspace / "data"
            if ws_data.exists():
                data_dir = ws_data
            import datetime as dt

            ts = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
            r2_output = r2_workspace / "output"
            r2_output.mkdir(parents=True, exist_ok=True)
            r2_run_history = r2_workspace / "runs" / f"{ts}_{job_id[:8]}"
            r2_run_history.mkdir(parents=True, exist_ok=True)
            r2_checkpoints = r2_workspace / "checkpoints"
            r2_checkpoints.mkdir(parents=True, exist_ok=True)
            # Logs are always job-scoped so /v1/jobs/{id}/logs and `mecon logs`
            # can retrieve the exact failed run. Older workers wrote workspace
            # logs to {workspace}/logs, which mixed multiple jobs and hid real
            # failures from the CLI.
            r2_logs = r2_job / "logs"
            r2_logs.mkdir(parents=True, exist_ok=True)
            meta = {"job_id": job_id, "gpu_type": gpu_type, "timeout": timeout_sec, "config": config}
            # Write meta.json via direct R2 PutObject (see R2 I/O POLICY in
            # module docstring). Small control-plane write; the FUSE mount is
            # reserved for user-code I/O.
            _s3_put_json(f"{workspace_path}/runs/{ts}_{job_id[:8]}/meta.json", meta)
        else:
            r2_output = r2_job / "output"
            r2_checkpoints = r2_job / "checkpoints"
            r2_logs = r2_job / "logs"
            for directory in (r2_output, r2_checkpoints, r2_logs):
                directory.mkdir(parents=True, exist_ok=True)
            meta = {"job_id": job_id, "gpu_type": gpu_type, "timeout": timeout_sec, "config": config}
            _s3_put_json(f"jobs/{job_id}/meta.json", meta)

            zip_file = None
            script_file = None
            if r2_uploads.exists():
                for file in r2_uploads.iterdir():
                    if file.suffix == ".zip":
                        zip_file = file
                    elif file.suffix == ".py":
                        script_file = file

            if zip_file:
                with zipfile.ZipFile(zip_file, "r") as archive:
                    archive.extractall(local_code)
                entry = config.pop("entry", "run.py")
                entry_path = local_code / _normalise_workspace_relative_path(entry)
                if not entry_path.exists():
                    py_files = list(local_code.rglob("*.py"))
                    raise ValueError(f"Entry point '{entry}' not found. Files: {py_files}")
                script_path = entry_path
                proj_data = local_code / "data"
                if proj_data.exists():
                    data_dir = proj_data
            elif script_file:
                shutil.copy2(script_file, script_path)
            elif config.get("script_code"):
                script_path.write_text(config.pop("script_code"))
            else:
                raise ValueError(f"No script found in uploads for job {job_id}")
    except Exception as exc:
        tb = traceback.format_exc()
        _report_status(
            callback_url,
            job_id,
            "failed",
            0.0,
            f"Setup failed: {exc}",
            gpu_seconds=0.0,
            error=tb,
        )
        _heartbeat_stop.set()
        return {"status": "error", "error": tb}

    phase = "execute"
    _report_status(callback_url, job_id, "running", 0.05, "Starting execution")
    activity_url = _derive_activity_url(callback_url)

    def progress_cb(pct: float, msg: str) -> None:
        nonlocal phase
        lower_msg = msg.lower()
        if "jit" in lower_msg or "warmup" in lower_msg or "compile" in lower_msg:
            phase = "warmup"
        else:
            phase = "execute"
        scaled = 0.05 + pct * 0.85
        _report_status(callback_url, job_id, "running", scaled, msg)

    def activity_cb(kind: str, message: str) -> None:
        import httpx

        try:
            httpx.post(
                activity_url,
                json={"job_id": job_id, "kind": kind, "message": message},
                timeout=CALLBACK_TIMEOUT_SECONDS,
            )
        except Exception:
            pass

    started_at = time.monotonic()

    try:
        result = execute_job(
            script_path=str(script_path),
            data_dir=str(data_dir),
            output_dir=str(r2_output),
            config=config,
            progress_cb=progress_cb,
            gpu_type=gpu_type,
            gpu_memory_gb=gpu_memory,
            timeout=timeout_sec,
            checkpoint_dir=str(r2_checkpoints),
            log_dir=str(r2_logs),
            activity_cb=activity_cb,
        )
    except _CancelledError:
        elapsed = max(0.0, time.monotonic() - started_at)
        _report_status(callback_url, job_id, "cancelled", 0.0, "Job cancelled -- logs flushed", gpu_seconds=elapsed)
        _heartbeat_stop.set()
        return {"status": "cancelled", "message": "Graceful shutdown completed"}
    except TimeoutError as exc:
        elapsed = max(0.0, time.monotonic() - started_at)
        archive_error = None
        timeout_result = getattr(exc, "partial_result", None)
        if not isinstance(timeout_result, dict):
            timeout_result = {
                "status": "timed_out",
                "message": str(exc),
                "partial": True,
            }
        if workspace_path and r2_run_history:
            try:
                _report_status(
                    callback_url,
                    job_id,
                    "running",
                    0.95,
                    "Archiving partial outputs to R2 after time budget was reached",
                )
                src_prefix = str(r2_output.relative_to(R2_MOUNT)) + "/"
                dst_prefix = str(r2_run_history.relative_to(R2_MOUNT)) + "/"
                _s3_copy_prefix(src_prefix, dst_prefix)

                log_src_prefix = f"jobs/{job_id}/logs/"
                log_dst_prefix = str((r2_run_history / "logs").relative_to(R2_MOUNT)) + "/"
                _s3_copy_prefix(log_src_prefix, log_dst_prefix)
            except Exception as archive_exc:  # noqa: BLE001
                archive_error = traceback.format_exc()
        _report_status(
            callback_url,
            job_id,
            "timed_out",
            1.0,
            str(exc),
            gpu_seconds=elapsed,
            result={
                **timeout_result,
                **({"archive_error": archive_error} if archive_error else {}),
            },
            error=archive_error,
        )
        _heartbeat_stop.set()
        return {"status": "timeout", "error": str(exc)}
    except Exception as exc:
        tb = traceback.format_exc()
        elapsed = max(0.0, time.monotonic() - started_at)
        _report_status(
            callback_url,
            job_id,
            "failed",
            0.0,
            str(exc),
            gpu_seconds=elapsed,
            error=tb,
        )
        _heartbeat_stop.set()
        return {"status": "error", "error": tb}

    # Post-execute path. Anything that raises here would otherwise leave the
    # job stuck in 'running' forever, because Modal does not push a platform
    # terminal event to our app -- the worker's own callback is the only path
    # to a terminal state. Wrap the whole tail so a failure during output
    # archival or the final POST still resolves the job.
    try:
        phase = "post_execute"
        if workspace_path and r2_run_history:
            # Tell the silent reaper that user code is done but archive is
            # underway. Without this last_progress_at can stay stale through
            # a multi-minute _s3_copy_prefix on large workspaces, which can
            # trip the 600 s silent threshold and force-fail a job whose
            # results are already on disk -- the customer would see status
            # 'failed' + credits refunded, but their results.json is in R2.
            _report_status(
                callback_url,
                job_id,
                "running",
                0.95,
                "Archiving outputs to R2 (this can take a few minutes for large workspaces)",
            )
            # Archive the run's outputs to a timestamped run-history folder.
            # Uses direct R2 CopyObject (server-side, zero egress) instead of
            # the previous mount-to-mount shutil.copyfile loop, which hit
            # upstream mountpoint-s3#785 ESTALE on long-writing jobs. See
            # ra-suite docs/cases/2026-04-24-r2-cloudbucketmount-estale.md.
            # Recursive so subdirectories written by user code are preserved
            # (the prior iterdir() loop silently dropped them).
            # Deriving prefixes from the mount Path objects (not from `ts`)
            # keeps the control flow analysable and matches whatever the
            # setup block produced.
            src_prefix = str(r2_output.relative_to(R2_MOUNT)) + "/"
            dst_prefix = str(r2_run_history.relative_to(R2_MOUNT)) + "/"
            _s3_copy_prefix(src_prefix, dst_prefix)

            log_src_prefix = f"jobs/{job_id}/logs/"
            log_dst_prefix = str((r2_run_history / "logs").relative_to(R2_MOUNT)) + "/"
            _s3_copy_prefix(log_src_prefix, log_dst_prefix)

        elapsed = max(0.0, time.monotonic() - started_at)
        callback_result = result if isinstance(result, dict) else None
        _report_status(
            callback_url,
            job_id,
            "completed",
            1.0,
            "Job finished",
            gpu_seconds=elapsed,
            result=callback_result,
        )
        _heartbeat_stop.set()
        return {"status": "completed", "result": result}
    except Exception as exc:
        tb = traceback.format_exc()
        elapsed = max(0.0, time.monotonic() - started_at)
        _report_status(
            callback_url,
            job_id,
            "failed",
            1.0,
            f"Post-execute failure: {exc}",
            gpu_seconds=elapsed,
            error=tb,
        )
        _heartbeat_stop.set()
        return {"status": "error", "error": tb}


@app.function(gpu="T4", timeout=GPU_FUNCTION_TIMEOUT, retries=0, volumes={"/r2": r2_bucket}, secrets=[r2_env_secret])
def run_job_t4(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "T4")
    return _run_job(payload)


@app.function(gpu="L4", timeout=GPU_FUNCTION_TIMEOUT, retries=0, volumes={"/r2": r2_bucket}, secrets=[r2_env_secret])
def run_job_l4(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "L4")
    return _run_job(payload)


@app.function(gpu="A10G", timeout=GPU_FUNCTION_TIMEOUT, retries=0, volumes={"/r2": r2_bucket}, secrets=[r2_env_secret])
def run_job_a10g(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "A10G")
    return _run_job(payload)


@app.function(gpu="L40S", timeout=GPU_FUNCTION_TIMEOUT, retries=0, volumes={"/r2": r2_bucket}, secrets=[r2_env_secret])
def run_job_l40s(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "L40S")
    return _run_job(payload)


@app.function(gpu="A100", timeout=GPU_FUNCTION_TIMEOUT, retries=0, volumes={"/r2": r2_bucket}, secrets=[r2_env_secret])
def run_job_a100(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "A100")
    return _run_job(payload)


@app.function(gpu="H100", timeout=GPU_FUNCTION_TIMEOUT, retries=0, volumes={"/r2": r2_bucket}, secrets=[r2_env_secret])
def run_job_h100(payload: dict[str, Any]) -> dict[str, Any]:
    payload.setdefault("gpu_type", "H100")
    return _run_job(payload)


GPU_FUNCTIONS = {
    "T4": run_job_t4,
    "L4": run_job_l4,
    "A10G": run_job_a10g,
    "L40S": run_job_l40s,
    "A100": run_job_a100,
    "H100": run_job_h100,
}


def dispatch(payload: dict[str, Any]) -> dict[str, Any]:
    gpu_type = payload.get("gpu_type", "L4")
    fn = GPU_FUNCTIONS.get(gpu_type)
    if fn is None:
        raise ValueError(f"Unknown gpu_type: {gpu_type}. Valid: {list(GPU_FUNCTIONS)}")
    return fn.remote(payload)


@app.function(timeout=60)
@modal.fastapi_endpoint(method="POST")
def submit_job(payload: dict[str, Any]) -> dict[str, Any]:
    """HTTP endpoint: POST /submit_job with JSON payload.

    Modal's per-function timeout is the only timeout the platform supports;
    there is no public per-invocation override API (Function.with_options
    was removed/never landed). Instead the decorator sets the maximum
    runtime (GPU_FUNCTION_TIMEOUT = 24h) and the user's actual budget is
    enforced inside the worker by runtime.handler._Timeout (SIGALRM). When
    that fires, the try/except in _run_job posts a `failed` callback
    before the function returns. The server watchdog remains the
    authoritative backstop if even that path misses.
    """
    gpu_type = payload.get("gpu_type", "L4")
    fn = GPU_FUNCTIONS.get(gpu_type)
    if fn is None:
        return {"error": f"Unknown gpu_type: {gpu_type}", "valid": list(GPU_FUNCTIONS)}

    call = fn.spawn(payload)
    return {
        "call_id": call.object_id,
        "gpu_type": gpu_type,
        "status": "spawned",
    }
