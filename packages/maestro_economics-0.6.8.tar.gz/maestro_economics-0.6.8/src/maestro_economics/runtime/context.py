"""JobContext -- the runtime context passed to user scripts via run(ctx)."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd

from . import transforms


@dataclass
class GpuInfo:
    """GPU hardware information available to the job."""

    type: str | None = None
    memory_gb: float | None = None


class DataLoader:
    """Load datasets from the job's data directory."""

    def __init__(self, data_dir: Path) -> None:
        self._data_dir = data_dir

    def load(
        self,
        file: str,
        entity: str | None = None,
        time: str | None = None,
    ) -> pd.DataFrame:
        path = self._data_dir / file
        if not path.exists():
            raise FileNotFoundError(f"Data file not found: {path}")

        suffix = path.suffix.lower()
        if suffix == ".csv":
            df = pd.read_csv(path)
        elif suffix == ".parquet":
            df = pd.read_parquet(path)
        elif suffix == ".dta":
            df = pd.DataFrame(pd.read_stata(path))
        else:
            raise ValueError(f"Unsupported file format: {suffix}")

        df.attrs["entity"] = entity
        df.attrs["time"] = time
        return df


class _TransformNamespace:
    winsorize = staticmethod(transforms.winsorize)
    lag = staticmethod(transforms.lag)
    lead = staticmethod(transforms.lead)
    diff = staticmethod(transforms.diff)
    balance_panel = staticmethod(transforms.balance_panel)
    dummy = staticmethod(transforms.dummy)
    standardize = staticmethod(transforms.standardize)
    merge = staticmethod(transforms.merge)
    recode = staticmethod(transforms.recode)


class JobContext:
    """Runtime context passed to user scripts."""

    def __init__(
        self,
        data_dir: Path,
        output_dir: Path,
        config: dict[str, Any],
        progress_callback: Callable[[float, str], None] | None = None,
        gpu: GpuInfo | None = None,
        checkpoint_dir: Path | None = None,
        log_dir: Path | None = None,
    ) -> None:
        self._data_dir = Path(data_dir)
        self._output_dir = Path(output_dir)
        self._config = config
        self._progress_callback = progress_callback
        self._gpu = gpu or GpuInfo()
        self._data = DataLoader(self._data_dir)
        self._transform = _TransformNamespace()
        self._checkpoint_dir = Path(checkpoint_dir) if checkpoint_dir else self._output_dir / "checkpoints"
        self._checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self._log_dir = Path(log_dir) if log_dir else self._output_dir / "logs"
        self._log_dir.mkdir(parents=True, exist_ok=True)
        self._log_seq = self._next_log_seq()
        self._latest_progress: dict[str, Any] | None = None
        self._partial_result: dict[str, Any] = {}

    @property
    def data_dir(self) -> Path:
        return self._data_dir

    @property
    def output_dir(self) -> Path:
        return self._output_dir

    @property
    def config(self) -> dict[str, Any]:
        return self._config

    @property
    def data(self) -> DataLoader:
        return self._data

    @property
    def transform(self) -> _TransformNamespace:
        return self._transform

    @property
    def gpu(self) -> GpuInfo:
        return self._gpu

    def progress(self, pct: float, msg: str = "") -> None:
        self._latest_progress = {"pct": pct, "message": msg}
        if self._progress_callback is not None:
            self._progress_callback(pct, msg)

    def update_result(self, **fields: Any) -> None:
        """Persist a structured partial result for timeout/resume recovery.

        Long-running searches should call this whenever a new incumbent/best
        estimate is found. The runtime owns final callbacks and billing, but
        it cannot infer domain-specific partial results unless user code
        publishes them through this generic envelope.
        """
        self._partial_result.update(fields)
        path = self._output_dir / "results.partial.json"
        path.write_text(json.dumps(self._partial_result, indent=2, default=str))

    @property
    def partial_result(self) -> dict[str, Any]:
        return dict(self._partial_result)

    @property
    def latest_progress(self) -> dict[str, Any] | None:
        return dict(self._latest_progress) if self._latest_progress is not None else None

    def save_checkpoint(self, **arrays: Any) -> None:
        import io

        buffer = io.BytesIO()
        np.savez(buffer, **arrays)
        path = self._checkpoint_dir / "checkpoint_latest.npz"
        path.write_bytes(buffer.getvalue())

    def load_checkpoint(self) -> dict[str, Any] | None:
        import io

        path = self._checkpoint_dir / "checkpoint_latest.npz"
        if not path.exists():
            return None
        data = io.BytesIO(path.read_bytes())
        return dict(np.load(data, allow_pickle=False))

    @property
    def has_checkpoint(self) -> bool:
        return (self._checkpoint_dir / "checkpoint_latest.npz").exists()

    def _next_log_seq(self) -> int:
        existing = sorted(self._log_dir.glob("log_*.txt"))
        if not existing:
            return 0
        last = existing[-1].stem
        return int(last.split("_")[1]) + 1

    def log(self, msg: str) -> None:
        chunk = self._log_dir / f"log_{self._log_seq:04d}.txt"
        chunk.write_text(msg + "\n")
        self._log_seq += 1
