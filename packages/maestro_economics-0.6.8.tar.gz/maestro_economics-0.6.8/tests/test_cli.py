"""Tests for the mecon CLI."""

from __future__ import annotations

import json
import os

from click.testing import CliRunner

import maestro_economics.cli as cli


def test_get_config_defaults(monkeypatch):
    monkeypatch.setattr(cli, "CONFIG_FILE", "/nonexistent/config.toml")
    monkeypatch.delenv("MECON_API_KEY", raising=False)
    monkeypatch.delenv("MECON_API_BASE", raising=False)

    cfg = cli.get_config()

    assert cfg["api_key"] == ""
    assert cfg["api_base"] == "https://ra.maestro.onl"


def test_env_var_takes_precedence(monkeypatch, tmp_path):
    config_file = tmp_path / "config.toml"
    config_file.write_text('[default]\napi_key = "file-key"\napi_base = "https://file.example"\n')
    monkeypatch.setattr(cli, "CONFIG_FILE", str(config_file))
    monkeypatch.setenv("MECON_API_KEY", "env-key")
    monkeypatch.setenv("MECON_API_BASE", "https://env.example")

    cfg = cli.get_config()

    assert cfg["api_key"] == "env-key"
    assert cfg["api_base"] == "https://env.example"


def test_setup_saves_profile(monkeypatch, tmp_path):
    runner = CliRunner()
    config_dir = tmp_path / ".mecon"
    config_file = config_dir / "config.toml"
    monkeypatch.setattr(cli, "CONFIG_DIR", str(config_dir))
    monkeypatch.setattr(cli, "CONFIG_FILE", str(config_file))

    result = runner.invoke(cli.main, ["setup"], input="test-key\nhttps://api.example\n")

    assert result.exit_code == 0
    saved = config_file.read_text()
    assert 'api_key = "test-key"' in saved
    assert 'api_base = "https://api.example"' in saved


def test_setup_supports_noninteractive_flags(monkeypatch, tmp_path):
    runner = CliRunner()
    config_dir = tmp_path / ".mecon"
    config_file = config_dir / "config.toml"
    monkeypatch.setattr(cli, "CONFIG_DIR", str(config_dir))
    monkeypatch.setattr(cli, "CONFIG_FILE", str(config_file))

    result = runner.invoke(
        cli.main,
        [
            "setup",
            "--api-key",
            "flag-key",
            "--api-base",
            "https://flag.example",
        ],
    )

    assert result.exit_code == 0
    saved = config_file.read_text()
    assert 'api_key = "flag-key"' in saved
    assert 'api_base = "https://flag.example"' in saved


def test_setup_api_key_only_uses_default_api_base_noninteractively(monkeypatch, tmp_path):
    runner = CliRunner()
    config_dir = tmp_path / ".mecon"
    config_file = config_dir / "config.toml"
    monkeypatch.setattr(cli, "CONFIG_DIR", str(config_dir))
    monkeypatch.setattr(cli, "CONFIG_FILE", str(config_file))

    result = runner.invoke(
        cli.main,
        [
            "setup",
            "--api-key",
            "flag-key",
        ],
    )

    assert result.exit_code == 0
    saved = config_file.read_text()
    assert 'api_key = "flag-key"' in saved
    assert 'api_base = "https://ra.maestro.onl"' in saved


def test_main_help():
    runner = CliRunner()

    result = runner.invoke(cli.main, ["--help"])

    assert result.exit_code == 0
    assert "RA Compute CLI" in result.output
    assert "workspace" in result.output
    assert "doctor" in result.output


def test_workspace_init_creates_manifest(monkeypatch, tmp_path):
    runner = CliRunner()
    manifest_path = tmp_path / ".mecon" / "manifest.json"
    (tmp_path / "run.py").write_text("def run(ctx):\n    return {}\n")

    def fake_api(method, path, json_data=None, timeout=30, raw=False):
        assert method == "POST"
        assert path == "/workspace"
        return {"data": {"workspace_id": "ws_123", "r2_prefix": "workspace/ws_123"}}

    monkeypatch.setattr(cli, "api", fake_api)

    with runner.isolated_filesystem(temp_dir=tmp_path):
        os.chdir(tmp_path)
        result = runner.invoke(cli.main, ["workspace", "init"])

    assert result.exit_code == 0
    assert manifest_path.exists()
    assert '"workspace_id": "ws_123"' in manifest_path.read_text()


def test_add_tracks_files(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".mecon").mkdir()
    (tmp_path / ".mecon" / "manifest.json").write_text(
        '{"project":"demo","workspace_id":"ws_123","files":{},"entry":"run.py"}'
    )
    (tmp_path / "run.py").write_text("def run(ctx):\n    return {}\n")

    result = runner.invoke(cli.main, ["add", "run.py"])

    assert result.exit_code == 0
    manifest = (tmp_path / ".mecon" / "manifest.json").read_text()
    assert '"run.py"' in manifest


def test_add_skips_default_ignore_patterns(monkeypatch, tmp_path):
    """`mecon add **` must not capture __pycache__/, .git/, .pyc, .DS_Store
    etc. Stale .pyc on R2 is one of the failure modes that masked aowang's
    BCH_347 numerical drift (Codex 2026-04-27)."""
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".mecon").mkdir()
    (tmp_path / ".mecon" / "manifest.json").write_text(
        '{"project":"demo","workspace_id":"ws_123","files":{},"entry":"run.py"}'
    )
    (tmp_path / "run.py").write_text("def run(ctx):\n    return {}\n")
    # Things we expect to be skipped:
    pycache = tmp_path / "__pycache__"
    pycache.mkdir()
    (pycache / "run.cpython-311.pyc").write_text("stale bytecode")
    (tmp_path / "stale_helper.pyc").write_text("stale bytecode")
    git_dir = tmp_path / ".git"
    git_dir.mkdir()
    (git_dir / "HEAD").write_text("ref: refs/heads/main\n")

    result = runner.invoke(cli.main, ["add", "**"])

    assert result.exit_code == 0
    manifest_text = (tmp_path / ".mecon" / "manifest.json").read_text()
    assert "run.py" in manifest_text
    assert "__pycache__" not in manifest_text
    assert ".pyc" not in manifest_text
    assert ".git" not in manifest_text


def test_doctor_reports_missing_prereqs(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli, "CONFIG_FILE", str(tmp_path / "missing-config.toml"))
    monkeypatch.delenv("MECON_API_KEY", raising=False)
    monkeypatch.delenv("MECON_API_BASE", raising=False)

    result = runner.invoke(cli.main, ["doctor"])

    assert result.exit_code == 0
    assert "API key configured" in result.output
    assert "workspace manifest" in result.output
    assert "Doctor result:" in result.output


def test_doctor_supports_json_output(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(cli, "CONFIG_FILE", str(tmp_path / "missing-config.toml"))
    monkeypatch.delenv("MECON_API_KEY", raising=False)
    monkeypatch.delenv("MECON_API_BASE", raising=False)

    result = runner.invoke(cli.main, ["doctor", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["ready"] is False
    assert payload["failed_checks"] >= 1
    assert any(check["name"] == "API key configured" for check in payload["checks"])
    assert any("mecon setup" in fix for fix in payload["fixes"])


def test_submit_workspace_fails_when_tracked_files_are_unsynced(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".mecon").mkdir()
    (tmp_path / "run.py").write_text("def run(ctx):\n    return {}\n")
    (tmp_path / ".mecon" / "manifest.json").write_text(
        json.dumps(
            {
                "project": "demo",
                "workspace_id": "ws_123",
                "entry": "run.py",
                "files": {
                    "run.py": {
                        "sha256": "abc",
                        "size": 24,
                        "synced_at": None,
                    }
                },
            }
        )
    )

    api_calls: list[tuple[str, str]] = []

    def fake_api(method, path, json_data=None, timeout=30, raw=False):
        api_calls.append((method, path))
        return {"data": {"job_id": "job_123"}}

    monkeypatch.setattr(cli, "api", fake_api)

    result = runner.invoke(cli.main, ["submit", "--no-watch"])

    assert result.exit_code == 1
    assert "Run 'mecon sync' before submit." in result.output
    assert api_calls == []


def test_submit_workspace_sends_manifest_file_whitelist(monkeypatch, tmp_path):
    runner = CliRunner()
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".mecon").mkdir()
    (tmp_path / "run.py").write_text("def run(ctx):\n    return {}\n")
    (tmp_path / ".mecon" / "manifest.json").write_text(
        json.dumps(
            {
                "project": "demo",
                "workspace_id": "ws_123",
                "entry": "run.py",
                "files": {
                    "run.py": {"sha256": "a", "size": 24, "synced_at": "2026-04-27T00:00:00Z"},
                    "pkg/helper.py": {"sha256": "b", "size": 10, "synced_at": "2026-04-27T00:00:00Z"},
                    "data/panel.parquet": {"sha256": "c", "size": 10, "synced_at": "2026-04-27T00:00:00Z"},
                },
            }
        )
    )

    captured: dict = {}

    def fake_api(method, path, json_data=None, timeout=30, raw=False, extra_headers=None):  # noqa: ANN001
        captured.update({"method": method, "path": path, "json_data": json_data, "headers": extra_headers})
        return {"run_id": "run_123", "modal_call_id": "fc-123", "status": "queued"}

    monkeypatch.setattr(cli, "api", fake_api)

    result = runner.invoke(cli.main, ["submit", "--no-watch"])

    assert result.exit_code == 0
    assert captured["path"] == "/runs"
    assert captured["json_data"]["config"]["entry"] == "run.py"
    assert captured["json_data"]["config"]["workspace_files"] == [
        "data/panel.parquet",
        "pkg/helper.py",
        "run.py",
    ]


# ---------------------------------------------------------------------------
# Version-hint capture and enforcement
# ---------------------------------------------------------------------------


class _FakeResponse:
    def __init__(self, headers):
        self.headers = headers


def test_capture_version_hints_records_headers():
    cli._version_hints["latest"] = None
    cli._version_hints["min_supported"] = None
    cli._capture_version_hints(
        _FakeResponse({"X-Mecon-Latest": "1.2.3", "X-Mecon-Min-Supported": "0.9.0"})
    )
    assert cli._version_hints["latest"] == "1.2.3"
    assert cli._version_hints["min_supported"] == "0.9.0"


def test_capture_version_hints_case_insensitive():
    cli._version_hints["latest"] = None
    cli._version_hints["min_supported"] = None
    cli._capture_version_hints(
        _FakeResponse({"x-mecon-latest": "2.0.0", "x-mecon-min-supported": "1.5.0"})
    )
    assert cli._version_hints["latest"] == "2.0.0"
    assert cli._version_hints["min_supported"] == "1.5.0"


def test_capture_version_hints_preserves_when_headers_missing():
    cli._version_hints["latest"] = "9.9.9"
    cli._version_hints["min_supported"] = "5.5.5"
    cli._capture_version_hints(_FakeResponse({}))
    assert cli._version_hints["latest"] == "9.9.9"
    assert cli._version_hints["min_supported"] == "5.5.5"


def test_version_tuple_handles_prereleases():
    assert cli._version_tuple("0.4.0") == (0, 4, 0)
    assert cli._version_tuple("0.4.0rc1") == (0, 4, 0)
    assert cli._version_tuple("0.4") == (0, 4)


def test_is_older_basic():
    assert cli._is_older("0.3.1", "0.4.0") is True
    assert cli._is_older("0.4.0", "0.4.0") is False
    assert cli._is_older("0.5.0", "0.4.0") is False


def test_maybe_show_upgrade_notice_emits_on_stale(monkeypatch, capsys):
    cli._version_hints["latest"] = "0.9.0"
    monkeypatch.setattr(cli, "_get_version", lambda: "0.4.0")
    cli._maybe_show_upgrade_notice()
    captured = capsys.readouterr()
    assert "0.9.0 is available" in captured.err
    assert "pip install -U maestro-economics" in captured.err


def test_maybe_show_upgrade_notice_silent_when_current(monkeypatch, capsys):
    cli._version_hints["latest"] = "0.4.0"
    monkeypatch.setattr(cli, "_get_version", lambda: "0.4.0")
    cli._maybe_show_upgrade_notice()
    captured = capsys.readouterr()
    assert captured.err == ""


def test_maybe_show_upgrade_notice_silent_when_no_hint(capsys):
    cli._version_hints["latest"] = None
    cli._maybe_show_upgrade_notice()
    captured = capsys.readouterr()
    assert captured.err == ""


def test_enforce_min_supported_exits_when_below(monkeypatch, capsys):
    cli._version_hints["min_supported"] = "1.0.0"
    monkeypatch.setattr(cli, "_get_version", lambda: "0.4.0")
    import pytest

    with pytest.raises(SystemExit) as exc_info:
        cli._enforce_min_supported()
    assert exc_info.value.code == 2
    captured = capsys.readouterr()
    assert "below the minimum supported version 1.0.0" in captured.err


def test_enforce_min_supported_passes_when_at_or_above(monkeypatch):
    cli._version_hints["min_supported"] = "0.4.0"
    monkeypatch.setattr(cli, "_get_version", lambda: "0.4.0")
    cli._enforce_min_supported()  # must not raise
    monkeypatch.setattr(cli, "_get_version", lambda: "0.5.0")
    cli._enforce_min_supported()  # must not raise


def test_api_retries_5xx_with_backoff(monkeypatch):
    """api() retries up to 3 times on 5xx, succeeds on final 2xx."""
    import maestro_economics.cli as cli

    monkeypatch.setattr(cli, "get_config", lambda: {"api_key": "k", "api_base": "https://api.test"})
    monkeypatch.setattr(cli.time, "sleep", lambda _s: None)

    class FakeResponse:
        def __init__(self, status: int, text: str = ""):
            self.status_code = status
            self.text = text
            self.headers: dict = {}

        def json(self):
            return {"success": True, "data": {"ok": 1}}

    calls: list[int] = []

    def fake_request(method, url, **kw):
        calls.append(len(calls))
        if len(calls) < 3:
            return FakeResponse(502, "bad gateway")
        return FakeResponse(200)

    monkeypatch.setattr(cli.httpx, "request", fake_request)

    result = cli.api("POST", "/runs", json_data={}, extra_headers={"Idempotency-Key": "abc"})

    assert result == {"ok": 1}
    assert len(calls) == 3


def test_api_exits_on_4xx_without_retry(monkeypatch):
    """4xx is permanent — api() exits immediately, no retry."""
    import maestro_economics.cli as cli
    import pytest

    monkeypatch.setattr(cli, "get_config", lambda: {"api_key": "k", "api_base": "https://api.test"})
    monkeypatch.setattr(cli.time, "sleep", lambda _s: None)

    class FakeResponse:
        status_code = 400
        text = "bad request"
        headers: dict = {}

        def json(self):
            return {}

    calls: list[int] = []

    def fake_request(method, url, **kw):
        calls.append(len(calls))
        return FakeResponse()

    monkeypatch.setattr(cli.httpx, "request", fake_request)

    with pytest.raises(SystemExit) as exc:
        cli.api("POST", "/runs", json_data={})

    assert exc.value.code == 1
    assert len(calls) == 1  # no retry on 4xx


def test_api_retries_connect_error_then_succeeds(monkeypatch):
    """ConnectError is retried; a 2xx on a later attempt is honored."""
    import maestro_economics.cli as cli
    import httpx

    monkeypatch.setattr(cli, "get_config", lambda: {"api_key": "k", "api_base": "https://api.test"})
    monkeypatch.setattr(cli.time, "sleep", lambda _s: None)

    class FakeResponse:
        status_code = 200
        text = ""
        headers: dict = {}

        def json(self):
            return {"success": True, "data": {"ok": 1}}

    calls = {"n": 0}

    def fake_request(method, url, **kw):
        calls["n"] += 1
        if calls["n"] == 1:
            raise httpx.ConnectError("conn refused")
        return FakeResponse()

    monkeypatch.setattr(cli.httpx, "request", fake_request)

    result = cli.api("GET", "/jobs/x")
    assert result == {"ok": 1}
    assert calls["n"] == 2


def test_api_exits_after_exhausted_retries(monkeypatch):
    """Transport errors exhaust retries → sys.exit(1) with helpful kind label."""
    import maestro_economics.cli as cli
    import httpx
    import pytest

    monkeypatch.setattr(cli, "get_config", lambda: {"api_key": "k", "api_base": "https://api.test"})
    monkeypatch.setattr(cli.time, "sleep", lambda _s: None)

    calls = {"n": 0}

    def fake_request(method, url, **kw):
        calls["n"] += 1
        raise httpx.TimeoutException("deadline")

    monkeypatch.setattr(cli.httpx, "request", fake_request)

    with pytest.raises(SystemExit) as exc:
        cli.api("POST", "/runs", json_data={})

    assert exc.value.code == 1
    assert calls["n"] == 3


# ---------------------------------------------------------------------------
# mecon precompile — local JIT preflight
# Motivated by the 2026-04-24 customer incident where a JAX 0.5.0 compile
# hang (upstream #26767) burned 4 h of L4 before we noticed. Precompile is
# the customer-side catch: if it hangs locally on CPU, do not submit.
# ---------------------------------------------------------------------------


def test_precompile_passes_quickly_runnable_script(tmp_path):
    """A run.py that returns immediately should exit 0 within the deadline."""
    import maestro_economics.cli as cli

    (tmp_path / "run.py").write_text(
        "def run(ctx):\n    ctx.progress(1.0, 'nothing to do')\n    return {}\n"
    )
    runner = CliRunner()
    result = runner.invoke(cli.main, ["precompile", str(tmp_path), "--timeout", "30"])
    assert result.exit_code == 0, result.output
    assert "[precompile]" in result.output


def test_precompile_flags_timeout_as_jit_hang(tmp_path):
    """A run.py that blocks past the deadline → exit 124 with the known-bug hint.

    We use time.sleep (not an actual JAX compile) to stand in for the hang —
    the server-visible signature is identical: no exit, no callback, no
    progress. Our job is to detect 'process did not return in time', not to
    actually trigger XLA's pathological optimiser pass.
    """
    import maestro_economics.cli as cli

    (tmp_path / "run.py").write_text(
        "import time\n"
        "def run(ctx):\n"
        "    ctx.progress(0.14, 'Setting up evaluator (JIT warmup)')\n"
        "    time.sleep(30)\n"
    )
    runner = CliRunner()
    # 2s deadline keeps the test fast but still gives the subprocess time
    # to boot Python and print the progress line.
    result = runner.invoke(cli.main, ["precompile", str(tmp_path), "--timeout", "2"])
    assert result.exit_code == 124, result.output
    assert "PRECOMPILE TIMED OUT" in result.output
    assert "jax-ml/jax/issues/26767" in result.output


def test_precompile_rejects_missing_entry(tmp_path):
    import maestro_economics.cli as cli

    runner = CliRunner()
    result = runner.invoke(cli.main, ["precompile", str(tmp_path)])
    assert result.exit_code == 1
    assert "not found" in result.output


def test_precompile_rejects_invalid_config_json(tmp_path):
    import maestro_economics.cli as cli

    (tmp_path / "run.py").write_text("def run(ctx): return {}\n")
    runner = CliRunner()
    result = runner.invoke(
        cli.main, ["precompile", str(tmp_path), "--config", "{not json"],
    )
    assert result.exit_code == 1
    assert "not valid JSON" in result.output


def test_submit_help_lists_gpu_tier_choices():
    """The tier table must ship in --help so customers stop defaulting to L4 blindly."""
    import maestro_economics.cli as cli

    runner = CliRunner()
    result = runner.invoke(cli.main, ["submit", "--help"])
    assert result.exit_code == 0
    for tier in ("t4", "l4", "a10g", "l40s", "a100", "h100"):
        assert tier in result.output
    assert "24GB" in result.output  # L4 / A10G VRAM line present
    assert "80GB" in result.output  # A100 / H100 VRAM line present


def test_submit_rejects_unknown_gpu_tier(tmp_path):
    import maestro_economics.cli as cli

    (tmp_path / "run.py").write_text("def run(ctx): return {}\n")
    runner = CliRunner()
    result = runner.invoke(
        cli.main, ["submit", str(tmp_path / "run.py"), "--gpu", "banana"],
    )
    # click.Choice converts invalid values into UsageError → exit code 2
    assert result.exit_code == 2
    assert "'banana' is not one of" in result.output or "Invalid value" in result.output


# ---------------------------------------------------------------------------
# mecon status / watch — Phase 4 liveness surfacing
# ---------------------------------------------------------------------------


def test_status_human_output_highlights_stall(monkeypatch):
    """is_stalled=true MUST render a visible ⚠ STALLED tag so agents notice."""
    import maestro_economics.cli as cli

    monkeypatch.setattr(
        cli,
        "api",
        lambda *a, **k: {
            "id": "j_1",
            "status": "running",
            "progress_pct": 14,
            "progress_message": "Setting up evaluator (JIT warmup)",
            "seconds_since_update": 720,
            "seconds_since_activity": 720,
            "seconds_since_progress": 720,
            "seconds_since_heartbeat": 180,
            "is_stalled": True,
            "heartbeat_stale": True,
            "error_message": None,
        },
    )
    runner = CliRunner()
    result = runner.invoke(cli.main, ["status", "j_1"])

    assert result.exit_code == 0
    assert "⚠ STALLED" in result.output
    assert "⚠ CONTAINER DEAD" in result.output
    assert "12m 00s ago" in result.output  # 720s = 12m
    assert "3m 00s ago" in result.output  # 180s = 3m
    assert "running" in result.output


def test_status_human_output_shows_activity_when_progress_label_is_stale(monkeypatch):
    """A long-running search can keep logging after the last progress callback."""
    import maestro_economics.cli as cli

    monkeypatch.setattr(
        cli,
        "api",
        lambda *a, **k: {
            "id": "j_active",
            "status": "running",
            "progress_pct": 14,
            "progress_message": "Setting up evaluator (JIT warmup)",
            "seconds_since_update": 8,
            "seconds_since_activity": 8,
            "seconds_since_progress": 2388,
            "seconds_since_heartbeat": 18,
            "latest_activity_message": "gen= 455  nfev=  6825  rate=1.6/s",
            "is_stalled": False,
            "heartbeat_stale": False,
        },
    )
    runner = CliRunner()
    result = runner.invoke(cli.main, ["status", "j_active"])

    assert result.exit_code == 0
    assert "Last activity:  8s ago" in result.output
    assert "Latest activity: gen= 455  nfev=  6825  rate=1.6/s" in result.output
    assert "Last progress:  39m 48s ago" in result.output
    assert "⚠" not in result.output


def test_status_human_output_renders_server_advice(monkeypatch):
    """The API owns diagnosis rules; the CLI renders any advice item generically."""
    import maestro_economics.cli as cli

    monkeypatch.setattr(
        cli,
        "api",
        lambda *a, **k: {
            "id": "j_active",
            "status": "running",
            "progress_pct": 14,
            "progress_message": "Setting up evaluator (JIT warmup)",
            "seconds_since_update": 8,
            "seconds_since_activity": 8,
            "seconds_since_progress": 2388,
            "seconds_since_heartbeat": 18,
            "is_stalled": False,
            "heartbeat_stale": False,
            "server_advice": [
                {
                    "level": "info",
                    "code": "progress_label_stale_but_activity_fresh",
                    "title": "Progress label is stale, but the job is active",
                    "message": "Fresh worker activity is arriving.",
                    "action": "Keep monitoring latest activity and ETA.",
                    "command": "mecon status j_active",
                    "docs": "docs/compute-workflow-control-plane.md",
                }
            ],
        },
    )
    runner = CliRunner()
    result = runner.invoke(cli.main, ["status", "j_active"])

    assert result.exit_code == 0
    assert "Server advice:" in result.output
    assert "[INFO] Progress label is stale, but the job is active" in result.output
    assert "Fresh worker activity is arriving." in result.output
    assert "Action: Keep monitoring latest activity and ETA." in result.output
    assert "Command: mecon status j_active" in result.output
    assert "Docs: docs/compute-workflow-control-plane.md" in result.output


def test_status_human_output_hides_stall_when_fresh(monkeypatch):
    """A healthy job must not scare the user with a false-positive warning."""
    import maestro_economics.cli as cli

    monkeypatch.setattr(
        cli,
        "api",
        lambda *a, **k: {
            "id": "j_1",
            "status": "running",
            "progress_pct": 42,
            "progress_message": "nfev=500",
            "seconds_since_update": 4,
            "seconds_since_activity": 4,
            "seconds_since_progress": 4,
            "seconds_since_heartbeat": 12,
            "is_stalled": False,
            "heartbeat_stale": False,
        },
    )
    runner = CliRunner()
    result = runner.invoke(cli.main, ["status", "j_1"])

    assert result.exit_code == 0
    assert "⚠" not in result.output
    assert "4s ago" in result.output
    assert "12s ago" in result.output


def test_status_json_flag_emits_raw_payload(monkeypatch):
    """--json stays stable for scripts even as the human format evolves."""
    import json as _json
    import maestro_economics.cli as cli

    payload = {"id": "j_1", "status": "running", "is_stalled": True}
    monkeypatch.setattr(cli, "api", lambda *a, **k: payload)
    runner = CliRunner()
    result = runner.invoke(cli.main, ["status", "j_1", "--json"])

    assert result.exit_code == 0
    parsed = _json.loads(result.output)
    assert parsed == payload


def test_failure_advice_detects_xla_gpu_oom():
    import maestro_economics.cli as cli

    lines = cli._failure_advice_lines(
        {"status": "failed", "gpu_type": "l4", "progress_message": "Setting up evaluator"},
        "jaxlib.xla_extension.XlaRuntimeError: RESOURCE_EXHAUSTED: Out of memory",
        {
            "gpu_type": "l4",
            "summary": {
                "gpu_mem_used_max_mb": 23200,
                "gpu_mem_total_mb": 24576,
                "cgroup_oom_count_max": 1,
            },
        },
    )

    joined = "\n".join(lines)
    assert "GPU/XLA out of memory" in joined
    assert "--gpu l40s" in joined
    assert "smaller choice/menu grid" in joined


def test_failure_advice_distinguishes_xla_hang_from_oom():
    import maestro_economics.cli as cli

    lines = cli._failure_advice_lines(
        {
            "status": "failed",
            "gpu_type": "l4",
            "progress_message": "Setting up evaluator (JIT warmup)",
            "error_message": "Watchdog: worker progress callback silent for 760s",
        },
        "",
        {
            "gpu_type": "l4",
            "summary": {
                "gpu_mem_used_max_mb": 200,
                "gpu_mem_total_mb": 23034,
            },
        },
    )

    joined = "\n".join(lines)
    assert "not proven GPU OOM" in joined
    assert "precompile" in joined
    assert "upgrading GPU alone may not help" in joined


def test_watch_auto_escalates_on_heartbeat_stale(monkeypatch):
    """First poll where heartbeat_stale flips true -> pull logs and warn once."""
    import maestro_economics.cli as cli

    # First poll flips heartbeat_stale true; second poll is the terminal
    # failed row (reaper caught it). Auto-escalate fires once.
    poll_sequence = [
        {
            "status": "running",
            "progress_pct": 14,
            "progress_message": "Setting up evaluator",
            "seconds_since_heartbeat": 200,
            "seconds_since_update": 30,
            "is_stalled": False,
            "heartbeat_stale": True,
        },
        {
            "status": "failed",
            "progress_pct": 14,
            "progress_message": "heartbeat silent",
            "error_message": "Watchdog: worker heartbeat silent for 240s",
        },
    ]
    logs_seen: list[str] = []

    def fake_api(method, path, **_kw):
        if "/logs" in path:
            logs_seen.append(path)
            return {"content": "line A\nline B\nline C\n"}
        return poll_sequence.pop(0)

    monkeypatch.setattr(cli, "api", fake_api)
    monkeypatch.setattr(cli.time, "sleep", lambda *_a, **_kw: None)

    runner = CliRunner()
    result = runner.invoke(cli.main, ["watch", "j_1", "--interval", "0"])

    assert result.exit_code == 0
    assert "⚠ CONTAINER DEAD" in result.output
    assert "Heartbeat silent" in result.output
    assert "line A" in result.output
    assert len(logs_seen) == 1, "auto-escalate must pull logs exactly once per stall"


def test_watch_failed_oom_pulls_logs_and_prints_upgrade_advice(monkeypatch):
    """Terminal failed rows should diagnose OOM without the user running debug."""
    import maestro_economics.cli as cli

    poll_sequence = [
        {
            "status": "failed",
            "gpu_type": "l4",
            "progress_pct": 14,
            "progress_message": "Setting up evaluator",
            "error_message": "XlaRuntimeError: RESOURCE_EXHAUSTED",
        }
    ]

    def fake_api(method, path, **_kw):
        if path.endswith("/profile"):
            return {
                "gpu_type": "l4",
                "summary": {
                    "gpu_mem_used_max_mb": 23200,
                    "gpu_mem_total_mb": 24576,
                },
            }
        if "/logs" in path:
            return {"content": "RESOURCE_EXHAUSTED: CUDA out of memory\n"}
        return poll_sequence.pop(0)

    monkeypatch.setattr(cli, "api", fake_api)
    monkeypatch.setattr(cli.time, "sleep", lambda *_a, **_kw: None)

    runner = CliRunner()
    result = runner.invoke(cli.main, ["watch", "j_1", "--interval", "0"])

    assert result.exit_code == 0
    assert "GPU/XLA out of memory" in result.output
    assert "--gpu l40s" in result.output
    assert "RESOURCE_EXHAUSTED" in result.output


def test_watch_timed_out_is_not_reported_as_failed(monkeypatch):
    """A configured time budget stop is a terminal outcome, not a crash."""
    import maestro_economics.cli as cli

    poll_sequence = [
        {
            "status": "timed_out",
            "gpu_type": "l4",
            "progress_pct": 100,
            "progress_message": "Job exceeded timeout of 14400 seconds",
            "server_advice": [
                {
                    "level": "warning",
                    "title": "Run exhausted its time budget",
                    "message": "The worker stayed alive until the configured timeout.",
                    "action": "Sync partial outputs and resume from checkpoints.",
                }
            ],
        }
    ]

    def fake_api(method, path, **_kw):
        if path.endswith("/profile"):
            return {
                "gpu_type": "l4",
                "summary": {
                    "sample_count": 1345,
                    "gpu_util_avg": 9.5,
                    "gpu_util_p50": 0,
                    "gpu_util_p95": 52,
                    "gpu_util_max": 98,
                    "gpu_mem_used_max_mb": 17136,
                    "gpu_mem_total_mb": 23034,
                },
                "recommendation": {
                    "suggestion": "optimize_workload",
                    "rationale": "gpu_util_avg=9.5%, gpu_util_p50=0.0%, gpu_util_p95=52.0%, vram_peak=74.4%.",
                    "action": "Batch/vectorize candidate evaluations.",
                },
            }
        return poll_sequence.pop(0)

    monkeypatch.setattr(cli, "api", fake_api)
    monkeypatch.setattr(cli.time, "sleep", lambda *_a, **_kw: None)

    runner = CliRunner()
    result = runner.invoke(cli.main, ["watch", "j_1", "--interval", "0"])

    assert result.exit_code == 0
    assert "Job stopped at its configured time budget" in result.output
    assert "Run exhausted its time budget" in result.output
    assert "Performance advice" in result.output
    assert "GPU is under-utilised" in result.output
    assert "gpu_util_avg=9.5%" in result.output
    assert "Job failed" not in result.output


def test_profile_flags_host_bound_low_gpu_utilization(monkeypatch):
    import maestro_economics.cli as cli

    def fake_api(method, path, **_kw):
        assert path.endswith("/profile")
        return {
            "job_id": "j_low",
            "gpu_type": "l4",
            "summary": {
                "sample_count": 1345,
                "gpu_util_avg": 9.5,
                "gpu_util_p50": 0,
                "gpu_util_p95": 52,
                "gpu_util_max": 98,
                "gpu_mem_used_max_mb": 17136,
                "gpu_mem_total_mb": 23034,
                "cpu_pct_p50": 20,
                "cpu_pct_p95": 80,
                "rss_peak_mb": 9000,
                "jax_peak_mb": 8000,
                "cgroup_mem_peak_mb": 10000,
            },
            "recommendation": {
                "suggestion": "optimize_workload",
                "rationale": "gpu_util_avg=9.5%, gpu_util_p50=0.0%, gpu_util_p95=52.0%, vram_peak=74.4%.",
                "action": "Batch/vectorize candidate evaluations.",
            },
        }

    monkeypatch.setattr(cli, "api", fake_api)
    runner = CliRunner()
    result = runner.invoke(cli.main, ["profile", "j_low"])

    assert result.exit_code == 0
    assert "avg=9.5%" in result.output
    assert "p50=0%" in result.output
    assert "Recommendation: ! optimize_workload" in result.output
    assert "Batch/vectorize candidate evaluations" in result.output


def test_logs_surfaces_error_message_when_no_log_chunks(monkeypatch):
    import maestro_economics.cli as cli

    def fake_api(method, path, raw=False, **_kw):
        if path.endswith("/profile"):
            return {"gpu_type": "l4", "summary": {}}
        return {
            "status": "failed",
            "error_message": "Watchdog: worker progress callback silent for 760s",
            "content": "",
            "next_since": 0,
        }

    monkeypatch.setattr(cli, "api", fake_api)
    runner = CliRunner()
    result = runner.invoke(cli.main, ["logs", "j_1"])

    assert result.exit_code == 0
    assert "error_message: Watchdog" in result.output


def test_watch_no_escalate_flag_suppresses_logs(monkeypatch):
    """`--no-escalate` lets CI / scripted pollers opt out cleanly."""
    import maestro_economics.cli as cli

    poll_sequence = [
        {
            "status": "running",
            "progress_pct": 14,
            "is_stalled": True,
            "heartbeat_stale": False,
        },
        {"status": "failed", "error_message": "watchdog"},
    ]
    logs_seen: list[str] = []

    def fake_api(method, path, **_kw):
        if "/logs" in path:
            logs_seen.append(path)
            return {"content": "should not be pulled"}
        return poll_sequence.pop(0)

    monkeypatch.setattr(cli, "api", fake_api)
    monkeypatch.setattr(cli.time, "sleep", lambda *_a, **_kw: None)

    runner = CliRunner()
    result = runner.invoke(
        cli.main, ["watch", "j_1", "--interval", "0", "--no-escalate"],
    )

    assert result.exit_code == 0
    assert "⚠ STALLED" in result.output
    assert logs_seen == [], "--no-escalate must prevent log pull"
