"""
Example: Simultaneous cell and geometry optimization for bulk silicon.

Demonstrates using ASE's FrechetCellFilter with the RIPER calculator
to relax both atomic positions and lattice parameters.
We start from a slightly distorted cell to show optimization at work.
"""
import numpy as np
from ase.build import bulk
from ase.optimize import LBFGS
from ase.filters import FrechetCellFilter
from riper import RIPERCalculator
from ase.io import write

# Build bulk silicon with a slightly off lattice constant
si = bulk("Si", "diamond", a=5.50)  # experimental ~5.43 Å

a_init = np.linalg.norm(si.cell[0])
print("=== Bulk Silicon — Cell + Geometry Optimization ===")
print(f"PBC: {si.pbc}")
print(f"Number of atoms: {len(si)}")
print(f"Initial lattice constant: {a_init:.4f} Å")
print()

# Save initial structure
write("calculations/si_initial.cif", si)

# Set up calculator
calc = RIPERCalculator(
    functional="pbe",
    basis="pob-DZVP-rev2",
    auxbasis="universal",
    nkpoints=[9, 9, 9],
    scfconv=8, # Tighter conv criterion than default
    scfiterlimit=100,
    riper_command="riper_smp",
    directory="calculations/calc_si_opt",
)

si.calc = calc

# FrechetCellFilter wraps atoms so optimizer relaxes cell + positions together
# It uses a proper metric for cell degrees of freedom, giving more stable
# and efficient convergence compared to UnitCellFilter
fcf = FrechetCellFilter(si)
opt = LBFGS(fcf, trajectory="calculations/calc_si_opt/opt.traj")
opt.run(fmax=0.01)

# Results
a_opt = np.linalg.norm(si.cell[0])
energy = si.get_potential_energy()

print()
print("=== Results ===")
print(f"Initial lattice constant: {a_init:.4f} Å")
print(f"Optimized lattice constant: {a_opt:.4f} Å")
print(f"Energy: {energy:.6f} eV")
print()
print("Optimized cell (Å):")
for i, vec in enumerate(si.cell):
    print(f"  a{i+1}: [{vec[0]:8.4f}, {vec[1]:8.4f}, {vec[2]:8.4f}]")

# Save optimized structure
write("calculations/si_optimized.cif", si)