from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AtlasChart:
    name: str
    coordinates: tuple[str, ...]
    domain: str = "default"


def chart_index(charts: list[AtlasChart]) -> dict[str, list[str]]:
    index: dict[str, list[str]] = {}
    for chart in charts:
        for coordinate in chart.coordinates:
            index.setdefault(coordinate, []).append(chart.name)
    return {key: sorted(values) for key, values in index.items()}


def covering_charts(charts: list[AtlasChart], coordinates: set[str]) -> list[str]:
    matches = [
        chart.name
        for chart in charts
        if coordinates <= set(chart.coordinates)
    ]
    return sorted(matches)


def coordinate_union(charts: list[AtlasChart], domain: str | None = None) -> list[str]:
    selected = [chart for chart in charts if domain is None or chart.domain == domain]
    coordinates = {coordinate for chart in selected for coordinate in chart.coordinates}
    return sorted(coordinates)
