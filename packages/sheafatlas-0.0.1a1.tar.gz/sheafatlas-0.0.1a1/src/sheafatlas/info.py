from __future__ import annotations


def project_info() -> dict[str, str]:
    return {
        "name": "sheafatlas",
        "version": "0.0.1a1",
        "repository": "https://github.com/SheafLab/sheafatlas-python",
    }
