from __future__ import annotations

from .info import project_info


def main() -> None:
    info = project_info()
    print(f"{info['name']} {info['version']} ({info['repository']})")


if __name__ == "__main__":
    main()
