# sheafatlas

`sheafatlas` is the official Python package namespace for atlas and chart
helpers in the SheafLab project.

This initial public release provides a compact but real core for describing
named charts, indexing chart coverage, and selecting charts that cover a
requested coordinate set.
