import unittest

from sheafatlas import AtlasChart, chart_index, coordinate_union, covering_charts


class AtlasTests(unittest.TestCase):
    def setUp(self) -> None:
        self.charts = [
            AtlasChart("local", ("x", "y"), "plane"),
            AtlasChart("global", ("x", "y", "z"), "space"),
            AtlasChart("depth", ("z",), "space"),
        ]

    def test_chart_index_groups_chart_names_by_coordinate(self) -> None:
        self.assertEqual(chart_index(self.charts)["z"], ["depth", "global"])

    def test_covering_charts_selects_supersets(self) -> None:
        self.assertEqual(covering_charts(self.charts, {"x", "y"}), ["global", "local"])

    def test_coordinate_union_can_filter_by_domain(self) -> None:
        self.assertEqual(coordinate_union(self.charts, "space"), ["x", "y", "z"])
