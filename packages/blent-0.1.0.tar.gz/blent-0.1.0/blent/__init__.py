def hello():
    print("Hello from Blent! This is your first PyPI-ready project.")

if __name__ == "__main__":
    hello()
