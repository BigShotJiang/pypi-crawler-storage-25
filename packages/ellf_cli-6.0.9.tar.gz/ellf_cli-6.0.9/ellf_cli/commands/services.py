import builtins
from collections.abc import Sequence
from typing import Optional, Union
from uuid import UUID

from radicli import Arg
from wasabi import msg

from ellf_pam_sdk.models import ServiceDetail, ServiceSummary

from ..cli import cli
from ..errors import BrokerError, CLIError, EllfError, HTTPXErrors
from ..messages import Messages
from ..query import (
    delete_job,
    resolve_recipe,
    resolve_service,
    start_job,
    stop_job,
)
from ..ui import (
    print_args_table,
    print_info_table,
    print_logs,
    print_mutation_result,
    print_recipes_help,
    print_table_with_select,
)
from ._recipe_subcommand import (
    create_from_recipe,
    create_from_recipe_file,
    request_recipes,
)
from ._state import get_auth_state, get_saved_settings


@cli.subcommand_with_extra(
    "services",
    "create",
    exists_ok=Arg("--exists-ok", help=Messages.exists_ok),
    no_start=Arg("--no-start", help=Messages.no_start),
    no_wait=Arg("--no-wait", help=Messages.no_wait.format(noun="service")),
    _show_help=Arg("--help", "-h", help=Messages.help),
)
def create(
    exists_ok: bool = False,
    no_start: bool = False,
    no_wait: bool = False,
    _show_help: bool = False,
    _extra: builtins.list[str] = [],
) -> UUID | None:
    """
    Create a new service. The available service recipes are fetched from your
    cluster and are added as dynamic subcommands. You can see more details
    and available arguments by calling the subcommand with --help, e.g. create
    [name] --help
    """
    auth = get_auth_state()
    settings = get_saved_settings()
    is_file_mode = settings.recipes_file is not None
    try:
        schemas = request_recipes(auth=auth, job_type="service")
    except EllfError as e:
        raise CLIError(Messages.E009, e)
    except HTTPXErrors as e:
        raise CLIError(Messages.E009, e)
    if not _extra:
        print_recipes_help(schemas, "Create a new service", "services create")
        return None
    args = [*_extra]
    name = args.pop(0)
    if name not in schemas:
        opts = f"Available: {', '.join(schemas.keys())}"
        raise CLIError(Messages.E010.format(noun="service", name=name), opts)
    if is_file_mode:
        schema = schemas[name]
        job_spec = create_from_recipe_file(
            schema, args, command="services", show_help=_show_help, job_type="service"
        )
        msg.good(Messages.T002.format(noun="service", name=job_spec.name))
        print_args_table(job_spec.plan.args or {}, job_spec.plan.cli_names or {})
        if not no_start:
            response = auth.broker_client.jobs.start_job(job_spec)
            if response.cluster_change is not None:
                msg.good(Messages.T005.format(noun="service", name=job_spec.job_id))
            elif response.cluster_error is not None:
                raise CLIError(
                    Messages.E025.format(noun="service", name=job_spec.job_id),
                    response.cluster_error,
                )
        return job_spec.job_id
    schema = resolve_recipe(name, cluster_id=auth.cluster_id)
    service_id, plan = create_from_recipe(
        schema, args, command="services", show_help=_show_help, exists_ok=exists_ok
    )
    msg.good(Messages.T002.format(noun="service", name=service_id))
    print_args_table(plan.args, schema.form_schema.cli_names)
    if not no_start:
        try:
            start(service_id, no_wait=no_wait)
        except Exception:
            auth.client.service.delete(id=service_id)
            raise
    return service_id


@cli.subcommand(
    "services",
    "list",
    select=Arg(
        "--select",
        help=Messages.select.format(
            opts=[*builtins.list(ServiceSummary.model_fields), "state"]
        ),
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def list(
    select: builtins.list[str] = ["id", "name", "state", "project_name"],
    as_json: bool = False,
) -> Sequence[ServiceSummary]:
    """List the services on the cluster."""
    auth = get_auth_state()
    items = builtins.list(auth.client.service.all(page_size=100))
    if "state" in select and items:
        job_ids = [item.id for item in items]
        try:
            statuses = auth.broker_client.jobs.get_batch_status(job_ids).statuses
        except (BrokerError, *HTTPXErrors):
            statuses = {}
        enriched = []
        for item in items:
            d = item.model_dump(include=set(s for s in select if s != "state"))
            status = statuses.get(str(item.id))
            d["state"] = status.state.value if status else "unknown"
            enriched.append(d)
        print_table_with_select(enriched, select=select, as_json=as_json)
    else:
        print_table_with_select(items, select=select, as_json=as_json)
    return items


@cli.subcommand(
    "services",
    "info",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="service")),
    project_id=Arg(help=Messages.project_id.format(noun="service")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="service")),
    select=Arg(
        "--select",
        help=Messages.select.format(opts=builtins.list(ServiceDetail.model_fields)),
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def info(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[Union[str, UUID]] = None,
    select: Optional[builtins.list[str]] = None,
    as_json: bool = False,
) -> ServiceDetail:
    """Print information about a service on the cluster."""
    auth = get_auth_state()
    res = resolve_service(name_or_id, cluster_id=cluster_id, project_id=project_id)
    try:
        status = auth.broker_client.jobs.get_status(res.id)
        msg.text(f"State: {status.state.value}", icon="info")
    except (BrokerError, *HTTPXErrors):
        pass
    print_info_table(res, exclude=["plan"], as_json=as_json, select=select)
    return res


@cli.subcommand(
    "services",
    "logs",
    name_or_id=Arg(help=Messages.name_or_id_optional.format(noun="service")),
    project_id=Arg(help=Messages.project_id.format(noun="service")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="service")),
    as_json=Arg("--json", help=Messages.as_json),
    show_errors=Arg(
        "--errors", help="Show structured error information instead of full logs"
    ),
    query=Arg("--query", help="Filter log lines matching this text (requires Loki)"),
)
def logs(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[Union[str, UUID]] = None,
    cluster_id: Optional[Union[str, UUID]] = None,
    as_json: bool = False,
    show_errors: bool = False,
    query: Optional[str] = None,
) -> str | None:
    """Get logs for a service on the cluster."""
    job = resolve_service(name_or_id, cluster_id=cluster_id, project_id=project_id)
    auth = get_auth_state()
    if job.last_execution_id is None:
        raise CLIError(Messages.E051.format(noun="service", name=job.name, id=job.id))
    if show_errors:
        try:
            resp = auth.broker_client.jobs.errors(job_id=job.last_execution_id)
        except BrokerError as e:
            raise CLIError(Messages.E011.format(noun="service"), e)
        if as_json:
            print(resp.model_dump_json(indent=2))
        else:
            msg.text(f"State: {resp.state}", icon="info")
            if resp.errors:
                for err in resp.errors:
                    msg.fail(err.message)
                    if err.traceback:
                        print(err.traceback)
                        print()
            elif resp.tail:
                msg.warn("No structured errors found. Last 50 lines:")
                print(resp.tail)
            else:
                msg.good("No errors found")
        return None
    try:
        text = auth.broker_client.jobs.logs(job_id=job.last_execution_id, query=query)
    except BrokerError as e:
        raise CLIError(Messages.E011.format(noun="service"), e)
    print_logs(text, as_json=as_json)
    return text


@cli.subcommand(
    "services",
    "start",
    name_or_id=Arg(help=Messages.name_or_id_optional.format(noun="service")),
    project_id=Arg(help=Messages.project_id.format(noun="service")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="service")),
    worker_class=Arg(
        "--worker-class",
        help=Messages.recipe_worker_class.format(noun="service"),
    ),
    no_wait=Arg("--no-wait", help=Messages.no_wait.format(noun="service")),
    as_json=Arg("--json", help=Messages.as_json),
)
def start(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[Union[str, UUID]] = None,
    cluster_id: Optional[Union[str, UUID]] = None,
    worker_class: Optional[str] = None,
    no_wait: bool = False,
    as_json: bool = False,
) -> UUID:
    """Start a service on the cluster."""
    job = resolve_service(name_or_id, cluster_id=cluster_id, project_id=project_id)
    start_job(
        job,
        worker_class,
        get_auth_state(),
        wait=not no_wait,
        quiet=as_json,
    )
    if as_json:
        print_mutation_result(
            {"id": str(job.id), "status": "started"}, "", as_json=True
        )
    return job.id


@cli.subcommand(
    "services",
    "stop",
    name_or_id=Arg(help=Messages.name_or_id_optional.format(noun="service")),
    project_id=Arg(help=Messages.project_id.format(noun="service")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="service")),
    as_json=Arg("--json", help=Messages.as_json),
)
def stop(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[Union[str, UUID]] = None,
    cluster_id: Optional[Union[str, UUID]] = None,
    as_json: bool = False,
) -> UUID:
    """Stop a service on the cluster."""
    job = resolve_service(name_or_id, cluster_id=cluster_id, project_id=project_id)
    stop_job(job, get_auth_state(), quiet=as_json)
    if as_json:
        print_mutation_result(
            {"id": str(job.id), "status": "stopped"}, "", as_json=True
        )
    return job.id


@cli.subcommand(
    "services",
    "delete",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="service")),
    project_id=Arg(help=Messages.project_id.format(noun="service")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="service")),
    as_json=Arg("--json", help=Messages.as_json),
)
def delete(
    name_or_id: Union[str, UUID],
    project_id: Optional[Union[str, UUID]] = None,
    cluster_id: Optional[Union[str, UUID]] = None,
    as_json: bool = False,
) -> UUID:
    """Delete a service by name or ID."""
    job = resolve_service(name_or_id, cluster_id=cluster_id, project_id=project_id)
    delete_job(job, get_auth_state(), quiet=as_json)
    if as_json:
        print_mutation_result({"id": str(job.id), "deleted": True}, "", as_json=True)
    return job.id


@cli.subcommand(
    "services",
    "url",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="service")),
    project_id=Arg(help=Messages.project_id.format(noun="service")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="service")),
    as_json=Arg("--json", help=Messages.as_json),
)
def url(
    name_or_id: Union[str, UUID],
    project_id: Optional[Union[str, UUID]] = None,
    cluster_id: Optional[Union[str, UUID]] = None,
    as_json: bool = False,
) -> dict[str, str]:
    """Print the bearer-token-authenticated URL for a service.

    Mints a fresh 90-day token via ``POST /v1/service/issue-token`` and
    formats it together with the service's public URL so the result can
    be dropped into an MCP client config or curl invocation:

        curl -H "Authorization: Bearer <token>" <url>

    Use ``services rotate-token`` to mint a new token without printing
    the URL again.
    """
    auth = get_auth_state()
    service = resolve_service(name_or_id, cluster_id=cluster_id, project_id=project_id)
    token = auth.client.service.issue_token(id=service.id)
    result = {
        "url": service.url,
        "access_token": token.access_token,
        "expires_at": token.expires_at.isoformat(),
    }
    if as_json:
        print_mutation_result(result, "", as_json=True)
    else:
        msg.good(f"URL:        {service.url}")
        msg.text(f"Token:      {token.access_token}")
        msg.text(f"Expires at: {token.expires_at.isoformat()}")
        msg.text(
            f"Try it:     curl -H 'Authorization: Bearer {token.access_token}' "
            f"{service.url}"
        )
    return result


@cli.subcommand(
    "services",
    "rotate-token",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="service")),
    project_id=Arg(help=Messages.project_id.format(noun="service")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="service")),
    as_json=Arg("--json", help=Messages.as_json),
)
def rotate_token(
    name_or_id: Union[str, UUID],
    project_id: Optional[Union[str, UUID]] = None,
    cluster_id: Optional[Union[str, UUID]] = None,
    as_json: bool = False,
) -> dict[str, str]:
    """Mint a fresh 90-day token for an existing service.

    Issuing a new token does not invalidate previous ones -- they remain
    valid until their own expiration. Use this when the previous token
    is leaked, or when you want a longer remaining window for an MCP
    client config.
    """
    auth = get_auth_state()
    service = resolve_service(name_or_id, cluster_id=cluster_id, project_id=project_id)
    token = auth.client.service.issue_token(id=service.id)
    result = {
        "access_token": token.access_token,
        "expires_at": token.expires_at.isoformat(),
    }
    if as_json:
        print_mutation_result(result, "", as_json=True)
    else:
        msg.good(f"Token:      {token.access_token}")
        msg.text(f"Expires at: {token.expires_at.isoformat()}")
    return result
