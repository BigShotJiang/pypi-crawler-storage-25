import json
import sys
from pathlib import Path
from typing import Optional, Union
from uuid import UUID

from radicli import Arg
from wasabi import msg

from ellf_pam_sdk.errors import ProjectPlanVersionConflict

from ..cli import cli
from ..errors import CLIError
from ..messages import Messages
from ..query import (
    DEFAULT_PLAN_NAME,
    find_plan,
    resolve_plan,
    resolve_plan_id,
    resolve_project_id,
)
from ..ui import print_table_with_select
from ._state import get_auth_state, get_saved_settings


@cli.subcommand(
    "plans",
    "list",
    project_id=Arg(help="Project name, slug, or UUID (defaults to saved project)"),
    name=Arg("--name", help="Filter by name (substring)"),
    as_json=Arg("--json", help=Messages.as_json),
)
def list(
    project_id: Optional[Union[str, UUID]] = None,
    name: Optional[str] = None,
    as_json: bool = False,
) -> None:
    """List all plans for a project"""
    if project_id is not None:
        project_uuid = resolve_project_id(project_id)
    else:
        saved = get_saved_settings().project
        if saved is None:
            raise CLIError(Messages.E012)
        project_uuid = saved
    client = get_auth_state().client
    items = client.project_plan.list(project_uuid)
    if name is not None:
        items = [p for p in items if name in p.name]
    select = ["id", "name", "version", "updated_by_id", "created", "updated"]
    print_table_with_select(items, select=select, as_json=as_json)


@cli.subcommand(
    "plans",
    "read",
    name_or_id=Arg(help=f"Plan name or UUID (defaults to '{DEFAULT_PLAN_NAME}')"),
    project_id=Arg(help="Project name, slug, or UUID (defaults to saved project)"),
    version=Arg("--version", help="Specific revision to read (default: head)"),
    as_json=Arg("--json", help=Messages.as_json),
)
def read(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[Union[str, UUID]] = None,
    version: Optional[int] = None,
    as_json: bool = False,
) -> Optional[str]:
    """Read a plan for a project"""
    if name_or_id is None:
        name_or_id = DEFAULT_PLAN_NAME
    if project_id is not None:
        project_id = resolve_project_id(project_id)
    else:
        project_id = get_saved_settings().project
    client = get_auth_state().client
    try:
        plan = resolve_plan(name_or_id, project_id=project_id)
    except CLIError:
        if version is not None:
            raise
        if as_json:
            print("{}")
            return None
        if project_id is None:
            raise
        siblings = client.project_plan.list(project_id)
        if not siblings:
            msg.info("No plans for this project")
            return None
        msg.warn(f"No plan '{name_or_id}' for this project.")
        msg.info("Available plans:")
        for p in sorted(siblings, key=lambda p: p.name):
            msg.text(f"  - {p.name} (v{p.version})")
        raise SystemExit(1)
    if version is not None:
        revision = client.project_plan.read_revision(plan_id=plan.id, version=version)
        if as_json:
            print(revision.model_dump_json(indent=2))
        else:
            msg.info(
                f"Plan: {plan.name} v{revision.version} "
                f"(authored by {revision.created_by_id})"
            )
            print(revision.content)
        return revision.content
    if as_json:
        print(plan.model_dump_json(indent=2))
    else:
        msg.info(
            f"Plan: {plan.name} v{plan.version} (last edited by {plan.updated_by_id})"
        )
        print(plan.content)
    return plan.content


@cli.subcommand(
    "plans",
    "write",
    name_or_id=Arg(help=f"Plan name or UUID (defaults to '{DEFAULT_PLAN_NAME}')"),
    project_id=Arg(help="Project name, slug, or UUID (defaults to saved project)"),
    content=Arg(
        "--content", help="Plan content (markdown). Use --file to read from a file."
    ),
    file=Arg("--file", help="Path to a file containing the plan content"),
    as_json=Arg("--json", help=Messages.as_json),
)
def write(
    name_or_id: Optional[Union[str, UUID]] = None,
    project_id: Optional[Union[str, UUID]] = None,
    content: Optional[str] = None,
    file: Optional[Path] = None,
    as_json: bool = False,
) -> None:
    """Create or update a plan for a project (upsert)"""
    if name_or_id is None:
        name_or_id = DEFAULT_PLAN_NAME
    if project_id is not None:
        project_id = resolve_project_id(project_id)
    else:
        project_id = get_saved_settings().project
    if content is None and file is None:
        if not sys.stdin.isatty():
            content = sys.stdin.read()
        else:
            msg.fail("Provide --content or --file (or pipe content via stdin)")
            raise SystemExit(1)
    if file is not None:
        content = file.read_text()
    assert content is not None
    existing = find_plan(name_or_id, project_id=project_id)
    if existing is not None:
        plan_name = existing.name
        target_project_id = existing.project_id
        expected_version: Optional[int] = existing.version
    else:
        # Name lookup miss — create a new plan. find_plan would have raised
        # if name_or_id were a UUID or project_id were missing.
        assert isinstance(name_or_id, str)
        assert project_id is not None
        plan_name = name_or_id
        target_project_id = project_id
        expected_version = None
    client = get_auth_state().client
    try:
        plan = client.project_plan.upsert(
            target_project_id,
            plan_name,
            content=content,
            expected_version=expected_version,
        )
    except ProjectPlanVersionConflict as exc:
        msg.fail(
            f"Conflict: plan changed to v{exc.current_version} "
            f"between fetch and write. Re-run to overwrite the new head."
        )
        print("----- current head -----")
        print(exc.current_content)
        raise SystemExit(1)
    if as_json:
        print(plan.model_dump_json(indent=2))
    else:
        msg.good(f"Plan '{plan_name}' saved (id: {plan.id}, version: {plan.version})")


@cli.subcommand(
    "plans",
    "revisions",
    name_or_id=Arg(help="Plan name or UUID"),
    project_id=Arg(help="Project name, slug, or UUID (defaults to saved project)"),
    size=Arg("--size", help="Page size (1-100)"),
    after=Arg("--after", help="Cursor returned by a previous page"),
    as_json=Arg("--json", help=Messages.as_json),
)
def revisions(
    name_or_id: Union[str, UUID],
    project_id: Optional[Union[str, UUID]] = None,
    size: int = 50,
    after: Optional[UUID] = None,
    as_json: bool = False,
) -> None:
    """List revisions for a plan, newest first"""
    if project_id is not None:
        project_id = resolve_project_id(project_id)
    plan = resolve_plan(name_or_id, project_id=project_id)
    client = get_auth_state().client
    page = client.project_plan.list_revisions(
        plan.project_id, plan.name, after=after, size=size
    )
    select = ["version", "created_by_id", "created", "id"]
    print_table_with_select(page.items, select=select, as_json=as_json)
    if not as_json and page.has_more and page.next_cursor:
        msg.text(f"next: {page.next_cursor}")


@cli.subcommand(
    "plans",
    "delete",
    name_or_id=Arg(help="Plan name or UUID"),
    project_id=Arg(help="Project name, slug, or UUID (defaults to saved project)"),
    as_json=Arg("--json", help=Messages.as_json),
)
def delete(
    name_or_id: Union[str, UUID],
    project_id: Optional[Union[str, UUID]] = None,
    as_json: bool = False,
) -> None:
    """Delete a plan"""
    if project_id is not None:
        project_id = resolve_project_id(project_id)
    plan_id = resolve_plan_id(name_or_id, project_id=project_id)
    client = get_auth_state().client
    client.project_plan.delete(id=plan_id)
    if as_json:
        print(json.dumps({"deleted": True}))
    else:
        msg.good("Plan deleted")
