import json
import os
import subprocess
from pathlib import Path
from typing import Any, Literal, Optional, Union
from uuid import UUID

from radicli import Arg

from ..cli import cli
from ..config import SavedSettings
from ..errors import CLIError, EllfErrors
from ..messages import Messages
from ..ui import print_as_json, print_mutation_result
from ._state import get_auth_state, get_root_cfg


def _resolve_project_id(project_id: Optional[Union[str, UUID]]) -> UUID:
    if project_id is not None:
        from ..query import resolve_project_id

        return resolve_project_id(project_id)
    settings = SavedSettings.from_file(get_root_cfg().saved_settings_path)
    if settings.project is None:
        raise CLIError(Messages.E012)
    return settings.project


def _resolve_support_project_id(
    project_id: Optional[Union[str, UUID]],
) -> tuple[UUID | None, dict[str, Any] | None]:
    """Resolve an optional support project, ignoring stale saved defaults."""
    if project_id is not None:
        from ..query import resolve_project_id

        return resolve_project_id(project_id), {
            "source": "argument",
            "verified": True,
        }

    settings = SavedSettings.from_file(get_root_cfg().saved_settings_path)
    if settings.project is None:
        return None, {"source": "default", "verified": False, "reason": "missing"}

    project_client = getattr(get_auth_state().client, "project", None)
    if project_client is None or not hasattr(project_client, "read"):
        return settings.project, {
            "source": "default",
            "verified": False,
            "reason": "unverified",
            "project_id": str(settings.project),
        }

    try:
        project_client.read(id=settings.project)
    except EllfErrors.ProjectNotFound:
        return None, {
            "source": "default",
            "verified": False,
            "reason": "stale_default",
            "project_id": str(settings.project),
        }
    return settings.project, {
        "source": "default",
        "verified": True,
        "project_id": str(settings.project),
    }


def _git_branch(cwd: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "branch", "--show-current"],
            check=False,
            capture_output=True,
            text=True,
            cwd=str(cwd),
        )
    except Exception:
        return None
    branch = result.stdout.strip()
    return branch or None


def _find_session_jsonl(session_id: str) -> Path | None:
    root = Path.home() / ".claude" / "projects"
    if not root.exists():
        return None
    matches = sorted(root.rglob(f"{session_id}.jsonl"))
    return matches[0] if matches else None


def _read_text(path: Path | None) -> str | None:
    if path is None or not path.exists():
        return None
    text = path.read_text(encoding="utf-8", errors="replace").strip()
    return text or None


def _collect_attachment_payload(
    explicit_session_id: str | None = None,
    explicit_transcript_path: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Collect transcript/debug attachment payloads and lookup diagnostics."""
    transcript_path = (
        Path(explicit_transcript_path).expanduser()
        if explicit_transcript_path is not None
        else None
    )
    env_session_id = (os.environ.get("CLAUDE_CODE_SESSION_ID") or "").strip() or None
    if explicit_transcript_path is not None:
        session_id = explicit_session_id
    else:
        session_id = explicit_session_id or env_session_id
    if explicit_session_id:
        session_id_source = "argument"
    elif session_id is not None:
        session_id_source = "env_var"
    else:
        session_id_source = "missing"
    attachment_lookup: dict[str, Any] = {
        "consent_requested": True,
        "session_id": session_id,
        "session_id_present": bool(session_id),
        "session_id_source": session_id_source,
        "transcript_path": None,
        "transcript_found": False,
        "debug_log_path": None,
        "debug_log_found": False,
    }
    payload: dict[str, Any] = {}
    session_path = (
        transcript_path
        if transcript_path is not None
        else (_find_session_jsonl(session_id) if session_id is not None else None)
    )
    attachment_lookup["transcript_path"] = (
        str(session_path) if session_path is not None else None
    )
    session_jsonl = _read_text(session_path)
    if session_jsonl is not None:
        payload["transcript_text"] = session_jsonl
        attachment_lookup["transcript_found"] = True

    if session_id is None:
        return payload, attachment_lookup

    payload["session_id"] = session_id
    debug_path = Path.home() / ".claude" / "debug" / f"{session_id}.txt"
    attachment_lookup["debug_log_path"] = str(debug_path)
    debug_log = _read_text(debug_path)
    if debug_log is not None:
        payload["debug_log_text"] = debug_log
        attachment_lookup["debug_log_found"] = True

    return payload, attachment_lookup


@cli.subcommand(
    "support",
    "create",
    user_comment=Arg(
        "--message", help="The user's support request or issue description"
    ),
    summary=Arg(
        "--summary",
        help="Optional support-ready summary of the issue and current state",
    ),
    project_id=Arg(
        "--project", help=Messages.project_id.format(noun="support request")
    ),
    no_project=Arg(
        "--no-project",
        help="Explicitly send the request without any project association",
    ),
    conversation_id=Arg(
        "--conversation",
        help="Conversation ID to attach from PAM when available",
    ),
    session_id=Arg(
        "--session-id",
        help="Claude Code session ID to use for transcript/debug attachment lookup",
    ),
    transcript_path=Arg(
        "--transcript-path",
        help="Path to a Claude transcript .jsonl file to attach explicitly",
    ),
    transcript_consent=Arg(
        "--transcript-consent",
        help="Explicit transcript consent mode: 'summary_only' or 'attach_full_transcript'",
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def create(
    user_comment: str,
    summary: Optional[str] = None,
    project_id: Optional[Union[str, UUID]] = None,
    no_project: bool = False,
    conversation_id: Optional[UUID] = None,
    session_id: Optional[str] = None,
    transcript_path: Optional[str] = None,
    transcript_consent: Literal[
        "summary_only", "attach_full_transcript"
    ] = "summary_only",
    as_json: bool = False,
) -> dict[str, Any]:
    """Send a support request to the Ellf team."""
    auth = get_auth_state()
    if no_project:
        resolved_project_id = None
        project_lookup: dict[str, Any] | None = {
            "source": "explicit",
            "verified": True,
            "reason": "no_project_flag",
        }
    else:
        resolved_project_id, project_lookup = _resolve_support_project_id(project_id)
    cwd = Path.cwd()
    effective_summary = (summary or "").strip() or user_comment.strip()
    body: dict[str, Any] = {
        "user_comment": user_comment,
        "summary": effective_summary,
        "transcript_consent": transcript_consent,
        "project_path": str(cwd),
    }
    if resolved_project_id is not None:
        body["project_id"] = str(resolved_project_id)
    branch = _git_branch(cwd)
    if branch is not None:
        body["git_branch"] = branch
    if conversation_id is not None:
        body["conversation_id"] = str(conversation_id)
    attachment_lookup: dict[str, Any] | None = None
    if transcript_consent == "attach_full_transcript":
        attachment_payload, attachment_lookup = _collect_attachment_payload(
            session_id, transcript_path
        )
        body.update(attachment_payload)
    response = auth.client._sync_client.post("/api/v1/support/request", json=body)
    response.raise_for_status()
    result = response.json()
    if attachment_lookup is not None:
        attachment_lookup = {
            **attachment_lookup,
            "transcript_attached": result.get("transcript_attached", False),
            "debug_log_attached": result.get("debug_log_attached", False),
        }
        result["attachment_lookup"] = attachment_lookup
    if project_lookup is not None:
        result["project_lookup"] = project_lookup
    if as_json:
        print_as_json(result)
    else:
        support_id = result.get("support_id")
        mutation = {
            "status": "ok",
            "support_id": support_id,
            "transcript_attached": result.get("transcript_attached", False),
            "debug_log_attached": result.get("debug_log_attached", False),
        }
        print_mutation_result(
            mutation,
            (
                f"Successfully sent support request {support_id}"
                if support_id
                else "Successfully sent support request"
            ),
            as_json=False,
        )
        details = {
            "support_id": support_id,
            "to_email": result.get("to_email"),
            "subject": result.get("subject"),
            "transcript_attached": result.get("transcript_attached", False),
            "debug_log_attached": result.get("debug_log_attached", False),
            "support_id_available": bool(support_id),
        }
        if attachment_lookup is not None:
            details["attachment_lookup"] = attachment_lookup
        if project_lookup is not None:
            details["project_lookup"] = project_lookup
        print(json.dumps(details, indent=2))
    return result
