import builtins
from collections.abc import Sequence
from getpass import getpass
from typing import Optional, Union
from uuid import UUID

from radicli import Arg
from wasabi import msg

from ellf_broker_sdk.errors import AuthError as BrokerAuthError
from ellf_broker_sdk.errors import BrokerError
from ellf_broker_sdk.models import Secret
from ellf_pam_sdk.models import SecretDetail, SecretSummary

from ..cli import cli
from ..errors import CLIError, EllfErrors, HTTPXErrors
from ..messages import Messages
from ..query import resolve_secret
from ..ui import (
    isatty,
    print_info_table,
    print_mutation_result,
    print_table_with_select,
)
from ._state import get_auth_state


@cli.subcommand(
    "secrets",
    "list",
    # fmt: off
    cluster_id=Arg("--cluster-id", help=Messages.cluster_id.format(noun="secret")),
    select=Arg(
        "--select",
        help=Messages.select.format(opts=builtins.list(SecretSummary.model_fields)),
    ),
    as_json=Arg("--json", help=Messages.as_json),
    # fmt: on
)
def list(
    cluster_id: Optional[Union[str, UUID]] = None,
    select: builtins.list[str] = ["created", "id", "name"],
    as_json: bool = False,
) -> Sequence[SecretSummary]:
    """List all named pointers to secrets on the cluster"""
    auth = get_auth_state()
    items = builtins.list(
        auth.client.secret.all(cluster_id=cluster_id or auth.cluster_id)
    )
    print_table_with_select(items, select=select, as_json=as_json)
    return items


@cli.subcommand(
    "secrets",
    "info",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="secret")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="secret")),
    select=Arg(
        "--select",
        help=Messages.select.format(opts=builtins.list(SecretDetail.model_fields)),
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def info(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[Union[str, UUID]] = None,
    select: Optional[builtins.list[str]] = None,
    as_json: bool = False,
) -> SecretDetail:
    """Show info about a secret on the cluster"""
    res = resolve_secret(name_or_id, cluster_id=cluster_id)
    print_info_table(res, as_json=as_json, select=select)
    return res


@cli.subcommand(
    "secrets",
    "create",
    name=Arg(help=Messages.name.format(noun="secret")),
    value=Arg("--value", help="The secret value. Omit to be prompted interactively."),
    exists_ok=Arg("--exists-ok", help=Messages.exists_ok),
    as_json=Arg("--json", help=Messages.as_json),
)
def create(
    name: str,
    value: Optional[str] = None,
    exists_ok: bool = False,
    as_json: bool = False,
) -> UUID | None:
    """Create a secret on the cluster"""
    import sys

    auth = get_auth_state()
    client = auth.client
    broker_client = auth.broker_client
    cluster_id = auth.cluster_id

    if value is None:
        if not isatty(sys.stdin):
            raise CLIError(
                "Cannot prompt for secret in non-interactive mode",
                "Provide the value with --value",
            )
        value = getpass(f"Enter secret value for {name}: ")

    cluster_secret = Secret(key=name, value=value)
    try:
        broker_client.secrets.create(cluster_secret)
    except BrokerAuthError:
        raise CLIError(
            Messages.E039.format(
                message="Could not store secret on cluster: authentication failed"
            ),
            "Try re-authenticating with `ellf login`",
        )
    except (BrokerError, *HTTPXErrors) as e:
        raise CLIError(Messages.E003.format(noun="secret", name=name), str(e))

    try:
        res = client.secret.create(name=name, cluster_id=cluster_id)
    except EllfErrors.SecretExists:
        if exists_ok:
            msg.info(Messages.T001.format(noun="secret", name=name))
            return None
        raise CLIError(Messages.E002.format(noun="secret", name=name))
    except EllfErrors.SecretInvalid:
        raise CLIError(Messages.E004.format(noun="secret", name=name))
    except EllfErrors.SecretForbiddenCreate:
        raise CLIError(Messages.E003.format(noun="secret", name=name))
    print_mutation_result(
        {"id": str(res.id), "name": res.name},
        Messages.T002.format(noun="secret", name=res.name),
        as_json=as_json,
    )
    if not as_json:
        print_info_table(res)
    return res.id


@cli.subcommand(
    "secrets",
    "delete",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="secret")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="secret")),
    as_json=Arg("--json", help=Messages.as_json),
)
def delete(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[Union[str, UUID]] = None,
    as_json: bool = False,
) -> UUID:
    """Delete a secret by name or ID"""

    auth = get_auth_state()
    client = auth.client
    broker_client = auth.broker_client
    cluster_id = cluster_id or auth.cluster_id

    pam_secret = resolve_secret(name_or_id, cluster_id=cluster_id)
    try:
        broker_client.secrets.delete(key=pam_secret.name)
    except BrokerAuthError:
        raise CLIError(
            Messages.E039.format(
                message="Could not delete secret from cluster: authentication failed"
            ),
            "Try re-authenticating with `ellf login`",
        )
    except (BrokerError, *HTTPXErrors) as e:
        raise CLIError(Messages.E006.format(noun="secret", name=name_or_id), str(e))

    try:
        client.secret.delete(id=pam_secret.id)
    except (
        EllfErrors.SecretForbiddenDelete,
        EllfErrors.SecretNotFound,
    ):
        raise CLIError(Messages.E006.format(noun="secret", name=name_or_id))
    else:
        print_mutation_result(
            {"id": str(pam_secret.id), "deleted": True},
            Messages.T003.format(noun="secret", name=name_or_id),
            as_json=as_json,
        )
    return pam_secret.id
