from __future__ import annotations

import builtins
import sys
from typing import Union
from uuid import UUID

from wasabi import msg

from ellf_pam_sdk import Client
from ellf_pam_sdk.models import OrgMembership

from ..errors import CLIError
from ..messages import Messages
from ..ui import isatty


def list_person_orgs(client: Client) -> builtins.list[OrgMembership]:
    """Return all org memberships for the authenticated person.

    The PAM ``org.all()`` listing is org-scoped by the api_token, so it
    only returns the *current* org. To enumerate everywhere this person
    can sign in we hit ``/api/v1/person/orgs`` directly — the same
    endpoint the web app's org switcher uses.
    """
    response = client._sync_client.post("/api/v1/person/orgs")
    response.raise_for_status()
    return [OrgMembership.model_validate(row) for row in response.json()]


def _match_org(
    orgs: builtins.list[OrgMembership],
    name_or_id: Union[str, UUID],
) -> OrgMembership | None:
    if isinstance(name_or_id, UUID):
        for o in orgs:
            if o.org_id == name_or_id:
                return o
        return None
    needle = str(name_or_id)
    for o in orgs:
        if str(o.org_id) == needle or o.org_name == needle:
            return o
    return None


def _prompt_for_org(orgs: builtins.list[OrgMembership]) -> OrgMembership:
    if not isatty(sys.stdin) or not isatty(sys.stdout):
        raise CLIError(Messages.E136)
    msg.info("Multiple organizations are available:")
    for idx, org in enumerate(orgs, start=1):
        print(f"  [{idx}] {org.org_name}  ({org.org_id})")
    while True:
        raw = input(f"Pick an organization [1-{len(orgs)}]: ").strip()
        if raw.isdigit():
            choice = int(raw)
            if 1 <= choice <= len(orgs):
                return orgs[choice - 1]
        matched = _match_org(orgs, raw)
        if matched is not None:
            return matched
        msg.warn(f"Invalid selection: {raw!r}")


def select_org(
    client: Client,
    name_or_id: Union[str, UUID, None] = None,
) -> OrgMembership:
    """Pick an org the current person belongs to.

    When ``name_or_id`` is provided, looks it up exactly. Otherwise:
    auto-selects the only org, or prompts in a TTY when there are
    multiple. Raises ``CLIError`` if the person has no orgs or the
    caller is non-interactive with multiple orgs.
    """
    orgs = list_person_orgs(client)
    if not orgs:
        raise CLIError(Messages.E135)
    if name_or_id is not None:
        matched = _match_org(orgs, name_or_id)
        if matched is None:
            raise CLIError(Messages.E038.format(noun="org", name_or_id=name_or_id))
        return matched
    if len(orgs) == 1:
        return orgs[0]
    return _prompt_for_org(orgs)
