import json
import shutil
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Union
from uuid import UUID

import httpx
from radicli import Arg
from wasabi import msg

from .. import about
from ..auth import AuthState
from ..cli import cli
from ..config import SavedSettings, global_config_dir
from ..errors import CLIError, EllfError
from ..messages import Messages
from ..ui import print_as_json, print_mutation_result
from ..util import URL
from ._cluster_select import select_cluster
from ._org_select import select_org
from ._state import get_auth_state, get_root_cfg, get_saved_settings


def _ellf_claude_plugin_dir() -> Path | None:
    package_root = Path(__file__).resolve().parents[1]
    plugin_dir = package_root / "ellf_skills"
    if (plugin_dir / "skill_variants.json").exists():
        return plugin_dir
    return None


def _ellf_skill_variants(plugin_dir: Path) -> dict[str, dict[str, str]]:
    manifest_path = plugin_dir / "skill_variants.json"
    return json.loads(manifest_path.read_text(encoding="utf-8"))


def _install_claude_skills() -> None:
    plugin_dir = _ellf_claude_plugin_dir()
    if plugin_dir is None:
        msg.warn(
            "Packaged ellf Claude plugin not found. "
            "Install the ellf-skills plugin assets to use --claude."
        )
        return
    claude_dir = Path.home() / ".claude"
    dest = claude_dir / "skills"
    dest.mkdir(parents=True, exist_ok=True)
    selected_skills = {
        canonical_name: plugin_dir / "skills" / variants["coding"]
        for canonical_name, variants in _ellf_skill_variants(plugin_dir).items()
        if "coding" in variants
    }
    for canonical_name, skill_dir in sorted(selected_skills.items()):
        dst = dest / canonical_name
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(skill_dir, dst)
    msg.good(f"Installed {len(selected_skills)} Claude Code skills to {dest}")
    for canonical_name in sorted(selected_skills):
        print(f"  - {canonical_name}")


@cli.command(
    "login",
    no_cluster=Arg("--no-cluster", help=Messages.no_cluster),
    no_org=Arg("--no-org", help=Messages.no_org),
    no_browser=Arg("--no-browser", help=Messages.no_browser),
    org=Arg("--org", help=Messages.login_org),
    cluster=Arg("--cluster", help=Messages.login_cluster),
    as_json=Arg("--json", help=Messages.as_json),
    claude=Arg("--claude", help=Messages.claude),
)
def login(
    no_cluster: bool = False,
    no_org: bool = False,
    no_browser: bool = False,
    org: Optional[Union[str, UUID]] = None,
    cluster: Optional[Union[str, UUID]] = None,
    as_json: bool = False,
    claude: bool = False,
) -> None:
    """
    Log in to your Ellf account. You normally don't need to call this
    manually. It will automatically authenticate when needed.
    """
    auth = get_auth_state()
    auth.no_browser = no_browser
    auth._ensure_readable_secrets()
    auth.get_api_token(force_refresh=True)
    if not no_org:
        # Org selection happens before cluster selection so cluster lookups
        # below run against the chosen org's api_token, not whatever org
        # the device-flow login happened to land in.
        _select_and_persist_org(auth, org)
    if not no_cluster:
        try:
            _select_and_persist_cluster(auth, cluster)
            auth.get_cluster_token(force_refresh=True)
        except EllfError as e:
            err = Messages.E116.format(command=f"{cli.prog} login --no-cluster")
            raise CLIError(err, e)
    print_mutation_result(
        {"status": "ok"},
        Messages.T012,
        as_json=as_json,
    )
    if claude:
        _install_claude_skills()


@cli.command(
    "logout",
    all_=Arg("--all", help=Messages.logout_all),
    as_json=Arg("--json", help=Messages.as_json),
)
def logout(all_: bool = False, as_json: bool = False) -> None:
    """
    Log out by deleting locally-stored auth tokens.

    PAM bearer tokens can't be revoked server-side, so this is a local
    operation: subsequent commands will trigger a fresh device-flow
    login. The cached tokens would have expired on their own within
    roughly an hour. Use ``--all`` to also reset the saved defaults
    (active org, cluster, project, etc.), e.g. when handing the
    machine to a different user.
    """
    from ..auth import FileSecrets

    ctx = get_root_cfg()
    secrets_existed = ctx.secrets_path.exists()
    FileSecrets.clean(ctx.secrets_path)
    settings_reset = False
    if all_:
        settings_path = ctx.saved_settings_path
        if settings_path.exists():
            SavedSettings.blank().save(settings_path)
            settings_reset = True
    print_mutation_result(
        {
            "status": "ok",
            "secrets_removed": secrets_existed,
            "settings_reset": settings_reset,
        },
        Messages.T013,
        as_json=as_json,
    )


def _select_and_persist_org(
    auth: AuthState,
    name_or_id: Optional[Union[str, UUID]] = None,
) -> UUID:
    """Pick an org via pam and write it into SavedSettings.

    The api_token's JWT carries an ``oid`` claim that PAM authorizes
    against server-side; the saved-defaults ``org_id`` is only a local
    display pointer. The two can drift apart (e.g. saved-defaults reset
    independently, or a prior switch that updated the pointer without
    re-minting). We compare ``chosen`` to the JWT claim — not the saved
    pointer — so a ``login --org X`` that finds the pointer already at X
    but the token issued for Y still calls ``/v1/token/switch-org`` and
    converges both sides on X.
    """
    chosen = select_org(auth.client, name_or_id)
    settings = get_saved_settings()
    token_oid = auth.get_api_token().header.get("oid")
    token_org_id = UUID(token_oid) if token_oid else None
    if token_org_id != chosen.org_id:
        auth.set_active_org(chosen.org_id)
    settings.update("org_id", chosen.org_id)
    settings.save(get_root_cfg().saved_settings_path)
    msg.good(f"Logged in to organization '{chosen.org_name}'")
    return chosen.org_id


def _select_and_persist_cluster(
    auth: AuthState,
    name_or_id: Optional[Union[str, UUID]] = None,
) -> UUID:
    """Pick a cluster via pam and write it into SavedSettings.

    Mutates ``auth`` so subsequent ``get_cluster_token`` / ``broker_client``
    calls in the same process use the chosen cluster without re-querying.
    """
    chosen = select_cluster(auth.client, name_or_id)
    broker_url = URL.parse(chosen.address)
    settings = get_saved_settings()
    settings.update("broker_host", str(broker_url))
    settings.update("cluster_id", chosen.id)
    settings.save(get_root_cfg().saved_settings_path)
    auth.set_active_cluster(chosen.id, broker_url)
    persist_last_active_context(auth, last_cluster_id=chosen.id)
    return chosen.id


def persist_last_active_context(
    auth: AuthState,
    *,
    last_cluster_id: Optional[UUID] = None,
    last_project_id: Optional[UUID] = None,
) -> None:
    """Mirror local cluster/project state into the user's PAM record.

    The web app reads ``User.last_cluster_id`` / ``last_project_id`` to
    restore context after org switches, and the CLI persists here so a
    web session that follows a ``clusters use`` lands on the same
    cluster.
    """
    from ellf_pam_sdk.models import UserUpdating

    if last_cluster_id is None and last_project_id is None:
        return
    auth.client.user.update(
        UserUpdating(
            id=auth.user_id,
            last_cluster_id=last_cluster_id,
            last_project_id=last_project_id,
        )
    )


@cli.command("info", field=Arg(help=Messages.select_field))
def info(field: Optional[Literal["config-dir", "code", "defaults"]] = None) -> Any:
    """Print information about the CLI"""
    settings = SavedSettings.from_file(get_root_cfg().saved_settings_path)
    info = {
        "config-dir": str(global_config_dir().absolute()),
        "code": __file__,
        "defaults": settings.to_json(),
    }
    if field:
        print(info[field])
        return info[field]
    else:
        print_as_json(info)
        return info


@cli.command(
    "get-auth-token",
    token_type=Arg(help="The token type"),
)
def get_auth_token(
    token_type: Optional[Literal["api", "cluster", "id", "ci"]] = None,
) -> AuthState:
    """
    Return an auth token for the current user
    """
    auth = get_auth_state()
    if token_type == "api":
        print(auth.get_api_token().access_token)
    elif token_type == "cluster":
        print(auth.get_cluster_token().access_token)
    elif token_type == "id":
        print(auth.get_id_token())
    elif token_type == "ci":
        # this uses a dev endpoint because we don't want to give CI
        # a full access token. Once we can create and revoke limited
        # tokens, remove this.
        response = auth.client._sync_client.post(
            "/api/v1/dev/create-ci-token",
            json={},
        )
        response.raise_for_status()
        print(response.json()["access_token"])
    else:
        raise CLIError(Messages.E117.format(token_type=token_type))
    return auth


def _fetch_version(client: httpx.Client, path: str) -> Optional[Dict[str, str]]:
    """Fetch version info from a service endpoint, returning None on failure."""
    try:
        response = client.get(path)
        response.raise_for_status()
        return response.json()
    except Exception:
        return None


def _print_version_table(rows: List[Dict[str, str]]) -> None:
    """Print version info for all services in a readable format."""
    for row in rows:
        msg.divider(row["service"])
        for key in (
            "package_version",
            "repo_sha",
            "service_sha",
            "container_sha",
            "build_date",
        ):
            value = row.get(key, "")
            if value:
                print(f"  {key}: {value}")
            else:
                print(f"  {key}: -")


@cli.command(
    "version",
    as_json=Arg("--json", help=Messages.as_json),
)
def version(as_json: bool = False) -> None:
    """Show version info for the CLI and running services."""
    auth = get_auth_state()
    rows: List[Dict[str, str]] = []

    pam_version = _fetch_version(auth.client._sync_client, "/api/v1/version")
    if pam_version:
        rows.append(pam_version)
    elif not as_json:
        msg.warn("Could not reach PAM service")

    try:
        broker_version = _fetch_version(
            auth.broker_client._sync_client, "/api/v1/version"
        )
        if broker_version:
            rows.append(broker_version)
        elif not as_json:
            msg.warn("Could not reach Cluster service")
    except EllfError:
        if not as_json:
            msg.warn("Could not reach Cluster service (no cluster configured)")

    if as_json:
        import json

        result = {"cli": {"package_version": about.__version__}, "services": rows}
        print(json.dumps(result, indent=2, default=str))
    else:
        msg.divider("cli")
        print(f"  package_version: {about.__version__}")
        print()
        _print_version_table(rows)
