from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Callable, ParamSpec, Protocol, TypeVar
from uuid import UUID

import httpx
import jwt
import pydantic
from pydantic import BaseModel, field_validator

from ellf_broker_sdk import (
    AccessTokenCredential as BrokerAccessTokenCredential,
)
from ellf_broker_sdk import Client as BrokerClient
from ellf_pam_sdk import AccessTokenCredential, Client
from ellf_pam_sdk.models import ClusterReading

from .config import DEFAULT_PAM_HOST, RootConfig
from .errors import (
    CLIError,
    EllfError,
    EllfIDTokenError,
    EllfParseSecretsError,
    HTTPError,
)
from .messages import Messages
from .ui import print_login_info
from .util import URL

logger = logging.getLogger(__name__)


def _format_http_error(response: httpx.Response) -> str:
    """Format an HTTP error response into a readable message.

    Extracts the ``detail`` field from JSON responses when available,
    falling back to the raw response text.
    """
    detail = ""
    try:
        detail = response.json().get("detail", "")
    except (ValueError, KeyError):
        detail = response.text
    status = f"{response.status_code} {response.reason_phrase}"
    url = str(response.url)
    if detail:
        return f"HTTP {status} from {url}: {detail}"
    return f"HTTP {status} from {url}"


_P = ParamSpec("_P")
_R = TypeVar("_R")

OIDC_SCOPE = "openid profile email"
OIDC_DEVICE_GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code"
AUTH_WAIT_TIME_SECONDS = 60 * 5
# httpx default is 5s — too tight for the auth round-trip when PAM's
# load balancer occasionally takes longer than that to respond. A
# transient network blip during login should not require the user to
# re-run; pick a value that comfortably outlasts any realistic single
# request without making a genuinely-down PAM hang noticeably.
AUTH_REQUEST_TIMEOUT_SECONDS = 15.0


class Secrets(Protocol):
    """
    Defines the interface for secrets storage. During normal operation,
    the secrets are stored in a file on disk. During testing, a mock
    implementation can be used to prevent breaking configuration.
    """

    id_token: str | None
    api_token: AccessTokenCredential | None
    broker_tokens: dict[str, BrokerAccessTokenCredential]

    @classmethod
    def load(cls, path: Path) -> Secrets: ...

    @classmethod
    def clean(cls, path: Path) -> None: ...

    def save(self, path: Path) -> None: ...


class FileSecrets(BaseModel):
    id_token: str | None = None
    api_token: AccessTokenCredential | None = None
    broker_tokens: dict[str, BrokerAccessTokenCredential] = {}

    @field_validator("api_token")
    @classmethod
    def validate_api_token(
        cls, value: AccessTokenCredential | None
    ) -> AccessTokenCredential | None:
        if value is not None:
            try:
                value.header  # trigger header validation
            except jwt.exceptions.DecodeError:
                raise ValueError("Invalid header for api_token")
        return value

    @classmethod
    def load(cls, path: Path) -> Secrets:
        try:
            return cls.model_validate_json(path.read_text())
        except pydantic.ValidationError as e:
            raise EllfParseSecretsError(secrets_file=path, error=e) from e
        except FileNotFoundError:
            return cls()

    @classmethod
    def clean(cls, path: Path) -> None:
        path.unlink(missing_ok=True)

    def save(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open(mode="w", encoding="utf-8") as f:
            if hasattr(os, "fchmod"):
                os.fchmod(f.fileno(), 0o600)
            f.write(self.model_dump_json())


class AuthState(Protocol):
    no_browser: bool

    @property
    def client(self) -> Client: ...

    @property
    def broker_client(self) -> BrokerClient: ...

    @property
    def broker_host(self) -> str: ...

    @property
    def broker_url(self) -> URL: ...

    @property
    def cluster_id(self) -> UUID: ...

    @property
    def org_id(self) -> UUID: ...

    @property
    def user_id(self) -> UUID: ...

    @property
    def pam_host(self) -> str: ...

    @property
    def pam_url(self) -> URL: ...

    @property
    def secrets(self) -> Secrets: ...

    def retry_id(self, func: Callable[_P, _R]) -> Callable[_P, _R]: ...

    def retry_api(self, func: Callable[_P, _R]) -> Callable[_P, _R]: ...

    def retry(self, func: Callable[_P, _R]) -> Callable[_P, _R]: ...

    def _ensure_readable_secrets(self) -> Secrets: ...

    def _ensure_broker_host(self) -> None: ...

    def set_active_cluster(self, cluster_id: UUID, broker_url: URL) -> None: ...

    def set_active_org(self, org_id: UUID) -> AccessTokenCredential: ...

    def get_id_token(self, force_refresh: bool = False) -> str: ...

    def get_api_token(self, force_refresh: bool = False) -> AccessTokenCredential: ...

    def get_cluster_token(
        self, force_refresh: bool = False
    ) -> BrokerAccessTokenCredential: ...


class AuthStateImpl:
    _pam_url: URL
    _broker_url: URL | None
    _cluster_id: UUID | None
    _org_id: UUID | None

    _secrets: Secrets | None
    _secrets_path: Path
    _saved_settings_path: Path
    _client: Client | None
    _cluster_client: BrokerClient | None

    no_browser: bool

    def __init__(self, ctx: RootConfig) -> None:
        from .commands._state import get_saved_settings

        settings = get_saved_settings()
        # Allow env var overrides (used by the assistant service container).
        pam_host = (
            os.environ.get("ELLF_PAM_HOST") or settings.pam_host or DEFAULT_PAM_HOST
        )
        broker_host = os.environ.get("ELLF_BROKER_HOST") or settings.broker_host
        self._secrets = None
        self._broker_url = URL.parse(broker_host) if broker_host is not None else None
        self._pam_url = URL.parse(pam_host)
        # Seed from saved-defaults so we don't make an unnecessary (and brittle)
        # PAM lookup-by-address every time the user runs an ellf command.
        # `auth.cluster_id` falls back to the address lookup only if this is None.
        self._cluster_id = settings.cluster_id
        # Seed org_id from saved-defaults as a fallback only. The ``org_id``
        # property reads from the api_token's ``oid`` claim — which is what
        # PAM authorizes against — and overwrites this value on first access.
        # The seed is just here to satisfy callers that read ``_org_id``
        # before any token is fetched.
        self._org_id = settings.org_id
        self._secrets_path = ctx.secrets_path
        self._saved_settings_path = ctx.saved_settings_path
        self._client = None
        self._cluster_client = None
        self.no_browser = False

    @property
    def client(self) -> Client:
        if self._client is None or self._client._token != self.get_api_token():
            self._client = Client(base_url=self.pam_url.url, token=self.get_api_token())
        return self._client

    @property
    def broker_client(self) -> BrokerClient:
        if (
            self._cluster_client is None
            or self._cluster_client._token != self.get_cluster_token()
        ):
            self._ensure_broker_host()
            self._cluster_client = BrokerClient(
                base_url=self.broker_url.url, token=self.get_cluster_token()
            )
        return self._cluster_client

    @property
    def broker_host(self) -> str:
        return self.broker_url.netloc

    @property
    def broker_url(self) -> URL:
        assert self._broker_url is not None
        return self._broker_url

    @property
    def cluster_id(self) -> UUID:
        from .commands._state import get_saved_settings

        if self._cluster_id is None:
            if self._broker_url is None:
                raise CLIError(Messages.E035)
            # The models from pam_sdk need to be generated using the default keyword
            # when using pydantic.Field. Pyright needs this to work well
            # Ref: https://pydantic-docs.helpmanual.io/visual_studio_code/#adding-a-default-with-field
            body = ClusterReading(address=str(self.broker_url))  # pyright: ignore
            cluster = self.client.cluster.read(body)
            self._cluster_id = cluster.id
            get_saved_settings().update(
                "cluster_id",
                self._cluster_id,
            )
        return self._cluster_id

    @property
    def org_id(self) -> UUID:
        # PAM authorizes against the api_token's ``oid`` claim, so the JWT
        # is the source of truth. The saved-defaults pointer (seeded into
        # ``_org_id`` in __init__) can drift — e.g. when secrets.json is
        # restored from backup, when a switch updates the pointer without
        # re-minting the token, or when an ELLF_API_TOKEN env var injects
        # a token from a different org. Reading from the JWT keeps every
        # caller (server-side request bodies, display strings) aligned
        # with what PAM will actually authorize against.
        oid = self.get_api_token().header.get("oid")
        if oid is not None:
            self._org_id = UUID(oid)
            return self._org_id
        if self._org_id is None:
            # Token missing the oid claim (older PAM tokens, or an
            # externally-supplied ELLF_API_TOKEN). Fall back to listing —
            # the login should only have the user's own org accessible.
            orgs = list(self.client.org.all())
            if not orgs:
                raise EllfError(message="Could not fetch orgs")
            self._org_id = orgs[0].id
        return self._org_id

    @property
    def user_id(self) -> UUID:
        """Extract the current user's UUID from the PAM api token.

        Decoded from the JWT's ``uid`` claim (set by pam.tokens.encode_pam_token).
        Reading from the token avoids a /v1/user/read round-trip for the
        common case where a caller just wants to associate state with the
        current user — e.g. persisting last_cluster_id after `clusters use`.
        """
        token = self.get_api_token()
        uid = token.header.get("uid")
        if uid is None:
            raise EllfError(message="PAM token missing uid claim")
        return UUID(uid)

    @property
    def pam_host(self) -> str:
        return self.pam_url.netloc

    @property
    def pam_url(self) -> URL:
        # TODO: better error message
        assert self._pam_url is not None
        return self._pam_url

    @property
    def secrets(self) -> Secrets:
        # Secrets are lazy loaded to prevent `ellf login` from crashing due to
        # a broken secrets file.
        if self._secrets is None:
            self._secrets = FileSecrets.load(self._secrets_path)
        return self._secrets

    def retry_id(self, func: Callable[_P, _R]) -> Callable[_P, _R]:
        def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _R:
            try:
                return func(*args, **kwargs)
            except EllfIDTokenError:
                self.get_id_token(force_refresh=True)
                try:
                    return func(*args, **kwargs)
                except (HTTPError, EllfError) as e:
                    logger.exception(e)
                    raise CLIError(Messages.E104, e)

        return wrapper

    def retry_api(self, func: Callable[_P, _R]) -> Callable[_P, _R]:
        def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _R:
            try:
                return func(*args, **kwargs)
            except HTTPError:
                self.get_api_token(force_refresh=True)
                try:
                    return func(*args, **kwargs)
                except (HTTPError, EllfError) as e:
                    logger.exception(e)
                    raise CLIError(Messages.E105, e)

        return wrapper

    def retry(self, func: Callable[_P, _R]) -> Callable[_P, _R]:
        @self.retry_api
        @self.retry_id
        def wrapper(*args: _P.args, **kwargs: _P.kwargs) -> _R:
            return func(*args, **kwargs)

        return wrapper

    def _ensure_readable_secrets(self) -> Secrets:
        """Try to load the secrets file, cleaning the file if there is an error"""
        self._secrets = None
        try:
            self.secrets
        except EllfParseSecretsError:
            FileSecrets.clean(self._secrets_path)
        return self.secrets

    def _ensure_broker_host(self) -> None:
        # FIXME: move context use into commands
        from .commands._state import get_saved_settings

        if self._broker_url is None:
            clusters_page = self.client.cluster.all(page_size=2).first_page()
            clusters = list(clusters_page.items)
            if len(clusters) == 0:
                raise CLIError(Messages.E106)
            elif len(clusters) == 1:
                self._broker_url = URL.parse(clusters[0].address)
                self._cluster_id = clusters[0].id
                settings = get_saved_settings()
                settings.update("broker_host", self.broker_host)
                settings.update("cluster_id", self._cluster_id)
            else:
                raise CLIError(Messages.E107)

    def set_active_cluster(self, cluster_id: UUID, broker_url: URL) -> None:
        """Switch the active cluster in-memory.

        Persisting to ``SavedSettings`` is the caller's responsibility — this
        only updates the auth state so the next ``broker_client`` /
        ``get_cluster_token`` call targets the new cluster.
        """
        self._broker_url = broker_url
        self._cluster_id = cluster_id
        self._cluster_client = None

    def set_active_org(self, org_id: UUID) -> AccessTokenCredential:
        """Exchange the current api_token for one scoped to ``org_id``.

        PAM tokens carry an org_id claim (each user-org pair is a separate
        ``models.User`` record), so "switching org" is a token-exchange,
        not a local-only change. We POST to ``/v1/token/switch-org`` with
        the current api_token and persist the response in secrets. Any
        cached cluster-scoped broker tokens are dropped because they were
        derived from the old api_token's org.

        Persisting ``org_id`` to ``SavedSettings`` is the caller's
        responsibility.
        """
        api_token = self.get_api_token().access_token
        res = httpx.post(
            str(self.pam_url / "api/v1/token/switch-org"),
            headers={"authorization": f"Bearer {api_token}"},
            json={"org_id": str(org_id)},
            timeout=AUTH_REQUEST_TIMEOUT_SECONDS,
        )
        if res.status_code != 200:
            err = _format_http_error(res)
            if res.status_code == 401:
                raise EllfIDTokenError(err)
            raise EllfError(Messages.E137.format(org_id=org_id) + f": {err}")
        data = res.json()
        new_token = AccessTokenCredential(access_token=data["access_token"])
        self.secrets.api_token = new_token
        # Broker tokens were minted for the previous org; clear them so
        # the next get_cluster_token re-issues against the new org.
        self.secrets.broker_tokens = {}
        if self._secrets_path is not None:
            self.secrets.save(self._secrets_path)
        self._org_id = org_id
        self._client = None
        self._cluster_client = None
        return new_token

    @staticmethod
    def _check_token_expired(
        token: AccessTokenCredential | BrokerAccessTokenCredential | str,
    ) -> bool:
        # TODO: this is reusing the pam_sdk implementation to reduce duplication
        # in the tricky token management logic. Needs to be cleaned up.
        if isinstance(token, str):
            return AccessTokenCredential(access_token=token).expired
        return token.expired

    def get_id_token(self, force_refresh: bool = False) -> str:
        if (
            force_refresh
            or self.secrets.id_token is None
            or self._check_token_expired(self.secrets.id_token)
        ):
            self._client = None
            self._cluster_client = None
            id_token = self._authenticate_device_and_get_id_token()
            self.secrets.id_token = id_token
            if self._secrets_path is not None:
                self.secrets.save(self._secrets_path)
            return id_token
        else:
            return self.secrets.id_token

    def get_api_token(self, force_refresh: bool = False) -> AccessTokenCredential:
        # Allow injecting a PAM JWT via env var (used by the assistant service
        # to authenticate ellf commands on behalf of the logged-in user).
        env_token = os.environ.get("ELLF_API_TOKEN")
        if env_token:
            return AccessTokenCredential(access_token=env_token)
        if (
            self.secrets.api_token is None
            or self.secrets.api_token.expired
            or force_refresh
        ):
            self._client = None
            self._cluster_client = None
            id_token = self.get_id_token(force_refresh=force_refresh)
            api_response = httpx.post(
                str(self.pam_url / "api/v1/login"),
                headers={"authorization": f"Bearer {id_token}"},
                timeout=AUTH_REQUEST_TIMEOUT_SECONDS,
            )
            if api_response.status_code != 200:
                err = _format_http_error(api_response)
                raise EllfIDTokenError(err)
            data = api_response.json()
            token = AccessTokenCredential(access_token=data["access_token"])
            self.secrets.api_token = token
            if self._secrets_path is not None:
                self.secrets.save(self._secrets_path)
            return token
        else:
            return self.secrets.api_token

    def get_cluster_token(
        self, force_refresh: bool = False
    ) -> BrokerAccessTokenCredential:
        self._ensure_broker_host()
        broker_host = self.broker_host
        if (
            broker_host not in self.secrets.broker_tokens
            or self._check_token_expired(self.secrets.broker_tokens[broker_host])
            or force_refresh
        ):
            self._cluster_client = None
            api_token = self.get_api_token().access_token
            # Prefer looking up the cluster by id when we have it. Address
            # lookup is brittle: the registered cluster.address (e.g.
            # 'cluster.example.com' or 'localhost') often doesn't textually
            # match broker_host (e.g. 'https://localhost:8443'), and even
            # canonicalized forms differ when the user includes a port to
            # reach the cluster via tunnel that the cluster.address doesn't
            # carry. cluster_id is unambiguous.
            body: dict[str, str] = {}
            if self._cluster_id is not None:
                body["id"] = str(self._cluster_id)
            else:
                body["address"] = str(URL.parse(broker_host))
            res = httpx.post(
                str(self.pam_url / "api/v1/cluster/token"),
                headers={"authorization": f"Bearer {api_token}"},
                json=body,
                timeout=AUTH_REQUEST_TIMEOUT_SECONDS,
            )
            if res.status_code != 200:
                err = _format_http_error(res)
                if res.status_code == 401:
                    raise EllfIDTokenError(err)
                raise EllfError(err)
            data = res.json()
            pam_cluster_token = data["access_token"]
            # Exchange the PAM-issued cluster-scoped token at the cluster's
            # token exchange endpoint to get a cluster-signed token.
            # See docs/auth-architecture.md State 3 → State 4.
            exchange_res = httpx.post(
                str(self.broker_url / "api/v1/token/exchange"),
                json={"token": pam_cluster_token},
                timeout=AUTH_REQUEST_TIMEOUT_SECONDS,
            )
            if exchange_res.status_code != 200:
                err = _format_http_error(exchange_res)
                if exchange_res.status_code == 401:
                    raise EllfIDTokenError(err)
                raise EllfError(err)
            exchange_data = exchange_res.json()
            token = BrokerAccessTokenCredential(
                access_token=exchange_data["access_token"]
            )
            self.secrets.broker_tokens[broker_host] = token
            if self._secrets_path is not None:
                self.secrets.save(self._secrets_path)
            return token
        else:
            return self.secrets.broker_tokens[broker_host]

    def _safe_json(self, response: httpx.Response, url: str) -> dict:
        """Decode an auth-endpoint response as JSON, or raise a clear error.

        Auth endpoints can return non-JSON when traffic is routed to the
        wrong backend (LB misconfigured, CDN intercept, etc). Without this
        helper the symptom is an opaque ``json.JSONDecodeError`` deep in
        httpx; with it, the error names the URL, status code, content
        type, and a body excerpt — enough to diagnose where the routing
        broke.
        """
        try:
            return response.json()
        except ValueError:
            body = response.text[:200].replace("\n", " ")
            raise CLIError(
                Messages.E102.format(
                    url=url,
                    status=response.status_code,
                    reason=response.reason_phrase or "?",
                    content_type=response.headers.get("content-type", "?"),
                    body=body,
                )
            )

    def _authenticate_device_and_get_id_token(self) -> str:
        try:
            config_response = httpx.get(
                str(self.pam_url / "api/v1/cli.json"),
                timeout=AUTH_REQUEST_TIMEOUT_SECONDS,
            )
            config_response.raise_for_status()
        except httpx.HTTPError as exc:
            err = Messages.E033.format(url=self.pam_url)
            logger.exception(err)
            raise EllfError(err) from exc
        device_code_url = str(self.pam_url / "api/v1/device/code")
        token_url = str(self.pam_url / "api/v1/device/token")
        response = httpx.post(
            device_code_url,
            json={"scope": OIDC_SCOPE},
            timeout=AUTH_REQUEST_TIMEOUT_SECONDS,
        )
        data = self._safe_json(response, device_code_url)
        if response.status_code != 200:
            raise CLIError(Messages.E101, data)
        device_code = data.get("device_code")
        user_code = data.get("user_code")
        uri = data.get("verification_uri")
        interval = data.get("interval", 5)
        uri_complete = data.get("verification_uri_complete")
        if not (device_code and user_code and uri and interval and uri_complete):
            raise CLIError(Messages.E032, data)
        print_login_info(uri_complete, uri, user_code, no_browser=self.no_browser)
        last_check = 0
        for _ in range(AUTH_WAIT_TIME_SECONDS):
            if time.time() > (last_check + int(interval)):
                token_response = httpx.post(
                    token_url,
                    json={
                        "grant_type": OIDC_DEVICE_GRANT_TYPE,
                        "device_code": device_code,
                    },
                    timeout=AUTH_REQUEST_TIMEOUT_SECONDS,
                )
                last_check = time.time()
                token_data = self._safe_json(token_response, token_url)
                if token_response.status_code == 200:
                    id_token = token_data.get("id_token")
                    if id_token is None:
                        raise EllfIDTokenError(
                            "Device auth succeeded but no id_token in response"
                        )
                    return id_token
            time.sleep(1)
        raise EllfIDTokenError(Messages.E031)
