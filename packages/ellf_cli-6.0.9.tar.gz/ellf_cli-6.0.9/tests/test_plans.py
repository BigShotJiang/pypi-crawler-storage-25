from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Any
from uuid import UUID, uuid4

import pytest

from ellf_cli import query
from ellf_cli.commands import plans as plans_cmd
from ellf_cli.errors import CLIError
from ellf_pam_sdk.errors import ProjectNotFound, ProjectPlanVersionConflict
from ellf_pam_sdk.ty import Page


def _detail(
    project_id: UUID,
    name: str = "project_plan",
    content: str = "",
    *,
    version: int = 1,
    updated_by_id: UUID | None = None,
) -> Any:
    now = datetime.now(timezone.utc)
    return SimpleNamespace(
        id=uuid4(),
        project_id=project_id,
        name=name,
        content=content,
        version=version,
        updated_by_id=updated_by_id or uuid4(),
        created=now,
        updated=now,
        model_dump_json=lambda **_: "{}",
    )


def _revision_detail(
    plan_id: UUID,
    version: int,
    content: str,
    *,
    created_by_id: UUID | None = None,
) -> Any:
    now = datetime.now(timezone.utc)
    return SimpleNamespace(
        id=uuid4(),
        plan_id=plan_id,
        version=version,
        content=content,
        created_by_id=created_by_id or uuid4(),
        created=now,
        updated=now,
        model_dump_json=lambda **_: "{}",
    )


class _FakeProjectClient:
    def __init__(self, by_name: dict[str, UUID]) -> None:
        self._by_name = by_name
        self.calls: list[dict[str, Any]] = []

    def read(self, **kwargs: Any) -> Any:
        self.calls.append(kwargs)
        name = kwargs.get("name")
        if name in self._by_name:
            return SimpleNamespace(id=self._by_name[name])
        raise ProjectNotFound(f"no project named {name!r}")


_UNSET = object()


class _FakeProjectPlanClient:
    def __init__(self) -> None:
        self.list_calls: list[UUID] = []
        self.read_calls: list[dict[str, Any]] = []
        self.upsert_calls: list[dict[str, Any]] = []
        self.delete_calls: list[dict[str, Any]] = []
        self.list_revisions_calls: list[dict[str, Any]] = []
        self.read_revision_calls: list[dict[str, Any]] = []
        self.upsert_raises: Exception | None = None
        self.read_returns: Any = _UNSET
        self.list_returns: list[Any] = []
        self.list_revisions_returns: Page[Any] | None = None
        self.read_revision_returns: Any | None = None

    def list(self, project_id: UUID) -> list[Any]:
        self.list_calls.append(project_id)
        return self.list_returns

    def read(self, **kwargs: Any) -> Any:
        self.read_calls.append(kwargs)
        if self.read_returns is not _UNSET:
            return self.read_returns
        # Default fabricated plan; works for both name- and id-based reads.
        project_id = kwargs.get("project_id") or uuid4()
        return _detail(project_id, kwargs.get("name", "project_plan"))

    def upsert(
        self,
        project_id: UUID,
        name: str,
        *,
        content: str,
        expected_version: int | None = None,
    ) -> Any:
        self.upsert_calls.append(
            {
                "project_id": project_id,
                "name": name,
                "content": content,
                "expected_version": expected_version,
            }
        )
        if self.upsert_raises is not None:
            raise self.upsert_raises
        return _detail(project_id, name, content)

    def delete(self, **kwargs: Any) -> None:
        self.delete_calls.append(kwargs)

    def list_revisions(
        self,
        project_id: UUID,
        name: str = "project_plan",
        *,
        after: UUID | None = None,
        size: int = 50,
    ) -> Page[Any]:
        self.list_revisions_calls.append(
            {
                "project_id": project_id,
                "name": name,
                "after": after,
                "size": size,
            }
        )
        if self.list_revisions_returns is not None:
            return self.list_revisions_returns
        return Page(items=[], next_cursor=None, has_more=False)

    def read_revision(self, *, plan_id: UUID, version: int) -> Any:
        self.read_revision_calls.append({"plan_id": plan_id, "version": version})
        if self.read_revision_returns is not None:
            return self.read_revision_returns
        return _revision_detail(plan_id, version, content=f"v{version}")


@pytest.fixture
def fake_clients(monkeypatch):
    project_id = uuid4()
    project_client = _FakeProjectClient({"my-project": project_id})
    plan_client = _FakeProjectPlanClient()
    auth = SimpleNamespace(
        client=SimpleNamespace(project=project_client, project_plan=plan_client)
    )
    monkeypatch.setattr(plans_cmd, "get_auth_state", lambda: auth)
    monkeypatch.setattr(query, "get_auth_state", lambda: auth)
    return SimpleNamespace(
        project_id=project_id, project=project_client, plan=plan_client
    )


def test_list_calls_sdk_with_project_id(fake_clients, monkeypatch):
    monkeypatch.setattr(
        plans_cmd, "print_table_with_select", lambda *_args, **_kwargs: None
    )

    plans_cmd.list(fake_clients.project_id)

    assert fake_clients.plan.list_calls == [fake_clients.project_id]


def test_list_select_includes_version(fake_clients, monkeypatch):
    captured: dict[str, Any] = {}

    def _capture(items, *, select=None, as_json=False):
        captured["select"] = select

    monkeypatch.setattr(plans_cmd, "print_table_with_select", _capture)

    plans_cmd.list(fake_clients.project_id)

    assert "version" in captured["select"]
    assert "updated_by_id" in captured["select"]


def test_list_filters_by_name_substring(fake_clients, monkeypatch):
    captured: dict[str, Any] = {}

    def _capture(items, *, select=None, as_json=False):
        captured["items"] = items

    monkeypatch.setattr(plans_cmd, "print_table_with_select", _capture)
    fake_clients.plan.list_returns = [
        _detail(fake_clients.project_id, name="ner-component"),
        _detail(fake_clients.project_id, name="evaluation-design"),
        _detail(fake_clients.project_id, name="ner-eval"),
    ]

    plans_cmd.list(fake_clients.project_id, name="ner")

    names = [p.name for p in captured["items"]]
    assert names == ["ner-component", "ner-eval"]


def test_read_calls_sdk_with_project_id(fake_clients):
    plans_cmd.read(project_id=fake_clients.project_id, as_json=True)

    assert fake_clients.plan.read_calls == [
        {"project_id": fake_clients.project_id, "name": "project_plan"}
    ]


def test_read_lists_siblings_when_named_plan_missing(fake_clients, capsys):
    fake_clients.plan.read_returns = None
    fake_clients.plan.list_returns = [
        _detail(fake_clients.project_id, name="ner-component", version=3),
        _detail(fake_clients.project_id, name="evaluation-design", version=1),
    ]

    with pytest.raises(SystemExit) as exc:
        plans_cmd.read(project_id=fake_clients.project_id)

    assert exc.value.code == 1
    out = capsys.readouterr().out
    assert "No plan 'project_plan' for this project" in out
    assert "evaluation-design (v1)" in out
    assert "ner-component (v3)" in out
    assert out.index("evaluation-design") < out.index("ner-component")


def test_read_no_siblings_prints_no_plans_and_exits_zero(fake_clients, capsys):
    fake_clients.plan.read_returns = None
    fake_clients.plan.list_returns = []

    plans_cmd.read(project_id=fake_clients.project_id)

    out = capsys.readouterr().out
    assert "No plans for this project" in out


def test_read_json_mode_silent_when_plan_missing(fake_clients, capsys):
    fake_clients.plan.read_returns = None
    fake_clients.plan.list_returns = [
        _detail(fake_clients.project_id, name="ner-component", version=3),
    ]

    plans_cmd.read(project_id=fake_clients.project_id, as_json=True)

    out = capsys.readouterr().out
    assert out.strip() == "{}"
    assert fake_clients.plan.list_calls == []


def test_read_with_version_looks_up_plan_then_reads_revision(fake_clients):
    plan_id = uuid4()
    fake_clients.plan.read_returns = _detail(fake_clients.project_id, version=4)
    fake_clients.plan.read_returns.id = plan_id
    fake_clients.plan.read_revision_returns = _revision_detail(
        plan_id, version=2, content="v2 content"
    )

    plans_cmd.read(project_id=fake_clients.project_id, version=2, as_json=True)

    assert fake_clients.plan.read_calls == [
        {"project_id": fake_clients.project_id, "name": "project_plan"}
    ]
    assert fake_clients.plan.read_revision_calls == [{"plan_id": plan_id, "version": 2}]


def test_read_with_version_raises_when_plan_missing(fake_clients):
    fake_clients.plan.read_returns = None

    with pytest.raises(CLIError):
        plans_cmd.read(project_id=fake_clients.project_id, version=1, as_json=False)

    assert fake_clients.plan.read_revision_calls == []


def test_write_first_time_upserts_with_no_expected_version(fake_clients):
    """No existing plan: read returns None, upsert sends expected_version=None."""
    fake_clients.plan.read_returns = None

    plans_cmd.write(project_id=fake_clients.project_id, content="hello", as_json=True)

    assert fake_clients.plan.read_calls == [
        {"project_id": fake_clients.project_id, "name": "project_plan"}
    ]
    assert fake_clients.plan.upsert_calls == [
        {
            "project_id": fake_clients.project_id,
            "name": "project_plan",
            "content": "hello",
            "expected_version": None,
        }
    ]


def test_write_existing_plan_reads_then_upserts_with_version(fake_clients):
    """Existing plan: read captures version, upsert forwards it as expected_version."""
    fake_clients.plan.read_returns = _detail(fake_clients.project_id, version=7)

    plans_cmd.write(project_id=fake_clients.project_id, content="next", as_json=True)

    assert fake_clients.plan.upsert_calls == [
        {
            "project_id": fake_clients.project_id,
            "name": "project_plan",
            "content": "next",
            "expected_version": 7,
        }
    ]


def test_write_on_version_conflict_prints_head_and_exits_one(fake_clients, capsys):
    head_id = uuid4()
    fake_clients.plan.read_returns = _detail(fake_clients.project_id, version=2)
    fake_clients.plan.upsert_raises = ProjectPlanVersionConflict(
        current_version=5,
        current_content="head content",
        current_id=head_id,
    )

    with pytest.raises(SystemExit) as exc_info:
        plans_cmd.write(
            project_id=fake_clients.project_id, content="stale", as_json=False
        )

    assert exc_info.value.code == 1
    out = capsys.readouterr().out
    assert "head content" in out
    assert "5" in out


def test_revisions_forwards_args(fake_clients):
    cursor = uuid4()
    plans_cmd.revisions(
        project_id=fake_clients.project_id,
        name_or_id="project_plan",
        size=10,
        after=cursor,
        as_json=True,
    )

    assert fake_clients.plan.list_revisions_calls == [
        {
            "project_id": fake_clients.project_id,
            "name": "project_plan",
            "after": cursor,
            "size": 10,
        }
    ]


def test_revisions_prints_next_cursor_when_has_more(fake_clients, monkeypatch, capsys):
    monkeypatch.setattr(
        plans_cmd, "print_table_with_select", lambda *_args, **_kwargs: None
    )
    next_cursor = uuid4()
    fake_clients.plan.list_revisions_returns = Page(
        items=[],
        next_cursor=str(next_cursor),
        has_more=True,
    )

    plans_cmd.revisions(
        project_id=fake_clients.project_id,
        name_or_id="project_plan",
        as_json=False,
    )

    out = capsys.readouterr().out
    assert str(next_cursor) in out


def test_delete_by_name_resolves_to_plan_id(fake_clients):
    fake_clients.plan.read_returns = _detail(fake_clients.project_id)
    plan_id = fake_clients.plan.read_returns.id

    plans_cmd.delete(
        name_or_id="project_plan",
        project_id=fake_clients.project_id,
        as_json=True,
    )

    assert fake_clients.plan.delete_calls == [{"id": plan_id}]


def test_delete_by_uuid_positional_skips_name_lookup(fake_clients):
    plan_id = uuid4()

    plans_cmd.delete(name_or_id=plan_id, as_json=True)

    assert fake_clients.project.calls == []
    assert fake_clients.plan.read_calls == []
    assert fake_clients.plan.delete_calls == [{"id": plan_id}]


# ---------------------------------------------------------------------------
# --project-id accepts name / slug, not just UUID
#
# The CLI's recipe-create path canonicalises name/slug/UUID at entry via
# resolve_project_id; plans was the one command group still rejecting
# non-UUID values. These tests pin the new behaviour: a project name or
# slug passed to --project-id resolves to a UUID before any SDK call.


def test_list_accepts_project_name(fake_clients, monkeypatch):
    monkeypatch.setattr(plans_cmd, "print_table_with_select", lambda *_a, **_kw: None)

    plans_cmd.list("my-project")

    assert fake_clients.plan.list_calls == [fake_clients.project_id]


def test_list_falls_back_to_saved_project(fake_clients, monkeypatch):
    """``plans list`` with no --project-id uses the saved default project,
    matching the rest of the plans family (read/write/revisions/delete) and
    the rest of the CLI.
    """
    monkeypatch.setattr(plans_cmd, "print_table_with_select", lambda *_a, **_kw: None)
    monkeypatch.setattr(
        plans_cmd,
        "get_saved_settings",
        lambda: SimpleNamespace(project=fake_clients.project_id),
    )

    plans_cmd.list()

    assert fake_clients.plan.list_calls == [fake_clients.project_id]


def test_list_errors_when_no_project_id_and_no_saved_default(fake_clients, monkeypatch):
    monkeypatch.setattr(plans_cmd, "print_table_with_select", lambda *_a, **_kw: None)
    monkeypatch.setattr(
        plans_cmd,
        "get_saved_settings",
        lambda: SimpleNamespace(project=None),
    )

    with pytest.raises(CLIError):
        plans_cmd.list()

    assert fake_clients.plan.list_calls == []


def test_read_accepts_project_name(fake_clients):
    plans_cmd.read(project_id="my-project", as_json=True)

    assert fake_clients.plan.read_calls == [
        {"project_id": fake_clients.project_id, "name": "project_plan"}
    ]


def test_write_accepts_project_name(fake_clients):
    fake_clients.plan.read_returns = None

    plans_cmd.write(project_id="my-project", content="hello", as_json=True)

    assert fake_clients.plan.upsert_calls == [
        {
            "project_id": fake_clients.project_id,
            "name": "project_plan",
            "content": "hello",
            "expected_version": None,
        }
    ]


def test_revisions_accepts_project_name(fake_clients, monkeypatch):
    monkeypatch.setattr(plans_cmd, "print_table_with_select", lambda *_a, **_kw: None)
    fake_clients.plan.read_returns = _detail(fake_clients.project_id, name="my-plan")

    plans_cmd.revisions("my-plan", project_id="my-project", as_json=True)

    assert fake_clients.plan.list_revisions_calls == [
        {
            "project_id": fake_clients.project_id,
            "name": "my-plan",
            "after": None,
            "size": 50,
        }
    ]


def test_delete_accepts_project_name(fake_clients):
    plan = _detail(fake_clients.project_id, name="my-plan")
    fake_clients.plan.read_returns = plan

    plans_cmd.delete("my-plan", project_id="my-project", as_json=True)

    assert fake_clients.plan.delete_calls == [{"id": plan.id}]
