from unittest.mock import MagicMock
from uuid import UUID, uuid4

import pytest

from ellf_cli.commands._org_select import (
    _match_org,
    list_person_orgs,
    select_org,
)
from ellf_cli.errors import CLIError


def _membership(name: str, org_id: UUID | None = None) -> dict:
    """Build a JSON-shaped OrgMembership row the way pam returns it."""
    return {
        "org_id": str(org_id or uuid4()),
        "org_name": name,
        "user_id": str(uuid4()),
        "is_org_admin": False,
        "is_org_developer": True,
    }


def _client_with_orgs(rows: list[dict]) -> MagicMock:
    """Build a fake pam_sdk Client whose ``_sync_client.post`` returns rows."""
    client = MagicMock()
    response = MagicMock()
    response.json.return_value = rows
    response.raise_for_status.return_value = None
    client._sync_client.post.return_value = response
    return client


def test_list_person_orgs_hits_person_orgs_endpoint():
    rows = [_membership("acme")]
    client = _client_with_orgs(rows)
    result = list_person_orgs(client)
    assert len(result) == 1
    assert result[0].org_name == "acme"
    client._sync_client.post.assert_called_once_with("/api/v1/person/orgs")


def test_match_org_by_name():
    org_id = uuid4()
    rows = [_membership("acme", org_id), _membership("globex")]
    from ellf_pam_sdk.models import OrgMembership

    orgs = [OrgMembership.model_validate(r) for r in rows]
    matched = _match_org(orgs, "globex")
    assert matched is not None
    assert matched.org_name == "globex"


def test_match_org_by_uuid_string():
    org_id = uuid4()
    rows = [_membership("acme", org_id)]
    from ellf_pam_sdk.models import OrgMembership

    orgs = [OrgMembership.model_validate(r) for r in rows]
    matched = _match_org(orgs, str(org_id))
    assert matched is not None
    assert matched.org_id == org_id


def test_match_org_by_uuid_object():
    org_id = uuid4()
    rows = [_membership("acme", org_id)]
    from ellf_pam_sdk.models import OrgMembership

    orgs = [OrgMembership.model_validate(r) for r in rows]
    matched = _match_org(orgs, org_id)
    assert matched is not None
    assert matched.org_id == org_id


def test_match_org_no_match_returns_none():
    from ellf_pam_sdk.models import OrgMembership

    orgs = [OrgMembership.model_validate(_membership("acme"))]
    assert _match_org(orgs, "nope") is None


def test_select_org_no_orgs_raises():
    client = _client_with_orgs([])
    with pytest.raises(CLIError):
        select_org(client)


def test_select_org_single_auto_selects():
    rows = [_membership("acme")]
    client = _client_with_orgs(rows)
    chosen = select_org(client)
    assert chosen.org_name == "acme"


def test_select_org_by_name_picks_match():
    rows = [_membership("acme"), _membership("globex")]
    client = _client_with_orgs(rows)
    chosen = select_org(client, "globex")
    assert chosen.org_name == "globex"


def test_select_org_by_name_no_match_raises():
    rows = [_membership("acme"), _membership("globex")]
    client = _client_with_orgs(rows)
    with pytest.raises(CLIError):
        select_org(client, "missing")


def test_select_org_multiple_non_tty_raises(monkeypatch):
    """With multiple orgs and no name_or_id, a non-TTY caller must error,
    not block on an interactive prompt — same contract as cluster select.
    """
    rows = [_membership("acme"), _membership("globex")]
    client = _client_with_orgs(rows)
    # Force isatty=False so _prompt_for_org raises immediately.
    monkeypatch.setattr("ellf_cli.commands._org_select.isatty", lambda _: False)
    with pytest.raises(CLIError):
        select_org(client)
