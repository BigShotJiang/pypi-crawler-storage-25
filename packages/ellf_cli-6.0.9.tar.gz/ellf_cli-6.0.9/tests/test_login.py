import json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
from uuid import uuid4


def _plugin_runtime_files(base_dir: Path) -> dict[Path, bytes]:
    ignored_parts = {"tests", "backups", "evals", ".git", "__pycache__"}
    files = {}
    for path in sorted(base_dir.rglob("*")):
        if not path.is_file():
            continue
        rel_path = path.relative_to(base_dir)
        if any(part in ignored_parts for part in rel_path.parts):
            continue
        files[rel_path] = path.read_bytes()
    return files


def _make_fake_plugin(tmp_path: Path) -> Path:
    plugin_dir = tmp_path / "ellf-plugin"
    (plugin_dir / ".claude-plugin").mkdir(parents=True)
    (plugin_dir / ".claude-plugin" / "plugin.json").write_text(
        '{"name":"ellf-skills","version":"0.1.0"}', encoding="utf-8"
    )
    (plugin_dir / "skill_variants.json").write_text(
        json.dumps({"ellf-ask": {"coding": "ellf-ask"}}), encoding="utf-8"
    )
    (plugin_dir / "skills" / "ellf-ask").mkdir(parents=True)
    (plugin_dir / "skills" / "ellf-ask" / "SKILL.md").write_text(
        "---\nname: ellf-ask\n---", encoding="utf-8"
    )
    return plugin_dir


def test_ellf_claude_plugin_dir_prefers_packaged_assets():
    from ellf_cli.commands.general import _ellf_claude_plugin_dir

    plugin_dir = _ellf_claude_plugin_dir()
    assert plugin_dir is not None
    assert plugin_dir.name == "ellf_skills"
    assert (plugin_dir / "skill_variants.json").exists()


def test_packaged_claude_assets_live_in_cli_package():
    repo_root = Path(__file__).resolve().parents[2]
    packaged_dir = repo_root / "cli" / "ellf_cli" / "ellf_skills"

    assert (packaged_dir / "skill_variants.json").exists()
    assert _plugin_runtime_files(packaged_dir)


def test_install_claude_skills_success(tmp_path, monkeypatch):
    """Skills are copied to ~/.claude/skills/ when ellf_skills is available."""
    from ellf_cli.commands.general import _install_claude_skills

    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    plugin_dir = _make_fake_plugin(tmp_path)

    with patch(
        "ellf_cli.commands.general._ellf_claude_plugin_dir",
        return_value=plugin_dir,
    ):
        _install_claude_skills()

    assert (tmp_path / ".claude" / "skills" / "ellf-ask").is_dir()
    assert not (tmp_path / ".claude" / "settings.json").exists()


def test_install_claude_skills_missing_package(tmp_path, monkeypatch):
    """Shows a warning when ellf_skills is not installed."""
    from ellf_cli.commands.general import _install_claude_skills

    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    with patch("ellf_cli.commands.general._ellf_claude_plugin_dir", return_value=None):
        _install_claude_skills()

    assert not (tmp_path / ".claude" / "skills").exists()


def test_install_claude_skills_overwrites_existing(tmp_path, monkeypatch):
    """Existing skill dir is replaced, not merged."""
    from ellf_cli.commands.general import _install_claude_skills

    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    dest = tmp_path / ".claude" / "skills" / "ellf-ask"
    dest.mkdir(parents=True)
    (dest / "stale.md").write_text("stale")

    plugin_dir = _make_fake_plugin(tmp_path)

    with patch(
        "ellf_cli.commands.general._ellf_claude_plugin_dir",
        return_value=plugin_dir,
    ):
        _install_claude_skills()

    assert not (dest / "stale.md").exists()
    assert (dest / "SKILL.md").exists()


def test_install_claude_skills_uses_canonical_name(tmp_path, monkeypatch):
    """Variant source directories install under the canonical slash-command name."""
    from ellf_cli.commands.general import _install_claude_skills

    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    plugin_dir = tmp_path / "ellf-plugin"
    (plugin_dir / ".claude-plugin").mkdir(parents=True)
    (plugin_dir / ".claude-plugin" / "plugin.json").write_text(
        '{"name":"ellf-skills","version":"0.1.0"}', encoding="utf-8"
    )
    (plugin_dir / "skill_variants.json").write_text(
        json.dumps({"ellf-project": {"coding": "ellf-project.coding"}}),
        encoding="utf-8",
    )
    (plugin_dir / "skills" / "ellf-project.coding").mkdir(parents=True)
    (plugin_dir / "skills" / "ellf-project.coding" / "SKILL.md").write_text(
        "---\nname: ellf-project\n---", encoding="utf-8"
    )
    (plugin_dir / "skills" / "ellf-project.assistant").mkdir(parents=True)
    (plugin_dir / "skills" / "ellf-project.assistant" / "SKILL.md").write_text(
        "---\nname: ellf-project\n---", encoding="utf-8"
    )

    with patch(
        "ellf_cli.commands.general._ellf_claude_plugin_dir",
        return_value=plugin_dir,
    ):
        _install_claude_skills()

    assert (tmp_path / ".claude" / "skills" / "ellf-project").is_dir()
    assert not (tmp_path / ".claude" / "skills" / "ellf-project.coding").exists()
    assert not (tmp_path / ".claude" / "skills" / "ellf-project.assistant").exists()


def test_install_claude_skills_with_packaged_plugin(tmp_path, monkeypatch):
    """The packaged plugin coding skill set is copied under canonical names."""

    from ellf_cli.commands.general import _install_claude_skills

    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    repo_root = Path(__file__).resolve().parents[2]
    vendor_path = repo_root / "cli" / "ellf_cli" / "ellf_skills"
    with patch(
        "ellf_cli.commands.general._ellf_claude_plugin_dir",
        return_value=vendor_path,
    ):
        _install_claude_skills()

    dest = tmp_path / ".claude" / "skills"
    assert (dest / "ellf-train").is_dir()
    assert (dest / "ellf-patterns").is_dir()


def _fake_membership(org_id, org_name="acme"):
    return SimpleNamespace(
        org_id=org_id,
        org_name=org_name,
        user_id=uuid4(),
        is_org_admin=True,
        is_org_developer=True,
    )


def _build_select_org_test(tmp_path, monkeypatch, *, jwt_oid, saved_org, chosen_org):
    """Common scaffolding for _select_and_persist_org tests.

    Patches the three module-level lookups the function depends on
    (``select_org``, ``get_saved_settings``, ``get_root_cfg``) and returns
    a mock ``auth`` whose ``get_api_token().header['oid']`` is ``jwt_oid``.
    """
    from ellf_cli.commands import general
    from ellf_cli.config import SavedSettings

    settings = SavedSettings.blank()
    settings.org_id = saved_org
    settings_path = tmp_path / "saved-defaults.json"
    monkeypatch.setattr(general, "get_saved_settings", lambda: settings)
    monkeypatch.setattr(
        general,
        "get_root_cfg",
        lambda: SimpleNamespace(saved_settings_path=settings_path),
    )
    monkeypatch.setattr(
        general,
        "select_org",
        MagicMock(return_value=_fake_membership(chosen_org)),
    )

    auth = MagicMock()
    auth.get_api_token.return_value = SimpleNamespace(header={"oid": str(jwt_oid)})
    return general, auth, settings, settings_path


def test_select_and_persist_org_reissues_when_jwt_disagrees(tmp_path, monkeypatch):
    """Regression: even if saved-defaults already names the chosen org, a
    mismatched JWT must trigger ``/v1/token/switch-org`` so the local
    pointer and the server-side authorization converge.
    """
    chosen_org = uuid4()
    jwt_org = uuid4()  # token was issued for a different org
    general, auth, settings, settings_path = _build_select_org_test(
        tmp_path,
        monkeypatch,
        jwt_oid=jwt_org,
        saved_org=chosen_org,  # stale pointer already at chosen
        chosen_org=chosen_org,
    )

    result = general._select_and_persist_org(auth, chosen_org)

    assert result == chosen_org
    auth.set_active_org.assert_called_once_with(chosen_org)
    assert settings.org_id == chosen_org
    assert json.loads(settings_path.read_text())["org_id"] == str(chosen_org)


def test_select_and_persist_org_skips_reissue_when_jwt_matches(tmp_path, monkeypatch):
    """No token round-trip when the JWT already authorizes the chosen org."""
    chosen_org = uuid4()
    general, auth, _, _ = _build_select_org_test(
        tmp_path,
        monkeypatch,
        jwt_oid=chosen_org,
        saved_org=uuid4(),  # saved-defaults out of sync the other way
        chosen_org=chosen_org,
    )

    result = general._select_and_persist_org(auth, chosen_org)

    assert result == chosen_org
    auth.set_active_org.assert_not_called()


def test_install_claude_skills_leaves_existing_settings_untouched(
    tmp_path, monkeypatch
):
    from ellf_cli.commands.general import _install_claude_skills

    monkeypatch.setattr(Path, "home", lambda: tmp_path)

    settings_path = tmp_path / ".claude" / "settings.json"
    settings_path.parent.mkdir(parents=True)
    settings_payload = {"enabledPlugins": {"existing": True}}
    settings_path.write_text(json.dumps(settings_payload), encoding="utf-8")

    plugin_dir = _make_fake_plugin(tmp_path)

    with patch(
        "ellf_cli.commands.general._ellf_claude_plugin_dir",
        return_value=plugin_dir,
    ):
        _install_claude_skills()

    settings = json.loads(settings_path.read_text())
    assert settings == settings_payload
