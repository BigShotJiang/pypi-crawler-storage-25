"""Tests for ellf_cli.query — helper functions that don't need auth."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any
from uuid import UUID, uuid4

import pytest

from ellf_cli import query
from ellf_cli.query import _normalise_scope_params, get_not_found_error
from ellf_pam_sdk.errors import ClusterNotFound, ProjectNotFound


class TestGetNotFoundError:
    def test_task(self):
        err = get_not_found_error("task")
        assert err.__name__ == "TaskNotFound"

    def test_action(self):
        err = get_not_found_error("action")
        assert err.__name__ == "ActionNotFound"

    def test_project(self):
        err = get_not_found_error("project")
        assert err.__name__ == "ProjectNotFound"

    def test_cluster(self):
        err = get_not_found_error("cluster")
        assert err.__name__ == "ClusterNotFound"

    def test_dataset(self):
        err = get_not_found_error("dataset")
        assert err.__name__ == "DatasetNotFound"

    def test_secret(self):
        err = get_not_found_error("secret")
        assert err.__name__ == "SecretNotFound"

    def test_cluster_path(self):
        err = get_not_found_error("cluster_path")
        assert err.__name__ == "ClusterPathNotFound"


# ---------------------------------------------------------------------------
# Scope-param normalisation: ``--project-id`` / ``--cluster-id`` accept
# name/slug/UUID across every command that funnels through ``_resolve_object``
# or ``_resolve_id``. This pins the central normalisation point.


class _FakeLookupClient:
    """SDK lookup stub: only honours name-keyed reads."""

    def __init__(
        self, by_name: dict[str, UUID], not_found: type[BaseException]
    ) -> None:
        self._by_name = by_name
        self._not_found = not_found

    def read(self, **kwargs: Any) -> Any:
        name = kwargs.get("name")
        if name in self._by_name:
            return SimpleNamespace(id=self._by_name[name])
        raise self._not_found(f"no record named {name!r}")


@pytest.fixture
def fake_scope_resolution(monkeypatch):
    project_id = uuid4()
    cluster_id = uuid4()
    auth = SimpleNamespace(
        client=SimpleNamespace(
            project=_FakeLookupClient({"my-project": project_id}, ProjectNotFound),
            cluster=_FakeLookupClient({"my-cluster": cluster_id}, ClusterNotFound),
        )
    )
    monkeypatch.setattr(query, "get_auth_state", lambda: auth)
    return SimpleNamespace(project_id=project_id, cluster_id=cluster_id)


class TestNormaliseScopeParams:
    def test_uuid_passthrough(self, fake_scope_resolution):
        project_id = fake_scope_resolution.project_id
        cluster_id = fake_scope_resolution.cluster_id
        out = _normalise_scope_params(
            {"project_id": project_id, "cluster_id": cluster_id}
        )
        assert out == {"project_id": project_id, "cluster_id": cluster_id}

    def test_none_passthrough(self):
        out = _normalise_scope_params({"project_id": None, "cluster_id": None})
        assert out == {"project_id": None, "cluster_id": None}

    def test_resolves_project_name_to_uuid(self, fake_scope_resolution):
        out = _normalise_scope_params({"project_id": "my-project"})
        assert out == {"project_id": fake_scope_resolution.project_id}

    def test_resolves_cluster_name_to_uuid(self, fake_scope_resolution):
        out = _normalise_scope_params({"cluster_id": "my-cluster"})
        assert out == {"cluster_id": fake_scope_resolution.cluster_id}

    def test_resolves_both_in_one_call(self, fake_scope_resolution):
        out = _normalise_scope_params(
            {"project_id": "my-project", "cluster_id": "my-cluster"}
        )
        assert out == {
            "project_id": fake_scope_resolution.project_id,
            "cluster_id": fake_scope_resolution.cluster_id,
        }

    def test_uuid_string_passthrough(self, fake_scope_resolution):
        # A UUID supplied as a string (e.g. parsed by radicli but not yet
        # converted to UUID) should be left alone -- no PAM lookup needed.
        project_id = fake_scope_resolution.project_id
        out = _normalise_scope_params({"project_id": str(project_id)})
        assert out == {"project_id": str(project_id)}

    def test_does_not_touch_unrelated_keys(self, fake_scope_resolution):
        out = _normalise_scope_params({"name": "foo", "after": "cursor-1"})
        assert out == {"name": "foo", "after": "cursor-1"}
