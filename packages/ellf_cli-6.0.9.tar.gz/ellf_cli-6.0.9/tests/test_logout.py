from uuid import uuid4

from ellf_cli.auth import FileSecrets
from ellf_cli.commands._state import get_root_cfg, get_saved_settings
from ellf_cli.commands.general import logout
from ellf_cli.config import DEFAULT_PAM_HOST, SavedSettings


def _seed_secrets() -> None:
    """Write a secrets.json with a sentinel id_token at the active config path."""
    ctx = get_root_cfg()
    ctx.secrets_path.parent.mkdir(parents=True, exist_ok=True)
    FileSecrets(id_token="sentinel-id-token").save(ctx.secrets_path)


def _seed_settings() -> None:
    """Write saved-defaults.json populated with workflow defaults."""
    ctx = get_root_cfg()
    settings = SavedSettings(
        broker_host="https://cluster.example.com",
        project=uuid4(),
        task=uuid4(),
        action=uuid4(),
        agent=uuid4(),
        pam_host="https://pam.example.com",
        cluster_id=uuid4(),
        org_id=uuid4(),
        recipes_file="/tmp/recipes.json",
    )
    settings.save(ctx.saved_settings_path)


def test_logout_removes_secrets_file():
    _seed_secrets()
    ctx = get_root_cfg()
    assert ctx.secrets_path.exists()
    logout()
    assert not ctx.secrets_path.exists()


def test_logout_is_idempotent_when_no_secrets():
    ctx = get_root_cfg()
    assert not ctx.secrets_path.exists()
    # Should not raise even when nothing to clean up.
    logout()
    assert not ctx.secrets_path.exists()


def test_logout_default_keeps_saved_settings():
    _seed_secrets()
    _seed_settings()
    ctx = get_root_cfg()
    logout()
    # secrets gone, saved-defaults untouched
    assert not ctx.secrets_path.exists()
    persisted = SavedSettings.from_file(ctx.saved_settings_path)
    assert persisted.org_id is not None
    assert persisted.cluster_id is not None
    assert persisted.broker_host == "https://cluster.example.com"


def test_logout_all_resets_saved_settings():
    _seed_secrets()
    _seed_settings()
    ctx = get_root_cfg()
    logout(all_=True)
    assert not ctx.secrets_path.exists()
    persisted = SavedSettings.from_file(ctx.saved_settings_path)
    # `blank()` zeroes everything except pam_host, which defaults back
    # to DEFAULT_PAM_HOST so the next `ellf login` still knows where
    # to talk.
    assert persisted.org_id is None
    assert persisted.cluster_id is None
    assert persisted.broker_host is None
    assert persisted.project is None
    assert persisted.task is None
    assert persisted.action is None
    assert persisted.agent is None
    assert persisted.recipes_file is None
    assert persisted.pam_host == DEFAULT_PAM_HOST


def test_logout_all_without_existing_settings_file():
    """--all on a machine that never wrote saved-defaults.json shouldn't
    create one. Otherwise we'd leave a sticky artifact on what should be
    a "clean slate" command.
    """
    _seed_secrets()
    ctx = get_root_cfg()
    # Defensive: confirm settings file isn't there
    if ctx.saved_settings_path.exists():
        ctx.saved_settings_path.unlink()
    logout(all_=True)
    assert not ctx.secrets_path.exists()
    assert not ctx.saved_settings_path.exists()


def test_logout_does_not_invoke_network(monkeypatch):
    """logout is a local operation — no PAM round-trip required."""
    import httpx

    def _explode(*_args, **_kwargs):
        raise AssertionError("logout must not touch the network")

    monkeypatch.setattr(httpx, "post", _explode)
    monkeypatch.setattr(httpx, "get", _explode)
    _seed_secrets()
    logout()
    # If we got here without the assertion firing, no network call happened.


def test_logout_clears_get_saved_settings_cache_independence():
    """The in-memory cached SavedSettings from a prior get_saved_settings()
    call is not mutated by `logout` itself — it just rewrites the file.
    The next process invocation will pick up the new on-disk state.
    """
    _seed_secrets()
    _seed_settings()
    cached = get_saved_settings()
    assert cached.org_id is not None
    logout(all_=True)
    # Re-read from disk to verify the persisted state, since the cached
    # object lives in a ContextVar and isn't refreshed in-process.
    ctx = get_root_cfg()
    on_disk = SavedSettings.from_file(ctx.saved_settings_path)
    assert on_disk.org_id is None
