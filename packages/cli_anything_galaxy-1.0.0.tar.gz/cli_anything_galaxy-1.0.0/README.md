# cli-anything-galaxy

CLI harness for the [Galaxy](https://galaxyproject.org/) bioinformatics platform.
It wraps Galaxy's REST API to provide command-line and REPL access to histories,
datasets, tools, workflows, jobs, and libraries.

## Prerequisites

- Python 3.10+
- A running Galaxy server
- A Galaxy API key from your target instance

## Installation

```bash
python3 -m pip install -e .
```

Verify installation:

```bash
cli-anything-galaxy --version
```

## Configuration

Set your Galaxy server URL and API key:

```bash
export GALAXY_URL=https://usegalaxy.org
export GALAXY_API_KEY=your-api-key

cli-anything-galaxy config test
```

## Usage

```bash
cli-anything-galaxy history list
cli-anything-galaxy history create "My Analysis"
cli-anything-galaxy tool search "bowtie"
cli-anything-galaxy --json workflow list
```

Run the REPL:

```bash
cli-anything-galaxy
```

## Tests

```bash
python3 -m pytest cli_anything/galaxy/tests/ -v
```

