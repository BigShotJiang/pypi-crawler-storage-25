use pyo3::prelude::*;

mod structure;
mod read_trd_ord_only;
mod tsc;

use read_trd_ord_only::read_messages;
use structure::Message;

#[pyclass]
pub struct OrderBook {
    messages: Vec<Message>,
    current_index: usize,
}

#[pymethods]
impl OrderBook {
    #[new]
    #[pyo3(signature = (path, token=None))]
    fn new(path: String, token: Option<u32>) -> PyResult<Self> {
        let messages = read_messages(&path)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let filtered_messages = if let Some(filter_token) = token {
            messages
                .into_iter()
                .filter(|msg| match msg {
                    Message::Order(o) => o.ord.token == filter_token,
                    Message::Trade(t) => t.trd.token as u32 == filter_token,
                })
                .collect()
        } else {
            messages
        };

        Ok(Self {
            messages: filtered_messages,
            current_index: 0,
        })
    }

    fn total_messages(&self) -> usize {
        self.messages.len()
    }

    fn total_orders(&self) -> usize {
        self.messages
            .iter()
            .filter(|m| matches!(m, Message::Order(_)))
            .count()
    }

    fn total_trades(&self) -> usize {
        self.messages
            .iter()
            .filter(|m| matches!(m, Message::Trade(_)))
            .count()
    }

    fn summary(&self) -> (usize, usize, usize) {
        (
            self.total_messages(),
            self.total_trades(),
            self.total_orders(),
        )
    }

    fn reset_cursor(&mut self) {
        self.current_index = 0;
    }

    // =========================================
    // DELETE FUNCTIONS WITH SAFE CURSOR HANDLING
    // =========================================

    fn delete_order_messages(&mut self) -> usize {
        let before = self.messages.len();

        self.messages
            .retain(|m| !matches!(m, Message::Order(_)));

        if self.current_index > self.messages.len() {
            self.current_index = self.messages.len();
        }

        before - self.messages.len()
    }

    fn delete_trade_messages(&mut self) -> usize {
        let before = self.messages.len();

        self.messages
            .retain(|m| !matches!(m, Message::Trade(_)));

        if self.current_index > self.messages.len() {
            self.current_index = self.messages.len();
        }

        before - self.messages.len()
    }

    #[pyo3(signature = (token))]
    fn delete_by_token(&mut self, token: u32) -> usize {
        let before = self.messages.len();

        self.messages.retain(|m| match m {
            Message::Order(o) => o.ord.token != token,
            Message::Trade(t) => t.trd.token as u32 != token,
        });

        if self.current_index > self.messages.len() {
            self.current_index = self.messages.len();
        }

        before - self.messages.len()
    }

    // =========================================

    fn next_message_formatted(&mut self) -> String {
        if self.current_index >= self.messages.len() {
            return "END".to_string();
        }

        let msg = &self.messages[self.current_index];

        self.current_index += 1;

        match msg {
            Message::Order(order_packet) => {
                let seq_no = order_packet.hdr.seq_no;
                let msg_len = order_packet.hdr.msg_len;
                let local_ts = order_packet.local_ts;
                let missed = if order_packet.flags { 1 } else { 0 };

                let msg_type = order_packet.ord.msg_type as char;
                let exch_ts = order_packet.ord.exch_ts;
                let token = order_packet.ord.token;
                let order_type = order_packet.ord.order_type as char;
                let price = order_packet.ord.price;
                let quantity = order_packet.ord.quantity;

                format!(
                    "Order Message: SeqNo{}, msg_len{}, Msg_Type'{}', Local_ts{}, Exch_ts{}, Token{}, order_Type'{}', Price{}, Quantity{}, missed{}",
                    seq_no,
                    msg_len,
                    msg_type,
                    local_ts,
                    exch_ts,
                    token,
                    order_type,
                    price,
                    quantity,
                    missed
                )
            }

            Message::Trade(trade_packet) => {
                let seq_no = trade_packet.hdr.seq_no;
                let msg_len = trade_packet.hdr.msg_len;
                let local_ts = trade_packet.local_ts;
                let missed = if trade_packet.flags { 1 } else { 0 };

                let msg_type = trade_packet.trd.msg_type as char;
                let exch_ts = trade_packet.trd.exch_ts;
                let token = trade_packet.trd.token;
                let price = trade_packet.trd.trade_price;
                let quantity = trade_packet.trd.trade_quantity;

                format!(
                    "Trade Message: SeqNo{}, msg_len{}, Msg_Type'{}', Local_ts{}, Exch_ts{}, Token{}, Price{}, Quantity{}, missed{}",
                    seq_no,
                    msg_len,
                    msg_type,
                    local_ts,
                    exch_ts,
                    token,
                    price,
                    quantity,
                    missed
                )
            }
        }
    }

    #[pyo3(signature = (limit=None))]
    fn print_messages(&mut self, limit: Option<usize>) {
        let mut count = 0usize;

        loop {
            if let Some(max) = limit {
                if count >= max {
                    break;
                }
            }

            let msg = self.next_message_formatted();

            if msg == "END" {
                break;
            }

            println!("{}", msg);

            count += 1;
        }
    }
}

#[pymodule]
fn fastorderbook(_py: Python, m: &Bound<PyModule>) -> PyResult<()> {
    m.add_class::<OrderBook>()?;
    Ok(())
}