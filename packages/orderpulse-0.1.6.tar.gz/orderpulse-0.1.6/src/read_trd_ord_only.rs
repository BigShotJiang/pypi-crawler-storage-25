use std::fs::File;
use std::io::Result;
use std::mem::size_of;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::OnceLock;

use memmap2::Mmap;

use crate::structure::{Message, OrderPacket, PeekStructure, TradePacket};

fn parser_debug_enabled() -> bool {
    static PARSER_DEBUG: OnceLock<bool> = OnceLock::new();

    *PARSER_DEBUG.get_or_init(|| {
        match std::env::var("ORDERPULSE_DEBUG") {
            Ok(value) => {
                let normalized = value.trim().to_ascii_lowercase();
                normalized == "1" || normalized == "true" || normalized == "yes" || normalized == "on"
            }
            Err(_) => false,
        }
    })
}

fn parser_debug_limit() -> Option<usize> {
    static PARSER_DEBUG_LIMIT: OnceLock<Option<usize>> = OnceLock::new();

    *PARSER_DEBUG_LIMIT.get_or_init(|| {
        match std::env::var("ORDERPULSE_DEBUG_LIMIT") {
            Ok(value) => value.trim().parse::<usize>().ok().filter(|limit| *limit > 0),
            Err(_) => None,
        }
    })
}

fn parser_debug_log(message: impl FnOnce() -> String) {
    static PARSER_DEBUG_COUNT: AtomicUsize = AtomicUsize::new(0);

    if !parser_debug_enabled() {
        return;
    }

    let count = PARSER_DEBUG_COUNT.fetch_add(1, Ordering::Relaxed);

    if let Some(limit) = parser_debug_limit() {
        if count >= limit {
            if count == limit {
                eprintln!(
                    "[orderpulse-debug] log limit reached limit={} (set ORDERPULSE_DEBUG_LIMIT higher or unset it)",
                    limit
                );
            }
            return;
        }
    }

    eprintln!("{}", message());
}

#[inline]
pub fn read_messages(path: &str) -> Result<Vec<Message>> {
    let file = File::open(path)?;
    let mmap = unsafe { Mmap::map(&file)? };
    let buf = &mmap[..];

    // Heuristic capacity to reduce reallocs.
    let estimated_msg_count = buf.len() / size_of::<OrderPacket>();
    let mut messages = Vec::with_capacity(estimated_msg_count);

    let mut i: usize = 0;
    while i < buf.len() {
        // skip spaces
        while i < buf.len() && buf[i] == b' ' {
            i += 1;
        }

        if i + size_of::<PeekStructure>() > buf.len() {
            parser_debug_log(|| {
                format!(
                    "[orderpulse-debug] stopping at offset={} because remaining bytes={} are smaller than peek structure size={}",
                    i,
                    buf.len().saturating_sub(i),
                    size_of::<PeekStructure>()
                )
            });
            break;
        }

        let peek_buf = &buf[i..i + size_of::<PeekStructure>()];
        let peek_struct: PeekStructure =
            unsafe { std::ptr::read_unaligned(peek_buf.as_ptr() as *const _) };

        match peek_struct.msg_type {
            b'T' => {
                if i + size_of::<TradePacket>() > buf.len() {
                    parser_debug_log(|| {
                        format!(
                            "[orderpulse-debug] truncated trade packet at offset={} remaining={} expected={}",
                            i,
                            buf.len().saturating_sub(i),
                            size_of::<TradePacket>()
                        )
                    });
                    break;
                }

                let trade_buf = &buf[i..i + size_of::<TradePacket>()];
                let mut trade_packet: TradePacket =
                    unsafe { std::ptr::read_unaligned(trade_buf.as_ptr() as *const _) };

                // endian fixups
                trade_packet.hdr.msg_len = u16::from_le(trade_packet.hdr.msg_len);
                trade_packet.hdr.stream_id = u16::from_le(trade_packet.hdr.stream_id);
                trade_packet.hdr.seq_no = u32::from_le(trade_packet.hdr.seq_no);

                trade_packet.trd.exch_ts = u64::from_le(trade_packet.trd.exch_ts);
                trade_packet.trd.buy_order_id = u64::from_le(trade_packet.trd.buy_order_id);
                trade_packet.trd.sell_order_id = u64::from_le(trade_packet.trd.sell_order_id);
                trade_packet.trd.token = i32::from_le(trade_packet.trd.token);
                trade_packet.trd.trade_price = i32::from_le(trade_packet.trd.trade_price);
                trade_packet.trd.trade_quantity = i32::from_le(trade_packet.trd.trade_quantity);

                parser_debug_log(|| {
                    let seq_no = trade_packet.hdr.seq_no;
                    let msg_len = trade_packet.hdr.msg_len;
                    let msg_type = trade_packet.trd.msg_type as char;
                    let token = trade_packet.trd.token;
                    let price = trade_packet.trd.trade_price;
                    let quantity = trade_packet.trd.trade_quantity;
                    let local_ts = trade_packet.local_ts;
                    let exch_ts = trade_packet.trd.exch_ts;
                    let flags = trade_packet.flags;

                    format!(
                        "[orderpulse-debug] trade offset={} seq_no={} msg_len={} msg_type={} token={} price={} qty={} local_ts={} exch_ts={} flags={}",
                        i,
                        seq_no,
                        msg_len,
                        msg_type,
                        token,
                        price,
                        quantity,
                        local_ts,
                        exch_ts,
                        flags
                    )
                });

                messages.push(Message::Trade(trade_packet));
                i += size_of::<TradePacket>();
            }
            b'N' | b'M' | b'X' => {
                if i + size_of::<OrderPacket>() > buf.len() {
                    parser_debug_log(|| {
                        format!(
                            "[orderpulse-debug] truncated order packet at offset={} remaining={} expected={}",
                            i,
                            buf.len().saturating_sub(i),
                            size_of::<OrderPacket>()
                        )
                    });
                    break;
                }

                let order_buf = &buf[i..i + size_of::<OrderPacket>()];
                let mut order_packet: OrderPacket =
                    unsafe { std::ptr::read_unaligned(order_buf.as_ptr() as *const _) };

                // endian fixups
                order_packet.hdr.msg_len = u16::from_le(order_packet.hdr.msg_len);
                order_packet.hdr.stream_id = u16::from_le(order_packet.hdr.stream_id);
                order_packet.hdr.seq_no = u32::from_le(order_packet.hdr.seq_no);

                order_packet.ord.exch_ts = u64::from_le(order_packet.ord.exch_ts);
                order_packet.ord.order_id = u64::from_le(order_packet.ord.order_id);
                order_packet.ord.token = u32::from_le(order_packet.ord.token);
                order_packet.ord.price = u32::from_le(order_packet.ord.price);
                order_packet.ord.quantity = u32::from_le(order_packet.ord.quantity);

                parser_debug_log(|| {
                    let seq_no = order_packet.hdr.seq_no;
                    let msg_len = order_packet.hdr.msg_len;
                    let msg_type = order_packet.ord.msg_type as char;
                    let token = order_packet.ord.token;
                    let order_type = order_packet.ord.order_type as char;
                    let price = order_packet.ord.price;
                    let quantity = order_packet.ord.quantity;
                    let local_ts = order_packet.local_ts;
                    let exch_ts = order_packet.ord.exch_ts;
                    let flags = order_packet.flags;

                    format!(
                        "[orderpulse-debug] order offset={} seq_no={} msg_len={} msg_type={} token={} order_type={} price={} qty={} local_ts={} exch_ts={} flags={}",
                        i,
                        seq_no,
                        msg_len,
                        msg_type,
                        token,
                        order_type,
                        price,
                        quantity,
                        local_ts,
                        exch_ts,
                        flags
                    )
                });

                messages.push(Message::Order(order_packet));
                i += size_of::<OrderPacket>();
            }
            _ => {
                // resync
                parser_debug_log(|| {
                    format!(
                        "[orderpulse-debug] resync at offset={} unknown_msg_type=0x{:02X}",
                        i,
                        peek_struct.msg_type
                    )
                });
                i += 1;
            }
        }
    }

    parser_debug_log(|| {
        format!(
            "[orderpulse-debug] finished parse total_messages={} file_size={}",
            messages.len(),
            buf.len()
        )
    });

    Ok(messages)
}