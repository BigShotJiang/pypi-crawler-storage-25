# OrderPulse

Ultra-low latency NSE Order & Trade binary feed parser built in Rust with Python bindings using PyO3.

OrderPulse is designed for high-performance market data processing, quantitative research, HFT backtesting, and real-time order flow analytics.

---

# Features

- Ultra-fast binary packet parsing
- Rust-powered zero-copy architecture
- Python API support via PyO3
- Supports:
  - Order Messages
  - Trade Messages
- Token-level filtering
- Sequential message reader
- Human-readable formatted output
- Optimized timestamp cycle measurement
- Production-grade memory-safe architecture

---

# Architecture

```text
                    +----------------------+
                    |  NSE Binary Feed     |
                    |  .bin Stream File    |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |  Binary Packet Reader |
                    | read_trd_ord_only.rs |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Packet Decoder     |
                    |    structure.rs      |
                    +----------+-----------+
                               |
                 +-------------+-------------+
                 |                           |
                 v                           v
        +----------------+         +----------------+
        | Order Message  |         | Trade Message  |
        +----------------+         +----------------+
                 |                           |
                 +-------------+-------------+
                               |
                               v
                    +----------------------+
                    |   Rust Message Enum  |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   PyO3 Python Layer  |
                    |       lib.rs         |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Python API Users   |
                    +----------------------+
```

---

# Project Structure

```text
orderpulse/
│
├── src/
│   ├── lib.rs
│   ├── main.rs
│   ├── structure.rs
│   ├── read_trd_ord_only.rs
│   ├── tsc.rs
│
├── Cargo.toml
├── pyproject.toml
├── README.md
```

---

# Supported Message Types

## Order Message

```text
Order Message:
SeqNo4,
msg_len47,
Msg_Type'N',
Local_ts1766977220948514680,
Exch_ts1451448008397631958,
Token12842,
order_Type'B',
Price20000,
Quantity3,
missed1
```

---

## Trade Message

```text
Trade Message:
SeqNo10,
msg_len51,
Msg_Type'T',
Local_ts1766977220948514680,
Exch_ts1451448008397631958,
Token12842,
Price20010,
Quantity2,
missed0
```

---

# Installation

## Install from PyPI

```bash
pip install orderpulse
```

---

# Build From Source

## Requirements

- Rust >= 1.75
- Python >= 3.9
- maturin

---

## Install maturin

```bash
pip install maturin
```

---

## Build wheel

```bash
maturin build --release
```

---

## Install local wheel

```bash
pip install target/wheels/*.whl --force-reinstall
```

---

# Python Usage

## Basic Usage

```python
import fastorderbook

path = "/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin"

ob = fastorderbook.OrderBook(path)

print(ob.summary())
```

---

## Token Filtering

```python
import fastorderbook

path = "/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin"

token = 1333

ob = fastorderbook.OrderBook(path, token)

print(ob.summary())
```

---

## Read Sequential Messages

```python
import fastorderbook

ob = fastorderbook.OrderBook(
    "/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin",
    1333
)

while True:

    msg = ob.next_message_formatted()

    if msg == "END":
        break

    print(msg)
```

---

## Print First 10 Messages

```python
import fastorderbook

ob = fastorderbook.OrderBook(
    "/nas/50.30/NSE_CM/Feed_CM_StreamID_2_29_12_2025.bin"
)

ob.print_messages(10)
```

---

# API Reference

## Constructor

```python
OrderBook(path: str, token: Optional[int] = None)
```

### Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| path | str | NSE binary feed path |
| token | int | Optional token filter |

---

# Methods

## summary()

Returns:

```python
(total_messages, total_trades, total_orders)
```

---

## next_message_formatted()

Returns formatted Order/Trade message string.

---

## print_messages(limit)

Prints sequential messages.

---

## reset_cursor()

Resets internal message iterator.

---

# Performance

OrderPulse is optimized for:

- Cache-efficient packet parsing
- Low-allocation processing
- SIMD-friendly memory layout
- Packed binary structures
- High-frequency trading environments

---

# Low Latency Timestamp Counter

The library uses architecture-specific cycle counters:

## x86_64

- RDTSC
- RDTSCP

## ARM64

- cntvct_el0

Used for ultra-fast latency benchmarking.

---

# Safety

Although optimized for speed, OrderPulse preserves:

- Rust ownership guarantees
- Memory safety
- Thread-safe abstractions
- Safe Python interoperability

---

# Example Output

```text
Order Message: SeqNo4, msg_len47, Msg_Type'N', Local_ts1766977220948514680, Exch_ts1451448008397631958, Token12842, order_Type'B', Price20000, Quantity3, missed1

Trade Message: SeqNo10, msg_len51, Msg_Type'T', Local_ts1766977220948514680, Exch_ts1451448008397631958, Token12842, Price20010, Quantity2, missed0
```

---

# Build Commands

## Clean

```bash
cargo clean
```

## Build Rust

```bash
cargo build --release
```

## Build Python Wheel

```bash
maturin build --release
```

## Publish to PyPI

```bash
maturin publish --release
```

---

# Future Enhancements

- Real-time socket streaming
- Shared memory feed handling
- Async parser
- Multi-threaded packet dispatch
- Order book reconstruction
- VWAP analytics
- Market microstructure signals
- Arrow/Polars integration
- Kafka output adapters

---

# License

MIT License

---

# Author

Chetan Sharan  
Head of Quantitative Research  
Raghunandan Money