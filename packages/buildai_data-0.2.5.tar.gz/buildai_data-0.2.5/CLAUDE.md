# BuildAI SDK

Python SDK for the Build AI API. Used by CLI, workers, and external integrators.

## Structure

- `buildai/client.py`: Single `Client` class with public and internal modes.
- `buildai/resources/`: Resource classes (clips, sessions, search, jobs, etc.)
- `buildai/models/v1/`: Response models mirroring API shapes.

## Modes

| Mode | Access | Use |
|------|--------|-----|
| `"public"` (default) | API key / JWT | External consumers, CLI |
| `"internal"` | Service key | Workers, admin operations |

## Convention

Workers call the API through the SDK. They do not import `core/` or access the database directly.

## Reference

API contract: `docs/api-reference.md`
