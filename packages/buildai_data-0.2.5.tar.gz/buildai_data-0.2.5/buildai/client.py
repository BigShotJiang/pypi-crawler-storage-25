"""BuildAI client — the standard API for egocentric data.

Usage::

    from buildai import BuildAI

    client = BuildAI(api_key="build_data_xxxx")
    client.download(hours=10, output_dir="/data/buildai/")
    client.visualize(source="/data/buildai/")
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import httpx
from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

from buildai._http import ApiError, HttpTransport

_CHUNK_SIZE = 8 * 1024 * 1024
_console = Console()


def _hrs(n: int) -> str:
    """Pluralize 'hour' correctly."""
    return f"{n} hour{'s' if n != 1 else ''}"


class BuildAI:
    """Client for the BuildAI data product API.

    Authenticates with an API key issued at signup. All data access — allocation,
    billing, and signed URL generation — goes through the API. The SDK never
    touches GCS directly.
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str | None = None,
        timeout: float | None = None,
    ) -> None:
        resolved_key = api_key or os.getenv("BUILDAI_API_KEY")
        if not resolved_key:
            raise ValueError(
                "API key required. Pass api_key= or set BUILDAI_API_KEY. "
                "Get one at https://build.ai"
            )
        self._http = HttpTransport(
            api_key=resolved_key,
            base_url=base_url,
            timeout=timeout,
        )

    # ── Download ───────────────────────────────────────────────────────

    def download(
        self,
        hours: int,
        output_dir: str = "./buildai-data",
        *,
        workers: int = 8,
        verify_checksum: bool = True,
    ) -> Path:
        """Download data from Build AI.

        Allocates ``hours`` of new data, downloads to ``output_dir``, and
        returns the path. Each call gets data you've never received before.

        Downloads stream to ``.part`` files and atomically rename on
        completion. Interrupted downloads resume via HTTP Range requests.
        SHA-256 is verified after each file.

        Increase ``workers`` to saturate faster links (try 16–32 for 10Gbps+).
        """
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        state = _DownloadState(out)

        # ── Allocate ──────────────────────────────────────────────────
        _console.print()
        _console.print("  [bold]Build AI[/bold]")
        _console.print()
        _console.print(f"  Allocating {_hrs(hours)} of data...")

        allocation = self._http.post("/downloads", json={"hours": hours})
        download_id = allocation["download_id"]
        shard_indices = allocation["shard_indices"]
        total = len(shard_indices)

        _console.print(f"  [green]✓[/green] {_hrs(total)} allocated")
        _console.print()

        # ── Collect signed URLs ───────────────────────────────────────
        all_shards: list[dict] = []
        offset = 0
        while offset < total:
            batch = self._http.get(
                f"/downloads/{download_id}/shards",
                params={"offset": offset, "limit": 50},
            )
            shards = batch["shards"]
            if not shards:
                break
            all_shards.extend(shards)
            offset += 50

        total_bytes = sum(s.get("size_bytes", 0) for s in all_shards)

        # ── Download with live progress ───────────────────────────────
        downloaded: list[int] = []
        failed: list[int] = []
        t0 = time.monotonic()

        with Progress(
            "  ",
            BarColumn(bar_width=None),
            " ",
            DownloadColumn(),
            " ",
            TransferSpeedColumn(),
            " ",
            TimeRemainingColumn(),
            console=_console,
            transient=True,
        ) as progress:
            task = progress.add_task("download", total=total_bytes)

            def _tick(nbytes: int) -> None:
                progress.advance(task, nbytes)

            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {
                    pool.submit(
                        self._download_shard,
                        s, out, verify_checksum, state, _tick,
                    ): s
                    for s in all_shards
                }
                for future in as_completed(futures):
                    shard = futures[future]
                    idx = shard["shard_index"]
                    try:
                        future.result()
                        downloaded.append(idx)
                    except Exception as e:
                        failed.append(idx)
                        _console.print(
                            f"  [red]✗[/red] Hour {idx} failed: {e}",
                            style="dim",
                        )

        # ── Ack ───────────────────────────────────────────────────────
        if downloaded:
            self._http.post(
                f"/downloads/{download_id}/ack",
                json={"shard_indices": downloaded},
            )

        # ── Summary ───────────────────────────────────────────────────
        elapsed = time.monotonic() - t0
        speed = total_bytes / elapsed if elapsed > 0 else 0

        _console.print(
            f"  [green]✓[/green] Downloaded {_hrs(len(downloaded))} "
            f"({_human_bytes(total_bytes)}) "
            f"in {_human_time(elapsed)} at {_human_bytes(speed)}/s"
        )
        _console.print(f"  [dim]→ {out}[/dim]")
        _console.print()

        if failed:
            _console.print(
                f"  [red]{len(failed)} failed: {failed}[/red]",
                style="bold",
            )

        return out

    def _download_shard(
        self,
        shard: dict[str, Any],
        output_dir: Path,
        verify: bool,
        state: _DownloadState,
        on_chunk: Any,
    ) -> None:
        """Download one shard to a .part file, verify, and atomically rename.

        Calls ``on_chunk(nbytes)`` on every chunk write so the progress bar
        updates in real-time from worker threads.
        """
        idx = shard["shard_index"]
        url = shard["url"]
        expected_sha = shard.get("checksum_sha256")
        expected_size = shard.get("size_bytes", 0)
        dest = output_dir / f"shard-{idx:06d}.tar"
        part = dest.with_suffix(".tar.part")

        # Already complete — advance progress and skip
        if state.is_complete(idx) and dest.exists():
            on_chunk(expected_size)
            return
        if dest.exists() and verify and expected_sha:
            if _sha256(dest) == expected_sha:
                state.mark_complete(idx, expected_sha)
                on_chunk(expected_size)
                return

        # Resume from .part if it exists
        existing_bytes = part.stat().st_size if part.exists() else 0
        headers: dict[str, str] = {}
        if existing_bytes > 0 and expected_size > 0 and existing_bytes < expected_size:
            headers["Range"] = f"bytes={existing_bytes}-"
            on_chunk(existing_bytes)

        # Stream download
        with httpx.stream(
            "GET", url, headers=headers, timeout=600, follow_redirects=True
        ) as resp:
            if resp.status_code == 200 and existing_bytes > 0:
                existing_bytes = 0

            resp.raise_for_status()
            mode = "ab" if resp.status_code == 206 else "wb"

            with open(part, mode) as f:
                for chunk in resp.iter_bytes(chunk_size=_CHUNK_SIZE):
                    f.write(chunk)
                    on_chunk(len(chunk))

        # Verify
        if verify and expected_sha:
            actual = _sha256(part)
            if actual != expected_sha:
                part.unlink(missing_ok=True)
                state.mark_failed(idx)
                raise ValueError(
                    f"Checksum mismatch for shard {idx}: "
                    f"expected {expected_sha[:16]}..., got {actual[:16]}..."
                )

        part.rename(dest)
        state.mark_complete(idx, expected_sha or "")

    # ── Visualize ──────────────────────────────────────────────────────

    def visualize(
        self,
        source: str | None = None,
        *,
        port: int = 0,
        count: int = 20,
    ) -> None:
        """Open a browser-based viewer for BuildAI data.

        **Local** (``source`` provided): scans shard-*.tar files on disk,
        serves video and IMU from the tars. Nothing is uploaded.

        **Remote** (``source`` omitted): fetches random clips from the API
        to preview before downloading. Requires a valid API key.

        Press Ctrl+C to stop.
        """
        from buildai._visualizer import serve_local, serve_remote

        if source is not None:
            serve_local(source, port=port)
        else:
            clips = self._http.get("/preview", params={"count": count})
            serve_remote(clips, http=self._http, port=port)

    # ── Account ────────────────────────────────────────────────────────

    @property
    def account(self) -> dict[str, Any]:
        """Fetch the authenticated user's account info and usage."""
        data = self._http.get("/account")
        for key in ("total_spent_usd", "total_cents"):
            data.pop(key, None)
        for dl in data.get("downloads", []):
            dl.pop("total_cents", None)
        return data

    def close(self) -> None:
        """Close the underlying HTTP connection."""
        self._http.close()

    def __enter__(self) -> BuildAI:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return "BuildAI()"


# ── Download state ─────────────────────────────────────────────────────────


class _DownloadState:
    """Persists completed shards in ``buildai-state.json`` for cross-session resume.

    On restart, completed shards are skipped instantly without re-hashing
    multi-GB files. The manifest stores shard index → SHA-256 + timestamp.
    """

    def __init__(self, output_dir: Path) -> None:
        self._path = output_dir / "buildai-state.json"
        self._data: dict[str, Any] = {"completed": {}, "failed": []}
        if self._path.exists():
            try:
                self._data = json.loads(self._path.read_text())
            except (json.JSONDecodeError, OSError):
                pass

    def is_complete(self, shard_index: int) -> bool:
        """Check if a shard was previously downloaded and verified."""
        return str(shard_index) in self._data.get("completed", {})

    def mark_complete(self, shard_index: int, sha256: str) -> None:
        """Record a shard as successfully downloaded and verified."""
        self._data.setdefault("completed", {})[str(shard_index)] = {
            "sha256": sha256,
            "completed_at": time.time(),
        }
        self._save()

    def mark_failed(self, shard_index: int) -> None:
        """Record a shard that failed checksum verification."""
        failed = self._data.setdefault("failed", [])
        if shard_index not in failed:
            failed.append(shard_index)
        self._save()

    def _save(self) -> None:
        try:
            self._path.write_text(json.dumps(self._data, indent=2))
        except OSError:
            pass


# ── Helpers ────────────────────────────────────────────────────────────────


def _sha256(path: Path) -> str:
    """Compute SHA-256 hex digest of a file, streaming in 64KB blocks."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(65536), b""):
            h.update(block)
    return h.hexdigest()


def _human_bytes(n: float) -> str:
    """Format byte count as human-readable string."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def _human_time(seconds: float) -> str:
    """Format seconds as human-readable duration."""
    if seconds < 60:
        return f"{seconds:.0f}s"
    m, s = divmod(int(seconds), 60)
    if m < 60:
        return f"{m}m {s}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"
