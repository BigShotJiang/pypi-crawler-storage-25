"""HTTP transport for the BuildAI data product API.

Handles authentication, retries with backoff, and error normalization.
All requests go through api.build.ai/v1/data/*.
"""

from __future__ import annotations

import os
import random
import time
from typing import Any

import httpx

_DEFAULT_BASE_URL = "https://api.build.ai"
_DEFAULT_TIMEOUT = 60.0
_RETRY_STATUSES = {429, 500, 502, 503, 504}


class ApiError(Exception):
    """Error returned by the BuildAI API."""

    def __init__(self, message: str, *, status_code: int = 0, detail: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail


class HttpTransport:
    """Sync HTTP client for the BuildAI data product API."""

    def __init__(
        self,
        api_key: str,
        base_url: str | None = None,
        timeout: float | None = None,
        max_retries: int = 3,
    ) -> None:
        self._api_key = api_key
        self._base_url = (base_url or os.getenv("BUILDAI_API_URL") or _DEFAULT_BASE_URL).rstrip("/")
        self._timeout = timeout or _DEFAULT_TIMEOUT
        self._max_retries = max_retries
        self._client = httpx.Client(timeout=self._timeout)

    def _headers(self) -> dict[str, str]:
        return {
            "X-API-Key": self._api_key,
            "User-Agent": "buildai-sdk/0.2.4",
        }

    def _url(self, path: str) -> str:
        return f"{self._base_url}/v1/data{path}"

    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        """Send an HTTP request with retries and error handling."""
        url = self._url(path)
        max_attempts = self._max_retries + 1 if method == "GET" else 1

        last_resp = None
        for attempt in range(max_attempts):
            resp = self._client.request(method, url, headers=self._headers(), **kwargs)

            if resp.status_code < 400:
                return resp.json() if resp.content else {}

            if resp.status_code in _RETRY_STATUSES and attempt < max_attempts - 1:
                wait = min(2 ** attempt * 0.5, 30.0) + random.uniform(0, 1)
                time.sleep(wait)
                last_resp = resp
                continue

            last_resp = resp
            break

        self._raise(last_resp)

    def _raise(self, resp: httpx.Response) -> None:
        message = resp.text or f"HTTP {resp.status_code}"
        try:
            body = resp.json()
            if isinstance(body, dict):
                message = body.get("detail", message)
                if isinstance(message, dict):
                    message = message.get("message", str(message))
        except Exception:
            pass
        raise ApiError(message, status_code=resp.status_code)

    def get(self, path: str, **kwargs: Any) -> Any:
        """HTTP GET with automatic retries."""
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> Any:
        """HTTP POST."""
        return self.request("POST", path, **kwargs)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()
