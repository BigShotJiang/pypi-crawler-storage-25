"""PyTorch dataloader for downloaded BuildAI shards using WebDataset.

Streams video + IMU clips from local WebDataset-format tar files as
batched PyTorch tensors. Requires ``pip install buildai-data[torch]``
which pulls in torch, decord, and webdataset.

Uses the webdataset library natively — the shards are already in
WebDataset format (files sharing a basename are grouped into samples).
This means researchers with existing WebDataset pipelines can skip
this loader entirely and point their pipeline at the downloaded tars.

Usage::

    from buildai import BuildAI

    client = BuildAI(api_key="build_data_xxxx")
    loader = client.loader(source="./buildai-data", batch_size=32)
    for batch in loader:
        video = batch.video  # (B, T, 3, H, W)
        imu = batch.imu      # (B, T, 6)
"""

from __future__ import annotations

import io
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any


def _check_deps() -> None:
    """Fail fast with an actionable message if torch extras are missing."""
    missing = []
    for pkg in ("torch", "decord", "webdataset"):
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    if missing:
        raise ImportError(
            f"Missing: {', '.join(missing)}. "
            "Install with: pip install 'buildai-data[torch]'"
        )


_check_deps()

import numpy as np  # noqa: E402
import torch  # noqa: E402
import webdataset as wds  # noqa: E402


@dataclass
class BuildAIBatch:
    """Named container for a batch of video + IMU tensors.

    Attributes match the spec: ``batch.video`` is (B, T, 3, H, W) and
    ``batch.imu`` is (B, T, 6), both float32.
    """

    video: torch.Tensor
    imu: torch.Tensor


# ── Custom decoders ────────────────────────────────────────────────────────


def _decode_mp4(data: bytes) -> torch.Tensor:
    """Decode mp4 bytes → (T, 3, H, W) float32 tensor via decord.

    Decord is ~3x faster than OpenCV and supports GPU decoding.
    We use the numpy bridge and convert to CHW float32 [0, 1].
    """
    import decord

    decord.bridge.set_bridge("numpy")
    reader = decord.VideoReader(io.BytesIO(data), num_threads=1)
    frames = reader.get_batch(range(len(reader))).asnumpy()  # (T, H, W, 3) uint8
    return torch.from_numpy(frames).permute(0, 3, 1, 2).float() / 255.0


def _decode_imu_npy(data: bytes) -> torch.Tensor:
    """Decode .imu.npy bytes → (T, 6) float32 tensor."""
    arr = np.load(io.BytesIO(data))
    return torch.from_numpy(arr).float()


# ── Collation ──────────────────────────────────────────────────────────────


def _collate(
    samples: list[dict[str, Any]],
) -> BuildAIBatch:
    """Collate a list of sample dicts into a BuildAIBatch.

    All clips in the data product are the same length (5400 frames),
    but we handle variable lengths gracefully by padding shorter clips
    with zeros — this supports clip_slice_frames and edge cases.
    """
    videos = [s["video"] for s in samples]
    imus = [s["imu"] for s in samples]

    max_frames = max(v.shape[0] for v in videos)

    padded_videos = []
    padded_imus = []
    for v, m in zip(videos, imus):
        t = v.shape[0]
        if t < max_frames:
            v = torch.cat([v, torch.zeros(max_frames - t, *v.shape[1:], dtype=v.dtype)])
            m = torch.cat([m, torch.zeros(max_frames - t, m.shape[1], dtype=m.dtype)])
        padded_videos.append(v)
        padded_imus.append(m)

    return BuildAIBatch(
        video=torch.stack(padded_videos),
        imu=torch.stack(padded_imus),
    )


# ── Pipeline helpers ───────────────────────────────────────────────────────


def _make_sample(sample: dict) -> dict[str, Any]:
    """Reshape a decoded webdataset sample into {video, imu} dict.

    WebDataset groups files by basename and strips the extension to form
    keys. Our tars have ``000001.mp4`` and ``000001.imu.npy`` — after
    decoding, the sample dict contains ``mp4`` and ``imu.npy`` keys.
    """
    return {
        "video": sample["mp4"],
        "imu": sample["imu.npy"],
    }


def _make_slicer(clip_slice_frames: int):
    """Return a transform that takes a random sub-clip of fixed length.

    Useful for training with shorter sequences than the full 3-min clip.
    Both video and IMU are sliced at the same random offset.
    """
    def _slice(sample: dict[str, Any]) -> dict[str, Any]:
        t = sample["video"].shape[0]
        if t <= clip_slice_frames:
            return sample
        start = random.randint(0, t - clip_slice_frames)
        end = start + clip_slice_frames
        return {
            "video": sample["video"][start:end],
            "imu": sample["imu"][start:end],
        }
    return _slice


def _find_shards(source: str | Path) -> str:
    """Build a brace-expansion shard pattern from a directory of tars.

    WebDataset accepts patterns like ``/data/shard-{000000..000099}.tar``.
    We scan the directory, find the range, and build the pattern.
    Falls back to a glob pipe if shards aren't contiguously numbered.
    """
    source = Path(source)
    tars = sorted(source.glob("shard-*.tar"))
    if not tars:
        raise FileNotFoundError(
            f"No shard-*.tar files found in {source}. "
            "Download data first: client.download(hours=N)"
        )

    if len(tars) == 1:
        return str(tars[0])

    # Extract shard indices to build brace pattern
    indices = []
    for t in tars:
        stem = t.stem  # "shard-000042"
        idx_str = stem.split("-", 1)[1]
        try:
            indices.append(int(idx_str))
        except ValueError:
            # Non-standard naming — fall back to explicit list
            return "pipe:cat " + " ".join(str(t) for t in tars)

    lo, hi = min(indices), max(indices)
    # Check if contiguous
    if hi - lo + 1 == len(indices):
        width = len(tars[0].stem.split("-", 1)[1])  # zero-pad width
        return str(source / f"shard-{{{lo:0{width}d}..{hi:0{width}d}}}.tar")

    # Non-contiguous — pass explicit file list
    return "pipe:cat " + " ".join(str(t) for t in tars)


# ── Public API ─────────────────────────────────────────────────────────────


def loader(
    source: str | Path = "./buildai-data",
    batch_size: int = 32,
    *,
    shuffle: bool = True,
    num_workers: int = 4,
    clip_slice_frames: int | None = None,
    shuffle_buffer: int = 100,
) -> torch.utils.data.DataLoader:
    """Create a DataLoader that streams clips from downloaded shard tars.

    Uses the webdataset library for efficient sequential streaming from
    tar archives. Each iteration yields a ``BuildAIBatch`` with
    ``.video`` (B, T, 3, H, W) and ``.imu`` (B, T, 6) as float32 tensors.

    Args:
        source: Directory containing shard-*.tar files.
        batch_size: Clips per batch.
        shuffle: Randomize shard and clip order (default True).
        num_workers: DataLoader workers for parallel decoding.
        clip_slice_frames: If set, take a random sub-clip of this many
            frames instead of the full 3-minute clip.
        shuffle_buffer: Number of samples to buffer for shuffling.
            Larger values give better randomization at the cost of memory.
    """
    shard_pattern = _find_shards(source)

    # Build the webdataset pipeline
    dataset = wds.WebDataset(
        shard_pattern,
        shardshuffle=shuffle,
        handler=wds.warn_and_continue,
    )

    if shuffle:
        dataset = dataset.shuffle(shuffle_buffer)

    # Decode .mp4 with decord, .imu.npy with numpy — skip built-in decoders
    dataset = dataset.decode(
        wds.handle_extension(".mp4", _decode_mp4),
        wds.handle_extension(".imu.npy", _decode_imu_npy),
    )

    # Reshape into {video, imu} dicts
    dataset = dataset.map(_make_sample, handler=wds.warn_and_continue)

    # Optional sub-clip slicing
    if clip_slice_frames:
        dataset = dataset.map(_make_slicer(clip_slice_frames))

    # Batch inside webdataset (DataLoader batch_size=None)
    dataset = dataset.batched(batch_size, collation_fn=_collate)

    return torch.utils.data.DataLoader(
        dataset,
        batch_size=None,  # batching handled by webdataset
        num_workers=num_workers,
    )
