"""Local and remote visualizer for BuildAI data.

Two modes:
- **Local**: scans shard-*.tar files, serves video/IMU from tars on disk.
- **Remote**: uses pre-signed CDN URLs from the API, fetches IMU on demand.

Both open the same browser-based viewer — a dark grid of clips with
video playback and IMU charts (accelerometer + gyroscope) synced below.

No external dependencies beyond numpy (already required for IMU).
"""

from __future__ import annotations

import io
import json
import tarfile
import threading
import webbrowser
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Any

import numpy as np


# ── Shared HTML template ──────────────────────────────────────────────────────

_INDEX_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>BuildAI Data Viewer</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
       background: #0a0a0a; color: #e0e0e0; }
.header { padding: 24px 32px; border-bottom: 1px solid #222; }
.header h1 { font-size: 20px; font-weight: 600; color: #fff; }
.header p { font-size: 13px; color: #888; margin-top: 4px; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: 12px; padding: 24px 32px; }
.clip { background: #161616; border: 1px solid #222; border-radius: 8px;
        cursor: pointer; overflow: hidden; transition: border-color 0.15s; }
.clip:hover { border-color: #555; }
.clip video { width: 100%; aspect-ratio: 16/9; object-fit: cover; background: #000; }
.clip .label { padding: 8px 12px; font-size: 12px; color: #999; }
.clip .label span { color: #ccc; }

/* Viewer overlay */
.viewer { display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
          background: #0a0a0aee; z-index: 100; overflow-y: auto; }
.viewer.active { display: flex; flex-direction: column; align-items: center;
                 padding: 32px; }
.viewer .close { position: fixed; top: 16px; right: 24px; font-size: 28px;
                 color: #888; cursor: pointer; z-index: 101; }
.viewer .close:hover { color: #fff; }
.viewer video { max-width: 960px; width: 100%; border-radius: 8px;
                background: #000; }
.viewer .meta { font-size: 13px; color: #888; margin: 12px 0; }
.chart-container { max-width: 960px; width: 100%; margin-top: 16px; }
.chart-container canvas { width: 100%; height: 180px; border-radius: 6px;
                          background: #111; }
.chart-label { font-size: 11px; color: #666; margin: 8px 0 4px; }
</style>
</head>
<body>
<div class="header">
  <h1>BuildAI Data Viewer</h1>
  <p id="summary"></p>
</div>
<div class="grid" id="grid"></div>

<div class="viewer" id="viewer">
  <span class="close" onclick="closeViewer()">&times;</span>
  <video id="vplayer" controls></video>
  <div class="meta" id="vmeta"></div>
  <div class="chart-container">
    <div class="chart-label">Accelerometer (m/s&sup2;)</div>
    <canvas id="accChart"></canvas>
    <div class="chart-label">Gyroscope (rad/s)</div>
    <canvas id="gyroChart"></canvas>
  </div>
</div>

<script>
let clips = __CLIP_DATA__;
let mode = '__MODE__';
let summary = document.getElementById('summary');
summary.textContent = clips.length + ' clips' + (mode === 'remote' ? ' (streaming from CDN)' : '');

let grid = document.getElementById('grid');
clips.forEach((clip, i) => {
  let div = document.createElement('div');
  div.className = 'clip';
  let videoSrc = mode === 'local'
    ? '/video/' + clip.shard + '/' + clip.id
    : clip.video_url;
  div.innerHTML = '<video src="' + videoSrc +
    '" preload="metadata" muted></video>' +
    '<div class="label">Clip <span>' + (clip.label || clip.id) + '</span></div>';
  div.onclick = () => openViewer(clip, videoSrc);
  grid.appendChild(div);
});

function openViewer(clip, videoSrc) {
  document.getElementById('viewer').classList.add('active');
  let vp = document.getElementById('vplayer');
  vp.src = videoSrc;
  vp.play();
  document.getElementById('vmeta').textContent =
    (clip.label || clip.id) + ' — 3 min, H.265, 1080p, 30fps';

  let imuUrl = mode === 'local'
    ? '/imu/' + clip.shard + '/' + clip.id
    : '/imu?id=' + clip.id;

  fetch(imuUrl)
    .then(r => r.json())
    .then(data => {
      drawChart('accChart', data.timestamps || [],
        [{d: data.acc_x || [], c: '#4fc3f7'},
         {d: data.acc_y || [], c: '#81c784'},
         {d: data.acc_z || [], c: '#ffb74d'}],
        data.readings);
      drawChart('gyroChart', data.timestamps || [],
        [{d: data.gyro_x || [], c: '#ce93d8'},
         {d: data.gyro_y || [], c: '#f06292'},
         {d: data.gyro_z || [], c: '#fff176'}],
        data.readings);
    }).catch(() => {});
}

function closeViewer() {
  document.getElementById('viewer').classList.remove('active');
  document.getElementById('vplayer').pause();
}

document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeViewer();
});

function drawChart(canvasId, timestamps, series, readings) {
  let canvas = document.getElementById(canvasId);
  let ctx = canvas.getContext('2d');
  let w = canvas.width = canvas.offsetWidth * 2;
  let h = canvas.height = canvas.offsetHeight * 2;
  ctx.scale(2, 2);
  let cw = w / 2, ch = h / 2;
  ctx.clearRect(0, 0, cw, ch);

  // Support both formats: {acc_x, acc_y, ...} and {readings: [[ax,ay,az,gx,gy,gz]]}
  if (readings && readings.length > 0 && (!series[0].d || series[0].d.length === 0)) {
    let isAcc = canvasId === 'accChart';
    let offset = isAcc ? 0 : 3;
    let colors = isAcc
      ? ['#4fc3f7', '#81c784', '#ffb74d']
      : ['#ce93d8', '#f06292', '#fff176'];
    series = colors.map((c, i) => ({
      d: readings.map(r => r[offset + i]),
      c: c
    }));
  }

  if (!series[0].d || series[0].d.length === 0) return;

  let allVals = series.flatMap(s => s.d);
  let minV = Math.min(...allVals), maxV = Math.max(...allVals);
  let range = maxV - minV || 1;
  let pad = range * 0.1;
  minV -= pad; maxV += pad; range = maxV - minV;

  ctx.strokeStyle = '#222';
  ctx.lineWidth = 0.5;
  for (let i = 0; i <= 4; i++) {
    let y = (i / 4) * ch;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(cw, y); ctx.stroke();
  }

  series.forEach(s => {
    ctx.strokeStyle = s.c;
    ctx.lineWidth = 1;
    ctx.beginPath();
    s.d.forEach((v, i) => {
      let x = (i / (s.d.length - 1)) * cw;
      let y = ch - ((v - minV) / range) * ch;
      i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    });
    ctx.stroke();
  });
}
</script>
</body>
</html>"""


# ── Local mode helpers ────────────────────────────────────────────────────────


def _index_shards(source_dir: Path) -> list[dict[str, Any]]:
    """Scan tar files and build an index of clips without extracting.

    Returns a list of shard dicts, each containing clip entries with
    their byte offsets inside the tar for on-demand extraction.
    """
    shards = []
    for tar_path in sorted(source_dir.glob("shard-*.tar")):
        shard_name = tar_path.stem
        clips: dict[str, dict] = {}

        with tarfile.open(str(tar_path), "r") as tf:
            for member in tf.getmembers():
                name = member.name
                if name.endswith(".mp4"):
                    clip_num = name.replace(".mp4", "")
                    clips.setdefault(clip_num, {})["mp4"] = True
                elif name.endswith(".imu.npy"):
                    clip_num = name.replace(".imu.npy", "")
                    clips.setdefault(clip_num, {})["imu"] = True

        shard_clips = []
        for clip_num in sorted(clips.keys()):
            c = clips[clip_num]
            if c.get("mp4") and c.get("imu"):
                shard_clips.append({"id": clip_num, "shard": shard_name})

        if shard_clips:
            shards.append({
                "name": shard_name,
                "path": str(tar_path),
                "clips": shard_clips,
                "count": len(shard_clips),
            })

    return shards


def _extract_file(tar_path: str, filename: str) -> bytes | None:
    """Extract a single file from a tar archive by name."""
    try:
        with tarfile.open(tar_path, "r") as tf:
            member = tf.getmember(filename)
            f = tf.extractfile(member)
            if f:
                return f.read()
    except (KeyError, tarfile.TarError):
        pass
    return None


def _imu_to_json(npy_bytes: bytes) -> str:
    """Convert IMU numpy bytes to JSON arrays for the chart."""
    arr = np.load(io.BytesIO(npy_bytes))  # (5400, 6) float32
    step = 10
    downsampled = arr[::step]
    timestamps = [round(i * step / 30, 2) for i in range(len(downsampled))]

    return json.dumps({
        "timestamps": timestamps,
        "acc_x": [round(float(v), 3) for v in downsampled[:, 0]],
        "acc_y": [round(float(v), 3) for v in downsampled[:, 1]],
        "acc_z": [round(float(v), 3) for v in downsampled[:, 2]],
        "gyro_x": [round(float(v), 3) for v in downsampled[:, 3]],
        "gyro_y": [round(float(v), 3) for v in downsampled[:, 4]],
        "gyro_z": [round(float(v), 3) for v in downsampled[:, 5]],
    })


# ── Local mode server ─────────────────────────────────────────────────────────


def serve_local(source_dir: str | Path, port: int = 0) -> None:
    """Start the local visualizer — scans tars, serves video/IMU from disk.

    Opens a browser showing a grid of all clips across all shard tars.
    Click a clip to watch with IMU charts synced below. Nothing uploaded.
    """
    source = Path(source_dir)
    if not source.is_dir():
        raise FileNotFoundError(f"Source directory not found: {source}")

    print(f"Scanning shards in {source}...")
    shards = _index_shards(source)

    if not shards:
        print("No shard-*.tar files found.")
        return

    total_clips = sum(s["count"] for s in shards)
    print(f"Found {len(shards)} shards, {total_clips} clips")

    # Flatten clips for the template
    all_clips = []
    for shard in shards:
        for clip in shard["clips"]:
            all_clips.append(clip)

    shard_paths = {s["name"]: s["path"] for s in shards}

    class Handler(SimpleHTTPRequestHandler):
        """Serves the viewer UI, extracts video and IMU from tars on demand."""

        def log_message(self, fmt, *args):
            pass

        def do_GET(self):
            path = self.path

            if path == "/" or path == "/index.html":
                html = _INDEX_HTML.replace("__CLIP_DATA__", json.dumps(all_clips))
                html = html.replace("__MODE__", "local")
                self._respond(200, "text/html", html.encode())

            elif path.startswith("/video/"):
                parts = path.split("/")
                if len(parts) >= 4:
                    shard_name, clip_id = parts[2], parts[3]
                    tar_path = shard_paths.get(shard_name)
                    if tar_path:
                        data = _extract_file(tar_path, f"{clip_id}.mp4")
                        if data:
                            self._respond(200, "video/mp4", data)
                            return
                self._respond(404, "text/plain", b"Not found")

            elif path.startswith("/imu/"):
                parts = path.split("/")
                if len(parts) >= 4:
                    shard_name, clip_id = parts[2], parts[3]
                    tar_path = shard_paths.get(shard_name)
                    if tar_path:
                        data = _extract_file(tar_path, f"{clip_id}.imu.npy")
                        if data:
                            self._respond(200, "application/json", _imu_to_json(data).encode())
                            return
                self._respond(404, "text/plain", b"Not found")

            else:
                self._respond(404, "text/plain", b"Not found")

        def _respond(self, code: int, content_type: str, body: bytes):
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            if content_type == "video/mp4":
                self.send_header("Accept-Ranges", "bytes")
            self.end_headers()
            self.wfile.write(body)

    server = HTTPServer(("127.0.0.1", port), Handler)
    actual_port = server.server_address[1]
    url = f"http://127.0.0.1:{actual_port}"
    print(f"Viewer running at {url}")
    print("Press Ctrl+C to stop\n")
    webbrowser.open(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()


# ── Remote mode server ────────────────────────────────────────────────────────


def serve_remote(
    clips: list[dict[str, Any]],
    http: Any,
    port: int = 0,
) -> None:
    """Start the remote visualizer — streams video from CDN, IMU from API.

    ``clips`` is the response from GET /v1/data/preview (list of dicts
    with id, video_url, thumbnail_url, duration_sec).
    ``http`` is the SDK's HttpTransport for fetching IMU on demand.
    """
    if not clips:
        print("No preview clips returned from API.")
        return

    print(f"Loaded {len(clips)} preview clips from API")

    # Reshape for template — video_url is already a signed CDN URL
    template_clips = []
    for c in clips:
        template_clips.append({
            "id": c["id"],
            "video_url": c["video_url"],
            "label": c["id"][:8],
        })

    class Handler(SimpleHTTPRequestHandler):
        """Serves viewer UI and proxies IMU requests to the API."""

        def log_message(self, fmt, *args):
            pass

        def do_GET(self):
            path = self.path

            if path == "/" or path == "/index.html":
                html = _INDEX_HTML.replace("__CLIP_DATA__", json.dumps(template_clips))
                html = html.replace("__MODE__", "remote")
                self._respond(200, "text/html", html.encode())

            elif path.startswith("/imu?"):
                # Proxy IMU request to the API using opaque clip UUID
                from urllib.parse import parse_qs, urlparse
                parsed = urlparse(path)
                params = parse_qs(parsed.query)
                clip_id = params.get("id", [None])[0]

                if clip_id:
                    try:
                        imu_data = http.get(
                            "/preview/imu",
                            params={"id": clip_id},
                        )
                        self._respond(
                            200,
                            "application/json",
                            json.dumps(imu_data).encode(),
                        )
                        return
                    except Exception:
                        pass
                self._respond(404, "text/plain", b"Not found")

            else:
                self._respond(404, "text/plain", b"Not found")

        def _respond(self, code: int, content_type: str, body: bytes):
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

    server = HTTPServer(("127.0.0.1", port), Handler)
    actual_port = server.server_address[1]
    url = f"http://127.0.0.1:{actual_port}"
    print(f"Viewer running at {url}")
    print("Press Ctrl+C to stop\n")
    webbrowser.open(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        server.server_close()


# ── Backward compat ───────────────────────────────────────────────────────────

serve = serve_local
