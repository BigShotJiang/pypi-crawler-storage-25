from setuptools import setup; setup(name='pint-logger', version='0.0.1', description='test')
