#!/usr/bin/env python
# Copyright 2019-2026 AstroLab Software
# Author: Julien Peloton
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import yaml
import os

from fink_client.logger import get_fink_logger
from fink_client.tester import regular_unit_tests

_LOG = get_fink_logger()
_ROOTDIR = os.path.join(os.environ["HOME"], ".finkclient")
_CREDNAME = "{}_credentials.yml"


def check_survey_exists(survey):
    """Check survey exists"""
    if survey not in ["ztf", "lsst"]:
        raise KeyError(
            "-survey must be one of ['ztf', 'lsst']. {} is not recognized.".format(
                survey
            )
        )


def write_credentials(dict_file: dict, log_level: str = "WARN", tmp: bool = False):
    """Store user credentials on the computer.

    To get your credentials, contact Fink admins or fill the registration form:
        https://forms.gle/2td4jysT4e9pkf889

    Parameters
    ----------
    dict_file: dict
        Dictionnary containing user credentials.
    log_level: str, optional
        Level of verbosity. Default is WARN.
    tmp: bool, optional
        If True, store the credentials under /tmp. Default is False.

    Examples
    --------
    >>> conf = {
    ...   'survey': 'lsst',
    ...   'username': 'test',
    ...   'password': None,
    ...   'mytopics': ['rrlyr'],
    ...   'servers': 'localhost:9093',
    ...   'group_id': 'test_group',
    ...   'maxtimeout': 10
    ... }
    >>> write_credentials(conf, log_level="WARN", tmp=True)
    """
    _LOG.setLevel(log_level)
    if tmp:
        ROOTDIR = "/tmp"
    else:
        ROOTDIR = _ROOTDIR

    # check there are no missing information
    mandatory_keys = [
        "survey",
        "username",
        "group_id",
        "servers",
    ]
    for k in mandatory_keys:
        assert k in dict_file.keys(), "You need to specify {}".format(k)

    check_survey_exists(dict_file["survey"])

    # Create the folder if it does not exist
    os.makedirs(ROOTDIR, exist_ok=True)

    # Store data into yml file
    with open(os.path.join(ROOTDIR, _CREDNAME.format(dict_file["survey"])), "w") as f:
        yaml.dump(dict_file, f)

    _LOG.info(
        "Credentials stored at {}/{}".format(
            ROOTDIR, _CREDNAME.format(dict_file["survey"])
        )
    )


def load_credentials(survey: str, tmp: bool = False) -> dict:
    """Load fink-client credentials.

    Parameters
    ----------
    survey: str
        Survey name, among ztf or lsst
    tmp: bool, optional
        If True, load the credentials from /tmp. Default is False.

    Returns
    -------
    creds: dict
        Dictionnary containing user credentials.

    Examples
    --------
    >>> conf_in = {
    ...   'survey': 'lsst',
    ...   'username': 'test',
    ...   'password': None,
    ...   'mytopics': ['rrlyr'],
    ...   'servers': 'localhost:9093',
    ...   'group_id': 'test_group',
    ...   'maxtimeout': 10
    ... }
    >>> write_credentials(conf_in, tmp=True)
    >>> conf_out = load_credentials(survey=conf_in["survey"], tmp=True)

    If, however the credentials do not exist yet
    >>> os.remove('/tmp/lsst_credentials.yml')
    >>> conf = load_credentials(survey="lsst", tmp=True) # doctest: +NORMALIZE_WHITESPACE, +ELLIPSIS
    Traceback (most recent call last):
     ...
    OSError: No credentials found for survey lsst, did you register?
    To get your credentials, and use fink-client you need to:
      1. subscribe to one or more Fink streams at
        https://forms.gle/2td4jysT4e9pkf889
      2. run `fink_client_register` to register
    See https://doc.lsst.fink-broker.org/en/latest/services/data_transfer/

    """
    check_survey_exists(survey)
    if tmp:
        ROOTDIR = "/tmp"
    else:
        ROOTDIR = _ROOTDIR

    path = os.path.join(ROOTDIR, _CREDNAME.format(survey))

    if not os.path.exists(path):
        msg = """
        No credentials found for survey {}, did you register?
        To get your credentials, and use fink-client you need to:
          1. subscribe to one or more Fink streams at
            https://forms.gle/2td4jysT4e9pkf889
          2. run `fink_client_register` to register
        See https://doc.{}.fink-broker.org/en/latest/services/data_transfer/
        """.format(survey, survey)
        raise IOError(msg)

    with open(path) as f:
        creds = yaml.load(f, Loader=yaml.FullLoader)

    return creds


def mm_topic_names():
    """Return list of topics with MMA schema"""
    out = [
        "fink_grb_bronze",
        "fink_grb_silver",
        "fink_grb_gold",
        "fink_gw_bronze",
    ]
    return out


if __name__ == "__main__":
    """ Run the test suite """

    regular_unit_tests(globals())
