from django.contrib import admin
from django.template.loader import render_to_string
from django.urls import reverse
from edc_model_admin.dashboard import ModelAdminDashboardMixin
from edc_model_admin.mixins import TemplatesModelAdminMixin
from edc_qareports.modeladmin_mixins import QaReportModelAdminMixin
from edc_sites.admin import SiteModelAdminMixin
from rangefilter.filters import DateRangeFilterBuilder

from ...admin_site import meta_reports_admin
from ...models import OffscheduleReport


@admin.register(OffscheduleReport, site=meta_reports_admin)
class OffScheduleReportAdmin(
    QaReportModelAdminMixin,
    SiteModelAdminMixin,
    ModelAdminDashboardMixin,
    TemplatesModelAdminMixin,
    admin.ModelAdmin,
):
    ordering = ("site", "subject_identifier", "onschedule_datetime")
    include_note_column = False
    list_display = (
        "dashboard",
        "subject_identifier_link",
        "site",
        "schedule_name",
        "onschedule_date",
        "visit_code",
        "appt_date",
        "days",
        "appt_status",
        "source",
    )

    list_filter = (
        "appt_status",
        ("onschedule_datetime", DateRangeFilterBuilder()),
        ("appt_datetime", DateRangeFilterBuilder()),
        "source",
        "schedule_name",
    )

    search_fields = ("subject_identifier",)

    @admin.display(description="Subject Idenfifier", ordering="subject_identifier")
    def subject_identifier_link(self, obj=None):
        url = reverse("meta_reports_admin:meta_reports_eosreport_changelist")
        return render_to_string(
            "meta_reports/columns/subject_identifier_column.html",
            {
                "subject_identifier": obj.subject_identifier,
                "url": url,
                "title": "Click to filter for this subject only",
            },
        )

    def get_subject_dashboard_url_kwargs(self, obj) -> dict:
        return dict(
            subject_identifier=obj.subject_identifier,
        )

    @admin.display(description="Appt date", ordering="appt_datetime")
    def appt_date(self, obj):
        if obj and obj.appt_datetime:
            return obj.appt_datetime.date()
        return None

    @admin.display(description="Onschedule date", ordering="onschedule_datetime")
    def onschedule_date(self, obj):
        if obj and obj.onschedule_datetime:
            return obj.onschedule_datetime.date()
        return None
