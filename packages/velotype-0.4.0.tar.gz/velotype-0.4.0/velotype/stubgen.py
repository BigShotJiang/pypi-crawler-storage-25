"""Generate .pyi stub text from ModelSpec."""

from __future__ import annotations

import subprocess
from typing import Literal

from velarium.ir import ModelSpec, TypeKind, TypeSpec


def _render_literal_value(v: object) -> str:
    if isinstance(v, (bool, type(None))):
        return repr(v)
    if isinstance(v, (int, float, str, bytes)):
        return repr(v)
    return repr(v)


def render_typespec(ts: TypeSpec) -> str:
    """Render TypeSpec as a PEP 604-style annotation string."""
    if ts.kind == TypeKind.NONE:
        return "None"
    if ts.kind == TypeKind.ANY:
        return "typing.Any"
    if ts.kind == TypeKind.INT:
        return "int"
    if ts.kind == TypeKind.FLOAT:
        return "float"
    if ts.kind == TypeKind.BOOL:
        return "bool"
    if ts.kind == TypeKind.STR:
        return "str"
    if ts.kind == TypeKind.BYTES:
        return "bytes"
    if ts.kind == TypeKind.DATETIME:
        return "datetime.datetime"
    if ts.kind == TypeKind.DATE:
        return "datetime.date"
    if ts.kind == TypeKind.TIME:
        return "datetime.time"
    if ts.kind == TypeKind.TIMESTAMP:
        return "datetime.datetime"
    if ts.kind == TypeKind.TYPE_VAR:
        # Stubs do not emit TypeVar declarations; field types fall back to Any.
        return "typing.Any"

    if ts.kind in (
        TypeKind.PARAM_SPEC,
        TypeKind.TYPE_VAR_TUPLE,
        TypeKind.PROTOCOL,
        TypeKind.NOMINAL,
    ):
        # IR preserves names for tooling; generated stubs stay simple and import-safe.
        return "typing.Any"

    if ts.kind == TypeKind.LITERAL:
        if ts.default is not None:
            return f"typing.Literal[{_render_literal_value(ts.default)}]"
        return "typing.Any"

    if ts.kind == TypeKind.LIST:
        inner = render_typespec(ts.args[0]) if ts.args else "typing.Any"
        return f"list[{inner}]"

    if ts.kind == TypeKind.SET:
        inner = render_typespec(ts.args[0]) if ts.args else "typing.Any"
        return f"set[{inner}]"

    if ts.kind == TypeKind.DICT:
        k = (
            render_typespec(ts.args[0])
            if ts.args and len(ts.args) > 0
            else "typing.Any"
        )
        v = (
            render_typespec(ts.args[1])
            if ts.args and len(ts.args) > 1
            else "typing.Any"
        )
        return f"dict[{k}, {v}]"

    if ts.kind == TypeKind.TUPLE:
        if not ts.args:
            return "tuple[()]"
        parts = [render_typespec(a) for a in ts.args]
        return f"tuple[{', '.join(parts)}]"

    if ts.kind == TypeKind.UNION:
        if not ts.args:
            return "typing.Any"
        parts = [render_typespec(a) for a in ts.args]
        return " | ".join(parts)

    if ts.kind == TypeKind.ENUM:
        if not ts.args:
            return "typing.Any"
        lit_parts = []
        for a in ts.args:
            if a.kind == TypeKind.LITERAL and a.default is not None:
                lit_parts.append(_render_literal_value(a.default))
            else:
                lit_parts.append(render_typespec(a))
        if lit_parts:
            return f"typing.Literal[{', '.join(lit_parts)}]"
        return "typing.Any"  # pragma: no cover — unreachable when args is non-empty; empty ENUM uses branch above

    if ts.kind == TypeKind.CALLABLE:
        if not ts.args or len(ts.args) < 2:
            return "typing.Callable[..., typing.Any]"
        params, ret = ts.args[0], ts.args[1]
        if params.kind == TypeKind.LIST and params.args:
            plist = ", ".join(render_typespec(x) for x in (params.args or []))
            return f"typing.Callable[[{plist}], {render_typespec(ret)}]"
        return f"typing.Callable[[{render_typespec(params)}], {render_typespec(ret)}]"

    if ts.kind == TypeKind.GENERIC:
        return "typing.Any"

    return "typing.Any"  # pragma: no cover — all TypeKind variants handled above


def _default_repr(value: object) -> str:
    if isinstance(value, str):
        return repr(value)
    return repr(value)


def _typespec_needs_datetime(ts: TypeSpec) -> bool:
    """Whether rendering this TypeSpec references ``datetime``."""
    if ts.kind in (
        TypeKind.DATETIME,
        TypeKind.DATE,
        TypeKind.TIME,
        TypeKind.TIMESTAMP,
    ):
        return True
    if ts.args:
        return any(_typespec_needs_datetime(a) for a in ts.args)
    return False


def _modelspec_needs_datetime(spec: ModelSpec) -> bool:
    return any(_typespec_needs_datetime(fts) for fts in spec.fields.values())


def generate_pyi(
    spec: ModelSpec,
    *,
    module_docstring: str | None = None,
    header: str | None = None,
    footer: str | None = None,
    include_all: bool = False,
    style: Literal["default", "minimal"] = "default",
) -> str:
    """Emit a minimal stub module body for a ModelSpec.

    **Imports:** ``import datetime`` is omitted when no field type uses date/time kinds
    (loss-minimized vs always importing).

    **include_all:** When True, appends ``__all__ = ("ClassName",)`` for the model class.

    **style:** ``default`` includes the standard velotype banner; ``minimal`` omits it.
    """
    lines: list[str] = []
    if style == "default":
        lines.append('"""Stub generated by velotype — ModelSpec IR."""')
        lines.append("")

    lines.append("from __future__ import annotations")
    lines.append("")

    need_dt = _modelspec_needs_datetime(spec)
    if need_dt:
        lines.append("import datetime")
    lines.append("import typing")
    lines.append("from dataclasses import dataclass")
    lines.append("")

    if module_docstring:
        lines.append(f'"""{module_docstring}"""')
        lines.append("")

    if header:
        lines.extend(header.strip("\n").split("\n"))
        lines.append("")

    lines.append("@dataclass")
    if spec.config and spec.config.frozen:
        lines[-1] = "@dataclass(frozen=True)"

    lines.append(f"class {spec.name}:")
    if not spec.fields:
        lines.append("    ...")
    else:
        for name, fts in spec.fields.items():
            ann = render_typespec(fts)
            if fts.default is not None:
                lines.append(f"    {name}: {ann} = {_default_repr(fts.default)}")
            else:
                lines.append(f"    {name}: {ann}")

    lines.append("")

    if include_all:
        lines.append(f"__all__ = (\"{spec.name}\",)")
        lines.append("")

    if footer:
        lines.extend(footer.strip("\n").split("\n"))
        lines.append("")

    return "\n".join(lines) + "\n"


def format_stub_text(
    text: str,
    *,
    backend: Literal["none", "ruff"] = "none",
) -> str:
    """Optionally reformat stub text (e.g. with **ruff format**). Not used by default.

    Requires ``ruff`` on ``PATH`` when ``backend`` is ``\"ruff\"``; returns input unchanged on failure.
    """
    if backend == "none":
        return text
    try:
        r = subprocess.run(
            ["ruff", "format", "-"],
            input=text.encode(),
            capture_output=True,
            check=True,
            timeout=60,
        )
        return r.stdout.decode()
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return text
