import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock
from slave_cp import fetcher


# ─── FIXTURES ───────────────────────────────────────────────────────────────

@pytest.fixture
def workspace(tmp_path):
    """Return a temp workspace directory."""
    ws = tmp_path / "competitive"
    ws.mkdir()
    return ws


# ─── PLATFORM DETECTION ─────────────────────────────────────────────────────

def test_fetch_contest_invalid_platform(workspace):
    with pytest.raises(ValueError, match="Unsupported platform"):
        fetcher.fetch_contest("XY1234", "unknown", workspace)


# ─── WRITE TESTCASES ────────────────────────────────────────────────────────

def test_write_testcases_creates_files(tmp_path):
    test_cases = [
        {"index": 1, "input": "3\n1 2 3", "output": "6"},
        {"index": 2, "input": "2\n4 5",   "output": "9"},
    ]
    fetcher.write_testcases(tmp_path, test_cases)

    assert (tmp_path / "input1.txt").exists()
    assert (tmp_path / "output1.txt").exists()
    assert (tmp_path / "input2.txt").exists()
    assert (tmp_path / "output2.txt").exists()


def test_write_testcases_correct_content(tmp_path):
    test_cases = [{"index": 1, "input": "5", "output": "10"}]
    fetcher.write_testcases(tmp_path, test_cases)

    assert (tmp_path / "input1.txt").read_text(encoding="utf-8")  == "5"
    assert (tmp_path / "output1.txt").read_text(encoding="utf-8") == "10"


def test_write_testcases_empty(tmp_path):
    fetcher.write_testcases(tmp_path, [])
    assert not any(tmp_path.iterdir())


# ─── CREATE SOLUTION TEMPLATE ────────────────────────────────────────────────

def test_create_solution_template_cpp(tmp_path):
    fetcher.create_solution_template(tmp_path, "A", ".cpp")
    assert (tmp_path / "A.cpp").exists()
    content = (tmp_path / "A.cpp").read_text()
    assert "#include" in content
    assert "int main" in content


def test_create_solution_template_python(tmp_path):
    fetcher.create_solution_template(tmp_path, "B", ".py")
    assert (tmp_path / "B.py").exists()
    content = (tmp_path / "B.py").read_text()
    assert "def main" in content


def test_create_solution_template_java(tmp_path):
    fetcher.create_solution_template(tmp_path, "C", ".java")
    assert (tmp_path / "C.java").exists()
    content = (tmp_path / "C.java").read_text()
    assert "class C" in content


def test_create_solution_template_does_not_overwrite(tmp_path):
    """If file already exists, template should not overwrite it."""
    solution = tmp_path / "A.cpp"
    solution.write_text("// my solution", encoding="utf-8")
    fetcher.create_solution_template(tmp_path, "A", ".cpp")
    assert solution.read_text(encoding="utf-8") == "// my solution"


def test_create_solution_template_unknown_ext_defaults_to_cpp(tmp_path):
    fetcher.create_solution_template(tmp_path, "A", ".xyz")
    assert (tmp_path / "A.cpp").exists()


# ─── SCRAPE CODEFORCES TESTCASES (mocked) ───────────────────────────────────

MOCK_CF_HTML = """
<html><body>
<div class="sample-test">
    <div class="input"><pre>3
1 2 3</pre></div>
    <div class="output"><pre>6</pre></div>
    <div class="input"><pre>2
4 5</pre></div>
    <div class="output"><pre>9</pre></div>
</div>
</body></html>
"""

def test_scrape_codeforces_testcases(requests_mock):
    url = "https://codeforces.com/contest/1234/problem/A"
    requests_mock.get(url, text=MOCK_CF_HTML)
    test_cases = fetcher.scrape_codeforces_testcases(url)

    assert len(test_cases) == 2
    assert test_cases[0]["input"]  == "3\n1 2 3"
    assert test_cases[0]["output"] == "6"
    assert test_cases[1]["input"]  == "2\n4 5"
    assert test_cases[1]["output"] == "9"


def test_scrape_codeforces_testcases_no_sample(requests_mock):
    url = "https://codeforces.com/contest/1234/problem/B"
    requests_mock.get(url, text="<html><body>No samples here</body></html>")
    test_cases = fetcher.scrape_codeforces_testcases(url)
    assert test_cases == []


def test_scrape_codeforces_testcases_http_error(requests_mock):
    url = "https://codeforces.com/contest/9999/problem/A"
    requests_mock.get(url, status_code=404)
    with pytest.raises(ConnectionError):
        fetcher.scrape_codeforces_testcases(url)


# ─── SCRAPE CODECHEF TESTCASES ───────────────────────────────────────────────

MOCK_CC_HTML = """
<html><body>
<section>
    <h3>Example</h3>
    <pre>5
1 2 3 4 5</pre>
    <pre>15</pre>
</section>
</body></html>
"""

def test_scrape_codechef_testcases():
    test_cases = fetcher.scrape_codechef_testcases(MOCK_CC_HTML)
    assert len(test_cases) == 1
    assert test_cases[0]["input"]  == "5\n1 2 3 4 5"
    assert test_cases[0]["output"] == "15"


def test_scrape_codechef_testcases_no_examples():
    html = "<html><body><section><h3>Constraints</h3></section></body></html>"
    test_cases = fetcher.scrape_codechef_testcases(html)
    assert test_cases == []