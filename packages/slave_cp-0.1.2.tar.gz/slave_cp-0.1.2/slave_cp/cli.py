"""Command-line interface for slave-cp."""

import click
from pathlib import Path
from rich.console import Console
from rich.prompt import Prompt, Confirm

from . import config
from . import fetcher
from . import runner
from . import utils

console = Console()


@click.group()
@click.version_option(version='0.1.1', prog_name='slave-cp')
def main():
    """
    slave-cp - Automate your competitive programming workflow.
    
    Fetch problems, test locally, and submit solutions with ease.
    """
    pass


@main.command()
@click.argument('workspace', type=click.Path(), required=False)
def init(workspace):
    """
    Initialize workspace and configure credentials.
    
    WORKSPACE: Path to your competitive programming workspace directory
    """
    console.print("\n[bold cyan]╔═══════════════════════════════════════╗[/bold cyan]")
    console.print("[bold cyan]║      slave-cp Initialization          ║[/bold cyan]")
    console.print("[bold cyan]╚═══════════════════════════════════════╝[/bold cyan]\n")
    
    # Set workspace
    if not workspace:
        default_workspace = str(Path.home() / 'competitive')
        workspace = Prompt.ask(
            "[cyan]Enter workspace path[/cyan]",
            default=default_workspace
        )
    
    try:
        workspace_path = config.set_workspace(workspace)
        console.print(f"[green]✓ Workspace set to:[/green] {workspace_path}\n")
    except Exception as e:
        console.print(f"[red]Error setting workspace: {e}[/red]")
        return
    
    # Set default language
    console.print("[cyan]Select default programming language:[/cyan]")
    console.print("  1. C++ (cpp)")
    console.print("  2. Python (py)")
    console.print("  3. Java (java)")
    console.print("  4. Other\n")
    
    lang_choice = Prompt.ask(
        "Enter choice",
        choices=['1', '2', '3', '4'],
        default='1'
    )
    
    lang_map = {
        '1': 'cpp',
        '2': 'py',
        '3': 'java',
    }
    
    if lang_choice in lang_map:
        language = lang_map[lang_choice]
    else:
        language = Prompt.ask("[cyan]Enter language extension (e.g., cpp, py, java)[/cyan]")
    
    config.set_language(language)
    console.print(f"[green]✓ Default language set to:[/green] {language}\n")
    
    # Configure Codeforces
    console.print("[bold cyan]Codeforces Configuration[/bold cyan]")
    
    if Confirm.ask("Configure Codeforces credentials?", default=True):
        cf_handle = Prompt.ask("[cyan]Codeforces handle[/cyan]")
        cf_password = Prompt.ask("[cyan]Codeforces password[/cyan]", password=True)
        
        # Validate credentials
        if config.validate_cf_credentials(cf_handle, cf_password):
            config.set_cf_credentials(cf_handle, cf_password)
            console.print("[green]✓ Codeforces credentials saved[/green]\n")
        else:
            console.print("[red]✗ Invalid credentials - not saved[/red]")
            console.print("[yellow]You can run 'slave-cp init' again to reconfigure[/yellow]\n")
    else:
        console.print("[yellow]Skipped Codeforces configuration[/yellow]\n")
    
    # Configure CodeChef
    console.print("[bold cyan]CodeChef Configuration[/bold cyan]")
    
    if Confirm.ask("Configure CodeChef credentials?", default=True):
        cc_handle = Prompt.ask("[cyan]CodeChef handle[/cyan]")
        cc_password = Prompt.ask("[cyan]CodeChef password[/cyan]", password=True)
        
        if cc_handle and cc_password:
            config.set_cc_credentials(cc_handle, cc_password)
            console.print("[green]✓ CodeChef credentials saved[/green]\n")
        else:
            console.print("[yellow]Empty credentials - skipped[/yellow]\n")
    else:
        console.print("[yellow]Skipped CodeChef configuration[/yellow]\n")
    
    console.print("[bold green]✓ Initialization complete![/bold green]")
    console.print("\n[cyan]Next steps:[/cyan]")
    console.print("  1. Fetch a contest: [yellow]slave-cp fetch CF1234[/yellow]")
    console.print("  2. Write your solution in the problem folder")
    console.print("  3. Test it: [yellow]slave-cp run A[/yellow]")
    console.print("\nRun [yellow]slave-cp --help[/yellow] for more commands.\n")


@main.command()
@click.argument('contest_id')
def fetch(contest_id):
    """
    Fetch problems and test cases from a contest.
    
    CONTEST_ID: Contest identifier (e.g., CF1234 for Codeforces, CC-START001 for CodeChef)
    """
    workspace = config.get_workspace()
    
    if not workspace:
        console.print("[red]Workspace not configured. Run 'slave-cp init' first.[/red]")
        return
    
    console.print(f"\n[bold cyan]Fetching contest: {contest_id}[/bold cyan]\n")
    
    cfg = config.get_config()
    success = fetcher.fetch_contest(contest_id, workspace, cfg)
    
    if success:
        console.print(f"\n[green]Contest fetched successfully![/green]")
        console.print(f"[cyan]Location:[/cyan] {Path(workspace) / contest_id}")
        console.print(f"\n[cyan]Next:[/cyan] Navigate to a problem folder and write your solution")
        console.print(f"[cyan]Then run:[/cyan] [yellow]slave-cp run <problem>[/yellow]\n")


@main.command()
@click.argument('problem')
@click.option('--contest', '-c', help='Contest ID (auto-detected if in contest folder)')
def run(problem, contest):
    """
    Test your solution against sample test cases.
    
    PROBLEM: Problem identifier (e.g., A, B, C)
    """
    workspace = config.get_workspace()
    
    if not workspace:
        console.print("[red]Workspace not configured. Run 'slave-cp init' first.[/red]")
        return
    
    # Auto-detect contest if not provided
    if not contest:
        cwd = Path.cwd()
        workspace_path = Path(workspace)
        
        # Check if we're inside a contest folder
        if workspace_path in cwd.parents or cwd == workspace_path:
            relative = cwd.relative_to(workspace_path)
            parts = relative.parts
            if parts:
                contest = parts[0]
        
        if not contest:
            console.print("[red]Could not detect contest. Please specify with --contest or run from within a contest folder.[/red]")
            return
    
    console.print(f"\n[bold cyan]Testing problem {problem} from contest {contest}[/bold cyan]\n")
    
    # Get default language
    language = config.get_language()
    
    # Run tests
    cfg = config.get_config()
    runner.run_tests(problem, contest, workspace, language, cfg)


@main.command()
def show_config():
    """
    Display current configuration.
    """
    config.display_config()


# Alias for config command
@main.command(name='config')
def config_alias():
    """
    Display current configuration.
    """
    config.display_config()


@main.command()
def list():
    """
    List all contests in workspace.
    """
    workspace = config.get_workspace()
    
    if not workspace:
        console.print("[red]Workspace not configured. Run 'slave-cp init' first.[/red]")
        return
    
    workspace_path = Path(workspace)
    
    if not workspace_path.exists():
        console.print(f"[red]Workspace does not exist: {workspace}[/red]")
        return
    
    # Find contest directories (CF* or CC-*)
    contests = []
    for item in workspace_path.iterdir():
        if item.is_dir() and (item.name.startswith('CF') or item.name.startswith('CC-')):
            contests.append(item.name)
    
    if not contests:
        console.print("[yellow]No contests found in workspace.[/yellow]")
        console.print(f"\n[cyan]Workspace:[/cyan] {workspace}")
        console.print("[cyan]Fetch a contest with:[/cyan] [yellow]slave-cp fetch CF1234[/yellow]\n")
        return
    
    console.print(f"\n[bold cyan]Contests in workspace:[/bold cyan] {workspace}\n")
    
    for contest in sorted(contests):
        contest_path = workspace_path / contest
        
        # Count problems
        problems = [p.name for p in contest_path.iterdir() if p.is_dir()]
        problem_count = len(problems)
        
        console.print(f"  [green]{contest}[/green] - {problem_count} problem(s)")
    
    console.print()


@main.command()
def check():
    """
    Check which compilers and interpreters are installed.
    """
    console.print("\n[bold cyan]Checking installed compilers/interpreters...[/bold cyan]\n")
    
    utils.check_compilers()
    
    console.print("\n[cyan]Tip:[/cyan] Install missing tools to support more languages.\n")


if __name__ == '__main__':
    main()
