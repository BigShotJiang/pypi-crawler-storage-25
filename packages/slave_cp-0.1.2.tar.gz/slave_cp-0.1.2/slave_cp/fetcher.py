"""Fetcher module for scraping problems and test cases from competitive programming platforms."""

import re
import time
from pathlib import Path
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from rich.console import Console

console = Console()


# Browser-like headers to avoid being blocked
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Cache-Control': 'max-age=0',
}

# Solution templates keyed by extension
_TEMPLATES = {
    ".cpp": """\
#include <bits/stdc++.h>
using namespace std;

int main() {{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    // TODO: solve {problem}

    return 0;
}}
""",
    ".py": """\
import sys
input = sys.stdin.readline

def main():
    # TODO: solve {problem}
    pass

if __name__ == "__main__":
    main()
""",
    ".java": """\
import java.util.*;
import java.io.*;

public class {problem} {{
    public static void main(String[] args) throws IOException {{
        Scanner sc = new Scanner(System.in);
        // TODO: solve {problem}
    }}
}}
""",
}


# ─── WRITE TESTCASES ────────────────────────────────────────────────────────

def write_testcases(folder: Path, test_cases: list):
    """
    Write test cases to input/output files inside folder.

    Args:
        folder: Directory to write files into
        test_cases: List of dicts with keys 'index', 'input', 'output'
    """
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    for tc in test_cases:
        idx = tc["index"]
        (folder / f"input{idx}.txt").write_text(tc["input"],  encoding="utf-8")
        (folder / f"output{idx}.txt").write_text(tc["output"], encoding="utf-8")


# ─── CREATE SOLUTION TEMPLATE ────────────────────────────────────────────────

def create_solution_template(folder: Path, problem: str, ext: str):
    """
    Create a solution template file. Does NOT overwrite existing files.
    Falls back to .cpp for unknown extensions.

    Args:
        folder:  Directory to create the file in
        problem: Problem label (e.g. 'A', 'B')
        ext:     File extension including dot (e.g. '.cpp', '.py')
    """
    folder = Path(folder)

    # Fall back to .cpp for unknown extensions
    if ext not in _TEMPLATES:
        ext = ".cpp"

    dest = folder / f"{problem}{ext}"

    # Never overwrite
    if dest.exists():
        return

    template = _TEMPLATES[ext].format(problem=problem)
    dest.write_text(template, encoding="utf-8")


# ─── SCRAPE CODEFORCES TESTCASES ─────────────────────────────────────────────

def scrape_codeforces_testcases(url: str) -> list:
    """
    Fetch a single Codeforces problem page and extract sample test cases.

    Args:
        url: Full URL to the problem page

    Returns:
        List of dicts with keys 'index', 'input', 'output'

    Raises:
        ConnectionError: On any non-200 HTTP response
    """
    session = requests.Session()
    session.headers.update(HEADERS)

    response = session.get(url, timeout=15)
    if response.status_code != 200:
        raise ConnectionError(
            f"Failed to fetch {url} — HTTP {response.status_code}"
        )

    soup = BeautifulSoup(response.text, "html.parser")
    sample_div = soup.find("div", class_="sample-test")
    if not sample_div:
        return []

    inputs  = sample_div.find_all("div", class_="input")
    outputs = sample_div.find_all("div", class_="output")

    test_cases = []
    for idx, (inp, out) in enumerate(zip(inputs, outputs), 1):
        input_text  = inp.find("pre").get_text(strip=False).strip()
        output_text = out.find("pre").get_text(strip=False).strip()
        test_cases.append({
            "index":  idx,
            "input":  input_text,
            "output": output_text,
        })

    return test_cases


# ─── SCRAPE CODECHEF TESTCASES ───────────────────────────────────────────────

def scrape_codechef_testcases(html: str) -> list:
    """
    Parse CodeChef problem HTML and extract sample test cases.
    Looks for a <section> containing an <h3>Example</h3> header,
    then takes the first two <pre> blocks as input and output.

    Args:
        html: Raw HTML string of the problem page

    Returns:
        List of dicts with keys 'index', 'input', 'output'
    """
    soup = BeautifulSoup(html, "html.parser")
    test_cases = []

    for section in soup.find_all("section"):
        h3 = section.find("h3")
        if not h3 or "example" not in h3.get_text(strip=True).lower():
            continue

        pres = section.find_all("pre")
        # Pair them up: first is input, second is output
        for i in range(0, len(pres) - 1, 2):
            input_text  = pres[i].get_text(strip=False).strip()
            output_text = pres[i + 1].get_text(strip=False).strip()
            test_cases.append({
                "index":  len(test_cases) + 1,
                "input":  input_text,
                "output": output_text,
            })

    return test_cases


# ─── FETCH CONTEST (main entry point) ────────────────────────────────────────

def fetch_contest(contest_id: str, platform: str, workspace, config: dict = None):
    """
    Main entry point for fetching contests.

    Args:
        contest_id: Contest ID (e.g., 'CF1234' or 'CC-START001')
        platform:   Platform string — only used for validation.
                    Actual platform is inferred from contest_id prefix.
        workspace:  Path to workspace directory
        config:     Configuration dict (needed for CodeChef credentials)

    Returns:
        bool: True if successful

    Raises:
        ValueError: If platform/contest_id prefix is unrecognised
    """
    workspace = Path(workspace)
    config = config or {}

    if contest_id.startswith("CF"):
        cf_id = contest_id[2:]
        return fetch_codeforces(cf_id, workspace)

    elif contest_id.startswith("CC-"):
        cc_id = contest_id[3:]
        if "codechef" not in config or not config["codechef"].get("handle"):
            console.print("[red]CodeChef credentials not found. Run 'slave-cp init' first.[/red]")
            return False
        return fetch_codechef(cc_id, workspace, config["codechef"])

    else:
        raise ValueError(
            f"Unsupported platform or contest ID format: '{contest_id}'. "
            "Use 'CF' prefix for Codeforces (e.g. CF1234) "
            "or 'CC-' prefix for CodeChef (e.g. CC-START001)."
        )


# ─── INTERNAL HELPERS (unchanged from original) ──────────────────────────────

def fetch_codeforces(contest_id, workspace):
    """Fetch all problems for a Codeforces contest."""
    contest_url = f"https://codeforces.com/contest/{contest_id}"

    try:
        session = requests.Session()
        session.headers.update(HEADERS)

        console.print("[cyan]Visiting Codeforces to establish session...[/cyan]")
        session.get("https://codeforces.com", timeout=15)
        time.sleep(1)

        console.print(f"[cyan]Fetching contest {contest_id}...[/cyan]")
        response = session.get(contest_url, timeout=15)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")
        problem_links = soup.find_all(
            "a", href=re.compile(rf"/contest/{contest_id}/problem/[A-Z]")
        )

        if not problem_links:
            console.print("[red]No problems found.[/red]")
            return False

        problems = sorted(set(link["href"].split("/")[-1] for link in problem_links))
        console.print(f"[green]Found {len(problems)} problems: {', '.join(problems)}[/green]")

        contest_dir = Path(workspace) / f"CF{contest_id}"
        contest_dir.mkdir(parents=True, exist_ok=True)

        for problem_id in problems:
            fetch_codeforces_problem(session, contest_id, problem_id, contest_dir)

        console.print(f"[bold green]✓ Fetched CF{contest_id}[/bold green]")
        return True

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 403:
            console.print("[red]HTTP 403 — Codeforces blocked the request.[/red]")
        else:
            console.print(f"[red]HTTP Error: {e}[/red]")
        return False
    except requests.exceptions.RequestException as e:
        console.print(f"[red]Network error: {e}[/red]")
        return False
    except Exception as e:
        console.print(f"[red]Unexpected error: {e}[/red]")
        return False


def fetch_codeforces_problem(session, contest_id, problem_id, contest_dir):
    """Fetch a single Codeforces problem and write its test cases."""
    problem_url = f"https://codeforces.com/contest/{contest_id}/problem/{problem_id}"

    try:
        console.print(f"[cyan]  Fetching problem {problem_id}...[/cyan]")
        time.sleep(0.5)

        response = session.get(problem_url, timeout=15)
        response.raise_for_status()

        problem_dir = contest_dir / problem_id
        problem_dir.mkdir(parents=True, exist_ok=True)

        test_cases = scrape_codeforces_testcases(problem_url)
        # scrape_codeforces_testcases already fetched — reparse from response
        soup = BeautifulSoup(response.text, "html.parser")
        sample_div = soup.find("div", class_="sample-test")

        if not sample_div:
            console.print(f"[yellow]    No sample tests for {problem_id}[/yellow]")
            return

        inputs  = sample_div.find_all("div", class_="input")
        outputs = sample_div.find_all("div", class_="output")

        for idx, (inp, out) in enumerate(zip(inputs, outputs), 1):
            input_text  = inp.find("pre").get_text(strip=False)
            output_text = out.find("pre").get_text(strip=False)
            (problem_dir / f"input{idx}.txt").write_text(input_text,  encoding="utf-8")
            (problem_dir / f"output{idx}.txt").write_text(output_text, encoding="utf-8")

        count = len(list(problem_dir.glob("input*.txt")))
        console.print(f"[green]    ✓ {problem_id}: {count} test case(s)[/green]")

    except Exception as e:
        console.print(f"[red]    Error fetching {problem_id}: {e}[/red]")


def fetch_codechef(contest_id, workspace, credentials):
    """Fetch CodeChef contest using Selenium."""
    try:
        console.print("[cyan]Launching headless Chrome for CodeChef...[/cyan]")

        chrome_options = Options()
        chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_argument(
            "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        )

        driver = webdriver.Chrome(options=chrome_options)

        try:
            console.print("[cyan]Logging in to CodeChef...[/cyan]")
            driver.get("https://www.codechef.com")
            time.sleep(2)

            login_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.LINK_TEXT, "Login"))
            )
            login_button.click()
            time.sleep(2)

            driver.find_element(By.ID, "edit-name").send_keys(credentials["handle"])
            driver.find_element(By.ID, "edit-pass").send_keys(credentials["password"])
            driver.find_element(By.ID, "edit-submit").click()
            time.sleep(3)

            contest_url = f"https://www.codechef.com/{contest_id}"
            driver.get(contest_url)
            time.sleep(2)

            problem_elements = driver.find_elements(By.CSS_SELECTOR, "a[href*='/problems/']")
            problem_codes = []
            for elem in problem_elements:
                href = elem.get_attribute("href")
                if href and "/problems/" in href:
                    code = href.split("/problems/")[-1].split("?")[0]
                    if code and code not in problem_codes:
                        problem_codes.append(code)

            if not problem_codes:
                console.print("[red]No problems found.[/red]")
                return False

            console.print(f"[green]Found {len(problem_codes)} problems[/green]")

            contest_dir = Path(workspace) / f"CC-{contest_id}"
            contest_dir.mkdir(parents=True, exist_ok=True)

            for code in problem_codes:
                fetch_codechef_problem(driver, code, contest_dir)

            console.print(f"[bold green]✓ Fetched CC-{contest_id}[/bold green]")
            return True

        finally:
            driver.quit()

    except Exception as e:
        console.print(f"[red]Error fetching from CodeChef: {e}[/red]")
        return False


def fetch_codechef_problem(driver, problem_code, contest_dir):
    """Fetch a single CodeChef problem."""
    try:
        console.print(f"[cyan]  Fetching {problem_code}...[/cyan]")
        driver.get(f"https://www.codechef.com/problems/{problem_code}")
        time.sleep(2)

        problem_dir = contest_dir / problem_code
        problem_dir.mkdir(parents=True, exist_ok=True)

        test_cases = scrape_codechef_testcases(driver.page_source)
        write_testcases(problem_dir, test_cases)

        console.print(f"[green]    ✓ {problem_code}: {len(test_cases)} test case(s)[/green]")

    except Exception as e:
        console.print(f"[red]    Error fetching {problem_code}: {e}[/red]")