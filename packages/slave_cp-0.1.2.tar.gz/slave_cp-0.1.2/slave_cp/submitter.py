import time
import requests
from pathlib import Path
from bs4 import BeautifulSoup
from rich.console import Console
from slave_cp import config

console = Console()

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

# ─── CODEFORCES LANGUAGE MAP ─────────────────────────────────────────────────
# Maps file extension → Codeforces language ID

CF_LANG_MAP = {
    ".cpp":   "54",   # GNU G++17 7.3.0
    ".c":     "43",   # GNU GCC C11 5.1.0
    ".py":    "70",   # PyPy 3-64
    ".java":  "60",   # Java 11.0.6
    ".kt":    "88",   # Kotlin 1.6.10
    ".go":    "32",   # Go 1.19.5
    ".rs":    "75",   # Rust 2021
    ".cs":    "65",   # Mono C# 6.8
    ".rb":    "67",   # Ruby 3.0.0
    ".js":    "55",   # Node.js 12.16.3
    ".hs":    "12",   # Haskell GHC 8.10.1
    ".scala": "20",   # Scala 2.12.8
    ".d":     "28",   # D DMD32 v2.091.0
    ".pas":   "4",    # Pascal Free Pascal 3.0.2
    ".pl":    "13",   # Perl 5.20.1
    ".php":   "6",    # PHP 8.1.7
    ".swift": "83",   # Swift 5.5
    ".lua":   "19",   # Lua 5.3.5
    ".r":     "99",   # R 4.2.1 (if supported)
    ".dart":  "91",   # Dart 2.18 (if supported)
    ".fs":    "100",  # F# (if supported)
    ".ts":    "55",   # Falls back to Node.js
}

# ─── CODECHEF LANGUAGE MAP ───────────────────────────────────────────────────

CC_LANG_MAP = {
    ".cpp":   "cpp17",
    ".c":     "c",
    ".py":    "python3",
    ".java":  "java",
    ".kt":    "kotlin",
    ".go":    "go",
    ".rs":    "rust",
    ".cs":    "csharp",
    ".rb":    "ruby",
    ".js":    "nodejs",
    ".hs":    "haskell",
    ".scala": "scala",
    ".pas":   "pascal-fpc",
    ".pl":    "perl",
    ".php":   "php",
    ".swift": "swift",
    ".lua":   "lua",
    ".d":     "d",
    ".ts":    "nodejs",
}


# ─── MAIN ENTRY POINT ────────────────────────────────────────────────────────

def submit(problem: str, contest_id: str, platform: str, workspace: Path):
    """Main function called by cli.py to submit a solution."""
    if platform == "codeforces":
        submit_codeforces(problem, contest_id, workspace)
    elif platform == "codechef":
        submit_codechef(problem, contest_id, workspace)
    else:
        raise ValueError(f"Unsupported platform: {platform}")


# ─── CODEFORCES ──────────────────────────────────────────────────────────────

def submit_codeforces(problem: str, contest_id: str, workspace: Path):
    """Login to Codeforces and submit the solution."""

    creds = config.get_credentials("codeforces")
    handle   = creds.get("handle")
    password = creds.get("password")

    if not handle or not password:
        console.print("[bold red]✘ Codeforces credentials not set.[/]")
        console.print("[dim]Run 'slave-cp init <path>' to set your credentials.[/]")
        return

    numeric_id = contest_id.upper().replace("CF", "").strip()
    contest_folder = workspace / contest_id.upper()

    # ── Find solution file ──
    solution_file, ext = find_solution_file(contest_folder, problem)
    if solution_file is None:
        console.print(f"[bold red]✘ No solution file found for problem {problem.upper()}[/]")
        return

    lang_id = CF_LANG_MAP.get(ext)
    if not lang_id:
        console.print(f"[bold red]✘ Language {ext} not supported for Codeforces submission.[/]")
        return

    source_code = solution_file.read_text(encoding="utf-8")

    session = requests.Session()
    session.headers.update(HEADERS)

    # ── Step 1: Get CSRF token from login page ──
    console.print("[dim]Connecting to Codeforces...[/]")
    try:
        login_page = session.get("https://codeforces.com/enter", timeout=15)
    except requests.RequestException as e:
        console.print(f"[bold red]✘ Could not reach Codeforces: {e}[/]")
        return

    csrf_token = extract_csrf(login_page.text)
    if not csrf_token:
        console.print("[bold red]✘ Could not extract CSRF token from Codeforces.[/]")
        return

    # ── Step 2: Login ──
    console.print(f"[dim]Logging in as:[/] [bold]{handle}[/]")
    login_data = {
        "handleOrEmail": handle,
        "password":      password,
        "action":        "enter",
        "csrf_token":    csrf_token,
        "remember":      "on"
    }

    login_response = session.post(
        "https://codeforces.com/enter",
        data=login_data,
        timeout=15
    )

    if "logout" not in login_response.text.lower():
        console.print("[bold red]✘ Login failed. Check your Codeforces handle and password.[/]")
        return

    console.print("[bold green]✔ Logged in successfully.[/]")

    # ── Step 3: Get CSRF token from submit page ──
    submit_page_url = f"https://codeforces.com/contest/{numeric_id}/submit"
    submit_page = session.get(submit_page_url, timeout=15)
    submit_csrf = extract_csrf(submit_page.text)

    if not submit_csrf:
        console.print("[bold red]✘ Could not extract CSRF token from submit page.[/]")
        return

    # ── Step 4: Submit ──
    console.print(f"[dim]Submitting problem {problem.upper()} ({ext}) ...[/]")

    submit_data = {
        "csrf_token":          submit_csrf,
        "action":              "submitSolutionFormSubmitAjax",
        "contestId":           numeric_id,
        "problemIndex":        problem.upper(),
        "programTypeId":       lang_id,
        "source":              source_code,
        "tabSize":             4,
        "_tta":                "594"
    }

    submit_response = session.post(
        f"https://codeforces.com/contest/{numeric_id}/submit?csrf_token={submit_csrf}",
        data=submit_data,
        timeout=15
    )

    if submit_response.status_code == 200:
        console.print("[bold green]✔ Solution submitted successfully![/]")
        console.print(f"[dim]View your submission at:[/] https://codeforces.com/contest/{numeric_id}/my")
        poll_codeforces_verdict(session, numeric_id, handle)
    else:
        console.print(f"[bold red]✘ Submission failed (HTTP {submit_response.status_code})[/]")


def poll_codeforces_verdict(session: requests.Session, contest_id: str, handle: str):
    """Poll Codeforces for the verdict of the latest submission."""
    console.print("\n[dim]Waiting for verdict", end="")

    url = f"https://codeforces.com/contest/{contest_id}/my"
    max_attempts = 20

    for attempt in range(max_attempts):
        time.sleep(3)
        console.print(".", end="", flush=True)

        try:
            response = session.get(url, timeout=15)
            soup = BeautifulSoup(response.text, "html.parser")

            # Find the verdict cell of the latest submission
            verdict_cell = soup.select_one("td.status-cell")
            if not verdict_cell:
                continue

            verdict_text = verdict_cell.get_text(strip=True)

            # Still judging
            if "queue" in verdict_text.lower() or "running" in verdict_text.lower() or verdict_text == "":
                continue

            console.print()  # newline after dots

            if "accepted" in verdict_text.lower():
                console.print(f"\n[bold green]  ✔ ACCEPTED[/] 🎉")
            elif "wrong answer" in verdict_text.lower():
                console.print(f"\n[bold red]  ✘ WRONG ANSWER[/]")
            elif "time limit" in verdict_text.lower():
                console.print(f"\n[bold yellow]  ✘ TIME LIMIT EXCEEDED[/]")
            elif "memory limit" in verdict_text.lower():
                console.print(f"\n[bold yellow]  ✘ MEMORY LIMIT EXCEEDED[/]")
            elif "runtime error" in verdict_text.lower():
                console.print(f"\n[bold red]  ✘ RUNTIME ERROR[/]")
            elif "compilation error" in verdict_text.lower():
                console.print(f"\n[bold red]  ✘ COMPILATION ERROR[/]")
            else:
                console.print(f"\n[bold cyan]  Verdict: {verdict_text}[/]")

            return

        except Exception:
            continue

    console.print()
    console.print("[yellow]⚠ Could not fetch verdict. Check manually.[/]")
    console.print(f"[dim]https://codeforces.com/contest/{contest_id}/my[/]")


# ─── CODECHEF ────────────────────────────────────────────────────────────────

def submit_codechef(problem: str, contest_id: str, workspace: Path):
    """Login to CodeChef via Selenium and submit the solution."""

    creds = config.get_credentials("codechef")
    handle   = creds.get("handle")
    password = creds.get("password")

    if not handle or not password:
        console.print("[bold red]✘ CodeChef credentials not set.[/]")
        console.print("[dim]Run 'slave-cp init <path>' to set your credentials.[/]")
        return

    numeric_id     = contest_id.upper().replace("CC-", "").replace("CC", "").strip()
    contest_folder = workspace / contest_id.upper()

    # ── Find solution file ──
    solution_file, ext = find_solution_file(contest_folder, problem)
    if solution_file is None:
        console.print(f"[bold red]✘ No solution file found for problem {problem.upper()}[/]")
        return

    lang_id = CC_LANG_MAP.get(ext)
    if not lang_id:
        console.print(f"[bold red]✘ Language {ext} not supported for CodeChef submission.[/]")
        return

    source_code = solution_file.read_text(encoding="utf-8")

    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait
        from selenium.webdriver.support import expected_conditions as EC
        from selenium.webdriver.common.keys import Keys
        from webdriver_manager.chrome import ChromeDriverManager
    except ImportError:
        raise ImportError("Selenium not installed. Run: pip install selenium webdriver-manager")

    options = webdriver.ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    driver = webdriver.Chrome(
        service=Service(ChromeDriverManager().install()),
        options=options
    )

    try:
        # ── Step 1: Login ──
        console.print("[dim]Logging in to CodeChef...[/]")
        driver.get("https://www.codechef.com/login")
        wait = WebDriverWait(driver, 15)

        wait.until(EC.presence_of_element_located((By.ID, "edit-name")))
        driver.find_element(By.ID, "edit-name").send_keys(handle)
        driver.find_element(By.ID, "edit-pass").send_keys(password)
        driver.find_element(By.ID, "edit-submit").click()

        time.sleep(4)

        if "login" in driver.current_url.lower():
            console.print("[bold red]✘ Login failed. Check your CodeChef handle and password.[/]")
            return

        console.print("[bold green]✔ Logged in successfully.[/]")

        # ── Step 2: Go to submit page ──
        submit_url = f"https://www.codechef.com/{numeric_id}/problems/{problem.upper()}/submit"
        driver.get(submit_url)
        time.sleep(3)

        # ── Step 3: Select language ──
        console.print(f"[dim]Selecting language: {lang_id}[/]")
        lang_select = wait.until(EC.presence_of_element_located((By.NAME, "language")))
        for option in lang_select.find_elements(By.TAG_NAME, "option"):
            if option.get_attribute("value") == lang_id:
                option.click()
                break

        # ── Step 4: Paste code ──
        # CodeChef uses CodeMirror editor
        code_area = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ".CodeMirror")))
        driver.execute_script(
            "arguments[0].CodeMirror.setValue(arguments[1]);",
            code_area,
            source_code
        )

        # ── Step 5: Submit ──
        submit_btn = driver.find_element(By.ID, "submit-problem")
        submit_btn.click()
        console.print("[bold green]✔ Solution submitted successfully![/]")

        # ── Step 6: Poll for verdict ──
        poll_codechef_verdict(driver, wait)

    finally:
        driver.quit()


def poll_codechef_verdict(driver, wait):
    """Wait and poll for the verdict on CodeChef."""
    console.print("\n[dim]Waiting for verdict", end="")

    max_attempts = 20
    for attempt in range(max_attempts):
        time.sleep(3)
        console.print(".", end="", flush=True)

        try:
            soup = BeautifulSoup(driver.page_source, "html.parser")
            verdict_el = soup.select_one(".verdict, .result, [class*='verdict']")

            if not verdict_el:
                continue

            verdict_text = verdict_el.get_text(strip=True).lower()

            if not verdict_text or "running" in verdict_text or "waiting" in verdict_text:
                continue

            console.print()  # newline after dots

            if "accepted" in verdict_text:
                console.print("\n[bold green]  ✔ ACCEPTED[/] 🎉")
            elif "wrong" in verdict_text:
                console.print("\n[bold red]  ✘ WRONG ANSWER[/]")
            elif "time limit" in verdict_text:
                console.print("\n[bold yellow]  ✘ TIME LIMIT EXCEEDED[/]")
            elif "runtime" in verdict_text:
                console.print("\n[bold red]  ✘ RUNTIME ERROR[/]")
            elif "compile" in verdict_text:
                console.print("\n[bold red]  ✘ COMPILATION ERROR[/]")
            else:
                console.print(f"\n[bold cyan]  Verdict: {verdict_text}[/]")

            return

        except Exception:
            continue

    console.print()
    console.print("[yellow]⚠ Could not fetch verdict. Check manually on CodeChef.[/]")


# ─── HELPERS ─────────────────────────────────────────────────────────────────

def extract_csrf(html: str) -> str | None:
    """Extract CSRF token from a Codeforces page."""
    soup = BeautifulSoup(html, "html.parser")
    meta = soup.find("meta", {"name": "X-Csrf-Token"})
    if meta:
        return meta.get("content")
    # Fallback: look in hidden input
    inp = soup.find("input", {"name": "csrf_token"})
    if inp:
        return inp.get("value")
    return None


def find_solution_file(contest_folder: Path, problem: str):
    """
    Find the solution file for a problem by scanning all known extensions.
    Returns (Path, extension) or (None, None).
    """
    from slave_cp.runner import LANGUAGES

    found = []
    for ext in LANGUAGES:
        candidate = contest_folder / f"{problem.upper()}{ext}"
        if candidate.exists():
            found.append((candidate, ext))

    if not found:
        return None, None

    if len(found) == 1:
        return found[0]

    # Multiple files — ask user
    console.print(f"\n[bold yellow]Multiple solution files found:[/]")
    for i, (f, e) in enumerate(found):
        console.print(f"  [{i + 1}] {f.name}")

    while True:
        choice = input("\nWhich file to submit? (enter number): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(found):
            return found[int(choice) - 1]
        console.print("[red]Invalid choice. Try again.[/]")