"""Configuration management for slave-cp."""

import json
from pathlib import Path
import requests
from rich.console import Console

console = Console()

CONFIG_DIR  = Path.home() / '.slave-cp'
CONFIG_FILE = CONFIG_DIR / 'config.json'

_DEFAULT_CONFIG = {
    "workspace":  None,
    "extension":  ".cpp",
    "codeforces": {"handle": None, "password": None},
    "codechef":   {"handle": None, "password": None},
}


# ─── INIT / LOAD / SAVE ─────────────────────────────────────────────────────

def init_config():
    """Create config dir + file with defaults. Does NOT overwrite existing file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_FILE.exists():
        save_config(_DEFAULT_CONFIG.copy())


def load_config() -> dict:
    """Load config from file. Returns default structure if file missing."""
    if not CONFIG_FILE.exists():
        return _DEFAULT_CONFIG.copy()
    try:
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    except Exception as e:
        console.print(f"[red]Error reading config: {e}[/red]")
        return _DEFAULT_CONFIG.copy()


# Keep get_config as alias for backward compat
get_config = load_config


def save_config(config: dict):
    """Save configuration dict to file."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        console.print(f"[red]Error saving config: {e}[/red]")


# ─── WORKSPACE ──────────────────────────────────────────────────────────────

def set_workspace(path: str) -> str:
    """Set workspace dir. Creates it if it doesn't exist."""
    workspace_path = Path(path).expanduser().resolve()
    workspace_path.mkdir(parents=True, exist_ok=True)

    cfg = load_config()
    cfg['workspace'] = str(workspace_path)
    save_config(cfg)
    return str(workspace_path)


def get_workspace() -> Path:
    """Get workspace as a Path. Raises ValueError if not set."""
    cfg = load_config()
    ws = cfg.get('workspace')
    if not ws:
        raise ValueError("Workspace not set. Run 'slave-cp init' first.")
    return Path(ws)


# ─── LANGUAGE ───────────────────────────────────────────────────────────────

def set_language(language: str):
    cfg = load_config()
    cfg['language'] = language
    save_config(cfg)


def get_language() -> str:
    cfg = load_config()
    return cfg.get('language', 'cpp')


# ─── CREDENTIALS (unified) ───────────────────────────────────────────────────

def set_credentials(platform: str, handle: str, password: str):
    """Set credentials for 'codeforces' or 'codechef'."""
    cfg = load_config()
    if platform not in cfg:
        cfg[platform] = {}
    cfg[platform]['handle']   = handle
    cfg[platform]['password'] = password
    save_config(cfg)


def get_credentials(platform: str) -> dict:
    """Get credentials for a platform. Returns {} if not set."""
    cfg = load_config()
    return cfg.get(platform, {})


# ─── PLATFORM-SPECIFIC SHORTCUTS ────────────────────────────────────────────

def set_cf_credentials(handle: str, password: str):
    set_credentials('codeforces', handle, password)

def get_cf_credentials() -> dict:
    return get_credentials('codeforces')

def set_cc_credentials(handle: str, password: str):
    set_credentials('codechef', handle, password)

def get_cc_credentials() -> dict:
    return get_credentials('codechef')


# ─── VALIDATE CF ────────────────────────────────────────────────────────────

def validate_cf_credentials(handle: str, password: str) -> bool:
    """Validate CF credentials by attempting login. Returns True if valid."""
    if not handle or not password:
        console.print("[red]Handle and password cannot be empty[/red]")
        return False

    try:
        console.print("[cyan]Validating Codeforces credentials...[/cyan]")
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                          'AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
        })

        response = session.get('https://codeforces.com/enter', timeout=10)
        if response.status_code != 200:
            console.print("[yellow]Warning: CF unreachable — saving without validation[/yellow]")
            return True

        from bs4 import BeautifulSoup
        soup = BeautifulSoup(response.text, 'html.parser')
        csrf = soup.find('input', {'name': 'csrf_token'})
        if not csrf:
            console.print("[yellow]Warning: CSRF token not found — saving without validation[/yellow]")
            return True

        login_response = session.post(
            'https://codeforces.com/enter',
            data={
                'csrf_token': csrf.get('value'),
                'action': 'enter',
                'handleOrEmail': handle,
                'password': password,
                'remember': 'on',
            },
            timeout=10,
            allow_redirects=True,
        )

        if 'logout' in login_response.text.lower():
            console.print("[green]✓ Credentials validated[/green]")
            return True
        else:
            console.print("[red]✗ Invalid credentials[/red]")
            return False

    except requests.exceptions.RequestException:
        console.print("[yellow]Warning: Network error — saving without validation[/yellow]")
        return True
    except Exception as e:
        console.print(f"[yellow]Warning: Validation error: {e} — saving without validation[/yellow]")
        return True


# ─── DISPLAY ────────────────────────────────────────────────────────────────

def display_config():
    """Pretty-print current config."""
    cfg = load_config()
    if not cfg or cfg == _DEFAULT_CONFIG:
        console.print("[yellow]No configuration found. Run 'slave-cp init'.[/yellow]")
        return

    console.print("\n[bold cyan]Current Configuration:[/bold cyan]\n")
    console.print(f"[green]Workspace:[/green] {cfg.get('workspace') or 'Not set'}")
    console.print(f"[green]Default Language:[/green] {cfg.get('language', 'Not set')}\n")

    cf = cfg.get('codeforces', {})
    if cf.get('handle'):
        console.print(f"[green]Codeforces Handle:[/green] {cf['handle']}")
        console.print(f"[green]Codeforces Password:[/green] {'*' * len(cf.get('password') or '')}")
    else:
        console.print("[yellow]Codeforces: Not configured[/yellow]")

    console.print()
    cc = cfg.get('codechef', {})
    if cc.get('handle'):
        console.print(f"[green]CodeChef Handle:[/green] {cc['handle']}")
        console.print(f"[green]CodeChef Password:[/green] {'*' * len(cc.get('password') or '')}")
    else:
        console.print("[yellow]CodeChef: Not configured[/yellow]")
    console.print()