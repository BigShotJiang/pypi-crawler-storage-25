# Changelog

## 1.2.0b2

-   Updated Cof Box Fundamental samples that adds visualization for
    \"Run a CofBox analysis\" step
-   Added `x-ap-sdk-operation` and changed User Agent in request headers
    to support Telemetry

## 1.2.0b1

-   Added new functions `get_benchmarks`, `get_factors`, `get_esg` and
    `validate_instruments` to module `basket_scan` for Basket Scan API
-   Support Telemetry in request headers

## 1.1.0b1

-   Added new functions `create_basket`, `update_basket` and
    `delete_basket` to module `basket_scan` for Basket Scan API
-   Added new modules `curve_follower`, `fx_event_tracker`,
    `sustainable_bond_screener`, `market_data`, `cof_box` for new APIs

## 1.0.0

-   Initial version SDK to support Societe Generale Basket Scan API
