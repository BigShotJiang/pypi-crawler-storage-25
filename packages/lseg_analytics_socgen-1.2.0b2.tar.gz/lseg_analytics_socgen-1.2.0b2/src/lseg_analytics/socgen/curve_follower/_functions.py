import copy
import datetime
from typing import Any, Iterator, Literal, Optional, Union

from lseg_analytics.core.common._resource_base import ResourceBase
from lseg_analytics.core.exceptions import (
    LibraryException,
    ResourceNotFound,
    check_exception_and_raise,
    check_id,
)

from lseg_analytics.socgen._basic_client.models import (
    ClosestStrategiesResponse,
    ClosestStrategiesResponseStrategies1,
    ClosestStrategyDto,
    CurveDto,
    CustomStrategyCoupleRequest,
    CustomStrategyCoupleRequestRegressionResponse,
    CustomStrategyCoupleRequestRegressionStrategyCoupleDto,
    GetCurvesResponse,
    HedgeStrategyCoupleRequest,
    HedgingSimulationResponse,
    HedgingSimulationStrategyCoupleDto,
    RatePointDto,
    RatesAndClosestStrategiesAndRegressionRequest,
    RatesAndClosestStrategiesAndRegressionResponse,
    RatesResponse,
    RateStrategyDto,
    RegressionPointDto,
    StrategyInstrumentRequest,
    StrategyRequest,
)
from lseg_analytics.socgen._client.client import Client

from ._logger import logger

__all__ = [
    "ClosestStrategiesResponse",
    "ClosestStrategiesResponseStrategies1",
    "ClosestStrategyDto",
    "CurveDto",
    "CustomStrategyCoupleRequest",
    "CustomStrategyCoupleRequestRegressionResponse",
    "CustomStrategyCoupleRequestRegressionStrategyCoupleDto",
    "GetCurvesResponse",
    "HedgeStrategyCoupleRequest",
    "HedgingSimulationResponse",
    "HedgingSimulationStrategyCoupleDto",
    "RatePointDto",
    "RateStrategyDto",
    "RatesAndClosestStrategiesAndRegressionResponse",
    "RatesResponse",
    "RegressionPointDto",
    "StrategyInstrumentRequest",
    "StrategyRequest",
    "compute_historical_rates_and_regression_indicators",
    "list_curves",
]


def compute_historical_rates_and_regression_indicators(
    *,
    strategy: Optional[StrategyRequest] = None,
    regression_curve: Optional[str] = None,
    start_date: Optional[datetime.datetime] = None,
    end_date: Optional[datetime.datetime] = None,
    top: Optional[int] = None,
    place: Optional[str] = None,
    indicators: Optional[list[str]] = None,
    regression_indicators: Optional[list[str]] = None,
    nominal: Optional[float] = None,
) -> RatesAndClosestStrategiesAndRegressionResponse:
    """
    Compute historical rates and regression indicators between main strategy and top basic ones.

    Parameters
    ----------
    strategy : StrategyRequest, optional

    regression_curve : str, optional

    start_date : datetime.datetime, optional
        An instant in coordinated universal time (UTC)"
    end_date : datetime.datetime, optional
        An instant in coordinated universal time (UTC)"
    top : int, optional

    place : str, optional

    indicators : list[str], optional

    regression_indicators : list[str], optional

    nominal : float, optional
        A 64 bit floating point number. (`±5.0 × 10^−324` to `±1.7 × 10^308`)

    Returns
    --------
    RatesAndClosestStrategiesAndRegressionResponse


    Examples
    --------
    >>> # Define a custom strategy composed of two instruments on the EUR 6M curve
    >>> strategy_definition = {
    >>>     "instruments": [
    >>>         {
    >>>             "leg1": "1Y",
    >>>             "leg2": "2Y",
    >>>             "leg3": "",
    >>>             "forward": "",
    >>>             "duration": "",
    >>>             "curve": "EUR 6M",
    >>>             "weight": -1,
    >>>         }
    >>>     ]
    >>> }
    >>>
    >>> historical_rates = compute_historical_rates_and_regression_indicators(
    >>>     strategy=strategy_definition,
    >>>     regression_curve="EUR 6M",
    >>>     start_date="2026-01-02",
    >>>     end_date="2026-01-27",
    >>>     top=1,
    >>>     place="EUROPE",
    >>>     indicators=["RATE"],
    >>>     regression_indicators=[
    >>>         "ZSCORE"
    >>>     ],
    >>>     nominal=25000000,
    >>> )
    >>>
    >>> print(json.dumps(historical_rates.as_dict().get("closestStrategies"), indent=4))
    {
        "strategies": {
            "swap": [
                {
                    "curve": "EUR 6M",
                    "leg1": "5Y",
                    "alpha": 0.9161309111220503,
                    "beta": -0.3898444142786819,
                    "r2": 0.7536295646091974,
                    "zScore": 15.164251832084105
                }
            ],
            "spread": [
                {
                    "curve": "EUR 6M",
                    "leg1": "1Y",
                    "leg2": "5Y",
                    "alpha": 0.07731564299991385,
                    "beta": -0.41377726245964536,
                    "r2": 0.8209297093899227,
                    "zScore": -18.335895521037404
                }
            ],
            "butterfly": [
                {
                    "curve": "EUR 6M",
                    "leg1": "1Y",
                    "leg2": "5Y",
                    "leg3": "10Y",
                    "alpha": -0.060254534476503384,
                    "beta": -0.5914748489703783,
                    "r2": 0.7903529228337682,
                    "zScore": -10.377188879884834
                }
            ]
        }
    }

    """

    try:
        logger.info("Calling compute_historical_rates_and_regression_indicators")

        response = Client().curve_follower_service.compute_historical_rates_and_regression_indicators(
            body=RatesAndClosestStrategiesAndRegressionRequest(
                strategy=strategy,
                regression_curve=regression_curve,
                start_date=start_date,
                end_date=end_date,
                top=top,
                place=place,
                indicators=indicators,
                regression_indicators=regression_indicators,
                nominal=nominal,
            ),
            content_type="application/json",
            headers={"x-ap-sdk-operation": "curve_follower.compute_historical_rates_and_regression_indicators"},
        )

        output = response
        logger.info("Called compute_historical_rates_and_regression_indicators")

        return output
    except Exception as err:
        logger.error("Error compute_historical_rates_and_regression_indicators.")
        check_exception_and_raise(err, logger)


def list_curves(*, currency: Optional[str] = None) -> GetCurvesResponse:
    """
    List available curves for live pricing and computing the strategies.

    Parameters
    ----------
    currency : str, optional
        A sequence of textual characters.

    Returns
    --------
    GetCurvesResponse


    Examples
    --------
    >>> curves = list_curves(currency="USD")
    >>>
    >>> curve_dict = curves.as_dict()
    >>> curve_list = curve_dict.get('curves', [])
    >>> print(f"Total bonds found: {len(curve_list)}")
    >>>
    >>> # Limit to first few records for display
    >>> limited_response = {'curves': curve_list[:2]}
    >>> print(json.dumps(limited_response, indent=4))
    Total bonds found: 4
    {
        "curves": [
            {
                "type": "IRS",
                "curve": "USD SOFR",
                "referenceRate": "LIBOR SOFR",
                "dv01Curve": "USD SOFR",
                "ticker": "USD SOFR",
                "currency": "USD",
                "availableMaturities": [
                    "1Y",
                    "2Y",
                    "3Y",
                    "4Y",
                    "5Y",
                    "6Y",
                    "7Y",
                    "8Y",
                    "9Y",
                    "10Y",
                    "11Y",
                    "12Y",
                    "13Y",
                    "14Y",
                    "15Y",
                    "16Y",
                    "17Y",
                    "18Y",
                    "19Y",
                    "20Y",
                    "21Y",
                    "22Y",
                    "23Y",
                    "24Y",
                    "25Y",
                    "26Y",
                    "27Y",
                    "28Y",
                    "29Y",
                    "30Y"
                ],
                "availablePlaces": [
                    "EUROPE",
                    "ASIA",
                    "US"
                ],
                "defaultPlace": "US",
                "isDefault": false,
                "minDate": "2021-03-31T00:00:00Z",
                "maxDate": "2026-04-21T00:00:00Z"
            },
            {
                "type": "IRS",
                "curve": "USD OIS",
                "referenceRate": "LIBOR OIS",
                "dv01Curve": "USD OIS",
                "ticker": "USD OIS",
                "currency": "USD",
                "availableMaturities": [
                    "1Y",
                    "2Y",
                    "3Y",
                    "4Y",
                    "5Y",
                    "6Y",
                    "7Y",
                    "8Y",
                    "9Y",
                    "10Y",
                    "11Y",
                    "12Y",
                    "13Y",
                    "14Y",
                    "15Y",
                    "16Y",
                    "17Y",
                    "18Y",
                    "19Y",
                    "20Y",
                    "21Y",
                    "22Y",
                    "23Y",
                    "24Y",
                    "25Y",
                    "26Y",
                    "27Y",
                    "28Y",
                    "29Y",
                    "30Y"
                ],
                "availablePlaces": [
                    "EUROPE",
                    "ASIA",
                    "US"
                ],
                "defaultPlace": "US",
                "isDefault": false,
                "minDate": "2008-06-23T00:00:00Z",
                "maxDate": "2026-04-21T00:00:00Z"
            }
        ]
    }

    """

    try:
        logger.info("Calling list_curves")

        response = Client().curve_follower_service.list_curves(
            currency=currency,
            headers={"x-ap-sdk-operation": "curve_follower.list_curves"},
        )

        output = response
        logger.info("Called list_curves")

        return output
    except Exception as err:
        logger.error("Error list_curves.")
        check_exception_and_raise(err, logger)
