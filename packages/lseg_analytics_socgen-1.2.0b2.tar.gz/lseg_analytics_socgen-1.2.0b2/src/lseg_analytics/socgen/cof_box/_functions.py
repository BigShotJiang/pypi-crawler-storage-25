import copy
import datetime
from typing import Any, Iterator, Literal, Optional, Union

from lseg_analytics.core.common._resource_base import ResourceBase
from lseg_analytics.core.exceptions import (
    LibraryException,
    ResourceNotFound,
    check_exception_and_raise,
    check_id,
)

from lseg_analytics.socgen._basic_client.models import (
    AnalysisRequest,
    AnalysisRequestInstrument,
    AnalysisType,
    CofType,
)
from lseg_analytics.socgen._client.client import Client

from ._logger import logger

__all__ = [
    "AnalysisRequestInstrument",
    "AnalysisType",
    "CofType",
    "get_analysis_types",
    "get_instruments",
    "get_instruments_details",
    "get_instruments_search",
    "post_analysis",
]


def get_analysis_types() -> dict[str, Any]:
    """
    List possible analyses types. See 'analysis' for detail.

    Parameters
    ----------


    Returns
    --------
    dict[str, Any]


    Examples
    --------
    >>> analysis_types = get_analysis_types()
    >>>
    >>> print(json.dumps(analysis_types, indent=4))
    {
        "analysisTypes": [
            "Cof",
            "FwdCof",
            "RollDownCof"
        ]
    }

    """

    try:
        logger.info("Calling get_analysis_types")

        response = Client().cof_box_service.get_analysis_types(
            headers={"x-ap-sdk-operation": "cof_box.get_analysis_types"}
        )

        output = response
        logger.info("Called get_analysis_types")

        return output
    except Exception as err:
        logger.error("Error get_analysis_types.")
        check_exception_and_raise(err, logger)


def get_instruments(*, instrument_codes: Optional[list[str]] = None) -> dict[str, Any]:
    """
    List the instruments available with their properties: currency, reference rate, underlying.

    Parameters
    ----------
    instrument_codes : list[str], optional
        Filter by instruments codes (all returned if not specified).

    Returns
    --------
    dict[str, Any]


    Examples
    --------
    >>> instruments_response = get_instruments()
    >>>
    >>> instruments = instruments_response.get("instruments", [])
    >>>
    >>> print(json.dumps({"instruments": instruments[:5]}, indent=4))
    {
        "instruments": [
            {
                "instrumentCode": "AEX_EUR_E3M",
                "instrumentLabel": "AEX - EUR - E3M",
                "instrumentEndDate": null,
                "currency": "EUR",
                "referenceRate": "EURIBOR",
                "underlyingType": "I",
                "underlyingCode": "AEX",
                "underlyingLabel": "AEX-Index",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": false,
                "isInternal": false
            },
            {
                "instrumentCode": "AEX_EUR_EON",
                "instrumentLabel": "AEX - ESTR",
                "instrumentEndDate": null,
                "currency": "EUR",
                "referenceRate": "EST",
                "underlyingType": "I",
                "underlyingCode": "AEX",
                "underlyingLabel": "AEX-Index",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": true,
                "isInternal": false
            },
            {
                "instrumentCode": "AEX_JPY_OIS",
                "instrumentLabel": "AEX - JPYOIS",
                "instrumentEndDate": null,
                "currency": "JPY",
                "referenceRate": "TONAR",
                "underlyingType": "I",
                "underlyingCode": "AEX",
                "underlyingLabel": "AEX-Index",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": false,
                "isInternal": false
            },
            {
                "instrumentCode": "AEX_USD_OIS",
                "instrumentLabel": "AEX - USD - FF",
                "instrumentEndDate": null,
                "currency": "USD",
                "referenceRate": "FEDFUNDS",
                "underlyingType": "I",
                "underlyingCode": "AEX",
                "underlyingLabel": "AEX-Index",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": false,
                "isInternal": false
            },
            {
                "instrumentCode": "AEX_USD_SOFR",
                "instrumentLabel": "AEX - USD - SOFR",
                "instrumentEndDate": null,
                "currency": "USD",
                "referenceRate": "SOF",
                "underlyingType": "I",
                "underlyingCode": "AEX",
                "underlyingLabel": "AEX-Index",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": false,
                "isInternal": false
            }
        ]
    }

    """

    try:
        logger.info("Calling get_instruments")

        response = Client().cof_box_service.get_instruments(
            instrument_codes=instrument_codes,
            headers={"x-ap-sdk-operation": "cof_box.get_instruments"},
        )

        output = response
        logger.info("Called get_instruments")

        return output
    except Exception as err:
        logger.error("Error get_instruments.")
        check_exception_and_raise(err, logger)


def get_instruments_details(
    *, instrument_codes: Optional[list[str]] = None, as_of_date: Optional[datetime.datetime] = None
) -> dict[str, Any]:
    """
    List the maturities available for some instruments at a specific time (today by default), giving detail on the type of maturity (1 year rolling, next listed maturity, etc.).

    Parameters
    ----------
    instrument_codes : list[str], optional
        List of instruments codes.
    as_of_date : datetime.datetime, optional
        Specify a date for the maturities (max date for each instrument used if not specified).

    Returns
    --------
    dict[str, Any]


    Examples
    --------
    >>> instruments_details_response = get_instruments_details(instrument_codes=["SX5E_EUR_EON"])
    >>>
    >>> print(json.dumps(instruments_details_response, indent=4))
    {
        "instruments": [
            {
                "instrumentCode": "SX5E_EUR_EON",
                "minDate": "2015-01-02",
                "maxDate": "2026-04-22",
                "availableMaturities": [
                    {
                        "maturityLabel": "E1",
                        "maturityType": "LISTED",
                        "maturityDate": "2026-06-19"
                    },
                    {
                        "maturityLabel": "3M",
                        "maturityType": "ROLLING",
                        "maturityDate": "2026-07-22"
                    },
                    {
                        "maturityLabel": "E2",
                        "maturityType": "LISTED",
                        "maturityDate": "2026-09-18"
                    },
                    {
                        "maturityLabel": "6M",
                        "maturityType": "ROLLING",
                        "maturityDate": "2026-10-22"
                    },
                    {
                        "maturityLabel": "E3",
                        "maturityType": "LISTED",
                        "maturityDate": "2026-12-18"
                    },
                    {
                        "maturityLabel": "Y1",
                        "maturityType": "LISTED",
                        "maturityDate": "2026-12-18"
                    },
                    {
                        "maturityLabel": "9M",
                        "maturityType": "ROLLING",
                        "maturityDate": "2027-01-22"
                    },
                    {
                        "maturityLabel": "EY1",
                        "maturityType": "LISTED",
                        "maturityDate": "2027-03-19"
                    },
                    {
                        "maturityLabel": "1Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2027-04-22"
                    },
                    {
                        "maturityLabel": "Y2",
                        "maturityType": "LISTED",
                        "maturityDate": "2027-12-17"
                    },
                    {
                        "maturityLabel": "EY2",
                        "maturityType": "LISTED",
                        "maturityDate": "2028-03-17"
                    },
                    {
                        "maturityLabel": "2Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2028-04-22"
                    },
                    {
                        "maturityLabel": "Y3",
                        "maturityType": "LISTED",
                        "maturityDate": "2028-12-15"
                    },
                    {
                        "maturityLabel": "EY3",
                        "maturityType": "LISTED",
                        "maturityDate": "2029-03-16"
                    },
                    {
                        "maturityLabel": "3Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2029-04-22"
                    },
                    {
                        "maturityLabel": "Y4",
                        "maturityType": "LISTED",
                        "maturityDate": "2029-12-21"
                    },
                    {
                        "maturityLabel": "4Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2030-04-22"
                    },
                    {
                        "maturityLabel": "Y5",
                        "maturityType": "LISTED",
                        "maturityDate": "2030-12-20"
                    },
                    {
                        "maturityLabel": "5Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2031-04-22"
                    },
                    {
                        "maturityLabel": "Y6",
                        "maturityType": "LISTED",
                        "maturityDate": "2031-12-19"
                    },
                    {
                        "maturityLabel": "6Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2032-04-22"
                    },
                    {
                        "maturityLabel": "Y7",
                        "maturityType": "LISTED",
                        "maturityDate": "2032-12-17"
                    },
                    {
                        "maturityLabel": "7Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2033-04-22"
                    },
                    {
                        "maturityLabel": "Y8",
                        "maturityType": "LISTED",
                        "maturityDate": "2033-12-16"
                    },
                    {
                        "maturityLabel": "8Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2034-04-22"
                    },
                    {
                        "maturityLabel": "Y9",
                        "maturityType": "LISTED",
                        "maturityDate": "2034-12-15"
                    },
                    {
                        "maturityLabel": "9Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2035-04-22"
                    },
                    {
                        "maturityLabel": "Y10",
                        "maturityType": "LISTED",
                        "maturityDate": "2035-12-21"
                    },
                    {
                        "maturityLabel": "10Y",
                        "maturityType": "ROLLING",
                        "maturityDate": "2036-04-22"
                    }
                ]
            }
        ]
    }

    """

    try:
        logger.info("Calling get_instruments_details")

        response = Client().cof_box_service.get_instruments_details(
            instrument_codes=instrument_codes,
            as_of_date=as_of_date,
            headers={"x-ap-sdk-operation": "cof_box.get_instruments_details"},
        )

        output = response
        logger.info("Called get_instruments_details")

        return output
    except Exception as err:
        logger.error("Error get_instruments_details.")
        check_exception_and_raise(err, logger)


def get_instruments_search(
    *, underlying_code: Optional[str] = None, currency: Optional[str] = None, reference_rate: Optional[str] = None
) -> dict[str, Any]:
    """
    Search of instruments

    Parameters
    ----------
    underlying_code : str, optional
        Specify an underlying code (optional).
    currency : str, optional
        Specify an instrument currency (optional).
    reference_rate : str, optional
        Specify a reference rate (optional).

    Returns
    --------
    dict[str, Any]


    Examples
    --------
    >>> instruments_search_response = get_instruments_search(currency="EUR")
    >>>
    >>> instruments_search = instruments_search_response.get("instruments", [])
    >>>
    >>> print(json.dumps({"instruments": instruments_search[:5]}, indent=4))
    {
        "instruments": [
            {
                "instrumentCode": "AEX_EUR_E3M",
                "instrumentLabel": "AEX - EUR - E3M",
                "instrumentEndDate": null,
                "currency": "EUR",
                "referenceRate": "EURIBOR",
                "underlyingType": "I",
                "underlyingCode": "AEX",
                "underlyingLabel": "AEX-Index",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": false,
                "isInternal": false
            },
            {
                "instrumentCode": "AEX_EUR_EON",
                "instrumentLabel": "AEX - ESTR",
                "instrumentEndDate": null,
                "currency": "EUR",
                "referenceRate": "EST",
                "underlyingType": "I",
                "underlyingCode": "AEX",
                "underlyingLabel": "AEX-Index",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": true,
                "isInternal": false
            },
            {
                "instrumentCode": "AS51_EUR_EON",
                "instrumentLabel": "AS51 - ESTR",
                "instrumentEndDate": null,
                "currency": "EUR",
                "referenceRate": "EST",
                "underlyingType": "I",
                "underlyingCode": "AS51",
                "underlyingLabel": "S&P/ASX 200",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "APAC",
                "underlyingCcy": "AUD",
                "isDefault": false,
                "isInternal": false
            },
            {
                "instrumentCode": "CAC_EUR_E3M",
                "instrumentLabel": "CAC - EUR - E3M",
                "instrumentEndDate": null,
                "currency": "EUR",
                "referenceRate": "EURIBOR",
                "underlyingType": "I",
                "underlyingCode": "CAC",
                "underlyingLabel": "CAC 40",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": false,
                "isInternal": false
            },
            {
                "instrumentCode": "CAC_EUR_EON",
                "instrumentLabel": "CAC - ESTR",
                "instrumentEndDate": null,
                "currency": "EUR",
                "referenceRate": "EST",
                "underlyingType": "I",
                "underlyingCode": "CAC",
                "underlyingLabel": "CAC 40",
                "underlyingAssetClass": "EQUITY",
                "underlyingRegion": "EMEA",
                "underlyingCcy": "EUR",
                "isDefault": true,
                "isInternal": false
            }
        ]
    }

    """

    try:
        logger.info("Calling get_instruments_search")

        response = Client().cof_box_service.get_instruments_search(
            underlying_code=underlying_code,
            currency=currency,
            reference_rate=reference_rate,
            headers={"x-ap-sdk-operation": "cof_box.get_instruments_search"},
        )

        output = response
        logger.info("Called get_instruments_search")

        return output
    except Exception as err:
        logger.error("Error get_instruments_search.")
        check_exception_and_raise(err, logger)


def post_analysis(
    *,
    instruments: list[AnalysisRequestInstrument],
    analysis_types: Optional[list[Union[str, AnalysisType]]] = None,
    start_date: Optional[datetime.datetime] = None,
    end_date: Optional[datetime.datetime] = None,
    cof_types: Optional[list[Union[str, CofType]]] = None,
    min_update_timestamp_utc: Optional[datetime.datetime] = None,
) -> dict[str, Any]:
    """
    Runs a list of analysis.

    Parameters
    ----------
    analysis_types : list[Union[str, AnalysisType]], optional
        Analysis results requested (all analysis returned if none specified). Available analysis are:<br />
        - <b>Cof</b>: TBD.<br />
        - <b>FwdCof</b>: TBD.<br />
        - <b>RollDownCof</b>: TBD.
    instruments : list[AnalysisRequestInstrument]
        The instruments to analyse.
    start_date : datetime.datetime, optional
        The start date.
    end_date : datetime.datetime, optional
        The end date.
    cof_types : list[Union[str, CofType]], optional
        The Cof types ('CofDiv100pct' by default or/and 'CofDivMarket', 'CofDivNtr).
    min_update_timestamp_utc : datetime.datetime, optional
        Minimum UpdateTimestamp (Utc) Format : yyyy-MM-ddTHH:mm:ssZ.

    Returns
    --------
    dict[str, Any]


    Examples
    --------
    >>> maturity_list = ["3M","6M","9M","1Y","3Y","6Y","10Y"]
    >>>
    >>> post_analysis_response = post_analysis(
    >>>     instruments=[{
    >>>         "instrumentCode": "SX5E_EUR_EON",
    >>>         "maturitiesCodes": maturity_list,
    >>>     }],
    >>>     analysis_types=["Cof", "FwdCof", "RollDownCof"],
    >>>     start_date="2026-01-01",
    >>>     end_date="2026-01-10",
    >>>     cof_types=["CofDiv100pct", "CofDivMarket"],
    >>> )
    >>>
    >>> print("Top-level keys:", post_analysis_response["instruments"][0].keys())
    >>> print("cof blocks:", len(post_analysis_response["instruments"][0].get("cof", [])))
    >>> print("fwdCof blocks:", len(post_analysis_response["instruments"][0].get("fwdCof", [])))
    >>> print("rollDownCof blocks:", len(post_analysis_response["instruments"][0].get("rollDownCof", [])))
    Top-level keys: dict_keys(['instrumentCode', 'previousDateWithData', 'cof', 'fwdCof', 'rollDownCof'])
    cof blocks: 6
    fwdCof blocks: 6
    rollDownCof blocks: 6

    """

    try:
        logger.info("Calling post_analysis")

        response = Client().cof_box_service.post_analysis(
            body=AnalysisRequest(
                analysis_types=analysis_types,
                instruments=instruments,
                start_date=start_date,
                end_date=end_date,
                cof_types=cof_types,
                min_update_timestamp_utc=min_update_timestamp_utc,
            ),
            content_type="application/json",
            headers={"x-ap-sdk-operation": "cof_box.post_analysis"},
        )

        output = response
        logger.info("Called post_analysis")

        return output
    except Exception as err:
        logger.error("Error post_analysis.")
        check_exception_and_raise(err, logger)
