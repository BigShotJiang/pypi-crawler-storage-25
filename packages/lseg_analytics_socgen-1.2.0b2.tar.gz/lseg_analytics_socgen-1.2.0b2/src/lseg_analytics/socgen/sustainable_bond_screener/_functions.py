import copy
import datetime
from typing import Any, Iterator, Literal, Optional, Union

from lseg_analytics.core.common._resource_base import ResourceBase
from lseg_analytics.core.exceptions import (
    LibraryException,
    ResourceNotFound,
    check_exception_and_raise,
    check_id,
)

from lseg_analytics.socgen._basic_client.models import (
    BondType,
    BoundResponse,
    CalculationMethod,
    Category,
    GetSustainableBondsResponse,
    HistoricalDataDto,
    HistoricalDataRequest,
    PostHistoricalDataResponse,
    SustainableBondResponse,
)
from lseg_analytics.socgen._client.client import Client

from ._logger import logger

__all__ = [
    "BondType",
    "BoundResponse",
    "CalculationMethod",
    "Category",
    "GetSustainableBondsResponse",
    "HistoricalDataDto",
    "PostHistoricalDataResponse",
    "SustainableBondResponse",
    "get_historical_data",
    "get_sustainable_bonds",
]


def get_historical_data(
    *, isins: list[str], start_date: Optional[datetime.datetime] = None, end_date: Optional[datetime.datetime] = None
) -> PostHistoricalDataResponse:
    """
    Historical data

    Parameters
    ----------
    isins : list[str]

    start_date : datetime.datetime, optional
        An instant in coordinated universal time (UTC)"
    end_date : datetime.datetime, optional


    Returns
    --------
    PostHistoricalDataResponse


    Examples
    --------
    >>> response = get_historical_data(
    >>>     isins=["DE0001030732"],
    >>>     start_date="2024-01-20",
    >>>     end_date="2025-12-31",
    >>> ).as_dict()
    >>>
    >>> data = response.get('historicalData', {})
    >>> limited = {isin: records[:10] for isin, records in data.items()}
    >>> for isin, records in data.items():
    >>>     print(f"ISIN {isin}: {len(records)} total records, showing first {min(10, len(records))}")
    >>> print(json.dumps({'historicalData': limited}, indent=4))
    ISIN DE0001030732: 712 total records, showing first 10
    {
        "historicalData": {
            "DE0001030732": [
                {
                    "date": "2024-01-20",
                    "zSpread": -47.098,
                    "lowerBoundZSpread": -46.016,
                    "upperBoundZSpread": -46.016,
                    "zSpreadComparable": -46.016,
                    "greenium": -1.0820000000000007
                },
                {
                    "date": "2024-01-21",
                    "zSpread": -47.098,
                    "lowerBoundZSpread": -46.016,
                    "upperBoundZSpread": -46.016,
                    "zSpreadComparable": -46.016,
                    "greenium": -1.0820000000000007
                },
                {
                    "date": "2024-01-22",
                    "zSpread": -47.935,
                    "lowerBoundZSpread": -46.887,
                    "upperBoundZSpread": -46.887,
                    "zSpreadComparable": -46.887,
                    "greenium": -1.0480000000000018
                },
                {
                    "date": "2024-01-23",
                    "zSpread": -48.164,
                    "lowerBoundZSpread": -47.112,
                    "upperBoundZSpread": -47.112,
                    "zSpreadComparable": -47.112,
                    "greenium": -1.0519999999999996
                },
                {
                    "date": "2024-01-24",
                    "zSpread": -47.395,
                    "lowerBoundZSpread": -46.343,
                    "upperBoundZSpread": -46.343,
                    "zSpreadComparable": -46.343,
                    "greenium": -1.0519999999999996
                },
                {
                    "date": "2024-01-25",
                    "zSpread": -47.78,
                    "lowerBoundZSpread": -46.753,
                    "upperBoundZSpread": -46.753,
                    "zSpreadComparable": -46.753,
                    "greenium": -1.027000000000001
                },
                {
                    "date": "2024-01-26",
                    "zSpread": -47.309,
                    "lowerBoundZSpread": -46.258,
                    "upperBoundZSpread": -46.258,
                    "zSpreadComparable": -46.258,
                    "greenium": -1.0509999999999948
                },
                {
                    "date": "2024-01-27",
                    "zSpread": -47.309,
                    "lowerBoundZSpread": -46.258,
                    "upperBoundZSpread": -46.258,
                    "zSpreadComparable": -46.258,
                    "greenium": -1.0509999999999948
                },
                {
                    "date": "2024-01-28",
                    "zSpread": -47.309,
                    "lowerBoundZSpread": -46.258,
                    "upperBoundZSpread": -46.258,
                    "zSpreadComparable": -46.258,
                    "greenium": -1.0509999999999948
                },
                {
                    "date": "2024-01-29",
                    "zSpread": -48.078,
                    "lowerBoundZSpread": -47.032,
                    "upperBoundZSpread": -47.032,
                    "zSpreadComparable": -47.032,
                    "greenium": -1.0460000000000065
                }
            ]
        }
    }

    """

    try:
        logger.info("Calling get_historical_data")

        response = Client().sustainable_bond_screener_service.get_historical_data(
            body=HistoricalDataRequest(isins=isins, start_date=start_date, end_date=end_date),
            content_type="application/json",
            headers={"x-ap-sdk-operation": "sustainable_bond_screener.get_historical_data"},
        )

        output = response
        logger.info("Called get_historical_data")

        return output
    except Exception as err:
        logger.error("Error get_historical_data.")
        check_exception_and_raise(err, logger)


def get_sustainable_bonds() -> GetSustainableBondsResponse:
    """


    Parameters
    ----------


    Returns
    --------
    GetSustainableBondsResponse


    Examples
    --------
    >>> get_sustainable_bonds_response = get_sustainable_bonds()
    >>>
    >>> response_dict = get_sustainable_bonds_response.as_dict()
    >>>
    >>> bonds_list = response_dict.get('sustainableBonds', [])
    >>> print(f"Total bonds found: {len(bonds_list)}")
    >>>
    >>> # Limit to first few records for display
    >>> limited_response = {'sustainableBonds': bonds_list[:3]}
    >>> print(json.dumps(limited_response, indent=4))
    Total bonds found: 1326
    {
        "sustainableBonds": [
            {
                "isin": "XS3286502821",
                "name": "NATIONAL GRID ELECTRICITY TRANSMISSION PLC",
                "ticker": "NGGLN",
                "currency": "EUR",
                "country": "UNITED KINGDOM",
                "region": "EMEA",
                "maturity": "2034-02-03",
                "issueDate": "2026-02-03",
                "zSpread": 74.127,
                "amountOutstanding": 650000000.0,
                "lowerBound": null,
                "upperBound": null,
                "calculationMethod": "None",
                "zSpreadComparable": null,
                "greenium": null,
                "coupon": 3.563,
                "seniority": "Sr Unsecured",
                "duration": 6.88,
                "category": "CorporatesAndFinancials"
            },
            {
                "isin": "XS3291116955",
                "name": "ING GROEP NV",
                "ticker": "INTNED",
                "currency": "EUR",
                "country": "NETHERLANDS",
                "region": "EMEA",
                "maturity": "2032-02-10",
                "issueDate": "2026-02-10",
                "zSpread": 72.343,
                "amountOutstanding": 1250000000.0,
                "lowerBound": {
                    "isin": "XS3002547563",
                    "maturity": "2031-08-17",
                    "zSpread": 65.601
                },
                "upperBound": {
                    "isin": "XS2554745708",
                    "maturity": "2033-11-14",
                    "zSpread": 80.321
                },
                "calculationMethod": "Interpolation",
                "zSpreadComparable": 69.9212972136223,
                "greenium": 2.4217027863777076,
                "coupon": 3.125,
                "seniority": "Sr Unsecured",
                "duration": 4.506,
                "category": "CorporatesAndFinancials"
            },
            {
                "isin": "XS3303714045",
                "name": "NATWEST GROUP PLC",
                "ticker": "NWG",
                "currency": "EUR",
                "country": "UNITED KINGDOM",
                "region": "EMEA",
                "maturity": "2037-02-25",
                "issueDate": "2026-02-25",
                "zSpread": 90.993,
                "amountOutstanding": 750000000.0,
                "lowerBound": {
                    "isin": "XS3170277704",
                    "maturity": "2034-09-03",
                    "zSpread": 87.302
                },
                "upperBound": null,
                "calculationMethod": "Extrapolation",
                "zSpreadComparable": 93.64294507768793,
                "greenium": -2.6499450776879314,
                "coupon": 3.756,
                "seniority": "Sr Unsecured",
                "duration": 8.351,
                "category": "CorporatesAndFinancials"
            }
        ]
    }

    """

    try:
        logger.info("Calling get_sustainable_bonds")

        response = Client().sustainable_bond_screener_service.get_sustainable_bonds(
            headers={"x-ap-sdk-operation": "sustainable_bond_screener.get_sustainable_bonds"}
        )

        output = response
        logger.info("Called get_sustainable_bonds")

        return output
    except Exception as err:
        logger.error("Error get_sustainable_bonds.")
        check_exception_and_raise(err, logger)
