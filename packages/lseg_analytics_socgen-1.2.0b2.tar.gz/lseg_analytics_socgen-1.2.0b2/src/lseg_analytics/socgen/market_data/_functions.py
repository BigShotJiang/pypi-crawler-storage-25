import copy
import datetime
from typing import Any, Iterator, Literal, Optional, Union

from lseg_analytics.core.common._resource_base import ResourceBase
from lseg_analytics.core.exceptions import (
    LibraryException,
    ResourceNotFound,
    check_exception_and_raise,
    check_id,
)

from lseg_analytics.socgen._basic_client.models import (
    Component,
    DataType,
    FieldDescription,
    FieldValue,
    InstrumentsFieldsValuesSortOrder,
    LastQuotesByConstraintsRequest,
    LastQuotesRequest,
    ListSourceResponse,
    LiveQuote,
    LiveQuotesRequest,
    LiveQuotesResponse,
    LiveQuoteValue,
    LookupInstrumentsFieldsValuesRequest,
    LookupInstrumentsFieldsValuesResponse,
    MatchInstrument,
    MissingValuesReason,
    Order,
    ProductDescription,
    Quote,
    QuoteField,
    QuotesByConstraintsResponse,
    QuotesResponse,
    QuotesUpdateRequest,
    QuoteUpdate,
    QuoteUpdates,
    QuoteUpdatesResponse,
    QuoteValue,
    RangeQuotesByConstraintsRequest,
    RangeQuotesRequest,
    RefsetDescription,
    SearchInclude,
    SearchInstrumentsRequest,
    SearchInstrumentsResponse,
    SnapshotQuotesByConstraintsRequest,
    SnapshotQuotesRequest,
    SortCriterion,
    SourceDescription,
    SubField,
)
from lseg_analytics.socgen._client.client import Client

from ._logger import logger

__all__ = [
    "Component",
    "DataType",
    "FieldDescription",
    "FieldValue",
    "InstrumentsFieldsValuesSortOrder",
    "LastQuotesByConstraintsRequest",
    "LastQuotesRequest",
    "ListSourceResponse",
    "LiveQuote",
    "LiveQuoteValue",
    "LiveQuotesResponse",
    "LookupInstrumentsFieldsValuesResponse",
    "MatchInstrument",
    "MissingValuesReason",
    "Order",
    "ProductDescription",
    "Quote",
    "QuoteField",
    "QuoteUpdate",
    "QuoteUpdates",
    "QuoteUpdatesResponse",
    "QuoteValue",
    "QuotesByConstraintsResponse",
    "QuotesResponse",
    "RangeQuotesByConstraintsRequest",
    "RangeQuotesRequest",
    "RefsetDescription",
    "SearchInclude",
    "SearchInstrumentsResponse",
    "SnapshotQuotesByConstraintsRequest",
    "SnapshotQuotesRequest",
    "SortCriterion",
    "SourceDescription",
    "SubField",
    "data_catalog_describe_all_sources",
    "data_catalog_describe_products_by_source",
    "data_catalog_describe_single_product_by_source",
    "explorer_lookup_instruments_fields_values",
    "explorer_search_instruments_by_constraints",
    "quotes_query_live_quotes",
    "quotes_query_quote_updates",
    "quotes_query_quotes",
    "quotes_query_quotes_by_constraints",
]


def data_catalog_describe_all_sources() -> ListSourceResponse:
    """
    More details about 'sources' endpoint

    Parameters
    ----------


    Returns
    --------
    ListSourceResponse
        Describe a set of Sources

    Examples
    --------
    >>> data_catalog_sources = data_catalog_describe_all_sources()
    >>>
    >>> # Extract ref_sets from the first product of the first source
    >>> sources = data_catalog_sources.get("sources", [])
    >>> products = sources[0].get("products", []) if sources else []
    >>> ref_sets = products[0].get("refsets") if products else None
    >>>
    >>> ref_sets_dict = [rs.as_dict() if hasattr(rs, 'as_dict') else rs for rs in ref_sets]
    >>>
    >>> print(json.dumps(ref_sets_dict, indent=4))
    >>>
    >>>
    [
        {
            "name": "ASIA 08H30",
            "definition": "Asia 8h30 HK Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "ASIA 15H00",
            "definition": "Asia 15H00 HK Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "ASIA 18H30",
            "definition": "Asia 18h30 HK Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "ASIA CLOSE",
            "definition": "Asia close price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 17H15",
            "definition": "Europe 17H15 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 18H00",
            "definition": "Europe 18H00 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 18H30",
            "definition": "Europe 18H30 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 19H00",
            "definition": "Europe 19H00 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 20H15",
            "definition": "Europe 20H15 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE CLOSE",
            "definition": "Europe close price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE OPEN",
            "definition": "Europe open price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "US 17H00",
            "definition": "US 17H00 Eastern Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "US 18H00",
            "definition": "US 18H00 Eastern Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "US CLOSE",
            "definition": "US close price retrieved from market and enriched by SG trading desk"
        }
    ]

    """

    try:
        logger.info("Calling data_catalog_describe_all_sources")

        response = Client().market_data_service.data_catalog_describe_all_sources(
            headers={"x-ap-sdk-operation": "market_data.data_catalog_describe_all_sources"}
        )

        output = response
        logger.info("Called data_catalog_describe_all_sources")

        return output
    except Exception as err:
        logger.error("Error data_catalog_describe_all_sources.")
        check_exception_and_raise(err, logger)


def data_catalog_describe_products_by_source(*, source_name: str) -> SourceDescription:
    """
    More details about 'sources/{sourceName}/products' endpoint

    Parameters
    ----------
    source_name : str
        A sequence of textual characters.

    Returns
    --------
    SourceDescription
        Describe a Source

    Examples
    --------
    >>> data_catalog_products_by_source = data_catalog_describe_products_by_source(source_name="SG")
    >>>
    >>> data_catalog_products = data_catalog_products_by_source.get("products", []) if data_catalog_products_by_source else []
    >>>
    >>> product = data_catalog_products[:1]
    >>> ref_sets = data_catalog_products[0].get("refsets")
    >>> ref_sets_dict = [rs.as_dict() if hasattr(rs, 'as_dict') else rs for rs in ref_sets]
    >>>
    >>> print(json.dumps(ref_sets_dict, indent=4))
    [
        {
            "name": "ASIA 08H30",
            "definition": "Asia 8h30 HK Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "ASIA 15H00",
            "definition": "Asia 15H00 HK Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "ASIA 18H30",
            "definition": "Asia 18h30 HK Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "ASIA CLOSE",
            "definition": "Asia close price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 17H15",
            "definition": "Europe 17H15 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 18H00",
            "definition": "Europe 18H00 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 18H30",
            "definition": "Europe 18H30 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 19H00",
            "definition": "Europe 19H00 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE 20H15",
            "definition": "Europe 20H15 Paris Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE CLOSE",
            "definition": "Europe close price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "EUROPE OPEN",
            "definition": "Europe open price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "US 17H00",
            "definition": "US 17H00 Eastern Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "US 18H00",
            "definition": "US 18H00 Eastern Time price retrieved from market and enriched by SG trading desk"
        },
        {
            "name": "US CLOSE",
            "definition": "US close price retrieved from market and enriched by SG trading desk"
        }
    ]

    """

    try:
        logger.info("Calling data_catalog_describe_products_by_source")

        response = Client().market_data_service.data_catalog_describe_products_by_source(
            source_name=source_name,
            headers={"x-ap-sdk-operation": "market_data.data_catalog_describe_products_by_source"},
        )

        output = response
        logger.info("Called data_catalog_describe_products_by_source")

        return output
    except Exception as err:
        logger.error("Error data_catalog_describe_products_by_source.")
        check_exception_and_raise(err, logger)


def data_catalog_describe_single_product_by_source(*, source_name: str, product_name: str) -> ProductDescription:
    """
    More details about 'sources/{sourceName}/products/{productName}' endpoint

    Parameters
    ----------
    source_name : str
        A sequence of textual characters.
    product_name : str
        A sequence of textual characters.

    Returns
    --------
    ProductDescription
        Describe a Product

    Examples
    --------
    >>> product_by_name = data_catalog_describe_single_product_by_source(
    >>>     source_name="SG", product_name="Equity"
    >>> )
    >>>
    >>> print(json.dumps(product_by_name.as_dict().get("refsets"), indent=4))
    [
        {
            "name": "ASIA OPEN",
            "definition": "Asia open price contributed by SG trading desk"
        },
        {
            "name": "EUROPE CLOSE",
            "definition": "Official close price on the market and worldwide end of day volatilities computed applying SG models based on SG trading contribution"
        },
        {
            "name": "EUROPE OPEN",
            "definition": "Europe open price contributed by SG trading desk"
        },
        {
            "name": "US OPEN",
            "definition": "US open price contributed by SG trading desk"
        }
    ]

    """

    try:
        logger.info("Calling data_catalog_describe_single_product_by_source")

        response = Client().market_data_service.data_catalog_describe_single_product_by_source(
            source_name=source_name,
            product_name=product_name,
            headers={"x-ap-sdk-operation": "market_data.data_catalog_describe_single_product_by_source"},
        )

        output = response
        logger.info("Called data_catalog_describe_single_product_by_source")

        return output
    except Exception as err:
        logger.error("Error data_catalog_describe_single_product_by_source.")
        check_exception_and_raise(err, logger)


def explorer_lookup_instruments_fields_values(
    *,
    source_name: str,
    field_name: str,
    filter: Optional[str] = None,
    sort: Optional[Union[str, InstrumentsFieldsValuesSortOrder]] = None,
    top: Optional[int] = None,
) -> LookupInstrumentsFieldsValuesResponse:
    """
    You can learn more about the `filter` syntax [here](/data/instruments-filter-syntax.md)

    Parameters
    ----------
    filter : str, optional
        The query describing the instruments you are looking for. [learn more about the syntax](/data/instruments-filter-syntax.md)
    sort : Union[str, InstrumentsFieldsValuesSortOrder], optional

    top : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    source_name : str
        A sequence of textual characters.
    field_name : str
        A sequence of textual characters.

    Returns
    --------
    LookupInstrumentsFieldsValuesResponse


    Examples
    --------
    >>> lookup_instruments_fields_values_response = explorer_lookup_instruments_fields_values(
    >>>     source_name="SG",
    >>>     field_name="ISIN",
    >>>     filter="'PRODUCT NAME' eq 'FOREX' and 'BASE CURRENCY' ctn 'U'",
    >>>     sort="CountDesc",
    >>>     top=10,
    >>> )
    >>>
    >>> print(json.dumps(lookup_instruments_fields_values_response.as_dict(), indent=4))
    {
        "fieldValues": [],
        "totalFieldValues": 0,
        "totalMatchingInstruments": 344
    }

    """

    try:
        logger.info("Calling explorer_lookup_instruments_fields_values")

        response = Client().market_data_service.explorer_lookup_instruments_fields_values(
            body=LookupInstrumentsFieldsValuesRequest(filter=filter, sort=sort, top=top),
            source_name=source_name,
            field_name=field_name,
            headers={"x-ap-sdk-operation": "market_data.explorer_lookup_instruments_fields_values"},
        )

        output = response
        logger.info("Called explorer_lookup_instruments_fields_values")

        return output
    except Exception as err:
        logger.error("Error explorer_lookup_instruments_fields_values.")
        check_exception_and_raise(err, logger)


def explorer_search_instruments_by_constraints(
    *,
    source_name: str,
    search: Optional[str] = None,
    filter: Optional[str] = None,
    page: Optional[int] = None,
    page_size: Optional[int] = None,
    includes: Optional[list[Union[str, SearchInclude]]] = None,
    sort_criteria: Optional[list[SortCriterion]] = None,
) -> SearchInstrumentsResponse:
    """
    You can learn more about the `filter` syntax [here](/data/instruments-filter-syntax.md)

    Parameters
    ----------
    search : str, optional

    filter : str, optional
        The query describing the instruments you are looking for. [learn more about the syntax](/data/instruments-filter-syntax.md)
    page : int, optional
        Page index (1 based)
    page_size : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)
    includes : list[Union[str, SearchInclude]], optional
        Additional properties to include in response
    sort_criteria : list[SortCriterion], optional
        An optional list of sorting criterion. Default to ascending instrument name. Ignored when search is set.
    source_name : str
        A sequence of textual characters.

    Returns
    --------
    SearchInstrumentsResponse


    Examples
    --------
    >>> search_instruments_by_constraints_response = explorer_search_instruments_by_constraints(
    >>>     source_name="SG",
    >>>     search=None,
    >>>     filter="'PRODUCT NAME' eq 'FOREX' and 'BASE CURRENCY' oneof ('EUR')",
    >>>     page=1,
    >>>     page_size=10,
    >>>     includes=None,
    >>>     sort_criteria=[
    >>>         {
    >>>             "field": "DISPLAY NAME",
    >>>             "order": "Asc",
    >>>         }
    >>>     ],
    >>> )
    >>>
    >>> print(json.dumps(search_instruments_by_constraints_response.as_dict(), indent=4))
    {
        "instruments": [
            {
                "instrument": "EURAED"
            },
            {
                "instrument": "EURAFN"
            },
            {
                "instrument": "EURALL"
            },
            {
                "instrument": "EURAMD"
            },
            {
                "instrument": "EURANG"
            },
            {
                "instrument": "EURAOA"
            },
            {
                "instrument": "EURARS"
            },
            {
                "instrument": "EURAUD"
            },
            {
                "instrument": "EURAWG"
            },
            {
                "instrument": "EURAZN"
            }
        ],
        "totalMatchingInstruments": 155
    }

    """

    try:
        logger.info("Calling explorer_search_instruments_by_constraints")

        response = Client().market_data_service.explorer_search_instruments_by_constraints(
            body=SearchInstrumentsRequest(
                search=search,
                filter=filter,
                page=page,
                page_size=page_size,
                includes=includes,
                sort_criteria=sort_criteria,
            ),
            source_name=source_name,
            headers={"x-ap-sdk-operation": "market_data.explorer_search_instruments_by_constraints"},
        )

        output = response
        logger.info("Called explorer_search_instruments_by_constraints")

        return output
    except Exception as err:
        logger.error("Error explorer_search_instruments_by_constraints.")
        check_exception_and_raise(err, logger)


def quotes_query_live_quotes(
    *,
    source_name: str,
    instruments: Optional[list[str]] = None,
    fields: Optional[list[QuoteField]] = None,
    cross_instruments_formulas: Optional[list[str]] = None,
) -> LiveQuotesResponse:
    """


    Parameters
    ----------
    instruments : list[str], optional
        The list of instruments you want to query
    fields : list[QuoteField], optional
        The list of fields you want to query
    cross_instruments_formulas : list[str], optional
        A list of indicators computed over many instruments
    source_name : str
        Only 'SG' are supported for now.

    Returns
    --------
    LiveQuotesResponse


    Examples
    --------
    >>> query_live_quotes_response = quotes_query_live_quotes(
    >>>     source_name="SG",
    >>>     instruments=["EURUSD"],
    >>>     fields=["RATE"],
    >>>     cross_instruments_formulas=None,
    >>> )
    >>>
    >>> print(json.dumps(query_live_quotes_response.as_dict(), indent=4))
    {
        "quotes": [
            {
                "instrument": "EURUSD",
                "field": "RATE",
                "dataType": "Decimal",
                "quoteValue": {
                    "date": "2026-03-23T07:58:32.6839137Z",
                    "value": 1.152685
                }
            }
        ]
    }

    """

    try:
        logger.info("Calling quotes_query_live_quotes")

        response = Client().market_data_service.quotes_query_live_quotes(
            body=LiveQuotesRequest(
                instruments=instruments,
                fields=fields,
                cross_instruments_formulas=cross_instruments_formulas,
            ),
            source_name=source_name,
            headers={"x-ap-sdk-operation": "market_data.quotes_query_live_quotes"},
        )

        output = response
        logger.info("Called quotes_query_live_quotes")

        return output
    except Exception as err:
        logger.error("Error quotes_query_live_quotes.")
        check_exception_and_raise(err, logger)


def quotes_query_quote_updates(
    *,
    source_name: str,
    refset: Optional[str] = None,
    instruments: Optional[list[str]] = None,
    fields: Optional[list[str]] = None,
    start_date: Optional[Union[str, datetime.date]] = None,
    end_date: Optional[Union[str, datetime.date]] = None,
) -> QuoteUpdatesResponse:
    """
    Limited to last month

    Parameters
    ----------
    refset : str, optional
        A sequence of textual characters.
    instruments : list[str], optional

    fields : list[str], optional

    start_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    end_date : Union[str, datetime.date], optional
        A date on a calendar without a time zone, e.g. "April 10th"
    source_name : str
        A sequence of textual characters.

    Returns
    --------
    QuoteUpdatesResponse


    Examples
    --------
    >>> query_quote_updates_response = quotes_query_quote_updates(
    >>>     source_name="SG",
    >>>     refset="EUROPE CLOSE",
    >>>     instruments=
    >>>         [
    >>>             "GLE FP EQUITY",
    >>>         ],
    >>>     fields=[
    >>>         "IV",
    >>>     ],
    >>>     start_date="2025-01-01",
    >>>     end_date="2025-01-22",
    >>> )
    >>>
    >>> print(json.dumps(query_quote_updates_response.as_dict(), indent=4))
    {
        "source": "SG",
        "refset": "EUROPE CLOSE",
        "quotes": []
    }

    """

    try:
        logger.info("Calling quotes_query_quote_updates")

        response = Client().market_data_service.quotes_query_quote_updates(
            body=QuotesUpdateRequest(
                refset=refset,
                instruments=instruments,
                fields=fields,
                start_date=start_date,
                end_date=end_date,
            ),
            source_name=source_name,
            headers={"x-ap-sdk-operation": "market_data.quotes_query_quote_updates"},
        )

        output = response
        logger.info("Called quotes_query_quote_updates")

        return output
    except Exception as err:
        logger.error("Error quotes_query_quote_updates.")
        check_exception_and_raise(err, logger)


def quotes_query_quotes(
    *,
    body: Union[LastQuotesRequest, SnapshotQuotesRequest, RangeQuotesRequest],
    source_name: str,
    accept: Literal["text/csv", "application/json"],
) -> Union[str, QuotesResponse, QuotesByConstraintsResponse]:
    """


    Parameters
    ----------
    body : Union[LastQuotesRequest, SnapshotQuotesRequest, RangeQuotesRequest]

    source_name : str
        A sequence of textual characters.
    accept : Literal["text/csv", "application/json"]
        The desired response content type. Must be one of: "text/csv" | "application/json"

    Returns
    --------
    Union[str, QuotesResponse, QuotesByConstraintsResponse]


    Examples
    --------
    >>> quotes_query_quotes_response = quotes_query_quotes(
    >>>     source_name="SG",
    >>>      body=SnapshotQuotesRequest(
    >>>          fields=[QuoteField(name="RATE")],
    >>>          refset="EUROPE CLOSE",
    >>>          instruments=["EURUSD"]
    >>>          ),
    >>>     accept="application/json")
    >>>
    >>> print(json.dumps(quotes_query_quotes_response.as_dict(), indent=4))
    {
        "source": "SG",
        "refset": "EUROPE CLOSE",
        "quotes": [
            {
                "instrument": "EURUSD",
                "field": "RATE",
                "dataType": "Decimal",
                "isTimeSeries": true,
                "quoteValues": [
                    {
                        "date": "2026-03-20",
                        "value": 1.15576
                    }
                ]
            }
        ]
    }

    """

    try:
        logger.info("Calling quotes_query_quotes")

        response = Client().market_data_service.quotes_query_quotes(
            source_name=source_name,
            headers={
                **{"accept": accept},
                "x-ap-sdk-operation": "market_data.quotes_query_quotes",
            },
            body=body,
        )

        output = response
        logger.info("Called quotes_query_quotes")

        return output
    except Exception as err:
        logger.error("Error quotes_query_quotes.")
        check_exception_and_raise(err, logger)


def quotes_query_quotes_by_constraints(
    *,
    body: Union[
        LastQuotesByConstraintsRequest,
        SnapshotQuotesByConstraintsRequest,
        RangeQuotesByConstraintsRequest,
    ],
    source_name: str,
    accept: Literal["text/csv", "application/json"],
) -> Union[str, QuotesResponse, QuotesByConstraintsResponse]:
    """


    Parameters
    ----------
    body : Union[LastQuotesByConstraintsRequest, SnapshotQuotesByConstraintsRequest, RangeQuotesByConstraintsRequest]

    source_name : str
        A sequence of textual characters.
    accept : Literal["text/csv", "application/json"]
        The desired response content type. Must be one of: "text/csv" | "application/json"

    Returns
    --------
    Union[str, QuotesResponse, QuotesByConstraintsResponse]


    Examples
    --------
    >>> query_quotes_by_constraints_response = quotes_query_quotes_by_constraints(
    >>>     source_name="SG",
    >>>      body=RangeQuotesByConstraintsRequest(
    >>>          filter="'PRODUCT NAME' eq 'FOREX' and 'BASE CURRENCY' eq 'EUR' and 'ACTIVE' eq 'YES' and 'DAILY VOL AVAILABLE' eq 'YES'",
    >>>          fields=[QuoteField(name="RATE")],
    >>>          refset="EUROPE CLOSE",
    >>>          start_date="2026-01-15",
    >>>          end_date="2026-01-22",
    >>>          fill_empty_quotes=False,
    >>>          page=1,
    >>>          page_size=2
    >>>          ),
    >>>     accept="application/json",
    >>> )
    >>>
    >>> print(json.dumps(query_quotes_by_constraints_response.as_dict(), indent=4))
    {
        "source": "SG",
        "refset": "EUROPE CLOSE",
        "quotes": [
            {
                "instrument": "EURAUD",
                "field": "RATE",
                "dataType": "Decimal",
                "isTimeSeries": true,
                "quoteValues": [
                    {
                        "date": "2026-01-15",
                        "value": 1.73097
                    },
                    {
                        "date": "2026-01-16",
                        "value": 1.736325
                    },
                    {
                        "date": "2026-01-19",
                        "value": 1.73387
                    },
                    {
                        "date": "2026-01-20",
                        "value": 1.74008
                    },
                    {
                        "date": "2026-01-21",
                        "value": 1.728775
                    },
                    {
                        "date": "2026-01-22",
                        "value": 1.71993
                    }
                ]
            },
            {
                "instrument": "EURCAD",
                "field": "RATE",
                "dataType": "Decimal",
                "isTimeSeries": true,
                "quoteValues": [
                    {
                        "date": "2026-01-15",
                        "value": 1.61243
                    },
                    {
                        "date": "2026-01-16",
                        "value": 1.61359
                    },
                    {
                        "date": "2026-01-19",
                        "value": 1.613895
                    },
                    {
                        "date": "2026-01-20",
                        "value": 1.62246
                    },
                    {
                        "date": "2026-01-21",
                        "value": 1.61559
                    },
                    {
                        "date": "2026-01-22",
                        "value": 1.620275
                    }
                ]
            }
        ],
        "totalMatchingInstruments": 19
    }

    """

    try:
        logger.info("Calling quotes_query_quotes_by_constraints")

        response = Client().market_data_service.quotes_query_quotes_by_constraints(
            source_name=source_name,
            headers={
                **{"accept": accept},
                "x-ap-sdk-operation": "market_data.quotes_query_quotes_by_constraints",
            },
            body=body,
        )

        output = response
        logger.info("Called quotes_query_quotes_by_constraints")

        return output
    except Exception as err:
        logger.error("Error quotes_query_quotes_by_constraints.")
        check_exception_and_raise(err, logger)
