from lseg_analytics.socgen.market_data import (
    explorer_search_instruments_by_constraints,
    quotes_query_quotes, QuoteField, SnapshotQuotesRequest, RangeQuotesRequest
)
import pandas as pd
from datetime import datetime
from dateutil.relativedelta import relativedelta
import plotly.express as px
from IPython.display import display

pd.options.display.max_rows = 10

source = 'SG'
product = 'RATES VOL'
refset = 'EUROPE CLOSE'

def quotes_to_dataframe(quotes):
    records = []

    for quote in quotes["quotes"]:
        quote_values = quote.get("quoteValues", [])
        if quote_values:
            for value in quote_values:
                subfields = value.get("subFields", {})
                record = {
                    "instrument": quote["instrument"],
                    "field": quote["field"],
                    "date": value["date"],
                    "value": value["value"]
                }
                if subfields:
                    for subfield_name in subfields:
                        record[subfield_name] = subfields[subfield_name]
                records.append(record)

    df = pd.DataFrame(records)
    return df

def sort_expiry_in_months(expiry):
    letter = expiry[-1]
    number = int(expiry[0:-1])
    if letter=='M':
        return number
    elif letter=='Y':
        return number*12
    else:
        return None

instruments_universe = []
page = 1
instruments = { 'instruments' : 1}

while instruments['instruments'] != []:
    instruments = explorer_search_instruments_by_constraints(
    source_name=source,
    search=None,
    filter="""'PRODUCT NAME' eq 'RATES VOL' and 'CURRENCY' eq 'EUR'""",
    page=page,
    page_size=10,
    includes=[ "displayName", "productName" ],
    sort_criteria=[
        {
            "field": "DISPLAY NAME",
            "order": "Asc",
        }
    ])

    instruments_universe.extend(instruments['instruments'])
    page = page + 1

df = pd.DataFrame(instruments_universe)
display(df)

instruments = list(df['instrument'])
quotes_query_quotes_response = quotes_query_quotes(
    source_name=source,
     body=SnapshotQuotesRequest(
         fields=[QuoteField(name="VOL HJM ATM"), QuoteField(name="TENOR"), QuoteField(name="CURRENCY"), QuoteField(name="EXPIRY")],
         refset=refset,
         instruments=instruments
         ),
    accept="application/json")

quotes_df = quotes_to_dataframe(quotes_query_quotes_response)

vol_surface_df = quotes_df.pivot(columns='field', values='value', index='instrument').reset_index().pivot(index='EXPIRY', columns='TENOR', values='VOL HJM ATM')
vol_surface_df = vol_surface_df.sort_values(axis='columns', by='TENOR',key= lambda x: x.apply(lambda y: sort_expiry_in_months(y)))
vol_surface_df = vol_surface_df.sort_index(key = lambda x: x.map(lambda y: sort_expiry_in_months(y)))
display(vol_surface_df)

fig = px.imshow(vol_surface_df, text_auto='.2f', aspect="auto", color_continuous_scale=[ "#444852", "#B4BBCB", "white", "#DC4941"], labels= { "color": "Vol" })
fig.update_xaxes(side="top")
fig.show()

startDate = datetime.today() - relativedelta(years=3)
endDate = datetime.today()

quotes_response = quotes_query_quotes(
    source_name=source,
    body=RangeQuotesRequest(
        fields=[QuoteField(name="VOL HJM ATM")],
        refset="EUROPE CLOSE",
        instruments=['RATES VOL EUR/3M_2Y', 'RATES VOL EUR/3M_5Y', 'RATES VOL EUR/3M_10Y'],
        start_date=startDate.strftime('%Y-%m-%d'),
        end_date=endDate.strftime('%Y-%m-%d')
    ),
    accept="application/json")

quotes_df = quotes_to_dataframe(quotes_response)
quotes_df['label'] = quotes_df['instrument'].apply(lambda x: x.split('/')[1])
display(quotes_df)

df = quotes_df[['date', 'label', 'value']]
fig = px.line(df, x="date", y="value", color='label', color_discrete_sequence=[ "#444852", "#DC4941", "#38699F"])
fig.show()