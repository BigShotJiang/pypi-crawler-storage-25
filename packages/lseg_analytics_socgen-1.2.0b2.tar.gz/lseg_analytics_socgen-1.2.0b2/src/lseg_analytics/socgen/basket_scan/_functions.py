import copy
import datetime
from typing import Any, Iterator, Literal, Optional, Union

from lseg_analytics.core.common._resource_base import ResourceBase
from lseg_analytics.core.exceptions import (
    LibraryException,
    ResourceNotFound,
    check_exception_and_raise,
    check_id,
)

from lseg_analytics.socgen._basic_client.models import (
    AdvDistributionDto,
    AdvType,
    AllOrdersAndCostDto,
    BasketAnalysisComputedResponse,
    BasketCreationRequest,
    BasketCreationResponse,
    BasketDto,
    BasketTimeToLive,
    BasketType,
    BasketUpdateRequest,
    Benchmark,
    BenchmarkResponse,
    BreakDownAnalysisDto,
    CompletionDto,
    CountryBreakDownAnalysisDto,
    DailyCompletionDto,
    EsgScoreInstrument,
    ExecutionDto,
    ExecutionResponse,
    FactorAnalysis,
    FactorsResponse,
    GetBasketResponse,
    GetBasketsResponse,
    GetEsgResponse,
    IdentifierType,
    InstrumentAbaqueDto,
    InstrumentDto,
    InstrumentValidationRequest,
    InstrumentValidationResponse,
    LiquidityImpactDto,
    MarketStatus,
    MostAndLargestBreakDownsDto,
    NominalOrQuantity,
    PerInstrumentFactorAnalysis,
    RegionAbaqueDto,
    RegionDto,
    SharingPolicy,
    StatusDto,
    SummaryDailyDto,
    TargetCloseInstrumentDto,
    TargetCloseResponseDto,
    TargetCloseTradingSegmentDto,
    TargetCloseTradingSessionDto,
    UserAuthorization,
    Way,
    WayDto,
    WeightedAverageByNominal,
)
from lseg_analytics.socgen._client.client import Client

from ._logger import logger

__all__ = [
    "AdvDistributionDto",
    "AdvType",
    "AllOrdersAndCostDto",
    "BasketAnalysisComputedResponse",
    "BasketCreationResponse",
    "BasketDto",
    "BasketTimeToLive",
    "BasketType",
    "Benchmark",
    "BenchmarkResponse",
    "BreakDownAnalysisDto",
    "CompletionDto",
    "CountryBreakDownAnalysisDto",
    "DailyCompletionDto",
    "EsgScoreInstrument",
    "ExecutionDto",
    "ExecutionResponse",
    "FactorAnalysis",
    "FactorsResponse",
    "GetBasketResponse",
    "GetBasketsResponse",
    "GetEsgResponse",
    "IdentifierType",
    "InstrumentAbaqueDto",
    "InstrumentDto",
    "InstrumentValidationResponse",
    "LiquidityImpactDto",
    "MarketStatus",
    "MostAndLargestBreakDownsDto",
    "NominalOrQuantity",
    "PerInstrumentFactorAnalysis",
    "RegionAbaqueDto",
    "RegionDto",
    "SharingPolicy",
    "StatusDto",
    "SummaryDailyDto",
    "TargetCloseInstrumentDto",
    "TargetCloseResponseDto",
    "TargetCloseTradingSegmentDto",
    "TargetCloseTradingSessionDto",
    "UserAuthorization",
    "Way",
    "WayDto",
    "WeightedAverageByNominal",
    "create_basket",
    "delete_basket",
    "get_basket",
    "get_basket_analyzed_data",
    "get_basket_export_data_excel",
    "get_basket_export_data_json",
    "get_basket_export_data_pdf",
    "get_benchmarks",
    "get_esg",
    "get_factors",
    "list_baskets",
    "perform_execution_analysis_by_timeframe",
    "perform_target_close_analysis",
    "update_basket",
    "validate_instruments",
]


def create_basket(
    *,
    instruments: list[InstrumentDto],
    time_to_live: Optional[Union[str, BasketTimeToLive]] = None,
    basket_name: Optional[str] = None,
    identifier_type: Optional[Union[str, IdentifierType]] = None,
    nominal_or_quantity: Optional[Union[str, NominalOrQuantity]] = None,
    total: Optional[float] = None,
    nominal_currency: Optional[str] = None,
) -> BasketCreationResponse:
    """
    Create a new basket.

    Parameters
    ----------
    time_to_live : Union[str, BasketTimeToLive], optional

    basket_name : str, optional

    identifier_type : Union[str, IdentifierType], optional

    nominal_or_quantity : Union[str, NominalOrQuantity], optional

    total : float, optional

    nominal_currency : str, optional

    instruments : list[InstrumentDto]


    Returns
    --------
    BasketCreationResponse


    Examples
    --------
    >>> create_basket(time_to_live="OneDay",
    >>>               basket_name="My First Basket",
    >>>               identifier_type="Ticker",
    >>>               nominal_or_quantity="Nominal",
    >>>               nominal_currency="EUR",
    >>>               instruments=[
    >>>                   {
    >>>                       "id": "BAYN GY",
    >>>                       "quantity": 0,
    >>>                       "weight": 0.25,
    >>>                       "way": "Buy"
    >>>                  },
    >>>                  {
    >>>                       "id": "GLE FP",
    >>>                       "quantity": 0,
    >>>                       "weight": 0.75,
    >>>                       "way": "Buy"
    >>>                  }
    >>>             ])
    {'basketId': '79da453f-ae57-4e22-afd1-41df767ad81c'}

    """

    try:
        logger.info("Calling create_basket")

        response = Client().basket_scan_service.create_basket(
            body=BasketCreationRequest(
                time_to_live=time_to_live,
                basket_name=basket_name,
                identifier_type=identifier_type,
                nominal_or_quantity=nominal_or_quantity,
                total=total,
                nominal_currency=nominal_currency,
                instruments=instruments,
            ),
            content_type="application/json",
            headers={"x-ap-sdk-operation": "basket_scan.create_basket"},
        )

        output = response
        logger.info("Called create_basket")

        return output
    except Exception as err:
        logger.error("Error create_basket.")
        check_exception_and_raise(err, logger)


def delete_basket(*, basket_id: str) -> bool:
    """
    Delete an existing basket.

    Parameters
    ----------
    basket_id : str
        Identifier of the basket to delete.

    Returns
    --------
    bool
        boolean specifying the operation status

    Examples
    --------
    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     # Get basket id
    >>>     basket_id = baskets.baskets[0].id
    >>>     print(f"Deleting basket with id: {basket_id}")
    >>>
    >>>     # Delete basket
    >>>     delete_basket(basket_id=basket_id)
    >>>     print("Basket deleted.")
    >>> else:
    >>>     print("No baskets available!")
    Deleting basket with id: 6a41d276-192e-4349-a06a-6966c927bd46
    Basket deleted.

    """

    try:
        logger.info("Calling delete_basket")
        Client().basket_scan_service.delete_basket(
            basket_id=basket_id,
            headers={"x-ap-sdk-operation": "basket_scan.delete_basket"},
        )
        logger.info("Called delete_basket")

        return True
    except Exception as err:
        logger.error("Error delete_basket.")
        check_exception_and_raise(err, logger)


def get_basket(
    *, basket_id: str, basket_type: Optional[Union[str, BasketType]] = None, multiplier: Optional[float] = None
) -> GetBasketResponse:
    """
    Retrieve details and content of an existing basket.

    Parameters
    ----------
    basket_id : str
        A sequence of textual characters.
    basket_type : Union[str, BasketType], optional
        Basket type (to analyze baskets from YouTrack or indices).
    multiplier : float, optional
        Total nominal if the basketType is different than basket.

    Returns
    --------
    GetBasketResponse


    Examples
    --------
    If the user holds or knows the id of a specific basket he wishes to retrieve, he can use the get_basket function as follows:

    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     # Get Basket
    >>>     spec_basket = get_basket(basket_id=baskets.baskets[0].id)
    >>>
    >>>     print(json.dumps(spec_basket.as_dict(), indent=4))
    >>>
    >>> else:
    >>>     print("No baskets available!")
    {
        "basket": {
            "id": "6a41d276-192e-4349-a06a-6966c927bd46",
            "identifierType": "Ticker",
            "nominalOrQuantity": "Nominal",
            "name": "Test Basket",
            "timeToLive": "2026-04-13 00:00:00",
            "owner": "GE-GST3R76PQ4XE",
            "sharingPolicy": "Private",
            "sharedWithUsers": {},
            "total": 100000.0,
            "nominalCurrency": "EUR",
            "instruments": [
                {
                    "id": "BAYN GY",
                    "quantity": null,
                    "weight": 0.25,
                    "way": "Buy"
                },
                {
                    "id": "GLE FP",
                    "quantity": null,
                    "weight": 0.75,
                    "way": "Buy"
                }
            ]
        }
    }

    """

    try:
        logger.info("Calling get_basket")

        response = Client().basket_scan_service.get_basket(
            basket_id=basket_id,
            basket_type=basket_type,
            multiplier=multiplier,
            headers={"x-ap-sdk-operation": "basket_scan.get_basket"},
        )

        output = response
        logger.info("Called get_basket")

        return output
    except Exception as err:
        logger.error("Error get_basket.")
        check_exception_and_raise(err, logger)


def get_basket_analyzed_data(
    *,
    basket_id: str,
    currency: Optional[str] = None,
    adv: Optional[Union[str, AdvType]] = None,
    max_participation: Optional[float] = None,
    way: Optional[Union[str, Way]] = None,
    basket_type: Optional[Union[str, BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
) -> BasketAnalysisComputedResponse:
    """
    Get all analyzed data for a basket.

    Parameters
    ----------
    basket_id : str
        Identifier of the basket.
    currency : str, optional
        Currency to convert the returned nominal values ('EUR' by default).
    adv : Union[str, AdvType], optional
        ADV period used to compute impact ('ADV20' by default).
    max_participation : float, optional
        Maximum % of ADV allowed (used for impact computation).
    way : Union[str, Way], optional
        Way (if not set, returns both Buy and Sell).
    basket_type : Union[str, BasketType], optional
        Basket type (to analyze baskets from YouTrack or indices).
    multiplier : float, optional
        Total nominal if the basketType is different than basket.
    volumes : list[str], optional
        The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'Main only' is used if not specified).

    Returns
    --------
    BasketAnalysisComputedResponse


    Examples
    --------
    User can execute deep data analysis of the basket as follows:

    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     # Analyze Basket data
    >>>     analyzed_data = get_basket_analyzed_data(
    >>>         basket_id=baskets.baskets[0].id,
    >>>         currency=baskets.baskets[0].nominal_currency,
    >>>         adv="ACV",
    >>>         max_participation=0.92,
    >>>         way="Buy",
    >>>         multiplier=4
    >>>     )
    >>>
    >>>     print(json.dumps(analyzed_data.as_dict().get("totalSummaryAnalysis"), indent=4))
    >>>
    >>> else:
    >>>     print("No baskets available!")
    [
        {
            "rowKey": "Buy",
            "orders": 2,
            "shares": 18186.95346018531,
            "grossNominal": 1000000.0,
            "netNominal": 1000000.0,
            "weight": 1.0,
            "percentageAdv": 0.00927185419416756,
            "volatility": 0.4252424155618377,
            "impact": 1.5006619825722638,
            "spread": 12.335,
            "instrumentsContained": [
                "BAYN GY",
                "GLE FP"
            ]
        }
    ]

    """

    try:
        logger.info("Calling get_basket_analyzed_data")

        response = Client().basket_scan_service.get_basket_analyzed_data(
            basket_id=basket_id,
            currency=currency,
            adv=adv,
            max_participation=max_participation,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            headers={"x-ap-sdk-operation": "basket_scan.get_basket_analyzed_data"},
        )

        output = response
        logger.info("Called get_basket_analyzed_data")

        return output
    except Exception as err:
        logger.error("Error get_basket_analyzed_data.")
        check_exception_and_raise(err, logger)


def get_basket_export_data_excel(
    *,
    basket_id: str,
    exec_start_time: str,
    max_open_adv_percentage: float,
    max_intra_day_adv_percentage: float,
    max_close_adv_percentage: float,
    currency: Optional[str] = None,
    adv: Optional[Union[str, AdvType]] = None,
    max_participation: Optional[float] = None,
    way: Optional[Union[str, Way]] = None,
    basket_type: Optional[Union[str, BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
    benchmark_index: Optional[str] = None,
) -> Iterator[bytes]:
    """
    Get all analyzed data for a basket in Excel Spreadsheet format.

    Parameters
    ----------
    basket_id : str
        Identifier of the basket.
    exec_start_time : str
        Time at which the analysis starts (format: HH:MM:SS, timezone: UTC).
    max_open_adv_percentage : float
        Maximum ratio of the ADV that can be traded at open.
    max_intra_day_adv_percentage : float
        Maximum ratio of the ADV that can be traded between open and close.
    max_close_adv_percentage : float
        Maximum ratio of the ADV that can be traded at close.
    currency : str, optional
        Currency to convert the returned nominal values ('EUR' by default).
    adv : Union[str, AdvType], optional
        ADV period used to compute impact ('ADV20' by default).
    max_participation : float, optional
        Maximum % of ADV allowed (used for impact computation).
    way : Union[str, Way], optional
        Way (if not set, returns both Buy and Sell).
    basket_type : Union[str, BasketType], optional
        Basket type (to analyze baskets from YouTrack or indices).
    multiplier : float, optional
        Total nominal if the basketType is different than basket.
    volumes : list[str], optional
        The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'Main only' is used if not specified).
    benchmark_index : str, optional
        The index ticker used for comparison (for example: MXWO INDEX for the MSCI World index)

    Returns
    --------
    Iterator[bytes]
        Iterator of bytes

    Examples
    --------
    Excel Export

    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     excel_data = get_basket_export_data_excel(basket_id=baskets.baskets[0].id,
    >>>                                 exec_start_time="08:00:00",
    >>>                                 max_open_adv_percentage=0.89,
    >>>                                 max_intra_day_adv_percentage=0.97,
    >>>                                 max_close_adv_percentage=0.99
    >>>                                 )
    >>>
    >>>     # Write the bytes into the file
    >>>     total_bytes = 0
    >>>     with open("basket_export_data.xlsx", "wb") as f:
    >>>         for chunk in excel_data:
    >>>             f.write(chunk)
    >>>             total_bytes += len(chunk)
    >>>
    >>>     print(f"Excel saved with {total_bytes} bytes")
    >>>
    >>> else:
    >>>     print("No baskets available!")

    """

    try:
        logger.info("Calling get_basket_export_data_excel")

        response = Client().basket_scan_service.get_basket_export_data_excel(
            accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_open_adv_percentage=max_open_adv_percentage,
            max_intra_day_adv_percentage=max_intra_day_adv_percentage,
            max_close_adv_percentage=max_close_adv_percentage,
            currency=currency,
            adv=adv,
            max_participation=max_participation,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            benchmark_index=benchmark_index,
            headers={"x-ap-sdk-operation": "basket_scan.get_basket_export_data_excel"},
        )

        output = response
        logger.info("Called get_basket_export_data_excel")

        return output
    except Exception as err:
        logger.error("Error get_basket_export_data_excel.")
        check_exception_and_raise(err, logger)


def get_basket_export_data_json(
    *,
    basket_id: str,
    exec_start_time: str,
    max_open_adv_percentage: float,
    max_intra_day_adv_percentage: float,
    max_close_adv_percentage: float,
    currency: Optional[str] = None,
    adv: Optional[Union[str, AdvType]] = None,
    max_participation: Optional[float] = None,
    way: Optional[Union[str, Way]] = None,
    basket_type: Optional[Union[str, BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
    benchmark_index: Optional[str] = None,
) -> BasketAnalysisComputedResponse:
    """
    Get all analyzed data for a basket.

    Parameters
    ----------
    basket_id : str
        Identifier of the basket.
    exec_start_time : str
        Time at which the analysis starts (format: HH:MM:SS, timezone: UTC).
    max_open_adv_percentage : float
        Maximum ratio of the ADV that can be traded at open.
    max_intra_day_adv_percentage : float
        Maximum ratio of the ADV that can be traded between open and close.
    max_close_adv_percentage : float
        Maximum ratio of the ADV that can be traded at close.
    currency : str, optional
        Currency to convert the returned nominal values ('EUR' by default).
    adv : Union[str, AdvType], optional
        ADV period used to compute impact ('ADV20' by default).
    max_participation : float, optional
        Maximum % of ADV allowed (used for impact computation).
    way : Union[str, Way], optional
        Way (if not set, returns both Buy and Sell).
    basket_type : Union[str, BasketType], optional
        Basket type (to analyze baskets from YouTrack or indices).
    multiplier : float, optional
        Total nominal if the basketType is different than basket.
    volumes : list[str], optional
        The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'Main only' is used if not specified).
    benchmark_index : str, optional
        The index ticker used for comparison (for example: MXWO INDEX for the MSCI World index)

    Returns
    --------
    BasketAnalysisComputedResponse


    Examples
    --------


    """

    try:
        logger.info("Calling get_basket_export_data_json")

        response = Client().basket_scan_service.get_basket_export_data_json(
            accept="application/json",
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_open_adv_percentage=max_open_adv_percentage,
            max_intra_day_adv_percentage=max_intra_day_adv_percentage,
            max_close_adv_percentage=max_close_adv_percentage,
            currency=currency,
            adv=adv,
            max_participation=max_participation,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            benchmark_index=benchmark_index,
            headers={"x-ap-sdk-operation": "basket_scan.get_basket_export_data_json"},
        )

        output = response
        logger.info("Called get_basket_export_data_json")

        return output
    except Exception as err:
        logger.error("Error get_basket_export_data_json.")
        check_exception_and_raise(err, logger)


def get_basket_export_data_pdf(
    *,
    basket_id: str,
    exec_start_time: str,
    max_open_adv_percentage: float,
    max_intra_day_adv_percentage: float,
    max_close_adv_percentage: float,
    currency: Optional[str] = None,
    adv: Optional[Union[str, AdvType]] = None,
    max_participation: Optional[float] = None,
    way: Optional[Union[str, Way]] = None,
    basket_type: Optional[Union[str, BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
    benchmark_index: Optional[str] = None,
) -> Iterator[bytes]:
    """
    Get all analyzed data for a basket in PDF format.

    Parameters
    ----------
    basket_id : str
        Identifier of the basket.
    exec_start_time : str
        Time at which the analysis starts (format: HH:MM:SS, timezone: UTC).
    max_open_adv_percentage : float
        Maximum ratio of the ADV that can be traded at open.
    max_intra_day_adv_percentage : float
        Maximum ratio of the ADV that can be traded between open and close.
    max_close_adv_percentage : float
        Maximum ratio of the ADV that can be traded at close.
    currency : str, optional
        Currency to convert the returned nominal values ('EUR' by default).
    adv : Union[str, AdvType], optional
        ADV period used to compute impact ('ADV20' by default).
    max_participation : float, optional
        Maximum % of ADV allowed (used for impact computation).
    way : Union[str, Way], optional
        Way (if not set, returns both Buy and Sell).
    basket_type : Union[str, BasketType], optional
        Basket type (to analyze baskets from YouTrack or indices).
    multiplier : float, optional
        Total nominal if the basketType is different than basket.
    volumes : list[str], optional
        The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'Main only' is used if not specified).
    benchmark_index : str, optional
        The index ticker used for comparison (for example: MXWO INDEX for the MSCI World index)

    Returns
    --------
    Iterator[bytes]
        Iterator of bytes

    Examples
    --------
    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     pdf_data = get_basket_export_data_pdf(basket_id=baskets.baskets[0].id,
    >>>                              exec_start_time="09:00:00",
    >>>                              max_open_adv_percentage=0.98,
    >>>                              max_intra_day_adv_percentage=0.79,
    >>>                              max_close_adv_percentage=0.88
    >>>                              )
    >>>
    >>>     # Write the bytes into the file
    >>>     total_bytes = 0
    >>>     with open("basket_export_data.pdf", "wb") as f:
    >>>         for chunk in pdf_data:
    >>>             f.write(chunk)
    >>>             total_bytes += len(chunk)
    >>>
    >>>     print(f"PDF saved with {total_bytes} bytes")
    >>>
    >>> else:
    >>>     print("No baskets available!")
    PDF saved with 95066 bytes

    """

    try:
        logger.info("Calling get_basket_export_data_pdf")

        response = Client().basket_scan_service.get_basket_export_data_pdf(
            accept="application/pdf",
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_open_adv_percentage=max_open_adv_percentage,
            max_intra_day_adv_percentage=max_intra_day_adv_percentage,
            max_close_adv_percentage=max_close_adv_percentage,
            currency=currency,
            adv=adv,
            max_participation=max_participation,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            benchmark_index=benchmark_index,
            headers={"x-ap-sdk-operation": "basket_scan.get_basket_export_data_pdf"},
        )

        output = response
        logger.info("Called get_basket_export_data_pdf")

        return output
    except Exception as err:
        logger.error("Error get_basket_export_data_pdf.")
        check_exception_and_raise(err, logger)


def get_benchmarks() -> BenchmarkResponse:
    """
    Returns the list of benchmarks which can be used in factor analysis.

    Parameters
    ----------


    Returns
    --------
    BenchmarkResponse


    Examples
    --------
    >>> benchmarks_data = get_benchmarks()
    >>>
    >>> print(json.dumps(benchmarks_data.as_dict().get("benchmarks")[0], indent=4))
    {
        "code": "AEX INDEX",
        "label": "AEX-Index"
    }

    """

    try:
        logger.info("Calling get_benchmarks")

        response = Client().basket_scan_service.get_benchmarks(
            headers={"x-ap-sdk-operation": "basket_scan.get_benchmarks"}
        )

        output = response
        logger.info("Called get_benchmarks")

        return output
    except Exception as err:
        logger.error("Error get_benchmarks.")
        check_exception_and_raise(err, logger)


def get_esg(
    *,
    basket_id: str,
    currency: Optional[str] = None,
    way: Optional[Union[str, Way]] = None,
    basket_type: Optional[Union[str, BasketType]] = None,
    multiplier: Optional[float] = None,
) -> GetEsgResponse:
    """
    Get ESG, Environmental, Social and Governance scores for a basket.

    Parameters
    ----------
    basket_id : str
        Identifier of the basket.
    currency : str, optional
        Currency to convert the returned nominal values ('EUR' by default)
    way : Union[str, Way], optional
        Way (if not set, returns both Buy and Sell).
    basket_type : Union[str, BasketType], optional
        Basket type (to analyze baskets from YouTrack or indices).
    multiplier : float, optional
        Total nominal if the basketType is diffeModelrent than basket.

    Returns
    --------
    GetEsgResponse


    Examples
    --------
    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>         esg_data = get_esg(
    >>>             basket_id=baskets.baskets[0].id,
    >>>             currency="EUR",
    >>>             way="Buy",
    >>>             basket_type="Basket",
    >>>             multiplier=1
    >>>         )
    >>>         print(json.dumps(esg_data.as_dict(), indent=4))
    >>> else:
    >>>     print("No baskets available!")

    """

    try:
        logger.info("Calling get_esg")

        response = Client().basket_scan_service.get_esg(
            basket_id=basket_id,
            currency=currency,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            headers={"x-ap-sdk-operation": "basket_scan.get_esg"},
        )

        output = response
        logger.info("Called get_esg")

        return output
    except Exception as err:
        logger.error("Error get_esg.")
        check_exception_and_raise(err, logger)


def get_factors(*, basket_id: str, benchmark_index: Optional[str] = None) -> FactorsResponse:
    """
    Returns a factors analysis of your basket compared to a chosen index (benchmark).

    Parameters
    ----------
    basket_id : str
        Your basket identifier (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx format).
    benchmark_index : str, optional
        The index ticker used for comparison (for example: MXWO INDEX for the MSCI World index)

    Returns
    --------
    FactorsResponse


    Examples
    --------
    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     factors_data = get_factors(
    >>>         basket_id=baskets.baskets[0].id,
    >>>         benchmark_index="NDUEACWF INDEX"
    >>>     )
    >>>     response_dict = factors_data.as_dict()
    >>>     print(json.dumps(response_dict.get("instrumentsExposure"), indent=4))
    >>>
    >>> else:
    >>>     print("No baskets available!")
    [
        {
            "instrumentCode": "BAYN GY",
            "instrumentName": "BAYER AG-REG",
            "country": "DE",
            "sector": "Consumer, Non-cyclical",
            "weight": 0.25,
            "adjustedWeight": 0.25,
            "exposure": {
                "value": 2.1105331757396284,
                "momentum": -1.2134478543101284,
                "lowRisk": -0.9404979375367526,
                "fundamentalQuality": 0.14509427559929583,
                "lowSize": -0.3610352311399003,
                "growth": -1.0775427576007033,
                "duration": -0.0026311363338317297,
                "inflation": 0.2951489198636046
            }
        },
        {
            "instrumentCode": "GLE FP",
            "instrumentName": "SOCIETE GENERALE SA",
            "country": "FR",
            "sector": "Financial",
            "weight": 0.75,
            "adjustedWeight": 0.75,
            "exposure": {
                "value": 1.4493416470536344,
                "momentum": -0.09866159142709008,
                "lowRisk": -0.3918934838707386,
                "fundamentalQuality": -0.30292095511275074,
                "lowSize": -0.2688482418463992,
                "growth": 0.692246889289277,
                "duration": 1.2332247909505343,
                "inflation": 1.4034809766733156
            }
        }
    ]

    """

    try:
        logger.info("Calling get_factors")

        response = Client().basket_scan_service.get_factors(
            basket_id=basket_id,
            benchmark_index=benchmark_index,
            headers={"x-ap-sdk-operation": "basket_scan.get_factors"},
        )

        output = response
        logger.info("Called get_factors")

        return output
    except Exception as err:
        logger.error("Error get_factors.")
        check_exception_and_raise(err, logger)


def list_baskets() -> GetBasketsResponse:
    """
    Retrieve the list of existing baskets including shared and public ones.

    Parameters
    ----------


    Returns
    --------
    GetBasketsResponse


    Examples
    --------
    >>> # List Baskets
    >>> baskets = list_baskets()
    >>>
    >>> print(json.dumps(baskets.as_dict().get("baskets")[0],indent=4))
    {
        "id": "6a41d276-192e-4349-a06a-6966c927bd46",
        "identifierType": "Ticker",
        "nominalOrQuantity": "Nominal",
        "name": "Test Basket",
        "timeToLive": "2026-04-13 00:00:00",
        "owner": "GE-GST3R76PQ4XE",
        "sharingPolicy": "Private",
        "sharedWithUsers": {},
        "total": 100000.0,
        "nominalCurrency": "EUR",
        "instruments": [
            {
                "id": "BAYN GY",
                "quantity": null,
                "weight": 0.25,
                "way": "Buy"
            },
            {
                "id": "GLE FP",
                "quantity": null,
                "weight": 0.75,
                "way": "Buy"
            }
        ]
    }

    """

    try:
        logger.info("Calling list_baskets")

        response = Client().basket_scan_service.list_baskets(headers={"x-ap-sdk-operation": "basket_scan.list_baskets"})

        output = response
        logger.info("Called list_baskets")

        return output
    except Exception as err:
        logger.error("Error list_baskets.")
        check_exception_and_raise(err, logger)


def perform_execution_analysis_by_timeframe(
    *,
    basket_id: str,
    exec_start_time: str,
    max_participation: float,
    way: Optional[Union[str, Way]] = None,
    currency: Optional[str] = None,
    adv_type: Optional[Union[str, AdvType]] = None,
    basket_type: Optional[Union[str, BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
) -> ExecutionResponse:
    """
    Perform an execution analysis by timeframe for a basket.

    Parameters
    ----------
    basket_id : str
        Identifier of the basket.
    exec_start_time : str
        Time at which the execution starts (format: HH:MM:SS, timezone: UTC).
    max_participation : float
        Maximum participation.
    way : Union[str, Way], optional
        Way (if not set, returns both Buy and Sell).
    currency : str, optional
        Currency to convert the returned nominal values.
    adv_type : Union[str, AdvType], optional
        ADV period used to compute impact ('ADV20' by default).
    basket_type : Union[str, BasketType], optional
        Basket type (to analyze baskets from YouTrack or indices).
    multiplier : float, optional
        Total nominal if the basketType is different than basket.
    volumes : list[str], optional
        The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'IX (deprecated)', 'EB (deprecated), 'TQ (deprecated)', 'Main only' is used if not specified).

    Returns
    --------
    ExecutionResponse


    Examples
    --------
    Execution Analysis by Timeframe

    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     exec_analysis = perform_execution_analysis_by_timeframe(
    >>>         basket_id=baskets.baskets[0].id,
    >>>         currency=baskets.baskets[0].nominal_currency,
    >>>         exec_start_time="11:00:00",
    >>>         max_participation=0.93,
    >>>         adv_type="ACV",
    >>>         way="Buy",
    >>>         multiplier=4
    >>>     )
    >>>
    >>>     print(json.dumps(exec_analysis.as_dict().get("regions")[0].get("advDistribution"), indent=4))
    >>>
    >>> else:
    >>>     print("No baskets available!")
    [
        {
            "from": 0.004454603792036714,
            "to": 0.005096903845654161,
            "count": 1.0
        },
        {
            "from": 0.005096903845654161,
            "to": 0.005739203899271607,
            "count": 0.0
        },
        {
            "from": 0.005739203899271607,
            "to": 0.0063815039528890526,
            "count": 0.0
        },
        {
            "from": 0.0063815039528890526,
            "to": 0.007023804006506499,
            "count": 0.0
        },
        {
            "from": 0.007023804006506499,
            "to": 0.007666104060123946,
            "count": 0.0
        },
        {
            "from": 0.007666104060123946,
            "to": 0.008308404113741391,
            "count": 0.0
        },
        {
            "from": 0.008308404113741391,
            "to": 0.008950704167358839,
            "count": 0.0
        },
        {
            "from": 0.008950704167358839,
            "to": 0.009593004220976285,
            "count": 0.0
        },
        {
            "from": 0.009593004220976285,
            "to": 0.01023530427459373,
            "count": 0.0
        },
        {
            "from": 0.01023530427459373,
            "to": 0.010877604328211176,
            "count": 1.0
        }
    ]

    """

    try:
        logger.info("Calling perform_execution_analysis_by_timeframe")

        response = Client().basket_scan_service.perform_execution_analysis_by_timeframe(
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_participation=max_participation,
            way=way,
            currency=currency,
            adv_type=adv_type,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            headers={"x-ap-sdk-operation": "basket_scan.perform_execution_analysis_by_timeframe"},
        )

        output = response
        logger.info("Called perform_execution_analysis_by_timeframe")

        return output
    except Exception as err:
        logger.error("Error perform_execution_analysis_by_timeframe.")
        check_exception_and_raise(err, logger)


def perform_target_close_analysis(
    *,
    basket_id: str,
    exec_start_time: str,
    max_open_adv_percentage: float,
    max_intra_day_adv_percentage: float,
    max_close_adv_percentage: float,
    currency: Optional[str] = None,
    adv_type: Optional[Union[str, AdvType]] = None,
    basket_type: Optional[Union[str, BasketType]] = None,
    multiplier: Optional[float] = None,
    exec_start_date: Optional[datetime.datetime] = None,
    volumes: Optional[list[str]] = None,
) -> TargetCloseResponseDto:
    """
    Perform a target close analysis on all the instruments of a basket.

    Parameters
    ----------
    basket_id : str
        Identifier of the basket.
    exec_start_time : str
        Time at which the analysis starts (format: HH:MM:SS, timezone: UTC).
    max_open_adv_percentage : float
        Maximum ratio of the ADV that can be traded at open.
    max_intra_day_adv_percentage : float
        Maximum ratio of the ADV that can be traded between open and close.
    max_close_adv_percentage : float
        Maximum ratio of the ADV that can be traded at close.
    currency : str, optional
        Currency to convert the returned nominal values.
    adv_type : Union[str, AdvType], optional
        ADV period used to compute impact ('ADV20' by default).
    basket_type : Union[str, BasketType], optional
        Basket type (to analyze baskets from YouTrack or indices).
    multiplier : float, optional
        Total nominal if the basketType is different than basket.
    exec_start_date : datetime.datetime, optional
        An instant in coordinated universal time (UTC)"
    volumes : list[str], optional
        The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'IX (deprecated)', 'EB (deprecated), 'TQ (deprecated)', 'Main only' is used if not specified).

    Returns
    --------
    TargetCloseResponseDto


    Examples
    --------
    Target Close Analysis

    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     target_close = perform_target_close_analysis(
    >>>         basket_id=baskets.baskets[0].id,
    >>>         currency=baskets.baskets[0].nominal_currency,
    >>>         exec_start_time="12:00:00",
    >>>         max_open_adv_percentage=0.99,
    >>>         max_intra_day_adv_percentage=0.89,
    >>>         max_close_adv_percentage=0.92,
    >>>         adv_type="Adv10d",
    >>>         multiplier=1
    >>>     )
    >>>
    >>>     print(json.dumps(target_close.as_dict().get("instruments"), indent=4))
    >>>
    >>> else:
    >>>     print("No baskets available!")
    [
        {
            "ticker": "BAYN GY",
            "name": "BAYER AG-REG",
            "geoZone": "EMEA",
            "way": "Buy",
            "market": "Germany",
            "executionStartDateTime": "2026-03-16 16:30:00",
            "executionEndDateTime": "2026-03-16 16:35:00",
            "adv": 4055643.823725092,
            "advPct": 0.0016002724294577548,
            "quantityToExecute": 6490,
            "nominalToExecute": 249994.80000000002,
            "weightPct": 0.25000922053184027,
            "residualQuantity": 0,
            "residualNominal": 0.0,
            "costBps": 0.9094822515308616,
            "costCcy": 22.736583357500745,
            "acv": 1471598.2692529259,
            "acvPct": 0.0044102627261872794,
            "tradingSessions": [
                {
                    "executionStartDateTime": "2026-03-16 16:30:00",
                    "executionEndDateTime": "2026-03-16 16:35:00",
                    "quantityToExecute": 6490,
                    "nominalToExecute": 249994.80000000002,
                    "residualQuantity": 0,
                    "residualNominal": 0.0,
                    "impactTemporaryBps": 0.0,
                    "impactPermanentBps": 0.0,
                    "impactCloseBps": 0.9094822515308615,
                    "impactTotalBps": 0.9094822515308615,
                    "costBps": 0.9094822515308616,
                    "costCcy": 22.736583357500745,
                    "close": {
                        "executionStartDateTime": "2026-03-16 16:30:00",
                        "executionEndDateTime": "2026-03-16 16:35:00",
                        "doneQuantity": 6490,
                        "doneNominal": 249994.80000000002
                    },
                    "pctCompletion": 1.0,
                    "marketStatus": "Open"
                }
            ],
            "nbDays": 1
        },
        {
            "ticker": "GLE FP",
            "name": "SOCIETE GENERALE SA",
            "geoZone": "EMEA",
            "way": "Buy",
            "market": "Paris",
            "executionStartDateTime": "2026-03-16 16:30:00",
            "executionEndDateTime": "2026-03-16 16:35:00",
            "adv": 3019637.8882398745,
            "advPct": 0.0038735831574147487,
            "quantityToExecute": 11696,
            "nominalToExecute": 749947.52,
            "weightPct": 0.7499907794681597,
            "residualQuantity": 0,
            "residualNominal": 0.0,
            "costBps": 1.5605565199162332,
            "costCcy": 117.03354919310098,
            "acv": 1212685.5437982606,
            "acvPct": 0.009645384597182326,
            "tradingSessions": [
                {
                    "executionStartDateTime": "2026-03-16 16:30:00",
                    "executionEndDateTime": "2026-03-16 16:35:00",
                    "quantityToExecute": 11696,
                    "nominalToExecute": 749947.52,
                    "residualQuantity": 0,
                    "residualNominal": 0.0,
                    "impactTemporaryBps": 0.0,
                    "impactPermanentBps": 0.0,
                    "impactCloseBps": 1.5605565199162335,
                    "impactTotalBps": 1.5605565199162335,
                    "costBps": 1.5605565199162335,
                    "costCcy": 117.03354919310098,
                    "close": {
                        "executionStartDateTime": "2026-03-16 16:30:00",
                        "executionEndDateTime": "2026-03-16 16:35:00",
                        "doneQuantity": 11696,
                        "doneNominal": 749947.52
                    },
                    "pctCompletion": 1.0,
                    "marketStatus": "Open"
                }
            ],
            "nbDays": 1
        }
    ]

    """

    try:
        logger.info("Calling perform_target_close_analysis")

        response = Client().basket_scan_service.perform_target_close_analysis(
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_open_adv_percentage=max_open_adv_percentage,
            max_intra_day_adv_percentage=max_intra_day_adv_percentage,
            max_close_adv_percentage=max_close_adv_percentage,
            currency=currency,
            adv_type=adv_type,
            basket_type=basket_type,
            multiplier=multiplier,
            exec_start_date=exec_start_date,
            volumes=volumes,
            headers={"x-ap-sdk-operation": "basket_scan.perform_target_close_analysis"},
        )

        output = response
        logger.info("Called perform_target_close_analysis")

        return output
    except Exception as err:
        logger.error("Error perform_target_close_analysis.")
        check_exception_and_raise(err, logger)


def update_basket(
    *,
    instruments: list[InstrumentDto],
    basket_id: str,
    time_to_live: Optional[Union[str, BasketTimeToLive]] = None,
    basket_name: Optional[str] = None,
    identifier_type: Optional[Union[str, IdentifierType]] = None,
    nominal_or_quantity: Optional[Union[str, NominalOrQuantity]] = None,
    total: Optional[float] = None,
    nominal_currency: Optional[str] = None,
) -> bool:
    """
    Update an existing basket.

    Parameters
    ----------
    time_to_live : Union[str, BasketTimeToLive], optional

    basket_name : str, optional

    identifier_type : Union[str, IdentifierType], optional

    nominal_or_quantity : Union[str, NominalOrQuantity], optional

    total : float, optional

    nominal_currency : str, optional

    instruments : list[InstrumentDto]

    basket_id : str
        Identifier of the basket to update.

    Returns
    --------
    bool
        boolean specifying the operation status

    Examples
    --------
    >>> # Get a list of available baskets
    >>> baskets = list_baskets()
    >>>
    >>> if baskets and baskets.baskets:
    >>>     # Get basket id
    >>>     basket_id = baskets.baskets[0].id
    >>>     print(f"Updating basket with id: {basket_id}")
    >>>
    >>>     update_basket(basket_id=basket_id,
    >>>               time_to_live="OneDay",
    >>>               basket_name="Update Basket",
    >>>               identifier_type="Ticker",
    >>>               nominal_or_quantity="Nominal",
    >>>               nominal_currency="EUR",
    >>>               instruments=[
    >>>                   {
    >>>                       "id": "BAYN GY",
    >>>                       "quantity": 0,
    >>>                       "weight": 0.25,
    >>>                       "way": "Buy"
    >>>                  },
    >>>                  {
    >>>                       "id": "GLE FP",
    >>>                       "quantity": 0,
    >>>                       "weight": 0.75,
    >>>                       "way": "Buy"
    >>>                  }
    >>>             ])
    >>>     print(f"{basket_id} updated.")
    >>> else:
    >>>     print("No baskets available!")
    Updating basket with id: 6a41d276-192e-4349-a06a-6966c927bd46
    6a41d276-192e-4349-a06a-6966c927bd46 updated.

    """

    try:
        logger.info("Calling update_basket")
        Client().basket_scan_service.update_basket(
            body=BasketUpdateRequest(
                time_to_live=time_to_live,
                basket_name=basket_name,
                identifier_type=identifier_type,
                nominal_or_quantity=nominal_or_quantity,
                total=total,
                nominal_currency=nominal_currency,
                instruments=instruments,
            ),
            basket_id=basket_id,
            content_type="application/json",
            headers={"x-ap-sdk-operation": "basket_scan.update_basket"},
        )
        logger.info("Called update_basket")

        return True
    except Exception as err:
        logger.error("Error update_basket.")
        check_exception_and_raise(err, logger)


def validate_instruments(
    *,
    identifier_type: Optional[Union[str, IdentifierType]] = None,
    basket_currency: Optional[str] = None,
    instruments: Optional[list[str]] = None,
) -> InstrumentValidationResponse:
    """
    Validate a list of instruments.
    Check if the list is valid for Basket Scan and return invalid instruments.

    Parameters
    ----------
    identifier_type : Union[str, IdentifierType], optional

    basket_currency : str, optional

    instruments : list[str], optional


    Returns
    --------
    InstrumentValidationResponse


    Examples
    --------
    >>> validation_result = validate_instruments(
    >>>     identifier_type="Ticker",
    >>>     instruments=["BAYN GY", "GLE FP"],
    >>>     basket_currency="EUR"
    >>> )
    >>>
    >>> print(json.dumps(validation_result.as_dict(), indent=4))
    {
        "validInstruments": [
            "BAYN GY",
            "GLE FP"
        ],
        "invalidInstruments": []
    }

    """

    try:
        logger.info("Calling validate_instruments")

        response = Client().basket_scan_service.validate_instruments(
            body=InstrumentValidationRequest(
                identifier_type=identifier_type,
                basket_currency=basket_currency,
                instruments=instruments,
            ),
            content_type="application/json",
            headers={"x-ap-sdk-operation": "basket_scan.validate_instruments"},
        )

        output = response
        logger.info("Called validate_instruments")

        return output
    except Exception as err:
        logger.error("Error validate_instruments.")
        check_exception_and_raise(err, logger)
