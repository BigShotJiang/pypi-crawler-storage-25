# pylint: disable=line-too-long,useless-suppression
# coding=utf-8

from copy import deepcopy
from typing import Any, Awaitable

from corehttp.rest import AsyncHttpResponse, HttpRequest
from corehttp.runtime import AsyncPipelineClient, policies
from typing_extensions import Self

from .._utils.serialization import Deserializer, Serializer
from ._configuration import SocGenAPIClientConfiguration
from .operations import (
    basketScanServiceOperations,
    cofBoxServiceOperations,
    curveFollowerServiceOperations,
    fxEventTrackerServiceOperations,
    marketDataServiceOperations,
    sustainableBondScreenerServiceOperations,
)


class SocGenAPIClient:  # pylint: disable=client-accepts-api-version-keyword
    """SG Market workflows.

    :ivar basket_scan_service: basketScanServiceOperations operations
    :vartype basket_scan_service: socgenapi.aio.operations.basketScanServiceOperations
    :ivar curve_follower_service: curveFollowerServiceOperations operations
    :vartype curve_follower_service: socgenapi.aio.operations.curveFollowerServiceOperations
    :ivar fx_event_tracker_service: fxEventTrackerServiceOperations operations
    :vartype fx_event_tracker_service: socgenapi.aio.operations.fxEventTrackerServiceOperations
    :ivar sustainable_bond_screener_service: sustainableBondScreenerServiceOperations operations
    :vartype sustainable_bond_screener_service:
     socgenapi.aio.operations.sustainableBondScreenerServiceOperations
    :ivar market_data_service: marketDataServiceOperations operations
    :vartype market_data_service: socgenapi.aio.operations.marketDataServiceOperations
    :ivar cof_box_service: cofBoxServiceOperations operations
    :vartype cof_box_service: socgenapi.aio.operations.cofBoxServiceOperations
    :keyword endpoint: Service host. Default value is "https://api.analytics.lseg.com".
    :paramtype endpoint: str
    """

    def __init__(  # pylint: disable=missing-client-constructor-parameter-credential
        self, *, endpoint: str = "https://api.analytics.lseg.com", **kwargs: Any
    ) -> None:
        _endpoint = "{endpoint}"
        self._config = SocGenAPIClientConfiguration(endpoint=endpoint, **kwargs)

        _policies = kwargs.pop("policies", None)
        if _policies is None:
            _policies = [
                self._config.headers_policy,
                self._config.user_agent_policy,
                self._config.proxy_policy,
                policies.ContentDecodePolicy(**kwargs),
                self._config.retry_policy,
                self._config.authentication_policy,
                self._config.logging_policy,
            ]
        self._client: AsyncPipelineClient = AsyncPipelineClient(endpoint=_endpoint, policies=_policies, **kwargs)

        self._serialize = Serializer()
        self._deserialize = Deserializer()
        self._serialize.client_side_validation = False
        self.basket_scan_service = basketScanServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.curve_follower_service = curveFollowerServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.fx_event_tracker_service = fxEventTrackerServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.sustainable_bond_screener_service = sustainableBondScreenerServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.market_data_service = marketDataServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.cof_box_service = cofBoxServiceOperations(self._client, self._config, self._serialize, self._deserialize)

    def send_request(
        self, request: HttpRequest, *, stream: bool = False, **kwargs: Any
    ) -> Awaitable[AsyncHttpResponse]:
        """Runs the network request through the client's chained policies.

        >>> from corehttp.rest import HttpRequest
        >>> request = HttpRequest("GET", "https://www.example.org/")
        <HttpRequest [GET], url: 'https://www.example.org/'>
        >>> response = await client.send_request(request)
        <AsyncHttpResponse: 200 OK>

        For more information on this code flow, see https://aka.ms/azsdk/dpcodegen/python/send_request

        :param request: The network request you want to make. Required.
        :type request: ~corehttp.rest.HttpRequest
        :keyword bool stream: Whether the response payload will be streamed. Defaults to False.
        :return: The response of your network call. Does not do error handling on your response.
        :rtype: ~corehttp.rest.AsyncHttpResponse
        """

        request_copy = deepcopy(request)
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }

        request_copy.url = self._client.format_url(request_copy.url, **path_format_arguments)
        return self._client.send_request(request_copy, stream=stream, **kwargs)  # type: ignore

    async def close(self) -> None:
        await self._client.close()

    async def __aenter__(self) -> Self:
        await self._client.__aenter__()
        return self

    async def __aexit__(self, *exc_details: Any) -> None:
        await self._client.__aexit__(*exc_details)
