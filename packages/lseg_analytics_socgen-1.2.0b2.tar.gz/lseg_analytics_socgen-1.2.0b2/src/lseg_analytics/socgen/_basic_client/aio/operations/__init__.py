# coding=utf-8
# pylint: disable=wrong-import-position

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._patch import *  # pylint: disable=unused-wildcard-import

from ._operations import basketScanServiceOperations  # type: ignore
from ._operations import cofBoxServiceOperations  # type: ignore
from ._operations import curveFollowerServiceOperations  # type: ignore
from ._operations import fxEventTrackerServiceOperations  # type: ignore
from ._operations import marketDataServiceOperations  # type: ignore
from ._operations import sustainableBondScreenerServiceOperations  # type: ignore
from ._patch import *
from ._patch import __all__ as _patch_all
from ._patch import patch_sdk as _patch_sdk

__all__ = [
    "basketScanServiceOperations",
    "curveFollowerServiceOperations",
    "fxEventTrackerServiceOperations",
    "sustainableBondScreenerServiceOperations",
    "marketDataServiceOperations",
    "cofBoxServiceOperations",
]
__all__.extend([p for p in _patch_all if p not in __all__])  # pyright: ignore
_patch_sdk()
