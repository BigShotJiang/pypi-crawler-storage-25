# pylint: disable=line-too-long,useless-suppression
# coding=utf-8

from copy import deepcopy
from typing import Any

from corehttp.rest import HttpRequest, HttpResponse
from corehttp.runtime import PipelineClient, policies
from typing_extensions import Self

from ._configuration import SocGenAPIClientConfiguration
from ._utils.serialization import Deserializer, Serializer
from .operations import (
    basketScanServiceOperations,
    cofBoxServiceOperations,
    curveFollowerServiceOperations,
    fxEventTrackerServiceOperations,
    marketDataServiceOperations,
    sustainableBondScreenerServiceOperations,
)


class SocGenAPIClient:  # pylint: disable=client-accepts-api-version-keyword
    """SG Market workflows.

    :ivar basket_scan_service: basketScanServiceOperations operations
    :vartype basket_scan_service: socgenapi.operations.basketScanServiceOperations
    :ivar curve_follower_service: curveFollowerServiceOperations operations
    :vartype curve_follower_service: socgenapi.operations.curveFollowerServiceOperations
    :ivar fx_event_tracker_service: fxEventTrackerServiceOperations operations
    :vartype fx_event_tracker_service: socgenapi.operations.fxEventTrackerServiceOperations
    :ivar sustainable_bond_screener_service: sustainableBondScreenerServiceOperations operations
    :vartype sustainable_bond_screener_service:
     socgenapi.operations.sustainableBondScreenerServiceOperations
    :ivar market_data_service: marketDataServiceOperations operations
    :vartype market_data_service: socgenapi.operations.marketDataServiceOperations
    :ivar cof_box_service: cofBoxServiceOperations operations
    :vartype cof_box_service: socgenapi.operations.cofBoxServiceOperations
    :keyword endpoint: Service host. Default value is "https://api.analytics.lseg.com".
    :paramtype endpoint: str
    """

    def __init__(  # pylint: disable=missing-client-constructor-parameter-credential
        self, *, endpoint: str = "https://api.analytics.lseg.com", **kwargs: Any
    ) -> None:
        _endpoint = "{endpoint}"
        self._config = SocGenAPIClientConfiguration(endpoint=endpoint, **kwargs)

        _policies = kwargs.pop("policies", None)
        if _policies is None:
            _policies = [
                self._config.headers_policy,
                self._config.user_agent_policy,
                self._config.proxy_policy,
                policies.ContentDecodePolicy(**kwargs),
                self._config.retry_policy,
                self._config.authentication_policy,
                self._config.logging_policy,
            ]
        self._client: PipelineClient = PipelineClient(endpoint=_endpoint, policies=_policies, **kwargs)

        self._serialize = Serializer()
        self._deserialize = Deserializer()
        self._serialize.client_side_validation = False
        self.basket_scan_service = basketScanServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.curve_follower_service = curveFollowerServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.fx_event_tracker_service = fxEventTrackerServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.sustainable_bond_screener_service = sustainableBondScreenerServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.market_data_service = marketDataServiceOperations(
            self._client, self._config, self._serialize, self._deserialize
        )
        self.cof_box_service = cofBoxServiceOperations(self._client, self._config, self._serialize, self._deserialize)

    def send_request(self, request: HttpRequest, *, stream: bool = False, **kwargs: Any) -> HttpResponse:
        """Runs the network request through the client's chained policies.

        >>> from corehttp.rest import HttpRequest
        >>> request = HttpRequest("GET", "https://www.example.org/")
        <HttpRequest [GET], url: 'https://www.example.org/'>
        >>> response = client.send_request(request)
        <HttpResponse: 200 OK>

        For more information on this code flow, see https://aka.ms/azsdk/dpcodegen/python/send_request

        :param request: The network request you want to make. Required.
        :type request: ~corehttp.rest.HttpRequest
        :keyword bool stream: Whether the response payload will be streamed. Defaults to False.
        :return: The response of your network call. Does not do error handling on your response.
        :rtype: ~corehttp.rest.HttpResponse
        """

        request_copy = deepcopy(request)
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }

        request_copy.url = self._client.format_url(request_copy.url, **path_format_arguments)
        return self._client.send_request(request_copy, stream=stream, **kwargs)  # type: ignore

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Self:
        self._client.__enter__()
        return self

    def __exit__(self, *exc_details: Any) -> None:
        self._client.__exit__(*exc_details)
