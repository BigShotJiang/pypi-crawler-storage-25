# coding=utf-8

from enum import Enum

from corehttp.utils import CaseInsensitiveEnumMeta


class AdvType(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of AdvType."""

    ADV5D = "Adv5d"
    ADV10D = "Adv10d"
    ADV20D = "Adv20d"
    ADV30D = "Adv30d"
    ADV3_M = "Adv3M"
    ACV = "ACV"
    AOV = "AOV"


class AnalysisType(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of AnalysisType."""

    COF = "Cof"
    FWD_COF = "FwdCof"
    ROLL_DOWN_COF = "RollDownCof"


class BasketTimeToLive(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of BasketTimeToLive."""

    ONE_DAY = "OneDay"
    ONE_WEEK = "OneWeek"
    ONE_MONTH = "OneMonth"
    INFINITE = "Infinite"


class BasketType(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of BasketType."""

    BASKET = "Basket"
    INDEX = "Index"
    YOU_TRACK = "YouTrack"


class BondType(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of BondType."""

    GREEN = "Green"
    SLB = "Slb"
    SOCIAL = "Social"
    SUSTAINABLE = "Sustainable"


class CalculationMethod(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of CalculationMethod."""

    INTERPOLATION = "Interpolation"
    EXTRAPOLATION = "Extrapolation"
    NONE = "None"


class Category(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of Category."""

    OTHER = "Other"
    SOVEREIGN = "Sovereign"
    SUB_SOVEREIGN = "SubSovereign"
    COVERED = "Covered"
    CORPORATES_AND_FINANCIALS = "CorporatesAndFinancials"
    HIGH_YIELD = "HighYield"


class CofType(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of CofType."""

    COF_DIV100PCT = "CofDiv100pct"
    COF_DIV_MARKET = "CofDivMarket"
    COF_DIV_NTR = "CofDivNtr"


class DataType(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of DataType."""

    INTEGER = "Integer"
    DECIMAL = "Decimal"
    TEXT = "Text"
    DATE_TIME = "DateTime"
    UNKNOWN = "Unknown"


class IdentifierType(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of IdentifierType."""

    RIC = "Ric"
    TICKER = "Ticker"
    SEDOL = "Sedol"
    ISIN = "Isin"


class InstrumentsFieldsValuesSortOrder(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of InstrumentsFieldsValuesSortOrder."""

    COUNT_DESC = "CountDesc"
    VALUE_ASC = "ValueAsc"
    VALUE_DESC = "ValueDesc"


class MarketStatus(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of MarketStatus."""

    OPEN = "Open"
    CLOSED = "Closed"
    WEEKEND = "Weekend"
    HOLIDAY = "Holiday"


class MissingValuesReason(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of MissingValuesReason."""

    PRODUCT_ACCESS_IS_DENIED = "ProductAccessIsDenied"
    INSTRUMENT_DOES_NOT_EXIST_OR_ACCESS_IS_DENIED = "InstrumentDoesNotExistOrAccessIsDenied"
    FIELD_DOES_NOT_EXIST_OR_ACCESS_IS_DENIED = "FieldDoesNotExistOrAccessIsDenied"
    FIELD_IS_NOT_AVAILABLE_ON_CURRENT_REFSET = "FieldIsNotAvailableOnCurrentRefset"
    SUB_FIELD_DOES_NOT_EXIST_OR_ACCESS_IS_DENIED = "SubFieldDoesNotExistOrAccessIsDenied"
    COMPUTATION_FAILED = "ComputationFailed"
    COMPUTED_INDICATOR_FORBIDDEN = "ComputedIndicatorForbidden"
    COMPUTED_INDICATOR_PARSING_FAILURE = "ComputedIndicatorParsingFailure"


class NominalOrQuantity(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of NominalOrQuantity."""

    NOMINAL = "Nominal"
    QUANTITY = "Quantity"


class Order(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of Order."""

    ASC = "Asc"
    DESC = "Desc"


class SearchInclude(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of SearchInclude."""

    PRODUCT_NAME = "ProductName"
    DISPLAY_NAME = "DisplayName"


class SharingPolicy(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of SharingPolicy."""

    PRIVATE = "Private"
    SHARED_TO_NAMED_USERS = "SharedToNamedUsers"
    ANYONE_WITH_A_LINK = "AnyoneWithALink"
    PUBLIC = "Public"


class UserAuthorization(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of UserAuthorization."""

    READ_ONLY = "ReadOnly"
    READ_WRITE = "ReadWrite"


class Way(str, Enum, metaclass=CaseInsensitiveEnumMeta):
    """Type of Way."""

    BUY = "Buy"
    SELL = "Sell"
    TOTAL = "Total"
