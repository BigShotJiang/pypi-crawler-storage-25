# pylint: disable=line-too-long,useless-suppression,too-many-lines
# coding=utf-8
# pylint: disable=useless-super-delegation

import datetime
from abc import ABC
from typing import TYPE_CHECKING, Any, Mapping, Optional, Union, overload

from .._utils.model_base import Model as _Model
from .._utils.model_base import rest_field

if TYPE_CHECKING:
    from .. import models as _models


class AdvDistributionDto(_Model):
    """AdvDistributionDto.

    Readonly variables are only populated by the server, and will be ignored when sending a request.

    Attributes
    ----------
    from_property : float
    to : float
    count : float
    """

    from_property: Optional[float] = rest_field(name="from", visibility=["read"])
    to: Optional[float] = rest_field(visibility=["read"])
    count: Optional[float] = rest_field(visibility=["read"])


class AllOrdersAndCostDto(_Model):
    """AllOrdersAndCostDto.

    Attributes
    ----------
    code : str
    sector : str
    index : str
    market_capitalisation : str
    country : str
    isin : str
    ric : str
    sedol : str
    ticker : str
    ticker_composite : str
    name : str
    geo_zone : str
    way : str or ~socgenapi.models.Way
        Known values are: "Buy", "Sell", and "Total".
    share : float
    nominal : float
    weight : float
    cost : float
    impact : float
    volatility : float
    adv_volume : float
    adv_selected : float
    average5_previous_close_auction_volume : float
    cost_weighted : float
    volatility_weighted : float
    spread_weighted : float
    impact_weighted : float
    previous_day_percentage_of_volume : float
    previous_day_turnover : float
    previous_day_day_count : float
    adv_percentage_of_volume : float
    average5_previous_open_auction_percentage_volume : float
    average5_previous_close_auction_percentage_volume : float
    prev_impact_key : str
    prev_liquidity_key : str
    versus_impact_key : str
    versus_liquidity_key : str
    """

    code: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    sector: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    index: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    market_capitalisation: Optional[str] = rest_field(
        name="marketCapitalisation", visibility=["read", "create", "update", "delete", "query"]
    )
    country: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    isin: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    ric: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    sedol: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    ticker: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    ticker_composite: Optional[str] = rest_field(
        name="tickerComposite", visibility=["read", "create", "update", "delete", "query"]
    )
    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    geo_zone: Optional[str] = rest_field(name="geoZone", visibility=["read", "create", "update", "delete", "query"])
    way: Optional[Union[str, "_models.Way"]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Known values are: \"Buy\", \"Sell\", and \"Total\"."""
    share: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    nominal: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    weight: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    cost: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    impact: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    volatility: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    adv_volume: Optional[float] = rest_field(
        name="advVolume", visibility=["read", "create", "update", "delete", "query"]
    )
    adv_selected: Optional[float] = rest_field(
        name="advSelected", visibility=["read", "create", "update", "delete", "query"]
    )
    average5_previous_close_auction_volume: Optional[float] = rest_field(
        name="average5PreviousCloseAuctionVolume", visibility=["read", "create", "update", "delete", "query"]
    )
    cost_weighted: Optional[float] = rest_field(
        name="costWeighted", visibility=["read", "create", "update", "delete", "query"]
    )
    volatility_weighted: Optional[float] = rest_field(
        name="volatilityWeighted", visibility=["read", "create", "update", "delete", "query"]
    )
    spread_weighted: Optional[float] = rest_field(
        name="spreadWeighted", visibility=["read", "create", "update", "delete", "query"]
    )
    impact_weighted: Optional[float] = rest_field(
        name="impactWeighted", visibility=["read", "create", "update", "delete", "query"]
    )
    previous_day_percentage_of_volume: Optional[float] = rest_field(
        name="previousDayPercentageOfVolume", visibility=["read", "create", "update", "delete", "query"]
    )
    previous_day_turnover: Optional[float] = rest_field(
        name="previousDayTurnover", visibility=["read", "create", "update", "delete", "query"]
    )
    previous_day_day_count: Optional[float] = rest_field(
        name="previousDayDayCount", visibility=["read", "create", "update", "delete", "query"]
    )
    adv_percentage_of_volume: Optional[float] = rest_field(
        name="advPercentageOfVolume", visibility=["read", "create", "update", "delete", "query"]
    )
    average5_previous_open_auction_percentage_volume: Optional[float] = rest_field(
        name="average5PreviousOpenAuctionPercentageVolume", visibility=["read", "create", "update", "delete", "query"]
    )
    average5_previous_close_auction_percentage_volume: Optional[float] = rest_field(
        name="average5PreviousCloseAuctionPercentageVolume", visibility=["read", "create", "update", "delete", "query"]
    )
    prev_impact_key: Optional[str] = rest_field(
        name="prevImpactKey", visibility=["read", "create", "update", "delete", "query"]
    )
    prev_liquidity_key: Optional[str] = rest_field(
        name="prevLiquidityKey", visibility=["read", "create", "update", "delete", "query"]
    )
    versus_impact_key: Optional[str] = rest_field(
        name="versusImpactKey", visibility=["read", "create", "update", "delete", "query"]
    )
    versus_liquidity_key: Optional[str] = rest_field(
        name="versusLiquidityKey", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(  # pylint: disable=too-many-locals
        self,
        *,
        code: Optional[str] = None,
        sector: Optional[str] = None,
        index: Optional[str] = None,
        market_capitalisation: Optional[str] = None,
        country: Optional[str] = None,
        isin: Optional[str] = None,
        ric: Optional[str] = None,
        sedol: Optional[str] = None,
        ticker: Optional[str] = None,
        ticker_composite: Optional[str] = None,
        name: Optional[str] = None,
        geo_zone: Optional[str] = None,
        way: Optional[Union[str, "_models.Way"]] = None,
        share: Optional[float] = None,
        nominal: Optional[float] = None,
        weight: Optional[float] = None,
        cost: Optional[float] = None,
        impact: Optional[float] = None,
        volatility: Optional[float] = None,
        adv_volume: Optional[float] = None,
        adv_selected: Optional[float] = None,
        average5_previous_close_auction_volume: Optional[float] = None,
        cost_weighted: Optional[float] = None,
        volatility_weighted: Optional[float] = None,
        spread_weighted: Optional[float] = None,
        impact_weighted: Optional[float] = None,
        previous_day_percentage_of_volume: Optional[float] = None,
        previous_day_turnover: Optional[float] = None,
        previous_day_day_count: Optional[float] = None,
        adv_percentage_of_volume: Optional[float] = None,
        average5_previous_open_auction_percentage_volume: Optional[float] = None,
        average5_previous_close_auction_percentage_volume: Optional[float] = None,
        prev_impact_key: Optional[str] = None,
        prev_liquidity_key: Optional[str] = None,
        versus_impact_key: Optional[str] = None,
        versus_liquidity_key: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class AnalysisRequest(_Model):
    """AnalysisRequest.

    All required parameters must be populated in order to send to server.

    Attributes
    ----------
    analysis_types : list[str or ~socgenapi.models.AnalysisType]
        Analysis results requested (all analysis returned if none specified).
        Available analysis are:<br />

        * <b>Cof</b>: TBD.<br />
        * <b>FwdCof</b>: TBD.<br />
        * <b>RollDownCof</b>: TBD.  The default value is None, needs to be assigned before using.
    instruments : list[~socgenapi.models.AnalysisRequestInstrument]
        The instruments to analyse. Required.  The default value is None, needs
        to be assigned before using.
    start_date : ~datetime.datetime
        The start date.
    end_date : ~datetime.datetime
        The end date.
    cof_types : list[str or ~socgenapi.models.CofType]
        The Cof types ('CofDiv100pct' by default or/and 'CofDivMarket',
        'CofDivNtr). The default value is None, needs to be assigned before
        using.
    min_update_timestamp_utc : ~datetime.datetime
        Minimum UpdateTimestamp (Utc) Format : yyyy-MM-ddTHH:mm:ssZ.
    """

    analysis_types: Optional[list[Union[str, "_models.AnalysisType"]]] = rest_field(
        name="analysisTypes", visibility=["read", "create", "update", "delete", "query"]
    )
    """Analysis results requested (all analysis returned if none specified). Available analysis
     are:<br />
 
     * <b>Cof</b>: TBD.<br />
     * <b>FwdCof</b>: TBD.<br />
     * <b>RollDownCof</b>: TBD."""
    instruments: list["_models.AnalysisRequestInstrument"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """The instruments to analyse. Required."""
    start_date: Optional[datetime.datetime] = rest_field(
        name="startDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    """The start date."""
    end_date: Optional[datetime.datetime] = rest_field(
        name="endDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    """The end date."""
    cof_types: Optional[list[Union[str, "_models.CofType"]]] = rest_field(
        name="cofTypes", visibility=["read", "create", "update", "delete", "query"]
    )
    """The Cof types ('CofDiv100pct' by default or/and 'CofDivMarket', 'CofDivNtr)."""
    min_update_timestamp_utc: Optional[datetime.datetime] = rest_field(
        name="minUpdateTimestampUtc", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    """Minimum UpdateTimestamp (Utc) Format : yyyy-MM-ddTHH:mm:ssZ."""

    @overload
    def __init__(
        self,
        *,
        instruments: list["_models.AnalysisRequestInstrument"],
        analysis_types: Optional[list[Union[str, "_models.AnalysisType"]]] = None,
        start_date: Optional[datetime.datetime] = None,
        end_date: Optional[datetime.datetime] = None,
        cof_types: Optional[list[Union[str, "_models.CofType"]]] = None,
        min_update_timestamp_utc: Optional[datetime.datetime] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class AnalysisRequestInstrument(_Model):
    """AnalysisRequestInstrument.

    All required parameters must be populated in order to send to server.

    Attributes
    ----------
    instrument_code : str
        The instrument code. Required.
    maturities_codes : list[str]
        The instrument maturities (all maturities used if none specified).  The
        default value is None, needs to be assigned before using.
    """

    instrument_code: str = rest_field(name="instrumentCode", visibility=["read", "create", "update", "delete", "query"])
    """The instrument code. Required."""
    maturities_codes: Optional[list[str]] = rest_field(
        name="maturitiesCodes", visibility=["read", "create", "update", "delete", "query"]
    )
    """The instrument maturities (all maturities used if none specified)."""

    @overload
    def __init__(
        self,
        *,
        instrument_code: str,
        maturities_codes: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class BasketAnalysisComputedResponse(_Model):
    """BasketAnalysisComputedResponse.

    Attributes
    ----------
    total_summary_analysis : list[~socgenapi.models.BreakDownAnalysisDto]
        The default value is None, needs to be assigned before using.
    capitalisation_analysis : list[~socgenapi.models.BreakDownAnalysisDto]
        The default value is None, needs to be assigned before using.
    sector_analysis : list[~socgenapi.models.BreakDownAnalysisDto]
        The default value is None, needs to be assigned before using.
    country_analysis : list[~socgenapi.models.CountryBreakDownAnalysisDto]
        The default value is None, needs to be assigned before using.
    index_analysis : list[~socgenapi.models.BreakDownAnalysisDto]
        The default value is None, needs to be assigned before using.
    liquidity_analysis : list[~socgenapi.models.LiquidityImpactDto]
        The default value is None, needs to be assigned before using.
    impact_analysis : list[~socgenapi.models.LiquidityImpactDto]
        The default value is None, needs to be assigned before using.
    largest_predicted_impact : list[~socgenapi.models.MostAndLargestBreakDownsDto]
        The default value is None, needs to be assigned before using.
    largest_position : list[~socgenapi.models.MostAndLargestBreakDownsDto]
        The default value is None, needs to be assigned before using.
    most_liquidity : list[~socgenapi.models.MostAndLargestBreakDownsDto]
        The default value is None, needs to be assigned before using.
    all_orders_and_costs : list[~socgenapi.models.AllOrdersAndCostDto]
        The default value is None, needs to be assigned before using.
    instrument_validation_result : list[~socgenapi.models.StatusDto]
        The default value is None, needs to be assigned before using.
    """

    total_summary_analysis: Optional[list["_models.BreakDownAnalysisDto"]] = rest_field(
        name="totalSummaryAnalysis", visibility=["read", "create", "update", "delete", "query"]
    )
    capitalisation_analysis: Optional[list["_models.BreakDownAnalysisDto"]] = rest_field(
        name="capitalisationAnalysis", visibility=["read", "create", "update", "delete", "query"]
    )
    sector_analysis: Optional[list["_models.BreakDownAnalysisDto"]] = rest_field(
        name="sectorAnalysis", visibility=["read", "create", "update", "delete", "query"]
    )
    country_analysis: Optional[list["_models.CountryBreakDownAnalysisDto"]] = rest_field(
        name="countryAnalysis", visibility=["read", "create", "update", "delete", "query"]
    )
    index_analysis: Optional[list["_models.BreakDownAnalysisDto"]] = rest_field(
        name="indexAnalysis", visibility=["read", "create", "update", "delete", "query"]
    )
    liquidity_analysis: Optional[list["_models.LiquidityImpactDto"]] = rest_field(
        name="liquidityAnalysis", visibility=["read", "create", "update", "delete", "query"]
    )
    impact_analysis: Optional[list["_models.LiquidityImpactDto"]] = rest_field(
        name="impactAnalysis", visibility=["read", "create", "update", "delete", "query"]
    )
    largest_predicted_impact: Optional[list["_models.MostAndLargestBreakDownsDto"]] = rest_field(
        name="largestPredictedImpact", visibility=["read", "create", "update", "delete", "query"]
    )
    largest_position: Optional[list["_models.MostAndLargestBreakDownsDto"]] = rest_field(
        name="largestPosition", visibility=["read", "create", "update", "delete", "query"]
    )
    most_liquidity: Optional[list["_models.MostAndLargestBreakDownsDto"]] = rest_field(
        name="mostLiquidity", visibility=["read", "create", "update", "delete", "query"]
    )
    all_orders_and_costs: Optional[list["_models.AllOrdersAndCostDto"]] = rest_field(
        name="allOrdersAndCosts", visibility=["read", "create", "update", "delete", "query"]
    )
    instrument_validation_result: Optional[list["_models.StatusDto"]] = rest_field(
        name="instrumentValidationResult", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        total_summary_analysis: Optional[list["_models.BreakDownAnalysisDto"]] = None,
        capitalisation_analysis: Optional[list["_models.BreakDownAnalysisDto"]] = None,
        sector_analysis: Optional[list["_models.BreakDownAnalysisDto"]] = None,
        country_analysis: Optional[list["_models.CountryBreakDownAnalysisDto"]] = None,
        index_analysis: Optional[list["_models.BreakDownAnalysisDto"]] = None,
        liquidity_analysis: Optional[list["_models.LiquidityImpactDto"]] = None,
        impact_analysis: Optional[list["_models.LiquidityImpactDto"]] = None,
        largest_predicted_impact: Optional[list["_models.MostAndLargestBreakDownsDto"]] = None,
        largest_position: Optional[list["_models.MostAndLargestBreakDownsDto"]] = None,
        most_liquidity: Optional[list["_models.MostAndLargestBreakDownsDto"]] = None,
        all_orders_and_costs: Optional[list["_models.AllOrdersAndCostDto"]] = None,
        instrument_validation_result: Optional[list["_models.StatusDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class BasketCreationRequest(_Model):
    """BasketCreationRequest.

    All required parameters must be populated in order to send to server.

    Attributes
    ----------
    time_to_live : str or ~socgenapi.models.BasketTimeToLive
        Known values are: "OneDay", "OneWeek", "OneMonth", and "Infinite".
    basket_name : str
    identifier_type : str or ~socgenapi.models.IdentifierType
        Known values are: "Ric", "Ticker", "Sedol", and "Isin".
    nominal_or_quantity : str or ~socgenapi.models.NominalOrQuantity
        Known values are: "Nominal" and "Quantity".
    total : float
    nominal_currency : str
    instruments : list[~socgenapi.models.InstrumentDto]
        Required.  The default value is None, needs to be assigned before
        using.
    """

    time_to_live: Optional[Union[str, "_models.BasketTimeToLive"]] = rest_field(
        name="timeToLive", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"OneDay\", \"OneWeek\", \"OneMonth\", and \"Infinite\"."""
    basket_name: Optional[str] = rest_field(
        name="basketName", visibility=["read", "create", "update", "delete", "query"]
    )
    identifier_type: Optional[Union[str, "_models.IdentifierType"]] = rest_field(
        name="identifierType", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Ric\", \"Ticker\", \"Sedol\", and \"Isin\"."""
    nominal_or_quantity: Optional[Union[str, "_models.NominalOrQuantity"]] = rest_field(
        name="nominalOrQuantity", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Nominal\" and \"Quantity\"."""
    total: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    nominal_currency: Optional[str] = rest_field(
        name="nominalCurrency", visibility=["read", "create", "update", "delete", "query"]
    )
    instruments: list["_models.InstrumentDto"] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Required."""

    @overload
    def __init__(
        self,
        *,
        instruments: list["_models.InstrumentDto"],
        time_to_live: Optional[Union[str, "_models.BasketTimeToLive"]] = None,
        basket_name: Optional[str] = None,
        identifier_type: Optional[Union[str, "_models.IdentifierType"]] = None,
        nominal_or_quantity: Optional[Union[str, "_models.NominalOrQuantity"]] = None,
        total: Optional[float] = None,
        nominal_currency: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class BasketCreationResponse(_Model):
    """BasketCreationResponse.

    Attributes
    ----------
    basket_id : str
    """

    basket_id: Optional[str] = rest_field(name="basketId", visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        basket_id: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["basket_id"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class BasketDto(_Model):
    """BasketDto.

    Attributes
    ----------
    id : str
    identifier_type : str or ~socgenapi.models.IdentifierType
        Known values are: "Ric", "Ticker", "Sedol", and "Isin".
    nominal_or_quantity : str or ~socgenapi.models.NominalOrQuantity
        Known values are: "Nominal" and "Quantity".
    name : str
    time_to_live : ~datetime.datetime
    owner : str
    sharing_policy : str or ~socgenapi.models.SharingPolicy
        Known values are: "Private", "SharedToNamedUsers", "AnyoneWithALink",
        and "Public".
    shared_with_users : dict[str, str or ~socgenapi.models.UserAuthorization]
    total : float
    nominal_currency : str
    instruments : list[~socgenapi.models.InstrumentDto]
        The default value is None, needs to be assigned before using.
    """

    id: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    identifier_type: Optional[Union[str, "_models.IdentifierType"]] = rest_field(
        name="identifierType", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Ric\", \"Ticker\", \"Sedol\", and \"Isin\"."""
    nominal_or_quantity: Optional[Union[str, "_models.NominalOrQuantity"]] = rest_field(
        name="nominalOrQuantity", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Nominal\" and \"Quantity\"."""
    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    time_to_live: Optional[datetime.datetime] = rest_field(
        name="timeToLive", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    owner: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    sharing_policy: Optional[Union[str, "_models.SharingPolicy"]] = rest_field(
        name="sharingPolicy", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Private\", \"SharedToNamedUsers\", \"AnyoneWithALink\", and \"Public\"."""
    shared_with_users: Optional[dict[str, Union[str, "_models.UserAuthorization"]]] = rest_field(
        name="sharedWithUsers", visibility=["read", "create", "update", "delete", "query"]
    )
    total: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    nominal_currency: Optional[str] = rest_field(
        name="nominalCurrency", visibility=["read", "create", "update", "delete", "query"]
    )
    instruments: Optional[list["_models.InstrumentDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        id: Optional[str] = None,  # pylint: disable=redefined-builtin
        identifier_type: Optional[Union[str, "_models.IdentifierType"]] = None,
        nominal_or_quantity: Optional[Union[str, "_models.NominalOrQuantity"]] = None,
        name: Optional[str] = None,
        time_to_live: Optional[datetime.datetime] = None,
        owner: Optional[str] = None,
        sharing_policy: Optional[Union[str, "_models.SharingPolicy"]] = None,
        shared_with_users: Optional[dict[str, Union[str, "_models.UserAuthorization"]]] = None,
        total: Optional[float] = None,
        nominal_currency: Optional[str] = None,
        instruments: Optional[list["_models.InstrumentDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class BasketUpdateRequest(_Model):
    """BasketUpdateRequest.

    All required parameters must be populated in order to send to server.

    Attributes
    ----------
    time_to_live : str or ~socgenapi.models.BasketTimeToLive
        Known values are: "OneDay", "OneWeek", "OneMonth", and "Infinite".
    basket_name : str
    identifier_type : str or ~socgenapi.models.IdentifierType
        Known values are: "Ric", "Ticker", "Sedol", and "Isin".
    nominal_or_quantity : str or ~socgenapi.models.NominalOrQuantity
        Known values are: "Nominal" and "Quantity".
    total : float
    nominal_currency : str
    instruments : list[~socgenapi.models.InstrumentDto]
        Required.  The default value is None, needs to be assigned before
        using.
    """

    time_to_live: Optional[Union[str, "_models.BasketTimeToLive"]] = rest_field(
        name="timeToLive", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"OneDay\", \"OneWeek\", \"OneMonth\", and \"Infinite\"."""
    basket_name: Optional[str] = rest_field(
        name="basketName", visibility=["read", "create", "update", "delete", "query"]
    )
    identifier_type: Optional[Union[str, "_models.IdentifierType"]] = rest_field(
        name="identifierType", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Ric\", \"Ticker\", \"Sedol\", and \"Isin\"."""
    nominal_or_quantity: Optional[Union[str, "_models.NominalOrQuantity"]] = rest_field(
        name="nominalOrQuantity", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Nominal\" and \"Quantity\"."""
    total: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    nominal_currency: Optional[str] = rest_field(
        name="nominalCurrency", visibility=["read", "create", "update", "delete", "query"]
    )
    instruments: list["_models.InstrumentDto"] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Required."""

    @overload
    def __init__(
        self,
        *,
        instruments: list["_models.InstrumentDto"],
        time_to_live: Optional[Union[str, "_models.BasketTimeToLive"]] = None,
        basket_name: Optional[str] = None,
        identifier_type: Optional[Union[str, "_models.IdentifierType"]] = None,
        nominal_or_quantity: Optional[Union[str, "_models.NominalOrQuantity"]] = None,
        total: Optional[float] = None,
        nominal_currency: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class Benchmark(_Model):
    """Benchmark.

    Attributes
    ----------
    code : str
    label : str
    """

    code: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    label: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        code: Optional[str] = None,
        label: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class BenchmarkResponse(_Model):
    """BenchmarkResponse.

    Attributes
    ----------
    benchmarks : list[~socgenapi.models.Benchmark]
        The default value is None, needs to be assigned before using.
    """

    benchmarks: Optional[list["_models.Benchmark"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        benchmarks: Optional[list["_models.Benchmark"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["benchmarks"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class BoundResponse(_Model):
    """BoundResponse.

    Attributes
    ----------
    isin : str
    maturity : ~datetime.datetime
    z_spread : float
    """

    isin: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    maturity: Optional[datetime.datetime] = rest_field(
        visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    z_spread: Optional[float] = rest_field(name="zSpread", visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        isin: Optional[str] = None,
        maturity: Optional[datetime.datetime] = None,
        z_spread: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class BreakDownAnalysisDto(_Model):
    """BreakDownAnalysisDto.

    Attributes
    ----------
    row_key : str
    orders : int
    shares : float
    gross_nominal : float
    net_nominal : float
    weight : float
    percentage_adv : float
    volatility : float
    impact : float
    spread : float
    instruments_contained : list[str]
        The default value is None, needs to be assigned before using.
    """

    row_key: Optional[str] = rest_field(name="rowKey", visibility=["read", "create", "update", "delete", "query"])
    orders: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    shares: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    gross_nominal: Optional[float] = rest_field(
        name="grossNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    net_nominal: Optional[float] = rest_field(
        name="netNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    weight: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    percentage_adv: Optional[float] = rest_field(
        name="percentageAdv", visibility=["read", "create", "update", "delete", "query"]
    )
    volatility: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    impact: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    spread: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    instruments_contained: Optional[list[str]] = rest_field(
        name="instrumentsContained", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        row_key: Optional[str] = None,
        orders: Optional[int] = None,
        shares: Optional[float] = None,
        gross_nominal: Optional[float] = None,
        net_nominal: Optional[float] = None,
        weight: Optional[float] = None,
        percentage_adv: Optional[float] = None,
        volatility: Optional[float] = None,
        impact: Optional[float] = None,
        spread: Optional[float] = None,
        instruments_contained: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class ClosestStrategiesResponse(_Model):
    """ClosestStrategiesResponse.

    Attributes
    ----------
    strategies : ~socgenapi.models.ClosestStrategiesResponseStrategies1
    """

    strategies: Optional["_models.ClosestStrategiesResponseStrategies1"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        strategies: Optional["_models.ClosestStrategiesResponseStrategies1"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["strategies"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class ClosestStrategiesResponseStrategies1(_Model):
    """ClosestStrategiesResponseStrategies1.

    Attributes
    ----------
    swap : list[~socgenapi.models.ClosestStrategyDto]
        The default value is None, needs to be assigned before using.
    spread : list[~socgenapi.models.ClosestStrategyDto]
        The default value is None, needs to be assigned before using.
    butterfly : list[~socgenapi.models.ClosestStrategyDto]
        The default value is None, needs to be assigned before using.
    forward : list[~socgenapi.models.ClosestStrategyDto]
        The default value is None, needs to be assigned before using.
    """

    swap: Optional[list["_models.ClosestStrategyDto"]] = rest_field(
        name="Swap", visibility=["read", "create", "update", "delete", "query"]
    )
    spread: Optional[list["_models.ClosestStrategyDto"]] = rest_field(
        name="Spread", visibility=["read", "create", "update", "delete", "query"]
    )
    butterfly: Optional[list["_models.ClosestStrategyDto"]] = rest_field(
        name="Butterfly", visibility=["read", "create", "update", "delete", "query"]
    )
    forward: Optional[list["_models.ClosestStrategyDto"]] = rest_field(
        name="Forward", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        swap: Optional[list["_models.ClosestStrategyDto"]] = None,
        spread: Optional[list["_models.ClosestStrategyDto"]] = None,
        butterfly: Optional[list["_models.ClosestStrategyDto"]] = None,
        forward: Optional[list["_models.ClosestStrategyDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class ClosestStrategyDto(_Model):
    """ClosestStrategyDto.

    Attributes
    ----------
    curve : str
    leg1 : str
    leg2 : str
    leg3 : str
    forward : str
    duration : str
    alpha : float
    beta : float
    r2 : float
    z_score : float
    """

    curve: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    leg1: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    leg2: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    leg3: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    forward: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    duration: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    alpha: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    beta: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    r2: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    z_score: Optional[float] = rest_field(name="zScore", visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        curve: Optional[str] = None,
        leg1: Optional[str] = None,
        leg2: Optional[str] = None,
        leg3: Optional[str] = None,
        forward: Optional[str] = None,
        duration: Optional[str] = None,
        alpha: Optional[float] = None,
        beta: Optional[float] = None,
        r2: Optional[float] = None,
        z_score: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class CompletionDto(_Model):
    """CompletionDto.

    Attributes
    ----------
    regions : list[~socgenapi.models.RegionDto]
        The default value is None, needs to be assigned before using.
    ways : list[~socgenapi.models.WayDto]
        The default value is None, needs to be assigned before using.
    summary : list[~socgenapi.models.SummaryDailyDto]
        The default value is None, needs to be assigned before using.
    """

    regions: Optional[list["_models.RegionDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    ways: Optional[list["_models.WayDto"]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    summary: Optional[list["_models.SummaryDailyDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        regions: Optional[list["_models.RegionDto"]] = None,
        ways: Optional[list["_models.WayDto"]] = None,
        summary: Optional[list["_models.SummaryDailyDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class Component(_Model):
    """Describe a SubField Component.

    Attributes
    ----------
    name : str
        The SubField Component Name.
    definition : str
        The SubField Component Definition.
    """

    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The SubField Component Name."""
    definition: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The SubField Component Definition."""

    @overload
    def __init__(
        self,
        *,
        name: Optional[str] = None,
        definition: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class CountryBreakDownAnalysisDto(_Model):
    """CountryBreakDownAnalysisDto.

    Attributes
    ----------
    country_iso2 : str
    row_key : str
    orders : int
    shares : float
    gross_nominal : float
    net_nominal : float
    weight : float
    percentage_adv : float
    volatility : float
    impact : float
    spread : float
    instruments_contained : list[str]
        The default value is None, needs to be assigned before using.
    """

    country_iso2: Optional[str] = rest_field(
        name="countryIso2", visibility=["read", "create", "update", "delete", "query"]
    )
    row_key: Optional[str] = rest_field(name="rowKey", visibility=["read", "create", "update", "delete", "query"])
    orders: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    shares: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    gross_nominal: Optional[float] = rest_field(
        name="grossNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    net_nominal: Optional[float] = rest_field(
        name="netNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    weight: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    percentage_adv: Optional[float] = rest_field(
        name="percentageAdv", visibility=["read", "create", "update", "delete", "query"]
    )
    volatility: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    impact: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    spread: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    instruments_contained: Optional[list[str]] = rest_field(
        name="instrumentsContained", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        country_iso2: Optional[str] = None,
        row_key: Optional[str] = None,
        orders: Optional[int] = None,
        shares: Optional[float] = None,
        gross_nominal: Optional[float] = None,
        net_nominal: Optional[float] = None,
        weight: Optional[float] = None,
        percentage_adv: Optional[float] = None,
        volatility: Optional[float] = None,
        impact: Optional[float] = None,
        spread: Optional[float] = None,
        instruments_contained: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class CurveDto(_Model):
    """CurveDto.

    Attributes
    ----------
    curve : str
    reference_rate : str
    dv01_curve : str
    ticker : str
    currency : str
    type : str
    available_maturities : list[str]
        The default value is None, needs to be assigned before using.
    available_places : list[str]
        The default value is None, needs to be assigned before using.
    default_place : str
    is_default : bool
    min_date : ~datetime.datetime
    max_date : ~datetime.datetime
    """

    curve: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    reference_rate: Optional[str] = rest_field(
        name="referenceRate", visibility=["read", "create", "update", "delete", "query"]
    )
    dv01_curve: Optional[str] = rest_field(name="dv01Curve", visibility=["read", "create", "update", "delete", "query"])
    ticker: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    currency: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    type: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"], default="None")
    available_maturities: Optional[list[str]] = rest_field(
        name="availableMaturities", visibility=["read", "create", "update", "delete", "query"]
    )
    available_places: Optional[list[str]] = rest_field(
        name="availablePlaces", visibility=["read", "create", "update", "delete", "query"]
    )
    default_place: Optional[str] = rest_field(
        name="defaultPlace", visibility=["read", "create", "update", "delete", "query"]
    )
    is_default: Optional[bool] = rest_field(
        name="isDefault", visibility=["read", "create", "update", "delete", "query"]
    )
    min_date: Optional[datetime.datetime] = rest_field(
        name="minDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    max_date: Optional[datetime.datetime] = rest_field(
        name="maxDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )

    @overload
    def __init__(
        self,
        *,
        curve: Optional[str] = None,
        reference_rate: Optional[str] = None,
        dv01_curve: Optional[str] = None,
        ticker: Optional[str] = None,
        currency: Optional[str] = None,
        type: Optional[str] = None,
        available_maturities: Optional[list[str]] = None,
        available_places: Optional[list[str]] = None,
        default_place: Optional[str] = None,
        is_default: Optional[bool] = None,
        min_date: Optional[datetime.datetime] = None,
        max_date: Optional[datetime.datetime] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class CurveParameter(_Model):
    """CurveParameter.

    Attributes
    ----------
    currency_pair : str
    event_date : ~datetime.datetime
    ref_date : ~datetime.datetime
    start_date : ~datetime.datetime
    end_date : ~datetime.datetime
    """

    currency_pair: Optional[str] = rest_field(
        name="currencyPair", visibility=["read", "create", "update", "delete", "query"]
    )
    event_date: Optional[datetime.datetime] = rest_field(
        name="eventDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    ref_date: Optional[datetime.datetime] = rest_field(
        name="refDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    start_date: Optional[datetime.datetime] = rest_field(
        name="startDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    end_date: Optional[datetime.datetime] = rest_field(
        name="endDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )

    @overload
    def __init__(
        self,
        *,
        currency_pair: Optional[str] = None,
        event_date: Optional[datetime.datetime] = None,
        ref_date: Optional[datetime.datetime] = None,
        start_date: Optional[datetime.datetime] = None,
        end_date: Optional[datetime.datetime] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class CurveVolResponse(_Model):
    """CurveVolResponse.

    Attributes
    ----------
    curve_parameter : ~socgenapi.models.CurveParameter
    warning_message : str
    event_vol_overnight : list[~socgenapi.models.DailyVolAtDate]
        The default value is None, needs to be assigned before using.
    ref_vol_overnight : list[~socgenapi.models.DailyVolAtDate]
        The default value is None, needs to be assigned before using.
    event_premiums : list[~socgenapi.models.DailyVolAtDate]
        The default value is None, needs to be assigned before using.
    """

    curve_parameter: Optional["_models.CurveParameter"] = rest_field(
        name="curveParameter", visibility=["read", "create", "update", "delete", "query"]
    )
    warning_message: Optional[str] = rest_field(
        name="warningMessage", visibility=["read", "create", "update", "delete", "query"]
    )
    event_vol_overnight: Optional[list["_models.DailyVolAtDate"]] = rest_field(
        name="eventVolOvernight", visibility=["read", "create", "update", "delete", "query"]
    )
    ref_vol_overnight: Optional[list["_models.DailyVolAtDate"]] = rest_field(
        name="refVolOvernight", visibility=["read", "create", "update", "delete", "query"]
    )
    event_premiums: Optional[list["_models.DailyVolAtDate"]] = rest_field(
        name="eventPremiums", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        curve_parameter: Optional["_models.CurveParameter"] = None,
        warning_message: Optional[str] = None,
        event_vol_overnight: Optional[list["_models.DailyVolAtDate"]] = None,
        ref_vol_overnight: Optional[list["_models.DailyVolAtDate"]] = None,
        event_premiums: Optional[list["_models.DailyVolAtDate"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class CustomStrategyCoupleRequest(_Model):
    """CustomStrategyCoupleRequest.

    Attributes
    ----------
    user_strategy : ~socgenapi.models.StrategyRequest
    basic_strategy : ~socgenapi.models.StrategyRequest
    """

    user_strategy: Optional["_models.StrategyRequest"] = rest_field(
        name="userStrategy", visibility=["read", "create", "update", "delete", "query"]
    )
    basic_strategy: Optional["_models.StrategyRequest"] = rest_field(
        name="basicStrategy", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        user_strategy: Optional["_models.StrategyRequest"] = None,
        basic_strategy: Optional["_models.StrategyRequest"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class CustomStrategyCoupleRequestRegressionResponse(_Model):  # pylint: disable=name-too-long
    """CustomStrategyCoupleRequestRegressionResponse.

    Attributes
    ----------
    strategy_couples : list[~socgenapi.models.CustomStrategyCoupleRequestRegressionStrategyCoupleDto]
        The default value is None, needs to be assigned before using.
    """

    strategy_couples: Optional[list["_models.CustomStrategyCoupleRequestRegressionStrategyCoupleDto"]] = rest_field(
        name="strategyCouples", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        strategy_couples: Optional[list["_models.CustomStrategyCoupleRequestRegressionStrategyCoupleDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["strategy_couples"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class CustomStrategyCoupleRequestRegressionStrategyCoupleDto(_Model):  # pylint: disable=name-too-long
    """CustomStrategyCoupleRequestRegressionStrategyCoupleDto.

    Attributes
    ----------
    z_score : list[~socgenapi.models.RegressionPointDto]
        The default value is None, needs to be assigned before using.
    spread : list[~socgenapi.models.RegressionPointDto]
        The default value is None, needs to be assigned before using.
    request : ~socgenapi.models.CustomStrategyCoupleRequest
    alpha : float
    beta : float
    r2 : float
    last_z_score : float
    """

    z_score: Optional[list["_models.RegressionPointDto"]] = rest_field(
        name="zScore", visibility=["read", "create", "update", "delete", "query"]
    )
    spread: Optional[list["_models.RegressionPointDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    request: Optional["_models.CustomStrategyCoupleRequest"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    alpha: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    beta: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    r2: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    last_z_score: Optional[float] = rest_field(
        name="lastZScore", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        z_score: Optional[list["_models.RegressionPointDto"]] = None,
        spread: Optional[list["_models.RegressionPointDto"]] = None,
        request: Optional["_models.CustomStrategyCoupleRequest"] = None,
        alpha: Optional[float] = None,
        beta: Optional[float] = None,
        r2: Optional[float] = None,
        last_z_score: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class DailyCompletionDto(_Model):
    """DailyCompletionDto.

    Attributes
    ----------
    day : int
    pct_completion : float
    """

    day: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    pct_completion: Optional[float] = rest_field(
        name="pctCompletion", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        day: Optional[int] = None,
        pct_completion: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class DailyVolAtDate(_Model):
    """DailyVolAtDate.

    Attributes
    ----------
    date : ~datetime.datetime
    value : float
    straddle_breakeven : float
    """

    date: Optional[datetime.datetime] = rest_field(
        visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    value: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    straddle_breakeven: Optional[float] = rest_field(
        name="straddleBreakeven", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        date: Optional[datetime.datetime] = None,
        value: Optional[float] = None,
        straddle_breakeven: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class EsgScoreInstrument(_Model):
    """EsgScoreInstrument.

    Attributes
    ----------
    instrument_code : str
    name : str
    nominal : float
    esg_score : float
    environmental_score : float
    social_score : float
    governance_score : float
    weight_pct : float
    """

    instrument_code: Optional[str] = rest_field(
        name="instrumentCode", visibility=["read", "create", "update", "delete", "query"]
    )
    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    nominal: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    esg_score: Optional[float] = rest_field(name="esgScore", visibility=["read", "create", "update", "delete", "query"])
    environmental_score: Optional[float] = rest_field(
        name="environmentalScore", visibility=["read", "create", "update", "delete", "query"]
    )
    social_score: Optional[float] = rest_field(
        name="socialScore", visibility=["read", "create", "update", "delete", "query"]
    )
    governance_score: Optional[float] = rest_field(
        name="governanceScore", visibility=["read", "create", "update", "delete", "query"]
    )
    weight_pct: Optional[float] = rest_field(
        name="weightPct", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        instrument_code: Optional[str] = None,
        name: Optional[str] = None,
        nominal: Optional[float] = None,
        esg_score: Optional[float] = None,
        environmental_score: Optional[float] = None,
        social_score: Optional[float] = None,
        governance_score: Optional[float] = None,
        weight_pct: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class ExecutionDto(_Model):
    """ExecutionDto.

    Attributes
    ----------
    time_frame : str
    average_adv_percent : float
    maximum_advpercent : float
    worst_instruments : list[~socgenapi.models.InstrumentAbaqueDto]
        The default value is None, needs to be assigned before using.
    """

    time_frame: Optional[str] = rest_field(name="timeFrame", visibility=["read", "create", "update", "delete", "query"])
    average_adv_percent: Optional[float] = rest_field(
        name="averageAdvPercent", visibility=["read", "create", "update", "delete", "query"]
    )
    maximum_advpercent: Optional[float] = rest_field(
        name="maximumAdvpercent", visibility=["read", "create", "update", "delete", "query"]
    )
    worst_instruments: Optional[list["_models.InstrumentAbaqueDto"]] = rest_field(
        name="worstInstruments", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        time_frame: Optional[str] = None,
        average_adv_percent: Optional[float] = None,
        maximum_advpercent: Optional[float] = None,
        worst_instruments: Optional[list["_models.InstrumentAbaqueDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class ExecutionResponse(_Model):
    """ExecutionResponse.

    Attributes
    ----------
    regions : list[~socgenapi.models.RegionAbaqueDto]
        The default value is None, needs to be assigned before using.
    """

    regions: Optional[list["_models.RegionAbaqueDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        regions: Optional[list["_models.RegionAbaqueDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["regions"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class FactorAnalysis(_Model):
    """FactorAnalysis.

    Attributes
    ----------
    value : float
    momentum : float
    low_risk : float
    fundamental_quality : float
    low_size : float
    growth : float
    duration : float
    inflation : float
    """

    value: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    momentum: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    low_risk: Optional[float] = rest_field(name="lowRisk", visibility=["read", "create", "update", "delete", "query"])
    fundamental_quality: Optional[float] = rest_field(
        name="fundamentalQuality", visibility=["read", "create", "update", "delete", "query"]
    )
    low_size: Optional[float] = rest_field(name="lowSize", visibility=["read", "create", "update", "delete", "query"])
    growth: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    duration: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    inflation: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        value: Optional[float] = None,
        momentum: Optional[float] = None,
        low_risk: Optional[float] = None,
        fundamental_quality: Optional[float] = None,
        low_size: Optional[float] = None,
        growth: Optional[float] = None,
        duration: Optional[float] = None,
        inflation: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class FactorsResponse(_Model):
    """FactorsResponse.

    Attributes
    ----------
    basket_exposure : ~socgenapi.models.FactorAnalysis
    benchmark_exposure : ~socgenapi.models.FactorAnalysis
    basket_vs_benchmark_exposure : ~socgenapi.models.FactorAnalysis
    instruments_exposure : list[~socgenapi.models.PerInstrumentFactorAnalysis]
        The default value is None, needs to be assigned before using.
    basket_distribution_per_country : dict[str, float]
    benchmark_distribution_per_country : dict[str, float]
    basket_distribution_per_sector : dict[str, float]
    benchmark_distribution_per_sector : dict[str, float]
    invalid_basket_instruments : list[str]
        The default value is None, needs to be assigned before using.
    invalid_benchmark_instruments : list[str]
        The default value is None, needs to be assigned before using.
    """

    basket_exposure: Optional["_models.FactorAnalysis"] = rest_field(
        name="basketExposure", visibility=["read", "create", "update", "delete", "query"]
    )
    benchmark_exposure: Optional["_models.FactorAnalysis"] = rest_field(
        name="benchmarkExposure", visibility=["read", "create", "update", "delete", "query"]
    )
    basket_vs_benchmark_exposure: Optional["_models.FactorAnalysis"] = rest_field(
        name="basketVsBenchmarkExposure", visibility=["read", "create", "update", "delete", "query"]
    )
    instruments_exposure: Optional[list["_models.PerInstrumentFactorAnalysis"]] = rest_field(
        name="instrumentsExposure", visibility=["read", "create", "update", "delete", "query"]
    )
    basket_distribution_per_country: Optional[dict[str, float]] = rest_field(
        name="basketDistributionPerCountry", visibility=["read", "create", "update", "delete", "query"]
    )
    benchmark_distribution_per_country: Optional[dict[str, float]] = rest_field(
        name="benchmarkDistributionPerCountry", visibility=["read", "create", "update", "delete", "query"]
    )
    basket_distribution_per_sector: Optional[dict[str, float]] = rest_field(
        name="basketDistributionPerSector", visibility=["read", "create", "update", "delete", "query"]
    )
    benchmark_distribution_per_sector: Optional[dict[str, float]] = rest_field(
        name="benchmarkDistributionPerSector", visibility=["read", "create", "update", "delete", "query"]
    )
    invalid_basket_instruments: Optional[list[str]] = rest_field(
        name="invalidBasketInstruments", visibility=["read", "create", "update", "delete", "query"]
    )
    invalid_benchmark_instruments: Optional[list[str]] = rest_field(
        name="invalidBenchmarkInstruments", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        basket_exposure: Optional["_models.FactorAnalysis"] = None,
        benchmark_exposure: Optional["_models.FactorAnalysis"] = None,
        basket_vs_benchmark_exposure: Optional["_models.FactorAnalysis"] = None,
        instruments_exposure: Optional[list["_models.PerInstrumentFactorAnalysis"]] = None,
        basket_distribution_per_country: Optional[dict[str, float]] = None,
        benchmark_distribution_per_country: Optional[dict[str, float]] = None,
        basket_distribution_per_sector: Optional[dict[str, float]] = None,
        benchmark_distribution_per_sector: Optional[dict[str, float]] = None,
        invalid_basket_instruments: Optional[list[str]] = None,
        invalid_benchmark_instruments: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class FieldDescription(_Model):
    """Describe a Field.

    Attributes
    ----------
    name : str
        The Field Name.
    definition : str
        The Field Definition.
    data_type : str or ~socgenapi.models.DataType
        Known values are: "Integer", "Decimal", "Text", "DateTime", and
        "Unknown".
    is_time_series : bool
        Whether the Field is Historical or only the last value is available.
    sub_fields : list[~socgenapi.models.SubField]
        Descriptions of available SubFields on a Field.  The default value is
        None, needs to be assigned before using.
    """

    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The Field Name."""
    definition: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The Field Definition."""
    data_type: Optional[Union[str, "_models.DataType"]] = rest_field(
        name="dataType", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Integer\", \"Decimal\", \"Text\", \"DateTime\", and \"Unknown\"."""
    is_time_series: Optional[bool] = rest_field(
        name="isTimeSeries", visibility=["read", "create", "update", "delete", "query"]
    )
    """Whether the Field is Historical or only the last value is available."""
    sub_fields: Optional[list["_models.SubField"]] = rest_field(
        name="subFields", visibility=["read", "create", "update", "delete", "query"]
    )
    """Descriptions of available SubFields on a Field."""

    @overload
    def __init__(
        self,
        *,
        name: Optional[str] = None,
        definition: Optional[str] = None,
        data_type: Optional[Union[str, "_models.DataType"]] = None,
        is_time_series: Optional[bool] = None,
        sub_fields: Optional[list["_models.SubField"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class FieldValue(_Model):
    """FieldValue.

    Attributes
    ----------
    value : any
    count : int
    """

    value: Optional[Any] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    count: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        value: Optional[Any] = None,
        count: Optional[int] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class GetBasketResponse(_Model):
    """GetBasketResponse.

    Attributes
    ----------
    basket : ~socgenapi.models.BasketDto
    """

    basket: Optional["_models.BasketDto"] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        basket: Optional["_models.BasketDto"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["basket"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class GetBasketsResponse(_Model):
    """GetBasketsResponse.

    Attributes
    ----------
    baskets : list[~socgenapi.models.BasketDto]
        The default value is None, needs to be assigned before using.
    """

    baskets: Optional[list["_models.BasketDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        baskets: Optional[list["_models.BasketDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["baskets"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class GetCurvesResponse(_Model):
    """GetCurvesResponse.

    Attributes
    ----------
    curves : list[~socgenapi.models.CurveDto]
        The default value is None, needs to be assigned before using.
    """

    curves: Optional[list["_models.CurveDto"]] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        curves: Optional[list["_models.CurveDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["curves"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class GetEsgResponse(_Model):
    """GetEsgResponse.

    Attributes
    ----------
    invalid_instruments : list[str]
        The default value is None, needs to be assigned before using.
    instruments : list[~socgenapi.models.EsgScoreInstrument]
        The default value is None, needs to be assigned before using.
    weighted_average_by_nominal : ~socgenapi.models.WeightedAverageByNominal
    """

    invalid_instruments: Optional[list[str]] = rest_field(
        name="invalidInstruments", visibility=["read", "create", "update", "delete", "query"]
    )
    instruments: Optional[list["_models.EsgScoreInstrument"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    weighted_average_by_nominal: Optional["_models.WeightedAverageByNominal"] = rest_field(
        name="weightedAverageByNominal", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        invalid_instruments: Optional[list[str]] = None,
        instruments: Optional[list["_models.EsgScoreInstrument"]] = None,
        weighted_average_by_nominal: Optional["_models.WeightedAverageByNominal"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class GetSustainableBondsResponse(_Model):
    """GetSustainableBondsResponse.

    Attributes
    ----------
    sustainable_bonds : list[~socgenapi.models.SustainableBondResponse]
        The default value is None, needs to be assigned before using.
    """

    sustainable_bonds: Optional[list["_models.SustainableBondResponse"]] = rest_field(
        name="sustainableBonds", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        sustainable_bonds: Optional[list["_models.SustainableBondResponse"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["sustainable_bonds"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class HedgeStrategyCoupleRequest(_Model):
    """HedgeStrategyCoupleRequest.

    Attributes
    ----------
    user_strategy : ~socgenapi.models.StrategyRequest
    hedging_strategy : ~socgenapi.models.StrategyRequest
    """

    user_strategy: Optional["_models.StrategyRequest"] = rest_field(
        name="userStrategy", visibility=["read", "create", "update", "delete", "query"]
    )
    hedging_strategy: Optional["_models.StrategyRequest"] = rest_field(
        name="hedgingStrategy", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        user_strategy: Optional["_models.StrategyRequest"] = None,
        hedging_strategy: Optional["_models.StrategyRequest"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class HedgingSimulationResponse(_Model):
    """HedgingSimulationResponse.

    Attributes
    ----------
    strategy_couples : list[~socgenapi.models.HedgingSimulationStrategyCoupleDto]
        The default value is None, needs to be assigned before using.
    """

    strategy_couples: Optional[list["_models.HedgingSimulationStrategyCoupleDto"]] = rest_field(
        name="strategyCouples", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        strategy_couples: Optional[list["_models.HedgingSimulationStrategyCoupleDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["strategy_couples"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class HedgingSimulationStrategyCoupleDto(_Model):
    """HedgingSimulationStrategyCoupleDto.

    Attributes
    ----------
    request : ~socgenapi.models.HedgeStrategyCoupleRequest
    hedging_nominal : float
    beta : float
    """

    request: Optional["_models.HedgeStrategyCoupleRequest"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    hedging_nominal: Optional[float] = rest_field(
        name="hedgingNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    beta: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        request: Optional["_models.HedgeStrategyCoupleRequest"] = None,
        hedging_nominal: Optional[float] = None,
        beta: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class HistoricalDataDto(_Model):
    """HistoricalDataDto.

    Attributes
    ----------
    date : ~datetime.datetime
    z_spread : float
    lower_bound_z_spread : float
    upper_bound_z_spread : float
    z_spread_comparable : float
    greenium : float
    """

    date: Optional[datetime.datetime] = rest_field(
        visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    z_spread: Optional[float] = rest_field(name="zSpread", visibility=["read", "create", "update", "delete", "query"])
    lower_bound_z_spread: Optional[float] = rest_field(
        name="lowerBoundZSpread", visibility=["read", "create", "update", "delete", "query"]
    )
    upper_bound_z_spread: Optional[float] = rest_field(
        name="upperBoundZSpread", visibility=["read", "create", "update", "delete", "query"]
    )
    z_spread_comparable: Optional[float] = rest_field(
        name="zSpreadComparable", visibility=["read", "create", "update", "delete", "query"]
    )
    greenium: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        date: Optional[datetime.datetime] = None,
        z_spread: Optional[float] = None,
        lower_bound_z_spread: Optional[float] = None,
        upper_bound_z_spread: Optional[float] = None,
        z_spread_comparable: Optional[float] = None,
        greenium: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class HistoricalDataRequest(_Model):
    """HistoricalDataRequest.

    All required parameters must be populated in order to send to server.

    Attributes
    ----------
    isins : list[str]
        Required.  The default value is None, needs to be assigned before
        using.
    start_date : ~datetime.datetime
    end_date : ~datetime.datetime
    """

    isins: list[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Required."""
    start_date: Optional[datetime.datetime] = rest_field(
        name="startDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    end_date: Optional[datetime.datetime] = rest_field(
        name="endDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )

    @overload
    def __init__(
        self,
        *,
        isins: list[str],
        start_date: Optional[datetime.datetime] = None,
        end_date: Optional[datetime.datetime] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class InnerError(_Model):
    """An object that contains the detailed information in case of a blocking error in calculation.

    All required parameters must be populated in order to send to server.

    Attributes
    ----------
    key : str
        The specification of the request in which an error occurs. Required.
    reason : str
        The reason why an error occurs. Required.
    name : str
        The name of the property causing the error.
    invalid_name : str
        The name of the invalid property.
    """

    key: str = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The specification of the request in which an error occurs. Required."""
    reason: str = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The reason why an error occurs. Required."""
    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The name of the property causing the error."""
    invalid_name: Optional[str] = rest_field(
        name="invalidName", visibility=["read", "create", "update", "delete", "query"]
    )
    """The name of the invalid property."""

    @overload
    def __init__(
        self,
        *,
        key: str,
        reason: str,
        name: Optional[str] = None,
        invalid_name: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class InstrumentAbaqueDto(_Model):
    """InstrumentAbaqueDto.

    Attributes
    ----------
    id : str
    adv_percentage : float
    """

    id: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    adv_percentage: Optional[float] = rest_field(
        name="advPercentage", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        id: Optional[str] = None,  # pylint: disable=redefined-builtin
        adv_percentage: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class InstrumentDto(_Model):
    """InstrumentDto.

    Attributes
    ----------
    id : str
    quantity : float
    weight : float
    way : str or ~socgenapi.models.Way
        Known values are: "Buy", "Sell", and "Total".
    """

    id: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    quantity: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    weight: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    way: Optional[Union[str, "_models.Way"]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Known values are: \"Buy\", \"Sell\", and \"Total\"."""

    @overload
    def __init__(
        self,
        *,
        id: Optional[str] = None,  # pylint: disable=redefined-builtin
        quantity: Optional[float] = None,
        weight: Optional[float] = None,
        way: Optional[Union[str, "_models.Way"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class InstrumentValidationRequest(_Model):
    """InstrumentValidationRequest.

    Attributes
    ----------
    identifier_type : str or ~socgenapi.models.IdentifierType
        Known values are: "Ric", "Ticker", "Sedol", and "Isin".
    basket_currency : str
    instruments : list[str]
        The default value is None, needs to be assigned before using.
    """

    identifier_type: Optional[Union[str, "_models.IdentifierType"]] = rest_field(
        name="identifierType", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Ric\", \"Ticker\", \"Sedol\", and \"Isin\"."""
    basket_currency: Optional[str] = rest_field(
        name="basketCurrency", visibility=["read", "create", "update", "delete", "query"]
    )
    instruments: Optional[list[str]] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        identifier_type: Optional[Union[str, "_models.IdentifierType"]] = None,
        basket_currency: Optional[str] = None,
        instruments: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class InstrumentValidationResponse(_Model):
    """InstrumentValidationResponse.

    Attributes
    ----------
    valid_instruments : list[str]
        The default value is None, needs to be assigned before using.
    invalid_instruments : list[~socgenapi.models.StatusDto]
        The default value is None, needs to be assigned before using.
    """

    valid_instruments: Optional[list[str]] = rest_field(
        name="validInstruments", visibility=["read", "create", "update", "delete", "query"]
    )
    invalid_instruments: Optional[list["_models.StatusDto"]] = rest_field(
        name="invalidInstruments", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        valid_instruments: Optional[list[str]] = None,
        invalid_instruments: Optional[list["_models.StatusDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class LastQuotesByConstraintsRequest(_Model):
    """Last Quotes Request with instruments defined by constraints.

    Attributes
    ----------
    refset : str
        The refset you want to query.
    filter : str
        The query describing the instruments you are looking for. `learn more
        about the syntax </data/instruments-filter-syntax.md>`_.
    fields : list[~socgenapi.models.QuoteField]
        The list of fields you want to query.  The default value is None, needs
        to be assigned before using.
    page : int
        Page index (1 based).
    page_size : int
    sort_criteria : list[~socgenapi.models.SortCriterion]
        An optional list of sorting criterion. Default to ascending instrument
        name.  The default value is None, needs to be assigned before using.
    """

    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The refset you want to query."""
    filter: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The query describing the instruments you are looking for. `learn more about the syntax
     </data/instruments-filter-syntax.md>`_."""
    fields: Optional[list["_models.QuoteField"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """The list of fields you want to query."""
    page: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Page index (1 based)."""
    page_size: Optional[int] = rest_field(name="pageSize", visibility=["read", "create", "update", "delete", "query"])
    sort_criteria: Optional[list["_models.SortCriterion"]] = rest_field(
        name="sortCriteria", visibility=["read", "create", "update", "delete", "query"]
    )
    """An optional list of sorting criterion. Default to ascending instrument name."""

    @overload
    def __init__(
        self,
        *,
        refset: Optional[str] = None,
        filter: Optional[str] = None,  # pylint: disable=redefined-builtin
        fields: Optional[list["_models.QuoteField"]] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        sort_criteria: Optional[list["_models.SortCriterion"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class LastQuotesRequest(_Model):
    """Last Quotes Request.

    Attributes
    ----------
    refset : str
        The refset you want to query.
    instruments : list[str]
        The list of instruments you want to query.  The default value is None,
        needs to be assigned before using.
    fields : list[~socgenapi.models.QuoteField]
        The list of fields you want to query.  The default value is None, needs
        to be assigned before using.
    """

    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The refset you want to query."""
    instruments: Optional[list[str]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The list of instruments you want to query."""
    fields: Optional[list["_models.QuoteField"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """The list of fields you want to query."""

    @overload
    def __init__(
        self,
        *,
        refset: Optional[str] = None,
        instruments: Optional[list[str]] = None,
        fields: Optional[list["_models.QuoteField"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class LiquidityImpactDto(_Model):
    """LiquidityImpactDto.

    Attributes
    ----------
    row_key : str
    prev_day_nominal : float
    prev_day_share : float
    prev_day_weight : float
    prev_day_order_count : float
    prev_instruments_contained : list[str]
        The default value is None, needs to be assigned before using.
    versus_nominal : float
    versus_share : float
    versus_weight : float
    versus_order_count : float
    versus_instruments_contained : list[str]
        The default value is None, needs to be assigned before using.
    """

    row_key: Optional[str] = rest_field(name="rowKey", visibility=["read", "create", "update", "delete", "query"])
    prev_day_nominal: Optional[float] = rest_field(
        name="prevDayNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    prev_day_share: Optional[float] = rest_field(
        name="prevDayShare", visibility=["read", "create", "update", "delete", "query"]
    )
    prev_day_weight: Optional[float] = rest_field(
        name="prevDayWeight", visibility=["read", "create", "update", "delete", "query"]
    )
    prev_day_order_count: Optional[float] = rest_field(
        name="prevDayOrderCount", visibility=["read", "create", "update", "delete", "query"]
    )
    prev_instruments_contained: Optional[list[str]] = rest_field(
        name="prevInstrumentsContained", visibility=["read", "create", "update", "delete", "query"]
    )
    versus_nominal: Optional[float] = rest_field(
        name="versusNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    versus_share: Optional[float] = rest_field(
        name="versusShare", visibility=["read", "create", "update", "delete", "query"]
    )
    versus_weight: Optional[float] = rest_field(
        name="versusWeight", visibility=["read", "create", "update", "delete", "query"]
    )
    versus_order_count: Optional[float] = rest_field(
        name="versusOrderCount", visibility=["read", "create", "update", "delete", "query"]
    )
    versus_instruments_contained: Optional[list[str]] = rest_field(
        name="versusInstrumentsContained", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        row_key: Optional[str] = None,
        prev_day_nominal: Optional[float] = None,
        prev_day_share: Optional[float] = None,
        prev_day_weight: Optional[float] = None,
        prev_day_order_count: Optional[float] = None,
        prev_instruments_contained: Optional[list[str]] = None,
        versus_nominal: Optional[float] = None,
        versus_share: Optional[float] = None,
        versus_weight: Optional[float] = None,
        versus_order_count: Optional[float] = None,
        versus_instruments_contained: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class ListSourceResponse(_Model):
    """Describe a set of Sources.

    Attributes
    ----------
    sources : list[~socgenapi.models.SourceDescription]
        Descriptions of available Sources.  The default value is None, needs to
        be assigned before using.
    """

    sources: Optional[list["_models.SourceDescription"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Descriptions of available Sources."""

    @overload
    def __init__(
        self,
        sources: Optional[list["_models.SourceDescription"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["sources"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class LiveQuote(_Model):
    """LiveQuote.

    Attributes
    ----------
    instrument : str
    field : str
    sub_fields : dict[str, str]
    missing_reason : str or ~socgenapi.models.MissingValuesReason
        Known values are: "ProductAccessIsDenied",
        "InstrumentDoesNotExistOrAccessIsDenied",
        "FieldDoesNotExistOrAccessIsDenied",
        "FieldIsNotAvailableOnCurrentRefset",
        "SubFieldDoesNotExistOrAccessIsDenied", "ComputationFailed",
        "ComputedIndicatorForbidden", and "ComputedIndicatorParsingFailure".
    missing_reason_details : str
    data_type : str or ~socgenapi.models.DataType
        Known values are: "Integer", "Decimal", "Text", "DateTime", and
        "Unknown".
    quote_value : ~socgenapi.models.LiveQuoteValue
    """

    instrument: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    field: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    sub_fields: Optional[dict[str, str]] = rest_field(
        name="subFields", visibility=["read", "create", "update", "delete", "query"]
    )
    missing_reason: Optional[Union[str, "_models.MissingValuesReason"]] = rest_field(
        name="missingReason", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"ProductAccessIsDenied\", \"InstrumentDoesNotExistOrAccessIsDenied\",
     \"FieldDoesNotExistOrAccessIsDenied\", \"FieldIsNotAvailableOnCurrentRefset\",
     \"SubFieldDoesNotExistOrAccessIsDenied\", \"ComputationFailed\",
     \"ComputedIndicatorForbidden\", and \"ComputedIndicatorParsingFailure\"."""
    missing_reason_details: Optional[str] = rest_field(
        name="missingReasonDetails", visibility=["read", "create", "update", "delete", "query"]
    )
    data_type: Optional[Union[str, "_models.DataType"]] = rest_field(
        name="dataType", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Integer\", \"Decimal\", \"Text\", \"DateTime\", and \"Unknown\"."""
    quote_value: Optional["_models.LiveQuoteValue"] = rest_field(
        name="quoteValue", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        instrument: Optional[str] = None,
        field: Optional[str] = None,
        sub_fields: Optional[dict[str, str]] = None,
        missing_reason: Optional[Union[str, "_models.MissingValuesReason"]] = None,
        missing_reason_details: Optional[str] = None,
        data_type: Optional[Union[str, "_models.DataType"]] = None,
        quote_value: Optional["_models.LiveQuoteValue"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class LiveQuotesRequest(_Model):
    """LiveQuotesRequest.

    Attributes
    ----------
    instruments : list[str]
        The list of instruments you want to query.  The default value is None,
        needs to be assigned before using.
    fields : list[~socgenapi.models.QuoteField]
        The list of fields you want to query.  The default value is None, needs
        to be assigned before using.
    cross_instruments_formulas : list[str]
        A list of indicators computed over many instruments.  The default value
        is None, needs to be assigned before using.
    """

    instruments: Optional[list[str]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The list of instruments you want to query."""
    fields: Optional[list["_models.QuoteField"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """The list of fields you want to query."""
    cross_instruments_formulas: Optional[list[str]] = rest_field(
        name="crossInstrumentsFormulas", visibility=["read", "create", "update", "delete", "query"]
    )
    """A list of indicators computed over many instruments."""

    @overload
    def __init__(
        self,
        *,
        instruments: Optional[list[str]] = None,
        fields: Optional[list["_models.QuoteField"]] = None,
        cross_instruments_formulas: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class LiveQuotesResponse(_Model):
    """LiveQuotesResponse.

    Attributes
    ----------
    quotes : list[~socgenapi.models.LiveQuote]
        The default value is None, needs to be assigned before using.
    """

    quotes: Optional[list["_models.LiveQuote"]] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        quotes: Optional[list["_models.LiveQuote"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["quotes"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class LiveQuoteValue(_Model):
    """LiveQuoteValue.

    Attributes
    ----------
    date : ~datetime.datetime
    value : any
    """

    date: Optional[datetime.datetime] = rest_field(
        visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    value: Optional[Any] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        date: Optional[datetime.datetime] = None,
        value: Optional[Any] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class LookupInstrumentsFieldsValuesRequest(_Model):
    """LookupInstrumentsFieldsValuesRequest.

    Attributes
    ----------
    filter : str
        The query describing the instruments you are looking for. `learn more
        about the syntax </data/instruments-filter-syntax.md>`_.
    sort : str or ~socgenapi.models.InstrumentsFieldsValuesSortOrder
        Known values are: "CountDesc", "ValueAsc", and "ValueDesc".
    top : int
    """

    filter: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The query describing the instruments you are looking for. `learn more about the syntax
     </data/instruments-filter-syntax.md>`_."""
    sort: Optional[Union[str, "_models.InstrumentsFieldsValuesSortOrder"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"CountDesc\", \"ValueAsc\", and \"ValueDesc\"."""
    top: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        filter: Optional[str] = None,  # pylint: disable=redefined-builtin
        sort: Optional[Union[str, "_models.InstrumentsFieldsValuesSortOrder"]] = None,
        top: Optional[int] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class LookupInstrumentsFieldsValuesResponse(_Model):
    """LookupInstrumentsFieldsValuesResponse.

    Attributes
    ----------
    field_values : list[~socgenapi.models.FieldValue]
        The default value is None, needs to be assigned before using.
    total_field_values : int
    total_matching_instruments : int
    """

    field_values: Optional[list["_models.FieldValue"]] = rest_field(
        name="fieldValues", visibility=["read", "create", "update", "delete", "query"]
    )
    total_field_values: Optional[int] = rest_field(
        name="totalFieldValues", visibility=["read", "create", "update", "delete", "query"]
    )
    total_matching_instruments: Optional[int] = rest_field(
        name="totalMatchingInstruments", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        field_values: Optional[list["_models.FieldValue"]] = None,
        total_field_values: Optional[int] = None,
        total_matching_instruments: Optional[int] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class MarketEvent(_Model):
    """MarketEvent.

    Attributes
    ----------
    event_date : ~datetime.datetime
    event_title : str
    """

    event_date: Optional[datetime.datetime] = rest_field(
        name="eventDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    event_title: Optional[str] = rest_field(
        name="eventTitle", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        event_date: Optional[datetime.datetime] = None,
        event_title: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class MatchInstrument(_Model):
    """MatchInstrument.

    Attributes
    ----------
    instrument : str
    product : str
    display_name : str
    """

    instrument: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    product: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    display_name: Optional[str] = rest_field(
        name="displayName", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        instrument: Optional[str] = None,
        product: Optional[str] = None,
        display_name: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class MostAndLargestBreakDownsDto(_Model):
    """MostAndLargestBreakDownsDto.

    Attributes
    ----------
    way : str or ~socgenapi.models.Way
        Known values are: "Buy", "Sell", and "Total".
    nominal : float
    weight : float
    percentage_adv : float
    theorical_impact : float
    code : str
    """

    way: Optional[Union[str, "_models.Way"]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Known values are: \"Buy\", \"Sell\", and \"Total\"."""
    nominal: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    weight: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    percentage_adv: Optional[float] = rest_field(
        name="percentageAdv", visibility=["read", "create", "update", "delete", "query"]
    )
    theorical_impact: Optional[float] = rest_field(
        name="theoricalImpact", visibility=["read", "create", "update", "delete", "query"]
    )
    code: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        way: Optional[Union[str, "_models.Way"]] = None,
        nominal: Optional[float] = None,
        weight: Optional[float] = None,
        percentage_adv: Optional[float] = None,
        theorical_impact: Optional[float] = None,
        code: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class PerInstrumentFactorAnalysis(_Model):
    """PerInstrumentFactorAnalysis.

    Attributes
    ----------
    instrument_code : str
    instrument_name : str
    country : str
    sector : str
    weight : float
    adjusted_weight : float
    exposure : ~socgenapi.models.FactorAnalysis
    """

    instrument_code: Optional[str] = rest_field(
        name="instrumentCode", visibility=["read", "create", "update", "delete", "query"]
    )
    instrument_name: Optional[str] = rest_field(
        name="instrumentName", visibility=["read", "create", "update", "delete", "query"]
    )
    country: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    sector: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    weight: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    adjusted_weight: Optional[float] = rest_field(
        name="adjustedWeight", visibility=["read", "create", "update", "delete", "query"]
    )
    exposure: Optional["_models.FactorAnalysis"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        instrument_code: Optional[str] = None,
        instrument_name: Optional[str] = None,
        country: Optional[str] = None,
        sector: Optional[str] = None,
        weight: Optional[float] = None,
        adjusted_weight: Optional[float] = None,
        exposure: Optional["_models.FactorAnalysis"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class PostHistoricalDataResponse(_Model):
    """PostHistoricalDataResponse.

    Attributes
    ----------
    historical_data : dict[str, list[~socgenapi.models.HistoricalDataDto]]
    """

    historical_data: Optional[dict[str, list["_models.HistoricalDataDto"]]] = rest_field(
        name="historicalData", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        historical_data: Optional[dict[str, list["_models.HistoricalDataDto"]]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["historical_data"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class ProductDescription(_Model):
    """Describe a Product.

    Attributes
    ----------
    name : str
        The Product Name.
    definition : str
        The Product Definition.
    refsets : list[~socgenapi.models.RefsetDescription]
        Descriptions of available Refsets on a Product.  The default value is
        None, needs to be assigned before using.
    fields : list[~socgenapi.models.FieldDescription]
        Descriptions of available Fields on a Product.  The default value is
        None, needs to be assigned before using.
    """

    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The Product Name."""
    definition: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The Product Definition."""
    refsets: Optional[list["_models.RefsetDescription"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Descriptions of available Refsets on a Product."""
    fields: Optional[list["_models.FieldDescription"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Descriptions of available Fields on a Product."""

    @overload
    def __init__(
        self,
        *,
        name: Optional[str] = None,
        definition: Optional[str] = None,
        refsets: Optional[list["_models.RefsetDescription"]] = None,
        fields: Optional[list["_models.FieldDescription"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class Quote(_Model):
    """Quote.

    Attributes
    ----------
    instrument : str
    field : str
    sub_fields : dict[str, str]
    missing_reason : str or ~socgenapi.models.MissingValuesReason
        Known values are: "ProductAccessIsDenied",
        "InstrumentDoesNotExistOrAccessIsDenied",
        "FieldDoesNotExistOrAccessIsDenied",
        "FieldIsNotAvailableOnCurrentRefset",
        "SubFieldDoesNotExistOrAccessIsDenied", "ComputationFailed",
        "ComputedIndicatorForbidden", and "ComputedIndicatorParsingFailure".
    missing_reason_details : str
    data_type : str or ~socgenapi.models.DataType
        Known values are: "Integer", "Decimal", "Text", "DateTime", and
        "Unknown".
    is_time_series : bool
    quote_values : list[~socgenapi.models.QuoteValue]
        The default value is None, needs to be assigned before using.
    """

    instrument: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    field: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    sub_fields: Optional[dict[str, str]] = rest_field(
        name="subFields", visibility=["read", "create", "update", "delete", "query"]
    )
    missing_reason: Optional[Union[str, "_models.MissingValuesReason"]] = rest_field(
        name="missingReason", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"ProductAccessIsDenied\", \"InstrumentDoesNotExistOrAccessIsDenied\",
     \"FieldDoesNotExistOrAccessIsDenied\", \"FieldIsNotAvailableOnCurrentRefset\",
     \"SubFieldDoesNotExistOrAccessIsDenied\", \"ComputationFailed\",
     \"ComputedIndicatorForbidden\", and \"ComputedIndicatorParsingFailure\"."""
    missing_reason_details: Optional[str] = rest_field(
        name="missingReasonDetails", visibility=["read", "create", "update", "delete", "query"]
    )
    data_type: Optional[Union[str, "_models.DataType"]] = rest_field(
        name="dataType", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Integer\", \"Decimal\", \"Text\", \"DateTime\", and \"Unknown\"."""
    is_time_series: Optional[bool] = rest_field(
        name="isTimeSeries", visibility=["read", "create", "update", "delete", "query"]
    )
    quote_values: Optional[list["_models.QuoteValue"]] = rest_field(
        name="quoteValues", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        instrument: Optional[str] = None,
        field: Optional[str] = None,
        sub_fields: Optional[dict[str, str]] = None,
        missing_reason: Optional[Union[str, "_models.MissingValuesReason"]] = None,
        missing_reason_details: Optional[str] = None,
        data_type: Optional[Union[str, "_models.DataType"]] = None,
        is_time_series: Optional[bool] = None,
        quote_values: Optional[list["_models.QuoteValue"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class QuoteField(_Model):
    """QuoteField.

    Attributes
    ----------
    name : str
    sub_fields : dict[str, list[str]]
    """

    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    sub_fields: Optional[dict[str, list[str]]] = rest_field(
        name="subFields", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        name: Optional[str] = None,
        sub_fields: Optional[dict[str, list[str]]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class QuotesByConstraintsResponse(_Model):
    """QuotesByConstraintsResponse.

    Attributes
    ----------
    source : str
    refset : str
    quotes : list[~socgenapi.models.Quote]
        The default value is None, needs to be assigned before using.
    total_matching_instruments : int
    """

    source: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    quotes: Optional[list["_models.Quote"]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    total_matching_instruments: Optional[int] = rest_field(
        name="totalMatchingInstruments", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        source: Optional[str] = None,
        refset: Optional[str] = None,
        quotes: Optional[list["_models.Quote"]] = None,
        total_matching_instruments: Optional[int] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class QuotesResponse(_Model):
    """QuotesResponse.

    Attributes
    ----------
    source : str
    refset : str
    quotes : list[~socgenapi.models.Quote]
        The default value is None, needs to be assigned before using.
    """

    source: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    quotes: Optional[list["_models.Quote"]] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        source: Optional[str] = None,
        refset: Optional[str] = None,
        quotes: Optional[list["_models.Quote"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class QuotesUpdateRequest(_Model):
    """QuotesUpdateRequest.

    Attributes
    ----------
    refset : str
    instruments : list[str]
        The default value is None, needs to be assigned before using.
    fields : list[str]
        The default value is None, needs to be assigned before using.
    start_date : ~datetime.date
    end_date : ~datetime.date
    """

    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    instruments: Optional[list[str]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    fields: Optional[list[str]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    start_date: Optional[datetime.date] = rest_field(
        name="startDate", visibility=["read", "create", "update", "delete", "query"]
    )
    end_date: Optional[datetime.date] = rest_field(
        name="endDate", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        refset: Optional[str] = None,
        instruments: Optional[list[str]] = None,
        fields: Optional[list[str]] = None,
        start_date: Optional[datetime.date] = None,
        end_date: Optional[datetime.date] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class QuoteUpdate(_Model):
    """QuoteUpdate.

    Attributes
    ----------
    date : ~datetime.date
    last_update : ~datetime.datetime
    """

    date: Optional[datetime.date] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    last_update: Optional[datetime.datetime] = rest_field(
        name="lastUpdate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )

    @overload
    def __init__(
        self,
        *,
        date: Optional[datetime.date] = None,
        last_update: Optional[datetime.datetime] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class QuoteUpdates(_Model):
    """QuoteUpdates.

    Attributes
    ----------
    instrument : str
    field : str
    quote_values : list[~socgenapi.models.QuoteUpdate]
        The default value is None, needs to be assigned before using.
    """

    instrument: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    field: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    quote_values: Optional[list["_models.QuoteUpdate"]] = rest_field(
        name="quoteValues", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        instrument: Optional[str] = None,
        field: Optional[str] = None,
        quote_values: Optional[list["_models.QuoteUpdate"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class QuoteUpdatesResponse(_Model):
    """QuoteUpdatesResponse.

    Attributes
    ----------
    source : str
    refset : str
    quotes : list[~socgenapi.models.QuoteUpdates]
        The default value is None, needs to be assigned before using.
    """

    source: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    quotes: Optional[list["_models.QuoteUpdates"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        source: Optional[str] = None,
        refset: Optional[str] = None,
        quotes: Optional[list["_models.QuoteUpdates"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class QuoteValue(_Model):
    """A time based quote value.

    Attributes
    ----------
    date : ~datetime.date
        The quote Date.
    value : any
        The quote Value.
    sub_fields : dict[str, str]
        The quote SubFields if any.
    original_quote_date : ~datetime.date
        When queried with fillEmptyQuotes, the date of the original quote.
        Absent when fillEmptyQuotes was false or when the quote is an original
        value.
    """

    date: Optional[datetime.date] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The quote Date."""
    value: Optional[Any] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The quote Value."""
    sub_fields: Optional[dict[str, str]] = rest_field(
        name="subFields", visibility=["read", "create", "update", "delete", "query"]
    )
    """The quote SubFields if any."""
    original_quote_date: Optional[datetime.date] = rest_field(
        name="originalQuoteDate", visibility=["read", "create", "update", "delete", "query"]
    )
    """When queried with fillEmptyQuotes, the date of the original quote. Absent when fillEmptyQuotes
     was false or when the quote is an original value."""

    @overload
    def __init__(
        self,
        *,
        date: Optional[datetime.date] = None,
        value: Optional[Any] = None,
        sub_fields: Optional[dict[str, str]] = None,
        original_quote_date: Optional[datetime.date] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RangeQuotesByConstraintsRequest(_Model):
    """Quotes Request on a Date range with instruments defined by constraints.

    Attributes
    ----------
    refset : str
        The refset you want to query.
    filter : str
        The query describing the instruments you are looking for. `learn more
        about the syntax </data/instruments-filter-syntax.md>`_.
    fields : list[~socgenapi.models.QuoteField]
        The list of fields you want to query.  The default value is None, needs
        to be assigned before using.
    page : int
        Page index (1 based).
    page_size : int
    sort_criteria : list[~socgenapi.models.SortCriterion]
        An optional list of sorting criterion. Default to ascending instrument
        name.  The default value is None, needs to be assigned before using.
    start_date : ~datetime.date
        The StartDate (inclusive) for which you want quotes.
    end_date : ~datetime.date
        The EndDate (inclusive) for which you want quotes.
    fill_empty_quotes : bool
        Whether you want to compensate missing values with previous one (up to
        30 days).
    """

    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The refset you want to query."""
    filter: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The query describing the instruments you are looking for. `learn more about the syntax
     </data/instruments-filter-syntax.md>`_."""
    fields: Optional[list["_models.QuoteField"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """The list of fields you want to query."""
    page: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Page index (1 based)."""
    page_size: Optional[int] = rest_field(name="pageSize", visibility=["read", "create", "update", "delete", "query"])
    sort_criteria: Optional[list["_models.SortCriterion"]] = rest_field(
        name="sortCriteria", visibility=["read", "create", "update", "delete", "query"]
    )
    """An optional list of sorting criterion. Default to ascending instrument name."""
    start_date: Optional[datetime.date] = rest_field(
        name="startDate", visibility=["read", "create", "update", "delete", "query"]
    )
    """The StartDate (inclusive) for which you want quotes."""
    end_date: Optional[datetime.date] = rest_field(
        name="endDate", visibility=["read", "create", "update", "delete", "query"]
    )
    """The EndDate (inclusive) for which you want quotes."""
    fill_empty_quotes: Optional[bool] = rest_field(
        name="fillEmptyQuotes", visibility=["read", "create", "update", "delete", "query"]
    )
    """Whether you want to compensate missing values with previous one (up to 30 days)."""

    @overload
    def __init__(
        self,
        *,
        refset: Optional[str] = None,
        filter: Optional[str] = None,  # pylint: disable=redefined-builtin
        fields: Optional[list["_models.QuoteField"]] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        sort_criteria: Optional[list["_models.SortCriterion"]] = None,
        start_date: Optional[datetime.date] = None,
        end_date: Optional[datetime.date] = None,
        fill_empty_quotes: Optional[bool] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RangeQuotesRequest(_Model):
    """Quotes Request on a Date range.

    Attributes
    ----------
    refset : str
        The refset you want to query.
    instruments : list[str]
        The list of instruments you want to query.  The default value is None,
        needs to be assigned before using.
    fields : list[~socgenapi.models.QuoteField]
        The list of fields you want to query.  The default value is None, needs
        to be assigned before using.
    start_date : ~datetime.date
        The StartDate (inclusive) for which you want quotes.
    end_date : ~datetime.date
        The EndDate (inclusive) for which you want quotes.
    fill_empty_quotes : bool
        Whether you want to compensate missing values with previous one (up to
        30 days).
    cross_instruments_formulas : list[str]
        Formula with many instruments in formula, visit <a
        href="https://sgithub.fr.world.socgen/ResearchNeo/analytics-api-data-
        docs/wiki/Computed-quotes-V3">this link</a>.  The default value is
        None, needs to be assigned before using.
    """

    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The refset you want to query."""
    instruments: Optional[list[str]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The list of instruments you want to query."""
    fields: Optional[list["_models.QuoteField"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """The list of fields you want to query."""
    start_date: Optional[datetime.date] = rest_field(
        name="startDate", visibility=["read", "create", "update", "delete", "query"]
    )
    """The StartDate (inclusive) for which you want quotes."""
    end_date: Optional[datetime.date] = rest_field(
        name="endDate", visibility=["read", "create", "update", "delete", "query"]
    )
    """The EndDate (inclusive) for which you want quotes."""
    fill_empty_quotes: Optional[bool] = rest_field(
        name="fillEmptyQuotes", visibility=["read", "create", "update", "delete", "query"]
    )
    """Whether you want to compensate missing values with previous one (up to 30 days)."""
    cross_instruments_formulas: Optional[list[str]] = rest_field(
        name="crossInstrumentsFormulas", visibility=["read", "create", "update", "delete", "query"]
    )
    """Formula with many instruments in formula, visit <a
     href=\"https://sgithub.fr.world.socgen/ResearchNeo/analytics-api-data-docs/wiki/Computed-quotes-V3\">this
     link</a>."""

    @overload
    def __init__(
        self,
        *,
        refset: Optional[str] = None,
        instruments: Optional[list[str]] = None,
        fields: Optional[list["_models.QuoteField"]] = None,
        start_date: Optional[datetime.date] = None,
        end_date: Optional[datetime.date] = None,
        fill_empty_quotes: Optional[bool] = None,
        cross_instruments_formulas: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RatePointDto(_Model):
    """RatePointDto.

    Attributes
    ----------
    date : ~datetime.datetime
    value : float
    """

    date: Optional[datetime.datetime] = rest_field(
        visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    value: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        date: Optional[datetime.datetime] = None,
        value: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RatesAndClosestStrategiesAndRegressionRequest(_Model):  # pylint: disable=name-too-long
    """RatesAndClosestStrategiesAndRegressionRequest.

    Attributes
    ----------
    strategy : ~socgenapi.models.StrategyRequest
    regression_curve : str
    start_date : ~datetime.datetime
    end_date : ~datetime.datetime
    top : int
    place : str
    indicators : list[str]
        The default value is None, needs to be assigned before using.
    regression_indicators : list[str]
        The default value is None, needs to be assigned before using.
    nominal : float
    """

    strategy: Optional["_models.StrategyRequest"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    regression_curve: Optional[str] = rest_field(
        name="regressionCurve", visibility=["read", "create", "update", "delete", "query"]
    )
    start_date: Optional[datetime.datetime] = rest_field(
        name="startDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    end_date: Optional[datetime.datetime] = rest_field(
        name="endDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    top: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    place: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    indicators: Optional[list[str]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    regression_indicators: Optional[list[str]] = rest_field(
        name="regressionIndicators", visibility=["read", "create", "update", "delete", "query"]
    )
    nominal: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        strategy: Optional["_models.StrategyRequest"] = None,
        regression_curve: Optional[str] = None,
        start_date: Optional[datetime.datetime] = None,
        end_date: Optional[datetime.datetime] = None,
        top: Optional[int] = None,
        place: Optional[str] = None,
        indicators: Optional[list[str]] = None,
        regression_indicators: Optional[list[str]] = None,
        nominal: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RatesAndClosestStrategiesAndRegressionResponse(_Model):  # pylint: disable=name-too-long
    """RatesAndClosestStrategiesAndRegressionResponse.

    Attributes
    ----------
    historical_rates : ~socgenapi.models.RatesResponse
    regression : ~socgenapi.models.CustomStrategyCoupleRequestRegressionResponse
    closest_strategies : ~socgenapi.models.ClosestStrategiesResponse
    hedging_simulations : ~socgenapi.models.HedgingSimulationResponse
    """

    historical_rates: Optional["_models.RatesResponse"] = rest_field(
        name="historicalRates", visibility=["read", "create", "update", "delete", "query"]
    )
    regression: Optional["_models.CustomStrategyCoupleRequestRegressionResponse"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    closest_strategies: Optional["_models.ClosestStrategiesResponse"] = rest_field(
        name="closestStrategies", visibility=["read", "create", "update", "delete", "query"]
    )
    hedging_simulations: Optional["_models.HedgingSimulationResponse"] = rest_field(
        name="hedgingSimulations", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        historical_rates: Optional["_models.RatesResponse"] = None,
        regression: Optional["_models.CustomStrategyCoupleRequestRegressionResponse"] = None,
        closest_strategies: Optional["_models.ClosestStrategiesResponse"] = None,
        hedging_simulations: Optional["_models.HedgingSimulationResponse"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RatesResponse(_Model):
    """RatesResponse.

    Attributes
    ----------
    strategies : list[~socgenapi.models.RateStrategyDto]
        The default value is None, needs to be assigned before using.
    """

    strategies: Optional[list["_models.RateStrategyDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        strategies: Optional[list["_models.RateStrategyDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["strategies"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class RateStrategyDto(_Model):
    """RateStrategyDto.

    Attributes
    ----------
    rate : list[~socgenapi.models.RatePointDto]
        The default value is None, needs to be assigned before using.
    carry : list[~socgenapi.models.RatePointDto]
        The default value is None, needs to be assigned before using.
    rolldown : list[~socgenapi.models.RatePointDto]
        The default value is None, needs to be assigned before using.
    volatility : list[~socgenapi.models.RatePointDto]
        The default value is None, needs to be assigned before using.
    request : ~socgenapi.models.StrategyRequest
    """

    rate: Optional[list["_models.RatePointDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    carry: Optional[list["_models.RatePointDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    rolldown: Optional[list["_models.RatePointDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    volatility: Optional[list["_models.RatePointDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    request: Optional["_models.StrategyRequest"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        rate: Optional[list["_models.RatePointDto"]] = None,
        carry: Optional[list["_models.RatePointDto"]] = None,
        rolldown: Optional[list["_models.RatePointDto"]] = None,
        volatility: Optional[list["_models.RatePointDto"]] = None,
        request: Optional["_models.StrategyRequest"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RefsetDescription(_Model):
    """Describe a Refset.

    Attributes
    ----------
    name : str
        The Refset Name.
    definition : str
        The Refset Definition.
    """

    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The Refset Name."""
    definition: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The Refset Definition."""

    @overload
    def __init__(
        self,
        *,
        name: Optional[str] = None,
        definition: Optional[str] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RegionAbaqueDto(_Model):
    """RegionAbaqueDto.

    Attributes
    ----------
    market : str
    execution_start_time : str
    nominal : float
    number_of_orders : int
    average_duration : str
    max_duration : str
    times_frames : list[~socgenapi.models.ExecutionDto]
        The default value is None, needs to be assigned before using.
    adv_distribution : list[~socgenapi.models.AdvDistributionDto]
        The default value is None, needs to be assigned before using.
    """

    market: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    execution_start_time: Optional[str] = rest_field(
        name="executionStartTime", visibility=["read", "create", "update", "delete", "query"]
    )
    nominal: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    number_of_orders: Optional[int] = rest_field(
        name="numberOfOrders", visibility=["read", "create", "update", "delete", "query"]
    )
    average_duration: Optional[str] = rest_field(
        name="averageDuration", visibility=["read", "create", "update", "delete", "query"]
    )
    max_duration: Optional[str] = rest_field(
        name="maxDuration", visibility=["read", "create", "update", "delete", "query"]
    )
    times_frames: Optional[list["_models.ExecutionDto"]] = rest_field(
        name="timesFrames", visibility=["read", "create", "update", "delete", "query"]
    )
    adv_distribution: Optional[list["_models.AdvDistributionDto"]] = rest_field(
        name="advDistribution", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        market: Optional[str] = None,
        execution_start_time: Optional[str] = None,
        nominal: Optional[float] = None,
        number_of_orders: Optional[int] = None,
        average_duration: Optional[str] = None,
        max_duration: Optional[str] = None,
        times_frames: Optional[list["_models.ExecutionDto"]] = None,
        adv_distribution: Optional[list["_models.AdvDistributionDto"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RegionDto(_Model):
    """RegionDto.

    Attributes
    ----------
    region : str
    daily_completions : list[~socgenapi.models.DailyCompletionDto]
        The default value is None, needs to be assigned before using.
    nominal_to_execute : float
    """

    region: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    daily_completions: Optional[list["_models.DailyCompletionDto"]] = rest_field(
        name="dailyCompletions", visibility=["read", "create", "update", "delete", "query"]
    )
    nominal_to_execute: Optional[float] = rest_field(
        name="nominalToExecute", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        region: Optional[str] = None,
        daily_completions: Optional[list["_models.DailyCompletionDto"]] = None,
        nominal_to_execute: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class RegressionPointDto(_Model):
    """RegressionPointDto.

    Attributes
    ----------
    date : ~datetime.datetime
    value : float
    """

    date: Optional[datetime.datetime] = rest_field(
        visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    value: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        date: Optional[datetime.datetime] = None,
        value: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class SearchInstrumentsRequest(_Model):
    """SearchInstrumentsRequest.

    Attributes
    ----------
    search : str
    filter : str
        The query describing the instruments you are looking for. `learn more
        about the syntax </data/instruments-filter-syntax.md>`_.
    page : int
        Page index (1 based).
    page_size : int
    includes : list[str or ~socgenapi.models.SearchInclude]
        Additional properties to include in response.  The default value is
        None, needs to be assigned before using.
    sort_criteria : list[~socgenapi.models.SortCriterion]
        An optional list of sorting criterion. Default to ascending instrument
        name. Ignored when search is set.  The default value is None, needs to
        be assigned before using.
    """

    search: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    filter: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The query describing the instruments you are looking for. `learn more about the syntax
     </data/instruments-filter-syntax.md>`_."""
    page: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Page index (1 based)."""
    page_size: Optional[int] = rest_field(name="pageSize", visibility=["read", "create", "update", "delete", "query"])
    includes: Optional[list[Union[str, "_models.SearchInclude"]]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Additional properties to include in response."""
    sort_criteria: Optional[list["_models.SortCriterion"]] = rest_field(
        name="sortCriteria", visibility=["read", "create", "update", "delete", "query"]
    )
    """An optional list of sorting criterion. Default to ascending instrument name. Ignored when
     search is set."""

    @overload
    def __init__(
        self,
        *,
        search: Optional[str] = None,
        filter: Optional[str] = None,  # pylint: disable=redefined-builtin
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        includes: Optional[list[Union[str, "_models.SearchInclude"]]] = None,
        sort_criteria: Optional[list["_models.SortCriterion"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class SearchInstrumentsResponse(_Model):
    """SearchInstrumentsResponse.

    Attributes
    ----------
    instruments : list[~socgenapi.models.MatchInstrument]
        The default value is None, needs to be assigned before using.
    total_matching_instruments : int
    """

    instruments: Optional[list["_models.MatchInstrument"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    total_matching_instruments: Optional[int] = rest_field(
        name="totalMatchingInstruments", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        instruments: Optional[list["_models.MatchInstrument"]] = None,
        total_matching_instruments: Optional[int] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class ServiceError(_Model):
    """An object that contains the information in case of a blocking error in calculation.

    All required parameters must be populated in order to send to server.

    Attributes
    ----------
    id : str
        The identifier of the error. Required.
    code : str
        The code of the error. Required.
    message : str
        The message in case of a blocking error in calculation. Required.
    status : str
        The status of the error.
    errors : list[~socgenapi.models.InnerError]
        An array of objects that contains the detailed information in case of a
        blocking error in calculation.  The default value is None, needs to be
        assigned before using.
    """

    id: str = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The identifier of the error. Required."""
    code: str = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The code of the error. Required."""
    message: str = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The message in case of a blocking error in calculation. Required."""
    status: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The status of the error."""
    errors: Optional[list["_models.InnerError"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """An array of objects that contains the detailed information in case of a blocking error in
     calculation."""

    @overload
    def __init__(
        self,
        *,
        id: str,  # pylint: disable=redefined-builtin
        code: str,
        message: str,
        status: Optional[str] = None,
        errors: Optional[list["_models.InnerError"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class ServiceErrorResponse(_Model):
    """The error information returned in response.

    All required parameters must be populated in order to send to server.

    Attributes
    ----------
    error : ~socgenapi.models.ServiceError
        An object that contains the information in case of a blocking error in
        calculation. Required.
    """

    error: "_models.ServiceError" = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """An object that contains the information in case of a blocking error in calculation. Required."""

    @overload
    def __init__(
        self,
        error: "_models.ServiceError",
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["error"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class SnapshotQuotesByConstraintsRequest(_Model):
    """Quotes Request on a set of Dates with instruments defined by constraints.

    Attributes
    ----------
    refset : str
        The refset you want to query.
    filter : str
        The query describing the instruments you are looking for. `learn more
        about the syntax </data/instruments-filter-syntax.md>`_.
    fields : list[~socgenapi.models.QuoteField]
        The list of fields you want to query.  The default value is None, needs
        to be assigned before using.
    page : int
        Page index (1 based).
    page_size : int
    sort_criteria : list[~socgenapi.models.SortCriterion]
        An optional list of sorting criterion. Default to ascending instrument
        name.  The default value is None, needs to be assigned before using.
    dates : list[~datetime.date]
        A set of Dates for which you want quotes.  The default value is None,
        needs to be assigned before using.
    fill_empty_quotes : bool
        Whether you want to compensate missing values with previous one (up to
        30 days).
    """

    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The refset you want to query."""
    filter: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The query describing the instruments you are looking for. `learn more about the syntax
     </data/instruments-filter-syntax.md>`_."""
    fields: Optional[list["_models.QuoteField"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """The list of fields you want to query."""
    page: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """Page index (1 based)."""
    page_size: Optional[int] = rest_field(name="pageSize", visibility=["read", "create", "update", "delete", "query"])
    sort_criteria: Optional[list["_models.SortCriterion"]] = rest_field(
        name="sortCriteria", visibility=["read", "create", "update", "delete", "query"]
    )
    """An optional list of sorting criterion. Default to ascending instrument name."""
    dates: Optional[list[datetime.date]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """A set of Dates for which you want quotes."""
    fill_empty_quotes: Optional[bool] = rest_field(
        name="fillEmptyQuotes", visibility=["read", "create", "update", "delete", "query"]
    )
    """Whether you want to compensate missing values with previous one (up to 30 days)."""

    @overload
    def __init__(
        self,
        *,
        refset: Optional[str] = None,
        filter: Optional[str] = None,  # pylint: disable=redefined-builtin
        fields: Optional[list["_models.QuoteField"]] = None,
        page: Optional[int] = None,
        page_size: Optional[int] = None,
        sort_criteria: Optional[list["_models.SortCriterion"]] = None,
        dates: Optional[list[datetime.date]] = None,
        fill_empty_quotes: Optional[bool] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class SnapshotQuotesRequest(_Model):
    """Quotes Request on a set of Dates.

    Attributes
    ----------
    refset : str
        The refset you want to query.
    instruments : list[str]
        The list of instruments you want to query.  The default value is None,
        needs to be assigned before using.
    fields : list[~socgenapi.models.QuoteField]
        The list of fields you want to query.  The default value is None, needs
        to be assigned before using.
    dates : list[~datetime.date]
        A set of Dates for which you want quotes.  The default value is None,
        needs to be assigned before using.
    fill_empty_quotes : bool
        Whether you want to compensate missing values with previous one (up to
        30 days).
    """

    refset: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The refset you want to query."""
    instruments: Optional[list[str]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The list of instruments you want to query."""
    fields: Optional[list["_models.QuoteField"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """The list of fields you want to query."""
    dates: Optional[list[datetime.date]] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """A set of Dates for which you want quotes."""
    fill_empty_quotes: Optional[bool] = rest_field(
        name="fillEmptyQuotes", visibility=["read", "create", "update", "delete", "query"]
    )
    """Whether you want to compensate missing values with previous one (up to 30 days)."""

    @overload
    def __init__(
        self,
        *,
        refset: Optional[str] = None,
        instruments: Optional[list[str]] = None,
        fields: Optional[list["_models.QuoteField"]] = None,
        dates: Optional[list[datetime.date]] = None,
        fill_empty_quotes: Optional[bool] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class SortCriterion(_Model):
    """SortCriterion.

    Attributes
    ----------
    field : str
    order : str or ~socgenapi.models.Order
        Known values are: "Asc" and "Desc".
    """

    field: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    order: Optional[Union[str, "_models.Order"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Asc\" and \"Desc\"."""

    @overload
    def __init__(
        self,
        *,
        field: Optional[str] = None,
        order: Optional[Union[str, "_models.Order"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class SourceDescription(_Model):
    """Describe a Source.

    Attributes
    ----------
    name : str
        The Source Name.
    definition : str
        The Source Definition.
    products : list[~socgenapi.models.ProductDescription]
        Descriptions of available Products on a Source.  The default value is
        None, needs to be assigned before using.
    """

    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The Source Name."""
    definition: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The Source Definition."""
    products: Optional[list["_models.ProductDescription"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Descriptions of available Products on a Source."""

    @overload
    def __init__(
        self,
        *,
        name: Optional[str] = None,
        definition: Optional[str] = None,
        products: Optional[list["_models.ProductDescription"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class StatusDto(_Model):
    """StatusDto.

    Attributes
    ----------
    id : str
    invalid_reasons : list[str]
        The default value is None, needs to be assigned before using.
    """

    id: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    invalid_reasons: Optional[list[str]] = rest_field(
        name="invalidReasons", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        id: Optional[str] = None,  # pylint: disable=redefined-builtin
        invalid_reasons: Optional[list[str]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class StrategyInstrumentRequest(_Model):
    """StrategyInstrumentRequest.

    Attributes
    ----------
    leg1 : str
    leg2 : str
    leg3 : str
    forward : str
    duration : str
    curve : str
    weight : float
    """

    leg1: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    leg2: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    leg3: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    forward: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    duration: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    curve: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    weight: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        leg1: Optional[str] = None,
        leg2: Optional[str] = None,
        leg3: Optional[str] = None,
        forward: Optional[str] = None,
        duration: Optional[str] = None,
        curve: Optional[str] = None,
        weight: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class StrategyRequest(_Model):
    """StrategyRequest.

    Attributes
    ----------
    instruments : list[~socgenapi.models.StrategyInstrumentRequest]
        The default value is None, needs to be assigned before using.
    """

    instruments: Optional[list["_models.StrategyInstrumentRequest"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        instruments: Optional[list["_models.StrategyInstrumentRequest"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["instruments"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class SubField(_Model):
    """Describe a SubFieldGroups.

    Attributes
    ----------
    type : str
        The SubFieldGroups Type.
    definition : str
        The SubFieldGroups Definition.
    components : list[~socgenapi.models.Component]
        Descriptions of available Components on a SubFieldGroups.  The default
        value is None, needs to be assigned before using.
    """

    type: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"], default="None")
    """The SubFieldGroups Type."""
    definition: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    """The SubFieldGroups Definition."""
    components: Optional[list["_models.Component"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Descriptions of available Components on a SubFieldGroups."""

    @overload
    def __init__(
        self,
        *,
        type: Optional[str] = None,
        definition: Optional[str] = None,
        components: Optional[list["_models.Component"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class SummaryDailyDto(_Model):
    """SummaryDailyDto.

    Attributes
    ----------
    day : int
    intraday : float
    close : float
    """

    day: Optional[int] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    intraday: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    close: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        day: Optional[int] = None,
        intraday: Optional[float] = None,
        close: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class SustainableBondResponse(_Model):
    """SustainableBondResponse.

    Attributes
    ----------
    isin : str
    name : str
    ticker : str
    currency : str
    country : str
    region : str
    maturity : ~datetime.datetime
    issue_date : ~datetime.datetime
    z_spread : float
    amount_outstanding : float
    lower_bound : ~socgenapi.models.BoundResponse
    upper_bound : ~socgenapi.models.BoundResponse
    calculation_method : str or ~socgenapi.models.CalculationMethod
        Known values are: "Interpolation", "Extrapolation", and "None".
    z_spread_comparable : float
    greenium : float
    coupon : float
    seniority : str
    duration : float
    category : str or ~socgenapi.models.Category
        Known values are: "Other", "Sovereign", "SubSovereign", "Covered",
        "CorporatesAndFinancials", and "HighYield".
    bond_type : str or ~socgenapi.models.BondType
        Known values are: "Green", "Slb", "Social", and "Sustainable".
    """

    isin: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    ticker: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    currency: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    country: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    region: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    maturity: Optional[datetime.datetime] = rest_field(
        visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    issue_date: Optional[datetime.datetime] = rest_field(
        name="issueDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    z_spread: Optional[float] = rest_field(name="zSpread", visibility=["read", "create", "update", "delete", "query"])
    amount_outstanding: Optional[float] = rest_field(
        name="amountOutstanding", visibility=["read", "create", "update", "delete", "query"]
    )
    lower_bound: Optional["_models.BoundResponse"] = rest_field(
        name="lowerBound", visibility=["read", "create", "update", "delete", "query"]
    )
    upper_bound: Optional["_models.BoundResponse"] = rest_field(
        name="upperBound", visibility=["read", "create", "update", "delete", "query"]
    )
    calculation_method: Optional[Union[str, "_models.CalculationMethod"]] = rest_field(
        name="calculationMethod", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Interpolation\", \"Extrapolation\", and \"None\"."""
    z_spread_comparable: Optional[float] = rest_field(
        name="zSpreadComparable", visibility=["read", "create", "update", "delete", "query"]
    )
    greenium: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    coupon: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    seniority: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    duration: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    category: Optional[Union[str, "_models.Category"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Other\", \"Sovereign\", \"SubSovereign\", \"Covered\",
     \"CorporatesAndFinancials\", and \"HighYield\"."""
    bond_type: Optional[Union[str, "_models.BondType"]] = rest_field(
        name="bondType", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Green\", \"Slb\", \"Social\", and \"Sustainable\"."""

    @overload
    def __init__(
        self,
        *,
        isin: Optional[str] = None,
        name: Optional[str] = None,
        ticker: Optional[str] = None,
        currency: Optional[str] = None,
        country: Optional[str] = None,
        region: Optional[str] = None,
        maturity: Optional[datetime.datetime] = None,
        issue_date: Optional[datetime.datetime] = None,
        z_spread: Optional[float] = None,
        amount_outstanding: Optional[float] = None,
        lower_bound: Optional["_models.BoundResponse"] = None,
        upper_bound: Optional["_models.BoundResponse"] = None,
        calculation_method: Optional[Union[str, "_models.CalculationMethod"]] = None,
        z_spread_comparable: Optional[float] = None,
        greenium: Optional[float] = None,
        coupon: Optional[float] = None,
        seniority: Optional[str] = None,
        duration: Optional[float] = None,
        category: Optional[Union[str, "_models.Category"]] = None,
        bond_type: Optional[Union[str, "_models.BondType"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class TargetCloseInstrumentDto(_Model):
    """TargetCloseInstrumentDto.

    Attributes
    ----------
    ticker : str
    name : str
    geo_zone : str
    way : str
    market : str
    execution_start_date_time : ~datetime.datetime
    execution_end_date_time : ~datetime.datetime
    adv : float
    adv_pct : float
    quantity_to_execute : int
    nominal_to_execute : float
    weight_pct : float
    residual_quantity : int
    residual_nominal : float
    cost_bps : float
    cost_ccy : float
    acv : float
    acv_pct : float
    trading_sessions : list[~socgenapi.models.TargetCloseTradingSessionDto]
        The default value is None, needs to be assigned before using.
    nb_days : int
    """

    ticker: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    name: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    geo_zone: Optional[str] = rest_field(name="geoZone", visibility=["read", "create", "update", "delete", "query"])
    way: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    market: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    execution_start_date_time: Optional[datetime.datetime] = rest_field(
        name="executionStartDateTime", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    execution_end_date_time: Optional[datetime.datetime] = rest_field(
        name="executionEndDateTime", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    adv: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    adv_pct: Optional[float] = rest_field(name="advPct", visibility=["read", "create", "update", "delete", "query"])
    quantity_to_execute: Optional[int] = rest_field(
        name="quantityToExecute", visibility=["read", "create", "update", "delete", "query"]
    )
    nominal_to_execute: Optional[float] = rest_field(
        name="nominalToExecute", visibility=["read", "create", "update", "delete", "query"]
    )
    weight_pct: Optional[float] = rest_field(
        name="weightPct", visibility=["read", "create", "update", "delete", "query"]
    )
    residual_quantity: Optional[int] = rest_field(
        name="residualQuantity", visibility=["read", "create", "update", "delete", "query"]
    )
    residual_nominal: Optional[float] = rest_field(
        name="residualNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    cost_bps: Optional[float] = rest_field(name="costBps", visibility=["read", "create", "update", "delete", "query"])
    cost_ccy: Optional[float] = rest_field(name="costCcy", visibility=["read", "create", "update", "delete", "query"])
    acv: Optional[float] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    acv_pct: Optional[float] = rest_field(name="acvPct", visibility=["read", "create", "update", "delete", "query"])
    trading_sessions: Optional[list["_models.TargetCloseTradingSessionDto"]] = rest_field(
        name="tradingSessions", visibility=["read", "create", "update", "delete", "query"]
    )
    nb_days: Optional[int] = rest_field(name="nbDays", visibility=["read", "create", "update", "delete", "query"])

    @overload
    def __init__(
        self,
        *,
        ticker: Optional[str] = None,
        name: Optional[str] = None,
        geo_zone: Optional[str] = None,
        way: Optional[str] = None,
        market: Optional[str] = None,
        execution_start_date_time: Optional[datetime.datetime] = None,
        execution_end_date_time: Optional[datetime.datetime] = None,
        adv: Optional[float] = None,
        adv_pct: Optional[float] = None,
        quantity_to_execute: Optional[int] = None,
        nominal_to_execute: Optional[float] = None,
        weight_pct: Optional[float] = None,
        residual_quantity: Optional[int] = None,
        residual_nominal: Optional[float] = None,
        cost_bps: Optional[float] = None,
        cost_ccy: Optional[float] = None,
        acv: Optional[float] = None,
        acv_pct: Optional[float] = None,
        trading_sessions: Optional[list["_models.TargetCloseTradingSessionDto"]] = None,
        nb_days: Optional[int] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class TargetCloseResponseDto(_Model):
    """TargetCloseResponseDto.

    Attributes
    ----------
    execution_start_date_time : ~datetime.datetime
    execution_end_date_time : ~datetime.datetime
    quantity_to_execute : int
    nominal_to_execute : float
    residual_quantity : int
    residual_nominal : float
    cost_bps : float
    cost_ccy : float
    anticipated_impacts_day1 : float
    nb_days_max : int
    instruments : list[~socgenapi.models.TargetCloseInstrumentDto]
        The default value is None, needs to be assigned before using.
    completion : ~socgenapi.models.CompletionDto
    """

    execution_start_date_time: Optional[datetime.datetime] = rest_field(
        name="executionStartDateTime", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    execution_end_date_time: Optional[datetime.datetime] = rest_field(
        name="executionEndDateTime", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    quantity_to_execute: Optional[int] = rest_field(
        name="quantityToExecute", visibility=["read", "create", "update", "delete", "query"]
    )
    nominal_to_execute: Optional[float] = rest_field(
        name="nominalToExecute", visibility=["read", "create", "update", "delete", "query"]
    )
    residual_quantity: Optional[int] = rest_field(
        name="residualQuantity", visibility=["read", "create", "update", "delete", "query"]
    )
    residual_nominal: Optional[float] = rest_field(
        name="residualNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    cost_bps: Optional[float] = rest_field(name="costBps", visibility=["read", "create", "update", "delete", "query"])
    cost_ccy: Optional[float] = rest_field(name="costCcy", visibility=["read", "create", "update", "delete", "query"])
    anticipated_impacts_day1: Optional[float] = rest_field(
        name="anticipatedImpactsDay1", visibility=["read", "create", "update", "delete", "query"]
    )
    nb_days_max: Optional[int] = rest_field(
        name="nbDaysMax", visibility=["read", "create", "update", "delete", "query"]
    )
    instruments: Optional[list["_models.TargetCloseInstrumentDto"]] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    completion: Optional["_models.CompletionDto"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        execution_start_date_time: Optional[datetime.datetime] = None,
        execution_end_date_time: Optional[datetime.datetime] = None,
        quantity_to_execute: Optional[int] = None,
        nominal_to_execute: Optional[float] = None,
        residual_quantity: Optional[int] = None,
        residual_nominal: Optional[float] = None,
        cost_bps: Optional[float] = None,
        cost_ccy: Optional[float] = None,
        anticipated_impacts_day1: Optional[float] = None,
        nb_days_max: Optional[int] = None,
        instruments: Optional[list["_models.TargetCloseInstrumentDto"]] = None,
        completion: Optional["_models.CompletionDto"] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class TargetCloseTradingSegmentDto(_Model):
    """TargetCloseTradingSegmentDto.

    Attributes
    ----------
    execution_start_date_time : ~datetime.datetime
    execution_end_date_time : ~datetime.datetime
    done_quantity : int
    done_nominal : float
    """

    execution_start_date_time: Optional[datetime.datetime] = rest_field(
        name="executionStartDateTime", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    execution_end_date_time: Optional[datetime.datetime] = rest_field(
        name="executionEndDateTime", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    done_quantity: Optional[int] = rest_field(
        name="doneQuantity", visibility=["read", "create", "update", "delete", "query"]
    )
    done_nominal: Optional[float] = rest_field(
        name="doneNominal", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        execution_start_date_time: Optional[datetime.datetime] = None,
        execution_end_date_time: Optional[datetime.datetime] = None,
        done_quantity: Optional[int] = None,
        done_nominal: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class TargetCloseTradingSessionDto(_Model):
    """TargetCloseTradingSessionDto.

    Attributes
    ----------
    execution_start_date_time : ~datetime.datetime
    execution_end_date_time : ~datetime.datetime
    quantity_to_execute : int
    nominal_to_execute : float
    residual_quantity : int
    residual_nominal : float
    impact_temporary_bps : float
    impact_permanent_bps : float
    impact_close_bps : float
    impact_total_bps : float
    cost_bps : float
    cost_ccy : float
    open : ~socgenapi.models.TargetCloseTradingSegmentDto
    intra_day : ~socgenapi.models.TargetCloseTradingSegmentDto
    close : ~socgenapi.models.TargetCloseTradingSegmentDto
    pct_completion : float
    market_status : str or ~socgenapi.models.MarketStatus
        Known values are: "Open", "Closed", "Weekend", and "Holiday".
    """

    execution_start_date_time: Optional[datetime.datetime] = rest_field(
        name="executionStartDateTime", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    execution_end_date_time: Optional[datetime.datetime] = rest_field(
        name="executionEndDateTime", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    quantity_to_execute: Optional[int] = rest_field(
        name="quantityToExecute", visibility=["read", "create", "update", "delete", "query"]
    )
    nominal_to_execute: Optional[float] = rest_field(
        name="nominalToExecute", visibility=["read", "create", "update", "delete", "query"]
    )
    residual_quantity: Optional[int] = rest_field(
        name="residualQuantity", visibility=["read", "create", "update", "delete", "query"]
    )
    residual_nominal: Optional[float] = rest_field(
        name="residualNominal", visibility=["read", "create", "update", "delete", "query"]
    )
    impact_temporary_bps: Optional[float] = rest_field(
        name="impactTemporaryBps", visibility=["read", "create", "update", "delete", "query"]
    )
    impact_permanent_bps: Optional[float] = rest_field(
        name="impactPermanentBps", visibility=["read", "create", "update", "delete", "query"]
    )
    impact_close_bps: Optional[float] = rest_field(
        name="impactCloseBps", visibility=["read", "create", "update", "delete", "query"]
    )
    impact_total_bps: Optional[float] = rest_field(
        name="impactTotalBps", visibility=["read", "create", "update", "delete", "query"]
    )
    cost_bps: Optional[float] = rest_field(name="costBps", visibility=["read", "create", "update", "delete", "query"])
    cost_ccy: Optional[float] = rest_field(name="costCcy", visibility=["read", "create", "update", "delete", "query"])
    open: Optional["_models.TargetCloseTradingSegmentDto"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    intra_day: Optional["_models.TargetCloseTradingSegmentDto"] = rest_field(
        name="intraDay", visibility=["read", "create", "update", "delete", "query"]
    )
    close: Optional["_models.TargetCloseTradingSegmentDto"] = rest_field(
        visibility=["read", "create", "update", "delete", "query"]
    )
    pct_completion: Optional[float] = rest_field(
        name="pctCompletion", visibility=["read", "create", "update", "delete", "query"]
    )
    market_status: Optional[Union[str, "_models.MarketStatus"]] = rest_field(
        name="marketStatus", visibility=["read", "create", "update", "delete", "query"]
    )
    """Known values are: \"Open\", \"Closed\", \"Weekend\", and \"Holiday\"."""

    @overload
    def __init__(
        self,
        *,
        execution_start_date_time: Optional[datetime.datetime] = None,
        execution_end_date_time: Optional[datetime.datetime] = None,
        quantity_to_execute: Optional[int] = None,
        nominal_to_execute: Optional[float] = None,
        residual_quantity: Optional[int] = None,
        residual_nominal: Optional[float] = None,
        impact_temporary_bps: Optional[float] = None,
        impact_permanent_bps: Optional[float] = None,
        impact_close_bps: Optional[float] = None,
        impact_total_bps: Optional[float] = None,
        cost_bps: Optional[float] = None,
        cost_ccy: Optional[float] = None,
        open: Optional["_models.TargetCloseTradingSegmentDto"] = None,
        intra_day: Optional["_models.TargetCloseTradingSegmentDto"] = None,
        close: Optional["_models.TargetCloseTradingSegmentDto"] = None,
        pct_completion: Optional[float] = None,
        market_status: Optional[Union[str, "_models.MarketStatus"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class VolatilityOvernight(_Model):
    """VolatilityOvernight.

    Attributes
    ----------
    volatility_overnight_date : ~datetime.datetime
    values_property : list[~socgenapi.models.DailyVolAtDate]
        The default value is None, needs to be assigned before using.
    """

    volatility_overnight_date: Optional[datetime.datetime] = rest_field(
        name="volatilityOvernightDate", visibility=["read", "create", "update", "delete", "query"], format="rfc3339"
    )
    values_property: Optional[list["_models.DailyVolAtDate"]] = rest_field(
        name="values", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        volatility_overnight_date: Optional[datetime.datetime] = None,
        values_property: Optional[list["_models.DailyVolAtDate"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class VolatilityOvernightRange(_Model):
    """VolatilityOvernightRange.

    Attributes
    ----------
    volatility_overnights : list[~socgenapi.models.VolatilityOvernight]
        The default value is None, needs to be assigned before using.
    """

    volatility_overnights: Optional[list["_models.VolatilityOvernight"]] = rest_field(
        name="volatilityOvernights", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        volatility_overnights: Optional[list["_models.VolatilityOvernight"]] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        if len(args) == 1 and not isinstance(args[0], dict):
            kwargs["volatility_overnights"] = args[0]
            args = tuple()
        super().__init__(*args, **kwargs)


class WayDto(_Model):
    """WayDto.

    Attributes
    ----------
    way : str
    daily_completions : list[~socgenapi.models.DailyCompletionDto]
        The default value is None, needs to be assigned before using.
    nominal_to_execute : float
    """

    way: Optional[str] = rest_field(visibility=["read", "create", "update", "delete", "query"])
    daily_completions: Optional[list["_models.DailyCompletionDto"]] = rest_field(
        name="dailyCompletions", visibility=["read", "create", "update", "delete", "query"]
    )
    nominal_to_execute: Optional[float] = rest_field(
        name="nominalToExecute", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        way: Optional[str] = None,
        daily_completions: Optional[list["_models.DailyCompletionDto"]] = None,
        nominal_to_execute: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)


class WeightedAverageByNominal(_Model):
    """WeightedAverageByNominal.

    Attributes
    ----------
    esg_score : float
    environmental_score : float
    social_score : float
    governance_score : float
    """

    esg_score: Optional[float] = rest_field(name="esgScore", visibility=["read", "create", "update", "delete", "query"])
    environmental_score: Optional[float] = rest_field(
        name="environmentalScore", visibility=["read", "create", "update", "delete", "query"]
    )
    social_score: Optional[float] = rest_field(
        name="socialScore", visibility=["read", "create", "update", "delete", "query"]
    )
    governance_score: Optional[float] = rest_field(
        name="governanceScore", visibility=["read", "create", "update", "delete", "query"]
    )

    @overload
    def __init__(
        self,
        *,
        esg_score: Optional[float] = None,
        environmental_score: Optional[float] = None,
        social_score: Optional[float] = None,
        governance_score: Optional[float] = None,
    ) -> None: ...

    @overload
    def __init__(self, mapping: Mapping[str, Any]) -> None:
        """
        Parameters
        ----------
        mapping : Mapping[str, Any]
            raw JSON to initialize the model.
        """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
