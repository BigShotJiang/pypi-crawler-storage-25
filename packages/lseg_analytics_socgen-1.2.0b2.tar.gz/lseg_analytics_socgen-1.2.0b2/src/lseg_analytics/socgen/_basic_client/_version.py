# coding=utf-8

VERSION = "1.2.0b2"
