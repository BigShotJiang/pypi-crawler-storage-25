# pylint: disable=line-too-long,useless-suppression,too-many-lines
# coding=utf-8
import datetime
import json
from collections.abc import MutableMapping
from io import IOBase
from typing import (
    IO,
    Any,
    Callable,
    Iterator,
    Literal,
    Optional,
    TypeVar,
    Union,
    overload,
)

from corehttp.exceptions import (
    ClientAuthenticationError,
    HttpResponseError,
    ResourceExistsError,
    ResourceNotFoundError,
    ResourceNotModifiedError,
    StreamClosedError,
    StreamConsumedError,
    map_error,
)
from corehttp.rest import HttpRequest, HttpResponse
from corehttp.runtime import PipelineClient
from corehttp.runtime.pipeline import PipelineResponse
from corehttp.utils import case_insensitive_dict

from .. import models as _models
from .._configuration import SocGenAPIClientConfiguration
from .._utils.model_base import SdkJSONEncoder, _deserialize, _failsafe_deserialize
from .._utils.serialization import Deserializer, Serializer

JSON = MutableMapping[str, Any]
T = TypeVar("T")
ClsType = Optional[Callable[[PipelineResponse[HttpRequest, HttpResponse], T, dict[str, Any]], Any]]

_SERIALIZER = Serializer()
_SERIALIZER.client_side_validation = False


def build_basket_scan_service_delete_basket_request(  # pylint: disable=name-too-long
    basket_id: str, **kwargs: Any
) -> HttpRequest:
    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets/{basketId}"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    return HttpRequest(method="DELETE", url=_url, **kwargs)


def build_basket_scan_service_get_basket_request(  # pylint: disable=name-too-long
    basket_id: str,
    *,
    basket_type: Optional[Union[str, _models.BasketType]] = None,
    multiplier: Optional[float] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", "application/json")

    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets/{basketId}"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    if basket_type is not None:
        _params["basketType"] = _SERIALIZER.query("basket_type", basket_type, "str")
    if multiplier is not None:
        _params["multiplier"] = _SERIALIZER.query("multiplier", multiplier, "float")

    # Construct headers
    _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_update_basket_request(  # pylint: disable=name-too-long
    basket_id: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets/{basketId}"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    if content_type is not None:
        _headers["content-type"] = _SERIALIZER.header("content_type", content_type, "str")

    return HttpRequest(method="PATCH", url=_url, headers=_headers, **kwargs)


def build_basket_scan_service_list_baskets_request(**kwargs: Any) -> HttpRequest:  # pylint: disable=name-too-long
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets"

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, headers=_headers, **kwargs)


def build_basket_scan_service_create_basket_request(**kwargs: Any) -> HttpRequest:  # pylint: disable=name-too-long
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets"

    # Construct headers
    if content_type is not None:
        _headers["content-type"] = _SERIALIZER.header("content_type", content_type, "str")
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_basket_scan_service_get_basket_analyzed_data_request(  # pylint: disable=name-too-long
    basket_id: str,
    *,
    currency: Optional[str] = None,
    adv: Optional[Union[str, _models.AdvType]] = None,
    max_participation: Optional[float] = None,
    way: Optional[Union[str, _models.Way]] = None,
    basket_type: Optional[Union[str, _models.BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets/{basketId}/analyze"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")
    if adv is not None:
        _params["adv"] = _SERIALIZER.query("adv", adv, "str")
    if max_participation is not None:
        _params["maxParticipation"] = _SERIALIZER.query("max_participation", max_participation, "float")
    if way is not None:
        _params["way"] = _SERIALIZER.query("way", way, "str")
    if basket_type is not None:
        _params["basketType"] = _SERIALIZER.query("basket_type", basket_type, "str")
    if multiplier is not None:
        _params["multiplier"] = _SERIALIZER.query("multiplier", multiplier, "float")
    if volumes is not None:
        _params["volumes"] = [_SERIALIZER.query("volumes", q, "str") if q is not None else "" for q in volumes]

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_get_basket_export_data_json_request(  # pylint: disable=name-too-long
    basket_id: str,
    *,
    exec_start_time: str,
    max_open_adv_percentage: float,
    max_intra_day_adv_percentage: float,
    max_close_adv_percentage: float,
    currency: Optional[str] = None,
    adv: Optional[Union[str, _models.AdvType]] = None,
    max_participation: Optional[float] = None,
    way: Optional[Union[str, _models.Way]] = None,
    basket_type: Optional[Union[str, _models.BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
    benchmark_index: Optional[str] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept: Literal["application/json"] = kwargs.pop("accept", _headers.pop("accept", "application/json"))
    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets/{basketId}/export"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    _params["execStartTime"] = _SERIALIZER.query("exec_start_time", exec_start_time, "str")
    _params["maxOpenAdvPercentage"] = _SERIALIZER.query("max_open_adv_percentage", max_open_adv_percentage, "float")
    _params["maxIntraDayAdvPercentage"] = _SERIALIZER.query(
        "max_intra_day_adv_percentage", max_intra_day_adv_percentage, "float"
    )
    _params["maxCloseAdvPercentage"] = _SERIALIZER.query("max_close_adv_percentage", max_close_adv_percentage, "float")
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")
    if adv is not None:
        _params["adv"] = _SERIALIZER.query("adv", adv, "str")
    if max_participation is not None:
        _params["maxParticipation"] = _SERIALIZER.query("max_participation", max_participation, "float")
    if way is not None:
        _params["way"] = _SERIALIZER.query("way", way, "str")
    if basket_type is not None:
        _params["basketType"] = _SERIALIZER.query("basket_type", basket_type, "str")
    if multiplier is not None:
        _params["multiplier"] = _SERIALIZER.query("multiplier", multiplier, "float")
    if volumes is not None:
        _params["volumes"] = [_SERIALIZER.query("volumes", q, "str") if q is not None else "" for q in volumes]
    if benchmark_index is not None:
        _params["benchmarkIndex"] = _SERIALIZER.query("benchmark_index", benchmark_index, "str")

    # Construct headers
    _headers["accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_get_basket_export_data_pdf_request(  # pylint: disable=name-too-long
    basket_id: str,
    *,
    exec_start_time: str,
    max_open_adv_percentage: float,
    max_intra_day_adv_percentage: float,
    max_close_adv_percentage: float,
    currency: Optional[str] = None,
    adv: Optional[Union[str, _models.AdvType]] = None,
    max_participation: Optional[float] = None,
    way: Optional[Union[str, _models.Way]] = None,
    basket_type: Optional[Union[str, _models.BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
    benchmark_index: Optional[str] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept: Literal["application/pdf"] = kwargs.pop("accept", _headers.pop("accept", "application/pdf"))
    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets/{basketId}/export"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    _params["execStartTime"] = _SERIALIZER.query("exec_start_time", exec_start_time, "str")
    _params["maxOpenAdvPercentage"] = _SERIALIZER.query("max_open_adv_percentage", max_open_adv_percentage, "float")
    _params["maxIntraDayAdvPercentage"] = _SERIALIZER.query(
        "max_intra_day_adv_percentage", max_intra_day_adv_percentage, "float"
    )
    _params["maxCloseAdvPercentage"] = _SERIALIZER.query("max_close_adv_percentage", max_close_adv_percentage, "float")
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")
    if adv is not None:
        _params["adv"] = _SERIALIZER.query("adv", adv, "str")
    if max_participation is not None:
        _params["maxParticipation"] = _SERIALIZER.query("max_participation", max_participation, "float")
    if way is not None:
        _params["way"] = _SERIALIZER.query("way", way, "str")
    if basket_type is not None:
        _params["basketType"] = _SERIALIZER.query("basket_type", basket_type, "str")
    if multiplier is not None:
        _params["multiplier"] = _SERIALIZER.query("multiplier", multiplier, "float")
    if volumes is not None:
        _params["volumes"] = [_SERIALIZER.query("volumes", q, "str") if q is not None else "" for q in volumes]
    if benchmark_index is not None:
        _params["benchmarkIndex"] = _SERIALIZER.query("benchmark_index", benchmark_index, "str")

    # Construct headers
    _headers["accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_get_basket_export_data_excel_request(  # pylint: disable=name-too-long
    basket_id: str,
    *,
    exec_start_time: str,
    max_open_adv_percentage: float,
    max_intra_day_adv_percentage: float,
    max_close_adv_percentage: float,
    currency: Optional[str] = None,
    adv: Optional[Union[str, _models.AdvType]] = None,
    max_participation: Optional[float] = None,
    way: Optional[Union[str, _models.Way]] = None,
    basket_type: Optional[Union[str, _models.BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
    benchmark_index: Optional[str] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept: Literal["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"] = kwargs.pop(
        "accept", _headers.pop("accept", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    )
    # Construct URL
    _url = "/socgen/basket-scan/v1/baskets/{basketId}/export"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    _params["execStartTime"] = _SERIALIZER.query("exec_start_time", exec_start_time, "str")
    _params["maxOpenAdvPercentage"] = _SERIALIZER.query("max_open_adv_percentage", max_open_adv_percentage, "float")
    _params["maxIntraDayAdvPercentage"] = _SERIALIZER.query(
        "max_intra_day_adv_percentage", max_intra_day_adv_percentage, "float"
    )
    _params["maxCloseAdvPercentage"] = _SERIALIZER.query("max_close_adv_percentage", max_close_adv_percentage, "float")
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")
    if adv is not None:
        _params["adv"] = _SERIALIZER.query("adv", adv, "str")
    if max_participation is not None:
        _params["maxParticipation"] = _SERIALIZER.query("max_participation", max_participation, "float")
    if way is not None:
        _params["way"] = _SERIALIZER.query("way", way, "str")
    if basket_type is not None:
        _params["basketType"] = _SERIALIZER.query("basket_type", basket_type, "str")
    if multiplier is not None:
        _params["multiplier"] = _SERIALIZER.query("multiplier", multiplier, "float")
    if volumes is not None:
        _params["volumes"] = [_SERIALIZER.query("volumes", q, "str") if q is not None else "" for q in volumes]
    if benchmark_index is not None:
        _params["benchmarkIndex"] = _SERIALIZER.query("benchmark_index", benchmark_index, "str")

    # Construct headers
    _headers["accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_get_esg_request(  # pylint: disable=name-too-long
    basket_id: str,
    *,
    currency: Optional[str] = None,
    way: Optional[Union[str, _models.Way]] = None,
    basket_type: Optional[Union[str, _models.BasketType]] = None,
    multiplier: Optional[float] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/esg/{basketId}"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")
    if way is not None:
        _params["way"] = _SERIALIZER.query("way", way, "str")
    if basket_type is not None:
        _params["basketType"] = _SERIALIZER.query("basket_type", basket_type, "str")
    if multiplier is not None:
        _params["multiplier"] = _SERIALIZER.query("multiplier", multiplier, "float")

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_perform_execution_analysis_by_timeframe_request(  # pylint: disable=name-too-long
    basket_id: str,
    *,
    exec_start_time: str,
    max_participation: float,
    way: Optional[Union[str, _models.Way]] = None,
    currency: Optional[str] = None,
    adv_type: Optional[Union[str, _models.AdvType]] = None,
    basket_type: Optional[Union[str, _models.BasketType]] = None,
    multiplier: Optional[float] = None,
    volumes: Optional[list[str]] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/execution/{basketId}/by-timeframe"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    _params["execStartTime"] = _SERIALIZER.query("exec_start_time", exec_start_time, "str")
    _params["maxParticipation"] = _SERIALIZER.query("max_participation", max_participation, "float")
    if way is not None:
        _params["way"] = _SERIALIZER.query("way", way, "str")
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")
    if adv_type is not None:
        _params["advType"] = _SERIALIZER.query("adv_type", adv_type, "str")
    if basket_type is not None:
        _params["basketType"] = _SERIALIZER.query("basket_type", basket_type, "str")
    if multiplier is not None:
        _params["multiplier"] = _SERIALIZER.query("multiplier", multiplier, "float")
    if volumes is not None:
        _params["volumes"] = [_SERIALIZER.query("volumes", q, "str") if q is not None else "" for q in volumes]

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_perform_target_close_analysis_request(  # pylint: disable=name-too-long
    basket_id: str,
    *,
    exec_start_time: str,
    max_open_adv_percentage: float,
    max_intra_day_adv_percentage: float,
    max_close_adv_percentage: float,
    currency: Optional[str] = None,
    adv_type: Optional[Union[str, _models.AdvType]] = None,
    basket_type: Optional[Union[str, _models.BasketType]] = None,
    multiplier: Optional[float] = None,
    exec_start_date: Optional[datetime.datetime] = None,
    volumes: Optional[list[str]] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/execution/{basketId}/target-close"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    _params["execStartTime"] = _SERIALIZER.query("exec_start_time", exec_start_time, "str")
    _params["maxOpenAdvPercentage"] = _SERIALIZER.query("max_open_adv_percentage", max_open_adv_percentage, "float")
    _params["maxIntraDayAdvPercentage"] = _SERIALIZER.query(
        "max_intra_day_adv_percentage", max_intra_day_adv_percentage, "float"
    )
    _params["maxCloseAdvPercentage"] = _SERIALIZER.query("max_close_adv_percentage", max_close_adv_percentage, "float")
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")
    if adv_type is not None:
        _params["advType"] = _SERIALIZER.query("adv_type", adv_type, "str")
    if basket_type is not None:
        _params["basketType"] = _SERIALIZER.query("basket_type", basket_type, "str")
    if multiplier is not None:
        _params["multiplier"] = _SERIALIZER.query("multiplier", multiplier, "float")
    if exec_start_date is not None:
        _params["execStartDate"] = _SERIALIZER.query("exec_start_date", exec_start_date, "iso-8601")
    if volumes is not None:
        _params["volumes"] = [_SERIALIZER.query("volumes", q, "str") if q is not None else "" for q in volumes]

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_get_factors_request(  # pylint: disable=name-too-long
    basket_id: str, *, benchmark_index: Optional[str] = None, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/factors/{basketId}"
    path_format_arguments = {
        "basketId": _SERIALIZER.url("basket_id", basket_id, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct parameters
    if benchmark_index is not None:
        _params["benchmarkIndex"] = _SERIALIZER.query("benchmark_index", benchmark_index, "str")

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_basket_scan_service_get_benchmarks_request(**kwargs: Any) -> HttpRequest:  # pylint: disable=name-too-long
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/factors/benchmarks"

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, headers=_headers, **kwargs)


def build_basket_scan_service_validate_instruments_request(  # pylint: disable=name-too-long
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/basket-scan/v1/instruments/validate"

    # Construct headers
    if content_type is not None:
        _headers["content-type"] = _SERIALIZER.header("content_type", content_type, "str")
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_curve_follower_service_list_curves_request(  # pylint: disable=name-too-long
    *, currency: Optional[str] = None, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/curve-follower/v1/curves"

    # Construct parameters
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_curve_follower_service_compute_historical_rates_and_regression_indicators_request(  # pylint: disable=name-too-long
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/curve-follower/v1/strategies"

    # Construct headers
    if content_type is not None:
        _headers["content-type"] = _SERIALIZER.header("content_type", content_type, "str")
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_fx_event_tracker_service_get_currency_pairs_request(  # pylint: disable=name-too-long
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/fx-event-tracker/v1/currency-pairs"

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, headers=_headers, **kwargs)


def build_fx_event_tracker_service_get_volatility_overnight_request(  # pylint: disable=name-too-long
    *,
    currency_pair: Optional[str] = None,
    volatility_overnight_date: Optional[datetime.datetime] = None,
    start_date: Optional[datetime.datetime] = None,
    end_date: Optional[datetime.datetime] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/fx-event-tracker/v1/volatility-overnight"

    # Construct parameters
    if currency_pair is not None:
        _params["currencyPair"] = _SERIALIZER.query("currency_pair", currency_pair, "str")
    if volatility_overnight_date is not None:
        _params["volatilityOvernightDate"] = _SERIALIZER.query(
            "volatility_overnight_date", volatility_overnight_date, "iso-8601"
        )
    if start_date is not None:
        _params["startDate"] = _SERIALIZER.query("start_date", start_date, "iso-8601")
    if end_date is not None:
        _params["endDate"] = _SERIALIZER.query("end_date", end_date, "iso-8601")

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_fx_event_tracker_service_get_volatility_overnight_range_request(  # pylint: disable=name-too-long
    *,
    currency_pair: Optional[str] = None,
    volatility_overnight_start_date: Optional[datetime.datetime] = None,
    volatility_overnight_end_date: Optional[datetime.datetime] = None,
    start_date: Optional[datetime.datetime] = None,
    end_date: Optional[datetime.datetime] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/fx-event-tracker/v1/volatility-overnight-range"

    # Construct parameters
    if currency_pair is not None:
        _params["currencyPair"] = _SERIALIZER.query("currency_pair", currency_pair, "str")
    if volatility_overnight_start_date is not None:
        _params["volatilityOvernightStartDate"] = _SERIALIZER.query(
            "volatility_overnight_start_date", volatility_overnight_start_date, "iso-8601"
        )
    if volatility_overnight_end_date is not None:
        _params["volatilityOvernightEndDate"] = _SERIALIZER.query(
            "volatility_overnight_end_date", volatility_overnight_end_date, "iso-8601"
        )
    if start_date is not None:
        _params["startDate"] = _SERIALIZER.query("start_date", start_date, "iso-8601")
    if end_date is not None:
        _params["endDate"] = _SERIALIZER.query("end_date", end_date, "iso-8601")

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_fx_event_tracker_service_compute_event_premiums_request(  # pylint: disable=name-too-long
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/fx-event-tracker/v1/event-premiums"

    # Construct headers
    if content_type is not None:
        _headers["content-type"] = _SERIALIZER.header("content_type", content_type, "str")
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_fx_event_tracker_service_get_market_events_request(  # pylint: disable=name-too-long
    *,
    currency_pair: str,
    event_title: Optional[str] = None,
    start_date: Optional[datetime.datetime] = None,
    page_size: Optional[int] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/fx-event-tracker/v1/market-events"

    # Construct parameters
    _params["currencyPair"] = _SERIALIZER.query("currency_pair", currency_pair, "str")
    if event_title is not None:
        _params["eventTitle"] = _SERIALIZER.query("event_title", event_title, "str")
    if start_date is not None:
        _params["startDate"] = _SERIALIZER.query("start_date", start_date, "iso-8601")
    if page_size is not None:
        _params["pageSize"] = _SERIALIZER.query("page_size", page_size, "int")

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_sustainable_bond_screener_service_get_sustainable_bonds_request(  # pylint: disable=name-too-long
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/sustainablebondscreener/v1/sustainablebonds"

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, headers=_headers, **kwargs)


def build_sustainable_bond_screener_service_get_historical_data_request(  # pylint: disable=name-too-long
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/sustainablebondscreener/v1/sustainablebonds"

    # Construct headers
    if content_type is not None:
        _headers["content-type"] = _SERIALIZER.header("content_type", content_type, "str")
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_market_data_service_data_catalog_describe_all_sources_request(  # pylint: disable=name-too-long
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    accept = _headers.pop("Accept", "application/json")

    # Construct URL
    _url = "/socgen/market-data/v1/sources"

    # Construct headers
    _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, headers=_headers, **kwargs)


def build_market_data_service_data_catalog_describe_products_by_source_request(  # pylint: disable=name-too-long
    source_name: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    accept = _headers.pop("Accept", "application/json")

    # Construct URL
    _url = "/socgen/market-data/v1/sources/{sourceName}/products"
    path_format_arguments = {
        "sourceName": _SERIALIZER.url("source_name", source_name, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, headers=_headers, **kwargs)


def build_market_data_service_data_catalog_describe_single_product_by_source_request(  # pylint: disable=name-too-long
    source_name: str, product_name: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    accept = _headers.pop("Accept", "application/json")

    # Construct URL
    _url = "/socgen/market-data/v1/sources/{sourceName}/products/{productName}"
    path_format_arguments = {
        "sourceName": _SERIALIZER.url("source_name", source_name, "str"),
        "productName": _SERIALIZER.url("product_name", product_name, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, headers=_headers, **kwargs)


def build_market_data_service_explorer_search_instruments_by_constraints_request(  # pylint: disable=name-too-long
    source_name: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
    accept = _headers.pop("Accept", "application/json")

    # Construct URL
    _url = "/socgen/market-data/v1/sources/{sourceName}/instruments"
    path_format_arguments = {
        "sourceName": _SERIALIZER.url("source_name", source_name, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    if content_type is not None:
        _headers["Content-Type"] = _SERIALIZER.header("content_type", content_type, "str")
    _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_market_data_service_explorer_lookup_instruments_fields_values_request(  # pylint: disable=name-too-long
    source_name: str, field_name: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
    accept = _headers.pop("Accept", "application/json")

    # Construct URL
    _url = "/socgen/market-data/v1/sources/{sourceName}/instruments/fields/{fieldName}"
    path_format_arguments = {
        "sourceName": _SERIALIZER.url("source_name", source_name, "str"),
        "fieldName": _SERIALIZER.url("field_name", field_name, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    if content_type is not None:
        _headers["Content-Type"] = _SERIALIZER.header("content_type", content_type, "str")
    _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_market_data_service_quotes_query_quotes_request(  # pylint: disable=name-too-long
    source_name: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/market-data/v1/sources/{sourceName}/quotes"
    path_format_arguments = {
        "sourceName": _SERIALIZER.url("source_name", source_name, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    if content_type is not None:
        _headers["Content-Type"] = _SERIALIZER.header("content_type", content_type, "str")
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_market_data_service_quotes_query_quote_updates_request(  # pylint: disable=name-too-long
    source_name: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
    accept = _headers.pop("Accept", "application/json")

    # Construct URL
    _url = "/socgen/market-data/v1/sources/{sourceName}/quotes/updates"
    path_format_arguments = {
        "sourceName": _SERIALIZER.url("source_name", source_name, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    if content_type is not None:
        _headers["Content-Type"] = _SERIALIZER.header("content_type", content_type, "str")
    _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_market_data_service_quotes_query_live_quotes_request(  # pylint: disable=name-too-long
    source_name: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
    accept = _headers.pop("Accept", "application/json")

    # Construct URL
    _url = "/socgen/market-data/v1/sources/{sourceName}/live-quotes"
    path_format_arguments = {
        "sourceName": _SERIALIZER.url("source_name", source_name, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    if content_type is not None:
        _headers["Content-Type"] = _SERIALIZER.header("content_type", content_type, "str")
    _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_market_data_service_quotes_query_quotes_by_constraints_request(  # pylint: disable=name-too-long
    source_name: str, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/market-data/v1/sources/{sourceName}/quotes-by-constraints"
    path_format_arguments = {
        "sourceName": _SERIALIZER.url("source_name", source_name, "str"),
    }

    _url: str = _url.format(**path_format_arguments)  # type: ignore

    # Construct headers
    if content_type is not None:
        _headers["Content-Type"] = _SERIALIZER.header("content_type", content_type, "str")
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_cof_box_service_get_analysis_types_request(**kwargs: Any) -> HttpRequest:  # pylint: disable=name-too-long
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/cofbox/v1/analysis-types"

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, headers=_headers, **kwargs)


def build_cof_box_service_post_analysis_request(**kwargs: Any) -> HttpRequest:  # pylint: disable=name-too-long
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})

    content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/cofbox/v1/analysis"

    # Construct headers
    if content_type is not None:
        _headers["content-type"] = _SERIALIZER.header("content_type", content_type, "str")
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="POST", url=_url, headers=_headers, **kwargs)


def build_cof_box_service_get_instruments_request(  # pylint: disable=name-too-long
    *, instrument_codes: Optional[list[str]] = None, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/cofbox/v1/instruments"

    # Construct parameters
    if instrument_codes is not None:
        _params["instrumentCodes"] = [
            _SERIALIZER.query("instrument_codes", q, "str") if q is not None else "" for q in instrument_codes
        ]

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_cof_box_service_get_instruments_details_request(  # pylint: disable=name-too-long
    *, instrument_codes: Optional[list[str]] = None, as_of_date: Optional[datetime.datetime] = None, **kwargs: Any
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/cofbox/v1/instruments-details"

    # Construct parameters
    if instrument_codes is not None:
        _params["instrumentCodes"] = [
            _SERIALIZER.query("instrument_codes", q, "str") if q is not None else "" for q in instrument_codes
        ]
    if as_of_date is not None:
        _params["asOfDate"] = _SERIALIZER.query("as_of_date", as_of_date, "iso-8601")

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


def build_cof_box_service_get_instruments_search_request(  # pylint: disable=name-too-long
    *,
    underlying_code: Optional[str] = None,
    currency: Optional[str] = None,
    reference_rate: Optional[str] = None,
    **kwargs: Any,
) -> HttpRequest:
    _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
    _params = case_insensitive_dict(kwargs.pop("params", {}) or {})

    accept = _headers.pop("Accept", None)

    # Construct URL
    _url = "/socgen/cofbox/v1/instruments-search"

    # Construct parameters
    if underlying_code is not None:
        _params["underlyingCode"] = _SERIALIZER.query("underlying_code", underlying_code, "str")
    if currency is not None:
        _params["currency"] = _SERIALIZER.query("currency", currency, "str")
    if reference_rate is not None:
        _params["referenceRate"] = _SERIALIZER.query("reference_rate", reference_rate, "str")

    # Construct headers
    if accept is not None:
        _headers["Accept"] = _SERIALIZER.header("accept", accept, "str")

    return HttpRequest(method="GET", url=_url, params=_params, headers=_headers, **kwargs)


class basketScanServiceOperations:
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~socgenapi.SocGenAPIClient`'s
        :attr:`basket_scan_service` attribute.
    """

    def __init__(self, *args, **kwargs) -> None:
        input_args = list(args)
        self._client: PipelineClient = input_args.pop(0) if input_args else kwargs.pop("client")
        self._config: SocGenAPIClientConfiguration = input_args.pop(0) if input_args else kwargs.pop("config")
        self._serialize: Serializer = input_args.pop(0) if input_args else kwargs.pop("serializer")
        self._deserialize: Deserializer = input_args.pop(0) if input_args else kwargs.pop("deserializer")

    def delete_basket(self, basket_id: str, **kwargs: Any) -> None:  # pylint: disable=inconsistent-return-statements
        """Delete an existing basket.

        Delete an existing basket.

        :param basket_id: Identifier of the basket to delete. Required.
        :type basket_id: str
        :return: None
        :rtype: None
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[None] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_delete_basket_request(
            basket_id=basket_id,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = False
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [204]:
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 412:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 423:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if cls:
            return cls(pipeline_response, None, {})  # type: ignore

    def get_basket(
        self,
        basket_id: str,
        *,
        basket_type: Optional[Union[str, _models.BasketType]] = None,
        multiplier: Optional[float] = None,
        **kwargs: Any,
    ) -> _models.GetBasketResponse:
        """Retrieve details and content of an existing basket.

        Retrieve details and content of an existing basket.

        :param basket_id: Required.
        :type basket_id: str
        :keyword basket_type: Basket type (to analyze baskets from YouTrack or indices). Known values
         are: "Basket", "Index", and "YouTrack". Default value is None.
        :paramtype basket_type: str or ~socgenapi.models.BasketType
        :keyword multiplier: Total nominal if the basketType is different than basket. Default value is
         None.
        :paramtype multiplier: float
        :return: GetBasketResponse. The GetBasketResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.GetBasketResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.GetBasketResponse] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_get_basket_request(
            basket_id=basket_id,
            basket_type=basket_type,
            multiplier=multiplier,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.GetBasketResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, {})  # type: ignore

        return deserialized  # type: ignore

    @overload
    def update_basket(
        self, basket_id: str, body: Optional[_models.BasketUpdateRequest] = None, *, content_type: str, **kwargs: Any
    ) -> None:
        """Update an existing basket.

        Update an existing basket.

        :param basket_id: Identifier of the basket to update. Required.
        :type basket_id: str
        :param body: Basket content. Default value is None.
        :type body: ~socgenapi.models.BasketUpdateRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: None
        :rtype: None
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def update_basket(self, basket_id: str, body: Optional[JSON] = None, *, content_type: str, **kwargs: Any) -> None:
        """Update an existing basket.

        Update an existing basket.

        :param basket_id: Identifier of the basket to update. Required.
        :type basket_id: str
        :param body: Basket content. Default value is None.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: None
        :rtype: None
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def update_basket(
        self, basket_id: str, body: Optional[IO[bytes]] = None, *, content_type: str, **kwargs: Any
    ) -> None:
        """Update an existing basket.

        Update an existing basket.

        :param basket_id: Identifier of the basket to update. Required.
        :type basket_id: str
        :param body: Basket content. Default value is None.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Required.
        :paramtype content_type: str
        :return: None
        :rtype: None
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def update_basket(  # pylint: disable=inconsistent-return-statements
        self, basket_id: str, body: Optional[Union[_models.BasketUpdateRequest, JSON, IO[bytes]]] = None, **kwargs: Any
    ) -> None:
        """Update an existing basket.

        Update an existing basket.

        :param basket_id: Identifier of the basket to update. Required.
        :type basket_id: str
        :param body: Basket content. Is one of the following types: BasketUpdateRequest, JSON,
         IO[bytes] Default value is None.
        :type body: ~socgenapi.models.BasketUpdateRequest or JSON or IO[bytes]
        :return: None
        :rtype: None
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
        content_type = content_type if body else None
        cls: ClsType[None] = kwargs.pop("cls", None)

        content_type = content_type or "application/json" if body else None
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            if body is not None:
                _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore
            else:
                _content = None

        _request = build_basket_scan_service_update_basket_request(
            basket_id=basket_id,
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = False
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [204]:
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if cls:
            return cls(pipeline_response, None, {})  # type: ignore

    def list_baskets(self, **kwargs: Any) -> _models.GetBasketsResponse:
        """Retrieve the list of existing baskets including shared and public ones.

        Retrieve the list of existing baskets including shared and public ones.

        :return: GetBasketsResponse. The GetBasketsResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.GetBasketsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.GetBasketsResponse] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_list_baskets_request(
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.GetBasketsResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    @overload
    def create_basket(
        self, body: Optional[_models.BasketCreationRequest] = None, *, content_type: str, **kwargs: Any
    ) -> _models.BasketCreationResponse:
        """Create a new basket.

        Create a new basket.

        :param body: The basket to create : a basket can be created by either setting a total and then
         providing a weight for each instrument, or by not providing a total and setting nominal or
         quantity for each instrument in the basket.
         Required: basketName, identifierType and inputType.
         identifierType: Type of instrument identifiers.
         nominalOrQuantity: Defines if inputs will be number of shares or amounts.
         total: Optional. If set, the instruments should have weights.
         nominalCurrency: Required if nominalOrQuantity=Nominal.
         timeToLive: 'OneMonth' by default. Default value is None.
        :type body: ~socgenapi.models.BasketCreationRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: BasketCreationResponse. The BasketCreationResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.BasketCreationResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def create_basket(
        self, body: Optional[JSON] = None, *, content_type: str, **kwargs: Any
    ) -> _models.BasketCreationResponse:
        """Create a new basket.

        Create a new basket.

        :param body: The basket to create : a basket can be created by either setting a total and then
         providing a weight for each instrument, or by not providing a total and setting nominal or
         quantity for each instrument in the basket.
         Required: basketName, identifierType and inputType.
         identifierType: Type of instrument identifiers.
         nominalOrQuantity: Defines if inputs will be number of shares or amounts.
         total: Optional. If set, the instruments should have weights.
         nominalCurrency: Required if nominalOrQuantity=Nominal.
         timeToLive: 'OneMonth' by default. Default value is None.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: BasketCreationResponse. The BasketCreationResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.BasketCreationResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def create_basket(
        self, body: Optional[IO[bytes]] = None, *, content_type: str, **kwargs: Any
    ) -> _models.BasketCreationResponse:
        """Create a new basket.

        Create a new basket.

        :param body: The basket to create : a basket can be created by either setting a total and then
         providing a weight for each instrument, or by not providing a total and setting nominal or
         quantity for each instrument in the basket.
         Required: basketName, identifierType and inputType.
         identifierType: Type of instrument identifiers.
         nominalOrQuantity: Defines if inputs will be number of shares or amounts.
         total: Optional. If set, the instruments should have weights.
         nominalCurrency: Required if nominalOrQuantity=Nominal.
         timeToLive: 'OneMonth' by default. Default value is None.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Required.
        :paramtype content_type: str
        :return: BasketCreationResponse. The BasketCreationResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.BasketCreationResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def create_basket(
        self, body: Optional[Union[_models.BasketCreationRequest, JSON, IO[bytes]]] = None, **kwargs: Any
    ) -> _models.BasketCreationResponse:
        """Create a new basket.

        Create a new basket.

        :param body: The basket to create : a basket can be created by either setting a total and then
         providing a weight for each instrument, or by not providing a total and setting nominal or
         quantity for each instrument in the basket.
         Required: basketName, identifierType and inputType.
         identifierType: Type of instrument identifiers.
         nominalOrQuantity: Defines if inputs will be number of shares or amounts.
         total: Optional. If set, the instruments should have weights.
         nominalCurrency: Required if nominalOrQuantity=Nominal.
         timeToLive: 'OneMonth' by default. Is one of the following types: BasketCreationRequest, JSON,
         IO[bytes] Default value is None.
        :type body: ~socgenapi.models.BasketCreationRequest or JSON or IO[bytes]
        :return: BasketCreationResponse. The BasketCreationResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.BasketCreationResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
        content_type = content_type if body else None
        cls: ClsType[_models.BasketCreationResponse] = kwargs.pop("cls", None)

        content_type = content_type or "application/json" if body else None
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            if body is not None:
                _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore
            else:
                _content = None

        _request = build_basket_scan_service_create_basket_request(
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [201]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.BasketCreationResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_basket_analyzed_data(
        self,
        basket_id: str,
        *,
        currency: Optional[str] = None,
        adv: Optional[Union[str, _models.AdvType]] = None,
        max_participation: Optional[float] = None,
        way: Optional[Union[str, _models.Way]] = None,
        basket_type: Optional[Union[str, _models.BasketType]] = None,
        multiplier: Optional[float] = None,
        volumes: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> _models.BasketAnalysisComputedResponse:
        """Get all analyzed data for a basket.

        Get all analyzed data for a basket.

        :param basket_id: Identifier of the basket. Required.
        :type basket_id: str
        :keyword currency: Currency to convert the returned nominal values ('EUR' by default). Default
         value is None.
        :paramtype currency: str
        :keyword adv: ADV period used to compute impact ('ADV20' by default). Known values are:
         "Adv5d", "Adv10d", "Adv20d", "Adv30d", "Adv3M", "ACV", and "AOV". Default value is None.
        :paramtype adv: str or ~socgenapi.models.AdvType
        :keyword max_participation: Maximum % of ADV allowed (used for impact computation). Default
         value is None.
        :paramtype max_participation: float
        :keyword way: Way (if not set, returns both Buy and Sell). Known values are: "Buy", "Sell", and
         "Total". Default value is None.
        :paramtype way: str or ~socgenapi.models.Way
        :keyword basket_type: Basket type (to analyze baskets from YouTrack or indices). Known values
         are: "Basket", "Index", and "YouTrack". Default value is None.
        :paramtype basket_type: str or ~socgenapi.models.BasketType
        :keyword multiplier: Total nominal if the basketType is different than basket. Default value is
         None.
        :paramtype multiplier: float
        :keyword volumes: The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'Main only' is used if not
         specified). Default value is None.
        :paramtype volumes: list[str]
        :return: BasketAnalysisComputedResponse. The BasketAnalysisComputedResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.BasketAnalysisComputedResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.BasketAnalysisComputedResponse] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_get_basket_analyzed_data_request(
            basket_id=basket_id,
            currency=currency,
            adv=adv,
            max_participation=max_participation,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.BasketAnalysisComputedResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_basket_export_data_json(
        self,
        basket_id: str,
        *,
        exec_start_time: str,
        max_open_adv_percentage: float,
        max_intra_day_adv_percentage: float,
        max_close_adv_percentage: float,
        currency: Optional[str] = None,
        adv: Optional[Union[str, _models.AdvType]] = None,
        max_participation: Optional[float] = None,
        way: Optional[Union[str, _models.Way]] = None,
        basket_type: Optional[Union[str, _models.BasketType]] = None,
        multiplier: Optional[float] = None,
        volumes: Optional[list[str]] = None,
        benchmark_index: Optional[str] = None,
        **kwargs: Any,
    ) -> _models.BasketAnalysisComputedResponse:
        """Get all analyzed data for a basket.

        Get all analyzed data for a basket.

        :param basket_id: Identifier of the basket. Required.
        :type basket_id: str
        :keyword exec_start_time: Time at which the analysis starts (format: HH:MM:SS, timezone: UTC).
         Required.
        :paramtype exec_start_time: str
        :keyword max_open_adv_percentage: Maximum ratio of the ADV that can be traded at open.
         Required.
        :paramtype max_open_adv_percentage: float
        :keyword max_intra_day_adv_percentage: Maximum ratio of the ADV that can be traded between open
         and close. Required.
        :paramtype max_intra_day_adv_percentage: float
        :keyword max_close_adv_percentage: Maximum ratio of the ADV that can be traded at close.
         Required.
        :paramtype max_close_adv_percentage: float
        :keyword currency: Currency to convert the returned nominal values ('EUR' by default). Default
         value is None.
        :paramtype currency: str
        :keyword adv: ADV period used to compute impact ('ADV20' by default). Known values are:
         "Adv5d", "Adv10d", "Adv20d", "Adv30d", "Adv3M", "ACV", and "AOV". Default value is None.
        :paramtype adv: str or ~socgenapi.models.AdvType
        :keyword max_participation: Maximum % of ADV allowed (used for impact computation). Default
         value is None.
        :paramtype max_participation: float
        :keyword way: Way (if not set, returns both Buy and Sell). Known values are: "Buy", "Sell", and
         "Total". Default value is None.
        :paramtype way: str or ~socgenapi.models.Way
        :keyword basket_type: Basket type (to analyze baskets from YouTrack or indices). Known values
         are: "Basket", "Index", and "YouTrack". Default value is None.
        :paramtype basket_type: str or ~socgenapi.models.BasketType
        :keyword multiplier: Total nominal if the basketType is different than basket. Default value is
         None.
        :paramtype multiplier: float
        :keyword volumes: The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'Main only' is used if not
         specified). Default value is None.
        :paramtype volumes: list[str]
        :keyword benchmark_index: The index ticker used for comparison (for example: MXWO INDEX for the
         MSCI World index). Default value is None.
        :paramtype benchmark_index: str
        :return: BasketAnalysisComputedResponse. The BasketAnalysisComputedResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.BasketAnalysisComputedResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        accept: Literal["application/json"] = kwargs.pop("accept", _headers.pop("accept", "application/json"))
        cls: ClsType[_models.BasketAnalysisComputedResponse] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_get_basket_export_data_json_request(
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_open_adv_percentage=max_open_adv_percentage,
            max_intra_day_adv_percentage=max_intra_day_adv_percentage,
            max_close_adv_percentage=max_close_adv_percentage,
            currency=currency,
            adv=adv,
            max_participation=max_participation,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            benchmark_index=benchmark_index,
            accept=accept,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.BasketAnalysisComputedResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_basket_export_data_pdf(
        self,
        basket_id: str,
        *,
        exec_start_time: str,
        max_open_adv_percentage: float,
        max_intra_day_adv_percentage: float,
        max_close_adv_percentage: float,
        currency: Optional[str] = None,
        adv: Optional[Union[str, _models.AdvType]] = None,
        max_participation: Optional[float] = None,
        way: Optional[Union[str, _models.Way]] = None,
        basket_type: Optional[Union[str, _models.BasketType]] = None,
        multiplier: Optional[float] = None,
        volumes: Optional[list[str]] = None,
        benchmark_index: Optional[str] = None,
        **kwargs: Any,
    ) -> Iterator[bytes]:
        """Get all analyzed data for a basket in PDF format.

        Get all analyzed data for a basket in PDF format.

        :param basket_id: Identifier of the basket. Required.
        :type basket_id: str
        :keyword exec_start_time: Time at which the analysis starts (format: HH:MM:SS, timezone: UTC).
         Required.
        :paramtype exec_start_time: str
        :keyword max_open_adv_percentage: Maximum ratio of the ADV that can be traded at open.
         Required.
        :paramtype max_open_adv_percentage: float
        :keyword max_intra_day_adv_percentage: Maximum ratio of the ADV that can be traded between open
         and close. Required.
        :paramtype max_intra_day_adv_percentage: float
        :keyword max_close_adv_percentage: Maximum ratio of the ADV that can be traded at close.
         Required.
        :paramtype max_close_adv_percentage: float
        :keyword currency: Currency to convert the returned nominal values ('EUR' by default). Default
         value is None.
        :paramtype currency: str
        :keyword adv: ADV period used to compute impact ('ADV20' by default). Known values are:
         "Adv5d", "Adv10d", "Adv20d", "Adv30d", "Adv3M", "ACV", and "AOV". Default value is None.
        :paramtype adv: str or ~socgenapi.models.AdvType
        :keyword max_participation: Maximum % of ADV allowed (used for impact computation). Default
         value is None.
        :paramtype max_participation: float
        :keyword way: Way (if not set, returns both Buy and Sell). Known values are: "Buy", "Sell", and
         "Total". Default value is None.
        :paramtype way: str or ~socgenapi.models.Way
        :keyword basket_type: Basket type (to analyze baskets from YouTrack or indices). Known values
         are: "Basket", "Index", and "YouTrack". Default value is None.
        :paramtype basket_type: str or ~socgenapi.models.BasketType
        :keyword multiplier: Total nominal if the basketType is different than basket. Default value is
         None.
        :paramtype multiplier: float
        :keyword volumes: The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'Main only' is used if not
         specified). Default value is None.
        :paramtype volumes: list[str]
        :keyword benchmark_index: The index ticker used for comparison (for example: MXWO INDEX for the
         MSCI World index). Default value is None.
        :paramtype benchmark_index: str
        :return: Iterator[bytes]
        :rtype: Iterator[bytes]
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        accept: Literal["application/pdf"] = kwargs.pop("accept", _headers.pop("accept", "application/pdf"))
        cls: ClsType[Iterator[bytes]] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_get_basket_export_data_pdf_request(
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_open_adv_percentage=max_open_adv_percentage,
            max_intra_day_adv_percentage=max_intra_day_adv_percentage,
            max_close_adv_percentage=max_close_adv_percentage,
            currency=currency,
            adv=adv,
            max_participation=max_participation,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            benchmark_index=benchmark_index,
            accept=accept,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", True)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["Content-Type"] = self._deserialize("str", response.headers.get("Content-Type"))

        deserialized = response.iter_bytes()

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_basket_export_data_excel(
        self,
        basket_id: str,
        *,
        exec_start_time: str,
        max_open_adv_percentage: float,
        max_intra_day_adv_percentage: float,
        max_close_adv_percentage: float,
        currency: Optional[str] = None,
        adv: Optional[Union[str, _models.AdvType]] = None,
        max_participation: Optional[float] = None,
        way: Optional[Union[str, _models.Way]] = None,
        basket_type: Optional[Union[str, _models.BasketType]] = None,
        multiplier: Optional[float] = None,
        volumes: Optional[list[str]] = None,
        benchmark_index: Optional[str] = None,
        **kwargs: Any,
    ) -> Iterator[bytes]:
        """Get all analyzed data for a basket in Excel Spreadsheet format.

        Get all analyzed data for a basket in Excel Spreadsheet format.

        :param basket_id: Identifier of the basket. Required.
        :type basket_id: str
        :keyword exec_start_time: Time at which the analysis starts (format: HH:MM:SS, timezone: UTC).
         Required.
        :paramtype exec_start_time: str
        :keyword max_open_adv_percentage: Maximum ratio of the ADV that can be traded at open.
         Required.
        :paramtype max_open_adv_percentage: float
        :keyword max_intra_day_adv_percentage: Maximum ratio of the ADV that can be traded between open
         and close. Required.
        :paramtype max_intra_day_adv_percentage: float
        :keyword max_close_adv_percentage: Maximum ratio of the ADV that can be traded at close.
         Required.
        :paramtype max_close_adv_percentage: float
        :keyword currency: Currency to convert the returned nominal values ('EUR' by default). Default
         value is None.
        :paramtype currency: str
        :keyword adv: ADV period used to compute impact ('ADV20' by default). Known values are:
         "Adv5d", "Adv10d", "Adv20d", "Adv30d", "Adv3M", "ACV", and "AOV". Default value is None.
        :paramtype adv: str or ~socgenapi.models.AdvType
        :keyword max_participation: Maximum % of ADV allowed (used for impact computation). Default
         value is None.
        :paramtype max_participation: float
        :keyword way: Way (if not set, returns both Buy and Sell). Known values are: "Buy", "Sell", and
         "Total". Default value is None.
        :paramtype way: str or ~socgenapi.models.Way
        :keyword basket_type: Basket type (to analyze baskets from YouTrack or indices). Known values
         are: "Basket", "Index", and "YouTrack". Default value is None.
        :paramtype basket_type: str or ~socgenapi.models.BasketType
        :keyword multiplier: Total nominal if the basketType is different than basket. Default value is
         None.
        :paramtype multiplier: float
        :keyword volumes: The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'Main only' is used if not
         specified). Default value is None.
        :paramtype volumes: list[str]
        :keyword benchmark_index: The index ticker used for comparison (for example: MXWO INDEX for the
         MSCI World index). Default value is None.
        :paramtype benchmark_index: str
        :return: Iterator[bytes]
        :rtype: Iterator[bytes]
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        accept: Literal["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"] = kwargs.pop(
            "accept", _headers.pop("accept", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        )
        cls: ClsType[Iterator[bytes]] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_get_basket_export_data_excel_request(
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_open_adv_percentage=max_open_adv_percentage,
            max_intra_day_adv_percentage=max_intra_day_adv_percentage,
            max_close_adv_percentage=max_close_adv_percentage,
            currency=currency,
            adv=adv,
            max_participation=max_participation,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            benchmark_index=benchmark_index,
            accept=accept,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", True)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["Content-Type"] = self._deserialize("str", response.headers.get("Content-Type"))

        deserialized = response.iter_bytes()

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_esg(
        self,
        basket_id: str,
        *,
        currency: Optional[str] = None,
        way: Optional[Union[str, _models.Way]] = None,
        basket_type: Optional[Union[str, _models.BasketType]] = None,
        multiplier: Optional[float] = None,
        **kwargs: Any,
    ) -> _models.GetEsgResponse:
        """Get ESG, Environmental, Social and Governance scores for a basket.

        Get ESG, Environmental, Social and Governance scores for a basket.

        :param basket_id: Identifier of the basket. Required.
        :type basket_id: str
        :keyword currency: Currency to convert the returned nominal values ('EUR' by default). Default
         value is None.
        :paramtype currency: str
        :keyword way: Way (if not set, returns both Buy and Sell). Known values are: "Buy", "Sell", and
         "Total". Default value is None.
        :paramtype way: str or ~socgenapi.models.Way
        :keyword basket_type: Basket type (to analyze baskets from YouTrack or indices). Known values
         are: "Basket", "Index", and "YouTrack". Default value is None.
        :paramtype basket_type: str or ~socgenapi.models.BasketType
        :keyword multiplier: Total nominal if the basketType is diffeModelrent than basket. Default
         value is None.
        :paramtype multiplier: float
        :return: GetEsgResponse. The GetEsgResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.GetEsgResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.GetEsgResponse] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_get_esg_request(
            basket_id=basket_id,
            currency=currency,
            way=way,
            basket_type=basket_type,
            multiplier=multiplier,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.GetEsgResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def perform_execution_analysis_by_timeframe(
        self,
        basket_id: str,
        *,
        exec_start_time: str,
        max_participation: float,
        way: Optional[Union[str, _models.Way]] = None,
        currency: Optional[str] = None,
        adv_type: Optional[Union[str, _models.AdvType]] = None,
        basket_type: Optional[Union[str, _models.BasketType]] = None,
        multiplier: Optional[float] = None,
        volumes: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> _models.ExecutionResponse:
        """Perform an execution analysis by timeframe for a basket.

        Perform an execution analysis by timeframe for a basket.

        :param basket_id: Identifier of the basket. Required.
        :type basket_id: str
        :keyword exec_start_time: Time at which the execution starts (format: HH:MM:SS, timezone: UTC).
         Required.
        :paramtype exec_start_time: str
        :keyword max_participation: Maximum participation. Required.
        :paramtype max_participation: float
        :keyword way: Way (if not set, returns both Buy and Sell). Known values are: "Buy", "Sell", and
         "Total". Default value is None.
        :paramtype way: str or ~socgenapi.models.Way
        :keyword currency: Currency to convert the returned nominal values. Default value is None.
        :paramtype currency: str
        :keyword adv_type: ADV period used to compute impact ('ADV20' by default). Known values are:
         "Adv5d", "Adv10d", "Adv20d", "Adv30d", "Adv3M", "ACV", and "AOV". Default value is None.
        :paramtype adv_type: str or ~socgenapi.models.AdvType
        :keyword basket_type: Basket type (to analyze baskets from YouTrack or indices). Known values
         are: "Basket", "Index", and "YouTrack". Default value is None.
        :paramtype basket_type: str or ~socgenapi.models.BasketType
        :keyword multiplier: Total nominal if the basketType is different than basket. Default value is
         None.
        :paramtype multiplier: float
        :keyword volumes: The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'IX (deprecated)', 'EB
         (deprecated), 'TQ (deprecated)', 'Main only' is used if not specified). Default value is None.
        :paramtype volumes: list[str]
        :return: ExecutionResponse. The ExecutionResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.ExecutionResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.ExecutionResponse] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_perform_execution_analysis_by_timeframe_request(
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_participation=max_participation,
            way=way,
            currency=currency,
            adv_type=adv_type,
            basket_type=basket_type,
            multiplier=multiplier,
            volumes=volumes,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.ExecutionResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def perform_target_close_analysis(
        self,
        basket_id: str,
        *,
        exec_start_time: str,
        max_open_adv_percentage: float,
        max_intra_day_adv_percentage: float,
        max_close_adv_percentage: float,
        currency: Optional[str] = None,
        adv_type: Optional[Union[str, _models.AdvType]] = None,
        basket_type: Optional[Union[str, _models.BasketType]] = None,
        multiplier: Optional[float] = None,
        exec_start_date: Optional[datetime.datetime] = None,
        volumes: Optional[list[str]] = None,
        **kwargs: Any,
    ) -> _models.TargetCloseResponseDto:
        """Perform a target close analysis on all the instruments of a basket.

        Perform a target close analysis on all the instruments of a basket.

        :param basket_id: Identifier of the basket. Required.
        :type basket_id: str
        :keyword exec_start_time: Time at which the analysis starts (format: HH:MM:SS, timezone: UTC).
         Required.
        :paramtype exec_start_time: str
        :keyword max_open_adv_percentage: Maximum ratio of the ADV that can be traded at open.
         Required.
        :paramtype max_open_adv_percentage: float
        :keyword max_intra_day_adv_percentage: Maximum ratio of the ADV that can be traded between open
         and close. Required.
        :paramtype max_intra_day_adv_percentage: float
        :keyword max_close_adv_percentage: Maximum ratio of the ADV that can be traded at close.
         Required.
        :paramtype max_close_adv_percentage: float
        :keyword currency: Currency to convert the returned nominal values. Default value is None.
        :paramtype currency: str
        :keyword adv_type: ADV period used to compute impact ('ADV20' by default). Known values are:
         "Adv5d", "Adv10d", "Adv20d", "Adv30d", "Adv3M", "ACV", and "AOV". Default value is None.
        :paramtype adv_type: str or ~socgenapi.models.AdvType
        :keyword basket_type: Basket type (to analyze baskets from YouTrack or indices). Known values
         are: "Basket", "Index", and "YouTrack". Default value is None.
        :paramtype basket_type: str or ~socgenapi.models.BasketType
        :keyword multiplier: Total nominal if the basketType is different than basket. Default value is
         None.
        :paramtype multiplier: float
        :keyword exec_start_date: Default value is None.
        :paramtype exec_start_date: ~datetime.datetime
        :keyword volumes: The volumes ('CBOE', 'TURQUOISE', 'AQUIS', 'IX (deprecated)', 'EB
         (deprecated), 'TQ (deprecated)', 'Main only' is used if not specified). Default value is None.
        :paramtype volumes: list[str]
        :return: TargetCloseResponseDto. The TargetCloseResponseDto is compatible with MutableMapping
        :rtype: ~socgenapi.models.TargetCloseResponseDto
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.TargetCloseResponseDto] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_perform_target_close_analysis_request(
            basket_id=basket_id,
            exec_start_time=exec_start_time,
            max_open_adv_percentage=max_open_adv_percentage,
            max_intra_day_adv_percentage=max_intra_day_adv_percentage,
            max_close_adv_percentage=max_close_adv_percentage,
            currency=currency,
            adv_type=adv_type,
            basket_type=basket_type,
            multiplier=multiplier,
            exec_start_date=exec_start_date,
            volumes=volumes,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.TargetCloseResponseDto, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_factors(
        self, basket_id: str, *, benchmark_index: Optional[str] = None, **kwargs: Any
    ) -> _models.FactorsResponse:
        """Returns a factors analysis of your basket compared to a chosen index (benchmark).

        Returns a factors analysis of your basket compared to a chosen index (benchmark).

        :param basket_id: Your basket identifier (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx format).
         Required.
        :type basket_id: str
        :keyword benchmark_index: The index ticker used for comparison (for example: MXWO INDEX for the
         MSCI World index). Default value is None.
        :paramtype benchmark_index: str
        :return: FactorsResponse. The FactorsResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.FactorsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.FactorsResponse] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_get_factors_request(
            basket_id=basket_id,
            benchmark_index=benchmark_index,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.FactorsResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_benchmarks(self, **kwargs: Any) -> _models.BenchmarkResponse:
        """Returns the list of benchmarks which can be used in factor analysis.

        Returns the list of benchmarks which can be used in factor analysis.

        :return: BenchmarkResponse. The BenchmarkResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.BenchmarkResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.BenchmarkResponse] = kwargs.pop("cls", None)

        _request = build_basket_scan_service_get_benchmarks_request(
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.BenchmarkResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    @overload
    def validate_instruments(
        self, body: Optional[_models.InstrumentValidationRequest] = None, *, content_type: str, **kwargs: Any
    ) -> _models.InstrumentValidationResponse:
        """Validate a list of instruments.
        Check if the list is valid for Basket Scan and return invalid instruments.

        Validate a list of instruments.
        Check if the list is valid for Basket Scan and return invalid instruments.

        :param body: List of instruments. Default value is None.
        :type body: ~socgenapi.models.InstrumentValidationRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: InstrumentValidationResponse. The InstrumentValidationResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.InstrumentValidationResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def validate_instruments(
        self, body: Optional[JSON] = None, *, content_type: str, **kwargs: Any
    ) -> _models.InstrumentValidationResponse:
        """Validate a list of instruments.
        Check if the list is valid for Basket Scan and return invalid instruments.

        Validate a list of instruments.
        Check if the list is valid for Basket Scan and return invalid instruments.

        :param body: List of instruments. Default value is None.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: InstrumentValidationResponse. The InstrumentValidationResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.InstrumentValidationResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def validate_instruments(
        self, body: Optional[IO[bytes]] = None, *, content_type: str, **kwargs: Any
    ) -> _models.InstrumentValidationResponse:
        """Validate a list of instruments.
        Check if the list is valid for Basket Scan and return invalid instruments.

        Validate a list of instruments.
        Check if the list is valid for Basket Scan and return invalid instruments.

        :param body: List of instruments. Default value is None.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Required.
        :paramtype content_type: str
        :return: InstrumentValidationResponse. The InstrumentValidationResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.InstrumentValidationResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def validate_instruments(
        self, body: Optional[Union[_models.InstrumentValidationRequest, JSON, IO[bytes]]] = None, **kwargs: Any
    ) -> _models.InstrumentValidationResponse:
        """Validate a list of instruments.
        Check if the list is valid for Basket Scan and return invalid instruments.

        Validate a list of instruments.
        Check if the list is valid for Basket Scan and return invalid instruments.

        :param body: List of instruments. Is one of the following types: InstrumentValidationRequest,
         JSON, IO[bytes] Default value is None.
        :type body: ~socgenapi.models.InstrumentValidationRequest or JSON or IO[bytes]
        :return: InstrumentValidationResponse. The InstrumentValidationResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.InstrumentValidationResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
        content_type = content_type if body else None
        cls: ClsType[_models.InstrumentValidationResponse] = kwargs.pop("cls", None)

        content_type = content_type or "application/json" if body else None
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            if body is not None:
                _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore
            else:
                _content = None

        _request = build_basket_scan_service_validate_instruments_request(
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.InstrumentValidationResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore


class curveFollowerServiceOperations:
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~socgenapi.SocGenAPIClient`'s
        :attr:`curve_follower_service` attribute.
    """

    def __init__(self, *args, **kwargs) -> None:
        input_args = list(args)
        self._client: PipelineClient = input_args.pop(0) if input_args else kwargs.pop("client")
        self._config: SocGenAPIClientConfiguration = input_args.pop(0) if input_args else kwargs.pop("config")
        self._serialize: Serializer = input_args.pop(0) if input_args else kwargs.pop("serializer")
        self._deserialize: Deserializer = input_args.pop(0) if input_args else kwargs.pop("deserializer")

    def list_curves(self, *, currency: Optional[str] = None, **kwargs: Any) -> _models.GetCurvesResponse:
        """List available curves for live pricing and computing the strategies.

        List available curves for live pricing and computing the strategies.

        :keyword currency: Default value is None.
        :paramtype currency: str
        :return: GetCurvesResponse. The GetCurvesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.GetCurvesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.GetCurvesResponse] = kwargs.pop("cls", None)

        _request = build_curve_follower_service_list_curves_request(
            currency=currency,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.GetCurvesResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    @overload
    def compute_historical_rates_and_regression_indicators(  # pylint: disable=name-too-long
        self, body: _models.RatesAndClosestStrategiesAndRegressionRequest, *, content_type: str, **kwargs: Any
    ) -> _models.RatesAndClosestStrategiesAndRegressionResponse:
        """Compute historical rates and regression indicators between main strategy and top basic ones.

        Compute historical rates and regression indicators between main strategy and top basic ones.

        :param body: Required.
        :type body: ~socgenapi.models.RatesAndClosestStrategiesAndRegressionRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: RatesAndClosestStrategiesAndRegressionResponse. The
         RatesAndClosestStrategiesAndRegressionResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.RatesAndClosestStrategiesAndRegressionResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def compute_historical_rates_and_regression_indicators(  # pylint: disable=name-too-long
        self, body: JSON, *, content_type: str, **kwargs: Any
    ) -> _models.RatesAndClosestStrategiesAndRegressionResponse:
        """Compute historical rates and regression indicators between main strategy and top basic ones.

        Compute historical rates and regression indicators between main strategy and top basic ones.

        :param body: Required.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: RatesAndClosestStrategiesAndRegressionResponse. The
         RatesAndClosestStrategiesAndRegressionResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.RatesAndClosestStrategiesAndRegressionResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def compute_historical_rates_and_regression_indicators(  # pylint: disable=name-too-long
        self, body: IO[bytes], *, content_type: str, **kwargs: Any
    ) -> _models.RatesAndClosestStrategiesAndRegressionResponse:
        """Compute historical rates and regression indicators between main strategy and top basic ones.

        Compute historical rates and regression indicators between main strategy and top basic ones.

        :param body: Required.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Required.
        :paramtype content_type: str
        :return: RatesAndClosestStrategiesAndRegressionResponse. The
         RatesAndClosestStrategiesAndRegressionResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.RatesAndClosestStrategiesAndRegressionResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def compute_historical_rates_and_regression_indicators(  # pylint: disable=name-too-long
        self, body: Union[_models.RatesAndClosestStrategiesAndRegressionRequest, JSON, IO[bytes]], **kwargs: Any
    ) -> _models.RatesAndClosestStrategiesAndRegressionResponse:
        """Compute historical rates and regression indicators between main strategy and top basic ones.

        Compute historical rates and regression indicators between main strategy and top basic ones.

        :param body: Is one of the following types: RatesAndClosestStrategiesAndRegressionRequest,
         JSON, IO[bytes] Required.
        :type body: ~socgenapi.models.RatesAndClosestStrategiesAndRegressionRequest or JSON or
         IO[bytes]
        :return: RatesAndClosestStrategiesAndRegressionResponse. The
         RatesAndClosestStrategiesAndRegressionResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.RatesAndClosestStrategiesAndRegressionResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
        cls: ClsType[_models.RatesAndClosestStrategiesAndRegressionResponse] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_curve_follower_service_compute_historical_rates_and_regression_indicators_request(
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.RatesAndClosestStrategiesAndRegressionResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore


class fxEventTrackerServiceOperations:
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~socgenapi.SocGenAPIClient`'s
        :attr:`fx_event_tracker_service` attribute.
    """

    def __init__(self, *args, **kwargs) -> None:
        input_args = list(args)
        self._client: PipelineClient = input_args.pop(0) if input_args else kwargs.pop("client")
        self._config: SocGenAPIClientConfiguration = input_args.pop(0) if input_args else kwargs.pop("config")
        self._serialize: Serializer = input_args.pop(0) if input_args else kwargs.pop("serializer")
        self._deserialize: Deserializer = input_args.pop(0) if input_args else kwargs.pop("deserializer")

    def get_currency_pairs(self, **kwargs: Any) -> list[str]:
        """Retrieve the list of currency pairs available for computing in the service.

        get_currency_pairs.

        :return: list of str
        :rtype: list[str]
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[list[str]] = kwargs.pop("cls", None)

        _request = build_fx_event_tracker_service_get_currency_pairs_request(
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(list[str], response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_volatility_overnight(
        self,
        *,
        currency_pair: Optional[str] = None,
        volatility_overnight_date: Optional[datetime.datetime] = None,
        start_date: Optional[datetime.datetime] = None,
        end_date: Optional[datetime.datetime] = None,
        **kwargs: Any,
    ) -> list[_models.DailyVolAtDate]:
        """Compute the historical volatility overnight.

        get_volatility_overnight.

        :keyword currency_pair: The currency pair. Default value is None.
        :paramtype currency_pair: str
        :keyword volatility_overnight_date: The volatility overnight date or event date (format:
         'YYYY-MM-DD). Default value is None.
        :paramtype volatility_overnight_date: ~datetime.datetime
        :keyword start_date: The historical start date (format: 'YYYY-MM-DD). Default value is None.
        :paramtype start_date: ~datetime.datetime
        :keyword end_date: The historical end date (format: 'YYYY-MM-DD). Default value is None.
        :paramtype end_date: ~datetime.datetime
        :return: list of DailyVolAtDate
        :rtype: list[~socgenapi.models.DailyVolAtDate]
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[list[_models.DailyVolAtDate]] = kwargs.pop("cls", None)

        _request = build_fx_event_tracker_service_get_volatility_overnight_request(
            currency_pair=currency_pair,
            volatility_overnight_date=volatility_overnight_date,
            start_date=start_date,
            end_date=end_date,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(list[_models.DailyVolAtDate], response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_volatility_overnight_range(
        self,
        *,
        currency_pair: Optional[str] = None,
        volatility_overnight_start_date: Optional[datetime.datetime] = None,
        volatility_overnight_end_date: Optional[datetime.datetime] = None,
        start_date: Optional[datetime.datetime] = None,
        end_date: Optional[datetime.datetime] = None,
        **kwargs: Any,
    ) -> _models.VolatilityOvernightRange:
        """Compute a range of historical volatility overnight.

        get_volatility_overnight_range.

        :keyword currency_pair: The currency pair. Default value is None.
        :paramtype currency_pair: str
        :keyword volatility_overnight_start_date: The volatility overnight start date or event date
         (format: 'YYYY-MM-DD). Default value is None.
        :paramtype volatility_overnight_start_date: ~datetime.datetime
        :keyword volatility_overnight_end_date: The volatility overnight end date or event date
         (format: 'YYYY-MM-DD). Default value is None.
        :paramtype volatility_overnight_end_date: ~datetime.datetime
        :keyword start_date: The historical start date (format: 'YYYY-MM-DD). Default value is None.
        :paramtype start_date: ~datetime.datetime
        :keyword end_date: The historical end date (format: 'YYYY-MM-DD). Default value is None.
        :paramtype end_date: ~datetime.datetime
        :return: VolatilityOvernightRange. The VolatilityOvernightRange is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.VolatilityOvernightRange
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.VolatilityOvernightRange] = kwargs.pop("cls", None)

        _request = build_fx_event_tracker_service_get_volatility_overnight_range_request(
            currency_pair=currency_pair,
            volatility_overnight_start_date=volatility_overnight_start_date,
            volatility_overnight_end_date=volatility_overnight_end_date,
            start_date=start_date,
            end_date=end_date,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.VolatilityOvernightRange, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    @overload
    def compute_event_premiums(
        self, body: list[_models.CurveParameter], *, content_type: str, **kwargs: Any
    ) -> list[_models.CurveVolResponse]:
        """Compute event premium which is the difference between the overnight volatility of the event
        date and the one of a ref date.

        compute_event_premiums.

        :param body: Required.
        :type body: list[~socgenapi.models.CurveParameter]
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: list of CurveVolResponse
        :rtype: list[~socgenapi.models.CurveVolResponse]
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def compute_event_premiums(
        self, body: list[JSON], *, content_type: str, **kwargs: Any
    ) -> list[_models.CurveVolResponse]:
        """Compute event premium which is the difference between the overnight volatility of the event
        date and the one of a ref date.

        compute_event_premiums.

        :param body: Required.
        :type body: list[JSON]
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: list of CurveVolResponse
        :rtype: list[~socgenapi.models.CurveVolResponse]
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def compute_event_premiums(
        self, body: IO[bytes], *, content_type: str, **kwargs: Any
    ) -> list[_models.CurveVolResponse]:
        """Compute event premium which is the difference between the overnight volatility of the event
        date and the one of a ref date.

        compute_event_premiums.

        :param body: Required.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Required.
        :paramtype content_type: str
        :return: list of CurveVolResponse
        :rtype: list[~socgenapi.models.CurveVolResponse]
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def compute_event_premiums(
        self, body: Union[list[_models.CurveParameter], list[JSON], IO[bytes]], **kwargs: Any
    ) -> list[_models.CurveVolResponse]:
        """Compute event premium which is the difference between the overnight volatility of the event
        date and the one of a ref date.

        compute_event_premiums.

        :param body: Is one of the following types: [CurveParameter], [JSON], IO[bytes] Required.
        :type body: list[~socgenapi.models.CurveParameter] or list[JSON] or IO[bytes]
        :return: list of CurveVolResponse
        :rtype: list[~socgenapi.models.CurveVolResponse]
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
        cls: ClsType[list[_models.CurveVolResponse]] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_fx_event_tracker_service_compute_event_premiums_request(
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(list[_models.CurveVolResponse], response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_market_events(
        self,
        *,
        currency_pair: str,
        event_title: Optional[str] = None,
        start_date: Optional[datetime.datetime] = None,
        page_size: Optional[int] = None,
        **kwargs: Any,
    ) -> list[_models.MarketEvent]:
        """Retrieve markets event filtered by start and end dates or by eventTitle.

        get_market_events.

        :keyword currency_pair: Required.
        :paramtype currency_pair: str
        :keyword event_title: Default value is None.
        :paramtype event_title: str
        :keyword start_date: Default value is None.
        :paramtype start_date: ~datetime.datetime
        :keyword page_size: Default value is None.
        :paramtype page_size: int
        :return: list of MarketEvent
        :rtype: list[~socgenapi.models.MarketEvent]
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[list[_models.MarketEvent]] = kwargs.pop("cls", None)

        _request = build_fx_event_tracker_service_get_market_events_request(
            currency_pair=currency_pair,
            event_title=event_title,
            start_date=start_date,
            page_size=page_size,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(list[_models.MarketEvent], response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore


class sustainableBondScreenerServiceOperations:
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~socgenapi.SocGenAPIClient`'s
        :attr:`sustainable_bond_screener_service` attribute.
    """

    def __init__(self, *args, **kwargs) -> None:
        input_args = list(args)
        self._client: PipelineClient = input_args.pop(0) if input_args else kwargs.pop("client")
        self._config: SocGenAPIClientConfiguration = input_args.pop(0) if input_args else kwargs.pop("config")
        self._serialize: Serializer = input_args.pop(0) if input_args else kwargs.pop("serializer")
        self._deserialize: Deserializer = input_args.pop(0) if input_args else kwargs.pop("deserializer")

    def get_sustainable_bonds(self, **kwargs: Any) -> _models.GetSustainableBondsResponse:
        """Lists sustainable bonds.

        get_sustainable_bonds.

        :return: GetSustainableBondsResponse. The GetSustainableBondsResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.GetSustainableBondsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.GetSustainableBondsResponse] = kwargs.pop("cls", None)

        _request = build_sustainable_bond_screener_service_get_sustainable_bonds_request(
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.GetSustainableBondsResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    @overload
    def get_historical_data(
        self, body: _models.HistoricalDataRequest, *, content_type: str, **kwargs: Any
    ) -> _models.PostHistoricalDataResponse:
        """Get historical data for several bonds for each day over a given period.

        Historical data.

        :param body: Required.
        :type body: ~socgenapi.models.HistoricalDataRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: PostHistoricalDataResponse. The PostHistoricalDataResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.PostHistoricalDataResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def get_historical_data(
        self, body: JSON, *, content_type: str, **kwargs: Any
    ) -> _models.PostHistoricalDataResponse:
        """Get historical data for several bonds for each day over a given period.

        Historical data.

        :param body: Required.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: PostHistoricalDataResponse. The PostHistoricalDataResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.PostHistoricalDataResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def get_historical_data(
        self, body: IO[bytes], *, content_type: str, **kwargs: Any
    ) -> _models.PostHistoricalDataResponse:
        """Get historical data for several bonds for each day over a given period.

        Historical data.

        :param body: Required.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Required.
        :paramtype content_type: str
        :return: PostHistoricalDataResponse. The PostHistoricalDataResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.PostHistoricalDataResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def get_historical_data(
        self, body: Union[_models.HistoricalDataRequest, JSON, IO[bytes]], **kwargs: Any
    ) -> _models.PostHistoricalDataResponse:
        """Get historical data for several bonds for each day over a given period.

        Historical data.

        :param body: Is one of the following types: HistoricalDataRequest, JSON, IO[bytes] Required.
        :type body: ~socgenapi.models.HistoricalDataRequest or JSON or IO[bytes]
        :return: PostHistoricalDataResponse. The PostHistoricalDataResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.PostHistoricalDataResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
        cls: ClsType[_models.PostHistoricalDataResponse] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_sustainable_bond_screener_service_get_historical_data_request(
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.PostHistoricalDataResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore


class marketDataServiceOperations:
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~socgenapi.SocGenAPIClient`'s
        :attr:`market_data_service` attribute.
    """

    def __init__(self, *args, **kwargs) -> None:
        input_args = list(args)
        self._client: PipelineClient = input_args.pop(0) if input_args else kwargs.pop("client")
        self._config: SocGenAPIClientConfiguration = input_args.pop(0) if input_args else kwargs.pop("config")
        self._serialize: Serializer = input_args.pop(0) if input_args else kwargs.pop("serializer")
        self._deserialize: Deserializer = input_args.pop(0) if input_args else kwargs.pop("deserializer")

    def data_catalog_describe_all_sources(self, **kwargs: Any) -> _models.ListSourceResponse:
        """Describe all sources handled by this API.

        More details about 'sources' endpoint.

        :return: ListSourceResponse. The ListSourceResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.ListSourceResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.ListSourceResponse] = kwargs.pop("cls", None)

        _request = build_market_data_service_data_catalog_describe_all_sources_request(
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.ListSourceResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, {})  # type: ignore

        return deserialized  # type: ignore

    def data_catalog_describe_products_by_source(self, source_name: str, **kwargs: Any) -> _models.SourceDescription:
        """Describe all products of a given source handled by this API.

        More details about 'sources/{sourceName}/products' endpoint.

        :param source_name: Required.
        :type source_name: str
        :return: SourceDescription. The SourceDescription is compatible with MutableMapping
        :rtype: ~socgenapi.models.SourceDescription
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.SourceDescription] = kwargs.pop("cls", None)

        _request = build_market_data_service_data_catalog_describe_products_by_source_request(
            source_name=source_name,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.SourceDescription, response.json())

        if cls:
            return cls(pipeline_response, deserialized, {})  # type: ignore

        return deserialized  # type: ignore

    def data_catalog_describe_single_product_by_source(  # pylint: disable=name-too-long
        self, source_name: str, product_name: str, **kwargs: Any
    ) -> _models.ProductDescription:
        """Describe a given product of a given source handled by this API.

        More details about 'sources/{sourceName}/products/{productName}' endpoint.

        :param source_name: Required.
        :type source_name: str
        :param product_name: Required.
        :type product_name: str
        :return: ProductDescription. The ProductDescription is compatible with MutableMapping
        :rtype: ~socgenapi.models.ProductDescription
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[_models.ProductDescription] = kwargs.pop("cls", None)

        _request = build_market_data_service_data_catalog_describe_single_product_by_source_request(
            source_name=source_name,
            product_name=product_name,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.ProductDescription, response.json())

        if cls:
            return cls(pipeline_response, deserialized, {})  # type: ignore

        return deserialized  # type: ignore

    @overload
    def explorer_search_instruments_by_constraints(  # pylint: disable=name-too-long
        self,
        source_name: str,
        body: _models.SearchInstrumentsRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> _models.SearchInstrumentsResponse:
        """Search for instruments.

        You can learn more about the ``filter`` syntax `here </data/instruments-filter-syntax.md>`_.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.SearchInstrumentsRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: SearchInstrumentsResponse. The SearchInstrumentsResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.SearchInstrumentsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def explorer_search_instruments_by_constraints(  # pylint: disable=name-too-long
        self, source_name: str, body: JSON, *, content_type: str = "application/json", **kwargs: Any
    ) -> _models.SearchInstrumentsResponse:
        """Search for instruments.

        You can learn more about the ``filter`` syntax `here </data/instruments-filter-syntax.md>`_.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: SearchInstrumentsResponse. The SearchInstrumentsResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.SearchInstrumentsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def explorer_search_instruments_by_constraints(  # pylint: disable=name-too-long
        self, source_name: str, body: IO[bytes], *, content_type: str = "application/json", **kwargs: Any
    ) -> _models.SearchInstrumentsResponse:
        """Search for instruments.

        You can learn more about the ``filter`` syntax `here </data/instruments-filter-syntax.md>`_.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: SearchInstrumentsResponse. The SearchInstrumentsResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.SearchInstrumentsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def explorer_search_instruments_by_constraints(  # pylint: disable=name-too-long
        self, source_name: str, body: Union[_models.SearchInstrumentsRequest, JSON, IO[bytes]], **kwargs: Any
    ) -> _models.SearchInstrumentsResponse:
        """Search for instruments.

        You can learn more about the ``filter`` syntax `here </data/instruments-filter-syntax.md>`_.

        :param source_name: Required.
        :type source_name: str
        :param body: Is one of the following types: SearchInstrumentsRequest, JSON, IO[bytes] Required.
        :type body: ~socgenapi.models.SearchInstrumentsRequest or JSON or IO[bytes]
        :return: SearchInstrumentsResponse. The SearchInstrumentsResponse is compatible with
         MutableMapping
        :rtype: ~socgenapi.models.SearchInstrumentsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
        cls: ClsType[_models.SearchInstrumentsResponse] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_market_data_service_explorer_search_instruments_by_constraints_request(
            source_name=source_name,
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.SearchInstrumentsResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, {})  # type: ignore

        return deserialized  # type: ignore

    @overload
    def explorer_lookup_instruments_fields_values(  # pylint: disable=name-too-long
        self,
        source_name: str,
        field_name: str,
        body: _models.LookupInstrumentsFieldsValuesRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> _models.LookupInstrumentsFieldsValuesResponse:
        """Lookup for possible values of a field according to an optional set of constraints.

        You can learn more about the ``filter`` syntax `here </data/instruments-filter-syntax.md>`_.

        :param source_name: Required.
        :type source_name: str
        :param field_name: Required.
        :type field_name: str
        :param body: Required.
        :type body: ~socgenapi.models.LookupInstrumentsFieldsValuesRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: LookupInstrumentsFieldsValuesResponse. The LookupInstrumentsFieldsValuesResponse is
         compatible with MutableMapping
        :rtype: ~socgenapi.models.LookupInstrumentsFieldsValuesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def explorer_lookup_instruments_fields_values(  # pylint: disable=name-too-long
        self, source_name: str, field_name: str, body: JSON, *, content_type: str = "application/json", **kwargs: Any
    ) -> _models.LookupInstrumentsFieldsValuesResponse:
        """Lookup for possible values of a field according to an optional set of constraints.

        You can learn more about the ``filter`` syntax `here </data/instruments-filter-syntax.md>`_.

        :param source_name: Required.
        :type source_name: str
        :param field_name: Required.
        :type field_name: str
        :param body: Required.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: LookupInstrumentsFieldsValuesResponse. The LookupInstrumentsFieldsValuesResponse is
         compatible with MutableMapping
        :rtype: ~socgenapi.models.LookupInstrumentsFieldsValuesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def explorer_lookup_instruments_fields_values(  # pylint: disable=name-too-long
        self,
        source_name: str,
        field_name: str,
        body: IO[bytes],
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> _models.LookupInstrumentsFieldsValuesResponse:
        """Lookup for possible values of a field according to an optional set of constraints.

        You can learn more about the ``filter`` syntax `here </data/instruments-filter-syntax.md>`_.

        :param source_name: Required.
        :type source_name: str
        :param field_name: Required.
        :type field_name: str
        :param body: Required.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: LookupInstrumentsFieldsValuesResponse. The LookupInstrumentsFieldsValuesResponse is
         compatible with MutableMapping
        :rtype: ~socgenapi.models.LookupInstrumentsFieldsValuesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def explorer_lookup_instruments_fields_values(  # pylint: disable=name-too-long
        self,
        source_name: str,
        field_name: str,
        body: Union[_models.LookupInstrumentsFieldsValuesRequest, JSON, IO[bytes]],
        **kwargs: Any,
    ) -> _models.LookupInstrumentsFieldsValuesResponse:
        """Lookup for possible values of a field according to an optional set of constraints.

        You can learn more about the ``filter`` syntax `here </data/instruments-filter-syntax.md>`_.

        :param source_name: Required.
        :type source_name: str
        :param field_name: Required.
        :type field_name: str
        :param body: Is one of the following types: LookupInstrumentsFieldsValuesRequest, JSON,
         IO[bytes] Required.
        :type body: ~socgenapi.models.LookupInstrumentsFieldsValuesRequest or JSON or IO[bytes]
        :return: LookupInstrumentsFieldsValuesResponse. The LookupInstrumentsFieldsValuesResponse is
         compatible with MutableMapping
        :rtype: ~socgenapi.models.LookupInstrumentsFieldsValuesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
        cls: ClsType[_models.LookupInstrumentsFieldsValuesResponse] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_market_data_service_explorer_lookup_instruments_fields_values_request(
            source_name=source_name,
            field_name=field_name,
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.LookupInstrumentsFieldsValuesResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, {})  # type: ignore

        return deserialized  # type: ignore

    @overload
    def quotes_query_quotes(
        self,
        source_name: str,
        body: _models.LastQuotesRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]:
        """Query fields values on some instruments for a given source.

        quotes_query_quotes.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.LastQuotesRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: str or QuotesResponse or QuotesByConstraintsResponse
        :rtype: str or ~socgenapi.models.QuotesResponse or
         ~socgenapi.models.QuotesByConstraintsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def quotes_query_quotes(
        self,
        source_name: str,
        body: _models.SnapshotQuotesRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]:
        """Query fields values on some instruments for a given source.

        quotes_query_quotes.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.SnapshotQuotesRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: str or QuotesResponse or QuotesByConstraintsResponse
        :rtype: str or ~socgenapi.models.QuotesResponse or
         ~socgenapi.models.QuotesByConstraintsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def quotes_query_quotes(
        self,
        source_name: str,
        body: _models.RangeQuotesRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]:
        """Query fields values on some instruments for a given source.

        quotes_query_quotes.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.RangeQuotesRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: str or QuotesResponse or QuotesByConstraintsResponse
        :rtype: str or ~socgenapi.models.QuotesResponse or
         ~socgenapi.models.QuotesByConstraintsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def quotes_query_quotes(
        self,
        source_name: str,
        body: Union[_models.LastQuotesRequest, _models.SnapshotQuotesRequest, _models.RangeQuotesRequest],
        **kwargs: Any,
    ) -> Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]:
        """Query fields values on some instruments for a given source.

        quotes_query_quotes.

        :param source_name: Required.
        :type source_name: str
        :param body: Is one of the following types: LastQuotesRequest, SnapshotQuotesRequest,
         RangeQuotesRequest Required.
        :type body: ~socgenapi.models.LastQuotesRequest or ~socgenapi.models.SnapshotQuotesRequest or
         ~socgenapi.models.RangeQuotesRequest
        :return: str or QuotesResponse or QuotesByConstraintsResponse
        :rtype: str or ~socgenapi.models.QuotesResponse or
         ~socgenapi.models.QuotesByConstraintsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
        cls: ClsType[Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, _models.LastQuotesRequest):
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore
        elif isinstance(body, _models.SnapshotQuotesRequest):
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore
        elif isinstance(body, _models.RangeQuotesRequest):
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_market_data_service_quotes_query_quotes_request(
            source_name=source_name,
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            if response.headers["content-type"] == "text/csv":
                deserialized = _deserialize(str, response.text())
            else:
                deserialized = _deserialize(
                    Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse], response.json()
                )

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    @overload
    def quotes_query_quote_updates(
        self,
        source_name: str,
        body: _models.QuotesUpdateRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> _models.QuoteUpdatesResponse:
        """Query fields values update on some instruments for a given source.

        Limited to last month.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.QuotesUpdateRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: QuoteUpdatesResponse. The QuoteUpdatesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.QuoteUpdatesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def quotes_query_quote_updates(
        self, source_name: str, body: JSON, *, content_type: str = "application/json", **kwargs: Any
    ) -> _models.QuoteUpdatesResponse:
        """Query fields values update on some instruments for a given source.

        Limited to last month.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: QuoteUpdatesResponse. The QuoteUpdatesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.QuoteUpdatesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def quotes_query_quote_updates(
        self, source_name: str, body: IO[bytes], *, content_type: str = "application/json", **kwargs: Any
    ) -> _models.QuoteUpdatesResponse:
        """Query fields values update on some instruments for a given source.

        Limited to last month.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: QuoteUpdatesResponse. The QuoteUpdatesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.QuoteUpdatesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def quotes_query_quote_updates(
        self, source_name: str, body: Union[_models.QuotesUpdateRequest, JSON, IO[bytes]], **kwargs: Any
    ) -> _models.QuoteUpdatesResponse:
        """Query fields values update on some instruments for a given source.

        Limited to last month.

        :param source_name: Required.
        :type source_name: str
        :param body: Is one of the following types: QuotesUpdateRequest, JSON, IO[bytes] Required.
        :type body: ~socgenapi.models.QuotesUpdateRequest or JSON or IO[bytes]
        :return: QuoteUpdatesResponse. The QuoteUpdatesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.QuoteUpdatesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
        cls: ClsType[_models.QuoteUpdatesResponse] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_market_data_service_quotes_query_quote_updates_request(
            source_name=source_name,
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.QuoteUpdatesResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, {})  # type: ignore

        return deserialized  # type: ignore

    @overload
    def quotes_query_live_quotes(
        self,
        source_name: str,
        body: _models.LiveQuotesRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> _models.LiveQuotesResponse:
        """Get live quotes for instruments.

        quotes_query_live_quotes.

        :param source_name: Only 'SG' are supported for now. Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.LiveQuotesRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: LiveQuotesResponse. The LiveQuotesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.LiveQuotesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def quotes_query_live_quotes(
        self, source_name: str, body: JSON, *, content_type: str = "application/json", **kwargs: Any
    ) -> _models.LiveQuotesResponse:
        """Get live quotes for instruments.

        quotes_query_live_quotes.

        :param source_name: Only 'SG' are supported for now. Required.
        :type source_name: str
        :param body: Required.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: LiveQuotesResponse. The LiveQuotesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.LiveQuotesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def quotes_query_live_quotes(
        self, source_name: str, body: IO[bytes], *, content_type: str = "application/json", **kwargs: Any
    ) -> _models.LiveQuotesResponse:
        """Get live quotes for instruments.

        quotes_query_live_quotes.

        :param source_name: Only 'SG' are supported for now. Required.
        :type source_name: str
        :param body: Required.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: LiveQuotesResponse. The LiveQuotesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.LiveQuotesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def quotes_query_live_quotes(
        self, source_name: str, body: Union[_models.LiveQuotesRequest, JSON, IO[bytes]], **kwargs: Any
    ) -> _models.LiveQuotesResponse:
        """Get live quotes for instruments.

        quotes_query_live_quotes.

        :param source_name: Only 'SG' are supported for now. Required.
        :type source_name: str
        :param body: Is one of the following types: LiveQuotesRequest, JSON, IO[bytes] Required.
        :type body: ~socgenapi.models.LiveQuotesRequest or JSON or IO[bytes]
        :return: LiveQuotesResponse. The LiveQuotesResponse is compatible with MutableMapping
        :rtype: ~socgenapi.models.LiveQuotesResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
        cls: ClsType[_models.LiveQuotesResponse] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_market_data_service_quotes_query_live_quotes_request(
            source_name=source_name,
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(_models.LiveQuotesResponse, response.json())

        if cls:
            return cls(pipeline_response, deserialized, {})  # type: ignore

        return deserialized  # type: ignore

    @overload
    def quotes_query_quotes_by_constraints(
        self,
        source_name: str,
        body: _models.LastQuotesByConstraintsRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]:
        """Combine a request to search for instruments and retrieve quotes on them.

        quotes_query_quotes_by_constraints.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.LastQuotesByConstraintsRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: str or QuotesResponse or QuotesByConstraintsResponse
        :rtype: str or ~socgenapi.models.QuotesResponse or
         ~socgenapi.models.QuotesByConstraintsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def quotes_query_quotes_by_constraints(
        self,
        source_name: str,
        body: _models.SnapshotQuotesByConstraintsRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]:
        """Combine a request to search for instruments and retrieve quotes on them.

        quotes_query_quotes_by_constraints.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.SnapshotQuotesByConstraintsRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: str or QuotesResponse or QuotesByConstraintsResponse
        :rtype: str or ~socgenapi.models.QuotesResponse or
         ~socgenapi.models.QuotesByConstraintsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def quotes_query_quotes_by_constraints(
        self,
        source_name: str,
        body: _models.RangeQuotesByConstraintsRequest,
        *,
        content_type: str = "application/json",
        **kwargs: Any,
    ) -> Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]:
        """Combine a request to search for instruments and retrieve quotes on them.

        quotes_query_quotes_by_constraints.

        :param source_name: Required.
        :type source_name: str
        :param body: Required.
        :type body: ~socgenapi.models.RangeQuotesByConstraintsRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: str or QuotesResponse or QuotesByConstraintsResponse
        :rtype: str or ~socgenapi.models.QuotesResponse or
         ~socgenapi.models.QuotesByConstraintsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def quotes_query_quotes_by_constraints(
        self,
        source_name: str,
        body: Union[
            _models.LastQuotesByConstraintsRequest,
            _models.SnapshotQuotesByConstraintsRequest,
            _models.RangeQuotesByConstraintsRequest,
        ],
        **kwargs: Any,
    ) -> Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]:
        """Combine a request to search for instruments and retrieve quotes on them.

        quotes_query_quotes_by_constraints.

        :param source_name: Required.
        :type source_name: str
        :param body: Is one of the following types: LastQuotesByConstraintsRequest,
         SnapshotQuotesByConstraintsRequest, RangeQuotesByConstraintsRequest Required.
        :type body: ~socgenapi.models.LastQuotesByConstraintsRequest or
         ~socgenapi.models.SnapshotQuotesByConstraintsRequest or
         ~socgenapi.models.RangeQuotesByConstraintsRequest
        :return: str or QuotesResponse or QuotesByConstraintsResponse
        :rtype: str or ~socgenapi.models.QuotesResponse or
         ~socgenapi.models.QuotesByConstraintsResponse
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("Content-Type", None))
        cls: ClsType[Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse]] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, _models.LastQuotesByConstraintsRequest):
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore
        elif isinstance(body, _models.SnapshotQuotesByConstraintsRequest):
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore
        elif isinstance(body, _models.RangeQuotesByConstraintsRequest):
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_market_data_service_quotes_query_quotes_by_constraints_request(
            source_name=source_name,
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            if response.headers["content-type"] == "text/csv":
                deserialized = _deserialize(str, response.text())
            else:
                deserialized = _deserialize(
                    Union[str, _models.QuotesResponse, _models.QuotesByConstraintsResponse], response.json()
                )

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore


class cofBoxServiceOperations:
    """
    .. warning::
        **DO NOT** instantiate this class directly.

        Instead, you should access the following operations through
        :class:`~socgenapi.SocGenAPIClient`'s
        :attr:`cof_box_service` attribute.
    """

    def __init__(self, *args, **kwargs) -> None:
        input_args = list(args)
        self._client: PipelineClient = input_args.pop(0) if input_args else kwargs.pop("client")
        self._config: SocGenAPIClientConfiguration = input_args.pop(0) if input_args else kwargs.pop("config")
        self._serialize: Serializer = input_args.pop(0) if input_args else kwargs.pop("serializer")
        self._deserialize: Deserializer = input_args.pop(0) if input_args else kwargs.pop("deserializer")

    def get_analysis_types(self, **kwargs: Any) -> Any:
        """List possible analyses types. See 'analysis' for detail.

        List possible analyses types. See 'analysis' for detail.

        :return: any
        :rtype: any
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[Any] = kwargs.pop("cls", None)

        _request = build_cof_box_service_get_analysis_types_request(
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(Any, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    @overload
    def post_analysis(self, body: _models.AnalysisRequest, *, content_type: str, **kwargs: Any) -> Any:
        """Runs a list of analysis.

        Runs a list of analysis.

        :param body: For you to get the most in 1 call, various analyses can be carried out with
         various instruments, tax scenarios and computing dates.<br />
         analysisTypes: <i>Analysis results requested (all analysis returned if none specified). 3
         analysis are available:</i><br /><b>- Cof</b>: <i>Cost Of Financing spread rate(aka Spot Cost
         Of Financing at the time of computing).</i><br /><b>- FwdCof</b>: <i>Forward Cost Of Financing
         spread rates between different maturities.</i><br /><b>- RollDownCof</b>: <i>Rolldown of Cost
         Of Financing spread rates between different maturities.</i>.<br />
         instruments: <i>The instruments to analyse.</i><br />
         startDate: <i>The start date.</i><br />
         endDate: <i>The end date.</i><br />
         cofTypes: <i>The Cof types ('CofDiv100pct' by default or/and 'CofDivMarket',
         'CofDivNtr').</i><br />
         minUpdateTimestampUtc:  <i> Minimum Update timestamp expresses in UTC - Format :
         yyyy-MM-ddTHH:mm:ssZ </i>. Required.
        :type body: ~socgenapi.models.AnalysisRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: any
        :rtype: any
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def post_analysis(self, body: JSON, *, content_type: str, **kwargs: Any) -> Any:
        """Runs a list of analysis.

        Runs a list of analysis.

        :param body: For you to get the most in 1 call, various analyses can be carried out with
         various instruments, tax scenarios and computing dates.<br />
         analysisTypes: <i>Analysis results requested (all analysis returned if none specified). 3
         analysis are available:</i><br /><b>- Cof</b>: <i>Cost Of Financing spread rate(aka Spot Cost
         Of Financing at the time of computing).</i><br /><b>- FwdCof</b>: <i>Forward Cost Of Financing
         spread rates between different maturities.</i><br /><b>- RollDownCof</b>: <i>Rolldown of Cost
         Of Financing spread rates between different maturities.</i>.<br />
         instruments: <i>The instruments to analyse.</i><br />
         startDate: <i>The start date.</i><br />
         endDate: <i>The end date.</i><br />
         cofTypes: <i>The Cof types ('CofDiv100pct' by default or/and 'CofDivMarket',
         'CofDivNtr').</i><br />
         minUpdateTimestampUtc:  <i> Minimum Update timestamp expresses in UTC - Format :
         yyyy-MM-ddTHH:mm:ssZ </i>. Required.
        :type body: JSON
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Required.
        :paramtype content_type: str
        :return: any
        :rtype: any
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    @overload
    def post_analysis(self, body: IO[bytes], *, content_type: str, **kwargs: Any) -> Any:
        """Runs a list of analysis.

        Runs a list of analysis.

        :param body: For you to get the most in 1 call, various analyses can be carried out with
         various instruments, tax scenarios and computing dates.<br />
         analysisTypes: <i>Analysis results requested (all analysis returned if none specified). 3
         analysis are available:</i><br /><b>- Cof</b>: <i>Cost Of Financing spread rate(aka Spot Cost
         Of Financing at the time of computing).</i><br /><b>- FwdCof</b>: <i>Forward Cost Of Financing
         spread rates between different maturities.</i><br /><b>- RollDownCof</b>: <i>Rolldown of Cost
         Of Financing spread rates between different maturities.</i>.<br />
         instruments: <i>The instruments to analyse.</i><br />
         startDate: <i>The start date.</i><br />
         endDate: <i>The end date.</i><br />
         cofTypes: <i>The Cof types ('CofDiv100pct' by default or/and 'CofDivMarket',
         'CofDivNtr').</i><br />
         minUpdateTimestampUtc:  <i> Minimum Update timestamp expresses in UTC - Format :
         yyyy-MM-ddTHH:mm:ssZ </i>. Required.
        :type body: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Required.
        :paramtype content_type: str
        :return: any
        :rtype: any
        :raises ~corehttp.exceptions.HttpResponseError:
        """

    def post_analysis(self, body: Union[_models.AnalysisRequest, JSON, IO[bytes]], **kwargs: Any) -> Any:
        """Runs a list of analysis.

        Runs a list of analysis.

        :param body: For you to get the most in 1 call, various analyses can be carried out with
         various instruments, tax scenarios and computing dates.<br />
         analysisTypes: <i>Analysis results requested (all analysis returned if none specified). 3
         analysis are available:</i><br /><b>- Cof</b>: <i>Cost Of Financing spread rate(aka Spot Cost
         Of Financing at the time of computing).</i><br /><b>- FwdCof</b>: <i>Forward Cost Of Financing
         spread rates between different maturities.</i><br /><b>- RollDownCof</b>: <i>Rolldown of Cost
         Of Financing spread rates between different maturities.</i>.<br />
         instruments: <i>The instruments to analyse.</i><br />
         startDate: <i>The start date.</i><br />
         endDate: <i>The end date.</i><br />
         cofTypes: <i>The Cof types ('CofDiv100pct' by default or/and 'CofDivMarket',
         'CofDivNtr').</i><br />
         minUpdateTimestampUtc:  <i> Minimum Update timestamp expresses in UTC - Format :
         yyyy-MM-ddTHH:mm:ssZ </i>. Is one of the following types: AnalysisRequest, JSON, IO[bytes]
         Required.
        :type body: ~socgenapi.models.AnalysisRequest or JSON or IO[bytes]
        :return: any
        :rtype: any
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = case_insensitive_dict(kwargs.pop("headers", {}) or {})
        _params = kwargs.pop("params", {}) or {}

        content_type: Optional[str] = kwargs.pop("content_type", _headers.pop("content-type", None))
        cls: ClsType[Any] = kwargs.pop("cls", None)

        content_type = content_type or "application/json"
        _content = None
        if isinstance(body, (IOBase, bytes)):
            _content = body
        else:
            _content = json.dumps(body, cls=SdkJSONEncoder, exclude_readonly=True)  # type: ignore

        _request = build_cof_box_service_post_analysis_request(
            content_type=content_type,
            content=_content,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 409:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceExistsError(response=response, model=error)
            if response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 415:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(Any, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_instruments(self, *, instrument_codes: Optional[list[str]] = None, **kwargs: Any) -> Any:
        """List the instruments available with their properties: currency, reference rate, underlying.

        List the instruments available with their properties: currency, reference rate, underlying.

        :keyword instrument_codes: Filter by instruments codes (all returned if not specified). Default
         value is None.
        :paramtype instrument_codes: list[str]
        :return: any
        :rtype: any
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[Any] = kwargs.pop("cls", None)

        _request = build_cof_box_service_get_instruments_request(
            instrument_codes=instrument_codes,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(Any, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_instruments_details(
        self,
        *,
        instrument_codes: Optional[list[str]] = None,
        as_of_date: Optional[datetime.datetime] = None,
        **kwargs: Any,
    ) -> Any:
        """List the maturities available for some instruments at a specific time (today by default),
        giving detail on the type of maturity (1 year rolling, next listed maturity, etc.).

        List the maturities available for some instruments at a specific time (today by default),
        giving detail on the type of maturity (1 year rolling, next listed maturity, etc.).

        :keyword instrument_codes: List of instruments codes. Default value is None.
        :paramtype instrument_codes: list[str]
        :keyword as_of_date: Specify a date for the maturities (max date for each instrument used if
         not specified). Default value is None.
        :paramtype as_of_date: ~datetime.datetime
        :return: any
        :rtype: any
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[Any] = kwargs.pop("cls", None)

        _request = build_cof_box_service_get_instruments_details_request(
            instrument_codes=instrument_codes,
            as_of_date=as_of_date,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(Any, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore

    def get_instruments_search(
        self,
        *,
        underlying_code: Optional[str] = None,
        currency: Optional[str] = None,
        reference_rate: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Search of instruments.

        Search of instruments.

        :keyword underlying_code: Specify an underlying code (optional). Default value is None.
        :paramtype underlying_code: str
        :keyword currency: Specify an instrument currency (optional). Default value is None.
        :paramtype currency: str
        :keyword reference_rate: Specify a reference rate (optional). Default value is None.
        :paramtype reference_rate: str
        :return: any
        :rtype: any
        :raises ~corehttp.exceptions.HttpResponseError:
        """
        error_map: MutableMapping = {
            409: ResourceExistsError,
            304: ResourceNotModifiedError,
        }
        error_map.update(kwargs.pop("error_map", {}) or {})

        _headers = kwargs.pop("headers", {}) or {}
        _params = kwargs.pop("params", {}) or {}

        cls: ClsType[Any] = kwargs.pop("cls", None)

        _request = build_cof_box_service_get_instruments_search_request(
            underlying_code=underlying_code,
            currency=currency,
            reference_rate=reference_rate,
            headers=_headers,
            params=_params,
        )
        path_format_arguments = {
            "endpoint": self._serialize.url("self._config.endpoint", self._config.endpoint, "str", skip_quote=True),
        }
        _request.url = self._client.format_url(_request.url, **path_format_arguments)

        _stream = kwargs.pop("stream", False)
        pipeline_response: PipelineResponse = self._client.pipeline.run(_request, stream=_stream, **kwargs)

        response = pipeline_response.http_response

        if response.content_type == "text/html" and "Microsoft-Azure-Application-Gateway" in response.headers.get(
            "Server", ""
        ):
            raise HttpResponseError(
                response=response,
                message=f"Azure WAF Error - unsupported content type {response.content_type}. Original message is {response.content}",
            )

        if response.status_code not in [200]:
            if _stream:
                try:
                    response.read()  # Load the body in memory and close the socket
                except (StreamConsumedError, StreamClosedError):
                    pass
            map_error(status_code=response.status_code, response=response, error_map=error_map)
            error = None
            if response.status_code == 400:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 401:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ClientAuthenticationError(response=response, model=error)
            if response.status_code == 403:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 404:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
                raise ResourceNotFoundError(response=response, model=error)
            if response.status_code == 405:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 406:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 408:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 410:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 428:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 429:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 500:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 501:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 502:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 503:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            elif response.status_code == 504:
                error = _failsafe_deserialize(_models.ServiceErrorResponse, response)
            raise HttpResponseError(response=response, model=error)

        response_headers = {}
        response_headers["content-type"] = self._deserialize("str", response.headers.get("content-type"))

        if _stream:
            deserialized = response.iter_bytes()
        else:
            deserialized = _deserialize(Any, response.json())

        if cls:
            return cls(pipeline_response, deserialized, response_headers)  # type: ignore

        return deserialized  # type: ignore
