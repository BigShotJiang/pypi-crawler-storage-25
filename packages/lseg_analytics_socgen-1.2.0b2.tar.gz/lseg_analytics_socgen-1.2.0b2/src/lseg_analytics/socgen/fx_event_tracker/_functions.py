import copy
import datetime
from typing import Any, Iterator, Literal, Optional, Union

from lseg_analytics.core.common._resource_base import ResourceBase
from lseg_analytics.core.exceptions import (
    LibraryException,
    ResourceNotFound,
    check_exception_and_raise,
    check_id,
)

from lseg_analytics.socgen._basic_client.models import (
    CurveParameter,
    CurveVolResponse,
    DailyVolAtDate,
    MarketEvent,
    VolatilityOvernight,
    VolatilityOvernightRange,
)
from lseg_analytics.socgen._client.client import Client

from ._logger import logger

__all__ = [
    "CurveParameter",
    "CurveVolResponse",
    "DailyVolAtDate",
    "MarketEvent",
    "VolatilityOvernight",
    "VolatilityOvernightRange",
    "compute_event_premiums",
    "get_currency_pairs",
    "get_market_events",
    "get_volatility_overnight",
    "get_volatility_overnight_range",
]


def compute_event_premiums(*, body: list[CurveParameter]) -> list[CurveVolResponse]:
    """


    Parameters
    ----------
    body : list[CurveParameter]


    Returns
    --------
    list[CurveVolResponse]


    Examples
    --------
    >>> event_premiums = compute_event_premiums(
    >>>     body=[
    >>>         CurveParameter(
    >>>             currency_pair="EUR/USD",
    >>>             event_date="2026-01-08",
    >>>             ref_date="2026-01-01",
    >>>             start_date="2026-01-01",
    >>>             end_date="2026-01-07",
    >>>         )
    >>>     ]
    >>> )
    >>>
    >>> print(json.dumps([premium.as_dict() for premium in event_premiums], indent=4))
    [
        {
            "curveParameter": {
                "currencyPair": "EUR/USD",
                "eventDate": "2026-01-08T00:00:00Z",
                "refDate": "2026-01-01T00:00:00Z",
                "startDate": "2026-01-01T00:00:00Z",
                "endDate": "2026-01-07T00:00:00Z"
            },
            "eventVolOvernight": [
                {
                    "date": "2026-01-01T00:00:00Z",
                    "value": 5.35623926766439,
                    "straddleBreakeven": 0.00223693620325522
                },
                {
                    "date": "2026-01-02T00:00:00Z",
                    "value": 5.54045676417307,
                    "straddleBreakeven": 0.0023138713001806
                },
                {
                    "date": "2026-01-03T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                },
                {
                    "date": "2026-01-04T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                },
                {
                    "date": "2026-01-05T00:00:00Z",
                    "value": 5.52518956166672,
                    "straddleBreakeven": 0.00230749522990028
                },
                {
                    "date": "2026-01-06T00:00:00Z",
                    "value": 5.18831925737207,
                    "straddleBreakeven": 0.0021668074559191
                },
                {
                    "date": "2026-01-07T00:00:00Z",
                    "value": 5.25,
                    "straddleBreakeven": 0.00219256729959543
                }
            ],
            "refVolOvernight": [
                {
                    "date": "2026-01-01T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                }
            ],
            "eventPremiums": [
                {
                    "date": "2026-01-01T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                },
                {
                    "date": "2026-01-02T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                },
                {
                    "date": "2026-01-03T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                },
                {
                    "date": "2026-01-04T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                },
                {
                    "date": "2026-01-05T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                },
                {
                    "date": "2026-01-06T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                },
                {
                    "date": "2026-01-07T00:00:00Z",
                    "value": null,
                    "straddleBreakeven": null
                }
            ]
        }
    ]

    """

    try:
        logger.info("Calling compute_event_premiums")

        response = Client().fx_event_tracker_service.compute_event_premiums(
            content_type="application/json",
            body=body,
            headers={"x-ap-sdk-operation": "fx_event_tracker.compute_event_premiums"},
        )

        output = response
        logger.info("Called compute_event_premiums")

        return output
    except Exception as err:
        logger.error("Error compute_event_premiums.")
        check_exception_and_raise(err, logger)


def get_currency_pairs() -> list[str]:
    """


    Parameters
    ----------


    Returns
    --------
    list[str]


    Examples
    --------
    >>> currency_pairs = get_currency_pairs()
    >>>
    >>> print(f"Total currency pairs: {len(currency_pairs)}")
    >>> print(json.dumps(currency_pairs[:90], indent=4))
    Total currency pairs: 172
    [
        "AUD/CAD",
        "AUD/CHF",
        "AUD/HKD",
        "AUD/INR",
        "AUD/JPY",
        "AUD/KRW",
        "AUD/MXN",
        "AUD/NOK",
        "AUD/NZD",
        "AUD/SEK",
        "AUD/SGD",
        "AUD/THB",
        "AUD/TWD",
        "AUD/USD",
        "AUD/ZAR",
        "BRL/JPY",
        "BRL/MXN",
        "CAD/BRL",
        "CAD/CHF",
        "CAD/CZK",
        "CAD/HKD",
        "CAD/JPY",
        "CAD/MXN",
        "CAD/NOK",
        "CAD/SEK",
        "CAD/SGD",
        "CHF/BRL",
        "CHF/CZK",
        "CHF/DKK",
        "CHF/HKD",
        "CHF/HUF",
        "CHF/JPY",
        "CHF/KRW",
        "CHF/MXN",
        "CHF/NOK",
        "CHF/PLN",
        "CHF/RON",
        "CHF/RUB",
        "CHF/SEK",
        "CHF/SGD",
        "CHF/THB",
        "CHF/TRY",
        "CHF/ZAR",
        "CNY/JPY",
        "CZK/HUF",
        "CZK/JPY",
        "DKK/JPY",
        "DKK/SEK",
        "DKK/TRY",
        "EUR/AUD",
        "EUR/BRL",
        "EUR/CAD",
        "EUR/CHF",
        "EUR/CLP",
        "EUR/CNY",
        "EUR/COP",
        "EUR/CZK",
        "EUR/DKK",
        "EUR/GBP",
        "EUR/HKD",
        "EUR/HUF",
        "EUR/IDR",
        "EUR/ILS",
        "EUR/INR",
        "EUR/JPY",
        "EUR/KRW",
        "EUR/MAD",
        "EUR/MXN",
        "EUR/NOK",
        "EUR/NZD",
        "EUR/PHP",
        "EUR/PLN",
        "EUR/RON",
        "EUR/RUB",
        "EUR/SAR",
        "EUR/SEK",
        "EUR/SGD",
        "EUR/THB",
        "EUR/TRY",
        "EUR/TWD",
        "EUR/USD",
        "EUR/ZAR",
        "GBP/AUD",
        "GBP/BRL",
        "GBP/CAD",
        "GBP/CHF",
        "GBP/CNY",
        "GBP/CZK",
        "GBP/HKD",
        "GBP/HUF"
    ]

    """

    try:
        logger.info("Calling get_currency_pairs")

        response = Client().fx_event_tracker_service.get_currency_pairs(
            headers={"x-ap-sdk-operation": "fx_event_tracker.get_currency_pairs"}
        )

        output = response
        logger.info("Called get_currency_pairs")

        return output
    except Exception as err:
        logger.error("Error get_currency_pairs.")
        check_exception_and_raise(err, logger)


def get_market_events(
    *,
    currency_pair: str,
    event_title: Optional[str] = None,
    start_date: Optional[datetime.datetime] = None,
    page_size: Optional[int] = None,
) -> list[MarketEvent]:
    """


    Parameters
    ----------
    currency_pair : str
        A sequence of textual characters.
    event_title : str, optional
        A sequence of textual characters.
    start_date : datetime.datetime, optional
        An instant in coordinated universal time (UTC)"
    page_size : int, optional
        A 32-bit integer. (`-2,147,483,648` to `2,147,483,647`)

    Returns
    --------
    list[MarketEvent]


    Examples
    --------
    >>> market_events = get_market_events(
    >>>     currency_pair="EUR/USD",
    >>>     start_date=datetime(2024, 1, 1),
    >>>     event_title="Test",
    >>>     page_size=100,
    >>> )
    >>>
    >>> print(json.dumps([event.as_dict() for event in market_events], indent=4))
    [
        {
            "eventDate": "2024-03-07T00:00:00Z",
            "eventTitle": "ECB; POWELL TESTIMONY"
        }
    ]

    """

    try:
        logger.info("Calling get_market_events")

        response = Client().fx_event_tracker_service.get_market_events(
            currency_pair=currency_pair,
            event_title=event_title,
            start_date=start_date,
            page_size=page_size,
            headers={"x-ap-sdk-operation": "fx_event_tracker.get_market_events"},
        )

        output = response
        logger.info("Called get_market_events")

        return output
    except Exception as err:
        logger.error("Error get_market_events.")
        check_exception_and_raise(err, logger)


def get_volatility_overnight(
    *,
    currency_pair: Optional[str] = None,
    volatility_overnight_date: Optional[datetime.datetime] = None,
    start_date: Optional[datetime.datetime] = None,
    end_date: Optional[datetime.datetime] = None,
) -> list[DailyVolAtDate]:
    """


    Parameters
    ----------
    currency_pair : str, optional
        The currency pair.
    volatility_overnight_date : datetime.datetime, optional
        The volatility overnight date or event date (format: 'YYYY-MM-DD).
    start_date : datetime.datetime, optional
        The historical start date (format: 'YYYY-MM-DD).
    end_date : datetime.datetime, optional
        The historical end date (format: 'YYYY-MM-DD).

    Returns
    --------
    list[DailyVolAtDate]


    Examples
    --------
    >>> get_volatility_overnight_response = get_volatility_overnight(
    >>>     currency_pair="EUR/USD",
    >>>     volatility_overnight_date=datetime(2024, 1, 15),
    >>>     start_date=datetime(2024, 1, 10),
    >>>     end_date=datetime(2024, 1, 14),
    >>> )
    >>>
    >>> print(json.dumps([vol.as_dict() for vol in get_volatility_overnight_response], indent=4))
    [
        {
            "date": "2024-01-10T00:00:00Z",
            "value": 6.65117271887925,
            "straddleBreakeven": 0.00277774167759541
        },
        {
            "date": "2024-01-11T00:00:00Z",
            "value": 6.61775210000668,
            "straddleBreakeven": 0.00276378416215307
        },
        {
            "date": "2024-01-12T00:00:00Z",
            "value": 4.25,
            "straddleBreakeven": 0.00177493543300582
        },
        {
            "date": "2024-01-13T00:00:00Z",
            "value": null,
            "straddleBreakeven": null
        },
        {
            "date": "2024-01-14T00:00:00Z",
            "value": null,
            "straddleBreakeven": null
        }
    ]

    """

    try:
        logger.info("Calling get_volatility_overnight")

        response = Client().fx_event_tracker_service.get_volatility_overnight(
            currency_pair=currency_pair,
            volatility_overnight_date=volatility_overnight_date,
            start_date=start_date,
            end_date=end_date,
            headers={"x-ap-sdk-operation": "fx_event_tracker.get_volatility_overnight"},
        )

        output = response
        logger.info("Called get_volatility_overnight")

        return output
    except Exception as err:
        logger.error("Error get_volatility_overnight.")
        check_exception_and_raise(err, logger)


def get_volatility_overnight_range(
    *,
    currency_pair: Optional[str] = None,
    volatility_overnight_start_date: Optional[datetime.datetime] = None,
    volatility_overnight_end_date: Optional[datetime.datetime] = None,
    start_date: Optional[datetime.datetime] = None,
    end_date: Optional[datetime.datetime] = None,
) -> VolatilityOvernightRange:
    """


    Parameters
    ----------
    currency_pair : str, optional
        The currency pair.
    volatility_overnight_start_date : datetime.datetime, optional
        The volatility overnight start date or event date (format: 'YYYY-MM-DD).
    volatility_overnight_end_date : datetime.datetime, optional
        The volatility overnight end date or event date (format: 'YYYY-MM-DD).
    start_date : datetime.datetime, optional
        The historical start date (format: 'YYYY-MM-DD).
    end_date : datetime.datetime, optional
        The historical end date (format: 'YYYY-MM-DD).

    Returns
    --------
    VolatilityOvernightRange


    Examples
    --------
    >>> volatility_range = get_volatility_overnight_range(
    >>>     currency_pair="EUR/USD",
    >>>     volatility_overnight_start_date="2024-01-01T00:00:00Z",
    >>>     volatility_overnight_end_date="2024-12-31T23:59:59Z",
    >>>     start_date="2023-12-01T00:00:00Z",
    >>>     end_date="2023-12-15T00:00:00Z",
    >>> )
    >>>
    >>> response = volatility_range.as_dict()
    >>> get_volatility_overnight_list = response.get('volatilityOvernights', [])
    >>> # Limit to first few records for display
    >>> limited_response = {'volatilityOvernights': get_volatility_overnight_list[:1]}
    >>>
    >>> print(json.dumps(limited_response, indent=4))
    {
        "volatilityOvernights": [
            {
                "volatilityOvernightDate": "2024-01-01T00:00:00Z",
                "values": [
                    {
                        "date": "2023-12-01T00:00:00Z",
                        "value": 5.97989818213676,
                        "straddleBreakeven": 0.00249739603982156
                    },
                    {
                        "date": "2023-12-02T00:00:00Z",
                        "value": null,
                        "straddleBreakeven": null
                    },
                    {
                        "date": "2023-12-03T00:00:00Z",
                        "value": null,
                        "straddleBreakeven": null
                    },
                    {
                        "date": "2023-12-04T00:00:00Z",
                        "value": 6.07403399837809,
                        "straddleBreakeven": 0.00253671015647137
                    },
                    {
                        "date": "2023-12-05T00:00:00Z",
                        "value": 6.08098060539192,
                        "straddleBreakeven": 0.00253961128092502
                    },
                    {
                        "date": "2023-12-06T00:00:00Z",
                        "value": 6.31815300361184,
                        "straddleBreakeven": 0.00263866203229714
                    },
                    {
                        "date": "2023-12-07T00:00:00Z",
                        "value": 6.53830496521704,
                        "straddleBreakeven": 0.00273060450695568
                    },
                    {
                        "date": "2023-12-08T00:00:00Z",
                        "value": 6.24707677430113,
                        "straddleBreakeven": 0.00260897833397995
                    },
                    {
                        "date": "2023-12-09T00:00:00Z",
                        "value": null,
                        "straddleBreakeven": null
                    },
                    {
                        "date": "2023-12-10T00:00:00Z",
                        "value": null,
                        "straddleBreakeven": null
                    },
                    {
                        "date": "2023-12-11T00:00:00Z",
                        "value": 5.57925115748171,
                        "straddleBreakeven": 0.0023300730750713
                    },
                    {
                        "date": "2023-12-12T00:00:00Z",
                        "value": 5.22050722173373,
                        "straddleBreakeven": 0.00218025017555717
                    },
                    {
                        "date": "2023-12-13T00:00:00Z",
                        "value": 4.89902744683188,
                        "straddleBreakeven": 0.00204598997709411
                    },
                    {
                        "date": "2023-12-14T00:00:00Z",
                        "value": 5.26462893247096,
                        "straddleBreakeven": 0.00219867680796949
                    },
                    {
                        "date": "2023-12-15T00:00:00Z",
                        "value": 5.16928186501762,
                        "straddleBreakeven": 0.00215885683421511
                    }
                ]
            }
        ]
    }

    """

    try:
        logger.info("Calling get_volatility_overnight_range")

        response = Client().fx_event_tracker_service.get_volatility_overnight_range(
            currency_pair=currency_pair,
            volatility_overnight_start_date=volatility_overnight_start_date,
            volatility_overnight_end_date=volatility_overnight_end_date,
            start_date=start_date,
            end_date=end_date,
            headers={"x-ap-sdk-operation": "fx_event_tracker.get_volatility_overnight_range"},
        )

        output = response
        logger.info("Called get_volatility_overnight_range")

        return output
    except Exception as err:
        logger.error("Error get_volatility_overnight_range.")
        check_exception_and_raise(err, logger)
