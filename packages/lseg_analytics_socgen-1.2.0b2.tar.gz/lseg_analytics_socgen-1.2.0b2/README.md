# LSEG Analytics SDK for Python

The LSEG Analytics SDK for Python provides access to LSEG Financials Analytics Services of Societe Generale API.

## Getting Started

```shell
$ pip install lseg-analytics-socgen
```

## Usage Examples

An example to list Baskets.

```python
from lseg_analytics.socgen.basket_scan list_baskets

response = list_baskets()
```

## Modules Structure

- `common` - contains models that can be used in different API modules
- API modules
  - `basket_scan` - contains functions for Basket Scan API
  - `cof_box` - contains functions for CofBox API
  - `curve_follower` - contains functions for Curve Follower API
  - `fx_event_tracker` - contains functions for FX Event Tracker API
  - `market_data` - contains functions for Market Data API
  - `sustainable_bond_screener` - contains functions for Sustainable Bond Screener API
