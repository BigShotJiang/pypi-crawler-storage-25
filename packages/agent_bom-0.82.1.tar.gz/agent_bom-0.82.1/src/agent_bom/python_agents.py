"""Python agent framework scanner for agent-bom.

Scans a Python project directory for AI agent framework usage and extracts:

- **Agent definitions** — name, tools, model, credentials referenced in code
- **Framework packages** — exact version from requirements files for OSV scanning
- **Credential exposure** — env var references passed to agents/LLMs

Frameworks supported
--------------------
| Framework           | Package(s)                          | Org          |
|---------------------|-------------------------------------|--------------|
| OpenAI Agents SDK   | openai-agents                       | OpenAI       |
| Google ADK          | google-adk                          | Google       |
| LangChain / Graph   | langchain, langgraph                | LangChain AI |
| AutoGen             | pyautogen, autogen-agentchat        | Microsoft    |
| CrewAI              | crewai                              | CrewAI       |
| LlamaIndex          | llama-index-core, llama_index       | LlamaIndex   |
| Pydantic AI         | pydantic-ai                         | Pydantic     |
| smolagents          | smolagents                          | HuggingFace  |
| Semantic Kernel     | semantic-kernel                     | Microsoft    |
| Haystack            | haystack-ai, farm-haystack          | deepset      |

Zero extra dependencies — uses only ``re``, ``ast``, and ``pathlib`` from stdlib.

Usage::

    from agent_bom.python_agents import scan_python_agents

    agents, warnings = scan_python_agents("/path/to/my-agent-project")
"""

from __future__ import annotations

import ast
import hashlib
import re
from pathlib import Path
from typing import Any, NamedTuple

from agent_bom.models import Agent, AgentType, MCPServer, MCPTool, Package, TransportType

# ─── Framework registry ───────────────────────────────────────────────────────
# Maps canonical PyPI package name → (display_name, framework_key, import_roots)

_FRAMEWORKS: dict[str, tuple[str, str, list[str]]] = {
    "openai-agents": ("OpenAI Agents SDK", "openai-agents", ["agents"]),
    "google-adk": ("Google ADK", "google-adk", ["google.adk", "google.adk.agents"]),
    "langchain": ("LangChain", "langchain", ["langchain", "langchain_core", "langchain_community"]),
    "langgraph": ("LangGraph", "langchain", ["langgraph"]),
    "langchain-openai": ("LangChain-OpenAI", "langchain", ["langchain_openai"]),
    "langchain-anthropic": ("LangChain-Anthropic", "langchain", ["langchain_anthropic"]),
    "pyautogen": ("AutoGen", "autogen", ["autogen"]),
    "autogen-agentchat": ("AutoGen AgentChat", "autogen", ["autogen_agentchat", "autogen"]),
    "crewai": ("CrewAI", "crewai", ["crewai"]),
    "llama-index-core": ("LlamaIndex", "llamaindex", ["llama_index", "llama_index.core"]),
    "llama_index": ("LlamaIndex (legacy)", "llamaindex", ["llama_index"]),
    "pydantic-ai": ("Pydantic AI", "pydantic-ai", ["pydantic_ai"]),
    "smolagents": ("smolagents", "smolagents", ["smolagents"]),
    "semantic-kernel": ("Semantic Kernel", "semantic-kernel", ["semantic_kernel"]),
    "haystack-ai": ("Haystack", "haystack", ["haystack"]),
    "farm-haystack": ("Haystack (legacy)", "haystack", ["haystack"]),
}

# Flat set of all import roots for fast lookup
_ALL_IMPORT_ROOTS: frozenset[str] = frozenset(root for _, _, roots in _FRAMEWORKS.values() for root in roots)

# ─── Credential env var patterns ──────────────────────────────────────────────

_CRED_ENV_RE = re.compile(
    r"(?:OPENAI|ANTHROPIC|GOOGLE|GEMINI|AZURE|GROQ|COHERE|MISTRAL|"
    r"HUGGINGFACE|HF_TOKEN|LANGCHAIN|LLAMA|TOGETHER|REPLICATE|"
    r"AI21|VERTEX|BEDROCK|AWS_SECRET|API_KEY|API_TOKEN|SECRET_KEY)",
    re.IGNORECASE,
)

# ─── Agent instantiation patterns (per framework) ─────────────────────────────

# Generic: Agent(name="...", ...) or Agent("...", ...)
_AGENT_NAME_RE = re.compile(
    r'Agent\s*\(\s*(?:name\s*=\s*)?["\']([^"\']+)["\']',
)

# Tool decorators: @tool, @function_tool, @agent.tool
_TOOL_DECORATOR_RE = re.compile(
    r"@(?:\w+\.)?(?:function_tool|tool|skill|action)\s*\n\s*(?:async\s+)?def\s+(\w+)",
)

# tools=[foo, bar, baz] argument
_TOOLS_ARG_RE = re.compile(
    r"tools\s*=\s*\[([^\]]*)\]",
)

# model= argument
_MODEL_ARG_RE = re.compile(
    r'model\s*=\s*["\']([^"\']+)["\']',
)

# os.environ / os.getenv / env variable references
_ENV_REF_RE = re.compile(
    r'(?:os\.environ(?:\.get)?\s*[\[(]["\']|os\.getenv\s*\(\s*["\']|getenv\s*\(\s*["\'])'
    r"([A-Z][A-Z0-9_]+)",
)


# ─── Data classes ─────────────────────────────────────────────────────────────


class _PythonAgentDef(NamedTuple):
    name: str
    framework: str
    tools: list[tuple[str, str, str]]
    model: str
    env_refs: list[str]  # credential env var names referenced (never values)
    file: str
    system_prompts: tuple[dict[str, Any], ...] = ()


# ─── Requirement file parsers ─────────────────────────────────────────────────


def _parse_requirements_txt(path: Path) -> dict[str, str]:
    """Parse requirements.txt / constraints.txt → {package: version}."""
    pkgs: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line or line.startswith(("#", "-")):
            continue
        # name==1.2.3, name>=1.2, name~=1.2, name[extra]==1.2
        m = re.match(r"^([A-Za-z0-9_\-]+)(?:\[[^\]]*\])?\s*[=~!<>]+\s*([^\s;#,]+)", line)
        if m:
            pkgs[m.group(1).lower().replace("_", "-")] = m.group(2)
        else:
            # bare name with no version
            bare = re.match(r"^([A-Za-z0-9_\-]+)", line)
            if bare:
                pkgs[bare.group(1).lower().replace("_", "-")] = "unknown"
    return pkgs


def _parse_pyproject_toml(path: Path) -> dict[str, str]:
    """Parse pyproject.toml dependencies → {package: version}."""
    pkgs: dict[str, str] = {}
    text = path.read_text(encoding="utf-8", errors="replace")
    # Find [project.dependencies] or [tool.poetry.dependencies] sections
    in_deps = False
    for line in text.splitlines():
        stripped = line.strip()
        if re.match(r"^\[(?:project\.dependencies|tool\.poetry\.dependencies)\]", stripped):
            in_deps = True
            continue
        if stripped.startswith("[") and in_deps:
            in_deps = False
        if not in_deps:
            continue
        # "package>=1.2" or package = ">=1.2"
        m = re.match(r'^["\']?([A-Za-z0-9_\-]+)["\']?\s*(?:=\s*["\'])?[=~!<>^]*\s*([0-9][^\s"\']*)?', stripped)
        if m and m.group(1):
            name = m.group(1).lower().replace("_", "-")
            ver = m.group(2) or "unknown"
            pkgs[name] = ver
    return pkgs


def _collect_requirements(project: Path) -> dict[str, str]:
    """Collect {package: version} from all requirement files in the project."""
    pkgs: dict[str, str] = {}
    for req_file in project.rglob("requirements*.txt"):
        try:
            pkgs.update(_parse_requirements_txt(req_file))
        except OSError:
            pass
    for ppt in project.rglob("pyproject.toml"):
        try:
            pkgs.update(_parse_pyproject_toml(ppt))
        except OSError:
            pass
    return pkgs


# ─── Python file analysis ─────────────────────────────────────────────────────


def _detect_frameworks_in_imports(tree: ast.Module) -> set[str]:
    """Return set of framework_keys found via import statements."""
    found: set[str] = set()
    for node in ast.walk(tree):
        root: str | None = None
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
        elif isinstance(node, ast.ImportFrom) and node.module:
            root = node.module.split(".")[0]
        if root and root in _ALL_IMPORT_ROOTS:
            for pkg, (_, fkey, roots) in _FRAMEWORKS.items():
                if root in roots:
                    found.add(fkey)
    return found


def _extract_string_literal(node: ast.AST | None) -> str:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return ""


def _call_name(node: ast.AST) -> str:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _call_name(node.value)
        return f"{prefix}.{node.attr}" if prefix else node.attr
    return ""


def _keyword_value(node: ast.Call, name: str) -> ast.AST | None:
    for kw in node.keywords:
        if kw.arg == name:
            return kw.value
    return None


def _dedupe_detected_tools(tools: list[tuple[str, str, str]]) -> list[tuple[str, str, str]]:
    deduped: list[tuple[str, str, str]] = []
    seen: set[str] = set()
    for name, source, confidence in tools:
        normalized = name.strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        deduped.append((normalized, source, confidence))
    return deduped


def _extract_env_refs_from_ast(tree: ast.Module) -> list[str]:
    refs: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            call_name = _call_name(node.func)
            if call_name in {"os.getenv", "getenv"} and node.args:
                value = _extract_string_literal(node.args[0])
                if value and _CRED_ENV_RE.search(value):
                    refs.append(value)
            elif call_name == "os.environ.get" and node.args:
                value = _extract_string_literal(node.args[0])
                if value and _CRED_ENV_RE.search(value):
                    refs.append(value)
        elif isinstance(node, ast.Subscript):
            target_name = _call_name(node.value)
            if target_name != "os.environ":
                continue
            slice_node = node.slice
            value = _extract_string_literal(slice_node)
            if value and _CRED_ENV_RE.search(value):
                refs.append(value)
    return list(dict.fromkeys(refs))


def _framework_from_content(content: str) -> str:
    framework = "unknown"
    for root in _ALL_IMPORT_ROOTS:
        if re.search(rf"\bimport\s+{re.escape(root)}\b|from\s+{re.escape(root)}\b", content):
            for _, (_, fkey, roots) in _FRAMEWORKS.items():
                if root in roots:
                    framework = fkey
                    break
            if framework != "unknown":
                break
    return framework


def _extract_agent_defs_regex(content: str, filename: str) -> list[_PythonAgentDef]:
    """Extract agent definitions from Python source via regex fallback."""
    defs: list[_PythonAgentDef] = []

    # Detect framework from imports
    framework = _framework_from_content(content)

    # Extract @tool / @function_tool decorated functions
    tool_names = _TOOL_DECORATOR_RE.findall(content)

    # Extract env var references
    env_refs = [v for v in _ENV_REF_RE.findall(content) if _CRED_ENV_RE.search(v)]
    env_refs = list(dict.fromkeys(env_refs))  # dedupe preserving order

    # Extract Agent(...) instantiations
    for agent_m in _AGENT_NAME_RE.finditer(content):
        agent_name = agent_m.group(1)

        # Look for tools=[...] near this agent definition (within 500 chars)
        nearby = content[agent_m.start() : agent_m.start() + 500]
        tools_in_call: list[str] = []
        tools_m = _TOOLS_ARG_RE.search(nearby)
        if tools_m:
            raw = tools_m.group(1)
            tools_in_call = [t.strip().strip("\"'") for t in raw.split(",") if t.strip()]

        model_m = _MODEL_ARG_RE.search(nearby)
        model = model_m.group(1) if model_m else ""

        # Merge tools from decorators + call-site
        all_tools = _dedupe_detected_tools(
            [(name, "decorator", "high") for name in tool_names] + [(name, "literal-tools-arg", "high") for name in tools_in_call]
        )

        defs.append(
            _PythonAgentDef(
                name=agent_name,
                framework=framework,
                tools=all_tools,
                model=model,
                env_refs=env_refs,
                file=filename,
            )
        )

    return defs


def _extract_agent_defs(content: str, filename: str) -> list[_PythonAgentDef]:
    """Extract agent definitions from Python source with AST heuristics."""
    try:
        tree = ast.parse(content, filename=filename)
    except SyntaxError:
        return _extract_agent_defs_regex(content, filename)

    frameworks = _detect_frameworks_in_imports(tree)
    framework = sorted(frameworks)[0] if frameworks else _framework_from_content(content)
    env_refs = _extract_env_refs_from_ast(tree)

    tool_values: dict[str, tuple[str, str, str]] = {}
    tool_sets: dict[str, list[tuple[str, str, str]]] = {}

    def resolve_tool_expr(node: ast.AST | None, depth: int = 0) -> list[tuple[str, str, str]]:
        if node is None or depth > 6:
            return []
        if isinstance(node, ast.Name):
            if node.id in tool_sets:
                return tool_sets[node.id]
            if node.id in tool_values:
                return [tool_values[node.id]]
            return [(node.id, "name-reference", "low")]
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return [(node.value, "literal-tool-name", "medium")]
        if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
            items: list[tuple[str, str, str]] = []
            for elt in node.elts:
                items.extend(resolve_tool_expr(elt, depth + 1))
            return _dedupe_detected_tools(items)
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            return _dedupe_detected_tools(resolve_tool_expr(node.left, depth + 1) + resolve_tool_expr(node.right, depth + 1))
        if isinstance(node, ast.Call):
            call_name = _call_name(node.func).split(".")[-1]
            if call_name in {"Tool", "StructuredTool", "DynamicTool", "FunctionTool", "ToolWrapper", "tool"}:
                name = _extract_string_literal(_keyword_value(node, "name"))
                if not name and node.args:
                    name = _extract_string_literal(node.args[0])
                func_ref = _keyword_value(node, "func")
                if not name and isinstance(func_ref, ast.Name):
                    name = func_ref.id
                if not name and node.args and isinstance(node.args[0], ast.Name):
                    name = node.args[0].id
                if not name and node.args and isinstance(node.args[-1], ast.Name):
                    name = node.args[-1].id
                return [(name or call_name, "tool-constructor", "medium")]
            if call_name == "from_function":
                name = _extract_string_literal(_keyword_value(node, "name"))
                if not name and node.args and isinstance(node.args[0], ast.Name):
                    name = node.args[0].id
                return [(name or "from_function", "tool-from-function", "medium")]
        return []

    def record_assignment(target: ast.AST, value: ast.AST) -> None:
        if not isinstance(target, ast.Name):
            return
        resolved = _dedupe_detected_tools(resolve_tool_expr(value))
        if not resolved:
            return
        if isinstance(value, (ast.List, ast.Tuple, ast.Set, ast.BinOp)):
            tool_sets[target.id] = resolved
        elif len(resolved) == 1:
            tool_values[target.id] = resolved[0]
        else:
            tool_sets[target.id] = resolved

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for decorator in node.decorator_list:
                decorator_name = _call_name(decorator).split(".")[-1]
                if decorator_name in {"function_tool", "tool", "skill", "action"}:
                    tool_values[node.name] = (node.name, "decorator", "high")
                    break

    for stmt in tree.body:
        if isinstance(stmt, ast.Assign):
            for target in stmt.targets:
                record_assignment(target, stmt.value)
        elif isinstance(stmt, ast.AnnAssign):
            if stmt.value is not None:
                record_assignment(stmt.target, stmt.value)

    defs: list[_PythonAgentDef] = []
    candidate_calls = {"Agent", "AgentExecutor", "Crew", "create_react_agent", "initialize_agent"}

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        full_call_name = _call_name(node.func)
        call_name = full_call_name.split(".")[-1]
        if call_name not in candidate_calls and not call_name.endswith("Agent"):
            continue

        name = _extract_string_literal(_keyword_value(node, "name"))
        if not name and call_name == "create_react_agent":
            name = "react-agent"
        if not name and call_name == "Agent":
            name = _extract_string_literal(_keyword_value(node, "role"))
        if not name and node.args:
            name = _extract_string_literal(node.args[0])
        if not name:
            name = f"{Path(filename).stem}:{call_name.lower()}"

        tools_node = _keyword_value(node, "tools")
        tool_source = "keyword-tools-arg"
        if tools_node is None and call_name == "create_react_agent" and len(node.args) >= 2:
            tools_node = node.args[1]
            tool_source = "positional-tools-arg"

        all_tools = resolve_tool_expr(tools_node)
        if tool_source == "positional-tools-arg":
            all_tools = [(tool_name, f"{source}+{tool_source}", confidence) for tool_name, source, confidence in all_tools]

        model = _extract_string_literal(_keyword_value(node, "model"))
        if not model:
            model = _extract_string_literal(_keyword_value(node, "llm"))
        if not model and call_name == "create_react_agent" and node.args:
            model = _extract_string_literal(node.args[0])

        defs.append(
            _PythonAgentDef(
                name=name,
                framework=framework,
                tools=_dedupe_detected_tools(all_tools),
                model=model,
                env_refs=env_refs,
                file=filename,
            )
        )

    if defs:
        return defs
    return _extract_agent_defs_regex(content, filename)


def _scan_python_files(project: Path) -> list[_PythonAgentDef]:
    """Walk Python files and extract agent definitions."""
    all_defs: list[_PythonAgentDef] = []
    seen_names: set[str] = set()

    py_files = sorted(project.rglob("*.py"))
    # Exclude common non-project dirs
    py_files = [
        f
        for f in py_files
        if not any(
            part in f.parts
            for part in (
                ".venv",
                "venv",
                "env",
                ".env",
                "node_modules",
                "__pycache__",
                ".git",
                "dist",
                "build",
                "site-packages",
                "tests",
                "test",
            )
        )
    ]

    for py_file in py_files[:200]:  # cap at 200 files for performance
        try:
            content = py_file.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

        # Quick pre-filter: skip files with no agent framework imports
        if not any(root in content for root in _ALL_IMPORT_ROOTS):
            continue

        defs = _extract_agent_defs(content, py_file.name)
        for d in defs:
            key = f"{d.framework}:{d.name}"
            if key not in seen_names:
                seen_names.add(key)
                all_defs.append(d)

    return all_defs


def _prompt_inventory_by_file(project: Path) -> dict[str, list[dict[str, Any]]]:
    """Return bounded prompt inventory keyed by relative path and basename."""
    try:
        from agent_bom.ast_analyzer import analyze_project
    except Exception:
        return {}

    try:
        ast_result = analyze_project(project)
    except Exception:
        return {}

    by_file: dict[str, list[dict[str, Any]]] = {}
    for prompt in ast_result.prompts:
        text = str(prompt.text or "")
        item = {
            "variable": prompt.variable_name,
            "file": prompt.file_path,
            "line": prompt.line_number,
            "framework": prompt.framework,
            "type": prompt.prompt_type,
            "risk_flags": list(prompt.risk_flags),
            "text_preview": text[:240],
            "text_sha256": hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest(),
        }
        for key in {prompt.file_path, Path(prompt.file_path).name}:
            by_file.setdefault(key, []).append(item)
    return by_file


def _attach_system_prompts(agent_defs: list[_PythonAgentDef], project: Path) -> list[_PythonAgentDef]:
    """Attach AST-extracted prompt inventory to discovered Python agents."""
    prompts_by_file = _prompt_inventory_by_file(project)
    if not prompts_by_file:
        return agent_defs
    enriched: list[_PythonAgentDef] = []
    for agent_def in agent_defs:
        prompts = tuple(prompts_by_file.get(agent_def.file, []))
        enriched.append(agent_def._replace(system_prompts=prompts))
    return enriched


# ─── Public API ───────────────────────────────────────────────────────────────


def scan_python_agents(project_path: str) -> tuple[list[Agent], list[str]]:
    """Scan a Python project for AI agent framework usage.

    Detects agents built with OpenAI Agents SDK, Google ADK, LangChain,
    AutoGen, CrewAI, LlamaIndex, Pydantic AI, smolagents, Semantic Kernel,
    and Haystack. Extracts tool definitions, model names, credential references,
    and package versions for OSV vulnerability scanning.

    Parameters
    ----------
    project_path:
        Root of a Python project directory.

    Returns
    -------
    (agents, warnings)
        ``agents`` — list of :class:`~agent_bom.models.Agent` objects, one per
        discovered agent definition. Each agent has one
        :class:`~agent_bom.models.MCPServer` whose ``packages`` are the AI
        framework packages found in requirements files (with versions for OSV
        scanning), ``tools`` are the tool functions registered to the agent,
        and ``env`` contains the *names* of any credential env vars referenced
        (values are never logged).

        ``warnings`` — human-readable strings about credential exposure or
        missing version information.
    """
    project = Path(project_path).expanduser().resolve()  # lgtm[py/path-injection]
    if not project.is_dir():
        return [], [f"Not a directory: {project_path}"]

    # 1. Collect all package versions from requirements files
    req_pkgs = _collect_requirements(project)

    # 2. Determine which AI frameworks are present
    active_frameworks: dict[str, str] = {}  # framework_key → display_name
    framework_packages: dict[str, list[Package]] = {}  # framework_key → [Package]

    for pkg_name, (display, fkey, _) in _FRAMEWORKS.items():
        version = req_pkgs.get(pkg_name, req_pkgs.get(pkg_name.replace("-", "_")))
        if version:
            active_frameworks[fkey] = display
            pkg = Package(
                name=pkg_name,
                version=version,
                ecosystem="pypi",
                purl=f"pkg:pypi/{pkg_name}@{version}",
            )
            framework_packages.setdefault(fkey, []).append(pkg)

    # 3. Scan Python files for agent definitions
    agent_defs = _scan_python_files(project)
    if agent_defs:
        agent_defs = _attach_system_prompts(agent_defs, project)

    # If no agent definitions found but frameworks detected in requirements,
    # create one synthetic entry per framework so CVE scanning still runs
    if not agent_defs and active_frameworks:
        for fkey, display in active_frameworks.items():
            agent_defs.append(
                _PythonAgentDef(
                    name=f"{display} project",
                    framework=fkey,
                    tools=[],
                    model="",
                    env_refs=[],
                    file=project.name,
                )
            )

    if not agent_defs:
        return [], []

    # 4. Build warnings for credential exposure
    warnings: list[str] = []
    for d in agent_defs:
        if d.env_refs:
            warnings.append(f"Credential env vars referenced in {d.file} ({d.name}): " + ", ".join(d.env_refs))

    # 5. Build Agent objects
    agents: list[Agent] = []
    for d in agent_defs:
        pkgs = framework_packages.get(d.framework, [])

        # Include ALL non-AI packages too (for full CVE coverage)
        if not pkgs:
            # Framework not in requirements but used in code — add as unknown version
            display = dict((fkey, dn) for _, (dn, fkey, _) in _FRAMEWORKS.items()).get(d.framework, d.framework)
            pkgs = [
                Package(
                    name=d.framework,
                    version="unknown",
                    ecosystem="pypi",
                )
            ]
            warnings.append(
                f"Framework '{d.framework}' used in {d.file} but not found in "
                f"requirements files — version unknown, CVE scan may be incomplete"
            )

        tools = [
            MCPTool(
                name=name,
                description="agent tool",
                discovery_source=source,
                discovery_confidence=confidence,
            )
            for name, source, confidence in d.tools
        ]
        if d.model:
            tools.append(MCPTool(name=d.model, description="LLM model"))

        cred_env = {k: "***REDACTED***" for k in d.env_refs}

        server = MCPServer(
            name=f"{d.framework}:{d.name}",
            command="python",
            args=[],
            env=cred_env,
            transport=TransportType.STDIO,
            packages=pkgs,
            config_path=str(project),
            tools=tools,
        )
        agent = Agent(
            name=f"{d.framework}:{d.name}",
            agent_type=AgentType.CUSTOM,
            config_path=str(project),
            mcp_servers=[server],
            source="python-agents",
            metadata={
                "system_prompts": d.system_prompts,
                "system_prompt_count": len(d.system_prompts),
                "system_prompt_risk_flags": sorted({flag for prompt in d.system_prompts for flag in prompt.get("risk_flags", [])}),
            }
            if d.system_prompts
            else {},
        )
        agents.append(agent)

    return agents, warnings
