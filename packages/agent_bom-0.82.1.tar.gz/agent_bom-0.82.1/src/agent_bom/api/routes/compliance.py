"""Compliance and posture API routes.

Endpoints:
    GET  /v1/compliance                      14-framework compliance posture
    GET  /v1/compliance/narrative            full compliance narrative (all frameworks)
    GET  /v1/compliance/narrative/{framework} single-framework narrative
    GET  /v1/compliance/{framework}          single framework (must be after /narrative)
    GET  /v1/compliance/{framework}/report   signed evidence bundle for auditors
    GET  /v1/posture                         enterprise posture scorecard
    GET  /v1/posture/counts                  severity counts for nav badges
    GET  /v1/posture/credentials             credential risk ranking
    GET  /v1/posture/incidents               agent-centric incident correlation
"""

from __future__ import annotations

import json
import logging
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, cast

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, PlainTextResponse, StreamingResponse

from agent_bom.api.models import ComplianceReportBundle, JobStatus
from agent_bom.api.stores import _get_analytics_store, _get_fleet_store, _get_policy_store, _get_store
from agent_bom.rbac import require_authenticated_permission

if TYPE_CHECKING:
    from agent_bom.models import AIBOMReport
    from agent_bom.output.compliance_narrative import ComplianceNarrative


def _dep(permission: str) -> Any:
    return cast(Any, require_authenticated_permission(permission))


router = APIRouter(dependencies=[_dep("read")])
_logger = logging.getLogger(__name__)

_CLUSTER_SCAN_SOURCES = {"gpu_infra", "k8s"}
_CI_CD_SCAN_SOURCES = {"github_actions"}
_REGISTRY_SCAN_SOURCES = {"external_scan", "image", "sbom"}
_LOCAL_SCAN_SOURCES = {
    "agent_discovery",
    "ast_analysis",
    "browser_extensions",
    "dataset_cards",
    "external_scan",
    "filesystem",
    "image",
    "jupyter",
    "sbom",
    "secret_scan",
    "terraform",
    "training_pipelines",
}
_CLUSTER_ENVIRONMENTS = {"aks", "cluster", "eks", "gke", "k8s", "kubernetes"}


def _tenant_id(request: Request) -> str:
    return getattr(request.state, "tenant_id", "default")


def _tenant_jobs(request: Request) -> list:
    return _get_store().list_all(tenant_id=_tenant_id(request))


def _normalize_csv_filter(value: str | None) -> set[str]:
    if not value:
        return set()
    return {item.strip().lower() for item in value.split(",") if item.strip()}


def _result_has_runtime_signals(result: dict[str, Any]) -> bool:
    return bool(
        result.get("runtime_correlation")
        or result.get("runtime_session_graph")
        or result.get("introspection")
        or result.get("introspection_data")
        or result.get("health_check")
        or result.get("health_check_data")
    )


def _derive_deployment_context(request: Request, jobs: list[Any]) -> dict[str, Any]:
    tenant_id = _tenant_id(request)
    scan_sources: set[str] = set()
    has_mcp_context = False
    has_agent_context = False
    has_runtime_signals = False
    scan_count = 0

    for job in jobs:
        if job.status != JobStatus.DONE or not job.result:
            continue
        scan_count += 1
        result = cast(dict[str, Any], job.result)
        has_mcp_context = has_mcp_context or bool(result.get("has_mcp_context"))
        has_agent_context = has_agent_context or bool(result.get("has_agent_context"))
        scan_sources.update(str(src) for src in result.get("scan_sources", []) if src)
        has_runtime_signals = has_runtime_signals or _result_has_runtime_signals(result)

    fleet_agents = _get_fleet_store().list_by_tenant(tenant_id)
    has_fleet_ingest = len(fleet_agents) > 0
    has_cluster_scan = bool(scan_sources & _CLUSTER_SCAN_SOURCES) or any(
        str(getattr(agent, "environment", "") or "").strip().lower() in _CLUSTER_ENVIRONMENTS for agent in fleet_agents
    )
    has_ci_cd_scan = bool(scan_sources & _CI_CD_SCAN_SOURCES)
    has_local_scan = (
        bool(scan_sources & _LOCAL_SCAN_SOURCES)
        or has_agent_context
        or has_mcp_context
        or (scan_count > 0 and not has_cluster_scan and not has_ci_cd_scan)
    )
    has_registry = bool(scan_sources & _REGISTRY_SCAN_SOURCES)

    policy_store = _get_policy_store()
    policies = policy_store.list_policies(tenant_id=tenant_id)
    policy_audit = policy_store.list_audit_entries(limit=1, tenant_id=tenant_id)
    has_gateway = bool(policies)
    has_proxy = bool(policy_audit) or has_runtime_signals
    has_traces = bool(policy_audit) or has_runtime_signals
    has_mesh = (
        has_fleet_ingest
        or bool(scan_count and has_agent_context and has_mcp_context)
        or bool(has_runtime_signals and (has_agent_context or has_fleet_ingest))
    )

    active_modes = sum((has_local_scan, has_fleet_ingest, has_cluster_scan))
    if active_modes > 1:
        deployment_mode = "hybrid"
    elif has_cluster_scan:
        deployment_mode = "cluster"
    elif has_fleet_ingest:
        deployment_mode = "fleet"
    else:
        deployment_mode = "local"

    return {
        "deployment_mode": deployment_mode,
        "has_local_scan": has_local_scan,
        "has_fleet_ingest": has_fleet_ingest,
        "has_cluster_scan": has_cluster_scan,
        "has_ci_cd_scan": has_ci_cd_scan,
        "has_mesh": has_mesh,
        "has_gateway": has_gateway,
        "has_proxy": has_proxy,
        "has_traces": has_traces,
        "has_registry": has_registry,
        "has_mcp_context": has_mcp_context,
        "has_agent_context": has_agent_context,
        "scan_sources": sorted(scan_sources),
        "scan_count": scan_count,
    }


@router.get("/v1/compliance", tags=["compliance"])
async def get_compliance(request: Request) -> dict:
    """Aggregate OWASP LLM Top 10, OWASP MCP Top 10, MITRE ATLAS, NIST AI RMF,
    OWASP Agentic Top 10, and EU AI Act compliance posture across all completed scans.

    Returns per-control pass/warning/fail status and an overall compliance score.
    """
    from agent_bom.atlas import ATLAS_TECHNIQUES
    from agent_bom.nist_ai_rmf import NIST_AI_RMF
    from agent_bom.owasp import OWASP_LLM_TOP10

    # Collect blast_radius entries from all completed scans
    all_blast: list[dict] = []
    latest_scan: str | None = None
    scan_count = 0
    has_mcp_context = False
    has_agent_context = False
    all_scan_sources: set[str] = set()

    for job in _tenant_jobs(request):
        if job.status != JobStatus.DONE or not job.result:
            continue
        scan_count += 1
        br_list = job.result.get("blast_radius", [])
        all_blast.extend(br_list)
        if latest_scan is None or (job.completed_at and job.completed_at > latest_scan):
            latest_scan = job.completed_at
        # Detect scan context from result metadata
        if job.result.get("has_mcp_context"):
            has_mcp_context = True
        if job.result.get("has_agent_context"):
            has_agent_context = True
        for src in job.result.get("scan_sources", []):
            all_scan_sources.add(src)

    def _build_controls(
        catalog: dict[str, str],
        tag_field: str,
        id_key: str,
    ) -> list[dict]:
        """Build per-control compliance entries from blast_radius data."""
        controls = []
        for code, name in sorted(catalog.items()):
            sev_breakdown = {"critical": 0, "high": 0, "medium": 0, "low": 0}
            affected_pkgs: set[str] = set()
            affected_agents: set[str] = set()
            findings = 0

            for br in all_blast:
                tags = br.get(tag_field, [])
                if code in tags:
                    findings += 1
                    sev = (br.get("severity") or "").lower()
                    if sev in sev_breakdown:
                        sev_breakdown[sev] += 1
                    pkg = br.get("package")
                    if pkg:
                        affected_pkgs.add(pkg)
                    for agent in br.get("affected_agents", []):
                        affected_agents.add(agent)

            if findings == 0:
                status = "pass"
            elif sev_breakdown["critical"] > 0 or sev_breakdown["high"] > 0:
                status = "fail"
            else:
                status = "warning"

            controls.append(
                {
                    id_key: code,
                    "control_id": code,
                    "name": name,
                    "tags": [code],
                    "findings": findings,
                    "status": status,
                    "severity_breakdown": sev_breakdown,
                    "affected_packages": sorted(affected_pkgs),
                    "affected_agents": sorted(affected_agents),
                }
            )
        return controls

    from agent_bom.cis_controls import CIS_CONTROLS
    from agent_bom.cmmc import CMMC_PRACTICES
    from agent_bom.eu_ai_act import EU_AI_ACT
    from agent_bom.fedramp import FEDRAMP_MODERATE
    from agent_bom.iso_27001 import ISO_27001
    from agent_bom.nist_800_53 import NIST_800_53
    from agent_bom.nist_csf import NIST_CSF
    from agent_bom.owasp_agentic import OWASP_AGENTIC_TOP10
    from agent_bom.owasp_mcp import OWASP_MCP_TOP10
    from agent_bom.pci_dss import PCI_DSS_REQUIREMENTS
    from agent_bom.soc2 import SOC2_TSC

    owasp = _build_controls(OWASP_LLM_TOP10, "owasp_tags", "code")
    owasp_mcp = _build_controls(OWASP_MCP_TOP10, "owasp_mcp_tags", "code")
    atlas = _build_controls(ATLAS_TECHNIQUES, "atlas_tags", "code")
    nist = _build_controls(NIST_AI_RMF, "nist_ai_rmf_tags", "code")
    owasp_agentic = _build_controls(OWASP_AGENTIC_TOP10, "owasp_agentic_tags", "code")
    eu_ai_act = _build_controls(EU_AI_ACT, "eu_ai_act_tags", "code")
    nist_csf = _build_controls(NIST_CSF, "nist_csf_tags", "code")
    iso27001 = _build_controls(ISO_27001, "iso_27001_tags", "code")
    soc2 = _build_controls(SOC2_TSC, "soc2_tags", "code")
    cis = _build_controls(CIS_CONTROLS, "cis_tags", "code")
    cmmc = _build_controls(CMMC_PRACTICES, "cmmc_tags", "code")
    nist_800_53 = _build_controls(NIST_800_53, "nist_800_53_tags", "code")
    fedramp = _build_controls({c: c for c in FEDRAMP_MODERATE}, "fedramp_tags", "code")
    pci_dss = _build_controls(PCI_DSS_REQUIREMENTS, "pci_dss_tags", "code")

    def _count_statuses(controls: list[dict]) -> tuple[int, int, int]:
        p = sum(1 for c in controls if c["status"] == "pass")
        w = sum(1 for c in controls if c["status"] == "warning")
        f = sum(1 for c in controls if c["status"] == "fail")
        return p, w, f

    all_frameworks = [
        owasp,
        owasp_mcp,
        atlas,
        nist,
        owasp_agentic,
        eu_ai_act,
        nist_csf,
        iso27001,
        soc2,
        cis,
        cmmc,
        nist_800_53,
        fedramp,
        pci_dss,
    ]
    total_controls = sum(len(fw) for fw in all_frameworks)
    total_pass = sum(_count_statuses(fw)[0] for fw in all_frameworks)
    any_fail = any(_count_statuses(fw)[2] > 0 for fw in all_frameworks)
    any_warn = any(_count_statuses(fw)[1] > 0 for fw in all_frameworks)
    overall_score = round((total_pass / total_controls) * 100, 1) if total_controls > 0 else 100.0

    if any_fail:
        overall_status = "fail"
    elif any_warn:
        overall_status = "warning"
    else:
        overall_status = "pass"

    op, ow, of_ = _count_statuses(owasp)
    mp, mw, mf = _count_statuses(owasp_mcp)
    ap, aw, af = _count_statuses(atlas)
    np_, nw, nf = _count_statuses(nist)
    oap, oaw, oaf = _count_statuses(owasp_agentic)
    eup, euw, euf = _count_statuses(eu_ai_act)
    ncp, ncw, ncf = _count_statuses(nist_csf)
    ip, iw, if2 = _count_statuses(iso27001)
    sp, sw, sf = _count_statuses(soc2)
    cp, cw, cf = _count_statuses(cis)
    cmp, cmw, cmf = _count_statuses(cmmc)
    n8p, n8w, n8f = _count_statuses(nist_800_53)
    frp, frw, frf = _count_statuses(fedramp)
    pp, pw, pf = _count_statuses(pci_dss)

    return {
        "overall_score": overall_score,
        "overall_status": overall_status,
        "scan_count": scan_count,
        "latest_scan": latest_scan,
        "has_mcp_context": has_mcp_context,
        "has_agent_context": has_agent_context,
        "scan_sources": sorted(all_scan_sources),
        "owasp_llm_top10": owasp,
        "owasp_mcp_top10": owasp_mcp,
        "mitre_atlas": atlas,
        "nist_ai_rmf": nist,
        "owasp_agentic_top10": owasp_agentic,
        "eu_ai_act": eu_ai_act,
        "nist_csf": nist_csf,
        "iso_27001": iso27001,
        "soc2": soc2,
        "cis_controls": cis,
        "cmmc": cmmc,
        "nist_800_53": nist_800_53,
        "fedramp": fedramp,
        "pci_dss": pci_dss,
        "summary": {
            "owasp_pass": op,
            "owasp_warn": ow,
            "owasp_fail": of_,
            "owasp_mcp_pass": mp,
            "owasp_mcp_warn": mw,
            "owasp_mcp_fail": mf,
            "atlas_pass": ap,
            "atlas_warn": aw,
            "atlas_fail": af,
            "nist_pass": np_,
            "nist_warn": nw,
            "nist_fail": nf,
            "owasp_agentic_pass": oap,
            "owasp_agentic_warn": oaw,
            "owasp_agentic_fail": oaf,
            "eu_ai_act_pass": eup,
            "eu_ai_act_warn": euw,
            "eu_ai_act_fail": euf,
            "nist_csf_pass": ncp,
            "nist_csf_warn": ncw,
            "nist_csf_fail": ncf,
            "iso_27001_pass": ip,
            "iso_27001_warn": iw,
            "iso_27001_fail": if2,
            "soc2_pass": sp,
            "soc2_warn": sw,
            "soc2_fail": sf,
            "cis_pass": cp,
            "cis_warn": cw,
            "cis_fail": cf,
            "cmmc_pass": cmp,
            "cmmc_warn": cmw,
            "cmmc_fail": cmf,
            "nist_800_53_pass": n8p,
            "nist_800_53_warn": n8w,
            "nist_800_53_fail": n8f,
            "fedramp_pass": frp,
            "fedramp_warn": frw,
            "fedramp_fail": frf,
            "pci_dss_pass": pp,
            "pci_dss_warn": pw,
            "pci_dss_fail": pf,
        },
    }


@router.get("/v1/cis/checks", tags=["compliance"])
async def list_cis_benchmark_checks(
    request: Request,
    cloud: str | None = None,
    status: str | None = None,
    priority: int | None = None,
    limit: int = 100,
    offset: int = 0,
) -> dict:
    """List tenant-scoped CIS benchmark checks with indexed filters where available."""
    tenant_id = _tenant_id(request)
    safe_limit = max(1, min(int(limit), 500))
    safe_offset = max(0, int(offset))
    cloud_filter = _normalize_csv_filter(cloud)
    status_filter = _normalize_csv_filter(status)
    if priority is not None and priority < 0:
        raise HTTPException(status_code=400, detail="priority must be >= 0")

    job_store = _get_store()
    store_query = getattr(job_store, "query_cis_benchmark_checks", None)
    if callable(store_query) and len(cloud_filter) <= 1 and len(status_filter) <= 1:
        rows = store_query(
            tenant_id,
            cloud=next(iter(cloud_filter), None),
            status=next(iter(status_filter), None),
            priority=priority,
            limit=safe_limit,
            offset=safe_offset,
        )
        if rows:
            return {"checks": [_coerce_cis_row(row) for row in rows], "count": len(rows), "source": "columnar"}

    analytics_store = _get_analytics_store()
    query_fn = getattr(analytics_store, "query_cis_benchmark_checks", None)
    if callable(query_fn) and len(cloud_filter) <= 1 and len(status_filter) <= 1:
        try:
            rows = query_fn(
                cloud=next(iter(cloud_filter), None),
                status=next(iter(status_filter), None),
                priority=priority,
                limit=safe_limit,
                offset=safe_offset,
                tenant_id=tenant_id,
            )
            if rows:
                return {"checks": [_coerce_cis_row(row) for row in rows], "count": len(rows), "source": "analytics"}
        except Exception:
            pass

    from agent_bom.analytics_contract import build_cis_benchmark_check_rows

    all_rows: list[dict[str, Any]] = []
    for job in _tenant_jobs(request):
        if job.status != JobStatus.DONE or not isinstance(getattr(job, "result", None), dict):
            continue
        all_rows.extend(
            build_cis_benchmark_check_rows(
                job.result,
                str(job.result.get("scan_id") or job.job_id),
                measured_at=getattr(job, "completed_at", None) or getattr(job, "created_at", None),
            )
        )
    filtered = [
        row
        for row in all_rows
        if (not cloud_filter or row["cloud"].lower() in cloud_filter)
        and (not status_filter or row["status"].lower() in status_filter)
        and (priority is None or int(row["priority"]) == priority)
    ]
    filtered.sort(key=lambda row: (str(row.get("measured_at") or ""), -int(row.get("priority") or 0)), reverse=True)
    return {"checks": filtered[safe_offset : safe_offset + safe_limit], "count": len(filtered), "source": "scan_jobs"}


def _coerce_cis_row(row: dict[str, Any]) -> dict[str, Any]:
    coerced = dict(row)
    remediation = coerced.get("remediation")
    if isinstance(remediation, str):
        try:
            coerced["remediation"] = json.loads(remediation)
        except json.JSONDecodeError:
            coerced["remediation"] = {}
    return coerced


# ─── CIS Benchmark Trend / Drilldown (#1832) ──────────────────────────────


@router.get("/v1/cis/trends", tags=["compliance"])
async def cis_benchmark_trends(
    request: Request,
    days: int = 30,
    bucket: str = "day",
    cloud: str | None = None,
    section: str | None = None,
    status: str | None = None,
    severity: str | None = None,
) -> dict:
    """Time-bucketed CIS finding counts for trend / drilldown surfaces.

    Resolves to the columnar store (Postgres ``cis_benchmark_checks`` →
    ClickHouse) when available; otherwise reconstructs the aggregation
    in-memory from the tenant's recent scan results so single-node and
    SQLite-only deployments still return data.

    Query parameters:
    - ``days`` (1–366, default 30): rolling window size.
    - ``bucket`` (``hour`` | ``day`` | ``week``, default ``day``): bucket
      width. Anything else falls back to ``day``.
    - ``cloud`` / ``section`` / ``status`` / ``severity``: optional
      single-value filters narrowing the slice before aggregation.
    """
    tenant_id = _tenant_id(request)
    bucket_unit = bucket if bucket in {"hour", "day", "week"} else "day"
    days_clamped = max(1, min(int(days), 366))

    job_store = _get_store()
    aggregate_fn = getattr(job_store, "aggregate_cis_benchmark_checks", None)
    if callable(aggregate_fn):
        try:
            buckets = aggregate_fn(
                tenant_id,
                days=days_clamped,
                cloud=cloud,
                section=section,
                status=status,
                severity=severity,
                bucket=bucket_unit,
            )
            if buckets:
                return {
                    "buckets": buckets,
                    "count": len(buckets),
                    "source": "columnar",
                    "bucket": bucket_unit,
                    "days": days_clamped,
                }
        except Exception as exc:  # noqa: BLE001
            _logger.warning("Postgres CIS aggregation failed; trying analytics store: %s", exc)

    analytics_store = _get_analytics_store()
    analytics_aggregate = getattr(analytics_store, "aggregate_cis_benchmark_checks", None)
    if callable(analytics_aggregate):
        try:
            buckets = analytics_aggregate(
                days=days_clamped,
                cloud=cloud,
                section=section,
                status=status,
                severity=severity,
                bucket=bucket_unit,
                tenant_id=tenant_id,
            )
            if buckets:
                return {
                    "buckets": buckets,
                    "count": len(buckets),
                    "source": "analytics",
                    "bucket": bucket_unit,
                    "days": days_clamped,
                }
        except Exception as exc:  # noqa: BLE001
            _logger.warning("ClickHouse CIS aggregation failed: %s", exc)

    # In-memory fallback: aggregate the tenant's recent scan results
    # locally so even single-node and SQLite-only deployments answer.
    from agent_bom.analytics_contract import build_cis_benchmark_check_rows

    cutoff_isoformat = (datetime.now(timezone.utc) - timedelta(days=days_clamped)).isoformat()
    counts: dict[tuple[str, str, str, str, str], int] = {}
    for job in _tenant_jobs(request):
        if job.status != JobStatus.DONE or not isinstance(getattr(job, "result", None), dict):
            continue
        measured_at = getattr(job, "completed_at", None) or getattr(job, "created_at", None)
        if measured_at and str(measured_at) < cutoff_isoformat:
            continue
        rows = build_cis_benchmark_check_rows(
            job.result,
            str(job.result.get("scan_id") or job.job_id),
            measured_at=measured_at,
        )
        for row in rows:
            if cloud and row.get("cloud", "").lower() != cloud.lower():
                continue
            if section and row.get("cis_section", "") != section:
                continue
            if status and row.get("status", "").lower() != status.lower():
                continue
            if severity and row.get("severity", "").lower() != severity.lower():
                continue
            bucket_key = _bucket_for(str(row.get("measured_at") or ""), bucket_unit)
            key = (
                bucket_key,
                row.get("cloud", ""),
                row.get("cis_section", ""),
                row.get("status", ""),
                row.get("severity", ""),
            )
            counts[key] = counts.get(key, 0) + 1

    buckets_payload = [
        {
            "bucket": bucket_value,
            "cloud": cloud_value,
            "cis_section": section_value,
            "status": status_value,
            "severity": severity_value,
            "count": count,
        }
        for (bucket_value, cloud_value, section_value, status_value, severity_value), count in sorted(counts.items(), reverse=True)
    ]
    return {
        "buckets": buckets_payload,
        "count": len(buckets_payload),
        "source": "scan_jobs",
        "bucket": bucket_unit,
        "days": days_clamped,
    }


def _bucket_for(measured_at_iso: str, unit: str) -> str:
    """Truncate ``measured_at_iso`` to the given bucket granularity for the in-memory fallback."""
    if not measured_at_iso:
        return ""
    try:
        moment = datetime.fromisoformat(measured_at_iso.replace("Z", "+00:00"))
    except ValueError:
        return measured_at_iso
    if unit == "hour":
        moment = moment.replace(minute=0, second=0, microsecond=0)
    elif unit == "week":
        moment = moment - timedelta(days=moment.weekday())
        moment = moment.replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        moment = moment.replace(hour=0, minute=0, second=0, microsecond=0)
    return moment.isoformat()


# ─── Compliance Narrative ─────────────────────────────────────────────────


def _latest_report(request: Request) -> "AIBOMReport | None":
    """Return a synthetic AIBOMReport built from the latest completed scan result.

    The narrative generator expects a real ``AIBOMReport`` model object, but the
    API layer stores scan results as plain dicts (the JSON-serialised output).
    We reconstruct a minimal report with only the fields the narrative generator
    reads (``blast_radii``, ``agents``, ``total_packages``, ``total_agents``).
    """
    from agent_bom.models import (
        Agent,
        AgentType,
        AIBOMReport,
        BlastRadius,
        MCPServer,
        Package,
        Severity,
        Vulnerability,
    )

    # Merge blast_radius entries from ALL completed scans (same as /v1/compliance)
    all_blast_dicts: list[dict] = []
    total_agents_count = 0
    total_packages_count = 0

    for job in _tenant_jobs(request):
        if job.status != JobStatus.DONE or not job.result:
            continue
        all_blast_dicts.extend(job.result.get("blast_radius", []))
        summary = job.result.get("summary", {})
        total_agents_count += summary.get("total_agents", 0)
        total_packages_count += summary.get("total_packages", 0)

    if not all_blast_dicts and total_agents_count == 0:
        return None

    # Build minimal BlastRadius objects the narrative module can read
    blast_radii: list[BlastRadius] = []
    for bd in all_blast_dicts:
        raw_pkg = bd.get("package", "unknown@0.0")
        if "@" in raw_pkg:
            pkg_name, pkg_ver = raw_pkg.rsplit("@", 1)
        else:
            pkg_name, pkg_ver = raw_pkg, "0.0"

        sev_str = (bd.get("severity") or "unknown").upper()
        try:
            sev = Severity(sev_str.lower())
        except ValueError:
            sev = Severity.UNKNOWN

        vuln = Vulnerability(
            id=bd.get("vulnerability_id", "UNKNOWN"),
            summary="",
            severity=sev,
            fixed_version=bd.get("fixed_version"),
            is_kev=bool(bd.get("is_kev") or bd.get("cisa_kev")),
        )
        pkg = Package(name=pkg_name, version=pkg_ver, ecosystem=bd.get("ecosystem", ""))

        # Minimal affected agents (name only)
        agents = [Agent(name=n, agent_type=AgentType.CUSTOM, config_path="") for n in bd.get("affected_agents", [])]
        servers = [MCPServer(name=n) for n in bd.get("affected_servers", [])]

        br = BlastRadius(
            vulnerability=vuln,
            package=pkg,
            affected_servers=servers,
            affected_agents=agents,
            exposed_credentials=bd.get("exposed_credentials", []),
            exposed_tools=[],
            risk_score=float(bd.get("risk_score") or 0),
            owasp_tags=bd.get("owasp_tags", []),
            atlas_tags=bd.get("atlas_tags", []),
            nist_ai_rmf_tags=bd.get("nist_ai_rmf_tags", []),
            owasp_mcp_tags=bd.get("owasp_mcp_tags", []),
            owasp_agentic_tags=bd.get("owasp_agentic_tags", []),
            eu_ai_act_tags=bd.get("eu_ai_act_tags", []),
            nist_csf_tags=bd.get("nist_csf_tags", []),
            iso_27001_tags=bd.get("iso_27001_tags", []),
            soc2_tags=bd.get("soc2_tags", []),
            cis_tags=bd.get("cis_tags", []),
            cmmc_tags=bd.get("cmmc_tags", []),
        )
        blast_radii.append(br)

    # Pad agents list to match counts from scan summaries (narrative uses len(agents))
    agents_list = [Agent(name=f"agent-{i}", agent_type=AgentType.CUSTOM, config_path="") for i in range(total_agents_count)]
    # Pad packages via a synthetic server on the first agent
    if agents_list and total_packages_count > 0:
        dummy_pkgs = [Package(name=f"pkg-{i}", version="0.0", ecosystem="unknown") for i in range(total_packages_count)]
        agents_list[0].mcp_servers.append(MCPServer(name="__summary__", packages=dummy_pkgs))

    report = AIBOMReport(agents=agents_list, blast_radii=blast_radii)
    return report


def _narrative_to_dict(narrative: "ComplianceNarrative") -> dict:
    """Serialise a ComplianceNarrative dataclass to a JSON-safe dict."""
    return {
        "executive_summary": narrative.executive_summary,
        "risk_narrative": narrative.risk_narrative,
        "generated_at": narrative.generated_at,
        "framework_narratives": [
            {
                "framework": fn.framework,
                "slug": fn.slug,
                "status": fn.status,
                "score": fn.score,
                "narrative": fn.narrative,
                "recommendations": fn.recommendations,
                "failing_controls": [
                    {
                        "control_id": cn.control_id,
                        "title": cn.title,
                        "status": cn.status,
                        "narrative": cn.narrative,
                        "affected_packages": cn.affected_packages,
                        "affected_agents": cn.affected_agents,
                        "remediation_steps": cn.remediation_steps,
                    }
                    for cn in fn.failing_controls
                ],
            }
            for fn in narrative.framework_narratives
        ],
        "remediation_impact": [
            {
                "package": ri.package,
                "current_version": ri.current_version,
                "fix_version": ri.fix_version,
                "controls_fixed": ri.controls_fixed,
                "frameworks_impacted": ri.frameworks_impacted,
                "narrative": ri.narrative,
            }
            for ri in narrative.remediation_impact
        ],
    }


@router.get("/v1/compliance/narrative", tags=["compliance"])
async def get_compliance_narrative(request: Request) -> dict:
    """Generate a review-ready compliance narrative from all completed scans.

    Produces human-readable stories for all 11 supported frameworks, a
    cross-framework executive summary, and a remediation-compliance bridge
    showing which package upgrades resolve which controls.

    No LLM is required — narratives are generated from template strings
    and the structured blast radius data in completed scan results.
    """
    from agent_bom.output.compliance_narrative import (
        generate_compliance_narrative,
    )

    report = _latest_report(request)
    if report is None:
        return {
            "executive_summary": "No completed scans available. Run agent-bom scan first.",
            "framework_narratives": [],
            "remediation_impact": [],
            "risk_narrative": "No scan data available.",
            "generated_at": "",
        }

    narrative: ComplianceNarrative = generate_compliance_narrative(report)
    return _narrative_to_dict(narrative)


@router.get("/v1/compliance/narrative/{framework}", tags=["compliance"])
async def get_compliance_narrative_by_framework(request: Request, framework: str) -> dict:
    """Generate a single-framework compliance narrative.

    Supported framework slugs: owasp-llm, owasp-mcp, atlas, nist,
    owasp-agentic, eu-ai-act, nist-csf, iso-27001, soc2, cis, cmmc.

    Returns the same structure as GET /v1/compliance/narrative but scoped
    to a single framework's controls.
    """
    from agent_bom.output.compliance_narrative import (
        ALL_FRAMEWORK_SLUGS,
        generate_compliance_narrative,
    )

    if framework.lower() not in ALL_FRAMEWORK_SLUGS:
        raise HTTPException(
            status_code=400,
            detail=(f"Unknown framework '{framework}'. Supported: {', '.join(ALL_FRAMEWORK_SLUGS)}"),
        )

    report = _latest_report(request)
    if report is None:
        return {
            "executive_summary": "No completed scans available. Run agent-bom scan first.",
            "framework_narratives": [],
            "remediation_impact": [],
            "risk_narrative": "No scan data available.",
            "generated_at": "",
        }

    narrative: ComplianceNarrative = generate_compliance_narrative(report, framework=framework.lower())
    return _narrative_to_dict(narrative)


@router.get("/v1/compliance/verification-key", tags=["compliance"])
async def get_compliance_verification_key(request: Request) -> dict:
    """Return the Ed25519 public key used to sign compliance evidence bundles.

    Safe to expose — it's a public key. Auditors and external SIEM systems
    use this endpoint to fetch the verification key without operator
    hand-off.

    Response shape:
      - ``algorithm``: "Ed25519" when asymmetric signing is configured, else "HMAC-SHA256"
      - ``key_id``: stable 16-hex prefix of SHA-256(DER public key) — identifies the key across rotations
      - ``public_key_pem``: PEM-encoded public key (Ed25519 only)
      - ``key_distribution``: one-line guidance for verifiers
    """
    from agent_bom.api.compliance_signing import describe_current_signer

    algorithm, key_id, public_key_pem = describe_current_signer()
    if algorithm == "Ed25519":
        return {
            "algorithm": algorithm,
            "key_id": key_id,
            "public_key_pem": public_key_pem,
            "key_distribution": (
                "Retrieve this key over TLS once, pin the key_id, and use it to verify "
                "every compliance bundle signed with Ed25519. Rotate by updating "
                "AGENT_BOM_COMPLIANCE_ED25519_PRIVATE_KEY_PEM and re-fetching."
            ),
        }
    return {
        "algorithm": algorithm,
        "key_id": None,
        "public_key_pem": None,
        "key_distribution": (
            "Server is signing with HMAC-SHA256 (shared secret). Verifiers must obtain "
            "AGENT_BOM_AUDIT_HMAC_KEY out-of-band. For auditor-distributable signing, "
            "set AGENT_BOM_COMPLIANCE_ED25519_PRIVATE_KEY_PEM on the server."
        ),
    }


@router.get("/v1/compliance/{framework}", tags=["compliance"])
async def get_compliance_by_framework(request: Request, framework: str) -> dict:
    """Get compliance posture for a single framework.

    Supported frameworks: owasp-llm, owasp-mcp, atlas, nist, owasp-agentic, eu-ai-act,
    nist-csf, iso-27001, soc2, cis, cmmc
    """
    full = await get_compliance(request)

    framework_map = {
        "owasp-llm": "owasp_llm_top10",
        "owasp-mcp": "owasp_mcp_top10",
        "atlas": "mitre_atlas",
        "nist": "nist_ai_rmf",
        "owasp-agentic": "owasp_agentic_top10",
        "eu-ai-act": "eu_ai_act",
        "nist-csf": "nist_csf",
        "iso-27001": "iso_27001",
        "soc2": "soc2",
        "cis": "cis_controls",
        "cmmc": "cmmc",
        "nist-800-53": "nist_800_53",
        "fedramp": "fedramp",
        "pci-dss": "pci_dss",
    }

    key = framework_map.get(framework.lower())
    if not key:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown framework '{framework}'. Supported: {', '.join(framework_map.keys())}",
        )

    controls = full.get(key, [])
    pass_count = sum(1 for c in controls if c["status"] == "pass")
    warn_count = sum(1 for c in controls if c["status"] == "warning")
    fail_count = sum(1 for c in controls if c["status"] == "fail")

    return {
        "framework": framework,
        "controls": controls,
        "summary": {"pass": pass_count, "warning": warn_count, "fail": fail_count},
        "score": round((pass_count / len(controls)) * 100, 1) if controls else 100.0,
    }


# ─── Signed evidence bundle ────────────────────────────────────────────────


def _parse_iso_or_default(value: str | None, default: datetime) -> datetime:
    """Parse an ISO-8601 timestamp; fall back to ``default`` on missing/invalid."""
    if not value:
        return default
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid timestamp '{value}'. Use ISO-8601 with timezone.",
        ) from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _evidence_for_control(
    control: dict,
    blast_radii_by_tag: dict[str, list[dict]],
) -> list[dict]:
    """Map a control's tags onto the matching blast-radius findings."""
    seen_finding_ids: set[str] = set()
    evidence: list[dict] = []
    tags = list(control.get("tags", []) or [])
    fallback_tag = control.get("control_id") or control.get("code") or control.get("id")
    if fallback_tag and fallback_tag not in tags:
        tags.append(str(fallback_tag))
    for tag in tags:
        for br in blast_radii_by_tag.get(tag, []):
            finding_id = br.get("finding_id") or f"{br.get('vulnerability_id', '')}@{br.get('package', '')}"
            if finding_id in seen_finding_ids:
                continue
            seen_finding_ids.add(finding_id)
            evidence.append(
                {
                    "finding_id": finding_id,
                    "control_tag": tag,
                    "vulnerability_id": br.get("vulnerability_id"),
                    "package": br.get("package"),
                    "severity": br.get("severity"),
                    "scan_id": br.get("scan_id"),
                    "fixed_version": br.get("fixed_version"),
                    "agents_at_risk": br.get("affected_agents") or [],
                }
            )
    return evidence


def _index_blast_radii_by_tag(jobs: list) -> dict[str, list[dict]]:
    """Build a flat tag → list[blast-radius] index across all completed scans."""
    by_tag: dict[str, list[dict]] = {}
    for job in jobs:
        if job.status != JobStatus.DONE or not job.result:
            continue
        scan_id = job.result.get("scan_id") or job.job_id
        for br in job.result.get("blast_radius", []):
            br_with_scan = {**br, "scan_id": scan_id}
            for tag_field in (
                "owasp_tags",
                "owasp_mcp_tags",
                "atlas_tags",
                "nist_ai_rmf_tags",
                "nist_csf_tags",
                "iso_27001_tags",
                "soc2_tags",
                "cmmc_tags",
                "fedramp_tags",
                "owasp_agentic_tags",
                "eu_ai_act_tags",
                "cis_tags",
                "nist_800_53_tags",
                "pci_dss_tags",
            ):
                for tag in br.get(tag_field, []) or []:
                    by_tag.setdefault(tag, []).append(br_with_scan)
    return by_tag


def _verify_audit_entries(entries: list) -> tuple[int, int]:
    """Verify only the entries included in the exported bundle."""
    verified = 0
    tampered = 0
    for entry in entries:
        if entry.verify():
            verified += 1
        else:
            tampered += 1
    return verified, tampered


@router.get("/v1/compliance/{framework}/report", tags=["compliance"], response_model=ComplianceReportBundle)
async def export_compliance_report(
    request: Request,
    framework: str,
    since: str | None = None,
    until: str | None = None,
    format: str = "json",
) -> JSONResponse | PlainTextResponse | StreamingResponse:
    """Export a tamper-evident signed evidence bundle for a single framework.

    The bundle pairs each control with the blast-radius findings that map to
    its tags, the audit-log entries within the requested time window, and
    integrity totals from the HMAC-chained log.

    Security properties of the bundle:

    - **Integrity** — ``X-Agent-Bom-Compliance-Report-Signature`` is the
      HMAC-SHA256 of the canonical body. Any tampering with any field
      invalidates the signature.
    - **Replay protection** — the body carries ``nonce`` (128-bit) and
      ``expires_at``; both are inside the signed envelope so a captured
      bundle cannot be re-used after its expiry window. Consumers should
      reject bundles where ``expires_at`` is in the past.
    - **Confidentiality** — the bundle is cleartext at the application
      layer by design (auditors need to read it). Operators MUST serve
      ``/v1/compliance/*`` over TLS so evidence is not sniffable in
      transit.
    - **Non-repudiation** — HMAC is a shared secret so it does not provide
      true non-repudiation; for forensic use, correlate with the
      ``compliance.report_exported`` entry in the audit log (which
      records the nonce of every exported bundle).
    - **Tenant isolation** — controls evidence and audit events are
      filtered by the authed tenant; cross-tenant data never appears
      in a bundle belonging to another tenant.

    Query params:
      - ``since`` ISO-8601 timestamp (default: now − 30 days)
      - ``until`` ISO-8601 timestamp (default: now)
      - ``format`` ``json`` (default) or ``jsonl`` for streaming consumers
    """
    fmt = format.lower()
    if fmt not in {"json", "jsonl"}:
        raise HTTPException(status_code=400, detail="format must be one of: json, jsonl")

    now = datetime.now(timezone.utc)
    since_dt = _parse_iso_or_default(since, now - timedelta(days=30))
    until_dt = _parse_iso_or_default(until, now)
    if since_dt >= until_dt:
        raise HTTPException(status_code=400, detail="since must be earlier than until")

    full = await get_compliance(request)
    framework_map = {
        "owasp-llm": ("owasp_llm_top10", "OWASP LLM Top 10"),
        "owasp-mcp": ("owasp_mcp_top10", "OWASP MCP Top 10"),
        "atlas": ("mitre_atlas", "MITRE ATLAS"),
        "nist": ("nist_ai_rmf", "NIST AI RMF"),
        "owasp-agentic": ("owasp_agentic_top10", "OWASP Agentic Top 10"),
        "eu-ai-act": ("eu_ai_act", "EU AI Act"),
        "nist-csf": ("nist_csf", "NIST CSF"),
        "iso-27001": ("iso_27001", "ISO 27001"),
        "soc2": ("soc2", "SOC 2"),
        "cis": ("cis_controls", "CIS Controls"),
        "cmmc": ("cmmc", "CMMC"),
        "nist-800-53": ("nist_800_53", "NIST 800-53"),
        "fedramp": ("fedramp", "FedRAMP"),
        "pci-dss": ("pci_dss", "PCI DSS"),
    }
    key_label = framework_map.get(framework.lower())
    if not key_label:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown framework '{framework}'. Supported: {', '.join(framework_map.keys())}",
        )
    framework_key, framework_label = key_label
    controls = full.get(framework_key, [])

    tenant_id = _tenant_id(request)
    actor = getattr(request.state, "api_key_name", "") or "system"

    blast_by_tag = _index_blast_radii_by_tag(_tenant_jobs(request))

    from agent_bom.api.audit_log import get_audit_log, log_action

    store = get_audit_log()
    audit_since_iso = since_dt.isoformat()
    # Cap audit fetch at 10k for export sanity; consumers paginate further via /v1/audit
    audit_entries = store.list_entries(since=audit_since_iso, limit=10_000, tenant_id=tenant_id)
    until_iso = until_dt.isoformat()
    audit_in_window = [e for e in audit_entries if audit_since_iso <= (e.timestamp or "") <= until_iso]
    verified, tampered = _verify_audit_entries(audit_in_window)

    pass_count = sum(1 for c in controls if c.get("status") == "pass")
    warn_count = sum(1 for c in controls if c.get("status") == "warning")
    fail_count = sum(1 for c in controls if c.get("status") == "fail")

    enriched_controls: list[dict] = []
    total_findings = 0
    for control in controls:
        evidence = _evidence_for_control(control, blast_by_tag)
        total_findings += len(evidence)
        enriched_controls.append(
            {
                "control_id": control.get("control_id") or control.get("id"),
                "control_name": control.get("name") or control.get("title"),
                "status": control.get("status", "unknown"),
                "finding_count": len(evidence),
                "evidence": evidence,
            }
        )

    # Replay-protection envelope: every bundle carries a fresh 128-bit nonce
    # and an explicit expiry. The signature is computed over the canonical
    # body that includes both, so tampering with either invalidates the
    # signature and a captured bundle cannot be re-used after expiry.
    nonce = secrets.token_hex(16)
    bundle_ttl_seconds = int(os.environ.get("AGENT_BOM_COMPLIANCE_BUNDLE_TTL_SECONDS", "86400"))
    bundle_ttl_seconds = max(60, min(bundle_ttl_seconds, 30 * 86400))  # 1 min to 30 days
    expires_at = now + timedelta(seconds=bundle_ttl_seconds)

    # Resolve signer config up-front so the algorithm, key_id, and public key
    # are part of the canonical body that gets signed — verifiers read the
    # same fields and reconstruct the exact canonical form.
    from agent_bom.api.compliance_signing import (
        describe_current_signer,
        sign_compliance_bundle,
    )

    signing_algorithm, signing_key_id, signing_public_key_pem = describe_current_signer()

    body: dict[str, Any] = {
        "schema_version": "v1",
        "framework": framework,
        "framework_key": framework_key,
        "framework_label": framework_label,
        "tenant_id": tenant_id,
        "generated_at": now.isoformat(),
        "expires_at": expires_at.isoformat(),
        "nonce": nonce,
        "scope": {
            "since": since_dt.isoformat(),
            "until": until_dt.isoformat(),
            "control_count": len(controls),
            "finding_count": total_findings,
            "audit_event_count": len(audit_in_window),
        },
        "summary": {
            "pass": pass_count,
            "warning": warn_count,
            "fail": fail_count,
            "score": round((pass_count / len(controls)) * 100, 1) if controls else 100.0,
        },
        "controls": enriched_controls,
        "audit_events": [entry.to_dict() for entry in audit_in_window],
        "audit_log_integrity": {
            "verified": verified,
            "tampered": tampered,
            "checked": len(audit_in_window),
        },
        "signature_algorithm": signing_algorithm,
        "threat_model": {
            "integrity": (f"{signing_algorithm} over the canonical UTF-8 body. Tampering with any field invalidates the signature."),
            "confidentiality": (
                "The bundle is cleartext at the application layer by design — auditors "
                "need to read it. Operators MUST serve /v1/compliance/* over TLS so the "
                "bundle is not sniffable in transit."
            ),
            "replay": (
                "nonce + expires_at are inside the signed envelope. A re-issued bundle "
                "past expires_at is expected to be rejected by the consumer."
            ),
            "non_repudiation": (
                "Ed25519 provides asymmetric non-repudiation — verifiers only need the "
                "public key (at /v1/compliance/verification-key). HMAC is a shared secret "
                "so it does NOT provide true non-repudiation; for forensic cases cross-"
                "reference the compliance.report_exported audit entry."
                if signing_algorithm == "Ed25519"
                else "HMAC is a shared secret between server and auditor; it does NOT provide "
                "true non-repudiation. For forensic cases requiring non-repudiation, "
                "cross-reference the compliance.report_exported audit entry, or configure "
                "AGENT_BOM_COMPLIANCE_ED25519_PRIVATE_KEY_PEM to switch to Ed25519 signing."
            ),
        },
    }
    if signing_key_id is not None:
        body["signature_key_id"] = signing_key_id
    if signing_public_key_pem is not None:
        body["signature_public_key_pem"] = signing_public_key_pem

    log_action(
        "compliance.report_exported",
        actor=actor,
        resource=f"compliance/{framework_key}",
        tenant_id=tenant_id,
        format=fmt,
        since=since_dt.isoformat(),
        until=until_dt.isoformat(),
        control_count=len(controls),
        finding_count=total_findings,
        audit_event_count=len(audit_in_window),
        nonce=nonce,
        expires_at=expires_at.isoformat(),
    )

    filename = f"agent-bom-compliance-{framework_key.replace('_', '-')}.{'jsonl' if fmt == 'jsonl' else 'json'}"

    def _signing_headers(payload: bytes) -> dict[str, str]:
        sig_result = sign_compliance_bundle(payload)
        headers = {
            "X-Agent-Bom-Compliance-Report-Signature": sig_result.signature_hex,
            "X-Agent-Bom-Compliance-Signature-Algorithm": sig_result.algorithm,
        }
        if sig_result.key_id is not None:
            headers["X-Agent-Bom-Compliance-Signature-KeyId"] = sig_result.key_id
        return headers

    from agent_bom.api.metrics import record_compliance_export

    if fmt == "jsonl":
        # jsonl streams one control per line so SIEM and security-lake
        # consumers can ingest without loading the whole bundle. We build
        # the full payload once (signing requires the complete canonical
        # bytes), then stream it in 64 KB chunks so very large exports
        # don't pin a whole copy in the ASGI write buffer.
        lines = [json.dumps({"meta": {k: v for k, v in body.items() if k not in {"controls", "audit_events"}}}, sort_keys=True)]
        for control in body["controls"]:
            lines.append(json.dumps({"control": control}, sort_keys=True))
        for entry in body["audit_events"]:
            lines.append(json.dumps({"audit": entry}, sort_keys=True))
        payload = ("\n".join(lines) + "\n").encode()
        record_compliance_export(signing_algorithm, framework_key, len(payload))

        async def _iter_chunks(data: bytes, chunk_size: int = 64 * 1024):
            for offset in range(0, len(data), chunk_size):
                yield data[offset : offset + chunk_size]

        return StreamingResponse(
            _iter_chunks(payload),
            media_type="application/x-ndjson",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Content-Length": str(len(payload)),
                **_signing_headers(payload),
            },
        )

    payload = json.dumps(body, sort_keys=True).encode()
    record_compliance_export(signing_algorithm, framework_key, len(payload))
    return JSONResponse(
        content=body,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            **_signing_headers(payload),
        },
    )


# ─── Posture Scorecard ─────────────────────────────────────────────────────


@router.get("/v1/posture", tags=["compliance"])
async def get_posture_scorecard(request: Request) -> dict:
    """Compute enterprise posture scorecard from the latest completed scan.

    Returns a letter grade (A-F), numeric score (0-100), and per-dimension
    breakdown covering vulnerability posture, credential hygiene, supply
    chain quality, compliance coverage, active exploitation, and configuration.
    """
    latest_result = None
    for job in _tenant_jobs(request):
        if job.status != JobStatus.DONE or not job.result:
            continue
        latest_result = job.result
        break  # list_all returns newest first

    if latest_result is None:
        return {
            "grade": "N/A",
            "score": 0,
            "summary": "No completed scans available",
            "dimensions": {},
        }

    scorecard = latest_result.get("posture_scorecard")
    if scorecard:
        return scorecard

    return {
        "grade": "N/A",
        "score": 0,
        "summary": "Scorecard not computed for this scan",
        "dimensions": {},
    }


@router.get("/v1/posture/enrichment", tags=["compliance"])
async def get_enrichment_posture() -> dict:
    """Report runtime health for external vulnerability enrichment sources."""

    from agent_bom.enrichment_posture import describe_enrichment_posture

    return describe_enrichment_posture()


@router.get("/v1/posture/backpressure", tags=["compliance"])
async def get_backpressure_posture() -> dict:
    """Report adaptive runtime backpressure state for expensive paths."""

    from agent_bom.backpressure import describe_backpressure_posture

    return describe_backpressure_posture()


@router.get("/v1/posture/counts", tags=["compliance"])
async def get_posture_counts(request: Request) -> dict:
    """Aggregate vulnerability counts across all completed scans.

    Lightweight endpoint used by the dashboard nav to show Critical/High
    badges without loading full scan payloads.

    Returns:
        {critical, high, medium, low, total, kev, compound_issues}
    """
    counts: dict[str, Any] = {
        "critical": 0,
        "high": 0,
        "medium": 0,
        "low": 0,
        "total": 0,
        "kev": 0,
        "compound_issues": 0,
    }
    seen_ids: set[str] = set()
    tenant_jobs = _tenant_jobs(request)

    for job in tenant_jobs:
        if job.status != JobStatus.DONE or not job.result:
            continue

        blast_list = job.result.get("blast_radius", [])
        for b in blast_list:
            vid = b.get("vulnerability_id", "")
            if vid in seen_ids:
                continue
            seen_ids.add(vid)
            sev = (b.get("severity") or "").lower()
            if sev in counts:
                counts[sev] += 1
            counts["total"] += 1
            if b.get("cisa_kev") or b.get("is_kev"):
                counts["kev"] += 1
            # Compound issue: KEV + reachable tool, or KEV + exposed cred
            if (b.get("cisa_kev") or b.get("is_kev")) and (b.get("reachable_tools") or b.get("exposed_credentials")):
                counts["compound_issues"] += 1
            elif (b.get("epss_score") or 0) >= 0.3 and (b.get("cvss_score") or 0) >= 7:
                counts["compound_issues"] += 1

    counts.update(_derive_deployment_context(request, tenant_jobs))
    return counts


@router.get("/v1/posture/credentials", tags=["compliance"])
async def get_credential_risk_ranking(request: Request) -> dict:
    """Rank credentials by blast radius exposure from the latest scan.

    Returns credentials sorted by risk tier (critical to low) with
    associated vulnerability counts and affected agents.
    """
    latest_result = None
    for job in _tenant_jobs(request):
        if job.status != JobStatus.DONE or not job.result:
            continue
        latest_result = job.result
        break

    if latest_result is None:
        return {"credentials": [], "count": 0}

    ranking = latest_result.get("credential_risk_ranking", [])
    return {"credentials": ranking, "count": len(ranking)}


@router.get("/v1/posture/incidents", tags=["compliance"])
async def get_incident_correlation(request: Request) -> dict:
    """Group vulnerabilities by agent for SOC incident correlation.

    Returns agent-centric incident summaries with priority (P1-P4),
    severity counts, credential exposure, and recommended actions.
    """
    latest_result = None
    for job in _tenant_jobs(request):
        if job.status != JobStatus.DONE or not job.result:
            continue
        latest_result = job.result
        break

    if latest_result is None:
        return {"incidents": [], "count": 0}

    incidents = latest_result.get("incident_correlation", [])
    return {"incidents": incidents, "count": len(incidents)}
