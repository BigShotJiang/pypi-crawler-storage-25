"""Pydantic models for SubscribeFlow SDK."""

from datetime import datetime
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict, EmailStr, Field

T = TypeVar("T")


class TagBrief(BaseModel):
    """Brief tag information embedded in subscriber responses."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Tag UUID")
    name: str = Field(description="Tag display name")
    category: str | None = Field(default=None, description="Tag category")


class SubscriberTagsResult(BaseModel):
    """Response from adding/listing subscriber tags."""

    model_config = ConfigDict(extra="forbid")

    subscriber_id: str = Field(description="Subscriber UUID")
    tags: list[TagBrief] = Field(description="Current tags")
    total: int = Field(description="Total number of tags")


class Subscriber(BaseModel):
    """A subscriber in the SubscribeFlow system."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Subscriber UUID")
    email: EmailStr = Field(description="Subscriber email address")
    status: str = Field(description="Status: active, unsubscribed, bounced, complained")
    tags: list[TagBrief] = Field(default_factory=list, description="Subscribed tags")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Custom metadata")
    created_at: datetime = Field(description="Creation timestamp")
    updated_at: datetime = Field(description="Last update timestamp")


class Tag(BaseModel):
    """A subscription tag/topic."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Tag UUID")
    name: str = Field(description="Tag display name")
    description: str | None = Field(default=None, description="Tag description")
    category: str | None = Field(default=None, description="Category for grouping tags")
    external_topic_id: str | None = Field(default=None, description="External provider topic ID")
    is_public: bool = Field(default=True, description="Whether visible in Preference Center")
    subscriber_count: int = Field(default=0, description="Number of active subscribers")
    created_at: datetime = Field(description="Creation timestamp")
    updated_at: datetime = Field(description="Last update timestamp")


class WebhookEndpoint(BaseModel):
    """A webhook endpoint configuration."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Webhook endpoint UUID")
    url: str = Field(description="Webhook delivery URL")
    events: list[str] = Field(description="Subscribed event types")
    description: str | None = Field(default=None, description="Endpoint description")
    is_active: bool = Field(description="Whether the endpoint is active")
    last_triggered_at: datetime | None = Field(default=None, description="Last trigger timestamp")
    failure_count: int = Field(default=0, description="Consecutive failure count")
    created_at: datetime = Field(description="Creation timestamp")
    updated_at: datetime = Field(description="Last update timestamp")


class WebhookEndpointWithSecret(WebhookEndpoint):
    """Webhook endpoint with signing secret (returned on creation)."""

    secret: str = Field(description="Signing secret for signature verification")


class WebhookTestResult(BaseModel):
    """Result of a webhook endpoint test."""

    model_config = ConfigDict(extra="forbid")

    success: bool = Field(description="Whether the test succeeded")
    status_code: int | None = Field(default=None, description="HTTP response status code")
    response_time_ms: int | None = Field(default=None, description="Response time in milliseconds")
    error: str | None = Field(default=None, description="Error message if failed")


class TokenResponse(BaseModel):
    """Preference center token response."""

    model_config = ConfigDict(extra="forbid")

    token: str = Field(description="JWT token for preference center access")
    expires_at: datetime = Field(description="Token expiration timestamp")


class PaginatedResponse(BaseModel, Generic[T]):
    """Generic paginated response wrapper."""

    model_config = ConfigDict(extra="forbid")

    items: list[T] = Field(description="List of items in this page")
    total: int = Field(description="Total number of items across all pages")
    next_cursor: str | None = Field(default=None, description="Cursor for next page, if available")

    def __iter__(self):
        """Iterate over items in the response."""
        return iter(self.items)

    def __len__(self) -> int:
        """Return number of items in this page."""
        return len(self.items)


# Request models


class SubscriberCreate(BaseModel):
    """Request model for creating a subscriber."""

    email: EmailStr = Field(description="Email address")
    tags: list[str] = Field(default_factory=list, description="Tag IDs to subscribe to")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Custom metadata")


class SubscriberUpdate(BaseModel):
    """Request model for updating a subscriber."""

    metadata: dict[str, Any] | None = Field(default=None, description="Custom metadata")
    status: str | None = Field(default=None, description="New status: active or unsubscribed")


class TagCreate(BaseModel):
    """Request model for creating a tag."""

    name: str = Field(description="Tag display name")
    description: str | None = Field(default=None, description="Tag description")
    category: str | None = Field(default=None, description="Category for grouping tags")
    is_public: bool = Field(default=True, description="Whether visible in Preference Center")


class TagUpdate(BaseModel):
    """Request model for updating a tag."""

    name: str | None = Field(default=None, description="New display name")
    description: str | None = Field(default=None, description="New description")
    category: str | None = Field(default=None, description="New category")
    is_public: bool | None = Field(default=None, description="New visibility setting")


class WebhookCreate(BaseModel):
    """Request model for creating a webhook endpoint."""

    url: str = Field(description="Webhook delivery URL")
    events: list[str] = Field(description="Event types to subscribe to")
    description: str | None = Field(default=None, description="Endpoint description")


# Template models


class EmailTemplate(BaseModel):
    """An email template in the SubscribeFlow system."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Template UUID")
    name: str = Field(description="Template display name")
    slug: str = Field(description="URL-safe template identifier")
    subject: str = Field(description="Email subject line")
    mjml_content: str = Field(description="MJML template content")
    compiled_html: str | None = Field(default=None, description="Compiled HTML output")
    variables_schema: dict[str, Any] | None = Field(
        default=None, description="JSON Schema for template variables"
    )
    category: str = Field(description="Template category")
    is_active: bool = Field(description="Whether the template is active")
    created_at: datetime = Field(description="Creation timestamp")
    updated_at: datetime = Field(description="Last update timestamp")


class EmailTemplateCreate(BaseModel):
    """Request model for creating an email template."""

    name: str = Field(description="Template display name")
    subject: str = Field(description="Email subject line")
    mjml_content: str = Field(description="MJML template content")
    variables_schema: dict[str, Any] | None = Field(
        default=None, description="JSON Schema for template variables"
    )
    category: str = Field(default="transactional", description="Template category")


class EmailTemplateUpdate(BaseModel):
    """Request model for updating an email template."""

    name: str | None = Field(default=None, description="New display name")
    subject: str | None = Field(default=None, description="New subject line")
    mjml_content: str | None = Field(default=None, description="New MJML template content")
    variables_schema: dict[str, Any] | None = Field(
        default=None, description="New JSON Schema for template variables"
    )
    category: str | None = Field(default=None, description="New category")


class TemplatePreview(BaseModel):
    """Preview of a rendered email template."""

    model_config = ConfigDict(extra="forbid")

    html: str = Field(description="Rendered HTML content")
    subject: str = Field(description="Rendered subject line")


# Email send models


class EmailSendRequest(BaseModel):
    """Request model for sending an email."""

    template_slug: str = Field(description="Template slug to use")
    to: EmailStr = Field(description="Recipient email address")
    variables: dict[str, str | int | float | bool] = Field(
        default_factory=dict, description="Template variables"
    )
    idempotency_key: str | None = Field(
        default=None, description="Idempotency key for deduplication"
    )


class EmailSendResponse(BaseModel):
    """Response model for a sent email."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Email send UUID")
    status: str = Field(description="Send status: queued, sent, delivered, etc.")
    template: str = Field(description="Template slug used")
    to: str = Field(description="Recipient email address")
    queued_at: datetime = Field(description="Timestamp when email was queued")
    esp_message_id: str | None = Field(default=None, description="ESP provider message ID")


# --- Campaign Models ---


class TagFilter(BaseModel):
    """Tag-based recipient filter for campaigns."""

    include_tags: list[str] = Field(default_factory=list, description="Tag IDs to include")
    exclude_tags: list[str] = Field(default_factory=list, description="Tag IDs to exclude")
    match: str = Field(default="any", description="Match mode: 'any' or 'all'")


class CampaignStats(BaseModel):
    """Campaign sending statistics."""

    model_config = ConfigDict(extra="forbid")

    total_recipients: int = Field(description="Total recipients")
    sent_count: int = Field(description="Successfully sent")
    failed_count: int = Field(description="Failed sends")
    pending_count: int = Field(description="Pending sends")
    send_progress: float = Field(description="Progress 0.0-1.0")


class Campaign(BaseModel):
    """A campaign for batch email sending."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Campaign UUID")
    name: str = Field(description="Campaign name")
    template_id: str = Field(description="Template UUID")
    tag_filter: dict[str, Any] | None = Field(
        default=None, description="Tag-based recipient filter"
    )
    status: str = Field(description="Status: draft, sending, sent, cancelled, failed")
    stats: CampaignStats | None = Field(default=None, description="Sending statistics")
    scheduled_at: datetime | None = Field(default=None, description="Scheduled send time")
    started_at: datetime | None = Field(default=None, description="Actual start time")
    completed_at: datetime | None = Field(default=None, description="Completion time")
    created_at: datetime = Field(description="Creation timestamp")
    updated_at: datetime = Field(description="Last update timestamp")


class CampaignCreate(BaseModel):
    """Request model for creating a campaign."""

    name: str = Field(description="Campaign name")
    template_id: str = Field(description="Template UUID to use")
    tag_filter: TagFilter | None = Field(default=None, description="Recipient filter")


class CampaignUpdate(BaseModel):
    """Request model for updating a campaign."""

    name: str | None = Field(default=None, description="New campaign name")
    template_id: str | None = Field(default=None, description="New template UUID")
    tag_filter: TagFilter | None = Field(default=None, description="New recipient filter")


class CampaignSendResponse(BaseModel):
    """Response after triggering campaign send."""

    model_config = ConfigDict(extra="forbid")

    campaign_id: str = Field(description="Campaign UUID")
    status: str = Field(description="Campaign status after send")
    total_recipients: int = Field(description="Number of recipients")
    message: str = Field(description="Status message")


class RecipientCountResponse(BaseModel):
    """Response for recipient count query."""

    model_config = ConfigDict(extra="forbid")

    count: int = Field(description="Number of matching recipients")


# --- Email Trigger Models ---


class EmailTrigger(BaseModel):
    """An event-based email trigger."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Trigger UUID")
    event_type: str = Field(description="Event type (e.g., subscriber.created)")
    template_id: str = Field(description="Template UUID to send")
    description: str | None = Field(default=None, description="Trigger description")
    is_active: bool = Field(default=True, description="Whether trigger is active")
    created_at: datetime = Field(description="Creation timestamp")
    updated_at: datetime = Field(description="Last update timestamp")


class TriggerCreate(BaseModel):
    """Request model for creating a trigger."""

    event_type: str = Field(description="Event type to trigger on")
    template_id: str = Field(description="Template UUID to send")
    description: str | None = Field(default=None, description="Description")
    is_active: bool = Field(default=True, description="Whether active immediately")


class TriggerUpdate(BaseModel):
    """Request model for updating a trigger."""

    event_type: str | None = Field(default=None, description="New event type")
    template_id: str | None = Field(default=None, description="New template UUID")
    description: str | None = Field(default=None, description="New description")
    is_active: bool | None = Field(default=None, description="New active state")


# --- Webhook Extension Models ---


class WebhookDelivery(BaseModel):
    """A webhook delivery record."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Delivery UUID")
    endpoint_id: str = Field(description="Webhook endpoint UUID")
    event_id: str = Field(description="Event identifier")
    event_type: str = Field(description="Event type")
    status: str = Field(description="Status: pending, delivered, failed, retrying")
    attempt_count: int = Field(description="Number of delivery attempts")
    response_status_code: int | None = Field(default=None, description="HTTP response code")
    response_time_ms: int | None = Field(default=None, description="Response time in ms")
    error_message: str | None = Field(default=None, description="Error message if failed")
    created_at: datetime = Field(description="Creation timestamp")
    delivered_at: datetime | None = Field(default=None, description="Delivery timestamp")
    next_retry_at: datetime | None = Field(default=None, description="Next retry time")


class WebhookDeliveryDetail(WebhookDelivery):
    """Detailed webhook delivery with payload."""

    payload: dict[str, Any] = Field(description="Event payload sent")
    response_body: str | None = Field(default=None, description="Response body")


class WebhookDeliveryStats(BaseModel):
    """Webhook delivery statistics."""

    model_config = ConfigDict(extra="forbid")

    total_deliveries: int = Field(description="Total deliveries")
    successful_deliveries: int = Field(description="Successful deliveries")
    failed_deliveries: int = Field(description="Failed deliveries")
    pending_deliveries: int = Field(description="Pending deliveries")
    success_rate: float = Field(description="Success rate as percentage")
    avg_response_time_ms: float | None = Field(default=None, description="Avg response time")


class WebhookUpdate(BaseModel):
    """Request model for updating a webhook endpoint."""

    url: str | None = Field(default=None, description="New URL")
    description: str | None = Field(default=None, description="New description")
    events: list[str] | None = Field(default=None, description="New event types")
    is_active: bool | None = Field(default=None, description="New active state")


# --- Subscriber Note Models ---


class SubscriberNote(BaseModel):
    """A note associated with a subscriber."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(description="Note UUID")
    subscriber_id: str = Field(description="Subscriber UUID")
    content: str = Field(description="Note content")
    source: str = Field(description="Note source: contact_form, admin, api, system")
    subject: str | None = Field(default=None, description="Optional subject line")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Custom metadata")
    created_at: datetime = Field(description="Creation timestamp")
    updated_at: datetime = Field(description="Last update timestamp")


class NoteCreate(BaseModel):
    """Request model for creating a note."""

    content: str = Field(description="Note content")
    source: str = Field(default="api", description="Note source")
    subject: str | None = Field(default=None, description="Optional subject line")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Custom metadata")


class NoteUpdate(BaseModel):
    """Request model for updating a note."""

    content: str | None = Field(default=None, description="Updated content")
    subject: str | None = Field(default=None, description="Updated subject")
    metadata: dict[str, Any] | None = Field(default=None, description="Updated metadata")


# --- Preference Center Models ---


class PreferenceCenterInfo(BaseModel):
    """Subscriber preferences and available tags."""

    model_config = ConfigDict(extra="forbid")

    subscriber: dict[str, Any] = Field(description="Subscriber public info")
    subscribed_tags: list[dict[str, Any]] = Field(
        default_factory=list, description="Subscribed tags"
    )
    available_tags: list[dict[str, Any]] = Field(
        default_factory=list, description="Available public tags"
    )
    data_stored: dict[str, Any] = Field(default_factory=dict, description="DSGVO data transparency")


class TagSubscriptionResult(BaseModel):
    """Result of a tag subscription change."""

    model_config = ConfigDict(extra="forbid")

    success: bool = Field(description="Whether the operation succeeded")
    tag_id: str = Field(description="Tag UUID")
    is_subscribed: bool = Field(description="Current subscription state")
    message: str = Field(description="Status message")


class DataExportResult(BaseModel):
    """DSGVO data export response."""

    model_config = ConfigDict(extra="forbid")

    subscriber: dict[str, Any] = Field(description="Subscriber info")
    subscribed_tags: list[dict[str, Any]] = Field(description="Tag subscriptions")
    subscription_history: list[dict[str, Any]] = Field(default_factory=list, description="History")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Custom metadata")
    audit_log: list[dict[str, Any]] = Field(default_factory=list, description="Audit trail")
    exported_at: datetime = Field(description="Export timestamp")


class AccountDeleteResult(BaseModel):
    """Account deletion result."""

    model_config = ConfigDict(extra="forbid")

    success: bool = Field(description="Whether deletion succeeded")
    message: str = Field(description="Status message")
    deleted_at: datetime = Field(description="Deletion timestamp")


# --- Billing Models ---


class SubscriptionInfo(BaseModel):
    """Current billing subscription information."""

    model_config = ConfigDict(extra="forbid")

    tier: str = Field(description="Plan tier (free, starter, pro, enterprise)")
    status: str = Field(description="Subscription status (active, trialing, past_due, canceled)")
    stripe_subscription_id: str | None = Field(default=None, description="Stripe subscription ID")
    current_period_end: datetime | None = Field(
        default=None, description="Current billing period end"
    )
    max_subscribers: int = Field(description="Maximum subscribers allowed")
    max_emails_per_month: int = Field(description="Maximum emails per month")
    max_campaigns_per_month: int | None = Field(
        default=None, description="Maximum campaigns per month (None = unlimited)"
    )
    emails_sent_this_month: int = Field(default=0, description="Emails sent this billing period")


class CheckoutSession(BaseModel):
    """Stripe checkout session response."""

    model_config = ConfigDict(extra="forbid")

    session_id: str = Field(description="Stripe checkout session ID")
    url: str = Field(description="Checkout URL to redirect the user to")


class PortalSession(BaseModel):
    """Stripe customer portal session response."""

    model_config = ConfigDict(extra="forbid")

    url: str = Field(description="Portal URL to redirect the user to")


class SyncResult(BaseModel):
    """Result of a manual subscription sync."""

    model_config = ConfigDict(extra="forbid")

    synced: bool = Field(description="Whether a sync was performed")
    tier: str = Field(description="Current tier after sync")
    status: str = Field(description="Current status after sync")
