# gpu-who

GPU process monitor — see who's using the GPU with full process details.

Like `nvidia-htop` but shows **everything**: working directory, full command, conda/venv environment, Docker container info, and per-user summary.

## Install

```bash
pip install gpu-who
```

## Usage

```bash
gpu                # one-shot display
gpu -w             # watch mode (refresh every 2s)
gpu -w -n 5        # watch mode, 5s interval
gpu --json         # JSON output for scripting
```

## What it shows

**Per GPU:** utilization bar, memory bar, power, temperature, fan speed

**Per process:**
- PID, user, GPU memory usage (bar + percentage)
- Running time (elapsed)
- Working directory (`cwd`) — correctly resolved even for Docker containers
- Full command line (shortened for readability)
- conda/venv environment name
- Docker container name + image (auto-detected)
- tmux/screen session indicator

**Summary:** per-user GPU memory totals

## Requirements

- Linux with NVIDIA GPU
- `nvidia-smi` in PATH
- Python 3.9+
- No pip dependencies (stdlib only)
- Optional: `docker` CLI (for container name resolution)
