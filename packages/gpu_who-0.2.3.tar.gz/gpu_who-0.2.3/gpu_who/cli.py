#!/usr/bin/env python3
"""
gpu-who: GPU process monitor
Shows who's using the GPU with full process details.
"""
from __future__ import annotations

import csv
import io
import os
import re
import shutil
import signal
import subprocess
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import psutil


# ── Terminal helpers ─────────────────────────────────────────────────────────

def _term_width() -> int:
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return 80


def _use_color() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    if not hasattr(sys.stdout, "isatty"):
        return False
    return sys.stdout.isatty()


_COLOR_ON = _use_color()


class C:
    RESET   = "\033[0m"
    BOLD    = "\033[1m"
    DIM     = "\033[2m"
    RED     = "\033[91m"
    GREEN   = "\033[92m"
    YELLOW  = "\033[93m"
    BLUE    = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN    = "\033[96m"
    WHITE   = "\033[97m"
    GREY    = "\033[90m"


def c(code: str, text: str) -> str:
    """Apply color only when supported."""
    if _COLOR_ON:
        return f"{code}{text}{C.RESET}"
    return text


def cb(text: str) -> str:
    """Bold."""
    return c(C.BOLD, text)


# ── Data models ──────────────────────────────────────────────────────────────

@dataclass
class GpuInfo:
    index: int
    uuid: str
    name: str
    mem_total: int      # MiB
    mem_used: int       # MiB
    mem_free: int       # MiB
    gpu_util: int       # %
    mem_util: int       # %
    temp: int           # °C
    power_draw: float   # W
    power_limit: float  # W
    fan_speed: int      # %


@dataclass
class ProcessInfo:
    pid: int
    gpu_index: int
    gpu_mem: int        # MiB
    user: str = ""
    cmd: str = ""
    cmd_short: str = ""
    cwd: str = ""
    elapsed: str = ""
    started: str = ""
    conda_env: str = ""
    venv: str = ""
    parent_info: str = ""
    container_name: str = ""
    container_image: str = ""
    cpu_percent: float = 0.0   # may exceed 100 on multi-core
    rss_bytes: int = 0          # resident set size


@dataclass
class SystemInfo:
    cpu_per_core: list[float] = field(default_factory=list)
    cpu_total: float = 0.0
    load_avg: tuple[float, float, float] = (0.0, 0.0, 0.0)
    mem_total: int = 0
    mem_used: int = 0
    mem_available: int = 0
    mem_percent: float = 0.0
    swap_total: int = 0
    swap_used: int = 0
    swap_percent: float = 0.0
    uptime_seconds: float = 0.0


# ── UI state + click regions (htop-style interactive watch mode) ─────────────

# Sort keys → (attribute, label displayed in column header)
SORT_KEYS = [
    ("gpu_index", "GPU"),
    ("pid", "PID"),
    ("user", "USER"),
    ("gpu_mem", "GPU MEM"),
    ("cpu_percent", "%CPU"),
    ("rss_bytes", "RES"),
    ("elapsed_sec", "ELAPSED"),
    ("cmd_short", "COMMAND"),
]


@dataclass
class UIState:
    filter_gpu: int | None = None   # None = all GPUs
    sort_key: str = "gpu_index"
    sort_desc: bool = False
    long: bool = False
    mode: str = "gpu"               # "gpu" | "cpu" | "mem" — what process list to show
    selected_pid: int | None = None # process selected via click/arrows
    kill_prompt: str | None = None  # transient status text shown in title line
    focus_procs: bool = False       # when True, hide cpu/mem/gpus and fill with procs


@dataclass
class ClickRegion:
    row_min: int        # 1-indexed terminal row, inclusive
    row_max: int        # inclusive
    col_min: int        # 1-indexed terminal col, inclusive
    col_max: int        # inclusive
    action: str         # e.g. "gpu:0", "sort:cpu_percent"


def _parse_etime(s: str) -> int:
    """Parse ps etime format: [DD-]HH:MM:SS or MM:SS. Returns seconds."""
    if not s:
        return 0
    try:
        days = 0
        if "-" in s:
            d, s = s.split("-", 1)
            days = int(d)
        parts = [int(p) for p in s.split(":")]
        if len(parts) == 3:
            h, m, sec = parts
        elif len(parts) == 2:
            h, m, sec = 0, parts[0], parts[1]
        else:
            h, m, sec = 0, 0, parts[0] if parts else 0
        return days * 86400 + h * 3600 + m * 60 + sec
    except (ValueError, IndexError):
        return 0


def sort_procs(procs: list[ProcessInfo], key: str, desc: bool) -> list[ProcessInfo]:
    """Sort processes by the given key. When sorting by GPU index, a secondary
    sort by GPU memory (largest first within each GPU) gives a more readable
    grouping."""
    def getter(p: ProcessInfo):
        if key == "gpu_index":
            # tuple so reverse=True gives (gpu_index desc, gpu_mem desc);
            # reverse=False gives (gpu_index asc, gpu_mem desc) — always
            # biggest-first within a GPU group.
            return (p.gpu_index, -p.gpu_mem)
        if key == "elapsed_sec":
            return _parse_etime(p.elapsed)
        if key == "cmd_short":
            return p.cmd_short.lower()
        if key == "user":
            return p.user.lower()
        return getattr(p, key, 0)
    return sorted(procs, key=getter, reverse=desc)


# ── nvidia-smi queries ──────────────────────────────────────────────────────

def query_gpus() -> list[GpuInfo]:
    result = subprocess.run(
        ["nvidia-smi",
         "--query-gpu=index,uuid,name,memory.total,memory.used,memory.free,"
         "utilization.gpu,utilization.memory,temperature.gpu,"
         "power.draw,power.limit,fan.speed",
         "--format=csv,noheader,nounits"],
        capture_output=True, text=True, timeout=10,
    )
    gpus = []
    for row in csv.reader(io.StringIO(result.stdout.strip())):
        if len(row) < 12:
            continue
        r = [v.strip() for v in row]
        gpus.append(GpuInfo(
            index=int(r[0]), uuid=r[1], name=r[2],
            mem_total=int(r[3]), mem_used=int(r[4]), mem_free=int(r[5]),
            gpu_util=_safe_int(r[6]), mem_util=_safe_int(r[7]),
            temp=_safe_int(r[8]),
            power_draw=_safe_float(r[9]), power_limit=_safe_float(r[10]),
            fan_speed=_safe_int(r[11]),
        ))
    return gpus


def query_processes() -> list[tuple[int, int, str]]:
    """Returns list of (pid, gpu_mem_mib, gpu_uuid)."""
    result = subprocess.run(
        ["nvidia-smi",
         "--query-compute-apps=pid,used_gpu_memory,gpu_uuid",
         "--format=csv,noheader,nounits"],
        capture_output=True, text=True, timeout=10,
    )
    procs = []
    for row in csv.reader(io.StringIO(result.stdout.strip())):
        if len(row) < 3:
            continue
        r = [v.strip() for v in row]
        procs.append((int(r[0]), int(r[1]), r[2]))
    return procs


# ── psutil sampling (system + per-process CPU%) ──────────────────────────────

_cpu_primed = False
_proc_cache: dict[int, psutil.Process] = {}


def _prime_and_sample(pids: list[int], sample_interval: float = 0.3) -> None:
    """First call primes psutil and sleeps so subsequent cpu_percent() calls
    return a real delta. On later calls this is a no-op — the time between
    watch-mode iterations serves as the sample window."""
    global _cpu_primed
    if _cpu_primed:
        # Still ensure new PIDs are primed.
        _ensure_proc_primed(pids)
        return
    psutil.cpu_percent(percpu=True)  # prime system
    _ensure_proc_primed(pids)
    time.sleep(sample_interval)
    _cpu_primed = True


def _ensure_proc_primed(pids: list[int]) -> None:
    for pid in pids:
        if pid in _proc_cache:
            continue
        try:
            p = psutil.Process(pid)
            p.cpu_percent()  # first call returns 0.0, primes the delta
            _proc_cache[pid] = p
        except (psutil.NoSuchProcess, psutil.AccessDenied, Exception):
            pass


def _cleanup_proc_cache(alive_pids: set[int]) -> None:
    for pid in list(_proc_cache.keys()):
        if pid not in alive_pids:
            _proc_cache.pop(pid, None)


def query_system() -> SystemInfo:
    cpu_per_core = psutil.cpu_percent(percpu=True)
    cpu_total = sum(cpu_per_core) / len(cpu_per_core) if cpu_per_core else 0.0
    vm = psutil.virtual_memory()
    sw = psutil.swap_memory()
    try:
        load = os.getloadavg()
    except (OSError, AttributeError):
        load = (0.0, 0.0, 0.0)
    try:
        uptime = time.time() - psutil.boot_time()
    except Exception:
        uptime = 0.0
    return SystemInfo(
        cpu_per_core=list(cpu_per_core),
        cpu_total=cpu_total,
        load_avg=tuple(load),
        mem_total=vm.total,
        mem_used=vm.used,
        mem_available=vm.available,
        mem_percent=vm.percent,
        swap_total=sw.total,
        swap_used=sw.used,
        swap_percent=sw.percent,
        uptime_seconds=uptime,
    )


def query_proc_metrics(pids: list[int]) -> dict[int, tuple[float, int]]:
    """Returns {pid: (cpu_percent, rss_bytes)} for alive PIDs."""
    out: dict[int, tuple[float, int]] = {}
    for pid in pids:
        p = _proc_cache.get(pid)
        if p is None:
            continue
        try:
            out[pid] = (p.cpu_percent(), p.memory_info().rss)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            out[pid] = (0.0, 0)
    return out


def _secs_to_etime(secs: float) -> str:
    """Format seconds as ps-style etime: [D-]HH:MM:SS or MM:SS."""
    secs = max(0, int(secs))
    d = secs // 86400
    h = (secs % 86400) // 3600
    m = (secs % 3600) // 60
    s = secs % 60
    if d > 0:
        return f"{d}-{h:02d}:{m:02d}:{s:02d}"
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def query_top_procs(sort_key: str, limit: int = 50) -> list[ProcessInfo]:
    """Iterate all system processes and return top N by the given sort key
    (either 'cpu_percent' or 'rss_bytes'). Uses the same psutil Process cache
    as GPU procs so cpu_percent deltas remain accurate across iterations.
    First-seen PIDs report 0% CPU until the next call."""
    rows: list[tuple[float, int, int, psutil.Process]] = []

    for p in psutil.process_iter():
        try:
            pid = p.pid
            if pid not in _proc_cache:
                _proc_cache[pid] = p
                try:
                    p.cpu_percent()  # prime, returns 0
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                cpu_pct = 0.0
            else:
                try:
                    cpu_pct = _proc_cache[pid].cpu_percent()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            try:
                mem = p.memory_info().rss
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            rows.append((cpu_pct, mem, pid, p))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    # Drop processes that contribute nothing interesting for the current metric:
    # idle procs in CPU mode, tiny procs in mem mode.
    if sort_key == "cpu_percent":
        rows = [r for r in rows if r[0] >= 0.5]
    else:
        rows = [r for r in rows if r[1] >= 20 * 1024 * 1024]  # >= 20 MiB RSS

    if sort_key == "rss_bytes":
        rows.sort(key=lambda x: -x[1])
    else:
        rows.sort(key=lambda x: -x[0])

    now_ts = time.time()
    infos: list[ProcessInfo] = []
    for cpu_pct, mem, pid, p in rows[:limit]:
        try:
            with p.oneshot():
                user = p.username() or ""
                try:
                    cmdline = p.cmdline()
                    cmd = " ".join(cmdline) if cmdline else p.name()
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    cmd = p.name() if False else ""
                try:
                    create_time = p.create_time()
                    elapsed = _secs_to_etime(now_ts - create_time)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    elapsed = ""
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

        infos.append(ProcessInfo(
            pid=pid,
            gpu_index=-1,
            gpu_mem=0,
            user=user,
            cmd=cmd,
            cmd_short=_shorten_cmd(cmd) if cmd else "",
            cwd="",
            elapsed=elapsed,
            cpu_percent=cpu_pct,
            rss_bytes=mem,
        ))
    return infos


def _fmt_bytes(b: int) -> str:
    for unit, div in (("TiB", 1024 ** 4), ("GiB", 1024 ** 3),
                      ("MiB", 1024 ** 2), ("KiB", 1024)):
        if b >= div:
            return f"{b / div:.1f} {unit}"
    return f"{b} B"


def _fmt_bytes_compact(b: int) -> str:
    """Compact form for tight columns: '1.2G', '234M', '12K'."""
    if b >= 1024 ** 3:
        return f"{b / 1024 ** 3:.1f}G"
    if b >= 1024 ** 2:
        return f"{b / 1024 ** 2:.0f}M"
    if b >= 1024:
        return f"{b / 1024:.0f}K"
    return f"{b}B"


def _fmt_mib(mib: int) -> str:
    """Compact VRAM display: '7.5G' / '24G' / '512M'."""
    if mib >= 1024:
        return f"{mib / 1024:.1f}G"
    return f"{mib}M"


def _fmt_uptime(secs: float) -> str:
    d = int(secs // 86400)
    h = int((secs % 86400) // 3600)
    m = int((secs % 3600) // 60)
    if d > 0:
        return f"{d}d {h}h"
    if h > 0:
        return f"{h}h {m}m"
    return f"{m}m"


# ── Docker container detection ───────────────────────────────────────────────

_container_cache: dict[str, dict] = {}
_has_docker: bool | None = None


def _docker_available() -> bool:
    global _has_docker
    if _has_docker is None:
        _has_docker = shutil.which("docker") is not None
    return _has_docker


def _detect_container(pid: int) -> str | None:
    """Detect if PID runs inside a Docker/Podman container. Returns container ID or None."""
    try:
        cgroup = Path(f"/proc/{pid}/cgroup").read_text()
        # cgroup v2: docker-<id>.scope  (systemd slice)
        m = re.search(r'docker-([a-f0-9]{12,64})\.scope', cgroup)
        if m:
            return m.group(1)[:12]
        # cgroup v1: /docker/<id>
        m = re.search(r'/docker/([a-f0-9]{12,64})', cgroup)
        if m:
            return m.group(1)[:12]
        # containerd / k8s: /cri-containerd-<id>
        m = re.search(r'cri-containerd-([a-f0-9]{12,64})', cgroup)
        if m:
            return m.group(1)[:12]
        # podman
        m = re.search(r'/libpod-([a-f0-9]{12,64})', cgroup)
        if m:
            return m.group(1)[:12]
    except Exception:
        pass
    return None


def _get_container_info(container_id: str) -> dict:
    """Get container name, image, and overlay MergedDir via docker inspect."""
    if container_id in _container_cache:
        return _container_cache[container_id]

    info: dict = {"name": container_id, "image": "", "merged_dir": "", "working_dir": ""}

    if not _docker_available():
        _container_cache[container_id] = info
        return info

    try:
        result = subprocess.run(
            ["docker", "inspect", "--format",
             "{{.Name}}|{{.GraphDriver.Data.MergedDir}}|{{.Config.Image}}|{{.Config.WorkingDir}}",
             container_id],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split("|")
            if len(parts) >= 1 and parts[0]:
                info["name"] = parts[0].lstrip("/")
            if len(parts) >= 2:
                info["merged_dir"] = parts[1]
            if len(parts) >= 3:
                info["image"] = parts[2]
            if len(parts) >= 4:
                info["working_dir"] = parts[3]
    except Exception:
        pass

    _container_cache[container_id] = info
    return info


def _container_cwd(pid: int, container_id: str, cinfo: dict) -> str:
    """Get the container-internal cwd for a process, trying multiple methods."""
    # Method 1: readlink from host — may get overlay path or may fail (permission)
    try:
        host_cwd = os.readlink(f"/proc/{pid}/cwd")
        merged = cinfo.get("merged_dir", "")
        if merged and host_cwd.startswith(merged):
            return host_cwd[len(merged):] or "/"
        return host_cwd
    except PermissionError:
        pass
    except Exception:
        return "(unknown)"

    # Method 2: nsenter into mount namespace (works when running as root)
    try:
        result = subprocess.run(
            ["nsenter", "-m", "-t", str(pid), "readlink", f"/proc/{pid}/cwd"],
            capture_output=True, text=True, timeout=3,
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except Exception:
        pass

    # Method 3: fallback to container's configured WorkingDir
    wd = cinfo.get("working_dir", "")
    if wd:
        return wd

    return "(container — cwd not accessible)"


# ── Process detail gathering ─────────────────────────────────────────────────

def _detect_parent_session(pid: int) -> str:
    """Walk up process tree via /proc to find tmux/screen. No subprocess needed."""
    try:
        current = pid
        for _ in range(20):
            stat = Path(f"/proc/{current}/stat").read_text()
            comm_start = stat.index("(")
            comm_end = stat.rindex(")")
            comm = stat[comm_start + 1 : comm_end].lower()
            if "tmux" in comm:
                return "tmux"
            if "screen" in comm:
                return "screen"
            ppid = int(stat[comm_end + 2 :].split()[1])
            if ppid <= 1:
                break
            current = ppid
    except Exception:
        pass
    return ""


def get_process_info(pid: int, gpu_index: int, gpu_mem: int) -> ProcessInfo:
    p = ProcessInfo(pid=pid, gpu_index=gpu_index, gpu_mem=gpu_mem)

    # user, elapsed, start time
    try:
        ps_out = subprocess.run(
            ["ps", "-o", "user=,etime=,lstart=", "-p", str(pid)],
            capture_output=True, text=True, timeout=5,
        ).stdout.strip()
        if ps_out:
            parts = ps_out.split()
            if len(parts) >= 2:
                p.user = parts[0]
                p.elapsed = parts[1]
            if len(parts) >= 7:
                p.started = " ".join(parts[2:7])
    except Exception:
        pass

    # cmdline
    try:
        raw = Path(f"/proc/{pid}/cmdline").read_bytes()
        p.cmd = raw.replace(b'\x00', b' ').decode('utf-8', errors='replace').strip()
        p.cmd = re.sub(r'[\r\n\t]+', ' ', p.cmd)
        p.cmd_short = _shorten_cmd(p.cmd)
    except Exception:
        p.cmd = "(access denied)"
        p.cmd_short = p.cmd

    # cwd
    try:
        p.cwd = os.readlink(f"/proc/{pid}/cwd")
    except Exception:
        p.cwd = "(access denied)"

    # Docker container detection
    container_id = _detect_container(pid)
    if container_id:
        cinfo = _get_container_info(container_id)
        p.container_name = cinfo.get("name", container_id)
        p.container_image = cinfo.get("image", "")
        p.cwd = _container_cwd(pid, container_id, cinfo)

    # environment: conda, venv
    try:
        env_raw = Path(f"/proc/{pid}/environ").read_bytes()
        env_vars = env_raw.split(b'\x00')
        for var in env_vars:
            decoded = var.decode('utf-8', errors='replace')
            if decoded.startswith("CONDA_DEFAULT_ENV="):
                val = decoded.split("=", 1)[1]
                if val and val != "base":
                    p.conda_env = val
            elif decoded.startswith("VIRTUAL_ENV="):
                p.venv = decoded.split("=", 1)[1]
    except Exception:
        pass

    # parent tmux/screen session hint (walk /proc, no subprocess)
    p.parent_info = _detect_parent_session(pid)

    return p


def _shorten_cmd(cmd: str) -> str:
    cmd = re.sub(r'/home/([^/\s]+)', lambda m: '~', cmd)
    cmd = re.sub(r'\S+/bin/python[23]?\s', 'python ', cmd)
    # Collapse embedded newlines / tabs / CR into single spaces so
    # `python -c "line1\nline2"` style commands don't break the box layout.
    cmd = re.sub(r'[\r\n\t]+', ' ', cmd)
    return cmd


def _trunc(text: str, maxlen: int) -> str:
    if maxlen < 4:
        return text[:maxlen]
    if len(text) <= maxlen:
        return text
    return text[: maxlen - 3] + "..."


# ── Rendering primitives ─────────────────────────────────────────────────────

_ANSI_RE = re.compile(r'\x1b\[[0-9;]*m')


def _vlen(s: str) -> int:
    """Visible length — strips ANSI escape codes."""
    return len(_ANSI_RE.sub('', s))


def _ansi_truncate(s: str, max_visible: int, ellipsis: str = "…") -> str:
    """Truncate to `max_visible` visible chars while preserving ANSI escape
    codes. Without this, naive slicing strips color mid-sequence and causes
    the rest of the row (and subsequent rows) to lose formatting."""
    if _vlen(s) <= max_visible:
        return s
    target = max(0, max_visible - len(ellipsis))
    out: list[str] = []
    visible = 0
    i = 0
    n = len(s)
    while i < n:
        if s[i] == '\x1b':
            m = _ANSI_RE.match(s, i)
            if m:
                out.append(m.group(0))
                i = m.end()
                continue
        if visible >= target:
            break
        out.append(s[i])
        visible += 1
        i += 1
    out.append(ellipsis)
    if _COLOR_ON:
        out.append(C.RESET)
    return "".join(out)


def _rgb(r: int, g: int, b: int) -> str:
    return f"\033[38;2;{r};{g};{b}m"


# btop default-ish gradient stops: green → yellow → red
_GRAD_STOPS: list[tuple[float, tuple[int, int, int]]] = [
    (0.0, (0x50, 0xF0, 0x95)),
    (0.5, (0xF2, 0xE2, 0x60)),
    (1.0, (0xEE, 0x44, 0x45)),
]


def _grad_ansi(pct_0_100: float) -> str:
    """Return an ANSI truecolor escape for the given percentage on the
    green→yellow→red ramp, or empty string when color is disabled."""
    if not _COLOR_ON:
        return ""
    r, g, b = _grad_color(max(0.0, min(1.0, pct_0_100 / 100.0)))
    return _rgb(r, g, b)


def _reset() -> str:
    return C.RESET if _COLOR_ON else ""


def _grad_color(t: float) -> tuple[int, int, int]:
    t = max(0.0, min(1.0, t))
    for i in range(len(_GRAD_STOPS) - 1):
        t0, c0 = _GRAD_STOPS[i]
        t1, c1 = _GRAD_STOPS[i + 1]
        if t0 <= t <= t1:
            k = (t - t0) / (t1 - t0) if t1 > t0 else 0.0
            return (
                int(c0[0] + k * (c1[0] - c0[0])),
                int(c0[1] + k * (c1[1] - c0[1])),
                int(c0[2] + k * (c1[2] - c0[2])),
            )
    return _GRAD_STOPS[-1][1]


# Box border color (soft blue, like btop's panel accent)
_BORDER_RAW = "\033[38;2;90;130;200m"
# Empty bar cell color (dim slate)
_EMPTY_RAW = "\033[38;2;60;60;80m"
# Button background (for clickable box titles) — dim blue like the F-key footer
_BTN_BG_RAW = "\033[48;2;30;80;160m\033[38;2;255;255;255m\033[1m"
# Panel background — a very dark blue-gray so boxes read as sunken panels
# like btop's theme. Applied via post-process so existing fg/color rendering
# doesn't need to be touched.
_PANEL_BG_RAW = "\033[48;2;15;15;25m"


def _apply_row_bg(line: str, width: int, bg_raw: str) -> str:
    """Wrap an already-rendered line with a solid background color, and
    re-inject the bg after every RESET so fg color changes inside the line
    don't blow away the bg. Also pads with spaces (on bg) up to `width`."""
    if not _COLOR_ON:
        return line
    vlen = _vlen(line)
    pad = " " * max(0, width - vlen)
    with_bg = line.replace("\x1b[0m", f"\x1b[0m{bg_raw}")
    return f"{bg_raw}{with_bg}{pad}\x1b[0m"


def _apply_panel_bg(line: str, width: int) -> str:
    return _apply_row_bg(line, width, _PANEL_BG_RAW)


def _border(s: str) -> str:
    """Wrap border glyphs in soft-blue color when color is enabled."""
    if _COLOR_ON:
        return f"{_BORDER_RAW}{s}{C.RESET}"
    return s


def _btn(label: str) -> str:
    """Render text as a clickable-looking button (bold white on dim-blue bg).
    Falls back to plain bold when color is disabled."""
    if _COLOR_ON:
        return f"{_BTN_BG_RAW} {label} {C.RESET}"
    return f"[{label}]"


def bar(pct: float, width: int = 30) -> str:
    """btop-style gradient bar using slim ■ chars for filled cells and
    dim · for empty — looks lighter than solid █ blocks."""
    if not _COLOR_ON:
        filled = max(0, min(width, int(pct / 100 * width)))
        return "#" * filled + "-" * (width - filled)

    frac = max(0.0, min(1.0, pct / 100.0))
    full = round(frac * width)
    full = max(0, min(width, full))

    parts: list[str] = []
    denom = max(1, width - 1)
    for i in range(full):
        r, g, b = _grad_color(i / denom)
        parts.append(f"{_rgb(r, g, b)}■")

    empty = width - full
    if empty > 0:
        parts.append(_EMPTY_RAW + "·" * empty)
    parts.append(C.RESET)
    return "".join(parts)


# ── Box drawing ──────────────────────────────────────────────────────────────

def _box_top(title: str, width: int, subtitle: str = "",
             clickable: bool = False) -> str:
    """╭──┤ [title] ├────────── subtitle ──╮
    When clickable=True the title is rendered as a button (highlighted
    background) so users see it as a click target."""
    title_rendered = _btn(title) if clickable else f" {cb(title)} "
    prefix = f"{_border('╭──┤')}{title_rendered}{_border('├')}"
    if subtitle:
        suffix = f"{_border('┤')} {c(C.DIM, subtitle)} {_border('├──╮')}"
    else:
        suffix = _border("──╮")
    fill = width - _vlen(prefix) - _vlen(suffix)
    return prefix + _border("─" * max(0, fill)) + suffix


def _box_bottom(width: int) -> str:
    return _border("╰" + "─" * (width - 2) + "╯")


def _box_line(content: str, width: int) -> str:
    """│ content (padded to width-4) │"""
    inner = width - 4
    vlen = _vlen(content)
    if vlen > inner:
        content = _ansi_truncate(content, inner)
        vlen = _vlen(content)
    pad = inner - vlen
    return f"{_border('│')} {content}{' ' * pad} {_border('│')}"


# ── Boxed section renderers ──────────────────────────────────────────────────

def render_cpu_box(sysinfo: SystemInfo, W: int) -> list[str]:
    """CPU box: single usage bar + percent. 4 lines (one blank row to
    keep the height matched with the memory box for hstack alignment)."""
    lines: list[str] = []
    lines.append(_box_top("cpu", W, f"{sysinfo.cpu_total:.0f}%", clickable=True))
    inner_w = W - 4

    bar_w = max(8, inner_w - 8)
    pct_plain = f"{sysinfo.cpu_total:>5.1f}%"   # always 6 chars
    if _COLOR_ON:
        r, g, b = _grad_color(sysinfo.cpu_total / 100)
        pct_s = f"{_rgb(r, g, b)}{pct_plain}{C.RESET}"
    else:
        pct_s = pct_plain
    lines.append(_box_line(f"{bar(sysinfo.cpu_total, bar_w)}  {pct_s}", W))
    lines.append(_box_bottom(W))
    return lines


def render_mem_box(sysinfo: SystemInfo, W: int) -> list[str]:
    """Memory box: single Mem usage row. 3 lines — Swap moves to the subtitle."""
    lines: list[str] = []
    if sysinfo.swap_total > 0:
        subtitle = f"{sysinfo.mem_percent:.0f}%  ·  swap {sysinfo.swap_percent:.0f}%"
    else:
        subtitle = f"{sysinfo.mem_percent:.0f}%"
    lines.append(_box_top("memory", W, subtitle, clickable=True))
    inner_w = W - 4

    # Fixed budget: label(4) + "  " + "  " + mem_txt(16) + "  " + pct(4) = 30
    MEM_TXT_W = 16
    fixed = 4 + 2 + 2 + MEM_TXT_W + 2 + 4
    bar_w = max(6, inner_w - fixed)

    def _row(label: str, pct: float, used: int, total: int) -> str:
        used_s = f"{used / 1024 ** 3:.1f}G"
        total_s = f"{total / 1024 ** 3:.1f}G"
        mem_txt = f"{used_s} / {total_s}".rjust(MEM_TXT_W)
        return (
            f"{cb(label.ljust(4))}  {bar(pct, bar_w)}  "
            f"{mem_txt}  {c(C.DIM, f'{pct:>3.0f}%')}"
        )

    lines.append(_box_line(
        _row("Mem", sysinfo.mem_percent, sysinfo.mem_used, sysinfo.mem_total), W))
    lines.append(_box_bottom(W))
    return lines


def render_cpu_mem_compact(sysinfo: SystemInfo, W: int) -> list[str]:
    """Single-line compact CPU + Memory summaries without borders.
    Used on short terminals where boxed versions would push content off-screen.
    Returns exactly 2 lines (row 0 = cpu, row 1 = memory)."""
    reset = _reset()
    # CPU line: [cpu] NN.N%  bar  load a b c  up Xd Xh
    bar_w = max(10, W - 55)
    cpu_pct = sysinfo.cpu_total
    cpu_col = _grad_ansi(cpu_pct)
    load = sysinfo.load_avg
    cpu_line = (
        f" {_btn('cpu')}  {cpu_col}{cpu_pct:>5.1f}%{reset}  "
        f"{bar(cpu_pct, bar_w)}  "
        f"{c(C.DIM, f'load {load[0]:.2f} {load[1]:.2f} {load[2]:.2f}')}"
        f"  {c(C.DIM, f'up {_fmt_uptime(sysinfo.uptime_seconds)}')}"
    )

    # Memory line: [memory] NN.N%  bar  used/total [ swap N% ]
    mem_pct = sysinfo.mem_percent
    mem_col = _grad_ansi(mem_pct)
    mem_used_g = sysinfo.mem_used / 1024 ** 3
    mem_total_g = sysinfo.mem_total / 1024 ** 3
    mem_line = (
        f" {_btn('memory')}  {mem_col}{mem_pct:>5.1f}%{reset}  "
        f"{bar(mem_pct, bar_w)}  "
        f"{mem_used_g:>5.1f}G / {mem_total_g:<6.1f}G"
    )
    if sysinfo.swap_total > 0:
        sp = sysinfo.swap_percent
        sp_col = _grad_ansi(sp)
        mem_line += f"  {c(C.DIM, 'swap')} {sp_col}{sp:>3.0f}%{reset}"

    return [cpu_line, mem_line]


def _hstack(left: list[str], right: list[str], left_w: int, right_w: int) -> list[str]:
    """Place two pre-rendered boxes side by side. Pads shorter side with spaces
    so the right box lines up vertically."""
    n = max(len(left), len(right))
    out = []
    for i in range(n):
        l = left[i] if i < len(left) else " " * left_w
        r = right[i] if i < len(right) else " " * right_w
        out.append(l + r)
    return out


def _gpu_content_parts(gpu: GpuInfo) -> tuple[str, str, str, str, str, str, str]:
    """Return (util_pfx, util_sfx, vram_pfx, vram_sfx, power_s, temp_s, fan_s)
    as plain-text strings (no ANSI). All fields use fixed-width formatting so
    every GPU row renders to the same visible length — the right edge of each
    box lines up regardless of whether numbers are 1, 2, or 3 digits."""
    # VRAM: right-pad used to 6, left-pad total to 6 → always 13 chars ("used/total")
    vram_text = f"{_fmt_mib(gpu.mem_used):>6}/{_fmt_mib(gpu.mem_total):<6}"
    util_pfx = "Util: "
    util_sfx = f"  {gpu.gpu_util:>3}%"                # always 6 chars
    vram_pfx = "VRAM: "
    vram_sfx = f"  {vram_text}"                       # always 15 chars
    power_s = f"Power: {gpu.power_draw:>3.0f}/{gpu.power_limit:>3.0f}W"  # 15 chars
    temp_s = f"Temp: {gpu.temp:>3d}°C"                # 11 chars
    fan_s = f"Fan: {gpu.fan_speed:>3d}%" if gpu.fan_speed else ""
    return util_pfx, util_sfx, vram_pfx, vram_sfx, power_s, temp_s, fan_s


def _gpu_fixed_non_bar(gpu: GpuInfo, gap: str = "   ") -> int:
    util_pfx, util_sfx, vram_pfx, vram_sfx, power_s, temp_s, fan_s = _gpu_content_parts(gpu)
    meta_parts = [power_s, temp_s] + ([fan_s] if fan_s else [])
    meta_text = gap.join(meta_parts)
    return (
        len(util_pfx) + len(util_sfx) + len(gap)
        + len(vram_pfx) + len(vram_sfx) + len(gap)
        + len(meta_text)
    )


def _unified_bar_w(gpus: list[GpuInfo], inner_w: int) -> int:
    """Return a single bar_w that guarantees the widest GPU still fits.
    Using the SAME bar_w for every GPU keeps bars visually aligned."""
    if not gpus:
        return 10
    worst = max(_gpu_fixed_non_bar(g) for g in gpus)
    return max(3, (inner_w - worst) // 2)


def render_gpus_box(gpus: list[GpuInfo], W: int,
                    state: UIState | None = None,
                    show_separators: bool = False) -> list[str]:
    """Combined GPU box — one row per GPU inside a single outer box.
    Saves vertical space versus one-box-per-GPU and keeps all bars aligned."""
    lines: list[str] = []
    if not gpus:
        return lines

    # Build subtitle "N × <model>" when all GPUs share the same name,
    # otherwise just "N GPUs".
    names = {g.name for g in gpus}
    if len(names) == 1:
        short = next(iter(names)).replace("NVIDIA ", "").replace("GeForce ", "")
        subtitle = f"{len(gpus)} × {short}"
    else:
        subtitle = f"{len(gpus)} GPUs"
    lines.append(_box_top("gpus", W, subtitle, clickable=True))

    inner_w = W - 4
    # Column separator: dim vertical bar between sections, like btop's table.
    col_sep_raw = "│"
    gap = f" {col_sep_raw} "  # " │ " — 3 visible chars
    col_sep = c(C.DIM, col_sep_raw)
    gap_rendered = f" {col_sep} "
    # GPU index width: enough to hold the largest index
    idx_w = max(1, len(str(max(g.index for g in gpus))))
    # Prefix plain width: "GPU "(4) + idx(idx_w)
    prefix_w = 4 + idx_w

    # Unified bar_w across all rows so bars line up for comparison.
    # Row structure: prefix  gap  Util bar util_sfx  gap  VRAM bar vram_sfx  gap  meta_text
    max_fixed = 0
    for g in gpus:
        _, util_sfx, _, vram_sfx, power_s, temp_s, fan_s = _gpu_content_parts(g)
        meta_parts = [power_s, temp_s] + ([fan_s] if fan_s else [])
        meta_text = gap.join(meta_parts)
        fixed = (prefix_w + len(gap)
                 + len("Util: ") + len(util_sfx) + len(gap)
                 + len("VRAM: ") + len(vram_sfx) + len(gap)
                 + len(meta_text))
        max_fixed = max(max_fixed, fixed)
    bar_w = max(3, (inner_w - max_fixed) // 2)

    # Dotted separator line used between rows for vertical breathing room.
    sep_line = c(C.DIM, "┈" * inner_w)

    reset = _reset()
    for i, gpu in enumerate(gpus):
        _, util_sfx, _, vram_sfx, power_s, temp_s, fan_s = _gpu_content_parts(gpu)
        mem_pct = gpu.mem_used / gpu.mem_total * 100 if gpu.mem_total else 0
        power_pct = (gpu.power_draw / gpu.power_limit * 100) if gpu.power_limit else 0
        tc = C.RED if gpu.temp >= 85 else C.YELLOW if gpu.temp >= 70 else C.GREEN

        util_col = _grad_ansi(gpu.gpu_util)
        vram_col = _grad_ansi(mem_pct)
        power_col = _grad_ansi(power_pct)
        fan_col = _grad_ansi(gpu.fan_speed) if gpu.fan_speed else ""

        # GPU label — highlighted when this index is the active filter.
        filtered = state is not None and state.filter_gpu == gpu.index
        label_text = f"GPU {gpu.index:>{idx_w}}"
        idx_label = c(C.CYAN + C.BOLD, label_text) if filtered else cb(label_text)

        util_num = util_sfx[2:]     # "XXX%" (strip leading 2-space pad)
        vram_val = vram_sfx[2:]     # "XXX/YYY"

        util_part = f"{cb('Util:')} {bar(gpu.gpu_util, bar_w)}  {util_col}{util_num}{reset}"
        vram_part = f"{cb('VRAM:')} {bar(mem_pct, bar_w)}  {vram_col}{vram_val}{reset}"
        power_part = f"{cb('Power:')} {power_col}{power_s[len('Power: '):]}{reset}"
        temp_part = f"{cb('Temp:')} " + c(tc + C.BOLD, temp_s[len('Temp: '):])
        parts = [util_part, vram_part, power_part, temp_part]
        if fan_s:
            parts.append(f"{cb('Fan:')} {fan_col}{fan_s[len('Fan: '):]}{reset}")

        row = idx_label + gap_rendered + gap_rendered.join(parts)
        lines.append(_box_line(row, W))
        if show_separators and i < len(gpus) - 1:
            lines.append(_box_line(sep_line, W))

    lines.append(_box_bottom(W))
    return lines


# Process table column layout. (key, label, width, align).
# Widths include label visible chars only; separators are 2 spaces between cols.
_PROC_COLS_ALL = [
    # (key,         label,      width, align, modes)
    ("gpu_index",   "GPU",       3, "right", ("gpu",)),
    ("pid",         "PID",       7, "right", ("gpu", "cpu", "mem")),
    ("user",        "USER",      5, "left",  ("gpu", "cpu", "mem")),
    ("gpu_mem",     "GPU MEM",  10, "right", ("gpu",)),
    ("cpu_percent", "%CPU",      5, "right", ("cpu", "mem")),
    ("rss_bytes",   "RES",       6, "right", ("cpu", "mem")),
    ("elapsed_sec", "ELAPSED",  10, "right", ("gpu", "cpu", "mem")),
    ("cmd_short",   "COMMAND",   7, "left",  ("gpu", "cpu", "mem")),
]


def _proc_cols_for(mode: str) -> list[tuple[str, str, int, str]]:
    """Pick the visible column set for the current mode (gpu/cpu/mem)."""
    return [(k, l, w, a) for (k, l, w, a, modes) in _PROC_COLS_ALL if mode in modes]


# Back-compat alias used by older callers inside the file.
_PROC_COLS = _proc_cols_for("gpu")
_PROC_COL_GAP = 2
# Left-edge offset of content within each row (_box_line prefix: "│ " = 2 terminal cols before content)
_CONTENT_COL_OFFSET = 3  # 1-indexed terminal col where content[0] sits


def _proc_col_bounds(inner_w: int, mode: str = "gpu") -> list[tuple[int, int, str]]:
    """Return (content_col_start, content_col_end, sort_key) — 0-indexed, inclusive.
    Each column's click region includes the trailing gap; the last col
    (COMMAND) extends to the end of the inner content area."""
    cols = _proc_cols_for(mode)
    bounds = []
    offset = 0
    n = len(cols)
    for i, (key, _label, width, _align) in enumerate(cols):
        is_last = i == n - 1
        if is_last:
            end = max(offset, inner_w - 1)
        else:
            end = offset + width + _PROC_COL_GAP - 1
        bounds.append((offset, end, key))
        offset = end + 1
    return bounds


_SELECTED_BG_RAW = "\033[48;2;40;70;130m"   # row highlight for selected proc


def render_proc_box(all_procs: list[ProcessInfo], W: int,
                    state: UIState | None = None,
                    long: bool = False,
                    hidden_count: int = 0,
                    extra_cmd_rows: int = 0
                    ) -> tuple[list[str], list[tuple[int, int, int]]]:
    """Returns (lines, proc_rows) where proc_rows is a list of
    (local_line_start, local_line_end, pid) — indices into `lines` for
    the row(s) belonging to each rendered process.

    `extra_cmd_rows`: in non-long mode, allow each proc to wrap the command
    up to this many extra rows (distributed from spare vertical space) so the
    display fills the terminal uniformly instead of leaving a big empty gap."""
    lines: list[str] = []
    subtitle_count = f"{len(all_procs)} proc" + ("" if len(all_procs) == 1 else "s") \
        if all_procs else "none"
    mode_label = ""
    if state is not None and state.mode != "gpu":
        metric = {"cpu": "by CPU", "mem": "by MEM"}.get(state.mode, state.mode)
        mode_label = f"  ·  {metric}  ·  click to reset ◀"
    subtitle = subtitle_count + mode_label
    lines.append(_box_top("processes", W, subtitle, clickable=True))

    proc_rows: list[tuple[int, int, int]] = []
    if not all_procs:
        lines.append(_box_line(c(C.DIM, "no GPU processes"), W))
        lines.append(_box_bottom(W))
        return lines, proc_rows

    inner_w = W - 4
    active_key = state.sort_key if state else None
    mode = state.mode if state else "gpu"
    cols = _proc_cols_for(mode)

    # Header: underline only the label glyphs (not padding) so it reads as
    # a link. Active sort column additionally gets cyan highlight.
    UL = "\033[4m"
    hdr_segs = []
    for key, label, width, align in cols:
        color = (C.CYAN + C.BOLD + UL) if key == active_key else (C.BOLD + UL)
        colored = c(color, label)
        pad_n = width - len(label)
        seg = (" " * pad_n + colored) if align == "right" else (colored + " " * pad_n)
        hdr_segs.append(seg)
    hdr = (" " * _PROC_COL_GAP).join(hdr_segs)
    lines.append(_box_line(hdr, W))

    # CMD_COL is the sum of all cols before COMMAND plus gaps
    CMD_COL = 0
    for i, (_k, _l, width, _a) in enumerate(cols):
        if i == len(cols) - 1:
            break
        CMD_COL += width + _PROC_COL_GAP

    cmd_width = max(20, inner_w - CMD_COL)
    selected_pid = state.selected_pid if state else None

    for proc in all_procs:
        proc_start_line = len(lines)
        is_selected = proc.pid == selected_pid
        user_color = _user_color(proc.user)

        cpu_raw = f"{proc.cpu_percent:.0f}" if proc.cpu_percent >= 100 else f"{proc.cpu_percent:.1f}"
        cpu_color = (
            C.RED if proc.cpu_percent >= 200
            else C.YELLOW if proc.cpu_percent >= 50
            else C.GREEN if proc.cpu_percent >= 10
            else C.DIM
        )

        # Build each cell's value based on which cols are active for this mode
        cell: dict[str, str] = {
            "gpu_index":  c(C.WHITE,  f"{proc.gpu_index:>3}" if proc.gpu_index >= 0 else f"{'-':>3}"),
            "pid":        c(C.YELLOW, f"{proc.pid:>7}"),
            "user":       c(user_color, _trunc(proc.user, 5).ljust(5)),
            "gpu_mem":    (f"{proc.gpu_mem:>6,} MiB" if proc.gpu_mem > 0 else f"{'-':>10}"),
            "cpu_percent": c(cpu_color, f"{cpu_raw:>5}"),
            "rss_bytes":  (f"{_fmt_bytes_compact(proc.rss_bytes):>6}" if proc.rss_bytes else f"{'-':>6}"),
            "elapsed_sec": f"{proc.elapsed:>10}",
        }
        # COMMAND column is rendered after prefix, so assemble all non-COMMAND.
        prefix_cells = [cell[k] for (k, _l, _w, _a) in cols if k != "cmd_short"]
        prefix = ("  " * 0) + ("  ").join(prefix_cells) + "  "

        # Build the inline meta (cwd + badges) once — we may append it after
        # the command on the same row to keep each proc compact, instead of
        # burning a whole second row on it.
        meta_parts_colored: list[str] = []
        cwd_disp = proc.cwd.replace(f"/home/{proc.user}", "~") if proc.cwd else ""
        if cwd_disp:
            meta_parts_colored.append(c(C.CYAN, cwd_disp))
        if proc.container_name:
            docker_label = proc.container_name
            if proc.container_image:
                docker_label += f"({proc.container_image})"
            meta_parts_colored.append(c(C.RED, f"[{docker_label}]"))
        if proc.conda_env:
            meta_parts_colored.append(c(C.GREEN, f"[{proc.conda_env}]"))
        if proc.venv:
            meta_parts_colored.append(c(C.MAGENTA, f"[{os.path.basename(proc.venv)}]"))
        if proc.parent_info:
            meta_parts_colored.append(c(C.BLUE, f"[{proc.parent_info}]"))
        meta_inline = " ".join(meta_parts_colored) if meta_parts_colored else ""
        meta_vlen = _vlen(meta_inline)

        cmd_text = proc.cmd_short or ""
        # First-row cmd width (reduced if inline meta is appended on row 1).
        sep = "  ·  "
        if meta_inline:
            cmd_width_first = max(15, cmd_width - meta_vlen - len(sep))
        else:
            cmd_width_first = cmd_width

        if long and cmd_text and len(cmd_text) > cmd_width:
            # Long mode — wrap the full command, meta on its own row at end.
            first = cmd_text[:cmd_width]
            lines.append(_box_line(prefix + first, W))
            remaining = cmd_text[cmd_width:]
            cont_indent = " " * CMD_COL
            while remaining:
                chunk = remaining[:cmd_width]
                remaining = remaining[cmd_width:]
                lines.append(_box_line(cont_indent + chunk, W))
            if meta_inline:
                lines.append(_box_line(cont_indent + meta_inline, W))
        elif extra_cmd_rows > 0 and cmd_text and len(cmd_text) > cmd_width_first:
            # Compact + spare rows: meta stays inline on row 1, cmd wraps into
            # `extra_cmd_rows` continuation rows under the COMMAND column so
            # the proc box fills vertical space without wasting rows.
            first = cmd_text[:cmd_width_first]
            row1 = prefix + first
            if meta_inline:
                row1 += c(C.DIM, sep) + meta_inline
            lines.append(_box_line(row1, W))
            remaining = cmd_text[cmd_width_first:]
            cont_indent = " " * CMD_COL
            cont_emitted = 0
            while remaining and cont_emitted < extra_cmd_rows:
                chunk = remaining[:cmd_width]
                remaining = remaining[cmd_width:]
                cont_emitted += 1
                if remaining and cont_emitted == extra_cmd_rows:
                    chunk = (chunk[:-1] + "…") if len(chunk) > 1 else "…"
                lines.append(_box_line(cont_indent + chunk, W))
        else:
            # Compact (tight) — single row: cmd truncated + meta inline.
            if meta_inline:
                cmd_shown = cmd_text if len(cmd_text) <= cmd_width_first else (
                    cmd_text[:cmd_width_first - 1] + "…")
                content = f"{prefix}{cmd_shown}{c(C.DIM, sep)}{meta_inline}"
            else:
                cmd = cmd_text if long else _trunc(cmd_text, cmd_width)
                content = prefix + cmd
            lines.append(_box_line(content, W))

        # Record the line range this proc occupies for click + highlight mapping.
        proc_rows.append((proc_start_line, len(lines) - 1, proc.pid))

    if hidden_count > 0:
        lines.append(_box_line(
            c(C.DIM, f"…  ({hidden_count} more hidden)"), W))

    lines.append(_box_bottom(W))
    return lines, proc_rows


_USER_COLORS: dict[str, str] = {}
_COLOR_POOL = [C.CYAN, C.GREEN, C.MAGENTA, C.BLUE, C.YELLOW]


def _user_color(user: str) -> str:
    if user not in _USER_COLORS:
        _USER_COLORS[user] = _COLOR_POOL[len(_USER_COLORS) % len(_COLOR_POOL)]
    return _USER_COLORS[user]


# ── Main display ─────────────────────────────────────────────────────────────

def render_footer(state: UIState, W: int, num_procs: int) -> str:
    """htop-style function-key hint bar."""
    keys = [
        ("F5", "Sort"),
        ("F6", "GPU"),
        ("F10", "Quit"),
    ]
    left_parts = []
    for k, label in keys:
        left_parts.append(
            c(C.BLACK if False else C.WHITE + C.BOLD, k)
            + c("\033[48;2;30;110;200m" + C.WHITE, f" {label} ")
            + C.RESET
        )
    left = " ".join(left_parts) if _COLOR_ON else "  ".join(f"{k} {l}" for k, l in keys)

    # Right side: state summary
    sort_label = next((lbl for k, lbl, *_ in _PROC_COLS if k == state.sort_key), state.sort_key)
    arrow = "↓" if state.sort_desc else "↑"
    gpu_label = "all" if state.filter_gpu is None else str(state.filter_gpu)
    info = (
        f"sort {c(C.CYAN + C.BOLD, sort_label + arrow)}   "
        f"gpu {c(C.CYAN + C.BOLD, gpu_label)}   "
        f"procs {c(C.CYAN + C.BOLD, str(num_procs))}"
    )

    pad = max(1, W - _vlen(left) - _vlen(info) - 2)
    return f" {left}{' ' * pad}{info} "


def _term_height() -> int:
    try:
        return shutil.get_terminal_size().lines
    except Exception:
        return 24


def render_all(state: UIState | None = None) -> tuple[str, list[ClickRegion]]:
    if state is None:
        state = UIState()
    _container_cache.clear()
    W = _term_width()
    H = _term_height()

    gpus = query_gpus()
    raw_procs = query_processes()
    pids = [pid for pid, _, _ in raw_procs]

    _prime_and_sample(pids)
    sysinfo = query_system()
    proc_metrics = query_proc_metrics(pids)
    _cleanup_proc_cache(set(pids))

    uuid_to_gpu = {g.uuid: g for g in gpus}

    procs: list[ProcessInfo] = []
    for pid, gpu_mem, gpu_uuid in raw_procs:
        gpu = uuid_to_gpu.get(gpu_uuid)
        gpu_idx = gpu.index if gpu else -1
        p = get_process_info(pid, gpu_idx, gpu_mem)
        cpu_pct, rss = proc_metrics.get(pid, (0.0, 0))
        p.cpu_percent = cpu_pct
        p.rss_bytes = rss
        procs.append(p)

    procs_by_gpu: dict[int, list[ProcessInfo]] = {}
    for p in procs:
        procs_by_gpu.setdefault(p.gpu_index, []).append(p)

    regions: list[ClickRegion] = []
    lines: list[str] = []
    lines.append(f" {cb('gpu-who')}   {c(C.DIM, datetime.now().strftime('%Y-%m-%d %H:%M:%S'))}")

    # Adaptive layout — priorities when the terminal is short:
    #   1. GPU util + VRAM (gpus box)   ← MUST show
    #   2. CPU + Memory                 ← MUST show (compact if needed)
    #   3. Processes                    ← drop first when space is tight
    n_gpus = len(gpus)
    # When W < 100 the boxed cpu/mem stacks vertically (2 × 4 rows = 8)
    # instead of rendering side by side (4 rows). Compact form is always 2.
    stacked_cpumem = W < 80

    def _cpumem_rows(compact: bool) -> int:
        if compact:
            return 2
        return 6 if stacked_cpumem else 3

    def _gpus_rows(with_sep: bool) -> int:
        if n_gpus == 0:
            return 0
        return (2 * n_gpus + 1) if with_sep else (n_gpus + 2)

    # Core overhead (always present): title line only = 1 row.
    BASE_CORE = 1
    # Proc section cost (when shown): box top + header + bottom = 3 rows,
    # plus actual proc rows.
    PROC_SECTION = 3

    # GPU separators are off by default (they waste vertical space and the
    # `│` in-row separators already delineate columns). Compact CPU/Mem is
    # only enabled when space is tight.
    cfg = None
    for compact in (False, True):
        fixed = BASE_CORE + _cpumem_rows(compact) + _gpus_rows(False) + PROC_SECTION
        if fixed + 1 <= H:
            cfg = (False, compact, True)
            break
    if cfg is None:
        for compact in (False, True):
            fixed = BASE_CORE + _cpumem_rows(compact) + _gpus_rows(False)
            if fixed <= H:
                cfg = (False, compact, False)
                break
    if cfg is None:
        cfg = (False, True, False)
    gpu_separators, compact_cpumem, show_procs = cfg

    # Focused-procs mode: skip CPU/Mem + GPUs so the process table owns the
    # entire terminal. Reset show_procs to True since we definitely want procs.
    if state.focus_procs:
        show_procs = True

    # Render CPU + memory (unless focused on procs)
    if state.focus_procs:
        pass
    elif compact_cpumem:
        cpu_row = len(lines) + 1
        lines.extend(render_cpu_mem_compact(sysinfo, W))
        regions.append(ClickRegion(cpu_row, cpu_row, 1, W, "mode:cpu"))
        regions.append(ClickRegion(cpu_row + 1, cpu_row + 1, 1, W, "mode:mem"))
    else:
        cpu_mem_row_start = len(lines) + 1
        if W >= 80:
            W_left = W // 2
            W_right = W - W_left
            lines.extend(_hstack(
                render_cpu_box(sysinfo, W_left),
                render_mem_box(sysinfo, W_right),
                W_left, W_right,
            ))
            cpu_mem_row_end = len(lines)
            regions.append(ClickRegion(
                cpu_mem_row_start, cpu_mem_row_end, 1, W_left, "mode:cpu"))
            regions.append(ClickRegion(
                cpu_mem_row_start, cpu_mem_row_end, W_left + 1, W, "mode:mem"))
        else:
            cpu_start = len(lines) + 1
            lines.extend(render_cpu_box(sysinfo, W))
            regions.append(ClickRegion(cpu_start, len(lines), 1, W, "mode:cpu"))
            mem_start = len(lines) + 1
            lines.extend(render_mem_box(sysinfo, W))
            regions.append(ClickRegion(mem_start, len(lines), 1, W, "mode:mem"))

    # GPUs — combined box, clickable to reset mode (skip when focused on procs)
    if gpus and not state.focus_procs:
        gpus_start = len(lines) + 1
        lines.extend(render_gpus_box(
            gpus, W, state=state, show_separators=gpu_separators))
        gpus_end = len(lines)
        regions.append(ClickRegion(gpus_start, gpus_end, 1, W, "mode:gpu"))

    # Proc section only renders if the adaptive tier picked show_procs=True.
    # When skipped (short terminal), CPU/Mem + GPUs get all the space.
    if show_procs:
        hint_rows = 1 if state.selected_pid is not None else 0
        if state.focus_procs:
            used = BASE_CORE + PROC_SECTION + hint_rows
        else:
            gpu_rows = _gpus_rows(gpu_separators)
            used = BASE_CORE + _cpumem_rows(compact_cpumem) + gpu_rows + PROC_SECTION + hint_rows
        max_proc_rows = max(1, H - used)
        # Compact mode (default) = 1 row per proc; long mode reserves ~2 rows
        # (cmd wrap + meta on own row).
        if state.long:
            max_procs = max(1, max_proc_rows // 2)
        else:
            max_procs = max(1, max_proc_rows)

        # Build the full pre-trim list first so we can report how many were
        # hidden by the dynamic row limit.
        if state.mode == "cpu":
            full = query_top_procs("cpu_percent", limit=max(max_procs, 64))
        elif state.mode == "mem":
            full = query_top_procs("rss_bytes", limit=max(max_procs, 64))
        else:
            full = procs
            if state.filter_gpu is not None:
                full = [p for p in full if p.gpu_index == state.filter_gpu]
            full = sort_procs(full, state.sort_key, state.sort_desc)
        visible = full[:max_procs]
        hidden_count = max(0, len(full) - len(visible))

        # Distribute spare vertical rows across procs as extra command-wrap
        # rows so the box fills the terminal evenly instead of leaving a
        # band of blank panel-bg below it.
        spare = max(0, max_proc_rows - len(visible) - (1 if hidden_count else 0))
        extra_cmd_rows = (spare // len(visible)) if visible and not state.long else 0

        proc_top_row = len(lines) + 1  # terminal row of box top (1-indexed)
        proc_base_line = len(lines)    # 0-indexed offset into `lines`
        proc_lines, proc_row_map = render_proc_box(
            visible, W, state=state, long=state.long,
            hidden_count=hidden_count, extra_cmd_rows=extra_cmd_rows)
        # Clicking "[processes]" title toggles focused view (hide cpu/mem/gpus
        # and dedicate the entire terminal to the process table).
        regions.append(ClickRegion(
            proc_top_row, proc_top_row, 1, W, "focus:procs"))
        lines.extend(proc_lines)

        # Per-proc click regions + selection-highlight row set.
        selected_rows: set[int] = set()
        for rel_s, rel_e, pid in proc_row_map:
            abs_s = proc_base_line + rel_s
            abs_e = proc_base_line + rel_e
            regions.append(ClickRegion(
                abs_s + 1, abs_e + 1, 1, W, f"select:{pid}"))
            if state.selected_pid == pid:
                for i in range(abs_s, abs_e + 1):
                    selected_rows.add(i)

        if visible:
            header_row = proc_top_row + 1
            for content_c1, content_c2, key in _proc_col_bounds(W - 4, mode=state.mode):
                t_c1 = content_c1 + _CONTENT_COL_OFFSET
                t_c2 = content_c2 + _CONTENT_COL_OFFSET
                regions.append(ClickRegion(
                    header_row, header_row, t_c1, t_c2, f"sort:{key}"))
    else:
        selected_rows = set()

    # Action hint line — only visible when a proc is selected.
    if state.selected_pid is not None and show_procs:
        hint_parts = [
            f"{_btn('k')} {c(C.DIM, 'Kill')}",
            f"{_btn('↑↓')} {c(C.DIM, 'Move')}",
            f"{_btn('Esc / ←')} {c(C.DIM, 'Deselect')}",
        ]
        hint_line = (
            f" {'  '.join(hint_parts)}   "
            f"{c(C.DIM, f'PID {state.selected_pid}')}"
        )
        lines.append(hint_line)

    # Apply btop-style dark panel bg to every row; the currently-selected
    # proc row (if any) gets a slightly brighter bg for highlight.
    if _COLOR_ON:
        lines = [
            _apply_row_bg(l, W,
                          _SELECTED_BG_RAW if i in selected_rows else _PANEL_BG_RAW)
            for i, l in enumerate(lines)
        ]

    return "\n".join(lines), regions


# ── Input parsing (mouse + keys) ─────────────────────────────────────────────

# xterm-style function-key escape sequences (subset we care about)
_ESC_KEYS = {
    b"\x1bOP":    "F1",
    b"\x1bOQ":    "F2",
    b"\x1bOR":    "F3",
    b"\x1bOS":    "F4",
    b"\x1b[15~":  "F5",
    b"\x1b[17~":  "F6",
    b"\x1b[18~":  "F7",
    b"\x1b[19~":  "F8",
    b"\x1b[20~":  "F9",
    b"\x1b[21~":  "F10",
    b"\x1b[A":    "UP",
    b"\x1b[B":    "DOWN",
    b"\x1b[C":    "RIGHT",
    b"\x1b[D":    "LEFT",
}
_MOUSE_SGR_RE = re.compile(rb"\x1b\[<(\d+);(\d+);(\d+)([Mm])")


def parse_input(buf: bytes) -> tuple[list[tuple], bytes]:
    """Decode terminal input buffer into events. Unconsumed bytes are returned
    for reuse. Events: ('key', name) or ('click', row, col)."""
    events: list[tuple] = []
    while buf:
        # SGR mouse: ESC [ < B ; Cx ; Cy M|m
        if buf.startswith(b"\x1b[<"):
            m = _MOUSE_SGR_RE.match(buf)
            if m:
                btn, col, row = int(m.group(1)), int(m.group(2)), int(m.group(3))
                pressed = m.group(4) == b"M"
                buf = buf[m.end():]
                # Only act on left-button press (btn 0, plain)
                if btn == 0 and pressed:
                    events.append(("click", row, col))
                continue
            break  # incomplete mouse sequence, wait for more
        # Known function/arrow key escape sequences
        if buf.startswith(b"\x1b"):
            matched = False
            for seq, name in _ESC_KEYS.items():
                if buf.startswith(seq):
                    events.append(("key", name))
                    buf = buf[len(seq):]
                    matched = True
                    break
            if matched:
                continue
            # unknown escape — drop ESC byte, loop
            if len(buf) == 1:
                break  # wait; might be start of longer sequence
            buf = buf[1:]
            continue
        # regular byte
        events.append(("key", chr(buf[0])))
        buf = buf[1:]
    return events, buf


def _cycle_sort(state: UIState) -> None:
    keys = [k for k, *_ in _PROC_COLS]
    try:
        idx = keys.index(state.sort_key)
    except ValueError:
        idx = -1
    state.sort_key = keys[(idx + 1) % len(keys)]


def _cycle_gpu_filter(state: UIState, gpu_indices: list[int]) -> None:
    order = [None] + gpu_indices
    try:
        idx = order.index(state.filter_gpu)
    except ValueError:
        idx = 0
    state.filter_gpu = order[(idx + 1) % len(order)]


def _move_selection(state: UIState, regions: list[ClickRegion], delta: int) -> None:
    """Move the selected proc up (delta=-1) or down (+1) based on the proc
    click regions emitted in the last render."""
    pids = [int(r.action.split(":")[1]) for r in regions
            if r.action.startswith("select:")]
    if not pids:
        return
    if state.selected_pid in pids:
        idx = (pids.index(state.selected_pid) + delta) % len(pids)
    else:
        idx = 0 if delta >= 0 else len(pids) - 1
    state.selected_pid = pids[idx]


def _kill_selected(state: UIState, fd: int, old_settings) -> None:
    """Try to kill the currently-selected PID. Falls back to sudo kill when
    the current user lacks permission — sudo will prompt for a password on
    the raw terminal, so we briefly suspend the TUI and restore it after."""
    pid = state.selected_pid
    if not pid:
        return
    try:
        os.kill(pid, signal.SIGTERM)
        return
    except ProcessLookupError:
        state.selected_pid = None
        return
    except PermissionError:
        pass  # fall through to sudo

    # Suspend TUI (restore terminal) so sudo can prompt for password normally.
    import termios
    import tty
    termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    sys.stdout.write("\x1b[?1000l\x1b[?1006l\x1b[?25h\x1b[2J\x1b[H")
    sys.stdout.flush()
    print(f"sudo kill {pid}  (enter your password if prompted)")
    try:
        subprocess.run(["sudo", "kill", str(pid)], check=False)
    except Exception as e:
        print(f"kill failed: {e}")
    time.sleep(0.3)
    # Re-enter TUI
    tty.setcbreak(fd)
    sys.stdout.write("\x1b[?25l\x1b[?1000h\x1b[?1006h")
    sys.stdout.flush()


def _apply_action(state: UIState, action: str) -> None:
    kind, _, arg = action.partition(":")
    if kind == "gpu":
        try:
            g = int(arg)
        except ValueError:
            return
        state.mode = "gpu"
        state.filter_gpu = None if state.filter_gpu == g else g
    elif kind == "sort":
        if state.sort_key == arg:
            state.sort_desc = not state.sort_desc
        else:
            state.sort_key = arg
            state.sort_desc = True
    elif kind == "mode":
        if arg == "cpu":
            state.mode = "cpu"
            state.sort_key = "cpu_percent"
            state.sort_desc = True
            state.focus_procs = False
        elif arg == "mem":
            state.mode = "mem"
            state.sort_key = "rss_bytes"
            state.sort_desc = True
            state.focus_procs = False
        elif arg == "gpu":
            state.mode = "gpu"
            state.filter_gpu = None
            state.focus_procs = False
    elif kind == "focus":
        if arg == "procs":
            state.focus_procs = not state.focus_procs
    elif kind == "select":
        try:
            state.selected_pid = int(arg)
        except ValueError:
            pass


def run_watch(interval: float, long: bool = False):
    state = UIState(long=long)
    interactive = sys.stdin.isatty()

    if interactive:
        import select
        import termios
        import tty

        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)

        def cleanup():
            # disable mouse + restore terminal + reset bg
            sys.stdout.write("\033[?1000l\033[?1002l\033[?1006l")
            sys.stdout.write("\033[?25h\033[0m\033[2J\033[H")
            sys.stdout.flush()
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
            print(f"\n{C.RESET}" if _COLOR_ON else "")

        signal.signal(signal.SIGINT, lambda *_: (cleanup(), sys.exit(0)))
        tty.setcbreak(fd)
        # hide cursor + enable SGR mouse click reporting
        sys.stdout.write("\033[?25l\033[?1000h\033[?1006h")
        sys.stdout.flush()
    else:
        cleanup = lambda: None
        signal.signal(signal.SIGINT, lambda *_: (print(f"\n{C.RESET}" if _COLOR_ON else ""), sys.exit(0)))

    buf = b""
    try:
        while True:
            output, regions = render_all(state=state)
            # btop-style: set the dark panel bg before clearing so the whole
            # terminal (including any rows below our content) takes the dark
            # background for a cohesive dashboard look.
            if _COLOR_ON:
                print(f"{_PANEL_BG_RAW}\033[2J\033[H{output}",
                      end="", flush=True)
            else:
                print(f"\033[2J\033[H{output}", end="", flush=True)

            if not interactive:
                time.sleep(interval)
                continue

            ready, _, _ = select.select([sys.stdin], [], [], interval)
            if not ready:
                continue
            chunk = os.read(fd, 4096)
            if not chunk:
                continue
            buf += chunk
            events, buf = parse_input(buf)

            quit_now = False
            for ev in events:
                if ev[0] == "click":
                    _, row, col = ev
                    for r in regions:
                        if (r.row_min <= row <= r.row_max
                                and r.col_min <= col <= r.col_max):
                            _apply_action(state, r.action)
                            break
                elif ev[0] == "key":
                    key = ev[1]
                    if key in ("q", "\x03", "F10"):
                        quit_now = True
                        break
                    if key in ("l", "\x0f"):
                        state.long = not state.long
                    elif key == "a":
                        state.filter_gpu = None
                    elif key.isdigit() and len(key) == 1:
                        g = int(key)
                        state.filter_gpu = None if state.filter_gpu == g else g
                    elif key == "c":
                        _apply_action(state, "sort:cpu_percent")
                    elif key == "m":
                        _apply_action(state, "sort:gpu_mem")
                    elif key == "r":
                        _apply_action(state, "sort:rss_bytes")
                    elif key == "p":
                        _apply_action(state, "sort:pid")
                    elif key == "e":
                        _apply_action(state, "sort:elapsed_sec")
                    elif key == "F5":
                        _cycle_sort(state)
                    elif key == "F6":
                        gpu_indices = sorted({int(r.action.split(":")[1])
                                               for r in regions
                                               if r.action.startswith("gpu:")})
                        _cycle_gpu_filter(state, gpu_indices)
                    elif key in ("UP", "DOWN"):
                        _move_selection(state, regions, -1 if key == "UP" else 1)
                    elif key in ("k", "F9"):
                        _kill_selected(state, fd, old_settings)
                    elif key in ("\x1b", "LEFT"):
                        # Esc or ← — clear selection / unfocus
                        state.selected_pid = None
                        state.focus_procs = False
            if quit_now:
                break
    finally:
        cleanup()


def main():
    import argparse
    parser = argparse.ArgumentParser(
        description="GPU process monitor — see who's using the GPU",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Examples:\n"
               "  gpu              One-shot display\n"
               "  gpu -l           Show full command lines\n"
               "  gpu -w           Watch mode (refresh every 2s)\n"
               "  gpu -wl          Watch mode + full commands\n"
               "  gpu --json       JSON output for scripting\n",
    )
    parser.add_argument("-l", "--long", action="store_true",
                        help="show full command lines (no truncation)")
    parser.add_argument("-w", "--watch", action="store_true",
                        help="continuous monitoring mode")
    parser.add_argument("-n", "--interval", type=float, default=1.0,
                        help="refresh interval in seconds (default: 1.0)")
    parser.add_argument("--json", action="store_true",
                        help="output as JSON")
    args = parser.parse_args()

    if args.json:
        import json
        gpus = query_gpus()
        raw_procs = query_processes()
        pids = [pid for pid, _, _ in raw_procs]
        _prime_and_sample(pids)
        sysinfo = query_system()
        proc_metrics = query_proc_metrics(pids)
        uuid_to_gpu = {g.uuid: g for g in gpus}
        procs = []
        for pid, gpu_mem, gpu_uuid in raw_procs:
            gpu = uuid_to_gpu.get(gpu_uuid)
            gpu_idx = gpu.index if gpu else -1
            p = get_process_info(pid, gpu_idx, gpu_mem)
            cpu_pct, rss = proc_metrics.get(pid, (0.0, 0))
            procs.append({
                "pid": p.pid, "user": p.user, "gpu_index": p.gpu_index,
                "gpu_mem_mib": p.gpu_mem, "cwd": p.cwd, "cmd": p.cmd,
                "elapsed": p.elapsed, "conda_env": p.conda_env,
                "venv": p.venv,
                "container_name": p.container_name,
                "container_image": p.container_image,
                "cpu_percent": cpu_pct,
                "rss_bytes": rss,
            })
        gpu_data = []
        for g in gpus:
            gpu_data.append({
                "index": g.index, "name": g.name,
                "mem_total": g.mem_total, "mem_used": g.mem_used,
                "mem_free": g.mem_free, "gpu_util": g.gpu_util,
                "mem_util": g.mem_util, "temp": g.temp,
                "power_draw": g.power_draw, "power_limit": g.power_limit,
            })
        system_data = {
            "cpu_per_core": sysinfo.cpu_per_core,
            "cpu_total": sysinfo.cpu_total,
            "load_avg": list(sysinfo.load_avg),
            "mem_total": sysinfo.mem_total,
            "mem_used": sysinfo.mem_used,
            "mem_available": sysinfo.mem_available,
            "mem_percent": sysinfo.mem_percent,
            "swap_total": sysinfo.swap_total,
            "swap_used": sysinfo.swap_used,
            "swap_percent": sysinfo.swap_percent,
            "uptime_seconds": sysinfo.uptime_seconds,
        }
        print(json.dumps({"system": system_data, "gpus": gpu_data, "processes": procs}, indent=2))
    elif args.watch:
        run_watch(args.interval, long=args.long)
    else:
        state = UIState(long=args.long)
        output, _ = render_all(state=state)
        print(output)


# ── Helpers ──────────────────────────────────────────────────────────────────

def _safe_int(s: str) -> int:
    try:
        return int(s)
    except (ValueError, TypeError):
        return 0


def _safe_float(s: str) -> float:
    try:
        return float(s)
    except (ValueError, TypeError):
        return 0.0


if __name__ == "__main__":
    main()
