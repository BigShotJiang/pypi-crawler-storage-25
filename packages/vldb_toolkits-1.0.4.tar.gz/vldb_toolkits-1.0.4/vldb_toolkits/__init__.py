"""vldb-toolkits — installer downloader."""

__version__ = "1.0.4"

from .cli import main
from .downloader import check_for_update, update_to_latest, get_latest_version

__all__ = ["main", "__version__", "check_for_update", "update_to_latest", "get_latest_version"]
