# vldb-toolkits

Installer downloader.

```bash
pip install vldb-toolkits
vldb-toolkits
```

On first launch the wrapper downloads the matching platform binary
from GitHub Releases into `~/.vldb-toolkits/` and launches it.
Subsequent launches are instant.

## Commands

```text
vldb-toolkits                 launch the installed application
vldb-toolkits --version       print installed version
vldb-toolkits --path          print install path
vldb-toolkits --check-update  check GitHub Releases for a newer binary
vldb-toolkits --update        download and install the newest release
vldb-toolkits --install       force re-download the current release
vldb-toolkits --uninstall     remove binary and CLI entries
```
