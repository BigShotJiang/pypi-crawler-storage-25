from setuptools import setup, find_packages
from pathlib import Path

# Read the contents of your README file
this_directory = Path(__file__).parent
long_desc = (this_directory / "README.md").read_text()

setup(
    name='3pc-laminate',
    version='1.0.0',
    description='A 3pc Python library used to define a composite laminate and compute its properties based on classical lamination theory.',
    long_description=long_desc,
    long_description_content_type='text/markdown',
    author="Omprakash Seresta",
    author_email="oseresta@gmail.com",
    license="MIT",
    entry_points={
        'console_scripts': ['laminate = laminate.main:main']
    },
    packages=find_packages(),
    install_requires=[
        '3pc-ply',
        'numpy'
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    include_package_data=True,
    zip_safe=False
)
