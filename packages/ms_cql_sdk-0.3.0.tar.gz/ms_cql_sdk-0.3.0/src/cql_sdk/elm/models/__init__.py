"""ELM model classes."""
