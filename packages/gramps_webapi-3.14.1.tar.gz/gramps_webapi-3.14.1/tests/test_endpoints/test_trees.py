#
# Gramps Web API - A RESTful API for the Gramps genealogy program
#
# Copyright (C) 2023      David Straub
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
#

"""Tests for the `gramps_webapi.api.resources.user` module."""

import os
import shutil
import unittest
from unittest.mock import patch

from gramps.cli.clidbman import CLIDbManager
from gramps.gen.dbstate import DbState

from gramps_webapi.app import create_app
from gramps_webapi.auth import add_user, user_db
from gramps_webapi.auth.const import ROLE_ADMIN, ROLE_OWNER
from gramps_webapi.const import ENV_CONFIG_FILE, TEST_AUTH_CONFIG

from . import BASE_URL


class TestTrees(unittest.TestCase):
    """Test cases for the /api/trees endpoints."""

    def setUp(self):
        self.name = "Test Web API"
        self.dbman = CLIDbManager(DbState())
        dbpath, _name = self.dbman.create_new_db_cli(self.name, dbid="sqlite")
        self.tree = os.path.basename(dbpath)
        with patch.dict("os.environ", {ENV_CONFIG_FILE: TEST_AUTH_CONFIG}):
            self.app = create_app(
                config={"TESTING": True, "RATELIMIT_ENABLED": False},
                config_from_env=False,
            )
        self.client = self.app.test_client()
        with self.app.app_context():
            user_db.create_all()
            add_user(
                name="owner",
                password="123",
                email="owner@example.com",
                role=ROLE_OWNER,
                tree=self.tree,
            )
            add_user(
                name="admin",
                password="123",
                email="admin@example.com",
                role=ROLE_ADMIN,
                tree=self.tree,
            )
        self.assertTrue(self.app.testing)
        self.ctx = self.app.test_request_context()
        self.ctx.push()

    def tearDown(self):
        self.ctx.pop()
        self.dbman.remove_database(self.name)

    def test_list_trees_admin(self):
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "admin", "password": "123"}
        )
        token = rv.json["access_token"]
        rv = self.client.get(
            BASE_URL + "/trees/", headers={"Authorization": f"Bearer {token}"}
        )
        assert rv.status_code == 200
        trees = rv.json
        trees_dict = {tree["id"]: tree["name"] for tree in trees}
        assert trees_dict[self.tree] == self.name
        # admin can see more trees
        assert len(trees) > 1

    def test_list_trees_owner(self):
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        token = rv.json["access_token"]
        rv = self.client.get(
            BASE_URL + "/trees/", headers={"Authorization": f"Bearer {token}"}
        )
        assert rv.status_code == 200
        trees = rv.json
        # owner can see only one tree
        assert trees == [{"id": self.tree, "name": self.name, "enabled": True}]

    def test_get_tree(self):
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "admin", "password": "123"}
        )
        token = rv.json["access_token"]
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        token_owner = rv.json["access_token"]
        rv = self.client.get(
            BASE_URL + "/trees/..", headers={"Authorization": f"Bearer {token}"}
        )
        assert rv.status_code == 422
        # owner should get a 403 for non existing tree - not authorized
        rv = self.client.get(
            BASE_URL + "/trees/notexist",
            headers={"Authorization": f"Bearer {token_owner}"},
        )
        assert rv.status_code == 403
        # admin should get 404 thouogh
        rv = self.client.get(
            BASE_URL + "/trees/notexist", headers={"Authorization": f"Bearer {token}"}
        )
        assert rv.status_code == 404
        rv = self.client.get(
            BASE_URL + f"/trees/{self.tree}",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert rv.status_code == 200
        assert rv.json == {"name": self.name, "id": self.tree, "enabled": True}

    def test_post_tree(self):
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        token = rv.json["access_token"]
        # wrong parameter name
        rv = self.client.post(
            BASE_URL + "/trees/",
            headers={"Authorization": f"Bearer {token}"},
            json={"value": "some name"},
        )
        assert rv.status_code == 422
        # missing authorization
        rv = self.client.post(
            BASE_URL + "/trees/",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "some name"},
        )
        assert rv.status_code == 403
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "admin", "password": "123"}
        )
        token = rv.json["access_token"]
        # OK
        rv = self.client.post(
            BASE_URL + "/trees/",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "some name", "quota_media": 1000000},
        )
        assert rv.status_code == 201
        assert rv.json["id"]
        assert rv.json["name"] == "some name"
        assert rv.json["quota_media"] == 1000000
        assert rv.json["quota_people"] is None
        assert rv.json["enabled"]

    def test_rename_tree(self):
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "admin", "password": "123"}
        )
        token = rv.json["access_token"]
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        token_owner = rv.json["access_token"]
        rv = self.client.post(
            BASE_URL + "/trees/",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "my old name"},
        )
        assert rv.status_code == 201
        tree_id = rv.json["id"]
        # missing authorization
        rv = self.client.put(
            BASE_URL + f"/trees/{tree_id}",
            headers={"Authorization": f"Bearer {token_owner}"},
            json={"name": "my new name"},
        )
        assert rv.status_code == 403
        # OK
        rv = self.client.put(
            BASE_URL + f"/trees/{tree_id}",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "my new name"},
        )
        assert rv.status_code == 200
        assert rv.json == {"old_name": "my old name", "new_name": "my new name"}

    def test_rename_tree_blank_name(self):
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "admin", "password": "123"}
        )
        token = rv.json["access_token"]
        rv = self.client.post(
            BASE_URL + "/trees/",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "blank name test"},
        )
        assert rv.status_code == 201
        tree_id = rv.json["id"]
        rv = self.client.put(
            BASE_URL + f"/trees/{tree_id}",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "   "},
        )
        assert rv.status_code == 422
        # Ensure name was not changed
        rv = self.client.get(
            BASE_URL + f"/trees/{tree_id}",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert rv.status_code == 200
        assert rv.json["name"] == "blank name test"

    def test_disable_tree(self):
        # fetch tokens
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        assert rv.status_code == 200
        token_owner = rv.json["access_token"]
        token_owner_refresh = rv.json["refresh_token"]
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "admin", "password": "123"}
        )
        assert rv.status_code == 200
        token_admin = rv.json["access_token"]
        # owner can't disable
        rv = self.client.post(
            BASE_URL + f"/trees/{self.tree}/disable",
            headers={"Authorization": f"Bearer {token_owner}"},
        )
        assert rv.status_code == 403
        # admin can disable
        rv = self.client.post(
            BASE_URL + f"/trees/{self.tree}/disable",
            headers={"Authorization": f"Bearer {token_admin}"},
        )
        assert rv.status_code == 201
        # token does not work
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        assert rv.status_code == 503
        rv = self.client.post(
            BASE_URL + "/token/refresh/",
            headers={"Authorization": f"Bearer {token_owner_refresh}"},
        )
        assert rv.status_code == 503
        rv = self.client.post(
            BASE_URL + f"/trees/{self.tree}/enable",
            headers={"Authorization": f"Bearer {token_admin}"},
        )
        assert rv.status_code == 201
        # works again
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        assert rv.status_code == 200
        rv = self.client.post(
            BASE_URL + "/token/refresh/",
            headers={"Authorization": f"Bearer {token_owner_refresh}"},
        )
        assert rv.status_code == 200
        # and disable again
        rv = self.client.post(
            BASE_URL + f"/trees/{self.tree}/disable",
            headers={"Authorization": f"Bearer {token_admin}"},
        )
        assert rv.status_code == 201
        # token does not work
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        assert rv.status_code == 503
        rv = self.client.post(
            BASE_URL + "/token/refresh/",
            headers={"Authorization": f"Bearer {token_owner_refresh}"},
        )
        assert rv.status_code == 503
        rv = self.client.post(
            BASE_URL + f"/trees/{self.tree}/enable",
            headers={"Authorization": f"Bearer {token_admin}"},
        )
        assert rv.status_code == 201
        # works again
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        assert rv.status_code == 200
        rv = self.client.post(
            BASE_URL + "/token/refresh/",
            headers={"Authorization": f"Bearer {token_owner_refresh}"},
        )
        assert rv.status_code == 200

    def test_disable_nonexistant_tree(self):
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "admin", "password": "123"}
        )
        assert rv.status_code == 200
        token_admin = rv.json["access_token"]
        rv = self.client.post(
            BASE_URL + "/trees/idontexist/disable",
            headers={"Authorization": f"Bearer {token_admin}"},
        )
        assert rv.status_code == 404


class TestTreeConfig(unittest.TestCase):
    """Test cases for the /api/trees/<tree_id>/config endpoint."""

    def setUp(self):
        self.name = "Test Web API Config"
        self.dbman = CLIDbManager(DbState())
        dbpath, _name = self.dbman.create_new_db_cli(self.name, dbid="sqlite")
        self.tree = os.path.basename(dbpath)
        with patch.dict("os.environ", {ENV_CONFIG_FILE: TEST_AUTH_CONFIG}):
            self.app = create_app(
                config={"TESTING": True, "RATELIMIT_ENABLED": False},
                config_from_env=False,
            )
        self.client = self.app.test_client()
        with self.app.app_context():
            user_db.create_all()
            add_user(
                name="owner",
                password="123",
                email="owner@example.com",
                role=ROLE_OWNER,
                tree=self.tree,
            )
            add_user(
                name="admin",
                password="123",
                email="admin@example.com",
                role=ROLE_ADMIN,
                tree=self.tree,
            )
        self.ctx = self.app.test_request_context()
        self.ctx.push()

    def tearDown(self):
        self.ctx.pop()
        self.dbman.remove_database(self.name)

    def _token(self, username):
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": username, "password": "123"}
        )
        return rv.json["access_token"]

    def test_get_config_empty(self):
        token = self._token("owner")
        rv = self.client.get(
            BASE_URL + "/trees/-/config",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert rv.status_code == 200
        assert rv.json == {}

    def test_put_and_get_flat_config(self):
        token = self._token("owner")
        payload = {"show_sidebar": True, "items_per_page": 25, "theme": "dark"}
        rv = self.client.put(
            BASE_URL + "/trees/-/config",
            headers={"Authorization": f"Bearer {token}"},
            json=payload,
        )
        assert rv.status_code == 200
        assert rv.json == payload
        rv = self.client.get(
            BASE_URL + "/trees/-/config",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert rv.status_code == 200
        assert rv.json == payload

    def test_put_and_get_nested_config(self):
        token = self._token("owner")
        payload = {
            "ui": {"sidebar": True, "theme": "dark"},
            "allowed_roles": [1, 2, 3],
            "feature_flags": {"ai_chat": False, "export": True},
        }
        rv = self.client.put(
            BASE_URL + "/trees/-/config",
            headers={"Authorization": f"Bearer {token}"},
            json=payload,
        )
        assert rv.status_code == 200
        assert rv.json == payload
        rv = self.client.get(
            BASE_URL + "/trees/-/config",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert rv.status_code == 200
        assert rv.json == payload

    def test_put_config_replaces_entirely(self):
        token = self._token("owner")
        self.client.put(
            BASE_URL + "/trees/-/config",
            headers={"Authorization": f"Bearer {token}"},
            json={"key1": "val1", "key2": "val2"},
        )
        rv = self.client.put(
            BASE_URL + "/trees/-/config",
            headers={"Authorization": f"Bearer {token}"},
            json={"key2": "new"},
        )
        assert rv.status_code == 200
        rv = self.client.get(
            BASE_URL + "/trees/-/config",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert rv.json == {"key2": "new"}

    def test_get_config_other_tree_forbidden_for_owner(self):
        token = self._token("owner")
        rv = self.client.get(
            BASE_URL + "/trees/notexist/config",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert rv.status_code == 403

    def test_get_config_nonexistent_tree_404_for_admin(self):
        token = self._token("admin")
        rv = self.client.get(
            BASE_URL + "/trees/notexist/config",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert rv.status_code == 404

    def test_put_config_nonexistent_tree_404_for_admin(self):
        token = self._token("admin")
        rv = self.client.put(
            BASE_URL + "/trees/notexist/config",
            headers={"Authorization": f"Bearer {token}"},
            json={"key": "val"},
        )
        assert rv.status_code == 404


class TestTreesSingleTreeRename(unittest.TestCase):
    """Test tree rename in single-tree mode using TREE_ID config."""

    def setUp(self):
        self.name = "Test Single Tree Rename"
        self.dbman = CLIDbManager(DbState())
        dbpath, _name = self.dbman.create_new_db_cli(self.name, dbid="sqlite")
        self.tree = os.path.basename(dbpath)
        self.dbpath = dbpath
        # Single-tree mode: TREE=name, TREE_ID=dirname
        with patch.dict("os.environ", {ENV_CONFIG_FILE: TEST_AUTH_CONFIG}):
            self.app = create_app(
                config={
                    "TESTING": True,
                    "RATELIMIT_ENABLED": False,
                    "TREE": self.name,
                    "TREE_ID": self.tree,
                },
                config_from_env=False,
            )
        self.client = self.app.test_client()
        with self.app.app_context():
            user_db.create_all()
            add_user(
                name="owner",
                password="123",
                email="owner@example.com",
                role=ROLE_OWNER,
                tree=self.tree,
            )
        self.ctx = self.app.test_request_context()
        self.ctx.push()

    def tearDown(self):
        self.ctx.pop()
        # Remove by path directly: name may have changed after a rename test
        if os.path.isdir(self.dbpath):
            shutil.rmtree(self.dbpath)

    def test_rename_single_tree(self):
        """Owner can rename own tree in single-tree mode when TREE_ID is set."""
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        assert rv.status_code == 200
        token = rv.json["access_token"]
        # Verify the current name via GET /trees/-
        rv = self.client.get(
            BASE_URL + "/trees/-", headers={"Authorization": f"Bearer {token}"}
        )
        assert rv.status_code == 200
        assert rv.json["name"] == self.name
        assert rv.json["id"] == self.tree
        # Rename the tree
        rv = self.client.put(
            BASE_URL + "/trees/-",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "New Name"},
        )
        assert rv.status_code == 200
        assert rv.json == {"old_name": self.name, "new_name": "New Name"}
        # New login still works (TREE_ID means no name-based lookup at login)
        rv = self.client.post(
            BASE_URL + "/token/", json={"username": "owner", "password": "123"}
        )
        assert rv.status_code == 200
        token2 = rv.json["access_token"]
        # GET /trees/- reflects the new name
        rv = self.client.get(
            BASE_URL + "/trees/-", headers={"Authorization": f"Bearer {token2}"}
        )
        assert rv.status_code == 200
        assert rv.json["name"] == "New Name"

    def test_rename_single_tree_without_tree_id_blocked(self):
        """Rename is blocked in single-tree mode when TREE_ID is not set."""
        # Create a second app instance without TREE_ID
        with patch.dict("os.environ", {ENV_CONFIG_FILE: TEST_AUTH_CONFIG}):
            app_no_tree_id = create_app(
                config={
                    "TESTING": True,
                    "RATELIMIT_ENABLED": False,
                    "TREE": self.name,
                    # no TREE_ID
                },
                config_from_env=False,
            )
        client = app_no_tree_id.test_client()
        with app_no_tree_id.app_context():
            user_db.create_all()
            add_user(
                name="owner2",
                password="123",
                email="owner2@example.com",
                role=ROLE_OWNER,
                tree=self.tree,
            )
        rv = client.post(
            BASE_URL + "/token/", json={"username": "owner2", "password": "123"}
        )
        assert rv.status_code == 200
        token = rv.json["access_token"]
        rv = client.put(
            BASE_URL + "/trees/-",
            headers={"Authorization": f"Bearer {token}"},
            json={"name": "Attempted New Name"},
        )
        assert rv.status_code == 405
