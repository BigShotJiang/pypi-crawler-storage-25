import torch
import torch.nn as nn

def ParaLSTM(system_dim, embed_dim, num_heads, nclass, vocab_size):
    mini_info = '''
Памятка использования ParaLSTM в рамках библиотеки ryaNN.

<pars:ParaLSTM-main>
Что такое ParaLSTM?
ParaLSTM - вид архитектуры нейронной сети, представляющая собой параллельную LSTM с модификациями. Данная архитектура имеет 2 вентиля - Input и forget. 
Если в обычной LSTM сначала идет Forget, то у ParaLSTM сначала input. Это связанно с отстутсвием рекуррентности архитектуры. Записывать в память просто x - будет нелогично. Это создаст проблемы с классификацией в будущем.
Все идет параллельно - сначала обновляем x на основе голов и складываем, получая мнение всех голов вместе взятых. Потом делим на количество голов для нормализации и прогоняем через Tanh для получения сигналов что сеть считает важным (любит ли сообщество голов такой отрывок из embeddingа x или нет), а что нет (насколько не любит сообщество голов данный отрывок из embeddingа x).
<pars:ParaLSTM-main>

<pars:ParaLSTM-ingate>
InGate в ParaLSTM это просто матричное умножение каждой из голов (x@h), независимо от других голов. Каждая "любит" свои сигналы (непример, при классификации текста мат/не мат) каждая матрица весов подстраивается под embedding - напримеро, в эмбеддинге токена "ху" есть важные сигналым на позициях 20 и 50, которые есть только у токена "ху". Нарпимер, голова 1 будет смотреть на эти сигналы (20, 50) больше всего и конечно будет смотреть на другие, но основа будет 20 и 50е позиции, а вторая меньше всего на 20 и 50 позиции (если во время обучения веса сложились так, что эта голова не любит смотреть на плохие слова и всегда ищет только хорошее). Как мы видим, первая голова хочет распознать мат, а вторая - хорошее слово.
Так же важно знать: этот гейт складывает в один тензор все, что выдали головы. Только потом нормализует (делит на количество голов) и пропускает через tanh. Этот гейт может быть не стабильным по сравнению с оригинальным Input Gate в LSTM.
Работа:
headox = torch.zeros(x.size(0), x.size(1), self.system_dim) 
k_del = 0
for i in self.body:
    headx = x @ i 
    headox = headox + headx 
    k_del = k_del+ 1
headox = headox / k_del
headox = self.tanh(headox)
memory = memory + headox 

Сначала memory - это тензор с нулями, размера batch, x.size(1), system_dim
<pars:ParaLSTM-ingate>

<pars:ParaLSTM-fogate>
ForgetGate в ParaLSTM копирует 1в1 формулы и работу InGate, только со своими весами и головами. Головы в ForgetGate, в отличие от InGate решают, что будет не важно на основе входа x. Далее так же нормализуем, но уже не tanh, а сигмоид (sigmoid). Это сделано для того, что бы умножить память на наш новый тензор (прямо как в LSTM с f_t и c_t) операцией memory * f_paralstm. Memory на этот момент содержит инофрмацию, которую заготовил InGate. 
Получается, у нас есть 2 вентиля которые работают в паре и готовят память.
Работа:
headoxn = torch.zeros(x.size(0), x.size(1), self.system_dim)
k_del = 0
for i in self.forgets_x:
    headoxn = headoxn + (x @ i)
    k_del = k_del + 1
head_add = headoxn/k_del
head_add = self.sigmoid(head_add)
memory = memory * head_add
<pars:ParaLSTM-fogate>

<pars:ParaLSTM-memory>
После всех вентилей мы должны сформировать матрицу размером batch, system_dim. Это будет общая информация о всей последовательности. Сначала, мы усредняем нашу память (memory.mean(dim=1)), затем матрично умножаем на веса памяти. Все то же самое, что и в других вентилях, но с чуть другими размерностями. И прогоняем через tanh для стабильности.
Теперь тут сигналы - насколько этот нейрон, а точнее веса нейрона любят это число в памяти. Потом, мы так же нормализуем память и прогоняем через линейный слой. В основном, задача слоев LSTM, RNN, MHA и т.п. - преобразовать матрицу последовательности для классификации линейным слоем. Зачем так делать, встает вопрос. Это делается для того, что бы линейный слой запомнил стиль выхода слоя и не получал всегда разные, хаотичные входы. Это поможет его весам стабильностью.
Работа:
memory = memory.mean(dim=1)
memn = torch.randn(memory.size(0), self.system_dim)
k_del = 0
for i in self.matrix:
    memn = memn + (memory@i)
    k_del = k_del + 1
memn = memn / k_del
memn = self.tanh(memn)
memory = memn
<pars:ParaLSTM-memory>

<pars:ryaNN>
ryaNN - A library created for training our own architectures. Fully compatible with PyTorch. IMPORTANT - the Russian translation may be off and written with issues.
ryaNN, 2026. ML Python library.
Check and: ryatrain, ryainfo, ryaNN
librares may be testing and not available.
<pars:ryaNN>

<pars:parsing>
Info - <pars:ParaLSTM-main>
InGate - <pars:ParaLSTM-ingate>
ForgetGate - <pars:ParaLSTM-fogate>
Memory - <pars:ParaLSTM-memory>
ryan - <pars:ryaNN>
<pars:parsing>
    '''
    class AI(nn.Module):
        def __init__(self, vocab_size=vocab_size, nclass=nclass, embed_dim=embed_dim, num_heads=num_heads, system_dim=system_dim):
            super().__init__()
            self.embedding = nn.Embedding(vocab_size, embed_dim)
            self.system_dim = system_dim
            self.body = nn.ParameterList([

            ])
            for i in range(num_heads):
                self.body.append(nn.Parameter(torch.randn(embed_dim, system_dim)))

            self.forgets_x = nn.ParameterList([

            ])
            for i in range(num_heads):
                self.forgets_x.append(nn.Parameter(torch.randn(embed_dim, system_dim)))
            self.matrix = nn.ParameterList([

            ])
            for i in range(num_heads):
                self.matrix.append(nn.Parameter(torch.randn(system_dim, system_dim)))
            self.tanh = nn.Tanh()
            self.sigmoid = nn.Sigmoid()
            self.normalization = nn.LayerNorm(system_dim)
            self.linear = nn.Linear(system_dim, nclass)
        def forward(self, x):
            x = self.embedding(x)
            memory = torch.zeros(x.size(0), x.size(1), self.system_dim) 
            if x.dim() == 2:
                x = x.unsqueeze(0)
            headox = torch.zeros(x.size(0), x.size(1), self.system_dim) 
            k_del = 0
            for i in self.body:
                headx = x @ i 
                headox = headox + headx 
                k_del = k_del+ 1
            headox = headox / k_del
            headox = self.tanh(headox)
            memory = memory + headox 
            headoxn = torch.zeros(x.size(0), x.size(1), self.system_dim)
            k_del = 0
            for i in self.forgets_x:
                headoxn = headoxn + (x @ i)
                k_del = k_del + 1
            head_add = headoxn/k_del
            head_add = self.sigmoid(head_add)
            memory = memory * head_add
            memory = memory.mean(dim=1)
            memn = torch.randn(memory.size(0), self.system_dim)
            k_del = 0
            for i in self.matrix:
                memn = memn + (memory@i)
                k_del = k_del + 1
            memn = memn / k_del
            memn = self.tanh(memn)
            memory = memn
            x = self.linear(memory)
            return x
    return (AI(), mini_info)