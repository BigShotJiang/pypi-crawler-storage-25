"""FastMCP Tool 信息提取器

解决 fastmcp_docs 的不足：
- 补全每个入参的 description（从 Google-style 文档字符串解析）
- 补全每个入参的 default 值（从 inspect.signature 读取）
- 补全 required 标记
- 新增出参 (output) schema 提取（从返回类型注解生成）
"""

import ast
import inspect
import re
import textwrap
from typing import Any, Callable, Literal, get_type_hints

from pydantic import BaseModel

OPENAPI3_REF_TEMPLATE = "#/components/schemas/{model}"

# ---------------------------------------------------------------------------
# 辅助：从 JSON Schema property 提取可读类型名
# ---------------------------------------------------------------------------


def _resolve_type_str(prop: dict[str, Any]) -> str:
    """从单个 JSON Schema property dict 提取可读类型字符串。"""
    if not isinstance(prop, dict):
        return "any"
    if "type" in prop:
        return prop["type"]
    # anyOf / oneOf → 取第一个非 null 类型
    for key in ("anyOf", "oneOf"):
        if key in prop:
            non_null = [
                _resolve_type_str(sub) for sub in prop[key] if isinstance(sub, dict) and sub.get("type") != "null"
            ]
            return non_null[0] if non_null else "any"
    # $ref → 取引用名称
    if "$ref" in prop:
        return prop["$ref"].split("/")[-1]
    return "any"


# ---------------------------------------------------------------------------
# 辅助：解析 Google-style 文档字符串的 Args 段落
# ---------------------------------------------------------------------------


def _parse_docstring_args(docstring: str) -> dict[str, str]:
    """
    解析 Google-style 文档字符串中的 Args 段落，返回参数名 → 描述的映射。

    支持多行描述（续行必须比参数名多 4 个空格缩进）。
    """
    if not docstring:
        return {}

    params: dict[str, str] = {}
    lines = docstring.splitlines()
    in_args = False
    current_param: str | None = None
    current_lines: list[str] = []

    # Google-style 段落标题正则：形如 "    Args:" 或 "Args:"
    section_re = re.compile(r"^(\s*)(\w[\w\s]*):\s*$")
    # 参数行正则：4 个空格缩进，参数名后跟冒号
    param_re = re.compile(r"^    (\w+):\s*(.*)")

    for line in lines:
        stripped = line.strip()

        # 检测段落切换
        m = section_re.match(line)
        if m:
            if in_args:
                # 遇到新段落，结束 Args 解析
                if current_param is not None:
                    params[current_param] = " ".join(current_lines).strip()
                break
            if stripped == "Args:":
                in_args = True
            continue

        if not in_args:
            continue

        # 参数行
        mp = param_re.match(line)
        if mp:
            # 保存上一个参数
            if current_param is not None:
                params[current_param] = " ".join(current_lines).strip()
            current_param = mp.group(1)
            current_lines = [mp.group(2).strip()] if mp.group(2).strip() else []
        elif current_param is not None and line.startswith("      "):
            # 续行（至少 6 个空格）
            current_lines.append(stripped)
        elif not stripped:
            # 空行：允许段落内的空行
            pass

    # 提交最后一个参数
    if current_param is not None:
        params[current_param] = " ".join(current_lines).strip()

    return params


# ---------------------------------------------------------------------------
# 辅助：从函数签名获取参数默认值信息
# ---------------------------------------------------------------------------

_SKIP_PARAMS = frozenset({"ctx", "self", "cls"})


def _normalize_schema_name(name: str) -> str:
    """规范化 components/schemas 名称。"""
    return re.sub(r"[^\w.\-]", "_", name)


JsonSchemaMode = Literal["validation", "serialization"]


def _model_schema_components(
    model: type[BaseModel], *, mode: JsonSchemaMode = "validation"
) -> tuple[str, dict[str, Any]]:
    """生成模型 schema，并将 $defs 平铺为 components/schemas。"""
    schema = model.model_json_schema(ref_template=OPENAPI3_REF_TEMPLATE, mode=mode)
    definitions = schema.pop("$defs", {}) or {}
    model_name = _normalize_schema_name(str(schema.get("title") or model.__name__))
    components = {model_name: schema}
    for def_name, def_schema in definitions.items():
        components[_normalize_schema_name(def_name)] = def_schema
    return model_name, components


def _get_signature_defaults(fn: Callable) -> dict[str, dict[str, Any]]:
    """
    通过 inspect.signature（自动 follow __wrapped__）获取参数默认值。

    返回：{ param_name: {"has_default": bool, "default": Any} }
    """
    try:
        sig = inspect.signature(fn, follow_wrapped=True)
    except (ValueError, TypeError):
        return {}

    result: dict[str, dict[str, Any]] = {}
    for name, param in sig.parameters.items():
        if name in _SKIP_PARAMS:
            continue
        if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            continue
        has_default = param.default is not inspect.Parameter.empty
        result[name] = {
            "has_default": has_default,
            "default": param.default if has_default else None,
        }
    return result


# ---------------------------------------------------------------------------
# 辅助：获取 tool 的底层函数
# ---------------------------------------------------------------------------


def _get_tool_fn(tool: Any) -> Callable | None:
    """尝试从 tool 对象获取底层函数。"""
    for attr in ("fn", "func", "_fn", "function"):
        fn = getattr(tool, attr, None)
        if fn is not None and callable(fn):
            return fn
    return None


# ---------------------------------------------------------------------------
# 辅助：恢复 my_mcp_tool wrapper 元数据
# ---------------------------------------------------------------------------


def _get_closure_nonlocals(fn: Callable | None) -> dict[str, Any]:
    """读取函数闭包中的 nonlocal 变量。"""
    if fn is None or fn.__closure__ is None:
        return {}
    return {name: cell.cell_contents for name, cell in zip(fn.__code__.co_freevars, fn.__closure__, strict=True)}


def _get_original_fn(fn: Callable | None) -> Callable | None:
    """从 wrapper 闭包中恢复原始函数。"""
    nonlocals = _get_closure_nonlocals(fn)
    original = nonlocals.get("func")
    return original if callable(original) else fn


def _get_body_model(fn: Callable | None) -> type[BaseModel] | None:
    """从 my_mcp_tool 闭包中获取唯一 body model。"""
    body_params = _get_closure_nonlocals(fn).get("_body_params") or {}
    for model in body_params.values():
        if inspect.isclass(model) and issubclass(model, BaseModel):
            return model
    return None


def _get_query_response_model(fn: Callable | None) -> type[BaseModel] | None:
    """从 client.query(req, ResponseModel, ...) 调用中提取响应模型。"""
    if fn is None:
        return None
    try:
        source = textwrap.dedent(inspect.getsource(fn))
        tree = ast.parse(source)
    except (OSError, TypeError, SyntaxError):
        return None

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute) or node.func.attr != "query":
            continue
        if len(node.args) < 2 or not isinstance(node.args[1], ast.Name):
            continue
        model = fn.__globals__.get(node.args[1].id)
        if inspect.isclass(model) and issubclass(model, BaseModel):
            return model
    return None


# ---------------------------------------------------------------------------
# 辅助：从返回类型注解生成 output schema
# ---------------------------------------------------------------------------


def _get_return_schema(fn: Callable | None) -> dict[str, Any]:
    """
    尝试从函数返回注解生成 JSON Schema。
    - 如果是 pydantic.BaseModel 子类，使用 model_json_schema()
    - 否则返回简单描述
    """
    if fn is None:
        return {}

    try:
        hints = get_type_hints(fn)
    except Exception:
        hints = {}

    return_type = hints.get("return")
    if return_type is None:
        return {}

    # 尝试直接从 BaseModel 子类生成 schema
    try:
        import pydantic  # pylint: disable=import-outside-toplevel

        # 处理泛型：取 __origin__ 或 __mro_entries__ 中的具体类
        origin = getattr(return_type, "__origin__", None)
        if origin is not None and inspect.isclass(origin) and issubclass(origin, pydantic.BaseModel):
            return origin.model_json_schema()
        if inspect.isclass(return_type) and issubclass(return_type, pydantic.BaseModel):
            return return_type.model_json_schema()
    except Exception:
        pass

    # 退化为类型名称
    type_name = getattr(return_type, "__name__", str(return_type))
    return {"description": type_name}


# ---------------------------------------------------------------------------
# 主提取器
# ---------------------------------------------------------------------------


class ToolExtractor:
    """从 FastMCP server 实例提取 tool 完整信息"""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    async def extract(self, mcp: Any) -> dict[str, Any]:
        """
        提取所有 tool 信息，返回 { tool_name: tool_info } 的字典。

        兼容 FastMCP v2（get_tools -> dict）和 v3（list_tools -> list）。
        """
        tools_raw = await self._fetch_tools(mcp)
        if not tools_raw:
            return {}

        registry: dict[str, Any] = {}
        for name, tool in tools_raw.items():
            try:
                registry[name] = self._extract_one(name, tool)
                if self.verbose:
                    print(f"  ✓ {name}")
            except Exception as exc:  # pylint: disable=broad-except
                if self.verbose:
                    print(f"  ✗ {name}: {exc}")
        return registry

    # ------------------------------------------------------------------
    # 内部方法
    # ------------------------------------------------------------------

    async def _fetch_tools(self, mcp: Any) -> dict[str, Any]:
        """从 FastMCP server 获取 tool 原始对象字典。"""
        if hasattr(mcp, "list_tools"):
            tools_list = await mcp.list_tools()
            return {t.name: t for t in tools_list}
        if hasattr(mcp, "get_tools"):
            return await mcp.get_tools()
        raise AttributeError("FastMCP server 既无 list_tools() 也无 get_tools()")

    def _extract_one(self, tool_name: str, tool: Any) -> dict[str, Any]:
        """提取单个 tool 的完整信息。"""
        # ---- 基础信息 ----
        description: str = getattr(tool, "description", "") or ""
        tags: list[str] = list(getattr(tool, "tags", None) or [])
        title: str = tool_name
        if getattr(tool, "annotations", None) is not None:
            ann_title = getattr(tool.annotations, "title", None)
            if ann_title:
                title = ann_title

        # ---- 底层函数 ----
        fn = _get_tool_fn(tool)
        original_fn = _get_original_fn(fn)

        # ---- 入参 schema（来自 FastMCP 生成的 JSON Schema）----
        # FastMCP FunctionTool 使用 .parameters 属性；旧版本使用 .input_schema
        input_schema: dict[str, Any] = getattr(tool, "parameters", None) or getattr(tool, "input_schema", None) or {}

        # ---- 从函数签名补充默认值 ----
        sig_defaults = _get_signature_defaults(fn) if fn else {}

        # ---- 从文档字符串补充参数描述 ----
        doc = inspect.getdoc(original_fn) if original_fn else inspect.getdoc(fn) if fn else None
        doc_params = _parse_docstring_args(doc or "")

        # ---- 合并构建参数列表 ----
        parameters = self._build_parameters(input_schema, sig_defaults, doc_params)

        # ---- 入参/出参模型 schema ----
        component_schemas: dict[str, Any] = {}
        input_model_name = None
        input_model = _get_body_model(fn)
        if input_model is not None:
            input_model_name, input_components = _model_schema_components(input_model, mode="validation")
            component_schemas.update(input_components)

        response_model_name = None
        response_model = _get_query_response_model(original_fn)
        if response_model is not None:
            response_model_name, response_components = _model_schema_components(response_model, mode="serialization")
            component_schemas.update(response_components)

        # ---- 出参 schema ----
        output_schema = _get_return_schema(fn)

        doc_lines = [line.strip() for line in (doc or "").splitlines()]
        summary = doc_lines[0].rstrip("。.") if doc_lines else title
        openapi_description = "<br/>".join(doc_lines) if doc_lines else description or ""
        tag_descriptions: dict[str, str] = {}
        if tool_name.startswith("shuiyin_"):
            tags = ["水印相关接口"]
            tag_descriptions["水印相关接口"] = "水印对应业务逻辑实现的相关接口"

        return {
            "name": tool_name,
            "title": title,
            "summary": summary,
            "description": openapi_description or "（无描述）",
            "tags": tags,
            "tag_descriptions": tag_descriptions,
            "parameters": parameters,
            "output_schema": output_schema,
            "input_model_name": input_model_name,
            "response_model_name": response_model_name,
            "component_schemas": component_schemas,
        }

    def _build_parameters(
        self,
        input_schema: dict[str, Any],
        sig_defaults: dict[str, dict[str, Any]],
        doc_params: dict[str, str],
    ) -> list[dict[str, Any]]:
        """
        融合三个来源的信息，构建完整的参数列表。

        优先级（高 → 低）：
          1. input_schema.properties（FastMCP 生成，含 type / description / default）
          2. sig_defaults（inspect.signature，含真实 default）
          3. doc_params（文档字符串 Args 段落，含 description）
        """
        if not isinstance(input_schema, dict):
            return []

        properties: dict[str, Any] = input_schema.get("properties") or {}
        required_set: set[str] = set(input_schema.get("required") or [])

        params: list[dict[str, Any]] = []
        for param_name, prop in properties.items():
            if not isinstance(prop, dict):
                continue

            # 类型
            type_str = _resolve_type_str(prop)

            # 描述：schema > 文档字符串
            description = prop.get("description", "") or doc_params.get(param_name, "")

            # 默认值：schema > inspect.signature
            schema_has_default = "default" in prop
            sig_info = sig_defaults.get(param_name, {})

            if schema_has_default:
                has_default = True
                default_value = prop["default"]
            elif sig_info.get("has_default"):
                has_default = True
                default_value = sig_info["default"]
            else:
                has_default = False
                default_value = None

            # 是否必填：required 列表优先；其次看是否有默认值
            is_required = param_name in required_set if required_set else not has_default

            # 枚举值
            enum_values: list[Any] | None = prop.get("enum")

            # 示例
            example = prop.get("example")

            entry: dict[str, Any] = {
                "name": param_name,
                "type": type_str,
                "description": description,
                "required": is_required,
            }
            if has_default:
                entry["default"] = default_value
            if enum_values is not None:
                entry["enum"] = enum_values
            if example is not None:
                entry["example"] = example

            params.append(entry)

        return params
