import functools
import inspect
import typing as t
from dataclasses import dataclass

from fastmcp import Context, FastMCP
from pydantic import BaseModel
from starlette.requests import Request
from starlette.responses import Response

T = t.TypeVar("T")
RequestIdGetter = t.Callable[[], str]
RequestIdSetter = t.Callable[[str | None], None]


@dataclass(frozen=True)
class RequestIdHandlers:
    get_request_id: RequestIdGetter | None = None
    set_request_id: RequestIdSetter | None = None


_request_id_handlers = RequestIdHandlers()


def configure_request_id_handlers(
    *,
    get_request_id: RequestIdGetter | None = None,
    set_request_id: RequestIdSetter | None = None,
) -> None:
    global _request_id_handlers  # pylint: disable=global-statement
    _request_id_handlers = RequestIdHandlers(get_request_id=get_request_id, set_request_id=set_request_id)


def _get_request_id() -> str:
    if _request_id_handlers.get_request_id is None:
        return ""
    return _request_id_handlers.get_request_id()


def _set_request_id(request_id: str | None) -> None:
    if _request_id_handlers.set_request_id is not None:
        _request_id_handlers.set_request_id(request_id)


def _build_flattened_signature(  # pylint: disable=too-many-locals
    func: t.Callable, body_params: dict[str, type[BaseModel]]
) -> tuple[inspect.Signature, dict[str, list[str]]]:
    from pydantic_core import PydanticUndefined  # pylint: disable=import-outside-toplevel

    original_sig = inspect.signature(func)
    field_map: dict[str, list[str]] = {}
    new_params: list[inspect.Parameter] = []
    has_keyword_only_field = False

    for param_name, param in original_sig.parameters.items():
        if param_name not in body_params:
            if has_keyword_only_field and param.kind is inspect.Parameter.POSITIONAL_OR_KEYWORD:
                param = param.replace(kind=inspect.Parameter.KEYWORD_ONLY)
            new_params.append(param)
            continue

        model_cls = body_params[param_name]
        field_names: list[str] = []

        try:
            field_hints = t.get_type_hints(model_cls)
        except Exception:  # pylint: disable=broad-except
            field_hints = {}

        for field_name, field_info in model_cls.model_fields.items():
            field_names.append(field_name)
            base_type = field_hints.get(field_name, t.Any)
            annotation = t.Annotated[base_type, field_info]  # type: ignore
            default = field_info.default if field_info.default is not PydanticUndefined else inspect.Parameter.empty
            kind = inspect.Parameter.POSITIONAL_OR_KEYWORD
            if field_info.default_factory is not None:
                default = inspect.Parameter.empty
                kind = inspect.Parameter.KEYWORD_ONLY  # type: ignore
                has_keyword_only_field = True
            elif has_keyword_only_field:
                kind = inspect.Parameter.KEYWORD_ONLY  # type: ignore
            new_params.append(
                inspect.Parameter(
                    name=field_name,
                    kind=kind,
                    default=default,
                    annotation=annotation,
                )
            )

        field_map[param_name] = field_names

    return original_sig.replace(parameters=new_params), field_map


def my_mcp_tool(mcp: FastMCP, *a: t.Any, **kw: t.Any) -> t.Callable[..., t.Any]:
    def decorator(func: t.Callable[..., t.Awaitable[T]]) -> t.Any:
        _body_params: dict[str, type[BaseModel]] = {}
        try:
            hints = t.get_type_hints(func)
            for pname, hint in hints.items():
                if pname in ("ctx", "self", "cls", "return"):
                    continue
                if inspect.isclass(hint) and issubclass(hint, BaseModel):
                    _body_params[pname] = hint
        except Exception:  # pylint: disable=broad-except
            pass

        _field_map: dict[str, list[str]] = {}
        _flat_sig = None
        if _body_params:
            try:
                _flat_sig, _field_map = _build_flattened_signature(func, _body_params)
            except Exception:  # pylint: disable=broad-except
                pass

        @functools.wraps(func)
        async def wrapper(ctx: Context, *args: t.Any, **kwargs: t.Any) -> T:
            if ctx.request_context:
                mcp_sid = getattr(ctx, "session_id", "mcp-sid")
                mcp_rid = ctx.request_context.request_id
            else:
                mcp_sid, mcp_rid = "rest-session", "rest-request"
            _set_request_id(f"{_get_request_id()}:{mcp_sid}:{mcp_rid}")
            for model_param, field_names in _field_map.items():
                model_cls = _body_params[model_param]
                model_kwargs = {fn: kwargs.pop(fn) for fn in field_names if fn in kwargs}
                kwargs[model_param] = model_cls.model_validate(obj=model_kwargs)
            for pname, model_cls in _body_params.items():
                if pname in kwargs and isinstance(kwargs[pname], dict):
                    kwargs[pname] = model_cls.model_validate(obj=kwargs[pname])
            return await func(ctx, *args, **kwargs)

        if _flat_sig is not None:
            wrapper.__signature__ = _flat_sig  # type: ignore[attr-defined]
            new_annotations: dict[str, t.Any] = {
                p.name: p.annotation
                for p in _flat_sig.parameters.values()
                if p.annotation is not inspect.Parameter.empty
            }
            if _flat_sig.return_annotation is not inspect.Signature.empty:
                new_annotations["return"] = _flat_sig.return_annotation
            wrapper.__annotations__ = new_annotations
            try:
                del wrapper.__wrapped__  # type: ignore[attr-defined]
            except AttributeError:
                pass

        return mcp.tool(*a, **kw)(wrapper)

    return decorator


def my_mcp_custom_route(
    mcp: FastMCP,
    path: str,
    methods: list[str],
    name: str | None = None,
    include_in_schema: bool = True,
) -> t.Callable[..., t.Callable[[Request], t.Awaitable[Response]]]:
    def decorator(func: t.Callable[[Request], t.Awaitable[Response]]) -> t.Callable[[Request], t.Awaitable[Response]]:
        @functools.wraps(func)
        async def wrapper(request: Request) -> Response:
            _set_request_id(request.headers.get("X-Request-Id"))
            resp = await func(request)
            resp.headers["X-MZ-Request-Id"] = _get_request_id()
            return resp

        return mcp.custom_route(path, methods=methods, name=name, include_in_schema=include_in_schema)(wrapper)

    return decorator
