"""FastMCP OpenAPI 配置"""

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class FastMCPOpenAPIConfig:
    """FastMCP OpenAPI 文档服务配置"""

    # 文档基础信息
    title: str = "MCP Tools API"
    version: str = "1.0.0"
    description: str = ""
    base_url: str = ""

    # 路由路径
    openapi_route: str = "/openapi.json"
    docs_ui_route: str = "/docs"
    api_tools_route: str = "/api/tools"
    api_base: str = "/call"

    # OpenAPI 版本
    openapi_version: str = "3.1.0"

    # CORS
    enable_cors: bool = True

    # 调试输出
    verbose: bool = False

    # 自定义 favicon（None 则使用内置 SVG）
    favicon_url: Optional[str] = None

    # 额外的 OpenAPI servers 配置
    extra_servers: list = field(default_factory=list)
