from importlib import import_module
from pathlib import Path

_src_package = Path(__file__).resolve().parent / "src" / "fastmcp_openapi"
if _src_package.is_dir():
    __path__.insert(0, str(_src_package))  # type: ignore[name-defined]

_config = import_module(f"{__name__}.config")
_decorators = import_module(f"{__name__}.decorators")
_extractor = import_module(f"{__name__}.extractor")
_routes = import_module(f"{__name__}.routes")

FastMCPOpenAPIConfig = _config.FastMCPOpenAPIConfig
ToolExtractor = _extractor.ToolExtractor
RouteRegistrar = _routes.RouteRegistrar
configure_request_id_handlers = _decorators.configure_request_id_handlers
my_mcp_custom_route = _decorators.my_mcp_custom_route
my_mcp_tool = _decorators.my_mcp_tool

__version__ = "1.0.0"
__all__ = [
    "FastMCPOpenAPI",
    "FastMCPOpenAPIConfig",
    "configure_request_id_handlers",
    "my_mcp_custom_route",
    "my_mcp_tool",
]


class FastMCPOpenAPI:
    def __init__(
        self,
        mcp,
        *,
        title: str = "MCP Tools API",
        version: str = "1.0.0",
        description: str = "",
        base_url: str | None = None,
        config: FastMCPOpenAPIConfig | None = None,
        verbose: bool = False,
    ) -> None:
        self.mcp = mcp
        self.config = config or FastMCPOpenAPIConfig(
            title=title,
            version=version,
            description=description,
            base_url=base_url or "",
            verbose=verbose,
        )
        self._extractor = ToolExtractor(verbose=self.config.verbose)
        self._registry: dict = {}

    async def setup(self) -> None:
        if self.config.verbose:
            print("[fastmcp_openapi] 开始提取 tool 信息…")

        self._registry = await self._extractor.extract(self.mcp)

        registrar = RouteRegistrar(self.mcp, self.config, self._registry)
        registrar.register_all()

        if self.config.verbose:
            print(
                f"[fastmcp_openapi] 完成，共 {len(self._registry)} 个 tool。"
                f" 文档：{self.config.base_url}{self.config.docs_ui_route}"
            )
