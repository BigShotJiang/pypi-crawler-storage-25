"""fastmcp_openapi — 为 FastMCP server 提供完整的 OpenAPI 文档服务

功能：
  - 提取每个 tool 的入参（含 description / default / required）
  - 提取每个 tool 的出参 schema（从返回类型注解生成）
  - 挂载 /openapi.json、/docs、/api/tools 三条路由

用法::

    from fastmcp import FastMCP
    from fastmcp_openapi import FastMCPOpenAPI

    mcp = FastMCP("My Server")

    # 注册 tool …

    docs = FastMCPOpenAPI(mcp, title="美折 MCP Tools", base_url="http://localhost:8333")
    import asyncio
    asyncio.run(docs.setup())
"""

from .config import FastMCPOpenAPIConfig
from .decorators import configure_request_id_handlers, my_mcp_custom_route, my_mcp_tool
from .extractor import ToolExtractor
from .routes import RouteRegistrar

__version__ = "1.0.0"
__all__ = [
    "FastMCPOpenAPI",
    "FastMCPOpenAPIConfig",
    "configure_request_id_handlers",
    "my_mcp_custom_route",
    "my_mcp_tool",
]


class FastMCPOpenAPI:
    """FastMCP OpenAPI 文档挂载器

    Args:
        mcp:         FastMCP server 实例
        title:       文档标题
        version:     文档版本
        description: 文档描述
        base_url:    服务器基础 URL
        config:      完整配置对象（优先于单独参数）
        verbose:     是否打印调试信息
    """

    def __init__(
        self,
        mcp,
        *,
        title: str = "MCP Tools API",
        version: str = "1.0.0",
        description: str = "",
        base_url: str | None = None,
        config: FastMCPOpenAPIConfig | None = None,
        verbose: bool = False,
    ) -> None:
        self.mcp = mcp
        self.config = config or FastMCPOpenAPIConfig(
            title=title,
            version=version,
            description=description,
            base_url=base_url or "",
            verbose=verbose,
        )
        self._extractor = ToolExtractor(verbose=self.config.verbose)
        self._registry: dict = {}

    async def setup(self) -> None:
        """提取所有 tool 信息并注册文档路由。"""
        if self.config.verbose:
            print("[fastmcp_openapi] 开始提取 tool 信息…")

        self._registry = await self._extractor.extract(self.mcp)

        registrar = RouteRegistrar(self.mcp, self.config, self._registry)
        registrar.register_all()

        if self.config.verbose:
            print(
                f"[fastmcp_openapi] 完成，共 {len(self._registry)} 个 tool。"
                f" 文档：{self.config.base_url}{self.config.docs_ui_route}"
            )
