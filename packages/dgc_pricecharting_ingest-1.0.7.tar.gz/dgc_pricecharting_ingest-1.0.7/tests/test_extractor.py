# tests/test_extractor.py

import pytest

from dgc_pricecharting_ingest.extractor import (
    _extract_full_detail_value,
    _label_to_pattern,
    extract_card_number,
    extract_image_info,
    extract_pricecharting_id,
)


# ---------------------------
# Helper tests
# ---------------------------

def test_label_to_pattern_matches_normal_label():
    pattern = _label_to_pattern("PriceCharting ID")

    assert pattern.match("PriceCharting ID")
    assert pattern.match("PriceCharting ID:")
    assert pattern.match("  PriceCharting   ID  ")
    assert pattern.match("  PriceCharting   ID:  ")


def test_label_to_pattern_does_not_match_wrong_label():
    pattern = _label_to_pattern("PriceCharting ID")

    assert not pattern.match("Card Number:")
    assert not pattern.match("Price Charting ID:")
    assert not pattern.match("PriceCharting Product ID:")


def test_extract_full_detail_value_returns_value():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">7307259</td>
        </tr>
      </table>
    </div>
    """

    assert _extract_full_detail_value(html, "PriceCharting ID") == "7307259"


def test_extract_full_detail_value_returns_none_without_full_details():
    html = """
    <div id="other">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">7307259</td>
        </tr>
      </table>
    </div>
    """

    assert _extract_full_detail_value(html, "PriceCharting ID") is None


def test_extract_full_detail_value_returns_none_without_matching_label():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td class="details">#85</td>
        </tr>
      </table>
    </div>
    """

    assert _extract_full_detail_value(html, "PriceCharting ID") is None


def test_extract_full_detail_value_returns_none_when_matching_label_has_no_sibling_td():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
        </tr>
      </table>
    </div>
    """

    assert _extract_full_detail_value(html, "PriceCharting ID") is None


def test_extract_full_detail_value_returns_none_when_value_is_empty():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">     </td>
        </tr>
      </table>
    </div>
    """

    assert _extract_full_detail_value(html, "PriceCharting ID") is None


def test_extract_full_detail_value_supports_nested_label_text():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting <span>ID:</span></td>
          <td class="details">5834844</td>
        </tr>
      </table>
    </div>
    """

    assert _extract_full_detail_value(html, "PriceCharting ID") == "5834844"


def test_extract_full_detail_value_supports_nested_value_text():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td class="details"><span>#</span><strong>85</strong></td>
        </tr>
      </table>
    </div>
    """

    assert _extract_full_detail_value(html, "Card Number") == "# 85"


# ---------------------------
# PriceCharting ID tests
# ---------------------------

def test_extracts_numeric_id():
    html = """
    <div id="full_details">
      <table id="attribute">
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">7307259</td>
        </tr>
      </table>
    </div>
    """

    assert extract_pricecharting_id(html) == "7307259"


def test_extract_pricecharting_id_returns_none_when_no_full_details():
    html = """
    <div id="other">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">999999</td>
        </tr>
      </table>
    </div>
    """

    assert extract_pricecharting_id(html) is None


def test_extract_pricecharting_id_ignores_value_outside_full_details():
    html = """
    <div id="other">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">999999</td>
        </tr>
      </table>
    </div>
    <div id="full_details">
      <p>some other content</p>
    </div>
    """

    assert extract_pricecharting_id(html) is None


def test_extract_pricecharting_id_returns_none_when_title_has_no_sibling_details_td():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
        </tr>
      </table>
    </div>
    """

    assert extract_pricecharting_id(html) is None


def test_extract_pricecharting_id_returns_none_when_details_contains_no_digits():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">none</td>
        </tr>
      </table>
    </div>
    """

    assert extract_pricecharting_id(html) is None


def test_extracts_first_numeric_token_from_mixed_text():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">ref: abc123 def456</td>
        </tr>
      </table>
    </div>
    """

    assert extract_pricecharting_id(html) == "123"


def test_matches_case_and_whitespace_variants():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">  PriceCharting   ID  </td>
          <td class="details">  98765  </td>
        </tr>
      </table>
    </div>
    """

    assert extract_pricecharting_id(html) == "98765"


def test_multiple_pricecharting_rows_returns_first_found():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">111 222</td>
        </tr>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td class="details">333</td>
        </tr>
      </table>
    </div>
    """

    assert extract_pricecharting_id(html) == "111"


def test_extract_pricecharting_id_with_nested_label_text():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting <span>ID:</span></td>
          <td class="details">5834844</td>
        </tr>
      </table>
    </div>
    """

    assert extract_pricecharting_id(html) == "5834844"


# ---------------------------
# Card Number tests
# ---------------------------

def test_extract_card_number_with_hash():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td>#123</td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) == "123"


def test_extract_card_number_without_hash():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td>ST09-001</td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) == "ST09-001"


def test_extract_card_number_with_spaces():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">  Card Number  </td>
          <td>   #45   </td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) == "45"


def test_extract_card_number_no_hash_no_trim_needed():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td>ABC-999</td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) == "ABC-999"


def test_extract_card_number_no_full_details():
    html = "<html><body><p>No details here</p></body></html>"

    assert extract_card_number(html) is None


def test_extract_card_number_no_matching_title():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">PriceCharting ID:</td>
          <td>#888</td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) is None


def test_extract_card_number_empty_value():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td></td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) is None


def test_extract_card_number_with_linebreaks():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td class="details" itemprop="model-number">
              #34
          </td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) == "34"


def test_extract_card_number_keeps_complex_card_number():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td class="details">#54/L-P</td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) == "54/L-P"


def test_extract_card_number_keeps_slashes_and_letters():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td class="details">001/198</td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) == "001/198"


def test_extract_card_number_with_nested_label_text():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card <span>Number:</span></td>
          <td class="details">#85</td>
        </tr>
      </table>
    </div>
    """

    assert extract_card_number(html) == "85"


def test_extract_card_number_with_nested_hash_and_number_value():
    html = """
    <div id="full_details">
      <table>
        <tr>
          <td class="title">Card Number:</td>
          <td class="details"><span>#</span><strong>85</strong></td>
        </tr>
      </table>
    </div>
    """

    # BeautifulSoup joins nested text with a space, so "# 85" becomes "85" after lstrip("#").strip().
    assert extract_card_number(html) == "85"


# ---------------------------
# Image info tests
# ---------------------------

@pytest.mark.parametrize(
    "image_id,size",
    [
        ("abc123xyz", 240),
        ("testid987", 600),
        ("id180", 180),
        ("5e96704258cea7c698de7602006f71dfe88d868c0c9585a1e11055de7d488007", 240),
    ],
)
def test_extract_image_info_valid_images(image_id, size):
    html = f"""
    <div id="product_details">
      <div class="cover">
        <a>
          <img src="https://storage.googleapis.com/images.pricecharting.com/{image_id}/{size}.jpg">
        </a>
      </div>
    </div>
    """

    info = extract_image_info(html)

    assert info == {
        "image_id": image_id,
        "no_image": False,
    }


def test_extract_image_info_valid_image_with_query_string():
    html = """
    <div id="product_details">
      <div class="cover">
        <img src="https://storage.googleapis.com/images.pricecharting.com/abc123/240.jpg?foo=bar">
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": "abc123",
        "no_image": False,
    }


def test_extract_image_info_valid_image_case_insensitive_domain_and_extension():
    html = """
    <div id="product_details">
      <div class="cover">
        <img src="HTTPS://STORAGE.GOOGLEAPIS.COM/IMAGES.PRICECHARTING.COM/abc123/240.JPG">
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": "abc123",
        "no_image": False,
    }


def test_extract_image_info_placeholder_no_image():
    html = """
    <div id="product_details">
      <div class="cover">
        <a>
          <img src="/images/no-image-available.png">
        </a>
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": True,
    }


def test_extract_image_info_placeholder_case_insensitive():
    html = """
    <div id="product_details">
      <div class="cover">
        <img src="/images/NO-IMAGE-AVAILABLE.png">
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": True,
    }


def test_extract_image_info_missing_img_tag():
    html = """
    <div id="product_details">
      <div class="cover"></div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": False,
    }


def test_extract_image_info_unexpected_src():
    html = """
    <div id="product_details">
      <div class="cover">
        <a>
          <img src="https://cdn.example.com/images/foo.png">
        </a>
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": False,
    }


def test_extract_image_info_missing_product_div():
    html = """
    <div>
      <a>
        <img src="https://storage.googleapis.com/images.pricecharting.com/xyz/240.jpg">
      </a>
    </div>
    """

    assert extract_image_info(html) is None


def test_extract_image_info_missing_src_attribute():
    html = """
    <div id="product_details">
      <div class="cover">
        <a><img></a>
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": False,
    }


def test_extract_image_info_empty_src_attribute():
    html = """
    <div id="product_details">
      <div class="cover">
        <img src="   ">
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": False,
    }


def test_extract_image_info_ignores_image_outside_product_details():
    html = """
    <div>
      <div class="cover">
        <img src="https://storage.googleapis.com/images.pricecharting.com/outside/240.jpg">
      </div>
    </div>
    <div id="product_details">
      <div class="cover"></div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": False,
    }


def test_extract_image_info_uses_first_cover_image_inside_product_details():
    html = """
    <div id="product_details">
      <div class="cover">
        <img src="https://storage.googleapis.com/images.pricecharting.com/first/240.jpg">
        <img src="https://storage.googleapis.com/images.pricecharting.com/second/240.jpg">
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": "first",
        "no_image": False,
    }


def test_extract_image_info_requires_numeric_size_filename():
    html = """
    <div id="product_details">
      <div class="cover">
        <img src="https://storage.googleapis.com/images.pricecharting.com/abc123/small.jpg">
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": False,
    }


def test_extract_image_info_rejects_non_jpg_extension():
    html = """
    <div id="product_details">
      <div class="cover">
        <img src="https://storage.googleapis.com/images.pricecharting.com/abc123/240.png">
      </div>
    </div>
    """

    assert extract_image_info(html) == {
        "image_id": None,
        "no_image": False,
    }