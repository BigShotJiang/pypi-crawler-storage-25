# tests/test_pricecharting.py

import pytest

import dgc_pricecharting_ingest.pricecharting as pricecharting
from dgc_pricecharting_ingest.pricecharting import product_exists


class MockFetchResponse:
    def __init__(self, status_code=200, content=None):
        self.status_code = status_code
        self.content = content


@pytest.fixture(autouse=True)
def patch_config(monkeypatch):
    monkeypatch.setattr(pricecharting, "PRICECHARTING_TOKEN", "test-token")
    monkeypatch.setattr(
        pricecharting,
        "PRICECHARTING_PRODUCT_API_URL",
        "https://www.pricecharting.com/api/product",
    )
    monkeypatch.setattr(
        pricecharting,
        "PRICECHARTING_PRODUCT_NOT_FOUND_MESSAGE",
        "no such product",
    )
    monkeypatch.setattr(pricecharting, "FETCH_RETRIES", 1)
    monkeypatch.setattr(pricecharting, "FETCH_TIMEOUT_SECONDS", 5)

    # Silence logs during tests.
    monkeypatch.setattr(pricecharting, "log", lambda *args, **kwargs: None)


def test_product_exists_true(monkeypatch):
    """200 OK with normal product JSON -> True"""

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(
            status_code=200,
            content={"id": 8314662, "name": "Example"},
        )

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(8314662) is True


def test_product_not_found_404(monkeypatch):
    """HTTP 404 -> False"""

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(status_code=404, content=None)

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(9999999) is False


def test_product_not_found_json_error(monkeypatch):
    """200 with {'status':'error','error':'No such product'} -> False"""

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(
            status_code=200,
            content={"status": "error", "error": "No such product"},
        )

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(12345) is False


def test_product_not_found_json_error_alt_field(monkeypatch):
    """200 with {'status':'error','error-message':'No such product'} -> False"""

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(
            status_code=200,
            content={"status": "error", "error-message": "No such product"},
        )

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(12345) is False


def test_unknown_on_server_error(monkeypatch):
    """Non-200 and non-404 -> None"""

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(status_code=500, content=None)

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(1) is None


def test_unknown_on_network_error(monkeypatch):
    """fetch_url raises -> None"""

    def mock_fetch_url(**kwargs):
        raise RuntimeError("network error")

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(1) is None


def test_unknown_when_error_but_not_no_such_product(monkeypatch):
    """200 + status:error but not no-such-product -> None"""

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(
            status_code=200,
            content={"status": "error", "error": "Some other error happened"},
        )

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(1) is None


def test_product_exists_with_non_dict_json(monkeypatch):
    """200 with non-dict JSON -> None"""

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(status_code=200, content=[1, 2, 3])

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(42) is None


def test_product_exists_dict_without_status(monkeypatch):
    """200 with dict JSON but no status field -> True"""

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(
            status_code=200,
            content={"id": 8314662, "name": "Example"},
        )

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(8314662) is True


def test_missing_token_raises(monkeypatch):
    """Missing PRICECHARTING_TOKEN is config error."""

    monkeypatch.setattr(pricecharting, "PRICECHARTING_TOKEN", None)

    with pytest.raises(RuntimeError, match="PRICECHARTING_TOKEN"):
        product_exists(1)


def test_fetch_url_called_with_expected_args(monkeypatch):
    """Verify API call params are correct."""

    calls = []

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        return MockFetchResponse(
            status_code=200,
            content={"id": 123, "name": "Example"},
        )

    monkeypatch.setattr(pricecharting, "fetch_url", mock_fetch_url)

    assert product_exists(123) is True

    assert calls == [
        {
            "url": "https://www.pricecharting.com/api/product",
            "params": {
                "t": "test-token",
                "id": "123",
            },
            "retries": 1,
            "timeout": 5,
            "extra_retryable_status_codes": {403},
            "response_type": "json",
        }
    ]