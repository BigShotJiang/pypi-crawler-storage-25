# tests/test_url.py

import pytest
import dgc_pricecharting_ingest.url as url_module
from dgc_pricecharting_ingest.url import _simple_slug, pricecharting_url, get_card_manual_url

BASE_PC = url_module.PRICECHARTING_BASE_URL
BASE_SC = url_module.SPORTSCARDS_BASE_URL

class MockFetchResponse:
    def __init__(self, status_code=200, content=None):
        self.status_code = status_code
        self.content = content

@pytest.fixture(autouse=True)
def reset_manual_url_cache():
    url_module._manual_url_cache = None
    yield
    url_module._manual_url_cache = None

# ----------------------------
# Test pricecharting_url examples with collection_name
# ----------------------------
@pytest.mark.parametrize(
    "collection_name,console,product,expected",
    [
        (url_module.COL_CARDS, "Atari ST", "Leisure Suit Larry 1, 2 & 3", f"{BASE_PC}/atari-st/leisure-suit-larry-1-2-&-3"),
        (url_module.COL_CARDS, "Magic Warhammer 40,000", "Celestine, the Living Saint #10", f"{BASE_PC}/magic-warhammer-40,000/celestine-the-living-saint-10"),
        (url_module.COL_CARDS, "Magic Unstable", "Half-Shark, Half-", f"{BASE_PC}/magic-unstable/half-shark-half-"),
        (url_module.COL_CARDS, "Magic Unfinity", "How Is This a Par Three?! [Galaxy Foil]", f"{BASE_PC}/magic-unfinity/how-is-this-a-par-three-galaxy-foil"),
        (url_module.COL_CARDS, "Magic Unhinged", "Framed! [Foil]", f"{BASE_PC}/magic-unhinged/framed-foil"),
        (url_module.COL_CARDS, "Amiga", "Monkey Island 2: LeChuck’s Revenge", f"{BASE_PC}/amiga/monkey-island-2-lechuck’s-revenge"),
        (url_module.COL_CARDS, "Pokemon Japanese Promo", "Umbreon [Daisuki Club 7,200 Pts.] #54/L-P", f"{BASE_PC}/pokemon-japanese-promo/umbreon-daisuki-club-7,200-pts-54l-p"),
        (url_module.COL_CARDS, "Pokemon Japanese Promo", "PokePark‘s Celebi #44/PCG-P", f"{BASE_PC}/pokemon-japanese-promo/pokepark‘s-celebi-44pcg-p"),
        (url_module.COL_CARDS, "Pokemon Japanese Gaia Volcano", "Nidoran♀ #25", f"{BASE_PC}/pokemon-japanese-gaia-volcano/nidoran♀-25"),
        (url_module.COL_CARDS, "Pokemon Japanese Cruel Traitor", "Nidoran♂ #20", f"{BASE_PC}/pokemon-japanese-cruel-traitor/nidoran♂-20"),
        (url_module.COL_CARDS, "Magic Unstable", "Monkey-", f"{BASE_PC}/magic-unstable/monkey-"),
        (url_module.COL_CARDS, "Magic Unhinged", "_____ [Foil]", f"{BASE_PC}/magic-unhinged/_____-foil"),
        (url_module.COL_CARDS, "Magic Commander 2013", "Borrowing 100,000 Arrows", f"{BASE_PC}/magic-commander-2013/borrowing-100,000-arrows"),
        (url_module.COL_CARDS, "Lorcana Ursula's Return", "Flotsam - Ursula's \"Baby\" #43", f"{BASE_PC}/lorcana-ursula's-return/flotsam-ursula's-\"baby\"-43"),
        (url_module.COL_CARDS, "YuGiOh World Championship 2025 Limited Pack", "Maliss <C> GWC-06 [Emblazoned] 25LP-EN017", f"{BASE_PC}/yugioh-world-championship-2025-limited-pack/maliss-<c>-gwc-06-emblazoned-25lp-en017"),
        (url_module.COL_CARDS, "YuGiOh 2025 Mega Pack Tin", "S:P Little Knight MP25-EN047", f"{BASE_PC}/yugioh-2025-mega-pack-tin/sp-little-knight-mp25-en047"),
        (url_module.COL_CARDS, "YuGiOh Tactical Evolution", "Damage = Reptile TAEV-EN067", f"{BASE_PC}/yugioh-tactical-evolution/damage-=-reptile-taev-en067"),
        (url_module.COL_CARDS, "YuGiOh Ignition Assault", "Water Leviathan @Ignister IGAS-EN034", f"{BASE_PC}/yugioh-ignition-assault/water-leviathan-@ignister-igas-en034"),
        (url_module.COL_CARDS, "YuGiOH Japanese Booster Pack Collectors Tin", "Chaos Emperor Dragon - Envoy of the End BPT-J02", f"{BASE_PC}/yugioh-japanese-booster-pack-collectors-tin/chaos-emperor-dragon-envoy-of-the-end-bpt-j02"),
        (url_module.COL_CARDS, "Atari 2600", "M*A*S*H", f"{BASE_PC}/atari-2600/m*a*s*h"),
        (url_module.COL_CARDS, "Asian English Playstation Vita", "Hyperdimension Neptunia Re;Birth1", f"{BASE_PC}/asian-english-playstation-vita/hyperdimension-neptunia-re;birth1"),
        (url_module.COL_CARDS, "Amiga", "Darius+", f"{BASE_PC}/amiga/darius+"),
        (url_module.COL_CARDS, "Pokemon 2001 Topps Johto", "Unstoppable Team! [Foil]", f"{BASE_PC}/pokemon-2001-topps-johto/unstoppable-team-foil"),
        (url_module.COL_CARDS, "Pokemon 1999 Topps Movie", "Don't Cry, Togepi [Rainbow Foil] #43", f"{BASE_PC}/pokemon-1999-topps-movie/don't-cry-togepi-rainbow-foil-43"),
        (url_module.COL_CARDS, "Apple II", "Death Race '82", f"{BASE_PC}/apple-ii/death-race-'82"),
        (url_module.COL_CARDS, "Pokemon 1998 KFC", "Charizard #6", f"{BASE_PC}/pokemon-1998-kfc/charizard-6"),
        (url_module.COL_CARDS, "Pokemon 1999 Topps Movie", "A Call to Arms [Foil] #16", f"{BASE_PC}/pokemon-1999-topps-movie/a-call-to-arms-foil-16"),
        (url_module.COL_CARDS, "Pokemon Astral Radiance", "Build & Battle Display Box", f"{BASE_PC}/pokemon-astral-radiance/build-&-battle-display-box"),
    ]
)
def test_examples_full_url(collection_name, console, product, expected):
    assert pricecharting_url(collection_name, console, product) == expected

# ----------------------------
# _simple_slug tests
# ----------------------------
@pytest.mark.parametrize(
    "raw,expected_slug",
    [
        ("A Call to Arms [Foil] #16", "a-call-to-arms-foil-16"),
        ("Build & Battle   Display Box  ", "build-&-battle-display-box"),
        ("  Pokemon   Astral Radiance  ", "pokemon-astral-radiance"),
        ("Hello/World Edition", "helloworld-edition"),
        ("A - - B", "a-b"),
        ("Monkey-", "monkey-"),
        ("Half-Shark, Half-", "half-shark-half-"),
        ("Borrowing 100,000 Arrows", "borrowing-100,000-arrows"),
    ]
)
def test_simple_slug_behaviour(raw, expected_slug):
    assert _simple_slug(raw) == expected_slug


def test_slug_and_url_consistency_with_ampersand():
    console = "Pokemon Astral Radiance"
    product = "Build & Battle Display Box"
    slug = _simple_slug(product)
    assert slug == "build-&-battle-display-box"
    assert pricecharting_url(url_module.COL_CARDS, console, product).endswith("/" + slug)


def test_empty_inputs():
    assert _simple_slug("") == ""
    assert pricecharting_url(url_module.COL_CARDS, "", "") == f"{BASE_PC}//"

# ----------------------------
# get_card_manual_url tests
# ----------------------------
def test_get_card_manual_url_returns_matching_url(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", "https://api.example.com")
    monkeypatch.setattr(url_module, "API_LOAD_TIMEOUT_SECONDS", 10)

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(
            status_code=200,
            content={
                "123": f"{BASE_PC}/pokemon-promo/pikachu-85",
                "456": f"{BASE_SC}/magic-unstable/monkey-",
            },
        )

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)
    assert get_card_manual_url(123) == f"{BASE_PC}/pokemon-promo/pikachu-85"
    assert get_card_manual_url(456) == f"{BASE_SC}/magic-unstable/monkey-"


def test_get_card_manual_url_returns_none_when_card_missing(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", "https://api.example.com")

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(status_code=200, content={"123": "url"})

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)
    assert get_card_manual_url(999) is None


def test_get_card_manual_url_converts_numeric_keys_and_values_to_strings(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", "https://api.example.com")

    def mock_fetch_url(**kwargs):
        return MockFetchResponse(status_code=200, content={123: f"{BASE_PC}/pokemon-promo/pikachu-85", 456: 789, None: "ignored", 777: ""})

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)

    assert get_card_manual_url(123) == f"{BASE_PC}/pokemon-promo/pikachu-85"
    assert get_card_manual_url(456) == "789"
    assert get_card_manual_url(777) is None


def test_get_card_manual_url_uses_cache_after_first_success(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", "https://api.example.com")

    calls = []

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        return MockFetchResponse(status_code=200, content={"123": f"{BASE_PC}/pokemon-promo/pikachu-85"})

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)

    assert get_card_manual_url(123) == f"{BASE_PC}/pokemon-promo/pikachu-85"
    assert get_card_manual_url(123) == f"{BASE_PC}/pokemon-promo/pikachu-85"
    assert len(calls) == 1


def test_get_card_manual_url_returns_none_when_api_url_missing(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", None)
    monkeypatch.setattr(url_module, "log", lambda *args, **kwargs: None)

    def mock_fetch_url(**kwargs):
        raise AssertionError("fetch_url should not be called when API_URL is missing")

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)
    assert get_card_manual_url(123) is None


def test_get_card_manual_url_returns_none_and_does_not_cache_on_fetch_error(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", "https://api.example.com")
    monkeypatch.setattr(url_module, "log", lambda *args, **kwargs: None)

    calls = []

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        raise RuntimeError("network error")

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)

    assert get_card_manual_url(123) is None
    assert get_card_manual_url(123) is None
    assert len(calls) == 2


def test_get_card_manual_url_returns_none_and_does_not_cache_on_non_200(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", "https://api.example.com")
    monkeypatch.setattr(url_module, "log", lambda *args, **kwargs: None)

    calls = []

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        return MockFetchResponse(status_code=500, content={})

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)

    assert get_card_manual_url(123) is None
    assert get_card_manual_url(123) is None
    assert len(calls) == 2


def test_get_card_manual_url_returns_none_and_does_not_cache_invalid_response(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", "https://api.example.com")
    monkeypatch.setattr(url_module, "log", lambda *args, **kwargs: None)

    calls = []

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        return MockFetchResponse(status_code=200, content=["not", "a", "dict"])

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)

    assert get_card_manual_url(123) is None
    assert get_card_manual_url(123) is None
    assert len(calls) == 2


def test_get_card_manual_url_fetch_url_called_with_expected_args(monkeypatch):
    monkeypatch.setattr(url_module, "API_URL", "https://api.example.com")
    monkeypatch.setattr(url_module, "API_LOAD_TIMEOUT_SECONDS", 7)

    calls = []

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        return MockFetchResponse(status_code=200, content={})

    monkeypatch.setattr(url_module, "fetch_url", mock_fetch_url)

    assert get_card_manual_url(123) is None
    assert calls == [{"url": "https://api.example.com/pricecharting-ingest-urls", "timeout": 7, "response_type": "json"}]
