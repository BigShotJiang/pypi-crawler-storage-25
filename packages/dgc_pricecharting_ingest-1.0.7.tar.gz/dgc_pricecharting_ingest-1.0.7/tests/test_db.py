# tests/test_db.py

import os
from datetime import datetime, timezone

import pytest

# Set required environment variables for testing
os.environ["MONGO_URI_PRICES"] = "mongodb://test:27017"
os.environ["DB"] = "test_db"
os.environ["COL_CARDS"] = "cards"
os.environ["COL_SPORTS_CARDS"] = "sports_cards"
os.environ["ALLOWED_SERVICE_ACCOUNT"] = "test-sa@example.com"
os.environ["ALLOWED_AUDIENCE"] = "test-audience"
os.environ["API_URL"] = "https://api.example.com"
os.environ["API_LOAD_TIMEOUT_SECONDS"] = "10"
os.environ["FIREBASE_STORAGE_BUCKET"] = "test-bucket"
os.environ["FIREBASE_IMAGE_DEST_PREFIX"] = "images/"
os.environ["PRICECHARTING_TOKEN"] = "test-token"
os.environ["PRICECHARTING_PRODUCT_API_URL"] = "https://api.example.com/product"
os.environ["PRICECHARTING_PRODUCT_NOT_FOUND_MESSAGE"] = "Not found"
os.environ["PRICECHARTING_BASE_URL"] = "https://www.pricecharting.com/game"
os.environ["SPORTSCARDS_BASE_URL"] = "https://www.sportscards.com/game"
os.environ["FETCH_RETRIES"] = "10"
os.environ["FETCH_TIMEOUT_SECONDS"] = "10"

import dgc_pricecharting_ingest.db as cards_client


COL_CARDS = "cards"
COL_SPORTS_CARDS = "sports_cards"


class FakeCollection:
    def __init__(self, name: str):
        self.name = name
        self.calls = []

    def update_one(self, filter_doc, update_doc):
        self.calls.append((_deepcopy(filter_doc), _deepcopy(update_doc)))

        class Result:
            matched_count = 1
            modified_count = 1

        return Result()


class FakeDB:
    def __init__(self):
        self.collections = {}

    def __getitem__(self, collection_name):
        if collection_name not in self.collections:
            self.collections[collection_name] = FakeCollection(collection_name)

        return self.collections[collection_name]


def _deepcopy(obj):
    if isinstance(obj, dict):
        return {key: _deepcopy(value) for key, value in obj.items()}

    if isinstance(obj, list):
        return [_deepcopy(value) for value in obj]

    return obj


def assert_utc_datetime(value):
    assert isinstance(value, datetime)
    assert value.tzinfo is not None
    assert value.tzinfo.utcoffset(value) == timezone.utc.utcoffset(value)


def assert_no_touched_fields(set_doc):
    assert "touched" not in set_doc
    assert "touchedAt" not in set_doc


@pytest.fixture(autouse=True)
def env_and_reset(monkeypatch):
    monkeypatch.setenv("MONGO_URI_PRICES", "mongodb://test:27017")
    monkeypatch.setattr(
        cards_client,
        "MONGO_URI_PRICES",
        os.getenv("MONGO_URI_PRICES"),
        raising=False,
    )

    monkeypatch.setattr(cards_client, "_db_client", None, raising=False)
    monkeypatch.setattr(cards_client, "_collections", {}, raising=False)

    yield

    monkeypatch.setattr(cards_client, "_db_client", None, raising=False)
    monkeypatch.setattr(cards_client, "_collections", {}, raising=False)


@pytest.fixture
def fake_db(monkeypatch):
    db = FakeDB()

    monkeypatch.setattr(
        cards_client._mongo_cache,
        "get_db",
        lambda uri, db_name: db,
        raising=True,
    )

    cards_client._db_client = None
    cards_client._collections = {}

    return db


@pytest.fixture
def fake_collection(fake_db):
    return fake_db[COL_CARDS]


def test_get_collection_happy_path(monkeypatch):
    fake_db = FakeDB()
    calls = []

    def fake_get_db(uri, db_name):
        calls.append((uri, db_name))
        assert uri == cards_client.MONGO_URI_PRICES
        assert db_name == cards_client.DB
        return fake_db

    monkeypatch.setattr(cards_client._mongo_cache, "get_db", fake_get_db, raising=True)

    coll = cards_client._get_collection(COL_CARDS)
    coll2 = cards_client._get_collection(COL_CARDS)

    assert coll is fake_db[COL_CARDS]
    assert coll2 is fake_db[COL_CARDS]
    assert calls == [(cards_client.MONGO_URI_PRICES, cards_client.DB)]


def test_get_collection_caches_multiple_collections(monkeypatch):
    fake_db = FakeDB()
    calls = []

    def fake_get_db(uri, db_name):
        calls.append((uri, db_name))
        return fake_db

    monkeypatch.setattr(cards_client._mongo_cache, "get_db", fake_get_db, raising=True)

    cards_collection = cards_client._get_collection(COL_CARDS)
    sports_collection = cards_client._get_collection(COL_SPORTS_CARDS)

    assert cards_collection is fake_db[COL_CARDS]
    assert sports_collection is fake_db[COL_SPORTS_CARDS]
    assert cards_collection is not sports_collection
    assert cards_client._collections[COL_CARDS] is cards_collection
    assert cards_client._collections[COL_SPORTS_CARDS] is sports_collection
    assert len(calls) == 1


def test_get_collection_reuses_existing_db_client(monkeypatch):
    fake_db = FakeDB()
    calls = []

    def fake_get_db(uri, db_name):
        calls.append((uri, db_name))
        return fake_db

    monkeypatch.setattr(cards_client._mongo_cache, "get_db", fake_get_db, raising=True)

    cards_client._db_client = fake_db
    cards_client._collections = {}

    coll = cards_client._get_collection(COL_CARDS)

    assert coll is fake_db[COL_CARDS]
    assert calls == []


def test_get_collection_raises_when_collection_name_missing():
    with pytest.raises(RuntimeError, match="collection_name"):
        cards_client._get_collection("")


def test_now_returns_utc_datetime():
    now = cards_client._now()
    assert_utc_datetime(now)


def test_mark_card_uploaded_updates_correct_fields(fake_collection):
    cards_client.mark_card_uploaded(COL_CARDS, 42, "image_id")

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]

    assert filter_doc == {"id": 42}
    assert set_doc["uploadStatus.imagesUploaded"] is True
    assert set_doc["imageId"] == "image_id"
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)

    assert update_doc["$unset"] == {
        "uploadStatus.invalidUrl": "",
        "uploadStatus.noImage": "",
        "uploadStatus.uploadFailed": "",
        "uploadStatus.lastError": "",
    }


def test_mark_card_noimage_updates_correct_fields(fake_collection):
    cards_client.mark_card_noimage(COL_CARDS, 99)

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]

    assert filter_doc == {"id": 99}
    assert set_doc["uploadStatus.noImage"] is True
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)

    assert update_doc["$unset"] == {
        "uploadStatus.invalidUrl": "",
        "uploadStatus.uploadFailed": "",
        "uploadStatus.lastError": "",
    }


def test_mark_card_deleted_sets_deleted_and_updated_at(fake_collection):
    cards_client.mark_card_deleted(COL_CARDS, 314)

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]

    assert filter_doc == {"id": 314}
    assert set_doc["deleted"] is True
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)


def test_mark_card_invalid_url_sets_flag_and_updated_at(fake_collection):
    cards_client.mark_card_invalid_url(COL_CARDS, 7)

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]

    assert filter_doc == {"id": 7}
    assert set_doc["uploadStatus.invalidUrl"] is True
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)

    assert "uploadStatus.lastError" not in set_doc
    assert update_doc["$unset"] == {
        "uploadStatus.uploadFailed": "",
    }


def test_mark_card_invalid_url_sets_last_error_when_reason_given(fake_collection):
    cards_client.mark_card_invalid_url(
        COL_CARDS,
        7,
        reason="pricecharting_id_mismatch",
        message="Expected 7, got 8",
    )

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]
    last_error = set_doc["uploadStatus.lastError"]

    assert filter_doc == {"id": 7}
    assert set_doc["uploadStatus.invalidUrl"] is True
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)

    assert last_error["reason"] == "pricecharting_id_mismatch"
    assert last_error["message"] == "Expected 7, got 8"
    assert_utc_datetime(last_error["at"])

    assert update_doc["$unset"] == {
        "uploadStatus.uploadFailed": "",
    }


def test_mark_card_invalid_url_defaults_reason_when_only_message_given(fake_collection):
    cards_client.mark_card_invalid_url(
        COL_CARDS,
        8,
        message="Missing image ID",
    )

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]
    last_error = set_doc["uploadStatus.lastError"]

    assert filter_doc == {"id": 8}
    assert last_error["reason"] == "invalid_url"
    assert last_error["message"] == "Missing image ID"
    assert_utc_datetime(last_error["at"])
    assert_no_touched_fields(set_doc)


def test_mark_card_upload_failed_sets_failed_status_and_last_error(fake_collection):
    cards_client.mark_card_upload_failed(
        COL_CARDS,
        123,
        reason="all_uploads_failed",
        message="All image downloads/uploads failed",
    )

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]
    last_error = set_doc["uploadStatus.lastError"]

    assert filter_doc == {"id": 123}
    assert set_doc["uploadStatus.uploadFailed"] is True
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)

    assert last_error["reason"] == "all_uploads_failed"
    assert last_error["message"] == "All image downloads/uploads failed"
    assert_utc_datetime(last_error["at"])

    assert update_doc["$unset"] == {
        "uploadStatus.imagesUploaded": "",
        "uploadStatus.noImage": "",
    }


def test_mark_card_upload_failed_allows_none_message(fake_collection):
    cards_client.mark_card_upload_failed(
        COL_CARDS,
        123,
        reason="firebase_permission_error",
    )

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]
    last_error = set_doc["uploadStatus.lastError"]

    assert filter_doc == {"id": 123}
    assert last_error["reason"] == "firebase_permission_error"
    assert last_error["message"] is None
    assert_utc_datetime(last_error["at"])
    assert_no_touched_fields(set_doc)


def test_update_image_path_sets_field_and_updated_at(fake_collection):
    cards_client.update_image_path(
        COL_CARDS,
        123,
        "small",
        "https://cdn.example/img.jpg",
    )

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]

    assert filter_doc == {"id": 123}
    assert set_doc["images.small"] == "https://cdn.example/img.jpg"
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)


def test_update_image_path_supports_dynamic_size_name(fake_collection):
    cards_client.update_image_path(
        COL_CARDS,
        123,
        "normal",
        "https://cdn.example/normal.jpg",
    )

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]

    assert filter_doc == {"id": 123}
    assert set_doc["images.normal"] == "https://cdn.example/normal.jpg"
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)


def test_update_card_number_sets_card_number_and_updated_at(fake_collection):
    cards_client.update_card_number(COL_CARDS, 555, "A-1")

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]

    assert filter_doc == {"id": 555}
    assert set_doc["cardNumber"] == "A-1"
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)


def test_update_card_number_accepts_none(fake_collection):
    cards_client.update_card_number(COL_CARDS, 555, None)

    assert len(fake_collection.calls) == 1

    filter_doc, update_doc = fake_collection.calls[0]
    set_doc = update_doc["$set"]

    assert filter_doc == {"id": 555}
    assert set_doc["cardNumber"] is None
    assert_utc_datetime(set_doc["updatedAt"])
    assert_no_touched_fields(set_doc)


def test_updates_can_target_sports_cards_collection(fake_db):
    sports_collection = fake_db[COL_SPORTS_CARDS]

    cards_client.mark_card_uploaded(COL_SPORTS_CARDS, 9001, "sports-image-id")
    cards_client.update_image_path(
        COL_SPORTS_CARDS,
        9001,
        "small",
        "https://cdn.example/sports.jpg",
    )

    assert len(sports_collection.calls) == 2

    filter_doc, update_doc = sports_collection.calls[0]
    assert filter_doc == {"id": 9001}
    assert update_doc["$set"]["imageId"] == "sports-image-id"
    assert "touched" not in update_doc["$set"]

    filter_doc, update_doc = sports_collection.calls[1]
    assert filter_doc == {"id": 9001}
    assert update_doc["$set"]["images.small"] == "https://cdn.example/sports.jpg"
    assert "touched" not in update_doc["$set"]

    assert fake_db[COL_CARDS].calls == []


def test_cards_and_sports_cards_are_cached_separately(fake_db):
    cards_client.mark_card_uploaded(COL_CARDS, 1, "cards-image")
    cards_client.mark_card_uploaded(COL_SPORTS_CARDS, 2, "sports-image")

    cards_collection = fake_db[COL_CARDS]
    sports_collection = fake_db[COL_SPORTS_CARDS]

    assert len(cards_collection.calls) == 1
    assert len(sports_collection.calls) == 1

    assert cards_collection.calls[0][0] == {"id": 1}
    assert sports_collection.calls[0][0] == {"id": 2}

    assert cards_client._collections[COL_CARDS] is cards_collection
    assert cards_client._collections[COL_SPORTS_CARDS] is sports_collection


def test_cached_collection_is_used_for_multiple_update_calls(fake_db, monkeypatch):
    get_db_calls = []

    def fake_get_db(uri, db_name):
        get_db_calls.append((uri, db_name))
        return fake_db

    monkeypatch.setattr(cards_client._mongo_cache, "get_db", fake_get_db, raising=True)

    cards_client._db_client = None
    cards_client._collections = {}

    cards_client.mark_card_invalid_url(COL_CARDS, 2)
    cards_client.update_card_number(COL_CARDS, 3, "A-3")
    cards_client.mark_card_upload_failed(COL_CARDS, 4, "all_uploads_failed")

    assert len(fake_db[COL_CARDS].calls) == 3
    assert len(get_db_calls) == 1


def test_update_functions_use_card_id_filter(fake_collection):
    cards_client.mark_card_uploaded(COL_CARDS, 2, "img")
    cards_client.mark_card_noimage(COL_CARDS, 3)
    cards_client.mark_card_deleted(COL_CARDS, 4)
    cards_client.mark_card_invalid_url(COL_CARDS, 5)
    cards_client.mark_card_upload_failed(COL_CARDS, 6, "all_uploads_failed")
    cards_client.update_image_path(COL_CARDS, 7, "small", "url")
    cards_client.update_card_number(COL_CARDS, 8, "CN-8")

    filters = [call[0] for call in fake_collection.calls]

    assert filters == [
        {"id": 2},
        {"id": 3},
        {"id": 4},
        {"id": 5},
        {"id": 6},
        {"id": 7},
        {"id": 8},
    ]