# tests/test_img.py

import importlib
import sys
from types import ModuleType

import pytest


# ---------------------------
# Build firebase_admin mock BEFORE importing dgc_pricecharting_ingest.img
# ---------------------------

mock_firebase_admin = ModuleType("firebase_admin")
mock_firebase_admin._apps = {}

mock_credentials = ModuleType("firebase_admin.credentials")
mock_credentials.ApplicationDefault = staticmethod(lambda: "mock-app-default")
mock_firebase_admin.credentials = mock_credentials

mock_storage = ModuleType("firebase_admin.storage")
mock_firebase_admin.storage = mock_storage

mock_firebase_admin.initialize_app = lambda *args, **kwargs: None

sys.modules["firebase_admin"] = mock_firebase_admin
sys.modules["firebase_admin.credentials"] = mock_credentials
sys.modules["firebase_admin.storage"] = mock_storage


# ---------------------------
# Dummy Firebase Storage objects
# ---------------------------

class DummyBlob:
    def __init__(self, name: str, store: list, fail_on_upload: bool = False):
        self.name = name
        self._store = store
        self._fail_on_upload = fail_on_upload
        self._is_public = False
        self.public_url = f"https://storage.googleapis.com/dummy-bucket/{self.name}"

    def upload_from_string(self, data: bytes, content_type: str | None = None):
        if self._fail_on_upload:
            raise RuntimeError("upload failed")

        self._store.append((self.name, data, content_type))

    def make_public(self):
        self._is_public = True


class DummyBucket:
    def __init__(
        self,
        name: str = "dummy-bucket",
        fail_on_prefixes: list[str] | None = None,
    ):
        self.name = name
        self._store: list[tuple[str, bytes, str | None]] = []
        self._fail_on_prefixes = set(fail_on_prefixes or [])

    def blob(self, path: str) -> DummyBlob:
        should_fail = any(path.startswith(prefix) for prefix in self._fail_on_prefixes)
        return DummyBlob(path, self._store, fail_on_upload=should_fail)

    def get_store(self):
        return list(self._store)


def _bucket_factory(name: str | None = None):
    return DummyBucket(name or "dummy-bucket")


mock_storage.bucket = _bucket_factory


# ---------------------------
# Import module under test after Firebase mocks are installed
# ---------------------------

app_img = importlib.import_module("dgc_pricecharting_ingest.img")


# ---------------------------
# Fixtures
# ---------------------------

@pytest.fixture(autouse=True)
def reset_img_state(monkeypatch):
    app_img.bucket = DummyBucket(name="dummy-bucket")
    monkeypatch.setattr(app_img, "log", lambda *args, **kwargs: None)
    yield
    app_img.bucket = DummyBucket(name="dummy-bucket")


class MockImageResponse:
    def __init__(
        self,
        content: bytes = b"imagedata",
        content_type: str | None = "image/jpeg",
        status_code: int = 200,
    ):
        self.content = content
        self.content_type = content_type
        self.status_code = status_code


# ---------------------------
# download_image tests
# ---------------------------

def test_download_image_success(monkeypatch):
    calls = []

    def mock_fetch_image(**kwargs):
        calls.append(kwargs)
        return MockImageResponse(
            content=b"imagedata",
            content_type="image/jpeg",
        )

    monkeypatch.setattr(app_img, "fetch_image", mock_fetch_image)

    data, content_type = app_img.download_image("https://example.com/1.jpg")

    assert data == b"imagedata"
    assert content_type == "image/jpeg"
    assert calls == [
        {
            "url": "https://example.com/1.jpg",
            "retries": app_img.FETCH_RETRIES,
            "timeout": app_img.FETCH_TIMEOUT_SECONDS,
            "extra_retryable_status_codes": {403},
        }
    ]


def test_download_image_failure(monkeypatch):
    def mock_fetch_image(**kwargs):
        raise RuntimeError("network error")

    monkeypatch.setattr(app_img, "fetch_image", mock_fetch_image)

    data, content_type = app_img.download_image("https://example.com/404.jpg")

    assert data is None
    assert content_type is None


# ---------------------------
# upload_image tests
# ---------------------------

def test_upload_image_success():
    bucket = app_img.bucket
    assert isinstance(bucket, DummyBucket)

    public_url = app_img.upload_image(
        data=b"abc",
        content_type="image/jpeg",
        dest_path="pricecharting/123/tiny.jpg",
    )

    assert public_url == (
        "https://storage.googleapis.com/dummy-bucket/"
        "pricecharting/123/tiny.jpg"
    )
    assert ("pricecharting/123/tiny.jpg", b"abc", "image/jpeg") in bucket.get_store()


# ---------------------------
# download_and_upload_images tests
# ---------------------------

def test_download_and_upload_images_success(monkeypatch):
    uuid_calls = []
    monkeypatch.setattr(
        app_img,
        "generate_uuid",
        lambda mongo_id, card_id: uuid_calls.append((mongo_id, card_id))
        or f"{mongo_id}-{card_id}-uid",
    )

    updates = []
    monkeypatch.setattr(
        app_img,
        "update_image_path",
        lambda collection_name, card_id, name, url: updates.append(
            (collection_name, card_id, name, url)
        ),
    )

    def mock_download_image(url):
        return b"imgbytes-" + url.encode("utf-8"), "image/jpeg"

    monkeypatch.setattr(app_img, "download_image", mock_download_image)

    results, uid = app_img.download_and_upload_images(
        collection_name="cards",
        mongo_id="42",
        card_id=1001,
        image_id="img-abc123",
    )

    assert uuid_calls == [("42", 1001)]
    assert uid == "42-1001-uid"
    assert len(results) == 3
    assert len(updates) == 3

    expected_sizes = {
        "tiny": 120,
        "small": 240,
        "normal": 1600,
    }

    for name, size in expected_sizes.items():
        source_url = (
            f"https://storage.googleapis.com/images.pricecharting.com/"
            f"img-abc123/{size}.jpg"
        )
        uploaded_url = (
            f"https://storage.googleapis.com/dummy-bucket/"
            f"{app_img.FIREBASE_IMAGE_DEST_PREFIX}/42-1001-uid/{size}.jpg"
        )

        assert (source_url, uploaded_url) in results
        assert ("cards", 1001, name, uploaded_url) in updates


def test_download_and_upload_images_uses_custom_sizes_and_dest_prefix(monkeypatch):
    uuid_calls = []
    monkeypatch.setattr(
        app_img,
        "generate_uuid",
        lambda mongo_id, card_id: uuid_calls.append((mongo_id, card_id))
        or "uid-custom",
    )

    updates = []
    monkeypatch.setattr(
        app_img,
        "update_image_path",
        lambda collection_name, card_id, name, url: updates.append(
            (collection_name, card_id, name, url)
        ),
    )

    def mock_download_image(url):
        return b"custom-image", "image/png"

    monkeypatch.setattr(app_img, "download_image", mock_download_image)

    results, uid = app_img.download_and_upload_images(
        collection_name="sports_cards",
        mongo_id="abc",
        card_id=222,
        image_id="image-hash",
        sizes={"thumb": 120, "large": 1600},
        dest_prefix="custom_prefix",
    )

    assert uuid_calls == [("abc", 222)]
    assert uid == "uid-custom"
    assert results == [
        (
            "https://storage.googleapis.com/images.pricecharting.com/image-hash/120.jpg",
            "https://storage.googleapis.com/dummy-bucket/custom_prefix/uid-custom/120.jpg",
        ),
        (
            "https://storage.googleapis.com/images.pricecharting.com/image-hash/1600.jpg",
            "https://storage.googleapis.com/dummy-bucket/custom_prefix/uid-custom/1600.jpg",
        ),
    ]
    assert updates == [
        (
            "sports_cards",
            222,
            "thumb",
            "https://storage.googleapis.com/dummy-bucket/custom_prefix/uid-custom/120.jpg",
        ),
        (
            "sports_cards",
            222,
            "large",
            "https://storage.googleapis.com/dummy-bucket/custom_prefix/uid-custom/1600.jpg",
        ),
    ]


def test_download_and_upload_images_partial_download_failure(monkeypatch):
    monkeypatch.setattr(app_img, "generate_uuid", lambda mongo_id, card_id: "uid-1")

    updates = []
    monkeypatch.setattr(
        app_img,
        "update_image_path",
        lambda collection_name, card_id, name, url: updates.append(
            (collection_name, card_id, name, url)
        ),
    )

    def mock_download_image(url):
        if url.endswith("/240.jpg"):
            return None, None

        return b"good", "image/jpeg"

    monkeypatch.setattr(app_img, "download_image", mock_download_image)

    results, uid = app_img.download_and_upload_images(
        collection_name="cards",
        mongo_id="77",
        card_id=2002,
        image_id="img-zzz",
    )

    assert uid == "uid-1"
    assert len(results) == 3
    assert any(src.endswith("/240.jpg") and uploaded is None for src, uploaded in results)

    assert len(updates) == 2
    assert {name for _, _, name, _ in updates} == {"tiny", "normal"}
    assert all(collection_name == "cards" for collection_name, _, _, _ in updates)


def test_download_and_upload_images_empty_bytes_treated_as_failure(monkeypatch):
    monkeypatch.setattr(app_img, "generate_uuid", lambda mongo_id, card_id: "uid-empty")

    updates = []
    monkeypatch.setattr(
        app_img,
        "update_image_path",
        lambda collection_name, card_id, name, url: updates.append(
            (collection_name, card_id, name, url)
        ),
    )

    def mock_download_image(url):
        return b"", "image/jpeg"

    monkeypatch.setattr(app_img, "download_image", mock_download_image)

    results, uid = app_img.download_and_upload_images(
        collection_name="cards",
        mongo_id="88",
        card_id=3003,
        image_id="img-empty",
        sizes={"tiny": 120},
    )

    assert uid == "uid-empty"
    assert results == [
        (
            "https://storage.googleapis.com/images.pricecharting.com/img-empty/120.jpg",
            None,
        )
    ]
    assert updates == []


def test_download_and_upload_images_upload_failure(monkeypatch):
    monkeypatch.setattr(app_img, "generate_uuid", lambda mongo_id, card_id: "uid-xyz")

    updates = []
    monkeypatch.setattr(
        app_img,
        "update_image_path",
        lambda collection_name, card_id, name, url: updates.append(
            (collection_name, card_id, name, url)
        ),
    )

    def mock_download_image(url):
        return b"ok", "image/jpeg"

    def mock_upload_image(data, content_type, dest_path):
        if dest_path.endswith("/240.jpg"):
            raise RuntimeError("upload failed")

        return f"https://storage.googleapis.com/dummy-bucket/{dest_path}"

    monkeypatch.setattr(app_img, "download_image", mock_download_image)
    monkeypatch.setattr(app_img, "upload_image", mock_upload_image)

    results, uid = app_img.download_and_upload_images(
        collection_name="cards",
        mongo_id="99",
        card_id=3003,
        image_id="img-kkk",
    )

    assert uid == "uid-xyz"
    assert len(results) == 3
    assert any(src.endswith("/240.jpg") and uploaded is None for src, uploaded in results)

    assert len(updates) == 2
    assert {name for _, _, name, _ in updates} == {"tiny", "normal"}


def test_download_and_upload_images_defaults_missing_content_type_to_jpeg(monkeypatch):
    monkeypatch.setattr(app_img, "generate_uuid", lambda mongo_id, card_id: "uid-content-type")

    updates = []
    uploads = []

    monkeypatch.setattr(
        app_img,
        "update_image_path",
        lambda collection_name, card_id, name, url: updates.append(
            (collection_name, card_id, name, url)
        ),
    )

    def mock_download_image(url):
        return b"image-data", None

    def mock_upload_image(data, content_type, dest_path):
        uploads.append((data, content_type, dest_path))
        return f"https://storage.googleapis.com/dummy-bucket/{dest_path}"

    monkeypatch.setattr(app_img, "download_image", mock_download_image)
    monkeypatch.setattr(app_img, "upload_image", mock_upload_image)

    results, uid = app_img.download_and_upload_images(
        collection_name="sports_cards",
        mongo_id="101",
        card_id=4004,
        image_id="img-no-content-type",
        sizes={"tiny": 120},
    )

    assert uid == "uid-content-type"
    assert results == [
        (
            "https://storage.googleapis.com/images.pricecharting.com/"
            "img-no-content-type/120.jpg",
            "https://storage.googleapis.com/dummy-bucket/"
            f"{app_img.FIREBASE_IMAGE_DEST_PREFIX}/uid-content-type/120.jpg",
        )
    ]

    assert uploads == [
        (
            b"image-data",
            "image/jpeg",
            f"{app_img.FIREBASE_IMAGE_DEST_PREFIX}/uid-content-type/120.jpg",
        )
    ]
    assert updates == [
        (
            "sports_cards",
            4004,
            "tiny",
            "https://storage.googleapis.com/dummy-bucket/"
            f"{app_img.FIREBASE_IMAGE_DEST_PREFIX}/uid-content-type/120.jpg",
        )
    ]


def test_download_and_upload_images_does_not_update_db_when_upload_fails(monkeypatch):
    monkeypatch.setattr(app_img, "generate_uuid", lambda mongo_id, card_id: "uid-db-safe")

    updates = []

    monkeypatch.setattr(
        app_img,
        "update_image_path",
        lambda collection_name, card_id, name, url: updates.append(
            (collection_name, card_id, name, url)
        ),
    )

    def mock_download_image(url):
        return b"image-data", "image/jpeg"

    def mock_upload_image(data, content_type, dest_path):
        raise RuntimeError("upload failed")

    monkeypatch.setattr(app_img, "download_image", mock_download_image)
    monkeypatch.setattr(app_img, "upload_image", mock_upload_image)

    results, uid = app_img.download_and_upload_images(
        collection_name="cards",
        mongo_id="202",
        card_id=5005,
        image_id="img-fail",
        sizes={"tiny": 120},
    )

    assert uid == "uid-db-safe"
    assert results == [
        (
            "https://storage.googleapis.com/images.pricecharting.com/img-fail/120.jpg",
            None,
        )
    ]
    assert updates == []