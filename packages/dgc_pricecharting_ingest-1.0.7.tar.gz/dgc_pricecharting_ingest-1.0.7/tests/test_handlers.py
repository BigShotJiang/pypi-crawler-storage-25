# tests/test_handlers.py

import sys
from types import ModuleType

import pytest


# ---------------------------
# Mock firebase_admin BEFORE importing handlers
# because handlers imports img.py, and img.py initializes Firebase at import time.
# ---------------------------

mock_firebase_admin = ModuleType("firebase_admin")
mock_firebase_admin._apps = {}

mock_credentials = ModuleType("firebase_admin.credentials")
mock_credentials.ApplicationDefault = staticmethod(lambda: "mock-app-default")
mock_firebase_admin.credentials = mock_credentials

mock_storage = ModuleType("firebase_admin.storage")
mock_firebase_admin.storage = mock_storage

mock_firebase_admin.initialize_app = lambda *args, **kwargs: None


class DummyBucket:
    def blob(self, path):
        raise AssertionError("Firebase bucket should not be used in handler tests")


mock_storage.bucket = lambda *args, **kwargs: DummyBucket()

sys.modules["firebase_admin"] = mock_firebase_admin
sys.modules["firebase_admin.credentials"] = mock_credentials
sys.modules["firebase_admin.storage"] = mock_storage


# Now it is safe to import handlers.
import dgc_pricecharting_ingest.handlers as handlers


COL_CARDS = "cards"
COL_SPORTS_CARDS = "sports_cards"


class MockFetchResponse:
    def __init__(self, status_code=200, content="<html></html>"):
        self.status_code = status_code
        self.content = content


@pytest.fixture(autouse=True)
def patch_common(monkeypatch):
    monkeypatch.setattr(handlers, "COL_CARDS", COL_CARDS)
    monkeypatch.setattr(handlers, "COL_SPORTS_CARDS", COL_SPORTS_CARDS)
    monkeypatch.setattr(handlers, "VALID_COLLECTIONS", {COL_CARDS, COL_SPORTS_CARDS})

    monkeypatch.setattr(handlers, "ALLOWED_SERVICE_ACCOUNT", "test-sa")
    monkeypatch.setattr(handlers, "ALLOWED_AUDIENCE", "test-audience")
    monkeypatch.setattr(handlers, "FETCH_RETRIES", 1)
    monkeypatch.setattr(handlers, "FETCH_TIMEOUT_SECONDS", 5)

    monkeypatch.setattr(handlers, "verify_request", lambda request, sa, aud: True)
    monkeypatch.setattr(handlers, "log", lambda *args, **kwargs: None)

    yield


@pytest.fixture
def client():
    handlers.app.config["TESTING"] = True
    return handlers.app.test_client()


@pytest.fixture
def valid_payload():
    return {
        "collection_name": COL_CARDS,
        "_id": "mongo-123",
        "id": 123,
        "console_name": "Pokemon Promo",
        "product_name": "Pikachu #85",
    }


def post_json(client, payload):
    return client.post("/", json=payload)


def assert_json_status(response, status):
    assert response.status_code == 200
    assert response.get_json() == {"status": status}


# ---------------------------
# Request validation
# ---------------------------

def test_unauthorized_returns_403(client, valid_payload, monkeypatch):
    monkeypatch.setattr(handlers, "verify_request", lambda request, sa, aud: False)

    response = post_json(client, valid_payload)

    assert response.status_code == 403
    assert response.get_json() == {"error": "Unauthorized"}


def test_non_json_request_returns_400(client):
    response = client.post("/", data="not json", content_type="text/plain")

    assert response.status_code == 400
    assert response.get_json() == {"error": "Request must be JSON"}


def test_invalid_json_body_returns_400(client):
    response = client.post("/", data="{bad json", content_type="application/json")

    assert response.status_code == 400
    assert response.get_json() == {"error": "Request must contain a valid JSON body"}


def test_invalid_collection_name_returns_failed(client, valid_payload):
    valid_payload["collection_name"] = "bad_collection"

    response = post_json(client, valid_payload)

    assert_json_status(response, "failed")


@pytest.mark.parametrize(
    "field",
    [
        "collection_name",
        "_id",
        "id",
        "console_name",
        "product_name",
    ],
)
def test_missing_required_fields_return_failed(client, valid_payload, field):
    valid_payload.pop(field)

    response = post_json(client, valid_payload)

    assert_json_status(response, "failed")


@pytest.mark.parametrize(
    "field,value",
    [
        ("_id", ""),
        ("console_name", ""),
        ("product_name", ""),
    ],
)
def test_empty_required_fields_return_failed(client, valid_payload, field, value):
    valid_payload[field] = value

    response = post_json(client, valid_payload)

    assert_json_status(response, "failed")


def test_invalid_card_id_returns_failed(client, valid_payload):
    valid_payload["id"] = "abc"

    response = post_json(client, valid_payload)

    assert_json_status(response, "failed")


# ---------------------------
# Fetch URL behavior
# ---------------------------

def test_fetch_url_exception_returns_failed(client, valid_payload, monkeypatch):
    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(
        handlers,
        "pricecharting_url",
        lambda collection_name, console_name, product_name: "https://pricecharting.test/generated",
    )

    def mock_fetch_url(**kwargs):
        raise RuntimeError("network error")

    monkeypatch.setattr(handlers, "fetch_url", mock_fetch_url)

    response = post_json(client, valid_payload)

    assert_json_status(response, "failed")


def test_fetch_url_non_200_returns_failed(client, valid_payload, monkeypatch):
    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(
        handlers,
        "pricecharting_url",
        lambda collection_name, console_name, product_name: "https://pricecharting.test/generated",
    )
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=500, content="server error"),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "failed")


def test_empty_html_returns_failed(client, valid_payload, monkeypatch):
    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(
        handlers,
        "pricecharting_url",
        lambda collection_name, console_name, product_name: "https://pricecharting.test/generated",
    )
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content=""),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "failed")


def test_uses_manual_url_when_available(client, valid_payload, monkeypatch):
    calls = []

    monkeypatch.setattr(
        handlers,
        "get_card_manual_url",
        lambda card_id: "https://pricecharting.test/manual",
    )
    monkeypatch.setattr(
        handlers,
        "pricecharting_url",
        lambda collection_name, console_name, product_name: "https://pricecharting.test/generated",
    )

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        return MockFetchResponse(status_code=200, content="<html>ok</html>")

    monkeypatch.setattr(handlers, "fetch_url", mock_fetch_url)
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": None, "no_image": True},
    )

    noimage_calls = []
    monkeypatch.setattr(
        handlers,
        "mark_card_noimage",
        lambda collection_name, card_id: noimage_calls.append((collection_name, card_id)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert calls[0]["url"] == "https://pricecharting.test/manual"
    assert noimage_calls == [(COL_CARDS, 123)]


def test_uses_generated_url_when_manual_url_missing(client, valid_payload, monkeypatch):
    calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(
        handlers,
        "pricecharting_url",
        lambda collection_name, console_name, product_name: "https://pricecharting.test/generated",
    )

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        return MockFetchResponse(status_code=200, content="<html>ok</html>")

    monkeypatch.setattr(handlers, "fetch_url", mock_fetch_url)
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": None, "no_image": True},
    )
    monkeypatch.setattr(handlers, "mark_card_noimage", lambda collection_name, card_id: None)

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert calls[0]["url"] == "https://pricecharting.test/generated"


def test_fetch_url_called_with_expected_args(client, valid_payload, monkeypatch):
    calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(
        handlers,
        "pricecharting_url",
        lambda collection_name, console_name, product_name: "https://pricecharting.test/generated",
    )

    def mock_fetch_url(**kwargs):
        calls.append(kwargs)
        return MockFetchResponse(status_code=200, content="<html>ok</html>")

    monkeypatch.setattr(handlers, "fetch_url", mock_fetch_url)
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": None, "no_image": True},
    )
    monkeypatch.setattr(handlers, "mark_card_noimage", lambda collection_name, card_id: None)

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert calls == [
        {
            "url": "https://pricecharting.test/generated",
            "retries": 1,
            "timeout": 5,
            "extra_retryable_status_codes": {403},
            "response_type": "text",
        }
    ]


# ---------------------------
# PriceCharting ID validation
# ---------------------------

def test_missing_pricecharting_id_marks_deleted_when_product_missing(
    client,
    valid_payload,
    monkeypatch,
):
    deleted_calls = []
    invalid_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: None)
    monkeypatch.setattr(handlers, "product_exists", lambda card_id: False)
    monkeypatch.setattr(
        handlers,
        "mark_card_deleted",
        lambda collection_name, card_id: deleted_calls.append((collection_name, card_id)),
    )
    monkeypatch.setattr(
        handlers,
        "mark_card_invalid_url",
        lambda *args, **kwargs: invalid_calls.append((args, kwargs)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert deleted_calls == [(COL_CARDS, 123)]
    assert invalid_calls == []


@pytest.mark.parametrize("exists", [True, None])
def test_missing_pricecharting_id_marks_invalid_when_product_exists_unknown_or_true(
    client,
    valid_payload,
    monkeypatch,
    exists,
):
    invalid_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: None)
    monkeypatch.setattr(handlers, "product_exists", lambda card_id: exists)
    monkeypatch.setattr(
        handlers,
        "mark_card_invalid_url",
        lambda *args, **kwargs: invalid_calls.append((args, kwargs)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert invalid_calls == [
        (
            (COL_CARDS, 123),
            {
                "reason": "missing_pricecharting_id",
                "message": "Could not extract PriceCharting ID from fetched page",
            },
        )
    ]


def test_non_numeric_extracted_pid_marks_invalid(client, valid_payload, monkeypatch):
    invalid_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "abc")
    monkeypatch.setattr(
        handlers,
        "mark_card_invalid_url",
        lambda *args, **kwargs: invalid_calls.append((args, kwargs)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert invalid_calls == [
        (
            (COL_CARDS, 123),
            {
                "reason": "invalid_pricecharting_id",
                "message": "Extracted PriceCharting ID is not numeric: abc",
            },
        )
    ]


def test_pid_mismatch_marks_deleted_when_original_product_missing(
    client,
    valid_payload,
    monkeypatch,
):
    deleted_calls = []
    invalid_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "999")
    monkeypatch.setattr(handlers, "product_exists", lambda card_id: False)
    monkeypatch.setattr(
        handlers,
        "mark_card_deleted",
        lambda collection_name, card_id: deleted_calls.append((collection_name, card_id)),
    )
    monkeypatch.setattr(
        handlers,
        "mark_card_invalid_url",
        lambda *args, **kwargs: invalid_calls.append((args, kwargs)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert deleted_calls == [(COL_CARDS, 123)]
    assert invalid_calls == []


@pytest.mark.parametrize("exists", [True, None])
def test_pid_mismatch_marks_invalid_when_original_product_exists_unknown_or_true(
    client,
    valid_payload,
    monkeypatch,
    exists,
):
    invalid_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "999")
    monkeypatch.setattr(handlers, "product_exists", lambda card_id: exists)
    monkeypatch.setattr(
        handlers,
        "mark_card_invalid_url",
        lambda *args, **kwargs: invalid_calls.append((args, kwargs)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert invalid_calls == [
        (
            (COL_CARDS, 123),
            {
                "reason": "pricecharting_id_mismatch",
                "message": "Expected 123, got 999",
            },
        )
    ]


# ---------------------------
# Card number behavior
# ---------------------------

def test_card_number_is_updated_when_found(client, valid_payload, monkeypatch):
    update_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: "#85")
    monkeypatch.setattr(
        handlers,
        "update_card_number",
        lambda collection_name, card_id, card_number: update_calls.append(
            (collection_name, card_id, card_number)
        ),
    )
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": None, "no_image": True},
    )
    monkeypatch.setattr(handlers, "mark_card_noimage", lambda collection_name, card_id: None)

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert update_calls == [(COL_CARDS, 123, "#85")]


def test_card_number_none_string_updates_none(client, valid_payload, monkeypatch):
    update_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: "None")
    monkeypatch.setattr(
        handlers,
        "update_card_number",
        lambda collection_name, card_id, card_number: update_calls.append(
            (collection_name, card_id, card_number)
        ),
    )
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": None, "no_image": True},
    )
    monkeypatch.setattr(handlers, "mark_card_noimage", lambda collection_name, card_id: None)

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert update_calls == [(COL_CARDS, 123, None)]


def test_card_number_not_updated_when_missing(client, valid_payload, monkeypatch):
    update_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "update_card_number",
        lambda *args, **kwargs: update_calls.append((args, kwargs)),
    )
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": None, "no_image": True},
    )
    monkeypatch.setattr(handlers, "mark_card_noimage", lambda collection_name, card_id: None)

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert update_calls == []


# ---------------------------
# Image info behavior
# ---------------------------

def test_missing_product_details_returns_skipped_without_marking(client, valid_payload, monkeypatch):
    marker_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(handlers, "extract_image_info", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "mark_card_invalid_url",
        lambda *args, **kwargs: marker_calls.append((args, kwargs)),
    )
    monkeypatch.setattr(
        handlers,
        "mark_card_noimage",
        lambda *args, **kwargs: marker_calls.append((args, kwargs)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert marker_calls == []


def test_no_image_marks_noimage(client, valid_payload, monkeypatch):
    noimage_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": None, "no_image": True},
    )
    monkeypatch.setattr(
        handlers,
        "mark_card_noimage",
        lambda collection_name, card_id: noimage_calls.append((collection_name, card_id)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert noimage_calls == [(COL_CARDS, 123)]


def test_missing_image_id_marks_invalid(client, valid_payload, monkeypatch):
    invalid_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": None, "no_image": False},
    )
    monkeypatch.setattr(
        handlers,
        "mark_card_invalid_url",
        lambda *args, **kwargs: invalid_calls.append((args, kwargs)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert invalid_calls == [
        (
            (COL_CARDS, 123),
            {
                "reason": "missing_image_id",
                "message": "Could not extract valid PriceCharting image ID",
            },
        )
    ]


# ---------------------------
# Upload behavior
# ---------------------------

def test_successful_upload_marks_uploaded(client, valid_payload, monkeypatch):
    upload_calls = []
    download_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": "img-123", "no_image": False},
    )

    def mock_download_and_upload_images(**kwargs):
        download_calls.append(kwargs)
        return [
            ("source-120", "uploaded-120"),
            ("source-240", None),
            ("source-1600", None),
        ], "stored-image-id"

    monkeypatch.setattr(
        handlers,
        "download_and_upload_images",
        mock_download_and_upload_images,
    )
    monkeypatch.setattr(
        handlers,
        "mark_card_uploaded",
        lambda collection_name, card_id, stored_image_id: upload_calls.append(
            (collection_name, card_id, stored_image_id)
        ),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "uploaded")
    assert download_calls == [
        {
            "collection_name": COL_CARDS,
            "mongo_id": "mongo-123",
            "card_id": 123,
            "image_id": "img-123",
        }
    ]
    assert upload_calls == [(COL_CARDS, 123, "stored-image-id")]


def test_all_uploads_failed_marks_upload_failed(client, valid_payload, monkeypatch):
    failed_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": "img-123", "no_image": False},
    )
    monkeypatch.setattr(
        handlers,
        "download_and_upload_images",
        lambda **kwargs: (
            [
                ("source-120", None),
                ("source-240", None),
                ("source-1600", None),
            ],
            "stored-image-id",
        ),
    )
    monkeypatch.setattr(
        handlers,
        "mark_card_upload_failed",
        lambda *args, **kwargs: failed_calls.append((args, kwargs)),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "skipped")
    assert failed_calls == [
        (
            (COL_CARDS, 123),
            {
                "reason": "all_uploads_failed",
                "message": "All image downloads/uploads failed",
            },
        )
    ]


def test_sports_cards_collection_is_passed_through(client, valid_payload, monkeypatch):
    valid_payload["collection_name"] = COL_SPORTS_CARDS
    upload_calls = []
    download_calls = []

    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)
    monkeypatch.setattr(handlers, "pricecharting_url", lambda cn, c, p: "https://url")
    monkeypatch.setattr(
        handlers,
        "fetch_url",
        lambda **kwargs: MockFetchResponse(status_code=200, content="<html>ok</html>"),
    )
    monkeypatch.setattr(handlers, "extract_pricecharting_id", lambda html: "123")
    monkeypatch.setattr(handlers, "extract_card_number", lambda html: None)
    monkeypatch.setattr(
        handlers,
        "extract_image_info",
        lambda html: {"image_id": "img-123", "no_image": False},
    )

    def mock_download_and_upload_images(**kwargs):
        download_calls.append(kwargs)
        return [("source", "uploaded")], "stored-image-id"

    monkeypatch.setattr(
        handlers,
        "download_and_upload_images",
        mock_download_and_upload_images,
    )
    monkeypatch.setattr(
        handlers,
        "mark_card_uploaded",
        lambda collection_name, card_id, stored_image_id: upload_calls.append(
            (collection_name, card_id, stored_image_id)
        ),
    )

    response = post_json(client, valid_payload)

    assert_json_status(response, "uploaded")
    assert download_calls[0]["collection_name"] == COL_SPORTS_CARDS
    assert upload_calls == [(COL_SPORTS_CARDS, 123, "stored-image-id")]


# ---------------------------
# Catch-all exception
# ---------------------------

def test_unexpected_exception_returns_failed(client, valid_payload, monkeypatch):
    monkeypatch.setattr(handlers, "get_card_manual_url", lambda card_id: None)

    def bad_pricecharting_url(collection_name, console_name, product_name):
        raise RuntimeError("boom")

    monkeypatch.setattr(handlers, "pricecharting_url", bad_pricecharting_url)

    response = post_json(client, valid_payload)

    assert_json_status(response, "failed")