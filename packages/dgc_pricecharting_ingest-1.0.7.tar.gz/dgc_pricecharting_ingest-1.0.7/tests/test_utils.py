# tests/test_utils.py

import pytest

from dgc_pricecharting_ingest.utils import to_int


@pytest.mark.parametrize(
    "value,expected",
    [
        (123, 123),
        (0, 0),
        (-1, -1),
        ("123", 123),
        ("0", 0),
        ("00123", 123),
        (" 123 ", 123),
        ("\t456\n", 456),
    ],
)
def test_to_int_valid_values(value, expected):
    assert to_int(value) == expected


@pytest.mark.parametrize(
    "value",
    [
        None,
        "",
        " ",
        "abc",
        "123abc",
        "12.3",
        "-1",
        "+1",
        "1,000",
        12.3,
        True,
        False,
        [],
        {},
        object(),
    ],
)
def test_to_int_invalid_values(value):
    assert to_int(value) is None