# dgc_pricecharting_ingest/pricecharting.py

import traceback
from typing import Optional

from opticedge_cloud_utils import LogLevel, fetch_url, log

from .config import (
    FETCH_RETRIES,
    FETCH_TIMEOUT_SECONDS,
    PRICECHARTING_TOKEN,
    PRICECHARTING_PRODUCT_API_URL,
    PRICECHARTING_PRODUCT_NOT_FOUND_MESSAGE,
)


def product_exists(product_id: int) -> Optional[bool]:
    """
    Return:
        True  -> product exists
        False -> product definitely does not exist
        None  -> unknown, retryable, or unexpected API/server/network issue
    """
    if not PRICECHARTING_TOKEN:
        raise RuntimeError("PRICECHARTING_TOKEN environment variable is not set")

    params = {
        "t": PRICECHARTING_TOKEN,
        "id": str(product_id),
    }

    try:
        resp = fetch_url(
            url=PRICECHARTING_PRODUCT_API_URL,
            params=params,
            retries=FETCH_RETRIES,
            timeout=FETCH_TIMEOUT_SECONDS,
            extra_retryable_status_codes={403},
            response_type="json",
        )
    except Exception:
        log(
            LogLevel.WARNING,
            "[product_exists] request failed",
            product_id=product_id,
            traceback=traceback.format_exc(),
        )
        return None

    if resp.status_code == 404:
        return False

    if resp.status_code != 200:
        log(
            LogLevel.WARNING,
            "[product_exists] unexpected status code",
            product_id=product_id,
            status_code=resp.status_code,
        )
        return None

    data = resp.content

    if not isinstance(data, dict):
        log(
            LogLevel.WARNING,
            "[product_exists] unexpected response body",
            product_id=product_id,
            body_type=type(data).__name__,
        )
        return None

    status = str(data.get("status") or "").lower()
    err_text = (
        str(data.get("error") or "")
        + " "
        + str(data.get("error-message") or "")
    ).lower()

    if status == "error":
        if PRICECHARTING_PRODUCT_NOT_FOUND_MESSAGE in err_text:
            return False

        log(
            LogLevel.WARNING,
            "[product_exists] api returned error",
            product_id=product_id,
            error=err_text,
        )
        return None

    return True