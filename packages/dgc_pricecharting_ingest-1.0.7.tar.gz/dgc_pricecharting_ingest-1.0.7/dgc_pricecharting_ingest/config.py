# dgc_pricecharing_ingest/config.py
from opticedge_cloud_utils import require_env

MONGO_URI_PRICES = require_env("MONGO_URI_PRICES")
DB = require_env("DB")
COL_CARDS = require_env("COL_CARDS")
COL_SPORTS_CARDS = require_env("COL_SPORTS_CARDS")

ALLOWED_SERVICE_ACCOUNT = require_env("ALLOWED_SERVICE_ACCOUNT")
ALLOWED_AUDIENCE = require_env("ALLOWED_AUDIENCE")
API_URL = require_env("API_URL")
try:
    API_LOAD_TIMEOUT_SECONDS = int(require_env("API_LOAD_TIMEOUT_SECONDS", "10"))
except ValueError:
    raise RuntimeError("API_LOAD_TIMEOUT_SECONDS must be a valid integer")

FIREBASE_BUCKET = require_env("FIREBASE_STORAGE_BUCKET")
FIREBASE_IMAGE_DEST_PREFIX = require_env("FIREBASE_IMAGE_DEST_PREFIX")

PRICECHARTING_TOKEN = require_env("PRICECHARTING_TOKEN")
PRICECHARTING_PRODUCT_API_URL = require_env("PRICECHARTING_PRODUCT_API_URL")
PRICECHARTING_PRODUCT_NOT_FOUND_MESSAGE = require_env("PRICECHARTING_PRODUCT_NOT_FOUND_MESSAGE")
PRICECHARTING_BASE_URL = require_env("PRICECHARTING_BASE_URL")
SPORTSCARDS_BASE_URL = require_env("SPORTSCARDS_BASE_URL")

try:
    FETCH_RETRIES = int(require_env("FETCH_RETRIES", "10"))
except ValueError:
    raise RuntimeError("FETCH_RETRIES must be a valid integer")

try:
    FETCH_TIMEOUT_SECONDS = int(require_env("FETCH_TIMEOUT_SECONDS", "10"))
except ValueError:
    raise RuntimeError("FETCH_TIMEOUT_SECONDS must be a valid integer")

PRICECHARTING_IMAGE_SIZES = {"tiny": 120, "small": 240, "normal": 1600}
