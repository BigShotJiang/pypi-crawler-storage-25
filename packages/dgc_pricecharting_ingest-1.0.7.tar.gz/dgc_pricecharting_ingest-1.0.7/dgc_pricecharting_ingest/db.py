# dgc_pricecharting_ingest/db.py

from datetime import datetime, timezone
from typing import Optional

from opticedge_cloud_utils.mongo_cache import MongoCache

from .config import MONGO_URI_PRICES, DB


_mongo_cache = MongoCache()
_db_client = None
_collections = {}


def _get_collection(collection_name: str):
    """Lazily obtain and cache collection objects for connection reuse."""
    global _db_client, _collections

    if not collection_name:
        raise RuntimeError("collection_name is required")

    if _db_client is None:
        _db_client = _mongo_cache.get_db(MONGO_URI_PRICES, DB)

    if collection_name not in _collections:
        _collections[collection_name] = _db_client[collection_name]

    return _collections[collection_name]


def _now():
    return datetime.now(timezone.utc)


def mark_card_uploaded(
    collection_name: str,
    card_id: int,
    image_id: str,
):
    """Mark card image upload as successful."""
    now = _now()

    _get_collection(collection_name).update_one(
        {"id": card_id},
        {
            "$set": {
                "uploadStatus.imagesUploaded": True,
                "imageId": image_id,
                "updatedAt": now,
            },
            "$unset": {
                "uploadStatus.invalidUrl": "",
                "uploadStatus.noImage": "",
                "uploadStatus.uploadFailed": "",
                "uploadStatus.lastError": "",
            },
        },
    )


def mark_card_noimage(collection_name: str, card_id: int):
    """Mark card as having no image."""
    now = _now()

    _get_collection(collection_name).update_one(
        {"id": card_id},
        {
            "$set": {
                "uploadStatus.noImage": True,
                "updatedAt": now,
            },
            "$unset": {
                "uploadStatus.invalidUrl": "",
                "uploadStatus.uploadFailed": "",
                "uploadStatus.lastError": "",
            },
        },
    )


def mark_card_deleted(collection_name: str, card_id: int):
    """Mark card as deleted."""
    now = _now()

    _get_collection(collection_name).update_one(
        {"id": card_id},
        {
            "$set": {
                "deleted": True,
                "updatedAt": now,
            }
        },
    )


def mark_card_invalid_url(
    collection_name: str,
    card_id: int,
    reason: Optional[str] = None,
    message: Optional[str] = None,
):
    """Mark card as having an invalid URL or mismatched page."""
    now = _now()

    set_doc = {
        "uploadStatus.invalidUrl": True,
        "updatedAt": now,
    }

    if reason or message:
        set_doc["uploadStatus.lastError"] = {
            "reason": reason or "invalid_url",
            "message": message,
            "at": now,
        }

    _get_collection(collection_name).update_one(
        {"id": card_id},
        {
            "$set": set_doc,
            "$unset": {
                "uploadStatus.uploadFailed": "",
            },
        },
    )


def mark_card_upload_failed(
    collection_name: str,
    card_id: int,
    reason: str,
    message: Optional[str] = None,
):
    """Mark card image upload as failed."""
    now = _now()

    _get_collection(collection_name).update_one(
        {"id": card_id},
        {
            "$set": {
                "uploadStatus.uploadFailed": True,
                "uploadStatus.lastError": {
                    "reason": reason,
                    "message": message,
                    "at": now,
                },
                "updatedAt": now,
            },
            "$unset": {
                "uploadStatus.imagesUploaded": "",
                "uploadStatus.noImage": "",
            },
        },
    )


def update_image_path(
    collection_name: str,
    card_id: int,
    size: str,
    url: str,
):
    now = _now()

    _get_collection(collection_name).update_one(
        {"id": card_id},
        {
            "$set": {
                f"images.{size}": url,
                "updatedAt": now,
            }
        },
    )


def update_card_number(
    collection_name: str,
    card_id: int,
    card_number: Optional[str],
):
    now = _now()

    _get_collection(collection_name).update_one(
        {"id": card_id},
        {
            "$set": {
                "cardNumber": card_number,
                "updatedAt": now,
            }
        },
    )