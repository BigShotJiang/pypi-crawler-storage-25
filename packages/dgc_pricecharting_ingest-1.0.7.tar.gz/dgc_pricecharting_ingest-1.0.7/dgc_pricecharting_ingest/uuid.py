# dgc_pricecharting_ingest/uuid.py

import uuid


def generate_uuid(mongo_id: str, card_id: int) -> uuid.UUID:
    """
    Generate a stable UUID based on Mongo document ID and PriceCharting card ID.

    Same mongo_id + card_id always returns the same UUID.
    """
    data = f"{mongo_id}:{card_id}"
    return uuid.uuid5(uuid.NAMESPACE_DNS, data)