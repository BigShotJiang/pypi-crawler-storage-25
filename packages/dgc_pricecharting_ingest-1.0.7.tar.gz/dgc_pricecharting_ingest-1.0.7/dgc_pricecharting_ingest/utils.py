# dgc_pricecharting_ingest/utils.py

from typing import Any, Optional


def to_int(val: Any) -> Optional[int]:
    """Safely convert clean int-like values to int, otherwise return None."""
    if isinstance(val, bool):
        return None

    if isinstance(val, int):
        return val

    if isinstance(val, str):
        val = val.strip()

        if val.isdigit():
            return int(val)

        return None

    return None