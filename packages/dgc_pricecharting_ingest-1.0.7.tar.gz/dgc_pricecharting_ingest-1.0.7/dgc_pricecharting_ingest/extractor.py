# dgc_pricecharting_ingest/extractor.py

import re
from typing import Optional, Dict, Any

from bs4 import BeautifulSoup


def _label_to_pattern(label: str) -> re.Pattern:
    """
    Convert a label like "PriceCharting ID" into a whitespace-tolerant regex.
    """
    parts = label.strip().split()
    escaped_parts = [re.escape(part) for part in parts]
    pattern = r"^\s*" + r"\s+".join(escaped_parts) + r"\s*:?\s*$"
    return re.compile(pattern, re.IGNORECASE)


def _extract_full_detail_value(html: str, label: str) -> Optional[str]:
    """
    Extract a value from #full_details by matching a td.title label.
    """
    soup = BeautifulSoup(html, "html.parser")
    full = soup.find("div", id="full_details")
    if not full:
        return None

    label_pattern = _label_to_pattern(label)

    for title_td in full.select("td.title"):
        title_text = title_td.get_text(" ", strip=True)

        if label_pattern.match(title_text):
            details_td = title_td.find_next_sibling("td")
            if not details_td:
                return None

            value = details_td.get_text(separator=" ", strip=True)
            return value or None

    return None


def extract_pricecharting_id(html: str) -> Optional[str]:
    """
    Extract PriceCharting ID from #full_details.

    Returns the first numeric token, for example "7307259", or None.
    """
    value = _extract_full_detail_value(html, "PriceCharting ID")
    if not value:
        return None

    match = re.search(r"\d+", value)
    return match.group(0) if match else None


def extract_card_number(html: str) -> Optional[str]:
    """
    Extract Card Number from #full_details.
    """
    value = _extract_full_detail_value(html, "Card Number")
    if not value:
        return None

    cleaned = value.strip().lstrip("#").strip()
    return cleaned or None


def extract_image_info(html: str) -> Optional[Dict[str, Any]]:
    """
    Extract PriceCharting image information from the product detail page.

    Returns:
        {
            "image_id": <str or None>,
            "no_image": <bool>
        }

    Returns None if #product_details is missing entirely.
    """
    soup = BeautifulSoup(html, "html.parser")
    product_div = soup.find("div", id="product_details")
    if not product_div:
        return None

    img_tag = product_div.select_one(".cover img")
    if not img_tag:
        return {"image_id": None, "no_image": False}

    src = img_tag.get("src")
    if not src:
        return {"image_id": None, "no_image": False}

    src = src.strip()

    if "no-image-available" in src.lower():
        return {"image_id": None, "no_image": True}

    match = re.search(
        r"https://storage\.googleapis\.com/images\.pricecharting\.com/([^/]+)/\d+\.jpg(?:\?.*)?$",
        src,
        re.IGNORECASE,
    )

    if match:
        return {"image_id": match.group(1), "no_image": False}

    return {"image_id": None, "no_image": False}