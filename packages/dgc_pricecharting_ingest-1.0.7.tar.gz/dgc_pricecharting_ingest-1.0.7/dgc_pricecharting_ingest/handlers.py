# dgc_pricecharting_ingest/handlers.py

import traceback

from flask import Flask, jsonify, request
from opticedge_cloud_utils import (
    LogLevel,
    fetch_url,
    log,
    verify_request,
)

from .config import (
    ALLOWED_AUDIENCE,
    ALLOWED_SERVICE_ACCOUNT,
    COL_CARDS,
    COL_SPORTS_CARDS,
    FETCH_RETRIES,
    FETCH_TIMEOUT_SECONDS,
)
from .db import (
    mark_card_deleted,
    mark_card_invalid_url,
    mark_card_noimage,
    mark_card_upload_failed,
    mark_card_uploaded,
    update_card_number,
)
from .extractor import (
    extract_card_number,
    extract_image_info,
    extract_pricecharting_id,
)
from .img import download_and_upload_images
from .pricecharting import product_exists
from .url import get_card_manual_url, pricecharting_url
from .utils import to_int


app = Flask(__name__)

VALID_COLLECTIONS = {COL_CARDS, COL_SPORTS_CARDS}


@app.route("/", methods=["POST"])
def handler():
    if not verify_request(request, ALLOWED_SERVICE_ACCOUNT, ALLOWED_AUDIENCE):
        return jsonify({"error": "Unauthorized"}), 403

    if not request.is_json:
        return jsonify({"error": "Request must be JSON"}), 400

    request_json = request.get_json(silent=True)
    if request_json is None:
        log(LogLevel.ERROR, "Invalid request: No JSON body")
        return jsonify({"error": "Request must contain a valid JSON body"}), 400

    collection_name = request_json.get("collection_name")
    mongo_id = request_json.get("_id")
    raw_id = request_json.get("id")
    console_name = request_json.get("console_name")
    product_name = request_json.get("product_name")
    log(LogLevel.DEBUG, "Debug", request_json=request_json)
    
    if collection_name not in VALID_COLLECTIONS:
        log(
            LogLevel.WARNING,
            "Invalid collection_name",
            collection_name=collection_name,
            item=request_json,
        )
        return jsonify({"status": "failed"})

    if not (mongo_id and raw_id is not None and console_name and product_name):
        log(
            LogLevel.WARNING,
            "Skipping card due to missing fields",
            collection_name=collection_name,
            item=request_json,
        )
        return jsonify({"status": "failed"})

    card_id = to_int(raw_id)
    if card_id is None:
        log(
            LogLevel.WARNING,
            "Invalid id for item",
            collection_name=collection_name,
            raw_id=raw_id,
            item=request_json,
        )
        return jsonify({"status": "failed"})

    try:
        manual_url = get_card_manual_url(card_id)
        card_url = manual_url or pricecharting_url(collection_name, console_name, product_name)

        try:
            resp = fetch_url(
                url=card_url,
                retries=FETCH_RETRIES,
                timeout=FETCH_TIMEOUT_SECONDS,
                extra_retryable_status_codes={403},
                response_type="text",
            )
        except Exception:
            log(
                LogLevel.ERROR,
                "Failed to load card URL",
                collection_name=collection_name,
                card_id=card_id,
                card_url=card_url,
                manual_url_used=manual_url is not None,
                traceback=traceback.format_exc(),
            )
            return jsonify({"status": "failed"})
        log(LogLevel.DEBUG, "Debug", resp=resp)
        if resp.status_code != 200:
            log(
                LogLevel.ERROR,
                "Failed to fetch card",
                collection_name=collection_name,
                card_id=card_id,
                card_url=card_url,
                manual_url_used=manual_url is not None,
                status_code=resp.status_code,
            )
            return jsonify({"status": "failed"})

        html = resp.content
        if not html:
            log(
                LogLevel.WARNING,
                "Fetched card page but HTML body is empty",
                collection_name=collection_name,
                card_id=card_id,
                card_url=card_url,
            )
            return jsonify({"status": "failed"})
        log(LogLevel.DEBUG, "Debug", html=html)
        extracted_pid = extract_pricecharting_id(html)
        log(LogLevel.DEBUG, "Debug", extracted_pid=extracted_pid)

        if extracted_pid is None:
            exists = product_exists(card_id)

            if exists is False:
                mark_card_deleted(collection_name, card_id)
                log(
                    LogLevel.INFO,
                    "Marked card deleted because product no longer exists",
                    collection_name=collection_name,
                    card_id=card_id,
                    card_url=card_url,
                )
            else:
                mark_card_invalid_url(
                    collection_name,
                    card_id,
                    reason="missing_pricecharting_id",
                    message="Could not extract PriceCharting ID from fetched page",
                )
                log(
                    LogLevel.WARNING,
                    "Missing PriceCharting ID and marked card URL invalid",
                    collection_name=collection_name,
                    card_id=card_id,
                    card_url=card_url,
                    product_exists=exists,
                )

            return jsonify({"status": "skipped"})

        extracted_pid_str = str(extracted_pid).strip()

        if not extracted_pid_str.isdigit():
            mark_card_invalid_url(
                collection_name,
                card_id,
                reason="invalid_pricecharting_id",
                message=f"Extracted PriceCharting ID is not numeric: {extracted_pid_str}",
            )
            log(
                LogLevel.WARNING,
                "Invalid extracted PriceCharting ID",
                collection_name=collection_name,
                card_id=card_id,
                card_url=card_url,
                extracted_pid=extracted_pid_str,
            )
            return jsonify({"status": "skipped"})

        extracted_pid_int = int(extracted_pid_str)

        if extracted_pid_int != card_id:
            exists = product_exists(card_id)

            if exists is False:
                mark_card_deleted(collection_name, card_id)
                log(
                    LogLevel.INFO,
                    "Marked card deleted because product ID mismatched and original product no longer exists",
                    collection_name=collection_name,
                    card_id=card_id,
                    extracted_pid=extracted_pid_int,
                    card_url=card_url,
                )
            else:
                mark_card_invalid_url(
                    collection_name,
                    card_id,
                    reason="pricecharting_id_mismatch",
                    message=f"Expected {card_id}, got {extracted_pid_int}",
                )
                log(
                    LogLevel.WARNING,
                    "PriceCharting ID mismatch and marked card URL invalid",
                    collection_name=collection_name,
                    card_id=card_id,
                    extracted_pid=extracted_pid_int,
                    card_url=card_url,
                    product_exists=exists,
                )

            return jsonify({"status": "skipped"})

        card_number = extract_card_number(html)
        if card_number:
            update_card_number(
                collection_name,
                card_id,
                None if card_number.lower() == "none" else card_number,
            )

        image_info = extract_image_info(html)

        if image_info is None:
            log(
                LogLevel.WARNING,
                "Product details section missing, image extraction skipped",
                collection_name=collection_name,
                card_id=card_id,
                card_url=card_url,
            )
            return jsonify({"status": "skipped"})

        if image_info.get("no_image"):
            mark_card_noimage(collection_name, card_id)
            log(
                LogLevel.INFO,
                "No image available",
                collection_name=collection_name,
                card_id=card_id,
                card_url=card_url,
            )
            return jsonify({"status": "skipped"})

        image_id = image_info.get("image_id")

        if not image_id:
            mark_card_invalid_url(
                collection_name,
                card_id,
                reason="missing_image_id",
                message="Could not extract valid PriceCharting image ID",
            )
            log(
                LogLevel.WARNING,
                "Failed to extract image ID and marked card URL invalid",
                collection_name=collection_name,
                card_id=card_id,
                card_url=card_url,
                image_info=image_info,
            )
            return jsonify({"status": "skipped"})

        results, stored_image_id = download_and_upload_images(
            collection_name=collection_name,
            mongo_id=mongo_id,
            card_id=card_id,
            image_id=image_id,
        )

        any_success = any(uploaded_url is not None for _, uploaded_url in results)

        if any_success:
            mark_card_uploaded(collection_name, card_id, stored_image_id)
            log(
                LogLevel.INFO,
                "Card marked as imagesUploaded",
                collection_name=collection_name,
                card_id=card_id,
                image_id=image_id,
                stored_image_id=stored_image_id,
                results=results,
            )
            return jsonify({"status": "uploaded"})

        mark_card_upload_failed(
            collection_name,
            card_id,
            reason="all_uploads_failed",
            message="All image downloads/uploads failed",
        )
        log(
            LogLevel.WARNING,
            "All image uploads failed",
            collection_name=collection_name,
            card_id=card_id,
            image_id=image_id,
            stored_image_id=stored_image_id,
            results=results,
        )
        return jsonify({"status": "skipped"})

    except Exception:
        log(
            LogLevel.ERROR,
            "An error occurred while processing card",
            collection_name=collection_name,
            card_id=card_id,
            traceback=traceback.format_exc(),
        )
        return jsonify({"status": "failed"})