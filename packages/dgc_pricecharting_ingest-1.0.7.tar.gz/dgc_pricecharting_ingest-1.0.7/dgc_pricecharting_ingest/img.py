# dgc_pricecharting_ingest/img.py

import traceback
from typing import Dict, List, Optional, Tuple

import firebase_admin
from firebase_admin import credentials, initialize_app, storage
from opticedge_cloud_utils import LogLevel, fetch_image, log

from .config import (
    FETCH_RETRIES,
    FETCH_TIMEOUT_SECONDS,
    FIREBASE_BUCKET,
    FIREBASE_IMAGE_DEST_PREFIX,
    PRICECHARTING_IMAGE_SIZES,
)
from .db import update_image_path
from .uuid import generate_uuid


if not firebase_admin._apps:
    cred = credentials.ApplicationDefault()
    initialize_app(cred, {"storageBucket": FIREBASE_BUCKET})


bucket = storage.bucket()


def download_image(url: str) -> Tuple[Optional[bytes], Optional[str]]:
    """Download image bytes from a given URL."""
    try:
        resp = fetch_image(
            url=url,
            retries=FETCH_RETRIES,
            timeout=FETCH_TIMEOUT_SECONDS,
            extra_retryable_status_codes={403},
        )

        return resp.content, resp.content_type

    except Exception:
        log(
            LogLevel.WARNING,
            "[download_image] failed",
            url=url,
            traceback=traceback.format_exc(),
        )
        return None, None


def upload_image(data: bytes, content_type: str, dest_path: str) -> str:
    """Upload image bytes to Firebase Storage."""
    blob = bucket.blob(dest_path)
    blob.upload_from_string(data, content_type=content_type)

    # Keep this only if the bucket is not already public.
    blob.make_public()

    return blob.public_url


def download_and_upload_images(
    collection_name: str,
    mongo_id: str,
    card_id: int,
    image_id: str,
    sizes: Dict[str, int] = PRICECHARTING_IMAGE_SIZES,
    dest_prefix: str = FIREBASE_IMAGE_DEST_PREFIX,
) -> Tuple[List[Tuple[str, Optional[str]]], str]:
    """
    Download PriceCharting image sizes and upload them to Firebase Storage.
    """
    results: List[Tuple[str, Optional[str]]] = []
    uid = generate_uuid(mongo_id, card_id)

    for name, size in sizes.items():
        url = f"https://storage.googleapis.com/images.pricecharting.com/{image_id}/{size}.jpg"
        dest_path = f"{dest_prefix}/{uid}/{size}.jpg"

        data, content_type = download_image(url)

        if not data:
            results.append((url, None))
            continue

        try:
            uploaded = upload_image(
                data=data,
                content_type=content_type or "image/jpeg",
                dest_path=dest_path,
            )

            update_image_path(collection_name, card_id, name, uploaded)
            results.append((url, uploaded))

        except Exception:
            log(
                LogLevel.ERROR,
                "[download_and_upload_images] upload failed",
                collection_name=collection_name,
                card_id=card_id,
                image_id=image_id,
                size_name=name,
                size=size,
                url=url,
                dest_path=dest_path,
                traceback=traceback.format_exc(),
            )
            results.append((url, None))

    return results, str(uid)