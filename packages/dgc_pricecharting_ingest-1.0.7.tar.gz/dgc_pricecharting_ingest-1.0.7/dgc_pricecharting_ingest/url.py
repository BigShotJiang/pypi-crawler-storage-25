# dgc_pricecharting_ingest/url.py

import re
import traceback

from opticedge_cloud_utils import LogLevel, fetch_url, log

from .config import (
    COL_CARDS,
    API_LOAD_TIMEOUT_SECONDS,
    API_URL,
    PRICECHARTING_BASE_URL,
    SPORTSCARDS_BASE_URL,
)


_manual_url_cache: dict[str, str] | None = None


def _simple_slug(s: str) -> str:
    if not s:
        return ""

    s = s.strip().lower()

    # remove square brackets but keep contents
    s = s.replace("[", "").replace("]", "")

    # remove common punctuation we don't want
    for ch in ("#", ":", "/", ".", "?", "!"):
        s = s.replace(ch, "")

    # remove commas unless they are between two digits (keep 100,000)
    def comma_repl(m):
        i = m.start()
        # safe neighbor lookup
        left = s[i-1] if i > 0 else ""
        right = s[i+1] if i+1 < len(s) else ""
        return "," if (left.isdigit() and right.isdigit()) else ""
    s = re.sub(",", comma_repl, s)

    # collapse whitespace -> single hyphen
    s = re.sub(r'\s+', '-', s)
    # collapse multiple hyphens and trim edges
    s = re.sub(r'-{2,}', '-', s)

    return s


def pricecharting_url(collection_name: str, console_name: str, product_name: str) -> str:
    base_url = PRICECHARTING_BASE_URL if collection_name == COL_CARDS else SPORTSCARDS_BASE_URL
    return (
        f"{base_url}/"
        f"{_simple_slug(console_name)}/"
        f"{_simple_slug(product_name)}"
    )


def _load_manual_url_cache() -> dict[str, str]:
    global _manual_url_cache

    if _manual_url_cache is not None:
        return _manual_url_cache

    if not API_URL:
        log(LogLevel.ERROR, "API_URL environment variable is not set")
        return {}

    try:
        resp = fetch_url(
            url=f"{API_URL}/pricecharting-ingest-urls",
            timeout=API_LOAD_TIMEOUT_SECONDS,
            response_type="json",
        )
    except Exception:
        log(
            LogLevel.ERROR,
            "Failed to load manual URL cache",
            traceback=traceback.format_exc(),
        )

        # Do not cache failure. Let the next call retry.
        return {}

    if resp.status_code != 200:
        log(
            LogLevel.ERROR,
            "Manual URL API failed",
            status_code=resp.status_code,
        )

        # Do not cache failure. Let the next call retry.
        return {}

    if not isinstance(resp.content, dict):
        log(
            LogLevel.ERROR,
            "Manual URL API returned invalid response",
            response_type=type(resp.content).__name__,
        )
        return {}

    _manual_url_cache = {
        str(card_id): str(url)
        for card_id, url in resp.content.items()
        if card_id is not None and url
    }

    return _manual_url_cache


def get_card_manual_url(card_id: int) -> str | None:
    urls = _load_manual_url_cache()
    return urls.get(str(card_id))