﻿from .network import MainNetwork
from .eventemitter import EventEmitter, AsyncEventEmitter, Event
from .modules import *
from .modules.enums import *
from .utils import InlineKeypad, ChatKeypad, MetadataBuilder, InlineBundle, ChatBundle, create_markdown
from .exceptions import *
from .filters import *
from .database import SyncDatabase, AsyncDatabase
from httpx import TimeoutException
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from typing import Callable, Dict, List, Literal, Union, Any
from functools import wraps
import time, asyncio, os, sys, sqlite3, threading, aiofiles, aiohttp, requests, uuid, json

class Client(EventEmitter):
    database: SyncDatabase

    def __init__(self, session: str, token: Union[str, None] = None, interval_timeout: Union[int, float] = 0.3, use_database: bool = False, remove_messages_from_database: bool = False):

        super().__init__()

        self.__stored_new_mids = set()
        self.__stored_started_mids = set()
        self.__stored_updated_mids = set()
        self.__stored_stopped_mids = set()
        self.__stored_removed_mids = set()
        self.__stop_event = threading.Event()
        self.__thread: Union[threading.Thread, None] = None
        self.__background_scheduler = BackgroundScheduler()
        self.__whens: Dict[Literal[
            'started_polling', 'stopped_polling',
            'started_schedule', 'stopped_schedule',
            'internet_connection_error', 'timeout_error', # internet_connection_error and timeout_error are the same
            'server_response_error', 'client_input_error',
            'status_error', 'json_decode_error',
            'session_or_token_not_found', 'polling_exception'
        ], List[When]] = {}
        self.__allkeys = [
            'started_polling', 'stopped_polling',
            'started_schedule', 'stopped_schedule',
            'internet_connection_error', 'timeout_error',
            'server_response_error', 'client_input_error',
            'status_error', 'json_decode_error',
            'session_or_token_not_found', 'polling_exception'
        ]

        self.use_database = use_database
        self.remove_messages_from_database = remove_messages_from_database
        self.interval_timeout = interval_timeout
        self.session = session + ".rforge"

        if self.use_database:
            self.database = SyncDatabase()

        for _k in self.__allkeys:
            self.__whens[_k] = [] # pyright: ignore[reportArgumentType]
        
        if not os.path.exists(self.session):
            if not token:
                print("please enter a valid session path or enter a token")
                if "session_or_token_not_found" in self.__whens:
                    for wh in self.__whens['session_or_token_not_found']:
                        if wh.func:wh.func()

                sys.exit(0)
            
            self.__sql = sqlite3.connect(self.session, check_same_thread=False)
            self.token = token
            self.__sql.execute("CREATE TABLE IF NOT EXISTS session (sessionid INT PRIMARY KEY, token TEXT)")
            self.__sql.execute("INSERT INTO session (sessionid, token) VALUES (?, ?)", (1, self.token))
            self.__sql.commit()
        else:
            self.__sql = sqlite3.connect(self.session, check_same_thread=False)
            self.__sql.execute("CREATE TABLE IF NOT EXISTS session (sessionid INT PRIMARY KEY, token TEXT)")
            ___ = self.__sql.execute("SELECT * FROM session").fetchall()
            if len(___) == 0:
                self.token = token
                self.__sql.execute("INSERT INTO session (sessionid, token) VALUES (?, ?)", (1, token))
                self.__sql.commit()
            else:
                self.token = ___[0][1]

        self.net = MainNetwork(self.token if self.token else "", self.__whens)
    
    def create_markdown(self, text: str) -> dict[str, Any]:
        return create_markdown(text)

    def get_me(self) -> Bot:
        response = self.net.makeSyncRequest("getMe")
        return Bot.from_dict(response['data']['bot'])
    
    def send_text(
        self,
        chat_id: str,
        text: str,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        metadata: Union[MetadataBuilder, List[MetadataPart], None] = None,
        is_markdown: Union[bool, None] = None,
        reply_to_message_id: Union[str, None] = None
    ) -> str:
        inp = {
            "chat_id": chat_id,
            "text": text,
            "disable_notification": disable_notification
        }

        if inline_keypad:
            if isinstance(inline_keypad, InlineKeypad):
                inp['inline_keypad'] = inline_keypad.get_keypads()
        
        if chat_keypad:
            if isinstance(chat_keypad, ChatKeypad):
                inp['chat_keypad'] = chat_keypad.get_keypads()

            inp['chat_keypad_type'] = 'New' if (chat_keypad_type == None or (not isinstance(chat_keypad_type, str))) else chat_keypad_type

        if reply_to_message_id:
            inp['reply_to_message_id'] = reply_to_message_id

        if metadata:
            if isinstance(metadata, MetadataBuilder):
                inp['metadata'] = { "meta_data_parts": [md.to_dict() for md in metadata.getMetadataParts()] }
            elif isinstance(metadata, list):
                inp['metadata'] = { "meta_data_parts": [] }
                for mdata in metadata:
                    if isinstance(metadata, MetadataPart):
                        inp['metadata']['meta_data_parts'].append(mdata.to_dict())

        if is_markdown == True:
            text_metadata = self.create_markdown(text)
            inp['metadata'] = { "meta_data_parts": [md.to_dict() for md in text_metadata['metadata']] }
            inp['text'] = text_metadata['clean_text']

        print(inp)

        response = self.net.makeSyncRequest(
            "sendMessage",
            inp
        )

        return response['data']['message_id']

    def send_poll(
        self,
        chat_id: str,
        question: str,
        options: list[str]
    ) -> str:
        response = self.net.makeSyncRequest(
            "sendPoll",
            {
                "chat_id": chat_id,
                "question": question,
                "options": options
            }
        )

        return response['data']['message_id']
    
    def send_location(
        self,
        chat_id: str,
        latitude: str,
        longitude: str,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ) -> str:
        response = self.net.makeSyncRequest(
            "sendLocation",
            {
                "chat_id": chat_id,
                "latitude": latitude,
                "longitude": longitude,
                "disable_notification": disable_notification,
                "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
                "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
                "chat_keypad_type": chat_keypad_type,
                "reply_to_message_id": reply_to_message_id
            }
        )

        return response['data']['message_id']
    
    def send_contact(
        self,
        chat_id: str,
        first_name: str,
        phone_number: str,
        last_name: str = "",
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ) -> str:
        response = self.net.makeSyncRequest(
            "sendContact",
            {
                "chat_id": chat_id,
                "first_name": first_name,
                "phone_number": phone_number,
                "last_name": last_name,
                "disable_notification": disable_notification,
                "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
                "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
                "chat_keypad_type": chat_keypad_type,
                "reply_to_message_id": reply_to_message_id
            }
        )

        return response['data']['message_id']
    
    def get_chat(
        self,
        chat_id: str
    ) -> Chat:
        response = self.net.makeSyncRequest(
            "getChat",
            {
                "chat_id": chat_id
            }
        )

        return Chat.from_dict(response['data']['chat'])

    def get_updates(
        self,
        offset_id: Union[str, None] = None,
        limit: Union[str, None] = None
    ) -> RawUpdates:
        response = self.net.makeSyncRequest(
            "getUpdates",
            {
                "offset_id": offset_id,
                "limit": limit
            }
        )

        return RawUpdates.from_dict(response['data'])
    
    def get_last_update(
        self
    ) -> Union[Update, None]:
        response = self.get_updates()

        if response.updates and len(response.updates) !=  0:
            if not response.next_offset_id:
                return response.updates[-1]
            else:
                global __2_offset_id
                __2_offset_id = response.next_offset_id
                global __2_resps
                __2_resps = response
                while 1:
                    resp = self.get_updates(__2_offset_id)
                    if resp.updates:
                        if len(resp.updates) != 0:
                            __2_resps = resp
                            __2_offset_id = resp.next_offset_id
                            continue
                        elif len(resp.updates) == 0:
                            if __2_resps.updates:
                                return __2_resps.updates[-1]
                            else: return None
                    else:
                        if __2_resps.updates:
                            return __2_resps.updates[-1]
                        else: return None
        else:return None

    def attach_webhook_updates(self, raw_output: dict) -> RawUpdates:
        return RawUpdates.from_dict(raw_output['data'])
    
    def attach_single_webhook_update(self, raw_output: dict) -> Update:
        return Update.from_dict(raw_output['data'])

    def get_last_webhook_update(self, raw_output: dict) -> Union[Update, None]:
        _o = RawUpdates.from_dict(raw_output['data']).updates
        if _o and len(_o) != 0:
            return _o[-1]
        else:return None
    
    def change_interval_timeout(self, new_interval_timeout: int) -> bool:
        self.interval_timeout = new_interval_timeout
        return True
    
    def __store_new(self, message_id: Union[str, None]):
        self.__stored_new_mids.add(message_id)
    
    def __store_started(self, message_id: Union[str, None]):
        self.__stored_started_mids.add(message_id)
    
    def __store_updated(self, message_id: Union[str, None]):
        self.__stored_updated_mids.add(message_id)
    
    def __store_stopped(self, message_id: Union[str, None]):
        self.__stored_stopped_mids.add(message_id)

    def __store_removed(self, message_id: Union[str, None]):
        self.__stored_removed_mids.add(message_id)
    
    def __exists_new(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_new_mids)
    
    def __exists_started(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_started_mids)
    
    def __exists_updated(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_updated_mids)
    
    def __exists_stopped(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_stopped_mids)
    
    def __exists_removed(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_removed_mids)

    def __handle_new_message(self, last_update: Update) -> None:
        if not last_update.new_message:return
        if self.use_database:
            self.database.add_message(last_update.new_message)
        events = self.dict_events.get("NewMessage", [])
        if len(events) != 0:
            self.__store_new(last_update.new_message.id)
            for event in events:
                if not event.plugins:
                    if event.listener_func:
                        event.listener_func(last_update.new_message)

                    return

                if not isinstance(event.plugins, tuple):continue
                global all_plugins_match
                all_plugins_match = True

                for plugin in event.plugins:
                    global plugin_matches
                    plugin_matches = False
                    if (isinstance(plugin, Command) or isinstance(plugin, Contains) or isinstance(plugin, BeforeTimestamp) or isinstance(plugin, AfterTimestamp) or isinstance(plugin, Equals) or isinstance(plugin, isPrivate) or isinstance(plugin, isGroup) or isinstance(plugin, isChannel) or isinstance(plugin, isUnknown) or isinstance(plugin, isReply) or isinstance(plugin, isForwarded) or isinstance(plugin, hasBold) or isinstance(plugin, hasItalic) or isinstance(plugin, hasMono) or isinstance(plugin, hasUnderline) or isinstance(plugin, hasSpoiler) or isinstance(plugin, hasStrike) or isinstance(plugin, hasLink) or isinstance(plugin, hasMentionText) or isinstance(plugin, hasPre) or isinstance(plugin, hasQuote)):
                        if isinstance(plugin, Command):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if last_update.new_message.text.startswith("/" + plugin.text):
                                    plugin_matches = True
                        elif isinstance(plugin, Contains):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if plugin.isContains(last_update.new_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, BeforeTimestamp):
                            if last_update.new_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isBefore(last_update.new_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, AfterTimestamp):
                            if last_update.new_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isAfter(last_update.new_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, Equals):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if plugin.is_equal(last_update.new_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, isPrivate):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "private":
                                    plugin_matches = True
                        elif isinstance(plugin, isGroup):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "group":
                                    plugin_matches = True
                        elif isinstance(plugin, isChannel):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "channel":
                                    plugin_matches = True
                        elif isinstance(plugin, isUnknown):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "unknown":
                                    plugin_matches = True
                        elif isinstance(plugin, isReply):
                            if last_update.new_message.reply_to_message_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, isForwarded):
                            if last_update.new_message.forwarded_from and last_update.new_message.forwarded_from.from_sender_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, hasBold):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Bold":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasItalic):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Italic":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMono):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Mono":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasUnderline):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Underline":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasSpoiler):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Spoiler":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasStrike):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Strike":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasLink):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Link":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMentionText):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "MentionText":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasPre):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Pre":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasQuote):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Quote":
                                            plugin_matches = True
                                            break
                        if not plugin_matches:
                            all_plugins_match = False
                            break

                if all_plugins_match:
                    if event.listener_func:
                        event.listener_func(last_update.new_message)

    def __handle_started_bot(self, last_update: Update) -> None:
        if not last_update.new_message:return
        if self.use_database:
            self.database.add_message(last_update.new_message)
        events = self.dict_events.get("StartedBot", [])
        if len(events) != 0:
            self.__store_started(last_update.new_message.id)
            for event in events:
                if not event.plugins:
                    if event.listener_func:
                        event.listener_func(last_update.new_message)

                    return

                if not isinstance(event.plugins, tuple):continue
                global all_plugins_match
                all_plugins_match = True

                for plugin in event.plugins:
                    global plugin_matches
                    plugin_matches = False
                    if (isinstance(plugin, Command) or isinstance(plugin, Contains) or isinstance(plugin, BeforeTimestamp) or isinstance(plugin, AfterTimestamp) or isinstance(plugin, Equals) or isinstance(plugin, isPrivate) or isinstance(plugin, isGroup) or isinstance(plugin, isChannel) or isinstance(plugin, isUnknown) or isinstance(plugin, isReply) or isinstance(plugin, isForwarded) or isinstance(plugin, hasBold) or isinstance(plugin, hasItalic) or isinstance(plugin, hasMono) or isinstance(plugin, hasUnderline) or isinstance(plugin, hasSpoiler) or isinstance(plugin, hasStrike) or isinstance(plugin, hasLink) or isinstance(plugin, hasMentionText) or isinstance(plugin, hasPre) or isinstance(plugin, hasQuote)):
                        if isinstance(plugin, Command):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if last_update.new_message.text.startswith("/" + plugin.text):
                                    plugin_matches = True
                        elif isinstance(plugin, Contains):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if plugin.isContains(last_update.new_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, BeforeTimestamp):
                            if last_update.new_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isBefore(last_update.new_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, AfterTimestamp):
                            if last_update.new_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isAfter(last_update.new_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, Equals):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if plugin.is_equal(last_update.new_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, isPrivate):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "private":
                                    plugin_matches = True
                        elif isinstance(plugin, isGroup):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "group":
                                    plugin_matches = True
                        elif isinstance(plugin, isChannel):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "channel":
                                    plugin_matches = True
                        elif isinstance(plugin, isUnknown):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "unknown":
                                    plugin_matches = True
                        elif isinstance(plugin, isReply):
                            if last_update.new_message.reply_to_message_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, isForwarded):
                            if last_update.new_message.forwarded_from and last_update.new_message.forwarded_from.from_sender_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, hasBold):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Bold":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasItalic):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Italic":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMono):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Mono":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasUnderline):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Underline":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasSpoiler):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Spoiler":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasStrike):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Strike":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasLink):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Link":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMentionText):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "MentionText":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasPre):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Pre":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasQuote):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Quote":
                                            plugin_matches = True
                                            break
                        if not plugin_matches:
                            all_plugins_match = False
                            break

                if all_plugins_match:
                    if event.listener_func:
                        event.listener_func(last_update.new_message)

    def __handle_updated_message(self, last_update: Update) -> None:
        if not last_update.updated_message:return
        if not last_update.updated_message.id:return
        if self.use_database:
                self.database.update_message(last_update.updated_message.id, last_update.updated_message)
        events = self.dict_events.get("UpdatedMessage", [])
        if len(events) != 0:
            self.__store_updated(last_update.updated_message.id)
            for event in events:
                if not event.plugins:
                    if event.listener_func:
                        event.listener_func(last_update.updated_message)

                    return

                if not isinstance(event.plugins, tuple):continue
                global all_plugins_match
                all_plugins_match = True

                for plugin in event.plugins:
                    global plugin_matches
                    plugin_matches = False
                    if (isinstance(plugin, Command) or isinstance(plugin, Contains) or isinstance(plugin, BeforeTimestamp) or isinstance(plugin, AfterTimestamp) or isinstance(plugin, Equals) or isinstance(plugin, isPrivate) or isinstance(plugin, isGroup) or isinstance(plugin, isChannel) or isinstance(plugin, isUnknown) or isinstance(plugin, isReply) or isinstance(plugin, isForwarded) or isinstance(plugin, hasBold) or isinstance(plugin, hasItalic) or isinstance(plugin, hasMono) or isinstance(plugin, hasUnderline) or isinstance(plugin, hasSpoiler) or isinstance(plugin, hasStrike) or isinstance(plugin, hasLink) or isinstance(plugin, hasMentionText) or isinstance(plugin, hasPre) or isinstance(plugin, hasQuote)):
                        if isinstance(plugin, Command):
                            if last_update.updated_message.text and plugin.text and event.listener_func:
                                if last_update.updated_message.text.startswith("/" + plugin.text):
                                    plugin_matches = True
                        elif isinstance(plugin, Contains):
                            if last_update.updated_message.text and plugin.text and event.listener_func:
                                if plugin.isContains(last_update.updated_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, BeforeTimestamp):
                            if last_update.updated_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isBefore(last_update.updated_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, AfterTimestamp):
                            if last_update.updated_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isAfter(last_update.updated_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, Equals):
                            if last_update.updated_message.text and plugin.text and event.listener_func:
                                if plugin.is_equal(last_update.updated_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, isPrivate):
                            if last_update.updated_message.chat_type and event.listener_func:
                                if last_update.updated_message.chat_type == "private":
                                    plugin_matches = True
                        elif isinstance(plugin, isGroup):
                            if last_update.updated_message.chat_type and event.listener_func:
                                if last_update.updated_message.chat_type == "group":
                                    plugin_matches = True
                        elif isinstance(plugin, isChannel):
                            if last_update.updated_message.chat_type and event.listener_func:
                                if last_update.updated_message.chat_type == "channel":
                                    plugin_matches = True
                        elif isinstance(plugin, isUnknown):
                            if last_update.updated_message.chat_type and event.listener_func:
                                if last_update.updated_message.chat_type == "unknown":
                                    plugin_matches = True
                        elif isinstance(plugin, isReply):
                            if last_update.updated_message.reply_to_message_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, isForwarded):
                            if last_update.updated_message.forwarded_from and last_update.updated_message.forwarded_from.from_sender_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, hasBold):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Bold":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasItalic):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Italic":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMono):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Mono":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasUnderline):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Underline":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasSpoiler):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Spoiler":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasStrike):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Strike":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasLink):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Link":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMentionText):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "MentionText":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasPre):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Pre":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasQuote):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Quote":
                                            plugin_matches = True
                                            break
                        if not plugin_matches:
                            all_plugins_match = False
                            break

                if all_plugins_match:
                    if event.listener_func:
                        event.listener_func(last_update.updated_message)

    def __r(self):
        while (not self.__stop_event.is_set()):
            try:
                last_update = self.get_last_update()
                if last_update:
                    if last_update.type == "NewMessage":
                        if last_update.new_message:
                            _de = self.__exists_new(last_update.new_message.id)
                            if not _de:
                                self.__handle_new_message(last_update)
                    
                    if last_update.type == "StartedBot":
                        if last_update.new_message:
                            _de = self.__exists_started(last_update.new_message.id)
                            if not _de:
                                self.__handle_started_bot(last_update)
                    if last_update.type == "UpdatedMessage":
                        if last_update.updated_message:
                            _de = self.__exists_updated(last_update.updated_message.id)
                            if not _de:
                                self.__handle_updated_message(last_update)

                    if last_update.type == "StoppedBot":
                        _de = self.__exists_stopped(last_update.chat_id)
                        if not _de:
                            events = self.dict_events.get("StoppedBot", [])
                            if len(events) != 0:
                                self.__store_stopped(last_update.chat_id)
                                self.emit("StoppedBot", last_update.chat_id)

                    if last_update.type == "RemovedMessage":
                        _de = self.__exists_removed(last_update.removed_message_id)
                        if not _de:
                            events = self.dict_events.get("RemovedMessage", [])
                            if len(events) != 0:
                                self.__store_removed(last_update.removed_message_id)
                                self.emit("RemovedMessage", last_update.removed_message_id)
                                if self.remove_messages_from_database:
                                    if last_update.removed_message_id:
                                        self.database.delete_message(last_update.removed_message_id)

            except (KeyboardInterrupt, SystemExit):sys.exit(0)
            except json.JSONDecodeError:
                print("invalid data for decoding in json - caused by getUpdates")
                if "json_decode_error" in self.__whens:
                    for wh in self.__whens['json_decode_error']:
                        if wh.func:wh.func()
            except InternetConnectionError as ICE:
                print(ICE)
            except ServerResponseError:
                print("server response error detected - caused by getUpdates")
            except ClientInputError:
                print("client input got a wrong thing - caused by getUpdates")
            except StatusError as S:
                print(S)
            except Exception as E:
                print(E)
                if "polling_exception" in self.__whens:
                    for wh in self.__whens['polling_exception']:
                        if wh.func:wh.func()
            time.sleep(self.interval_timeout)

    def schedule(self, seconds: int = 10):
        def decorator(listener_func: Callable):
            self.__background_scheduler.add_job(listener_func, "interval", seconds=seconds)
            @wraps(listener_func)
            def wrapper(*args, **kwargs):
                return listener_func(*args, **kwargs)
            return wrapper
        return decorator
    
    def when(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ]):
        def decorator(listener_func: Callable):
            self.__whens[type].append(When(
                type,
                listener_func,
                'enable'
            ))

            @wraps(listener_func)
            def wrapper(*args, **kwargs):
                return listener_func(*args, **kwargs)
            return wrapper
        return decorator
    
    def enable_when_func(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ], func_name: str) -> bool:
        allwhenstype = self.__whens.get(type)
        if allwhenstype:
            for wh in allwhenstype:
                if wh.func:
                    if wh.func.__name__ == func_name:
                        return wh.enable()

        return False
    
    def disable_when_func(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ], func_name: str) -> bool:
        allwhenstype = self.__whens.get(type)
        if allwhenstype:
            for wh in allwhenstype:
                if wh.func:
                    if wh.func.__name__ == func_name:
                        return wh.disable()

        return False
    
    def enable_all_when_type(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ]) -> bool:
        allwhenstype = self.__whens.get(type)
        if allwhenstype:
            for wh in allwhenstype:
                wh.enable()

        return True
    
    def disable_all_when_type(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ]) -> bool:
        allwhenstype = self.__whens.get(type)
        if allwhenstype:
            for wh in allwhenstype:
                wh.disable()

        return True
    
    def enable_whens(self) -> bool:
        for k in self.__allkeys:
            whens = self.__whens.get(k) # pyright: ignore[reportArgumentType]
            if whens:
                for wh in whens:
                    wh.enable()

        return True
    
    def disable_whens(self) -> bool:
        for k in self.__allkeys:
            whens = self.__whens.get(k) # pyright: ignore[reportArgumentType]
            if whens:
                for wh in whens:
                    wh.disable()

        return True

    def start_schedule(self):
        self.__background_scheduler.start()
        if "started_schedule" in self.__whens:
            for wh in self.__whens['started_schedule']:
                if wh.func:wh.func()
        while True:...

    def start_both(self):
        self.start_polling()
        self.start_schedule()

    def start(self):
        self.start_polling()
        self.start_schedule()

    def clear_schedules(self) -> bool:
        self.__background_scheduler.remove_all_jobs()
        return True
    
    def stop_schedule(self):
        self.__background_scheduler.shutdown()
        if "stopped_schedule" in self.__whens:
            for wh in self.__whens['stopped_schedule']:
                if wh.func:wh.func()

    def close_schedule(self):
        self.__background_scheduler.shutdown()
        if "stopped_schedule" in self.__whens:
            for wh in self.__whens['stopped_schedule']:
                if wh.func:wh.func()

    def start_polling(self):
        self.__thread = threading.Thread(target=self.__r)
        self.__thread.start()
        if "started_polling" in self.__whens:
            for wh in self.__whens['started_polling']:
                if wh.func:wh.func()

    def close_polling(self):
        self.__stop_event.set()
        if self.__thread:self.__thread.join()
        self.__thread = None
        if "stopped_polling" in self.__whens:
            for wh in self.__whens['stopped_polling']:
                if wh.func:wh.func()

    def stop_polling(self):
        self.__stop_event.set()
        if self.__thread:self.__thread.join()
        self.__thread = None
        if "stopped_polling" in self.__whens:
            for wh in self.__whens['stopped_polling']:
                if wh.func:wh.func()

    def get_polling_status(self) -> bool:
        return (self.__stop_event.is_set() == False)
    
    def get_flowing_status(self) -> bool:
        return (self.__stop_event.is_set() == False)

    def forward_message(
        self,
        from_chat_id: str,
        to_chat_id: str,
        message_id: str,
        disable_notification: bool = False
    ) -> str:
        response = self.net.makeSyncRequest(
            "forwardMessage",
            {
                "from_chat_id": from_chat_id,
                "to_chat_id": to_chat_id,
                "message_id": message_id,
                "disable_notification": disable_notification
            }
        )

        return response['data']['new_message_id']

    def edit_message_text(
        self,
        chat_id: str,
        message_id: str,
        text: str
    ) -> bool:
        self.net.makeSyncRequest(
            "editMessageText",
            {
                "chat_id": chat_id,
                "message_id": message_id,
                "text": text
            }
        )

        return True

    def edit_message_keypad(
        self,
        chat_id: str,
        message_id: str,
        inline_keypad: InlineKeypad
    ) -> bool:
        self.net.makeSyncRequest(
            "editMessageKeypad",
            {
                "chat_id": chat_id,
                "message_id": message_id,
                "inline_keypad": inline_keypad.get_keypads()
            }
        )

        return True

    def delete_message(
        self,
        chat_id: str,
        message_id: str
    ) -> bool:
        self.net.makeSyncRequest(
            "deleteMessage",
            {
                "chat_id": chat_id,
                "message_id": message_id
            }
        )

        return True

    def set_commands(
        self,
        bot_commands: List[BotCommand]
    ) -> bool:
        self.net.makeSyncRequest(
            "setCommands",
            {
                "bot_commands": [x.to_dict() for x in bot_commands]
            }
        )

        return True

    def set_webhook(
        self,
        url: str,
        type: update_endpoint_type_enum
    ) -> bool:
        self.net.makeSyncRequest(
            "updateBotEndpoints",
            {
                "url": url,
                "type": type
            }
        )

        return True
    
    def add_webhook(
        self,
        url: str,
        type: update_endpoint_type_enum
    ) -> bool:
        return self.set_webhook(url, type)
    
    def delete_message_chatkeypad(
        self,
        chat_id: str
    ) -> bool:
        self.net.makeSyncRequest(
            "editChatKeypad",
            {
                "chat_id": chat_id,
                "chat_keypad_type": 'Remove'
            }
        )

        return True
    
    def edit_message_chatkeypad(
        self,
        chat_id: str,
        chat_keypad: ChatKeypad
    ) -> bool:
        self.net.makeSyncRequest(
            "editChatKeypad",
            {
                "chat_id": chat_id,
                "chat_keypad": chat_keypad.get_keypads(),
                "chat_keypad_type": 'New'
            }
        )

        return True
    
    def get_file_download_url(
        self,
        file_id: str
    ) -> str:
        res = self.net.makeSyncRequest(
            "getFile",
            {
                "file_id": file_id
            }
        )

        return res['data']['download_url']
    
    def download_file(
        self,
        file: File,
        save_to: Union[str, None] = None
    ) -> dict:
        filename = save_to if save_to is not None else file.file_name if isinstance(file.file_name, str) else ( uuid.uuid4().hex + ".rforge" )
        if isinstance(file.file_id, str):
            try:
                _f = self.get_file_download_url(file.file_id)
                with requests.get(_f, stream=True) as r:
                    r.raise_for_status()
                    with open(filename, 'wb') as f:
                        for chunk in r.iter_content(chunk_size=8192):
                            f.write(chunk)
                
                return { "status": True, "saved_as": filename }
            except requests.exceptions.RequestException as e:
                return { "status": False, "message": e }
            except Exception as e:
                return { "status": False, "message": e }
        else:
            return { "status": False, "message": "invalid file id type" }
    
    def send_file(
        self,
        chat_id: str,
        file_id: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ) -> str:
        response = self.net.makeSyncRequest(
            "sendFile",
            {
                "chat_id": chat_id,
                "file_id": file_id,
                "text": caption,
                "disable_notification": disable_notification,
                "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
                "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
                "chat_keypad_type": chat_keypad_type,
                "reply_to_message_id": reply_to_message_id
            }
        )
    
        return response['data']['message_id']
    
    def request_send_file(
        self,
        type: file_type_enum
    ) -> str:
        response = self.net.makeSyncRequest(
            "requestSendFile",
            {
                "type": type
            }
        )
    
        return response['data']['upload_url']
    
    def __read_stream(
        self,
        file_path: str
    ):
        return open(file_path, 'rb')

    def send_photo(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = self.__read_stream(path)
        reqed = self.request_send_file(
            "Image"
        )

        file = {
            "photo": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = self.net.synchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:wh.func()

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:wh.func()

            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:wh.func()
                raise ClientInputError(last_obj)

        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:wh.func()
                raise StatusError(__)
        
        file_id = __['data']['file_id']
        __realout = self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    def send_video(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = self.__read_stream(path)
        reqed = self.request_send_file(
            "Video"
        )

        file = {
            "video": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = self.net.synchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:wh.func()

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:wh.func()

            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:wh.func()
                raise ClientInputError(last_obj)

        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    def send_voice(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = self.__read_stream(path)
        reqed = self.request_send_file(
            "Voice"
        )

        file = {
            "voice": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = self.net.synchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:wh.func()

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:wh.func()

            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:wh.func()
                raise ClientInputError(last_obj)

        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    def send_music(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = self.__read_stream(path)
        reqed = self.request_send_file(
            "Music"
        )

        file = {
            "music": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = self.net.synchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:wh.func()

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:wh.func()

            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:wh.func()
                raise ClientInputError(last_obj)

        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    def send_document(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = self.__read_stream(path)
        reqed = self.request_send_file(
            "File"
        )

        file = {
            "document": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = self.net.synchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:wh.func()

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:wh.func()

            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:wh.func()
                raise ClientInputError(last_obj)

        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    def send_gif(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = self.__read_stream(path)
        reqed = self.request_send_file(
            "Gif"
        )

        file = {
            "gif": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = self.net.synchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:wh.func()

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:wh.func()

            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:wh.func()
                raise ClientInputError(last_obj)

        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    def ban_user(
        self,
        chat_id: str,
        user_id: str
    ) -> bool:
        self.net.makeSyncRequest(
            "banChatMember",
            {
                "chat_id": chat_id,
                "user_id": user_id
            }
        )

        return True
    
    def unban_user(
        self,
        chat_id: str,
        user_id: str
    ) -> bool:
        self.net.makeSyncRequest(
            "unbanChatMember",
            {
                "chat_id": chat_id,
                "user_id": user_id
            }
        )

        return True

class AsyncClient(AsyncEventEmitter):
    database: AsyncDatabase

    def __init__(self, session: str, token: Union[str, None] = None, interval_timeout: Union[int, float] = 0.3, use_database: bool = False, remove_messages_from_database: bool = False):

        super().__init__()

        self.__stored_new_mids = set()
        self.__stored_started_mids = set()
        self.__stored_updated_mids = set()
        self.__stored_stopped_mids = set()
        self.__stored_removed_mids = set()
        self.__stop_event = asyncio.Event()
        self.__thread: Union[threading.Thread, None] = None
        self.__background_scheduler = AsyncIOScheduler()
        self.__is_running = False
        self.__whens: Dict[Literal[
            'started_polling', 'stopped_polling',
            'started_schedule', 'stopped_schedule',
            'internet_connection_error', 'timeout_error', # internet_connection_error and timeout_error are the same
            'server_response_error', 'client_input_error',
            'status_error', 'json_decode_error',
            'session_or_token_not_found', 'polling_exception'
        ], List[When]] = {}
        self.__allkeys = [
            'started_polling', 'stopped_polling',
            'started_schedule', 'stopped_schedule',
            'internet_connection_error', 'timeout_error',
            'server_response_error', 'client_input_error',
            'status_error', 'json_decode_error',
            'session_or_token_not_found', 'polling_exception'
        ]

        self.use_database = use_database
        self.remove_messages_from_database = remove_messages_from_database
        self.interval_timeout = interval_timeout
        self.session = session + ".rforge"

        if self.use_database:
            self.database = AsyncDatabase()

        for _k in self.__allkeys:
            self.__whens[_k] = [] # pyright: ignore[reportArgumentType]
        
        if not os.path.exists(self.session):
            if not token:
                print("please enter a valid session path or enter a token")
                if "session_or_token_not_found" in self.__whens:
                    for wh in self.__whens['session_or_token_not_found']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):asyncio.run(wh.func())

                sys.exit(0)
            
            self.__sql = sqlite3.connect(self.session, check_same_thread=False)
            self.token = token
            self.__sql.execute("CREATE TABLE IF NOT EXISTS session (sessionid INT PRIMARY KEY, token TEXT)")
            self.__sql.execute("INSERT INTO session (sessionid, token) VALUES (?, ?)", (1, self.token))
            self.__sql.commit()
        else:
            self.__sql = sqlite3.connect(self.session, check_same_thread=False)
            self.__sql.execute("CREATE TABLE IF NOT EXISTS session (sessionid INT PRIMARY KEY, token TEXT)")
            ___ = self.__sql.execute("SELECT * FROM session").fetchall()
            if len(___) == 0:
                self.token = token
                self.__sql.execute("INSERT INTO session (sessionid, token) VALUES (?, ?)", (1, token))
                self.__sql.commit()
            else:
                self.token = ___[0][1]

        self.net = MainNetwork(self.token if self.token else "", self.__whens)
    
    async def create_markdown(self, text: str) -> dict[str, Any]:
        return create_markdown(text)

    async def get_me(self) -> Bot:
        response = await self.net.makeAsyncRequest("getMe")
        return Bot.from_dict(response['data']['bot'])
    
    async def send_text(
        self,
        chat_id: str,
        text: str,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        metadata: Union[MetadataBuilder, List[MetadataPart], None] = None,
        is_markdown: Union[bool, None] = None,
        reply_to_message_id: Union[str, None] = None
    ) -> str:
        inp = {
            "chat_id": chat_id,
            "text": text,
            "disable_notification": disable_notification
        }

        if inline_keypad:
            if isinstance(inline_keypad, InlineKeypad):
                inp['inline_keypad'] = inline_keypad.get_keypads()
        
        if chat_keypad:
            if isinstance(chat_keypad, ChatKeypad):
                inp['chat_keypad'] = chat_keypad.get_keypads()

            inp['chat_keypad_type'] = 'New' if (chat_keypad_type == None or (not isinstance(chat_keypad_type, str))) else chat_keypad_type

        if reply_to_message_id:
            inp['reply_to_message_id'] = reply_to_message_id

        if metadata:
            if isinstance(metadata, MetadataBuilder):
                inp['metadata'] = { "meta_data_parts": [md.to_dict() for md in metadata.getMetadataParts()] }
            elif isinstance(metadata, list):
                inp['metadata'] = { "meta_data_parts": [] }
                for mdata in metadata:
                    if isinstance(metadata, MetadataPart):
                        inp['metadata']['meta_data_parts'].append(mdata.to_dict())

        if is_markdown == True:
            text_metadata = await self.create_markdown(text)
            inp['metadata'] = { "meta_data_parts": [md.to_dict() for md in text_metadata['metadata']] }
            inp['text'] = text_metadata['clean_text']

        response = await self.net.makeAsyncRequest(
            "sendMessage",
            inp
        )

        return response['data']['message_id']

    async def send_poll(
        self,
        chat_id: str,
        question: str,
        options: list[str]
    ) -> str:
        response = await self.net.makeAsyncRequest(
            "sendPoll",
            {
                "chat_id": chat_id,
                "question": question,
                "options": options
            }
        )

        return response['data']['message_id']
    
    async def send_location(
        self,
        chat_id: str,
        latitude: str,
        longitude: str,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ) -> str:
        response = await self.net.makeAsyncRequest(
            "sendLocation",
            {
                "chat_id": chat_id,
                "latitude": latitude,
                "longitude": longitude,
                "disable_notification": disable_notification,
                "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
                "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
                "chat_keypad_type": chat_keypad_type,
                "reply_to_message_id": reply_to_message_id
            }
        )

        return response['data']['message_id']
    
    async def send_contact(
        self,
        chat_id: str,
        first_name: str,
        phone_number: str,
        last_name: str = "",
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ) -> str:
        response = await self.net.makeAsyncRequest(
            "sendContact",
            {
                "chat_id": chat_id,
                "first_name": first_name,
                "phone_number": phone_number,
                "last_name": last_name,
                "disable_notification": disable_notification,
                "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
                "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
                "chat_keypad_type": chat_keypad_type,
                "reply_to_message_id": reply_to_message_id
            }
        )

        return response['data']['message_id']
    
    async def get_chat(
        self,
        chat_id: str
    ) -> Chat:
        response = await self.net.makeAsyncRequest(
            "getChat",
            {
                "chat_id": chat_id
            }
        )

        return Chat.from_dict(response['data']['chat'])

    async def get_updates(
        self,
        offset_id: Union[str, None] = None,
        limit: Union[str, None] = None
    ) -> RawUpdates:
        response = await self.net.makeAsyncRequest(
            "getUpdates",
            {
                "offset_id": offset_id,
                "limit": limit
            }
        )

        return RawUpdates.from_dict(response['data'])
    
    async def get_last_update(
        self,
    ) -> Union[Update, None]:
        response = await self.get_updates()

        if response.updates and len(response.updates) !=  0:
            if not response.next_offset_id:
                return response.updates[-1]
            else:
                global __2_offset_id
                __2_offset_id = response.next_offset_id
                global __2_resps
                __2_resps = response
                while 1:
                    resp = await self.get_updates(__2_offset_id)
                    if resp.updates:
                        if len(resp.updates) != 0:
                            __2_resps = resp
                            __2_offset_id = resp.next_offset_id
                            continue
                        elif len(resp.updates) == 0:
                            if __2_resps.updates:
                                return __2_resps.updates[-1]
                            else: return None
                    else:
                        if __2_resps.updates:
                            return __2_resps.updates[-1]
                        else: return None
        else:return None
    
    async def attach_webhook_updates(self, raw_output: dict) -> RawUpdates:
        return RawUpdates.from_dict(raw_output['data'])
    
    async def attach_single_webhook_update(self, raw_output: dict) -> Update:
        return Update.from_dict(raw_output['data'])

    async def get_last_webhook_update(self, raw_output: dict) -> Union[Update, None]:
        _o = RawUpdates.from_dict(raw_output['data']).updates
        if _o and len(_o) != 0:
            return _o[-1]
        else:return None
    
    async def change_interval_timeout(self, new_interval_timeout: int) -> bool:
        self.interval_timeout = new_interval_timeout
        return True
    
    async def __store_new(self, message_id: Union[str, None]):
        self.__stored_new_mids.add(message_id)
    
    async def __store_started(self, message_id: Union[str, None]):
        self.__stored_started_mids.add(message_id)
    
    async def __store_updated(self, message_id: Union[str, None]):
        self.__stored_updated_mids.add(message_id)
    
    async def __store_stopped(self, message_id: Union[str, None]):
        self.__stored_stopped_mids.add(message_id)

    async def __store_removed(self, message_id: Union[str, None]):
        self.__stored_removed_mids.add(message_id)
    
    async def __exists_new(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_new_mids)
    
    async def __exists_started(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_started_mids)
    
    async def __exists_updated(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_updated_mids)
    
    async def __exists_stopped(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_stopped_mids)
    
    async def __exists_removed(self, message_id: Union[str, None]) -> bool:
        return (message_id in self.__stored_removed_mids)
    
    async def __handle_new_message(self, last_update: Update) -> None:
        if not last_update.new_message:return
        if self.use_database:
            await self.database.add_message(last_update.new_message)
        events = self.dict_events.get("NewMessage", [])
        if len(events) != 0:
            await self.__store_new(last_update.new_message.id)
            for event in events:
                if not event.plugins:
                    if event.listener_func:
                        await event.listener_func(last_update.new_message)

                    return

                if not isinstance(event.plugins, tuple):continue
                global all_plugins_match
                all_plugins_match = True

                for plugin in event.plugins:
                    global plugin_matches
                    plugin_matches = False
                    if (isinstance(plugin, Command) or isinstance(plugin, Contains) or isinstance(plugin, BeforeTimestamp) or isinstance(plugin, AfterTimestamp) or isinstance(plugin, Equals) or isinstance(plugin, isPrivate) or isinstance(plugin, isGroup) or isinstance(plugin, isChannel) or isinstance(plugin, isUnknown) or isinstance(plugin, isReply) or isinstance(plugin, isForwarded) or isinstance(plugin, hasBold) or isinstance(plugin, hasItalic) or isinstance(plugin, hasMono) or isinstance(plugin, hasUnderline) or isinstance(plugin, hasSpoiler) or isinstance(plugin, hasStrike) or isinstance(plugin, hasLink) or isinstance(plugin, hasMentionText) or isinstance(plugin, hasPre) or isinstance(plugin, hasQuote)):
                        if isinstance(plugin, Command):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if last_update.new_message.text.startswith("/" + plugin.text):
                                    plugin_matches = True
                        elif isinstance(plugin, Contains):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if plugin.isContains(last_update.new_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, BeforeTimestamp):
                            if last_update.new_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isBefore(last_update.new_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, AfterTimestamp):
                            if last_update.new_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isAfter(last_update.new_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, Equals):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if plugin.is_equal(last_update.new_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, isPrivate):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "private":
                                    plugin_matches = True
                        elif isinstance(plugin, isGroup):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "group":
                                    plugin_matches = True
                        elif isinstance(plugin, isChannel):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "channel":
                                    plugin_matches = True
                        elif isinstance(plugin, isUnknown):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "unknown":
                                    plugin_matches = True
                        elif isinstance(plugin, isReply):
                            if last_update.new_message.reply_to_message_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, isForwarded):
                            if last_update.new_message.forwarded_from and last_update.new_message.forwarded_from.from_sender_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, hasBold):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Bold":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasItalic):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Italic":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMono):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Mono":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasUnderline):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Underline":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasSpoiler):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Spoiler":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasStrike):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Strike":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasLink):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Link":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMentionText):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "MentionText":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasPre):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Pre":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasQuote):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Quote":
                                            plugin_matches = True
                                            break
                        if not plugin_matches:
                            all_plugins_match = False
                            break

                if all_plugins_match:
                    if event.listener_func:
                        await event.listener_func(last_update.new_message)

    async def __handle_started_bot(self, last_update: Update) -> None:
        if not last_update.new_message:return
        if self.use_database:
            await self.database.add_message(last_update.new_message)
        events = self.dict_events.get("StartedBot", [])
        if len(events) != 0:
            await self.__store_started(last_update.new_message.id)
            for event in events:
                if not event.plugins:
                    if event.listener_func:
                        await event.listener_func(last_update.new_message)

                    return

                if not isinstance(event.plugins, tuple):continue
                global all_plugins_match
                all_plugins_match = True

                for plugin in event.plugins:
                    global plugin_matches
                    plugin_matches = False
                    if (isinstance(plugin, Command) or isinstance(plugin, Contains) or isinstance(plugin, BeforeTimestamp) or isinstance(plugin, AfterTimestamp) or isinstance(plugin, Equals) or isinstance(plugin, isPrivate) or isinstance(plugin, isGroup) or isinstance(plugin, isChannel) or isinstance(plugin, isUnknown) or isinstance(plugin, isReply) or isinstance(plugin, isForwarded) or isinstance(plugin, hasBold) or isinstance(plugin, hasItalic) or isinstance(plugin, hasMono) or isinstance(plugin, hasUnderline) or isinstance(plugin, hasSpoiler) or isinstance(plugin, hasStrike) or isinstance(plugin, hasLink) or isinstance(plugin, hasMentionText) or isinstance(plugin, hasPre) or isinstance(plugin, hasQuote)):
                        if isinstance(plugin, Command):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if last_update.new_message.text.startswith("/" + plugin.text):
                                    plugin_matches = True
                        elif isinstance(plugin, Contains):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if plugin.isContains(last_update.new_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, BeforeTimestamp):
                            if last_update.new_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isBefore(last_update.new_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, AfterTimestamp):
                            if last_update.new_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isAfter(last_update.new_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, Equals):
                            if last_update.new_message.text and plugin.text and event.listener_func:
                                if plugin.is_equal(last_update.new_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, isPrivate):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "private":
                                    plugin_matches = True
                        elif isinstance(plugin, isGroup):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "group":
                                    plugin_matches = True
                        elif isinstance(plugin, isChannel):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "channel":
                                    plugin_matches = True
                        elif isinstance(plugin, isUnknown):
                            if last_update.new_message.chat_type and event.listener_func:
                                if last_update.new_message.chat_type == "unknown":
                                    plugin_matches = True
                        elif isinstance(plugin, isReply):
                            if last_update.new_message.reply_to_message_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, isForwarded):
                            if last_update.new_message.forwarded_from and last_update.new_message.forwarded_from.from_sender_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, hasBold):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Bold":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasItalic):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Italic":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMono):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Mono":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasUnderline):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Underline":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasSpoiler):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Spoiler":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasStrike):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Strike":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasLink):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Link":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMentionText):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "MentionText":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasPre):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Pre":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasQuote):
                            if last_update.new_message.metadata and event.listener_func:
                                if last_update.new_message.metadata.meta_data_parts:
                                    for _ in last_update.new_message.metadata.meta_data_parts:
                                        if _.type == "Quote":
                                            plugin_matches = True
                                            break
                        if not plugin_matches:
                            all_plugins_match = False
                            break

                if all_plugins_match:
                    if event.listener_func:
                        if self.use_database:
                            await self.database.add_message(last_update.new_message)
                            await event.listener_func(last_update.new_message)
                        else:
                            await event.listener_func(last_update.new_message)

    async def __handle_updated_message(self, last_update: Update) -> None:
        if not last_update.updated_message:return
        if not last_update.updated_message.id:return
        if self.use_database:
            await self.database.update_message(last_update.updated_message.id, last_update.updated_message)
        events = self.dict_events.get("UpdatedMessage", [])
        if len(events) != 0:
            await self.__store_updated(last_update.updated_message.id)
            for event in events:
                if not event.plugins:
                    if event.listener_func:
                        if self.use_database:
                            await self.database.update_message(last_update.updated_message.id, last_update.updated_message)
                            await event.listener_func(last_update.updated_message)
                        else:
                            await event.listener_func(last_update.updated_message)

                    return

                if not isinstance(event.plugins, tuple):continue
                global all_plugins_match
                all_plugins_match = True

                for plugin in event.plugins:
                    global plugin_matches
                    plugin_matches = False
                    if (isinstance(plugin, Command) or isinstance(plugin, Contains) or isinstance(plugin, BeforeTimestamp) or isinstance(plugin, AfterTimestamp) or isinstance(plugin, Equals) or isinstance(plugin, isPrivate) or isinstance(plugin, isGroup) or isinstance(plugin, isChannel) or isinstance(plugin, isUnknown) or isinstance(plugin, isReply) or isinstance(plugin, isForwarded) or isinstance(plugin, hasBold) or isinstance(plugin, hasItalic) or isinstance(plugin, hasMono) or isinstance(plugin, hasUnderline) or isinstance(plugin, hasSpoiler) or isinstance(plugin, hasStrike) or isinstance(plugin, hasLink) or isinstance(plugin, hasMentionText) or isinstance(plugin, hasPre) or isinstance(plugin, hasQuote)):
                        if isinstance(plugin, Command):
                            if last_update.updated_message.text and plugin.text and event.listener_func:
                                if last_update.updated_message.text.startswith("/" + plugin.text):
                                    plugin_matches = True
                        elif isinstance(plugin, Contains):
                            if last_update.updated_message.text and plugin.text and event.listener_func:
                                if plugin.isContains(last_update.updated_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, BeforeTimestamp):
                            if last_update.updated_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isBefore(last_update.updated_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, AfterTimestamp):
                            if last_update.updated_message.time and plugin.timestamp and event.listener_func:
                                if plugin.isAfter(last_update.updated_message.time):
                                    plugin_matches = True
                        elif isinstance(plugin, Equals):
                            if last_update.updated_message.text and plugin.text and event.listener_func:
                                if plugin.is_equal(last_update.updated_message.text):
                                    plugin_matches = True
                        elif isinstance(plugin, isPrivate):
                            if last_update.updated_message.chat_type and event.listener_func:
                                if last_update.updated_message.chat_type == "private":
                                    plugin_matches = True
                        elif isinstance(plugin, isGroup):
                            if last_update.updated_message.chat_type and event.listener_func:
                                if last_update.updated_message.chat_type == "group":
                                    plugin_matches = True
                        elif isinstance(plugin, isChannel):
                            if last_update.updated_message.chat_type and event.listener_func:
                                if last_update.updated_message.chat_type == "channel":
                                    plugin_matches = True
                        elif isinstance(plugin, isUnknown):
                            if last_update.updated_message.chat_type and event.listener_func:
                                if last_update.updated_message.chat_type == "unknown":
                                    plugin_matches = True
                        elif isinstance(plugin, isReply):
                            if last_update.updated_message.reply_to_message_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, isForwarded):
                            if last_update.updated_message.forwarded_from and last_update.updated_message.forwarded_from.from_sender_id and event.listener_func:
                                plugin_matches = True
                        elif isinstance(plugin, hasBold):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Bold":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasItalic):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Italic":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMono):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Mono":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasUnderline):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Underline":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasSpoiler):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Spoiler":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasStrike):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Strike":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasLink):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Link":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasMentionText):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "MentionText":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasPre):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Pre":
                                            plugin_matches = True
                                            break
                        elif isinstance(plugin, hasQuote):
                            if last_update.updated_message.metadata and event.listener_func:
                                if last_update.updated_message.metadata.meta_data_parts:
                                    for _ in last_update.updated_message.metadata.meta_data_parts:
                                        if _.type == "Quote":
                                            plugin_matches = True
                                            break
                        if not plugin_matches:
                            all_plugins_match = False
                            break

                if all_plugins_match:
                    if event.listener_func:
                        if self.use_database:
                            await self.database.update_message(last_update.updated_message.id, last_update.updated_message)
                            await event.listener_func(last_update.updated_message)
                        else:
                            await event.listener_func(last_update.updated_message)

    async def __r(self, offset_id: Union[str, None] = None):
        while (not self.__stop_event.is_set()):
            try:
                last_update = await self.get_last_update()
                if last_update:
                    if last_update.type == "NewMessage":
                        if last_update.new_message:
                            _de = await self.__exists_new(last_update.new_message.id)
                            if not _de:
                                await self.__handle_new_message(last_update)
                    
                    if last_update.type == "StartedBot":
                        if last_update.new_message:
                            _de = await self.__exists_started(last_update.new_message.id)
                            if not _de:
                                await self.__handle_started_bot(last_update)

                    if last_update.type == "UpdatedMessage":
                        if last_update.updated_message:
                            _de = await self.__exists_updated(last_update.updated_message.id)
                            if not _de:
                                await self.__handle_updated_message(last_update)

                    if last_update.type == "StoppedBot":
                        _de = await self.__exists_stopped(last_update.chat_id)
                        if not _de:
                            events = self.dict_events.get("StoppedBot", [])
                            if len(events) != 0:
                                await self.__store_removed(last_update.removed_message_id)
                                await self.emit("StoppedBot", last_update.removed_message_id)

                    if last_update.type == "RemovedMessage":
                        _de = await self.__exists_removed(last_update.removed_message_id)
                        if not _de:
                            events = self.dict_events.get("RemovedMessage", [])
                            if len(events) != 0:
                                await self.__store_removed(last_update.removed_message_id)
                                await self.emit("RemovedMessage", last_update.removed_message_id)
                                if self.remove_messages_from_database:
                                    if last_update.removed_message_id:
                                        await self.database.delete_message(last_update.removed_message_id)

            except (KeyboardInterrupt, SystemExit):sys.exit(0)
            except json.JSONDecodeError:
                print("invalid data for decoding in json")
                if "json_decode_error" in self.__whens:
                    for wh in self.__whens['json_decode_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
            except InternetConnectionError as ICE:
                print(ICE)
            except ServerResponseError:
                print("server response error detected")
            except ClientInputError:
                print("client input got a wrong thing")
            except StatusError as S:
                print(S)
            except Exception as E:
                print(E)
                if "polling_exception" in self.__whens:
                    for wh in self.__whens['polling_exception']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
            await asyncio.sleep(self.interval_timeout)
    
    def schedule(self, seconds: int = 10):
        def async_decorator(func):
            if not asyncio.iscoroutinefunction(func):
                raise TypeError("Scheduled functions must be async.")
            self.__background_scheduler.add_job(func, "interval", seconds=seconds, id=func.__name__)
            @wraps(func)
            async def wrapper(*args, **kwargs):
                pass
            return func
        return async_decorator
    
    def when(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ]):
        def async_decorator(func):
            if not asyncio.iscoroutinefunction(func):
                raise TypeError("Scheduled functions must be async.")
            self.__whens[type].append(When(
                type,
                func,
                'enable'
            ))

            @wraps(func)
            async def wrapper(*args, **kwargs):
                pass
            return func
        return async_decorator
    
    async def enable_when_func(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ], func_name: str) -> bool:
        allwhenstype = self.__whens.get(type)
        if allwhenstype:
            for wh in allwhenstype:
                if wh.func:
                    if wh.func.__name__ == func_name:
                        return wh.enable()

        return False
    
    async def disable_when_func(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ], func_name: str) -> bool:
        allwhenstype = self.__whens.get(type)
        if allwhenstype:
            for wh in allwhenstype:
                if wh.func:
                    if wh.func.__name__ == func_name:
                        return wh.disable()

        return False
    
    async def enable_all_when_type(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ]) -> bool:
        allwhenstype = self.__whens.get(type)
        if allwhenstype:
            for wh in allwhenstype:
                wh.enable()

        return True
    
    async def disable_all_when_type(self, type: Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error',
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ]) -> bool:
        allwhenstype = self.__whens.get(type)
        if allwhenstype:
            for wh in allwhenstype:
                wh.disable()

        return True
    
    async def enable_whens(self) -> bool:
        for k in self.__allkeys:
            whens = self.__whens.get(k) # pyright: ignore[reportArgumentType]
            if whens:
                for wh in whens:
                    wh.enable()

        return True
    
    async def disable_whens(self) -> bool:
        for k in self.__allkeys:
            whens = self.__whens.get(k) # pyright: ignore[reportArgumentType]
            if whens:
                for wh in whens:
                    wh.disable()

        return True

    async def __schedule_runner(self):
        if self.__is_running:
            return

        self.__background_scheduler.start()
        self.__is_running = True

        try:
            while True:
                await asyncio.Future()
        except asyncio.CancelledError:print("Main loop cancelled")
        finally:
            self.__background_scheduler.shutdown()
            self.__is_running = False

    async def start_schedule(self):
        if "started_schedule" in self.__whens:
            for wh in self.__whens['started_schedule']:
                if wh.func:
                    if asyncio.iscoroutinefunction(wh.func):await wh.func()
        await self.__schedule_runner()

    async def start_both(self):
        await asyncio.gather(self.start_polling(), self.start_schedule())

    async def start(self):
        await asyncio.gather(self.start_polling(), self.start_schedule())

    async def clear_schedules(self) -> bool:
        self.__background_scheduler.remove_all_jobs()
        return True
    
    async def stop_schedule(self):
        self.__background_scheduler.shutdown()
        if "stopped_schedule" in self.__whens:
            for wh in self.__whens['stopped_schedule']:
                if wh.func:
                    if asyncio.iscoroutinefunction(wh.func):await wh.func()

    async def close_schedule(self):
        self.__background_scheduler.shutdown()
        if "stopped_schedule" in self.__whens:
            for wh in self.__whens['stopped_schedule']:
                if wh.func:
                    if asyncio.iscoroutinefunction(wh.func):await wh.func()

    async def start_polling(self, offset_id: Union[str, None] = None):
        self.__stop_event.clear()
        if "started_polling" in self.__whens:
            for wh in self.__whens['started_polling']:
                if wh.func:
                    if asyncio.iscoroutinefunction(wh.func):await wh.func()
        await self.__r(offset_id)

    async def close_polling(self):
        self.__stop_event.set()
        if self.__thread:self.__thread.join()
        self.__thread = None
        if "stopped_polling" in self.__whens:
            for wh in self.__whens['stopped_polling']:
                if wh.func:
                    if asyncio.iscoroutinefunction(wh.func):await wh.func()

    async def stop_polling(self):
        self.__stop_event.set()
        if self.__thread:self.__thread.join()
        self.__thread = None
        if "stopped_polling" in self.__whens:
            for wh in self.__whens['stopped_polling']:
                if wh.func:
                    if asyncio.iscoroutinefunction(wh.func):await wh.func()

    async def get_polling_status(self) -> bool:
        return (self.__stop_event.is_set() == False)
    
    async def get_flowing_status(self) -> bool:
        return (self.__stop_event.is_set() == False)

    async def forward_message(
        self,
        from_chat_id: str,
        to_chat_id: str,
        message_id: str,
        disable_notification: bool = False
    ) -> str:
        response = await self.net.makeAsyncRequest(
            "forwardMessage",
            {
                "from_chat_id": from_chat_id,
                "to_chat_id": to_chat_id,
                "message_id": message_id,
                "disable_notification": disable_notification
            }
        )

        return response['data']['new_message_id']

    async def edit_message_text(
        self,
        chat_id: str,
        message_id: str,
        text: str
    ) -> bool:
        await self.net.makeAsyncRequest(
            "editMessageText",
            {
                "chat_id": chat_id,
                "message_id": message_id,
                "text": text
            }
        )

        return True

    async def edit_message_keypad(
        self,
        chat_id: str,
        message_id: str,
        inline_keypad: InlineKeypad
    ) -> bool:
        await self.net.makeAsyncRequest(
            "editMessageKeypad",
            {
                "chat_id": chat_id,
                "message_id": message_id,
                "inline_keypad": inline_keypad.get_keypads()
            }
        )

        return True

    async def delete_message(
        self,
        chat_id: str,
        message_id: str
    ) -> bool:
        await self.net.makeAsyncRequest(
            "deleteMessage",
            {
                "chat_id": chat_id,
                "message_id": message_id
            }
        )

        return True

    async def set_commands(
        self,
        bot_commands: List[BotCommand]
    ) -> bool:
        await self.net.makeAsyncRequest(
            "setCommands",
            {
                "bot_commands": [x.to_dict() for x in bot_commands]
            }
        )

        return True

    async def set_webhook(
        self,
        url: str,
        type: update_endpoint_type_enum
    ) -> bool:
        await self.net.makeAsyncRequest(
            "updateBotEndpoints",
            {
                "url": url,
                "type": type
            }
        )

        return True
    
    async def add_webhook(
        self,
        url: str,
        type: update_endpoint_type_enum
    ) -> bool:
        return await self.set_webhook(url, type)
    
    async def delete_message_chatkeypad(
        self,
        chat_id: str
    ) -> bool:
        await self.net.makeAsyncRequest(
            "editChatKeypad",
            {
                "chat_id": chat_id,
                "chat_keypad_type": 'Remove'
            }
        )

        return True
    
    async def edit_message_chatkeypad(
        self,
        chat_id: str,
        chat_keypad: ChatKeypad
    ) -> bool:
        await self.net.makeAsyncRequest(
            "editChatKeypad",
            {
                "chat_id": chat_id,
                "chat_keypad": chat_keypad.get_keypads(),
                "chat_keypad_type": 'New'
            }
        )

        return True
    
    async def get_file_download_url(
        self,
        file_id: str
    ) -> str:
        res = await self.net.makeAsyncRequest(
            "getFile",
            {
                "file_id": file_id
            }
        )

        return res['data']['download_url']
    
    async def download_file(
        self,
        file: File,
        save_to: Union[str, None] = None
    ) -> dict:
        filename = save_to if save_to is not None else file.file_name if isinstance(file.file_name, str) else ( uuid.uuid4().hex + ".rforge" )
        if isinstance(file.file_id, str):
            try:
                _f = await self.get_file_download_url(file.file_id)
                async with aiohttp.ClientSession() as session:
                    async with session.get(_f) as resp:
                        resp.raise_for_status()
                        async with aiofiles.open(filename, "wb") as filex:
                            while True:
                                chunk = await resp.content.read(8192)
                                if not chunk:
                                    break
                                await filex.write(chunk)     
                return { "status": True, "saved_as": filename }
            except aiohttp.ClientError as e:
                return { "status": False, "message": e }
            except Exception as e:
                return { "status": False, "message": e }
        else:
            return { "status": False, "message": "invalid file id type" }
    
    async def send_file(
        self,
        chat_id: str,
        file_id: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ) -> str:
        response = await self.net.makeAsyncRequest(
            "sendFile",
            {
                "chat_id": chat_id,
                "file_id": file_id,
                "text": caption,
                "disable_notification": disable_notification,
                "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
                "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
                "chat_keypad_type": chat_keypad_type,
                "reply_to_message_id": reply_to_message_id
            }
        )
    
        return response['data']['message_id']
    
    async def request_send_file(
        self,
        type: file_type_enum
    ) -> str:
        response = await self.net.makeAsyncRequest(
            "requestSendFile",
            {
                "type": type
            }
        )
    
        return response['data']['upload_url']
    
    async def __read_stream(
        self,
        file_path: str
    ):
        return await aiofiles.open(file_path, 'rb')

    async def send_photo(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = await self.__read_stream(path)
        read_path = await read_path.read()
        reqed = await self.request_send_file(
            "Image"
        )

        file = {
            "photo": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = await self.net.asynchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
                            

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ClientInputError(last_obj)
        
        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = await self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    async def send_video(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = await self.__read_stream(path)
        read_path = await read_path.read()
        reqed = await self.request_send_file(
            "Video"
        )

        file = {
            "video": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = await self.net.asynchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
                            

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ClientInputError(last_obj)
        
        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = await self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    async def send_voice(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = await self.__read_stream(path)
        read_path = await read_path.read()
        reqed = await self.request_send_file(
            "Voice"
        )

        file = {
            "voice": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = await self.net.asynchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
                            

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ClientInputError(last_obj)
        
        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = await self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    async def send_music(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = await self.__read_stream(path)
        read_path = await read_path.read()
        reqed = await self.request_send_file(
            "Music"
        )

        file = {
            "music": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = await self.net.asynchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
                            

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ClientInputError(last_obj)
        
        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = await self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    async def send_document(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = await self.__read_stream(path)
        read_path = await read_path.read()
        reqed = await self.request_send_file(
            "File"
        )

        file = {
            "document": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = await self.net.asynchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
                            

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ClientInputError(last_obj)
        
        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = await self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    async def send_gif(
        self,
        chat_id: str,
        path: str,
        caption: Union[str, None] = None,
        disable_notification: bool = False,
        chat_keypad: Union[ChatKeypad, None] = None,
        chat_keypad_type: Union[chat_keypad_type_enum, None] = None,
        inline_keypad: Union[InlineKeypad, None] = None,
        reply_to_message_id: Union[str, None] = None
    ):
        read_path = await self.__read_stream(path)
        read_path = await read_path.read()
        reqed = await self.request_send_file(
            "Gif"
        )

        file = {
            "gif": read_path
        }

        param = {
            "chat_id": chat_id,
            "text": caption,
            "disable_notification": disable_notification,
            "inline_keypad": inline_keypad.get_keypads() if inline_keypad else None,
            "chat_keypad": chat_keypad.get_keypads() if chat_keypad else None,
            "chat_keypad_type": chat_keypad_type,
            "reply_to_message_id": reply_to_message_id
        }

        try:
            res = await self.net.asynchttp.post(
                reqed,
                params=param,
                files=file
            )
        except TimeoutException:
            if "internet_connection_error" in self.__whens:
                for wh in self.__whens['internet_connection_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
                            

            if "timeout_error" in self.__whens:
                for wh in self.__whens['timeout_error']:
                    if wh.func:
                        if asyncio.iscoroutinefunction(wh.func):await wh.func()
            raise InternetConnectionError("check your internet connection then try again - caused by upload")

        if res.status_code >= 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "server_response_error" in self.__whens:
                    for wh in self.__whens['server_response_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ServerResponseError(last_obj)
        
        if 400 <= res.status_code < 500:
            last_obj = None
            try:
                last_obj = res.json()
            except json.JSONDecodeError as JS:
                raise json.JSONDecodeError("invalid json to decode - caused by upload", JS.doc, JS.pos)
            except Exception:
                last_obj = res.text
                if "client_input_error" in self.__whens:
                    for wh in self.__whens['client_input_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise ClientInputError(last_obj)
        
        __ = res.json()
        if 'status' in __:
            if __['status'] != 'OK':
                if "status_error" in self.__whens:
                    for wh in self.__whens['status_error']:
                        if wh.func:
                            if asyncio.iscoroutinefunction(wh.func):await wh.func()
                raise StatusError(__)

        file_id = __['data']['file_id']
        __realout = await self.send_file(
            chat_id,
            file_id,
            caption,
            disable_notification,
            chat_keypad,
            chat_keypad_type,
            inline_keypad,
            reply_to_message_id
        )

        return __realout

    async def ban_user(
        self,
        chat_id: str,
        user_id: str
    ) -> bool:
        await self.net.makeAsyncRequest(
            "banChatMember",
            {
                "chat_id": chat_id,
                "user_id": user_id
            }
        )

        return True
    
    async def unban_user(
        self,
        chat_id: str,
        user_id: str
    ) -> bool:
        await self.net.makeAsyncRequest(
            "unbanChatMember",
            {
                "chat_id": chat_id,
                "user_id": user_id
            }
        )

        return True
