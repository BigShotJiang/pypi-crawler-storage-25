import sqlite3
import aiosqlite
import json
from typing import Union, Any, List, Dict
from ..modules import Message

class SyncDatabase(object):
    def __init__(self):
        self.__sql = sqlite3.connect(".messages_db.rforgedb", check_same_thread=False)
        self.__settingup()

    def __settingup(self):
        self.__sql.execute(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id TEXT PRIMARY KEY,
                chat_id TEXT,
                chat_type TEXT,
                text TEXT,
                time INT,
                is_edited INT,
                sender_type TEXT,
                sender_id TEXT,
                aux_data TEXT,
                file TEXT,
                reply_to_message_id TEXT,
                forwarded_from TEXT,
                forwarded_no_link TEXT,
                location TEXT,
                sticker TEXT,
                contact_message TEXT,
                poll TEXT,
                metadata TEXT,
                is_link INT,
                has_link INT
            )
            """
        )
        self.__sql.commit()

    def jsonify(self, inp: Union[str, None]):
        if inp is None:return None
        try:
            return json.loads(inp)
        except:
            return inp

    def get_messages(self) -> List[Message]:
        msgs = self.__sql.execute("SELECT * FROM messages").fetchall()
        mlist: List[Message] = []

        for msg in msgs:
            _ = Message.from_dict({
                "id": msg[0],
                "chat_id": msg[1],
                "chat_type": msg[2],
                "text": msg[3],
                "time": msg[4],
                "is_edited": msg[5],
                "sender_type": msg[6],
                "sender_id": msg[7],
                "aux_data": self.jsonify(msg[8]),
                "file": self.jsonify(msg[9]),
                "reply_to_message_id": msg[10],
                "forwarded_from": self.jsonify(msg[11]),
                "forwarded_no_link": msg[12],
                "location": self.jsonify(msg[13]),
                "sticker": self.jsonify(msg[14]),
                "contact_message": self.jsonify(msg[15]),
                "poll": self.jsonify(msg[16]),
                "metadata": self.jsonify(msg[17]),
                "is_link": msg[18],
                "has_link": msg[19]
            })

            mlist.append(_)

        return mlist
    
    def get_message_by_id(self, id: str) -> Union[Message, None]:
        msg = self.__sql.execute("SELECT * FROM messages WHERE id = ?", (id,)).fetchone()
        if msg:
            return Message.from_dict({
                "id": msg[0],
                "chat_id": msg[1],
                "chat_type": msg[2],
                "text": msg[3],
                "time": msg[4],
                "is_edited": True if msg[5] == 1 else False,
                "sender_type": msg[6],
                "sender_id": msg[7],
                "aux_data": self.jsonify(msg[8]),
                "file": self.jsonify(msg[9]),
                "reply_to_message_id": msg[10],
                "forwarded_from": self.jsonify(msg[11]),
                "forwarded_no_link": msg[12],
                "location": self.jsonify(msg[13]),
                "sticker": self.jsonify(msg[14]),
                "contact_message": self.jsonify(msg[15]),
                "poll": self.jsonify(msg[16]),
                "metadata": self.jsonify(msg[17]),
                "is_link": True if msg[18] == 1 else False,
                "has_link": True if msg[19] == 1 else False
            })
        else:
            return None
        
    def add_message(self, message: Message):
        if message.id:
            stat = self.get_message_by_id(message.id)
            if stat:return { "status": False, "message": "message exists" }

            msg_dict = message.to_dict()
            if not msg_dict['is_edited'] is None:
                msg_dict['is_edited'] = 1 if msg_dict['is_edited'] == True else 0
            
            if not msg_dict['is_link'] is None:
                msg_dict['is_link'] = 1 if msg_dict['is_link'] == True else 0

            if not msg_dict['has_link'] is None:
                msg_dict['has_link'] = 1 if msg_dict['has_link'] == True else 0

            values = list(msg_dict.values())
            for _i in range(len(values)):
                if isinstance(values[_i], dict):
                    values[_i] = json.dumps(values[_i], ensure_ascii=False)
            
            self.__sql.execute(
                """
                INSERT INTO messages (
                    id,
                    chat_id,
                    chat_type,
                    text,
                    time,
                    is_edited,
                    sender_type,
                    sender_id,
                    aux_data,
                    file,
                    reply_to_message_id,
                    forwarded_from,
                    forwarded_no_link,
                    location,
                    sticker,
                    contact_message,
                    poll,
                    metadata,
                    is_link,
                    has_link
                ) VALUES (
                    @id,
                    @chat_id,
                    @chat_type,
                    @text,
                    @time,
                    @is_edited,
                    @sender_type,
                    @sender_id,
                    @aux_data,
                    @file,
                    @reply_to_message_id,
                    @forwarded_from,
                    @forwarded_no_link,
                    @location,
                    @sticker,
                    @contact_message,
                    @poll,
                    @metadata,
                    @is_link,
                    @has_link
                )
                """,
                values
            )

            self.__sql.commit()

            return { "status": True }
        else:
            return { "status": False, "message": "message does not contain any id" }

    def update_message(
        self,
        id: str,
        message: Message
    ):
        if message.id:
            first_stat = self.get_message_by_id(id)
            second_stat = self.get_message_by_id(message.id)

            if not first_stat:
                return { "status": False, "message": "invalid id" }
            
            if second_stat:
                self.__sql.execute("DELETE FROM messages WHERE id = ?", (message.id,))
                self.__sql.commit()

            msg_dict = message.to_dict()
            if not msg_dict['is_edited'] is None:
                msg_dict['is_edited'] = 1 if msg_dict['is_edited'] == True else 0
            
            if not msg_dict['is_link'] is None:
                msg_dict['is_link'] = 1 if msg_dict['is_link'] == True else 0

            if not msg_dict['has_link'] is None:
                msg_dict['has_link'] = 1 if msg_dict['has_link'] == True else 0

            values = list(msg_dict.values())
            for _i in range(len(values)):
                if isinstance(values[_i], dict):
                    values[_i] = json.dumps(values[_i], ensure_ascii=False)

            self.__sql.execute(
                """
                INSERT INTO messages (
                    id,
                    chat_id,
                    chat_type,
                    text,
                    time,
                    is_edited,
                    sender_type,
                    sender_id,
                    aux_data,
                    file,
                    reply_to_message_id,
                    forwarded_from,
                    forwarded_no_link,
                    location,
                    sticker,
                    contact_message,
                    poll,
                    metadata,
                    is_link,
                    has_link
                ) VALUES (
                    @id,
                    @chat_id,
                    @chat_type,
                    @text,
                    @time,
                    @is_edited,
                    @sender_type,
                    @sender_id,
                    @aux_data,
                    @file,
                    @reply_to_message_id,
                    @forwarded_from,
                    @forwarded_no_link,
                    @location,
                    @sticker,
                    @contact_message,
                    @poll,
                    @metadata,
                    @is_link,
                    @has_link
                )
                """,
                values
            )

            self.__sql.commit()

            return { "status": True }
        else:
            return { "status": False, "message": "message does not contain any id" }
        
    def delete_message(self, id: str):
        stat = self.get_message_by_id(id)

        if stat:
            self.__sql.execute("DELETE FROM messages WHERE id = ?", (id,))
            self.__sql.commit()

            return { "status": True }
        else:
            return { "status": False, "message": "message does not exist" }

class AsyncDatabase(object):
    def __init__(self):
        self.db_path = ".messages_db.rforgedb"

    async def __settingup(self):
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute(
                """
                CREATE TABLE IF NOT EXISTS messages (
                    id TEXT PRIMARY KEY,
                    chat_id TEXT,
                    chat_type TEXT,
                    text TEXT,
                    time INT,
                    is_edited INT,
                    sender_type TEXT,
                    sender_id TEXT,
                    aux_data TEXT,
                    file TEXT,
                    reply_to_message_id TEXT,
                    forwarded_from TEXT,
                    forwarded_no_link TEXT,
                    location TEXT,
                    sticker TEXT,
                    contact_message TEXT,
                    poll TEXT,
                    metadata TEXT,
                    is_link INT,
                    has_link INT
                )
                """
            )
            await db.commit()

    def jsonify(self, inp: Union[str, None]) -> Any:
        if inp is None:
            return None
        try:
            return json.loads(inp)
        except (json.JSONDecodeError, TypeError):
            return inp

    async def get_messages(self) -> List[Message]:
        await self.__settingup()
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("SELECT * FROM messages")
            msgs = await cursor.fetchall()
            mlist: List[Message] = []

            for msg in msgs:
                message_data = {
                    "id": msg[0],
                    "chat_id": msg[1],
                    "chat_type": msg[2],
                    "text": msg[3],
                    "time": msg[4],
                    "is_edited": bool(msg[5]),
                    "sender_type": msg[6],
                    "sender_id": msg[7],
                    "aux_data": self.jsonify(msg[8]),
                    "file": self.jsonify(msg[9]),
                    "reply_to_message_id": msg[10],
                    "forwarded_from": self.jsonify(msg[11]),
                    "forwarded_no_link": msg[12],
                    "location": self.jsonify(msg[13]),
                    "sticker": self.jsonify(msg[14]),
                    "contact_message": self.jsonify(msg[15]),
                    "poll": self.jsonify(msg[16]),
                    "metadata": self.jsonify(msg[17]),
                    "is_link": msg[18],
                    "has_link": msg[19]
                }
                mlist.append(Message.from_dict(message_data))
            return mlist

    async def get_message_by_id(self, id: str) -> Union[Message, None]:
        await self.__settingup()
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("SELECT * FROM messages WHERE id = ?", (id,))
            msg = await cursor.fetchone()
            if msg:
                return Message.from_dict({
                    "id": msg[0],
                    "chat_id": msg[1],
                    "chat_type": msg[2],
                    "text": msg[3],
                    "time": msg[4],
                    "is_edited": True if msg[5] == 1 else False,
                    "sender_type": msg[6],
                    "sender_id": msg[7],
                    "aux_data": self.jsonify(msg[8]),
                    "file": self.jsonify(msg[9]),
                    "reply_to_message_id": msg[10],
                    "forwarded_from": self.jsonify(msg[11]),
                    "forwarded_no_link": msg[12],
                    "location": self.jsonify(msg[13]),
                    "sticker": self.jsonify(msg[14]),
                    "contact_message": self.jsonify(msg[15]),
                    "poll": self.jsonify(msg[16]),
                    "metadata": self.jsonify(msg[17]),
                    "is_link": True if msg[18] == 1 else False,
                    "has_link": True if msg[19] == 1 else False
                })
            else:
                return None

    async def add_message(self, message: Message) -> Dict[str, Union[bool, str]]:
        await self.__settingup() 
        if not message.id:
            return {"status": False, "message": "message does not contain any id"}

        async with aiosqlite.connect(self.db_path) as db:
            stat = await self.get_message_by_id(message.id)
            if stat:
                return {"status": False, "message": "message exists"}

            msg_dict = message.to_dict()
            
            msg_dict = message.to_dict()
            if not msg_dict['is_edited'] is None:
                msg_dict['is_edited'] = 1 if msg_dict['is_edited'] == True else 0
            
            if not msg_dict['is_link'] is None:
                msg_dict['is_link'] = 1 if msg_dict['is_link'] == True else 0

            if not msg_dict['has_link'] is None:
                msg_dict['has_link'] = 1 if msg_dict['has_link'] == True else 0

            values = list(msg_dict.values())
            for _i in range(len(values)):
                if isinstance(values[_i], dict):
                    values[_i] = json.dumps(values[_i], ensure_ascii=False)

            try:
                await db.execute(
                    """
                    INSERT INTO messages (
                        id,
                        chat_id,
                        chat_type,
                        text,
                        time,
                        is_edited,
                        sender_type,
                        sender_id,
                        aux_data,
                        file,
                        reply_to_message_id,
                        forwarded_from,
                        forwarded_no_link,
                        location,
                        sticker,
                        contact_message,
                        poll,
                        metadata,
                        is_link,
                        has_link
                    ) VALUES (
                        @id,
                        @chat_id,
                        @chat_type,
                        @text,
                        @time,
                        @is_edited,
                        @sender_type,
                        @sender_id,
                        @aux_data,
                        @file,
                        @reply_to_message_id,
                        @forwarded_from,
                        @forwarded_no_link,
                        @location,
                        @sticker,
                        @contact_message,
                        @poll,
                        @metadata,
                        @is_link,
                        @has_link
                    )
                    """,
                    values
                )
                await db.commit()
                return {"status": True}
            except aiosqlite.IntegrityError:
                
                return {"status": False, "message": "message with this id already exists (IntegrityError)"}
            except Exception as e:
                return {"status": False, "message": f"An error occurred: {str(e)}"}

    async def update_message(self, id: str, message: Message) -> Dict[str, Union[bool, str]]:
        await self.__settingup() 
        if not message.id:
            return {"status": False, "message": "message does not contain any id"}

        async with aiosqlite.connect(self.db_path) as db:
            first_stat = await self.get_message_by_id(id)
            if not first_stat:
                return {"status": False, "message": "invalid id"}

            current_id = message.id
            if id != current_id:
                await db.execute("DELETE FROM messages WHERE id = ?", (id,))

            msg_dict = message.to_dict()
            if not msg_dict['is_edited'] is None:
                msg_dict['is_edited'] = 1 if msg_dict['is_edited'] == True else 0
            
            if not msg_dict['is_link'] is None:
                msg_dict['is_link'] = 1 if msg_dict['is_link'] == True else 0

            if not msg_dict['has_link'] is None:
                msg_dict['has_link'] = 1 if msg_dict['has_link'] == True else 0

            values = list(msg_dict.values())
            for _i in range(len(values)):
                if isinstance(values[_i], dict):
                    values[_i] = json.dumps(values[_i], ensure_ascii=False)
    
            existing_with_new_id = await db.execute("SELECT id FROM messages WHERE id = ?", (current_id,))
            existing_with_new_id = existing_with_new_id.fetchone()
            if existing_with_new_id and id != current_id:
                return {"status": False, "message": f"message with id '{current_id}' already exists"}

            
            try:
                if id != current_id:
                    await db.execute("DELETE FROM messages WHERE id = ?", (id,))
                else:
                    await db.execute("DELETE FROM messages WHERE id = ?", (current_id,))

                await db.execute(
                    """
                    INSERT INTO messages (
                        id,
                        chat_id,
                        chat_type,
                        text,
                        time,
                        is_edited,
                        sender_type,
                        sender_id,
                        aux_data,
                        file,
                        reply_to_message_id,
                        forwarded_from,
                        forwarded_no_link,
                        location,
                        sticker,
                        contact_message,
                        poll,
                        metadata,
                        is_link,
                        has_link
                    ) VALUES (
                        @id,
                        @chat_id,
                        @chat_type,
                        @text,
                        @time,
                        @is_edited,
                        @sender_type,
                        @sender_id,
                        @aux_data,
                        @file,
                        @reply_to_message_id,
                        @forwarded_from,
                        @forwarded_no_link,
                        @location,
                        @sticker,
                        @contact_message,
                        @poll,
                        @metadata,
                        @is_link,
                        @has_link
                    )
                    """,
                    values
                )
                await db.commit()
                return {"status": True}
            except aiosqlite.IntegrityError:
                 return {"status": False, "message": "message with this id already exists (IntegrityError)"}
            except Exception as e:
                return {"status": False, "message": f"An error occurred: {str(e)}"}


    async def delete_message(self, id: str) -> Dict[str, Union[bool, str]]:
        await self.__settingup() 
        async with aiosqlite.connect(self.db_path) as db:
            stat = await self.get_message_by_id(id) 

            if stat:
                await db.execute("DELETE FROM messages WHERE id = ?", (id,))
                await db.commit()
                return {"status": True}
            else:
                return {"status": False, "message": "message does not exist"}
            