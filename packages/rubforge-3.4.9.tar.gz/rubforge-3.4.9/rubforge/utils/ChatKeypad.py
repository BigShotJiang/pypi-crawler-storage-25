﻿from ..exceptions import ErrorKeypadType
from ..modules.enums import button_type_enum
from ..modules import (
    ButtonSelection,
    ButtonCalendar,
    ButtonNumberPicker,
    ButtonStringPicker,
    ButtonLocation,
    ButtonTextbox
)

class ChatBundle(object):
    def __init__(
        self,
        id: str,
        button_text: str,
        type: button_type_enum = "Simple"
    ):
        self.id = id
        self.button_text = button_text
        self.type = type

class ChatKeypad(object):
    def __init__(self, resize_keyboard: bool = True, one_time_keyboard: bool = True):
        self.__keys = {
            "resize_keboard": resize_keyboard,
            "one_time_keyboard": one_time_keyboard,
            "rows": [{
                "buttons": []
            }]
        }

    def __next_line(self):
        self.__keys['rows'].append({
            'buttons': []
        })

    def add_keypad(
        self,
        *args,
        **kwargs
    ):

        for arg in args:
            if not isinstance(arg, ChatBundle):continue

            obj_to_append = {
                "id": arg.id,
                "button_text": arg.button_text,
                "type": arg.type
            }

            if kwargs.get("button_selection") and not isinstance(kwargs.get("button_selection"), ButtonSelection):
                raise ErrorKeypadType("invalid keypad classify")
            elif kwargs.get("button_selection") and isinstance(kwargs.get("button_selection"), ButtonSelection):
                obj_to_append['button_selection'] = kwargs.get("button_selection").to_dict() # pyright: ignore[reportOptionalMemberAccess]
            
            if kwargs.get("button_calendar") and not isinstance(kwargs.get("button_calendar"), ButtonCalendar):
                raise ErrorKeypadType("invalid keypad classify")
            elif kwargs.get("button_calendar") and isinstance(kwargs.get("button_calendar"), ButtonCalendar):
                obj_to_append['button_calendar'] = kwargs.get("button_calendar").to_dict() # pyright: ignore[reportOptionalMemberAccess]
            
            if kwargs.get("button_number_picker") and not isinstance(kwargs.get("button_number_picker"), ButtonNumberPicker):
                raise ErrorKeypadType("invalid keypad classify")
            elif kwargs.get("button_number_picker") and isinstance(kwargs.get("button_number_picker"), ButtonNumberPicker):
                obj_to_append['button_number_picker'] = kwargs.get("button_number_picker").to_dict() # pyright: ignore[reportOptionalMemberAccess]
            
            if kwargs.get("button_string_picker") and not isinstance(kwargs.get("button_string_picker"), ButtonStringPicker):
                raise ErrorKeypadType("invalid keypad classify")
            elif kwargs.get("button_string_picker") and isinstance(kwargs.get("button_string_picker"), ButtonStringPicker):
                obj_to_append['button_string_picker'] = kwargs.get("button_string_picker").to_dict() # pyright: ignore[reportOptionalMemberAccess]
            
            if kwargs.get("button_location") and not isinstance(kwargs.get("button_location"), ButtonLocation):
                raise ErrorKeypadType("invalid keypad classify")
            elif kwargs.get("button_location") and isinstance(kwargs.get("button_location"), ButtonLocation):
                obj_to_append['button_location'] = kwargs.get("button_location").to_dict() # pyright: ignore[reportOptionalMemberAccess]
            
            if kwargs.get("button_textbox") and not isinstance(kwargs.get("button_textbox"), ButtonTextbox):
                raise ErrorKeypadType("invalid keypad classify")
            elif kwargs.get("button_textbox") and isinstance(kwargs.get("button_textbox"), ButtonTextbox):
                obj_to_append['button_textbox'] = kwargs.get("button_textbox").to_dict() # pyright: ignore[reportOptionalMemberAccess]
            
            self.__keys['rows'][-1]['buttons'].append(obj_to_append)

        self.__next_line()

    def get_keypads(self):
        for k in self.__keys['rows']:
            if len(k['buttons']) == 0:self.__keys['rows'].remove(k)
        return self.__keys

