from ..modules import MetadataPart

def create_markdown(text: str):
    """
    **bold**

    _italic_

    `mono`

    __underline__

    ~~strike~~

    ||spoiler||

    [Google](https://google.com)

    [@Mamad Ali Klay](123456789)

    ```code block```
    """
    clean_text = ""
    positions = []

    i = 0
    length = len(text)
    
    while i < length:
        matched = False
        
        
        if text[i:i+2] == '**' and i+2 < length:
            end = text.find('**', i+2)
            if end != -1:
                inner_text = text[i+2:end]
                positions.append({
                    "type": "Bold",
                    "from_index": len(clean_text),
                    "length": len(inner_text),
                    "link_url": None,
                    "mention_text_user_id": None
                })
                clean_text += inner_text
                i = end + 2
                matched = True
        
        
        elif text[i:i+2] == '__' and i+2 < length:
            end = text.find('__', i+2)
            if end != -1:
                inner_text = text[i+2:end]
                positions.append({
                    "type": "Underline",
                    "from_index": len(clean_text),
                    "length": len(inner_text),
                    "link_url": None,
                    "mention_text_user_id": None
                })
                clean_text += inner_text
                i = end + 2
                matched = True
        
        
        elif text[i] == '*' and (i+1 < length and text[i+1] != '*'):
            end = text.find('*', i+1)
            if end != -1 and (end+1 >= length or text[end+1] != '*'):
                inner_text = text[i+1:end]
                positions.append({
                    "type": "Italic",
                    "from_index": len(clean_text),
                    "length": len(inner_text),
                    "link_url": None,
                    "mention_text_user_id": None
                })
                clean_text += inner_text
                i = end + 1
                matched = True
        
        
        elif text[i] == '_' and (i+1 < length and text[i+1] != '_'):
            end = text.find('_', i+1)
            if end != -1 and (end+1 >= length or text[end+1] != '_'):
                inner_text = text[i+1:end]
                positions.append({
                    "type": "Italic",
                    "from_index": len(clean_text),
                    "length": len(inner_text),
                    "link_url": None,
                    "mention_text_user_id": None
                })
                clean_text += inner_text
                i = end + 1
                matched = True
        
        
        elif text[i] == '`':
            end = text.find('`', i+1)
            if end != -1:
                inner_text = text[i+1:end]
                positions.append({
                    "type": "Mono",
                    "from_index": len(clean_text),
                    "length": len(inner_text),
                    "link_url": None,
                    "mention_text_user_id": None
                })
                clean_text += inner_text
                i = end + 1
                matched = True
        
        
        elif text[i:i+2] == '~~' and i+2 < length:
            end = text.find('~~', i+2)
            if end != -1:
                inner_text = text[i+2:end]
                positions.append({
                    "type": "Strike",
                    "from_index": len(clean_text),
                    "length": len(inner_text),
                    "link_url": None,
                    "mention_text_user_id": None
                })
                clean_text += inner_text
                i = end + 2
                matched = True
        
        
        elif text[i:i+2] == '||' and i+2 < length:
            end = text.find('||', i+2)
            if end != -1:
                inner_text = text[i+2:end]
                positions.append({
                    "type": "Spoiler",
                    "from_index": len(clean_text),
                    "length": len(inner_text),
                    "link_url": None,
                    "mention_text_user_id": None
                })
                clean_text += inner_text
                i = end + 2
                matched = True
        
        
        elif text[i] == '[':
            close_bracket = text.find(']', i)
            if close_bracket != -1 and close_bracket + 1 < length and text[close_bracket+1] == '(':
                open_paren = close_bracket + 1
                close_paren = text.find(')', open_paren)
                if close_paren != -1:
                    inner_text = text[i+1:close_bracket]
                    url = text[open_paren+1:close_paren]
                    positions.append({
                        "type": "Link",
                        "from_index": len(clean_text),
                        "length": len(inner_text),
                        "link_url": url,
                        "mention_text_user_id": None
                    })
                    clean_text += inner_text
                    i = close_paren + 1
                    matched = True
        
        
        elif text[i:i+2] == '@[':
            close_bracket = text.find(']', i)
            if close_bracket != -1 and close_bracket + 1 < length and text[close_bracket+1] == '(':
                open_paren = close_bracket + 1
                close_paren = text.find(')', open_paren)
                if close_paren != -1:
                    inner_text = text[i+2:close_bracket]
                    user_id = text[open_paren+1:close_paren]
                    positions.append({
                        "type": "MentionText",
                        "from_index": len(clean_text),
                        "length": len(inner_text),
                        "link_url": None,
                        "mention_text_user_id": user_id
                    })
                    clean_text += inner_text
                    i = close_paren + 1
                    matched = True
        
        
        elif text[i:i+2] == '[@':
            close_bracket = text.find(']', i)
            if close_bracket != -1 and close_bracket + 1 < length and text[close_bracket+1] == '(':
                open_paren = close_bracket + 1
                close_paren = text.find(')', open_paren)
                if close_paren != -1:
                    inner_text = text[i+2:close_bracket]
                    user_id = text[open_paren+1:close_paren]
                    positions.append({
                        "type": "MentionText",
                        "from_index": len(clean_text),
                        "length": len(inner_text),
                        "link_url": None,
                        "mention_text_user_id": user_id
                    })
                    clean_text += inner_text
                    i = close_paren + 1
                    matched = True
        
        
        elif text[i] == '@' and i+1 < length and text[i+1].isalnum():
            end = i + 1
            while end < length and (text[end].isalnum() or text[end] == '_'):
                end += 1
            inner_text = text[i+1:end]
            positions.append({
                "type": "MentionText",
                "from_index": len(clean_text),
                "length": len(inner_text),
                "link_url": None,
                "mention_text_user_id": None
            })
            clean_text += inner_text
            i = end
            matched = True
        
        
        elif text[i:i+3] == '```':
            end = text.find('```', i+3)
            if end != -1:
                inner_text = text[i+3:end]
                positions.append({
                    "type": "Pre",
                    "from_index": len(clean_text),
                    "length": len(inner_text),
                    "link_url": None,
                    "mention_text_user_id": None
                })
                clean_text += inner_text
                i = end + 3
                matched = True
        
        
        if not matched:
            clean_text += text[i]
            i += 1
    
    
    _pos = []
    for p in positions:
        _pos.append(MetadataPart.from_dict(p))
    
    return {
        "clean_text": clean_text,
        "metadata": _pos
    }

