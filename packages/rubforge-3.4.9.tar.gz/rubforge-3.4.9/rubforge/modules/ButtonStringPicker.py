﻿from dataclasses import dataclass, field
from typing import Optional, List, Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ButtonStringPicker(object):
    items: Union[List[str], None] = field(default_factory=list)
    default_value: Optional[str] = None
    title: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ButtonStringPicker":
        return cls(
            items=data.get("items", []),
            default_value=data.get("default_value"),
            title=data.get("title")
        )
    
    def to_dict(self) -> dict:
        return {
            "items": self.items,
            "default_value": self.default_value,
            "title": self.title
        }


