﻿from .enums import poll_status_enum
from dataclasses import dataclass, field
from typing import Union, List
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class PollStatus(object):
    state: Union[poll_status_enum, None] = None
    selection_index: Union[int, None] = None
    percent_vote_options: Union[List[int], None] = field(default_factory=list)
    total_vote: Union[int, None] = None
    show_total_votes: Union[bool, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "PollStatus":
        return cls(
            state=data.get("state"),
            selection_index=data.get("selection_index"),
            percent_vote_options=data.get("percent_vote_options", []),
            total_vote=data.get("total_vote"),
            show_total_votes=data.get("show_total_votes")
        )
    
    def to_dict(self) -> dict:
        return {
            "state":self.state,
            "selection_index":self.selection_index,
            "percent_vote_options":self.percent_vote_options if self.percent_vote_options else [],
            "total_vote":self.total_vote,
            "show_total_votes":self.show_total_votes
        }


