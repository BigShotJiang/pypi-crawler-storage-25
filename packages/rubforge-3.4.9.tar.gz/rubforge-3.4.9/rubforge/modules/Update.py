﻿from .enums import update_type_enum
from .Message import Message
from dataclasses import dataclass
from typing import Optional, Union, Literal
from .__rule import dataclass_items

def guess_chat(chat_id: Union[str, None]):
    if chat_id:
        if chat_id.startswith("b0"):
            return "private"
        elif chat_id.startswith("c0"):
            return "channel"
        elif chat_id.startswith("g0"):
            return "group"
        else:
            return "unknown"
    else:
        return "unknown"

@dataclass(**dataclass_items)
class Update(object):
    type: Union[update_type_enum, None] = None
    chat_id: Union[str, None] = None
    chat_type: Union[Literal['private', 'channel', 'group', 'unknown'], None] = None
    removed_message_id: Optional[Union[str, None]] = None
    new_message: Union[Message, None] = None
    updated_message: Optional[Union[Message, None]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Update":
        n_msg = Message.from_dict(data["new_message"] if data.get("new_message") else {}) if data.get("new_message") else None
        u_msg = Message.from_dict(data["updated_message"] if data.get("updated_message") else {}) if data.get("updated_message") else None
        if isinstance(n_msg, Message):
            n_msg.chat_id = data.get("chat_id")
            n_msg.chat_type = guess_chat(data.get("chat_id"))

        if isinstance(u_msg, Message):
            u_msg.chat_id = data.get("chat_id")
            u_msg.chat_type = guess_chat(data.get("chat_id"))
        return cls(
            type=data.get("type"),
            chat_id=data.get("chat_id"),
            chat_type=guess_chat(data.get("chat_id")),
            removed_message_id=data.get("removed_message_id"),
            new_message=n_msg,
            updated_message=u_msg
        )

    def to_dict(self) -> dict:
        n_msg = self.new_message.to_dict() if self.new_message else None
        u_msg = self.updated_message.to_dict() if self.updated_message else None
        if isinstance(n_msg, dict):
            n_msg['chat_id'] = self.chat_id
            n_msg['chat_type'] = self.guess_chat()

        if isinstance(u_msg, dict):
            u_msg['chat_id'] = self.chat_id
            u_msg['chat_type'] = self.guess_chat()
        return {
            "type": self.type,
            "chat_id": self.chat_id,
            "chat_type": self.chat_type,
            "removed_message_id": self.removed_message_id,
            "new_message": n_msg,
            "updated_message": u_msg
        }

    def guess_chat(self):
        if self.chat_id:
            if self.chat_id.startswith("b0"):
                return "private"
            elif self.chat_id.startswith("c0"):
                return "channel"
            elif self.chat_id.startswith("g0"):
                return "group"
            else:
                return "unknown"
        else:
            return "unknown"
