﻿from dataclasses import dataclass
from typing import Optional, Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ButtonNumberPicker(object):
    min_value: Union[str, None] = None
    max_value: Union[str, None] = None
    default_value: Optional[Union[str, None]] = None
    title: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ButtonNumberPicker":
        return cls(
            min_value=data.get("min_value"),
            max_value=data.get("max_value"),
            default_value=data.get("default_value"),
            title=data.get("title")
        )
    
    def to_dict(self) -> dict:
        return {
            "min_value": self.min_value,
            "max_value": self.max_value,
            "default_value": self.default_value,
            "title": self.title
        }


