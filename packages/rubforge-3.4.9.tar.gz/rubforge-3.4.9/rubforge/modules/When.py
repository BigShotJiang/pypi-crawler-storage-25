﻿from dataclasses import dataclass
from typing import Union, Literal, Callable
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class When(object):
    type: Union[Literal[
        'started_polling', 'stopped_polling',
        'started_schedule', 'stopped_schedule',
        'internet_connection_error', 'timeout_error', # internet_connection_error and timeout_error are the same
        'server_response_error', 'client_input_error',
        'status_error', 'json_decode_error',
        'session_or_token_not_found', 'polling_exception'
    ], None] = None

    func: Union[Callable, None] = None
    status: Union[Literal['enable', 'disable'], None] = None
    
    @classmethod
    def from_dict(cls, data: dict) -> "When":
        return cls(
            type=data.get("type"),
            func=data.get("func"),
            status=data.get("status")
        )

    def to_dict(self) -> dict:
        return {
            "type": self.type,
            "func": self.func,
            "status": self.status
        }

    def disable(self) -> bool:
        if self.status == "enable":self.status = "disable"
        return True

    def enable(self) -> bool:
        if self.status == "disable":self.status = "enable"
        return True
