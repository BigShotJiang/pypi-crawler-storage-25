﻿from .enums import button_selection_search_enum, button_selection_get_enum
from .ButtonSelectionItem import ButtonSelectionItem
from dataclasses import dataclass, field
from typing import Union, List
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ButtonSelection(object):
    selection_id: Union[str, None] = None
    search_type: Union[button_selection_search_enum, None] = None
    get_type: Union[button_selection_get_enum, None] = None
    items: Union[List[ButtonSelectionItem], None] = field(default_factory=list)
    is_multi_selection: Union[bool, None] = None
    columns_count: Union[str, None] = None
    title: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ButtonSelection":
        return cls(
            selection_id=data.get("selection_id"),
            search_type=data.get("search_type"),
            get_type=data.get("get_type"),
            items=[ButtonSelectionItem.from_dict(bx) for bx in data.get("items", [])],
            is_multi_selection=data.get("is_multi_selection"),
            columns_count=data.get("columns_count"),
            title=data.get("title")
        )
    
    def to_dict(self) -> dict:
        return {
            "selection_id": self.selection_id,
            "search_type": self.search_type,
            "get_type": self.get_type,
            "items": [bx.to_dict() for bx in (self.items if self.items else [])],
            "is_multi_selection": self.is_multi_selection,
            "columns_count": self.columns_count,
            "title": self.title
        }


