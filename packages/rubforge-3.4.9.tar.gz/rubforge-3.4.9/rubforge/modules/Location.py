﻿from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class Location(object):
    longitude: Union[str, None] = None
    latitude: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Location":
        return cls(
            longitude=data.get("longitude"),
            latitude=data.get("latitude")
        )
    
    def to_dict(self) -> dict:
        return {
            "longitude": self.longitude,
            "latitude": self.latitude
        }


