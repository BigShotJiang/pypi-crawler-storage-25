﻿from .enums import meta_data_part_enum
from dataclasses import dataclass
from typing import Union, Optional
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class MetadataPart(object):
    type: Union[meta_data_part_enum, None] = None
    from_index: Union[int, None] = None
    length: Union[int, None] = None
    link_url: Optional[Union[str, None]] = None
    mention_text_user_id: Optional[Union[str, None]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "MetadataPart":
        return cls(
            type=data.get("type"),
            from_index=data.get("from_index"),
            length=data.get("length"),
            link_url=data.get("link_url"),
            mention_text_user_id=data.get("mention_text_user_id")
        )
    
    def to_dict(self) -> dict:
        return {
            "type": self.type,
            "from_index": self.from_index,
            "length": self.length,
            "link_url": self.link_url,
            "mention_text_user_id": self.mention_text_user_id,
        }


