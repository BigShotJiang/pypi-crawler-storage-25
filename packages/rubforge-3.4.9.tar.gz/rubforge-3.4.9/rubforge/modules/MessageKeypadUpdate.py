﻿from .Keypad import Keypad
from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class MessageKeypadUpdate(object):
    message_id: Union[str, None] = None
    inline_keypad: Union[Keypad, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "MessageKeypadUpdate":
        return cls(
            message_id=data.get("message_id"),
            inline_keypad=Keypad.from_dict(data.get("inline_keypad", {}))
        )
    
    def to_dict(self) -> dict:
        return {
            "message_id": self.message_id,
            "inline_keypad": self.inline_keypad.to_dict() if self.inline_keypad else None
        }


