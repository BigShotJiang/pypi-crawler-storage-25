﻿from .enums import forwarded_from_enum
from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ForwardedFrom(object):
    type_from: Union[forwarded_from_enum, None] = None
    message_id: Union[str, None] = None    
    from_chat_id: Union[str, None] = None
    from_sender_id: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ForwardedFrom":
        return cls(
            type_from=data.get("type_from"),
            message_id=data.get("message_id"),
            from_chat_id=data.get("from_chat_id"),
            from_sender_id=data.get("from_sender_id")
        )
    
    def to_dict(self) -> dict:
        return {
            "type_from": self.type_from,
            "message_id": self.message_id,
            "from_chat_id": self.from_chat_id,
            "from_sender_id": self.from_sender_id
        }


