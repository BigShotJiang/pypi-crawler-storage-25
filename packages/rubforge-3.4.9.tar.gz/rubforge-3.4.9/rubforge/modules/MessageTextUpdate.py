﻿from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class MessageTextUpdate(object):
    message_id: Union[str, None] = None
    text: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "MessageTextUpdate":
        return cls(
            message_id=data.get("message_id"),
            text=data.get("text")
        )
    
    def to_dict(self) -> dict:
        return {
            "message_id": self.message_id,
            "text": self.text
        }


