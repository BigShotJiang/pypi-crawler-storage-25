﻿from .enums import button_selection_type_enum
from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ButtonSelectionItem(object):
    text: Union[str, None] = None
    image_url: Union[str, None] = None
    type: Union[button_selection_type_enum, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ButtonSelectionItem":
        return cls(
            text=data.get("text"),
            image_url=data.get("image_url"),
            type=data.get("type")
        )
    
    def to_dict(self) -> dict:
        return {
            "text": self.text,
            "image_url": self.image_url,
            "type": self.type
        }


