﻿from .File import File
from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class Sticker(object):
    sticker_id: Union[str, None] = None
    file: Union[File, None] = None
    emoji_character: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Sticker":
        return cls(
            sticker_id=data.get("sticker_id"),
            file=File.from_dict(data.get("file", {})),
            emoji_character=data.get("emoji_character")
        )
    
    def to_dict(self) -> dict:
        return {
            "sticker_id": self.sticker_id,
            "file": self.file.to_dict() if self.file else None,
            "emoji_character": self.emoji_character
        }


