from typing import Literal

button_text_box_type_line_enum = Literal['SingleLine', 'MultiLine']
