from typing import Literal

button_selection_type_enum = Literal['TextOnly', 'TextImgThu', 'TextImgBig']
