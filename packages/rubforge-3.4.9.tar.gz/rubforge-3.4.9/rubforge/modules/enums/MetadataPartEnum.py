from typing import Literal

meta_data_part_enum = Literal['Bold', 'Italic', 'Mono', 'Underline', 'Strike', 'Spoiler', 'Link', 'MentionText', 'Pre', 'Quote']
