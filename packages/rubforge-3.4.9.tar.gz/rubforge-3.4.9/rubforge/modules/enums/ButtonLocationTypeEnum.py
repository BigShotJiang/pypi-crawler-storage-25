from typing import Literal

button_location_type_enum = Literal['Picker', 'View']
