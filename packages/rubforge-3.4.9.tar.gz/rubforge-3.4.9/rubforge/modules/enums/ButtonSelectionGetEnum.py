from typing import Literal

button_selection_get_enum = Literal['Local', 'Api']
