from typing import Literal

message_sender_enum = Literal['User', 'Bot']
