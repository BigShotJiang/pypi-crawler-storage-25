from typing import Literal

chat_keypad_type_enum = Literal['None', 'New', 'Remove']
