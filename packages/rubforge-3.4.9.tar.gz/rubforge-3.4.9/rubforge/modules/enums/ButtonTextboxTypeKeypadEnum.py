from typing import Literal

button_text_box_type_keypad_enum = Literal['String', 'Number']
