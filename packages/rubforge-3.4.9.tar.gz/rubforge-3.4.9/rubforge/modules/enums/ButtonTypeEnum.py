from typing import Literal

button_type_enum = Literal[
    'Simple', 'Selection',
    'Calendar', 'NumberPicker',
    'StringPicker', 'Location',
    'CameraImage', 'CameraVideo',
    'GalleryImage', 'GalleryVideo',
    'File', 'Audio',
    'RecordAudio', 'Textbox',
    'Link', 'AskMyPhoneNumber',
    'AskMyLocation', 'Barcode'
]
