from typing import Literal

button_calendar_type_enum = Literal['DatePersian', 'DateGregorian']
