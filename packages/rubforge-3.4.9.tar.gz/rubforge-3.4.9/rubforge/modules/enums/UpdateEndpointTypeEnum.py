from typing import Literal

update_endpoint_type_enum = Literal[
    'ReceiveUpdate',
    'ReceiveInlineMessage',
    'ReceiveQuery',
    'GetSelectionItem',
    'SearchSelectionItems'
]
