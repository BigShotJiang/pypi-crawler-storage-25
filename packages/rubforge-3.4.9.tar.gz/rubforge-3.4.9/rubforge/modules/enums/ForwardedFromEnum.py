from typing import Literal

forwarded_from_enum = Literal['User', 'Channel', 'Bot']
