from typing import Literal

button_selection_search_enum = Literal['None', 'Local', 'Api']
