from typing import Literal

chat_type_enum = Literal['User', 'Bot', 'Group', 'Channel']
