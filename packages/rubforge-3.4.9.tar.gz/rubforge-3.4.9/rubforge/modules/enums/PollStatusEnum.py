from typing import Literal

poll_status_enum = Literal['Open', 'Closed']