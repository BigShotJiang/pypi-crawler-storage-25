from typing import Literal

file_type_enum = Literal['File', 'Image', 'Voice', 'Video', 'Music', 'Gif']
