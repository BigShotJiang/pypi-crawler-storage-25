﻿from .enums import chat_type_enum
from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class Chat(object):
    chat_id: Union[str, None] = None
    chat_type: Union[chat_type_enum, None] = None
    user_id: Union[str, None] = None
    first_name: Union[str, None] = None
    last_name: Union[str, None] = None
    title: Union[str, None] = None
    username: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Chat":
        return cls(
            chat_id=data.get("chat_id"),
            chat_type=data.get("chat_type"),
            user_id=data.get("user_id"),
            first_name=data.get("first_name"),
            last_name=data.get("last_name"),
            title=data.get("title"),
            username=data.get("username")
        )
    
    def to_dict(self) -> dict:
        return {
            "chat_id": self.chat_id,
            "chat_type": self.chat_type,
            "user_id": self.user_id,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "title": self.title,
            "username": self.username
        }


