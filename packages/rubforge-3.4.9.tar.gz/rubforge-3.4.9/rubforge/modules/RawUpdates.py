﻿from .Update import Update
from dataclasses import dataclass, field
from typing import Optional, List, Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class RawUpdates(object):
    updates: Union[List[Update], None] = field(default_factory=list)
    next_offset_id: Optional[Union[str, None]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "RawUpdates":
        return cls(
            updates=[Update.from_dict(x) for x in data.get("updates", [])],
            next_offset_id=data.get("next_offset_id")
        )
    
    def to_dict(self) -> dict:
        t = self.updates if isinstance(self.updates, list) else []
        return {
            "updates": [x.to_dict() for x in t],
            "next_offset_id": self.next_offset_id
        }


