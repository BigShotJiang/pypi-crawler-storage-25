import sys

dataclass_items = {}

if sys.version_info >= (3, 10):
    dataclass_items['slots'] = True
