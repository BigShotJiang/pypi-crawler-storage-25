﻿from .enums import button_location_type_enum
from .Location import Location
from dataclasses import dataclass
from typing import Optional, Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ButtonLocation(object):
    default_pointer_location: Union[Location, None] = None
    default_map_location: Union[Location, None] = None
    type: Union[button_location_type_enum, None] = None
    title: Optional[Union[str, None]] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ButtonLocation":
        return cls(
            default_pointer_location=Location.from_dict(data.get("default_pointer_location", {})),
            default_map_location=Location.from_dict(data.get("default_map_location", {})),
            type=data.get("type"),
            title=data.get("title")
        )
    
    def to_dict(self) -> dict:
        return {
            "default_pointer_location": self.default_pointer_location.to_dict() if self.default_pointer_location else None,
            "default_map_location": self.default_map_location.to_dict() if self.default_map_location else None,
            "type": self.type,
            "title": self.title
        }


