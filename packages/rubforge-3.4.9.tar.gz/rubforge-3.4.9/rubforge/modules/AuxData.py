﻿from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class AuxData(object):
    start_id: Union[str, None] = None
    button_id: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "AuxData":
        return cls(
            start_id=data.get("start_id"),
            button_id=data.get("button_id")
        )
    
    def to_dict(self) -> dict:
        return {
            "start_id": self.start_id,
            "button_id": self.button_id
        }


