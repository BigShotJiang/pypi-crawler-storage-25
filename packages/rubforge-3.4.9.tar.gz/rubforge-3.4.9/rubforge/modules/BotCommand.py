﻿from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class BotCommand(object):
    command: Union[str, None] = None
    description: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "BotCommand":
        return cls(
            command=data.get("command"),
            description=data.get("description")
        )
    
    def to_dict(self) -> dict:
        return {
            "command": self.command,
            "description": self.description
        }


