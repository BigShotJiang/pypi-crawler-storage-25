﻿from .File import File
from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class Bot(object):
    bot_id: Union[str, None] = None
    bot_title: Union[str, None] = None
    avatar: Union[File, None] = None
    description: Union[str, None] = None
    username: Union[str, None] = None
    start_message: Union[str, None] = None
    share_url: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Bot":
        return cls(
            bot_id=data.get("bot_id"),
            bot_title=data.get("bot_title"),
            avatar=File.from_dict(data.get("avatar", {})),
            description=data.get("description"),
            username=data.get("username"),
            start_message=data.get("start_message"),
            share_url=data.get("share_url")
        )
    
    def to_dict(self) -> dict:
        return {
            "bot_id": self.bot_id,
            "bot_title": self.bot_title,
            "avatar": self.avatar.to_dict() if self.avatar else None,
            "description": self.description,
            "username": self.username,
            "start_message": self.start_message,
            "share_url": self.share_url
        }


