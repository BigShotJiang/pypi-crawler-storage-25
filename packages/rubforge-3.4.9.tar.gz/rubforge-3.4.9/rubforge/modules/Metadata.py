﻿from .MetadataPart import MetadataPart
from dataclasses import dataclass, field
from typing import Optional, List, Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class Metadata(object):
    meta_data_parts: Union[List[MetadataPart], None] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "Metadata":
        return cls(
            meta_data_parts=[MetadataPart.from_dict(x) for x in data.get("meta_data_parts", [])]
        )
    
    def to_dict(self) -> dict:
        return {
            "updates": [x.to_dict() for x in (self.meta_data_parts if self.meta_data_parts else [])],
        }


