﻿from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class File(object):
    file_id: Union[str, None] = None
    file_name: Union[str, None] = None
    file_size: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "File":
        return cls(
            file_id=data.get("file_id"),
            file_name=data.get("file_name"),
            file_size=data.get("size")
        )
    
    def to_dict(self) -> dict:
        return {
            "file_id": self.file_id,
            "file_name": self.file_name,
            "file_size": self.file_size
        }


