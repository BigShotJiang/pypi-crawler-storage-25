﻿from .enums import button_calendar_type_enum
from dataclasses import dataclass
from typing import Optional, Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ButtonCalendar(object):
    default_value: Optional[Union[str, None]] = None
    type: Union[button_calendar_type_enum, None] = None
    min_year: Union[str, None] = None
    max_year: Union[str, None] = None
    title: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ButtonCalendar":
        return cls(
            default_value=data.get("default_value"),
            type=data.get("type"),
            min_year=data.get("min_year"),
            max_year=data.get("max_year"),
            title=data.get("title")
        )
    
    def to_dict(self) -> dict:
        return {
            "default_value": self.default_value,
            "type": self.type,
            "min_year": self.min_year,
            "max_year": self.max_year,
            "title": self.title
        }


