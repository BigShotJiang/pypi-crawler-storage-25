﻿from .enums import button_text_box_type_keypad_enum, button_text_box_type_line_enum
from dataclasses import dataclass
from typing import Optional, Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ButtonTextbox(object):
    type_line: Union[button_text_box_type_line_enum, None] = None
    type_keypad: Union[button_text_box_type_keypad_enum, None] = None
    place_holder: Optional[str] = None
    title: Optional[str] = None
    default_value: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ButtonTextbox":
        return cls(
            type_line=data.get("type_line"),
            type_keypad=data.get("type_keypad"),
            place_holder=data.get("place_holder"),
            default_value=data.get("default_value"),
            title=data.get("title")
        )
    
    def to_dict(self) -> dict:
        return {
            "type_line": self.type_line,
            "type_keypad": self.type_keypad,
            "place_holder": self.place_holder,
            "default_value": self.default_value,
            "title": self.title
        }


