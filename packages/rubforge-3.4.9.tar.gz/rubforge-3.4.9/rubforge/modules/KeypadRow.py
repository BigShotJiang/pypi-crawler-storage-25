﻿from .Button import Button
from dataclasses import dataclass, field
from typing import Union, List
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class KeypadRow(object):
    buttons: Union[List[Button], None] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "KeypadRow":
        return cls(
            buttons=[Button.from_dict(x) for x in data.get("buttons", [])]
        )
    
    def to_dict(self) -> dict:
        return {
            "buttons": [x.to_dict() for x in (self.buttons if self.buttons else [])]
        }


