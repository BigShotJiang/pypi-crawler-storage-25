﻿from .PollStatus import PollStatus
from dataclasses import dataclass, field
from typing import Union, List
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class Poll(object):
    question: Union[str, None] = None
    options: Union[List[str], None] = field(default_factory=list)
    poll_status: Union[PollStatus, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Poll":
        return cls(
            question=data.get("question"),
            options=data.get("options", []),
            poll_status=PollStatus.from_dict(data.get("poll_status", {}))
        )
    
    def to_dict(self) -> dict:
        return {
            "question": self.question,
            "options": self.options if self.options else [],
            "poll_status": self.poll_status.to_dict() if self.poll_status else None
        }


