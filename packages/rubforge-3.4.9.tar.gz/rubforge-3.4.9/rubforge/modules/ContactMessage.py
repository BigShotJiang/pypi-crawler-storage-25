﻿from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class ContactMessage(object):
    phone_number: Union[str, None] = None
    first_name: Union[str, None] = None
    last_name: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "ContactMessage":
        return cls(
            phone_number=data.get("phone_number"),
            first_name=data.get("first_name"),
            last_name=data.get("last_name")
        )
    
    def to_dict(self) -> dict:
        return {
            "phone_number": self.phone_number,
            "first_name": self.first_name,
            "last_name": self.last_name
        }


