﻿from .AuxData import AuxData
from .Location import Location
from .File import File
from dataclasses import dataclass, field
from typing import Optional, Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class InlineMessage(object):
    sender_id: Union[str, None] = None
    text: Union[str, None] = None
    file: Optional[File] = None
    location: Optional[Location] = None
    aux_data: Optional[AuxData] = None
    message_id: Union[str, None] = None
    chat_id: Union[str, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "InlineMessage":
        return cls(
            sender_id=data.get("sender_id"),
            text=data.get("text"),
            file=File.from_dict(data.get("file", {})),
            location=Location.from_dict(data.get("location", {})),
            aux_data=AuxData.from_dict(data.get("aux_data", {})),
            message_id=data.get("message_id"),
            chat_id=data.get("chat_id")
        )
    
    def to_dict(self) -> dict:
        return {
            "sender_id": self.sender_id,
            "text": self.text,
            "file": self.file.to_dict() if self.file else None,
            "location": self.location.to_dict() if self.location else None,
            "aux_data": self.aux_data.to_dict() if self.aux_data else None,
            "message_id": self.message_id,
            "chat_id": self.chat_id
        }


