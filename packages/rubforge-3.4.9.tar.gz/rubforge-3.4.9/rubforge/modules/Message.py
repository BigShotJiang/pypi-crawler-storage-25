﻿from .enums import message_sender_enum
from .AuxData import AuxData
from .File import File
from .ForwardedFrom import ForwardedFrom
from .Location import Location
from .Sticker import Sticker
from .ContactMessage import ContactMessage
from .Poll import Poll
from .Metadata import Metadata, MetadataPart
from dataclasses import dataclass
from typing import Union, Literal
from .__rule import dataclass_items
import re

def guess_chat(chat_id: Union[str, None]):
    if chat_id:
        if chat_id.startswith("b0"):
            return "private"
        elif chat_id.startswith("c0"):
            return "channel"
        elif chat_id.startswith("g0"):
            return "group"
        else:
            return "unknown"
    else:
        return "unknown"

def is_link(text: Union[str, None]):
    if text:
        if re.fullmatch(r"^https?://[^\s]+$", text):
            return True
        else:
            return False
    else:
        return False

def has_link(text: Union[str, None]):
    if text:
        if re.findall(r"(https?://[^\s]+)", text):
            return True
        else:
            return False
    else:
        return False

@dataclass(**dataclass_items)
class Message(object):
    id: Union[str, None] = None
    chat_id: Union[str, None] = None
    chat_type: Union[Literal['private', 'channel', 'group', 'unknown'], None] = None
    text: Union[str, None] = None
    time: Union[int, None] = None
    is_edited: Union[bool, None] = None
    sender_type: Union[message_sender_enum, None] = None
    sender_id: Union[str, None] = None
    aux_data: Union[AuxData, None] = None
    file: Union[File, None] = None
    reply_to_message_id: Union[str, None] = None
    forwarded_from: Union[ForwardedFrom, None] = None
    forwarded_no_link: Union[str, None] = None
    location: Union[Location, None] = None
    sticker: Union[Sticker, None] = None
    contact_message: Union[ContactMessage, None] = None
    metadata: Union[Metadata, None] = None
    poll: Union[Poll, None] = None
    is_link: Union[bool, None] = None
    has_link: Union[bool, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Message":
        mid = data.get("message_id") if "message_id" in data else data.get("id") if "id" in data else None
        return cls(
            id=mid,
            chat_id=data.get("chat_id"),
            chat_type=guess_chat(data.get("chat_id")),
            text=data.get("text"),
            time=data.get("time"),
            is_edited=data.get("is_edited"),
            sender_type=data.get("sender_type"),
            sender_id=data.get("sender_id"),
            aux_data=AuxData.from_dict(data.get("aux_data", {})),
            file=File.from_dict(data.get("file", {})),
            reply_to_message_id=data.get("reply_to_message_id"),
            forwarded_from=ForwardedFrom.from_dict(data.get("forwarded_from", {})),
            forwarded_no_link=data.get("forwarded_no_link"),
            location=Location.from_dict(data.get("location", {})),
            sticker=Sticker.from_dict(data.get("sticker", {})),
            contact_message=ContactMessage.from_dict(data.get("contact_message", {})),
            metadata=Metadata.from_dict(data.get("metadata", {})),
            poll=Poll.from_dict(data.get("poll", {})),
            is_link=is_link(data.get("text")),
            has_link=has_link(data.get("text"))
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "chat_id": self.chat_id,
            "chat_type": self.chat_type,
            "text": self.text,
            "time": self.time,
            "is_edited": self.is_edited,
            "sender_type": self.sender_type,
            "sender_id": self.sender_id,
            "aux_data": self.aux_data.to_dict() if self.aux_data else None,
            "file": self.file.to_dict() if self.file else None,
            "reply_to_message_id": self.reply_to_message_id,
            "forwarded_from": self.forwarded_from.to_dict() if self.forwarded_from else None,
            "forwarded_no_link": self.forwarded_no_link,
            "location": self.location.to_dict() if self.location else None,
            "sticker": self.sticker.to_dict() if self.sticker else None,
            "contact_message": self.contact_message.to_dict() if self.contact_message else None,
            "metadata": self.metadata.to_dict() if self.metadata else None,
            "poll": self.poll.to_dict() if self.poll else None,
            "is_link": self.is_link,
            "has_link": self.has_link
        }

    def guess_chat(self):
        if self.chat_id:
            if self.chat_id.startswith("b0"):
                return "private"
            elif self.chat_id.startswith("c0"):
                return "channel"
            elif self.chat_id.startswith("g0"):
                return "group"
            else:
                return "unknown"
        else:
            return "unknown"
