﻿from .KeypadRow import KeypadRow
from dataclasses import dataclass, field
from typing import Union, List
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class Keypad(object):
    rows: Union[List[KeypadRow], None] = field(default_factory=list)
    resize_keyboard: Union[bool, None] = None
    one_time_keyboard: Union[bool, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Keypad":
        return cls(
            rows=[KeypadRow.from_dict(rx) for rx in data.get("rows", [])],
            resize_keyboard=data.get("resize_keyboard"),
            one_time_keyboard=data.get("one_time_keyboard")
        )
    
    def to_dict(self) -> dict:
        return {
            "rows": [rx.to_dict() for rx in (self.rows if self.rows else [])],
            "resize_keyboard": self.resize_keyboard,
            "one_time_keyboard": self.one_time_keyboard
        }


