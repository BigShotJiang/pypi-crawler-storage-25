﻿from .enums import button_type_enum
from .ButtonSelection import ButtonSelection
from .ButtonCalendar import ButtonCalendar
from .ButtonNumberPicker import ButtonNumberPicker
from .ButtonStringPicker import ButtonStringPicker
from .ButtonLocation import ButtonLocation
from .ButtonTextbox import ButtonTextbox
from dataclasses import dataclass
from typing import Union
from .__rule import dataclass_items

@dataclass(**dataclass_items)
class Button(object):
    id: Union[str, None] = None
    type: Union[button_type_enum, None] = None
    button_text: Union[str, None] = None
    button_selection: Union[ButtonSelection, None] = None
    button_calendar: Union[ButtonCalendar, None] = None
    button_number_picker: Union[ButtonNumberPicker, None] = None
    button_string_picker: Union[ButtonStringPicker, None] = None
    button_location: Union[ButtonLocation, None] = None
    button_textbox: Union[ButtonTextbox, None] = None

    @classmethod
    def from_dict(cls, data: dict) -> "Button":
        return cls(
            id=data.get("id"),
            type=data.get("type"),
            button_text=data.get("button_text"),
            button_selection=ButtonSelection.from_dict(data.get("button_selection", {})),
            button_calendar=ButtonCalendar.from_dict(data.get("button_calendar", {})),
            button_number_picker=ButtonNumberPicker.from_dict(data.get("button_number_picker", {})),
            button_string_picker=ButtonStringPicker.from_dict(data.get("button_string_picker", {})),
            button_location=ButtonLocation.from_dict(data.get("button_location", {})),
            button_textbox=ButtonTextbox.from_dict(data.get("button_textbox", {}))
        )
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type,
            "button_text": self.button_text,
            "button_selection": self.button_selection.to_dict() if self.button_selection else None,
            "button_calendar": self.button_calendar.to_dict() if self.button_calendar else None,
            "button_number_picker": self.button_number_picker.to_dict() if self.button_number_picker else None,
            "button_string_picker": self.button_string_picker.to_dict() if self.button_string_picker else None,
            "button_location": self.button_location.to_dict() if self.button_location else None,
            "button_textbox": self.button_textbox.to_dict() if self.button_textbox else None
        }


