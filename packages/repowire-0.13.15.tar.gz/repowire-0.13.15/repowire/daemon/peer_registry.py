"""Unified peer registry: merges PeerManager + SessionMapper into one class.

Holds both the in-memory peer registry (_peers) and the persistent session
mappings (_mappings). Mutations that touch both stores happen under a single
lock, fixing the stale-mapping bug where set_peer_circle / update_peer_display_name
only updated the Peer but not the SessionMapping.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from collections import deque
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal
from uuid import uuid4

from repowire.config.models import DEFAULT_QUERY_TIMEOUT, AgentType, Config
from repowire.protocol.peers import Peer, PeerRole, PeerStatus, TurnState

if TYPE_CHECKING:
    from repowire.daemon.ask_tracker import AskTracker
    from repowire.daemon.event_bus import EventBus
    from repowire.daemon.message_router import MessageRouter
    from repowire.daemon.query_tracker import QueryTracker
    from repowire.daemon.websocket_transport import WebSocketTransport

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# SessionMapping dataclass (previously in session_mapper.py)
# ---------------------------------------------------------------------------

@dataclass
class SessionMapping:
    """Persistent mapping of session to peer identity."""

    session_id: str  # "repow-dev-a1b2c3d4"
    display_name: str
    circle: str
    backend: AgentType
    path: str | None = None
    role: PeerRole = PeerRole.AGENT
    updated_at: str | None = None
    description: str = ""

    def __post_init__(self) -> None:
        if self.updated_at is None:
            self.updated_at = datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# PeerRegistry
# ---------------------------------------------------------------------------

class PeerRegistry:
    """Unified peer registry with integrated session mapping.

    Combines the responsibilities of PeerManager (in-memory peer state,
    message routing delegation, event tracking) and SessionMapper (stable
    peer-ID allocation, disk persistence).

    Thread-safe with asyncio locks.
    """

    def __init__(
        self,
        config: Config,
        message_router: MessageRouter,
        query_tracker: QueryTracker | None = None,
        transport: WebSocketTransport | None = None,
        persistence_path: Path | None = None,
        ask_tracker: AskTracker | None = None,
        event_bus: EventBus | None = None,
    ) -> None:
        self._config = config
        self._router = message_router
        self._query_tracker = query_tracker
        self._transport = transport
        self._ask_tracker = ask_tracker
        self._event_bus = event_bus

        # Peer registry: peer_id -> Peer (single source of truth)
        self._peers: dict[str, Peer] = {}

        # Session mappings: peer_id -> SessionMapping (persistent)
        self._mappings: dict[str, SessionMapping] = {}
        self._mappings_path = persistence_path or (
            Config.get_config_dir() / "sessions.json"
        )
        self._mappings_dirty = False
        self._load_mappings()

        self._lock = asyncio.Lock()
        self._events: deque[dict[str, Any]] = deque(maxlen=500)
        self._events_path = Config.get_config_dir() / "events.json"
        self._events_dirty = False
        self._load_events()
        self._last_repair: float = 0.0
        self._repair_lock = asyncio.Lock()
        # Per-subscriber wakeup events for SSE streamers. add_event() sets
        # all of them; each streamer clears and waits on its own.
        self._event_subscribers: set[asyncio.Event] = set()

        # When each peer's current description was set. Used for clear-on-read
        # TTL — see config.daemon.description_ttl_seconds. Registry-internal
        # so the wire-facing Peer schema stays untouched.
        self._description_set_at: dict[str, datetime] = {}

    # ------------------------------------------------------------------
    # Mapping persistence
    # ------------------------------------------------------------------

    def _load_mappings(self) -> None:
        """Load session mappings from disk."""
        if not self._mappings_path.exists():
            return
        try:
            data = json.loads(self._mappings_path.read_text())
            skipped = 0
            for session_id, mapping_data in data.items():
                path = mapping_data.get("path")
                if path and not Path(path).exists():
                    skipped += 1
                    continue
                self._mappings[session_id] = SessionMapping(**mapping_data)
            if skipped:
                logger.info(f"Skipped {skipped} mappings with non-existent paths")
                self._mappings_dirty = True
            logger.info(f"Loaded {len(self._mappings)} session mappings")
        except (json.JSONDecodeError, TypeError, ValueError, KeyError) as e:
            backup_ts = int(time.time())
            backup = self._mappings_path.with_suffix(f".json.corrupt.{backup_ts}")
            try:
                self._mappings_path.rename(backup)
                logger.error(f"Corrupt session mappings, backed up to {backup}: {e}")
            except OSError:
                logger.error(f"Corrupt session mappings (backup failed): {e}")
        except OSError as e:
            logger.error(f"Failed to read session mappings file: {e}")

    def _persist_mappings(self) -> None:
        """Save session mappings to disk atomically (debounced via dirty flag).

        Called from lazy_repair and shutdown, not on every mutation.
        """
        if not self._mappings_dirty:
            return
        tmp_path = self._mappings_path.with_suffix(".json.tmp")
        try:
            self._mappings_path.parent.mkdir(parents=True, exist_ok=True)
            data = {
                session_id: asdict(mapping)
                for session_id, mapping in self._mappings.items()
            }
            tmp_path.write_text(json.dumps(data, indent=2))
            os.replace(str(tmp_path), str(self._mappings_path))
            self._mappings_dirty = False
        except OSError as e:
            logger.error(f"Failed to save session mappings: {e}")
            try:
                tmp_path.unlink(missing_ok=True)
            except OSError:
                pass

    # ------------------------------------------------------------------
    # Event tracking
    # ------------------------------------------------------------------

    def _load_events(self) -> None:
        """Load persisted events from disk."""
        try:
            if self._events_path.exists():
                data = json.loads(self._events_path.read_text())
                for event in data[-100:]:
                    self._events.append(event)
        except Exception:
            logger.warning("Failed to load events from %s", self._events_path)

    def _save_events(self) -> None:
        """Persist events to disk (called periodically, not on every write)."""
        if not self._events_dirty:
            return
        try:
            self._events_path.parent.mkdir(parents=True, exist_ok=True)
            self._events_path.write_text(json.dumps(list(self._events)))
            self._events_dirty = False
        except Exception:
            logger.warning("Failed to save events to %s", self._events_path)

    def add_event(self, event_type: str, data: dict[str, Any]) -> str:
        """Add an event to the history. Returns event ID."""
        event_id = str(uuid4())
        self._events.append(
            {
                "id": event_id,
                "type": event_type,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                **data,
            }
        )
        self._events_dirty = True
        for sub in self._event_subscribers:
            sub.set()
        return event_id

    def subscribe_events(self) -> asyncio.Event:
        """Register a wakeup Event fired on each add_event call.

        Caller must pair with unsubscribe_events on cleanup.
        """
        evt = asyncio.Event()
        self._event_subscribers.add(evt)
        return evt

    def unsubscribe_events(self, evt: asyncio.Event) -> None:
        """Remove a subscriber Event registered via subscribe_events."""
        self._event_subscribers.discard(evt)

    def events_since(self, event_id: str | None) -> list[dict[str, Any]]:
        """Return events after the given id. If id is None or evicted, return all."""
        events = list(self._events)
        if event_id is None:
            return events
        for i, event in enumerate(events):
            if event["id"] == event_id:
                return events[i + 1 :]
        return events

    def _update_event(self, event_id: str, updates: dict[str, Any]) -> bool:
        """Update an existing event by ID."""
        for event in self._events:
            if event["id"] == event_id:
                event.update(updates)
                return True
        return False

    def get_events(self) -> list[dict[str, Any]]:
        """Get the last 100 events."""
        return list(self._events)

    def _emit_status_change(
        self, peer: Peer, old_status: PeerStatus, new_status: PeerStatus,
    ) -> None:
        """Publish a PeerStatusChanged event if the status actually changed.

        Safe to call with the registry lock held: publish only schedules
        delivery tasks, it does not await.
        """
        if self._event_bus is None or old_status == new_status:
            return
        from repowire.daemon.event_bus import PeerStatusChanged
        self._event_bus.publish(
            PeerStatusChanged(
                peer_id=peer.peer_id,
                display_name=peer.display_name,
                old_status=old_status,
                new_status=new_status,
            )
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Start the peer registry."""
        logger.info("PeerRegistry started with unified WebSocket backend")

    async def stop(self) -> None:
        """Stop the peer registry."""
        logger.info("PeerRegistry stopped")

    # ------------------------------------------------------------------
    # Peer lookup (internal, must hold _lock)
    # ------------------------------------------------------------------

    def _lookup_peer_unlocked(self, identifier: str, circle: str | None = None) -> Peer | None:
        """Lookup peer by session_id or display_name. Must be called with lock held.

        When multiple peers share a display_name (different circles), filters by
        circle if provided. If circle is unspecified and multiple *online*
        peers share the name, raises ValueError instead of silently picking
        one (see issue #136: misroute via ambiguous resolve).
        """
        if identifier in self._peers:
            return self._peers[identifier]
        # Scan all peers matching display_name
        matches = [p for p in self._peers.values() if p.display_name == identifier]
        if not matches:
            return None
        # Filter by circle if specified
        if circle:
            matches = [p for p in matches if p.circle == circle]
            if not matches:
                return None
        if len(matches) == 1:
            return matches[0]
        active = [p for p in matches if p.status != PeerStatus.OFFLINE]
        candidates = active or matches

        # Ambiguous: >1 viable candidate and no explicit circle to disambiguate.
        # Pane ownership is the only safe tiebreaker — a pane-owned peer is
        # locally bound to a live tmux pane, so picking it over a pane-less
        # twin is unambiguous. Anything else (e.g. last_seen) is a guess and
        # caused issue #136 misroutes. Refuse to guess in that case.
        if circle is None and len(candidates) > 1:
            paned = [p for p in candidates if p.pane_id]
            if len(paned) == 1:
                return paned[0]
            circles = sorted({p.circle for p in candidates})
            raise ValueError(
                f"Ambiguous peer name {identifier!r}: matches in circles "
                f"{circles}. Specify a circle= or pass a peer_id."
            )

        def preference(peer: Peer) -> tuple[bool, bool, float]:
            connected = bool(self._transport and self._transport.is_connected(peer.peer_id))
            last_seen = peer.last_seen.timestamp() if peer.last_seen else 0.0
            return connected, bool(peer.pane_id), last_seen

        return max(candidates, key=preference)

    @staticmethod
    def _sanitize_folder_name(name: str) -> str:
        """Sanitize a folder name for use in display_name.

        Replaces characters not matching [a-zA-Z0-9._-] with hyphens,
        collapses runs, strips leading/trailing hyphens.
        """
        sanitized = re.sub(r"[^a-zA-Z0-9._-]", "-", name)
        sanitized = re.sub(r"-{2,}", "-", sanitized)
        sanitized = sanitized.strip("-")
        return sanitized or "peer"

    def _build_display_name(
        self, path: str, circle: str, backend: AgentType,
    ) -> str:
        """Build a unique display_name for a peer. Must hold lock.

        Format: {folder}-{backend}[-{suffix}]
        Prunes offline peers that hold a conflicting name (clean takeover).
        """
        folder = self._sanitize_folder_name(Path(path).name) if path else "peer"
        base = f"{folder}-{backend.value}"

        candidate = base
        suffix = 2
        while True:
            blocker = None
            for sid, peer in self._peers.items():
                if peer.display_name == candidate and peer.circle == circle:
                    blocker = (sid, peer)
                    break

            if blocker is None:
                self._prune_name_from_mappings(candidate, circle, backend)
                return candidate

            sid, peer = blocker
            if peer.status == PeerStatus.OFFLINE:
                # Prune the offline peer entirely (clean takeover)
                del self._peers[sid]
                self._mappings.pop(sid, None)
                self._mappings_dirty = True
                logger.info(f"Pruned offline peer {candidate} ({sid}) for name reclaim")
                return candidate

            # Name held by an active peer -- try next suffix
            candidate = f"{folder}-{suffix}-{backend.value}"
            suffix += 1

    def _prune_name_from_mappings(
        self, display_name: str, circle: str, backend: AgentType,
    ) -> None:
        """Remove orphaned mappings for a name not held by any live peer. Must hold lock."""
        to_remove = [
            sid for sid, m in self._mappings.items()
            if m.display_name == display_name and m.circle == circle and m.backend == backend
            and sid not in self._peers
        ]
        for sid in to_remove:
            del self._mappings[sid]
            self._mappings_dirty = True

    def _find_or_allocate_mapping(
        self,
        display_name: str,
        circle: str,
        backend: AgentType,
        path: str | None = None,
        role: PeerRole = PeerRole.AGENT,
    ) -> str:
        """Find existing mapping or allocate a new session_id. Must hold lock.

        Returns the session_id (existing or new).
        """
        for sid, mapping in self._mappings.items():
            if (
                mapping.display_name == display_name
                and mapping.circle == circle
                and mapping.backend == backend
            ):
                mapping.path = path
                mapping.updated_at = datetime.now(timezone.utc).isoformat()
                logger.info(f"Reusing session {sid} for {display_name}@{circle}")
                self._mappings_dirty = True
                return sid

        # Cross-circle adoption: when the caller supplied the fallback circle
        # ("default") but a prior mapping exists for the same (name, backend,
        # path), reuse it so the peer's prior circle and description survive
        # restarts where the tmux session name didn't propagate (e.g. claude
        # --continue). Strictly gated on circle == "default" to avoid
        # collapsing genuinely separate same-path peers in different circles.
        if circle == "default" and path:
            for sid, mapping in self._mappings.items():
                if (
                    mapping.display_name == display_name
                    and mapping.backend == backend
                    and mapping.path == path
                ):
                    mapping.updated_at = datetime.now(timezone.utc).isoformat()
                    self._mappings_dirty = True
                    logger.info(
                        f"Adopted prior session {sid} for {display_name} "
                        f"(restored circle={mapping.circle})"
                    )
                    return sid

        session_id = f"repow-{circle}-{uuid4().hex[:8]}"
        self._mappings[session_id] = SessionMapping(
            session_id=session_id,
            display_name=display_name,
            circle=circle,
            backend=backend,
            path=path,
            role=role,
        )
        logger.info(f"Created session {session_id} for {display_name}@{circle}")
        self._mappings_dirty = True
        return session_id

    def _release_pane(self, pane_id: str, new_peer_id: str) -> None:
        """Clear pane_id from any peer that currently owns it, except new_peer_id.

        When a new ws-hook claims a pane, the old peer's pane registration is
        stale. Clearing it prevents get_peer_by_pane from returning the wrong
        peer after a session restart in the same tmux pane. Must hold lock.

        Also marks the displaced peer offline: losing the pane means its
        ws-hook is no longer the live owner of that tmux pane, so the peer's
        inbound transport is gone. Leaving it ONLINE with pane_id=None creates
        zombie peers that future sessions may incorrectly claim.
        """
        for sid, peer in self._peers.items():
            if peer.pane_id == pane_id and sid != new_peer_id:
                old_status = peer.status
                peer.pane_id = None
                peer.status = PeerStatus.OFFLINE
                self._emit_status_change(peer, old_status, PeerStatus.OFFLINE)

    # ------------------------------------------------------------------
    # Allocate + register (atomic, the preferred public API)
    # ------------------------------------------------------------------

    async def allocate_and_register(
        self,
        *,
        circle: str,
        backend: AgentType,
        path: str | None = None,
        pane_id: str | None = None,
        tmux_session: str | None = None,
        metadata: dict | None = None,
        machine: str = "unknown",
        role: PeerRole = PeerRole.AGENT,
        peer_id: str | None = None,
        turn_state: TurnState | None = None,
    ) -> tuple[str, str]:
        """Allocate a peer_id and register the peer atomically.

        Returns (peer_id, assigned_display_name). The daemon builds the
        display_name from path + backend, auto-suffixing on collision and
        pruning offline peers for clean name takeover.

        If ``peer_id`` is provided and matches an existing peer, the peer is
        taken over in-place (WebSocket reconnect after HTTP pre-registration).
        """
        async with self._lock:
            # Reconnect: if caller provides a peer_id that exists, take over
            # only when it still describes the same peer identity. Stale pane
            # metadata can otherwise bind another pane's WebSocket to this id.
            if peer_id and peer_id in self._peers:
                existing = self._peers[peer_id]
                same_backend = existing.backend == backend
                same_path = not existing.path or not path or existing.path == path
                if not same_backend or not same_path:
                    logger.warning(
                        "Ignoring stale peer_id claim %s: existing=%s backend=%s path=%s "
                        "claim_backend=%s claim_path=%s",
                        peer_id,
                        existing.display_name,
                        existing.backend.value,
                        existing.path,
                        backend.value,
                        path,
                    )
                else:
                    old_status = existing.status
                    existing.status = PeerStatus.ONLINE
                    existing.last_seen = datetime.now(timezone.utc)
                    if turn_state is not None:
                        existing.turn_state = turn_state
                    self._emit_status_change(existing, old_status, PeerStatus.ONLINE)
                    if pane_id:
                        self._release_pane(pane_id, peer_id)
                        existing.pane_id = pane_id
                    if tmux_session:
                        existing.tmux_session = tmux_session
                    if machine != "unknown":
                        existing.machine = machine
                    logger.info(f"Peer reconnected: {existing.display_name} ({peer_id})")
                    return peer_id, existing.display_name

            # Fresh registration: daemon owns the name
            assigned_name = self._build_display_name(path or "", circle, backend)
            allocated_id = self._find_or_allocate_mapping(
                assigned_name, circle, backend, path, role=role,
            )
            if pane_id:
                self._release_pane(pane_id, allocated_id)

            # Restore circle, role, and description from persisted mapping. The
            # mapping is the durable source of truth for these fields; when
            # _find_or_allocate_mapping adopted a prior session, its stored
            # circle/role may differ from the caller-supplied defaults and
            # should win.
            restored = self._mappings.get(allocated_id)
            effective_circle = restored.circle if restored else circle
            effective_role = restored.role if restored else role
            restored_description = restored.description if restored else ""

            # --- create and insert Peer ---
            peer = Peer(
                peer_id=allocated_id,
                display_name=assigned_name,
                circle=effective_circle,
                backend=backend,
                role=effective_role,
                status=PeerStatus.ONLINE,
                last_seen=datetime.now(timezone.utc),
                pane_id=pane_id,
                tmux_session=tmux_session,
                path=path or "",
                machine=machine,
                metadata=metadata or {},
                description=restored_description,
                turn_state=turn_state,
            )
            self._peers[allocated_id] = peer
            logger.info(f"Peer registered: {assigned_name} ({allocated_id})")

            return allocated_id, assigned_name

    # ------------------------------------------------------------------
    # register_peer (backward-compat for tests that build Peer objects)
    # ------------------------------------------------------------------

    async def register_peer(self, peer: Peer) -> None:
        """Register a pre-built Peer in the mesh.

        Indexed by peer_id. Evicts stale same-name peers but does NOT create
        or update session mappings -- use ``allocate_and_register`` for the
        full atomic path.
        """
        async with self._lock:
            # Evict offline peers with same (display_name, backend)
            for old_sid, old_peer in list(self._peers.items()):
                if (
                    old_peer.display_name == peer.display_name
                    and old_peer.backend == peer.backend
                    and old_sid != peer.peer_id
                    and (old_peer.circle == peer.circle or old_peer.status == PeerStatus.OFFLINE)
                ):
                    del self._peers[old_sid]
            existing = self._peers.get(peer.peer_id)
            old_status = existing.status if existing else PeerStatus.OFFLINE
            peer.status = PeerStatus.ONLINE
            peer.last_seen = datetime.now(timezone.utc)
            self._peers[peer.peer_id] = peer
            self._emit_status_change(peer, old_status, PeerStatus.ONLINE)
            logger.info(f"Peer registered: {peer.display_name} ({peer.peer_id})")

    # ------------------------------------------------------------------
    # Unregister
    # ------------------------------------------------------------------

    async def unregister_peer(self, identifier: str, circle: str | None = None) -> bool:
        """Unregister a peer from the mesh (removes from both _peers and _mappings).

        Args:
            identifier: Either session_id or display_name
            circle: Optional circle filter to disambiguate same-name peers

        Returns:
            True if peer was found and removed
        """
        async with self._lock:
            # Try as session_id first (always unambiguous)
            if identifier in self._peers:
                peer = self._peers.pop(identifier)
                self._mappings.pop(identifier, None)
                self._mappings_dirty = True
                logger.info(f"Peer unregistered: {peer.display_name} ({identifier})")
                return True

            # Try as display_name — with optional circle filter
            for sid, peer in list(self._peers.items()):
                if peer.display_name == identifier:
                    if circle and peer.circle != circle:
                        continue
                    self._peers.pop(sid)
                    self._mappings.pop(sid, None)
                    self._mappings_dirty = True
                    logger.info(f"Peer unregistered: {identifier} ({sid})")
                    return True

            return False

    # ------------------------------------------------------------------
    # Peer accessors
    # ------------------------------------------------------------------

    async def get_peer(self, identifier: str, circle: str | None = None) -> Peer | None:
        """Get a peer by session_id or display_name."""
        async with self._lock:
            peer = self._lookup_peer_unlocked(identifier, circle=circle)
            if peer:
                self._apply_description_ttl(peer)
            return peer

    async def resolve_peer_strict(
        self, identifier: str, circle: str | None = None
    ) -> Peer | list[Peer]:
        """Resolve a peer by id-or-display_name, returning all matches when ambiguous.

        Unlike `get_peer`, an ambiguous display_name does not silently pick a
        winner — the caller gets the full candidate list and must disambiguate.
        Use this for destructive operations (kill, etc.) where guessing is wrong.

        Returns:
            The matching `Peer` (single match or peer_id hit), an empty list if
            no peer matches, or a list of 2+ peers when the display_name is
            ambiguous after circle filtering.
        """
        async with self._lock:
            in_circle = lambda p: circle is None or p.circle == circle  # noqa: E731
            by_id = [p for p in self._peers.values() if p.peer_id == identifier and in_circle(p)]
            if by_id:
                self._apply_description_ttl(by_id[0])
                return by_id[0]
            by_name = [
                p for p in self._peers.values()
                if p.display_name == identifier and in_circle(p)
            ]
            if len(by_name) == 1:
                self._apply_description_ttl(by_name[0])
                return by_name[0]
            for p in by_name:
                self._apply_description_ttl(p)
            return by_name

    async def get_peer_by_pane(self, pane_id: str) -> Peer | None:
        """Lookup peer by tmux pane_id."""
        async with self._lock:
            for peer in self._peers.values():
                if peer.pane_id == pane_id:
                    self._apply_description_ttl(peer)
                    return peer
            return None

    async def get_peers_by_circle(self, circle: str) -> list[Peer]:
        """Get all peers in a given circle."""
        async with self._lock:
            peers = [p for p in self._peers.values() if p.circle == circle]
            for p in peers:
                self._apply_description_ttl(p)
            return peers

    async def get_all_peers(self) -> list[Peer]:
        """Get all registered peers."""
        async with self._lock:
            peers = list(self._peers.values())
            for p in peers:
                self._apply_description_ttl(p)
            return peers

    def heartbeat_tolerance(self) -> int:
        """Seconds a peer's last_seen may lag before it's considered dead.

        Two heartbeat intervals: one missed beat is tolerated (normal jitter),
        two means the wire is dead. Public accessor so callers (routes, MCP)
        don't reach into `_config`.
        """
        return self._config.daemon.heartbeat_interval * 2

    async def get_orchestrator(self, circle: str) -> Peer | None:
        """Return the live orchestrator for a circle, or None.

        Live = role=ORCHESTRATOR, status in (ONLINE, BUSY), and last_seen within
        2 * heartbeat_interval (one missed beat tolerated, two means dead). If
        multiple match, returns the most recently seen.
        """
        tolerance = self.heartbeat_tolerance()
        now = datetime.now(timezone.utc)
        async with self._lock:
            candidates = [
                p for p in self._peers.values()
                if p.circle == circle
                and p.role == PeerRole.ORCHESTRATOR
                and p.status in (PeerStatus.ONLINE, PeerStatus.BUSY)
                and p.last_seen is not None
                and (now - p.last_seen).total_seconds() <= tolerance
            ]
            if not candidates:
                return None
            return max(candidates, key=lambda p: p.last_seen or now)

    async def is_orchestrator_present(self, circle: str) -> bool:
        """True iff a live orchestrator exists in the circle (see get_orchestrator)."""
        return (await self.get_orchestrator(circle)) is not None

    # ------------------------------------------------------------------
    # Circle access control (internal)
    # ------------------------------------------------------------------

    def _resolve_from_peer_unlocked(
        self, from_peer: str, target_peer: Peer, bypass_circle: bool
    ) -> Peer | None:
        """Resolve from_peer and check circle access. Must hold lock.

        Returns the resolved from_peer Peer object (or None if not found).
        """
        from_peer_obj = self._lookup_peer_unlocked(
            from_peer, circle=target_peer.circle
        ) or self._lookup_peer_unlocked(from_peer)
        self._check_circle_access_by_peers(from_peer_obj, target_peer, bypass_circle)
        return from_peer_obj

    def _check_circle_access_by_peers(
        self, from_obj: Peer | None, to_obj: Peer | None, bypass: bool
    ) -> None:
        """Check circle access given already-resolved Peer objects. Must hold lock."""
        if bypass:
            return
        if not from_obj or not to_obj:
            return
        if from_obj.bypasses_circles or to_obj.bypasses_circles:
            return
        if from_obj.circle != to_obj.circle:
            raise ValueError(
                f"Circle boundary: {from_obj.display_name} ({from_obj.circle}) "
                f"cannot access {to_obj.display_name} ({to_obj.circle})"
            )

    # ------------------------------------------------------------------
    # Message routing (query / notify / broadcast)
    # ------------------------------------------------------------------

    async def query(
        self,
        from_peer: str,
        to_peer: str,
        text: str,
        timeout: float = DEFAULT_QUERY_TIMEOUT,
        bypass_circle: bool = False,
        circle: str | None = None,
    ) -> str:
        """Send a query to a peer and wait for response.

        Raises:
            ValueError: If peer not found or circle boundary violated
            TimeoutError: If no response within timeout
        """
        async with self._lock:
            peer = self._lookup_peer_unlocked(to_peer, circle=circle)
            if not peer:
                raise ValueError(f"Unknown peer: {to_peer}")
            from_obj = self._resolve_from_peer_unlocked(from_peer, peer, bypass_circle)
            peer_id = peer.peer_id
            peer_name = peer.display_name
            from_peer_id = from_obj.peer_id if from_obj else None

        formatted_query = (
            f"[Repowire Query from @{from_peer}]\n"
            f"{text}\n\n"
            f"IMPORTANT: Respond directly in your message. Do NOT use ask() to reply - "
            f"your response is automatically captured and returned to {from_peer}."
        )

        query_event_id = self.add_event(
            "query",
            {
                "from": from_peer, "to": to_peer, "text": text,
                "from_peer_id": from_peer_id, "to_peer_id": peer_id,
                "status": "pending",
            },
        )

        try:
            response = await self._router.send_query(
                from_peer=from_peer,
                to_session_id=peer_id,
                to_peer_name=peer_name,
                text=formatted_query,
                timeout=timeout,
            )

            self._update_event(query_event_id, {"status": "success"})
            self.add_event(
                "response",
                {
                    "from": to_peer, "to": from_peer,
                    "from_peer_id": peer_id, "to_peer_id": from_peer_id,
                    "text": response[:100] + "..." if len(response) > 100 else response,
                    "correlation_id": query_event_id,
                },
            )

            return response

        except TimeoutError:
            self._update_event(query_event_id, {"status": "timeout"})
            # Fire-and-forget liveness check — don't block the error path
            asyncio.ensure_future(self._check_peer_after_timeout(peer_id))
            raise

        except Exception as e:
            self._update_event(query_event_id, {"status": "error", "error": str(e)})
            raise

    async def _check_peer_after_timeout(self, peer_id: str) -> None:
        """Targeted liveness check after a query timeout. Runs in background."""
        if not self._transport or not self._transport.is_connected(peer_id):
            return
        try:
            await self._transport.ping(peer_id, timeout=5.0)
        except Exception:
            await self.update_peer_status(peer_id, PeerStatus.OFFLINE)
            if self._query_tracker:
                await self._query_tracker.cancel_queries_to_peer(peer_id)

    async def notify(
        self,
        from_peer: str,
        to_peer: str,
        text: str,
        bypass_circle: bool = False,
        circle: str | None = None,
    ) -> Literal["sent", "queued"]:
        """Send a notification to a peer (fire-and-forget).

        Direct wire send via the router. No daemon-side queueing: BUSY peers
        have a live WS and ws-hook buffers the tmux paste through the busy
        turn, so direct send is sufficient. Offline peers raise TransportError
        so callers can retry or escalate.

        Returns:
            "sent" if recipient was ONLINE at send-time (immediate delivery),
            "queued" if recipient was BUSY (ws-hook holds the paste until the
            current turn ends).

        Raises:
            ValueError: peer not found / circle boundary violated.
            TransportError: peer has no live WS.
        """
        async with self._lock:
            peer = self._lookup_peer_unlocked(to_peer, circle=circle)
            if not peer:
                raise ValueError(f"Unknown peer: {to_peer}")
            from_obj = self._resolve_from_peer_unlocked(from_peer, peer, bypass_circle)
            peer_id = peer.peer_id
            peer_name = peer.display_name
            from_peer_id = from_obj.peer_id if from_obj else None
            delivery_status: Literal["sent", "queued"] = (
                "queued" if peer.status == PeerStatus.BUSY else "sent"
            )

        self.add_event(
            "notification",
            {
                "from": from_peer, "to": to_peer, "text": text,
                "from_peer_id": from_peer_id, "to_peer_id": peer_id,
                "delivery_status": delivery_status,
            },
        )

        await self._router.send_notification(
            from_peer=from_peer,
            to_session_id=peer_id,
            to_peer_name=peer_name,
            text=text,
            intended_recipient_name=to_peer,
        )
        return delivery_status

    async def deliver_ask(
        self,
        from_peer: str,
        to_peer: str,
        text: str,
        correlation_id: str,
        reply_to: str | None = None,
        bypass_circle: bool = False,
        circle: str | None = None,
    ) -> None:
        """Inject an ask to a peer as a type=ask wire frame.

        Direct wire send via the router. BUSY isn't a delivery barrier under
        async ask semantics — ws-hook buffers the tmux paste through the busy
        turn. Offline peers raise TransportError so the /ask route can roll
        back the tracker registration and return an error to the caller.

        Raises:
            ValueError: peer not found / circle violation.
            TransportError: peer has no live WS.
        """
        async with self._lock:
            peer = self._lookup_peer_unlocked(to_peer, circle=circle)
            if not peer:
                raise ValueError(f"Unknown peer: {to_peer}")
            from_obj = self._resolve_from_peer_unlocked(from_peer, peer, bypass_circle)
            peer_id = peer.peer_id
            peer_name = peer.display_name
            from_peer_id = from_obj.peer_id if from_obj else None

        self.add_event(
            "ask",
            {
                "from": from_peer, "to": to_peer, "text": text,
                "from_peer_id": from_peer_id, "to_peer_id": peer_id,
                "correlation_id": correlation_id,
                "reply_to": reply_to,
            },
        )

        await self._router.send_ask(
            from_peer=from_peer,
            to_session_id=peer_id,
            to_peer_name=peer_name,
            correlation_id=correlation_id,
            text=text,
            reply_to=reply_to,
            intended_recipient_name=to_peer,
        )

    async def broadcast(
        self,
        from_peer: str,
        text: str,
        exclude: list[str] | None = None,
        bypass_circle: bool = False,
    ) -> tuple[list[str], list[dict[str, str]]]:
        """Broadcast to all peers in sender's circle (or all, if sender bypasses).

        Best-effort per-peer: a stale WS for one recipient doesn't fail the
        whole call. Returns ([sent_to_names], [{peer, error}, ...]).
        """
        exclude_names = set(exclude or [])
        exclude_names.add(from_peer)

        exclude_session_ids: set[str] = set()
        async with self._lock:
            from_peer_obj: Peer | None = None
            for name in exclude_names:
                peer = self._lookup_peer_unlocked(name)
                if peer:
                    exclude_session_ids.add(peer.peer_id)
                    if name == from_peer:
                        from_peer_obj = peer

            sender_bypasses = from_peer_obj and (bypass_circle or from_peer_obj.bypasses_circles)
            if not sender_bypasses and from_peer_obj:
                from_circle = from_peer_obj.circle
                for sid, peer in self._peers.items():
                    if peer.circle != from_circle and not peer.bypasses_circles:
                        exclude_session_ids.add(sid)

            from_peer_id = from_peer_obj.peer_id if from_peer_obj else None
            id_to_name = {sid: p.display_name for sid, p in self._peers.items()}

        self.add_event(
            "broadcast",
            {
                "from": from_peer, "text": text, "exclude": exclude,
                "from_peer_id": from_peer_id,
            },
        )

        sent_ids, failed = await self._router.broadcast(
            from_peer=from_peer,
            text=text,
            exclude=exclude_session_ids,
        )

        sent_names = [id_to_name[sid] for sid in sent_ids if sid in id_to_name]
        failed_named = [
            {"peer": id_to_name.get(f["session_id"], f["session_id"]), "error": f["error"]}
            for f in failed
        ]
        return sent_names, failed_named

    # ------------------------------------------------------------------
    # Status / metadata mutations
    # ------------------------------------------------------------------

    async def update_peer_status(self, identifier: str, status: PeerStatus) -> None:
        """Update peer status + last_seen. No side effects beyond that."""
        async with self._lock:
            peer = self._lookup_peer_unlocked(identifier)
            if not peer:
                logger.warning(
                    "update_peer_status: peer not found: %s (status=%s not applied)",
                    identifier,
                    status.value,
                )
                return
            old_status = peer.status
            peer.status = status
            peer.last_seen = datetime.now(timezone.utc)
            self._emit_status_change(peer, old_status, status)

    async def update_peer_turn_state(
        self, identifier: str, turn_state: TurnState | None,
    ) -> None:
        """Update peer turn_state (idle/working/awaiting_input/pending_first_turn).

        Orthogonal to status; does not refresh last_seen on its own (the
        accompanying status update typically does). No event is emitted for
        v1 — list_peers consumers pick it up on next read.
        """
        async with self._lock:
            peer = self._lookup_peer_unlocked(identifier)
            if not peer:
                logger.warning(
                    "update_peer_turn_state: peer not found: %s (turn_state=%s not applied)",
                    identifier,
                    turn_state,
                )
                return
            peer.turn_state = turn_state

    async def touch_last_seen(
        self, identifier: str, circle: str | None = None,
    ) -> bool:
        """Refresh a peer's last_seen and revive OFFLINE peers.

        Outbound MCP traffic from a peer is a liveness signal even when the
        peer's ws-hook has dropped (inbound is broken, but the agent is alive
        and acting). If the registry still marks that peer OFFLINE, the
        observed activity is stronger evidence than the stale status, so revive
        it to ONLINE while preserving BUSY/ONLINE peers as-is.
        """
        async with self._lock:
            peer = self._lookup_peer_unlocked(identifier, circle=circle)
            if not peer:
                return False
            old_status = peer.status
            if peer.status == PeerStatus.OFFLINE:
                peer.status = PeerStatus.ONLINE
            peer.last_seen = datetime.now(timezone.utc)
            if old_status != peer.status:
                self._emit_status_change(peer, old_status, peer.status)
            return True

    async def update_description(
        self, identifier: str, description: str, circle: str | None = None
    ) -> bool:
        """Update peer's task description."""
        async with self._lock:
            peer = self._lookup_peer_unlocked(identifier, circle=circle)
            if not peer:
                return False
            peer.description = description
            peer.last_seen = datetime.now(timezone.utc)
            if description:
                self._description_set_at[peer.peer_id] = datetime.now(timezone.utc)
            else:
                self._description_set_at.pop(peer.peer_id, None)
            mapping = self._mappings.get(peer.peer_id)
            if mapping and mapping.description != description:
                mapping.description = description
                mapping.updated_at = datetime.now(timezone.utc).isoformat()
                self._mappings_dirty = True
            return True

    def _apply_description_ttl(self, peer: Peer) -> None:
        """Clear peer.description if it's older than the configured TTL.

        Mutates in place so list_peers / get_peer reflect cleared state on the
        next read without waiting for a sweep. TTL <= 0 disables the check.
        """
        if not peer.description:
            return
        ttl = self._config.daemon.description_ttl_seconds
        if ttl <= 0:
            return
        set_at = self._description_set_at.get(peer.peer_id)
        if set_at is None:
            # Description was set before TTL tracking started (e.g. restored
            # from a persisted mapping). Stamp now so the TTL window is
            # well-defined, rather than clearing a description we cannot age.
            self._description_set_at[peer.peer_id] = datetime.now(timezone.utc)
            return
        if (datetime.now(timezone.utc) - set_at).total_seconds() < ttl:
            return
        peer.description = ""
        self._description_set_at.pop(peer.peer_id, None)
        mapping = self._mappings.get(peer.peer_id)
        if mapping and mapping.description:
            mapping.description = ""
            mapping.updated_at = datetime.now(timezone.utc).isoformat()
            self._mappings_dirty = True

    async def set_peer_circle(self, identifier: str, circle: str) -> None:
        """Update peer's circle (both in-memory Peer AND persistent mapping)."""
        async with self._lock:
            peer = self._lookup_peer_unlocked(identifier)
            if peer:
                old_circle = peer.circle
                peer.circle = circle
                # Keep mapping in sync
                mapping = self._mappings.get(peer.peer_id)
                if mapping:
                    mapping.circle = circle
                    self._mappings_dirty = True
                logger.info(f"Peer {peer.display_name} moved from {old_circle} to {circle}")
            else:
                logger.warning(
                    "set_peer_circle: peer not found: %s (circle=%s not applied)",
                    identifier,
                    circle,
                )

    async def update_peer_display_name(self, session_id: str, new_name: str) -> bool:
        """Update a peer's display_name in-place, preserving peer_id.

        Evicts OFFLINE ghosts with the same (display_name, backend). Returns False
        if a conflicting ONLINE/BUSY peer exists with that name.

        Also updates the persistent mapping atomically.
        """
        async with self._lock:
            peer = self._peers.get(session_id)
            if not peer:
                return False
            to_evict = []
            for old_sid, old_peer in self._peers.items():
                if (
                    old_peer.display_name != new_name
                    or old_peer.backend != peer.backend
                    or old_sid == session_id
                ):
                    continue
                if old_peer.status == PeerStatus.OFFLINE:
                    to_evict.append(old_sid)
                else:
                    return False
            for old_sid in to_evict:
                del self._peers[old_sid]
            peer.display_name = new_name
            # Keep mapping in sync
            mapping = self._mappings.get(session_id)
            if mapping:
                mapping.display_name = new_name
                mapping.updated_at = datetime.now(timezone.utc).isoformat()
                self._mappings_dirty = True
            return True

    async def mark_offline(self, identifier: str) -> int:
        """Mark peer offline and cancel pending queries.

        Returns:
            Number of cancelled queries
        """
        async with self._lock:
            peer = self._lookup_peer_unlocked(identifier)
            if not peer:
                return 0
            old_status = peer.status
            peer.status = PeerStatus.OFFLINE
            peer.last_seen = datetime.now(timezone.utc)
            self._emit_status_change(peer, old_status, PeerStatus.OFFLINE)
            session_id = peer.peer_id

        cancelled = 0
        if self._query_tracker:
            cancelled = await self._query_tracker.cancel_queries_to_peer(session_id)

        logger.info(f"Marked {identifier} offline, cancelled {cancelled} queries")
        return cancelled

    # ------------------------------------------------------------------
    # Session mapping helpers (public, formerly on SessionMapper)
    # ------------------------------------------------------------------

    def get_mapping(self, session_id: str) -> SessionMapping | None:
        """Get mapping for session_id."""
        return self._mappings.get(session_id)

    def get_all_mappings(self) -> dict[str, SessionMapping]:
        """Get all mappings."""
        return self._mappings.copy()

    def _register_session(
        self,
        display_name: str,
        circle: str,
        backend: AgentType,
        path: str | None = None,
    ) -> str:
        """Register or reuse session_id (synchronous, mapping-only, internal)."""
        return self._find_or_allocate_mapping(display_name, circle, backend, path)

    def _update_mapping_circle(self, session_id: str, circle: str) -> bool:
        """Update circle for an existing mapping (internal)."""
        mapping = self._mappings.get(session_id)
        if mapping:
            mapping.circle = circle
            self._mappings_dirty = True
            return True
        return False

    def _update_mapping_display_name(self, session_id: str, new_name: str) -> bool:
        """Update display_name for an existing mapping (internal)."""
        mapping = self._mappings.get(session_id)
        if mapping:
            mapping.display_name = new_name
            mapping.updated_at = datetime.now(timezone.utc).isoformat()
            self._mappings_dirty = True
            return True
        return False

    def _unregister_session(self, session_id: str) -> bool:
        """Unregister a single session mapping (internal)."""
        if session_id in self._mappings:
            del self._mappings[session_id]
            self._mappings_dirty = True
            logger.info(f"Unregistered session {session_id}")
            return True
        return False

    def _unregister_sessions(self, session_ids: list[str]) -> int:
        """Batch unregister session mappings (internal). Returns count removed."""
        removed = 0
        for sid in session_ids:
            if sid in self._mappings:
                del self._mappings[sid]
                removed += 1
        if removed:
            self._mappings_dirty = True
            logger.info(f"Batch unregistered {removed} sessions")
        return removed

    @staticmethod
    def _is_stale(mapping: SessionMapping, cutoff: datetime) -> bool:
        if not mapping.updated_at:
            return True
        try:
            return datetime.fromisoformat(mapping.updated_at) < cutoff
        except ValueError:
            return True

    def prune_offline(self, max_age_hours: float = 72) -> int:
        """Remove stale mappings older than max_age_hours.

        Returns:
            Number of pruned mappings.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
        initial_count = len(self._mappings)
        self._mappings = {
            sid: mapping
            for sid, mapping in self._mappings.items()
            if not self._is_stale(mapping, cutoff)
        }
        pruned_count = initial_count - len(self._mappings)

        if pruned_count > 0:
            self._mappings_dirty = True
            logger.info(
                f"Pruned {pruned_count} stale session mappings (>{max_age_hours}h old)"
            )

        return pruned_count

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    async def lazy_repair(self) -> None:
        """Debounced maintenance: demote ghosts, evict stale, persist.

        Max 1x per 30s. Called from message/peer endpoints. Lifecycle hooks
        and WebSocket disconnect handle liveness — this catches stragglers.
        """
        if time.monotonic() - self._last_repair < 30.0:
            return
        async with self._repair_lock:
            if time.monotonic() - self._last_repair < 30.0:
                return
            self._last_repair = time.monotonic()
            await self._demote_disconnected_peers()
            await self._demote_unsafe_connected_peers()
            await self._reap_dangling_peers()
            await self._evict_stale_peers()
            self._save_events()
            self._persist_mappings()

    async def _demote_disconnected_peers(self) -> int:
        """Mark ONLINE/BUSY peers without a WebSocket connection as OFFLINE.

        Catches ghost peers that registered via HTTP but whose ws-hook
        never connected (e.g. pane died before ws-hook could start).
        """
        if not self._transport:
            return 0
        async with self._lock:
            ghosts = [
                p for p in self._peers.values()
                if p.status in (PeerStatus.ONLINE, PeerStatus.BUSY)
                and not self._transport.is_connected(p.peer_id)
            ]
        count = 0
        for peer in ghosts:
            await self.mark_offline(peer.peer_id)
            count += 1
        if count:
            logger.info("demoted %d ghost peers (no WebSocket)", count)
        return count

    async def _demote_unsafe_connected_peers(self) -> int:
        """Mark connected tmux peers OFFLINE if their pane is no longer safe."""
        transport = self._transport
        if not transport:
            return 0

        async with self._lock:
            targets = [
                p.peer_id for p in self._peers.values()
                if p.status in (PeerStatus.ONLINE, PeerStatus.BUSY)
                and p.pane_id
                and p.backend != AgentType.OPENCODE
                and transport.is_connected(p.peer_id)
            ]

        async def check(peer_id: str) -> tuple[str, bool]:
            try:
                pong = await transport.ping(peer_id, timeout=1.0)
                return peer_id, bool(pong.get("pane_alive", True))
            except Exception:
                return peer_id, False

        results = await asyncio.gather(*(check(peer_id) for peer_id in targets))
        count = 0
        for peer_id, pane_alive in results:
            if pane_alive:
                continue
            await self.mark_offline(peer_id)
            await transport.disconnect(peer_id)
            count += 1

        if count:
            logger.info("demoted %d unsafe connected peers", count)
        return count

    async def _reap_dangling_peers(self) -> int:
        """Remove OFFLINE peers whose liveness TTL has expired.

        Lazy-repair only: no background polling. ONLINE/BUSY peers are first
        demoted by the WebSocket liveness checks above; this pass removes peers
        that stayed offline past the configured grace window.
        """
        ttl = self._config.daemon.peer_reap_ttl_seconds
        if ttl <= 0:
            return 0

        cutoff = datetime.now(timezone.utc) - timedelta(seconds=ttl)
        async with self._lock:
            stale = [
                p for p in self._peers.values()
                if p.status == PeerStatus.OFFLINE
                and p.last_seen is not None
                and p.last_seen < cutoff
            ]
            for peer in stale:
                self._peers.pop(peer.peer_id, None)
                self._mappings.pop(peer.peer_id, None)
                self._description_set_at.pop(peer.peer_id, None)
                self._mappings_dirty = True

        for peer in stale:
            if self._transport is not None:
                try:
                    await self._transport.disconnect(peer.peer_id)
                except Exception as e:
                    logger.warning(
                        "reaper: failed to disconnect %s transport: %s",
                        peer.peer_id,
                        e,
                    )
            if self._ask_tracker is not None:
                await self._ask_tracker.forget_peer(peer.peer_id)
            self.add_event(
                "peer_reaped",
                {
                    "peer_id": peer.peer_id,
                    "display_name": peer.display_name,
                    "backend": peer.backend.value,
                    "path": peer.path,
                    "pane_id": peer.pane_id,
                    "reason": "offline_ttl",
                },
            )

        if stale:
            logger.info("reaped %d dangling offline peers", len(stale))
        return len(stale)

    async def _evict_stale_peers(self) -> int:
        """Evict long-offline peers from both _peers and _mappings.

        Returns number of evicted peers.
        """
        max_age = self._config.daemon.prune_max_age_hours * 3600
        now = time.time()
        async with self._lock:
            stale = [
                pid for pid, p in self._peers.items()
                if p.status == PeerStatus.OFFLINE
                and p.last_seen
                and (now - p.last_seen.timestamp()) > max_age
            ]
            for pid in stale:
                del self._peers[pid]
                self._mappings.pop(pid, None)
            if stale:
                self._mappings_dirty = True
                logger.info("evicted %d stale offline peers", len(stale))
        if stale and self._ask_tracker is not None:
            for pid in stale:
                await self._ask_tracker.forget_peer(pid)
        return len(stale)

    async def active_repair(self) -> None:
        """Full liveness sweep: ping ONLINE/BUSY peers, mark dead ones OFFLINE.

        Unlike lazy_repair, this actively probes peers. Use for diagnostics
        or when lifecycle hooks are not available.
        """
        async with self._repair_lock:
            await self._do_repair()
            self._save_events()
            self._persist_mappings()

    async def _do_repair(self) -> None:
        """Ping/pong liveness check. Must hold _repair_lock."""
        transport = self._transport
        if not transport:
            return

        async with self._lock:
            targets = [
                (p.peer_id, p.backend, p.circle)
                for p in self._peers.values()
                if p.status in (PeerStatus.ONLINE, PeerStatus.BUSY)
            ]

        async def check_peer(
            peer_id: str, backend, circle: str,
        ) -> tuple[str, str | None] | None:
            """Returns (peer_id, circle) if alive, None if dead."""
            if not transport.is_connected(peer_id):
                return None
            if backend == AgentType.OPENCODE:
                return (peer_id, circle)
            try:
                pong = await transport.ping(peer_id, timeout=5.0)
                pong_circle = pong.get("circle")
                return (peer_id, pong_circle or circle)
            except Exception:
                return None

        results = await asyncio.gather(
            *(check_peer(pid, backend, circle) for pid, backend, circle in targets),
            return_exceptions=True,
        )

        alive_peers = [r for r in results if isinstance(r, tuple)]
        dead_peer_ids = {t[0] for t in targets} - {r[0] for r in alive_peers}

        targets_map = {pid: c for pid, _, c in targets}
        for peer_id, new_circle in alive_peers:
            current = targets_map.get(peer_id)
            if current and new_circle and new_circle != current:
                logger.info(
                    "active_repair: circle recovery %s: %s → %s",
                    peer_id, current, new_circle,
                )
                await self.set_peer_circle(peer_id, new_circle)

        for peer_id in dead_peer_ids:
            logger.info("active_repair: marking %s OFFLINE (no pong)", peer_id)
            await self.update_peer_status(peer_id, PeerStatus.OFFLINE)
            if self._query_tracker:
                await self._query_tracker.cancel_queries_to_peer(peer_id)

        await self._evict_stale_peers()
