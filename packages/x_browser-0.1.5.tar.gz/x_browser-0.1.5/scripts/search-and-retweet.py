"""Search for a query on X and retweet results in-place (no page navigation).

Usage:
    python scripts/search-and-retweet.py "AI agents" --hours 3
    python scripts/search-and-retweet.py "YC W26" --hours 5 --min-delay 30 --max-delay 120
"""

from __future__ import annotations

import argparse
import asyncio
import re
import sys
import time

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import retweet_in_place


async def _extract_articles_with_data(page) -> list[tuple[object, dict]]:
    results = []
    articles = await page.query_selector_all('article[data-testid="tweet"]')
    for article in articles:
        try:
            time_el = await article.query_selector("time")
            if not time_el:
                continue
            parent_a = await time_el.evaluate_handle("el => el.closest('a')")
            if not parent_a:
                continue
            href = await parent_a.get_attribute("href")
            if not href or "/status/" not in href:
                continue
            match = re.search(r"/status/(\d+)", href)
            if not match:
                continue

            tweet_id = match.group(1)
            author = ""
            user_link = await article.query_selector('div[data-testid="User-Name"] a')
            if user_link:
                user_href = await user_link.get_attribute("href") or ""
                author = user_href.strip("/").split("/")[0]
            text = ""
            text_el = await article.query_selector('div[data-testid="tweetText"]')
            if text_el:
                text = (await text_el.inner_text()).strip()

            results.append((article, {"id": tweet_id, "author": author, "text": text}))
        except Exception:
            continue
    return results


async def main():
    parser = argparse.ArgumentParser(description="Search & retweet posts on X (in-place)")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--hours", type=float, default=3, help="How long to run (default: 3)")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between retweets")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between retweets")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    args = parser.parse_args()

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    deadline = time.monotonic() + (args.hours * 3600)
    processed_ids: set[str] = set()
    total = 0
    dry_streak = 0

    print(f"\U0001f50d Searching for: {args.query}", file=sys.stderr)
    print(f"\u23f1\ufe0f  Running for {args.hours} hours", file=sys.stderr)
    print("\u2500" * 50, file=sys.stderr)

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page
        encoded = args.query.replace(" ", "%20")
        await page.goto(
            f"https://x.com/search?q={encoded}&src=typed_query&f=live",
            wait_until="domcontentloaded",
        )
        await page.wait_for_timeout(4000)

        while time.monotonic() < deadline:
            items = await _extract_articles_with_data(page)
            new_items = [(a, d) for a, d in items if d["id"] not in processed_ids]

            if not new_items:
                dry_streak += 1
                if dry_streak >= 15:
                    print(f"\n\U0001f504 Reloading search...", file=sys.stderr)
                    await page.goto(
                        f"https://x.com/search?q={encoded}&src=typed_query&f=live",
                        wait_until="domcontentloaded",
                    )
                    await page.wait_for_timeout(4000)
                    dry_streak = 0
                    continue
                await page.evaluate("window.scrollBy(0, 800)")
                await page.wait_for_timeout(2000)
                continue

            dry_streak = 0
            for article, data in new_items:
                if time.monotonic() >= deadline:
                    break
                text_preview = (data["text"][:60] + "...") if len(data["text"]) > 60 else data["text"]

                result = await retweet_in_place(page, article, config=config)
                processed_ids.add(data["id"])

                if result.get("already_retweeted"):
                    print(f"\u2705 Already retweeted @{data['author']}: {text_preview}", file=sys.stderr)
                elif result.get("retweeted"):
                    total += 1
                    print(f"\U0001f501 [{total}] Retweeted @{data['author']}: {text_preview}", file=sys.stderr)
                elif result.get("error"):
                    print(f"\u274c @{data['author']}: {result['error']}", file=sys.stderr)

            await page.evaluate("window.scrollBy(0, 800)")
            await page.wait_for_timeout(2000)

    print(f"\n\u2705 Done! Retweeted {total} tweets.", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
