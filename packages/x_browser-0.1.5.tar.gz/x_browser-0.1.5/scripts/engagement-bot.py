"""Full engagement bot: search → like + retweet in-place + follow author (navigates).

Usage:
    python scripts/engagement-bot.py "AI startups" --hours 5
    python scripts/engagement-bot.py "YC W26" --hours 8 --skip-follow --min-delay 10 --max-delay 60
"""

from __future__ import annotations

import argparse
import asyncio
import re
import sys
import time

sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent / "src"))

from x_browser.browser import XBrowser
from x_browser.config import Config
from x_browser.actions import like_in_place, retweet_in_place, follow


async def _extract_articles_with_data(page) -> list[tuple[object, dict]]:
    results = []
    articles = await page.query_selector_all('article[data-testid="tweet"]')
    for article in articles:
        try:
            time_el = await article.query_selector("time")
            if not time_el:
                continue
            parent_a = await time_el.evaluate_handle("el => el.closest('a')")
            if not parent_a:
                continue
            href = await parent_a.get_attribute("href")
            if not href or "/status/" not in href:
                continue
            match = re.search(r"/status/(\d+)", href)
            if not match:
                continue

            tweet_id = match.group(1)
            author = ""
            user_link = await article.query_selector('div[data-testid="User-Name"] a')
            if user_link:
                user_href = await user_link.get_attribute("href") or ""
                author = user_href.strip("/").split("/")[0]
            text = ""
            text_el = await article.query_selector('div[data-testid="tweetText"]')
            if text_el:
                text = (await text_el.inner_text()).strip()

            results.append((article, {"id": tweet_id, "author": author, "text": text}))
        except Exception:
            continue
    return results


async def main():
    parser = argparse.ArgumentParser(description="Engagement bot: like + retweet + follow")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--hours", type=float, default=5, help="How long to run (default: 5)")
    parser.add_argument("--skip-like", action="store_true", help="Skip liking")
    parser.add_argument("--skip-retweet", action="store_true", help="Skip retweeting")
    parser.add_argument("--skip-follow", action="store_true", help="Skip following authors")
    parser.add_argument("--min-delay", type=float, default=None, help="Min delay between actions")
    parser.add_argument("--max-delay", type=float, default=None, help="Max delay between actions")
    parser.add_argument("--headed", action="store_true", help="Show browser window")
    args = parser.parse_args()

    config = Config.load()
    if args.min_delay is not None:
        config.min_politeness_delay = args.min_delay
    if args.max_delay is not None:
        config.max_politeness_delay = args.max_delay

    do_like = not args.skip_like
    do_retweet = not args.skip_retweet
    do_follow = not args.skip_follow

    if not do_like and not do_retweet and not do_follow:
        print("\u274c All actions skipped. Nothing to do.", file=sys.stderr)
        return

    deadline = time.monotonic() + (args.hours * 3600)
    processed_ids: set[str] = set()
    followed_authors: set[str] = set()
    stats = {"liked": 0, "retweeted": 0, "followed": 0}
    dry_streak = 0
    search_url = ""

    actions_desc = ", ".join(
        [a for a, f in [("like", do_like), ("retweet", do_retweet), ("follow", do_follow)] if f]
    )
    print(f"\U0001f916 Engagement bot for: {args.query}", file=sys.stderr)
    print(f"\u23f1\ufe0f  Running for {args.hours} hours", file=sys.stderr)
    print(f"\U0001f3af Actions: {actions_desc}", file=sys.stderr)
    print("\u2500" * 50, file=sys.stderr)

    async with XBrowser(headless=not args.headed) as xb:
        page = xb.page
        encoded = args.query.replace(" ", "%20")
        search_url = f"https://x.com/search?q={encoded}&src=typed_query&f=live"
        await page.goto(search_url, wait_until="domcontentloaded")
        await page.wait_for_timeout(4000)

        while time.monotonic() < deadline:
            items = await _extract_articles_with_data(page)
            new_items = [(a, d) for a, d in items if d["id"] not in processed_ids]

            if not new_items:
                dry_streak += 1
                if dry_streak >= 15:
                    print(f"\n\U0001f504 Reloading search...", file=sys.stderr)
                    await page.goto(search_url, wait_until="domcontentloaded")
                    await page.wait_for_timeout(4000)
                    dry_streak = 0
                    continue
                await page.evaluate("window.scrollBy(0, 800)")
                await page.wait_for_timeout(2000)
                continue

            dry_streak = 0

            # Collect follow targets from this batch (done after in-place actions)
            follow_targets: list[str] = []

            for article, data in new_items:
                if time.monotonic() >= deadline:
                    break

                text_preview = (data["text"][:50] + "...") if len(data["text"]) > 50 else data["text"]
                total = stats["liked"] + stats["retweeted"] + stats["followed"]
                print(f"\n\U0001f4cc [{total}] @{data['author']}: {text_preview}", file=sys.stderr)

                # Like (in-place)
                if do_like:
                    result = await like_in_place(page, article, config=config)
                    if result.get("already_liked"):
                        print(f"   \u2705 Already liked", file=sys.stderr)
                    elif result.get("liked"):
                        stats["liked"] += 1
                        print(f"   \u2764\ufe0f  Liked", file=sys.stderr)
                    elif result.get("error"):
                        print(f"   \u274c Like: {result['error']}", file=sys.stderr)

                # Retweet (in-place)
                if do_retweet:
                    result = await retweet_in_place(page, article, config=config)
                    if result.get("already_retweeted"):
                        print(f"   \u2705 Already retweeted", file=sys.stderr)
                    elif result.get("retweeted"):
                        stats["retweeted"] += 1
                        print(f"   \U0001f501 Retweeted", file=sys.stderr)
                    elif result.get("error"):
                        print(f"   \u274c Retweet: {result['error']}", file=sys.stderr)

                # Collect follow target (will navigate later, after in-place batch)
                if do_follow and data["author"] and data["author"] not in followed_authors:
                    follow_targets.append(data["author"])

                processed_ids.add(data["id"])

            # Follow authors (requires navigation — do all at once after in-place batch)
            for author in follow_targets:
                if time.monotonic() >= deadline:
                    break
                try:
                    result = await follow(page, author, config=config)
                    followed_authors.add(author)
                    if result.get("followed"):
                        stats["followed"] += 1
                        print(f"   \U0001f464 Followed @{author}", file=sys.stderr)
                    else:
                        print(f"   \u2714\ufe0f  Already following @{author}", file=sys.stderr)
                except Exception as e:
                    print(f"   \u274c Follow @{author}: {e}", file=sys.stderr)
                    followed_authors.add(author)

            # If we navigated for follows, go back to search
            if follow_targets:
                await page.goto(search_url, wait_until="domcontentloaded")
                await page.wait_for_timeout(3000)
                # Scroll past already-seen tweets
                for _ in range(min(len(processed_ids) // 3, 20)):
                    await page.evaluate("window.scrollBy(0, 800)")
                    await page.wait_for_timeout(400)

            await page.evaluate("window.scrollBy(0, 800)")
            await page.wait_for_timeout(2000)

    print(f"\n\u2500" * 50, file=sys.stderr)
    print(f"\u2705 Done!", file=sys.stderr)
    print(f"   \u2764\ufe0f  Liked: {stats['liked']}", file=sys.stderr)
    print(f"   \U0001f501 Retweeted: {stats['retweeted']}", file=sys.stderr)
    print(f"   \U0001f464 Followed: {stats['followed']}", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
