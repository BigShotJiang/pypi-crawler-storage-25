"""Write actions for X: post, like, retweet, reply, quote, delete, bookmark.

Every action calls politeness_wait() before executing.
"""

from __future__ import annotations

import re
import sys
from typing import Optional

from playwright.async_api import Page

from .config import Config


def _normalize_tweet_url(id_or_url: str) -> str:
    """Turn a tweet ID or URL into a canonical x.com URL."""
    id_or_url = id_or_url.strip()
    # Already a URL
    if id_or_url.startswith("http"):
        return id_or_url.split("?")[0]  # strip query params
    # Bare numeric ID — we need a placeholder username, but X redirects anyway
    if id_or_url.isdigit():
        return f"https://x.com/i/status/{id_or_url}"
    return id_or_url


async def _goto_tweet(page: Page, id_or_url: str) -> None:
    """Navigate to a tweet page and wait for it to load."""
    url = _normalize_tweet_url(id_or_url)
    await page.goto(url, wait_until="domcontentloaded")
    # Wait for the tweet article to appear
    await page.wait_for_selector('article[data-testid="tweet"]', timeout=15_000)


# ---------------------------------------------------------------------------
# Post a tweet
# ---------------------------------------------------------------------------

async def tweet_post(
    page: Page,
    text: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
    poll_options: list[str] | None = None,
    poll_duration: int = 1440,
) -> dict:
    """Compose and post a new tweet.

    Returns {"ok": True, "text": <posted text>} on success.
    """
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    await page.goto("https://x.com/compose/post", wait_until="domcontentloaded")
    # Wait for the compose box
    editor = await page.wait_for_selector(
        'div[data-testid="tweetTextarea_0"]', timeout=10_000
    )
    await editor.click()
    await page.keyboard.type(text, delay=30)

    # Optional: add poll
    if poll_options and len(poll_options) >= 2:
        # Click the poll icon
        poll_btn = await page.wait_for_selector(
            'button[data-testid="pollButton"]', timeout=5_000
        )
        await poll_btn.click()
        await page.wait_for_timeout(500)
        # Fill poll options
        poll_inputs = await page.query_selector_all('input[placeholder*="Choice"]')
        for i, opt in enumerate(poll_options[:4]):  # max 4 options
            if i < len(poll_inputs):
                await poll_inputs[i].fill(opt)
            elif i >= 2:
                # Click "Add" to add more options (3rd, 4th)
                add_btn = await page.query_selector('button[data-testid="addPollOptionButton"]')
                if add_btn:
                    await add_btn.click()
                    await page.wait_for_timeout(300)
                    poll_inputs = await page.query_selector_all('input[placeholder*="Choice"]')
                    if i < len(poll_inputs):
                        await poll_inputs[i].fill(opt)

    # Click Post button
    post_btn = await page.wait_for_selector(
        'button[data-testid="tweetButton"]', timeout=5_000
    )
    await post_btn.click()

    # Wait for navigation or confirmation
    await page.wait_for_timeout(3000)

    return {"ok": True, "text": text}


# ---------------------------------------------------------------------------
# Delete a tweet
# ---------------------------------------------------------------------------

async def tweet_delete(
    page: Page,
    id_or_url: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Delete a tweet you own."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    await _goto_tweet(page, id_or_url)

    # Click the "..." (more) menu on the tweet
    more_btn = await page.wait_for_selector(
        'article[data-testid="tweet"] button[data-testid="caret"]', timeout=5_000
    )
    await more_btn.click()
    await page.wait_for_timeout(500)

    # Click "Delete"
    delete_item = await page.wait_for_selector(
        'div[data-testid="Dropdown"] [role="menuitem"]:has-text("Delete")',
        timeout=5_000,
    )
    await delete_item.click()
    await page.wait_for_timeout(500)

    # Confirm deletion
    confirm_btn = await page.wait_for_selector(
        'button[data-testid="confirmationSheetConfirm"]', timeout=5_000
    )
    await confirm_btn.click()
    await page.wait_for_timeout(2000)

    return {"ok": True, "deleted": id_or_url}


# ---------------------------------------------------------------------------
# Reply to a tweet
# ---------------------------------------------------------------------------

async def tweet_reply(
    page: Page,
    id_or_url: str,
    text: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Reply to a tweet."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    await _goto_tweet(page, id_or_url)

    # Click the reply button on the tweet
    reply_btn = await page.wait_for_selector(
        'article[data-testid="tweet"] button[data-testid="reply"]', timeout=5_000
    )
    await reply_btn.click()
    await page.wait_for_timeout(1000)

    # Type in the reply compose box
    editor = await page.wait_for_selector(
        'div[data-testid="tweetTextarea_0"]', timeout=5_000
    )
    await editor.click()
    await page.keyboard.type(text, delay=30)

    # Click Reply/Post button
    post_btn = await page.wait_for_selector(
        'button[data-testid="tweetButton"]', timeout=5_000
    )
    await post_btn.click()
    await page.wait_for_timeout(3000)

    return {"ok": True, "replied_to": id_or_url, "text": text}


# ---------------------------------------------------------------------------
# Quote tweet
# ---------------------------------------------------------------------------

async def tweet_quote(
    page: Page,
    id_or_url: str,
    text: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Quote a tweet with your own commentary."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    await _goto_tweet(page, id_or_url)

    # Click the retweet/repost button
    repost_btn = await page.wait_for_selector(
        'article[data-testid="tweet"] button[data-testid="retweet"]', timeout=5_000
    )
    await repost_btn.click()
    await page.wait_for_timeout(500)

    # Click "Quote" from the dropdown
    quote_item = await page.wait_for_selector(
        '[role="menuitem"]:has-text("Quote")', timeout=5_000
    )
    await quote_item.click()
    await page.wait_for_timeout(1000)

    # Type in the quote compose box
    editor = await page.wait_for_selector(
        'div[data-testid="tweetTextarea_0"]', timeout=5_000
    )
    await editor.click()
    await page.keyboard.type(text, delay=30)

    # Click Post button
    post_btn = await page.wait_for_selector(
        'button[data-testid="tweetButton"]', timeout=5_000
    )
    await post_btn.click()
    await page.wait_for_timeout(3000)

    return {"ok": True, "quoted": id_or_url, "text": text}


# ---------------------------------------------------------------------------
# Like a tweet
# ---------------------------------------------------------------------------

async def like(
    page: Page,
    id_or_url: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Like a tweet. Skips if already liked."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    await _goto_tweet(page, id_or_url)

    # Check if already liked (button testid is "unlike" when liked)
    already_liked = await page.query_selector(
        'article[data-testid="tweet"] button[data-testid="unlike"]'
    )
    if already_liked:
        return {"ok": True, "already_liked": id_or_url}

    like_btn = await page.wait_for_selector(
        'article[data-testid="tweet"] button[data-testid="like"]', timeout=5_000
    )
    await like_btn.click()
    await page.wait_for_timeout(1000)

    return {"ok": True, "liked": id_or_url}


# ---------------------------------------------------------------------------
# Retweet
# ---------------------------------------------------------------------------

async def retweet(
    page: Page,
    id_or_url: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Retweet (repost) a tweet. Skips if already retweeted."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    await _goto_tweet(page, id_or_url)

    # Check if already retweeted (button testid is "unretweet" when retweeted)
    already_retweeted = await page.query_selector(
        'article[data-testid="tweet"] button[data-testid="unretweet"]'
    )
    if already_retweeted:
        return {"ok": True, "already_retweeted": id_or_url}

    repost_btn = await page.wait_for_selector(
        'article[data-testid="tweet"] button[data-testid="retweet"]', timeout=5_000
    )
    await repost_btn.click()
    await page.wait_for_timeout(500)

    # Click "Repost" from the dropdown
    repost_item = await page.wait_for_selector(
        '[role="menuitem"]:has-text("Repost")', timeout=5_000
    )
    await repost_item.click()
    await page.wait_for_timeout(2000)

    return {"ok": True, "retweeted": id_or_url}


# ---------------------------------------------------------------------------
# Bookmark / Unbookmark
# ---------------------------------------------------------------------------

async def bookmark(
    page: Page,
    id_or_url: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Bookmark a tweet. Skips if already bookmarked."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    await _goto_tweet(page, id_or_url)

    # Check if already bookmarked
    already_bookmarked = await page.query_selector(
        'article[data-testid="tweet"] button[data-testid="removeBookmark"]'
    )
    if already_bookmarked:
        return {"ok": True, "already_bookmarked": id_or_url}

    bookmark_btn = await page.wait_for_selector(
        'article[data-testid="tweet"] button[data-testid="bookmark"]', timeout=5_000
    )
    await bookmark_btn.click()
    await page.wait_for_timeout(1000)

    return {"ok": True, "bookmarked": id_or_url}


async def unbookmark(
    page: Page,
    id_or_url: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Remove bookmark from a tweet."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    await _goto_tweet(page, id_or_url)

    # If already bookmarked, the testid is "removeBookmark"
    unbookmark_btn = await page.wait_for_selector(
        'article[data-testid="tweet"] button[data-testid="removeBookmark"]',
        timeout=5_000,
    )
    await unbookmark_btn.click()
    await page.wait_for_timeout(1000)

    return {"ok": True, "unbookmarked": id_or_url}


# ---------------------------------------------------------------------------
# Follow a user
# ---------------------------------------------------------------------------

async def follow(
    page: Page,
    username: str,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Follow a user by username."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    username = username.lstrip("@").strip()
    await page.goto(f"https://x.com/{username}", wait_until="domcontentloaded")
    await page.wait_for_timeout(2000)

    # Look for the Follow button (not Following — that means already followed)
    follow_btn = await page.query_selector(
        f'button[data-testid="{username}-follow"]'
    )
    if not follow_btn:
        # Try generic follow button
        follow_btn = await page.query_selector(
            'div[data-testid="placementTracking"] button:not([data-testid*="unfollow"])'
        )

    if follow_btn:
        label = (await follow_btn.inner_text()).strip()
        if label == "Follow":
            await follow_btn.click()
            await page.wait_for_timeout(1500)
            return {"ok": True, "followed": username}
        else:
            return {"ok": True, "already_following": username}
    else:
        return {"ok": False, "error": f"Could not find follow button for @{username}"}


# ===========================================================================
# In-place actions — click buttons on article elements without navigating.
# Use these in scripts that loop through search results to avoid page loads.
# ===========================================================================

async def like_in_place(
    page: Page,
    article,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Like a tweet by clicking the heart on an article element (no navigation)."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    try:
        already = await article.query_selector('button[data-testid="unlike"]')
        if already:
            return {"ok": True, "already_liked": True}

        btn = await article.query_selector('button[data-testid="like"]')
        if btn:
            await btn.click()
            await page.wait_for_timeout(800)
            return {"ok": True, "liked": True}
        return {"ok": False, "error": "like button not found"}
    except Exception as e:
        return {"ok": False, "error": f"stale element: {e}"}


async def retweet_in_place(
    page: Page,
    article,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Retweet by clicking the repost button on an article element (no navigation)."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    try:
        already = await article.query_selector('button[data-testid="unretweet"]')
        if already:
            return {"ok": True, "already_retweeted": True}

        btn = await article.query_selector('button[data-testid="retweet"]')
        if btn:
            await btn.click()
            await page.wait_for_timeout(500)
            # Click "Repost" from the dropdown menu (global)
            repost_item = await page.wait_for_selector(
                '[role="menuitem"]:has-text("Repost")', timeout=3_000
            )
            await repost_item.click()
            await page.wait_for_timeout(1000)
            return {"ok": True, "retweeted": True}
        return {"ok": False, "error": "retweet button not found"}
    except Exception as e:
        return {"ok": False, "error": f"stale element: {e}"}


async def bookmark_in_place(
    page: Page,
    article,
    *,
    config: Config | None = None,
    min_delay: float | None = None,
    max_delay: float | None = None,
) -> dict:
    """Bookmark by clicking the bookmark icon on an article element (no navigation)."""
    cfg = config or Config.load()
    await cfg.politeness_wait(min_delay=min_delay, max_delay=max_delay)

    try:
        already = await article.query_selector('button[data-testid="removeBookmark"]')
        if already:
            return {"ok": True, "already_bookmarked": True}

        btn = await article.query_selector('button[data-testid="bookmark"]')
        if btn:
            await btn.click()
            await page.wait_for_timeout(800)
            return {"ok": True, "bookmarked": True}
        return {"ok": False, "error": "bookmark button not found"}
    except Exception as e:
        return {"ok": False, "error": f"stale element: {e}"}
