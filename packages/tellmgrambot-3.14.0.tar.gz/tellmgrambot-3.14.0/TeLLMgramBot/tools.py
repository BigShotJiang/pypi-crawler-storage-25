"""
Webhook and MCP tool registry and executors for TeLLMgramBot.

Provides build_tool_registry() for startup parsing of bot config 'tools:' webhook
entries, discover_mcp_tools() for async MCP server discovery, execute_webhook() for
dispatching webhook tool calls, and execute_mcp() for MCP tool calls at runtime.
"""
import ipaddress
import json
import logging
import os
import re
import socket
from urllib.parse import parse_qs, quote, urlparse, urlunparse

import httpx

logger = logging.getLogger(__name__)

_RESPONSE_LOG_LIMIT = 200
_RESPONSE_BODY_LIMIT = 4000
_ENV_VAR_PATTERN = re.compile(r'\$([A-Z_][A-Z0-9_]*)')
_PLACEHOLDER_PATTERN = re.compile(r'\{(\w+)\}')


def _safe_log_url(url: str) -> str:
    """Return the URL with userinfo (user:pass@) stripped for safe logging."""
    p = urlparse(url)
    netloc = p.hostname or ''
    if p.port:
        netloc += f':{p.port}'
    return urlunparse(p._replace(netloc=netloc))


def _expand_env_vars(value: str) -> tuple:
    """
    Expand $UPPER_CASE_VAR references in a header value string.

    Returns a two-tuple (expanded_value, first_missing_var_or_None). If any
    referenced variable is not set, the first missing name is returned so the
    caller can disable the tool rather than continue with an incomplete header.
    """
    missing = None

    def _sub(m):
        nonlocal missing
        var = m.group(1)
        val = os.environ.get(var)
        if val is None and missing is None:
            missing = var
        return val or ''

    return _ENV_VAR_PATTERN.sub(_sub, value), missing


def _is_blocked_address(hostname: str) -> bool:
    """
    Return True if the hostname is, or resolves to, a loopback or link-local address.

    Raw IP literals are checked without DNS. Hostnames are resolved via
    socket.getaddrinfo; resolution failures are treated as not-blocked to avoid
    incorrectly disabling tools when DNS is temporarily unavailable.

    Only loopback (127.x.x.x, ::1) and link-local (169.254.x.x, fe80::/10) are
    blocked. Private LAN addresses (192.168.x.x, 10.x.x.x, etc.) are permitted.
    """
    try:
        addr = ipaddress.ip_address(hostname)
        return addr.is_loopback or addr.is_link_local
    except ValueError:
        pass
    try:
        for _, _, _, _, sockaddr in socket.getaddrinfo(hostname, None):
            try:
                addr = ipaddress.ip_address(sockaddr[0])
                if addr.is_loopback or addr.is_link_local:
                    return True
            except ValueError:
                continue
    except OSError:
        pass
    return False


def _extract_json_path(obj, segments: list) -> list:
    """
    Walk a dotted-path segment list through a parsed JSON object, returning all matching leaf values.

    Supports wildcard array traversal via '[*]' segments with an early-exit budget check
    to cap total extracted results. Non-empty strings and numeric scalars (int, float)
    are returned as string values; booleans, None, and empty containers return empty list.
    Mismatched path segments or missing keys return empty list (not an error).

    Args:
        obj: Parsed JSON object (typically a dict or list).
        segments: List of path segments (e.g., ['data', 'items', '[*]', 'name']).

    Returns:
        List of matched leaf values as strings, or empty list if no matches.
    """
    if not segments:
        if isinstance(obj, bool) or obj is None:
            return []
        if isinstance(obj, (str, int, float)):
            return [str(obj)] if str(obj).strip() else []
        return []
    seg = segments[0]
    rest = segments[1:]
    if seg == '[*]':
        if not isinstance(obj, list):
            return []
        results = []
        total = 0
        for item in obj:
            batch = _extract_json_path(item, rest)
            for v in batch:
                total += len(v)
                results.append(v)
                if total >= _RESPONSE_BODY_LIMIT:
                    return results
        return results
    if not isinstance(obj, dict) or seg not in obj:
        return []
    return _extract_json_path(obj[seg], rest)


def _validated_json_path(value, tool_name: str):
    """Return value if it is a non-empty string, else log a warning and return None."""
    if value is None:
        return None
    if isinstance(value, str) and value.strip():
        return value
    logger.warning(
        f"Webhook tool '{tool_name}': 'response_json_path' must be a non-empty string; ignoring."
    )
    return None


def _validated_bool(value, tool_name: str, key_name: str) -> bool:
    """Return value if it is a real bool, else log a warning and return False."""
    if isinstance(value, bool):
        return value
    if value is not None:
        logger.warning(
            f"Tool '{tool_name}': '{key_name}' must be a boolean (true/false); defaulting to false."
        )
    return False


def build_tool_registry(
    tools_config: list,
    allow_local: bool = False,
) -> tuple:
    """
    Parse raw tool config entries and build the webhook tool registry.

    Validates all required fields ('name', 'description', 'webhook') and skips
    entries missing any required field. Expands $ENV_VAR references in header
    values at startup; tools whose header values reference missing environment
    variables are excluded with a logged warning (graceful-degradation pattern).
    Non-dict entries, non-dict headers values, and non-dict parameter definitions
    are skipped with warnings. Duplicate tool names are deduplicated (first wins).
    Calls _validated_json_path() to validate response_json_path at registry build time.

    Args:
        tools_config: List of raw tool definition dicts from bot config 'tools:' key.
                      Pass an empty list or None to produce an empty registry.
        allow_local: If True, the executor permits webhook URLs targeting loopback or
                     link-local addresses. Mirrors the 'allow_local_webhooks' config key.

    Returns:
        Tuple of (schemas, defs) where:
        - schemas: list of provider-compatible tool schema dicts (same shape as _SEARCH_TOOL).
        - defs: dict mapping tool name -> resolved definition dict with expanded headers,
                optional 'response_json_path' for JSON response extraction, and 'allow_groups'
                flag for group/supergroup scope control.
    """
    schemas = []
    defs = {}

    for entry in (tools_config or []):
        if not isinstance(entry, dict):
            logger.warning("Webhook tool entry is not a dict; skipping.")
            continue
        if 'mcp_server' in entry:
            continue  # MCP entries are handled by discover_mcp_tools() at startup
        name = entry.get('name')
        if not name:
            logger.warning("Webhook tool entry missing 'name'; skipping.")
            continue

        # Expand $ENV_VAR references in header values; disable tool on first missing var
        raw_headers = entry.get('headers') or {}
        if not isinstance(raw_headers, dict):
            logger.warning(f"Webhook tool '{name}': 'headers' must be a dict; treating as empty.")
            raw_headers = {}
        expanded_headers = {}
        disabled = False
        for header_name, header_value in raw_headers.items():
            expanded, missing = _expand_env_vars(str(header_value))
            if missing:
                logger.warning(
                    f"Webhook tool '{name}': header '{header_name}' references "
                    f"missing env var ${missing}; tool disabled."
                )
                disabled = True
                break
            expanded_headers[header_name] = expanded
        if disabled:
            continue

        # Validate required fields
        webhook_url = entry.get('webhook', '')
        if not webhook_url:
            logger.warning(f"Webhook tool '{name}': missing 'webhook' URL; skipping.")
            continue
        description = entry.get('description', '')
        if not description:
            logger.warning(f"Webhook tool '{name}': missing 'description'; skipping.")
            continue

        # Duplicate name check - warn and skip to keep schemas/defs in sync
        if name in defs:
            logger.warning(f"Webhook tool '{name}': duplicate name; skipping.")
            continue

        # Build the provider-compatible schema from the parameters block
        raw_params = entry.get('parameters') or {}
        properties = {}
        required = []
        if isinstance(raw_params, dict):
            for param_name, param_def in raw_params.items():
                if not isinstance(param_def, dict):
                    logger.warning(
                        f"Webhook tool '{name}': parameter '{param_name}' definition "
                        f"is not a dict; skipping parameter."
                    )
                    continue
                prop = {'type': param_def.get('type', 'string')}
                if 'description' in param_def:
                    prop['description'] = param_def['description']
                properties[param_name] = prop
                if param_def.get('required', False):
                    required.append(param_name)

        schemas.append({
            'name': name,
            'description': description,
            'parameters': {
                'type': 'object',
                'properties': properties,
                'required': required,
            },
        })
        defs[name] = {
            'name': name,
            'webhook': webhook_url,
            'method': str(entry.get('method', 'POST')).upper(),
            'headers': expanded_headers,
            'normalize_args': entry.get('normalize_args'),
            'response_json_path': _validated_json_path(entry.get('response_json_path'), name),
            'allow_groups': _validated_bool(entry.get('allow_groups'), name, 'allow_groups'),
            'allow_local': allow_local,
        }

    return schemas, defs


async def discover_mcp_tools(
    mcp_entries: list,
    existing_names: set,
    allow_local: bool = False,
) -> tuple:
    """
    Discover tools from MCP server(s) and return them ready to merge into the registry.

    For each entry with an 'mcp_server:' key, sends a JSON-RPC 2.0 tools/list request
    to the server base URL, translates MCP inputSchema to provider-compatible parameters,
    and returns (schemas, defs) for the discovered tools. Passes allow_groups through to
    MCP tool defs.

    Headers support $ENV_VAR expansion. Missing env vars disable the MCP source with a
    warning. Discovery failures (non-2xx, timeout, network error) log a warning and
    continue -- graceful degradation, matching the pattern for missing env vars in webhooks.

    An 'include:' list on an entry restricts which discovered tools are registered; omitting
    it registers all tools. Name collisions with existing_names (or with each other across
    MCP sources) are skipped with a warning; first-registered wins.

    SSRF guard applies to the discovery call: loopback and link-local addresses are blocked
    unless allow_local is True.

    Args:
        mcp_entries: List of MCP entry dicts (each has 'mcp_server' key).
        existing_names: Set of already-registered tool names to check collisions against
                        (should include webhook tool names and 'search_messages').
        allow_local: If True, permits MCP server URLs targeting loopback or link-local addresses.

    Returns:
        Tuple of (schemas, defs) for newly discovered MCP tools.
    """
    schemas = []
    defs = {}
    all_registered = set(existing_names)

    for entry in (mcp_entries or []):
        if not isinstance(entry, dict):
            continue
        server_url = entry.get('mcp_server', '').rstrip('/')
        if not server_url:
            logger.warning("MCP entry missing 'mcp_server' URL; skipping.")
            continue

        parsed = urlparse(server_url)
        log_url = _safe_log_url(server_url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname:
            logger.warning(f"MCP server '{log_url}': invalid URL scheme; skipping.")
            continue
        if parsed.query or parsed.fragment:
            logger.warning(
                f"MCP server '{log_url}': URL must not contain a query string or fragment; skipping."
            )
            continue
        if not allow_local and _is_blocked_address(parsed.hostname):
            logger.warning(
                f"MCP server '{log_url}': SSRF block - loopback or link-local address "
                f"not permitted; set allow_local_webhooks: true to allow."
            )
            continue

        raw_headers = entry.get('headers') or {}
        if not isinstance(raw_headers, dict):
            logger.warning(f"MCP server '{server_url}': 'headers' must be a dict; treating as empty.")
            raw_headers = {}
        expanded_headers = {}
        disabled = False
        for header_name, header_value in raw_headers.items():
            expanded, missing = _expand_env_vars(str(header_value))
            if missing:
                logger.warning(
                    f"MCP server '{log_url}': header '{header_name}' references "
                    f"missing env var ${missing}; source disabled."
                )
                disabled = True
                break
            expanded_headers[header_name] = expanded
        if disabled:
            continue

        include_set = None
        if 'include' in entry:
            include_filter = entry.get('include')
            if not isinstance(include_filter, list) or not all(
                isinstance(tool_name, str) for tool_name in include_filter
            ):
                logger.warning(
                    f"MCP server '{log_url}': 'include' must be a list of strings; source disabled."
                )
                continue
            include_set = set(include_filter)

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(
                    server_url,
                    json={"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
                    headers=expanded_headers,
                )
            if not (200 <= resp.status_code < 300):
                logger.warning(
                    f"MCP server '{log_url}': tools/list returned HTTP {resp.status_code}; skipping source."
                )
                continue
            resp_data = resp.json()
            if resp_data.get('error'):
                err = resp_data['error']
                err_summary = f"code={err.get('code')} {err.get('message', '')}" if isinstance(err, dict) else str(err)[:100]
                logger.warning(f"MCP server '{log_url}': tools/list error {err_summary}; skipping source.")
                continue
            tools_data = resp_data.get('result', {}).get('tools', [])
        except httpx.TimeoutException:
            logger.warning(f"MCP server '{log_url}': tools/list timed out; skipping source.")
            continue
        except httpx.RequestError as e:
            logger.warning(f"MCP server '{log_url}': tools/list failed ({type(e).__name__}); skipping source.")
            continue
        except Exception as e:
            logger.warning(f"MCP server '{log_url}': tools/list error ({type(e).__name__}); skipping source.")
            continue

        server_count = 0
        for tool in tools_data:
            if not isinstance(tool, dict):
                continue
            tool_name = tool.get('name')
            if not tool_name:
                logger.warning(f"MCP server '{log_url}': tool entry missing 'name'; skipping.")
                continue
            if include_set is not None and tool_name not in include_set:
                continue
            if tool_name in all_registered:
                logger.warning(
                    f"MCP server '{log_url}': tool '{tool_name}' collides with existing "
                    f"registration; skipping."
                )
                continue

            input_schema = tool.get('inputSchema')
            if isinstance(input_schema, dict):
                parameters = input_schema
            else:
                if input_schema is not None:
                    logger.warning(
                        f"MCP tool '{tool_name}': 'inputSchema' is malformed; "
                        f"registering with empty parameters."
                    )
                parameters = {'type': 'object', 'properties': {}, 'required': []}

            schemas.append({
                'name': tool_name,
                'description': tool.get('description', ''),
                'parameters': parameters,
            })
            defs[tool_name] = {
                'name': tool_name,
                '_mcp_server': server_url,
                'headers': expanded_headers,
                'allow_groups': _validated_bool(entry.get('allow_groups'), tool_name, 'allow_groups'),
                'allow_local': allow_local,
            }
            all_registered.add(tool_name)
            server_count += 1

        logger.info(f"MCP server '{server_url}': registered {server_count} tool(s).")

    return schemas, defs


async def execute_mcp(tool_def: dict, arguments: dict) -> str:
    """
    Execute an MCP tool call and return a framed result string for LLM injection.

    Sends a JSON-RPC 2.0 tools/call request to the server base URL, parses the MCP
    content array from the result field, and frames the result for LLM injection.

    Applies the same SSRF guard as execute_webhook(). Request headers are never
    logged at any level. Response bodies are logged at DEBUG only, truncated to 200
    characters. LLM-facing response is truncated to 4000 characters.

    Args:
        tool_def: Resolved MCP tool definition dict (contains '_mcp_server', 'headers',
                  'allow_local' keys set by discover_mcp_tools).
        arguments: Arguments dict from the LLM ToolCall.

    Returns:
        '[Tool result from <name>]:\\n<body>' on success (2xx), or a descriptive
        '[Tool error: ...]' string on failure (non-2xx, timeout, network error,
        SSRF block). Never raises.
    """
    name = tool_def['name']
    server_url = tool_def['_mcp_server']
    headers = tool_def['headers']
    allow_local = tool_def.get('allow_local', False)

    parsed = urlparse(server_url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        return f"[Tool error: '{name}' MCP server has an invalid or unsupported URL]"
    if not allow_local and _is_blocked_address(parsed.hostname):
        logger.warning(f"MCP '{name}': SSRF block - '{parsed.hostname}' is loopback or link-local")
        return (
            f"[Tool error: '{name}' targets a loopback or link-local address. "
            f"Set allow_local_webhooks: true in bot config to permit local addresses.]"
        )

    log_url = _safe_log_url(server_url)
    logger.info(f"MCP '{name}': POST {log_url}")

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.post(
                server_url,
                json={"jsonrpc": "2.0", "id": 1, "method": "tools/call",
                      "params": {"name": name, "arguments": arguments}},
                headers=headers,
            )

        if not (200 <= resp.status_code < 300):
            logger.warning(f"MCP '{name}': status {resp.status_code}")
            return f"[Tool error: '{name}' returned HTTP {resp.status_code}]"

        logger.info(f"MCP '{name}': status {resp.status_code}")
        logger.debug(f"MCP '{name}' response: {resp.text[:_RESPONSE_LOG_LIMIT]}")

        try:
            data = resp.json()
            if data.get('error'):
                err = data['error']
                err_summary = f"code={err.get('code')} {err.get('message', '')}" if isinstance(err, dict) else str(err)[:100]
                logger.warning(f"MCP '{name}': JSON-RPC error {err_summary}")
                return f"[Tool error: '{name}' returned error: {err.get('message', err)}]"
            content_items = data.get('result', {}).get('content', [])
            body = '\n'.join(
                item.get('text', '') for item in content_items
                if isinstance(item, dict) and item.get('type') == 'text'
            )
            if not body:
                body = resp.text
        except Exception:
            body = resp.text

        if len(body) > _RESPONSE_BODY_LIMIT:
            body = body[:_RESPONSE_BODY_LIMIT] + f"\n[Response truncated at {_RESPONSE_BODY_LIMIT} characters]"
        return f"[Tool result from {name}]:\n{body}"

    except httpx.TimeoutException:
        logger.warning(f"MCP '{name}': request timed out")
        return f"[Tool error: '{name}' timed out]"
    except httpx.RequestError as e:
        logger.warning(f"MCP '{name}': {type(e).__name__}")
        return f"[Tool error: '{name}' request failed ({type(e).__name__})]"


async def execute_webhook(tool_def: dict, arguments: dict) -> str:
    """
    Execute a webhook tool call and return a framed result string for LLM injection.

    Applies argument normalization, URL template substitution ({param} -> value),
    and SSRF protection before firing the HTTP request. On 2xx response, if
    'response_json_path' is set in tool_def and is a valid string, parses the response
    as JSON and extracts values at the dotted path (supporting [*] array wildcards);
    falls back to raw response on invalid JSON or no path matches with a WARNING logged.
    The response body is wrapped with a '[Tool result from <name>]:' framing line
    so the LLM can distinguish tool output from user instructions (prompt injection
    guard).

    Request headers are never logged at any level. Response bodies are logged at
    DEBUG only, truncated to 200 characters. Only tool name, HTTP method, base URL
    (no query string), and status code are logged at INFO. The response body sent
    to the LLM is truncated to 4000 characters to prevent overwhelming the context.

    Args:
        tool_def: Resolved tool definition dict from build_tool_registry defs
                  (may contain 'response_json_path' for JSON extraction).
        arguments: Arguments dict from the LLM ToolCall.

    Returns:
        '[Tool result from <name>]:\n<body>' on success (2xx), or a descriptive
        '[Tool error: ...]' string on failure (non-2xx, timeout, network error,
        missing placeholder, SSRF block). Never raises.
    """
    name = tool_def['name']
    url_template = tool_def['webhook']
    method = tool_def['method']
    headers = tool_def['headers']
    normalize = tool_def.get('normalize_args')
    allow_local = tool_def.get('allow_local', False)

    args = dict(arguments)

    # Normalize string arguments if requested (e.g. for case-sensitive resource IDs)
    if normalize == 'lowercase':
        args = {k: v.lower() if isinstance(v, str) else v for k, v in args.items()}

    # Substitute {param} placeholders; remove them so they are not also sent in body/query
    url = url_template
    substituted = set()
    for placeholder in _PLACEHOLDER_PATTERN.findall(url_template):
        if placeholder not in args:
            return f"[Tool error: required URL parameter '{placeholder}' was not provided]"
        url = url.replace(f'{{{placeholder}}}', quote(str(args[placeholder]), safe=''))
        substituted.add(placeholder)
    for p in substituted:
        args.pop(p, None)

    # SSRF protection: block loopback and link-local unless explicitly allowed
    parsed = urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.hostname:
        return f"[Tool error: '{name}' has an invalid or unsupported webhook URL]"
    hostname = parsed.hostname
    if not allow_local and _is_blocked_address(hostname):
        logger.warning(f"Webhook '{name}': SSRF block - '{hostname}' is loopback or link-local")
        return (
            f"[Tool error: '{name}' targets a loopback or link-local address. "
            f"Set allow_local_webhooks: true in bot config to permit local addresses.]"
        )

    host_part = f"{parsed.hostname}:{parsed.port}" if parsed.port else parsed.hostname
    base_url = f"{parsed.scheme}://{host_part}{parsed.path}"
    logger.info(f"Webhook '{name}': {method} {base_url}")

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            if method == 'GET':
                # Merge any static query params already in the URL (e.g. ?appid=KEY) with runtime args -
                # httpx replaces the query string when 'params=' is passed separately, dropping static ones.
                url_params = {k: v[0] for k, v in parse_qs(parsed.query).items()}
                merged = {**url_params, **args}
                resp = await client.get(base_url, params=merged if merged else None, headers=headers)
            else:
                resp = await client.request(method, url, json=args if args else None, headers=headers)

        if not (200 <= resp.status_code < 300):
            logger.warning(f"Webhook '{name}': status {resp.status_code}")
            return f"[Tool error: '{name}' returned HTTP {resp.status_code}]"

        logger.info(f"Webhook '{name}': status {resp.status_code}")
        logger.debug(f"Webhook '{name}' response: {resp.text[:_RESPONSE_LOG_LIMIT]}")

        body = resp.text
        json_path = tool_def.get('response_json_path')
        if json_path and isinstance(json_path, str):
            try:
                data = json.loads(body)
                normalized = json_path.replace('[*]', '.[*]')
                segments = [s for s in normalized.split('.') if s]
                extracted = _extract_json_path(data, segments)
                if extracted:
                    body = '\n'.join(extracted)
                else:
                    logger.warning(
                        f"Webhook '{name}': response_json_path '{json_path}' matched no values; "
                        f"using raw response"
                    )
            except Exception:
                logger.warning(
                    f"Webhook '{name}': response_json_path extraction failed; using raw response"
                )

        if len(body) > _RESPONSE_BODY_LIMIT:
            body = body[:_RESPONSE_BODY_LIMIT] + f"\n[Response truncated at {_RESPONSE_BODY_LIMIT} characters]"
        return f"[Tool result from {name}]:\n{body}"

    except httpx.TimeoutException:
        logger.warning(f"Webhook '{name}': request timed out")
        return f"[Tool error: '{name}' timed out]"
    except httpx.RequestError as e:
        logger.warning(f"Webhook '{name}': {type(e).__name__}")
        return f"[Tool error: '{name}' request failed ({type(e).__name__})]"
