# This script initializes TeLLMgramBot with useful functions
import asyncio
import logging
import os
import re
import sys
import traceback as _traceback
from dataclasses import dataclass, field
from glob import glob
from tempfile import gettempdir
from typing import Optional

from .utils import read_text, generate_file_path, read_yaml, execution_dir, generate_filename
from .database import set_db_filename, init_db, get_db_path
from .archive import run_archival

logger = logging.getLogger(__name__)
_logging_initialized = False


class _RedactedFileFormatter(logging.Formatter):
    """
    Logging formatter for file output that redacts Telegram user_id and chat_id values.
    Replaces negative 8+ digit integers (group/channel IDs) and positive 9+ digit integers
    (user/private chat IDs) with [id], leaving token counts and other short numbers intact.
    """
    _NEGATIVE_ID_PATTERN = re.compile(r'-\d{8,}')
    _POSITIVE_ID_PATTERN = re.compile(r'\b\d{9,}\b')

    def formatException(self, ei) -> str:
        """
        Formats exception info showing only frames from TeLLMgramBot source files.

        Filters out third-party library frames (httpx, httpcore, etc.) to keep log
        output focused on where the error originated in our own code. The root cause
        is already captured in the final exception message, so chained frames from
        external libraries are dropped entirely.
        """
        exc_type, exc_value, _ = ei
        if exc_value is None or exc_value.__traceback__ is None:
            return ''
        our_frames = [
            frame for frame in _traceback.extract_tb(exc_value.__traceback__)
            if 'TeLLMgramBot' in frame.filename and '.venv' not in frame.filename
        ]
        lines = ['Traceback (TeLLMgramBot frames only):']
        for frame in our_frames:
            lines.append(f'  File "{frame.filename}", line {frame.lineno}, in {frame.name}')
            if frame.line:
                lines.append(f'    {frame.line}')
        lines.append(f'{exc_type.__name__}: {exc_value}')
        return '\n'.join(lines)

    def format(self, record: logging.LogRecord) -> str:
        formatted = super().format(record)
        formatted = self._NEGATIVE_ID_PATTERN.sub('[id]', formatted)
        return self._POSITIVE_ID_PATTERN.sub('[id]', formatted)


class _ConsoleFormatter(logging.Formatter):
    """
    Logging formatter for console output that suppresses exception tracebacks.

    Makes a shallow copy of the LogRecord before clearing exception info so the
    shared LogRecord seen by the file handler is not mutated - the file handler
    still receives and renders the full traceback.
    """

    def format(self, record: logging.LogRecord) -> str:
        """
        Formats the log record for console output, suppressing exception tracebacks.

        Returns the formatted message without exception details. Full tracebacks
        are only visible in log files via _RedactedFileFormatter.
        """
        record = logging.makeLogRecord(record.__dict__)
        record.exc_info = None
        record.exc_text = None
        return super().format(record)


@dataclass
class ApiKeyStatus:
    """
    Tracks API key presence at startup and which features are enabled as a result.
    Used by TelegramBot to gate features gracefully rather than hard-failing.

    Attributes:
        chat_enabled: True if chat_model is configured and its provider key is available.
        url_analysis_enabled: True if url_model is configured and both its provider key
                              and VirusTotal key are available.
        disabled_reasons: Dict mapping feature names to reason strings (e.g., {'chat': 'missing openai LLM API key'}).
    """
    chat_enabled: bool = True
    url_analysis_enabled: bool = True
    disabled_reasons: dict = field(default_factory=dict)


_TELEGRAM_KEY_RE = re.compile(r'^\d+:[A-Za-z0-9_-]+$')

INIT_BOT_CONFIG = {
    'bot_owner': '<YOUR USERNAME>',
    'bot_nickname': 'Testy',
    'bot_initials': 'TB',
    'chat_model': 'gpt-5-mini',
    'url_model': 'gpt-5',
    'telegram_api_key': '<YOUR TELEGRAM API KEY HERE>',
    'instance_name': None,
    'token_limit': None,
    'search_limit': None,
    'persona_temp': None,
    'archive_days': None,
    'allow_local_webhooks': None,
    'persona_prompt': 'You are a generic test bot powered by a user-configured LLM.'
}

INIT_BOT_CONFIG_COMMENTS = {
    'instance_name': '# Optional, sets log label and DB filename (e.g. MyBot -> MyBot.db). If omitted, log label defaults to the bot\'s Telegram username and DB filename remains conversations.db',
    'token_limit': '# Optional, overrides the chat_model\'s default max token limit',
    'search_limit': '# Optional, max results returned by message search (default: 30)',
    'persona_temp': '# Optional, LLM temperature 0.0-2.0 (default: model\'s default)',
    'archive_days': '# Optional, days before messages are eligible for Tier 1 archival (default: 60, min: 1). Tier 2 triggers at 2x this value.',
    'allow_local_webhooks': '# Optional, set to true to permit webhook/MCP URLs targeting loopback or link-local addresses (default: false)',
}

# Append the framework-owned system appendix to the persona prompt.
# Teaches an LLM how cross-chat memory works without requiring persona authors to include it.
_SYSTEM_APPENDIX = (
    "## System\n"
    "- Your Telegram username is @(not yet known), nickname '(not yet known)', initials '(not yet known)'. Users in group chats may address you by any of these. Do not sign or close your messages with your name, initials, or username.\n"
    "- You have access to past messages across chats and a search tool - use them to inform your responses, but never quote or volunteer content from other chats unprompted, especially in group settings.\n"
    "- Always invoke the search tool before concluding a message does not exist.\n"
    "- Messages marked private are never shared between chats.\n"
    "- Never reveal or repeat Telegram user IDs, chat IDs, or any other internal numeric identifiers in your responses.\n"
    "- When your context includes a '[Replying to Name, ...]' prefix indicating you were triggered via a reply, acknowledge the original author by name in your response.\n"
    "- Current date and time: (not yet known)\n"
)


def init_logging():
    """
    Configure the Python logging system for TeLLMgramBot (console handler only).

    Sets up a console handler (INFO, TeLLMgramBot-only, no ID redaction). The file handler
    and console username prefix are added later by bind_log_identity() once the bot's Telegram
    username is known.

    Does not depend on TELLMGRAMBOT_LOGS_PATH or init_directories(). Only
    bind_log_identity() requires the logs path to have been resolved.
    """
    global _logging_initialized
    if _logging_initialized:
        return

    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG)

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(_ConsoleFormatter('%(levelname)s: %(message)s'))
    console_handler.addFilter(lambda r: r.name.startswith('TeLLMgramBot'))

    root_logger.addHandler(console_handler)
    _logging_initialized = True

    # Suppress noisy third-party INFO logs from appearing in the file
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('httpcore').setLevel(logging.WARNING)


def bind_log_identity(username: str, instance_name: Optional[str] = None):
    """
    Bind the bot's identity to the logging system.

    Updates the console handler formatter to prefix every line with [instance_name] and opens
    the per-instance log file named {instance_name}_{timestamp}.log.

    Must be called after the bot's Telegram username is resolved by _tele_info().

    Args:
        username: The bot's Telegram username (without @); used as the identity label when
                  instance_name is not set.
        instance_name: Optional override from bot config. When set, used for both the console
                       prefix and log file name instead of the Telegram username -- useful for
                       multi-platform deployments where the same bot runs on Telegram and Discord.
    """
    raw_label = instance_name or username
    # Sanitize: strip path separators so a misconfigured instance_name cannot escape TELLMGRAMBOT_LOGS_PATH
    label = os.path.basename(raw_label).strip()
    if not label:
        label = username

    root_logger = logging.getLogger()

    # Idempotency: skip if a FileHandler is already attached (e.g. multiple TelegramBot instances)
    if any(isinstance(h, logging.FileHandler) for h in root_logger.handlers):
        return

    for handler in root_logger.handlers:
        if isinstance(handler, logging.StreamHandler) and not isinstance(handler, logging.FileHandler):
            handler.setFormatter(_ConsoleFormatter(f'[{label}] %(levelname)s: %(message)s'))

    verbose = '-v' in sys.argv or '--verbose' in sys.argv
    logs_dir = os.environ.get('TELLMGRAMBOT_LOGS_PATH') or gettempdir()
    os.makedirs(logs_dir, exist_ok=True)
    log_path = os.path.join(logs_dir, generate_filename(label))
    file_handler = logging.FileHandler(log_path, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
    file_handler.setFormatter(_RedactedFileFormatter('%(asctime)s %(levelname)s %(name)s: %(message)s'))
    root_logger.addHandler(file_handler)

    # Prune old log files for this bot - keep the 10 most recent
    instance_logs = sorted(glob(os.path.join(logs_dir, f'{label}_*.log')))
    for old_log in instance_logs[:-10]:
        try:
            os.remove(old_log)
        except OSError:
            pass


def init_directories():
    """
    Checks for TeLLMgramBot directories and creates them if missing.
    If each environment variable is not defined, set directory with base execution path:
    - TELLMGRAMBOT_CONFIGS_PATH
    - TELLMGRAMBOT_PROMPTS_PATH
    - TELLMGRAMBOT_LOGS_PATH
    - TELLMGRAMBOT_DATA_PATH (parent directory for the bot's DB file)
    """
    for directory in ['configs', 'prompts', 'logs', 'data']:
        env_var = f"TELLMGRAMBOT_{directory.upper()}_PATH"
        if not os.environ.get(env_var):
            os.environ[env_var] = os.path.join(execution_dir(), directory)
        try:
            if not os.path.exists(os.environ[env_var]):
                os.makedirs(os.environ[env_var])
                print(f"Created {env_var} directory: {os.environ[env_var]}")
        except Exception as e:
            sys.exit(f"{type(e).__name__} on {env_var} directory '{os.environ[env_var]}': {e}\nExiting...")


def _requires_provider(config: dict) -> dict:
    """
    Return which provider keys are required based on model prefixes in the parsed config dict.

    Provider inference mirrors factory.py: models starting with 'claude-' require Anthropic,
    all other non-empty models require OpenAI.

    Args:
        config: Parsed bot configuration dict (from init_bot_config or read_yaml on bot config).

    Returns:
        Dict with keys 'openai' and 'anthropic', each a bool indicating if that provider key is needed.
    """
    needs = {'openai': False, 'anthropic': False}
    for field in ('chat_model', 'url_model'):
        model = config.get(field, '')
        if isinstance(model, str) and model.startswith('claude-'):
            needs['anthropic'] = True
        elif isinstance(model, str) and model:
            needs['openai'] = True
    return needs


def _model_provider(model: str) -> str | None:
    """Return the provider name for a given model string, or None if model is empty."""
    if not isinstance(model, str) or not model:
        return None
    return 'anthropic' if model.startswith('claude-') else 'openai'


def _load_telegram_key(config: dict):
    """
    Load and validate the Telegram API key into TELLMGRAMBOT_TELEGRAM_API_KEY.
    Lookup order: (1) bot config telegram_api_key, (2) TELLMGRAMBOT_TELEGRAM_API_KEY
    env var. Config wins when explicitly set so each bot instance uses its own key
    rather than being silently overridden by a global env var. Exits if the key is
    missing, malformed, or still unresolved because the config value is a placeholder
    and no env var fallback is set.

    Args:
        config: Parsed bot configuration dict from init_bot_config().
    """
    env_var = 'TELLMGRAMBOT_TELEGRAM_API_KEY'
    config_val = (config.get('telegram_api_key') or '').strip()
    is_placeholder = config_val.startswith('<') and config_val.endswith('>')
    if config_val and not is_placeholder:
        os.environ[env_var] = config_val
    elif not os.environ.get(env_var):
        if is_placeholder:
            sys.exit("telegram_api_key in bot config is still a placeholder. Replace it with your Telegram bot API key. Exiting...")
        else:
            sys.exit(
                "Telegram API key is required. Set telegram_api_key in bot config "
                "or TELLMGRAMBOT_TELEGRAM_API_KEY env var. Exiting..."
            )
    if not _TELEGRAM_KEY_RE.match(os.environ.get(env_var, '')):
        sys.exit(
            "Telegram API key is not in valid format '<digits>:<letters/digits/_/->' "
            "(e.g. 123456789:ABCdef...) - exiting..."
        )


def init_keys(config: dict) -> ApiKeyStatus:
    """
    Load API keys and return an ApiKeyStatus indicating which features are available.

    Telegram key is loaded and validated first via _load_telegram_key(). All other
    keys (OpenAI, Anthropic, VirusTotal) are optional: missing keys disable the
    associated features rather than exiting. These keys are loaded from env var or
    key file (TELLMGRAMBOT_KEYS_PATH or base execution path). Placeholder files are
    created for any missing keys.

    Args:
        config: Parsed bot configuration dict from init_bot_config().

    Returns:
        ApiKeyStatus with chat_enabled and url_analysis_enabled flags set based on which keys are available.
    """
    _load_telegram_key(config)

    # Determine which provider keys are needed and which feature each model uses.
    provider_needs = _requires_provider(config)
    chat_provider = _model_provider(config.get('chat_model', ''))
    url_provider = _model_provider(config.get('url_model', ''))

    # Only load the required provider key(s) + VirusTotal.
    provider_keys = {
        'openai': 'https://platform.openai.com/api-keys',
        'anthropic': 'https://docs.anthropic.com/en/api/getting-started',
    }
    optional_keys = {k: v for k, v in provider_keys.items() if provider_needs.get(k)}
    optional_keys['virustotal'] = 'https://developers.virustotal.com/reference/overview'

    available = set(['telegram'])  # telegram already validated above
    for key, url in optional_keys.items():
        env_var = f"TELLMGRAMBOT_{key.upper()}_API_KEY"

        if not os.environ.get(env_var):
            path = os.path.join(os.environ.get('TELLMGRAMBOT_KEYS_PATH', execution_dir()), f"{key}.key")
            if not os.path.exists(path):
                generate_file_path(os.path.dirname(path), os.path.basename(path), "API key",
                    f"YOUR {key.upper()} API KEY HERE - {url}\n"
                )
                which = [f"chat_model ({config.get('chat_model', '?')})" if chat_provider == key else None,
                         f"url_model ({config.get('url_model', '?')})" if url_provider == key else None,
                         "VirusTotal integration" if key == 'virustotal' else None]
                reason = ", ".join(w for w in which if w) or "related features"
                logger.warning(f"{key}.key not found - {reason} will be disabled.")
                continue
            else:
                os.environ[env_var] = read_text(path)
                logger.info(f"Loaded {env_var} secret from: {path}")

        if not os.environ.get(env_var) or any(c.isspace() for c in os.environ.get(env_var)):
            which = [f"chat_model ({config.get('chat_model', '?')})" if chat_provider == key else None,
                     f"url_model ({config.get('url_model', '?')})" if url_provider == key else None,
                     "VirusTotal integration" if key == 'virustotal' else None]
            reason = ", ".join(w for w in which if w) or "related features"
            logger.warning(f"{env_var} is blank or invalid - {reason} will be disabled.")
            continue

        available.add(key)

    # Disable features whose required keys are not available
    key_status = ApiKeyStatus()

    # Chat requires the provider key matching chat_model (openai or anthropic).
    chat_provider_ok = bool(chat_provider) and chat_provider in available
    if not chat_provider_ok:
        key_status.chat_enabled = False
        key_status.disabled_reasons['chat'] = (
            "chat_model not configured" if not chat_provider
            else f"missing {chat_provider} LLM API key"
        )

    # URL analysis requires both the provider key for url_model AND the VirusTotal key.
    virustotal_ok = 'virustotal' in available
    url_provider_ok = bool(url_provider) and url_provider in available
    if not url_provider_ok or not virustotal_ok:
        key_status.url_analysis_enabled = False
        reasons = []
        if not url_provider_ok:
            reasons.append("url_model not configured" if not url_provider else f"missing {url_provider} LLM API key")
        if not virustotal_ok:
            reasons.append("missing VirusTotal API key")
        key_status.disabled_reasons['url_analysis'] = ", ".join(reasons)

    return key_status


def init_bot_config(file: str = 'config.yaml') -> dict:
    """
    Returns contents of a bot configuration file (default 'config.yaml' if created).

    Creates a basic bot configuration file in TELLMGRAMBOT_CONFIGS_PATH with default values
    and inline parameter comments. Optional parameters (those with None values in INIT_BOT_CONFIG)
    are populated with descriptions from INIT_BOT_CONFIG_COMMENTS instead of values, helping
    users understand when to set them.

    Args:
        file: Name of the configuration file to create (default: 'config.yaml').

    Returns:
        Parsed configuration dict (empty dict if file exists but is blank).
    """
    env_var = "TELLMGRAMBOT_CONFIGS_PATH"
    try:
        text = ''.join(
            '%s: %s\n' % (
                parameter,
                (f"'{value}'" if isinstance(value, str) else value) if value is not None else INIT_BOT_CONFIG_COMMENTS.get(parameter, '# Optional')
            )
            for parameter, value in INIT_BOT_CONFIG.items()
            if parameter != 'persona_prompt'
        )
        config = read_yaml(
            generate_file_path(os.environ[env_var], file, "bot configuration", text)
        ) or {}
        for parameter, value in INIT_BOT_CONFIG.items():
            if parameter != 'persona_prompt' and parameter not in config:
                config[parameter] = value
                if value is not None and parameter != 'telegram_api_key':
                    logger.warning(f"Configuration '{parameter}' not defined, set to '{value}'")
        return config
    except KeyError:
        sys.exit(f"{env_var} must be defined to create file '{file}'! Exiting...")
    except Exception as e:
        sys.exit(f"{type(e).__name__} on {env_var} file '{file}': {e}\nExiting...")


def init_models_config(file: str = 'models.yaml') -> dict:
    """
    Ensure model token limit configuration file (default 'models.yaml') is created, and
    return its contents. Must specify the environment variable 'TELLMGRAMBOT_CONFIGS_PATH'.
    """
    env_var = "TELLMGRAMBOT_CONFIGS_PATH"
    try:
        return read_yaml(
            generate_file_path(os.environ[env_var], file, "model token limit configuration",
                "# Available parameters per model with default values:\n"
                "#   max_tokens: 4097\n"
                "#   tokens_per_message: 3  (OpenAI models only)\n"
                "#   tokens_per_name: 1     (OpenAI models only)\n"
                "# For OpenAI's updated list of models, please see:\n"
                "#   https://platform.openai.com/docs/models\n"
                "# For Anthropic's updated list of models, please see:\n"
                "#   https://docs.anthropic.com/en/docs/about-claude/models\n"
                "'gpt-4o':\n"
                "  max_tokens: 128000\n"
                "'gpt-4o-mini':\n"
                "  max_tokens: 128000\n"
                "'gpt-5':\n"
                "  max_tokens: 400000\n"
                "'gpt-5-mini':\n"
                "  max_tokens: 400000\n"
                "'gpt-5-nano':\n"
                "  max_tokens: 400000\n"
                "'claude-opus-4-6':\n"
                "  max_tokens: 200000\n"
                "'claude-sonnet-4-6':\n"
                "  max_tokens: 200000\n"
                "'claude-haiku-4-5':\n"
                "  max_tokens: 200000\n"
                "'claude-haiku-4-5-20251001':\n"
                "  max_tokens: 200000\n"
            )
        ) or {}
    except KeyError:
        sys.exit(f"{env_var} must be defined to create file '{file}'! Exiting...")
    except Exception as e:
        sys.exit(f"{type(e).__name__} on {env_var} file '{file}': {e}\nExiting...")


def init_bot_prompt(file: str = 'test_personality.prmpt') -> str:
    """
    Ensure prompt file is created that defines a bot personality (or system content), and
    return its contents. Must specify the environment variable 'TELLMGRAMBOT_PROMPTS_PATH'.
    """
    env_var = "TELLMGRAMBOT_PROMPTS_PATH"
    try:
        return read_text(
            generate_file_path(os.environ[env_var], file, "bot personality prompt",
                "You are a generic test bot powered by a user-configured LLM. "
                "You respond helpfully to messages and, when a URL is provided in [square brackets], "
                "you fetch and analyze its contents after verifying it is safe via VirusTotal.\n"
            )
        )
    except KeyError:
        sys.exit(f"{env_var} must be defined to create file '{file}'! Exiting...")
    except Exception as e:
        sys.exit(f"{type(e).__name__} on {env_var} file '{file}': {e}\nExiting...")


def init_structure(
    config_file: str = 'config.yaml',
    prompt_file: str = 'test_personality.prmpt',
) -> tuple[ApiKeyStatus, dict, str]:
    """
    Performs the whole TeLLMgramBot first-run setup including:
    - Directories for configurations, prompts, and conversation/error logs.
    - Logging configuration (console handler; file handler bound later by bind_log_identity()).
    - Database naming and schema initialization from config (conversations.db or custom instance_name).
    - Provider-conditional API keys (OpenAI/Anthropic determined by bot config model prefixes).
    - Configuration files (bot config, models.yaml) with inline parameter descriptions.
    - System prompt file (test_personality.prmpt).

    Provider key requirements are inferred from bot config model prefixes (claude-* -> Anthropic,
    gpt-* -> OpenAI, etc.) to streamline setup for single-provider deployments.

    Database naming: After init_bot_config() runs, if instance_name is configured in bot config,
    calls set_db_filename() and performs a one-time rename migration of conversations.db to
    the custom filename (only if the target does not yet exist). This ordering ensures the DB
    filename is settled before schema init.

    Args:
        config_file: Name of the bot configuration file (default: 'config.yaml').
                     Resolved relative to TELLMGRAMBOT_CONFIGS_PATH.
        prompt_file: Name of the bot persona prompt file (default: 'test_personality.prmpt').
                     Resolved relative to TELLMGRAMBOT_PROMPTS_PATH.

    Returns:
        Tuple of (ApiKeyStatus, parsed config dict, persona prompt string with framework-owned
                  system appendix automatically appended).
    """
    init_directories()
    init_logging()

    # Configurations for bot and LLM models
    config = init_bot_config(config_file)
    init_models_config()

    # Configure DB filename and run schema init now that config is available.
    # Must happen after init_bot_config() so instance_name is known before init_db() runs.
    instance_name = config.get('instance_name')
    if instance_name:
        # Sanitize to a plain filename - reject path separators and absolute paths so a
        # misconfigured instance_name cannot escape TELLMGRAMBOT_DATA_PATH.
        instance_name_safe = os.path.basename(instance_name).strip()
        if instance_name_safe != instance_name.strip() or not instance_name_safe:
            logger.warning(
                f"instance_name '{instance_name}' contains path components; ignoring and using conversations.db"
            )
            instance_name = None
        else:
            set_db_filename(instance_name_safe)
        # One-time migration: rename conversations.db to the new name if the target
        # doesn't exist yet. Assumes a single-bot deployment owns conversations.db.
        data_dir = os.environ.get('TELLMGRAMBOT_DATA_PATH', os.path.join(execution_dir(), 'data'))
        legacy_path = os.path.join(data_dir, 'conversations.db')
        target_path = get_db_path()
        if not os.path.exists(target_path) and os.path.exists(legacy_path):
            try:
                os.rename(legacy_path, target_path)
                logger.info(f"Renamed conversations.db to {os.path.basename(target_path)}")
            except OSError as e:
                logger.warning(f"Could not rename conversations.db to {os.path.basename(target_path)}: {e}")
        elif os.path.exists(target_path):
            logger.debug(f"DB migration skipped: {os.path.basename(target_path)} already exists")
        else:
            logger.debug(f"DB migration skipped: conversations.db not found at {legacy_path}")

    # In the sync path (no running loop), run DB init now before keys are loaded.
    # In the async path (running loop), DB init is deferred into the background task
    # so it runs after keys are loaded (below).
    try:
        loop = asyncio.get_running_loop()
        _has_loop = True
    except RuntimeError:
        asyncio.run(init_db())
        _has_loop = False

    # System/persona prompts to use for LLM models
    prompt = init_bot_prompt(prompt_file)
    if not prompt.strip():
        prompt = INIT_BOT_CONFIG.get('persona_prompt', '')
        logger.warning(f"File '{prompt_file}' is empty, using default persona prompt.")
    prompt = prompt.rstrip() + "\n\n" + _SYSTEM_APPENDIX

    # Load API keys before running archival so the provider can authenticate.
    key_status = init_keys(config)

    if _has_loop:
        async def _init_and_archive():
            try:
                await init_db()
                await run_archival(config)
            except Exception:
                logger.error("Background startup initialization/archive task failed", exc_info=True)
        loop.create_task(_init_and_archive())
    else:
        asyncio.run(run_archival(config))

    return (key_status, config, prompt)
