#!/usr/bin/env python
import asyncio
import datetime
import logging
import json
import os
import re
from math import floor

from telegram import Bot, Update, Message, Chat, User, ReactionTypeEmoji, MessageEntity, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import MessageLimit
from telegram.error import TelegramError
from telegram.ext import Application, CallbackQueryHandler, CommandHandler, MessageHandler, filters, ContextTypes

from .conversation import Conversation
from .utils import format_dt
from .database import (
    get_private_mode,
    set_private_mode,
    insert_message,
    delete_messages_for_user,
    delete_messages_for_chat,
    delete_private_messages_for_user,
    delete_bot_replies_for_user,
    delete_archive_for_user,
    delete_archive_for_chat,
    get_shared_group_chat_ids,
    message_id_exists,
    update_message_tg_id,
    prune_bot_messages,
    search_messages,
    upsert_chat,
    upsert_user,
    wipe_all_data,
)
from .archive import run_archival
from .initialize import (
    INIT_BOT_CONFIG,
    ApiKeyStatus,
    bind_log_identity,
    init_logging,
    init_structure,
)
from .message_handlers import handle_greetings, handle_common_queries, handle_url_ask
from .models import TokenLimits
from .tools import build_tool_registry, discover_mcp_tools, execute_mcp, execute_webhook
from .providers.factory import get_provider
from .providers.base import ContextLengthExceededError, ProviderAuthError, ProviderConnectionError, ToolCall
from .utils import exact_word_match, log_error

logger = logging.getLogger(__name__)

# Dialog copy - centralised so tests never hard-code these strings
_MSG_ADMIN_ONLY        = "Sorry, I can't do that for you."
_MSG_PROCESS_ERROR     = "Sorry, I couldn't process your message! Please contact my creator."
_MSG_TOOL_RESULT_ERROR = "Sorry, I couldn't process the tool result."
_MSG_NOT_YOUR_PROMPT   = "Sorry, this prompt is not for you!"
_MSG_WIPE_PROMPT       = "ALL of my memories will be lost! Are you sure?"
_MSG_WIPE_COMPLETE     = "Wipe complete. I hope you won't regret this..."
_MSG_WIPE_CANCELLED    = "Wipe cancelled. Whew, you scared me for a moment!"
_MSG_FORGET_PROMPT     = "Do you really want me to forget our memories together?"
_MSG_FORGET_COMPLETE   = "Forget complete. Fresh start it is..."
_MSG_FORGET_CANCELLED  = "Forget cancelled. Glad you changed your mind!"

_SEARCH_TOOL = {
    "name": "search_messages",
    "description": (
        "Search the full message history across the user's private chat and shared group chats. "
        "Results include both raw messages and archived summaries of older content. "
        "Use whenever the user asks who said something, what someone said, or what was discussed. "
        "Always search before claiming a person has no message history - do not assume from context alone. "
        "Run the search immediately when it would help answer the question - do not ask the user for permission to search. "
        "All filters are optional - omit them to retrieve recent messages broadly. "
        "Results are ordered most-recent-first by default; use ascending=true for oldest-first."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "content_query": {"type": "string", "description": "Text to search for in message content"},
            "speaker_query": {"type": "string", "description": "Name or @username of the person who sent the message. When the user refers to their own messages ('I said', 'my messages', 'what did I say'), use the current user's name or @username from the system prompt. If multiple users match, the search will return an ambiguity error asking you to clarify."},
            "chat_query": {"type": "string", "description": "Name of the group chat to search within. Use the exact chat title if known. If multiple chats match, the search will return an ambiguity error asking you to clarify."},
            "date_from": {"type": "string", "description": "Start of time range as ISO datetime (YYYY-MM-DDTHH:MM). For a full day, use T00:00."},
            "date_to": {"type": "string", "description": "End of time range as ISO datetime (YYYY-MM-DDTHH:MM). For a full day, use T23:59."},
            "ascending": {"type": "boolean", "description": "If true, results are ordered oldest-first. Use for queries like 'what was the first message about X?' or 'earliest mention of Y'."},
        },
        "required": [],
    },
}


class TelegramBot:
    """
    The bridge between the Telegram interface and a Large Language Model (LLM).
    - Tokens help retain conversation messages between the Telegram bot assistant and the user.
    - URLs in [square brackets] can be supplied on how the bot should interpret it.
    - For more information, see README or: https://github.com/Digital-Heresy/TeLLMgramBot
    """

    async def _tele_info(self):
        """Fetch the Telegram bot's information before running application."""
        try:
            bot = await Bot(token=os.environ['TELLMGRAMBOT_TELEGRAM_API_KEY']).get_me()
            self.telegram['bot_id'] = bot.id
            self.telegram['username'] = bot.username
            self.telegram['first_name'] = bot.first_name
            self.telegram['last_name'] = bot.last_name
            bind_log_identity(bot.username, self._instance_name)
        except Exception as e:
            # Fail fast if the bot's identity cannot be fetched to avoid
            # continuing with an uninitialized self.telegram['username'].
            log_error(e, 'Telegram')
            raise

    async def tele_commands(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Show available commands when the user sends `/help` to the bot.

        Displays general commands (/nick, /forget, /private, /help) to all users.
        Admin commands (/start, /stop, /wipe) are shown only to usernames in bot_owner list,
        and only in private chats (not in groups).

        Args:
            update: Telegram Update object containing the /help message.
            context: Telegram context for sending the reply.
        """
        uname = update.message.from_user.username
        chat_type = update.message.chat.type
        text = (
            "TeLLMgramBot commands:\n"
            "/nick - Set your nickname (e.g. \"/nick B0b #2\").\n"
            "/forget - Clear memories of all your conversations.\n"
            "/private - Toggle private mode (private chats only).\n"
            "/help - Display this usage information."
        )
        if uname in self.telegram['owners'] and chat_type == 'private':
            text += (
                "\n\nAdmin commands:\n"
                "/start - Go online to receive new responses (default).\n"
                "/stop - Go offline to prevent new responses.\n"
                "/wipe - Permanently delete all conversation data.\n"
                "/tools - List all registered tools available to this bot."
            )
        await update.message.reply_text(text)

    async def tele_start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Start the bot and resume handling new messages (admin-only).

        Only usernames in self.telegram['owners'] can execute this command; otherwise deny access.
        If the sender is an owner, sets self._online to True and confirms via reply.

        Args:
            update: Telegram Update object containing the /start message.
            context: Telegram context for sending the reply.
        """
        uname = update.message.from_user.username
        if uname in self.telegram['owners']:
            self._online = True
            greeting_text = f"Oh, hello {update.message.from_user.first_name}! Let me get to work!"
            await update.message.reply_text(greeting_text)
        else:
            await update.message.reply_text(_MSG_ADMIN_ONLY)

    async def tele_stop_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Stop the bot and pause handling new messages (admin-only).

        Only usernames in self.telegram['owners'] can execute this command; otherwise, deny access.
        If the sender is an owner, sets self._online to False and confirms via reply.

        Args:
            update: Telegram Update object containing the /stop message.
            context: Telegram context for sending the reply.
        """
        uname = update.message.from_user.username
        if uname in self.telegram['owners']:
            self._online = False
            await update.message.reply_text("Sure thing boss, cutting out!")
        else:
            await update.message.reply_text(_MSG_ADMIN_ONLY)

    async def tele_tools_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        List tools available to this bot instance (admin-only, private/group/supergroup).

        Shows name and description for every tool the bot exposes, including the built-in
        search_messages tool and any webhook tools defined in bot config. Restricted to
        usernames in bot_owner list. Works in private, group, and supergroup chats;
        channels always receive an admin-only denial. In group/supergroup chats, only
        tools with allow_groups=True are shown.

        Args:
            update: Telegram Update object containing the /tools message.
            context: Telegram context for sending the reply.
        """
        uname = update.message.from_user.username
        chat_type = update.message.chat.type
        if uname not in self.telegram['owners'] or chat_type not in ('private', 'group', 'supergroup'):
            await update.message.reply_text(_MSG_ADMIN_ONLY)
            return

        def _first_sentence(text: str) -> str:
            return text.split('. ')[0].rstrip('.!?') + '.'

        lines = ["Registered tools:"]
        for schema in self._build_tool_list(chat_type, uname):
            lines.append(f"- {schema['name']} - {_first_sentence(schema['description'])}")
        await update.message.reply_text('\n'.join(lines))

    async def tele_wipe_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Prompt for inline keyboard confirmation before wiping all conversation data (admin-only).

        Only usernames in self.telegram['owners'] can execute this command, otherwise deny access.
        Sends a confirmation message with Confirm and Cancel inline buttons, and the
        actual wipe is handled by tele_wipe_callback() once the owner taps Confirm.

        Args:
            update: Telegram Update object containing the /wipe message.
            context: Telegram context for sending the reply.
        """
        uname = update.message.from_user.username
        if uname not in self.telegram['owners']:
            await update.message.reply_text(_MSG_ADMIN_ONLY)
            return
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("Confirm", callback_data=f"wipe:confirm:{uname}"),
            InlineKeyboardButton("Cancel", callback_data=f"wipe:cancel:{uname}"),
        ]])
        await update.message.reply_text(_MSG_WIPE_PROMPT, reply_markup=keyboard)

    async def tele_wipe_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Handle the inline keyboard confirmation for /wipe.

        Executes the wipe if the tapping user matches the original /wipe sender and they tapped Confirm.
        If they tapped Cancel, the wipe is suppressed and the confirmation message is edited
        to show a cancellation notice. Ignores taps from any other user with an ephemeral alert.
        Confirm calls wipe_all_data() and clears all in-memory conversation state.

        Args:
            update: Telegram Update containing the callback query.
            context: Telegram context for answering the callback.
        """
        query = update.callback_query
        parts = query.data.split(':')
        action, original_uname = parts[1], parts[2]

        if query.from_user.username != original_uname:
            await query.answer(_MSG_NOT_YOUR_PROMPT)
            return

        await query.answer()
        if action == 'confirm':
            await wipe_all_data()
            self.conversations.clear()
            self.token_warning.clear()
            await query.edit_message_text(_MSG_WIPE_COMPLETE)
        else:
            await query.edit_message_text(_MSG_WIPE_CANCELLED)

    async def tele_nick_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Let bot assistant know to call the user by a different name other than the Telegram username.
        Must follow the format of "/nick(@<bot name>)? <nickname>", checked by a regular expression.
        """
        validated = await self.tele_validate(update)
        if not validated:
            return
        (msg, chat, user) = validated

        # If it's a group conversation, need to handle commands directly to bot with @<bot name> also
        pattern = re.compile(fr"^\s*/nick(?:@{re.escape(self.telegram['username'])})?\s+(.+?)\s*$", re.IGNORECASE)
        result = pattern.search(msg.text or "")
        if result:
            prompt = f"Please refer to me by my nickname, {result.group(1).strip()}, rather than my user name."
            response, _ = await self.tele_handle_response(prompt, msg)
            await msg.reply_text(response)
        else:
            await msg.reply_text("Please provide a valid nickname after the command like \"/nick B0b #2\".")

    async def tele_forget_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Prompt for inline keyboard confirmation before removing the requester's conversation history.

        Executes the forget if the tapping user matches the original /forget sender
        and they tapped Confirm. If they tapped Cancel, the forget is suppressed and
        the confirmation message is edited to show a cancellation notice. Ignores taps
        from any other user with an ephemeral alert.

        Args:
            update: Telegram Update object containing the /forget message.
            context: Telegram context for sending the reply.
        """
        validated = await self.tele_validate(update)
        if not validated:
            return
        (msg, chat, user) = validated
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("Confirm", callback_data=f"forget:confirm:{user.id}"),
            InlineKeyboardButton("Cancel", callback_data=f"forget:cancel:{user.id}"),
        ]])
        await msg.reply_text(_MSG_FORGET_PROMPT, reply_markup=keyboard)

    async def tele_forget_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Handle the inline keyboard confirmation for /forget.

        Executes the forget if the tapping user matches the original /forget sender and
        they tapped Confirm. Cancels gracefully if they tapped Cancel. Ignores taps
        from any other user with an ephemeral alert.
        - In private chats: deletes bot replies linked to this user, all user rows across chats,
          then remaining chat-level rows (pre-migration).
        - In group chats: bot replies and user rows only, leaving other participants intact.

        Args:
            update: Telegram Update containing the callback query.
            context: Telegram context for answering the callback.
        """
        query = update.callback_query
        parts = query.data.split(':')
        action, original_user_id = parts[1], int(parts[2])

        if query.from_user.id != original_user_id:
            await query.answer(_MSG_NOT_YOUR_PROMPT)
            return

        await query.answer()
        if action == 'cancel':
            await query.edit_message_text(_MSG_FORGET_CANCELLED)
            return

        chat = update.effective_chat
        user_id = original_user_id
        chat_id = chat.id
        chat_type = chat.type

        # Find all chat_ids where this user's context has been merged in memory,
        # identified by user_id being present in the Conversation's _context_cursor.
        user_chat_ids = {
            gid for gid, conv in self.conversations.items() if user_id in conv._context_cursor
        }
        # Always include the private chat (chat_id == user_id in Telegram) and current chat.
        user_chat_ids.update({chat_id, user_id})

        if chat_type == 'private':
            # Wipe bot replies linked to this user, then user's own rows across all chats,
            # then any remaining bot replies in the private chat (pre-migration rows).
            await delete_bot_replies_for_user(user_id)
            await delete_archive_for_user(user_id)
            await delete_messages_for_user(user_id)
            await delete_archive_for_chat(chat_id)
            await delete_messages_for_chat(chat_id)
        else:
            await delete_bot_replies_for_user(user_id)
            await delete_archive_for_user(user_id)
            await delete_messages_for_user(user_id)

        # Evict only the Conversations that contain this user's data, not all sessions.
        for evict_id in user_chat_ids:
            self.conversations.pop(evict_id, None)
            self.token_warning.pop(evict_id, None)

        await query.edit_message_text(_MSG_FORGET_COMPLETE)

    async def tele_private_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Enable or disable private mode for the requesting user (private chats only).

        When private mode is ON, messages sent in private chats are flagged as is_private=1
        in the database. These rows are excluded from all context loads - both group context
        (cross-pollination) and private chat reloads. On /private off, they are permanently
        deleted from the DB and purged from in-session memory (neuralyzer semantics).

        Usage:
            /private       - enables private mode (idempotent if already on)
            /private off   - disables private mode and purges in-session private messages

        Only available in private chats; sending the command in a group returns an error.
        """
        validated = await self.tele_validate(update)
        if not validated:
            return
        (msg, chat, user) = validated

        if chat.type != 'private':
            await msg.reply_text("Private mode is only available in private chats.")
            return

        user_id = user.id
        chat_id = chat.id
        args = (msg.text or "").strip().split()
        force_off = len(args) > 1 and args[1].lower() == 'off'

        if force_off:
            # Neuralyzer: delete before flipping the mode flag so that if the delete
            # fails, private mode stays ON and the user can safely retry /private off.
            await delete_private_messages_for_user(user_id)
            await set_private_mode(user_id, False)
            # Also purge from in-memory conversation so the bot cannot reference them now.
            if chat_id in self.conversations:
                self.conversations[chat_id].purge_private_messages()
            await msg.reply_text(
                "Private mode is OFF. Future messages in this private chat will be included in group conversation contexts."
            )
        else:
            await set_private_mode(user_id, True)
            await msg.reply_text(
                "Private mode is ON. Future messages in this private chat will be excluded "
                "from group conversation contexts. Use /private off to disable."
            )

    async def tele_handle_response(self, text: str, msg: Message, context_prefix: str = '') -> tuple[str, int | None]:
        """
        Primary function for handling any response including Generative AI, ensuring:
        - The owner started up the bot assistant for user interactions.
        - User has conversed with the bot assistant before.
        - Depending on regular interaction or URL request, formulate message based
          on the Generative AI model (e.g. OpenAI GPT) and token count checks.

        Conversations are keyed by chat_id (Telegram chat ID) and track both user_id
        and bot_id to support multi-participant group conversations. Respects per-user
        private mode settings when loading past context.

        Feature gating: If chat_enabled or url_analysis_enabled are False (per key_status),
        those features return a generic "couldn't process" error rather than attempting
        to call disabled LLM providers.

        Args:
            text: The user's message text.
            msg: The Telegram Message object containing chat/user context.
            context_prefix: Optional context prepended to the message before the live
                           speaker annotation. Used for reply-to-thread context. Defaults to ''.

        Returns:
            Tuple of (response_text, assistant_db_id). response_text is the bot's response
            string (or generic error if no handler matches or features are disabled).
            assistant_db_id is the database row id of the stored assistant message,
            or None if the bot is offline.

        Side Effects:
            - Adds user message to conversation history (keyed by chat_id).
            - Upserts user (first_name, last_name, username) and chat metadata.
            - Loads past interactions if this is the first message in this chat_id.
            - May invoke LLM tool calling (search_messages) and perform a second LLM round-trip.
            - Generates a token warning if conversation nears the limit.
            - Prunes conversation if token count exceeds the threshold.
            - Stores bot's response with bot identity and reply_to_id for tracking.
            - Returns assistant_db_id so the caller can update tg_message_id after Telegram send completes.
        """
        # Starting ensures we get some kind of user account details for logging
        if not self._online:
            return "I'd love to chat, but I am offline at the moment!", None

        # Extract identity and context from the message
        user_id    = msg.from_user.id
        username   = msg.from_user.username
        first_name = msg.from_user.first_name
        last_name  = msg.from_user.last_name
        chat_id    = msg.chat.id
        chat_type  = msg.chat.type
        chat_title = msg.chat.title
        identity = f"@{username}" if username else ' '.join(filter(None, [first_name, last_name]))
        logger.info(f"User {user_id} ({identity}) in {chat_type} Chat {chat_id}{f' ({chat_title})' if chat_title else ''}")

        # For a new session, create a Conversation keyed by chat_id
        if chat_id not in self.conversations:
            self.conversations[chat_id] = Conversation(
                chat_id,
                chat_type,
                self.llm['prompt'],
                self.llm['chat_model'],
                chat_title,
            )

        conv = self.conversations[chat_id]

        # Refresh datetime on every message
        conv.update_datetime()

        token_budget = floor(self.llm['prune_threshold'] / 2)

        if user_id not in conv._context_cursor:
            # First appearance of this user in this session - load their cross-chat history.
            # Pass bot_id so private chats can also load shared group context.
            # If no history exists yet, the cursor stays unset so the next message retries.
            await conv.get_past_interaction(token_budget, user_id, self.telegram['bot_id'])
        else:
            # Already loaded - check for new cross-chat messages since last load.
            await conv.refresh_user_context(user_id, token_budget)

        # Short-circuit for trivial greetings/queries - not persisted to conversation history
        quick_reply = handle_greetings(text) or handle_common_queries(text)
        if quick_reply:
            return quick_reply, None

        # Add the user's message to our conversation, respecting private mode
        # Private mode only applies in private chats - group messages are never flagged private
        user_private_mode = await get_private_mode(user_id)
        is_private = (chat_type == 'private') and user_private_mode
        user_msg_id = await conv.add_user_message(
            text, user_id, username, first_name, last_name, is_private, context_prefix, msg.message_id
        )

        # Check if the user is asking about a [URL]
        url_match = re.search(r'\[http(s)?://\S+]', text)

        # Form the assistant's message based on low level easy stuff or send to the LLM
        reply = _MSG_PROCESS_ERROR
        if url_match and self.key_status.url_analysis_enabled:
            await msg.reply_text("Sure, give me a moment to look at that URL...")
            reply = await handle_url_ask(text, self.llm['url_model'], conv.system_content)
        elif self._online and self.key_status.chat_enabled:
            # This is the transition point between quick Telegram replies and the LLM.
            tools = self._build_tool_list(chat_type, username)
            result = await self.llm_completion(chat_id, tools)
            if isinstance(result, ToolCall):
                reply = await self._resolve_tool_call(result, conv, user_id, username=username, chat_type=chat_type)
            else:
                reply = result

        # Check token count before storing to determine if warning should be appended
        token_count = await conv.get_message_token_count()
        if token_count > self.llm['prune_back_to'] and chat_id not in self.token_warning:
            reply += ("\n\n"
                "By the way, our conversation will soon reach my token limit, so I may"
                " start forgetting some of our older exchanges. Would you like me to"
                " summarize our conversation so far to keep the main points alive?"
            )
            self.token_warning[chat_id] = True

        # Add the full reply (including any warning) to the conversation.
        # Propagate is_private so bot replies in private-mode exchanges are also excluded
        # from group context loading - otherwise the assistant's half of the conversation leaks.
        assistant_db_id = await conv.add_assistant_message(
            reply,
            self.telegram['bot_id'],
            self.telegram['username'],
            self.telegram['first_name'],
            self.telegram['last_name'],
            is_private,
            user_msg_id,
        )

        # Recompute token count after full exchange is stored, then prune if needed
        token_count = await conv.get_message_token_count()
        if token_count > self.llm['prune_threshold']:
            await conv.prune_conversation(self.llm['prune_back_to'])

        return reply, assistant_db_id

    async def _build_reply_context(self, msg: Message) -> str:
        """
        Build an inline context prefix when the user is replying to another message.

        Used to surface context when the triggering message is a reply-to another message
        not already in the conversation's memory window. Returns an annotated prefix string
        with speaker name and timestamp if the replied-to message is not in context, or an
        empty string if already present.

        Deduplication applies only to our own bot's replies (to avoid repeating content
        already visible in context). For all other senders - foreign bots and human users -
        the prefix is always prepended so the LLM has an explicit anchor to the referenced
        message regardless of whether it appears elsewhere in the loaded context.

        Own-bot dedup uses two tiers:
        1. Memory - reply_to_message.message_id in conv._loaded_message_ids (O(1)).
           In-session bot replies are added here immediately after each send.
        2. DB fallback - query for tg_message_id in the messages table.
           Cross-session bot replies are findable here since tg_message_id is now
           stored for assistant messages after each send.

        Fires in all chat types (group and private) when reply_to_message exists and has text.
        from_user is not required — messages from channel-linked bots or anonymous admins
        may omit it; sender_chat.title or 'unknown' is used as the name fallback.
        Correctly re-surfaces bot messages that are no longer in context (e.g. post-/forget).

        Args:
            msg: The incoming Telegram Message that triggered the bot.

        Returns:
            Formatted prefix string, e.g.
            "[BotB, 2026-04-05 14:30 UTC]: The ancient sword was forged in...\n"
            or empty string if the replied-to message is already in context.
        """
        reply = msg.reply_to_message
        if not reply or not reply.text:
            return ''

        r_tg_id = reply.message_id
        conv = self.conversations.get(msg.chat.id)
        is_our_reply = (
            reply.from_user is not None and
            reply.from_user.id == self.telegram['bot_id']
        )

        if is_our_reply:
            # Dedup only our own bot's replies to avoid repeating content already visible.
            # Tier 1: in-session check via loaded message ID set
            if conv and r_tg_id in conv._loaded_message_ids:
                return ''
            # Tier 2: DB fallback for cross-session bot replies
            if await message_id_exists(msg.chat.id, r_tg_id):
                return ''

        # For own-bot replies, mark as seen to skip dedup on subsequent replies
        # to the same message within the session. Foreign/human IDs are tracked
        # by tele_handle_message after the response is sent.
        if is_our_reply and conv:
            conv._loaded_message_ids.add(r_tg_id)
        if reply.from_user:
            sender = reply.from_user
            name_parts = [p for p in [sender.first_name, sender.last_name] if p]
            name = ' '.join(name_parts) if name_parts else (sender.username or 'unknown')
        elif reply.sender_chat:
            name = reply.sender_chat.title or reply.sender_chat.username or 'unknown'
        else:
            name = 'unknown'
        dt = format_dt(reply.date)
        return f"[Replying to {name}, {dt}]: {reply.text}\n"

    async def _store_bot_message(self, msg: Message) -> None:
        """
        Persist a foreign bot's message to the DB for ambient group context.

        Registers the bot as a user (is_bot=True) and its chat, inserts the message
        with role='user', then prunes the per-chat bot message cap. Skips if the
        message has no text or is already stored (tg_message_id dedup).

        Args:
            msg: The Telegram Message from a foreign bot (msg.from_user.is_bot must be True).
        """
        if not msg.text:
            return
        bot_user = msg.from_user
        await upsert_user(bot_user.id, bot_user.username, bot_user.first_name, bot_user.last_name, is_bot=True)
        await upsert_chat(msg.chat.id, msg.chat.type, msg.chat.title or msg.chat.username or '')
        existing = await message_id_exists(msg.chat.id, msg.message_id)
        if not existing:
            await insert_message(
                chat_id=msg.chat.id,
                user_id=bot_user.id,
                role='user',
                content=msg.text,
                is_private=False,
                tg_message_id=msg.message_id,
            )
            await prune_bot_messages(msg.chat.id)

    def _exclusive_foreign_mention(self, msg: Message) -> str | None:
        """
        Return the first foreign @mention if all @mention entities are exclusively foreign.

        Used in the reply-to-bot path: when the user threads Kowi's message but addresses
        a different account via @mention, return that account's username so the caller can
        detect a redirect. Returns None when we are also @mentioned (co-mention),
        when there are no @mention entities, or when msg.entities is absent.

        Args:
            msg: The incoming Telegram Message object.

        Returns:
            The first foreign @username string (with leading @) if all @mentions are
            foreign, or None if we are co-mentioned or no @mention entities exist.
        """
        if not msg.entities:
            return None
        our_username = self.telegram['username'].lower()
        first_foreign = None
        for entity in msg.entities:
            if entity.type == MessageEntity.MENTION:
                mentioned = msg.parse_entity(entity)
                if mentioned.lstrip('@').lower() == our_username:
                    return None
                if first_foreign is None:
                    first_foreign = mentioned
        return first_foreign


    async def _send_read_receipt(self, msg: Message, context: ContextTypes.DEFAULT_TYPE):
        """
        Send a read receipt acknowledgement via message reaction.

        Attempts to add a 👀 emoji reaction to the user's message to confirm the bot
        read it. If the message reaction API is unavailable (e.g., older Telegram clients),
        falls back to a short "Got it!" text reply. Called unconditionally on every group
        mention before the normal LLM response.

        Args:
            msg: The Telegram Message object to react to.
            context: The Telegram context for sending the reply if reaction fails.
        """
        try:
            await context.bot.set_message_reaction(
                chat_id=msg.chat.id,
                message_id=msg.message_id,
                reaction=[ReactionTypeEmoji(emoji="👀")],
            )
        except (TelegramError, AttributeError):
            await msg.reply_text("Got it!")

    async def tele_handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """
        Route incoming Telegram messages to appropriate handlers based on chat type and trigger conditions.

        In group/supergroup chats, the bot responds when any of the following conditions are met:
        - User mentions the bot by @username
        - User mentions the bot by nickname (set via config)
        - User mentions the bot by initials (set via config)
        - User directly replies to one of the bot's messages (Telegram reply-to feature)

        Path A - foreign bot message (standalone update): Stores the message for ambient context and returns without LLM response.
        Path B - human reply to foreign bot: Stores the replied-to message before normal routing (fires regardless of whether we are triggered).
        Nickname/initials triggers always engage even when foreign bots are also @mentioned.
        Reply-to-bot trigger yields silently when the message is exclusively addressed to a foreign @account.

        In private chats, the bot responds to all messages (Telegram does not deliver bot-to-bot DMs).

        When the triggering message is itself a reply to a non-bot message not already in context,
        the replied-to message is prepended as inline context for the LLM via _build_reply_context().
        This applies to both group and private chat contexts.

        In all group matching scenarios, a read receipt acknowledgement (👀 reaction or "Got it!" fallback)
        is sent immediately via _send_read_receipt() before generating the full LLM response.

        Args:
            update: The Telegram Update object containing the incoming message.
            context: The Telegram context for sending replies.
        """
        validated = await self.tele_validate(update)
        if not validated:
            return
        (msg, chat, user) = validated

        # Path A: foreign bot message delivered directly as a standalone update (rare).
        # Store for ambient context and return - no LLM response triggered by bot messages.
        if user.is_bot and user.id != self.telegram['bot_id'] and chat.type in ('group', 'supergroup'):
            await self._store_bot_message(msg)
            return

        # Path B: capture a foreign bot's message when a human replies to it.
        # Fires regardless of whether the reply also triggers us.
        if (
            chat.type in ('group', 'supergroup') and
            msg.reply_to_message is not None and
            msg.reply_to_message.from_user is not None and
            msg.reply_to_message.from_user.is_bot and
            msg.reply_to_message.from_user.id != self.telegram['bot_id']
        ):
            await self._store_bot_message(msg.reply_to_message)

        # If it's a group text, only reply if the bot is named
        # The real magic of how the bot behaves is in tele_handle_response()
        response = _MSG_PROCESS_ERROR
        assistant_db_id = None
        reply_context = ''
        if chat.type == 'supergroup' or chat.type == 'group':
            is_reply_to_bot = (
                msg.reply_to_message is not None and
                msg.reply_to_message.from_user is not None and
                msg.reply_to_message.from_user.id == self.telegram['bot_id']
            )
            if exact_word_match(self.telegram['username'], msg.text):
                # Explicit @username mention: strongest signal - respond even if another
                # bot is also @mentioned (both may be intentionally addressed).
                pattern = r'@?\b' + re.escape(self.telegram['username']) + r'\b'
                new_text = re.sub(pattern, '', msg.text).strip()
                reply_context = await self._build_reply_context(msg)
                await self._send_read_receipt(msg, context)
                response, assistant_db_id = await self.tele_handle_response(new_text, msg, reply_context)
            elif (
                exact_word_match(self.telegram['nickname'], msg.text) or
                exact_word_match(self.telegram['initials'], msg.text)
            ):
                # Nickname/initials: always engage - no reliable way to distinguish
                # our name as addressee vs topic from text position alone.
                reply_context = await self._build_reply_context(msg)
                await self._send_read_receipt(msg, context)
                response, assistant_db_id = await self.tele_handle_response(msg.text, msg, reply_context)
            elif is_reply_to_bot:
                # Reply-to-bot: weaker signal - yield silently if the message is
                # exclusively addressed to a foreign account via @mention.
                if self._exclusive_foreign_mention(msg):
                    return
                reply_context = await self._build_reply_context(msg)
                await self._send_read_receipt(msg, context)
                response, assistant_db_id = await self.tele_handle_response(msg.text, msg, reply_context)
            else:
                return
        elif chat.type == 'private':
            reply_context = await self._build_reply_context(msg)
            response, assistant_db_id = await self.tele_handle_response(msg.text, msg, reply_context)
        else:
            return

        # Split into smaller chunks since Telegram messages have a maximum text length (likely 4096)
        chunk_length = MessageLimit.MAX_TEXT_LENGTH - 1
        chunks = [response[i:i+chunk_length] for i in range(0, len(response), chunk_length)]
        conv = self.conversations.get(msg.chat.id)
        # If reply context was surfaced on the first interaction (conv was None when
        # _build_reply_context ran), record the ID now that the conversation exists.
        if conv and reply_context and msg.reply_to_message:
            conv._loaded_message_ids.add(msg.reply_to_message.message_id)
        for chunk in chunks:
            sent = await msg.reply_text(chunk)
            if sent:
                if conv:
                    conv._loaded_message_ids.add(sent.message_id)
                # Persist this chunk's Telegram message ID on the assistant row.
                # Each call overwrites the previous, so only the last chunk's ID is
                # retained for cross-session tier 2 dedup. Tier 1 covers all chunks
                # in-session via _loaded_message_ids.
                if assistant_db_id:
                    await update_message_tg_id(assistant_db_id, sent.message_id)
            await asyncio.sleep(0.12)  # small pause to reduce risk of rate limiting

    async def tele_validate(self, update: Update) -> tuple[Message, Chat, User] | None:
        """
        Check if any update through Telegram has a complete message, chat, and user.
        Requires a valid message and chat; user.id must be present (username is optional).
        Uses python-telegram-bot's Update `effective` methods for all three.
        """
        if update is None:
            return None

        # Any python-telegram-bot 'effective' method helps ensure there are no "None" types
        # Non-user updates like Inline queries or chat member updates makes either one undefined
        msg  = update.effective_message
        chat = update.effective_chat
        user = update.effective_user

        # If there is no chat or valid message of the unique conversation, no reason to reply
        if chat is None or msg is None:
            return None
        # chat.type => 'private', 'group', 'supergroup', 'channel'
        # chat.id = user.id if 'private'

        # Handle the user sending the message; user.id is always present
        if not user:
            return None

        return (msg, chat, user)

    async def tele_error(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle any conversation error caused on the Telegram side."""
        log_error(context.error, 'Telegram')
        msg = update.effective_message if update else None
        if msg:
            await msg.reply_text("Sorry, I ran into an error! Please contact my creator.")

    def _build_tool_list(self, chat_type: str, username: str | None) -> list:
        """
        Build the tool list to pass to the LLM for this request.

        _SEARCH_TOOL is always included. Owner in private chat receives all webhook and
        MCP schemas. Owner in group/supergroup receives only schemas with allow_groups=True.
        Non-owners and all other chat types (channels) receive only _SEARCH_TOOL.

        Args:
            chat_type: Telegram chat type string ('private', 'group', 'supergroup', etc.).
            username: Telegram username of the requesting user (without @), or None.

        Returns:
            List of provider-compatible tool schema dicts.
        """
        tools = [_SEARCH_TOOL]
        if username not in self.telegram['owners']:
            return tools
        if chat_type == 'private':
            return tools + self.webhook_schemas
        if chat_type in ('group', 'supergroup'):
            group_schemas = [
                s for s in self.webhook_schemas
                if self.webhook_defs.get(s['name'], {}).get('allow_groups', False)
            ]
            return tools + group_schemas
        return tools

    async def _handle_tool_call(
        self, tool_call: ToolCall, user_id: int, chat_id: int,
        username: str | None = None, chat_type: str = 'private',
    ) -> str:
        """
        Execute a tool call requested by the LLM and return the result string.

        Routes 'search_messages' to the built-in search handler. Webhook and MCP tools are
        routed to execute_webhook() or execute_mcp() (distinguished by '_mcp_server' key in
        tool_def) after a defense-in-depth permission check that rechecks owner status and
        allow_groups scope even for group/supergroup chats (channels are always denied).

        Args:
            tool_call: The ToolCall returned by the provider.
            user_id: Telegram user ID of the requesting user (for search access control).
            chat_id: Telegram chat ID of the current conversation.
            username: Telegram username of the requesting user (for tool permission check).
            chat_type: Telegram chat type string (for tool permission check).

        Returns either:
            search_messages: JSON-encoded list of result dicts, JSON error object, or ambiguity sentinel.
            webhook or MCP tools: framed '[Tool result from <name>]:' string, or error string.
        """
        if tool_call.name == 'search_messages':
            args = tool_call.arguments
            shared_groups = await get_shared_group_chat_ids(user_id, self.telegram['bot_id'])
            accessible = list({user_id, chat_id, *shared_groups})
            results = await search_messages(
                accessible,
                args.get('content_query'),
                args.get('speaker_query'),
                args.get('chat_query'),
                args.get('date_from'),
                args.get('date_to'),
                self.llm['search_limit'],
                bool(args.get('ascending', False)),
            )
            if isinstance(results, list):
                for r in results:
                    ts = r.get('timestamp', '')
                    if ts:
                        try:
                            dt = datetime.datetime.fromisoformat(ts.rstrip('Z')).replace(tzinfo=datetime.timezone.utc)
                            r['timestamp'] = format_dt(dt)
                        except ValueError:
                            pass
                # Lazy archival trigger: cap hit may indicate more archivable content.
                if len(results) == self.llm['search_limit']:
                    try:
                        loop = asyncio.get_running_loop()
                        loop.create_task(run_archival(self.llm))
                    except RuntimeError:
                        pass
            return json.dumps(results)

        tool_def = self.webhook_defs.get(tool_call.name)
        if tool_def:
            # Defense-in-depth guard: primary gate is _build_tool_list(); this catches
            # edge cases where a tool call arrives despite the schema not being injected.
            if username not in self.telegram['owners']:
                return "[Permission denied: tools are only available to the bot owner]"
            if chat_type not in ('private', 'group', 'supergroup'):
                return "[Permission denied: tools are not available in this chat type]"
            if chat_type != 'private' and not tool_def.get('allow_groups', False):
                return "[Permission denied: this tool is not enabled for group chats]"
            if tool_def.get('_mcp_server'):
                return await execute_mcp(tool_def, tool_call.arguments)
            return await execute_webhook(tool_def, tool_call.arguments)

        return json.dumps({"error": f"Unknown tool: {tool_call.name}"})

    async def _resolve_tool_call(self,
        tool_call: ToolCall,
        conv: Conversation,
        user_id: int,
        username: str | None = None,
        chat_type: str = 'private',
    ) -> str:
        """
        Execute a tool call and perform the second LLM round-trip with results injected.

        Builds an ephemeral message slice that appends a placeholder assistant acknowledgement
        and a user message containing the tool results to conv.messages, then calls the
        provider for a final natural-language answer. The ephemeral messages are not stored
        in conv.messages - only the final answer is persisted by the caller.

        Args:
            tool_call: The ToolCall returned by the first LLM call.
            conv: The active Conversation for this chat.
            user_id: Telegram user ID of the requesting user (for search access control).
            username: Telegram username passed through to _handle_tool_call for webhook permission.
            chat_type: Telegram chat type passed through to _handle_tool_call for webhook permission.

        Returns:
            The final LLM response string, or a fallback error message on failure.
        """
        tool_result = await self._handle_tool_call(tool_call, user_id, conv.chat_id, username=username, chat_type=chat_type)
        ephemeral = list(conv.messages) + [
            {"role": "assistant", "content": "Let me handle that."},
            {"role": "user", "content": f"Tool result:\n{tool_result}\n\nPlease respond to my original request based on this result. Be concise - do not repeat raw data from the tool result verbatim."},
        ]
        provider = get_provider(self.llm['chat_model'])
        try:
            result = await provider.complete(self.llm['chat_model'], ephemeral)
            return result if isinstance(result, str) else _MSG_TOOL_RESULT_ERROR
        except Exception as e:
            log_error(e, 'ToolCall')
            return "Sorry, I had trouble handling that request."

    async def llm_completion(self, chat_id: int, tools: list[dict] | None = None, _retry: bool = True) -> "str | ToolCall":
        """
        Get the LLM response for the conversation in the given chat.

        Args:
            chat_id: Telegram chat ID (negative for groups, positive for private).
            tools: Optional list of tool definitions in unified format. When provided,
                   the LLM may return a ToolCall instead of a string.
            _retry: Internal flag to prevent infinite retry loops on context overflow.

        Returns:
            The LLM's response string, a ToolCall if the model wants to invoke a tool,
            or a user-facing error message string on failure.

        Selects the provider (OpenAI or Anthropic) automatically based on the configured model.
        On context length errors, prunes the conversation and retries once. Other errors are
        logged and return a user-facing fallback string.
        """
        provider = get_provider(self.llm['chat_model'])
        try:
            return await provider.complete(self.llm['chat_model'], self.conversations[chat_id].messages, tools)
        except ContextLengthExceededError:
            if not _retry:
                return "Sorry, your conversation is too long for me to respond to. Try /forget to start fresh."
            logger.warning(f"Chat {chat_id} reached maximum context length, pruning conversation")
            await self.conversations[chat_id].prune_conversation(self.llm['prune_back_to'])
            return await self.llm_completion(chat_id, tools, False)
        except ProviderAuthError as e:
            log_error(e, f"{self.llm['chat_model']} Authentication")
            return "Sorry, I'm having trouble authenticating with the AI provider. Please contact my owner!"
        except ProviderConnectionError as e:
            log_error(e, f"{self.llm['chat_model']} Connection")
            return "Sorry, I couldn't reach the AI provider. Please try again in a moment!"
        except Exception as e:
            log_error(e, f"{self.llm['chat_model']} Other")
            return "Sorry, something went wrong on my end. Please try again!"

    def start_polling(self):
        """The main polling "loop" the user interacts with via Telegram."""
        logger.info(f"TeLLMgramBot {self.telegram['username']} polling...")
        self.telegram['app'].run_polling(poll_interval=self.telegram['pollinterval'])
        logger.info(f"TeLLMgramBot {self.telegram['username']} polling ended.")

    # Initialization
    def __init__(self,
        bot_owner      = INIT_BOT_CONFIG['bot_owner'],
        bot_nickname   = INIT_BOT_CONFIG['bot_nickname'],
        bot_initials   = INIT_BOT_CONFIG['bot_initials'],
        chat_model     = INIT_BOT_CONFIG['chat_model'],
        url_model      = INIT_BOT_CONFIG['url_model'],
        token_limit    = INIT_BOT_CONFIG['token_limit'],
        search_limit   = INIT_BOT_CONFIG['search_limit'],
        persona_temp   = INIT_BOT_CONFIG['persona_temp'],
        archive_days   = INIT_BOT_CONFIG['archive_days'],
        persona_prompt = INIT_BOT_CONFIG['persona_prompt'],
        key_status: ApiKeyStatus | None = None,
        instance_name: str | None = None,
        webhook_schemas: list | None = None,
        webhook_defs: dict | None = None,
    ):
        """
        Initialize the Telegram bot with LLM configuration and API keys.

        Args:
            bot_owner: Telegram username(s) with admin access (no `@`).
                       Accepts a single string or a list of strings; normalised to list[str] internally.
            bot_nickname: Nickname the bot responds to in group chats.
            bot_initials: Initials the bot responds to in group chats.
            chat_model: LLM model for conversation (e.g., 'gpt-5-mini', 'claude-sonnet-4-6').
            url_model: LLM model for URL analysis (can differ from chat_model).
            token_limit: Maximum tokens for conversations. If None, uses the chat_model default.
            search_limit: Maximum results returned by message search. If None, defaults to 30.
            persona_temp: LLM temperature (0.0-2.0). If None, defaults to 1.0.
            persona_prompt: System prompt defining the bot's behavior and personality.
            key_status: ApiKeyStatus object indicating available features. If None, calls init_structure().
            instance_name: Optional label for console prefix and log file name (from bot config `instance_name`).
                           Defaults to the bot's Telegram username when not set.
            archive_days: Days before messages are eligible for Tier 1 archival (default: 60).
                          Must be an integer >= 1; invalid values log a warning and fall back to 60.
                          Tier 2 compression triggers at archive_days * 2.
            webhook_schemas: Provider-compatible tool schema dicts for webhook tools (from build_tool_registry).
                             If None, no webhook tools are registered.
            webhook_defs: Resolved webhook tool definitions keyed by tool name (from build_tool_registry).
                          If None, no webhook tools are registered.

        Side Effects:
            - Normalises bot_owner to list[str] and stores in self.telegram['owners'].
            - Fetches bot metadata (username, first_name, last_name, bot_id) from Telegram API via _tele_info().
            - Initializes command and message handlers for the Telegram application.
            - Sets self._online to True once initialization completes (ready for polling).
        """
        # Starting to initialize, not online yet
        self._online = False
        self._instance_name = instance_name

        # Bootstrap structure and logging; init_logging() is a no-op if init_structure already ran it.
        self.key_status = key_status if key_status is not None else init_structure()[0]
        init_logging()

        # Initialize some variables
        self.token_warning = {}  # Determines whether user has reached token limit by AI model
        self.conversations = {}  # Provides Conversation class per user based on bot response
        self.webhook_schemas = webhook_schemas or []  # Provider-compatible schemas for webhook tools
        self.webhook_defs = webhook_defs or {}        # Resolved tool definitions keyed by name
        owners = bot_owner if isinstance(bot_owner, list) else [bot_owner]
        self.telegram = {
            'bot_id'       : 0,  # overwritten by _tele_info(); 0 is a safe sentinel
            'owners'       : [str(u).strip() for u in owners if str(u).strip()],
            'nickname'     : bot_nickname,
            'initials'     : bot_initials,
            'username'     : None,
            'first_name'   : None,
            'last_name'    : None,
            'pollinterval' : 3,
        }
        # Check for event running loops before getting the bot's information
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running event loop; safe to run synchronously
            asyncio.run(self._tele_info())
        else:
            # Already in an event loop; schedule as a background task
            loop.create_task(self._tele_info())

        # Build our application with handlers for Commands, Messages, and Errors
        self.telegram['app'] = Application.builder().token(os.environ['TELLMGRAMBOT_TELEGRAM_API_KEY']).build()
        self.telegram['app'].add_handler(CommandHandler('help', self.tele_commands))
        self.telegram['app'].add_handler(CommandHandler('start', self.tele_start_command))
        self.telegram['app'].add_handler(CommandHandler('stop', self.tele_stop_command))
        self.telegram['app'].add_handler(CommandHandler('tools', self.tele_tools_command))
        self.telegram['app'].add_handler(CommandHandler('wipe', self.tele_wipe_command))
        self.telegram['app'].add_handler(CallbackQueryHandler(self.tele_wipe_callback, pattern=r'^wipe:'))
        self.telegram['app'].add_handler(CallbackQueryHandler(self.tele_forget_callback, pattern=r'^forget:'))
        self.telegram['app'].add_handler(CommandHandler('nick', self.tele_nick_command))
        self.telegram['app'].add_handler(CommandHandler('forget', self.tele_forget_command))
        self.telegram['app'].add_handler(CommandHandler('private', self.tele_private_command))
        self.telegram['app'].add_handler(MessageHandler(filters.TEXT & ~filters.UpdateType.EDITED_MESSAGE, self.tele_handle_message))
        self.telegram['app'].add_error_handler(self.tele_error)

        # Validate optional config values before storing; warn and fall back to defaults on bad input
        if token_limit is not None and not (isinstance(token_limit, int) and token_limit > 0):
            logger.warning(f"Invalid token_limit '{token_limit}' (must be a positive integer), using model default")
            token_limit = None
        if search_limit is not None and not (isinstance(search_limit, int) and search_limit > 0):
            logger.warning(f"Invalid search_limit '{search_limit}' (must be a positive integer), using default 30")
            search_limit = None
        if persona_temp is not None and not (isinstance(persona_temp, (int, float)) and 0.0 <= persona_temp <= 2.0):
            logger.warning(f"Invalid persona_temp '{persona_temp}' (must be a decimal between 0.0 and 2.0), using default 1.0")
            persona_temp = None
        if archive_days is not None and not (isinstance(archive_days, int) and archive_days >= 1):
            logger.warning(f"Invalid archive_days '{archive_days}' (must be an integer >= 1), using default 60")
            archive_days = None

        # Get our LLM spun up with defaults if not defined by user input
        # Tokens as integers measure the length of conversation messages
        self.llm = {
            'prompt'       : persona_prompt,
            'chat_model'   : chat_model,
            'url_model'    : url_model,
            'token_limit'  : token_limit or TokenLimits(chat_model).max_tokens(),
            'search_limit' : search_limit or 30,
            'temperature'  : persona_temp or 1.0,
            'top_p'        : 0.9,
            'archive_days' : archive_days if archive_days is not None else 60,
        }
        # Set a rounded-down integer to prune a lengthy conversation by 500 tokens
        # Note if the upper limit is below 500, the lower limit is set to 0
        self.llm['prune_threshold'] = floor(0.95 * self.llm['token_limit'])
        self.llm['prune_back_to'] = max(0, self.llm['prune_threshold'] - 500)

        # Patch identity placeholders now that both self.llm and self.telegram are set.
        # _tele_info() has already populated username, nickname, and initials.
        identity_line = (
            f"\n- Your Telegram username is @{self.telegram['username']}, "
            f"nickname '{self.telegram['nickname']}', "
            f"initials '{self.telegram['initials']}'. "
            "Users in group chats may address you by any of these. "
            "Do not sign or close your messages with your name, initials, or username."
        )
        self.llm['prompt'] = re.sub(
            r'\n-?\s*Your Telegram username is.*',
            identity_line,
            self.llm['prompt'],
        )

        # Bot is now ready and active by default
        self._online = True

    def set(config_file: str = 'config.yaml', prompt_file: str = 'test_personality.prmpt'):
        """
        Instantiate a TelegramBot from configuration and prompt files.

        Calls init_structure() to bootstrap directories, API keys, and configuration files,
        unpacking a three-tuple (ApiKeyStatus, config dict, persona prompt str with system
        appendix already appended). Builds webhook tool registry from 'tools:' config, discovers
        MCP tools from any 'mcp_server:' entries, and merges both into the final tool registry.
        Applies defaults for any missing values and returns a fully initialized TelegramBot.

        Args:
            config_file: Filename of the bot configuration YAML (default: 'config.yaml').
                         Resolved relative to TELLMGRAMBOT_CONFIGS_PATH env var, not as a literal path.
            prompt_file: Filename of the bot persona prompt (default: 'test_personality.prmpt').
                         Resolved relative to TELLMGRAMBOT_PROMPTS_PATH env var, not as a literal path.

        Returns:
            A fully initialized TelegramBot instance.

        Side Effects:
            - Calls init_structure() which creates directories, config/prompt files, and checks API keys.
            - Calls discover_mcp_tools() if any 'mcp_server:' entries are in config (gracefully degrades if called from async context).
            - May log warnings (for missing config values, empty prompt, or skipped MCP discovery), but does not print a startup API key status summary.
            - Log identity/file label is taken from bot config `instance_name` when set; otherwise defaults to the bot's Telegram username once _tele_info() resolves.
        """
        # Bootstrap directories, logging, config, prompt (with appendix), and API keys in one call.
        key_status, config, prompt = init_structure(config_file, prompt_file)

        # Build the webhook tool registry from the optional 'tools:' block in bot config.
        allow_local = config['allow_local_webhooks'] or False
        webhook_schemas, webhook_defs = build_tool_registry(config.get('tools') or [], allow_local)

        # Discover MCP tools from any 'mcp_server:' entries in the tools config.
        mcp_entries = [
            e for e in (config.get('tools') or [])
            if isinstance(e, dict) and 'mcp_server' in e
        ]
        if mcp_entries:
            existing_names = set(webhook_defs.keys()) | {'search_messages'}
            mcp_schemas, mcp_defs = [], {}
            try:
                asyncio.get_running_loop()
                logger.warning("MCP discovery skipped: set() called from within an async context.")
            except RuntimeError:
                mcp_schemas, mcp_defs = asyncio.run(discover_mcp_tools(
                    mcp_entries, existing_names, allow_local=allow_local,
                ))
            webhook_schemas = webhook_schemas + mcp_schemas
            webhook_defs = {**webhook_defs, **mcp_defs}

        # Apply parameters to bot:
        return TelegramBot(
            bot_owner       = config['bot_owner'],
            bot_nickname    = config['bot_nickname'],
            bot_initials    = config['bot_initials'],
            chat_model      = config['chat_model'],
            url_model       = config['url_model'],
            token_limit     = config['token_limit'],
            search_limit    = config['search_limit'],
            persona_temp    = config['persona_temp'],
            archive_days    = config['archive_days'],
            persona_prompt  = prompt,
            key_status      = key_status,
            instance_name   = config['instance_name'],
            webhook_schemas = webhook_schemas,
            webhook_defs    = webhook_defs,
        )
