"""
Two-tier conversation archive for TeLLMgramBot.

Tier 1: Key fact extraction - batches of old messages distilled into concise statements,
        grouped by chat + day. Private chats produce single-user rows; group chats produce
        multi-speaker rows with a participants JSON array of contributing user_ids.

Tier 2: Episodic summarization - old Tier 1 rows compressed into thematic digests,
        grouped by chat + month.

Raw messages are never deleted; archived_at flags rows to skip during context loading.
Search still hits raw rows regardless of archived_at.
"""
import json
import logging

import aiosqlite

from .database import get_db_path
from .providers.factory import get_provider
from .utils import cutoff_iso, now_iso

logger = logging.getLogger(__name__)

_archival_running = False

_TIER1_PROMPT = (
    "Extract key facts from this conversation. "
    "Ignore greetings, acknowledgments, and filler. "
    "Return one concise factual statement per line, no numbering. "
    "Only include meaningful, specific information. "
    "Keep each statement under 20 words.\n\n"
    "Conversation:\n{conversation}"
)

_TIER2_PROMPT = (
    "Summarize these key facts into a concise thematic digest. "
    "Group related facts together into 2-5 sentences. "
    "Be specific, not generic. Do not use bullet points.\n\n"
    "Key facts:\n{facts}"
)


async def run_archival(config: dict) -> None:
    """
    Run Tier 1 and Tier 2 archival passes. No-op if already running.

    Called at bot startup and lazily when search_messages hits the result cap.

    Args:
        config: Dict with keys: chat_model, and optionally archive_days.
    """
    global _archival_running
    if _archival_running:
        return
    _archival_running = True
    try:
        await _run_tier1(config)
        await _run_tier2(config)
    except Exception as e:
        logger.error(f"Archival run failed: {e}", exc_info=True)
    finally:
        _archival_running = False


def _get_model(config: dict) -> str:
    """Return the chat_model from config, or empty string if not set."""
    return config.get('chat_model', '')


def _get_archive_days(config: dict) -> int:
    """Return validated archive_days from config, falling back to 60 on invalid values."""
    _ad = config.get('archive_days')
    if _ad is not None:
        try:
            days = int(_ad)
            if days >= 1:
                return days
        except (TypeError, ValueError):
            pass
        logger.warning(f"ARCHIVE: invalid archive_days '{_ad}', using default 60")
    return 60


def _fmt_ts(ts: str) -> str:
    if not ts:
        return ''
    return ts[:16].replace('T', ' ') + ' UTC'


async def _run_tier1(config: dict) -> None:
    """
    Extract key facts from messages older than archive_days into Tier 1 rows.

    Groups old messages by chat and day, batches each group through the LLM with
    _TIER1_PROMPT, stores the extracted facts as summary_archive rows, and flags
    source rows with archived_at. Logs warnings on batch failures but continues
    processing other batches.

    Args:
        config: Dict with keys: chat_model, and optionally archive_days.
    """
    model = _get_model(config)
    if not model:
        logger.warning("ARCHIVE: no model configured, skipping Tier 1")
        return

    after_days = _get_archive_days(config)

    async with aiosqlite.connect(get_db_path()) as db:
        cursor = await db.execute(
            """
            SELECT m.id, m.chat_id, m.user_id, m.role, m.content, m.created_at,
                   u.first_name, u.username
            FROM messages m
            LEFT JOIN users u ON m.user_id = u.user_id
            WHERE m.archived_at IS NULL AND m.is_private = 0
              AND m.created_at < ?
            ORDER BY m.chat_id, date(m.created_at), m.created_at ASC, m.id ASC
            """,
            (cutoff_iso(after_days),),
        )
        raw_rows = await cursor.fetchall()

    if not raw_rows:
        return

    batches: dict[tuple, list] = {}
    for row in raw_rows:
        key = (row[1], row[5][:10])  # (chat_id, YYYY-MM-DD)
        batches.setdefault(key, []).append(row)

    provider = get_provider(model)
    for (chat_id, day), batch in batches.items():
        try:
            await _process_tier1_batch(provider, model, chat_id, day, batch)
        except Exception as e:
            logger.warning(f"ARCHIVE: Tier 1 batch {chat_id}/{day} failed: {e}")


async def _process_tier1_batch(provider, model: str, chat_id: int, day: str, rows: list) -> None:
    """
    Extract key facts from a single day's batch of messages via LLM.

    Formats messages with speaker/timestamp annotations, calls the provider with
    _TIER1_PROMPT, inserts the result as a summary_archive row (tier 1), and marks
    source rows with archived_at. For private chats (chat_id > 0), stores as a
    single-user row; for groups, extracts participant user_ids and stores as
    multi-speaker row with participants JSON array.

    Args:
        provider: LLM provider instance (e.g., from get_provider).
        model: Model name to pass to provider.complete().
        chat_id: Telegram chat ID.
        day: YYYY-MM-DD date string (used for logging).
        rows: List of message tuples from the database query.
    """
    # rows: (id, chat_id, user_id, role, content, created_at, first_name, username)
    lines = []
    for row in rows:
        if row[3] == 'assistant':
            speaker = 'Assistant'
        else:
            first_name, username = row[6], row[7]
            speaker = first_name or (f"@{username}" if username else f"User {row[2]}")
        lines.append(f"[{speaker}, {_fmt_ts(row[5])}]: {row[4]}")

    conversation = '\n'.join(lines)
    messages = [{"role": "user", "content": _TIER1_PROMPT.format(conversation=conversation)}]

    result = await provider.complete(model, messages)
    if not isinstance(result, str) or not result.strip():
        return

    user_ids = sorted({row[2] for row in rows if row[3] == 'user'})
    is_private = chat_id > 0
    if is_private and len(user_ids) == 1:
        archive_user_id = user_ids[0]
        participants_json = None
    else:
        archive_user_id = None
        participants_json = json.dumps(user_ids) if user_ids else None

    covers_from = rows[0][5]
    covers_to = rows[-1][5]
    msg_ids = [row[0] for row in rows]

    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute(
            "INSERT INTO summary_archive "
            "(chat_id, user_id, participants, tier, content, covers_from, covers_to) "
            "VALUES (?, ?, ?, 1, ?, ?, ?)",
            (chat_id, archive_user_id, participants_json, result.strip(), covers_from, covers_to),
        )
        placeholders = ','.join('?' * len(msg_ids))
        await db.execute(
            f"UPDATE messages SET archived_at = ? WHERE id IN ({placeholders})",
            [now_iso()] + msg_ids,
        )
        await db.commit()

    logger.info(
        f"ARCHIVE: Tier 1 stored for chat {chat_id} day {day} "
        f"({len(rows)} messages -> {len(result.splitlines())} facts)"
    )


async def _run_tier2(config: dict) -> None:
    """
    Compress old Tier 1 rows into Tier 2 (episodic) summaries.

    Groups Tier 1 rows older than archive_days * 2 by chat and month, batches each
    group through the LLM with _TIER2_PROMPT, stores the result as a summary_archive
    row (tier 2), and flags source Tier 1 rows with archived_at. Logs warnings on
    batch failures but continues processing other batches.

    Args:
        config: Dict with keys: chat_model, and optionally archive_days.
    """
    model = _get_model(config)
    if not model:
        return

    after_days = _get_archive_days(config)
    episode_days = after_days * 2

    async with aiosqlite.connect(get_db_path()) as db:
        cursor = await db.execute(
            """
            SELECT id, chat_id, user_id, participants, content, covers_from, covers_to
            FROM summary_archive
            WHERE tier = 1 AND archived_at IS NULL
              AND covers_to < ?
            ORDER BY chat_id, strftime('%Y-%m', covers_from), covers_from ASC
            """,
            (cutoff_iso(episode_days),),
        )
        tier1_rows = await cursor.fetchall()

    if not tier1_rows:
        return

    batches: dict[tuple, list] = {}
    for row in tier1_rows:
        key = (row[1], row[5][:7])  # (chat_id, YYYY-MM)
        batches.setdefault(key, []).append(row)

    provider = get_provider(model)
    for (chat_id, month), batch in batches.items():
        try:
            await _process_tier2_batch(provider, model, chat_id, month, batch)
        except Exception as e:
            logger.warning(f"ARCHIVE: Tier 2 batch {chat_id}/{month} failed: {e}")


async def _process_tier2_batch(provider, model: str, chat_id: int, month: str, rows: list) -> None:
    """
    Compress a month's worth of Tier 1 summaries into a single thematic digest.

    Concatenates Tier 1 facts, calls the provider with _TIER2_PROMPT, inserts the
    result as a summary_archive row (tier 2), and marks source Tier 1 rows with
    archived_at. Merges participants from all source rows into a single JSON array
    for the Tier 2 row (unless all rows are attributed to a single user, in which
    case stores as single-user row).

    Args:
        provider: LLM provider instance (e.g., from get_provider).
        model: Model name to pass to provider.complete().
        chat_id: Telegram chat ID.
        month: YYYY-MM month string (used for logging).
        rows: List of Tier 1 archive tuples from the database query.
    """
    # rows: (id, chat_id, user_id, participants, content, covers_from, covers_to)
    facts = '\n'.join(row[4] for row in rows)
    messages = [{"role": "user", "content": _TIER2_PROMPT.format(facts=facts)}]

    result = await provider.complete(model, messages)
    if not isinstance(result, str) or not result.strip():
        return

    all_user_ids: set[int] = set()
    for row in rows:
        if row[2] is not None:
            all_user_ids.add(row[2])
        if row[3]:
            try:
                all_user_ids.update(json.loads(row[3]))
            except (json.JSONDecodeError, TypeError):
                pass

    unique_attributed = {row[2] for row in rows if row[2] is not None}
    has_multi_speaker = any(row[3] for row in rows)
    if len(unique_attributed) == 1 and not has_multi_speaker:
        archive_user_id = next(iter(unique_attributed))
        participants_json = None
    else:
        archive_user_id = None
        participants_json = json.dumps(sorted(all_user_ids)) if all_user_ids else None

    covers_from = rows[0][5]
    covers_to = rows[-1][6]
    source_ids = [row[0] for row in rows]

    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute(
            "INSERT INTO summary_archive "
            "(chat_id, user_id, participants, tier, content, covers_from, covers_to) "
            "VALUES (?, ?, ?, 2, ?, ?, ?)",
            (chat_id, archive_user_id, participants_json, result.strip(), covers_from, covers_to),
        )
        placeholders = ','.join('?' * len(source_ids))
        await db.execute(
            f"UPDATE summary_archive SET archived_at = ? WHERE id IN ({placeholders})",
            [now_iso()] + source_ids,
        )
        await db.commit()

    logger.info(
        f"ARCHIVE: Tier 2 stored for chat {chat_id} month {month} "
        f"({len(rows)} Tier 1 rows -> 1 episode)"
    )
