#!/bin/sh

# Cleanup script for .claude/settings.local.json
# Removes duplicates, fixes path typos, and removes entries covered by broader patterns
#
# Usage: cleanup-settings-local.sh [project-root]
#   project-root: Path to the project root (default: auto-detect from script location)

set -e

# Inline output helpers (no external dependencies)
info() { echo "[INFO] $1"; }
success() { echo "[OK] $1"; }
warning() { echo "[WARN] $1"; }
error() { echo "[ERROR] $1" >&2; }

# Determine project root
if [ -n "$1" ]; then
    PROJECT_ROOT="$1"
elif [ -n "$SCRIPT_DIR" ]; then
    PROJECT_ROOT="$SCRIPT_DIR"
else
    # Auto-detect: walk up from script location
    SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
    # scripts/ -> ai-analyze-permissions/ -> skills/ -> .claude/ -> project-root
    PROJECT_ROOT="$(cd "$SCRIPT_DIR/../../../.." && pwd)"
fi

SETTINGS_FILE="$PROJECT_ROOT/.claude/settings.local.json"
SHARED_SETTINGS_FILE="$HOME/.claude/settings.json"
PROJECT_SETTINGS_FILE="$PROJECT_ROOT/.claude/settings.json"

if [ ! -f "$SETTINGS_FILE" ]; then
    info "No settings.local.json found at $SETTINGS_FILE - nothing to clean"
    exit 0
fi

if ! command -v jq > /dev/null 2>&1; then
    error "jq is required but not installed"
    exit 1
fi

# Validate JSON first
if ! jq empty "$SETTINGS_FILE" > /dev/null 2>&1; then
    error "settings.local.json contains invalid JSON"
    exit 1
fi

BEFORE_COUNT=$(jq '.permissions.allow | length' "$SETTINGS_FILE" 2>/dev/null || echo "0")
info "Found $BEFORE_COUNT permission entries in $SETTINGS_FILE"

# Create backup
cp "$SETTINGS_FILE" "${SETTINGS_FILE}.bak"
info "Backup created at ${SETTINGS_FILE}.bak"

# Extract wildcards from global settings.json (if it exists)
SHARED_WILDCARDS="[]"
if [ -f "$SHARED_SETTINGS_FILE" ]; then
    SHARED_WILDCARDS=$(jq '[.permissions.allow[]? | select(test(":\\*\\)$") or test("\\*\\*\\)$") or test("\\(\\*\\)$"))]' "$SHARED_SETTINGS_FILE" 2>/dev/null || echo "[]")
fi

# Extract wildcards from project settings.json (if it exists and is different from local)
PROJECT_WILDCARDS="[]"
if [ -f "$PROJECT_SETTINGS_FILE" ]; then
    PROJECT_WILDCARDS=$(jq '[.permissions.allow[]? | select(test(":\\*\\)$") or test("\\*\\*\\)$") or test("\\(\\*\\)$"))]' "$PROJECT_SETTINGS_FILE" 2>/dev/null || echo "[]")
fi

# Merge shared and project wildcards
EXTERNAL_WILDCARDS=$(echo "$SHARED_WILDCARDS" "$PROJECT_WILDCARDS" | jq -s 'add | unique')

# Process the settings file:
# 1. Fix double slashes in paths (//Users -> /Users, //Library -> /Library)
# 2. Remove duplicates
# 3. Remove entries covered by broader wildcard patterns (from local, project, and global settings)
jq --argjson external_wildcards "$EXTERNAL_WILDCARDS" '
# Helper function to check if a specific entry is covered by a wildcard pattern
def is_covered_by($wildcards):
    . as $entry |
    any($wildcards[]; . as $pattern |
        # Extract the prefix before the wildcard
        ($pattern |
            if test("^Bash\\(") and test(":\\*\\)$") then
                # Bash pattern like Bash(git commit:*) or Bash(tail:*)
                # Replace :*) with empty string, then trim trailing spaces and
                # re-add one space to ensure word boundary matching.
                # This prevents Bash(tail:*) from matching Bash(tailscale:*)
                # and handles patterns with spaces before the colon like Bash(cargo :*)
                gsub(":\\*\\)$"; "") | gsub("\\s+$"; "") + " "
            elif test(":\\*\\)$") then
                # Non-Bash pattern like WebFetch(https://example.com/*) - keep the colon
                gsub("\\*\\)$"; "")
            elif test("\\*\\*\\)$") then
                # Pattern like Read(/Users/**) - extract "Read(/Users/"
                gsub("\\*\\*\\)$"; "")
            elif test("\\(\\*\\)$") then
                # Pattern like Fetch(*)
                gsub("\\*\\)$"; "")
            else
                null
            end
        ) as $prefix |
        if $prefix != null then
            ($entry | startswith($prefix)) and ($entry != $pattern)
        else
            false
        end
    );

# Fix double slashes in paths
def fix_double_slashes:
    gsub("\\(//(?<path>Users|Library|tmp)"; "(/\(.path)");

.permissions.allow |= (
    # Step 1: Fix double slashes
    map(fix_double_slashes) |

    # Step 2: Remove exact duplicates
    unique |

    # Step 3: Identify wildcard patterns from local file
    . as $all |
    [$all[] | select(test(":\\*\\)$") or test("\\*\\*\\)$") or test("\\(\\*\\)$"))] as $local_wildcards |

    # Step 4: Combine local and external wildcards
    ($local_wildcards + $external_wildcards) as $all_wildcards |

    # Step 5: Filter out entries covered by any wildcards
    [.[] | select(is_covered_by($all_wildcards) | not)]
)
' "$SETTINGS_FILE" > "${SETTINGS_FILE}.tmp"

# Validate the result
if ! jq empty "${SETTINGS_FILE}.tmp" > /dev/null 2>&1; then
    error "Generated invalid JSON - restoring backup"
    mv "${SETTINGS_FILE}.bak" "$SETTINGS_FILE"
    rm -f "${SETTINGS_FILE}.tmp"
    exit 1
fi

mv "${SETTINGS_FILE}.tmp" "$SETTINGS_FILE"

AFTER_COUNT=$(jq '.permissions.allow | length' "$SETTINGS_FILE" 2>/dev/null || echo "0")
REMOVED=$((BEFORE_COUNT - AFTER_COUNT))

if [ "$REMOVED" -gt 0 ]; then
    success "Removed $REMOVED redundant entries ($BEFORE_COUNT -> $AFTER_COUNT)"
else
    success "No redundant entries found"
fi

# Show what wildcards are protecting the remaining entries
info "Active wildcard patterns:"
jq -r '.permissions.allow[] | select(test(":\\*\\)$") or test("\\*\\*\\)$"))' "$SETTINGS_FILE" 2>/dev/null | sort -u | head -20 | while read -r pattern; do
    echo "  - $pattern"
done

echo ""
success "Cleanup complete!"
