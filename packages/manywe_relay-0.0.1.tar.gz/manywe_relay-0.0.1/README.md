# manywe-relay

Official ManyWe placeholder package for future relay-related tooling.

Current utilities:
- normalize ManyWe relay base URLs
- derive `/ws` and `/healthz` endpoints
- normalize lightweight relay health payloads

This package is intentionally small and is not a relay server implementation.
