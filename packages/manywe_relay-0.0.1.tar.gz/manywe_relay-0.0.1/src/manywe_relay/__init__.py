from urllib.parse import urlparse, urlunparse
import json

PACKAGE_NAME = "manywe-relay"
__version__ = "0.0.1"


def normalize_relay_base_url(value: str) -> str:
    parsed = urlparse(value)
    return urlunparse((parsed.scheme, parsed.netloc, "", "", "", "")).rstrip("/")


def relay_ws_url(value: str) -> str:
    parsed = urlparse(normalize_relay_base_url(value))
    scheme = "wss" if parsed.scheme == "https" else "ws"
    return urlunparse((scheme, parsed.netloc, "/ws", "", "", ""))


def relay_health_url(value: str) -> str:
    parsed = urlparse(normalize_relay_base_url(value))
    scheme = "https" if parsed.scheme == "wss" else "http" if parsed.scheme == "ws" else parsed.scheme
    return urlunparse((scheme, parsed.netloc, "/healthz", "", "", ""))


def normalize_health_payload(payload):
    value = json.loads(payload) if isinstance(payload, str) else (payload or {})
    return {
        "status": value.get("status", "unknown") if isinstance(value, dict) else "unknown",
        "checked_at": value.get("checked_at") or value.get("checkedAt") if isinstance(value, dict) else None,
        "metrics": value.get("metrics", {}) if isinstance(value, dict) and isinstance(value.get("metrics", {}), dict) else {},
    }
