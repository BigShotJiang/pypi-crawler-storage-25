"""
Default configuration settings.
"""

import os
from pathlib import Path
from typing import Any


def get_default_config_path() -> str:
    """Get the default configuration file path."""
    config_dir = os.environ.get("AIRCLI_CONFIG_DIR")
    if config_dir:
        return os.path.join(config_dir, "config.yaml")

    home = Path.home()
    return str(home / ".airctl" / "config.yaml")


def get_default_config() -> dict[str, Any]:
    """Get default configuration values."""
    return {
        "version": 1,
        "aliases": {},
        "presets": {},
        "daemon": {
            "auto_start": True,
            "socket_path": None,
            "log_level": "INFO",
        },
        "scan": {
            "default_timeout": 10.0,
        },
        "connection": {
            "default_timeout": 30.0,
        },
    }


DEFAULT_PRESETS: dict[str, dict[str, str]] = {
    "uart": {
        "service": "6E400001-B5A3-F393-E0A9-E50E24DCCA9E",
        "rx_char": "6E400002-B5A3-F393-E0A9-E50E24DCCA9E",
        "tx_char": "6E400003-B5A3-F393-E0A9-E50E24DCCA9E",
    },
    "heart_rate": {
        "service": "180D",
        "measurement": "2A37",
    },
    "battery": {
        "service": "180F",
        "level": "2A19",
    },
    "device_info": {
        "service": "180A",
        "model_number": "2A24",
        "serial_number": "2A25",
        "firmware_revision": "2A26",
        "hardware_revision": "2A27",
        "manufacturer_name": "2A29",
    },
}
