"""
Entry point for running daemon as module: python -m airctl.daemon
"""

import argparse

from airctl.daemon.server import run_daemon


def main() -> None:
    """Main entry point for daemon module."""
    parser = argparse.ArgumentParser(description="BLE Daemon")
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Log level",
    )
    args = parser.parse_args()

    run_daemon(log_level=args.log_level)


if __name__ == "__main__":
    main()
