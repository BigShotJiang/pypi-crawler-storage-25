"""
Main entry point for AirCli.
"""

import typer

from airctl.cli.app import app

__all__ = ["app"]

if __name__ == "__main__":
    app()
