"""
Data models for AirCli.
"""

from airctl.models.device import BLEDeviceInfo, ConnectedDevice
from airctl.models.events import (
    BaseEvent,
    DeviceConnectedEvent,
    DeviceDisconnectedEvent,
    DeviceFoundEvent,
    ErrorEvent,
    NotificationEvent,
)
from airctl.models.gatt import (
    CharacteristicInfo,
    DescriptorInfo,
    ServiceInfo,
)
from airctl.models.protocol import JSONRPCError, JSONRPCRequest, JSONRPCResponse

__all__ = [
    "BLEDeviceInfo",
    "ConnectedDevice",
    "BaseEvent",
    "DeviceFoundEvent",
    "DeviceConnectedEvent",
    "DeviceDisconnectedEvent",
    "NotificationEvent",
    "ErrorEvent",
    "ServiceInfo",
    "CharacteristicInfo",
    "DescriptorInfo",
    "JSONRPCRequest",
    "JSONRPCResponse",
    "JSONRPCError",
]
