"""
Device-related data models.
"""

from typing import Any, Optional

from pydantic import BaseModel, Field


class BLEDeviceInfo(BaseModel):
    """Information about a BLE device discovered during scanning."""

    address: str = Field(..., description="Device Bluetooth address (MAC or UUID)")
    name: Optional[str] = Field(None, description="Device name")
    rssi: int = Field(..., description="Signal strength in dBm")
    service_uuids: list[str] = Field(default_factory=list, description="Service UUIDs advertised")
    manufacturer_data: dict[int, str] = Field(
        default_factory=dict, description="Manufacturer data (hex encoded)"
    )
    service_data: dict[str, str] = Field(
        default_factory=dict, description="Service data (hex encoded)"
    )
    local_name: Optional[str] = Field(None, description="Local name from advertisement")
    tx_power: Optional[int] = Field(None, description="Transmission power level")

    model_config = {"populate_by_name": True}


class ConnectedDevice(BaseModel):
    """Information about a connected device."""

    address: str = Field(..., description="Device Bluetooth address")
    name: Optional[str] = Field(None, description="Device name")
    alias: Optional[str] = Field(None, description="User-defined alias")
    mtu_size: int = Field(default=23, description="Negotiated MTU size")
    connected_at: float = Field(..., description="Connection timestamp (Unix epoch)")
    services_discovered: bool = Field(
        default=False, description="Whether GATT services have been discovered"
    )

    model_config = {"populate_by_name": True}
