"""
Platform detection utilities.
"""

import platform
from enum import Enum


class Platform(str, Enum):
    """Supported platforms."""

    WINDOWS = "windows"
    LINUX = "linux"
    MACOS = "macos"
    UNKNOWN = "unknown"


def get_platform() -> Platform:
    """Detect the current platform."""
    system = platform.system()
    if system == "Windows":
        return Platform.WINDOWS
    elif system == "Linux":
        return Platform.LINUX
    elif system == "Darwin":
        return Platform.MACOS
    return Platform.UNKNOWN


def is_windows() -> bool:
    """Check if running on Windows."""
    return get_platform() == Platform.WINDOWS


def is_linux() -> bool:
    """Check if running on Linux."""
    return get_platform() == Platform.LINUX


def is_macos() -> bool:
    """Check if running on macOS."""
    return get_platform() == Platform.MACOS
