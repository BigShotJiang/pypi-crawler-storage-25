"""
Common utilities for AirCli.
"""

from airctl.common.logging import setup_logging
from airctl.common.platform import get_platform, is_windows, is_linux, is_macos
from airctl.common.utils import get_timestamp, generate_request_id

__all__ = [
    "setup_logging",
    "get_platform",
    "is_windows",
    "is_linux",
    "is_macos",
    "get_timestamp",
    "generate_request_id",
]
