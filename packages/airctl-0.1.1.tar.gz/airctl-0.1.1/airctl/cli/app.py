"""
Main CLI application definition.
"""

import typer
from rich.console import Console

from airctl.cli import ble, config, daemon, doctor

app = typer.Typer(
    name="airctl",
    help="AI-friendly CLI tool for device control via Bluetooth and more",
    add_completion=False,
    rich_markup_mode="rich",
)

console = Console()

app.add_typer(daemon.app, name="daemon")
app.add_typer(ble.app, name="ble")
app.add_typer(config.app, name="config")
app.add_typer(doctor.app, name="doctor")


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-v", help="Show version and exit"
    ),
) -> None:
    """AirCtl - AI-friendly CLI tool for device control."""
    if version:
        from airctl import __version__

        console.print(f"airctl version {__version__}")
        raise typer.Exit()
    
    if ctx.invoked_subcommand is None:
        console.print(ctx.get_help())
        raise typer.Exit()
