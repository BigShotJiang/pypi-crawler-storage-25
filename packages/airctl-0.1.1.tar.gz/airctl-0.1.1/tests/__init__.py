"""
Tests for AirCli.
"""
