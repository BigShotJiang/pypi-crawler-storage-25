"""
Tests for IPC protocol.
"""

import pytest

from airctl.ipc.protocol import IPCProtocol, IPCError, IPCErrorCode
from airctl.models.protocol import JSONRPCRequest, JSONRPCResponse


class TestIPCProtocol:
    """Tests for IPCProtocol class."""

    def test_create_request(self):
        """Test request creation."""
        protocol = IPCProtocol()
        request = protocol.create_request("test.method", {"param": "value"})

        assert request.jsonrpc == "2.0"
        assert request.method == "test.method"
        assert request.params == {"param": "value"}
        assert request.id == 1

    def test_create_request_auto_increment(self):
        """Test request ID auto-increment."""
        protocol = IPCProtocol()
        request1 = protocol.create_request("method1")
        request2 = protocol.create_request("method2")

        assert request2.id == request1.id + 1

    def test_create_response_success(self):
        """Test success response creation."""
        protocol = IPCProtocol()
        response = protocol.create_response(1, result={"data": "value"})

        assert response.jsonrpc == "2.0"
        assert response.id == 1
        assert response.result == {"data": "value"}
        assert response.error is None

    def test_create_response_error(self):
        """Test error response creation."""
        protocol = IPCProtocol()
        response = protocol.create_error_response(1, -32000, "Test error")

        assert response.jsonrpc == "2.0"
        assert response.id == 1
        assert response.result is None
        assert response.error.code == -32000
        assert response.error.message == "Test error"

    def test_serialize_request(self):
        """Test request serialization."""
        protocol = IPCProtocol()
        request = JSONRPCRequest(id=1, method="test", params={"key": "value"})
        data = protocol.serialize(request)

        assert b'"jsonrpc":"2.0"' in data
        assert b'"method":"test"' in data
        assert data.endswith(b"\n")

    def test_deserialize_request(self):
        """Test request deserialization."""
        protocol = IPCProtocol()
        data = b'{"jsonrpc":"2.0","id":1,"method":"test","params":{"key":"value"}}\n'
        request = protocol.deserialize(data)

        assert isinstance(request, JSONRPCRequest)
        assert request.method == "test"
        assert request.params == {"key": "value"}

    def test_deserialize_response(self):
        """Test response deserialization."""
        protocol = IPCProtocol()
        data = b'{"jsonrpc":"2.0","id":1,"result":{"status":"ok"}}\n'
        response = protocol.deserialize(data)

        assert isinstance(response, JSONRPCResponse)
        assert response.result == {"status": "ok"}


class TestIPCError:
    """Tests for IPCError exception."""

    def test_ipc_error_creation(self):
        """Test IPCError creation."""
        error = IPCError(code=-32000, message="Test error", data={"extra": "info"})

        assert error.code == -32000
        assert error.message == "Test error"
        assert error.data == {"extra": "info"}
        assert "Test error" in str(error)
