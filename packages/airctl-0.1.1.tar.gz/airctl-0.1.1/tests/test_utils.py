"""
Tests for utility functions.
"""

import pytest

from airctl.common.utils import (
    bytes_to_hex,
    hex_to_bytes,
    bytes_to_base64,
    base64_to_bytes,
    parse_data_input,
    format_data_output,
)


class TestByteConversions:
    """Tests for byte conversion utilities."""

    def test_bytes_to_hex(self):
        """Test bytes to hex conversion."""
        assert bytes_to_hex(b"\x01\x02\x03") == "010203"
        assert bytes_to_hex(b"") == ""

    def test_hex_to_bytes(self):
        """Test hex to bytes conversion."""
        assert hex_to_bytes("010203") == b"\x01\x02\x03"
        assert hex_to_bytes("") == b""

    def test_bytes_to_base64(self):
        """Test bytes to base64 conversion."""
        assert bytes_to_base64(b"\x01\x02\x03") == "AQID"
        assert bytes_to_base64(b"hello") == "aGVsbG8="

    def test_base64_to_bytes(self):
        """Test base64 to bytes conversion."""
        assert base64_to_bytes("AQID") == b"\x01\x02\x03"
        assert base64_to_bytes("aGVsbG8=") == b"hello"

    def test_roundtrip(self):
        """Test roundtrip conversions."""
        original = b"\x01\x02\x03\x04\x05"
        assert hex_to_bytes(bytes_to_hex(original)) == original
        assert base64_to_bytes(bytes_to_base64(original)) == original


class TestDataInputParsing:
    """Tests for data input parsing."""

    def test_parse_hex_prefix(self):
        """Test hex: prefix parsing."""
        assert parse_data_input("hex:010203") == b"\x01\x02\x03"

    def test_parse_text_prefix(self):
        """Test text: prefix parsing."""
        assert parse_data_input("text:hello") == b"hello"

    def test_parse_base64_prefix(self):
        """Test base64: prefix parsing."""
        assert parse_data_input("base64:AQID") == b"\x01\x02\x03"

    def test_parse_default_hex(self):
        """Test default hex parsing."""
        assert parse_data_input("010203") == b"\x01\x02\x03"


class TestDataOutputFormatting:
    """Tests for data output formatting."""

    def test_format_hex(self):
        """Test hex formatting."""
        assert format_data_output(b"\x01\x02\x03", "hex") == "010203"

    def test_format_base64(self):
        """Test base64 formatting."""
        assert format_data_output(b"\x01\x02\x03", "base64") == "AQID"

    def test_format_text(self):
        """Test text formatting."""
        assert format_data_output(b"hello", "text") == "hello"

    def test_format_text_fallback(self):
        """Test text formatting with binary data fallback."""
        result = format_data_output(b"\x01\x02\x03", "text")
        assert result == "010203"
