"""
Pytest configuration for AirCli tests.
"""

import pytest


@pytest.fixture
def temp_config_dir(tmp_path):
    """Create a temporary config directory."""
    config_dir = tmp_path / ".airctl"
    config_dir.mkdir()
    return config_dir
