"""On-disk handoff for per-branch CHALK_MODEL_ENDPOINT_CONFIG.

The supervisor (in chalkengine) writes the snapshot here; the idle-actor
subprocess (this package) reads it before graph import so its libchalk
catalog matches the deployment's view of the world. Both halves of the
handoff live in this module so the contract is testable end-to-end without
spinning up an actor.
"""

from __future__ import annotations

import os

import pytest

from chalkruntime.server.branch_model_endpoint_config import (
    apply_local_snapshot_if_present,
    local_snapshot_path,
    write_local_snapshot,
)


class _ReinitRecorder:
    """Captures whatever JSON the reader hands to libchalk.

    The real ``reinitialize_global_catalog_runtime`` parses the JSON itself,
    so the reader must hand it the exact wire bytes, not a re-encoded
    string. Tests assert byte-equality through this recorder.
    """

    def __init__(self):
        self.calls: list[str] = []

    def __call__(self, model_config: str) -> None:
        self.calls.append(model_config)


@pytest.fixture(autouse=True)
def _scoped_snapshot_root(tmp_path, monkeypatch):
    monkeypatch.setenv("CHALK_BRANCH_CATALOG_SNAPSHOT_ROOT", str(tmp_path))
    yield tmp_path


def test_path_is_deterministic_and_scoped_by_ids(_scoped_snapshot_root):
    # The supervisor writer and the actor reader compute the path
    # independently; if they disagree the handoff is silently broken.
    path = local_snapshot_path("env_xyz", "dep_abc")
    assert path == str(_scoped_snapshot_root / "env_env_xyz" / "dep_dep_abc" / "model_endpoint_config.json")


def test_write_then_apply_round_trips_payload_byte_equal():
    payload = b'{"ner_extract": {"uri": "env-ner.example:443", "output_dtype": "dt=="}}'

    write_local_snapshot("abc", "123", payload)

    recorder = _ReinitRecorder()
    applied = apply_local_snapshot_if_present("abc", "123", reinitialize=recorder)

    assert applied is True
    assert recorder.calls == [payload.decode("utf-8")]


def test_apply_returns_false_when_no_file_exists():
    # Missing snapshot is the steady state for envs without model SGs —
    # must be a quiet no-op, not a raise, and must not clobber the catalog.
    recorder = _ReinitRecorder()
    assert apply_local_snapshot_if_present("abc", "never-deployed", reinitialize=recorder) is False
    assert recorder.calls == []


def test_empty_payload_is_not_written():
    # We must never blank the catalog of a future reader. An empty payload
    # therefore must not create a file at all — apply on the next read sees
    # FileNotFoundError and falls back to the boot env catalog.
    written = write_local_snapshot("abc", "123", b"")
    assert written is None
    assert not os.path.exists(local_snapshot_path("abc", "123"))


def test_write_is_atomic_under_rename(_scoped_snapshot_root):
    # The reader must never see a half-written file. We rely on os.replace
    # for atomicity; pin that the temporary scratch file is gone after a
    # successful write so the directory only contains the final artifact.
    write_local_snapshot("abc", "123", b'{"svc":{"uri":"x:1"}}')
    parent = os.path.dirname(local_snapshot_path("abc", "123"))
    entries = os.listdir(parent)
    assert entries == ["model_endpoint_config.json"]


def test_overwrite_yields_latest_payload():
    # A later branch deploy for the same deployment id (rare but possible
    # on retry) must replace the file rather than append.
    write_local_snapshot("abc", "123", b'{"old":{"uri":"o:1"}}')
    write_local_snapshot("abc", "123", b'{"new":{"uri":"n:1"}}')

    recorder = _ReinitRecorder()
    applied = apply_local_snapshot_if_present("abc", "123", reinitialize=recorder)

    assert applied is True
    assert recorder.calls == ['{"new":{"uri":"n:1"}}']


def test_reinit_failure_is_swallowed():
    # libchalk-side errors during reinit must not crash the actor; the actor
    # falls back to its boot env catalog and the load proceeds (and likely
    # fails downstream with a clearer error message during validation).
    write_local_snapshot("abc", "123", b'{"svc":{"uri":"x:1"}}')

    def broken_reinit(_: str) -> None:
        raise RuntimeError("libchalk catalog explosion")

    assert apply_local_snapshot_if_present("abc", "123", reinitialize=broken_reinit) is False


def test_apply_resets_chalkdf_catalog_python_singleton(monkeypatch):
    # The reinit replaces the C++ global CatalogRuntime, but the chalkdf
    # Python Catalog singleton wraps a shared_ptr captured at first access.
    # Without reset_local(), get_active_catalog() keeps returning the stale
    # wrapper and underscore validation never sees the refreshed catalog —
    # this is what caused the "model.<sg> not found in catalog" symptom
    # during supervisor-side graph load. Pin that the reset runs after a
    # successful reinit.
    from chalkdf import catalog as chalkdf_catalog

    reset_calls: list[int] = []
    monkeypatch.setattr(chalkdf_catalog.Catalog, "reset_local", staticmethod(lambda: reset_calls.append(1)))

    write_local_snapshot("abc", "123", b'{"svc":{"uri":"x:1"}}')
    recorder = _ReinitRecorder()

    assert apply_local_snapshot_if_present("abc", "123", reinitialize=recorder) is True
    assert reset_calls == [1]


def test_apply_does_not_reset_when_no_snapshot(monkeypatch):
    # Reset is gated on a successful reinit. With no file to read we leave
    # everything untouched — the cached Python wrapper is still valid
    # against the boot env catalog, and reset would force a needless rebuild
    # on the next access.
    from chalkdf import catalog as chalkdf_catalog

    reset_calls: list[int] = []
    monkeypatch.setattr(chalkdf_catalog.Catalog, "reset_local", staticmethod(lambda: reset_calls.append(1)))

    recorder = _ReinitRecorder()
    assert apply_local_snapshot_if_present("abc", "never-deployed", reinitialize=recorder) is False
    assert reset_calls == []


def test_env_var_overrides_root(monkeypatch, tmp_path):
    # The whole point of CHALK_BRANCH_CATALOG_SNAPSHOT_ROOT is to let the
    # operator point this at a real persistent dir (e.g. an emptyDir volume)
    # without recompiling. Pin that the env var actually moves the path.
    custom = tmp_path / "custom-root"
    monkeypatch.setenv("CHALK_BRANCH_CATALOG_SNAPSHOT_ROOT", str(custom))
    assert local_snapshot_path("abc", "123").startswith(str(custom))
