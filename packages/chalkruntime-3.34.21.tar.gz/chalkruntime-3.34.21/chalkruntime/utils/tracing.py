from __future__ import annotations

import os
from threading import Lock
from typing import TYPE_CHECKING, Callable, Optional

from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import SpanProcessor
from opentelemetry.sdk.trace import TracerProvider as ConfigurableTracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from libchalk.rust_otel.chalk_otel import RustBatchedGrpcSpanExporter as UnderlyingExporter

if TYPE_CHECKING:
    from opentelemetry.context import Context
    from opentelemetry.sdk.trace import ReadableSpan, Span

_TRUTHY_VALUES = {"1", "true", "yes", "t", "y"}
_FALSY_VALUES = {"0", "false", "no", "f", "n"}


def env_var_bool(env_name: str, default: bool = False) -> bool:
    var = os.environ.get(env_name)
    if var is None:
        return default
    if var.lower() in _TRUTHY_VALUES:
        return True
    return False


class Once:
    """Execute a function exactly once and block all callers until the function returns

    Same as golang's `sync.Once <https://pkg.go.dev/sync#Once>`_
    """

    def __init__(self) -> None:
        self._lock = Lock()
        self._done = False
        super().__init__()

    def do_once(self, func: Callable[[], None]) -> bool:
        """Execute ``func`` if it hasn't been executed or return.

        Will block until ``func`` has been called by one thread.

        Returns:
            Whether or not ``func`` was executed in this call
        """

        # fast path, try to avoid locking
        if self._done:
            return False

        with self._lock:
            if not self._done:
                func()
                self._done = True
                return True
        return False


_TRACING_CONFIGURED = Once()
CHALK_SERVICE_ENV_VAR = "CHALK_SERVICE"


class BatchedRustGrpcSpanExporter(SpanProcessor):
    def __init__(
        self,
        endpoint: Optional[str] = None,
        insecure: Optional[bool] = None,
        export_timeout_millis: Optional[int] = None,
    ):
        super().__init__()
        self._underlying = UnderlyingExporter(
            endpoint,
            insecure,
            export_timeout_millis=export_timeout_millis or 10000,
        )

    def on_start(
        self,
        span: Span,
        parent_context: Optional[Context] = None,
    ) -> None:
        self._underlying.on_start(span, parent_context)

    def on_end(self, span: ReadableSpan) -> None:
        self._underlying.on_end(span)

    def shutdown(self) -> None:
        self._underlying.shutdown()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return self._underlying.force_flush(timeout_millis)


def service_name_for_tracing(default_service_name: str) -> str:
    return os.environ.get(CHALK_SERVICE_ENV_VAR) or default_service_name


def configure_tracing(default_service_name: str):
    def do_configure_tracing():
        pod_name = os.environ.get("HOSTNAME", "unknown")
        resource_group = os.environ.get("CHALK_RESOURCE_GROUP", "default")
        service_name = service_name_for_tracing(default_service_name)

        resources = Resource.create(
            attributes={
                "pod_name": pod_name,
                "resource_group": resource_group,
                "service.name": service_name,
            }
        )

        # FastAPI - optional, only if package is available
        try:
            from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor

            FastAPIInstrumentor().instrument()
        except ImportError:
            pass

        # Requests
        try:
            from opentelemetry.instrumentation.requests import RequestsInstrumentor

            RequestsInstrumentor().instrument()
        except ImportError:
            pass

        # HTTPX
        try:
            from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor

            HTTPXClientInstrumentor().instrument()
        except ImportError:
            pass

        # PyMongo
        try:
            from opentelemetry.instrumentation.pymongo import PymongoInstrumentor

            PymongoInstrumentor().instrument()
        except ImportError:
            pass

        # PyMySQL
        try:
            from opentelemetry.instrumentation.pymysql import PyMySQLInstrumentor

            PyMySQLInstrumentor().instrument()
        except ImportError:
            pass

        # Psycopg2
        try:
            from opentelemetry.instrumentation.psycopg2 import Psycopg2Instrumentor

            Psycopg2Instrumentor().instrument()
        except ImportError:
            pass

        provider = ConfigurableTracerProvider(
            resource=resources,
        )
        if os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT", None) is not None:
            if env_var_bool("CHALK_USE_PYTHON_OTLP_EXPORTER"):
                provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
            else:
                provider.add_span_processor(BatchedRustGrpcSpanExporter())

        trace.set_tracer_provider(provider)

    _TRACING_CONFIGURED.do_once(do_configure_tracing)
