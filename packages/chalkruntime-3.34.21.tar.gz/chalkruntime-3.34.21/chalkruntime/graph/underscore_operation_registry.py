from typing import Any, Sequence, Type

import pyarrow as pa
import pyarrow.compute as pc
from frozendict import frozendict

from chalkruntime.graph.underscore import UnderscoreOperation
from chalkruntime.graph.underscore_codec_info import FromPythonRegCodecInfo


class UnderscoreOperationRegistry:
    @staticmethod
    def resolve(function_name: str, params: frozendict[str, object]):
        match function_name:
            case "cast":
                return UnderscoreOperationRegistry._cast(params)
            case "struct_pack":
                return UnderscoreOperationRegistry._struct_pack(params)
            case "get_struct_subfield":
                return UnderscoreOperationRegistry._get_struct_subfield(params)
            case "chalk_execution_ts":
                # fixed functions, no params
                return UnderscoreOperationRegistry._chalk_execution_ts()
            case "catalog_call":
                return UnderscoreOperationRegistry._catalog_call(params)
            case "call_resolver":
                return UnderscoreOperationRegistry._call_resolver(params)
            case _:
                raise KeyError(f"UnderscoreOperationRegistry: trying to resolve unknown function {function_name=}")

    @staticmethod
    def __type_error_str(fn_name: str, param_name: str, exp_type: Type, param_value: object) -> str:
        return f"UnderscoreOperationRegistry: while resolving '{fn_name}', expect parameter {param_name} to be of type {exp_type} but instead got {param_value} of type {type(param_value).__name__}"

    @staticmethod
    def __key_error_str(fn_name: str, required_param_name: str, params: frozendict[str, object]) -> str:
        return f"UnderscoreOperationRegistry: while resolving '{fn_name}', did not find required parameter {required_param_name} in {params=}"

    @staticmethod
    def _cast(params: frozendict[str, object]) -> UnderscoreOperation:
        # Lint _chalk__to_type: pa.DataType
        if "_chalk__to_type" not in params:
            raise KeyError(
                UnderscoreOperationRegistry.__key_error_str(
                    fn_name="cast", required_param_name="_chalk__to_type", params=params
                )
            )
        _chalk__to_type = params["_chalk__to_type"]
        if not isinstance(_chalk__to_type, pa.DataType):
            raise ValueError(
                UnderscoreOperationRegistry.__type_error_str(
                    fn_name="cast", param_name="_chalk__to_type", exp_type=pa.DataType, param_value=_chalk__to_type
                )
            )

        codec_info = FromPythonRegCodecInfo(
            function_name="cast",
            params=frozendict(
                {"_chalk__to_type": _chalk__to_type},
            ),
        )

        return UnderscoreOperation(
            operation_name="cast",
            return_type=lambda _: _chalk__to_type,
            fn=lambda x: pc.cast(x, _chalk__to_type),
            codec_info=codec_info,
        )

    @staticmethod
    def _struct_pack(params: frozendict[str, object]) -> UnderscoreOperation:
        # Lint names: Sequence[str]
        if "names" not in params:
            raise KeyError(
                UnderscoreOperationRegistry.__key_error_str(
                    fn_name="struct_pack", required_param_name="names", params=params
                )
            )
        names = params["names"]
        if not isinstance(names, Sequence):
            raise ValueError(
                UnderscoreOperationRegistry.__type_error_str(
                    fn_name="struct_pack", param_name="names", exp_type=Sequence, param_value=names
                )
            )

        # Check each element in names is a string
        for i, name in enumerate(names):
            if not isinstance(name, str):
                raise ValueError(
                    f"UnderscoreOperationRegistry: while resolving 'struct_pack', expect each element of names to be str but element at index {i} is {name} of type {type(name).__name__}"
                )

        # Lint types: Sequence[pa.DataType]
        if "types" not in params:
            raise KeyError(
                UnderscoreOperationRegistry.__key_error_str(
                    fn_name="struct_pack", required_param_name="types", params=params
                )
            )
        types = params["types"]
        if not isinstance(types, Sequence):
            raise ValueError(
                UnderscoreOperationRegistry.__type_error_str(
                    fn_name="struct_pack", param_name="types", exp_type=Sequence, param_value=types
                )
            )

        # Check each element in types is a pa.DataType
        for i, type_val in enumerate(types):
            if not isinstance(type_val, pa.DataType):
                raise ValueError(
                    f"UnderscoreOperationRegistry: while resolving 'struct_pack', expect each element of types to be pa.DataType but element at index {i} is {type_val} of type {type(type_val).__name__}"
                )

        codec_info = FromPythonRegCodecInfo(
            function_name="struct_pack",
            params=frozendict(
                {
                    "names": tuple(names),
                    "types": tuple(types),
                }
            ),
        )

        return UnderscoreOperation(
            operation_name="struct_pack",
            return_type=lambda _: pa.struct(
                {name: type for name, type in zip(names, types)}  # ty: ignore[invalid-argument-type]
            ),
            fn=_struct_pack_python_op,
            codec_info=codec_info,
        )

    @staticmethod
    def _get_struct_subfield(params: frozendict[str, object]) -> UnderscoreOperation:
        # Lint return_type: pa.DataType
        if "return_type" not in params:
            raise KeyError(
                UnderscoreOperationRegistry.__key_error_str(
                    fn_name="get_struct_subfield", required_param_name="return_type", params=params
                )
            )
        return_type = params["return_type"]
        if not isinstance(return_type, pa.DataType):
            raise ValueError(
                UnderscoreOperationRegistry.__type_error_str(
                    fn_name="get_struct_subfield",
                    param_name="return_type",
                    exp_type=pa.DataType,
                    param_value=return_type,
                )
            )

        codec_info = FromPythonRegCodecInfo(
            function_name="get_struct_subfield",
            params=frozendict(
                {
                    "return_type": return_type,
                }
            ),
        )

        return UnderscoreOperation(
            operation_name="get_struct_subfield",
            return_type=lambda _: return_type,
            fn=lambda s, k: getattr(s, k, None),
            codec_info=codec_info,
        )

    @staticmethod
    def _chalk_execution_ts() -> UnderscoreOperation:
        codec_info = FromPythonRegCodecInfo(function_name="chalk_execution_ts", params=frozendict())
        return UnderscoreOperation(
            operation_name="chalk_execution_ts",
            return_type=lambda _: pa.timestamp("us", "UTC"),
            resolved_overload=None,  # Technically not a function but a shorthand for "get this specific bindparam"
            convert_input_errors_to_none=False,
            fn=None,
            codec_info=codec_info,
        )

    @staticmethod
    def _catalog_call(params: frozendict[str, object]) -> UnderscoreOperation:
        # Lint qualified_name: str
        if "qualified_name" not in params:
            raise KeyError(
                UnderscoreOperationRegistry.__key_error_str(
                    fn_name="catalog_call", required_param_name="qualified_name", params=params
                )
            )
        qualified_name = params["qualified_name"]
        if not isinstance(qualified_name, str):
            raise ValueError(
                UnderscoreOperationRegistry.__type_error_str(
                    fn_name="catalog_call", param_name="qualified_name", exp_type=str, param_value=qualified_name
                )
            )

        # Lint output_type: pa.DataType
        if "output_type" not in params:
            raise KeyError(
                UnderscoreOperationRegistry.__key_error_str(
                    fn_name="catalog_call", required_param_name="output_type", params=params
                )
            )
        output_type = params["output_type"]
        if not isinstance(output_type, pa.DataType):
            raise ValueError(
                UnderscoreOperationRegistry.__type_error_str(
                    fn_name="catalog_call", param_name="output_type", exp_type=pa.DataType, param_value=output_type
                )
            )

        codec_info = FromPythonRegCodecInfo(
            function_name="catalog_call",
            params=frozendict(
                {
                    "qualified_name": qualified_name,
                    "output_type": output_type,
                }
            ),
        )

        return UnderscoreOperation(
            operation_name="catalog_call",
            return_type=lambda _: output_type,
            resolved_overload=None,  # catalog_call is a blocking function, not a standard overload
            convert_input_errors_to_none=False,
            fn=None,  # No Python fallback for remote catalog calls
            codec_info=codec_info,
        )

    @staticmethod
    def _call_resolver(params: frozendict[str, object]) -> UnderscoreOperation:
        # Lint resolver_fqn: str
        if "resolver_fqn" not in params:
            raise KeyError(
                UnderscoreOperationRegistry.__key_error_str(
                    fn_name="call_resolver", required_param_name="resolver_fqn", params=params
                )
            )
        resolver_fqn = params["resolver_fqn"]
        if not isinstance(resolver_fqn, str):
            raise ValueError(
                UnderscoreOperationRegistry.__type_error_str(
                    fn_name="call_resolver", param_name="resolver_fqn", exp_type=str, param_value=resolver_fqn
                )
            )

        # Lint output_type: pa.DataType
        if "output_type" not in params:
            raise KeyError(
                UnderscoreOperationRegistry.__key_error_str(
                    fn_name="call_resolver", required_param_name="output_type", params=params
                )
            )
        output_type = params["output_type"]
        if not isinstance(output_type, pa.DataType):
            raise ValueError(
                UnderscoreOperationRegistry.__type_error_str(
                    fn_name="call_resolver", param_name="output_type", exp_type=pa.DataType, param_value=output_type
                )
            )

        codec_info = FromPythonRegCodecInfo(
            function_name="call_resolver",
            params=frozendict(
                {
                    "resolver_fqn": resolver_fqn,
                    "output_type": output_type,
                }
            ),
        )

        return UnderscoreOperation(
            operation_name="call_resolver",
            return_type=lambda _: output_type,
            resolved_overload=None,
            convert_input_errors_to_none=False,
            fn=None,
            codec_info=codec_info,
        )


def _struct_pack_python_op(names: list[str], *args: Any) -> dict[str, Any]:
    return {name: arg for name, arg in zip(names, args, strict=True)}
