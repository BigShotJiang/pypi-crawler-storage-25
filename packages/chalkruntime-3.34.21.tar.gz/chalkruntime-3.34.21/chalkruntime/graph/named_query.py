import warnings
from collections import defaultdict
from dataclasses import dataclass
from typing import Collection, Iterable, Mapping, cast

from chalk.utils.log_with_context import get_logger

_logger = get_logger(__name__)


def warning_to_log(
    message: str, category: str, filename: str, lineno: int, file: str | None = None, line: int | None = None
) -> None:
    _logger.warning(message)


warnings.showwarning = warning_to_log  # ty:ignore[invalid-assignment]


def _display_name(name: str, version: str | None) -> str:
    if version is None:
        return name + " (no version)"
    else:
        return f"{name} (v{version})"


@dataclass(frozen=True, repr=False, slots=True)
class NamedQueryParsed:
    name: str
    """
    The name of the query
    """

    version: str | None
    """
    The version of the query
    """

    input: tuple[str, ...] | None
    """
    The features which will be provided by callers of this query.
    For example, `[User.id]`. Features can also be expressed as snakecased strings,
    e.g. `["user.id"]`.
    """

    output: tuple[str, ...] | None
    """
    Outputs are the features that you'd like to compute from the inputs.
    For example, `[User.age, User.name, User.email]`.
    If an empty sequence, the output will be set to all features on the namespace
    of the query. For example, if you pass as input `{"user.id": 1234}`, then the query
    is defined on the `User` namespace, and all features on the `User` namespace
    (excluding has-one and has-many relationships) will be used as outputs.
    """

    additional_logged_features: tuple[str, ...] | None
    """
    Additional logged features are the features that you'd like to log to the query log
    but not return to the client.
    For example: `[User.intermediary_feature]`.
    """

    staleness: Mapping[str, str] | None

    """
    Maximum staleness overrides for any output features or intermediate features.
    See https://docs.chalk.ai/docs/query-caching for more information.
    """

    tags: tuple[str, ...] | None
    """
    The tags used to scope the resolvers.
    See https://docs.chalk.ai/docs/resolver-tags for more information.
    """

    owner: str | None
    """
    The owner of the query. This should be a Slack username or email address.
    This is used to notify the owner in case of incidents
    """

    planner_options: Mapping[str, str]
    """
    Dictionary of additional options to pass to the Chalk query engine.
    Values may be provided as part of conversations with Chalk support to
    to enable or disable specific functionality.
    """

    valid_plan_not_required: bool
    """
    By default, named queries are planned when the engine boots up—this provides a way
    of ensuring that your common application queries you've written are plannable. This
    can be disabled for specific Named Queries by setting this parameter to `True`.
    """

    def __str__(self):
        return _display_name(self.name, self.version)


def extend_unique(target: list[str] | None, source: Collection[str] | None) -> list[str]:
    """
    Inserts elements of source into target only if they are not already present (in-place)
    Used to merge tags and outputs of a named query into the list already being passed
    """
    target_none_or_empty = target is None or len(target) == 0
    source_none_or_empty = source is None or len(source) == 0
    if target_none_or_empty and source_none_or_empty:
        return []
    elif source_none_or_empty:
        return cast(list, target)
    elif target_none_or_empty:
        return list(cast(Collection, source))
    target_checked: list[str] = target  # pyright: ignore[reportAssignmentType]
    target_set = set(target_checked)
    for s in cast(Collection, source):
        if s not in target_set:
            target_checked.append(s)
    return target_checked


class NamedQueryRegistry:
    def __init__(self, named_queries: Iterable[NamedQueryParsed]):
        super().__init__()
        self._named_queries: dict[str, dict[str | None, NamedQueryParsed]] = defaultdict(dict)
        for nq in named_queries:
            self._named_queries[nq.name][nq.version] = nq

    @classmethod
    def empty(cls) -> "NamedQueryRegistry":
        return cls(named_queries=[])

    def get_named_query(self, name: str, version: str | None) -> NamedQueryParsed | None:
        if name not in self._named_queries:
            return None
        return self._named_queries[name].get(version)

    def check_named_query(self, name: str | None, version: str | None) -> NamedQueryParsed | None:
        if name is None:
            return None
        queries_by_version = self._named_queries.get(name)
        if queries_by_version is None:
            warnings.warn(
                f"Unable to find query {_display_name(name, version)}: Named Queries available in current deployment are {(*self._named_queries.keys(),)}",
                category=Warning,
            )
            return
        nq = queries_by_version.get(version)
        if nq is None:
            warnings.warn(
                f"Unable to find query {_display_name(name, version)}: versions of Named Query {name} available in current deployment are {(*queries_by_version.keys(),)}",
                category=Warning,
            )
        return nq

    def named_queries(self) -> Iterable[NamedQueryParsed]:
        for queries_by_version in self._named_queries.values():
            yield from queries_by_version.values()

    def has_named_query_regardless_of_version(self, name: str) -> bool:
        return name in self._named_queries
