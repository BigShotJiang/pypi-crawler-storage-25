from __future__ import annotations

import dataclasses
from datetime import datetime, timedelta
from enum import Enum
from typing import TYPE_CHECKING, Any, Sequence, Tuple, TypeVar

import pyarrow as pa
from chalk.utils.collections import FrozenOrderedSet
from typing_extensions import assert_never

if TYPE_CHECKING:
    from chalkruntime.graph.feature import FeatureTimeFeatureType, FilterParsed, ScalarFeatureType


class _TimeSeriesRuleParsedAggregationTypeInfo:
    def __init__(self, timeseries_rule_aggregation_name: str):
        self.timeseries_rule_aggregation_name = timeseries_rule_aggregation_name
        super().__init__()


class TimeSeriesRuleParsedAggregationType(Enum):
    def __format__(self, fmt: Any):  # ty:ignore[invalid-method-override]
        raise ValueError(
            f"Cannot format {repr(self)} - call 'repr(...)' or '.time_series_rule_name()' to convert to str"
        )

    Sum = _TimeSeriesRuleParsedAggregationTypeInfo("sum")
    Count = _TimeSeriesRuleParsedAggregationTypeInfo("count")
    ApproxCountDistinct = _TimeSeriesRuleParsedAggregationTypeInfo("approx_count_distinct")
    ApproxPercentile = _TimeSeriesRuleParsedAggregationTypeInfo("approx_percentile")
    ApproxTopK = _TimeSeriesRuleParsedAggregationTypeInfo("approx_top_k")
    MinByN = _TimeSeriesRuleParsedAggregationTypeInfo("min_by_n")
    MaxByN = _TimeSeriesRuleParsedAggregationTypeInfo("max_by_n")
    SetAgg = _TimeSeriesRuleParsedAggregationTypeInfo("set_agg")
    M2 = _TimeSeriesRuleParsedAggregationTypeInfo("m2")
    Min = _TimeSeriesRuleParsedAggregationTypeInfo("min")
    Max = _TimeSeriesRuleParsedAggregationTypeInfo("max")
    VectorSum = _TimeSeriesRuleParsedAggregationTypeInfo("vector_sum")

    def time_series_rule_name(self) -> str:
        return self.value.timeseries_rule_aggregation_name

    def bucket_result_type(self, input_types: Sequence[pa.DataType]) -> pa.DataType:
        match self:
            case TimeSeriesRuleParsedAggregationType.Count:
                return pa.int64()
            case (
                TimeSeriesRuleParsedAggregationType.Sum
                | TimeSeriesRuleParsedAggregationType.Min
                | TimeSeriesRuleParsedAggregationType.Max
                | TimeSeriesRuleParsedAggregationType.M2
            ):
                return pa.float64()
            case (
                TimeSeriesRuleParsedAggregationType.ApproxCountDistinct
                | TimeSeriesRuleParsedAggregationType.ApproxPercentile
                | TimeSeriesRuleParsedAggregationType.ApproxTopK
            ):
                return pa.large_binary()
            case TimeSeriesRuleParsedAggregationType.MinByN | TimeSeriesRuleParsedAggregationType.MaxByN:
                return pa.struct(
                    {
                        "n": pa.int64(),
                        "sort_by": pa.large_list(input_types[1]),
                        "values": pa.large_list(input_types[0]),
                    }  # ty: ignore[invalid-argument-type]
                )
            case TimeSeriesRuleParsedAggregationType.SetAgg:
                # set_agg's intermediate state is a deduplicated array of input values.
                return pa.large_list(input_types[0])
            case TimeSeriesRuleParsedAggregationType.VectorSum:
                return input_types[0]
        assert_never(self)

    def intermediate_storage_type(self, input_types: Sequence[pa.DataType]) -> pa.DataType:
        if self == TimeSeriesRuleParsedAggregationType.VectorSum:
            return pa.large_binary()
        return self.bucket_result_type(input_types)


class _MaterializedAggregationTypeInfo:
    def __init__(self, materialized_aggregation_type_name: str):
        self.materialized_aggregation_type_name = materialized_aggregation_type_name
        super().__init__()


class MaterializedAggregationType(Enum):
    Mean = _MaterializedAggregationTypeInfo("mean")
    Sum = _MaterializedAggregationTypeInfo("sum")
    Count = _MaterializedAggregationTypeInfo("count")
    ApproxCountDistinct = _MaterializedAggregationTypeInfo("approx_count_distinct")
    ApproxPercentile = _MaterializedAggregationTypeInfo("approx_percentile")
    ApproxTopK = _MaterializedAggregationTypeInfo("approx_top_k")
    MinByN = _MaterializedAggregationTypeInfo("min_by_n")
    MaxByN = _MaterializedAggregationTypeInfo("max_by_n")
    SetAgg = _MaterializedAggregationTypeInfo("set_agg")
    StandardDeviationSample = _MaterializedAggregationTypeInfo("std")
    VarianceSample = _MaterializedAggregationTypeInfo("var")
    StandardDeviationPopulation = _MaterializedAggregationTypeInfo("std_pop")
    VariancePopulation = _MaterializedAggregationTypeInfo("var_pop")
    Min = _MaterializedAggregationTypeInfo("min")
    Max = _MaterializedAggregationTypeInfo("max")
    VectorSum = _MaterializedAggregationTypeInfo("vector_sum")
    VectorMean = _MaterializedAggregationTypeInfo("vector_mean")

    def materialized_aggregation_type(self) -> str:
        return self.value.materialized_aggregation_type_name


def convert_materialized_aggregation_type_to_timeseries_rule_aggregation_type(
    agg: MaterializedAggregationType,
) -> tuple[TimeSeriesRuleParsedAggregationType, ...]:
    """
    Converts the materialized aggregate into a list of the underlying timeseries values
    which must be stored in order to compute it.

    Many aggregations (count/sum/min/max) just store the same underlying value.

    Some aggregations require multiple timeseries; e.g. `mean` requires `sum` and `count` to
    be stored; there is no benefit to materializing `mean` on a per-bucket basis directly.
    """

    # Pyright checks that we are not missing any cases.
    if agg == MaterializedAggregationType.Mean:
        # The mean doesn't roll-up to anything meaningful.
        # If we want to compute the mean, we need to know
        # the count in each bucket to normalize the mean
        # to be the sum. As this requires two roll ups, in
        # any case, we prefer to compute the sum, as it's
        # useful in its own right and for computing other
        # aggs like variance (see below).
        return (
            TimeSeriesRuleParsedAggregationType.Count,
            TimeSeriesRuleParsedAggregationType.Sum,
        )
    elif agg == MaterializedAggregationType.Sum:
        return (TimeSeriesRuleParsedAggregationType.Sum,)
    elif agg == MaterializedAggregationType.Count:
        return (TimeSeriesRuleParsedAggregationType.Count,)
    elif agg == MaterializedAggregationType.ApproxCountDistinct:
        return (TimeSeriesRuleParsedAggregationType.ApproxCountDistinct,)
    elif agg == MaterializedAggregationType.ApproxPercentile:
        return (TimeSeriesRuleParsedAggregationType.ApproxPercentile,)
    elif agg == MaterializedAggregationType.ApproxTopK:
        return (TimeSeriesRuleParsedAggregationType.ApproxTopK,)
    elif agg == MaterializedAggregationType.VectorSum:
        return (TimeSeriesRuleParsedAggregationType.VectorSum,)
    elif agg == MaterializedAggregationType.VectorMean:
        return (
            TimeSeriesRuleParsedAggregationType.Count,
            TimeSeriesRuleParsedAggregationType.VectorSum,
        )
    elif agg == MaterializedAggregationType.MinByN:
        return (TimeSeriesRuleParsedAggregationType.MinByN,)
    elif agg == MaterializedAggregationType.MaxByN:
        return (TimeSeriesRuleParsedAggregationType.MaxByN,)
    elif agg == MaterializedAggregationType.SetAgg:
        return (TimeSeriesRuleParsedAggregationType.SetAgg,)
    elif (
        agg == MaterializedAggregationType.VarianceSample
        or agg == MaterializedAggregationType.StandardDeviationSample
        or agg == MaterializedAggregationType.VariancePopulation
        or agg == MaterializedAggregationType.StandardDeviationPopulation
    ):
        # To compute variance/standard deviation from a set of pre-aggregated
        # values, we use the following formula:
        #
        # variance = 1/(n - 1) * (
        #   sum(n_i * (m_i - m)^2 for i in range(num_groups)) +
        #   sum((n_i - 1) * v_i for i in range(num_groups))
        # )
        #
        # where n_i is the number of elements in the i-th group,
        # m_i is the mean of the i-th group, m is the mean of all
        # elements, and v_i is the variance of the i-th group.
        #
        # To compute variance, we needed three roll-ups:
        #   - n_i: count of elements in the i-th group
        #   - s_i: sum of the i-th group (we compute the mean from the sum)
        #   - v_i: variance of the i-th group
        # The same three roll-ups are sufficient for both the sample and the
        # population variants — only the final divisor differs (`n` vs. `n - 1`),
        # which is captured by the chosen `*_merge_extract` companion at lookup time.
        return (
            TimeSeriesRuleParsedAggregationType.Count,
            TimeSeriesRuleParsedAggregationType.Sum,
            TimeSeriesRuleParsedAggregationType.M2,
        )
    elif agg == MaterializedAggregationType.Min:
        return (TimeSeriesRuleParsedAggregationType.Min,)
    elif agg == MaterializedAggregationType.Max:
        return (TimeSeriesRuleParsedAggregationType.Max,)
    else:
        assert_never(agg)


_materialized_aggregation_type_mapping = {
    "mean": MaterializedAggregationType.Mean,
    "vector_mean": MaterializedAggregationType.VectorMean,
    "sum": MaterializedAggregationType.Sum,
    "vector_sum": MaterializedAggregationType.VectorSum,
    "count": MaterializedAggregationType.Count,
    "approx_count_distinct": MaterializedAggregationType.ApproxCountDistinct,
    "approx_percentile": MaterializedAggregationType.ApproxPercentile,
    "approx_top_k": MaterializedAggregationType.ApproxTopK,
    "min_by_n": MaterializedAggregationType.MinByN,
    "max_by_n": MaterializedAggregationType.MaxByN,
    "set_agg": MaterializedAggregationType.SetAgg,
    # Several aliases for completeness:
    "std": MaterializedAggregationType.StandardDeviationSample,
    "stddev": MaterializedAggregationType.StandardDeviationSample,
    "std_sample": MaterializedAggregationType.StandardDeviationSample,
    "stddev_sample": MaterializedAggregationType.StandardDeviationSample,
    "std_pop": MaterializedAggregationType.StandardDeviationPopulation,
    "stddev_pop": MaterializedAggregationType.StandardDeviationPopulation,
    "std_population": MaterializedAggregationType.StandardDeviationPopulation,
    "stddev_population": MaterializedAggregationType.StandardDeviationPopulation,
    # Several aliases for completeness:
    "var": MaterializedAggregationType.VarianceSample,
    "var_sample": MaterializedAggregationType.VarianceSample,
    "var_pop": MaterializedAggregationType.VariancePopulation,
    "variance_pop": MaterializedAggregationType.VariancePopulation,
    "var_population": MaterializedAggregationType.VariancePopulation,
    "variance_population": MaterializedAggregationType.VariancePopulation,
    "min": MaterializedAggregationType.Min,
    "max": MaterializedAggregationType.Max,
}


def parse_materialized_aggregation_type_from_name(aggregation_name: str) -> MaterializedAggregationType | None:
    """
    Converts the aggregation name into a `MaterializedAggregationType` aggregation or returns `None` if it is not known.
    """
    return _materialized_aggregation_type_mapping.get(aggregation_name, None)


_AggregateOnFeatureT = TypeVar("_AggregateOnFeatureT")


def expand_legacy_min_max_by_n_aggregate_on(
    aggregation: MaterializedAggregationType,
    aggregate_on: tuple[_AggregateOnFeatureT, ...],
    bucket_feature: _AggregateOnFeatureT,
) -> tuple[_AggregateOnFeatureT, ...]:
    """
    Compatibility for old serialized min_by_n/max_by_n configs that encoded only
    the value column and implicitly used the bucket timestamp as the comparator.
    """
    if (
        aggregation in (MaterializedAggregationType.MinByN, MaterializedAggregationType.MaxByN)
        and len(aggregate_on) == 1
    ):
        return (*aggregate_on, bucket_feature)
    return aggregate_on


@dataclasses.dataclass(frozen=True, slots=True)
class MaterializationWindowConfigParsed:
    namespace: str
    """The namespace being aggregated. For example, 'transaction'."""

    group_by: tuple[ScalarFeatureType, ...]
    """The fqns of the features on which to group by.
    For example ('transaction.user_id', 'transaction.mcc').
    There will always be at least one group-by feature.
    """

    bucket_duration: timedelta
    """The width of each of the tiles maintained for the aggregation"""

    bucket_start: datetime
    """The lower bound of the first bucket"""

    aggregation: MaterializedAggregationType

    aggregate_on: tuple[ScalarFeatureType | FeatureTimeFeatureType, ...]
    """The features on which to aggregate.
    For min_by_n/max_by_n this is [value, comparator].
    """

    aggregation_kwargs: FrozenOrderedSet[Tuple[str, Any]]
    """The kwargs passed into the aggregation. Currently only supported by 'approx_top_k'."""

    pyarrow_dtype: pa.DataType
    """The dtype of the aggregation"""

    bucket_feature: ScalarFeatureType | FeatureTimeFeatureType

    filters: tuple[FilterParsed, ...] = ()
    """The filters to apply to the has-many aggregation"""

    backfill_resolver: str | None = None
    """The resolver to use for backfilling the aggregation
    in a continuous backfill setup"""

    backfill_lookback_duration: timedelta | None = None

    backfill_start_time: datetime | None = None

    backfill_schedule: str | None = None

    continuous_buffer_duration: timedelta | None = None

    continuous_resolver: str | None = None

    approximate_offline_query: bool = False

    cache_aggregated_values: bool = False
