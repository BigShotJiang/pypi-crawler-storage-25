import functools
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Generic, Literal, TypeVar

import chalk.functions as F
from chalk.features import Underscore

if TYPE_CHECKING:
    from sklearn.ensemble import GradientBoostingRegressor, RandomForestClassifier, RandomForestRegressor
    from sklearn.linear_model import LogisticRegression
    from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
    from xgboost import XGBRegressor

    T = TypeVar(
        "T",
        bound=RandomForestRegressor
        | RandomForestClassifier
        | GradientBoostingRegressor
        | LogisticRegression
        | DecisionTreeClassifier
        | DecisionTreeRegressor
        | XGBRegressor,
    )


def import_sklearn_logistic_regression() -> type["LogisticRegression"]:
    from sklearn.linear_model import LogisticRegression

    return LogisticRegression


def import_sklearn_decision_tree_regressor() -> type["DecisionTreeRegressor"]:
    from sklearn.tree import DecisionTreeRegressor

    return DecisionTreeRegressor


def import_sklearn_decision_tree_classifier() -> type["DecisionTreeClassifier"]:
    from sklearn.tree import DecisionTreeClassifier

    return DecisionTreeClassifier


def import_sklearn_random_forest_regressor() -> type["RandomForestRegressor"]:
    from sklearn.ensemble import RandomForestRegressor

    return RandomForestRegressor


def import_sklearn_random_forest_classifier() -> type["RandomForestClassifier"]:
    from sklearn.ensemble import RandomForestClassifier

    return RandomForestClassifier


def import_sklearn_gradient_boosting_regressor() -> type["GradientBoostingRegressor"]:
    from sklearn.ensemble import GradientBoostingRegressor

    return GradientBoostingRegressor


def import_xgboost_regressor() -> type["XGBRegressor"]:
    from xgboost import XGBRegressor

    return XGBRegressor


def _sklearn_dtree_to_underscore(
    tree: "DecisionTreeRegressor | DecisionTreeClassifier", features: tuple[Underscore, ...], classifier: bool = False
) -> Underscore:
    """Convert decision tree rules to expression."""
    try:
        from sklearn.tree._tree import (  # ty: ignore[unresolved-import]
            TREE_UNDEFINED,  # pyright: ignore[reportMissingImports]
        )
    except ImportError:
        raise ValueError(f"Failed to import sklearn, which is required for loading {type(tree)}")

    tree_ = tree.tree_

    def parse_tree(node: int):
        if (variable_idx := tree_.feature[node]) != TREE_UNDEFINED:
            variable = features[variable_idx]
            threshold = tree_.threshold[node]
            return F.if_then_else(
                variable < threshold,
                parse_tree(tree_.children_left[node]),
                parse_tree(tree_.children_right[node]),
            )
        else:
            if classifier:
                return tree_.value[node][0][1] / tree_.value[node].sum()
            return tree_.value[node][0][0]

    return parse_tree(node=0)


def _sklearn_rf_to_underscore(
    forest: "RandomForestRegressor | RandomForestClassifier",
    features: tuple[Underscore, ...],
    *,
    classifier: bool = False,
) -> Underscore:
    estimators = forest.estimators_
    rf_expression = sum([_sklearn_dtree_to_underscore(e, features, classifier=classifier) for e in estimators]) / len(
        estimators
    )
    if not isinstance(rf_expression, Underscore):
        raise ValueError(f"Expected expression but got {type(rf_expression)}")
    return rf_expression


def _sklearn_gb_to_underscore(gb: "GradientBoostingRegressor", features: tuple[Underscore, ...]):
    estimators = [e[0] for e in gb.estimators_]
    init = (
        gb.init_.constant_.squeeze() if hasattr(gb.init_, "constant_") and hasattr(gb.init_.constant_, "squeeze") else 0  # type: ignore
    )
    learning_rate = gb.learning_rate
    return init + learning_rate * sum([_sklearn_dtree_to_underscore(e, features) for e in estimators])


def _sklearn_lr_to_underscore(lr: Any, features: tuple[Underscore, ...]) -> Underscore:
    return F.sigmoid(sum([float(w) * f for w, f in zip(lr.coef_[0], features)]) + lr.intercept_[0])


def _xgb_reg_to_underscore(xgb: "XGBRegressor", features: tuple[Underscore, ...]) -> Underscore:
    """Convert XGBoost regressor to expression."""
    import json

    if not hasattr(xgb, "get_booster"):
        raise ValueError("XGBRegressor must have get_booster method.")

    booster = xgb.get_booster()
    config = json.loads(xgb.get_booster().save_config())

    base_score = float(config["learner"]["learner_model_param"]["base_score"])
    feature_names = booster.feature_names or [f"f{i}" for i in range(xgb.n_features_in_)]

    if len(feature_names) != len(features):
        raise ValueError(f"Expected {len(feature_names)} features but got {len(features)}")

    feature_map = {name: feature_expression for name, feature_expression in zip(feature_names, features)}

    def parse_tree(tree: Any) -> Underscore:
        if tree.get("children", None) is None:
            return tree["leaf"]
        left = next((t for t in tree["children"] if t["nodeid"] == tree["yes"]))
        right = next((t for t in tree["children"] if t["nodeid"] == tree["no"]))
        return F.if_then_else(feature_map[tree["split"]] < tree["split_condition"], parse_tree(left), parse_tree(right))

    trees = [json.loads(t) for t in xgb.get_booster().get_dump(dump_format="json")]
    expressions = [parse_tree(tree) for tree in trees]
    return sum(expressions) + base_score  # type: ignore


@dataclass(frozen=True, kw_only=True, slots=True)
class MLModel(Generic["T"] if TYPE_CHECKING else object):  # ty:ignore[invalid-argument-type]
    to_expression: Callable[["T", tuple[Underscore, ...]], Underscore]
    import_: Callable[[], type["T"]]
    feature_count: Callable[["T"], int]
    type_: Literal["regressor", "classifier"]


SUPPORTED_MODELS = {
    "decision_tree_regressor": MLModel(
        to_expression=functools.partial(
            _sklearn_dtree_to_underscore, classifier=False
        ),  # ty:ignore[invalid-argument-type]
        import_=import_sklearn_decision_tree_regressor,
        feature_count=lambda x: x.n_features_in_,
        type_="regressor",
    ),
    "decision_tree_classifier": MLModel(
        to_expression=functools.partial(
            _sklearn_dtree_to_underscore, classifier=True
        ),  # ty:ignore[invalid-argument-type]
        type_="classifier",
        feature_count=lambda x: x.n_features_in_,
        import_=import_sklearn_decision_tree_classifier,
    ),
    "random_forest_regressor": MLModel(
        to_expression=functools.partial(
            _sklearn_rf_to_underscore, classifier=False
        ),  # ty:ignore[invalid-argument-type]
        type_="regressor",
        feature_count=lambda x: x.n_features_in_,
        import_=import_sklearn_random_forest_regressor,
    ),
    "random_forest_classifier": MLModel(
        to_expression=functools.partial(_sklearn_rf_to_underscore, classifier=True),  # ty:ignore[invalid-argument-type]
        type_="classifier",
        feature_count=lambda x: x.n_features_in_,
        import_=import_sklearn_random_forest_classifier,
    ),
    "gradient_boosting_regressor": MLModel(
        to_expression=_sklearn_gb_to_underscore,  # ty:ignore[invalid-argument-type]
        type_="regressor",
        feature_count=lambda x: x.n_features_in_,
        import_=import_sklearn_gradient_boosting_regressor,
    ),
    "logistic_regression": MLModel(
        to_expression=_sklearn_lr_to_underscore,
        type_="classifier",
        feature_count=lambda x: x.n_features_in_,
        import_=import_sklearn_logistic_regression,
    ),
    "xgb_regressor": MLModel(
        to_expression=_xgb_reg_to_underscore,  # ty:ignore[invalid-argument-type]
        type_="regressor",
        feature_count=lambda x: x.n_features_in_,
        import_=import_xgboost_regressor,
    ),
}


def parse_sklearn_model(
    *features: Underscore,
    model_config: MLModel,
    model_path: str,
    return_probability: bool = False,
    threshold: float | Underscore = 0.5,
) -> Underscore:
    try:
        import joblib  # pyright: ignore[reportMissingImports]

        model_type = model_config.import_()
    except ImportError:
        raise RuntimeError("Failed to import scikit-learn, which is required for model chalk functions")

    try:
        model = joblib.load(model_path)
    except FileNotFoundError:
        raise RuntimeError("Model file not found. Please check the model path.")

    if model is None or not isinstance(model, model_type):
        raise RuntimeError(f"Model must be a `{model_type.__name__}` but got a {type(model)}")

    if (feature_count := model_config.feature_count(model)) != len(features):
        raise RuntimeError(
            f"Model takes {feature_count} inputs, but {len(features)} features were provided: ([{features}])"
        )

    expr = model_config.to_expression(model, features)

    if model_config.type_ == "regressor" or return_probability:
        return expr

    return expr >= threshold
