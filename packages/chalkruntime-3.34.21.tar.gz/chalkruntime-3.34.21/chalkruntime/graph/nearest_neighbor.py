import dataclasses
from typing import Literal

from chalk.utils.collections import FrozenOrderedSet

from chalkruntime.graph.feature import FilterParsed, HasManyFeatureType, ScalarFeatureType


@dataclasses.dataclass
class ForeignLocalPair:
    foreign_feature: ScalarFeatureType
    local_feature: ScalarFeatureType

    def __hash__(self):
        return hash((self.foreign_feature.root_fqn, self.local_feature.root_fqn))


@dataclasses.dataclass
class NearestNeighborJoinInfo:
    vector_index: tuple[ForeignLocalPair, Literal["l2", "ip", "cos"]]
    additional_index_features: FrozenOrderedSet[ForeignLocalPair]

    def foreign_embedding_feature(self) -> ScalarFeatureType:
        return self.vector_index[0].foreign_feature

    @classmethod
    def maybe_from_feature(cls, feat: HasManyFeatureType) -> "NearestNeighborJoinInfo | None":
        """
        Parses the nearest-neighbor related info from a filter representing a has-many join, or
        None if it's not a nearest-neighor join
        """
        local_ns = feat.namespace
        res = _MaybeNearestNeighborJoinInfo.from_filter(local_ns, feat.join).finalize()
        if res is None:
            return None
        if res.vector_index[0].foreign_feature.namespace == local_ns:
            raise ValueError(
                f"Join vector feature {res.vector_index[0].foreign_feature.root_fqn} is in the wrong namespace! (expected NOT {local_ns})"
            )
        for f in res.additional_index_features:
            if f.foreign_feature.namespace == local_ns:
                raise ValueError(
                    f"Join index feature {f.foreign_feature} is in the wrong namespace! (expected NOT {local_ns})"
                )
        return res


@dataclasses.dataclass
class _MaybeNearestNeighborJoinInfo:
    """
    Parital information for a nearest-neighbor
    """

    vector_index: tuple[ForeignLocalPair, Literal["l2", "ip", "cos"]] | None
    additional_index_features: FrozenOrderedSet[ForeignLocalPair]

    def merge(self, other: "_MaybeNearestNeighborJoinInfo") -> "_MaybeNearestNeighborJoinInfo":
        if self.vector_index is not None and other.vector_index is not None:
            raise ValueError(f"Can't combine two nearest-neighbor joins: {self.vector_index} != {other.vector_index}")

        vector_index = self.vector_index if self.vector_index is not None else other.vector_index
        additional_index_features = self.additional_index_features | other.additional_index_features
        return _MaybeNearestNeighborJoinInfo(
            vector_index=vector_index, additional_index_features=additional_index_features
        )

    def finalize(self) -> NearestNeighborJoinInfo | None:
        if self.vector_index is None:
            return None
        return NearestNeighborJoinInfo(
            vector_index=self.vector_index, additional_index_features=self.additional_index_features
        )

    @classmethod
    def from_filter(cls, local_namespace: str, filt: FilterParsed) -> "_MaybeNearestNeighborJoinInfo":
        """
        :param local_namespace: The _local_ namespace for the join (e.g. for Query.embedding <~> Document.embedding, we want 'document'.
        :param filt:
        :return:
        """
        if filt.is_simple_nearest_neighbor_join():
            if not isinstance(filt.lhs, ScalarFeatureType) or not isinstance(filt.rhs, ScalarFeatureType):
                raise ValueError(f"Invalid nearest-neighbor join: {filt}")
            foreign_vec_feat: ScalarFeatureType = filt.lhs if filt.lhs.namespace != local_namespace else filt.rhs
            local_vec_feat: ScalarFeatureType = filt.rhs if filt.lhs.namespace != local_namespace else filt.lhs
            vec = ForeignLocalPair(foreign_feature=foreign_vec_feat, local_feature=local_vec_feat)

            distance_method = filt.operation.removeprefix("is_near_")
            return _MaybeNearestNeighborJoinInfo(
                vector_index=(vec, distance_method),  # pyright: ignore[reportArgumentType] # pyright isn't great at Literal[...]  # ty:ignore[invalid-argument-type]
                additional_index_features=FrozenOrderedSet(),
            )
        if filt.operation == "and":
            if not isinstance(filt.lhs, FilterParsed) or not isinstance(filt.rhs, FilterParsed):
                raise ValueError(f"Invalid nearest-neighbor join: {filt}")
            lhs = _MaybeNearestNeighborJoinInfo.from_filter(local_namespace, filt.lhs)
            rhs = _MaybeNearestNeighborJoinInfo.from_filter(local_namespace, filt.rhs)
            return lhs.merge(rhs)
        if isinstance(filt.lhs, ScalarFeatureType) and isinstance(filt.rhs, ScalarFeatureType):
            if filt.lhs.namespace != local_namespace:
                feat = ForeignLocalPair(foreign_feature=filt.lhs, local_feature=filt.rhs)
            else:
                feat = ForeignLocalPair(foreign_feature=filt.rhs, local_feature=filt.lhs)
            return _MaybeNearestNeighborJoinInfo(vector_index=None, additional_index_features=FrozenOrderedSet([feat]))
        else:
            raise ValueError(f"Unsupported filter for nearest-neighbor join: {filt}")
