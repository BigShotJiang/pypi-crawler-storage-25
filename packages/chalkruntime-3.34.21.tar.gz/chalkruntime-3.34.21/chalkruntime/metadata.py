from __future__ import annotations

import enum
import functools
import hashlib
import sys
from typing import TYPE_CHECKING, overload

import polars as pl
import pyarrow as pa
import pyarrow.compute as pc
from chalk.utils.environment_parsing import env_var_bool

if TYPE_CHECKING:
    from chalkruntime.graph.graph import ResolvedGraph
    from chalkruntime.graph.resolver import ResolverParsed


CHALK_METADATA_PREFIX = "__chalk__.__metadata__."
METADATA_PYARROW_TYPE = pa.uint64()
METADATA_POLARS_TYPE = pl.UInt64()

CHALK_FEATURE_IS_MISSING_PREFIX = "__chalk__.__is_missing__."

# We do not use the highest order bit because velox represents all columns as signed integers, and bitwise ops
# on signed integers that touch the sign bit could lead to unexpected results
_MAX_VALUE = 2**63 - 1

# The source takes up 3 bits to encode
_SOURCE_TYPE_NUM_BITS = 3
# The source is encoded on bits [60, 62], inclusive.
_SOURCE_OFFSET = 60
SOURCE_TYPE_MASK = (1 << _SOURCE_TYPE_NUM_BITS) - 1

# The resolver id is the lower 56 bits. This saves 4 bits for future-proofing
_RESOLVER_ID_NUM_BITS = 56
RESOLVER_ID_MASK = (1 << _RESOLVER_ID_NUM_BITS) - 1

# These are the same, aliasing for readability
_MAX_RESOLVER_ID = RESOLVER_ID_MASK

_CHALK_FIX_INVALID_RESULT_PROPAGATION: bool = env_var_bool("CHALK_FIX_INVALID_RESULT_PROPAGATION")  # pyright: ignore[reportConstantRedefinition]


def get_chalk_fix_invalid_result_propagation() -> bool:
    return _CHALK_FIX_INVALID_RESULT_PROPAGATION


class ResultMetadataSourceType(enum.IntEnum):
    """
    Note that this should be kept in sync with libplanner's src/libplanner/chalktable/metadata.h.
    It's only copied here because libplanner is not available in all contexts that need this code.
    """

    MISSING = 0b000
    """The feature value is missing"""

    # By convention, always setting the highest-order bit to 1 if the value is non-missing. This makes it easy to distinguish missing values,
    # as you'll only need to look at the first bit. However, external code should not rely on this convention -- instead,
    # they should use the ``is_value_valid`` or ``pa_is_value_valid`` functions

    OPTIONAL_JOIN = 0b111
    """The feature value came from a has_many or an optional has_one relationship in which there are no linked entities"""

    LIVE_RESOLVER = 0b001
    """The feature value was computed that was run live as part of the plan execution. It did not come from a cache store.
    Note that this value _may_ be returned if a default value was used.
    """

    ONLINE_CACHE = 0b010
    """The feature value came from the online cache. The resolver ID (in the lower order bits) is the resolver that originally ran
    to populate this cache value
    """

    OFFLINE_STORE = 0b011
    """The feature value came from the offline store. The resolver ID (in the lower order bits) is the resolver that originally ran
    to populate this value in the offline store
    """

    GIVENS = 0b100
    """The feature value was provided as givens during the query"""

    FEATURE_DEFAULT = 0b101
    """The value is the default value from the feature set.
    Note that sometimes the source type will be ``LIVE_RESOLVER`` if a default value was used"""

    UNKNOWN = 0b110
    """The source resolvers is unknown. This is a transitory value until metadata can be threaded through the entire system"""


def _get_resolver_fqn(resolver_id: int, graph: ResolvedGraph):
    if resolver_id == 0:
        return None
    return graph.resolver_by_id(resolver_id).fqn


def _make_metadata_value_py(source_type: ResultMetadataSourceType, resolver: ResolverParsed | None) -> int | None:
    if source_type == ResultMetadataSourceType.LIVE_RESOLVER:
        if resolver is None:
            # OK, but unwise, to have an unknown resolver
            source_id = 0
        else:
            source_id = compute_resolver_id(resolver.short_name)
    else:
        # If not a live resolver, then there shouldn't be a resolver
        assert resolver is None, f"Source type '{source_type.name}' should not have any resolver"
        source_id = 0
    assert source_id >= 0 and source_id <= _MAX_RESOLVER_ID, (
        f"Source id {source_id} is invalid. It must be on [0, {_MAX_RESOLVER_ID}]"
    )
    value = (source_type.value << _SOURCE_OFFSET) | source_id
    assert value <= _MAX_VALUE
    if value == 0:
        # We use None instead of 0 because then you don't need to do a fill_null() step
        return None
    return value


def _parse_metadata_value_py(
    metadata: int | None, graph: ResolvedGraph | None
) -> tuple[ResultMetadataSourceType, str | None]:
    if metadata is None:
        return ResultMetadataSourceType.MISSING, None
    resolver_id = metadata & RESOLVER_ID_MASK
    source_type = ResultMetadataSourceType((metadata >> _SOURCE_OFFSET) & SOURCE_TYPE_MASK)

    if graph is None or resolver_id == 0:
        return source_type, None
    else:
        resolver_fqn = _get_resolver_fqn(resolver_id, graph)
    return source_type, resolver_fqn


try:
    # Conditionally import libchalk since some of our pre-commit hooks (i.e. stubgen) don't have access to it.
    import libchalk.batchplan
    from libchalk.batchplan import (
        ResultMetadataSourceType as _ResultMetadataSourceTypeCpp,
    )
    from libchalk.batchplan import make_metadata_value_internal, parse_metadata_value_internal

    assert CHALK_METADATA_PREFIX == libchalk.batchplan.CHALK_METADATA_PREFIX
    assert METADATA_PYARROW_TYPE == libchalk.batchplan.METADATA_PYARROW_TYPE
    # Check that the two IntEnums are the same
    assert dict(_ResultMetadataSourceTypeCpp.__members__) == dict(ResultMetadataSourceType.__members__)

    def _make_metadata_value_cpp(source_type: ResultMetadataSourceType, resolver: ResolverParsed | None) -> int | None:
        if source_type != ResultMetadataSourceType.LIVE_RESOLVER:
            assert resolver is None, f"Source type '{source_type.name}' should not have any resolver"
            source_id = 0
        else:
            source_id = 0 if resolver is None else compute_resolver_id(resolver.short_name)
        assert 0 <= source_id <= _MAX_RESOLVER_ID
        value: int | None = make_metadata_value_internal(source_type.value, source_id)
        if value is not None:
            assert value <= _MAX_VALUE
        assert (py_metadata_val := _make_metadata_value_py(source_type, resolver)) == value, (
            f"Python metadata value {py_metadata_val} differs from cpp metadata val {value}"
        )
        return value

    make_metadata_value = _make_metadata_value_cpp

    def _parse_metadata_value_cpp(
        metadata: int | None, graph: ResolvedGraph | None
    ) -> tuple[ResultMetadataSourceType, str | None]:
        if metadata is None:
            return (ResultMetadataSourceType.MISSING, None)
        source_type_int, resolver_id = parse_metadata_value_internal(metadata)
        source_type = ResultMetadataSourceType(source_type_int)
        assert source_type != ResultMetadataSourceType.MISSING, (
            "Missing metadata should always be represented by null, not 0"
        )
        resolver_fqn = None if graph is None or resolver_id is None else _get_resolver_fqn(resolver_id, graph)
        assert (py_result := _parse_metadata_value_py(metadata, graph)) == (
            source_type,
            resolver_fqn,
        ), f"Parsed python metadata {py_result} differs from parsed cpp metadata ({(source_type, resolver_fqn)})"
        return source_type, resolver_fqn

    parse_metadata_value = _parse_metadata_value_cpp

except ImportError:
    make_metadata_value = _make_metadata_value_py
    parse_metadata_value = _parse_metadata_value_py

MISSING_METADATA_VALUE = make_metadata_value(ResultMetadataSourceType.MISSING, None)
assert MISSING_METADATA_VALUE is None, "A bunch of code depends on missing being None"
MISSING_METADATA_SCALAR = pa.scalar(MISSING_METADATA_VALUE, METADATA_PYARROW_TYPE)
GIVENS_METADATA_VALUE = make_metadata_value(ResultMetadataSourceType.GIVENS, None)
GIVENS_METADATA_SCALAR = pa.scalar(GIVENS_METADATA_VALUE, METADATA_PYARROW_TYPE)
FEATURE_DEFAULT_METADATA_VALUE = make_metadata_value(ResultMetadataSourceType.FEATURE_DEFAULT, None)
FEATURE_DEFAULT_METADATA_SCALAR = pa.scalar(FEATURE_DEFAULT_METADATA_VALUE, METADATA_PYARROW_TYPE)
OFFLINE_STORE_METADATA_VALUE = make_metadata_value(ResultMetadataSourceType.OFFLINE_STORE, None)
OFFLINE_STORE_METADATA_SCALAR = pa.scalar(OFFLINE_STORE_METADATA_VALUE, METADATA_PYARROW_TYPE)
ONLINE_STORE_METADATA_VALUE = make_metadata_value(ResultMetadataSourceType.ONLINE_CACHE, None)
ONLINE_STORE_METADATA_SCALAR = pa.scalar(ONLINE_STORE_METADATA_VALUE, METADATA_PYARROW_TYPE)


def get_metadata_col_name(fqn: str, metadata_prefix: str = CHALK_METADATA_PREFIX):
    return f"{metadata_prefix}{fqn}"


def get_feature_is_missing_col_name(fqn: str, is_missing_prefix: str = CHALK_FEATURE_IS_MISSING_PREFIX):
    return f"{is_missing_prefix}{fqn}"


@overload
def pa_is_value_valid(metadata_col: pa.Array) -> pa.BooleanArray: ...


@overload
def pa_is_value_valid(
    metadata_col: pa.ChunkedArray,
) -> pa.ChunkedArray: ...


def pa_is_value_valid(metadata_col: pa.Array | pa.ChunkedArray):
    """
    Returns
    -------
    pa.BooleanArray
        A boolean array indicating whether the value is valid or not. Typed as any b/c of pyright.
    """
    assert not pc.any(pc.equal(metadata_col, pa.scalar(0, METADATA_PYARROW_TYPE))).as_py(), (
        "metadata should never be 0"
    )  # ty:ignore[unresolved-attribute]
    return metadata_col.is_valid()


def is_metadata_col(col_name: str) -> bool:
    return col_name.startswith(CHALK_METADATA_PREFIX)


def is_feature_is_missing_col(col_name: str) -> bool:
    return col_name.startswith(CHALK_FEATURE_IS_MISSING_PREFIX)


def arrow_get_metadata_source_type(metadata_col: pa.Array) -> pa.Array:
    """Given a pyarrow array for the metadata column, return an array that parses it into the metadata source type integer"""
    valid_source_type = pc.shift_right(
        metadata_col, pa.scalar(_SOURCE_OFFSET, METADATA_PYARROW_TYPE)
    )  # ty:ignore[unresolved-attribute]
    valid_source_type = pc.bit_wise_and(
        valid_source_type, pa.scalar(SOURCE_TYPE_MASK, METADATA_PYARROW_TYPE)
    )  # ty:ignore[unresolved-attribute]

    return pc.if_else(  # ty:ignore[unresolved-attribute]
        pc.is_null(metadata_col),  # ty:ignore[unresolved-attribute]
        pa.scalar(ResultMetadataSourceType.MISSING.value, METADATA_PYARROW_TYPE),
        valid_source_type,
    )


def pl_get_metadata_source_type(metadata_col: pl.Expr, alias: str = "source_type") -> pl.Expr:
    """Given a polars expression for the metadata column, return an expression that parses it into the metadata source type integer"""
    valid_source_type = metadata_col // pl.lit(2**_SOURCE_OFFSET, METADATA_POLARS_TYPE)
    # This and should be useless, but it ensures that we discard any high-order (sign?) bits
    valid_source_type = valid_source_type.mod(2**_SOURCE_TYPE_NUM_BITS)
    return (
        pl.when(metadata_col.is_null())
        .then(pl.lit(ResultMetadataSourceType.MISSING.value, METADATA_POLARS_TYPE))
        .otherwise(valid_source_type)
        .alias(alias)
    )


def arrow_get_resolver_id_from_metadata(metadata_col: pa.Array) -> pa.Array:
    """Given a pyarrow array for the metadata column, return an array that parses it into the resolver id, or None if the metadata is not from a live resolver"""
    intermediate = pc.bit_wise_and(
        metadata_col, pa.scalar(RESOLVER_ID_MASK, METADATA_PYARROW_TYPE)
    )  # ty:ignore[unresolved-attribute]
    return pc.if_else(  # ty:ignore[unresolved-attribute]
        pc.equal(metadata_col, pa.scalar(0, METADATA_PYARROW_TYPE)),  # ty:ignore[unresolved-attribute]
        pa.scalar(None, METADATA_PYARROW_TYPE),
        intermediate,
    )


def pl_get_resolver_id_from_metadata(metadata_col: pl.Expr, resolver_id: str = "resolver_id") -> pl.Expr:
    """Given a polars expression for the metadata column, return an expression that parses it into the resolver id, or None if the metadata is not from a live resolver"""
    intermediate = metadata_col.and_(pl.lit(RESOLVER_ID_MASK, METADATA_POLARS_TYPE))
    return (
        pl.when(intermediate == pl.lit(0, METADATA_POLARS_TYPE))
        .then(pl.lit(None, METADATA_POLARS_TYPE))
        .otherwise(intermediate)
        .alias(resolver_id)
    )


@functools.cache
def compute_resolver_id(short_name: str, /) -> int:
    resolver_id_long = int.from_bytes(hashlib.sha256(short_name.encode("utf8")).digest(), sys.byteorder)
    return resolver_id_long & (RESOLVER_ID_MASK)
