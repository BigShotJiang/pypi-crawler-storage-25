"""Per-branch CHALK_MODEL_ENDPOINT_CONFIG handoff via local filesystem.

The engine pod hosts two cooperating processes for every branch deployment:
the supervisor in ``chalkengine.branch_server`` that downloads the snapshot
the go-api-server wrote to cloud storage, and an idle actor subprocess in
``chalkruntime.server.service`` where the graph is actually imported and
``F.catalog_call("model.*")`` underscore expressions are validated. Each
process owns its own libchalk catalog singleton, so reinitializing in one
does not refresh the other.

This module is the file-system handoff between them: the supervisor calls
``write_local_snapshot`` after fetching from GCS, and the actor calls
``apply_local_snapshot_if_present`` right before graph import. Missing files
are non-fatal — both ends fall back to whatever the actor's boot env
``CHALK_MODEL_ENDPOINT_CONFIG`` had.
"""

from __future__ import annotations

import os
from typing import Callable, Optional

from chalk.utils.log_with_context import get_logger

_logger = get_logger(__name__)

_DEFAULT_ROOT = "/tmp/chalk_branch_catalog_snapshots"

_ROOT_ENV_VAR = "CHALK_BRANCH_CATALOG_SNAPSHOT_ROOT"


def _root() -> str:
    return os.environ.get(_ROOT_ENV_VAR, _DEFAULT_ROOT)


def local_snapshot_path(environment_id: str, deployment_id: str) -> str:
    """Deterministic on-disk location used by both writer and reader."""
    return os.path.join(
        _root(),
        f"env_{environment_id}",
        f"dep_{deployment_id}",
        "model_endpoint_config.json",
    )


def write_local_snapshot(environment_id: str, deployment_id: str, payload: bytes) -> Optional[str]:
    """Persist the snapshot atomically (write-then-rename) so a concurrent
    actor read can never see a half-written file. Empty payloads are skipped
    so we never blank the catalog of a future reader. Returns the path on
    success, or None when nothing was written.
    """
    if not payload:
        return None
    path = local_snapshot_path(environment_id, deployment_id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp_path = f"{path}.tmp"
    with open(tmp_path, "wb") as f:
        f.write(payload)
    os.replace(tmp_path, path)
    return path


def apply_local_snapshot_if_present(
    environment_id: str,
    deployment_id: str,
    *,
    reinitialize: Optional[Callable[[str], None]] = None,
) -> bool:
    """Reinit the libchalk global catalog from the local snapshot.

    Returns True iff the file was read and applied. Missing/empty/unreadable
    snapshots all return False and leave the catalog untouched — they mean
    "nothing extra to refresh for this deployment". The ``reinitialize``
    callable defaults to libchalk's
    ``reinitialize_global_catalog_runtime``; tests inject a recorder so they
    can run without linking libchalk.
    """
    path = local_snapshot_path(environment_id, deployment_id)
    try:
        with open(path, "rb") as f:
            payload = f.read()
    except FileNotFoundError:
        _logger.debug(f"No branch catalog snapshot at {path}; keeping boot env catalog")
        return False
    except Exception as e:
        _logger.warning(f"Failed to read branch catalog snapshot at {path}: {e}", exc_info=True)
        return False

    if not payload:
        return False

    try:
        config_str = payload.decode("utf-8")
    except UnicodeDecodeError as e:
        _logger.warning(f"Failed to decode branch catalog snapshot at {path}: {e}", exc_info=True)
        return False

    if reinitialize is None:
        from libchalk.runtime.remote_call import reinitialize_global_catalog_runtime

        reinitialize = reinitialize_global_catalog_runtime

    try:
        reinitialize(config_str)
    except Exception as e:
        _logger.warning(f"Failed to reinitialize global catalog runtime from {path}: {e}", exc_info=True)
        return False

    # The C++ side just rebuilt the global ``CatalogRuntime`` shared_ptr, but
    # ``chalkdf.catalog._GLOBAL_CATALOG`` is a *Python* singleton that wraps a
    # ``CatalogRuntime`` captured at first access. Without invalidating it,
    # ``get_active_catalog()`` keeps returning a Catalog backed by the stale
    # pre-reinit runtime — which is exactly the bug "model.<sg> not found in
    # catalog" symptom underscore validation hits during graph load. Reset so
    # the next ``Catalog.local_catalog()`` lazy-creates a fresh wrapper that
    # picks up the new global runtime.
    try:
        from chalkdf.catalog import Catalog

        Catalog.reset_local()
    except Exception as e:
        _logger.warning(
            f"Failed to reset chalkdf Catalog singleton after catalog reinit from {path}: {e}",
            exc_info=True,
        )

    _logger.info(
        f"Refreshed CHALK_MODEL_ENDPOINT_CONFIG for branch deployment {deployment_id} from {path} ({len(payload)} bytes)"
    )
    return True
