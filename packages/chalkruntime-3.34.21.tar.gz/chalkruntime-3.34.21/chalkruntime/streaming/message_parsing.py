import contextlib
import dataclasses
import functools
import json
import uuid
from collections.abc import Iterable
from datetime import datetime, timezone
from enum import Enum
from inspect import getargs, isclass
from io import BytesIO
from typing import TYPE_CHECKING, Any, Sequence, Type, Union, get_origin

import polars as pl
import pyarrow
import pyarrow as pa
from chalk.features import DataFrame
from chalk.streams.types import (
    StreamResolverParam,
    StreamResolverParamMessage,
    StreamResolverParamMessageWindow,
    StreamResolverWindowType,
)
from chalk.utils import AnyDataclass
from chalk.utils.collections import get_unique_item
from chalk.utils.log_with_context import add_logging_context, get_logger, get_operation_log_context, get_public_logger
from chalk.utils.pydanticutil.pydantic_compat import (
    get_pydantic_model_dict,
    get_pydantic_model_json,
    is_pydantic_basemodel,
    is_pydantic_basemodel_instance,
    parse_pydantic_model,
)
from pyarrow.json import ParseOptions, read_json

from chalkruntime.exc.resolver_errors import ResolverErrors
from chalkruntime.graph.stream_resolver import (
    StreamResolverParsed,
    get_list_item_typ,
    is_list_typ_annotation,
    pydantic_to_pyarrow_schema,
)
from chalkruntime.streaming.converter_utils import convert_format
from chalkruntime.streaming.exc import FatalResolverError
from chalkruntime.streaming.resolver_utils import (
    coerce_streaming_message_body,
    log_resolver_error,
)
from chalkruntime.streaming.types import (
    DataClassAny,
    ParsedMessage,
    StreamingMessageFormatError,
    StreamMessageRaw,
)
from chalkruntime.streaming.window_keys import window_key_for

if TYPE_CHECKING:
    from pydantic import BaseModel

_logger = get_logger(__name__)
_public_logger = get_public_logger(__name__)


def _is_dataclass_instance(value: object) -> bool:
    return dataclasses.is_dataclass(value) and not isinstance(value, type)


def _model_to_dict(model: Any) -> dict[str, Any]:
    if is_pydantic_basemodel_instance(model):
        return get_pydantic_model_dict(model)
    if _is_dataclass_instance(model):
        return dataclasses.asdict(model)
    raise TypeError(f"Expected pydantic model or dataclass instance, got {model}")


def _dataclass_json_default(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    raise TypeError(f"Object of type {value.__class__.__name__} is not JSON serializable")


def _model_to_json(model: Any) -> str:
    if is_pydantic_basemodel_instance(model):
        return get_pydantic_model_json(model)
    if _is_dataclass_instance(model):
        return json.dumps(_model_to_dict(model), default=_dataclass_json_default)
    raise TypeError(f"Expected pydantic model or dataclass instance, got {model}")


@contextlib.contextmanager
def _with_log_context(resolver_fqn: str, operation_id: str):
    with add_logging_context(
        **get_operation_log_context(
            operation_id=operation_id,
            operation_kind="streaming",
            resolver_fqn=resolver_fqn,
        )
    ):
        yield


def _get_non_windowed_parsed_param_value(
    input_param: Type,
    message: StreamMessageRaw,
    is_optional: bool,
    log_error: bool,
) -> "BaseModel | DataClassAny | str | bytes | None":
    try:
        return coerce_streaming_message_body(message.value_raw, input_param)
    except Exception as e:
        if log_error:
            _public_logger.warning(f"Failed to parse message body: {message.value_raw.decode('utf-8')}", exc_info=e)
            _logger.error(f"Failed to parse message body: {message.value_raw.decode('utf-8')}", exc_info=e)
        if is_optional and not message.is_test_message:
            return None
        raise


@functools.cache
def parse_maybe(
    message: StreamMessageRaw, resolver: StreamResolverParsed, operation_id: str | None = None, log_error: bool = True
) -> ParsedMessage | None:
    """
    MUST BE RUN IN A TRY CATCH BLOCK

    Parse a message if the resolver has a parse function, otherwise package and return the raw message.

    Will raise _if_ the parse function raises.

    Will return None if the parse function returns None and the output is optional.
    """
    if operation_id is None:
        operation_id = str(uuid.uuid4())
    if resolver.is_windowed:
        return _parse_windowed_maybe(message, resolver, operation_id, log_error)
    return _parse_mapping_maybe(message, resolver, operation_id, log_error)


def _parse_mapping_maybe(
    message: StreamMessageRaw,
    stream_resolver: StreamResolverParsed,
    operation_id: str,
    log_error: bool,
) -> ParsedMessage | None:
    message_bytes = message.value_raw
    extracted_key = message.message_key

    message_model = None
    if stream_resolver.parse_info_parsed:
        parse = stream_resolver.raw_resolver.parse
        assert parse is not None
        try:
            parse_param = _get_non_windowed_parsed_param_value(
                input_param=parse.input_type,
                is_optional=parse.output_is_optional,
                message=message,
                log_error=log_error,
            )
            if parse_param is None:
                return None
            message_model = parse.fn(parse_param)
            if message_model is None:
                if parse.output_is_optional:
                    return None
                else:
                    raise ValueError(
                        f"The parse function for '{stream_resolver.fqn}' returned None,"
                        + " but the output type is not optional"
                    )
            message_bytes = _model_to_json(message_model).encode("utf-8")
        except Exception as e:
            if log_error:
                with add_logging_context(
                    **get_operation_log_context(
                        operation_id=operation_id,
                        operation_kind="streaming",
                        resolver_fqn=stream_resolver.fqn,
                    )
                ):
                    _public_logger.error(
                        (
                            f"Streaming resolver '{stream_resolver.fqn}' could not parse message '{message}'"
                            + f"with parse function {parse.fn.__name__} "  # ty:ignore[unresolved-attribute]
                        )
                    )
            raise StreamingMessageFormatError(f"{e.__class__.__name__}: {str(e)}")

    else:
        for param in stream_resolver.raw_resolver.signature.params:
            if isinstance(param, StreamResolverParamMessage):
                try:
                    message_model = coerce_streaming_message_body(message.value_raw, param.typ)
                    break
                except Exception as e:
                    if log_error:
                        log_resolver_error(
                            stream_resolver,
                            ResolverErrors.resolver_raised_exception(resolver_fqn=stream_resolver.fqn, exception=e),
                            public=True,
                        )
                    raise e
    if message_model is None:
        return None

    if stream_resolver.keys:
        sub_keys = [_look_up_value_with_key(message_model, key) for key in stream_resolver.keys.keys()]
        extracted_key = window_key_for(sub_keys)

    timestamp = message.time
    if stream_resolver.timestamp is not None:
        timestamp = _get_timestamp_override(message_model, [stream_resolver], operation_id=operation_id)

    return ParsedMessage(
        extracted_message_key=extracted_key,
        parsed_bytes=message_bytes,
        parsed_model=message_model,
        raw_message=message,
        timestamp=timestamp,
    )


def _parse_windowed_maybe(
    message: StreamMessageRaw, stream_resolver: StreamResolverParsed, operation_id: str, log_error: bool
) -> ParsedMessage | None:
    message_bytes = message.value_raw
    message_key = message.message_key

    # if we have a parse function, we must parse the message's raw bytes to the parse function's input type.
    # otherwise, we parse to the resolver's input type.
    parse = stream_resolver.raw_resolver.parse
    target_bytes_parse_type = parse.input_type if parse else stream_resolver.message
    try:
        message_models = convert_window_value(
            source=[message.value_raw],
            destination_type=list[target_bytes_parse_type],  # ty:ignore[invalid-type-form]
        )
    except Exception as e:
        if log_error:
            log_resolver_error(
                stream_resolver,
                ResolverErrors.resolver_raised_exception(resolver_fqn=stream_resolver.fqn, exception=e),
                public=True,
            )
        raise e
    if not isinstance(message_models, Iterable):
        raise ValueError(f"message_models must be iterable for windowed parsing, got {message_models}")

    message_model = get_unique_item(message_models)

    # If we have a parse function, we must run it on the input message_model and set the result to message_model
    if stream_resolver.parse_info_parsed:
        parse = stream_resolver.raw_resolver.parse
        assert parse is not None
        try:
            message_model = parse.fn(message_model)
            if message_model is None:
                if parse.output_is_optional:
                    return None
                else:
                    raise ValueError(
                        f"The parse function for '{stream_resolver.fqn}' returned None,"
                        + " but the output type is not optional"
                    )

            message_bytes = _model_to_json(message_model).encode("utf-8")
        except Exception as e:
            if log_error:
                with add_logging_context(
                    **get_operation_log_context(
                        operation_id=operation_id,
                        operation_kind="streaming",
                        resolver_fqn=stream_resolver.fqn,
                    )
                ):
                    _public_logger.error(
                        (
                            f"Streaming resolver '{stream_resolver.fqn}' could not parse message '{message_model}'"
                            + f"with parse function {parse.fn.__name__} "  # ty:ignore[unresolved-attribute]
                        )
                    )
            raise StreamingMessageFormatError(f"{e.__class__.__name__}: {str(e)}")
    if stream_resolver.mode == "continuous":
        schema = stream_resolver.schema
        table_input = (
            _model_to_json(message_model).encode("utf-8") if stream_resolver.parse_info_parsed else message_bytes
        )
        try:
            # Emulate the deserialization that's going to happen in WindowBuffer.append() to catch
            # issues that would otherwise happen at read-time
            read_json(
                BytesIO(table_input),
                parse_options=ParseOptions(
                    explicit_schema=schema,
                    newlines_in_values=True,
                    unexpected_field_behavior="error",
                ),
            )

        except Exception as e:
            if log_error:
                with add_logging_context(
                    **get_operation_log_context(
                        operation_id=operation_id,
                        operation_kind="streaming",
                        resolver_fqn=stream_resolver.fqn,
                    )
                ):
                    _public_logger.error(
                        (
                            f"Continuous streaming resolver '{stream_resolver.fqn}' could not parse table "
                            + f"'{table_input}' with schema {schema} "
                        )
                    )
            raise StreamingMessageFormatError(f"{e.__class__.__name__}: {str(e)}")

    if stream_resolver.keys is not None:
        sub_keys = [_look_up_value_with_key(message_model, key) for key in stream_resolver.keys.keys()]
        message_key = window_key_for(sub_keys)

    timestamp = message.time
    if stream_resolver.timestamp is not None:
        timestamp = _get_timestamp_override(message_model, [stream_resolver], operation_id=operation_id)

    return ParsedMessage(
        extracted_message_key=message_key,
        parsed_bytes=message_bytes,
        parsed_model=message_model,
        raw_message=message,
        timestamp=timestamp,
    )


def parse_bytes(value_raw: bytes, resolver: StreamResolverParsed, operation_id: str | None = None) -> str | None:
    """
    Parse a message if the resolver has a parse function, otherwise package and return the raw message.

     Will raise _if_ the parse function raises.

     Will return None if the parse function returns None and the output is optional.
    """
    if operation_id is None:
        operation_id = str(uuid.uuid4())
    if not resolver.parse_info_parsed:
        return value_raw.decode("utf-8")

    assert resolver.raw_resolver.parse is not None
    target_bytes_parse_type = resolver.raw_resolver.parse.input_type

    message_models = convert_window_value(
        source=[value_raw],
        destination_type=list[target_bytes_parse_type],
    )
    if not isinstance(message_models, Iterable):
        raise ValueError(f"message_models must be iterable for windowed parsing, got {message_models}")

    message_model = get_unique_item(message_models)  # 'source' is length 1, so output should be length 1 as well

    try:  # see chalkengine/streaming/streaming_invoker.py::get_windowed_parsed_param_value
        message_model = resolver.raw_resolver.parse.fn(message_model)
        if message_model is None:
            return None

        return message_model.json()
    except Exception as e:
        with _with_log_context(resolver_fqn=resolver.fqn, operation_id=operation_id):
            _public_logger.error(
                (
                    f"Streaming resolver '{resolver.fqn}' could not parse message '{message_model}'"
                    f"with parse function {resolver.raw_resolver.parse.fn.__name__} "  # ty:ignore[unresolved-attribute]
                )
            )
            raise StreamingMessageFormatError(f"{e.__class__.__name__}: {str(e)}")


def get_buffer_key_raw_message(resolver: StreamResolverParsed, message: StreamMessageRaw) -> str | None:
    if not resolver.keys:
        return message.message_key

    parsed = parse_maybe(message, resolver)
    return parsed.extracted_message_key if parsed else None


def _get_timestamp_override(
    parsed_message_model: "BaseModel | DataClassAny",
    resolvers: Sequence[StreamResolverParsed],
    operation_id: str,
) -> datetime:
    # All resolvers for a single source should have the same timestamp value.
    # This should be handled by the parse and register function in chalkpy for stream resolvers
    timestamps: set[str] = set()
    for resolver in resolvers:
        assert resolver.timestamp is not None, "function call checks for timestamp to be set"
        timestamps.add(resolver.timestamp)
    timestamp_attribute_field = get_unique_item(timestamps)
    parsed_message_dict = _model_to_dict(parsed_message_model)

    datetimes: set[datetime] = set()
    for resolver in resolvers:
        with _with_log_context(resolver_fqn=resolver.fqn, operation_id=operation_id):
            # get incoming messages (maybe parsed)
            timestamp_value = parsed_message_dict[timestamp_attribute_field]

            # value must be a datetime
            if not isinstance(timestamp_value, datetime):
                msg = (
                    f"Streaming resolver '{resolver.fqn}' timestamp field '{timestamp_attribute_field}' has a value "
                    f"'{timestamp_value}' which is not a datetime instance "
                )
                chalk_error = ResolverErrors.resolver_raised_exception(
                    resolver_fqn=resolver.fqn, exception=RuntimeError(msg)
                )
                log_resolver_error(resolver, chalk_error, public=True)
                raise FatalResolverError(chalk_error=chalk_error)

            # value must be a timezoned datetime. If not, set to UTC
            if timestamp_value.tzinfo is None or timestamp_value.tzinfo.utcoffset(timestamp_value) is None:
                timestamp_value = timestamp_value.replace(tzinfo=timezone.utc)
            # timestamp must not be different from other timestamps of the same source
            if len(datetimes) > 0 and timestamp_value not in datetimes:
                msg = (
                    f"Streaming resolver '{resolver.fqn}' timestamp field '{timestamp_attribute_field}' has a value "
                    f"'{timestamp_value}' which is a naive datetime instance. Datetime instances must be timezoned "
                )
                chalk_error = ResolverErrors.resolver_raised_exception(
                    resolver_fqn=resolver.fqn, exception=RuntimeError(msg)
                )
                log_resolver_error(resolver, chalk_error, public=True)
                raise FatalResolverError(chalk_error=chalk_error)

            datetimes.add(timestamp_value)

    timestamp = get_unique_item(datetimes)
    return timestamp


class ConversionNode(Enum):
    BYTES = 0
    STR = 1
    DATACLASS = 2
    PYDANTIC = 3
    PYARROW = 4
    POLARS = 5
    DATAFRAME = 6


def _get_end_node(annotation: StreamResolverWindowType):
    if is_list_typ_annotation(annotation):
        item_typ = get_list_item_typ(annotation)
        if item_typ is bytes:
            return ConversionNode.BYTES
        if item_typ is str:
            return ConversionNode.STR
        if dataclasses.is_dataclass(item_typ):
            return ConversionNode.DATACLASS
        if is_pydantic_basemodel(item_typ):
            return ConversionNode.PYDANTIC

    if issubclass(annotation, DataFrame):
        return ConversionNode.DATAFRAME

    if issubclass(annotation, pyarrow.Table):
        return ConversionNode.PYARROW

    if issubclass(annotation, pl.DataFrame):
        return ConversionNode.POLARS

    raise ValueError(f"Unexpected end node value type {annotation}")


def convert_window_value(
    source: Union[Sequence[bytes], pyarrow.Table],
    destination_type: "Union[Type[str], Type[bytes], Type[BaseModel], AnyDataclass]",
):
    n = ConversionNode
    start_node = n.PYARROW if isinstance(source, pyarrow.Table) else n.BYTES
    end_node = _get_end_node(destination_type)
    if start_node == n.PYARROW and end_node == n.DATAFRAME:
        assert issubclass(destination_type, DataFrame)
        target_model = destination_type.__pydantic_model__
        return DataFrame(pl.LazyFrame(source), pydantic_model=target_model, missing_value_strategy="allow")

    return _convert_window_value(source=source, destination_type=destination_type)


def _convert_window_value(
    source: Sequence[bytes] | pyarrow.Table,
    destination_type: "Type[str] | Type[bytes] | Type[BaseModel] | AnyDataclass",
):
    def bytes_to_str(messages: list[bytes]) -> list[str]:
        return [s.decode("utf8") for s in messages]

    def bytes_to_pydantic(messages: list[bytes]) -> "list[BaseModel]":
        assert is_list_typ_annotation(destination_type)
        model = get_list_item_typ(destination_type)
        return [parse_pydantic_model(model, m) for m in messages]

    def pydantic_to_bytes(messages: "list[BaseModel]") -> list[bytes]:
        return [m.json().encode("utf-8") for m in messages]  # ty:ignore[deprecated]

    def bytes_to_dataclass(messages: list[bytes]) -> list[object]:
        assert get_origin(destination_type) is list
        dataclass = getargs(destination_type)[0]  # pyright: ignore[reportArgumentType]  # ty:ignore[invalid-argument-type]
        assert isclass(dataclass) and dataclasses.is_dataclass(dataclass)
        return [dataclass(**json.loads(m)) for m in messages]

    def pyarrow_to_pydantic(table: pyarrow.Table) -> "list[BaseModel]":
        assert is_list_typ_annotation(destination_type)
        model = get_list_item_typ(destination_type)
        df = pl.from_arrow(table)
        assert isinstance(df, pl.DataFrame)
        return [model(**{field: value for field, value in zip(table.column_names, row)}) for row in df.rows()]

    def pyarrow_to_polars(table: pyarrow.Table) -> pl.DataFrame:
        ans = pl.from_arrow(table)
        assert isinstance(ans, pl.DataFrame)
        return ans

    def bytes_to_dataframe(bts: list[bytes]) -> DataFrame:
        assert issubclass(destination_type, DataFrame)
        target_model = destination_type.__pydantic_model__
        if target_model is None:
            raise ValueError(f"destination_type {destination_type} must have a pydantic model")
        body_table: pyarrow.Table = read_json(
            BytesIO(b"".join(bts)),
            parse_options=ParseOptions(
                explicit_schema=pydantic_to_pyarrow_schema(target_model),
                newlines_in_values=True,
                unexpected_field_behavior="error",
            ),
        )
        r = DataFrame(pl.from_arrow(body_table), pydantic_model=target_model, missing_value_strategy="allow")
        return r

    def pyarrow_to_dataframe(table: pyarrow.Table) -> DataFrame:
        assert issubclass(destination_type, DataFrame)
        target_model = destination_type.__pydantic_model__
        r = DataFrame(pl.from_arrow(table), pydantic_model=target_model, missing_value_strategy="allow")
        return r

    n = ConversionNode
    start_node = n.PYARROW if isinstance(source, pyarrow.Table) else n.BYTES
    end_node = _get_end_node(destination_type)
    if start_node == n.PYARROW and end_node == n.DATAFRAME:
        assert isinstance(source, pyarrow.Table)
        return pyarrow_to_dataframe(source)

    return convert_format(
        source,
        edges=[
            (n.BYTES, n.STR, bytes_to_str),
            (n.BYTES, n.PYDANTIC, bytes_to_pydantic),
            (n.BYTES, n.DATACLASS, bytes_to_dataclass),
            (n.BYTES, n.DATAFRAME, bytes_to_dataframe),
            (n.PYDANTIC, n.BYTES, pydantic_to_bytes),
            (n.PYARROW, n.PYDANTIC, pyarrow_to_pydantic),
            (n.PYARROW, n.POLARS, pyarrow_to_polars),
            (n.PYARROW, n.DATAFRAME, pyarrow_to_dataframe),
        ],
        start_node=start_node,
        end_node=end_node,
    )


def get_windowed_param_value(
    param: StreamResolverParam,
    message_bodies: Sequence[bytes] | pa.Table,
    resolver_fqn: str,
    log_error: bool,
):
    if isinstance(param, StreamResolverParamMessageWindow):
        try:
            return convert_window_value(
                source=message_bodies,
                destination_type=param.typ,
            )
        except Exception as e:
            if log_error:
                _public_logger.warning(f"Failed to convert message body: {param}", exc_info=e)
            raise

    raise FatalResolverError(
        chalk_error=ResolverErrors.unrecognized_streaming_window_resolver_arg(resolver_fqn, param.name)
    )


def _look_up_value_with_key(obj: Any, key: str) -> Any:
    """
    Looks up the corresponding key in the object.
    It is assumed that the path is valid (type-correct).

    If the key is a string that contains at least one `.`, it is assumed to be a nested key,
    like `"foo.bar"` which accesses `["foo"]["bar"]`.
    """

    # This is a possibly-nested key:
    sub_obj: Any = obj
    for sub_key in key.split("."):
        assert sub_key != ""
        if sub_obj is None:
            # Attempting to look up a value that does not exist here would crash,
            # so just return `None` instead.
            return None

        if hasattr(sub_obj, sub_key):
            # First, use an attribute if present.
            sub_obj = getattr(sub_obj, sub_key)
            continue

        if isinstance(sub_obj, dict):
            if sub_key not in sub_obj:
                # If the key does not exist in the dictionary, attempting to
                # look it up would crash - suppress this by returning `None` instead.
                return None
            sub_obj = sub_obj[sub_key]
            continue

        # Since it isn't an attribute on the object, and the object is not a `dict`,
        # Assume that it is a pydantic model that we can call `.dict()` on.
        sub_obj = sub_obj.dict()[sub_key]
    return sub_obj
