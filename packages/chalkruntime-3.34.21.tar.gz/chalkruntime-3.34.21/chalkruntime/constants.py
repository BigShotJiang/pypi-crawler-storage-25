from datetime import datetime, timedelta, timezone
from typing import Final

import pyarrow as pa

ID_FEATURE_COL_NAME = "__id__"
TS_COL_NAME = "__ts__"
TS_COL_TYPE = pa.timestamp("us", "UTC")

PRESENCE_INDICATOR_COL_NAME = "__present__"

INDEX_COL_NAME = "__index__"
INDEX_COL_TYPE = pa.int64()
"""The type of the `INDEX_COL_NAME` column."""

CHILD_INDEX_COL_NAME = "__cidx__"
OBSERVED_AT_FEATURE_COL_NAME = "__oat__"
REPLACED_OBSERVED_AT_FEATURE_COL_NAME = "__rat__"
SAMPLE_COL_NAME = "__sample__"
IS_VALID_COL_NAME = "__is_valid__"
RESOLVER_INPUT_PREFIX = "__CHALK_RESOLVER_INPUT__"

HAS_MANY_SAMPLE_COL_NAME = "__hm_sample__"
# Appears in the groups table of a has-many returning scalar resolver, equals __id__ of the input

ONLINE_STORE_TTL_COL_NAME = "__exp__"

CHALK_SPECIAL_COL_NAMES = (
    ID_FEATURE_COL_NAME,
    TS_COL_NAME,
    INDEX_COL_NAME,
    CHILD_INDEX_COL_NAME,
    OBSERVED_AT_FEATURE_COL_NAME,
    REPLACED_OBSERVED_AT_FEATURE_COL_NAME,
    SAMPLE_COL_NAME,
    IS_VALID_COL_NAME,
    HAS_MANY_SAMPLE_COL_NAME,
    ONLINE_STORE_TTL_COL_NAME,
)

INTERNAL_TTL_MAX = timedelta(days=365 * 10)
CLOSE_TO_MIN_UTC = datetime.min.replace(tzinfo=timezone.utc) + timedelta(days=10)

COUNT_COL_NAME = "__count__"
MAX_OBSERVED_AT_COL_NAME = "__max_observed_at__"

# Bucket partition columns live in the ``__chalk__.bucket.<scan_key>`` namespace so existing
# metadata-detection paths (``parse_table_against_feature_graph``, ``parse_input_sql``, etc.)
# skip them automatically via their ``startswith("__chalk__")`` check.
BUCKET_LABEL_PREFIX: Final = "__chalk__.bucket."


class SpecialResolverFQN:
    CHALK_QUERY_INPUT = "__chalk__.query-input"
