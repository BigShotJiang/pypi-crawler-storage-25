from __future__ import annotations

import dataclasses
from typing import Collection

from chalk.sql import BaseSQLSourceProtocol, PostgreSQLSourceImpl
from chalk.sql._internal.query_execution_parameters import (
    BigqueryQueryExecutionParameters,
    PostgresQueryExecutionParameters,
    QueryExecutionParameters,
    SnowflakeQueryExecutionParameters,
)
from chalk.utils.collections import FrozenOrderedSet
from chalk.utils.string import in_regex_set


def attempt_efficient_execution(
    source: BaseSQLSourceProtocol, query_execution_parameters: QueryExecutionParameters
) -> QueryExecutionParameters:
    if isinstance(source, PostgreSQLSourceImpl):
        """Since query_execution_parameters.attempt_efficient_execution is nominally default,
        we should override it if the postgres execution flag is True
        """
        query_execution_parameters = dataclasses.replace(
            query_execution_parameters,
            attempt_efficient_execution=query_execution_parameters.postgres.attempt_efficient_postgres_execution,
        )
    else:
        query_execution_parameters = dataclasses.replace(query_execution_parameters, attempt_efficient_execution=True)
    return query_execution_parameters


@dataclasses.dataclass(frozen=True, kw_only=True, slots=True)
class QueryExecutionParameterFactory:
    snowflake_unload_stage: str | None
    snowflake_storage_integration: str | None
    snowflake_unload_external_location: str | None
    use_efficient_postgres_for_named_queries: FrozenOrderedSet[str]
    always_use_efficient_postgres_offline: bool
    use_polars_read_csv_for_named_queries: FrozenOrderedSet[str]
    bigquery_unload_path: str | None
    num_client_prefetch_threads: int
    max_prefetch_size_bytes: int
    force_polars_read_csv: bool
    skip_pg_datetime_zone_cast: bool
    fallback_to_inefficient_execution: bool

    def get_parameters_for_query(
        self,
        query_name: str | None,
        tags: Collection[str],
    ) -> QueryExecutionParameters:
        """There are other header-like things like OnlineQueryRequestInternal, DatasetRecomputeRequest, etc.
        Currently, they do not affect query execution, but in the future, they should be able to.
        Thus, this method (or another to be created) should handle those in the future.
        """
        return QueryExecutionParameters(
            attempt_efficient_execution=True,
            postgres=PostgresQueryExecutionParameters(
                attempt_efficient_postgres_execution=in_regex_set(
                    query_name, self.use_efficient_postgres_for_named_queries
                )
                or self.always_use_efficient_postgres_offline,
                polars_read_csv=in_regex_set(query_name, self.use_polars_read_csv_for_named_queries)
                or self.force_polars_read_csv,
                skip_datetime_timezone_cast=self.skip_pg_datetime_zone_cast,
            ),
            snowflake=SnowflakeQueryExecutionParameters(
                snowflake_unload_stage=self.snowflake_unload_stage,
                snowflake_storage_integration=self.snowflake_storage_integration,
                snowflake_unload_external_location=self.snowflake_unload_external_location,
            ),
            bigquery=BigqueryQueryExecutionParameters(bigquery_unload_path=self.bigquery_unload_path),
            tags=frozenset(tags),
            max_prefetch_size_bytes=self.max_prefetch_size_bytes,
            num_client_prefetch_threads=self.num_client_prefetch_threads,
            fallback_to_inefficient_execution=self.fallback_to_inefficient_execution,
        )
