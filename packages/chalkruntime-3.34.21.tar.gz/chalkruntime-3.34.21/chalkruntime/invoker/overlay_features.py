import collections
import contextlib
import datetime as dt
import typing
from typing import Any, Mapping, Type

from chalk import DataFrame, Features
from chalk._gen.chalk.graph.v1 import graph_pb2
from chalk.features import Feature
from chalk.features._encoding.pyarrow import pyarrow_to_primitive
from chalk.features.feature_set import CURRENT_FEATURE_REGISTRY, FeatureRegistryProtocol
from chalk.features.feature_set_decorator import _items_fn, _iter_fn, _len_fn  # # pyright: ignore[reportPrivateUsage]
from chalk.utils.collections import FrozenOrderedSet

from chalkruntime.graph.feature import (
    FeatureTimeFeatureType,
    GroupByFeatureType,
    HasManyFeatureType,
    HasOneFeatureType,
    InputFeatureType,
    NamedFeatureType,
    ScalarFeatureType,
)
from chalkruntime.graph.overlay_graph import OverlayGraphInfo


def _get_feature_prop_from_oneof(ft: graph_pb2.FeatureType, prop_name: str) -> typing.Any:
    field_name = ft.WhichOneof("type")
    if field_name is None:
        return None
    f = getattr(ft, field_name, None)
    if f is None:
        return None
    return getattr(f, prop_name, None)


def _get_proto_feature_namespace(ft: graph_pb2.FeatureType) -> str:
    res = _get_feature_prop_from_oneof(ft, "namespace")
    if res is None:
        raise ValueError("Failed to get namespace from proto FeatureType.")
    return res


def _get_proto_feature_name(ft: graph_pb2.FeatureType) -> str:
    res = _get_feature_prop_from_oneof(ft, "name")
    if res is None:
        raise ValueError("Failed to get name from proto FeatureType.")
    return res


class OverlayFeatureRegistry(FeatureRegistryProtocol):
    """
    Feature registry with overlay features not necessarily present in the deployment source.
    This is used for running queries with notebook-defined features.
    """

    def __init__(self, overlay_graph_info: OverlayGraphInfo):
        super().__init__()
        self._overlay_graph_info = overlay_graph_info
        self._graph = overlay_graph_info.graph
        self._registry: dict[str, typing.Type[Features]] = dict()

        current_features = CURRENT_FEATURE_REGISTRY.get().get_feature_sets()
        # Copy the old registry
        self._registry = dict(current_features)
        # Add newly-defined feature sets
        for fs in self._overlay_graph_info.overlay_graph_proto.feature_sets:
            if fs.name in current_features:
                raise ValueError(
                    f"Can't add externally-defined feature class with namespace '{fs.name}', it already exists in the registry."
                )
            f_cls = self._make_overlay_feature_cls(fs)
            self._registry[f_cls.namespace] = f_cls
        # For existing feature sets w/ new features, replace the Features class w/ a new one that has the extra fields
        namespaces_to_overlay_fields: dict[str, list[graph_pb2.FeatureType]] = collections.defaultdict(list)
        for f in self._overlay_graph_info.overlay_graph_proto.feature_fields:
            ns = _get_proto_feature_namespace(f)
            namespaces_to_overlay_fields[ns].append(f)
        for ns, new_fields in namespaces_to_overlay_fields.items():
            if ns not in current_features:
                raise RuntimeError(
                    f"Failed to find feature set w/ namespace '{ns}' while augmenting with externally-defined fields."
                )
            current_f_cls = current_features[ns]
            f_cls = self._make_feature_cls_with_overlay_fields(current_f_cls, new_fields)
            self._registry[f_cls.namespace] = f_cls

    def get_feature_sets(self) -> Mapping[str, Type[Features]]:
        return self._registry

    def get_singletons(self) -> Mapping[str, Type[Features]]:
        raise NotImplementedError("Not currently implemented")

    def _make_overlay_feature_cls_internal(
        self, namespace: str, feature_names: list[str], raw_features_getter: typing.Callable[[], list[Feature]]
    ):
        parsed_feats = {f.name: f for f in self._graph.get_features_in_namespace(namespace)}
        parsed_feats_ordered = [parsed_feats[n] for n in feature_names]
        attribute_names = FrozenOrderedSet(x.attribute_name or x.name for x in parsed_feats_ordered)

        def __init__(self, *args, **kwargs):  # pyright: ignore[reportMissingParameterType]
            for name, val in zip(attribute_names, args):
                if name in kwargs:
                    raise ValueError(f"Argument '{name}' cannot be specified as both a positional and keyword argument")
                kwargs[name] = val

            for k, v in kwargs.items():
                if k not in self._chalk_attribute_names:
                    raise ValueError(
                        f"Constructor for externally-defined feature class {type(self).__name__}.__init__() got an unexpected keyword argument '{k}'."
                    )
                setattr(self, k, v)

        def __setattr__(self, key: str, value: Any):  # pyright: ignore[reportMissingParameterType]
            if key in ["features", "namespace", "items"]:
                object.__setattr__(self, key, value)
            if key not in self._chalk_attribute_names:
                raise ValueError(f"Externally-defined feature '{namespace}' has no feature w/ attribute name '{key}'")
            object.__setattr__(self, key, value)

        def __getattr__(self: Any, name: str):  # pyright: ignore[reportMissingParameterType]
            raise AttributeError(
                f"Feature '{name}' is not defined on this instance of externally-defined feature class '{namespace}'"
            )

        @property
        def features_fn(cls: Any):
            if cls._chalk_raw_features is None:
                cls._chalk_raw_features = cls._chalk_raw_features_getter()
            return cls._chalk_raw_features

        class_namespace = {
            "__init__": __init__,
            "__setattr__": __setattr__,
            "__getattr__": __getattr__,
            "namespace": namespace,
            "features": classmethod(features_fn),  # pyright: ignore[reportArgumentType]  This actually works  # ty:ignore[invalid-argument-type]
            "__is_features__": True,  # For isinstance/issubclass checks against Features
            "__chalk_feature_set__": True,
            "_chalk_attribute_names": attribute_names,
            "_chalk_parsed_features": parsed_feats_ordered,
            "_chalk_raw_features": None,  # Cached data for `cls.features` prop
            "_chalk_raw_features_getter": raw_features_getter,
            "_chalk_is_externally_defined": True,
            "__len__": _len_fn,
            "items": _items_fn,
            "__iter__": _iter_fn,
        }
        return typing.cast(Type[Features], type(namespace, (), class_namespace))

    def _make_overlay_feature_cls(self, fs_proto: graph_pb2.FeatureSet) -> Type[Features]:
        feature_names = [_get_proto_feature_name(f) for f in fs_proto.features]
        parsed_feats = {f.name: f for f in self._graph.get_features_in_namespace(fs_proto.name)}

        def features_getter():
            return [self._make_overlay_feature_field(parsed_feats[fname]) for fname in feature_names]

        return self._make_overlay_feature_cls_internal(
            namespace=fs_proto.name,
            feature_names=feature_names,
            raw_features_getter=features_getter,
        )

    def _make_feature_cls_with_overlay_fields(
        self, existing_cls: Type[Features], new_fields: list[graph_pb2.FeatureType]
    ) -> Type[Features]:
        namespace = existing_cls.namespace
        parsed_feats = {f.name: f for f in self._graph.get_features_in_namespace(namespace)}
        old_feature_names = [x.name for x in existing_cls.features]
        new_feature_names = [_get_proto_feature_name(x) for x in new_fields]
        overlap = set(old_feature_names) & set(new_feature_names)
        if overlap:
            raise ValueError(
                f"Can't add externally-defined feature fields {overlap} to feature class {namespace} since they already exist."
            )
        feature_names = old_feature_names + new_feature_names

        old_features = list(existing_cls.features)

        def features_getter():
            feats = old_features
            for new_name in new_feature_names:
                new_parsed = parsed_feats[new_name]
                feats.append(self._make_overlay_feature_field(new_parsed))
            return feats

        return self._make_overlay_feature_cls_internal(
            namespace=namespace,
            feature_names=feature_names,
            raw_features_getter=features_getter,
        )

    def _parse_rich_type_for_scalar(self, ft: ScalarFeatureType) -> Type:
        if not ft.rich_type_info.has_nontrivial_rich_type:
            typ = pyarrow_to_primitive(ft.pyarrow_dtype, name=ft.fqn)
            if ft.is_feature_nullable:
                typ = typing.Optional[typ]
            return typ  # ty:ignore[invalid-return-type]
        if ft.rich_type_info.rich_type is None:
            raise RuntimeError(
                f"Rich type '{ft.rich_type_info.rich_type_name}' for feature '{ft.root_fqn}' is unavailable."
            )
        typ_parsed = ft.rich_type_info.rich_type
        try:
            return typ_parsed.to_typ()
        except Exception as e:
            raise RuntimeError(
                f"Failed to parse rich type '{ft.rich_type_info.rich_type_name}' for feature '{ft.root_fqn}': {e}"
            ) from e

    def _make_overlay_feature_field(self, ft: NamedFeatureType):
        if not ft.is_externally_defined:
            raise ValueError(
                f"Feature '{ft.root_fqn}' is not externally defined (it already exists in the global registry)"
            )
        kwargs: dict[str, typing.Any] = {
            "name": ft.name,
            "attribute_name": ft.attribute_name,
            "unversioned_attribute_name": ft.original_python_attribute_name,
            "namespace": ft.namespace,
            "is_autogenerated": ft.autogenerated,
            "is_feature_time": isinstance(ft, FeatureTimeFeatureType),
        }
        if isinstance(ft, FeatureTimeFeatureType):
            kwargs["typ"] = dt.datetime
        if isinstance(ft, ScalarFeatureType):
            if ft.version is not None:
                kwargs["version"] = ft.version.maximum
                kwargs["default_version"] = ft.version.default
            kwargs["description"] = ft.description
            kwargs["owner"] = ft.owner
            kwargs["tags"] = ft.tags
            kwargs["primary"] = ft.primary
            kwargs["is_distance_pseudofeature"] = ft.is_distance_pseudofeature
            # TODO default? Note: default isn't used in the features class object so it's probably fine to ignore
            # Note for the cache-related params: we never want to persist these overlay features anyway
            kwargs["max_staleness"] = None
            kwargs["cache_strategy"] = ft.cache_strategy
            kwargs["store_online"] = False
            kwargs["store_offline"] = False
            kwargs["is_deprecated"] = ft.is_deprecated
            if ft.last_for is not None:
                kwargs["last_for"] = ft.last_for.to_feature()
            kwargs["etl_offline_to_online"] = ft.etl_offline_to_online
            kwargs["underscore_expression"] = ft.underscore_expression
            kwargs["typ"] = self._parse_rich_type_for_scalar(ft)
            kwargs["pyarrow_dtype"] = ft.pyarrow_dtype
            # (Note: raw validations not used in chalkpy, no need to recreate)
        if isinstance(ft, HasManyFeatureType):
            kwargs["join"] = lambda: ft.join.to_filter()
            kwargs["join_type"] = "has_many"
            foreign_cls = self._registry[ft.foreign_namespace()]
            kwargs["typ"] = DataFrame[foreign_cls]
        if isinstance(ft, HasOneFeatureType):
            kwargs["join"] = lambda: ft.join.to_filter()
            kwargs["join_type"] = "has_one"
            foreign_cls = self._registry[ft.foreign_namespace()]
            kwargs["typ"] = foreign_cls
        if isinstance(ft, GroupByFeatureType):
            raise NotImplementedError("Can't convert GroupByFeatureType back to original raw feature.")
            # window_materialization
            # group_by_windowed: TODO
        if isinstance(ft, InputFeatureType):
            # TODO: we probably need to do this
            raise NotImplementedError("Can't convert InputFeatureType back to original raw feature.")

        feature_cls = self.get_feature_sets().get(ft.namespace)
        if feature_cls is None:
            raise ValueError(
                f"Failed to parse externally-defined feature {ft.root_fqn} -- Can't find feature set with namespace '{ft.namespace}'."
            )
        kwargs["features_cls"] = feature_cls

        # etl_offline_to_online
        # encoder # TODO rich dencoder
        # decoder # TODO rich dencoder
        # window_durations # TODO window durations?
        # window_duration
        # no_display # TODO?
        # is_pseudofeature # TODO?
        # version_mapping # TODO?

        f = Feature(**kwargs)
        # f._converter = FeatureConverter(
        #     name=ft.fqn,
        #     rich_type=f.typ.parsed_annotation,
        #     is_nullable=False if is_underlying_feature_time(ft) else ft.is_feature_nullable,
        #     pyarrow_dtype=ft.pyarrow_dtype,
        # )
        return f

    def add_feature_set(self, updated_class: Type[Features]):
        raise NotImplementedError(
            "OverlayFeatureRegistry doesn't support adding new @features classes. It should only be used in the context of running externally-defined resolves in a query."
        )


@contextlib.contextmanager
def overlay_registry_ctx(registry: FeatureRegistryProtocol | None):
    if registry is not None:
        token = CURRENT_FEATURE_REGISTRY.set(registry)
        try:
            yield
        finally:
            CURRENT_FEATURE_REGISTRY.reset(token)
    else:
        yield
