import copy
import functools
import itertools
import warnings
from typing import TYPE_CHECKING, Iterable, List, Optional, Protocol, Sequence, TypeAlias, Union, cast

import chalk.functions as F
import chalkdf
import isodate
import polars as pl
import pyarrow as pa
import pyarrow.compute as pc
from chalk.features import DataFrame
from chalk.features.dataframe._filters import PolarsFilterConverter
from chalk.features.dataframe._validation import (
    _generate_empty_series_for_dtype,  # pyright: ignore[reportPrivateUsage]
    _polars_dtype_contains_struct,  # pyright: ignore[reportPrivateUsage]
)
from chalk.utils.collections import FrozenOrderedSet, OrderedSet, unwrap_optional
from chalk.utils.df_utils import pa_cast, pa_table_to_pl_df
from chalk.utils.pl_helpers import is_new_polars, pl_is_uniquable_on, str_json_decode_compat
from chalk.utils.tracing import safe_trace

from chalkruntime.constants import (
    CHILD_INDEX_COL_NAME,
    INDEX_COL_NAME,
    OBSERVED_AT_FEATURE_COL_NAME,
    REPLACED_OBSERVED_AT_FEATURE_COL_NAME,
    RESOLVER_INPUT_PREFIX,
    TS_COL_NAME,
)
from chalkruntime.graph.feature import (
    FeatureTimeFeatureType,
    GroupByFeatureType,
    HasManyFeatureType,
    HasOneFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    WindowedFeatureType,
    get_filters_parsed_from_has_many_feature_type,
    is_underlying_feature_time,
    is_underlying_has_many,
    is_underlying_has_one,
    rewrite_local_join_features_with_input_path,
)
from chalkruntime.graph.filter_conversion import FilterParsedConverter, LibchalkExprConverter
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.underscore import get_filter_expressions_parsed_from_has_many_feature_type
from chalkruntime.metadata import CHALK_METADATA_PREFIX
from chalkruntime.utils.internal_pl_utils import (
    CompatPlDataType,
    PolarsPanicErrorCompat,  # pyright: ignore
    join_compat,
    with_row_index_compat,
)

if TYPE_CHECKING:
    from typing import Callable

    from chalkruntime.graph.feature import UnderlyingHasManyFeatureType
    from libchalk.chalktable import Expr

PKey: TypeAlias = "int | str"


RESOLVER_INPUT_IDX_COL_NAME = "___CHALK_RESOLVER_INPUT_IDX_COL_NAME___"
GROUP_TEMP_COL_NAME = "___CHALK_LAZY_GROUP_INDICES___"


class VectorizedHasManySampler(Protocol):
    def yield_groups_per_row(self) -> Iterable[DataFrame]:
        """
        Yields a dataframe of has-many data for each pkey in the resolver input.
        :param pkeys_list:
        :return:
        """
        ...


class ChalkdfVectorizedHasManySampler(VectorizedHasManySampler):
    def __init__(
        self,
        *,
        resolver_inputs_df: chalkdf.DataFrame,
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        has_many_df: tuple[chalkdf.DataFrame, chalkdf.DataFrame | None],
        index_col_name: str,
        mask_col_name: str | None,
        graph: ResolvedGraph,
        # enable_indexed_has_many_joins: bool,
        allow_planner_postponed_has_many_sampling_planner_option: bool,
        include_metadata_columns: bool,
        filter_expression_parsed_converter: "Callable[[chalkdf.DataFrame, UnderlyingHasManyFeatureType], Expr | None] | None",
        deduplicate_rows: bool,
    ):
        super().__init__()
        # enable_indexed_has_many_joins = True  # DOMINIC EXPERIMENT - set this to true always
        # If joining multiple has-manys against the same resolver inputs, caller may want to reuse the "resolver input idx" column.
        if index_col_name not in resolver_inputs_df.column_names:
            resolver_inputs_df = resolver_inputs_df.with_unique_id(index_col_name)
        self.mask_col_name = mask_col_name
        self.index_col_name = index_col_name
        self.deduplicate_rows = deduplicate_rows
        self.resolver_inputs_df = resolver_inputs_df
        self.has_many_feature = has_many_feature
        self.filter_expression_parsed_converter = filter_expression_parsed_converter

        foreign_pkey_feature = unwrap_optional(
            graph.primary_feature_for_namespace(has_many_feature.underlying.foreign_namespace())
        )
        foreign_ts_feature = unwrap_optional(
            graph.ts_feature_for_namespace(has_many_feature.underlying.foreign_namespace())
        )

        left_join_features = has_many_feature.underlying.get_local_join_features()
        if isinstance(has_many_feature, InputFeatureType):
            left_join_features = [
                InputFeatureType.replace_suffix(has_many_feature, join_feature) for join_feature in left_join_features
            ]

        self._left_join_cols = [feat.root_fqn for feat in left_join_features]
        self._right_join_cols = [feat.root_fqn for feat in has_many_feature.underlying.get_foreign_join_features()]
        self._expected_col_names: list[str] = [x.root_fqn for x in has_many_feature.underlying.df.columns]
        # This mapping that describes how the left (input data) table columns get renamed with the prefix.
        # This renaming occurs to avoid rows of the same name being renamed in weird ways after the join.
        inputs_rename_dict = {
            col_name: RESOLVER_INPUT_PREFIX + col_name
            for col_name in resolver_inputs_df.column_names
            if col_name != index_col_name
        }

        with safe_trace("_get_grouped_rows__get_ungrouped_rows_pyarrow"):
            self._ungrouped_relevant_rows = self._get_ungrouped_rows(
                graph=graph,
                hm_df=has_many_df[0],
                resolver_inputs_df=resolver_inputs_df,
                foreign_ts_feature=foreign_ts_feature,
                has_many_feature=has_many_feature,
                inputs_rename_dict=inputs_rename_dict,
                left_join_cols=self._left_join_cols,
                right_join_cols=self._right_join_cols,
                foreign_pkey_feature=foreign_pkey_feature,
                allow_planner_postponed_has_many_sampling_planner_option=allow_planner_postponed_has_many_sampling_planner_option,
                filter_expression_parsed_converter=self.filter_expression_parsed_converter,
                index_col_name=self.index_col_name,
                mask_col_name=self.mask_col_name,
                deduplicate_rows=self.deduplicate_rows,
            )

        if include_metadata_columns:
            self._expected_col_names = [
                *self._expected_col_names,
                *(
                    CHALK_METADATA_PREFIX + x
                    for x in self._expected_col_names
                    if CHALK_METADATA_PREFIX + x in self._ungrouped_relevant_rows.column_names
                ),
            ]

        self._groups_packed_into_structs = self._pack_groups_into_structs(
            expected_cols=self._expected_col_names,
            has_many_feature=has_many_feature,
            ungrouped_rows=self._ungrouped_relevant_rows,
            index_col_name=self.index_col_name,
            mask_col_name=self.mask_col_name,
            inputs_rename_dict=inputs_rename_dict,
        )

        self._groups_packed_into_list_of_structs = self._pack_groups_into_lists_of_structs(
            self._groups_packed_into_structs, has_many_feature, self.index_col_name, self.mask_col_name
        )

    def join_df_and_pack_into_structs(self) -> chalkdf.DataFrame:
        return self._groups_packed_into_structs

    def join_df_and_pack_into_list_of_structs(self, *, retain_empty_lists: bool) -> chalkdf.DataFrame:
        """
        Joined grouped has-many data against the resolver inputs.
        Stored the has-many data as a list of structs for each row,
        or an empty list/no row if the given row has no data, depending
        on the value of retain_empty_lists.
        """
        assert self._groups_packed_into_list_of_structs is not None, "groups_packed_into_structs must be non-none"
        assert self.resolver_inputs_df is not None
        if retain_empty_lists:
            return self.resolver_inputs_df.join(
                self._groups_packed_into_list_of_structs, on=[self.index_col_name], how="left"
            ).with_columns(
                {
                    str(self.has_many_feature): self._groups_packed_into_list_of_structs.col(
                        str(self.has_many_feature)
                    ).coalesce(
                        pa.scalar(
                            [],
                            self._groups_packed_into_list_of_structs.get_plan().schema_dict[str(self.has_many_feature)],
                        )
                    )
                }
            )
        else:
            return self.resolver_inputs_df.join(
                self._groups_packed_into_list_of_structs, on=[self.index_col_name], how="inner"
            )

    @staticmethod
    def _pack_groups_into_structs(
        *,
        expected_cols: Sequence[str],
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        ungrouped_rows: chalkdf.DataFrame,
        index_col_name: str,
        mask_col_name: str | None,
        inputs_rename_dict: dict[str, str],
    ) -> chalkdf.DataFrame:
        """
        Groups the has-many data by resolver input idx and adds a column of type List[Struct[HasManyFeature]]
        :return: A DataFrame containing 2-3 columns:
                 - `index_col_name`:  (which index in the resolver input this group corresponds to)
                 - `mask_col_name`: (may be omitted - the column to use as a mask for the aggregation)
                 - `has_many_feature.root_fqn`: Grouped has-many data. Each row is a list of Polars structs.
        """
        # Explicitly cast the struct's dtype based on the FeatureConverter since the fields need to have the correct order.
        # df_dtype = has_many_feature.underlying.primitive_converter.polars_dtype
        # assert isinstance(df_dtype, pl.List) and isinstance(df_dtype.inner, pl.Struct), (
        #     "Polars DType for a has-many should be list-of-structs"
        # )
        # Only include columns requested by this resolver

        renamed = ungrouped_rows.rename({v: k for k, v in inputs_rename_dict.items()})
        return renamed.project(
            {
                str(has_many_feature): F.struct_pack(
                    {expected_col: renamed.col(expected_col) for expected_col in expected_cols}
                ),
                index_col_name: renamed.col(index_col_name),
                **(
                    {mask_col_name: renamed.col(mask_col_name)}
                    if mask_col_name is not None and mask_col_name in renamed.schema
                    else {}
                ),
            }
            | {k: renamed.col(k) for k in inputs_rename_dict.keys()}
        )

    @staticmethod
    def _pack_groups_into_lists_of_structs(
        with_structs: chalkdf.DataFrame,
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        index_col_name: str,
        mask_col_name: str | None,
    ):
        agg_underscore = with_structs.col(str(has_many_feature)).array_agg()
        if mask_col_name is not None and mask_col_name in with_structs.schema:
            agg_underscore = agg_underscore.where(with_structs.col(mask_col_name))
        agg_underscore = agg_underscore.alias(str(has_many_feature))

        return with_structs.agg([index_col_name], agg_underscore)

    @staticmethod
    def _get_ungrouped_rows(
        *,
        graph: ResolvedGraph,
        hm_df: chalkdf.DataFrame,
        resolver_inputs_df: chalkdf.DataFrame,
        foreign_pkey_feature: ScalarFeatureType,
        foreign_ts_feature: FeatureTimeFeatureType,
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        inputs_rename_dict: dict[str, str],
        left_join_cols: list[str],
        right_join_cols: list[str],
        filter_expression_parsed_converter: "Callable[[chalkdf.DataFrame, UnderlyingHasManyFeatureType], Expr | None] | None",
        index_col_name: str,
        mask_col_name: str | None,
        # oom_slim_hm_by_dates: bool,
        # oom_slim_hm_by_join_keys: bool,
        # unique_resolver_inputs: bool,
        # enable_indexed_has_many_joins: bool,
        deduplicate_rows: bool,
        allow_planner_postponed_has_many_sampling_planner_option: bool,
    ) -> chalkdf.DataFrame:
        """
        Filters the has-many data to the relevant pkeys & ensures temporal consistency, but does not group them.
        :return: A table containing the following columns:
                 - The has-many columns
                 - The local join key
                 - `index_col_name` -- maps each row of has-many data to the index in the resolver inputs.
        """
        # The row count comes in hand later for maintaining ordering consistent with the inputs
        resolver_inputs_lf = resolver_inputs_df
        hm_lf = hm_df

        needs_oat_rat_calculations = (
            foreign_ts_feature.fqn in hm_lf.column_names or not allow_planner_postponed_has_many_sampling_planner_option
        )

        # If we do not have the feature time column, append it with nulls
        if needs_oat_rat_calculations and foreign_ts_feature.fqn not in hm_lf.column_names:
            # pl.lit(None, pl.Datetime("us", "UTC")).alias(foreign_ts_feature.fqn)
            hm_lf = hm_lf.with_columns(
                {foreign_ts_feature.fqn: chalkdf.Expr.lit(pa.scalar(None, pa.timestamp("us", "UTC")))}
            )

        if needs_oat_rat_calculations and not allow_planner_postponed_has_many_sampling_planner_option:
            # When this planner option is FALSE, __ts__ is the actual feature time
            # hm_lf = hm_lf.with_columns(
            #     pl.col(foreign_ts_feature.fqn).fill_null(pl.col(TS_COL_NAME)).alias(foreign_ts_feature.fqn)
            # )
            hm_lf = hm_lf.with_columns(
                {foreign_ts_feature.fqn: hm_lf.col(foreign_ts_feature.fqn).coalesce(hm_lf.col(TS_COL_NAME))}
            )

        if deduplicate_rows:
            with safe_trace("VectorizedHasManySampler_get_ungrouped_rows_hm_unique"):
                unique_on = [foreign_pkey_feature.fqn]
                if foreign_ts_feature.fqn in hm_lf.column_names:
                    unique_on.append(foreign_ts_feature.fqn)
                if not allow_planner_postponed_has_many_sampling_planner_option:
                    unique_on.append(TS_COL_NAME)
                # Add __index__ to prevent cross-transaction deduplication in bulk queries
                # This ensures that duplicate GL codes across different transactions in a bulk query
                # are treated as distinct results, not as duplicates to be removed
                if (
                    INDEX_COL_NAME in hm_lf.column_names
                    and has_many_feature.underlying.get_nearest_neighbor_join_info()
                ):
                    unique_on.append(INDEX_COL_NAME)
                hm_lf = hm_lf.agg(
                    unique_on,
                    *[hm_lf.column(col).one().alias(col) for col in hm_lf.column_names if col not in unique_on],
                )

        # We need to compute the "observed_at" and "replaced_observed_at" for each row in the RHS, similar
        # to what is done in offline query, if it was not already done in the offline or inject operator result nodes
        # The observed at is the TS feature
        # The replaced observed at should be the TS of the next row for the given pkey
        if needs_oat_rat_calculations and OBSERVED_AT_FEATURE_COL_NAME not in hm_lf.column_names:
            over = [foreign_pkey_feature.fqn]
            if INDEX_COL_NAME in hm_lf.column_names:
                over.append(INDEX_COL_NAME)
            hm_lf = hm_lf.with_columns(
                {
                    OBSERVED_AT_FEATURE_COL_NAME: hm_lf.col(foreign_ts_feature.fqn),
                }
            )
            # hm_lf = hm_lf.order_by(*over, foreign_ts_feature.fqn)
            hm_lf = hm_lf.window(
                over,
                [foreign_ts_feature.fqn],
                chalkdf.WindowExpr.shift(foreign_ts_feature.fqn, REPLACED_OBSERVED_AT_FEATURE_COL_NAME, -1),  # pyright: ignore[reportCallIssue]  # ty:ignore[missing-argument, too-many-positional-arguments]
            )
            # hm_lf = hm_lf.with_columns(
            #     [
            #         pl.col(foreign_ts_feature.fqn).alias(OBSERVED_AT_FEATURE_COL_NAME),
            #         (pl.col(foreign_ts_feature.fqn).shift(-1).over(over).alias(REPLACED_OBSERVED_AT_FEATURE_COL_NAME)),
            #     ]
            # )

        # Fill any null feature times with the ts column
        # This will force the FT for any time-oblivious has-manys to be the execution timestamp, which will cause them to
        # be filtered out if there is also a before/after feature. However, it also ensure that the ft feature is never null
        # when calling the resolver
        if needs_oat_rat_calculations and allow_planner_postponed_has_many_sampling_planner_option:
            # When this planner option is TRUE, __ts__ is the execution time
            # hm_lf = hm_lf.with_columns(
            #     pl.col(foreign_ts_feature.fqn).fill_null(pl.col(TS_COL_NAME)).alias(foreign_ts_feature.fqn)
            # )
            hm_lf = hm_lf.with_columns(
                {foreign_ts_feature.fqn: hm_lf.col(foreign_ts_feature.fqn).coalesce(hm_lf.col(TS_COL_NAME))}
            )

        # We use rewrite_local_join_features_with_input_path not for the join but just so we can easily get all
        # referenced features below.
        df_join_filter = rewrite_local_join_features_with_input_path(has_many_feature)

        # Add in feature time columns that may be needed
        # for x in FrozenOrderedSet((*df_join_filter.all_referenced_features(), *has_many_feature.underlying.df.columns)):
        #     if x.root_fqn not in hm_lf.columns and is_underlying_feature_time(x):
        #         # Batch query does not return nested feature time features
        #         # But the filters and/or requested has-many dataframe may depend on them
        #         # So, we'll alias the root feature time feature to whatever feature time columns were requested
        #         hm_lf = hm_lf.with_columns(pl.col(foreign_ts_feature.fqn).alias(x.root_fqn))

        if needs_oat_rat_calculations:
            hm_lf = hm_lf.with_columns(
                {
                    x.root_fqn: hm_lf.col(foreign_ts_feature.fqn)
                    for x in FrozenOrderedSet(
                        (*df_join_filter.all_referenced_features(), *has_many_feature.underlying.df.columns)
                    )
                    if x.root_fqn not in hm_lf.column_names and is_underlying_feature_time(x)
                }
            )

        # Now we need to filter out rows in the has many dataframe whose timestamps make them inapplicable.
        # hm_oat_before_input_ts_expr = (
        #     pl.col(OBSERVED_AT_FEATURE_COL_NAME).le(pl.col(RESOLVER_INPUT_COL_NAME + TS_COL_NAME))
        # ).or_(pl.col(OBSERVED_AT_FEATURE_COL_NAME).is_null())

        # hm_rat_after_input_ts = (
        #                             pl.col(RESOLVER_INPUT_COL_NAME + TS_COL_NAME).lt(pl.col(REPLACED_OBSERVED_AT_FEATURE_COL_NAME))
        #                         ) | pl.col(REPLACED_OBSERVED_AT_FEATURE_COL_NAME).is_null()

        # We need to convert all the filters that the feature specifies for the has many (i.e. last 7 days, last 30
        # days, etc.) into a list of polars expressions that will be used for filtering after the join.
        # filters_from_feature = get_filters_parsed_from_has_many_feature_type(has_many_feature)
        ts_feature = graph.ts_feature_for_namespace(has_many_feature.underlying.foreign_namespace())

        # Convert has-many filters to a polars expr.
        # arrow_tbl = pl.DataFrame({k: [] for k in hm_df.schema}, hm_df.schema).to_arrow()
        # arrow_schema_dict = {k: v for (k, v) in zip(arrow_tbl.schema.names, arrow_tbl.schema.types)}

        # FilterParsedCon

        # Rename the left join column here since all the left table's column names had that prefix added.
        left_join_cols = [RESOLVER_INPUT_PREFIX + left_join_col for left_join_col in left_join_cols]
        on_dict = {l: r for l, r in zip(left_join_cols, right_join_cols)}

        resolver_inputs_lf_renamed = resolver_inputs_lf.rename(inputs_rename_dict)  # pyright: ignore[reportArgumentType]

        final_resolver_inputs_for_join = resolver_inputs_lf_renamed
        final_hm_lf_for_join = hm_lf

        joined_df = final_resolver_inputs_for_join.join(
            final_hm_lf_for_join,
            on=on_dict,  # pyright: ignore[reportArgumentType]  # ty:ignore[invalid-argument-type]
            how="inner",
            probe_with_right_side=True,
        )

        if needs_oat_rat_calculations:
            hm_oat_before_input_ts_expr = joined_df.col(OBSERVED_AT_FEATURE_COL_NAME).is_null() | (
                joined_df.col(OBSERVED_AT_FEATURE_COL_NAME) <= joined_df.col(RESOLVER_INPUT_PREFIX + TS_COL_NAME)
            )
            hm_rat_after_input_ts = joined_df.col(REPLACED_OBSERVED_AT_FEATURE_COL_NAME).is_null() | (
                joined_df.col(RESOLVER_INPUT_PREFIX + TS_COL_NAME)
                < joined_df.col(REPLACED_OBSERVED_AT_FEATURE_COL_NAME)
            )

            ts_consistency_expr = hm_oat_before_input_ts_expr & hm_rat_after_input_ts

            joined_df = joined_df.filter(ts_consistency_expr)

        # Get the columns we want
        # for left_join_col, right_join_col in zip(left_join_cols, right_join_cols):
        #     if right_join_col not in ungrouped_relevant_rows.columns:
        #         # FIXME: I think this is wrong, because we should not always assume that the join is equality
        #         # I also think we should always have the right join column at this point
        #         ungrouped_relevant_rows = ungrouped_relevant_rows.with_columns(
        #             {right_join_col: ungrouped_relevant_rows.col(left_join_col)}
        #         )
        #

        joined_df = joined_df.with_columns(
            {
                right_join_col: joined_df.col(left_join_col)
                for left_join_col, right_join_col in zip(left_join_cols, right_join_cols)
                if right_join_col not in joined_df.column_names
            }
        )

        # Apply all the polars filters that were generated from the dataframe filters (like last 7 days, last month,
        # etc.) that the self.has_many_feature specified.
        # for pl_filter_from_feature in pl_filters_from_feature:
        #     if pl_filter_from_feature is not None:
        #         ungrouped_relevant_rows = ungrouped_relevant_rows.filter(pl_filter_from_feature)

        if filter_expression_parsed_converter is not None:
            # Default to using the filter_expression_parsed field of the has_many_feature
            filter_expr = filter_expression_parsed_converter(joined_df, has_many_feature)
        else:
            # Backup is to use the old filter_parsed
            filters_from_feature: "list[Expr | None]" = [
                FilterParsedConverter(LibchalkExprConverter(joined_df.get_plan())).convert_filters(
                    filters=[f],
                    df_schema=hm_df.schema._schema_dict,  # pyright:ignore[reportPrivateUsage]
                    timestamp_feature=ts_feature,
                    now=None,
                    now_col_name=RESOLVER_INPUT_PREFIX + TS_COL_NAME,
                )
                for f in OrderedSet(
                    get_filters_parsed_from_has_many_feature_type(has_many_feature)
                    + [
                        fe.tmp_convert_to_exact_filter_parsed()
                        for fe in get_filter_expressions_parsed_from_has_many_feature_type(has_many_feature)
                    ]
                )
            ]
            non_none_filters_from_feature: "list[Expr]" = cast(
                "list[Expr]", list(filter(lambda f: f is not None, filters_from_feature))
            )
            filter_expr = (
                None
                if len(non_none_filters_from_feature) == 0
                else functools.reduce(lambda acc, elem: acc & elem, non_none_filters_from_feature)
            )

        # Either compute a mask column or apply the filter now
        if mask_col_name is not None:
            joined_df = joined_df.with_columns({mask_col_name: filter_expr if filter_expr is not None else True})
        elif filter_expr is not None:
            joined_df = joined_df.filter(filter_expr)

        joined_df = joined_df.select(
            *itertools.chain(
                hm_lf.column_names,
                # take everything from input, which has been renamed with the prefix
                inputs_rename_dict.values(),
                # ordering column
                (index_col_name,),
                (mask_col_name,) if mask_col_name is not None else (),
            )
        )

        return joined_df

    def yield_groups_per_row(self) -> Iterable[DataFrame]:
        raise NotImplementedError


class PolarsVectorizedHasManySampler(VectorizedHasManySampler):
    """
    This class contains the logic for joining Has-Many data against a table of resolver inputs.
    """

    def __init__(
        self,
        *,
        resolver_inputs_df: pl.DataFrame,
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        has_many_df: tuple[pl.DataFrame, pl.DataFrame | None],
        graph: ResolvedGraph,
        oom_slim_hm_by_dates: bool,
        oom_slim_hm_by_join_keys: bool,
        enable_indexed_has_many_joins: bool,
        allow_planner_postponed_has_many_sampling_planner_option: bool,
        include_metadata_columns: bool,
    ):
        super().__init__()
        # If joining multiple has-manys against the same resolver inputs, caller may want to reuse the "resolver input idx" column.
        if RESOLVER_INPUT_IDX_COL_NAME not in resolver_inputs_df.columns:
            resolver_inputs_df = with_row_index_compat(resolver_inputs_df, RESOLVER_INPUT_IDX_COL_NAME)
        self.resolver_inputs_df = resolver_inputs_df
        self.has_many_feature = has_many_feature
        if self.has_many_feature.underlying.get_nearest_neighbor_join_info():  # pyright: ignore[reportAttributeAccessIssue] # graph_cached props are weird for pyright
            # Vector-based join features only worked w/ indexed has-many joins
            enable_indexed_has_many_joins = True

        foreign_pkey_feature = unwrap_optional(
            graph.primary_feature_for_namespace(has_many_feature.underlying.foreign_namespace())
        )
        foreign_ts_feature = unwrap_optional(
            graph.ts_feature_for_namespace(has_many_feature.underlying.foreign_namespace())
        )

        left_join_features = has_many_feature.underlying.get_local_join_features()
        if isinstance(has_many_feature, InputFeatureType):
            left_join_features = [
                InputFeatureType.replace_suffix(has_many_feature, join_feature) for join_feature in left_join_features
            ]

        self._left_join_cols = [feat.root_fqn for feat in left_join_features]
        if (nearest_neighbor_info := has_many_feature.underlying.get_nearest_neighbor_join_info()) is not None:
            self._right_join_cols = [nearest_neighbor_info.foreign_embedding_feature().root_fqn]
        else:
            self._right_join_cols = [feat.root_fqn for feat in has_many_feature.underlying.get_foreign_join_features()]

        self._expected_col_names: list[str] = [x.root_fqn for x in has_many_feature.underlying.df.columns]
        expected_cols = tuple(pl.col(x) for x in self._expected_col_names)
        # This mapping that describes how the left (input data) table columns get renamed with the prefix.
        # This renaming occurs to avoid rows of the same name being renamed in weird ways after the join.
        inputs_rename_dict = {
            col_name: RESOLVER_INPUT_PREFIX + col_name
            for col_name in resolver_inputs_df.columns
            if col_name != RESOLVER_INPUT_IDX_COL_NAME
        }
        unique_resolver_inputs = all(pl_is_uniquable_on(dtype) for dtype in resolver_inputs_df.dtypes)

        if has_many_feature.underlying.get_nearest_neighbor_join_info():
            unique_resolver_inputs = False  # Cannot hash the vectors
            oom_slim_hm_by_join_keys = False  # Cannot hash the vectors

        with safe_trace("_get_grouped_rows__get_ungrouped_rows_non_pyarrow"):
            assert resolver_inputs_df is not None, (
                "Cannot perform vectorized has-many sampling if no `resolver_inputs_df` is set"
            )
            assert has_many_df is not None
            self._ungrouped_relevant_rows = self._get_ungrouped_rows(
                graph=graph,
                hm_df=has_many_df[0],
                mapping_table=has_many_df[1],
                resolver_inputs_df=resolver_inputs_df,
                foreign_ts_feature=foreign_ts_feature,
                has_many_feature=has_many_feature,
                inputs_rename_dict=inputs_rename_dict,
                left_join_cols=self._left_join_cols,
                right_join_cols=self._right_join_cols,
                foreign_pkey_feature=foreign_pkey_feature,
                oom_slim_hm_by_join_keys=oom_slim_hm_by_join_keys,
                oom_slim_hm_by_dates=oom_slim_hm_by_dates,
                unique_resolver_inputs=unique_resolver_inputs,
                enable_indexed_has_many_joins=enable_indexed_has_many_joins,
                allow_planner_postponed_has_many_sampling_planner_option=allow_planner_postponed_has_many_sampling_planner_option,
            )
        # FIXME: do manual caching instead of always calculating both paths

        # Metadata columns may be requested for struct packing to check validity of features
        if include_metadata_columns:
            expected_cols = (
                *expected_cols,
                *(
                    pl.col(CHALK_METADATA_PREFIX + x)
                    for x in self._expected_col_names
                    if CHALK_METADATA_PREFIX + x in self._ungrouped_relevant_rows.columns
                ),
            )

        with safe_trace("_get_grouped_rows__get_grouped_rows_non_pyarrow"):
            self._grouped_rows = self._get_grouped_rows(
                graph=graph,
                resolver_inputs_df=resolver_inputs_df,
                ungrouped_relevant_rows=self._ungrouped_relevant_rows,
                right_join_cols=self._right_join_cols,
                expected_cols=expected_cols,
                inputs_rename_dict=inputs_rename_dict,
                enable_indexed_has_many_joins=enable_indexed_has_many_joins and has_many_df[1] is not None,
            )
        self._groups_packed_into_structs = self._pack_groups_into_structs(
            expected_cols=expected_cols,
            has_many_feature=has_many_feature,
            ungrouped_rows=self._ungrouped_relevant_rows,
        )

    @staticmethod
    def _get_ungrouped_rows(
        *,
        graph: ResolvedGraph,
        hm_df: pl.DataFrame,
        mapping_table: pl.DataFrame | None,
        resolver_inputs_df: pl.DataFrame,
        foreign_pkey_feature: ScalarFeatureType,
        foreign_ts_feature: FeatureTimeFeatureType,
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        inputs_rename_dict: dict[str, str],
        left_join_cols: list[str],
        right_join_cols: list[str],
        oom_slim_hm_by_dates: bool,
        oom_slim_hm_by_join_keys: bool,
        unique_resolver_inputs: bool,
        enable_indexed_has_many_joins: bool,
        allow_planner_postponed_has_many_sampling_planner_option: bool,
    ) -> pl.LazyFrame:
        """
        Filters the has-many data to the relevant pkeys & ensures temporal consistency, but does not group them.
        :return: A table containing the following columns:
                 - The has-many columns
                 - The local join key
                 - `RESOLVER_INPUT_IDX_COL_NAME` -- maps each row of has-many data to the index in the resolver inputs.
        """
        if mapping_table is not None and enable_indexed_has_many_joins:
            # These flags are incompatible with joining with a mapping table
            oom_slim_hm_by_join_keys = False
            oom_slim_hm_by_dates = False

        # The row count comes in hand later for maintaining ordering consistent with the inputs
        resolver_inputs_lf = resolver_inputs_df
        hm_lf = hm_df
        hm_mapping_lf = mapping_table

        # If we do not have the feature time column, append it with nulls
        if foreign_ts_feature.fqn not in hm_lf.columns:
            hm_lf = hm_lf.with_columns(pl.lit(None, pl.Datetime("us", "UTC")).alias(foreign_ts_feature.fqn))

        if not allow_planner_postponed_has_many_sampling_planner_option:
            # When this planner option is FALSE, __ts__ is the actual feature time
            hm_lf = hm_lf.with_columns(
                pl.col(foreign_ts_feature.fqn).fill_null(pl.col(TS_COL_NAME)).alias(foreign_ts_feature.fqn)
            )

        with safe_trace("VectorizedHasManySampler_get_ungrouped_rows_hm_unique"):
            unique_on = [foreign_pkey_feature.fqn, foreign_ts_feature.fqn]
            if not allow_planner_postponed_has_many_sampling_planner_option:
                unique_on.append(TS_COL_NAME)
            # Add __index__ to prevent cross-transaction deduplication in bulk queries
            # This ensures that duplicate GL codes across different transactions in a bulk query
            # are treated as distinct results, not as duplicates to be removed
            if INDEX_COL_NAME in hm_lf.columns and has_many_feature.underlying.get_nearest_neighbor_join_info():
                unique_on.append(INDEX_COL_NAME)
            hm_lf_unique = hm_lf.unique(subset=unique_on)
            if (hm_lf_unique_len := len(hm_lf_unique.lazy().collect())) != (
                hm_lf_len := len(hm_lf.lazy().collect())
            ):  # ty:ignore[invalid-argument-type]
                warnings.warn(
                    f"Got duplicated results for {has_many_feature}: Num unique elements: {hm_lf_unique_len}/{hm_lf_len}"
                )
                hm_lf = hm_lf_unique

        # We need to compute the "observed_at" and "replaced_observed_at" for each row in the RHS, similar
        # to what is done in offline query, if it was not already done in the offline or inject operator result nodes
        # The observed at is the TS feature
        # The replaced observed at should be the TS of the next row for the given pkey
        if OBSERVED_AT_FEATURE_COL_NAME not in hm_lf.columns:
            hm_lf = hm_lf.sort(by=foreign_ts_feature.fqn)
            over = [pl.col(foreign_pkey_feature.fqn)]
            if INDEX_COL_NAME in hm_lf.columns:
                over.append(pl.col(INDEX_COL_NAME))
            hm_lf = hm_lf.with_columns(
                [
                    pl.col(foreign_ts_feature.fqn).alias(OBSERVED_AT_FEATURE_COL_NAME),
                    (pl.col(foreign_ts_feature.fqn).shift(-1).over(over).alias(REPLACED_OBSERVED_AT_FEATURE_COL_NAME)),
                ]
            )

        # Fill any null feature times with the ts column
        # This will force the FT for any time-oblivious has-manys to be the execution timestamp, which will cause them to
        # be filtered out if there is also a before/after feature. However, it also ensure that the ft feature is never null
        # when calling the resolver
        if allow_planner_postponed_has_many_sampling_planner_option:
            # When this planner option is TRUE, __ts__ is the execution time
            hm_lf = hm_lf.with_columns(
                pl.col(foreign_ts_feature.fqn).fill_null(pl.col(TS_COL_NAME)).alias(foreign_ts_feature.fqn)
            )

        # We use rewrite_local_join_features_with_input_path not for the join but just so we can easily get all
        # referenced features below.
        df_join_filter = rewrite_local_join_features_with_input_path(has_many_feature)

        # Add in feature time columns that may be needed
        for x in FrozenOrderedSet((*df_join_filter.all_referenced_features(), *has_many_feature.underlying.df.columns)):
            if x.root_fqn not in hm_lf.columns and is_underlying_feature_time(x):
                # Batch query does not return nested feature time features
                # But the filters and/or requested has-many dataframe may depend on them
                # So, we'll alias the root feature time feature to whatever feature time columns were requested
                hm_lf = hm_lf.with_columns(pl.col(foreign_ts_feature.fqn).alias(x.root_fqn))

        # Now we need to filter out rows in the has many dataframe whose timestamps make them inapplicable.
        hm_oat_before_input_ts_expr = (
            pl.col(OBSERVED_AT_FEATURE_COL_NAME).le(pl.col(RESOLVER_INPUT_PREFIX + TS_COL_NAME))
        ).or_(pl.col(OBSERVED_AT_FEATURE_COL_NAME).is_null())

        hm_rat_after_input_ts = (
            pl.col(RESOLVER_INPUT_PREFIX + TS_COL_NAME).lt(pl.col(REPLACED_OBSERVED_AT_FEATURE_COL_NAME))
        ) | pl.col(REPLACED_OBSERVED_AT_FEATURE_COL_NAME).is_null()

        ts_consistency_expr = hm_oat_before_input_ts_expr & hm_rat_after_input_ts

        # We need to convert all the filters that the feature specifies for the has many (i.e. last 7 days, last 30
        # days, etc.) into a list of polars expressions that will be used for filtering after the join.
        filters_from_feature = get_filters_parsed_from_has_many_feature_type(has_many_feature)
        ts_feature = graph.ts_feature_for_namespace(has_many_feature.underlying.foreign_namespace())

        # Convert has-many filters to a polars expr.
        arrow_tbl = pl.DataFrame({k: [] for k in hm_df.schema}, hm_df.schema).to_arrow()
        arrow_schema_dict = {k: v for (k, v) in zip(arrow_tbl.schema.names, arrow_tbl.schema.types)}
        pl_filters_from_feature: List[Optional[pl.Expr]] = [
            FilterParsedConverter(PolarsFilterConverter()).convert_filters(
                filters=[f],
                df_schema=arrow_schema_dict,
                timestamp_feature=ts_feature,
                now=None,
                now_col_name=RESOLVER_INPUT_PREFIX + TS_COL_NAME,
            )
            for f in filters_from_feature
        ]

        # Rename the left join column here since all the left table's column names had that prefix added.
        left_join_cols = [RESOLVER_INPUT_PREFIX + left_join_col for left_join_col in left_join_cols]

        resolver_inputs_lf_renamed = resolver_inputs_lf.rename(inputs_rename_dict)

        final_resolver_inputs_for_join = resolver_inputs_lf_renamed
        if unique_resolver_inputs:
            final_resolver_inputs_for_join = final_resolver_inputs_for_join.unique(maintain_order=True)
        final_hm_lf_for_join = hm_lf

        if oom_slim_hm_by_join_keys:
            # filter out join keys that don't matter in hm_lf. Note we force collect (i.e. prevent lazy) to ensure polars
            # does this has-many slimming before it tries to do anything later on in the big actual join
            with safe_trace("VectorizedHasManySampler_slim_by_join_keys"):
                inputs_join_col = resolver_inputs_lf_renamed.select(pl.col(left_join_cols))
                if unique_resolver_inputs:
                    inputs_join_col = inputs_join_col.unique(maintain_order=True)
                final_hm_lf_for_join = (
                    inputs_join_col.lazy()
                    .join(other=hm_lf.lazy(), left_on=left_join_cols, right_on=right_join_cols, how="inner")
                    .with_columns(
                        [
                            pl.col(left_join_col).alias(right_join_col)
                            for left_join_col, right_join_col in zip(left_join_cols, right_join_cols)
                        ]
                    )
                    .select([c for c in hm_lf.columns])
                    .collect()
                )

        if oom_slim_hm_by_dates:
            with safe_trace("VectorizedHasManySampler_slim_by_dates"):
                if is_new_polars:
                    resolver_inputs_least_ts_per_input = resolver_inputs_lf_renamed.group_by(left_join_cols)  # pyright: ignore -- backcompat
                else:
                    resolver_inputs_least_ts_per_input = (
                        resolver_inputs_lf_renamed.groupby(  # ty:ignore[unresolved-attribute]
                            left_join_cols
                        )
                    )  # FIXME: Dominic - this might be wrong (should it be *left_join_cols)?

                resolver_inputs_least_ts_per_input = resolver_inputs_least_ts_per_input.agg(
                    [pl.col(RESOLVER_INPUT_PREFIX + TS_COL_NAME).min().alias(RESOLVER_INPUT_PREFIX + TS_COL_NAME)]
                )

                if is_new_polars:
                    resolver_inputs_greatest_ts_per_input = resolver_inputs_lf_renamed.group_by(left_join_cols)  # pyright: ignore -- backcompat
                else:
                    resolver_inputs_greatest_ts_per_input = resolver_inputs_lf_renamed.groupby(
                        left_join_cols
                    )  # ty:ignore[unresolved-attribute]

                resolver_inputs_greatest_ts_per_input = resolver_inputs_greatest_ts_per_input.agg(
                    [pl.col(RESOLVER_INPUT_PREFIX + TS_COL_NAME).max().alias(RESOLVER_INPUT_PREFIX + TS_COL_NAME)]
                )
                # try filtering out any rows that definitely don't meet ts consistency criteria to reduce join size
                final_hm_lf_for_join = (
                    final_hm_lf_for_join.lazy()  # ty:ignore[unresolved-attribute]
                    .join(
                        resolver_inputs_greatest_ts_per_input.lazy(),
                        right_on=left_join_cols,
                        left_on=right_join_cols,
                        how="inner",
                    )
                    .filter(hm_oat_before_input_ts_expr)
                    .select([c for c in hm_lf.columns])
                )
                final_hm_lf_for_join = (
                    final_hm_lf_for_join.join(
                        resolver_inputs_least_ts_per_input.lazy(),
                        right_on=left_join_cols,
                        left_on=right_join_cols,
                        how="inner",
                    )
                    .filter(hm_rat_after_input_ts)
                    .select([c for c in hm_lf.columns])
                )

        if hm_mapping_lf is not None and enable_indexed_has_many_joins:
            # This first join puts the index column from the mapping table onto the lhs side
            ungrouped_relevant_rows = final_resolver_inputs_for_join.lazy().join(
                hm_mapping_lf.lazy(),
                left_on=RESOLVER_INPUT_PREFIX + CHILD_INDEX_COL_NAME,
                right_on=CHILD_INDEX_COL_NAME,
                how="inner",
            )
            ungrouped_relevant_rows = ungrouped_relevant_rows.join(
                final_hm_lf_for_join.lazy(),  # ty:ignore[unresolved-attribute]
                on=INDEX_COL_NAME,
                how="inner",
            )
        else:
            ungrouped_relevant_rows = final_resolver_inputs_for_join.lazy().join(
                final_hm_lf_for_join.lazy(),  # ty:ignore[unresolved-attribute]
                left_on=left_join_cols,
                right_on=right_join_cols,
                how="inner",
            )
        ungrouped_relevant_rows = ungrouped_relevant_rows.filter(ts_consistency_expr)

        # Get the columns we want
        for left_join_col, right_join_col in zip(left_join_cols, right_join_cols):
            if right_join_col not in ungrouped_relevant_rows.columns:
                # FIXME: I think this is wrong, because we should not always assume that the join is equality
                # I also think we should always have the right join column at this point
                ungrouped_relevant_rows = ungrouped_relevant_rows.with_columns(
                    pl.col(left_join_col).alias(right_join_col)
                )

        # Apply all the polars filters that were generated from the dataframe filters (like last 7 days, last month,
        # etc.) that the self.has_many_feature specified.
        for pl_filter_from_feature in pl_filters_from_feature:
            if pl_filter_from_feature is not None:
                ungrouped_relevant_rows = ungrouped_relevant_rows.filter(pl_filter_from_feature)

        ungrouped_relevant_rows = ungrouped_relevant_rows.select(
            itertools.chain(
                hm_lf.columns,
                # take everything from input, which has been renamed with the prefix
                inputs_rename_dict.values(),
                # ordering column
                (RESOLVER_INPUT_IDX_COL_NAME,),
            )
        )

        return ungrouped_relevant_rows.lazy()

    @staticmethod
    def _get_grouped_rows(
        *,
        graph: ResolvedGraph,
        resolver_inputs_df: pl.DataFrame,
        ungrouped_relevant_rows: pl.LazyFrame,
        right_join_cols: list[str],
        inputs_rename_dict: dict[str, str],
        expected_cols: Sequence[pl.Expr],
        enable_indexed_has_many_joins: bool,
    ) -> dict[int, tuple[PKey, pl.DataFrame]]:
        """
        Groups has-many rows by which resolver input (i.e. local pkey) they correspond to
        :return: A dictionary that maps resolver_input_idx to (pkey, Group dataframe)
        """
        if len(resolver_inputs_df) == 0:
            # There are no inputs, no need to yield anything
            return {}

        # Perform grouping in a way that makes the groups iterable.
        if enable_indexed_has_many_joins and len(right_join_cols) == 1:
            right_join_cols = [INDEX_COL_NAME]
        g = with_row_index_compat(ungrouped_relevant_rows, GROUP_TEMP_COL_NAME)

        if is_new_polars:
            g = g.group_by(*right_join_cols, RESOLVER_INPUT_IDX_COL_NAME)  # pyright: ignore -- polars backcompat
        else:
            g = g.groupby(*right_join_cols, RESOLVER_INPUT_IDX_COL_NAME)  # pyright: ignore - polars backcompat  # ty:ignore[unresolved-attribute]

        with safe_trace("VectorizedHasManySampler_get_grouped_rows_groups_collect"):
            groups = g.agg(pl.col(GROUP_TEMP_COL_NAME)).lazy().collect()

        # Note: it is possible (though not the "normal" case) for the has_many table and the inputs
        # to belong to the same namespace. In this edge case, we need to be careful that we always
        # use the values from the has_many table.
        ungrouped_relevant_rows = ungrouped_relevant_rows.rename(
            {v: k for k, v in inputs_rename_dict.items() if v not in ungrouped_relevant_rows.columns}
        )
        with safe_trace("VectorizedHasManySampler_get_grouped_rows_ungrouped_relevant_rows_collect"):
            ungrouped_relevant_rows_collected = ungrouped_relevant_rows.select(expected_cols).lazy().collect()

        group_input_indices: list[int] = (
            groups.select(RESOLVER_INPUT_IDX_COL_NAME).to_series().to_list()
        )  # ty:ignore[unresolved-attribute]
        group_pkeys = (
            groups.select(pl.exclude(GROUP_TEMP_COL_NAME)).to_series().to_list()
        )  # ty:ignore[unresolved-attribute]
        group_indices_list: list[int] = (
            groups.select(GROUP_TEMP_COL_NAME).to_series().to_list()
        )  # ty:ignore[unresolved-attribute]

        # Perform validation on df schema overall. That way we can skip validation for each group, which would be
        # redundant since each group has the same schema.
        _validate_df_schema(ungrouped_relevant_rows_collected, graph=graph)  # ty:ignore[invalid-argument-type]

        # Map the index of the group to a tuple where the first element is the primary key for that group, and the
        # second item is a Series of indices (relative to ungrouped_relevant_rows) that specify the row indices for
        # rows in ungrouped_relevant_rows that are members of the group.
        with safe_trace("VectorizedHasManySampler_get_grouped_rows_ungrouped_relevant_rows_get_groups_dict"):
            groups_dict = {
                group_index: (
                    group_pkey,
                    ungrouped_relevant_rows_collected[group_indices],
                )  # ty:ignore[not-subscriptable]
                for group_indices, group_pkey, group_index in zip(group_indices_list, group_pkeys, group_input_indices)
            }
        return groups_dict

    def yield_groups_per_row(self) -> Iterable[DataFrame]:
        """
        Yields a dataframe of has-many data for each pkey in the resolver input.
        :param pkeys_list:
        :return:
        """
        if len(self.resolver_inputs_df) == 0:
            return

        ungrouped_relevant_rows = self._ungrouped_relevant_rows
        assert isinstance(ungrouped_relevant_rows, pl.LazyFrame)
        # For pkeys that had no rows after grouping, and we want to provide an empty df, but there's no need to make a
        # separate empty DataFrame for each one! We'll make one here, and it'll be used for all the _Samples for each
        # of these pkeys. Saves us lots of time because the latency for making a dataframe is high, even for dfs that
        # are empty.
        with safe_trace(
            "VectorizedHasManySampler_get_grouped_rows_ungrouped_relevant_rows_yield_groups_per_row_get_empty_df"
        ):
            # We call `collect()` here because it appears that without it, future operations on the lazy slice
            # run in a time that scales with the pre-sliced (i.e. len(ungrouped_relevant_rows) size. This causes
            # issues down the line that can slow down resolvers that try to perform ops on it. It's possible a
            # future version polars will fix this issue, but for now this avoids it.
            empty_polars_df = (
                ungrouped_relevant_rows.slice(0, 0).select(self._expected_col_names).collect().lazy()
            )  # ty:ignore[unresolved-attribute]
            empty_chalk_df: DataFrame = DataFrame(  # ... just get Chalk DF metadata right using one of them.
                empty_polars_df,
                missing_value_strategy="default_or_allow",
                # The partitioned groups are already verified to be valid.
                verify_validity=False,
            )

        # We do a sneaky trick here: Instantiating a Chalk DataFrame is slow, and time adds up when you have to do that
        # for thousands of groups. To avoid this, we make just one template Chalk DataFrame from one of the polars
        # group dataframes. We know all the Chalk DataFrame metadata will be the same for all the groups, and we
        # already validated the dataframe schema before grouping, so we can reuse the same Chalk DataFrame as a
        # template from which we will copy.copy(...) and swap out ._underlying with the group's table for each group.
        # This skips the latency added with the Chalk DataFrame .__init__ and just copies all the Python metadata
        # which is valid and the same for each group.
        _, template_group = next(iter(self._grouped_rows.values())) if self._grouped_rows else (None, empty_polars_df)
        template_df = DataFrame(  # ... just get Chalk DF metadata right using one of them.
            template_group,
            missing_value_strategy="default_or_allow",
            # The partitioned groups are already verified to be valid.
            verify_validity=False,
        )

        # Finally, let's iterate over ALL the groups in order of index (which specifies the input row to which the
        # group df output corresponds) as they appeared in the resolver inputs. This maintains ordering between the
        # inputs and outputs (and length too, in cases where the number of groups was shorter than the number of input
        # rows due to no instances of the input row's join key in the has many).
        dfs = []
        for input_index in range(len(self.resolver_inputs_df)):
            with safe_trace(
                "VectorizedHasManySampler_get_grouped_rows_ungrouped_relevant_rows_yield_groups_per_row_yield_df"
            ):
                assert self._grouped_rows is not None
                pl_df = self._grouped_rows[input_index][1] if input_index in self._grouped_rows else None
                if pl_df is None:  # we can just paste in the empty dataframe
                    dfs.append(empty_chalk_df)
                else:
                    copied_df = copy.copy(template_df)
                    copied_df._swap_underlying(  # pyright: ignore[reportPrivateUsage]
                        pl_df.lazy()
                    )  # use same Chalk DF, but swap the data to be this group's polars df. We are trying to be fast.
                    dfs.append(copied_df)

        for df in dfs:
            yield df

    @staticmethod
    def _pack_groups_into_structs(
        *,
        expected_cols: Sequence[pl.Expr],
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        ungrouped_rows: pl.LazyFrame,
    ) -> pl.DataFrame:
        """
        Groups the has-many data by resolver input idx and adds a column of type List[Struct[HasManyFeature]]
        :return: A DataFrame containing two columns:
                 - `RESOLVER_INPUT_IDX_COL_NAME`:  (which index in the resolver input this group corresponds to)
                 - `has_many_feature.root_fqn`: Grouped has-many data. Each row is a list of Polars structs.
        """
        # Explicitly cast the struct's dtype based on the FeatureConverter since the fields need to have the correct order.
        df_dtype = has_many_feature.underlying.primitive_converter.polars_dtype
        assert isinstance(df_dtype, pl.List) and isinstance(df_dtype.inner, pl.Struct), (
            "Polars DType for a has-many should be list-of-structs"
        )
        # Only include columns requested by this resolver

        with_struct = ungrouped_rows.with_columns(pl.struct(expected_cols).alias(str(has_many_feature)))

        if is_new_polars:
            ans = with_struct.group_by(RESOLVER_INPUT_IDX_COL_NAME).agg(  # pyright: ignore -- polars backcompat
                pl.col(str(has_many_feature))
            )
        else:
            ans = with_struct.groupby(RESOLVER_INPUT_IDX_COL_NAME).agg(
                pl.col(str(has_many_feature))
            )  # ty:ignore[unresolved-attribute]
        result = ans.select([RESOLVER_INPUT_IDX_COL_NAME, str(has_many_feature)]).collect()
        return result  # ty:ignore[invalid-return-type]

    def join_df_and_pack_into_struct(self) -> pl.DataFrame:
        """
        Joined grouped has-many data against the resolver inputs.
        Stored the has-many data as a list of structs for each row,
        or an empty list if the given row has no data.
        """
        assert self._groups_packed_into_structs is not None
        assert self.resolver_inputs_df is not None
        return join_compat(
            self.resolver_inputs_df,
            self._groups_packed_into_structs,
            on=RESOLVER_INPUT_IDX_COL_NAME,
            how="left",
            coalesce=True,
        ).with_columns(pl.col(str(self.has_many_feature)).fill_null([]))


class PyArrowVectorizedHasManySampler(VectorizedHasManySampler):
    """
    This class contains the logic for joining Has-Many data against a table of resolver inputs.
    """

    def __init__(
        self,
        *,
        resolver_inputs_table: pa.Table,
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        has_many_table: tuple[pa.Table, pa.Table | None],
        graph: ResolvedGraph,
        # TODO: is this needed?
        allow_planner_postponed_has_many_sampling_planner_option: bool,
    ):
        super().__init__()
        if RESOLVER_INPUT_IDX_COL_NAME not in resolver_inputs_table.column_names:
            with safe_trace("VectorizedHasManySampler__init_add_index_col"):
                resolver_input_indices = pl.arange(0, resolver_inputs_table.num_rows, eager=True).to_arrow()
                resolver_inputs_table = resolver_inputs_table.add_column(
                    0, RESOLVER_INPUT_IDX_COL_NAME, resolver_input_indices
                )
        self.resolver_inputs_table = resolver_inputs_table

        # Nathan note: we're using dicts instead of sets for now because we need column names to be ordered.
        foreign_pkey_feature = unwrap_optional(
            graph.primary_feature_for_namespace(has_many_feature.underlying.foreign_namespace())
        )
        foreign_ts_feature = unwrap_optional(
            graph.ts_feature_for_namespace(has_many_feature.underlying.foreign_namespace())
        )

        left_join_features = has_many_feature.underlying.get_local_join_features()
        if isinstance(has_many_feature, InputFeatureType):
            left_join_features = [
                InputFeatureType.replace_suffix(has_many_feature, join_feature) for join_feature in left_join_features
            ]

        self._left_join_cols = [feat.root_fqn for feat in left_join_features]
        self._right_join_cols = [feat.root_fqn for feat in has_many_feature.underlying.get_foreign_join_features()]
        self._expected_col_names: list[str] = [x.root_fqn for x in has_many_feature.underlying.df.columns]
        # This mapping that describes how the left (input data) table columns get renamed with the prefix.
        # This renaming occurs to avoid rows of the same name being renamed in weird ways after the join.
        inputs_rename_dict = {
            col_name: RESOLVER_INPUT_PREFIX + col_name
            for col_name in resolver_inputs_table.column_names
            if col_name != RESOLVER_INPUT_IDX_COL_NAME
        }

        with safe_trace("_get_grouped_rows__get_ungrouped_rows_pyarrow"):
            self._ungrouped_relevant_rows = self._get_ungrouped_rows_pa(
                graph=graph,
                hm_table=has_many_table[0],
                resolver_inputs_table=resolver_inputs_table,
                foreign_ts_feature=foreign_ts_feature,
                has_many_feature=has_many_feature,
                inputs_rename_dict=inputs_rename_dict,
                left_join_cols=self._left_join_cols,
                right_join_cols=self._right_join_cols,
                foreign_pkey_feature=foreign_pkey_feature,
            )

    @staticmethod
    def _get_ungrouped_rows_pa(
        *,
        graph: ResolvedGraph,
        hm_table: pa.Table,
        resolver_inputs_table: pa.Table,
        foreign_pkey_feature: ScalarFeatureType,
        foreign_ts_feature: FeatureTimeFeatureType,
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        inputs_rename_dict: dict[str, str],
        left_join_cols: list[str],
        right_join_cols: list[str],
    ) -> pa.Table:
        # If we do not have the feature time column, append it with nulls
        if foreign_ts_feature.fqn not in hm_table.schema.names:
            # Create an array with None values and the desired type
            new_column_array = pa.nulls(hm_table.num_rows, type=pa.timestamp("us", tz="UTC"))

            # Add the new column to the Table
            hm_table = hm_table.append_column(foreign_ts_feature.fqn, new_column_array)

        # We need to compute the "observed_at" and "replaced_observed_at" for each row in the RHS, similar
        # to what is done in offline query, if it was not already done in the offline or inject operator result nodes
        # The observed at is the TS feature
        # The replaced observed at should be the TS of the next row for the given pkey
        if OBSERVED_AT_FEATURE_COL_NAME not in hm_table.schema.names:
            # We want to compute:
            # - "observed-at" (`__oat__`) (first-valid-time)
            # - "replaced-at" (`__rat__`) (last-valid-time)
            # In order to do this, we group by PKEY and then sort by FeatureTime.
            # (Actually, we just do a combined sort by PKEY + FeatureTime).
            # Each row's `__rat__` is set to the `__oat__` of the next, unless they have different
            # pkeys, in which case it gets NULLed out since.

            # Sort by pkey, then by ts.
            # This means that all entries with the same pkey will be contiguous.
            sorted_indices = pc.sort_indices(  # ty:ignore[unresolved-attribute]
                hm_table,
                sort_keys=[
                    (foreign_pkey_feature.root_fqn, "ascending"),
                    (foreign_ts_feature.fqn, "ascending"),
                ],
            )
            hm_table = hm_table.take(sorted_indices)
            # Select the column containing the FeatureTime:
            observed_at_col: pa.ChunkedArray = hm_table.column(foreign_ts_feature.fqn)
            # Add the column with a new name, '__oat__'.
            hm_table = hm_table.append_column(OBSERVED_AT_FEATURE_COL_NAME, observed_at_col)

            # Each row is replaced when the next row becomes valid (within each block having the same
            # pkey value), so we just copy the __oat__ column and shift 1 backwards, adding a `null` at the
            # end to match the length with the existing table.
            if hm_table.num_rows != 0:
                replaced_observed_at_array = pa.concat_arrays(
                    [
                        observed_at_col.slice(1).combine_chunks(),
                        pa.nulls(1, type=observed_at_col.type),
                    ]
                )
                col_foreign_pkeys = hm_table.column(foreign_pkey_feature.root_fqn).combine_chunks()
                # Now, we need to mask off any replacements which applied to different pkeys.
                col_foreign_pkeys_shifted = pa.concat_arrays(
                    [
                        col_foreign_pkeys.slice(1),
                        pa.nulls(1, type=col_foreign_pkeys.type),
                    ]
                )
                replaced_observed_at_array = pc.if_else(  # ty:ignore[unresolved-attribute]
                    pc.equal(col_foreign_pkeys, col_foreign_pkeys_shifted),  # ty:ignore[unresolved-attribute]
                    replaced_observed_at_array,
                    pa.scalar(None, replaced_observed_at_array.type),
                )
            else:
                # It's still empty, so we can re-use the same empty array.
                replaced_observed_at_array = observed_at_col.combine_chunks()

            if REPLACED_OBSERVED_AT_FEATURE_COL_NAME in hm_table.schema.names:
                hm_table = hm_table.remove_column(
                    hm_table.schema.get_field_index(REPLACED_OBSERVED_AT_FEATURE_COL_NAME)
                )
            hm_table = hm_table.append_column(REPLACED_OBSERVED_AT_FEATURE_COL_NAME, replaced_observed_at_array)

        # Fill any null feature times with the ts column
        # This will force the FT for any time-oblivious has-manys to be the execution timestamp, which will cause them to
        # be filtered out if there is also a before/after feature. However, it also ensure that the ft feature is never null
        # when calling the resolver
        foreign_ts_col: pa.ChunkedArray = hm_table.column(foreign_ts_feature.fqn)
        ts_col = hm_table.column(TS_COL_NAME)

        # Use coalesce to replace null values in foreign_ts_col with values from ts_col
        combined_array = pc.if_else(
            pc.is_valid(foreign_ts_col), foreign_ts_col, ts_col
        )  # ty:ignore[unresolved-attribute]
        # combined_array = pc.coalesce([foreign_ts_col, ts_col])

        # Replace the original column in the table
        hm_table = hm_table.set_column(
            hm_table.schema.get_field_index(foreign_ts_feature.fqn), foreign_ts_feature.fqn, combined_array
        )

        # We use rewrite_local_join_features_with_input_path not for the join but just so we can easily get all
        # referenced features below.
        df_join_filter = rewrite_local_join_features_with_input_path(has_many_feature)

        # Add in feature time columns that may be needed
        # FIXME: Not convinced that this is correct
        xs = FrozenOrderedSet((*df_join_filter.all_referenced_features(), *has_many_feature.underlying.df.columns))
        for x in xs:
            if x.root_fqn not in hm_table.schema.names and is_underlying_feature_time(x):
                # Batch query does not return nested feature time features
                # But the filters and/or requested has-many dataframe may depend on them
                # So, we'll alias the root feature time feature to whatever feature time columns were requested
                new_col = hm_table.column(foreign_ts_feature.fqn)
                hm_table = hm_table.append_column(x.root_fqn, new_col)

        # Rename the left join column here since all the left table's column names had that prefix added.
        left_join_cols = [RESOLVER_INPUT_PREFIX + left_join_col for left_join_col in left_join_cols]

        # resolver_inputs_table_renamed =
        # Assuming `table` is your pyarrow.Table
        new_names: list[str] = []

        # Rename columns in order
        for col_name in resolver_inputs_table.schema.names:
            if col_name in inputs_rename_dict:
                new_names.append(inputs_rename_dict[col_name])
            else:
                new_names.append(col_name)

        resolver_inputs_table_renamed = resolver_inputs_table.rename_columns(new_names)

        final_resolver_inputs_table_for_join: pa.Table = (
            resolver_inputs_table_renamed  # TODO: unique? (watch out for list[] columns in the table)
        )
        final_hm_table_for_join: pa.Table = hm_table
        with safe_trace("_produce_resolver_args_has_many_has_many___get_ungrouped_rows_pa_join"):
            ungrouped_relevant_rows_table = final_resolver_inputs_table_for_join.join(
                right_table=final_hm_table_for_join,
                keys=left_join_cols,
                right_keys=right_join_cols,
                join_type="inner",
            )

        for right_join_col, left_join_col in zip(right_join_cols, left_join_cols):
            if right_join_col not in ungrouped_relevant_rows_table.column_names:
                ungrouped_relevant_rows_table = ungrouped_relevant_rows_table.add_column(
                    0, right_join_col, ungrouped_relevant_rows_table[left_join_col]
                )

        # ungrouped_relevant_rows_table = ungrouped_relevant_rows_table.filter(ts_consistency_expr)

        # Now we need to filter out rows in the has many dataframe whose timestamps make them inapplicable.
        with safe_trace("_produce_resolver_args_has_many_has_many___get_ungrouped_rows_pa_filter"):
            hm_oat_before_cond_1 = pc.less_equal(  # ty:ignore[unresolved-attribute]
                ungrouped_relevant_rows_table.column(OBSERVED_AT_FEATURE_COL_NAME),
                ungrouped_relevant_rows_table.column(RESOLVER_INPUT_PREFIX + TS_COL_NAME),
            )

            hm_oat_before_cond_1 = pc.fill_null(hm_oat_before_cond_1, False)  # ty: ignore[invalid-argument-type]

            hm_oat_before_cond_2 = pc.is_null(
                ungrouped_relevant_rows_table.column(OBSERVED_AT_FEATURE_COL_NAME)
            )  # ty:ignore[unresolved-attribute]
            hm_oat_before_input_ts_expr = pc.or_(
                hm_oat_before_cond_1, hm_oat_before_cond_2
            )  # ty:ignore[unresolved-attribute]

            hm_oat_after_cond_1 = pc.less(  # ty:ignore[unresolved-attribute]
                ungrouped_relevant_rows_table.column(RESOLVER_INPUT_PREFIX + TS_COL_NAME),
                ungrouped_relevant_rows_table.column(REPLACED_OBSERVED_AT_FEATURE_COL_NAME),
            )

            hm_oat_after_cond_1 = pc.fill_null(hm_oat_after_cond_1, False)  # ty: ignore[invalid-argument-type]

            hm_oat_after_cond_2 = pc.is_null(  # ty:ignore[unresolved-attribute]
                ungrouped_relevant_rows_table.column(REPLACED_OBSERVED_AT_FEATURE_COL_NAME)
            )
            hm_oat_after_input_ts_expr = pc.or_(
                hm_oat_after_cond_1, hm_oat_after_cond_2
            )  # ty:ignore[unresolved-attribute]

            # Combine the bf and af expressions
            ts_consistency_expr = pc.and_(  # ty: ignore[no-matching-overload]
                hm_oat_before_input_ts_expr, hm_oat_after_input_ts_expr
            )
            ungrouped_relevant_rows_table = ungrouped_relevant_rows_table.filter(ts_consistency_expr)

        # Apply all the polars filters that were generated from the dataframe filters (like last 7 days, last month,
        # etc.) that the self.has_many_feature specified.

        # We need to convert all the filters that the feature specifies for the has many (i.e. last 7 days, last 30
        # days, etc.) into a list of polars expressions that will be used for filtering after the join.
        filters_from_feature = get_filters_parsed_from_has_many_feature_type(has_many_feature)
        filter_expressions_from_feature = get_filter_expressions_parsed_from_has_many_feature_type(has_many_feature)
        filters_from_feature.extend(
            [fp for fp in [fe.tmp_convert_to_exact_filter_parsed() for fe in filter_expressions_from_feature]]
        )
        ts_feature = graph.ts_feature_for_namespace(has_many_feature.underlying.foreign_namespace())
        if len(filters_from_feature) > 0:
            converter = PolarsFilterConverter()
            parsed_converter = FilterParsedConverter(PolarsFilterConverter())
            pl_filter_mask = parsed_converter.convert_filters(
                filters=filters_from_feature,
                df_schema=dict(
                    zip(ungrouped_relevant_rows_table.schema.names, ungrouped_relevant_rows_table.schema.types)
                ),
                timestamp_feature=ts_feature,
                now_col_name=RESOLVER_INPUT_PREFIX + TS_COL_NAME,
            )
            if pl_filter_mask is not None:
                # only enter polars land if we absolutely have to
                ungrouped_relevant_rows_df = pa_table_to_pl_df(ungrouped_relevant_rows_table).lazy()
                pl_filter_mask = converter.fill_null(pl_filter_mask, converter.lit(False, pa.bool_()))
                ungrouped_relevant_rows_df = ungrouped_relevant_rows_df.filter(pl_filter_mask)
                ungrouped_relevant_rows_table = pa_cast(
                    ungrouped_relevant_rows_df.collect().to_arrow(),
                    ungrouped_relevant_rows_table.schema,  # ty:ignore[unresolved-attribute]
                )

        # Filter for rows where the foreign primary key is not null
        non_null_mask = pc.is_valid(
            ungrouped_relevant_rows_table.column(foreign_pkey_feature.root_fqn)
        )  # ty:ignore[unresolved-attribute]
        ungrouped_relevant_rows_table = ungrouped_relevant_rows_table.filter(non_null_mask)

        # Get the columns we want
        selection_columns_final = list(
            itertools.chain(
                hm_table.schema.names,
                # take everything from input, which has been renamed with the prefix
                inputs_rename_dict.values(),
                # ordering column
                (RESOLVER_INPUT_IDX_COL_NAME,),
            )
        )
        ungrouped_relevant_rows_table = ungrouped_relevant_rows_table.select(selection_columns_final)

        return ungrouped_relevant_rows_table

    def yield_groups_per_row(self) -> Iterable[DataFrame]:
        """
        Yields a dataframe of has-many data for each pkey in the resolver input.
        :param pkeys_list:
        :return:
        """
        assert isinstance(self._ungrouped_relevant_rows, pa.Table)
        ungrouped_relevant_rows_table: pa.Table = self._ungrouped_relevant_rows

        for i, group_keys in enumerate(
            zip(*(self.resolver_inputs_table.column(left_join_col) for left_join_col in self._left_join_cols))
        ):
            assert len(group_keys) == len(self._right_join_cols), (
                "number of foreign and local join features do not match"
            )
            mask = None
            for j, group_key in enumerate(group_keys):
                if mask is None:
                    mask = pc.and_(  # ty: ignore[unresolved-attribute]
                        pc.fill_null(
                            pc.equal(ungrouped_relevant_rows_table.column(self._right_join_cols[j]), group_key),
                            False,  # ty: ignore[invalid-argument-type]
                        ),
                        pc.equal(
                            ungrouped_relevant_rows_table.column(RESOLVER_INPUT_IDX_COL_NAME), pa.scalar(i)
                        ),  # ty: ignore[unresolved-attribute]
                    )
                else:
                    mask = pc.and_(  # ty:ignore[unresolved-attribute]
                        mask,
                        pc.and_(  # ty: ignore[unresolved-attribute]
                            pc.fill_null(
                                pc.equal(
                                    ungrouped_relevant_rows_table.column(self._right_join_cols[j]), group_key
                                ),  # ty: ignore[unresolved-attribute]
                                False,  # ty: ignore[invalid-argument-type]
                            ),
                            pc.equal(
                                ungrouped_relevant_rows_table.column(RESOLVER_INPUT_IDX_COL_NAME), pa.scalar(i)
                            ),  # ty:ignore[unresolved-attribute]
                        ),
                    )
            assert mask is not None, "the mask should always be constructed by this point"
            input_group_results = ungrouped_relevant_rows_table.filter(mask).select(self._expected_col_names)
            final_pl_frame = pl.DataFrame(input_group_results)
            yield DataFrame(
                final_pl_frame,
                missing_value_strategy="default_or_allow",
                # The partitioned groups are already verified to be valid.
                verify_validity=False,
            )

    @staticmethod
    def can_use_pyarrow_sampler(
        *,
        resolver_inputs_table: pa.Table,
        has_many_feature: HasManyFeatureType | InputFeatureType[HasManyFeatureType],
        has_many_table: tuple[pa.Table, pa.Table | None],
    ) -> bool:
        return not (
            table_has_struct_or_list(resolver_inputs_table)
            or table_has_struct_or_list(has_many_table[0])
            or has_many_feature.underlying.get_nearest_neighbor_join_info()
        )


class NestedHasManySampler:
    """
    Handles nested has-many relationships by processing levels top-down: the outermost
    join is resolved first (preserving its timestamps), then each successive inner level
    is sampled using the matched rows from the level above as resolver inputs.

    For a ``College -> Courses -> Sections`` hierarchy:

    1. **Top** (Courses): obtain the course rows that match each college, including their
       ``__ts__`` values, via :meth:`PolarsVectorizedHasManySampler._get_ungrouped_rows`.
    2. **Inner** (Sections): use those course rows as resolver inputs for a
       :class:`PolarsVectorizedHasManySampler` that packs sections into each course row,
       with temporal filtering driven by the courses' ``__ts__`` values.
    3. **Yield**: emit one :class:`DataFrame` of (augmented) courses per college.

    This top-down ordering is required for correct temporal semantics: the ``__ts__``
    stored in each course row (after the outer join) must govern which section rows are
    considered valid for that course.

    Parameters
    ----------
    resolver_inputs_df:
        The outermost resolver inputs (e.g. the College table).
    levels:
        A list of ``(feature, data_df)`` tuples ordered **outermost to innermost**.
        Each feature must be scoped to its own parent's namespace — i.e. ``Course.sections``
        is passed as a plain :class:`HasManyFeatureType`, not prefixed with
        ``College.courses``.  Example for the two-level case::

            [
                (College.courses, courses_df),   # outermost
                (Course.sections, sections_df),  # innermost
            ]

    graph:
        The resolved feature graph, forwarded to each inner sampler.
    allow_planner_postponed_has_many_sampling_planner_option:
        Forwarded unchanged to each inner :class:`PolarsVectorizedHasManySampler`.
    """

    # Temporary column used to preserve the outer resolver-input index while inner
    # samplers add their own RESOLVER_INPUT_IDX_COL_NAME.
    _OUTER_IDX_COL = "___CHALK_NESTED_HM_OUTER_IDX___"

    def __init__(
        self,
        *,
        resolver_inputs_df: pl.DataFrame,
        levels: list[tuple[HasManyFeatureType | InputFeatureType[HasManyFeatureType], pl.DataFrame]],
        graph: ResolvedGraph,
        allow_planner_postponed_has_many_sampling_planner_option: bool,
    ):
        super().__init__()
        assert len(levels) >= 1, "NestedHasManySampler requires at least one level"
        self._resolver_inputs_df = resolver_inputs_df
        self._levels = levels
        self._graph = graph
        self._allow_postponed = allow_planner_postponed_has_many_sampling_planner_option

    def yield_groups_per_row(self) -> Iterable[DataFrame]:
        levels = self._levels
        outer_feature, outer_data = levels[0]

        if len(levels) == 1:
            # Single level: delegate to the standard sampler unchanged.
            yield from PolarsVectorizedHasManySampler(
                resolver_inputs_df=self._resolver_inputs_df,
                has_many_feature=outer_feature,
                has_many_df=(outer_data, None),
                graph=self._graph,
                oom_slim_hm_by_dates=False,
                oom_slim_hm_by_join_keys=False,
                enable_indexed_has_many_joins=False,
                allow_planner_postponed_has_many_sampling_planner_option=self._allow_postponed,
                include_metadata_columns=False,
            ).yield_groups_per_row()
            return

        # --- Step 1: get outer-level ungrouped rows (e.g. courses matched to colleges) ---
        # We call _get_ungrouped_rows directly instead of constructing a full
        # PolarsVectorizedHasManySampler, because the sampler's __init__ calls
        # _get_grouped_rows which tries to select the outer expected columns (including
        # the nested has-many column e.g. course.sections) — those don't exist in
        # outer_data yet.  _get_ungrouped_rows only does the join + temporal filter,
        # which is exactly what we need here.
        outer_ri_df = self._resolver_inputs_df
        if RESOLVER_INPUT_IDX_COL_NAME not in outer_ri_df.columns:
            outer_ri_df = with_row_index_compat(outer_ri_df, RESOLVER_INPUT_IDX_COL_NAME)

        outer_foreign_pkey = unwrap_optional(
            self._graph.primary_feature_for_namespace(outer_feature.underlying.foreign_namespace())
        )
        outer_foreign_ts = unwrap_optional(
            self._graph.ts_feature_for_namespace(outer_feature.underlying.foreign_namespace())
        )

        outer_left_join_features = outer_feature.underlying.get_local_join_features()
        if isinstance(outer_feature, InputFeatureType):
            outer_left_join_features = [
                InputFeatureType.replace_suffix(outer_feature, jf) for jf in outer_left_join_features
            ]
        outer_left_join_cols = [f.root_fqn for f in outer_left_join_features]
        outer_right_join_cols = [f.root_fqn for f in outer_feature.underlying.get_foreign_join_features()]

        outer_inputs_rename_dict = {
            col: "__CHALK_RESOLVER_INPUT__" + col for col in outer_ri_df.columns if col != RESOLVER_INPUT_IDX_COL_NAME
        }
        outer_unique = all(pl_is_uniquable_on(dtype) for dtype in outer_ri_df.dtypes)

        # outer_ungrouped: RESOLVER_INPUT_IDX_COL_NAME=outer_idx, course cols (incl. __ts__)
        outer_ungrouped: pl.DataFrame = PolarsVectorizedHasManySampler._get_ungrouped_rows(  # pyright: ignore[reportPrivateUsage]
            graph=self._graph,
            hm_df=outer_data,
            mapping_table=None,
            resolver_inputs_df=outer_ri_df,
            foreign_pkey_feature=outer_foreign_pkey,
            foreign_ts_feature=outer_foreign_ts,
            has_many_feature=outer_feature,
            inputs_rename_dict=outer_inputs_rename_dict,
            left_join_cols=outer_left_join_cols,
            right_join_cols=outer_right_join_cols,
            oom_slim_hm_by_dates=False,
            oom_slim_hm_by_join_keys=False,
            unique_resolver_inputs=outer_unique,
            enable_indexed_has_many_joins=False,
            allow_planner_postponed_has_many_sampling_planner_option=self._allow_postponed,
        ).collect()  # ty:ignore[invalid-assignment]

        # --- Step 2: rename outer idx to backup so inner samplers get fresh row indices ---
        # current_rows has _OUTER_IDX=outer_idx, course cols — no RESOLVER_INPUT_IDX_COL_NAME
        current_rows = outer_ungrouped.rename({RESOLVER_INPUT_IDX_COL_NAME: self._OUTER_IDX_COL})

        # --- Step 3: process each inner level in order (top-down) ---
        # Each inner sampler receives the (possibly augmented) rows from the level above as
        # its resolver_inputs.  Because RESOLVER_INPUT_IDX_COL_NAME is absent, the sampler
        # adds a fresh per-row index, joins the next level's data, and packs it as a
        # list-of-structs column.  We then drop that transient index and move on.
        for inner_feature, inner_data in levels[1:]:
            inner_sampler = PolarsVectorizedHasManySampler(
                resolver_inputs_df=current_rows,
                has_many_feature=inner_feature,
                has_many_df=(inner_data, None),
                graph=self._graph,
                oom_slim_hm_by_dates=False,
                oom_slim_hm_by_join_keys=False,
                enable_indexed_has_many_joins=False,
                allow_planner_postponed_has_many_sampling_planner_option=self._allow_postponed,
                include_metadata_columns=False,
            )
            # Result: RESOLVER_INPUT_IDX_COL_NAME=inner_row_idx, _OUTER_IDX=outer_idx,
            #         parent_cols, packed_inner_col
            packed = inner_sampler.join_df_and_pack_into_struct()
            # Drop the transient inner row index; _OUTER_IDX is preserved for the next
            # iteration (or for the final yield step below).
            current_rows = packed.drop(RESOLVER_INPUT_IDX_COL_NAME)

        # --- Step 4: restore outer idx and yield one DataFrame per outer resolver input ---
        # current_rows: _OUTER_IDX=outer_idx, parent_cols (with all inner levels packed in)
        augmented = current_rows.rename({self._OUTER_IDX_COL: RESOLVER_INPUT_IDX_COL_NAME})

        outer_expected_col_names: list[str] = [x.root_fqn for x in outer_feature.underlying.df.columns]
        n_outer = len(self._resolver_inputs_df)

        empty_pl = augmented.filter(pl.lit(False)).select(outer_expected_col_names)
        empty_chalk = DataFrame(
            empty_pl.lazy(),
            missing_value_strategy="default_or_allow",
            verify_validity=False,
            convert_dtypes=False,
        )

        # Build a template Chalk DataFrame from the first non-empty group so we can
        # copy.copy() it for subsequent groups (avoids re-running DataFrame.__init__ N times).
        template_chalk: DataFrame | None = None

        for outer_idx in range(n_outer):
            group_pl = augmented.filter(pl.col(RESOLVER_INPUT_IDX_COL_NAME) == outer_idx).select(
                outer_expected_col_names
            )
            if len(group_pl) == 0:
                yield empty_chalk
            elif template_chalk is None:
                template_chalk = DataFrame(
                    group_pl.lazy(),
                    missing_value_strategy="default_or_allow",
                    verify_validity=False,
                    convert_dtypes=False,
                )
                yield template_chalk
            else:
                copied = copy.copy(template_chalk)
                copied._swap_underlying(group_pl.lazy())  # pyright: ignore[reportPrivateUsage]
                yield copied


def table_has_struct_or_list(table: pa.Table):
    return any(type_contains_struct_or_list(pa_type) for pa_type in table.schema.types)


def type_contains_struct_or_list(pa_type: pa.DataType):
    return (
        pa.types.is_struct(pa_type)
        or pa.types.is_list(pa_type)
        or pa.types.is_large_list(pa_type)
        or pa.types.is_fixed_size_list(pa_type)
    )


def _get_expected_pl_dtype_for_feature(
    ft: ScalarFeatureType
    | HasOneFeatureType
    | HasManyFeatureType
    | WindowedFeatureType
    | FeatureTimeFeatureType
    | GroupByFeatureType
    | InputFeatureType[
        ScalarFeatureType | HasOneFeatureType | HasManyFeatureType | WindowedFeatureType | FeatureTimeFeatureType
    ],
) -> pl.DataType:
    import polars as pl
    import polars.datatypes as pl_dt

    dtype: CompatPlDataType = ft.underlying.polars_dtype  # pyright: ignore
    assert pl_dt.is_polars_dtype(dtype)  # for pyright
    if isinstance(ft, InputFeatureType):
        for path_obj in ft.path:
            if is_underlying_has_many(path_obj.parent):
                dtype = pl.List(inner=dtype)  # pyright: ignore - polars backcompat
    return dtype  # ty:ignore[invalid-return-type]


def _validate_df_schema(underlying: Union[pl.DataFrame, pl.LazyFrame], graph: ResolvedGraph):
    for root_fqn, actual_dtype in underlying.schema.items():
        if root_fqn.startswith(CHALK_METADATA_PREFIX):
            continue
        feature = graph.feature_from_fqn(root_fqn)
        if feature is None:
            raise RuntimeError(f"Feature not found: {root_fqn}")
        if is_underlying_has_one(feature) or is_underlying_has_many(feature):
            continue
        expected_dtype = _get_expected_pl_dtype_for_feature(feature)
        if actual_dtype == expected_dtype:
            continue
        if isinstance(underlying, pl.LazyFrame):
            underlying = underlying.collect()  # ty:ignore[invalid-assignment]
        if (
            len(underlying) == underlying.get_column(root_fqn).null_count() and actual_dtype != expected_dtype
        ):  # ty:ignore[invalid-argument-type, unresolved-attribute]
            # If all values are null, then replace with a null series of the correct datatype
            # It's quite possible that the original column will have an incorrect dtype if all values are null,
            # since there was no data to infer the correct dtype from
            underlying = underlying.with_columns(
                _generate_empty_series_for_dtype(
                    root_fqn, expected_dtype, len(underlying)
                )  # ty:ignore[invalid-argument-type]
            )
        elif (
            isinstance(expected_dtype, pl.List) and actual_dtype == pl.Utf8  # pyright: ignore[reportUnnecessaryComparison]
        ):
            col = str_json_decode_compat(pl.col(root_fqn), expected_dtype)
            try:
                underlying = underlying.with_columns(col.cast(expected_dtype))
            except (Exception, PolarsPanicErrorCompat) as e:
                raise TypeError(
                    f"Values for list feature `{root_fqn}` could not be deserialized from a JSON string to dtype `{expected_dtype}`."
                ) from e

            deser_actual_dtype = underlying[root_fqn].dtype  # ty:ignore[unresolved-attribute]
            if deser_actual_dtype != expected_dtype:
                raise TypeError(
                    f"Values for list feature `{root_fqn}` could not be deserialized from a JSON string to dtype `{expected_dtype}`. Found type {deser_actual_dtype}, instead."
                )
        elif _polars_dtype_contains_struct(expected_dtype):
            # Cannot cast to a struct type. Instead, will error, so the user can ensure the underlying
            # dictionaries / dataclasses are of the correct type
            col = pl.col(root_fqn).cast(expected_dtype)
            try:
                underlying = underlying.with_columns(underlying.select(col))  # ty:ignore[invalid-argument-type]
            except (pl.ComputeError, PolarsPanicErrorCompat) as e:  # ty:ignore[unresolved-attribute]
                try:
                    series = pl.from_arrow(
                        underlying.select(pl.col(root_fqn))
                        .to_arrow()[root_fqn]
                        .cast(feature.pyarrow_dtype)  # ty:ignore[unresolved-attribute]
                    )
                    assert isinstance(series, pl.Series)
                    underlying = underlying.with_columns(series.alias(root_fqn))
                except:
                    raise TypeError(
                        f"Expected struct field '{root_fqn}' to have dtype `{expected_dtype}`; got dtype `{actual_dtype}. Attempted to automatically coerce to the correct dtype, but failed with error: {e}`"
                    ) from e
        else:
            try:
                if actual_dtype == pl.Utf8:  # pyright: ignore[reportUnnecessaryComparison]
                    if isinstance(expected_dtype, pl.Datetime):
                        # tzinfo = None if expected_dtype.time_zone is None else zoneinfo.ZoneInfo(expected_dtype.time_zone)
                        underlying = underlying.with_columns(pl.col(root_fqn).str.strptime(pl.Datetime).alias(root_fqn))
                        if cast(pl.Datetime, underlying.schema[root_fqn]).time_zone is not None:
                            assert expected_dtype.time_zone is not None
                            cast_expr = pl.col(root_fqn).dt.convert_time_zone(expected_dtype.time_zone)
                        else:
                            cast_expr = pl.col(root_fqn).dt.replace_time_zone(expected_dtype.time_zone)
                    elif expected_dtype == pl.Date:
                        cast_expr = pl.col(root_fqn).apply(  # ty:ignore[unresolved-attribute]
                            lambda x: None if x is None else isodate.parse_date(x),
                        )
                    elif expected_dtype == pl.Time:
                        cast_expr = pl.col(root_fqn).apply(  # ty:ignore[unresolved-attribute]
                            lambda x: None if x is None else isodate.parse_time(x),
                        )
                    elif expected_dtype == pl.Duration:
                        cast_expr = pl.col(root_fqn).apply(  # ty:ignore[unresolved-attribute]
                            lambda x: None if x is None else isodate.parse_duration(x),
                        )
                    else:
                        cast_expr = pl.col(root_fqn).cast(expected_dtype)
                    col = cast_expr.alias(root_fqn)
                else:
                    col = pl.col(root_fqn).cast(expected_dtype)
                underlying = underlying.with_columns(col)
            except pl.ComputeError:  # ty:ignore[unresolved-attribute]
                raise TypeError(
                    (
                        f"Values for feature `{root_fqn}` with type '{feature.pyarrow_dtype}' could not be converted "
                        f"to dtype `{expected_dtype}`. Found type {actual_dtype}, instead."
                    )
                )

    return underlying
