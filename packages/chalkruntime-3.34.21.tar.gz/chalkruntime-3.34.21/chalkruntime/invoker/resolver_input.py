from __future__ import annotations

import dataclasses
from datetime import datetime
from typing import TYPE_CHECKING, Mapping, TypeAlias

import pyarrow as pa
import pyarrow.compute as pc
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.collections import FrozenOrderedSet

from chalkruntime.constants import CHILD_INDEX_COL_NAME, INDEX_COL_NAME
from chalkruntime.graph.feature import DataFrameType, HasManyFeatureType, InputFeatureType
from chalkruntime.metadata import get_metadata_col_name, pa_is_value_valid


@dataclasses.dataclass(frozen=True, eq=True, slots=True)
class HasManyFeatureEntry:
    result_and_metadata: ChalkRecordBatch
    """The data for the has many table. This table must include an INDEX column, which is used to map the rows from this table to the rows of the batch's table"""

    mapping_table: ChalkRecordBatch | None
    # NOTE: the index column names are intentionally inverted.
    """A mapping table to link the rows from this has-many feature to the batch's feature. This table contains two columns -- CHILD_INDEX_COL_NAME and INDEX_COL_NAME.
    The CHILD_INDEX_COL_NAME corresponds to the row in the immediate parent table, and the INDEX_COL_NAME corresponds to the row in the has-many table. The length of this table
    is the entire join cardinality. However, since it contains only two integer columns, it should be relatively small.

    If unset, that means the result_and_metadata table has no INDEX_COL_NAME, so we must re-join the result_and_metadata against the local data when joining

    This is only used by new batch planner, since original batch planner doesn't generate nor use a mapping table to do joins.. For original batch planner, this will be None.
    """

    if __debug__:

        def __post_init__(self):
            if self.mapping_table is not None:
                assert self.mapping_table.schema_dict == {INDEX_COL_NAME: pa.int64(), CHILD_INDEX_COL_NAME: pa.int64()}
                assert INDEX_COL_NAME in self.result_and_metadata.schema_dict, (
                    "The result_and_metadata must have an INDEX_COL_NAME if there is a mapping table"
                )


@dataclasses.dataclass(frozen=True, eq=True, slots=True)
class DataframeFeatureEntry:
    result_and_metadata: ChalkRecordBatch
    """The data for this dataframe feature"""


THasManyMapping: TypeAlias = "Mapping[HasManyFeatureType | InputFeatureType[HasManyFeatureType], HasManyFeatureEntry]"
TDataframeMapping: TypeAlias = "Mapping[DataFrameType, DataframeFeatureEntry]"


@dataclasses.dataclass(frozen=True, slots=True)
class LocalResolverInputs:
    """The resolver inputs. All data in this dataclass must be serializable as it will be shared IPC."""

    resolver_fqns: FrozenOrderedSet[str]
    """The resolver FQN for which these arguments apply."""

    scalarish_features: ChalkRecordBatch | None
    """A pyarrow table where the column names are root fqns
    corresponding to the input feature types, scalar feature
    types, and flattened has-one features.

    The "spine" is included in this table with special column
    names `__id__` and `__ts__`.

    If and only if this field is `None`, the resolver takes
    zero or more `DataFrame[...]` inputs as its only args.
    """

    has_many_features: THasManyMapping
    """A mapping from the resolver argument position
    corresponding to a has-many feature to the data and mapping table for the has-many feature.

    The table contains all the rows for
    all distinct pkeys across the entire spine. The mapping table limits when rows
    from the root dataframe correspond to the rows of the has many feature
    """

    df_features: TDataframeMapping
    """A mapping from the resolver argument position
    corresponding to a DataFrame input.
    """

    observed_at_fallback: datetime | None
    """A fallback timestamp for the 'observed_at', if the
    resolver does not return it. It should only be specified for dataframe-taking resovlers;
    otherwise, the observed at fallback should be specified in the scalarish_features table via the
    special `TS_COL_NAME` column"""

    if TYPE_CHECKING:

        def replace(
            self,
            *,
            resolver_fqn: str = ...,
            scalarish_features: ChalkRecordBatch | None = ...,
            has_many_features: THasManyMapping = ...,
            df_features: TDataframeMapping = ...,
            observed_at_fallback: datetime | None = ...,
        ) -> LocalResolverInputs: ...

    else:

        def replace(self, **kwargs):
            return dataclasses.replace(self, **kwargs)

    def to_metadata_data_reconciled_chalk_table(self) -> ChalkRecordBatch:
        """
        Create a ChalkTable from resolver_inputs. This means we'll be making a table of all the input data required
        to realize the feature values which are inputs to the resolver we're running.
        :return: a ChalkTable that encodes the resolver_inputs data.
        """

        # Ok, so what we do here in this method is:
        # (A) Only have columns that appear in the data table (batch.scalarish_features)
        # (C) Keep other columns from data table unchanged where there is no contention with metadata
        # The block below just "hstack"s resolver_inputs.scalarish_features (data) and
        # resolver_inputs.scalarish_feature_metadata (metadata) into a table, with the latter having column prefixes
        # "___chalk_meta___"
        if self.scalarish_features is None:
            raise ValueError("Need non-None scalarish_feature_metadata and scalarish_features.")

        scalarish_features = self.scalarish_features
        if __debug__:
            # If the metadata column is invalid, then the value column should be null
            for column_name in scalarish_features.column_names:
                meta_col_name = get_metadata_col_name(column_name)
                if meta_col_name in scalarish_features.column_names:
                    invalid_rows = scalarish_features.column(column_name).filter(
                        pc.invert(
                            pa_is_value_valid(scalarish_features[meta_col_name])
                        )  # ty:ignore[unresolved-attribute]
                    )
                    assert len(invalid_rows) == invalid_rows.null_count, (
                        "All invalid rows should already have null values"
                    )

        # USED TO DROP METADATA - WE NO LONGER DO (CHA-6936)
        return scalarish_features
