import datetime as dt
import typing
from typing import Any, Sequence

import pyarrow as pa
import pyarrow.compute as pc
from chalk.features import Features
from chalk.features.feature_set import CURRENT_FEATURE_REGISTRY
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.df_utils import to_pylist
from chalk.utils.log_with_context import get_logger

from chalkruntime.constants import TS_COL_NAME
from chalkruntime.exc.failed_argument import FailedArgument
from chalkruntime.graph.feature import (
    FeatureTimeFeatureType,
    HasOneFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    UnderlyingScalarFeatureType,
    is_underlying_feature_time,
    is_underlying_scalar,
)
from chalkruntime.graph.graph import ResolvedGraph
from chalkruntime.graph.resolver import ResolverArgErrorHandlerParsed
from chalkruntime.metadata import (
    get_chalk_fix_invalid_result_propagation,
    get_metadata_col_name,
)

_logger = get_logger(__name__)


class ResolverArgsBuilder:
    """
    This class prepares the actual python objects passed as arguments into python resolvers.
    """

    def __init__(self, graph: ResolvedGraph):
        super().__init__()
        self._graph = graph

    def get_feature_time_arr_for_resolver(
        self,
        unique_input_root_ns: str,
        resolver_inputs_table: ChalkRecordBatch,
        ft_feature: FeatureTimeFeatureType | InputFeatureType[FeatureTimeFeatureType],
        scope_feature_time_to_namespace: bool,
    ) -> pa.Array:
        """
        Gets the actual FeatureTimeFeatureType values for each resolver run -- each as an item in a pa.Array that
        orders the values in order corresponding to the original input order specified in resolver_inputs_table.
        :param resolver_inputs_table: the inputs table containing the columns / data necessary to generate the actual
        concrete feature values that the resolver uses.
        :return: a pa.Array that orders the FeatureTimeFeatureType values in order corresponding to the original
        input order.
        """
        if scope_feature_time_to_namespace:
            feature_time_column_name = ft_feature.root_fqn
        else:
            input_ft_feature = self._graph.ts_feature_for_namespace(unique_input_root_ns)
            assert input_ft_feature is not None
            feature_time_column_name = input_ft_feature.root_fqn

        # Fallback to regular TS_COL_NAME if we can't find the feature time feature in the inputs
        if not resolver_inputs_table.contains_column_name(feature_time_column_name):
            feature_time_column_name = TS_COL_NAME

        # If there are any rows with nulls for the feature time column, just default to the value from TS_COL_NAME
        feature_time_arr: pa.Array = pc.fill_null(
            resolver_inputs_table[feature_time_column_name],
            resolver_inputs_table[TS_COL_NAME],
        )
        return feature_time_arr

    def produce_resolver_args_scalar(
        self,
        resolver_arg: ResolverArgErrorHandlerParsed | None,
        feature_type: UnderlyingScalarFeatureType,
        resolver_inputs_table: ChalkRecordBatch,
    ) -> Sequence[Any | FailedArgument]:
        """
        Gets the actual Scalar feature value of the specified feature for each resolver run -- each as an item in a
        python list. Defaulted values are used in place of Nones if the feature or resolver specified it.
        :param feature_type: The scalar-backed feature type for which we will generate values and place in the list
        :param resolver_inputs_table: the inputs table containing the columns / data necessary to generate the actual
        concrete feature values that the resolver uses.
        :return: an iterable that orders the feature_type values in order corresponding to the original input order.
        """

        values_arr = (
            resolver_inputs_table[feature_type.root_fqn]
            if resolver_inputs_table.contains_column_name(feature_type.root_fqn)
            else pa.nulls(
                len(resolver_inputs_table), feature_type.underlying.pyarrow_dtype
            )  # ty: ignore[no-matching-overload]
        )

        metadata_arr = (
            resolver_inputs_table[get_metadata_col_name(feature_type.root_fqn)]
            if resolver_inputs_table.contains_column_name(get_metadata_col_name(feature_type.root_fqn))
            else pa.nulls(
                len(resolver_inputs_table), feature_type.underlying.pyarrow_dtype
            )  # ty: ignore[no-matching-overload]
        )

        try:
            values_pylist = to_pylist(values_arr)
            metadata_pylist = to_pylist(metadata_arr)
        except Exception as e:
            raise ValueError(f"while processing {feature_type.fqn}\n{e}")
        del values_arr  # use values_pylist
        del metadata_arr

        if resolver_arg is not None and resolver_arg.default_value is not None:
            # First, prefer the default value specified in the resolver signature
            # Assume that the default value is already "rich"
            values_pylist = [resolver_arg.default_value if x is None else x for x in values_pylist]

        elif (
            feature_type.underlying.primitive_converter.has_default
            and (primitive_default := feature_type.underlying.primitive_converter.primitive_default) is not None
        ):
            # We make the values array contain the default value wherever it's currently null.
            values_pylist = [primitive_default if x is None else x for x in values_pylist]

        # Later, we need to know this for the case where the feature_type
        # says the value is missing because it is None but it None was
        # actually the resolver default value. In this case we don't have
        # an error.
        no_default_resolver_or_none_default = resolver_arg is None or resolver_arg.default_value is not None

        if not feature_type.underlying.rich_type_info.has_nontrivial_rich_type:
            # or cast(int, values_arr.index(...).as_py()) >= 0:
            if get_chalk_fix_invalid_result_propagation():
                # New Way: Checks metadata to determine validity of input
                if (
                    no_default_resolver_or_none_default
                    and any(x is None or x is ... for x in values_pylist)
                    and any(x is None for x in metadata_pylist)
                ):
                    if len(metadata_pylist) != len(values_pylist):
                        raise ValueError(f"while processing {feature_type.fqn}\n.Missing metadata cols. ")
                    for i in range(len(metadata_pylist)):
                        unconverted_metadata = metadata_pylist[i]
                        if unconverted_metadata is None:
                            values_pylist[i] = FailedArgument(
                                value=values_pylist[i], expected_feature=str(feature_type)
                            )
            else:
                # Old Way: Checks value to determine validity of input
                # Technically incorrect, slow roll-out using get_chalk_fix_invalid_result_propagation().
                if (
                    not feature_type.is_feature_nullable
                    and no_default_resolver_or_none_default
                    and any(x is None for x in values_pylist)
                ):
                    for i in range(len(values_pylist)):
                        unconverted_val = values_pylist[i]
                        # if unconverted_val is ... or unconverted_val is None:
                        if unconverted_val is None:
                            values_pylist[i] = FailedArgument(
                                value=values_pylist[i], expected_feature=str(feature_type)
                            )

            return values_pylist
        if feature_type.underlying.is_externally_defined:
            raise ValueError(
                f"Can't process notebook-defined feature {feature_type.root_fqn} since it has a non-trivial rich type."
            )
        prim_to_rich_converter = feature_type.underlying.to_feature().converter.from_primitive_to_rich
        for i in range(len(values_pylist)):
            unconverted_val = values_pylist[i]
            if (
                feature_type.underlying.primitive_converter.is_value_missing(unconverted_val)
                and no_default_resolver_or_none_default
                and not feature_type.is_feature_nullable
            ):
                # if we find that the value is missing (is None when it shouldn't be) according to the feature_type
                # AND the resolver function argument also doesn't default to None, we have a failure.
                values_pylist[i] = FailedArgument(value=unconverted_val, expected_feature=str(feature_type))
            else:
                try:
                    values_pylist[i] = ... if unconverted_val is ... else prim_to_rich_converter(unconverted_val)
                except Exception as e:
                    # Not logging the value for security
                    _logger.warning(
                        "Unable to convert a value for feature %s into the rich type",
                        feature_type.root_fqn,
                        exc_info=e,
                    )
                    values_pylist[i] = FailedArgument(value=unconverted_val, expected_feature=str(feature_type))

        return values_pylist

    def produce_resolver_args_feature_time(
        self,
        unique_input_root_ns: str,
        feature_type: FeatureTimeFeatureType | InputFeatureType[FeatureTimeFeatureType],
        resolver_inputs_table: ChalkRecordBatch,
        scope_feature_time_to_namespace: bool,
    ) -> list[dt.datetime]:
        """
        Gets the actual FeatureTimeFeatureType values for each resolver run -- each as an item in a list that orders
        the values in order corresponding to the original input order specified in resolver_inputs_table.
        """
        datetimes = to_pylist(
            self.get_feature_time_arr_for_resolver(
                unique_input_root_ns, resolver_inputs_table, feature_type, scope_feature_time_to_namespace
            )
        )
        return typing.cast(list[dt.datetime], datetimes)

    def produce_resolver_args_has_one(
        self,
        unique_input_root_ns: str,
        feature_type: HasOneFeatureType | InputFeatureType[HasOneFeatureType],
        resolver_inputs_table: ChalkRecordBatch,
        scope_feature_time_to_namespace: bool,
    ) -> typing.List[Features | FailedArgument]:
        """
        Gets the actual Features instances of the specified has one feature for each resolver run -- each as an item in
        a python list. Defaulted values are used in place of Nones if the feature or resolver specified it.
        :param feature_type: The Features-class-instance-backed feature type for which we will generate values and
        place in the list
        :param resolver_inputs_table: the inputs table containing the columns / data necessary to generate the encoded
        concrete feature values that will be used to generate the Features instances, each of which is used as an
        argument for a resolver run.
        pyarrow handles our data types a little more robustly. But it's here if you need it!
        :return: an iterable that orders the feature_type values in order corresponding to the original input order.
        """
        if len(resolver_inputs_table) == 0:
            return []

        nested_features_and_attribute_names: list[
            tuple[
                ScalarFeatureType
                | FeatureTimeFeatureType
                | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType],
                str,
            ]
        ] = []

        for x in feature_type.flatten():
            assert is_underlying_feature_time(x) or is_underlying_scalar(x)
            if x.underlying.attribute_name is not None:
                nested_features_and_attribute_names.append((x, x.underlying.attribute_name))

        foreign_ns: str = feature_type.underlying.foreign_namespace()
        registry = CURRENT_FEATURE_REGISTRY.get().get_feature_sets()
        foreign_cls = registry.get(foreign_ns)
        if foreign_cls is None:
            raise TypeError(
                f"Failed to construct object for feature type '{foreign_ns}': Python class not found in the registry."
            )
        resolver_arg_features_cls: type[Features] = foreign_cls

        arg_name_to_val_list: dict[str, list | pa.Array] = {}
        for nested_f, attribute_name in nested_features_and_attribute_names:
            if is_underlying_feature_time(nested_f):
                arg_name_to_val_list[attribute_name] = self.get_feature_time_arr_for_resolver(
                    unique_input_root_ns, resolver_inputs_table, nested_f, scope_feature_time_to_namespace
                )
            elif is_underlying_scalar(nested_f):
                if get_chalk_fix_invalid_result_propagation():
                    arg_name_to_val_list[attribute_name] = list(
                        self.produce_resolver_args_scalar(
                            ResolverArgErrorHandlerParsed(default_value=None), nested_f, resolver_inputs_table
                        )
                    )
                else:
                    arg_name_to_val_list[attribute_name] = list(
                        self.produce_resolver_args_scalar(None, nested_f, resolver_inputs_table)
                    )
            else:
                raise TypeError(f"Unsupported feature type for has-one feature: {nested_f}")

        features_instances: typing.List[Features | FailedArgument] = []
        for i in range(len(resolver_inputs_table)):
            kwargs = {arg_name: val_list[i] for arg_name, val_list in arg_name_to_val_list.items()}
            if any(isinstance(val, FailedArgument) for val in kwargs.values()):
                features_instances.append(
                    next(iter(failed_arg for failed_arg in kwargs.values() if isinstance(failed_arg, FailedArgument)))
                )
            else:
                features_instances.append(resolver_arg_features_cls(**kwargs))
        return features_instances
