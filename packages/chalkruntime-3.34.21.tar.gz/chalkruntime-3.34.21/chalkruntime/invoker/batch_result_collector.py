from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Literal, Mapping, Sequence, cast

import polars as pl
import pyarrow as pa
import pyarrow.compute as pc
from chalk.client.models import ChalkError, ChalkException
from chalk.features import DataFrame, FeatureConverter, Features
from chalk.utils.chalk_record_batch import ChalkRecordBatch
from chalk.utils.collections import FrozenOrderedSet
from chalk.utils.df_utils import describe_type_of_dataframe, pa_cast, to_pydict
from chalk.utils.environment_parsing import env_var_bool
from chalk.utils.log_with_context import get_logger
from chalk.utils.pl_helpers import recursively_has_struct
from chalk.utils.tracing import safe_trace

from chalkruntime.constants import (
    INDEX_COL_NAME,
    IS_VALID_COL_NAME,
    TS_COL_NAME,
)
from chalkruntime.exc.resolver_errors import ResolverErrors
from chalkruntime.graph.feature import (
    FeatureTimeFeatureType,
    FeatureType,
    FeatureValidationsParsed,
    HasManyFeatureType,
    HasOneFeatureType,
    InputFeatureType,
    ScalarFeatureType,
    UnderlyingScalarFeatureType,
    WindowedFeatureType,
    is_underlying_scalar,
)
from chalkruntime.invoker.resolver_output_metadata import ResolverOutputMetadata
from chalkruntime.invoker.validator import validate_results
from chalkruntime.metadata import (
    get_feature_is_missing_col_name,
    is_feature_is_missing_col,
)

pd = None
try:
    import pandas as pd
except ImportError:
    pass


_logger = get_logger(__name__)


@dataclass(frozen=True)
class _InvocationError:
    index: int | None
    error: ChalkError


_SPECIAL_CLASSES = (
    DataFrame,
    pa.RecordBatch,
    pa.Table,
    pl.LazyFrame,
    pl.DataFrame,
) + ((pd.DataFrame,) if pd is not None else ())


class ResultCollector:
    """Holder to collect individual resolver invocation results into a pyarrow table"""

    __slots__ = (
        "_resolver_fqn",
        "_strict_validations",
        "_metadata",
        "_pl_dfs",
        "_num_rows",
        "_python_object_results",
        "_pa_tables",
        "_observed_at_fallback",
        "_errors",
        "_query_rewriter_output_root_fqns",
        "_check_duplicate_rows",
        "_indices_already_processed",
        "_chalk_result_collector_fastpath",
        "_estimated_size_bytes",
        "_feature_fqn_to_resolver_fqn",
        "_error_on_ellipsis",
    )

    def __init__(
        self,
        resolver_fqn: str,
        strict_validations: Mapping[UnderlyingScalarFeatureType, Sequence[FeatureValidationsParsed]],
        resolver_metadata: ResolverOutputMetadata,
        observed_at_fallback: datetime | None,
        check_duplicate_rows: bool,
        feature_fqn_to_resolver_fqn: Mapping[str, str],
        error_on_ellipsis: bool,
    ):
        super().__init__()

        # self._metadata may be mutated once in self.override_output_fqns
        self._resolver_fqn = resolver_fqn
        self._error_on_ellipsis = error_on_ellipsis
        self._strict_validations = strict_validations
        self._metadata = resolver_metadata
        self._num_rows: int = 0
        self._python_object_results: dict[str, tuple[list[Any], FeatureConverter[Any, Any] | None]] = {
            k: ([], None) for k in resolver_metadata.table_schema
        }
        for ft in self._metadata.output_schema:
            self._python_object_results[ft.root_fqn] = ([], ft.underlying.to_feature().converter)
            self._python_object_results[get_feature_is_missing_col_name(ft.root_fqn)] = ([], None)
        self._pl_dfs: "list[pl.DataFrame]" = []
        self._pa_tables: list[ChalkRecordBatch] = []
        self._observed_at_fallback = observed_at_fallback
        self._errors: list[_InvocationError] = []
        # This allows query rewriters to return outputs with columns that may be unused, None means we don't use this (e.g. not a query rewriter)
        self._query_rewriter_output_root_fqns: FrozenOrderedSet[str] | Literal["not set"] | None = "not set"
        self._check_duplicate_rows = check_duplicate_rows
        self._indices_already_processed: set[int] = set()
        self._chalk_result_collector_fastpath = env_var_bool("CHALK_RESULT_COLLECTOR_FASTPATH")
        self._estimated_size_bytes = 0
        self._feature_fqn_to_resolver_fqn = feature_fqn_to_resolver_fqn

    @property
    def num_collected_rows(self):
        """The total number of collected rows"""
        return self._num_rows

    @property
    def estimated_size_bytes(self):
        return self._estimated_size_bytes

    def _get_effective_resolver_fqn(
        self,
        feature: ScalarFeatureType
        | HasManyFeatureType
        | FeatureTimeFeatureType
        | InputFeatureType[ScalarFeatureType | FeatureTimeFeatureType | HasManyFeatureType]
        | str,
    ):
        return self._feature_fqn_to_resolver_fqn.get(str(feature), self._resolver_fqn)

    def add_result(
        self,
        index: int | None,
        pkey: str | int | None,
        execution_timestamp: datetime | None,
        result: object,
    ) -> None:
        """Add the result to the collector."""
        # We accept results of the following types
        # 1) Feature set
        # 2) a single value (if the resolver is annotated to return a single value)
        # 3) A Dataframe (chalk, polars, or pandas)
        if result.__class__ in _SPECIAL_CLASSES:
            if pd is not None and isinstance(result, pd.DataFrame):
                result = pl.from_pandas(result)

            if isinstance(result, pl.LazyFrame):
                # We want to ensure that any exceptions raised during `LazyFrame::collect()` calls
                # are attributed to the resolver which created the lazy frame and not to the executor.
                #
                # Currently, `.collect()` gets called in the BatchInvoker during execution.
                raise ValueError("LazyFrames should be collected before being added to `add_result`")

            if isinstance(result, DataFrame):
                # Note: we are constructing an intermediate `LazyFrame` here, which is fine.
                # The above check is to make sure that we weren't given an unevaluated `LazyFrame` from client code.
                result = result.to_polars().collect()

            if isinstance(result, pa.RecordBatch):
                result = pa.Table.from_batches([result])

            if isinstance(result, (pa.Table, pl.DataFrame)) and not self._metadata.output_is_df:
                # we returned a dataframe when we were expecting a single row
                if self._metadata.single_output_feature is not None:
                    if is_underlying_scalar(self._metadata.single_output_feature):
                        if result.shape == (0, 1):
                            expected_type_name = self._metadata.single_output_feature.underlying.to_feature().converter.rich_type.__name__
                            if expected_type_name != "Optional":
                                self.add_error(
                                    index,
                                    pkey,
                                    execution_timestamp,
                                    ResolverErrors.wrong_output_type(
                                        resolver_fqn=self._get_effective_resolver_fqn(
                                            self._metadata.single_output_feature
                                        ),
                                        expected_type_name=expected_type_name,
                                        result_type_name="NoneType",
                                        feature_fqn=self._metadata.single_output_feature.display_name,
                                    ),
                                )
                                return
                            else:
                                result = pl.DataFrame(
                                    {
                                        col: [None]
                                        for col in (
                                            result.columns if isinstance(result, pl.DataFrame) else result.column_names
                                        )
                                    }
                                )
                        elif result.shape != (1, 1):
                            self.add_error(
                                index,
                                pkey,
                                execution_timestamp,
                                ResolverErrors.wrong_output_type(
                                    resolver_fqn=self._get_effective_resolver_fqn(self._metadata.single_output_feature),
                                    expected_type_name=f"{self._metadata.single_output_feature.underlying.to_feature().converter.rich_type.__name__} (underlying type of feature '{self._metadata.single_output_feature.root_fqn}')",
                                    result_type_name=describe_type_of_dataframe(result),
                                    feature_fqn=self._metadata.single_output_feature.fqn,
                                ),
                            )
                            return
                        # Extract the single item from the DF and discard the columns
                        result = (
                            result.item() if isinstance(result, pl.DataFrame) else to_pydict(result).popitem()[1][0]
                        )
                    else:
                        # This is a has-many feature, so we put it in a dictionary to escape the detection of a dataframe
                        # We also convert it to the DataFrame type, since its columns will be features anyway
                        if isinstance(result, pa.Table):
                            result = pl.DataFrame(result)
                        expected_columns = cast(
                            HasManyFeatureType, self._metadata.single_output_feature.underlying
                        ).df.columns
                        expected_schema = {
                            col.root_fqn: col.underlying.polars_dtype
                            for col in expected_columns
                            if not isinstance(col.underlying, WindowedFeatureType)
                        }
                        if result.schema != expected_schema:
                            self.add_error(
                                index,
                                pkey,
                                execution_timestamp,
                                ResolverErrors.wrong_df_columns(
                                    resolver_fqn=self._get_effective_resolver_fqn(self._metadata.single_output_feature),
                                    expected=expected_schema.keys(),
                                    actual=FrozenOrderedSet(result.columns),
                                    path=self._metadata.single_output_feature.underlying.fqn,
                                ),
                            )
                            return
                        result = {self._metadata.single_output_feature.root_fqn: DataFrame(result)}
                else:
                    all_output_columns_optional = all(
                        is_underlying_scalar(out_feat) and out_feat.underlying.is_feature_nullable
                        for out_feat in self._metadata.output_schema
                    )
                    if len(result) == 0 and all_output_columns_optional:
                        column_names = result.columns if isinstance(result, pl.DataFrame) else result.column_names
                        # Intentionally not passing a schema here, because
                        # we will just turn this DF into a dict of {fqn: None}
                        # below
                        result = pl.DataFrame({col: [None] for col in column_names})
                    elif len(result) != 1:
                        self.add_error(
                            index,
                            pkey,
                            execution_timestamp,
                            ResolverErrors.dataframe_instead_of_scalar(
                                resolver_fqn=self._resolver_fqn,
                                dataframe_shape=result.shape,
                                dataframe_columns=result.column_names
                                if isinstance(result, pa.Table)
                                else result.columns,
                            ),
                        )
                        return
                    result = result.to_dicts()[0] if isinstance(result, pl.DataFrame) else result.to_pylist()[0]
            if isinstance(result, pa.Table):
                self._append_table(index, pkey, execution_timestamp, result)
                return
            elif isinstance(result, pl.DataFrame):
                self._append_df(index, pkey, execution_timestamp, result)
                return
        if getattr(result, "__is_features__", False):  # This is faster than the subclass check
            result_row: dict[str, Any] = {}

            def recurse_over_results(r: Any, fqn_parent: str):
                for f in cast(Features, r).features:
                    if hasattr(r, f.attribute_name) and not f.no_display:
                        f_attr = getattr(r, f.attribute_name)
                        path = f.root_fqn if fqn_parent == "" else fqn_parent + f.root_fqn.split(".", 1)[-1]
                        if getattr(f_attr, "__is_features__", False):
                            recurse_over_results(f_attr, path + ".")
                        else:
                            result_row[path] = getattr(r, f.attribute_name)

            recurse_over_results(result, "")
        elif isinstance(result, dict):
            result_row = {str(k): v for k, v in result.items()}
        elif self._metadata.single_output_feature is not None and self._metadata.is_one_to_one_resolver:
            self._append_raw_row_single(index, pkey, execution_timestamp, result)
            return
        elif result is None:
            result_row = {col.root_fqn: ... for col in self._metadata.output_schema}
        else:
            self.add_error(
                index,
                pkey,
                execution_timestamp,
                ResolverErrors.wrong_output_type(
                    resolver_fqn=self._resolver_fqn,
                    expected_type_name="DataFrame, Mapping, or Features set",
                    result_type_name=type(result).__name__,
                    feature_fqn=None,
                ),
            )
            return
        self._append_raw_row(index, pkey, execution_timestamp, result_row)

    def _append_raw_row_single(
        self,
        index: int | None,
        pkey: str | int | None,
        execution_timestamp: datetime | None,
        result: Any,
    ):
        assert self._metadata.single_output_feature is not None
        if result is None or result is ...:
            if self._metadata.single_output_feature_default is not ...:
                # Has default
                if self._metadata.single_output_feature_is_nullable:
                    # None is valid, not default
                    if result is ...:
                        result = self._metadata.single_output_feature_default
                else:
                    result = self._metadata.single_output_feature_default
            else:
                self.add_error(
                    index,
                    pkey,
                    execution_timestamp,
                    ResolverErrors.wrong_output_type(
                        expected_type_name=rt.__name__
                        if isinstance(  # pyright: ignore[reportUnnecessaryIsInstance]
                            rt := self._metadata.single_output_feature.underlying.primitive_converter.primitive_type,
                            type,
                        )
                        else str(rt),
                        result_type_name="NoneType",
                        resolver_fqn=self._get_effective_resolver_fqn(self._metadata.single_output_feature),
                        feature_fqn=self._metadata.single_output_feature.root_fqn,
                    ),
                )
                return
        self._python_object_results[IS_VALID_COL_NAME][0].append(True)
        self._python_object_results[self._metadata.single_output_feature.root_fqn][0].append(result)
        if self._metadata.is_one_to_one_resolver:
            self._python_object_results[get_feature_is_missing_col_name(self._metadata.single_output_feature.root_fqn)][
                0
            ].append(result is ...)
        self._num_rows += 1
        self._estimated_size_bytes += self._metadata.estimated_row_size_bytes

    def _append_raw_row(
        self,
        index: int | None,
        pkey: str | int | None,
        execution_timestamp: datetime | None,
        result_row: dict[str, Any],
    ):
        # See if there are nullable has-one features here
        nullable_has_one_features: list[str] = []
        seen_parents = set()
        for feat in self._metadata.output_schema:
            if isinstance(feat, InputFeatureType):
                parent_has_one = feat.path[-1].parent
                if parent_has_one in seen_parents:
                    continue
                seen_parents.add(parent_has_one)
                if isinstance(parent_has_one, HasOneFeatureType) and parent_has_one.is_feature_nullable:
                    nullable_has_one_features.extend([f.fqn for f in parent_has_one.features])
                    for local_join_feat in feat.path[-1].parent.get_local_join_features():
                        nullable_has_one_features.append(local_join_feat.fqn)

        # Using the private method for perf
        if result_row.keys() != self._metadata.resolver_output_root_fqns._items.keys():  # pyright: ignore[reportPrivateUsage]
            # Hack to fix a bug where we allowed returning the sub-class directly without it being wrapped in the parent class
            output_fqns_to_features = {x.root_fqn: x for x in self._metadata.output_schema}
            for k in tuple(result_row):
                if (
                    k not in self._metadata.resolver_output_root_fqns
                    and (root_fqn := self._metadata.resolver_output_fqn_to_root_fqn.get(k)) is not None
                ):
                    if root_fqn not in result_row:
                        # If the root fqn is already there, then prefer that
                        result_row[root_fqn] = result_row[k]
                    del result_row[k]
                else:
                    root_fqn = k
                if root_fqn in output_fqns_to_features:
                    root_feature = output_fqns_to_features[root_fqn]
                    if (
                        isinstance(root_feature, InputFeatureType)
                        and root_feature.underlying in root_feature.join_path_keys
                    ):
                        # CHA-4857
                        for local_join_feat, foreign_join_feat in zip(
                            root_feature.path[-1].parent.get_local_join_features(),
                            root_feature.path[-1].parent.get_foreign_join_features(),
                        ):
                            if foreign_join_feat == root_feature.underlying:
                                result_row[local_join_feat.root_fqn] = result_row[root_fqn]
            if FrozenOrderedSet(result_row.keys()) != self._metadata.resolver_output_root_fqns:
                resolver_fqn = next(iter(self._feature_fqn_to_resolver_fqn.values()), self._resolver_fqn)
                self.add_error(
                    index,
                    pkey,
                    execution_timestamp,
                    ResolverErrors.wrong_df_columns(
                        resolver_fqn=resolver_fqn,
                        expected=self._metadata.resolver_output_root_fqns,
                        actual=result_row,
                    ),
                )
                return
        sample_errored = False
        for fqn in self._metadata.has_many_feature_outputs:
            if isinstance(chalk_df := result_row.get(fqn), DataFrame):
                has_many_feature = self._metadata.has_many_feature_outputs[fqn]
                if not isinstance(has_many_feature, HasManyFeatureType):
                    continue  # TODO: support test_mlion_nested_join test please
                df = chalk_df.to_polars()
                expected_columns = has_many_feature.df.columns
                expected_schema = {
                    col.root_fqn: col.underlying.polars_dtype
                    for col in expected_columns
                    if not isinstance(col.underlying, WindowedFeatureType)
                }
                if df.schema != expected_schema:
                    self.add_error(
                        index,
                        pkey,
                        execution_timestamp,
                        ResolverErrors.wrong_df_columns(
                            resolver_fqn=self._get_effective_resolver_fqn(fqn),
                            expected=expected_schema.keys(),
                            actual=df.columns,
                            path=fqn,
                        ),
                    )
                    sample_errored = True
                elif self._check_duplicate_rows:
                    duplicate_return = _df_has_duplicate_rows(df, expected_columns)
                    if duplicate_return is not None:
                        self.add_error(
                            index,
                            pkey,
                            execution_timestamp,
                            ResolverErrors.df_has_duplicate_pkey_ts_rows(
                                resolver_fqn=self._get_effective_resolver_fqn(fqn),
                                pkeys=duplicate_return.pkeys,
                                timestamps=duplicate_return.timestamps,
                                path=fqn,
                                pkey_fqn=duplicate_return.pkey_fqn,
                                ts_fqn=duplicate_return.ts_fqn,
                            ),
                        )
                        sample_errored = True
        if sample_errored:
            return

        if self._metadata.is_one_to_one_resolver:
            # Creating a new col for each feature to encode if it was missing.
            # This will be used to set metadata cols in one_to_one_scalar_resolver.
            for feature, vals in list(result_row.items()):
                result_row[get_feature_is_missing_col_name(feature)] = vals is ...

            # Entire row can be invalid if the pkey is invalid as in Lateral Join
            # else, it will be handled using feature_is_missing_col.
            result_row[IS_VALID_COL_NAME] = (
                result_row[self._metadata.pkey_feature.root_fqn] is not ...
                if self._metadata.pkey_feature.root_fqn in result_row.keys()
                else True
            )
        else:
            if self._metadata.pkey_feature.fqn not in result_row:
                result_row[self._metadata.pkey_feature.root_fqn] = pkey
            # Set the execution timestamp under the TS_COL_NAME
            execution_timestamp = execution_timestamp or self._observed_at_fallback
            assert execution_timestamp is not None
            assert execution_timestamp.utcoffset() == timedelta(0), (
                f"execution_timestamp should always be utc; got {execution_timestamp}"
            )
            result_row[TS_COL_NAME] = execution_timestamp
            result_row[INDEX_COL_NAME] = index
        for col in self._metadata.cols_without_defaults:
            if (
                col.underlying.primitive_converter.is_value_missing(result_row[col.root_fqn])
                and (self._error_on_ellipsis or result_row[col.root_fqn] is not ...)
                and col.fqn not in nullable_has_one_features
            ):
                self.add_error(
                    index,
                    pkey,
                    execution_timestamp,
                    ResolverErrors.wrong_output_type(
                        expected_type_name=rt.__name__
                        if isinstance(rt := col.underlying.primitive_converter.primitive_type, type)  # pyright: ignore[reportUnnecessaryIsInstance]
                        else str(rt),
                        result_type_name="NoneType",
                        resolver_fqn=self._get_effective_resolver_fqn(col),
                        feature_fqn=col.root_fqn,
                    ),
                )
                return

        if self._metadata.is_one_to_one_resolver and index is None:
            raise ValueError("Unable to run a one-to-one resolver without a row index")

        if index is not None:
            if index in self._indices_already_processed:
                raise ValueError(f"Attempting to add a 2nd row for one-to-one resolver for index {index}")
            self._indices_already_processed.add(index)

        assert (actual_keys := FrozenOrderedSet(result_row.keys())) == (
            expected_keys := FrozenOrderedSet(self._python_object_results.keys())
        ), f"Keys mismatch. Expected {expected_keys} but got {actual_keys}"
        for k, (v, _) in self._python_object_results.items():
            v.append(result_row.get(k))
        self._num_rows += 1
        self._estimated_size_bytes += self._metadata.estimated_row_size_bytes

    def _append_df(
        self,
        index: int | None,
        pkey: str | int | None,
        execution_timestamp: datetime | None,
        result: pl.DataFrame,
    ) -> None:
        assert not self._metadata.is_one_to_one_resolver, (
            "Should not have a dataframe if expecting one output row per input row"
        )
        if FrozenOrderedSet(result.columns) != self._metadata.resolver_output_root_fqns:
            # Hack to fix a bug where we allowed returning the sub-class directly without it being wrapped in the parent class
            for k in result.columns:
                if (
                    k not in self._metadata.resolver_output_root_fqns
                    and (root_fqn := self._metadata.resolver_output_fqn_to_root_fqn.get(k)) is not None
                ):
                    if root_fqn in result.columns:
                        result = result.drop(k)
                    else:
                        result = result.rename({k: root_fqn})

            # If the dataframe is a 0x0, its schema should be considered valid.
            is_0_by_0 = len(result) == 0 and len(result.columns) == 0
            if is_0_by_0:
                # Differs from output_schema because
                # we inject certain things into the "implicit output schema" of the resolver.
                # here we just want to pretend the resovler returned a 0xk of its *declared* schema.
                declared_output_schema = [
                    k for k in self._metadata.output_schema if k.root_fqn in self._metadata.resolver_output_root_fqns
                ]

                result = pl.DataFrame(
                    data={k.root_fqn: [] for k in declared_output_schema},
                    schema={k.root_fqn: k.underlying.polars_dtype for k in declared_output_schema},
                )

            if FrozenOrderedSet(result.columns) != self._metadata.resolver_output_root_fqns:
                self.add_error(
                    index,
                    pkey,
                    execution_timestamp,
                    ResolverErrors.wrong_df_columns(
                        resolver_fqn=self._resolver_fqn,
                        expected=self._metadata.resolver_output_root_fqns,
                        actual=FrozenOrderedSet(result.columns),
                    ),
                )
                return
        if self._metadata.pkey_feature.fqn not in result.columns:
            result = result.with_columns(
                pl.lit(pkey, self._metadata.pkey_feature.polars_dtype).alias(self._metadata.pkey_feature.fqn)
            )
        # Set the execution timestamp under the TS_COL_NAME
        execution_timestamp = execution_timestamp or self._observed_at_fallback
        assert execution_timestamp is not None
        assert execution_timestamp.utcoffset() == timedelta(0), (
            f"execution_timestamp should always be utc; got {execution_timestamp}"
        )
        result = result.with_columns(
            pl.lit(
                execution_timestamp,
                dtype=pl.Datetime,
            )
            .dt.convert_time_zone("UTC")
            .alias(TS_COL_NAME),
            pl.lit(index, pl.Int64()).alias(INDEX_COL_NAME),
        )

        for col in self._metadata.cols_without_defaults:
            if result.get_column(col.root_fqn).null_count() > 0:
                self.add_error(
                    index,
                    pkey,
                    execution_timestamp,
                    ResolverErrors.wrong_output_type(
                        expected_type_name=rt.__name__
                        if isinstance(rt := col.underlying.primitive_converter.primitive_type, type)  # pyright: ignore[reportUnnecessaryIsInstance]
                        else str(rt),
                        result_type_name="NoneType",
                        resolver_fqn=self._get_effective_resolver_fqn(col),
                        feature_fqn=col.root_fqn,
                    ),
                )
                return
        result_len = len(result)
        if result_len > 0:
            self._estimated_size_bytes += result.estimated_size()
            self._pl_dfs.append(result)
            self._num_rows += result_len

    def _append_table(
        self,
        index: int | None,
        pkey: str | int | None,
        execution_timestamp: datetime | None,
        result: pa.Table,
    ):
        if len(result) == 0 and len(result.column_names) == 0:  # 0x0 table are considered valid
            declared_pa_schema = pa.schema(
                [f for f in self._metadata.pa_schema if f.name in self._metadata.resolver_output_root_fqns]
            )
            result = pa.Table.from_pylist([], schema=declared_pa_schema)

        assert not self._metadata.is_one_to_one_resolver, (
            "Should not have a table if expecting one output row per input row"
        )
        if FrozenOrderedSet(result.column_names) != self._metadata.resolver_output_root_fqns:
            # Hack to fix a bug where we allowed returning the sub-class directly without it being wrapped in the parent class
            cols_to_drop: list[str] = []
            cols_to_rename: dict[str, str] = {}
            for k in result.column_names:
                if (
                    k not in self._metadata.resolver_output_root_fqns
                    and (root_fqn := self._metadata.resolver_output_fqn_to_root_fqn.get(k)) is not None
                ):
                    if root_fqn in result.column_names:
                        cols_to_drop.append(k)
                    else:
                        cols_to_rename[k] = root_fqn
            if len(cols_to_drop) > 0:
                result = result.drop(cols_to_drop)
            if len(cols_to_rename) > 0:
                result = result.rename_columns([cols_to_rename.get(x, x) for x in result.column_names])
            if FrozenOrderedSet(result.column_names) != self._metadata.resolver_output_root_fqns:
                self.add_error(
                    index,
                    pkey,
                    execution_timestamp,
                    ResolverErrors.wrong_df_columns(
                        resolver_fqn=self._resolver_fqn,
                        expected=self._metadata.resolver_output_root_fqns,
                        actual=FrozenOrderedSet(result.column_names),
                    ),
                )
                return

        for col in self._metadata.cols_without_defaults:
            if result.column(col.root_fqn).null_count > 0:
                self.add_error(
                    index,
                    pkey,
                    execution_timestamp,
                    ResolverErrors.wrong_output_type(
                        expected_type_name=rt.__name__
                        if isinstance(rt := col.underlying.primitive_converter.primitive_type, type)  # pyright: ignore[reportUnnecessaryIsInstance]
                        else str(rt),
                        result_type_name="NoneType",
                        resolver_fqn=self._get_effective_resolver_fqn(col),
                        feature_fqn=col.display_name,
                    ),
                )
                return

        if self._metadata.pkey_feature.root_fqn not in result.column_names:
            result = result.append_column(
                self._metadata.pkey_feature.root_fqn,
                pa.nulls(  # ty: ignore[no-matching-overload]
                    len(result), self._metadata.pkey_feature.pyarrow_dtype
                ).fill_null(pkey),
            )

        # Set the execution timestamp under the TS_COL_NAME
        execution_timestamp = execution_timestamp or self._observed_at_fallback
        assert execution_timestamp is not None
        assert execution_timestamp.utcoffset() == timedelta(0), (
            f"execution_timestamp should always be utc; got {execution_timestamp}"
        )
        result = result.append_column(
            TS_COL_NAME,
            pa.nulls(len(result), pa.timestamp("us", "UTC")).fill_null(cast(Any, execution_timestamp)),
        )
        result = result.append_column(
            INDEX_COL_NAME,
            pa.nulls(len(result), pa.int64()).fill_null(index),  # ty: ignore[invalid-argument-type]
        )
        try:
            result = pa_cast(result, self._metadata.pa_schema)
        except Exception as e:
            # Logging as a warning as it is a user error, not a chalk error
            # But we still want the full stack trace
            _logger.warning(
                "Failed to cast pyarrow table with schema %s to schema %s. Are the dtypes compatible?",
                result.schema,
                self._metadata.pa_schema,
                exc_info=e,
            )
            self.add_error(
                index,
                pkey,
                execution_timestamp,
                ResolverErrors.failed_to_convert_to_dataframe(
                    resolver_fqn=self._resolver_fqn,
                    exception=ChalkException.create(
                        kind=type(e).__name__,
                        message=str(e),
                        # Suppressing the stack because it is internal
                        stacktrace="",
                    ),
                ),
            )
            return
        result_table = ChalkRecordBatch.from_table(result)
        assert result_table.schema_dict == self._metadata.table_schema, (
            f"Schema mismatch: {result_table.schema_dict} != {self._metadata.table_schema}"
        )
        assert result_table.column_names == tuple(self._metadata.table_schema.keys()), (
            f"Column order mismatch: {result_table.column_names} != {tuple(self._metadata.table_schema.keys())}"
        )
        result_table_len = len(result_table)
        if result_table_len > 0:
            self._pa_tables.append(result_table)
            self._estimated_size_bytes += result_table.get_total_buffer_size()
            self._num_rows += result_table_len

    def collect_results(self) -> ChalkRecordBatch | ChalkError:
        final_tables: list[ChalkRecordBatch] = []
        for x in self._pa_tables:
            if len(x) > 0:
                final_tables.append(x)
        # Doesn't matter which key we look it since all keys should have the same length
        num_py_obj_rows = len(next(iter(self._python_object_results.values()))[0])
        if num_py_obj_rows > 0:
            resolver_output_cols = {
                k: v for (k, v) in self._python_object_results.items() if k in self._metadata.resolver_output_root_fqns
            }
            assert len(resolver_output_cols) > 0, "Must be at least one output"
            resolver_input_cols = {
                k: v
                for (k, v) in self._python_object_results.items()
                if k not in self._metadata.resolver_output_root_fqns
            }
            output_data: dict[str, pa.Array | pa.ChunkedArray] = {}
            with safe_trace("output_conversion"):
                for col, (values, converter) in resolver_output_cols.items():
                    assert converter is not None
                    if self._metadata.is_one_to_one_resolver:
                        try:
                            if (
                                self._chalk_result_collector_fastpath
                                and len(values) > 0
                                and isinstance(values[0], list)
                                and len(values[0]) == 1
                                and isinstance(values[0][0], Features)
                            ):
                                # This is a weird hack -- this is a much faster way of going from @features
                                # classes to arrow list[struct] type for resolvers that do things like return
                                # Features[Account.transactions]
                                struct = (
                                    DataFrame(values[0]).to_polars().collect().to_struct("foo").to_frame()
                                )  # ty:ignore[unresolved-attribute]

                                if hasattr(struct, "groupby"):
                                    grouped = struct.groupby(pl.lit(1))  # ty:ignore[call-non-callable]
                                else:
                                    grouped = cast(Any, struct).group_by(pl.lit(1))

                                pa_arr = grouped.all()["foo"].to_arrow()
                            else:
                                # We only want to convert the valid values, not the invalid ones, because the sentinel (which is None) for invalid values
                                # might fail the conversion
                                pa_arr = None
                                if not recursively_has_struct(converter.pyarrow_dtype) and (
                                    not converter.has_default or converter.primitive_default is None
                                ):
                                    # Fast path, assuming that the rich type is coeracable into the pyarrow array
                                    # This doesn't work for structs because of null handling
                                    try:
                                        # Hack: Try to treat the rich values as primitive when converting. This would be faster
                                        pa_arr = converter.from_primitive_to_pyarrow(
                                            val if val is not ... else None for val in values
                                        )
                                    except Exception:
                                        pass
                                if pa_arr is None:
                                    # Fallback: rich values need explicit conversion (e.g. structs,
                                    # or the coercion above failed). from_rich_to_pyarrow handles
                                    # missing values, defaults, and null semantics correctly.
                                    pa_arr = converter.from_rich_to_pyarrow(
                                        values, missing_value_strategy="default_or_allow", feature_name=col
                                    )
                        except Exception as e:
                            # Discarding the stacktrace as it would be an internal stack
                            return ResolverErrors.failed_to_convert_to_dataframe(
                                resolver_fqn=self._get_effective_resolver_fqn(col),
                                exception=ChalkException.create(kind=type(e).__name__, message=str(e), stacktrace=""),
                            )
                    else:
                        # All values are valid
                        try:
                            # We only want to convert the valid values, not the invalid ones, because the sentinel (which is None) for invalid values
                            # might fail the conversion
                            pa_arr = converter.from_rich_to_pyarrow(
                                values, missing_value_strategy="default_or_error", feature_name=col
                            )
                        except Exception as e:
                            # Discarding the stacktrace as it would be an internal stack
                            return ResolverErrors.failed_to_convert_to_dataframe(
                                resolver_fqn=self._get_effective_resolver_fqn(col),
                                exception=ChalkException.create(kind=type(e).__name__, message=str(e), stacktrace=""),
                            )
                    assert len(pa_arr) == num_py_obj_rows, (
                        f"Row count mismatch after conversion: Expected {num_py_obj_rows}; gto {len(pa_arr)}"
                    )
                    output_data[col] = pa_arr
            with safe_trace("input_conversion"):
                if len(resolver_input_cols) > 0:
                    for col, (values, converter) in resolver_input_cols.items():
                        if col == TS_COL_NAME:
                            arr = pa.array(values, pa.timestamp("us", "UTC"))
                        elif col == INDEX_COL_NAME:
                            arr = pa.array(values, pa.int64())
                        elif col == IS_VALID_COL_NAME:
                            arr = pa.array(values, pa.bool_())
                        elif is_feature_is_missing_col(col):
                            arr = pa.array(values, pa.bool_())
                        else:
                            assert converter is not None
                            arr = converter.from_primitive_to_pyarrow(values)
                        assert len(arr) == num_py_obj_rows, (
                            f"Row count mismatch: Got {len(arr)}; originally had {num_py_obj_rows}"
                        )
                        output_data[col] = arr
            assert FrozenOrderedSet(output_data.keys()) == FrozenOrderedSet(self._metadata.table_schema.keys()), (
                f"Table key mismatch: {output_data.keys()} != {self._metadata.table_schema.keys()}"
            )
            # Put the columns in the correct order
            output_data = {k: output_data[k] for k in self._metadata.table_schema}
            pa_tbl = ChalkRecordBatch.from_pydict(output_data)
            assert len(pa_tbl) == num_py_obj_rows
            assert pa_tbl.schema_dict == self._metadata.table_schema, (
                f"Schema mismatch: {pa_tbl.schema_dict} != {self._metadata.table_schema}"
            )
            assert pa_tbl.column_names == tuple(self._metadata.table_schema.keys()), (
                f"Column order mismatch: {pa_tbl.column_names} != {tuple(self._metadata.table_schema.keys())}"
            )
            final_tables.append(pa_tbl)
        if len(self._pl_dfs) > 0:
            if len(self._pl_dfs) == 1:
                pl_df = self._pl_dfs[0]
            else:
                pl_df = pl.concat(self._pl_dfs, how="diagonal")
            pa_table = pl_df.to_arrow()
            try:
                pa_table = pa_cast(pa_table, self._metadata.pa_schema)
            except Exception as e:
                # Discarding the stacktrace as it would be an internal stack
                return ResolverErrors.failed_to_convert_to_dataframe(
                    resolver_fqn=self._resolver_fqn,
                    exception=ChalkException.create(kind=type(e).__name__, message=str(e), stacktrace=""),
                )
            tbl = ChalkRecordBatch.from_table(pa_table)
            assert tbl.schema_dict == self._metadata.table_schema, (
                f"Schema mismatch: {tbl.schema_dict} != {self._metadata.table_schema}"
            )
            assert tbl.column_names == tuple(self._metadata.table_schema.keys()), (
                f"Column order mismatch: {tbl.column_names} != {tuple(self._metadata.table_schema.keys())}"
            )
            if len(tbl) > 0:
                final_tables.append(tbl)

        if len(final_tables) == 0:
            data = {x: [] for x in self._metadata.table_schema}
            return ChalkRecordBatch.from_pydict(data, self._metadata.table_schema)

        if len(final_tables) == 1:
            final_table = final_tables[0]
        else:
            # No need to promote or cast the results, as each table should have the expected schema
            assert all(pa.schema(x.schema_dict) == self._metadata.pa_schema for x in final_tables), (
                f"Not all final tables have the correct schema. Expected {self._metadata.pa_schema}"
            )
            final_table = ChalkRecordBatch.from_table(pa.concat_tables([x.to_table() for x in final_tables]))

        if len(self._strict_validations) > 0:
            validation_err = validate_results(
                self._strict_validations,
                final_table,
                is_valid_mask=final_table.column(IS_VALID_COL_NAME) if self._metadata.is_one_to_one_resolver else None,
            )
            if validation_err is not None:
                return validation_err

        final_table = self._replace_nulls_with_defaults(
            final_table,
            is_valid=final_table.column(IS_VALID_COL_NAME) if self._metadata.is_one_to_one_resolver else None,
        )
        assert final_table.schema_dict == self._metadata.table_schema, (
            f"Schema mismatch: {final_table.schema_dict} != {self._metadata.table_schema}"
        )
        assert final_table.column_names == tuple(self._metadata.table_schema.keys()), (
            f"Column order mismatch: {final_table.column_names} != {tuple(self._metadata.table_schema.keys())}"
        )

        # TODO: Duplicate any join columns on both sides of the join
        # And validate that if the results contain both sides of the join column, then they are exactly equal
        assert len(final_table) == self._num_rows, (
            f"Final table length {len(final_table)} differs from the tracked row count {self._num_rows}"
        )
        return final_table

    # @_tracer.wrap("result_collector_add_error")
    def add_error(
        self,
        index: int | None,
        pkey: str | int | None,
        execution_timestamp: datetime | None,
        error: ChalkError,
    ):
        if pkey is not None:
            error = error.copy(update={"display_primary_key": str(pkey)})  # ty:ignore[deprecated]
        # Do we want to keep track of all the samples that errored? or just the observed at and pkey?
        self._errors.append(_InvocationError(index=index, error=error))
        if self._metadata.is_one_to_one_resolver and index is not None:
            if index not in self._indices_already_processed:
                self._indices_already_processed.add(index)
                self._num_rows += 1
                self._estimated_size_bytes += self._metadata.estimated_row_size_bytes
                for k, (v, _) in self._python_object_results.items():
                    if k == self._metadata.pkey_feature.root_fqn:
                        v.append(pkey)
                        continue
                    if k == TS_COL_NAME:
                        execution_timestamp = execution_timestamp or self._observed_at_fallback
                        assert execution_timestamp is not None
                        if execution_timestamp.tzinfo is None:
                            # Assume unzoned timestamps are utc. Ignore any system local timezone
                            execution_timestamp = execution_timestamp.replace(tzinfo=timezone.utc)
                        # Convert obscure timestamps to utc
                        execution_timestamp = execution_timestamp.astimezone(timezone.utc)
                        v.append(execution_timestamp)
                        continue
                    if k == INDEX_COL_NAME:
                        v.append(index)
                        continue
                    if k == IS_VALID_COL_NAME:
                        v.append(True)
                        continue
                    if is_feature_is_missing_col(k):
                        v.append(True)
                        continue
                    # Otherwise, appending None to keep the row counts the same for each column
                    v.append(None)

    @property
    def errors(self):
        return self._errors

    def _replace_nulls_with_defaults(
        self,
        final_table: ChalkRecordBatch,
        is_valid: pa.Array | None,
    ):
        for feature_type, default in self._metadata.cols_with_defaults.items():
            col = final_table.column(feature_type.root_fqn)
            if is_valid is None:
                # All are valid
                col = col.fill_null(default)
            else:
                assert not pc.any(
                    pc.and_(col.is_valid(), pc.invert(is_valid))
                ).as_py(), (  # ty:ignore[unresolved-attribute]
                    "If a row is marked as invalid, then all values must be null"
                )
                col = pc.if_else(  # ty:ignore[unresolved-attribute]
                    pc.or_(  # ty:ignore[unresolved-attribute]
                        col.is_valid(),
                        is_valid,
                    ),
                    col,
                    default,
                )
            idx = final_table.column_names.index(feature_type.root_fqn)
            final_table = final_table.set_column(idx, feature_type.root_fqn, col)

        return final_table

    def override_output_fqns(self, root_fqns: FrozenOrderedSet[str] | None) -> bool:
        # returns True if the output root_fqns were overridden
        # mutates self, this should be fine since it can only happen once at the beginning of first add_result()
        if root_fqns is None:
            # This is totally unprincipled and an absolute guess.
            return False
        if self._query_rewriter_output_root_fqns == root_fqns:
            return False
        if self._query_rewriter_output_root_fqns != "not set":
            raise ValueError(
                f"Cannot override output root fqn from {self._query_rewriter_output_root_fqns} to {root_fqns}"
            )
        self._query_rewriter_output_root_fqns = root_fqns
        return True


@dataclasses.dataclass
class _DuplicateReturn:
    pkeys: list[Any]
    timestamps: list[Any] | None
    pkey_fqn: str
    ts_fqn: str | None


# TODO: Also check this for normal dataframe resolvers
def _df_has_duplicate_rows(
    lazy_df: pl.LazyFrame, column_features: FrozenOrderedSet[FeatureType]
) -> _DuplicateReturn | None:
    pkey_fqn = None
    ts_fqn = None
    for feature in column_features:
        if isinstance(feature, ScalarFeatureType) and feature.primary:
            pkey_fqn = feature.fqn
        elif isinstance(feature, FeatureTimeFeatureType):
            ts_fqn = feature.fqn
    if pkey_fqn is None:
        """This is a more serious issue, will be caught elsewhere"""
        return
    df = lazy_df.collect()
    if ts_fqn is None:
        pkey_col = df.select(pl.col(pkey_fqn))  # ty:ignore[unresolved-attribute]
        mask = pkey_col.is_duplicated()
        pkey_values = pkey_col.filter(mask).unique().to_series().head(10).to_list()
        if len(pkey_values) > 0:
            return _DuplicateReturn(
                pkeys=pkey_values,
                timestamps=None,
                pkey_fqn=pkey_fqn,
                ts_fqn=ts_fqn,
            )
        else:
            return
    struct = pl.struct(pkey_fqn, ts_fqn)
    mask = df.select(struct).is_duplicated()  # ty:ignore[unresolved-attribute]
    values = df.filter(mask).unique().head(10).to_dict(as_series=False)  # ty:ignore[unresolved-attribute]
    pkey_values = values[pkey_fqn]
    if len(pkey_values) > 0:
        return _DuplicateReturn(
            pkeys=values[pkey_fqn],
            timestamps=values[ts_fqn],
            pkey_fqn=pkey_fqn,
            ts_fqn=ts_fqn,
        )
