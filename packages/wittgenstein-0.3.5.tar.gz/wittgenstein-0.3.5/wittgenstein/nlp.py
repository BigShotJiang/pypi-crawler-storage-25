import re
from collections import Counter

def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^a-z ]+', '', text)
    return text

def tokenize(text, stopwords=None):
    toks = [word for word in text.split() if word]
    if stopwords:
        toks = [tok for tok in toks if tok not in stopwords]
    return toks

def get_glove_embeddings(embeddings_path):
    with open(embeddings_path) as f:
        embeddings_txt = f.readlines()
    embeddings = {}
    for line in embeddings_txt:
        line = line.replace('\n','').split()
        embeddings[line[0]] = [float(val) for val in line[1:]]
    return embeddings

def build_corpus(texts, embeddings, stopwords):
    corpus = []
    for text in texts:
        text = tokenize(clean_text(text), stopwords=stopwords)
        text = [tok for tok in text if tok in embeddings]
        corpus.append(text)

    word_counts = Counter()
    for doc in corpus:
        word_counts += Counter(doc)

    print(word_counts.most_common(10))
    tok2id = {tok:idx for idx, tok in enumerate(word_counts)}
    id2tok = {idx:tok for idx, tok in enumerate(word_counts)}

    return corpus, word_counts, tok2id, id2tok
