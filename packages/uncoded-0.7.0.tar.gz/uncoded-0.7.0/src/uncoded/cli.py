"""CLI entry point for uncoded."""

import argparse
import sys
from pathlib import Path

from uncoded.config import (
    find_pyproject_toml,
    read_instruction_files,
    read_source_roots,
)
from uncoded.extract import extract_modules, iter_source_files
from uncoded.instruction_files import sync_instruction_file
from uncoded.namespace_map import build_map, render_map
from uncoded.serena_setup import setup
from uncoded.skill import sync_skill
from uncoded.stubs import build_stubs
from uncoded.sync import sync_file


def _sync(*, start: Path | None = None, check: bool = False) -> int:
    """Sync (or verify) the namespace map, stub files, and instruction-file sections.

    The upward walk for ``pyproject.toml`` begins at ``start`` (defaulting
    to the current working directory at the CLI boundary). The parent of
    the located ``pyproject.toml`` becomes ``project_root``: the single
    anchor every writer uses for project-relative paths it reads or
    writes. Running from a subdirectory of the project produces artefacts
    in the same locations as running from the project root.

    When ``check=True``, the on-disk tree is not mutated; the function
    reports each prospective write, returns 1 if anything would change
    (so CI can gate on a stale index), and 0 otherwise. Configuration
    errors return 1 in either mode.
    """
    if start is None:
        start = Path.cwd()

    pyproject_path = find_pyproject_toml(start)
    if pyproject_path is None:
        print(
            "Error: No pyproject.toml found. "
            "Create one with a [tool.uncoded] source-roots entry.",
            file=sys.stderr,
        )
        return 1
    project_root = pyproject_path.parent

    try:
        configured_roots = read_source_roots(pyproject_path)
    except LookupError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    source_roots: list[Path] = []
    for configured in configured_roots:
        src_root = (project_root / configured).resolve()
        if not src_root.is_dir():
            print(
                f"Error: source root {configured} is not a directory. "
                "Check [tool.uncoded] source-roots in pyproject.toml.",
                file=sys.stderr,
            )
            return 1
        source_roots.append(src_root)

    changes = 0

    roots_with_files = [
        (src_root, list(iter_source_files(src_root, project_root=project_root)))
        for src_root in source_roots
    ]

    modules = [
        m for _src_root, files in roots_with_files for m in extract_modules(files)
    ]
    map_content = render_map(build_map(modules))
    if sync_file(
        Path(".uncoded/namespace.yaml"),
        map_content,
        project_root=project_root,
        check=check,
    ):
        changes += 1

    for src_root, files in roots_with_files:
        changes += build_stubs(
            files=files,
            source_root=src_root,
            output_dir=Path(".uncoded/stubs"),
            project_root=project_root,
            check=check,
        )

    # Dedupe configured instruction paths by resolved (canonical) path.
    # Without this, if CLAUDE.md is a symlink to AGENTS.md, pass 1 writes
    # through the symlink and reports the alias name while pass 2 finds
    # the file already in sync and reports nothing — asymmetric output
    # that hides the actual write target. Resolving collapses both aliases
    # to the same canonical path, which we render relative to
    # ``project_root`` for the user-facing line, falling back to the
    # absolute resolved path when the file lives outside ``project_root``.
    seen_resolved: set[Path] = set()
    for path in read_instruction_files(project_root):
        resolved = (project_root / path).resolve()
        if resolved in seen_resolved:
            continue
        seen_resolved.add(resolved)
        try:
            canonical = resolved.relative_to(project_root)
        except ValueError:
            canonical = resolved
        if sync_instruction_file(canonical, project_root=project_root, check=check):
            changes += 1

    if sync_skill(project_root=project_root, check=check):
        changes += 1

    if check:
        if changes:
            print(f"Index out of date: {changes} file(s) would change.")
            return 1
        print("Index is up to date.")
        return 0
    return 0


def main() -> int:
    """Dispatch the uncoded CLI.

    Three subcommands: ``sync`` builds or refreshes the navigation index;
    ``check`` verifies the index matches what a rebuild would produce
    (exits non-zero on drift, useful in CI); ``setup`` generates
    MCP and Claude Code config for the recommended Serena + ty LSP
    integration.

    Each subparser binds its own ``action`` callable via
    ``set_defaults``; ``main`` then dispatches via ``args.action()``.
    Adding a new subcommand is a local change at the registration site —
    no central dispatch ladder to update, and no silent fall-through if
    the binding is forgotten (``args.action`` will simply be missing).
    """
    parser = argparse.ArgumentParser(
        prog="uncoded",
        description="Build a navigation index for AI coding agents.",
    )
    subparsers = parser.add_subparsers(required=True)

    sync_parser = subparsers.add_parser(
        "sync",
        help=(
            "Build or refresh the namespace map, stub files, and "
            "instruction-file sections."
        ),
    )
    sync_parser.set_defaults(action=lambda: _sync(check=False))

    check_parser = subparsers.add_parser(
        "check",
        help=(
            "Verify the index is up to date without writing. Exits non-zero "
            "if any file would change. Useful in CI."
        ),
    )
    check_parser.set_defaults(action=lambda: _sync(check=True))

    setup_parser = subparsers.add_parser(
        "setup",
        help=(
            "Write .mcp.json, .serena/project.yml, and .claude/settings.json "
            "for the recommended Serena + ty LSP integration."
        ),
    )
    setup_parser.set_defaults(action=lambda: setup())

    args = parser.parse_args()
    return args.action()
