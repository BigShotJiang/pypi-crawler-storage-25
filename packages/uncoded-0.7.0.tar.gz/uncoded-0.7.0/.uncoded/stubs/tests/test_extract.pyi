# tests/test_extract.py

import textwrap
from uncoded.extract import extract_module, extract_modules, iter_source_files

class TestExtractModule:
    def test_classes_and_functions(self):
        ...

    def test_async_functions_and_methods(self):
        ...

    def test_empty_module(self):
        ...

    def test_module_level_constants(self):
        ...

    def test_type_alias_classic(self):
        ...

    def test_type_alias_pep695(self):
        ...

    def test_tuple_unpacking_skipped(self):
        ...

    def test_unannotated_class_variable(self):
        ...

    def test_annotated_attributes(self):
        ...

    def test_property_classified_as_attribute(self):
        ...

    def test_property_setter_and_deleter_suppressed(self):
        ...

    def test_preserves_source_order(self):
        ...

class TestIterAndExtract:
    def test_basic_walk(self, tmp_path):
        ...

    def test_nested_subpackage(self, tmp_path):
        ...

    def test_includes_init_with_symbols(self, tmp_path):
        ...

    def test_skips_empty_init(self, tmp_path):
        ...

    def test_skips_syntax_errors(self, tmp_path, capsys):
        ...

class TestExtractModules:
    def test_returns_module_info_per_parseable_file(self):
        ...

    def test_preserves_source_order(self):
        ...

    def test_module_with_only_constants_is_kept(self):
        ...

    def test_skips_files_with_no_symbols(self):
        ...
