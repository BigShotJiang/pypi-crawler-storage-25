# src/uncoded/stubs.py

import ast
from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from uncoded.extract import property_kind
from uncoded.sync import remove_file, sync_file

VALUE_WIDTH_CAP = 80

def _extract_params(args: ast.arguments) -> list[StubParam]:
    ...

def _render_value(value: ast.expr) -> str:
    ...

def _extract_assignment(node: ast.Assign | ast.AnnAssign | ast.TypeAlias) -> StubAssignment | None:
    ...

def _extract_function(node: ast.FunctionDef | ast.AsyncFunctionDef) -> StubFunction:
    ...

def _property_attribute(node: ast.FunctionDef | ast.AsyncFunctionDef) -> StubAssignment:
    ...

def _extract_class(node: ast.ClassDef) -> StubClass:
    ...

def extract_stub(source: str, rel_path: str) -> StubModule:
    ...

def _render_param(p: StubParam) -> str:
    ...

def _render_function(func: StubFunction, indent: str) -> list[str]:
    ...

def _format_assignment_body(a: StubAssignment) -> str:
    ...

def _render_assignment(a: StubAssignment, indent: str) -> str:
    ...

def render_stub(module: StubModule) -> str:
    ...

def _generate_stubs(files: Iterable[tuple[str, str]]) -> dict[Path, str]:
    ...

def _write_stubs(*, stubs: dict[Path, str], source_root: Path, output_dir: Path, project_root: Path, check: bool) -> int:
    ...

def build_stubs(*, files: Iterable[tuple[str, str]], source_root: Path, output_dir: Path, project_root: Path, check: bool) -> int:
    ...

class StubParam:
    name: str
    annotation: str | None = None

class StubFunction:
    name: str
    params: list[StubParam] = field(default_factory=list)
    return_annotation: str | None = None
    is_async: bool = False

class StubAssignment:
    name: str
    annotation: str | None = None
    value_source: str | None = None
    is_type_alias: bool = False

class StubClass:
    name: str
    bases: list[str] = field(default_factory=list)
    attributes: list[StubAssignment] = field(default_factory=list)
    methods: list[StubFunction] = field(default_factory=list)

class StubModule:
    rel_path: str
    imports: list[str] = field(default_factory=list)
    constants: list[StubAssignment] = field(default_factory=list)
    classes: list[StubClass] = field(default_factory=list)
    functions: list[StubFunction] = field(default_factory=list)
