# Bob Skill Creator

A simplified Python CLI tool for creating Bob skills. This tool helps you scaffold new skills and guides you to work with your AI coding assistant (Bob, Claude, etc.) to complete them.

## Installation

```bash
pip install bob-skill-creator
```

Or install from source:

```bash
git clone https://github.com/yourusername/bob-skill-creator.git
cd bob-skill-creator
pip install -e .
```

## Quick Start

Create a new skill with a single command:

```bash
bob-skill my-skill --description "What your skill does"
```

This creates a folder with:
- **SKILL.md** - Complete skill-creator guide with instructions
- **README.md** - Getting started instructions

## Usage

### Basic Command

```bash
bob-skill <name> --description "<description>" [--output <path>]
```

**Arguments:**
- `name` - Name of your skill (e.g., `csv-analyzer`, `hello-world`)
- `--description, -d` - Brief description of what the skill does (required)
- `--output, -o` - Output directory (optional, defaults to `./skills/<name>`)

### Examples

**Create a simple skill:**
```bash
bob-skill hello-world --description "A simple greeting skill"
```

**Create a data processing skill:**
```bash
bob-skill csv-analyzer \
  --description "Analyze CSV files and generate statistical reports" \
  --output ./my-skills/csv-analyzer
```

## Working with Your AI Assistant

After creating a skill scaffold:

1. **Open the folder** in your AI coding assistant (Bob, Claude, etc.)
2. **Ask your AI:** "Help me create a skill called 'my-skill' that does: [description]"
3. **Your AI will:**
   - Read the SKILL.md file (complete skill-creator guide)
   - Ask you questions about requirements
   - Help you write the skill content
   - Create test cases
   - Guide you through iterations

The SKILL.md file contains comprehensive instructions that your AI assistant will follow to help you create high-quality skills.

## What Gets Created

When you run `bob-skill`, it creates:

```
skills/my-skill/
├── SKILL.md          # Complete skill-creator guide
└── README.md         # Getting started instructions
```

The **SKILL.md** file contains everything your AI needs to know about:
- Skill structure and anatomy
- Writing effective descriptions
- Creating test cases
- Iterating and improving
- Best practices and patterns

## Examples

See the `examples/` directory for usage examples:
- [`basic_usage.py`](examples/basic_usage.py) - Simple CLI usage
- [`advanced_usage.py`](examples/advanced_usage.py) - Working with AI assistant workflow

Run examples:
```bash
python examples/basic_usage.py
python examples/advanced_usage.py
```

## Philosophy

This tool follows a simple philosophy:

1. **Keep it simple** - One command to scaffold a skill
2. **Let AI do the work** - The SKILL.md guide teaches your AI assistant how to build skills
3. **Human + AI collaboration** - You provide the vision, AI handles the implementation details

Instead of complex automation, we provide the complete skill-creator guide that your AI assistant can read and follow, making the skill creation process more flexible and powerful.

## Requirements

- Python 3.8+
- An AI coding assistant (Bob, Claude, etc.) to help complete the skills

## License

Apache-2.0 License - see [LICENSE](LICENSE) file for details.

## Contributing

Contributions welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Support

- 📚 [Skill Creator Guide](SKILLS.md) - Complete guide for creating skills
- 🐛 [Issues](https://github.com/yourusername/bob-skill-creator/issues) - Report bugs or request features
- 💬 [Discussions](https://github.com/yourusername/bob-skill-creator/discussions) - Ask questions

---

Made with ❤️ by Nabarko and Aakriti