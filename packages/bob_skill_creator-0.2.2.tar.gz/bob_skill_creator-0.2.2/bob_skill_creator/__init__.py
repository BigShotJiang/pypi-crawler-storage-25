"""
Bob Skill Creator - A simplified CLI tool for creating Bob skills.
"""

__version__ = "0.2.2"


