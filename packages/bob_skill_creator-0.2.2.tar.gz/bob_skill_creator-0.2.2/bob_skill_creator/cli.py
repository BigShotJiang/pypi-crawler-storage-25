"""
Simplified command-line interface for Bob Skill Creator.
"""

import click
from pathlib import Path
import shutil


@click.command()
@click.argument("name")
@click.option("--description", "-d", required=True, help="Skill description")
@click.option("--output", "-o", type=click.Path(), help="Output directory (default: ./skills/<name>)")
@click.version_option(version="0.2.2")
def main(name: str, description: str, output: str) -> None:
    """
    Create a new Bob skill by copying the skill-creator SKILL.md template.
    
    This creates a folder with the full skill-creator guide (SKILL.md) that your
    AI assistant can use to help you build the skill.
    
    Example:
        bob-skills create my-skill --description "My skill description"
    """
    # Determine output path
    if output:
        output_path = Path(output)
    else:
        output_path = Path("./skills") / name
    
    # Create directory
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Find and copy the SKILL.md template
    # Look for SKILLS.md in multiple locations
    package_dir = Path(__file__).parent.parent
    skill_template = package_dir / "SKILLS.md"
    
    if not skill_template.exists():
        # Try parent directory (for development)
        skill_template = package_dir.parent / "SKILLS.md"
    
    if not skill_template.exists():
        # Try current directory
        skill_template = Path("SKILLS.md")
    
    if not skill_template.exists():
        # Create in ~/.bob/skill-creator/ and use from there
        bob_dir = Path.home() / ".bob" / "skill-creator"
        bob_dir.mkdir(parents=True, exist_ok=True)
        skill_template = bob_dir / "SKILLS.md"
        
        if not skill_template.exists():
            # Download or create a basic template
            click.echo("⚠ SKILLS.md not found. Creating basic template in ~/.bob/skill-creator/", err=True)
            basic_template = """---
name: skill-creator
description: Create new skills, modify and improve existing skills, and measure skill performance.
---

# Skill Creator

This is a basic skill template. For the complete skill-creator guide, visit:
https://github.com/aakriti1318/bob-skill-creator/blob/main/SKILLS.md

## Getting Started

Work with your AI coding assistant (Bob, Claude, etc.) to complete this skill.

1. Define what your skill should do
2. Write clear instructions
3. Add examples
4. Test and iterate

Your AI assistant will help guide you through the process.
"""
            skill_template.write_text(basic_template)
            click.echo(f"✓ Created basic template at {skill_template}")
    
    # Copy SKILL.md to output directory
    dest_file = output_path / "SKILL.md"
    shutil.copy2(skill_template, dest_file)
    
    # Create a README with the skill name and description
    readme_content = f"""# {name}

{description}

## Getting Started

This folder contains the complete skill-creator guide (SKILL.md).

To complete this skill:
1. Open this folder in your AI coding assistant (Bob, Claude, etc.)
2. Ask: "Help me create a skill called '{name}' that does: {description}"
3. Your AI assistant will read SKILL.md and guide you through the process

## What's in SKILL.md?

The SKILL.md file contains comprehensive instructions for creating Bob skills, including:
- How to structure skills
- Writing effective skill descriptions
- Creating test cases
- Iterating and improving skills
- Best practices and patterns

Your AI assistant will use these instructions to help you build a high-quality skill.
"""
    
    readme_file = output_path / "README.md"
    readme_file.write_text(readme_content)
    
    # Print success message with guidance
    click.echo(f"✓ Created skill folder at {output_path}/")
    click.echo()
    click.echo("📁 Contents:")
    click.echo(f"   - SKILL.md (complete skill-creator guide)")
    click.echo(f"   - README.md (getting started instructions)")
    click.echo()
    click.echo("🤖 Next steps:")
    click.echo("1. Open this folder in your AI coding assistant (Bob, Claude, etc.)")
    click.echo(f"2. Ask: 'Help me create a skill called \"{name}\" that does: {description}'")
    click.echo("3. Your AI will read SKILL.md and guide you through the process")
    click.echo()
    click.echo(f"📍 Location: {output_path.absolute()}")


if __name__ == "__main__":
    main()


