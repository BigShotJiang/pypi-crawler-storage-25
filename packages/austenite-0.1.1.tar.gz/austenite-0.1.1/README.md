# austenite

[![PyPI version](https://img.shields.io/pypi/v/austenite.svg)](https://pypi.org/project/austenite/)
[![CI](https://img.shields.io/badge/CI-coming%20soon-lightgrey.svg)](https://github.com/jvnshirr-collab/austenite/actions)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)

**Bayesian end-to-end materials engineering — chemistry to compliance, with citations.**

> 🚀 **New to this?** Start with [GETTING_STARTED.md](https://github.com/jvnshirr-collab/austenite/blob/main/packages/austenite-py/GETTING_STARTED.md) — a beginner-friendly tutorial with copy-paste examples and explained results.
> 📖 **Full capability reference:** [USAGE.md](https://github.com/jvnshirr-collab/austenite/blob/main/packages/austenite-py/USAGE.md) — every namespace (`au.*`) with runnable examples.

`austenite` is the Python client for the [Austenite API](https://api.austenite.org/v1).
One function call takes you from composition to a code-stamped fatigue allowable,
with Bayesian posterior bands and the literature citations the engine used.

```python
import austenite as au

result = au.design_path(
    alloy="AISI 4140",
    cooling_rate=10,
    spec="ASME-VIII-Div2",
    sigma_app_MPa=600,
    posterior=True,
)

print(result.properties.sigma_y_MPa)        # 1535
print(result.compliance.pass_)               # True
print(result.posterior["sigma_y_MPa"].p05)   # 1500
for c in result.citations:
    print(c.source, c.page)
```

---

## Install

```bash
pip install austenite
```

For the notebook examples:

```bash
pip install "austenite[notebook]"
```

For batch MTC parsing with PDF + OCR support (requires tesseract binary):

```bash
pip install "austenite[ocr,xlsx]"
# also install tesseract: brew install tesseract  / apt install tesseract-ocr
# language packs: tesseract-ocr-deu, tesseract-ocr-jpn, tesseract-ocr-kor, ...
```

For the JAX-differentiable backend (end-to-end gradients through the
composition -> hardness -> strength -> fracture -> fatigue chain, suitable for
`jax.grad` / `jax.jit` / `jax.vmap` and gradient-based inverse design):

```bash
pip install "austenite[jax]"
```

```python
import austenite as au
import jax
import jax.numpy as jnp

def objective(comp):
    # comp = [C, Mn, Cr, Mo, Ni, Si, V] in wt%
    r = au.design_path_jax(comp, cooling_rate=10.0, sigma_app_MPa=500.0)
    return r.fatigue.utilisation_pct

gradient = jax.grad(objective)(jnp.array([0.40, 0.85, 0.95, 0.20, 0.0]))
# gradient[i] = sensitivity of fatigue utilisation to element i (wt%)
```

See `examples/08_jax_inverse_design.py` for a full inverse-design loop.
The differentiable engines (Maynier-Dollet HV30, Pavlina-Tyne 2008,
Barsom-Rolfe 1972, Hall-Petch, Goodman) are calibrated against the
same references as the production HTTP backend. The conceptual basis
for end-to-end differentiable matsci is Liu & Strachan (2025),
[arXiv:2505.01585](https://arxiv.org/abs/2505.01585) -- austenite ships
the first production implementation.

For development:

```bash
pip install -e ".[dev]"
```

Python 3.10+.

---

## What's in the box

| Function                          | What it does                                                              |
|-----------------------------------|---------------------------------------------------------------------------|
| `au.design_path(...)`             | Full ICME chain: composition → CALPHAD → KWN → Orowan → Sy(t) → Goodman   |
| `au.am.qualification(...)`        | Predict porosity, regime, and properties for LPBF / DED / EBM             |
| `au.am.sweep(...)`                | Grid sweep over laser power × scan speed                                  |
| `au.mtc.parse(pdf)`               | Parse a Material Test Certificate (PDF, URL, or raw text)                 |
| `au.mtc.batch_parse(folder)`      | **Folder of 1000 PDFs in 7 languages → pandas DataFrame (replaces 2-4 QC FTEs)** |
| `au.mtc.audit_lot(df, spec=...)`  | Compare a lot of heats against the spec library → Excel report            |
| `au.mtc.compare(a, b)`            | Element-by-element diff between two MTCs (>0.05 wt% flag)                 |
| `au.mtc.detect_grade(comp)`       | Identify the most likely grade for a composition map                      |
| `au.ttt.compute(...)`             | Isothermal TTT curves + M_s / B_s                                         |
| `au.ttt.cct_sweep(...)`           | CCT curves across a list of cooling rates                                 |
| `au.calphad.equilibrium(...)`     | Phase fractions at (T, P, composition)                                    |
| `au.calphad.ternary(...)`         | Sampled ternary isothermal section                                        |
| `au.bayesian.calphad(...)`        | **Posterior** P(phase ≤ threshold) — the differentiator                  |
| `au.audit.record / replay(...)`   | Server-side audit log + replay                                            |

---

## Configure

```python
import austenite as au

au.set_api_url("https://api.austenite.org")   # default
au.set_timeout(30)                            # seconds
au.set_api_key("sk-...")                      # bearer token
au.set_max_retries(3)
```

Or set per-call:

```python
client = au.Client(api_url="http://localhost:8000", timeout=10)
```

---

## Async

```python
import asyncio
import austenite as au

async def main():
    async with au.AsyncClient() as client:
        resp = await client.post("/v1/design-path", json={"alloy": "AISI 4140"})
        print(resp.json()["properties"]["sigma_y_MPa"])

asyncio.run(main())
```

---

## Errors

```python
import austenite as au

try:
    au.design_path(alloy="bogus")
except au.ValidationError as e:
    print(f"Bad input: {e}")          # HTTP 4xx
except au.RateLimitError as e:
    print(f"Slow down: {e}")          # HTTP 429
except au.EngineError as e:
    print(f"Server failed: {e}")      # HTTP 5xx
except au.NetworkError as e:
    print(f"Transport: {e}")          # timeout / DNS / reset
```

All transient failures (5xx, network) are retried automatically with exponential
backoff (default 3 retries).

---

## Examples

See [`examples/`](examples/) for runnable scripts:

1. `01_design_path_quickstart.py` — AISI 4140 end-to-end
2. `02_am_qualification.py` — IN718 LPBF parameter sweep
3. `03_batch_mtc_parse.py` — folder of MTCs → pandas DataFrame
4. `04_ttt_steel_grade.py` — chemistry → CCT curves
5. `05_calphad_phases.py` — Fe-Cr-Ni equilibrium + Bayesian σ-phase posterior
6. `07_batch_mtc_workflow.py` — full 7-language batch MTC + audit + Excel export

---

## Why this client?

* **Typed inputs and outputs** — pydantic v2 models, so your IDE knows the shape.
* **Forward-compatible** — server-side schema additions never break old clients.
* **Production-ready transport** — automatic retries, idempotency keys, timeouts,
  bearer-token auth.
* **Sync + async** in a single API.
* **Citations on every call** — every prediction carries the literature it stands on.

---

## Links

* API:  https://api.austenite.org/v1
* Docs: https://docs.austenite.org
* Issues: https://github.com/jvnshirr-collab/austenite/issues
* License: MIT

---

*Built by Javanshir Hasanov.*
