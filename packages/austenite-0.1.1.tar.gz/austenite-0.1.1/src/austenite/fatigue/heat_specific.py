"""Heat-batch-aware Bayesian S-N fitter — hierarchical Basquin model.

Engineer pain:
    *"Generic MMPDS S-N curves don't match shop-specific tempered batches.
    Engineers either over-design (waste material) or take false risk."*

This module fits a hierarchical Bayesian Basquin model

.. math::

    \\sigma_a = \\sigma'_f \\cdot (2 N)^{b}

across multiple heat IDs in the same alloy / heat-treat condition,
shrinking each heat's posterior toward a published MMPDS prior with
heat-level random effects. The result: tighter design allowables for
heats with enough data, broader (MMPDS-pulled) priors for heats with
too little data — automatically.

Model:

* Per-heat: ``(log_sigma_f_i, b_i) ~ Normal(mu_global, Sigma_heat)``
* Global hyperprior: ``mu_global ~ Normal(prior_mean_MMPDS, prior_cov)``
* Heat random effect: ``Sigma_heat ~ HalfNormal``
* Observation noise: ``log N_obs ~ Normal(log N_predicted, sigma_obs)``

Sampler: Adaptive Metropolis / DRAM (already shipped via
:mod:`austenite.bayesian`) — but the heat-specific likelihood is
local-only so it runs without an API round-trip.

Public API::

    import austenite as au
    import pandas as pd

    df = pd.read_csv("mill_X_4140_fatigue.csv")
    # required cols: heat_id, sigma_alt_MPa, N_cycles, R_ratio (optional)

    fit = au.fatigue.heat_specific_sn_fit(
        df,
        pretrained_prior="austenite/4140-MMPDS-baseline",
        method="DRAM",
        chains=4, samples=10_000, burn=2_000,
    )

    heat_curve = fit.heat_specific_curves["HEAT-2026-Q1-batch-014"]
    N = heat_curve.predict(sigma_amplitude_MPa=350, R=0.1, target_p_failure=0.05)

    fit.save("./mill-X-4140-fatigue.pkl")
"""

from __future__ import annotations

import json
import math
import pickle
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence, Union


# ---------------------------------------------------------------------------
# Pretrained MMPDS priors — each one is (log sigma_f mean, b mean, cov 2x2).
#
# Numbers reflect published MMPDS-15 / Bannantine-Comer-Handrock values
# for the named alloy + heat-treat condition. The priors are intentionally
# broad (large covariance) so that a shop with enough data dominates.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MMPDSPrior:
    """Pretrained-prior parameters for hierarchical fitting.

    Attributes:
        prior_id: Identifier (e.g. ``"austenite/4140-MMPDS-baseline"``).
        alloy: Material name.
        condition: Heat-treat condition.
        log_sigma_f_mean: Mean of log(σ_f') in MPa (natural log).
        b_mean: Mean of Basquin exponent ``b`` (negative).
        prior_cov: 2x2 covariance matrix as
            ``(var_log_sigma_f, cov, var_b)``.
        obs_noise_log_N: Standard deviation of log-cycles observation
            noise (default 0.5 — captures typical inter-specimen scatter
            of factor-1.6 in life at fixed stress).
        citation: Literature pointer.
    """

    prior_id: str
    alloy: str
    condition: str
    log_sigma_f_mean: float
    b_mean: float
    prior_cov: tuple[float, float, float]  # (var_log_sigma_f, cov, var_b)
    obs_noise_log_N: float = 0.5
    citation: str = ""


# Curated priors — broad covariances so shop data dominates as it
# accumulates (Gelman BDA Ch. 5, "weakly informative" priors).
_PRETRAINED_PRIORS: dict[str, MMPDSPrior] = {
    "austenite/4140-MMPDS-baseline": MMPDSPrior(
        prior_id="austenite/4140-MMPDS-baseline",
        alloy="AISI 4140",
        condition="Q+T HRC 28-32",
        # σ_f' ≈ 1810 MPa → log ≈ 7.50
        log_sigma_f_mean=math.log(1810.0),
        b_mean=-0.085,
        prior_cov=(0.04, -0.0006, 0.0009),  # σ_log ≈ 0.20, σ_b ≈ 0.03, mild neg corr
        obs_noise_log_N=0.5,
        citation=(
            "MMPDS-15 (2022) §2.3; Bannantine-Comer-Handrock 1990 p.111 "
            "— AISI 4140 Q+T smooth-bar rotating-bending S-N."
        ),
    ),
    "austenite/4340-MMPDS-baseline": MMPDSPrior(
        prior_id="austenite/4340-MMPDS-baseline",
        alloy="AISI 4340",
        condition="Q+T HRC 32-38",
        log_sigma_f_mean=math.log(1880.0),
        b_mean=-0.080,
        prior_cov=(0.04, -0.0006, 0.0009),
        obs_noise_log_N=0.5,
        citation=(
            "MMPDS-15 (2022) §2.3.2; Bannantine 1990 p.115 — AISI 4340 "
            "Q+T smooth-bar S-N."
        ),
    ),
    "austenite/sa-516-70-MMPDS-baseline": MMPDSPrior(
        prior_id="austenite/sa-516-70-MMPDS-baseline",
        alloy="SA-516 Gr 70",
        condition="normalized",
        log_sigma_f_mean=math.log(770.0),
        b_mean=-0.087,
        prior_cov=(0.05, -0.0005, 0.001),
        obs_noise_log_N=0.55,
        citation=(
            "ASME VIII Div 2 Annex 3.F.4 — carbon-steel pressure-vessel "
            "smooth-bar fatigue baseline."
        ),
    ),
    "austenite/in718-MMPDS-baseline": MMPDSPrior(
        prior_id="austenite/in718-MMPDS-baseline",
        alloy="Inconel 718",
        condition="STA",
        log_sigma_f_mean=math.log(2050.0),
        b_mean=-0.070,
        prior_cov=(0.04, -0.0004, 0.0008),
        obs_noise_log_N=0.45,
        citation=(
            "MMPDS-15 (2022) §6.3; NASA TM-2007-214694 — IN718 STA "
            "smooth-bar fatigue at RT."
        ),
    ),
    "austenite/ti-6al-4v-MMPDS-baseline": MMPDSPrior(
        prior_id="austenite/ti-6al-4v-MMPDS-baseline",
        alloy="Ti-6Al-4V",
        condition="annealed",
        log_sigma_f_mean=math.log(1700.0),
        b_mean=-0.090,
        prior_cov=(0.05, -0.0006, 0.001),
        obs_noise_log_N=0.5,
        citation=(
            "MMPDS-15 (2022) §5.2; Boyer R., Materials Properties Handbook: "
            "Titanium Alloys, ASM (1994) — Ti-6Al-4V annealed S-N."
        ),
    ),
}


def list_pretrained_priors() -> list[str]:
    """Return every pretrained-prior id this module ships."""

    return sorted(_PRETRAINED_PRIORS.keys())


def _resolve_prior(prior_id_or_obj: Union[str, MMPDSPrior]) -> MMPDSPrior:
    if isinstance(prior_id_or_obj, MMPDSPrior):
        return prior_id_or_obj
    if prior_id_or_obj in _PRETRAINED_PRIORS:
        return _PRETRAINED_PRIORS[prior_id_or_obj]
    raise KeyError(
        f"Unknown pretrained prior {prior_id_or_obj!r}; "
        f"available: {list_pretrained_priors()}"
    )


# ---------------------------------------------------------------------------
# Basquin curve output object
# ---------------------------------------------------------------------------


@dataclass
class BasquinCurve:
    """A per-heat (or global) Basquin posterior summary.

    Attributes:
        heat_id: Heat identifier (``"GLOBAL"`` for the pooled curve).
        sigma_f_mean_MPa: Posterior mean of ``σ_f'`` in MPa.
        sigma_f_std_MPa: Posterior std-dev of ``σ_f'`` in MPa.
        b_mean: Posterior mean of Basquin exponent.
        b_std: Posterior std-dev of ``b``.
        log_N_std: Posterior std-dev of log(N) observation noise.
        n_observations: Number of measured (σ, N) pairs for this heat.
        log_sigma_f_samples / b_samples: Posterior draws (for predict).
    """

    heat_id: str
    sigma_f_mean_MPa: float
    sigma_f_std_MPa: float
    b_mean: float
    b_std: float
    log_N_std: float
    n_observations: int
    log_sigma_f_samples: list[float] = field(default_factory=list)
    b_samples: list[float] = field(default_factory=list)

    def predict(
        self,
        *,
        sigma_amplitude_MPa: float,
        R: float = -1.0,
        target_p_failure: float = 0.05,
    ) -> float:
        """Predict cycles-to-failure at a given stress amplitude.

        The basic Basquin equation::

            σ_a = σ_f' · (2N)^b   ⇒   2N = (σ_a / σ_f')^(1/b)

        For mean-stress correction we apply the simple Goodman (1899)
        rule with σ_uts ≈ 1.6·σ_f' (typical ratio for engineering steels)
        and convert R-ratio to a mean stress.

        Args:
            sigma_amplitude_MPa: Stress amplitude (half-range).
            R: Stress ratio R = σ_min / σ_max. Default ``-1`` (fully
                reversed → no Goodman correction).
            target_p_failure: Allowable probability of failure (e.g.
                ``0.05`` for a 5 % design allowable). Uses the posterior
                samples to compute the lower bound of N at that quantile.

        Returns:
            N (cycles-to-failure) at the requested failure probability.
        """

        if not self.log_sigma_f_samples:
            # Fall back to point estimate using mean
            return self._point_predict(
                sigma_amplitude_MPa=sigma_amplitude_MPa, R=R
            )

        # Effective stress amplitude after Goodman correction
        sigma_a_eq = self._goodman_amplitude(sigma_amplitude_MPa, R)

        N_samples: list[float] = []
        for log_sf, b in zip(self.log_sigma_f_samples, self.b_samples):
            sigma_f = math.exp(log_sf)
            if sigma_a_eq <= 0:
                # Infinite-life regime — return Ne = 1e7 sentinel
                N_samples.append(1.0e7)
                continue
            ratio = sigma_a_eq / sigma_f
            if ratio <= 0:
                N_samples.append(1.0e7)
                continue
            try:
                N = 0.5 * ratio ** (1.0 / b)
            except (OverflowError, ValueError):
                N = 1.0e7
            if math.isnan(N) or math.isinf(N) or N <= 0:
                N = 1.0e7
            N_samples.append(N)

        N_samples.sort()
        # P(failure) = p → take the p-th quantile of N_samples
        q = max(0.0, min(1.0, target_p_failure))
        idx = int(q * (len(N_samples) - 1))
        return N_samples[idx]

    def _point_predict(self, *, sigma_amplitude_MPa: float, R: float) -> float:
        sigma_a_eq = self._goodman_amplitude(sigma_amplitude_MPa, R)
        if sigma_a_eq <= 0:
            return 1.0e7
        ratio = sigma_a_eq / self.sigma_f_mean_MPa
        if ratio <= 0 or self.b_mean == 0:
            return 1.0e7
        try:
            N = 0.5 * ratio ** (1.0 / self.b_mean)
        except (OverflowError, ValueError):
            return 1.0e7
        if math.isnan(N) or math.isinf(N) or N <= 0:
            return 1.0e7
        return N

    def _goodman_amplitude(self, sigma_a: float, R: float) -> float:
        """Goodman (1899) mean-stress correction.

        Convert R-ratio + amplitude to a fully-reversed equivalent
        amplitude using σ_uts ≈ 1.6 · σ_f' (Roessle-Fatemi 2000 ratio).
        Returns ``sigma_a`` unchanged for R = -1.
        """

        if R == -1.0:
            return sigma_a
        # σ_max = σ_a + σ_m, σ_min = σ_m - σ_a → σ_m = σ_a · (1+R)/(1-R)
        if abs(1.0 - R) < 1e-9:
            return sigma_a
        sigma_m = sigma_a * (1.0 + R) / (1.0 - R)
        sigma_uts = 1.6 * self.sigma_f_mean_MPa
        # Goodman: σ_a_eq = σ_a / (1 - σ_m/σ_uts)
        denom = 1.0 - sigma_m / sigma_uts
        if denom <= 0:
            return float("inf")  # mean stress exceeds UTS → instant failure
        return sigma_a / denom

    def to_dict(self) -> dict[str, Any]:
        return {
            "heat_id": self.heat_id,
            "sigma_f_mean_MPa": self.sigma_f_mean_MPa,
            "sigma_f_std_MPa": self.sigma_f_std_MPa,
            "b_mean": self.b_mean,
            "b_std": self.b_std,
            "log_N_std": self.log_N_std,
            "n_observations": self.n_observations,
        }


# ---------------------------------------------------------------------------
# Fit container
# ---------------------------------------------------------------------------


@dataclass
class HeatSpecificSNFit:
    """Result of :func:`heat_specific_sn_fit`.

    Attributes:
        prior: Pretrained MMPDS prior used.
        global_posterior: Pooled / hyperprior posterior (used when a
            new heat has no data).
        heat_specific_curves: Map from ``heat_id`` to :class:`BasquinCurve`.
        discrepancy: Map from ``heat_id`` to the signed deviation of the
            heat's posterior mean (log σ_f) from the MMPDS prior mean
            (i.e. ``mu_heat - mu_MMPDS``) — positive means this heat is
            stronger than MMPDS.
        r_hat: Brooks-Gelman R-hat per parameter (max should be ≤1.1).
        method: Sampler ("DRAM" or "MH").
        n_chains / n_samples / n_burn: Sampler config.
        acceptance_rate: Posterior acceptance ratio.
    """

    prior: MMPDSPrior
    global_posterior: BasquinCurve
    heat_specific_curves: dict[str, BasquinCurve]
    discrepancy: dict[str, float]
    r_hat: dict[str, float]
    method: str
    n_chains: int
    n_samples: int
    n_burn: int
    acceptance_rate: float

    def save(self, path: Union[str, Path]) -> Path:
        """Pickle the fit to ``path``. Returns the resolved Path."""

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("wb") as f:
            pickle.dump(self, f)
        return p

    @classmethod
    def load(cls, path: Union[str, Path]) -> "HeatSpecificSNFit":
        with Path(path).open("rb") as f:
            obj = pickle.load(f)
        if not isinstance(obj, HeatSpecificSNFit):
            raise TypeError(
                f"Loaded object is {type(obj).__name__}, expected HeatSpecificSNFit"
            )
        return obj

    def to_json(self, path: Union[str, Path]) -> Path:
        """Pickle-free JSON serialisation."""

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "prior_id": self.prior.prior_id,
            "method": self.method,
            "n_chains": self.n_chains,
            "n_samples": self.n_samples,
            "n_burn": self.n_burn,
            "acceptance_rate": self.acceptance_rate,
            "r_hat": dict(self.r_hat),
            "global_posterior": self.global_posterior.to_dict(),
            "heat_specific_curves": {
                k: v.to_dict() for k, v in self.heat_specific_curves.items()
            },
            "discrepancy": dict(self.discrepancy),
        }
        with p.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return p


# ---------------------------------------------------------------------------
# Core fit routine
# ---------------------------------------------------------------------------


def heat_specific_sn_fit(
    data: Any,
    *,
    pretrained_prior: Union[str, MMPDSPrior] = "austenite/4140-MMPDS-baseline",
    method: str = "DRAM",
    chains: int = 4,
    samples: int = 10_000,
    burn: Optional[int] = None,
    seed: Optional[int] = None,
) -> HeatSpecificSNFit:
    """Hierarchical Bayesian Basquin fit with MMPDS prior shrinkage.

    Args:
        data: Either a ``pandas.DataFrame`` with columns
            ``heat_id, sigma_alt_MPa, N_cycles`` (and optionally
            ``R_ratio``), OR a list of dicts with the same keys.
        pretrained_prior: Either an :class:`MMPDSPrior` instance or one of
            the ids returned by :func:`list_pretrained_priors`.
        method: ``"DRAM"`` (Haario et al. 2006) or ``"MH"``
            (basic Metropolis).
        chains: Number of independent MCMC chains for R-hat (default 4).
        samples: Steps per chain post-burn (default 10_000).
        burn: Burn-in steps (default ``samples // 5``).
        seed: RNG seed for reproducibility.

    Returns:
        :class:`HeatSpecificSNFit`.
    """

    prior = _resolve_prior(pretrained_prior)
    burn = burn if burn is not None else max(500, samples // 5)
    if chains < 1:
        raise ValueError("chains must be >= 1")
    if samples < 100:
        raise ValueError("samples must be >= 100")
    method_u = method.upper()
    if method_u not in ("DRAM", "MH"):
        raise ValueError(f"Unknown method {method!r}; use DRAM or MH")

    # ── Coerce input to per-heat datasets ──
    heat_data = _parse_input(data)
    if not heat_data:
        raise ValueError("No data rows supplied — need at least one heat.")

    rng = random.Random(seed)
    chain_results: list[dict[str, Any]] = []
    overall_n_accepted = 0
    overall_n_proposed = 0

    for chain_idx in range(chains):
        chain_seed = rng.randint(0, 2**31 - 1)
        chain = _run_chain(
            heat_data=heat_data,
            prior=prior,
            method=method_u,
            samples=samples,
            burn=burn,
            seed=chain_seed,
        )
        chain_results.append(chain)
        overall_n_accepted += chain["n_accepted"]
        overall_n_proposed += chain["n_proposed"]

    acceptance_rate = (
        overall_n_accepted / overall_n_proposed if overall_n_proposed else 0.0
    )

    # ── Combine chains: concat samples, compute summaries ──
    heat_ids = sorted(heat_data.keys())
    combined: dict[str, dict[str, list[float]]] = {
        h: {"log_sigma_f": [], "b": []} for h in heat_ids + ["__global__"]
    }
    log_N_std_samples: list[float] = []
    for ch in chain_results:
        for h in heat_ids:
            combined[h]["log_sigma_f"].extend(ch["heat_samples"][h]["log_sigma_f"])
            combined[h]["b"].extend(ch["heat_samples"][h]["b"])
        combined["__global__"]["log_sigma_f"].extend(ch["global_samples"]["log_sigma_f"])
        combined["__global__"]["b"].extend(ch["global_samples"]["b"])
        log_N_std_samples.extend(ch["log_N_std_samples"])

    # ── R-hat per parameter (Brooks-Gelman 1998) ──
    r_hat: dict[str, float] = {}
    for h in heat_ids + ["__global__"]:
        for param in ("log_sigma_f", "b"):
            per_chain = [ch["heat_samples"][h][param] if h != "__global__"
                         else ch["global_samples"][param]
                         for ch in chain_results]
            r_hat[f"{h}.{param}"] = _r_hat(per_chain)

    # ── Build per-heat BasquinCurves ──
    heat_curves: dict[str, BasquinCurve] = {}
    discrepancy: dict[str, float] = {}
    for h in heat_ids:
        log_sf_samples = combined[h]["log_sigma_f"]
        b_samples = combined[h]["b"]
        log_sf_mean = _mean(log_sf_samples)
        b_mean = _mean(b_samples)
        heat_curves[h] = BasquinCurve(
            heat_id=h,
            sigma_f_mean_MPa=math.exp(log_sf_mean),
            sigma_f_std_MPa=math.exp(log_sf_mean) * _stdev(log_sf_samples),
            b_mean=b_mean,
            b_std=_stdev(b_samples),
            log_N_std=_mean(log_N_std_samples) if log_N_std_samples else prior.obs_noise_log_N,
            n_observations=len(heat_data[h]),
            log_sigma_f_samples=log_sf_samples,
            b_samples=b_samples,
        )
        discrepancy[h] = log_sf_mean - prior.log_sigma_f_mean

    # ── Global posterior ──
    gl_log_sf = combined["__global__"]["log_sigma_f"]
    gl_b = combined["__global__"]["b"]
    gl_log_sf_mean = _mean(gl_log_sf)
    gl_b_mean = _mean(gl_b)
    global_curve = BasquinCurve(
        heat_id="GLOBAL",
        sigma_f_mean_MPa=math.exp(gl_log_sf_mean),
        sigma_f_std_MPa=math.exp(gl_log_sf_mean) * _stdev(gl_log_sf),
        b_mean=gl_b_mean,
        b_std=_stdev(gl_b),
        log_N_std=_mean(log_N_std_samples) if log_N_std_samples else prior.obs_noise_log_N,
        n_observations=sum(len(v) for v in heat_data.values()),
        log_sigma_f_samples=gl_log_sf,
        b_samples=gl_b,
    )

    return HeatSpecificSNFit(
        prior=prior,
        global_posterior=global_curve,
        heat_specific_curves=heat_curves,
        discrepancy=discrepancy,
        r_hat=r_hat,
        method=method_u,
        n_chains=chains,
        n_samples=samples,
        n_burn=burn,
        acceptance_rate=acceptance_rate,
    )


# ---------------------------------------------------------------------------
# Single-chain Metropolis / DRAM sampler
# ---------------------------------------------------------------------------


def _run_chain(
    *,
    heat_data: dict[str, list[dict[str, float]]],
    prior: MMPDSPrior,
    method: str,
    samples: int,
    burn: int,
    seed: int,
) -> dict[str, Any]:
    """Run one MCMC chain over the hierarchical model.

    Parameter vector layout (per chain step):

      θ = [mu_log_sf, mu_b, log_tau_sf, log_tau_b, log_sigma_obs,
           log_sf_h1, b_h1, ..., log_sf_hk, b_hk]

    where ``mu_log_sf, mu_b`` are global means, ``tau_*`` are heat-level
    random-effect std-devs, ``sigma_obs`` is observation noise, and the
    last 2K elements are per-heat parameters.
    """

    rng = random.Random(seed)
    heat_ids = sorted(heat_data.keys())
    K = len(heat_ids)

    var_log_sf, _cov, var_b = prior.prior_cov
    sd_log_sf = math.sqrt(max(var_log_sf, 1e-9))
    sd_b = math.sqrt(max(var_b, 1e-9))

    # ── Initial state: prior means + small noise ──
    state = {
        "mu_log_sf": prior.log_sigma_f_mean + rng.gauss(0.0, 0.1),
        "mu_b": prior.b_mean + rng.gauss(0.0, 0.01),
        "log_tau_sf": math.log(0.1) + rng.gauss(0.0, 0.05),
        "log_tau_b": math.log(0.03) + rng.gauss(0.0, 0.02),
        "log_sigma_obs": math.log(prior.obs_noise_log_N) + rng.gauss(0.0, 0.05),
        "heats": {
            h: {
                "log_sf": prior.log_sigma_f_mean + rng.gauss(0.0, 0.05),
                "b": prior.b_mean + rng.gauss(0.0, 0.01),
            }
            for h in heat_ids
        },
    }

    # Initial step sizes (will adapt during burn-in)
    step = {
        "mu_log_sf": 0.05,
        "mu_b": 0.01,
        "log_tau_sf": 0.05,
        "log_tau_b": 0.05,
        "log_sigma_obs": 0.05,
        "heat_log_sf": 0.05,
        "heat_b": 0.01,
    }
    target_acc = 0.30

    def log_prior(s: dict) -> float:
        # Global means
        lp = _norm_logpdf(s["mu_log_sf"], prior.log_sigma_f_mean, sd_log_sf)
        lp += _norm_logpdf(s["mu_b"], prior.b_mean, sd_b)
        # Half-normal hyperpriors on tau (in log-space)
        tau_sf = math.exp(s["log_tau_sf"])
        tau_b = math.exp(s["log_tau_b"])
        lp += _halfnormal_logpdf(tau_sf, sigma=0.3)
        lp += _halfnormal_logpdf(tau_b, sigma=0.05)
        sigma_obs = math.exp(s["log_sigma_obs"])
        lp += _halfnormal_logpdf(sigma_obs, sigma=prior.obs_noise_log_N * 2)
        # Per-heat random effects
        for h in heat_ids:
            hp = s["heats"][h]
            lp += _norm_logpdf(hp["log_sf"], s["mu_log_sf"], tau_sf)
            lp += _norm_logpdf(hp["b"], s["mu_b"], tau_b)
        return lp

    def log_likelihood(s: dict) -> float:
        sigma_obs = math.exp(s["log_sigma_obs"])
        ll = 0.0
        for h in heat_ids:
            log_sf = s["heats"][h]["log_sf"]
            b = s["heats"][h]["b"]
            sigma_f = math.exp(log_sf)
            for row in heat_data[h]:
                sigma_a = row["sigma_alt_MPa"]
                N_obs = row["N_cycles"]
                if N_obs <= 0 or sigma_a <= 0 or sigma_f <= 0:
                    continue
                # Predicted log N = log(0.5) + (1/b) * log(sigma_a / sigma_f)
                ratio = sigma_a / sigma_f
                if ratio <= 0 or b == 0:
                    continue
                log_N_pred = math.log(0.5) + (1.0 / b) * math.log(ratio)
                log_N_obs = math.log(N_obs)
                ll += _norm_logpdf(log_N_obs, log_N_pred, sigma_obs)
        return ll

    def log_posterior(s: dict) -> float:
        return log_prior(s) + log_likelihood(s)

    cur_lp = log_posterior(state)
    n_accepted = 0
    n_proposed = 0

    # Storage
    heat_samples: dict[str, dict[str, list[float]]] = {
        h: {"log_sigma_f": [], "b": []} for h in heat_ids
    }
    global_samples: dict[str, list[float]] = {"log_sigma_f": [], "b": []}
    log_N_std_samples: list[float] = []

    total = burn + samples
    adapt_freq = 50

    for it in range(total):
        # ── Block 1: global means ──
        proposed = _copy_state(state)
        proposed["mu_log_sf"] += rng.gauss(0.0, step["mu_log_sf"])
        proposed["mu_b"] += rng.gauss(0.0, step["mu_b"])
        n_proposed += 1
        prop_lp = log_posterior(proposed)
        if _accept(prop_lp - cur_lp, rng):
            state = proposed
            cur_lp = prop_lp
            n_accepted += 1
        else:
            # DRAM: try a smaller delayed-rejection step
            if method == "DRAM":
                dr = _copy_state(state)
                dr["mu_log_sf"] += rng.gauss(0.0, step["mu_log_sf"] * 0.3)
                dr["mu_b"] += rng.gauss(0.0, step["mu_b"] * 0.3)
                dr_lp = log_posterior(dr)
                if _accept(dr_lp - cur_lp, rng):
                    state = dr
                    cur_lp = dr_lp
                    n_accepted += 1

        # ── Block 2: tau (heat random-effect std-devs) + sigma_obs ──
        proposed = _copy_state(state)
        proposed["log_tau_sf"] += rng.gauss(0.0, step["log_tau_sf"])
        proposed["log_tau_b"] += rng.gauss(0.0, step["log_tau_b"])
        proposed["log_sigma_obs"] += rng.gauss(0.0, step["log_sigma_obs"])
        n_proposed += 1
        prop_lp = log_posterior(proposed)
        if _accept(prop_lp - cur_lp, rng):
            state = proposed
            cur_lp = prop_lp
            n_accepted += 1

        # ── Block 3: per-heat update (sequentially) ──
        for h in heat_ids:
            proposed = _copy_state(state)
            proposed["heats"][h]["log_sf"] += rng.gauss(0.0, step["heat_log_sf"])
            proposed["heats"][h]["b"] += rng.gauss(0.0, step["heat_b"])
            n_proposed += 1
            prop_lp = log_posterior(proposed)
            if _accept(prop_lp - cur_lp, rng):
                state = proposed
                cur_lp = prop_lp
                n_accepted += 1
            elif method == "DRAM":
                dr = _copy_state(state)
                dr["heats"][h]["log_sf"] += rng.gauss(0.0, step["heat_log_sf"] * 0.3)
                dr["heats"][h]["b"] += rng.gauss(0.0, step["heat_b"] * 0.3)
                dr_lp = log_posterior(dr)
                if _accept(dr_lp - cur_lp, rng):
                    state = dr
                    cur_lp = dr_lp
                    n_accepted += 1

        # Adapt during burn-in
        if it < burn and it > 0 and it % adapt_freq == 0:
            rate = n_accepted / max(1, n_proposed)
            scale = 1.0 + 0.5 * (rate - target_acc)
            scale = max(0.5, min(2.0, scale))
            for k in step:
                step[k] *= scale

        # Record samples post-burn
        if it >= burn:
            for h in heat_ids:
                heat_samples[h]["log_sigma_f"].append(state["heats"][h]["log_sf"])
                heat_samples[h]["b"].append(state["heats"][h]["b"])
            global_samples["log_sigma_f"].append(state["mu_log_sf"])
            global_samples["b"].append(state["mu_b"])
            log_N_std_samples.append(math.exp(state["log_sigma_obs"]))

    return {
        "heat_samples": heat_samples,
        "global_samples": global_samples,
        "log_N_std_samples": log_N_std_samples,
        "n_accepted": n_accepted,
        "n_proposed": n_proposed,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _accept(log_alpha: float, rng: random.Random) -> bool:
    if log_alpha >= 0:
        return True
    u = rng.random()
    if u <= 0:
        return False
    return math.log(u) < log_alpha


def _norm_logpdf(x: float, mean: float, sd: float) -> float:
    if sd <= 0:
        return -1e15
    z = (x - mean) / sd
    return -0.5 * z * z - math.log(sd) - 0.5 * math.log(2 * math.pi)


def _halfnormal_logpdf(x: float, sigma: float) -> float:
    if x <= 0 or sigma <= 0:
        return -1e15
    return (
        math.log(2.0)
        - 0.5 * (x / sigma) ** 2
        - math.log(sigma)
        - 0.5 * math.log(2 * math.pi)
    )


def _copy_state(s: dict) -> dict:
    return {
        "mu_log_sf": s["mu_log_sf"],
        "mu_b": s["mu_b"],
        "log_tau_sf": s["log_tau_sf"],
        "log_tau_b": s["log_tau_b"],
        "log_sigma_obs": s["log_sigma_obs"],
        "heats": {h: dict(v) for h, v in s["heats"].items()},
    }


def _mean(xs: Sequence[float]) -> float:
    if not xs:
        return 0.0
    return sum(xs) / len(xs)


def _stdev(xs: Sequence[float]) -> float:
    n = len(xs)
    if n < 2:
        return 0.0
    m = _mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (n - 1))


def _r_hat(chains: list[list[float]]) -> float:
    """Brooks-Gelman R-hat (1998).

    R-hat ≤ 1.1 is the standard convergence rule.
    """

    chains = [c for c in chains if c]
    if len(chains) < 2:
        return 1.0
    n = min(len(c) for c in chains)
    if n < 2:
        return 1.0
    m = len(chains)
    chain_means = [_mean(c[:n]) for c in chains]
    chain_vars = [
        sum((x - chain_means[i]) ** 2 for x in chains[i][:n]) / (n - 1)
        for i in range(m)
    ]
    grand_mean = _mean(chain_means)
    B = n / (m - 1) * sum((cm - grand_mean) ** 2 for cm in chain_means)
    W = sum(chain_vars) / m
    if W <= 0:
        return 1.0
    var_hat = (n - 1) / n * W + B / n
    return math.sqrt(var_hat / W)


def _parse_input(data: Any) -> dict[str, list[dict[str, float]]]:
    """Coerce a DataFrame OR a list of dicts into ``{heat_id: [{sigma_alt,N},...]}``."""

    rows: list[Mapping[str, Any]] = []
    try:
        import pandas as pd  # type: ignore

        if isinstance(data, pd.DataFrame):
            for _, r in data.iterrows():
                rows.append(r.to_dict())
        else:
            rows = list(data)
    except ImportError:
        rows = list(data)

    out: dict[str, list[dict[str, float]]] = {}
    for r in rows:
        heat = r.get("heat_id")
        if heat is None:
            continue
        try:
            sigma = float(r.get("sigma_alt_MPa"))
            N = float(r.get("N_cycles"))
        except (TypeError, ValueError):
            continue
        if not math.isfinite(sigma) or not math.isfinite(N) or sigma <= 0 or N <= 0:
            continue
        entry: dict[str, float] = {"sigma_alt_MPa": sigma, "N_cycles": N}
        if "R_ratio" in r and r["R_ratio"] is not None:
            try:
                entry["R_ratio"] = float(r["R_ratio"])
            except (TypeError, ValueError):
                pass
        out.setdefault(str(heat), []).append(entry)
    return out
