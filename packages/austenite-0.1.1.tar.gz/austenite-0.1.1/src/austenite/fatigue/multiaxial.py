"""Multi-axial / critical-plane fatigue.

The single most-used fatigue method for shafts, gears, bearings, and pressure
vessels with combined loading. Most real-world fatigue failures occur under
multi-axial stress, not the uniaxial assumption MMPDS S-N curves imply.

Implements the canonical critical-plane criteria + the stress-invariant
methods:

* **Goodman 1899 / Soderberg 1930 / Gerber 1874 / Morrow 1968 mean-stress
  corrections** — unified ``mean_stress_correction``.
* **Smith-Watson-Topper 1970 (SWT)** — ``σ_a · ε_a · E`` damage parameter
  used widely for non-zero mean stress.
* **Findley 1959** — critical-plane parameter
  ``τ_a + k · σ_n,max`` for hard metals.
* **Brown-Miller 1973** — γ-N curve approach with shear- and normal-strain
  on the maximum shear plane.
* **Wang-Brown 1993** — path-dependent extension for non-proportional loading.
* **Dang Van 1989** — stress-invariant micro/macro criterion for high-cycle
  fatigue under arbitrary loading paths.
* **Crossland 1956** — closed-form stress-invariant criterion (octahedral
  shear amplitude + max hydrostatic).
* **Itoh 1995 non-proportionality factor F_NP** — quantifies out-of-phase
  damage amplification.

Critical-plane search is done by exhaustive sweep over ``θ ∈ [0°, 180°]``
in 1° increments (Brown-Miller / Findley), or by closed-form for invariant-
based criteria (Crossland, Dang Van).

References:
    * Findley W., J. Eng. Ind. 81 (1959) 301-306.
    * Brown M.W., Miller K.J., Proc. Inst. Mech. Eng. 187 (1973) 745.
    * Wang C.H., Brown M.W., Fatigue Fract. Eng. Mater. Struct. 16 (1993) 1285.
    * Dang Van K., et al., ASTM STP 1191 (1989) 21-32.
    * Crossland B., Proc. Int. Conf. Fatigue of Metals (1956) 138.
    * Smith K.N., Watson P., Topper T.H., J. Mater. JMLSA 5 (1970) 767.
    * Itoh T., et al., Fatigue Fract. Eng. Mater. Struct. 18 (1995) 245-260.
    * Morrow J.D., in "Fatigue Design Handbook," SAE AE-4 (1968) 21.
    * Goodman J., "Mechanics Applied to Engineering," Longmans (1899).
    * Soderberg C.R., Trans. ASME 52 (1930) 13.
    * Gerber W., Z. Bayer Architekten Ingenieur-Vereins 6 (1874) 101.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal, Sequence

# ---------------------------------------------------------------------------
# 1. MEAN-STRESS CORRECTIONS (unified API)
# ---------------------------------------------------------------------------

MeanStressMethod = Literal[
    "goodman", "soderberg", "gerber", "morrow", "swt", "walker", "modified-walker"
]


def mean_stress_correction(
    sigma_amplitude_MPa: float,
    sigma_mean_MPa: float,
    *,
    method: MeanStressMethod = "goodman",
    sigma_uts_MPa: float = 800.0,
    sigma_y_MPa: float | None = None,
    sigma_fracture_MPa: float | None = None,
    walker_gamma: float = 0.5,
) -> float:
    """Return the equivalent fully-reversed amplitude ``σ_a,eq`` after a
    mean-stress correction.

    All formulae return ``σ_a,eq`` such that the design check becomes
    ``σ_a,eq ≤ σ_e`` against the fully-reversed endurance limit.

    Parameters
    ----------
    sigma_amplitude_MPa: applied stress amplitude (always positive).
    sigma_mean_MPa: applied mean stress (can be tensile + or compressive −).
    method: which correction to use.
    sigma_uts_MPa: ultimate tensile strength.
    sigma_y_MPa: yield strength (required for Soderberg).
    sigma_fracture_MPa: true-fracture stress (required for Morrow). If None,
        defaults to 1.2·sigma_uts which is a typical approximation.
    walker_gamma: Walker exponent, 0.5 typical for steels; lower (≈0.3) for
        Al alloys, higher (≈0.7) for Ti.

    Notes
    -----
    Soderberg (1930) is the most conservative — uses yield not UTS.
    Goodman (1899) is the classical industry baseline.
    Gerber (1874) is parabolic and least conservative on tensile mean.
    Morrow (1968) replaces UTS with the true-fracture stress σ_f', better for
    high-strength steels.
    SWT (Smith-Watson-Topper 1970) is widely used for non-zero R-ratio
    fatigue when ``σ_max · σ_a > 0``.
    Walker (1970) is the modern industry-standard correction with a tunable γ.
    """
    if not _is_finite(sigma_amplitude_MPa) or sigma_amplitude_MPa < 0:
        return float("nan")

    sa = float(sigma_amplitude_MPa)
    sm = float(sigma_mean_MPa) if _is_finite(sigma_mean_MPa) else 0.0
    su = max(1.0, float(sigma_uts_MPa))

    if method == "goodman":
        # σ_a,eq = σ_a / (1 − σ_m/σ_UTS), for σ_m ≥ 0; for compressive σ_m,
        # no benefit (Goodman cut-off).
        ratio = sm / su
        if ratio <= 0:
            return sa
        if ratio >= 1:
            return float("inf")
        return sa / (1.0 - ratio)

    if method == "soderberg":
        if sigma_y_MPa is None or not _is_finite(sigma_y_MPa):
            raise ValueError("Soderberg requires sigma_y_MPa.")
        sy = max(1.0, float(sigma_y_MPa))
        ratio = sm / sy
        if ratio <= 0:
            return sa
        if ratio >= 1:
            return float("inf")
        return sa / (1.0 - ratio)

    if method == "gerber":
        # σ_a,eq = σ_a / (1 − (σ_m/σ_UTS)²)
        ratio_sq = (sm / su) ** 2
        if sm <= 0:
            return sa
        if ratio_sq >= 1:
            return float("inf")
        return sa / (1.0 - ratio_sq)

    if method == "morrow":
        sf = sigma_fracture_MPa if sigma_fracture_MPa is not None else 1.2 * su
        sf = max(1.0, float(sf))
        ratio = sm / sf
        if ratio <= 0:
            return sa
        if ratio >= 1:
            return float("inf")
        return sa / (1.0 - ratio)

    if method == "swt":
        # σ_max = σ_m + σ_a; SWT damage = (σ_max · σ_a)^(1/2) scaled to amplitude
        smax = sm + sa
        if smax <= 0:
            return 0.0  # compressive max — SWT defines no damage
        return math.sqrt(smax * sa)

    if method == "walker":
        # σ_eq = σ_max^(1-γ) · σ_a^γ, with σ_max ≥ 0
        smax = sm + sa
        if smax <= 0:
            return 0.0
        return (smax ** (1.0 - walker_gamma)) * (sa ** walker_gamma)

    if method == "modified-walker":
        # Lawrence 1981 extension: piecewise γ_t (R≥0) vs γ_c (R<0)
        r_ratio = (sm - sa) / max(1e-9, sm + sa) if (sm + sa) > 0 else -1.0
        gamma = walker_gamma if r_ratio >= 0 else min(0.95, walker_gamma + 0.1)
        smax = sm + sa
        if smax <= 0:
            return 0.0
        return (smax ** (1.0 - gamma)) * (sa ** gamma)

    raise ValueError(f"Unknown mean-stress method: {method}")


# ---------------------------------------------------------------------------
# 2. CRITICAL-PLANE CRITERIA
# ---------------------------------------------------------------------------


@dataclass
class CriticalPlaneResult:
    """Result of a critical-plane search."""

    theta_deg: float
    """Orientation of the maximum-damage plane (degrees from a reference axis)."""

    damage_parameter: float
    """The maximum value of the critical-plane parameter."""

    method: str
    """Which criterion ('findley' / 'brown-miller' / 'wang-brown' / etc)."""

    tau_amplitude_MPa: float = float("nan")
    """Shear-stress amplitude on the critical plane."""

    sigma_normal_max_MPa: float = float("nan")
    """Maximum normal stress on the critical plane."""

    notes: list[str] = field(default_factory=list)

    @property
    def verdict(self) -> str:
        if not _is_finite(self.damage_parameter):
            return "INDETERMINATE"
        return f"max-damage plane at θ = {self.theta_deg:.1f}°"


def findley_critical_plane(
    sigma_xx_amplitude_MPa: float,
    sigma_xx_mean_MPa: float,
    tau_xy_amplitude_MPa: float,
    tau_xy_mean_MPa: float = 0.0,
    *,
    findley_k: float = 0.3,
    theta_grid_deg: float = 1.0,
) -> CriticalPlaneResult:
    """Findley 1959 critical-plane fatigue parameter.

    Sweeps θ across all possible plane orientations and finds the one that
    maximises ``τ_a + k · σ_n,max``. For ductile steels k ≈ 0.2-0.3; for
    cast iron k ≈ 0.4-0.5.

    Parameters
    ----------
    sigma_xx_amplitude_MPa, sigma_xx_mean_MPa:
        Normal-stress amplitude and mean on the reference axis.
    tau_xy_amplitude_MPa, tau_xy_mean_MPa:
        Shear-stress amplitude and mean on the reference axis.
    findley_k:
        Findley's material constant (0 ≤ k ≤ 1). 0.3 typical for ductile
        steels. Calibrated by matching uniaxial endurance + torsional
        endurance: ``k = (σ_e − τ_e·√3) / σ_e``.
    theta_grid_deg:
        Sweep increment in degrees.

    Returns
    -------
    CriticalPlaneResult
    """
    if not all(_is_finite(x) for x in [sigma_xx_amplitude_MPa, sigma_xx_mean_MPa,
                                       tau_xy_amplitude_MPa, tau_xy_mean_MPa]):
        return CriticalPlaneResult(
            theta_deg=float("nan"), damage_parameter=float("nan"),
            method="findley", notes=["Non-finite input."]
        )

    sxa = float(sigma_xx_amplitude_MPa)
    sxm = float(sigma_xx_mean_MPa)
    txa = float(tau_xy_amplitude_MPa)
    txm = float(tau_xy_mean_MPa)
    k = float(findley_k)

    best_theta = 0.0
    best_param = -float("inf")
    best_tau_a = 0.0
    best_sigma_n_max = 0.0

    # Sweep θ from 0 to 180° (period of plane orientations in 2D)
    n_steps = int(180.0 / theta_grid_deg) + 1
    for i in range(n_steps):
        theta = i * theta_grid_deg
        c2 = math.cos(2 * math.radians(theta))
        s2 = math.sin(2 * math.radians(theta))

        # Normal-stress on the plane (Mohr's circle transformation)
        sigma_n_a = 0.5 * sxa * (1 + c2) + txa * s2
        sigma_n_m = 0.5 * sxm * (1 + c2) + txm * s2

        # Shear-stress amplitude on the plane
        tau_a = abs(-0.5 * sxa * s2 + txa * c2)

        sigma_n_max = sigma_n_m + sigma_n_a
        param = tau_a + k * sigma_n_max

        if param > best_param:
            best_param = param
            best_theta = theta
            best_tau_a = tau_a
            best_sigma_n_max = sigma_n_max

    return CriticalPlaneResult(
        theta_deg=best_theta,
        damage_parameter=best_param,
        method="findley",
        tau_amplitude_MPa=best_tau_a,
        sigma_normal_max_MPa=best_sigma_n_max,
        notes=[f"Findley k = {k}; critical plane found by {theta_grid_deg}° sweep."],
    )


def brown_miller_critical_plane(
    epsilon_xx_amplitude: float,
    gamma_xy_amplitude: float,
    *,
    nu_e: float = 0.3,
    s: float = 1.65,
    theta_grid_deg: float = 1.0,
) -> CriticalPlaneResult:
    """Brown-Miller 1973 critical-plane parameter.

    Parameter is ``γ_max + s · ε_n`` on the maximum-shear plane, where γ_max
    is the maximum-shear-strain amplitude and ε_n is the normal-strain
    amplitude on that plane. ``s`` is calibrated against uniaxial+torsional
    fatigue data (typically 1.5-1.8 for low-alloy steels).

    Parameters
    ----------
    epsilon_xx_amplitude: normal strain amplitude on reference axis.
    gamma_xy_amplitude: shear strain amplitude on reference axis.
    nu_e: effective Poisson's ratio (≈ 0.3 elastic, 0.5 fully plastic).
    s: Brown-Miller s constant.
    """
    if not all(_is_finite(x) for x in [epsilon_xx_amplitude, gamma_xy_amplitude]):
        return CriticalPlaneResult(
            theta_deg=float("nan"), damage_parameter=float("nan"),
            method="brown-miller", notes=["Non-finite input."]
        )

    exa = float(epsilon_xx_amplitude)
    gxa = float(gamma_xy_amplitude)
    s_ = float(s)
    nu = float(nu_e)

    best_theta = 0.0
    best_param = -float("inf")

    n_steps = int(180.0 / theta_grid_deg) + 1
    for i in range(n_steps):
        theta = i * theta_grid_deg
        c2 = math.cos(2 * math.radians(theta))
        s2 = math.sin(2 * math.radians(theta))

        # Normal strain on plane
        epsilon_n = 0.5 * exa * (1 + c2) + 0.5 * gxa * s2 * (1 - nu)
        # Max shear strain amplitude (engineering γ/2 convention)
        gamma_max = abs(-exa * s2 + gxa * c2)

        param = gamma_max + s_ * epsilon_n

        if param > best_param:
            best_param = param
            best_theta = theta

    return CriticalPlaneResult(
        theta_deg=best_theta,
        damage_parameter=best_param,
        method="brown-miller",
        notes=[f"Brown-Miller s = {s_}; ν_eff = {nu}; sweep {theta_grid_deg}°."],
    )


def wang_brown_path_factor(
    sigma_xx_series: Sequence[float],
    tau_xy_series: Sequence[float],
) -> float:
    """Wang-Brown 1993 / Itoh 1995 non-proportionality factor F_NP.

    F_NP = 1 for proportional loading (σ + τ in phase).
    F_NP > 1 for out-of-phase loading; can reach ≈ 1.5-2.0 for 90°
    out-of-phase, causing significant fatigue-life reduction.

    Returns 1 if the input series is empty or too short.
    """
    if not sigma_xx_series or not tau_xy_series or len(sigma_xx_series) != len(tau_xy_series):
        return 1.0

    n = len(sigma_xx_series)
    if n < 4:
        return 1.0

    # Compute ranges + cross-covariance
    s = [float(x) for x in sigma_xx_series if _is_finite(x)]
    t = [float(x) for x in tau_xy_series if _is_finite(x)]
    if len(s) != len(t) or len(s) < 4:
        return 1.0

    s_mean = sum(s) / len(s)
    t_mean = sum(t) / len(t)
    s_dev = [x - s_mean for x in s]
    t_dev = [x - t_mean for x in t]

    s_std = math.sqrt(sum(x * x for x in s_dev) / len(s))
    t_std = math.sqrt(sum(x * x for x in t_dev) / len(t))
    if s_std <= 0 or t_std <= 0:
        return 1.0

    cov = sum(a * b for a, b in zip(s_dev, t_dev)) / len(s_dev)
    rho = cov / (s_std * t_std)
    rho = max(-1.0, min(1.0, rho))

    # F_NP increases with phase angle; at 90° phase, ρ ≈ 0 ⇒ F_NP ≈ 1.5
    # Itoh formula:  F_NP = 1 + (π/2)·|sin(φ)|·(τ_max/σ_max)
    # We approximate phase angle from correlation: φ = arccos(ρ)
    phase_rad = math.acos(rho)
    s_max = max((abs(x) for x in s), default=0.0)
    t_max = max((abs(x) for x in t), default=0.0)
    if s_max <= 0:
        return 1.0
    ratio = min(1.5, t_max / s_max)
    return float(1.0 + (math.pi / 2) * abs(math.sin(phase_rad)) * ratio)


# ---------------------------------------------------------------------------
# 3. STRESS-INVARIANT CRITERIA
# ---------------------------------------------------------------------------


def crossland_criterion(
    J2_a_MPa: float,
    sigma_h_max_MPa: float,
    *,
    sigma_endurance_MPa: float = 250.0,
    torsion_endurance_MPa: float | None = None,
) -> dict:
    """Crossland 1956 stress-invariant fatigue criterion.

    Computes the equivalent stress √J2_a + α·σ_h,max and compares to torsion
    endurance limit. Closed-form, faster than critical-plane search but
    slightly less accurate for non-proportional loading.

    Parameters
    ----------
    J2_a_MPa: second-invariant amplitude of deviatoric stress √J2_a.
    sigma_h_max_MPa: max hydrostatic stress over the cycle.
    sigma_endurance_MPa: σ_e (fully reversed uniaxial endurance limit).
    torsion_endurance_MPa: τ_e. If None, uses σ_e/√3.

    Returns
    -------
    {"alpha": ..., "sigma_eq_MPa": ..., "passed": True/False, "safety_factor": ...}
    """
    se = max(1.0, float(sigma_endurance_MPa))
    te = float(torsion_endurance_MPa) if torsion_endurance_MPa else se / math.sqrt(3.0)
    alpha = (3.0 * te - math.sqrt(3.0) * se) / max(1e-9, se)

    j2 = float(J2_a_MPa) if _is_finite(J2_a_MPa) else 0.0
    sh = float(sigma_h_max_MPa) if _is_finite(sigma_h_max_MPa) else 0.0

    eq = j2 + alpha * sh
    if not _is_finite(eq):
        eq = float("nan")
    sf = te / eq if eq > 0 else float("inf")

    return {
        "alpha": alpha,
        "sigma_eq_MPa": eq,
        "tau_endurance_MPa": te,
        "passed": eq <= te,
        "safety_factor": sf,
        "method": "crossland-1956",
    }


def dang_van_criterion(
    tau_a_series_MPa: Sequence[float],
    sigma_h_series_MPa: Sequence[float],
    *,
    sigma_endurance_MPa: float = 250.0,
    torsion_endurance_MPa: float | None = None,
) -> dict:
    """Dang Van 1989 micro/macro multi-axial high-cycle fatigue criterion.

    Computes max(τ_a + α_DV · σ_h) over the loading cycle. Considered the
    most sound theoretically — based on shake-down analysis at the
    microscopic (grain) scale.

    Parameters
    ----------
    tau_a_series_MPa: instantaneous shear-stress series (the "elastic shake-
        down" deviatoric component at each time step).
    sigma_h_series_MPa: instantaneous hydrostatic-stress series.
    sigma_endurance_MPa: σ_e (fully reversed uniaxial endurance limit).
    torsion_endurance_MPa: τ_e. If None, uses σ_e/√3.

    Returns
    -------
    {"alpha_DV": ..., "max_dv_param": ..., "passed": True/False, "safety_factor": ...}
    """
    if not tau_a_series_MPa or not sigma_h_series_MPa:
        return {"alpha_DV": float("nan"), "max_dv_param": float("nan"),
                "passed": False, "safety_factor": float("nan"),
                "method": "dang-van-1989", "error": "empty series"}

    se = max(1.0, float(sigma_endurance_MPa))
    te = float(torsion_endurance_MPa) if torsion_endurance_MPa else se / math.sqrt(3.0)
    alpha = (3.0 * te - 1.5 * se) / max(1e-9, se)

    if len(tau_a_series_MPa) != len(sigma_h_series_MPa):
        return {"error": "series length mismatch", "method": "dang-van-1989"}

    max_param = -float("inf")
    for tau, sh in zip(tau_a_series_MPa, sigma_h_series_MPa):
        if not (_is_finite(tau) and _is_finite(sh)):
            continue
        param = float(tau) + alpha * float(sh)
        if param > max_param:
            max_param = param

    if max_param == -float("inf"):
        max_param = float("nan")
    sf = te / max_param if max_param > 0 else float("inf")

    return {
        "alpha_DV": alpha,
        "max_dv_param": max_param,
        "tau_endurance_MPa": te,
        "passed": max_param <= te,
        "safety_factor": sf,
        "method": "dang-van-1989",
    }


# ---------------------------------------------------------------------------
# 4. PALMGREN-MINER DAMAGE ACCUMULATION
# ---------------------------------------------------------------------------


@dataclass
class LoadBlock:
    """One block of cyclic loading in a variable-amplitude history."""

    sigma_amplitude_MPa: float
    sigma_mean_MPa: float
    n_cycles: int


def miner_damage(
    blocks: Sequence[LoadBlock],
    *,
    basquin_sigma_f_prime_MPa: float,
    basquin_b: float = -0.085,
    sigma_uts_MPa: float = 800.0,
    sigma_y_MPa: float | None = None,
    mean_stress_method: MeanStressMethod = "goodman",
    walker_gamma: float = 0.5,
) -> dict:
    """Palmgren-Miner 1924/1945 linear cumulative damage rule.

    For each load block, compute the equivalent fully-reversed amplitude
    via ``mean_stress_correction``, look up N_f from the Basquin S-N curve,
    and accumulate damage D = Σ(n_i / N_f,i).

    Returns ``{"damage": D, "blocks": [...], "passed": D < 1.0,
    "remaining_life_factor": (1 - D) / 1.0}``.

    Basquin S-N: ``σ_a = σ_f' · (2N_f)^b`` ⇒  N_f = (σ_a / σ_f')^(1/b) / 2.
    For most metals b ≈ -0.05 to -0.12.

    Reference: Palmgren A., Z. VDI 68 (1924) 339; Miner M.A., J. Appl. Mech.
    12 (1945) 159.
    """
    total_damage = 0.0
    block_results: list[dict] = []

    for blk in blocks:
        sa_eq = mean_stress_correction(
            blk.sigma_amplitude_MPa, blk.sigma_mean_MPa,
            method=mean_stress_method, sigma_uts_MPa=sigma_uts_MPa,
            sigma_y_MPa=sigma_y_MPa, walker_gamma=walker_gamma,
        )
        if not _is_finite(sa_eq) or sa_eq <= 0:
            block_results.append({**blk.__dict__, "N_f": float("inf"), "damage": 0.0})
            continue

        ratio = sa_eq / max(1e-9, basquin_sigma_f_prime_MPa)
        if ratio <= 0:
            n_f = float("inf")
        else:
            n_f = 0.5 * (ratio ** (1.0 / basquin_b))

        if n_f <= 0 or not _is_finite(n_f):
            n_f = float("inf")

        d_i = blk.n_cycles / n_f if n_f > 0 else float("inf")
        total_damage += d_i
        block_results.append({**blk.__dict__, "sigma_a_eq_MPa": sa_eq,
                              "N_f": n_f, "damage": d_i})

    return {
        "damage": total_damage,
        "passed": total_damage < 1.0,
        "remaining_life_factor": max(0.0, 1.0 - total_damage),
        "blocks": block_results,
        "method": "palmgren-miner",
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_finite(x) -> bool:
    """Returns True if x is a finite number; False for None, str, NaN, Inf."""
    try:
        xf = float(x)
        return math.isfinite(xf)
    except (TypeError, ValueError):
        return False


__all__ = [
    "MeanStressMethod",
    "mean_stress_correction",
    "CriticalPlaneResult",
    "findley_critical_plane",
    "brown_miller_critical_plane",
    "wang_brown_path_factor",
    "crossland_criterion",
    "dang_van_criterion",
    "LoadBlock",
    "miner_damage",
]
