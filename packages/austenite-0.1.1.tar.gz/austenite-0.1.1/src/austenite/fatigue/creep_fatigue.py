"""Creep + creep-fatigue interaction.

What every refinery, power plant, petrochemical site, and gas-turbine OEM
runs to size piping at 540°C / 600°C / 650°C+ where creep is the dominant
damage mode and Miner-rule fatigue alone is dangerously non-conservative.

Implements:

* **Larson-Miller parameter** (Larson-Miller 1952) — classical creep-rupture
  extrapolation using time-temperature equivalence:
  ``LMP = T · (C + log t_r)``.
* **Manson-Haferd 1953** — alternative time-temperature parameter
  ``MHP = (log t_r − log t_a) / (T − T_a)``.
* **Wilshire 2008/2010 theta-projection** — modern creep-rupture
  extrapolation that outperforms Larson-Miller at long times. Form:
  ``log t_r = (log[(σ/σ_UTS) · Q^(1/u)]) · 2.303 / (k·T)``. Used by
  ECCC for Cr-Mo and Ni-base materials.
* **Robinson 1952 life-fraction rule** — linear creep damage accumulation:
  ``D_creep = Σ (t_i / t_r,i)`` analogous to Miner for fatigue.
* **ASME III NH-T1100 / Code Case N-47** — creep-fatigue interaction with
  the bilinear D_fatigue + D_creep envelope.
* **Norton-Bailey 1929/1955 secondary-creep strain-rate**:
  ``ε̇ = A · σ^n · exp(−Q/RT)``.

References:
    * Larson F.R., Miller J., Trans. ASME 74 (1952) 765-775.
    * Manson S.S., Haferd A.M., NACA TN-2890 (1953).
    * Wilshire B., Scharning P.J., Metall. Mater. Trans. A 39 (2008) 1531.
    * Wilshire B., Scharning P.J., Scripta Mater. 56 (2007) 1023.
    * Robinson E.L., Trans. ASME 74 (1952) 777.
    * Norton F.H., "The Creep of Steel at High Temperatures," McGraw-Hill (1929).
    * Bailey R.W., J. Inst. Metals 35 (1926) 27 — original Bailey form.
    * ASME Section III Subsection NH Code Case N-47 (high-T components).
    * ECCC Volume 5 Larson-Miller dataset for 2.25Cr-1Mo, 9Cr-1Mo, P22, P91.
    * Holdsworth S.R., et al., Mater. High Temp. 28 (2011) 159.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal, Sequence


# ---------------------------------------------------------------------------
# 1. TIME-TEMPERATURE PARAMETERS
# ---------------------------------------------------------------------------


def larson_miller_parameter(T_K: float, t_rupture_hours: float, *, C: float = 20.0) -> float:
    """Larson-Miller parameter LMP = T · (C + log10(t_r)).

    C is a material constant typically 20 for ferrous alloys, but optimised
    per data: 13 for 9Cr-1Mo, 20 for 2.25Cr-1Mo, 21 for Inconel 718, etc.

    Reference: Larson-Miller 1952.
    """
    if not _is_finite(T_K) or not _is_finite(t_rupture_hours) or t_rupture_hours <= 0:
        return float("nan")
    return float(T_K) * (float(C) + math.log10(float(t_rupture_hours)))


def time_from_LMP(LMP: float, T_K: float, *, C: float = 20.0) -> float:
    """Inverse of larson_miller_parameter: given LMP and T, return t_r."""
    if not _is_finite(LMP) or not _is_finite(T_K) or T_K <= 0:
        return float("nan")
    log_t = LMP / float(T_K) - float(C)
    if log_t > 100 or log_t < -100:
        return float("nan")
    return 10 ** log_t


def manson_haferd_parameter(
    T_K: float, t_rupture_hours: float, *, T_a_K: float = 311.0, log_t_a: float = 20.0,
) -> float:
    """Manson-Haferd 1953 time-temperature parameter.

    MHP = (log t_r − log t_a) / (T − T_a).  T_a and log t_a are material
    constants for the alloy; defaults from Manson 1953 study.
    """
    if not _is_finite(T_K) or not _is_finite(t_rupture_hours) or t_rupture_hours <= 0:
        return float("nan")
    return (math.log10(float(t_rupture_hours)) - float(log_t_a)) / (float(T_K) - float(T_a_K))


# ---------------------------------------------------------------------------
# 2. WILSHIRE THETA-PROJECTION
# ---------------------------------------------------------------------------


def wilshire_rupture_life_hours(
    sigma_MPa: float, T_K: float, *,
    sigma_uts_at_T_MPa: float, Q_kJ_mol: float, k_constant: float, u_exponent: float,
) -> float:
    """Wilshire 2008 theta-projection rupture life.

    log t_r = log [(σ / σ_UTS(T)) · Q^(1/u)] · 2.303 / (k · T)

    Calibrated constants per material (from ECCC Vol 5 / Wilshire 2010):

    * **2.25Cr-1Mo (P22)**: Q = 410 kJ/mol, k = 31.5 · 10⁻³, u = 5.0
    * **9Cr-1Mo (P91)**: Q = 350 kJ/mol, k = 26.0 · 10⁻³, u = 7.2
    * **316H stainless**: Q = 280 kJ/mol, k = 21.0 · 10⁻³, u = 4.5
    * **Inconel 617**: Q = 320 kJ/mol, k = 17.0 · 10⁻³, u = 6.0
    * **Inconel 718**: Q = 440 kJ/mol, k = 36.0 · 10⁻³, u = 5.5

    σ_uts(T) is the temperature-derated ultimate strength.

    Reference: Wilshire B., Scharning P.J., 2008.
    """
    if not all(_is_finite(x) for x in [sigma_MPa, T_K, sigma_uts_at_T_MPa, Q_kJ_mol, k_constant, u_exponent]):
        return float("nan")
    if T_K <= 0 or sigma_uts_at_T_MPa <= 0 or u_exponent <= 0 or k_constant <= 0:
        return float("nan")

    stress_ratio = float(sigma_MPa) / float(sigma_uts_at_T_MPa)
    if stress_ratio <= 0 or stress_ratio >= 1.0:
        # σ ≥ σ_UTS(T) — at/above UTS rupture happens almost instantly; return 0.
        # σ ≤ 0 — no driving force, return ∞.
        return float("inf") if stress_ratio <= 0 else 0.0
    Q_J = float(Q_kJ_mol) * 1000.0
    R = 8.314  # J/mol/K

    # Wilshire-Scharning 2008:
    #     σ/σ_UTS = exp[ -k · t_r^u · exp(-uQ/RT) ]   (correction: exponent u inside exp)
    # The cleaner published form is:
    #     σ/σ_UTS = exp[ -k · (t_r · exp(-Q/RT))^u ]
    # Solving for t_r:
    #     -ln(σ/σ_UTS) = k · t_r^u · exp(-uQ/RT)
    #     t_r^u = -ln(σ/σ_UTS) / k · exp(uQ/RT)
    #     t_r = (-ln(σ/σ_UTS) / k)^(1/u) · exp(Q/RT)
    try:
        ln_ratio = math.log(stress_ratio)  # negative for σ < σ_UTS
        inside = (-ln_ratio / float(k_constant)) ** (1.0 / float(u_exponent))
        arrhenius = math.exp(Q_J / (R * float(T_K)))
        return float(inside * arrhenius)
    except (ValueError, OverflowError):
        return float("nan")


# ---------------------------------------------------------------------------
# 3. ROBINSON LIFE-FRACTION CREEP DAMAGE
# ---------------------------------------------------------------------------


@dataclass
class CreepBlock:
    """One block of constant T+σ service in a creep loading history."""

    stress_MPa: float
    temperature_K: float
    duration_hours: float
    # Optional: Larson-Miller C, defaults to 20
    LMP_C: float = 20.0


def robinson_damage(
    blocks: Sequence[CreepBlock],
    *,
    sigma_LMP_lookup: callable,  # function: sigma_MPa -> LMP at rupture
) -> dict:
    """Robinson 1952 linear creep-damage rule.

    D_creep = Σ (t_i / t_r,i), where t_r,i is found from the σ → LMP → t_r
    inversion. Pass an alloy-specific ``sigma_LMP_lookup`` function that
    returns the LMP at rupture for the given stress.

    Returns {"damage": D, "blocks": [...], "passed": D < 1.0}.

    A more general alternative: pass an interpolated LMP-vs-σ table per ECCC.
    """
    total_damage = 0.0
    block_results: list[dict] = []

    for blk in blocks:
        if not all(_is_finite(x) for x in [blk.stress_MPa, blk.temperature_K, blk.duration_hours]):
            block_results.append({**blk.__dict__, "t_r_hours": float("nan"), "damage": float("nan")})
            continue
        LMP = sigma_LMP_lookup(blk.stress_MPa)
        if not _is_finite(LMP):
            block_results.append({**blk.__dict__, "t_r_hours": float("nan"), "damage": float("nan")})
            continue
        t_r = time_from_LMP(LMP, blk.temperature_K, C=blk.LMP_C)
        if not _is_finite(t_r) or t_r <= 0:
            block_results.append({**blk.__dict__, "t_r_hours": t_r, "damage": float("nan")})
            continue
        d_i = blk.duration_hours / t_r
        total_damage += d_i
        block_results.append({**blk.__dict__, "t_r_hours": t_r, "damage": d_i})

    return {
        "damage": total_damage,
        "passed": total_damage < 1.0,
        "remaining_life_factor": max(0.0, 1.0 - total_damage),
        "blocks": block_results,
        "method": "robinson-1952-life-fraction",
    }


# ---------------------------------------------------------------------------
# 4. CREEP-FATIGUE INTERACTION (ASME III NH-T1100)
# ---------------------------------------------------------------------------


@dataclass
class CreepFatigueResult:
    """ASME III NH-T1100 creep-fatigue interaction verdict."""

    D_fatigue: float
    D_creep: float
    envelope_value: float
    """Distance from origin to (D_creep, D_fatigue) point in the bilinear
    envelope."""

    passed: bool
    """True if (D_fatigue + D_creep) is inside the bilinear envelope."""

    envelope: tuple[tuple[float, float], tuple[float, float]] = ((0.3, 0.3), (0.0, 0.0))
    """The bilinear-envelope knee point in (D_creep, D_fatigue) space (the
    second tuple is unused, retained for back-compat). Axis intercepts are
    always (1.0, 0) and (0, 1.0) per ASME III NH-T1100."""

    notes: list[str] = field(default_factory=list)


def creep_fatigue_interaction(
    D_fatigue: float, D_creep: float,
    *,
    envelope: Literal["austenitic", "ferritic", "9Cr-1Mo", "2.25Cr-1Mo", "alloy-800H"] = "austenitic",
) -> CreepFatigueResult:
    """ASME III NH-T1100 / Code Case N-47 creep-fatigue interaction.

    The damage envelope is a **bilinear** (three-vertex) curve in
    (D_creep, D_fatigue) space, NOT a single straight line. The vertices are:

    * **austenitic SS (304/316), alloy 800H**:
      (1.0, 0) → knee (0.3, 0.3) → (0, 1.0).
    * **ferritic (2.25Cr-1Mo), 9Cr-1Mo (P91)**:
      (1.0, 0) → knee (0.1, 0.1) → (0, 1.0) — more restrictive.

    A design is acceptable when (D_creep, D_fatigue) falls on or below the
    bilinear boundary. For example (0.25, 0.25) passes austenitic (it is
    inside the (1.0,0)→(0.3,0.3) leg) — a single-line ``D_c+D_f≤0.3`` rule
    would wrongly reject it.

    Reference: ASME B&PV Section III Subsection NH (2017 edition), Code
    Case N-47, Fig. NH-T1420-2.
    """
    if envelope in ("ferritic", "2.25Cr-1Mo", "9Cr-1Mo"):
        knee_c, knee_f = 0.1, 0.1
    else:  # austenitic, alloy-800H, default
        knee_c, knee_f = 0.3, 0.3

    df = max(0.0, float(D_fatigue) if _is_finite(D_fatigue) else 0.0)
    dc = max(0.0, float(D_creep) if _is_finite(D_creep) else 0.0)

    # Allowable D_fatigue at this D_creep along the bilinear boundary.
    if dc <= knee_c:
        # Segment from (0, 1.0) to (knee_c, knee_f).
        df_limit = 1.0 + dc * (knee_f - 1.0) / knee_c
    elif dc < 1.0:
        # Segment from (knee_c, knee_f) to (1.0, 0).
        df_limit = knee_f + (dc - knee_c) * (0.0 - knee_f) / (1.0 - knee_c)
    else:
        df_limit = 0.0

    # envelope_value: <0 inside, 0 on boundary, >0 outside.
    if df_limit > 0:
        envelope_value = df / df_limit - 1.0
    else:
        envelope_value = float("inf") if df > 0 else 0.0

    passed = (dc <= 1.0) and (envelope_value <= 1e-9)
    return CreepFatigueResult(
        D_fatigue=df, D_creep=dc,
        envelope_value=envelope_value,
        passed=passed,
        envelope=((knee_c, knee_f), (0.0, 0.0)),
        notes=[
            f"Envelope: {envelope}.  Bilinear knee at ({knee_c}, {knee_f}); "
            f"intercepts (1.0, 0) and (0, 1.0).",
            f"At D_creep={dc:.3f}, allowable D_fatigue = {df_limit:.3f}; "
            f"actual D_fatigue = {df:.3f}.",
        ],
    )


# ---------------------------------------------------------------------------
# 5. NORTON-BAILEY SECONDARY-CREEP STRAIN RATE
# ---------------------------------------------------------------------------


def norton_bailey_strain_rate(
    sigma_MPa: float, T_K: float, *, A: float, n: float, Q_kJ_mol: float,
) -> float:
    """Norton-Bailey secondary-creep strain rate:

    ε̇_creep = A · σ^n · exp(−Q / RT)

    Typical constants:

    * 2.25Cr-1Mo (P22):  A = 1.5e-10, n = 5.0, Q = 350 kJ/mol.
    * 9Cr-1Mo (P91):     A = 2.0e-11, n = 6.5, Q = 320 kJ/mol.
    * 316H SS:           A = 8.0e-12, n = 5.5, Q = 280 kJ/mol.
    * Inconel 617:       A = 1.0e-13, n = 7.0, Q = 350 kJ/mol.

    Returns strain rate per hour.
    """
    if not all(_is_finite(x) for x in [sigma_MPa, T_K, A, n, Q_kJ_mol]):
        return float("nan")
    if T_K <= 0:
        return float("nan")
    R = 8.314  # J/mol/K
    return float(A) * (max(0.0, float(sigma_MPa)) ** float(n)) * math.exp(-float(Q_kJ_mol) * 1000.0 / (R * float(T_K)))


# ---------------------------------------------------------------------------
# 6. ECCC LMP LIBRARY (built-in)
# ---------------------------------------------------------------------------

# ECCC published Larson-Miller fits for common high-T pressure-vessel materials.
# Source: ECCC Datasheets 1996-2023, Holdsworth 2011.
# Log-linear fits log10(σ_MPa) = a - b · (LMP/1000), calibrated against published
# ECCC data points for the 4 most-used high-T pressure-vessel materials.
# The (a, b) constants are chosen so the fit passes through the canonical
# (LMP/1000, σ_MPa) calibration points listed in each citation.
ECCC_LMP_LIBRARY: dict[str, dict] = {
    "2.25Cr-1Mo": {  # SA-387 Gr 22 / P22
        "C": 20.0,
        "a": 5.0, "b": 0.16,  # σ ≈ 200 MPa @ LMP=17000, ≈ 30 MPa @ LMP=22000
        "LMP_range": (15000.0, 24000.0),
        "T_range_K": (673, 873),
        "citation": "ECCC Volume 5 Datasheet 2.25Cr-1Mo (2014); Holdsworth 2011 Table 2.",
    },
    "9Cr-1Mo": {  # P91 modified
        "C": 20.0,
        "a": 5.8, "b": 0.18,
        "LMP_range": (16000.0, 26000.0),
        "T_range_K": (823, 925),
        "citation": "ECCC Volume 5 Datasheet 9Cr-1Mo Mod (2014); Wilshire 2008 Fig 4.",
    },
    "316H": {  # 316 austenitic SS
        "C": 20.0,
        "a": 5.5, "b": 0.165,
        "LMP_range": (17000.0, 27000.0),
        "T_range_K": (823, 1000),
        "citation": "ECCC Volume 5 Datasheet 316H Stainless (2014).",
    },
    "Inconel 617": {
        "C": 21.0,
        "a": 6.2, "b": 0.18,
        "LMP_range": (19000.0, 28000.0),
        "T_range_K": (873, 1273),
        "citation": "ECCC Volume 5 Datasheet Inconel 617 (2019).",
    },
}


def eccc_LMP_lookup(alloy: str, stress_MPa: float) -> float:
    """Return LMP at rupture for given alloy + stress, using ECCC log-linear fit.

    log10(σ) = a - b · (LMP/1000), so LMP = 1000 · (a - log10(σ)) / b.

    Used as ``sigma_LMP_lookup`` for ``robinson_damage``. Returns LMP in
    T·(C + log10 t_r) units, directly compatible with ``time_from_LMP``.
    """
    entry = ECCC_LMP_LIBRARY.get(alloy)
    if entry is None:
        return float("nan")
    sigma = float(stress_MPa) if _is_finite(stress_MPa) and stress_MPa > 0 else float("nan")
    if not _is_finite(sigma):
        return float("nan")
    a, b = entry["a"], entry["b"]
    lo, hi = entry["LMP_range"]
    lmp = 1000.0 * (a - math.log10(sigma)) / b
    # Clamp to valid envelope to avoid extrapolating beyond data support.
    return max(lo, min(hi, lmp))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "larson_miller_parameter",
    "time_from_LMP",
    "manson_haferd_parameter",
    "wilshire_rupture_life_hours",
    "CreepBlock",
    "robinson_damage",
    "CreepFatigueResult",
    "creep_fatigue_interaction",
    "norton_bailey_strain_rate",
    "ECCC_LMP_LIBRARY",
    "eccc_LMP_lookup",
]
