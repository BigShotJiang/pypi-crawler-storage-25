"""Fatigue / creep / S-N sub-package.

Production-grade fatigue suite covering uniaxial S-N, notched strain-life,
multi-axial critical-plane, and creep + creep-fatigue interaction. Closes
the 4 single biggest gaps in open-source materials fatigue:

* ~90 % of structural failures initiate at notches → ``notched``.
* Most real loadings are multi-axial → ``multiaxial``.
* Every refinery/power-plant uses creep + creep-fatigue → ``creep_fatigue``.
* Generic S-N curves don't match shop-specific batches → ``heat_specific``.

Public API examples::

    import austenite as au

    # Notched strain-life (Neuber rule)
    r = au.fatigue.neuber_rule(
        sigma_nominal_amplitude_MPa=120, sigma_nominal_mean_MPa=80,
        K_t=2.5, E_GPa=207,
        cyclic_K_prime_MPa=1240, cyclic_n_prime=0.13,
        sigma_f_prime_MPa=1100, basquin_b=-0.08,
        epsilon_f_prime=0.30, coffin_manson_c=-0.55,
    )
    print(r.N_f)              # predicted cycles to failure

    # Multi-axial critical-plane (Findley)
    cp = au.fatigue.findley_critical_plane(
        sigma_xx_amplitude_MPa=120, sigma_xx_mean_MPa=80,
        tau_xy_amplitude_MPa=60, findley_k=0.3,
    )
    print(cp.theta_deg, cp.damage_parameter)

    # Creep-fatigue interaction (ASME III NH-T1100)
    v = au.fatigue.creep_fatigue_interaction(
        D_fatigue=0.15, D_creep=0.10, envelope="austenitic",
    )
    print(v.passed, v.envelope_value)

References:
    * Basquin O.H., Proc. ASTM 10 (1910) 625.
    * Neuber H., J. Appl. Mech. 28 (1961) 544.
    * Glinka G., Eng. Fract. Mech. 22 (1985) 839.
    * Findley W., J. Eng. Ind. 81 (1959) 301.
    * Brown M.W., Miller K.J., Proc. Inst. Mech. Eng. 187 (1973) 745.
    * Dang Van K., ASTM STP 1191 (1989) 21.
    * Larson F.R., Miller J., Trans. ASME 74 (1952) 765.
    * Wilshire B., Scharning P.J., Metall. Mater. Trans. A 39 (2008) 1531.
    * Robinson E.L., Trans. ASME 74 (1952) 777.
    * ASME B&PV Section III Subsection NH (2017).
    * ECCC Volume 5 Datasheets (2014).
    * Haario H., Laine M., Mira A., Saksman E., Stat. Comput. 16 (2006) 339.
    * Brooks S.P., Gelman A., J. Comput. Graph. Stat. 7 (1998) 434.
"""

from __future__ import annotations

from .heat_specific import (
    BasquinCurve,
    HeatSpecificSNFit,
    MMPDSPrior,
    heat_specific_sn_fit,
    list_pretrained_priors,
)
from .multiaxial import (
    CriticalPlaneResult,
    LoadBlock,
    MeanStressMethod,
    brown_miller_critical_plane,
    crossland_criterion,
    dang_van_criterion,
    findley_critical_plane,
    mean_stress_correction,
    miner_damage,
    wang_brown_path_factor,
)
from .notched import (
    NotchedStrainLifeResult,
    glinka_rule,
    kf_from_kt,
    neuber_rule,
    topper_rule,
)
from .creep_fatigue import (
    CreepBlock,
    CreepFatigueResult,
    ECCC_LMP_LIBRARY,
    creep_fatigue_interaction,
    eccc_LMP_lookup,
    larson_miller_parameter,
    manson_haferd_parameter,
    norton_bailey_strain_rate,
    robinson_damage,
    time_from_LMP,
    wilshire_rupture_life_hours,
)

__all__ = [
    # Heat-specific Bayesian
    "BasquinCurve",
    "HeatSpecificSNFit",
    "MMPDSPrior",
    "heat_specific_sn_fit",
    "list_pretrained_priors",
    # Mean-stress + multi-axial
    "MeanStressMethod",
    "mean_stress_correction",
    "CriticalPlaneResult",
    "findley_critical_plane",
    "brown_miller_critical_plane",
    "wang_brown_path_factor",
    "crossland_criterion",
    "dang_van_criterion",
    "LoadBlock",
    "miner_damage",
    # Notched
    "NotchedStrainLifeResult",
    "neuber_rule",
    "glinka_rule",
    "topper_rule",
    "kf_from_kt",
    # Creep + creep-fatigue
    "larson_miller_parameter",
    "time_from_LMP",
    "manson_haferd_parameter",
    "wilshire_rupture_life_hours",
    "CreepBlock",
    "robinson_damage",
    "CreepFatigueResult",
    "creep_fatigue_interaction",
    "norton_bailey_strain_rate",
    "ECCC_LMP_LIBRARY",
    "eccc_LMP_lookup",
]
