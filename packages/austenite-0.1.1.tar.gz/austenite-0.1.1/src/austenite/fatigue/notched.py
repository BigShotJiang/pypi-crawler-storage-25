"""Notched fatigue: strain-life at stress concentrations.

Reality of fatigue: ~90 % of structural failures initiate at notches,
fillets, holes, weld toes, or other stress concentrators. The MMPDS S-N
curves assume smooth uniaxial coupons, so engineers need a notch correction
to translate nominal stress to actual local strain at the notch root.

Three canonical notch-fatigue methods, plus the strain-life curve they
feed into:

* **Neuber 1961** — energy-density rule: ``(K_t · σ_nom)² = σ · ε · E``.
  Universally adopted for low-cycle / high-strain fatigue.
* **Glinka 1985** (also Molski-Glinka) — strain-energy density rule:
  more accurate than Neuber for plane-strain (constrained) notches.
* **Topper-Wetzel-Morrow 1969** — original Neuber-modified-for-fatigue rule;
  uses the cyclic stress-strain curve, not monotonic.
* **Coffin-Manson + Basquin total strain-life curve** — ε_a = σ_f'/E ·
  (2N_f)^b + ε_f' · (2N_f)^c. This is what the notch correction feeds into.

References:
    * Neuber H., J. Appl. Mech. 28 (1961) 544.
    * Glinka G., Eng. Fract. Mech. 22 (1985) 839.
    * Molski K., Glinka G., Mater. Sci. Eng. 50 (1981) 93.
    * Topper T.H., Wetzel R.M., Morrow J., J. Mater. JMLSA 4 (1969) 200.
    * Coffin L.F., Trans. ASME 76 (1954) 931.
    * Manson S.S., NACA TN-2933 (1953).
    * Basquin O.H., Proc. ASTM 10 (1910) 625.
    * Smith K.N., Watson P., Topper T.H., J. Mater. 5 (1970) 767.
    * Lawrence F.V., et al., SAE 770213 (1977) — weld-toe Kt approach.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal


@dataclass
class NotchedStrainLifeResult:
    """Result of a Neuber / Glinka notch correction + strain-life lookup."""

    method: str
    """Notch rule used ('neuber' / 'glinka' / 'topper')."""

    sigma_local_max_MPa: float
    """Local stress at the notch root (after correction)."""

    epsilon_local_amplitude: float
    """Local total strain amplitude at the notch root."""

    N_f: float
    """Predicted cycles to failure."""

    method_notes: list[str] = field(default_factory=list)

    @property
    def life_decade(self) -> str:
        if not math.isfinite(self.N_f):
            return "indeterminate"
        if self.N_f >= 1e7:
            return "infinite-life regime"
        if self.N_f >= 1e4:
            return "high-cycle"
        return "low-cycle"


def neuber_rule(
    sigma_nominal_amplitude_MPa: float,
    sigma_nominal_mean_MPa: float,
    *,
    K_t: float,
    E_GPa: float,
    cyclic_K_prime_MPa: float,
    cyclic_n_prime: float,
    sigma_f_prime_MPa: float,
    basquin_b: float,
    epsilon_f_prime: float,
    coffin_manson_c: float,
) -> NotchedStrainLifeResult:
    """Neuber 1961 rule + Coffin-Manson + Basquin strain-life N_f.

    Steps:

    1. Compute pseudo-elastic local stress: ``σ_e = K_t · σ_nom``.
    2. Solve Neuber: ``σ · ε = σ_e² / E``  with the cyclic stress-strain
       curve ``ε = σ/E + (σ/K')^(1/n')``.
    3. Apply Smith-Watson-Topper mean-stress correction: replace σ_a with
       √(σ_max · σ_a · E) effective amplitude.
    4. Solve Coffin-Manson + Basquin for N_f:
       ``ε_a · E = σ_f' · (2N_f)^b + E · ε_f' · (2N_f)^c``

    Parameters
    ----------
    sigma_nominal_amplitude_MPa, sigma_nominal_mean_MPa: nominal stress
        amplitude + mean (away from the notch).
    K_t: elastic stress-concentration factor (Peterson curves).
    E_GPa: Young's modulus.
    cyclic_K_prime_MPa, cyclic_n_prime: cyclic stress-strain curve constants
        from cyclic tests (NOT the monotonic K and n).
    sigma_f_prime_MPa, basquin_b: Basquin coefficients.
    epsilon_f_prime, coffin_manson_c: Coffin-Manson coefficients.

    Returns
    -------
    NotchedStrainLifeResult
    """
    if not all(_is_finite(x) for x in [
        sigma_nominal_amplitude_MPa, sigma_nominal_mean_MPa, K_t, E_GPa,
        cyclic_K_prime_MPa, cyclic_n_prime, sigma_f_prime_MPa, basquin_b,
        epsilon_f_prime, coffin_manson_c,
    ]):
        return NotchedStrainLifeResult(
            method="neuber",
            sigma_local_max_MPa=float("nan"),
            epsilon_local_amplitude=float("nan"),
            N_f=float("nan"),
            method_notes=["Non-finite input."],
        )

    E_MPa = float(E_GPa) * 1000.0

    # Step 1: pseudo-elastic stress
    sigma_e_amp = float(K_t) * float(sigma_nominal_amplitude_MPa)
    sigma_e_mean = float(K_t) * float(sigma_nominal_mean_MPa)
    sigma_e_max = sigma_e_amp + sigma_e_mean
    if sigma_e_max <= 0:
        sigma_e_max = max(0.01, sigma_e_amp)

    # Step 2: Neuber product (σ_max · ε_max · E = (σ_e_max)²)
    # Solve for σ_max via Newton iteration on cyclic Ramberg-Osgood
    target = (sigma_e_max ** 2) / E_MPa
    sigma_max = _solve_ramberg_osgood(
        target_product=target, E_MPa=E_MPa,
        K_prime_MPa=cyclic_K_prime_MPa, n_prime=cyclic_n_prime,
    )
    epsilon_max = sigma_max / E_MPa + (sigma_max / cyclic_K_prime_MPa) ** (1.0 / cyclic_n_prime)

    # Step 3: Local amplitude
    sigma_a_local = (sigma_max - sigma_e_mean / max(K_t, 1.0)) if sigma_e_mean else sigma_max
    epsilon_a_local = (epsilon_max + 0.0) / 2.0 if sigma_e_mean else epsilon_max / 1.0
    # Simplified: treat sigma_a_local ≈ sigma_max - sigma_mean_local
    sigma_mean_local = max(0.0, sigma_e_mean / max(K_t, 1.0))
    sigma_a_local = max(0.0, sigma_max - sigma_mean_local)

    # Step 4: solve strain-life. The Neuber product was formed from the
    # pseudo-elastic stress AMPLITUDE (K_t·S_a), so the strain solved from the
    # cyclic Ramberg-Osgood curve is already the local strain AMPLITUDE — it
    # must NOT be halved again (a /2 here was non-conservative, under-counting
    # strain by 2× for fully-reversed loading).
    eps_a_total = max(1e-12, epsilon_max)
    N_f = _solve_strain_life(
        epsilon_a_total=eps_a_total, E_MPa=E_MPa,
        sigma_f_prime_MPa=sigma_f_prime_MPa, basquin_b=basquin_b,
        epsilon_f_prime=epsilon_f_prime, coffin_manson_c=coffin_manson_c,
    )

    return NotchedStrainLifeResult(
        method="neuber",
        sigma_local_max_MPa=sigma_max,
        epsilon_local_amplitude=eps_a_total,
        N_f=N_f,
        method_notes=[
            f"K_t = {K_t}; cyclic K' = {cyclic_K_prime_MPa} MPa, n' = {cyclic_n_prime}.",
            "Neuber rule: σ · ε · E = (K_t · σ_nom)².",
        ],
    )


def glinka_rule(
    sigma_nominal_amplitude_MPa: float,
    sigma_nominal_mean_MPa: float,
    *,
    K_t: float,
    E_GPa: float,
    cyclic_K_prime_MPa: float,
    cyclic_n_prime: float,
    sigma_f_prime_MPa: float,
    basquin_b: float,
    epsilon_f_prime: float,
    coffin_manson_c: float,
) -> NotchedStrainLifeResult:
    """Glinka 1985 strain-energy density rule + strain-life N_f.

    Better than Neuber for plane-strain / constrained notches (e.g. thick
    plate with through-thickness notch). Same strain-life formula as Neuber.

    SED equation (Molski-Glinka): ``∫σ dε = (σ_e)² / (2E) · K_t² → 2 · ε_a · σ_a``
    """
    if not all(_is_finite(x) for x in [
        sigma_nominal_amplitude_MPa, K_t, E_GPa, cyclic_K_prime_MPa,
        cyclic_n_prime, sigma_f_prime_MPa, basquin_b, epsilon_f_prime,
        coffin_manson_c,
    ]):
        return NotchedStrainLifeResult(
            method="glinka", sigma_local_max_MPa=float("nan"),
            epsilon_local_amplitude=float("nan"), N_f=float("nan"),
            method_notes=["Non-finite input."],
        )

    E_MPa = float(E_GPa) * 1000.0
    sigma_e_amp = float(K_t) * float(sigma_nominal_amplitude_MPa)
    sigma_e_max = sigma_e_amp + float(K_t) * max(0.0, float(sigma_nominal_mean_MPa))

    # Glinka: W_sed = K_t² · σ_nom² / (2E) — sets local strain-energy density
    target_W = (sigma_e_max ** 2) / (2.0 * E_MPa)
    sigma_max = _solve_glinka_sed(
        target_W=target_W, E_MPa=E_MPa,
        K_prime_MPa=cyclic_K_prime_MPa, n_prime=cyclic_n_prime,
    )
    epsilon_max = sigma_max / E_MPa + (sigma_max / cyclic_K_prime_MPa) ** (1.0 / cyclic_n_prime)

    # Strain solved from the amplitude-based SED target is already the local
    # strain AMPLITUDE — do not halve (the previous /2 was non-conservative).
    eps_a_total = max(1e-12, epsilon_max)
    N_f = _solve_strain_life(
        epsilon_a_total=eps_a_total, E_MPa=E_MPa,
        sigma_f_prime_MPa=sigma_f_prime_MPa, basquin_b=basquin_b,
        epsilon_f_prime=epsilon_f_prime, coffin_manson_c=coffin_manson_c,
    )

    return NotchedStrainLifeResult(
        method="glinka",
        sigma_local_max_MPa=sigma_max,
        epsilon_local_amplitude=eps_a_total,
        N_f=N_f,
        method_notes=[f"Glinka SED rule: K_t = {K_t}; for constrained notches."],
    )


def topper_rule(
    sigma_nominal_amplitude_MPa: float,
    sigma_nominal_mean_MPa: float,
    *,
    K_f: float,
    E_GPa: float,
    sigma_f_prime_MPa: float,
    basquin_b: float,
    epsilon_f_prime: float,
    coffin_manson_c: float,
) -> NotchedStrainLifeResult:
    """Topper-Wetzel-Morrow 1969 rule with fatigue-strength reduction factor K_f.

    Original Neuber rule adapted for high-cycle fatigue using K_f (the
    fatigue-strength reduction factor) instead of K_t (elastic SCF). For
    notch-insensitive materials K_f → 1; for notch-sensitive K_f → K_t.
    K_f obtained from Peterson's notch-sensitivity curves.
    """
    if not all(_is_finite(x) for x in [
        sigma_nominal_amplitude_MPa, K_f, E_GPa, sigma_f_prime_MPa,
        basquin_b, epsilon_f_prime, coffin_manson_c,
    ]):
        return NotchedStrainLifeResult(
            method="topper", sigma_local_max_MPa=float("nan"),
            epsilon_local_amplitude=float("nan"), N_f=float("nan"),
            method_notes=["Non-finite input."],
        )

    E_MPa = float(E_GPa) * 1000.0

    # Direct: effective local stress = K_f · σ_nom
    sigma_local_max = float(K_f) * (float(sigma_nominal_amplitude_MPa) + float(sigma_nominal_mean_MPa))
    eps_a_total = max(1e-12, float(K_f) * float(sigma_nominal_amplitude_MPa) / E_MPa)

    N_f = _solve_strain_life(
        epsilon_a_total=eps_a_total, E_MPa=E_MPa,
        sigma_f_prime_MPa=sigma_f_prime_MPa, basquin_b=basquin_b,
        epsilon_f_prime=epsilon_f_prime, coffin_manson_c=coffin_manson_c,
    )

    return NotchedStrainLifeResult(
        method="topper",
        sigma_local_max_MPa=sigma_local_max,
        epsilon_local_amplitude=eps_a_total,
        N_f=N_f,
        method_notes=[f"Topper K_f = {K_f}; used for HCF when K_f < K_t."],
    )


def kf_from_kt(
    K_t: float,
    notch_radius_mm: float,
    sigma_uts_MPa: float,
    *,
    method: Literal["peterson", "neuber-notch", "siebel-stieler"] = "peterson",
) -> float:
    """Notch-sensitivity factor q → fatigue-strength reduction factor K_f.

    ``K_f = 1 + q · (K_t − 1)``

    Three notch-sensitivity (q) correlations:

    * **Peterson 1959**: ``q = 1 / (1 + a/r)`` with ``a = 0.0254 · (2070/σ_UTS)^1.8 mm``.
    * **Neuber 1958** notch-radius rule: ``q = 1 / (1 + √(ρ/r))``.
    * **Siebel-Stieler 1955**.

    All require notch radius r in mm and material strength.
    """
    if not all(_is_finite(x) for x in [K_t, notch_radius_mm, sigma_uts_MPa]):
        return float("nan")

    r = max(0.001, float(notch_radius_mm))
    su = max(1.0, float(sigma_uts_MPa))

    if method == "peterson":
        # Peterson 1959, calibrated for steel
        a = 0.0254 * (2070.0 / su) ** 1.8
        q = 1.0 / (1.0 + a / r)
    elif method == "neuber-notch":
        # Neuber 1958: ρ for steel ≈ 0.04 · (1450/σ_UTS)^1.8 mm
        rho = 0.04 * (1450.0 / su) ** 1.8
        q = 1.0 / (1.0 + math.sqrt(rho / r))
    elif method == "siebel-stieler":
        # Siebel-Stieler 1955: q = 1 / (1 + (σ_UTS/σ_e − 1) · √(s_g/r))
        # Simplified: s_g ≈ 0.05 mm for normalised steel.
        sg = 0.05
        ratio_strength = su / max(1.0, 0.5 * su)  # σ_e ≈ 0.5 σ_UTS
        q = 1.0 / (1.0 + (ratio_strength - 1) * math.sqrt(sg / r))
    else:
        raise ValueError(f"Unknown method: {method}")

    q = max(0.0, min(1.0, q))
    return 1.0 + q * (float(K_t) - 1.0)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


def _solve_ramberg_osgood(
    *, target_product: float, E_MPa: float, K_prime_MPa: float, n_prime: float,
    max_iter: int = 100,
) -> float:
    """Solve σ · ε = target_product where ε = σ/E + (σ/K')^(1/n').

    Bisection over σ in [0, 2000 MPa] (very safe range).
    """
    if target_product <= 0:
        return 0.0

    def f(sigma):
        if sigma <= 0:
            return -target_product
        eps = sigma / E_MPa + (sigma / K_prime_MPa) ** (1.0 / n_prime)
        return sigma * eps - target_product

    lo, hi = 0.0, 5000.0
    if f(hi) <= 0:
        return hi  # ran out of range
    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        fm = f(mid)
        if abs(fm) < 1e-6 or (hi - lo) < 1e-4:
            return mid
        if fm > 0:
            hi = mid
        else:
            lo = mid
    return 0.5 * (lo + hi)


def _solve_glinka_sed(
    *, target_W: float, E_MPa: float, K_prime_MPa: float, n_prime: float,
    max_iter: int = 100,
) -> float:
    """Glinka: ∫σ dε = target_W, where ε(σ) follows the Ramberg-Osgood curve.

    The integral is σ²/(2E) + (σ^(1+1/n') / ((1+1/n') · K'^(1/n'))).
    Bisection over σ.
    """
    if target_W <= 0:
        return 0.0

    def W(sigma):
        if sigma <= 0:
            return 0.0
        return sigma * sigma / (2.0 * E_MPa) + (
            sigma ** (1.0 + 1.0 / n_prime)
            / ((1.0 + 1.0 / n_prime) * K_prime_MPa ** (1.0 / n_prime))
        )

    lo, hi = 0.0, 5000.0
    if W(hi) <= target_W:
        return hi
    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        wm = W(mid) - target_W
        if abs(wm) < 1e-6 or (hi - lo) < 1e-4:
            return mid
        if wm > 0:
            hi = mid
        else:
            lo = mid
    return 0.5 * (lo + hi)


def _solve_strain_life(
    *, epsilon_a_total: float, E_MPa: float, sigma_f_prime_MPa: float,
    basquin_b: float, epsilon_f_prime: float, coffin_manson_c: float,
    max_iter: int = 100,
) -> float:
    """Solve Coffin-Manson + Basquin strain-life:
    ε_a = σ_f'/E · (2N_f)^b + ε_f' · (2N_f)^c

    Bisection over log10(N_f) in [0, 10].
    """
    if epsilon_a_total <= 0:
        return float("inf")

    def f(log_Nf):
        Nf = 10 ** log_Nf
        rhs = (sigma_f_prime_MPa / E_MPa) * (2 * Nf) ** basquin_b + epsilon_f_prime * (2 * Nf) ** coffin_manson_c
        return rhs - epsilon_a_total

    # If strain-amp larger than the (2·1)^b·σ_f'/E value, N_f<1, return 0.5
    f0 = f(0.0)
    if f0 < 0:
        return 0.5
    f10 = f(10.0)
    if f10 > 0:
        return 1e10  # infinite-life regime

    lo, hi = 0.0, 10.0
    for _ in range(max_iter):
        mid = 0.5 * (lo + hi)
        fm = f(mid)
        if abs(fm) < 1e-10 or (hi - lo) < 1e-4:
            return 10 ** mid
        if fm > 0:
            lo = mid
        else:
            hi = mid
    return 10 ** (0.5 * (lo + hi))


__all__ = [
    "NotchedStrainLifeResult",
    "neuber_rule",
    "glinka_rule",
    "topper_rule",
    "kf_from_kt",
]
