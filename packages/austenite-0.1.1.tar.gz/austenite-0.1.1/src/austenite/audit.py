"""Audit recording, persistence, and bit-exact replay — moat 6.

This module solves the reproducibility crisis (Tribello & Ceriotti 2022,
arXiv:2202.04915) as a side-effect of running compliance calculations.

Five public operations::

    result = au.design_path(alloy="AISI 4140", cooling_rate=10, posterior=True)

    rec = au.audit.record(result)
    au.audit.save(rec, "calc.json")

    # 6 years from now
    rec = au.audit.load("calc.json")
    result_then = au.audit.replay(rec, engine_version="0.1.0", deterministic=True)
    rep = au.audit.verify(rec)
    assert rep.hash_matches

The bit-exact guarantee:

  * Numbers in the canonical form are rounded to 12 significant figures so
    that platform-level math drift (x87 vs SSE2 vs FMA, libm-version
    differences) cannot perturb the hash.
  * Object key order is normalized.
  * NaN / ±Infinity are represented as sentinel strings.
  * The deterministic flag pins a fixed RNG seed inside the engine for
    stochastic ops (MCMC, Monte-Carlo).

The hash sits on disk alongside the record. Verification re-canonicalizes
the original_result + recomputes the hash; replay re-runs the call
through the API (with a version-pin guard) and checks the new result
hashes to the same digest.

Backwards-compatibility:

  * The old server-side log functions ``record(*, call_id, endpoint,
    payload, result)`` and ``replay(audit_id="...")`` still exist — same
    signatures, same return types. They're now opt-in: pass keyword args
    ``call_id`` / ``endpoint`` for the old behaviour, or pass a single
    positional argument for the new local-record API.

References:
  Tribello, G.A. & Ceriotti, M. "Using machine learning to address the
    reproducibility crisis in computational chemistry"
    arXiv:2202.04915 (2022). DOI: 10.48550/arXiv.2202.04915.
"""

from __future__ import annotations

import json
import os
import platform
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Optional, Union

from ._audit_hash import canonical_json, canonicalize, hash_record
from ._client import get_default_client
from ._exceptions import AusteniteError, ValidationError
from ._models import (
    AuditRecordInput,
    AuditRecordResult,
    AuditReplayInput,
    AuditReplayResult,
)


__all__ = [
    "record",
    "save",
    "load",
    "replay",
    "verify",
    "VerifyReport",
    "ReplayMismatchError",
    # Legacy re-exports for compat with v0.1 docs.
    "AuditRecordResult",
    "AuditReplayResult",
]


def _get_engine_version() -> str:
    """Read engine version lazily — avoids circular import at module load."""

    from . import __version__

    return __version__


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class ReplayMismatchError(AusteniteError):
    """Raised when a replay can't safely run under the current engine.

    Distinct from a successful replay that produces a different hash —
    that's surfaced via :class:`VerifyReport` so the caller can decide
    whether the divergence is engineering-meaningful.
    """


# ---------------------------------------------------------------------------
# Endpoint → API caller registry
# ---------------------------------------------------------------------------
#
# When ``replay()`` re-executes a record locally, it dispatches by the
# endpoint name baked into the record. New endpoints register themselves
# here; lazy-imports avoid circular-imports at module load.


def _replay_design_path(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    from .design_path import design_path

    result = design_path(**dict(payload))
    return result.model_dump()


def _replay_compliance_bayesian_p_pass(payload: Mapping[str, Any]) -> Mapping[str, Any]:
    from .compliance import bayesian_p_pass

    result = bayesian_p_pass(**dict(payload))
    return result.model_dump()


# Map endpoint id (mirrors the API route) → local re-runner.
_ENDPOINT_REPLAYERS: dict[str, Any] = {
    "/v1/design-path": _replay_design_path,
    "design_path": _replay_design_path,
    "/v1/compliance-bayesian-p-pass": _replay_compliance_bayesian_p_pass,
    "compliance_bayesian_p_pass": _replay_compliance_bayesian_p_pass,
}


# ---------------------------------------------------------------------------
# Record extraction
# ---------------------------------------------------------------------------


def _extract_input(result_obj: Any) -> dict[str, Any]:
    """Pull the original input payload out of a result object.

    Pydantic ``_BaseOutput`` models keep extras, so we look for common
    ``request`` / ``input`` fields first, then fall back to whatever the
    object stored under ``_audit_input``. Returns ``{}`` if nothing
    serializable is found — record is still valid, just opaque on replay.
    """

    if isinstance(result_obj, Mapping):
        for k in ("input", "request", "payload"):
            v = result_obj.get(k)
            if isinstance(v, Mapping):
                return dict(v)
        return {}

    # Pydantic model
    if hasattr(result_obj, "model_dump"):
        dumped = result_obj.model_dump()
        for k in ("input", "request", "payload"):
            v = dumped.get(k)
            if isinstance(v, Mapping):
                return dict(v)
    # Look for a manual side-channel attribute we set during a wrapped run.
    if hasattr(result_obj, "_audit_input") and isinstance(
        result_obj._audit_input, Mapping
    ):
        return dict(result_obj._audit_input)
    return {}


def _result_to_dict(result_obj: Any) -> dict[str, Any]:
    """Coerce a Pydantic / dict / mapping result into a dict."""

    if isinstance(result_obj, Mapping):
        return dict(result_obj)
    if hasattr(result_obj, "model_dump"):
        return result_obj.model_dump()
    raise TypeError(
        f"Cannot record an audit on {type(result_obj).__name__}; "
        "expected a dict or a Pydantic model."
    )


def _infer_endpoint(result_obj: Any, payload: Mapping[str, Any]) -> str:
    """Best-effort endpoint inference from a result object's class name."""

    if isinstance(result_obj, Mapping):
        end = result_obj.get("endpoint") or result_obj.get("_endpoint")
        if end:
            return str(end)
    cls_name = type(result_obj).__name__
    inferred = {
        "DesignPathResult": "/v1/design-path",
        "ComplianceBayesianPPassResult": "/v1/compliance-bayesian-p-pass",
        "AmQualificationResult": "/v1/am-qualification",
        "MtcParseResult": "/v1/mtc-parse",
        "TttComputeResult": "/v1/ttt-compute",
        "CalphadEquilibriumResult": "/v1/calphad-equilibrium",
        "BayesianCalphadDeepResult": "/v1/bayesian-calphad-deep",
        "CalibrateResult": "/v1/calibrate",
    }
    return inferred.get(cls_name, "<unknown>")


def _engine_env() -> dict[str, Any]:
    """Snapshot of the local Python environment for audit forensics."""

    return {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "machine": platform.machine(),
    }


def _dependency_versions() -> dict[str, str]:
    """Versions of the core dependencies the engine uses."""

    versions: dict[str, str] = {}
    for pkg in ("httpx", "pydantic", "tenacity"):
        try:
            mod = __import__(pkg)
            v = getattr(mod, "__version__", None)
            if v:
                versions[pkg] = str(v)
        except ImportError:
            pass
    return versions


# ---------------------------------------------------------------------------
# Public API: record / save / load / replay / verify
# ---------------------------------------------------------------------------


def record(
    result: Any = None,
    *,
    call_id: Optional[str] = None,
    endpoint: Optional[str] = None,
    payload: Optional[Mapping[str, Any]] = None,
    deterministic_seed: Optional[int] = None,
) -> Any:
    """Build a local audit record from a calc result, or POST to the server log.

    **New local-record API (moat 6)**::

        result = au.design_path(alloy="4140", cooling_rate=10, posterior=True)
        rec = au.audit.record(result)
        au.audit.save(rec, "calc.json")

    Returns a dict with keys::

        {
          "endpoint":         str,
          "engine_version":   str,
          "code_sha":         str | null,
          "timestamp":        ISO-8601 str,
          "deterministic":    bool,
          "rng_seed":         int | null,
          "environment":      {python, platform, machine},
          "dependencies":     {pkg: version},
          "input":            dict,
          "original_result":  dict,
          "result_hash":      sha256 hex
        }

    **Legacy server-log API (back-compat with v0.1)**::

        au.audit.record(
            call_id="vessel-V-2401",
            endpoint="/v1/design-path",
            payload={"alloy": "4140"},
            result={"sigma_y": 1535},
        )

    In legacy mode it POSTs to ``/v1/audit/record`` and returns an
    :class:`AuditRecordResult` from the server. Triggered when
    ``call_id`` is provided and ``result`` is a mapping; behaves exactly
    as the v0.1 stub did so old code keeps working.

    Args:
        result: The result object to audit (Pydantic model or dict). If
            also passing ``call_id``, this becomes the server-side
            ``result`` payload.
        call_id: Legacy. If provided, switches to server-log mode.
        endpoint: Legacy. Endpoint string for the server log.
        payload: Legacy. Original request payload for the server log.
        deterministic_seed: Local mode. RNG seed to record so the replay
            can pin the same seed (defaults to 0).

    Returns:
        Local-mode: a JSON-serializable dict (the audit record).
        Legacy-mode: an :class:`AuditRecordResult`.
    """

    # Legacy path: server-log mode
    if call_id is not None and endpoint is not None and payload is not None:
        body = AuditRecordInput(
            call_id=call_id,
            endpoint=endpoint,
            payload=payload,
            result=result if isinstance(result, Mapping) else {},
        )
        client = get_default_client()
        response = client.post(
            "/v1/audit/record",
            json=body.model_dump(exclude_none=True),
        )
        return AuditRecordResult.model_validate(response.json())

    if result is None:
        raise TypeError(
            "audit.record requires either a result object (local mode) or "
            "call_id/endpoint/payload (legacy server-log mode)."
        )

    # Local-record mode
    result_dict = _result_to_dict(result)
    inferred_endpoint = endpoint or _infer_endpoint(result, payload or {})
    inferred_input = (
        dict(payload) if payload else _extract_input(result)
    )
    rec: dict[str, Any] = {
        "schema_version": 1,
        "endpoint": inferred_endpoint,
        "engine_version": _get_engine_version(),
        "code_sha": os.environ.get("AUSTENITE_CODE_SHA"),
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "deterministic": deterministic_seed is not None,
        "rng_seed": deterministic_seed if deterministic_seed is not None else 0,
        "environment": _engine_env(),
        "dependencies": _dependency_versions(),
        "input": inferred_input,
        "original_result": result_dict,
    }
    rec["result_hash"] = hash_record(rec["original_result"])
    return rec


def save(record_obj: Mapping[str, Any], path: Union[str, Path]) -> Path:
    """Write a local audit record to disk in canonical JSON form.

    Two records with the same content always produce byte-identical files
    (sorted keys, no whitespace beyond standard JSON separators, numbers
    rounded to 12 sig figs).

    Args:
        record_obj: The dict returned by :func:`record`.
        path: Destination path (``.json`` extension recommended).

    Returns:
        The :class:`~pathlib.Path` that was written.
    """

    if not isinstance(record_obj, Mapping):
        raise TypeError(
            f"audit.save expected a mapping, got {type(record_obj).__name__}."
        )
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    # Pretty-print for human readers but with sorted keys for determinism.
    canon = canonicalize(record_obj)
    text = json.dumps(canon, indent=2, sort_keys=True, ensure_ascii=False)
    p.write_text(text, encoding="utf-8")
    return p


def load(path: Union[str, Path]) -> dict[str, Any]:
    """Read a local audit record back from disk."""

    p = Path(path)
    text = p.read_text(encoding="utf-8")
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError(
            f"audit.load: file {p} does not contain a top-level JSON object."
        )
    return data


def replay(
    record_obj: Union[Mapping[str, Any], str, None] = None,
    *,
    engine_version: Optional[str] = None,
    deterministic: bool = True,
    audit_id: Optional[str] = None,
) -> Any:
    """Re-execute a calculation from its audit record.

    **New local-replay API (moat 6)**::

        rec = au.audit.load("calc.json")
        result = au.audit.replay(rec, engine_version="0.1.0", deterministic=True)
        assert result_hash_of(result) == rec["result_hash"]

    Behaviour:

      * Validates ``engine_version`` matches the record's; warns (does
        **not** raise) on mismatch unless explicitly pinned with the
        ``engine_version`` argument — then raises
        :class:`ReplayMismatchError`.
      * Looks up the endpoint replayer registered in
        ``_ENDPOINT_REPLAYERS``; raises :class:`ReplayMismatchError` if
        not found.
      * In deterministic mode, sets ``AUSTENITE_DETERMINISTIC_SEED``
        environment variable so any stochastic engine respects it.
      * Re-runs the computation via the registered API caller and returns
        the new result object.

    **Legacy server-replay API (back-compat with v0.1)**::

        au.audit.replay("audit-id-xyz")
        # or
        au.audit.replay(audit_id="audit-id-xyz")

    Triggered when ``record_obj`` is a string or ``audit_id`` is passed.
    POSTs to ``/v1/audit/replay`` and returns an :class:`AuditReplayResult`.

    Args:
        record_obj: The local audit record (dict) — new mode. Or a string
            audit id — legacy mode.
        engine_version: If set, requires the record's recorded engine
            version to match exactly. Mismatch raises
            :class:`ReplayMismatchError`. If unset, a mismatch only logs
            a note in the returned object.
        deterministic: If ``True``, exports the recorded ``rng_seed``
            into the environment so any stochastic engine reads it.
        audit_id: Legacy keyword for server-replay mode.

    Returns:
        Local mode: the re-computed result (Pydantic model) annotated
        with ``_audit_replay`` metadata. Legacy mode:
        :class:`AuditReplayResult`.

    Raises:
        :class:`ReplayMismatchError`: engine_version pinned and mismatched,
            or the endpoint isn't registered for local replay.
    """

    # Legacy path
    if audit_id is not None:
        body = AuditReplayInput(audit_id=audit_id)
        client = get_default_client()
        response = client.post(
            "/v1/audit/replay", json=body.model_dump(exclude_none=True),
        )
        return AuditReplayResult.model_validate(response.json())
    if isinstance(record_obj, str):
        return replay(audit_id=record_obj)

    if record_obj is None:
        raise TypeError(
            "audit.replay requires either a record dict (local mode) or "
            "an audit_id string (legacy server-replay mode)."
        )

    if not isinstance(record_obj, Mapping):
        raise TypeError(
            f"audit.replay expected a mapping or string, got "
            f"{type(record_obj).__name__}."
        )

    rec_engine = str(record_obj.get("engine_version") or "")
    if engine_version is not None and rec_engine != engine_version:
        raise ReplayMismatchError(
            f"engine_version pin mismatch: record was {rec_engine!r}, "
            f"caller required {engine_version!r}. Pin to None or to the "
            f"recorded version to proceed.",
        )

    endpoint = str(record_obj.get("endpoint") or "")
    replayer = _ENDPOINT_REPLAYERS.get(endpoint)
    if replayer is None:
        raise ReplayMismatchError(
            f"No local replayer registered for endpoint {endpoint!r}. "
            f"Known: {sorted(_ENDPOINT_REPLAYERS.keys())}",
        )

    if deterministic:
        seed = record_obj.get("rng_seed", 0)
        os.environ["AUSTENITE_DETERMINISTIC_SEED"] = str(seed)

    payload = dict(record_obj.get("input") or {})
    result = replayer(payload)
    # Annotate the replayed result with audit metadata so the caller can
    # inspect what they ran.
    if isinstance(result, dict):
        result.setdefault("_audit_replay", {})
        eng_now = _get_engine_version()
        result["_audit_replay"].update(
            {
                "engine_version_now": eng_now,
                "engine_version_then": rec_engine,
                "matches": rec_engine == eng_now,
                "deterministic": deterministic,
                "result_hash_then": record_obj.get("result_hash"),
                "result_hash_now": hash_record(
                    {
                        k: v
                        for k, v in result.items()
                        if k != "_audit_replay"
                    }
                ),
            }
        )
    return result


@dataclass(frozen=True)
class VerifyReport:
    """Result of verifying an audit record's integrity.

    Attributes:
        hash_matches: True iff re-canonicalizing the record's
            ``original_result`` reproduces the stored ``result_hash``.
        stored_hash: The hash that was saved alongside the record.
        computed_hash: The hash we just re-computed.
        engine_version_matches: True iff the running engine version equals
            the one in the record (informational).
        notes: Human-readable notes on what passed / failed.
    """

    hash_matches: bool
    stored_hash: str
    computed_hash: str
    engine_version_matches: bool
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "hash_matches": self.hash_matches,
            "stored_hash": self.stored_hash,
            "computed_hash": self.computed_hash,
            "engine_version_matches": self.engine_version_matches,
            "notes": list(self.notes),
        }


def verify(record_obj: Mapping[str, Any]) -> VerifyReport:
    """Verify a local audit record's integrity.

    Re-canonicalizes the ``original_result`` and recomputes its SHA-256;
    if the hashes match, the record is intact. Also reports whether the
    engine version in the record matches the running engine — this is
    informational only (a version mismatch may still verify, since the
    integrity check is over the *recorded* result, not a re-run).

    Args:
        record_obj: The audit record dict.

    Returns:
        :class:`VerifyReport`.
    """

    if not isinstance(record_obj, Mapping):
        raise TypeError(
            f"audit.verify expected a mapping, got {type(record_obj).__name__}."
        )
    stored = str(record_obj.get("result_hash") or "")
    if not stored:
        raise ValueError(
            "audit.verify: record has no 'result_hash' field — was it "
            "produced by audit.record() in local-record mode?"
        )
    original = record_obj.get("original_result") or {}
    computed = hash_record(original)
    matches = computed == stored
    notes: list[str] = []
    rec_engine = str(record_obj.get("engine_version") or "")
    eng_now = _get_engine_version()
    eng_match = rec_engine == eng_now
    if not matches:
        notes.append(
            f"Hash mismatch — record_hash={stored[:16]}, "
            f"computed={computed[:16]}"
        )
    else:
        notes.append("Integrity hash verified.")
    if not eng_match:
        notes.append(
            f"engine_version differs: record={rec_engine!r}, "
            f"current={eng_now!r}"
        )
    return VerifyReport(
        hash_matches=matches,
        stored_hash=stored,
        computed_hash=computed,
        engine_version_matches=eng_match,
        notes=notes,
    )
