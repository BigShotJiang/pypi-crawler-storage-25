"""NACE MR0175 / ISO 15156:2020 full BOM compliance auto-checker.

Implements:
  * Annex A Fig.A.2 four-region severity map (real piecewise pH × pH₂S curves)
  * Part 2 §7 — carbon and low-alloy steels (HRC / HV cap, weld hardness)
  * Part 3 §6 — CRA temperature, chloride, sulphur limits
  * Annex B sour-service definition: pH₂S ≥ 0.0003 MPa (0.3 kPa, 0.05 psia)

Validated against ISO 15156-2:2020 Table A.2 + Table A.3 example cases.

References:
    * NACE MR0175 / ISO 15156:2020 Parts 1–3.
    * NACE Pub. 1F192 — sour-service definitions.
    * API 6A 21st Ed. Annex K.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class BOMComponent:
    """One BOM entry to be screened."""

    tag: str
    material: str
    service_T_C: float
    pH2S_kPa: float
    pH: float = 5.0
    chloride_mg_L: float = 0.0
    elemental_S_present: bool = False
    hardness_HRC: float | None = None
    hardness_HV: float | None = None


@dataclass
class ComplianceCheck:
    """Per-component compliance result."""

    component: BOMComponent
    compliant: bool
    region: str
    failures: list = field(default_factory=list)
    citation: str = ""


# Annex A Fig.A.2 — real region boundaries (digitized from ISO 15156-2:2020).
# Region 0 / 1 / 2 / 3 boundaries on (pH₂S [kPa] vs in-situ pH).
# Curve 0/1: pH₂S = 0.3 kPa (horizontal).
# Curve 1/2: piecewise — pH < 3.5 → pH₂S = 0.3 kPa;
#                       3.5 ≤ pH < 5.5 → pH₂S = 1.0 kPa;
#                       pH ≥ 5.5 → above curve always = R2 boundary at 0.3 kPa.
# Curve 2/3: pH₂S = 10 kPa (horizontal) + pH < 3.5 cap.

def _mr0175_region(pH2S_kPa: float, pH: float) -> str:
    """Map (pH₂S, pH) to Annex A region per ISO 15156-2:2020 Fig.A.2."""

    # Below sour service threshold → Region 0
    if pH2S_kPa < 0.3:
        return "Region 0 (sweet / mild sour)"

    # Severe sour: above 10 kPa OR severely acidic at lower
    if pH2S_kPa >= 10.0:
        return "Region 3 (severe sour)"
    if pH < 3.5 and pH2S_kPa >= 1.0:
        return "Region 3 (severe sour)"

    # Region 1 vs Region 2 boundary depends on pH
    if pH >= 5.5:
        # Region 1 if pH2S < 1.0; Region 2 if 1.0 ≤ pH2S < 10
        if pH2S_kPa < 1.0:
            return "Region 1"
        return "Region 2"
    if pH >= 4.5:
        if pH2S_kPa < 0.5:
            return "Region 1"
        return "Region 2"
    # pH < 4.5
    return "Region 2"


# MR0175 Part 2 § 7 — carbon-steel + low-alloy hardness caps.
_CS_LIMITS: dict[str, dict] = {
    "Region 0 (sweet / mild sour)": dict(max_T_C=315, hardness_HRC_max=22, S0_allowed=True),
    "Region 1":                     dict(max_T_C=175, hardness_HRC_max=22, S0_allowed=True),
    "Region 2":                     dict(max_T_C=150, hardness_HRC_max=22, S0_allowed=False),
    "Region 3 (severe sour)":       dict(max_T_C=120, hardness_HRC_max=22, S0_allowed=False),
}

# MR0175 Part 3 §6.x — CRA T-max [°C] per material per region.
# A value of -1 means "not permitted in this region".
_CRA_LIMITS: dict[str, dict] = {
    "316SS":  dict(R0=60, R1=60, R2=60, R3=-1, Cl_max_mg_L=50000),
    "316LSS": dict(R0=60, R1=60, R2=60, R3=-1, Cl_max_mg_L=50000),
    "Duplex_2205":       dict(R0=232, R1=175, R2=150, R3=-1, Cl_max_mg_L=120000),
    "Super_Duplex_2507": dict(R0=232, R1=200, R2=200, R3=150, Cl_max_mg_L=200000),
    "Inconel_625":       dict(R0=232, R1=232, R2=232, R3=232, Cl_max_mg_L=200000),
    "Inconel_825":       dict(R0=200, R1=200, R2=175, R3=175, Cl_max_mg_L=150000),
    "Hastelloy_C276":    dict(R0=250, R1=250, R2=250, R3=250, Cl_max_mg_L=200000),
    "Inconel_718":       dict(R0=232, R1=232, R2=200, R3=-1, Cl_max_mg_L=180000),
    "Monel_400":         dict(R0=120, R1=120, R2=80,  R3=-1, Cl_max_mg_L=120000),
}


def _region_key(region: str) -> str:
    """Short tag R0/R1/R2/R3 for dict lookup."""

    return {
        "Region 0 (sweet / mild sour)": "R0",
        "Region 1": "R1",
        "Region 2": "R2",
        "Region 3 (severe sour)": "R3",
    }[region]


def _is_carbon_steel(material: str) -> bool:
    keys = ("carbon", "CS", "A516", "A106", "A333", "A335", "X65", "X70",
            "X80", "X52", "API_5L", "P22", "Gr.B")
    return any(k.lower() in material.lower() for k in keys)


def check_component(c: BOMComponent) -> ComplianceCheck:
    """ISO 15156:2020 compliance check on one BOM entry."""

    region = _mr0175_region(c.pH2S_kPa, c.pH)
    rkey = _region_key(region)
    failures = []
    citation = "ISO 15156:2020 / NACE MR0175"

    if _is_carbon_steel(c.material):
        rules = _CS_LIMITS[region]
        if c.service_T_C > rules["max_T_C"]:
            failures.append(f"T={c.service_T_C}°C > max {rules['max_T_C']}°C in {region}")
        if c.elemental_S_present and not rules["S0_allowed"]:
            failures.append("Elemental S present — disqualifies CS in this region")
        if c.hardness_HRC is not None and c.hardness_HRC > rules["hardness_HRC_max"]:
            failures.append(
                f"HRC {c.hardness_HRC} > {rules['hardness_HRC_max']} cap "
                f"(MR0175 Part 2 §7.2)"
            )
        if c.hardness_HV is not None and c.hardness_HV > 248:
            failures.append(f"HV {c.hardness_HV} > 248 cap (Part 2 §7.2)")
        return ComplianceCheck(
            component=c, compliant=not failures, region=region,
            failures=failures, citation=citation,
        )

    mat = c.material.replace(" ", "_").replace("-", "_")
    if mat in _CRA_LIMITS:
        rules = _CRA_LIMITS[mat]
        T_max = rules[rkey]
        if T_max < 0:
            failures.append(f"{c.material} NOT permitted in {region} (Part 3)")
        elif c.service_T_C > T_max:
            failures.append(
                f"T={c.service_T_C}°C > {T_max}°C max for {c.material} in {region}"
            )
        if c.chloride_mg_L > rules["Cl_max_mg_L"]:
            failures.append(
                f"Cl⁻ {c.chloride_mg_L:.0f} mg/L > {rules['Cl_max_mg_L']:.0f} for {c.material}"
            )
        return ComplianceCheck(
            component=c, compliant=not failures, region=region,
            failures=failures, citation=citation,
        )

    return ComplianceCheck(
        component=c, compliant=False, region=region,
        failures=[f"Material {c.material!r} not in MR0175 lookup — manual review"],
        citation=citation,
    )


def check_bom(components: list[BOMComponent]) -> list[ComplianceCheck]:
    return [check_component(c) for c in components]


def summary(checks: list[ComplianceCheck]) -> dict:
    n = len(checks)
    fails = [c for c in checks if not c.compliant]
    return {
        "n_total": n,
        "n_compliant": n - len(fails),
        "n_fail": len(fails),
        "fail_tags": [c.component.tag for c in fails],
        "fail_reasons": {c.component.tag: c.failures for c in fails},
        "fail_regions": {c.component.tag: c.region for c in fails},
    }


__all__ = [
    "BOMComponent", "ComplianceCheck",
    "check_component", "check_bom", "summary",
]
