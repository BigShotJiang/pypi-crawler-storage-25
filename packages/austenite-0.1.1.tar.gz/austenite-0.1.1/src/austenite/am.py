"""Additive-manufacturing qualification and parameter sweeps.

This module is the public surface for ``au.am.qualification`` and
``au.am.sweep``. By default each call goes over HTTP to the Austenite
engine. When the environment variable ``AUSTENITE_OFFLINE=1`` is set
(or the HTTP call raises an :class:`AusteniteError`) the native pure-
Python pipeline in :mod:`austenite._am_native` is used instead, so the
package can be evaluated entirely offline / airgapped / in CI without
network.

The native pipeline implements the classical 10-stage AM qualification
chain: VED → Rosenthal / Eagar-Tsai / Goldak heat source → King-
Khairallah process classifier → Kurz-Fisher G/V_s map → Maynier-Dollet
HV → Pavlina-Tyne σ_y/σ_UTS → Barsom-Rolfe K_Ic → ASTM F3055/F3001/
F3184/F3318/F3301 compliance gate. See that module's docstring for
the full reference list.
"""

from __future__ import annotations

import os
from typing import Any, Optional

from . import _am_native as native
from ._client import get_default_client
from ._exceptions import AusteniteError
from ._models import (
    AmQualificationInput,
    AmQualificationResult,
    AmSweepInput,
    AmSweepResult,
)


def _offline_requested() -> bool:
    """``AUSTENITE_OFFLINE=1`` (or any truthy value) skips the HTTP path."""

    val = os.environ.get("AUSTENITE_OFFLINE", "").strip().lower()
    return val in {"1", "true", "yes", "on"}


def _native_qualification_to_model(
    res: dict[str, Any],
) -> AmQualificationResult:
    """Lift the native pipeline dict into the public Pydantic envelope.

    The native result is forward-compatible with the HTTP shape — all
    extra fields (``meltpool``, ``solidification``, ``postprocess``,
    ``cost``, ``headline``) are carried via the model's ``extra='allow'``
    config so callers see the same surface either way.
    """

    properties = res.get("properties") or {}
    astm = res.get("astm") or {}
    return AmQualificationResult.model_validate(
        {
            "energy_density_J_mm3": res["ved"]["VED_J_mm3"],
            "melt_pool_regime": res["meltpool"].get("region") or astm.get("region")
                                 or _infer_region(res),
            "porosity_pct": res["postprocess"]["porosity_pct"],
            "properties": {
                "sigma_y_MPa": properties.get("sigma_y_MPa"),
                "sigma_uts_MPa": properties.get("sigma_uts_MPa"),
                "elongation_pct": properties.get("elongation_pct"),
                "HV30": properties.get("HV30"),
                "HRC": properties.get("HRC"),
                "KIc_MPa_sqm": properties.get("KIc_MPa_sqm"),
                "sigma_endurance_MPa": properties.get("sigma_endurance_MPa"),
            },
            "compliance": {
                "spec": astm.get("spec"),
                "pass": astm.get("overall_pass", False),
                "notes": "; ".join(astm.get("notes", [])) if astm.get("notes") else None,
            } if astm.get("spec") is not None else None,
            "citations": [
                {"source": "Rosenthal D., Trans. ASME 68 (1946) 849",
                 "note": "Moving point-source heat solution"},
                {"source": "Eagar T.W., Tsai N.S., Welding J. 62 (1983) 346s",
                 "note": "Ellipsoidal distributed-source temperature field"},
                {"source": "Goldak J., Chakravarti A., Bibby M., Met. Trans. B 15 (1984) 299",
                 "note": "Double-ellipsoid asymmetric weld pool"},
                {"source": "King W.E., Yancey R.N., Anderson A.T., Acta Mater. 87 (2014) 421",
                 "note": "LPBF keyhole criterion ΔH/h_s > 30"},
                {"source": "Khairallah S.A., Anderson A.T., Rubenchik A., King W.E., Acta Mater. 108 (2016) 36",
                 "note": "LPBF melt-flow / keyhole physics"},
                {"source": "Kurz W., Fisher D.J., Fundamentals of Solidification 4th ed. (1998)",
                 "note": "G / V_s solidification morphology map"},
                {"source": "Maynier P., Dollet J., Bastien P., AIME (1978) 163",
                 "note": "Ferrous hardness multi-regression from composition"},
                {"source": "Pavlina E.J., Van Tyne C.J., J. Mater. Eng. Perform. 17 (2008) 888",
                 "note": "σ_y / σ_UTS from Vickers HV linear fit"},
                {"source": "Barsom J.M., Rolfe S.T., ASTM STP 466 (1970) 281",
                 "note": "Lower-shelf K_Ic^2 = 5·E·CVN"},
                {"source": "ASTM F3055 / F3001 / F3184 / F3318 / F3301",
                 "note": "AM minimum-property specifications"},
                {"source": "Promoppatum P. et al., Engineering 3 (2017) 685",
                 "note": "IN718 LPBF analytical vs FEA vs experiment"},
                {"source": "Yadroitsev I., Smurov I., Phys. Procedia 5 (2010) 551",
                 "note": "Lack-of-fusion criterion D < 1.5·layer"},
            ],
            "ved": res.get("ved"),
            "meltpool": res.get("meltpool"),
            "solidification": res.get("solidification"),
            "alloy_props": res.get("alloy_props"),
            "postprocess": res.get("postprocess"),
            "cost": res.get("cost"),
            "headline": res.get("headline"),
            "astm": astm,
            "backend": "native",
        }
    )


def _infer_region(res: dict[str, Any]) -> Optional[str]:
    """Infer process region from the headline string when missing."""

    headline = res.get("headline") or {}
    verdict = (headline.get("verdict") or "").lower()
    for tag in ("keyhole", "lack-of-fusion", "balling", "conduction", "optimal"):
        if tag in verdict:
            return tag
    return None


def qualification(
    *,
    alloy: str,
    laser_power_W: float,
    scan_speed_mm_s: float,
    hatch_um: float,
    layer_um: float,
    process: str = "LPBF",
    spec: Optional[str] = None,
    backend: Optional[str] = None,
    **kwargs: Any,
) -> AmQualificationResult:
    """Predict AM part quality for a given parameter set.

    Args:
        alloy: Alloy grade (e.g. ``"IN718"``, ``"Ti-6Al-4V"``).
        laser_power_W: Laser power, W.
        scan_speed_mm_s: Scan speed, mm/s.
        hatch_um: Hatch spacing, µm.
        layer_um: Layer thickness, µm.
        process: ``"LPBF"`` (default), ``"DED"``, or ``"EBM"``.
        spec: Optional compliance spec (e.g. ``"ASTM-F3055"``).
        backend: One of ``"http"`` (force HTTP), ``"native"`` (force the
            offline pipeline), or ``None`` (default: HTTP first, fall
            back to native on :class:`AusteniteError`, or native
            outright if ``AUSTENITE_OFFLINE`` is set).
        **kwargs: forwarded to the native pipeline (``eta``, ``T0_C``,
            ``spot_mm``, ``model``, ``cooling_rate_Cs``, ``chemistry``).

    Returns:
        :class:`AmQualificationResult` — VED, melt-pool regime, porosity,
        properties, ASTM compliance verdict.
    """

    use_native = backend == "native" or (backend is None and _offline_requested())

    if not use_native:
        try:
            payload = AmQualificationInput(
                alloy=alloy,
                process=process,
                laser_power_W=laser_power_W,
                scan_speed_mm_s=scan_speed_mm_s,
                hatch_um=hatch_um,
                layer_um=layer_um,
                spec=spec,
            )
            client = get_default_client()
            response = client.post(
                "/v1/am/qualification",
                json=payload.model_dump(exclude_none=True),
            )
            return AmQualificationResult.model_validate(response.json())
        except AusteniteError:
            if backend == "http":
                raise
            # fall through to the native pipeline

    res = native.run_qualification_native(
        alloy=alloy,
        power_W=laser_power_W,
        velocity_mm_s=scan_speed_mm_s,
        hatch_mm=hatch_um / 1000.0,  # µm → mm
        layer_mm=layer_um / 1000.0,
        eta=kwargs.get("eta"),
        T0_C=kwargs.get("T0_C", 100.0),
        spot_mm=kwargs.get("spot_mm"),
        model=kwargs.get("model", "rosenthal"),
        cooling_rate_Cs=kwargs.get("cooling_rate_Cs"),
        chemistry=kwargs.get("chemistry"),
        spec=spec or alloy,
    )
    return _native_qualification_to_model(res)


def sweep(
    *,
    alloy: str,
    laser_power_W: list[float],
    scan_speed_mm_s: list[float],
    hatch_um: float,
    layer_um: float,
    process: str = "LPBF",
    backend: Optional[str] = None,
    **kwargs: Any,
) -> AmSweepResult:
    """Run a grid sweep across laser power and scan speed.

    Returns a list of points plus an optional ``process_window`` bounding box
    of acceptable parameters. The native fallback enumerates the same
    grid by calling :func:`qualification` per point.
    """

    use_native = backend == "native" or (backend is None and _offline_requested())

    if not use_native:
        try:
            payload = AmSweepInput(
                alloy=alloy,
                process=process,
                laser_power_W=laser_power_W,
                scan_speed_mm_s=scan_speed_mm_s,
                hatch_um=hatch_um,
                layer_um=layer_um,
            )
            client = get_default_client()
            response = client.post(
                "/v1/am/sweep",
                json=payload.model_dump(exclude_none=True),
            )
            return AmSweepResult.model_validate(response.json())
        except AusteniteError:
            if backend == "http":
                raise

    # Native: enumerate the grid via the native qualification pipeline.
    points: list[dict[str, Any]] = []
    win_pow: list[float] = []
    win_v: list[float] = []
    for P in laser_power_W:
        for v in scan_speed_mm_s:
            res = native.run_qualification_native(
                alloy=alloy,
                power_W=P,
                velocity_mm_s=v,
                hatch_mm=hatch_um / 1000.0,
                layer_mm=layer_um / 1000.0,
                eta=kwargs.get("eta"),
                T0_C=kwargs.get("T0_C", 100.0),
                spot_mm=kwargs.get("spot_mm"),
                model=kwargs.get("model", "rosenthal"),
                cooling_rate_Cs=kwargs.get("cooling_rate_Cs"),
                chemistry=kwargs.get("chemistry"),
                spec=alloy,
            )
            region = res["solidification"].get("regime") or _infer_region(res)
            points.append(
                dict(
                    laser_power_W=float(P),
                    scan_speed_mm_s=float(v),
                    energy_density_J_mm3=res["ved"]["VED_J_mm3"],
                    porosity_pct=res["postprocess"]["porosity_pct"],
                    regime=region,
                )
            )
            verdict = res["headline"]["verdict"]
            if "PASS" in verdict:
                win_pow.append(float(P))
                win_v.append(float(v))
    window = None
    if win_pow and win_v:
        window = {
            "power_min_W": min(win_pow),
            "power_max_W": max(win_pow),
            "speed_min_mm_s": min(win_v),
            "speed_max_mm_s": max(win_v),
        }
    return AmSweepResult.model_validate(
        {
            "points": points,
            "process_window": window,
            "backend": "native",
        }
    )


__all__ = [
    "qualification",
    "sweep",
    "native",
]
