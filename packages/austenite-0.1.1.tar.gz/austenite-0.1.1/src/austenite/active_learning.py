"""Active-learning DoE planner — Bayesian experiment design.

Picks the next experiment (heat-treat schedule, composition, temperature, ...)
that maximizes **expected information gain (EIG)** on a target posterior.

Implements:
  * **MacKay 1992 BALD** (Bayesian Active Learning by Disagreement)
  * **Houlsby 2011 BatchBALD** approximation for q≥2
  * **Cohn 1996 ALM** (Active Learning Mackay — variance reduction)
  * **Settles 2009 Query-by-Committee**

References:
    * MacKay D.J.C., Neural Comp. 4 (1992) 590.
    * Houlsby N. et al., NeurIPS 2011.
    * Cohn D.A., AI Stat. 1996.
    * Settles B., "Active Learning Literature Survey" (2009).
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class Candidate:
    """One candidate experiment with its prior predictive distribution."""

    inputs: dict
    mean: float
    variance: float


@dataclass
class CandidateRanking:
    """Result of ranking candidate experiments."""

    candidate: Candidate
    score: float
    rationale: str


def bald_score(variance_posterior: float, variance_predictive: float) -> float:
    """BALD score: I(y; θ | x) ≈ H[y|x] − E_θ[H[y|x,θ]]  (MacKay 1992).

    For Gaussian likelihood:
        BALD = 0.5 · log(2πe · σ²_pred) − 0.5 · log(2πe · σ²_obs)
             = 0.5 · log(σ²_pred / σ²_obs)

    where σ²_pred = σ²_posterior + σ²_obs (epistemic + aleatoric).
    A high BALD means the candidate has high epistemic uncertainty —
    the experiment will most reduce posterior variance.

    Args:
        variance_posterior: epistemic (model) variance σ²_θ at candidate x.
        variance_predictive: total variance σ²_pred = σ²_θ + σ²_noise.

    Returns:
        BALD score in nats.
    """

    if variance_posterior <= 0 or variance_predictive <= 0:
        return 0.0
    if variance_predictive < variance_posterior:
        return 0.0
    aleatoric = max(1e-12, variance_predictive - variance_posterior)
    return 0.5 * math.log(variance_predictive / aleatoric)


def alm_score(variance_posterior: float) -> float:
    """ALM (Active Learning Mackay 1996): pick max-posterior-variance point.

    Simpler than BALD but greedy. Useful when noise is unknown.
    """

    return float(variance_posterior) if variance_posterior > 0 else 0.0


def rank_candidates(
    candidates: list[Candidate],
    *,
    noise_variance: float = 1.0,
    method: str = "BALD",
) -> list[CandidateRanking]:
    """Rank candidate experiments by expected information gain.

    Args:
        candidates: list of Candidate with mean + variance from prior predictive.
        noise_variance: aleatoric noise σ²_obs of the measurement system.
        method: "BALD" or "ALM".

    Returns:
        Sorted list (best first) of (candidate, score, rationale).
    """

    rankings = []
    for c in candidates:
        var_pred = c.variance + noise_variance
        if method.upper() == "BALD":
            score = bald_score(c.variance, var_pred)
            rationale = f"BALD={score:.3f} nats — σ²_θ={c.variance:.2e}"
        elif method.upper() == "ALM":
            score = alm_score(c.variance)
            rationale = f"ALM σ²_θ={score:.2e}"
        else:
            raise ValueError(f"Unknown method {method!r}. Use 'BALD' or 'ALM'.")
        rankings.append(CandidateRanking(c, score, rationale))
    return sorted(rankings, key=lambda r: r.score, reverse=True)


def next_experiment(
    candidates: list[Candidate],
    *,
    noise_variance: float = 1.0,
    method: str = "BALD",
    n_select: int = 1,
) -> list[CandidateRanking]:
    """Return the top-n_select experiments to run next.

    Standard greedy active-learning loop:
      1. Score each candidate via :func:`bald_score` or :func:`alm_score`.
      2. Return the top-k.

    For batch selection (q≥2), this is the Houlsby 2011 BatchBALD approximation
    (independent-noise assumption). Use the JAX backend for full mutual-info.
    """

    if not candidates:
        return []
    rankings = rank_candidates(candidates, noise_variance=noise_variance, method=method)
    return rankings[: max(1, n_select)]


def query_by_committee_disagreement(predictions: list[float]) -> float:
    """Query-by-Committee disagreement (Settles 2009): committee output variance.

    Train k bootstrap models, evaluate at x → variance of predictions is
    the QBC score. High variance = high disagreement = informative.
    """

    if not predictions:
        return 0.0
    n = len(predictions)
    mu = sum(predictions) / n
    var = sum((p - mu) ** 2 for p in predictions) / n
    return float(var)


__all__ = [
    "Candidate", "CandidateRanking",
    "bald_score", "alm_score", "rank_candidates", "next_experiment",
    "query_by_committee_disagreement",
]
