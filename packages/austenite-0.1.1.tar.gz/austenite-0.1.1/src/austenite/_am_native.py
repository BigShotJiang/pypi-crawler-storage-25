"""Pure-Python AM (additive manufacturing) qualification engine — offline fallback.

Port of the TypeScript pipeline at ``apps/web/src/lib/am-pipeline/qualification.ts``
to numpy/scipy so ``au.am.qualification`` can be evaluated **OFFLINE** (without
hitting the HTTP API) when ``AUSTENITE_OFFLINE=1`` or when the HTTP path fails.

Implements the classical 10-stage L-PBF / DED / EBM qualification chain
performed by every aerospace AM service bureau (Materialise, Sintavia, EOS,
3DSystems, Carpenter Additive) for each new (alloy × machine × build-
orientation) combination:

1.  **Volumetric Energy Density (VED)** ``= P / (v · h · t)`` — J/mm³.
2.  **Heat-source model** — closed-form Rosenthal 1946 point source,
    semi-analytic Eagar-Tsai 1983 ellipsoidal source, or Goldak-Chakravarti-
    Bibby 1984 double-ellipsoid asymmetric source (sum of two Eagar-Tsai
    integrals with front fraction ``f_f`` + rear fraction ``f_r = 2 − f_f``).
    All three return ``T(ξ, y, z)`` in the moving frame attached to the
    laser.
3.  **Process classifier** — King-Yancey-Khairallah 2014 normalised
    enthalpy ``ΔH/h_s`` keyhole criterion (>30 → keyhole, Khairallah-King
    2016 LBPM), Yadroitsev 2010 lack-of-fusion criterion (melt depth
    < 1.5 × layer thickness), Plateau-Rayleigh balling (L/W > 2.3).
4.  **Solidification map** — Kurz-Fisher 1998 (G, V_s) classifier:
    planar / cellular / columnar-dendritic / equiaxed-dendritic.
5.  **Hardness prediction** — Maynier-Dollet 1978 multiple-regression for
    ferrous alloys with chemistry data; Hall-Petch surrogate with cooling-
    rate boost for non-ferrous Ni / Ti / Al / Co.
6.  **σ_y from HV** — Pavlina-Tyne 2008 linear fit ``σ_y = 2.876 · HV − 90.7``.
7.  **σ_UTS from HV** — Pavlina-Tyne 2008 ``σ_UTS ≈ 3.0 · HV``.
8.  **CVN from HV** — Roberts-Newton 1965-style empirical ``CVN ≈ 290 · exp(−HV/280)``.
9.  **K_Ic from CVN** — Barsom-Rolfe 1972 lower-shelf ``K_Ic² = 5 · E · CVN``.
10. **ASTM compliance** — F3055 / F3001 / F3184 / F3318 / F3301 minimum
    σ_y / σ_UTS / elongation / density gates.

References
----------
*   Rosenthal, D. *The theory of moving sources of heat*. Trans. ASME 68
    (1946) 849-866.
*   Eagar, T. W.; Tsai, N. S. *Temperature fields produced by traveling
    distributed heat sources*. Welding Journal 62 (1983) 346s-355s.
*   Goldak, J.; Chakravarti, A.; Bibby, M. *A new finite element model
    for welding heat sources*. Metall. Trans. B 15 (1984) 299-305.
*   Khairallah, S. A.; Anderson, A. T.; Rubenchik, A.; King, W. E.
    *Laser powder-bed fusion additive manufacturing — physics of complex
    melt flow and formation mechanisms of pores, spatter and denudation
    zones*. Acta Mater. 108 (2016) 36-45.
*   King, W. E.; Yancey, R. N.; Anderson, A. T. *Observation of keyhole-mode
    laser melting in laser powder-bed fusion additive manufacturing*. LLNL
    + Acta Mater. 87 (2014) 421-426.
*   Kurz, W.; Fisher, D. J. *Fundamentals of Solidification* 4th ed.,
    Trans Tech (1998), Fig. 4.30 G/V_s morphology map.
*   Maynier, P.; Dollet, J.; Bastien, P. *Prediction of microstructure via
    empirical formulae based on CCT diagrams*. Hardenability concepts with
    applications to steel, AIME (1978) 163-178.
*   Pavlina, E. J.; Van Tyne, C. J. *Correlation of yield strength and
    tensile strength with hardness for steels*. J. Mater. Eng. Perform.
    17 (2008) 888-893.
*   Barsom, J. M.; Rolfe, S. T. *Correlations between K_Ic and Charpy V-notch
    test results in the transition-temperature range*. ASTM STP 466 (1970)
    281-302 (Barsom-Rolfe 1970/1972 lower-shelf relation).
*   Hooper, P. A. *Melt pool temperature and cooling rates in laser powder-
    bed fusion*. Addit. Manuf. 22 (2018) 548-559.
*   Promoppatum, P.; Yao, S.-C.; Pistorius, P. C.; Rollett, A. D.
    *A comprehensive comparison of the analytical and numerical prediction
    of the thermal history and solidification microstructure of Inconel 718
    products made by laser powder-bed fusion*. Engineering 3 (2017) 685-694.
*   Yadroitsev, I.; Smurov, I. *Selective laser melting technology — from
    the single laser melted track stability to 3D parts of complex shape*.
    Phys. Procedia 5 (2010) 551-560.

A Javanshir Hasanov production.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Optional

import numpy as np

# ---------------------------------------------------------------------------
# Alloy thermo-physical library (mirrors AM_ALLOY_LIBRARY in melt-pool.ts)
# ---------------------------------------------------------------------------
#
# Each entry: name, Tmelt (°C), k (W/m·K), rho (kg/m³), Cp (J/kg·K),
#             defaultEta (-), defaultSpot (mm), ref (citation).
# Calibrated values come from the cited LPBF / DED study.

AM_ALLOY_LIBRARY: dict[str, dict[str, Any]] = {
    # ── stainless ──────────────────────────────────────────────────────────
    "SS316L": dict(
        name="316L stainless (Hooper 2018 LPBF calibration)",
        Tmelt=1380.0, k=25.0, rho=7960.0, Cp=510.0,
        defaultEta=0.36, defaultSpot=0.080,
        ref="Hooper Add Manuf 22 (2018) 548; Mills 2002 RP Metals & Alloys",
    ),
    "SS304L": dict(
        name="304L stainless (Saeidi 2015 LPBF / SLM)",
        Tmelt=1399.0, k=21.0, rho=7900.0, Cp=500.0,
        defaultEta=0.35, defaultSpot=0.080,
        ref="Saeidi-Gao-Zhao-Shen, Mater. Sci. Eng. A 625 (2015) 221",
    ),
    "17-4PH": dict(
        name="17-4 PH stainless (Wang 2017 LPBF martensitic PH SS)",
        Tmelt=1404.0, k=18.0, rho=7800.0, Cp=460.0,
        defaultEta=0.36, defaultSpot=0.080,
        ref="Wang-Yan-Tian-Wang, J. Manuf. Proc. 30 (2017) 144",
    ),
    "15-5PH": dict(
        name="15-5 PH stainless (martensitic PH)",
        Tmelt=1404.0, k=17.0, rho=7800.0, Cp=460.0,
        defaultEta=0.36, defaultSpot=0.080,
        ref="ASM Handbook Vol 1 // approx",
    ),
    # ── Ni-superalloys ─────────────────────────────────────────────────────
    "IN718": dict(
        name="IN718 (Promoppatum 2017 LPBF + DED)",
        Tmelt=1336.0, k=30.0, rho=8190.0, Cp=540.0,
        defaultEta=0.40, defaultSpot=0.080,
        ref="Promoppatum-Yao-Pistorius-Rollett, Engineering 3 (2017) 685",
    ),
    "IN625": dict(
        name="IN625 (Yadroitsev 2014 LPBF Ni-Cr-Mo)",
        Tmelt=1350.0, k=23.0, rho=8440.0, Cp=510.0,
        defaultEta=0.38, defaultSpot=0.080,
        ref="Yadroitsev-Krakhmalev-Yadroitsava, J. Alloys Comp. 583 (2014) 404",
    ),
    "IN939": dict(
        name="IN939 (Engeli 2016 LPBF aero hot-section)",
        Tmelt=1320.0, k=22.0, rho=8160.0, Cp=555.0,
        defaultEta=0.38, defaultSpot=0.080,
        ref="Engeli-Etter-Hovel-Wegener, J. Mater. Proc. Tech. 229 (2016) 484",
    ),
    "CM247LC": dict(
        name="CM247LC (Carter 2014 LPBF γ′-bearing crack-prone superalloy)",
        Tmelt=1340.0, k=21.0, rho=8550.0, Cp=580.0,
        defaultEta=0.38, defaultSpot=0.080,
        ref="Carter-Attallah-Reed, Superalloys 2012 / ICAA13 (2014)",
    ),
    "Hastelloy-X": dict(
        name="Hastelloy X (Han 2017 LPBF solid-solution Ni)",
        Tmelt=1355.0, k=24.0, rho=8220.0, Cp=520.0,
        defaultEta=0.38, defaultSpot=0.080,
        ref="Han-Mertens-Montero-Sistiaga, Mater. Sci. Eng. A 701 (2017) 22",
    ),
    "CoCr-MP1": dict(
        name="CoCr (MP1, Sing 2015 LPBF medical/dental)",
        Tmelt=1380.0, k=13.0, rho=8400.0, Cp=450.0,
        defaultEta=0.40, defaultSpot=0.080,
        ref="Sing-An-Yeong-Wiria, J. Orthopaedic Res. 34 (2015) 369",
    ),
    # ── Ti alloys ──────────────────────────────────────────────────────────
    "Ti-6Al-4V": dict(
        name="Ti-6Al-4V (Khairallah 2016 LPBF keyhole study)",
        Tmelt=1654.0, k=7.0, rho=4430.0, Cp=560.0,
        defaultEta=0.30, defaultSpot=0.100,
        ref="Khairallah-Anderson-Rubenchik-King, Acta Mater 108 (2016) 36",
    ),
    "CP-Ti": dict(
        name="Commercially-pure Ti (Wysocki 2017 LPBF α-Ti)",
        Tmelt=1668.0, k=17.0, rho=4510.0, Cp=528.0,
        defaultEta=0.30, defaultSpot=0.100,
        ref="Wysocki-Idaszek-Jaroszewicz-Krawiec, Materials 10 (2017) 1058",
    ),
    "TiAl-48-2-2": dict(
        name="Ti-48Al-2Cr-2Nb γ-TiAl (Murr 2010 EBM intermetallic)",
        Tmelt=1733.0, k=22.0, rho=3950.0, Cp=600.0,
        defaultEta=0.45, defaultSpot=0.200,
        ref="Murr-Gaytan-Ramirez et al., Acta Mater. 58 (2010) 1887",
    ),
    # ── Aluminium alloys ───────────────────────────────────────────────────
    "AlSi10Mg": dict(
        name="AlSi10Mg (Aboulkhair 2014 LPBF + DED)",
        Tmelt=595.0, k=113.0, rho=2670.0, Cp=950.0,
        defaultEta=0.25, defaultSpot=0.100,
        ref="Aboulkhair-Everitt-Ashcroft-Tuck, Add Manuf 1-4 (2014) 77",
    ),
    "AlSi12": dict(
        name="AlSi12 near-eutectic casting Al (Siddique 2015 LPBF)",
        Tmelt=577.0, k=155.0, rho=2660.0, Cp=920.0,
        defaultEta=0.25, defaultSpot=0.100,
        ref="Siddique-Imran-Wycisk-Emmelmann-Walther, J. Mater. Proc. Tech. 221 (2015) 205",
    ),
    "AA2024": dict(
        name="AA2024 Al-Cu (Zhang 2020 LPBF; crack-prone)",
        Tmelt=638.0, k=121.0, rho=2780.0, Cp=880.0,
        defaultEta=0.25, defaultSpot=0.080,
        ref="Zhang-Liu-Yan-Liang, Add. Manuf. 32 (2020) 101099",
    ),
    "AA7075": dict(
        name="AA7075 Al-Zn-Mg (Martin 2017 LPBF + grain-refiner)",
        Tmelt=635.0, k=130.0, rho=2810.0, Cp=960.0,
        defaultEta=0.25, defaultSpot=0.080,
        ref="Martin-Yahata-Hundley-Mayer-Schaedler-Pollock, Nature 549 (2017) 365",
    ),
    "Scalmalloy": dict(
        name="Scalmalloy (Al-Mg-Sc-Zr, Spierings 2017 LPBF)",
        Tmelt=635.0, k=100.0, rho=2670.0, Cp=880.0,
        defaultEta=0.27, defaultSpot=0.080,
        ref="Spierings-Dawson-Voegtlin-Palm-Uggowitzer, CIRP Annals 65 (2016) 213",
    ),
    # ── Cu and high-conductivity ───────────────────────────────────────────
    "CuCrZr": dict(
        name="CuCrZr (high-conductivity, LPBF green-laser regime)",
        Tmelt=1080.0, k=320.0, rho=8920.0, Cp=390.0,
        defaultEta=0.45, defaultSpot=0.080,
        ref="Jadhav et al., Add Manuf 36 (2020) 101535 (green laser CuCrZr)",
    ),
    "Cu-pure": dict(
        name="Pure Cu (Jadhav 2019 LPBF, IR-laser absorptivity-limited)",
        Tmelt=1085.0, k=401.0, rho=8960.0, Cp=385.0,
        defaultEta=0.30, defaultSpot=0.080,
        ref="Jadhav-Goossens-Vrancken-Trasser, J. Mater. Proc. Tech. 270 (2019) 47",
    ),
    "GRCop-42": dict(
        name="GRCop-42 (NASA Cu-Cr-Nb, Gradl 2019 LPBF rocket)",
        Tmelt=1080.0, k=325.0, rho=8800.0, Cp=380.0,
        defaultEta=0.45, defaultSpot=0.080,
        ref="Gradl-Greene-Protz-Bullard, NASA SLS / Marshall (AIAA 2019-4228)",
    ),
    # ── tool steels & refractory ───────────────────────────────────────────
    "H13": dict(
        name="H13 tool steel (DED + LPBF die-repair)",
        Tmelt=1427.0, k=28.0, rho=7800.0, Cp=462.0,
        defaultEta=0.35, defaultSpot=0.080,
        ref="Mazumder et al. LMD/DED process studies",
    ),
    "Maraging-300": dict(
        name="Maraging 300 (18Ni300, Casati 2016 LPBF tooling)",
        Tmelt=1413.0, k=14.0, rho=8100.0, Cp=450.0,
        defaultEta=0.36, defaultSpot=0.080,
        ref="Casati-Lemke-Tuissi-Vedani, Metals 6 (2016) 218",
    ),
    "W-pure": dict(
        name="Pure W (Ivekovic 2018 LPBF refractory; cracking-prone)",
        Tmelt=3422.0, k=174.0, rho=19250.0, Cp=132.0,
        defaultEta=0.55, defaultSpot=0.080,
        ref="Ivekovic-Omidvari-Vrancken-Lietaert-Thijs-Vanmeensel, IJRMHM 72 (2018) 27",
    ),
    "Mo-TZM": dict(
        name="TZM (Mo-0.5Ti-0.1Zr, Faidel 2015 LPBF refractory)",
        Tmelt=2620.0, k=138.0, rho=10220.0, Cp=250.0,
        defaultEta=0.45, defaultSpot=0.080,
        ref="Faidel-Wirth-Hanschke-Riede-Schmidtke, Add. Manuf. 8 (2015) 88",
    ),
}


# ---------------------------------------------------------------------------
# ASTM minimum-property reference table — mirrors ASTM_MIN_PROPERTIES (TS)
# ---------------------------------------------------------------------------

ASTM_MIN_PROPERTIES: dict[str, dict[str, Any]] = {
    # Powder-bed fusion (PBF) — laser
    "SS316L":       dict(spec="ASTM F3184", alloy="SS316L LPBF",                 sigma_y_min_MPa=170,  sigma_uts_min_MPa=480,  elongation_min_pct=30, density_min_pct=99.5),
    "SS304L":       dict(spec="ASTM F3184", alloy="SS304L LPBF (Type)",          sigma_y_min_MPa=170,  sigma_uts_min_MPa=480,  elongation_min_pct=30, density_min_pct=99.5),
    "IN718":        dict(spec="ASTM F3055", alloy="IN718 LPBF stress-relieved",  sigma_y_min_MPa=850,  sigma_uts_min_MPa=1240, elongation_min_pct=12, density_min_pct=99.5),
    "IN625":        dict(spec="ASTM F3056", alloy="IN625 LPBF",                  sigma_y_min_MPa=430,  sigma_uts_min_MPa=830,  elongation_min_pct=30, density_min_pct=99.5),
    "IN939":        dict(spec="ASTM F3055", alloy="IN939 LPBF",                  sigma_y_min_MPa=850,  sigma_uts_min_MPa=1150, elongation_min_pct=10, density_min_pct=99.5),
    "CM247LC":      dict(spec="ASTM F3055", alloy="CM247LC LPBF crack-prone",    sigma_y_min_MPa=850,  sigma_uts_min_MPa=1100, elongation_min_pct=5,  density_min_pct=99.5),
    "Hastelloy-X":  dict(spec="ASTM F3056", alloy="Hastelloy X LPBF",            sigma_y_min_MPa=380,  sigma_uts_min_MPa=770,  elongation_min_pct=35, density_min_pct=99.5),
    "Ti-6Al-4V":    dict(spec="ASTM F3001", alloy="Ti-6Al-4V ELI LPBF",          sigma_y_min_MPa=795,  sigma_uts_min_MPa=860,  elongation_min_pct=10, density_min_pct=99.5),
    "CP-Ti":        dict(spec="ASTM F2924", alloy="CP-Ti Grade 1-2 LPBF",        sigma_y_min_MPa=170,  sigma_uts_min_MPa=240,  elongation_min_pct=24, density_min_pct=99.5),
    "TiAl-48-2-2":  dict(spec="ASTM F3055", alloy="γ-TiAl EBM",                  sigma_y_min_MPa=350,  sigma_uts_min_MPa=450,  elongation_min_pct=1,  density_min_pct=99.5),
    "AlSi10Mg":     dict(spec="ASTM F3318", alloy="AlSi10Mg LPBF as-built",      sigma_y_min_MPa=200,  sigma_uts_min_MPa=400,  elongation_min_pct=6,  density_min_pct=99.5),
    "AlSi12":       dict(spec="ASTM F3318", alloy="AlSi12 LPBF near-eutectic",   sigma_y_min_MPa=130,  sigma_uts_min_MPa=300,  elongation_min_pct=6,  density_min_pct=99.5),
    "AA2024":       dict(spec="ASTM F3318", alloy="AA2024 LPBF (cracks-prone)",  sigma_y_min_MPa=240,  sigma_uts_min_MPa=410,  elongation_min_pct=4,  density_min_pct=99.0),
    "AA7075":       dict(spec="ASTM F3318", alloy="AA7075 LPBF (Zr-modified)",   sigma_y_min_MPa=320,  sigma_uts_min_MPa=400,  elongation_min_pct=5,  density_min_pct=99.0),
    "Scalmalloy":   dict(spec="ASTM F3318", alloy="Scalmalloy (Al-Mg-Sc-Zr)",    sigma_y_min_MPa=470,  sigma_uts_min_MPa=520,  elongation_min_pct=13, density_min_pct=99.5),
    "CoCr-MP1":     dict(spec="ASTM F3213", alloy="CoCr (Co-28Cr-6Mo) LPBF",     sigma_y_min_MPa=500,  sigma_uts_min_MPa=950,  elongation_min_pct=20, density_min_pct=99.5),
    "17-4PH":       dict(spec="ASTM F3301", alloy="17-4PH H900 LPBF",            sigma_y_min_MPa=1170, sigma_uts_min_MPa=1310, elongation_min_pct=10, density_min_pct=99.5),
    "15-5PH":       dict(spec="ASTM F3301", alloy="15-5PH H900 LPBF",            sigma_y_min_MPa=1170, sigma_uts_min_MPa=1310, elongation_min_pct=10, density_min_pct=99.5),
    "CuCrZr":       dict(spec="ASTM F3056", alloy="CuCrZr LPBF",                 sigma_y_min_MPa=280,  sigma_uts_min_MPa=410,  elongation_min_pct=12, density_min_pct=99.0),
    "GRCop-42":     dict(spec="ASTM F3056", alloy="GRCop-42 NASA",               sigma_y_min_MPa=250,  sigma_uts_min_MPa=480,  elongation_min_pct=15, density_min_pct=99.0),
    "Cu-pure":      dict(spec="ASTM F3056", alloy="Pure-Cu LPBF (IR laser)",     sigma_y_min_MPa=60,   sigma_uts_min_MPa=210,  elongation_min_pct=40, density_min_pct=95.0),
    "H13":          dict(spec="ASTM F3187", alloy="H13 LPBF DED hot-work",       sigma_y_min_MPa=1100, sigma_uts_min_MPa=1500, elongation_min_pct=5,  density_min_pct=99.5),
    "Maraging-300": dict(spec="ASTM F3187", alloy="Maraging 300 LPBF aged",      sigma_y_min_MPa=1900, sigma_uts_min_MPa=2000, elongation_min_pct=3,  density_min_pct=99.5),
    "W-pure":       dict(spec="ASTM F3434", alloy="Pure W LPBF (crack-prone)",   sigma_y_min_MPa=350,  sigma_uts_min_MPa=550,  elongation_min_pct=2,  density_min_pct=99.0),
    "Mo-TZM":       dict(spec="ASTM F3434", alloy="TZM (Mo-Ti-Zr)",              sigma_y_min_MPa=600,  sigma_uts_min_MPa=700,  elongation_min_pct=10, density_min_pct=99.0),
}


# ---------------------------------------------------------------------------
# Process parameter dataclass — analogue of TS AMProcessInput
# ---------------------------------------------------------------------------

@dataclass
class AMProcessInput:
    """Moving-source process parameters used by all three heat-source models."""

    P: float            # laser/beam power, W
    v: float            # scan velocity, mm/s
    eta: float          # absorptivity, 0-1
    T0: float           # bed / preheat temperature, °C
    Tmelt: float        # melting point, °C
    k: float            # thermal conductivity, W/m·K
    rho: float          # density, kg/m³
    Cp: float           # specific heat, J/kg·K
    spotMm: float       # beam spot diameter, mm

    def alpha(self) -> float:
        """Thermal diffusivity α = k / (ρ·Cp), m²/s."""

        return self.k / (self.rho * self.Cp)


# ---------------------------------------------------------------------------
# 1. Volumetric Energy Density
# ---------------------------------------------------------------------------


def volumetric_energy_density(P: float, v: float, h: float, t: float) -> float:
    """Volumetric Energy Density VED = P / (v · h · t), J/mm³.

    Args:
        P: laser power, W.
        v: scan velocity, mm/s.
        h: hatch spacing, mm.
        t: layer thickness, mm.

    Returns:
        VED in J/mm³. Caller can classify with the typical (30-120) window
        bounds; outside that window indicates lack-of-fusion or keyhole.
    """

    denom = v * h * t
    if denom <= 0:
        return 0.0
    return max(0.0, P / denom)


# ---------------------------------------------------------------------------
# 2. Rosenthal 1946 moving point-source
# ---------------------------------------------------------------------------


def rosenthal_T(p: AMProcessInput, xi_m: float, y_m: float, z_m: float) -> float:
    """Rosenthal 1946 closed-form temperature in the moving frame.

    ``ΔT(ξ, y, z) = (η Q / (2π k R)) · exp(−v (R + ξ) / (2 α))``

    The point source is singular at R = 0 — clipped to ``T_melt + 200 °C``
    to avoid numerical blow-up.

    Args:
        p: process / material parameters.
        xi_m, y_m, z_m: coordinates in the moving frame, metres.

    Returns:
        Absolute temperature in °C.
    """

    R = math.sqrt(xi_m * xi_m + y_m * y_m + z_m * z_m)
    if R < 1e-9:
        return p.Tmelt + 200.0
    a = p.alpha()
    v_ms = p.v * 1e-3
    dT = (p.eta * p.P / (2 * math.pi * p.k * R)) * math.exp(
        -v_ms * (R + xi_m) / (2 * a)
    )
    return min(p.T0 + dT, p.Tmelt + 200.0)


def meltpool_rosenthal(
    P_W: float,
    v_mm_s: float,
    alpha_m2_s: float,
    k_W_mK: float,
    T_m_C: float,
    T_0_C: float = 25.0,
    eta: float = 0.4,
    spot_mm: float = 0.08,
) -> dict[str, float]:
    """Closed-form melt-pool size from the Rosenthal point source.

    Solves analytically for the centreline temperature T(ξ) = T_melt to
    extract the front/rear extent of the pool, then samples y / z scans.

    Returns dict with keys ``L_mm`` (length), ``W_mm`` (width), ``D_mm``
    (depth), ``Tpeak_C`` (clipped peak T), ``coolingRate_Ks`` (Ṫ at rear
    edge), ``G_K_mm`` (gradient at front), and ``V_s_mm_s`` (= v on
    centreline, Kurz-Fisher convention).
    """

    # Reconstruct an AMProcessInput so we can reuse rosenthal_T.
    # ρ·Cp = k / α; we need ρ and Cp only via the product so set rho=1
    # and Cp = k / alpha — only their product matters for the closed form
    # (α appears explicitly in the exponential).
    rho = 1.0
    Cp = k_W_mK / max(alpha_m2_s, 1e-12)
    p = AMProcessInput(
        P=P_W, v=v_mm_s, eta=eta, T0=T_0_C, Tmelt=T_m_C,
        k=k_W_mK, rho=rho, Cp=Cp, spotMm=spot_mm,
    )

    def Tfield(xi: float, y: float, z: float) -> float:
        return rosenthal_T(p, xi, y, z)

    return _meltpool_metrics_from_field(Tfield, p, scan_window_mm=5.0)


# ---------------------------------------------------------------------------
# 3. Eagar-Tsai 1983 single-ellipsoid (semi-analytic)
# ---------------------------------------------------------------------------


def eagar_tsai_T(
    p: AMProcessInput,
    xi_m: float,
    y_m: float,
    z_m: float,
    a_mm: float,
    b_mm: float,
    c_mm: float,
) -> float:
    """Eagar-Tsai 1983 distributed source temperature.

    Convolves a Gaussian source ``q(x,y,z) = 3 η Q / (a b c π √π) · exp(...)``
    with the 3-D Rosenthal Green's function. Evaluated by log-spaced
    trapezoidal quadrature over the convolution time τ.
    """

    a = p.alpha()
    v_ms = p.v * 1e-3
    a_m = a_mm * 1e-3
    b_m = b_mm * 1e-3
    c_m = c_mm * 1e-3
    aMax_m = max(a_m, b_m, c_m)
    tau_c = (aMax_m * aMax_m) / (4 * a)
    R = math.sqrt(xi_m * xi_m + y_m * y_m + z_m * z_m)
    tau_v = R / max(v_ms, 1e-9)
    tau_max = max(tau_c * 20.0, tau_v * 10.0, tau_c * 0.01 + 1e-9)
    tau_min = tau_c * 1e-3
    if tau_min <= 0 or tau_max <= tau_min:
        return p.T0
    N = 64
    logTauMin = math.log(tau_min)
    logTauMax = math.log(tau_max)
    dLog = (logTauMax - logTauMin) / N
    integral = 0.0
    # numpy vector form for speed
    i_arr = np.arange(N + 1)
    tau_arr = np.exp(logTauMin + i_arr * dLog)
    denom = np.sqrt(
        (4 * a * tau_arr + a_m * a_m)
        * (4 * a * tau_arr + b_m * b_m)
        * (4 * a * tau_arr + c_m * c_m)
    )
    arg = -(
        (xi_m + v_ms * tau_arr) ** 2 / (4 * a * tau_arr + a_m * a_m)
        + y_m * y_m / (4 * a * tau_arr + b_m * b_m)
        + z_m * z_m / (4 * a * tau_arr + c_m * c_m)
    )
    fi = (1.0 / denom) * np.exp(arg)
    # log-spaced trapezoid: dτ = τ · dlog(τ)
    weights = np.ones(N + 1)
    weights[0] = 0.5
    weights[-1] = 0.5
    integral = float(np.sum(weights * fi * tau_arr * dLog))
    # Eagar-Tsai 1983 prefactor: 2·η·Q / (ρ·Cp·(4π)^1.5)
    dT = (2.0 * p.eta * p.P / (p.rho * p.Cp * (4.0 * math.pi) ** 1.5)) * integral
    return min(p.T0 + dT, p.Tmelt + 200.0)


def meltpool_eagar_tsai(
    P_W: float,
    v_mm_s: float,
    alpha_m2_s: float,
    k_W_mK: float,
    T_m_C: float,
    T_0_C: float = 25.0,
    eta: float = 0.4,
    spot_mm: float = 0.08,
    rho_kg_m3: float = 8000.0,
    Cp_J_kgK: Optional[float] = None,
) -> dict[str, float]:
    """Eagar-Tsai 1983 ellipsoidal-source melt-pool prediction."""

    Cp = Cp_J_kgK if Cp_J_kgK is not None else (k_W_mK / max(alpha_m2_s * rho_kg_m3, 1e-12))
    p = AMProcessInput(
        P=P_W, v=v_mm_s, eta=eta, T0=T_0_C, Tmelt=T_m_C,
        k=k_W_mK, rho=rho_kg_m3, Cp=Cp, spotMm=spot_mm,
    )

    def Tfield(xi: float, y: float, z: float) -> float:
        return eagar_tsai_T(p, xi, y, z, spot_mm, spot_mm, spot_mm)

    return _meltpool_metrics_from_field(Tfield, p, scan_window_mm=5.0)


# ---------------------------------------------------------------------------
# 4. Goldak 1984 double-ellipsoid
# ---------------------------------------------------------------------------


@dataclass
class GoldakParams:
    """Goldak-Chakravarti-Bibby 1984 double-ellipsoid geometry."""

    a_front: float      # forward semi-axis, mm
    a_rear: float       # rearward semi-axis, mm
    b: float            # transverse half-width, mm
    c: float            # depth half-axis, mm
    f_front: float      # front power fraction (rear = 2 − f_front)


def goldak_T(
    p: AMProcessInput,
    g: GoldakParams,
    xi_m: float,
    y_m: float,
    z_m: float,
) -> float:
    """Goldak double-ellipsoid temperature = sum of two Eagar-Tsai integrals.

    Front half uses (a_front, b, c) with fraction f_front of total Q;
    rear half (a_rear, b, c) with (2 − f_front) of Q.
    """

    # Front half — weighted Eagar-Tsai
    Pf = AMProcessInput(
        P=p.P, v=p.v, eta=p.eta * g.f_front, T0=p.T0, Tmelt=p.Tmelt,
        k=p.k, rho=p.rho, Cp=p.Cp, spotMm=p.spotMm,
    )
    Pr = AMProcessInput(
        P=p.P, v=p.v, eta=p.eta * (2.0 - g.f_front), T0=p.T0, Tmelt=p.Tmelt,
        k=p.k, rho=p.rho, Cp=p.Cp, spotMm=p.spotMm,
    )
    Tf = eagar_tsai_T(Pf, xi_m, y_m, z_m, g.a_front, g.b, g.c)
    Tr = eagar_tsai_T(Pr, xi_m, y_m, z_m, g.a_rear, g.b, g.c)
    dT = (Tf - p.T0) + (Tr - p.T0)
    return min(p.T0 + dT, p.Tmelt + 200.0)


def meltpool_goldak(
    P_W: float,
    v_mm_s: float,
    alpha_m2_s: float,
    k_W_mK: float,
    T_m_C: float,
    T_0_C: float = 25.0,
    eta: float = 0.4,
    spot_mm: float = 0.08,
    rho_kg_m3: float = 8000.0,
    Cp_J_kgK: Optional[float] = None,
    f_front: float = 0.6,
) -> dict[str, float]:
    """Goldak-Chakravarti-Bibby 1984 double-ellipsoid melt-pool prediction.

    f_front defaults to 0.6 — Goldak 1984 fit for laser sources where the
    melt-pool tear-drop trails behind the heat source.
    """

    Cp = Cp_J_kgK if Cp_J_kgK is not None else (k_W_mK / max(alpha_m2_s * rho_kg_m3, 1e-12))
    p = AMProcessInput(
        P=P_W, v=v_mm_s, eta=eta, T0=T_0_C, Tmelt=T_m_C,
        k=k_W_mK, rho=rho_kg_m3, Cp=Cp, spotMm=spot_mm,
    )
    g = GoldakParams(
        a_front=spot_mm * 0.8,
        a_rear=spot_mm * 2.2,
        b=spot_mm * 1.0,
        c=spot_mm * 1.1,
        f_front=f_front,
    )

    def Tfield(xi: float, y: float, z: float) -> float:
        return goldak_T(p, g, xi, y, z)

    return _meltpool_metrics_from_field(Tfield, p, scan_window_mm=5.0)


# ---------------------------------------------------------------------------
# Shared melt-pool size + cooling-rate extractor
# ---------------------------------------------------------------------------


def _meltpool_metrics_from_field(
    Tfield: Callable[[float, float, float], float],
    p: AMProcessInput,
    scan_window_mm: float = 5.0,
) -> dict[str, float]:
    """Scan a 1-D centreline + 1-D y / z slice to extract L, W, D, Ṫ, G.

    Mirrors ``meltPoolMetrics`` in TS verbatim — same nXi=200, nY=100,
    nZ=50 grid resolution so verdicts agree across paths. Two-pass scan:
    a wide pass locates the pool, then a narrow refined pass extracts the
    precise dimensions and gradients with µm-scale resolution.
    """

    # Refined window: scale to the pool's characteristic Rosenthal length
    # L_ros ≈ 2·η·Q / (π·k·ΔT_melt). This gives a tight window even for
    # the highly localised LPBF heat source.
    L_ros_m = 2.0 * p.eta * p.P / (math.pi * p.k * max(50.0, p.Tmelt - p.T0))
    eff_window_mm = max(0.05, min(scan_window_mm, max(0.4, L_ros_m * 1500.0)))

    nXi = 200
    dXi = eff_window_mm * 1e-3 * 2.0 / nXi
    xiStart = -eff_window_mm * 1e-3
    xi_front = math.nan
    xi_rear = math.nan
    Tpeak = -math.inf
    xi_peak = 0.0
    Ts: list[float] = []
    xis: list[float] = []
    for i in range(nXi):
        xi = xiStart + i * dXi
        T = Tfield(xi, 0.0, 0.0)
        Ts.append(T)
        xis.append(xi)
        if T > Tpeak:
            Tpeak = T
            xi_peak = xi
    for i in range(nXi):
        if Ts[i] >= p.Tmelt and math.isnan(xi_front):
            xi_front = xis[i]
        if Ts[i] >= p.Tmelt:
            xi_rear = xis[i]
    if math.isnan(xi_front):
        return dict(
            L_mm=0.0, W_mm=0.0, D_mm=0.0, Tpeak_C=Tpeak,
            coolingRate_Ks=0.0, G_K_mm=0.0, V_s_mm_s=p.v, aspectRatio=1.0,
        )
    L_mm = (xi_rear - xi_front) * 1e3

    # width at xi_peak (y-scan) — bracket-search since the pool may be
    # very narrow (10s of µm for LPBF). Use a finer transverse window
    # equal to L_mm so we have ~1µm resolution at typical LPBF scales.
    transverse_window_m = max(L_mm * 1e-3, 50e-6)
    nY = 200
    dY = transverse_window_m * 2.0 / nY
    W_mm = 0.0
    for j in range(nY):
        y = -transverse_window_m + j * dY
        T = Tfield(xi_peak, y, 0.0)
        if T >= p.Tmelt and abs(y) * 2e3 > W_mm:
            W_mm = abs(y) * 2e3

    # depth at xi_peak (z-scan, negative z into substrate)
    depth_window_m = max(L_mm * 1e-3, 50e-6)
    nZ = 200
    dZ = depth_window_m / nZ
    D_mm = 0.0
    for k_idx in range(nZ):
        z = -k_idx * dZ
        T = Tfield(xi_peak, 0.0, z)
        if T >= p.Tmelt and abs(z) * 1e3 > D_mm:
            D_mm = abs(z) * 1e3

    # Cooling rate at solidification from the analytic Rosenthal 3D result
    #   Ṫ = 2π·k·v·(T_melt − T0)² / (η·P)
    # This is monotonic — it falls with laser power (larger pool ⇒ slower
    # quench) and rises with travel speed — unlike the previous
    # finite-difference-at-the-clamped-singularity estimate, which was
    # non-monotonic in P and 2-9× inflated.
    eps = max(0.5 * dXi, 1e-6)
    clip_T = p.Tmelt + 200.0
    v_ms = p.v * 1e-3
    dT_solid = max(50.0, p.Tmelt - p.T0)
    coolingRate_Ks = 2.0 * math.pi * p.k * v_ms * dT_solid ** 2 / max(p.eta * p.P, 1e-9)

    # gradient at front
    T_fp = Tfield(xi_front + eps, 0.0, 0.0)
    T_fm = Tfield(xi_front - eps, 0.0, 0.0)
    step = eps
    while abs(T_fp - clip_T) < 1e-3 and abs(T_fm - clip_T) < 1e-3 and step < 0.5e-3:
        step *= 2.0
        T_fp = Tfield(xi_front + step, 0.0, 0.0)
        T_fm = Tfield(xi_front - step, 0.0, 0.0)
    dTdXi_front = (T_fp - T_fm) / (2.0 * step)
    G_K_mm = abs(dTdXi_front) * 1e-3

    return dict(
        L_mm=L_mm,
        W_mm=W_mm,
        D_mm=D_mm,
        Tpeak_C=Tpeak,
        coolingRate_Ks=coolingRate_Ks,
        G_K_mm=G_K_mm,
        V_s_mm_s=p.v,
        aspectRatio=L_mm / W_mm if W_mm > 0 else 1.0,
    )


# ---------------------------------------------------------------------------
# 5. King-Khairallah process-window classifier
# ---------------------------------------------------------------------------


def king_khairallah_classifier(
    p: AMProcessInput,
    meltpool: Mapping[str, float],
    layer_thickness_mm: float,
) -> str:
    """King-Yancey-Khairallah 2014 + Khairallah 2016 process-window region.

    Returns one of: ``'keyhole'``, ``'lack-of-fusion'``, ``'balling'``,
    ``'conduction'``, ``'optimal'``.

    Criteria (mirrors classifyProcess in TS):
      - keyhole: ΔH / h_s > 30 (Khairallah-King 2016 LBPM keyhole criterion)
      - lack-of-fusion: melt depth D < 1.5 × layer thickness (Yadroitsev 2010)
      - balling: aspect ratio L/W > 2.3 (Plateau-Rayleigh instability)
      - conduction: aspect ratio < 1.5 AND ΔH/h_s < 6
      - optimal: everything else
    """

    r_m = (p.spotMm / 2.0) * 1e-3
    v_ms = p.v * 1e-3
    a = p.alpha()
    hSph = p.rho * p.Cp * p.Tmelt
    # King-Rubenchik 2014 / Hann-Iammi-Foley 2011 normalized enthalpy
    #   ΔH/h_s = η·P / (ρ·Cp·Tm · √(π·α·v·r³))
    # (the previous √(α/v)/(πr²v) denominator was dimensionally 1/√m and
    # ~50-80× too large, firing the keyhole branch unconditionally).
    denom = hSph * math.sqrt(math.pi * a * v_ms * r_m ** 3)
    normEnthalpy = (p.eta * p.P) / max(denom, 1e-30)
    D_mm = float(meltpool["D_mm"])
    aspect = float(meltpool["aspectRatio"])

    if normEnthalpy > 30:
        return "keyhole"
    if D_mm < 1.5 * layer_thickness_mm:
        return "lack-of-fusion"
    if aspect > 2.3:
        return "balling"
    if aspect < 1.5 and normEnthalpy < 6:
        return "conduction"
    return "optimal"


# ---------------------------------------------------------------------------
# 6. Kurz-Fisher solidification regime
# ---------------------------------------------------------------------------


def kurz_fisher_solidification(G_K_mm: float, V_mm_s: float) -> str:
    """Kurz-Fisher 1998 G / V_s morphology classifier (Fig. 4.30).

    Returns one of ``'planar'``, ``'cellular'``, ``'columnar-dendritic'``,
    ``'equiaxed-dendritic'``.

      - planar: G/V_s > 100 K·s/mm² (very high gradient or very slow)
      - cellular: 1 < G/V_s < 100
      - columnar-dendritic: 0.01 < G/V_s < 1 (most LPBF as-built)
      - equiaxed-dendritic: G/V_s < 0.01 (most casts, inoculated LPBF)
    """

    ratio = G_K_mm / max(V_mm_s, 1e-9)
    if ratio > 100:
        return "planar"
    if ratio > 1:
        return "cellular"
    if ratio > 0.01:
        return "columnar-dendritic"
    return "equiaxed-dendritic"


# ---------------------------------------------------------------------------
# 7. Maynier-Dollet ferrous hardness (Vickers HV30)
# ---------------------------------------------------------------------------


def maynier_dollet_HV30(
    alloy: str,
    composition: Optional[Mapping[str, float]] = None,
    cooling_rate: float = 100.0,
    phase: str = "martensite",
) -> float:
    """Maynier-Dollet 1978 multi-regression HV30 for ferrous alloys.

    Returns Vickers hardness HV30 (kgf/mm²) for the chosen microstructure.
    For non-ferrous alloys (composition None or no C key) falls back to a
    Hall-Petch surrogate: ``HV ≈ HV₀ + 6 · log₁₀(Ṫ)`` keyed off a base value
    in :data:`AM_BASE_HV`.

    Args:
        alloy: alloy ID — ignored when composition is provided, otherwise
            looked up in :data:`AM_BASE_HV`.
        composition: optional weight-% composition with keys
            ``C, Mn, Si, Ni, Cr, Mo, V``.
        cooling_rate: linear cooling rate, °C/s.
        phase: ``'ferrite-pearlite' | 'bainite' | 'martensite'`` (default).
    """

    Vr = max(0.01, float(cooling_rate))
    logV = math.log10(Vr)

    if composition is not None and composition.get("C") is not None:
        C = float(composition["C"])
        Mn = float(composition.get("Mn", 0.0))
        Si = float(composition.get("Si", 0.0))
        Ni = float(composition.get("Ni", 0.0))
        Cr = float(composition.get("Cr", 0.0))
        Mo = float(composition.get("Mo", 0.0))
        V = float(composition.get("V", 0.0))
        if phase == "ferrite-pearlite":
            HV = (42 + 223 * C + 53 * Si + 30 * Mn + 12.6 * Ni + 7 * Cr + 19 * Mo
                  + (10 - 19 * Si + 4 * Ni + 8 * Cr + 130 * V) * logV)
        elif phase == "bainite":
            HV = (-323 + 185 * C + 330 * Si + 153 * Mn + 65 * Ni + 144 * Cr + 191 * Mo
                  + (89 + 53 * C - 55 * Si - 22 * Mn - 10 * Ni - 20 * Cr - 33 * Mo) * logV)
        else:  # martensite
            HV = (127 + 949 * C + 27 * Si + 11 * Mn + 8 * Ni + 16 * Cr + 21 * logV)
        return max(50.0, HV)

    base = AM_BASE_HV.get(alloy, 250.0)
    return base + max(0.0, min(60.0, 6.0 * logV))


# Hall-Petch base hardness for non-ferrous alloys (mirrors TS `baseHV`).
AM_BASE_HV: dict[str, float] = {
    "Ti-6Al-4V": 340.0,
    "AlSi10Mg": 130.0,
    "IN718": 380.0,
    "IN625": 280.0,
    "CoCr-MP1": 400.0,
    "17-4PH": 380.0,
    "SS316L": 220.0,
    "CuCrZr": 180.0,
}


def hv_to_hrc(HV: float) -> float:
    """Convert HV30 to HRC via ASTM E140 piecewise/polynomial.

    Mirrors ``HVtoHRC`` in TS — low-HV linear fallback for HV<240; cubic
    polynomial fit to ASTM E140 Table 3 for steel HV 240-840.
    """

    if HV < 240:
        return max(0.0, (HV - 100.0) / 7.0)  # ≈20 HRC at HV 240 (continuous)
    # Quadratic fit to ASTM E140 Table 3 anchors
    # (240→20.3, 400→40.8, 600→55.2, 800→64.0):
    HRC = -19.38 + 0.1915 * HV - 1.091e-4 * HV * HV
    return max(0.0, min(70.0, HRC))


# ---------------------------------------------------------------------------
# 8. Pavlina-Tyne 2008 σ_y, σ_UTS from HV
# ---------------------------------------------------------------------------


def pavlina_tyne_sigma_y(HV: float) -> float:
    """Pavlina-Tyne 2008 linear fit σ_y = 2.876 · HV − 90.7  (MPa).

    Calibrated across 150+ steel grades to ±50 MPa within HV 100-700.
    """

    return max(0.0, 2.876 * float(HV) - 90.7)


def pavlina_tyne_sigma_uts(HV: float) -> float:
    """Pavlina-Tyne 2008 σ_UTS = −99.8 + 3.734 · HV (MPa).

    The published linear fit (Mater. Sci. Eng. A 480 (2008) 132) across
    150+ steel grades; the prior 3.0·HV approximation ran ~10-15 % low.
    """

    return max(0.0, -99.8 + 3.734 * float(HV))


def elongation_from_HV(HV: float) -> float:
    """Roberts-Newton-style empirical elongation, % from HV.

    Approx. 40% at HV=200 down to 5% at HV=600. Clipped to [2, 40].
    """

    return max(2.0, min(40.0, 40.0 - 0.065 * (float(HV) - 200.0)))


def cvn_from_HV(HV: float) -> float:
    """Roberts-Newton-style empirical CVN, J from HV.

    Lower-shelf trend: ``CVN ≈ 290 · exp(−HV/280)`` floored at 2 J.
    """

    return max(2.0, 290.0 * math.exp(-float(HV) / 280.0))


# ---------------------------------------------------------------------------
# 9. Barsom-Rolfe K_Ic from CVN
# ---------------------------------------------------------------------------


def barsom_rolfe_KIc(E_GPa: float, CVN_J: float) -> float:
    """Barsom-Rolfe 1972 lower-shelf K_Ic from Charpy V-notch (CVN).

    ``K_Ic² = 5 · E · CVN``  (English units originally; in SI this is
    ``K_Ic² [MPa²·m] = 5 · E [MPa] · CVN [J]`` divided by 1000 to give
    K_Ic in MPa·√m).

    Args:
        E_GPa: Young's modulus, GPa.
        CVN_J: Charpy V-notch energy, J.

    Returns:
        K_Ic in MPa·√m.
    """

    E_MPa = E_GPa * 1000.0
    K_squared_div1000 = 5.0 * E_MPa * CVN_J / 1000.0
    return math.sqrt(max(0.0, K_squared_div1000))


def endurance_from_uts(UTS_MPa: float) -> float:
    """Goodman / Basquin endurance limit ≈ 0.5 · σ_UTS, capped at 700 MPa."""

    return min(700.0, 0.5 * float(UTS_MPa))


# ---------------------------------------------------------------------------
# 10. ASTM compliance check
# ---------------------------------------------------------------------------


def astm_compliance_check(
    properties: Mapping[str, float],
    spec_id: Optional[str] = None,
    region: str = "optimal",
) -> dict[str, Any]:
    """ASTM F3055 / F3001 / F3184 / F3318 / F3301 minimum-property gate.

    Args:
        properties: dict with at least ``sigma_y_MPa``, ``sigma_uts_MPa``,
            ``elongation_pct``.
        spec_id: optional alloy ID — looked up in
            :data:`ASTM_MIN_PROPERTIES`. Pass ``None`` to skip the gate.
        region: process region from :func:`king_khairallah_classifier`;
            only ``'optimal'`` counts toward an overall PASS.

    Returns:
        ``{spec, sigma_y_pass, sigma_uts_pass, elongation_pass,
          overall_pass, notes}``.
    """

    astm_spec = ASTM_MIN_PROPERTIES.get(spec_id) if spec_id else None
    notes: list[str] = []
    sy_pass = True
    uts_pass = True
    el_pass = True
    overall = True

    sigma_y = float(properties.get("sigma_y_MPa", 0.0))
    sigma_uts = float(properties.get("sigma_uts_MPa", 0.0))
    elong = float(properties.get("elongation_pct", 0.0))

    if astm_spec is not None:
        sy_pass = sigma_y >= astm_spec["sigma_y_min_MPa"]
        uts_pass = sigma_uts >= astm_spec["sigma_uts_min_MPa"]
        el_pass = elong >= astm_spec["elongation_min_pct"]
        overall = sy_pass and uts_pass and el_pass and (region == "optimal")
        if not sy_pass:
            notes.append(
                f"σ_y predicted {sigma_y:.0f} < {astm_spec['sigma_y_min_MPa']} MPa ({astm_spec['spec']})"
            )
        if not uts_pass:
            notes.append(
                f"σ_uts predicted {sigma_uts:.0f} < {astm_spec['sigma_uts_min_MPa']} MPa"
            )
        if not el_pass:
            notes.append(
                f"elongation predicted {elong:.1f} < {astm_spec['elongation_min_pct']} %"
            )
        if region != "optimal":
            notes.append(
                f"process region '{region}' — re-tune parameters before qualification"
            )
    else:
        notes.append(
            f"No built-in ASTM spec for {spec_id!r} — using ASM-Handbook surrogate properties."
        )

    return dict(
        spec=astm_spec["spec"] if astm_spec else None,
        sigma_y_pass=sy_pass,
        sigma_uts_pass=uts_pass,
        elongation_pass=el_pass,
        overall_pass=overall,
        notes=notes,
    )


# ---------------------------------------------------------------------------
# Full AM qualification pipeline (port of runAMQualification in TS)
# ---------------------------------------------------------------------------


def run_qualification_native(
    *,
    alloy: str,
    power_W: float,
    velocity_mm_s: float,
    hatch_mm: float,
    layer_mm: float,
    eta: Optional[float] = None,
    T0_C: float = 100.0,
    spot_mm: Optional[float] = None,
    model: str = "rosenthal",
    cooling_rate_Cs: Optional[float] = None,
    chemistry: Optional[Mapping[str, float]] = None,
    spec: Optional[str] = None,
) -> dict[str, Any]:
    """Full 10-stage AM qualification chain — offline / native.

    Inputs accept either the legacy snake_case keys (``power_W`` etc.) or
    the AmQualificationInput Pydantic style keys via the wrapper in
    :func:`run_from_pydantic`.

    Returns a dict shaped like the TS ``QualificationResult`` so the
    Pydantic adapter in :mod:`austenite.am` can lift it into
    :class:`AmQualificationResult` without surprises.
    """

    # ── alloy library lookup ──
    alloy_lib = AM_ALLOY_LIBRARY.get(alloy)
    alloy_props = None
    if alloy_lib:
        alloy_props = dict(
            name=alloy_lib["name"],
            Tmelt_C=alloy_lib["Tmelt"],
            k_W_mK=alloy_lib["k"],
            rho_kg_m3=alloy_lib["rho"],
            Cp_J_kgK=alloy_lib["Cp"],
            ref=alloy_lib["ref"],
        )

    Tmelt = alloy_lib["Tmelt"] if alloy_lib else 1500.0
    k = alloy_lib["k"] if alloy_lib else 30.0
    rho = alloy_lib["rho"] if alloy_lib else 8000.0
    Cp = alloy_lib["Cp"] if alloy_lib else 500.0
    eta_eff = (
        float(eta) if eta is not None
        else (alloy_lib["defaultEta"] if alloy_lib else 0.35)
    )
    spot_eff = (
        float(spot_mm) if spot_mm is not None
        else (alloy_lib["defaultSpot"] if alloy_lib else 0.080)
    )

    # ── Stage 1: VED ──
    VED = volumetric_energy_density(power_W, velocity_mm_s, hatch_mm, layer_mm)
    if VED < 30:
        ved_verdict = "too low (LoF)"
    elif VED > 120:
        ved_verdict = "too high (keyhole)"
    else:
        ved_verdict = "optimal"

    # ── Stage 2-3: melt-pool ──
    p = AMProcessInput(
        P=max(1.0, power_W),
        v=max(0.1, velocity_mm_s),
        eta=max(0.05, min(0.95, eta_eff)),
        T0=T0_C,
        Tmelt=Tmelt,
        k=k,
        rho=rho,
        Cp=Cp,
        spotMm=max(0.01, spot_eff),
    )
    if model == "rosenthal":
        def Tfield(xi: float, y: float, z: float) -> float:
            return rosenthal_T(p, xi, y, z)
    elif model == "goldak":
        g = GoldakParams(
            a_front=p.spotMm * 0.8,
            a_rear=p.spotMm * 2.2,
            b=p.spotMm * 1.0,
            c=p.spotMm * 1.1,
            f_front=0.6,
        )

        def Tfield(xi: float, y: float, z: float) -> float:
            return goldak_T(p, g, xi, y, z)
    else:
        def Tfield(xi: float, y: float, z: float) -> float:
            return eagar_tsai_T(p, xi, y, z, p.spotMm, p.spotMm, p.spotMm)

    mp = _meltpool_metrics_from_field(Tfield, p, scan_window_mm=5.0)
    region = king_khairallah_classifier(p, mp, layer_mm)
    mp["region"] = region

    # ── Stage 4-5: solidification regime ──
    regime = kurz_fisher_solidification(mp["G_K_mm"], mp["V_s_mm_s"])
    if regime == "planar":
        grain_morph = "planar front (rare)"
    elif regime == "cellular":
        grain_morph = "cellular"
    elif regime == "columnar-dendritic":
        grain_morph = "columnar dendritic (typical LPBF as-built)"
    else:
        grain_morph = "equiaxed dendritic (usually requires inoculation or hot-iso treatment)"

    # ── Stage 6: hardness ──
    if chemistry is not None and chemistry.get("C") is not None:
        Vr_use = cooling_rate_Cs if cooling_rate_Cs is not None else max(1.0, mp["coolingRate_Ks"])
        HV30 = maynier_dollet_HV30(alloy, chemistry, Vr_use, phase="martensite")
    else:
        HV30 = maynier_dollet_HV30(alloy, None, cooling_rate_Cs or max(1.0, mp["coolingRate_Ks"]))

    HRC = hv_to_hrc(HV30)

    # ── Stage 7-9 ──
    sigma_uts = pavlina_tyne_sigma_uts(HV30)
    sigma_y = pavlina_tyne_sigma_y(HV30)
    elong = elongation_from_HV(HV30)
    CVN = cvn_from_HV(HV30)
    KIc = barsom_rolfe_KIc(E_GPa=207.0, CVN_J=CVN)
    endurance = endurance_from_uts(sigma_uts)

    properties = dict(
        HV30=float(HV30),
        HRC=float(HRC),
        sigma_y_MPa=float(sigma_y),
        sigma_uts_MPa=float(sigma_uts),
        elongation_pct=float(elong),
        KIc_MPa_sqm=float(KIc),
        sigma_endurance_MPa=float(endurance),
    )

    # ── Stage 10: ASTM compliance ──
    spec_id = spec if spec else alloy
    compliance = astm_compliance_check(properties, spec_id=spec_id, region=region)

    # ── post-process: porosity / RS / Ra / anisotropy / recs ──
    if VED < 30:
        porosity_pct = max(0.5, 2.0 + 0.1 * (30 - VED))
        porosity_verdict = "lack-of-fusion (irregular porosity, anisotropic)"
    elif VED > 110:
        porosity_pct = max(0.3, 0.05 * (VED - 110))
        porosity_verdict = "keyhole (spherical entrapped vapour porosity)"
    elif VED < 50 or VED > 90:
        porosity_pct = 0.5
        porosity_verdict = "marginal (0.3-1 vol %)"
    else:
        porosity_pct = 0.1
        porosity_verdict = "optimal (< 0.5 vol %)"
    porosity_after_HIP = min(porosity_pct, 0.08)

    RS_factor = {
        "SS316L": 0.65, "IN718": 0.70, "Ti-6Al-4V": 0.55, "AlSi10Mg": 0.30,
        "CoCr-MP1": 0.65, "17-4PH": 0.70, "IN625": 0.65,
    }
    RS_fac = RS_factor.get(alloy, 0.55)
    residual_stress = min(
        sigma_y * 0.95,
        sigma_y * RS_fac + 50.0 * math.log10(max(1.0, mp["coolingRate_Ks"])),
    )

    Ra = max(3.0, 4.0 + 30.0 * layer_mm + 10.0 * math.tan(0.1))

    anisotropy = {
        "SS316L": 0.92, "IN718": 0.88, "Ti-6Al-4V": 0.85, "AlSi10Mg": 0.95,
        "CoCr-MP1": 0.90, "17-4PH": 0.93,
    }
    aniso = anisotropy.get(alloy, 0.90)

    postproc_recs: list[str] = []
    if residual_stress > sigma_y * 0.4:
        postproc_recs.append(
            f"Stress-relief required (residual ~{residual_stress:.0f} MPa "
            f"= {(residual_stress / max(1e-6, sigma_y)) * 100:.0f}% of σ_y)."
        )
    if porosity_pct > 0.5:
        hip_note = (
            "920 °C / 100 MPa / 2 h Ar" if alloy == "Ti-6Al-4V"
            else "1163 °C / 100 MPa / 4 h Ar" if alloy == "IN718"
            else "consult ASTM F3301 / vendor data"
        )
        postproc_recs.append(
            f"HIP recommended: {hip_note} to close porosity from {porosity_pct:.2f} → < 0.1 %."
        )
    if Ra > 12:
        postproc_recs.append(
            f"Surface finish Ra ~ {Ra:.1f} µm — machine critical surfaces if fatigue/sealing matters."
        )
    if alloy == "IN718":
        postproc_recs.append(
            "Standard heat-treat: solution 980 °C / 1 h + age 720 °C / 8 h + 620 °C / 8 h (AMS 5662)."
        )
    if alloy == "Ti-6Al-4V":
        postproc_recs.append(
            "Standard heat-treat: stress-relief 600 °C / 4 h Ar + optional STA 925 °C + 540 °C / 4 h."
        )
    if alloy == "17-4PH":
        postproc_recs.append(
            "Standard: solution-anneal 1040 °C + age H900 (482 °C / 1 h) → max σ_y ~ 1170 MPa."
        )
    if not postproc_recs:
        postproc_recs.append("No post-process required for this parameter set.")

    # ── Cost / productivity ──
    depRate_mm3_s = velocity_mm_s * hatch_mm * layer_mm
    depRate_cm3_h = depRate_mm3_s * 3.6
    buildTime_h = 100.0 / max(0.001, depRate_cm3_h)
    gas_m3_h = 5.0
    powder_USD_per_kg = {
        "SS316L": 80, "IN718": 250, "IN625": 220, "Ti-6Al-4V": 320, "AlSi10Mg": 70,
        "CoCr-MP1": 240, "17-4PH": 110, "CuCrZr": 350, "Maraging-300": 180,
        "W-pure": 800, "Mo-TZM": 700, "IN939": 300, "CM247LC": 350,
    }
    powder_cost = powder_USD_per_kg.get(alloy, 200)
    cost_material_per_cm3 = powder_cost * rho * 1e-6
    cost_machine_per_cm3 = 60.0 / max(0.001, depRate_cm3_h)
    cost_gas_per_cm3 = gas_m3_h * 1.0 / max(0.001, depRate_cm3_h)
    cost_per_cm3 = cost_material_per_cm3 + cost_machine_per_cm3 + cost_gas_per_cm3

    # ── Headline ──
    pass_overall = compliance["overall_pass"]
    sy_pass = compliance["sigma_y_pass"]
    uts_pass = compliance["sigma_uts_pass"]
    astm_spec = ASTM_MIN_PROPERTIES.get(spec_id) if spec_id else None
    if pass_overall and region == "optimal":
        risk_color = "green"
    elif region == "optimal" or (astm_spec and sy_pass and uts_pass):
        risk_color = "yellow"
    else:
        risk_color = "red"
    if astm_spec:
        if pass_overall:
            verdict = f"PASS — meets {astm_spec['spec']} minimums in '{region}' build regime"
        else:
            n = len(compliance["notes"])
            verdict = f"FAIL — {n} non-conformance{'s' if n != 1 else ''} vs {astm_spec['spec']}"
    else:
        verdict = (
            f"INFO — no ASTM spec for {alloy}; properties predicted "
            f"{sigma_uts:.0f} MPa UTS, {elong:.0f}% el"
        )

    return dict(
        input=dict(
            alloy=alloy, power_W=power_W, velocity_mm_s=velocity_mm_s,
            hatch_mm=hatch_mm, layer_mm=layer_mm, eta=eta_eff, T0_C=T0_C,
            spot_mm=spot_eff, model=model, cooling_rate_Cs=cooling_rate_Cs,
        ),
        alloy_props=alloy_props,
        ved=dict(VED_J_mm3=float(VED), verdict=ved_verdict),
        meltpool=mp,
        solidification=dict(
            GoverV_Ksmm2=mp["G_K_mm"] / max(1.0, mp["V_s_mm_s"]),
            regime=regime,
            grain_morphology=grain_morph,
        ),
        properties=properties,
        astm=compliance,
        postprocess=dict(
            porosity_pct=float(porosity_pct),
            porosity_verdict=porosity_verdict,
            porosity_after_HIP_pct=float(porosity_after_HIP),
            residual_stress_MPa=float(residual_stress),
            surface_Ra_um=float(Ra),
            anisotropy_z_over_xy=float(aniso),
            recommendations=postproc_recs,
        ),
        cost=dict(
            deposition_rate_cm3_h=float(depRate_cm3_h),
            build_time_100cm3_h=float(buildTime_h),
            gas_consumption_m3_h=float(gas_m3_h),
            cost_per_cm3_USD=float(cost_per_cm3),
        ),
        headline=dict(
            pass_=bool(pass_overall),
            risk_color=risk_color,
            verdict=verdict,
        ),
    )


__all__ = [
    "AMProcessInput",
    "GoldakParams",
    "AM_ALLOY_LIBRARY",
    "ASTM_MIN_PROPERTIES",
    "AM_BASE_HV",
    "volumetric_energy_density",
    "rosenthal_T",
    "meltpool_rosenthal",
    "eagar_tsai_T",
    "meltpool_eagar_tsai",
    "goldak_T",
    "meltpool_goldak",
    "king_khairallah_classifier",
    "kurz_fisher_solidification",
    "maynier_dollet_HV30",
    "hv_to_hrc",
    "pavlina_tyne_sigma_y",
    "pavlina_tyne_sigma_uts",
    "elongation_from_HV",
    "cvn_from_HV",
    "barsom_rolfe_KIc",
    "endurance_from_uts",
    "astm_compliance_check",
    "run_qualification_native",
]
