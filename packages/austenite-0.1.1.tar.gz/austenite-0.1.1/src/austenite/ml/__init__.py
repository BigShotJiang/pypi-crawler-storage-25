"""Machine-learning bridges — MACE-MP-0 foundation MLIP, etc.

Sub-modules:

* :mod:`austenite.ml.mace_bridge` — MACE-MP-0 (Batatia 2024) bridge for
  DFT-quality endmember Gibbs energies and CALPHAD priors.

Optional heavy dependencies (``mace-torch``, ``ase``) are guarded with
informative ``ImportError`` messages pointing to ``pip install
austenite[mlip]``.
"""

from __future__ import annotations

from .mace_bridge import (
    MaceImportError,
    MacePriorResult,
    mace_mp_endmember_G,
    mace_mp_prior,
)

__all__ = [
    "MaceImportError",
    "MacePriorResult",
    "mace_mp_endmember_G",
    "mace_mp_prior",
]
