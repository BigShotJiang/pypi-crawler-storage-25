"""``austenite`` command-line interface.

After ``pip install austenite`` engineers get a single binary that wraps
the same surfaces the Python SDK exposes::

    $ austenite design-path --alloy "AISI 4140" --cooling 10 --json result.json
    $ austenite am qualification --alloy IN718 --P 285 --v 960 --h 0.11 --t 0.04
    $ austenite mtc parse cert.pdf
    $ austenite mtc audit-lot certs/ --spec "ASTM A29" --output audit.xlsx
    $ austenite ttt cct-sweep --alloy "AISI 4140" --rates "1,10,100"
    $ austenite calphad equilibrium --composition '{"Fe":0.74,"Cr":0.18,"Ni":0.08}' --T 1273
    $ austenite bayesian calphad --dataset hammar-1979-sigma --samples 10000
    $ austenite ffs api579-part5 --geometry geom.json --thickness ut.csv --output report.pdf
    $ austenite benchmark run-all --json scores.json
    $ austenite version
    $ austenite plugins list

Design notes:

* Built on `click <https://click.palletsprojects.com>`_ so we get
  groups, nested ``--help``, type coercion, prompt-fall-back, and
  exit-code handling for free.
* Exit codes follow standard convention:
    - ``0`` success
    - ``1`` runtime / engine error (e.g. HTTP failure)
    - ``2`` validation error (bad arguments or missing dependencies)
* Every command honours ``--quiet`` / ``--verbose`` / ``--no-color`` set
  on the *root* group, propagated through Click's context.
* Optional heavy dependencies (pandas, reportlab, openpyxl, pypdf ...) are
  imported lazily inside the command callback and produce a clear error
  message if missing -- ``pip install 'austenite[xlsx]'`` etc.

References:
  * Click documentation -- https://click.palletsprojects.com/
  * argparse vs Click  -- https://click.palletsprojects.com/en/stable/why/
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Mapping, Optional

import click

from . import __version__ as VERSION

# ---------------------------------------------------------------------------
# Exit codes -- published in --help so callers know what to expect.
# ---------------------------------------------------------------------------
EXIT_OK = 0
EXIT_ERROR = 1
EXIT_VALIDATION = 2


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _emit_json(payload: Any, path: Optional[Path], ctx: click.Context) -> None:
    """Write JSON either to a file or to stdout (with optional indent)."""

    text = json.dumps(payload, indent=2, default=_json_default)
    if path is not None:
        Path(path).write_text(text, encoding="utf-8")
        if not ctx.obj.get("quiet"):
            click.echo(f"wrote {path}")
    else:
        click.echo(text)


def _json_default(obj: Any) -> Any:
    """JSON fallback for Pydantic models / dataclasses / numpy."""

    if hasattr(obj, "model_dump"):
        return obj.model_dump()  # pydantic v2
    if hasattr(obj, "__dict__"):
        return obj.__dict__
    if hasattr(obj, "tolist"):
        return obj.tolist()  # numpy / pandas
    return str(obj)


def _parse_composition(value: Optional[str]) -> Optional[dict[str, float]]:
    """Accept a JSON object string or a comma list (``Fe=0.7,Cr=0.18``)."""

    if value is None:
        return None
    value = value.strip()
    if not value:
        return None
    if value.startswith("{"):
        return {str(k): float(v) for k, v in json.loads(value).items()}
    if value.startswith("@"):
        # Read from file: --composition @path/to/comp.json
        return {str(k): float(v) for k, v in json.loads(Path(value[1:]).read_text(encoding="utf-8")).items()}
    out: dict[str, float] = {}
    for part in value.split(","):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            raise click.BadParameter(f"bad token '{part}' -- use Fe=0.7,Cr=0.18 or JSON")
        k, v = part.split("=", 1)
        out[k.strip()] = float(v.strip())
    return out


def _verbose(ctx: click.Context, *parts: Any) -> None:
    if ctx.obj.get("verbose"):
        click.echo(" ".join(str(p) for p in parts), err=True)


def _fail(ctx: click.Context, message: str, *, exit_code: int = EXIT_ERROR) -> None:
    """Print an error message and exit. Honours ``--no-color``."""

    use_color = not ctx.obj.get("no_color", False)
    click.echo(
        click.style(f"error: {message}", fg="red") if use_color else f"error: {message}",
        err=True,
    )
    ctx.exit(exit_code)


# ---------------------------------------------------------------------------
# Root group
# ---------------------------------------------------------------------------


@click.group(
    context_settings={"help_option_names": ["-h", "--help"], "max_content_width": 100},
    invoke_without_command=False,
)
@click.option("--api-url", envvar="AUSTENITE_API_URL", help="Override the API base URL.")
@click.option("--api-key", envvar="AUSTENITE_API_KEY", help="Bearer token for authentication.")
@click.option("--timeout", type=float, envvar="AUSTENITE_TIMEOUT", help="Per-request timeout (seconds).")
@click.option("--quiet", "-q", is_flag=True, help="Suppress incidental output (stamps, progress).")
@click.option("--verbose", "-v", is_flag=True, help="Echo extra diagnostics to stderr.")
@click.option("--no-color", is_flag=True, envvar="NO_COLOR", help="Disable ANSI colour codes.")
@click.version_option(VERSION, "--version", "-V", message="austenite %(version)s")
@click.pass_context
def cli(
    ctx: click.Context,
    api_url: Optional[str],
    api_key: Optional[str],
    timeout: Optional[float],
    quiet: bool,
    verbose: bool,
    no_color: bool,
) -> None:
    """Austenite -- Bayesian end-to-end materials engineering.

    Exit codes: 0 success | 1 engine error | 2 validation error.

    Set ``AUSTENITE_API_URL`` / ``AUSTENITE_API_KEY`` to avoid passing them
    every call.  ``AUSTENITE_OFFLINE=1`` forces the native pure-Python
    CALPHAD backend (no network access required).
    """

    ctx.ensure_object(dict)
    ctx.obj.update(quiet=quiet, verbose=verbose, no_color=no_color)
    if api_url or api_key or timeout:
        # Update the package-level config without importing the rest of
        # austenite eagerly -- those imports are deferred to the commands.
        import austenite as au

        if api_url:
            au.set_api_url(api_url)
        if api_key:
            au.set_api_key(api_key)
        if timeout is not None:
            au.set_timeout(timeout)


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------


@cli.command("version")
@click.pass_context
def version(ctx: click.Context) -> None:
    """Print the installed austenite version."""

    click.echo(f"austenite {VERSION}")


# ---------------------------------------------------------------------------
# design-path
# ---------------------------------------------------------------------------


@cli.command("design-path")
@click.option("--alloy", help="Named alloy grade (e.g. 'AISI 4140').")
@click.option("--composition", help='Composition map: JSON `{"Fe":0.7,...}` or `Fe=0.7,Cr=0.18`.')
@click.option("--cooling", "cooling_rate", type=float, default=10.0, show_default=True,
              help="Cooling rate, K/s.")
@click.option("--T0", "T0_C", type=float, default=850.0, show_default=True,
              help="Austenitization temperature, degC.")
@click.option("--grain-size", "grain_size_ASTM", type=int, default=7, show_default=True,
              help="Prior austenite grain size (ASTM number).")
@click.option("--spec", help="Optional compliance spec (e.g. 'ASME-VIII-Div2').")
@click.option("--sigma-app", "sigma_app_MPa", type=float, help="Applied stress for fatigue check.")
@click.option("--posterior", is_flag=True, help="Return Bayesian posterior bands.")
@click.option("--json", "json_out", type=click.Path(dir_okay=False), help="Write result JSON to file.")
@click.pass_context
def cmd_design_path(
    ctx: click.Context,
    alloy: Optional[str],
    composition: Optional[str],
    cooling_rate: float,
    T0_C: float,
    grain_size_ASTM: int,
    spec: Optional[str],
    sigma_app_MPa: Optional[float],
    posterior: bool,
    json_out: Optional[str],
) -> None:
    """Run the full composition -> fatigue-life ICME chain."""

    if not alloy and not composition:
        _fail(ctx, "supply either --alloy or --composition", exit_code=EXIT_VALIDATION)

    try:
        comp = _parse_composition(composition)
    except (json.JSONDecodeError, ValueError) as e:
        _fail(ctx, f"bad --composition: {e}", exit_code=EXIT_VALIDATION)
        return  # unreachable, but keeps mypy happy

    try:
        import austenite as au
        _verbose(ctx, "calling au.design_path...")
        result = au.design_path(
            alloy=alloy, composition=comp,
            cooling_rate=cooling_rate, T0_C=T0_C,
            grain_size_ASTM=grain_size_ASTM,
            spec=spec, sigma_app_MPa=sigma_app_MPa,
            posterior=posterior,
        )
    except Exception as e:  # noqa: BLE001 - propagate as CLI error
        _fail(ctx, f"design-path failed: {e}")
        return

    _emit_json(result.model_dump(), Path(json_out) if json_out else None, ctx)


# ---------------------------------------------------------------------------
# am group
# ---------------------------------------------------------------------------


@cli.group("am")
def am_group() -> None:
    """Additive-manufacturing qualification."""


@am_group.command("qualification")
@click.option("--alloy", required=True, help="Alloy grade (e.g. 'IN718').")
@click.option("-P", "--P", "laser_power_W", required=True, type=float, help="Laser power, W.")
@click.option("-v", "--v", "scan_speed_mm_s", required=True, type=float, help="Scan speed, mm/s.")
@click.option("-h", "--h", "hatch_um", required=True, type=float, help="Hatch spacing, um.")
@click.option("-t", "--t", "layer_um", required=True, type=float, help="Layer thickness, um.")
@click.option("--process", default="LPBF", show_default=True,
              type=click.Choice(["LPBF", "DED", "EBM"], case_sensitive=False))
@click.option("--spec", help="Compliance spec (e.g. 'ASTM-F3055').")
@click.option("--json", "json_out", type=click.Path(dir_okay=False))
@click.pass_context
def cmd_am_qualification(
    ctx: click.Context,
    alloy: str,
    laser_power_W: float,
    scan_speed_mm_s: float,
    hatch_um: float,
    layer_um: float,
    process: str,
    spec: Optional[str],
    json_out: Optional[str],
) -> None:
    """Predict AM part quality (ASTM F3055/F3001/F3187 check)."""

    try:
        import austenite as au
        result = au.am.qualification(
            alloy=alloy,
            laser_power_W=laser_power_W,
            scan_speed_mm_s=scan_speed_mm_s,
            hatch_um=hatch_um,
            layer_um=layer_um,
            process=process,
            spec=spec,
        )
    except Exception as e:
        _fail(ctx, f"am qualification failed: {e}")
        return

    _emit_json(result.model_dump(), Path(json_out) if json_out else None, ctx)


# ---------------------------------------------------------------------------
# mtc group
# ---------------------------------------------------------------------------


@cli.group("mtc")
def mtc_group() -> None:
    """Material Test Certificate parse / detect / audit."""


@mtc_group.command("parse")
@click.argument("source", type=click.Path(exists=True, dir_okay=False))
@click.option("--language", default="auto", show_default=True,
              help="ISO 639-1 code or 'auto'.")
@click.option("--no-ocr", is_flag=True, help="Disable Tesseract OCR fallback.")
@click.option("--json", "json_out", type=click.Path(dir_okay=False))
@click.pass_context
def cmd_mtc_parse(
    ctx: click.Context,
    source: str,
    language: str,
    no_ocr: bool,
    json_out: Optional[str],
) -> None:
    """Parse a single Material Test Certificate (PDF / image / text)."""

    try:
        import austenite as au
        result = au.mtc.parse(source=source, language=language, ocr=not no_ocr)
    except ImportError as e:
        _fail(ctx, f"missing optional dep: {e}; install with `pip install 'austenite[ocr]'`",
              exit_code=EXIT_VALIDATION)
        return
    except Exception as e:
        _fail(ctx, f"mtc parse failed: {e}")
        return

    _emit_json(result.model_dump(), Path(json_out) if json_out else None, ctx)


@mtc_group.command("audit-lot")
@click.argument("folder", type=click.Path(exists=True, file_okay=False))
@click.option("--spec", required=True, help="Spec to audit against (e.g. 'ASTM A29').")
@click.option("--period", help="Reporting period (e.g. '2026-Q2').")
@click.option("--output", "-o", type=click.Path(dir_okay=False),
              help="Output path (.xlsx / .json -- inferred from extension).")
@click.option("--workers", type=int, default=10, show_default=True)
@click.pass_context
def cmd_mtc_audit_lot(
    ctx: click.Context,
    folder: str,
    spec: str,
    period: Optional[str],
    output: Optional[str],
    workers: int,
) -> None:
    """Audit every cert in a folder against a spec."""

    try:
        import austenite as au
        _verbose(ctx, f"batch-parsing certs in {folder}...")
        df = au.mtc.batch_parse(folder, workers=workers)
        _verbose(ctx, f"parsed {len(df)} certs; auditing against {spec}...")
        report = au.mtc.audit_lot(df, spec=spec, period=period)
    except ImportError as e:
        _fail(ctx, f"missing optional dep: {e}; install with `pip install 'austenite[ocr,xlsx]'`",
              exit_code=EXIT_VALIDATION)
        return
    except Exception as e:
        _fail(ctx, f"mtc audit-lot failed: {e}")
        return

    if output:
        out = Path(output)
        if out.suffix.lower() in {".xlsx", ".xls"}:
            try:
                report.export_xlsx(out)
                if not ctx.obj.get("quiet"):
                    click.echo(f"wrote {out}")
            except Exception as e:
                _fail(ctx, f"xlsx export failed: {e}")
                return
        else:
            _emit_json(_audit_report_to_dict(report), out, ctx)
    else:
        click.echo(report.summary())


def _audit_report_to_dict(report: Any) -> dict[str, Any]:
    """Coerce an AuditReport-like into a JSON-safe dict."""

    if hasattr(report, "to_dict"):
        return report.to_dict()
    if hasattr(report, "__dict__"):
        return {k: v for k, v in report.__dict__.items()}
    return {"summary": str(report)}


# ---------------------------------------------------------------------------
# ttt group
# ---------------------------------------------------------------------------


@cli.group("ttt")
def ttt_group() -> None:
    """Time-Temperature-Transformation diagrams."""


@ttt_group.command("cct-sweep")
@click.option("--alloy", help="Named alloy (e.g. 'AISI 4140').")
@click.option("--composition", help="Composition map (same syntax as design-path).")
@click.option("--rates", required=True, help="Comma-separated cooling rates in degC/s (e.g. '1,10,100').")
@click.option("--grain-size", "grain_size_ASTM", type=int, default=7, show_default=True)
@click.option("--json", "json_out", type=click.Path(dir_okay=False))
@click.pass_context
def cmd_ttt_cct_sweep(
    ctx: click.Context,
    alloy: Optional[str],
    composition: Optional[str],
    rates: str,
    grain_size_ASTM: int,
    json_out: Optional[str],
) -> None:
    """Sweep cooling rates and return CCT curves + final microstructure."""

    if not alloy and not composition:
        _fail(ctx, "supply either --alloy or --composition", exit_code=EXIT_VALIDATION)

    try:
        comp = _parse_composition(composition)
        if comp is None and alloy is not None:
            import austenite as au
            comp = au.data.alloy_composition(alloy)
    except Exception as e:
        _fail(ctx, f"could not resolve composition: {e}", exit_code=EXIT_VALIDATION)
        return

    try:
        rate_list = [float(x.strip()) for x in rates.split(",") if x.strip()]
    except ValueError as e:
        _fail(ctx, f"bad --rates: {e}", exit_code=EXIT_VALIDATION)
        return

    try:
        import austenite as au
        result = au.ttt.cct_sweep(
            composition=comp,
            cooling_rates_C_s=rate_list,
            grain_size_ASTM=grain_size_ASTM,
        )
    except Exception as e:
        _fail(ctx, f"ttt cct-sweep failed: {e}")
        return

    _emit_json(result.model_dump(), Path(json_out) if json_out else None, ctx)


# ---------------------------------------------------------------------------
# calphad group
# ---------------------------------------------------------------------------


@cli.group("calphad")
def calphad_group() -> None:
    """CALPHAD equilibrium and ternary sections."""


@calphad_group.command("equilibrium")
@click.option("--composition", required=True, help="Composition map (JSON or Fe=0.7,Cr=0.18).")
@click.option("--T", "T_K", required=True, type=float, help="Temperature, K.")
@click.option("--P", "P_Pa", type=float, default=101_325.0, show_default=True,
              help="Pressure, Pa (native backend ignores P).")
@click.option("--backend", type=click.Choice(["http", "native"], case_sensitive=False),
              help="Force a specific backend (default: HTTP first, native fallback).")
@click.option("--json", "json_out", type=click.Path(dir_okay=False))
@click.pass_context
def cmd_calphad_equilibrium(
    ctx: click.Context,
    composition: str,
    T_K: float,
    P_Pa: float,
    backend: Optional[str],
    json_out: Optional[str],
) -> None:
    """Solve CALPHAD equilibrium at (T, composition)."""

    try:
        comp = _parse_composition(composition)
        if not comp:
            _fail(ctx, "empty composition", exit_code=EXIT_VALIDATION)
            return
    except Exception as e:
        _fail(ctx, f"bad --composition: {e}", exit_code=EXIT_VALIDATION)
        return

    try:
        import austenite as au
        result = au.calphad.equilibrium(
            composition=comp, T_K=T_K, P_Pa=P_Pa,
            backend=backend.lower() if backend else None,
        )
    except Exception as e:
        _fail(ctx, f"calphad equilibrium failed: {e}")
        return

    _emit_json(result.model_dump(), Path(json_out) if json_out else None, ctx)


# ---------------------------------------------------------------------------
# bayesian group
# ---------------------------------------------------------------------------


@cli.group("bayesian")
def bayesian_group() -> None:
    """Bayesian CALPHAD posteriors."""


@bayesian_group.command("calphad")
@click.option("--dataset", default="hammar-1979-sigma", show_default=True,
              type=click.Choice([
                  "hammar-1979-sigma",
                  "bratberg-1996-in718-gamma-prime",
                  "hu-2009-al-cu",
                  "synthetic-rk",
              ], case_sensitive=False))
@click.option("--samples", type=int, default=3000, show_default=True)
@click.option("--chains", type=int, default=2, show_default=True)
@click.option("--method", default="dram", type=click.Choice(["dram", "mh"], case_sensitive=False),
              show_default=True)
@click.option("--seed", type=int, help="RNG seed.")
@click.option("--json", "json_out", type=click.Path(dir_okay=False))
@click.pass_context
def cmd_bayesian_calphad(
    ctx: click.Context,
    dataset: str,
    samples: int,
    chains: int,
    method: str,
    seed: Optional[int],
    json_out: Optional[str],
) -> None:
    """Deep Bayesian-CALPHAD with R-hat + HPD intervals."""

    try:
        import austenite as au
        result = au.bayesian.calphad_deep(
            dataset=dataset, samples=samples, chains=chains,
            method=method.lower(), seed=seed,
        )
    except Exception as e:
        _fail(ctx, f"bayesian calphad failed: {e}")
        return

    _emit_json(result.model_dump(), Path(json_out) if json_out else None, ctx)


# ---------------------------------------------------------------------------
# ffs group
# ---------------------------------------------------------------------------


@cli.group("ffs")
def ffs_group() -> None:
    """Fitness-For-Service per API 579-1 Parts 5, 6, 9."""


@ffs_group.command("api579-part5")
@click.option("--geometry", required=True, type=click.Path(exists=True, dir_okay=False),
              help="JSON file with geometry fields (type, OD_mm, wall_mm, ...).")
@click.option("--thickness", required=True, type=click.Path(exists=True, dir_okay=False),
              help="UT thickness CSV (column 'thickness_mm') or JSON list.")
@click.option("--T", "T_C", required=True, type=float, help="Service temperature, degC.")
@click.option("--P", "P_MPa", required=True, type=float, help="Service pressure, MPa.")
@click.option("--material", required=True, help="ASME II-D spec (e.g. 'SA-516-70').")
@click.option("--edition", help="'API 579-1 2021-12' or 'API 579-1 2024-09'.")
@click.option("--output", "-o", type=click.Path(dir_okay=False),
              help="Output path (.pdf / .xlsx / .json -- inferred from extension).")
@click.pass_context
def cmd_ffs_part5(
    ctx: click.Context,
    geometry: str,
    thickness: str,
    T_C: float,
    P_MPa: float,
    material: str,
    edition: Optional[str],
    output: Optional[str],
) -> None:
    """Part 5 -- general metal loss / LTA."""

    try:
        geom = json.loads(Path(geometry).read_text(encoding="utf-8"))
        thickness_map = _load_thickness(Path(thickness))
    except Exception as e:
        _fail(ctx, f"could not load inputs: {e}", exit_code=EXIT_VALIDATION)
        return

    try:
        import austenite as au
        result = au.ffs.api_579_part_5(
            geometry=geom,
            thickness_map=thickness_map,
            T_C=T_C, P_MPa=P_MPa,
            material=material,
            edition=edition,
        )
    except Exception as e:
        _fail(ctx, f"ffs part-5 failed: {e}")
        return

    if output:
        out = Path(output)
        suffix = out.suffix.lower()
        try:
            if suffix == ".pdf":
                result.report.export_pdf(out)
            elif suffix in {".xlsx", ".xls"}:
                result.report.export_xlsx(out)
            else:
                _emit_json(result.model_dump() if hasattr(result, "model_dump") else result.__dict__,
                           out, ctx)
                return
            if not ctx.obj.get("quiet"):
                click.echo(f"wrote {out}")
        except Exception as e:
            _fail(ctx, f"export failed: {e}")
    else:
        # Console summary
        level = getattr(result, "level", "?")
        rl = getattr(result, "remaining_life_years", None)
        tmin = getattr(result, "t_min_mm", None)
        mawp = getattr(result, "MAWP_MPa", None)
        click.echo(f"FFS Part 5: level={level}  remaining_life={rl} yr  t_min={tmin} mm  MAWP={mawp} MPa")


def _load_thickness(path: Path) -> Any:
    """Load UT thickness data from CSV or JSON."""

    if path.suffix.lower() == ".csv":
        try:
            import pandas as pd  # noqa: WPS433 - optional dep
        except ImportError as e:
            raise click.ClickException(
                "pandas is required to read CSV thickness maps; install `pip install 'austenite[xlsx]'`"
            ) from e
        return pd.read_csv(path)
    return json.loads(path.read_text(encoding="utf-8"))


# ---------------------------------------------------------------------------
# benchmark group
# ---------------------------------------------------------------------------


@cli.group("benchmark")
def benchmark_group() -> None:
    """Run the published-benchmark suite."""


@benchmark_group.command("run-all")
@click.option("--json", "json_out", type=click.Path(dir_okay=False),
              help="Write per-case scores to a JSON file.")
@click.pass_context
def cmd_benchmark_run_all(ctx: click.Context, json_out: Optional[str]) -> None:
    """Execute every shipped benchmark case and print the summary."""

    try:
        import austenite as au
        report = au.benchmark.run_all()
    except Exception as e:
        _fail(ctx, f"benchmark run failed: {e}")
        return

    click.echo(report.summary())
    if json_out:
        cases = [
            {
                "id": c.id, "capability": c.capability,
                "passed": c.passed, "skipped": c.skipped,
                "actual": c.actual, "expected": c.expected,
                "tolerance_pct": c.tolerance_pct, "error": c.error,
                "citation": c.citation,
            }
            for c in report.cases
        ]
        _emit_json({
            "total": report.n_total, "pass": report.n_pass,
            "fail": report.n_fail, "skip": report.n_skip,
            "cases": cases,
        }, Path(json_out), ctx)

    if report.n_fail > 0:
        ctx.exit(EXIT_ERROR)


# ---------------------------------------------------------------------------
# plugins group
# ---------------------------------------------------------------------------


@cli.group("plugins")
def plugins_group() -> None:
    """Plugin registry."""


@plugins_group.command("list")
@click.option("--json", "json_out", type=click.Path(dir_okay=False))
@click.pass_context
def cmd_plugins_list(ctx: click.Context, json_out: Optional[str]) -> None:
    """List installed austenite plugins."""

    try:
        import austenite as au
        names = au.plugins.list_installed()
    except Exception as e:
        _fail(ctx, f"plugin discovery failed: {e}")
        return

    if json_out:
        _emit_json({"plugins": list(names)}, Path(json_out), ctx)
    else:
        if not names:
            click.echo("(no plugins installed)")
            return
        for n in names:
            click.echo(n)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(argv: Optional[list[str]] = None) -> int:
    """Entry point used by ``[project.scripts] austenite = ...``.

    Returns the Click exit code so test harnesses can assert on it.
    """

    try:
        # Click handles ``SystemExit`` for us via ``standalone_mode=False``.
        cli.main(args=argv, prog_name="austenite", standalone_mode=False)
        return EXIT_OK
    except click.UsageError as e:
        click.echo(f"error: {e.format_message()}", err=True)
        return EXIT_VALIDATION
    except click.ClickException as e:
        e.show()
        return e.exit_code or EXIT_ERROR
    except SystemExit as e:
        # Honour explicit ctx.exit(...) calls from commands.
        code = e.code if isinstance(e.code, int) else (EXIT_ERROR if e.code else EXIT_OK)
        return code


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())


__all__ = ["main", "cli"]
