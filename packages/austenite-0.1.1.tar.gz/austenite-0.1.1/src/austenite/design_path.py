"""One-button multi-physics chain: composition → fatigue life."""

from __future__ import annotations

from typing import Any, Mapping, Optional

from ._client import get_default_client
from ._models import DesignPathInput, DesignPathResult


def design_path(
    *,
    alloy: Optional[str] = None,
    composition: Optional[Mapping[str, float]] = None,
    cooling_rate: float = 10.0,
    T0_C: float = 850.0,
    grain_size_ASTM: int = 7,
    spec: Optional[str] = None,
    sigma_app_MPa: Optional[float] = None,
    posterior: bool = False,
    **kwargs: Any,
) -> DesignPathResult:
    """Run the full ICME design-path on the Austenite server.

    The chain is: composition → CALPHAD → KWN precipitation → Orowan
    strengthening → temperature-dependent Sy(t) → Goodman fatigue allowable.

    Args:
        alloy: A named grade (e.g. ``"AISI 4140"``). One of ``alloy`` or
            ``composition`` must be supplied.
        composition: Mass-fraction composition map (e.g. ``{"Fe": 0.97, "C": 0.004}``).
        cooling_rate: Cooling rate in K/s (used by CCT lookup).
        T0_C: Austenitization temperature in °C.
        grain_size_ASTM: Prior austenite grain size, ASTM number.
        spec: Optional compliance spec (e.g. ``"ASME-VIII-Div2"``) to evaluate
            the design against.
        sigma_app_MPa: Applied stress for the fatigue check.
        posterior: If ``True``, the server returns Bayesian posterior bands
            for every derived quantity.

    Returns:
        :class:`~austenite._models.DesignPathResult` with mechanical
        properties, optional compliance verdict, optional posterior bands,
        and the literature citations the engine used.

    Examples:
        >>> import austenite as au
        >>> r = au.design_path(alloy="AISI 4140", cooling_rate=10)
        >>> print(r.properties.sigma_y_MPa)  # doctest: +SKIP
        1535
    """

    payload = DesignPathInput(
        alloy=alloy,
        composition=composition,
        cooling_rate=cooling_rate,
        T0_C=T0_C,
        grain_size_ASTM=grain_size_ASTM,
        spec=spec,
        sigma_app_MPa=sigma_app_MPa,
        posterior=posterior,
        **kwargs,
    )
    client = get_default_client()
    response = client.post("/v1/design-path", json=payload.model_dump(exclude_none=True))
    return DesignPathResult.model_validate(response.json())
