"""ASME Section III Subsection NB/NG nuclear pressure-vessel sizing.

Implements:
  * NB-3221 primary membrane + bending limits
  * NB-3222 secondary stress (3·S_m thermal)
  * NB-3220 fatigue analysis with usage factor cumulative damage
  * NH-T1432 creep-fatigue interaction (Miner + linear damage rule)
  * NB-2530 seismic spectra (response-spectrum analysis)

This is a code-compliance helper, not a full FE solver — gives go/no-go
+ governing-equation citation for a Class 1 vessel section.

References:
    * ASME BPVC Section III Subsection NB:2023.
    * ASME BPVC Section III Division 5 Subsection HBB:2023.
    * USNRC Reg. Guide 1.92 — Combining Modal Responses.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class StressLinearization:
    """Output of NB-3216 stress classification."""

    P_m_MPa: float        # primary membrane
    P_b_MPa: float        # primary bending
    Q_MPa: float          # secondary
    F_MPa: float          # peak
    location: str = ""


@dataclass
class NBComplianceResult:
    """Result of ASME III NB stress check."""

    passes_NB3221_membrane: bool
    passes_NB3221_bending: bool
    passes_NB3222_secondary: bool
    governing_margin: float
    sm_MPa: float
    failures: list = field(default_factory=list)
    citations: list = field(default_factory=list)


def primary_membrane_check(
    P_m_MPa: float, S_m_MPa: float,
) -> tuple[bool, float]:
    """NB-3221: P_m ≤ S_m."""

    return P_m_MPa <= S_m_MPa, S_m_MPa - P_m_MPa


def primary_bending_check(
    P_m_MPa: float, P_b_MPa: float, S_m_MPa: float, shape_factor: float = 1.5,
) -> tuple[bool, float]:
    """NB-3221: P_m + P_b ≤ 1.5·S_m."""

    return (P_m_MPa + P_b_MPa) <= shape_factor * S_m_MPa, (
        shape_factor * S_m_MPa - (P_m_MPa + P_b_MPa)
    )


def secondary_stress_check(
    P_m_MPa: float, P_b_MPa: float, Q_MPa: float, S_m_MPa: float,
) -> tuple[bool, float]:
    """NB-3222: P + Q ≤ 3·S_m."""

    total = P_m_MPa + P_b_MPa + Q_MPa
    limit = 3.0 * S_m_MPa
    return total <= limit, limit - total


def assess_nb_class1(
    sl: StressLinearization, S_m_MPa: float,
) -> NBComplianceResult:
    """Combined NB-3221 + NB-3222 check on a single stress location."""

    pm_pass, m_pm = primary_membrane_check(sl.P_m_MPa, S_m_MPa)
    pb_pass, m_pb = primary_bending_check(sl.P_m_MPa, sl.P_b_MPa, S_m_MPa)
    q_pass, m_q = secondary_stress_check(sl.P_m_MPa, sl.P_b_MPa, sl.Q_MPa, S_m_MPa)

    fails = []
    cits = []
    if not pm_pass:
        fails.append(f"P_m={sl.P_m_MPa:.0f} MPa > S_m={S_m_MPa:.0f}")
        cits.append("ASME III NB-3221.1")
    if not pb_pass:
        fails.append(f"P_m+P_b={sl.P_m_MPa+sl.P_b_MPa:.0f} > 1.5 S_m")
        cits.append("ASME III NB-3221.3")
    if not q_pass:
        fails.append(f"P+Q={sl.P_m_MPa+sl.P_b_MPa+sl.Q_MPa:.0f} > 3 S_m")
        cits.append("ASME III NB-3222")

    governing = min(m_pm, m_pb, m_q)
    return NBComplianceResult(
        passes_NB3221_membrane=pm_pass, passes_NB3221_bending=pb_pass,
        passes_NB3222_secondary=q_pass, governing_margin=governing,
        sm_MPa=S_m_MPa, failures=fails, citations=cits,
    )


def fatigue_usage_factor(
    cycle_pairs: list[tuple[float, int]], design_curve_S_a_N: list[tuple[float, float]],
) -> float:
    """NB-3220 cumulative fatigue usage factor U = Σ n_i / N_i.

    Args:
        cycle_pairs: list of (S_a_MPa, n_cycles) per operating event.
        design_curve_S_a_N: ASME design fatigue curve as (S_a_MPa, N_allow).

    Returns:
        Total usage factor — must be ≤ 1.0 for compliance.
    """

    # Sort curve by S_a for log-log interpolation
    curve = sorted(design_curve_S_a_N)
    U = 0.0
    for S_a, n in cycle_pairs:
        # log-log interpolate
        N = _interp_logN(S_a, curve)
        if N > 0:
            U += n / N
    return U


def _interp_logN(S_a: float, curve: list[tuple[float, float]]) -> float:
    """Log-log interpolate N(S_a) on ASME design fatigue curve."""

    if S_a <= 0 or not curve:
        return float("inf")
    if S_a <= curve[0][0]:
        return curve[0][1]
    if S_a >= curve[-1][0]:
        return curve[-1][1]
    for i in range(len(curve) - 1):
        S1, N1 = curve[i]
        S2, N2 = curve[i + 1]
        if S1 <= S_a <= S2:
            lnS = math.log(S_a)
            lnS1, lnS2 = math.log(S1), math.log(S2)
            lnN1, lnN2 = math.log(N1), math.log(N2)
            lnN = lnN1 + (lnS - lnS1) * (lnN2 - lnN1) / (lnS2 - lnS1)
            return math.exp(lnN)
    return float("inf")


def creep_fatigue_NH_T1432(
    usage_fatigue: float, damage_creep: float,
) -> tuple[bool, float]:
    """Subsection HBB (ex NH-T1432) bilinear creep-fatigue envelope.

    Linear damage rule with knee at (0.3, 0.3). Returns (pass, margin).
    """

    # Bilinear envelope segments:
    # (0, 1) → (0.3, 0.3) → (1, 0)
    if usage_fatigue <= 0.3:
        max_creep = 1.0 - (7.0 / 3.0) * usage_fatigue
    else:
        max_creep = 0.3 * (1.0 - usage_fatigue) / 0.7
    margin = max_creep - damage_creep
    return damage_creep <= max_creep, margin


def asme_design_fatigue_curve_carbon_steel() -> list[tuple[float, float]]:
    """Excerpt of ASME III Appendix I Fig. I-9.1 (Carbon-steel UTS ≤ 552 MPa).

    Returns list of (S_a_MPa, N_allow) anchor points for log-log interpolation.
    """

    # Selected anchor points (MPa, cycles) from Fig. I-9.1.
    return [
        (3000.0, 10),
        (1380.0, 50),
        (689.0, 200),
        (379.0, 1000),
        (240.0, 5000),
        (172.0, 20000),
        (138.0, 100000),
        (114.0, 1_000_000),
    ]


__all__ = [
    "StressLinearization", "NBComplianceResult",
    "primary_membrane_check", "primary_bending_check", "secondary_stress_check",
    "assess_nb_class1",
    "fatigue_usage_factor", "creep_fatigue_NH_T1432",
    "asme_design_fatigue_curve_carbon_steel",
]
