"""Shop-floor calibration — turn a mill's measured σ_y data into a posterior.

Workflow:

>>> import austenite as au
>>> shop = au.calibrate(
...     pretrained="austenite/4140-baseline-v0.1",
...     observations="./mill_X_2024.csv",
...     method="dram",
... )
>>> shop.save("./mill-X-prior.pkl")
>>> # subsequent design calls can pass shop as the prior:
>>> # au.design_path(..., prior=shop)

Observations accepted as:

* a path to a ``.csv``  — single column ``sigma_y_MPa`` (header optional);
* a path to a ``.json``  — either ``{sigma_y_MPa: [...]}`` or a list;
* a Python list / iterable of floats;
* a dict matching :class:`~austenite._models.CalibrateObservations`.

The returned :class:`ShopPrior` is a thin wrapper around the API result
that supports ``.save(path)`` / ``ShopPrior.load(path)`` via ``pickle``
(works in airgapped shop environments) or ``.to_json(path)`` /
``.from_json(path)`` (safer, no pickle attack surface).

References:
  * Haario, Laine, Mira, Saksman, Stat.Comput. 16 (2006) 339 (DRAM).
  * ESPEI (Otis & Liu 2017) — open-source Bayesian CALPHAD inspiration.
"""

from __future__ import annotations

import csv
import json
import pickle
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional, Union

from ._client import get_default_client
from ._models import (
    CalibrateInput,
    CalibrateObservations,
    CalibrateResult,
)

ObservationsLike = Union[
    str,
    Path,
    Mapping[str, Any],
    CalibrateObservations,
    Iterable[float],
]


# ---------------------------------------------------------------------------
# ShopPrior wrapper
# ---------------------------------------------------------------------------


@dataclass
class ShopPrior:
    """Persistable shop-floor posterior, returned by :func:`calibrate`.

    Wraps a :class:`CalibrateResult` with ``save`` / ``load`` helpers.
    The underlying model is exposed at ``.result`` for direct access to
    every posterior summary statistic.
    """

    result: CalibrateResult

    # ── headline accessors (delegates) ────────────────────────────────────

    @property
    def id(self) -> str:
        return self.result.id

    @property
    def pretrained(self) -> str:
        return self.result.pretrained

    @property
    def n_observations(self) -> int:
        return self.result.n_observations

    @property
    def posterior_mean_MPa(self) -> float:
        return self.result.posteriorMean_MPa

    @property
    def posterior_std_MPa(self) -> float:
        return self.result.posteriorStd_MPa

    @property
    def r_hat(self) -> Optional[float]:
        return self.result.rHat

    # ── persistence ───────────────────────────────────────────────────────

    def save(self, path: Union[str, Path]) -> Path:
        """Pickle the ShopPrior to ``path``. Returns the resolved Path."""

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("wb") as f:
            pickle.dump(self, f)
        return p

    @classmethod
    def load(cls, path: Union[str, Path]) -> "ShopPrior":
        """Unpickle a previously-saved ShopPrior. Raises if file missing."""

        p = Path(path)
        with p.open("rb") as f:
            obj = pickle.load(f)
        if not isinstance(obj, ShopPrior):
            raise TypeError(
                f"Loaded object at {p} is {type(obj).__name__}, expected ShopPrior."
            )
        return obj

    def to_json(self, path: Union[str, Path]) -> Path:
        """Pickle-free JSON serialisation (recommended for shop sharing)."""

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        # Pydantic v2: model_dump → json-serialisable dict
        with p.open("w", encoding="utf-8") as f:
            json.dump(self.result.model_dump(exclude_none=True), f, indent=2)
        return p

    @classmethod
    def from_json(cls, path: Union[str, Path]) -> "ShopPrior":
        """Inverse of :meth:`to_json`."""

        p = Path(path)
        with p.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return cls(result=CalibrateResult.model_validate(data))

    # ── repr ──────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"ShopPrior(id={self.id!r}, pretrained={self.pretrained!r}, "
            f"n_obs={self.n_observations}, mean={self.posterior_mean_MPa:.1f} "
            f"± {self.posterior_std_MPa:.1f} MPa)"
        )


# ---------------------------------------------------------------------------
# Observation loader
# ---------------------------------------------------------------------------


def _load_observations(observations: ObservationsLike) -> CalibrateObservations:
    """Coerce a variety of input forms into a ``CalibrateObservations``."""

    if isinstance(observations, CalibrateObservations):
        return observations

    if isinstance(observations, Mapping):
        return CalibrateObservations.model_validate(observations)

    if isinstance(observations, (str, Path)):
        p = Path(observations)
        if not p.exists():
            raise FileNotFoundError(f"observations file not found: {p}")
        suffix = p.suffix.lower()
        if suffix == ".json":
            with p.open("r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return CalibrateObservations(
                    sigma_y_MPa=[float(v) for v in data if v is not None]
                )
            if isinstance(data, dict):
                return CalibrateObservations.model_validate(data)
            raise ValueError(f"Unexpected JSON shape in {p}")
        if suffix == ".csv":
            return _load_csv(p)
        raise ValueError(
            f"Unsupported observations file extension {suffix}; use .csv or .json."
        )

    # Iterable of numbers
    try:
        values = [float(v) for v in observations]  # type: ignore[arg-type]
    except TypeError:
        raise TypeError(
            "observations must be a path, dict, CalibrateObservations, or iterable of floats."
        ) from None
    return CalibrateObservations(sigma_y_MPa=values)


def _load_csv(path: Path) -> CalibrateObservations:
    """Parse a one- or multi-column CSV.

    Heuristic: if a header row exists, search for a column matching
    ``sigma_y_MPa`` / ``sigma_y`` / ``yield_mpa`` / ``YS_MPa`` (case
    insensitive). Otherwise treat the first column as the σ_y values.
    """

    rows: list[list[str]] = []
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            if row:
                rows.append(row)
    if not rows:
        return CalibrateObservations(sigma_y_MPa=[])

    # Detect header
    header = rows[0]
    has_header = False
    try:
        float(header[0])
    except ValueError:
        has_header = True

    sigma_idx = 0
    if has_header:
        norm = [h.strip().lower() for h in header]
        for candidate in ("sigma_y_mpa", "sigma_y", "yield_mpa", "ys_mpa", "yield"):
            if candidate in norm:
                sigma_idx = norm.index(candidate)
                break
        data_rows = rows[1:]
    else:
        data_rows = rows

    values: list[float] = []
    for row in data_rows:
        if not row or sigma_idx >= len(row):
            continue
        cell = row[sigma_idx].strip()
        if not cell:
            continue
        try:
            values.append(float(cell))
        except ValueError:
            continue
    return CalibrateObservations(sigma_y_MPa=values)


# ---------------------------------------------------------------------------
# Top-level entry-point
# ---------------------------------------------------------------------------


def calibrate(
    *,
    pretrained: str,
    observations: ObservationsLike,
    method: str = "dram",
    samples: int = 3000,
    burn: Optional[int] = None,
    chains: int = 2,
    seed: Optional[int] = None,
    obs_noise_MPa: float = 25.0,
) -> ShopPrior:
    """Run DRAM-MCMC to update a pretrained austenite prior on a shop's data.

    Args:
        pretrained: Pretrained-prior id. Currently shipping:
            ``austenite/4140-baseline-v0.1``,
            ``austenite/sa-516-70-baseline-v0.1``,
            ``austenite/in718-baseline-v0.1``.
        observations: Path to ``.csv`` or ``.json``, or a list/iterable of
            measured σ_y values in MPa, or a dict.
        method: ``'dram'`` (Haario 2006) or ``'mh'``.
        samples: Steps per chain (default 3000, max 30000).
        burn: Burn-in (default samples / 5).
        chains: Number of chains (default 2, max 8).
        seed: Optional RNG seed.
        obs_noise_MPa: Likelihood noise σ on the σ_y measurement
            (default 25 MPa — typical mill variability).

    Returns:
        A :class:`ShopPrior` with the posterior summary + ``save`` /
        ``load`` helpers.
    """

    obs = _load_observations(observations)
    payload = CalibrateInput(
        pretrained=pretrained,
        observations=obs,
        method=method,
        samples=samples,
        burn=burn,
        chains=chains,
        seed=seed,
        obsNoise_MPa=obs_noise_MPa,
    )
    client = get_default_client()
    response = client.post(
        "/v1/calibrate",
        json=payload.model_dump(exclude_none=True),
    )
    return ShopPrior(result=CalibrateResult.model_validate(response.json()))
