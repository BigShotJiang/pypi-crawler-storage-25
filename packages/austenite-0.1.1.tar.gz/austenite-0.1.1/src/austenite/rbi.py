"""Full-API-581 Risk-Based Inspection — batch / single-asset calculation.

Ports the relevant pieces of ``apps/web/src/lib/rbi.ts`` and
``apps/web/src/lib/rbi-advanced/`` to Python. Pure local implementation —
NO API call required — so callers can run a 10 000-asset fleet screen on
a laptop without network round-trips.

Coordinated with the streaming-Bayesian RBI agent that owns
``au.rbi.create_asset`` / ``au.rbi.streaming_*``. This module owns the
batch (single-shot) API-581 verdict surface used for:

    * ``au.rbi.api_581_full(...)`` — one asset, returns POF/COF/risk
      matrix + recommended interval + per-mechanism DFs.
    * ``au.rbi.fleet_screen(assets, services)`` — vectorised over a list
      of asset dicts or a pandas DataFrame.
    * ``au.rbi.api581_corrosion_rate(...)`` — Part 2 §2 mechanism look-up.
    * ``au.rbi.risk_matrix_band(POF, COF)`` — Part 1 §4.1 colour cell.
    * ``au.rbi.pod_curve(method, depth_mm)`` — NDE POD library.
    * ``au.rbi.damage_mechanism(id)`` — 12-screen API 571 table.
    * ``au.rbi.tank_bottom_rbi(...)`` — API 653 bottom-plate KAPRO model.

References:
  * API RP 581 3rd ed. (2016) Risk-Based Inspection Methodology
  * API RP 571 3rd ed. (2020) Damage Mechanisms Affecting Fixed Equipment
  * API 510 / 570 / 653 — in-service inspection codes
  * NACE MR0175 / ISO 15156 — sour-service envelope
  * KAPRO underside-corrosion model (Geesey 1992 NACE 92-411)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, Optional, Sequence


# ---------------------------------------------------------------------------
# 1. CORROSION-RATE MECHANISMS (API 581 Part 2 §2 + Annex 2.A)
# ---------------------------------------------------------------------------


Mechanism = Literal[
    "CO2", "H2S", "NaCl", "NH3", "sulfidation", "naphthenic-acid", "amine",
]

AlloyClass = Literal[
    "CS", "1.25Cr", "2.25Cr", "5Cr", "9Cr",
    "304L", "316L", "825", "duplex2205",
]


def _alloy_factor(alloy: str, table: dict[str, float]) -> float:
    """Look up an alloy multiplier with reasonable fallback."""

    if alloy in table:
        return table[alloy]
    # crude fallback for unknown alloys: treat as CS
    return table.get("CS", 1.0)


def _cr_CO2(alloy: str, T_C: float, P_MPa: float, yCorr: float) -> float:
    """de Waard-Milliams 1991 CO2 corrosion + API 581 Annex 2.A alloy factor."""

    T_K = T_C + 273.15
    if T_K <= 0:
        return 0.0
    P_CO2_bar = max(0.0, P_MPa * 10.0 * yCorr)
    if P_CO2_bar <= 0:
        return 0.0
    logCR = 5.8 - 1710.0 / T_K + 0.67 * math.log10(P_CO2_bar)
    factors = {"CS": 1.0, "1.25Cr": 0.6, "2.25Cr": 0.4, "5Cr": 0.10, "9Cr": 0.05,
               "304L": 0.02, "316L": 0.01, "825": 0.005, "duplex2205": 0.005}
    cr = (10.0 ** logCR) * _alloy_factor(alloy, factors)
    if alloy == "CS" and T_C > 80:
        cr *= math.exp(-0.025 * (T_C - 80.0))
    return max(0.0, cr)


def _cr_H2S(alloy: str, T_C: float, P_MPa: float, yCorr: float) -> float:
    """H2S sour-service envelope (API 581 Table 2.A.2 + NACE MR0175)."""

    P_H2S_bar = max(0.0, P_MPa * 10.0 * yCorr)
    if P_H2S_bar <= 0:
        return 0.0
    base = 0.5 * (P_H2S_bar ** 0.4) * math.exp(-((T_C - 60.0) ** 2) / 1e4)
    factors = {"CS": 1.0, "1.25Cr": 0.7, "2.25Cr": 0.5, "5Cr": 0.20, "9Cr": 0.08,
               "304L": 0.05, "316L": 0.03, "825": 0.01, "duplex2205": 0.01}
    return max(0.0, base * _alloy_factor(alloy, factors))


def _cr_NaCl(alloy: str, Cl_ppm: float, vel_ms: float = 0.0) -> float:
    """Chloride / produced-water corrosion (API 581 Table 2.A.5)."""

    if Cl_ppm <= 0:
        return 0.0
    base = 0.05 + 1e-4 * Cl_ppm
    factors = {"CS": 1.0, "1.25Cr": 1.0, "2.25Cr": 1.0, "5Cr": 0.8, "9Cr": 0.6,
               "304L": 0.01, "316L": 0.005, "825": 0.002, "duplex2205": 0.002}
    if vel_ms > 3:
        base *= 1.0 + 0.3 * (vel_ms - 3.0)
    return max(0.0, base * _alloy_factor(alloy, factors))


def _cr_NH3(alloy: str, P_MPa: float, yCorr: float) -> float:
    """Overhead-NH3 corrosion (API 581 Table 2.A.7)."""

    P_NH3 = max(0.0, P_MPa * 10.0 * yCorr)
    if P_NH3 <= 0:
        return 0.0
    base = 0.3 * (P_NH3 ** 0.5)
    factors = {"CS": 1.0, "1.25Cr": 0.5, "2.25Cr": 0.3, "5Cr": 0.05, "9Cr": 0.02,
               "304L": 0.002, "316L": 0.001, "825": 0.0005, "duplex2205": 0.0005}
    return max(0.0, base * _alloy_factor(alloy, factors))


def _cr_sulfidation(alloy: str, T_C: float, yCorr: float) -> float:
    """Modified McConomy high-T sulfidation (API 581 Annex 2.B)."""

    T_K = T_C + 273.15
    if T_K <= 0 or yCorr <= 0:
        return 0.0
    R = 8.314e-3  # kJ / (mol·K)
    logCR = 4.6 + 0.5 * math.log10(yCorr) - 38.0 / (2.303 * R * T_K)
    factors = {"CS": 1.0, "1.25Cr": 0.6, "2.25Cr": 0.4, "5Cr": 0.10, "9Cr": 0.03,
               "304L": 0.01, "316L": 0.005, "825": 0.002, "duplex2205": 0.005}
    return max(0.0, (10.0 ** logCR) * _alloy_factor(alloy, factors))


def _cr_naphthenic(alloy: str, T_C: float, TAN: float) -> float:
    """Naphthenic-acid corrosion (API 571 §5.1.3)."""

    if TAN <= 0.5 or T_C < 220 or T_C > 400:
        return 0.0
    base = 0.05 * (TAN ** 1.5) * math.exp((T_C - 250.0) / 80.0)
    factors = {"CS": 1.0, "1.25Cr": 0.6, "2.25Cr": 0.3, "5Cr": 0.10, "9Cr": 0.03,
               "304L": 0.01, "316L": 0.001, "825": 0.0001, "duplex2205": 0.005}
    return max(0.0, base * _alloy_factor(alloy, factors))


def _cr_amine(alloy: str, T_C: float) -> float:
    """Amine corrosion (API 571 §5.1.1.4)."""

    if T_C < 60:
        return 0.05
    base = 0.1 + 0.005 * max(0.0, T_C - 100.0)
    factors = {"CS": 1.0, "1.25Cr": 0.4, "2.25Cr": 0.3, "5Cr": 0.1, "9Cr": 0.05,
               "304L": 0.02, "316L": 0.005, "825": 0.001, "duplex2205": 0.001}
    return max(0.0, base * _alloy_factor(alloy, factors))


def api581_corrosion_rate(
    *,
    alloy: str,
    mechanism: str,
    T_C: float = 25.0,
    P_MPa: float = 0.1,
    yCorr: float = 0.0,
    Cl_ppm: Optional[float] = None,
    TAN: Optional[float] = None,
    vel_ms: Optional[float] = None,
) -> dict[str, Any]:
    """Compute the API 581 Part 2 corrosion rate (mm/yr) for one mechanism.

    Args:
        alloy: Alloy class — ``CS``, ``1.25Cr``, ``2.25Cr``, ``5Cr``, ``9Cr``,
            ``304L``, ``316L``, ``825``, ``duplex2205`` (others fall back to CS).
        mechanism: One of ``"CO2"``, ``"H2S"``, ``"NaCl"``, ``"NH3"``,
            ``"sulfidation"``, ``"naphthenic-acid"``, ``"amine"``.
        T_C, P_MPa: Operating conditions.
        yCorr: Mole fraction of the corrosive species (CO2, H2S, NH3, S).
        Cl_ppm: Chloride content (NaCl mechanism).
        TAN: Total acid number (naphthenic).
        vel_ms: Flow velocity (NaCl erosion-corrosion bump > 3 m/s).

    Returns:
        ``{CR_mm_yr, mechanism, alloy, notes, citation}``.
    """

    cr = 0.0
    notes = "ok"
    if mechanism == "CO2":
        cr = _cr_CO2(alloy, T_C, P_MPa, yCorr); notes = "de Waard-Milliams 1991 + Annex 2.A"
    elif mechanism == "H2S":
        cr = _cr_H2S(alloy, T_C, P_MPa, yCorr); notes = "Table 2.A.2 + NACE MR0175"
    elif mechanism == "NaCl":
        cr = _cr_NaCl(alloy, float(Cl_ppm or 0), float(vel_ms or 0)); notes = "Table 2.A.5"
    elif mechanism == "NH3":
        cr = _cr_NH3(alloy, P_MPa, yCorr); notes = "Table 2.A.7"
    elif mechanism == "sulfidation":
        cr = _cr_sulfidation(alloy, T_C, yCorr); notes = "Modified McConomy / Annex 2.B"
    elif mechanism == "naphthenic-acid":
        cr = _cr_naphthenic(alloy, T_C, float(TAN or 0)); notes = "API 571 §5.1.3"
    elif mechanism == "amine":
        cr = _cr_amine(alloy, T_C); notes = "API 571 §5.1.1.4"
    else:
        notes = f"unknown mechanism {mechanism!r}; returning 0"
    return {
        "CR_mm_yr": cr if math.isfinite(cr) else 0.0,
        "mechanism": mechanism,
        "alloy": alloy,
        "notes": notes,
        "citation": "API RP 581 3rd ed. (2016) Part 2 §2 + Annex 2.A",
    }


# ---------------------------------------------------------------------------
# 2. RISK MATRIX (API 581 Part 1 §4.1)
# ---------------------------------------------------------------------------


POF_BANDS: list[dict[str, Any]] = [
    {"cat": 1, "min": 0.0, "max": 3.06e-5, "label": "< 3.06e-5/yr"},
    {"cat": 2, "min": 3.06e-5, "max": 3.06e-4, "label": "3.06e-5 to 3.06e-4"},
    {"cat": 3, "min": 3.06e-4, "max": 3.06e-3, "label": "3.06e-4 to 3.06e-3"},
    {"cat": 4, "min": 3.06e-3, "max": 3.06e-2, "label": "3.06e-3 to 3.06e-2"},
    {"cat": 5, "min": 3.06e-2, "max": 1.0,     "label": "> 3.06e-2/yr"},
]

COF_BANDS: list[dict[str, Any]] = [
    {"cat": "A", "min": 0.0,   "max": 1e4,  "label": "< $10K"},
    {"cat": "B", "min": 1e4,   "max": 1e5,  "label": "$10K to $100K"},
    {"cat": "C", "min": 1e5,   "max": 1e6,  "label": "$100K to $1M"},
    {"cat": "D", "min": 1e6,   "max": 1e7,  "label": "$1M to $10M"},
    {"cat": "E", "min": 1e7,   "max": 1e15, "label": "> $10M"},
]


def classify_pof(pof_per_yr: float) -> int:
    """API 581 Part 1 §4.1 — POF band ∈ [1, 5]."""

    for b in POF_BANDS:
        if pof_per_yr >= b["min"] and pof_per_yr < b["max"]:
            return b["cat"]
    return 5


def classify_cof(cof_usd: float) -> str:
    """API 581 Part 1 §4.1 — COF band ∈ {A,B,C,D,E}."""

    for b in COF_BANDS:
        if cof_usd >= b["min"] and cof_usd < b["max"]:
            return b["cat"]
    return "E"


# 5x5 matrix per API 581 Fig 4.1 — green/yellow/orange/red.
RISK_MATRIX = [
    # COF: A,         B,         C,            D,            E
    ["low",  "low",      "low",       "med",        "med"],       # POF 1
    ["low",  "low",      "med",       "med",        "med-high"],  # POF 2
    ["low",  "med",      "med",       "med-high",   "high"],      # POF 3
    ["med",  "med",      "med-high",  "high",       "high"],      # POF 4
    ["med",  "med-high", "high",      "high",       "high"],      # POF 5
]


def risk_matrix_band(pof_cat: int, cof_cat: str) -> str:
    """Return the API 581 risk band ('low'/'med'/'med-high'/'high')."""

    ci = ["A", "B", "C", "D", "E"].index(cof_cat)
    return RISK_MATRIX[pof_cat - 1][ci]


def recommended_inspection_interval_yr(band: str) -> dict[str, Any]:
    """API 581 §5.3 default reinspection intervals."""

    mapping = {
        "low":      {"years": 10, "method": "External visual + spot UT"},
        "med":      {"years": 6,  "method": "Routine UT + selective PA"},
        "med-high": {"years": 3,  "method": "Full UT mapping + PA on critical CMLs"},
        "high":     {"years": 1,  "method": "Continuous monitoring + ILI annually"},
    }
    return mapping.get(band, {"years": 1, "method": "Continuous monitoring"})


# ---------------------------------------------------------------------------
# 3. POD CURVES (NDE library — ASME V + MIL-HDBK-1823A)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PODCurve:
    """Probability-of-detection curve (lognormal CDF)."""

    id: str
    name: str
    mu_ln: float
    sigma_ln: float
    a_90_mm: float   # depth at P_d = 0.9
    citation: str


NDE_POD_LIBRARY: list[PODCurve] = [
    PODCurve("UT", "Ultrasonic (UT) manual A-scan",
             math.log(0.8), 0.45, 1.8, "ASME B&PV Sec V Article 4 + MIL-HDBK-1823A"),
    PODCurve("UT-PA", "UT Phased-Array",
             math.log(0.3), 0.35, 0.7, "ASME B&PV Sec V Article 4 App III"),
    PODCurve("RT", "Radiographic (RT) X-ray / γ",
             math.log(0.5), 0.55, 1.4, "ASME B&PV Sec V Article 2"),
    PODCurve("MT", "Magnetic particle (MT)",
             math.log(0.3), 0.50, 0.8, "ASME B&PV Sec V Article 7"),
    PODCurve("ET", "Eddy current (ET)",
             math.log(0.5), 0.50, 1.3, "ASME B&PV Sec V Article 8"),
    PODCurve("VT", "Visual (VT)",
             math.log(2.5), 0.80, 6.0, "ASME B&PV Sec V Article 9"),
    PODCurve("PT", "Penetrant (PT) fluorescent / colour",
             math.log(0.5), 0.60, 1.5, "ASME B&PV Sec V Article 6"),
    PODCurve("MFL-stnd", "MFL standard ILI (pipeline)",
             math.log(0.6), 0.55, 1.5, "PRCI MD-4-1 (2010) Table 5.2"),
    PODCurve("MFL-HR", "MFL high-resolution ILI",
             math.log(0.3), 0.45, 0.8, "PRCI MD-4-1 Table 5.3"),
]


def _phi_cdf(x: float) -> float:
    sign = -1.0 if x < 0 else 1.0
    ax = abs(x) / math.sqrt(2)
    t = 1.0 / (1.0 + 0.3275911 * ax)
    y = 1.0 - (
        (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736)
         * t + 0.254829592) * t * math.exp(-ax * ax)
    )
    return 0.5 * (1 + sign * y)


def pod_curve(method: str, depth_mm: float) -> float:
    """Return P_d at the given depth (mm) for the named method.

    Method is one of the IDs in :data:`NDE_POD_LIBRARY`. Falls back to UT
    if unknown.
    """

    curve = next((c for c in NDE_POD_LIBRARY if c.id.upper() == method.upper()), None)
    if curve is None:
        curve = NDE_POD_LIBRARY[0]
    if depth_mm <= 0:
        return 0.0
    z = (math.log(depth_mm) - curve.mu_ln) / max(1e-9, curve.sigma_ln)
    return _phi_cdf(z)


def api581_effectiveness(method: str, t_min_mm: float) -> str:
    """API 581 Table 3.A.1.4 effectiveness category for a single inspection.

    Maps P_d at the t_min threshold to A/B/C/D/E.
    """

    pd = pod_curve(method, t_min_mm)
    if pd > 0.95:
        return "A"
    if pd > 0.85:
        return "B"
    if pd > 0.70:
        return "C"
    if pd > 0.50:
        return "D"
    return "E"


# ---------------------------------------------------------------------------
# 4. DAMAGE-MECHANISM SCREEN (12 quick-screen rows — API 571)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class DamageMechanismScreen:
    id: str
    name: str
    api571_section: str
    susceptible_materials: tuple[str, ...]
    recommended_nde: tuple[str, ...]
    reinspect_interval_yr: int
    description: str


DAMAGE_MECHANISMS: list[DamageMechanismScreen] = [
    DamageMechanismScreen("thinning", "General thinning (CO2/H2S/NaCl)",
                          "§4.3 / §5.1.3",
                          ("CS", "1.25Cr", "2.25Cr", "5Cr"), ("UT",), 4,
                          "Uniform wall loss from acid gas + water; rate predicted by API 581 Part 2."),
    DamageMechanismScreen("scc", "Stress-corrosion cracking",
                          "§5.1.2.2", ("304L", "316L"), ("PT", "ET", "UT"), 2,
                          "Branched intergranular cracks in austenitic SS above 60 C + Cl- or caustic."),
    DamageMechanismScreen("hic", "Hydrogen-induced cracking (HIC)",
                          "§5.1.2.3", ("CS", "1.25Cr"), ("UT",), 3,
                          "Stepwise mid-thickness cracks from H2 recombination at MnS inclusions."),
    DamageMechanismScreen("ssc", "Sulfide stress cracking (SSC)",
                          "§5.1.2.4", ("CS", "1.25Cr", "2.25Cr"), ("MT", "PT", "UT"), 2,
                          "Brittle cracking near welds in H2S service; NACE MR0175 hardness control."),
    DamageMechanismScreen("sulfidation", "High-T sulfidation",
                          "§5.1.1.1", ("CS", "1.25Cr", "2.25Cr", "5Cr", "9Cr"), ("UT",), 3,
                          "Sulfide-scale corrosion 230-540 C; modified McConomy."),
    DamageMechanismScreen("carburization", "Carburization (reformer)",
                          "§4.2.2", ("304L", "316L", "825", "HK40"), ("UT", "ET"), 4,
                          "Carbon diffusion >540 C; ET detects permeability shift."),
    DamageMechanismScreen("pasc", "Polythionic-acid SCC (PASC)",
                          "§5.1.2.7", ("304L", "316L", "347"), ("PT", "ET"), 2,
                          "Sensitised austenitic SS attacked during shutdowns; NACE SP0170 soda-ash."),
    DamageMechanismScreen("dealloying", "Dealloying (dezincification, graphitic)",
                          "§4.3.6 / §4.3.7", ("CuZn", "CS"), ("VT", "UT"), 5,
                          "Selective leaching leaving spongy residue; UT for residual strength."),
    DamageMechanismScreen("mic", "Microbiologically-induced corrosion (MIC)",
                          "§4.3.8", ("CS", "304L", "316L"), ("UT", "VT"), 2,
                          "Pitting under SRB biofilm; tanks, dead legs, stagnant water."),
    DamageMechanismScreen("cui", "Corrosion under insulation (CUI)",
                          "§4.3.9", ("CS", "1.25Cr", "2.25Cr", "304L", "316L"), ("UT", "RT"), 4,
                          "60-175 C wet-insulation; guided-wave UT or profile RT under jacket."),
    DamageMechanismScreen("embrittlement", "885°F / σ-phase / temper embrittlement",
                          "§4.2.7 / §4.2.8", ("duplex2205", "347", "321"), ("VT", "UT"), 6,
                          "Long-term ferritic/duplex SS ageing; Charpy + VT/UT."),
    DamageMechanismScreen("fatigue", "Mechanical fatigue (HCF/LCF/thermal)",
                          "§4.5.1", ("CS", "1.25Cr", "2.25Cr", "304L", "316L"), ("MT", "PT", "UT"), 1,
                          "Crack initiation at stress concentrators; 1-yr reinspection once confirmed."),
]


def damage_mechanism(id: str) -> Optional[DamageMechanismScreen]:
    """Look up a damage mechanism by id (case-insensitive)."""

    k = id.lower()
    for m in DAMAGE_MECHANISMS:
        if m.id == k:
            return m
    return None


# ---------------------------------------------------------------------------
# 5. DAMAGE FACTORS (API 581 Part 2 §5) — light versions of rbi.ts physics
# ---------------------------------------------------------------------------


_INSPECTION_FACTOR = {"A": 0.10, "B": 0.20, "C": 0.50, "D": 0.80, "E": 1.00}


def _insp_coverage(category: str, n_inspections: int) -> float:
    """API 581 §5.5.4 — cumulative effectiveness with n same-category inspections."""

    f1 = _INSPECTION_FACTOR.get(category.upper(), 1.0)
    if n_inspections <= 0:
        return 1.0
    return max(f1 ** n_inspections, 0.05)


def damage_factor_thinning(
    *,
    age_yr: float,
    CR_mm_yr: float,
    t_mm: float,
    t_min_mm: float,
    inspection_category: str = "C",
    n_inspections: int = 1,
    on_line_monitoring: bool = False,
) -> dict[str, Any]:
    """API 581 §5.5 thinning damage factor.

    Returns ``{mechanism, df, rationale, inspection_factor}``.
    """

    if t_mm <= t_min_mm:
        return {"mechanism": "thinning", "df": 5000.0,
                "rationale": "t <= t_min — failure", "inspection_factor": 1.0}
    margin = t_mm - t_min_mm
    art = (age_yr * CR_mm_yr) / margin if margin > 0 else 1.0
    if art < 0.02:
        df_base = 1
    elif art < 0.04:
        df_base = 2
    elif art < 0.08:
        df_base = 10
    elif art < 0.16:
        df_base = 30
    elif art < 0.32:
        df_base = 100
    elif art < 0.50:
        df_base = 300
    elif art < 0.75:
        df_base = 1000
    else:
        df_base = 3000
    f = _insp_coverage(inspection_category, n_inspections)
    if on_line_monitoring:
        f *= 0.5
    return {
        "mechanism": "thinning",
        "df": df_base * f,
        "rationale": f"Art={art:.3f} (age {age_yr:.1f}·CR {CR_mm_yr:.3f} / margin {margin:.2f} mm); "
                     f"base DF={df_base}; insp f={f:.2f}.",
        "inspection_factor": f,
    }


def damage_factor_scc(
    *,
    susceptibility: str,
    last_inspection_age_yr: float,
    inspection_category: str = "C",
    n_inspections: int = 1,
) -> dict[str, Any]:
    """API 581 §5.6 SCC damage factor — bands per Table 5.16-5.21."""

    base = {"low": 1, "medium": 50, "high": 500, "very_high": 5000}
    df_base = base.get(susceptibility, 50)
    t_since = max(0.0, last_inspection_age_yr)
    time_factor = min(1.0 + 0.1 * t_since, 2.0)
    f = _insp_coverage(inspection_category, n_inspections)
    return {
        "mechanism": "scc",
        "df": df_base * time_factor * f,
        "rationale": f"Susceptibility={susceptibility}; base DF={df_base}; "
                     f"t_factor={time_factor:.2f}; insp f={f:.2f}.",
        "inspection_factor": f,
    }


def damage_factor_htha(
    *,
    T_op_C: float,
    nelson_curve_T_C: float,
    age_yr: float,
    inspection_category: str = "C",
    n_inspections: int = 1,
) -> dict[str, Any]:
    """API 581 §5.7 + API RP 941 HTHA damage factor."""

    if T_op_C < nelson_curve_T_C - 30:
        df_base = 1.0
        rationale = f"Well below Nelson curve (Δ={nelson_curve_T_C - T_op_C:.0f} C)."
    elif T_op_C < nelson_curve_T_C:
        df_base = 10.0
        rationale = "Within 30 C of Nelson curve."
    else:
        overshoot = T_op_C - nelson_curve_T_C
        df_base = 100.0 * (1 + overshoot / 50.0) * (1 + age_yr / 20.0)
        rationale = f"Above Nelson curve by {overshoot:.0f} C; aged {age_yr:.1f} yr."
    f = _insp_coverage(inspection_category, n_inspections)
    return {"mechanism": "htha", "df": df_base * f, "rationale": rationale,
            "inspection_factor": f}


def damage_factor_brittle(
    *,
    T_op_C: float,
    MAT_C: float,
    CVN_J: float = 40.0,
    t_mm: float = 25.0,
) -> dict[str, Any]:
    """API 581 §5.8 brittle-fracture damage factor."""

    margin = T_op_C - MAT_C
    df_base = 1.0
    rationale = f"T={T_op_C} > MAT={MAT_C} (margin {margin:.0f} C)."
    if margin < -20:
        df_base = 1000.0
        rationale = f"T below MAT by {-margin:.0f} C — brittle risk."
    elif margin < 0:
        df_base = 100.0
        rationale = f"T below MAT by {-margin:.0f} C."
    elif margin < 10 and t_mm > 50:
        df_base = 30.0
        rationale = f"Margin < 10 C with thick section ({t_mm} mm)."
    elif margin < 30:
        df_base = 10.0
        rationale = "Margin < 30 C; flaws may propagate."
    if CVN_J < 27:
        df_base *= 3.0
    return {"mechanism": "brittle", "df": df_base, "rationale": rationale,
            "inspection_factor": 1.0}


# ---------------------------------------------------------------------------
# 6. GENERIC FAILURE FREQUENCIES (API 581 Annex 3.A Table 4.1)
# ---------------------------------------------------------------------------


GFF_TABLE: dict[str, dict[str, float]] = {
    "vessel":          {"small": 8.0e-6, "medium": 2.0e-5, "large": 2.0e-6, "rupture": 6.0e-7},
    "tank":            {"small": 4.0e-5, "medium": 4.0e-6, "large": 1.0e-6, "rupture": 6.0e-7},
    "column":          {"small": 1.8e-4, "medium": 2.2e-5, "large": 2.0e-6, "rupture": 6.0e-7},
    "hex":             {"small": 8.0e-6, "medium": 2.0e-5, "large": 2.0e-6, "rupture": 6.0e-7},
    "piping_circuit":  {"small": 2.8e-5, "medium": 4.0e-6, "large": 1.0e-6, "rupture": 6.0e-7},
    "pump":            {"small": 4.0e-4, "medium": 1.0e-4, "large": 1.0e-5, "rupture": 1.0e-6},
    "compressor":      {"small": 4.0e-4, "medium": 1.0e-4, "large": 1.0e-5, "rupture": 1.0e-6},
    "pipeline":        {"small": 1.0e-5, "medium": 1.0e-6, "large": 1.0e-7, "rupture": 1.0e-8},
    "storage_sphere":  {"small": 8.0e-6, "medium": 2.0e-5, "large": 2.0e-6, "rupture": 6.0e-7},
}


def gff_total(asset_type: str) -> float:
    """Sum across hole sizes (Annex 3.A); falls back to vessel for unknown types."""

    alias = {"piping": "piping_circuit", "heat_exchanger": "hex", "valve": "piping_circuit"}
    key = alias.get(asset_type, asset_type)
    tbl = GFF_TABLE.get(key, GFF_TABLE["vessel"])
    return tbl["small"] + tbl["medium"] + tbl["large"] + tbl["rupture"]


# ---------------------------------------------------------------------------
# 7. AGGREGATE VERDICT — api_581_full
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Api581Verdict:
    """Output of :func:`api_581_full` — fleet-screen-ready row."""

    asset_tag: str
    POF_per_yr: float
    POF_category: int
    COF_usd: float
    COF_category: str
    risk_matrix: str          # like "3C"
    risk_band: str            # low / med / med-high / high
    recommended_inspection_interval_years: int
    recommended_inspection_method: str
    damage_factors: dict[str, float]
    F_MS: float
    citation: str
    notes: list[str] = field(default_factory=list)


def _normalise_alloy(material: Optional[str]) -> str:
    """Coerce common UNS / ASTM names to the RBI alloy-class enum."""

    if not material:
        return "CS"
    m = str(material).upper()
    if "304L" in m or "S30403" in m:
        return "304L"
    if "316L" in m or "S31603" in m:
        return "316L"
    if "316" in m or "S31600" in m:
        return "316L"
    if "304" in m or "S30400" in m:
        return "304L"
    if "825" in m or "N08825" in m:
        return "825"
    if "2205" in m or "S31803" in m or "S32205" in m:
        return "duplex2205"
    if "P22" in m or "2.25CR" in m or "A335" in m and "P22" in m:
        return "2.25Cr"
    if "P11" in m or "1.25CR" in m:
        return "1.25Cr"
    if "P5" in m or "5CR" in m:
        return "5Cr"
    if "P9" in m or "9CR" in m:
        return "9Cr"
    return "CS"


def _select_mechanism(service: str, chemistry: Mapping[str, Any]) -> str:
    """Pick the dominant API 581 mechanism by service name / chemistry."""

    s = (service or "").lower()
    if "sour" in s or float(chemistry.get("H2S_ppm", 0) or 0) > 100:
        return "H2S"
    if "co2" in s or "sweet" in s or float(chemistry.get("CO2_pct", 0) or 0) > 0:
        return "CO2"
    if "amine" in s or "mdea" in s or "dea" in s:
        return "amine"
    if "naphthenic" in s or float(chemistry.get("TAN", 0) or 0) >= 0.5:
        return "naphthenic-acid"
    if "sulfidation" in s or float(chemistry.get("yS", 0) or 0) > 0:
        return "sulfidation"
    if "nacl" in s or "chloride" in s or float(chemistry.get("Cl_ppm", 0) or 0) > 0:
        return "NaCl"
    return "CO2"


def _default_F_MS(eq_type: str) -> float:
    """API 581 §6 default management-systems factor (audit-driven, 0.1-10)."""

    return 1.0   # neutral; caller may override


def api_581_full(
    *,
    equipment: Mapping[str, Any],
    service: str,
    chemistry: Mapping[str, Any] | None = None,
    material: Optional[str] = None,
    inspection_history: Optional[Sequence[Mapping[str, Any]]] = None,
    cof_usd: float = 1e5,
    age_yr: Optional[float] = None,
    t_nominal_mm: float = 12.7,
    t_min_mm: float = 8.0,
    inspection_category: str = "C",
    n_inspections: Optional[int] = None,
    F_MS: Optional[float] = None,
) -> Api581Verdict:
    """Full API-581 single-asset risk assessment.

    Args:
        equipment: ``{"type": "vessel", "tag": "V-2401"}`` minimum.
        service: Free-text service descriptor ('sweet-corrosion', 'sour',
            'amine', 'naphthenic-acid', 'sulfidation', 'chloride'). Drives
            the dominant-mechanism look-up.
        chemistry: Optional ``{H2S_ppm, Cl_ppm, T_C, P_MPa, ...}``.
        material: Alloy name (UNS / ASTM / colloquial); see
            :func:`_normalise_alloy` for the supported keys.
        inspection_history: Optional list of ``{year, method, thickness_mm}``
            records. ``n_inspections`` is derived from the length unless
            explicitly provided.
        cof_usd: Consequence-of-failure dollar value (default $100K = COF C).
        age_yr: Service age. If omitted, derived from
            ``equipment.installed_year`` (vs current year, fallback 2026).
        t_nominal_mm, t_min_mm: Wall thickness and B31.3/VIII minimum.
        inspection_category: A/B/C/D/E effectiveness category.
        F_MS: Management-systems factor (default 1.0).

    Returns:
        :class:`Api581Verdict`.
    """

    chem = dict(chemistry or {})
    eq_type = str(equipment.get("type", "vessel")).lower()
    tag = str(equipment.get("tag", "unknown-asset"))
    if age_yr is None:
        from datetime import datetime
        current_yr = datetime.now().year
        installed = equipment.get("installed_year")
        try:
            age_yr = max(0.0, float(current_yr - int(installed))) if installed else 10.0
        except (TypeError, ValueError):
            age_yr = 10.0

    alloy = _normalise_alloy(material)
    mechanism = _select_mechanism(service, chem)
    T_C = float(chem.get("T_C", 25))
    P_MPa = float(chem.get("P_MPa", 0.1))
    y_corr = 0.0
    if mechanism == "H2S":
        y_corr = float(chem.get("H2S_ppm", 0)) / 1e6
    elif mechanism == "CO2":
        y_corr = float(chem.get("CO2_pct", 0)) / 100.0 or float(chem.get("yCO2", 0))
    elif mechanism == "NH3":
        y_corr = float(chem.get("yNH3", 0))
    elif mechanism == "sulfidation":
        y_corr = float(chem.get("yS", 0))

    cr = api581_corrosion_rate(
        alloy=alloy, mechanism=mechanism, T_C=T_C, P_MPa=P_MPa,
        yCorr=y_corr,
        Cl_ppm=float(chem.get("Cl_ppm", 0)) or None,
        TAN=float(chem.get("TAN", 0)) or None,
        vel_ms=float(chem.get("vel_ms", 0)) or None,
    )

    # default inspection-effectiveness from latest history record (if any)
    n_insp = n_inspections if n_inspections is not None else (
        len(inspection_history) if inspection_history else 1
    )
    df_thin = damage_factor_thinning(
        age_yr=age_yr, CR_mm_yr=cr["CR_mm_yr"], t_mm=t_nominal_mm, t_min_mm=t_min_mm,
        inspection_category=inspection_category, n_inspections=n_insp,
    )
    dfs: dict[str, float] = {"thinning": df_thin["df"]}

    # SCC for austenitics in chloride / amine / sour
    if alloy in ("304L", "316L") and (mechanism == "NaCl" or float(chem.get("Cl_ppm", 0)) > 50):
        scc = damage_factor_scc(susceptibility="high", last_inspection_age_yr=age_yr)
        dfs["scc"] = scc["df"]

    # HIC / SSC bump for CS in sour
    if alloy == "CS" and mechanism == "H2S":
        dfs["hic"] = 100.0

    # HTHA if H2 partial pressure flagged
    if float(chem.get("H2_partial_pressure_MPa", 0)) > 0.2 and T_C > 250:
        nelson_T = 350.0  # generic Nelson-curve datapoint @ 1.0 MPa H2 — engineer should refine
        htha = damage_factor_htha(T_op_C=T_C, nelson_curve_T_C=nelson_T, age_yr=age_yr)
        dfs["htha"] = htha["df"]

    df_total = sum(dfs.values())
    gff = gff_total(eq_type)
    F_MS_used = F_MS if F_MS is not None else _default_F_MS(eq_type)
    pof = gff * df_total * F_MS_used
    pof_cat = classify_pof(pof)
    cof_cat = classify_cof(float(cof_usd))
    band = risk_matrix_band(pof_cat, cof_cat)
    interval = recommended_inspection_interval_yr(band)
    notes = [
        f"Mechanism={mechanism}; alloy={alloy}; CR={cr['CR_mm_yr']:.3f} mm/yr.",
        f"GFF={gff:.2e}/yr; Σ DFs={df_total:.0f}; F_MS={F_MS_used:.2f}.",
        f"POF={pof:.2e}/yr → category {pof_cat}; COF=${cof_usd:.0f} → {cof_cat}.",
    ]
    return Api581Verdict(
        asset_tag=tag,
        POF_per_yr=pof,
        POF_category=pof_cat,
        COF_usd=float(cof_usd),
        COF_category=cof_cat,
        risk_matrix=f"{pof_cat}{cof_cat}",
        risk_band=band,
        recommended_inspection_interval_years=int(interval["years"]),
        recommended_inspection_method=str(interval["method"]),
        damage_factors=dfs,
        F_MS=F_MS_used,
        citation="API RP 581 3rd ed. (2016) + API 571 3rd ed. (2020)",
        notes=notes,
    )


def fleet_screen(
    assets: Any,
    service_db: Optional[Mapping[str, Any]] = None,
) -> Any:
    """Vectorised single-shot risk screen for many assets.

    Args:
        assets: ``pandas.DataFrame`` or list of dicts. Each row may have:
            ``tag``, ``type``, ``service``, ``material``, ``H2S_ppm``,
            ``Cl_ppm``, ``T_C``, ``P_MPa``, ``cof_usd``, ``age_yr``,
            ``t_mm``, ``t_min_mm``, ``inspection_category``, ``n_inspections``.
        service_db: Optional mapping ``service_name → dict overlay`` whose
            keys augment each row's ``chemistry`` before calling
            :func:`api_581_full`.

    Returns:
        ``pandas.DataFrame`` with the verdict columns (``POF_per_yr``,
        ``POF_category``, ``COF_category``, ``risk_matrix``,
        ``risk_band``, ``recommended_inspection_interval_years``,
        ``total_risk = POF · COF$``). Falls back to a list of dicts if
        pandas is not installed.
    """

    rows: list[dict[str, Any]] = []
    try:
        import pandas as pd  # type: ignore
        if isinstance(assets, pd.DataFrame):
            for _, r in assets.iterrows():
                rows.append(dict(r))
        else:
            rows = list(assets)
    except ImportError:
        rows = list(assets)

    sdb = dict(service_db or {})
    out: list[dict[str, Any]] = []
    for row in rows:
        service = str(row.get("service", "sweet-corrosion"))
        chem = {**(sdb.get(service, {}) or {}),
                "T_C": row.get("T_C", 25),
                "P_MPa": row.get("P_MPa", 0.1),
                "H2S_ppm": row.get("H2S_ppm", 0),
                "Cl_ppm": row.get("Cl_ppm", 0),
                "CO2_pct": row.get("CO2_pct", 0),
                "TAN": row.get("TAN", 0)}
        v = api_581_full(
            equipment={"type": row.get("type", "vessel"), "tag": row.get("tag", "?")},
            service=service,
            chemistry=chem,
            material=row.get("material"),
            cof_usd=float(row.get("cof_usd", 1e5)),
            age_yr=row.get("age_yr"),
            t_nominal_mm=float(row.get("t_mm", 12.7)),
            t_min_mm=float(row.get("t_min_mm", 8.0)),
            inspection_category=str(row.get("inspection_category", "C")),
            n_inspections=row.get("n_inspections"),
        )
        out.append({
            "tag": v.asset_tag,
            "POF_per_yr": v.POF_per_yr,
            "POF_category": v.POF_category,
            "COF_category": v.COF_category,
            "risk_matrix": v.risk_matrix,
            "risk_band": v.risk_band,
            "recommended_inspection_interval_years": v.recommended_inspection_interval_years,
            "total_risk": v.POF_per_yr * v.COF_usd,
        })

    try:
        import pandas as pd  # type: ignore
        return pd.DataFrame(out)
    except ImportError:
        return out


# ---------------------------------------------------------------------------
# 8. TANK-BOTTOM RBI (API 653 + KAPRO Geesey 1992)
# ---------------------------------------------------------------------------


def tank_bottom_rbi(
    *,
    t_nominal_mm: float = 9.5,
    t_min_mm: float = 2.54,
    CR_topside_mm_yr: float = 0.05,
    CR_underside_mm_yr: float = 0.1,
    CR_edge_mm_yr: float = 0.2,
    MIC: bool = False,
    service_age_yr: float = 10.0,
    product: str = "crude",
) -> dict[str, Any]:
    """API 653 tank-bottom remaining-life + internal-inspection interval.

    KAPRO underside model from Geesey 1992 NACE 92-411; crude/water bottoms
    get a 1.3x multiplier, confirmed MIC adds a 3.0x multiplier.
    """

    kapro = 1.0
    if product in ("crude", "water"):
        kapro *= 1.3
    if MIC:
        kapro *= 3.0
    CR_under = max(0.0, CR_underside_mm_yr * kapro)
    CR_top = max(0.0, CR_topside_mm_yr)
    CR_edge = max(0.0, CR_edge_mm_yr)
    t_top = max(0.0, t_nominal_mm - CR_top * service_age_yr)
    t_under = max(0.0, t_nominal_mm - CR_under * service_age_yr)
    t_edge = max(0.0, t_nominal_mm - CR_edge * service_age_yr)
    candidates = [
        ("topside", t_top, CR_top),
        ("underside", t_under, CR_under),
        ("edge", t_edge, CR_edge),
    ]
    loc, t_now, CR_lim = min(candidates, key=lambda c: c[1])
    rl = max(0.0, (t_now - t_min_mm) / CR_lim) if CR_lim > 0 else 999.0
    interval = min(10.0, rl / 2.0)
    return {
        "remaining_thickness_mm": t_now,
        "remaining_life_yr": rl,
        "limiting_location": loc,
        "internal_interval_yr": max(0.5, interval),
        "CR_total_mm_yr": CR_top + CR_under + CR_edge,
        "notes": (f"MIC ACTIVE — KAPRO ×{kapro:.1f} multiplier applied. Probe SRB."
                  if MIC else f"Normal RBI — no MIC. KAPRO ×{kapro:.1f}."),
        "citation": "API 653 4th ed. (2014) §6.4 + KAPRO Geesey 1992 NACE 92-411",
    }


# ---------------------------------------------------------------------------
# Export surface
# ---------------------------------------------------------------------------


__all__ = [
    "Api581Verdict",
    "api_581_full",
    "fleet_screen",
    "api581_corrosion_rate",
    "POF_BANDS",
    "COF_BANDS",
    "classify_pof",
    "classify_cof",
    "risk_matrix_band",
    "recommended_inspection_interval_yr",
    "PODCurve",
    "NDE_POD_LIBRARY",
    "pod_curve",
    "api581_effectiveness",
    "DamageMechanismScreen",
    "DAMAGE_MECHANISMS",
    "damage_mechanism",
    "damage_factor_thinning",
    "damage_factor_scc",
    "damage_factor_htha",
    "damage_factor_brittle",
    "GFF_TABLE",
    "gff_total",
    "tank_bottom_rbi",
]
