"""HTTPX-based synchronous and asynchronous client for the Austenite API.

Both clients:

* retry on 5xx / transport errors using tenacity (exponential backoff);
* attach an ``Idempotency-Key`` header (UUID4) on every POST so the server can
  dedupe retries safely;
* set a recognisable ``User-Agent`` so the engine can route by client version;
* translate HTTP / transport errors into the typed exceptions in
  :mod:`austenite._exceptions`.
"""

from __future__ import annotations

import sys
import uuid
from typing import Any, Mapping, Optional

import httpx
from tenacity import (
    RetryError,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from ._config import DEFAULT_USER_AGENT_TEMPLATE, ClientConfig, get_config
from ._exceptions import (
    EngineError,
    NetworkError,
    RateLimitError,
    ValidationError,
)


def _user_agent() -> str:
    py = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    return DEFAULT_USER_AGENT_TEMPLATE.format(py_version=py)


def _build_headers(
    config: ClientConfig,
    *,
    extra: Optional[Mapping[str, str]] = None,
    with_idempotency: bool = False,
) -> dict[str, str]:
    headers: dict[str, str] = {
        "User-Agent": _user_agent(),
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if config.api_key:
        headers["Authorization"] = f"Bearer {config.api_key}"
    if with_idempotency:
        headers["Idempotency-Key"] = str(uuid.uuid4())
    headers.update(config.extra_headers)
    if extra:
        headers.update(extra)
    return headers


def _raise_for_status(response: httpx.Response) -> None:
    """Translate HTTP errors into the typed exception hierarchy."""

    if response.is_success:
        return

    status = response.status_code
    try:
        body: Any = response.json()
        message = body.get("error") or body.get("message") or response.text
    except Exception:  # body wasn't JSON
        body = response.text
        message = response.text or response.reason_phrase or "<no message>"

    if status == 429:
        raise RateLimitError(message, status_code=status, response_body=body)
    if 400 <= status < 500:
        raise ValidationError(message, status_code=status, response_body=body)
    if status >= 500:
        raise EngineError(message, status_code=status, response_body=body)
    # Should be unreachable, but defensively raise:
    raise EngineError(message, status_code=status, response_body=body)


# Exception types we DO retry. Validation/rate-limit must NOT retry blindly.
_RETRYABLE = (EngineError, NetworkError, httpx.TransportError, httpx.RemoteProtocolError)


class Client:
    """Synchronous client for the Austenite API."""

    def __init__(
        self,
        *,
        api_url: Optional[str] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        max_retries: Optional[int] = None,
        backoff_factor: Optional[float] = None,
        transport: Optional[httpx.BaseTransport] = None,
    ) -> None:
        config = get_config()
        self._api_url = (api_url or config.api_url).rstrip("/")
        self._timeout = timeout if timeout is not None else config.timeout
        self._api_key = api_key if api_key is not None else config.api_key
        self._max_retries = max_retries if max_retries is not None else config.max_retries
        self._backoff_factor = (
            backoff_factor if backoff_factor is not None else config.backoff_factor
        )
        self._httpx = httpx.Client(
            base_url=self._api_url,
            timeout=self._timeout,
            transport=transport,
        )

    # -- context manager -----------------------------------------------------

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def close(self) -> None:
        self._httpx.close()

    # -- HTTP verbs ----------------------------------------------------------

    def post(
        self,
        path: str,
        *,
        json: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
    ) -> httpx.Response:
        config = ClientConfig(
            api_url=self._api_url,
            timeout=self._timeout,
            api_key=self._api_key,
        )
        request_headers = _build_headers(config, extra=headers, with_idempotency=True)

        @retry(
            reraise=True,
            stop=stop_after_attempt(self._max_retries),
            wait=wait_exponential(multiplier=self._backoff_factor, min=self._backoff_factor),
            retry=retry_if_exception_type(_RETRYABLE),
        )
        def _do() -> httpx.Response:
            try:
                response = self._httpx.post(path, json=json, headers=request_headers)
            except httpx.TimeoutException as exc:
                raise NetworkError(f"Request to {path} timed out: {exc}") from exc
            except httpx.TransportError as exc:
                raise NetworkError(f"Transport error on {path}: {exc}") from exc
            _raise_for_status(response)
            return response

        try:
            return _do()
        except RetryError as exc:  # pragma: no cover - tenacity rewraps when not reraise
            raise NetworkError(f"Retries exhausted for {path}: {exc}") from exc

    def get(
        self,
        path: str,
        *,
        params: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
    ) -> httpx.Response:
        config = ClientConfig(
            api_url=self._api_url,
            timeout=self._timeout,
            api_key=self._api_key,
        )
        request_headers = _build_headers(config, extra=headers, with_idempotency=False)

        @retry(
            reraise=True,
            stop=stop_after_attempt(self._max_retries),
            wait=wait_exponential(multiplier=self._backoff_factor, min=self._backoff_factor),
            retry=retry_if_exception_type(_RETRYABLE),
        )
        def _do() -> httpx.Response:
            try:
                response = self._httpx.get(path, params=params, headers=request_headers)
            except httpx.TimeoutException as exc:
                raise NetworkError(f"Request to {path} timed out: {exc}") from exc
            except httpx.TransportError as exc:
                raise NetworkError(f"Transport error on {path}: {exc}") from exc
            _raise_for_status(response)
            return response

        try:
            return _do()
        except RetryError as exc:  # pragma: no cover
            raise NetworkError(f"Retries exhausted for {path}: {exc}") from exc


class AsyncClient:
    """Asynchronous client for the Austenite API."""

    def __init__(
        self,
        *,
        api_url: Optional[str] = None,
        timeout: Optional[float] = None,
        api_key: Optional[str] = None,
        max_retries: Optional[int] = None,
        backoff_factor: Optional[float] = None,
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ) -> None:
        config = get_config()
        self._api_url = (api_url or config.api_url).rstrip("/")
        self._timeout = timeout if timeout is not None else config.timeout
        self._api_key = api_key if api_key is not None else config.api_key
        self._max_retries = max_retries if max_retries is not None else config.max_retries
        self._backoff_factor = (
            backoff_factor if backoff_factor is not None else config.backoff_factor
        )
        self._httpx = httpx.AsyncClient(
            base_url=self._api_url,
            timeout=self._timeout,
            transport=transport,
        )

    async def __aenter__(self) -> "AsyncClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._httpx.aclose()

    async def post(
        self,
        path: str,
        *,
        json: Optional[Mapping[str, Any]] = None,
        headers: Optional[Mapping[str, str]] = None,
    ) -> httpx.Response:
        config = ClientConfig(
            api_url=self._api_url,
            timeout=self._timeout,
            api_key=self._api_key,
        )
        request_headers = _build_headers(config, extra=headers, with_idempotency=True)

        @retry(
            reraise=True,
            stop=stop_after_attempt(self._max_retries),
            wait=wait_exponential(multiplier=self._backoff_factor, min=self._backoff_factor),
            retry=retry_if_exception_type(_RETRYABLE),
        )
        async def _do() -> httpx.Response:
            try:
                response = await self._httpx.post(path, json=json, headers=request_headers)
            except httpx.TimeoutException as exc:
                raise NetworkError(f"Request to {path} timed out: {exc}") from exc
            except httpx.TransportError as exc:
                raise NetworkError(f"Transport error on {path}: {exc}") from exc
            _raise_for_status(response)
            return response

        try:
            return await _do()
        except RetryError as exc:  # pragma: no cover
            raise NetworkError(f"Retries exhausted for {path}: {exc}") from exc


# ---------------------------------------------------------------------------
# Default-client singleton
# ---------------------------------------------------------------------------


_default_client: Optional[Client] = None


def get_default_client() -> Client:
    """Return the process-wide default :class:`Client`, lazily creating one."""

    global _default_client
    if _default_client is None:
        _default_client = Client()
    return _default_client


def reset_default_client() -> None:
    """Forcibly drop the default client (e.g. after :func:`set_api_url`)."""

    global _default_client
    if _default_client is not None:
        try:
            _default_client.close()
        except Exception:  # pragma: no cover - best effort
            pass
    _default_client = None
