"""ASME IX Weld Procedure Specification (WPS) management.

Engineer pain (verbatim from therness.com):
    *"WPS management still depends on PDFs in shared folders, paper copies
    at stations, and manual checks to confirm whether the right revision
    was used."*

This module replaces that PDF-and-paper workflow with a programmable
WPS/PQR registry that round-trips ASME IX Form QW-482 data. It is
deliberately dependency-light: PDF parsing degrades gracefully to
text-only if ``pypdf`` / ``pdfplumber`` are not installed.

Public API::

    import austenite as au

    # Parse a WPS PDF / Word / HTML / text file
    wps = au.wps.parse("WPS-A001-Rev3.pdf")

    # Validate against ASME IX
    verdict = au.wps.validate(wps)
    verdict.passed         # bool
    verdict.failed_items   # list[str]
    verdict.citation       # 'ASME BPVC Section IX (2021) Article II'

    # Backend selection
    au.wps.backend("sqlite", path="./wps.db")
    au.wps.backend("json", path="./wps_store/")

    # Revision tracking
    history = au.wps.history("WPS-A001")
    current = au.wps.current("WPS-A001")
    au.wps.supersede("WPS-A001", from_rev=2, to_rev=3,
                     reason="Updated joint geometry per ECN-1234")

    # Sign + audit trail
    au.wps.sign(current, signer="J. Smith, P.E.",
                signature_method="digital")

    # Export
    au.wps.export_pdf(current, "WPS-A001-Rev3.pdf")
    au.wps.export_xml(current, "WPS-A001-Rev3.xml")  # AWS WPS-XML

    # PQR (Procedure Qualification Record) linked to WPS
    pqr = au.wps.pqr.parse("PQR-A001.pdf")
    supporting = au.wps.find_qualifying_pqrs(wps)

References:
    * ASME BPVC Section IX (2021) — "Welding, Brazing, and Fusing
      Qualifications". Article II (Welding Procedure Qualifications)
      QW-200, QW-251 through QW-292 (Process-specific variables),
      QW-461 (Positions), QW-482 (Suggested Format for WPS),
      QW-483 (Suggested Format for PQR).
    * AWS A5.x (Filler-metal Specifications).
    * AWS D1.1/D1.1M (2020) Structural Welding Code — Steel.
    * NBIC NB-23 (2023) — National Board Inspection Code Part 3.
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import sqlite3
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional, Sequence, Union
from xml.sax.saxutils import escape as xml_escape

__all__ = [
    # Models
    "BaseMetals",
    "FillerMetals",
    "JointDesign",
    "Position",
    "ElectricalCharacteristics",
    "PreheatPostheat",
    "Gases",
    "Technique",
    "MechanicalTesting",
    "WPS",
    "PQR",
    "Revision",
    "WPSVerdict",
    # Functions
    "parse",
    "validate",
    "history",
    "current",
    "supersede",
    "sign",
    "export_pdf",
    "export_xml",
    "backend",
    "find_qualifying_pqrs",
    "save",
    "load",
    "list_wps",
    # Sub-namespace
    "pqr",
]


# ---------------------------------------------------------------------------
# ASME IX recognised welding processes (QW-251 family).
# ---------------------------------------------------------------------------

_VALID_PROCESSES: frozenset[str] = frozenset(
    {
        "SMAW",  # Shielded metal arc — QW-253
        "GTAW",  # Gas tungsten arc — QW-255
        "GMAW",  # Gas metal arc (MIG) — QW-255
        "FCAW",  # Flux-cored arc — QW-255
        "SAW",  # Submerged arc — QW-254
        "PAW",  # Plasma arc — QW-256
        "OFW",  # Oxy-fuel — QW-252
        "ESW",  # Electroslag — QW-261
        "EBW",  # Electron beam — QW-260
        "LBW",  # Laser beam — QW-264
    }
)


# ASME IX QW-461.1 / QW-461.2 — qualified positions.
_VALID_POSITIONS: frozenset[str] = frozenset(
    {
        # Groove (plate / pipe) — QW-461.1
        "1G",
        "2G",
        "3G",
        "4G",
        "5G",
        "6G",
        "6GR",
        # Fillet — QW-461.2
        "1F",
        "2F",
        "2FR",
        "3F",
        "4F",
        "5F",
    }
)


# ---------------------------------------------------------------------------
# Pydantic-free dataclasses (avoids pulling pydantic just for static schema).
# These mirror the QW-482 form blocks.
# ---------------------------------------------------------------------------


@dataclass
class BaseMetals:
    """ASME IX QW-403 — Base-metal variables.

    Attributes:
        p_number: P-Number (QW-422), e.g. "1" for carbon steel,
            "8" for austenitic stainless.
        group: P-Group within the P-Number, e.g. "1", "2".
        spec: AWS / ASTM / ASME spec, e.g. "SA-516 Gr.70".
        thickness_range_mm: ``(t_min_mm, t_max_mm)`` qualified range.
        diameter_range_mm: For pipe — ``(d_min_mm, d_max_mm)``.
    """

    p_number: Optional[str] = None
    group: Optional[str] = None
    spec: Optional[str] = None
    thickness_range_mm: Optional[tuple[float, float]] = None
    diameter_range_mm: Optional[tuple[float, float]] = None


@dataclass
class FillerMetals:
    """ASME IX QW-404 — Filler-metal variables.

    Attributes:
        f_number: F-Number (QW-432), e.g. "4" for E70xx covered electrodes,
            "6" for solid-wire steel.
        a_number: A-Number (QW-442) — chemical-composition group of weld
            deposit, e.g. "1" for mild steel.
        aws_spec: AWS spec / classification, e.g. "AWS A5.1 E7018".
        size_mm: Electrode / wire diameter in mm.
        trade_name: Optional manufacturer trade name (informational).
    """

    f_number: Optional[str] = None
    a_number: Optional[str] = None
    aws_spec: Optional[str] = None
    size_mm: Optional[float] = None
    trade_name: Optional[str] = None


@dataclass
class JointDesign:
    """ASME IX QW-402 — Joint design variables.

    Attributes:
        joint_type: e.g. "Butt", "Fillet", "Corner", "Lap", "Edge".
        groove_type: e.g. "Single-V", "Double-V", "Single-U", "Square".
        backing: Whether backing strip / ring is used (yes/no/none).
        root_opening_mm: Root opening gap (mm).
        included_angle_deg: Total included groove angle (degrees).
    """

    joint_type: Optional[str] = None
    groove_type: Optional[str] = None
    backing: Optional[str] = None
    root_opening_mm: Optional[float] = None
    included_angle_deg: Optional[float] = None


@dataclass
class Position:
    """ASME IX QW-405 — Position variables.

    Attributes:
        groove: Qualified groove position(s), e.g. ["3G", "4G"].
        fillet: Qualified fillet position(s), e.g. ["3F"].
        progression: For vertical welds — "uphill" or "downhill".
    """

    groove: list[str] = field(default_factory=list)
    fillet: list[str] = field(default_factory=list)
    progression: Optional[str] = None


@dataclass
class ElectricalCharacteristics:
    """ASME IX QW-409 — Electrical characteristics."""

    current_type: Optional[str] = None  # "AC", "DCEP", "DCEN", "Pulsed"
    polarity: Optional[str] = None
    amperage_range_A: Optional[tuple[float, float]] = None
    voltage_range_V: Optional[tuple[float, float]] = None
    heat_input_kJ_mm: Optional[float] = None


@dataclass
class PreheatPostheat:
    """ASME IX QW-406 + QW-407 — Preheat + PWHT variables."""

    preheat_C_min: Optional[float] = None
    interpass_C_max: Optional[float] = None
    pwht_C: Optional[float] = None
    pwht_hold_h: Optional[float] = None


@dataclass
class Gases:
    """ASME IX QW-408 — Shielding-gas variables."""

    shielding: Optional[str] = None  # e.g. "Ar+2%CO2"
    flow_rate_L_min: Optional[float] = None
    backing_gas: Optional[str] = None
    trailing: Optional[str] = None


@dataclass
class Technique:
    """ASME IX QW-410 — Technique variables."""

    travel_speed_mm_s: Optional[float] = None
    oscillation: Optional[bool] = None
    string_or_weave: Optional[str] = None
    multipass: Optional[bool] = None
    cleaning: Optional[str] = None


@dataclass
class MechanicalTesting:
    """ASME IX QW-150 / QW-160 — PQR mechanical testing requirements."""

    tensile_UTS_MPa: Optional[float] = None
    bend_test: Optional[str] = None   # "Pass" / "Fail" / per QW-160
    cvn_J: Optional[float] = None
    hardness_HV_max: Optional[float] = None


# ---------------------------------------------------------------------------
# Top-level WPS / PQR / Revision dataclasses
# ---------------------------------------------------------------------------


@dataclass
class WPS:
    """Weld Procedure Specification — ASME BPVC Section IX (QW-482 layout).

    Attributes:
        weld_id: Internal id (e.g. ``"WPS-A001"``).
        revision: Revision integer (1, 2, 3, ...).
        process: Welding process — one of QW-251 family.
        base_metal: :class:`BaseMetals` block (QW-403).
        filler: :class:`FillerMetals` block (QW-404).
        joint: :class:`JointDesign` block (QW-402).
        position: :class:`Position` block (QW-405).
        electrical: :class:`ElectricalCharacteristics` block (QW-409).
        preheat_postheat: :class:`PreheatPostheat` block (QW-406/407).
        gases: :class:`Gases` block (QW-408).
        technique: :class:`Technique` block (QW-410).
        mechanical_testing: :class:`MechanicalTesting` (PQR data).
        pqr_refs: List of supporting PQR ids — e.g. ``["PQR-A001"]``.
        status: One of ``"DRAFT"``, ``"AUTHORIZED"``, ``"SUPERSEDED"``,
            ``"REVOKED"``.
        signed_by: Free-form signer name.
        signed_at: ISO-8601 UTC timestamp string of signing.
        signature_method: ``"manual"`` / ``"digital"`` / ``"none"``.
        notes: Free-form notes.
    """

    weld_id: str
    revision: int = 1
    process: Optional[str] = None
    base_metal: BaseMetals = field(default_factory=BaseMetals)
    filler: FillerMetals = field(default_factory=FillerMetals)
    joint: JointDesign = field(default_factory=JointDesign)
    position: Position = field(default_factory=Position)
    electrical: ElectricalCharacteristics = field(
        default_factory=ElectricalCharacteristics
    )
    preheat_postheat: PreheatPostheat = field(default_factory=PreheatPostheat)
    gases: Gases = field(default_factory=Gases)
    technique: Technique = field(default_factory=Technique)
    mechanical_testing: MechanicalTesting = field(default_factory=MechanicalTesting)
    pqr_refs: list[str] = field(default_factory=list)
    status: str = "DRAFT"
    signed_by: Optional[str] = None
    signed_at: Optional[str] = None
    signature_method: Optional[str] = None
    notes: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        return _stringify_tuples(d)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "WPS":
        return _wps_from_dict(data)

    @property
    def fingerprint(self) -> str:
        """SHA-256 of the canonical JSON — used for tamper-detection.

        Same hash strategy as :mod:`austenite.audit` so callers can pin
        a WPS revision in an audit record and verify it later.
        """

        payload = json.dumps(self.to_dict(), sort_keys=True, default=str).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()


@dataclass
class PQR:
    """Procedure Qualification Record — ASME IX QW-483 layout.

    Records the *actual* test-weld parameters used to qualify a WPS.
    Per QW-200 a WPS must be supported by at least one PQR whose tested
    range of essential variables (QW-403/404/etc) covers the WPS.

    Attributes:
        pqr_id: PQR identifier.
        process: Process used to qualify (must be one of QW-251 family).
        base_metal_p_number / group: As welded in the test plate.
        base_metal_thickness_mm: Coupon thickness — drives the qualified
            range per QW-451 (≈ 0.5·t to 2·t for groove).
        filler_f_number / a_number: Filler used in the test.
        position_tested: e.g. ``"3G"`` — qualifies positions per QW-461.9.
        mechanical: :class:`MechanicalTesting` — actual test results.
        date: ISO-8601 date the qualification was witnessed.
        witnessed_by: Inspector / AI name.
    """

    pqr_id: str
    process: Optional[str] = None
    base_metal_p_number: Optional[str] = None
    base_metal_group: Optional[str] = None
    base_metal_thickness_mm: Optional[float] = None
    filler_f_number: Optional[str] = None
    filler_a_number: Optional[str] = None
    position_tested: Optional[str] = None
    mechanical: MechanicalTesting = field(default_factory=MechanicalTesting)
    date: Optional[str] = None
    witnessed_by: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return _stringify_tuples(asdict(self))

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "PQR":
        return _pqr_from_dict(data)


@dataclass
class Revision:
    """A single entry in a WPS revision history."""

    weld_id: str
    revision: int
    date: str
    status: str
    reason: Optional[str] = None
    fingerprint: Optional[str] = None
    signed_by: Optional[str] = None


@dataclass
class WPSVerdict:
    """Result of :func:`validate` — ASME IX envelope-check verdict.

    Attributes:
        weld_id: WPS being validated.
        revision: Revision validated.
        passed: ``True`` iff every required QW-482 field is supplied AND
            its value is consistent with ASME IX (process recognised,
            position recognised, supporting PQR's range covers WPS, etc.).
        failed_items: One-liner descriptions of every failure.
        notes: One-liner per check (passing or failing).
        citation: Citation string with edition pointer.
    """

    weld_id: str
    revision: int
    passed: bool
    failed_items: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    citation: str = (
        "ASME BPVC Section IX (2021) — Welding, Brazing, and Fusing "
        "Qualifications. Article II (QW-200, QW-251–QW-292, QW-461, QW-482)."
    )

    def to_dict(self) -> dict[str, Any]:
        return {
            "weld_id": self.weld_id,
            "revision": self.revision,
            "passed": self.passed,
            "failed_items": list(self.failed_items),
            "notes": list(self.notes),
            "citation": self.citation,
        }


# ---------------------------------------------------------------------------
# Backend (storage) — pluggable.
# ---------------------------------------------------------------------------


class _Backend:
    """Storage backend protocol."""

    def save_wps(self, wps: WPS, *, reason: Optional[str] = None) -> Revision:
        raise NotImplementedError

    def load_wps(self, weld_id: str, revision: Optional[int] = None) -> WPS:
        raise NotImplementedError

    def history(self, weld_id: str) -> list[Revision]:
        raise NotImplementedError

    def list_wps(self) -> list[str]:
        raise NotImplementedError

    def save_pqr(self, pqr: PQR) -> None:
        raise NotImplementedError

    def load_pqr(self, pqr_id: str) -> PQR:
        raise NotImplementedError

    def list_pqr(self) -> list[str]:
        raise NotImplementedError


class _JsonBackend(_Backend):
    """JSON-on-disk backend — one file per ``(weld_id, revision)``.

    Layout::

        <root>/
          wps/<weld_id>/rev_<n>.json
          wps/<weld_id>/_history.json
          pqr/<pqr_id>.json
    """

    def __init__(self, path: Union[str, Path] = "./wps_store") -> None:
        self.root = Path(path)
        (self.root / "wps").mkdir(parents=True, exist_ok=True)
        (self.root / "pqr").mkdir(parents=True, exist_ok=True)

    # -- helpers --
    def _wps_dir(self, weld_id: str) -> Path:
        d = self.root / "wps" / weld_id
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _history_path(self, weld_id: str) -> Path:
        return self._wps_dir(weld_id) / "_history.json"

    def _load_history(self, weld_id: str) -> list[dict[str, Any]]:
        p = self._history_path(weld_id)
        if not p.exists():
            return []
        with p.open("r", encoding="utf-8") as f:
            return json.load(f)

    def _write_history(self, weld_id: str, items: list[dict[str, Any]]) -> None:
        with self._history_path(weld_id).open("w", encoding="utf-8") as f:
            json.dump(items, f, indent=2)

    # -- API --
    def save_wps(self, wps: WPS, *, reason: Optional[str] = None) -> Revision:
        d = self._wps_dir(wps.weld_id)
        rev_path = d / f"rev_{wps.revision}.json"
        with rev_path.open("w", encoding="utf-8") as f:
            json.dump(wps.to_dict(), f, indent=2, default=str)
        rev = Revision(
            weld_id=wps.weld_id,
            revision=wps.revision,
            date=datetime.now(timezone.utc).isoformat(),
            status=wps.status,
            reason=reason,
            fingerprint=wps.fingerprint,
            signed_by=wps.signed_by,
        )
        items = self._load_history(wps.weld_id)
        # Replace if same revision already present
        items = [i for i in items if i.get("revision") != wps.revision]
        items.append(asdict(rev))
        items.sort(key=lambda x: int(x.get("revision", 0)))
        self._write_history(wps.weld_id, items)
        return rev

    def load_wps(self, weld_id: str, revision: Optional[int] = None) -> WPS:
        d = self._wps_dir(weld_id)
        if revision is None:
            # latest
            files = sorted(d.glob("rev_*.json"))
            if not files:
                raise KeyError(f"No WPS found for {weld_id}")
            rev_path = files[-1]
        else:
            rev_path = d / f"rev_{revision}.json"
            if not rev_path.exists():
                raise KeyError(f"No revision {revision} for {weld_id}")
        with rev_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return WPS.from_dict(data)

    def history(self, weld_id: str) -> list[Revision]:
        items = self._load_history(weld_id)
        return [Revision(**i) for i in items]

    def list_wps(self) -> list[str]:
        return sorted(
            p.name for p in (self.root / "wps").iterdir() if p.is_dir()
        )

    def save_pqr(self, pqr: PQR) -> None:
        p = self.root / "pqr" / f"{pqr.pqr_id}.json"
        with p.open("w", encoding="utf-8") as f:
            json.dump(pqr.to_dict(), f, indent=2, default=str)

    def load_pqr(self, pqr_id: str) -> PQR:
        p = self.root / "pqr" / f"{pqr_id}.json"
        if not p.exists():
            raise KeyError(f"PQR {pqr_id} not found")
        with p.open("r", encoding="utf-8") as f:
            return PQR.from_dict(json.load(f))

    def list_pqr(self) -> list[str]:
        return sorted(
            p.stem for p in (self.root / "pqr").glob("*.json")
        )


class _SqliteBackend(_Backend):
    """SQLite backend — single-file, all revisions in one DB.

    Schema::

        wps_revision(weld_id TEXT, revision INT, payload TEXT,
                     status TEXT, fingerprint TEXT, signed_by TEXT,
                     date TEXT, reason TEXT, PRIMARY KEY(weld_id, revision))
        pqr(pqr_id TEXT PRIMARY KEY, payload TEXT)
    """

    def __init__(self, path: Union[str, Path] = "./wps.db") -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path))
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_schema(self) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS wps_revision (
                    weld_id TEXT NOT NULL,
                    revision INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    status TEXT NOT NULL,
                    fingerprint TEXT,
                    signed_by TEXT,
                    date TEXT,
                    reason TEXT,
                    PRIMARY KEY (weld_id, revision)
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS pqr (
                    pqr_id TEXT PRIMARY KEY,
                    payload TEXT NOT NULL
                )
                """
            )

    def save_wps(self, wps: WPS, *, reason: Optional[str] = None) -> Revision:
        payload = json.dumps(wps.to_dict(), default=str)
        date = datetime.now(timezone.utc).isoformat()
        with self._conn() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO wps_revision
                  (weld_id, revision, payload, status, fingerprint,
                   signed_by, date, reason)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    wps.weld_id,
                    int(wps.revision),
                    payload,
                    wps.status,
                    wps.fingerprint,
                    wps.signed_by,
                    date,
                    reason,
                ),
            )
        return Revision(
            weld_id=wps.weld_id,
            revision=wps.revision,
            date=date,
            status=wps.status,
            reason=reason,
            fingerprint=wps.fingerprint,
            signed_by=wps.signed_by,
        )

    def load_wps(self, weld_id: str, revision: Optional[int] = None) -> WPS:
        with self._conn() as conn:
            if revision is None:
                row = conn.execute(
                    "SELECT payload FROM wps_revision WHERE weld_id=? "
                    "ORDER BY revision DESC LIMIT 1",
                    (weld_id,),
                ).fetchone()
            else:
                row = conn.execute(
                    "SELECT payload FROM wps_revision "
                    "WHERE weld_id=? AND revision=?",
                    (weld_id, int(revision)),
                ).fetchone()
        if row is None:
            raise KeyError(
                f"No revision found for {weld_id}"
                + (f" (rev={revision})" if revision is not None else "")
            )
        return WPS.from_dict(json.loads(row[0]))

    def history(self, weld_id: str) -> list[Revision]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT weld_id, revision, date, status, reason, fingerprint, "
                "signed_by FROM wps_revision WHERE weld_id=? ORDER BY revision",
                (weld_id,),
            ).fetchall()
        return [
            Revision(
                weld_id=r[0],
                revision=int(r[1]),
                date=r[2] or "",
                status=r[3] or "",
                reason=r[4],
                fingerprint=r[5],
                signed_by=r[6],
            )
            for r in rows
        ]

    def list_wps(self) -> list[str]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT DISTINCT weld_id FROM wps_revision ORDER BY weld_id"
            ).fetchall()
        return [r[0] for r in rows]

    def save_pqr(self, pqr: PQR) -> None:
        payload = json.dumps(pqr.to_dict(), default=str)
        with self._conn() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO pqr (pqr_id, payload) VALUES (?, ?)",
                (pqr.pqr_id, payload),
            )

    def load_pqr(self, pqr_id: str) -> PQR:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT payload FROM pqr WHERE pqr_id=?", (pqr_id,)
            ).fetchone()
        if row is None:
            raise KeyError(f"PQR {pqr_id} not found")
        return PQR.from_dict(json.loads(row[0]))

    def list_pqr(self) -> list[str]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT pqr_id FROM pqr ORDER BY pqr_id"
            ).fetchall()
        return [r[0] for r in rows]


_BACKEND: Optional[_Backend] = None


def backend(
    kind: str = "json",
    *,
    path: Union[str, Path, None] = None,
) -> _Backend:
    """Select the storage backend.

    Args:
        kind: ``"json"`` (default — folder-per-WPS) or ``"sqlite"``
            (single-file DB).
        path: Folder (json) or db file (sqlite). Defaults to
            ``./wps_store`` and ``./wps.db`` respectively.

    Returns:
        The activated backend instance.
    """

    global _BACKEND
    kind = (kind or "json").lower()
    if kind == "sqlite":
        _BACKEND = _SqliteBackend(path or "./wps.db")
    elif kind == "json":
        _BACKEND = _JsonBackend(path or "./wps_store")
    else:
        raise ValueError(f"Unknown backend {kind!r}; pick 'json' or 'sqlite'")
    return _BACKEND


def _get_backend() -> _Backend:
    global _BACKEND
    if _BACKEND is None:
        _BACKEND = _JsonBackend("./wps_store")
    return _BACKEND


# ---------------------------------------------------------------------------
# Parsing — PDF / Word / HTML / text.
# ---------------------------------------------------------------------------


def parse(
    source: Union[str, Path, bytes, None] = None,
    *,
    text: Optional[str] = None,
) -> WPS:
    """Parse a Weld Procedure Specification.

    Accepts any of:

    * Path / str pointing to a ``.pdf``, ``.docx``, ``.html``, ``.txt``,
      ``.xml``, or ``.json`` file.
    * Raw ``bytes``.
    * Pre-extracted text via ``text=``.

    The parser is intentionally robust to incomplete forms: missing
    fields stay ``None`` and surface in :func:`validate`. PDF parsing
    falls back to a no-op (empty WPS) if ``pypdf`` is not installed —
    the function never raises on missing optional dependencies.

    Args:
        source: File path or bytes.
        text: Pre-extracted text (skips file I/O).

    Returns:
        Populated :class:`WPS`.
    """

    if text is not None:
        return _parse_text(text)
    if source is None:
        raise TypeError("Provide either `source` or `text`.")

    if isinstance(source, (bytes, bytearray)):
        raw = bytes(source)
        return _parse_bytes(raw, ext_hint=".pdf" if raw[:4] == b"%PDF" else ".txt")

    p = Path(source)
    if not p.exists():
        # If the string looks like a path but doesn't exist, treat as inline text
        return _parse_text(str(source))

    raw = p.read_bytes()
    return _parse_bytes(raw, ext_hint=p.suffix.lower(), filename=p.name)


def _parse_bytes(raw: bytes, *, ext_hint: str = "", filename: str = "") -> WPS:
    """Dispatch based on extension / magic-bytes."""

    if raw[:4] == b"%PDF" or ext_hint == ".pdf":
        text = _extract_pdf_text(raw)
        if not text.strip() and filename:
            # Empty extraction → derive a stub WPS from the filename
            return _stub_from_filename(filename)
        wps = _parse_text(text)
        if filename and not wps.weld_id:
            wps.weld_id = _derive_weld_id_from_name(filename)
        return wps

    if ext_hint == ".json" or raw[:1] == b"{":
        try:
            data = json.loads(raw.decode("utf-8"))
            return WPS.from_dict(data)
        except (UnicodeDecodeError, json.JSONDecodeError):
            pass

    if ext_hint == ".xml" or raw.lstrip().startswith(b"<"):
        text = raw.decode("utf-8", errors="replace")
        wps = _parse_xml(text)
        if filename and not wps.weld_id:
            wps.weld_id = _derive_weld_id_from_name(filename)
        return wps

    if ext_hint == ".docx":
        text = _extract_docx_text(raw)
        wps = _parse_text(text)
        if filename and not wps.weld_id:
            wps.weld_id = _derive_weld_id_from_name(filename)
        return wps

    # Default: treat as text
    try:
        decoded = raw.decode("utf-8")
    except UnicodeDecodeError:
        decoded = raw.decode("latin-1", errors="replace")
    wps = _parse_text(decoded)
    if filename and not wps.weld_id:
        wps.weld_id = _derive_weld_id_from_name(filename)
    return wps


def _extract_pdf_text(raw: bytes) -> str:
    """Try pypdf, then pdfplumber. Return empty string if both missing."""

    try:
        from pypdf import PdfReader  # type: ignore

        reader = PdfReader(io.BytesIO(raw))
        parts: list[str] = []
        for page in reader.pages:
            try:
                parts.append(page.extract_text() or "")
            except Exception:
                pass
        joined = "\n".join(parts).strip()
        if joined:
            return joined
    except ImportError:
        pass
    except Exception:
        pass

    try:
        import pdfplumber  # type: ignore

        parts = []
        with pdfplumber.open(io.BytesIO(raw)) as pdf:
            for page in pdf.pages:
                try:
                    parts.append(page.extract_text() or "")
                except Exception:
                    pass
        return "\n".join(parts).strip()
    except ImportError:
        return ""
    except Exception:
        return ""


def _extract_docx_text(raw: bytes) -> str:
    """Try python-docx; return empty if not installed."""

    try:
        import docx  # type: ignore
        from docx import Document  # type: ignore

        doc = Document(io.BytesIO(raw))
        return "\n".join(p.text for p in doc.paragraphs)
    except ImportError:
        return ""
    except Exception:
        return ""


def _derive_weld_id_from_name(name: str) -> str:
    """``WPS-A001-Rev3.pdf`` → ``WPS-A001``."""

    stem = Path(name).stem
    # Strip a trailing -RevN / -rN / -R3
    stem = re.sub(r"[-_ ]?(rev|r|revision)[-_ ]?\d+$", "", stem, flags=re.I)
    return stem.strip()


def _stub_from_filename(name: str) -> WPS:
    """Filename-only stub used when PDF text extraction fails entirely."""

    weld_id = _derive_weld_id_from_name(name)
    rev_match = re.search(r"(?:rev|r)[-_ ]?(\d+)", name, flags=re.I)
    revision = int(rev_match.group(1)) if rev_match else 1
    return WPS(weld_id=weld_id or "WPS-UNKNOWN", revision=revision)


# Regex patterns for free-text extraction
_RE_WELD_ID = re.compile(r"\b(WPS[-_ ]?[A-Z0-9]+)", re.I)
_RE_REV = re.compile(r"\b(?:rev(?:ision)?|r)[\.\-_:\s]*(\d+)", re.I)
_RE_PROCESS = re.compile(
    r"\b(SMAW|GTAW|GMAW|FCAW|SAW|PAW|OFW|ESW|EBW|LBW)\b", re.I
)
# Anchor on word boundary + require the literal "Number" / "No" / "#" qualifier so
# we don't accidentally match against A5.18 / AWS A001 etc.
_RE_P_NUMBER = re.compile(
    r"\bP[\s\-]?(?:Number|No\.?|#)\s*[:\-]?\s*([0-9]+[A-Z]?)", re.I
)
_RE_F_NUMBER = re.compile(
    r"\bF[\s\-]?(?:Number|No\.?|#)\s*[:\-]?\s*([0-9]+)", re.I
)
_RE_A_NUMBER = re.compile(
    r"\bA[\s\-]?(?:Number|No\.?|#)\s*[:\-]?\s*([0-9]+)", re.I
)
_RE_AWS = re.compile(r"\b(?:AWS\s+)?(A5\.\d+[A-Z]?)(?:\s+([EF][A-Z0-9-]+))?", re.I)
_RE_POSITION = re.compile(r"\b(1G|2G|3G|4G|5G|6G|6GR|1F|2F|2FR|3F|4F|5F)\b")
_RE_PROGRESS = re.compile(r"\b(uphill|downhill)\b", re.I)
_RE_PREHEAT = re.compile(r"preheat[\s\S]{0,40}?(\d{1,4})\s*(?:°\s*)?C", re.I)
_RE_INTERPASS = re.compile(r"interpass[\s\S]{0,40}?(\d{1,4})\s*(?:°\s*)?C", re.I)
_RE_PWHT_T = re.compile(r"PWHT[\s\S]{0,80}?(\d{2,4})\s*(?:°\s*)?C", re.I)
_RE_PWHT_H = re.compile(r"(?:hold|soak)[\s\S]{0,40}?(\d+(?:\.\d+)?)\s*h", re.I)
_RE_CURRENT_TYPE = re.compile(r"\b(DCEP|DCEN|AC|Pulsed)\b", re.I)
_RE_AMPS = re.compile(
    r"(?:amperage|current)[\s\S]{0,40}?(\d{2,4})\s*[-–to]+\s*(\d{2,4})\s*A?",
    re.I,
)
_RE_VOLTS = re.compile(
    r"voltage[\s\S]{0,40}?(\d{1,3}(?:\.\d+)?)\s*[-–to]+\s*(\d{1,3}(?:\.\d+)?)\s*V?",
    re.I,
)
_RE_HEAT_INPUT = re.compile(r"heat[\s\-_]?input[\s\S]{0,40}?(\d+(?:\.\d+)?)\s*kJ", re.I)
_RE_SHIELD = re.compile(r"shield(?:ing)?(?:\s+gas)?[\s:\-]+([A-Z][A-Za-z0-9%\+\s]+)", re.I)
_RE_FLOW = re.compile(r"flow[\s\S]{0,40}?(\d+(?:\.\d+)?)\s*L\/?min", re.I)
_RE_PQR = re.compile(r"\b(PQR[-_ ]?[A-Z0-9]+)", re.I)
_RE_THK_RANGE = re.compile(
    r"thickness[\s\S]{0,80}?(\d+(?:\.\d+)?)\s*[-–to]+\s*(\d+(?:\.\d+)?)\s*(?:mm|in)",
    re.I,
)
_RE_BACKING = re.compile(r"backing[\s:\-]+(yes|no|with|without|none)", re.I)
_RE_GROOVE_TYPE = re.compile(
    r"groove[\s\S]{0,40}?(single[\s\-]?[uvj]|double[\s\-]?[uvj]|square|bevel)",
    re.I,
)
_RE_ROOT_OPENING = re.compile(
    r"root[\s\-]?opening[\s:\-]+(\d+(?:\.\d+)?)\s*mm", re.I
)
_RE_INC_ANGLE = re.compile(
    r"(?:included|groove)\s*angle[\s:\-]+(\d+(?:\.\d+)?)\s*(?:°|deg)?", re.I
)
_RE_TRAVEL = re.compile(
    r"travel(?:\s+speed)?[\s:\-]+(\d+(?:\.\d+)?)\s*mm\s*\/?\s*s", re.I
)
_RE_UTS = re.compile(r"(?:UTS|tensile)[\s\S]{0,40}?(\d{3,4})\s*MPa", re.I)


def _parse_text(text: str) -> WPS:
    """Free-text WPS parser — regex-based, tolerant of layout variations."""

    if not text:
        return WPS(weld_id="WPS-UNKNOWN")

    m = _RE_WELD_ID.search(text)
    weld_id = (m.group(1) if m else "WPS-UNKNOWN").upper().replace(" ", "-").replace("_", "-")
    weld_id = re.sub(r"-+", "-", weld_id)

    m = _RE_REV.search(text)
    revision = int(m.group(1)) if m else 1

    process = None
    m = _RE_PROCESS.search(text)
    if m:
        process = m.group(1).upper()

    # Base metal
    base = BaseMetals()
    m = _RE_P_NUMBER.search(text)
    if m:
        base.p_number = m.group(1)
    # Group: try "Group N" pattern
    m = re.search(r"P[-\s]?(?:Number|No\.?|#)?\s*[:\-]?\s*[0-9]+[A-Z]?[,\s]+Gr(?:oup|p)?\.?\s*([0-9]+)", text, re.I)
    if m:
        base.group = m.group(1)
    m = re.search(r"\bSA[-\s]?\d{2,4}(?:[-\s]?Gr\.?\s*[A-Z0-9]+)?", text)
    if m:
        base.spec = m.group(0).replace(" ", "")
    if base.spec is None:
        m = re.search(r"\b(ASTM\s+A\d{2,4}|EN\s+10025[-\d]*|API\s+5L\s+X\d+)", text, re.I)
        if m:
            base.spec = m.group(0)
    m = _RE_THK_RANGE.search(text)
    if m:
        base.thickness_range_mm = (float(m.group(1)), float(m.group(2)))

    # Filler metal
    filler = FillerMetals()
    m = _RE_F_NUMBER.search(text)
    if m:
        filler.f_number = m.group(1)
    m = _RE_A_NUMBER.search(text)
    if m:
        filler.a_number = m.group(1)
    m = _RE_AWS.search(text)
    if m:
        spec = m.group(1)
        cls = m.group(2)
        filler.aws_spec = f"AWS {spec} {cls}".strip() if cls else f"AWS {spec}".strip()
    m = re.search(r"(?:electrode\s+)?(?:size|diam(?:eter)?)[\s:\-]+(\d+(?:\.\d+)?)\s*mm", text, re.I)
    if m:
        filler.size_mm = float(m.group(1))

    # Joint
    joint = JointDesign()
    if re.search(r"\bbutt\b", text, re.I):
        joint.joint_type = "Butt"
    elif re.search(r"\bfillet\b", text, re.I):
        joint.joint_type = "Fillet"
    elif re.search(r"\bcorner\b", text, re.I):
        joint.joint_type = "Corner"
    m = _RE_GROOVE_TYPE.search(text)
    if m:
        joint.groove_type = m.group(1).strip().title().replace(" ", "-")
    m = _RE_BACKING.search(text)
    if m:
        joint.backing = m.group(1).lower()
    m = _RE_ROOT_OPENING.search(text)
    if m:
        joint.root_opening_mm = float(m.group(1))
    m = _RE_INC_ANGLE.search(text)
    if m:
        joint.included_angle_deg = float(m.group(1))

    # Position
    positions = list(set(_RE_POSITION.findall(text)))
    pos = Position()
    pos.groove = sorted([p for p in positions if p.endswith("G")])
    pos.fillet = sorted([p for p in positions if p.endswith("F")])
    m = _RE_PROGRESS.search(text)
    if m:
        pos.progression = m.group(1).lower()

    # Electrical
    elec = ElectricalCharacteristics()
    m = _RE_CURRENT_TYPE.search(text)
    if m:
        elec.current_type = m.group(1).upper()
    m = _RE_AMPS.search(text)
    if m:
        elec.amperage_range_A = (float(m.group(1)), float(m.group(2)))
    m = _RE_VOLTS.search(text)
    if m:
        elec.voltage_range_V = (float(m.group(1)), float(m.group(2)))
    m = _RE_HEAT_INPUT.search(text)
    if m:
        elec.heat_input_kJ_mm = float(m.group(1))

    # Preheat/postheat
    pre = PreheatPostheat()
    m = _RE_PREHEAT.search(text)
    if m:
        pre.preheat_C_min = float(m.group(1))
    m = _RE_INTERPASS.search(text)
    if m:
        pre.interpass_C_max = float(m.group(1))
    m = _RE_PWHT_T.search(text)
    if m:
        pre.pwht_C = float(m.group(1))
    m = _RE_PWHT_H.search(text)
    if m:
        pre.pwht_hold_h = float(m.group(1))

    # Gases
    gases = Gases()
    m = _RE_SHIELD.search(text)
    if m:
        gases.shielding = m.group(1).strip().split(";")[0].split(",")[0].strip()
    m = _RE_FLOW.search(text)
    if m:
        gases.flow_rate_L_min = float(m.group(1))

    # Technique
    tech = Technique()
    m = _RE_TRAVEL.search(text)
    if m:
        tech.travel_speed_mm_s = float(m.group(1))
    if re.search(r"\bmulti[\s-]?pass\b", text, re.I):
        tech.multipass = True
    if re.search(r"\bsingle[\s-]?pass\b", text, re.I):
        tech.multipass = False
    if re.search(r"\bweav(?:e|ing)\b", text, re.I):
        tech.string_or_weave = "weave"
    elif re.search(r"\bstringer\b", text, re.I):
        tech.string_or_weave = "string"

    # Mechanical testing
    mech = MechanicalTesting()
    m = _RE_UTS.search(text)
    if m:
        mech.tensile_UTS_MPa = float(m.group(1))
    m = re.search(r"CVN[\s\S]{0,40}?(\d{1,3})\s*J", text, re.I)
    if m:
        mech.cvn_J = float(m.group(1))
    m = re.search(r"hardness[\s\S]{0,40}?(\d{2,4})\s*HV", text, re.I)
    if m:
        mech.hardness_HV_max = float(m.group(1))

    # PQR references
    pqr_refs = sorted({m.upper() for m in _RE_PQR.findall(text)})

    return WPS(
        weld_id=weld_id,
        revision=revision,
        process=process,
        base_metal=base,
        filler=filler,
        joint=joint,
        position=pos,
        electrical=elec,
        preheat_postheat=pre,
        gases=gases,
        technique=tech,
        mechanical_testing=mech,
        pqr_refs=pqr_refs,
    )


def _parse_xml(text: str) -> WPS:
    """Parse the AWS-style XML schema we emit in :func:`export_xml`.

    Round-trip robust; not a fully-general AWS WPS-XML parser.
    """

    # Minimal element extraction via regex (avoids the xml stdlib for
    # robustness on partial / malformed input).
    def tag(name: str) -> Optional[str]:
        m = re.search(rf"<{name}>(.*?)</{name}>", text, re.S)
        return m.group(1).strip() if m else None

    weld_id = tag("weld_id") or "WPS-UNKNOWN"
    revision = int(tag("revision") or "1")
    process = tag("process")
    base = BaseMetals(
        p_number=tag("p_number"),
        group=tag("group"),
        spec=tag("base_spec"),
    )
    filler = FillerMetals(
        f_number=tag("f_number"),
        a_number=tag("a_number"),
        aws_spec=tag("aws_spec"),
    )
    return WPS(
        weld_id=weld_id,
        revision=revision,
        process=process,
        base_metal=base,
        filler=filler,
    )


# ---------------------------------------------------------------------------
# Validation — ASME IX QW-200 envelope check
# ---------------------------------------------------------------------------


def validate(wps: WPS) -> WPSVerdict:
    """Validate a WPS against ASME IX (QW-200 / QW-251 / QW-461 / QW-482).

    Checks:

    * Welding process is recognised per QW-251 family.
    * Position is recognised per QW-461.
    * Required QW-482 fields are present (process, base metal P-number,
      filler F-number, position, electrical characteristics, preheat).
    * At least one supporting PQR is referenced (QW-200).
    * For SAW/GTAW/GMAW with backing gas, the gas block is required
      (QW-408).

    Args:
        wps: WPS to validate.

    Returns:
        :class:`WPSVerdict` with ``.passed`` / ``.failed_items``.
    """

    notes: list[str] = []
    failed: list[str] = []

    # 1. Process recognised
    if wps.process is None:
        failed.append("Process: missing — QW-251 requires one of "
                      f"{sorted(_VALID_PROCESSES)}")
    elif wps.process.upper() not in _VALID_PROCESSES:
        failed.append(
            f"Process: '{wps.process}' not recognised — QW-251 "
            f"requires one of {sorted(_VALID_PROCESSES)}"
        )
    else:
        notes.append(f"Process: {wps.process} (recognised per QW-251)")

    # 2. Base metal P-number
    if not wps.base_metal.p_number:
        failed.append("Base metal: P-Number missing (QW-403 / QW-422 required)")
    else:
        notes.append(f"Base metal P-No: {wps.base_metal.p_number}")

    # 3. Filler F-number
    if not wps.filler.f_number:
        failed.append("Filler metal: F-Number missing (QW-404 / QW-432 required)")
    else:
        notes.append(f"Filler F-No: {wps.filler.f_number}")

    # 4. Position(s)
    all_positions = list(wps.position.groove) + list(wps.position.fillet)
    if not all_positions:
        failed.append(
            "Position: none qualified — QW-461 requires at least one "
            "groove or fillet position"
        )
    else:
        for p in all_positions:
            if p not in _VALID_POSITIONS:
                failed.append(
                    f"Position '{p}' not recognised — QW-461 valid "
                    f"positions: {sorted(_VALID_POSITIONS)}"
                )
        notes.append(f"Positions qualified: {', '.join(sorted(all_positions))}")

    # 5. Electrical characteristics
    if (
        wps.electrical.current_type is None
        and wps.electrical.amperage_range_A is None
    ):
        failed.append("Electrical: current type + amperage missing (QW-409 essential)")
    else:
        notes.append("Electrical: current/amperage supplied (QW-409)")

    # 6. Preheat
    if wps.preheat_postheat.preheat_C_min is None:
        # Per QW-406, preheat is essential — but allow 0/none for P-No 1
        # group 1 thin sections. We still warn but don't fail outright.
        notes.append("Preheat: not supplied (QW-406 — may be acceptable for P-1 thin)")
    else:
        notes.append(
            f"Preheat: min {wps.preheat_postheat.preheat_C_min} C (QW-406)"
        )

    # 7. Supporting PQR
    if not wps.pqr_refs:
        failed.append(
            f"No supporting PQR referenced — QW-200 requires "
            f"WPS {wps.weld_id} to be qualified by ≥1 PQR"
        )
    else:
        notes.append(f"Supporting PQRs: {', '.join(wps.pqr_refs)}")

    # 8. Gas required for GTAW/GMAW/FCAW
    proc = (wps.process or "").upper()
    if proc in ("GTAW", "GMAW", "FCAW", "PAW"):
        if not wps.gases.shielding:
            failed.append(
                f"Shielding gas missing — QW-408 essential for {proc}"
            )
        else:
            notes.append(f"Shielding gas: {wps.gases.shielding}")

    return WPSVerdict(
        weld_id=wps.weld_id,
        revision=wps.revision,
        passed=not failed,
        failed_items=failed,
        notes=notes,
    )


# ---------------------------------------------------------------------------
# Revision tracking
# ---------------------------------------------------------------------------


def save(wps: WPS, *, reason: Optional[str] = None) -> Revision:
    """Persist a WPS revision to the active backend."""

    return _get_backend().save_wps(wps, reason=reason)


def load(weld_id: str, *, revision: Optional[int] = None) -> WPS:
    """Load a WPS (latest revision unless ``revision=`` given)."""

    return _get_backend().load_wps(weld_id, revision=revision)


def list_wps() -> list[str]:
    """Return every WPS id known to the backend."""

    return _get_backend().list_wps()


def history(weld_id: str) -> list[Revision]:
    """Return the revision history for ``weld_id`` (oldest → newest)."""

    return _get_backend().history(weld_id)


def current(weld_id: str) -> WPS:
    """Return the *latest authorized* revision of ``weld_id``.

    Iterates the history from newest to oldest, returns the first entry
    whose status is ``AUTHORIZED``. Falls back to the latest revision if
    none is explicitly authorized.

    Raises:
        KeyError: If the WPS has no revisions stored at all.
    """

    backend = _get_backend()
    hist = backend.history(weld_id)
    if not hist:
        raise KeyError(f"No history for {weld_id}")
    # Newest first
    for rev in reversed(hist):
        if rev.status == "AUTHORIZED":
            return backend.load_wps(weld_id, revision=rev.revision)
    # No authorized revision — return the latest
    return backend.load_wps(weld_id, revision=hist[-1].revision)


def supersede(
    weld_id: str,
    *,
    from_rev: int,
    to_rev: int,
    reason: str,
) -> Revision:
    """Mark ``from_rev`` as SUPERSEDED by ``to_rev`` and audit the reason.

    Args:
        weld_id: WPS id.
        from_rev: Revision being superseded.
        to_rev: New revision that replaces it.
        reason: Free-form reason — recorded in the revision history
            (e.g. ``"Updated joint geometry per ECN-1234"``).

    Returns:
        :class:`Revision` entry for the (now authorized) ``to_rev``.
    """

    backend = _get_backend()
    # Load + mutate the old rev
    old = backend.load_wps(weld_id, revision=from_rev)
    old.status = "SUPERSEDED"
    backend.save_wps(old, reason=f"superseded by rev {to_rev}: {reason}")
    # Load + authorize the new rev
    new = backend.load_wps(weld_id, revision=to_rev)
    new.status = "AUTHORIZED"
    return backend.save_wps(new, reason=reason)


def sign(
    wps: WPS,
    *,
    signer: str,
    signature_method: str = "manual",
) -> Revision:
    """Apply a signature to a WPS and re-save it as AUTHORIZED.

    Args:
        wps: WPS to sign.
        signer: Free-form signer name (often "Name, P.E.").
        signature_method: ``"manual"`` (wet ink), ``"digital"`` (PKI),
            or ``"none"``.

    Returns:
        The Revision entry recorded for the signed copy.
    """

    wps.signed_by = signer
    wps.signed_at = datetime.now(timezone.utc).isoformat()
    wps.signature_method = signature_method
    wps.status = "AUTHORIZED"
    return _get_backend().save_wps(wps, reason=f"signed by {signer}")


# ---------------------------------------------------------------------------
# Exports — PDF / XML
# ---------------------------------------------------------------------------


def export_pdf(wps: WPS, path: Union[str, Path]) -> Path:
    """Write a one-page text-only PDF summary of the WPS.

    Uses ``reportlab`` if installed; otherwise falls back to a ``.txt``
    file with the same content (graceful degradation).
    """

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    summary = _text_summary(wps)
    try:
        from reportlab.lib.pagesizes import letter  # type: ignore
        from reportlab.pdfgen import canvas  # type: ignore
    except ImportError:
        out = path.with_suffix(".txt")
        out.write_text(summary, encoding="utf-8")
        return out

    c = canvas.Canvas(str(path), pagesize=letter)
    width, height = letter
    y = height - 50
    c.setFont("Helvetica-Bold", 13)
    c.drawString(
        50, y, f"WPS {wps.weld_id} Rev {wps.revision} — ASME IX QW-482"
    )
    y -= 20
    c.setFont("Helvetica", 9)
    for line in summary.split("\n"):
        if y < 50:
            c.showPage()
            y = height - 50
            c.setFont("Helvetica", 9)
        c.drawString(50, y, line[:120])
        y -= 11
    c.save()
    return path


def export_xml(wps: WPS, path: Union[str, Path]) -> Path:
    """Write an AWS-style WPS-XML file.

    The schema is a pragmatic subset — sufficient for tool round-trip
    and good enough for shop import. Not a literal AWS XSD claim.
    """

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    def el(tag: str, value: Any) -> str:
        if value is None:
            return ""
        return f"  <{tag}>{xml_escape(str(value))}</{tag}>\n"

    parts: list[str] = ['<?xml version="1.0" encoding="UTF-8"?>\n']
    parts.append('<WPS xmlns="urn:aws:wps:1.0">\n')
    parts.append(el("weld_id", wps.weld_id))
    parts.append(el("revision", wps.revision))
    parts.append(el("process", wps.process))
    parts.append(el("status", wps.status))
    parts.append(el("p_number", wps.base_metal.p_number))
    parts.append(el("group", wps.base_metal.group))
    parts.append(el("base_spec", wps.base_metal.spec))
    parts.append(el("f_number", wps.filler.f_number))
    parts.append(el("a_number", wps.filler.a_number))
    parts.append(el("aws_spec", wps.filler.aws_spec))
    parts.append(el("joint_type", wps.joint.joint_type))
    parts.append(el("groove_type", wps.joint.groove_type))
    if wps.position.groove:
        parts.append(
            el("positions_groove", ",".join(wps.position.groove))
        )
    if wps.position.fillet:
        parts.append(
            el("positions_fillet", ",".join(wps.position.fillet))
        )
    parts.append(el("preheat_C_min", wps.preheat_postheat.preheat_C_min))
    parts.append(el("pwht_C", wps.preheat_postheat.pwht_C))
    parts.append(el("shielding", wps.gases.shielding))
    for pqr_id in wps.pqr_refs:
        parts.append(el("pqr_ref", pqr_id))
    parts.append(el("signed_by", wps.signed_by))
    parts.append(el("signed_at", wps.signed_at))
    parts.append("</WPS>\n")

    path.write_text("".join(parts), encoding="utf-8")
    return path


def _text_summary(wps: WPS) -> str:
    """Human-readable one-page summary used by PDF export."""

    bm = wps.base_metal
    fl = wps.filler
    jo = wps.joint
    el = wps.electrical
    pp = wps.preheat_postheat
    lines = [
        f"WPS:        {wps.weld_id}",
        f"Revision:   {wps.revision}",
        f"Status:     {wps.status}",
        f"Process:    {wps.process or '—'}",
        "",
        "BASE METAL (QW-403)",
        f"  P-Number:   {bm.p_number or '—'}",
        f"  Group:      {bm.group or '—'}",
        f"  Spec:       {bm.spec or '—'}",
        f"  Thickness:  {bm.thickness_range_mm or '—'} mm",
        "",
        "FILLER METAL (QW-404)",
        f"  F-Number:   {fl.f_number or '—'}",
        f"  A-Number:   {fl.a_number or '—'}",
        f"  AWS spec:   {fl.aws_spec or '—'}",
        "",
        "JOINT DESIGN (QW-402)",
        f"  Joint:      {jo.joint_type or '—'}",
        f"  Groove:     {jo.groove_type or '—'}",
        f"  Backing:    {jo.backing or '—'}",
        "",
        f"POSITIONS (QW-405 / QW-461): "
        f"{', '.join(sorted(set(wps.position.groove + wps.position.fillet))) or '—'}",
        "",
        "ELECTRICAL (QW-409)",
        f"  Current:    {el.current_type or '—'}",
        f"  Amps:       {el.amperage_range_A or '—'}",
        f"  Volts:      {el.voltage_range_V or '—'}",
        f"  Heat input: {el.heat_input_kJ_mm or '—'} kJ/mm",
        "",
        "PREHEAT / PWHT (QW-406 / QW-407)",
        f"  Preheat:    {pp.preheat_C_min or '—'} C min",
        f"  PWHT:       {pp.pwht_C or '—'} C, {pp.pwht_hold_h or '—'} h",
        "",
        "SHIELDING GAS (QW-408)",
        f"  Gas:        {wps.gases.shielding or '—'}",
        f"  Flow:       {wps.gases.flow_rate_L_min or '—'} L/min",
        "",
        f"SUPPORTING PQRs: {', '.join(wps.pqr_refs) or '—'}",
    ]
    if wps.signed_by:
        lines += [
            "",
            f"Signed by:  {wps.signed_by} ({wps.signature_method or 'manual'})",
            f"Signed at:  {wps.signed_at}",
        ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# PQR sub-namespace
# ---------------------------------------------------------------------------


class _PQR_NS:
    """Namespace for PQR helpers — exposed as ``au.wps.pqr``."""

    @staticmethod
    def parse(source: Union[str, Path, bytes, None] = None,
              *, text: Optional[str] = None) -> PQR:
        """Parse a PQR PDF / text into a :class:`PQR`."""

        if text is None and source is None:
            raise TypeError("Provide `source` or `text`")
        if text is not None:
            return _parse_pqr_text(text)
        if isinstance(source, (bytes, bytearray)):
            t = _extract_pdf_text(bytes(source))
            return _parse_pqr_text(t)
        p = Path(source)  # type: ignore[arg-type]
        if not p.exists():
            return _parse_pqr_text(str(source))
        raw = p.read_bytes()
        if raw[:4] == b"%PDF" or p.suffix.lower() == ".pdf":
            return _parse_pqr_text(_extract_pdf_text(raw))
        return _parse_pqr_text(raw.decode("utf-8", errors="replace"))

    @staticmethod
    def save(pqr: PQR) -> None:
        _get_backend().save_pqr(pqr)

    @staticmethod
    def load(pqr_id: str) -> PQR:
        return _get_backend().load_pqr(pqr_id)

    @staticmethod
    def list_pqr() -> list[str]:
        return _get_backend().list_pqr()


pqr = _PQR_NS()


def _parse_pqr_text(text: str) -> PQR:
    """Free-text PQR parser — same regex toolkit as WPS but emits PQR fields."""

    if not text:
        return PQR(pqr_id="PQR-UNKNOWN")
    m = _RE_PQR.search(text)
    pqr_id = m.group(1).upper() if m else "PQR-UNKNOWN"
    pqr_id = pqr_id.replace(" ", "-").replace("_", "-")

    process = None
    m = _RE_PROCESS.search(text)
    if m:
        process = m.group(1).upper()
    pno = None
    m = _RE_P_NUMBER.search(text)
    if m:
        pno = m.group(1)
    fno = None
    m = _RE_F_NUMBER.search(text)
    if m:
        fno = m.group(1)
    ano = None
    m = _RE_A_NUMBER.search(text)
    if m:
        ano = m.group(1)
    thk = None
    m = re.search(
        r"(?:thickness|coupon)[\s\S]{0,40}?(\d+(?:\.\d+)?)\s*mm", text, re.I
    )
    if m:
        thk = float(m.group(1))
    pos = None
    m = _RE_POSITION.search(text)
    if m:
        pos = m.group(1).upper()

    mech = MechanicalTesting()
    m = _RE_UTS.search(text)
    if m:
        mech.tensile_UTS_MPa = float(m.group(1))
    if re.search(r"bend[\s\S]{0,40}?pass", text, re.I):
        mech.bend_test = "Pass"
    elif re.search(r"bend[\s\S]{0,40}?fail", text, re.I):
        mech.bend_test = "Fail"
    m = re.search(r"CVN[\s\S]{0,40}?(\d+(?:\.\d+)?)\s*J", text, re.I)
    if m:
        mech.cvn_J = float(m.group(1))

    return PQR(
        pqr_id=pqr_id,
        process=process,
        base_metal_p_number=pno,
        base_metal_thickness_mm=thk,
        filler_f_number=fno,
        filler_a_number=ano,
        position_tested=pos,
        mechanical=mech,
    )


def find_qualifying_pqrs(wps: WPS) -> list[PQR]:
    """Return the subset of stored PQRs that qualify ``wps`` per QW-200.

    A PQR qualifies the WPS if:
      * process matches (QW-251),
      * base-metal P-Number matches (QW-403),
      * filler F-Number matches (QW-404),
      * if a coupon thickness is known, the WPS thickness range falls
        inside the QW-451-derived qualified range (``0.5·t_PQR`` to
        ``2·t_PQR`` for grooves up to 38 mm, per QW-451.1).
    """

    backend = _get_backend()
    out: list[PQR] = []
    for pqr_id in backend.list_pqr():
        try:
            pq = backend.load_pqr(pqr_id)
        except Exception:
            continue
        if pq.process and wps.process and pq.process.upper() != wps.process.upper():
            continue
        if (
            pq.base_metal_p_number
            and wps.base_metal.p_number
            and pq.base_metal_p_number != wps.base_metal.p_number
        ):
            continue
        if (
            pq.filler_f_number
            and wps.filler.f_number
            and pq.filler_f_number != wps.filler.f_number
        ):
            continue
        # QW-451 thickness check
        if pq.base_metal_thickness_mm and wps.base_metal.thickness_range_mm:
            t_pqr = pq.base_metal_thickness_mm
            t_min = 0.5 * t_pqr if t_pqr >= 1.6 else t_pqr  # QW-451.1
            t_max = 2.0 * t_pqr
            wps_lo, wps_hi = wps.base_metal.thickness_range_mm
            if wps_lo < t_min or wps_hi > t_max:
                continue
        out.append(pq)
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _stringify_tuples(obj: Any) -> Any:
    """Convert tuple-typed dataclass fields to lists for JSON output."""

    if isinstance(obj, tuple):
        return list(obj)
    if isinstance(obj, dict):
        return {k: _stringify_tuples(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_stringify_tuples(v) for v in obj]
    return obj


def _wps_from_dict(data: Mapping[str, Any]) -> WPS:
    """Build a WPS from a JSON-loaded dict (inverse of :meth:`WPS.to_dict`)."""

    def _make(cls, key):
        block = data.get(key) or {}
        # Coerce list-typed tuple fields back to tuples
        for field_name in ("thickness_range_mm", "diameter_range_mm",
                           "amperage_range_A", "voltage_range_V"):
            v = block.get(field_name)
            if isinstance(v, list) and len(v) == 2:
                block[field_name] = tuple(v)
        return cls(**{k: v for k, v in block.items() if k in cls.__dataclass_fields__})

    return WPS(
        weld_id=data.get("weld_id", "WPS-UNKNOWN"),
        revision=int(data.get("revision", 1)),
        process=data.get("process"),
        base_metal=_make(BaseMetals, "base_metal"),
        filler=_make(FillerMetals, "filler"),
        joint=_make(JointDesign, "joint"),
        position=_make(Position, "position"),
        electrical=_make(ElectricalCharacteristics, "electrical"),
        preheat_postheat=_make(PreheatPostheat, "preheat_postheat"),
        gases=_make(Gases, "gases"),
        technique=_make(Technique, "technique"),
        mechanical_testing=_make(MechanicalTesting, "mechanical_testing"),
        pqr_refs=list(data.get("pqr_refs") or []),
        status=data.get("status", "DRAFT"),
        signed_by=data.get("signed_by"),
        signed_at=data.get("signed_at"),
        signature_method=data.get("signature_method"),
        notes=data.get("notes"),
    )


def _pqr_from_dict(data: Mapping[str, Any]) -> PQR:
    mech_block = data.get("mechanical") or {}
    return PQR(
        pqr_id=data.get("pqr_id", "PQR-UNKNOWN"),
        process=data.get("process"),
        base_metal_p_number=data.get("base_metal_p_number"),
        base_metal_group=data.get("base_metal_group"),
        base_metal_thickness_mm=data.get("base_metal_thickness_mm"),
        filler_f_number=data.get("filler_f_number"),
        filler_a_number=data.get("filler_a_number"),
        position_tested=data.get("position_tested"),
        mechanical=MechanicalTesting(
            **{k: v for k, v in mech_block.items()
               if k in MechanicalTesting.__dataclass_fields__}
        ),
        date=data.get("date"),
        witnessed_by=data.get("witnessed_by"),
    )
