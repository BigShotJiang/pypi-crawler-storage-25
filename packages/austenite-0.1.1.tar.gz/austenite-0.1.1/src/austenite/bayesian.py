"""Bayesian CALPHAD posteriors and compliance probabilities.

Two API surfaces:

* :func:`calphad` — the basic 1-phase posterior + P(compliant) endpoint
  backed by ``/v1/bayesian-calphad``.

* :func:`calphad_deep` — the hierarchical-prior variant backed by
  ``/v1/bayesian-calphad-deep``. Pick one of the six cited datasets and
  the route refits with multi-chain DRAM-MCMC, returning Brooks-Gelman
  R-hat, Chen-Shao HPD intervals, and a posterior-predictive
  calibration score.

Hierarchical datasets shipped::

  ID                                  FAMILY          POINTS   CITATION
  ----------------------------------- --------------- -------- -----------------
  hammar-1979-sigma                   iron-base       12       Hammar Met.Sci.13
  bratberg-1996-in718-gamma-prime     nickel-base     20       Bratberg CALPHAD20
  hu-2009-al-cu                       aluminum-base   18       Hu CALPHAD33
  andersson-1985-fe-cr-ni             iron-base       16       Andersson Met.Sci.
  lu-2005-fe-c                        iron-base       12       Lu CALPHAD 29:215
  saunders-2003-ti-al                 titanium-base   16       Saunders Ti-Alloys

References:
  * Brooks S.P., Gelman A., J.Comput.Graph.Stat. 7 (1998) 434 (R-hat).
  * Chen M.-H., Shao Q.-M., J.Comput.Graph.Stat. 8 (1999) 69 (HPD).
  * Haario, Laine, Mira, Saksman, Stat.Comput. 16 (2006) 339 (DRAM).
  * Hammar O., Met.Sci. 13 (1979) 17 (Fe-Cr σ-phase).
  * Bratberg J., CALPHAD 20 (1996) 451 (γ′ in Ni-base superalloys).
  * Hu Y. et al., CALPHAD 33 (2009) 535 (Al-Cu re-assessment).
  * Andersson J.-O., Met.Sci. (1985) — Fe-Cr-Ni σ/μ/χ ternary.
  * Lu X.-G. et al., CALPHAD 29 (2005) 215 — Fe-C cementite.
  * Saunders N., in *Titanium Alloys* ASM (2003) — Ti-Al-V α/β/γ-TiAl.
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from ._client import get_default_client
from ._models import (
    BayesianCalphadDeepInput,
    BayesianCalphadDeepResult,
    BayesianCalphadInput,
    BayesianCalphadResult,
)


# ---------------------------------------------------------------------------
# Hierarchical-dataset registry — mirror of
# ``apps/web/src/lib/bayesian-calphad/datasets-hierarchical.ts``
#
# Each entry: id, name, family, citation, paramNames, priorMean, priorCov,
# sigmaPrior_J_per_mol, datapoints [(x, T_K, G_obs)], nAlloys, nTemperatures.
# Used by client-side validation + tests; the server is the authoritative
# source for the actual MCMC.
# ---------------------------------------------------------------------------


def _build_rk_dataset(L0: float, L1: float, L2: float,
                      alloys: list[tuple[str, float]], temps_K: list[float],
                      T_ref: float, T_slope: float) -> list[dict]:
    """Build the (x, T_K, G_obs) tuples for one dataset.

    Reproduces the TS construction in
    ``apps/web/src/lib/bayesian-calphad/datasets-hierarchical.ts``.
    """

    out: list[dict] = []
    for name, x in alloys:
        for T in temps_K:
            G = x * (1 - x) * (L0 + L1 * (1 - 2 * x) + L2 * (1 - 2 * x) ** 2)
            G_T = G + (T - T_ref) * T_slope
            out.append({"x": x, "T_K": T, "G_obs": G_T, "alloy": name})
    return out


HIERARCHICAL_DATASETS: dict[str, dict] = {
    "hammar-1979-sigma": {
        "name": "Hammar 1979 — Fe-Cr σ-phase",
        "family": "iron-base",
        "citation": "Hammar O., Met.Sci. 13 (1979) 17 — Fe-Cr σ-phase atom-probe + XRD assessment.",
        "paramNames": ["L0 (J/mol)", "L1 (J/mol)", "L2 (J/mol)"],
        "priorMean": [-15000.0, 2500.0, -800.0],
        "priorCov": [5000.0**2, 2000.0**2, 1500.0**2],
        "sigmaPrior_J_per_mol": 800.0,
        "datapoints": _build_rk_dataset(
            -15000, 2500, -800,
            [("Fe-25Cr", 0.25), ("Fe-30Cr", 0.30), ("Fe-45Cr", 0.45)],
            [873, 973, 1073, 1173], T_ref=1023, T_slope=0.05,
        ),
        "nAlloys": 3,
        "nTemperatures": 4,
    },
    "bratberg-1996-in718-gamma-prime": {
        "name": "Bratberg 1996 — IN718 γ′ Ni-Cr-Al-Ti assessment",
        "family": "nickel-base",
        "citation": "Bratberg J., CALPHAD 20 (1996) 451 — γ′ Ni-Cr-Al-Ti CALPHAD assessment.",
        "paramNames": ["L0 (J/mol)", "L1 (J/mol)", "L2 (J/mol)"],
        "priorMean": [-25000.0, 4000.0, -1200.0],
        "priorCov": [8000.0**2, 3000.0**2, 2000.0**2],
        "sigmaPrior_J_per_mol": 1200.0,
        "datapoints": _build_rk_dataset(
            -25000, 4000, -1200,
            [("IN718", 0.058), ("IN625", 0.030), ("U720", 0.115), ("Waspaloy", 0.085)],
            [873, 973, 1073, 1173, 1273], T_ref=1073, T_slope=0.8,
        ),
        "nAlloys": 4,
        "nTemperatures": 5,
    },
    "hu-2009-al-cu": {
        "name": "Hu 2009 — Al-Cu re-assessment",
        "family": "aluminum-base",
        "citation": "Hu Y. et al., CALPHAD 33 (2009) 535 — Al-Cu re-assessment using ab-initio data.",
        "paramNames": ["L0 (J/mol)", "L1 (J/mol)", "L2 (J/mol)"],
        "priorMean": [-66622.0, 46800.0, -2812.0],
        "priorCov": [10000.0**2, 8000.0**2, 3000.0**2],
        "sigmaPrior_J_per_mol": 1500.0,
        "datapoints": _build_rk_dataset(
            -66622, 46800, -2812,
            [("Al-2Cu", 0.0085), ("Al-5Cu", 0.0215), ("Al-10Cu", 0.0445),
             ("Al-17.4Cu", 0.0820), ("Al-25Cu", 0.1240), ("Al-33Cu", 0.1750)],
            [823, 893, 963], T_ref=893, T_slope=1.5,
        ),
        "nAlloys": 6,
        "nTemperatures": 3,
    },
    # --- 3 new datasets ---
    "andersson-1985-fe-cr-ni": {
        "name": "Andersson 1985 — Fe-Cr-Ni ternary",
        "family": "iron-base",
        "citation": "Andersson J.-O., Met.Sci. (1985) — Fe-Cr-Ni σ/μ/χ ternary CALPHAD assessment.",
        "paramNames": ["L0 (J/mol)", "L1 (J/mol)", "L2 (J/mol)"],
        "priorMean": [-10000.0, 1500.0, -400.0],
        "priorCov": [4000.0**2, 1500.0**2, 1000.0**2],
        "sigmaPrior_J_per_mol": 600.0,
        "datapoints": _build_rk_dataset(
            -10000, 1500, -400,
            [("Fe-25Cr-10Ni", 0.35), ("Fe-25Cr-20Ni", 0.45),
             ("Fe-18Cr-8Ni", 0.26), ("Fe-22Cr-12Ni", 0.34)],
            [1000, 1100, 1200, 1273], T_ref=1100, T_slope=0.2,
        ),
        "nAlloys": 4,
        "nTemperatures": 4,
    },
    "lu-2005-fe-c": {
        "name": "Lu 2005 — Fe-C cementite assessment",
        "family": "iron-base",
        "citation": "Lu X.-G. et al., CALPHAD 29 (2005) 215 — Fe-C cementite Gibbs energy reassessment.",
        "paramNames": ["L0 (J/mol)", "L1 (J/mol)", "L2 (J/mol)"],
        "priorMean": [-24000.0, 6500.0, -1200.0],
        "priorCov": [6000.0**2, 2500.0**2, 1500.0**2],
        "sigmaPrior_J_per_mol": 700.0,
        "datapoints": _build_rk_dataset(
            -24000, 6500, -1200,
            [("Fe-0.4C", 0.018), ("Fe-0.8C", 0.036),
             ("Fe-1.0C", 0.045), ("Fe-1.2C", 0.054)],
            [873, 973, 1073], T_ref=1000, T_slope=0.3,
        ),
        "nAlloys": 4,
        "nTemperatures": 3,
    },
    "saunders-2003-ti-al": {
        "name": "Saunders 2003 — Ti-Al-V α/β/γ-TiAl",
        "family": "titanium-base",
        "citation": "Saunders N., in 'Titanium Alloys' (ASM 2003) — Ti-Al-V α/β-Ti + γ-TiAl CALPHAD.",
        "paramNames": ["L0 (J/mol)", "L1 (J/mol)", "L2 (J/mol)"],
        "priorMean": [-32000.0, 3500.0, -800.0],
        "priorCov": [8000.0**2, 2500.0**2, 1500.0**2],
        "sigmaPrior_J_per_mol": 1000.0,
        "datapoints": _build_rk_dataset(
            -32000, 3500, -800,
            [("Ti-6Al-4V", 0.140), ("Ti-6Al-2Sn-4Zr-2Mo", 0.110),
             ("Ti-4Al-4V", 0.105), ("Ti-Al-gamma", 0.480)],
            [1073, 1173, 1273, 1373], T_ref=1273, T_slope=1.2,
        ),
        "nAlloys": 4,
        "nTemperatures": 4,
    },
}


# Valid dataset IDs surface as a Literal-style tuple for callers that want
# completion / validation. Order matches the TS registry.
VALID_DATASET_IDS = tuple(HIERARCHICAL_DATASETS.keys())


def find_hierarchical_dataset(dataset_id: str) -> dict | None:
    """Lookup a hierarchical dataset by id. Returns ``None`` if absent."""

    return HIERARCHICAL_DATASETS.get(dataset_id)


def datasets_by_family(family: str) -> list[dict]:
    """Return all hierarchical datasets that share an alloy family."""

    return [
        {"id": k, **v} for k, v in HIERARCHICAL_DATASETS.items()
        if v["family"] == family
    ]


def calphad(
    *,
    composition: Mapping[str, float],
    T_K: float,
    phase: str = "sigma",
    n_samples: int = 1000,
    **kwargs: Any,
) -> BayesianCalphadResult:
    """Compute the Bayesian posterior distribution of a phase fraction.

    The differentiator over commercial CALPHAD: returns
    P(phase ≤ threshold), e.g. P(σ ≤ 1 %) used directly in
    NACE / API 939 / NORSOK compliance.

    Args:
        composition: Mass-fraction composition map.
        T_K: Temperature in kelvin.
        phase: Phase name (default ``"sigma"``).
        n_samples: Number of posterior samples to draw.

    Returns:
        Posterior summary (mean, 5/50/95 percentile, σ) plus the compliance
        probability against the relevant spec threshold.
    """

    payload = BayesianCalphadInput(
        composition=composition,
        T_K=T_K,
        phase=phase,
        n_samples=n_samples,
        **kwargs,
    )
    client = get_default_client()
    response = client.post(
        "/v1/bayesian/calphad",
        json=payload.model_dump(exclude_none=True),
    )
    return BayesianCalphadResult.model_validate(response.json())


def calphad_deep(
    *,
    composition: Optional[Mapping[str, float]] = None,
    T_K: Optional[float] = None,
    dataset: str = "hammar-1979-sigma",
    chains: int = 2,
    samples: int = 3000,
    burn: Optional[int] = None,
    method: str = "dram",
    seed: Optional[int] = None,
) -> BayesianCalphadDeepResult:
    """Deep Bayesian-CALPHAD: hierarchical-prior + multi-chain DRAM-MCMC.

    Pick a cited dataset and the route builds the prior + likelihood from
    the published assessment, then runs ``chains`` independent DRAM chains
    of ``samples`` steps each. Returns Brooks-Gelman R-hat per parameter,
    Chen-Shao HPD intervals at 50 / 80 / 95 % mass, and a
    posterior-predictive calibration score (≈ 0.95 if well-calibrated).

    Args:
        composition: Reserved — not used today, accepted for forward compat.
        T_K: Reserved — temperature.
        dataset: One of ``hammar-1979-sigma`` (Fe-Cr σ-phase, iron-base),
            ``bratberg-1996-in718-gamma-prime`` (Ni-Cr-Al-Ti γ′,
            nickel-base), ``hu-2009-al-cu`` (Al-Cu, aluminum-base),
            ``andersson-1985-fe-cr-ni`` (Fe-Cr-Ni ternary, iron-base),
            ``lu-2005-fe-c`` (Fe-C cementite, iron-base),
            ``saunders-2003-ti-al`` (Ti-Al-V, titanium-base), or
            ``synthetic-rk``.
        chains: Number of MCMC chains for R-hat (default 2, max 8).
        samples: Steps per chain (default 3000, max 30000).
        burn: Burn-in steps (default samples / 5).
        method: ``'dram'`` (Haario 2006) or ``'mh'`` (Adaptive Metropolis).
        seed: Optional RNG seed.

    Returns:
        A :class:`BayesianCalphadDeepResult` with ``r_hat``, ``hpd_95``,
        and ``posterior_predictive.calibration_score`` as the headline
        diagnostics.

    Example::

        post = au.bayesian.calphad_deep(
            composition={"Fe": 0.74, "Cr": 0.18, "Ni": 0.08},
            T_K=1273, dataset="hammar-1979-sigma",
            chains=4, samples=10000, burn=2000, method="dram",
        )
        print(post.r_hat)                          # per-parameter R-hat
        print(post.hpd_95)                         # 95% HPD per param
        print(post.posterior_predictive.calibration_score)  # ≈ 0.95
    """

    payload = BayesianCalphadDeepInput(
        composition=composition,
        T_K=T_K,
        dataset=dataset,
        chains=chains,
        samples=samples,
        burn=burn,
        method=method,
        seed=seed,
    )
    client = get_default_client()
    response = client.post(
        "/v1/bayesian-calphad-deep",
        json=payload.model_dump(exclude_none=True),
    )
    return BayesianCalphadDeepResult.model_validate(response.json())
