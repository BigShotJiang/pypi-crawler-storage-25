"""Welding distortion predictor — inherent-strain method.

Predicts angular distortion, longitudinal shortening, and transverse
shrinkage from heat-input + plate geometry using the **inherent-strain
method** (Ueda-Kim-Yuan 1986) and **Okerblom 1958 closed-form** for
angular distortion of butt welds.

References:
    * Okerblom N.O., "The Calculations of Deformations of Welded Metal
      Structures" HMSO London (1958).
    * Ueda Y., Murakawa H., Math. Mech. Comp. Mod. 11 (1989) 305.
    * Deng D., Mater. Des. 30 (2009) 359 — review of inherent-strain.
    * Verhaeghe G., Welding J. 78 (1999) 17s — empirical correlations.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class WeldingDistortion:
    """Inherent-strain prediction of butt-weld distortion."""

    transverse_shrinkage_mm: float
    longitudinal_shortening_mm: float
    angular_distortion_deg: float
    inherent_strain_xx: float
    inherent_strain_yy: float
    notes: list


def transverse_shrinkage_okerblom(
    Q_J_mm: float, thickness_mm: float,
    *, alpha_um_m_K: float = 13, rho: float = 7850, Cp: float = 480,
) -> float:
    """Okerblom 1958 transverse shrinkage: ΔT_y = C·α·Q/(ρ·Cp·t) [mm].

    The inherent-strain coefficient C ≈ 2.9 is calibrated so a single-pass
    butt weld with Q≈1000 J/mm in 10 mm steel gives ≈1 mm transverse
    shrinkage, matching Masubuchi "Analysis of Welded Structures" (1980)
    and TWI measured values (typically 0.8–2 mm).

    Q = net arc heat input (J/mm), t = plate thickness (mm). Returns mm.
    """

    if thickness_mm <= 0:
        return 0.0
    alpha_K = alpha_um_m_K * 1e-6
    return 2.9 * alpha_K * Q_J_mm / (rho * 1e-9 * Cp * thickness_mm)


def longitudinal_shortening_okerblom(
    Q_J_mm: float, area_mm2: float,
    *, alpha_um_m_K: float = 13, rho: float = 7850, Cp: float = 480,
    L_mm: float = 1000,
) -> float:
    """Okerblom 1958: ΔL_x = 0.335·α·Q·L / (ρ·Cp·A_cross) [mm]."""

    if area_mm2 <= 0:
        return 0.0
    alpha_K = alpha_um_m_K * 1e-6
    return 0.335 * alpha_K * Q_J_mm * L_mm / (rho * 1e-9 * Cp * area_mm2)


def angular_distortion_satoh(
    Q_J_mm: float, thickness_mm: float,
    *, alpha_um_m_K: float = 13, E_GPa: float = 200, T_melt_K: float = 1800,
) -> float:
    """Satoh-Terai 1972 angular distortion of a butt weld.

    Angular distortion is driven by the through-thickness temperature gradient
    and is governed by the dimensionless heat-input group, NOT the elastic
    modulus (the previous form divided by E, suppressing the result by ~6
    orders of magnitude):

        β [rad] = C · α · Q / (ρ · Cp · t²)

    with C ≈ 1.5 calibrated so Q≈1000 J/mm in 10 mm steel gives ≈3°, in line
    with Satoh-Terai measurements (single-V butt welds distort 1–7°).

    Returns degrees.
    """

    if thickness_mm <= 0:
        return 0.0
    alpha_K = alpha_um_m_K * 1e-6
    rho = 7850.0
    Cp = 480.0
    # ρ in kg/mm³ via 1e-9; t in mm; Q in J/mm → β dimensionless (rad).
    beta_rad = 1.5 * alpha_K * Q_J_mm / (rho * 1e-9 * Cp * thickness_mm ** 2)
    return math.degrees(beta_rad)


def predict_distortion(
    Q_J_mm: float, thickness_mm: float,
    *, area_mm2: float = 200, length_mm: float = 1000,
    alpha_um_m_K: float = 13.0,
) -> WeldingDistortion:
    """Aggregate Okerblom + Satoh prediction.

    Args:
        Q_J_mm: net arc heat input in J/mm (= V·I·η / v).
        thickness_mm: plate thickness.
        area_mm2: cross-section in mm².
        length_mm: weld length.
        alpha_um_m_K: CTE in µm/m·K.

    Returns:
        WeldingDistortion bundle.
    """

    dy = transverse_shrinkage_okerblom(Q_J_mm, thickness_mm, alpha_um_m_K=alpha_um_m_K)
    dx = longitudinal_shortening_okerblom(Q_J_mm, area_mm2, alpha_um_m_K=alpha_um_m_K, L_mm=length_mm)
    ang = angular_distortion_satoh(Q_J_mm, thickness_mm, alpha_um_m_K=alpha_um_m_K)

    # Inherent strain magnitudes:  ε_inh ≈ α·(T_y − T_0)
    eps_xx = alpha_um_m_K * 1e-6 * 1500   # transverse — full plastic strain
    eps_yy = eps_xx * 0.4                 # longitudinal — reduced

    notes = []
    if ang > 5:
        notes.append(f"Angular distortion {ang:.1f}° > 5° — pre-set or restrain fixture")
    if dy > 3:
        notes.append(f"Transverse ΔT_y {dy:.1f} mm — leave allowance or apply back-step")
    if Q_J_mm > 2500:
        notes.append(f"Q={Q_J_mm:.0f} J/mm > 2500 — consider multi-pass with lower heat input")

    return WeldingDistortion(
        transverse_shrinkage_mm=dy, longitudinal_shortening_mm=dx,
        angular_distortion_deg=ang, inherent_strain_xx=eps_xx, inherent_strain_yy=eps_yy,
        notes=notes,
    )


__all__ = [
    "WeldingDistortion",
    "transverse_shrinkage_okerblom", "longitudinal_shortening_okerblom",
    "angular_distortion_satoh", "predict_distortion",
]
