"""Cradle-to-grave LCA — multi-indicator impact assessment.

ISO 14040/14044 + ILCD recommended indicators:

  * **GWP100** (CO₂-eq, IPCC AR6 100-yr) — kg CO₂-eq / kg
  * **Embodied energy** — primary MJ / kg
  * **Water consumption** (AWARE) — m³ water / kg
  * **Abiotic depletion potential** (ADP, kg Sb-eq) — for non-fossil resources
  * **EOL recycling credit** — system-expansion methodology, Ashby Table 22.2
  * **Critical-mineral supply risk** — JRC + USGS 2024

References:
    * Ashby M.F., "Materials and the Environment" 3rd Ed. (Butterworth 2021).
    * IPCC AR6 WG-I Ch.7 Table 7.SM.7 — 100-yr GWPs.
    * ILCD Handbook 2010 — Recommended LCIA Methods.
    * Hammond G., Jones C., ICE Database v3.0 (2019).
    * Boulay A.-M. et al., AWARE 100, Int. J. LCA 23 (2018) 368.
    * van Oers L., Guinée J.B., Resources 5 (2016) 16 — ADP.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class LCAResult:
    """ISO 14044-compatible LCA inventory with multi-indicator impacts."""

    alloy: str
    mass_kg: float
    # Per-kg impact factors
    gwp100_kg_CO2eq_per_kg: float
    embodied_energy_MJ_per_kg: float
    water_consumption_m3_per_kg: float
    adp_kg_Sbeq_per_kg: float
    # Totals (factor × mass)
    total_gwp_kg_CO2eq: float
    total_energy_MJ: float
    total_water_m3: float
    total_adp_kg_Sbeq: float
    # End-of-life
    recycle_fraction: float
    eol_credit_kg_CO2eq: float
    net_gwp_with_eol: float
    # Critical-mineral risk
    critical_minerals: list = field(default_factory=list)
    risk_score: float = 0.0
    citation: str = "Ashby 2021 + IPCC AR6 + USGS 2024"

    # Backward-compatibility aliases
    @property
    def embodied_CO2_kg_per_kg(self) -> float:
        return self.gwp100_kg_CO2eq_per_kg

    @property
    def total_CO2_kg(self) -> float:
        return self.total_gwp_kg_CO2eq


# IPCC AR6 GWP100 values for trace process-emissions (relative to CO₂=1)
GWP100_AR6: dict[str, float] = {
    "CO2": 1.0, "CH4_fossil": 29.8, "CH4_bio": 27.0,
    "N2O": 273.0, "SF6": 25200.0,
}


# Ashby 2021 + Hammond ICE 3.0 + Boulay AWARE 2018 cradle-to-gate
# Columns:
#   GWP100 (kg CO₂-eq/kg)
#   Energy (MJ/kg)
#   Water (m³/kg, AWARE-normalized)
#   ADP (kg Sb-eq/kg × 1e-6)
#   Recycle fraction (typical EOL)
#   Recycle credit (kg CO₂-eq/kg recycled, displaced primary)
_LCA_DB: dict[str, dict] = {
    "Carbon_Steel":      dict(gwp=1.9, energy=25, water=0.12, adp=2.5, rec=0.85, rec_credit=1.2, critical=[]),
    "Stainless_304":     dict(gwp=5.8, energy=76, water=0.78, adp=82, rec=0.92, rec_credit=4.5, critical=["Ni", "Cr"]),
    "Stainless_316L":    dict(gwp=6.2, energy=81, water=0.85, adp=105, rec=0.92, rec_credit=4.9, critical=["Ni", "Cr", "Mo"]),
    "Inconel_718":       dict(gwp=13.5, energy=220, water=2.1, adp=1850, rec=0.65, rec_credit=8.0, critical=["Ni", "Cr", "Nb", "Mo"]),
    "Inconel_625":       dict(gwp=14.0, energy=230, water=2.3, adp=2100, rec=0.65, rec_credit=8.4, critical=["Ni", "Cr", "Nb", "Mo"]),
    "Hastelloy_C276":    dict(gwp=18.0, energy=270, water=3.1, adp=4500, rec=0.50, rec_credit=8.8, critical=["Ni", "Mo", "W"]),
    "Ti_6Al_4V":         dict(gwp=28.0, energy=430, water=4.5, adp=210, rec=0.30, rec_credit=10.5, critical=["Ti", "V"]),
    "AA2024_T3":         dict(gwp=9.8, energy=155, water=0.95, adp=15, rec=0.96, rec_credit=8.5, critical=[]),
    "AA7075_T6":         dict(gwp=10.4, energy=162, water=1.0, adp=18, rec=0.96, rec_credit=9.0, critical=["Zn"]),
    "AlSi10Mg_AM":       dict(gwp=12.2, energy=180, water=1.1, adp=12, rec=0.90, rec_credit=8.8, critical=[]),
    "Cu_OFHC":           dict(gwp=3.5, energy=48, water=0.55, adp=1380, rec=0.50, rec_credit=2.7, critical=["Cu"]),
    "Brass":             dict(gwp=3.8, energy=52, water=0.60, adp=1450, rec=0.65, rec_credit=2.9, critical=["Cu", "Zn"]),
    "Mg_AZ91":           dict(gwp=28.0, energy=280, water=1.8, adp=200, rec=0.40, rec_credit=14.0, critical=["Mg"]),
    "NdFeB_magnet":      dict(gwp=75.0, energy=850, water=12, adp=15000, rec=0.10, rec_credit=15.0, critical=["Nd", "Dy", "Fe"]),
    "Co_Cr_Mo_implant":  dict(gwp=23.0, energy=350, water=4.5, adp=8800, rec=0.40, rec_credit=11.5, critical=["Co", "Cr", "Mo"]),
}


# JRC 2020 + USGS 2024 supply-risk scores (0-1, higher = more risk)
_CRITICAL_RISK: dict[str, float] = {
    "Ni": 0.55, "Cr": 0.50, "Mo": 0.65, "Nb": 0.75, "Ti": 0.45, "V": 0.60,
    "W": 0.70, "Zn": 0.40, "Cu": 0.45, "Co": 0.85, "Mg": 0.65, "Nd": 0.92,
    "Dy": 0.95, "Fe": 0.10,
}


def assess(alloy: str, mass_kg: float = 1.0,
           *, eol_recycle_fraction: float | None = None) -> LCAResult:
    """Run multi-indicator LCA with optional EOL credit.

    Args:
        alloy: alloy ID matching :data:`_LCA_DB`.
        mass_kg: mass in kg.
        eol_recycle_fraction: override typical recycle fraction.

    Returns:
        LCAResult with all 4 environmental indicators + EOL credit.
    """

    entry = _LCA_DB.get(alloy)
    if entry is None:
        return LCAResult(
            alloy=alloy, mass_kg=mass_kg,
            gwp100_kg_CO2eq_per_kg=float("nan"),
            embodied_energy_MJ_per_kg=float("nan"),
            water_consumption_m3_per_kg=float("nan"),
            adp_kg_Sbeq_per_kg=float("nan"),
            total_gwp_kg_CO2eq=float("nan"), total_energy_MJ=float("nan"),
            total_water_m3=float("nan"), total_adp_kg_Sbeq=float("nan"),
            recycle_fraction=0.0, eol_credit_kg_CO2eq=0.0,
            net_gwp_with_eol=float("nan"),
            critical_minerals=[], risk_score=float("nan"),
            citation="alloy not in LCA database",
        )

    rec_f = eol_recycle_fraction if eol_recycle_fraction is not None else entry["rec"]
    rec_f = max(0.0, min(1.0, rec_f))

    total_gwp = entry["gwp"] * mass_kg
    eol_credit = entry["rec_credit"] * mass_kg * rec_f
    net_gwp = total_gwp - eol_credit

    crit = entry["critical"]
    risk = max((_CRITICAL_RISK.get(e, 0.0) for e in crit), default=0.0)

    return LCAResult(
        alloy=alloy, mass_kg=mass_kg,
        gwp100_kg_CO2eq_per_kg=entry["gwp"],
        embodied_energy_MJ_per_kg=entry["energy"],
        water_consumption_m3_per_kg=entry["water"],
        adp_kg_Sbeq_per_kg=entry["adp"] * 1e-6,
        total_gwp_kg_CO2eq=total_gwp,
        total_energy_MJ=entry["energy"] * mass_kg,
        total_water_m3=entry["water"] * mass_kg,
        total_adp_kg_Sbeq=entry["adp"] * 1e-6 * mass_kg,
        recycle_fraction=rec_f,
        eol_credit_kg_CO2eq=eol_credit,
        net_gwp_with_eol=net_gwp,
        critical_minerals=crit, risk_score=risk,
    )


def compare(alloys: list[str], mass_kg: float = 1.0,
            *, sort_by: str = "total_gwp_kg_CO2eq") -> list[LCAResult]:
    """Compare alloys on equal mass basis. Sorted by chosen indicator."""

    results = [assess(a, mass_kg) for a in alloys]
    valid = [r for r in results if not (r.total_gwp_kg_CO2eq != r.total_gwp_kg_CO2eq)]
    return sorted(valid, key=lambda r: getattr(r, sort_by))


def process_emissions_CO2eq(
    flue_gases: dict[str, float],
) -> float:
    """Convert dict of {species: kg} to total CO₂-eq using IPCC AR6 GWP100.

    Example::

        process_emissions_CO2eq({"CH4_fossil": 0.001, "CO2": 1.85})
        # → 1.85 + 0.001 * 29.8 = 1.88 kg CO2-eq
    """

    total = 0.0
    for species, kg in flue_gases.items():
        gwp = GWP100_AR6.get(species, 0.0)
        total += float(kg) * gwp
    return total


__all__ = [
    "LCAResult", "GWP100_AR6",
    "assess", "compare", "process_emissions_CO2eq",
]
