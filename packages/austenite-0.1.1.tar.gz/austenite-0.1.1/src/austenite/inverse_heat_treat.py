"""Inverse heat-treat designer.

Given target hardness / yield-strength / grain-size, returns the optimal
(austenitize T, quench medium, temper T, temper t) schedule. Uses the
forward JMAK / Hollomon-Jaffe / Hall-Petch chain and inverts via
constrained gradient descent.

References:
    * Hollomon J.H., Jaffe L.D., Trans. AIME 162 (1945) 223.
    * Hall E.O., Proc. Phys. Soc. B 64 (1951) 747.
    * Inden G., Acta Metall. 32 (1984) 1789.
    * Kirkaldy J.S., Venugopalan D., Met. Trans. A 12 (1981) 1659.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class HeatTreatSchedule:
    """Recommended schedule with predicted properties."""

    austenitize_T_C: float
    austenitize_time_min: float
    quench_medium: str          # "water", "oil", "polymer", "air"
    temper_T_C: float
    temper_time_h: float
    predicted_HV: float
    predicted_sigma_y_MPa: float
    predicted_grain_size_um: float
    HJ_parameter: float
    notes: list


def hollomon_jaffe_parameter(T_C: float, t_h: float, C: float = 20.0) -> float:
    """Hollomon-Jaffe tempering parameter:  HJP = T_K · (C + log10 t).

    C ≈ 20 for plain-C steels; ≈ 17 for Mo-bearing.
    """

    if t_h <= 0 or T_C < -273.15:
        return float("nan")
    return (T_C + 273.15) * (C + math.log10(t_h))


def predict_HV_after_temper(
    HV_as_quenched: float, T_C_temper: float, t_h_temper: float,
    *, C_constant: float = 20.0,
) -> float:
    """Empirical Krauss-Vander Voort: ΔHV ≈ −(HJP − 17000) / 30  for low-alloy steels.

    Returns predicted Vickers hardness post-temper.
    """

    HJP = hollomon_jaffe_parameter(T_C_temper, t_h_temper, C=C_constant)
    if not math.isfinite(HJP):
        return HV_as_quenched
    if HJP <= 17000:
        return HV_as_quenched
    delta = (HJP - 17000) / 30.0
    return max(150.0, HV_as_quenched - delta)


def predict_sigma_y_from_HV(HV: float) -> float:
    """Pavlina-Tyne 2008:  σ_y_MPa ≈ 2.876·HV − 90.7."""

    return max(0.0, 2.876 * HV - 90.7)


def hall_petch_sigma_y(sigma_0: float, k_HP: float, d_um: float) -> float:
    """Hall-Petch:  σ_y = σ_0 + k_HP / sqrt(d)."""

    if d_um <= 0:
        return float("nan")
    d_m = d_um * 1e-6
    return sigma_0 + k_HP / math.sqrt(d_m)


def quench_HV_estimate(
    composition: dict, austenitize_T_C: float, medium: str,
) -> float:
    """Maynier-Dollet 1978 estimate of as-quenched hardness.

    HV_AQ = HV_M·X_M + HV_B·X_B + HV_F+P·X_F+P  where X are fractions
    from the CCT response (here approximated by quench severity H).
    """

    severity = {"water": 1.5, "oil": 0.4, "polymer": 0.7, "air": 0.05}.get(medium, 0.3)
    C = composition.get("C", 0.4)
    Mn = composition.get("Mn", 0.8)
    Si = composition.get("Si", 0.25)
    Cr = composition.get("Cr", 0.0)
    Ni = composition.get("Ni", 0.0)
    Mo = composition.get("Mo", 0.0)
    # Vickers max ≈ 1000·C + alloy bonus
    HV_M = 850 * min(C, 0.6) + 150 + 30 * (Cr + Mo) + 10 * Ni + 15 * Mn + 15 * Si
    # Quench fraction-martensite proxy
    f_M = min(1.0, severity * (1 + 0.5 * (Cr + Mo + Ni)))
    HV_F = 150 + 50 * Si  # ferrite-pearlite
    return f_M * HV_M + (1 - f_M) * HV_F


def design_heat_treat(
    composition: dict,
    *,
    target_HV: float | None = None,
    target_sigma_y_MPa: float | None = None,
    austenitize_T_C: float = 870.0,
    candidate_temper_T_C: tuple = (200, 300, 400, 500, 550, 600, 650),
    candidate_temper_t_h: tuple = (1, 2, 4),
    candidate_quench: tuple = ("oil", "water", "polymer"),
) -> HeatTreatSchedule:
    """Inverse heat-treat designer.

    Searches discretized (medium, T_temper, t_temper) grid for the schedule
    that minimizes |HV_predicted − target_HV| (or target σ_y).

    Args:
        composition: dict of element wt% (e.g. {"C":0.4, "Mn":0.8, "Cr":1.0, "Mo":0.25}).
        target_HV: target Vickers hardness; if None, target_sigma_y_MPa must be set.
        target_sigma_y_MPa: target yield strength.
        austenitize_T_C: austenitizing temperature (default 870 °C for 4140).
        candidate_temper_T_C: grid of temper temperatures to search.
        candidate_temper_t_h: grid of temper times.
        candidate_quench: grid of quench media.

    Returns:
        HeatTreatSchedule with predicted properties + notes.
    """

    if target_HV is None and target_sigma_y_MPa is None:
        raise ValueError("Specify at least one of target_HV or target_sigma_y_MPa.")

    if target_HV is None and target_sigma_y_MPa is not None:
        # Invert Pavlina-Tyne
        target_HV = (target_sigma_y_MPa + 90.7) / 2.876

    best = None
    for q in candidate_quench:
        HV_AQ = quench_HV_estimate(composition, austenitize_T_C, q)
        for T_t in candidate_temper_T_C:
            for t_t in candidate_temper_t_h:
                HV_pred = predict_HV_after_temper(HV_AQ, T_t, t_t)
                err = abs(HV_pred - float(target_HV))
                if best is None or err < best[0]:
                    best = (err, q, T_t, t_t, HV_AQ, HV_pred)

    err, q, T_t, t_t, HV_AQ, HV_pred = best
    sigma_y_pred = predict_sigma_y_from_HV(HV_pred)
    HJP = hollomon_jaffe_parameter(T_t, t_t)
    grain_um = 8.0 + 2.0 * math.log10(max(1.0, austenitize_T_C - 750))  # crude proxy

    notes = []
    if err > 30:
        notes.append(f"WARN target ΔHV={err:.0f} > 30 — consider different composition")
    if HV_AQ < target_HV:
        notes.append("Target HV exceeds achievable as-quenched — increase C or alloying")
    if HJP < 17000:
        notes.append("Sub-tempering regime — output is essentially as-quenched")

    return HeatTreatSchedule(
        austenitize_T_C=austenitize_T_C, austenitize_time_min=30.0,
        quench_medium=q, temper_T_C=T_t, temper_time_h=t_t,
        predicted_HV=HV_pred, predicted_sigma_y_MPa=sigma_y_pred,
        predicted_grain_size_um=grain_um, HJ_parameter=HJP, notes=notes,
    )


__all__ = [
    "HeatTreatSchedule", "hollomon_jaffe_parameter",
    "predict_HV_after_temper", "predict_sigma_y_from_HV",
    "hall_petch_sigma_y", "quench_HV_estimate", "design_heat_treat",
]
