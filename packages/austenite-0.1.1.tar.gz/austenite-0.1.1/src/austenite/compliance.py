"""Compliance — the differentiating wedge.

Operations:

* :func:`bayesian_p_pass` — given a posterior on σ_y and a spec, return
  the probability of compliance with stamp-able margin + verdict.

* :func:`check` — quick boolean compliance check; light wrapper around
  ``bayesian_p_pass`` that returns ``True`` iff ``p_pass >= 0.95``.

* :func:`diff_edition` — diff a spec between two editions, e.g.
  ``au.compliance.diff_edition("API 579-1", "2021-12", "2024-09")``.
  Returns a :class:`DiffReport` with every formula / parameter / method
  / scope / editorial change introduced between the two editions.

* :func:`recheck_edition` — re-run a batch of compliance records under a
  newer spec edition and report PASS / FAIL transitions.

* :func:`list_editions`, :func:`list_specs` — corpus introspection.

The :func:`bayesian_p_pass` route accepts either MCMC samples or a
Gaussian (mean, std) summary. With samples it computes P(PASS) by direct
Monte-Carlo over the posterior; with a summary it uses the FORM
(Hasofer-Lind) standard-normal tail integral.

The edition-diff corpus is bundled in ``austenite/_editions/*.json`` —
see that package's docstring for the schema. Adding a new spec only
requires dropping a new JSON file and registering its filename in
:mod:`austenite.compliance_editions`.

References:
  * ASME BPVC Section II Part D, 2021 Edition, Table 1A.
  * Der Kiureghian A., Engineering Design Reliability Handbook (CRC 2004) —
    P(PASS) integral / reliability index β.
"""

from __future__ import annotations

from typing import Any, Mapping, Optional, Union

from ._client import get_default_client
from ._models import (
    BayesianCalphadDeepResult,
    CalibrateResult,
    ComplianceBayesianPPassInput,
    ComplianceBayesianPPassResult,
    ComplianceBayesianPPassState,
)
from .compliance_editions import (
    DiffReport,
    EditionChange,
    RecheckDetail,
    RecheckReport,
    diff_edition as _diff_edition_impl,
    list_editions as _list_editions_impl,
    list_specs as _list_specs_impl,
    recheck_edition as _recheck_edition_impl,
)
from .compliance_standards import (
    StandardVerdict,
    check_standard as _check_standard_impl,
    list_standards as _list_standards_impl,
)


# ---------------------------------------------------------------------------
# State adapter
# ---------------------------------------------------------------------------


def _state_from_input(
    state: Union[
        ComplianceBayesianPPassState,
        BayesianCalphadDeepResult,
        CalibrateResult,
        Mapping[str, Any],
    ],
) -> ComplianceBayesianPPassState:
    """Coerce a variety of inputs into a ``ComplianceBayesianPPassState``.

    Accepts:
      * a raw :class:`ComplianceBayesianPPassState` (passthrough);
      * a :class:`BayesianCalphadDeepResult` — uses ``posteriorMean[0]`` and
        ``posteriorStd[0]`` (the first parameter) as the σ_y proxy;
      * a :class:`CalibrateResult` — uses ``posteriorMean_MPa`` and
        ``posteriorStd_MPa`` directly;
      * a plain dict — matches loose Python-style keys.
    """

    if isinstance(state, ComplianceBayesianPPassState):
        return state

    if isinstance(state, BayesianCalphadDeepResult):
        mean = state.posteriorMean[0] if state.posteriorMean else None
        std = state.posteriorStd[0] if state.posteriorStd else None
        return ComplianceBayesianPPassState(posteriorMean=mean, posteriorStd=std)

    if isinstance(state, CalibrateResult):
        return ComplianceBayesianPPassState(
            posteriorMean=state.posteriorMean_MPa,
            posteriorStd=state.posteriorStd_MPa,
        )

    if isinstance(state, Mapping):
        # Liberal dict-ingestion — try common spellings
        mean = (
            state.get("posteriorMean")
            or state.get("posterior_mean")
            or state.get("posteriorMean_MPa")
            or state.get("posterior_mean_MPa")
        )
        std = (
            state.get("posteriorStd")
            or state.get("posterior_std")
            or state.get("posteriorStd_MPa")
            or state.get("posterior_std_MPa")
        )
        samples = state.get("samples")
        return ComplianceBayesianPPassState(
            posteriorMean=float(mean) if mean is not None else None,
            posteriorStd=float(std) if std is not None else None,
            samples=list(samples) if samples is not None else None,
        )

    raise TypeError(
        f"Unsupported state type {type(state).__name__}; expected "
        "ComplianceBayesianPPassState, BayesianCalphadDeepResult, "
        "CalibrateResult, or a dict."
    )


# ---------------------------------------------------------------------------
# Operations
# ---------------------------------------------------------------------------


def bayesian_p_pass(
    *,
    state: Union[
        ComplianceBayesianPPassState,
        BayesianCalphadDeepResult,
        CalibrateResult,
        Mapping[str, Any],
    ],
    spec: str,
    T_C: float,
    target_sigma_y_MPa: float,
    safety_factor: float = 1.5,
) -> ComplianceBayesianPPassResult:
    """Return P(PASS) for a Bayesian posterior σ_y against a code allowable.

    Args:
        state: Posterior on σ_y as either:
            - a :class:`BayesianCalphadDeepResult` (first param treated as σ_y),
            - a :class:`CalibrateResult` (a shop-calibrated prior),
            - a raw dict with ``posteriorMean`` / ``posteriorStd`` (MPa) or
              a list ``samples`` of σ_y values.
        spec: Spec id, e.g. ``"ASME II-D SA-516-70"`` or just ``"SA-516-70"``.
        T_C: Design temperature, °C.
        target_sigma_y_MPa: The minimum σ_y the design requires the
            material to deliver — typically the spec yield × design factor.
        safety_factor: ASME yield safety factor (default 1.5).

    Returns:
        :class:`ComplianceBayesianPPassResult` with ``p_pass`` ∈ [0, 1],
        ``margin`` (z-score), ``verdict`` ∈ {PASS, FAIL, MARGINAL}, and
        a list of human-readable ``notes``.
    """

    coerced_state = _state_from_input(state)
    payload = ComplianceBayesianPPassInput(
        state=coerced_state,
        spec=spec,
        T_C=T_C,
        target_sigma_y_MPa=target_sigma_y_MPa,
        safety_factor=safety_factor,
    )
    client = get_default_client()
    response = client.post(
        "/v1/compliance-bayesian-p-pass",
        json=payload.model_dump(exclude_none=True),
    )
    return ComplianceBayesianPPassResult.model_validate(response.json())


def check(
    *,
    state: Union[
        ComplianceBayesianPPassState,
        BayesianCalphadDeepResult,
        CalibrateResult,
        Mapping[str, Any],
    ],
    spec: str,
    T_C: float,
    target_sigma_y_MPa: float,
    threshold: float = 0.95,
) -> bool:
    """Quick boolean compliance check.

    Returns ``True`` iff ``bayesian_p_pass(...).p_pass >= threshold``.
    """

    result = bayesian_p_pass(
        state=state, spec=spec, T_C=T_C, target_sigma_y_MPa=target_sigma_y_MPa,
    )
    return float(result.p_pass) >= float(threshold)


def diff_edition(
    spec: str,
    from_edition: Optional[str] = None,
    to_edition: Optional[str] = None,
    *,
    v1: Optional[str] = None,
    v2: Optional[str] = None,
    kinds: Optional[list[str]] = None,
) -> DiffReport:
    """Diff a spec between two editions.

    Returns a :class:`DiffReport` containing every change (formula,
    parameter, method, scope, editorial) introduced between
    ``from_edition`` (exclusive) and ``to_edition`` (inclusive).

    The corpus is hand-curated and shipped in
    ``austenite/_editions/*.json``. Five specs ship today:

      * ``"API 579-1"`` — 2021-12, 2022-06, 2024-09
      * ``"API 581"``   — 2008, 2016, 2020
      * ``"ASME II-D"`` — 2021, 2023, 2025
      * ``"NACE MR0175"`` — 2009, 2015, 2021, 2023
      * ``"ASTM A29"``  — 2020a, 2022, 2024

    Args:
        spec: Spec id (any reasonable alias works — ``"API 579"``,
            ``"asme-ii-d"``, ``"ISO 15156"``, etc.).
        from_edition: Earlier edition id (e.g. ``"2021-12"``).
        to_edition: Later edition id.
        v1: Alias for ``from_edition`` (legacy keyword).
        v2: Alias for ``to_edition`` (legacy keyword).
        kinds: Optional filter, e.g. ``["formula", "parameter"]``.

    Returns:
        :class:`DiffReport` with one :class:`EditionChange` per delta.

    Example:
        >>> import austenite as au
        >>> diff = au.compliance.diff_edition(
        ...     "API 579-1", "2021-12", "2024-09"
        ... )
        >>> len(diff)
        7
        >>> diff.changes[0].kind
        'formula'
    """

    from_ed = from_edition if from_edition is not None else v1
    to_ed = to_edition if to_edition is not None else v2
    if from_ed is None or to_ed is None:
        raise ValueError(
            "diff_edition requires both from_edition and to_edition "
            "(or v1/v2 as legacy aliases)"
        )
    return _diff_edition_impl(spec, from_ed, to_ed, kinds=kinds)


def recheck_edition(
    *,
    records: Any,
    edition: str,
    spec: Optional[str] = None,
    margin_change_threshold: float = 0.01,
) -> RecheckReport:
    """Re-run a batch of compliance records under a newer spec edition.

    See :func:`austenite.compliance_editions.recheck_edition` for the full
    contract. Quick summary::

        report = au.compliance.recheck_edition(
            records=Q4_records, edition="2024-09",
        )
        # RecheckReport(still_pass=41, now_fail=4, changed_margin=6, ...)

    Each record should be a mapping carrying a verdict (``verdict`` or
    nested ``compliance.verdict``) and ideally its original ``spec`` and
    ``edition`` ids.
    """

    return _recheck_edition_impl(
        records=records,
        edition=edition,
        spec=spec,
        margin_change_threshold=margin_change_threshold,
    )


def list_editions(spec: str) -> list[dict[str, Any]]:
    """Return all known editions of ``spec`` as ``{id, published, label}`` dicts."""

    return _list_editions_impl(spec)


def list_specs() -> list[str]:
    """Return all canonical spec ids known to the local edition corpus."""

    return _list_specs_impl()


def check_standard(
    spec_id: str,
    *,
    composition: Optional[Mapping[str, float]] = None,
    mechanical: Optional[Mapping[str, float]] = None,
    plugin: Optional[str] = None,
    **kwargs: Any,
) -> Any:
    """Dispatch a standard / spec compliance check.

    Resolution order:

      1. **Envelope checker** — if ``spec_id`` matches one of the 10
         per-standard checkers bundled in :mod:`austenite.compliance_standards`
         (DNV-OS-F101, IMO PSPC, JIS G3106, GB/T 711, KS B 0801,
         AMS 6517, AMS 6418, MIL-S-46100, ASTM A576, ASTM A574), run
         the envelope check against ``composition`` + ``mechanical`` and
         return a :class:`StandardVerdict`.
      2. **Edition corpus** — if ``spec_id`` is in the
         :func:`list_specs` corpus (API 579-1, API 581, ASME II-D,
         NACE MR0175, ASTM A29), return a stub
         ``{spec, editions, note}`` describing the editions. Callers
         should call :func:`bayesian_p_pass` for an actual P(PASS).
      3. **Plugin** — otherwise dispatch to plugins via the
         ``custom_compliance_check`` hook.

    Args:
        spec_id: Canonical spec id (any reasonable alias works).
        composition: wt% per element. Forwarded to the envelope checker.
        mechanical: property → value. Forwarded to the envelope checker.
        plugin: Optional named plugin to dispatch to (when falling back
            to the plugin layer).
        **kwargs: Standard-specific extras (``grade=``, ``ballistic=``,
            ``size_class=``, …) forwarded to the per-standard checker
            or plugin hook.

    Example::

        # envelope checker
        v = au.compliance.check_standard(
            "DNV-OS-F101",
            composition={"C": 0.14, "Mn": 1.20, "P": 0.012, "S": 0.005},
            mechanical={"sigma_y_MPa": 450, "sigma_uts_MPa": 540,
                        "elongation_pct": 24, "CVN_J_at_-30C": 50},
        )

        # plugin fallback
        v = au.compliance.check_standard(
            "de-waard-1995-CO2",
            plugin="corro-rates",
            T_C=80, p_CO2_bar=2.0, pH=4.5,
        )
    """

    return _check_standard_impl(
        spec_id,
        composition=composition,
        mechanical=mechanical,
        plugin=plugin,
        **kwargs,
    )


def list_standards() -> list[str]:
    """Return every spec id supported by :func:`check_standard`.

    Union of:
      * the 10 envelope-checker ids bundled in
        :mod:`austenite.compliance_standards`,
      * the 5 edition-tracked ids from
        :mod:`austenite.compliance_editions`,
      * and any plugin-advertised ids.
    """

    return _list_standards_impl()


# Re-export dataclasses so callers can isinstance-check.
__all__ = [
    "bayesian_p_pass",
    "check",
    "check_standard",
    "diff_edition",
    "recheck_edition",
    "list_editions",
    "list_specs",
    "list_standards",
    "DiffReport",
    "EditionChange",
    "RecheckDetail",
    "RecheckReport",
    "StandardVerdict",
]
