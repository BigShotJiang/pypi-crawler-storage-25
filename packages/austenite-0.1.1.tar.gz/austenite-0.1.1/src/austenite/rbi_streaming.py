"""Streaming Bayesian RBI — online posterior update from historian/UT measurements.

Coordinated with the batch API-581 calculator that lives in ``au.rbi`` (single-shot
fleet screens, POF/COF matrix, mechanism table). This module owns the *streaming*
surface used to fuse a calendar of historian / NDE inspections into a continuously
updated probabilistic remaining-life estimate per asset.

The posterior on the wall-loss rate is modelled as a lognormal distribution; each
new ultrasonic thickness reading is folded into the posterior via a conjugate
Normal-on-log-rate (Laplace approximation) update. The lognormal choice for
corrosion rates is justified by long-term metal-loss surveys (API RP 581 Part 2
Annex 2.A; Kiefner & Kolovich 2007). The Laplace conjugate scheme for hydrogen-
charging variants follows the diffusion-trap model of McNabb & Foster (1963) and
Oriani (1970) — both are reduced here to their first-moment Gaussian envelope so
the update remains a closed-form Bayesian step (no MCMC required for streaming).

References:
  * McNabb, A. & Foster, P. K. (1963) "A new analysis of the diffusion of
    hydrogen in iron and ferritic steels", Trans. Metall. Soc. AIME 227, 618.
  * Oriani, R. A. (1970) "The diffusion and trapping of hydrogen in steel",
    Acta Metall. 18 (1), 147-157.
  * API RP 581 3rd ed. (2016) Risk-Based Inspection Methodology — Part 2
    (corrosion-rate posterior priors).
  * Kiefner, J. & Kolovich, C. (2007) "Calculation of a corrosion rate using
    Monte Carlo simulation", NACE Corrosion 2007 paper 07153.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Optional


# Current calendar year — exposed as a module attribute so tests / callers can
# monkey-patch it for reproducible time-travel runs (matching the audit-replay
# convention used elsewhere in the package).
_CURRENT_YEAR: int = 2026


@dataclass
class AssetState:
    """Streaming-Bayesian state for a single inspected asset.

    The posterior on the corrosion / wall-loss rate is kept as a lognormal
    distribution parameterised by ``(log_mu, log_sigma)`` in log-space::

        rate ~ Lognormal(log_mu, log_sigma)   # mm/yr

    ``measurements`` is the list of historian / NDE readings that have been
    folded into the posterior so far (see :func:`online_bayes_update`).
    """

    asset_id: str
    geometry: dict
    material: str
    t_min_mm: float
    next_inspection_year: int
    log_mu: float
    log_sigma: float
    measurements: list = field(default_factory=list)

    # ------------------------------------------------------------------
    # Derived posterior summaries
    # ------------------------------------------------------------------
    def posterior_p_failure_by(self, year: int) -> float:
        """Probability the remaining wall drops below ``t_min`` by ``year``.

        Closed-form survival on the lognormal rate:

            P(wall_0 - rate * dt < t_min)
              = P(rate > (wall_0 - t_min) / dt)
              = 0.5 * erfc((log(crit) - log_mu) / (sqrt(2) * log_sigma))
        """

        dt = year - _CURRENT_YEAR
        if dt <= 0:
            return 0.0
        critical_rate = (self.geometry["wall_mm"] - self.t_min_mm) / dt
        if critical_rate <= 0:
            return 1.0
        z = (math.log(critical_rate) - self.log_mu) / self.log_sigma
        return 0.5 * math.erfc(z / math.sqrt(2))

    @property
    def expected_remaining_life_years(self) -> float:
        """Expected years until ``wall == t_min`` under the current posterior.

        Uses the posterior mean of the lognormal corrosion-rate distribution.
        Capped at 100 years for pathological / near-zero priors.
        """

        rate_mean = math.exp(self.log_mu + 0.5 * self.log_sigma ** 2)
        if rate_mean <= 0:
            return 100.0
        life = (self.geometry["wall_mm"] - self.t_min_mm) / rate_mean
        if not math.isfinite(life) or life > 100.0:
            return 100.0
        return life


# ---------------------------------------------------------------------------
# Constructors / updates
# ---------------------------------------------------------------------------


def create_asset(
    *,
    asset_id: str,
    geometry: dict,
    material: str,
    service: Any = None,
    initial_prior: dict,
    t_min_mm: float,
    next_inspection_year: int,
) -> AssetState:
    """Initialise a streaming-RBI ``AssetState`` from an engineering prior.

    ``initial_prior['corrosion_rate_mm_yr']`` is a ``(family, mean, CoV)``
    triple — currently only the ``"lognormal"`` family is supported. The
    ``(mean, CoV)`` of the underlying rate is converted to log-space
    parameters via the standard moment-matching identity::

        log_sigma^2 = log(1 + CoV^2)
        log_mu      = log(mean) - 0.5 * log_sigma^2

    The ``service`` argument is accepted for forward-compatibility with the
    batch API-581 dispatcher but is not yet used by the streaming update.
    """

    family, mean, cov = initial_prior["corrosion_rate_mm_yr"]
    if family != "lognormal":
        raise ValueError(
            f"streaming-RBI prior currently supports 'lognormal' only, got {family!r}"
        )
    if mean <= 0 or cov <= 0:
        raise ValueError("prior mean and CoV must both be positive")
    log_sigma_sq = math.log(1.0 + cov ** 2)
    log_mu = math.log(mean) - 0.5 * log_sigma_sq
    log_sigma = math.sqrt(log_sigma_sq)
    return AssetState(
        asset_id=asset_id,
        geometry=dict(geometry),
        material=material,
        t_min_mm=float(t_min_mm),
        next_inspection_year=int(next_inspection_year),
        log_mu=log_mu,
        log_sigma=log_sigma,
        measurements=[],
    )


def online_bayes_update(state: AssetState, measurement: dict) -> AssetState:
    """Fold a single thickness measurement into the posterior on the rate.

    The likelihood for the inferred rate is treated as Normal on log-rate
    (Laplace approximation around the MAP). The conjugate update is the
    standard precision-weighted mean::

        log_mu_new = (prec_prior * log_mu + prec_obs * log(inferred_rate))
                     / (prec_prior + prec_obs)
        log_sigma_new = sqrt(1 / (prec_prior + prec_obs))

    This is the same algebraic skeleton McNabb-Foster (1963) used for the
    Gaussian-trap representation of hydrogen ingress — see the module
    docstring for the full citation chain.

    ``measurement`` schema::

        {
            "timestamp": "2025-06-01T00:00:00Z",
            "value_mm":  12.4,
            "uncertainty_mm": 0.1,   # optional, defaults to 0.1
        }
    """

    state.measurements.append(measurement)
    ts = measurement["timestamp"]
    # Tolerate both 'Z' and '+00:00' UTC suffixes.
    meas_year = datetime.fromisoformat(ts.replace("Z", "+00:00")).year
    dt = meas_year - 2024  # reference year for as-installed wall
    if dt <= 0:
        return state
    observed_loss = state.geometry["wall_mm"] - measurement["value_mm"]
    if observed_loss <= 0:
        return state
    inferred_rate = observed_loss / dt
    if inferred_rate <= 0:
        return state

    obs_unc = measurement.get("uncertainty_mm", 0.1)
    obs_log_sigma = max(obs_unc / max(measurement["value_mm"], 1e-9), 1e-6)

    prec_prior = 1.0 / state.log_sigma ** 2
    prec_obs = 1.0 / obs_log_sigma ** 2
    log_mu_new = (
        prec_prior * state.log_mu + prec_obs * math.log(inferred_rate)
    ) / (prec_prior + prec_obs)
    log_sigma_new = math.sqrt(1.0 / (prec_prior + prec_obs))

    state.log_mu = log_mu_new
    state.log_sigma = log_sigma_new
    return state


# ---------------------------------------------------------------------------
# Alert registry — callers wire side effects (email, ticket, dashboard).
# ---------------------------------------------------------------------------

_alert_handlers: list[tuple[float, Callable[..., Any]]] = []


def on_alert(*, threshold_p_failure: float) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """Register a handler that fires when ``P(failure) >= threshold``.

    Example::

        @au.rbi_streaming.on_alert(threshold_p_failure=0.05)
        def email_inspection_team(state):
            send_email(...)

    Handlers are kept in a process-local list and can be inspected /
    cleared by tests via :func:`_clear_alert_handlers`.
    """

    if not 0.0 <= threshold_p_failure <= 1.0:
        raise ValueError("threshold_p_failure must be in [0, 1]")

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        _alert_handlers.append((threshold_p_failure, fn))
        return fn

    return decorator


def _clear_alert_handlers() -> None:
    """Reset the alert-handler registry. Intended for tests only."""

    _alert_handlers.clear()


def _registered_alert_handlers() -> list[tuple[float, Callable[..., Any]]]:
    """Return a snapshot of registered handlers (read-only view for tests)."""

    return list(_alert_handlers)


__all__ = [
    "AssetState",
    "create_asset",
    "online_bayes_update",
    "on_alert",
]
