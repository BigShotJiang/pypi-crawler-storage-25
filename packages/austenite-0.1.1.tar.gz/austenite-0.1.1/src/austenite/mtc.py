"""Material Test Certificate (MTC) parsing, grade detection, batch
ingestion, and lot audit.

Engineers at a steel mill QC desk drown in PDF certs in 7 languages.
This module replaces 2-4 of those FTEs with a single ``au.mtc.batch_parse``
call that fans 1000 PDFs out across 20 worker threads and returns a
pandas DataFrame ready for spec audit.

Public API::

    au.mtc.parse(file_or_text)              # one cert
    au.mtc.batch_parse("incoming/", workers=20)  # folder → DataFrame
    au.mtc.audit_lot(df, spec="ASTM A29")        # → AuditReport
    au.mtc.compare(a, b)                         # element-by-element diff
"""

from __future__ import annotations

import asyncio
import base64
import io
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Mapping, Optional, Sequence, Union

from ._client import AsyncClient, get_default_client
from ._exceptions import AusteniteError, ValidationError
from ._languages import (
    ELEMENT_ALIASES,
    LANG_TO_TESSERACT,
    detect_language,
    translate_element_tokens,
)
from ._models import (
    MtcDetectGradeInput,
    MtcDetectGradeResult,
    MtcParseInput,
    MtcParseResult,
)


# ---------------------------------------------------------------------------
# Single-cert parse / detect — the original endpoints
# ---------------------------------------------------------------------------


def parse(
    source: Union[str, Path, bytes, None] = None,
    *,
    pdf_url: Optional[str] = None,
    text: Optional[str] = None,
    language: str = "auto",
    ocr: bool = True,
    **kwargs: Any,
) -> MtcParseResult:
    """Parse a Material Test Certificate.

    Exactly one of ``source``, ``pdf_url``, or ``text`` must be supplied.

    Args:
        source: A ``str``/``Path`` to a local PDF (or any other file), or
            raw ``bytes``. PDFs are extracted locally first; if extraction
            yields <50 chars and ``ocr=True``, the OCR chain runs.
        pdf_url: A URL the server can fetch.
        text: Already-extracted text content.
        language: ISO 639-1 code (``"en"``, ``"de"``, ``"ja"``, ...) or
            ``"auto"`` to detect from header tokens. Used both to pick
            the tesseract pack and to map element aliases.
        ocr: When ``True`` (default) and a PDF yields <50 chars of text,
            falls back to pytesseract if available. Install with
            ``pip install austenite[ocr]``.

    Returns:
        Heat number, detected grade, composition map, mechanical
        properties, and a confidence score.
    """
    # Decide how to send the cert:
    #   - explicit text=...           → POST {text}, with multi-language translation
    #   - source= path/bytes          → try local extract; if usable, POST text;
    #                                    otherwise fall back to base64 upload so
    #                                    the legacy server-side parser sees raw bytes
    #   - pdf_url=...                 → POST {pdf_url}
    if text is not None:
        lang = language
        if lang == "auto":
            lang = detect_language(text)
        normalised = translate_element_tokens(text) if lang != "en" else text
        payload = MtcParseInput(text=normalised, **kwargs)
    elif source is not None:
        extracted = _extract_text_from_source(source, ocr=ocr, language=language)
        if extracted and len(extracted.strip()) >= 50:
            lang = language
            if lang == "auto":
                lang = detect_language(extracted)
            normalised = translate_element_tokens(extracted) if lang != "en" else extracted
            payload = MtcParseInput(text=normalised, **kwargs)
        else:
            # Could not extract usable text locally; ship raw bytes for the
            # server to handle (preserves the existing-client contract).
            if isinstance(source, (str, Path)):
                raw = Path(source).read_bytes()
            elif isinstance(source, (bytes, bytearray)):
                raw = bytes(source)
            else:  # pragma: no cover - defensive
                raise TypeError(
                    "`source` must be a path, Path, or bytes; got "
                    f"{type(source).__name__}"
                )
            pdf_b64 = base64.b64encode(raw).decode("ascii")
            payload = MtcParseInput(pdf_b64=pdf_b64, **kwargs)
    elif pdf_url is not None:
        payload = MtcParseInput(pdf_url=pdf_url, **kwargs)
    else:
        raise TypeError("Provide one of source, pdf_url, or text.")

    client = get_default_client()
    response = client.post(
        "/v1/mtc/parse",
        json=payload.model_dump(exclude_none=True),
    )
    return MtcParseResult.model_validate(response.json())


def detect_grade(
    composition: Mapping[str, float],
    **kwargs: Any,
) -> MtcDetectGradeResult:
    """Identify the most likely grade for a composition map."""
    payload = MtcDetectGradeInput(composition=composition, **kwargs)
    client = get_default_client()
    response = client.post(
        "/v1/mtc/detect-grade",
        json=payload.model_dump(exclude_none=True),
    )
    return MtcDetectGradeResult.model_validate(response.json())


# ---------------------------------------------------------------------------
# Local PDF text extraction + OCR fallback chain
# ---------------------------------------------------------------------------


def _extract_text_from_source(
    source: Union[str, Path, bytes],
    *,
    ocr: bool = True,
    language: str = "auto",
) -> str:
    """Pull text out of a local source.

    Chain:
        1. If ``source`` is already a text string with no PDF magic bytes,
           treat it as raw text.
        2. Try ``pypdf`` / ``pdfplumber`` for embedded text.
        3. If <50 chars and ``ocr=True``, run pytesseract via PIL.

    Always returns a string (possibly empty) — never raises on missing
    optional deps; just falls through.
    """
    # ── coerce to bytes ──
    if isinstance(source, (bytes, bytearray)):
        raw = bytes(source)
    elif isinstance(source, (str, Path)):
        p = Path(source)
        if p.exists():
            raw = p.read_bytes()
        else:
            # caller passed a string of text, not a path
            return str(source)
    else:
        raise TypeError(f"Unsupported source type: {type(source).__name__}")

    # ── if it's not a PDF, decode as text ──
    is_pdf = raw[:4] == b"%PDF"
    if not is_pdf:
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            try:
                return raw.decode("latin-1")
            except Exception:
                return ""

    # ── PDF text extraction (pypdf / pdfplumber) ──
    text = _try_pdf_text_extract(raw)

    # ── OCR fallback ──
    if ocr and len(text.strip()) < 50:
        ocr_text = _try_ocr(raw, language=language)
        if len(ocr_text.strip()) > len(text.strip()):
            text = ocr_text

    return text


def _try_pdf_text_extract(raw: bytes) -> str:
    """Try pypdf first (fast), then pdfplumber (more robust on tables)."""
    # pypdf
    try:
        from pypdf import PdfReader  # type: ignore

        reader = PdfReader(io.BytesIO(raw))
        parts: list[str] = []
        for page in reader.pages:
            try:
                parts.append(page.extract_text() or "")
            except Exception:
                pass
        joined = "\n".join(parts).strip()
        if len(joined) >= 50:
            return joined
    except ImportError:
        pass
    except Exception:
        pass

    # pdfplumber
    try:
        import pdfplumber  # type: ignore

        parts = []
        with pdfplumber.open(io.BytesIO(raw)) as pdf:
            for page in pdf.pages:
                try:
                    parts.append(page.extract_text() or "")
                except Exception:
                    pass
        return "\n".join(parts).strip()
    except ImportError:
        return ""
    except Exception:
        return ""


def _try_ocr(raw: bytes, *, language: str = "auto") -> str:
    """Last-resort OCR via pytesseract. Returns "" if pytesseract or its
    binary aren't installed."""
    try:
        import pytesseract  # type: ignore
        from pdf2image import convert_from_bytes  # type: ignore
    except ImportError:
        return ""
    try:
        images = convert_from_bytes(raw, dpi=200)
    except Exception:
        return ""

    if language == "auto":
        # Use English for first page, detect from result, then re-OCR if needed.
        try:
            first_pass = pytesseract.image_to_string(images[0], lang="eng")
            lang_code = detect_language(first_pass)
        except Exception:
            lang_code = "en"
    else:
        lang_code = language

    tess_lang = LANG_TO_TESSERACT.get(lang_code, "eng")
    parts: list[str] = []
    for img in images:
        try:
            parts.append(pytesseract.image_to_string(img, lang=tess_lang))
        except Exception:
            try:
                parts.append(pytesseract.image_to_string(img, lang="eng"))
            except Exception:
                pass
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Batch parse — folder of N PDFs → pandas DataFrame
# ---------------------------------------------------------------------------


def batch_parse(
    folder: Union[str, Path, None] = None,
    *,
    files: Optional[Sequence[Union[str, Path]]] = None,
    workers: int = 20,
    languages: Optional[Sequence[str]] = None,
    show_progress: bool = False,
    batch_size: int = 50,
    ocr: bool = True,
    glob: str = "*.pdf",
) -> "Any":
    """Parse every PDF in a folder (or every file in ``files``) in parallel.

    Each PDF is text-extracted locally (with OCR fallback), then sent in
    batches of ``batch_size`` to the API. The API runs the parser per cert
    and returns parsed structures, which we assemble into one pandas
    DataFrame.

    Args:
        folder: Directory to scan with ``glob``.
        files: Explicit list of files (overrides ``folder``).
        workers: Concurrent HTTP requests (asyncio gather semaphore).
        languages: Whitelist of language codes the QC team accepts.
            Used for language detection.
        show_progress: If ``True`` and tqdm is installed, show a bar.
        batch_size: PDFs per /v1/mtc-batch-parse call (max 100).
        ocr: Pass through to :func:`parse` for OCR fallback.
        glob: File pattern (default ``"*.pdf"``).

    Returns:
        ``pandas.DataFrame`` with one row per cert. Columns:
        ``file, heat, grade, spec, language, confidence,
        C, Mn, Cr, Ni, ...`` (every element seen across all certs).
    """
    try:
        import pandas as pd  # type: ignore
    except ImportError as e:  # pragma: no cover
        raise AusteniteError(
            "pandas is required for batch_parse — install with "
            "`pip install austenite[xlsx]` or `pip install pandas`."
        ) from e

    # Collect file list
    paths: list[Path]
    if files is not None:
        paths = [Path(p) for p in files]
    elif folder is not None:
        folder_p = Path(folder)
        if not folder_p.exists():
            raise AusteniteError(f"Folder does not exist: {folder}")
        paths = sorted(folder_p.glob(glob))
    else:
        raise AusteniteError("Provide either `folder` or `files`.")

    if not paths:
        return pd.DataFrame(columns=["file", "heat", "grade"])

    # 1) extract text locally (in-process — pypdf is C-bound, fast)
    extracted: list[tuple[Path, str, str]] = []
    iterator: Iterable[Path] = paths
    if show_progress:
        try:
            from tqdm import tqdm  # type: ignore

            iterator = tqdm(paths, desc="extract", unit="cert")
        except ImportError:
            iterator = paths

    for p in iterator:
        try:
            txt = _extract_text_from_source(p, ocr=ocr)
        except Exception as exc:
            extracted.append((p, "", f"__extraction_error__:{exc}"))
            continue
        lang = detect_language(txt, allowed=list(languages) if languages else None)
        normalised = translate_element_tokens(txt) if lang != "en" else txt
        extracted.append((p, normalised, lang))

    # 2) batch-POST to the worker
    results = asyncio.run(
        _async_batch_post(
            extracted, workers=workers, batch_size=batch_size, show_progress=show_progress
        )
    )

    # 3) flatten to DataFrame rows
    rows: list[dict[str, Any]] = []
    all_elements: set[str] = set()
    for (path, _txt, lang), result in zip(extracted, results):
        row: dict[str, Any] = {
            "file": path.name,
            "language": lang,
        }
        if isinstance(result, dict) and "error" in result:
            row["error"] = result["error"]
            rows.append(row)
            continue
        parsed = (result or {}).get("parsed", {}) or {}
        chem = parsed.get("chemistry", {}) or {}
        meta = parsed.get("metadata", {}) or {}
        row["heat"] = meta.get("heat")
        row["lot"] = meta.get("lot")
        row["grade"] = result.get("detected_grade") or meta.get("grade")
        row["spec"] = meta.get("spec")
        row["confidence"] = result.get("confidence")
        for sym, val in chem.items():
            row[sym] = val
            all_elements.add(sym)
        rows.append(row)

    # Order columns: file / metadata first, then elements alphabetised.
    base_cols = ["file", "heat", "lot", "grade", "spec", "language", "confidence"]
    elem_cols = sorted(all_elements)
    other_cols = [c for c in {k for r in rows for k in r} if c not in base_cols + elem_cols]
    cols = base_cols + elem_cols + other_cols
    df = pd.DataFrame(rows)
    # Re-index columns, filling missing with NaN
    for c in cols:
        if c not in df.columns:
            df[c] = None
    return df[cols]


async def _async_batch_post(
    extracted: Sequence[tuple[Path, str, str]],
    *,
    workers: int,
    batch_size: int,
    show_progress: bool,
) -> list[dict[str, Any]]:
    """Fan extracted text out to /v1/mtc-batch-parse in chunks."""
    # Chunk into batches
    items = [
        {"filename": p.name, "text": txt or "(empty)"} for (p, txt, _lang) in extracted
    ]
    batches: list[list[dict[str, Any]]] = [
        items[i : i + batch_size] for i in range(0, len(items), batch_size)
    ]

    sem = asyncio.Semaphore(max(1, workers))
    all_results: list[Any] = [None] * len(items)

    async with AsyncClient() as client:

        async def run_batch(start: int, chunk: list[dict[str, Any]]) -> None:
            async with sem:
                try:
                    resp = await client.post(
                        "/v1/mtc-batch-parse",
                        json={"items": chunk, "detect_grade": True},
                    )
                    payload = resp.json()
                    for i, item_result in enumerate(payload.get("results", [])):
                        all_results[start + i] = item_result
                except Exception as exc:
                    for i in range(len(chunk)):
                        all_results[start + i] = {"error": str(exc)}

        tasks = []
        offset = 0
        for chunk in batches:
            tasks.append(asyncio.create_task(run_batch(offset, chunk)))
            offset += len(chunk)

        if show_progress:
            try:
                from tqdm.asyncio import tqdm  # type: ignore

                await tqdm.gather(*tasks, desc="parse", unit="batch")
            except ImportError:
                await asyncio.gather(*tasks)
        else:
            await asyncio.gather(*tasks)

    # Replace any leftover None (shouldn't happen, but be defensive)
    return [r if r is not None else {"error": "no_response"} for r in all_results]


# ---------------------------------------------------------------------------
# Audit lot — DataFrame → AuditReport
# ---------------------------------------------------------------------------


@dataclass
class AuditReport:
    """Result of :func:`audit_lot` — counts, flagged heats, Excel export."""

    spec: str
    period: Optional[str]
    summary: dict[str, Any]
    per_heat: list[dict[str, Any]]
    flagged: list[dict[str, Any]] = field(default_factory=list)
    raw_df: Optional[Any] = None  # pandas DataFrame, kept for export

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        s = self.summary
        return (
            f"<AuditReport spec={self.spec!r} period={self.period!r} "
            f"total={s.get('total')} pass={s.get('pass')} "
            f"near_boundary={s.get('near_boundary')} fail={s.get('fail')}>"
        )

    # ─── exporters ───
    def export_xlsx(self, path: Union[str, Path]) -> Path:
        """Write a 3-sheet xlsx (Summary / Compliance / Flagged)."""
        try:
            from openpyxl import Workbook  # type: ignore
            from openpyxl.styles import Alignment, Font, PatternFill  # type: ignore
        except ImportError as e:  # pragma: no cover
            raise AusteniteError(
                "openpyxl is required for export_xlsx — install with "
                "`pip install austenite[xlsx]`."
            ) from e

        path = Path(path)
        wb = Workbook()

        # ── Sheet 1: Summary ──
        ws = wb.active
        ws.title = "Summary"
        header_font = Font(bold=True, size=12)
        title_font = Font(bold=True, size=14)
        fill_pass = PatternFill("solid", fgColor="C6EFCE")
        fill_warn = PatternFill("solid", fgColor="FFEB9C")
        fill_fail = PatternFill("solid", fgColor="FFC7CE")

        ws["A1"] = "MTC Lot Audit Report"
        ws["A1"].font = title_font
        ws.merge_cells("A1:D1")

        from datetime import datetime, timezone

        rows = [
            ("Spec", self.spec),
            ("Period", self.period or "—"),
            ("Generated", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")),
            ("", ""),
            ("Total heats", self.summary.get("total", 0)),
            ("Pass", self.summary.get("pass", 0)),
            ("Near boundary", self.summary.get("near_boundary", 0)),
            ("Fail", self.summary.get("fail", 0)),
        ]
        for i, (k, v) in enumerate(rows, start=3):
            ws.cell(row=i, column=1, value=k).font = header_font if k else Font()
            ws.cell(row=i, column=2, value=v)
        # colour the totals
        ws.cell(row=8, column=2).fill = fill_pass
        ws.cell(row=9, column=2).fill = fill_warn
        ws.cell(row=10, column=2).fill = fill_fail
        ws.column_dimensions["A"].width = 24
        ws.column_dimensions["B"].width = 32

        # ── Sheet 2: Compliance (one row per heat) ──
        ws2 = wb.create_sheet("Compliance")
        if self.per_heat:
            cols = ["index", "filename", "heat", "grade", "status", "n_fail", "n_warn"]
            # collect any element measured across all heats
            elem_cols: list[str] = []
            seen: set[str] = set()
            for h in self.per_heat:
                for ch in h.get("checks") or []:
                    sym = ch.get("symbol")
                    if sym and sym not in seen:
                        seen.add(sym)
                        elem_cols.append(sym)
            elem_cols.sort()
            header = cols + elem_cols + ["min_max_table"]
            for c, name in enumerate(header, start=1):
                cell = ws2.cell(row=1, column=c, value=name)
                cell.font = header_font
            for r, h in enumerate(self.per_heat, start=2):
                for c, name in enumerate(cols, start=1):
                    ws2.cell(row=r, column=c, value=h.get(name))
                check_map = {ch["symbol"]: ch for ch in h.get("checks") or []}
                for c, sym in enumerate(elem_cols, start=len(cols) + 1):
                    chk = check_map.get(sym)
                    if chk is None:
                        continue
                    cell = ws2.cell(row=r, column=c, value=chk.get("measured"))
                    if chk.get("pass") is False:
                        cell.fill = fill_fail
                    elif "near boundary" in (chk.get("reason") or ""):
                        cell.fill = fill_warn
                # human-readable min/max summary in last column
                bounds = []
                for ch in h.get("checks") or []:
                    lo, hi = ch.get("min"), ch.get("max")
                    if lo is not None or hi is not None:
                        bounds.append(
                            f"{ch['symbol']}: [{lo if lo is not None else ''},{hi if hi is not None else ''}]"
                        )
                ws2.cell(row=r, column=len(header), value="; ".join(bounds))
                # tint the row by status
                status = h.get("status")
                if status == "pass":
                    fill = fill_pass
                elif status == "near-boundary":
                    fill = fill_warn
                else:
                    fill = fill_fail
                ws2.cell(row=r, column=5).fill = fill
            ws2.freeze_panes = "A2"

        # ── Sheet 3: Flagged ──
        ws3 = wb.create_sheet("Flagged")
        header = ["index", "filename", "heat", "grade", "status", "reason_summary"]
        for c, name in enumerate(header, start=1):
            cell = ws3.cell(row=1, column=c, value=name)
            cell.font = header_font
        for r, h in enumerate(self.flagged, start=2):
            for c, name in enumerate(header[:5], start=1):
                ws3.cell(row=r, column=c, value=h.get(name))
            reasons = [
                f"{ch['symbol']}: {ch.get('reason')}"
                for ch in h.get("checks") or []
                if ch.get("pass") is False or "near" in (ch.get("reason") or "")
            ]
            cell = ws3.cell(row=r, column=6, value="; ".join(reasons) or "—")
            cell.alignment = Alignment(wrap_text=True)
            ws3.cell(row=r, column=5).fill = (
                fill_fail if h.get("status") == "fail" else fill_warn
            )
        for col, width in zip(["A", "B", "C", "D", "E", "F"], [8, 24, 16, 24, 16, 80]):
            ws3.column_dimensions[col].width = width

        os.makedirs(path.parent, exist_ok=True) if path.parent and str(path.parent) != "" else None
        wb.save(str(path))
        return path

    def export_pdf(self, path: Union[str, Path]) -> Path:
        """Write a text-only PDF summary. Optional dep: reportlab."""
        path = Path(path)
        try:
            from reportlab.lib.pagesizes import letter  # type: ignore
            from reportlab.pdfgen import canvas  # type: ignore
        except ImportError:
            # Fallback: write a plain text file with .pdf extension swapped
            path = path.with_suffix(".txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write(self._text_summary())
            return path

        c = canvas.Canvas(str(path), pagesize=letter)
        width, height = letter
        y = height - 50
        c.setFont("Helvetica-Bold", 14)
        c.drawString(50, y, "MTC Lot Audit Report")
        y -= 24
        c.setFont("Helvetica", 10)
        for line in self._text_summary().split("\n"):
            if y < 50:
                c.showPage()
                y = height - 50
                c.setFont("Helvetica", 10)
            c.drawString(50, y, line[:110])
            y -= 14
        c.save()
        return path

    def _text_summary(self) -> str:
        s = self.summary
        lines = [
            f"Spec: {self.spec}",
            f"Period: {self.period or '—'}",
            f"Total heats: {s.get('total', 0)}",
            f"  Pass: {s.get('pass', 0)}",
            f"  Near boundary: {s.get('near_boundary', 0)}",
            f"  Fail: {s.get('fail', 0)}",
            "",
            "Flagged heats:",
        ]
        for h in self.flagged:
            lines.append(
                f"  [{h.get('status')}] {h.get('heat') or h.get('filename')} — "
                f"{h.get('n_fail',0)} fail / {h.get('n_warn',0)} warn"
            )
        return "\n".join(lines)


def audit_lot(
    parsed: "Any",
    *,
    spec: str,
    period: Optional[str] = None,
) -> AuditReport:
    """Run a lot of parsed MTCs against a spec.

    Args:
        parsed: Either the DataFrame returned by :func:`batch_parse`, or a
            list of dicts with ``heat`` / ``chemistry`` keys.
        spec: Spec name (substring match against SPEC_LIBRARY, e.g.
            ``"AISI 4140"`` or ``"ASTM A29"``).
        period: Optional period label (``"2026-Q2"``) recorded in the
            report header.

    Returns:
        :class:`AuditReport` with ``.summary``, ``.per_heat``, ``.flagged``
        and ``.export_xlsx`` / ``.export_pdf`` writers.
    """
    rows: list[dict[str, Any]] = []
    raw_df = None
    try:
        import pandas as pd  # type: ignore

        if isinstance(parsed, pd.DataFrame):
            raw_df = parsed
            for _, row in parsed.iterrows():
                rd = row.to_dict()
                chem: dict[str, float] = {}
                for k, v in rd.items():
                    if k in ELEMENT_ALIASES and v is not None:
                        try:
                            fv = float(v)
                            if fv == fv:  # NaN check
                                chem[k] = fv
                        except (TypeError, ValueError):
                            pass
                rows.append(
                    {
                        "filename": rd.get("file"),
                        "heat": rd.get("heat"),
                        "grade": rd.get("grade"),
                        "chemistry": chem,
                    }
                )
        else:
            rows = _coerce_to_rows(parsed)
    except ImportError:
        rows = _coerce_to_rows(parsed)

    if not rows:
        raise AusteniteError("audit_lot received no parsed heats.")

    client = get_default_client()
    response = client.post(
        "/v1/mtc-audit-lot",
        json={"parsed": rows, "spec": spec, "period": period},
    )
    payload = response.json()

    if "error" in payload:
        raise ValidationError(
            payload.get("error", "audit_lot failed"),
            response_body=payload,
        )

    return AuditReport(
        spec=payload.get("summary", {}).get("spec", spec),
        period=period,
        summary=payload.get("summary", {}),
        per_heat=payload.get("per_heat", []),
        flagged=payload.get("flagged", []),
        raw_df=raw_df,
    )


def _coerce_to_rows(parsed: Any) -> list[dict[str, Any]]:
    """Accept the various input shapes for audit_lot."""
    out: list[dict[str, Any]] = []
    if isinstance(parsed, list):
        for entry in parsed:
            if isinstance(entry, dict):
                chem = entry.get("chemistry") or entry.get("composition") or {}
                # Filter to numeric values only
                clean: dict[str, float] = {}
                for k, v in chem.items():
                    try:
                        clean[str(k)] = float(v)
                    except (TypeError, ValueError):
                        continue
                out.append(
                    {
                        "filename": entry.get("file") or entry.get("filename"),
                        "heat": entry.get("heat") or entry.get("heat_number"),
                        "grade": entry.get("grade"),
                        "chemistry": clean,
                    }
                )
            elif isinstance(entry, MtcParseResult):
                out.append(
                    {
                        "filename": None,
                        "heat": entry.heat_number,
                        "grade": entry.grade,
                        "chemistry": dict(entry.composition),
                    }
                )
    return out


# ---------------------------------------------------------------------------
# compare — element-by-element diff
# ---------------------------------------------------------------------------


def compare(
    mtc_a: Union[MtcParseResult, Mapping[str, Any]],
    mtc_b: Union[MtcParseResult, Mapping[str, Any]],
    *,
    threshold_wt_pct: float = 0.05,
) -> dict[str, Any]:
    """Element-by-element diff between two MTCs.

    Args:
        mtc_a / mtc_b: Either an :class:`MtcParseResult` or a plain dict
            with a ``"composition"`` / ``"chemistry"`` key.
        threshold_wt_pct: Absolute difference above which an element is
            flagged. Default 0.05 wt% (twice typical OES reading
            reproducibility).

    Returns:
        ``{element: {a, b, delta, flag}}`` plus an overall ``{n_diff,
        max_delta_element}``.
    """
    a_comp = _get_comp(mtc_a)
    b_comp = _get_comp(mtc_b)
    elements = sorted(set(a_comp) | set(b_comp))
    diffs: dict[str, Any] = {}
    max_delta = 0.0
    max_elem: Optional[str] = None
    n_diff = 0
    for sym in elements:
        a = a_comp.get(sym)
        b = b_comp.get(sym)
        if a is None and b is None:
            continue
        delta = (b or 0.0) - (a or 0.0)
        flag = abs(delta) > threshold_wt_pct or (a is None) != (b is None)
        diffs[sym] = {
            "a": a,
            "b": b,
            "delta": round(delta, 6),
            "flag": flag,
        }
        if flag:
            n_diff += 1
        if abs(delta) > abs(max_delta):
            max_delta = delta
            max_elem = sym
    return {
        "elements": diffs,
        "n_diff": n_diff,
        "max_delta_element": max_elem,
        "max_delta": round(max_delta, 6),
        "threshold_wt_pct": threshold_wt_pct,
    }


def _get_comp(mtc: Any) -> Mapping[str, float]:
    if isinstance(mtc, MtcParseResult):
        return mtc.composition
    if isinstance(mtc, dict):
        return mtc.get("composition") or mtc.get("chemistry") or {}
    raise TypeError(f"Expected MtcParseResult or dict; got {type(mtc).__name__}")


__all__ = [
    "parse",
    "detect_grade",
    "batch_parse",
    "audit_lot",
    "compare",
    "AuditReport",
]
