"""I/O bridges to the wider open-source materials science ecosystem.

Sub-modules:

* :mod:`austenite.io.tdb` — Parse CALPHAD TDB (SGTE) database files. Closes
  the long-standing pycalphad #413 gap by accepting industry-standard
  ThermoCalc / FactSage / ChemSage / MatCalc database files.

* :mod:`austenite.io.materials_project` — Query the Materials Project REST
  API for DFT energies and structures. Use as CALPHAD prior or for
  cross-validation.

* :mod:`austenite.io.ase` — Round-trip between austenite alloys and ASE
  ``Atoms`` objects for DFT/MD workflow integration.

All three sub-modules have optional heavy dependencies and surface clear
``ImportError`` messages when the corresponding ``[mp]`` / ``[ase]`` /
``[mlip]`` extra isn't installed.

References
----------
* SGTE TDB Specification, *SGTE Unary Database Documentation*,
  Scientific Group Thermodata Europe (1991, rev 2024).
* Jain A. et al., *Commentary: The Materials Project*, APL Materials 1
  (2013) 011002.
* Larsen A. H. et al., *The Atomic Simulation Environment — a Python
  library for working with atoms*, J. Phys. Condens. Matter 29 (2017)
  273002.
"""

from __future__ import annotations

from .tdb import (
    Parameter,
    Phase,
    Species,
    TdbParseError,
    TdbSystem,
    read_tdb,
    write_tdb,
)

__all__ = [
    "Parameter",
    "Phase",
    "Species",
    "TdbParseError",
    "TdbSystem",
    "read_tdb",
    "write_tdb",
]


def __getattr__(name: str):  # type: ignore[no-untyped-def]
    """Lazy-load heavyweight sub-modules (ase, materials_project).

    Keeps ``import austenite.io`` cheap even without the optional
    ``[mp]`` / ``[ase]`` extras installed.
    """

    if name == "ase":
        import importlib

        mod = importlib.import_module(".ase", __name__)
        globals()[name] = mod
        return mod
    if name == "materials_project":
        import importlib

        mod = importlib.import_module(".materials_project", __name__)
        globals()[name] = mod
        return mod
    raise AttributeError(f"module 'austenite.io' has no attribute {name!r}")
