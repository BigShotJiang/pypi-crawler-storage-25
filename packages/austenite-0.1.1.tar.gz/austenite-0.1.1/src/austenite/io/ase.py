"""ASE (Atomic Simulation Environment) bridge.

Converts austenite alloys ↔ :class:`ase.Atoms` so engineers can pipe
austenite results through any of ASE's 30+ DFT / MD calculators
(VASP, Quantum ESPRESSO, LAMMPS, Gaussian, GPAW, etc.) and feed the
output back to a CALPHAD posterior.

API
---
* :func:`to_atoms` — austenite alloy or composition → :class:`ase.Atoms`.
* :func:`from_atoms` — :class:`ase.Atoms` → austenite alloy record.

References
----------
* Larsen A. H. et al. *The Atomic Simulation Environment*. J. Phys.:
  Condens. Matter 29 (2017) 273002.

A Javanshir Hasanov production.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Optional, Sequence, Union


__all__ = [
    "AseImportError",
    "AlloyRecord",
    "from_atoms",
    "to_atoms",
]


class AseImportError(ImportError):
    """Raised when ``ase`` is not installed."""


_IMPORT_HINT = (
    "ASE bridge requires the `ase` package.\n"
    "Install with:\n"
    "    pip install 'austenite[ase]'\n"
    "or directly:\n"
    "    pip install ase\n"
    "ASE docs: https://wiki.fysik.dtu.dk/ase/"
)


def _require_ase() -> Any:
    try:
        import ase  # type: ignore
        return ase
    except ImportError as exc:
        raise AseImportError(_IMPORT_HINT) from exc


@dataclass
class AlloyRecord:
    """A lightweight austenite alloy descriptor.

    Used when round-tripping ASE → austenite for alloys that are not
    necessarily in the bundled catalog. ``elements`` and ``composition``
    are aligned: ``composition[i]`` is the mole fraction of
    ``elements[i]``.

    Attributes:
        alloy_id: Caller-provided identifier (e.g. ``"AISI 4140"``).
        elements: Element symbols in declaration order.
        composition: Mole fractions matching ``elements``.
        crystal_structure: ASE structure code (``"bcc"``, ``"fcc"``,
            ``"hcp"``, ...) if known.
        lattice_constant_A: Lattice parameter (Å) if known.
        provenance: Free text — e.g. ``"ase.bulk('Fe', 'bcc', a=2.87)"``.
    """

    alloy_id: str
    elements: list[str] = field(default_factory=list)
    composition: list[float] = field(default_factory=list)
    crystal_structure: Optional[str] = None
    lattice_constant_A: Optional[float] = None
    provenance: str = ""

    def composition_dict(self) -> dict[str, float]:
        """Return the composition as an ``{element: fraction}`` map."""

        return {el: frac for el, frac in zip(self.elements, self.composition)}

    def to_dict(self) -> dict[str, Any]:
        return {
            "alloy_id": self.alloy_id,
            "elements": list(self.elements),
            "composition": list(self.composition),
            "crystal_structure": self.crystal_structure,
            "lattice_constant_A": self.lattice_constant_A,
            "provenance": self.provenance,
        }


# ---------------------------------------------------------------------------
# Conversion
# ---------------------------------------------------------------------------


def from_atoms(atoms: Any, alloy_id: str = "ase-import") -> AlloyRecord:
    """Convert an :class:`ase.Atoms` to an :class:`AlloyRecord`.

    The mole fractions are computed from the atom-symbol counts in the
    primitive cell. Crystal structure is detected heuristically from the
    cell shape: cubic-1-atom = simple cubic, cubic-2-atom-BCC vector, etc.

    Args:
        atoms: An ase.Atoms object.
        alloy_id: Caller-provided alloy identifier.

    Returns:
        :class:`AlloyRecord` carrying the composition and structure.

    Example::

        from ase.build import bulk
        import austenite as au
        atoms = bulk("Fe", "bcc", a=2.87)
        alloy = au.io.ase.from_atoms(atoms, alloy_id="Fe-bcc")
        assert alloy.elements == ["Fe"]
    """

    ase_mod = _require_ase()
    if not isinstance(atoms, ase_mod.Atoms):  # type: ignore[attr-defined]
        raise TypeError(
            f"Expected ase.Atoms, got {type(atoms).__name__}"
        )

    symbols = list(atoms.get_chemical_symbols())
    if not symbols:
        raise ValueError("ase.Atoms cell is empty")

    counts: dict[str, int] = {}
    for s in symbols:
        counts[s] = counts.get(s, 0) + 1
    total = sum(counts.values())
    elements_sorted = sorted(counts.keys())
    composition = [counts[el] / total for el in elements_sorted]

    # Structure detection — coarse classifier from cell vectors.
    structure = _detect_structure(atoms)
    a = _detect_a(atoms)

    return AlloyRecord(
        alloy_id=alloy_id,
        elements=elements_sorted,
        composition=composition,
        crystal_structure=structure,
        lattice_constant_A=a,
        provenance=f"from_atoms({len(symbols)} atoms, cell={list(atoms.cell.cellpar()[:3])})",
    )


def to_atoms(
    alloy: Union[str, AlloyRecord, Mapping[str, float]],
    *,
    crystal_structure: Optional[str] = None,
    lattice_constant_A: Optional[float] = None,
    supercell: tuple[int, int, int] = (1, 1, 1),
    alloy_id: Optional[str] = None,
) -> Any:
    """Build an :class:`ase.Atoms` from an austenite alloy descriptor.

    The function accepts three input shapes:
      1. ``alloy_id`` string — looked up in ``au.data.alloys()``.
      2. :class:`AlloyRecord` — used directly.
      3. ``dict[element, fraction]`` — composition map; pairs with
         ``crystal_structure`` / ``lattice_constant_A`` kwargs.

    The primitive cell is built via :func:`ase.build.bulk` using the
    dominant element's symbol as the host lattice. Substitutional
    alloying is approximated by writing the alloy's symbol distribution
    onto the supercell.

    Args:
        alloy: Alloy descriptor — string ID, AlloyRecord, or
            composition dict.
        crystal_structure: ``"bcc"`` / ``"fcc"`` / ``"hcp"`` / etc.;
            overrides any cached value on the record.
        lattice_constant_A: Lattice constant in Å.
        supercell: ``(nx, ny, nz)`` repeat factors.
        alloy_id: Optional override for the alloy label.

    Returns:
        :class:`ase.Atoms`.

    Example::

        atoms = au.io.ase.to_atoms("AISI 4140", supercell=(2,2,2))
    """

    _require_ase()
    from ase.build import bulk  # type: ignore  # noqa: PLC0415
    import ase  # type: ignore  # noqa: PLC0415

    if isinstance(alloy, AlloyRecord):
        record = alloy
    elif isinstance(alloy, str):
        record = _lookup_alloy(alloy)
    elif isinstance(alloy, Mapping):
        record = _record_from_composition(
            composition=alloy,
            alloy_id=alloy_id or "composition-input",
            crystal_structure=crystal_structure,
            lattice_constant_A=lattice_constant_A,
        )
    else:
        raise TypeError(
            f"Unsupported alloy input type: {type(alloy).__name__}"
        )

    struct = crystal_structure or record.crystal_structure or "bcc"
    a = lattice_constant_A or record.lattice_constant_A or _default_a(record.elements)

    if not record.elements:
        raise ValueError("AlloyRecord has no elements")
    host = record.elements[0]
    try:
        atoms = bulk(host.capitalize(), struct, a=a, cubic=True)
    except (TypeError, ValueError):
        # bulk() raises if 'cubic=True' is incompatible with the structure
        # (e.g. hcp). Fall back to the conventional cell.
        atoms = bulk(host.capitalize(), struct, a=a)

    nx, ny, nz = supercell
    if (nx, ny, nz) != (1, 1, 1):
        atoms = atoms.repeat(supercell)

    # Substitutional approximation: random-style ordered substitution
    # respecting the composition mole fractions. Deterministic — uses a
    # simple modulo lookup so tests are reproducible.
    if len(record.elements) > 1:
        n = len(atoms)
        # Build a per-atom symbol assignment that respects target counts.
        target_counts = {
            el: max(int(round(frac * n)), 0)
            for el, frac in zip(record.elements, record.composition)
        }
        # Renormalise to exactly n atoms.
        diff = n - sum(target_counts.values())
        if diff != 0:
            target_counts[record.elements[0]] = max(
                target_counts[record.elements[0]] + diff, 0
            )
        symbols: list[str] = []
        for el in record.elements:
            symbols.extend([el.capitalize()] * target_counts[el])
        symbols = symbols[:n]
        # Pad if rounding lost atoms.
        while len(symbols) < n:
            symbols.append(record.elements[0].capitalize())
        atoms.set_chemical_symbols(symbols)

    return atoms


# ---------------------------------------------------------------------------
# Helpers — heuristic structure detection + defaults
# ---------------------------------------------------------------------------


def _detect_structure(atoms: Any) -> Optional[str]:
    """Coarse structure classifier from cell shape.

    Returns ``"bcc"``, ``"fcc"``, ``"hcp"``, ``"sc"``, or ``None`` when
    ambiguous. The heuristic uses the cell angles and atom count:

    * Cubic (90/90/90, a=b=c) with 1 atom    → ``sc``
    * Cubic with 2 atoms at (0,0,0) + (0.5,0.5,0.5)  → ``bcc``
    * Cubic with 4 atoms                     → ``fcc`` (primitive often 1)
    * Hexagonal (90/90/120, a=b≠c) with 2 atoms → ``hcp``
    """

    cell = atoms.cell
    a, b, c, al, be, ga = cell.cellpar()

    def _near(x: float, y: float, tol: float = 0.02) -> bool:
        return abs(x - y) < tol * max(abs(x), abs(y), 1e-9)

    n_atoms = len(atoms)
    cubic = _near(al, 90) and _near(be, 90) and _near(ga, 90) and _near(a, b) and _near(b, c)
    hex_like = _near(al, 90) and _near(be, 90) and _near(ga, 120) and _near(a, b)

    if cubic:
        if n_atoms == 1:
            return "sc"  # primitive cubic
        if n_atoms == 2:
            # Likely BCC primitive cell rebuilt as conventional (Fe etc.)
            return "bcc"
        if n_atoms == 4:
            return "fcc"
        if n_atoms in (8,):  # BCC conventional
            return "bcc"
    if hex_like and n_atoms in (2, 4):
        return "hcp"
    return None


def _detect_a(atoms: Any) -> Optional[float]:
    """Return the cubic lattice parameter (Å) if the cell is ~cubic."""

    a, b, c, al, be, ga = atoms.cell.cellpar()
    if abs(al - 90) < 2 and abs(be - 90) < 2 and abs(ga - 90) < 2:
        return float(a)
    return None


def _default_a(elements: Sequence[str]) -> float:
    """Look up a reasonable cubic-lattice parameter (Å) per host element."""

    table = {
        "FE": 2.87, "CR": 2.88, "NI": 3.52, "MO": 3.15, "AL": 4.05,
        "CU": 3.61, "TI": 2.95, "V": 3.03, "MN": 8.91, "SI": 5.43,
        "C": 3.57, "CO": 2.51, "W": 3.16, "TA": 3.30, "NB": 3.30,
    }
    if not elements:
        return 3.50
    return table.get(elements[0].upper(), 3.50)


def _lookup_alloy(alloy_id: str) -> AlloyRecord:
    """Look up an alloy in ``austenite.data.alloys()`` and build a record."""

    from .. import data as _data  # noqa: PLC0415

    row = _data.alloy_lookup(alloy_id) if hasattr(_data, "alloy_lookup") else None
    if row is None:
        raise ValueError(
            f"alloy {alloy_id!r} not found in au.data.alloys(); "
            "use a composition dict instead."
        )
    # The alloys catalog uses an 'composition' or per-element columns. We
    # accept both shapes.
    comp = row.get("composition")
    if isinstance(comp, dict):
        elements = list(comp.keys())
        comp_vals = [float(v) for v in comp.values()]
    else:
        # Heuristic: any 1-2-letter all-caps column with a numeric value.
        elements = []
        comp_vals = []
        for k, v in row.items():
            if not isinstance(k, str):
                continue
            if 1 <= len(k) <= 2 and k.isupper() and isinstance(v, (int, float)):
                elements.append(k)
                comp_vals.append(float(v))
        if not elements:
            elements = ["FE"]
            comp_vals = [1.0]
    total = sum(comp_vals) or 1.0
    comp_vals = [v / total for v in comp_vals]
    return AlloyRecord(
        alloy_id=alloy_id,
        elements=elements,
        composition=comp_vals,
        crystal_structure=row.get("crystal_structure", "bcc"),
        lattice_constant_A=row.get("lattice_constant_A"),
        provenance=f"au.data.alloy_lookup({alloy_id!r})",
    )


def _record_from_composition(
    composition: Mapping[str, float],
    alloy_id: str,
    crystal_structure: Optional[str] = None,
    lattice_constant_A: Optional[float] = None,
) -> AlloyRecord:
    elements = list(composition.keys())
    vals = [float(composition[e]) for e in elements]
    total = sum(vals) or 1.0
    vals = [v / total for v in vals]
    return AlloyRecord(
        alloy_id=alloy_id,
        elements=elements,
        composition=vals,
        crystal_structure=crystal_structure,
        lattice_constant_A=lattice_constant_A,
        provenance="composition-input",
    )
