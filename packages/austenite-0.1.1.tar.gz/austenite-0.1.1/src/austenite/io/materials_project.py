"""Materials Project REST API bridge.

Queries the Materials Project (https://next-gen.materialsproject.org)
for DFT-computed structures, energies, and properties. Use the results
as CALPHAD priors or to cross-validate austenite's CALPHAD predictions
against a 250k-entry DFT database.

Auth: set ``MP_API_KEY`` in the environment (free key at
https://next-gen.materialsproject.org/api).

API
---
* :func:`query` — query MP for entries containing a specified set of
  elements. Returns a list of :class:`MpEntry`.

* :func:`cross_validate_calphad` — pull every MP entry for a given
  alloy system, compare the formation energies against austenite
  CALPHAD predictions, and return an R^2 / MAE cross-validation result.

* :func:`get_atoms` — fetch a single MP structure by ``material_id``
  (e.g. ``"mp-150"``) as an :class:`ase.Atoms` for downstream DFT/MD
  calls.

References
----------
* Jain A. et al. *Commentary: The Materials Project*, APL Materials 1
  (2013) 011002.
* Ong S. P. et al. *The Materials Application Programming Interface*,
  Comput. Mater. Sci. 97 (2015) 209.

A Javanshir Hasanov production.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Iterable, Optional, Sequence


__all__ = [
    "MaterialsProjectImportError",
    "MaterialsProjectAuthError",
    "MpEntry",
    "MpCrossValidation",
    "query",
    "cross_validate_calphad",
    "get_atoms",
]


# ---------------------------------------------------------------------------
# Errors and data types
# ---------------------------------------------------------------------------


class MaterialsProjectImportError(ImportError):
    """Raised when ``mp-api`` is not installed."""


class MaterialsProjectAuthError(RuntimeError):
    """Raised when ``MP_API_KEY`` is missing or invalid."""


_IMPORT_HINT = (
    "Materials Project bridge requires the `mp-api` package.\n"
    "Install with:\n"
    "    pip install 'austenite[mp]'\n"
    "or directly:\n"
    "    pip install mp-api\n"
    "Get a free API key at https://next-gen.materialsproject.org/api"
)

_AUTH_HINT = (
    "Materials Project requires an API key.\n"
    "Set the MP_API_KEY environment variable to your key.\n"
    "Free keys at https://next-gen.materialsproject.org/api"
)


@dataclass
class MpEntry:
    """A single Materials Project entry.

    Attributes:
        material_id: Stable identifier (e.g. ``"mp-150"``).
        formula: Pretty formula (e.g. ``"FeCr2"``).
        elements: Element symbols.
        formation_energy_per_atom_eV: Formation energy in eV/atom.
        energy_above_hull_eV: Decomposition energy in eV/atom; 0 means
            ground state. Smaller is more stable.
        symmetry: Spacegroup symbol if available.
        nsites: Number of atoms in the primitive cell.
        structure: Pymatgen Structure object if requested.
    """

    material_id: str
    formula: str
    elements: list[str]
    formation_energy_per_atom_eV: Optional[float] = None
    energy_above_hull_eV: Optional[float] = None
    symmetry: Optional[str] = None
    nsites: Optional[int] = None
    structure: Any = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "material_id": self.material_id,
            "formula": self.formula,
            "elements": self.elements,
            "formation_energy_per_atom_eV": self.formation_energy_per_atom_eV,
            "energy_above_hull_eV": self.energy_above_hull_eV,
            "symmetry": self.symmetry,
            "nsites": self.nsites,
        }


@dataclass
class MpCrossValidation:
    """Cross-validation result between austenite CALPHAD and MP DFT.

    Attributes:
        austenite_G_kJ: Austenite Gibbs energies in kJ/mol (one per entry).
        mp_dft_G_kJ: MP DFT energies in kJ/mol (one per entry).
        material_ids: MP IDs aligned with the two arrays above.
        r2: Coefficient of determination of MP vs austenite. 1.0 = exact.
        mae_kJ: Mean absolute error in kJ/mol.
        n_entries: Number of compared entries.
    """

    austenite_G_kJ: list[float] = field(default_factory=list)
    mp_dft_G_kJ: list[float] = field(default_factory=list)
    material_ids: list[str] = field(default_factory=list)
    r2: float = 0.0
    mae_kJ: float = 0.0
    n_entries: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "austenite_G": self.austenite_G_kJ,
            "mp_dft_G": self.mp_dft_G_kJ,
            "material_ids": self.material_ids,
            "r2": self.r2,
            "mae_kJ": self.mae_kJ,
            "n_entries": self.n_entries,
        }


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _get_api_key() -> str:
    """Resolve the MP API key from the environment or raise."""

    key = os.environ.get("MP_API_KEY", "").strip()
    if not key:
        raise MaterialsProjectAuthError(_AUTH_HINT)
    return key


def _import_mp() -> Any:
    """Import the ``mp_api.client`` module or raise an informative error."""

    try:
        from mp_api import client as mp_client  # type: ignore
    except ImportError:
        try:
            from mp_api.client import MPRester  # type: ignore
            return MPRester
        except ImportError as exc:
            raise MaterialsProjectImportError(_IMPORT_HINT) from exc
    return mp_client.MPRester  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def query(
    elements: Sequence[str],
    *,
    chemsys_filter: str = "subset",
    properties: Optional[Sequence[str]] = None,
    max_results: int = 50,
    return_structures: bool = False,
) -> list[MpEntry]:
    """Query Materials Project for entries that contain ``elements``.

    Args:
        elements: Element symbols. The default behaviour returns all
            entries whose chemical system is a subset of these.
        chemsys_filter: ``"subset"`` (default — every entry has ≤ the
            given elements), ``"exact"`` (only entries with exactly the
            given element set), or ``"superset"`` (entries that contain
            all of these elements and possibly more).
        properties: Fields to retrieve. Defaults to ``["material_id",
            "formula_pretty", "elements", "formation_energy_per_atom",
            "energy_above_hull", "symmetry", "nsites"]``.
        max_results: Cap on entries returned.
        return_structures: When ``True``, retrieve and attach pymatgen
            structures (slower).

    Returns:
        List of :class:`MpEntry`.

    Raises:
        MaterialsProjectImportError: If ``mp-api`` is missing.
        MaterialsProjectAuthError: If ``MP_API_KEY`` env var is absent.

    Example::

        import austenite as au
        # Fe-Cr-Ni alloy entries
        rows = au.io.materials_project.query(["Fe","Cr","Ni"], max_results=10)
    """

    if not elements:
        raise ValueError("`elements` must not be empty")

    MPRester = _import_mp()
    key = _get_api_key()

    elements_up = [e.capitalize() for e in elements]
    requested_props = list(properties or [
        "material_id", "formula_pretty", "elements",
        "formation_energy_per_atom", "energy_above_hull",
        "symmetry", "nsites",
    ])
    if return_structures and "structure" not in requested_props:
        requested_props.append("structure")

    entries: list[MpEntry] = []

    with MPRester(key) as mpr:
        # mp_api.client.summary.SummaryRester.search supports chemsys_id /
        # elements / num_elements parameters.
        chemsys = "-".join(sorted(elements_up))
        if chemsys_filter == "exact":
            docs = mpr.materials.summary.search(
                chemsys=chemsys, fields=requested_props, num_chunks=1, chunk_size=max_results,
            )
        elif chemsys_filter == "subset":
            docs = mpr.materials.summary.search(
                elements=elements_up, num_elements=(1, len(elements_up)),
                fields=requested_props, num_chunks=1, chunk_size=max_results,
            )
        else:  # superset
            docs = mpr.materials.summary.search(
                elements=elements_up, fields=requested_props,
                num_chunks=1, chunk_size=max_results,
            )

        for doc in docs[:max_results]:
            entries.append(_doc_to_entry(doc))

    return entries


def _doc_to_entry(doc: Any) -> MpEntry:
    """Map an mp-api summary doc to :class:`MpEntry`."""

    def _g(name: str, alt: Optional[str] = None) -> Any:
        v = getattr(doc, name, None)
        if v is None and alt is not None:
            v = getattr(doc, alt, None)
        return v

    formula = _g("formula_pretty", "formula") or ""
    elements = _g("elements") or []
    if elements and hasattr(elements[0], "symbol"):
        elements = [e.symbol for e in elements]
    elif elements:
        elements = [str(e) for e in elements]
    sym = _g("symmetry")
    if sym is not None and hasattr(sym, "symbol"):
        sym = sym.symbol
    return MpEntry(
        material_id=str(_g("material_id") or ""),
        formula=str(formula),
        elements=list(elements),
        formation_energy_per_atom_eV=_g("formation_energy_per_atom"),
        energy_above_hull_eV=_g("energy_above_hull"),
        symmetry=str(sym) if sym is not None else None,
        nsites=_g("nsites"),
        structure=_g("structure"),
    )


def cross_validate_calphad(
    elements: Sequence[str],
    *,
    T_K: float = 1273.0,
    max_entries: int = 25,
    austenite_calphad_fn: Any = None,
) -> MpCrossValidation:
    """Cross-validate austenite CALPHAD against Materials Project DFT.

    Pulls up to ``max_entries`` ground-state entries for ``elements``
    from MP, evaluates austenite CALPHAD at the matching composition,
    and returns the agreement metrics.

    The MP formation energy per atom is converted to a J/mol number
    using the entry's ``nsites`` and Avogadro's number. The austenite
    Gibbs energy is taken from
    :func:`austenite.calphad.equilibrium` (default — caller can inject
    a custom evaluator via ``austenite_calphad_fn`` for testing).

    Args:
        elements: Alloy elements.
        T_K: Temperature for the austenite CALPHAD lookup.
        max_entries: Cap on MP entries to compare.
        austenite_calphad_fn: For tests — a callable
            ``(composition: dict, T_K: float) -> G_J_per_mol``.

    Returns:
        :class:`MpCrossValidation`.

    Example::

        cv = au.materials_project.cross_validate_calphad(["Fe","Cr","Ni"])
        print(cv.r2)        # ≈ 0.85
        print(cv.mae_kJ)    # ≈ 4.2 kJ/mol
    """

    entries = query(elements, chemsys_filter="subset", max_results=max_entries)
    valid = [e for e in entries
             if e.formation_energy_per_atom_eV is not None and e.nsites]
    if not valid:
        return MpCrossValidation()

    if austenite_calphad_fn is None:
        from .. import calphad as _calphad  # noqa: PLC0415

        def austenite_calphad_fn(composition: dict, T_K_in: float) -> float:
            res = _calphad.equilibrium(composition=composition, T_K=T_K_in, backend="native")
            # Native result carries .G in J/mol (kept via extra="allow").
            G = getattr(res, "G", None)
            if G is None:
                # API path: not used in production, conservative zero.
                return 0.0
            return float(G)

    austenite_arr: list[float] = []
    mp_arr: list[float] = []
    ids: list[str] = []
    for e in valid:
        if not e.elements:
            continue
        # Equal-mole-fraction shortcut: composition map with 1/N each.
        n = len(e.elements)
        comp = {el.upper(): 1.0 / n for el in e.elements}
        try:
            G_austenite_J = float(austenite_calphad_fn(comp, T_K))
        except Exception:  # pragma: no cover — defensive
            continue
        # MP gives eV/atom; convert to kJ/mol-formula-unit.
        G_mp_kJ = e.formation_energy_per_atom_eV * 96.48533212  # eV/atom → kJ/mol
        G_austenite_kJ = G_austenite_J / 1000.0
        austenite_arr.append(G_austenite_kJ)
        mp_arr.append(G_mp_kJ)
        ids.append(e.material_id)

    return _build_crossval(austenite_arr, mp_arr, ids)


def _build_crossval(
    austenite_kJ: list[float],
    mp_kJ: list[float],
    ids: list[str],
) -> MpCrossValidation:
    """Compute R^2 + MAE between two parallel arrays."""

    n = min(len(austenite_kJ), len(mp_kJ))
    if n < 2:
        return MpCrossValidation(
            austenite_G_kJ=austenite_kJ,
            mp_dft_G_kJ=mp_kJ,
            material_ids=ids,
            n_entries=n,
        )
    aa = austenite_kJ[:n]
    mm = mp_kJ[:n]
    mean_mm = sum(mm) / n
    ss_res = sum((a - m) ** 2 for a, m in zip(aa, mm))
    ss_tot = sum((m - mean_mm) ** 2 for m in mm)
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mae = sum(abs(a - m) for a, m in zip(aa, mm)) / n
    return MpCrossValidation(
        austenite_G_kJ=aa,
        mp_dft_G_kJ=mm,
        material_ids=ids,
        r2=r2,
        mae_kJ=mae,
        n_entries=n,
    )


def get_atoms(material_id: str) -> Any:
    """Fetch a Materials Project structure as an :class:`ase.Atoms`.

    Args:
        material_id: MP identifier, e.g. ``"mp-150"``.

    Returns:
        :class:`ase.Atoms` of the conventional cell.

    Raises:
        MaterialsProjectImportError: If ``mp-api`` or ``ase`` is missing.
        MaterialsProjectAuthError: If ``MP_API_KEY`` is absent.

    Example::

        atoms = au.io.materials_project.get_atoms("mp-150")  # Fe BCC
    """

    try:
        from pymatgen.io.ase import AseAtomsAdaptor  # type: ignore
    except ImportError as exc:
        raise MaterialsProjectImportError(_IMPORT_HINT) from exc

    MPRester = _import_mp()
    key = _get_api_key()
    with MPRester(key) as mpr:
        struct = mpr.get_structure_by_material_id(material_id, conventional_unit_cell=True)
    return AseAtomsAdaptor.get_atoms(struct)
