"""Parser for the SGTE TDB (Thermodynamic DataBase) file format.

This module closes the long-standing pycalphad #413 gap (20-comment,
4-year-old issue) and lets engineers feed their existing $30k/year
ThermoCalc / FactSage / ChemSage / MatCalc / pycalphad database files
into austenite.

Supported statements (the 80% that real industrial files use)
-------------------------------------------------------------
* ``DATABASE_INFO``     — free-form header text up to ``!``
* ``DEFINE_SYSTEM_DEFAULT`` — default element scope
* ``ELEMENT``           — element name + ref. phase + atomic weight
                           + H_298 + S_298
* ``SPECIES``           — molecular species composed of elements
* ``PHASE``             — phase declaration + model code + sublattices
* ``CONSTITUENT``       — list of species occupying each sublattice
* ``FUNCTION`` (``FUN``) — named temperature-dependent function with
                           one or more T-range expressions
* ``PARAMETER`` (``PAR``) — phase parameter (G, L, TC, BMAGN, ...)
                           with R-K mixing order
* ``TYPE_DEFINITION`` (``TYPE_DEF``) — model code shorthand
                           (magnetic, order-disorder)
* ``LIST_OF_REFERENCES`` / ``REFERENCE_FILE`` — reference list

Grammar overview (simplified)::

    file       := statement*
    statement  := KEYWORD body '!'
    body       := token (token | string | expression)*
    expression := T_RANGE '...' T_RANGE | poly_in_T

Strings are ``'`` or ``"`` quoted; comments start with ``$`` and run to
end-of-line. Statements terminate with ``!``. Continuation lines do not
need explicit markers — ``!`` is the only terminator.

The parser is a recursive-descent tokenizer + statement dispatcher. It
does *not* attempt to evaluate functions or build an equilibrium engine;
it parses the database into a :class:`TdbSystem` data structure that
``au.calphad.equilibrium(system=...)`` can consume.

References
----------
* SGTE TDB Specification, *SGTE Unary Database Documentation*,
  Scientific Group Thermodata Europe (1991, rev 2024).
* Dinsdale A. T., *SGTE data for pure elements*, CALPHAD 15 (1991) 317.
* Sundman B., Lukas H. L., Fries S. G., *Computational Thermodynamics —
  The CALPHAD Method*, Cambridge Univ. Press (2007), Ch. 5.4.
* Otis R., Liu Z.-K., *pycalphad: CALPHAD-based Computational
  Thermodynamics in Python*, J. Open Res. Soft. 5 (2017) 1.

A Javanshir Hasanov production.
"""

from __future__ import annotations

import io
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Optional, Sequence, Union


__all__ = [
    "Parameter",
    "Phase",
    "Species",
    "TdbParseError",
    "TdbSystem",
    "read_tdb",
    "write_tdb",
]


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class TdbParseError(ValueError):
    """Raised when a TDB file violates the SGTE grammar.

    Carries ``line`` (1-indexed) and ``column`` (1-indexed) attributes so
    callers can highlight the offending location.
    """

    def __init__(self, msg: str, line: int = 0, column: int = 0) -> None:
        self.line = line
        self.column = column
        if line:
            msg = f"line {line}:{column}: {msg}"
        super().__init__(msg)


# ---------------------------------------------------------------------------
# Data classes — the parsed TDB system
# ---------------------------------------------------------------------------


@dataclass
class Species:
    """A chemical species: element or molecular formula.

    Attributes:
        name: Species name (e.g. ``"FE"``, ``"O2"``, ``"FE3C"``).
        stoichiometry: Element → count map.
        charge: Formal ionic charge (default 0).
    """

    name: str
    stoichiometry: dict[str, float] = field(default_factory=dict)
    charge: float = 0.0


@dataclass
class Phase:
    """A CALPHAD phase definition.

    Attributes:
        name: Phase name (e.g. ``"LIQUID"``, ``"BCC_A2"``, ``"SIGMA"``).
        model_codes: Single-letter type codes attached via TYPE_DEF
            (e.g. ``"%"`` ferromagnetic, ``"&"`` order-disorder).
        sublattice_sites: Number of sites per sublattice.
        constituents: For each sublattice, list of species names.
    """

    name: str
    model_codes: list[str] = field(default_factory=list)
    sublattice_sites: list[float] = field(default_factory=list)
    constituents: list[list[str]] = field(default_factory=list)


@dataclass
class Parameter:
    """A thermodynamic parameter, e.g. ``G(BCC_A2,FE)``, ``L(SIGMA,FE,CR;0)``.

    Attributes:
        kind: Parameter symbol — ``G`` (Gibbs energy), ``L`` (interaction),
            ``TC`` (Curie temperature), ``BMAGN`` (Bohr magneton),
            ``BMAG`` (alias), ``MQ`` (mobility), etc.
        phase: Phase name the parameter belongs to.
        constituents: Constituent array, one entry per sublattice. Each
            entry is a list of species names. For interaction params the
            mixing sublattice has 2+ species.
        order: Redlich-Kister order (0, 1, 2, ...). Default 0 for
            non-mixing parameters.
        expression: The right-hand-side expression(s). A list of
            ``(T_low, T_high, expr_str)`` tuples that together cover the
            full temperature range. The expression may reference named
            ``FUNCTION``s.
        reference: Citation/reference string from the line tail.
    """

    kind: str
    phase: str
    constituents: list[list[str]] = field(default_factory=list)
    order: int = 0
    expression: list[tuple[float, float, str]] = field(default_factory=list)
    reference: str = ""


@dataclass
class TdbSystem:
    """A parsed TDB database.

    Use :func:`read_tdb` to construct one. ``elements`` is element
    symbols in declaration order. ``phases`` is phase names. The full
    parsed object graph is in ``species``, ``phase_objects``,
    ``parameters``, ``functions``, ``type_definitions``.

    Hand-off API for downstream engines (e.g. ``au.calphad.equilibrium``):
        ``system.elements``     → list[str]
        ``system.phases``       → list[str]
        ``system.parameters``   → list[Parameter]
        ``system.functions``    → dict[name, list[(T_low, T_high, expr)]]
    """

    elements: list[str] = field(default_factory=list)
    element_data: dict[str, dict[str, float]] = field(default_factory=dict)
    species: dict[str, Species] = field(default_factory=dict)
    phases: list[str] = field(default_factory=list)
    phase_objects: dict[str, Phase] = field(default_factory=dict)
    parameters: list[Parameter] = field(default_factory=list)
    functions: dict[str, list[tuple[float, float, str]]] = field(default_factory=dict)
    type_definitions: dict[str, str] = field(default_factory=dict)
    database_info: str = ""
    default_elements: list[str] = field(default_factory=list)
    references: dict[str, str] = field(default_factory=dict)

    # -- summary helpers ----------------------------------------------------

    def summary(self) -> str:
        """Return a one-line summary suitable for the REPL."""

        return (
            f"TdbSystem(elements={len(self.elements)}, "
            f"phases={len(self.phases)}, parameters={len(self.parameters)}, "
            f"functions={len(self.functions)})"
        )

    def parameters_for_phase(self, phase: str) -> list[Parameter]:
        """Return all parameters that belong to ``phase`` (case-insensitive)."""

        ph = phase.upper()
        return [p for p in self.parameters if p.phase.upper() == ph]

    def parameter(self, kind: str, phase: str, constituents: Sequence[Sequence[str]],
                  order: int = 0) -> Optional[Parameter]:
        """Look up a parameter by ``(kind, phase, constituents, order)``.

        Returns the first match (case-insensitive on species names) or
        ``None`` if absent.
        """

        kn, pn = kind.upper(), phase.upper()
        target = [tuple(sorted(s.upper() for s in sub)) for sub in constituents]
        for p in self.parameters:
            if p.kind.upper() != kn or p.phase.upper() != pn or p.order != order:
                continue
            here = [tuple(sorted(s.upper() for s in sub)) for sub in p.constituents]
            if here == target:
                return p
        return None


# ---------------------------------------------------------------------------
# Tokenizer
# ---------------------------------------------------------------------------


class _Token:
    __slots__ = ("kind", "value", "line", "column")

    def __init__(self, kind: str, value: str, line: int, column: int) -> None:
        self.kind = kind
        self.value = value
        self.line = line
        self.column = column

    def __repr__(self) -> str:  # pragma: no cover - debug aid
        return f"Token({self.kind!r}, {self.value!r}, L{self.line}:C{self.column})"


# Whitespace, comment, string, number, bang (statement terminator),
# semicolon (sublattice separator), comma (in lists), word.
_WORD_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_+\-*/\.#]*")
_NUM_RE = re.compile(
    r"""
    [+-]?               # optional sign
    (?:                 # body
        \d+\.\d*        # 12.  or  12.34
      | \.\d+           # .34
      | \d+             # 12
    )
    (?:[eEdD][+-]?\d+)? # optional exponent (Fortran D also accepted)
    """,
    re.VERBOSE,
)


def _tokenize(text: str) -> list[_Token]:
    """Tokenize TDB source text into a flat token list.

    Comments (``$`` to end-of-line) and pure whitespace are dropped.
    The terminator ``!`` and separators ``;`` ``,`` ``(`` ``)`` are
    emitted as their own one-character tokens.
    """

    tokens: list[_Token] = []
    i = 0
    line = 1
    col_start = 0
    n = len(text)

    while i < n:
        ch = text[i]

        # Newline: bump line counter
        if ch == "\n":
            line += 1
            col_start = i + 1
            i += 1
            continue
        if ch == "\r":
            i += 1
            continue
        # Whitespace
        if ch in " \t":
            i += 1
            continue
        # Comment
        if ch == "$":
            nl = text.find("\n", i)
            if nl == -1:
                break
            i = nl  # newline handled next iter
            continue
        # Statement terminator
        if ch == "!":
            tokens.append(_Token("BANG", "!", line, i - col_start + 1))
            i += 1
            continue
        # Sublattice separator
        if ch == ":":
            tokens.append(_Token("COLON", ":", line, i - col_start + 1))
            i += 1
            continue
        # Sublattice site count / R-K order separator
        if ch == ";":
            tokens.append(_Token("SEMI", ";", line, i - col_start + 1))
            i += 1
            continue
        # Comma
        if ch == ",":
            tokens.append(_Token("COMMA", ",", line, i - col_start + 1))
            i += 1
            continue
        # Parens
        if ch == "(":
            tokens.append(_Token("LPAREN", "(", line, i - col_start + 1))
            i += 1
            continue
        if ch == ")":
            tokens.append(_Token("RPAREN", ")", line, i - col_start + 1))
            i += 1
            continue
        # Strings — only double quotes per SGTE spec.
        # The single-quote ' is reserved as a TYPE_DEFINITION code character
        # in many real SGTE files (e.g. FCC_A1 magnetic shorthand), so we
        # cannot treat it as a string opener.
        if ch == '"':
            j = i + 1
            while j < n and text[j] != '"':
                if text[j] == "\n":
                    line += 1
                    col_start = j + 1
                j += 1
            if j >= n:
                raise TdbParseError("unterminated string literal", line, i - col_start + 1)
            tokens.append(_Token("STRING", text[i + 1:j], line, i - col_start + 1))
            i = j + 1
            continue
        # Numbers (try number first to handle leading +/-)
        if ch.isdigit() or (ch in "+-" and i + 1 < n and (text[i + 1].isdigit() or text[i + 1] == ".")) \
                or ch == ".":
            m = _NUM_RE.match(text, i)
            if m:
                tokens.append(_Token("NUMBER", m.group(0), line, i - col_start + 1))
                i = m.end()
                continue
        # Words (identifiers / keywords / phase names / species)
        m = _WORD_RE.match(text, i)
        if m:
            tokens.append(_Token("WORD", m.group(0), line, i - col_start + 1))
            i = m.end()
            continue
        # Unknown punctuation — treat as word (e.g. % & * markers used by
        # TYPE_DEF). We accept any single non-whitespace character so that
        # heteroclite TDB dialects don't crash us.
        tokens.append(_Token("WORD", ch, line, i - col_start + 1))
        i += 1

    return tokens


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


# Keyword set with all accepted abbreviations. The SGTE spec allows
# arbitrary truncation of statement names to 3+ characters; we accept the
# common 4-letter forms used in real files plus a couple of long forms.
_KEYWORDS = {
    "DATABASE_INFO": "DATABASE_INFO",
    "DATABASE": "DATABASE_INFO",
    "DEFINE_SYSTEM_DEFAULT": "DEFINE_SYSTEM_DEFAULT",
    "DEFSYSDEF": "DEFINE_SYSTEM_DEFAULT",
    "ELEMENT": "ELEMENT",
    "ELE": "ELEMENT",
    "SPECIES": "SPECIES",
    "SPEC": "SPECIES",
    "PHASE": "PHASE",
    "PHAS": "PHASE",
    "CONSTITUENT": "CONSTITUENT",
    "CONS": "CONSTITUENT",
    "FUNCTION": "FUNCTION",
    "FUNC": "FUNCTION",
    "FUN": "FUNCTION",
    "PARAMETER": "PARAMETER",
    "PARA": "PARAMETER",
    "PAR": "PARAMETER",
    "TYPE_DEFINITION": "TYPE_DEFINITION",
    "TYPE_DEF": "TYPE_DEFINITION",
    "LIST_OF_REFERENCES": "LIST_OF_REFERENCES",
    "REFERENCE_FILE": "LIST_OF_REFERENCES",
    "REFERENCE": "LIST_OF_REFERENCES",
    "ASSESSED_SYSTEMS": "ASSESSED_SYSTEMS",
    "DEFAULT_COMMAND": "DEFAULT_COMMAND",
    "SET_INTERACTIVE": "SET_INTERACTIVE",
}


def _normalize_keyword(word: str) -> Optional[str]:
    """Map a token to a canonical statement keyword (or None)."""

    up = word.upper()
    if up in _KEYWORDS:
        return _KEYWORDS[up]
    # Allow TYPE_DEF written as TYPE-DEF
    if up.replace("-", "_") in _KEYWORDS:
        return _KEYWORDS[up.replace("-", "_")]
    return None


class _Cursor:
    """Forward-only token cursor."""

    __slots__ = ("tokens", "i")

    def __init__(self, tokens: list[_Token]) -> None:
        self.tokens = tokens
        self.i = 0

    @property
    def at_end(self) -> bool:
        return self.i >= len(self.tokens)

    def peek(self) -> _Token:
        return self.tokens[self.i]

    def advance(self) -> _Token:
        t = self.tokens[self.i]
        self.i += 1
        return t

    def collect_until_bang(self) -> list[_Token]:
        """Consume tokens up to (but not including) the next ``!``."""

        out: list[_Token] = []
        while not self.at_end and self.peek().kind != "BANG":
            out.append(self.advance())
        if not self.at_end:
            self.advance()  # skip BANG
        return out


def _expect_word(t: _Token) -> str:
    if t.kind == "WORD":
        return t.value
    raise TdbParseError(f"expected identifier, got {t.kind} {t.value!r}", t.line, t.column)


def _expect_number(t: _Token) -> float:
    if t.kind == "NUMBER":
        # Fortran allows D for exponent — normalise to E
        return float(t.value.replace("D", "E").replace("d", "e"))
    raise TdbParseError(f"expected number, got {t.kind} {t.value!r}", t.line, t.column)


def _split_t_range(expr_tokens: list[_Token]) -> list[tuple[float, float, str]]:
    """Split an expression body into ``(T_low, T_high, expr)`` tuples.

    Many TDB ``FUNCTION`` / ``PARAMETER`` bodies are written as::

        298.15  +124.134 +24.6643*T -8.62 ... ;  6000  N  REF

    Or piecewise::

        298.15  expr1 ;  1811  expr2 ;  6000  N  REF

    We split on top-level ``;`` and pair the first NUMBER of each segment
    with the next segment's first NUMBER. The final segment may be
    terminated by ``N`` (or ``Y``) plus an optional reference string.

    Returns an empty list if no ranges could be detected.
    """

    if not expr_tokens:
        return []

    # Split into segments by SEMI tokens at top level (no nesting today).
    segments: list[list[_Token]] = [[]]
    for tk in expr_tokens:
        if tk.kind == "SEMI":
            segments.append([])
        else:
            segments[-1].append(tk)

    # Filter empties (trailing ; before reference token)
    segments = [s for s in segments if s]
    if not segments:
        return []

    ranges: list[tuple[float, float, str]] = []

    # Typical structure for first piece: [NUMBER T_low, ...expression...]
    # Following piece starts with [NUMBER T_high, ...expression...]
    # Final segment may be just [NUMBER T_high, "N", "REF" ...]
    # Identify the "tail" segment: it starts with a NUMBER (T_max) followed
    # by `N` or `Y` and optional reference tokens. That segment is *not* a
    # range body — it's the terminator. Detect it heuristically: a segment
    # whose tokens after the leading NUMBER are entirely WORD ("N", "Y")
    # and STRING / WORD reference tokens.
    def _is_tail_segment(seg: list[_Token]) -> bool:
        if len(seg) < 2 or seg[0].kind != "NUMBER":
            return False
        body = seg[1:]
        if not body:
            return False
        # Tail body starts with N or Y marker
        first_word = body[0]
        if first_word.kind == "WORD" and first_word.value.upper() in {"N", "Y"}:
            return True
        return False

    n = len(segments)
    for idx, seg in enumerate(segments):
        if not seg:
            continue
        first = seg[0]
        if first.kind != "NUMBER":
            continue
        # Skip the terminator segment — it is not its own range body.
        if idx == n - 1 and _is_tail_segment(seg):
            break
        try:
            t_low = float(first.value.replace("D", "E").replace("d", "e"))
        except ValueError:
            continue
        body_tokens = seg[1:]

        if idx + 1 < n:
            nxt = segments[idx + 1]
            if not nxt:
                t_high = t_low
            else:
                try:
                    t_high = float(nxt[0].value.replace("D", "E").replace("d", "e"))
                except (ValueError, AttributeError):
                    t_high = t_low
        else:
            t_high = t_low

        # If body ends with "N"/"Y" plus optional ref tokens (one-segment
        # case where there is no separate tail), strip it.
        while body_tokens and body_tokens[-1].kind in {"STRING"}:
            body_tokens = body_tokens[:-1]
        if body_tokens and body_tokens[-1].kind == "WORD" \
                and body_tokens[-1].value.upper() in {"N", "Y"}:
            body_tokens = body_tokens[:-1]

        expr_text = " ".join(b.value for b in body_tokens).strip()
        if expr_text:
            ranges.append((t_low, t_high, expr_text))
        elif idx == 0 and n == 1:
            ranges.append((t_low, t_high, str(t_low)))

    return ranges


def _parse_element(cur: _Cursor) -> tuple[str, dict[str, float]]:
    """ELEMENT  name  ref_phase  atomic_weight  H_298  S_298 !

    Some files use shortened forms; we accept whatever's there.
    """

    body = cur.collect_until_bang()
    if not body:
        raise TdbParseError("empty ELEMENT statement")
    name = _expect_word(body[0]).upper()
    data: dict[str, float] = {}
    if len(body) > 1 and body[1].kind == "WORD":
        data["reference_phase"] = body[1].value  # type: ignore[assignment]
    numbers: list[float] = []
    for tk in body[2:]:
        if tk.kind == "NUMBER":
            numbers.append(_expect_number(tk))
    keys = ("atomic_mass", "H298", "S298")
    for k, v in zip(keys, numbers):
        data[k] = v
    return name, data


def _parse_species(cur: _Cursor, known_elements: Iterable[str] = ()) -> Species:
    """SPECIES  name  formula !

    Formula is the chemical formula string with element symbols and
    optional counts (e.g. ``FE``, ``FE3C``, ``O2``, ``CO2``).
    """

    body = cur.collect_until_bang()
    if not body:
        raise TdbParseError("empty SPECIES statement")
    name = _expect_word(body[0]).upper()
    formula_tokens = body[1:]
    formula = "".join(t.value for t in formula_tokens)
    sp = Species(name=name)
    sp.stoichiometry = _parse_formula(formula, known_elements=known_elements)
    return sp


# Two formulas dialects coexist in real TDB files:
#   (a) CamelCase, e.g. Fe3C  →  {Fe: 3, C: 1}
#   (b) ALL-CAPS, e.g. FE3C  →  {FE: 3, C: 1}
# Dialect (a) is unambiguous with [A-Z][a-z]?\d*. Dialect (b) is
# ambiguous (FECR could be Fe+Cr or F+E+CR), so we greedy-match against
# the known element symbols from the parent ELEMENT statements where
# possible, falling back to a CamelCase split.

_CAMEL_RE = re.compile(r"([A-Z][a-z]+|[A-Z])([0-9]*\.?[0-9]*)")


def _parse_formula(formula: str, known_elements: Optional[Iterable[str]] = None) -> dict[str, float]:
    """Parse ``FE3C`` → ``{'FE': 3, 'C': 1}``.

    If ``known_elements`` is given, prefer multi-letter element symbols
    (e.g. ``FE`` vs ``F + E``) by greedy longest match. Otherwise fall
    back to the CamelCase rule ``[A-Z][a-z]?\\d*``.
    """

    out: dict[str, float] = {}
    if not formula:
        return out
    formula = re.sub(r"[+-]\d*$", "", formula.strip())

    # Branch (a): if the formula has any lowercase letter, use CamelCase.
    has_lower = any(c.islower() for c in formula)
    if has_lower:
        for m in _CAMEL_RE.finditer(formula):
            sym, cnt = m.group(1), m.group(2)
            if not sym:
                continue
            n = float(cnt) if cnt else 1.0
            sym_up = sym.upper()
            out[sym_up] = out.get(sym_up, 0.0) + n
        return out

    # Branch (b): all caps. Greedy match against known_elements where
    # available, else fall back to 1-2 letter heuristic.
    elements = sorted({e.upper() for e in (known_elements or [])}, key=lambda x: -len(x))
    i = 0
    n_chars = len(formula)
    while i < n_chars:
        ch = formula[i]
        if not ch.isalpha():
            i += 1
            continue
        matched = None
        for el in elements:
            if formula.startswith(el, i):
                matched = el
                break
        if matched is None:
            # Fallback: assume 1-letter element symbol in ALL-CAPS mode.
            # (FE, CR, NI etc. all get matched via known_elements path.)
            matched = ch
        i += len(matched)
        # Read count
        j = i
        while j < n_chars and (formula[j].isdigit() or formula[j] == "."):
            j += 1
        cnt = formula[i:j]
        n = float(cnt) if cnt else 1.0
        out[matched] = out.get(matched, 0.0) + n
        i = j
    return out


def _parse_phase(cur: _Cursor) -> Phase:
    """PHASE  name  model_codes  n_subl  sites_per_subl... !"""

    body = cur.collect_until_bang()
    if not body:
        raise TdbParseError("empty PHASE statement")
    name = _expect_word(body[0]).upper()

    # Find model_codes — non-NUMBER tokens after the name until first NUMBER
    codes: list[str] = []
    j = 1
    while j < len(body) and body[j].kind != "NUMBER":
        codes.append(body[j].value)
        j += 1

    # n_subl
    if j >= len(body):
        # Some short PHASE declarations omit sites — accept and bail
        return Phase(name=name, model_codes=codes)
    n_subl = int(_expect_number(body[j]))
    j += 1

    sites: list[float] = []
    for k in range(n_subl):
        if j + k < len(body) and body[j + k].kind == "NUMBER":
            sites.append(_expect_number(body[j + k]))
    return Phase(name=name, model_codes=codes, sublattice_sites=sites)


def _parse_constituent(cur: _Cursor, phases: dict[str, Phase]) -> None:
    """CONSTITUENT  phase_name  :  species,species,...  :  species,...  : !

    Sublattices are separated by ``:`` and species within a sublattice by
    ``,``. We accept both an opening and closing ``:``.
    """

    body = cur.collect_until_bang()
    if not body:
        raise TdbParseError("empty CONSTITUENT statement")
    pname = _expect_word(body[0]).upper()
    # Some dialects write CONSTITUENT phase_name :CONSTITUENTS:
    # We split on COLON, then COMMA.
    sublats: list[list[str]] = [[]]
    in_subl = False
    for tk in body[1:]:
        if tk.kind == "COLON":
            if in_subl:
                sublats.append([])
            in_subl = True
            continue
        if tk.kind == "COMMA":
            continue
        if tk.kind == "WORD":
            sublats[-1].append(tk.value.upper())
    # Drop trailing empty sublattice from final ":"
    sublats = [s for s in sublats if s]

    if pname not in phases:
        # Forward-declared phase — store the constituents anyway under a
        # placeholder so later PHASE statements can pick them up.
        phases[pname] = Phase(name=pname)
    phases[pname].constituents = sublats


# ---------------------------------------------------------------------------
# FUNCTION / PARAMETER body parsing
# ---------------------------------------------------------------------------


_PARAM_NAME_RE = re.compile(
    r"""
    ^\s*
    (?P<kind>G|L|TC|BMAGN|BMAG|MQ|GD|MU|VA|V0|VK|VC|VA0|F|TF|H|S|CP|MF|ML)
    \s*
    \(
        (?P<phase>[A-Za-z0-9_+\-#*]+)
        \s*,\s*
        (?P<constituents>.*?)
        \s*
        (?:;\s*(?P<order>\d+))?
    \)
    \s*$
    """,
    re.VERBOSE,
)


def _parse_parameter_name(name: str) -> Optional[tuple[str, str, list[list[str]], int]]:
    """Decompose a name like ``G(BCC_A2,FE)`` or ``L(SIGMA,FE,CR;0)``.

    Returns ``(kind, phase, constituent_array, order)`` or ``None`` on
    malformed name. ``constituent_array`` is a list-per-sublattice.
    Within one sublattice, species are comma-separated. Between
    sublattices the spec uses ``:`` — e.g. ``G(SIGMA,FE:CR)``.
    """

    m = _PARAM_NAME_RE.match(name)
    if not m:
        return None
    phase = m.group("phase").upper()
    kind = m.group("kind").upper()
    order = int(m.group("order")) if m.group("order") is not None else 0
    cons_str = m.group("constituents")
    # Sublattices split on ":", species inside split on ",".
    sublats: list[list[str]] = []
    for sub in cons_str.split(":"):
        species = [s.strip().upper() for s in sub.split(",") if s.strip()]
        if species:
            sublats.append(species)
    return kind, phase, sublats, order


def _parse_function(cur: _Cursor, sys: TdbSystem) -> None:
    """FUNCTION  name  T_low  expr ;  T_high  expr ;  T_max  N  REF !"""

    body = cur.collect_until_bang()
    if not body:
        raise TdbParseError("empty FUNCTION statement")
    name = _expect_word(body[0]).upper()
    ranges = _split_t_range(body[1:])
    if not ranges:
        # Try a permissive fallback: treat the whole body as a single
        # constant-T expression with bounds 1..6000.
        expr_text = " ".join(t.value for t in body[1:]).strip()
        if expr_text:
            ranges = [(1.0, 6000.0, expr_text)]
    sys.functions[name] = ranges


def _parse_parameter(cur: _Cursor, sys: TdbSystem) -> None:
    """PARAMETER  G(phase,A:B;0)  T_low  expr ;  T_high  expr ;  T_max  N  REF !

    The signature ``G(...)`` is consumed as a sequence of tokens; we
    reconstruct it and parse with ``_parse_parameter_name``.
    """

    body = cur.collect_until_bang()
    if not body:
        raise TdbParseError("empty PARAMETER statement")

    # Find the closing RPAREN of the parameter name. The name lives at
    # tokens[0..k] where tokens[k].kind == "RPAREN" and depth returns to 0.
    sig_end = -1
    depth = 0
    for j, tk in enumerate(body):
        if tk.kind == "LPAREN":
            depth += 1
        elif tk.kind == "RPAREN":
            depth -= 1
            if depth == 0:
                sig_end = j
                break
    if sig_end < 0:
        raise TdbParseError("PARAMETER signature missing closing ')'",
                            body[0].line, body[0].column)

    sig_tokens = body[: sig_end + 1]
    sig_str = ""
    for tk in sig_tokens:
        if tk.kind == "WORD" or tk.kind == "NUMBER":
            sig_str += tk.value
        elif tk.kind == "LPAREN":
            sig_str += "("
        elif tk.kind == "RPAREN":
            sig_str += ")"
        elif tk.kind == "COMMA":
            sig_str += ","
        elif tk.kind == "COLON":
            sig_str += ":"
        elif tk.kind == "SEMI":
            sig_str += ";"

    parsed = _parse_parameter_name(sig_str)
    if parsed is None:
        raise TdbParseError(f"unparseable PARAMETER signature {sig_str!r}",
                            body[0].line, body[0].column)
    kind, phase, sublats, order = parsed

    # Body is tokens after the parameter name.
    expr_body = body[sig_end + 1:]
    ranges = _split_t_range(expr_body)

    # Reference: the trailing STRING (or WORD) token after the final SEMI
    # in the raw body (kept by _split_t_range stripping). We re-derive
    # heuristically here: take the last STRING token.
    reference = ""
    for tk in reversed(expr_body):
        if tk.kind == "STRING":
            reference = tk.value
            break

    sys.parameters.append(Parameter(
        kind=kind,
        phase=phase,
        constituents=sublats,
        order=order,
        expression=ranges,
        reference=reference,
    ))


def _parse_type_definition(cur: _Cursor, sys: TdbSystem) -> None:
    """TYPE_DEFINITION  code  body...  !

    Stores the raw expansion under the code character.
    """

    body = cur.collect_until_bang()
    if not body:
        return
    code = body[0].value
    expansion = " ".join(t.value for t in body[1:])
    sys.type_definitions[code] = expansion


def _parse_define_default(cur: _Cursor, sys: TdbSystem) -> None:
    """DEFINE_SYSTEM_DEFAULT  ELEMENT  N !  — record element scope."""

    body = cur.collect_until_bang()
    # We accept a list of element symbols as words.
    elements = [t.value.upper() for t in body if t.kind == "WORD"
                and t.value.upper() not in {"ELEMENT", "SPECIES", "N", "Y"}]
    sys.default_elements = elements


def _parse_database_info(cur: _Cursor, sys: TdbSystem) -> None:
    """DATABASE_INFO  free-form text...  !"""

    body = cur.collect_until_bang()
    if not body:
        return
    parts = [t.value for t in body]
    sys.database_info = (sys.database_info + " " + " ".join(parts)).strip()


def _parse_references(cur: _Cursor, sys: TdbSystem) -> None:
    """LIST_OF_REFERENCES  ...  !  — read pairs of ``key  STRING``."""

    body = cur.collect_until_bang()
    j = 0
    while j < len(body):
        if body[j].kind == "WORD":
            key = body[j].value
            if j + 1 < len(body) and body[j + 1].kind == "STRING":
                sys.references[key] = body[j + 1].value
                j += 2
                continue
        j += 1


def _skip_statement(cur: _Cursor) -> None:
    """Consume one statement (everything up to and including the next !)."""

    cur.collect_until_bang()


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def read_tdb(source: Union[str, Path, bytes, "os.PathLike[str]"]) -> TdbSystem:
    """Parse a TDB file or text.

    Args:
        source: A filesystem path, raw bytes, or a string. Strings whose
            value is *not* a valid path are also accepted as inline TDB
            source (useful for tests).

    Returns:
        A :class:`TdbSystem` data structure with elements, phases,
        parameters, functions, and type-definitions populated.

    Raises:
        TdbParseError: On grammar violations. The exception carries the
            ``line`` / ``column`` of the offending token.

    Example::

        import austenite as au
        system = au.io.read_tdb("SGTE-2024.TDB")
        print(system.elements)   # ['FE', 'CR', 'NI', ...]
        print(system.summary())  # → TdbSystem(elements=7, phases=5, ...)
    """

    text = _load_text(source)
    tokens = _tokenize(text)
    cur = _Cursor(tokens)
    sys = TdbSystem()

    while not cur.at_end:
        t = cur.peek()
        if t.kind != "WORD":
            cur.advance()
            continue
        keyword = _normalize_keyword(t.value)
        if keyword is None:
            # Unknown leading token — skip until next BANG to recover.
            _skip_statement(cur)
            continue
        cur.advance()  # consume keyword token

        if keyword == "ELEMENT":
            name, data = _parse_element(cur)
            sys.elements.append(name)
            sys.element_data[name] = data
            # Implicit species: each element is a species of itself.
            if name not in sys.species:
                sys.species[name] = Species(name=name, stoichiometry={name: 1.0})
        elif keyword == "SPECIES":
            sp = _parse_species(cur, known_elements=sys.elements)
            sys.species[sp.name] = sp
        elif keyword == "PHASE":
            ph = _parse_phase(cur)
            # Preserve forward-declared constituents if any.
            if ph.name in sys.phase_objects:
                ph.constituents = sys.phase_objects[ph.name].constituents
            sys.phase_objects[ph.name] = ph
            if ph.name not in sys.phases:
                sys.phases.append(ph.name)
        elif keyword == "CONSTITUENT":
            _parse_constituent(cur, sys.phase_objects)
            # If CONSTITUENT comes before PHASE we still want the phase
            # listed.
            body_tokens_consumed = False  # already consumed
            del body_tokens_consumed
            # Track names appearing in CONSTITUENT
            for ph_name, ph in sys.phase_objects.items():
                if ph_name not in sys.phases:
                    sys.phases.append(ph_name)
        elif keyword == "FUNCTION":
            _parse_function(cur, sys)
        elif keyword == "PARAMETER":
            _parse_parameter(cur, sys)
        elif keyword == "TYPE_DEFINITION":
            _parse_type_definition(cur, sys)
        elif keyword == "DEFINE_SYSTEM_DEFAULT":
            _parse_define_default(cur, sys)
        elif keyword == "DATABASE_INFO":
            _parse_database_info(cur, sys)
        elif keyword == "LIST_OF_REFERENCES":
            _parse_references(cur, sys)
        else:
            _skip_statement(cur)

    return sys


def write_tdb(system: TdbSystem, path: Union[str, Path, None] = None) -> str:
    """Serialise a :class:`TdbSystem` back to SGTE TDB text.

    Useful for round-trip tests and for emitting a calibrated database
    after a Bayesian refit.

    Args:
        system: The parsed system to serialise.
        path: If given, write to this path. The function still returns
            the text.

    Returns:
        The full TDB text as a string.
    """

    out = io.StringIO()
    if system.database_info:
        out.write(f"$ {system.database_info.strip()}\n")
    if system.default_elements:
        out.write("DEFINE_SYSTEM_DEFAULT ELEMENT " + " ".join(system.default_elements) + " !\n")
    out.write("\n")

    # Elements
    for el in system.elements:
        d = system.element_data.get(el, {})
        ref_phase = d.get("reference_phase", "BLANK") if isinstance(d.get("reference_phase"), str) else "BLANK"
        atomic_mass = d.get("atomic_mass", 0.0)
        H298 = d.get("H298", 0.0)
        S298 = d.get("S298", 0.0)
        out.write(f"ELEMENT  {el}  {ref_phase}  {atomic_mass:.4f}  {H298:.4f}  {S298:.4f} !\n")
    out.write("\n")

    # Species — keep element-only entries implicit (one SPECIES per ELEMENT
    # is automatic on read). Multi-element formulas are written ALL-CAPS.
    for sp in system.species.values():
        if sp.name in system.elements and sp.stoichiometry == {sp.name: 1.0}:
            continue
        parts: list[str] = []
        for el, n in sp.stoichiometry.items():
            if n == 1.0:
                parts.append(el.upper())
            else:
                parts.append(f"{el.upper()}{n:g}")
        formula = "".join(parts)
        out.write(f"SPECIES  {sp.name}  {formula} !\n")
    out.write("\n")

    # Type defs
    for code, expansion in system.type_definitions.items():
        out.write(f"TYPE_DEFINITION  {code}  {expansion} !\n")
    out.write("\n")

    # Phases & constituents
    for ph_name in system.phases:
        ph = system.phase_objects.get(ph_name)
        if ph is None:
            continue
        codes = " ".join(ph.model_codes) if ph.model_codes else "%"
        n_subl = len(ph.sublattice_sites) if ph.sublattice_sites else 1
        sites = " ".join(f"{s:g}" for s in ph.sublattice_sites) or "1"
        out.write(f"PHASE  {ph_name}  {codes}  {n_subl}  {sites} !\n")
        if ph.constituents:
            cs = ":".join(",".join(species) for species in ph.constituents)
            out.write(f"CONSTITUENT {ph_name} :{cs}: !\n")
    out.write("\n")

    # Functions
    for fname, ranges in system.functions.items():
        if not ranges:
            continue
        parts: list[str] = []
        for t_lo, t_hi, expr in ranges:
            parts.append(f"{t_lo:g}  {expr}")
        body = " ; ".join(parts)
        last_t_hi = ranges[-1][1]
        out.write(f"FUNCTION  {fname}  {body} ; {last_t_hi:g}  N !\n")
    out.write("\n")

    # Parameters
    for p in system.parameters:
        cons_str = ":".join(",".join(sp for sp in sub) for sub in p.constituents)
        order_suffix = f";{p.order}" if p.order else ""
        sig = f"{p.kind}({p.phase},{cons_str}{order_suffix})"
        parts: list[str] = []
        for t_lo, t_hi, expr in p.expression:
            parts.append(f"{t_lo:g}  {expr}")
        body = " ; ".join(parts)
        last_t_hi = p.expression[-1][1] if p.expression else 6000.0
        ref = f' "{p.reference}"' if p.reference else ""
        out.write(f"PARAMETER  {sig}  {body} ; {last_t_hi:g}  N{ref} !\n")
    out.write("\n")

    text = out.getvalue()
    if path is not None:
        Path(path).write_text(text, encoding="utf-8")
    return text


def _load_text(source: Union[str, Path, bytes, "os.PathLike[str]"]) -> str:
    """Resolve ``source`` to TDB source text."""

    if isinstance(source, bytes):
        return source.decode("utf-8", errors="replace")
    if isinstance(source, (Path, os.PathLike)):
        return Path(source).read_text(encoding="utf-8", errors="replace")
    if isinstance(source, str):
        # If it looks like a path AND the file exists, read it.
        # Else treat the string as inline TDB content.
        looks_like_path = (
            len(source) < 1024
            and "\n" not in source
            and any(source.lower().endswith(ext) for ext in (".tdb", ".tdb.txt", ".dat"))
        )
        if looks_like_path and os.path.exists(source):
            return Path(source).read_text(encoding="utf-8", errors="replace")
        if "\n" in source or "ELEMENT" in source.upper() or "PHASE" in source.upper() \
                or "FUNCTION" in source.upper() or "PARAMETER" in source.upper():
            return source
        # Fall back: if it's a path on disk, read it.
        if os.path.exists(source):
            return Path(source).read_text(encoding="utf-8", errors="replace")
        return source
    raise TypeError(f"unsupported source type: {type(source).__name__}")
