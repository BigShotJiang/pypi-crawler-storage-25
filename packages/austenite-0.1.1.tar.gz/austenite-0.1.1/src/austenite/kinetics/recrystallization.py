"""Hot-deformation recrystallization (Sellars-Whiteman 1979).

Used in every hot-rolling, forging, and seamless-tube workflow. The
dominant kinetic model since 1979 for predicting:

* **Peak strain** at which dynamic recrystallization (DRX) initiates.
* **Critical strain** below which only static recovery occurs.
* **DRX fraction kinetics** ``X(t)`` via Avrami-form with Z-dependent τ.
* **Zener-Hollomon parameter**: ``Z = ε̇ · exp(Q_def / RT)``.

References:
    * Sellars C.M., Whiteman J.A., Met. Sci. 13 (1979) 187.
    * Sellars C.M., Mater. Sci. Technol. 6 (1990) 1072.
    * Yada H., Suehiro T., ISIJ Int. 35 (1995) 25.
    * Hodgson P.D., Gibbs R.K., ISIJ Int. 32 (1992) 1329 — C-Mn-Nb steels.
    * Beynon J.H., Sellars C.M., ISIJ Int. 32 (1992) 359 — Q_def values.
"""

from __future__ import annotations

import math
from typing import Literal


R_GAS: float = 8.31451


# Calibrated parameters per alloy (Sellars-Whiteman + Hodgson-Gibbs):
# Returns dict with: Q_def_kJ_mol, A_peak, alpha_peak, beta_peak, A_50, n_avrami,
# all from published assessments.
SELLARS_PARAMS: dict[str, dict] = {
    "304L": {
        "Q_def_kJ_mol": 290.0,
        "A_peak": 4.9e-4,  # ε_peak = A_peak · d₀^alpha · Z^beta
        "alpha_peak": 0.30,
        "beta_peak": 0.15,
        "A_50": 1.06,       # τ_50 = A_50 · d₀^p · Z^(-q)
        "p_50": 1.5,
        "q_50": 0.30,
        "n_avrami": 2.0,
        "citation": "Sellars-Whiteman 1979; Mecking-Kocks dataset for 304L.",
    },
    "316L": {
        "Q_def_kJ_mol": 305.0,
        "A_peak": 5.1e-4,
        "alpha_peak": 0.32,
        "beta_peak": 0.16,
        "A_50": 1.1,
        "p_50": 1.5,
        "q_50": 0.32,
        "n_avrami": 2.0,
        "citation": "Sellars 1990; Yada-Suehiro 1995 for austenitic SS.",
    },
    "C-Mn": {
        "Q_def_kJ_mol": 312.0,
        "A_peak": 6.82e-4,
        "alpha_peak": 0.50,
        "beta_peak": 0.13,
        "A_50": 2.0,
        "p_50": 2.0,
        "q_50": 0.40,
        "n_avrami": 2.0,
        "citation": "Hodgson-Gibbs 1992 ISIJ.",
    },
    "Nb-microalloyed": {
        "Q_def_kJ_mol": 375.0,
        "A_peak": 1.0e-4,
        "alpha_peak": 0.50,
        "beta_peak": 0.20,
        "A_50": 4.5,
        "p_50": 2.0,
        "q_50": 0.35,
        "n_avrami": 2.0,
        "citation": "Hodgson-Gibbs 1992; Beynon-Sellars 1992 ISIJ.",
    },
    "Inconel 718": {
        "Q_def_kJ_mol": 423.0,
        "A_peak": 2.9e-4,
        "alpha_peak": 0.27,
        "beta_peak": 0.12,
        "A_50": 0.95,
        "p_50": 1.6,
        "q_50": 0.30,
        "n_avrami": 1.9,
        "citation": "Medeiros et al., Mater. Sci. Eng. A 357 (2003) 167.",
    },
}


def zener_hollomon_parameter(strain_rate_per_s: float, T_K: float, Q_def_kJ_mol: float) -> float:
    """Zener-Hollomon parameter ``Z = ε̇ · exp(Q_def / RT)``.

    Reference: Zener C., Hollomon J.H., J. Appl. Phys. 15 (1944) 22.
    """
    if not all(_is_finite(x) for x in [strain_rate_per_s, T_K, Q_def_kJ_mol]):
        return float("nan")
    if T_K <= 0 or strain_rate_per_s < 0:
        return float("nan")
    Q_J = float(Q_def_kJ_mol) * 1000.0
    try:
        return float(strain_rate_per_s) * math.exp(Q_J / (R_GAS * float(T_K)))
    except OverflowError:
        return float("inf")


def sellars_whiteman_peak_strain(
    d0_um: float,
    Z_per_s: float,
    *,
    alloy: str = "304L",
    A: float | None = None,
    alpha: float | None = None,
    beta: float | None = None,
) -> float:
    """Sellars-Whiteman peak strain for dynamic recrystallization:

    ``ε_peak = A · d_0^α · Z^β``

    Parameters
    ----------
    d0_um: initial austenite grain size, μm.
    Z_per_s: Zener-Hollomon parameter.
    alloy: one of ``SELLARS_PARAMS`` keys, or pass A/α/β directly.

    Reference: Sellars-Whiteman 1979.
    """
    if alloy in SELLARS_PARAMS and (A is None or alpha is None or beta is None):
        p = SELLARS_PARAMS[alloy]
        A = float(p["A_peak"])
        alpha = float(p["alpha_peak"])
        beta = float(p["beta_peak"])
    if not all(_is_finite(x) for x in [d0_um, Z_per_s, A, alpha, beta]):
        return float("nan")
    if d0_um <= 0 or Z_per_s <= 0:
        return float("nan")
    return float(A) * (float(d0_um) ** float(alpha)) * (float(Z_per_s) ** float(beta))


def critical_strain(peak_strain: float, *, ratio: float = 0.8) -> float:
    """Critical strain for DRX initiation: typically ε_c ≈ 0.8 · ε_peak.

    Reference: Sellars-Whiteman 1979; ratio confirmed 0.7-0.85 across
    most steels and Ni alloys.
    """
    if not _is_finite(peak_strain) or peak_strain <= 0:
        return float("nan")
    return float(ratio) * float(peak_strain)


def Xrex_kinetics(
    eps_applied: float,
    eps_peak: float,
    t_s: float,
    *,
    alloy: str = "304L",
    d0_um: float = 100.0,
    Z_per_s: float = 1e12,
    n: float | None = None,
) -> float:
    """Recrystallization fraction X_rex(t) at applied strain ε:

    ``X_rex(t) = 1 − exp(−0.693 · (t / τ_50)^n)``

    where τ_50 = A_50 · d₀^p · Z^(-q) is the time for 50% recrystallization.
    Only valid if ``ε_applied > ε_critical = 0.8 · ε_peak``.

    Returns 0 if applied strain is below critical strain (no DRX initiates).

    Reference: Sellars-Whiteman 1979.
    """
    if not all(_is_finite(x) for x in [eps_applied, eps_peak, t_s, d0_um, Z_per_s]):
        return float("nan")
    if eps_applied < 0.8 * eps_peak:
        return 0.0

    if alloy in SELLARS_PARAMS:
        p = SELLARS_PARAMS[alloy]
        A_50 = float(p["A_50"])
        p_50 = float(p["p_50"])
        q_50 = float(p["q_50"])
        n_v = float(p["n_avrami"]) if n is None else float(n)
    else:
        # Default parameters
        A_50, p_50, q_50 = 1.0, 1.5, 0.3
        n_v = 2.0 if n is None else float(n)

    tau_50 = A_50 * (d0_um ** p_50) * (Z_per_s ** -q_50)
    if tau_50 <= 0:
        return 0.0
    try:
        return min(1.0, max(0.0, 1.0 - math.exp(-0.693 * (float(t_s) / tau_50) ** n_v)))
    except (ValueError, OverflowError):
        return float("nan")


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "SELLARS_PARAMS",
    "zener_hollomon_parameter",
    "sellars_whiteman_peak_strain",
    "critical_strain",
    "Xrex_kinetics",
]
