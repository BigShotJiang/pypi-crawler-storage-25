"""Microstructure-evolution kinetics: recrystallization, grain growth,
precipitation, and dynamic restoration.

Used by every welding HAZ, forging, rolling, additive-manufacturing
post-process, and steel heat-treat workflow. Closes the gap that engineers
identified in the research interviews ("everyone rolls their own JMAK
solver because no library ships one").

Modules:

* :mod:`.jmak` — Johnson-Mehl-Avrami-Kolmogorov 1939 + KJMA modified
  kinetics for isothermal AND non-isothermal transformations
  (Christian's additivity rule).
* :mod:`.grain_growth` — Burke-Turnbull 1952 normal grain growth, Hillert
  1965 mean-field model, Anderson 1989 Potts simulation surrogate,
  Hillert+Sellars second-phase pinning (Zener radius).
* :mod:`.kwn` — Kampmann-Wagner-Numerical 1984 precipitation model for
  nucleation + growth + coarsening (LSW classical + Lifshitz-Slyozov
  reduced).
* :mod:`.recrystallization` — Sellars-Whiteman 1979 hot-deformation
  recrystallization, ZH parameter, peak-strain + critical-strain models.

Public API examples::

    import austenite as au

    # JMAK isothermal transformation
    X = au.kinetics.jmak.fraction_transformed(t_s=600, k=1e-4, n=2.5)
    # X = 0.50

    # Burke-Turnbull grain growth: d² - d_0² = K · t
    d_um = au.kinetics.grain_growth.burke_turnbull(
        d0_um=20, t_s=3600, K_um2_per_s=1.5,
    )

    # Hillert mean-field grain growth (with Zener pinning)
    d_um = au.kinetics.grain_growth.hillert(
        d0_um=20, t_s=3600, K_um2_per_s=1.5,
        zener_pinning_radius_um=15,
    )

    # KWN precipitation: classical LSW coarsening
    r_nm = au.kinetics.kwn.lsw_coarsening(
        r0_nm=5, t_s=3600,
        gamma_J_m2=0.2, V_m_cm3=7.1, c_eq_at_frac=0.01,
        D_m2_per_s=1e-19, T_K=973,
    )

    # Sellars-Whiteman peak strain in hot-deformation
    eps_peak = au.kinetics.recrystallization.sellars_whiteman_peak_strain(
        d0_um=200, Z_per_s=1e12, alloy="304L",
    )

References:
    * Johnson W.A., Mehl R.F., Trans. AIME 135 (1939) 416.
    * Avrami M., J. Chem. Phys. 7 (1939) 1103; 8 (1940) 212; 9 (1941) 177.
    * Kolmogorov A.N., Izv. Akad. Nauk SSSR Ser. Mat. 1 (1937) 355.
    * Christian J.W., "The Theory of Transformations in Metals and
      Alloys" 3rd ed., Pergamon (2002) §10.
    * Burke J.E., Turnbull D., Prog. Met. Phys. 3 (1952) 220.
    * Hillert M., Acta Metall. 13 (1965) 227.
    * Anderson M.P., et al., Acta Metall. 32 (1984) 783; 37 (1989) 1227.
    * Sellars C.M., Whiteman J.A., Met. Sci. 13 (1979) 187.
    * Kampmann R., Wagner R., in "Decomposition of Alloys: the Early
      Stages," Pergamon (1984) p.91.
    * Lifshitz I.M., Slyozov V.V., J. Phys. Chem. Solids 19 (1961) 35.
    * Wagner C., Z. Elektrochem. 65 (1961) 581.
    * Smith C.S., Trans. AIME 175 (1948) 15 — Zener pinning.
"""

from __future__ import annotations

from .jmak import (
    fraction_transformed,
    fraction_transformed_non_isothermal,
    fit_jmak_avrami_exponent,
    avrami_classical_exponents,
)
from .grain_growth import (
    burke_turnbull,
    hillert,
    grain_growth_with_temperature,
    zener_pinning_radius,
)
from .kwn import (
    lsw_coarsening,
    bm_growth_rate,
    nucleation_rate_classical,
)
from .recrystallization import (
    sellars_whiteman_peak_strain,
    zener_hollomon_parameter,
    critical_strain,
    Xrex_kinetics,
)

__all__ = [
    # JMAK
    "fraction_transformed",
    "fraction_transformed_non_isothermal",
    "fit_jmak_avrami_exponent",
    "avrami_classical_exponents",
    # Grain growth
    "burke_turnbull",
    "hillert",
    "grain_growth_with_temperature",
    "zener_pinning_radius",
    # KWN precipitation
    "lsw_coarsening",
    "bm_growth_rate",
    "nucleation_rate_classical",
    # Hot-deformation recrystallization
    "sellars_whiteman_peak_strain",
    "zener_hollomon_parameter",
    "critical_strain",
    "Xrex_kinetics",
]
