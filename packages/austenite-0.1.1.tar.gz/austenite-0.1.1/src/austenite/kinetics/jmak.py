"""Johnson-Mehl-Avrami-Kolmogorov (JMAK) transformation kinetics.

The single most-used kinetic model in physical metallurgy. Computes the
volume fraction of a new phase ``X(t)`` from nucleation + growth assumptions:

    X(t) = 1 − exp(−k · t^n)

where ``n`` is the Avrami exponent (combination of nucleation mode + growth
dimensionality) and ``k`` is an Arrhenius rate constant.

Implements both:

* **Isothermal** transformation — direct closed-form X(t).
* **Non-isothermal** transformation — Christian's additivity rule:
  ``∫ dt / τ(T(t)) = constant`` for a given X.

Avrami-exponent classical values (Christian 2002 Ch. 12):

================================================  ==========
  Nucleation × Growth                              ``n``
================================================  ==========
  Site-saturation, 3D growth                       3.0
  Constant nucleation, 3D growth                   4.0
  Diffusion-controlled, 3D growth                  1.5
  Diffusion-controlled, constant nucleation        2.5
  Pearlite (2D growth from grain boundaries)       2.0
  Bainite (modified site-saturation)               1.0-1.5
  Cellular precipitation (1D thick)                1.0
================================================  ==========

References:
    * Johnson W.A., Mehl R.F., Trans. AIME 135 (1939) 416.
    * Avrami M., J. Chem. Phys. 7 (1939) 1103; 8 (1940) 212; 9 (1941) 177.
    * Kolmogorov A.N., Izv. Akad. Nauk SSSR Ser. Mat. 1 (1937) 355.
    * Christian J.W., "Theory of Transformations in Metals and Alloys"
      3rd ed., Pergamon (2002) §10-12.
    * Cahn J.W., Acta Metall. 4 (1956) 449 — grain-boundary nucleation.
    * Scheil E., Z. Metallkd. 70 (1979) 168 — additivity rule for CCT.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Sequence


def fraction_transformed(t_s: float, k: float, n: float) -> float:
    """JMAK fraction transformed: ``X(t) = 1 − exp(−k · t^n)``.

    Parameters
    ----------
    t_s: time in seconds (or any unit consistent with k).
    k: rate constant; has units of time^(−n).
    n: Avrami exponent (typically 1-4).

    Returns
    -------
    X ∈ [0, 1]. Clamped if numerical noise produces > 1 or < 0.
    """
    if not _is_finite(t_s) or t_s <= 0:
        return 0.0
    if not _is_finite(k) or not _is_finite(n):
        return float("nan")
    try:
        exponent = float(k) * (float(t_s) ** float(n))
        if exponent < 0:
            return 0.0
        if exponent > 700:  # exp(-700) underflows but X→1
            return 1.0
        return min(1.0, max(0.0, 1.0 - math.exp(-exponent)))
    except (ValueError, OverflowError):
        return float("nan")


def fraction_transformed_non_isothermal(
    T_history_K: Sequence[float],
    t_history_s: Sequence[float],
    *,
    k_arrhenius_prefactor: float,
    activation_energy_kJ_mol: float,
    n: float,
) -> float:
    """JMAK fraction transformed under varying T(t) via Scheil's additivity.

    For an Arrhenius rate ``k(T) = k_0 · exp(−Q/RT)``, integrate the
    consumed fraction along the cooling path:

        Φ(t) = ∫_0^t [k(T(τ))]^(1/n) dτ
        X(t) = 1 − exp(−Φ(t)^n)

    Parameters
    ----------
    T_history_K, t_history_s: parallel arrays of T(t).
    k_arrhenius_prefactor: pre-exponential ``k_0`` (s^(−n)).
    activation_energy_kJ_mol: ``Q`` in kJ/mol.
    n: Avrami exponent.

    Reference: Scheil 1979; Christian 2002 §11.
    """
    if len(T_history_K) != len(t_history_s) or len(T_history_K) < 2:
        return float("nan")
    if not _is_finite(k_arrhenius_prefactor) or not _is_finite(activation_energy_kJ_mol):
        return float("nan")
    if not _is_finite(n) or n <= 0:
        return float("nan")

    Q_J = float(activation_energy_kJ_mol) * 1000.0
    R = 8.314  # J/mol/K
    Phi = 0.0
    one_over_n = 1.0 / float(n)

    for i in range(len(t_history_s) - 1):
        T_a = float(T_history_K[i])
        T_b = float(T_history_K[i + 1])
        dt = float(t_history_s[i + 1]) - float(t_history_s[i])
        if dt <= 0 or T_a <= 0 or T_b <= 0:
            continue
        # Use mean T for the segment (trapezoidal)
        T_mid = 0.5 * (T_a + T_b)
        k_T = float(k_arrhenius_prefactor) * math.exp(-Q_J / (R * T_mid))
        if k_T < 0:
            k_T = 0.0
        Phi += (k_T ** one_over_n) * dt

    if Phi <= 0:
        return 0.0
    exponent = Phi ** float(n)
    if exponent > 700:
        return 1.0
    return min(1.0, max(0.0, 1.0 - math.exp(-exponent)))


def fit_jmak_avrami_exponent(
    t_s: Sequence[float], X: Sequence[float],
) -> tuple[float, float]:
    """Fit the Avrami exponent ``n`` and ``k`` from (t, X) data.

    Uses the linearised Avrami plot:
        log(−log(1 − X)) = n · log(t) + log(k)

    Returns
    -------
    (n, k) — best-fit Avrami exponent and rate constant.

    Drops points where X ≤ 0 or X ≥ 1 (logarithm undefined).
    """
    pts: list[tuple[float, float]] = []
    for ti, Xi in zip(t_s, X):
        if not _is_finite(ti) or ti <= 0:
            continue
        if not _is_finite(Xi) or Xi <= 1e-6 or Xi >= 1 - 1e-6:
            continue
        log_t = math.log(ti)
        log_loglog = math.log(-math.log(1.0 - Xi))
        pts.append((log_t, log_loglog))

    if len(pts) < 2:
        return float("nan"), float("nan")

    # Linear least squares
    n_pts = len(pts)
    sx = sum(p[0] for p in pts)
    sy = sum(p[1] for p in pts)
    sxx = sum(p[0] * p[0] for p in pts)
    sxy = sum(p[0] * p[1] for p in pts)
    mean_x = sx / n_pts
    mean_y = sy / n_pts
    denom = sxx - n_pts * mean_x * mean_x
    if abs(denom) < 1e-12:
        return float("nan"), float("nan")
    slope = (sxy - n_pts * mean_x * mean_y) / denom
    intercept = mean_y - slope * mean_x
    return slope, math.exp(intercept)


def avrami_classical_exponents() -> dict[str, float]:
    """Return the classical Avrami exponents for common nucleation+growth
    modes (Christian 2002 Ch. 12 Table 1)."""
    return {
        "site-saturation-3D": 3.0,
        "constant-nucleation-3D": 4.0,
        "diffusion-controlled-3D": 1.5,
        "diffusion-controlled-constant-nuc": 2.5,
        "pearlite-2D-GB-nucleated": 2.0,
        "bainite-site-saturation": 1.2,
        "cellular-1D": 1.0,
        "martensite-athermal": 0.0,  # not really JMAK; treated as athermal
        "spinodal-decomposition": 0.5,
    }


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "fraction_transformed",
    "fraction_transformed_non_isothermal",
    "fit_jmak_avrami_exponent",
    "avrami_classical_exponents",
]
