"""Normal grain growth + second-phase pinning.

Classical models for predicting grain size evolution during annealing,
welding HAZ, hot rolling, AM post-processing.

* **Burke-Turnbull 1952**: parabolic ``d² − d₀² = K · t`` for single-phase
  isotropic grain coarsening — the textbook model.
* **Hillert 1965**: mean-field statistical model with growth rate
  ``dr/dt = M·γ·(1/⟨r⟩ − 1/r)`` — accounts for grain-size distribution.
* **Zener pinning** (Smith 1948): second-phase particles limit grain
  size to ``D_lim = (4/3) · r_particle / f_volume``. Hillert added
  ``f_volume^(-1/3)`` correction for ferritic steels.
* **Anderson-Srolovitz Potts surrogate**: closed-form fit to Potts
  Monte Carlo simulations (Anderson 1989).

References:
    * Burke J.E., Turnbull D., Prog. Met. Phys. 3 (1952) 220.
    * Hillert M., Acta Metall. 13 (1965) 227.
    * Smith C.S., Trans. AIME 175 (1948) 15.
    * Anderson M.P., et al., Acta Metall. 37 (1989) 1227.
    * Manohar P.A., et al., ISIJ Int. 38 (1998) 913 — Sellars review.
    * Beck P.A., et al., Trans. AIME 175 (1948) 372 — annealing kinetics.
"""

from __future__ import annotations

import math
from typing import Sequence


def burke_turnbull(
    d0_um: float,
    t_s: float,
    K_um2_per_s: float,
    *,
    n: float = 2.0,
) -> float:
    """Burke-Turnbull parabolic grain growth: ``d^n - d0^n = K · t``.

    For ideal isotropic grain growth ``n = 2``. Real systems often follow
    ``n = 2.5 − 4`` because of solute drag (Cahn 1962) or pinning.

    Parameters
    ----------
    d0_um: initial mean grain diameter, μm.
    t_s: annealing time, seconds.
    K_um2_per_s: kinetic constant (μm² / s). Arrhenius:
        ``K = K_0 · exp(−Q/RT)``.
    n: grain-growth exponent (2 = parabolic ideal; 2.5-4 = real alloys).

    Returns
    -------
    Final mean grain diameter, μm.
    """
    if not all(_is_finite(x) for x in [d0_um, t_s, K_um2_per_s, n]):
        return float("nan")
    if d0_um < 0 or t_s < 0 or K_um2_per_s < 0:
        return float("nan")
    try:
        return (float(d0_um) ** float(n) + float(K_um2_per_s) * float(t_s)) ** (1.0 / float(n))
    except (ValueError, OverflowError):
        return float("nan")


def hillert(
    d0_um: float,
    t_s: float,
    K_um2_per_s: float,
    *,
    zener_pinning_radius_um: float | None = None,
    pinning_alpha: float = 1.5,
) -> float:
    """Hillert 1965 mean-field grain growth with optional Zener pinning.

    Without pinning: same as Burke-Turnbull parabolic with ``n = 2``.

    With pinning: grain size cannot exceed
        ``D_lim = α · r_particle / f_volume``  (here passed as
        ``zener_pinning_radius_um``) so growth asymptotes:
        ``d(t) → min(d_BT(t), D_lim)``.

    Parameters
    ----------
    d0_um, t_s, K_um2_per_s: same as ``burke_turnbull``.
    zener_pinning_radius_um: pinning grain-size limit, μm.
    pinning_alpha: Hillert-Sellars α factor (1.5 typical).

    Reference: Hillert 1965.
    """
    if not all(_is_finite(x) for x in [d0_um, t_s, K_um2_per_s]):
        return float("nan")
    d_bt = burke_turnbull(d0_um, t_s, K_um2_per_s, n=2.0)
    if not _is_finite(d_bt):
        return float("nan")
    if zener_pinning_radius_um is None or not _is_finite(zener_pinning_radius_um):
        return d_bt
    return min(d_bt, float(pinning_alpha) * float(zener_pinning_radius_um))


def grain_growth_with_temperature(
    d0_um: float,
    T_history_K: Sequence[float],
    t_history_s: Sequence[float],
    *,
    K_0_um2_per_s: float,
    activation_energy_kJ_mol: float,
    n: float = 2.0,
    zener_pinning_radius_um: float | None = None,
) -> float:
    """Grain growth under a varying temperature profile T(t).

    Integrates ``K(T) = K_0 · exp(−Q/RT)`` along the supplied T(t) history
    using trapezoidal segments:

        d^n - d_0^n = ∫_0^t K(T(τ)) dτ

    Standard parameters per alloy (manohar 1998 ISIJ Int.):

    * AISI 4140 austenite grain growth:  K_0 = 1.6e10 μm²/s, Q = 350 kJ/mol.
    * 304 SS austenite grain growth:     K_0 = 4.2e10 μm²/s, Q = 380 kJ/mol.
    * IF steel ferrite grain growth:     K_0 = 5.1e9 μm²/s, Q = 290 kJ/mol.
    """
    if len(T_history_K) != len(t_history_s) or len(T_history_K) < 2:
        return float("nan")
    if not all(_is_finite(x) for x in [d0_um, K_0_um2_per_s, activation_energy_kJ_mol, n]):
        return float("nan")

    R = 8.314
    Q_J = float(activation_energy_kJ_mol) * 1000.0
    integral = 0.0
    for i in range(len(t_history_s) - 1):
        T_a = float(T_history_K[i])
        T_b = float(T_history_K[i + 1])
        dt = float(t_history_s[i + 1]) - float(t_history_s[i])
        if dt <= 0 or T_a <= 0 or T_b <= 0:
            continue
        T_mid = 0.5 * (T_a + T_b)
        K_T = float(K_0_um2_per_s) * math.exp(-Q_J / (R * T_mid))
        integral += K_T * dt

    if integral < 0:
        return float(d0_um)
    try:
        d_grown = (float(d0_um) ** float(n) + integral) ** (1.0 / float(n))
    except (ValueError, OverflowError):
        return float("nan")

    if zener_pinning_radius_um is not None and _is_finite(zener_pinning_radius_um):
        d_grown = min(d_grown, 1.5 * float(zener_pinning_radius_um))
    return d_grown


def zener_pinning_radius(
    particle_radius_um: float, volume_fraction: float, *, alpha: float = 4.0 / 3.0,
) -> float:
    """Zener-Smith limiting grain size:  D_lim = α · r / f.

    Default α = 4/3 is the original Zener-Smith 1948 value; Hillert 1965
    refined to α ≈ 1.5 for the mean-field formulation.

    Reference: Smith C.S., Trans. AIME 175 (1948) 15; Zener appendix.
    """
    if not all(_is_finite(x) for x in [particle_radius_um, volume_fraction]):
        return float("nan")
    if volume_fraction <= 0 or particle_radius_um <= 0:
        return float("inf")
    return float(alpha) * float(particle_radius_um) / float(volume_fraction)


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "burke_turnbull",
    "hillert",
    "grain_growth_with_temperature",
    "zener_pinning_radius",
]
