"""Kampmann-Wagner-Numerical (KWN) precipitation model + LSW coarsening.

Used by every superalloy / Al-Cu-Mg / HSLA steel design workflow to predict
precipitate size distribution after aging treatment.

* **Classical nucleation rate** (Becker-Döring 1935, Volmer-Weber 1926):

      J* = N_v · Z · β* · exp(−ΔG* / kT)

  where ΔG* = (16π/3) · γ³ / ΔG_v² is the nucleation barrier.

* **Becker-Markvardsen-Christian classical growth rate** for a diffusing
  solute:

      dr/dt = (D / r) · (c̄ − c_eq(r)) / (c_p − c_eq(r))

  with Gibbs-Thomson capillary correction for c_eq(r).

* **Lifshitz-Slyozov-Wagner (LSW) classical coarsening**: ``r³ − r_0³ =
  K_LSW · t`` with ``K_LSW = (8/9) · γ · V_m² · c_eq · D / (R T)``.

References:
    * Kampmann R., Wagner R., in "Decomposition of Alloys: the Early
      Stages," Pergamon (1984) p.91.
    * Lifshitz I.M., Slyozov V.V., J. Phys. Chem. Solids 19 (1961) 35.
    * Wagner C., Z. Elektrochem. 65 (1961) 581.
    * Becker R., Döring W., Ann. Phys. 416 (1935) 719.
    * Volmer M., Weber A., Z. Phys. Chem. 119 (1926) 277.
    * Russell K.C., Adv. Colloid Interface Sci. 13 (1980) 205.
    * Robson J.D., Acta Mater. 52 (2004) 4669 — KWN review.
    * Kuehmann C.J., Voorhees P.W., Metall. Mater. Trans. A 27 (1996)
      937 — generalized LSW for multicomponent.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


K_B: float = 1.380649e-23  # Boltzmann constant J/K
N_A: float = 6.02214076e23  # Avogadro J/mol/K = R / k_B
R_GAS: float = 8.31451


def lsw_coarsening(
    r0_nm: float,
    t_s: float,
    *,
    gamma_J_m2: float,
    V_m_cm3: float,
    c_eq_at_frac: float,
    D_m2_per_s: float,
    T_K: float,
) -> float:
    """Lifshitz-Slyozov-Wagner classical coarsening law.

    ``r³(t) − r₀³ = K_LSW · t``  with
    ``K_LSW = (8/9) · γ · V_m² · c_eq · D / (R · T)``.

    Parameters
    ----------
    r0_nm: initial mean precipitate radius, nm.
    t_s: aging time, s.
    gamma_J_m2: precipitate/matrix interfacial energy, J/m². Typical:
        γ′-Ni3Al on γ-Ni: ~0.020 J/m².  θ-Al2Cu on α-Al: ~0.30 J/m².
        cementite Fe3C on ferrite: ~0.5 J/m².
    V_m_cm3: molar volume of precipitate, cm³/mol. Typical: 7.1 cm³/mol
        for Ni3Al; 10.5 for Al2Cu; 7.7 for Fe3C.
    c_eq_at_frac: equilibrium solute mole fraction in matrix.
    D_m2_per_s: solute diffusivity in matrix at T, m²/s.
    T_K: aging temperature, K.

    Returns
    -------
    Final mean precipitate radius, nm.

    Reference: Lifshitz-Slyozov 1961, Wagner 1961.
    """
    if not all(_is_finite(x) for x in [r0_nm, t_s, gamma_J_m2, V_m_cm3, c_eq_at_frac, D_m2_per_s, T_K]):
        return float("nan")
    if T_K <= 0 or V_m_cm3 <= 0 or D_m2_per_s < 0:
        return float("nan")
    V_m_m3 = float(V_m_cm3) * 1e-6
    K_LSW = (8.0 / 9.0) * float(gamma_J_m2) * V_m_m3 ** 2 * float(c_eq_at_frac) \
            * float(D_m2_per_s) / (R_GAS * float(T_K))
    K_LSW_nm3_per_s = K_LSW * 1e27  # m³ → nm³ (radius cubed)
    return (float(r0_nm) ** 3 + K_LSW_nm3_per_s * float(t_s)) ** (1.0 / 3.0)


def bm_growth_rate(
    r_nm: float,
    *,
    c_bulk_at_frac: float,
    c_eq_inf_at_frac: float,
    c_precipitate_at_frac: float,
    D_m2_per_s: float,
    capillary_length_nm: float | None = None,
) -> float:
    """Becker-Markvardsen-Christian growth rate of one precipitate radius:

    ``dr/dt = (D / r) · (c̄ − c_eq(r)) / (c_p − c_eq(r))``

    With Gibbs-Thomson capillary correction:
    ``c_eq(r) = c_eq(∞) · exp(l_c / r) ≈ c_eq(∞) · (1 + l_c/r)``.

    Parameters
    ----------
    r_nm: current radius (nm).
    c_bulk_at_frac: bulk solute mole-fraction in matrix.
    c_eq_inf_at_frac: equilibrium solute mole-fraction at flat interface.
    c_precipitate_at_frac: solute mole-fraction inside precipitate.
    D_m2_per_s: diffusivity in matrix.
    capillary_length_nm: Gibbs-Thomson capillary length
        ``l_c = 2·γ·V_m / (R·T)``. If None, uses 0.5 nm typical.

    Returns
    -------
    dr/dt in nm/s.
    """
    if not all(_is_finite(x) for x in [r_nm, c_bulk_at_frac, c_eq_inf_at_frac,
                                       c_precipitate_at_frac, D_m2_per_s]):
        return float("nan")
    if r_nm <= 0:
        return float("nan")
    lc = float(capillary_length_nm) if capillary_length_nm and _is_finite(capillary_length_nm) else 0.5
    c_eq_r = float(c_eq_inf_at_frac) * (1.0 + lc / float(r_nm))
    driving = (float(c_bulk_at_frac) - c_eq_r) / max(1e-12, float(c_precipitate_at_frac) - c_eq_r)
    # D in m²/s, r in nm: dr/dt = D/r → (m²/s) / m → m/s. Convert to nm/s.
    D_nm2_per_s = float(D_m2_per_s) * 1e18  # m² → nm²
    return D_nm2_per_s * driving / float(r_nm)


def nucleation_rate_classical(
    *,
    T_K: float,
    delta_G_v_J_m3: float,
    interfacial_energy_J_m2: float,
    site_density_per_m3: float = 1e29,
    attachment_freq_per_s: float = 1e13,
    zeldovich_factor: float = 0.01,
) -> float:
    """Becker-Döring classical nucleation rate for spherical precipitates.

    ``J* = N_v · Z · β* · exp(−ΔG* / kT)``

    where ``ΔG* = (16π/3) · γ³ / ΔG_v²`` is the critical nucleation barrier.

    Parameters
    ----------
    T_K: temperature, K.
    delta_G_v_J_m3: bulk Gibbs-energy driving force per unit volume of
        precipitate (always negative; absolute value matters here).
    interfacial_energy_J_m2: γ in J/m².
    site_density_per_m3: ``N_v`` heterogeneous nucleation site density.
        Default 1e29 ≈ all atoms; lower for GB-nucleated.
    attachment_freq_per_s: ``β*``, typically ~10¹³ Hz.
    zeldovich_factor: ``Z``, typically 0.01-0.1.

    Returns
    -------
    Nucleation rate per m³ per s.
    """
    if not all(_is_finite(x) for x in [T_K, delta_G_v_J_m3, interfacial_energy_J_m2,
                                       site_density_per_m3, attachment_freq_per_s,
                                       zeldovich_factor]):
        return float("nan")
    if T_K <= 0 or delta_G_v_J_m3 == 0:
        return float("nan")
    delta_G_star = (16.0 * math.pi / 3.0) * (float(interfacial_energy_J_m2) ** 3) / (delta_G_v_J_m3 ** 2)
    exp_arg = -delta_G_star / (K_B * float(T_K))
    if exp_arg < -700:
        return 0.0
    return (float(site_density_per_m3) * float(zeldovich_factor)
            * float(attachment_freq_per_s) * math.exp(exp_arg))


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "lsw_coarsening",
    "bm_growth_rate",
    "nucleation_rate_classical",
]
