"""Pure-Python API 579-1 / ASME FFS-1 fitness-for-service engine — offline.

Port of the TypeScript engine at ``apps/web/src/lib/ffs/`` and
``apps/web/src/lib/fracture-pro/`` to a deterministic numpy + scipy
implementation so ``au.ffs.api_579_part_5 / part_6 / part_9`` can be
evaluated entirely **OFFLINE** when ``AUSTENITE_OFFLINE=1`` or when the
HTTP path is unreachable.

Scope
-----
* **Part 5 — general metal loss** with Level-1 / Level-2 RSF cascade
  (Folias §4.4.3.3 LTA overlay), Level-3 limit-load.
* **Part 6 — pitting** with density-class screening, equivalent metal
  loss, RSF.
* **Part 9 — crack-like flaw**: Failure Assessment Diagram (FAD) Level-2A
  with Newman-Raju 1982 K solutions for surface / through / corner cracks,
  Annex 9E weld-residual-stress (WRS) overlay, BS 7910:2019 reserve
  factor by bisection.
* **Fracture-pro auxiliaries**:
  - :func:`lame_hoop_long_stress` — Lamé 1852 thick-walled cylinder.
  - :func:`t_min_thinning` — ASME VIII Div 1 UG-27 min wall.
  - :func:`fad_curve_level_2A` — Level-2A FAD curve from API 579-1 §9.4.
  - :func:`lbb_wuthrich_COD` — Wüthrich 1982 leak-before-break COD.
  - :func:`wrs_profile_api579_9e` — Annex 9E weld-residual-stress profile.
  - :func:`hic_nace_TM0284_severity` — NACE TM0284 hydrogen-induced
    cracking severity class.

References
----------
* API 579-1 / ASME FFS-1 (2021 + 2024 editions).
* ASME BPVC Section VIII Division 1 (2021) UG-27.
* BS 7910:2019 — assessment of flaws in metallic structures.
* Newman, J. C.; Raju, I. S. *NASA TM-83200* (1982) — K solutions for
  surface / corner / through-thickness cracks.
* Kiefner, J. F.; Vieth, P. H. *PRCI PR-3-805* (1989) — modified B31G /
  RSTRENG remaining-strength factor.
* Folias, E. S. *Int. J. Fracture Mech.* 1 (1965) 104 — bulging factor.
* Wüthrich, C. *Eng. Fract. Mech.* 16 (1982) 757 — crack-mouth opening
  displacement for leak-before-break analysis.
* Anderson, T. L. *Fracture Mechanics* 4th ed. (2017) §11.5.
* Kowaka, M. *Life Prediction of Industrial Plant Materials* (1994).
* NACE TM0284-2016 — HIC severity classification.
* Yan, A.; Crowe, C. *Corros. Sci.* 137 (2018) 65 — sour-service ASTM
  G129 SSC threshold.
* ASME B31G-2012 — remaining strength of corroded pipelines.

A Javanshir Hasanov production.
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Optional, Sequence

import numpy as np


# ---------------------------------------------------------------------------
# Allowable-stress lookups — coarse mid-temperature snapshot of ASME II-D
# (exact match to the TS engine at ~200 °C). Used when the caller does not
# supply explicit Sy/Suts/S values.
# ---------------------------------------------------------------------------

DEFAULT_S_ALLOW_BY_SPEC: dict[str, dict[str, float]] = {
    "SA-516-70":  {"S_MPa": 138, "Sy_MPa": 260, "Suts_MPa": 485},
    "SA-106-B":   {"S_MPa": 118, "Sy_MPa": 240, "Suts_MPa": 415},
    "SA-335-P22": {"S_MPa": 118, "Sy_MPa": 207, "Suts_MPa": 415},
    "SA-335-P91": {"S_MPa": 167, "Sy_MPa": 415, "Suts_MPa": 585},
    "SA-240-304": {"S_MPa": 117, "Sy_MPa": 205, "Suts_MPa": 515},
    "SA-240-316": {"S_MPa": 119, "Sy_MPa": 205, "Suts_MPa": 515},
    "SA-105":     {"S_MPa": 138, "Sy_MPa": 250, "Suts_MPa": 485},
    "API-5L-X65": {"S_MPa": 200, "Sy_MPa": 448, "Suts_MPa": 530},
}


# ---------------------------------------------------------------------------
# Lamé 1852 thick-walled cylinder stresses
# ---------------------------------------------------------------------------


def lame_hoop_long_stress(P_MPa: float, OD_mm: float, ID_mm: float) -> tuple[float, float]:
    """Lamé 1852 thick-walled cylinder hoop + longitudinal stresses (MPa).

    For internal pressure ``P`` (gauge), outer diameter ``OD``, inner
    diameter ``ID``:

    ``σ_hoop(r) = P·(R_i² · (R_o²/r² + 1)) / (R_o² − R_i²)``
    ``σ_long = P·R_i² / (R_o² − R_i²)``  (closed-end / open-end equiv)

    Hoop is evaluated at the inner surface (max). Both values are returned
    in MPa, suitable for direct comparison with allowable stress S.

    Args:
        P_MPa: internal pressure, MPa (gauge).
        OD_mm: outer diameter, mm.
        ID_mm: inner diameter, mm.

    Returns:
        (sigma_hoop_MPa, sigma_long_MPa).
    """

    if OD_mm <= ID_mm or ID_mm <= 0:
        raise ValueError(f"Invalid geometry: OD={OD_mm} mm must exceed ID={ID_mm} mm > 0.")
    Ro = OD_mm / 2.0
    Ri = ID_mm / 2.0
    denom = Ro * Ro - Ri * Ri
    # Hoop at inner radius: σ_h = P(Ri²)(Ro² + Ri²) / (Ri² (Ro² − Ri²)) = P(Ro²+Ri²)/(Ro²-Ri²)
    sigma_hoop = P_MPa * (Ro * Ro + Ri * Ri) / denom
    # Longitudinal (closed-end): σ_l = P·Ri² / (Ro²−Ri²)
    sigma_long = P_MPa * Ri * Ri / denom
    return float(sigma_hoop), float(sigma_long)


# ---------------------------------------------------------------------------
# Minimum-wall thickness (ASME VIII Div 1 UG-27)
# ---------------------------------------------------------------------------


def t_min_thinning(
    P_MPa: float,
    R_mm: float,
    S_MPa: float,
    edition: str = "API 579-1 2021-12",
    joint_efficiency: float = 1.0,
    geom: str = "cylinder",
) -> float:
    """ASME VIII Div 1 UG-27 minimum-wall thickness for thinning-only.

    For a cylinder, ``t_min = P · R_i / (S · E − 0.6 · P)``.
    For a sphere, ``t_min = P · R_i / (2 · S · E − 0.2 · P)``.

    The edition tag is echoed verbatim for the audit trail but does not
    change numerics (no UG-27 formula change between 2021 and 2024).

    Args:
        P_MPa: design pressure, MPa.
        R_mm: inside radius, mm.
        S_MPa: allowable stress, MPa.
        edition: API 579-1 edition string.
        joint_efficiency: weld joint efficiency E (default 1.0).
        geom: ``'cylinder'`` (default) or ``'sphere'``.

    Returns:
        t_min in mm.
    """

    E = float(joint_efficiency)
    if geom == "sphere":
        denom = 2 * S_MPa * E - 0.2 * P_MPa
    else:
        denom = S_MPa * E - 0.6 * P_MPa
    if denom <= 0:
        return math.inf
    return float(P_MPa * R_mm / denom)


# ---------------------------------------------------------------------------
# FAD Level-2A curve
# ---------------------------------------------------------------------------


def fad_curve_level_2A(L_r: float, L_r_max: Optional[float] = None) -> float:
    """API 579-1 §9.4 Level-2A FAD curve K_r(L_r).

    ``K_r = (1 − 0.14 L_r²) · (0.3 + 0.7 exp(−0.65 L_r⁶))``  for L_r ≤ L_r_max,
    K_r = 0 beyond cutoff (plastic collapse).

    Args:
        L_r: ratio of reference stress to yield (σ_ref / Sy).
        L_r_max: plastic-collapse cutoff. If None, no cutoff is applied.

    Returns:
        K_r value on the FAD curve, dimensionless.
    """

    if L_r_max is not None and L_r > L_r_max:
        return 0.0
    return float((1.0 - 0.14 * L_r * L_r) * (0.3 + 0.7 * math.exp(-0.65 * (L_r ** 6))))


# ---------------------------------------------------------------------------
# Annex 9E weld-residual-stress profile
# ---------------------------------------------------------------------------


def wrs_profile_api579_9e(
    weld_type: str,
    distance_from_centerline_mm: float,
    wall_mm: float = 25.0,
    sigma_y_MPa: float = 350.0,
) -> float:
    """Annex 9E weld-residual-stress (WRS) profile, MPa.

    Closed-form bounding envelopes from API 579-1 Annex 9E Table 9E-2 for
    ``'circumferential-butt'`` and ``'longitudinal-butt'`` weld geometries.

    The profile is roughly tensile (≈ +σ_y) at the weld centreline,
    decays exponentially over ~2·wall_mm to the parent metal, where it
    crosses through zero and reaches a compressive plateau at ~30 % σ_y
    at the heat-affected zone limit (~5·wall_mm), then decays to zero
    in the parent material.

    Args:
        weld_type: ``'circumferential-butt'`` or ``'longitudinal-butt'``.
        distance_from_centerline_mm: distance d from weld centreline (mm).
        wall_mm: shell wall thickness (mm), default 25.
        sigma_y_MPa: parent metal yield strength (MPa), default 350.

    Returns:
        Residual stress in MPa (tensile positive). Magnitude bounded to
        ±σ_y per Annex 9E.
    """

    d = abs(distance_from_centerline_mm)
    decay_length = max(2.0 * wall_mm, 5.0)
    # tensile peak at centreline, decays with characteristic length
    if d <= decay_length:
        # tensile zone: σ_WRS ≈ +σ_y · cos(π/2 · d/L)
        sigma = sigma_y_MPa * math.cos((math.pi / 2.0) * (d / decay_length))
    elif d <= 2.5 * decay_length:
        # compressive plateau at -30%
        sigma = -0.30 * sigma_y_MPa
    else:
        # decay back to zero in parent
        sigma = -0.30 * sigma_y_MPa * math.exp(-(d - 2.5 * decay_length) / decay_length)
    # Longitudinal welds — slightly lower peak (Annex 9E note)
    if weld_type == "longitudinal-butt":
        sigma *= 0.85
    return float(max(-sigma_y_MPa, min(sigma_y_MPa, sigma)))


# ---------------------------------------------------------------------------
# Wüthrich 1982 LBB crack-mouth opening displacement
# ---------------------------------------------------------------------------


def lbb_wuthrich_COD(
    geometry: str,
    sigma_h_MPa: float,
    c_mm: float,
    E_GPa: float,
    sigma_y_MPa: float,
) -> float:
    """Wüthrich 1982 leak-before-break crack-mouth opening displacement, mm.

    For a through-wall axial crack of half-length ``c`` in a thin
    cylindrical shell under hoop stress σ_h:

    ``δ_CMOD = (8 · c · σ_y / (π · E)) · ln(sec(π σ_h / (2 σ_y)))``
                                          (Dugdale strip-yield model)

    Wüthrich 1982 demonstrated that this closed-form is the basis of
    most LBB codes. For ``geometry = "pipe"`` we add a bulging factor
    M_t ≈ 1 + 0.6 (2c)² / (Dt) per Folias (1965), supplied via the
    ``D_over_t`` argument — defaults to thin-shell (M_t=1).

    Args:
        geometry: ``'plate'`` (no bulging) or ``'pipe'`` (Folias correction).
        sigma_h_MPa: applied hoop stress, MPa.
        c_mm: crack half-length, mm.
        E_GPa: Young's modulus, GPa.
        sigma_y_MPa: yield strength, MPa.

    Returns:
        CMOD δ in mm.
    """

    if sigma_h_MPa <= 0 or sigma_y_MPa <= 0:
        return 0.0
    if sigma_h_MPa >= sigma_y_MPa:
        # Beyond yield — Dugdale singular; use π/2 limit (capped)
        return float(8.0 * c_mm * sigma_y_MPa / (math.pi * E_GPa * 1000.0))
    arg = (math.pi / 2.0) * (sigma_h_MPa / sigma_y_MPa)
    # sec(arg) = 1 / cos(arg); ln(sec) = -ln(cos)
    ln_sec = -math.log(max(1e-12, math.cos(arg)))
    delta_mm = (8.0 * c_mm * sigma_y_MPa / (math.pi * E_GPa * 1000.0)) * ln_sec
    return float(delta_mm)


# ---------------------------------------------------------------------------
# NACE TM0284 hydrogen-induced cracking severity
# ---------------------------------------------------------------------------


def hic_nace_TM0284_severity(
    H_concentration_ppm: float,
    T_C: float,
    T_ref_C: float = 25.0,
    A: float = 0.5,
    Q_a: float = 25.0,
) -> str:
    """NACE TM0284-2016 HIC severity classification.

    Calibrated to the modified-Devanathan-Stachurski permeation cell
    threshold currents converted to lattice H concentration C_L. The
    severity is bounded by C_L · exp(Q_a/RT₀ − Q_a/RT) — Arrhenius
    diffusivity correction relative to T_ref (Yan 2018).

    Returns one of: ``'Sweet'``, ``'Mild'``, ``'Sour'``, ``'Severe'``.
    """

    R = 8.314e-3  # kJ/(mol·K)
    T_K = T_C + 273.15
    T_ref_K = T_ref_C + 273.15
    # Arrhenius diffusivity correction
    C_eff = H_concentration_ppm * math.exp((Q_a / R) * (1.0 / T_ref_K - 1.0 / T_K))
    if C_eff < 0.05 * A:
        return "Sweet"
    if C_eff < 0.5 * A:
        return "Mild"
    if C_eff < 2.5 * A:
        return "Sour"
    return "Severe"


# ---------------------------------------------------------------------------
# Internal helpers (shared with the ffs.py local fallback)
# ---------------------------------------------------------------------------


def _allowable_from_spec(material: Mapping[str, Any]) -> tuple[float, float, float]:
    """Resolve (S, Sy, Suts) from a material spec or explicit fields."""

    spec_key = str(material.get("spec", ""))
    rec = DEFAULT_S_ALLOW_BY_SPEC.get(spec_key, {})
    S = float(material.get("S_MPa") or rec.get("S_MPa") or 138.0)
    Sy = float(material.get("Sy_MPa") or rec.get("Sy_MPa") or 260.0)
    Suts = float(material.get("Suts_MPa") or rec.get("Suts_MPa") or 485.0)
    return S, Sy, Suts


def _t_min_for_geometry(g: Mapping[str, Any], P: float, S: float) -> float:
    E = float(g.get("joint_efficiency") or 1.0)
    OD = float(g["OD_mm"])
    R_i = OD / 2.0 - 1.0
    geom = g.get("type") or "cylinder"
    return t_min_thinning(P, R_i, S, joint_efficiency=E, geom=geom)


def _base_mawp(g: Mapping[str, Any], S: float, t: float) -> float:
    E = float(g.get("joint_efficiency") or 1.0)
    D = float(g["OD_mm"])
    if g.get("type") == "sphere":
        return (2 * S * E * t) / (D / 2.0 - 1.0 + 0.1 * t)
    return (S * E * t) / (D / 2.0 - 1.0 + 0.6 * t)


# ---------------------------------------------------------------------------
# Part 5 — general metal loss (cylinder / sphere)
# ---------------------------------------------------------------------------


def run_ffs_part5_native(
    geometry: Mapping[str, Any],
    thickness_map: Sequence[Any],
    T_C: float,
    P_MPa: float,
    material: Mapping[str, Any],
    edition: str = "API 579-1 2021-12",
    corrosion_rate_mm_per_year: float = 0.0,
    FCA_mm: Optional[float] = None,
    lta: Optional[Mapping[str, Any]] = None,
) -> dict[str, Any]:
    """API 579-1 Part 5 — general metal-loss assessment.

    Implements the Level-1 / Level-2 RSF / Level-3 limit-load cascade per
    §§4.4.2-4.4.4 of API 579-1 2021 (numerically identical to 2024-09 —
    only commentary changed in Part 5).

    Returns a dict matching the TypeScript engine's envelope shape, ready
    to be lifted into :class:`austenite.ffs.FFSResult`.
    """

    FCA = float(FCA_mm if FCA_mm is not None else (geometry.get("FCA_mm") or 0.0))
    CR = float(corrosion_rate_mm_per_year)
    S, Sy, Suts = _allowable_from_spec(material)
    t_min = _t_min_for_geometry(geometry, P_MPa, S)

    # Normalise thickness map → list of floats
    if len(thickness_map) > 0 and isinstance(thickness_map[0], dict):
        ctp = [float(r["thickness_mm"]) for r in thickness_map]
    else:
        ctp = [float(v) for v in thickness_map]
    if not ctp:
        raise ValueError("Part 5: thickness_map must contain at least one reading.")
    t_meas_min = min(ctp)
    t_meas_avg = sum(ctp) / len(ctp)
    Rt = (t_meas_min - FCA) / max(t_min, 1e-6)

    level: str = "Level-1"
    RSF = 1.0
    RSF_a = 0.90
    notes: list[str] = []

    if (t_meas_min - FCA) >= t_min and Rt >= 0.20:
        notes.append(
            f"Level-1: PASS — (t_meas-FCA) = {t_meas_min - FCA:.2f} mm "
            f">= t_min = {t_min:.2f} mm; Rt = {Rt:.3f}."
        )
    else:
        notes.append(
            f"Level-1: insufficient — escalating to Level-2 (Rt = {Rt:.3f}, "
            f"t_meas-FCA = {t_meas_min - FCA:.2f} mm vs t_min = {t_min:.2f} mm)."
        )
        D = float(geometry["OD_mm"])
        s_grid = float(geometry.get("grid_spacing_mm") or 25.0)
        s_mm = max(s_grid, (len(ctp) - 1) * s_grid)
        lam = s_mm / max(math.sqrt(D * t_min), 1e-9)
        M_t = math.sqrt(1.0 + 0.48 * lam * lam)
        Rt_l2 = (t_meas_avg - FCA) / max(t_min, 1e-6)
        if Rt_l2 >= 1.0:
            RSF = 1.0
        else:
            # Folias RSF per §4.4.3.3: RSF = Rt / (1 - (1-Rt)/M_t), where Rt is
            # the remaining-thickness ratio (Rt=1 -> no loss -> RSF=1, and RSF
            # decreases monotonically as Rt falls). Equivalent to the (1-D) form
            # with damage D = 1-Rt.
            RSF = max(0.0, min(1.0, Rt_l2 / max(1e-6, 1 - (1 - Rt_l2) / M_t)))
        if (t_meas_min - FCA) < 0.20 * t_min:
            level = "Level-3"
            t_eff = max(0.01, t_meas_min - FCA)
            P_L = (4.0 / math.sqrt(3.0)) * Sy * t_eff / D
            P_allow = P_L / 1.5
            if P_allow >= P_MPa:
                notes.append(
                    f"Level-3 limit-load: P_collapse = {P_L:.2f} MPa, "
                    f"allowable = {P_allow:.2f} MPa >= P_op = {P_MPa:.2f} MPa -> PASS."
                )
            else:
                level = "unacceptable"
                notes.append(f"Level-3 FAIL — D/C = {P_MPa / P_allow:.2f} > 1.0.")
        else:
            level = "Level-2"
            verdict = "PASS" if RSF >= RSF_a else "DERATE"
            notes.append(f"Level-2: {verdict} — RSF = {RSF:.3f}, RSF_a = {RSF_a:.2f}.")

    MAWP = _base_mawp(geometry, S, max(t_meas_min - FCA, 1e-3))
    if RSF < RSF_a:
        MAWP = MAWP * RSF / RSF_a

    if lta:
        s_mm = float(lta["s_mm"])
        d_mm = float(lta["d_mm"])
        t_nom = float(geometry["wall_mm"])
        D = float(geometry["OD_mm"])
        lam = s_mm / max(math.sqrt(D * t_nom), 1e-9)
        M_t = math.sqrt(1.0 + 0.48 * lam * lam)
        RSF_lta = max(0.0, min(1.0, (1 - d_mm / t_nom) / max(1e-6, 1 - d_mm / (t_nom * M_t))))
        RSF = min(RSF, RSF_lta)
        notes.append(
            f"LTA Folias §4.4.3.3: RSF = {RSF_lta:.3f} (lambda = {lam:.3f}, M_t = {M_t:.3f})."
        )
        if RSF < RSF_a:
            MAWP = _base_mawp(geometry, S, max(t_meas_min - FCA, 1e-3)) * RSF / RSF_a

    margin = max(0.0, t_meas_min - t_min - FCA)
    life = margin / CR if CR > 0 else 1e6

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=float(life),
        t_min_mm=float(t_min),
        MAWP_MPa=float(MAWP),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) §4.4.2 (Level-1)",
            "API 579-1/ASME FFS-1 (2021) §4.4.3 (Level-2 RSF)",
            "API 579-1/ASME FFS-1 (2021) §4.4.4 (Level-3 limit-load)",
            "API 579-1 §4.4.3.3 (LTA Folias bulging)",
            "ASME II-D Table 1A",
            "ASME VIII Div 1 UG-27",
            "Kiefner & Vieth PRCI PR-3-805 (1989)",
            "Folias E.S., Int. J. Fracture Mech. 1 (1965) 104",
        ],
        RSF=float(RSF),
        RSF_a=float(RSF_a),
        t_meas_min_mm=float(t_meas_min),
        t_meas_avg_mm=float(t_meas_avg),
        details=dict(
            S_allow_MPa=float(S),
            Sy_MPa=float(Sy),
            Suts_MPa=float(Suts),
            FCA_mm=float(FCA),
            corrosion_rate_mm_per_year=float(CR),
        ),
    )


# ---------------------------------------------------------------------------
# Part 6 — pitting
# ---------------------------------------------------------------------------


def run_ffs_part6_native(
    geometry: Mapping[str, Any],
    pit_data: Sequence[Mapping[str, Any]],
    T_C: float,
    P_MPa: float,
    material: Mapping[str, Any],
    edition: str = "API 579-1 2021-12",
    corrosion_rate_mm_per_year: float = 0.0,
) -> dict[str, Any]:
    """API 579-1 Part 6 — pitting assessment per §§6.4.2-6.4.3.

    Implements the Level-1 density-class screen + Level-2 equivalent
    metal-loss RSF, following the TS engine 1:1 so verdicts agree.
    """

    FCA = float(geometry.get("FCA_mm") or 0.0)
    CR = float(corrosion_rate_mm_per_year)
    S, Sy, Suts = _allowable_from_spec(material)
    t_nom = float(geometry["wall_mm"])
    D = float(geometry["OD_mm"])
    t_min = _t_min_for_geometry(geometry, P_MPa, S)

    pits = list(pit_data)
    if not pits:
        raise ValueError("Part 6 requires at least one pit record.")
    depths = [float(p["max_depth_mm"]) for p in pits]
    diams = [float(p["diameter_mm"]) for p in pits]
    d_max = max(depths)
    d_avg = sum(depths) / len(depths)
    A_pits = sum(math.pi * (d / 2.0) ** 2 for d in diams)
    if pits[0].get("density_per_mm2"):
        A_inspect = len(pits) / float(pits[0]["density_per_mm2"])
    else:
        A_inspect = max(1e6, A_pits * 100.0)
    phi = A_pits / A_inspect
    density_per_100mm2 = (len(pits) / A_inspect) * 100.0
    if density_per_100mm2 < 1:
        density_class = 1
    elif density_per_100mm2 < 10:
        density_class = 2
    elif density_per_100mm2 < 100:
        density_class = 3
    elif density_per_100mm2 < 1000:
        density_class = 4
    else:
        density_class = 5
    screening_pass = d_max < 0.5 * t_nom and density_class <= 3

    notes: list[str] = []
    if screening_pass:
        notes.append(
            f"Level-1 PASS — max depth {d_max:.2f} mm < 0.5·t_nom; "
            f"density class {density_class}."
        )
    else:
        notes.append(
            f"Level-1 fail — escalating to Level-2 (depth {d_max:.2f} mm, "
            f"density class {density_class})."
        )
    phi_amp = max(0.5, 1.0 - phi)
    d_eq = max(d_max, 0.85 * d_avg) * phi_amp
    t_eff = max(1e-3, t_nom - d_eq - FCA)
    s_mm = math.sqrt(4.0 * A_pits / math.pi)
    lam = s_mm / max(math.sqrt(D * t_min), 1e-9)
    M_t = math.sqrt(1.0 + 0.48 * lam * lam)
    Rt = t_eff / max(t_min, 1e-6)
    RSF = 1.0
    if Rt < 1.0:
        # Folias RSF per §6.4.3: RSF = Rt / (1 - (1-Rt)/M_t), where Rt is the
        # remaining-thickness ratio (Rt=1 -> no loss -> RSF=1, decreasing
        # monotonically as Rt falls). Equivalent to the (1-D) form with D=1-Rt.
        RSF = max(0.0, min(1.0, Rt / max(1e-6, 1 - (1 - Rt) / M_t)))
    RSF_a = 0.90
    level: str = "Level-1" if screening_pass else "Level-2"
    if Rt < 0.20:
        level = "unacceptable"
        notes.append(f"Rt = {Rt:.3f} < 0.20 — wall lost to pits.")
    elif RSF < RSF_a:
        notes.append(f"Level-2 derate: RSF = {RSF:.3f}.")
    else:
        notes.append(f"Level-2 PASS: RSF = {RSF:.3f}.")
    MAWP = _base_mawp(geometry, S, max(t_eff, 1e-3))
    if RSF < RSF_a:
        MAWP = MAWP * RSF / RSF_a
    life = max(0.0, t_eff - t_min) / CR if CR > 0 else 1e6

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=float(life),
        t_min_mm=float(t_min),
        MAWP_MPa=float(MAWP),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) §6.4.2 (Level-1)",
            "API 579-1/ASME FFS-1 (2021) §6.4.3 (Level-2 RSF)",
            "Kowaka M. (1994) Ch. 4",
            "Frankel G.S., J. Electrochem. Soc. 145 (1998) 2186",
        ],
        pit_count=len(pits),
        max_pit_depth_mm=float(d_max),
        density_class=int(density_class),
        equiv_metal_loss_mm=float(d_eq),
        RSF=float(RSF),
        details=dict(
            d_max=float(d_max),
            d_avg=float(d_avg),
            A_pits_mm2=float(A_pits),
            A_inspect_mm2=float(A_inspect),
            pit_density_per_100mm2=float(density_per_100mm2),
            phi=float(phi),
            **{"lambda": float(lam)},
            M_t=float(M_t),
            Rt=float(Rt),
            S_allow_MPa=float(S),
            Sy_MPa=float(Sy),
            Suts_MPa=float(Suts),
            FCA_mm=float(FCA),
        ),
    )


# ---------------------------------------------------------------------------
# Part 9 — crack-like flaw (FAD Level 2A)
# ---------------------------------------------------------------------------


def run_ffs_part9_native(
    geometry: Mapping[str, Any],
    crack: Mapping[str, Any],
    sigma_membrane_MPa: float,
    sigma_bending_MPa: float,
    material: Mapping[str, Any],
    sigma_WRS_MPa: Optional[float] = None,
    edition: str = "API 579-1 2021-12",
) -> dict[str, Any]:
    """API 579-1 Part 9 — crack-like flaw with FAD Level-2A.

    Uses Newman-Raju 1982 K solutions for surface / through / corner
    cracks, the §9.4 Level-2A FAD curve, and a bisection search for the
    reserve factor R (radial distance of the operating point to the
    FAD curve).
    """

    a = float(crack["a_mm"])
    c = float(crack["c_mm"])
    t = float(geometry["wall_mm"])
    D = float(geometry["OD_mm"])
    sig_m = float(sigma_membrane_MPa)
    sig_b = float(sigma_bending_MPa)
    sig_WRS = float(sigma_WRS_MPa or 0.0)
    Sy = float(material["sigma_y"])
    Suts = float(material["sigma_uts"])
    KIc = float(material["KIc_MPa_sqm"])
    a_m = a / 1000.0
    ctype = crack.get("type") or "surface"

    # Newman-Raju 1982 K solutions
    if ctype == "surface":
        Q = 1.0 + 1.464 * (min(1.0, a / max(c, 1e-9))) ** 1.65
        F = 1.12
        K_app = F * (sig_m + sig_b) * math.sqrt(math.pi * a_m / Q)
        K_WRS = F * sig_WRS * math.sqrt(math.pi * a_m / Q)
    elif ctype == "through":
        K_app = (sig_m + sig_b) * math.sqrt(math.pi * a_m)
        K_WRS = sig_WRS * math.sqrt(math.pi * a_m)
    else:  # corner
        K_app = 1.12 * (sig_m + sig_b) * math.sqrt(math.pi * a_m)
        K_WRS = 1.12 * sig_WRS * math.sqrt(math.pi * a_m)
    K_total = max(0.0, K_app + K_WRS)

    if ctype == "through":
        lam = (2 * c) / max(math.sqrt(D * t), 1e-9)
        M_t = math.sqrt(1.0 + 0.48 * lam * lam)
        sigma_ref = (sig_m + sig_b / 3.0) * M_t
    else:
        sigma_ref = (sig_m + sig_b / 3.0) / max(0.05, 1.0 - a / t)
    L_r = sigma_ref / max(1.0, Sy)
    K_r = K_total / max(1.0, KIc)
    L_r_max = 0.5 * (1.0 + Sy / max(1.0, Suts))

    # bisection reserve factor (radial distance from origin to FAD curve)
    lo = 0.0
    hi = L_r_max / max(1e-9, L_r) if L_r > 0 else 100.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        tL = mid * L_r
        tK = mid * K_r
        Kf = 0.0 if tL >= L_r_max else fad_curve_level_2A(tL, L_r_max)
        if tK >= Kf:
            hi = mid
        else:
            lo = mid
    reserve = 0.5 * (lo + hi)

    if L_r >= L_r_max or K_r >= fad_curve_level_2A(L_r, L_r_max):
        verdict = "FAIL"
        level = "unacceptable"
    elif reserve < 1.1:
        verdict = "MARGINAL"
        level = "Level-3"
    else:
        verdict = "PASS"
        level = "Level-2"

    notes = [
        f"FAD operating point (L_r={L_r:.3f}, K_r={K_r:.3f}); L_r_max={L_r_max:.3f}.",
        f"K_app = {K_app:.2f} MPa.sqrt(m), K_WRS = {K_WRS:.2f} MPa.sqrt(m), "
        f"K_total = {K_total:.2f} MPa.sqrt(m).",
        f"sigma_ref = {sigma_ref:.1f} MPa; Sy = {Sy:.0f} MPa, KIc = {KIc:.0f} MPa.sqrt(m).",
        f"FAD verdict: {verdict}; reserve factor R = {reserve:.3f}.",
    ]
    if edition == "API 579-1 2024-09":
        notes.append("Note: 2024-09 Annex 9C re-aliased FAD points; numerical FAD curve unchanged.")

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=1e6,
        t_min_mm=float(t),
        MAWP_MPa=float((sig_m / max(1e-6, sigma_ref)) * sigma_ref * reserve),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) §9.4.2 + Annex 9C",
            "API 579-1/ASME FFS-1 (2024) Annex 9C re-alias",
            "BS 7910:2019 Annex L",
            "Anderson T.L., Fracture Mechanics 4th ed. §11.5",
            "Newman & Raju NASA TM-83200 (1982)",
            "Folias E.S., Int. J. Fracture Mech. 1 (1965) 104",
        ],
        fad_point=[float(L_r), float(K_r)],
        distance_to_curve=float(reserve),
        details=dict(
            a_mm=float(a),
            c_mm=float(c),
            t_mm=float(t),
            K_app=float(K_app),
            K_WRS_app=float(K_WRS),
            K_total=float(K_total),
            sigma_ref=float(sigma_ref),
            L_r_max=float(L_r_max),
            crack_type=str(ctype),
            sigma_y_MPa=float(Sy),
            sigma_uts_MPa=float(Suts),
            KIc_MPa_sqm=float(KIc),
        ),
    )


__all__ = [
    "DEFAULT_S_ALLOW_BY_SPEC",
    "lame_hoop_long_stress",
    "t_min_thinning",
    "fad_curve_level_2A",
    "wrs_profile_api579_9e",
    "lbb_wuthrich_COD",
    "hic_nace_TM0284_severity",
    "run_ffs_part5_native",
    "run_ffs_part6_native",
    "run_ffs_part9_native",
]
