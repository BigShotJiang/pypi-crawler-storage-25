"""Oracle / benchmark harness — run the published-benchmark suite against
the local SDK and return a pass / fail report.

Drives the cases shipped in ``au.data.published_benchmarks()``. Each case
declares:

  * ``id``          — short identifier (used in the per-case row)
  * ``capability``  — which SDK capability to invoke
  * ``input``       — keyword arguments
  * ``expected``    — ``{key, value, unit}``  (dotted key path into result)
  * ``tolerance_pct`` — passing band (relative tolerance, %)
  * ``citation``    — published source

The harness intentionally does NOT call the remote API — it executes the
purely-local capabilities (data lookup, reliability, simple RBI). For
network-bound capabilities (CALPHAD, MTC, design-path) the case is marked
``skipped`` with a clear note unless the user supplies an ``http_client``.

Example::

    import austenite as au
    report = au.benchmark.run_all()
    print(report.summary())
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass(frozen=True)
class BenchmarkCaseResult:
    id: str
    capability: str
    passed: bool
    skipped: bool
    actual: Any
    expected: Any
    tolerance_pct: float
    error: Optional[str]
    citation: str

    def __repr__(self) -> str:  # pragma: no cover - dev convenience
        status = "SKIP" if self.skipped else ("PASS" if self.passed else "FAIL")
        return f"<BenchmarkCase {self.id} {status}>"


@dataclass(frozen=True)
class BenchmarkReport:
    cases: list[BenchmarkCaseResult] = field(default_factory=list)

    @property
    def n_total(self) -> int:
        return len(self.cases)

    @property
    def n_pass(self) -> int:
        return sum(1 for c in self.cases if c.passed and not c.skipped)

    @property
    def n_fail(self) -> int:
        return sum(1 for c in self.cases if not c.passed and not c.skipped)

    @property
    def n_skip(self) -> int:
        return sum(1 for c in self.cases if c.skipped)

    def summary(self) -> str:
        return (f"benchmark: cases={self.n_total}  pass={self.n_pass}  "
                f"fail={self.n_fail}  skip={self.n_skip}  "
                f"pass-rate={self.n_pass}/{self.n_total - self.n_skip}")

    def __repr__(self) -> str:  # pragma: no cover
        return f"<BenchmarkReport {self.summary()}>"


def _get_dotted(obj: Any, key: str) -> Any:
    """Traverse ``foo.bar.baz`` through dicts / objects / DataFrames."""

    cur = obj
    for part in key.split("."):
        if cur is None:
            return None
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            cur = getattr(cur, part, None)
    return cur


def _compare(actual: Any, expected: Any, tol_pct: float) -> tuple[bool, str]:
    """Compare numbers (relative tolerance), exact for strings / lists."""

    if isinstance(expected, list):
        if not isinstance(actual, list):
            return False, "expected list, got non-list"
        return (sorted(map(str, actual)) == sorted(map(str, expected))), ""
    if isinstance(expected, str):
        return (str(actual).strip().lower() == expected.strip().lower()), ""
    try:
        a = float(actual)
        e = float(expected)
    except (TypeError, ValueError):
        return False, f"non-numeric actual={actual!r}"
    if not (a == a):  # NaN
        return False, "NaN actual"
    if tol_pct <= 0:
        return (abs(a - e) < 1e-9), ""
    if e == 0:
        return (abs(a) <= tol_pct / 100.0), ""
    rel = abs(a - e) / abs(e) * 100.0
    return (rel <= tol_pct), ""


def _run_case(case: dict[str, Any]) -> BenchmarkCaseResult:
    cap = case.get("capability", "").lower()
    inp = case.get("input", {}) or {}
    exp = case.get("expected", {}) or {}
    tol = float(case.get("tolerance_pct", 0))
    cite = case.get("citation", "")
    cid = case.get("id", "?")

    # Locally-runnable capabilities — no network required
    try:
        if cap == "data":
            from . import data as _data
            asme = inp.get("asme")
            row = _data.alloy_lookup(asme) if asme else None
            actual = _get_dotted(row, exp.get("key", "")) if row else None
            ok, _ = _compare(actual, exp.get("value"), tol)
            return BenchmarkCaseResult(cid, cap, ok, False, actual, exp.get("value"),
                                       tol, None if ok else "value mismatch", cite)

        if cap == "reliability" and "times_h" in inp:
            from . import reliability as _r
            fit = _r.weibull_fit(inp["times_h"], inp.get("censored"))
            actual = _get_dotted({"beta": fit.beta, "eta": fit.eta,
                                  "MTTF": fit.MTTF, "B10": fit.B10}, exp.get("key", ""))
            ok, _ = _compare(actual, exp.get("value"), tol)
            return BenchmarkCaseResult(cid, cap, ok, False, actual, exp.get("value"),
                                       tol, None if ok else "value mismatch", cite)

        if cap == "reliability" and "cells" in inp:
            from . import reliability as _r
            fit = _r.arrhenius_alt(inp["cells"], use_T_K=inp.get("T_use_K", 300.0))
            actual = _get_dotted({"Ea_eV": fit.E_a_eV, "A": fit.A,
                                  "t50_at_use_T": fit.t50_at_use_T}, exp.get("key", ""))
            ok, _ = _compare(actual, exp.get("value"), tol)
            return BenchmarkCaseResult(cid, cap, ok, False, actual, exp.get("value"),
                                       tol, None if ok else "value mismatch", cite)

        if cap == "rbi":
            from . import rbi as _rbi
            df = _rbi.damage_factor_thinning(
                age_yr=float(inp.get("age_yr", 10)),
                CR_mm_yr=float(inp.get("CR_mm_yr", 0.1)),
                t_mm=float(inp.get("t_mm", 12.7)),
                t_min_mm=float(inp.get("t_min_mm", 8.0)),
                inspection_category=str(inp.get("insp", "C")),
                n_inspections=int(inp.get("n_insp", 1)),
            )
            actual = df.get("df")
            ok, _ = _compare(actual, exp.get("value"), tol)
            return BenchmarkCaseResult(cid, cap, ok, False, actual, exp.get("value"),
                                       tol, None if ok else "value mismatch", cite)

        # network-bound — skip in the local harness
        return BenchmarkCaseResult(
            cid, cap, passed=False, skipped=True, actual=None, expected=exp.get("value"),
            tolerance_pct=tol, error="capability requires API call; supply http_client to exercise",
            citation=cite,
        )

    except Exception as e:  # pragma: no cover - defensive
        return BenchmarkCaseResult(
            cid, cap, passed=False, skipped=False, actual=None, expected=exp.get("value"),
            tolerance_pct=tol, error=f"exception: {e}", citation=cite,
        )


def run_all() -> BenchmarkReport:
    """Run every shipped benchmark case and return the report."""

    from . import data as _data
    try:
        df = _data.published_benchmarks()
        rows = df.to_dict(orient="records") if hasattr(df, "to_dict") else list(df)
    except Exception:  # pragma: no cover - data load failure
        rows = []
    return BenchmarkReport(cases=[_run_case(c) for c in rows])


__all__ = ["BenchmarkCaseResult", "BenchmarkReport", "run_all"]
