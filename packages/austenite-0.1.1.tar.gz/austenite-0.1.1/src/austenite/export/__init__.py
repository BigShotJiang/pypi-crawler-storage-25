"""FEA / simulation deck exporters.

Bridges Austenite microstructure / alloy / geometry results into the
input-deck formats expected by the three most-used industry FEA tools:

* :func:`damask`      — DAMASK crystal-plasticity (free, open source).
* :func:`moose_input` — MOOSE multi-physics FEM (Idaho NL, free).
* :func:`abaqus_inp`  — Abaqus standard ``.inp`` deck (Dassault, commercial).

Each exporter writes a runnable input deck and returns a manifest of the
files it created. The exporters do *not* require the target FEA package
to be installed locally — they just emit text files. Tests verify the
generated syntax round-trips through dedicated mock parsers.

Example::

    import austenite as au

    # DAMASK CP-FEA on an EBSD voxelisation
    mesh = au.ebsd_3d.synthesize(grains=128, voxels=(32, 32, 32))
    au.export.damask(
        microstructure=mesh,
        alloy="IN718",
        loading={"strain_rate_per_s": 1e-3, "strain_max": 0.05, "direction": "z"},
        output_dir="./damask_run/",
    )

    # MOOSE thin-wall pressure-vessel
    au.export.moose_input(
        geometry={"type": "cylinder", "OD_mm": 500, "L_mm": 1000, "wall_mm": 12.5},
        physics=["solid_mechanics", "heat_conduction"],
        material="SA-516-70",
        boundary_conditions={"left": "fixed", "right": "P_MPa=2.5"},
        output_path="./pressure_vessel.i",
    )

    # Abaqus static deck
    au.export.abaqus_inp(
        geometry={"type": "cylinder", "OD_mm": 500, "L_mm": 1000, "wall_mm": 12.5},
        material="SA-516-70",
        physics="static",
        output_path="./model.inp",
    )

References:
    * Roters F. et al., Acta Mater. 58 (2010) 1152 — DAMASK crystal plasticity.
    * Permann C.J. et al., SoftwareX 11 (2020) 100430 — MOOSE multiphysics FEM.
    * Abaqus User's Manual, Dassault Systemes Simulia Corp., Providence RI.
"""

from __future__ import annotations

from .abaqus import abaqus_inp
from .damask import damask
from .moose import moose_input

__all__ = [
    "damask",
    "moose_input",
    "abaqus_inp",
]
