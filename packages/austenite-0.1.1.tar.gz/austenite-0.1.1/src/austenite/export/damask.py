"""DAMASK input-deck generator.

DAMASK is the de-facto open-source crystal-plasticity FEA suite — free,
well-cited, and the input-side pain point engineers run into is
hand-writing the YAML material card and the load-path file
(GitHub Discussion #27: "DAMASK_grid: command not found" — usually a
mis-written deck, not a missing binary).

This module takes an Austenite microstructure (synthetic or
EBSD-reconstructed) plus an alloy spec and writes four files:

  * ``material.yaml`` — DAMASK phenopowerlaw constitutive card +
    grain-to-phase mapping.
  * ``load.yaml``     — deformation-gradient time series.
  * ``geom.vti``      — VTK ImageData voxel grid (header + raw uint32
    payload referenced by ``material.yaml``).
  * ``run.sh``        — DAMASK_grid launcher.

The generated deck targets DAMASK 3.x (the actively maintained line).
Older 2.x decks used a separate ``geom`` ASCII format; we emit VTI which
both 3.0+ versions accept.

References:
    * Roters F., Eisenlohr P., Hantcherli L., Tjahjanto D.D., Bieler T.R.,
      Raabe D., Acta Mater. 58 (2010) 1152 — DAMASK crystal plasticity.
    * Roters F. et al., Comput. Mater. Sci. 158 (2019) 420 — DAMASK 3 redesign.
    * https://damask3.mpie.de/documentation/
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence, Union


# ---------------------------------------------------------------------------
# Default phenopowerlaw parameters for the three most common AM alloys.
# Values are literature defaults; engineers should override in production
# via the ``constitutive_overrides=`` kwarg.
# ---------------------------------------------------------------------------

_PHENOPOWERLAW_DEFAULTS: dict[str, dict[str, Any]] = {
    # Inconel 718 — Ni-base FCC. Roters/Raabe ICME defaults.
    "IN718": {
        "lattice": "cF",  # FCC
        "C_11_GPa": 259.6,
        "C_12_GPa": 179.0,
        "C_44_GPa": 109.6,
        "tau0_MPa": 305.0,   # initial CRSS
        "taus_MPa": 463.0,   # saturation CRSS
        "h0_MPa": 595.0,     # initial hardening modulus
        "dotgamma0_per_s": 1e-3,
        "n_exp": 20.0,
        "a_exp": 2.25,
        "n_slip_systems": 12,  # {111}<110>
        "citation": "Roters 2010; Inconel 718 (cF) phenopowerlaw fit",
    },
    # Ti-6Al-4V — HCP α + BCC β. We export the α-phase HCP card.
    "Ti-6Al-4V": {
        "lattice": "hP",
        "C_11_GPa": 162.4,
        "C_12_GPa": 92.0,
        "C_13_GPa": 69.0,
        "C_33_GPa": 180.7,
        "C_44_GPa": 46.7,
        "tau0_MPa": 390.0,
        "taus_MPa": 525.0,
        "h0_MPa": 700.0,
        "dotgamma0_per_s": 1e-3,
        "n_exp": 20.0,
        "a_exp": 2.0,
        "n_slip_systems": 24,  # basal + prismatic + pyramidal
        "citation": "Roters 2019; Ti-6Al-4V α-phase HCP phenopowerlaw",
    },
    # 316L austenitic stainless — FCC.
    "SS316L": {
        "lattice": "cF",
        "C_11_GPa": 204.6,
        "C_12_GPa": 137.7,
        "C_44_GPa": 126.2,
        "tau0_MPa": 95.0,
        "taus_MPa": 222.0,
        "h0_MPa": 285.0,
        "dotgamma0_per_s": 1e-3,
        "n_exp": 20.0,
        "a_exp": 2.25,
        "n_slip_systems": 12,
        "citation": "Eisenlohr 2013; AISI 316L FCC phenopowerlaw",
    },
}


def _alloy_to_phenopowerlaw(alloy: str) -> dict[str, Any]:
    """Return phenopowerlaw parameters for the named alloy.

    Falls back to a generic FCC IN718-like card with a ``citation`` note
    flagging the fallback so the user knows to override.
    """

    if alloy in _PHENOPOWERLAW_DEFAULTS:
        return dict(_PHENOPOWERLAW_DEFAULTS[alloy])

    # Match by family prefix
    a = alloy.lower()
    if "in718" in a or "inconel 718" in a:
        return dict(_PHENOPOWERLAW_DEFAULTS["IN718"])
    if "ti-6al-4v" in a or "ti6al4v" in a or "ti64" in a:
        return dict(_PHENOPOWERLAW_DEFAULTS["Ti-6Al-4V"])
    if "316" in a:
        return dict(_PHENOPOWERLAW_DEFAULTS["SS316L"])

    out = dict(_PHENOPOWERLAW_DEFAULTS["IN718"])
    out["citation"] = (
        f"FALLBACK IN718 phenopowerlaw — no calibrated card for {alloy!r}; "
        "supply constitutive_overrides=..."
    )
    return out


# ---------------------------------------------------------------------------
# Microstructure handling — accept several shapes politely
# ---------------------------------------------------------------------------


def _coerce_microstructure(
    microstructure: Any,
) -> dict[str, Any]:
    """Normalise the microstructure argument.

    Accepts:
      * dict with ``grains``, ``voxels``, optional ``grain_ids``
      * an object exposing ``.grain_ids`` / ``.shape`` / ``.n_grains``
      * a plain (nx, ny, nz) tuple (synthesises a striped voxel field)

    Returns a normalised dict::

        {
            "shape": (nx, ny, nz),
            "size_um": (Lx, Ly, Lz),
            "n_grains": int,
            "grain_ids": flat list[int] length nx*ny*nz (1-indexed)
        }
    """

    # Tuple/list shape only → make a synthetic striped field.
    if isinstance(microstructure, (tuple, list)) and len(microstructure) == 3 \
            and all(isinstance(d, int) for d in microstructure):
        shape = tuple(int(d) for d in microstructure)  # type: ignore[assignment]
        return _synthesise_voxels(shape)  # type: ignore[arg-type]

    # Dict-like
    if isinstance(microstructure, Mapping):
        shape = tuple(int(d) for d in microstructure.get("voxels", (16, 16, 16)))
        n_g = int(microstructure.get("grains", microstructure.get("n_grains", 64)))
        size_um = tuple(float(d) for d in microstructure.get("size_um", (100.0, 100.0, 100.0)))
        ids = microstructure.get("grain_ids")
        if ids is None:
            voxels = _synthesise_voxels(shape, n_grains=n_g, size_um=size_um)
            return voxels
        return {
            "shape": shape,
            "size_um": size_um,
            "n_grains": n_g,
            "grain_ids": list(int(x) for x in ids),
        }

    # Generic object — duck-type
    shape = getattr(microstructure, "shape", None) \
        or tuple(getattr(microstructure, "voxels", (16, 16, 16)))
    n_g = int(
        getattr(microstructure, "n_grains", None)
        or getattr(microstructure, "grains", 64)
    )
    size_um = tuple(float(d) for d in getattr(microstructure, "size_um", (100.0, 100.0, 100.0)))
    ids = getattr(microstructure, "grain_ids", None)
    shape = tuple(int(d) for d in shape)  # type: ignore[assignment]
    if ids is None:
        return _synthesise_voxels(shape, n_grains=n_g, size_um=size_um)
    return {
        "shape": shape,
        "size_um": size_um,
        "n_grains": n_g,
        "grain_ids": list(int(x) for x in ids),
    }


def _synthesise_voxels(
    shape: tuple[int, int, int],
    *,
    n_grains: int = 64,
    size_um: tuple[float, float, float] = (100.0, 100.0, 100.0),
) -> dict[str, Any]:
    """Build a simple cubic-stripe voxel field with ``n_grains`` IDs."""

    nx, ny, nz = (int(d) for d in shape)
    total = nx * ny * nz
    ids = [(i % n_grains) + 1 for i in range(total)]
    return {
        "shape": (nx, ny, nz),
        "size_um": size_um,
        "n_grains": n_grains,
        "grain_ids": ids,
    }


# ---------------------------------------------------------------------------
# Writers — each block is a focused str builder
# ---------------------------------------------------------------------------


def _write_material_yaml(
    alloy: str,
    params: Mapping[str, Any],
    n_grains: int,
    *,
    orientations: Optional[Sequence[Sequence[float]]] = None,
) -> str:
    """Compose the DAMASK 3 ``material.yaml`` file."""

    p = params
    lattice = p.get("lattice", "cF")

    # Elastic constants block (depends on lattice symmetry)
    if lattice == "cF":
        elastic = (
            f"      C_11: {p['C_11_GPa'] * 1e9:.3e}\n"
            f"      C_12: {p['C_12_GPa'] * 1e9:.3e}\n"
            f"      C_44: {p['C_44_GPa'] * 1e9:.3e}\n"
        )
    elif lattice == "hP":
        elastic = (
            f"      C_11: {p['C_11_GPa'] * 1e9:.3e}\n"
            f"      C_12: {p['C_12_GPa'] * 1e9:.3e}\n"
            f"      C_13: {p['C_13_GPa'] * 1e9:.3e}\n"
            f"      C_33: {p['C_33_GPa'] * 1e9:.3e}\n"
            f"      C_44: {p['C_44_GPa'] * 1e9:.3e}\n"
        )
    else:
        elastic = ""

    nss = int(p.get("n_slip_systems", 12))
    tau0 = p["tau0_MPa"] * 1e6
    taus = p["taus_MPa"] * 1e6
    h0 = p["h0_MPa"] * 1e6
    n_exp = float(p["n_exp"])
    a_exp = float(p["a_exp"])
    g0 = float(p["dotgamma0_per_s"])

    header = (
        "# DAMASK 3.x material configuration\n"
        f"# Generated by Austenite for alloy {alloy!r}\n"
        f"# Source: {p.get('citation', 'phenopowerlaw default')}\n"
        "# References:\n"
        "#   Roters F. et al., Acta Mater. 58 (2010) 1152.\n"
        "#   Roters F. et al., Comput. Mater. Sci. 158 (2019) 420.\n"
        "homogenization:\n"
        "  SX:\n"
        "    N_constituents: 1\n"
        "    mechanical: {type: pass}\n"
    )

    phase = (
        "phase:\n"
        f"  {alloy}:\n"
        f"    lattice: {lattice}\n"
        "    mechanical:\n"
        "      output: [F, P, F_e, F_p, L_p, O]\n"
        "      elastic:\n"
        "        type: Hooke\n"
        f"{elastic}"
        "      plastic:\n"
        "        type: phenopowerlaw\n"
        "        output: [xi_sl, gamma_sl]\n"
        f"        N_sl: [{nss}]\n"
        f"        xi_0_sl: [{tau0:.3e}]\n"
        f"        xi_inf_sl: [{taus:.3e}]\n"
        f"        h_0_sl-sl: [{h0:.3e}]\n"
        f"        dot_gamma_0_sl: {g0:.3e}\n"
        f"        n_sl: {n_exp:.3f}\n"
        f"        a_sl: {a_exp:.3f}\n"
        "        h_sl-sl: [1, 1, 5.0, 1, 1, 1]\n"
    )

    # Orientations — use isotropic uniform on SO(3) by sampling spherical
    # coordinates; gives a deterministic, citable distribution (Bunge ZXZ).
    if orientations is None:
        orientations = _isotropic_bunge_zxz(n_grains)

    mat_lines = ["material:"]
    for i, (phi1, Phi, phi2) in enumerate(orientations[:n_grains], start=1):
        mat_lines.append(
            f"  - constituents:\n"
            f"      - phase: {alloy}\n"
            f"        v: 1.0\n"
            f"        O: [{_bunge_to_quat(phi1, Phi, phi2)}]\n"
            f"    homogenization: SX"
        )

    return header + phase + "\n".join(mat_lines) + "\n"


def _isotropic_bunge_zxz(n: int) -> list[tuple[float, float, float]]:
    """Deterministic isotropic ZXZ Bunge angles via the Halton sequence.

    Avoids needing numpy/scipy. Returns radians.
    """

    out: list[tuple[float, float, float]] = []
    for k in range(1, n + 1):
        # van der Corput base-2 for phi1
        v = 0.0
        denom = 0.5
        kk = k
        while kk:
            v += (kk & 1) * denom
            kk >>= 1
            denom *= 0.5
        # phi1 ∈ [0, 2π)
        phi1 = 2.0 * math.pi * v
        # Phi from cos-uniform
        u = (k * 0.6180339887498949) % 1.0  # golden-ratio LDS
        Phi = math.acos(2.0 * u - 1.0)
        # phi2 — small offset
        phi2 = 2.0 * math.pi * ((k * 0.2247448713915890) % 1.0)
        out.append((phi1, Phi, phi2))
    return out


def _bunge_to_quat(phi1: float, Phi: float, phi2: float) -> str:
    """Convert Bunge ZXZ Euler angles (rad) to a normalised quaternion string.

    Returns "qw, qx, qy, qz" formatted for the DAMASK YAML list.
    """

    c1 = math.cos(phi1 / 2.0)
    s1 = math.sin(phi1 / 2.0)
    c2 = math.cos(Phi / 2.0)
    s2 = math.sin(Phi / 2.0)
    c3 = math.cos(phi2 / 2.0)
    s3 = math.sin(phi2 / 2.0)

    qw = c1 * c2 * c3 - s1 * c2 * s3
    qx = c1 * s2 * c3 + s1 * s2 * s3
    qy = -c1 * s2 * s3 + s1 * s2 * c3
    qz = c1 * c2 * s3 + s1 * c2 * c3
    return f"{qw:.6f}, {qx:.6f}, {qy:.6f}, {qz:.6f}"


def _write_load_yaml(loading: Mapping[str, Any]) -> str:
    """Build the DAMASK ``load.yaml`` (deformation-gradient time series)."""

    rate = float(loading.get("strain_rate_per_s", 1e-3))
    strain_max = float(loading.get("strain_max", 0.05))
    direction = str(loading.get("direction", "z")).lower()
    n_increments = int(loading.get("n_increments", 100))
    t_total = strain_max / rate

    axis = {"x": 0, "y": 1, "z": 2}[direction]
    L = [["x"] * 3 for _ in range(3)]
    L[axis][axis] = f"{rate:.3e}"
    # Diagonal others: lateral contraction left free (DAMASK 'x' wildcard means free)
    P = [["x"] * 3 for _ in range(3)]
    for i in range(3):
        if i != axis:
            P[i][i] = "0"
    P_str = "[" + ", ".join("[" + ", ".join(row) + "]" for row in P) + "]"
    L_str = "[" + ", ".join("[" + ", ".join(row) + "]" for row in L) + "]"

    return (
        "# DAMASK 3.x load configuration\n"
        f"# Strain rate {rate:.3e} /s along {direction}-axis to {strain_max*100:.1f}% true strain.\n"
        "# Citation: Roters F. et al., Acta Mater. 58 (2010) 1152.\n"
        "solver:\n"
        "  mechanical: spectral_basic\n"
        "loadstep:\n"
        f"  - boundary_conditions:\n"
        f"      mechanical:\n"
        f"        L: {L_str}\n"
        f"        P: {P_str}\n"
        f"    discretization:\n"
        f"      t: {t_total:.4f}\n"
        f"      N: {n_increments}\n"
        "    f_out: 5\n"
    )


def _write_geom_vti(
    shape: tuple[int, int, int],
    size_um: tuple[float, float, float],
    grain_ids: Sequence[int],
) -> str:
    """Build a VTK ImageData (.vti) ASCII deck encoding grain IDs.

    Uses the human-readable XML form so tests can parse it without VTK.
    Production DAMASK accepts both ASCII and binary VTI.
    """

    nx, ny, nz = shape
    Lx, Ly, Lz = size_um
    dx, dy, dz = Lx / nx, Ly / ny, Lz / nz

    flat = " ".join(str(int(v)) for v in grain_ids)

    return (
        '<?xml version="1.0"?>\n'
        '<VTKFile type="ImageData" version="1.0" byte_order="LittleEndian">\n'
        f'  <ImageData WholeExtent="0 {nx} 0 {ny} 0 {nz}" '
        f'Origin="0 0 0" Spacing="{dx} {dy} {dz}">\n'
        f'    <Piece Extent="0 {nx} 0 {ny} 0 {nz}">\n'
        '      <CellData Scalars="material">\n'
        '        <DataArray type="UInt32" Name="material" format="ascii">\n'
        f'          {flat}\n'
        '        </DataArray>\n'
        '      </CellData>\n'
        '    </Piece>\n'
        '  </ImageData>\n'
        '</VTKFile>\n'
    )


def _write_run_sh(output_dir: Path, n_grains: int, n_voxels: int) -> str:
    """Tiny launcher script for DAMASK_grid."""

    return (
        "#!/usr/bin/env bash\n"
        "# DAMASK_grid launcher — generated by Austenite\n"
        "# Reference: Roters F. et al., Comput. Mater. Sci. 158 (2019) 420.\n"
        f"# Microstructure: {n_grains} grains over {n_voxels} voxels.\n"
        "set -e\n"
        "cd \"$(dirname \"$0\")\"\n"
        "DAMASK_grid \\\n"
        "    --load load.yaml \\\n"
        "    --material material.yaml \\\n"
        "    --geom geom.vti \\\n"
        "    --workingdirectory .\n"
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def damask(
    *,
    microstructure: Any,
    alloy: str,
    loading: Mapping[str, Any],
    output_dir: Union[str, Path],
    constitutive_overrides: Optional[Mapping[str, Any]] = None,
    orientations: Optional[Sequence[Sequence[float]]] = None,
) -> dict[str, Any]:
    """Write a runnable DAMASK 3.x input deck.

    Args:
        microstructure: Voxelised microstructure. Accepts the output of
            :func:`austenite.ebsd_3d.reconstruct` /
            :func:`austenite.ebsd_3d.synthesize`, a plain dict
            ``{"voxels": (nx, ny, nz), "grains": n}``, or just a
            ``(nx, ny, nz)`` shape tuple.
        alloy: Alloy grade (e.g. ``"IN718"``, ``"Ti-6Al-4V"``, ``"SS316L"``).
            Falls back to the IN718 FCC phenopowerlaw card with a clear
            ``[FALLBACK]`` citation note if unknown.
        loading: Dict with ``strain_rate_per_s``, ``strain_max``,
            ``direction`` (one of ``"x"`` / ``"y"`` / ``"z"``), and an
            optional ``n_increments`` (default 100).
        output_dir: Directory to write the four files into. Created if
            absent. Existing files are overwritten.
        constitutive_overrides: Per-parameter overrides on top of the
            phenopowerlaw defaults (``tau0_MPa``, ``taus_MPa``, ``h0_MPa``,
            ``n_exp``, ``a_exp``, ``dotgamma0_per_s``, ``C_11_GPa``, ...).
        orientations: Optional list of (phi1, Phi, phi2) Bunge ZXZ Euler
            angles in radians, one per grain. Defaults to an isotropic
            deterministic Halton sampling.

    Returns:
        Dict with::

            {
                "output_dir":      pathlib.Path,
                "files":           ["material.yaml", "load.yaml",
                                   "geom.vti", "run.sh"],
                "alloy":           str,
                "n_grains":        int,
                "shape":           (nx, ny, nz),
                "citation":        str,
            }
    """

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    micro = _coerce_microstructure(microstructure)

    # Constitutive card
    params = _alloy_to_phenopowerlaw(alloy)
    if constitutive_overrides:
        params.update(dict(constitutive_overrides))

    material_yaml = _write_material_yaml(
        alloy=alloy,
        params=params,
        n_grains=micro["n_grains"],
        orientations=orientations,
    )
    load_yaml = _write_load_yaml(loading)
    geom_vti = _write_geom_vti(micro["shape"], micro["size_um"], micro["grain_ids"])
    run_sh = _write_run_sh(out_dir, micro["n_grains"], len(micro["grain_ids"]))

    (out_dir / "material.yaml").write_text(material_yaml, encoding="utf-8")
    (out_dir / "load.yaml").write_text(load_yaml, encoding="utf-8")
    (out_dir / "geom.vti").write_text(geom_vti, encoding="utf-8")
    run_path = out_dir / "run.sh"
    run_path.write_text(run_sh, encoding="utf-8")
    try:
        run_path.chmod(0o755)
    except (OSError, NotImplementedError):
        # Windows / non-POSIX — chmod is a no-op, ignore.
        pass

    return {
        "output_dir": out_dir,
        "files": ["material.yaml", "load.yaml", "geom.vti", "run.sh"],
        "alloy": alloy,
        "n_grains": int(micro["n_grains"]),
        "shape": tuple(int(d) for d in micro["shape"]),
        "citation": params.get("citation", ""),
    }


__all__ = ["damask"]
