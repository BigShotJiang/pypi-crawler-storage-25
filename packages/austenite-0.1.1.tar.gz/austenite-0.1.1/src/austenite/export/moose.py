"""MOOSE input-file generator.

MOOSE (Multiphysics Object Oriented Simulation Environment) is INL's
free FEM framework — extremely flexible but the GetPot-style hierarchical
input syntax is famously verbose to hand-write.

This module takes a geometry + physics + material/BC specification and
emits a runnable ``.i`` file with the blocks MOOSE expects:

    [Mesh] [Variables] [Kernels] [Materials] [BCs] [Executioner] [Outputs]

Supported physics modules today:

  * ``solid_mechanics``   — small-strain isotropic elasticity (TensorMechanics).
  * ``heat_conduction``   — HeatConduction kernel + BodyForce + bulk heat-source.
  * ``coupled_th``        — coupled thermo-mechanical (TM solid + heat).
  * ``porous_flow``       — incompressible single-phase Darcy (PorousFlowFullySat).

References:
    * Permann C.J., Andrs D., Peterson J.W. et al., SoftwareX 11 (2020) 100430
      — MOOSE: enabling massively parallel multiphysics simulation.
    * Gaston D., Newman C., Hansen G., Lebrun-Grandie D., Nucl.Eng.Des. 239
      (2009) 1768 — MOOSE base framework.
    * https://mooseframework.inl.gov/
"""

from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Mapping, Optional, Sequence, Union


# ---------------------------------------------------------------------------
# Built-in material database — values needed by the moose Material block.
# These echo `au.data.alloys()` but kept inline so this module is
# self-contained for unit testing without the broader catalogue.
# ---------------------------------------------------------------------------

_MATERIAL_DB: dict[str, dict[str, float]] = {
    "SA-516-70": {
        "E_GPa": 200.0, "nu": 0.30, "rho_kg_m3": 7850.0,
        "k_W_mK": 49.0, "Cp_J_kgK": 469.0,
        "alpha_e6_per_K": 12.1, "sigma_y_MPa": 260.0,
    },
    "304L": {
        "E_GPa": 193.0, "nu": 0.30, "rho_kg_m3": 8000.0,
        "k_W_mK": 16.2, "Cp_J_kgK": 500.0,
        "alpha_e6_per_K": 17.3, "sigma_y_MPa": 170.0,
    },
    "IN718": {
        "E_GPa": 200.0, "nu": 0.29, "rho_kg_m3": 8190.0,
        "k_W_mK": 11.4, "Cp_J_kgK": 435.0,
        "alpha_e6_per_K": 13.0, "sigma_y_MPa": 1100.0,
    },
    "Ti-6Al-4V": {
        "E_GPa": 114.0, "nu": 0.34, "rho_kg_m3": 4430.0,
        "k_W_mK": 6.7, "Cp_J_kgK": 526.0,
        "alpha_e6_per_K": 8.6, "sigma_y_MPa": 880.0,
    },
}

# Aliases — engineers will spell things 5 ways
_MATERIAL_ALIASES: dict[str, str] = {
    "sa-516-70": "SA-516-70", "sa-516 gr 70": "SA-516-70",
    "sa516": "SA-516-70", "a516": "SA-516-70",
    "ss304l": "304L", "304": "304L", "ss304": "304L",
    "inconel 718": "IN718", "in 718": "IN718", "alloy 718": "IN718",
    "ti6al4v": "Ti-6Al-4V", "ti-64": "Ti-6Al-4V", "ti64": "Ti-6Al-4V",
}


def _lookup_material(name: str) -> tuple[str, dict[str, float]]:
    """Resolve a free-form material name. Returns (canonical, props)."""

    if name in _MATERIAL_DB:
        return name, dict(_MATERIAL_DB[name])
    key = name.strip().lower()
    canon = _MATERIAL_ALIASES.get(key)
    if canon is not None:
        return canon, dict(_MATERIAL_DB[canon])
    # Try a substring match
    for db_name in _MATERIAL_DB:
        if db_name.lower() in key or key in db_name.lower():
            return db_name, dict(_MATERIAL_DB[db_name])
    # Sensible fallback — carbon steel
    props = dict(_MATERIAL_DB["SA-516-70"])
    return f"{name} [fallback SA-516-70]", props


# ---------------------------------------------------------------------------
# Geometry → mesh block. Three primitive shapes supported.
# ---------------------------------------------------------------------------


def _write_mesh_block(geometry: Mapping[str, Any]) -> tuple[str, list[str]]:
    """Build a ``[Mesh]`` block for the given primitive geometry.

    Returns ``(text, boundary_names)``.
    """

    g_type = str(geometry.get("type", "cylinder")).lower()

    if g_type == "cylinder":
        # Annular (thick-walled) cylinder
        OD = float(geometry["OD_mm"]) / 1000.0
        L = float(geometry["L_mm"]) / 1000.0
        wall = float(geometry["wall_mm"]) / 1000.0
        ID = OD - 2.0 * wall
        nx = int(geometry.get("nx", 32))
        ny = int(geometry.get("ny", 8))
        nz = int(geometry.get("nz", 8))
        bnd = ["left", "right", "inner", "outer"]
        block = (
            "[Mesh]\n"
            "  type = GeneratedMesh\n"
            "  dim = 3\n"
            f"  xmin = 0\n  xmax = {L:.6f}\n"
            f"  ymin = {ID/2:.6f}\n  ymax = {OD/2:.6f}\n"
            f"  zmin = 0\n  zmax = {OD/2:.6f}\n"
            f"  nx = {nx}\n  ny = {ny}\n  nz = {nz}\n"
            "  elem_type = HEX8\n"
            "[]\n"
        )
        return block, bnd

    if g_type == "plate":
        Lx = float(geometry["Lx_mm"]) / 1000.0
        Ly = float(geometry["Ly_mm"]) / 1000.0
        Lz = float(geometry.get("thickness_mm", 10.0)) / 1000.0
        nx = int(geometry.get("nx", 20))
        ny = int(geometry.get("ny", 20))
        nz = int(geometry.get("nz", 2))
        bnd = ["left", "right", "top", "bottom", "front", "back"]
        block = (
            "[Mesh]\n"
            "  type = GeneratedMesh\n"
            "  dim = 3\n"
            f"  xmin = 0\n  xmax = {Lx:.6f}\n"
            f"  ymin = 0\n  ymax = {Ly:.6f}\n"
            f"  zmin = 0\n  zmax = {Lz:.6f}\n"
            f"  nx = {nx}\n  ny = {ny}\n  nz = {nz}\n"
            "  elem_type = HEX8\n"
            "[]\n"
        )
        return block, bnd

    if g_type == "block":
        Lx = float(geometry.get("Lx_mm", 100.0)) / 1000.0
        Ly = float(geometry.get("Ly_mm", 100.0)) / 1000.0
        Lz = float(geometry.get("Lz_mm", 100.0)) / 1000.0
        nx = int(geometry.get("nx", 10))
        ny = int(geometry.get("ny", 10))
        nz = int(geometry.get("nz", 10))
        bnd = ["left", "right", "top", "bottom", "front", "back"]
        block = (
            "[Mesh]\n"
            "  type = GeneratedMesh\n"
            "  dim = 3\n"
            f"  xmin = 0\n  xmax = {Lx:.6f}\n"
            f"  ymin = 0\n  ymax = {Ly:.6f}\n"
            f"  zmin = 0\n  zmax = {Lz:.6f}\n"
            f"  nx = {nx}\n  ny = {ny}\n  nz = {nz}\n"
            "  elem_type = HEX8\n"
            "[]\n"
        )
        return block, bnd

    raise ValueError(
        f"Unsupported MOOSE geometry type {g_type!r}; expected "
        "'cylinder', 'plate', or 'block'."
    )


# ---------------------------------------------------------------------------
# Physics → variables / kernels / materials
# ---------------------------------------------------------------------------


def _variables_for_physics(physics: Sequence[str]) -> str:
    """``[Variables]`` block — disp_{x,y,z} and/or temperature."""

    vs: list[str] = []
    needs_mech = "solid_mechanics" in physics or "coupled_th" in physics
    needs_thermal = "heat_conduction" in physics or "coupled_th" in physics

    if needs_mech:
        for axis in ("x", "y", "z"):
            vs.append(f"  [disp_{axis}]\n  []\n")
    if needs_thermal:
        vs.append("  [T]\n    initial_condition = 293.15\n  []\n")

    if "porous_flow" in physics:
        vs.append("  [pp]\n    initial_condition = 1e5\n  []\n")

    if not vs:
        return "[Variables]\n[]\n"
    return "[Variables]\n" + "".join(vs) + "[]\n"


def _kernels_for_physics(physics: Sequence[str]) -> str:
    """``[Kernels]`` block — TensorMechanics + HeatConduction + others."""

    ks: list[str] = []
    if "solid_mechanics" in physics or "coupled_th" in physics:
        ks.append("  [TensorMechanics]\n    displacements = 'disp_x disp_y disp_z'\n  []\n")
    if "heat_conduction" in physics or "coupled_th" in physics:
        ks.append(
            "  [hc]\n    type = HeatConduction\n    variable = T\n  []\n"
            "  [hc_dt]\n    type = HeatConductionTimeDerivative\n    variable = T\n  []\n"
        )
    if "porous_flow" in physics:
        ks.append(
            "  [pf_mass]\n    type = PorousFlowMassTimeDerivative\n    variable = pp\n  []\n"
            "  [pf_flux]\n    type = PorousFlowAdvectiveFlux\n    variable = pp\n  []\n"
        )

    if not ks:
        return "[Kernels]\n[]\n"
    return "[Kernels]\n" + "".join(ks) + "[]\n"


def _materials_for_physics(
    physics: Sequence[str],
    material_name: str,
    props: Mapping[str, float],
) -> str:
    """``[Materials]`` block keyed off the selected physics modules."""

    mat_lines: list[str] = []
    needs_mech = "solid_mechanics" in physics or "coupled_th" in physics
    needs_thermal = "heat_conduction" in physics or "coupled_th" in physics

    if needs_mech:
        E_Pa = props["E_GPa"] * 1e9
        nu = props["nu"]
        mat_lines.append(
            f"  [elasticity_tensor]\n"
            f"    type = ComputeIsotropicElasticityTensor\n"
            f"    youngs_modulus = {E_Pa:.3e}\n"
            f"    poissons_ratio = {nu:.3f}\n"
            f"  []\n"
            f"  [strain]\n"
            f"    type = ComputeSmallStrain\n"
            f"    displacements = 'disp_x disp_y disp_z'\n"
            f"  []\n"
            f"  [stress]\n"
            f"    type = ComputeLinearElasticStress\n"
            f"  []\n"
        )

    if needs_thermal:
        k = props["k_W_mK"]
        rho = props["rho_kg_m3"]
        Cp = props["Cp_J_kgK"]
        mat_lines.append(
            f"  [thermal_conductivity]\n"
            f"    type = GenericConstantMaterial\n"
            f"    prop_names = 'thermal_conductivity specific_heat density'\n"
            f"    prop_values = '{k:.3f} {Cp:.3f} {rho:.3f}'\n"
            f"  []\n"
        )

    if not mat_lines:
        return f"# Material '{material_name}' — no physics requested.\n[Materials]\n[]\n"

    return (
        f"# Material: {material_name}\n"
        f"# E = {props['E_GPa']} GPa  nu = {props['nu']}  rho = {props['rho_kg_m3']} kg/m^3\n"
        f"# k = {props['k_W_mK']} W/m-K  Cp = {props['Cp_J_kgK']} J/kg-K\n"
        f"[Materials]\n" + "".join(mat_lines) + "[]\n"
    )


# ---------------------------------------------------------------------------
# Boundary conditions — accept loose strings like "left: fixed", "right: P_MPa=2.5"
# ---------------------------------------------------------------------------


_BC_FIXED = {"fixed", "clamped", "encastre"}
_BC_FREE = {"free"}


def _write_bcs_block(
    bcs: Mapping[str, str],
    physics: Sequence[str],
    valid_boundaries: Sequence[str],
) -> str:
    """Translate the friendly BC dict into a ``[BCs]`` block."""

    lines: list[str] = []
    needs_mech = "solid_mechanics" in physics or "coupled_th" in physics
    needs_thermal = "heat_conduction" in physics or "coupled_th" in physics

    valid = set(valid_boundaries)

    for boundary, spec in bcs.items():
        if boundary not in valid:
            # Soft-fail — log as a comment so the user can fix it
            lines.append(
                f"  # WARNING: unknown boundary {boundary!r}; "
                f"valid: {sorted(valid)}\n"
            )
            continue
        s = str(spec).strip()
        s_low = s.lower()

        # Fixed-displacement (clamped)
        if s_low in _BC_FIXED and needs_mech:
            for axis in ("x", "y", "z"):
                lines.append(
                    f"  [{boundary}_disp_{axis}]\n"
                    f"    type = DirichletBC\n"
                    f"    variable = disp_{axis}\n"
                    f"    boundary = {boundary}\n"
                    f"    value = 0\n"
                    f"  []\n"
                )
            continue

        if s_low in _BC_FREE:
            continue  # no Dirichlet/Neumann — left implicit

        # Pressure-MPa form: "P_MPa=2.5" or "P=2.5MPa"
        if "p_mpa" in s_low or "p=" in s_low:
            try:
                # extract the numeric portion
                num = "".join(c for c in s if c.isdigit() or c in ".-+e")
                P_Pa = float(num) * 1e6 if "mpa" in s_low else float(num)
            except ValueError:
                P_Pa = 0.0
            lines.append(
                f"  [{boundary}_pressure]\n"
                f"    type = Pressure\n"
                f"    boundary = {boundary}\n"
                f"    displacements = 'disp_x disp_y disp_z'\n"
                f"    factor = {P_Pa:.3e}\n"
                f"  []\n"
            )
            continue

        # Temperature form: "T_K=600" or "T_C=300"
        if "t_k=" in s_low or "t_c=" in s_low:
            try:
                num = float("".join(c for c in s if c.isdigit() or c in ".-+e"))
            except ValueError:
                num = 293.15
            T_K = num if "t_k" in s_low else (num + 273.15)
            if needs_thermal:
                lines.append(
                    f"  [{boundary}_T]\n"
                    f"    type = DirichletBC\n"
                    f"    variable = T\n"
                    f"    boundary = {boundary}\n"
                    f"    value = {T_K:.3f}\n"
                    f"  []\n"
                )
            continue

        # Heat-flux: "q_W_m2=1000"
        if "q_w_m2=" in s_low:
            try:
                num = float("".join(c for c in s if c.isdigit() or c in ".-+e"))
            except ValueError:
                num = 0.0
            if needs_thermal:
                lines.append(
                    f"  [{boundary}_q]\n"
                    f"    type = NeumannBC\n"
                    f"    variable = T\n"
                    f"    boundary = {boundary}\n"
                    f"    value = {num:.3f}\n"
                    f"  []\n"
                )
            continue

        # Unknown — comment it
        lines.append(
            f"  # WARNING: unrecognized BC spec {spec!r} on boundary {boundary!r}\n"
        )

    if not lines:
        return "[BCs]\n[]\n"
    return "[BCs]\n" + "".join(lines) + "[]\n"


# ---------------------------------------------------------------------------
# Executioner — pick Steady / Transient based on physics
# ---------------------------------------------------------------------------


def _write_executioner(physics: Sequence[str], geometry: Mapping[str, Any]) -> str:
    is_transient = (
        "heat_conduction" in physics
        or "coupled_th" in physics
        or "porous_flow" in physics
    )
    if not is_transient:
        return (
            "[Executioner]\n"
            "  type = Steady\n"
            "  solve_type = 'PJFNK'\n"
            "  petsc_options_iname = '-pc_type'\n"
            "  petsc_options_value = 'lu'\n"
            "  nl_rel_tol = 1e-8\n"
            "[]\n"
        )
    end_time = float(geometry.get("end_time_s", 3600.0))
    dt = float(geometry.get("dt_s", end_time / 100.0))
    return (
        "[Executioner]\n"
        "  type = Transient\n"
        "  solve_type = 'PJFNK'\n"
        "  petsc_options_iname = '-pc_type'\n"
        "  petsc_options_value = 'lu'\n"
        f"  end_time = {end_time:.3f}\n"
        f"  dt = {dt:.3f}\n"
        "  nl_rel_tol = 1e-8\n"
        "[]\n"
    )


def _write_outputs() -> str:
    return (
        "[Outputs]\n"
        "  exodus = true\n"
        "  csv = true\n"
        "[]\n"
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def moose_input(
    *,
    geometry: Mapping[str, Any],
    physics: Sequence[str],
    material: str,
    boundary_conditions: Mapping[str, str],
    output_path: Union[str, Path],
    title: Optional[str] = None,
) -> dict[str, Any]:
    """Write a MOOSE ``.i`` input file.

    Args:
        geometry: Dict describing the primitive shape. Supported types
            are ``"cylinder"`` (OD/L/wall + optional nx/ny/nz),
            ``"plate"`` (Lx/Ly/thickness), and ``"block"`` (Lx/Ly/Lz).
            For transient physics you can also pass ``end_time_s`` and
            ``dt_s``.
        physics: Sequence of physics modules — any of
            ``"solid_mechanics"``, ``"heat_conduction"``,
            ``"coupled_th"``, ``"porous_flow"``.
        material: Alloy grade (resolved through a small built-in alias
            map; falls back to SA-516-70 with a clear note if unknown).
        boundary_conditions: Boundary-name → spec string. Specs accepted::

                "fixed" / "clamped" / "encastre"    → Dirichlet 0 on all disp.
                "free"                              → no BC.
                "P_MPa=2.5" / "P=2.5MPa"            → pressure.
                "T_K=600" / "T_C=300"               → temperature Dirichlet.
                "q_W_m2=1000"                       → heat-flux Neumann.

            Unknown boundaries / specs are emitted as inline ``# WARNING``
            comments rather than raising.
        output_path: Where to write the ``.i`` file. Parent directories
            are created as needed.
        title: Optional human title placed in the file header.

    Returns:
        Dict with the canonical material name, the listed physics
        modules, and the ``output_path``.
    """

    canon, props = _lookup_material(material)
    physics = list(physics)
    out_path = Path(output_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    mesh_block, valid_boundaries = _write_mesh_block(geometry)

    header = (
        "# MOOSE input file — generated by Austenite\n"
        f"# Title: {title or canon}\n"
        f"# Material: {canon}\n"
        f"# Physics: {', '.join(physics)}\n"
        "# References:\n"
        "#   Permann C.J. et al., SoftwareX 11 (2020) 100430 — MOOSE.\n"
        "#   Gaston D. et al., Nucl.Eng.Des. 239 (2009) 1768 — base framework.\n"
    )

    body = (
        mesh_block
        + _variables_for_physics(physics)
        + _kernels_for_physics(physics)
        + _materials_for_physics(physics, canon, props)
        + _write_bcs_block(boundary_conditions, physics, valid_boundaries)
        + _write_executioner(physics, geometry)
        + _write_outputs()
    )

    out_path.write_text(header + body, encoding="utf-8")

    return {
        "output_path": out_path,
        "material": canon,
        "physics": physics,
        "valid_boundaries": valid_boundaries,
    }


__all__ = ["moose_input"]
