"""Abaqus standard ``.inp`` input-deck generator.

Abaqus is Dassault Simulia's legacy commercial FEA — the dominant
industrial tool in oil-and-gas, aerospace, and automotive structural
analysis. Its ``.inp`` keyword format is plain ASCII and parseable.

This module composes the canonical block sequence::

    *HEADING
    *NODE
    *ELEMENT
    *NSET / *ELSET
    *MATERIAL → *ELASTIC / *DENSITY / *EXPANSION / *CONDUCTIVITY / *SPECIFIC HEAT
    *SOLID SECTION
    *STEP
        *STATIC | *DYNAMIC | *HEAT TRANSFER
        *BOUNDARY
        *DLOAD / *DSLOAD / *CLOAD
        *OUTPUT
    *END STEP

Three geometry primitives ship: ``cylinder``, ``plate``, ``block``. The
mesh is a simple structured hexahedral grid (Abaqus element type
``C3D8`` / ``C3D8R``).

References:
    * Abaqus Analysis User's Manual, v6.14+, Dassault Systemes Simulia.
    * Abaqus Keywords Reference Manual §1.* — `*HEADING`, `*NODE`,
      `*ELEMENT`, `*MATERIAL`, `*STEP`, `*BOUNDARY`, etc.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping, Optional, Union

from .moose import _MATERIAL_DB, _lookup_material  # reuse the material DB


# ---------------------------------------------------------------------------
# Mesh — structured hex grid for each primitive
# ---------------------------------------------------------------------------


def _build_cylinder_mesh(g: Mapping[str, Any]) -> dict[str, Any]:
    """Generate nodes + C3D8 elements for an annular cylinder.

    Cylinder axis along x; mesh is structured (nθ × nr × nx). Returns
    a mesh dict with nodes / elements / nsets (faces) / element type.
    """

    OD = float(g["OD_mm"]) / 1000.0
    L = float(g["L_mm"]) / 1000.0
    wall = float(g["wall_mm"]) / 1000.0
    ID = OD - 2.0 * wall
    n_theta = int(g.get("n_theta", 24))
    n_r = int(g.get("n_r", 3))
    n_x = int(g.get("n_x", 20))

    import math
    nodes: list[tuple[int, float, float, float]] = []
    nid = 1
    # Map (i_x, i_r, i_th) → node id
    idx_of: dict[tuple[int, int, int], int] = {}
    for i_x in range(n_x + 1):
        x = (i_x / n_x) * L
        for i_r in range(n_r + 1):
            r = ID / 2.0 + (i_r / n_r) * wall
            for i_th in range(n_theta):
                th = 2.0 * math.pi * (i_th / n_theta)
                y = r * math.cos(th)
                z = r * math.sin(th)
                nodes.append((nid, x, y, z))
                idx_of[(i_x, i_r, i_th)] = nid
                nid += 1

    elements: list[tuple[int, int, int, int, int, int, int, int, int]] = []
    eid = 1
    for i_x in range(n_x):
        for i_r in range(n_r):
            for i_th in range(n_theta):
                jt = (i_th + 1) % n_theta
                # 8-node hex, Abaqus C3D8 ordering: bottom face CCW, then top.
                n1 = idx_of[(i_x,     i_r,     i_th)]
                n2 = idx_of[(i_x,     i_r,     jt  )]
                n3 = idx_of[(i_x,     i_r + 1, jt  )]
                n4 = idx_of[(i_x,     i_r + 1, i_th)]
                n5 = idx_of[(i_x + 1, i_r,     i_th)]
                n6 = idx_of[(i_x + 1, i_r,     jt  )]
                n7 = idx_of[(i_x + 1, i_r + 1, jt  )]
                n8 = idx_of[(i_x + 1, i_r + 1, i_th)]
                elements.append((eid, n1, n2, n3, n4, n5, n6, n7, n8))
                eid += 1

    # Define standard face-node sets so BCs can address them.
    nsets: dict[str, list[int]] = {
        "LEFT":  [idx_of[(0,   ir, it)] for ir in range(n_r + 1) for it in range(n_theta)],
        "RIGHT": [idx_of[(n_x, ir, it)] for ir in range(n_r + 1) for it in range(n_theta)],
        "INNER": [idx_of[(ix, 0, it)] for ix in range(n_x + 1) for it in range(n_theta)],
        "OUTER": [idx_of[(ix, n_r, it)] for ix in range(n_x + 1) for it in range(n_theta)],
        "ALLNODES": [n for n in range(1, nid)],
    }

    # Element sets on the inside/outside surfaces for pressure loads.
    elsets: dict[str, list[int]] = {
        "ALLELEMENTS": list(range(1, eid)),
    }

    return {
        "nodes": nodes,
        "elements": elements,
        "nsets": nsets,
        "elsets": elsets,
        "elem_type": "C3D8",
        "geom_kind": "cylinder",
        "geom_params": {"OD": OD, "L": L, "wall": wall},
    }


def _build_box_mesh(
    g: Mapping[str, Any],
    *,
    is_plate: bool = False,
) -> dict[str, Any]:
    """Generate nodes + C3D8 elements for a box / plate.

    Returns the same dict shape as :func:`_build_cylinder_mesh`.
    """

    if is_plate:
        Lx = float(g["Lx_mm"]) / 1000.0
        Ly = float(g["Ly_mm"]) / 1000.0
        Lz = float(g.get("thickness_mm", 10.0)) / 1000.0
    else:
        Lx = float(g.get("Lx_mm", 100.0)) / 1000.0
        Ly = float(g.get("Ly_mm", 100.0)) / 1000.0
        Lz = float(g.get("Lz_mm", 100.0)) / 1000.0
    nx = int(g.get("nx", 10))
    ny = int(g.get("ny", 10))
    nz = int(g.get("nz", 4 if is_plate else 10))

    nodes: list[tuple[int, float, float, float]] = []
    nid = 1
    idx_of: dict[tuple[int, int, int], int] = {}
    for ix in range(nx + 1):
        x = (ix / nx) * Lx
        for iy in range(ny + 1):
            y = (iy / ny) * Ly
            for iz in range(nz + 1):
                z = (iz / nz) * Lz
                nodes.append((nid, x, y, z))
                idx_of[(ix, iy, iz)] = nid
                nid += 1

    elements: list[tuple[int, int, int, int, int, int, int, int, int]] = []
    eid = 1
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                n1 = idx_of[(ix,     iy,     iz)]
                n2 = idx_of[(ix + 1, iy,     iz)]
                n3 = idx_of[(ix + 1, iy + 1, iz)]
                n4 = idx_of[(ix,     iy + 1, iz)]
                n5 = idx_of[(ix,     iy,     iz + 1)]
                n6 = idx_of[(ix + 1, iy,     iz + 1)]
                n7 = idx_of[(ix + 1, iy + 1, iz + 1)]
                n8 = idx_of[(ix,     iy + 1, iz + 1)]
                elements.append((eid, n1, n2, n3, n4, n5, n6, n7, n8))
                eid += 1

    nsets = {
        "LEFT":   [idx_of[(0,  iy, iz)] for iy in range(ny + 1) for iz in range(nz + 1)],
        "RIGHT":  [idx_of[(nx, iy, iz)] for iy in range(ny + 1) for iz in range(nz + 1)],
        "FRONT":  [idx_of[(ix, 0,  iz)] for ix in range(nx + 1) for iz in range(nz + 1)],
        "BACK":   [idx_of[(ix, ny, iz)] for ix in range(nx + 1) for iz in range(nz + 1)],
        "BOTTOM": [idx_of[(ix, iy, 0 )] for ix in range(nx + 1) for iy in range(ny + 1)],
        "TOP":    [idx_of[(ix, iy, nz)] for ix in range(nx + 1) for iy in range(ny + 1)],
        "ALLNODES": list(range(1, nid)),
    }
    elsets = {"ALLELEMENTS": list(range(1, eid))}

    return {
        "nodes": nodes,
        "elements": elements,
        "nsets": nsets,
        "elsets": elsets,
        "elem_type": "C3D8",
        "geom_kind": "plate" if is_plate else "block",
        "geom_params": {"Lx": Lx, "Ly": Ly, "Lz": Lz},
    }


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------


def _write_node_block(nodes: list[tuple[int, float, float, float]]) -> str:
    lines = ["*NODE"]
    for n, x, y, z in nodes:
        lines.append(f"{n}, {x:.6e}, {y:.6e}, {z:.6e}")
    return "\n".join(lines) + "\n"


def _write_element_block(
    elements: list[tuple[int, int, int, int, int, int, int, int, int]],
    elem_type: str,
) -> str:
    lines = [f"*ELEMENT, TYPE={elem_type}, ELSET=ALLELEMENTS"]
    for row in elements:
        eid, *nids = row
        lines.append(f"{eid}, " + ", ".join(str(n) for n in nids))
    return "\n".join(lines) + "\n"


def _write_set_block(name: str, ids: list[int], kind: str) -> str:
    """``*NSET`` or ``*ELSET`` keyword with the comma-formatted ID list.

    Abaqus likes a maximum of 16 entries per row.
    """

    if not ids:
        return ""
    head = f"*{kind}, {kind}={name}\n"
    rows: list[str] = []
    for i in range(0, len(ids), 16):
        chunk = ids[i : i + 16]
        rows.append(", ".join(str(x) for x in chunk))
    return head + "\n".join(rows) + "\n"


def _write_material_block(name: str, props: Mapping[str, float]) -> str:
    """``*MATERIAL`` + ``*ELASTIC`` + ``*DENSITY`` (+ thermal if present)."""

    safe = "".join(c for c in name if c.isalnum() or c in "-_") or "AUSTENITE_MAT"
    E_Pa = props["E_GPa"] * 1e9
    nu = props["nu"]
    rho = props["rho_kg_m3"]

    lines = [
        f"*MATERIAL, NAME={safe}",
        "*ELASTIC",
        f"{E_Pa:.3e}, {nu:.3f}",
        "*DENSITY",
        f"{rho:.3f},",
    ]
    if "k_W_mK" in props:
        lines += ["*CONDUCTIVITY", f"{props['k_W_mK']:.3f},"]
    if "Cp_J_kgK" in props:
        lines += ["*SPECIFIC HEAT", f"{props['Cp_J_kgK']:.3f},"]
    if "alpha_e6_per_K" in props:
        lines += ["*EXPANSION", f"{props['alpha_e6_per_K'] * 1e-6:.3e},"]
    return "\n".join(lines) + "\n"


def _write_section_block(material_name: str) -> str:
    safe = "".join(c for c in material_name if c.isalnum() or c in "-_") or "AUSTENITE_MAT"
    return (
        f"*SOLID SECTION, ELSET=ALLELEMENTS, MATERIAL={safe}\n"
        ",\n"
    )


def _write_step_block(
    physics: str,
    mesh: dict[str, Any],
    bcs: Mapping[str, str],
) -> str:
    """Build the ``*STEP`` block — Static / Dynamic / Heat Transfer."""

    physics_l = physics.lower()
    if physics_l == "static":
        step_kw = "*STATIC"
        step_init = "1.0, 1.0, 1.0e-6, 1.0"
    elif physics_l in ("dynamic", "implicit_dynamic"):
        step_kw = "*DYNAMIC"
        step_init = "0.01, 1.0, 1.0e-5, 0.1"
    elif physics_l in ("heat", "heat_transfer", "thermal"):
        step_kw = "*HEAT TRANSFER, STEADY STATE"
        step_init = "1.0, 1.0, 1.0e-6, 1.0"
    elif physics_l in ("coupled_th", "coupled"):
        step_kw = "*COUPLED TEMPERATURE-DISPLACEMENT"
        step_init = "1.0, 1.0, 1.0e-6, 1.0"
    else:
        step_kw = "*STATIC"
        step_init = "1.0, 1.0, 1.0e-6, 1.0"

    lines: list[str] = ["*STEP, NAME=Step-1, NLGEOM=NO", step_kw, step_init]

    # Boundary section
    bound_lines: list[str] = ["*BOUNDARY"]
    dload_lines: list[str] = []

    valid_nsets = set(mesh["nsets"].keys())

    for boundary, spec in bcs.items():
        b = boundary.upper()
        if b not in valid_nsets:
            lines.append(f"** WARNING: unknown boundary {boundary!r}; "
                         f"valid: {sorted(valid_nsets)}")
            continue
        s = str(spec).strip().lower()

        if s in ("fixed", "clamped", "encastre"):
            # ENCASTRE = all 6 DOF clamped (but solid elements have 3)
            bound_lines.append(f"{b}, 1, 3, 0.0")
            continue
        if s == "free":
            continue
        if "p_mpa" in s or "p=" in s:
            try:
                num = float("".join(c for c in spec if c.isdigit() or c in ".-+e"))
            except ValueError:
                num = 0.0
            P_Pa = num * 1e6 if "mpa" in s else num
            # Translate boundary → element-surface label
            # For our hex meshes, use *DSLOAD with the relevant surface
            dload_lines.append(
                f"** Pressure on {b}: {P_Pa:.3e} Pa"
            )
            dload_lines.append(f"*DSLOAD")
            dload_lines.append(f"{b}, P, {P_Pa:.3e}")
            continue
        if "u_mm=" in s or "ux_mm=" in s or "uy_mm=" in s or "uz_mm=" in s:
            try:
                num = float("".join(c for c in spec if c.isdigit() or c in ".-+e"))
            except ValueError:
                num = 0.0
            U_m = num / 1000.0  # mm → m
            axis = 1
            if "uy" in s:
                axis = 2
            elif "uz" in s:
                axis = 3
            bound_lines.append(f"{b}, {axis}, {axis}, {U_m:.6e}")
            continue
        if "t_k=" in s or "t_c=" in s:
            try:
                num = float("".join(c for c in spec if c.isdigit() or c in ".-+e"))
            except ValueError:
                num = 293.15
            T_K = num if "t_k" in s else num + 273.15
            bound_lines.append(f"{b}, 11, 11, {T_K:.3f}")  # NT11 nodal temperature
            continue
        lines.append(f"** WARNING: unrecognized BC {spec!r} on {boundary!r}")

    if len(bound_lines) > 1:
        lines.extend(bound_lines)
    lines.extend(dload_lines)

    # Output requests
    lines += [
        "*OUTPUT, FIELD, FREQUENCY=1",
        "*NODE OUTPUT",
        "U, RF",
        "*ELEMENT OUTPUT",
        "S, E, PEEQ",
        "*OUTPUT, HISTORY, FREQUENCY=1",
        "*NODE OUTPUT, NSET=ALLNODES",
        "U,",
        "*END STEP",
    ]
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def abaqus_inp(
    *,
    geometry: Mapping[str, Any],
    material: str,
    physics: str = "static",
    boundary_conditions: Optional[Mapping[str, str]] = None,
    output_path: Union[str, Path],
    title: Optional[str] = None,
) -> dict[str, Any]:
    """Write an Abaqus standard ``.inp`` deck.

    Args:
        geometry: Primitive shape spec. Same keys as the MOOSE exporter
            (``type``: ``cylinder`` | ``plate`` | ``block``). Cylinder
            takes ``OD_mm`` / ``L_mm`` / ``wall_mm``; plate takes
            ``Lx_mm`` / ``Ly_mm`` / ``thickness_mm``; block takes
            ``Lx_mm`` / ``Ly_mm`` / ``Lz_mm``. Mesh resolution: ``n_x``,
            ``n_r``, ``n_theta`` (cylinder) or ``nx``/``ny``/``nz``.
        material: Alloy grade. Resolved via the same alias map as the
            MOOSE exporter — accepts ``"SA-516-70"``, ``"Inconel 718"``,
            etc. Unknown grades fall back to SA-516-70 with a note.
        physics: Step type — ``"static"`` (default), ``"dynamic"``,
            ``"heat_transfer"``, or ``"coupled_th"``.
        boundary_conditions: Optional mapping of named face → spec.
            Face names use upper-case (``LEFT``, ``RIGHT``, ``INNER``,
            ``OUTER``, ``TOP``, ``BOTTOM``, ``FRONT``, ``BACK``).
            Specs accepted::

                "fixed"            → Encastre (clamped, DOF 1-3 = 0).
                "free"             → no BC.
                "P_MPa=2.5"        → *DSLOAD surface pressure.
                "Ux_mm=0.5"        → enforced displacement in axis x.
                "T_K=600"          → nodal temperature (heat-step only).

        output_path: Where to write the ``.inp`` file. Parent dirs created.
        title: Optional header title.

    Returns:
        Dict with::

            {
                "output_path":  pathlib.Path,
                "material":     canonical name str,
                "n_nodes":      int,
                "n_elements":   int,
                "elem_type":    "C3D8",
                "geom_kind":    "cylinder" | "plate" | "block",
            }
    """

    canon, props = _lookup_material(material)
    g_type = str(geometry.get("type", "cylinder")).lower()
    if g_type == "cylinder":
        mesh = _build_cylinder_mesh(geometry)
    elif g_type == "plate":
        mesh = _build_box_mesh(geometry, is_plate=True)
    elif g_type == "block":
        mesh = _build_box_mesh(geometry, is_plate=False)
    else:
        raise ValueError(
            f"Unsupported Abaqus geometry type {g_type!r}; expected "
            "'cylinder', 'plate', or 'block'."
        )

    bcs = dict(boundary_conditions or {})

    out_path = Path(output_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    parts: list[str] = []
    parts.append(
        "*HEADING\n"
        f"Austenite-generated Abaqus deck — {title or canon}\n"
        f"** Material: {canon}\n"
        f"** Geometry: {mesh['geom_kind']} {mesh['geom_params']}\n"
        f"** Physics: {physics}\n"
        "** References: Abaqus Analysis User's Manual (Dassault Systemes Simulia)\n"
        f"*PREPRINT, ECHO=NO, MODEL=NO, HISTORY=NO\n"
    )
    parts.append(_write_node_block(mesh["nodes"]))
    parts.append(_write_element_block(mesh["elements"], mesh["elem_type"]))

    # Node sets
    for name, ids in mesh["nsets"].items():
        parts.append(_write_set_block(name, ids, "NSET"))
    # Element sets
    for name, ids in mesh["elsets"].items():
        parts.append(_write_set_block(name, ids, "ELSET"))

    parts.append(_write_material_block(canon, props))
    parts.append(_write_section_block(canon))
    parts.append(_write_step_block(physics, mesh, bcs))

    out_path.write_text("".join(parts), encoding="utf-8")

    return {
        "output_path": out_path,
        "material": canon,
        "n_nodes": len(mesh["nodes"]),
        "n_elements": len(mesh["elements"]),
        "elem_type": mesh["elem_type"],
        "geom_kind": mesh["geom_kind"],
    }


__all__ = ["abaqus_inp"]
