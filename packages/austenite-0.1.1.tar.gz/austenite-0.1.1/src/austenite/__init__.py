"""Austenite — Bayesian end-to-end materials engineering.

Top-level convenience::

    import austenite as au
    r = au.design_path(alloy="AISI 4140", cooling_rate=10)

Namespaced operations stay grouped::

    au.am.qualification(...)
    au.mtc.parse(...)
    au.ttt.compute(...)
    au.calphad.equilibrium(...)
    au.bayesian.calphad(...)
    au.bayesian.calphad_deep(dataset="hammar-1979-sigma", chains=4)
    au.compliance.bayesian_p_pass(state=post, spec="ASME II-D SA-516-70",
                                  T_C=400, target_sigma_y_MPa=380)
    au.calibrate(pretrained="austenite/4140-baseline-v0.1",
                 observations="./mill_X_2024.csv")

Configuration::

    au.set_api_url("https://api.austenite.org")
    au.set_timeout(30)
    au.set_api_key("sk-...")
"""

from __future__ import annotations

from typing import Optional

# Sub-namespaces — imported as attributes so users get `au.am.qualification`.
from . import am as am
from . import audit as audit
from . import bayesian as bayesian
from . import benchmark as benchmark
from . import calphad as calphad
from . import compliance as compliance
from . import data as data
from . import fatigue as fatigue
from . import ffs as ffs
from . import io as io  # noqa: A004 — shadows stdlib io but distinct namespace
from . import ml as ml
from . import mtc as mtc
from . import plugins as plugins
from . import rbi as rbi
from . import reliability as reliability
from . import ttt as ttt
from . import wps as wps

# Advanced-capability modules — Tier 1/2/3 push
from . import active_learning as active_learning
from . import ams_heat_treat as ams_heat_treat
from . import am_planner as am_planner
from . import api581_scenarios as api581_scenarios
from . import asme_iii as asme_iii
from . import busbar_designer as busbar_designer
from . import creep_pinn as creep_pinn
from . import icme_monte_carlo as icme_monte_carlo
from . import inverse_heat_treat as inverse_heat_treat
from . import lca as lca
from . import nace_mr0175 as nace_mr0175
from . import pbf_screening as pbf_screening
from . import phase_field_grain as phase_field_grain
from . import ttt_cct as ttt_cct
from . import welding_distortion as welding_distortion
from . import wps_generator as wps_generator

# Exceptions
from ._exceptions import (
    AusteniteError,
    EngineError,
    NetworkError,
    RateLimitError,
    ValidationError,
)

# Models — re-exported so callers can isinstance-check / build inputs.
from ._models import (
    AmQualificationInput,
    AmQualificationResult,
    AmSweepInput,
    AmSweepPoint,
    AmSweepResult,
    AuditRecordInput,
    AuditRecordResult,
    AuditReplayInput,
    AuditReplayResult,
    BayesianCalphadDeepInput,
    BayesianCalphadDeepResult,
    BayesianCalphadInput,
    BayesianCalphadResult,
    CalibrateInput,
    CalibrateObservations,
    CalibrateResult,
    CalphadEquilibriumInput,
    CalphadEquilibriumResult,
    CalphadTernaryInput,
    CalphadTernaryResult,
    CctSweepInput,
    CctSweepResult,
    Citation,
    ComplianceBayesianPPassInput,
    ComplianceBayesianPPassResult,
    ComplianceBayesianPPassState,
    ComplianceVerdict,
    DesignPathInput,
    DesignPathResult,
    HpdInterval,
    MtcDetectGradeInput,
    MtcDetectGradeResult,
    MtcParseInput,
    MtcParseResult,
    PhaseFraction,
    PosteriorBand,
    PosteriorPredictive,
    Properties,
    TttComputeInput,
    TttComputeResult,
    TttCurve,
)

# Client + config primitives.
from ._client import AsyncClient, Client, get_default_client, reset_default_client
from ._config import get_config

# Top-level convenience.
from .calibrate import ShopPrior, calibrate
from .design_path import design_path

# Re-export AuditReport so callers can isinstance-check.
from .mtc import AuditReport as AuditReport

# Re-export new audit / edition-diff types so callers can isinstance-check.
from .audit import ReplayMismatchError, VerifyReport
from .compliance_editions import (
    DiffReport as DiffReport,
    EditionChange as EditionChange,
    RecheckDetail as RecheckDetail,
    RecheckReport as RecheckReport,
)
from .compliance_standards import StandardVerdict as StandardVerdict
from .plugins import PluginManifest as PluginManifest

__all__ = [
    # Convenience function
    "design_path",
    "calibrate",
    # Sub-namespaces
    "am",
    "audit",
    "bayesian",
    "benchmark",
    "calphad",
    "compliance",
    "coverage",
    "cross_database",
    "data",
    "diagnostics",
    "ebsd_3d",
    "explain",
    "export",
    "fatigue",
    "ffs",
    "io",
    "ml",
    "mtc",
    "multi_nozzle_vessel",
    "plugins",
    "profile",
    "rbi",
    "reliability",
    "ttt",
    "validate",
    "wps",
    # Setters
    "set_api_url",
    "set_timeout",
    "set_api_key",
    "set_max_retries",
    # Clients
    "Client",
    "AsyncClient",
    "get_default_client",
    "reset_default_client",
    # Exceptions
    "AusteniteError",
    "EngineError",
    "NetworkError",
    "RateLimitError",
    "ValidationError",
    # Models (input)
    "AmQualificationInput",
    "AmSweepInput",
    "AuditRecordInput",
    "AuditReplayInput",
    "BayesianCalphadInput",
    "BayesianCalphadDeepInput",
    "CalibrateInput",
    "CalibrateObservations",
    "CalphadEquilibriumInput",
    "CalphadTernaryInput",
    "CctSweepInput",
    "ComplianceBayesianPPassInput",
    "ComplianceBayesianPPassState",
    "DesignPathInput",
    "MtcDetectGradeInput",
    "MtcParseInput",
    "TttComputeInput",
    # Models (output)
    "AmQualificationResult",
    "AmSweepPoint",
    "AmSweepResult",
    "AuditRecordResult",
    "AuditReplayResult",
    "BayesianCalphadResult",
    "BayesianCalphadDeepResult",
    "CalibrateResult",
    "CalphadEquilibriumResult",
    "CalphadTernaryResult",
    "CctSweepResult",
    "ComplianceBayesianPPassResult",
    "DesignPathResult",
    "MtcDetectGradeResult",
    "MtcParseResult",
    "TttComputeResult",
    # Batch / audit
    "AuditReport",
    "ReplayMismatchError",
    "VerifyReport",
    # Edition diff
    "DiffReport",
    "EditionChange",
    "RecheckDetail",
    "RecheckReport",
    # Plugin / standard verdict
    "PluginManifest",
    "StandardVerdict",
    # Shop calibration
    "ShopPrior",
    # Models (shared)
    "Citation",
    "ComplianceVerdict",
    "HpdInterval",
    "PhaseFraction",
    "PosteriorBand",
    "PosteriorPredictive",
    "Properties",
    "TttCurve",
]

__version__ = "0.1.0"


# ---------------------------------------------------------------------------
# Configuration setters — each one resets the default client so the new
# value takes effect on the next call.
# ---------------------------------------------------------------------------


def set_api_url(url: str) -> None:
    """Override the base URL of the Austenite API."""

    get_config().api_url = url.rstrip("/")
    reset_default_client()


def set_timeout(seconds: float) -> None:
    """Override the default per-request timeout (seconds)."""

    get_config().timeout = float(seconds)
    reset_default_client()


def set_api_key(api_key: Optional[str]) -> None:
    """Set (or clear) the bearer token used for API authentication."""

    get_config().api_key = api_key
    reset_default_client()


def set_max_retries(n: int) -> None:
    """Set the maximum number of retries for transient failures."""

    if n < 1:
        raise ValueError("max_retries must be >= 1")
    get_config().max_retries = int(n)
    reset_default_client()


# ---------------------------------------------------------------------------
# JAX backend — optional, lazily imported. ``import austenite`` does not
# pull JAX in. Accessing ``austenite.jax_backend``, ``au.design_path_jax``
# etc. triggers the import; if JAX is missing the user gets a friendly
# ``ImportError`` from ``austenite.jax_backend.__init__``.
# ---------------------------------------------------------------------------

_JAX_ATTRS = frozenset(
    {
        "jax_backend",
        "design_path_jax",
        "am_qualification_jax",
        "design_jax",
        "design_hybrid",
        "set_jax_backend",
        # JAX-traceable engines (CALPHAD / melt-pool / FAD)
        "calphad_equilibrium_jax",
        "meltpool_rosenthal_jax",
        "meltpool_eagar_tsai_jax",
        "meltpool_goldak_jax",
        "fad_2a_jax",
        "in718_props",
        "ti64_props",
        "ss316_props",
    }
)

# Lazily-loaded sub-modules — keep optional heavy deps off the import path.
# Engineer-UX modules are lazy too so a bare ``import austenite`` stays
# fast even on import-cost-sensitive call sites (Excel xlwings, etc.).
_LAZY_MODULES = frozenset({
    "rbi_streaming",
    "surrogates",
    "diagnostics",
    "explain",
    "cross_database",
    "coverage",
    "validate",
    "multi_nozzle_vessel",
    # FEA-deck exporters + perf profiler (added 2026-05-19)
    "export",
    "profile",
    # 3-D EBSD reconstruction + 5-DOF GB property graph (research-grade moat)
    "ebsd_3d",
    # Physics suites (lazy so `au.corrosion`, `au.welding`, ... resolve)
    "corrosion",
    "welding",
    "tribology",
    "forming",
    "casting",
    "cyclic_plasticity",
    "thermophysics",
    "liquid_metal",
    "tmp",
    "kinetics",
})
# Convenience top-level names re-exported from the lazy sub-modules.
_LAZY_CONVENIENCE: dict = {
    "create_asset": ("rbi_streaming", "create_asset"),
    # MatSci ecosystem bridges (2026-05-19)
    "materials_project": ("io.materials_project", None),
}


def __getattr__(name: str):  # type: ignore[no-untyped-def]
    if name in _JAX_ATTRS:
        import importlib

        # Use importlib.import_module so we never re-enter this __getattr__
        # via a ``from . import jax_backend`` round-trip.
        jax_backend = importlib.import_module(".jax_backend", __name__)
        if name == "jax_backend":
            return jax_backend
        return getattr(jax_backend, name)
    if name in _LAZY_MODULES:
        import importlib

        mod = importlib.import_module(f".{name}", __name__)
        globals()[name] = mod
        return mod
    if name in _LAZY_CONVENIENCE:
        import importlib

        mod_name, attr = _LAZY_CONVENIENCE[name]
        mod = importlib.import_module(f".{mod_name}", __name__)
        # If attr is None we expose the module itself (e.g. au.materials_project).
        value = mod if attr is None else getattr(mod, attr)
        globals()[name] = value
        return value
    raise AttributeError(f"module 'austenite' has no attribute {name!r}")


def __dir__() -> list[str]:
    return sorted(
        list(globals().keys())
        + list(_JAX_ATTRS)
        + list(_LAZY_MODULES)
        + list(_LAZY_CONVENIENCE.keys())
    )
