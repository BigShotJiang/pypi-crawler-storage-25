"""Multi-language element-name aliases and language-detection heuristics.

A typical steel mill receiving incoming material certs sees 7+ languages
(EN/DE/IT/ES/JA/KO/ZH). Tesseract OSD can identify the script, but the
post-OCR text still uses the local element name ("Kohlenstoff" not "C").

This module provides:

* :data:`ELEMENT_ALIASES` — symbol → list of localised names
* :func:`alias_to_symbol` — reverse lookup (case-insensitive)
* :data:`LANGUAGE_KEYWORDS` — header tokens that indicate the cert language
* :func:`detect_language` — scan a text blob and guess the language code
* :data:`LANG_TO_TESSERACT` — map of ISO codes → tesseract language packs
"""

from __future__ import annotations

from typing import Mapping, Optional


# Each alias list is ordered: [English, German, Italian, Spanish,
# Japanese, Korean, Simplified-Chinese].
ELEMENT_ALIASES: Mapping[str, list[str]] = {
    "C":  ["Carbon", "Kohlenstoff", "Carbonio", "Carbono", "炭素", "탄소", "碳"],
    "Mn": ["Manganese", "Mangan", "Manganese", "Manganeso", "マンガン", "망간", "锰"],
    "Cr": ["Chromium", "Chrom", "Cromo", "Cromo", "クロム", "크로뮴", "铬"],
    "Ni": ["Nickel", "Nickel", "Nichel", "Níquel", "ニッケル", "니켈", "镍"],
    "Mo": ["Molybdenum", "Molybdän", "Molibdeno", "Molibdeno", "モリブデン", "몰리브덴", "钼"],
    "Si": ["Silicon", "Silizium", "Silicio", "Silicio", "ケイ素", "규소", "硅"],
    "P":  ["Phosphorus", "Phosphor", "Fosforo", "Fósforo", "リン", "인", "磷"],
    "S":  ["Sulfur", "Schwefel", "Zolfo", "Azufre", "硫黄", "황", "硫"],
    "Cu": ["Copper", "Kupfer", "Rame", "Cobre", "銅", "구리", "铜"],
    "V":  ["Vanadium", "Vanadium", "Vanadio", "Vanadio", "バナジウム", "바나듐", "钒"],
    "W":  ["Tungsten", "Wolfram", "Tungsteno", "Tungsteno", "タングステン", "텅스텐", "钨"],
    "Co": ["Cobalt", "Kobalt", "Cobalto", "Cobalto", "コバルト", "코발트", "钴"],
    "Al": ["Aluminum", "Aluminium", "Alluminio", "Aluminio", "アルミニウム", "알루미늄", "铝"],
    "Nb": ["Niobium", "Niob", "Niobio", "Niobio", "ニオブ", "나이오븀", "铌"],
    "Ti": ["Titanium", "Titan", "Titanio", "Titanio", "チタン", "타이타늄", "钛"],
    "B":  ["Boron", "Bor", "Boro", "Boro", "ホウ素", "붕소", "硼"],
    "N":  ["Nitrogen", "Stickstoff", "Azoto", "Nitrógeno", "窒素", "질소", "氮"],
    "Fe": ["Iron", "Eisen", "Ferro", "Hierro", "鉄", "철", "铁"],
}


# ── Reverse lookup ──
def _build_reverse() -> dict[str, str]:
    """Build a lowercase alias → symbol map."""
    out: dict[str, str] = {}
    for symbol, aliases in ELEMENT_ALIASES.items():
        out[symbol.lower()] = symbol  # symbol itself
        for alias in aliases:
            out[alias.lower()] = symbol
    return out


_REVERSE_ALIASES: dict[str, str] = _build_reverse()


def alias_to_symbol(token: str) -> Optional[str]:
    """Map a single token (any language) to its periodic-table symbol.

    Returns ``None`` if the token is not a known element name.
    """
    if not token:
        return None
    return _REVERSE_ALIASES.get(token.strip().lower())


# ── Language detection ──
# Header keywords engineers immediately recognise. Most certs start with
# at least one of these in the language they were issued in.
LANGUAGE_KEYWORDS: Mapping[str, list[str]] = {
    "en": [
        "Material", "Heat", "Certificate", "Grade", "Specification",
        "Chemical Analysis", "Mill Test Report", "Mechanical Properties",
    ],
    "de": [
        "Werkstoff", "Werkstoffnummer", "Schmelze", "Zeugnis", "Güte",
        "Spezifikation", "Chemische Zusammensetzung", "Abnahmeprüfzeugnis",
        "Schmelznummer",
    ],
    "it": [
        "Materiale", "Colata", "Certificato", "Specifica", "Composizione chimica",
        "Proprietà meccaniche", "Qualità",
    ],
    "es": [
        "Material", "Colada", "Certificado", "Especificación", "Composición química",
        "Propiedades mecánicas", "Calidad",
    ],
    "ja": [
        "材料", "ヒート", "証明書", "鋼種", "仕様", "化学成分", "機械的性質",
        "ミルシート",
    ],
    "ko": [
        "재질", "히트", "증명서", "강종", "사양", "화학성분", "기계적성질",
        "시험성적서",
    ],
    "zh": [
        "材料", "炉号", "证书", "牌号", "规格", "化学成分", "机械性能",
        "材质", "钢种",
    ],
}


# Map of ISO 639-1 language code → tesseract language pack name. Most
# packs follow ISO 639-2/T; use these when calling pytesseract.
LANG_TO_TESSERACT: Mapping[str, str] = {
    "en": "eng",
    "de": "deu",
    "it": "ita",
    "es": "spa",
    "ja": "jpn",
    "ko": "kor",
    "zh": "chi_sim",
}


def detect_language(text: str, *, allowed: Optional[list[str]] = None) -> str:
    """Guess the language of an MTC by scoring keyword hits.

    Args:
        text: The (typically OCR'd or extracted) raw text.
        allowed: Optional whitelist — e.g. a steel mill may only accept
            certs from countries it actually buys from. If supplied,
            languages outside the list score zero.

    Returns the best ISO 639-1 code (``"en"`` default if no hits).
    """
    if not text:
        return "en"
    sample = text[:4096]  # header is enough; saves CPU on 1000-cert batches
    scores: dict[str, int] = {lang: 0 for lang in LANGUAGE_KEYWORDS}
    for lang, words in LANGUAGE_KEYWORDS.items():
        if allowed and lang not in allowed:
            continue
        for w in words:
            if w in sample:
                scores[lang] += 1
    # CJK gets a tie-breaker bonus from having any of its characters at all
    cjk_bonus = {
        "ja": sum(1 for c in sample if 0x3040 <= ord(c) <= 0x30FF),
        "ko": sum(1 for c in sample if 0xAC00 <= ord(c) <= 0xD7AF),
        "zh": sum(1 for c in sample if 0x4E00 <= ord(c) <= 0x9FFF),
    }
    for lang, bonus in cjk_bonus.items():
        if allowed and lang not in allowed:
            continue
        if bonus > 5:
            # CJK chars score 1 per 10, capped at 5
            scores[lang] += min(bonus // 10, 5)

    best_lang = max(scores, key=lambda k: scores[k])
    if scores[best_lang] == 0:
        return "en"
    return best_lang


def translate_element_tokens(text: str) -> str:
    """Replace localised element names with their periodic-table symbols.

    This is a tiny preprocessing step so the existing English-only
    server-side parser can recognise multi-language certs. We replace
    each alias with " <SYMBOL> " (padded with spaces so token-level
    parsers still see distinct words).

    Longer aliases are processed first to avoid partial-string conflicts
    (e.g. "Stickstoff" must replace before "Stick" if it ever appeared
    as a separate alias).
    """
    if not text:
        return text
    pairs: list[tuple[str, str]] = []
    for symbol, aliases in ELEMENT_ALIASES.items():
        for alias in aliases:
            if alias == symbol:
                continue
            pairs.append((alias, symbol))
    # Sort by length descending so longer aliases replace before substrings.
    pairs.sort(key=lambda p: -len(p[0]))
    out = text
    for alias, symbol in pairs:
        if alias in out:
            out = out.replace(alias, f" {symbol} ")
    return out


__all__ = [
    "ELEMENT_ALIASES",
    "LANGUAGE_KEYWORDS",
    "LANG_TO_TESSERACT",
    "alias_to_symbol",
    "detect_language",
    "translate_element_tokens",
]
