"""Powder-bed-fusion melt-pool screening — process-window mapper.

Sweeps (P, v) grid through Rosenthal + Eagar-Tsai + King 2014 normalized
enthalpy + Tang LoF criterion to draw the **lack-of-fusion / keyhole /
balling / conduction-mode** map for a given alloy and machine.

Returns dense numpy-array map ready for matplotlib contour plotting.

References:
    * Rosenthal D., Trans. ASME 68 (1946) 849.
    * Eagar T.W., Tsai N.S., Weld. J. 62 (1983) 346.
    * King W.E. et al., J. Mater. Proc. Tech. 214 (2014) 2915.
    * Tang M., Pistorius P.C., Beuth J.L., Addit. Manuf. 14 (2017) 39.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from .am_planner import (
    AlloyProperties, MachineSpec,
    keyhole_probability, lack_of_fusion_probability,
    normalized_enthalpy, rosenthal_melt_pool_depth_um,
)


@dataclass
class ProcessWindow:
    """Sweep result + recommended operating point."""

    P_grid_W: list
    v_grid_mm_s: list
    pof_map: list  # 2-D list-of-lists [iP][iv]
    regime_map: list  # 2-D list of strings "LoF" / "OK" / "Keyhole" / "Balling"
    recommended_P_W: float
    recommended_v_mm_s: float
    recommended_VED: float    # J/mm³
    notes: list = field(default_factory=list)


def volumetric_energy_density(
    P_W: float, v_mm_s: float, layer_um: float, hatch_um: float,
) -> float:
    """Standard PBF VED = P / (v · t · h)  in J/mm³."""

    denom = v_mm_s * (layer_um / 1000.0) * (hatch_um / 1000.0)
    return P_W / denom if denom > 0 else float("inf")


def screen_process_window(
    alloy: AlloyProperties,
    *,
    P_min_W: float = 50, P_max_W: float = 400, n_P: int = 11,
    v_min_mm_s: float = 200, v_max_mm_s: float = 2000, n_v: int = 11,
    layer_um: float = 30, hatch_um: float = 100, spot_um: float = 80,
    T_preheat_K: float = 313, absorptivity: float = 0.4,
) -> ProcessWindow:
    """Sweep (P, v) grid and return regime + POF map.

    Each cell classified into one of:
      * "LoF" — P(lack-of-fusion) > 30%
      * "OK" — both LoF and keyhole < 10%
      * "Keyhole" — P(keyhole) > 30%
      * "Balling" — VED < 25 J/mm³
    """

    P_grid = [P_min_W + i * (P_max_W - P_min_W) / max(1, n_P - 1) for i in range(n_P)]
    v_grid = [v_min_mm_s + j * (v_max_mm_s - v_min_mm_s) / max(1, n_v - 1) for j in range(n_v)]

    pof_map = []
    regime_map = []
    best = (float("inf"), 0.0, 0.0, 0.0)
    for P in P_grid:
        row_pof = []
        row_reg = []
        for v in v_grid:
            depth = rosenthal_melt_pool_depth_um(
                P, v, alloy.alpha_um_m_K, alloy.k_W_mK,
                alloy.T_liquidus_K, T_preheat_K=T_preheat_K, absorptivity=absorptivity,
            )
            beta = normalized_enthalpy(
                P, v, spot_um, alloy.rho_kg_m3, alloy.Cp_J_kgK,
                alloy.T_liquidus_K, absorptivity=absorptivity,
            )
            p_lof = lack_of_fusion_probability(depth, layer_um, hatch_um, spot_um)
            p_key = keyhole_probability(beta)
            ved = volumetric_energy_density(P, v, layer_um, hatch_um)
            pof = max(p_lof, p_key)
            row_pof.append(pof)
            if ved < 25:
                row_reg.append("Balling")
            elif p_key > 0.3:
                row_reg.append("Keyhole")
            elif p_lof > 0.3:
                row_reg.append("LoF")
            else:
                row_reg.append("OK")
                # Track best-of-OK by lowest POF
                if pof < best[0]:
                    best = (pof, P, v, ved)
        pof_map.append(row_pof)
        regime_map.append(row_reg)

    if best[0] == float("inf"):
        notes = ["No (P, v) in OK regime — relax constraints or change alloy."]
        rec_P = rec_v = rec_ved = 0.0
    else:
        _, rec_P, rec_v, rec_ved = best
        notes = [f"Best operating point: P={rec_P:.0f} W, v={rec_v:.0f} mm/s, VED={rec_ved:.0f} J/mm³"]
    return ProcessWindow(
        P_grid_W=P_grid, v_grid_mm_s=v_grid,
        pof_map=pof_map, regime_map=regime_map,
        recommended_P_W=rec_P, recommended_v_mm_s=rec_v, recommended_VED=rec_ved,
        notes=notes,
    )


__all__ = [
    "ProcessWindow", "volumetric_energy_density", "screen_process_window",
]
