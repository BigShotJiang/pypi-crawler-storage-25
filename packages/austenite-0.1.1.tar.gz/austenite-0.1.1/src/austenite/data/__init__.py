"""Materials reference datasets — alloys, S-N curves, K_IC, oracle benchmarks.

Lazy-loaded JSON files bundled with the wheel. Returns ``pandas.DataFrame``
when pandas is installed (recommended via the ``austenite[notebook]`` extra),
otherwise a plain list of dicts.

Example::

    import austenite as au

    df = au.data.alloys()
    df[df['family'] == 'Nickel Alloy'].head()

    sn = au.data.fatigue_curves(alloy="AISI 4140")
    kic = au.data.kic_database(alloy="Ti-6Al-4V")
    bench = au.data.published_benchmarks()
"""

from ._loader import (
    alloy_lookup,
    alloys,
    diffusion_coefficients_extended,
    fatigue_curves,
    heat_treat_schedules,
    kic_database,
    magnetic_properties,
    open_tdb,
    oxidation_kinetics,
    phase_diagram_critical_points,
    published_benchmarks,
    surface_tension_T_dependent,
    thermophysical_T_dependent,
    viscosity_T_dependent,
)

__all__ = [
    "alloys",
    "fatigue_curves",
    "kic_database",
    "published_benchmarks",
    "open_tdb",
    "alloy_lookup",
    "thermophysical_T_dependent",
    "diffusion_coefficients_extended",
    "surface_tension_T_dependent",
    "viscosity_T_dependent",
    "heat_treat_schedules",
    "magnetic_properties",
    "oxidation_kinetics",
    "phase_diagram_critical_points",
]
