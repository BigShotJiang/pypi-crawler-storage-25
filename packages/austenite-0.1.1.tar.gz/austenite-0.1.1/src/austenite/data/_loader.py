"""Lazy loader for bundled JSON reference datasets.

The Austenite SDK ships small starter databases (alloys, fatigue curves,
fracture-toughness K_IC, oracle benchmarks) inside the wheel. They are
loaded on demand, cached, and returned as ``pandas.DataFrame`` when
``pandas`` is available; otherwise as a plain list of dicts.

Schema notes:
  * Each JSON file has a top-level ``_schema_version`` + ``_doc`` plus the
    actual payload list under one of the well-known keys (``alloys``,
    ``curves``, ``entries``, ``cases``).
  * The starter shipment is small (≈100 alloys, ≈50 S-N curves, ≈50 K_IC
    entries). A future PR is wired to lazy-fetch the much larger remote
    catalogue under ``austenite[data]``.

References:
  * ASME II-D 2021; ASTM A240/A276/A312/A29; MMPDS-15; CINDAS Handbook.
  * Bannantine-Comer-Handrock 1990; ASM Metals Handbook Vol 19.
  * Barsom-Rolfe 1987; ASTM E1921 Master Curve database.
"""

from __future__ import annotations

import json
from functools import lru_cache
from importlib import resources
from typing import Any, Optional


_DATA_PKG = "austenite.data"


def _load_raw(filename: str) -> dict[str, Any]:
    """Load one of the bundled JSON files. Wheel-safe via importlib.resources."""

    with resources.files(_DATA_PKG).joinpath(filename).open("r", encoding="utf-8") as fh:
        return json.load(fh)


@lru_cache(maxsize=None)
def _alloys_raw() -> list[dict[str, Any]]:
    return _load_raw("alloys.json")["alloys"]


@lru_cache(maxsize=None)
def _fatigue_raw() -> list[dict[str, Any]]:
    return _load_raw("fatigue_curves.json")["curves"]


@lru_cache(maxsize=None)
def _kic_raw() -> list[dict[str, Any]]:
    return _load_raw("kic_database.json")["entries"]


@lru_cache(maxsize=None)
def _bench_raw() -> list[dict[str, Any]]:
    return _load_raw("published_benchmarks.json")["cases"]


@lru_cache(maxsize=None)
def _thermophys_T_raw() -> list[dict[str, Any]]:
    return _load_raw("thermophysical_T_dependent.json")["alloys"]


@lru_cache(maxsize=None)
def _diffusion_ext_raw() -> list[dict[str, Any]]:
    return _load_raw("diffusion_coefficients_extended.json")["pairs"]


@lru_cache(maxsize=None)
def _surface_tension_T_raw() -> list[dict[str, Any]]:
    return _load_raw("surface_tension_T_dependent.json")["elements"]


@lru_cache(maxsize=None)
def _viscosity_T_raw() -> list[dict[str, Any]]:
    return _load_raw("viscosity_T_dependent.json")["elements"]


@lru_cache(maxsize=None)
def _heat_treat_raw() -> list[dict[str, Any]]:
    return _load_raw("heat_treat_schedules.json")["schedules"]


@lru_cache(maxsize=None)
def _magnetic_raw() -> list[dict[str, Any]]:
    return _load_raw("magnetic_properties.json")["materials"]


@lru_cache(maxsize=None)
def _oxidation_raw() -> list[dict[str, Any]]:
    return _load_raw("oxidation_kinetics.json")["data"]


@lru_cache(maxsize=None)
def _binary_phase_pts_raw() -> list[dict[str, Any]]:
    return _load_raw("phase_diagram_critical_points.json")["binaries"]


def _maybe_to_dataframe(rows: list[dict[str, Any]]) -> Any:
    """Convert to pandas.DataFrame if pandas is available; else return the list."""

    try:
        import pandas as pd  # type: ignore
    except ImportError:  # pragma: no cover - pandas missing path
        return rows
    return pd.DataFrame(rows)


def _plugin_rows(hook: str, plugin: Optional[str]) -> list[dict[str, Any]]:
    """Fan out a data-extension hook across plugins.

    Returns a flat list of rows from either the named plugin or every plugin
    that implements ``hook``. Hooks may return either:
      * ``dict[alloy_id, spec_dict]`` — single record per alloy (for alloys)
      * ``dict[alloy_id, list[record_dict]]`` — many records per alloy
    Both shapes are flattened to a list of dicts. If ``plugin`` is ``None``,
    no plugin extension is requested (returns ``[]``).
    """

    if plugin is None:
        return []
    # Local import keeps the data loader free of an unconditional plugins
    # dependency at module-import time.
    from .. import plugins as _plugins  # noqa: WPS433

    fn = _plugins.get_hook(plugin, hook)
    payload = fn()
    if payload is None:
        return []
    if not isinstance(payload, dict):
        raise TypeError(
            f"Plugin {plugin!r} hook {hook!r} returned {type(payload).__name__}; "
            "expected dict[alloy_id, record_or_list]."
        )
    flat: list[dict[str, Any]] = []
    for alloy_id, value in payload.items():
        if isinstance(value, dict):
            row = dict(value)
            row.setdefault("alloy", alloy_id)
            flat.append(row)
        elif isinstance(value, list):
            for sub in value:
                if not isinstance(sub, dict):
                    continue
                row = dict(sub)
                row.setdefault("alloy", alloy_id)
                flat.append(row)
    return flat


def alloys(plugin: Optional[str] = None) -> Any:
    """Return the bundled alloy reference database as a DataFrame (or list).

    Each row carries: ``uns``, ``name``, ``family``, optional cross-standards
    (``asme``, ``astm``, ``en``, ``jis``), ``composition`` (wt%), mechanicals
    (``Sy_MPa``, ``Sut_MPa``, ``A_pct``, ``E_GPa``), physical
    (``rho_kg_m3``, ``k_W_mK``, ``Cp_J_kgK``, ``alpha_e6_RT``), service
    (``Tmax_C``), and a ``citation`` string.

    Filter by family::

        df = au.data.alloys()
        df[df['family'] == 'Nickel Alloy'].head()

    Args:
        plugin: Optional plugin id (e.g. ``"mil5j"``). If given, merges in
            the plugin's ``custom_alloy_spec`` hook output.
    """

    rows = list(_alloys_raw())
    rows.extend(_plugin_rows("custom_alloy_spec", plugin))
    return _maybe_to_dataframe(rows)


def fatigue_curves(
    alloy: Optional[str] = None, plugin: Optional[str] = None,
) -> Any:
    """Return the S-N (Basquin) curve database.

    Each row carries: ``alloy``, ``condition``, ``R_ratio``,
    ``temperature_C``, ``sigma_f_MPa``, ``b``, ``Se_MPa``, ``Ne_cycles``,
    ``citation``. Use ``alloy`` to filter by substring match (case-insensitive).

    Args:
        alloy: Optional case-insensitive substring filter on the ``alloy`` field.
        plugin: Optional plugin id (e.g. ``"mil5j"``). If given, merges in
            the plugin's ``custom_fatigue_curves`` hook output.
    """

    rows = list(_fatigue_raw())
    rows.extend(_plugin_rows("custom_fatigue_curves", plugin))
    if alloy is not None:
        key = alloy.lower()
        rows = [r for r in rows if key in str(r.get("alloy", "")).lower()]
    return _maybe_to_dataframe(rows)


def kic_database(
    alloy: Optional[str] = None, plugin: Optional[str] = None,
) -> Any:
    """Return the K_IC fracture-toughness database.

    Each row carries: ``alloy``, ``condition``, ``temperature_C``,
    ``K_IC_MPa_sqrt_m``, ``orientation``, ``thickness_mm``, ``citation``.
    Use ``alloy`` to filter by substring match (case-insensitive).

    Args:
        alloy: Optional case-insensitive substring filter on the ``alloy`` field.
        plugin: Optional plugin id (e.g. ``"sandia-mms"``). If given, merges in
            the plugin's ``custom_kic_database`` hook output.
    """

    rows = list(_kic_raw())
    rows.extend(_plugin_rows("custom_kic_database", plugin))
    if alloy is not None:
        key = alloy.lower()
        rows = [r for r in rows if key in str(r.get("alloy", "")).lower()]
    return _maybe_to_dataframe(rows)


def published_benchmarks() -> Any:
    """Return the oracle-benchmark catalogue.

    Each row: ``id``, ``capability``, ``input``, ``expected``,
    ``tolerance_pct``, ``citation``. Drives :func:`austenite.benchmark.run_all`.
    """

    return _maybe_to_dataframe(_bench_raw())


def open_tdb(path: str) -> Any:
    """Open a CALPHAD TDB (ThermoCalc) database file.

    Not implemented in the starter release. Use ``pycalphad`` directly:

        from pycalphad import Database
        db = Database(path)
    """

    raise NotImplementedError(
        "au.data.open_tdb is a placeholder for the v0.2 CALPHAD bridge. "
        "Today, use `from pycalphad import Database; db = Database(path)` "
        "directly. Tracking issue: GH-DATA-TDB."
    )


def thermophysical_T_dependent(
    alloy: Optional[str] = None,
) -> Any:
    """Return T-dependent thermophysical properties for ~169 alloys.

    Each row carries: ``id``, ``family``, ``T_max_K``, ``T_dependent_properties``
    (a dict keyed by property name → list of (T, value) pairs for ``E_GPa``,
    ``sigma_y_MPa``, ``sigma_uts_MPa``, ``k_W_mK``, ``Cp_J_kgK``,
    ``alpha_e6_K_inv``), ``citation``.

    Filter by alloy ID substring (case-insensitive).
    """

    rows = list(_thermophys_T_raw())
    if alloy is not None:
        key = alloy.lower()
        rows = [r for r in rows if key in str(r.get("id", "")).lower()]
    return _maybe_to_dataframe(rows)


def diffusion_coefficients_extended(
    solute: Optional[str] = None, solvent: Optional[str] = None,
) -> Any:
    """Return ~73 diffusion coefficient pairs (Brandes-Brook 1992 + Mehrer 2007).

    Each row carries: ``solute``, ``solvent``, ``phase``, ``D_0_m2_s``,
    ``Q_kJ_mol``, ``T_range_K``, ``citation``.
    """

    rows = list(_diffusion_ext_raw())
    if solute is not None:
        rows = [r for r in rows if r.get("solute", "").lower() == solute.lower()]
    if solvent is not None:
        rows = [r for r in rows if r.get("solvent", "").lower() == solvent.lower()]
    return _maybe_to_dataframe(rows)


def surface_tension_T_dependent(
    element: Optional[str] = None,
) -> Any:
    """Return T-dependent surface tension data for 16 pure liquid metals.

    Each row carries: ``element``, ``T_m_K``, ``T_dependent`` (list of
    (T_K, sigma_mN_m) pairs), ``citation``.
    """

    rows = list(_surface_tension_T_raw())
    if element is not None:
        rows = [r for r in rows if r.get("element", "").lower() == element.lower()]
    return _maybe_to_dataframe(rows)


def viscosity_T_dependent(element: Optional[str] = None) -> Any:
    """Return Andrade A, B viscosity coefficients + T-dependent η(T) for 15 metals.

    Each row carries: ``element``, ``T_m_K``, ``A_mPa_s``, ``B_K``,
    ``T_dependent`` (list of (T_K, eta_mPa_s) pairs), ``citation``.
    """

    rows = list(_viscosity_T_raw())
    if element is not None:
        rows = [r for r in rows if r.get("element", "").lower() == element.lower()]
    return _maybe_to_dataframe(rows)


def heat_treat_schedules(alloy: Optional[str] = None) -> Any:
    """Return 37 cited heat-treat schedules (ASM Handbook Vol 4, AMS, MIL).

    Each row carries: ``alloy``, ``step_1``, ``step_2``, optional ``step_3``,
    ``citation``.
    """

    rows = list(_heat_treat_raw())
    if alloy is not None:
        key = alloy.lower()
        rows = [r for r in rows if key in str(r.get("alloy", "")).lower()]
    return _maybe_to_dataframe(rows)


def magnetic_properties(material: Optional[str] = None) -> Any:
    """Return 23 magnetic-material data entries (soft / hard / magnetostrictive).

    Each row carries: ``alloy``, ``type``, ``B_s_T`` (saturation),
    ``H_c_A_m`` (coercivity), ``mu_r_max``, ``T_c_K`` (Curie),
    ``lambda_s_ppm`` (saturation magnetostriction), ``citation``.
    """

    rows = list(_magnetic_raw())
    if material is not None:
        key = material.lower()
        rows = [r for r in rows if key in str(r.get("alloy", "")).lower()]
    return _maybe_to_dataframe(rows)


def oxidation_kinetics(alloy: Optional[str] = None) -> Any:
    """Return 29 parabolic oxidation-rate constants k_p + activation energies.

    Each row carries: ``alloy``, ``atmosphere``, ``kp_g2_cm4_s``,
    ``Q_kJ_mol``, ``T_range_C``, ``citation``.
    """

    rows = list(_oxidation_raw())
    if alloy is not None:
        key = alloy.lower()
        rows = [r for r in rows if key in str(r.get("alloy", "")).lower()]
    return _maybe_to_dataframe(rows)


def phase_diagram_critical_points(system: Optional[str] = None) -> Any:
    """Return 50 binary phase-diagram critical points (eutectic / peritectic / etc).

    Each row carries: ``system`` (e.g. "Fe-C"), ``type`` (eutectic /
    peritectic / eutectoid / congruent / monotectic), ``composition_pct``
    (of second element), ``T_C``, ``citation``.
    """

    rows = list(_binary_phase_pts_raw())
    if system is not None:
        key = system.lower()
        rows = [r for r in rows if key in str(r.get("system", "")).lower()]
    return _maybe_to_dataframe(rows)


def alloy_lookup(query: str) -> Optional[dict[str, Any]]:
    """Look up a single alloy row by matching against name, UNS, ASME, ASTM, EN, JIS.

    Returns the first match (case-insensitive substring) or ``None``.
    """

    if not query:
        return None
    key = query.strip().lower()
    for row in _alloys_raw():
        for field in ("name", "uns", "asme", "astm", "en", "jis"):
            v = row.get(field)
            if v and key in str(v).lower():
                return row
    return None
