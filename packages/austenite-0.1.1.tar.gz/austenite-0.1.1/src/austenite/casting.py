"""Casting solidification: shrinkage porosity + hot-tearing + feeder sizing.

Used in every foundry / die-casting / investment-cast / AM-LPBF design.
Closes the foundry-specific gap that API 581 / ASME don't cover.

* **Chvorinov 1940**: solidification time vs (V/A)².
* **Niyama criterion**: shrinkage-porosity predictor from G/√V_s.
* **Pellini 1953**: strain-at-solidus hot-tearing.
* **Clyne-Davies 1981**: CSC (Cracking Susceptibility Coefficient).
* **Feurer 1976**: feeding vs shrinkage criterion.
* **Rappaz-Drezet-Gremaud 1999 (RDG)**: mushy-zone pressure drop.
* **Kou 2015**: combined feeding + strain susceptibility index.
* **Modulus + feeder sizing** (Heine-Loper-Rosenthal).

References:
    * Chvorinov N., Giesserei 27 (1940) 177-186.
    * Niyama E., et al., AFS Trans. 90 (1982) 21.
    * Pellini W.S., Trans. AFS 60 (1952) 49.
    * Clyne T.W., Davies G.J., Met. Sci. 13 (1979) 257.
    * Feurer U., Solidif. Tech. Foundry & Casthouse (1976).
    * Rappaz M., Drezet J.-M., Gremaud M., Met. Mater. Trans. A 30 (1999) 449.
    * Kou S., Scripta Mater. 92 (2015) 71-74.
    * Heine R.W., Loper C.R., Rosenthal P.C., "Principles of Metal Casting" 3rd ed. (2009).
    * Campbell J., "Complete Casting Handbook" 2nd ed., Butterworth-Heinemann (2015).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal


# ---------------------------------------------------------------------------
# 1. CHVORINOV — solidification time
# ---------------------------------------------------------------------------


def chvorinov_solidification_time(
    V_cm3: float, A_cm2: float, *, K_min_per_cm2: float = 1.0,
) -> float:
    """Chvorinov 1940 solidification time: ``t = K · (V/A)²``.

    K depends on alloy + mould heat-transfer. Typical sand-cast K values
    (Campbell 2015 Table 3.3):

    =================  ============
    Alloy / Mould       K (min/cm²)
    =================  ============
    Steel sand-cast    1.6 - 2.0
    Steel CO2-mold     1.0
    Iron sand-cast     1.0
    Al sand-cast       0.5
    Al die-cast        0.05
    Cu sand-cast       0.6
    Mg sand-cast       0.4
    =================  ============

    Returns time in minutes.
    """
    if not all(_is_finite(x) for x in [V_cm3, A_cm2, K_min_per_cm2]):
        return float("nan")
    if A_cm2 <= 0:
        return float("nan")
    return float(K_min_per_cm2) * (float(V_cm3) / float(A_cm2)) ** 2


CHVORINOV_K_TABLE: dict[str, float] = {
    "steel-sand":       1.8,
    "steel-CO2":        1.0,
    "iron-sand":        1.0,
    "Al-sand":          0.5,
    "Al-permanent":     0.2,
    "Al-die":           0.05,
    "Cu-sand":          0.6,
    "Mg-sand":          0.4,
    "Mg-die":           0.05,
    "Zn-die":           0.04,
    "Ni-investment":    2.5,
    "Ti-investment":    1.4,
}


def chvorinov_K(alloy_and_mold: str) -> float:
    """Look up Chvorinov K constant for an alloy/mold combination."""
    return CHVORINOV_K_TABLE.get(alloy_and_mold, float("nan"))


# ---------------------------------------------------------------------------
# 2. NIYAMA CRITERION — shrinkage porosity
# ---------------------------------------------------------------------------


def niyama_value(
    G_K_per_mm: float, dT_dt_K_per_s: float,
) -> float:
    """Niyama 1982 criterion: ``Ny = G / sqrt(|dT/dt|)``.

    Low Niyama (typ. < 1.0 K^0.5·s^0.5·mm^-1 for steel) = shrinkage porosity
    likely. Foundries use this as a primary process-window indicator.

    Calibrated thresholds (Niyama 1982 + Carlson-Beckermann 2008):
    * Steel / Ni alloys:  Ny < 1.0   ⇒ porosity risk
    * Al alloys:          Ny < 0.5   ⇒ porosity risk
    * Mg alloys:          Ny < 0.3   ⇒ porosity risk

    Returns Ny in K^0.5 · s^0.5 / mm units.
    """
    if not all(_is_finite(x) for x in [G_K_per_mm, dT_dt_K_per_s]):
        return float("nan")
    abs_cool = abs(float(dT_dt_K_per_s))
    if abs_cool <= 0:
        return float("inf")
    return float(G_K_per_mm) / math.sqrt(abs_cool)


def niyama_porosity_verdict(
    Ny: float, *, alloy_family: Literal["steel", "Ni", "Al", "Mg"] = "steel",
) -> dict:
    """Apply alloy-specific threshold."""
    thresholds = {"steel": 1.0, "Ni": 1.0, "Al": 0.5, "Mg": 0.3}
    th = thresholds.get(alloy_family, 1.0)
    if not _is_finite(Ny):
        return {"passed": False, "Ny": Ny, "threshold": th, "verdict": "indeterminate"}
    return {
        "passed": Ny >= th,
        "Ny": Ny,
        "threshold": th,
        "verdict": "low-porosity risk" if Ny >= th else "shrinkage-porosity risk",
        "alloy_family": alloy_family,
    }


# ---------------------------------------------------------------------------
# 3. HOT-TEARING CRITERIA
# ---------------------------------------------------------------------------


def pellini_hot_tearing(
    strain_external: float, *, strain_critical: float = 0.005,
) -> dict:
    """Pellini 1953 strain-at-solidus criterion.

    Hot tear initiates when applied strain at solidification > ε_critical.
    For most steels ε_crit ≈ 0.5% (0.005); for high-alloy ≈ 1%.

    Reference: Pellini W.S., Trans. AFS 60 (1952) 49.
    """
    if not _is_finite(strain_external):
        return {"susceptible": False, "error": "non-finite input"}
    return {
        "susceptible": float(strain_external) > float(strain_critical),
        "strain_external": float(strain_external),
        "strain_critical": float(strain_critical),
        "method": "Pellini 1953",
    }


def clyne_davies_csc(
    t_fs_99: float, t_fs_90: float, t_fs_40: float,
) -> float:
    """Clyne-Davies 1981 Cracking Susceptibility Coefficient:

    ``CSC = (t_99 − t_90) / (t_90 − t_40)``

    Higher CSC = more hot-tear susceptible. Calibrated:
    * CSC > 0.5 = severe susceptibility
    * 0.2 < CSC < 0.5 = moderate
    * CSC < 0.2 = low

    Parameters
    ----------
    t_fs_99, t_fs_90, t_fs_40: times (s) to reach fraction-solid 0.99, 0.90, 0.40
        on the Scheil-Gulliver path.

    Reference: Clyne T.W., Davies G.J., Met. Sci. 13 (1979) 257.
    """
    if not all(_is_finite(x) for x in [t_fs_99, t_fs_90, t_fs_40]):
        return float("nan")
    numerator = float(t_fs_99) - float(t_fs_90)
    denominator = float(t_fs_90) - float(t_fs_40)
    if abs(denominator) < 1e-9:
        return float("inf")
    return numerator / denominator


def feurer_feeding_index(
    shrinkage_velocity_m_s: float, feeding_velocity_m_s: float,
) -> dict:
    """Feurer 1976 feeding-vs-shrinkage criterion.

    Hot tear forms when shrinkage demand exceeds feeding capability:
        ``susceptibility = v_shrink / v_feed``

    Values > 1 → tear. 0.5-1 → marginal. < 0.5 → safe.

    Reference: Feurer U., Solidif. Tech. Foundry & Casthouse (1976) 131.
    """
    if not all(_is_finite(x) for x in [shrinkage_velocity_m_s, feeding_velocity_m_s]):
        return {"susceptible": False, "error": "non-finite input"}
    if feeding_velocity_m_s <= 0:
        return {"susceptible": True, "ratio": float("inf"),
                "verdict": "feeding-impossible (severe tear risk)"}
    ratio = float(shrinkage_velocity_m_s) / float(feeding_velocity_m_s)
    if ratio > 1:
        verdict = "tear-likely"
    elif ratio > 0.5:
        verdict = "marginal"
    else:
        verdict = "safe"
    return {
        "ratio": ratio,
        "susceptible": ratio > 0.5,
        "verdict": verdict,
        "method": "Feurer 1976",
    }


def rdg_mushy_zone_pressure_drop(
    mu_liquid_Pa_s: float,
    strain_rate_per_s: float,
    L_mushy_m: float,
    permeability_lambda2_m: float = 1e-4,
    *,
    f_s_min: float = 0.01,
    f_s_max: float = 0.99,
    n_int_steps: int = 100,
) -> float:
    """Rappaz-Drezet-Gremaud 1999 mushy-zone pressure drop:

    ``Δp = (180·μ·ε̇·L²/λ_2²) · ∫_{f_s_min}^{f_s_max} (1−f_s)²/f_s³ df_s``

    where λ_2 is the secondary dendrite arm spacing. Larger Δp → hot
    tear more likely (capillary feeding insufficient).

    Reference: Rappaz M., Drezet J.-M., Gremaud M., Met. Mater. Trans. A
    30 (1999) 449.
    """
    if not all(_is_finite(x) for x in [mu_liquid_Pa_s, strain_rate_per_s, L_mushy_m,
                                       permeability_lambda2_m]):
        return float("nan")
    if permeability_lambda2_m <= 0 or L_mushy_m <= 0:
        return float("nan")
    # Trapezoidal integration of (1-f_s)²/f_s³ from f_s_min to f_s_max
    f_min = max(0.001, float(f_s_min))
    f_max = min(0.999, float(f_s_max))
    df = (f_max - f_min) / float(n_int_steps)
    integrand_sum = 0.0
    for i in range(n_int_steps + 1):
        fs = f_min + i * df
        if fs <= 0:
            continue
        integrand = (1 - fs) ** 2 / (fs ** 3)
        # Trapezoidal weight
        weight = 0.5 if (i == 0 or i == n_int_steps) else 1.0
        integrand_sum += integrand * weight
    integral = integrand_sum * df
    pre = 180.0 * float(mu_liquid_Pa_s) * float(strain_rate_per_s) * (float(L_mushy_m) ** 2) \
          / (float(permeability_lambda2_m) ** 2)
    return pre * integral


def kou_combined_index(
    dT_dfs_at_high_fs_K: float, max_strain_at_high_fs: float,
    *, T_window_K: float = 50.0,
) -> dict:
    """Kou 2015 combined susceptibility index:

    ``|dT/df_S^0.5|`` at f_s → 1, multiplied by strain accumulation.
    Higher = more susceptible.

    Reference: Kou S., Scripta Mater. 92 (2015) 71-74.
    """
    if not all(_is_finite(x) for x in [dT_dfs_at_high_fs_K, max_strain_at_high_fs, T_window_K]):
        return {"susceptible": False, "error": "non-finite input"}
    index = abs(float(dT_dfs_at_high_fs_K)) * float(max_strain_at_high_fs) / max(1.0, float(T_window_K))
    if index > 0.05:
        verdict = "severe-susceptibility"
    elif index > 0.02:
        verdict = "moderate"
    else:
        verdict = "low"
    return {
        "kou_index": index,
        "verdict": verdict,
        "susceptible": index > 0.02,
        "method": "Kou 2015",
    }


# ---------------------------------------------------------------------------
# 4. FEEDER (RISER) SIZING
# ---------------------------------------------------------------------------


def feeder_modulus_method(
    casting_V_cm3: float, casting_A_cm2: float, *, safety_factor: float = 1.2,
) -> dict:
    """Modulus-method feeder sizing (Heine-Loper-Rosenthal 1955).

    Rule: ``M_feeder ≥ 1.2 · M_casting`` where M = V/A.

    Returns the minimum feeder modulus + a typical cylindrical-feeder
    diameter assuming H = 1.5·D.
    """
    if not all(_is_finite(x) for x in [casting_V_cm3, casting_A_cm2, safety_factor]):
        return {"error": "non-finite input"}
    if casting_A_cm2 <= 0:
        return {"error": "A_casting must be > 0"}

    M_casting = float(casting_V_cm3) / float(casting_A_cm2)
    M_feeder_min = float(safety_factor) * M_casting
    # For cylindrical riser H = 1.5·D, V/A = D/4.5 → D = 4.5·M
    D_feeder_min_cm = 4.5 * M_feeder_min
    return {
        "M_casting_cm": M_casting,
        "M_feeder_required_cm": M_feeder_min,
        "feeder_diameter_min_cm": D_feeder_min_cm,
        "feeder_height_min_cm": 1.5 * D_feeder_min_cm,
        "feeder_volume_min_cm3": math.pi / 4 * D_feeder_min_cm ** 2 * 1.5 * D_feeder_min_cm,
        "method": "Heine-Loper-Rosenthal modulus method",
    }


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "chvorinov_solidification_time", "CHVORINOV_K_TABLE", "chvorinov_K",
    "niyama_value", "niyama_porosity_verdict",
    "pellini_hot_tearing", "clyne_davies_csc", "feurer_feeding_index",
    "rdg_mushy_zone_pressure_drop", "kou_combined_index",
    "feeder_modulus_method",
]
