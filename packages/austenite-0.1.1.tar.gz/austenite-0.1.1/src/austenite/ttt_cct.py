"""TTT / CCT diagram solver from composition.

Kirkaldy 1991 + Maynier-Dollet 1978 + Andrews 1965 critical-T model
generates Time-Temperature-Transformation and Continuous-Cooling-Transformation
curves directly from wt%-composition (no database lookup needed).

References:
    * Andrews K.W., J. Iron Steel Inst. 203 (1965) 721.
    * Kirkaldy J.S., Venugopalan D., Phase Transformations in Ferrous Alloys
      (1984) 125; J.S. Kirkaldy, Met. Trans. A 22 (1991) 437.
    * Maynier P., Dollet J., Bastien P., Hardenability Concepts with
      Applications to Steel (TMS-AIME 1978) 518.
    * Lee Y.-K., J. Mater. Sci. Lett. 18 (1999) 233 — Bs from composition.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class TTTCurve:
    """TTT / CCT result for one cooling path."""

    Ae3_C: float
    Ae1_C: float
    Bs_C: float    # bainite start
    Ms_C: float    # martensite start
    Mf_C: float    # martensite finish (~Ms - 215°C empirical)
    Tnose_ferrite_C: float
    tnose_ferrite_s: float
    Tnose_pearlite_C: float
    tnose_pearlite_s: float
    Tnose_bainite_C: float
    tnose_bainite_s: float
    critical_cooling_rate_C_s: float
    notes: list = field(default_factory=list)


def andrews_Ae3(comp: dict) -> float:
    """Andrews 1965 (linear): Ae3 [°C] = 910 − 203·sqrt(C) − 15.2·Ni + 44.7·Si + ..."""

    C = comp.get("C", 0.4)
    Mn = comp.get("Mn", 0.8)
    Si = comp.get("Si", 0.25)
    Cr = comp.get("Cr", 0.0)
    Ni = comp.get("Ni", 0.0)
    Mo = comp.get("Mo", 0.0)
    V = comp.get("V", 0.0)
    Cu = comp.get("Cu", 0.0)
    As = comp.get("As", 0.0)
    # Andrews 1965: the +13.1 coefficient is for W (tungsten), not Cu;
    # Cu carries only the −20 term.
    return (910 - 203 * math.sqrt(max(C, 0)) - 15.2 * Ni + 44.7 * Si
            + 104 * V + 31.5 * Mo + 13.1 * comp.get("W", 0) - 30 * Mn
            - 11 * Cr - 20 * Cu + 700 * comp.get("P", 0) + 400 * comp.get("Al", 0)
            + 120 * As + 400 * comp.get("Ti", 0))


def andrews_Ae1(comp: dict) -> float:
    """Andrews 1965: Ae1 [°C] = 727 − 10.7·Mn − 16.9·Ni + 29.1·Si + 16.9·Cr + ..."""

    Mn = comp.get("Mn", 0.8)
    Si = comp.get("Si", 0.25)
    Cr = comp.get("Cr", 0.0)
    Ni = comp.get("Ni", 0.0)
    Mo = comp.get("Mo", 0.0)
    As = comp.get("As", 0.0)
    return (727 - 10.7 * Mn - 16.9 * Ni + 29.1 * Si + 16.9 * Cr
            - 16.9 * comp.get("Cu", 0) + 290 * As + 6.38 * comp.get("W", 0))


def steven_haynes_Ms(comp: dict) -> float:
    """Steven-Haynes 1956: Ms [°C] = 561 − 474·C − 33·Mn − 17·Ni − 17·Cr − 21·Mo."""

    C = comp.get("C", 0.4)
    Mn = comp.get("Mn", 0.8)
    Ni = comp.get("Ni", 0.0)
    Cr = comp.get("Cr", 0.0)
    Mo = comp.get("Mo", 0.0)
    return 561 - 474 * C - 33 * Mn - 17 * Ni - 17 * Cr - 21 * Mo


def lee_Bs(comp: dict) -> float:
    """Lee 1999: Bs [°C] = 745 − 110·C − 59·Mn − 39·Ni − 68·Cr − 106·Mo + ..."""

    C = comp.get("C", 0.4)
    Mn = comp.get("Mn", 0.8)
    Si = comp.get("Si", 0.25)
    Cr = comp.get("Cr", 0.0)
    Ni = comp.get("Ni", 0.0)
    Mo = comp.get("Mo", 0.0)
    return (745 - 110 * C - 59 * Mn - 39 * Ni - 68 * Cr - 106 * Mo
            + 17 * Mn * Ni + 6 * Cr * Cr + 29 * Mo * Mo - 17 * Si * Mn)


def _kirkaldy_nose_time(T_C: float, comp: dict, transformation: str) -> float:
    """Kirkaldy 1984 isothermal incubation time τ [s] for given transformation.

    τ = F(comp, GS) / (ΔT^n · exp(−Q/RT)).
    Returns time to 1% formed.
    """

    GS = 7  # ASTM grain size
    R = 8.314
    if transformation == "ferrite":
        Q = 27500.0
        F = 59.6 * comp.get("Mn", 0.8) + 1.45 * comp.get("Ni", 0) + 67.7 * comp.get("Cr", 0) + 244 * comp.get("Mo", 0)
        Ae3 = andrews_Ae3(comp)
        dT = max(1, Ae3 - T_C)
        n = 3
    elif transformation == "pearlite":
        Q = 27500.0
        F = 1.79 + 5.42 * (comp.get("Cr", 0) + comp.get("Mo", 0) + 4 * comp.get("Mo", 0) * comp.get("Ni", 0))
        Ae1 = andrews_Ae1(comp)
        dT = max(1, Ae1 - T_C)
        n = 3
    elif transformation == "bainite":
        Q = 27500.0
        F = (2.34 + 10.1 * comp.get("C", 0.4) + 3.8 * comp.get("Cr", 0)
             + 19 * comp.get("Mo", 0)) * 1e-4
        Bs = lee_Bs(comp)
        dT = max(1, Bs - T_C)
        n = 2
    else:
        return float("inf")
    return F * (2 ** (0.5 * GS)) / (dT ** n * math.exp(-Q / (R * (T_C + 273.15))))


def _find_nose(comp: dict, transformation: str, T_lo: float, T_hi: float) -> tuple[float, float]:
    """Sweep T from T_lo to T_hi; return (T_nose, τ_nose) — minimum τ."""

    best = (T_lo, float("inf"))
    T = T_lo
    while T <= T_hi:
        tau = _kirkaldy_nose_time(T, comp, transformation)
        if tau < best[1]:
            best = (T, tau)
        T += 10
    return best


def compute_ttt(comp: dict) -> TTTCurve:
    """Generate TTT/CCT summary from composition.

    Args:
        comp: dict of element wt% (e.g. {"C":0.4, "Mn":0.8, "Cr":1.0, "Mo":0.25}).

    Returns:
        TTTCurve with all critical temperatures + transformation noses.
    """

    Ae3 = andrews_Ae3(comp)
    Ae1 = andrews_Ae1(comp)
    Ms = steven_haynes_Ms(comp)
    Mf = Ms - 215
    Bs = lee_Bs(comp)

    T_F, t_F = _find_nose(comp, "ferrite", Ae1 - 50, Ae3 - 20)
    T_P, t_P = _find_nose(comp, "pearlite", 500, min(Ae1 - 10, 700))
    T_B, t_B = _find_nose(comp, "bainite", Ms + 30, min(Bs - 20, 550))

    # Critical cooling rate to avoid pearlite nose:
    # CR = (Ae3 − T_nose_P) / t_nose_P
    if t_P > 0 and math.isfinite(t_P):
        ccr = (Ae3 - T_P) / t_P
    else:
        ccr = float("inf")

    notes = []
    if Ms < 0:
        notes.append("Ms<0 °C — alloy fully austenitic at RT (retained-austenite risk)")
    if t_B < 1:
        notes.append("Bainite nose <1 s — full martensite needs oil-or-faster quench")
    if Ae3 - Ae1 < 50:
        notes.append("Narrow γ window — single-phase austenitization difficult")

    return TTTCurve(
        Ae3_C=Ae3, Ae1_C=Ae1, Bs_C=Bs, Ms_C=Ms, Mf_C=Mf,
        Tnose_ferrite_C=T_F, tnose_ferrite_s=t_F,
        Tnose_pearlite_C=T_P, tnose_pearlite_s=t_P,
        Tnose_bainite_C=T_B, tnose_bainite_s=t_B,
        critical_cooling_rate_C_s=ccr,
        notes=notes,
    )


__all__ = [
    "TTTCurve",
    "andrews_Ae3", "andrews_Ae1", "steven_haynes_Ms", "lee_Bs",
    "compute_ttt",
]
