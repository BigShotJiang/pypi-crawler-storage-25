"""Plugin registry and discovery for austenite.

Third-parties extend austenite by shipping a separate PyPI package that
declares an entry point under the ``austenite.plugins`` group. The entry
point returns a :class:`PluginManifest` carrying named hook callables.

Quick usage::

    import austenite as au

    # see what's installed (discovers via importlib.metadata)
    au.plugins.list_installed()
    # → ['mil5j', 'sandia-mms', 'corro-rates']

    # explicitly load (idempotent — also auto-loads on first hook lookup)
    au.plugins.load("mil5j")

    # call a hooked function
    curves = au.data.fatigue_curves("Ti-6Al-4V", plugin="mil5j")

Hook contract (each is optional; plugin returns the ones it implements):

  * ``custom_alloy_spec()`` → ``dict[alloy_id, alloy_spec_dict]``
  * ``custom_fatigue_curves()`` → ``dict[alloy_id, list[sn_curve_dict]]``
  * ``custom_kic_database()`` → ``dict[alloy_id, list[kic_entry_dict]]``
  * ``custom_compliance_check(spec_id, **kwargs)`` → ``ComplianceVerdict``
    or ``None`` if the plugin doesn't recognise the spec.
  * ``custom_posterior_likelihood(name, params, data)`` → ``float`` log-lik
    or ``None`` if the plugin doesn't recognise the likelihood name.
  * ``custom_NDE_method(method_id)`` → ``PODCurve``-shaped dict or ``None``.

A plugin's ``pyproject.toml`` registers itself like::

    [project.entry-points."austenite.plugins"]
    mil5j = "austenite_extras_mil5j:get_manifest"

The ``get_manifest`` callable takes no args and returns a
:class:`PluginManifest`.

References:
  * PEP 621 — Storing project metadata in pyproject.toml.
  * PEP 660 — Editable installs for pyproject-based builds.
  * importlib.metadata — Standard entry-point discovery, Python 3.10+.
"""

from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from importlib import metadata as importlib_metadata
from typing import Any, Callable, Iterable, Optional


# ---------------------------------------------------------------------------
# Manifest + registry data structures
# ---------------------------------------------------------------------------


ENTRY_POINT_GROUP = "austenite.plugins"

# Hooks the core SDK knows how to call. Plugins may define a subset.
KNOWN_HOOKS: frozenset[str] = frozenset(
    {
        "custom_alloy_spec",
        "custom_compliance_check",
        "custom_posterior_likelihood",
        "custom_NDE_method",
        "custom_fatigue_curves",
        "custom_kic_database",
    }
)


@dataclass
class PluginManifest:
    """Metadata + hook registry for a single austenite plugin.

    Attributes:
        name: Short plugin id (matches the entry-point name, e.g. ``"mil5j"``).
        version: Plugin package version (semver string).
        hooks: Map of hook-name → callable. Allowed keys are in
            :data:`KNOWN_HOOKS`; unknown keys raise on registration.
        description: One-paragraph plain-English description.
        citation: Primary reference (e.g. ``"MIL-HDBK-5J (2003)"``).
    """

    name: str
    version: str
    hooks: dict[str, Callable[..., Any]] = field(default_factory=dict)
    description: str = ""
    citation: str = ""

    def __post_init__(self) -> None:
        unknown = set(self.hooks) - KNOWN_HOOKS
        if unknown:
            raise ValueError(
                f"Plugin {self.name!r} declared unknown hooks: {sorted(unknown)!r}. "
                f"Allowed hooks: {sorted(KNOWN_HOOKS)!r}."
            )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


# name → manifest
_REGISTRY: dict[str, PluginManifest] = {}
# True once we've scanned entry points at least once; populated lazily.
_DISCOVERED: bool = False


def discover() -> dict[str, PluginManifest]:
    """Scan installed packages for entry points and populate the registry.

    Idempotent — repeated calls re-scan but do not re-load already-loaded
    plugins (the entry-point factory is invoked once per name). Returns the
    full registry as a fresh dict.
    """

    global _DISCOVERED
    try:
        eps = importlib_metadata.entry_points()
    except Exception as exc:  # pragma: no cover - defensive
        warnings.warn(
            f"austenite.plugins.discover: entry_points() failed ({exc}); skipping.",
            RuntimeWarning,
            stacklevel=2,
        )
        _DISCOVERED = True
        return dict(_REGISTRY)

    # Python 3.10+: entry_points() returns an EntryPoints object that
    # supports .select(group=...). Earlier idiom used dict-of-list access.
    if hasattr(eps, "select"):
        group_eps = eps.select(group=ENTRY_POINT_GROUP)
    else:  # pragma: no cover - 3.9 fallback path
        group_eps = eps.get(ENTRY_POINT_GROUP, [])  # type: ignore[attr-defined]

    for ep in group_eps:
        if ep.name in _REGISTRY:
            continue
        try:
            factory = ep.load()
        except Exception as exc:
            warnings.warn(
                f"austenite plugin {ep.name!r} failed to load: {exc}",
                RuntimeWarning,
                stacklevel=2,
            )
            continue
        try:
            manifest = factory() if callable(factory) else factory
        except Exception as exc:
            warnings.warn(
                f"austenite plugin {ep.name!r} factory raised: {exc}",
                RuntimeWarning,
                stacklevel=2,
            )
            continue
        if not isinstance(manifest, PluginManifest):
            warnings.warn(
                f"austenite plugin {ep.name!r} returned {type(manifest).__name__}, "
                f"expected PluginManifest; ignoring.",
                RuntimeWarning,
                stacklevel=2,
            )
            continue
        _REGISTRY[manifest.name] = manifest

    _DISCOVERED = True
    return dict(_REGISTRY)


def _ensure_discovered() -> None:
    if not _DISCOVERED:
        discover()


def list_installed() -> list[str]:
    """Return a sorted list of installed plugin names."""

    _ensure_discovered()
    return sorted(_REGISTRY)


def list() -> list[str]:  # noqa: A001 - intentional shadowing of builtin per spec
    """Alias for :func:`list_installed` — matches ``au.plugins.list()`` in docs."""

    return list_installed()


def load(name: str) -> PluginManifest:
    """Explicitly load a named plugin and return its manifest.

    Raises :class:`KeyError` if the plugin is not installed.
    """

    _ensure_discovered()
    if name not in _REGISTRY:
        installed = sorted(_REGISTRY)
        raise KeyError(
            f"austenite plugin {name!r} not installed. Installed plugins: {installed!r}. "
            f"Install via e.g. `pip install austenite-extras-{name}`."
        )
    return _REGISTRY[name]


def register(manifest: PluginManifest, *, replace: bool = False) -> None:
    """Programmatically register a manifest (mainly for tests + in-process use).

    By default refuses to overwrite an existing registration; pass
    ``replace=True`` to override.
    """

    if not isinstance(manifest, PluginManifest):
        raise TypeError(
            f"register() expects PluginManifest, got {type(manifest).__name__}"
        )
    if manifest.name in _REGISTRY and not replace:
        raise ValueError(
            f"Plugin {manifest.name!r} is already registered; "
            "pass replace=True to override."
        )
    _REGISTRY[manifest.name] = manifest


def unregister(name: str) -> None:
    """Remove a plugin from the registry (mainly for tests)."""

    _REGISTRY.pop(name, None)


def clear(*, rediscover: bool = False) -> None:
    """Wipe the registry (test helper).

    By default leaves the discovery flag set so a freshly-cleared registry
    won't immediately re-populate itself the next time a hook is queried.
    Pass ``rediscover=True`` to also reset the discovery flag — in that
    case the next hook lookup will re-scan entry points.
    """

    global _DISCOVERED
    _REGISTRY.clear()
    if rediscover:
        _DISCOVERED = False


# ---------------------------------------------------------------------------
# Hook lookup helpers — used by core SDK modules.
# ---------------------------------------------------------------------------


def get_hook(plugin: str, hook: str) -> Callable[..., Any]:
    """Return the hook callable for ``plugin``, raising if missing.

    ``hook`` must be in :data:`KNOWN_HOOKS`. Raises :class:`KeyError` if the
    plugin is not installed or did not declare that hook.
    """

    if hook not in KNOWN_HOOKS:
        raise ValueError(
            f"Unknown hook name {hook!r}. Known hooks: {sorted(KNOWN_HOOKS)!r}."
        )
    manifest = load(plugin)
    if hook not in manifest.hooks:
        raise KeyError(
            f"Plugin {plugin!r} does not implement hook {hook!r}. "
            f"It declares: {sorted(manifest.hooks)!r}."
        )
    return manifest.hooks[hook]


def iter_hooks(hook: str) -> Iterable[tuple[str, Callable[..., Any]]]:
    """Iterate over ``(plugin_name, callable)`` for every plugin that implements ``hook``.

    Useful for fan-out dispatch (e.g. compliance check across all plugins).
    """

    if hook not in KNOWN_HOOKS:
        raise ValueError(
            f"Unknown hook name {hook!r}. Known hooks: {sorted(KNOWN_HOOKS)!r}."
        )
    _ensure_discovered()
    for name, manifest in _REGISTRY.items():
        if hook in manifest.hooks:
            yield name, manifest.hooks[hook]


def call_hook(
    plugin: Optional[str], hook: str, *args: Any, **kwargs: Any
) -> Optional[Any]:
    """Call a hook on a named plugin, or try every plugin until one returns non-None.

    If ``plugin`` is given, calls only that plugin (raising if missing).
    If ``plugin`` is ``None``, calls each plugin in turn and returns the first
    non-None result; returns ``None`` if all plugins return ``None`` or none
    implement the hook.
    """

    if plugin is not None:
        fn = get_hook(plugin, hook)
        return fn(*args, **kwargs)
    for _name, fn in iter_hooks(hook):
        try:
            result = fn(*args, **kwargs)
        except Exception as exc:
            warnings.warn(
                f"austenite plugin hook {hook!r} raised: {exc}",
                RuntimeWarning,
                stacklevel=2,
            )
            continue
        if result is not None:
            return result
    return None


__all__ = [
    "PluginManifest",
    "KNOWN_HOOKS",
    "ENTRY_POINT_GROUP",
    "discover",
    "list",
    "list_installed",
    "load",
    "register",
    "unregister",
    "clear",
    "get_hook",
    "iter_hooks",
    "call_hook",
]
