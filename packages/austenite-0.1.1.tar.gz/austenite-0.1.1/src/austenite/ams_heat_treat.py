"""Named AMS / AMS-QQ heat-treat routes.

Each route encapsulates the canonical heat-treat schedule for a widely-used
aerospace alloy, with the controlling AMS spec citation and engineer-readable
acceptance criteria.

Routes shipped:

  * **AMS5662** — Inconel 718, solution + double-age (1950+1325+1150°F)
  * **AMS5704** — Inconel 625, mill-anneal
  * **AMS5613** — 17-4 PH stainless, condition H900/H1025/H1075
  * **AMS5599** — Hastelloy X / C, solution anneal
  * **AMS4928** — Ti-6Al-4V, mill-anneal (α+β solution treat + age)
  * **AMS-QQ-A-225/5** — AA2024-T3 / T351, solution + natural age
  * **AMS-QQ-A-250/12** — AA7075-T6, solution + artificial age
  * **AMS6322** — AISI 4340 normalize + quench + temper

Each route returns a :class:`AMSHeatTreatSchedule` with the spec citation,
step-by-step parameters, and the post-treatment property guarantees
(HV / σ_y / σ_uts / elongation) the spec requires.

References:
    * SAE AMS5662M — Nickel Alloy, Corrosion & Heat Resistant, Bars (UNS N07718)
    * SAE AMS5704D — Nickel Alloy, Corrosion & Heat Resistant Sheet (UNS N06625)
    * SAE AMS5613K — Steel, Corrosion Resistant, Bars 17-4 PH (UNS S17400)
    * SAE AMS5599N — Nickel Alloy Sheet Hastelloy C-276 (UNS N10276)
    * SAE AMS4928V — Titanium 6Al-4V, Annealed (UNS R56400)
    * AMS-QQ-A-225/5G — Aluminum, Bars 2024
    * AMS-QQ-A-250/12 — Aluminum 7075
    * SAE AMS6322L — Steel, AISI 4340 Bar/Forging
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class AMSHeatTreatSchedule:
    """A named, traceable heat-treat schedule with property guarantees."""

    ams_spec: str
    alloy_uns: str
    common_name: str
    steps: list = field(default_factory=list)  # list of dict {step, T_C, t_h, medium}
    expected_HV_min: float = 0.0
    expected_HV_max: float = 0.0
    expected_sigma_y_MPa: float = 0.0
    expected_sigma_uts_MPa: float = 0.0
    expected_elong_pct_min: float = 0.0
    notes: list = field(default_factory=list)
    citation: str = ""


def AMS5662() -> AMSHeatTreatSchedule:
    """Inconel 718 — solution anneal + 2-step age per AMS5662M.

    Per AMS5662M §3.4.2:
      1. Solution anneal 1066±14°C / 1 h / oil or air cool
      2. Stabilize age 760±5°C / 10 h / furnace cool to 650°C
      3. Final age 650±5°C / 8 h / air cool (total step 2+3 time = 18 h)

    Acceptance: σ_y ≥ 1034 MPa, σ_uts ≥ 1241 MPa, elong ≥ 12 %.
    """

    return AMSHeatTreatSchedule(
        ams_spec="AMS5662M",
        alloy_uns="N07718",
        common_name="Inconel 718",
        steps=[
            {"step": "solution_anneal", "T_C": 1066, "t_h": 1.0, "medium": "air"},
            {"step": "stabilize_age", "T_C": 760, "t_h": 10.0, "medium": "furnace"},
            {"step": "final_age", "T_C": 650, "t_h": 8.0, "medium": "air"},
        ],
        expected_HV_min=380, expected_HV_max=460,
        expected_sigma_y_MPa=1034, expected_sigma_uts_MPa=1241,
        expected_elong_pct_min=12,
        notes=[
            "Double-age develops γ′′ (Ni3Nb) — controls HCF allowable",
            "Solution T above δ-solvus (~1010°C) avoids brittle grain-boundary δ",
        ],
        citation="SAE AMS5662M (2018) §3.4.2",
    )


def AMS5704() -> AMSHeatTreatSchedule:
    """Inconel 625 — mill-anneal per AMS5704D.

    Solution anneal 1093±14°C, water or rapid air quench. No age.

    Acceptance: σ_y ≥ 415 MPa, σ_uts ≥ 827 MPa, elong ≥ 30 %.
    """

    return AMSHeatTreatSchedule(
        ams_spec="AMS5704D",
        alloy_uns="N06625",
        common_name="Inconel 625",
        steps=[
            {"step": "mill_anneal", "T_C": 1093, "t_h": 1.0, "medium": "water"},
        ],
        expected_HV_min=180, expected_HV_max=240,
        expected_sigma_y_MPa=415, expected_sigma_uts_MPa=827,
        expected_elong_pct_min=30,
        notes=[
            "Solid-solution strengthening Nb+Mo — no precipitate phases at this anneal",
            "Avoid 600-800°C for >1h to prevent δ + γ′′ embrittlement",
        ],
        citation="SAE AMS5704D §3.4",
    )


def AMS5613(condition: str = "H900") -> AMSHeatTreatSchedule:
    """17-4 PH stainless — solution + age per AMS5613K.

    Conditions:
      * H900: 482°C / 1 h — peak strength, low toughness
      * H1025: 552°C / 4 h — balanced
      * H1075: 580°C / 4 h — higher toughness, lower strength

    Args:
        condition: "H900", "H1025", or "H1075".
    """

    table = {
        "H900":  (482, 1.0, 1170, 1310, 10, 380, 440),
        "H1025": (552, 4.0, 1000, 1070, 12, 320, 380),
        "H1075": (580, 4.0, 860, 1000, 13, 295, 350),
    }
    if condition not in table:
        raise ValueError(f"Unknown condition {condition!r}; choose H900/H1025/H1075")
    T_age, t_age, sy, suts, el, hv_min, hv_max = table[condition]

    return AMSHeatTreatSchedule(
        ams_spec="AMS5613K",
        alloy_uns="S17400",
        common_name=f"17-4 PH condition {condition}",
        steps=[
            {"step": "solution_anneal", "T_C": 1038, "t_h": 0.5, "medium": "air"},
            {"step": f"age_{condition}", "T_C": T_age, "t_h": t_age, "medium": "air"},
        ],
        expected_HV_min=hv_min, expected_HV_max=hv_max,
        expected_sigma_y_MPa=sy, expected_sigma_uts_MPa=suts,
        expected_elong_pct_min=el,
        notes=[
            "Cu-rich BCC precipitates carry the strengthening",
            "Avoid prolonged 400-500°C exposure (475°C embrittlement)",
        ],
        citation=f"SAE AMS5613K Table 1 Condition {condition}",
    )


def AMS5599() -> AMSHeatTreatSchedule:
    """Hastelloy C-276 — solution anneal per AMS5599N.

    Solution anneal 1121±14°C, rapid water quench. Single-step.

    Acceptance: σ_y ≥ 283 MPa, σ_uts ≥ 690 MPa, elong ≥ 40 %.
    """

    return AMSHeatTreatSchedule(
        ams_spec="AMS5599N",
        alloy_uns="N10276",
        common_name="Hastelloy C-276",
        steps=[
            {"step": "solution_anneal", "T_C": 1121, "t_h": 1.0, "medium": "water"},
        ],
        expected_HV_min=190, expected_HV_max=240,
        expected_sigma_y_MPa=283, expected_sigma_uts_MPa=690,
        expected_elong_pct_min=40,
        notes=[
            "Single-phase γ Ni-Cr-Mo-W — no precipitation hardening",
            "Avoid 540-900°C to prevent µ + P + σ intermetallics",
        ],
        citation="SAE AMS5599N §3.4",
    )


def AMS4928(double_anneal: bool = False) -> AMSHeatTreatSchedule:
    """Ti-6Al-4V — mill-anneal per AMS4928V.

    Standard mill-anneal: 705-790°C / 1-4 h / air cool.

    Args:
        double_anneal: if True, adds 595°C / 2 h second step (stabilizes β).

    Acceptance: σ_y ≥ 828 MPa, σ_uts ≥ 896 MPa, elong ≥ 10 %.
    """

    steps = [{"step": "mill_anneal", "T_C": 760, "t_h": 2.0, "medium": "air"}]
    if double_anneal:
        steps.append({"step": "beta_stabilize", "T_C": 595, "t_h": 2.0, "medium": "air"})
    return AMSHeatTreatSchedule(
        ams_spec="AMS4928V",
        alloy_uns="R56400",
        common_name="Ti-6Al-4V mill-anneal" + (" (double)" if double_anneal else ""),
        steps=steps,
        expected_HV_min=320, expected_HV_max=380,
        expected_sigma_y_MPa=828, expected_sigma_uts_MPa=896,
        expected_elong_pct_min=10,
        notes=[
            "Annealed α+β microstructure — sets fatigue + toughness baseline",
            "Mill-anneal T must stay below β-transus 995°C to retain duplex structure",
        ],
        citation="SAE AMS4928V §3.4.1",
    )


def AMS_QQ_A_225_5() -> AMSHeatTreatSchedule:
    """AA2024-T3 / T351 — solution + natural age per AMS-QQ-A-225/5.

    Steps:
      1. Solution heat treat 493±5°C / 1 h
      2. Water quench (< 7 s transfer)
      3. Cold-work stretch ~1.5-3% (T3 only)
      4. Natural age ≥ 96 h at room T

    Acceptance: σ_y ≥ 290 MPa, σ_uts ≥ 414 MPa, elong ≥ 10 %.
    """

    return AMSHeatTreatSchedule(
        ams_spec="AMS-QQ-A-225/5G",
        alloy_uns="A92024",
        common_name="AA2024-T3 / T351",
        steps=[
            {"step": "solution_heat_treat", "T_C": 493, "t_h": 1.0, "medium": "water"},
            {"step": "cold_work_stretch", "T_C": 25, "t_h": 0.0, "medium": "air"},
            {"step": "natural_age", "T_C": 25, "t_h": 96.0, "medium": "air"},
        ],
        expected_HV_min=120, expected_HV_max=145,
        expected_sigma_y_MPa=290, expected_sigma_uts_MPa=414,
        expected_elong_pct_min=10,
        notes=[
            "GP zones + S′ (Al2CuMg) precipitates from natural aging",
            "Quench delay must be < 7 s to avoid GB precipitation → IGC susceptibility",
        ],
        citation="AMS-QQ-A-225/5G §3.4",
    )


def AMS_QQ_A_250_12() -> AMSHeatTreatSchedule:
    """AA7075-T6 — solution + artificial age per AMS-QQ-A-250/12.

    Steps:
      1. Solution heat treat 477±5°C / 1 h
      2. Water quench
      3. Artificial age 121±3°C / 24 h

    Acceptance: σ_y ≥ 503 MPa, σ_uts ≥ 572 MPa, elong ≥ 11 %.
    """

    return AMSHeatTreatSchedule(
        ams_spec="AMS-QQ-A-250/12",
        alloy_uns="A97075",
        common_name="AA7075-T6",
        steps=[
            {"step": "solution_heat_treat", "T_C": 477, "t_h": 1.0, "medium": "water"},
            {"step": "artificial_age", "T_C": 121, "t_h": 24.0, "medium": "air"},
        ],
        expected_HV_min=150, expected_HV_max=180,
        expected_sigma_y_MPa=503, expected_sigma_uts_MPa=572,
        expected_elong_pct_min=11,
        notes=[
            "η′ (MgZn2) precipitates dominate hardening",
            "Over-age (T73) at 175°C trades strength for SCC immunity",
        ],
        citation="AMS-QQ-A-250/12 §3.4",
    )


def AMS6322(temper_condition: str = "tempered_500C") -> AMSHeatTreatSchedule:
    """AISI 4340 normalize + quench + temper per AMS6322L.

    Steps:
      1. Normalize 871±14°C / 1 h / air
      2. Austenitize 845±14°C / 1 h
      3. Oil quench (severity H ≈ 0.5)
      4. Temper per condition

    Conditions:
      * "tempered_200C": 200°C / 2 h → ~545 HV, σ_y ≈ 1620 MPa
      * "tempered_400C": 400°C / 2 h → ~430 HV, σ_y ≈ 1280 MPa
      * "tempered_500C": 500°C / 2 h → ~380 HV, σ_y ≈ 1100 MPa
      * "tempered_650C": 650°C / 2 h → ~280 HV, σ_y ≈ 820 MPa
    """

    table = {
        "tempered_200C": (200, 545, 1620, 1830, 9, 510, 580),
        "tempered_400C": (400, 430, 1280, 1450, 11, 400, 460),
        "tempered_500C": (500, 380, 1100, 1240, 13, 350, 410),
        "tempered_650C": (650, 280, 820, 940, 17, 250, 310),
    }
    if temper_condition not in table:
        raise ValueError(f"Unknown {temper_condition!r}")
    T_temper, hv, sy, suts, el, hv_min, hv_max = table[temper_condition]
    return AMSHeatTreatSchedule(
        ams_spec="AMS6322L",
        alloy_uns="G43400",
        common_name=f"AISI 4340 N+Q+T ({temper_condition})",
        steps=[
            {"step": "normalize", "T_C": 871, "t_h": 1.0, "medium": "air"},
            {"step": "austenitize", "T_C": 845, "t_h": 1.0, "medium": "oil"},
            {"step": "oil_quench", "T_C": 60, "t_h": 0.0, "medium": "oil"},
            {"step": f"temper_{temper_condition}", "T_C": T_temper, "t_h": 2.0, "medium": "air"},
        ],
        expected_HV_min=hv_min, expected_HV_max=hv_max,
        expected_sigma_y_MPa=sy, expected_sigma_uts_MPa=suts,
        expected_elong_pct_min=el,
        notes=[
            "Avoid 250-450°C temper (tempered-martensite embrittlement, TME)",
            "C ≈ 0.4 ⇒ Ms ≈ 320°C ⇒ full martensite needs oil quench",
        ],
        citation=f"SAE AMS6322L Table 2 ({temper_condition})",
    )


# Registry — engineers can iterate `available_routes()` for a UI dropdown
_REGISTRY = {
    "AMS5662": AMS5662,
    "AMS5704": AMS5704,
    "AMS5613_H900": lambda: AMS5613("H900"),
    "AMS5613_H1025": lambda: AMS5613("H1025"),
    "AMS5613_H1075": lambda: AMS5613("H1075"),
    "AMS5599": AMS5599,
    "AMS4928": AMS4928,
    "AMS_QQ_A_225_5": AMS_QQ_A_225_5,
    "AMS_QQ_A_250_12": AMS_QQ_A_250_12,
    "AMS6322_T200": lambda: AMS6322("tempered_200C"),
    "AMS6322_T400": lambda: AMS6322("tempered_400C"),
    "AMS6322_T500": lambda: AMS6322("tempered_500C"),
    "AMS6322_T650": lambda: AMS6322("tempered_650C"),
}


def get_route(name: str) -> AMSHeatTreatSchedule:
    """Look up a route by registry name."""

    if name not in _REGISTRY:
        raise KeyError(f"Unknown AMS route {name!r}. Choose from {list(_REGISTRY)}")
    return _REGISTRY[name]()


def available_routes() -> list:
    """Return the list of canonical route names."""

    return list(_REGISTRY)


__all__ = [
    "AMSHeatTreatSchedule",
    "AMS5662", "AMS5704", "AMS5613", "AMS5599", "AMS4928",
    "AMS_QQ_A_225_5", "AMS_QQ_A_250_12", "AMS6322",
    "get_route", "available_routes",
]
