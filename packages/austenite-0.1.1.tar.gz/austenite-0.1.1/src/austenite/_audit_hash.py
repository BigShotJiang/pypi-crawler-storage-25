"""Deterministic JSON canonical form + SHA-256 hashing for audit replay.

Hash design — what survives a re-run and what doesn't:

  * **Numbers** round to 12 significant figures so that the same calc on
    two different x87 / SSE2 / FMA-enabled CPUs hashes identically. This
    is well inside any engineering tolerance (1 ppm precision) and well
    above IEEE-754 double-precision floor (~16 digits). The 1e-12 ULP
    noise from re-running a Bayesian solver therefore doesn't change the
    hash.
  * **Object keys** are sorted lexicographically so dict insertion order
    is irrelevant.
  * **NaN / ±Infinity** serialize as the strings ``"NaN"``, ``"Infinity"``,
    ``"-Infinity"`` — JSON itself can't express these, so we substitute
    sentinel strings; an audit record carrying NaN still hashes stably.
  * **None / null** is preserved verbatim.

We intentionally do **not** use ``json.dumps(..., sort_keys=True)`` alone
because that does not round numbers and so two posteriors that differ in
the 14th decimal place would hash differently across CPUs / library
versions / OS-level math libs.

References:
  Tribello, G.A. & Ceriotti, M. "The reproducibility crisis in
  computational science", arXiv:2202.04915 (2022).
"""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any


_DEFAULT_SIG_FIGS = 12


def _round_sigfig(x: float, sig: int = _DEFAULT_SIG_FIGS) -> float:
    """Round ``x`` to ``sig`` significant figures.

    Returns ``x`` unchanged if it's NaN, ±Infinity, or zero (no rounding
    is meaningful for those cases).
    """

    if x == 0.0 or not math.isfinite(x):
        return x
    magnitude = math.floor(math.log10(abs(x)))
    factor = 10 ** (sig - 1 - magnitude)
    return math.copysign(round(abs(x) * factor) / factor, x)


def canonicalize(value: Any, sig: int = _DEFAULT_SIG_FIGS) -> Any:
    """Recursively coerce ``value`` into its canonical JSON form.

    The result is **always** JSON-serializable with ``json.dumps`` and is
    invariant under:

      * dict insertion order
      * trailing zeros in floats
      * ±1 ULP perturbation of any number
      * conversion of tuples to lists

    Args:
        value: Any JSON-ish Python value.
        sig: Significant figures to round numbers to (default 12).

    Returns:
        A JSON-compatible value (dict, list, str, int, float, bool, None).
    """

    if isinstance(value, bool):
        # bool must be checked before int (it subclasses int in Python).
        return bool(value)
    if isinstance(value, int):
        return int(value)
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        if math.isinf(value):
            return "Infinity" if value > 0 else "-Infinity"
        return _round_sigfig(value, sig)
    if isinstance(value, str):
        return value
    if value is None:
        return None
    if isinstance(value, dict):
        # Sort keys lexicographically; coerce non-string keys to str
        # deterministically.
        return {
            str(k): canonicalize(v, sig)
            for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))
        }
    if isinstance(value, (list, tuple)):
        return [canonicalize(v, sig) for v in value]
    if isinstance(value, (bytes, bytearray)):
        # Hash-safe: encode as base16.
        return value.hex()
    # Fallback: stringify via repr for anything else.
    return str(value)


def canonical_json(value: Any, sig: int = _DEFAULT_SIG_FIGS) -> str:
    """Serialize ``value`` to a canonical JSON string.

    Two values that are equivalent up to the ``sig`` significant figures
    of every number produce the same string.
    """

    canon = canonicalize(value, sig)
    # ``separators=(",", ":")`` removes whitespace; ``sort_keys`` is
    # redundant (already sorted) but harmless. ``ensure_ascii=False`` so
    # canonical strings stay UTF-8 (matters for multilingual MTC fields).
    return json.dumps(canon, separators=(",", ":"), ensure_ascii=False)


def hash_record(value: Any, sig: int = _DEFAULT_SIG_FIGS) -> str:
    """Return the hex SHA-256 of the canonical JSON of ``value``.

    Used as the integrity stamp of an audit record. A replay that
    reproduces the same canonical JSON returns the same hash.
    """

    payload = canonical_json(value, sig).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()
