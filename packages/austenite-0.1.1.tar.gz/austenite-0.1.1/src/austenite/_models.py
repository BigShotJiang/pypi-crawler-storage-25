"""Pydantic dataclasses for inputs and outputs of every endpoint.

All output models use ``model_config = ConfigDict(extra="allow")`` so that the
server can add new fields without breaking older clients.
"""

from __future__ import annotations

from typing import Any, Mapping, Optional

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Shared base classes
# ---------------------------------------------------------------------------


class _BaseInput(BaseModel):
    """Input models forbid unknown fields so typos surface early."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class _BaseOutput(BaseModel):
    """Output models allow extra fields for forward compatibility."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)


class Citation(_BaseOutput):
    """A single literature citation returned by the engine."""

    source: Optional[str] = None
    doi: Optional[str] = None
    url: Optional[str] = None
    page: Optional[str] = None
    note: Optional[str] = None


class PosteriorBand(_BaseOutput):
    """Bayesian posterior summary (mean + credible interval)."""

    mean: float
    p05: Optional[float] = None
    p50: Optional[float] = None
    p95: Optional[float] = None
    stdev: Optional[float] = None
    n_samples: Optional[int] = None


# ---------------------------------------------------------------------------
# design_path
# ---------------------------------------------------------------------------


class DesignPathInput(_BaseInput):
    alloy: Optional[str] = None
    composition: Optional[Mapping[str, float]] = None
    cooling_rate: float = 10.0
    T0_C: float = 850.0
    grain_size_ASTM: int = 7
    spec: Optional[str] = None
    sigma_app_MPa: Optional[float] = None
    posterior: bool = False


class Properties(_BaseOutput):
    sigma_y_MPa: Optional[float] = None
    sigma_uts_MPa: Optional[float] = None
    elongation_pct: Optional[float] = None
    hardness_HV: Optional[float] = None
    K_IC_MPa_sqrt_m: Optional[float] = None
    endurance_limit_MPa: Optional[float] = None


class ComplianceVerdict(_BaseOutput):
    spec: Optional[str] = None
    pass_: Optional[bool] = Field(default=None, alias="pass")
    p_pass: Optional[float] = None
    margin: Optional[float] = None
    notes: Optional[str] = None


class DesignPathResult(_BaseOutput):
    properties: Properties
    compliance: Optional[ComplianceVerdict] = None
    citations: list[Citation] = Field(default_factory=list)
    posterior: Optional[Mapping[str, PosteriorBand]] = None
    trace_id: Optional[str] = None


# ---------------------------------------------------------------------------
# AM
# ---------------------------------------------------------------------------


class AmQualificationInput(_BaseInput):
    alloy: str
    process: str = "LPBF"
    laser_power_W: float
    scan_speed_mm_s: float
    hatch_um: float
    layer_um: float
    spec: Optional[str] = None


class AmQualificationResult(_BaseOutput):
    energy_density_J_mm3: float
    melt_pool_regime: Optional[str] = None
    porosity_pct: Optional[float] = None
    properties: Optional[Properties] = None
    compliance: Optional[ComplianceVerdict] = None
    citations: list[Citation] = Field(default_factory=list)


class AmSweepInput(_BaseInput):
    alloy: str
    process: str = "LPBF"
    laser_power_W: list[float]
    scan_speed_mm_s: list[float]
    hatch_um: float
    layer_um: float


class AmSweepPoint(_BaseOutput):
    laser_power_W: float
    scan_speed_mm_s: float
    energy_density_J_mm3: float
    porosity_pct: Optional[float] = None
    regime: Optional[str] = None


class AmSweepResult(_BaseOutput):
    points: list[AmSweepPoint]
    process_window: Optional[Mapping[str, Any]] = None


# ---------------------------------------------------------------------------
# MTC
# ---------------------------------------------------------------------------


class MtcParseInput(_BaseInput):
    pdf_b64: Optional[str] = None
    pdf_url: Optional[str] = None
    text: Optional[str] = None


class MtcParseResult(_BaseOutput):
    heat_number: Optional[str] = None
    grade: Optional[str] = None
    composition: Mapping[str, float] = Field(default_factory=dict)
    mechanical: Optional[Properties] = None
    compliance: Optional[ComplianceVerdict] = None
    confidence: Optional[float] = None


class MtcDetectGradeInput(_BaseInput):
    composition: Mapping[str, float]


class MtcDetectGradeResult(_BaseOutput):
    candidates: list[Mapping[str, Any]]
    best: Optional[str] = None
    confidence: Optional[float] = None


# ---------------------------------------------------------------------------
# TTT / CCT
# ---------------------------------------------------------------------------


class TttComputeInput(_BaseInput):
    composition: Mapping[str, float]
    grain_size_ASTM: int = 7
    austenitization_C: Optional[float] = None


class TttCurve(_BaseOutput):
    phase: str
    temperature_C: list[float]
    time_s: list[float]


class TttComputeResult(_BaseOutput):
    curves: list[TttCurve]
    Ms_C: Optional[float] = None
    Bs_C: Optional[float] = None
    citations: list[Citation] = Field(default_factory=list)


class CctSweepInput(_BaseInput):
    composition: Mapping[str, float]
    cooling_rates_C_s: list[float]
    grain_size_ASTM: int = 7


class CctSweepResult(_BaseOutput):
    curves: list[TttCurve]
    final_microstructure: list[Mapping[str, Any]]


# ---------------------------------------------------------------------------
# CALPHAD
# ---------------------------------------------------------------------------


class CalphadEquilibriumInput(_BaseInput):
    composition: Mapping[str, float]
    T_K: float
    P_Pa: float = 101_325.0
    database: Optional[str] = None


class PhaseFraction(_BaseOutput):
    phase: str
    fraction: float
    composition: Optional[Mapping[str, float]] = None


class CalphadEquilibriumResult(_BaseOutput):
    T_K: float
    phases: list[PhaseFraction]
    citations: list[Citation] = Field(default_factory=list)


class CalphadTernaryInput(_BaseInput):
    elements: list[str]
    T_K: float
    n_grid: int = 50
    database: Optional[str] = None


class CalphadTernaryResult(_BaseOutput):
    elements: list[str]
    T_K: float
    grid: list[Mapping[str, Any]]


# ---------------------------------------------------------------------------
# Bayesian
# ---------------------------------------------------------------------------


class BayesianCalphadInput(_BaseInput):
    composition: Mapping[str, float]
    T_K: float
    phase: str = "sigma"
    n_samples: int = 1000


class BayesianCalphadResult(_BaseOutput):
    phase: str
    posterior: PosteriorBand
    p_compliant: Optional[float] = None
    citations: list[Citation] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Bayesian — deep / hierarchical-prior variant
# ---------------------------------------------------------------------------


class BayesianCalphadDeepInput(_BaseInput):
    composition: Optional[Mapping[str, float]] = None
    T_K: Optional[float] = None
    dataset: str = "hammar-1979-sigma"
    chains: int = 2
    samples: int = 3000
    burn: Optional[int] = None
    method: str = "dram"
    seed: Optional[int] = None


class HpdInterval(_BaseOutput):
    """Highest-posterior-density credible interval (Chen-Shao 1999)."""

    lo: float
    hi: float
    prob: Optional[float] = None


class PosteriorPredictive(_BaseOutput):
    """PPC band + calibration score (Gelman et al. BDA Ch. 6)."""

    calibration_score: float = Field(alias="calibrationScore")
    xs: list[float] = Field(default_factory=list)
    median: list[float] = Field(default_factory=list)
    lo95: list[float] = Field(default_factory=list)
    hi95: list[float] = Field(default_factory=list)
    obs: list[Mapping[str, float]] = Field(default_factory=list)


class BayesianCalphadDeepResult(_BaseOutput):
    """Deep Bayesian-CALPHAD posterior with R-hat + HPD + PPC."""

    dataset: str
    datasetId: Optional[str] = None
    family: Optional[str] = None
    citation: Optional[str] = None
    paramNames: list[str] = Field(default_factory=list)
    nChains: Optional[int] = None
    nSamplesPerChain: Optional[int] = None
    sampler: Optional[str] = None
    acceptanceRate: Optional[float] = None
    posteriorMean: list[float] = Field(default_factory=list)
    posteriorStd: list[float] = Field(default_factory=list)
    posteriorQuantiles: Optional[Mapping[str, list[float]]] = None
    MAP: list[float] = Field(default_factory=list)
    rHat: list[float] = Field(default_factory=list)
    """Per-parameter R-hat keyed by parameter name (Brooks-Gelman 1998)."""
    r_hat: Mapping[str, float] = Field(default_factory=dict)
    hpd50: list[HpdInterval] = Field(default_factory=list)
    hpd80: list[HpdInterval] = Field(default_factory=list)
    hpd95: list[HpdInterval] = Field(default_factory=list)
    """HPD 95% intervals keyed by parameter name."""
    hpd_95: Mapping[str, HpdInterval] = Field(default_factory=dict)
    posterior_predictive: Optional[PosteriorPredictive] = Field(
        default=None, alias="posteriorPredictive"
    )


# ---------------------------------------------------------------------------
# Compliance — Bayesian P(PASS)
# ---------------------------------------------------------------------------


class ComplianceBayesianPPassState(_BaseInput):
    posteriorMean: Optional[float] = None
    posteriorStd: Optional[float] = None
    samples: Optional[list[float]] = None


class ComplianceBayesianPPassInput(_BaseInput):
    state: ComplianceBayesianPPassState
    spec: str
    T_C: float
    target_sigma_y_MPa: float
    safety_factor: float = 1.5


class ComplianceBayesianPPassResult(_BaseOutput):
    spec: str
    original_spec: Optional[str] = None
    T_C: float
    S_allow_MPa: float
    target_sigma_y_MPa: float
    safety_factor: Optional[float] = None
    posteriorMean_MPa: float
    posteriorStd_MPa: float
    p_pass: float
    margin: Optional[float] = None
    verdict: str
    notes: list[str] = Field(default_factory=list)
    citations: list[Citation] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Calibrate — ShopPrior
# ---------------------------------------------------------------------------


class CalibrateObservations(_BaseInput):
    sigma_y_MPa: Optional[list[float]] = None
    records: Optional[list[Mapping[str, Any]]] = None


class CalibrateInput(_BaseInput):
    pretrained: str
    observations: CalibrateObservations
    method: str = "dram"
    samples: int = 3000
    burn: Optional[int] = None
    chains: int = 2
    seed: Optional[int] = None
    obsNoise_MPa: float = 25.0


class CalibrateResult(_BaseOutput):
    id: str
    pretrained: str
    pretrained_description: Optional[str] = None
    n_observations: int
    obs_mean_MPa: Optional[float] = None
    obs_std_MPa: Optional[float] = None
    prior_mean_MPa: Optional[float] = None
    prior_std_MPa: Optional[float] = None
    obs_noise_MPa: Optional[float] = None
    posteriorMean_MPa: float
    posteriorStd_MPa: float
    posteriorQuantiles: Optional[Mapping[str, float]] = None
    hpd_95: Optional[HpdInterval] = None
    rHat: Optional[float] = None
    acceptanceRate: Optional[float] = None
    nChains: Optional[int] = None
    nSamplesPerChain: Optional[int] = None
    sampler: Optional[str] = None
    citations: list[Citation] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------


class AuditRecordInput(_BaseInput):
    call_id: str
    endpoint: str
    payload: Mapping[str, Any]
    result: Mapping[str, Any]


class AuditRecordResult(_BaseOutput):
    audit_id: str
    timestamp: str


class AuditReplayInput(_BaseInput):
    audit_id: str


class AuditReplayResult(_BaseOutput):
    audit_id: str
    endpoint: str
    payload: Mapping[str, Any]
    original_result: Mapping[str, Any]
    replay_result: Mapping[str, Any]
    matches: bool
