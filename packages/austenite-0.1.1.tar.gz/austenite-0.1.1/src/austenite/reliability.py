"""Reliability statistics — Weibull fits, Cox PH, Arrhenius ALT, RBD systems.

Ports the TypeScript ``apps/web/src/lib/reliability-advanced`` engine to
pure Python. No SciPy required; uses :mod:`math` and small custom
implementations (Newton-Raphson, Wilson-Hilferty, Beasley-Springer-Moro).

Public API (mirrors the JS side wherever practical)::

    au.reliability.weibull_fit(times, censored)
    au.reliability.cox_ph(df, covariates)
    au.reliability.arrhenius_alt(test_matrix, use_T_K)
    au.reliability.system(topology, components, k)
    au.reliability.RBD()      # builder

References:
  * Weibull W., J. Appl. Mech. 18 (1951) 293.
  * Rinne H., The Weibull Distribution: A Handbook, CRC (2008).
  * Cox D.R., J. Roy. Stat. Soc. B 34 (1972) 187.
  * Therneau-Grambsch, Modeling Survival Data, Springer (2000).
  * Nelson W., Accelerated Testing, Wiley (1990).
  * IEC 62506 — Methods for product accelerated testing.
  * Hoyland-Rausand, System Reliability Theory, 2nd ed. Wiley (2003).
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Optional, Sequence, Union


# ---------------------------------------------------------------------------
# Numerics — phi / phi_inv / log-gamma (used across MLE + Wald + Wilson-Hilferty)
# ---------------------------------------------------------------------------


def _phi_cdf(x: float) -> float:
    """Standard-normal CDF — Abramowitz-Stegun 7.1.26 rational approximation."""

    sign = -1.0 if x < 0 else 1.0
    ax = abs(x) / math.sqrt(2)
    t = 1.0 / (1.0 + 0.3275911 * ax)
    y = 1.0 - (
        (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736)
         * t + 0.254829592) * t * math.exp(-ax * ax)
    )
    return 0.5 * (1 + sign * y)


def _phi_inv(p: float) -> float:
    """Inverse standard-normal CDF — Beasley-Springer-Moro."""

    if p <= 0:
        return -10.0
    if p >= 1:
        return 10.0
    a = [-39.6968302866538, 220.946098424521, -275.928510446969,
         138.357751867269, -30.6647980661472, 2.50662827745924]
    b = [-54.4760987982241, 161.585836858041, -155.698979859887,
         66.8013118877197, -13.2806815528857]
    c = [-7.78489400243029e-3, -0.322396458041136, -2.40075827716184,
         -2.54973253934373, 4.37466414146497, 2.93816398269878]
    d = [7.78469570904146e-3, 0.32246712907004, 2.445134137143,
         3.75440866190742]
    if p < 0.02425:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
               ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    if p < 1 - 0.02425:
        q = p - 0.5
        r = q * q
        return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / \
               (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)
    q = math.sqrt(-2 * math.log(1 - p))
    return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / \
            ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)


# ---------------------------------------------------------------------------
# 1. WEIBULL-2 FIT (with right-censored support — MLE Newton-Raphson)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class WeibullFit:
    """Output of :func:`weibull_fit`.

    Attributes:
        beta: Shape parameter (β > 1 → wear-out; β = 1 → exponential).
        eta: Scale parameter (characteristic life, 63.2 % failure time).
        MTTF: Mean time to failure = η · Γ(1 + 1/β).
        B10: Time at 10 % failure CDF.
        B50: Median failure time (B50 = η · (ln 2)^(1/β)).
        R2: Coefficient of determination from rank-regression linearisation.
        n_failures: Count of observed failures (uncensored).
        n_censored: Count of right-censored observations.
        converged: Whether MLE Newton-Raphson converged.
    """

    beta: float
    eta: float
    MTTF: float
    B10: float
    B50: float
    R2: float
    n_failures: int
    n_censored: int
    converged: bool

    def cdf(self, t: float) -> float:
        """F(t) = 1 − exp(−(t/η)^β)."""

        if t <= 0 or self.beta <= 0 or self.eta <= 0:
            return 0.0
        return 1.0 - math.exp(-((t / self.eta) ** self.beta))

    def reliability(self, t: float) -> float:
        """R(t) = exp(−(t/η)^β)."""

        return 1.0 - self.cdf(t)


def _log_gamma(x: float) -> float:
    """Stirling log-gamma series (Lanczos coefficients)."""

    if x <= 0:
        return float("inf")
    return math.lgamma(x)


def _median_rank(i: int, n: int) -> float:
    """Bernard's median-rank approximation."""

    return (i - 0.3) / (n + 0.4)


def weibull_fit(
    times: Sequence[float],
    censored: Optional[Sequence[bool]] = None,
    *,
    max_iter: int = 100,
    tol: float = 1e-7,
) -> WeibullFit:
    """Two-parameter Weibull fit with right-censoring (MLE Newton-Raphson).

    The MLE log-likelihood for Weibull-2 with right-censored data
    (Rinne 2008 §13.6.2):

        ℓ(β, η) = Σ_failures [ln β − β·ln η + (β−1)·ln t_i − (t_i/η)^β]
                  − Σ_censored (t_i/η)^β

    Profile-likelihood: for any β, η̂(β) = (Σ t_i^β / r)^(1/β) where r is
    the failure count. We Newton-Raphson on β.

    Args:
        times: Failure / censoring times, positive numbers.
        censored: Optional list; ``True`` = right-censored observation.
            Defaults to all ``False`` (complete data).
        max_iter: Newton iterations cap (default 100).
        tol: Δβ convergence threshold (default 1e-7).

    Returns:
        :class:`WeibullFit` with β, η, MTTF, B10/B50, R², convergence flag.
    """

    t = [float(x) for x in times if x is not None and math.isfinite(float(x)) and float(x) > 0]
    if censored is None:
        cens = [False] * len(t)
    else:
        cens = [bool(x) for x in censored][: len(t)]
        # pad with False if user gave fewer flags than times
        while len(cens) < len(t):
            cens.append(False)
    n = len(t)
    if n < 3:
        return WeibullFit(0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                          n_failures=0, n_censored=0, converged=False)

    r = sum(1 for c in cens if not c)   # number of failures
    if r < 1:
        return WeibullFit(0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                          n_failures=0, n_censored=n, converged=False)

    # MLE for β via Newton-Raphson on profile log-likelihood
    def g(beta: float) -> tuple[float, float]:
        """Return (∂ℓ/∂β, ∂²ℓ/∂β²) at the profile-η̂(β)."""

        s0 = 0.0      # Σ t_i^β
        s1 = 0.0      # Σ t_i^β ln t_i
        s2 = 0.0      # Σ t_i^β (ln t_i)^2
        s_lnf = 0.0   # Σ_failures ln t_i
        for ti, ci in zip(t, cens):
            tb = ti ** beta
            lnt = math.log(ti)
            s0 += tb
            s1 += tb * lnt
            s2 += tb * lnt * lnt
            if not ci:
                s_lnf += lnt
        if s0 <= 0:
            return 0.0, 1.0
        # dℓ/dβ = r/β + Σ_F ln t_i − r · (s1/s0)
        dl = r / beta + s_lnf - r * (s1 / s0)
        # d²ℓ/dβ² = −r/β² − r · [s2/s0 − (s1/s0)²]
        d2l = -r / (beta * beta) - r * (s2 / s0 - (s1 / s0) ** 2)
        return dl, d2l

    # Reasonable initial guess from rank-regression on uncensored data
    beta = 1.0
    converged = False
    for _ in range(max_iter):
        dl, d2l = g(beta)
        if d2l == 0 or not math.isfinite(d2l):
            break
        delta = dl / d2l
        beta_new = beta - delta
        if beta_new <= 0 or not math.isfinite(beta_new):
            beta_new = max(beta * 0.5, 0.05)
        if abs(beta_new - beta) < tol:
            beta = beta_new
            converged = True
            break
        beta = beta_new
    beta = max(beta, 1e-6)

    # η̂ = (Σ t_i^β / r)^(1/β)
    s0 = sum(ti ** beta for ti in t)
    eta = (s0 / r) ** (1.0 / beta) if r > 0 and s0 > 0 else 0.0

    # MTTF, B10, B50
    if eta > 0 and beta > 0:
        mttf = eta * math.exp(_log_gamma(1.0 + 1.0 / beta))
        b10 = eta * (-math.log(0.9)) ** (1.0 / beta)
        b50 = eta * (math.log(2.0)) ** (1.0 / beta)
    else:
        mttf = b10 = b50 = 0.0

    # R² from Weibull-paper rank-regression (failures only)
    failure_times = sorted([ti for ti, ci in zip(t, cens) if not ci])
    if len(failure_times) >= 2:
        x = [math.log(ti) for ti in failure_times]
        y = [math.log(-math.log(max(1e-12, 1 - _median_rank(i + 1, len(failure_times)))))
             for i in range(len(failure_times))]
        n2 = len(x)
        sx = sum(x)
        sy = sum(y)
        sxx = sum(xi * xi for xi in x)
        sxy = sum(xi * yi for xi, yi in zip(x, y))
        denom = n2 * sxx - sx * sx
        if abs(denom) > 1e-12:
            slope = (n2 * sxy - sx * sy) / denom
            intercept = (sy - slope * sx) / n2
            ymean = sy / n2
            ss_res = sum((yi - (slope * xi + intercept)) ** 2 for xi, yi in zip(x, y))
            ss_tot = sum((yi - ymean) ** 2 for yi in y)
            r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0
        else:
            r2 = 0.0
    else:
        r2 = 0.0

    return WeibullFit(
        beta=beta, eta=eta, MTTF=mttf, B10=b10, B50=b50, R2=r2,
        n_failures=r, n_censored=n - r, converged=converged,
    )


# ---------------------------------------------------------------------------
# 2. COX PROPORTIONAL HAZARDS (multivariate)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CoxFit:
    """Output of :func:`cox_ph`.

    Attributes:
        coefficients: Dict mapping covariate name → β coefficient.
        hazard_ratios: Dict covariate → exp(β).
        se: Dict covariate → standard error (sqrt of inverse Fisher info diagonal).
        p_values: Dict covariate → Wald two-sided p-value.
        loglik: Maximised partial log-likelihood.
        loglik_null: ℓ(0) for the likelihood-ratio test.
        LR_statistic: 2·(ℓ_max − ℓ_null) — overall model significance.
        n_events: Count of observed events.
        n_censored: Count of right-censored observations.
        iterations: Newton-Raphson iterations used.
        converged: Whether Newton-Raphson converged.
    """

    coefficients: dict[str, float]
    hazard_ratios: dict[str, float]
    se: dict[str, float]
    p_values: dict[str, float]
    loglik: float
    loglik_null: float
    LR_statistic: float
    n_events: int
    n_censored: int
    iterations: int
    converged: bool


def _zeros(r: int, c: int) -> list[list[float]]:
    return [[0.0] * c for _ in range(r)]


def _identity(n: int) -> list[list[float]]:
    return [[1.0 if i == j else 0.0 for j in range(n)] for i in range(n)]


def _mat_vec(M: list[list[float]], v: list[float]) -> list[float]:
    n = len(M)
    out = [0.0] * n
    for i in range(n):
        for j in range(len(v)):
            out[i] += M[i][j] * v[j]
    return out


def _invert_matrix(M: list[list[float]]) -> Optional[list[list[float]]]:
    """Gauss-Jordan; returns None on singular."""

    n = len(M)
    A = [row[:] for row in M]
    I = _identity(n)
    for k in range(n):
        pivot_row = k
        pivot_val = abs(A[k][k])
        for i in range(k + 1, n):
            if abs(A[i][k]) > pivot_val:
                pivot_val = abs(A[i][k]); pivot_row = i
        if pivot_val < 1e-15:
            return None
        if pivot_row != k:
            A[k], A[pivot_row] = A[pivot_row], A[k]
            I[k], I[pivot_row] = I[pivot_row], I[k]
        piv = A[k][k]
        for j in range(n):
            A[k][j] /= piv
            I[k][j] /= piv
        for i in range(n):
            if i == k:
                continue
            factor = A[i][k]
            if factor == 0:
                continue
            for j in range(n):
                A[i][j] -= factor * A[k][j]
                I[i][j] -= factor * I[k][j]
    return I


def cox_ph(
    df: Any,
    covariates: Sequence[str],
    *,
    time_col: str = "time",
    event_col: str = "event",
    max_iter: int = 50,
    tol: float = 1e-7,
) -> CoxFit:
    """Cox proportional-hazards regression with Newton-Raphson MLE.

    Accepts either a ``pandas.DataFrame`` or a list of dicts. Each row needs
    ``time``, ``event`` (1 = event, 0 = censored), and the named covariates.

    The partial log-likelihood (Breslow tie-handling, identical to the JS
    implementation in ``apps/web/src/lib/reliability-advanced/enhancements2.ts``):

        ℓ(β) = Σ_events [β·x_i − ln Σ_{j ∈ R(t_i)} exp(β·x_j)]

    Standard errors come from the diagonal of the inverse observed Fisher
    information. Wald p-values use the two-sided standard-normal tail.
    """

    rows: list[dict[str, Any]] = []
    try:
        import pandas as pd  # type: ignore
        if isinstance(df, pd.DataFrame):
            for _, r in df.iterrows():
                rows.append(dict(r))
        else:
            rows = list(df)
    except ImportError:
        rows = list(df)

    covs = list(covariates)
    p = len(covs)
    data: list[tuple[float, int, list[float]]] = []
    for r in rows:
        try:
            tt = float(r[time_col])
            ev = int(r[event_col])
            xs = [float(r[c]) for c in covs]
        except (KeyError, TypeError, ValueError):
            continue
        if not math.isfinite(tt) or tt <= 0:
            continue
        if not all(math.isfinite(x) for x in xs):
            continue
        data.append((tt, 1 if ev else 0, xs))
    if len(data) < 3 or p == 0:
        return CoxFit({}, {}, {}, {}, 0.0, 0.0, 0.0,
                      n_events=0, n_censored=0, iterations=0, converged=False)

    data.sort(key=lambda d: d[0])
    beta = [0.0] * p
    converged = False
    iterations = 0
    loglik = 0.0
    last_info: list[list[float]] = _identity(p)

    for it in range(max_iter):
        iterations = it + 1
        U = [0.0] * p
        I = _zeros(p, p)
        loglik = 0.0
        for ev_t, ev_e, ev_x in data:
            if ev_e == 0:
                continue
            s_exp = 0.0
            sx_exp = [0.0] * p
            sxx_exp = _zeros(p, p)
            for r_t, _, r_x in data:
                if r_t < ev_t:
                    continue
                bx = sum(beta[k] * r_x[k] for k in range(p))
                w = math.exp(bx)
                s_exp += w
                for k in range(p):
                    sx_exp[k] += r_x[k] * w
                    for j in range(p):
                        sxx_exp[k][j] += r_x[k] * r_x[j] * w
            if s_exp <= 0:
                continue
            bxe = sum(beta[k] * ev_x[k] for k in range(p))
            loglik += bxe - math.log(s_exp)
            xbar = [sx_exp[k] / s_exp for k in range(p)]
            for k in range(p):
                U[k] += ev_x[k] - xbar[k]
                for j in range(p):
                    I[k][j] += sxx_exp[k][j] / s_exp - xbar[k] * xbar[j]
        last_info = I
        I_inv = _invert_matrix(I)
        if I_inv is None:
            break
        d_beta = _mat_vec(I_inv, U)
        max_abs = max(abs(x) for x in d_beta) if d_beta else 0.0
        for k in range(p):
            beta[k] += d_beta[k]
        if max_abs < tol:
            converged = True
            break

    # Null log-likelihood (β = 0)
    loglik_null = 0.0
    for ev_t, ev_e, ev_x in data:
        if ev_e == 0:
            continue
        s_exp = 0.0
        for r_t, _, _ in data:
            if r_t >= ev_t:
                s_exp += 1.0  # exp(0) = 1
        if s_exp > 0:
            loglik_null += 0 - math.log(s_exp)

    # SEs and p-values
    I_inv = _invert_matrix(last_info)
    se_list = [0.0] * p
    if I_inv is not None:
        for k in range(p):
            v = I_inv[k][k]
            if v > 0:
                se_list[k] = math.sqrt(v)
    p_values = []
    for k in range(p):
        if se_list[k] == 0:
            p_values.append(1.0)
        else:
            z = beta[k] / se_list[k]
            p_values.append(2.0 * (1.0 - _phi_cdf(abs(z))))

    n_events = sum(1 for _, ev, _ in data if ev == 1)
    n_censored = len(data) - n_events

    coefs = {covs[k]: beta[k] for k in range(p)}
    hrs = {covs[k]: math.exp(beta[k]) for k in range(p)}
    ses = {covs[k]: se_list[k] for k in range(p)}
    ps = {covs[k]: p_values[k] for k in range(p)}

    return CoxFit(
        coefficients=coefs, hazard_ratios=hrs, se=ses, p_values=ps,
        loglik=loglik, loglik_null=loglik_null,
        LR_statistic=2.0 * (loglik - loglik_null),
        n_events=n_events, n_censored=n_censored,
        iterations=iterations, converged=converged,
    )


# ---------------------------------------------------------------------------
# 3. ARRHENIUS ACCELERATED-LIFE TESTING
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ArrheniusFit:
    """Output of :func:`arrhenius_alt`.

    Attributes:
        E_a_eV: Activation energy in eV (1 eV ≈ 96.485 kJ/mol).
        A: Pre-exponential factor (same time units as input t50).
        R2: Coefficient of determination of ln(t50) vs 1/T.
        T_use_K: Use temperature (K) passed in.
        t50_at_use_T: Predicted median life at use temperature.
        acceleration_factor: t50_at_use_T / min(t50 over tested cells).
        E_a_se: Standard error of E_a from regression (1σ).
        citation: Reference for the model.
    """

    E_a_eV: float
    A: float
    R2: float
    T_use_K: float
    t50_at_use_T: float
    acceleration_factor: float
    E_a_se: float
    citation: str


def arrhenius_alt(
    test_matrix: Sequence[Mapping[str, float]],
    use_T_K: float,
) -> ArrheniusFit:
    """Arrhenius ALT extrapolation: ln(t50) = ln(A) + (E_a/k_B) · (1/T).

    Args:
        test_matrix: Per-cell test data; each entry must have ``T_K`` and
            ``t50_h`` (any positive time unit). Optional ``n`` for weight.
        use_T_K: The use (service) temperature in Kelvin.

    Returns:
        :class:`ArrheniusFit`. Coefficient of determination is computed in
        log-time / inverse-T space (the line fit), per Nelson 1990 §2.
    """

    k_B_eV = 8.617333262e-5  # Boltzmann in eV / K
    citation = "Nelson W., Accelerated Testing, Wiley (1990) §2; IEC 62506 §6.4"

    pts: list[tuple[float, float, float]] = []
    for cell in test_matrix:
        try:
            T = float(cell.get("T_K", float("nan")))
            t50 = float(cell.get("t50_h", float("nan")))
            w = float(cell.get("n", 1.0))
        except (TypeError, ValueError):
            continue
        if math.isfinite(T) and math.isfinite(t50) and T > 0 and t50 > 0:
            pts.append((T, t50, max(1.0, w)))
    if len(pts) < 2:
        return ArrheniusFit(0.0, 0.0, 0.0, float(use_T_K), 0.0, 1.0, 0.0, citation)

    sw = sx = sy = sxx = sxy = 0.0
    for T, t50, w in pts:
        x = 1.0 / T
        y = math.log(t50)
        sw += w
        sx += w * x
        sy += w * y
        sxx += w * x * x
        sxy += w * x * y
    denom = sw * sxx - sx * sx
    if abs(denom) < 1e-20:
        return ArrheniusFit(0.0, 0.0, 0.0, float(use_T_K), 0.0, 1.0, 0.0, citation)

    slope = (sw * sxy - sx * sy) / denom
    intercept = (sy - slope * sx) / sw
    E_a_eV = slope * k_B_eV
    A = math.exp(intercept)
    t50_use = A * math.exp(slope / float(use_T_K))

    y_mean = sy / sw
    ss_res = 0.0
    ss_tot = 0.0
    for T, t50, w in pts:
        x = 1.0 / T
        y = math.log(t50)
        y_pred = intercept + slope * x
        ss_res += w * (y - y_pred) ** 2
        ss_tot += w * (y - y_mean) ** 2
    r2 = 1.0 - ss_res / ss_tot if ss_tot > 0 else 0.0

    dof = max(1, len(pts) - 2)
    sigma2 = ss_res / dof
    slope_se = math.sqrt(max(1e-30, sigma2 * sw / denom))
    E_a_se = abs(slope_se * k_B_eV)

    t50_min_test = min(p[1] for p in pts)
    af = t50_use / max(1e-30, t50_min_test)

    return ArrheniusFit(
        E_a_eV=E_a_eV, A=A, R2=r2, T_use_K=float(use_T_K),
        t50_at_use_T=t50_use, acceleration_factor=af, E_a_se=E_a_se,
        citation=citation,
    )


# ---------------------------------------------------------------------------
# 4. SYSTEM RELIABILITY — RBD builder + textual topology parser
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SystemReliability:
    """Output of :func:`system` / :meth:`RBD.evaluate`."""

    R_system: float
    weakest_id: Optional[str]
    weakest_R: float
    nodes: list[dict[str, Any]] = field(default_factory=list)


def _binom_c(n: int, k: int) -> float:
    if k < 0 or k > n:
        return 0.0
    k = min(k, n - k)
    c = 1.0
    for i in range(k):
        c = c * (n - i) / (i + 1)
    return c


def _k_of_n_reliability(rs: Sequence[float], k: int) -> float:
    """Exact k-of-n reliability with possibly non-identical R via bitmask
    enumeration. O(2^n) — fine for n ≤ 20."""

    n = len(rs)
    if n == 0 or k <= 0:
        return 1.0
    if k > n:
        return 0.0
    if n > 20:
        rbar = sum(rs) / n
        return sum(_binom_c(n, i) * rbar ** i * (1 - rbar) ** (n - i)
                   for i in range(k, n + 1))
    prob = 0.0
    for mask in range(1 << n):
        count = 0
        p = 1.0
        for i in range(n):
            if mask & (1 << i):
                count += 1
                p *= rs[i]
            else:
                p *= 1.0 - rs[i]
        if count >= k:
            prob += p
    return max(0.0, min(1.0, prob))


class RBD:
    """Reliability-block-diagram builder.

    Add components (leaves) and sub-blocks; call :meth:`evaluate` to compute
    the system reliability and identify the weakest sub-block (lowest R in
    the decomposition).

    Example::

        rbd = au.reliability.RBD()
        rbd.add("A", R=0.95)
        rbd.add_parallel(["B", "C"], R=[0.92, 0.92])
        rbd.add_kof3(["D", "E", "F"], R=[0.88, 0.88, 0.88], k=2)
        result = rbd.evaluate()
        print(result.R_system, result.weakest_id)
    """

    def __init__(self) -> None:
        self._blocks: list[dict[str, Any]] = []

    def add(self, id: str, R: float) -> "RBD":
        """Add a single in-series component."""

        self._blocks.append({"kind": "comp", "id": id, "R": float(R)})
        return self

    def add_series(self, ids: Sequence[str], R: Sequence[float]) -> "RBD":
        """Add a series sub-block (resolved into individual comps in order)."""

        for i, r in zip(ids, R):
            self.add(i, float(r))
        return self

    def add_parallel(self, ids: Sequence[str], R: Sequence[float]) -> "RBD":
        """Add a parallel block: 1 − Π (1 − R_i)."""

        children = [{"kind": "comp", "id": i, "R": float(r)} for i, r in zip(ids, R)]
        self._blocks.append({"kind": "parallel", "id": "||".join(ids), "children": children})
        return self

    def add_kofn(self, ids: Sequence[str], R: Sequence[float], k: int) -> "RBD":
        """Add a k-of-n block (exact reliability via inclusion-exclusion)."""

        children = [{"kind": "comp", "id": i, "R": float(r)} for i, r in zip(ids, R)]
        self._blocks.append({"kind": "kofn", "id": f"{k}of{len(ids)}",
                             "k": int(k), "children": children})
        return self

    add_kof3 = add_kofn  # alias for the common case (matches the task signature)

    def evaluate(self) -> SystemReliability:
        """Compute system R as a series chain of all added blocks."""

        R_sys = 1.0
        decomp: list[dict[str, Any]] = []
        weakest_id: Optional[str] = None
        weakest_R = 1.0

        def block_R(b: dict[str, Any]) -> float:
            if b["kind"] == "comp":
                return max(0.0, min(1.0, b["R"]))
            if b["kind"] == "parallel":
                q = 1.0
                for c in b["children"]:
                    q *= 1.0 - max(0.0, min(1.0, c["R"]))
                return 1.0 - q
            if b["kind"] == "kofn":
                rs = [max(0.0, min(1.0, c["R"])) for c in b["children"]]
                return _k_of_n_reliability(rs, b["k"])
            return 1.0

        for b in self._blocks:
            R_b = block_R(b)
            decomp.append({"id": b["id"], "kind": b["kind"], "R": R_b})
            R_sys *= R_b
            if R_b < weakest_R:
                weakest_R = R_b
                weakest_id = b["id"]
        return SystemReliability(R_system=R_sys, weakest_id=weakest_id,
                                  weakest_R=weakest_R, nodes=decomp)


# Topology-string parser — supports the textual form in the task spec.
# Examples:
#   "A -> (B || C) -> kof3(D,E,F)"
#   "A -> B -> C"
#   "(A || B || C)"

_TOK_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")


def _parse_topology(topology: str) -> list[dict[str, Any]]:
    """Tiny recursive-descent parser for series/parallel/kofN expressions."""

    s = topology.replace(" ", "")
    pos = 0

    def peek() -> str:
        return s[pos] if pos < len(s) else ""

    def consume(c: str) -> None:
        nonlocal pos
        if pos >= len(s) or s[pos] != c:
            raise ValueError(f"expected {c!r} at position {pos} in {topology!r}")
        pos += 1

    def parse_atom() -> dict[str, Any]:
        nonlocal pos
        if peek() == "(":
            consume("(")
            inner = parse_parallel()
            consume(")")
            return inner
        # named atom: either bare ID or kofN(A,B,C)
        m = _TOK_NAME.match(s, pos)
        if not m:
            raise ValueError(f"expected name at position {pos} in {topology!r}")
        name = m.group(0)
        pos = m.end()
        if peek() == "(":
            # kofN-style call
            consume("(")
            children: list[str] = []
            while True:
                m2 = _TOK_NAME.match(s, pos)
                if not m2:
                    raise ValueError(f"expected component name at position {pos}")
                children.append(m2.group(0))
                pos = m2.end()
                if peek() == ",":
                    consume(",")
                    continue
                break
            consume(")")
            mk = re.match(r"^kof(\d+)$", name)
            if not mk:
                raise ValueError(f"unsupported function {name!r}")
            return {"kind": "kofn", "id": name,
                    "k": int(mk.group(1)),
                    "children": [{"kind": "comp", "id": c} for c in children]}
        return {"kind": "comp", "id": name}

    def parse_parallel() -> dict[str, Any]:
        items = [parse_atom()]
        while peek() == "|":
            consume("|")
            consume("|")
            items.append(parse_atom())
        if len(items) == 1:
            return items[0]
        return {"kind": "parallel", "id": "||".join(it["id"] for it in items), "children": items}

    def parse_series() -> list[dict[str, Any]]:
        nonlocal pos
        out = [parse_parallel()]
        while pos < len(s) and s[pos:pos + 2] == "->":
            pos += 2
            out.append(parse_parallel())
        return out

    return parse_series()


def system(
    topology: str,
    components: Mapping[str, float],
    k: Optional[int] = None,
) -> SystemReliability:
    """Evaluate a textual topology against component reliabilities.

    Args:
        topology: Expression like ``"A -> (B || C) -> kof3(D,E,F)"``.
            Supported operators: ``->`` (series), ``||`` (parallel),
            ``kofN(...)`` (k-of-n with N children).
        components: Map ``component_id → reliability ∈ [0, 1]``.
        k: Optional override for the inner ``kofN`` call's k; if not given,
           the integer in the ``kofN`` token is used.

    Returns:
        :class:`SystemReliability` with overall R_system, weakest node id,
        and per-block decomposition.
    """

    blocks = _parse_topology(topology)

    def attach_R(b: dict[str, Any]) -> dict[str, Any]:
        if b["kind"] == "comp":
            return {**b, "R": float(components.get(b["id"], 0.0))}
        return {**b, "children": [attach_R(c) for c in b["children"]]}

    blocks = [attach_R(b) for b in blocks]
    rbd = RBD()
    for b in blocks:
        if b["kind"] == "comp":
            rbd.add(b["id"], b["R"])
        elif b["kind"] == "parallel":
            rbd.add_parallel([c["id"] for c in b["children"]],
                              [c["R"] for c in b["children"]])
        elif b["kind"] == "kofn":
            rbd.add_kofn([c["id"] for c in b["children"]],
                         [c["R"] for c in b["children"]],
                         k=k if k is not None else b["k"])
    return rbd.evaluate()


# ---------------------------------------------------------------------------
# 5. EXPORT
# ---------------------------------------------------------------------------


__all__ = [
    "WeibullFit",
    "weibull_fit",
    "CoxFit",
    "cox_ph",
    "ArrheniusFit",
    "arrhenius_alt",
    "SystemReliability",
    "system",
    "RBD",
]
