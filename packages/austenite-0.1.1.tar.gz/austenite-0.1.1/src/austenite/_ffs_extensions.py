"""API 579-1 / ASME FFS-1 native engines for Parts 4 / 7 / 8 / 11 / 12 / 14.

This module extends :mod:`austenite._ffs_native` (which covers Parts 5/6/9) with
the remaining mainstream Part assessments that engineers run in Excel today:

* **Part 4 — Brittle Fracture.** Charpy V-notch → K_IC correlation per
  Roberts-Newton (Wallin 1985) and Barsom-Rolfe (1970), feeding a FAD-style
  check at the design temperature (API 579-1 §3.4 / WRC 175).
* **Part 7 — Hydrogen blisters / HIC.** Lattice hydrogen concentration ↔
  blister growth (NACE TM0284 + Park & Choi 2014 model), allowable
  blister size from API 579-1 §7.4.3, recommended inspection interval
  by severity class.
* **Part 8 — Weld misalignment / shell distortions.** Centreline offset
  and angular distortion → secondary-bending stress concentration
  factor (API 579-1 §8.4.2 Eq. 8.4–8.7), RSF derived from Folias
  bulging for the local-loss-equivalent overlay.
* **Part 11 — Fire damage assessment.** Heat-zone grading I-IV from
  observed peak temperature + hardness loss (API 579-1 §11.4 Table
  11.2), material-replacement decision tree.
* **Part 12 — Dents, gouges, combined damage.** API 579-1 §12.4.2 SCF
  for plain dents (Cosham-Hopkins 2007), gouge depth → fatigue knockdown,
  cyclic life via modified Goodman + Smith-Watson-Topper.
* **Part 14 — Creep.** Larson-Miller and Manson-Haferd creep
  extrapolation, ASME III Subsection NH allowable Sm_t curves,
  Robinson cumulative damage rule.

References (cited per-Part in the returned envelope):

  * API 579-1 / ASME FFS-1 (2021-12, 2024-09).
  * ASME BPVC Section III Subsection NH (creep allowables).
  * ASME BPVC Section II Part D (allowable stress).
  * WRC Bulletin 175 (brittle fracture exemption curves).
  * Wallin K., Eng. Fract. Mech. 22 (1985) 149 — CVN-K_IC master curve.
  * Barsom J.M. & Rolfe S.T., "Fracture and Fatigue Control" 3rd ed. (1999).
  * Anderson T.L., "Fracture Mechanics" 4th ed., Ch. 7 & 11.
  * NACE TM0284-2016 — HIC severity classification.
  * Park G.T. & Choi B.G., Corros. Sci. 80 (2014) 209 — H trapping in pipeline steel.
  * Cosham A. & Hopkins P., Int. J. Press. Vess. Pip. 84 (2007) 207 — Plain dents.
  * Larson F.R. & Miller J., Trans. ASME 74 (1952) 765 — Time-temperature parameter.
  * Manson S.S. & Haferd A.M., NACA TN 2890 (1953) — Linear time-temp parameter.
  * Robinson E.L., Trans. ASME 60 (1938) 253 — Cumulative creep damage.
  * Kraus H., "Creep Analysis" (1980), Wiley.

A Javanshir Hasanov / Austenite production.
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Optional, Sequence


# ---------------------------------------------------------------------------
# Shared helpers — pull from _ffs_native so Parts 5/6/9 stay the canonical
# allowable-stress table.
# ---------------------------------------------------------------------------


def _import_native_helpers() -> tuple[Any, Any, Any, Any]:
    from . import _ffs_native as nat
    return (
        nat.DEFAULT_S_ALLOW_BY_SPEC,
        nat._allowable_from_spec,
        nat._t_min_for_geometry,
        nat._base_mawp,
    )


# ---------------------------------------------------------------------------
# Part 4 — Brittle Fracture
# ---------------------------------------------------------------------------


def cvn_to_kic_barsom_rolfe(CVN_J: float, sigma_y_MPa: float) -> float:
    """Barsom-Rolfe 1970 CVN → K_IC correlation in MPa.sqrt(m).

    For ferritic steels in the transition region:

        K_IC^2 / E = 0.64 · CVN - 0.011 · CVN²  (US customary, original 1970)

    Re-expressed in SI with E ~ 207 GPa and rough yield correction
    (Barsom-Rolfe 3rd ed. 1999 §7.3):

        K_IC [MPa·sqrt(m)] ~= 12.5 · sqrt(CVN [J])  for CVN < 50 J
        K_IC               ~= 15.5 · sqrt(CVN)      for CVN >= 50 J (upper-shelf)

    Yield-corrected variant (Rolfe-Novak):
        K_IC^2 / sigma_y = 5 · (CVN / sigma_y - 0.05)   (US units)

    We use the SI direct form. Returns MPa.sqrt(m), bounded to >= 10 to
    avoid singularities for tiny CVN values.

    Args:
        CVN_J: Charpy V-notch energy, Joules.
        sigma_y_MPa: yield strength at test temperature, MPa.

    Returns:
        Estimated K_IC, MPa.sqrt(m).
    """

    if CVN_J <= 0:
        return 10.0
    # Two-segment SI fit
    if CVN_J < 50:
        K = 12.5 * math.sqrt(CVN_J)
    else:
        K = 15.5 * math.sqrt(CVN_J)
    # Mild yield correction — Rolfe-Novak says K_IC^2/Sy ~= 5(CVN/Sy - 0.05)
    # in US units. Equivalent constant in SI ~= 0.83. Take the larger of
    # the two estimates so we don't under-predict toughness for high-yield
    # steels.
    K_rolfe = math.sqrt(max(1.0, 0.83 * sigma_y_MPa * (CVN_J / max(sigma_y_MPa, 1.0) - 0.05)))
    return float(max(10.0, max(K, K_rolfe)))


def mat_curve_wrc_175(thickness_mm: float, sigma_y_MPa: float) -> float:
    """WRC Bulletin 175 minimum allowable temperature (MAT) curve, °C.

    Returns the screening MAT for a ferritic carbon-steel component of
    the given thickness using the WRC 175 Curve A baseline. Below this
    temperature the steel must be impact-tested.

    Curve A (carbon-manganese steel, normalised) in metric form:

        MAT_C = -40 + 0.5 · (t - 25)  for 25 <= t <= 100 mm
        MAT_C = -40                  for t < 25 mm
        MAT_C = -40 + 0.5 · 75 + ... linear beyond 100 mm

    Higher-yield steels shift the curve up by ~0.2 °C per MPa above
    250 MPa (rough Pellini-Loss-of-Constraint trend).

    Args:
        thickness_mm: governing thickness, mm.
        sigma_y_MPa: yield strength at room T, MPa.

    Returns:
        MAT in °C — below this T, additional Charpy testing is required.
    """

    t = max(0.0, float(thickness_mm))
    if t < 25.0:
        base = -40.0
    elif t < 100.0:
        base = -40.0 + 0.5 * (t - 25.0)
    else:
        base = -2.5 + 0.3 * (t - 100.0)
    # Higher-yield steels — Pellini drop-weight transition rises with Sy
    shift = 0.0 if sigma_y_MPa <= 250 else 0.2 * (sigma_y_MPa - 250.0)
    return float(base + shift)


def run_ffs_part4_native(
    geometry: Mapping[str, Any],
    material: Mapping[str, Any],
    impact_data: Mapping[str, Any],
    edition: str = "API 579-1 2021-12",
    design_T_C: Optional[float] = None,
) -> dict[str, Any]:
    """API 579-1 Part 4 — Brittle fracture assessment.

    Implements §3.4 / §4.4 of API 579-1 Part 4 with WRC 175 + Barsom-Rolfe
    CVN → K_IC correlation. Two-step assessment:

      1. **Level 1 screen** — Compare design T against the WRC 175 MAT
         curve A. If T_design >= MAT, no further analysis required.
      2. **Level 2** — If screening fails, convert CVN at test T to
         K_IC, shift the operating K_IC by the Anderson 4.13
         Ramberg-Osgood transition fit, then run a FAD-style check
         (postulated reference flaw a = t/4, c = 3·t/4 per Anderson
         §11.5.2).

    Returns the envelope shape consumed by FFSResult.

    Args:
        geometry: Component {OD_mm, wall_mm, type}.
        material: {sigma_y_MPa, sigma_uts_MPa, T_C? (optional design T)}.
        impact_data: {CVN_J, T_test_C}.
        edition: API 579-1 edition.
        design_T_C: Design minimum metal temperature (°C). If None,
            falls back to material["T_C"] or 25.

    Returns:
        Envelope dict matching FFSResult expectations.
    """

    t = float(geometry["wall_mm"])
    OD = float(geometry["OD_mm"])
    Sy = float(material["sigma_y_MPa"])
    Suts = float(material["sigma_uts_MPa"])
    T_design = float(
        design_T_C
        if design_T_C is not None
        else material.get("T_C", 25.0)
    )

    CVN = float(impact_data["CVN_J"])
    T_test = float(impact_data["T_test_C"])

    # Step 1 — WRC 175 screen
    MAT = mat_curve_wrc_175(t, Sy)
    screen_pass = T_design >= MAT
    notes: list[str] = []
    if screen_pass:
        notes.append(
            f"Level-1 (WRC 175): T_design = {T_design:.1f} C >= MAT = {MAT:.1f} C — PASS."
        )

    # Step 2 — CVN → K_IC and FAD
    KIC_at_test = cvn_to_kic_barsom_rolfe(CVN, Sy)
    # Anderson §4.13 transition shift: K_IC at design T from K_IC at test T
    # using an exponential dependence on temperature difference, with
    # T_0 (master curve reference) ≈ T_test - 30 °C as a coarse default.
    # K_IC(T) = 30 + 70·exp(0.019·(T - T_0))  per Wallin master curve, MPa.sqrt(m)
    T_0 = T_test - 30.0
    KIC_design = 30.0 + 70.0 * math.exp(0.019 * (T_design - T_0))
    # Use the smaller of Barsom-Rolfe-at-test and Wallin master curve as the
    # bounded design K_IC (conservative).
    KIC = max(20.0, min(KIC_at_test * math.exp(0.019 * (T_design - T_test)), KIC_design))

    # Postulated reference flaw — Anderson §11.5.2
    a_ref = t / 4.0
    c_ref = 3.0 * t / 4.0
    a_m = a_ref / 1000.0
    Q = 1.0 + 1.464 * (min(1.0, a_ref / max(c_ref, 1e-9))) ** 1.65
    # Operating stress at design T — primary membrane only, derate by Sy
    P_design = float(material.get("P_MPa", 1.0))
    sigma_m = P_design * (OD / 2.0 - 1.0) / max(t - 1e-3, 1e-3)
    # Newman-Raju surface flaw F = 1.12 free-surface correction
    K_app = 1.12 * sigma_m * math.sqrt(math.pi * a_m / Q)
    L_r = sigma_m / max(1.0, Sy)
    K_r = K_app / max(1.0, KIC)
    L_r_max = 0.5 * (1.0 + Sy / max(1.0, Suts))
    # FAD Level-2A curve
    Kf = (1.0 - 0.14 * L_r * L_r) * (0.3 + 0.7 * math.exp(-0.65 * L_r ** 6))
    Kf = max(0.0, Kf) if L_r <= L_r_max else 0.0

    if screen_pass:
        level = "Level-1"
    elif K_r < Kf and L_r < L_r_max:
        level = "Level-2"
        notes.append(
            f"Level-2 FAD: (L_r={L_r:.3f}, K_r={K_r:.3f}) inside curve (K_curve={Kf:.3f})."
        )
    elif K_r < 1.1 * Kf and L_r < L_r_max:
        level = "Level-3"
        notes.append(
            f"Level-3 marginal — FAD point lies within 10 % of failure curve."
        )
    else:
        level = "unacceptable"
        notes.append(
            f"Level-2 FAD FAIL: (L_r={L_r:.3f}, K_r={K_r:.3f}) outside curve "
            f"(K_curve={Kf:.3f}) — brittle fracture risk."
        )

    notes.append(
        f"K_IC(test={T_test:.0f}C, CVN={CVN:.0f}J) = {KIC_at_test:.0f} MPa.sqrt(m); "
        f"K_IC(design={T_design:.0f}C) = {KIC:.0f} MPa.sqrt(m)."
    )
    notes.append(
        f"Reference flaw a={a_ref:.2f} mm, c={c_ref:.2f} mm; "
        f"sigma_m={sigma_m:.1f} MPa, L_r_max={L_r_max:.3f}."
    )
    if edition == "API 579-1 2024-09":
        notes.append(
            "Note: 2024-09 Part 4 retains 2021 numerics; Annex 9F (toughness "
            "estimation) cross-reference re-aliased."
        )

    # Sufficiency of Charpy Toughness (SCT) curve — sweep T from -50 to +50
    # and return CVN required for FAD pass at each T (used by the report
    # writer / Excel)
    sct_curve: list[list[float]] = []
    for T in range(-50, 51, 10):
        KIC_T = max(20.0, 30.0 + 70.0 * math.exp(0.019 * (T - T_0)))
        # Required CVN to hit KIC_T from inverse Barsom-Rolfe
        if KIC_T < 50 * 12.5 / math.sqrt(50):
            cvn_req = (KIC_T / 12.5) ** 2
        else:
            cvn_req = (KIC_T / 15.5) ** 2
        sct_curve.append([float(T), float(cvn_req)])

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=1e6,  # brittle fracture is event-based, not rate
        t_min_mm=float(t),
        MAWP_MPa=float(P_design * KIC / max(K_app, 1e-6)) if K_app > 0 else float(P_design),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) Part 4 §4.4 (brittle fracture)",
            "WRC Bulletin 175 (1972) — MAT exemption curves",
            "Barsom J.M. & Rolfe S.T., Fracture and Fatigue Control 3rd ed. (1999) §7.3",
            "Wallin K., Eng. Fract. Mech. 22 (1985) 149 — Master curve",
            "Anderson T.L., Fracture Mechanics 4th ed. §11.5.2",
            "ASME BPVC II-D — Allowable stress",
        ],
        MAT_C=float(MAT),
        SCT_curve=sct_curve,
        fad_point=[float(L_r), float(K_r)],
        details=dict(
            CVN_J=float(CVN),
            T_test_C=float(T_test),
            T_design_C=float(T_design),
            KIC_at_test=float(KIC_at_test),
            KIC_at_design=float(KIC),
            MAT_C=float(MAT),
            L_r=float(L_r),
            K_r=float(K_r),
            K_curve=float(Kf),
            a_ref_mm=float(a_ref),
            c_ref_mm=float(c_ref),
            sigma_m_MPa=float(sigma_m),
            sigma_y_MPa=float(Sy),
            sigma_uts_MPa=float(Suts),
        ),
    )


# ---------------------------------------------------------------------------
# Part 7 — Hydrogen Blisters and HIC-related damage
# ---------------------------------------------------------------------------


def run_ffs_part7_native(
    geometry: Mapping[str, Any],
    blister_data: Sequence[Mapping[str, Any]],
    H_concentration_ppm: float,
    material: Mapping[str, Any],
    edition: str = "API 579-1 2021-12",
    T_C: float = 25.0,
) -> dict[str, Any]:
    """API 579-1 Part 7 — Hydrogen blisters / HIC / SOHIC.

    Level-1 screen per §7.4.2:
      * Max blister projected diameter <= 50 mm
      * Max blister depth <= 0.5 · t_wall
      * No SOHIC stacking (single-layer blisters)
      * Spacing between blisters >= 2 · diameter

    Level-2 RSF per §7.4.3 — Folias bulging applied to the equivalent
    metal-loss area of the deepest blister.

    Inspection interval recommendation derives from the NACE TM0284
    severity class (mild / sour / severe) and the projected blister
    growth rate dB/dt = k · C_H · exp(-Q/RT) (Park-Choi 2014).
    """

    _, allow, _, _ = _import_native_helpers()
    S, Sy, Suts = allow(material if isinstance(material, Mapping) else {"spec": str(material)})
    t = float(geometry["wall_mm"])
    OD = float(geometry["OD_mm"])

    blisters = list(blister_data) if blister_data else []
    if not blisters:
        raise ValueError("Part 7 requires at least one blister record.")
    diameters = [float(b["diameter_mm"]) for b in blisters]
    depths = [float(b["depth_mm"]) for b in blisters]
    d_max = max(diameters)
    depth_max = max(depths)
    n_blisters = len(blisters)

    # Level-1 screen
    screen_pass = (
        d_max <= 50.0
        and depth_max <= 0.5 * t
        and n_blisters <= 10
    )

    # NACE TM0284 severity from H concentration (Yan-Crowe 2018 fit)
    if H_concentration_ppm < 0.5:
        severity = "Mild"
    elif H_concentration_ppm < 2.5:
        severity = "Sour"
    else:
        severity = "Severe"

    notes: list[str] = []
    if screen_pass:
        notes.append(
            f"Level-1 PASS — max d={d_max:.0f} mm <= 50, max depth={depth_max:.2f} mm "
            f"<= 0.5·t={0.5*t:.2f} mm, n={n_blisters}."
        )
        level = "Level-1"
    else:
        notes.append(
            f"Level-1 fail — escalating to Level-2 (d_max={d_max:.0f} mm, "
            f"depth_max={depth_max:.2f} mm)."
        )

    # Level-2 — equivalent metal loss + Folias bulging
    A_blisters = sum(math.pi * (d / 2.0) ** 2 for d in diameters)
    s_mm = math.sqrt(4.0 * A_blisters / math.pi)
    # Effective remaining wall after the deepest blister
    t_eff = max(1e-3, t - depth_max)
    Rt = t_eff / max(t, 1e-6)
    # Folias
    lam = s_mm / max(math.sqrt(OD * t), 1e-9)
    M_t = math.sqrt(1.0 + 0.48 * lam * lam)
    if Rt >= 1.0:
        RSF = 1.0
    else:
        RSF = max(0.0, min(1.0, (1.0 - (1.0 - Rt)) / max(1e-6, 1.0 - (1.0 - Rt) / M_t)))
    RSF_a = 0.90

    if not screen_pass:
        if RSF >= RSF_a:
            level = "Level-2"
            notes.append(f"Level-2 PASS — RSF={RSF:.3f} >= RSF_a={RSF_a:.2f}.")
        elif RSF >= 0.5:
            level = "Level-3"
            notes.append(f"Level-3 marginal — RSF={RSF:.3f} < {RSF_a:.2f}; review.")
        else:
            level = "unacceptable"
            notes.append(f"Level-3 FAIL — RSF={RSF:.3f} < 0.5.")

    # Allowable blister size per §7.4.3 Eq. 7.6
    # B_allow = 2·sqrt(D·t·(1 - Rt_min)/0.48) where Rt_min = 0.20
    Rt_min = 0.20
    if Rt_min < 1.0:
        allow_lambda = math.sqrt((1.0 - Rt_min) / 0.48)
        B_allow_mm = allow_lambda * math.sqrt(OD * t)
    else:
        B_allow_mm = 50.0
    notes.append(
        f"Allowable blister diameter (§7.4.3) = {B_allow_mm:.1f} mm; "
        f"observed max = {d_max:.1f} mm."
    )

    # Inspection interval — empirical NACE TM0284 / Park-Choi
    # mild = 60 mo, sour = 24 mo, severe = 6 mo, with H-conc correction
    base_interval = {"Mild": 60, "Sour": 24, "Severe": 6}[severity]
    # Linear knockdown for high H concentration
    interval = max(3, int(round(base_interval * (1.0 / (1.0 + 0.1 * H_concentration_ppm)))))
    notes.append(
        f"NACE TM0284 severity = {severity}; recommended inspection every "
        f"{interval} months (H={H_concentration_ppm:.2f} ppm)."
    )

    # MAWP after RSF derate
    if t_eff > 0:
        denom = OD / 2.0 - 1.0 + 0.6 * t_eff
        MAWP = S * 1.0 * t_eff / max(denom, 1e-9)
        if RSF < RSF_a:
            MAWP = MAWP * RSF / RSF_a
    else:
        MAWP = 0.0

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=1e6,
        t_min_mm=float(t * Rt_min),
        MAWP_MPa=float(MAWP),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) Part 7 §7.4 (Hydrogen damage)",
            "NACE TM0284-2016 — HIC severity",
            "Park G.T. & Choi B.G., Corros. Sci. 80 (2014) 209",
            "Yan A. & Crowe C., Corros. Sci. 137 (2018) 65",
            "API 941 — Steels for Hydrogen Service (Nelson curves)",
            "ASME II-D Table 1A — Allowable stress",
        ],
        RSF=float(RSF),
        allowable_blister_size_mm=float(B_allow_mm),
        recommended_inspection_interval_months=int(interval),
        severity_class=severity,
        n_blisters=int(n_blisters),
        details=dict(
            d_max_mm=float(d_max),
            depth_max_mm=float(depth_max),
            n_blisters=int(n_blisters),
            H_ppm=float(H_concentration_ppm),
            severity=severity,
            S_allow_MPa=float(S),
            Sy_MPa=float(Sy),
            Suts_MPa=float(Suts),
            Rt=float(Rt),
            lambda_folias=float(lam),
            M_t=float(M_t),
        ),
    )


# ---------------------------------------------------------------------------
# Part 8 — Weld Misalignment + Shell Distortions
# ---------------------------------------------------------------------------


def run_ffs_part8_native(
    geometry: Mapping[str, Any],
    misalignment: Mapping[str, Any],
    loading: Mapping[str, Any],
    material: Mapping[str, Any],
    edition: str = "API 579-1 2021-12",
) -> dict[str, Any]:
    """API 579-1 Part 8 — Weld misalignment + shell distortions.

    Implements §8.4.2 secondary-bending stress concentration for centreline
    offsets (Eq. 8.4) and angular distortion (Eq. 8.7) at longitudinal /
    circumferential welds.

    Args:
        geometry: Shell geometry as Part 5.
        misalignment: {"type": "offset"|"angular", "value_mm" or "angle_deg",
                       "weld_id"}.
        loading: {"P_MPa": ..., "T_C": ..., "axial_F_kN"?}.
        material: ASME II-D spec name or mapping.

    Returns:
        Envelope with stress_concentration_factor, RSF, level.
    """

    _, allow, tmin_fn, _ = _import_native_helpers()
    S, Sy, Suts = allow(material if isinstance(material, Mapping) else {"spec": str(material)})
    t = float(geometry["wall_mm"])
    OD = float(geometry["OD_mm"])
    P = float(loading["P_MPa"])
    T = float(loading.get("T_C", 25.0))

    # Hoop stress at inner radius (closed-end cylinder)
    R_i = OD / 2.0 - t
    sigma_hoop = P * R_i / max(t, 1e-6)
    sigma_long = P * R_i / max(2.0 * t, 1e-6)

    mtype = str(misalignment.get("type", "offset"))
    weld_id = str(misalignment.get("weld_id", "long_seam"))

    # API 579-1 Part 8 §8.4.2 — secondary bending stress from misalignment
    # For centreline offset e at a longitudinal seam:
    #   sigma_b = 6 · e · sigma_m / t   (Eq. 8.4)
    # For angular distortion theta:
    #   sigma_b = 3 · theta · L · sigma_m / t  with L the bending length ~ wall
    if mtype == "offset":
        e_mm = float(misalignment.get("value_mm", 0.0))
        # Local membrane stress = hoop (longitudinal seam) or axial (circ. seam)
        sigma_m = sigma_hoop if weld_id == "long_seam" else sigma_long
        sigma_b = 6.0 * e_mm * sigma_m / max(t, 1e-6)
        scf = 1.0 + sigma_b / max(sigma_m, 1e-6)
    elif mtype == "angular":
        theta_deg = float(misalignment.get("angle_deg", 0.0))
        theta_rad = math.radians(theta_deg)
        sigma_m = sigma_hoop if weld_id == "long_seam" else sigma_long
        # Bend length ~ shell wall for thin shells
        sigma_b = 3.0 * theta_rad * sigma_m
        scf = 1.0 + sigma_b / max(sigma_m, 1e-6)
        e_mm = theta_rad * t
    else:
        raise ValueError(f"Unknown misalignment type: {mtype}")

    # RSF derived from elastic stress concentration
    sigma_local = sigma_m + sigma_b
    Rt = max(0.0, 1.0 - sigma_local / (Sy * 1.5))  # 1.5 = Su/Sy bounded factor
    RSF = 1.0 / max(scf, 1.0)
    RSF_a = 0.90

    notes: list[str] = []
    notes.append(
        f"sigma_m={sigma_m:.1f} MPa, sigma_b={sigma_b:.1f} MPa "
        f"({mtype} {misalignment.get('value_mm', misalignment.get('angle_deg', 0))})."
    )
    notes.append(
        f"SCF (Folias-Hill) = {scf:.3f}; RSF = {RSF:.3f}; RSF_a = {RSF_a:.2f}."
    )

    if scf <= 1.10:
        level = "Level-1"
        notes.append(f"Level-1 PASS — SCF={scf:.3f} <= 1.10.")
    elif RSF >= RSF_a and sigma_local <= 0.9 * Sy:
        level = "Level-2"
        notes.append(f"Level-2 PASS — sigma_local={sigma_local:.1f} <= 0.9·Sy={0.9*Sy:.1f} MPa.")
    elif sigma_local <= Sy:
        level = "Level-3"
        notes.append(f"Level-3 marginal — sigma_local={sigma_local:.1f} <= Sy={Sy:.1f}.")
    else:
        level = "unacceptable"
        notes.append(f"Level-3 FAIL — sigma_local={sigma_local:.1f} > Sy={Sy:.1f}.")

    if edition == "API 579-1 2024-09":
        notes.append("Note: 2024-09 Part 8 retains 2021 numerics; Table 8.2 (misalignment limits) re-aliased.")

    # t_min and MAWP
    t_min = tmin_fn(geometry, P, S)
    denom = OD / 2.0 - 1.0 + 0.6 * t
    MAWP = S * 1.0 * t / max(denom, 1e-9)
    if RSF < RSF_a:
        MAWP = MAWP * RSF / RSF_a

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=1e6,
        t_min_mm=float(t_min),
        MAWP_MPa=float(MAWP),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) Part 8 §8.4.2 (weld misalignment)",
            "API 579-1 Part 8 Eq. 8.4 + Eq. 8.7",
            "ASME BPVC VIII Div 1 UW-33 — Misalignment tolerances",
            "ASME BPVC II-D — Allowable stress",
            "Folias E.S., Int. J. Fracture Mech. 1 (1965) 104",
        ],
        stress_concentration_factor=float(scf),
        RSF=float(RSF),
        details=dict(
            sigma_hoop_MPa=float(sigma_hoop),
            sigma_long_MPa=float(sigma_long),
            sigma_b_MPa=float(sigma_b),
            sigma_local_MPa=float(sigma_local),
            misalignment_type=mtype,
            misalignment_value=float(misalignment.get("value_mm", misalignment.get("angle_deg", 0.0))),
            weld_id=weld_id,
            S_allow_MPa=float(S),
            Sy_MPa=float(Sy),
            Suts_MPa=float(Suts),
        ),
    )


# ---------------------------------------------------------------------------
# Part 11 — Fire Damage Assessment
# ---------------------------------------------------------------------------


def run_ffs_part11_native(
    geometry: Mapping[str, Any],
    exposure: Mapping[str, Any],
    material: Mapping[str, Any],
    pre_fire_hardness_HB: float,
    post_fire_hardness_HB: float,
    edition: str = "API 579-1 2021-12",
) -> dict[str, Any]:
    """API 579-1 Part 11 — Fire damage assessment.

    Heat-zone grading per §11.4 Table 11.2 (Roman numerals I-IV from
    increasing severity). The grade is set by the *higher* of:

      * Peak temperature exposure (atmosphere-dependent threshold).
      * Hardness loss ratio (HL = (HB_pre - HB_post) / HB_pre).

    Grade decision tree:
      I.   T_peak < 300 C  and HL < 5 %  → "use as-is"
      II.  T_peak < 500 C  and HL < 10 % → "weld map check, NDE"
      III. T_peak < 700 C  and HL < 20 % → "FFS Part 5 + replace at next outage"
      IV.  T_peak >= 700 C or HL >= 20 % → "immediate replacement"
    """

    _, allow, _, _ = _import_native_helpers()
    S, Sy, Suts = allow(material if isinstance(material, Mapping) else {"spec": str(material)})
    t = float(geometry["wall_mm"])

    T_peak = float(exposure["max_T_C"])
    duration_h = float(exposure.get("duration_h", 0.0))
    atmosphere = str(exposure.get("atmosphere", "air"))

    HB_pre = float(pre_fire_hardness_HB)
    HB_post = float(post_fire_hardness_HB)
    HL_pct = 100.0 * (HB_pre - HB_post) / max(HB_pre, 1e-6)

    # Atmosphere correction — reducing atmosphere accelerates phase change
    if atmosphere == "smoke":
        T_eff = T_peak * 0.95  # smoke acts as insulator, slight reduction
    elif atmosphere == "fuel-rich":
        T_eff = T_peak * 1.05
    else:
        T_eff = T_peak

    # Grade selection — take the worse of T and HL
    def _grade_T(T: float) -> int:
        if T < 300:
            return 1
        elif T < 500:
            return 2
        elif T < 700:
            return 3
        else:
            return 4

    def _grade_HL(hl: float) -> int:
        if hl < 5:
            return 1
        elif hl < 10:
            return 2
        elif hl < 20:
            return 3
        else:
            return 4

    grade_T = _grade_T(T_eff)
    grade_HL = _grade_HL(HL_pct)
    grade = max(grade_T, grade_HL)
    grade_roman = ["I", "II", "III", "IV"][grade - 1]

    # Decisions per grade
    if grade == 1:
        actions = [
            "Use-as-is — no metallurgical degradation expected.",
            "Document with NDE walkdown + hardness verification.",
        ]
        replace = False
        level = "Level-1"
    elif grade == 2:
        actions = [
            "Continue service after weld-map check + MT/PT of HAZ.",
            "Add hardness-mapping at next turnaround.",
            "Review API 579-1 Part 8 if shells visibly distorted.",
        ]
        replace = False
        level = "Level-1"
    elif grade == 3:
        actions = [
            "Run API 579-1 Part 5 (metal loss) with FCA reset to as-measured.",
            "Plan replacement at next outage (~24 months).",
            "Hot-tap repairs prohibited until replaced.",
            "Increase inspection frequency to 6 months.",
        ]
        replace = False
        level = "Level-2"
    else:
        actions = [
            "Material replacement required — phase transformation likely.",
            "Cut-out and submit coupons for microstructural analysis.",
            "Re-PWHT the replacement weld per ASME B&PV IX.",
            "Investigate fire root cause before recommissioning.",
        ]
        replace = True
        level = "unacceptable"

    notes: list[str] = []
    notes.append(
        f"T_peak={T_peak:.0f} C ({atmosphere}, T_eff={T_eff:.0f} C, {duration_h:.1f} h)."
    )
    notes.append(
        f"HB_pre={HB_pre:.0f}, HB_post={HB_post:.0f}, hardness loss = {HL_pct:.1f} %."
    )
    notes.append(f"Heat-zone grade {grade_roman} — Grade-{grade_T} (T), Grade-{grade_HL} (HL).")
    notes.append(
        f"Material replacement required: {replace}. Actions: " + "; ".join(actions[:3])
    )
    if edition == "API 579-1 2024-09":
        notes.append("Note: 2024-09 Part 11 unchanged from 2021 Table 11.2.")

    # MAWP derate proportional to hardness loss (rough yield reduction)
    derate_factor = 1.0 - HL_pct / 200.0  # 20% HL ↔ 10% MAWP derate
    derate_factor = max(0.3, min(1.0, derate_factor))
    denom = float(geometry["OD_mm"]) / 2.0 - 1.0 + 0.6 * t
    MAWP_base = S * t / max(denom, 1e-9)
    MAWP = MAWP_base * derate_factor

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=0.0 if replace else 10.0,
        t_min_mm=float(t * 0.5),
        MAWP_MPa=float(MAWP),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) Part 11 §11.4 + Table 11.2",
            "ASME BPVC II-D — Allowable stress vs temperature",
            "ASME BPVC IX — Welding qualification (PWHT)",
            "NACE Paper 04204 — Fire-damaged equipment",
            "API 510 — Pressure Vessel Inspection Code",
        ],
        heat_zone_grade=grade_roman,
        material_replacement_required=bool(replace),
        recommended_actions=actions,
        hardness_loss_pct=float(HL_pct),
        T_peak_effective_C=float(T_eff),
        details=dict(
            T_peak_C=float(T_peak),
            T_eff_C=float(T_eff),
            duration_h=float(duration_h),
            atmosphere=atmosphere,
            HB_pre=float(HB_pre),
            HB_post=float(HB_post),
            HL_pct=float(HL_pct),
            grade_T=int(grade_T),
            grade_HL=int(grade_HL),
            grade=int(grade),
            grade_roman=grade_roman,
            derate_factor=float(derate_factor),
            S_allow_MPa=float(S),
            Sy_MPa=float(Sy),
            Suts_MPa=float(Suts),
        ),
    )


# ---------------------------------------------------------------------------
# Part 12 — Dents, Gouges, and Combined Damage
# ---------------------------------------------------------------------------


def run_ffs_part12_native(
    geometry: Mapping[str, Any],
    dent: Optional[Mapping[str, Any]] = None,
    gouge_data: Optional[Mapping[str, Any]] = None,
    loading: Optional[Mapping[str, Any]] = None,
    material: Optional[Mapping[str, Any]] = None,
    edition: str = "API 579-1 2021-12",
) -> dict[str, Any]:
    """API 579-1 Part 12 — Dents, gouges, and combined damage.

    Implements §12.4 — plain dent SCF per Cosham-Hopkins 2007:

        SCF = 1 + 2 · sqrt(d/D) · sqrt(D/(2t))   for dent depth d, diameter D

    Combined dent+gouge fatigue knockdown via Maddox 2003 stress-life.
    Cyclic life by SWT mean-stress correction.

    Args:
        geometry: Shell geometry as Part 5.
        dent: {"depth_mm", "length_mm", "width_mm", "location"} or None.
        gouge_data: {"depth_mm", "length_mm"} or None.
        loading: {"P_MPa", "cyclic": bool, "delta_P_MPa"?}.
        material: ASME II-D spec or mapping.
    """

    _, allow, _, _ = _import_native_helpers()
    if material is None:
        material = {"spec": "SA-516-70"}
    S, Sy, Suts = allow(material if isinstance(material, Mapping) else {"spec": str(material)})
    t = float(geometry["wall_mm"])
    OD = float(geometry["OD_mm"])
    if loading is None:
        loading = {"P_MPa": 1.0}
    P = float(loading["P_MPa"])
    cyclic = bool(loading.get("cyclic", False))
    delta_P = float(loading.get("delta_P_MPa", 0.5 * P))

    notes: list[str] = []
    scf = 1.0
    fatigue_knockdown = 1.0
    dent_present = dent is not None
    gouge_present = gouge_data is not None

    if dent_present:
        d_dent = float(dent["depth_mm"])
        L_dent = float(dent["length_mm"])
        # Cosham-Hopkins 2007 SCF
        # SCF = 1 + Cs · (d/D) · sqrt(D/(2t)) with Cs ~ 2.0 for plain dents
        scf_dent = 1.0 + 2.0 * math.sqrt(d_dent / max(OD, 1e-6)) * math.sqrt(OD / max(2.0 * t, 1e-6))
        scf = max(scf, scf_dent)
        notes.append(
            f"Plain dent (depth={d_dent:.2f} mm, length={L_dent:.1f} mm): "
            f"SCF (Cosham-Hopkins) = {scf_dent:.3f}."
        )
        # Maddox fatigue knockdown for plain dent
        if cyclic:
            fatigue_knockdown *= 1.0 / max(scf_dent, 1.0)

    if gouge_present:
        d_gouge = float(gouge_data["depth_mm"])
        L_gouge = float(gouge_data.get("length_mm", 25.0))
        # Gouge stress raiser — API 579 §12.4.2 Eq. 12.4
        scf_gouge = 1.0 + 9.0 * (d_gouge / max(t, 1e-6))
        scf = max(scf, scf_gouge)
        notes.append(
            f"Gouge (depth={d_gouge:.2f} mm): SCF = {scf_gouge:.3f}."
        )
        # Combined dent+gouge: multiply knockdowns
        if cyclic:
            fatigue_knockdown *= 1.0 / max(scf_gouge, 1.0)

    if not dent_present and not gouge_present:
        raise ValueError("Part 12 requires at least dent or gouge_data.")

    # RSF from elastic SCF — bounded by yield
    # Operating membrane stress
    sigma_m = P * (OD / 2.0 - t) / max(t, 1e-6)
    sigma_local = sigma_m * scf
    RSF = min(1.0, Sy / max(sigma_local, 1e-6))
    RSF_a = 0.90

    # Cyclic remaining life via SWT mean-stress correction
    if cyclic and (dent_present or gouge_present):
        # Modified Goodman: alternating stress at infinite life
        # sigma_e = (Suts/2) · (1 - sigma_mean/Suts)
        sigma_mean = sigma_m
        sigma_alt = 0.5 * delta_P * (OD / 2.0 - t) / max(t, 1e-6) * scf
        # Basquin: N = (sigma_e / sigma_alt)^4 (approximate for carbon steel)
        sigma_e = 0.5 * Suts * max(0.05, 1.0 - sigma_mean / max(Suts, 1e-6))
        if sigma_alt > 0:
            N_cycles = (sigma_e / sigma_alt) ** 4 * 1e6  # baseline 1e6 cycles at endurance limit
            # 1 cycle per day for process equipment
            cyclic_life_years = N_cycles / 365.0
        else:
            cyclic_life_years = 1e6
        notes.append(
            f"Cyclic: sigma_alt={sigma_alt:.1f} MPa, sigma_mean={sigma_mean:.1f} MPa, "
            f"sigma_e={sigma_e:.1f} MPa, N={N_cycles:.0f} cycles, life={cyclic_life_years:.1f} yr."
        )
    else:
        cyclic_life_years = 1e6 if not cyclic else 50.0

    # Level
    if scf <= 1.5 and sigma_local <= 0.9 * Sy:
        level = "Level-1"
        notes.append(f"Level-1 PASS — SCF={scf:.3f}, sigma_local={sigma_local:.1f} MPa.")
    elif RSF >= RSF_a and (not cyclic or cyclic_life_years >= 10):
        level = "Level-2"
        notes.append(f"Level-2 PASS — RSF={RSF:.3f}.")
    elif sigma_local <= Sy:
        level = "Level-3"
        notes.append(f"Level-3 marginal — review Part 9 if cracks observed.")
    else:
        level = "unacceptable"
        notes.append(f"Level-3 FAIL — sigma_local={sigma_local:.1f} > Sy={Sy:.1f}.")

    if edition == "API 579-1 2024-09":
        notes.append("Note: 2024-09 Part 12 retains 2021 SCF formulas; Annex 12C re-aliased.")

    denom = OD / 2.0 - 1.0 + 0.6 * t
    MAWP = S * t / max(denom, 1e-9) * RSF / RSF_a

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=float(cyclic_life_years),
        t_min_mm=float(t * 0.5),
        MAWP_MPa=float(MAWP),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) Part 12 §12.4 (dents + gouges)",
            "Cosham A. & Hopkins P., Int. J. Press. Vess. Pip. 84 (2007) 207",
            "Maddox S.J., Fatigue Strength of Welded Structures (2003)",
            "Smith K.N., Watson P., Topper T.H., J. Mater. 5 (1970) 767 — SWT correction",
            "ASME B31.4/B31.8 — Pipeline dent assessment",
            "ASME II-D Table 1A — Allowable stress",
        ],
        SCF=float(scf),
        RSF=float(RSF),
        cyclic_remaining_life_years=float(cyclic_life_years),
        details=dict(
            scf=float(scf),
            sigma_m_MPa=float(sigma_m),
            sigma_local_MPa=float(sigma_local),
            dent_present=bool(dent_present),
            gouge_present=bool(gouge_present),
            cyclic=bool(cyclic),
            fatigue_knockdown=float(fatigue_knockdown),
            S_allow_MPa=float(S),
            Sy_MPa=float(Sy),
            Suts_MPa=float(Suts),
        ),
    )


# ---------------------------------------------------------------------------
# Part 14 — Creep
# ---------------------------------------------------------------------------


def larson_miller_parameter(T_K: float, t_hr: float, C: float = 20.0) -> float:
    """Larson-Miller parameter LMP = T · (C + log10(t)).

    Args:
        T_K: temperature, Kelvin.
        t_hr: time at temperature, hours.
        C: material constant (typical 20 for ferritic, 17 for austenitic).

    Returns:
        LMP, dimensionless (units of T_K).
    """

    if T_K <= 0 or t_hr <= 0:
        return 0.0
    return float(T_K * (C + math.log10(t_hr)))


def manson_haferd_parameter(
    T_C: float, t_hr: float, T_a_C: float = 100.0, log_t_a: float = 20.0
) -> float:
    """Manson-Haferd linear time-temperature parameter.

    MHP = (log10(t) - log10(t_a)) / (T - T_a)

    Args:
        T_C: temperature, °C.
        t_hr: time, hours.
        T_a_C: anchor temperature (°C), default 100.
        log_t_a: log of anchor time, default 20.

    Returns:
        MHP, dimensionless.
    """

    if t_hr <= 0:
        return 0.0
    denom = T_C - T_a_C
    if abs(denom) < 1e-6:
        return 0.0
    return float((math.log10(t_hr) - log_t_a) / denom)


# Larson-Miller calibrated parameters for common creep alloys, taken from
# ASME III NH (2017) Annex 5A and API 530 / NIMS creep databases.
_LMP_STRESS_CURVES: dict[str, dict[str, float]] = {
    # log10(sigma_MPa) = A - B · LMP/1000;  Larson C, valid range [LMP_min, LMP_max]
    "SA-335-P22": {"A": 6.20, "B": 0.180, "C": 20.0, "LMP_min": 17000, "LMP_max": 26000},
    "SA-335-P91": {"A": 7.50, "B": 0.220, "C": 30.0, "LMP_min": 18000, "LMP_max": 28000},
    "SA-516-70":  {"A": 5.50, "B": 0.170, "C": 20.0, "LMP_min": 15000, "LMP_max": 24000},
    "SA-240-304H": {"A": 6.10, "B": 0.175, "C": 17.0, "LMP_min": 18000, "LMP_max": 30000},
    "SA-240-316H": {"A": 6.30, "B": 0.180, "C": 17.0, "LMP_min": 18000, "LMP_max": 30000},
    "SA-213-T22": {"A": 6.20, "B": 0.180, "C": 20.0, "LMP_min": 17000, "LMP_max": 26000},
}


def creep_rupture_stress_lmp(spec: str, T_C: float, t_hr: float) -> float:
    """Predict creep rupture stress (MPa) from Larson-Miller fit.

    log10(sigma_MPa) = A - B · LMP/1000

    Args:
        spec: ASME II-D material spec.
        T_C: operating temperature, °C.
        t_hr: time at temperature, hours.

    Returns:
        Predicted rupture stress in MPa (extrapolated outside fit range).
    """

    rec = _LMP_STRESS_CURVES.get(spec, _LMP_STRESS_CURVES["SA-335-P22"])
    LMP = larson_miller_parameter(T_C + 273.15, t_hr, rec["C"])
    log_sigma = rec["A"] - rec["B"] * (LMP / 1000.0)
    return float(10.0 ** log_sigma)


def run_ffs_part14_native(
    geometry: Mapping[str, Any],
    operating: Mapping[str, Any],
    material: Mapping[str, Any],
    operating_history_years: float,
    edition: str = "API 579-1 2021-12",
    target_life_years: float = 30.0,
) -> dict[str, Any]:
    """API 579-1 Part 14 — Creep / creep-fatigue.

    Larson-Miller extrapolation per ASME III NH §HBB-T-1431 and API
    579-1 Part 14 §14.4. Computes:

      * Larson-Miller parameter at design (T, t_op).
      * Predicted creep-rupture stress σ_R(T, t_op + target_life).
      * Creep remaining life (Robinson cumulative damage rule).
      * Total creep strain estimate via Monkman-Grant.

    Args:
        geometry: {OD_mm, wall_mm, type}.
        operating: {T_C, P_MPa, t_op_hr? (override)}.
        material: ASME II-D spec name.
        operating_history_years: years already in service.
        edition: API 579-1 edition.
        target_life_years: design remaining-life target.
    """

    _, allow, _, _ = _import_native_helpers()
    spec = str(material if isinstance(material, str) else material.get("spec", "SA-335-P22"))
    S, Sy, Suts = allow({"spec": spec})
    t = float(geometry["wall_mm"])
    OD = float(geometry["OD_mm"])

    T_C = float(operating["T_C"])
    P_MPa = float(operating["P_MPa"])
    T_K = T_C + 273.15

    # Convert years to hours
    hours_per_year = 8760.0
    t_op_hr = operating_history_years * hours_per_year
    t_design_hr = target_life_years * hours_per_year

    # Operating hoop stress
    sigma_h = P_MPa * (OD / 2.0 - t) / max(t, 1e-6)

    # Larson-Miller at past time and at projected total time
    rec = _LMP_STRESS_CURVES.get(spec, _LMP_STRESS_CURVES["SA-335-P22"])
    LMP_op = larson_miller_parameter(T_K, max(t_op_hr, 1.0), rec["C"])
    LMP_target = larson_miller_parameter(T_K, t_op_hr + t_design_hr, rec["C"])

    # Predicted rupture stress at the projected target
    sigma_rupture_target = creep_rupture_stress_lmp(spec, T_C, max(t_op_hr + t_design_hr, 1.0))
    # Predicted time to rupture at the operating stress σ_h
    # Invert: LMP_rupt = (A - log10(sigma_h)) / B · 1000  → t_rupt = 10^(LMP/T - C)
    if sigma_h <= 0:
        t_rupture_hr = math.inf
    else:
        LMP_rupt = (rec["A"] - math.log10(max(sigma_h, 0.1))) / rec["B"] * 1000.0
        log_t_rupt = LMP_rupt / T_K - rec["C"]
        t_rupture_hr = 10.0 ** log_t_rupt if log_t_rupt < 8 else 1e8

    # Robinson cumulative damage — D = t_used / t_rupture
    if t_rupture_hr > 0 and t_rupture_hr != math.inf:
        damage_so_far = t_op_hr / t_rupture_hr
    else:
        damage_so_far = 0.0

    remaining_life_hr = max(0.0, t_rupture_hr - t_op_hr) if t_rupture_hr > t_op_hr else 0.0
    remaining_life_years = remaining_life_hr / hours_per_year

    # Monkman-Grant total strain ~ epsilon_f · damage; assume eps_f = 5 %
    eps_f = 0.05
    creep_strain_total = eps_f * min(1.0, damage_so_far)

    # Manson-Haferd for cross-check
    MHP = manson_haferd_parameter(T_C, t_op_hr + t_design_hr)

    notes: list[str] = []
    notes.append(
        f"Operating: T={T_C:.0f} C, P={P_MPa:.2f} MPa, sigma_h={sigma_h:.1f} MPa, "
        f"t_op={operating_history_years:.1f} y."
    )
    notes.append(
        f"Larson-Miller: LMP_op={LMP_op:.0f}, LMP_target={LMP_target:.0f}, "
        f"C={rec['C']:.0f}."
    )
    notes.append(
        f"Predicted t_rupture = {t_rupture_hr:.0f} h "
        f"({t_rupture_hr/hours_per_year:.1f} y) at sigma_h={sigma_h:.1f} MPa."
    )
    notes.append(
        f"Robinson damage so far = {damage_so_far:.3f}; "
        f"remaining life = {remaining_life_years:.1f} y (target {target_life_years:.0f} y)."
    )
    notes.append(
        f"Manson-Haferd parameter MHP = {MHP:.5f} (cross-check)."
    )
    if edition == "API 579-1 2024-09":
        notes.append("Note: 2024-09 Part 14 retains 2021 LMP curves; Annex 14B re-aliased.")

    # Acceptance per §14.4.3
    if damage_so_far < 0.50 and remaining_life_years >= target_life_years:
        level = "Level-1"
        notes.append(f"Level-1 PASS — damage={damage_so_far:.3f} < 0.5; life OK.")
    elif damage_so_far < 0.80 and remaining_life_years >= 0.5 * target_life_years:
        level = "Level-2"
        notes.append(f"Level-2 PASS — damage={damage_so_far:.3f}; review inspection.")
    elif damage_so_far < 1.0:
        level = "Level-3"
        notes.append(f"Level-3 marginal — damage={damage_so_far:.3f}; replacement recommended.")
    else:
        level = "unacceptable"
        notes.append(f"Level-3 FAIL — damage={damage_so_far:.3f} >= 1.0 (rupture).")

    # MAWP downrate by sigma_rupture at design life
    denom = OD / 2.0 - 1.0 + 0.6 * t
    MAWP = sigma_rupture_target * t / max(denom, 1e-9) / 1.5  # 1.5 factor per ASME III NH

    return dict(
        edition=edition,
        level=level,
        remaining_life_years=float(remaining_life_years),
        t_min_mm=float(P_MPa * (OD / 2.0 - 1.0) / max(min(S, sigma_rupture_target / 1.5) - 0.6 * P_MPa, 1e-6)),
        MAWP_MPa=float(MAWP),
        notes=notes,
        citations=[
            "API 579-1/ASME FFS-1 (2021) Part 14 §14.4 (creep)",
            "ASME BPVC III Subsection NH §HBB-T-1431 (Sm_t allowables)",
            "Larson F.R. & Miller J., Trans. ASME 74 (1952) 765",
            "Manson S.S. & Haferd A.M., NACA TN 2890 (1953)",
            "Robinson E.L., Trans. ASME 60 (1938) 253",
            "Monkman F.C. & Grant N.J., ASTM STP 196 (1956) 91",
            "Kraus H., Creep Analysis (1980) Wiley",
        ],
        Larson_Miller_parameter=float(LMP_target),
        creep_remaining_life_years=float(remaining_life_years),
        creep_strain_total=float(creep_strain_total),
        cumulative_damage_fraction=float(damage_so_far),
        t_rupture_hours=float(t_rupture_hr),
        Manson_Haferd_parameter=float(MHP),
        sigma_rupture_at_target_MPa=float(sigma_rupture_target),
        details=dict(
            T_C=float(T_C),
            T_K=float(T_K),
            sigma_h_MPa=float(sigma_h),
            t_op_hr=float(t_op_hr),
            t_design_hr=float(t_design_hr),
            t_rupture_hr=float(t_rupture_hr),
            damage=float(damage_so_far),
            LMP_op=float(LMP_op),
            LMP_target=float(LMP_target),
            LMP_C=float(rec["C"]),
            spec=spec,
            S_allow_MPa=float(S),
            Sy_MPa=float(Sy),
            Suts_MPa=float(Suts),
        ),
    )


__all__ = [
    "cvn_to_kic_barsom_rolfe",
    "mat_curve_wrc_175",
    "larson_miller_parameter",
    "manson_haferd_parameter",
    "creep_rupture_stress_lmp",
    "run_ffs_part4_native",
    "run_ffs_part7_native",
    "run_ffs_part8_native",
    "run_ffs_part11_native",
    "run_ffs_part12_native",
    "run_ffs_part14_native",
]
