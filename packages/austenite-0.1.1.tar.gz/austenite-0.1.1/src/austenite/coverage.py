"""Coverage queries — "Do you support X alloy / Y temperature / Z phase?"

Inspired by an engineersrule.com piece on materials data:

    "engineers who most need accurate material data working with the
     least accurate versions"

A common engineer question we *can't* fail to answer honestly: does this
library cover the alloy / temperature / phase the engineer is about to
trust it with? Saying "probably yes" is worse than admitting a gap.

The :mod:`coverage` module sweeps the bundled data + installed plugins +
the per-system CALPHAD windows and returns a structured report.

Three queries today:

  * :func:`check_alloy`               — full coverage report for an alloy id.
  * :func:`system_temperature_range`  — (T_min, T_max) for a system tag.
  * :func:`list_supported_alloys`     — every alloy id known to the library.

Each returns a small dataclass that serializes cleanly to JSON / Markdown.

References:
  * MMPDS-15 (2020) — coverage matrix for aerospace alloys.
  * ASM Metals Handbook Vol 1-3 — heat-treatment + chemistry coverage.
  * Dinsdale A.T., CALPHAD 15 (1991) 317 — SGTE T-range per element.
  * Sundman B. et al., CALPHAD 9 (1985) 153 — TDB temperature windows.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


__all__ = [
    "CoverageReport",
    "SystemRange",
    "check_alloy",
    "system_temperature_range",
    "list_supported_alloys",
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CoverageReport:
    """Coverage report for a single alloy id.

    Attributes:
        alloy: Canonical alloy id (echoed from the query).
        supported: ``True`` if the alloy appears in the bundled spec table
            OR any installed plugin.
        calphad: ``True`` if a CALPHAD database covers this alloy's
            system family (Fe-Cr / Fe-Cr-Ni / Ni / Al / Ti).
        kinetics: ``True`` if TTT/CCT-style kinetics models are wired.
        mechanical: ``True`` if σ_y / UTS / E are in the alloy table.
        fatigue_curves: Count of S-N rows for this alloy.
        kic_entries: Count of K_IC entries for this alloy.
        gaps: Plain-English list of unsupported aspects (e.g. "No fatigue
            data below -20°C").
        plugin_recommendations: Plugins that would *expand* coverage.
        citation: Primary citation for the supported envelope.
    """

    alloy: str
    supported: bool = False
    calphad: bool = False
    kinetics: bool = False
    mechanical: bool = False
    fatigue_curves: int = 0
    kic_entries: int = 0
    gaps: list[str] = field(default_factory=list)
    plugin_recommendations: list[str] = field(default_factory=list)
    citation: str = ""

    def markdown(self) -> str:
        """Render as a small Markdown table."""

        lines = [f"# Coverage for {self.alloy}", ""]
        rows = [
            ("Supported", self.supported),
            ("CALPHAD", self.calphad),
            ("Kinetics (TTT/CCT)", self.kinetics),
            ("Mechanical (σ_y, UTS, E)", self.mechanical),
            ("Fatigue S-N rows", self.fatigue_curves),
            ("K_IC entries", self.kic_entries),
        ]
        lines.append("| Aspect | Value |")
        lines.append("| --- | --- |")
        for k, v in rows:
            mark = ("yes" if v else "no") if isinstance(v, bool) else str(v)
            lines.append(f"| {k} | {mark} |")
        if self.gaps:
            lines.append("")
            lines.append("**Gaps:**")
            for g in self.gaps:
                lines.append(f"- {g}")
        if self.plugin_recommendations:
            lines.append("")
            lines.append("**Plugins that would expand coverage:**")
            for p in self.plugin_recommendations:
                lines.append(f"- `{p}`")
        if self.citation:
            lines.append("")
            lines.append(f"_Citation: {self.citation}_")
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        return {
            "alloy": self.alloy,
            "supported": self.supported,
            "calphad": self.calphad,
            "kinetics": self.kinetics,
            "mechanical": self.mechanical,
            "fatigue_curves": self.fatigue_curves,
            "kic_entries": self.kic_entries,
            "gaps": list(self.gaps),
            "plugin_recommendations": list(self.plugin_recommendations),
            "citation": self.citation,
        }

    def __repr__(self) -> str:  # pragma: no cover - dev convenience
        return (
            f"<CoverageReport {self.alloy} supported={self.supported} "
            f"S-N={self.fatigue_curves} K_IC={self.kic_entries}>"
        )


@dataclass(frozen=True)
class SystemRange:
    """Temperature range over which a system is CALPHAD-modelled.

    Attributes:
        system: System tag, e.g. ``"Fe-Cr-Ni"``.
        T_min_K: Lower temperature bound (K).
        T_max_K: Upper temperature bound (K).
        notes: Notes about confidence at boundaries.
        citation: Primary CALPHAD assessment reference.
    """

    system: str
    T_min_K: float
    T_max_K: float
    notes: list[str] = field(default_factory=list)
    citation: str = ""

    def __iter__(self):  # type: ignore[no-untyped-def]
        # Allows ``T_lo, T_hi = au.coverage.system_temperature_range(...)``.
        yield self.T_min_K
        yield self.T_max_K


# ---------------------------------------------------------------------------
# Static coverage maps
# ---------------------------------------------------------------------------


# Per-system CALPHAD temperature window from primary literature.
_SYSTEM_RANGES: dict[str, tuple[float, float, str, list[str]]] = {
    "Fe-Cr": (
        273.0, 1873.0,
        "Andersson J.-O., CALPHAD 9 (1985) 187",
        ["σ-phase window 820-1100 K; reduced confidence outside that."],
    ),
    "Fe-Cr-Ni": (
        273.0, 1873.0,
        "Hertzman S. & Sundman B., CALPHAD 6 (1982) 67",
        ["Ni shifts σ window to 870-1180 K", "γ-loop 1180-1670 K"],
    ),
    "Fe-Cr-Mo-C": (
        300.0, 1700.0,
        "Andersson J.-O., CALPHAD 9 (1985) 187 — Fe-Cr-Mo-C",
        ["Reduced confidence below 600 K — extrapolation."],
    ),
    "Ni": (
        300.0, 1728.0,
        "Bratberg J., CALPHAD 20 (1996) 451 — Ni-base γ′",
        ["γ′ window 873-1640 K; melting 1728 K (pure Ni)."],
    ),
    "Ni-Cr-Al-Ti": (
        300.0, 1670.0,
        "Bratberg J., CALPHAD 20 (1996) 451",
        ["γ′ solvus 1100-1400 K for IN718 / IN939."],
    ),
    "Al-Cu": (
        300.0, 933.0,
        "Hu Y. et al., CALPHAD 33 (2009) 535",
        ["θ-phase below 813 K solvus", "Al melting at 933 K (pure)."],
    ),
    "Al-Cu-Mg-Zn": (
        300.0, 933.0,
        "Hu Y. et al., CALPHAD 33 (2009) 535",
        ["7xxx solvus 720-770 K"],
    ),
    "Ti": (
        300.0, 1941.0,
        "Saunders N., CALPHAD 22 (1998) 261 — Ti assessment",
        ["β-transus 1268 K for Ti-6Al-4V"],
    ),
    "Mg-Zn": (
        300.0, 923.0,
        "Liang P. et al., Z.Metallkde. 89 (1998) 536 — Mg-Zn",
        ["Mg melting 923 K"],
    ),
}


# Map alloy family substrings to CALPHAD system tags.
_ALLOY_FAMILY_TO_SYSTEM: tuple[tuple[str, str], ...] = (
    # Iron-base (most specific first)
    ("AISI 41", "Fe-Cr-Mo-C"),
    ("AISI 43", "Fe-Cr-Mo-C"),
    ("SA-516", "Fe-Cr-Ni"),
    ("SA-387", "Fe-Cr-Mo-C"),
    ("S30", "Fe-Cr-Ni"),
    ("S31", "Fe-Cr-Ni"),
    ("S32", "Fe-Cr-Ni"),
    ("304", "Fe-Cr-Ni"),
    ("316", "Fe-Cr-Ni"),
    ("321", "Fe-Cr-Ni"),
    ("347", "Fe-Cr-Ni"),
    ("steel", "Fe-Cr"),
    ("iron", "Fe-Cr"),
    # Nickel-base
    ("Inconel 718", "Ni-Cr-Al-Ti"),
    ("Inconel 625", "Ni-Cr-Al-Ti"),
    ("Inconel 939", "Ni-Cr-Al-Ti"),
    ("Inconel", "Ni-Cr-Al-Ti"),
    ("IN7", "Ni-Cr-Al-Ti"),
    ("IN9", "Ni-Cr-Al-Ti"),
    ("Hastelloy", "Ni"),
    ("Nimonic", "Ni-Cr-Al-Ti"),
    # Titanium / aluminium
    ("Ti-6Al-4V", "Ti"),
    ("Ti-", "Ti"),
    ("titanium", "Ti"),
    ("7075", "Al-Cu-Mg-Zn"),
    ("6061", "Al-Cu"),
    ("Al-", "Al-Cu"),
    ("aluminum", "Al-Cu"),
    ("aluminium", "Al-Cu"),
    # Magnesium
    ("AZ31", "Mg-Zn"),
    ("ZK60", "Mg-Zn"),
)


def _alloy_family(alloy: str) -> Optional[str]:
    """Return the CALPHAD system tag for an alloy id, or None."""

    if not alloy:
        return None
    lowered = alloy.lower()
    for needle, sysid in _ALLOY_FAMILY_TO_SYSTEM:
        if needle.lower() in lowered:
            return sysid
    return None


def _lookup_alloy_record(alloy: str) -> Optional[dict[str, Any]]:
    """Look up a single alloy row in the bundled dataset (None if not found)."""

    try:
        from . import data as _data  # local import to avoid cycles
        return _data.alloy_lookup(alloy)
    except Exception:  # pragma: no cover - defensive
        return None


def _count_fatigue(alloy: str) -> int:
    """Count S-N rows for the alloy in the bundled dataset."""

    try:
        from . import data as _data
        rows = _data.fatigue_curves(alloy=alloy)
    except Exception:  # pragma: no cover - defensive
        return 0
    # rows may be a DataFrame or list[dict]
    try:
        return int(len(rows))
    except TypeError:  # pragma: no cover
        return 0


def _count_kic(alloy: str) -> int:
    """Count K_IC rows for the alloy in the bundled dataset."""

    try:
        from . import data as _data
        rows = _data.kic_database(alloy=alloy)
    except Exception:  # pragma: no cover - defensive
        return 0
    try:
        return int(len(rows))
    except TypeError:  # pragma: no cover
        return 0


def _list_installed_plugins() -> list[str]:
    """Return installed plugin ids (best-effort, never raises)."""

    try:
        from . import plugins as _plugins
        return list(_plugins.list_installed())
    except Exception:  # pragma: no cover - defensive
        return []


# ---------------------------------------------------------------------------
# Public entry points
# ---------------------------------------------------------------------------


def check_alloy(alloy: str) -> CoverageReport:
    """Coverage report for a single alloy id.

    Args:
        alloy: Alloy name / UNS / spec id (case-insensitive substring match).

    Returns:
        :class:`CoverageReport` populated by sweeping the bundled alloy
        table, the fatigue + K_IC databases, the CALPHAD system tag, and
        the installed plugin registry.

    Example::

        >>> import austenite as au
        >>> r = au.coverage.check_alloy("Inconel 718")
        >>> r.supported
        True
    """

    record = _lookup_alloy_record(alloy)
    system = _alloy_family(alloy)
    n_sn = _count_fatigue(alloy)
    n_kic = _count_kic(alloy)
    plugins = _list_installed_plugins()

    gaps: list[str] = []
    citation = ""

    mechanical = bool(record and any(
        record.get(k) is not None
        for k in ("Sy_MPa", "Sut_MPa", "E_GPa", "sigma_y_MPa", "sigma_uts_MPa")
    ))
    kinetics = system in {"Fe-Cr", "Fe-Cr-Ni", "Fe-Cr-Mo-C", "Ni-Cr-Al-Ti"}
    calphad = system is not None and system in _SYSTEM_RANGES

    supported = bool(record) or mechanical or calphad or n_sn > 0

    if calphad:
        rng = _SYSTEM_RANGES[system]
        citation = rng[2]
    elif record and record.get("citation"):
        citation = record["citation"]

    # Build the gaps list.
    if n_sn == 0:
        gaps.append("No fatigue (S-N) data in bundled dataset.")
    elif n_sn < 3:
        gaps.append(f"Only {n_sn} fatigue curve(s) — limited R-ratio / T coverage.")

    if n_kic == 0:
        gaps.append("No K_IC fracture-toughness entries in bundled dataset.")

    if not calphad:
        gaps.append(
            f"CALPHAD system for {alloy!r} not yet catalogued; install "
            "a system-specific TDB plugin."
        )

    if not mechanical:
        gaps.append("Room-temperature σ_y / UTS not in the bundled spec table.")

    # Cox proportional-hazards (reliability) — not specific by alloy in v0.
    gaps.append(
        f"Cox proportional-hazards not calibrated for {alloy!r}; uses "
        "generic baseline. Calibrate with `au.calibrate(...)`."
    )

    # Plugin recommendations — same heuristics as `au.data` plugin lookup.
    plugin_recs: list[str] = []
    if "mil5j" not in plugins:
        plugin_recs.append("austenite-extras-mil5j — MMPDS / MIL-HDBK-5J extension")
    if "sandia-mms" not in plugins:
        plugin_recs.append("austenite-extras-sandia-mms — Sandia MMS toughness")
    if "corro-rates" not in plugins:
        plugin_recs.append("austenite-extras-corro-rates — long-term corrosion rates")

    return CoverageReport(
        alloy=alloy,
        supported=supported,
        calphad=calphad,
        kinetics=kinetics,
        mechanical=mechanical,
        fatigue_curves=n_sn,
        kic_entries=n_kic,
        gaps=gaps,
        plugin_recommendations=plugin_recs,
        citation=citation,
    )


def system_temperature_range(system: str) -> SystemRange:
    """Return the (T_min, T_max) over which a system is CALPHAD-modelled.

    Args:
        system: System tag, e.g. ``"Fe-Cr-Ni"``, ``"Al-Cu"``, ``"Ni"``.
            Case-insensitive; canonical hyphenation expected.

    Returns:
        :class:`SystemRange`. The bounds are derived from primary CALPHAD
        assessments and SGTE pure-element T-windows.

    Raises:
        NotImplementedError: If the system isn't catalogued.

    Example::

        >>> import austenite as au
        >>> rng = au.coverage.system_temperature_range("Fe-Cr-Ni")
        >>> T_lo, T_hi = rng
        >>> 273 <= T_lo <= 500 and 1700 <= T_hi <= 2000
        True
    """

    if not system:
        raise ValueError("system tag is required (e.g. 'Fe-Cr', 'Ni').")

    # Case-insensitive lookup; canonicalise hyphenation.
    norm = system.strip()
    candidates = [k for k in _SYSTEM_RANGES if k.lower() == norm.lower()]
    if not candidates:
        # Try prefix match.
        candidates = [k for k in _SYSTEM_RANGES if norm.lower() in k.lower()]
    if not candidates:
        raise NotImplementedError(
            f"System {system!r} is not catalogued in the v0.1 bundled "
            f"CALPHAD ranges. Known systems: {sorted(_SYSTEM_RANGES.keys())}."
        )
    chosen = candidates[0]
    T_lo, T_hi, cite, notes = _SYSTEM_RANGES[chosen]
    return SystemRange(
        system=chosen, T_min_K=T_lo, T_max_K=T_hi,
        notes=list(notes), citation=cite,
    )


def list_supported_alloys() -> list[str]:
    """Return every alloy name known to the bundled data + plugin registry."""

    names: list[str] = []
    try:
        from . import data as _data
        rows = _data.alloys()
        # rows may be a DataFrame or list[dict]
        if hasattr(rows, "to_dict"):
            for rec in rows.to_dict(orient="records"):
                n = rec.get("name") or rec.get("uns")
                if n:
                    names.append(str(n))
        else:
            for rec in rows:
                n = rec.get("name") or rec.get("uns")
                if n:
                    names.append(str(n))
    except Exception:  # pragma: no cover - defensive
        pass
    return sorted(set(names))
