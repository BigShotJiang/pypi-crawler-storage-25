"""Time-Temperature-Transformation and CCT diagram computation."""

from __future__ import annotations

from typing import Any, Mapping, Optional

from ._client import get_default_client
from ._models import (
    CctSweepInput,
    CctSweepResult,
    TttComputeInput,
    TttComputeResult,
)


def compute(
    *,
    composition: Mapping[str, float],
    grain_size_ASTM: int = 7,
    austenitization_C: Optional[float] = None,
    **kwargs: Any,
) -> TttComputeResult:
    """Compute the isothermal TTT diagram for a chemistry.

    Args:
        composition: Mass-fraction composition map.
        grain_size_ASTM: Prior austenite grain size (ASTM number).
        austenitization_C: Optional austenitization temperature override.

    Returns:
        A list of nose curves (ferrite, pearlite, bainite, ...) plus
        martensite-start and bainite-start temperatures.
    """

    payload = TttComputeInput(
        composition=composition,
        grain_size_ASTM=grain_size_ASTM,
        austenitization_C=austenitization_C,
        **kwargs,
    )
    client = get_default_client()
    response = client.post(
        "/v1/ttt/compute",
        json=payload.model_dump(exclude_none=True),
    )
    return TttComputeResult.model_validate(response.json())


def cct_sweep(
    *,
    composition: Mapping[str, float],
    cooling_rates_C_s: list[float],
    grain_size_ASTM: int = 7,
    **kwargs: Any,
) -> CctSweepResult:
    """Sweep cooling rates and return CCT curves + final microstructure."""

    payload = CctSweepInput(
        composition=composition,
        cooling_rates_C_s=cooling_rates_C_s,
        grain_size_ASTM=grain_size_ASTM,
        **kwargs,
    )
    client = get_default_client()
    response = client.post(
        "/v1/ttt/cct-sweep",
        json=payload.model_dump(exclude_none=True),
    )
    return CctSweepResult.model_validate(response.json())
