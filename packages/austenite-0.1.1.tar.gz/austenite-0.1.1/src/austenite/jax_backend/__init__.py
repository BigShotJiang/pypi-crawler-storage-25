"""JAX-differentiable backend for austenite — end-to-end gradients
through the ICME chain (chemistry -> hardness -> strength -> fracture ->
fatigue).

This module ports a representative subset of austenite's metallurgical
engines into a pure-JAX, jit-compilable, differentiable implementation
so that engineers can compose them with ``jax.grad``, ``jax.jit``,
``jax.vmap``, and gradient-based optimizers (``jaxopt`` / ``optax``).

The high-level entry point is :func:`design_path_jax`, which runs the
five-stage chain

    composition --(Maynier-Dollet HV30)--> HV
              --(Pavlina-Tyne 2008)--> sigma_y
              --(rule of thumb)-> sigma_uts
              --(Barsom-Rolfe 1972 from CVN(HV))--> KIc
              --(Goodman fatigue allowable)--> utilisation_pct, Nf

every step of which is expressed in ``jnp`` primitives. The result is a
pytree (``DesignPathJaxResult`` NamedTuple) so it round-trips cleanly
through JAX transformations.

The chain is intentionally lightweight and self-contained -- it does NOT
hit the Austenite HTTP API and therefore does not require ``httpx`` or
network access. It is the differentiable companion to
:func:`austenite.design_path`, suitable for fast surrogate-based inverse
design and gradient-based screening across composition / processing
spaces.

Citation
--------
This is the first production-ready end-to-end differentiable
materials-science library. The conceptual sketch first appeared in
Liu & Strachan (2025), "Differentiable programming for materials
science", arXiv:2505.01585. austenite ships a working implementation
calibrated against the same Maynier 1978 / Pavlina-Tyne 2008 /
Barsom-Rolfe 1972 / Goodman 1899 references the production
(non-differentiable) backend uses, so gradients flow from composition
all the way to fatigue utilisation.

Optional install
----------------
The JAX backend is an optional extra. To enable it::

    pip install austenite[jax]

If JAX is not installed, importing
:mod:`austenite.jax_backend` raises ``ImportError`` with a friendly
hint. The rest of austenite continues to work without JAX.

A Javanshir Hasanov production.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Optional-dep guard: surface a clear error if JAX is missing.
# ---------------------------------------------------------------------------

try:
    import jax  # noqa: F401  (presence check)
    import jax.numpy as _jnp  # noqa: F401  (presence check)
except ImportError as exc:  # pragma: no cover - exercised in CI without [jax]
    raise ImportError(
        "austenite.jax_backend requires JAX. Install the optional extra:\n"
        "    pip install austenite[jax]"
    ) from exc


# ---------------------------------------------------------------------------
# Backend selector — currently only one backend (jax). The hook is here
# so a future PyTorch / numpy backend can slot in without API churn.
# ---------------------------------------------------------------------------

_ACTIVE_BACKEND = "jax"


def set_jax_backend(name: str = "jax") -> None:
    """Select the differentiable backend.

    Currently only ``"jax"`` is supported. The argument exists so that
    a future ``"torch"`` / ``"numpy"`` backend can be wired in without
    touching call sites.
    """

    global _ACTIVE_BACKEND
    if name != "jax":
        raise ValueError(
            f"unsupported backend {name!r}; only 'jax' is available right now"
        )
    _ACTIVE_BACKEND = name


def get_active_backend() -> str:
    """Return the name of the currently selected differentiable backend."""

    return _ACTIVE_BACKEND


# ---------------------------------------------------------------------------
# Public surface — re-export the differentiable chain entry points.
# ---------------------------------------------------------------------------

from ._chains import (  # noqa: E402
    DesignPathJaxResult,
    FatigueResult,
    am_qualification_jax,
    design_path_jax,
)
from ._core import (  # noqa: E402
    barsom_rolfe_KIc,
    cvn_from_hv,
    goodman_utilisation,
    hall_petch_sigma_y,
    maynier_hv30,
    pavlina_tyne_sigma_y,
    sigma_uts_from_hv,
)
from ._optimizers import (  # noqa: E402
    HybridDesignResult,
    design,
    design_hybrid,
    design_jax,
)
from ._calphad import (  # noqa: E402
    CalphadEquilibriumJaxResult,
    calphad_equilibrium_jax,
)
from ._meltpool import (  # noqa: E402
    AlloyThermalProps,
    MeltPoolJaxResult,
    in718_props,
    meltpool_eagar_tsai_jax,
    meltpool_goldak_jax,
    meltpool_rosenthal_jax,
    ss316_props,
    ti64_props,
)
from ._fad import (  # noqa: E402
    FadResult,
    fad_2a_jax,
)
from ._phase_field import (  # noqa: E402
    AllenCahnResult,
    CahnHilliardResult,
    KarmaRappelResult,
    KhachaturyanResult,
    SteinbachPezzollaResult,
    allen_cahn_jax,
    cahn_hilliard_jax,
    cahn_hilliard_khachaturyan_jax,
    karma_rappel_jax,
    steinbach_pezzolla_jax,
)


__all__ = [
    # Entry points
    "design_path_jax",
    "am_qualification_jax",
    "design_jax",
    "design_hybrid",
    "design",
    "set_jax_backend",
    "get_active_backend",
    # Pytree result types
    "DesignPathJaxResult",
    "FatigueResult",
    "HybridDesignResult",
    # Differentiable primitives (exposed for advanced users)
    "maynier_hv30",
    "pavlina_tyne_sigma_y",
    "sigma_uts_from_hv",
    "barsom_rolfe_KIc",
    "cvn_from_hv",
    "goodman_utilisation",
    "hall_petch_sigma_y",
    # CALPHAD
    "calphad_equilibrium_jax",
    "CalphadEquilibriumJaxResult",
    # AM melt-pool
    "meltpool_rosenthal_jax",
    "meltpool_eagar_tsai_jax",
    "meltpool_goldak_jax",
    "AlloyThermalProps",
    "MeltPoolJaxResult",
    "in718_props",
    "ti64_props",
    "ss316_props",
    # Fracture FAD
    "fad_2a_jax",
    "FadResult",
    # Phase-field engines
    "cahn_hilliard_jax",
    "allen_cahn_jax",
    "steinbach_pezzolla_jax",
    "karma_rappel_jax",
    "cahn_hilliard_khachaturyan_jax",
    "CahnHilliardResult",
    "AllenCahnResult",
    "SteinbachPezzollaResult",
    "KarmaRappelResult",
    "KhachaturyanResult",
]
