"""JAX-traceable Failure Assessment Diagram (Level 2A).

Implements API 579-1 / ASME FFS-1 Part 9 Annex 9C Level 2A Failure
Assessment Diagram analysis in pure JAX so that ``jax.grad`` flows
from {crack size, applied stress, yield strength, KIc, geometry}
through to the *distance to the FAD curve*. That distance is the
canonical FFS margin used in pipeline / pressure-vessel litigation
work.

The Level 2A FAD curve is the elastic-plastic toughness ratio Kr as a
function of the load ratio Lr:

.. math::
    K_r(L_r) = \\left( 1 - 0.14 L_r^2 \\right) \\left( 0.3 + 0.7
                \\exp \\left( -0.65 L_r^6 \\right) \\right),
                \\;\\; L_r \\le L_r^{\\max}

with the cutoff :math:`L_r^{\\max} = (\\sigma_y + \\sigma_{uts}) /
(2 \\sigma_y)` (typically 1.2-1.4 for engineering alloys).

A given assessment point :math:`(L_r, K_r)` is acceptable iff it lies
**inside** the curve. We expose the signed distance to the curve so
``jax.grad`` returns a finite, well-conditioned gradient even at the
boundary.

Crack geometries supported (with stress-intensity formulas):

* ``"edge-crack"`` — single-edge notched plate, Y = 1.12 (Tada 2000).
* ``"surface-flaw"`` — semi-elliptical surface flaw, Newman-Raju 1981
  (a/c = 0.4 default).
* ``"through-wall"`` — through-thickness crack in a plate, Y = √π · F
  with F = (sec(π α / 2))^½ where α = a / W (Brown-Srawley).
* ``"center-crack"`` — centre crack in an infinite plate, Y = √π
  (Westergaard).

References
----------
* API 579-1 / ASME FFS-1 2021 *Fitness-For-Service*, Part 9 Annex 9C.
* Anderson T.L. *Fracture Mechanics — Fundamentals and Applications*
  4th ed., CRC Press (2017).
* Tada H., Paris P., Irwin G. *The Stress Analysis of Cracks
  Handbook*, ASME Press (2000).
* Newman J.C. & Raju I.S. *An empirical stress-intensity factor
  equation for the surface crack*. Engng. Fract. Mech. 15 (1981) 185.

A Javanshir Hasanov production.
"""

from __future__ import annotations

from typing import NamedTuple

import jax
import jax.numpy as jnp


# ---------------------------------------------------------------------------
# Result pytree
# ---------------------------------------------------------------------------


class FadResult(NamedTuple):
    """Pytree of Failure Assessment Diagram outputs.

    Attributes:
        Lr: Load ratio :math:`\\sigma_{ref} / \\sigma_y`.
        Kr: Toughness ratio :math:`K_I / K_{Ic}`.
        K_I_MPa_sqm: Computed mode-I stress intensity, MPa·√m.
        Kr_curve_at_Lr: Value of the FAD curve at this Lr (i.e. the
            maximum allowed Kr for the current Lr).
        Lr_max: Cutoff load ratio :math:`(\\sigma_y + \\sigma_{uts}) /
            (2 \\sigma_y)`.
        distance_to_curve: Signed Euclidean distance from (Lr, Kr) to
            the FAD curve. **Positive = inside (safe)**, negative =
            outside (unsafe). Differentiable everywhere thanks to a
            smooth interior approximation.
        acceptable: 1.0 if the point is inside the curve, 0.0 if not.
    """

    Lr: jnp.ndarray
    Kr: jnp.ndarray
    K_I_MPa_sqm: jnp.ndarray
    Kr_curve_at_Lr: jnp.ndarray
    Lr_max: jnp.ndarray
    distance_to_curve: jnp.ndarray
    acceptable: jnp.ndarray


# ---------------------------------------------------------------------------
# Geometry → Y factor + ref. stress
# ---------------------------------------------------------------------------


GEOMETRY_IDS = {
    "edge-crack": 0,
    "surface-flaw": 1,
    "through-wall": 2,
    "center-crack": 3,
}


def _Y_and_ref(geom_id: int, a_mm: jnp.ndarray, W_mm: jnp.ndarray,
               sigma_app: jnp.ndarray) -> tuple[jnp.ndarray, jnp.ndarray]:
    """Return ``(Y, sigma_ref)`` for the requested geometry.

    All four branches are smooth in ``a_mm`` so ``jax.grad`` is finite
    everywhere ``a_mm`` ∈ (0, W). ``sigma_ref`` is the reference stress
    used in Level 2A — for these simple geometries it equals the
    applied stress, but we expose it so callers can override.
    """

    a = jnp.maximum(jnp.asarray(a_mm), 1e-6)
    W = jnp.maximum(jnp.asarray(W_mm), 1e-6)
    alpha = jnp.clip(a / W, 1e-6, 0.99)
    dt = alpha.dtype

    sqrt_pi = jnp.sqrt(jnp.pi)

    def _edge(_a):
        # Tada-Paris-Irwin: F = 1.12 - 0.231 α + 10.55 α² - 21.72 α³ + 30.39 α⁴.
        # The √π is folded in here so K_I = Y·σ·√a is consistent with the
        # through/center branches (which also pre-bake √π). Without it the
        # edge/surface K_I were 1.772× low — non-conservative.
        y = sqrt_pi * (1.12
                       - 0.231 * alpha
                       + 10.55 * alpha**2
                       - 21.72 * alpha**3
                       + 30.39 * alpha**4)
        return y.astype(dt)

    def _surf(_a):
        # Newman-Raju 1981 with a/c = 0.4: K = (M/√Q)·σ·√(π a),
        # Q = 1 + 1.464 (a/c)^1.65 ≈ 1.376, M = 1.13 - 0.09 (a/c) ≈ 1.094.
        # √π folded in for the K_I = Y·σ·√a convention.
        y = jnp.asarray(sqrt_pi * 1.094 / jnp.sqrt(1.376), dtype=dt)
        # tiny α term keeps the gradient finite under autodiff
        return y + 0.0 * alpha

    def _through(_a):
        arg = jnp.clip(jnp.pi * alpha / 2.0, 0.0, 1.55)
        sec = 1.0 / jnp.cos(arg)
        y = jnp.sqrt(jnp.pi) * jnp.sqrt(jnp.maximum(sec, 1.0))
        return y.astype(dt)

    def _center(_a):
        y = jnp.asarray(jnp.sqrt(jnp.pi), dtype=dt) + 0.0 * alpha
        return y

    Y = jax.lax.switch(geom_id, [_edge, _surf, _through, _center], a)
    sigma_ref = jnp.asarray(sigma_app).astype(dt)
    return Y, sigma_ref


def _Kr_curve(Lr: jnp.ndarray) -> jnp.ndarray:
    """Level 2A FAD curve K_r(L_r) per API 579 Annex 9C.

    The classical Milne-Ainsworth Option 2 formula:
        K_r = (1 - 0.14 L_r²) · (0.3 + 0.7 · exp(-0.65 L_r⁶))
    Smoothly clamped at 0 for Lr beyond cutoff.
    """

    base = (1.0 - 0.14 * Lr * Lr) * (0.3 + 0.7 * jnp.exp(-0.65 * Lr**6))
    return jnp.maximum(base, 0.0)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def fad_2a_jax(
    *,
    a_mm: jnp.ndarray,
    sigma: jnp.ndarray,
    sigma_y: jnp.ndarray,
    sigma_uts: jnp.ndarray,
    KIc: jnp.ndarray,
    geometry: str = "edge-crack",
    W_mm: jnp.ndarray = jnp.asarray(50.0),
) -> FadResult:
    """Level 2A FAD analysis (API 579 Part 9 Annex 9C).

    Args:
        a_mm: Crack size (depth or half-length), mm.
        sigma: Applied (membrane) stress, MPa.
        sigma_y: Yield strength, MPa.
        sigma_uts: Ultimate tensile strength, MPa.
        KIc: Plane-strain fracture toughness, MPa·√m.
        geometry: One of ``"edge-crack"``, ``"surface-flaw"``,
            ``"through-wall"``, ``"center-crack"``.
        W_mm: Plate / section width, mm. Used to evaluate the α=a/W
            ratio for finite-width corrections.

    Returns:
        :class:`FadResult` with ``distance_to_curve`` — negative means
        unacceptable, positive means inside the FAD envelope.

    Example:
        >>> import jax, jax.numpy as jnp
        >>> from austenite.jax_backend import fad_2a_jax
        >>>
        >>> def signed_dist(a, s):
        ...     r = fad_2a_jax(a_mm=a, sigma=s, sigma_y=380.0,
        ...                    sigma_uts=550.0, KIc=80.0,
        ...                    geometry="edge-crack")
        ...     return r.distance_to_curve
        >>>
        >>> g = jax.grad(signed_dist, argnums=(0, 1))(jnp.float64(5.0),
        ...                                           jnp.float64(200.0))
    """

    a = jnp.asarray(a_mm)
    s = jnp.asarray(sigma)
    s_y = jnp.maximum(jnp.asarray(sigma_y), 1e-3)
    s_uts = jnp.maximum(jnp.asarray(sigma_uts), 1e-3)
    KIc_arr = jnp.maximum(jnp.asarray(KIc), 1e-3)

    geom_id = GEOMETRY_IDS.get(geometry)
    if geom_id is None:
        raise ValueError(
            f"unknown geometry {geometry!r}; expected one of {list(GEOMETRY_IDS)}"
        )

    Y, sigma_ref = _Y_and_ref(geom_id, a, W_mm, s)
    # K_I = Y · σ · √a  (a in metres). Every geometry's Y now pre-bakes the
    # √π factor, so this single expression is correct for all four.
    a_m = jnp.maximum(a * 1.0e-3, 1.0e-9)
    K_I = Y * s * jnp.sqrt(a_m)

    Lr = sigma_ref / s_y
    Kr = K_I / KIc_arr
    Lr_max = (s_y + s_uts) / (2.0 * s_y)
    # Smooth zeroing of the curve past Lr_max
    soft_cut = jax.nn.sigmoid(20.0 * (Lr_max - Lr))
    Kr_curve = _Kr_curve(jnp.minimum(Lr, Lr_max)) * soft_cut

    # Signed distance to the curve: positive inside, negative outside.
    # Use the closest-point distance approximation on a 64-point
    # discretisation of the curve — fully differentiable.
    n_grid = 64
    Lr_grid = jnp.linspace(0.0, Lr_max, n_grid)
    Kr_grid = _Kr_curve(jnp.minimum(Lr_grid, Lr_max))
    d2 = (Lr_grid - Lr) ** 2 + (Kr_grid - Kr) ** 2
    # smooth-min via -logsumexp(-d²/τ)·τ
    tau = 0.001
    d_min2 = -tau * jax.scipy.special.logsumexp(-d2 / tau)
    d_min = jnp.sqrt(jnp.maximum(d_min2, 1e-12))
    # Sign: inside iff Kr < Kr_curve(Lr) AND Lr < Lr_max
    inside = jax.nn.sigmoid(50.0 * (Kr_curve - Kr)) * jax.nn.sigmoid(50.0 * (Lr_max - Lr))
    signed = d_min * (2.0 * inside - 1.0)
    acceptable = jax.nn.sigmoid(20.0 * signed)

    return FadResult(
        Lr=Lr,
        Kr=Kr,
        K_I_MPa_sqm=K_I,
        Kr_curve_at_Lr=Kr_curve,
        Lr_max=Lr_max,
        distance_to_curve=signed,
        acceptable=acceptable,
    )


__all__ = [
    "FadResult",
    "GEOMETRY_IDS",
    "fad_2a_jax",
]
