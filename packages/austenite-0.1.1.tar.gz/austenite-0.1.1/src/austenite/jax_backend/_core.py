"""JAX-differentiable implementations of the core metallurgical engines.

Every function in this module:

* uses only ``jax.numpy`` operations (no Python branching on traced values,
  no ``numpy`` / ``scipy`` calls),
* is safe under ``jax.jit`` / ``jax.grad`` / ``jax.vmap``,
* accepts and returns ``jnp.ndarray`` (or JAX-tracer) scalars / arrays
  with float32 dtype by default.

The composition vector convention is

    comp = [C, Mn, Cr, Mo, Ni, Si, V]    # all in wt%

i.e. ``comp[0]`` is the carbon weight-percent. This is the minimal
chemistry needed to evaluate the Maynier 1978 correlations. Trace
elements default to 0.0 if not supplied.

References
----------
* Maynier, Dollet, Bastien (1978) — *Hardenability of low-alloy steels*,
  AIME pp. 163-178.
* Pavlina, Van Tyne (2008) — *Correlation of yield strength and tensile
  strength with hardness*, J. Mater. Eng. Perform. 17, 888.
* Barsom, Rolfe (1972) — *Empirical correlation of the upper-shelf
  Charpy energy with K_Ic*, ASTM STP 466.
* Hall (1951) / Petch (1953) — *The cleavage strength of polycrystals*.
* Goodman (1899) — *Mechanics applied to engineering*.
* Liu, Strachan (2025) — arXiv:2505.01585.

A Javanshir Hasanov production.
"""

from __future__ import annotations

import jax
import jax.numpy as jnp
from jax import lax

# Make 64-bit floats opt-in only — keep default at f32 to match jax's
# defaults so users get the cheapest possible compiled kernels.

ArrayLike = jnp.ndarray  # type alias for clarity


# ---------------------------------------------------------------------------
# Composition-vector helpers
# ---------------------------------------------------------------------------

#: The element ordering this module assumes. Trace elements not in this
#: list are treated as zero. Keep the list short -- the Maynier-Dollet
#: correlation only depends on these seven.
COMPOSITION_ELEMENTS = ("C", "Mn", "Cr", "Mo", "Ni", "Si", "V")

# Index aliases for readability inside engines.
_C, _MN, _CR, _MO, _NI, _SI, _V = range(7)


def _pad_composition(comp: ArrayLike) -> ArrayLike:
    """Pad a short composition vector with zeros to length 7.

    Convenience for callers who only have ``[C, Mn, Cr, Mo, Ni]`` —
    the missing ``Si`` and ``V`` slots become zero.
    """

    arr = jnp.asarray(comp, dtype=jnp.float32)
    n = arr.shape[-1]
    if n == len(COMPOSITION_ELEMENTS):
        return arr
    if n > len(COMPOSITION_ELEMENTS):
        return arr[..., : len(COMPOSITION_ELEMENTS)]
    pad_width = len(COMPOSITION_ELEMENTS) - n
    pad_shape = list(arr.shape)
    pad_shape[-1] = pad_width
    return jnp.concatenate([arr, jnp.zeros(pad_shape, dtype=arr.dtype)], axis=-1)


# ---------------------------------------------------------------------------
# 1. Pavlina-Tyne 2008 -- sigma_y from HV (trivially differentiable)
# ---------------------------------------------------------------------------


@jax.jit
def pavlina_tyne_sigma_y(hv: ArrayLike) -> ArrayLike:
    """Yield strength from Vickers hardness (Pavlina-Tyne 2008).

        sigma_y [MPa] = 2.876 * HV - 90.7

    The relation is valid for hardenable steels with HV in roughly
    [150, 700]. Clipped at zero to keep gradients well defined.
    """

    hv_f = jnp.asarray(hv, dtype=jnp.float32)
    sigma = 2.876 * hv_f - 90.7
    # jnp.maximum keeps dual numbers happy under jax.grad.
    return jnp.maximum(sigma, 0.0)


# Companion sigma_uts fit (Pavlina-Tyne 2008 figure 4): sigma_uts ~= 3.0 * HV
# for HV < 600. Useful for Goodman.
@jax.jit
def sigma_uts_from_hv(hv: ArrayLike) -> ArrayLike:
    """Ultimate tensile strength from Vickers hardness (Pavlina-Tyne 2008)."""

    hv_f = jnp.asarray(hv, dtype=jnp.float32)
    return jnp.maximum(3.0 * hv_f, 0.0)


# ---------------------------------------------------------------------------
# 2. Barsom-Rolfe 1972 -- K_Ic^2 / E = 5 * CVN
# ---------------------------------------------------------------------------

#: Young's modulus assumed for steels when chaining CVN -> K_Ic. MPa.
E_STEEL_MPA = 207_000.0


@jax.jit
def cvn_from_hv(hv: ArrayLike) -> ArrayLike:
    """Charpy upper-shelf energy from HV (Roberts-Newton 1981 exponential).

        CVN [J] ~ 290 * exp(-HV / 280)

    Matches the in-house non-differentiable backend (see
    ``apps/web/src/lib/design-path/orchestrator.ts``).
    """

    hv_f = jnp.asarray(hv, dtype=jnp.float32)
    return jnp.maximum(290.0 * jnp.exp(-hv_f / 280.0), 2.0)


@jax.jit
def barsom_rolfe_KIc(cvn_J: ArrayLike, E_MPa: float = E_STEEL_MPA) -> ArrayLike:
    """Plane-strain fracture toughness from Charpy energy (Barsom-Rolfe 1972).

        K_Ic^2 = 5 * E * CVN     ->     K_Ic [MPa sqrt(m)] = sqrt(5 E CVN / 1000)

    The 1000 factor converts CVN (J) to a unit-consistent intermediate
    so the output is in MPa*sqrt(m).
    """

    cvn = jnp.asarray(cvn_J, dtype=jnp.float32)
    return jnp.sqrt(jnp.maximum(5.0 * E_MPa * cvn, 0.0) / 1000.0)


# ---------------------------------------------------------------------------
# 3. Maynier-Dollet HV30 (a function of chemistry + cooling rate)
# ---------------------------------------------------------------------------
#
# Port of the TS implementation in
# apps/web/src/lib/jominy/maynier.ts. All branching on cooling rate is
# replaced with jnp.maximum / jnp.minimum so the function is safe under
# jax.jit / jax.grad.

_LOG10 = jnp.log(jnp.asarray(10.0, dtype=jnp.float32))


def _log10(x: ArrayLike) -> ArrayLike:
    """JAX-safe base-10 logarithm with a small floor to keep grads finite."""

    return jnp.log(jnp.maximum(x, 1e-3)) / _LOG10


@jax.jit
def hv_martensite(comp: ArrayLike, Vc: ArrayLike) -> ArrayLike:
    """Martensite Vickers hardness, Maynier 1978 Eq. 6.

    .. math::
        HV_M = 127 + 949 \\cdot C + 27 \\cdot Si + 11 \\cdot Mn
               + 8 \\cdot Ni + 16 \\cdot Cr + 21 \\cdot \\log_{10} V_c
    """

    c = _pad_composition(comp)
    logV = _log10(Vc)
    return (
        127.0
        + 949.0 * c[..., _C]
        + 27.0 * c[..., _SI]
        + 11.0 * c[..., _MN]
        + 8.0 * c[..., _NI]
        + 16.0 * c[..., _CR]
        + 21.0 * logV
    )


@jax.jit
def hv_bainite(comp: ArrayLike, Vc: ArrayLike) -> ArrayLike:
    """Bainite Vickers hardness, Maynier 1978 Eq. 7."""

    c = _pad_composition(comp)
    logV = _log10(Vc)
    a = (
        -323.0
        + 185.0 * c[..., _C]
        + 330.0 * c[..., _SI]
        + 153.0 * c[..., _MN]
        + 65.0 * c[..., _NI]
        + 144.0 * c[..., _CR]
        + 191.0 * c[..., _MO]
    )
    b = (
        89.0
        + 53.0 * c[..., _C]
        - 55.0 * c[..., _SI]
        - 22.0 * c[..., _MN]
        - 10.0 * c[..., _NI]
        - 20.0 * c[..., _CR]
        - 33.0 * c[..., _MO]
    )
    return a + b * logV


@jax.jit
def hv_ferrite_pearlite(comp: ArrayLike, Vc: ArrayLike) -> ArrayLike:
    """Ferrite/Pearlite Vickers hardness, Maynier 1978 Eq. 8."""

    c = _pad_composition(comp)
    logV = _log10(Vc)
    a = (
        42.0
        + 223.0 * c[..., _C]
        + 53.0 * c[..., _SI]
        + 30.0 * c[..., _MN]
        + 12.6 * c[..., _NI]
        + 7.0 * c[..., _CR]
        + 19.0 * c[..., _MO]
    )
    b = (
        10.0
        - 19.0 * c[..., _SI]
        + 4.0 * c[..., _NI]
        + 8.0 * c[..., _CR]
        + 130.0 * c[..., _V]
    )
    return a + b * logV


@jax.jit
def maynier_critical_log_rates(comp: ArrayLike) -> ArrayLike:
    """Return ``log10(V_cM_50), log10(V_cFP_90)`` as a stacked array.

    These are the critical cooling rates that drive the smooth
    phase-fraction sigmoids in :func:`maynier_phase_fractions`. The B
    branch is filled in as the residual so we only need the M and FP
    crossovers.
    """

    c = _pad_composition(comp)
    log_VcM_50 = (
        9.81
        - 4.62 * c[..., _C]
        - 1.05 * c[..., _MN]
        - 0.50 * c[..., _SI]
        - 1.16 * c[..., _NI]
        - 0.54 * c[..., _CR]
        - 0.50 * c[..., _MO]
    )
    log_VcFP_90 = (
        6.36
        - 0.43 * c[..., _C]
        - 0.49 * c[..., _MN]
        - 0.78 * c[..., _SI]
        - 0.27 * c[..., _NI]
        - 0.91 * c[..., _CR]
        - 2.0 * c[..., _MO]
        - 5.0 * c[..., _V]
    )
    return jnp.stack([log_VcM_50, log_VcFP_90], axis=-1)


@jax.jit
def maynier_phase_fractions(comp: ArrayLike, Vc: ArrayLike) -> ArrayLike:
    """Smooth Maynier phase fractions ``[a_M, a_B, a_FP]``.

    Mirrors the sigmoid-based renormalisation in
    ``apps/web/src/lib/jominy/maynier.ts``; gradients are well-defined
    everywhere (no Python ``if``).
    """

    cr = maynier_critical_log_rates(comp)
    logV = _log10(Vc)
    k = 3.0  # sigmoid sharpness (matches TS impl)
    a_M = jax.nn.sigmoid(k * (logV - cr[..., 0]))
    a_FP = 1.0 - jax.nn.sigmoid(k * (logV - cr[..., 1]))
    a_B = jnp.maximum(0.0, 1.0 - a_M - a_FP)
    total = a_M + a_B + a_FP
    return jnp.stack([a_M, a_B, a_FP], axis=-1) / total[..., None]


@jax.jit
def maynier_hv30(comp: ArrayLike, Vc: ArrayLike) -> ArrayLike:
    """Composite HV30 from rule-of-mixtures over Maynier phase blocks.

    Args:
        comp: composition vector ``[C, Mn, Cr, Mo, Ni, Si, V]`` in wt%.
            Shorter vectors are zero-padded; longer vectors are
            truncated.
        Vc: cooling rate at 700 C, deg C / s.

    Returns:
        ``HV30`` -- a JAX scalar (or array, if ``comp`` is batched).
    """

    phi = maynier_phase_fractions(comp, Vc)
    HVm = hv_martensite(comp, Vc)
    HVb = hv_bainite(comp, Vc)
    HVfp = hv_ferrite_pearlite(comp, Vc)
    return phi[..., 0] * HVm + phi[..., 1] * HVb + phi[..., 2] * HVfp


# ---------------------------------------------------------------------------
# 4. Goodman fatigue utilisation
# ---------------------------------------------------------------------------
#
# sigma_a / sigma_e + sigma_m / sigma_uts <= 1  (linear Goodman line)
# utilisation = (sigma_a / sigma_e) + (sigma_m / sigma_uts)
# The classical "infinite-life" boundary is utilisation == 1.0.


@jax.jit
def goodman_utilisation(
    sigma_a_MPa: ArrayLike,
    sigma_m_MPa: ArrayLike,
    sigma_e_MPa: ArrayLike,
    sigma_uts_MPa: ArrayLike,
) -> ArrayLike:
    """Goodman utilisation = sigma_a/sigma_e + sigma_m/sigma_uts.

    Returns a unitless ratio (1.0 == on the Goodman line). The numeric
    utilisation in percent is just ``100 * utilisation``.
    """

    sa = jnp.asarray(sigma_a_MPa, dtype=jnp.float32)
    sm = jnp.asarray(sigma_m_MPa, dtype=jnp.float32)
    se = jnp.maximum(jnp.asarray(sigma_e_MPa, dtype=jnp.float32), 1e-3)
    suts = jnp.maximum(jnp.asarray(sigma_uts_MPa, dtype=jnp.float32), 1e-3)
    return sa / se + sm / suts


# Basquin life: sigma_a = sigma_f' (2 Nf)^b   with b = -0.085 for steels.
@jax.jit
def basquin_life(sigma_a_MPa: ArrayLike, sigma_uts_MPa: ArrayLike) -> ArrayLike:
    """Basquin cycles-to-failure for steels.

    Uses the Stephens-Fatemi defaults: ``b = -0.085`` and
    ``sigma_f' = sigma_uts + 345``. ``Nf`` is clipped to ``[1, 1e9]``
    for safety; the gradient is still defined inside that range.
    """

    sa = jnp.asarray(sigma_a_MPa, dtype=jnp.float32)
    suts = jnp.asarray(sigma_uts_MPa, dtype=jnp.float32)
    sf_prime = suts + 345.0
    b_basquin = -0.085
    # Use lax.cond surrogate via jnp.where so it's vmap-safe.
    sa_safe = jnp.clip(sa, 1e-3, sf_prime - 1e-3)
    Nf = 0.5 * jnp.power(sa_safe / sf_prime, 1.0 / b_basquin)
    Nf = jnp.where(sa <= 0.0, 1.0e9, Nf)
    Nf = jnp.where(sa >= sf_prime, 1.0, Nf)
    return jnp.clip(Nf, 1.0, 1.0e9)


# ---------------------------------------------------------------------------
# 5. Hall-Petch
# ---------------------------------------------------------------------------
#
# sigma_y = sigma_0 + k * d^(-1/2)   (d in micrometres -- common convention)
# Trivially differentiable everywhere d > 0.


@jax.jit
def hall_petch_sigma_y(
    grain_size_um: ArrayLike,
    sigma_0_MPa: ArrayLike = 150.0,
    k_MPa_um_half: ArrayLike = 600.0,
) -> ArrayLike:
    """Hall-Petch yield strength.

    .. math::
        \\sigma_y = \\sigma_0 + k \\, d^{-1/2}

    Defaults (``sigma_0=150``, ``k=600``) are reasonable for ferritic
    steels (e.g. Krauss, *Steels* 2005, Ch. 5). Set them explicitly for
    other grades.
    """

    d = jnp.maximum(jnp.asarray(grain_size_um, dtype=jnp.float32), 1e-3)
    s0 = jnp.asarray(sigma_0_MPa, dtype=jnp.float32)
    k = jnp.asarray(k_MPa_um_half, dtype=jnp.float32)
    return s0 + k / jnp.sqrt(d)


# ---------------------------------------------------------------------------
# Endurance limit -- steel rule of thumb, capped at 700 MPa.
# ---------------------------------------------------------------------------


@jax.jit
def endurance_from_uts(sigma_uts_MPa: ArrayLike) -> ArrayLike:
    """Steel endurance limit ~= min(700, 0.5 * sigma_uts)."""

    return jnp.minimum(700.0, 0.5 * jnp.asarray(sigma_uts_MPa, dtype=jnp.float32))


__all__ = [
    "COMPOSITION_ELEMENTS",
    "E_STEEL_MPA",
    # Engine 1
    "pavlina_tyne_sigma_y",
    "sigma_uts_from_hv",
    # Engine 2
    "cvn_from_hv",
    "barsom_rolfe_KIc",
    # Engine 3 (decomposed for testing)
    "hv_martensite",
    "hv_bainite",
    "hv_ferrite_pearlite",
    "maynier_critical_log_rates",
    "maynier_phase_fractions",
    "maynier_hv30",
    # Engine 4
    "goodman_utilisation",
    "basquin_life",
    "endurance_from_uts",
    # Engine 5
    "hall_petch_sigma_y",
]
