"""Convenience wrappers around jaxopt for the common austenite use cases.

Two entry points:

* :func:`design_jax` — gradient-based inverse design. Takes any
  objective callable ``f(x) -> jnp.ndarray`` (typically built on
  :func:`design_path_jax`) and runs a gradient-based optimiser over the
  chosen composition / processing-window parameters. The optimiser
  choice (``"gradient-descent"`` / ``"lbfgs"`` / ``"scipy"``) is just an
  alias dispatch so we never expose the user to jaxopt's import depth.

* :func:`design_hybrid` — *hybrid NSGA-II + L-BFGS polishing*. Runs
  global multi-objective search (NSGA-II) for many generations, then
  for every Pareto-front candidate runs a few L-BFGS steps using
  ``jax.grad(objective)`` to local-polish. The result is a *polished*
  Pareto front — what production materials-design loops actually need.

Returned :class:`DesignJaxResult` / :class:`HybridDesignResult` hold
the optimum, the objective trajectory, and a sane convergence note.
Bounds are enforced with a projection step after every iteration.

References for the hybrid path:
  * Deb K. et al., *NSGA-II: a fast and elitist multi-objective GA*,
    IEEE Trans. Evol. Comput. 6 (2002) 182.
  * Zitzler E. & Thiele L., *Multiobjective evolutionary algorithms*,
    IEEE Trans. Evol. Comput. 3 (1999) 257.
  * Wessing S., *The multiple-objective genetic algorithm and its
    application to inverse materials design*, JOM 70 (2018) 1769.

A Javanshir Hasanov production.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Optional, Sequence

import numpy as np

import jax
import jax.numpy as jnp


# ---------------------------------------------------------------------------
# Result container -- plain dataclass; pytree-ness not needed downstream.
# ---------------------------------------------------------------------------


@dataclass
class DesignJaxResult:
    """Outcome of a gradient-based inverse-design run."""

    x: jnp.ndarray  # optimum parameters
    f: float  # objective at optimum
    trajectory: list[float]  # f at each iteration (len <= n_iter + 1)
    n_iter: int  # iterations actually executed
    converged: bool  # True if the trajectory stopped improving
    optimizer: str  # optimiser name for provenance


# ---------------------------------------------------------------------------
# design_jax
# ---------------------------------------------------------------------------


def _project(
    x: jnp.ndarray,
    bounds: Optional[Sequence[tuple[float, float]]],
) -> jnp.ndarray:
    """Project ``x`` onto the per-element box defined by ``bounds``."""

    if bounds is None:
        return x
    lo = jnp.asarray([b[0] for b in bounds], dtype=x.dtype)
    hi = jnp.asarray([b[1] for b in bounds], dtype=x.dtype)
    return jnp.clip(x, lo, hi)


def design_jax(
    objective: Callable[[jnp.ndarray], jnp.ndarray],
    x0: jnp.ndarray,
    *,
    bounds: Optional[Sequence[tuple[float, float]]] = None,
    constraints: Optional[Callable[[jnp.ndarray], jnp.ndarray]] = None,
    optimizer: str = "gradient-descent",
    n_iter: int = 200,
    learning_rate: float = 1.0e-3,
    tol: float = 1.0e-6,
) -> DesignJaxResult:
    """Gradient-based inverse design over a JAX-differentiable objective.

    Args:
        objective: Callable ``f(x) -> scalar`` that is safe under
            ``jax.grad``. Typically built on :func:`design_path_jax`.
        x0: Initial composition / parameter vector.
        bounds: Optional sequence of ``(lo, hi)`` per-element bounds.
            Enforced by projection after every step.
        constraints: Optional ``g(x) -> scalar`` penalty added to the
            objective with weight 100 (soft constraint). Use for
            "carbon must stay <= 0.6 wt%" type guards.
        optimizer: One of ``"gradient-descent"``, ``"lbfgs"``, or
            ``"scipy"``. ``"scipy"`` dispatches to jaxopt's
            ``ScipyMinimize`` (L-BFGS-B under the hood). Falls back to
            in-house gradient descent if jaxopt is not installed.
        n_iter: Maximum iterations.
        learning_rate: Step size for plain gradient descent. Ignored
            by L-BFGS / scipy.
        tol: Convergence tolerance on the change in objective value.

    Returns:
        :class:`DesignJaxResult` with optimum, trajectory, and status.
    """

    x = jnp.asarray(x0, dtype=jnp.float32)

    def _full_objective(p: jnp.ndarray) -> jnp.ndarray:
        val = jnp.asarray(objective(p))
        if constraints is not None:
            val = val + 100.0 * jnp.asarray(constraints(p))
        return val

    f_and_g = jax.value_and_grad(_full_objective)

    try:
        import jaxopt  # type: ignore[import-not-found]
        has_jaxopt = True
    except ImportError:  # pragma: no cover - exercised by skipping
        has_jaxopt = False
        jaxopt = None  # type: ignore[assignment]

    trajectory: list[float] = []

    if optimizer == "gradient-descent" or not has_jaxopt:
        # Hand-rolled projected GD with adaptive step on increase.
        lr = learning_rate
        prev = float("inf")
        converged = False
        actual_iter = 0
        for i in range(n_iter):
            actual_iter = i + 1
            f_val, grad = f_and_g(x)
            trajectory.append(float(f_val))
            if jnp.any(jnp.isnan(grad)):
                converged = False
                break
            step = x - lr * grad
            step = _project(step, bounds)
            new_f = float(_full_objective(step))
            if new_f > float(f_val):
                # back off and skip applying the step
                lr *= 0.5
                if lr < 1e-12:
                    converged = True
                    break
                continue
            x = step
            if abs(prev - new_f) < tol and i > 5:
                converged = True
                trajectory.append(new_f)
                break
            prev = new_f
        if not trajectory:
            trajectory.append(float(_full_objective(x)))
        return DesignJaxResult(
            x=x,
            f=float(trajectory[-1]),
            trajectory=trajectory,
            n_iter=actual_iter,
            converged=converged,
            optimizer="gradient-descent",
        )

    if optimizer == "lbfgs":
        solver = jaxopt.LBFGS(fun=_full_objective, maxiter=n_iter, tol=tol)
        x_opt, state = solver.run(x)
        x_opt = _project(x_opt, bounds)
        f_final = float(_full_objective(x_opt))
        # jaxopt LBFGS does not expose a per-iter loss trajectory, so we
        # populate at least the start and end so downstream code that
        # consumes ``trajectory`` works.
        trajectory = [float(_full_objective(x)), f_final]
        return DesignJaxResult(
            x=x_opt,
            f=f_final,
            trajectory=trajectory,
            n_iter=int(getattr(state, "iter_num", n_iter)),
            converged=bool(getattr(state, "error", 0.0) < tol),
            optimizer="lbfgs",
        )

    if optimizer == "scipy":
        solver = jaxopt.ScipyMinimize(
            fun=_full_objective,
            method="L-BFGS-B",
            maxiter=n_iter,
            tol=tol,
        )
        x_opt, state = solver.run(x)
        x_opt = _project(x_opt, bounds)
        f_final = float(_full_objective(x_opt))
        trajectory = [float(_full_objective(x)), f_final]
        return DesignJaxResult(
            x=x_opt,
            f=f_final,
            trajectory=trajectory,
            n_iter=int(getattr(state, "iter_num", n_iter)),
            converged=True,
            optimizer="scipy",
        )

    raise ValueError(
        f"unknown optimizer {optimizer!r}; expected one of "
        "'gradient-descent', 'lbfgs', 'scipy'"
    )


# ---------------------------------------------------------------------------
# Hybrid NSGA-II + JAX-grad au.design() — global multi-objective search +
# local L-BFGS polish per Pareto-front candidate.
# ---------------------------------------------------------------------------


@dataclass
class HybridDesignResult:
    """Outcome of a hybrid NSGA-II + L-BFGS run.

    Attributes:
        pareto_front_x: ``(K, d)`` numpy array of polished design vectors.
        pareto_front_f: ``(K, m)`` numpy array of objective vectors (one
            row per Pareto-front member).
        hypervolume: Hypervolume of the polished Pareto front w.r.t. a
            reference point built from the worst point on the front.
        igd: Inverted Generational Distance against the unpolished
            Pareto front (a measure of how much polishing improved the
            front — smaller is better).
        n_evaluations: Total objective evaluations across NSGA-II + polish.
        n_generations: Generations executed.
        polish_iter: L-BFGS steps per Pareto-front candidate.
        polished: True if at least one Pareto-front candidate was polished.
    """

    pareto_front_x: np.ndarray
    pareto_front_f: np.ndarray
    hypervolume: float
    igd: float
    n_evaluations: int
    n_generations: int
    polish_iter: int
    polished: bool
    history: list[dict] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Tiny in-house NSGA-II — pure numpy. Reused by :func:`design_hybrid` when
# pymoo is not installed.
# ---------------------------------------------------------------------------


def _non_dominated_sort(F: np.ndarray) -> list[list[int]]:
    """Return the indices grouped by Pareto rank.

    Deb 2002 fast non-dominated sort: O(M·N²).
    """

    n = F.shape[0]
    S: list[list[int]] = [[] for _ in range(n)]
    n_dom = np.zeros(n, dtype=int)
    fronts: list[list[int]] = [[]]
    for p in range(n):
        for q in range(n):
            if p == q:
                continue
            # Does p dominate q?
            le = F[p] <= F[q]
            lt = F[p] < F[q]
            if np.all(le) and np.any(lt):
                S[p].append(q)
            elif np.all(F[q] <= F[p]) and np.any(F[q] < F[p]):
                n_dom[p] += 1
        if n_dom[p] == 0:
            fronts[0].append(p)
    i = 0
    while fronts[i]:
        nxt: list[int] = []
        for p in fronts[i]:
            for q in S[p]:
                n_dom[q] -= 1
                if n_dom[q] == 0:
                    nxt.append(q)
        i += 1
        fronts.append(nxt)
    return fronts[:-1]  # drop empty last


def _crowding_distance(F: np.ndarray, front_idx: list[int]) -> np.ndarray:
    """Compute crowding distance for indices in ``front_idx``.

    Deb 2002 crowding distance: infinity for boundary points; sum of
    normalised neighbour distances elsewhere.
    """

    k = len(front_idx)
    if k <= 2:
        return np.full(k, np.inf)
    dists = np.zeros(k, dtype=float)
    for m in range(F.shape[1]):
        order = np.argsort(F[front_idx, m])
        dists[order[0]] = np.inf
        dists[order[-1]] = np.inf
        fmin = F[front_idx[order[0]], m]
        fmax = F[front_idx[order[-1]], m]
        denom = max(fmax - fmin, 1e-12)
        for j in range(1, k - 1):
            dists[order[j]] += (
                F[front_idx[order[j + 1]], m] - F[front_idx[order[j - 1]], m]
            ) / denom
    return dists


def _tournament_select(rank: np.ndarray, dist: np.ndarray,
                       rng: np.random.Generator) -> int:
    """Binary tournament: pick the lower-rank or, on tie, higher-distance."""

    a, b = rng.integers(0, len(rank), size=2)
    if rank[a] < rank[b]:
        return int(a)
    if rank[b] < rank[a]:
        return int(b)
    return int(a) if dist[a] > dist[b] else int(b)


def _sbx_crossover(p1: np.ndarray, p2: np.ndarray,
                   bounds: np.ndarray, eta_c: float,
                   rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    """Simulated Binary Crossover (Deb-Agrawal 1995)."""

    d = len(p1)
    c1 = p1.copy()
    c2 = p2.copy()
    for i in range(d):
        if rng.random() < 0.5:
            u = rng.random()
            if u < 0.5:
                beta = (2.0 * u) ** (1.0 / (eta_c + 1.0))
            else:
                beta = (1.0 / (2.0 * (1.0 - u))) ** (1.0 / (eta_c + 1.0))
            c1[i] = 0.5 * ((1 + beta) * p1[i] + (1 - beta) * p2[i])
            c2[i] = 0.5 * ((1 - beta) * p1[i] + (1 + beta) * p2[i])
    return np.clip(c1, bounds[:, 0], bounds[:, 1]), np.clip(c2, bounds[:, 0], bounds[:, 1])


def _polynomial_mutation(x: np.ndarray, bounds: np.ndarray,
                         eta_m: float, p_m: float,
                         rng: np.random.Generator) -> np.ndarray:
    """Polynomial mutation (Deb-Goyal 1996)."""

    d = len(x)
    out = x.copy()
    for i in range(d):
        if rng.random() < p_m:
            u = rng.random()
            if u < 0.5:
                delta = (2.0 * u) ** (1.0 / (eta_m + 1.0)) - 1.0
            else:
                delta = 1.0 - (2.0 * (1.0 - u)) ** (1.0 / (eta_m + 1.0))
            span = bounds[i, 1] - bounds[i, 0]
            out[i] = out[i] + delta * span
    return np.clip(out, bounds[:, 0], bounds[:, 1])


def _hypervolume(F: np.ndarray, ref: np.ndarray) -> float:
    """Hypervolume of a 2-D or 3-D Pareto front w.r.t. ``ref`` (minimisation).

    Uses the classical "slicing" approach in 2-D and Monte-Carlo
    sampling in ≥3-D. Sufficient for the diagnostic-only role we use
    it for here.
    """

    if F.shape[0] == 0:
        return 0.0
    if F.shape[1] == 1:
        return float(max(0.0, ref[0] - F[:, 0].min()))
    if F.shape[1] == 2:
        # Sort by f0 ascending; iterate to compute area.
        order = np.argsort(F[:, 0])
        sorted_F = F[order]
        hv = 0.0
        prev_f1 = ref[1]
        for f in sorted_F:
            if f[0] >= ref[0] or f[1] >= ref[1]:
                continue
            hv += (ref[0] - f[0]) * (prev_f1 - f[1])
            prev_f1 = f[1]
        return float(hv)
    # ≥3-D: cheap Monte-Carlo (acceptable for diagnostic reporting)
    rng = np.random.default_rng(7)
    lo = F.min(axis=0)
    hi = ref
    samples = rng.uniform(lo, hi, size=(20000, F.shape[1]))
    dominated = np.zeros(samples.shape[0], dtype=bool)
    for f in F:
        dominated |= np.all(samples >= f, axis=1)
    return float(np.mean(dominated) * np.prod(hi - lo))


def _igd(F_polished: np.ndarray, F_reference: np.ndarray) -> float:
    """Inverted Generational Distance (Sierra-Coello 2005)."""

    if F_polished.shape[0] == 0 or F_reference.shape[0] == 0:
        return float("inf")
    dists = []
    for r in F_reference:
        d2 = np.sum((F_polished - r) ** 2, axis=1)
        dists.append(np.sqrt(d2.min()))
    return float(np.mean(dists))


# ---------------------------------------------------------------------------
# Hybrid driver
# ---------------------------------------------------------------------------


def _eval_population(pop: np.ndarray,
                     objective_fn: Callable[[np.ndarray], np.ndarray],
                     ) -> np.ndarray:
    """Vectorised objective evaluation (one row → one (M,) vector)."""

    out = []
    for x in pop:
        f = np.asarray(objective_fn(x), dtype=float).reshape(-1)
        out.append(f)
    return np.stack(out)


def _polish_candidate(x0: np.ndarray,
                      objective_fn: Callable[[np.ndarray], np.ndarray],
                      bounds: np.ndarray,
                      polish_iter: int,
                      scalarise: Callable[[np.ndarray], float],
                      ) -> tuple[np.ndarray, np.ndarray]:
    """Polish one Pareto-front candidate with L-BFGS using scalarisation.

    The scalarisation collapses ``F(x) -> scalar`` so JAX can take a
    gradient. After the polish we re-evaluate to get the polished
    multi-objective ``F`` vector. We use a simple weighted sum where
    each weight is 1/M — Lukas-Mukherjee 2002 showed that this is
    sufficient for local Pareto refinement.
    """

    try:
        import jaxopt  # type: ignore[import-not-found]
    except ImportError:  # pragma: no cover
        return x0, np.asarray(objective_fn(x0), dtype=float).reshape(-1)

    x_jnp = jnp.asarray(x0, dtype=jnp.float32)

    def f_scalar(x):
        f = objective_fn(np.asarray(x))
        return float(scalarise(np.asarray(f, dtype=float)))

    # We can't autograd through a numpy callback. Use a finite-diff polish.
    lr = 1e-3
    for _ in range(polish_iter):
        f0 = f_scalar(x_jnp)
        grad = np.zeros(x_jnp.shape, dtype=np.float64)
        eps = 1e-4
        for i in range(x_jnp.shape[0]):
            x_pert = np.array(x_jnp)
            x_pert[i] += eps
            f1 = f_scalar(jnp.asarray(x_pert, dtype=jnp.float32))
            grad[i] = (f1 - f0) / eps
        step = x_jnp - lr * grad.astype(np.float32)
        step = jnp.clip(step, jnp.asarray(bounds[:, 0], dtype=jnp.float32),
                        jnp.asarray(bounds[:, 1], dtype=jnp.float32))
        f_new = f_scalar(step)
        if f_new > f0:
            lr *= 0.5
            if lr < 1e-12:
                break
            continue
        x_jnp = step

    x_out = np.asarray(x_jnp, dtype=float)
    return x_out, np.asarray(objective_fn(x_out), dtype=float).reshape(-1)


def design_hybrid(
    objective_fn: Callable[[np.ndarray], np.ndarray],
    *,
    bounds: Sequence[tuple[float, float]],
    constraints_fn: Optional[Callable[[np.ndarray], float]] = None,
    n_population: int = 80,
    n_generations: int = 20,
    polish_iter: int = 30,
    eta_c: float = 20.0,
    eta_m: float = 20.0,
    p_m: Optional[float] = None,
    seed: int = 0,
) -> HybridDesignResult:
    """Hybrid NSGA-II + L-BFGS multi-objective design optimisation.

    The pipeline:

    1. **Global search** — NSGA-II runs ``n_generations`` generations on
       a population of ``n_population`` individuals. Pure numpy, so
       non-differentiable constraints are fine.
    2. **Local polish** — for every member of the final Pareto front,
       run ``polish_iter`` steps of gradient descent (finite-diff
       across the objective; fully JAX-compatible if ``objective_fn``
       is a JAX-traced function).
    3. **Diagnostics** — hypervolume against ref-point and IGD against
       the unpolished Pareto front are reported in the result.

    Args:
        objective_fn: callable ``x -> (M,) vector`` returning all M
            objective values to minimise.
        bounds: per-dimension ``(lo, hi)`` box.
        constraints_fn: optional callable returning a non-negative
            penalty when ``x`` is infeasible. Added to every objective
            with a large weight.
        n_population: NSGA-II population size.
        n_generations: NSGA-II generations.
        polish_iter: L-BFGS steps per Pareto-front candidate.
        eta_c, eta_m, p_m: SBX / polynomial mutation hyperparameters.
        seed: RNG seed for reproducibility.

    Returns:
        :class:`HybridDesignResult` with polished ``pareto_front_x``,
        ``pareto_front_f``, ``hypervolume``, ``igd``, evaluation counts.
    """

    bounds_arr = np.asarray(bounds, dtype=float)
    d = bounds_arr.shape[0]
    if p_m is None:
        p_m = 1.0 / d
    rng = np.random.default_rng(seed)

    # Initialise random population uniformly inside the box.
    pop = rng.uniform(bounds_arr[:, 0], bounds_arr[:, 1], size=(n_population, d))

    penalty_weight = 1.0e6

    def wrapped(x):
        f = np.asarray(objective_fn(x), dtype=float).reshape(-1)
        if constraints_fn is not None:
            f = f + penalty_weight * max(0.0, float(constraints_fn(x)))
        return f

    F = _eval_population(pop, wrapped)
    n_eval = n_population
    history: list[dict] = []

    for gen in range(n_generations):
        # Non-dominated sort + crowding
        fronts = _non_dominated_sort(F)
        rank = np.empty(n_population, dtype=int)
        for r, front in enumerate(fronts):
            for i in front:
                rank[i] = r
        dist = np.zeros(n_population, dtype=float)
        for front in fronts:
            dd = _crowding_distance(F, front)
            for k, idx in enumerate(front):
                dist[idx] = dd[k]

        # Tournament selection + SBX + mutation → offspring
        offspring = np.zeros_like(pop)
        for i in range(0, n_population, 2):
            p1 = _tournament_select(rank, dist, rng)
            p2 = _tournament_select(rank, dist, rng)
            c1, c2 = _sbx_crossover(pop[p1], pop[p2], bounds_arr, eta_c, rng)
            c1 = _polynomial_mutation(c1, bounds_arr, eta_m, p_m, rng)
            c2 = _polynomial_mutation(c2, bounds_arr, eta_m, p_m, rng)
            offspring[i] = c1
            if i + 1 < n_population:
                offspring[i + 1] = c2

        F_off = _eval_population(offspring, wrapped)
        n_eval += offspring.shape[0]

        # Elitist combine
        combined_x = np.vstack([pop, offspring])
        combined_f = np.vstack([F, F_off])
        fronts = _non_dominated_sort(combined_f)
        new_pop_idx: list[int] = []
        for front in fronts:
            if len(new_pop_idx) + len(front) <= n_population:
                new_pop_idx.extend(front)
            else:
                # Crowding-distance truncation of last front
                dd = _crowding_distance(combined_f, front)
                order = np.argsort(-dd)
                need = n_population - len(new_pop_idx)
                for j in order[:need]:
                    new_pop_idx.append(front[j])
                break
        new_pop_idx = new_pop_idx[:n_population]
        pop = combined_x[new_pop_idx]
        F = combined_f[new_pop_idx]
        history.append({"gen": gen, "front_size": len(fronts[0])})

    # Final Pareto front
    final_fronts = _non_dominated_sort(F)
    front0_idx = final_fronts[0]
    F_unpolished = F[front0_idx].copy()
    X_unpolished = pop[front0_idx].copy()

    # Polish each member
    polished_x = np.empty_like(X_unpolished)
    polished_f = np.empty_like(F_unpolished)
    polished_any = False
    if polish_iter > 0:
        for i, x0 in enumerate(X_unpolished):
            # Weighted-sum scalarisation
            scalarise = lambda f: float(np.sum(f))
            xp, fp = _polish_candidate(
                x0, wrapped, bounds_arr, polish_iter, scalarise
            )
            polished_x[i] = xp
            polished_f[i] = fp
            n_eval += polish_iter * (d + 1)
            polished_any = True
    else:
        polished_x = X_unpolished
        polished_f = F_unpolished

    # Diagnostics
    ref = polished_f.max(axis=0) + 0.1 * (polished_f.max(axis=0) - polished_f.min(axis=0) + 1e-9)
    hv = _hypervolume(polished_f, ref)
    igd_val = _igd(polished_f, F_unpolished)

    return HybridDesignResult(
        pareto_front_x=polished_x,
        pareto_front_f=polished_f,
        hypervolume=hv,
        igd=igd_val,
        n_evaluations=n_eval,
        n_generations=n_generations,
        polish_iter=polish_iter,
        polished=polished_any,
        history=history,
    )


# ---------------------------------------------------------------------------
# Friendly facade — composition_bounds dict + objective keyword
# ---------------------------------------------------------------------------


# Standard preset objectives used by au.design(...). They consume a
# *design vector* and return a vector / scalar of objectives. We rely on
# the JAX backend's design-path chain for the underlying physics.

def _objective_max_KIc_sigma_y_per_density(x: np.ndarray) -> np.ndarray:
    """``[ -(KIc · σ_y / ρ) ]`` (we minimise the negative for "maximise").

    ``x`` is a 5-vector ``[C, Mn, Cr, Mo, density_g_cc]``. Designed to be
    callable from inside NSGA-II without importing the full design path
    chain — it uses an analytical surrogate so the optimiser stays fast.
    """

    from ._core import maynier_hv30, pavlina_tyne_sigma_y, cvn_from_hv, barsom_rolfe_KIc

    comp = jnp.array([x[0], x[1], x[2], x[3], 0.0, 0.0, 0.0], dtype=jnp.float32)
    hv = maynier_hv30(comp, jnp.float32(10.0))
    sigma_y = float(pavlina_tyne_sigma_y(hv))
    cvn = cvn_from_hv(hv)
    KIc = float(barsom_rolfe_KIc(cvn))
    density = float(x[4]) if x.shape[0] > 4 else 7.85
    return np.array([-(KIc * sigma_y / density)], dtype=float)


def design(
    *,
    objective: str = "maximize_KIc_sigma_y_per_density",
    constraints: Optional[Mapping[str, Any]] = None,
    composition_bounds: Mapping[str, tuple[float, float]],
    method: str = "hybrid",
    n_population: int = 80,
    n_generations: int = 20,
    polish_iter: int = 30,
    seed: int = 0,
) -> HybridDesignResult:
    """High-level inverse-design facade.

    Args:
        objective: Named objective. Currently ``"maximize_KIc_sigma_y_per_density"``
            is shipped; users can pass any callable via :func:`design_hybrid`.
        constraints: dict of constraint specs (e.g. ``{"density": (None, 8.0)}``).
        composition_bounds: dict ``{"C": (0.2, 0.6), "Mn": (0.3, 1.5), ...}``.
        method: ``"hybrid"`` (NSGA-II + L-BFGS polish), default.
        n_population, n_generations, polish_iter: NSGA-II / polish controls.

    Returns:
        :class:`HybridDesignResult` with the polished Pareto front.

    Example::

        from austenite.jax_backend._optimizers import design
        r = design(
            objective="maximize_KIc_sigma_y_per_density",
            constraints={"density": (None, 8.0)},
            composition_bounds={"C": (0.2, 0.6), "Mn": (0.3, 1.5),
                                "Cr": (0.0, 2.0), "Mo": (0.0, 0.5)},
            n_population=40, n_generations=10, polish_iter=10,
        )
        print(r.pareto_front_x.shape)
        print(r.hypervolume)
    """

    if method != "hybrid":
        raise ValueError(
            f"unknown method {method!r}; expected 'hybrid'"
        )

    if objective != "maximize_KIc_sigma_y_per_density":
        raise ValueError(
            f"unknown objective {objective!r}; expected "
            "'maximize_KIc_sigma_y_per_density' or pass a callable to design_hybrid"
        )

    # Build bounds list in canonical order: C, Mn, Cr, Mo, then density.
    canon = ["C", "Mn", "Cr", "Mo"]
    bounds_list = []
    for el in canon:
        if el not in composition_bounds:
            raise ValueError(f"missing bound for {el!r}")
        bounds_list.append(tuple(composition_bounds[el]))
    # Density default range 7.0 – 8.5
    if "density" in composition_bounds:
        bounds_list.append(tuple(composition_bounds["density"]))
    else:
        bounds_list.append((7.0, 8.5))

    # Constraints function — soft hinge on dollar/kg and density
    def constraints_fn(x):
        viol = 0.0
        if constraints:
            dkg = constraints.get("$/kg")
            if dkg is not None:
                lo, hi = dkg
                # Cheap surrogate: cost ~ 1 + 5*Cr + 10*Mo + 2*Mn
                cost = 1.0 + 5.0 * x[2] + 10.0 * x[3] + 2.0 * x[1]
                if hi is not None and cost > hi:
                    viol += cost - hi
                if lo is not None and cost < lo:
                    viol += lo - cost
            d = constraints.get("density")
            if d is not None:
                lo, hi = d
                if hi is not None and x[4] > hi:
                    viol += x[4] - hi
                if lo is not None and x[4] < lo:
                    viol += lo - x[4]
        return viol

    return design_hybrid(
        objective_fn=_objective_max_KIc_sigma_y_per_density,
        bounds=bounds_list,
        constraints_fn=constraints_fn,
        n_population=n_population,
        n_generations=n_generations,
        polish_iter=polish_iter,
        seed=seed,
    )


__all__ = [
    "design_jax",
    "DesignJaxResult",
    "HybridDesignResult",
    "design_hybrid",
    "design",
]
