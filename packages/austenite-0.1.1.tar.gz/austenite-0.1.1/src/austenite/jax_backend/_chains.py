"""End-to-end differentiable chains.

The orchestrator :func:`design_path_jax` glues the five
:mod:`._core` engines into the
composition -> HV -> strength -> KIc -> fatigue pipeline and returns a
JAX pytree (NamedTuple) so the result round-trips through ``jax.grad``,
``jax.jit``, and ``jax.vmap``.

A second orchestrator :func:`am_qualification_jax` reuses the same
chain with a process-window scalar so it can be ``vmap``-ed over a
laser-power / scan-speed grid.

A Javanshir Hasanov production.
"""

from __future__ import annotations

from typing import NamedTuple

import jax
import jax.numpy as jnp

from ._core import (
    barsom_rolfe_KIc,
    basquin_life,
    cvn_from_hv,
    endurance_from_uts,
    goodman_utilisation,
    maynier_hv30,
    pavlina_tyne_sigma_y,
    sigma_uts_from_hv,
)


# ---------------------------------------------------------------------------
# Pytree result types -- NamedTuple registered automatically as a pytree.
# ---------------------------------------------------------------------------


class FatigueResult(NamedTuple):
    """Pytree of fatigue outputs.

    Fields are JAX arrays (scalars unless inputs are batched).
    """

    utilisation_pct: jnp.ndarray  # Goodman utilisation in percent
    Nf_cycles: jnp.ndarray  # Basquin cycles to failure


class DesignPathJaxResult(NamedTuple):
    """Pytree of the full design-path chain.

    Every field is a JAX array. Because this is a NamedTuple it is a
    valid JAX pytree and works under :func:`jax.grad`, :func:`jax.jit`,
    and :func:`jax.vmap`.
    """

    hv30: jnp.ndarray
    sigma_y_MPa: jnp.ndarray
    sigma_uts_MPa: jnp.ndarray
    KIc_MPa_sqm: jnp.ndarray
    sigma_endurance_MPa: jnp.ndarray
    fatigue: FatigueResult


# ---------------------------------------------------------------------------
# design_path_jax
# ---------------------------------------------------------------------------


@jax.jit
def design_path_jax(
    composition_vec: jnp.ndarray,
    cooling_rate: jnp.ndarray = jnp.asarray(10.0, dtype=jnp.float32),
    sigma_app_MPa: jnp.ndarray = jnp.asarray(500.0, dtype=jnp.float32),
    sigma_mean_MPa: jnp.ndarray = jnp.asarray(0.0, dtype=jnp.float32),
) -> DesignPathJaxResult:
    """End-to-end differentiable design path: chemistry -> fatigue.

    Args:
        composition_vec: JAX array of weight percentages, ordered as
            ``[C, Mn, Cr, Mo, Ni, Si, V]``. Shorter vectors are
            zero-padded by :func:`._core._pad_composition`.
        cooling_rate: Cooling rate at 700 C, deg C / s. Drives
            Maynier-Dollet HV30.
        sigma_app_MPa: Applied stress amplitude for the Goodman check.
        sigma_mean_MPa: Mean stress for the Goodman check. Defaults to
            zero (fully-reversed loading, R = -1).

    Returns:
        :class:`DesignPathJaxResult` -- a pytree with every stage's
        scalar output. Pass it through ``jax.grad`` to get gradients
        with respect to ``composition_vec``.

    Example:
        >>> import jax
        >>> import jax.numpy as jnp
        >>> import austenite.jax_backend as ajx
        >>>
        >>> def obj(c):
        ...     return ajx.design_path_jax(c).fatigue.utilisation_pct
        >>>
        >>> g = jax.grad(obj)(jnp.array([0.40, 0.85, 0.95, 0.20, 0.0]))
    """

    comp = jnp.asarray(composition_vec, dtype=jnp.float32)
    Vc = jnp.asarray(cooling_rate, dtype=jnp.float32)
    sa = jnp.asarray(sigma_app_MPa, dtype=jnp.float32)
    sm = jnp.asarray(sigma_mean_MPa, dtype=jnp.float32)

    # ── Stage 1: Maynier-Dollet HV30 ────────────────────────────────
    hv = maynier_hv30(comp, Vc)

    # ── Stage 2: Pavlina-Tyne sigma_y / sigma_uts ───────────────────
    sigma_y = pavlina_tyne_sigma_y(hv)
    sigma_uts = sigma_uts_from_hv(hv)

    # ── Stage 3: Barsom-Rolfe KIc ───────────────────────────────────
    cvn = cvn_from_hv(hv)
    KIc = barsom_rolfe_KIc(cvn)

    # ── Stage 4: endurance + Goodman ────────────────────────────────
    sigma_e = endurance_from_uts(sigma_uts)
    util = goodman_utilisation(sa, sm, sigma_e, sigma_uts)
    util_pct = util * 100.0

    # ── Stage 5: Basquin life ───────────────────────────────────────
    Nf = basquin_life(sa, sigma_uts)

    return DesignPathJaxResult(
        hv30=hv,
        sigma_y_MPa=sigma_y,
        sigma_uts_MPa=sigma_uts,
        KIc_MPa_sqm=KIc,
        sigma_endurance_MPa=sigma_e,
        fatigue=FatigueResult(utilisation_pct=util_pct, Nf_cycles=Nf),
    )


# ---------------------------------------------------------------------------
# am_qualification_jax
# ---------------------------------------------------------------------------


@jax.jit
def am_qualification_jax(
    composition_vec: jnp.ndarray,
    laser_power_W: jnp.ndarray,
    scan_speed_mm_s: jnp.ndarray,
    hatch_um: jnp.ndarray = jnp.asarray(120.0, dtype=jnp.float32),
    layer_um: jnp.ndarray = jnp.asarray(60.0, dtype=jnp.float32),
    sigma_app_MPa: jnp.ndarray = jnp.asarray(500.0, dtype=jnp.float32),
) -> DesignPathJaxResult:
    """Differentiable AM-process qualification chain.

    Converts ``(laser_power, scan_speed, hatch, layer)`` into a
    volumetric-energy-density-driven cooling rate, then runs the same
    Maynier-Dollet -> Pavlina-Tyne -> Barsom-Rolfe -> Goodman chain.

    The mapping is intentionally a smooth surrogate, not a full melt-
    pool simulation -- the goal here is a differentiable
    process-window check for gradient-based DoE optimisation.

    .. math::
        VED = \\frac{P}{v \\cdot h \\cdot \\ell}  \\;\\; [J/mm^3]

        \\dot{T} \\approx 10^{6} \\cdot \\exp(-VED / 80)  \\;\\;
            [\\degree C/s]

    The exponential is a fit to LPBF cooling-rate data (Bertoli et al.
    2017, Mater. Today 19, 12). VED ~ 70 J/mm^3 -> ~3e5 K/s; VED ~ 30
    -> ~7e5 K/s; the rate is bounded above 1e6 K/s by the keyhole
    transition.

    Returns the same :class:`DesignPathJaxResult` pytree as
    :func:`design_path_jax` so downstream optimisers can chain them.
    """

    P = jnp.asarray(laser_power_W, dtype=jnp.float32)
    v = jnp.maximum(jnp.asarray(scan_speed_mm_s, dtype=jnp.float32), 1.0)
    h = jnp.maximum(jnp.asarray(hatch_um, dtype=jnp.float32), 1.0) / 1000.0  # mm
    ell = jnp.maximum(jnp.asarray(layer_um, dtype=jnp.float32), 1.0) / 1000.0  # mm

    ved = P / (v * h * ell)  # J/mm^3
    cooling_rate = jnp.clip(1.0e6 * jnp.exp(-ved / 80.0), 1.0, 1.0e7)

    return design_path_jax(
        composition_vec=composition_vec,
        cooling_rate=cooling_rate,
        sigma_app_MPa=sigma_app_MPa,
        sigma_mean_MPa=jnp.asarray(0.0, dtype=jnp.float32),
    )


__all__ = [
    "DesignPathJaxResult",
    "FatigueResult",
    "design_path_jax",
    "am_qualification_jax",
]
