"""Thermophysical + electrical + magnetic properties as functions of T and composition.

Used in EV, transformer, motor, heat-exchanger, solenoid, conductor design.
Wraps the canonical empirical correlations engineers need but never find
together in one library.

* **Bloch-Grüneisen** electrical resistivity ρ(T).
* **Matthiessen rule** for solute scattering.
* **Wiedemann-Franz** thermal conductivity from electrical.
* **Neumann-Kopp** specific-heat compositional weighting.
* **CTE rule of mixtures + Neumann-Kopp T expansion.**
* **Kersten-Néel** hysteresis-loss model for soft magnets.
* **Stoner-Wohlfarth** uniaxial coherent rotation for permanent magnets.
* **Curie-Weiss** susceptibility vs T.

References:
    * Bloch F., Z. Phys. 59 (1930) 208.
    * Grüneisen E., Ann. Phys. 408 (1933) 530.
    * Matthiessen A., Pogg. Ann. Phys. 110 (1860) 190.
    * Wiedemann G., Franz R., Ann. Phys. 89 (1853) 497.
    * Neumann F., Pogg. Ann. Phys. 23 (1831) 32.
    * Kopp H., Pogg. Ann. Phys. 38 (1865) 109.
    * Kersten M., Z. tech. Physik 19 (1938) 561; Néel L., Cahiers Phys. 25 (1944) 21.
    * Stoner E.C., Wohlfarth E.P., Phil. Trans. R. Soc. A 240 (1948) 599.
    * Curie P., Ann. Chim. Phys. 5 (1895) 289; Weiss P., J. Phys. Theor. Appl. 6 (1907) 661.
"""

from __future__ import annotations

import math
from typing import Mapping


# ---------------------------------------------------------------------------
# 1. ELECTRICAL RESISTIVITY — Bloch-Grüneisen + Matthiessen
# ---------------------------------------------------------------------------


def _bloch_gruneisen_integral(y: float, n_steps: int = 200) -> float:
    """J(y) = ∫_0^y x^5 · e^x / (e^x − 1)²  dx, by composite Simpson.

    Equivalent to ∫_0^y x^5 / ((e^x−1)(1−e^{−x})) dx. The integrand → x³ as
    x → 0 (numerically stable) and → 124.4 as y → ∞ (the full Debye integral).
    """

    if y <= 0:
        return 0.0
    n = n_steps if n_steps % 2 == 0 else n_steps + 1
    h = y / n

    def f(x: float) -> float:
        if x < 1e-6:
            return x ** 3  # small-x limit of x^5 e^x/(e^x-1)^2
        ex = math.exp(x)
        return x ** 5 * ex / (ex - 1.0) ** 2

    total = f(0.0) + f(y)
    for i in range(1, n):
        total += (4.0 if i % 2 else 2.0) * f(i * h)
    return total * h / 3.0


def bloch_gruneisen_resistivity(
    T_K: float, *, rho_residual_uohm_cm: float, theta_D_K: float, A_uohm_cm: float,
) -> float:
    """Bloch-Grüneisen 1930 electrical resistivity:

    ρ(T) = ρ_residual + 4·A · (T/Θ_D)^5 · ∫_0^{Θ_D/T} x^5/((e^x−1)(1−e^{−x})) dx

    The Debye integral is evaluated numerically with the correct upper limit
    Θ_D/T, so the curve is continuous across T = Θ_D. The normalisation (4·A)
    gives the two textbook limits:

    * T >> Θ_D: integral → ¼·(Θ_D/T)^4, so ρ → ρ_residual + A·(T/Θ_D).
    * T << Θ_D: integral → 124.4, so ρ − ρ_residual ∝ T^5.

    Typical metals: A ≈ 10 μΩ·cm; Θ_D ≈ 400-500 K. Returns ρ in μΩ·cm.
    """
    if not all(_is_finite(x) for x in [T_K, rho_residual_uohm_cm, theta_D_K, A_uohm_cm]):
        return float("nan")
    if theta_D_K <= 0 or T_K <= 0:
        return float("nan")
    ratio = float(T_K) / float(theta_D_K)
    J = _bloch_gruneisen_integral(1.0 / ratio)
    return float(rho_residual_uohm_cm) + 4.0 * float(A_uohm_cm) * (ratio ** 5) * J


def matthiessen_resistivity(
    rho_pure_uohm_cm: float, composition_wt_pct: Mapping[str, float],
    *, resistivity_coefficients_uohm_cm_per_wt_pct: Mapping[str, float],
) -> float:
    """Matthiessen 1860 rule for dilute solutions:

    ρ_alloy = ρ_pure + Σ_i c_i · k_i

    where k_i is the solute-specific resistivity coefficient (μΩ·cm per wt%).

    Typical k values for Cu host:
    * Cu host: Ni +1.13, Mn +2.85, Sn +2.84, Zn +0.30, Fe +9.50
    * Al host: Mg +0.54, Si +1.02, Mn +2.94, Zn +0.094, Cu +0.30

    Reference: Matthiessen A., Pogg. Ann. Phys. 110 (1860) 190.
    """
    if not _is_finite(rho_pure_uohm_cm):
        return float("nan")
    total = float(rho_pure_uohm_cm)
    for el, wt in composition_wt_pct.items():
        if not _is_finite(wt) or wt <= 0:
            continue
        k = resistivity_coefficients_uohm_cm_per_wt_pct.get(el, 0.0)
        if _is_finite(k):
            total += float(wt) * float(k)
    return total


MATTHIESSEN_COEFFICIENTS: dict[str, dict[str, float]] = {
    "Cu": {
        "Ni": 1.13, "Mn": 2.85, "Sn": 2.84, "Zn": 0.30, "Fe": 9.50,
        "Si": 7.05, "Be": 7.04, "Al": 1.96,
    },
    "Al": {
        "Mg": 0.54, "Si": 1.02, "Mn": 2.94, "Zn": 0.094, "Cu": 0.30,
        "Fe": 2.56, "Cr": 4.0, "Ti": 2.88,
    },
    "Fe": {
        "C": 5.0, "Si": 0.20, "Mn": 0.05, "Ni": 0.043, "Cr": 0.024,
        "Mo": 0.058, "P": 13.5, "Al": 0.39,
    },
    "Ni": {
        "Cr": 0.85, "Mo": 1.10, "Fe": 0.27, "Mn": 1.0, "Co": 0.16,
        "Si": 1.4, "Cu": 0.46,
    },
}


# ---------------------------------------------------------------------------
# 2. WIEDEMANN-FRANZ THERMAL CONDUCTIVITY
# ---------------------------------------------------------------------------


def wiedemann_franz_thermal_conductivity(
    rho_electrical_uohm_cm: float, T_K: float,
    *, lorenz_number_L: float = 2.44e-8,
) -> float:
    """Wiedemann-Franz law: ``k_thermal = L · T / ρ_electrical``.

    Lorenz number L₀ = π²/3 · (k_B/e)² = 2.44 × 10⁻⁸ W·Ω/K² (Sommerfeld 1928).
    Actual L is 2.20-2.50 × 10⁻⁸ for most metals at RT.

    Returns k in W/(m·K).
    """
    if not all(_is_finite(x) for x in [rho_electrical_uohm_cm, T_K]):
        return float("nan")
    if rho_electrical_uohm_cm <= 0 or T_K <= 0:
        return float("nan")
    rho_ohm_m = float(rho_electrical_uohm_cm) * 1e-8  # μΩ·cm → Ω·m
    return float(lorenz_number_L) * float(T_K) / rho_ohm_m


# ---------------------------------------------------------------------------
# 3. SPECIFIC HEAT — Neumann-Kopp
# ---------------------------------------------------------------------------


def neumann_kopp_specific_heat(
    composition_wt_pct: Mapping[str, float],
    *, Cp_pure_J_kgK: Mapping[str, float],
) -> float:
    """Neumann-Kopp 1865 mass-weighted specific heat:

    Cp_alloy = Σ x_i · Cp_i

    Returns Cp in J/(kg·K).
    """
    total_wt = sum(v for v in composition_wt_pct.values() if isinstance(v, (int, float)) and v > 0)
    if total_wt <= 0:
        return float("nan")
    cp_total = 0.0
    for el, wt in composition_wt_pct.items():
        if not _is_finite(wt) or wt <= 0:
            continue
        cp_i = Cp_pure_J_kgK.get(el)
        if cp_i is None or not _is_finite(cp_i):
            continue
        cp_total += float(wt) / total_wt * float(cp_i)
    return cp_total


# Pure-element Cp at 298 K, in J/(kg·K) (NIST WebBook)
CP_PURE_298K: dict[str, float] = {
    "Fe": 449, "Cr": 449, "Ni": 444, "Mn": 479, "Mo": 251, "C": 710,
    "Si": 712, "Cu": 385, "Al": 897, "Mg": 1020, "Ti": 523, "V": 489,
    "Zn": 388, "Sn": 228, "Pb": 129, "W": 132, "Ta": 140, "Nb": 265,
    "Co": 421, "Zr": 278, "Hf": 144, "Au": 129, "Ag": 235, "Pt": 133,
}


# ---------------------------------------------------------------------------
# 4. COEFFICIENT OF THERMAL EXPANSION
# ---------------------------------------------------------------------------


CTE_PURE_um_m_K: dict[str, float] = {
    # Linear CTE at 293 K, μm/m/K (NIST WebBook + ASM Vol 1)
    "Fe": 11.8, "Cr": 4.9, "Ni": 13.4, "Mn": 23.0, "Mo": 5.1, "Si": 2.6,
    "Cu": 16.5, "Al": 23.1, "Mg": 26.0, "Ti": 8.6, "V": 8.4,
    "Zn": 30.2, "Sn": 22.0, "Pb": 28.9, "W": 4.5, "Ta": 6.3, "Nb": 7.3,
    "Co": 13.0, "Zr": 5.7, "C": 7.1,
}


def cte_rule_of_mixtures(composition_wt_pct: Mapping[str, float]) -> float:
    """Mass-weighted CTE (rule of mixtures) in μm/m/K."""
    total_wt = sum(v for v in composition_wt_pct.values() if isinstance(v, (int, float)) and v > 0)
    if total_wt <= 0:
        return float("nan")
    cte_total = 0.0
    for el, wt in composition_wt_pct.items():
        cte_i = CTE_PURE_um_m_K.get(el)
        if cte_i is None or not _is_finite(wt) or wt <= 0:
            continue
        cte_total += float(wt) / total_wt * float(cte_i)
    return cte_total


# ---------------------------------------------------------------------------
# 5. MAGNETIC PROPERTIES
# ---------------------------------------------------------------------------


def curie_weiss_susceptibility(
    T_K: float, *, Curie_temperature_K: float, C_curie_constant: float = 1.0,
) -> float:
    """Curie-Weiss law above T_c: ``χ = C / (T − T_c)``.

    Returns volume susceptibility (dimensionless, SI). For Fe T_c ≈ 1043 K.

    Reference: Curie P., 1895; Weiss P., 1907.
    """
    if not all(_is_finite(x) for x in [T_K, Curie_temperature_K, C_curie_constant]):
        return float("nan")
    delta_T = float(T_K) - float(Curie_temperature_K)
    if abs(delta_T) < 1e-6:
        return float("inf")
    return float(C_curie_constant) / delta_T


def stoner_wohlfarth_switching_field(
    H_anisotropy_T: float, theta_deg: float,
) -> float:
    """Stoner-Wohlfarth 1948 coherent-rotation switching field.

    For a single-domain particle with uniaxial anisotropy:
        H_switch(θ) = H_K · (cos^(2/3)(θ) + sin^(2/3)(θ))^(-3/2)

    where θ is angle between applied field and easy axis. Maximum at θ=0
    (H_switch = H_K). Minimum at θ=45° (H_switch ≈ 0.5·H_K).

    Reference: Stoner-Wohlfarth 1948.
    """
    if not all(_is_finite(x) for x in [H_anisotropy_T, theta_deg]):
        return float("nan")
    theta_rad = math.radians(float(theta_deg))
    c = abs(math.cos(theta_rad)) ** (2.0 / 3.0)
    s = abs(math.sin(theta_rad)) ** (2.0 / 3.0)
    return float(H_anisotropy_T) * (c + s) ** (-1.5)


def kersten_hysteresis_loss(
    B_max_T: float, frequency_Hz: float, *,
    eta_hysteresis_J_kg_T2: float, n_steinmetz: float = 1.6,
) -> float:
    """Steinmetz / Kersten-Néel hysteresis loss per cycle:

    ``P_h = η · f · B_max^n``  (Steinmetz 1892 / Kersten 1938 calibration)

    Typical η for silicon-iron: ~30 J/(kg·T²); for ferrites: ~5 J/(kg·T²).
    Steinmetz exponent n ≈ 1.6-1.8 for most magnetic materials.

    Returns hysteresis power loss in W/kg.
    """
    if not all(_is_finite(x) for x in [B_max_T, frequency_Hz, eta_hysteresis_J_kg_T2, n_steinmetz]):
        return float("nan")
    if B_max_T < 0:
        return float("nan")
    return float(eta_hysteresis_J_kg_T2) * float(frequency_Hz) * (float(B_max_T) ** float(n_steinmetz))


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "bloch_gruneisen_resistivity", "matthiessen_resistivity",
    "MATTHIESSEN_COEFFICIENTS",
    "wiedemann_franz_thermal_conductivity",
    "neumann_kopp_specific_heat", "CP_PURE_298K",
    "cte_rule_of_mixtures", "CTE_PURE_um_m_K",
    "curie_weiss_susceptibility", "stoner_wohlfarth_switching_field",
    "kersten_hysteresis_loss",
]
