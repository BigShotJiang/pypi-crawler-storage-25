"""API 581 RBI scenario generator — optimal inspection planning.

Generates the next inspection plan that minimizes total expected cost
(inspection $ + risk $ from un-detected damage) given:

  * Vessel POF (probability of failure) curve
  * Damage mechanism (thinning, SCC, HTHA, brittle fracture)
  * Inspection cost & effectiveness (POD curve)
  * Consequence cost (fluid leak + business interruption)

Implements the API 581 Part 4 cost-of-risk minimization (Bahrami-O'Donoghue
2018, Kallen-van Noortwijk Bayesian RBI).

References:
    * API RP 581 3rd Ed. 2016 — Risk-Based Inspection.
    * Kallen M.-J., van Noortwijk J.M., Reliab. Eng. Sys. Saf. 90 (2005) 177.
    * Bahrami M., O'Donoghue P., Int. J. Press. Vessels Pip. 168 (2018) 92.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field


@dataclass
class DamageState:
    """Current damage state + uncertainty."""

    mechanism: str          # "thinning", "SCC", "HTHA", "fatigue"
    current_metric: float   # e.g. wall loss in mm, crack depth in mm
    rate_mean: float        # mean rate per year
    rate_sigma: float       # 1-sigma uncertainty on rate
    critical_metric: float  # failure threshold


@dataclass
class InspectionOption:
    """One candidate inspection technique."""

    method: str             # "VT", "UT", "RT", "AET", "PA-UT"
    cost_usd: float
    pod_at_critical: float  # P(detect) when damage is at critical level


@dataclass
class InspectionPlan:
    """Recommended next inspection plan."""

    when_years: float
    chosen_method: str
    expected_total_cost_usd: float
    expected_risk_usd: float
    inspection_cost_usd: float
    rationale: str
    notes: list = field(default_factory=list)


def pof_at_year(state: DamageState, t_years: float) -> float:
    """Closed-form POF assuming Normal-distributed cumulative damage at t.

    P(failure by t) = Φ((m_0 + ṁ·t − m_crit) / (σ_ṁ · t))
    """

    if t_years <= 0:
        return 0.0
    mu = state.current_metric + state.rate_mean * t_years
    sigma = max(1e-6, state.rate_sigma * t_years)
    z = (mu - state.critical_metric) / sigma
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2)))


def expected_risk_cost(
    state: DamageState, t_years: float, consequence_usd: float,
) -> float:
    """Expected risk cost = POF(t) · consequence_$."""

    return pof_at_year(state, t_years) * consequence_usd


def select_inspection_plan(
    state: DamageState,
    candidates: list[InspectionOption],
    *,
    consequence_usd: float,
    interval_candidates_years: tuple = (1.0, 2.0, 3.0, 5.0, 7.0, 10.0),
    target_pof: float = 1e-4,
) -> InspectionPlan:
    """Pick the (interval, method) pair that minimizes total expected cost.

    Total cost = inspection_$ + (1 − POD)·risk_$
    """

    best = None
    for t in interval_candidates_years:
        for opt in candidates:
            risk_no_inspect = expected_risk_cost(state, t, consequence_usd)
            residual_risk = (1.0 - opt.pod_at_critical) * risk_no_inspect
            total = opt.cost_usd + residual_risk
            if best is None or total < best[0]:
                best = (total, t, opt, risk_no_inspect, residual_risk)

    total, t, opt, risk_pre, risk_post = best
    pof_at_t = pof_at_year(state, t)
    notes = []
    if pof_at_t > target_pof:
        notes.append(
            f"POF at {t} y = {pof_at_t:.1e} > target {target_pof:.1e} — consider shorter interval",
        )
    if opt.pod_at_critical < 0.7:
        notes.append(f"POD={opt.pod_at_critical:.2f} low — consider PA-UT / AET")

    rationale = (
        f"Cost-minimum plan: {opt.method} every {t:.1f} y. "
        f"Inspection ${opt.cost_usd:,.0f} + residual risk ${risk_post:,.0f}"
    )
    return InspectionPlan(
        when_years=t, chosen_method=opt.method,
        expected_total_cost_usd=total, expected_risk_usd=risk_post,
        inspection_cost_usd=opt.cost_usd,
        rationale=rationale, notes=notes,
    )


def default_inspection_catalogue() -> list[InspectionOption]:
    """Stock catalogue (USD, typical onshore process plant 2025)."""

    return [
        InspectionOption("VT", 500.0, 0.20),
        InspectionOption("UT manual", 3000.0, 0.55),
        InspectionOption("AUT (auto UT)", 12000.0, 0.85),
        InspectionOption("PA-UT", 20000.0, 0.92),
        InspectionOption("RT", 15000.0, 0.80),
        InspectionOption("AET (continuous)", 50000.0, 0.95),
    ]


__all__ = [
    "DamageState", "InspectionOption", "InspectionPlan",
    "pof_at_year", "expected_risk_cost",
    "select_inspection_plan", "default_inspection_catalogue",
]
