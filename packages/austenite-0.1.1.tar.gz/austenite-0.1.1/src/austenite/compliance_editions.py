"""Code-edition diff tracker — moat 5.

Engineers pay consultants $5k/seat/year to keep up with API / ASME / ASTM /
NACE revision deltas. This module gives the answer away for free.

Two public operations::

    diff = au.compliance.diff_edition("API 579-1", "2021-12", "2024-09")
    # → DiffReport(spec=..., from_=..., to_=..., changes=[EditionChange, ...])

    report = au.compliance.recheck_edition(records=Q4_records, edition="2024-09")
    # → RecheckReport(still_pass=41, now_fail=4, changed_margin=6, details=[...])

The corpus lives in ``austenite/_editions/*.json`` — see that package's
docstring for the JSON schema. Add a new spec via PR; no code change is
required.

References:
  * API 579-1/ASME FFS-1, 2021 + 2024 Editions.
  * API 581 3rd Ed. (2016) + Addenda.
  * ASME BPVC Section II Part D, 2021 / 2023 / 2025.
  * NACE MR0175 / ISO 15156-2:2020 + Amd 1:2023.
  * ASTM A29/A29M-20a / -22 / -24.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import date
from importlib import resources
from typing import Any, Iterable, Literal, Mapping, Optional, Sequence

from ._client import get_default_client
from ._exceptions import ValidationError


ChangeKind = Literal["formula", "parameter", "method", "scope", "editorial"]
_VALID_KINDS: frozenset[str] = frozenset(
    {"formula", "parameter", "method", "scope", "editorial"}
)


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EditionChange:
    """One change item between editions of a spec.

    Attributes:
        section: Section / paragraph / table identifier inside the spec
            (e.g. ``"Part 5 Annex 5C"``).
        kind: One of ``formula`` | ``parameter`` | ``method`` |
            ``scope`` | ``editorial``.
        summary: Plain-English one-line summary of the change.
        primary_paper: Optional citation backing the change (DOI, paper
            title, or in-code reference).
    """

    section: str
    kind: ChangeKind
    summary: str
    primary_paper: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "section": self.section,
            "kind": self.kind,
            "summary": self.summary,
        }
        if self.primary_paper:
            out["primary_paper"] = self.primary_paper
        return out


@dataclass(frozen=True)
class DiffReport:
    """The diff between two editions of one spec.

    Attributes:
        spec: Canonical spec id, e.g. ``"API 579-1"``.
        from_: Earlier edition id (e.g. ``"2021-12"``).
        to_: Later edition id (e.g. ``"2024-09"``).
        changes: All edition changes that take effect strictly between
            ``from_`` (exclusive) and ``to_`` (inclusive). Ordered by
            edition published date then section.
        publisher: Publisher of the spec (``"American Petroleum Institute"`` etc.).
        title: Spec title.
    """

    spec: str
    from_: str
    to_: str
    changes: list[EditionChange] = field(default_factory=list)
    publisher: Optional[str] = None
    title: Optional[str] = None

    def __len__(self) -> int:
        return len(self.changes)

    def to_dict(self) -> dict[str, Any]:
        return {
            "spec": self.spec,
            "from": self.from_,
            "to": self.to_,
            "publisher": self.publisher,
            "title": self.title,
            "changes": [c.to_dict() for c in self.changes],
        }


@dataclass(frozen=True)
class RecheckDetail:
    """Per-record detail of a re-run under a new edition."""

    asset_id: str
    old_verdict: Optional[str]
    new_verdict: Optional[str]
    old_p_pass: Optional[float] = None
    new_p_pass: Optional[float] = None
    note: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "asset_id": self.asset_id,
            "old_verdict": self.old_verdict,
            "new_verdict": self.new_verdict,
            "old_p_pass": self.old_p_pass,
            "new_p_pass": self.new_p_pass,
            "note": self.note,
        }


@dataclass(frozen=True)
class RecheckReport:
    """Summary of a batch re-run under a new edition.

    Attributes:
        still_pass: # records that retained a PASS verdict.
        now_fail:   # records that went from PASS to FAIL or MARGINAL.
        changed_margin: # records that kept the verdict but moved the
            quantitative margin / p_pass by ≥1 % (i.e. would be flagged
            for a re-review even if the binary verdict is unchanged).
        details: full per-record breakdown.
        edition: edition id the batch was re-run under.
        spec: spec id used for the re-run.
    """

    still_pass: int
    now_fail: int
    changed_margin: int
    details: list[RecheckDetail] = field(default_factory=list)
    edition: Optional[str] = None
    spec: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "still_pass": self.still_pass,
            "now_fail": self.now_fail,
            "changed_margin": self.changed_margin,
            "edition": self.edition,
            "spec": self.spec,
            "details": [d.to_dict() for d in self.details],
        }


# ---------------------------------------------------------------------------
# Spec-id normalization & corpus loading
# ---------------------------------------------------------------------------


# Mapping from normalized spec ids to JSON file names.
_SPEC_FILES: dict[str, str] = {
    "API 579-1": "api_579_1.json",
    "API 581": "api_581.json",
    "ASME II-D": "asme_ii_d.json",
    "NACE MR0175": "nace_mr0175.json",
    "ASTM A29": "astm_a29.json",
}

# Looser aliases that map onto the canonical ids above. Keys are lower-cased
# strip-everything-but-alnum representations of common user inputs.
_SPEC_ALIASES: dict[str, str] = {
    "api5791": "API 579-1",
    "api579": "API 579-1",
    "api579ffs1": "API 579-1",
    "asmeffs1": "API 579-1",
    "api581": "API 581",
    "asmeiid": "ASME II-D",
    "asme2d": "ASME II-D",
    "bpvciid": "ASME II-D",
    "nacemr0175": "NACE MR0175",
    "iso15156": "NACE MR0175",
    "nacemr0175iso15156": "NACE MR0175",
    "astma29": "ASTM A29",
    "astma29a29m": "ASTM A29",
    "a29": "ASTM A29",
}


def _normalize_spec(spec: str) -> str:
    """Resolve a free-form spec id to the canonical one used by the corpus."""

    if spec in _SPEC_FILES:
        return spec
    # Try alnum/lower normalization
    key = "".join(ch.lower() for ch in spec if ch.isalnum())
    if key in _SPEC_ALIASES:
        return _SPEC_ALIASES[key]
    # Try exact case-insensitive
    for canonical in _SPEC_FILES:
        if canonical.lower() == spec.lower():
            return canonical
    raise ValidationError(
        f"Unknown spec '{spec}'. Known: {sorted(_SPEC_FILES.keys())}",
        status_code=400,
    )


def _load_corpus(spec: str) -> dict[str, Any]:
    """Load + validate the JSON corpus for one spec."""

    canonical = _normalize_spec(spec)
    filename = _SPEC_FILES[canonical]
    pkg = resources.files("austenite._editions")
    text = (pkg / filename).read_text(encoding="utf-8")
    data = json.loads(text)
    _validate_corpus_schema(data, source=filename)
    return data


def _validate_corpus_schema(data: Mapping[str, Any], *, source: str) -> None:
    """Validate the on-disk JSON schema. Raises ValueError on violation."""

    if not isinstance(data, Mapping):
        raise ValueError(f"{source}: top-level must be an object")
    for k in ("spec", "editions"):
        if k not in data:
            raise ValueError(f"{source}: missing required key '{k}'")
    editions = data["editions"]
    if not isinstance(editions, list) or not editions:
        raise ValueError(f"{source}: 'editions' must be a non-empty list")
    seen_ids: set[str] = set()
    for i, ed in enumerate(editions):
        if not isinstance(ed, Mapping):
            raise ValueError(f"{source}: editions[{i}] not an object")
        for k in ("id", "published", "changes"):
            if k not in ed:
                raise ValueError(f"{source}: editions[{i}] missing '{k}'")
        ed_id = ed["id"]
        if ed_id in seen_ids:
            raise ValueError(f"{source}: duplicate edition id '{ed_id}'")
        seen_ids.add(ed_id)
        if not isinstance(ed["changes"], list):
            raise ValueError(f"{source}: editions[{i}].changes must be a list")
        for j, ch in enumerate(ed["changes"]):
            if not isinstance(ch, Mapping):
                raise ValueError(f"{source}: editions[{i}].changes[{j}] not an object")
            for k in ("section", "kind", "summary"):
                if k not in ch:
                    raise ValueError(
                        f"{source}: editions[{i}].changes[{j}] missing '{k}'"
                    )
            if ch["kind"] not in _VALID_KINDS:
                raise ValueError(
                    f"{source}: editions[{i}].changes[{j}].kind='{ch['kind']}' "
                    f"invalid; must be one of {sorted(_VALID_KINDS)}"
                )


def list_editions(spec: str) -> list[dict[str, Any]]:
    """Return the list of editions known for ``spec`` (sorted by published date).

    Each item is ``{id, published, label}`` — useful for populating a UI
    dropdown without exposing the entire diff payload.
    """

    data = _load_corpus(spec)
    editions = sorted(
        data["editions"], key=lambda e: _parse_pubdate(e["published"])
    )
    return [
        {
            "id": ed["id"],
            "published": ed["published"],
            "label": ed.get("label", ed["id"]),
        }
        for ed in editions
    ]


def list_specs() -> list[str]:
    """Return the list of canonical spec ids known to the local corpus."""

    return sorted(_SPEC_FILES.keys())


def _parse_pubdate(s: str) -> date:
    """Parse an ISO-or-prefix date string; tolerates ``"2008"`` etc."""

    s = s.strip()
    parts = s.split("-")
    try:
        year = int(parts[0])
        month = int(parts[1]) if len(parts) > 1 else 1
        day = int(parts[2]) if len(parts) > 2 else 1
        return date(year, month, day)
    except (ValueError, IndexError) as e:
        raise ValueError(f"invalid published date '{s}': {e}") from e


# ---------------------------------------------------------------------------
# diff_edition — the marquee API
# ---------------------------------------------------------------------------


def diff_edition(
    spec: str,
    from_edition: str,
    to_edition: str,
    *,
    kinds: Optional[Sequence[ChangeKind]] = None,
) -> DiffReport:
    """Diff a spec between two editions.

    Returns every change introduced strictly *after* ``from_edition`` up to
    and including ``to_edition``. If the two ids are swapped (from > to),
    the diff is still computed correctly — direction is inferred from
    published dates.

    Args:
        spec: Spec id (any reasonable alias for one of the canonical ids
            returned by :func:`list_specs`).
        from_edition: Baseline edition id.
        to_edition: Target edition id.
        kinds: Optional filter — only include changes whose ``kind`` is in
            this list (e.g. ``["formula", "parameter"]``).

    Returns:
        :class:`DiffReport` with all matching changes ordered by edition
        published date, then by section name.

    Raises:
        :class:`~austenite.ValidationError`: spec or edition id unknown.
    """

    data = _load_corpus(spec)
    canonical_spec = data["spec"]
    publisher = data.get("publisher")
    title = data.get("title")

    eds_by_id: dict[str, dict[str, Any]] = {ed["id"]: ed for ed in data["editions"]}
    if from_edition not in eds_by_id:
        raise ValidationError(
            f"Unknown {canonical_spec} edition '{from_edition}'. "
            f"Known: {sorted(eds_by_id)}",
            status_code=400,
        )
    if to_edition not in eds_by_id:
        raise ValidationError(
            f"Unknown {canonical_spec} edition '{to_edition}'. "
            f"Known: {sorted(eds_by_id)}",
            status_code=400,
        )

    pub_from = _parse_pubdate(eds_by_id[from_edition]["published"])
    pub_to = _parse_pubdate(eds_by_id[to_edition]["published"])
    if pub_from > pub_to:
        # Caller passed (newer, older) — swap so the diff is always forward.
        from_edition, to_edition = to_edition, from_edition
        pub_from, pub_to = pub_to, pub_from

    kind_filter: Optional[frozenset[str]] = (
        frozenset(kinds) if kinds is not None else None
    )

    changes: list[tuple[date, str, EditionChange]] = []
    for ed in data["editions"]:
        pub = _parse_pubdate(ed["published"])
        if pub <= pub_from or pub > pub_to:
            continue
        for ch in ed["changes"]:
            if kind_filter is not None and ch["kind"] not in kind_filter:
                continue
            changes.append(
                (
                    pub,
                    str(ch["section"]),
                    EditionChange(
                        section=ch["section"],
                        kind=ch["kind"],
                        summary=ch["summary"],
                        primary_paper=ch.get("primary_paper"),
                    ),
                )
            )

    changes.sort(key=lambda t: (t[0], t[1]))
    return DiffReport(
        spec=canonical_spec,
        from_=from_edition,
        to_=to_edition,
        changes=[c[2] for c in changes],
        publisher=publisher,
        title=title,
    )


# ---------------------------------------------------------------------------
# recheck_edition — re-run a batch under a new edition
# ---------------------------------------------------------------------------


def _verdict_of(record: Mapping[str, Any]) -> Optional[str]:
    """Pull out a verdict string from a generic FFS/compliance record."""

    for k in ("verdict", "old_verdict", "current_verdict"):
        if k in record and record[k] is not None:
            return str(record[k]).upper()
    # nested compliance block
    comp = record.get("compliance")
    if isinstance(comp, Mapping):
        for k in ("verdict", "result"):
            if k in comp and comp[k] is not None:
                return str(comp[k]).upper()
        if "pass" in comp:
            return "PASS" if comp["pass"] else "FAIL"
    if "pass" in record:
        return "PASS" if record["pass"] else "FAIL"
    return None


def _p_pass_of(record: Mapping[str, Any]) -> Optional[float]:
    for k in ("p_pass", "P_pass", "probability_pass"):
        if k in record and record[k] is not None:
            try:
                return float(record[k])
            except (TypeError, ValueError):
                pass
    comp = record.get("compliance")
    if isinstance(comp, Mapping):
        for k in ("p_pass", "P_pass"):
            if k in comp and comp[k] is not None:
                try:
                    return float(comp[k])
                except (TypeError, ValueError):
                    pass
    return None


def _asset_id_of(record: Mapping[str, Any]) -> str:
    for k in ("asset_id", "asset", "id", "tag", "equipment_id"):
        if k in record and record[k] is not None:
            return str(record[k])
    return "<unknown>"


def recheck_edition(
    *,
    records: Iterable[Mapping[str, Any]],
    edition: str,
    spec: Optional[str] = None,
    margin_change_threshold: float = 0.01,
) -> RecheckReport:
    """Re-run a batch of compliance records under a newer spec edition.

    For now this is a *local impact estimator* — it does not call the
    server. It treats every change in the diff as a potential cause for
    re-review:

      * If the diff between the record's original edition and ``edition``
        contains any ``formula`` or ``parameter`` change touching the
        section the record was assessed against, the record is flagged as
        *changed_margin* (and conservatively *now_fail* if the original
        verdict was MARGINAL).
      * Otherwise the record retains its original verdict (*still_pass*).

    A future wave will plug this into the live engine so the re-check is
    physics-grounded rather than diff-grounded; the API is stable.

    Args:
        records: Iterable of record dicts. Each should provide a verdict
            (``verdict`` / ``compliance.verdict`` / ``compliance.pass``)
            and ideally the spec / edition it was originally assessed
            under (``spec`` / ``edition``).
        edition: Target edition id to re-check against.
        spec: Optional spec id; if omitted the record's own ``spec`` field
            is used (records without one are skipped with a note).
        margin_change_threshold: Records whose p_pass would move by more
            than this fraction get flagged as ``changed_margin`` even if
            the binary verdict is unchanged. Default 1 %.

    Returns:
        :class:`RecheckReport`.
    """

    records_list = list(records)
    still_pass = 0
    now_fail = 0
    changed_margin = 0
    details: list[RecheckDetail] = []
    cached_diffs: dict[tuple[str, str, str], DiffReport] = {}

    for rec in records_list:
        rec_spec = str(rec.get("spec") or spec or "")
        rec_edition = str(rec.get("edition") or rec.get("from_edition") or "")
        old_verdict = _verdict_of(rec) or "UNKNOWN"
        old_pp = _p_pass_of(rec)
        asset = _asset_id_of(rec)
        if not rec_spec:
            details.append(
                RecheckDetail(
                    asset_id=asset,
                    old_verdict=old_verdict,
                    new_verdict=old_verdict,
                    old_p_pass=old_pp,
                    new_p_pass=old_pp,
                    note="record had no 'spec' field — skipped",
                )
            )
            still_pass += 1 if old_verdict == "PASS" else 0
            continue
        if not rec_edition:
            details.append(
                RecheckDetail(
                    asset_id=asset,
                    old_verdict=old_verdict,
                    new_verdict=old_verdict,
                    old_p_pass=old_pp,
                    new_p_pass=old_pp,
                    note="record had no 'edition' field — assumed unchanged",
                )
            )
            still_pass += 1 if old_verdict == "PASS" else 0
            continue

        key = (rec_spec, rec_edition, edition)
        if key not in cached_diffs:
            try:
                cached_diffs[key] = diff_edition(rec_spec, rec_edition, edition)
            except ValidationError as e:
                details.append(
                    RecheckDetail(
                        asset_id=asset,
                        old_verdict=old_verdict,
                        new_verdict=old_verdict,
                        old_p_pass=old_pp,
                        new_p_pass=old_pp,
                        note=f"diff failed: {e.message}",
                    )
                )
                continue
        diff = cached_diffs[key]
        impactful = [
            c for c in diff.changes
            if c.kind in ("formula", "parameter", "method", "scope")
        ]
        if not impactful:
            still_pass += 1 if old_verdict == "PASS" else 0
            details.append(
                RecheckDetail(
                    asset_id=asset,
                    old_verdict=old_verdict,
                    new_verdict=old_verdict,
                    old_p_pass=old_pp,
                    new_p_pass=old_pp,
                    note=f"no impactful changes in {rec_spec} {rec_edition}→{edition}",
                )
            )
            continue

        # Heuristic margin impact: every impactful change worth ~1 % p_pass.
        delta = max(0.01, 0.01 * len(impactful))
        new_pp = max(0.0, min(1.0, (old_pp or 0.95) - delta))
        # Verdict transition: PASS may become MARGINAL or FAIL if the change
        # touches a *formula* or *parameter*; MARGINAL trends toward FAIL.
        new_verdict = old_verdict
        if old_verdict == "PASS" and any(
            c.kind in ("formula", "parameter") for c in impactful
        ):
            if new_pp >= 0.95:
                new_verdict = "PASS"
            elif new_pp >= 0.5:
                new_verdict = "MARGINAL"
            else:
                new_verdict = "FAIL"
        elif old_verdict == "MARGINAL":
            new_verdict = "FAIL" if new_pp < 0.5 else "MARGINAL"
        if new_verdict in ("FAIL",) or (
            old_verdict == "PASS" and new_verdict != "PASS"
        ):
            now_fail += 1
        else:
            still_pass += 1
        if abs((new_pp or 0.0) - (old_pp or 0.0)) >= margin_change_threshold:
            changed_margin += 1

        details.append(
            RecheckDetail(
                asset_id=asset,
                old_verdict=old_verdict,
                new_verdict=new_verdict,
                old_p_pass=old_pp,
                new_p_pass=new_pp,
                note=(
                    f"{len(impactful)} impactful change(s) in "
                    f"{rec_spec} {rec_edition}→{edition}"
                ),
            )
        )

    return RecheckReport(
        still_pass=still_pass,
        now_fail=now_fail,
        changed_margin=changed_margin,
        details=details,
        edition=edition,
        spec=spec,
    )
