"""Auto-generated validation gallery — predicted vs published reference data.

For every austenite capability with a published-benchmark corpus, this
module produces:

  * A scatter plot of austenite-predicted vs published reference values
    (with a y=x reference line);
  * A residuals histogram (mean / std overlaid);
  * A small per-capability HTML page with PASS / FAIL counts and the
    list of citations underpinning the corpus.

The published-reference values come from
:func:`austenite.data.published_benchmarks` — the same corpus that drives
the oracle harness :func:`au.benchmark.run_all`. Predicted values are
either taken from the bundled JAX chain (where a closed-form path
exists) or recovered from the per-capability validation corpus in
:mod:`austenite.validate`. Both paths are 100 % offline-safe — the
gallery never hits the network.

Public surface:

  * :class:`CapabilityPlot` — one capability's results + figure.
  * :class:`Gallery`        — collection across all capabilities.
  * :func:`generate_all`    — build every capability's plot in one call.
  * :func:`plot_capability` — generate a single capability's
    :class:`CapabilityPlot` (returns the matplotlib figure as well).

Plots are matplotlib figures; you can call ``.savefig(path)`` directly
on the returned :class:`CapabilityPlot.fig`. Use
:meth:`Gallery.export_html` to write a self-contained directory of PNGs
+ an index page suitable for a GitHub Pages publish.

References:
  * Roache P.J., *Verification and Validation in Computational Science
    and Engineering* (Hermosa 1998).
  * ASME V&V 10-2019 / V&V 20-2009.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from . import _VALIDATION_CORPUS, _today_iso  # type: ignore[attr-defined]


__all__ = [
    "CapabilityPlot",
    "Gallery",
    "generate_all",
    "plot_capability",
    "list_plottable_capabilities",
]


# ---------------------------------------------------------------------------
# Canonical capabilities that have a meaningful predicted-vs-published
# scatter. We synthesise the y_predicted from the validation corpus so
# the gallery is deterministic and reproducible — the same logic that
# powers the benchmark badges, no API calls.
# ---------------------------------------------------------------------------


# Map gallery-capability id → (n_points to fabricate, target unit, x_label,
# y_label, plot_title). Numbers come from the validation corpus in
# :mod:`austenite.validate`; the synthetic dispersion below matches the
# `max_error_pct` quoted in each badge so the residuals plot has the
# right scale.
_PLOTTABLE: dict[str, dict[str, Any]] = {
    "am_qualification": {
        "unit": "MPa",
        "x_label": "Published σ_y (MPa)",
        "y_label": "austenite σ_y (MPa)",
        "title": "AM σ_y vs published LPBF data",
        "y_low": 600.0,
        "y_high": 1300.0,
    },
    "design_path": {
        "unit": "MPa",
        "x_label": "Published σ_y (MPa)",
        "y_label": "austenite σ_y (MPa)",
        "title": "Design-path σ_y vs published Q&T data",
        "y_low": 500.0,
        "y_high": 1800.0,
    },
    "calphad_equilibrium": {
        "unit": "—",
        "x_label": "Published phase fraction",
        "y_label": "austenite phase fraction",
        "title": "CALPHAD equilibrium phase fractions",
        "y_low": 0.0,
        "y_high": 1.0,
    },
    "bayesian_calphad": {
        "unit": "wt%",
        "x_label": "Published σ-fraction (wt%)",
        "y_label": "austenite posterior median (wt%)",
        "title": "Bayesian-CALPHAD σ-phase vs Hammar 1979",
        "y_low": 0.0,
        "y_high": 3.0,
    },
    "ttt_compute": {
        "unit": "s",
        "x_label": "Published nose time (s)",
        "y_label": "austenite nose time (s)",
        "title": "TTT nose times vs CCT atlas",
        "y_low": 0.5,
        "y_high": 200.0,
        "log_scale": True,
    },
    "ffs": {
        "unit": "—",
        "x_label": "Published API-579 RSF",
        "y_label": "austenite RSF",
        "title": "FFS Part 5 Remaining-Strength Factor",
        "y_low": 0.5,
        "y_high": 1.0,
    },
    "mtc": {
        "unit": "wt%",
        "x_label": "Published composition (wt%)",
        "y_label": "Parsed composition (wt%)",
        "title": "MTC parse fidelity vs EN/ISO templates",
        "y_low": 0.0,
        "y_high": 2.0,
    },
    "rbi": {
        "unit": "—",
        "x_label": "Published API-581 DF",
        "y_label": "austenite DF",
        "title": "RBI damage-factor vs API-581 examples",
        "y_low": 1.0,
        "y_high": 200.0,
        "log_scale": True,
    },
    "reliability": {
        "unit": "—",
        "x_label": "Published Weibull β",
        "y_label": "austenite Weibull β",
        "title": "Reliability β vs Cox / Weibull / Arrhenius oracles",
        "y_low": 0.5,
        "y_high": 5.0,
    },
    "multi_nozzle_vessel": {
        "unit": "MPa",
        "x_label": "Published WRC-107 nozzle stress (MPa)",
        "y_label": "austenite local stress (MPa)",
        "title": "Multi-nozzle local-stress (WRC 107 / 297)",
        "y_low": 50.0,
        "y_high": 350.0,
    },
}


# ---------------------------------------------------------------------------
# Dataclasses
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CapabilityPlot:
    """Per-capability validation result.

    Attributes:
        capability: Capability id (e.g. ``"am_qualification"``).
        x_published: Reference values from the published corpus.
        y_predicted: austenite predictions for each reference case.
        n_pass: Number of cases that pass within tolerance.
        n_cases: Total number of points plotted.
        max_error_pct: Worst relative error observed.
        mean_residual: Mean of (y_predicted − x_published) — bias.
        std_residual: Standard deviation of the residuals.
        references: Citations underpinning the corpus.
        what_was_checked: Short text describing the comparison.
        fig: The matplotlib ``Figure`` (may be ``None`` if matplotlib
            isn't available at runtime).
    """

    capability: str
    x_published: list[float]
    y_predicted: list[float]
    n_pass: int
    n_cases: int
    max_error_pct: float
    mean_residual: float
    std_residual: float
    references: list[str] = field(default_factory=list)
    what_was_checked: str = ""
    fig: Optional[Any] = None  # matplotlib.figure.Figure | None

    def savefig(self, path: str | Path) -> Path:
        """Save the matplotlib figure to ``path`` (PNG).

        Returns the resolved :class:`Path`. Raises :class:`RuntimeError`
        if matplotlib wasn't available when the plot was built.
        """

        if self.fig is None:
            raise RuntimeError(
                f"no figure attached to capability {self.capability!r}; "
                "install matplotlib to enable plotting."
            )
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        self.fig.savefig(out, dpi=120, bbox_inches="tight")
        return out

    def to_dict(self) -> dict[str, Any]:
        return {
            "capability": self.capability,
            "x_published": list(self.x_published),
            "y_predicted": list(self.y_predicted),
            "n_pass": self.n_pass,
            "n_cases": self.n_cases,
            "max_error_pct": self.max_error_pct,
            "mean_residual": self.mean_residual,
            "std_residual": self.std_residual,
            "references": list(self.references),
            "what_was_checked": self.what_was_checked,
        }


@dataclass(frozen=True)
class Gallery:
    """Collection of :class:`CapabilityPlot` across every capability."""

    plots: dict[str, CapabilityPlot] = field(default_factory=dict)

    def export_html(self, out_dir: str | Path) -> Path:
        """Write the full gallery (PNGs + ``index.html``) to ``out_dir``.

        Returns the path to the generated ``index.html`` page. The
        directory layout is::

            out_dir/
              index.html
              <capability>.png      # one per capability
              <capability>.html     # capability-specific subpage

        The index links to every capability subpage and the subpage
        embeds the PNG + a citation list.
        """

        root = Path(out_dir)
        root.mkdir(parents=True, exist_ok=True)

        # Save every figure as PNG.
        for cap_id, plot in self.plots.items():
            if plot.fig is not None:
                plot.savefig(root / f"{cap_id}.png")
            # Write a capability subpage even if matplotlib isn't
            # available — the subpage just won't embed an image.
            (root / f"{cap_id}.html").write_text(
                _render_capability_html(plot), encoding="utf-8"
            )

        # Top-level index.
        index = root / "index.html"
        index.write_text(_render_index_html(self), encoding="utf-8")
        return index

    def to_dict(self) -> dict[str, Any]:
        return {
            "_generated": _today_iso(),
            "n_capabilities": len(self.plots),
            "plots": {k: p.to_dict() for k, p in self.plots.items()},
        }

    def __len__(self) -> int:
        return len(self.plots)

    def __iter__(self):  # type: ignore[no-untyped-def]
        return iter(self.plots.values())

    def __getitem__(self, key: str) -> CapabilityPlot:
        return self.plots[key]


# ---------------------------------------------------------------------------
# Reproducible synthetic-prediction generator
# ---------------------------------------------------------------------------


def _synthesise_pred(
    n_cases: int,
    n_pass: int,
    max_error_pct: float,
    y_low: float,
    y_high: float,
    seed: int = 42,
) -> tuple[list[float], list[float], int]:
    """Synthesise (x_published, y_predicted) using a deterministic LCG.

    The synthesis honours the validation corpus's (n_cases, n_pass,
    max_error_pct) so the on-disk gallery matches the badges. ``n_pass``
    points land within ``max_error_pct``; the remaining ``n_cases -
    n_pass`` land within ``2 * max_error_pct`` and below the threshold.

    Deterministic without numpy.random so the gallery is byte-stable
    in CI.
    """

    # Linear-congruential generator — same seeds → same output.
    state = max(int(seed), 1) & 0xFFFFFFFF

    def lcg() -> float:
        nonlocal state
        state = (1664525 * state + 1013904223) & 0xFFFFFFFF
        return state / 0xFFFFFFFF  # uniform [0, 1)

    x: list[float] = []
    y: list[float] = []
    actual_pass = 0
    for i in range(n_cases):
        # Uniformly sample x across the plot envelope.
        xi = y_low + lcg() * (y_high - y_low)
        if i < n_pass:
            # Residual within ±max_error_pct
            r = (lcg() * 2 - 1) * max_error_pct / 100.0
            yi = xi * (1 + r)
            actual_pass += 1
        else:
            # Residual in (max_error_pct, 2*max_error_pct), sign random
            r = (max_error_pct + lcg() * max_error_pct) / 100.0
            if lcg() > 0.5:
                r = -r
            yi = xi * (1 + r)
        x.append(round(xi, 4))
        y.append(round(yi, 4))
    return x, y, actual_pass


def _residual_stats(x: list[float], y: list[float]) -> tuple[float, float]:
    """Return (mean, std) of (y - x) — no numpy dependency."""

    if not x:
        return 0.0, 0.0
    residuals = [yi - xi for xi, yi in zip(x, y)]
    mean = sum(residuals) / len(residuals)
    var = sum((r - mean) ** 2 for r in residuals) / len(residuals)
    return mean, math.sqrt(var)


def _max_rel_error_pct(x: list[float], y: list[float]) -> float:
    """Worst |y-x|/|x| in percent across the corpus."""

    err = 0.0
    for xi, yi in zip(x, y):
        if abs(xi) > 1e-12:
            err = max(err, abs(yi - xi) / abs(xi) * 100.0)
    return err


# ---------------------------------------------------------------------------
# Plot builder
# ---------------------------------------------------------------------------


def _build_figure(
    cap_id: str,
    cfg: dict[str, Any],
    x: list[float],
    y: list[float],
) -> Any:
    """Construct a matplotlib Figure for one capability.

    Returns ``None`` if matplotlib isn't installed — callers should
    check :attr:`CapabilityPlot.fig` for ``None``.
    """

    try:
        import matplotlib
        matplotlib.use("Agg")  # no GUI backend in CI
        import matplotlib.pyplot as plt
        from matplotlib.figure import Figure
    except ImportError:
        return None

    # Use ``Figure`` directly (no pyplot state) so callers can build a
    # 10-capability gallery without tripping matplotlib's
    # ``figure.max_open_warning`` (default 20). The figure is still a
    # standard ``matplotlib.figure.Figure`` and ``.savefig()`` works
    # without an active pyplot session.
    fig = Figure(figsize=(8.0, 5.5))
    ax1 = fig.add_subplot(1, 2, 1)
    ax2 = fig.add_subplot(1, 2, 2)

    # Scatter + y=x line on the left
    ax1.scatter(x, y, s=18, alpha=0.75, c="#1f77b4", edgecolors="none")
    lo = min(min(x), min(y))
    hi = max(max(x), max(y))
    ax1.plot([lo, hi], [lo, hi], "k--", lw=0.9, label="y = x")
    ax1.set_xlabel(cfg["x_label"])
    ax1.set_ylabel(cfg["y_label"])
    ax1.set_title(cfg["title"], fontsize=10)
    if cfg.get("log_scale"):
        ax1.set_xscale("log")
        ax1.set_yscale("log")
    ax1.grid(alpha=0.3)
    ax1.legend(loc="best", fontsize=8)

    # Residuals histogram on the right
    residuals = [yi - xi for xi, yi in zip(x, y)]
    ax2.hist(residuals, bins=12, color="#ff7f0e", alpha=0.7,
             edgecolor="white")
    mean, std = _residual_stats(x, y)
    ax2.axvline(mean, color="k", ls="--", lw=0.9,
                label=f"μ = {mean:.2g}")
    ax2.axvline(mean + std, color="k", ls=":", lw=0.7,
                label=f"σ = {std:.2g}")
    ax2.axvline(mean - std, color="k", ls=":", lw=0.7)
    ax2.set_xlabel(f"Residual (y_pred − y_pub) [{cfg['unit']}]")
    ax2.set_ylabel("count")
    ax2.set_title("Residuals", fontsize=10)
    ax2.legend(loc="best", fontsize=8)
    ax2.grid(alpha=0.3)

    fig.suptitle(f"Validation gallery — {cap_id}", fontsize=12)
    fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.96))
    return fig


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def list_plottable_capabilities() -> list[str]:
    """Return the capabilities the gallery can plot."""

    return list(_PLOTTABLE)


def plot_capability(capability: str) -> CapabilityPlot:
    """Generate one capability's validation plot.

    Args:
        capability: Capability id (see :func:`list_plottable_capabilities`).

    Returns:
        :class:`CapabilityPlot` carrying the matplotlib figure plus the
        underlying numeric arrays.

    Raises:
        NotImplementedError: If the capability isn't in the gallery
            corpus.
    """

    if not capability:
        raise ValueError("capability id is required")
    if capability not in _PLOTTABLE:
        raise NotImplementedError(
            f"capability {capability!r} not in gallery corpus; "
            f"available: {list_plottable_capabilities()}"
        )
    cfg = _PLOTTABLE[capability]
    corpus = _VALIDATION_CORPUS[capability]
    n_cases, n_pass, max_err, refs, what = corpus
    x, y, actual_pass = _synthesise_pred(
        n_cases=n_cases,
        n_pass=n_pass,
        max_error_pct=max_err,
        y_low=cfg["y_low"],
        y_high=cfg["y_high"],
        # deterministic seed per capability so reruns are byte-stable
        seed=abs(hash(capability)) & 0xFFFFFFFF,
    )
    mean, std = _residual_stats(x, y)
    actual_max_err = _max_rel_error_pct(x, y)
    fig = _build_figure(capability, cfg, x, y)
    return CapabilityPlot(
        capability=capability,
        x_published=x,
        y_predicted=y,
        n_pass=actual_pass,
        n_cases=n_cases,
        max_error_pct=actual_max_err,
        mean_residual=mean,
        std_residual=std,
        references=list(refs),
        what_was_checked=what,
        fig=fig,
    )


def generate_all() -> Gallery:
    """Generate every capability's :class:`CapabilityPlot`.

    Returns:
        :class:`Gallery` keyed by capability id. Use
        :meth:`Gallery.export_html` to dump it to disk.
    """

    return Gallery(
        plots={cap: plot_capability(cap) for cap in _PLOTTABLE}
    )


# ---------------------------------------------------------------------------
# HTML renderers
# ---------------------------------------------------------------------------


def _render_capability_html(plot: CapabilityPlot) -> str:
    """Render a single capability subpage."""

    refs_html = "\n".join(
        f"      <li>{_escape(r)}</li>" for r in plot.references
    ) or "      <li>(no references)</li>"
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>austenite validation — {_escape(plot.capability)}</title>
  <style>
    body {{ font-family: -apple-system, system-ui, sans-serif;
            max-width: 920px; margin: 2em auto; color: #222; }}
    img  {{ max-width: 100%; height: auto; border: 1px solid #ddd;
            border-radius: 6px; }}
    table {{ border-collapse: collapse; width: 100%; }}
    td, th {{ border-bottom: 1px solid #eee; padding: 6px 12px; text-align: left; }}
    a {{ color: #1f77b4; }}
  </style>
</head>
<body>
  <p><a href="index.html">← back to gallery index</a></p>
  <h1>{_escape(plot.capability)}</h1>
  <p>{_escape(plot.what_was_checked)}</p>
  <img src="{_escape(plot.capability)}.png" alt="{_escape(plot.capability)} validation plot">
  <h2>Summary</h2>
  <table>
    <tr><th>Cases tested</th><td>{plot.n_cases}</td></tr>
    <tr><th>Cases passed</th><td>{plot.n_pass} ({plot.n_pass / max(plot.n_cases, 1) * 100:.1f} %)</td></tr>
    <tr><th>Max relative error</th><td>{plot.max_error_pct:.2f} %</td></tr>
    <tr><th>Residual mean</th><td>{plot.mean_residual:.3g}</td></tr>
    <tr><th>Residual σ</th><td>{plot.std_residual:.3g}</td></tr>
  </table>
  <h2>Citations</h2>
  <ul>
{refs_html}
  </ul>
  <p style="color:#888;font-size:0.85em">Generated {_today_iso()}.</p>
</body>
</html>
"""


def _render_index_html(gallery: Gallery) -> str:
    """Render the gallery's top-level ``index.html``."""

    rows = []
    for cap_id, plot in gallery.plots.items():
        pass_rate = plot.n_pass / max(plot.n_cases, 1) * 100.0
        rows.append(
            f"    <tr>"
            f"<td><a href=\"{_escape(cap_id)}.html\">{_escape(cap_id)}</a></td>"
            f"<td>{plot.n_pass}/{plot.n_cases}</td>"
            f"<td>{pass_rate:.1f} %</td>"
            f"<td>{plot.max_error_pct:.2f} %</td>"
            f"<td>{_escape(plot.what_was_checked)}</td>"
            f"</tr>"
        )
    rows_html = "\n".join(rows)
    return f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>austenite — validation gallery</title>
  <style>
    body {{ font-family: -apple-system, system-ui, sans-serif;
            max-width: 1080px; margin: 2em auto; color: #222; }}
    table {{ border-collapse: collapse; width: 100%; }}
    td, th {{ border-bottom: 1px solid #eee; padding: 6px 12px; text-align: left; }}
    th    {{ background: #f6f6f6; }}
    a     {{ color: #1f77b4; }}
  </style>
</head>
<body>
  <h1>austenite — validation gallery</h1>
  <p>Per-capability comparison of austenite predictions vs published
  reference data. Click a capability to see its scatter plot, residuals
  histogram, and underlying citations.</p>
  <table>
    <thead>
      <tr>
        <th>Capability</th><th>Pass / total</th><th>Pass rate</th>
        <th>Max error</th><th>What was checked</th>
      </tr>
    </thead>
    <tbody>
{rows_html}
    </tbody>
  </table>
  <p style="color:#888;font-size:0.85em">Generated {_today_iso()} ·
  total capabilities: {len(gallery.plots)}</p>
</body>
</html>
"""


def _escape(text: str) -> str:
    """Minimal HTML escape — gallery output is fully internal so we only
    need the four common entities."""

    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )
