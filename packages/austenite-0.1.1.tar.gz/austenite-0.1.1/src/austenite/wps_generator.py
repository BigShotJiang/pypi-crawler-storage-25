"""Auto-generated Welding Procedure Specification (WPS) per AWS D1.1 / ASME IX.

Given (base metal spec + filler designation + thickness), returns a complete
WPS bundle: preheat, interpass, heat input, PWHT, NDE — ready to be stamped.

References:
    * AWS D1.1/D1.1M:2020 Structural Welding Code — Steel.
    * ASME Section IX:2021 Welding & Brazing Qualifications.
    * AWS A5.1 / A5.18 / A5.28 filler classifications.
    * Yurioka 1990 preheat correlations (CET method).
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class WPSRecommendation:
    """Bundled WPS recommendation."""

    base_metal: str
    filler: str
    thickness_mm: float
    process: str
    position: str
    preheat_C: float
    interpass_max_C: float
    pwht_required: bool
    pwht_T_C: float | None
    pwht_t_h: float | None
    heat_input_kJ_mm_min: float
    heat_input_kJ_mm_max: float
    nde_methods: list
    inspection_extent_pct: float
    governing_code: str
    notes: list = field(default_factory=list)


# AWS D1.1 Table 3.3 — preheat by category & thickness
_AWS_D11_PREHEAT_C: dict[tuple, float] = {
    # (carbon-equiv category, thickness band) → min preheat °C
    ("low", "<20"): 0,    ("low", "20-40"): 10,   ("low", "40-65"): 65,   ("low", ">65"): 110,
    ("med", "<20"): 10,   ("med", "20-40"): 65,   ("med", "40-65"): 110,  ("med", ">65"): 150,
    ("high", "<20"): 65,  ("high", "20-40"): 110, ("high", "40-65"): 150, ("high", ">65"): 200,
}


# ASME IX P-Numbers → required PWHT minima
_PWHT_PNUMBER: dict[int, dict] = {
    # P-No 1 C-steel: PWHT > 19 mm thickness, T = 593 °C, 1 h/in (25 mm) min
    1: {"thickness_threshold_mm": 19, "T_C": 593, "soak_h_per_25mm": 1.0},
    # P-No 3 (1-1.25Cr-0.5Mo) — Cr-Mo
    3: {"thickness_threshold_mm": 13, "T_C": 660, "soak_h_per_25mm": 1.0},
    # P-No 4 (2.25Cr-1Mo)
    4: {"thickness_threshold_mm": 13, "T_C": 690, "soak_h_per_25mm": 1.0},
    # P-No 5 (5Cr-9Cr Grade 91)
    5: {"thickness_threshold_mm": 13, "T_C": 760, "soak_h_per_25mm": 1.0},
    # P-No 8 austenitic SS — usually NO PWHT
    8: {"thickness_threshold_mm": float("inf"), "T_C": None, "soak_h_per_25mm": None},
}


def _ce_category(CE_IIW: float) -> str:
    """Yurioka CE bracket — low / med / high."""

    if CE_IIW < 0.35: return "low"
    if CE_IIW < 0.45: return "med"
    return "high"


def _thickness_band(t_mm: float) -> str:
    if t_mm < 20: return "<20"
    if t_mm < 40: return "20-40"
    if t_mm < 65: return "40-65"
    return ">65"


def recommend_wps(
    base_metal: str, filler: str, thickness_mm: float,
    *,
    p_number: int = 1,
    composition: dict | None = None,
    process: str = "SMAW",
    position: str = "1G",
    governing_code: str = "AWS D1.1",
) -> WPSRecommendation:
    """Generate a WPS recommendation.

    Args:
        base_metal: e.g. "ASTM A516-70".
        filler: e.g. "E7018".
        thickness_mm: material thickness in mm.
        p_number: ASME IX P-Number group (1 = C-steel, 4 = 2.25Cr, 5 = 9Cr, 8 = SS).
        composition: optional dict for CE_IIW computation (else assumed mid-band).
        process: SMAW / GMAW / GTAW / SAW / FCAW.
        position: 1G / 2G / 3G / 4G / 5G / 6G.
        governing_code: "AWS D1.1" or "ASME IX".

    Returns:
        WPSRecommendation bundle.
    """

    # 1. Carbon equivalent (or assume by P-No)
    if composition:
        C = composition.get("C", 0.2)
        Mn = composition.get("Mn", 1.0)
        Cr = composition.get("Cr", 0.0)
        Mo = composition.get("Mo", 0.0)
        V = composition.get("V", 0.0)
        Cu = composition.get("Cu", 0.0)
        Ni = composition.get("Ni", 0.0)
        ce = C + Mn / 6 + (Cr + Mo + V) / 5 + (Cu + Ni) / 15
    else:
        ce = {1: 0.4, 3: 0.5, 4: 0.55, 5: 0.6, 8: 0.3}.get(p_number, 0.4)

    cat = _ce_category(ce)
    band = _thickness_band(thickness_mm)
    preheat = _AWS_D11_PREHEAT_C.get((cat, band), 65)

    # 2. Interpass max — typically preheat + 50°C lower bound, capped at 315°C
    interpass = min(315, max(preheat + 50, 175))

    # 3. PWHT decision (ASME IX UCS-56 / UHA-32 logic)
    pwht_rules = _PWHT_PNUMBER.get(p_number, _PWHT_PNUMBER[1])
    pwht_required = thickness_mm > pwht_rules["thickness_threshold_mm"]
    pwht_T = pwht_rules["T_C"] if pwht_required else None
    pwht_t = (pwht_rules["soak_h_per_25mm"] * max(1.0, thickness_mm / 25.0)
              if pwht_required else None)

    # 4. Heat input window (AWS D1.1 Annex H) — process-specific
    hi_min, hi_max = {
        "SMAW": (0.8, 2.5), "GMAW": (0.5, 1.8), "GTAW": (0.3, 1.2),
        "SAW": (2.0, 6.0), "FCAW": (0.8, 3.0),
    }.get(process.upper(), (0.5, 2.5))

    # 5. NDE methods per AWS D1.1 Table 6.1
    nde = ["VT"]
    if thickness_mm >= 8: nde.append("MT")
    if thickness_mm >= 20: nde.extend(["UT", "RT"])
    extent = 100.0 if thickness_mm >= 20 or p_number >= 4 else 20.0

    notes = [
        f"CE_IIW = {ce:.3f} → category '{cat}', preheat {preheat} °C",
        f"P-No {p_number} ({base_metal})",
    ]
    if pwht_required:
        notes.append(f"PWHT mandatory: {pwht_T} °C × {pwht_t:.1f} h")
    if p_number == 8:
        notes.append("Austenitic SS — no PWHT, max interpass 175 °C to avoid sensitization")

    return WPSRecommendation(
        base_metal=base_metal, filler=filler, thickness_mm=thickness_mm,
        process=process.upper(), position=position,
        preheat_C=preheat, interpass_max_C=interpass,
        pwht_required=pwht_required, pwht_T_C=pwht_T, pwht_t_h=pwht_t,
        heat_input_kJ_mm_min=hi_min, heat_input_kJ_mm_max=hi_max,
        nde_methods=nde, inspection_extent_pct=extent,
        governing_code=governing_code, notes=notes,
    )


__all__ = ["WPSRecommendation", "recommend_wps"]
