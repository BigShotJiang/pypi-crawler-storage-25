"""Welding physics: heat-input, dilution, HAZ geometry, preheat selection.

Native Python implementations of the canonical welding-engineering models.
Used in every fabrication shop for WPS qualification, distortion control,
HAZ-property prediction, and weld-quality QC.

* **Heat-input** ``H = η · V · I / v``  with arc-efficiency η per process.
* **Dilution calculator** for cladding / weld-overlay / dissimilar metal welds.
* **Yurioka 1981 carbon-equivalent** CE_yurioka for preheat prediction.
* **IIW carbon-equivalent** CE_IIW for HSLA + Cr-Mo steels.
* **Pcm** (Ito-Bessyo 1968) parameter for thin-section preheat.
* **CET** (Düren 1985) for modern fine-grained steels.
* **Rosenthal 2D + 3D heat-source temperature field** for HAZ width.
* **Goldak double-ellipsoidal heat source** with t_85 cooling-time output.
* **HAZ peak-temperature isotherm width**.
* **Cooling time t_8/5** (between 800-500°C) — the canonical predictor of
  HAZ microstructure (Yurioka 1995).
* **Suzuki-Yurioka preheat selection** chart.

References:
    * Yurioka N., Suzuki H., Met. Constr. 13 (1981) 217.
    * Ito Y., Bessyo K., J. Iron Steel Inst. Japan 54 (1968) 1086.
    * Düren C., Pannenbecker H., Stahl Eisen 105 (1985) 41 — CET method.
    * Yurioka N., Welding Journal 74 (1995) 311.
    * Rosenthal D., Welding Journal 20 (1941) 220.
    * Goldak J., Chakravarti A., Bibby M., Met. Trans. B 15 (1984) 299.
    * Bailey N., TWI Doc. 5570/1/74 (1973) — preheat charts.
    * IIW Doc. IX-1632-91 — CE_IIW formulation.
    * Pavaskar P.K., et al., Welding J. Suppl. 2014 — review.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal


# ---------------------------------------------------------------------------
# 1. CARBON EQUIVALENTS
# ---------------------------------------------------------------------------


def ce_iiw(composition_wt_pct: dict[str, float]) -> float:
    """IIW carbon equivalent: ``CE = C + Mn/6 + (Cr+Mo+V)/5 + (Cu+Ni)/15``.

    Limit for non-preheated welds (IIW): CE ≤ 0.41 for fine-grained
    structural steels; ≤ 0.45 for general C-Mn.
    """
    c = composition_wt_pct
    Mn = c.get("Mn", 0.0)
    Cr = c.get("Cr", 0.0)
    Mo = c.get("Mo", 0.0)
    V = c.get("V", 0.0)
    Cu = c.get("Cu", 0.0)
    Ni = c.get("Ni", 0.0)
    C_val = c.get("C", 0.0)
    return float(C_val + Mn / 6.0 + (Cr + Mo + V) / 5.0 + (Cu + Ni) / 15.0)


def ce_yurioka(composition_wt_pct: dict[str, float]) -> float:
    """Yurioka 1981 carbon equivalent:
    ``CE_Y = C + A(C)·{Si/24 + Mn/6 + Cu/15 + Ni/20 + (Cr+Mo+Nb+V)/5 + 5B}``

    where ``A(C) = 0.75 + 0.25·tanh(20·(C − 0.12))`` is the C-content factor.
    Designed for cold-cracking susceptibility of HSLA + Cr-Mo steels.
    """
    c = composition_wt_pct
    C_val = float(c.get("C", 0.0))
    A = 0.75 + 0.25 * math.tanh(20.0 * (C_val - 0.12))
    inner = (c.get("Si", 0.0) / 24.0 + c.get("Mn", 0.0) / 6.0
             + c.get("Cu", 0.0) / 15.0 + c.get("Ni", 0.0) / 20.0
             + (c.get("Cr", 0.0) + c.get("Mo", 0.0) + c.get("Nb", 0.0)
                + c.get("V", 0.0)) / 5.0
             + 5.0 * c.get("B", 0.0))
    return C_val + A * inner


def pcm_ito_bessyo(composition_wt_pct: dict[str, float]) -> float:
    """Ito-Bessyo 1968 Pcm parameter for thin-section preheat:

    ``Pcm = C + Si/30 + (Mn+Cu+Cr)/20 + Ni/60 + Mo/15 + V/10 + 5B``

    Used for high-strength steels with C < 0.18 wt%.
    """
    c = composition_wt_pct
    return float(c.get("C", 0.0)
                 + c.get("Si", 0.0) / 30.0
                 + (c.get("Mn", 0.0) + c.get("Cu", 0.0) + c.get("Cr", 0.0)) / 20.0
                 + c.get("Ni", 0.0) / 60.0
                 + c.get("Mo", 0.0) / 15.0
                 + c.get("V", 0.0) / 10.0
                 + 5.0 * c.get("B", 0.0))


def cet_duren(composition_wt_pct: dict[str, float]) -> float:
    """Düren 1985 CET parameter for fine-grained steels:

    ``CET = C + (Mn+Mo)/10 + (Cr+Cu)/20 + Ni/40``
    """
    c = composition_wt_pct
    return float(c.get("C", 0.0)
                 + (c.get("Mn", 0.0) + c.get("Mo", 0.0)) / 10.0
                 + (c.get("Cr", 0.0) + c.get("Cu", 0.0)) / 20.0
                 + c.get("Ni", 0.0) / 40.0)


# ---------------------------------------------------------------------------
# 2. HEAT INPUT + ARC EFFICIENCY
# ---------------------------------------------------------------------------


ARC_EFFICIENCY: dict[str, float] = {
    "SAW":   0.95,  # submerged arc welding
    "FCAW":  0.85,
    "GMAW":  0.80,  # MIG / MAG
    "MMA":   0.75,  # SMAW
    "GTAW":  0.65,  # TIG
    "PAW":   0.50,  # plasma arc
    "EBW":   0.95,  # electron-beam
    "LBW":   0.85,  # laser-beam
}


def heat_input_kJ_per_mm(
    voltage_V: float, current_A: float, travel_speed_mm_s: float,
    *, process: str = "SAW", eta_override: float | None = None,
) -> float:
    """Welding heat input:

    ``H_kJ/mm = η · V · I / (v · 1000)``

    where η is the arc thermal efficiency (process-dependent), V is the
    arc voltage, I the welding current, v the travel speed in mm/s.

    Per ASME IX, AWS D1.1, and EN ISO 1011-1 §4.2.
    """
    if not all(_is_finite(x) for x in [voltage_V, current_A, travel_speed_mm_s]):
        return float("nan")
    if travel_speed_mm_s <= 0:
        return float("inf")
    eta = float(eta_override) if eta_override is not None else ARC_EFFICIENCY.get(process, 0.80)
    return eta * float(voltage_V) * float(current_A) / (float(travel_speed_mm_s) * 1000.0)


# ---------------------------------------------------------------------------
# 3. DILUTION CALCULATION
# ---------------------------------------------------------------------------


def dilution_pct(
    A_filler_mm2: float, A_base_mm2: float,
) -> float:
    """Weld dilution percentage:

    ``D = A_base / (A_base + A_filler) × 100 %``

    Typical values:
    * SAW: 35-65 %
    * SMAW: 20-30 %
    * FCAW: 25-40 %
    * GMAW: 10-30 %
    * GTAW: 5-25 %

    Used to predict mixed-zone chemistry in dissimilar-metal or cladding
    welds via mass-balance:
        c_weld = (1 − D) · c_filler + D · c_base.
    """
    if not all(_is_finite(x) for x in [A_filler_mm2, A_base_mm2]):
        return float("nan")
    total = float(A_filler_mm2) + float(A_base_mm2)
    if total <= 0:
        return float("nan")
    return 100.0 * float(A_base_mm2) / total


def mixed_zone_composition(
    composition_filler: dict[str, float],
    composition_base: dict[str, float],
    dilution_pct_value: float,
) -> dict[str, float]:
    """Mass-balance for dilution-mixed weld metal composition."""
    if not _is_finite(dilution_pct_value):
        return {}
    D = max(0.0, min(100.0, float(dilution_pct_value))) / 100.0
    elements = set(composition_filler) | set(composition_base)
    return {
        el: (1.0 - D) * float(composition_filler.get(el, 0.0))
            + D * float(composition_base.get(el, 0.0))
        for el in elements
    }


# ---------------------------------------------------------------------------
# 4. ROSENTHAL HEAT-SOURCE TEMPERATURE FIELD
# ---------------------------------------------------------------------------


def rosenthal_2d_temperature(
    Q_W: float, v_mm_s: float, T_0_C: float,
    x_mm: float, r_perp_mm: float,
    *,
    thickness_mm: float = 10.0,
    k_W_mK: float = 50.0,
    alpha_mm2_s: float = 5.0,
) -> float:
    """Rosenthal 1941 2D moving-point-source temperature field for thin plates.

    Steady-state form:  ``T(x,r) − T_0 = Q / (2π · k · t) · exp(−v(x+R)/(2α)) · K_0(vR/(2α))``

    where R = sqrt(x² + r_perp²). For thick plates use rosenthal_3d.

    Returns absolute temperature in °C.

    Reference: Rosenthal D., Welding Journal 20 (1941) 220.
    """
    if not all(_is_finite(x) for x in [Q_W, v_mm_s, T_0_C, x_mm, r_perp_mm,
                                       thickness_mm, k_W_mK, alpha_mm2_s]):
        return float("nan")
    if k_W_mK <= 0 or thickness_mm <= 0:
        return float("nan")
    # Convert mm to m
    v_m_s = float(v_mm_s) / 1000.0
    x_m = float(x_mm) / 1000.0
    r_m = float(r_perp_mm) / 1000.0
    t_m = float(thickness_mm) / 1000.0
    alpha_m2_s = float(alpha_mm2_s) / 1e6
    R_m = math.sqrt(x_m ** 2 + r_m ** 2)
    if R_m < 1e-9:
        return float("inf")  # at source
    # K_0 modified Bessel — approximate with asymptotic form for moderate
    # values (the textbook practical case)
    arg = v_m_s * R_m / (2.0 * alpha_m2_s)
    if arg < 0.01:
        K0 = -math.log(arg / 2.0) - 0.5772156649
    elif arg > 50:
        K0 = 0.0
    else:
        # Polynomial fit (Abramowitz-Stegun 9.8.5/9.8.6)
        K0 = math.sqrt(math.pi / (2.0 * arg)) * math.exp(-arg) \
             * (1.0 - 1.0 / (8.0 * arg) + 9.0 / (128.0 * arg ** 2))
    pre = float(Q_W) / (2.0 * math.pi * float(k_W_mK) * t_m)
    expo = math.exp(-v_m_s * (x_m + R_m) / (2.0 * alpha_m2_s))
    delta_T = pre * expo * K0
    return float(T_0_C) + delta_T


def rosenthal_3d_temperature(
    Q_W: float, v_mm_s: float, T_0_C: float,
    x_mm: float, r_mm: float,
    *,
    k_W_mK: float = 50.0,
    alpha_mm2_s: float = 5.0,
) -> float:
    """Rosenthal 3D moving-point-source temperature field for thick plates:

    ``T − T_0 = Q / (2π · k · R) · exp(−v(R+x) / 2α)``

    Use this when ``thickness >> b_HAZ``.

    Reference: Rosenthal 1941.
    """
    if not all(_is_finite(x) for x in [Q_W, v_mm_s, T_0_C, x_mm, r_mm, k_W_mK, alpha_mm2_s]):
        return float("nan")
    if k_W_mK <= 0:
        return float("nan")
    v_m_s = float(v_mm_s) / 1000.0
    x_m = float(x_mm) / 1000.0
    r_m = float(r_mm) / 1000.0
    alpha_m2_s = float(alpha_mm2_s) / 1e6
    R_m = math.sqrt(x_m ** 2 + r_m ** 2)
    if R_m < 1e-9:
        return float("inf")
    pre = float(Q_W) / (2.0 * math.pi * float(k_W_mK) * R_m)
    expo = math.exp(-v_m_s * (R_m + x_m) / (2.0 * alpha_m2_s))
    return float(T_0_C) + pre * expo


# ---------------------------------------------------------------------------
# 5. COOLING TIME t_8/5
# ---------------------------------------------------------------------------


def cooling_time_t85(
    Q_kJ_mm: float, T_0_C: float, thickness_mm: float, *,
    geometry: Literal["thin", "thick"] = "thin",
    F2: float = 1.0,
    rho_cp_J_mm3K: float = 4.5e-3,
    k_W_mmK: float = 0.05,
) -> float:
    """Cooling time between 800 °C and 500 °C — the canonical HAZ predictor.

    Two regimes per EN 1011-2 / SEW 088. Note the EN nomenclature: a **thin**
    plate cools by **two-dimensional** in-plane heat flow, a **thick** plate
    by **three-dimensional** flow:

    * **Thin plate** (2D heat flow):
      ``t_85 = (Q²/(4π·k·ρc·t²)) · F2 · (1/(500−T_0)² − 1/(800−T_0)²)``
    * **Thick plate** (3D heat flow):
      ``t_85 = (Q/(2π·k)) · F3 · (1/(500−T_0) − 1/(800−T_0))``

    Yurioka 1995 demonstrates that the HAZ microstructure (martensite vs
    bainite vs ferrite-pearlite) is set primarily by t_85.

    Parameters
    ----------
    Q_kJ_mm: heat input in kJ/mm (= 10⁻³ × W·s/mm).
    T_0_C: preheat / interpass temperature in °C.
    thickness_mm: plate thickness.
    geometry: 'thin' (3D) vs 'thick' (2D) — pick from plate thickness vs
        Q rule per EN 1011-2 §C.2.
    F2: geometric factor (1.0 for fillet weld, 0.67 for butt-weld typical).
    rho_cp_J_mm3K: volumetric heat capacity (4.5e-3 J/mm³/K for steel).
    k_W_mmK: conductivity (0.05 W/mm/K for steel).

    Reference: EN 1011-2 (2001) Annex D; SEW 088 (1993); Yurioka 1995.
    """
    if not all(_is_finite(x) for x in [Q_kJ_mm, T_0_C, thickness_mm, F2, rho_cp_J_mm3K, k_W_mmK]):
        return float("nan")
    if thickness_mm <= 0 or k_W_mmK <= 0:
        return float("nan")
    Q_J_mm = float(Q_kJ_mm) * 1000.0
    T0 = float(T_0_C)
    if (500 - T0) <= 0 or (800 - T0) <= 0:
        return float("nan")

    if geometry == "thin":
        # 2D in-plane heat flow (EN 1011-2 thin-plate regime)
        t_sq = float(thickness_mm) ** 2
        pre = (Q_J_mm ** 2) / (4.0 * math.pi * float(k_W_mmK) * float(rho_cp_J_mm3K) * t_sq)
        return pre * float(F2) * (1.0 / (500 - T0) ** 2 - 1.0 / (800 - T0) ** 2)
    else:
        # 3D heat flow (EN 1011-2 thick-plate regime). The 2π factor was
        # previously missing, which inflated the linear-regime result ~6×.
        return (Q_J_mm / (2.0 * math.pi * float(k_W_mmK))) * float(F2) * (
            1.0 / (500 - T0) - 1.0 / (800 - T0)
        )


# ---------------------------------------------------------------------------
# 6. YURIOKA PREHEAT RECOMMENDATION
# ---------------------------------------------------------------------------


def yurioka_preheat_C(
    ce_yurioka_value: float, hydrogen_ppm: float, thickness_mm: float,
    *,
    restraint: Literal["low", "medium", "high"] = "medium",
) -> float:
    """Yurioka 1981 preheat recommendation for cold-crack prevention.

    ``T_preheat = a · CE + b · log10(H) + c · t + offset(restraint)``

    Simplified fit:
        T_pre = 1440·CE_Y − 392 + 100·log10(H_diff_ppm) + 0.5·t_mm + R_offset

    where R_offset ∈ {0, 20, 40 °C} for low/medium/high restraint.

    Bounded at [0, 350 °C].

    Reference: Yurioka N., Suzuki H., Met. Constr. 13 (1981) 217.
    """
    if not all(_is_finite(x) for x in [ce_yurioka_value, hydrogen_ppm, thickness_mm]):
        return float("nan")
    if hydrogen_ppm <= 0:
        hydrogen_ppm = 0.1  # don't crash on dry weld
    R_offsets = {"low": 0.0, "medium": 20.0, "high": 40.0}
    R = R_offsets.get(restraint, 20.0)
    T_pre = (1440.0 * float(ce_yurioka_value) - 392.0
             + 100.0 * math.log10(float(hydrogen_ppm))
             + 0.5 * float(thickness_mm) + R)
    return max(0.0, min(350.0, T_pre))


# ---------------------------------------------------------------------------
# 7. HAZ width estimate
# ---------------------------------------------------------------------------


def haz_width_mm(
    Q_kJ_mm: float, T_peak_C: float, T_0_C: float, *,
    thickness_mm: float = 10.0,
    k_W_mmK: float = 0.05,
    rho_cp_J_mm3K: float = 4.5e-3,
) -> float:
    """HAZ isotherm width at peak T (e.g. AC3 ≈ 850 °C for ferrite-pearlite
    transformation).

    From Rosenthal 2D in steady state:
        b_HAZ = sqrt(Q / (e · π · ρc · t · (T_peak − T_0)))

    where e = Euler's number ≈ 2.718. Used to estimate HAZ extent during
    WPS qualification.
    """
    if not all(_is_finite(x) for x in [Q_kJ_mm, T_peak_C, T_0_C, thickness_mm,
                                       k_W_mmK, rho_cp_J_mm3K]):
        return float("nan")
    if T_peak_C <= T_0_C or thickness_mm <= 0:
        return float("nan")
    Q_J_mm = float(Q_kJ_mm) * 1000.0
    return math.sqrt(Q_J_mm / (math.e * math.pi * float(rho_cp_J_mm3K)
                               * float(thickness_mm) * (float(T_peak_C) - float(T_0_C))))


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "ce_iiw", "ce_yurioka", "pcm_ito_bessyo", "cet_duren",
    "ARC_EFFICIENCY", "heat_input_kJ_per_mm",
    "dilution_pct", "mixed_zone_composition",
    "rosenthal_2d_temperature", "rosenthal_3d_temperature",
    "cooling_time_t85",
    "yurioka_preheat_C",
    "haz_width_mm",
]
