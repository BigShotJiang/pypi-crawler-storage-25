"""Liquid-metal physics: surface tension, viscosity, density, slag-metal thermo.

Used in casting / welding / AM melt-pool engineering. Closes the gap that
no open-source materials library ships these together.

* **Iida-Guthrie surface tension** σ(T) for liquid metals.
* **Andrade viscosity** η(T) = A·exp(B/T) for liquid metals.
* **Riboud-Roth-Lucas slag viscosity** for CaO-Al2O3-SiO2-MgO systems.
* **Sieverts hydrogen solubility** in liquid Fe.
* **Surface-tension Marangoni dM/dT** for melt-pool prediction.

References:
    * Iida T., Guthrie R.I.L., "Physical Properties of Liquid Metals" Oxford UP (1988).
    * Andrade E.N. da C., Phil. Mag. 17 (1934) 497, 698.
    * Riboud P.V., Roth Y., Lucas L.D., et al., Fachber. Hüttenpraxis 19 (1981) 859.
    * Sieverts A., Z. phys. Chem. 60 (1907) 129.
    * Mills K.C., et al., "Recommended Values of Thermophysical Properties for
      Selected Commercial Alloys" Woodhead (2002).
    * Lange's "Handbook of Chemistry" 17th ed. (2017) for backup data.
"""

from __future__ import annotations

import math


# ---------------------------------------------------------------------------
# 1. SURFACE TENSION — Iida-Guthrie database + T-dependence
# ---------------------------------------------------------------------------


# Database: σ_0 in mN/m at T_m, dσ/dT in mN/(m·K), and melting T.
# From Iida-Guthrie 1988 Table 8.5.1 + Mills 2002 update.
LIQUID_METAL_SURFACE_TENSION: dict[str, dict] = {
    "Fe":  {"sigma_0": 1865, "dsigma_dT": -0.43, "T_m_K": 1811, "citation": "Iida-Guthrie 1988"},
    "Ni":  {"sigma_0": 1834, "dsigma_dT": -0.38, "T_m_K": 1728, "citation": "Iida-Guthrie 1988"},
    "Co":  {"sigma_0": 1880, "dsigma_dT": -0.45, "T_m_K": 1768, "citation": "Mills 2002"},
    "Cu":  {"sigma_0": 1304, "dsigma_dT": -0.33, "T_m_K": 1358, "citation": "Iida-Guthrie 1988"},
    "Ag":  {"sigma_0": 925,  "dsigma_dT": -0.20, "T_m_K": 1235, "citation": "Iida-Guthrie 1988"},
    "Au":  {"sigma_0": 1140, "dsigma_dT": -0.52, "T_m_K": 1338, "citation": "Iida-Guthrie 1988"},
    "Al":  {"sigma_0": 914,  "dsigma_dT": -0.35, "T_m_K": 933,  "citation": "Mills 2002"},
    "Mg":  {"sigma_0": 559,  "dsigma_dT": -0.35, "T_m_K": 923,  "citation": "Mills 2002"},
    "Zn":  {"sigma_0": 782,  "dsigma_dT": -0.17, "T_m_K": 693,  "citation": "Iida-Guthrie 1988"},
    "Pb":  {"sigma_0": 458,  "dsigma_dT": -0.13, "T_m_K": 600,  "citation": "Iida-Guthrie 1988"},
    "Sn":  {"sigma_0": 560,  "dsigma_dT": -0.08, "T_m_K": 505,  "citation": "Iida-Guthrie 1988"},
    "Ti":  {"sigma_0": 1650, "dsigma_dT": -0.26, "T_m_K": 1941, "citation": "Mills 2002"},
    "Cr":  {"sigma_0": 1700, "dsigma_dT": -0.32, "T_m_K": 2180, "citation": "Mills 2002"},
    "Mo":  {"sigma_0": 2250, "dsigma_dT": -0.30, "T_m_K": 2896, "citation": "Iida-Guthrie 1988"},
    "W":   {"sigma_0": 2316, "dsigma_dT": -0.29, "T_m_K": 3695, "citation": "Iida-Guthrie 1988"},
    "Ta":  {"sigma_0": 2150, "dsigma_dT": -0.21, "T_m_K": 3290, "citation": "Mills 2002"},
    "Nb":  {"sigma_0": 1900, "dsigma_dT": -0.24, "T_m_K": 2750, "citation": "Mills 2002"},
}


def iida_guthrie_surface_tension(
    element: str, T_K: float,
) -> float:
    """Linear extrapolation: ``σ(T) = σ_0 − |dσ/dT| · (T − T_m)``.

    Returns surface tension in mN/m (= dyn/cm).
    """
    entry = LIQUID_METAL_SURFACE_TENSION.get(element)
    if entry is None or not _is_finite(T_K):
        return float("nan")
    return float(entry["sigma_0"]) + float(entry["dsigma_dT"]) * (float(T_K) - float(entry["T_m_K"]))


def marangoni_dsigma_dT(element: str) -> float:
    """Return dσ/dT in mN/(m·K). Negative for clean liquid metals."""
    entry = LIQUID_METAL_SURFACE_TENSION.get(element)
    return float(entry["dsigma_dT"]) if entry else float("nan")


# ---------------------------------------------------------------------------
# 2. VISCOSITY — Andrade
# ---------------------------------------------------------------------------


# Andrade: η(T) = A·exp(B/T)
# A in mPa·s, B in K. B re-fitted so η(T_m) matches the experimental
# melting-point viscosities tabulated by Iida-Guthrie 1988 (Table 4.7) /
# Battezzati-Greer 1989: Fe 5.5, Ni 4.9, Co 4.5, Cu 4.0, Al 1.3, Zn 3.85,
# Sn 2.0, Pb 2.6, Ag 3.9, Au 5.0 mPa·s, etc. (The previous B values were
# ~1.6-2× too large, over-predicting η_m by 6-20×.)
LIQUID_METAL_VISCOSITY: dict[str, dict] = {
    "Fe": {"A": 0.37, "B": 4888, "T_m_K": 1811, "citation": "Iida-Guthrie 1988"},
    "Ni": {"A": 0.40, "B": 4329, "T_m_K": 1728, "citation": "Iida-Guthrie 1988"},
    "Co": {"A": 0.36, "B": 4466, "T_m_K": 1768, "citation": "Iida-Guthrie 1988"},
    "Cu": {"A": 0.30, "B": 3517, "T_m_K": 1358, "citation": "Iida-Guthrie 1988"},
    "Al": {"A": 0.149, "B": 1990, "T_m_K": 933, "citation": "Mills 2002"},
    "Mg": {"A": 0.15, "B": 2100, "T_m_K": 923, "citation": "Mills 2002"},
    "Zn": {"A": 0.40, "B": 1569, "T_m_K": 693, "citation": "Iida-Guthrie 1988"},
    "Sn": {"A": 0.74, "B": 502, "T_m_K": 505, "citation": "Iida-Guthrie 1988"},
    "Pb": {"A": 0.46, "B": 1039, "T_m_K": 600, "citation": "Iida-Guthrie 1988"},
    "Ag": {"A": 0.45, "B": 2667, "T_m_K": 1235, "citation": "Iida-Guthrie 1988"},
    "Au": {"A": 1.13, "B": 1990, "T_m_K": 1338, "citation": "Iida-Guthrie 1988"},
    "Ti": {"A": 0.30, "B": 5538, "T_m_K": 1941, "citation": "Mills 2002"},
    "Cr": {"A": 0.31, "B": 6347, "T_m_K": 2180, "citation": "Mills 2002"},
    "Mo": {"A": 0.34, "B": 8062, "T_m_K": 2896, "citation": "Iida-Guthrie 1988"},
    "W":  {"A": 0.37, "B": 10864, "T_m_K": 3695, "citation": "Iida-Guthrie 1988"},
}


def andrade_viscosity(element: str, T_K: float) -> float:
    """Andrade 1934 viscosity of liquid metal:  ``η(T) = A · exp(B/T)``.

    Returns viscosity in mPa·s (= cP).
    """
    entry = LIQUID_METAL_VISCOSITY.get(element)
    if entry is None or not _is_finite(T_K) or T_K <= 0:
        return float("nan")
    try:
        return float(entry["A"]) * math.exp(float(entry["B"]) / float(T_K))
    except OverflowError:
        return float("inf")


# ---------------------------------------------------------------------------
# 3. RIBOUD-ROTH-LUCAS SLAG VISCOSITY
# ---------------------------------------------------------------------------


def riboud_slag_viscosity(
    *, X_CaO: float, X_SiO2: float, X_Al2O3: float, X_MgO: float = 0.0,
    X_CaF2: float = 0.0, X_Na2O: float = 0.0, T_K: float = 1773,
) -> float:
    """Riboud-Roth-Lucas 1981 viscosity model for CaO-Al2O3-SiO2 slags.

    log10(η_Pa·s) = A + B / T  where A, B depend on the modified slag basicity.

    Inputs are mole fractions. Used in steelmaking ladle / casting tundish
    + continuous-casting mold-flux design.

    Reference: Riboud P.V., Roth Y., Lucas L.D., et al., Fachber. Hüttenpraxis
    19 (1981) 859.
    """
    if not all(_is_finite(x) for x in [X_CaO, X_SiO2, X_Al2O3, X_MgO, X_CaF2, X_Na2O, T_K]):
        return float("nan")
    # Modified mole fractions per Riboud:
    X_M = X_CaO + X_MgO + X_Na2O + X_CaF2  # network-modifiers
    X_AmO = X_Al2O3                          # amphoteric
    X_N = X_SiO2                              # network-formers

    # Slag basicity index (simplified)
    if X_N <= 0:
        return float("inf")
    basicity = X_M / max(0.001, X_N)

    # Empirical A, B (Riboud Table 2; simplified)
    A = -19.81 + 1.73 * basicity + 4.0 * X_AmO + 5.82 * X_CaF2
    B = 31140.0 - 23896.0 * X_CaF2 - 39159.0 * basicity * X_AmO

    log_eta = A + B / float(T_K)
    try:
        return 10 ** log_eta
    except OverflowError:
        return float("inf")


# ---------------------------------------------------------------------------
# 4. SIEVERTS — HYDROGEN SOLUBILITY IN LIQUID Fe
# ---------------------------------------------------------------------------


def sieverts_H_solubility_in_Fe(
    p_H2_bar: float, T_K: float,
) -> float:
    """Sieverts hydrogen solubility in liquid Fe:

        [H]_ppm = K_S(T) · sqrt(p_H2)

    with the Weinstein-Elliott 1963 fit ``log10[H, ppm] = −1900/T + 2.423``
    at p_H2 = 1 atm, i.e. ``K_S(T) = 10^(2.423) · 10^(−1900/T)``. This gives
    ≈26 ppm at 1873 K / 1 bar, matching steelmaking practice (the previous
    ``27·exp(−1882/T)`` fit under-predicted by ~2.6×).

    Reference: Weinstein M., Elliott J.F., Trans. AIME 227 (1963) 382;
    Sieverts A., Z. phys. Chem. 60 (1907) 129.
    """
    if not all(_is_finite(x) for x in [p_H2_bar, T_K]):
        return float("nan")
    if p_H2_bar < 0 or T_K <= 0:
        return float("nan")
    K_S = 10.0 ** (2.423 - 1900.0 / float(T_K))
    return K_S * math.sqrt(float(p_H2_bar))


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "LIQUID_METAL_SURFACE_TENSION", "iida_guthrie_surface_tension", "marangoni_dsigma_dT",
    "LIQUID_METAL_VISCOSITY", "andrade_viscosity",
    "riboud_slag_viscosity",
    "sieverts_H_solubility_in_Fe",
]
