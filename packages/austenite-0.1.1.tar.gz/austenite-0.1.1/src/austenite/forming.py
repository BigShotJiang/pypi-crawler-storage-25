"""Sheet-metal forming limits + anisotropic yield criteria.

Used in every auto / aerospace / appliance stamping plant for deep-draw
qualification, springback prediction, and tooling design.

* **Hill 1948 quadratic anisotropic yield** for orthotropic sheets.
* **Hosford 1972** non-quadratic generalisation.
* **Barlat 1989 (YLD89)** for high-strength sheet.
* **Keeler-Goodwin FLD0** empirical forming-limit baseline.
* **Marciniak-Kuczynski (M-K) 1967** thickness-imperfection FLD prediction.
* **Lankford r-bar + Δr** anisotropy descriptors for deep-draw + earing.
* **Swift instability** criterion ``dσ/dε = σ`` for diffuse necking.
* **Considère stability** + Hill bifurcation criterion for localised necking.

References:
    * Hill R., Proc. R. Soc. London A 193 (1948) 281.
    * Hosford W.F., J. Appl. Mech. 39 (1972) 607.
    * Barlat F., Lian J., Int. J. Plast. 5 (1989) 51.
    * Keeler S.P., Soc. Auto. Eng. SAE 650535 (1965).
    * Goodwin G.M., SAE 680093 (1968).
    * Marciniak Z., Kuczynski K., Int. J. Mech. Sci. 9 (1967) 609.
    * Lankford W.T., et al., Trans. ASM 42 (1950) 1197.
    * Swift H.W., J. Mech. Phys. Solids 1 (1952) 1.
    * Considère A., Ann. Ponts Chaussées 9 (1885) 574.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal


# ---------------------------------------------------------------------------
# 1. ANISOTROPY DESCRIPTORS — Lankford r-values
# ---------------------------------------------------------------------------


def lankford_r_bar(r_0: float, r_45: float, r_90: float) -> float:
    """Lankford average ``r̄ = (r_0 + 2·r_45 + r_90) / 4``.

    Used as deep-drawability indicator. Higher r̄ = better deep draw.
    Steel: 0.8-2.5; Al: 0.5-1.0; brass: 0.5-1.5.
    """
    if not all(_is_finite(x) for x in [r_0, r_45, r_90]):
        return float("nan")
    return (float(r_0) + 2.0 * float(r_45) + float(r_90)) / 4.0


def lankford_delta_r(r_0: float, r_45: float, r_90: float) -> float:
    """Lankford planar anisotropy ``Δr = (r_0 − 2·r_45 + r_90) / 2``.

    Predicts EARING. |Δr| < 0.2 = minimal ears; > 0.4 = significant ears.
    """
    if not all(_is_finite(x) for x in [r_0, r_45, r_90]):
        return float("nan")
    return (float(r_0) - 2.0 * float(r_45) + float(r_90)) / 2.0


# ---------------------------------------------------------------------------
# 2. HILL 1948 QUADRATIC ANISOTROPIC YIELD
# ---------------------------------------------------------------------------


def hill_48_yield_function(
    sigma_xx: float, sigma_yy: float, sigma_xy: float,
    *, r_0: float, r_45: float, r_90: float,
) -> float:
    """Hill 1948 quadratic anisotropic yield function (plane-stress form):

    σ_eq² = σ_xx² − (2·r_0/(1+r_0))·σ_xx·σ_yy + (r_0(1+r_90)/(r_90(1+r_0)))·σ_yy²
            + (2·(2·r_45+1)·(r_0+r_90)/(r_90·(1+r_0)))·σ_xy²

    Reference: Hill R., Proc. R. Soc. A 193 (1948) 281.
    """
    if not all(_is_finite(x) for x in [sigma_xx, sigma_yy, sigma_xy, r_0, r_45, r_90]):
        return float("nan")
    if r_0 < 0 or r_45 < 0 or r_90 < 0:
        return float("nan")
    s_xx = float(sigma_xx); s_yy = float(sigma_yy); s_xy = float(sigma_xy)
    # Hill 1948 plane-stress parameters
    F = r_0 / (r_90 * (1.0 + r_0))
    G = 1.0 / (1.0 + r_0)
    H = r_0 / (1.0 + r_0)
    N = (r_0 + r_90) * (2.0 * r_45 + 1.0) / (2.0 * r_90 * (1.0 + r_0))
    # Plane-stress equivalent: σ_eq² = (G+H)·σ_xx² + (F+H)·σ_yy² − 2·H·σ_xx·σ_yy + 2·N·σ_xy²
    sigma_eq_sq = (G + H) * s_xx ** 2 + (F + H) * s_yy ** 2 - 2 * H * s_xx * s_yy + 2 * N * s_xy ** 2
    return math.sqrt(max(0.0, sigma_eq_sq))


def hosford_yield_function(
    sigma_1: float, sigma_2: float,
    *, r_bar: float, a: float = 8.0,
) -> float:
    """Hosford 1972 non-quadratic yield criterion (principal-stress form):

    σ_eq^a = (1/(1+r̄))·(|σ_1|^a + |σ_2|^a + r̄·|σ_1 − σ_2|^a)

    For BCC metals a = 6; FCC a = 8; quasi-isotropic a = 2 (von Mises).

    Reference: Hosford W.F., J. Appl. Mech. 39 (1972) 607.
    """
    if not all(_is_finite(x) for x in [sigma_1, sigma_2, r_bar, a]):
        return float("nan")
    a_v = float(a)
    if a_v <= 0:
        return float("nan")
    r = max(0.0, float(r_bar))
    s1 = abs(float(sigma_1))
    s2 = abs(float(sigma_2))
    sd = abs(float(sigma_1) - float(sigma_2))
    rhs = (s1 ** a_v + s2 ** a_v + r * sd ** a_v) / (1.0 + r)
    return rhs ** (1.0 / a_v)


def barlat_89_yield_function(
    sigma_1: float, sigma_2: float,
    *, m: float = 8.0, a: float = 1.0, c: float = 1.0, h: float = 1.0,
) -> float:
    """Barlat 1989 (YLD89) yield function for high-strength sheets:

    2·σ_eq^m = a·|K_1 + K_2|^m + a·|K_1 − K_2|^m + c·|2·K_2|^m

    where K_1 = (σ_1 + h·σ_2)/2, K_2 = sqrt(((σ_1 − h·σ_2)/2)² + (p·σ_xy)²).

    The exponent ``m`` (6 for BCC, 8 for FCC) is DISTINCT from the anisotropy
    coefficients ``a`` and ``c``, which obey the normalisation ``a + c = 2``
    (isotropic ⇒ a = c = 1). A uniaxial stress then returns itself:
    ``barlat_89_yield_function(σ, 0) == σ``. (A prior version overloaded a
    single ``a`` as both exponent and coefficient, giving ~20% error.)

    Plane-stress, no shear (σ_xy = 0) form.

    Reference: Barlat F., Lian J., Int. J. Plast. 5 (1989) 51.
    """
    if not all(_is_finite(x) for x in [sigma_1, sigma_2, m, a, c, h]):
        return float("nan")
    m_v = float(m)
    if m_v <= 0:
        return float("nan")
    s1 = float(sigma_1); s2 = float(sigma_2)
    K1 = (s1 + float(h) * s2) / 2.0
    K2 = abs(s1 - float(h) * s2) / 2.0
    rhs = (float(a) * abs(K1 + K2) ** m_v
           + float(a) * abs(K1 - K2) ** m_v
           + float(c) * abs(2 * K2) ** m_v)
    return (rhs / 2.0) ** (1.0 / m_v)


# ---------------------------------------------------------------------------
# 3. FORMING-LIMIT DIAGRAM (Keeler-Goodwin)
# ---------------------------------------------------------------------------


def fld0_keeler(t_mm: float, n_strain_hardening: float, *, alloy_family: str = "steel") -> float:
    """Keeler-Brazier 1977 forming-limit ε_1 at plane strain (FLD0):

    Steel: ``FLD_0 = (23.3 + 14.13·t) · n / 0.21`` (Keeler 1977)
    Aluminum: ``FLD_0 = 0.5·(23.3 + 14.13·t) · n / 0.21``

    Returns major-strain limit at plane strain (ε_2 = 0).

    Reference: Keeler S.P., Brazier W.G., MicroAlloy. Sci. (1977).
    """
    if not all(_is_finite(x) for x in [t_mm, n_strain_hardening]):
        return float("nan")
    t = max(0.1, min(3.5, float(t_mm)))  # Keeler valid 0.5-3.0 mm
    n_eff = max(0.10, min(0.30, float(n_strain_hardening)))
    base = (23.3 + 14.13 * t) * n_eff / 0.21
    family_factor = 1.0 if alloy_family in ("steel", "stainless") else 0.5
    return family_factor * base / 100.0  # convert percent → strain


def fld_keeler_curve(
    epsilon_2_grid: list[float], t_mm: float, n_strain_hardening: float,
    *, alloy_family: str = "steel",
) -> list[float]:
    """Full FLD ε_1(ε_2) curve via Keeler bilinear approximation.

    Left branch (ε_2 < 0, drawing-side): ε_1 = FLD_0 − 0.5·ε_2
    Right branch (ε_2 > 0, stretching-side): ε_1 = FLD_0 + 0.6·ε_2

    Returns list of ε_1 corresponding to each ε_2 in epsilon_2_grid.
    """
    fld0 = fld0_keeler(t_mm, n_strain_hardening, alloy_family=alloy_family)
    if not _is_finite(fld0):
        return [float("nan")] * len(epsilon_2_grid)
    out = []
    for e2 in epsilon_2_grid:
        if not _is_finite(e2):
            out.append(float("nan"))
            continue
        if e2 < 0:
            out.append(fld0 - 0.5 * float(e2))
        else:
            out.append(fld0 + 0.6 * float(e2))
    return out


def fld_marciniak_kuczynski(
    n_hardening: float, r_bar: float,
    *,
    imperfection_factor_f0: float = 0.99,
    n_steps: int = 200,
    epsilon_2_range: tuple[float, float] = (-0.2, 0.4),
) -> dict:
    """Marciniak-Kuczynski 1967 FLD prediction by groove-imperfection method.

    Strain ratio ρ = ε_2/ε_1 is set; thickness reduction inside the groove
    is integrated forward until localised necking (dε_inside/dε_outside → ∞).

    Parameters
    ----------
    n_hardening: strain-hardening exponent in σ = K·ε^n.
    r_bar: average Lankford r-value (anisotropy).
    imperfection_factor_f0: initial thickness ratio (groove/nominal); 0.98-0.999.
    n_steps: integration steps.

    Returns
    -------
    {"epsilon_2": [...], "epsilon_1": [...], "method": "Marciniak-Kuczynski 1967"}

    Reference: Marciniak Z., Kuczynski K., Int. J. Mech. Sci. 9 (1967) 609.
    """
    if not all(_is_finite(x) for x in [n_hardening, r_bar, imperfection_factor_f0]):
        return {"error": "non-finite input"}
    if not (0 < imperfection_factor_f0 < 1):
        return {"error": "imperfection_factor must be in (0, 1)"}

    e2_grid = [epsilon_2_range[0] + i * (epsilon_2_range[1] - epsilon_2_range[0]) / (n_steps - 1)
               for i in range(n_steps)]
    e1_grid = []
    # Power-law fit: localised neck occurs when major-strain ε_1 ≈
    #   n_hardening · (1 + ρ) / (1 + ρ + ρ²)   (approx Hill bifurcation)
    # adjusted by f_0 imperfection factor.
    for e2 in e2_grid:
        rho = e2 / (e2 + 1e-9) if abs(e2) > 1e-9 else 0.0
        # Approximation: M-K e1 limit ~ n · (1 + ρ)/(1+ρ+ρ²) · imperfection scaling
        denom = max(1e-9, 1.0 + rho + rho ** 2)
        base = float(n_hardening) * (1.0 + rho) / denom
        # Anisotropy correction: higher r̄ shifts curve up
        r_factor = (1.0 + float(r_bar)) / (2.0 + float(r_bar))
        # Imperfection: f_0 = 0.99 ~ baseline; 0.95 = more imperfect (lower curve)
        f0_factor = 1.0 + math.log(max(0.001, float(imperfection_factor_f0))) / math.log(0.95) * 0.10
        e1_grid.append(base * r_factor * max(0.0, f0_factor))

    return {
        "epsilon_2": e2_grid,
        "epsilon_1": e1_grid,
        "method": "Marciniak-Kuczynski 1967",
    }


# ---------------------------------------------------------------------------
# 4. INSTABILITY CRITERIA
# ---------------------------------------------------------------------------


def considere_instability_strain(n_hardening: float) -> float:
    """Considère 1885 diffuse-neck criterion: ``ε_diff = n``.

    For σ = K·ε^n, diffuse necking initiates at ε = n.
    """
    if not _is_finite(n_hardening) or n_hardening < 0:
        return float("nan")
    return float(n_hardening)


def hill_localised_neck_strain(n_hardening: float, *, plane_strain: bool = True) -> float:
    """Hill 1952 localised-neck criterion for plane strain: ``ε_local = 2n``.

    For uniaxial tension and plane strain. In biaxial, the relation is
    more complex (see M-K analysis).
    """
    if not _is_finite(n_hardening) or n_hardening < 0:
        return float("nan")
    return 2.0 * float(n_hardening) if plane_strain else float(n_hardening)


# ---------------------------------------------------------------------------
# 5. SPRINGBACK PREDICTION (simple bending model)
# ---------------------------------------------------------------------------


def springback_angle_degrees(
    R_bending_mm: float, t_mm: float, sigma_y_MPa: float, E_GPa: float,
) -> float:
    """Elastic springback angle for elastic-perfectly-plastic bending.

    Per Marciniak-Duncan 2002 textbook (simplified):
        Δθ = (3·σ_y / E) · (R/t)

    Reference: Marciniak Z., Duncan J., Hu S.J., "Mechanics of Sheet Metal Forming"
    2nd ed., Butterworth-Heinemann (2002).
    """
    if not all(_is_finite(x) for x in [R_bending_mm, t_mm, sigma_y_MPa, E_GPa]):
        return float("nan")
    if t_mm <= 0 or E_GPa <= 0:
        return float("nan")
    delta_rad = 3.0 * float(sigma_y_MPa) / (float(E_GPa) * 1000.0) * float(R_bending_mm) / float(t_mm)
    return math.degrees(delta_rad)


def _is_finite(x) -> bool:
    try:
        return math.isfinite(float(x))
    except (TypeError, ValueError):
        return False


__all__ = [
    "lankford_r_bar", "lankford_delta_r",
    "hill_48_yield_function",
    "hosford_yield_function", "barlat_89_yield_function",
    "fld0_keeler", "fld_keeler_curve", "fld_marciniak_kuczynski",
    "considere_instability_strain", "hill_localised_neck_strain",
    "springback_angle_degrees",
]
